-- "addons\\evo_wordfilter\\lua\\autorun\\evo_wordfilter.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- evo_wordfilter — BASE COMMUNE de mots interdits (insultes / slurs / sexuel / haine /
-- usurpation staff...) partagée par : nom de katana (shikai), pseudos in-game (création
-- de perso), et chat. Fichier autorun SHARED -> EVO_WordFilter dispo client + serveur.
--
-- API :
--   EVO_WordFilter.Normalize(s)  -> minuscules + leetspeak + retrait des non-lettres
--   EVO_WordFilter.Contains(text)-> true si `text` contient un mot interdit.
--                                   Pour les NOMS : sous-chaîne (agressif), sauf stems
--                                   courts (≤4) / ExactOnly → match exact uniquement.
--   EVO_WordFilter.Censor(text)  -> remplace chaque MOT interdit par des * (pour le CHAT).
--                                   Match EXACT sur le token normalisé (pas de sous-chaîne
--                                   → "analyser" ne match plus "anal", etc.).
--   EVO_WordFilter.Words         -> insultes / slurs (chat + noms)
--   EVO_WordFilter.NameOnly      -> usurpation staff/système (NOMS seulement, pas le chat)
-- ============================================================

EVO_WordFilter = EVO_WordFilter or {}

-- Base multilingue (formes NORMALISÉES : minuscules, sans accents/espaces/ponctuation, car
-- le texte est normalisé pareil avant comparaison). Ajoute en gardant ce format.
EVO_WordFilter.Words = {
    -- ── Slurs raciaux / ethniques (EN) ───────────────────────────────────────
    "nigger", "nigga", "niggah", "niggor", "niggress", "negro", "negros", "negroe",
    "coon", "jigaboo", "porchmonkey", "tarbaby", "darkie", "darky", "sambo",
    "chink", "chingchong", "chinaman", "gook", "slanteye", "zipperhead",
    "spic", "spick", "beaner", "wetback", "greaser", "sudaca",
    "kike", "kyke", "heeb", "hymie",
    "paki", "raghead", "towelhead", "sandnigger", "cameljockey", "muzzie", "mudslime",
    "wop", "dago", "guido", "kraut", "polack", "redskin", "injun", "abbo", "halfbreed", "mudblood",
    -- ── Slurs / insultes ethniques (FR) ──────────────────────────────────────
    "bougnoule", "bougnoul", "bamboula", "bicot", "niakoue", "niakwe", "chinetoque", "youpin",
    "feuj", "raton", "ratonnade", "negresse", "negre", "salearabe", "saleblanc", "salenoir",
    "salejuif", "salenegre", "chintoc", "crouille",
    -- ── Homophobes / transphobes (multi) ─────────────────────────────────────
    "faggot", "fagot", "faggit", "faggotry", "dyke", "tranny", "trannie", "shemale", "ladyboy",
    "queerbait", "pede", "pedale", "tarlouze", "tapette", "fiotte", "gouine",
    "enculedesa", "maricon", "marica", "maricona", "frocio", "finocchio", "viado", "bicha",
    "schwuchtel", "battyboy", "tarro", "poofter", "zamel", "fairyboy", "battybwoy", "chichiman",
    "buttpirate", "fudgepacker", "carpetmuncher", "rugmuncher", "homofag", "tantouze",
    "broutegazon", "ricchione", "checca", "culattone", "flikker",
    -- ── Sexuel — vocabulaire neutre FR/EN (volontairement large) ─────────────
    -- Inclut termes cliniques / d'orientation : la politique serveur est zéro
    -- discussion sexuelle, même neutre. Stems courts (sex/sexe/sexy) = exact (≤4).
    "sex", "sexe", "sexo", "sexy", "sexual", "sexuel", "sexuelle", "sexuels", "sexuelles",
    "sexually", "sexuellement", "sexuality", "sexualite", "sexualiser", "sexualise",
    "homosexual", "homosexuel", "homosexuelle", "homosexuels", "homosexuelles",
    "homosexuality", "homosexualite",
    "heterosexual", "heterosexuel", "heterosexuelle", "heterosexuality", "heterosexualite",
    "bisexual", "bisexuel", "bisexuelle", "bisexuality", "bisexualite",
    "pansexual", "pansexuel", "asexual", "asexuel", "asexuelle",
    "erotic", "erotica", "erotique", "erotisme", "libido", "coitus", "coit", "intercourse",
    "fornication", "genital", "genitals", "genitaux", "genitale", "clitoris", "testicule",
    "testicles", "testicules", "scrotum", "nude", "nudes", "nudity", "nudite", "naked",
    "pornographie", "pornography", "pornographique",
    -- ── Sexuel / explicite (EN) ──────────────────────────────────────────────
    -- "anal" ≤4 → exact only : le mot seul est censuré, pas analyser/canal/banal.
    "porn", "porno", "pornhub", "xxx", "pussy", "cock", "dick", "cunt",
    "whore", "slut", "bitch", "bastard", "blowjob", "handjob", "cumshot", "cumming", "jizz",
    "boobs", "titties", "anal", "analsex", "rape", "rapist", "molest", "incest", "bestiality",
    "zoophile", "zoophilia", "dildo", "fapping", "masturbat", "ejaculat", "orgasm", "hentai",
    "gangbang", "bukkake", "deepthroat", "creampie", "fetish", "boner", "smegma",
    "necrophil", "scato", "footjob", "bdsm", "milf", "thot", "lolicon", "shotacon", "felching",
    "rimjob", "fisting", "gokkun", "squirting", "cameltoe", "upskirt", "creampied", "gangrape",
    "cumslut", "cumbucket", "fleshlight", "buttplug", "buttsex", "buttfuck", "assfuck", "titfuck",
    "facefuck", "throatfuck", "cockring", "ballsack", "nutsack", "queef", "smut", "camgirl",
    "onlyfans", "ahegao", "futanari", "ecchi", "yiff", "pegging",
    -- ── Sexuel / explicite (FR) ──────────────────────────────────────────────
    "bite", "kbite", "grossebite", "chibre", "teub", "penis", "vagin", "chatte", "nichon",
    "nichons", "salope", "salopes", "pute", "putes", "putain", "putaclic", "suceur", "sucemoi",
    "branleur", "branlette", "branler", "sperme", "baiseur", "baiser", "baise", "encule",
    "enculer", "enculee", "encules", "sodomie", "sodomi", "sodomite", "viol", "violeur", "violer",
    "pedophile", "pedo", "inceste", "masturb", "fellation", "cunnilingus", "levrette", "couille",
    "couilles", "zizi", "foutre", "branle", "ejac", "ejacule", "zoophilie", "roubignoles",
    "foufoune", "cramouille", "biroute", "queutard", "branleux", "branlotin", "chiure",
    "orgasme", "masturbation", "masturber", "ejaculation",
    -- ── Sexuel / explicite (autres langues) ──────────────────────────────────
    "puta", "puto", "polla", "verga", "joder", "follar", "mamada", "pendejo", "chocha", "concha",
    "caralho", "buceta", "foder", "rola", "pinto", "punheta", "putita", "boquete", "punheteiro",
    "cazzo", "figa", "troia", "puttana", "vaffanculo", "pompino", "minchia", "scopare", "mignotta",
    "zoccola", "sticchio", "cesso", "porca",
    "ficken", "fotze", "schwanz", "muschi", "wichser", "nutte", "schlampe", "votze", "hodensack",
    "schwanzlutscher", "fickfresse", "fickdich", "fickfehler",
    "klootzak", "hoer", "neuken",
    "pizda", "khuy", "blyad", "blyat", "suka", "ebat", "mudak", "pidor", "pidoras", "yebat",
    "khuylo", "zalupa", "pizdec",
    "orospu", "amcik", "sikik", "yarrak", "pezevenk", "sikeyim", "aminakoyayim",
    "sharmuta", "charmuta", "kahba", "kuss", "kahpe", "sharmota", "kahbe", "labwa", "metnaka",
    "kurwa", "jebac", "skurwysyn", "chuj", "pierdol", "kutas",
    "manko", "chinko", "chikusho", "omanko", "yariman", "chinpo", "chinchin", "oppai", "yarichin",
    "sukebe", "boji", "jaji",
    -- ── Insultes fortes (EN) ─────────────────────────────────────────────────
    "asshole", "motherfuck", "fucker", "fucking", "fuckyou", "fuckoff", "shithead", "dumbass",
    "jackass", "dickhead", "wanker", "scumbag", "cocksuck", "douchebag", "twat", "prick",
    "fuck", "fuk", "shit", "bullshit", "skank", "tosser", "bellend", "bollocks", "knobhead",
    "arsehole", "minger", "wankstain", "fuckface", "cockwomble", "twatface", "shitstain",
    "cumdumpster", "fucktard", "clusterfuck", "fuckhead", "shitlord", "shitcunt", "twatwaffle",
    "asswipe", "asslicker", "ballbag", "cockhead", "cockface", "dickface", "dickwad", "dickbag",
    "jerkoff", "jackoff", "buttmunch", "shithole", "pisshead", "pissflaps", "knobend", "munter",
    "slapper", "numbnuts", "gobshite", "shitebag", "wank", "spunk", "asshat", "shitbag",
    "shitface", "dipshit", "dumbfuck", "fuckwit", "fuckboy", "cuckold", "incel", "soyboy",
    -- ── Insultes fortes (FR) + abréviations ──────────────────────────────────
    "connard", "conard", "connasse", "conasse", "salaud", "salopard", "batard", "batards",
    "enfoire", "enfoires", "fdp", "filsdepute", "filsdeput", "ntm", "niquetamere", "niquetamre",
    "niquer", "tamere", "tagueule", "fermetagueule", "ftg", "vatefaire", "vatefoutre",
    "vatefairefoutre", "ducon", "trouduc", "troudballe", "petasse", "pouffiasse", "grognasse",
    "tafiole", "merdeux", "chiotte", "abruti", "cretin", "debile", "lopette", "filsdechien",
    "enculedetarace", "samere", "cassos", "boloss", "bouffon", "clochard", "raclure", "tafioler",
    "gogole", "ferpd", "trouducul", "tetedenoeud", "feignasse", "pouffe", "etron", "merdier",
    "couillemolle", "tafioles", "grossevache", "salopiot", "sousmerde", "grossemerde", "chieur",
    "chiasse", "couillon", "tocard", "salopiaud", "vatenculer", "greluche", "souillon", "merde",
    "fumier", "charogne", "saligaud", "crevure", "crevard", "glandu", "garce", "gourgandine",
    "catin", "mangemerde", "salocon", "groscon", "pauvretype", "duconnard", "tabarnak",
    "tabarnac", "calisse", "viarge",
    -- ── Insultes (autres langues) ────────────────────────────────────────────
    "cabron", "gilipollas", "hijodeputa", "mierda", "culero", "chinga", "chingada", "culiao",
    "conchatumadre", "joto", "chingatumadre", "mamahuevo", "putamadre", "malparido", "gonorrea",
    "cerote", "verguero", "chocho", "zorra", "cojones", "gilipuertas", "subnormal", "mamon",
    "marrano",
    "filhodaputa", "merda", "otario", "corno", "arrombado", "vaitomarnocu", "filhadaputa",
    "putaquepariu", "cuzao", "vagabunda", "foda", "fodase", "safado", "babaca", "porra",
    "viadinho", "xota",
    "stronzo", "coglione", "bastardo", "figliodiputtana", "testadicazzo", "stronza", "puttaniere",
    "leccaculo", "merdaiolo", "porcamadonna", "porcodio", "merdaccia", "bastarda", "minchione",
    "arschloch", "hurensohn", "scheisse", "scheise", "missgeburt", "spasti", "hure", "drecksau",
    "judensau", "vollidiot", "verpissdich", "miststuck", "arschgeige", "drecksack", "kackbratze",
    "saftsack", "neger", "trottel", "vollpfosten", "pisser",
    "kankerlijer", "kankerhoer", "kanker", "tyfus", "mongool", "godverdomme", "teringlijer",
    "skurwiel", "gerizekali", "spierdalaj", "pierdolic", "cwel", "ciota", "jebany", "siktir",
    "gavat", "surtuk", "siktirgit", "gotveren", "ibne", "yavsak",
    "gandon", "dolboeb", "eblan", "pidaras", "svoloch", "gnida", "vyrodok", "dolbaeb", "uebok",
    "ohuel", "tvar", "zhopa", "mraz", "ublyudok", "shlyukha", "padla", "yebal", "huj", "pojeb",
    "wypierdalaj", "gnoj", "pierdole", "dziwka", "szmata", "pojebany", "spierdolic",
    "manyak", "zarba", "ahbel", "khara", "tabon", "wladlkahba", "kahbeh", "nikomak",
    "sibal", "shibal", "byeongsin", "gaesaekki", "kaesaekki", "sibalnom", "ddong",
    "madarchod", "behenchod", "bhenchod", "chutiya", "gandu", "bhosdike", "harami", "bhadwa",
    "tatti", "jhaant", "lodu", "bakchod", "chinaal", "kaminey", "kamine", "haraamkhor", "bsdk",
    "gaand", "kutiya", "haramzada", "chodu", "lavde",
    "bakayaro", "kichigai",
    "caonima", "shabi", "biaozi", "wangbadan", "tamade", "nimade", "shenjingbing", "wangba",
    "tamabi",
    "ditme", "cailon", "dumemay", "ditconme", "thangcho", "dumay", "cacut", "dume",
    "putangina", "tangina", "gago", "tarantado", "ulol", "puki", "kantot", "pakshet", "burat",
    "etits",
    "poutana", "gamoto", "archidi", "muie", "cacat", "kurva", "geci", "faszom", "picsa", "buzi",
    "vittu", "huora", "fitta",
    -- ── Validisme / médical insultant ───────────────────────────────────────
    -- Pas de "retard" seul : en FR = être en retard (mot courant). Slurs = retarde(e) / attarde(e) / retarded.
    -- attarde/retarde (+e) en ExactOnly (sinon attarder en sous-chaîne).
    "mongol", "mongolien", "mongoloid", "trisomique", "attarde", "attardee",
    "retarde", "retardee", "debilemental", "autiste", "handicapedu",
    "schizo", "spastic", "cripple", "retarded", "spaz", "spazz", "windowlicker",
    -- ── Haine / nazisme / extrémisme ─────────────────────────────────────────
    "hitler", "nazi", "naziste", "nazism", "nazisme", "swastika", "heilhitler", "sieghail",
    "siegheil", "kkk", "kukluxklan", "holocaust", "holocauste", "genocide", "fuhrer", "fuehrer",
    "troisiemereich", "thirdreich", "gazlesjuif", "gazlesjuifs", "gazage", "chambreagaz",
    "gaschamber", "whitepower", "whitepride", "wpww", "fourteenwords", "bloodandsoil",
    "suprematie", "supremacist", "daech", "alqaeda", "terroriste", "niglet", "negroid", "groid",
    "sheboon", "monkeyman", "junglebunny", "spearchucker", "subhuman", "untermensch", "muzzrat",
    "pikey", "gypo", "diddicoy", "honky", "wigger", "abeed", "zanj", "dothead", "currymuncher",
    "tacohead", "borderhopper", "halfcaste", "octoroon", "quadroon", "highyellow", "christkiller",
    "wetbacks",
    -- ── Auto-mutilation / violence ───────────────────────────────────────────
    -- creve en ExactOnly (sinon "crevette" en sous-chaîne sur les noms).
    "suicide", "suicidetoi", "killyourself", "kysrope", "petetoi", "creve", "crevetoi",
    "mangetamerde", "tamerelapute", "neckrope", "killurself", "endyourself",
}

-- Usurpation staff / système : UNIQUEMENT pour les noms (pseudo, clan, katana…).
-- Ne doit PAS censurer le chat ("demande au staff", "le serveur lag", "admin?").
EVO_WordFilter.NameOnly = {
    "admin", "administrateur", "administrator", "moderateur", "moderator", "moderation", "staff",
    "fondateur", "fondatrice", "founder", "owner", "proprietaire", "console", "systeme", "system",
    "officiel", "officielle", "official", "serveur", "rootuser", "superadmin", "gamemaster",
    -- Refuse comme NOM seulement (user 08/29). 4 lettres -> match EXACT : le nom
    -- « Joue » est refuse, mais « Joueur », « Joyeuse » ou un « joue » dans le
    -- chat ne sont pas touches (NameOnly n'est jamais consulte par le chat).
    "joue",
}

-- Stems ≥5 lettres trop ambigus pour un match sous-chaîne sur les noms.
-- Match exact uniquement (le chat est déjà en exact-token via Censor).
EVO_WordFilter.ExactOnly = {
    attarde = true,   -- sinon "attarder"
    attardee = true,
    retarde = true,   -- "retardé" normalisé (pas "retard" = en retard)
    retardee = true,
    creve = true,     -- sinon "crevette"
    mongol = true,    -- sinon "mongolie"
}

-- Normalisation : minuscules + leetspeak (0->o @->a 1->i 3->e 4->a 5->s 7->t $->s) +
-- retrait de TOUT caractère non-lettre -> attrape "n1 gg3r", "f.u.c.k", accents, etc.
-- Accents -> lettre de base. AVANT : `gsub("[^a-z]", "")` les SUPPRIMAIT purement et
-- simplement, ce qui deforme les noms RP ("Léonne" -> "lonne", "Valdés" -> "valds",
-- "Jisaï Kanryū" -> "jisakanry") : on comparait donc des mots tronques a la liste, avec
-- autant de risques de faux positif que de contournement (ecrire un terme interdit avec
-- un accent au milieu passait au travers). Table en UTF-8, comme les noms saisis en jeu.
local ACCENTS = {
    ["à"]="a",["á"]="a",["â"]="a",["ä"]="a",["ã"]="a",["å"]="a",["ā"]="a",
    ["è"]="e",["é"]="e",["ê"]="e",["ë"]="e",["ē"]="e",
    ["ì"]="i",["í"]="i",["î"]="i",["ï"]="i",["ī"]="i",
    ["ò"]="o",["ó"]="o",["ô"]="o",["ö"]="o",["õ"]="o",["ø"]="o",["ō"]="o",
    ["ù"]="u",["ú"]="u",["û"]="u",["ü"]="u",["ū"]="u",
    ["ç"]="c",["ñ"]="n",["ý"]="y",["ÿ"]="y",
}

function EVO_WordFilter.Normalize(s)
    s = string.lower(tostring(s or ""))
    s = s:gsub("0", "o"):gsub("@", "a"):gsub("1", "i"):gsub("3", "e"):gsub("4", "a")
         :gsub("5", "s"):gsub("7", "t"):gsub("%$", "s")
    -- [\128-\191]* : on avale les octets de continuation UTF-8, sinon une lettre accentuee
    -- non listee laisserait un demi-caractere derriere elle.
    s = s:gsub("[\194-\244][\128-\191]*", function(c) return ACCENTS[c] or c end)
    return (s:gsub("[^a-z]", ""))
end

-- true si le texte normalisé matche `bad` selon les règles noms (sous-chaîne / exact).
local function nameMatches(norm, bad)
    if #bad <= 4 or EVO_WordFilter.ExactOnly[bad] then
        return norm == bad
    end
    return string.find(norm, bad, 1, true) ~= nil
end

local function listContains(norm, list, useNameRules)
    for _, bad in ipairs(list) do
        if useNameRules then
            if nameMatches(norm, bad) then return true end
        elseif norm == bad then
            return true
        end
    end
    return false
end

-- true si `text` contient un mot interdit. Pour les NOMS (katana, pseudo…) où on
-- REFUSE le texte entier. Inclut NameOnly (usurpation staff).
function EVO_WordFilter.Contains(text)
    local norm = EVO_WordFilter.Normalize(text)
    if norm == "" then return false end
    if listContains(norm, EVO_WordFilter.Words, true) then return true end
    if listContains(norm, EVO_WordFilter.NameOnly, true) then return true end
    return false
end

-- true si le token (mot isolé) est interdit pour le CHAT. Exact après normalisation —
-- pas de sous-chaîne, pas de NameOnly.
function EVO_WordFilter.IsBadToken(word)
    local norm = EVO_WordFilter.Normalize(word)
    if norm == "" then return false end
    return listContains(norm, EVO_WordFilter.Words, false)
end

-- Remplace chaque MOT interdit (séparé par des espaces) par des '*' de même longueur.
-- À utiliser pour le CHAT (on garde le reste du message). Exact-token : "fils de pute"
-- -> "fils de ****", mais "analyser" / "dispute" / "violon" passent.
function EVO_WordFilter.Censor(text)
    if not isstring(text) or text == "" then return text end
    return (string.gsub(text, "%S+", function(word)
        if EVO_WordFilter.IsBadToken(word) then
            return string.rep("*", math.max(3, #word))
        end
    end))
end
