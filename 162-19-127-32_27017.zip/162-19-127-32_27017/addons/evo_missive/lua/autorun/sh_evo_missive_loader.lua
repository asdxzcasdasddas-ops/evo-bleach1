-- "addons\\evo_missive\\lua\\autorun\\sh_evo_missive_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MISSIVE — Bureau des missions. Dans la zone du bureau (config par map),
-- un gradé rédige une MISSIVE (titre, rang, objectif, récompense), la voit en
-- aperçu sur la feuille, puis l'IMPRIME en exemplaires physiques (items
-- dynamiques evo_missive_<id>) à distribuer aux joueurs, qui la lisent via
-- Clic droit > Utiliser. Patterns calqués sur evo_note (items runtime, defs
-- broadcast sans le contenu, texte à la demande gaté par la détention).
-- ============================================================================
EVO_MISSIVE = EVO_MISSIVE or {}

if SERVER then
	AddCSLuaFile("evo_missive/sh_config.lua")
	AddCSLuaFile("evo_missive/cl_missive.lua")
	include("evo_missive/sh_config.lua")
	include("evo_missive/sv_missive.lua")
else
	include("evo_missive/sh_config.lua")
	include("evo_missive/cl_missive.lua")
end
