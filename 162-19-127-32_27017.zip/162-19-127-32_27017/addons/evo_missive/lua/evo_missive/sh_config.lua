-- "addons\\evo_missive\\lua\\evo_missive\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MISSIVE — config partagée (zone du bureau, rangs, item dynamique).
-- ============================================================================
EVO_MISSIVE = EVO_MISSIVE or {}
local M = EVO_MISSIVE

-- Mêmes assets papier qu'evo_note (déjà shippés, rien à ajouter au contenu).
M.Model      = "models/evo/props/items/evo_dsddsc57kdezx96gbj/evo_dsddsc57kdezx96gbj.mdl"
M.Icon       = "a8pi8v5e07z97o/iwjnbnd6ira9.png"
M.ModelLift  = 0.15

M.WrittenItemId   = "evo_missive"
M.ItemPrefix      = "evo_missive_" -- legacy item_id (migration boot)

-- Lecture en main (user 08/19 : « comme avec le livre ») : MÊME séquence que la
-- carte / gestion faction, la feuille attachée à la main gauche. Offsets repris
-- de la carte en main (modèle plat aussi) ; à affiner ici si besoin.
M.ReadNW   = "EVO::IsReadingMissive"
M.ReadAnim = "evo_hwndw1d2gtqzzdvkf"
M.ReadBone = "ValveBiped.Bip01_L_Hand"
M.ReadPos  = Vector(-3.3, -1.6, -1.3)
M.ReadAng  = Angle(-65.7, 180.0, -5.5)
M.MaxTitleLen     = 48
M.MaxObjectiveLen = 700
M.MaxRewardLen    = 120
M.MinRank         = 3    -- grade de faction requis pour ouvrir le bureau (superadmin exempté)
M.PrintMax        = 5    -- exemplaires max par impression
M.CreateCooldown  = 3
M.PurgeDays       = 60   -- purge BDD des missives plus vieilles que N jours (boot)
M.MaxPerAuthor    = 24   -- missives vivantes max par auteur (anti-spam registre)

-- Rangs de mission, du plus simple au plus dangereux. La rareté teinte la case
-- d'inventaire de l'exemplaire imprimé (tooltip), la couleur sert aux chips UI
-- et au tampon de la feuille.
M.RankOrder = { "D", "C", "B", "A", "S" }
-- xp = % du niveau versé au participant validé (même formule que les quêtes), gratuit.
M.RankData = {
	D = { col = Color(150, 152, 158), rarity = "common",    xp = 3 },
	C = { col = Color(96, 220, 130),  rarity = "common",    xp = 6 },
	B = { col = Color(90, 170, 255),  rarity = "rare",      xp = 10 },
	A = { col = Color(178, 103, 255), rarity = "epic",      xp = 15 },
	S = { col = Color(255, 174, 66),  rarity = "legendary", xp = 25 },
}

-- ── MISSIONS AU TABLEAU DES QUÊTES (09/29, user) ────────────────────────────
-- Prises par PLUSIEURS joueurs (places), validées par N'IMPORTE QUEL officier du
-- bureau, payées par la TRÉSORERIE de la faction (¥ + coffre, evo_division_bank).
M.DefaultPlaces  = 3
M.MaxPlaces      = 10
M.MaxYen         = 100000
M.MaxActiveTakes = 3   -- missions en cours à la fois par personnage
M.BoardTakeDist  = 400 -- distance max au tableau des quêtes pour accepter
M.ChestOrder = { "", "common", "rare", "epic" } -- clés d'EVO_DIVBANK.Config.ChestCost / ChestItem
M.ChestLabel = { [""] = "Aucun", common = "Commun", rare = "Rare", epic = "Épique" }

function M.FormatYen(n)
	return string.Comma(math.floor(tonumber(n) or 0)):gsub(",", " ") .. " ¥"
end

-- Texte de récompense (feuille, bureau, tableau) : ¥ · coffre · XP du rang · note libre.
function M.RewardText(yen, chest, rk, note)
	local t = {}
	if (tonumber(yen) or 0) > 0 then t[#t + 1] = M.FormatYen(yen) end
	if chest and chest ~= "" and M.ChestLabel[chest] then t[#t + 1] = "coffre " .. string.lower(M.ChestLabel[chest]) end
	local rd = M.RankData[rk]
	if rd and rd.xp then t[#t + 1] = rd.xp .. " % d'XP" end
	local s = table.concat(t, " · ")
	note = string.Trim(note or "")
	if note ~= "" then s = (s ~= "" and (s .. " · ") or "") .. note end
	return s
end

-- ── ZONES DU BUREAU (une par map). gm_construct = position de TEST en
-- attendant les vraies coordonnées (user 08/19 : « zone que je te donnerai
-- plus tard »). En jeu : evo_missive_zone_pos (superadmin) imprime la ligne
-- prête à coller ici.
M.Zones = {
	["gm_construct"]   = { pos = Vector(0, 0, -79), radius = 140 }, -- zone de TEST
	-- Poses relevées par le user (08/24) : le bureau physique (M.Decor) EST le
	-- centre de la zone, mêmes coordonnées des deux côtés.
	["hueco_mundo_v1"]  = { pos = Vector(-11747.81, -1713.97, 6472.72), radius = 140 },
	["rp_seireitei_v1"] = { pos = Vector(-4715.17, -1271.58, 14498.72), radius = 140 },
}

-- ── DÉCOR : le bureau physique posé au centre de la zone (user 08/24). Le
-- « models/models/ » est VOULU, chemin réel du pack watcherprops (cf evo_craft).
-- Yaw = setang du user, pitch 89 (regard noclip vers le sol) jeté.
-- Copies extra via config_positions Modeles : WorldModelPresets.bureau_missions
-- doit rester identique (même drift assassin StationModels vs presets).
M.DeskModel = "models/models/watcherprops/watcher_konoha_stuff_71.mdl"
M.Decor = {
	["hueco_mundo_v1"]  = { { pos = Vector(-11747.81, -1713.97, 6472.72), yaw = -0.93 } },
	["rp_seireitei_v1"] = { { pos = Vector(-4715.17, -1271.58, 14498.72), yaw = 88.49 } },
}

function M.ZoneFor(sMap)
	return M.Zones[sMap or game.GetMap()]
end

-- Ancrage AU SOL, partagé client/serveur : MÊME recette que les Archives
-- (EVO_LIVRE.StationAnchor). Les poses viennent du getpos (hauteur des yeux,
-- voire noclip) : le rendu ET la détection utilisent le z ANCRÉ, sinon la zone
-- s'affiche au sol mais la touche E refuse (bug documenté des Archives).
local tAnchor = {}
function M.InvalidateAnchor()
	tAnchor = {}
end
function M.ZoneAnchor(z)
	local a = tAnchor[z]
	if a then return a end
	local tr = util.TraceLine({
		start = z.pos + Vector(0, 0, 30),
		endpos = z.pos - Vector(0, 0, 1000),
		mask = MASK_SOLID_BRUSHONLY,
	})
	a = tr.Hit and tr.HitPos or z.pos
	tAnchor[z] = a
	return a
end

-- Le joueur est-il dans la zone du bureau ? Cylindre contre le z ancré
-- (recette Archives), partagé : marqueur client + gates serveur.
function M.InZone(ply)
	local z = M.ZoneFor(game.GetMap())
	if not z or not IsValid(ply) then return false end
	local a = M.ZoneAnchor(z)
	local p = ply:GetPos()
	local r = (z.radius or 140) + 40
	local dx, dy = p.x - a.x, p.y - a.y
	return dx * dx + dy * dy <= r * r and math.abs(p.z - a.z) <= 160
end

-- Le bureau appartient à la Division 1 / l'Ordre 1 (user 08/19) : seuls leurs
-- membres de grade 3+ le voient et le tiennent. Résolution par NOM via
-- LZY_FACTION_CONFIG (règle projet : robuste au ré-ordonnancement des divisions).
M.DeskDivisions = { Shinigami = "Division 1", Hollow = "Ordre 1" }

function M.DeskDivisionName(ply)
	local sFaction = IsValid(ply) and ply:GetEvoNWString("FactionName", "") or ""
	return M.DeskDivisions[sFaction] or "Division 1"
end

function M.CanUseDesk(ply)
	if not (IsValid(ply) and ply.IsPlayer and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	if (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) < (M.MinRank or 3) then return false end
	local sFaction = ply:GetEvoNWString("FactionName", "")
	local sReq = M.DeskDivisions[sFaction]
	if not sReq then return false end
	local divs = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions and LZY_FACTION_CONFIG.divisions[sFaction]
	if not divs then return false end
	return divs[ply:GetEvoNWInt("FactionDivision", 0)] == sReq
end

function M.MissiveItemId(id) return M.ItemPrefix .. id end

local function missiveDoc(key)
	local d
	if CLIENT then
		d = M.Defs and M.Defs[key]
	else
		d = M.Docs and M.Docs[key]
	end
	if not d then return nil end
	return {
		id = d.id or key,
		ti = d.ti or d.title or "",
		rk = d.rk or d.rank or "D",
		au = d.au or d.ownerName or "?",
	}
end

function M.RegisterWrittenItem()
	if not istable(ITEMS) then return false end
	ITEMS[M.WrittenItemId] = {
		name         = "Missive",
		description  = "Ordre de mission. Clic droit > Utiliser pour consulter la missive.",
		category     = "object",
		rarity       = "common",
		icon         = M.Icon,
		model_path   = M.Model,
		model_lift   = M.ModelLift,
		is_droppable = true,
		is_deletable = true,
		bDocumentItem = true, -- document RP : un perso animation peut le jeter (gate inventory net.lua)
		requires_instance_key = true,
		evo_missive  = true,
		instance_name = function(key)
			local d = missiveDoc(key)
			local rk = d and M.RankData[d.rk] and d.rk or "D"
			local ti = d and d.ti or ""
			return "Missive " .. rk .. " : " .. (ti ~= "" and ti or "sans titre")
		end,
		instance_description = function(key)
			local d = missiveDoc(key)
			local rk = d and M.RankData[d.rk] and d.rk or "D"
			return "Ordre de mission de rang " .. rk .. ", émis par " .. ((d and d.au) or "?")
				.. ".\nClic droit > Utiliser pour consulter la missive."
		end,
		instance_rarity = function(key)
			local d = missiveDoc(key)
			local rk = d and M.RankData[d.rk] and d.rk or "D"
			return M.RankData[rk].rarity
		end,
		on_use = CLIENT and function(_, slot)
			local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
			local key = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
			if key and M.OpenRead then M.OpenRead(key) end
		end or function() end,
	}
	return true
end

-- Compat : ancien enregistrement par document — pose le def et le type canonique.
function M.RegisterMissiveItem(d)
	if istable(d) and d.id then
		M.Defs = M.Defs or {}
		if CLIENT then M.Defs[d.id] = d end
		if SERVER then
			M.Docs = M.Docs or {}
		end
	end
	return M.RegisterWrittenItem()
end
