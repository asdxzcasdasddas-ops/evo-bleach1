-- "addons\\evo_missive\\lua\\evo_missive\\cl_missive.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MISSIVE — client. Marqueur de la zone du bureau + touche E, BUREAU plein
-- écran (registre, rédaction, aperçu EN DIRECT de la feuille), rendu de la
-- FEUILLE de mission (papier, tampon de rang incliné, sceau) et lecteur des
-- exemplaires imprimés (Clic droit > Utiliser). Look « DHTML » DA : VGUI +
-- RNDX purs, cartes sombres sans bordure, accent #cf444e, jamais de Chromium.
-- ============================================================================
local M = EVO_MISSIVE

M.Defs = M.Defs or {} -- missiveId -> { id, title, rank, ownerName, createdAt }

-- ── Palette bureau (DA clean base) + palette papier ─────────────────────────
local COL_CARD   = Color(13, 14, 17, 250)
local COL_SUB    = Color(20, 20, 24, 255)
local COL_SUB_HI = Color(27, 27, 33, 255)
local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)
local COL_WASH   = Color(207, 68, 78, 26)
local COL_FIELD  = Color(8, 8, 10, 230)
local COL_GOLD   = Color(216, 185, 106)
local COL_SHADOW = Color(0, 0, 0, 160)

local PAPER      = Color(237, 231, 218)
local PAPER_DARK = Color(226, 219, 203)
local INK        = Color(44, 39, 34)
local INK_SOFT   = Color(74, 66, 57)
local INK_DIM    = Color(122, 111, 97)
local INK_LINE   = Color(44, 39, 34, 70)
local STAMP      = Color(172, 44, 52, 235)
local STAMP_SOFT = Color(172, 44, 52, 60)
local REWARD_INK = Color(122, 34, 40)

local function R(v)
	if gRespY then return gRespY(v) end
	return math.floor(v * (ScrH() / 1080))
end
local function RX(v)
	if gRespX then return gRespX(v) end
	return math.floor(v * (ScrW() / 1920))
end

-- ── Fontes papier (Georgia, comme les livres des Archives) ──────────────────
local function fs(n)
	if gRespFont then return gRespFont(n) end
	return math.floor(n * (ScrH() / 1080))
end
local function MakeFonts()
	surface.CreateFont("EVOMsv_Serif",  { font = "Georgia", size = fs(19), weight = 400, antialias = true })
	surface.CreateFont("EVOMsv_SerifB", { font = "Georgia", size = fs(21), weight = 700, antialias = true })
	surface.CreateFont("EVOMsv_SerifT", { font = "Georgia", size = fs(31), weight = 700, antialias = true })
	surface.CreateFont("EVOMsv_SerifI", { font = "Georgia", size = fs(16), weight = 400, italic = true, antialias = true })
	surface.CreateFont("EVOMsv_Small",  { font = "Georgia", size = fs(14), weight = 400, antialias = true })
end
MakeFonts()
-- evo_missive se charge AVANT glibs (ordre alphabétique des addons) : les
-- tailles gRespFont ne sont dispo qu'après -> on re-crée à Initialize.
hook.Add("Initialize", "EVO_Missive::FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Missive::Fonts", MakeFonts)

-- ── Petits helpers UI (pattern evo_note) ────────────────────────────────────
local function plate(x, y, w, h, col, rad)
	if RNDX and RNDX.Draw then RNDX.Draw(rad or R(12), x, y, w, h, col)
	else draw.RoundedBox(8, x, y, w, h, col) end
end
local function click()
	if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
end
local function mkBtn(parent, label, fill, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetCursor("hand")
	b._lbl = label
	b.Paint = function(s, w, h)
		local hov = s:IsHovered()
		if fill then plate(0, 0, w, h, ColorAlpha(COL_ACCENT, hov and 255 or 220), R(8))
		else plate(0, 0, w, h, Color(255, 255, 255, hov and 22 or 10), R(8)) end
		draw.SimpleText(s._lbl, "Bebas Neue:26", w / 2, h / 2,
			fill and color_white or (hov and COL_TITLE or COL_MUTED), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function() click() fn() end
	return b
end
local function mkClose(parent, x, y, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetSize(R(34), R(34)) b:SetPos(x, y) b:SetCursor("hand")
	b.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fn
	return b
end
local function mkEntry(parent, sPlaceholder, nMax, bMulti)
	local e = vgui.Create("DTextEntry", parent)
	e:SetFont("Avenir Next World:20") e:SetDrawLanguageID(false)
	e:SetTextColor(COL_TITLE) e:SetCursorColor(COL_TITLE) e:SetPaintBackground(false)
	e:SetUpdateOnType(true)
	if bMulti then e:SetMultiline(true) end
	e.Paint = function(s, w, h)
		plate(0, 0, w, h, COL_FIELD, R(7))
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText(sPlaceholder, "Avenir Next World:20", R(10), bMulti and R(8) or h / 2,
				COL_DIM, TEXT_ALIGN_LEFT, bMulti and TEXT_ALIGN_TOP or TEXT_ALIGN_CENTER)
		end
	end
	e.OnValueChange = function(s, v)
		if #v > nMax then s:SetText(string.sub(v, 1, nMax)) s:SetCaretPos(nMax) end
	end
	return e
end
local function notifyLocal(msg, err)
	if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(msg, err and NOTIFY_ERROR or NOTIFY_GENERIC, 4)
	else chat.AddText(COL_ACCENT, "[Missive] ", color_white, msg) end
end

-- Backdrop plein écran (flou RNDX + voile). bClickClose = clic hors carte ferme.
local function makeBackdrop(bClickClose)
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
	frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false) frame:MakePopup()
	openedFrame = frame
	frame.OnRemove = function(s) if openedFrame == s then openedFrame = nil end end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end -- APRÈS MakePopup
	frame.Paint = function(_, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR) end
		surface.SetDrawColor(5, 5, 7, 215) surface.DrawRect(0, 0, w, h)
	end
	if bClickClose then frame.OnMousePressed = function(s) s:Remove() end end
	return frame
end

-- ── Dessin sous rotation locale (tampon incliné du papier) ──────────────────
local function withRotation(cx, cy, deg, fn)
	local m = Matrix()
	m:Translate(Vector(cx, cy, 0))
	m:Rotate(Angle(0, deg, 0))
	m:Translate(Vector(-cx, -cy, 0))
	cam.PushModelMatrix(m, true)
	local ok, err = pcall(fn)
	cam.PopModelMatrix()
	if not ok then ErrorNoHalt("[evo_missive] " .. tostring(err) .. "\n") end
end

-- Répartition de texte en lignes (glibs), avec repli mono-ligne.
local function wrapLines(sText, sFont, nWide, nMaxLines)
	if splitText then return splitText(sText or "", sFont, nWide, nMaxLines) end
	return { sText or "" }
end

-- ============================================================================
-- LA FEUILLE : rendu pur dans le panel courant (0,0,w,h). d = { ti, rk, ob,
-- rw, au, fa, at }. Sert à l'aperçu du bureau ET au lecteur (WYSIWYG).
-- ============================================================================
local function DrawSheet(w, h, d)
	d = d or {}
	local rk = M.RankData[d.rk] and d.rk or "D"
	local pad = math.floor(w * 0.09)
	local inner = w - pad * 2

	-- Papier : fond, marge sombre subtile, filet de bord.
	plate(0, 0, w, h, PAPER, R(4))
	surface.SetDrawColor(PAPER_DARK)
	surface.DrawRect(0, h - R(5), w, R(5))
	surface.SetDrawColor(INK_LINE)
	surface.DrawOutlinedRect(math.floor(pad * 0.42), math.floor(pad * 0.42),
		w - math.floor(pad * 0.84), h - math.floor(pad * 0.84), 1)

	-- En-tête.
	local sFa = (d.fa and d.fa ~= "") and string.upper(d.fa) or "SEIREITEI"
	draw.SimpleText("BUREAU DES MISSIONS · " .. sFa, "Bebas Neue:20", w / 2, math.floor(h * 0.055),
		INK_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("ORDRE DE MISSION", "Bebas Neue:52", w / 2, math.floor(h * 0.098),
		INK, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	local yRule = math.floor(h * 0.138)
	surface.SetDrawColor(INK)
	surface.DrawRect(pad, yRule, inner, R(2))
	surface.DrawRect(pad, yRule + R(5), inner, 1)


	-- Titre (2 lignes max).
	local sTitle = (d.ti and string.Trim(d.ti) ~= "") and d.ti or "Sans titre"
	local tLines = wrapLines(sTitle, "EVOMsv_SerifT", inner, 2)
	local y = math.floor(h * 0.168)
	surface.SetFont("EVOMsv_SerifT")
	local _, thT = surface.GetTextSize("Ag")
	for i = 1, math.min(#tLines, 2) do
		draw.SimpleText(tLines[i], "EVOMsv_SerifT", w / 2, y, INK, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		y = y + thT
	end

	-- OBJECTIF.
	y = math.max(y + math.floor(h * 0.022), math.floor(h * 0.245))
	draw.SimpleText("OBJECTIF", "Bebas Neue:22", pad, y, INK_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	surface.SetDrawColor(STAMP)
	surface.DrawRect(pad, y + R(24), R(46), R(2))
	y = y + math.floor(h * 0.045)
	surface.SetFont("EVOMsv_Serif")
	local _, thB = surface.GetTextSize("Ag")
	local yRewardTop = math.floor(h * 0.665)
	local nMaxLines = math.max(1, math.floor((yRewardTop - y - R(8)) / thB))
	local sOb = (d.ob and string.Trim(d.ob) ~= "") and d.ob or "Se présenter au bureau des missions pour recevoir les consignes."
	local oLines = wrapLines(sOb, "EVOMsv_Serif", inner, nMaxLines + 1)
	for i = 1, math.min(#oLines, nMaxLines) do
		local sLine = oLines[i]
		if i == nMaxLines and #oLines > nMaxLines then sLine = sLine .. " …" end
		draw.SimpleText(sLine, "EVOMsv_Serif", pad, y, INK_SOFT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		y = y + thB
	end

	-- Filet pointillé puis encart RÉCOMPENSE.
	surface.SetDrawColor(INK_LINE)
	local dx = pad
	while dx < pad + inner do
		surface.DrawRect(dx, yRewardTop - R(10), R(6), 1)
		dx = dx + R(11)
	end
	local rbH = math.floor(h * 0.115)
	surface.SetDrawColor(Color(255, 252, 244, 130))
	surface.DrawRect(pad, yRewardTop, inner, rbH)
	surface.SetDrawColor(INK_LINE)
	surface.DrawOutlinedRect(pad, yRewardTop, inner, rbH, 1)
	draw.SimpleText("RÉCOMPENSE", "Bebas Neue:20", pad + R(12), yRewardTop + R(10), INK_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	local sRw = (d.rw and string.Trim(d.rw) ~= "") and d.rw or "À convenir avec l'émetteur."
	local rLines = wrapLines(sRw, "EVOMsv_SerifB", inner - R(24), 2)
	local ry = yRewardTop + R(34)
	surface.SetFont("EVOMsv_SerifB")
	local _, thR = surface.GetTextSize("Ag")
	for i = 1, math.min(#rLines, 2) do
		draw.SimpleText(rLines[i], "EVOMsv_SerifB", pad + R(12), ry, REWARD_INK, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		ry = ry + thR
	end

	-- Pied : date + signature à gauche, tampon de rang à droite.
	local yFoot = math.floor(h * 0.845)
	draw.SimpleText("Fait le " .. os.date("%d/%m/%Y", d.at or os.time()), "EVOMsv_Small",
		pad, yFoot, INK_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("Par " .. ((d.au and d.au ~= "") and d.au or "?") .. ((d.fa and d.fa ~= "") and (" · " .. d.fa) or ""),
		"EVOMsv_SerifI", pad, yFoot + R(20), INK_SOFT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	-- Tampon de rang à l'encre rouge, incliné, calé DANS les marges du pied
	-- (l'en-tête reste net, plus de kanji : retours user 08/19).
	local sr = math.floor(w * 0.07)
	local scx = w - pad - sr - R(2)
	local scy = math.floor(h * 0.878)
	withRotation(scx, scy, -10, function()
		if RNDX and RNDX.DrawCircleOutlined then
			RNDX.DrawCircleOutlined(scx, scy, sr, STAMP, R(3))
			RNDX.DrawCircleOutlined(scx, scy, sr - R(5), ColorAlpha(STAMP, 160), R(1))
		end
		draw.SimpleText("RANG", "Bebas Neue:14", scx, scy - sr * 0.5, STAMP, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(rk, "Bebas Neue:48", scx, scy + sr * 0.06, STAMP, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("MISSION", "Bebas Neue:12", scx, scy + sr * 0.56, ColorAlpha(STAMP, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)
	draw.SimpleText("Missive officielle du bureau. Toute falsification sera sanctionnée.",
		"EVOMsv_Small", w / 2, math.floor(h * 0.955), ColorAlpha(INK_DIM, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

-- ============================================================================
-- LECTEUR : Utiliser un exemplaire -> demande le texte -> feuille plein cadre.
-- ============================================================================
local function OpenViewer(d)
	if IsValid(M._viewUI) then M._viewUI:Remove() end
	local frame = makeBackdrop(true)
	M._viewUI = frame

	-- Feuille EN MAIN pendant la lecture (pose forcée par le serveur, clé
	-- M.ReadNW). Stop chaîné dans OnRemove : couvre Échap, croix et clic dehors.
	net.Start("EVO:Missive:ReadStart")
	net.SendToServer()
	local fOldRemove = frame.OnRemove
	frame.OnRemove = function(fr)
		if fOldRemove then fOldRemove(fr) end
		net.Start("EVO:Missive:ReadStop")
		net.SendToServer()
	end

	local H = math.floor(ScrH() * 0.86)
	local W = math.floor(H / 1.414)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		if RNDX and RNDX.DrawShadows then RNDX.DrawShadows(R(4), 0, 0, w, h, COL_SHADOW, R(18), 20) end
		DrawSheet(w, h, d)
	end
	mkClose(card, W - R(40), R(8), function() frame:Remove() end)

	local hint = vgui.Create("DLabel", frame)
	hint:SetSize(ScrW(), R(24))
	hint:SetPos(0, card:GetY() + H + R(10))
	hint:SetFont("Avenir Next World:16") hint:SetTextColor(COL_DIM) hint:SetContentAlignment(5)
	hint:SetText("Échap pour reposer la missive")
end

function M.OpenRead(id)
	-- Filet : DefAll différé ou droppé -> re-demande les defs avant lecture.
	if id and not M.Defs[id] then
		net.Start("EVO:Missive:RequestDefs")
		net.SendToServer()
	end
	M._pendingRead = id
	net.Start("EVO:Missive:RequestText") net.WriteString(id) net.SendToServer()
end

net.Receive("EVO:Missive:ForceClose", function()
	if IsValid(M._viewUI) then M._viewUI:Remove() end
end)

net.Receive("EVO:Missive:Text", function()
	local d = {}
	local id = net.ReadString()
	d.ti = net.ReadString()
	d.rk = net.ReadString()
	d.ob = net.ReadString()
	d.rw = net.ReadString()
	d.au = net.ReadString()
	d.fa = net.ReadString()
	d.at = net.ReadUInt(32)
	if M._pendingRead ~= id then return end
	M._pendingRead = nil
	OpenViewer(d)
end)

-- ============================================================================
-- LE BUREAU : registre (gauche), rédaction ou missive choisie (milieu),
-- aperçu EN DIRECT de la feuille (droite).
-- ============================================================================
local DESK = { docs = {}, sel = nil }

local function myName()
	local lp = LocalPlayer()
	local nm = IsValid(lp) and lp:GetEvoNWString("Nickname", "") or ""
	return nm ~= "" and nm or (IsValid(lp) and lp:Nick() or "?")
end
local function myFaction()
	local lp = LocalPlayer()
	return IsValid(lp) and lp:GetEvoNWString("FactionName", "") or ""
end

local function BuildDesk()
	local frame = DESK.frame
	if not IsValid(frame) or not IsValid(frame._content) then return end
	-- On reconstruit un CONTENEUR enfant, jamais frame:Clear() : Clear sur un
	-- DFrame détruit ses boutons internes et son PerformLayout crashe derrière.
	local root = frame._content
	root:Clear()

	local draft = DESK.draft or { ti = "", rk = "C", ob = "", rw = "", yen = "", ch = "", pl = M.DefaultPlaces, tb = false }
	DESK.draft = draft
	local sel = DESK.sel and DESK.docs[DESK.sel] or nil

	mkClose(root, ScrW() - RX(96), R(48), function() frame:Remove() end)

	-- ── Colonne gauche : REGISTRE ────────────────────────────────────────────
	local reg = vgui.Create("DPanel", root)
	reg:SetPos(RX(70), R(150))
	reg:SetSize(RX(430), R(890))
	reg.Paint = function(_, w, h)
		if RNDX and RNDX.DrawShadows then RNDX.DrawShadows(R(16), 0, 0, w, h, COL_SHADOW, R(12), 14) end
		plate(0, 0, w, h, COL_CARD, R(16))
		draw.SimpleText("REGISTRE", "Bebas Neue:32", RX(24), R(34), COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(#DESK.docs .. " missive(s)", "Avenir Next World:16", w - RX(24), R(34),
			COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		if #DESK.docs == 0 then
			draw.SimpleText("Aucune missive au registre.", "Avenir Next World:18", w / 2, R(120),
				COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	local list = vgui.Create("DScrollPanel", reg)
	list:SetPos(RX(14), R(60))
	list:SetSize(RX(402), R(750))
	list.Paint = nil
	local vbar = list:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(R(5)) vbar:SetHideButtons(true)
		vbar.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h) end
	end

	for i, d in ipairs(DESK.docs) do
		local row = list:Add("DButton")
		row:SetText("") row:SetCursor("hand")
		row:Dock(TOP) row:DockMargin(0, 0, RX(8), R(8))
		row:SetTall(R(64))
		local rc = (M.RankData[d.rk] and M.RankData[d.rk].col) or COL_MUTED
		row.Paint = function(s, w, h)
			local bSel = DESK.sel == i
			plate(0, 0, w, h, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB, R(10))
			if bSel then
				plate(0, 0, w, h, COL_WASH, R(10))
				plate(RX(6), R(10), RX(4), h - R(20), COL_ACCENT, R(2))
			end
			plate(RX(18), R(14), R(36), R(36), ColorAlpha(rc, 34), R(8))
			draw.SimpleText(d.rk or "D", "Bebas Neue:30", RX(18) + R(18), h / 2, rc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(d.ti or "?", "Bebas Neue:24", RX(66), R(20),
				bSel and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local nPris = 0
			for _, t in ipairs(d.tk or {}) do if t.st ~= "refus" then nPris = nPris + 1 end end
			local sSub = os.date("%d/%m", d.at or 0) .. (d.mine and "" or (" · " .. (d.au or "?")))
				.. " · " .. nPris .. "/" .. (d.pl or M.DefaultPlaces) .. " participant(s)"
			draw.SimpleText(sSub, "Avenir Next World:15", RX(66), R(44), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			click()
			DESK.sel = (DESK.sel == i) and nil or i
			BuildDesk()
		end
	end

	local newBtn = mkBtn(reg, "NOUVELLE MISSIVE", DESK.sel ~= nil, function()
		DESK.sel = nil
		BuildDesk()
	end)
	newBtn:SetPos(RX(14), R(824))
	newBtn:SetSize(RX(402), R(48))

	-- ── Colonne du milieu : RÉDACTION ou missive choisie ─────────────────────
	local ed = vgui.Create("DPanel", root)
	ed:SetPos(RX(530), R(150))
	ed:SetSize(RX(560), R(890))
	ed.Paint = function(_, w, h)
		if RNDX and RNDX.DrawShadows then RNDX.DrawShadows(R(16), 0, 0, w, h, COL_SHADOW, R(12), 14) end
		plate(0, 0, w, h, COL_CARD, R(16))
		draw.SimpleText(sel and "MISSIVE CHOISIE" or "RÉDACTION", "Bebas Neue:32", RX(24), R(34),
			COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	if not sel then
		-- Mode brouillon : champs + rang + CRÉER.
		local lbl = function(txt, y)
			local l = vgui.Create("DLabel", ed)
			l:SetPos(RX(24), y) l:SetSize(RX(500), R(20))
			l:SetFont("Bebas Neue:22") l:SetTextColor(COL_DIM) l:SetText(txt)
		end
		lbl("TITRE DE LA MISSION", R(66))
		local titleE = mkEntry(ed, "Escorte du convoi vers le Rukongai…", M.MaxTitleLen)
		titleE:SetPos(RX(24), R(92)) titleE:SetSize(RX(512), R(44))
		titleE:SetText(draft.ti)
		local oldT = titleE.OnValueChange
		titleE.OnValueChange = function(s, v) oldT(s, v) draft.ti = s:GetText() end

		lbl("RANG", R(150))
		local chipW = (RX(512) - R(8) * 4) / 5
		for k, rkKey in ipairs(M.RankOrder) do
			local chip = vgui.Create("DButton", ed)
			chip:SetText("") chip:SetCursor("hand")
			chip:SetPos(RX(24) + (k - 1) * (chipW + R(8)), R(176))
			chip:SetSize(chipW, R(46))
			local rc = M.RankData[rkKey].col
			chip.Paint = function(s, w, h)
				local bOn = draft.rk == rkKey
				plate(0, 0, w, h, (bOn or s:IsHovered()) and COL_SUB_HI or COL_SUB, R(8))
				if bOn then
					plate(0, 0, w, h, ColorAlpha(rc, 26), R(8))
					if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(R(8), 0, 0, w, h, rc, R(2)) end
				end
				draw.SimpleText(rkKey, "Bebas Neue:30", w / 2, h / 2, bOn and rc or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			chip.DoClick = function() click() draft.rk = rkKey end
		end

		lbl("OBJECTIF", R(238))
		local obE = mkEntry(ed, "Décris la mission : contexte, cible, consignes…", M.MaxObjectiveLen, true)
		obE:SetPos(RX(24), R(264)) obE:SetSize(RX(512), R(250))
		obE:SetText(draft.ob)
		local counter = vgui.Create("DLabel", ed)
		counter:SetPos(RX(24), R(518)) counter:SetSize(RX(512), R(18))
		counter:SetFont("Avenir Next World:15") counter:SetTextColor(COL_DIM) counter:SetContentAlignment(6)
		counter:SetText(#draft.ob .. "/" .. M.MaxObjectiveLen)
		local oldO = obE.OnValueChange
		obE.OnValueChange = function(s, v)
			oldO(s, v)
			draft.ob = s:GetText()
			counter:SetText(#draft.ob .. "/" .. M.MaxObjectiveLen)
		end

		-- Récompense PAYÉE PAR LA TRÉSORERIE à la validation (09/29) ; l'XP suit le rang.
		lbl("¥ PAR PARTICIPANT (TRÉSORERIE)", R(544))
		local yenE = mkEntry(ed, "0", 7)
		yenE:SetPos(RX(24), R(570)) yenE:SetSize(RX(300), R(44))
		yenE:SetNumeric(true)
		yenE:SetText(draft.yen or "")
		local oldY = yenE.OnValueChange
		yenE.OnValueChange = function(s, v) oldY(s, v) draft.yen = s:GetText() end

		local lPl = vgui.Create("DLabel", ed)
		lPl:SetPos(RX(340), R(544)) lPl:SetSize(RX(196), R(20))
		lPl:SetFont("Bebas Neue:22") lPl:SetTextColor(COL_DIM) lPl:SetText("PLACES")
		draft.pl = math.Clamp(tonumber(draft.pl) or M.DefaultPlaces, 1, M.MaxPlaces)
		local plLbl
		local plMinus = mkBtn(ed, "-", false, function()
			draft.pl = math.max(1, draft.pl - 1) plLbl:SetText(draft.pl)
		end)
		plMinus:SetPos(RX(340), R(570)) plMinus:SetSize(R(44), R(44))
		plLbl = vgui.Create("DLabel", ed)
		plLbl:SetPos(RX(340) + R(48), R(570)) plLbl:SetSize(RX(196) - R(96), R(44))
		plLbl:SetFont("Bebas Neue:34") plLbl:SetTextColor(COL_TITLE) plLbl:SetContentAlignment(5)
		plLbl:SetText(draft.pl)
		local plPlus = mkBtn(ed, "+", false, function()
			draft.pl = math.min(M.MaxPlaces, draft.pl + 1) plLbl:SetText(draft.pl)
		end)
		plPlus:SetPos(RX(536) - R(44), R(570)) plPlus:SetSize(R(44), R(44))

		lbl("COFFRE PAR PARTICIPANT (TRÉSORERIE)", R(626))
		local nCh = #M.ChestOrder
		local chW = (RX(512) - R(8) * (nCh - 1)) / nCh
		for k, sTier in ipairs(M.ChestOrder) do
			local chip = vgui.Create("DButton", ed)
			chip:SetText("") chip:SetCursor("hand")
			chip:SetPos(RX(24) + (k - 1) * (chW + R(8)), R(652))
			chip:SetSize(chW, R(40))
			chip.Paint = function(s, w, h)
				local bOn = (draft.ch or "") == sTier
				plate(0, 0, w, h, (bOn or s:IsHovered()) and COL_SUB_HI or COL_SUB, R(8))
				if bOn then plate(0, 0, w, h, COL_WASH, R(8)) end
				draw.SimpleText(M.ChestLabel[sTier], "Bebas Neue:24", w / 2, h / 2, bOn and COL_TITLE or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			chip.DoClick = function() click() draft.ch = sTier end
		end

		lbl("NOTE DE RÉCOMPENSE (FACULTATIVE)", R(704))
		local rwE = mkEntry(ed, "Une lettre de recommandation…", M.MaxRewardLen)
		rwE:SetPos(RX(24), R(730)) rwE:SetSize(RX(512), R(44))
		rwE:SetText(draft.rw)
		local oldR = rwE.OnValueChange
		rwE.OnValueChange = function(s, v) oldR(s, v) draft.rw = s:GetText() end

		-- Coche (09/30, user) : sans elle la mission reste au registre, hors tableau des quêtes.
		local tb = vgui.Create("DButton", ed)
		tb:SetText("") tb:SetCursor("hand")
		tb:SetPos(RX(24), R(782)) tb:SetSize(RX(512), R(28))
		tb.Paint = function(s, w, h)
			local c = R(22)
			plate(0, (h - c) / 2, c, c, s:IsHovered() and COL_SUB_HI or COL_SUB, R(5))
			if draft.tb then plate(R(5), (h - c) / 2 + R(5), c - R(10), c - R(10), COL_TITLE, R(3)) end
			draw.SimpleText("Afficher au tableau des quêtes", "Avenir Next World:17", c + R(10), h / 2,
				draft.tb and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		tb.DoClick = function() click() draft.tb = not draft.tb end

		local create = mkBtn(ed, "ENREGISTRER LA MISSIVE AU REGISTRE", true, function()
			if string.Trim(draft.ti) == "" then notifyLocal("Donne un titre à la mission.", true) return end
			if string.Trim(draft.ob) == "" then notifyLocal("Décris l'objectif de la mission.", true) return end
			net.Start("EVO:Missive:Create")
				net.WriteString(draft.ti)
				net.WriteString(draft.rk)
				net.WriteString(draft.ob)
				net.WriteString(draft.rw)
				net.WriteUInt(math.Clamp(math.floor(tonumber(draft.yen) or 0), 0, M.MaxYen), 32)
				net.WriteString(draft.ch or "")
				net.WriteUInt(math.Clamp(draft.pl or M.DefaultPlaces, 1, M.MaxPlaces), 8)
				net.WriteBool(draft.tb == true)
			net.SendToServer()
			DESK.draft = { ti = "", rk = draft.rk, ob = "", rw = "", yen = draft.yen, ch = draft.ch, pl = draft.pl, tb = draft.tb }
		end)
		create:SetPos(RX(24), R(816))
		create:SetSize(RX(512), R(52))
	else
		-- Mode missive choisie : résumé + impression + retrait.
		local rc = (M.RankData[sel.rk] and M.RankData[sel.rk].col) or COL_MUTED
		local info = vgui.Create("DPanel", ed)
		info:SetPos(RX(24), R(66)) info:SetSize(RX(512), R(150))
		info.Paint = function(_, w, h)
			plate(0, 0, w, h, COL_SUB, R(10))
			plate(RX(14), R(14), R(44), R(44), ColorAlpha(rc, 34), R(8))
			draw.SimpleText(sel.rk or "D", "Bebas Neue:36", RX(14) + R(22), R(36), rc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(sel.ti or "?", "Bebas Neue:28", RX(72), R(28), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("Par " .. (sel.au or "?") .. " · " .. os.date("%d/%m/%Y", sel.at or 0)
				.. (sel.tb == false and " · hors tableau des quêtes" or " · au tableau des quêtes"),
				"Avenir Next World:16", RX(72), R(52), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local sRwSel = M.RewardText(sel.yen, sel.ch, sel.rk, sel.rw)
			draw.SimpleText("Récompense : " .. (sRwSel ~= "" and sRwSel or "à convenir"),
				"Avenir Next World:17", RX(14), R(96), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("La feuille de droite est l'exemplaire tel qu'il sera imprimé.",
				"Avenir Next World:15", RX(14), R(122), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		-- Impression / duplication / retrait : réservés à l'auteur (le serveur revalide).
		local bAuteur = sel.mine or LocalPlayer():IsSuperAdmin()
		local yPart = bAuteur and R(392) or R(240)
		if bAuteur then
		local lblEx = vgui.Create("DLabel", ed)
		lblEx:SetPos(RX(24), R(240)) lblEx:SetSize(RX(300), R(22))
		lblEx:SetFont("Bebas Neue:22") lblEx:SetTextColor(COL_DIM) lblEx:SetText("EXEMPLAIRES À IMPRIMER")

		DESK.count = math.Clamp(DESK.count or 1, 1, M.PrintMax)
		local cntLbl
		local minus = mkBtn(ed, "-", false, function()
			DESK.count = math.max(1, DESK.count - 1)
			cntLbl:SetText(DESK.count)
		end)
		minus:SetPos(RX(24), R(268)) minus:SetSize(R(44), R(44))
		cntLbl = vgui.Create("DLabel", ed)
		cntLbl:SetPos(RX(24) + R(52), R(268)) cntLbl:SetSize(R(60), R(44))
		cntLbl:SetFont("Bebas Neue:34") cntLbl:SetTextColor(COL_TITLE) cntLbl:SetContentAlignment(5)
		cntLbl:SetText(DESK.count)
		local plus = mkBtn(ed, "+", false, function()
			DESK.count = math.min(M.PrintMax, DESK.count + 1)
			cntLbl:SetText(DESK.count)
		end)
		plus:SetPos(RX(24) + R(120), R(268)) plus:SetSize(R(44), R(44))

		local print_ = mkBtn(ed, "IMPRIMER", true, function()
			net.Start("EVO:Missive:Print")
				net.WriteString(sel.id)
				net.WriteUInt(DESK.count, 4)
			net.SendToServer()
		end)
		print_:SetPos(RX(24) + R(180), R(268)) print_:SetSize(RX(512) - R(180), R(44))

		local dup = mkBtn(ed, "DUPLIQUER EN BROUILLON", false, function()
			DESK.draft = { ti = sel.ti or "", rk = sel.rk or "C", ob = sel.ob or "", rw = sel.rw or "",
				yen = (sel.yen or 0) > 0 and tostring(sel.yen) or "", ch = sel.ch or "", pl = sel.pl or M.DefaultPlaces, tb = sel.tb ~= false }
			DESK.sel = nil
			BuildDesk()
		end)
		dup:SetPos(RX(24), R(330)) dup:SetSize(RX(512), R(44))

		-- Retrait tout en bas, à l'écart des actions courantes.
		local del = vgui.Create("DButton", ed)
		del:SetText("") del:SetCursor("hand")
		del:SetPos(RX(24), R(820)) del:SetSize(RX(512), R(48))
		del.Paint = function(s, w, h)
			plate(0, 0, w, h, s:IsHovered() and Color(120, 34, 40, 235) or Color(64, 26, 30, 200), R(8))
			draw.SimpleText("RETIRER LA MISSIVE (rappelle les exemplaires)", "Bebas Neue:24", w / 2, h / 2,
				s:IsHovered() and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		del.DoClick = function()
			click()
			net.Start("EVO:Missive:Delete") net.WriteString(sel.id) net.SendToServer()
			DESK.sel = nil
		end
		end -- bAuteur

		-- PARTICIPANTS : n'importe quel officier du bureau valide (paiement par la
		-- trésorerie) ou refuse. On ne valide pas sa propre participation (serveur).
		local tk = sel.tk or {}
		local nPris = 0
		for _, t in ipairs(tk) do if t.st ~= "refus" then nPris = nPris + 1 end end
		local lblP = vgui.Create("DLabel", ed)
		lblP:SetPos(RX(24), yPart) lblP:SetSize(RX(512), R(22))
		lblP:SetFont("Bebas Neue:22") lblP:SetTextColor(COL_DIM)
		lblP:SetText("PARTICIPANTS · " .. nPris .. "/" .. (sel.pl or M.DefaultPlaces))
		local pList = vgui.Create("DScrollPanel", ed)
		pList:SetPos(RX(24), yPart + R(28))
		pList:SetSize(RX(512), (bAuteur and R(808) or R(868)) - (yPart + R(28)))
		pList.Paint = function(_, w, h)
			if #tk == 0 then
				draw.SimpleText("Personne n'a encore pris cette mission au tableau des quêtes.", "Avenir Next World:16",
					w / 2, R(24), COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		local ST_TXT = { cours = "En cours", paie = "Paiement…", ok = "Validée", refus = "Refusée" }
		local ST_COL = { cours = COL_GOLD, paie = COL_MUTED, ok = Color(96, 220, 130), refus = COL_ACCENT }
		for _, t in ipairs(tk) do
			local row = pList:Add("DPanel")
			row:Dock(TOP) row:DockMargin(0, 0, 0, R(6)) row:SetTall(R(48))
			row.Paint = function(_, w, h)
				plate(0, 0, w, h, COL_SUB, R(8))
				draw.SimpleText(t.nm or "?", "Bebas Neue:24", RX(14), h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if t.st ~= "cours" then
					draw.SimpleText(ST_TXT[t.st] or "", "Bebas Neue:22", w - RX(14), h / 2, ST_COL[t.st] or COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			if t.st == "cours" then
				local function juger(bOk)
					net.Start("EVO:Missive:Judge")
						net.WriteString(sel.id)
						net.WriteString(t.uid or "")
						net.WriteBool(bOk)
					net.SendToServer()
				end
				local ok = mkBtn(row, "VALIDER", true, function() juger(true) end)
				ok:SetSize(RX(110), R(36)) ok:SetPos(RX(512) - RX(110) * 2 - RX(16), R(6))
				local no = mkBtn(row, "REFUSER", false, function() juger(false) end)
				no:SetSize(RX(110), R(36)) no:SetPos(RX(512) - RX(110) - RX(8), R(6))
			end
		end
	end

	-- ── Colonne droite : APERÇU en direct de la feuille ──────────────────────
	local shH = R(792)
	local shW = math.floor(shH / 1.414)
	local sheet = vgui.Create("DPanel", root)
	sheet:SetPos(RX(1130), R(150) + math.floor((R(890) - shH - R(30)) / 2))
	sheet:SetSize(shW, shH)
	sheet.Paint = function(_, w, h)
		if RNDX and RNDX.DrawShadows then RNDX.DrawShadows(R(4), 0, 0, w, h, COL_SHADOW, R(16), 18) end
		local src
		if sel then
			src = { ti = sel.ti, rk = sel.rk, ob = sel.ob, rw = M.RewardText(sel.yen, sel.ch, sel.rk, sel.rw), au = sel.au, fa = sel.fa, at = sel.at }
		else
			src = { ti = draft.ti, rk = draft.rk, ob = draft.ob, rw = M.RewardText(tonumber(draft.yen) or 0, draft.ch, draft.rk, draft.rw),
				au = myName(), fa = myFaction(), at = os.time() }
		end
		DrawSheet(w, h, src)
	end
	local cap = vgui.Create("DLabel", root)
	cap:SetPos(RX(1130), sheet:GetY() + shH + R(8))
	cap:SetSize(shW, R(20))
	cap:SetFont("Avenir Next World:16") cap:SetTextColor(COL_DIM) cap:SetContentAlignment(5)
	cap:SetText(sel and "Exemplaire tel qu'imprimé" or "Aperçu en direct de ta rédaction")
end

net.Receive("EVO:Missive:Desk", function()
	local nLen = net.ReadUInt(32)
	local sJson = util.Decompress(net.ReadData(nLen), 400000)
	local t = util.JSONToTable(sJson or "{}") or {}
	local selId = DESK.sel and DESK.docs[DESK.sel] and DESK.docs[DESK.sel].id or nil
	DESK.docs = istable(t.docs) and t.docs or {}
	DESK.sel = nil
	if selId then
		for i, d in ipairs(DESK.docs) do
			if d.id == selId then DESK.sel = i break end
		end
	end
	if not IsValid(DESK.frame) then
		local frame = makeBackdrop(false)
		frame.OnRemove = function(s)
			if openedFrame == s then openedFrame = nil end
			DESK.frame = nil
		end
		local content = vgui.Create("DPanel", frame)
		content:SetSize(ScrW(), ScrH()) content:SetPos(0, 0)
		content.Paint = function(_, w, h)
			local padX = RX(70)
			draw.SimpleText("BUREAU DES MISSIONS", "Bebas Neue:68", padX, R(70), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetFont("Bebas Neue:68")
			local tw = surface.GetTextSize("BUREAU DES MISSIONS")
			plate(padX, R(108), tw, R(5), COL_ACCENT, R(2))
			draw.SimpleText("Rédige une mission : elle part au tableau des quêtes de ta faction. Valide ici ceux qui l'ont accomplie.",
				"Avenir Next World:20", padX + tw + RX(30), R(78), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		frame._content = content
		DESK.frame = frame
	end
	BuildDesk()
end)

-- ============================================================================
-- ZONE DU BUREAU : plaque « BUREAU DES MISSIONS [E] Rédiger les missives » face
-- au joueur (EVO_ZonePrompt, recette cachot — plus de cercle au sol, user 08/24).
-- ============================================================================
hook.Add("PostDrawTranslucentRenderables", "EVO_Missive::ZoneMarker", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local z = M.ZoneFor(game.GetMap())
	if not z then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Le bureau n'existe QUE pour sa division (user 08/19) : aucun marqueur,
	-- aucune enseigne pour les autres. Le serveur revalide de toute façon.
	if not M.CanUseDesk(lp) then return end
	local gpos = M.ZoneAnchor(z) -- z ancré au sol, comme les Archives
	if EyePos():DistToSqr(gpos) > (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then return end

	EVO_ZonePrompt.Draw(gpos, "BUREAU DES MISSIONS", "Rédiger les missives")
end)

hook.Add("PlayerButtonDown", "EVO_Missive::UseKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if IsValid(DESK.frame) or IsValid(M._viewUI) then return end
	if not M.CanUseDesk(ply) or not M.InZone(ply) then return end
	net.Start("EVO:Missive:Open")
	net.SendToServer()
end)

-- Ouverture sans zone (maps pas encore calées) : le serveur exige superadmin.
concommand.Add("evo_missive_bureau", function()
	net.Start("EVO:Missive:Open")
	net.SendToServer()
end)

-- ── Pose de lecture forcée sur TOUT joueur qui lit une missive (recette carte
-- en main : ResetSequence UNE fois puis playback tenu, cache par modèle). ─────
local seqCache = {}
local function CachedLookupSequence(ply, seqName)
	local key = ply:GetModel() .. "_" .. seqName
	if seqCache[key] == nil then
		seqCache[key] = ply:LookupSequence(seqName) or -1
	end
	return seqCache[key]
end

hook.Add("UpdateAnimation", "EVO_Missive::ReadAnimForce", function(ply)
	if not IsValid(ply) then return end
	if not ply:GetEvoNWBool(M.ReadNW, false) then
		ply._MissiveSeqSet = nil
		return
	end
	local nSeq = CachedLookupSequence(ply, M.ReadAnim)
	if nSeq and nSeq > 0 then
		-- Ne reset la séquence qu'UNE fois pour ne pas bloquer l'anim à cycle 0.
		if not ply._MissiveSeqSet then
			ply:ResetSequence(nSeq)
			ply:SetCycle(0)
			ply._MissiveSeqSet = true
		end
		ply:SetPlaybackRate(1)
		return true
	end
end)

-- ── Defs des missives -> items d'inventaire CLIENT ──────────────────────────
local function installDef(d)
	M.Defs[d.id] = d
	M.RegisterMissiveItem({ id = d.id, ti = d.title, rk = d.rank, au = d.ownerName, at = d.createdAt })
end
local function readDef()
	return {
		id = net.ReadString(), title = net.ReadString(), rank = net.ReadString(),
		ownerName = net.ReadString(), createdAt = net.ReadUInt(32),
	}
end
net.Receive("EVO:Missive:DefAdd", function() installDef(readDef()) end)
net.Receive("EVO:Missive:DefRemove", function()
	local id = net.ReadString()
	M.Defs[id] = nil
end)
-- Gardien permanent : un refresh Lua ré-assigne la table ITEMS et les items
-- dynamiques deviennent des cases vides (piège evo_livre). Ré-installe depuis
-- les defs connues ; coût nul quand tout est en place.
timer.Create("EVO_Missive::EnsureItemsCL", 3, 0, function()
	if istable(ITEMS) then M.RegisterWrittenItem() end
end)
M.RegisterWrittenItem()

net.Receive("EVO:Missive:DefAll", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do installDef(readDef()) end
end)
