-- "addons\\evo_repos\\lua\\autorun\\sh_evo_repos.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO REPOS — points « [E] S'allonger » (demande user 2026-07-24).
-- À un SPOT (position + orientation, par map), un prompt [E] apparaît ; l'appui
-- pose le joueur sur le spot et joue l'emote « Allongé sur le dos »
-- (evo_ca1g2is0q0w26o1dt) via le pipeline du menu d'animations -> cancel au
-- mouvement + persistance PVS + soignable comme les autres emotes « à terre ».
--
-- Les spots sont ÉDITABLES IN-GAME (panneau SuperAdmin : concommand
-- « evo_repos_menu ») : ajout à ta position exacte, suppression, TP. Ils sont
-- PERSISTÉS (data/evo_repos_spots.json côté serveur) et NETWORKÉS aux clients
-- (aucun redémarrage nécessaire après un ajout/suppression).
-- ============================================================================

EVO_REPOS = EVO_REPOS or {}

-- Emote jouée = « Allongé sur le dos » (id du menu lzy_animation_menu/config.lua).
EVO_REPOS.Anim = "evo_ca1g2is0q0w26o1dt"

-- Lit médecin spawné (config_positions) : l'emote doit s'aligner sur le prop.
-- HealBedLocalYaw = yaw LOCAL au modèle (0 = Forward, 90 = Right). Les usercmds
-- client écrasent SetEyeAngles serveur chaque tick -> le lock CreateMove (cl) est
-- obligatoire, sinon le joueur garde le regard d'approche (souvent sur le CÔTÉ
-- du lit = pieds qui sortent).
EVO_REPOS.HealBedModel = "models/props_unique/hospital/hospital_bed.mdl"
-- hospital_bed (L4D) : matelas le long du Right local (+Y), pas du Forward.
-- 90 = aligné dans le lit ; 0 = en travers (pieds qui sortent sur le côté).
EVO_REPOS.HealBedLocalYaw = 90

function EVO_REPOS.IsHealBed(ent)
	return IsValid(ent) and string.lower(ent:GetModel() or "") == EVO_REPOS.HealBedModel
end

function EVO_REPOS.NearestHealBed(pos, radius)
	if not isvector(pos) then return nil end
	radius = tonumber(radius) or 120
	local best, bestD
	for _, e in ipairs(ents.FindInSphere(pos, radius)) do
		if EVO_REPOS.IsHealBed(e) then
			local d = e:GetPos():DistToSqr(pos)
			if not bestD or d < bestD then
				best, bestD = e, d
			end
		end
	end
	return best
end

-- Yaw monde pour s'allonger sur ce lit (Forward du modèle + offset local).
function EVO_REPOS.LieYawForBed(bed)
	if not IsValid(bed) then return nil end
	local localYaw = tonumber(EVO_REPOS.HealBedLocalYaw) or 0
	return bed:LocalToWorldAngles(Angle(0, localYaw, 0)).y
end

-- Yaw du lit hospital_bed, figé au premier allongement.
-- Relire GetAngles() à chaque E est faux : s'allonger dessus décale le physobj
-- (même motion off) et le 2e E se couche en travers. Un move gizmo (MoveSpot)
-- vide le cache pour reprendre la nouvelle pose.
function EVO_REPOS.ResolveLieYaw(spot)
	if not spot then return 0 end
	if tonumber(spot._evoHealYaw) then
		return math.NormalizeAngle(spot._evoHealYaw)
	end
	local bed = EVO_REPOS.NearestHealBed(spot.pos, 120)
	if IsValid(bed) then
		local yaw = EVO_REPOS.LieYawForBed(bed)
		if yaw then
			yaw = math.NormalizeAngle(yaw)
			spot._evoHealYaw = yaw
			return yaw
		end
	end
	return math.NormalizeAngle(tonumber(spot.yaw) or 0)
end

-- ── MANNEQUIN D'ENTRAÎNEMENT (demande user 2026-07-31) ──────────────────────
-- Sur un lit LIBRE, les hauts gradés de la division de soin posent un mannequin
-- avec F ; E dessus lance la même opération « Docteur Maboule » que sur un vrai
-- patient (voie EvoHealBed.StartHeal du cobaye ncm_operation_test).
EVO_REPOS.DummyModel = "models/evo/props/items/evo_85hgjsc5452tdezx9452ghfbj/evo_85hgjsc5452tdezx9452GHFbj.mdl"

-- Gate PARTAGÉE (prompt client + revalidation serveur) : réutilise les deux règles
-- existantes — division de soin (EvoHealBed.CanHeal) ET grade formateur
-- (EVO_INSTRUCTEUR.IsInstructor, MinGrade 6) ; SuperAdmin passe les deux.
function EVO_REPOS.CanManageDummy(ply)
	if not IsValid(ply) then return false end
	if not (EvoHealBed and EvoHealBed.CanHeal and EVO_INSTRUCTEUR and EVO_INSTRUCTEUR.IsInstructor) then return false end
	return EvoHealBed.CanHeal(ply) and EVO_INSTRUCTEUR.IsInstructor(ply)
end

-- SEED initial (utilisé UNIQUEMENT si aucun fichier de données n'existe encore).
-- Ensuite, la vérité vient de EVO_REPOS.Spots (fichier data / net).
EVO_REPOS.DefaultSpots = {
	["rp_seireitei_v1"] = {
		-- Infirmerie Seireitei (25 lits, demande user 2026-07-24, valeurs exactes evo_repos_print).
		{ pos = Vector(-7904.207520, -9980.789062, 555.873047), yaw = -94.142830, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8026.892090, -10114.650391, 385.653595), yaw = 94.314000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-7915.398438, -10120.090820, 385.653595), yaw = 89.392000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-7913.086914, -9707.537109, 386.332428), yaw = 90.445000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8025.723145, -9704.853516, 385.653595), yaw = 93.349000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8446.224609, -9707.240234, 386.142120), yaw = 91.627000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8559.228516, -9707.813477, 386.509613), yaw = 90.570000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8557.429688, -10128.253906, 390.612885), yaw = 91.353000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8446.501953, -10120.562500, 385.653595), yaw = 89.899000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8990.254883, -9706.435547, 385.653595), yaw = 90.819000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-9100.549805, -9705.449219, 385.653595), yaw = 90.026000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-9103.451172, -10120.029297, 385.653595), yaw = 90.022000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8989.453125, -10120.646484, 385.653595), yaw = 90.778000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6664.327148, -12188.106445, 386.671753), yaw = 93.318000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6553.219238, -12187.037109, 385.653595), yaw = 91.170000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6666.923340, -11774.361328, 386.835175), yaw = 90.637000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6553.827637, -11772.614258, 385.653595), yaw = 93.404000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6125.941895, -12187.044922, 385.653595), yaw = 91.853000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6010.483398, -12183.925781, 385.653595), yaw = 87.723000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6013.255859, -11774.783203, 387.105621), yaw = 88.776000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-6126.322266, -11771.706055, 385.653595), yaw = 87.851000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-5592.313477, -11771.457031, 385.653595), yaw = 90.883000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-5479.242676, -11774.412109, 386.867737), yaw = 93.255000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-5591.801758, -12180.588867, 385.653595), yaw = 90.780000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-5478.943848, -12186.981445, 385.653595), yaw = 91.303000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8270.661133, -7579.524414, 453.882843), yaw = -0.948000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-8273.875977, -7327.063477, 455.943878), yaw = -0.156000, radius = 90, label = "S'allonger" },
		-- Lits du laboratoire scientifique (user 09/20, valeurs exactes evo_repos_print) :
		-- amputation et pose de prothèse se font sur un lit, comme les opérations de soin.
		{ pos = Vector(4787.506836, 9650.185547, 14926.863281), yaw = 88.715000, radius = 90, label = "S'allonger" },
		{ pos = Vector(4783.951172, 9865.413086, 14930.171875), yaw = 90.431000, radius = 90, label = "S'allonger" },
		{ pos = Vector(4790.344727, 4920.997070, 14931.180664), yaw = -95.595000, radius = 90, label = "S'allonger" },
		{ pos = Vector(4790.012695, 5132.168457, 14931.180664), yaw = -91.799000, radius = 90, label = "S'allonger" },
	},
	["hueco_mundo_v1"] = {
		-- Infirmerie de l'Ordre médecin, nouvelle salle (poses user 08/22 :
		-- l'ancienne double rangée 5603/4279 est remplacée d'un bloc).
		{ pos = Vector(-11727.388672, 5598.638672, 6303.334961), yaw = -92.125000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12654.189453, 5943.649414, 6284.031250), yaw = -0.740000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12654.343750, 5777.404297, 6284.031250), yaw = -0.604000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12658.402344, 5607.974609, 6284.031250), yaw = -0.203000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12658.550781, 5445.374512, 6284.031250), yaw = 2.178000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12661.923828, 5278.863281, 6284.031250), yaw = 0.987000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12164.072266, 5285.215332, 6284.031250), yaw = -179.329000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12167.599609, 5458.171875, 6284.031250), yaw = -176.156000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12168.250000, 5621.871582, 6284.031250), yaw = -174.306000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12170.714844, 5784.806152, 6284.031250), yaw = 178.437000, radius = 90, label = "S'allonger" },
		{ pos = Vector(-12167.726562, 5946.061035, 6284.031250), yaw = -176.417000, radius = 90, label = "S'allonger" },
		-- Lit du laboratoire scientifique de l'Ordre 3 (user 09/20, valeurs exactes evo_repos_print).
		-- Le meuble lui-même = EVO_ConfigPos.WorldModelDefaults (evo_config_positions).
		{ pos = Vector(-11140.880859, 653.904053, 6315.011719), yaw = 1.282000, radius = 90, label = "S'allonger" },
	},
}

-- Liste LIVE des spots par map. Serveur : chargée du fichier data (seed au 1er boot).
-- Client : reçue par le net EVO_Repos:Sync. NearestSpot l'utilise des deux côtés.
EVO_REPOS.Spots = EVO_REPOS.Spots or {}

-- Spot de la MAP COURANTE dont `pos` est le plus proche et dans son rayon.
-- Renvoie (spot, index) ou nil. Partagé (client : prompt ; serveur : revalidation).
function EVO_REPOS.NearestSpot(vPos)
	local list = EVO_REPOS.Spots[game.GetMap()]
	if not list then return nil end
	local best, bestD, bestI
	for i, s in ipairs(list) do
		local d = vPos:DistToSqr(s.pos)
		if d <= (s.radius * s.radius) and (not bestD or d < bestD) then
			best, bestD, bestI = s, d, i
		end
	end
	return best, bestI
end

-- Occupant d'un spot (09/10, UN SEUL joueur par lit) : un AUTRE joueur qui joue l'emote
-- couchée à <= OCCUPY_DIST du spot (Lie pose exactement sur spot.pos ; lits voisins à
-- 110 u et plus). Partagé : refus serveur (Lie) + prompt client « Lit occupé ».
EVO_REPOS.OCCUPY_DIST = 60
function EVO_REPOS.SpotOccupant(spot, pIgnore)
	if not spot then return nil end
	local nMax = EVO_REPOS.OCCUPY_DIST * EVO_REPOS.OCCUPY_DIST
	for _, p in player.Iterator() do
		if p ~= pIgnore and p:Alive()
			and p:GetEvoNWString("EVO::AnimMenuLoopPath", "") == EVO_REPOS.Anim
			and p:GetPos():DistToSqr(spot.pos) <= nMax then
			return p
		end
	end
	return nil
end
