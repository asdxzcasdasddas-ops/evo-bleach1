-- "addons\\evo_repos\\lua\\autorun\\client\\cl_evo_repos_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO REPOS — PANNEAU D'ÉDITION (SuperAdmin). Concommand « evo_repos_menu ».
-- « Ajouter ici » capture ta position EXACTE (lue côté serveur) + ton yaw.
-- Liste des spots de la map : TP + Supprimer. Persisté + networké en direct
-- (le prompt [E] apparaît/disparaît sans redémarrage). Toutes les actions sont
-- re-validées SuperAdmin côté serveur.
-- ============================================================================

if not CLIENT then return end

local COL_BG    = Color(20, 20, 25)
local COL_ROW   = Color(32, 32, 39)
local COL_TXT   = Color(235, 236, 240)
local COL_ACCENT= Color(207, 68, 78)

local function openMenu()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then
		chat.AddText(COL_ACCENT, "[Repos] Réservé aux SuperAdmins.")
		return
	end
	if IsValid(EVO_REPOS._Menu) then EVO_REPOS._Menu:Remove() end

	local frame = vgui.Create("DFrame")
	EVO_REPOS._Menu = frame
	frame:SetSize(540, 460)
	frame:Center()
	frame:SetTitle("Points « [E] S'allonger » : " .. game.GetMap())
	frame:MakePopup()
	frame.Paint = function(_, w, h)
		draw.RoundedBox(6, 0, 0, w, h, COL_BG)
		surface.SetDrawColor(COL_ACCENT) surface.DrawRect(0, 24, w, 2)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end

	-- Redemande la liste à jour au serveur (au cas où le sync initial aurait été manqué).
	net.Start("EVO_Repos:RequestSync") net.SendToServer()

	-- ── Barre d'ajout ──
	local rad = vgui.Create("DNumSlider", frame)
	rad:Dock(TOP) rad:DockMargin(8, 6, 8, 0) rad:SetTall(30)
	rad:SetText("Rayon du prompt")
	rad:SetMin(30) rad:SetMax(300) rad:SetDecimals(0) rad:SetValue(90)
	rad.Label:SetTextColor(COL_TXT)

	local lblEntry = vgui.Create("DTextEntry", frame)
	lblEntry:Dock(TOP) lblEntry:DockMargin(8, 4, 8, 0) lblEntry:SetTall(26)
	lblEntry:SetValue("S'allonger")
	lblEntry:SetUpdateOnType(true)

	local add = vgui.Create("DButton", frame)
	add:Dock(TOP) add:DockMargin(8, 6, 8, 6) add:SetTall(36)
	add:SetText("➕  Ajouter un spot ICI (ma position exacte)")
	add:SetTextColor(color_white)
	add.Paint = function(s, w, h)
		draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(227, 88, 98) or COL_ACCENT)
	end
	add.DoClick = function()
		net.Start("EVO_Repos:Add")
			net.WriteUInt(math.Clamp(math.Round(rad:GetValue()), 30, 300), 16)
			net.WriteString(lblEntry:GetValue() or "S'allonger")
		net.SendToServer()
	end

	-- Imprime les spots (valeurs exactes) dans la console pour copier/coller.
	local prn = vgui.Create("DButton", frame)
	prn:Dock(TOP) prn:DockMargin(8, 0, 8, 6) prn:SetTall(28)
	prn:SetText("Imprimer les spots dans la console")
	prn:SetTextColor(COL_TXT)
	prn.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(58, 58, 70) or Color(42, 42, 52)) end
	prn.DoClick = function() net.Start("EVO_Repos:Print") net.SendToServer() end

	-- ── Liste ──
	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:Dock(FILL) scroll:DockMargin(8, 0, 8, 8)

	local function refresh()
		scroll:GetCanvas():Clear()
		local spots = EVO_REPOS.Spots[game.GetMap()] or {}
		if #spots == 0 then
			local e = vgui.Create("DLabel", scroll)
			e:Dock(TOP) e:DockMargin(4, 8, 4, 4)
			e:SetText("Aucun spot sur cette map. Place-toi à l'endroit voulu et clique « Ajouter ».")
			e:SetTextColor(Color(150, 152, 158))
			return
		end
		for i, s in ipairs(spots) do
			local row = vgui.Create("DPanel", scroll)
			row:Dock(TOP) row:DockMargin(0, 0, 0, 5) row:SetTall(44)
			row.Paint = function(_, w, h) draw.RoundedBox(4, 0, 0, w, h, COL_ROW) end

			-- Supprimer : UNIQUEMENT les spots du PANNEAU. Les spots du CODE (config) portent
			-- un badge « CODE » et s'éditent dans sh_evo_repos.lua (le code prime).
			if not s.code then
				local del = vgui.Create("DButton", row)
				del:Dock(RIGHT) del:DockMargin(4, 6, 6, 6) del:SetWide(90) del:SetText("Supprimer")
				del:SetTextColor(color_white)
				del.Paint = function(sb, w, h) draw.RoundedBox(4, 0, 0, w, h, sb:IsHovered() and Color(180, 55, 60) or Color(120, 40, 44)) end
				del.DoClick = function()
					net.Start("EVO_Repos:Remove") net.WriteUInt(i, 16) net.SendToServer()
				end
			else
				local tag = vgui.Create("DLabel", row)
				tag:Dock(RIGHT) tag:DockMargin(4, 0, 10, 0) tag:SetWide(84)
				tag:SetText("CODE") tag:SetContentAlignment(6) tag:SetTextColor(Color(150, 170, 210))
			end

			local tp = vgui.Create("DButton", row)
			tp:Dock(RIGHT) tp:DockMargin(4, 6, 0, 6) tp:SetWide(56) tp:SetText("TP")
			tp:SetTextColor(color_white)
			tp.Paint = function(sb, w, h) draw.RoundedBox(4, 0, 0, w, h, sb:IsHovered() and Color(60, 60, 72) or Color(46, 46, 56)) end
			tp.DoClick = function()
				net.Start("EVO_Repos:Tp") net.WriteUInt(i, 16) net.SendToServer()
			end

			local info = vgui.Create("DLabel", row)
			info:Dock(FILL) info:DockMargin(10, 0, 0, 0)
			info:SetText(string.format("#%d   « %s »   (%.0f, %.0f, %.0f)   yaw %.0f   r=%d",
				i, tostring(s.label or ""), s.pos.x, s.pos.y, s.pos.z, s.yaw or 0, s.radius or 90))
			info:SetTextColor(COL_TXT)
		end
	end

	refresh()
	-- Le net Sync (cl_evo_repos) appelle ce refresh quand la liste change côté serveur.
	EVO_REPOS.RefreshMenu = function() if IsValid(frame) then refresh() end end
	frame.OnRemove = function() EVO_REPOS.RefreshMenu = nil end
end

concommand.Add("evo_repos_menu", openMenu)
