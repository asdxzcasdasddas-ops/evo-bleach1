-- "addons\\evo_repos\\lua\\autorun\\client\\cl_evo_repos.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO REPOS — CLIENT : prompt « [E] S'allonger » près d'un spot + détection de
-- l'appui E. E envoie EVO_Repos:Lie (le serveur place + joue l'emote). Si on est
-- déjà couché sur le spot, E envoie StopAnimation (= se relever). On NE vole PAS
-- le E d'une entité usable (porte/PNJ/joueur/prop sous le réticule) ni pendant un
-- menu / KO -> aucun conflit avec le +use normal ou la roue radiale (hold E).
-- ============================================================================

if not CLIENT then return end

local COL_BG     = Color(14, 14, 17, 225)
local COL_ACCENT = Color(207, 68, 78, 255)
local COL_TXT    = Color(238, 239, 243, 255)

local function S(v) return math.Round(v * (ScrH() / 1080)) end

local function makeFonts()
	surface.CreateFont("EVO_Repos_Key",   { font = "Bebas Neue", size = S(20), weight = 600, antialias = true })
	surface.CreateFont("EVO_Repos_Label", { font = "Bebas Neue", size = S(26), weight = 500, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO_Repos::Fonts", makeFonts)

-- Le joueur joue-t-il DÉJÀ notre emote couchée (via un spot) ? -> toggle « se relever ».
local function isLying(lp)
	return lp:GetEvoNWString("EVO::AnimMenuLoopPath", "") == EVO_REPOS.Anim
end

-- Yaw figé pendant l'emote : sans ça les usercmds renvoient le regard d'approche
-- et écrasent SetEyeAngles serveur chaque tick. UNIQUEMENT le yaw envoyé par le
-- serveur : relire le prop côté client est faux après le 1er allongement (le
-- physobj local a bougé) et recouchait le joueur en travers.
local lieYawLocked
net.Receive("EVO_Repos:LieYaw", function()
	lieYawLocked = net.ReadFloat()
end)

hook.Add("CreateMove", "EVO_Repos::LieYawLock", function(cmd)
	local lp = LocalPlayer()
	if not IsValid(lp) or not isLying(lp) or not lieYawLocked then return end
	cmd:SetViewAngles(Angle(0, lieYawLocked, 0))
end)

-- Mannequin d'entraînement présent sur ce spot ? Détection LOCALE par modèle
-- (l'occupation autoritaire vit côté serveur ; ici on ne pilote que l'affichage
-- et la mise en veille du E). Throttlée : pas de scan à chaque frame.
local sDummyModel = string.lower(EVO_REPOS.DummyModel or "")
local dummyEnt, dummyAt, dummySpot
local function spotDummy(spot)
	if dummySpot == spot and CurTime() - (dummyAt or 0) < 0.25 then return dummyEnt end
	dummySpot, dummyAt, dummyEnt = spot, CurTime(), nil
	for _, e in ipairs(ents.FindInSphere(spot.pos, 80)) do
		if IsValid(e) and string.lower(e:GetModel() or "") == sDummyModel then dummyEnt = e break end
	end
	return dummyEnt
end

-- Autre joueur déjà couché sur ce spot ? (helper partagé, throttlé comme le mannequin)
local occAt, occSpot, occPly = 0, nil, nil
local function spotOccupant(spot)
	if occSpot == spot and CurTime() - occAt < 0.25 then return occPly end
	occSpot, occAt = spot, CurTime()
	occPly = EVO_REPOS.SpotOccupant(spot, LocalPlayer())
	return occPly
end

-- ── Détection des appuis E / F (front montant) ──────────────────────────────
local wasUse, wasF = false, false
local function SendReposAction(lying)
	net.Start(lying and "Evo:Server:AnimationMenu:StopAnimation" or "EVO_Repos:Lie")
	net.SendToServer()
end
hook.Add("Think", "EVO_Repos::Detect", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then wasUse = false wasF = false return end
	local downE = lp:KeyDown(IN_USE)
	local edgeE = downE and not wasUse
	wasUse = downE
	local downF = input.IsKeyDown(KEY_F)
	local edgeF = downF and not wasF
	wasF = downF
	if not (edgeE or edgeF) then return end
	if vgui.CursorVisible() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	-- Sous opération : pas de s'allonger / se relever (serveur refuse aussi StopAnimation).
	if lp:GetEvoNWBool("EVO_HealBed_Operated", false)
		or lp:GetEvoNWBool("EVO_HealBed_Healing", false) then
		return
	end
	local spot = EVO_REPOS.NearestSpot(lp:GetPos())
	if not spot then return end

	-- F : poser / retirer le mannequin d'entraînement (gate partagée, revalidée serveur).
	if edgeF then
		if EVO_REPOS.CanManageDummy(lp) then
			net.Start("EVO_Repos:Dummy") -- netgate: edge -- F key rising edge (wasF)
			net.SendToServer()
		end
		return
	end

	local dummy = spotDummy(spot)

	-- Ne pas voler le E d'une entité usable sous le réticule (porte/PNJ/joueur/prop
	-- proche) : le +use / la roue radiale gardent la priorité. Le sol (worldspawn,
	-- EntIndex 0) ne compte pas ; le MANNEQUIN non plus (c'est justement notre cible).
	-- Lit médecin spawné (hospital_bed) : le prop EST la cible du [E] S'allonger —
	-- sans cette exception, viser le matelas bloquait le Lie.
	local tr = lp:GetEyeTrace()
	local trEnt = tr.Entity
	local trIsHealBed = EVO_REPOS.IsHealBed(trEnt)
	if IsValid(trEnt) and trEnt:EntIndex() > 0 and trEnt ~= dummy and not trIsHealBed
		and tr.HitPos:DistToSqr(lp:EyePos()) < 90 * 90 then
		return
	end

	-- Lit occupé par un mannequin : E = OPÉRER, via un net dédié revalidé serveur
	-- (le dispatch +use moteur sur un base_anim spawné en Lua ne se déclenchait pas
	-- in-game -> même patron déterministe que Lie, aucune visée précise exigée).
	if IsValid(dummy) then
		net.Start("EVO_Repos:Operate") -- netgate: edge -- USE key rising edge (wasUse)
		net.SendToServer()
		return
	end

	-- Lit déjà occupé par un autre joueur : rien à envoyer (le serveur refuse aussi).
	if not isLying(lp) and IsValid(spotOccupant(spot)) then return end

	SendReposAction(isLying(lp))  -- netgate: edge -- USE key rising edge (wasUse)
end)

-- ── Prompt [E]/[F] près d'un spot ────────────────────────────────────────────
local COL_ACCENT_F = Color(86, 176, 124, 255) -- keycap F (mannequin) : vert « soin »
local COL_OCCUPIED = Color(96, 98, 104, 255)  -- keycap grisée : lit déjà occupé

-- Une ligne « keycap + libellé », centrée. Même géométrie que le prompt d'origine.
local function drawKeyRow(cy, sKey, sLabel, colKey)
	-- Style d'invite unifié ; lit occupé (keycap grisée) = motif seul, sans touche.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(ScrW() * 0.5, cy, "", sLabel, colKey == COL_OCCUPIED and "" or sKey)
		return
	end
	surface.SetFont("EVO_Repos_Label")
	local lw = surface.GetTextSize(sLabel)
	local keyR, gap = S(13), S(9)
	local totalW = keyR * 2 + gap + lw
	local x0 = ScrW() * 0.5 - totalW * 0.5

	-- Fond discret derrière l'ensemble (lisibilité).
	local padX, padY = S(10), S(7)
	draw.RoundedBox(S(6), x0 - padX, cy - keyR - padY, totalW + padX * 2, keyR * 2 + padY * 2, COL_BG)
	local kx = x0 + keyR
	draw.RoundedBox(S(4), kx - keyR, cy - keyR, keyR * 2, keyR * 2, colKey)
	draw.SimpleText(sKey, "EVO_Repos_Key", kx, cy + S(1), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sLabel, "EVO_Repos_Label", x0 + keyR * 2 + gap, cy, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

hook.Add("HUDPaint", "EVO_Repos::Prompt", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if vgui.CursorVisible() then return end
	local spot = EVO_REPOS.NearestSpot(lp:GetPos())
	if not spot then return end

	-- Lignes selon l'état du lit et le rôle : lit libre = S'allonger (tout le monde) ;
	-- mannequin posé = Opérer (médecins) ; pose/retrait au F (gate partagée formateur).
	local rows = {}
	local bManage = EVO_REPOS.CanManageDummy(lp)
	if IsValid(spotDummy(spot)) then
		if EvoHealBed and EvoHealBed.CanHeal and EvoHealBed.CanHeal(lp) then
			rows[#rows + 1] = { key = "E", label = "Opérer le mannequin", col = COL_ACCENT }
		end
		if bManage then
			rows[#rows + 1] = { key = "F", label = "Retirer le mannequin", col = COL_ACCENT_F }
		end
	elseif not isLying(lp) and IsValid(spotOccupant(spot)) then
		rows[#rows + 1] = { key = "E", label = "Lit occupé", col = COL_OCCUPIED }
	else
		rows[#rows + 1] = { key = "E", label = isLying(lp) and "Se relever" or (spot.label or "S'allonger"), col = COL_ACCENT }
		if bManage then
			rows[#rows + 1] = { key = "F", label = "Poser un mannequin d'entraînement", col = COL_ACCENT_F }
		end
	end
	if #rows == 0 then return end

	local cy = ScrH() * 0.5 + S(66)
	-- Pas entre lignes : 60 u à l'échelle EVO_ZonePrompt (ScrH/1080*0.5), sinon l'ancien.
	local nStep = (EVO_ZonePrompt and EVO_ZonePrompt.Draw2D) and (ScrH() / 1080 * 30) or S(46)
	for i, r in ipairs(rows) do
		drawKeyRow(cy + (i - 1) * nStep, r.key, r.label, r.col)
	end
end)

-- ── Liste des spots reçue du serveur (persistée + éditable in-game) ──────────
net.Receive("EVO_Repos:Sync", function()
	EVO_REPOS.Spots[game.GetMap()] = net.ReadTable()
	if EVO_REPOS.RefreshMenu then EVO_REPOS.RefreshMenu() end -- rafraîchit le panneau s'il est ouvert
end)

-- Demande la liste au chargement (le serveur re-push aussi au spawn, filet de sécurité).
hook.Add("InitPostEntity", "EVO_Repos::RequestSync", function()
	net.Start("EVO_Repos:RequestSync") net.SendToServer()
end)

-- ── Impression des spots dans la console (valeurs EXACTES du serveur) ────────
net.Receive("EVO_Repos:Print", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do print(net.ReadString()) end
	chat.AddText(Color(120, 220, 120), "[Repos] ", color_white, "spots imprimés dans la console (ouvre-la : « ² » / ~).")
end)

-- Raccourci sans passer par le panneau.
concommand.Add("evo_repos_print", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then
		chat.AddText(Color(255, 80, 80), "[Repos] Réservé aux SuperAdmins.")
		return
	end
	net.Start("EVO_Repos:Print") net.SendToServer()
end)
