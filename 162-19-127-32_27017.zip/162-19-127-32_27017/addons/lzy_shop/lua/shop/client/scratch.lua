-- "addons\\lzy_shop\\lua\\shop\\client\\scratch.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- TICKET (grille de lots) — client (user 08/26). Panneau "LZY:Shop:Ticket"
-- (1840x905, monté par main.lua OpenCategory). Tout en VGUI (plus de DHTML) :
-- les lots sont montrés « en vrai » — modèle 3D du gros lot (katana bankai
-- d'Ichigo / gantelet du Lion d'Or) et des accessoires via l'aperçu inventaire,
-- icônes reroll déjà utilisées par le panneau Reroll, icône kan du HUD pour les
-- yens. DEUX ONGLETS (gros lot katana / gros lot hakuda), une grille persistée
-- par onglet. Un tirage lance un ROULEMENT façon reroll (la surbrillance saute
-- de case en case, ralentit, s'arrête sur le lot), puis le lot s'affiche EN
-- GRAND AU CENTRE ; la case remportée reste GRISÉE (état serveur). À droite :
-- prix, solde, boutons et la liste des lots avec leurs taux. Le lot est versé
-- par le serveur AU TIRAGE ; l'animation est purement visuelle.
-- ============================================================================
local PANEL = {}
local _active

local ACCENT    = Color(207, 68, 78)
local COL_GOLD  = Color(255, 205, 60)
local COL_GOLD2 = Color(196, 142, 26)
local COL_MUTED = Color(150, 154, 162)
local COL_TITLE = Color(238, 239, 243)
local COL_PLATE = Color(13, 14, 17, 235)
local COL_CELL  = Color(22, 24, 29, 235)

local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"
local SND_GAIN  = "a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3"
local SND_TICK  = "4wsd81r0bjysb8vy/j7yfn6t0r7a7d.wav"

local coinMat = Material("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "smooth")
-- Icônes reroll DÉJÀ utilisées par le panneau Reroll (630x630).
local REROLL_MAT = {
	art   = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/red.png", "smooth"),
	aura  = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/green.png", "smooth"),
	style = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/purple.png", "smooth"),
}
local function MoneyMat() return (MUGEN and MUGEN.MoneyIcon) or coinMat end

local function Notify(msg, bErr)
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify(msg, bErr and NOTIFY_ERROR or NOTIFY_GENERIC, 5)
	else
		chat.AddText(ACCENT, "[Boutique] ", color_white, msg)
	end
end

local function TierCol(t) return SCRATCH_CONFIG.TierColor[t] or COL_MUTED end

local function FmtPct(p)
	if math.abs(p - math.Round(p)) < 0.05 then return string.format("%d %%", math.Round(p)) end
	return string.format("%.1f %%", p)
end

local function DrawMat(mat, x, y, s, alpha)
	surface.SetDrawColor(255, 255, 255, alpha or 255)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(math.Round(x), math.Round(y), math.Round(s), math.Round(s))
end

-- ── Icône « œil » (aperçu sur ton perso) : amande PLEINE + pupille sombre, sans
-- anneau ni plaque derrière (user 08/27 : « pas de contour bizarre avec un fond
-- noir »). Polygones réutilisés, 0 alloc par frame.
local EYE_SEGS = 24
local EYE_COS, EYE_SIN, EYE_OUT, EYE_PUP = {}, {}, {}, {}
for i = 1, EYE_SEGS do
	local a = (i - 1) / EYE_SEGS * math.pi * 2
	EYE_COS[i], EYE_SIN[i] = math.cos(a), math.sin(a)
	EYE_OUT[i], EYE_PUP[i] = {}, {}
end
local function DrawEye(cx, cy, w, h, col, pupilCol)
	local hw, hh = w * 0.5, h * 0.5
	local pr = math.min(hw, hh) * 0.5
	for i = 1, EYE_SEGS do
		local c, sn = EYE_COS[i], EYE_SIN[i]
		local po, pp = EYE_OUT[i], EYE_PUP[i]
		po.x, po.y = cx + c * hw, cy + sn * hh
		pp.x, pp.y = cx + c * pr * 0.95, cy + sn * pr
	end
	draw.NoTexture()
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(EYE_OUT)
	surface.SetDrawColor(pupilCol.r, pupilCol.g, pupilCol.b, pupilCol.a or 255)
	surface.DrawPoly(EYE_PUP)
end

-- Bouton « œil » posé sur une case / une carte : ouvre l'aperçu cosmétique (le lot
-- sur le perso du joueur, comme dans la boutique cosmétique).
local function MakeEyeButton(parent, def, tip)
	if not (def and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open) then return nil end
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b:SetTooltip(tip or "Aperçu sur ton perso")
	b:SetZPos(60)
	b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	b.Paint = function(s, w, h)
		-- Pas de plaque : juste l'œil, discret au repos, blanc franc et un peu plus
		-- grand au survol.
		local hf = EVO_UI.HoverFrac(s, 10)
		local sc = 0.66 + 0.14 * hf
		DrawEye(w / 2, h / 2, w * sc, h * sc, Color(235, 236, 240, 140 + 115 * hf), Color(12, 13, 17, 230))
	end
	b.DoClick = function()
		surface.PlaySound(SND_CLICK)
		LZY_SHOP_COSMETIC_PREVIEW.Open(def)
	end
	return b
end

-- ── Aperçus 3D (même moteur que l'inventaire et les coffres) ─────────────────
-- Le DModelPanel peut arriver PLUS TARD (file lazy-load) : on coupe son mouse
-- input dès qu'il existe, sinon il avale les clics.
local function DisableModelMouse(holder)
	holder.Think = function(s)
		local mp = s._modelPanel
		if IsValid(mp) then
			mp:SetMouseInputEnabled(false)
			s.Think = nil
		end
	end
end

local function MountModel(holder, def, fov)
	holder.Paint = function() end
	if not (def and isstring(def.model_path) and def.model_path ~= "") then return false end
	if not (LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel) then return false end
	LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, def, fov or 30)
	DisableModelMouse(holder)
	return true
end

local function LocalFaction()
	local lp = LocalPlayer()
	return IsValid(lp) and lp:GetEvoNWString("FactionName", "") or ""
end

-- Item d'une case cosmétique : FIXE (config), résolu par la faction du perso ; le
-- vrai item ITEMS (skin_id / gauntlet_id évitent le repli « rareté -> skin », cf.
-- cl_item_preview_model), sinon le modèle de repli de la config.
local function CellDef(cell)
	local id = SCRATCH_CONFIG.ResolveItem(cell, LocalFaction())
	local def = id and ITEMS and ITEMS[id]
	if def and isstring(def.model_path) and def.model_path ~= "" then return def end
	if isstring(cell.display_model) and cell.display_model ~= "" then
		return {
			name = cell.label, model_path = cell.display_model,
			skin_id = (cell.kind == "katana") and true or nil,
			gauntlet_id = (cell.kind == "hakuda") and true or nil,
		}
	end
	return nil
end

-- Mélange des cases (user 08/27) : les positions sont permutées entre cases de MÊME
-- forme (2x1 / 1x2 / 1x1), les cases `fixed` (gros lots) restent en place. Purement visuel et
-- local : le serveur tire par id, et l'INDEX i des cases est inchangé (c'est lui
-- que porte le cellIdx du résultat). Nouveau tirage à chaque ouverture du panneau.
local function ShuffledCells(tCells)
	local out, pools = {}, {}
	for i, c in ipairs(tCells) do
		out[i] = table.Copy(c)
		if not c.fixed then
			local key = c.w .. "x" .. c.h
			pools[key] = pools[key] or {}
			pools[key][#pools[key] + 1] = { x = c.x, y = c.y }
		end
	end
	for _, pool in pairs(pools) do
		for k = #pool, 2, -1 do
			local j = math.random(k)
			pool[k], pool[j] = pool[j], pool[k]
		end
	end
	local used = {}
	for _, c in ipairs(out) do
		if not c.fixed then
			local key = c.w .. "x" .. c.h
			used[key] = (used[key] or 0) + 1
			local pos = pools[key][used[key]]
			c.x, c.y = pos.x, pos.y
		end
	end
	return out
end

-- ============================================================================
-- Grille d'un onglet : UN panneau qui dessine les 20 cases, avec des enfants
-- porte-modèle pour le gros lot et les accessoires (positionnés dans PerformLayout).
-- ============================================================================
local GRID = {}

function GRID:Init()
	self._cells = {}
	self._rects = {}
	self._pcts = {}
	self._taken = {}
	self._holders = {}
	self._names = {}
	self._eyes = {}
	self._cur, self._win = -1, -1
	self._sCount, self._bDone = "", false
end

-- Cases prises : recalcule le compteur d'en-tête et le drapeau « grille terminée »
-- UNE fois au changement (jamais dans Paint, qui tourne à chaque frame).
function GRID:SetTaken(set)
	self._taken = set or {}
	local n = self:Remaining()
	self._bDone = (#self._cells > 0 and n == 0)
	self._sCount = self._bDone and "Grille terminée" or (n .. " / " .. #self._cells .. " cases restantes")
end

function GRID:Setup(tab)
	self._tab = tab
	self._cells = ShuffledCells(SCRATCH_CONFIG.Cells(tab.id))
	for i, c in ipairs(self._cells) do self._pcts[i] = SCRATCH_CONFIG.PctOf(tab.id, c) end
	for i, c in ipairs(self._cells) do
		local def = SCRATCH_CONFIG.IsCosmetic(c.kind) and CellDef(c) or nil
		if def then
			self._names[i] = def.name
			local holder = vgui.Create("DPanel", self)
			holder:SetMouseInputEnabled(false)
			holder.Paint = function() end
			self._holders[i] = holder
			MountModel(holder, def, 30)
			self._eyes[i] = MakeEyeButton(self, def)
		end
	end
	self:SetTaken(self._taken)
	self:InvalidateLayout(true)
end

function GRID:Remaining()
	local n = 0
	for _, c in ipairs(self._cells) do if not self._taken[c.id] then n = n + 1 end end
	return n
end

function GRID:PerformLayout(w, h)
	local cfg = SCRATCH_CONFIG.grid
	local PAD, GAP = gRespX(36), gRespX(16)
	local TOP, BOT = gRespY(104), gRespY(28)
	local cw = (w - PAD * 2 - GAP * (cfg.cols - 1)) / cfg.cols
	local ch = (h - TOP - BOT - GAP * (cfg.rows - 1)) / cfg.rows
	self._pad = PAD
	self._top, self._bot = TOP, BOT
	for i, c in ipairs(self._cells) do
		local r = self._rects[i] or {}
		r.x = PAD + c.x * (cw + GAP)
		r.y = TOP + c.y * (ch + GAP)
		r.w = c.w * cw + (c.w - 1) * GAP
		r.h = c.h * ch + (c.h - 1) * GAP
		self._rects[i] = r
		local holder = self._holders[i]
		if IsValid(holder) then
			if c.kind == "accessory" then
				-- Modèle CENTRÉ dans la case (user 08/27 : « trop à gauche »), étiquette
				-- en haut à côté de l'œil, nom de l'item en bas.
				local s = r.h - gRespY(44)
				holder:SetPos(r.x + (r.w - s) / 2, r.y + gRespY(24))
				holder:SetSize(s, s)
			else
				-- Gros lot : le modèle prend la case, bande de texte en bas.
				holder:SetPos(r.x + gRespX(10), r.y + gRespY(14))
				holder:SetSize(r.w - gRespX(20), r.h - gRespY(84))
			end
		end
		local eye = self._eyes[i]
		if IsValid(eye) then
			eye:SetPos(r.x + gRespX(8), r.y + gRespY(8))
			eye:SetSize(gRespX(34), gRespY(22))
		end
	end
end

-- Kan : MÊME taille que la pièce du battle pass (42 unités design, user 08/27),
-- quelle que soit la case ; les cases d'argent sont petites, donc l'icône ne
-- doit pas suivre leur taille.
local KAN_SIZE = 42
local function DrawYens(c, r, col, alpha)
	local horiz = r.w > r.h * 1.4
	local fLabel, fSub = "Avenir Next World:20", "Avenir Next World:15"
	local s = gRespY(KAN_SIZE)
	if horiz then
		local ix = r.x + gRespX(14)
		DrawMat(MoneyMat(), ix, r.y + r.h / 2 - s / 2, s, alpha)
		local tx = ix + s + gRespX(10)
		draw.SimpleText(c.label, fLabel, tx, r.y + r.h / 2 - gRespY(11), ColorAlpha(COL_TITLE, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(c.sub, fSub, tx, r.y + r.h / 2 + gRespY(12), ColorAlpha(col, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		local cx = r.x + r.w / 2
		DrawMat(MoneyMat(), cx - s / 2, r.y + r.h * 0.38 - s / 2, s, alpha)
		draw.SimpleText(c.label, fLabel, cx, r.y + r.h * 0.7, ColorAlpha(COL_TITLE, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(c.sub, fSub, cx, r.y + r.h * 0.7 + gRespY(20), ColorAlpha(col, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local function DrawReroll(c, r, col, alpha)
	local mat = REROLL_MAT[c.sub] or REROLL_MAT.art
	local s = math.min(r.w * 0.66, r.h * 0.42)
	local cx = r.x + r.w / 2
	DrawMat(mat, cx - s / 2, r.y + r.h * 0.34 - s / 2, s, alpha)
	draw.SimpleText(c.label, "Avenir Next World:18", cx, r.y + r.h * 0.66, ColorAlpha(COL_TITLE, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(c.sub2 or c.sub, "Avenir Next World:15", cx, r.y + r.h * 0.66 + gRespY(22), ColorAlpha(col, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function GRID:Paint(w, h)
	local pts = EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(18))
	EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 70))
	local PAD = self._pad or gRespX(36)

	-- En-tête : titre, sous-titre, compteur (les onglets sont posés par le panneau parent).
	draw.SimpleText("GRILLE DES LOTS", "Avenir Next World:30", PAD, gRespY(46), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText("Un tirage tourne sur la grille et s'arrête sur ton lot. Une case remportée reste grisée.",
		"Avenir Next World:16", PAD, gRespY(76), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText(self._sCount, "Avenir Next World:16",
		w - PAD, gRespY(82), self._bDone and ColorAlpha(COL_MUTED, 220) or ColorAlpha(COL_GOLD, 220), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	for i, c in ipairs(self._cells) do
		local r = self._rects[i]
		if r then
			local col = TierCol(c.tier)
			local taken = self._taken[c.id]
			local isCur, isWin = (i == self._cur), (i == self._win)
			local plate = isWin and Color(58, 48, 18, 250) or (isCur and Color(42, 44, 52, 250) or COL_CELL)
			EVO_UI.PaintCut(r.x, r.y, r.w, r.h, plate, gRespY(10))
			local alpha = taken and 70 or 255
			surface.SetDrawColor(col.r, col.g, col.b, taken and 60 or 230)
			surface.DrawRect(r.x + gRespX(10), r.y, r.w - gRespX(20), gRespY(3))
			draw.SimpleText(FmtPct(self._pcts[i] or 0), "Avenir Next World:15", r.x + r.w - gRespX(10), r.y + gRespY(13),
				ColorAlpha(COL_MUTED, taken and 90 or 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

			if c.kind == "yens" then
				DrawYens(c, r, col, alpha)
			elseif c.kind == "reroll" then
				DrawReroll(c, r, col, alpha)
			elseif c.kind == "accessory" then
				draw.SimpleText(c.label, "Avenir Next World:15", r.x + gRespX(50), r.y + gRespY(19), ColorAlpha(COL_MUTED, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(self._names[i] or c.sub, "Avenir Next World:15", r.x + r.w / 2, r.y + r.h - gRespY(12), ColorAlpha(col, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				local cx = r.x + r.w / 2
				draw.SimpleText(c.label, "Avenir Next World:30", cx, r.y + r.h - gRespY(50), ColorAlpha(COL_TITLE, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText((self._names[i] or c.sub) .. "  ·  gros lot", "Avenir Next World:15", cx, r.y + r.h - gRespY(24), ColorAlpha(col, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
end

-- Au-dessus des modèles 3D : voile des cases prises, contour de la case courante,
-- halo doré de la case gagnante.
function GRID:PaintOver(w, h)
	for i, c in ipairs(self._cells) do
		local r = self._rects[i]
		if r then
			if self._taken[c.id] and i ~= self._win then
				EVO_UI.PaintCut(r.x, r.y, r.w, r.h, Color(10, 11, 14, 205), gRespY(10))
				draw.SimpleText("DÉJÀ REMPORTÉ", "Avenir Next World:15", r.x + r.w / 2, r.y + r.h * 0.5,
					ColorAlpha(COL_MUTED, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			if i == self._cur then
				local pts = EVO_UI.PaintCut(r.x, r.y, r.w, r.h, Color(255, 255, 255, 14), gRespY(10))
				EVO_UI.OutlineCut(pts, Color(255, 255, 255, 230))
				EVO_UI.OutlineCut(pts, Color(255, 255, 255, 120))
			elseif i == self._win then
				local pulse = 0.5 + 0.5 * math.sin(SysTime() * 6)
				local pts = EVO_UI.PaintCut(r.x, r.y, r.w, r.h, ColorAlpha(COL_GOLD, 30 + 30 * pulse), gRespY(10))
				EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 255))
				EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 140 + 100 * pulse))
			end
		end
	end

	-- GRILLE TERMINÉE (user 08/27) : tout est remporté -> voile gris sur toutes les
	-- cases + mention, bouton verrouillé (le serveur refuse aussi tout tirage).
	if self._bDone and not self._roll then
		local PAD, TOP, BOT = self._pad or gRespX(36), self._top or gRespY(104), self._bot or gRespY(28)
		local x, y, gw, gh = PAD - gRespX(8), TOP - gRespY(8), w - PAD * 2 + gRespX(16), h - TOP - BOT + gRespY(16)
		local pts = EVO_UI.PaintCut(x, y, gw, gh, Color(8, 9, 12, 165), gRespY(12))
		EVO_UI.OutlineCut(pts, ColorAlpha(COL_MUTED, 90))
		local cx, cy = x + gw / 2, y + gh / 2
		draw.SimpleText("GRILLE TERMINÉE", "Bebas Neue:46", cx, cy - gRespY(16), ColorAlpha(COL_TITLE, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Tous les lots de cet onglet ont été remportés.", "Avenir Next World:17", cx, cy + gRespY(22), ColorAlpha(COL_MUTED, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

-- Roulement : ordre de visite aléatoire parmi les cases LIBRES, ~28 sauts,
-- intervalle croissant (ralentit), dernier saut = la case gagnante.
function GRID:StartRoll(target, onDone)
	local free = {}
	for k, c in ipairs(self._cells) do
		if not self._taken[c.id] or k == target then free[#free + 1] = k end
	end
	if #free == 0 then free[1] = target end
	local steps = math.min(28, 10 + #free * 2)
	local seq, times, last, t = {}, {}, -1, 0
	for s = 1, steps - 1 do
		local pick
		repeat pick = free[math.random(#free)] until #free <= 1 or pick ~= last
		seq[s] = pick
		last = pick
	end
	seq[steps] = target
	for s = 1, steps do
		local p = (s - 1) / math.max(1, steps - 1)
		t = t + 0.06 + (p ^ 2.6) * 0.42
		times[s] = t
	end
	self._win, self._cur = -1, -1
	self._roll = { seq = seq, times = times, i = 0, t0 = SysTime(), target = target, onDone = onDone }
end

function GRID:FinishRoll()
	local r = self._roll
	if not r then return end
	self._roll = nil
	self._cur = -1
	self._win = r.target
	if r.onDone then r.onDone() end
end

function GRID:Skip()
	if self._roll then self:FinishRoll() end
end

function GRID:Think()
	local r = self._roll
	if not r then return end
	local el = SysTime() - r.t0
	while r.i < #r.seq and el >= r.times[r.i + 1] do
		r.i = r.i + 1
		self._cur = r.seq[r.i]
		surface.PlaySound(SND_TICK)
	end
	if r.i >= #r.seq then self:FinishRoll() end
end

vgui.Register("LZY:Shop:TicketGrid", GRID, "DPanel")

-- ============================================================================
-- Panneau
-- ============================================================================
function PANEL:Init()
	-- Chargement paresseux des aperçus 3D (09/08) : même file que le reste de la boutique.
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_ticket", true, self)
	end
	_active = self
	self._pending = false
	self._rolling = false
	self._grids = {}

	-- Géométrie design 1840x905 : grille à gauche (1180x780), plaque à droite.
	local GX, GY, GW, GH = 40, 60, 1180, 780
	for _, tab in ipairs(SCRATCH_CONFIG.tabs) do
		local g = vgui.Create("LZY:Shop:TicketGrid", self)
		g:gSetPos(GX, GY)
		g:gSetSize(GW, GH)
		g:Setup(tab)
		g:SetVisible(false)
		self._grids[tab.id] = g
	end

	-- Onglets : bande AU-DESSUS de la grille (6 onglets depuis les tickets thématiques
	-- du 10/01 : ils ne tenaient plus dans l'en-tête), largeur partagée sur la grille.
	local th, gap = 40, 10
	local n = #SCRATCH_CONFIG.tabs
	local tw = math.min(200, (GW - (n - 1) * gap) / n)
	self._tabBtns = {}
	for i, tab in ipairs(SCRATCH_CONFIG.tabs) do
		local b = vgui.Create("DButton", self)
		b:gSetPos(GX + (i - 1) * (tw + gap), GY - th - 10)
		b:gSetSize(tw, th)
		b:SetText("")
		b:SetCursor("hand")
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local on = (self._tab == tab)
			local hf = EVO_UI.HoverFrac(s, 10)
			EVO_UI.PaintCut(0, 0, w, h, on and Color(COL_GOLD2.r, COL_GOLD2.g, COL_GOLD2.b, 235) or Color(24, 26, 32, 240), gRespY(8), "br")
			if not on then EVO_UI.PaintCut(0, 0, w, h, Color(255, 255, 255, 8 + 26 * hf), gRespY(8), "br") end
			draw.SimpleText(tab.label, "Avenir Next World:17", w / 2, h / 2, on and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			if self._rolling or self._pending or IsValid(self._ov) then return end
			surface.PlaySound(SND_CLICK)
			self:SetTab(tab.id)
		end
		self._tabBtns[i] = b
	end

	self:BuildPlate()
	self:SetTab(SCRATCH_CONFIG.tabs[1].id)

	-- État de MES grilles (cases déjà remportées) : demandé à l'ouverture, une fois.
	net.Start("server:lzy_shop.scratch_state")
	net.SendToServer()
end

function PANEL:Paint() end

function PANEL:OnRemove()
	if _active == self then _active = nil end
end

function PANEL:SetTab(id)
	local tab = SCRATCH_CONFIG.TabByID(id) or SCRATCH_CONFIG.tabs[1]
	self._tab = tab
	for tid, g in pairs(self._grids) do g:SetVisible(tid == tab.id) end
	local odds = SCRATCH_CONFIG.OddsSummary(tab.id, LocalFaction())
	local maxPct = 0
	-- Géométrie des lignes de la liste des lots (unités design) : les lignes des lots
	-- cosmétiques sont plus hautes, elles portent un petit aperçu 3D de l'item.
	local y = 378
	-- Tickets thématiques : 4 lots cosmétiques -> lignes resserrées pour tenir dans la plaque (780).
	local nBig = 0
	for _, o in ipairs(odds) do if o.item_id ~= nil then nBig = nBig + 1 end end
	local hBig, hSmall = (nBig > 3) and 50 or 60, (nBig > 3) and 34 or 38
	for _, o in ipairs(odds) do
		maxPct = math.max(maxPct, o.pct)
		o.big = (o.item_id ~= nil)
		o.h = o.big and hBig or hSmall
		o.y = y
		y = y + o.h
	end
	self._odds, self._maxPct = odds, math.max(1, maxPct)
	self:RefreshPlateModels()
end

-- Petits modèles 3D des lots cosmétiques (katana / gantelet / accessoires) dans la
-- liste des lots. Recréés à chaque changement d'onglet.
local PLATE_ICON_X, PLATE_ICON_SLOT, PLATE_MODEL = 32, 62, 52
function PANEL:RefreshPlateModels()
	for _, h in ipairs(self._plateModels or {}) do if IsValid(h) then h:Remove() end end
	self._plateModels = {}
	if not IsValid(self._plate) or not self._odds then return end
	for _, o in ipairs(self._odds) do
		local def = o.big and ITEMS and ITEMS[o.item_id]
		if def then
			local holder = vgui.Create("DPanel", self._plate)
			local sz = gRespY(PLATE_MODEL)
			holder:SetPos(gRespX(PLATE_ICON_X) + (gRespX(PLATE_ICON_SLOT) - sz) / 2, gRespY(o.y + o.h / 2 - 6 - PLATE_MODEL / 2))
			holder:SetSize(sz, sz)
			holder:SetMouseInputEnabled(false)
			MountModel(holder, def, 30)
			self._plateModels[#self._plateModels + 1] = holder
		end
	end
end

function PANEL:ApplyGrids(grids)
	for tid, g in pairs(self._grids) do
		local set = {}
		for _, id in ipairs(istable(grids) and istable(grids[tid]) and grids[tid] or {}) do set[tostring(id)] = true end
		g:SetTaken(set)
	end
end

-- ── Plaque de droite : prix, solde, boutons, liste des lots ─────────────────
function PANEL:BuildPlate()
	local px, py, pw, ph = 1260, 60, 540, 780
	local plate = vgui.Create("DPanel", self)
	plate:gSetPos(px, py)
	plate:gSetSize(pw, ph)
	plate.Paint = function(_, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(14))
		EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 70))
		surface.SetDrawColor(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 200)
		surface.DrawRect(gRespX(14), 0, w - gRespX(28), gRespY(3))
		local x = gRespX(32)
		draw.SimpleText("Ticket", "Avenir Next World:30", x, gRespY(52), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Un tirage, un lot. Grille vidée = grille remise à neuf.", "Avenir Next World:16", x, gRespY(86), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Prix + solde, deux colonnes bien séparées.
		local price = math.floor(tonumber(SCRATCH_CONFIG.price) or 1000)
		local bal = LocalPlayer():GetEvoNWInt("coins", 0)
		draw.SimpleText("Prix du tirage", "Avenir Next World:15", x, gRespY(146), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.Comma(price), "Avenir Next World:30", x, gRespY(180), COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Avenir Next World:30")
		local pwid = surface.GetTextSize(string.Comma(price))
		DrawMat(coinMat, x + pwid + gRespX(10), gRespY(180) - gRespY(12), gRespY(24))
		draw.SimpleText("Ton solde", "Avenir Next World:15", w - gRespX(32), gRespY(146), COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.Comma(bal), "Avenir Next World:30", w - gRespX(32), gRespY(180), bal >= price and COL_TITLE or ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		-- Liste des lots de l'onglet : icône, nom, part du tirage (barre) et taux.
		local tab = self._tab
		draw.SimpleText("Les lots de la grille  ·  " .. ((tab and tab.label) or ""), "Avenir Next World:15", x, gRespY(348), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(255, 255, 255, 18)
		surface.DrawRect(x, gRespY(364), w - x * 2, 1)
		local odds = self._odds
		if odds then
			local slot = gRespX(PLATE_ICON_SLOT)
			local isz = gRespY(30)
			local pctW = gRespX(64)
			for _, o in ipairs(odds) do
				local col = TierCol(o.tier)
				local y, rowH = gRespY(o.y), gRespY(o.h)
				local cy = y + rowH / 2 - gRespY(6)
				local ix = x + (slot - isz) / 2
				-- Icône du lot (le gros lot est un aperçu 3D enfant, cf. RefreshPlateModel).
				if o.kind == "yens" then
					DrawMat(MoneyMat(), ix, cy - isz / 2, isz)
				elseif o.kind == "reroll" then
					for k, sub in ipairs(o.subs) do
						DrawMat(REROLL_MAT[sub] or REROLL_MAT.art, x + (k - 1) * gRespX(21), cy - gRespY(10), gRespY(20))
					end
				elseif o.big then
					local ms = gRespY(PLATE_MODEL)
					local pts2 = EVO_UI.PaintCut(x + (slot - ms) / 2, cy - ms / 2, ms, ms, ColorAlpha(col, 22), gRespY(8), "br")
					EVO_UI.OutlineCut(pts2, ColorAlpha(col, 120))
				else
					EVO_UI.PaintCut(ix, cy - isz / 2, isz, isz, ColorAlpha(col, 40), gRespY(6), "br")
					local pts2 = EVO_UI.PaintCut(ix, cy - isz / 2, isz, isz, Color(0, 0, 0, 0), gRespY(6), "br")
					EVO_UI.OutlineCut(pts2, ColorAlpha(col, 200))
					draw.SimpleText("A", "Avenir Next World:17", ix + isz / 2, cy, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				local tx = x + slot + gRespX(14)
				draw.SimpleText(o.label, "Avenir Next World:17", tx, cy - gRespY(4), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(FmtPct(o.pct), "Avenir Next World:17", w - gRespX(32), cy - gRespY(4), col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				if o.cells > 1 then
					draw.SimpleText(o.cells .. " cases", "Avenir Next World:15", w - gRespX(32) - pctW, cy - gRespY(4), ColorAlpha(COL_MUTED, 180), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				-- Barre : part du tirage relative au lot le plus courant.
				local bx, bw = tx, w - gRespX(32) - tx
				local by = cy + gRespY(14)
				surface.SetDrawColor(255, 255, 255, 16)
				surface.DrawRect(bx, by, bw, gRespY(3))
				surface.SetDrawColor(col.r, col.g, col.b, 220)
				surface.DrawRect(bx, by, math.max(gRespX(4), bw * o.pct / self._maxPct), gRespY(3))
			end
		end
	end
	self._plate = plate

	-- Bouton TIRER.
	local buy = vgui.Create("DButton", plate)
	buy:gSetPos(32, 226)
	buy:gSetSize(pw - 64, 56)
	buy:SetText("")
	buy:SetCursor("hand")
	-- Animation (user 08/26) : reflet qui balaie la plaque en continu ; au survol, un
	-- « grattage » AUTOMATIQUE (des traits révèlent une couche plus claire de gauche
	-- à droite) et la plaque se soulève ; au clic, gerbe de paillettes. Piloté par
	-- SysTime, traits et paillettes figés à la création (0 alloc par frame).
	local strokes, flakes = {}, {}
	for i = 1, 26 do
		strokes[i] = { x = (i - 1) / 25, y = math.Rand(0.18, 0.82), len = math.Rand(0.05, 0.11), ang = math.Rand(-30, -12), th = math.Rand(2, 4) }
	end
	for i = 1, 22 do
		flakes[i] = { x = math.Rand(0.08, 0.92), vx = math.Rand(-60, 60), vy = math.Rand(-170, -70), r = math.Rand(0, 360), sz = math.Rand(3, 6) }
	end
	buy._hoverT, buy._burstT = -10, -10
	buy.Think = function(s)
		s:SetCursor(self:CanBuy() and "hand" or "arrow")
	end
	buy.OnCursorEntered = function(s)
		if not self:CanBuy() then return end
		surface.PlaySound(EVO_UI.SndHover)
		s._hoverT = SysTime()
	end
	buy.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac(s, 10)
		local price = math.floor(tonumber(SCRATCH_CONFIG.price) or 1000)
		local gCur = self._tab and self._grids[self._tab.id]
		local bDone = IsValid(gCur) and gCur._bDone == true
		local can = self:CanBuy()
		local t = SysTime()
		-- ENFONCEMENT (user 08/27) : tant que le bouton est MAINTENU, la plaque s'enfonce
		-- (rétrécit, s'assombrit, le texte descend) et revient en ressort au relâchement ;
		-- le clic déclenche alors l'onde + la gerbe. Lissé par frame, 0 alloc.
		s._press = Lerp(math.min(1, FrameTime() * 18), s._press or 0, (can and s:IsDown()) and 1 or 0)
		local press = s._press
		local grow = (can and hf * gRespY(3) or 0) - press * gRespY(4)
		local sx, sy = s:LocalToScreen(0, 0)
		DisableClipping(true)
		local base = can and Color(COL_GOLD2.r, COL_GOLD2.g, COL_GOLD2.b, 235) or Color(40, 40, 46, 235)
		local pts = EVO_UI.PaintCut(-grow, -grow, w + grow * 2, h + grow * 2, base, gRespY(10), "br")
		if press > 0.01 then
			EVO_UI.PaintCut(-grow, -grow, w + grow * 2, h + grow * 2, Color(0, 0, 0, 95 * press), gRespY(10), "br")
		end
		if can then
			-- Couche « grattée » révélée de gauche à droite (0.9 s après l'entrée du curseur).
			local rev = math.Clamp((t - s._hoverT) / 0.9, 0, 1) * hf
			if rev > 0.01 then
				render.SetScissorRect(sx - grow, sy - grow, sx + w * rev, sy + h + grow, true)
				EVO_UI.PaintCut(-grow, -grow, w + grow * 2, h + grow * 2, ColorAlpha(COL_GOLD, 150), gRespY(10), "br")
				render.SetScissorRect(0, 0, 0, 0, false)
				draw.NoTexture()
				surface.SetDrawColor(255, 244, 210, 170)
				for i = 1, #strokes do
					local st = strokes[i]
					if st.x > rev then break end
					surface.DrawTexturedRectRotated(st.x * w, st.y * h, st.len * w, gRespY(st.th), st.ang)
				end
			end
			-- Reflet qui balaie (cycle 2.6 s), clip à la plaque.
			local p = (t % 2.6) / 2.6
			if p < 0.45 then
				local px = (p / 0.45) * (w + gRespX(140)) - gRespX(70)
				render.SetScissorRect(sx - grow, sy - grow, sx + w + grow, sy + h + grow, true)
				draw.NoTexture()
				surface.SetDrawColor(255, 255, 255, 60)
				surface.DrawTexturedRectRotated(px, h / 2, gRespX(26), h * 2.4, 22)
				surface.SetDrawColor(255, 255, 255, 25)
				surface.DrawTexturedRectRotated(px + gRespX(30), h / 2, gRespX(10), h * 2.4, 22)
				render.SetScissorRect(0, 0, 0, 0, false)
			end
			EVO_UI.PaintCut(-grow, -grow, w + grow * 2, h + grow * 2, ColorAlpha(COL_GOLD, 25 + 50 * hf), gRespY(10), "br")
			local pulse = 0.5 + 0.5 * math.sin(t * 3)
			EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 110 + 110 * pulse))
		end
		-- Gerbe de paillettes au clic (0.8 s), au-dessus du bouton, précédée d'une ONDE :
		-- un liseré doré qui s'élargit hors de la plaque en s'effaçant (0.45 s).
		local bt = t - s._burstT
		if bt >= 0 and bt < 0.45 then
			local rp = bt / 0.45
			local ex = gRespX(4) + rp * gRespX(28)
			local rpts = EVO_UI.CutPoints(-ex, -ex, w + ex * 2, h + ex * 2, gRespY(10), "br")
			EVO_UI.OutlineCut(rpts, ColorAlpha(COL_GOLD, 210 * (1 - rp)))
			EVO_UI.OutlineCut(rpts, ColorAlpha(COL_GOLD, 120 * (1 - rp)))
		end
		if bt < 0.8 then
			draw.NoTexture()
			local a = 255 * (1 - bt / 0.8)
			for i = 1, #flakes do
				local f = flakes[i]
				local fx = f.x * w + gRespX(f.vx * bt)
				local fy = h / 2 + gRespY(f.vy * bt + 240 * bt * bt)
				surface.SetDrawColor(255, 225, 130, a)
				surface.DrawTexturedRectRotated(fx, fy, gRespX(f.sz), gRespY(f.sz), f.r + bt * 420)
			end
		end
		DisableClipping(false)
		local label = bDone and "Grille terminée" or (self._pending and "Tirage en cours…" or (self._rolling and "La grille tourne…" or ("Tirer un lot  ·  " .. string.Comma(price) .. " coins")))
		draw.SimpleText(label, "Avenir Next World:20", w / 2, h / 2 - grow * 0.3, can and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	buy.DoClick = function(s)
		if not self:CanBuy() then return end
		surface.PlaySound(SND_CLICK)
		s._burstT = SysTime()
		self:Buy()
	end
	self._buy = buy

	-- Passer l'animation.
	local skip = vgui.Create("DButton", plate)
	skip:gSetPos(32, 292)
	skip:gSetSize(pw - 64, 32)
	skip:SetText("")
	skip:SetCursor("hand")
	skip.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	skip.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac(s, 10)
		EVO_UI.PaintCut(0, 0, w, h, Color(22, 24, 30, 240), gRespY(8), "br")
		EVO_UI.PaintCut(0, 0, w, h, Color(255, 255, 255, 10 + 28 * hf), gRespY(8), "br")
		draw.SimpleText("Passer l'animation", "Avenir Next World:17", w / 2, h / 2, self._rolling and Color(220, 222, 228) or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	skip.DoClick = function()
		if not self._rolling then return end
		local g = self._tab and self._grids[self._tab.id]
		if IsValid(g) then g:Skip() end
	end
end

function PANEL:CanBuy()
	if self._pending or self._rolling or IsValid(self._ov) or not self._tab then return false end
	local gCur = self._grids[self._tab.id]
	if IsValid(gCur) and gCur._bDone then return false end
	local price = math.floor(tonumber(SCRATCH_CONFIG.price) or 1000)
	return LocalPlayer():GetEvoNWInt("coins", 0) >= price
end

function PANEL:Buy()
	if not self:CanBuy() then return end
	local price = math.floor(tonumber(SCRATCH_CONFIG.price) or 1000)
	if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then
		Notify("Pas assez de coins pour un tirage (" .. string.Comma(price) .. ").", true)
		return
	end
	self._pending = true
	net.Start("server:lzy_shop.scratch_buy")
		net.WriteString(self._tab.id)
	net.SendToServer()
	-- Failsafe : sans réponse serveur, on relâche le bouton au lieu de le figer.
	local serial = (self._serial or 0) + 1
	self._serial = serial
	timer.Simple(8, function()
		if IsValid(self) and self._serial == serial and self._pending then
			self._pending = false
		end
	end)
end

-- ── Écran de victoire : le lot EN GRAND AU CENTRE (modèle 3D / icône), nom, nature ──
function PANEL:ShowWin(tab, cell, kind, label, item_id)
	if IsValid(self._ov) then self._ov:Remove() end
	local col = TierCol(cell.tier)
	local def = (kind == "katana" or kind == "hakuda" or kind == "accessory") and ITEMS and ITEMS[item_id] or nil
	local sName, sSub
	if kind == "yens" then
		sName = cell.label .. " yens"
		sSub = "Versés sur ton personnage"
	elseif kind == "reroll" then
		sName = cell.label .. "  ·  " .. string.upper(cell.sub2 or cell.sub)
		sSub = "Ajoutés à ton compte"
	else
		sName = (def and def.name) or label
		local rar = def and isstring(def.rarity) and def.rarity or cell.tier
		sSub = string.upper(tostring(rar)) .. "  ·  ajouté à ton inventaire"
	end

	local ov = vgui.Create("DButton", self)
	ov:SetPos(0, 0)
	ov:SetSize(self:GetSize())
	ov:SetText("")
	ov:SetCursor("hand")
	ov:SetZPos(500)
	ov._t0 = SysTime()
	-- Confettis dorés (positions/vitesses figées à la création, 0 alloc par frame).
	local conf = {}
	local cCols = { COL_GOLD, Color(255, 255, 255), col, COL_GOLD2 }
	for i = 1, 40 do
		conf[i] = { x = math.Rand(0.05, 0.95), v = math.Rand(0.22, 0.5), ph = math.Rand(0, 6.28), rot = math.Rand(0, 360), c = cCols[(i % #cCols) + 1] }
	end
	local CW, CH = gRespX(540), gRespY(430) -- réduit (user 08/27 : « trop grosse »)
	local sTag = tab.label .. "  ·  case " .. FmtPct(SCRATCH_CONFIG.PctOf(tab.id, cell)) -- figé hors Paint
	ov.Paint = function(s, w, h)
		local t = SysTime() - s._t0
		local f = math.min(1, t / 0.25)
		surface.SetDrawColor(0, 0, 0, 215 * f)
		surface.DrawRect(0, 0, w, h)
		local cx, cy = w / 2, h / 2
		local x, y = cx - CW / 2, cy - CH / 2
		if t < 3.2 then
			draw.NoTexture()
			local fade = (t > 2.4) and (1 - (t - 2.4) / 0.8) or 1
			for _, p in ipairs(conf) do
				local py = -gRespY(20) + ((t * p.v) % 1.0) * (h + gRespY(40))
				local pxx = p.x * w + math.sin(t * 2.5 + p.ph) * gRespX(26)
				surface.SetDrawColor(p.c.r, p.c.g, p.c.b, 220 * fade)
				surface.DrawTexturedRectRotated(pxx, py, gRespX(8), gRespY(14), p.rot + t * 180)
			end
		end
		local pts = EVO_UI.PaintCut(x, y, CW, CH, Color(13, 14, 17, 250 * f), gRespY(16))
		EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 220 * f))
		EVO_UI.OutlineCut(pts, ColorAlpha(COL_GOLD, 120 * f))
		surface.SetDrawColor(col.r, col.g, col.b, 230 * f)
		surface.DrawRect(x + gRespX(16), y, CW - gRespX(32), gRespY(4))
		draw.SimpleText("LOT REMPORTÉ", "Avenir Next World:16", cx, y + gRespY(32), ColorAlpha(COL_GOLD, 255 * f), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sTag, "Avenir Next World:15", cx, y + gRespY(54), ColorAlpha(COL_MUTED, 255 * f), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sName, "Bebas Neue:40", cx, y + CH - gRespY(92), ColorAlpha(COL_TITLE, 255 * f), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sSub, "Avenir Next World:16", cx, y + CH - gRespY(62), ColorAlpha(col, 255 * f), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Cliquer pour continuer", "Avenir Next World:15", x + CW - gRespX(22), y + CH - gRespY(28), ColorAlpha(COL_MUTED, 255 * f), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	-- Le lot lui-même : modèle 3D (cosmétique) ou grande icône (yens / rerolls).
	local hs = gRespY(230)
	local holder = vgui.Create("DPanel", ov)
	holder:SetSize(hs, hs)
	holder:SetPos(math.floor(ov:GetWide() / 2 - hs / 2), math.floor(ov:GetTall() / 2 - CH / 2 + gRespY(72)))
	holder:SetMouseInputEnabled(false)
	if kind == "yens" then
		holder.Paint = function(_, w, h)
			local s = h * 0.62
			DrawMat(MoneyMat(), w / 2 - s / 2, h / 2 - s / 2, s)
		end
	elseif kind == "reroll" then
		holder.Paint = function(_, w, h)
			local s = h * 0.72
			DrawMat(REROLL_MAT[cell.sub] or REROLL_MAT.art, w / 2 - s / 2, h / 2 - s / 2, s)
		end
	else
		if not MountModel(holder, def or CellDef(cell), 26) then
			holder.Paint = function(_, w, h)
				draw.SimpleText(sName, "Bebas Neue:46", w / 2, h / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	if def and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open then
		local pv = vgui.Create("DButton", ov)
		pv:SetSize(gRespX(190), gRespY(32))
		pv:SetPos(math.floor(ov:GetWide() / 2 - CW / 2 + gRespX(22)), math.floor(ov:GetTall() / 2 + CH / 2 - gRespY(44)))
		pv:SetText("")
		pv:SetCursor("hand")
		pv.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		pv.Paint = function(s, w, h)
			local hf = EVO_UI.HoverFrac(s, 10)
			EVO_UI.PaintCut(0, 0, w, h, Color(22, 24, 30, 240), gRespY(8), "br")
			EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL_GOLD, 20 + 60 * hf), gRespY(8), "br")
			DrawEye(gRespX(22), h / 2, gRespX(18), gRespY(12), COL_TITLE, Color(22, 24, 30))
			draw.SimpleText("Voir sur mon perso", "Avenir Next World:15", gRespX(40), h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		pv.DoClick = function()
			surface.PlaySound(SND_CLICK)
			LZY_SHOP_COSMETIC_PREVIEW.Open(def)
		end
	end

	ov.DoClick = function()
		surface.PlaySound(SND_CLICK)
		ov:Remove()
		self._ov = nil
	end
	self._ov = ov
end

function PANEL:OnResult(ok, tabID, cellIdx, kind, label, item_id, bReset, grids)
	self._pending = false
	if not ok then return end
	local tab = SCRATCH_CONFIG.TabByID(tabID)
	local g = tab and self._grids[tab.id]
	if not IsValid(g) then return end
	local cell = g._cells[cellIdx]
	if not cell then return end
	if self._tab ~= tab then self:SetTab(tab.id) end
	if bReset then
		Notify("Grille " .. tab.label .. " complète : nouvelle grille de " .. #g._cells .. " cases.")
		g:SetTaken({})
	end
	-- Les autres onglets prennent l'état serveur tout de suite ; celui qui joue
	-- attend la fin du roulement (la case tombée se grise après le halo).
	for tid, other in pairs(self._grids) do
		if tid ~= tab.id then
			local set = {}
			for _, id in ipairs(istable(grids) and istable(grids[tid]) and grids[tid] or {}) do set[tostring(id)] = true end
			other:SetTaken(set)
		end
	end
	self._rollSerial = (self._rollSerial or 0) + 1
	local rollSerial = self._rollSerial
	self._rolling = true
	g:StartRoll(cellIdx, function()
		if not IsValid(self) or self._rollSerial ~= rollSerial then return end
		self._rolling = false
		surface.PlaySound(SND_GAIN)
		self:ShowWin(tab, cell, kind, label, item_id)
		timer.Simple(1.4, function()
			if not IsValid(g) then return end
			local set = {}
			for _, id in ipairs(istable(grids) and istable(grids[tab.id]) and grids[tab.id] or {}) do set[tostring(id)] = true end
			set[cell.id] = true
			g:SetTaken(set)
			g._win = -1
		end)
	end)
	-- Filet : si le roulement ne se termine jamais, on relâche CE tirage seulement.
	timer.Simple(12, function()
		if IsValid(self) and self._rollSerial == rollSerial then self._rolling = false end
	end)
end

net.Receive("server:lzy_shop.scratch_grid", function()
	local grids = util.JSONToTable(net.ReadString() or "{}") or {}
	if IsValid(_active) then _active:ApplyGrids(grids) end
end)

net.Receive("server:lzy_shop.scratch_result", function()
	local ok = net.ReadBool()
	local tabID = net.ReadString()
	local cellIdx = net.ReadUInt(6)
	local kind = net.ReadString()
	local label = net.ReadString()
	local item_id = net.ReadString()
	local bReset = net.ReadBool()
	local grids = util.JSONToTable(net.ReadString() or "{}") or {}
	if IsValid(_active) then _active:OnResult(ok, tabID, cellIdx, kind, label, item_id, bReset, grids) end
end)

vgui.Register("LZY:Shop:Ticket", PANEL, "DPanel")
