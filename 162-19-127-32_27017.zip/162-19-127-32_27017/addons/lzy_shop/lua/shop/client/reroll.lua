-- "addons\\lzy_shop\\lua\\shop\\client\\reroll.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Confirmation d'achat (demande user 2026-07-16) : popup "Confirmer l'achat ?" avant
-- d'envoyer l'achat au serveur (meme pattern que le night market).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_Reroll_Buy = function(args)
	if not args or not args.rtype or not args.index then return end
	net.Start("server:lzy_shop.reroll_buy")
		net.WriteString(tostring(args.rtype))
		net.WriteUInt(tonumber(args.index) or 0, 8)
	net.SendToServer()
end

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- ============================================================================
-- DA ATELIER (07/07, remplace le design "Valorant") :
-- Layer 1 = selection screen (4 grandes cards DHTML = PLAQUES de métal noir à
-- coins coupés + liseré acier + vis, image de catégorie en fond, titre Bebas +
-- entaille slash1)
-- Layer 2 = detail screen (grid de plaques 352x321, bar bottom count + prix
-- doré + coin, séparateur DENTÉ, gift/buy slide-up — ACHETER en accent rouge)
-- ============================================================================

-- Couleur unique neutre (gris clair) pour tous les encadres de l'onglet reroll.
-- Pas de differenciation par categorie / quantite -- DA sobre uniforme.
-- (signatures avec _ pour garder la compat des call sites qui passent un arg)
local NEUTRAL_BORDER = Color(180, 180, 190, 240)
local function GetCategoryColor(_) return NEUTRAL_BORDER end
local function GetRerollTierColor(_) return NEUTRAL_BORDER end

-- Entaille slash1 (signature Atelier) en masque CSS : data URI (CEF ne voit
-- pas les PNG workshop via asset://, même recette que questboard/selector).
local _slashUri
local function GetSlashMaskURI()
	if _slashUri ~= nil then return _slashUri end
	local raw = file.Read("materials/evo_ui/tex/slash1.png", "GAME")
	if raw and #raw > 0 and #raw < 150 * 1024 then
		_slashUri = "data:image/png;base64," .. string.gsub(util.Base64Encode(raw, true), "%s", "")
	else
		_slashUri = "asset://garrysmod/materials/evo_ui/tex/slash1.png" -- filet (fichier local)
	end
	return _slashUri
end

-- Coin image inline en base64.
local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- Material paths pour chaque categorie (utilises pour le BG des selection cards)
-- Icons 630x630 : etgmnxxbvsadh9/etgmnxxbvsadh9/{red,purple,blue,green}.png
local CATEGORY_MAT_PATH = {
	art_spirituel   = "etgmnxxbvsadh9/etgmnxxbvsadh9/red.png",
	combat_style    = "etgmnxxbvsadh9/etgmnxxbvsadh9/purple.png",
	style_execution = "etgmnxxbvsadh9/etgmnxxbvsadh9/blue.png",
	aura_spirituel  = "etgmnxxbvsadh9/etgmnxxbvsadh9/green.png",
	catalyseur      = "etgmnxxbvsadh9/etgmnxxbvsadh9/blue.png", -- provisoire (pas d'image dédiée)
}

-- ============================================================================
-- Template HTML/CSS (utilise pour selection ET detail cards).
-- 13 placeholders : 11 rgb + matURI + bodyHTML.
-- ============================================================================
local CARD_FRAME_HTML_REROLL = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
/* PAS de scale (fix 08/07 « fond noir bizarre ») : le scale au repos revelait la
   plaque de secours Lua en cadre sombre autour de la carte. La carte remplit
   maintenant EXACTEMENT son panneau ; le survol = voile clair + bordure rouge
   dessinee EN LUA (coins coupes propres). */
.wrap { position:relative; width:100%%; height:100%%; transition: -webkit-transform 0.12s ease-out; }
/* Survol « déplace un peu » (demande user 08/07, comme le menu Échap) : léger
   décalage haut-gauche. PAS de scale (évite le fond noir). */
body.hovered .wrap { -webkit-transform: translate(-4px, -4px); }
/* PLAQUE de métal noir Atelier : coins coupés 45°, arête claire en haut,
   liseré acier — remplace le cadre dégradé "Valorant" animé. */
.crate {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background:-webkit-linear-gradient(top, rgba(16,17,21,.97) 0%%, rgba(10,11,14,.99) 100%%);
	-webkit-clip-path:polygon(0 0, calc(100%% - 18px) 0, 100%% 18px, 100%% 100%%, 18px 100%%, 0 calc(100%% - 18px));
	/* DA dashboard 08/07 : plus de liseré acier */
	overflow:hidden; z-index:1;
}
.screw { position:absolute; width:12px; height:12px; border-radius:50%%; z-index:6;
	background:-webkit-radial-gradient(circle, #33373d 0%%, #17191d 70%%);
	box-shadow:0 0 0 1px rgba(0,0,0,.6); }
.screw i { position:absolute; top:44%%; left:12%%; width:76%%; height:12%%;
	background:rgba(0,0,0,.55); font-style:normal; -webkit-transform:rotate(38deg); }
/* Vis ALIGNEES (fix 08/07) : retrait UNIFORME 12px aux 4 coins (avant 9/26
   asymetrique = « pas alignes »). 12px degage les coins coupes 18px (diag 24>18). */
.sc1 { top:12px; left:12px; } .sc2 { top:12px; right:12px; }
.sc3 { bottom:12px; right:12px; } .sc4 { bottom:12px; left:12px; }
.reroll-bg {
	position:absolute; top:0; left:0; right:0; bottom:0;
	background-size: cover; background-position: center;
	z-index: 0;
	opacity: 0.85;
}
.reroll-bg::after {
	content:''; position:absolute; top:0; left:0; right:0; bottom:0;
	background: linear-gradient(to bottom, transparent 0%%, transparent 45%%, rgba(9,9,12,0.92) 82%%, rgba(9,9,12,1) 100%%);
}
/* (Scale au survol RETIRE — cf. .wrap. Bordure rouge du survol = EVO_UI.HoverOutline
   dessinee en Lua au-dessus du DHTML : elle suit les COINS COUPES, alors que le
   box-shadow inset etait rogne aux coins = « contour rouge pas terrible ».) */
/* Hover DA : simple voile clair (plus de glow radial coloré). */
.hover-veil {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: rgba(255,255,255,0.03);
	opacity: 0; transition: opacity 0.15s ease-out;
	pointer-events: none; z-index: 2;
}
body.hovered .hover-veil { opacity: 1; }

/* Bar bottom 50px : séparateur DENTÉ acier (plus de liseré dégradé). */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 50px;
	background: linear-gradient(to top, rgba(9,9,12,0.97) 0%%, rgba(9,9,12,0.6) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	/* Prix (droite) + nombre de rerolls (gauche) DECALES vers le centre (fix
	   08/07) : padding 34px pour ne plus passer SOUS les vis d'angle (12px). */
	padding: 0 34px;
	z-index: 5;
}
.bar::before {
	content: ''; position: absolute;
	top: 0; left: 16px; right: 16px;
	height: 0;
	border-top: 1px dashed rgba(146,152,161,0.35);
}
.bar-name {
	font-size: 26px;
	color: #ECECEC;
	font-weight: 400;
	letter-spacing: 3px;
	font-family: 'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 8px; }
.bar-old {
	font-size: 19px;
	color: rgba(255,255,255,0.45);
	text-decoration: line-through;
	text-decoration-color: rgba(207, 68, 78, 0.85);
	letter-spacing: 1px;
	font-weight: 400;
	font-family: 'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
}
.bar-discount {
	font-size: 19px;
	color: rgb(207, 68, 78);
	font-weight: 400;
	letter-spacing: 1px;
	font-family: 'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
}
.bar-price {
	font-size: 28px;
	color: rgb(232, 179, 75);
	font-weight: 400;
	letter-spacing: 1px;
	font-family: 'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
}
.bar-coin {
	width: 22px; height: 22px;
	image-rendering: -webkit-optimize-contrast;
}

/* Selection title centered au milieu (grandes cards de catégorie) :
   titre Bebas SANS bold + entaille slash1 teintée accent dessous. */
.sel-title {
	position: absolute;
	top: 50%%; left: 0; right: 0;
	transform: translateY(-50%%);
	text-align: center;
	z-index: 5;
	padding: 0 30px;
}
.sel-name {
	display: block;
	font-size: 56px;
	font-weight: 400;
	letter-spacing: 10px;
	color: #fff;
	text-shadow: 0 4px 22px rgba(0,0,0,0.95);
	font-family: 'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
}
.sel-slash {
	display:block; width:230px; height:13px; margin:8px auto 0 auto;
	background:#cf444e;
	-webkit-mask-image:url('%s');
	-webkit-mask-size:100%% 100%%; -webkit-mask-repeat:no-repeat;
}
.sel-hint {
	display: block;
	margin-top: 12px;
	font-size: 16px;
	font-weight: 600;
	color: rgba(255,255,255,0.55);
	letter-spacing: 4px;
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
	opacity: 0;
	transition: opacity 0.2s ease-out;
}
body.hovered .sel-hint { opacity: 1; }
</style></head>
<body>
	<div class="wrap">
		<div class="crate">
			<div class="reroll-bg" style="background-image: url('%s');"></div>
			<div class="hover-veil"></div>
			<div class="screw sc1"><i></i></div><div class="screw sc2"><i></i></div>
			<div class="screw sc3"><i></i></div><div class="screw sc4"><i></i></div>
			%s
		</div>
	</div>
</body></html>
]]

-- (l'arg `rgb` des anciens dégradés "Valorant" n'est plus utilisé — la plaque
-- Atelier est neutre ; signature conservée pour les call sites.)
local function BuildFrameHTML(_, matDataURI, innerHTML)
	return string.format(CARD_FRAME_HTML_REROLL,
		GetSlashMaskURI(), -- masque de l'entaille .sel-slash
		matDataURI,        -- background image URI
		innerHTML
	)
end

-- ============================================================================
-- LAYER 1 : SELECTION SCREEN (4 big categories cards)
-- Optimisation : on utilise asset:// (loader natif Chromium) pour les bg
-- images au lieu de base64. Le base64 decode bloquait le rendu 100-300ms,
-- asset:// lit le fichier direct du disque -- transition seamless.
-- ============================================================================

-- Pour les bg images des selection cards : asset:// URL (loader natif rapide).
-- Si CEF de cette version GMod ne supporte pas asset://, on fallback en base64.
local function GetMatPathFastURI(matPath)
	if not isstring(matPath) or matPath == "" then return "" end
	return "asset://garrysmod/materials/" .. matPath
end

function PANEL:CreateSelectionButton(displayName, matKey, x, y, soon, w, h)
	local W, H = w or 760, h or 370
	local borderCol = GetCategoryColor(matKey)
	local rgb       = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local matURI    = GetMatPathFastURI(CATEGORY_MAT_PATH[matKey] or "")

	-- Titre Bebas + entaille slash1 dessous (DA Atelier) + hint au survol.
	local innerHTML = string.format([[
<div class="sel-title">
	<span class="sel-name">%s</span>
	<span class="sel-hint">SELECTIONNER</span>
</div>
]], displayName)

	local btn = gPanel(x, y, W, H, self)
	btn:SetMouseInputEnabled(true)
	btn:SetCursor("hand")
	-- Paint fallback structuel : matche border 4px + dark inner. Si le DHTML
	-- met du temps a charger l'image (cas pire CEF lent), au moins la
	-- structure est visible immediatement.
	btn.Paint = function(_, w, h)
		-- Fallback structurel SOUS le DHTML : plaque SOMBRE à COINS COUPÉS (épouse
		-- le clip-path 18px du .crate). Fix 08/07 : avant, un rect BLANC CARRÉ
		-- derrière débordait aux coins coupés + au repos scale(0.99) = « un carré ».
		EVO_UI.PaintCut(0, 0, w, h, Color(11, 12, 16, 255), 18)
	end

	local frame = vgui.Create("DHTML", btn)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(BuildFrameHTML(rgb, matURI, innerHTML))
	btn._dhtmlFrame = frame

	-- Bordure rouge de survol dessinee EN LUA AU-DESSUS du DHTML (coins coupes
	-- propres, 18px = clip-path du .crate). Souris off -> laisse passer les clics.
	local topBorder = vgui.Create("DPanel", btn)
	topBorder:Dock(FILL)
	topBorder:SetMouseInputEnabled(false)
	topBorder:SetPaintBackground(false)
	topBorder.Paint = function(_, w, h)
		if btn._hovered then
			EVO_UI.HoverOutline(w, h, Color(207, 68, 78, 235), 18)
		end
	end

	btn.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
		end
	end

	btn.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if soon then
			MUGEN.Notify("Cette catégorie n'est pas encore disponible.")
			return
		end
		self:LoadRerollConfig(displayName, matKey)
	end

	table.insert(self.btn_list, btn)
end

function PANEL:CreateSelection()
	self.btn_list = {}

	-- Layout : 2x2 grid centre avec gaps reduits (cards proches).
	-- Panel parent (category_panel) : 1840 x 905. Cards : W=760 H=370.
	-- Gap H = 30, gap V = 30. Marges symetriques :
	--   H : (1840 - 2*760 - 30) / 2 = 145   -> TR x = 145+760+30 = 935
	--   V : (905  - 2*370 - 30) / 2 = 67.5 ~= 68 -> BL/BR y = 68+370+30 = 468
	-- Catalyseur en test (10/07) : sans lui, grille 2x2 d'origine.
	if not LocalPlayer():IsSuperAdmin() then
		self:CreateSelectionButton("ART SPIRITUEL",     "art_spirituel",   145, 68)
		self:CreateSelectionButton("STYLE DE COMBAT",   "combat_style",    935, 68)
		self:CreateSelectionButton("STYLE D'EXECUTION", "style_execution", 145, 468)
		self:CreateSelectionButton("AURA SPIRITUEL",    "aura_spirituel",  935, 468)
		return
	end
	-- 10/06 : 5 catégories -> 3 cartes en haut + 2 centrées en bas, cartes 560x420.
	-- H : (1840 - 3*560 - 2*30) / 2 = 50 ; bas centré : (1840 - 2*560 - 30) / 2 = 345.
	-- V : (905 - 2*420 - 30) / 2 = 17.5 ~= 18 -> 2e rangée y = 18 + 420 + 30 = 468.
	self:CreateSelectionButton("ART SPIRITUEL",     "art_spirituel",   50,   18,  nil, 560, 420)
	self:CreateSelectionButton("STYLE DE COMBAT",   "combat_style",    640,  18,  nil, 560, 420)
	self:CreateSelectionButton("STYLE D'EXECUTION", "style_execution", 1230, 18,  nil, 560, 420)
	self:CreateSelectionButton("AURA SPIRITUEL",    "aura_spirituel",  345,  468, nil, 560, 420)
	self:CreateSelectionButton("CATALYSEUR",        "catalyseur",      935,  468, nil, 560, 420)
end

-- ============================================================================
-- LAYER 2 : DETAIL SCREEN (grid of reroll quantity cards 352x321)
-- ============================================================================
function PANEL:CreateDetailCard(rerollCount, price, mat, rerollType, configIndex, x, y)
	local CARD_W, CARD_H = 352, 321
	local borderCol = GetRerollTierColor(rerollCount)
	local rgb       = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)

	-- Icone categorie (630x630) via asset:// — meme chemin que les selection cards.
	-- Evite GetName()..".png" (double extension) et le base64 de 8× gros PNG dans le HTML.
	local matURI = GetMatPathFastURI(CATEGORY_MAT_PATH[rerollType] or "")

	-- Discount calc
	local finalPrice, hasDiscount = GetDiscountedPrice(price)
	local discPct = hasDiscount and SHOP_CONFIG.CREATOR_CODE_DISCOUNT or 0

	-- Bar HTML : count + prix + coin.
	-- Pour les paliers a bonus, on affiche le detail "base + bonus" au lieu du
	-- total (ex: 22 -> "20 + 2"). Cosmetique : le total accorde reste identique.
	local REROLL_BONUS_DISPLAY = {
		[22]  = "20 + 2",
		[33]  = "30 + 3",
		[45]  = "40 + 5",
		[60]  = "50 + 10",
		[120] = "100 + 20",
	}
	local countLabel
	if REROLL_BONUS_DISPLAY[rerollCount] then
		countLabel = REROLL_BONUS_DISPLAY[rerollCount] .. " REROLLS"
	elseif rerollCount == 1 then
		countLabel = "1 REROLL"
	else
		countLabel = tostring(rerollCount) .. " REROLLS"
	end
	local barHTML
	if hasDiscount then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-old">%d</span>
		<span class="bar-discount">-%d%%</span>
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], countLabel, price, discPct, finalPrice, _COIN_DATA_URI)
	else
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], countLabel, price, _COIN_DATA_URI)
	end

	-- ========================================================================
	-- Background statique : porte le DHTML frame Valorant.
	-- ========================================================================
	local background = gPanel(x, y, CARD_W, CARD_H, self)
	-- Paint fallback structuel : matche la structure du DHTML (4px border +
	-- 4px inset dark) pour transition seamless quand le DHTML finit de parser.
	background.Paint = function(_, w, h)
		-- Fallback SOUS le DHTML : plaque sombre à coins coupés (épouse le
		-- clip-path 18px). Fix 08/07 : plus de rect blanc carré derrière.
		EVO_UI.PaintCut(0, 0, w, h, Color(11, 12, 16, 255), 18)
	end

	local frame = vgui.Create("DHTML", background)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(BuildFrameHTML(rgb, matURI, barHTML))
	background._dhtmlFrame = frame

	-- ========================================================================
	-- Container slide-up 50px pour reveal gift/buy. Hover via gui.MousePos.
	-- ========================================================================
	local container = gPanel(0, 0, CARD_W, CARD_H + 50, background)
	container:SetMouseInputEnabled(true)
	background._container = container

	container.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
			if inside then
				-- Affiche gift/buy au tout debut du slide-up
				if IsValid(background._gift) then background._gift:SetVisible(true) end
				if IsValid(background._buy)  then background._buy:SetVisible(true)  end
				selff:gMoveToY(-50, 0.2, 0, 4)
			else
				timer.Simple(0.05, function()
					if IsValid(selff) and not selff._hovered then
						selff:gMoveToY(0, 0.2, 0, 4)
					end
				end)
				-- Masque gift/buy une fois le slide-down anim termine pour ne pas
				-- les laisser visibles en idle (debordement de container 50px sous
				-- le card = barres parasites dans le gap entre rangees).
				timer.Simple(0.27, function()
					if IsValid(background) and not selff._hovered then
						if IsValid(background._gift) then background._gift:SetVisible(false) end
						if IsValid(background._buy)  then background._buy:SetVisible(false)  end
					end
				end)
			end
		end
	end
	container.Paint = function() end

	-- Bordure rouge de survol dessinee EN LUA AU-DESSUS du DHTML (coins coupes
	-- propres). STATIQUE sur la zone carte (le container, lui, glisse de 50px) ;
	-- lit container._hovered. Souris off -> ne vole pas les clics du container.
	local topBorder = vgui.Create("DPanel", background)
	topBorder:gSetPos(0, 0)
	topBorder:gSetSize(CARD_W, CARD_H)
	topBorder:SetMouseInputEnabled(false)
	topBorder:SetPaintBackground(false)
	topBorder.Paint = function(_, w, h)
		if IsValid(container) and container._hovered then
			EVO_UI.HoverOutline(w, h, Color(207, 68, 78, 235), 18)
		end
	end

	-- ========================================================================
	-- OFFRIR (gift)
	-- Cache par defaut : evite que le panel (positionne 50px sous le card)
	-- soit visible comme une "barre" dans le gap entre rangees en idle.
	-- Le container.Think les rend visible au hover, et les remasque apres le
	-- slide-down.
	-- ========================================================================
	local gift = gPanel(0, CARD_H, CARD_W / 2, 50, container)
	gift:SetVisible(false)
	background._gift = gift
	gift.opacity = 0.20
	gift:SetCursor("hand")
	gift.OnCursorEntered = function() gift.opacity = 0.40 end
	gift.OnCursorExited  = function() gift.opacity = 0.20 end
	gift.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		local giftPanel = vgui.Create("LZY:Shop:Gift", self:GetParent())
		giftPanel.giftType = "reroll"
		giftPanel.configIndex = configIndex
		giftPanel.rerollCategory = rerollType
	end
	gift.Paint = function(_, w, h)
		-- Style boutique IDENTIQUE aux cosmétiques (demande user 08/07) : aplat
		-- VERT plein, coin bas-GAUCHE coupé 18px (= épouse le coin coupé BL de la
		-- carte) + voile clair au survol + texte blanc Bebas.
		local base = (EVO_UI and EVO_UI.Col and EVO_UI.Col.green) or Color(78, 196, 128)
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(0, 0, w, h, base, 18, "bl")
			if pts and gift.opacity > 0.30 then
				draw.NoTexture()
				surface.SetDrawColor(255, 255, 255, 26)
				surface.DrawPoly(pts)
			end
		else
			rRect(0, 0, CARD_W / 2, 50, base)
		end
		rSimpleText("OFFRIR", "Bebas Neue:22", CARD_W / 4, 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- ========================================================================
	-- ACHETER (buy)
	-- Idem que gift : cache par defaut pour eviter la barre parasite sous la card.
	-- ========================================================================
	local buy = gPanel(CARD_W / 2, CARD_H, CARD_W / 2, 50, container)
	buy:SetVisible(false)
	background._buy = buy
	buy.opacity = 0.30
	buy:SetCursor("hand")
	buy.OnCursorEntered = function() buy.opacity = 0.50 end
	buy.OnCursorExited  = function() buy.opacity = 0.30 end
	buy.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		-- Pas assez de coins : LZY_Shop_CanAfford affiche la notif ; en plus, pour
		-- l'achat de rerolls, on redirige vers l'onglet Coins pour en acheter.
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then
			if LZY_Shop_OpenCoins then LZY_Shop_OpenCoins() end
			return
		end
		-- Confirmation avant achat (demande user) : l'achat part dans le callback popup.
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Confirmer l'achat de " .. rerollCount .. " reroll(s) ?", "LzyShop_Reroll_Buy", { rtype = rerollType, index = configIndex })
		end
	end
	buy.Paint = function(_, w, h)
		-- ACHETER « complet » (demande user 08/07) : rectangle PLEIN, PAS de coin
		-- coupé (le coin bas-droit de la carte est carré). Aplat accent rouge +
		-- voile clair au survol + texte blanc Bebas.
		rRect(0, 0, CARD_W / 2, 50, Color(207, 68, 78))
		if buy.opacity > 0.40 then
			rRect(0, 0, CARD_W / 2, 50, Color(255, 255, 255, 26))
		end
		rSimpleText("ACHETER", "Bebas Neue:22", CARD_W / 4, 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Bordure de survol AU-DESSUS des boutons (fix 08/07 : OFFRIR/ACHETER montent
	-- couvrir le bas de la carte et DÉPASSAIENT la bordure rouge). topBorder créé
	-- avant les boutons -> on le remonte au premier plan pour qu'il les encadre.
	if IsValid(topBorder) then topBorder:MoveToFront() end

	table.insert(self.btn_list, background)
end

function PANEL:LoadRerollConfig(name, rerollType)
	for _, btn in ipairs(self.btn_list) do
		if IsValid(btn) then btn:Remove() end
	end
	self.btn_list = {}

	-- Bouton retour : plaque Atelier (coin bas-droit coupé + liseré acier),
	-- flèche grise -> accent au survol (plus d'inversion noir/blanc).
	local back = gPanel(226 - 40, 60, 50, 50, self)
	back:SetMouseInputEnabled(true)
	back:SetCursor("hand")
	-- Paint fallback (au cas ou le DHTML met du temps a parser)
	back.Paint = function()
		-- DA dashboard 08/07 : plus de liseré acier
		rRect(0, 0, 50, 50, Color(13, 14, 17, 250))
	end

	local backHTML = vgui.Create("DHTML", back)
	backHTML:Dock(FILL)
	backHTML:SetMouseInputEnabled(false)
	backHTML:SetHTML([[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; background:transparent; }
.btn {
	width:100%; height:100%;
	display:flex; align-items:center; justify-content:center;
	background:#0d0e11;
	/* DA dashboard 08/07 : plus de liseré acier (bordure rouge au survol) */
	-webkit-clip-path:polygon(0 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%);
	color:#8A8A93;
	font-size:30px;
	font-weight:400;
	line-height:1;
	font-family:'Bebas Neue', 'Tungsten', 'Impact', sans-serif;
	transition: color 0.15s ease-out, box-shadow 0.15s ease-out, transform 0.15s ease-out;
	user-select:none;
}
body.hovered .btn {
	color:#cf444e;
	box-shadow:inset 0 0 0 1px rgba(207,68,78,.8);
	transform: scale(1.03);
}
</style></head>
<body>
	<div class="btn">&#10094;</div>
</body></html>
]])
	back._dhtmlFrame = backHTML

	-- Hover detection via Think (le DHTML capte le curseur sinon)
	back.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(backHTML) then
				backHTML:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
		end
	end

	back.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		for _, btn in ipairs(self.btn_list) do
			if IsValid(btn) then btn:Remove() end
		end
		self.btn_list = {}
		if IsValid(back) then back:Remove() end
		self:CreateSelection()
	end

	-- Title centered + entaille slash1 (DA Atelier). Panneau agrandi (40 -> 70)
	-- pour ne pas clipper l'entaille sous le titre.
	local title = gPanel(0, 50, 1840, 70, self)
	title:SetMouseInputEnabled(false)
	title.Paint = function()
		-- (Slash sous le titre RETIRÉ — demande user 08/07 : « enlève le slash en
		-- dessous du titre art spirituel… ».)
		rSimpleText(string.upper(name), "Bebas Neue:48", 1840 / 2, 20,
			color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	table.insert(self.btn_list, title)

	-- Grid of reroll quantity cards
	local x = 226 - 40
	local y = 145
	local catCfg = REROLL_CONFIG and REROLL_CONFIG[rerollType]
	if not catCfg or not catCfg.config then
		MUGEN.Notify("Configuration reroll introuvable pour cette catégorie.")
		return
	end
	for i, config in ipairs(catCfg.config) do
		local rerollCount = config[1]
		local price = config[2]
		local mat = config[3]

		self:CreateDetailCard(rerollCount, price, mat, rerollType, i, x, y)
		x = x + 370 + 20
		if i % 4 == 0 then
			x = 226 - 40
			y = y + 321 + 20
		end
	end
end

-- Libellés des catégories (mêmes que CreateSelection) pour la présélection ci-dessous.
local CATEGORY_DISPLAY_NAME = {
	art_spirituel   = "ART SPIRITUEL",
	combat_style    = "STYLE DE COMBAT",
	style_execution = "STYLE D'EXECUTION",
	aura_spirituel  = "AURA SPIRITUEL",
	catalyseur      = "CATALYSEUR",
}

function PANEL:Init()
	self:CreateSelection()
	-- Présélection (demande user 2026-07-16) : l'UI de reroll en jeu (plus de stock) et le
	-- Maître d'armes passent la catégorie via LZY_Shop_OpenRerollTab(cat) -> on saute
	-- directement sur la bonne page d'achat au lieu de l'écran de sélection. One-shot.
	local pre = LZY_Shop_RerollPreselect
	LZY_Shop_RerollPreselect = nil
	if pre and CATEGORY_DISPLAY_NAME[pre] then
		self:LoadRerollConfig(CATEGORY_DISPLAY_NAME[pre], pre)
	end
end

function PANEL:Paint() end

vgui.Register("LZY:Shop:Reroll", PANEL, "DPanel")
