-- "addons\\lzy_shop\\lua\\shop\\client\\main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Use the shared preview queue without changing this menu's framing.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

local PANEL = {}
local frame = nil
local can_open = true

-- ============================================================================
-- BOUTIQUE « ACCUEIL » — DA Atelier (plaques plates coins coupés + vis + image
-- dans le polygone + hover ressort/bordure accent + titre Bebas + slash). La DA
-- est CELLE du dashboard (validée), on GARDE le style ; seul l'AGENCEMENT change
-- (demande user 08/07 : moins « grille menu Échap ») -> grosse carte HÉROS
-- verticale à GAUCHE + COLONNE de catégories 2×3 à droite.
-- Clic carte -> PAGE CATÉGORIE existante (LZY:Shop:*) + bouton RETOUR.
-- FONCTIONNEL inchangé : OpenShop/SwitchToCategory/LZY_Shop_OpenCoins/
-- OpenRerollTab/CanAfford, gating TAMPON, encarts Coins + grade premium.
-- ============================================================================

local materials = {
	["coin"] = Material("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png"),
}

-- Logo serveur (même que le menu Échap) : centré en haut de l'accueil.
local logo = Material("materials/etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png", "smooth")

local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"

-- Palette DA.
local COL_ACCENT   = Color(207, 68, 78)     -- #cf444e
local COL_TITLE    = Color(238, 239, 243)
local COL_TITLE_RE = Color(222, 224, 230)
local COL_MUTED    = Color(150, 154, 162)
local COL_VIOLET   = Color(225, 165, 245)   -- identité Black Market (fonctionnelle)
local COL_VIOLET_B = Color(170, 80, 210)
local COL_GOLD     = Color(255, 205, 60)    -- identité EVO Coins (achat = doré, fonctionnel)
local COL_INK      = Color(236, 237, 241)   -- identité TICKET : accent blanc (user 08/26)
local COL_TEAL     = Color(46, 188, 148)    -- identité ENCHÈRES (teal, pas déjà pris)

-- Backgrounds 1..8 (chaîne png -> jpg -> sans extension), cache par numéro.
local bgCache = {}
local function bgMat(n)
	local m = bgCache[n]
	if m ~= nil then return m or nil end
	local base = "etgmnxxbvsadh9/etgmnxxbvsadh9/background" .. n
	m = Material(base .. ".png", "smooth")
	if m:IsError() then m = Material(base .. ".jpg", "smooth") end
	if m:IsError() then m = Material(base, "smooth") end
	bgCache[n] = (not m:IsError()) and m or false
	return bgCache[n] or nil
end

-- Image nommée du pack (ex. Black Market = bc10) : essaie .png PUIS .jpg PUIS .jpeg
-- (nos bc* sont livrés en .jpg), même dossier que les backgrounds ; nil si rien n'est monté.
local function namedMat(nm)
	local base = "etgmnxxbvsadh9/etgmnxxbvsadh9/" .. nm:gsub("%.%w+$", "")
	local m = Material(base .. ".png", "smooth")
	if m:IsError() then m = Material(base .. ".jpg", "smooth") end
	if m:IsError() then m = Material(base .. ".jpeg", "smooth") end
	return (not m:IsError()) and m or nil
end

-- PRECACHE des textures AU CHARGEMENT (cf. menu Echap) : Material() lit le disque de
-- facon SYNCHRONE -> la 1re ouverture chargeait ~10 textures d'un coup = gel. On les
-- charge une fois au load (invisible) ; l'engine met en cache, donc les Material() de
-- PANEL:Init deviennent instantanes. Idempotent.
do
	for n = 1, 8 do bgMat(n) end
	for _, nm in ipairs({ "bc13", "bc11", "bc14", "bc8", "bc10", "ticket_gratter" }) do namedMat(nm) end
end

-- Catégories annoncées mais pas encore ouvrables (carte grisée + « BIENTÔT »).
-- COFFRES suit COFFRES_CONFIG.enabled (shared) : un seul interrupteur pour
-- la tuile ET le refus serveur. Autres clés : reposer ici suffit à les voiler.
local SOON_CATS = {
	["LZY:Shop:Coffres"] = not (COFFRES_CONFIG and COFFRES_CONFIG.IsEnabled and COFFRES_CONFIG.IsEnabled()),
}

local function shopCatSoon(vguiName)
	return vguiName and SOON_CATS[vguiName]
end

local function shopCatLocked(vguiName)
	return shopCatSoon(vguiName) == true
end

-- ── PALIERS DE DÉPENSE (barre du bas de l'accueil, 08/19) ─────────────────────
-- Cumul des EVO Coins DÉPENSÉS par le compte (journal evo_coins_log, sync
-- lzy_shop.spend_sync) : un COSMÉTIQUE EXCLUSIF (faction + sexe, config
-- SHOP_CONFIG.SPEND_TIER_OUTFITS) par palier de 100 000, jusqu'à 600 000 (6 paliers depuis le 10/08).
-- Survol d'un médaillon = aperçu du cosmétique ; clic = récupération (serveur).
-- Look « DHTML » = VGUI + kit DA (règle projet), pas de page web.
local SPEND_MAX  = (SHOP_CONFIG and SHOP_CONFIG.SPEND_MAX) or 600000
local SPEND_STEP = (SHOP_CONFIG and SHOP_CONFIG.SPEND_STEP) or 100000

-- Teinte de TOUTE la barre (halo, filet, slash, cumul, jauge, losanges,
-- médaillons, aperçu) : 3 couleurs, un seul endroit à changer.
-- 08/19 : essai violet + socle image barre_boutique ABANDONNÉ (demande user
-- « reviens en arrière avec le truc en jaune ») -> retour à l'OR d'origine.
local COL_SBAR     = Color(255, 205, 60)       -- or clair (accent)
local COL_SBAR_B   = Color(196, 142, 26)       -- or profond (remplissage)
local COL_SBAR_TXT = Color(20, 16, 6, 255)     -- texte sombre sur or clair
local g_spent     = 0
local g_claimed   = 0   -- masque bits 1..N : paliers déjà récupérés
local SPEND_TIERS = math.floor(SPEND_MAX / SPEND_STEP) -- 10 ; = largeur du masque envoyé par le serveur
local g_lastCoins = -1  -- re-sync quand le solde bouge (achat boutique ouverte)
local g_nextReq   = 0

local function requestSpendSync()
	if SysTime() < g_nextReq then return end
	g_nextReq = SysTime() + 2
	net.Start("lzy_shop.spend_sync")
	net.SendToServer()
end

net.Receive("lzy_shop.spend_sync", function()
	g_spent   = net.ReadUInt(32)
	g_claimed = net.ReadUInt(SPEND_TIERS)
end)

local function tierClaimed(i)
	return bit.band(g_claimed, bit.lshift(1, i - 1)) ~= 0
end

-- "1234" -> "1 234" (séparateur de milliers, format FR).
local function fmtCoins(n)
	return (string.Comma(math.floor(n or 0)):gsub(",", " "))
end

local ROMANS_BTN = { "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X" }

-- Géométrie de la barre des paliers, en unités DESIGN (1920x1080). Partagée par
-- le dessin (PaintSpendBar) et les boutons-médaillons (PANEL:Init) : une seule
-- source, donc aucun décalage entre les deux.
local SBAR_W, SBAR_PAD = 1540, 30      -- plaque et marge interne
local SBAR_MED_W = 128                -- largeur des boutons de palier
local SBAR_TOP = 82                    -- haut de la piste dans la plaque
local SBAR_H   = 16                    -- épaisseur de la piste
local SBAR_BOT = 1076                  -- bas de la plaque (écran design)
local function spendBarGeom()
	local wD = SBAR_W
	-- Réserve une demi-largeur à droite pour centrer le dernier bouton sur son repère.
	local twD = wD - SBAR_PAD * 2 - SBAR_MED_W / 2
	local hD = SBAR_TOP + SBAR_H + 40  -- + place pour les montants sous la piste
	local yD = SBAR_BOT - hD
	local xD = (1920 - wD) / 2
	local txD = xD + SBAR_PAD
	return {
		x = xD, y = yD, w = wD, h = hD,
		tx = txD, ty = yD + SBAR_TOP, tw = twD, th = SBAR_H,
		medY = yD + SBAR_TOP - 34,     -- rangée des médaillons COSMÉTIQUE
	}
end

-- Peintre d'un BOUTON-MÉDAILLON « COSMÉTIQUE N » : verrouillé / prochain (pulse) /
-- récupérable (or pulsé, « RÉCUPÉRER » au survol) / récupérée (or plein).
local function paintSpendMedallion(s, w, h)
	local i = s._tier
	local nNeed = i * SPEND_STEP
	local bReached = g_spent >= nNeed
	local bClaimed = tierClaimed(i)
	local bNext = not bReached and (g_spent >= nNeed - SPEND_STEP)
	local pulse = 0.5 + 0.5 * math.sin(CurTime() * 3)
	local hf = (EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10)) or 0
	local sManual = SHOP_CONFIG.SPEND_TIER_MANUAL[i]
	local sTxt = sManual or ("COSMÉTIQUE " .. ROMANS_BTN[i])
	local sFont = "Bebas Neue:19"

	if bClaimed or (sManual and bReached) then
		EVO_UI.PaintCut(0, 0, w, h, COL_SBAR, gRespY(6), "br")
		draw.SimpleText(sTxt, sFont, w / 2, h / 2, COL_SBAR_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	elseif bReached then
		EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL_SBAR, 200 + 55 * math.max(pulse, hf)), gRespY(6), "br")
		surface.SetDrawColor(255, 255, 255, 90 + 120 * math.max(pulse * 0.6, hf))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(hf > 0.4 and "RÉCUPÉRER" or sTxt, "Bebas Neue:19", w / 2, h / 2, COL_SBAR_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	else
		EVO_UI.PaintCut(0, 0, w, h, Color(10, 11, 13, 225), gRespY(6), "br")
		local cTxt = (hf > 0.02 and ColorAlpha(COL_SBAR, 220))
			or (bNext and ColorAlpha(COL_SBAR, 150 + 90 * pulse))
			or COL_MUTED
		draw.SimpleText(sTxt, sFont, w / 2, h / 2, cTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if bNext or hf > 0.02 then
			surface.SetDrawColor(ColorAlpha(COL_SBAR, 60 + 80 * math.max(bNext and pulse or 0, hf)))
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
	end
end

local function closeSpendTip(panel)
	if IsValid(panel._spendTip) then panel._spendTip:Remove() end
	panel._spendTip = nil
end

-- Carte d'APERÇU au survol d'un médaillon : le cosmétique du palier pour MON perso
-- (faction + sexe), modèle 3D tournant si l'item est connu, état en pied.
local function openSpendTip(panel, btn)
	closeSpendTip(panel)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local i = btn._tier
	local sManual = SHOP_CONFIG.SPEND_TIER_MANUAL[i]
	local sItem = (SHOP_CONFIG.SpendTierOutfit and SHOP_CONFIG.SpendTierOutfit(lp, i)) or ""
	local tItem = (sItem ~= "" and ITEMS) and ITEMS[sItem] or nil
	local bReached = g_spent >= i * SPEND_STEP
	local bClaimed = tierClaimed(i)

	local twD, thD = 280, tItem and 380 or 150
	local mxD = math.Clamp(btn._pxD - twD / 2, 340, 1920 - 340 - twD)
	local tip = vgui.Create("DPanel", panel)
	panel._spendTip = tip
	tip:gSetPos(mxD, spendBarGeom().medY - thD - 12)
	tip:gSetSize(twD, thD)
	tip:SetMouseInputEnabled(false)
	tip:MoveToFront()

	local sState, cState
	if sManual then sState, cState = "Aucun item à récupérer pour ce palier.", COL_MUTED
	elseif bClaimed then sState, cState = "Récupéré : il est dans ton inventaire.", Color(78, 196, 128)
	elseif not tItem then sState, cState = "Cosmétique exclusif : bientôt dévoilé !", COL_MUTED
	elseif bReached then sState, cState = "Palier atteint : clique pour le récupérer !", COL_SBAR
	else sState, cState = "Atteins ce palier pour le débloquer.", COL_MUTED end
	local sHint = tItem and "Clic droit : essayer sur ton personnage" or nil

	tip.Paint = function(_, w, h)
		EVO_UI.PaintTooltip(0, 0, w, h)
		draw.SimpleText(sManual or ("COSMÉTIQUE " .. ROMANS_BTN[i]), "Bebas Neue:26", w / 2, gRespY(22), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Palier " .. fmtCoins(i * SPEND_STEP) .. " EVO Coins", "Avenir Next World:15", w / 2, gRespY(44), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if tItem and tItem.name then
			draw.SimpleText(tItem.name, "Bebas Neue:22", w / 2, h - gRespY(70), COL_SBAR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText(sState, "Avenir Next World:15", w / 2, h - gRespY(44), cState, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if sHint then
			draw.SimpleText(sHint, "Avenir Next World:14", w / 2, h - gRespY(20), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	if tItem and tItem.model_path then
		local mp = vgui.Create("DModelPanel", tip)
		mp:gSetPos(20, 58)
		mp:gSetSize(twD - 40, 210)
		mp:SetMouseInputEnabled(false)
		QueuePreviewModel(mp, function(mp)
			mp:SetModel(tItem.model_path)
			local ent = mp.Entity
			if IsValid(ent) then
				if tItem.skin then ent:SetSkin(tItem.skin) end
				local mn, mx2 = ent:GetRenderBounds()
				local c = (mn + mx2) / 2
				local size = math.max(mx2.x - mn.x, mx2.y - mn.y, mx2.z - mn.z, 1)
				mp:SetCamPos(c + Vector(size * 0.9, size * 0.9, size * 0.35))
				mp:SetLookAt(c)
				mp:SetFOV(42)
				mp.LayoutEntity = function(_, e) e:SetAngles(Angle(0, (RealTime() * 30) % 360, 0)) end
			end
		end)
	end
end

-- Aperçu du cosmétique SUR SON PERSONNAGE (même visionneuse que les cosmétiques :
-- bonemerge sur le modèle du joueur + anim idle). Marche à tout moment, même
-- palier non atteint : c'est la carotte. Retourne false si rien à montrer.
local function previewSpendTier(panel, i)
	if SHOP_CONFIG.SPEND_TIER_MANUAL[i] then return false end
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	local sItem = (SHOP_CONFIG.SpendTierOutfit and SHOP_CONFIG.SpendTierOutfit(lp, i)) or ""
	local tItem = (sItem ~= "" and ITEMS) and ITEMS[sItem] or nil
	if not (tItem and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open) then
		MUGEN.Notify("Ce cosmétique arrive bientôt !", NOTIFY_GENERIC, 4)
		return false
	end
	closeSpendTip(panel)
	LZY_SHOP_COSMETIC_PREVIEW.Open(tItem)
	return true
end

-- Clic sur un médaillon : refus expliqués côté client, le SERVEUR re-valide tout.
-- Palier PAS encore récupérable -> on ouvre l'APERÇU (plus utile qu'une notif
-- sèche : on veut voir ce qu'on va gagner). Clic droit = aperçu dans tous les cas.
local function clickSpendTier(panel, i)
	if SHOP_CONFIG.SPEND_TIER_MANUAL[i] then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if tierClaimed(i) then
		MUGEN.Notify("Cosmétique déjà récupéré.", NOTIFY_GENERIC, 3)
		previewSpendTier(panel, i)
		return
	end
	local nNeed = i * SPEND_STEP
	if g_spent < nNeed then
		MUGEN.Notify("Encore " .. fmtCoins(nNeed - g_spent) .. " EVO Coins dépensés pour débloquer ce palier.", NOTIFY_ERROR, 4)
		previewSpendTier(panel, i)
		return
	end
	if ((SHOP_CONFIG.SpendTierOutfit and SHOP_CONFIG.SpendTierOutfit(lp, i)) or "") == "" then
		MUGEN.Notify("Ce cosmétique arrive bientôt !", NOTIFY_GENERIC, 4)
		return
	end
	closeSpendTip(panel)
	net.Start("lzy_shop.spend_claim")
	net.WriteUInt(i, 4) -- = ReadUInt(4) serveur
	net.SendToServer()
end

local PREMIUM_NAMES = { [1] = "Premium", [2] = "VIP", [3] = "Platinum" }
local function getPremiumInfo()
	local ply = LocalPlayer()
	if not IsValid(ply) then return nil, 0 end
	local tier = ply:GetEvoNWInt("premium", 0)
	if tier <= 0 then return nil, 0 end
	local name = PREMIUM_NAMES[tier] or ("Grade " .. tier)
	local endDateStr = ply:GetEvoNWString("LZY_Shop_PremiumEndDate", "")
	if endDateStr == "" then return name, 0 end
	local year, month, day = endDateStr:match("(%d+)-(%d+)-(%d+)")
	if not year then return name, 0 end
	-- Le grade vaut jusqu'a la FIN de sa date : le serveur ne l'eteint que le lendemain
	-- (GradeDatePassed) et un abonnement se renouvelle le soir meme. Sans heure, os.time
	-- prend MIDI : l'encart affichait « Expire » des 12 h le dernier jour sur un grade
	-- encore actif, et des joueurs resiliaient ou tentaient de racheter pour rien.
	local endTime = os.time({ year = tonumber(year), month = tonumber(month), day = tonumber(day), hour = 23, min = 59, sec = 59 })
	local diff = endTime - os.time()
	if diff <= 0 then return name, 0 end
	return name, math.ceil(diff / 86400)
end

-- Découpe une description en lignes (largeur écran max).
local function wrapText(text, font, maxW)
	surface.SetFont(font)
	local lines, cur = {}, ""
	for word in string.gmatch(text or "", "%S+") do
		local try = cur == "" and word or (cur .. " " .. word)
		if select(1, surface.GetTextSize(try)) > maxW and cur ~= "" then
			lines[#lines + 1] = cur
			cur = word
		else
			cur = try
		end
	end
	if cur ~= "" then lines[#lines + 1] = cur end
	return lines
end

-- ── Peintre des cartes DA (recette dashboard : plaque plate + image polygone +
-- vis + hover ressort + bordure accent + titre Bebas + slash + CTA). GARDÉE ──
local function paintShopCard(s, w, h)
	local cd = s._cd
	local soon = shopCatSoon(cd.vgui)
	local blocked = shopCatLocked(cd.vgui)
	local hf = blocked and 0 or EVO_UI.HoverFrac(s, 10)

	-- Ressort au survol (NoClipping posé à la création).
	local grow = hf * gRespY(6)
	local gx = -grow - hf * gRespX(5)
	local gy = -grow - hf * gRespY(5)
	local gw, gh = w + grow * 2, h + grow * 2

	-- Halo éclairé DERRIÈRE la carte (demande user 08/07 : que la boutique
	-- RESSORTE). Ombre colorée douce dans l'accent (rouge ; doré EVO Coins ;
	-- violet Black Market), discrète au repos, plus forte au survol.
	if RNDX and RNDX.DrawShadows then
		local gacc = cd.accent or COL_ACCENT
		local glowA = (cd.featured and 55 or 28) + 75 * hf
		RNDX.DrawShadows(gRespY(16), gx, gy, gw, gh, ColorAlpha(gacc, glowA), gRespX(16) + gRespX(26) * hf)
	end

	local plate = hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 235)
	local pts = EVO_UI.PaintCut(gx, gy, gw, gh, plate, gRespY(14))

	-- Visuel : image dans le polygone de la plaque (UV par sommet) OU contain dézoomé.
	local img = cd.img
	if img and not img:IsError() then
		local iw, ih = img:Width(), img:Height()
		if iw > 0 and ih > 0 and cd.contain then
			-- Cadrage zoom (>1) + biais h/v MASQUÉ au POLYGONE de la plaque (coins
			-- coupés respectés en haut-droite / bas-gauche — plus de débordement
			-- rectangulaire dans les coins). Flou de calque optionnel (cd.blur).
			-- UV = position du sommet dans le rect zoomé de l'image.
			local sc = math.min(gw / iw, gh / ih) * (cd.zoom or 1)
			local rw, rh = iw * sc, ih * sc
			local rx = gx + (gw - rw) * (cd.hBias or 0.5)  -- hBias : 0 = côté gauche, 1 = côté droit
			local ry = gy + (gh - rh) * (cd.vBias or 0.5)
			local m = (cd.blur and EVO_UI.GhostBlurMat and EVO_UI.GhostBlurMat(img)) or img
			local ipts = {}
			for k, p in ipairs(pts) do
				ipts[k] = { x = p.x, y = p.y, u = (p.x - rx) / rw, v = (p.y - ry) / rh }
			end
			surface.SetMaterial(m)
			if cd.blur then
				-- Layer blur RENFORCÉ : GhostBlurMat + box-blur multi-passes (UV décalés,
				-- masque polygone FIXE -> coins coupés respectés). Alpha réparti par passe.
				local baseA = cd.imgAlpha or (cd.hero and 70 or 10)
				local off = 3.0
				local tapA = math.max(1, math.Round(baseA * 0.12))
				for _, t in ipairs({ {0,0},{off,0},{-off,0},{0,off},{0,-off},{off,off},{-off,off},{off,-off},{-off,-off} }) do
					local ip = {}
					for k, p in ipairs(pts) do
						ip[k] = { x = p.x, y = p.y, u = (p.x - rx + t[1]) / rw, v = (p.y - ry + t[2]) / rh }
					end
					surface.SetDrawColor(255, 255, 255, tapA)
					surface.DrawPoly(ip)
				end
			else
				surface.SetDrawColor(255, 255, 255, cd.imgAlpha or (cd.hero and 70 or 10))
				surface.DrawPoly(ipts)
			end
		elseif iw > 0 and ih > 0 then
			-- cd.rotPortrait : image livrée en PORTRAIT (ticket_gratter tel quel dans le pack,
			-- têtes à gauche) -> tournée de 90° horaire AU RENDU : dimensions échangées, puis
			-- UV pivotés (u, v) -> (v, 1 - u). Une image déjà en paysage passe telle quelle.
			local rot = cd.rotPortrait and ih > iw
			local ew, eh = iw, ih
			if rot then ew, eh = ih, iw end
			local sc = math.max(gw / ew, gh / eh)
			local sw2, sh2 = gw / (ew * sc), gh / (eh * sc)
			local u0 = (1 - sw2) * (cd.hBias or 0.5)  -- hBias : 0 = côté gauche, 1 = côté droit
			local v0 = (1 - sh2) * (cd.vBias or 0.5)
			local sharp = cd.hero or cd.sharp
			local m = sharp and img or ((EVO_UI.GhostBlurMat and EVO_UI.GhostBlurMat(img)) or img)
			local ipts = {}
			for k, p in ipairs(pts) do
				local u = u0 + ((p.x - gx) / gw) * sw2
				local v = v0 + ((p.y - gy) / gh) * sh2
				if rot then u, v = v, 1 - u end
				ipts[k] = { x = p.x, y = p.y, u = u, v = v }
			end
			surface.SetDrawColor(255, 255, 255, cd.imgAlpha or (cd.hero and 70 or 10))
			surface.SetMaterial(m)
			surface.DrawPoly(ipts)
		end
	end

	-- Liseré permanent (EVO Coins mis en avant).
	if cd.restOutline then
		EVO_UI.OutlineCut(pts, ColorAlpha(cd.accent or COL_ACCENT, 110 + 80 * hf))
	end

	-- Survol : voile clair + bordure accent extérieure.
	if hf > 0.02 then
		draw.NoTexture()
		surface.SetDrawColor(226, 230, 238, 10 * hf)
		surface.DrawPoly(pts)
		local bc = ColorAlpha(cd.accent or COL_ACCENT, 235 * hf)
		EVO_UI.OutlineCut(pts, bc)
		EVO_UI.OutlineCut(pts, bc)
	end

	-- Vis d'angle (retrait uniforme 16).
	local sr = gRespY(4)
	local mx, my = gRespX(16), gRespY(16)
	EVO_UI.Screw(gx + mx, gy + my, sr)
	EVO_UI.Screw(gx + gw - mx, gy + my, sr)
	EVO_UI.Screw(gx + gw - mx, gy + gh - my, sr)
	EVO_UI.Screw(gx + mx, gy + gh - my, sr)

	-- Titre Bebas + entaille slash1 + description.
	local tFont = cd.hero and "Bebas Neue:52" or "Bebas Neue:40"
	local tx = gRespX(24)
	local ty = cd.hero and (h - gRespY(112)) or gRespY(32)
	local ctitle = cd.titleCol or (hf > 0.01 and COL_TITLE or COL_TITLE_RE)
	draw.SimpleText(cd.title, tFont, tx, ty, ctitle, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont(tFont)
	local twT, thT = surface.GetTextSize(cd.title)
	local sy = ty + (cd.hero and gRespY(14) or gRespY(10))
	-- Titre CENTER-aligné vertical (Y = ty) -> haut du texte = ty - thT/2, donc
	-- slash à ty + thT*0.78 - thT/2 = ty + thT*0.28 (règle référence « BOUTIQUE »).
	local slashY = ty + thT * 0.28
	if not EVO_UI.Ink(EVO_UI.TexSlash, tx - gRespX(2), slashY, twT * 1.15, gRespY(9),
		ColorAlpha(cd.accent or COL_ACCENT, 245)) then
		surface.SetDrawColor(cd.accent or COL_ACCENT)
		surface.DrawRect(tx, ty + thT * 0.34, twT, math.max(2, gRespY(2)))
	end
	if cd._lines then
		local dy = sy + gRespY(18)
		for i, ln in ipairs(cd._lines) do
			draw.SimpleText(ln, "Avenir Next World:18", tx, dy + (i - 1) * gRespY(24),
				ColorAlpha(COL_MUTED, 235), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	-- Puce CTA (« OUVRIR » / « ACHETER » / « VOIR ») bas-gauche.
	if cd.cta and not blocked then
		local bw, bh = gRespX(110), gRespY(36)
		local bx, by = gRespX(24), h - bh - gRespY(20)
		if hf > 0.3 then
			EVO_UI.PaintCut(bx, by, bw, bh, ColorAlpha(cd.accent or COL_ACCENT, 235), gRespY(8), "br")
			-- cd.ctaTextCol : accent clair (TICKET blanc) -> texte sombre, sinon il disparaîtrait.
			draw.SimpleText(cd.cta, "Bebas Neue:22", bx + bw / 2, by + bh / 2, cd.ctaTextCol or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			EVO_UI.PaintCut(bx, by, bw, bh, Color(10, 11, 13, 200), gRespY(8), "br")
			draw.SimpleText(cd.cta, "Bebas Neue:22", bx + bw / 2, by + bh / 2, ColorAlpha(cd.accent or COL_ACCENT, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Catégorie verrouillée : voile + mention (bientôt, ou TAMPON).
	if blocked then
		draw.NoTexture()
		surface.SetDrawColor(8, 8, 11, 188)
		surface.DrawPoly(pts)
		draw.SimpleText(soon and "BIENTÔT" or "INDISPONIBLE DANS LA FILE",
			soon and "Bebas Neue:34" or "Bebas Neue:24", w / 2, h / 2,
			ColorAlpha(COL_MUTED, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Bandeau en biais dans le coin haut-droit (cd.ribbon, ex. « NEW », user 08/26).
	-- Rotation autour du pivot en coordonnées ÉCRAN (les surfaces VGUI sont décalées
	-- par la position du panneau avant la matrice) ; clip au rectangle de la carte
	-- (NoClipping est posé sur la carte, sinon le ruban dépasserait des coins).
	-- Dessiné APRÈS le voile « BIENTÔT » : sous lui, le ruban virait au gris.
	if cd.ribbon then
		local sx, sy = s:LocalToScreen(0, 0)
		local rx, ry = gx + gw - gRespX(30), gy + gRespY(30)
		local rw, rh = gRespX(180), gRespY(24)
		local m = Matrix()
		m:Translate(Vector(sx + rx, sy + ry, 0))
		m:Rotate(Angle(0, 45, 0))
		m:Translate(Vector(-(sx + rx), -(sy + ry), 0))
		render.SetScissorRect(sx + gx, sy + gy, sx + gx + gw, sy + gy + gh, true)
		cam.PushModelMatrix(m)
			draw.NoTexture()
			-- SURBRILLANCE ANIMÉE (user 08/27) : halo pulsé derrière le ruban + reflet
			-- qui le balaie (cycle 2,2 s), borné à sa largeur. Tout est calé sur SysTime,
			-- rien d'alloué par image.
			local t = SysTime()
			local pulse = 0.5 + 0.5 * math.sin(t * 3.2)
			local acc = cd.accent or COL_ACCENT
			surface.SetDrawColor(acc.r, acc.g, acc.b, 70 + 90 * pulse)
			surface.DrawRect(rx - rw / 2 - gRespX(3), ry - rh / 2 - gRespY(3), rw + gRespX(6), rh + gRespY(6))
			surface.SetDrawColor(acc)
			surface.DrawRect(rx - rw / 2, ry - rh / 2, rw, rh)
			local p = (t % 2.2) / 2.2
			if p < 0.55 then
				local x0, x1 = rx - rw / 2, rx + rw / 2
				local sw = gRespX(22)
				local sx = x0 - sw + (p / 0.55) * (rw + sw * 2)
				local a0, a1 = math.max(x0, sx - sw), math.min(x1, sx + sw)
				if a1 > a0 then
					surface.SetDrawColor(255, 255, 255, 70)
					surface.DrawRect(a0, ry - rh / 2, a1 - a0, rh)
				end
				local b0, b1 = math.max(x0, sx - sw * 0.35), math.min(x1, sx + sw * 0.35)
				if b1 > b0 then
					surface.SetDrawColor(255, 255, 255, 150)
					surface.DrawRect(b0, ry - rh / 2, b1 - b0, rh)
				end
			end
			surface.SetDrawColor(255, 255, 255, 60 + 80 * pulse)
			surface.DrawRect(rx - rw / 2, ry - rh / 2, rw, math.max(1, gRespY(1)))
			draw.SimpleText(cd.ribbon, "Bebas Neue:22", rx, ry, Color(24, 18, 6), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.PopModelMatrix()
		render.SetScissorRect(0, 0, 0, 0, false)
	end
end

-- Fabrique une carte de l'accueil.
function PANEL:MakeHomeCard(cd)
	local b = vgui.Create("DButton", self)
	b:NoClipping(true)
	b:gSetPos(cd.x, cd.y)
	b:gSetSize(cd.w, cd.h)
	b:SetText("")
	b._cd = cd
	if cd.desc then
		cd._lines = wrapText(cd.desc, "Avenir Next World:18", gRespX(cd.w - 60))
	end
	local blockedNow = shopCatLocked(cd.vgui)
	b:SetCursor(blockedNow and "no" or "hand")
	b.OnCursorEntered = function()
		if not shopCatLocked(cd.vgui) then
			surface.PlaySound(EVO_UI.SndHover)
		end
	end
	b.DoClick = function()
		surface.PlaySound(SND_CLICK)
		if shopCatSoon(cd.vgui) then
			MUGEN.Notify("Cette catégorie n'est pas encore disponible.", NOTIFY_ERROR, 3)
			return
		end
		self:OpenCategory(cd.vgui)
	end
	b.Paint = paintShopCard
	self._homeCards[#self._homeCards + 1] = b
	if cd.vgui then
		self._catTitles = self._catTitles or {}
		self._catTitles[cd.vgui] = { text = cd.title, col = cd.titleCol, accent = cd.accent }
	end
	return b
end

-- ── Navigation accueil <-> page catégorie ────────────────────────────────────
function PANEL:ShowHome()
	if IsValid(self.current_category) then self.current_category:Remove() end
	self.current_category = nil
	self._curCatName = nil
	self._titleInfo = nil
	for _, c in ipairs(self._homeCards) do
		if IsValid(c) then c:SetVisible(true) end
	end
	if IsValid(self.backBtn) then self.backBtn:SetVisible(false) end
end

function PANEL:OpenCategory(vguiName)
	if not vguiName then return end
	if shopCatSoon(vguiName) then return end
	if self._curCatName == vguiName and IsValid(self.current_category) then return end

	for _, c in ipairs(self._homeCards) do
		if IsValid(c) then c:SetVisible(false) end
	end
	closeSpendTip(self) -- l'aperçu du cosmétique ne doit pas survivre à la mosaïque
	if IsValid(self.current_category) then self.current_category:Remove() end

	local category_panel = vgui.Create(vguiName, self)
	category_panel:gSetPos(40, 110)
	-- Les coffres utilisent la marge basse pour leur bouton de recyclage.
	category_panel:gSetSize(1840, vguiName == "LZY:Shop:Coffres" and 950 or 905)
	self.current_category = category_panel
	self._curCatName = vguiName
	self._titleInfo = self._catTitles and self._catTitles[vguiName] or nil

	if IsValid(self.backBtn) then
		self.backBtn:SetVisible(true)
		self.backBtn:MoveToFront()
	end
end

function PANEL:SwitchToCategory(vguiName)
	self:OpenCategory(vguiName)
	return self._curCatName == vguiName
end

function PANEL:Init()
	openedFrame = self
	self:gSetPos(0, 0)
	self:gSetSize(1920, 1080)
	self:Center()
	self:MakePopup()
	self:SetDraggable(false)
	self:SetTitle("")
	self:ShowCloseButton(false)

	self._homeCards = {}
	self.current_category = nil
	self._curCatName = nil

	-- Barre des paliers : cumul demandé à l'ouverture, jauge animée depuis 0,
	-- et un BOUTON-MÉDAILLON par palier (survol = aperçu du cosmétique, clic =
	-- récupération). Géométrie = MIROIR du dessin de PaintSpendBar (design 1920).
	self._spendFrac = 0
	g_nextReq = 0
	requestSpendSync()
	local G = spendBarGeom()
	for i = 1, SPEND_TIERS do
		local pxD = G.tx + G.tw * (i / SPEND_TIERS)
		-- Chaque bouton reste centré sur son repère, avec au moins 12 px d'écart.
		local nMedW = math.min(SBAR_MED_W, math.floor(G.tw / SPEND_TIERS) - 12)
		local mxD = pxD - nMedW / 2
		local b = vgui.Create("DButton", self)
		b:gSetPos(mxD, G.medY)
		b:gSetSize(nMedW, 24)
		b:SetText("")
		b:SetCursor(SHOP_CONFIG.SPEND_TIER_MANUAL[i] and "arrow" or "hand")
		b._tier = i
		b._pxD = mxD + nMedW / 2
		b.Paint = paintSpendMedallion
		b.OnCursorEntered = function(s)
			surface.PlaySound(EVO_UI.SndHover)
			openSpendTip(self, s)
		end
		b.OnCursorExited = function() closeSpendTip(self) end
		b.DoClick = function(s)
			surface.PlaySound(SND_CLICK)
			clickSpendTier(self, s._tier)
		end
		-- Clic droit : aperçu du cosmétique sur son perso, quel que soit l'état
		-- (même un cosmétique déjà récupéré ou un palier encore loin).
		b.DoRightClick = function(s)
			surface.PlaySound(SND_CLICK)
			previewSpendTier(self, s._tier)
		end
		-- Dans la liste des cartes d'accueil : masqué/réaffiché avec la mosaïque.
		self._homeCards[#self._homeCards + 1] = b
	end

	-- ── AGENCEMENT « MOSAÏQUE ASYMÉTRIQUE » (choix user 08/07, DA gardée) :
	-- tailles VARIÉES, aucune grille régulière. REROLL à gauche (raccourci pour
	-- caler ENCHÈRES dessous), STARTER/GRADES en blocs moyens en haut-droite,
	-- COSMÉTIQUES et BLACK MARKET en colonnes hautes à droite.
	-- Positions/tailles en design 1920x1080.
	local promoPct = LZY_Shop_CosmetiquePromoPct()
	local cards = {
		-- HÉROS : REROLL, à gauche — hauteur réduite pour ENCHÈRES en dessous
		-- (560+20+120 = 700, même bas qu'avant / que COFFRES).
		{ x = 60, y = 130, w = 720, h = 560, title = "REROLL", cta = "OUVRIR", hero = true,
			contain = true, zoom = 1.15, vBias = 0.5, hBias = 0.72, imgAlpha = 45,
			desc = "Packs de rerolls et de resets — tente ta chance.",
			img = 2, imgName = "bc13.jpg", vgui = "LZY:Shop:Reroll" },
		{ x = 60, y = 710, w = 720, h = 120, title = "ENCHÈRES", cta = "OUVRIR",
			accent = COL_TEAL, sharp = true, imgAlpha = 40,
			desc = "Lots du vendredi — enchéris tes EVO Coins.",
			img = 3, imgName = "bc14.jpg", vgui = "LZY:Shop:Encheres" },
		-- Haut-droite : STARTER PACK + TICKET empilés (le bloc 505x330 d'origine coupé en
		-- deux, user 08/26 : le héros REROLL reste intact), GRADES à côté.
		{ x = 800, y = 130, w = 505, h = 150, title = "STARTER PACK", cta = "OUVRIR", accent = Color(64, 67, 75),
			contain = true, zoom = 1.4, hBias = 0.5, vBias = 0.35, imgAlpha = 45, desc = "Le pack de départ du serveur.",
			img = 1, vgui = "LZY:Shop:Pack" },
		-- TICKET / grille des lots (1000 coins le tirage) : accent blanc comme
		-- avant, bordure au survol comme REROLL (plus de liseré permanent).
		{ x = 800, y = 300, w = 505, h = 160, title = "TICKET À GRATTER", cta = "TIRER", ribbon = "NEW",
			accent = COL_INK, ctaTextCol = Color(14, 14, 17), sharp = true, imgAlpha = 55, vBias = 0.2,
			rotPortrait = true,
			desc = "1000 coins le tirage : la grille tourne et s'arrête sur ton lot.",
			img = 3, imgName = "ticket_gratter.jpeg", vgui = "LZY:Shop:Ticket" },
		-- Colonne droite du haut (user 08/26) : EVO COINS puis GRADES (moitié de sa
		-- hauteur d'origine), tous deux en cadrage cover (une carte courte en contain
		-- ferait flotter l'image).
		{ x = 1325, y = 130, w = 535, h = 150, title = "EVO COINS", cta = "ACHETER",
			titleCol = COL_GOLD, accent = COL_GOLD, restOutline = true, sharp = true, imgAlpha = 40,
			desc = "Recharge tes EVO Coins.", img = 3, imgName = "bc14.jpg", vgui = "LZY:Shop:Coins" },
		{ x = 1325, y = 300, w = 535, h = 160, title = "GRADES", sharp = true, hBias = 0.3, vBias = 0.05, imgAlpha = 45,
			desc = "Les grades premium du serveur.", img = 2, imgName = "bc11.png", vgui = "LZY:Shop:Grades" },
		-- COFFRES : toute la colonne (ex-EVO COINS + COFFRES). Voilée tant que
		-- COFFRES_CONFIG.enabled est false (SOON_CATS + refus serveur).
		{ x = 800, y = 480, w = 350, h = 350, title = "COFFRES", --[[ ribbon = "NEW", ]]
			desc = "Coffres à cosmétiques.", img = 6, vgui = "LZY:Shop:Coffres" },
		-- Cosmétiques : même taille que Black Market (colonne haute).
		-- Ruban promo : même bandeau que « NEW », retiré quand promo_pct vaut 0.
		{ x = 1170, y = 480, w = 330, h = 350, title = "COSMÉTIQUES", accent = Color(178, 210, 248),
			contain = true, zoom = 1.4, vBias = 0.5,
			ribbon = (promoPct > 0) and ("-" .. promoPct .. "%") or nil,
			desc = "Skins et cosmétiques.", img = 7, imgName = "bc8.png", vgui = "LZY:Shop:Cosmetiques" },
		-- Black Market : colonne haute à droite. Même ruban promo que Cosmétiques.
		{ x = 1530, y = 480, w = 330, h = 350, title = "BLACK MARKET",
			titleCol = COL_VIOLET, accent = COL_VIOLET_B,
			ribbon = (promoPct > 0) and ("-" .. promoPct .. "%") or nil,
			desc = "Offres en rotation.",
			img = 8, imgName = "bc10.png", vgui = "LZY:Shop:BlackMarket" },
	}
	-- Agrandit LÉGÈREMENT toutes les cases (demande user 08/07) : mise à l'échelle
	-- douce autour du centre de la mosaïque, un peu plus marquée en vertical (place
	-- dispo) qu'en horizontal (la mosaïque remplit déjà la largeur).
	local PVX, PVY = 960, 480
	local SCX, SCY = 1.02, 1.05
	for _, cd in ipairs(cards) do
		cd.w, cd.h = cd.w * SCX, cd.h * SCY
		cd.x = PVX + (cd.x - PVX) * SCX
		cd.y = PVY + (cd.y - PVY) * SCY
	end
	-- Recentre verticalement le bloc sur l'écran sans passer sous le logo/en-tête.
	local top, bot = math.huge, -math.huge
	for _, cd in ipairs(cards) do
		top, bot = math.min(top, cd.y), math.max(bot, cd.y + cd.h)
	end
	local YOFF = math.max((1080 - (bot - top)) * 0.5, 186) - top
	for _, cd in ipairs(cards) do
		cd.y = cd.y + YOFF
		cd.cta = cd.cta or "VOIR"
		if cd.imgName then
			-- Image nommée (namedMat) ; repli sur l'image numérotée si rien n'est monté.
			cd.img = namedMat(cd.imgName) or bgMat(cd.img)
		else
			cd.img = bgMat(cd.img)
		end
		self:MakeHomeCard(cd)
	end

	-- ── Bouton RETOUR (DA) ──────────────────────────────────────────────────
	local back = vgui.Create("DButton", self)
	self.backBtn = back
	back:gSetPos(40, 40)
	back:gSetSize(190, 60)
	back:SetText("")
	back:SetCursor("hand")
	back:SetVisible(false)
	back.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	back.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac(s, 10)
		EVO_UI.PaintCut(0, 0, w, h, hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 220), gRespY(10), "br")
		local cx, cy = gRespX(28), h / 2
		local a = gRespY(8)
		draw.NoTexture()
		surface.SetDrawColor(ColorAlpha(COL_ACCENT, 235))
		surface.DrawPoly({
			{ x = cx - a, y = cy }, { x = cx + a * 0.7, y = cy - a }, { x = cx + a * 0.7, y = cy + a },
		})
		draw.SimpleText("ACCUEIL", "Bebas Neue:26", gRespX(48), cy,
			hf > 0.02 and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	back.DoClick = function()
		surface.PlaySound(SND_CLICK)
		self:ShowHome()
	end

	-- ── Croix de fermeture ───────────────────────────────────────────────────
	local close_btn = gPanel(1920 - 70, 40, 30, 30, self)
	close_btn.opacity = 1
	close_btn.OnCursorEntered = function() close_btn:SetCursor("hand") close_btn.opacity = 0.5 end
	close_btn.OnCursorExited  = function() close_btn:SetCursor("arrow") close_btn.opacity = 1 end
	close_btn.OnMousePressed  = function() surface.PlaySound(SND_CLICK) self:Close() end
	close_btn.Paint = function(_, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			close_btn.opacity < 1 and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	self:ShowCosmetiquePromo()
end

-- Annonce de la promo cosmétiques, une fois par session client (survit à la
-- fermeture de la boutique, pas à une reconnexion). Absente quand promo_pct vaut 0.
LZY_Shop_PromoPopupSeen = LZY_Shop_PromoPopupSeen or false
function PANEL:CloseCosmetiquePromo()
	if IsValid(self._promoPopup) then self._promoPopup:Remove() end
	self._promoPopup = nil
end

function PANEL:ShowCosmetiquePromo()
	local pct = LZY_Shop_CosmetiquePromoPct()
	if pct <= 0 or LZY_Shop_PromoPopupSeen or IsValid(self._promoPopup) then return end
	LZY_Shop_PromoPopupSeen = true

	local root = vgui.Create("DButton", self)
	self._promoPopup = root
	root:gSetPos(0, 0)
	root:gSetSize(1920, 1080)
	root:SetText("")
	root:SetCursor("arrow")
	root.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 168)
		surface.DrawRect(0, 0, w, h)
	end
	root.DoClick = function()
		self:CloseCosmetiquePromo()
	end

	local cw, ch = 620, 340
	local card = vgui.Create("DButton", root)
	card:gSetSize(cw, ch)
	card:gSetPos((1920 - cw) / 2, (1080 - ch) / 2)
	card:SetText("")
	card:SetCursor("arrow")
	card.DoClick = function() end
	card.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 252), gRespY(14), "br")
		else
			surface.SetDrawColor(13, 14, 17, 252)
			surface.DrawRect(0, 0, w, h)
		end
		surface.SetDrawColor(COL_GOLD)
		surface.DrawRect(gRespX(36), gRespY(32), gRespX(52), math.max(2, gRespY(3)))
		draw.SimpleText("PROMO", "Bebas Neue:22", gRespX(36), gRespY(44), COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("-" .. pct .. "%", "Bebas Neue:86", w / 2, gRespY(128), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("SUR TOUTES LES COSMÉTIQUES", "Bebas Neue:28", w / 2, gRespY(186), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Boutique cosmétiques et Black Market.", "Avenir Next World:18", w / 2, gRespY(222), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local ok = vgui.Create("DButton", card)
	ok:gSetSize(220, 46)
	ok:gSetPos((cw - 220) / 2, ch - 46 - 28)
	ok:SetText("")
	ok:SetCursor("hand")
	ok.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	ok.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac) and EVO_UI.HoverFrac(s, 10) or 0
		local col = ColorAlpha(COL_ACCENT, hf > 0.3 and 255 or 225)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, col, gRespY(8), "br")
		else
			surface.SetDrawColor(col)
			surface.DrawRect(0, 0, w, h)
		end
		draw.SimpleText("COMPRIS", "Bebas Neue:24", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ok.DoClick = function()
		surface.PlaySound(SND_CLICK)
		self:CloseCosmetiquePromo()
	end

	-- OpenShop peut ouvrir une catégorie juste après Init : le voile repasse devant.
	timer.Simple(0, function()
		if IsValid(root) then root:MoveToFront() end
	end)
end

function PANEL:Paint()
	-- Fond DA (même recette que le menu Échap) : blur + voile sombre.
	local w, h = self:GetWide(), self:GetTall()
	if RNDX and RNDX.BLUR and RNDX.Draw then
		RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
	end
	surface.SetDrawColor(5, 5, 7, 242)
	surface.DrawRect(0, 0, w, h)

	-- Ambiance : grand halo central doux derrière la boutique (que ça ressorte).
	if RNDX and RNDX.DrawShadows then
		RNDX.DrawShadows(gRespY(220), w * 0.5 - gRespX(420), gRespY(220), gRespX(840), gRespY(560),
			Color(120, 62, 70, 24), gRespX(190))
	end

	-- En-tête : sur l'ACCUEIL, LOGO serveur CENTRÉ (comme le menu Échap) +
	-- « BOUTIQUE » en gros à gauche (top-droite = les coins -> on équilibre à
	-- gauche). DANS une catégorie : son NOM centré + entaille slash.
	local ti = self._titleInfo
	if ti then
		local cAccent = ti.accent or COL_ACCENT
		rSimpleText(ti.text, "Bebas Neue:46", 960, 58, ti.col or COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:46")
		local twT, thT = surface.GetTextSize(ti.text)
		if not EVO_UI.Ink(EVO_UI.TexSlash, gRespX(960) - twT * 0.575, gRespY(58) + thT * 0.28, twT * 1.15, gRespY(9), ColorAlpha(cAccent, 245)) then
			surface.SetDrawColor(cAccent)
			surface.DrawRect(gRespX(960) - twT * 0.5, gRespY(58) + thT * 0.34, twT, math.max(2, gRespY(2)))
		end
	else
		-- Logo serveur centré (agrandi — retour user 08/07).
		if logo and not logo:IsError() then
			local lw, lh = logo:Width(), logo:Height()
			local dh = gRespY(160)
			local dw = (lw > 0 and lh > 0) and dh * (lw / lh) or dh
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(logo)
			surface.DrawTexturedRect(gRespX(960) - dw / 2, gRespY(4), dw, dh)
		end
		-- « BOUTIQUE » en GROS à gauche + entaille slash COLLÉE juste sous le mot.
		local bx, by = gRespX(66), gRespY(46)
		surface.SetFont("Bebas Neue:86")
		local tw, th = surface.GetTextSize("BOUTIQUE")
		draw.SimpleText("BOUTIQUE", "Bebas Neue:86", bx, by, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if not EVO_UI.Ink(EVO_UI.TexSlash, bx - gRespX(2), by + th * 0.78, tw * 1.08, gRespY(15), ColorAlpha(COL_ACCENT, 245)) then
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(bx, by + th * 0.84, tw, math.max(2, gRespY(2)))
		end
	end

	local ply = LocalPlayer()

	-- Encart EVO Coins (mini-plaque DA).
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(gRespX(1641), gRespY(40), gRespX(159), gRespY(60), Color(13, 14, 17, 220), gRespY(10), "br")
	else
		rRect(1641, 40, 159, 60, Color(16, 16, 16, 200), 0)
	end
	rMaterials(materials["coin"], 1749, 49, 42, 42)
	rSimpleText("EVO Coins", "Bebas Neue:20", 1641 + 100, 40 + 8, Color(255, 255, 255, 90), TEXT_ALIGN_RIGHT)
	rSimpleText(ply:GetEvoNWInt("coins", 0), "Bebas Neue:24", 1641 + 100, 40 + 28, Color(255, 255, 255), TEXT_ALIGN_RIGHT)

	-- Encart grade premium.
	local gradeName, daysLeft = getPremiumInfo()
	if gradeName then
		local boxX, boxW, boxH, boxY = 1540, 96, 60, 40
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(gRespX(boxX), gRespY(boxY), gRespX(boxW), gRespY(boxH), Color(13, 14, 17, 220), gRespY(10), "br")
		else
			rRect(boxX, boxY, boxW, boxH, Color(16, 16, 16, 200), 0)
		end
		local color = daysLeft > 0 and Color(255, 215, 0) or Color(180, 180, 180)
		rSimpleText(gradeName, "Bebas Neue:21", boxX + boxW / 2, boxY + boxH / 2, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		rSimpleText(daysLeft > 0 and (daysLeft .. " jour" .. (daysLeft > 1 and "s" or "")) or "Expiré",
			"Bebas Neue:18", boxX + boxW / 2, boxY + boxH / 2,
			daysLeft > 0 and Color(255, 255, 255, 200) or Color(255, 80, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Barre des paliers de dépense : sur l'ACCUEIL uniquement (sous la mosaïque).
	if not self._titleInfo then
		self:PaintSpendBar()
	end
end

-- ── Barre des PALIERS DE DÉPENSE (bas de l'accueil) — VERSION RICHE (08/19) ──
-- « Abuse de la beauté » (demande user) : halo doré derrière la plaque, filet
-- doré fondu en tête, titre Bebas + entaille slash, jauge en dégradé avec reflet,
-- BALAYAGE BRILLANT animé, étincelle pulsée en pointe, médaillons COSMÉTIQUE I à IV
-- au-dessus de chaque palier. Toujours 100 % VGUI + kit DA (notre « DHTML »).
local MAT_GRAD_R = Material("vgui/gradient-r")
local MAT_GRAD_U = Material("vgui/gradient-u")
local COL_BAR_PLATE = Color(13, 14, 17, 242)
local COL_BAR_TRACK = Color(23, 24, 29, 235)
local COL_BAR_LOCK  = Color(70, 72, 80, 255)
local COL_SHINE     = Color(255, 255, 255, 70)

function PANEL:PaintSpendBar()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	-- Un achat vient d'être fait boutique ouverte : le solde bouge -> re-sync.
	local nCoins = ply:GetEvoNWInt("coins", 0)
	if nCoins ~= g_lastCoins then
		g_lastCoins = nCoins
		requestSpendSync()
	end

	local now = CurTime()
	local frac = math.Clamp(g_spent / SPEND_MAX, 0, 1)
	self._spendFrac = Lerp(math.min(FrameTime() * 5, 1), self._spendFrac or 0, frac)
	local bFull = g_spent >= SPEND_MAX

	-- ── Plaque (design 1920x1080, sous la mosaïque) + halo violet derrière. ──
	-- Géométrie PARTAGÉE avec les boutons-médaillons (spendBarGeom) : la hauteur
	-- de la plaque suit celle du socle, qui suit le ratio natif de l'image.
	local G = spendBarGeom()
	local X, Y = gRespX(G.x), gRespY(G.y)
	local W, H = gRespX(G.w), gRespY(G.h)
	if RNDX and RNDX.DrawShadows then
		local glowA = (bFull and 52 or 30) + 12 * (0.5 + 0.5 * math.sin(now * 1.4))
		RNDX.DrawShadows(gRespY(16), X, Y, W, H, ColorAlpha(COL_SBAR_B, glowA), gRespX(28))
	end
	EVO_UI.PaintCut(X, Y, W, H, COL_BAR_PLATE, gRespY(14), "br")
	-- Filet violet en tête de plaque, fondu vers les bords.
	surface.SetDrawColor(ColorAlpha(COL_SBAR, 110))
	surface.SetMaterial(MAT_GRAD_R)
	surface.DrawTexturedRect(X + W * 0.05, Y, W * 0.45, math.max(1, gRespY(2)))
	surface.DrawTexturedRectUV(X + W * 0.5, Y, W * 0.45, math.max(1, gRespY(2)), 1, 0, 0, 1)
	local sr = gRespY(4)
	EVO_UI.Screw(X + gRespX(16), Y + gRespY(16), sr)
	EVO_UI.Screw(X + W - gRespX(16), Y + gRespY(16), sr)
	EVO_UI.Screw(X + W - gRespX(16), Y + H - gRespY(16), sr)
	EVO_UI.Screw(X + gRespX(16), Y + H - gRespY(16), sr)

	-- ── Titre + entaille slash (recette des cartes) + explication + cumul. ──
	local hx, hy = X + gRespX(30), Y + gRespY(20)
	draw.SimpleText("COSMÉTIQUES EXCLUSIFS", "Bebas Neue:32", hx, hy, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:32")
	local twT, thT = surface.GetTextSize("COSMÉTIQUES EXCLUSIFS")
	if not EVO_UI.Ink(EVO_UI.TexSlash, hx - gRespX(2), hy + thT * 0.28, twT * 1.15, gRespY(8), ColorAlpha(COL_SBAR, 235)) then
		surface.SetDrawColor(COL_SBAR)
		surface.DrawRect(hx, hy + thT * 0.34, twT, math.max(2, gRespY(2)))
	end
	draw.SimpleText("Une récompense exclusive à chaque palier de " .. fmtCoins(SPEND_STEP) .. " EVO Coins dépensés",
		"Avenir Next World:16", X + W * 0.5 + gRespX(30), hy, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	-- Cumul à droite, pièce EVO Coins devant.
	local sTotal = fmtCoins(math.min(g_spent, SPEND_MAX)) .. " / " .. fmtCoins(SPEND_MAX)
	surface.SetFont("Bebas Neue:28")
	local twS = surface.GetTextSize(sTotal)
	draw.SimpleText(sTotal, "Bebas Neue:28", X + W - gRespX(30), hy, COL_SBAR, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	local ci = gRespY(26)
	surface.SetDrawColor(255, 255, 255, 255)
	surface.SetMaterial(materials["coin"])
	surface.DrawTexturedRect(X + W - gRespX(30) - twS - ci - gRespX(8), hy - ci / 2, ci, ci)

	-- ── Jauge : piste creusée + remplissage doré dégradé + reflet + balayage. ──
	local TX, TY = gRespX(G.tx), gRespY(G.ty)
	local TW, TH = gRespX(G.tw), gRespY(G.th)
	local r = gRespY(8)
	local FX, FY, FWmax, FH = TX, TY, TW, TH

	if RNDX and RNDX.Draw then
		RNDX.Draw(r, TX, TY, TW, TH, COL_BAR_TRACK)
		if RNDX.DrawOutlined then RNDX.DrawOutlined(r, TX, TY, TW, TH, Color(255, 255, 255, 14), 1) end
	else
		surface.SetDrawColor(COL_BAR_TRACK) surface.DrawRect(TX, TY, TW, TH)
	end

	local fillW = math.max(FH, FWmax * self._spendFrac)
	if self._spendFrac > 0.004 then
		render.SetScissorRect(FX, FY, FX + fillW, FY + FH, true)
		-- Base or profond -> or clair (gradient horizontal), assombri en pied
		-- (relief), fine ligne claire en crête (reflet).
		if RNDX and RNDX.Draw then RNDX.Draw(r, FX, FY, fillW, FH, COL_SBAR_B)
		else surface.SetDrawColor(COL_SBAR_B) surface.DrawRect(FX, FY, fillW, FH) end
		surface.SetDrawColor(COL_SBAR)
		surface.SetMaterial(MAT_GRAD_R)
		surface.DrawTexturedRect(FX, FY, fillW, FH)
		surface.SetDrawColor(0, 0, 0, 55)
		surface.SetMaterial(MAT_GRAD_U)
		surface.DrawTexturedRectUV(FX, FY + FH * 0.5, fillW, FH * 0.5, 0, 1, 1, 0)
		surface.SetDrawColor(255, 255, 255, 60)
		surface.DrawRect(FX + gRespX(4), FY + math.max(1, gRespY(1)), math.max(0, fillW - gRespX(8)), math.max(1, gRespY(2)))
		-- Balayage brillant : bande lumineuse qui parcourt la jauge en boucle.
		local sw = FWmax * 0.10
		local sx = FX - sw + ((now * 0.30) % 1.35) * (FWmax + sw)
		surface.SetDrawColor(COL_SHINE)
		surface.SetMaterial(MAT_GRAD_R)
		surface.DrawTexturedRect(sx, FY, sw * 0.5, FH)
		surface.DrawTexturedRectUV(sx + sw * 0.5, FY, sw * 0.5, FH, 1, 0, 0, 1)
		render.SetScissorRect(0, 0, 0, 0, false)
	end

	-- Pointe de jauge : lueur + étincelle losange pulsée.
	if self._spendFrac > 0.004 and not bFull then
		local px = FX + fillW
		if RNDX and RNDX.DrawShadows then
			RNDX.DrawShadows(gRespY(6), px - gRespX(9), FY - gRespY(5), gRespX(18), FH + gRespY(10), ColorAlpha(COL_SBAR, 120), gRespX(12))
		end
		local sp = gRespY(4) + gRespY(2) * (0.5 + 0.5 * math.sin(now * 5))
		local cyT = FY + FH / 2
		draw.NoTexture()
		surface.SetDrawColor(255, 240, 190, 235)
		surface.DrawPoly({
			{ x = px, y = cyT - sp }, { x = px + sp, y = cyT }, { x = px, y = cyT + sp }, { x = px - sp, y = cyT },
		})
	end

	-- ── Paliers : losange sur la jauge, MÉDAILLON « COSMÉTIQUE N » au-dessus,
	-- montant dessous. Atteint = or plein ; prochain = contour or pulsé. ──
	local cy = TY + TH / 2
	local nTiers = SPEND_MAX / SPEND_STEP
	for i = 1, nTiers do
		local nNeed = i * SPEND_STEP
		local px = TX + TW * (nNeed / SPEND_MAX)
		local bReached = g_spent >= nNeed
		local bNext = not bReached and (g_spent >= nNeed - SPEND_STEP)
		local pulse = 0.5 + 0.5 * math.sin(now * 3)

		-- (Le médaillon « COSMÉTIQUE N » au-dessus du repère est un BOUTON enfant —
		-- survol = aperçu, clic = récupération — créé dans PANEL:Init.)

		-- Losange sur la piste.
		local a = gRespY(8)
		local col
		if bReached then col = COL_SBAR
		elseif bNext then col = ColorAlpha(COL_SBAR, 120 + 90 * pulse)
		else col = COL_BAR_LOCK end
		draw.NoTexture()
		surface.SetDrawColor(0, 0, 0, 160)
		surface.DrawPoly({
			{ x = px, y = cy - a - 2 }, { x = px + a + 2, y = cy }, { x = px, y = cy + a + 2 }, { x = px - a - 2, y = cy },
		})
		surface.SetDrawColor(col)
		surface.DrawPoly({
			{ x = px, y = cy - a }, { x = px + a, y = cy }, { x = px, y = cy + a }, { x = px - a, y = cy },
		})

		-- Montant sous la piste (pas de glyphe coche : Bebas rend les symboles
		-- hors-ASCII en carré, piège connu du projet).
		draw.SimpleText(fmtCoins(nNeed), "Bebas Neue:20", px, TY + TH + gRespY(18),
			bReached and COL_SBAR or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

function PANEL:OnKeyCodePressed(keycode)
	if keycode == KEY_ESCAPE and can_open == false then
		if IsValid(self._promoPopup) then
			self:CloseCosmetiquePromo()
			return true
		end
		self:Close()
		return true
	end
end

function PANEL:OnClose()
	if LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Close then
		LZY_SHOP_COSMETIC_PREVIEW.Close()
	end
	timer.Simple(0.1, function() can_open = true end)
	frame = nil
	self:Remove()
end

vgui.Register("LZY:Shop", PANEL, "DFrame")

function OpenShop(sCategoryVgui)
	if IsValid(frame) then
		if sCategoryVgui and frame.SwitchToCategory then
			frame:SwitchToCategory(sCategoryVgui)
			return
		end
		frame:Close()
	else
		frame = vgui.Create("LZY:Shop")
		can_open = false
		if sCategoryVgui and IsValid(frame) and frame.SwitchToCategory then
			frame:SwitchToCategory(sCategoryVgui)
		end
	end
end

function LZY_Shop_OpenCoins()
	OpenShop("LZY:Shop:Coins")
end

function LZY_Shop_CanAfford(nPrice)
	nPrice = math.floor(tonumber(nPrice) or 0)
	local ply = LocalPlayer()
	if not IsValid(ply) then return false end
	if ply:GetEvoNWInt("coins", 0) >= nPrice then return true end
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify("Pas assez de coins.", NOTIFY_ERROR, 4)
	end
	return false
end

function LZY_Shop_OpenRerollTab(category)
	-- Catégorie optionnelle (clé REROLL_CONFIG : art_spirituel / combat_style / style_execution /
	-- aura_spirituel). Consommée one-shot par LZY:Shop:Reroll PANEL:Init pour ouvrir DIRECTEMENT
	-- la bonne page d'achat au lieu de l'écran de sélection (demande user 2026-07-16).
	LZY_Shop_RerollPreselect = isstring(category) and category or nil
	OpenShop("LZY:Shop:Reroll")
end
