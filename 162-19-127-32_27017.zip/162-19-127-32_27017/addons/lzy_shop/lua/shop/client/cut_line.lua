-- "addons\\lzy_shop\\lua\\shop\\client\\cut_line.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Confirmation d'achat (demande user 2026-07-16) : popup "Confirmer l'achat ?" avant
-- d'envoyer l'achat au serveur (meme pattern que le night market).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_CutLine_Buy = function(args)
	if not args or not args.index then return end
	net.Start("server:lzy_shop.cutline_buy")
		net.WriteUInt(tonumber(args.index) or 0, 8)
	net.SendToServer()
end

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- ============================================================================
-- DESIGN VALORANT (mirror cosmetiques/night market) : DHTML frame avec
-- bordure + corners + glints + halo + bar bottom. Material du grade rendue
-- en background via base64 inline. Couleur du frame par grade (premium=cyan,
-- vip=gold). Gift+Buy preserves avec slide-up au hover.
-- ============================================================================

-- Coin image inline en base64.
local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- Couleur de bordure par grade (uppercase).
local GRADE_BORDER_COLOR = {
	PREMIUM = Color(110, 200, 255, 240),  -- cyan
	VIP     = Color(255, 210, 90, 240),   -- gold
}
local function GetGradeColor(grade)
	local g = isstring(grade) and string.upper(grade) or "PREMIUM"
	return GRADE_BORDER_COLOR[g] or GRADE_BORDER_COLOR.PREMIUM
end

-- Pour les bg images : asset:// (loader natif Chromium) plus rapide que base64
-- pour les grosses images (decode quasi-instant vs 100-300ms en data:URI).
local function GetMatDataURI(matPath)
	if not isstring(matPath) or matPath == "" then return "" end
	return "asset://garrysmod/materials/" .. matPath
end

local CARD_W = 352
local CARD_H = 764

-- ============================================================================
-- Template HTML/CSS : frame Valorant + material background + bar bottom.
-- 12 placeholders : 11 rgb + 1 barHTML.
-- ============================================================================
local CARD_FRAME_HTML_CUT = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
.wrap { position:relative; width:100%%; height:100%%; transition: transform 0.2s ease-out; }
.border {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
}
.border::before {
	content:''; position:absolute; top:-4px; right:-4px; bottom:-4px; left:-4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity:0.35;
}
.border::after {
	content:''; position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:#0a0a0e;
}
.crate {
	position:absolute; top:4px; right:4px; bottom:4px; left:4px;
	background: radial-gradient(ellipse at top, rgba(%s, 0.18) 0%%, rgba(0,0,0,0.96) 70%%), #0a0a0e;
	overflow:hidden; z-index:1;
}
/* Material background du grade : image stretch fullsize, fade au bas pour bar */
.grade-bg {
	position:absolute; top:-8px; left:-8px; right:-8px; bottom:-8px;
	background-size: cover; background-position: center;
	z-index: 0;
	/* Image TRANSLUCIDE + LAYER BLUR léger (demande user 08/07). L'inset négatif
	   (-8px) évite que le flou fasse fondre les bords visibles (clippés par .crate). */
	opacity: 0.5;
	-webkit-filter: blur(3px);
	filter: blur(3px);
}
.grade-bg::after {
	content:''; position:absolute; top:0; left:0; right:0; bottom:0;
	background: linear-gradient(to bottom, transparent 0%%, transparent 55%%, rgba(0,0,0,0.85) 88%%, rgba(0,0,0,1) 100%%);
}
/* Corners 4 coins (top + bottom au-dessus de la bar 72px) */
.corner { display:none;
	position:absolute; width:22px; height:22px;
	border:2px solid rgba(%s, 0.9); z-index:3;
	transition: border-color 0.15s ease-out;
}
.corner.tl { top:12px; left:12px; border-right:none; border-bottom:none; }
.corner.tr { top:12px; right:12px; border-left:none; border-bottom:none; }
.corner.bl { bottom:82px; left:12px; top:auto; border-right:none; border-top:none; }
.corner.br { bottom:82px; right:12px; top:auto; border-left:none; border-top:none; }
/* Glints */
/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }
@keyframes sweep {
	0%%   { transform: translate3d(-120px, 0, 0) skewX(-25deg); }
	100%% { transform: translate3d(420px, 0, 0) skewX(-25deg); }
}
/* Hover : scale + glow */
body.hovered .wrap { transform: scale(1.015); }
.hover-glow {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: radial-gradient(ellipse at center, rgba(%s, 0.28) 0%%, transparent 65%%);
	opacity: 0; transition: opacity 0.2s ease-out;
	pointer-events: none; z-index: 2;
}
body.hovered .hover-glow { opacity: 1; }
body.hovered .corner { display:none; border-color: rgba(%s, 1); }

/* OWNED label : ACTIF en vert quand le joueur a deja le coupe-file */
.owned-label {
	position: absolute;
	top: 65%%; left: 0; right: 0;
	text-align: center;
	z-index: 6;
	display: none;
	pointer-events: none;
}
body.owned .owned-label { display: block; }
body.owned .bar { opacity: 0.4; }
.owned-main {
	display: block;
	font-size: 32px;
	font-weight: 900;
	letter-spacing: 8px;
	color: rgb(0, 235, 120);
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}

/* Bar bottom : 72px tall, grade label a gauche + prix/coin a droite */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 72px;
	background: linear-gradient(to top, rgba(0,0,0,0.95) 0%%, rgba(0,0,0,0.5) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 24px;
	z-index: 5;
}
.bar::before {
	content: ''; position: absolute;
	top: 0; left: 18px; right: 18px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.7), transparent);
}
.bar-grade {
	font-size: 34px;
	color: #fff;
	font-weight: 800;
	letter-spacing: 4px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 8px; }
.bar-old {
	font-size: 20px;
	color: rgba(255,255,255,0.45);
	text-decoration: line-through;
	text-decoration-color: rgba(255, 80, 80, 0.85);
	letter-spacing: 1px;
	font-weight: 700;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-discount {
	font-size: 20px;
	color: rgb(255, 80, 80);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-price {
	font-size: 34px;
	color: rgb(0, 235, 120);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-coin {
	width: 24px; height: 24px;
	vertical-align: middle;
	image-rendering: -webkit-optimize-contrast;
}

/* Description : nom + desc au-dessus du milieu, fadee */
.info {
	position: absolute;
	top: 52%%; left: 0; right: 0;
	padding: 0 24px;
	text-align: center;
	z-index: 5;
}
.info-name {
	display: block;
	font-size: 36px;
	font-weight: 900;
	letter-spacing: 6px;
	color: #fff;
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
	margin-bottom: 12px;
}
.info-desc {
	display: block;
	font-size: 18px;
	color: rgba(255,255,255,0.78);
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
	font-weight: 500;
	line-height: 1.4;
}
</style></head>
<body>
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="grade-bg" style="background-image: url('%s');"></div>
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="glint"></div>
			<div class="hover-glow"></div>
			<div class="owned-label">
				<span class="owned-main">ACTIF</span>
			</div>
			%s
		</div>
	</div>
</body></html>
]]

function PANEL:CreateGrade(row, x, offerIndex)
	local name  = row.name  or "?"
	local desc  = row.desc  or ""
	local grade = row.grade or ""
	local price = tonumber(row.price) or 0
	local matPath = row.mat or ""

	-- Check if the player already has this cut line active
	local ply = LocalPlayer()
	local alreadyOwned = IsValid(ply) and ply:GetEvoNWInt("queue_bypass", 0) == offerIndex

	local borderCol  = GetGradeColor(grade)
	local rgb        = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local matDataURI = GetMatDataURI(matPath)

	-- Discount calc
	local finalPrice, hasDiscount = GetDiscountedPrice(price)
	local discPct = hasDiscount and SHOP_CONFIG.CREATOR_CODE_DISCOUNT or 0

	-- Bar HTML : avec/sans discount + coin icon
	local barHTML
	if hasDiscount then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-grade">%s</span>
	<span class="bar-right">
		<span class="bar-old">%d</span>
		<span class="bar-discount">-%d%%</span>
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(grade), price, discPct, finalPrice, _COIN_DATA_URI)
	else
		barHTML = string.format([[
<div class="bar">
	<span class="bar-grade">%s</span>
	<span class="bar-right">
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(grade), price, _COIN_DATA_URI)
	end

	-- Info HTML : nom + description au-dessus du milieu
	local infoHTML = string.format([[
<div class="info">
	<span class="info-name">%s</span>
	<span class="info-desc">%s</span>
</div>
]], name, desc)

	local innerHTML = infoHTML .. barHTML

	-- ========================================================================
	-- Background (statique 352x764) : porte le DHTML frame Valorant.
	-- ========================================================================
	local background = gPanel(x, 115, CARD_W, CARD_H, self)
	background.Paint = function() end

	local frame = vgui.Create("DHTML", background)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(string.format(CARD_FRAME_HTML_CUT,
		rgb, rgb, rgb,   -- border (3)
		rgb, rgb, rgb,   -- border::before (3)
		rgb,             -- crate radial (1)
		rgb,             -- corner (1)
		rgb,             -- hover-glow (1)
		rgb,             -- corner hover (1)
		rgb,             -- bar lisere (1)
		matDataURI,      -- material background URI
		innerHTML
	))
	background._dhtmlFrame = frame

	-- Push owned class si deja achete (apres charge async du DHTML)
	if alreadyOwned then
		timer.Simple(0.2, function()
			if IsValid(frame) then
				frame:RunJavascript("if(document.body){document.body.classList.add('owned');}")
			end
		end)
	end

	-- ========================================================================
	-- Container (352x764+50) : extends 50px sous le card pour slide-up des
	-- boutons gift/buy au hover. Hover detection via gui.MousePos (le DHTML
	-- intercepte le curseur sinon).
	-- ========================================================================
	local container = gPanel(0, 0, CARD_W, CARD_H + 50, background)
	container:SetMouseInputEnabled(true)
	container._alreadyOwned = alreadyOwned

	container.Think = function(selff)
		if not IsValid(selff) or selff._alreadyOwned then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
			if inside then
				selff:gMoveToY(-50, 0.2, 0, 4)
			else
				timer.Simple(0.05, function()
					if IsValid(selff) and not selff._hovered then
						selff:gMoveToY(0, 0.2, 0, 4)
					end
				end)
			end
		end
	end
	container.Paint = function() end

	-- ========================================================================
	-- Bouton OFFRIR (gift) : moitie gauche du bas, vert.
	-- ========================================================================
	local gift = gPanel(0, CARD_H, CARD_W / 2, 50, container)
	gift.opacity = 0.20
	gift:SetCursor("hand")
	gift.OnCursorEntered = function() gift.opacity = 0.40 end
	gift.OnCursorExited  = function() gift.opacity = 0.20 end
	gift.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		local giftPanel = vgui.Create("LZY:Shop:Gift", self:GetParent())
		giftPanel.giftType = "cutline"
		giftPanel.configIndex = offerIndex
	end
	gift.Paint = function()
		rRect(0, 0, CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
		rRect(0, 0, CARD_W / 2, 50, Color(0, 255, 9, 255 * gift.opacity))
		rSimpleText("OFFRIR", "Avenir Next World:20", CARD_W / 4, 25,
			Color(0, 255, 9), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- ========================================================================
	-- Bouton ACHETER (buy) : moitie droite du bas, cyan ou greyed si owned.
	-- ========================================================================
	local buy = gPanel(CARD_W / 2, CARD_H, CARD_W / 2, 50, container)
	buy.opacity = 0.30
	buy:SetCursor("hand")
	buy.OnCursorEntered = function()
		if not alreadyOwned then buy.opacity = 0.50 end
	end
	buy.OnCursorExited = function() buy.opacity = 0.30 end
	buy.OnMousePressed = function()
		if alreadyOwned then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
		-- Confirmation avant achat (demande user) : l'achat part dans le callback popup.
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Confirmer l'achat de " .. name .. " ?", "LzyShop_CutLine_Buy", { index = offerIndex })
		end
	end
	buy.Paint = function()
		rRect(0, 0, CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
		if alreadyOwned then
			rRect(0, 0, CARD_W / 2, 50, Color(80, 80, 80, 255 * buy.opacity))
			rSimpleText("ACTIF", "Avenir Next World:20", CARD_W / 4, 25,
				Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			-- ACHETER : couleur du tier (matche la border de la case)
			rRect(0, 0, CARD_W / 2, 50,
				Color(borderCol.r, borderCol.g, borderCol.b, 255 * buy.opacity))
			local lblCol = Color(
				math.min(borderCol.r + 50, 255),
				math.min(borderCol.g + 50, 255),
				math.min(borderCol.b + 50, 255))
			rSimpleText("ACHETER", "Avenir Next World:20", CARD_W / 4, 25,
				lblCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

function PANEL:Init()
	local x = 598 - 40
	local list = COUPE_FILE_CONFIG or {}

	for i = 1, #list do
		self:CreateGrade(list[i], x, i)
		x = x + 352 + 20
	end
end

function PANEL:Paint()
	-- (Titre interne « COUPE FIL » RETIRÉ — 08/07 : le nom de la catégorie est
	-- affiché en haut-centre par l'accueil boutique, il était en DOUBLE ici.)
end

vgui.Register("LZY:Shop:CutLine", PANEL, "DPanel")
