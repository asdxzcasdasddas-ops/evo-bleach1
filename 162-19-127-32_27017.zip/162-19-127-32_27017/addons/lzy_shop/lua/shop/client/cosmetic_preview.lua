-- "addons\\lzy_shop\\lua\\shop\\client\\cosmetic_preview.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Preview cosmetique sur le model du joueur : ouvre une frame avec un DModelPanel
-- qui rend le corps + cheveux du joueur (via PlayerModelParts) + l'accessoire bonemerge.
-- Pour les outfits, swap le model entier (les outfits sont des full-body replacements).

LZY_SHOP_COSMETIC_PREVIEW = LZY_SHOP_COSMETIC_PREVIEW or {}

local IDLE_ANIM_MALE   = (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.IDLE_ANIM_MALE)   or "idle_all_01"
local IDLE_ANIM_FEMALE = (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.IDLE_ANIM_FEMALE) or "idle_all_01"

-- ============================================================================
-- Bandeau EVO « détail modèles » (cosmétiques + black market).
-- Visibilité pilotée par LZY_Shop_TickModelDetailWarn (appelée depuis PANEL:Think
-- du parent) : un DPanel SetVisible(false) ne reçoit PAS Think lui-même.
-- ============================================================================
local WARN_ACCENT = Color(207, 68, 78)
local WARN_PLATE  = Color(13, 14, 17, 245)
local WARN_BODY   = Color(200, 204, 212)

local function DrawWarnTriangle(cx, cy, size, col)
	local half = size * 0.5
	local pts = {
		{ x = cx, y = cy - half },
		{ x = cx + half * 0.92, y = cy + half * 0.78 },
		{ x = cx - half * 0.92, y = cy + half * 0.78 },
	}
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
	draw.SimpleText("!", "Avenir Next World Bold:18", cx, cy + size * 0.1,
		Color(13, 14, 17), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local WARN_TITLE_FONT = "Bebas Neue:20"
local WARN_BODY_FONT  = "Avenir Next World:15"

local function WarnBodyText(rootLod)
	local levelName = (rootLod or 0) >= 2 and "Bas" or "Moyen"
	return "Détail des modèles : " .. levelName .. ". Passez-le sur Élevé (Options > Vidéo) pour afficher les cosmétiques en haute définition."
end

--- Attache le bandeau LOD en bas du panneau boutique (enfant, z-haut).
--- opts.bottomPad : marge bas en design units (défaut 12). Négatif = plus bas
--- (déborde sous le panneau via NoClipping) — utile Black Market (crates y=115+764).
function LZY_Shop_AttachModelDetailWarn(parent, opts)
	if not IsValid(parent) then return nil end
	if IsValid(parent._lodWarn) then return parent._lodWarn end

	opts = opts or {}
	parent._lodWarnBottomPad = tonumber(opts.bottomPad) or 12

	local accent = (EVO_UI and EVO_UI.Col and EVO_UI.Col.accent) or WARN_ACCENT
	local lodWarn = vgui.Create("DPanel", parent)
	lodWarn:SetMouseInputEnabled(false)
	lodWarn:SetKeyboardInputEnabled(false)
	lodWarn:SetPaintBackground(false)
	lodWarn:SetVisible(false)
	lodWarn:SetZPos(50)
	if parent._lodWarnBottomPad < 0 then
		lodWarn:NoClipping(true)
	end
	parent._lodWarn = lodWarn

	lodWarn.Paint = function(s, bw, bh)
		local cut = gRespY(10)
		local pts
		if EVO_UI and EVO_UI.PaintCut then
			pts = EVO_UI.PaintCut(0, 0, bw, bh, WARN_PLATE, cut, "br")
			if EVO_UI.OutlineCut and pts then
				EVO_UI.OutlineCut(pts, Color(accent.r, accent.g, accent.b, 200))
			end
		else
			surface.SetDrawColor(WARN_PLATE)
			surface.DrawRect(0, 0, bw, bh)
			surface.SetDrawColor(accent.r, accent.g, accent.b, 200)
			surface.DrawOutlinedRect(0, 0, bw, bh)
		end
		surface.SetDrawColor(accent)
		surface.DrawRect(gRespX(2), gRespY(8), gRespX(3), bh - gRespY(16))

		local iconS = gRespY(22)
		local ix = gRespX(22)
		DrawWarnTriangle(ix + iconS * 0.5, bh * 0.5, iconS, accent)

		local tx = ix + iconS + gRespX(12)
		draw.SimpleText("ATTENTION", WARN_TITLE_FONT, tx, gRespY(8),
			accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(s._bodyText or WarnBodyText(s._rootLod), WARN_BODY_FONT,
			tx, bh - gRespY(10), WARN_BODY, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	end

	return lodWarn
end

--- À appeler depuis PANEL:Think du parent. r_rootlod : 0=Élevé, 1=Moyen, 2=Bas.
function LZY_Shop_TickModelDetailWarn(parent)
	if not IsValid(parent) then return end
	local warn = parent._lodWarn
	if not IsValid(warn) then return end
	local cv = GetConVar("r_rootlod")
	local rootLod = cv and cv:GetInt() or 0
	local show = rootLod >= 1
	warn._rootLod = rootLod
	if warn:IsVisible() ~= show then
		warn:SetVisible(show)
	end
	if not show then return end

	local bodyText = WarnBodyText(rootLod)
	warn._bodyText = bodyText
	surface.SetFont(WARN_TITLE_FONT)
	local titleW = surface.GetTextSize("ATTENTION")
	surface.SetFont(WARN_BODY_FONT)
	local bodyW = surface.GetTextSize(bodyText)
	local textW = math.max(titleW, bodyW)

	-- icon + gaps + text + right pad
	local bw = gRespX(22) + gRespY(22) + gRespX(12) + textW + gRespX(22)
	bw = math.min(bw, math.max(gRespX(200), parent:GetWide() - gRespX(16)))
	local bh = gRespY(54)
	local pad = parent._lodWarnBottomPad
	if pad == nil then pad = 12 end
	warn:SetSize(bw, bh)
	warn:SetPos(math.floor((parent:GetWide() - bw) * 0.5), parent:GetTall() - bh - gRespY(pad))
	warn:MoveToFront()
end

local function safePlayIdle(ent, gender)
	if not IsValid(ent) then return end
	local anim = (gender == "f") and IDLE_ANIM_FEMALE or IDLE_ANIM_MALE
	local seq = ent:LookupSequence(anim)
	if not seq or seq < 0 then seq = ent:LookupSequence("idle_all_01") end
	if not seq or seq < 0 then seq = ent:LookupSequence("idle") end
	if seq and seq >= 0 then
		ent:ResetSequence(seq)
		ent:SetPlaybackRate(1)
	end
end

-- Bonemerge un model sur un parent, l'ajoute a `tracked` pour cleanup, retourne l'entite.
-- sourceEnt (optionnel) : la part deja rendue dont on clone l'apparence (skin de
-- variante). Sans ca, recreer la part depuis son seul model_path la remet en skin 0
-- -> un accessoire de couleur porte s'affichait dans sa version de base dans la preview.
local function bonemergeOnto(parent, modelPath, tracked, sourceEnt)
	if not IsValid(parent) or not isstring(modelPath) or modelPath == "" then return nil end
	local mdl = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
	if not IsValid(mdl) then return nil end
	-- Pet d'épaule : attaché par le module pets de cl_models (bonemerge) + animé par son Think.
	local petCfg = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetShoulderPet and LZY_CHARACTER_CONFIG.GetShoulderPet(modelPath)
	if petCfg and LZY_Character_SetupPetPart then
		mdl:SetNoDraw(true)
		mdl:SetLOD(0)
		if IsValid(sourceEnt) then mdl:SetSkin(sourceEnt:GetSkin() or 0) end
		LZY_Character_SetupPetPart(parent, mdl, petCfg)
		tracked[#tracked + 1] = mdl
		return mdl
	end
	mdl:SetParent(parent)
	mdl:SetLocalPos(Vector(0, 0, 0))
	mdl:SetLocalAngles(Angle(0, 0, 0))
	mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
	mdl:SetNoDraw(true) -- on dessine manuellement via PostDrawModel pour controler l'ordre
	mdl:SetLOD(0) -- preview shop : toujours le mesh le plus detaille
	if IsValid(sourceEnt) then
		mdl:SetSkin(sourceEnt:GetSkin() or 0)
	end
	tracked[#tracked + 1] = mdl
	return mdl
end

local function cleanupTracked(tracked)
	for _, e in ipairs(tracked) do
		if IsValid(e) then SafeRemoveEntity(e) end
	end
end

--- Ferme la preview actuellement ouverte (si applicable).
function LZY_SHOP_COSMETIC_PREVIEW.Close()
	local f = LZY_SHOP_COSMETIC_PREVIEW._currentFrame
	if IsValid(f) then f:Close() end
	LZY_SHOP_COSMETIC_PREVIEW._currentFrame = nil
end

--- Ouvre une frame avec la preview de itemData (ITEMS entry) sur le perso du joueur.
function LZY_SHOP_COSMETIC_PREVIEW.Open(itemData)
	if not itemData or not isstring(itemData.model_path) or itemData.model_path == "" then return end

	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	-- Une seule preview a la fois : fermer la precedente si elle existe
	LZY_SHOP_COSMETIC_PREVIEW.Close()

	local isOutfit = itemData.category == "outfit"
	-- Fourreau (09/30, user) : l'objet SEUL, sans personnage (rien sur quoi le greffer).
	local bSeul = itemData.fourreau_cosmetic ~= nil or itemData.compagnon_id ~= nil -- compagnon : seul aussi

	-- Le model de base est TOUJOURS la face du joueur (lp:GetModel() = model de face/rig
	-- avec les anims). Les body/hair/outfit sont des body models qu'il faut bonemerge dessus
	-- (sinon les outfits n'ont pas de tete, ce sont juste des corps).
	local baseModel = bSeul and itemData.model_path or lp:GetModel()
	if not isstring(baseModel) or baseModel == "" then return end

	-- Frame modale
	local W, H = math.floor(ScrW() * 0.36), math.floor(ScrH() * 0.78)
	local frame = vgui.Create("DFrame")
	frame:SetSize(W, H)
	frame:Center()
	frame:SetTitle("")
	frame:SetDraggable(true)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	LZY_SHOP_COSMETIC_PREVIEW._currentFrame = frame

	-- Fond MODAL plein écran (fix 08/07 : cliquer À CÔTÉ de l'aperçu doit le
	-- FERMER, avant il passait juste en arrière-plan de la boutique). Le backdrop
	-- capte les clics hors de la frame et la ferme ; léger assombrissement. Créé
	-- APRÈS le MakePopup de la frame, puis la frame est remise au premier plan.
	local backdrop = vgui.Create("DButton")
	frame._backdrop = backdrop
	backdrop:SetText("")
	backdrop:SetSize(ScrW(), ScrH())
	backdrop:SetPos(0, 0)
	backdrop:MakePopup()
	backdrop.Paint = function(_, bw, bh)
		surface.SetDrawColor(0, 0, 0, 90)
		surface.DrawRect(0, 0, bw, bh)
	end
	backdrop.DoClick = function()
		if IsValid(frame) then frame:Close() end
	end
	frame:MoveToFront()
	frame:MakePopup()

	frame.Paint = function(_, w, h)
		-- Plaque de métal noir Atelier (DA 07/07) : coins coupés + liseré acier,
		-- titre Bebas + entaille slash1 centrée (remplace le rect + bordure blanche).
		if EVO_UI and EVO_UI.PaintCut then
			-- DA dashboard 08/07 : plus de liseré acier
			EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250), 14)
		else
			surface.SetDrawColor(18, 18, 22, 245)
			surface.DrawRect(0, 0, w, h)
		end
		local sTitle = "APERÇU : " .. tostring(itemData.name or "?")
		draw.SimpleText(sTitle, "Bebas Neue:26", w / 2, 12,
			Color(237, 238, 242), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		surface.SetFont("Bebas Neue:26")
		local twT, thT = surface.GetTextSize(sTitle)
		if EVO_UI and EVO_UI.Ink then
			EVO_UI.Ink(EVO_UI.TexSlash, w / 2 - twT * 0.575, 12 + thT * 0.78, twT * 1.15, 8, Color(207, 68, 78, 245))
		end
		draw.SimpleText("Glisser pour pivoter • Molette pour zoomer",
			"Avenir Next World:14", w / 2, 48,
			Color(150, 154, 162), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Croix standard DA : glyphe ✕, pas de fond, gris -> accent au survol.
	local closeBtn = vgui.Create("DButton", frame)
	closeBtn:SetSize(36, 36)
	closeBtn:SetPos(W - 44, 8)
	closeBtn:SetText("")
	closeBtn:SetCursor("hand")
	closeBtn.Paint = function(_, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			closeBtn:IsHovered() and Color(207, 68, 78) or Color(150, 154, 162),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeBtn.DoClick = function() frame:Close() end

	-- DModelPanel
	local mdl = vgui.Create("DModelPanel", frame)
	mdl:SetPos(10, 70)
	mdl:SetSize(W - 20, H - 80)
	mdl:SetModel(baseModel)
	mdl:SetFOV(35)
	mdl:SetAnimated(true)

	local ent = mdl:GetEntity()
	if not IsValid(ent) then
		frame:Close()
		return
	end
	ent:SetLOD(0) -- preview shop : toujours le mesh le plus detaille

	-- Garder une trace des ClientsideModels crees pour cleanup
	local tracked = {}

	-- ent = face model (anims + tete visible). On bonemerge tout le reste par-dessus.
	-- - Accessoire : body actuel + hair + accessoires existants + l'accessoire preview
	-- - Outfit     : l'outfit REMPLACE le body (on ne bonemerge pas le body actuel) + hair
	local parts = lp.PlayerModelParts
	local previewEnt
	-- Capture les ents bonemergés pour appliquer la gradient hair après
	local hairEnt, beardEnt, mustacheEnt

	-- Si on preview un accessoire et qu'on porte deja un accessoire dans le meme
	-- slot, on skip ce dernier (sinon les deux models se superposent sur le meme
	-- bone et l'existant masque visuellement la preview / vice-versa).
	local previewCharData = GetPlayerCharacterData and GetPlayerCharacterData(lp) or nil
	local skipAccModel = nil
	-- Écart par SLOT (09/06) : les parts du joueur portent _lzyAccessorySlot. Le slot du
	-- preview est écarté, et pour un MASQUE on écarte AUSSI le masque de base : c'est un
	-- cosmétique de GRADE (slot masque_base), jamais dans equipped_accessories, donc la
	-- comparaison de modèle ci-dessous ne le voyait pas et il restait sous le masque testé.
	local skipSlots = {}
	if not isOutfit and INVENTORY_CONFIG and INVENTORY_CONFIG.GetAccessoryEquipSlot then
		local slot = INVENTORY_CONFIG.GetAccessoryEquipSlot(itemData)
		if slot then
			skipSlots[tostring(slot)] = true
			if previewCharData and istable(previewCharData.equipped_accessories) then
				skipAccModel = previewCharData.equipped_accessories[tostring(slot)]
			end
		end
		local bMask = INVENTORY_CONFIG.IsMaskAccessory and itemData.__shopItemId
			and INVENTORY_CONFIG.IsMaskAccessory(itemData.__shopItemId)
		if bMask == nil or bMask == false then
			bMask = isstring(itemData.model_path) and string.find(string.lower(itemData.model_path), "/arr_mask/", 1, true) ~= nil
		end
		if bMask then
			skipSlots[INVENTORY_CONFIG.MASQUE_BASE_SLOT or "masque_base"] = true
		end
	end

	if bSeul then
		previewEnt = ent
	elseif not isOutfit then
		if istable(parts) then
			if IsValid(parts.body) and parts.body:GetModel() then
				-- parts.body en SOURCE -> bonemergeOnto copie son SKIN (= couleur de peau du
				-- corps). Sans ça le corps de la preview restait en skin 0 (mauvaise couleur).
				bonemergeOnto(ent, parts.body:GetModel(), tracked, parts.body)
			end
			if IsValid(parts.hair) and parts.hair:GetModel() then
				hairEnt = bonemergeOnto(ent, parts.hair:GetModel(), tracked)
			end
			if IsValid(parts.beard) and parts.beard:GetModel() then
				beardEnt = bonemergeOnto(ent, parts.beard:GetModel(), tracked)
			end
			if IsValid(parts.mustache) and parts.mustache:GetModel() then
				mustacheEnt = bonemergeOnto(ent, parts.mustache:GetModel(), tracked)
			end
			-- Accessoires deja equipes : on garde tous les slots SAUF celui du
			-- preview pour eviter la superposition de deux models sur le meme bone.
			if istable(parts.accessories) then
				for _, acc in ipairs(parts.accessories) do
					if IsValid(acc) and acc:GetModel() then
						local sSlot = acc._lzyAccessorySlot and tostring(acc._lzyAccessorySlot) or nil
						local bSkip = (sSlot and skipSlots[sSlot]) or (skipAccModel and acc:GetModel() == skipAccModel)
						if not bSkip then
							bonemergeOnto(ent, acc:GetModel(), tracked, acc)
						end
					end
				end
			end
		end
		previewEnt = bonemergeOnto(ent, itemData.model_path, tracked)
	else
		-- Outfit = body model qui remplace le body. La face est deja le ent.
		previewEnt = bonemergeOnto(ent, itemData.model_path, tracked)
		-- Garde les cheveux/barbe/moustache + accessoires du joueur pour qu'on
		-- reconnaisse le perso (sinon preview enleve visuellement les accessoires equipes).
		if istable(parts) then
			if IsValid(parts.hair) and parts.hair:GetModel() then
				hairEnt = bonemergeOnto(ent, parts.hair:GetModel(), tracked)
			end
			if IsValid(parts.beard) and parts.beard:GetModel() then
				beardEnt = bonemergeOnto(ent, parts.beard:GetModel(), tracked)
			end
			if IsValid(parts.mustache) and parts.mustache:GetModel() then
				mustacheEnt = bonemergeOnto(ent, parts.mustache:GetModel(), tracked)
			end
			if istable(parts.accessories) then
				for _, acc in ipairs(parts.accessories) do
					if IsValid(acc) and acc:GetModel() then
						bonemergeOnto(ent, acc:GetModel(), tracked, acc)
					end
				end
			end
		end
	end

	-- Recupere les character data une seule fois (utilise pour gradient + tatouages).
	local char = (not bSeul) and GetPlayerCharacterData and GetPlayerCharacterData(lp) or nil

	-- VISAGE DU PERSO sur la face (ent) : skin + bodygroups + shape_keys (la MORPHOLOGIE = la "tête")
	-- + pupilles. Sans ça la preview gardait la tête PAR DÉFAUT du modèle (flex à 0) -> après une modif
	-- chez le chirurgien esthétique, la preview montrait "la même tête qu'avant" (HUD/inventaire OK car
	-- eux ré-appliquent bien). Les shape_keys ne sont PAS bakés dans le .mdl : il faut les ré-appliquer
	-- sur CHAQUE ClientsideModel (même fonction exacte que le joueur in-world). Placé AVANT le tatouage
	-- ci-dessous pour que le bake se fasse sur le bon skin.
	if char and LZY_Character_ApplyFaceAppearanceFromData then
		LZY_Character_ApplyFaceAppearanceFromData(ent, char)
	end

	-- ROBUSTESSE tête + couleur : la table `char` (playersModels) peut être EN RETARD juste
	-- après une édition chez le chirurgien esthétique (gate FaceModelMatches qui rate, ou data
	-- pas encore re-net) -> la preview montrait "la même tête qu'avant". Le joueur LIVE (lp)
	-- porte DÉJÀ la bonne apparence (le composite l'applique sur lp lui-même, et HUD/in-world
	-- sont corrects). On COPIE donc skin + bodygroups + morphologie (flex = shape_keys)
	-- DIRECTEMENT depuis lp = source de vérité réellement affichée, pas la donnée stale.
	-- ent a le MÊME modèle de face que lp (baseModel = lp:GetModel()) -> les IDs flex/bodygroup
	-- correspondent 1:1. Fait AVANT le tatouage ci-dessous pour que le bake utilise le bon skin.
	if IsValid(lp) and ent.SetSkin and not bSeul then
		ent:SetSkin(lp:GetSkin() or 0)
		for i = 0, lp:GetNumBodyGroups() - 1 do
			ent:SetBodygroup(i, lp:GetBodygroup(i))
		end
		for i = 0, (lp:GetFlexNum() or 0) - 1 do
			ent:SetFlexWeight(i, lp:GetFlexWeight(i))
		end
		ent:SetFlexScale(lp:GetFlexScale() or 1)
	end

	-- Applique la gradient hair (color1/color2/angle + details color) sur les
	-- bonemerges qu'on vient de créer. Sinon ils s'affichent avec la couleur de
	-- base du modèle au lieu de celle du perso.
	if char and ApplyHairGradientToWorldPlayer then
		if char.hair_color1 and char.hair_color2 then
			local detailsCol = (LZY_NormalizeHairDetailsColor and LZY_NormalizeHairDetailsColor(char.hair_details_color)) or Color(255, 255, 255)
			local angleDeg   = char.hair_gradient_angle or 0
			if IsValid(hairEnt) then
				ApplyHairGradientToWorldPlayer(ent, hairEnt, char.hair_color1, char.hair_color2, angleDeg, detailsCol)
			end
			if IsValid(beardEnt) then
				ApplyHairGradientToWorldPlayer(ent, beardEnt, char.hair_color1, char.hair_color2, angleDeg, detailsCol)
			end
			if IsValid(mustacheEnt) then
				ApplyHairGradientToWorldPlayer(ent, mustacheEnt, char.hair_color1, char.hair_color2, angleDeg, detailsCol)
			end
		end
	end

	-- Applique les tatouages du joueur sur la face (ent). Le bake utilise les
	-- meme slots et keys que le character creator (tattoo_texture, _pos_x,
	-- _scale_x, _color, _opacity x 3 slots). Sans ca, la preview montre la
	-- face nue meme si le joueur a des tatouages equipes.
	if char and LZY_ApplyTattooFromCharacterData then
		LZY_ApplyTattooFromCharacterData(ent, char)
	end

	-- Couleur des yeux : matproxy lit ent.EyesColor pour set $color2 du VMT eyes.
	-- Sans ca la preview garde les yeux par defaut du model.
	if char then
		local eyesCol = char.eyes_color
		if istable(eyesCol) then
			ent.EyesColor = Color(
				tonumber(eyesCol.r) or 255,
				tonumber(eyesCol.g) or 255,
				tonumber(eyesCol.b) or 255
			)
		end
	end

	-- Pupilles (forme + couleur) : meme code que le world player.
	if char and ApplyPupilsFromCharacterData then
		local gender = (lp.PlayerModelParts and lp.PlayerModelParts.gender) or char.gender or "m"
		ApplyPupilsFromCharacterData(ent, gender, char)
	end

	-- Skin / variant de l'item preview
	if previewEnt and IsValid(previewEnt) then
		if itemData.skin ~= nil then
			previewEnt:SetSkin(tonumber(itemData.skin) or 0)
		end
		if itemData.bodygroup ~= nil then
			if istable(itemData.bodygroup) then
				for g, v in pairs(itemData.bodygroup) do
					local nId = tonumber(g) or previewEnt:FindBodygroupByName(tostring(g)) -- clé = index ou NOM
					if nId >= 0 then previewEnt:SetBodygroup(nId, tonumber(v) or 0) end
				end
			else
				local n = tonumber(itemData.bodygroup) or 0
				previewEnt:SetBodygroup(0, n)
				previewEnt:SetSkin(n)
			end
		end
	end

	-- TENUE : le body model utilise le SKIN comme COULEUR DE PEAU (exactement comme le corps
	-- in-world, cf createModelPart(ent, bodyModel, nil, skin_color) dans cl_models). La branche
	-- outfit laissait previewEnt en skin 0 -> "corps pas à jour" (ancienne/mauvaise couleur de
	-- peau) après une édition chez le chirurgien, alors que la tête, elle, suivait. On force donc
	-- la peau de la tenue sur lp:GetSkin() (la peau RÉELLEMENT affichée = source de vérité, pas la
	-- data potentiellement périmée). Placé APRÈS le bloc itemData.skin pour que la couleur de peau
	-- ACTUELLE gagne toujours sur la preview d'une tenue.
	if isOutfit and IsValid(previewEnt) and IsValid(lp) then
		previewEnt:SetSkin(lp:GetSkin() or 0)
	end

	-- Animation : idle de base pour TOUT le monde, katana/gantelet compris (demande
	-- user 2026-07-21 : plus de combos de combat en preview, meme pose que les
	-- autres equipements). Seule difference : un dezoom pour voir l'arme en entier.
	local gender = (lp.PlayerModelParts and lp.PlayerModelParts.gender) or "m"
	local isWeapon = itemData.skin_id ~= nil or itemData.gauntlet_id ~= nil -- katana ou gantelet Hakuda
	if not bSeul then safePlayIdle(ent, gender) end

	-- Override PostDrawModel pour dessiner les bonemerges manuellement
	-- (necessaire car SetNoDraw(true) sur les enfants empeche le rendu automatique)
	mdl.PostDrawModel = function(_, e)
		if not IsValid(e) then return end
		e:SetLOD(0)
		for _, sub in ipairs(tracked) do
			if IsValid(sub) then
				sub:SetLOD(0)
				if sub._lzyPet and LZY_Character_PetPlace then
					sub._petParent = e
					LZY_Character_PetPlace(sub) -- pet d'épaule : posé sur l'os du modèle de preview
					sub:SetupBones()
				end
				sub:SetNoDraw(false)
				sub:DrawModel()
				sub:SetNoDraw(true)
			end
		end
	end

	-- Camera FIXE devant le model (+X direction) ; le model rotate sur place via yaw
	-- => entity yaw=0 face +X = face a la camera. Drag horizontal change le yaw du model
	-- pour voir tous les cotes sans bouger la cam.
	local yaw       = bSeul and 90 or 0 -- angle de rotation du model (0 = face camera ; fourreau vu de côté)
	local dist      = isWeapon and 130 or 70  -- distance camera (katana/gantelet = dezoom pour voir l'arme)
	if bSeul then dist = math.Clamp((ent:GetModelRadius() or 30) * 2.6, 25, 200) end
	local heightOff = 60     -- hauteur de focus si head bone absent
	local pitch     = 0      -- offset vertical de la cam
	local dragging  = false
	local dragStart = nil

	mdl.LayoutEntity = function(pnl, e)
		if not IsValid(e) then return end
		e:FrameAdvance(FrameTime())
		e:SetAngles(Angle((bSeul and not itemData.compagnon_id) and -35 or 0, yaw, 0)) -- fourreau incliné, compagnon debout

		-- Focus : tete si possible, sinon hauteur fixe (fourreau : centre du modèle)
		local headBone = (not bSeul) and e:LookupBone("ValveBiped.Bip01_Head1")
		local focus
		if bSeul then
			local mn, mx = e:GetModelRenderBounds()
			focus = e:LocalToWorld((mn + mx) * 0.5)
		end
		if headBone and headBone >= 0 then
			local mat = e:GetBoneMatrix(headBone)
			if mat then
				focus = mat:GetTranslation()
			end
		end
		if not focus then
			focus = e:GetPos() + Vector(0, 0, heightOff)
		end
		-- Camera fixe au +X du focus : le model face +X (yaw=0) regarde la camera.
		local cam = focus + Vector(dist, 0, pitch)
		pnl:SetLookAt(focus)
		pnl:SetCamPos(cam)
		pnl:SetFOV(35)
	end

	-- Drag-to-rotate
	mdl.OnMousePressed = function(_, key)
		if key == MOUSE_LEFT then
			dragging = true
			dragStart = { x = gui.MouseX(), y = gui.MouseY(), yaw = yaw, pitch = pitch }
		end
	end
	mdl.OnMouseReleased = function(_, key)
		if key == MOUSE_LEFT then dragging = false end
	end
	mdl.Think = function()
		if dragging and dragStart then
			local dx = gui.MouseX() - dragStart.x
			local dy = gui.MouseY() - dragStart.y
			yaw   = dragStart.yaw + dx * 0.5
			pitch = math.Clamp(dragStart.pitch - dy * 0.3, -25, 25)
		end
	end
	-- Zoom molette
	mdl.OnMouseWheeled = function(_, delta)
		dist = math.Clamp(dist - delta * 6, 25, 200)
	end

	-- Cleanup
	frame.OnRemove = function()
		if IsValid(frame._backdrop) then frame._backdrop:Remove() end
		cleanupTracked(tracked)
		if LZY_SHOP_COSMETIC_PREVIEW._currentFrame == frame then
			LZY_SHOP_COSMETIC_PREVIEW._currentFrame = nil
		end
	end
end
