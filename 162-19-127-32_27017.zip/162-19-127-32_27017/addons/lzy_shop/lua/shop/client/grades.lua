-- "addons\\lzy_shop\\lua\\shop\\client\\grades.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Confirmation d'achat (demande user 2026-07-16) : popup "Confirmer l'achat ?" avant
-- d'envoyer l'achat au serveur (meme pattern que le night market).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_Premium_Buy = function(args)
	if not args or not args.index then return end
	net.Start("server:lzy_shop.premium_buy")
		net.WriteUInt(tonumber(args.index) or 0, 8)
	net.SendToServer()
end

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- ============================================================================
-- DESIGN VALORANT (mirror cut_line/pack_opening) : DHTML frame + material
-- background custom (ncm_combat/grade_{1,2,3}.png) + features list HTML +
-- bar bottom + gift/buy slide-up + state "ACQUIS" si tier deja possede.
-- ============================================================================

local SHOP_GRADES_WIDTH = 1840
local GRADE_CARD_W = 352
local GRADE_CARD_H = 764
local GRADE_GAP = 20

-- Coin image inline en base64.
local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- Couleur de bordure par tier (offerIndex).
-- Tier 1 Premium = violet, Tier 2 VIP = jaune gold, Tier 3 Platinum = rouge.
local function GetTierColor(tier)
	if tier == 3 then
		return Color(255, 80, 80, 240)    -- rouge (Platinum, top)
	elseif tier == 2 then
		return Color(255, 210, 90, 240)   -- jaune gold (VIP, mid)
	else
		return Color(150, 70, 220, 240)   -- violet (Premium, low)
	end
end

-- Pour les bg images : asset:// (loader natif Chromium) plus rapide que base64
-- pour les grosses images (decode quasi-instant vs 100-300ms en data:URI).
local function GetMatDataURI(matPath)
	if not isstring(matPath) or matPath == "" then return "" end
	return "asset://garrysmod/materials/" .. matPath
end

-- ============================================================================
-- Template HTML/CSS : frame Valorant + material BG + features + bar bottom.
-- 13 placeholders : 11 rgb + matURI + bodyHTML.
-- ============================================================================
local CARD_FRAME_HTML_GRADE = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
.wrap { position:relative; width:100%%; height:100%%; transition: transform 0.2s ease-out; }
.border {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
}
.border::before {
	content:''; position:absolute; top:-4px; right:-4px; bottom:-4px; left:-4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity:0.35;
}
.border::after {
	content:''; position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:#0a0a0e;
}
.crate {
	position:absolute; top:4px; right:4px; bottom:4px; left:4px;
	background: radial-gradient(ellipse at top, rgba(%s, 0.20) 0%%, rgba(0,0,0,0.96) 70%%), #0a0a0e;
	overflow:hidden; z-index:1;
}
.grade-bg {
	position:absolute; top:0; left:0; right:0; bottom:0;
	background-size: 60%%;
	background-position: center 7%%;
	background-repeat: no-repeat;
	z-index: 0;
	opacity: 0.95;
}
.grade-bg::after {
	content:''; position:absolute; top:0; left:0; right:0; bottom:0;
	background: linear-gradient(to bottom, transparent 0%%, transparent 35%%, rgba(0,0,0,0.90) 78%%, rgba(0,0,0,1) 100%%);
}
.corner { display:none;
	position:absolute; width:22px; height:22px;
	border:2px solid rgba(%s, 0.9); z-index:3;
	transition: border-color 0.15s ease-out;
}
.corner.tl { top:12px; left:12px; border-right:none; border-bottom:none; }
.corner.tr { top:12px; right:12px; border-left:none; border-bottom:none; }
.corner.bl { bottom:82px; left:12px; top:auto; border-right:none; border-top:none; }
.corner.br { bottom:82px; right:12px; top:auto; border-left:none; border-top:none; }
/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }
@keyframes sweep {
	0%%   { transform: translate3d(-120px, 0, 0) skewX(-25deg); }
	100%% { transform: translate3d(420px, 0, 0) skewX(-25deg); }
}
body.hovered .wrap { transform: scale(1.015); }
.hover-glow {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: radial-gradient(ellipse at center, rgba(%s, 0.28) 0%%, transparent 65%%);
	opacity: 0; transition: opacity 0.2s ease-out;
	pointer-events: none; z-index: 2;
}
body.hovered .hover-glow { opacity: 1; }
body.hovered .corner { display:none; border-color: rgba(%s, 1); }

/* ACQUIS overlay si owned (push class par Lua Think) */
.owned-label {
	position: absolute;
	top: 65%%; left: 0; right: 0;
	text-align: center;
	z-index: 6;
	display: none;
	pointer-events: none;
}
body.owned .owned-label { display: block; }
body.owned .bar { opacity: 0.4; }
.owned-main {
	display: block;
	font-size: 32px;
	font-weight: 900;
	letter-spacing: 8px;
	color: rgb(0, 235, 120);
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}

/* Grade title en haut, sobre */
.grade-title {
	position: absolute;
	top: 24px; left: 0; right: 0;
	z-index: 5;
	text-align: center;
	font-size: 26px;
	font-weight: 700;
	color: rgba(%s, 0.95);
	letter-spacing: 6px;
	text-shadow: 0 2px 8px rgba(0,0,0,0.9);
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
}

/* Features list au centre.
   Fonts en vw (viewport width = largeur du panel DHTML) -> scaling automatique
   avec la taille de la card. Card de reference = 352px de large.
   8.5vw ≈ 30px @ 352w, 4.5vw ≈ 16px @ 352w, etc.
   top: 32%% -> remonte les descriptions plus pres du titre du grade pour eviter
   qu'elles flottent trop bas et collent visuellement a la bar du prix. */
.features {
	position: absolute;
	top: 41%%; left: 0; right: 0;
	padding: 0 7.5%%;
	z-index: 5;
}
.features.platinum { top: 32%%; }
.feat {
	display: block;
	font-size: 6vw;
	font-weight: 800;
	color: #fff;
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
	letter-spacing: 0.2vw;
	line-height: 1.35;
	padding-left: 6vw;
	position: relative;
	margin-bottom: 3vw;
}
.feat::before {
	content: '';
	position: absolute;
	top: 3vw; left: 0;
	width: 2.5vw; height: 2.5vw;
	background: rgba(%s, 0.95);
	box-shadow: 0 0 2.5vw rgba(%s, 0.85);
}
/* Petite description sous une feature line (italic, dim, plus petite) */
.feat-desc {
	display: block;
	font-size: 3.5vw;
	font-weight: 500;
	color: rgba(255, 255, 255, 0.65);
	text-shadow: 0 1px 8px rgba(0,0,0,0.9);
	letter-spacing: 0.1vw;
	line-height: 1.25;
	margin-top: 0.6vw;
	font-style: italic;
}

/* Bar bottom : 72px */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 72px;
	background: linear-gradient(to top, rgba(0,0,0,0.97) 0%%, rgba(0,0,0,0.6) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 24px;
	z-index: 5;
}
.bar::before {
	content: ''; position: absolute;
	top: 0; left: 18px; right: 18px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.75), transparent);
}
.bar-name {
	font-size: 34px;
	color: #fff;
	font-weight: 800;
	letter-spacing: 4px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 8px; }
.bar-old {
	font-size: 20px;
	color: rgba(255,255,255,0.45);
	text-decoration: line-through;
	text-decoration-color: rgba(255, 80, 80, 0.85);
	letter-spacing: 1px;
	font-weight: 700;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-discount {
	font-size: 20px;
	color: rgb(255, 80, 80);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-price {
	font-size: 34px;
	color: rgb(0, 235, 120);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-free {
	font-size: 28px;
	color: rgba(255,255,255,0.6);
	font-weight: 700;
	letter-spacing: 2px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-coin {
	width: 24px; height: 24px;
	image-rendering: -webkit-optimize-contrast;
}
</style></head>
<body>
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="grade-bg" style="background-image: url('%s');"></div>
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="glint"></div>
			<div class="hover-glow"></div>
			<div class="owned-label">
				<span class="owned-main">ACQUIS</span>
			</div>
			%s
		</div>
	</div>
</body></html>
]]

function PANEL:CreateGrade(row, x, offerIndex)
	local name  = row.name or "?"
	local price = tonumber(row.price) or 0
	local yen   = tonumber(row.yen) or 0
	local slot  = tonumber(row.slot) or 0
	local exp   = tonumber(row.exp) or 0
	local rerollArt    = tonumber(row.reroll_art) or 0
	local rerollCombat = tonumber(row.reroll_combat) or 0
	local tier  = tonumber(row.tier) or offerIndex

	-- Image custom par offerIndex
	local GRADE_IMG = { "tr1hvwro4i8ad", "td4tr10ji55zk", "z83u35503ma6dyk" }
	local matPath = "a4xy732ex6yeop2/" .. (GRADE_IMG[offerIndex] or GRADE_IMG[1]) .. ".png"

	local borderCol  = GetTierColor(tier)
	local rgb        = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local matDataURI = GetMatDataURI(matPath)

	-- Discount creator code
	local finalPrice, hasDiscount = GetDiscountedPrice(price)
	local discPct = hasDiscount and SHOP_CONFIG.CREATOR_CODE_DISCOUNT or 0

	-- Features HTML dynamiques (selon les champs du row)
	local featParts = {}
	if yen ~= 0 then
		-- Icône argent du HUD à la place du « ¥ » (data-URI, comme la pièce bar-coin) ;
		-- fallback texte ¥ si le PNG n'a pas pu être lu. Style inline : la CSS de cette
		-- carte passe par string.format (les % d'une classe seraient interprétés).
		local sMoneyIcon = (MUGEN and MUGEN.MoneyIconDataURI and MUGEN.MoneyIconDataURI()) or ""
		if sMoneyIcon ~= "" then
			featParts[#featParts + 1] = string.format('<span class="feat">%d <img src="%s" style="height:1.3em;width:auto;vertical-align:-0.28em;"></span>', yen, sMoneyIcon)
		else
			featParts[#featParts + 1] = string.format('<span class="feat">%d ¥</span>', yen)
		end
	end
	if rerollArt > 0 then
		featParts[#featParts + 1] = string.format('<span class="feat">+%d Reroll Art Spirituel</span>', rerollArt)
	end
	if rerollCombat > 0 then
		featParts[#featParts + 1] = string.format('<span class="feat">+%d Reroll Style de Combat</span>', rerollCombat)
	end
	if exp ~= 0 then
		featParts[#featParts + 1] = string.format('<span class="feat">%sx EXP</span>', tostring(exp))
	end
	if slot ~= 0 then
		featParts[#featParts + 1] = string.format('<span class="feat">+%d Slot perso</span>', slot)
	end
	if row.bp_premium == true then
		featParts[#featParts + 1] = '<span class="feat">Battlepass Premium</span>'
	end
	-- Coupe-file inclus dans le grade : on PRÉCISE lequel (Premium niv.1 / VIP niv.2).
	-- VIP passe devant Premium dans la file (queue_bypass plus élevé).
	local cfLevel = tonumber(row.coupe_file_level) or 0
	if cfLevel > 0 then
		local cfName = (cfLevel >= 2) and "VIP" or "Premium"
		featParts[#featParts + 1] =
			'<span class="feat">Coupe-file ' .. cfName ..
			'<span class="feat-desc">Priorité dans la file d\'attente</span>' ..
			'</span>'
	end
	if row.reroll_advantage == true then
		-- Feature avec description sous-titre : explique ce que ça débloque
		-- concrètement (sinon "Sécurité Reroll" tout seul est cryptique).
		featParts[#featParts + 1] =
			'<span class="feat">Sécurité Reroll' ..
			'<span class="feat-desc">Garde ton drop actuel si le reroll est moins bon</span>' ..
			'</span>'
	end
	if tier == 3 then
		featParts[#featParts + 1] =
			'<span class="feat">Sécurité pity' ..
			'<span class="feat-desc">Garde ta pity si tu refuses le drop</span>' ..
			'</span>'
	end
	local featuresClass = tier == 3 and "features platinum" or "features"
	local featuresHTML = string.format('<div class="%s">%s</div>', featuresClass, table.concat(featParts))

	-- Title en haut spaced caps
	local titleHTML = string.format('<div class="grade-title">%s</div>', string.upper(name))

	-- Bar HTML : site / free / price / discount
	local barHTML
	if SHOP_CONFIG.GRADES_SITE_ONLY then
		-- Vitrine : on montre ce que contient le grade, pas un prix en coins qu'on
		-- ne peut plus payer ici.
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-free">SUR LE SITE</span>
	</span>
</div>
]], string.upper(name))
	elseif price <= 0 then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-free">GRATUIT</span>
	</span>
</div>
]], string.upper(name))
	elseif hasDiscount then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-old">%d</span>
		<span class="bar-discount">-%d%%</span>
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(name), price, discPct, finalPrice, _COIN_DATA_URI)
	else
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(name), price, _COIN_DATA_URI)
	end

	local innerHTML = titleHTML .. featuresHTML .. barHTML

	-- ========================================================================
	-- Background (statique 352x764) porte le DHTML frame Valorant.
	-- ========================================================================
	local background = gPanel(x, 37, GRADE_CARD_W, GRADE_CARD_H, self)
	background._offerIndex = offerIndex
	background.Paint = function() end

	local frame = vgui.Create("DHTML", background)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(string.format(CARD_FRAME_HTML_GRADE,
		rgb, rgb, rgb,    -- border (3)
		rgb, rgb, rgb,    -- border::before (3)
		rgb,              -- crate radial (1)
		rgb,              -- corner (1)
		rgb,              -- hover-glow (1)
		rgb,              -- corner hover (1)
		rgb,              -- grade-title color (1)
		rgb, rgb,         -- feat::before bullet (2)
		rgb,              -- bar lisere (1)
		matDataURI,       -- background image URI
		innerHTML
	))
	background._dhtmlFrame = frame

	-- ========================================================================
	-- Container (slide-up 50px pour reveal gift/buy au hover) + hover detection
	-- ========================================================================
	-- Forward-declare `buy` ici pour que le closure de container.Think capture
	-- la variable locale (assignee plus bas), sinon Lua capture le global nil.
	local buy
	local container = gPanel(0, 0, GRADE_CARD_W, GRADE_CARD_H + 50, background)
	container:SetMouseInputEnabled(true)
	background._container = container

	container.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		-- 1er frame : sync l'etat sans declencher d'animation. Sinon si la
		-- souris est deja par-dessus la card a l'ouverture du tab, le Think
		-- detecte un changement nil->true et tire un slide-up indesire.
		if selff._hovered == nil then
			selff._hovered = inside
			if inside and IsValid(frame) then
				frame:RunJavascript("if(document.body){document.body.classList.add('hovered');}")
			end
			return
		end
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
			if inside then
				selff:gMoveToY(-50, 0.2, 0, 4)
			else
				timer.Simple(0.05, function()
					if IsValid(selff) and not selff._hovered then
						selff:gMoveToY(0, 0.2, 0, 4)
					end
				end)
			end
		end
	end
	container.Paint = function() end

	-- ========================================================================
	-- Bouton OFFRIR (gift) : moitie gauche du bas.
	-- Retire quand les grades sont reserves au site : offrir reste un achat en
	-- coins, le laisser rouvrirait la porte qu'on vient de fermer.
	-- ========================================================================
	if not SHOP_CONFIG.GRADES_SITE_ONLY then
		local gift = gPanel(0, GRADE_CARD_H, GRADE_CARD_W / 2, 50, container)
		gift.opacity = 0.20
		gift:SetCursor("hand")
		gift.OnCursorEntered = function() gift.opacity = 0.40 end
		gift.OnCursorExited  = function() gift.opacity = 0.20 end
		gift.OnMousePressed = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			local giftPanel = vgui.Create("LZY:Shop:Gift", self:GetParent())
			giftPanel.giftType = "premium"
			giftPanel.configIndex = offerIndex
		end
		gift.Paint = function()
			rRect(0, 0, GRADE_CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
			rRect(0, 0, GRADE_CARD_W / 2, 50, Color(0, 255, 9, 255 * gift.opacity))
			rSimpleText("OFFRIR", "Avenir Next World:20", GRADE_CARD_W / 4, 25,
				Color(0, 255, 9), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- ========================================================================
	-- Grades reserves au site : un seul bouton pleine largeur qui ouvre la
	-- boutique. Pas de prix en coins, pas d'achat possible ici.
	-- ========================================================================
	if SHOP_CONFIG.GRADES_SITE_ONLY then
		buy = gPanel(0, GRADE_CARD_H, GRADE_CARD_W, 50, container)
		buy._rowTier = tier
		buy.opacity = 0.30
		buy:SetCursor("hand")
		buy.OnCursorEntered = function() buy.opacity = 0.50 end
		buy.OnCursorExited  = function() buy.opacity = 0.30 end
		buy.OnMousePressed = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			gui.OpenURL(SHOP_CONFIG.GRADES_SITE_URL or "https://evo-roleplay.com/BleachRP/boutique.html")
		end
		buy.Paint = function()
			rRect(0, 0, GRADE_CARD_W, 50, color_white, 0, RNDX.BLUR)
			if buy._owned then
				rRect(0, 0, GRADE_CARD_W, 50, Color(80, 80, 80, 255 * buy.opacity))
				rSimpleText("ACQUIS", "Avenir Next World:20", GRADE_CARD_W / 2, 25,
					Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				rRect(0, 0, GRADE_CARD_W, 50,
					Color(borderCol.r, borderCol.g, borderCol.b, 255 * buy.opacity))
				local lblCol = Color(
					math.min(borderCol.r + 50, 255),
					math.min(borderCol.g + 50, 255),
					math.min(borderCol.b + 50, 255))
				rSimpleText("VOIR SUR LE SITE", "Avenir Next World:20", GRADE_CARD_W / 2, 25,
					lblCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		self._buyBtns = self._buyBtns or {}
		self._buyBtns[offerIndex] = buy
		background._buyBtn = buy
		return background
	end

	-- ========================================================================
	-- Bouton ACHETER (buy) : moitie droite, couleur tier ou greyed si owned.
	-- ========================================================================
	-- Assigne (pas `local`) sur la variable forward-declared plus haut, pour
	-- que container.Think capture la bonne reference dans son closure.
	buy = gPanel(GRADE_CARD_W / 2, GRADE_CARD_H, GRADE_CARD_W / 2, 50, container)
	buy._rowTier = tier
	buy.opacity = 0.30
	buy:SetCursor("hand")
	buy.OnCursorEntered = function()
		if buy._owned then return end
		buy.opacity = 0.50
	end
	buy.OnCursorExited = function()
		if buy._owned then return end
		buy.opacity = 0.30
	end
	buy.OnMousePressed = function()
		if buy._owned then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
		-- Confirmation avant achat (demande user) : l'achat part dans le callback popup.
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Confirmer l'achat de " .. name .. " ?", "LzyShop_Premium_Buy", { index = offerIndex })
		end
	end
	buy.Paint = function()
		rRect(0, 0, GRADE_CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
		if buy._owned then
			rRect(0, 0, GRADE_CARD_W / 2, 50, Color(80, 80, 80, 255 * buy.opacity))
			rSimpleText("ACQUIS", "Avenir Next World:20", GRADE_CARD_W / 4, 25,
				Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			-- ACHETER : couleur du tier (matche la border de la case)
			rRect(0, 0, GRADE_CARD_W / 2, 50,
				Color(borderCol.r, borderCol.g, borderCol.b, 255 * buy.opacity))
			local lblCol = Color(
				math.min(borderCol.r + 50, 255),
				math.min(borderCol.g + 50, 255),
				math.min(borderCol.b + 50, 255))
			rSimpleText("ACHETER", "Avenir Next World:20", GRADE_CARD_W / 4, 25,
				lblCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	self._buyBtns = self._buyBtns or {}
	self._buyBtns[offerIndex] = buy
	background._buyBtn = buy

	return background
end

function PANEL:Init()
	self._gradeRoots = self._gradeRoots or {}
	self._buyBtns = {}
	self._lastPremCheck = nil
	local list = PREMIUM_CONFIG or {}
	for i = 1, #list do
		local root = self:CreateGrade(list[i], 0, i)
		self._gradeRoots[i] = root
	end
	self:PerformLayout()
end

function PANEL:Think()
	if not self._buyBtns then return end
	local p = LocalPlayer()
	if not IsValid(p) then return end
	local pr = p:GetEvoNWInt("premium", 0)
	if self._lastPremCheck ~= nil and pr == self._lastPremCheck then return end
	self._lastPremCheck = pr
	for idx, b in pairs(self._buyBtns) do
		if IsValid(b) then
			local t = b._rowTier or 0
			local owned = t > 0 and pr >= t
			b._owned = owned
			if owned then
				b:SetMouseInputEnabled(false)
				b:SetCursor("no")
			else
				b:SetMouseInputEnabled(true)
				b:SetCursor("hand")
			end
			-- Push owned class au DHTML frame correspondant
			local root = self._gradeRoots and self._gradeRoots[idx]
			if IsValid(root) and root._dhtmlFrame and IsValid(root._dhtmlFrame) then
				root._dhtmlFrame:RunJavascript(owned
					and "if(document.body){document.body.classList.add('owned');}"
					or  "if(document.body){document.body.classList.remove('owned');}")
			end
		end
	end
end

function PANEL:PerformLayout()
	local w = 1840
	if w < 1 then w = SHOP_GRADES_WIDTH end
	local list = PREMIUM_CONFIG or {}
	local n = #list
	if n == 0 or not self._gradeRoots then return end
	local totalW = n * GRADE_CARD_W + math.max(0, n - 1) * GRADE_GAP
	local x = math.floor((w - totalW) / 2)
	for i = 1, n do
		local root = self._gradeRoots[i]
		if IsValid(root) and root.gSetPos then
			root:gSetPos(x, 115)
		elseif IsValid(root) and root.SetPos then
			root:SetPos(x, 115)
		end
		x = x + GRADE_CARD_W + GRADE_GAP
	end
end

function PANEL:Paint(w, h)
	-- (Titre interne « GRADES » RETIRÉ — 08/07 : le nom de la catégorie est
	-- affiché en haut-centre par l'accueil boutique, il était en DOUBLE ici.)
end

vgui.Register("LZY:Shop:Grades", PANEL, "DPanel")

-- ============================================================================
-- CHOIX DU PERSONNAGE POUR LES YENS D'UN GRADE ACHETE HORS JEU
--
-- Les yens sont PAR PERSONNAGE. Un grade achete sur le site peut arriver alors
-- que le joueur n'a jamais joue, ou qu'il a plusieurs persos (Shinigami ET
-- Hollow) : on lui demande donc lequel crediter, a son chargement de perso.
--
-- L'argent reste dans l'escrow serveur (table evo_stripe) tant qu'il n'a pas
-- repondu. Fermer cette fenetre ne fait RIEN perdre : la question revient au
-- prochain chargement de perso. C'est volontaire — on ne force personne.
--
-- Loge ICI et pas dans un fichier neuf : un nouveau fichier client (CS-Lua)
-- imposerait un restart serveur pour etre transmis aux joueurs.
-- ============================================================================

local YEN_ASK_W, YEN_ASK_ROW_H = 460, 54

net.Receive("EVO:Stripe:YenTargetAsk", function()
	local amount = net.ReadUInt(32)
	local n      = net.ReadUInt(8)
	local chars  = {}
	for i = 1, n do
		chars[i] = {
			uid  = net.ReadString(),
			name = net.ReadString(),
			lvl  = net.ReadUInt(16),
		}
	end
	if #chars == 0 then return end

	local h = 118 + #chars * (YEN_ASK_ROW_H + 8) + 14
	local frame = vgui.Create("DFrame")
	frame:SetSize(YEN_ASK_W, h)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end -- APRES MakePopup

	frame.Paint = function(_, w, hh)
		draw.RoundedBox(10, 0, 0, w, hh, Color(14, 14, 17))            -- carte DA
		draw.RoundedBox(10, 0, 0, w, 3, Color(207, 68, 78))            -- accent
		draw.SimpleText("RECOMPENSE DE GRADE", "DermaLarge", w * 0.5, 30,
			Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Sur quel personnage veux-tu recevoir tes " .. string.Comma(amount) .. " yens ?",
			"DermaDefault", w * 0.5, 62, Color(160, 160, 170), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Tu peux fermer : la question reviendra a ta prochaine connexion.",
			"DermaDefault", w * 0.5, hh - 16, Color(110, 110, 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local y = 92
	for _, c in ipairs(chars) do
		local btn = vgui.Create("DButton", frame)
		btn:SetPos(16, y)
		btn:SetSize(YEN_ASK_W - 32, YEN_ASK_ROW_H)
		btn:SetText("")
		btn.Paint = function(pnl, w, hh)
			local bg = pnl:IsHovered() and Color(30, 30, 36) or Color(22, 22, 27)
			draw.RoundedBox(8, 0, 0, w, hh, bg)
			if pnl:IsHovered() then draw.RoundedBox(8, 0, 0, 3, hh, Color(207, 68, 78)) end
			draw.SimpleText(c.name ~= "" and c.name or "Personnage", "DermaDefaultBold", 16, hh * 0.5 - 8,
				Color(235, 235, 240), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("Niveau " .. c.lvl, "DermaDefault", 16, hh * 0.5 + 10,
				Color(140, 140, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("+" .. string.Comma(amount) .. " ¥", "DermaDefaultBold", w - 16, hh * 0.5,
				Color(207, 68, 78), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = function()
			surface.PlaySound("buttons/button14.wav")
			net.Start("EVO:Stripe:YenTargetPick")
				net.WriteString(c.uid)
			net.SendToServer()
			frame:Close()
		end
		y = y + YEN_ASK_ROW_H + 8
	end
end)
