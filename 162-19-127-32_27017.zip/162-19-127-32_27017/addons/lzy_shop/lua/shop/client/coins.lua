-- "addons\\lzy_shop\\lua\\shop\\client\\coins.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Config tiers : { coins, prix_eur, bonus_coins }
local coins_config = {
	{450,   5,   0},
	{1000,  10,  100},
	{2000,  20,  200},
	{3000,  30,  300},
	{5000,  50,  500},
	{10000, 100, 1000},
	{20000, 200, 2000},
	{30000, 300, 5000},
}

-- ============================================================================
-- DA DASHBOARD (08/07) : plaque Atelier PLATE à coins coupés (tr-bl) + vis
-- d'angle + voile clair et bordure ACCENT extérieure au survol + CTA
-- « ACHETER » plein accent (coin bas-droit coupé). Remplace le chrome DHTML
-- Valorant. Ambiance DORÉE : c'est la page d'ACHAT de coins, elle doit
-- ressortir du reste de la boutique (accent = or, pas le rouge standard).
-- Le coin (PNG haute résolution) reste rendu en Lua surface : net à tous les
-- zooms, taille croissante par tier pour signifier la valeur.
-- ============================================================================

local ACCENT    = Color(255, 205, 60)  -- ambiance dorée de la catégorie
local COL_BONUS = Color(255, 80, 80)   -- badge promo « +N » (fonctionnel, conservé)
local COL_MUTED = Color(150, 154, 162)

-- Coin unique fourni par l'utilisateur : ncm_combat/coin_gros.png
-- (image custom haute resolution). Rendu centre, taille croissante par tier.
local _COIN_MAT = Material("a4xy732ex6yeop2/m3vznbexvus1qa1.png", "smooth")

-- Taille du coin par tier : croissance progressive pour signifier la valeur.
-- Design space 322x302 (coin area = 232 haut). T1 reste compact, T8 a peine
-- plus gros qu'avant pour pas saturer la case.
local _TIER_COIN_SIZE = {
	[1] = 80,
	[2] = 95,
	[3] = 110,
	[4] = 125,
	[5] = 140,
	[6] = 155,
	[7] = 170,
	[8] = 185,
}

function PANEL:CreateTier(tier, coins, price, plus, x, y)
	local container = gPanel(x, y, 322, 302, self)
	container:SetMouseInputEnabled(true)
	container:SetCursor("hand")

	local coinSz  = _TIER_COIN_SIZE[tier] or 150
	local coinMat = _COIN_MAT

	-- Position verticale du CTA "ACHETER" : il suit le BAS du coin pour que, sur
	-- les gros coins (tiers eleves), il DESCENDE au lieu de rester fige. Le coin
	-- est centre a ~116/302 -> bas du coin = 116 + coinSz/2 (en % de la hauteur
	-- de la card). On borne (52-64%) pour ne jamais chevaucher la bar du bas.
	local coinBottomPct = (116 + coinSz * 0.5) / 302 * 100
	local achatTopFrac  = math.Clamp(coinBottomPct - 4, 52, 64) / 100

	local startT = SysTime()
	-- Ratios design : sur 322x302, le coin area fait 232 de haut (bar=70).
	local COIN_AREA_RATIO = 232 / 302

	container.Paint = function(s, w, h)
		-- 1) Plaque plate Atelier : fond sombre, coins coupés tr-bl, éclaircie
		--    au survol. PAS de liseré au repos (recette dashboard).
		local hf    = EVO_UI.HoverFrac(s, 10)
		local plate = hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 235)
		local pts   = EVO_UI.PaintCut(0, 0, w, h, plate, gRespY(14))

		-- 2) Coin : bob doux, centre dans la zone haute (rendu Lua surface =
		--    net a tous les zooms — les images CEF DHTML perdaient en qualite).
		local t     = SysTime() - startT
		local areaH = h * COIN_AREA_RATIO
		local scale = w / 322
		local sz    = coinSz * scale
		local bob   = math.sin(t * 1.6) * (3 * scale)
		local cx, cy = w / 2, areaH / 2 + bob
		local half   = sz / 2
		local dx, dy = cx - half, cy - half
		surface.SetMaterial(coinMat)
		surface.SetDrawColor(0, 0, 0, 60)
		surface.DrawTexturedRect(dx + 1 * scale, dy + 2 * scale, sz, sz)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(dx, dy, sz, sz)

		-- 3) Bar bottom (70 design) : liseré ACCENT + montants.
		local barY = h - gRespY(70)
		surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 140 + 60 * hf)
		surface.DrawRect(gRespX(16), barY, w - gRespX(32), 1)

		-- Montant de coins (Bebas blanc) + bonus promo « +N » (rouge, conservé).
		local lx = gRespX(20)
		draw.SimpleText(coins, "Bebas Neue:32", lx, barY + gRespY(21),
			color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if plus > 0 then
			surface.SetFont("Bebas Neue:32")
			local tw = surface.GetTextSize(tostring(coins))
			draw.SimpleText("+" .. plus, "Bebas Neue:20", lx + tw + gRespX(6), barY + gRespY(23),
				COL_BONUS, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("COINS", "Avenir Next World:12", lx, barY + gRespY(50),
			COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Prix EUR a droite : ACCENT doré, Bebas.
		local rx = w - gRespX(20)
		surface.SetFont("Bebas Neue:24")
		local ew = surface.GetTextSize("€")
		draw.SimpleText("€", "Bebas Neue:24", rx, barY + gRespY(35),
			ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(price, "Bebas Neue:38", rx - ew - gRespX(4), barY + gRespY(35),
			ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		-- 4) Vis d'angle : retrait UNIFORME 16px aux 4 coins (recette dashboard).
		local sr = gRespY(4)
		local mx, my = gRespX(16), gRespY(16)
		EVO_UI.Screw(mx, my, sr)
		EVO_UI.Screw(w - mx, my, sr)
		EVO_UI.Screw(w - mx, h - my, sr)
		EVO_UI.Screw(mx, h - my, sr)

		-- 5) Survol : voile clair + bordure ACCENT extérieure (2 passes ≈ 2px)
		--    + CTA « ACHETER » plein accent, coin bas-droit coupé, texte Bebas.
		if hf > 0.02 then
			draw.NoTexture()
			surface.SetDrawColor(226, 230, 238, 10 * hf)
			surface.DrawPoly(pts)
			-- Bordure INSET 1px (fix 08/07 : tracée sur les bornes exactes du
			-- panneau clippé, les bords droit/bas étaient COUPÉS = « pas clean »).
			EVO_UI.HoverOutline(w, h, ColorAlpha(ACCENT, 235 * hf), gRespY(14))

			local bw, bh = gRespX(120), gRespY(36)
			local bx, by = (w - bw) / 2, h * achatTopFrac
			EVO_UI.PaintCut(bx, by, bw, bh, ColorAlpha(ACCENT, 235 * hf), gRespY(8), "br")
			draw.SimpleText("ACHETER", "Bebas Neue:22", bx + bw / 2, by + bh / 2,
				ColorAlpha(color_white, 255 * hf), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	container.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		-- L'achat de coins se fait sur le SITE (paiement Stripe). On ouvre la
		-- boutique web (pack pré-sélectionné) DANS LE JEU via evo_weblink :
		-- gui.OpenURL seul = overlay Steam, qui n'affiche RIEN si l'overlay est
		-- désactivé ("ça dit que ça ouvre le site mais rien ne s'ouvre").
		local url = "https://evo-roleplay.com/BleachRP/boutique.html?pack=p" .. coins
		if EVO_OpenWeb then
			EVO_OpenWeb(url, "Boutique Coins — EVO")
		else
			gui.OpenURL(url)
			if MUGEN and MUGEN.Notify then MUGEN.Notify("Boutique ouverte dans l'overlay Steam.", NOTIFY_HINT or 4, 4) end
		end
	end
end

-- Callback popup (la vraie logique d'achat coins n'est pas encore branchee).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_CoinsBuy = function(args)
	if not args or not args.tier then return end
	LocalPlayer():PrintMessage(HUD_PRINTCONSOLE, string.format(
		"[Shop] Achat coins tier %d (%d coins / %d€) -- logique a brancher",
		args.tier, args.coins or 0, args.price or 0
	))
end

function PANEL:Init()
	local x = 226 - 40
	local y = 145

	for i = 1, #coins_config do
		self:CreateTier(i, coins_config[i][1], coins_config[i][2], coins_config[i][3], x, y)

		x = x + 370 + 20
		if i % 4 == 0 then
			x = 226 - 40
			y = y + 321 + 20
		end
	end
end

function PANEL:Paint()
	-- (Titre interne RETIRÉ — 08/07 : le titre de la catégorie est affiché en
	-- haut-centre par l'accueil boutique, il était en DOUBLE ici.)
end

vgui.Register("LZY:Shop:Coins", PANEL, "DPanel")
