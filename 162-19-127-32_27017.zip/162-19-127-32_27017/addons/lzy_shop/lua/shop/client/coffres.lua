-- "addons\\lzy_shop\\lua\\shop\\client\\coffres.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Coffres Cosmétiques : 4 coffres par catégorie (Tenues, Accessoires, Katanas, Hakuda),
-- 300 coins, doublons autorisés, bouton i = aperçu du contenu possible, animation
-- d'ouverture DHTML (célébration renforcée légendaire/mythique), + Recycleur
-- (1 cosmétique recyclé = des YENS selon sa rareté). Jetons supprimés (user 08/12).
-- Design local 1840x950 (monté par main.lua OpenCategory) ; le titre de catégorie
-- est dessiné par la frame parente.

local PANEL = {}

local _active -- instance ouverte (une seule à la fois)
local _tokens = {} -- jetons cadeau du compte : [tier.id] = n (serveur : coffre_tokens)

net.Receive("server:lzy_shop.coffre_tokens", function()
	_tokens = {}
	for _ = 1, net.ReadUInt(5) do
		local sId = net.ReadString()
		_tokens[sId] = net.ReadUInt(16)
	end
end)

-- ============================================================================
-- Confirmations d'achat (pattern cosmetiques/cut_line).
-- ============================================================================
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_Coffre_Open = function(args)
	if not args or not args.tier then return end
	local tierIdx = tonumber(args.tier) or 0
	-- LOT (09/07) : 1..3 coffres d'un coup, même contrat net que RÉOUVRIR.
	local nCount = math.Clamp(math.floor(tonumber(args.count) or 1), 1, 3)
	if IsValid(_active) then
		_active:StartOpening(tierIdx, nCount)
	end
	net.Start("server:lzy_shop.coffre_open")
		net.WriteUInt(tierIdx, 4)
		net.WriteUInt(nCount, 2)
		net.WriteBool(args.token == true) -- ouverture avec un JETON cadeau (09/28)
	net.SendToServer()
end
-- Cadeau (09/28) : le destinataire reçoit un JETON de ce coffre.
LZY_POPUP_CALLBACKS.LzyShop_Coffre_Gift = function(args)
	if not args or not args.tier or not IsValid(args.target) then return end
	net.Start("server:lzy_shop.coffre_gift")
		net.WriteUInt(tonumber(args.tier) or 0, 4)
		net.WriteEntity(args.target)
	net.SendToServer()
end
-- Recyclage à l'UNITÉ : un seul id envoyé (le serveur n'en lit qu'un).
LZY_POPUP_CALLBACKS.LzyShop_Coffre_Recycle = function(args)
	if not args or not isstring(args.id) or args.id == "" then return end
	net.Start("server:lzy_shop.coffre_recycle")
		net.WriteString(args.id)
		-- LOT (09/06) : nombre d'exemplaires a recycler d'un coup (1 = ancien comportement).
		net.WriteUInt(math.Clamp(math.floor(tonumber(args.count) or 1), 1, 200), 8)
	net.SendToServer()
end

-- ============================================================================
-- Constantes DA / sons / raretés.
-- ============================================================================
local ACCENT     = Color(207, 68, 78)
local COL_PLATE  = Color(13, 14, 17, 235)
local COL_GOLD   = Color(255, 205, 60)
local COL_MUTED  = Color(150, 154, 162)
local COL_TITLE  = Color(238, 239, 243)

-- Mêmes icônes que le solde de la boutique et l'argent du HUD.
local CURRENCY_ICONS = {
	coins = "fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png",
	yens = "yc5uunqp9of5t/dtv26o0y16owrlzi.png",
}

local SND_CLICK  = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"
local SND_HOVER  = "a4xy732ex6yeop2/g1kpyv29gwai.mp3"
local SND_TICK   = "4wsd81r0bjysb8vy/j7yfn6t0r7a7d.wav"
local SND_REVEAL = "4wsd81r0bjysb8vy/417iarkuz4el6024d.ogg"
local SND_GAIN   = "a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3"

local RARITY_KEYS  = { "common", "rare", "epic", "legendary", "mythic" }
local RARITY_ORDER = { common = 1, rare = 2, epic = 3, legendary = 4, mythic = 5 }
local RARITY_LABEL = {
	common = "COMMUN", rare = "RARE", epic = "ÉPIQUE",
	legendary = "LÉGENDAIRE", mythic = "MYTHIQUE",
}
local RARITY_LABEL_PLUR = {
	common = "communs", rare = "rares", epic = "épiques",
	legendary = "légendaires", mythic = "mythiques",
}
local RARITY_COLOR = {
	common    = Color(180, 180, 180, 255),
	rare      = Color(110, 170, 255, 255),
	epic      = Color(150, 70,  220, 255),
	legendary = Color(255, 210, 90,  255),
	mythic    = Color(255, 95,  95,  255),
}
local function RarityOf(def)
	local r = def and isstring(def.rarity) and string.lower(def.rarity) or "common"
	return RARITY_COLOR[r] and r or "common"
end

-- Identité visuelle par coffre (clé = tier.id de COFFRES_CONFIG).
local TIER_COLOR = {
	tenues      = Color(207, 68, 78),
	accessoires = Color(110, 200, 255),
	armes       = Color(255, 205, 90),
	hakuda      = Color(255, 140, 80),
	visage      = Color(200, 130, 255),
	chapeaux    = Color(110, 200, 255),
	corps       = Color(120, 210, 150),
	pets        = Color(255, 160, 200),
	fourreaux   = Color(190, 150, 100),
	compagnons  = Color(255, 200, 120),
}
local function TierColor(tier)
	return (tier and TIER_COLOR[tier.id]) or ACCENT
end

local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

local function Notify(msg)
	chat.AddText(ACCENT, "[Boutique] ", color_white, msg)
end

-- Yens rendus au recyclage. ⚠ MIROIR de RECYCLE_VALUE dans server/sv_coffres.lua :
-- seul le serveur paie, ici c'est l'aperçu. Une divergence promettrait un montant
-- différent de celui réellement reçu.
local RECYCLE_VALUE = {
	common = 350, rare = 800, epic = 1500, legendary = 7500, mythic = 15000, -- 09/28 : 100/300/500 avant
}
local function RecycleValue(def)
	local r = def and isstring(def.rarity) and string.lower(def.rarity) or "common"
	return RECYCLE_VALUE[r] or RECYCLE_VALUE.common
end

-- Échappe (ne supprime pas) : un nom avec apostrophe doit s'afficher intact.
local function jsEsc(s)
	s = string.gsub(tostring(s or ""), "[\r\n]", " ")
	return (string.gsub(s, "[\\'\"]", "\\%0"))
end

-- Remplacement {{CLE}} -> valeur. TOUJOURS passer par la table (littéral) : un gsub
-- avec remplacement STRING casse sur les % des valeurs CSS.
local function tpl(html, map)
	return (string.gsub(html, "{{(%w+)}}", map))
end

local _iconCache = {}
local function GetIconMat(path)
	if not isstring(path) or path == "" then return nil end
	local m = _iconCache[path]
	if m ~= nil then return m or nil end
	m = Material(path, "smooth")
	_iconCache[path] = (not m:IsError()) and m or false
	return _iconCache[path] or nil
end

-- Le DModelPanel peut arriver PLUS TARD (file lazy-load) : on coupe son mouse
-- input dès qu'il existe, sinon il avale les clics des attrape-clics au-dessus.
local function DisableModelMouse(holder)
	holder.Think = function(s)
		local mp = s._modelPanel
		if IsValid(mp) then
			mp:SetMouseInputEnabled(false)
			s.Think = nil
		end
	end
end

-- Préview d'un item dans `holder` : modèle 3D si possible, sinon icône à plat.
local function SetupItemPreview(holder, def)
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(def) then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, def, 30)
		DisableModelMouse(holder)
		return true
	elseif def.icon then
		local mat = GetIconMat(def.icon)
		if mat then
			holder.Paint = function(s, w, h)
				surface.SetMaterial(mat)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(w * 0.1, h * 0.1, w * 0.8, h * 0.8)
			end
			return true
		end
	end
	return false
end

-- ============================================================================
-- Pool CLIENT d'un coffre (miroir des filtres serveur, doublons autorisés donc
-- identique au pool réel) : catégorie du coffre + faction + genre.
-- ============================================================================
local function CoffreIsPet(def)
	return istable(def) and isstring(def.model_path)
		and string.find(string.lower(def.model_path), "/pet_epaule/", 1, true) ~= nil
end
local POOL_FILTERS = {
	outfit    = function(def) return def.category == "outfit" end,
	accessory = function(def) return def.category == "accessory" end,
	katana    = function(def) return def.skin_id ~= nil end,
	gauntlet  = function(def) return def.gauntlet_id ~= nil end,
	weapon    = function(def) return def.skin_id ~= nil or def.gauntlet_id ~= nil end,
	-- 4 coffres d'accessoires spécialisés (09/08) : `coffre_cat` de la fiche, pets par chemin.
	visage    = function(def) return def.category == "accessory" and def.coffre_cat == "visage" end,
	chapeaux  = function(def) return def.category == "accessory" and def.coffre_cat == "chapeaux" end,
	corps     = function(def) return def.category == "accessory" and def.coffre_cat == "corps" end,
	pets      = function(def) return def.category == "accessory" and CoffreIsPet(def) end,
	fourreaux = function(def) return def.category == "accessory" and def.coffre_cat == "fourreaux" end,
	compagnons = function(def) return def.compagnon_id ~= nil end,
}

local function ChestPoolList(tier)
	local testId = COFFRES_CONFIG and COFFRES_CONFIG.test_item
	if isstring(testId) and testId ~= "" and ITEMS and ITEMS[testId] then
		return { { id = testId, def = ITEMS[testId], rar = RarityOf(ITEMS[testId]) } }
	end
	local lp = LocalPlayer()
	local fac = IsValid(lp) and lp:GetEvoNWString("FactionName", "") or ""
	local gen = (INVENTORY_CONFIG and INVENTORY_CONFIG.NormalizeGender)
		and INVENTORY_CONFIG.NormalizeGender(IsValid(lp) and lp:GetEvoNWString("Gender", "") or "") or nil
	local filter = tier and POOL_FILTERS[tier.pool] or nil
	local out, seen = {}, {}
	for _, row in ipairs(COSMETIQUES_CONFIG or {}) do
		local id = istable(row) and row.item_id
		if isstring(id) and id ~= "" and not seen[id] then
			seen[id] = true
			local def = ITEMS and ITEMS[id]
			-- Miroir EXACT de CoffrePoolBuckets (server/sv_coffres.lua) : exclusivités
			-- de coffre seulement. Tout écart ici ferait mentir l'aperçu du contenu
			-- et les pourcentages par objet affichés à côté.
			if def and row.coffre_only and not row.palier_only -- palier de dépense : jamais au coffre
				and (not filter or filter(def))
				and (not row.faction or row.faction == "" or row.faction == fac) then
				local ig = (INVENTORY_CONFIG and INVENTORY_CONFIG.GetItemGender)
					and INVENTORY_CONFIG.GetItemGender(def) or nil
				if (not ig) or (not gen) or ig == gen then
					out[#out + 1] = { id = id, def = def, rar = RarityOf(def) }
				end
			end
		end
	end
	return out
end

-- Taux affichés = taux appliqués : même résolveur que le serveur, jamais une
-- lecture directe de .weights (cf. COFFRES_CONFIG.WeightsFor).
local function ChestWeights(tier)
	local cfg = COFFRES_CONFIG or {}
	if isfunction(cfg.WeightsFor) then return cfg.WeightsFor(tier) end
	return cfg.weights or {}
end

-- Visuel du coffre : image de la config (asset:// = loader Chromium natif, rapide)
-- si le fichier est monté, sinon repli sur le coffre SVG. Le chemin config peut
-- être SANS extension : on tente tel quel puis .png puis .jpg (même chaîne que
-- les backgrounds workshop, dont l'extension varie d'un pack à l'autre).
local function ChestImgTag(tier, cssClass)
	local p = tier and tier.img
	if not (isstring(p) and p ~= "") then return nil end
	for _, cand in ipairs({ p, p .. ".png", p .. ".jpg" }) do
		if file.Exists("materials/" .. cand, "GAME") then
			return string.format('<img class="%s" src="asset://garrysmod/materials/%s">', cssClass, cand)
		end
	end
	return nil
end

-- ============================================================================
-- SVG du coffre (couleur injectée via {{TIER}} = "r, g, b").
-- ============================================================================
local CHEST_SVG = [[
<svg width="300" height="240" viewBox="0 0 200 160">
	<ellipse cx="100" cy="146" rx="72" ry="12" fill="rgba({{TIER}},0.20)"/>
	<path d="M40 78 v-14 a60 36 0 0 1 120 0 v14 z" fill="#191b21" stroke="rgba({{TIER}},0.9)" stroke-width="3"/>
	<rect x="40" y="78" width="120" height="56" rx="6" fill="#14161b" stroke="rgba({{TIER}},0.9)" stroke-width="3"/>
	<line x1="43" y1="78" x2="157" y2="78" stroke="rgba({{TIER}},0.95)" stroke-width="2.5"/>
	<rect x="90" y="40" width="20" height="94" fill="#1c1e25" stroke="rgba({{TIER}},0.9)" stroke-width="2.5"/>
	<rect x="86" y="84" width="28" height="30" rx="4" fill="#0b0c0f" stroke="rgb({{TIER}})" stroke-width="3"/>
	<circle cx="100" cy="95" r="4.5" fill="rgb({{TIER}})"/>
	<rect x="98" y="97" width="4" height="10" fill="rgb({{TIER}})"/>
</svg>
]]

-- ============================================================================
-- Cartes coffre : un seul DHTML pour toute la grille. Les animations ne tournent
-- que sur la carte survolée ; les boutons restent des panneaux VGUI.
-- ============================================================================
local CARD_SPARKS_CSS, CARD_SPARKS_DIVS
do
	local css, divs = {}, {}
	for i = 1, 10 do
		local x = 8 + ((i * 47) % 84)
		local dur = 2.4 + (i % 5) * 0.45
		local delay = ((i * 13) % 20) * 0.13
		local size = 3 + (i % 3) * 2
		css[#css + 1] = string.format([[
.s%d { left:%d%%; width:%dpx; height:%dpx; -webkit-animation:rise %.2fs linear %.2fs infinite; animation:rise %.2fs linear %.2fs infinite; }
]], i, x, size, size, dur, delay, dur, delay)
		divs[#divs + 1] = string.format('<div class="spark s%d"></div>', i)
	end
	CARD_SPARKS_CSS = table.concat(css)
	CARD_SPARKS_DIVS = table.concat(divs)
end

local CARD_MARKUP = [[
<div class="card" id="chest{{INDEX}}" style="--tier:{{TIER}};"><div class="card-inner">
<div class="wrap">
	<div class="border"></div>
	<div class="crate">
		<div class="ring"></div>
		{{SPARKS}}
		<div class="chest-art">{{CHESTSVG}}</div>
		<div class="cname">{{NAME}}</div>
		<div class="cdesc">{{DESC}}</div>
		<div class="ccount">{{COUNT}} OBJETS POSSIBLES</div>
		<div class="csub">DU COMMUN AU MYTHIQUE</div>
		<div class="hover-glow"></div>
		<div class="bar">
			<span class="bar-tag">COFFRE</span>
			<span class="bar-right"><span class="bar-price">{{PRICE}}</span><img class="bar-coin" src="{{COIN}}"></span>
		</div>
	</div>
</div>
</div></div>
]]

local CARD_HTML = [[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; background:transparent; }
.card { position:absolute; overflow:hidden; }
.card-inner { position:absolute; left:0; top:0; }
.wrap { position:relative; width:100%; height:100%; transition:transform 0.2s ease-out; }
.card.hovered .wrap { -webkit-transform:scale(1.02); transform:scale(1.02); }
.border { position:absolute; top:0; right:0; bottom:0; left:0;
	background:linear-gradient(135deg, rgba(var(--tier),0.55), rgba(var(--tier),0.12) 45%, rgba(var(--tier),0.45)); }
.crate { position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:radial-gradient(ellipse at 50% 18%, rgba(var(--tier),0.16) 0%, rgba(0,0,0,0.96) 72%), #0a0a0e;
	overflow:hidden; }
.hover-glow { position:absolute; top:0; right:0; bottom:0; left:0;
	background:radial-gradient(ellipse at center, rgba(var(--tier),0.22) 0%, transparent 65%);
	opacity:0; transition:opacity 0.2s ease-out; pointer-events:none; }
.card.hovered .hover-glow { opacity:1; }
.ring { display:none; position:absolute; left:50%; top:28px; width:300px; height:190px; margin-left:-150px;
	border:2px solid rgba(var(--tier),0.35); border-radius:50%; }
.card.hovered .ring { display:block; -webkit-animation:pulse 1.8s ease-out infinite; animation:pulse 1.8s ease-out infinite; }
@keyframes pulse { 0% { -webkit-transform:scale(0.85); transform:scale(0.85); opacity:0.6; }
	70% { -webkit-transform:scale(1.15); transform:scale(1.15); opacity:0; } 100% { opacity:0; } }
.chest-art { position:absolute; top:24px; left:0; right:0; height:176px; text-align:center;
	-webkit-filter:drop-shadow(0 0 14px rgba(var(--tier),0.5)); filter:drop-shadow(0 0 14px rgba(var(--tier),0.5)); }
.chest-art svg { width:220px; height:176px; }
.chest-art img { max-width:360px; max-height:176px; }
.card.hovered .chest-art { -webkit-filter:drop-shadow(0 0 26px rgba(var(--tier),0.9)); filter:drop-shadow(0 0 26px rgba(var(--tier),0.9));
	-webkit-animation:floaty 2.6s ease-in-out infinite; animation:floaty 2.6s ease-in-out infinite; }
@keyframes floaty { 0%,100% { -webkit-transform:translateY(0); transform:translateY(0); }
	50% { -webkit-transform:translateY(-9px); transform:translateY(-9px); } }
.spark { display:none; position:absolute; bottom:80px; background:rgb(var(--tier)); border-radius:2px; opacity:0; }
.card.hovered .spark { display:block; }
@keyframes rise { 0% { -webkit-transform:translateY(0); transform:translateY(0); opacity:0; }
	12% { opacity:0.9; } 85% { opacity:0.15; }
	100% { -webkit-transform:translateY(-300px); transform:translateY(-300px); opacity:0; } }
{{SPARKCSS}}
.cname { position:absolute; top:212px; left:10px; right:10px; text-align:center; font-size:32px;
	letter-spacing:3px; color:#fff; font-family:'Tungsten','Bebas Neue','Impact',sans-serif;
	text-shadow:0 2px 12px rgba(0,0,0,0.9);
	white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.cdesc { position:absolute; top:256px; left:14px; right:14px; text-align:center; font-size:13px;
	letter-spacing:1px; color:rgba(255,255,255,0.55); font-family:'Avenir Next','Segoe UI',sans-serif; }
.ccount { position:absolute; top:282px; left:0; right:0; text-align:center; font-size:12px;
	letter-spacing:3px; color:rgb(var(--tier)); font-family:'Avenir Next','Segoe UI',sans-serif; }
.csub { position:absolute; top:308px; left:0; right:0; text-align:center; font-size:11px;
	letter-spacing:3px; color:rgba(255,255,255,0.35); font-family:'Avenir Next','Segoe UI',sans-serif; }
.bar { position:absolute; bottom:0; left:0; right:0; height:50px;
	background:linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.5) 80%, transparent); }
.bar::before { content:''; position:absolute; top:0; left:14px; right:14px; height:1px;
	background:linear-gradient(90deg, transparent, rgba(var(--tier),0.7), transparent); }
.bar-tag { position:absolute; left:18px; top:0; line-height:50px; font-size:22px; letter-spacing:4px;
	color:rgb(var(--tier)); font-family:'Tungsten','Bebas Neue','Impact',sans-serif; }
.bar-right { position:absolute; right:16px; top:0; height:50px; line-height:50px; }
.bar-price { font-size:26px; color:rgb(0,235,120); font-weight:800; letter-spacing:1px;
	font-family:'Tungsten','Bebas Neue','Impact',sans-serif; vertical-align:middle; }
.bar-coin { width:20px; height:20px; vertical-align:middle; margin-left:6px;
	image-rendering:-webkit-optimize-contrast; }
</style></head><body>
{{CARDS}}
<script>
/* Titre adaptatif : police 32 -> 20 et interlettrage 3 -> 1 jusqu'à tenir sur une ligne,
   sinon 2 lignes (l'espace sous le nom, jusqu'à la description, le permet). Rejoué après un
   court délai : la police peut ne pas être prête au premier passage. */
function fitName(card){
	var el = card.querySelector('.cname'); if (!el) return;
	var fs = 32, ls = 3;
	el.style.whiteSpace = 'nowrap'; el.style.lineHeight = ''; el.style.top = '';
	el.style.fontSize = fs + 'px'; el.style.letterSpacing = ls + 'px';
	while (el.scrollWidth > el.clientWidth && fs > 20) {
		fs -= 1; ls = Math.max(1, ls - 0.25);
		el.style.fontSize = fs + 'px'; el.style.letterSpacing = ls + 'px';
	}
	if (el.scrollWidth > el.clientWidth) {
		el.style.whiteSpace = 'normal'; el.style.lineHeight = '1.05';
		el.style.fontSize = '20px'; el.style.letterSpacing = '1px'; el.style.top = '206px';
	}
}
function layoutCards(list){
	for (var i = 0; i < list.length; i++) {
		var e = list[i], card = document.getElementById('chest' + e.id);
		if (!card) continue;
		card.style.left = e.x + 'px'; card.style.top = e.y + 'px';
		card.style.width = e.w + 'px'; card.style.height = e.h + 'px';
		var inner = card.querySelector('.card-inner');
		inner.style.zoom = e.zoom;
		inner.style.width = (e.w / e.zoom) + 'px'; inner.style.height = (e.h / e.zoom) + 'px';
		fitName(card);
	}
}
function setCardHover(id, hovered){
	var card = document.getElementById('chest' + id);
	if (card) card.classList.toggle('hovered', hovered);
}
layoutCards({{LAYOUT}});
setTimeout(function(){
	var cards = document.querySelectorAll('.card');
	for (var i = 0; i < cards.length; i++) fitName(cards[i]);
}, 300);
</script>
</body></html>
]]

-- ============================================================================
-- Panneau TAUX DE DROP compact (370x330, partagé par les 4 coffres).
-- ============================================================================
-- tier = nil -> taux communs. Ce panneau est UNIQUE pour toute la vitrine : dès
-- qu'un coffre surcharge ses poids, il ne peut plus parler pour tout le monde,
-- d'où le titre adaptatif ci-dessous (sinon il annoncerait à tous les taux d'un
-- seul coffre, ce que le résolveur centralisé est justement là pour éviter).
local function OddsPanelHTML(tier)
	local accRGB = string.format("%d, %d, %d", ACCENT.r, ACCENT.g, ACCENT.b)
	local weights = ChestWeights(tier)
	local total = 0
	for _, r in ipairs(RARITY_KEYS) do total = total + math.max(0, tonumber(weights[r]) or 0) end
	if total <= 0 then total = 1 end

	local css, rows = {}, {}
	local idx = 0
	for _, r in ipairs(RARITY_KEYS) do
		local w = math.max(0, tonumber(weights[r]) or 0)
		if w > 0 then
			idx = idx + 1
			local c = RARITY_COLOR[r]
			local pct = w / total * 100
			-- Largeur mini 2.5% : 0.01% serait invisible. Le CHIFFRE fait foi.
			local barW = math.max(2.5, pct)
			css[#css + 1] = string.format([[
.f%d { background:linear-gradient(90deg, rgba(%d,%d,%d,0.55), rgb(%d,%d,%d)); box-shadow:0 0 10px rgba(%d,%d,%d,0.5);
	-webkit-animation:grow%d 1s cubic-bezier(0.2,0.8,0.2,1) %.2fs forwards; animation:grow%d 1s cubic-bezier(0.2,0.8,0.2,1) %.2fs forwards; }
@keyframes grow%d { to { width:%.2f%%; } }
]], idx, c.r, c.g, c.b, c.r, c.g, c.b, c.r, c.g, c.b, idx, 0.1 * idx, idx, 0.1 * idx, idx, barW)
			rows[#rows + 1] = string.format([[
<div class="orow">
	<span class="odot" style="background:rgb(%d,%d,%d)"></span>
	<span class="oname">%s</span>
	<span class="opct" style="color:rgb(%d,%d,%d)">%s%%</span>
	<div class="obar"><div class="ofill f%d"><div class="oshine"></div></div></div>
</div>
]], c.r, c.g, c.b, RARITY_LABEL[r], c.r, c.g, c.b, string.format("%.3g", pct), idx)
		end
	end

	local head = tpl([[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; background:transparent; }
.plate { position:absolute; top:0; left:0; right:0; bottom:0; background:#0d0e11;
	border:1px solid rgba({{ACC}},0.25); }
.title { position:absolute; top:18px; left:28px; font-size:26px; letter-spacing:5px; color:#eeeff3;
	font-family:'Tungsten','Bebas Neue','Impact',sans-serif; }
.title::after { content:''; position:absolute; left:2px; bottom:-7px; width:48px; height:2px;
	background:rgb({{ACC}}); }
.rows { position:absolute; top:64px; left:28px; right:28px; }
.orow { position:relative; height:45px; }
.odot { position:absolute; left:0; top:5px; width:8px; height:8px; border-radius:2px; }
.oname { position:absolute; left:18px; top:0; font-size:13px; letter-spacing:2px;
	color:rgba(255,255,255,0.8); font-family:'Avenir Next','Segoe UI',sans-serif; }
.opct { position:absolute; right:0; top:-4px; font-size:20px; font-weight:800; letter-spacing:1px;
	font-family:'Tungsten','Bebas Neue','Impact',sans-serif; }
.obar { position:absolute; left:0; right:0; top:24px; height:7px; background:rgba(255,255,255,0.06); overflow:hidden; }
.ofill { position:absolute; left:0; top:0; bottom:0; width:0; }
.oshine { position:absolute; top:0; bottom:0; width:36px; left:-50px;
	background:linear-gradient(105deg, transparent, rgba(255,255,255,0.28), transparent);
	-webkit-animation:oshine 3.2s ease-in-out infinite; animation:oshine 3.2s ease-in-out infinite; }
@keyframes oshine { 0% { left:-50px; } 55% { left:110%; } 100% { left:110%; } }
.foot { position:absolute; bottom:12px; left:28px; right:28px; font-size:11px; letter-spacing:1px;
	color:rgba(255,255,255,0.35); font-family:'Avenir Next','Segoe UI',sans-serif; }
]], { ACC = accRGB })

	-- Un coffre au moins a ses propres taux -> ce panneau unique ne vaut plus pour
	-- tous : on le dit, et le détail exact reste lisible coffre par coffre via le
	-- bouton « ? ». Sans ça il annoncerait des chiffres faux à côté des autres.
	local bUniforme = true
	for _, t in ipairs((COFFRES_CONFIG and COFFRES_CONFIG.tiers) or {}) do
		if istable(t.weights) and next(t.weights) then bUniforme = false break end
	end

	return head .. table.concat(css) .. [[
</style></head><body>
<div class="plate">
	<div class="title">]] .. (bUniforme and "TAUX DE DROP" or "TAUX PAR DÉFAUT") .. [[</div>
	<div class="rows">]] .. table.concat(rows) .. [[</div>
	<div class="foot">]] .. (bUniforme
		and "Identiques pour tous les coffres. Doublons possibles : recycle-les !"
		or "Certains coffres ont leurs propres taux : vois le « ? » de chaque coffre.") .. [[</div>
</div>
</body></html>
]]
end

-- ============================================================================
-- Overlay d'ouverture (plein écran). Phases pilotées depuis le Lua :
-- startPending -> startShake -> shakeHarder -> doBurst(rgb, big) -> showCard(...).
-- big = légendaire/mythique : double flash, écran secoué, 6 faisceaux, confettis.
-- ============================================================================
local OVERLAY_PARTICLES_CSS, OVERLAY_PARTICLES_DIVS
do
	local css, divs = {}, {}
	for i = 1, 34 do
		local ang = (i / 34) * math.pi * 2 + 0.35 * math.sin(i * 3.1)
		local dist = 170 + ((i * 53) % 190)
		local dx = math.floor(math.cos(ang) * dist)
		local dy = math.floor(math.sin(ang) * dist * 0.7)
		local size = 4 + (i % 4) * 3
		css[#css + 1] = string.format([[
.p%d { width:%dpx; height:%dpx; -webkit-animation-delay:%.3fs; animation-delay:%.3fs; }
@keyframes fly%d { 0%% { -webkit-transform:translate(0,0) scale(1); transform:translate(0,0) scale(1); opacity:1; }
	100%% { -webkit-transform:translate(%dpx,%dpx) scale(0.15); transform:translate(%dpx,%dpx) scale(0.15); opacity:0; } }
body.burst .p%d { -webkit-animation-name:fly%d; animation-name:fly%d; }
]], i, size, size, ((i * 7) % 12) * 0.014, ((i * 7) % 12) * 0.014, i, dx, dy, dx, dy, i, i, i)
		divs[#divs + 1] = string.format('<div class="p p%d"></div>', i)
	end
	-- Confettis (mode big uniquement) : montent puis retombent en tournant.
	for i = 1, 18 do
		local dx1 = math.floor(math.cos(i * 1.7) * (60 + (i * 31) % 160))
		local dy1 = -180 - ((i * 23) % 140)
		local dx2 = math.floor(dx1 * 1.5)
		local rot = 360 + (i % 4) * 180
		css[#css + 1] = string.format([[
.c%d { -webkit-animation-delay:%.3fs; animation-delay:%.3fs; }
@keyframes conf%d { 0%% { -webkit-transform:translate(0,0) rotate(0deg); transform:translate(0,0) rotate(0deg); opacity:1; }
	30%% { -webkit-transform:translate(%dpx,%dpx) rotate(%ddeg); transform:translate(%dpx,%dpx) rotate(%ddeg); opacity:1; }
	100%% { -webkit-transform:translate(%dpx,460px) rotate(%ddeg); transform:translate(%dpx,460px) rotate(%ddeg); opacity:0; } }
body.big.burst .c%d { -webkit-animation-name:conf%d; animation-name:conf%d; }
]], i, 0.1 + (i % 6) * 0.05, 0.1 + (i % 6) * 0.05,
			i, dx1, dy1, math.floor(rot * 0.3), dx1, dy1, math.floor(rot * 0.3), dx2, rot, dx2, rot, i, i, i)
		divs[#divs + 1] = string.format('<div class="c c%d"></div>', i)
	end
	OVERLAY_PARTICLES_CSS = table.concat(css)
	OVERLAY_PARTICLES_DIVS = table.concat(divs)
end

local OVERLAY_HTML = [[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; background:transparent;
	font-family:'Tungsten','Bebas Neue','Impact',sans-serif; }
.veil { position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(5,5,8,0);
	transition:background 0.35s ease-out; }
body.on .veil { background:rgba(5,5,8,0.93); }
.stage { position:absolute; top:0; left:0; right:0; bottom:0; opacity:0; transition:opacity 0.3s ease-out; }
body.on .stage { opacity:1; }
body.burst .stage { -webkit-animation:sshake 0.45s linear; animation:sshake 0.45s linear; }
body.big.burst .stage { -webkit-animation:sshake2 0.7s linear; animation:sshake2 0.7s linear; }
@keyframes sshake { 0% { transform:translate(0,0); } 20% { transform:translate(-7px,5px); }
	40% { transform:translate(6px,-5px); } 60% { transform:translate(-5px,3px); }
	80% { transform:translate(4px,-2px); } 100% { transform:translate(0,0); } }
@keyframes sshake2 { 0% { transform:translate(0,0); } 15% { transform:translate(-13px,9px); }
	30% { transform:translate(11px,-9px); } 45% { transform:translate(-9px,6px); }
	60% { transform:translate(8px,-5px); } 80% { transform:translate(-5px,3px); } 100% { transform:translate(0,0); } }

.chestzone { position:absolute; left:50%; top:46%; width:0; height:0; }
.ring { position:absolute; left:-190px; top:-168px; width:380px; height:330px;
	border:2px solid rgba({{TIER}},0.45); border-radius:50%;
	-webkit-animation:pulse 1.5s ease-out infinite; animation:pulse 1.5s ease-out infinite; }
body.burst .ring, body.revealed .ring { display:none; }
@keyframes pulse { 0% { -webkit-transform:scale(0.85); transform:scale(0.85); opacity:0.7; }
	70% { -webkit-transform:scale(1.25); transform:scale(1.25); opacity:0; } 100% { opacity:0; } }
.chest { position:absolute; left:-170px; top:-152px; width:340px; height:300px; text-align:center;
	-webkit-filter:drop-shadow(0 0 26px rgba({{TIER}},0.55)); filter:drop-shadow(0 0 26px rgba({{TIER}},0.55)); }
body.shake2 .chest { -webkit-animation:suspense 0.55s linear infinite; animation:suspense 0.55s linear infinite; }
@keyframes suspense {
	0%   { -webkit-filter:drop-shadow(0 0 26px rgba(180,180,180,0.7)); filter:drop-shadow(0 0 26px rgba(180,180,180,0.7)); }
	25%  { -webkit-filter:drop-shadow(0 0 30px rgba(110,170,255,0.8)); filter:drop-shadow(0 0 30px rgba(110,170,255,0.8)); }
	50%  { -webkit-filter:drop-shadow(0 0 34px rgba(150,70,220,0.85)); filter:drop-shadow(0 0 34px rgba(150,70,220,0.85)); }
	75%  { -webkit-filter:drop-shadow(0 0 38px rgba(255,210,90,0.9)); filter:drop-shadow(0 0 38px rgba(255,210,90,0.9)); }
	100% { -webkit-filter:drop-shadow(0 0 42px rgba(255,95,95,0.95)); filter:drop-shadow(0 0 42px rgba(255,95,95,0.95)); } }
.chest .inner { width:100%; height:100%;
	-webkit-animation:floaty 2.4s ease-in-out infinite; animation:floaty 2.4s ease-in-out infinite; }
.chest svg { width:340px; height:266px; }
@keyframes floaty { 0%,100% { -webkit-transform:translateY(0); transform:translateY(0); }
	50% { -webkit-transform:translateY(-12px); transform:translateY(-12px); } }
body.shake .chest .inner { -webkit-animation:shakeA 0.4s linear infinite; animation:shakeA 0.4s linear infinite; }
@keyframes shakeA { 0% { transform:translate(0,0) rotate(0deg); } 20% { transform:translate(-5px,2px) rotate(-1.6deg); }
	40% { transform:translate(5px,-2px) rotate(1.6deg); } 60% { transform:translate(-6px,-1px) rotate(-2deg); }
	80% { transform:translate(6px,2px) rotate(2deg); } 100% { transform:translate(0,0) rotate(0deg); } }
body.shake2 .chest .inner { -webkit-animation:shakeB 0.18s linear infinite; animation:shakeB 0.18s linear infinite; }
@keyframes shakeB { 0% { transform:translate(0,0) rotate(0deg) scale(1.02); }
	25% { transform:translate(-9px,4px) rotate(-3deg) scale(1.02); }
	50% { transform:translate(9px,-4px) rotate(3deg) scale(1.04); }
	75% { transform:translate(-10px,-3px) rotate(-3.5deg) scale(1.04); }
	100% { transform:translate(0,0) rotate(0deg) scale(1.05); } }
body.burst .chest, body.revealed .chest { opacity:0; transition:opacity 0.25s; }

.status { position:absolute; left:0; right:0; top:66%; text-align:center; font-size:34px;
	letter-spacing:12px; color:rgba(255,255,255,0.85); text-shadow:0 2px 12px rgba(0,0,0,0.9); }
body.revealed .status { display:none; }

.flash { position:absolute; top:0; left:0; right:0; bottom:0; background:#fff; opacity:0; pointer-events:none; }
body.burst .flash { -webkit-animation:flashk 0.55s ease-out; animation:flashk 0.55s ease-out; }
body.big.burst .flash { -webkit-animation:flashk2 0.95s ease-out; animation:flashk2 0.95s ease-out; }
@keyframes flashk { 0% { opacity:0; } 10% { opacity:0.92; } 100% { opacity:0; } }
@keyframes flashk2 { 0% { opacity:0; } 8% { opacity:0.95; } 30% { opacity:0.15; } 42% { opacity:0.75; } 100% { opacity:0; } }

.beamwrap { position:absolute; left:50%; top:46%; width:0; height:0; }
.bw2 { -webkit-transform:rotate(60deg); transform:rotate(60deg); }
.bw3 { -webkit-transform:rotate(120deg); transform:rotate(120deg); }
.bw4 { -webkit-transform:rotate(30deg); transform:rotate(30deg); }
.bw5 { -webkit-transform:rotate(90deg); transform:rotate(90deg); }
.bw6 { -webkit-transform:rotate(150deg); transform:rotate(150deg); }
.bigonly { display:none; }
body.big .bigonly { display:block; }
.beam { position:absolute; left:-300px; top:-2px; width:600px; height:4px; opacity:0;
	background:linear-gradient(90deg, transparent, rgba(255,255,255,0.85), transparent); }
body.burst .beam { -webkit-animation:beamk 0.7s ease-out; animation:beamk 0.7s ease-out; }
body.big.burst .beam { -webkit-animation:beamk 1s ease-out; animation:beamk 1s ease-out; }
@keyframes beamk { 0% { opacity:0; -webkit-transform:scaleX(0.1); transform:scaleX(0.1); }
	25% { opacity:1; } 100% { opacity:0; -webkit-transform:scaleX(1.7); transform:scaleX(1.7); } }

.p { position:absolute; left:50%; top:46%; background:rgb({{TIER}}); border-radius:2px; opacity:0;
	-webkit-animation-duration:0.9s; animation-duration:0.9s;
	-webkit-animation-timing-function:cubic-bezier(0.1,0.75,0.3,1); animation-timing-function:cubic-bezier(0.1,0.75,0.3,1);
	-webkit-animation-fill-mode:forwards; animation-fill-mode:forwards; }
.c { position:absolute; left:50%; top:46%; width:9px; height:14px; background:rgb({{TIER}}); opacity:0;
	-webkit-animation-duration:1.7s; animation-duration:1.7s;
	-webkit-animation-timing-function:cubic-bezier(0.2,0.6,0.4,1); animation-timing-function:cubic-bezier(0.2,0.6,0.4,1);
	-webkit-animation-fill-mode:forwards; animation-fill-mode:forwards; }
{{PARTICLES}}

.rescard { position:absolute; left:50%; top:48%; width:420px; height:560px; margin-left:-210px; margin-top:-280px;
	opacity:0; -webkit-transform:scale(0.6); transform:scale(0.6); overflow:hidden; }
body.revealed .rescard { opacity:1; -webkit-transform:scale(1); transform:scale(1);
	-webkit-transition:opacity 0.3s ease-out, -webkit-transform 0.42s cubic-bezier(0.18,1.35,0.4,1);
	transition:opacity 0.3s ease-out, transform 0.42s cubic-bezier(0.18,1.35,0.4,1); }
.reshalo { position:absolute; left:50%; top:48%; width:1000px; height:1000px; margin-left:-500px; margin-top:-500px;
	border-radius:50%; opacity:0; background:radial-gradient(circle, rgba(255,255,255,0.12) 0%, transparent 60%); }
body.revealed .reshalo { opacity:1; transition:opacity 0.5s; }
body.big .reshalo { background:radial-gradient(circle, rgba(255,255,255,0.22) 0%, transparent 62%); }
.resborder { position:absolute; top:0; left:0; right:0; bottom:0; }
.rescrate { position:absolute; top:3px; left:3px; right:3px; bottom:3px; background:#0a0a0e; }
.ribbon { position:absolute; top:16px; left:0; right:0; text-align:center; font-size:26px;
	letter-spacing:8px; color:#fff; opacity:0.95; }
.ph { position:absolute; top:58px; left:40px; width:340px; height:340px; }
.phglow { position:absolute; top:0; left:0; right:0; bottom:0;
	background:radial-gradient(circle, rgba({{TIER}},0.10) 0%, transparent 70%); }
.emblem { display:none; position:absolute; top:120px; left:50%; width:150px; height:150px; margin-left:-75px;
	-webkit-transform:rotate(45deg); transform:rotate(45deg); border:4px solid #fff; }
.resname { position:absolute; top:412px; left:20px; right:20px; text-align:center; font-size:40px;
	letter-spacing:3px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
	text-shadow:0 2px 12px rgba(0,0,0,0.9); }
.resrar { position:absolute; top:462px; left:0; right:0; text-align:center; font-size:26px; letter-spacing:10px; }
body.big .resrar { font-size:32px; text-shadow:0 0 26px currentColor; }
.ressub { position:absolute; top:508px; left:0; right:0; text-align:center; font-size:15px; letter-spacing:2px;
	color:rgba(255,255,255,0.55); font-family:'Avenir Next','Segoe UI',sans-serif; }
.shine { position:absolute; top:-40px; bottom:-40px; left:-140px; width:90px; opacity:0;
	background:linear-gradient(105deg, transparent, rgba(255,255,255,0.35), transparent);
	-webkit-transform:skewX(-18deg); transform:skewX(-18deg); }
body.revealed .shine { -webkit-animation:shinek 0.9s ease-out 0.45s; animation:shinek 0.9s ease-out 0.45s; }
@keyframes shinek { 0% { left:-140px; opacity:0; } 15% { opacity:1; } 100% { left:560px; opacity:0; } }
</style></head>
<body>
<div class="veil"></div>
<div class="stage">
	<div class="chestzone" id="chestzone0">
		<div class="ring"></div>
		<div class="chest"><div class="inner">{{CHESTSVG}}</div></div>
	</div>
	<div class="beamwrap"><div class="beam"></div></div>
	<div class="beamwrap bw2"><div class="beam"></div></div>
	<div class="beamwrap bw3"><div class="beam"></div></div>
	<div class="beamwrap bw4 bigonly"><div class="beam"></div></div>
	<div class="beamwrap bw5 bigonly"><div class="beam"></div></div>
	<div class="beamwrap bw6 bigonly"><div class="beam"></div></div>
	{{PDIVS}}
	<div class="reshalo"></div>
	<div class="rescard" id="rescard0">
		<div class="resborder" id="resborder"></div>
		<div class="rescrate"></div>
		<div class="ribbon" id="ribbon">NOUVEAU !</div>
		<div class="ph"><div class="phglow"></div></div>
		<div class="emblem" id="emblem"></div>
		<div class="resname" id="resname"></div>
		<div class="resrar" id="resrar"></div>
		<div class="ressub" id="ressub">AJOUTÉ À TON INVENTAIRE</div>
		<div class="shine"></div>
	</div>
	<div class="status">OUVERTURE...</div>
	<div class="flash"></div>
</div>
<script>
function startPending(){ document.body.className='on'; }
function clearChests(){
	var cl = document.querySelectorAll('.chestzone.clone');
	for (var i = 0; i < cl.length; i++) { cl[i].parentNode.removeChild(cl[i]); }
	var tpl = document.getElementById('chestzone0');
	if (tpl) tpl.style.display = '';
}
/* LOT : un coffre animé par entrée du lot, clones du gabarit #chestzone0 décalés de dx px
   (mêmes décalages que les cartes). Un seul coffre = gabarit tel quel. */
function setChests(dxList){
	clearChests();
	if (!dxList || dxList.length <= 1) return;
	var tpl = document.getElementById('chestzone0');
	tpl.style.display = 'none';
	for (var i = 0; i < dxList.length; i++) {
		var c = tpl.cloneNode(true);
		c.id = '';
		c.className = 'chestzone clone';
		c.style.display = '';
		c.style.marginLeft = (dxList[i] || 0) + 'px';
		tpl.parentNode.appendChild(c);
	}
}
function startShake(){ document.body.classList.add('shake'); }
function shakeHarder(){ document.body.classList.remove('shake'); document.body.classList.add('shake2'); }
function doBurst(rgb, big){
	document.body.classList.remove('shake2');
	if (big) document.body.classList.add('big');
	var ps = document.querySelectorAll('.p');
	for (var i = 0; i < ps.length; i++) { ps[i].style.background = 'rgb(' + rgb + ')'; }
	var cs = document.querySelectorAll('.c');
	for (var j = 0; j < cs.length; j++) {
		cs[j].style.background = (j % 2 == 0) ? 'rgb(' + rgb + ')' : 'rgb(255,205,60)';
	}
	document.body.classList.add('burst');
}
function clearCards(){
	var cl = document.querySelectorAll('.rescard.clone');
	for (var i = 0; i < cl.length; i++) { cl[i].parentNode.removeChild(cl[i]); }
}
/* LOT : une carte par entrée, clone du gabarit #rescard0 (jamais affiché lui-même),
   décalée de e.dx px ; body.revealed anime tous les .rescard, clones compris. */
function showCards(list){
	var tpl = document.getElementById('rescard0');
	tpl.style.display = 'none';
	clearCards();
	for (var i = 0; i < list.length; i++) {
		var e = list[i];
		var c = tpl.cloneNode(true);
		c.id = '';
		c.className = 'rescard clone';
		c.style.display = 'block';
		c.style.marginLeft = (-210 + (e.dx || 0)) + 'px';
		var rb = c.querySelector('.resborder');
		rb.style.background = 'linear-gradient(135deg, rgba(' + e.rgb + ',0.85), rgba(' + e.rgb + ',0.25) 50%, rgba(' + e.rgb + ',0.85))';
		rb.style.boxShadow = '0 0 40px rgba(' + e.rgb + ',0.4)';
		c.querySelector('.resname').innerText = e.nm;
		var rr = c.querySelector('.resrar'); rr.innerText = e.rl; rr.style.color = 'rgb(' + e.rgb + ')';
		var rib = c.querySelector('.ribbon');
		rib.innerText = e.rib || (e.isNew ? 'NOUVEAU !' : 'DOUBLON');
		rib.style.color = e.isNew ? '#fff' : 'rgba(255,255,255,0.5)';
		c.querySelector('.ressub').innerText = e.sub ? e.sub : e.isNew
			? 'AJOUTÉ À TON INVENTAIRE'
			: 'AJOUTÉ À TON INVENTAIRE (RECYCLABLE)';
		var em = c.querySelector('.emblem');
		if (!e.hasPrev) {
			em.style.display = 'block';
			em.style.borderColor = 'rgb(' + e.rgb + ')';
			em.style.boxShadow = '0 0 30px rgba(' + e.rgb + ',0.5)';
		} else { em.style.display = 'none'; }
		tpl.parentNode.appendChild(c);
		void c.offsetWidth; /* force le reflow : la transition d'apparition part bien de 0 */
	}
	document.body.classList.add('revealed');
}
function showCard(nm, rl, rgb, hasPrev, isNew){ showCards([{nm:nm, rl:rl, rgb:rgb, hasPrev:hasPrev, isNew:isNew, dx:0}]); }
function resetPending(){ clearCards(); clearChests(); document.body.className='on'; }
</script>
</body></html>
]]

-- ============================================================================
-- Vitrine défilante + taux ; le recyclage se déplie à la demande.
-- ============================================================================
-- Quatre colonnes de grandes cartes au repos, cinq colonnes compactes avec
-- le recycleur ouvert. Les rangées supplémentaires restent accessibles en défilant.
local CARD_CSS_H = 380
local CARD_GAP = 16
local CARD_COLS = 5
local CARD_Y = 10
local CARD_W = math.floor((1405 - (CARD_COLS - 1) * CARD_GAP) / CARD_COLS)
local CARD_H = math.floor(CARD_W * CARD_CSS_H / 440)
local CHESTS_H = 880
local RZ_Y, RZ_H = 505, 330

function PANEL:BuildChests()
	local tiers = (COFFRES_CONFIG and COFFRES_CONFIG.tiers) or {}
	-- Coffres en test (superadmin_only) masqués ; l'index d'origine reste celui envoyé au serveur.
	local tVis, lp = {}, LocalPlayer()
	for tierIdx, tier in ipairs(tiers) do
		if not COFFRES_CONFIG.TierVisible or COFFRES_CONFIG.TierVisible(tier, lp) then
			tVis[#tVis + 1] = { idx = tierIdx, tier = tier }
		end
	end
	local scroll = vgui.Create("DScrollPanel", self)
	scroll:gSetPos(0, 0)
	scroll:gSetSize(1460, CHESTS_H)
	if EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	self._chestScroll = scroll
	local content = vgui.Create("DPanel", scroll)
	scroll:AddItem(content)
	content.Paint = function() end
	self._chestContent = content
	self._chestCards = {}
	-- Un navigateur partagé, créé avant les boutons VGUI pour rester derrière.
	local frame = vgui.Create("DHTML", content)
	frame:SetMouseInputEnabled(false)
	self._chestHTML = frame
	local markup = {}
	for k, v in ipairs(tVis) do
		self._chestCards[k] = self:CreateChestCard(v.tier, v.idx, 0, CARD_Y, content)
		markup[k] = self._chestCards[k]._markup
	end
	self:LayoutChestCards()
	frame:SetHTML(tpl(CARD_HTML, {
		CARDS = table.concat(markup), SPARKCSS = CARD_SPARKS_CSS,
		LAYOUT = util.TableToJSON(self._chestLayout),
	}))
	self._chestHTMLReady = true

	-- Panneau TAUX DE DROP (DHTML, barres animées, taux par défaut).
	local oddsBg = gPanel(1470, 10, 370, 330, self)
	oddsBg.Paint = function() end
	local odds = vgui.Create("DHTML", oddsBg)
	odds:Dock(FILL)
	odds:SetMouseInputEnabled(false)
	odds:SetHTML(OddsPanelHTML())
	odds:QueueJavascript(string.format("document.body.style.zoom=%f;", math.min(ScrW() / 1920, ScrH() / 1080)))

	-- Panneau RECYCLAGE : barème des yens rendus (remplace l'ancien panneau JETONS).
	local info = gPanel(1470, 350, 370, 140, self)
	self._recycleInfo = info
	info:SetVisible(false)
	info.Paint = function(s, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(12))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 50)) end
		rSimpleText("RECYCLAGE", "Bebas Neue:26", 28, 24, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rRect(30, 40, 42, 2, COL_GOLD)
		local y = 56
		for _, r in ipairs(RARITY_KEYS) do
			rSimpleText(RARITY_LABEL[r] or r, "Avenir Next World:13", 30, y,
				RARITY_COLOR[r], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			rSimpleText(RECYCLE_VALUE[r] .. " yens", "Avenir Next World:13", 340, y,
				COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			y = y + 16
		end
	end
end

function PANEL:LayoutChestCards()
	local cols = self._recyclerVisible and CARD_COLS or 4
	local cardW = math.floor((1405 - (cols - 1) * CARD_GAP) / cols)
	local cards = self._chestCards
	local rows = math.max(1, math.ceil(#cards / cols))
	if not self._recyclerVisible then
		-- Ajuste aussi la taille à la hauteur disponible : trois rangées doivent
		-- tenir entièrement au-dessus du bouton, prix compris. Au-delà, conserve
		-- au moins le format compact et laisse le défilement prendre le relais.
		local maxCardH = (CHESTS_H - CARD_Y - (rows - 1) * CARD_GAP) / rows
		cardW = math.min(cardW, math.max(CARD_W, math.floor(maxCardH * 440 / CARD_CSS_H)))
	end
	local cardH = math.floor(cardW * CARD_CSS_H / 440)
	self._chestContent:gSetSize(1445, CARD_Y + rows * (cardH + CARD_GAP) - CARD_GAP)
	local layout = {}
	for k, card in ipairs(cards) do
		local col = (k - 1) % cols
		local row = math.floor((k - 1) / cols)
		local nInRow = math.min(cols, #cards - row * cols)
		local rowW = nInRow * cardW + (nInRow - 1) * CARD_GAP
		local x0 = 40 + math.floor((1405 - rowW) / 2)
		card:gSetPos(x0 + col * (cardW + CARD_GAP), CARD_Y + row * (cardH + CARD_GAP))
		card:SetCardSize(cardW, cardH)
		layout[k] = {
			id = card._tierIdx, x = card:GetX(), y = card:GetY(),
			w = card:GetWide(), h = card:GetTall(),
			zoom = math.min(ScrW() / 1920, ScrH() / 1080) * cardW / 440,
		}
	end
	self._chestLayout = layout
	self._chestHTML:SetSize(self._chestContent:GetSize())
	if self._chestHTMLReady then
		self._chestHTML:QueueJavascript("layoutCards(" .. util.TableToJSON(layout) .. ");")
	end
	self._chestScroll:gSetSize(1460, self._recyclerVisible and (RZ_Y - 10) or CHESTS_H)
	self._chestScroll:InvalidateLayout(true)
	self._chestScroll:GetVBar():SetScroll(0)
end

function PANEL:CreateChestCard(tier, tierIdx, x, y, parent)
	local cardW, cardH = CARD_W, CARD_H
	local panel = self
	local col = TierColor(tier)
	local rgb = string.format("%d, %d, %d", col.r, col.g, col.b)
	local price = math.floor(tonumber(tier.price) or 0)
	local poolCount = #ChestPoolList(tier)
	-- Coffre annoncé mais pas sorti : carte éteinte, bouton mort. Le serveur
	-- refuse aussi l'ouverture, le bouton n'est pas le garde-fou.
	local bSoon = tier.soon == true

	local map = {
		INDEX = tostring(tierIdx),
		TIER = rgb,
		SPARKS = CARD_SPARKS_DIVS,
		CHESTSVG = "",
		NAME = tier.name or "COFFRE",
		DESC = tier.desc or "",
		COUNT = tostring(poolCount),
		-- Coffre pas encore sorti : pas de prix affiché, sinon la carte annonce
		-- 300 coins pour quelque chose qu'on ne peut pas acheter.
		PRICE = bSoon and "—" or tostring(price),
		COIN = _COIN_DATA_URI,
	}
	map.CHESTSVG = ChestImgTag(tier, "chest-img") or tpl(CHEST_SVG, map)

	local background = gPanel(x, y or CARD_Y, cardW, cardH, parent or self)
	background.Paint = function() end
	background._tierIdx = tierIdx
	background._markup = tpl(CARD_MARKUP, map)

	-- Container étendu de 50px : slide-up des boutons au hover (pattern boutique).
	local container = gPanel(0, 0, cardW, cardH + 50, background)
	container:SetMouseInputEnabled(true)
	container.Paint = function() end
	-- GLISSEMENT PILOTÉ PAR L'ÉTAT (09/08, « le OUVRIR reste parfois déployé ») : la position
	-- est recalculée à CHAQUE image depuis le survol (math.Approach sur 0,2 s), plus
	-- d'animations MoveTo empilées qui se disputaient la position et pouvaient laisser le
	-- container déployé avec _hovered déjà remis à false (le hover suivant ne corrigeait rien).
	local nSlideMax = gRespY(50)
	container._slide = 0
	container.Think = function(selff)
		if not IsValid(selff) or not IsValid(background) then return end
		if bSoon then return end -- pas de slide-up : rien à ouvrir dessous
		local inside = false
		if vgui.CursorVisible() then
			local mx, my = gui.MousePos()
			-- Zone de hover STATIQUE (rect du background, qui ne bouge pas) : détecter sur
			-- le container qui GLISSE faisait osciller le hover à l'infini quand la souris
			-- restait dans la bande sous la carte (la zone montait puis redescendait).
			local sx, sy = background:LocalToScreen(0, 0)
			inside = mx >= sx and mx < sx + background:GetWide() and my >= sy and my < sy + background:GetTall()
			-- Ce que VGUI survole VRAIMENT : sous un popup de confirmation, l'overlay
			-- d'ouverture ou l'aperçu « ? », la carte ne doit pas réagir.
			if inside then
				local hp = vgui.GetHoveredPanel()
				inside = IsValid(hp) and (hp == background or hp:HasParent(background))
			end
		end
		if inside ~= selff._hovered then
			selff._hovered = inside
			if inside then surface.PlaySound(SND_HOVER) end
			if IsValid(panel._chestHTML) then
				panel._chestHTML:QueueJavascript(string.format("setCardHover(%d, %s);", tierIdx, inside and "true" or "false"))
			end
		end
		local nTarget = inside and 1 or 0
		if selff._slide ~= nTarget then
			selff._slide = math.Approach(selff._slide, nTarget, FrameTime() / 0.2)
			local f = 1 - (1 - selff._slide) ^ 3 -- ease-out
			selff:SetPos(selff:GetX(), -math.Round(nSlideMax * f))
			if IsValid(selff._buy) then selff._buy:SetVisible(selff._slide > 0) end
		end
	end

	-- Bouton OUVRIR : pleine largeur depuis le retrait des jetons (il occupait la moitié
	-- droite, le bouton JETON tenant la gauche).
	-- ⚠️ Pas de bouton du tout sur un coffre « Bientôt » : il vit à y = cardH et
	-- n'est VISIBLE que quand le container glisse de 50 px au survol. Sans le
	-- slide, le peindre serait du code mort ; c'est le voile qui porte le message.
	if not bSoon then
		local buy = gPanel(0, cardH, cardW, 50, container)
		buy:SetVisible(false) -- masqué au repos, montré par le Think dès que ça glisse
		container._buy = buy
		buy.opacity = 0.30
		buy:SetCursor("hand")
		buy.OnCursorEntered = function() buy.opacity = 0.50 end
		buy.OnCursorExited  = function() buy.opacity = 0.30 end
		local panel = self
		buy.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			local nJ = _tokens[tier.id or ""] or 0
			if nJ > 0 then
				local lpJ = LocalPlayer()
				if IsValid(lpJ) and lpJ.OpenYesNoPopup then
					lpJ:OpenYesNoPopup("Utiliser un jeton cadeau pour ouvrir le " .. (tier.name or "coffre") .. " ?",
						"LzyShop_Coffre_Open", { tier = tierIdx, count = 1, token = true })
				end
				return
			end
			local nQ = math.Clamp(tonumber(panel._openCount) or 1, 1, 3)
			if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price * nQ) then return end
			local lp = LocalPlayer()
			if IsValid(lp) and lp.OpenYesNoPopup then
				local sQuoi = (nQ > 1) and (nQ .. " × " .. (tier.name or "coffre")) or ("le " .. (tier.name or "coffre"))
				lp:OpenYesNoPopup("Ouvrir " .. sQuoi .. " pour " .. (price * nQ) .. " coins ?",
					"LzyShop_Coffre_Open", { tier = tierIdx, count = nQ })
			end
		end
		buy.Paint = function()
			rRect(0, 0, cardW, 50, color_white, 0, RNDX.BLUR)
			rRect(0, 0, cardW, 50, Color(col.r, col.g, col.b, 255 * buy.opacity))
			local lblCol = Color(math.min(col.r + 50, 255), math.min(col.g + 50, 255), math.min(col.b + 50, 255))
			local nQ = math.Clamp(tonumber(panel._openCount) or 1, 1, 3)
			local nJ = _tokens[tier.id or ""] or 0
			rSimpleText((nJ > 0) and ("OUVRIR AVEC UN JETON (" .. nJ .. ")")
				or ((nQ > 1) and ("OUVRIR ×" .. nQ .. " (" .. (price * nQ) .. ")") or ("OUVRIR (" .. price .. ")")),
				"Avenir Next World:15", cardW / 2, 25, lblCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Voile d'extinction : enfant du background créé APRÈS la DHTML, donc dessiné
	-- par-dessus (même raison que le bouton info plus bas). Un simple voile suffit,
	-- la carte reste lisible et on comprend qu'elle arrive.
	local veil
	if bSoon then
		veil = gPanel(0, 0, cardW, cardH, background)
		veil:SetMouseInputEnabled(false)
		veil.Paint = function()
			rRect(0, 0, cardW, cardH, Color(8, 9, 12, 175))
			rRect(0, cardH / 2 - 26, cardW, 52, Color(10, 11, 14, 235))
			rSimpleText("BIENTÔT", "Bebas Neue:34", cardW / 2, cardH / 2,
				Color(200, 203, 212), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- LOT (09/07, déplacé 09/08) : ×1 ×2 ×3 en BARRE D'OUTILS à droite du bouton « ? » (haut
	-- gauche, hors de l'art), choix PARTAGÉ par toutes les cartes. Enfants du background (ne
	-- glissent pas au hover) ; le hover se détecte sur le rect du background, un enfant
	-- cliquable ne le casse pas.
	if not bSoon then
		local panel = self
		for k = 1, 3 do
			local seg = gPanel(62 + (k - 1) * 32, 20, 28, 24, background)
			seg:SetCursor("hand")
			seg.Paint = function(sp, w, h)
				local bOn = (math.Clamp(tonumber(panel._openCount) or 1, 1, 3) == k)
				rRect(0, 0, 28, 24, bOn and Color(col.r, col.g, col.b, 235) or Color(10, 11, 14, 210), 4)
				rSimpleText("×" .. k, "Bebas Neue:14", 14, 12, bOn and color_white or Color(200, 202, 208, 190),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			seg.OnMousePressed = function()
				surface.PlaySound(SND_CLICK)
				panel._openCount = k
			end
		end

		-- OFFRIR (09/28) : un coffre pour un autre joueur connecté (choix dans une liste).
		local gift = gPanel(62 + 3 * 32 + 6, 20, 70, 24, background)
		gift:SetCursor("hand")
		gift.Paint = function(sp, w, h)
			rRect(0, 0, 70, 24, sp:IsHovered() and Color(col.r, col.g, col.b, 235) or Color(10, 11, 14, 210), 4)
			rSimpleText("OFFRIR", "Bebas Neue:14", 35, 12, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		gift.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			panel:OpenGiftPicker(tier, tierIdx)
		end
		-- Jetons cadeau reçus pour CE coffre : pastille dorée.
		local tag = gPanel(62 + 3 * 32 + 6 + 76, 20, 92, 24, background)
		tag:SetMouseInputEnabled(false)
		tag.Paint = function()
			local nJ = _tokens[tier.id or ""] or 0
			if nJ <= 0 then return end
			rRect(0, 0, 92, 24, Color(255, 205, 60, 235), 4)
			rSimpleText("JETON ×" .. nJ, "Bebas Neue:14", 46, 12, Color(20, 16, 6), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Bouton ? (info) : aperçu du contenu possible. Créé APRÈS le container pour
	-- rester au-dessus, et enfant du background pour ne pas glisser au hover.
	local ibtn = gPanel(12, 12, 40, 40, background)
	ibtn:SetCursor("hand")
	ibtn.Paint = function(s, w, h)
		local hovered = s.Hovered
		rRect(0, 0, 40, 40, Color(10, 11, 14, hovered and 250 or 210), gRespY(20))
		rRect(2, 2, 36, 36, Color(col.r, col.g, col.b, hovered and 70 or 35), gRespY(18))
		rSimpleText("?", "Bebas Neue:24", 20, 19,
			hovered and color_white or Color(col.r, col.g, col.b), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ibtn.OnCursorEntered = function() surface.PlaySound(SND_HOVER) end
	ibtn.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		panel:OpenPoolPreview(tierIdx)
	end
	-- Redimensionne les boutons ; LayoutChestCards actualise le HTML en une passe.
	background.SetCardSize = function(s, w, h)
		cardW, cardH = w, h
		s:gSetSize(w, h)
		container:gSetSize(w, h + 50)
		if IsValid(container._buy) then
			container._buy:gSetPos(0, h)
			container._buy:gSetSize(w, 50)
		end
		if IsValid(veil) then veil:gSetSize(w, h) end
	end
	return background
end

-- ============================================================================
-- Aperçu du contenu d'un coffre (modal plein écran, préviews 3D + % par item).
-- ============================================================================
-- ============================================================================
-- OFFRIR (09/28, user) : choix du destinataire dans la DA de la boutique (plus de
-- DermaMenu). Recherche + liste des joueurs en ligne ; un clic -> confirmation.
-- ============================================================================
function PANEL:CloseGiftPicker()
	if IsValid(self._giftModal) then self._giftModal:Remove() end
	self._giftModal = nil
end

function PANEL:OpenGiftPicker(tier, tierIdx)
	self:CloseGiftPicker()
	local panel = self
	local col = TierColor(tier)
	local price = math.floor(tonumber(tier.price) or 0)

	local modal = gPanel(0, 0, 1840, 950, self)
	modal:SetMouseInputEnabled(true)
	modal:MoveToFront()
	modal.Paint = function(_, w, h) surface.SetDrawColor(6, 7, 9, 200) surface.DrawRect(0, 0, w, h) end
	modal.OnMousePressed = function() panel:CloseGiftPicker() end -- clic dehors = fermer
	self._giftModal = modal

	local card = gPanel(620, 95, 600, 715, modal)
	card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		rRect(0, 0, 600, 715, Color(14, 14, 17, 250), 12)
		rRect(0, 0, 600, 4, ACCENT, 0)
		rSimpleText("OFFRIR UN JETON", "Bebas Neue:34", 32, 40, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rSimpleText(tostring(tier.name or "Coffre") .. " · " .. price .. " coins", "Avenir Next World:15", 32, 72,
			Color(col.r, col.g, col.b), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rSimpleText("Il recevra un jeton et ouvrira ce coffre lui-même.", "Avenir Next World:14", 32, 96,
			COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local close = gPanel(548, 22, 36, 36, card)
	close:SetCursor("hand")
	close.Paint = function(s, w, h)
		rSimpleText("✕", "Bebas Neue:26", 18, 17, s:IsHovered() and ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.OnMousePressed = function() surface.PlaySound(SND_CLICK) panel:CloseGiftPicker() end

	local search = vgui.Create("DTextEntry", card)
	search:gSetPos(32, 120)
	search:gSetSize(536, 42)
	search:SetFont("Avenir Next World:15")
	search:SetPlaceholderText("Rechercher un joueur...")
	search:SetDrawLanguageID(false)
	search:SetUpdateOnType(true)
	search.Paint = function(s, w, h)
		RNDX.Draw(gRespY(8), 0, 0, w, h, Color(24, 25, 30, 255))
		if s:HasFocus() then RNDX.DrawOutlined(gRespY(8), 0, 0, w, h, ACCENT, 1) end
		s:DrawTextEntryText(COL_TITLE, ACCENT, COL_TITLE)
		if s:GetValue() == "" and not s:HasFocus() then
			draw.SimpleText(s:GetPlaceholderText(), "Avenir Next World:15", gRespX(12), h / 2, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local scroll = vgui.Create("DScrollPanel", card)
	scroll:gSetPos(32, 178)
	scroll:gSetSize(536, 505)
	local vbar = scroll:GetVBar()
	vbar:SetWide(gRespX(6))
	vbar.Paint = function() end
	vbar.btnUp.Paint, vbar.btnDown.Paint = function() end, function() end
	vbar.btnGrip.Paint = function(_, w, h) RNDX.Draw(gRespY(3), 0, 0, w, h, Color(207, 68, 78, 160)) end

	local function rebuild()
		scroll:Clear()
		local sQ = string.lower(string.Trim(search:GetValue() or ""))
		local lp = LocalPlayer()
		local tList = {}
		for _, p in player.Iterator() do
			if IsValid(p) and p ~= lp and not p:IsBot() then
				local sNom = p:Nick()
				if sQ == "" or string.find(string.lower(sNom), sQ, 1, true) then
					tList[#tList + 1] = { ply = p, nom = sNom, fac = p:GetEvoNWString("FactionName", "") }
				end
			end
		end
		table.sort(tList, function(x, y) return string.lower(x.nom) < string.lower(y.nom) end)
		if #tList == 0 then
			local empty = scroll:Add("DPanel")
			empty:Dock(TOP)
			empty:SetTall(gRespY(60))
			empty.Paint = function(_, w, h)
				draw.SimpleText(sQ == "" and "Personne d'autre n'est connecté." or "Aucun joueur ne correspond.",
					"Avenir Next World:15", w / 2, h / 2, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		for _, e in ipairs(tList) do
			local row = scroll:Add("DButton")
			row:Dock(TOP)
			row:DockMargin(0, 0, gRespX(8), gRespY(6))
			row:SetTall(gRespY(52))
			row:SetText("")
			row.Paint = function(s, w, h)
				local bH = s:IsHovered()
				RNDX.Draw(gRespY(8), 0, 0, w, h, bH and Color(34, 30, 34, 255) or Color(22, 23, 28, 255))
				if bH then RNDX.Draw(0, 0, 0, gRespX(3), h, ACCENT) end
				draw.SimpleText(e.nom, "Avenir Next World:16", gRespX(18), h / 2 - gRespY(8), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(e.fac ~= "" and e.fac or "Sans faction", "Avenir Next World:13", gRespX(18), h / 2 + gRespY(10), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText("OFFRIR", "Bebas Neue:20", w - gRespX(18), h / 2, bH and ACCENT or COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.OnCursorEntered = function() surface.PlaySound(SND_HOVER) end
			row.DoClick = function()
				surface.PlaySound(SND_CLICK)
				local p = e.ply
				local lpc = LocalPlayer()
				if not (IsValid(p) and IsValid(lpc) and lpc.OpenYesNoPopup) then return end
				if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
				panel:CloseGiftPicker()
				lpc:OpenYesNoPopup("Offrir un jeton de " .. (tier.name or "coffre") .. " à " .. e.nom .. " pour " .. price .. " coins ?",
					"LzyShop_Coffre_Gift", { tier = tierIdx, target = p })
			end
		end
	end
	search.OnValueChange = function() rebuild() end
	rebuild()
end

function PANEL:ClosePoolPreview()
	if IsValid(self._poolModal) then self._poolModal:Remove() end
	self._poolModal = nil
end

function PANEL:OpenPoolPreview(tierIdx)
	self:ClosePoolPreview()
	local tiers = (COFFRES_CONFIG and COFFRES_CONFIG.tiers) or {}
	local tier = tiers[tierIdx]
	if not tier then return end
	local panel = self
	local col = TierColor(tier)

	local list = ChestPoolList(tier)
	table.sort(list, function(a, b)
		local ra, rb = RARITY_ORDER[a.rar] or 1, RARITY_ORDER[b.rar] or 1
		if ra ~= rb then return ra > rb end -- mythiques d'abord
		return tostring(a.def.name or a.id) < tostring(b.def.name or b.id)
	end)

	-- Comptes par rareté + chance PAR ITEM (poids de la rareté réparti dans le bucket).
	local weights = ChestWeights(tier)
	local totalW, rarCount = 0, {}
	for _, r in ipairs(RARITY_KEYS) do totalW = totalW + math.max(0, tonumber(weights[r]) or 0) end
	totalW = totalW + (COFFRES_CONFIG.ArgentTotal and COFFRES_CONFIG.ArgentTotal(tier) or 0)
	if totalW <= 0 then totalW = 1 end
	for _, e in ipairs(list) do rarCount[e.rar] = (rarCount[e.rar] or 0) + 1 end
	local function ItemChance(rar)
		local w = math.max(0, tonumber(weights[rar]) or 0)
		local n = rarCount[rar] or 0
		if w <= 0 or n <= 0 then return nil end
		return w / totalW * 100 / n
	end
	local countsParts = {}
	for _, r in ipairs(RARITY_KEYS) do
		if (rarCount[r] or 0) > 0 then
			countsParts[#countsParts + 1] = rarCount[r] .. " " .. (RARITY_LABEL_PLUR[r] or r)
		end
	end
	local countsLine = #list .. " objets possibles : " .. table.concat(countsParts, ", ")
	local gainsParts = {}
	for _, g in ipairs(istable(tier.gains_argent) and tier.gains_argent or {}) do
		gainsParts[#gainsParts + 1] = string.format("%d %s (%s %%)", tonumber(g.yens or g.coins) or 0,
			g.yens and "yens" or "coins", string.format("%.3g", (tonumber(g.poids) or 0) / totalW * 100))
	end
	if #gainsParts > 0 then countsLine = countsLine .. "  •  ou " .. table.concat(gainsParts, ", ") end

	local parent = self:GetParent()
	if not IsValid(parent) then parent = self end
	local m = vgui.Create("DPanel", parent)
	m:SetPos(0, 0)
	m:SetSize(parent:GetWide(), parent:GetTall())
	m:SetMouseInputEnabled(true)
	m:MoveToFront()
	m.Paint = function()
		rRect(0, 0, 1920, 1080, color_white, 0, RNDX.BLUR)
		rRect(0, 0, 1920, 1080, Color(5, 5, 8, 215))
	end
	m.OnMousePressed = function() panel:ClosePoolPreview() end
	self._poolModal = m

	local inner = gPanel(210, 90, 1500, 900, m)
	inner.OnMousePressed = function() end -- ne ferme pas quand on clique DANS le panneau
	inner.Paint = function(s, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250), gRespY(14))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(col.r, col.g, col.b, 90)) end
		rSimpleText(tier.name .. " : CONTENU POSSIBLE", "Bebas Neue:36", 40, 44,
			COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rRect(42, 70, 64, 3, col)
		rSimpleText(countsLine, "Avenir Next World:15", 40, 96, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local closeb = gPanel(1436, 20, 44, 44, inner)
	closeb:SetCursor("hand")
	closeb.Paint = function(s, w, h)
		rRect(0, 0, 44, 44, Color(255, 255, 255, s.Hovered and 26 or 12), gRespY(6))
		rSimpleText("✕", "Bebas Neue:26", 22, 21,
			s.Hovered and color_white or Color(200, 202, 208), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeb.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		panel:ClosePoolPreview()
	end

	local scroll = vgui.Create("DScrollPanel", inner)
	scroll:gSetPos(40, 126)
	scroll:gSetSize(1420, 748)
	if EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end

	local content = vgui.Create("DPanel", scroll)
	scroll:AddItem(content)
	local rows = math.max(1, math.ceil(#list / 9))
	content:gSetSize(1390, 8 + rows * 235)
	content.Paint = function() end

	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_coffres_pool", true, content)
	end

	for i, entry in ipairs(list) do
		local cx = 4 + ((i - 1) % 9) * 156
		local cy = 4 + math.floor((i - 1) / 9) * 235
		local card = gPanel(cx, cy, 150, 225, content)
		card._rar = entry.rar
		local chance = ItemChance(entry.rar)
		local chanceStr = chance and (string.format("%.3g", chance) .. "%") or ""
		card.Paint = function(s, w, h)
			local rc = RARITY_COLOR[s._rar]
			rRect(0, 0, 150, 225, Color(15, 16, 20, 240), 6)
			rRect(0, 0, 150, 3, rc, 0)
			rSimpleText(tostring(entry.def.name or entry.id), "Avenir Next World:12", 75, 172,
				Color(220, 222, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText(RARITY_LABEL[s._rar] or "", "Avenir Next World:11", 75, 192,
				rc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText(chanceStr, "Bebas Neue:18", 75, 211, rc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		local holder = gPanel(12, 8, 126, 150, card)
		holder:SetMouseInputEnabled(false)
		holder.Paint = function() end
		SetupItemPreview(holder, entry.def)
		-- Œil « aperçu sur ton perso » (user 09/05), en haut à droite de la carte comme
		-- dans la catégorie cosmétiques. Bouton partagé EVO_UI : l'aperçu 3D du holder
		-- n'a pas de souris, le clic n'atteint que l'œil et ne ferme pas la modale.
		if EVO_UI and EVO_UI.EyeButton then
			local eye = EVO_UI.EyeButton(card, entry.def)
			if IsValid(eye) then
				eye:gSetPos(110, 8)
				eye:gSetSize(32, 20)
			end
		end
	end
	scroll:InvalidateLayout(true)
end

-- ============================================================================
-- Overlay d'ouverture.
-- ============================================================================
function PANEL:CreateOverlay(tierIdx)
	local tiers = (COFFRES_CONFIG and COFFRES_CONFIG.tiers) or {}
	local col = TierColor(tiers[tierIdx])
	local rgb = string.format("%d, %d, %d", col.r, col.g, col.b)

	local parent = self:GetParent()
	if not IsValid(parent) then parent = self end
	local ov = vgui.Create("DPanel", parent)
	ov:SetPos(0, 0)
	ov:SetSize(parent:GetWide(), parent:GetTall())
	ov:SetMouseInputEnabled(true)
	ov:MoveToFront()
	ov.Paint = function() end
	ov.OnMousePressed = function() end -- avale les clics hors boutons
	ov._z = math.min(ScrW() / 1920, ScrH() / 1080)
	ov._tierIdx = tierIdx

	-- L'animation garde le coffre SVG (demande user) : l'image config ne sert QUE sur la carte.
	local map = { TIER = rgb, PARTICLES = OVERLAY_PARTICLES_CSS, PDIVS = OVERLAY_PARTICLES_DIVS, CHESTSVG = "" }
	map.CHESTSVG = tpl(CHEST_SVG, map)
	local fx = vgui.Create("DHTML", ov)
	fx:Dock(FILL)
	fx:SetMouseInputEnabled(false)
	fx:SetHTML(tpl(OVERLAY_HTML, map))
	fx:QueueJavascript(string.format("document.body.style.zoom=%f; startPending();", ov._z))
	ov._fx = fx

	-- Boutons du reveal (cachés jusqu'à showCard), alignés sur la carte CSS
	-- (centrée à 50%/48%, 420x560 zoomés).
	local z = ov._z
	local btnY = math.floor(ScrH() * 0.48 + 292 * z)
	local btnH = math.floor(52 * z)

	local reopen = vgui.Create("DPanel", ov)
	reopen:SetSize(math.floor(340 * z), btnH)
	reopen:SetPos(math.floor(ScrW() / 2 - 300 * z), btnY)
	reopen:SetCursor("hand")
	reopen:SetVisible(false)
	reopen.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10) or 0
		EVO_UI.PaintCut(0, 0, w, h, Color(col.r * 0.16 + 14, col.g * 0.16 + 14, col.b * 0.16 + 14, 240), math.floor(10 * z))
		EVO_UI.PaintCut(0, 0, w, h, Color(col.r, col.g, col.b, 40 + 60 * hf), math.floor(10 * z))
		local nQ = self._openLot and self._openLot.total or 1
		draw.SimpleText("RÉOUVRIR" .. (nQ > 1 and (" ×" .. nQ) or "") .. " (" .. (math.floor(tonumber(self._openPrice) or 0) * nQ) .. " COINS)",
			"Bebas Neue:24", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	reopen.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		local nQ = self._openLot and self._openLot.total or 1
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(math.floor(tonumber(self._openPrice) or 0) * nQ) then return end
		self:StartOpening(self._openTier, nQ)
		net.Start("server:lzy_shop.coffre_open")
			net.WriteUInt(self._openTier or 0, 4)
			net.WriteUInt(nQ, 2)
		net.SendToServer()
	end
	ov._reopen = reopen

	local closeb = vgui.Create("DPanel", ov)
	closeb:SetSize(math.floor(220 * z), btnH)
	closeb:SetPos(math.floor(ScrW() / 2 + 60 * z), btnY)
	closeb:SetCursor("hand")
	closeb:SetVisible(false)
	closeb.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10) or 0
		EVO_UI.PaintCut(0, 0, w, h, Color(22, 24, 30, 240), math.floor(10 * z))
		EVO_UI.PaintCut(0, 0, w, h, Color(255, 255, 255, 12 + 30 * hf), math.floor(10 * z))
		draw.SimpleText("FERMER", "Bebas Neue:24", w / 2, h / 2, Color(220, 222, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeb.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		self:CloseOverlay()
	end
	ov._closeb = closeb

	self._overlay = ov
end

function PANEL:CloseOverlay()
	self._openSerial = (self._openSerial or 0) + 1 -- invalide les timers de phase en vol
	self:ReleaseRevealHold()
	self._ovPending = false
	if IsValid(self._overlay) then self._overlay:Remove() end
	self._overlay = nil
end

-- Décalage horizontal (px CSS, zoomés) de chaque carte de révélation selon la taille du lot.
local LOT_DX = { [1] = { 0 }, [2] = { -240, 240 }, [3] = { -460, 0, 460 } }

local function ClearRevealPreviews(ov)
	if not IsValid(ov) then return end
	if IsValid(ov._preview) then ov._preview:Remove() end
	ov._preview = nil
	for _, h in ipairs(ov._previews or {}) do
		if IsValid(h) then h:Remove() end
	end
	ov._previews = nil
end

function PANEL:StartOpening(tierIdx, nCount)
	local tiers = (COFFRES_CONFIG and COFFRES_CONFIG.tiers) or {}
	local tier = tiers[tierIdx]
	if not tier then return end
	self:ClosePoolPreview()

	self._openSerial = (self._openSerial or 0) + 1
	local serial = self._openSerial
	self._openTier = tierIdx
	self._openPrice = math.floor(tonumber(tier.price) or 0)
	-- LOT (09/07) : résultats collectés jusqu'au dernier (ou un échec) avant l'animation.
	nCount = math.Clamp(math.floor(tonumber(nCount) or 1), 1, 3)
	self._openLot = { total = nCount, results = {} }
	self._ovPending = true
	-- ANTI-SPOIL (09/06) : le serveur donne l'objet AVANT la fin de l'animation, et la liste
	-- du recycleur se reconstruit sur LZY_Inventory_Synced -> le drop s'y lisait avant la
	-- carte. Gele jusqu'a showCard (ReleaseRevealHold), ou jusqu'a la fermeture de l'overlay.
	self._revealHold = true

	-- Overlay d'un AUTRE coffre encore ouvert (couleur différente) : on repart à neuf.
	if IsValid(self._overlay) and self._overlay._tierIdx ~= tierIdx then
		self._overlay:Remove()
		self._overlay = nil
	end
	if IsValid(self._overlay) then
		-- Réouverture en chaîne : reset de la scène sans recharger le HTML.
		local ov = self._overlay
		if IsValid(ov._fx) then ov._fx:RunJavascript("resetPending();") end
		ClearRevealPreviews(ov)
		if IsValid(ov._reopen) then ov._reopen:SetVisible(false) end
		if IsValid(ov._closeb) then ov._closeb:SetVisible(false) end
	else
		self:CreateOverlay(tierIdx)
	end
	-- LOT : autant de coffres animés que de coffres demandés, aux positions des futures cartes.
	if IsValid(self._overlay) and IsValid(self._overlay._fx) then
		self._overlay._fx:QueueJavascript("setChests(" .. util.TableToJSON(LOT_DX[nCount] or LOT_DX[1]) .. ");")
	end

	-- Failsafe : pas de réponse serveur, on referme au lieu de bloquer l'écran (+3 s par coffre du lot).
	timer.Simple(5 + 3 * nCount, function()
		if IsValid(self) and self._openSerial == serial and self._ovPending then
			self:CloseOverlay()
		end
	end)
end

function PANEL:OnOpenResult(ok, tierIdx, item_id, rarity, isNew, nIdx, nTotal)
	if not self._ovPending then return end
	local lot = self._openLot or { total = 1, results = {} }
	if ok then
		lot.results[#lot.results + 1] = { item_id = item_id, rarity = rarity, isNew = isNew }
	end
	-- LOT (09/07) : on attend le dernier résultat ; un échec met fin au lot (le serveur a
	-- déjà affiché pourquoi), on révèle ce qui a été obtenu.
	local nWant = math.max(1, tonumber(lot.total) or 1, tonumber(nTotal) or 1)
	if ok and #lot.results < nWant and (tonumber(nIdx) or 1) < nWant then return end
	self._ovPending = false
	if #lot.results == 0 or not IsValid(self._overlay) then
		self:CloseOverlay()
		return
	end

	local serial = self._openSerial
	local ov = self._overlay
	-- Une entrée par carte ; couleur de l'explosion = la plus rare du lot.
	local cards, big, rgb = {}, false, nil
	for i, r in ipairs(lot.results) do
		local sArg, nArg = string.match(r.item_id or "", "^@(%a+):(%d+)$")
		local def = not sArg and ITEMS and ITEMS[r.item_id] or nil
		local rar = RARITY_COLOR[r.rarity] and r.rarity or RarityOf(def)
		if sArg == "yens" then
			rar = "common"
		elseif sArg == "coins" then
			rar = tonumber(nArg) == 500 and "epic" or "rare"
		end
		local rc = RARITY_COLOR[rar]
		local bBig = (rar == "legendary" or rar == "mythic")
		local sRgb = string.format("%d,%d,%d", rc.r, rc.g, rc.b)
		if bBig and not big then big, rgb = true, sRgb end
		rgb = rgb or sRgb
		cards[i] = { def = def, item_id = r.item_id, rar = rar, rgb = sRgb, isNew = r.isNew and true or false }
		if sArg then
			cards[i].nm = nArg .. (sArg == "yens" and " yens" or " coins")
			cards[i].rl = sArg == "yens" and "YENS" or "COINS"
			cards[i].sub = sArg == "yens" and "AJOUTÉ À TON PERSONNAGE" or "AJOUTÉ À TON COMPTE"
			cards[i].currencyIcon = CURRENCY_ICONS[sArg]
			if cards[i].currencyIcon then
				-- Définition visuelle uniquement : ce gain n'est pas un objet d'inventaire.
				cards[i].def = { name = cards[i].nm, icon = cards[i].currencyIcon }
			end
		end
	end

	local function alive()
		return IsValid(self) and self._openSerial == serial and IsValid(self._overlay)
	end

	-- Montée de tension : secousses + ticks accélérés, puis explosion et reveal.
	if IsValid(ov._fx) then ov._fx:RunJavascript("startShake();") end
	local t, d = 0.05, 0.30
	while t < 1.9 do
		local tt = t
		timer.Simple(tt, function()
			if alive() then surface.PlaySound(SND_TICK) end
		end)
		t = t + d
		d = math.max(0.055, d * 0.84)
	end
	timer.Simple(1.0, function()
		if alive() and IsValid(self._overlay._fx) then self._overlay._fx:RunJavascript("shakeHarder();") end
	end)
	timer.Simple(1.95, function()
		if not alive() then return end
		surface.PlaySound(SND_REVEAL)
		if IsValid(self._overlay._fx) then
			self._overlay._fx:RunJavascript(string.format("doBurst('%s', %s);", rgb, big and "true" or "false"))
		end
	end)
	timer.Simple(2.3, function()
		if not alive() then return end
		local tDx = LOT_DX[#cards] or LOT_DX[1]
		local tJs = {}
		for i, c in ipairs(cards) do
			c.hasPrev = (c.currencyIcon and GetIconMat(c.currencyIcon) ~= nil)
				or c.def and LZY_INVENTORY_ITEM_PREVIEW
				and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
				and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(c.def) or false
			c.dx = tDx[i] or 0
			tJs[i] = { nm = c.nm or tostring(c.def and c.def.name or c.item_id), rl = c.rl or RARITY_LABEL[c.rar] or "",
				rgb = c.rgb, hasPrev = c.hasPrev, isNew = c.isNew, dx = c.dx,
				rib = c.sub and "GAIN" or nil, sub = c.sub }
		end
		if IsValid(self._overlay._fx) then
			self._overlay._fx:RunJavascript("showCards(" .. util.TableToJSON(tJs) .. ");")
		end
		surface.PlaySound(SND_GAIN)
		if big then
			timer.Simple(0.25, function()
				if alive() then surface.PlaySound(SND_REVEAL) end
			end)
		end
		for _, c in ipairs(cards) do
			self:CreateRevealPreview(c.def, c.hasPrev, c.dx, c.currencyIcon)
		end
		self:ReleaseRevealHold()
		if IsValid(self._overlay._reopen) then self._overlay._reopen:SetVisible(true) end
		if IsValid(self._overlay._closeb) then self._overlay._closeb:SetVisible(true) end
	end)
end

function PANEL:CreateRevealPreview(def, hasPrev, dx, currencyIcon)
	local ov = self._overlay
	if not IsValid(ov) or not def then return end
	local z = ov._z
	-- Trou .ph de la carte CSS : carte centrée (50% + dx, 48%), .ph à top 58 / left 40 / 340x340.
	local hs = math.floor(340 * z)
	local hx = math.floor(ScrW() / 2 + (tonumber(dx) or 0) * z - 170 * z)
	local hy = math.floor(ScrH() * 0.48 - 222 * z)

	local holder = vgui.Create("DPanel", ov)
	holder:SetPos(hx, hy)
	holder:SetSize(hs, hs)
	holder:SetMouseInputEnabled(false)
	holder.Paint = function() end
	ov._previews = ov._previews or {}
	ov._previews[#ov._previews + 1] = holder

	if currencyIcon then
		local mat = GetIconMat(currencyIcon)
		if mat then
			-- Petites icônes du HUD : ne jamais les agrandir au-delà de leur
			-- résolution native, même sur un grand écran ou une carte unique.
			local iw, ih = math.max(1, mat:Width()), math.max(1, mat:Height())
			local scale = math.min(1, 64 * z / math.max(iw, ih))
			local dw, dh = math.max(1, math.floor(iw * scale)), math.max(1, math.floor(ih * scale))
			holder.Paint = function(_, w, h)
				surface.SetMaterial(mat)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(math.floor((w - dw) / 2), math.floor((h - dh) / 2), dw, dh)
			end
		end
		return
	end

	if hasPrev and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_coffres_reveal", true, ov)
	end
	SetupItemPreview(holder, def)
end

-- ============================================================================
-- Recycleur (doublons : sélection PAR EXEMPLAIRE, badge ×N).
-- ============================================================================
function PANEL:BuildRecyclerToggle()
	local panel = self
	local btn = vgui.Create("DButton", self)
	btn:gSetPos(780, CHESTS_H + 14)
	btn:gSetSize(280, 56)
	btn:SetText("")
	btn.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10) or 0
		local pts = EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(10))
		EVO_UI.PaintCut(0, 0, w, h, Color(ACCENT.r, ACCENT.g, ACCENT.b, 35 + 65 * hf), gRespY(10))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, ACCENT) end
		draw.SimpleText(panel._recyclerVisible and "FERMER LE RECYCLAGE" or "RECYCLAGE",
			"Bebas Neue:26", w / 2, h / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.OnCursorEntered = function() surface.PlaySound(SND_HOVER) end
	btn.DoClick = function()
		surface.PlaySound(SND_CLICK)
		panel:SetRecyclerVisible(not panel._recyclerVisible)
	end
end

function PANEL:SetRecyclerVisible(visible)
	self._recyclerVisible = visible == true
	if self._recyclerVisible then
		if not IsValid(self._zone) then
			self:BuildRecycler()
		else
			self:RebuildRecycleList()
		end
	end
	if IsValid(self._zone) then self._zone:SetVisible(self._recyclerVisible) end
	self._recycleInfo:SetVisible(self._recyclerVisible)
	self:LayoutChestCards()
end

function PANEL:BuildRecycler()
	local panel = self
	-- Recyclage à l'UNITÉ (user 08/12) : un seul emplacement, payé en yens selon la
	-- rareté. _recycleNeed reste exposé, RebuildRecycleList s'en sert pour ses messages.
	local need = 1
	self._recycleNeed = need
	self._sel = {}
	self._selCount = {}

	local zone = gPanel(0, RZ_Y, 1840, RZ_H, self)
	self._zone = zone
	zone.Paint = function(s, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(14))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60)) end

		rSimpleText("RECYCLEUR", "Bebas Neue:36", 30, 30, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rSimpleText("Des yens selon la rareté  •  Clic = 1 exemplaire, clic droit = tout le lot, ajuste avec - et +  •  Supprimé, rachetable en boutique",
			"Avenir Next World:15", 230, 30, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Flash du gain, au-dessus de l'encart de valeur.
		local fl = panel._gainFlash
		if fl and CurTime() - fl.t < 1.2 then
			local fr = (CurTime() - fl.t) / 1.2
			rSimpleText("+" .. fl.n .. " yens", "Bebas Neue:26", 1735, 30 - fr * 34,
				Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 255 * (1 - fr)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		-- Encart de GAIN : valeur de l'objet sélectionné (aperçu, le serveur fait foi).
		local selDef = panel._sel[1] and ITEMS and ITEMS[panel._sel[1]]
		rSimpleText("→", "Bebas Neue:46", 1652, 150, Color(238, 239, 243, 160), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rRect(1690, 105, 90, 90, Color(20, 17, 8, 235), gRespY(45))
		rSimpleText(selDef and tostring(RecycleValue(selDef)) or "—", "Bebas Neue:34", 1735, 143,
			COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rSimpleText("YENS", "Avenir Next World:13", 1735, 172, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rSimpleText(selDef and (RARITY_LABEL[RarityOf(selDef)] or "") or "CHOISIS UN OBJET",
			"Avenir Next World:12", 1735, 212, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local scroll = vgui.Create("DScrollPanel", zone)
	scroll:gSetPos(30, 62)
	scroll:gSetSize(1130, 250)
	if EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	self._scroll = scroll

	-- Sockets de sélection (préview 3D remplie par RefreshSockets).
	self._socketPanels = {}
	for i = 1, need do
		-- Emplacement unique : centré sur la largeur du bouton RECYCLER (1190..1630).
		local sp = gPanel(1342, 70, 135, 172, zone)
		sp._idx = i
		sp:SetCursor("hand")
		sp.Paint = function(s, w, h)
			local id = panel._sel[s._idx]
			local def = id and ITEMS and ITEMS[id]
			if id and def then
				local rc = RARITY_COLOR[RarityOf(def)]
				rRect(0, 0, 135, 172, Color(17, 18, 23, 245), 6)
				rRect(0, 0, 135, 3, rc, 0)
				rSimpleText(tostring(def.name or id), "Avenir Next World:12", 67, 158,
					Color(220, 222, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				local nMax = panel._selMax or 1
				if nMax > 1 then
					rSimpleText((panel._selQty or 1) .. " / " .. nMax, "Bebas Neue:20", 67, 141,
						COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			else
				rRect(0, 0, 135, 172, Color(255, 255, 255, 8), 6)
				rSimpleText("+", "Bebas Neue:44", 67, 78, Color(255, 255, 255, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				rSimpleText("COSMÉTIQUE", "Avenir Next World:11", 67, 120, Color(255, 255, 255, 45), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		sp.OnMousePressed = function(s)
			if not panel._sel[s._idx] then return end
			surface.PlaySound(SND_CLICK)
			table.remove(panel._sel, s._idx)
			panel._selQty = nil
			panel._selMax = nil
			panel:OnSelChanged()
		end
		self._socketPanels[i] = sp
	end

	-- Bouton RECYCLER.
	local btn = gPanel(1190, 254, 440, 56, zone)
	btn:SetCursor("hand")
	btn.Paint = function(s, w, h)
		local id = panel._sel[1]
		local def = id and ITEMS and ITEMS[id]
		local hf = (def and EVO_UI.HoverFrac) and EVO_UI.HoverFrac(s, 10) or 0
		local col = def and ACCENT or Color(60, 62, 70)
		EVO_UI.PaintCut(0, 0, w, h, Color(col.r * 0.2 + 10, col.g * 0.2 + 10, col.b * 0.2 + 10, 245), gRespY(10))
		EVO_UI.PaintCut(0, 0, w, h, Color(col.r, col.g, col.b, def and (60 + 70 * hf) or 25), gRespY(10))
		local nQ = panel._selQty or 1
		draw.SimpleText(def and ("RECYCLER" .. (nQ > 1 and (" ×" .. nQ) or "") .. "  (+" .. (RecycleValue(def) * nQ) .. " YENS)") or "RECYCLER",
			"Bebas Neue:26", w / 2, h / 2, def and color_white or Color(150, 150, 150),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		local id = panel._sel[1]
		local def = id and ITEMS and ITEMS[id]
		if not def then
			Notify("Choisis un cosmétique à recycler.")
			return
		end
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			local nQ = panel._selQty or 1
			local sQuoi = (nQ > 1) and (nQ .. " exemplaires de " .. tostring(def.name or id)) or tostring(def.name or id)
			lp:OpenYesNoPopup("Recycler " .. sQuoi .. " contre " .. (RecycleValue(def) * nQ) ..
				" yens ? " .. ((nQ > 1) and "Ils seront SUPPRIMÉS" or "L'objet sera SUPPRIMÉ") ..
				" de ton inventaire (rachetable en boutique).",
				"LzyShop_Coffre_Recycle", { id = id, count = nQ })
		end
	end

	self:RebuildRecycleList()

	hook.Add("LZY_Inventory_Synced", "LZY_Shop_Coffres_InvSync", function()
		if not IsValid(panel) then return end
		if panel._revealHold then panel._recycleDirty = true return end
		panel:RebuildRecycleList()
	end)
end

-- Fin du gel anti-spoil : reconstruit la liste si une synchro a ete reportee entre-temps.
function PANEL:ReleaseRevealHold()
	self._revealHold = nil
	if self._recycleDirty then
		self._recycleDirty = nil
		self:RebuildRecycleList()
	end
end

function PANEL:OnSelChanged()
	self._selCount = {}
	for _, id in ipairs(self._sel) do
		self._selCount[id] = (self._selCount[id] or 0) + 1
	end
	self:RefreshSockets()
end

-- Reconstruit les préviews 3D DANS les sockets (le Paint du socket ne dessine que
-- la plaque et le nom ; le modèle est un enfant recréé à chaque changement).
function PANEL:RefreshSockets()
	if not istable(self._socketPanels) then return end
	local panel = self
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_coffres", true, self)
	end
	for i, sp in ipairs(self._socketPanels) do
		if IsValid(sp) then
			sp:Clear()
			local id = self._sel[i]
			local def = id and ITEMS and ITEMS[id]
			if def then
				local holder = gPanel(8, 8, 119, 118, sp)
				holder:SetMouseInputEnabled(false)
				holder.Paint = function() end
				SetupItemPreview(holder, def)
				-- Attrape-clic AU-DESSUS de la préview : retirer CETTE copie au clic.
				local catcher = gPanel(0, 0, 135, 172, sp)
				catcher:SetCursor("hand")
				catcher.Paint = function() end
				catcher.OnMousePressed = function()
					surface.PlaySound(SND_CLICK)
					if panel._sel[i] == id then
						table.remove(panel._sel, i)
						panel._selQty = nil
						panel._selMax = nil
						panel:OnSelChanged()
					end
				end
				-- QUANTITÉ (09/06) : boutons - / + quand l'objet existe en plusieurs exemplaires.
				-- Créés après l'attrape-clic pour recevoir le clic ; le Paint du socket lit
				-- _selQty en direct, pas besoin de reconstruire la préview.
				if (panel._selMax or 1) > 1 then
					local function stepper(x, sLabel, nDelta)
						local b = gPanel(x, 130, 30, 22, sp)
						b:SetCursor("hand")
						b.Paint = function(bs, w, h)
							local hf = EVO_UI.HoverFrac and EVO_UI.HoverFrac(bs, 10) or 0
							rRect(0, 0, 30, 22, Color(ACCENT.r * 0.25 + 12, ACCENT.g * 0.25 + 12, ACCENT.b * 0.25 + 12, 240), 4)
							rRect(0, 0, 30, 22, Color(ACCENT.r, ACCENT.g, ACCENT.b, 50 + 90 * hf), 4)
							rSimpleText(sLabel, "Bebas Neue:20", 15, 11, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
						b.OnMousePressed = function()
							local nNew = math.Clamp((panel._selQty or 1) + nDelta, 1, panel._selMax or 1)
							if nNew == (panel._selQty or 1) then return end
							surface.PlaySound(SND_CLICK)
							panel._selQty = nNew
						end
					end
					stepper(8, "-", -1)
					stepper(97, "+", 1)
				end
			end
		end
	end
end

function PANEL:RebuildRecycleList()
	if not self._recyclerVisible or self._revealHold then
		self._recycleDirty = true
		return
	end
	local scroll = self._scroll
	if not IsValid(scroll) then return end
	self._recycleDirty = nil
	if IsValid(self._listContent) then self._listContent:Remove() end

	local lp = LocalPlayer()
	if not IsValid(lp) or not lp.GetInventory then return end
	local inv = lp:GetInventory()

	-- Comptage PAR EXEMPLAIRE, piles comprises (09/07) : une pile de 5 = 5 recyclables.
	local ownedCount = {}
	for slot, id in pairs(inv.items or {}) do
		if isstring(id) and id ~= "" then
			local q = (INVENTORY_CONFIG and INVENTORY_CONFIG.GetSlotQuantity) and INVENTORY_CONFIG.GetSlotQuantity(inv, slot) or 1
			ownedCount[id] = (ownedCount[id] or 0) + math.max(1, q)
		end
	end
	local list = {}
	for id, cnt in pairs(ownedCount) do
		local def = ITEMS and ITEMS[id]
		-- Miroir EXACT du gate serveur : seuls les DOUBLONS DE COFFRE se recyclent
		-- (pass de combat, vitrine et marché noir exclus, 09/08). Lister ce que le
		-- serveur refusera ne ferait que promettre des yens qui ne viendront jamais.
		if def and LZY_Shop_CanRecycleItem and LZY_Shop_CanRecycleItem(id, lp) then
			list[#list + 1] = { id = id, def = def, rar = RarityOf(def), count = cnt }
		end
	end
	table.sort(list, function(a, b)
		local ra, rb = RARITY_ORDER[a.rar] or 1, RARITY_ORDER[b.rar] or 1
		if ra ~= rb then return ra < rb end
		return tostring(a.def.name or a.id) < tostring(b.def.name or b.id)
	end)

	-- Purge des sélections en trop (copies disparues / équipées entre-temps).
	local recyclable = {}
	for _, e in ipairs(list) do recyclable[e.id] = e.count end
	local newSel, used = {}, {}
	for _, id in ipairs(self._sel) do
		used[id] = (used[id] or 0) + 1
		if used[id] <= (recyclable[id] or 0) then newSel[#newSel + 1] = id end
	end
	self._sel = newSel
	-- LOT : la quantite selectionnee ne depasse jamais ce qui reste dans le sac.
	self._selMax = newSel[1] and (recyclable[newSel[1]] or 1) or nil
	self._selQty = (newSel[1] and self._selQty) and math.min(self._selQty, self._selMax) or nil
	self:OnSelChanged()

	local panel = self
	local content = vgui.Create("DPanel", scroll)
	scroll:AddItem(content)
	local rows = math.max(1, math.ceil(#list / 7))
	content:gSetSize(1100, 8 + rows * 245)
	content.Paint = (#list == 0) and function(s, w, h)
		rSimpleText("Aucun cosmétique recyclable dans ton sac.", "Avenir Next World:16",
			550, 60, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rSimpleText("(Les objets équipés doivent d'abord être déséquipés.)", "Avenir Next World:13",
			550, 90, Color(110, 113, 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end or function() end
	self._listContent = content

	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_coffres", true, self)
	end

	for i, entry in ipairs(list) do
		local col = (i - 1) % 7
		local row = math.floor((i - 1) / 7)
		local card = gPanel(4 + col * 150, 4 + row * 245, 140, 235, content)
		card._rar = entry.rar
		card.Paint = function(s, w, h)
			local rc = RARITY_COLOR[s._rar]
			rRect(0, 0, 140, 235, s._hover and Color(22, 24, 30, 245) or Color(15, 16, 20, 240), 6)
			rRect(0, 0, 140, 3, rc, 0)
			if entry.count > 1 then
				rRect(98, 8, 34, 22, Color(10, 11, 14, 230), 4)
				rSimpleText("×" .. entry.count, "Bebas Neue:16", 115, 19, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			rSimpleText(tostring(entry.def.name or entry.id), "Avenir Next World:12", 70, 200,
				Color(220, 222, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText(RARITY_LABEL[s._rar] or "", "Avenir Next World:11", 70, 220,
				rc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		-- Préview 3D (ou icône à plat en repli).
		local holder = gPanel(10, 10, 120, 150, card)
		holder:SetMouseInputEnabled(false)
		holder.Paint = function() end
		SetupItemPreview(holder, entry.def)

		-- Attrape-clics AU-DESSUS de la préview. C'est aussi LUI qui dessine l'état
		-- SÉLECTIONNÉ (dessiné dans card.Paint il passerait DERRIÈRE le modèle 3D).
		local catcher = gPanel(0, 0, 140, 235, card)
		catcher:SetCursor("hand")
		catcher.Paint = function(s, w, h)
			if (panel._selCount[entry.id] or 0) > 0 then
				local nQ = panel._selQty or 1
				rRect(0, 0, 140, 235, Color(0, 0, 0, 145), 6)
				rOutlinedRect(0, 0, 140, 235, ACCENT, 6, 2)
				rSimpleText("SÉLECTIONNÉ" .. (nQ > 1 and (" ×" .. nQ) or ""), "Bebas Neue:18", 70, 108,
					ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		catcher.OnCursorEntered = function()
			card._hover = true
			surface.PlaySound(SND_HOVER)
		end
		catcher.OnCursorExited = function() card._hover = false end
		-- Emplacement UNIQUE : cliquer un autre objet REMPLACE la sélection (refuser
		-- obligerait à décocher d'abord pour rien), re-cliquer le même la retire.
		-- QUANTITÉ (09/06) : clic gauche = 1 exemplaire (le joueur ajuste avec - / + sur le
		-- socket), clic droit = tout le lot d'un coup. Tout mettre d'office forçait à
		-- recycler les 5 quand on n'en voulait lâcher qu'un.
		catcher.OnMousePressed = function(_, code)
			surface.PlaySound(SND_CLICK)
			local nMax = math.max(1, tonumber(entry.count) or 1)
			if code == MOUSE_RIGHT then
				panel._sel = { entry.id }
				panel._selQty = nMax
				panel._selMax = nMax
			elseif panel._sel[1] == entry.id then
				panel._sel = {}
				panel._selQty = nil
				panel._selMax = nil
			else
				panel._sel = { entry.id }
				panel._selQty = 1
				panel._selMax = nMax
			end
			panel:OnSelChanged()
		end
	end
	scroll:InvalidateLayout(true)
end

function PANEL:OnRecycled(ok, nYens, sName)
	if not ok then return end
	surface.PlaySound(SND_GAIN)
	self._sel = {}
	self._selQty = nil
	self._selMax = nil
	self:OnSelChanged()
	self._gainFlash = { t = CurTime(), n = nYens or 0 }
	self:RebuildRecycleList()
	if sName and sName ~= "" then
		Notify(sName .. " recyclé : +" .. (nYens or 0) .. " yens.")
	end
end

-- ============================================================================
-- Cycle de vie + net.
-- ============================================================================
function PANEL:Init()
	_active = self
	self:BuildChests()
	self:BuildRecyclerToggle()
	-- Jetons cadeau du compte (pastilles + bouton OUVRIR AVEC UN JETON).
	net.Start("server:lzy_shop.coffre_tokens_req")
	net.SendToServer()
end

function PANEL:Paint() end

function PANEL:OnRemove()
	if _active == self then _active = nil end
	hook.Remove("LZY_Inventory_Synced", "LZY_Shop_Coffres_InvSync")
	self:ClosePoolPreview()
	self:CloseGiftPicker()
	self:CloseOverlay()
end

net.Receive("server:lzy_shop.coffre_result", function()
	local ok = net.ReadBool()
	local tierIdx = net.ReadUInt(4)
	local item_id = net.ReadString()
	local rarity = net.ReadString()
	local isNew = net.ReadBool()
	local nIdx = net.ReadUInt(2)
	local nTotal = net.ReadUInt(2)
	if IsValid(_active) then
		_active:OnOpenResult(ok, tierIdx, item_id, rarity, isNew, nIdx, nTotal)
	end
end)

-- ⚠ Même ordre d'écriture que CoffreSendRecycled (server/sv_coffres.lua).
net.Receive("server:lzy_shop.coffre_recycled", function()
	local ok = net.ReadBool()
	local nYens = net.ReadUInt(32)
	local sName = net.ReadString()
	if IsValid(_active) then
		_active:OnRecycled(ok, nYens, sName)
	end
end)

vgui.Register("LZY:Shop:Coffres", PANEL, "DPanel")
