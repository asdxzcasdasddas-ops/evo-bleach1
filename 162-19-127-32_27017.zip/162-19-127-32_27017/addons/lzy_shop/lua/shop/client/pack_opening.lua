-- "addons\\lzy_shop\\lua\\shop\\client\\pack_opening.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Confirmation d'achat (demande user 2026-07-16) : popup "Confirmer l'achat ?" avant
-- d'envoyer l'achat au serveur (meme pattern que le night market).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_Pack_Buy = function(args)
	if not args or not args.index then return end
	net.Start("server:lzy_shop.pack_opening_buy")
		net.WriteUInt(tonumber(args.index) or 0, 8)
	net.SendToServer()
end

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- ============================================================================
-- DESIGN VALORANT (mirror cut_line/cosmetiques) : DHTML frame Valorant +
-- material du pack rendue en background via base64 inline + features list
-- en HTML + bar bottom + gift/buy slide-up + reduction badge + overlay
-- blocked si non-eligible.
-- ============================================================================

-- Coin image inline en base64.
local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- Couleur de bordure par tier de pack (price-based).
-- Aizen 2000 = violet epic, Yamamoto 5000 = jaune gold, Ichigo 10000 = rouge.
local function GetPackColor(price)
	if price >= 10000 then
		return Color(255, 80, 80, 240)   -- rouge (Ichigo, top tier)
	elseif price >= 5000 then
		return Color(255, 210, 90, 240)  -- jaune gold (Yamamoto, mid)
	else
		return Color(150, 70, 220, 240)  -- violet epic (Aizen, low)
	end
end

-- Pour les bg images : asset:// (loader natif Chromium) plus rapide que base64
-- pour les grosses images (decode quasi-instant vs 100-300ms en data:URI).
local function GetMatDataURI(matPath)
	if not isstring(matPath) or matPath == "" then return "" end
	return "asset://garrysmod/materials/" .. matPath
end

local CARD_W  = 352
local CARD_H  = 764
local GAP_X   = 352 + 180
local START_X = 205

-- ============================================================================
-- Template HTML/CSS : frame Valorant + material BG + features + bar bottom.
-- 12 placeholders : 11 rgb + 1 bodyHTML.
-- ============================================================================
local CARD_FRAME_HTML_PACK = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
.wrap { position:relative; width:100%%; height:100%%; transition: transform 0.2s ease-out; }
.border {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
}
.border::before {
	content:''; position:absolute; top:-4px; right:-4px; bottom:-4px; left:-4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity:0.35;
}
.border::after {
	content:''; position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:#0a0a0e;
}
.crate {
	position:absolute; top:4px; right:4px; bottom:4px; left:4px;
	background: radial-gradient(ellipse at top, rgba(%s, 0.20) 0%%, rgba(0,0,0,0.96) 70%%), #0a0a0e;
	overflow:hidden; z-index:1;
}
/* Material pack background : image stretch fullsize, fade au bas */
.pack-bg {
	position:absolute; top:0; left:0; right:0; bottom:0;
	background-size: cover; background-position: center;
	z-index: 0;
	opacity: 0.85;
}
.pack-bg::after {
	content:''; position:absolute; top:0; left:0; right:0; bottom:0;
	background: linear-gradient(to bottom, transparent 0%%, transparent 30%%, rgba(0,0,0,0.92) 75%%, rgba(0,0,0,1) 100%%);
}
/* Corners 4 coins (top + bottom au-dessus de la bar 72px) */
.corner { display:none;
	position:absolute; width:22px; height:22px;
	border:2px solid rgba(%s, 0.9); z-index:3;
	transition: border-color 0.15s ease-out;
}
.corner.tl { top:12px; left:12px; border-right:none; border-bottom:none; }
.corner.tr { top:12px; right:12px; border-left:none; border-bottom:none; }
.corner.bl { bottom:82px; left:12px; top:auto; border-right:none; border-top:none; }
.corner.br { bottom:82px; right:12px; top:auto; border-left:none; border-top:none; }
/* Glints */
/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }
@keyframes sweep {
	0%%   { transform: translate3d(-120px, 0, 0) skewX(-25deg); }
	100%% { transform: translate3d(420px, 0, 0) skewX(-25deg); }
}
/* Hover : scale + glow */
body.hovered .wrap { transform: scale(1.015); }
.hover-glow {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: radial-gradient(ellipse at center, rgba(%s, 0.28) 0%%, transparent 65%%);
	opacity: 0; transition: opacity 0.2s ease-out;
	pointer-events: none; z-index: 2;
}
body.hovered .hover-glow { opacity: 1; }
body.hovered .corner { display:none; border-color: rgba(%s, 1); }

/* Reduction badge en haut-droite (-%% OFF) */
.reduction {
	position: absolute;
	top: 24px; right: 24px;
	z-index: 7;
	font-size: 38px;
	font-weight: 900;
	color: rgb(255, 70, 70);
	text-shadow: 0 2px 12px rgba(0,0,0,0.95), 0 0 22px rgba(255,70,70,0.5);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
	letter-spacing: 2px;
	transform: rotate(6deg);
	transform-origin: top right;
}

/* Features list au centre/haut.
   Fonts en vw (largeur panel en pct) -> scaling automatique avec la card.
   top: 42%% -> remonte les descriptions pour eviter qu'elles tombent trop bas. */
.features {
	position: absolute;
	top: 42%%; left: 0; right: 0;
	padding: 0 7.5%%;
	z-index: 5;
}
.feat {
	display: block;
	font-size: 6vw;
	font-weight: 800;
	color: #fff;
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
	letter-spacing: 0.2vw;
	line-height: 1.35;
	padding-left: 6vw;
	position: relative;
	margin-bottom: 3vw;
}
.feat::before {
	content: '';
	position: absolute;
	top: 50%%; left: 0;
	transform: translateY(-50%%);
	width: 2.5vw; height: 2.5vw;
	background: rgba(%s, 0.95);
	box-shadow: 0 0 2.5vw rgba(%s, 0.85);
}

/* Bar bottom : 72px, nom a gauche + prix + coin a droite */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 72px;
	background: linear-gradient(to top, rgba(0,0,0,0.97) 0%%, rgba(0,0,0,0.6) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 24px;
	z-index: 5;
}
.bar::before {
	content: ''; position: absolute;
	top: 0; left: 18px; right: 18px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.75), transparent);
}
.bar-name {
	font-size: 28px;
	color: #fff;
	font-weight: 800;
	letter-spacing: 3px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 8px; }
.bar-old {
	font-size: 20px;
	color: rgba(255,255,255,0.45);
	text-decoration: line-through;
	text-decoration-color: rgba(255, 80, 80, 0.85);
	letter-spacing: 1px;
	font-weight: 700;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-discount {
	font-size: 20px;
	color: rgb(255, 80, 80);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-price {
	font-size: 34px;
	color: rgb(0, 235, 120);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-coin {
	width: 24px; height: 24px;
	image-rendering: -webkit-optimize-contrast;
}

/* Titre du pack en haut, sobre (style Valorant pack label) */
.pack-title {
	position: absolute;
	top: 24px; left: 28px;
	z-index: 5;
	font-size: 26px;
	font-weight: 700;
	color: rgba(%s, 0.95);
	letter-spacing: 5px;
	text-shadow: 0 2px 8px rgba(0,0,0,0.9);
	font-family: 'Avenir Next', 'Segoe UI', sans-serif;
}
</style></head>
<body>
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="pack-bg" style="background-image: url('%s');"></div>
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="glint"></div>
			<div class="hover-glow"></div>
			%s
		</div>
	</div>
</body></html>
]]

function PANEL:CreatePack(configIndex, row, x)
	local name      = row.name or "?"
	local price     = tonumber(row.price) or 0
	local features  = row.features or {}
	local matPath   = row.mat or ""
	local reduction = tonumber(row.reduction) or 0

	-- Eligibilite : niveau < 30, pas deja achete sur CE perso, plafond par compte.
	local ply = LocalPlayer()
	local canBuy = true
	local blockReason = ""
	if IsValid(ply) then
		local level = ply:GetEvoNWInt("Level", 1)
		local bought = ply:GetEvoNWInt("start_pack_bought", 0)
		local maxPacks = math.max(1, math.floor(tonumber(SHOP_CONFIG and SHOP_CONFIG.STARTER_PACK_MAX_PER_ACCOUNT) or 3))
		local accountBought = ply:GetEvoNWInt("start_packs_bought", 0)
		if level >= 30 then
			canBuy = false
			blockReason = "Niveau 30+ maximum"
		elseif bought == 1 then
			canBuy = false
			blockReason = "Déjà acheté"
		elseif accountBought >= maxPacks then
			canBuy = false
			blockReason = "Limite de " .. maxPacks .. " packs atteinte"
		end
	end

	local borderCol  = GetPackColor(price)
	local rgb        = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local matDataURI = GetMatDataURI(matPath)

	-- Discount calc creator code
	local finalPrice, hasDiscount = GetDiscountedPrice(price)
	local discPct = hasDiscount and SHOP_CONFIG.CREATOR_CODE_DISCOUNT or 0

	-- Features HTML list
	local featParts = {}
	for _, feat in ipairs(features) do
		featParts[#featParts + 1] = string.format('<span class="feat">%s</span>', feat)
	end
	local featuresHTML = string.format('<div class="features">%s</div>', table.concat(featParts))

	-- Reduction badge (only if reduction > 0)
	local reductionHTML = ""
	if reduction > 0 then
		reductionHTML = string.format('<div class="reduction">-%d%%</div>', reduction)
	end

	-- Pack title en haut (uppercase, spaced)
	local titleHTML = string.format('<div class="pack-title">%s</div>', string.upper(name))

	-- Bar HTML : avec/sans discount creator code
	local barHTML
	if hasDiscount then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		<span class="bar-old">%d</span>
		<span class="bar-discount">-%d%%</span>
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(name), price, discPct, finalPrice, _COIN_DATA_URI)
	else
		-- Prix "gonflé" barré (promo visuelle, façon night market) : le prix affiché reste le VRAI
		-- prix (APRÈS remise), et on montre barré l'ancien prix AVANT remise, COHÉRENT avec le % :
		--     prix_barré × (1 - reduction/100) = prix   ->   prix_barré = prix / (1 - reduction/100)
		-- Ex. Pack Aizen 2500 avec -20% -> 3125 barré (3125 - 20% = 2500 ✓).
		-- (Avant : prix × (1 + reduction/100) = 3000, or -20% de 3000 = 2400 ≠ 2500 -> incohérent.)
		-- En COINS (l'icône coin suit le prix). Rien si reduction = 0. Garde < 100 (division par 0).
		local oldPart = ""
		if reduction > 0 and reduction < 100 then
			oldPart = string.format('<span class="bar-old">%d</span>',
				math.Round(price / (1 - reduction / 100)))
		end
		barHTML = string.format([[
<div class="bar">
	<span class="bar-name">%s</span>
	<span class="bar-right">
		%s
		<span class="bar-price">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>
]], string.upper(name), oldPart, price, _COIN_DATA_URI)
	end

	local innerHTML = titleHTML .. reductionHTML .. featuresHTML .. barHTML

	-- ========================================================================
	-- Background (statique 352x764) : porte le DHTML frame Valorant.
	-- ========================================================================
	local background = gPanel(x, 115, CARD_W, CARD_H, self)
	background._configIndex = configIndex
	background.Paint = function() end

	local frame = vgui.Create("DHTML", background)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(string.format(CARD_FRAME_HTML_PACK,
		rgb, rgb, rgb,    -- border (3)
		rgb, rgb, rgb,    -- border::before (3)
		rgb,              -- crate radial (1)
		rgb,              -- corner (1)
		rgb,              -- hover-glow (1)
		rgb,              -- corner hover (1)
		rgb, rgb,         -- feat::before bullet (2)
		rgb,              -- bar lisere (1)
		rgb,              -- pack-title color (1)
		matDataURI,       -- background image URI
		innerHTML
	))
	background._dhtmlFrame = frame

	-- ========================================================================
	-- Container (352x764+50) : extends 50px sous le card pour slide-up.
	-- Hover detection via gui.MousePos (le DHTML intercepte sinon).
	-- ========================================================================
	local container = gPanel(0, 0, CARD_W, CARD_H + 50, background)
	container:SetMouseInputEnabled(true)
	background._container = container
	container._blocked = not canBuy

	container.Think = function(selff)
		if not IsValid(selff) or selff._blocked then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
			if inside then
				selff:gMoveToY(-50, 0.2, 0, 4)
			else
				timer.Simple(0.05, function()
					if IsValid(selff) and not selff._hovered then
						selff:gMoveToY(0, 0.2, 0, 4)
					end
				end)
			end
		end
	end
	container.Paint = function() end

	-- ========================================================================
	-- Bouton OFFRIR (gift) : moitie gauche du bas, vert.
	-- ========================================================================
	local gift = gPanel(0, CARD_H, CARD_W / 2, 50, container)
	gift._blocked = not canBuy
	gift.opacity = 0.20
	gift:SetCursor("hand")
	background._giftButton = gift
	gift.OnCursorEntered = function()
		if not gift._blocked then gift.opacity = 0.40 end
	end
	gift.OnCursorExited = function() gift.opacity = 0.20 end
	gift.OnMousePressed = function()
		if gift._blocked then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		local giftPanel = vgui.Create("LZY:Shop:Gift", self:GetParent())
		giftPanel.giftType = "pack_opening"
		giftPanel.configIndex = configIndex
	end
	gift.Paint = function()
		rRect(0, 0, CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
		if not gift._blocked then
			rRect(0, 0, CARD_W / 2, 50, Color(0, 255, 9, 255 * gift.opacity))
			rSimpleText("OFFRIR", "Avenir Next World:20", CARD_W / 4, 25,
				Color(0, 255, 9), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			rRect(0, 0, CARD_W / 2, 50, Color(80, 80, 80, 255 * gift.opacity))
			rSimpleText("OFFRIR", "Avenir Next World:20", CARD_W / 4, 25,
				Color(120, 120, 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- ========================================================================
	-- Bouton ACHETER (buy) : moitie droite, color-matched au pack tier.
	-- ========================================================================
	local buy = gPanel(CARD_W / 2, CARD_H, CARD_W / 2, 50, container)
	buy._blocked = not canBuy
	buy.opacity = 0.30
	buy:SetCursor("hand")
	background._buyButton = buy
	buy.OnCursorEntered = function()
		if not buy._blocked then buy.opacity = 0.50 end
	end
	buy.OnCursorExited = function() buy.opacity = 0.30 end
	buy.OnMousePressed = function()
		if buy._blocked then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
		-- Confirmation avant achat (demande user) : l'achat part dans le callback popup.
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Confirmer l'achat de " .. name .. " ?", "LzyShop_Pack_Buy", { index = configIndex })
		end
	end
	buy.Paint = function()
		rRect(0, 0, CARD_W / 2, 50, color_white, 0, RNDX.BLUR)
		if buy._blocked then
			rRect(0, 0, CARD_W / 2, 50, Color(80, 80, 80, 255 * buy.opacity))
			rSimpleText("ACHETER", "Avenir Next World:20", CARD_W / 4, 25,
				Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			-- ACHETER : couleur du tier (matche la border de la case)
			rRect(0, 0, CARD_W / 2, 50,
				Color(borderCol.r, borderCol.g, borderCol.b, 255 * buy.opacity))
			local lblCol = Color(
				math.min(borderCol.r + 50, 255),
				math.min(borderCol.g + 50, 255),
				math.min(borderCol.b + 50, 255))
			rSimpleText("ACHETER", "Avenir Next World:20", CARD_W / 4, 25,
				lblCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- ========================================================================
	-- Overlay blocked : voile noir + raison centree quand non-eligible.
	-- ========================================================================
	if not canBuy then
		local overlay = gPanel(0, 0, CARD_W, CARD_H + 50, container)
		background._overlay = overlay
		overlay:SetMouseInputEnabled(false)
		overlay.Paint = function()
			rRect(0, 0, CARD_W, CARD_H + 50, Color(0, 0, 0, 180))
			rSimpleText(blockReason, "Avenir Next World Bold:30",
				CARD_W / 2, (CARD_H + 50) / 2,
				Color(255, 80, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	else
		background._overlay = nil
	end

	table.insert(self._packSlots, background)
end

function PANEL:OnPackBought()
	for _, slot in ipairs(self._packSlots or {}) do
		if not IsValid(slot) then continue end

		if slot._buyButton and IsValid(slot._buyButton) then
			slot._buyButton._blocked = true
		end
		if slot._giftButton and IsValid(slot._giftButton) then
			slot._giftButton._blocked = true
		end
		if slot._container and IsValid(slot._container) then
			slot._container._blocked = true
		end

		if (not slot._overlay or not IsValid(slot._overlay)) and slot._container and IsValid(slot._container) then
			local overlay = gPanel(0, 0, CARD_W, CARD_H + 50, slot._container)
			slot._overlay = overlay
			overlay:SetMouseInputEnabled(false)
			overlay.Paint = function()
				rRect(0, 0, CARD_W, CARD_H + 50, Color(0, 0, 0, 180))
				rSimpleText("Déjà acheté", "Avenir Next World Bold:30",
					CARD_W / 2, (CARD_H + 50) / 2,
					Color(255, 80, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
end

function PANEL:Init()
	self._packSlots = {}
	local list = PACK_OPENING_CONFIG or {}
	local x = START_X

	for i, row in ipairs(list) do
		self:CreatePack(i, row, x)
		x = x + GAP_X
	end
end

function PANEL:Paint(w, h)
	-- (Titre interne « STARTER PACK » RETIRÉ — 08/07 : le nom de la catégorie est
	-- affiché en haut-centre par l'accueil boutique, il était en DOUBLE ici.)
	-- Avertissement remonté TOUT EN HAUT de la page (demande user 08/07).
	local maxPacks = math.max(1, math.floor(tonumber(SHOP_CONFIG and SHOP_CONFIG.STARTER_PACK_MAX_PER_ACCOUNT) or 3))
	local warnText = "1 pack par personnage, " .. maxPacks .. " maximum par compte, uniquement avant le niveau 30"
	surface.SetFont("Avenir Next World:14")
	local textW = surface.GetTextSize(warnText)
	local centerX = 1840 / 2
	local rectX = centerX - textW / 2 - 10
	local rectY = 12
	local rectW = textW + 20
	local rectH = 16
	rRect(rectX, rectY, rectW, rectH, Color(40, 40, 40, 170))
	rSimpleText(warnText, "Avenir Next World:14", 1840 / 2, rectY + rectH / 2,
		Color(255, 180, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

vgui.Register("LZY:Shop:Pack", PANEL, "DPanel")

-- Receive sold notification from server
net.Receive("server:lzy_shop.pack_opening_sold", function()
	local function findPanel(root)
		if not IsValid(root) then return nil end
		if root.GetName and root:GetName() == "LZY:Shop:Pack" then
			return root
		end
		if root.GetChildren then
			for _, child in ipairs(root:GetChildren()) do
				local found = findPanel(child)
				if found then return found end
			end
		end
		return nil
	end

	local panel = findPanel(vgui.GetWorldPanel())
	if IsValid(panel) then
		panel:OnPackBought()
	end
end)
