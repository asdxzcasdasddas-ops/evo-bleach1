-- "addons\\lzy_shop\\lua\\shop\\client\\night_market.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- Le coin (currency icon) etait dans le PNG materials/lzy_shop/coin.png. Pour
-- l'afficher dans le DHTML, on l'encode en base64 a l'init du fichier puis on
-- l'inline en data: URI dans le HTML (asset:// pas fiable selon les versions
-- de CEF GMod, base64 marche toujours).
local _COIN_DATA_URI = "" -- fallback vide -> .bar-coin tombe en CSS-drawn
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- ============================================================================
-- Callback popup confirmation pour l'achat night market. Le clic sur la
-- carte revelee ouvre LZY:Popup yesno qui invoque cette fonction nommee si
-- "ACHETER" est confirme.
-- ============================================================================
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_NightMarket_Buy = function(args)
	if not args or not args.index then return end
	net.Start("server:lzy_shop.night_market_buy")
		net.WriteUInt(tonumber(args.index) or 0, 8)
		net.WriteString(tostring(args.item_id or ""))
	net.SendToServer()
end

-- Palette bordure par rarete (memes cles que INVENTORY_CONFIG.raritiesColor)
local RARITY_BORDER_COLOR = {
	common    = Color(180, 180, 180, 200),  -- gris
	rare      = Color(110, 170, 255, 220),  -- bleu
	epic      = Color(150, 70,  220, 240),  -- violet fonce
	legendary = Color(255, 210, 90,  240),  -- jaune dore
	mythic    = Color(255, 95,  95,  240),  -- rouge
}
local function GetRarityBorderColor(itemDef)
	local r = itemDef and isstring(itemDef.rarity) and string.lower(itemDef.rarity) or "common"
	return RARITY_BORDER_COLOR[r] or RARITY_BORDER_COLOR.common
end

-- Ambiance DA « Black Market » : accent VIOLET (170,80,210) / texte d'accent
-- violet clair (225,165,245). Le chrome des cartes est rendu dans les templates
-- DHTML (plaque #0d0e11 + voile hover neutre + label ACHETER violet clair) ;
-- la rarete reste LA bordure fonctionnelle des cartes (inchangee).

local function resetItemSlots(self)
	for _, v in ipairs(self._itemSlots or {}) do
		if IsValid(v) then v:Remove() end
	end
	self._itemSlots = {}
end

-- Helper : icone "oeil" stylise dessine en Lua. (cx, cy) en pixels, w/h taille
-- de l'almond, col = couleur principale, bgCol = couleur du fond du bouton
-- (utilisee pour creer l'effet de cutout interieur). Cache : on pre-calcule
-- les polygones cosinus une fois pour eviter trig chaque frame.
local _EYE_SEGS = 18
local _EYE_COS, _EYE_SIN = {}, {}
for i = 0, _EYE_SEGS - 1 do
	local a = (i / _EYE_SEGS) * math.pi * 2
	_EYE_COS[i + 1] = math.cos(a)
	_EYE_SIN[i + 1] = math.sin(a)
end
-- Polygons reutilises in-place pour eviter d'allouer 3 tables x 18 entries
-- chaque frame par eye icon. Avec ~5-8 cards visibles ca evite ~300 allocs/f.
local _EYE_POLY_OUTER = {}
local _EYE_POLY_INNER = {}
local _EYE_POLY_PUPIL = {}
for i = 1, _EYE_SEGS do
	_EYE_POLY_OUTER[i] = { x = 0, y = 0 }
	_EYE_POLY_INNER[i] = { x = 0, y = 0 }
	_EYE_POLY_PUPIL[i] = { x = 0, y = 0 }
end

local function DrawEyeIcon(cx, cy, w, h, col, bgCol)
	local hw, hh = w * 0.5, h * 0.5
	-- Inner ellipse offset PROPORTIONNEL (vs pixels fixes -2 / -1.5) : epaisseur
	-- du ring scale avec la resolution. ~12% du demi-axe.
	local ihw, ihh = hw * 0.88, hh * 0.85
	local pr = math.min(hw, hh) * 0.42
	for i = 1, _EYE_SEGS do
		local cosA, sinA = _EYE_COS[i], _EYE_SIN[i]
		local po = _EYE_POLY_OUTER[i]; po.x = cx + cosA * hw;  po.y = cy + sinA * hh
		local pi = _EYE_POLY_INNER[i]; pi.x = cx + cosA * ihw; pi.y = cy + sinA * ihh
		local pp = _EYE_POLY_PUPIL[i]; pp.x = cx + cosA * pr;  pp.y = cy + sinA * pr
	end
	draw.NoTexture()
	-- 1. Almond outline
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_OUTER)
	-- 2. Cutout interieur (bg)
	surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a or 255)
	surface.DrawPoly(_EYE_POLY_INNER)
	-- 3. Pupille centrale
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_PUPIL)
end

-- ============================================================================
-- Frame HTML pour la carte REVELEE : reprend le meme look Valorant que la
-- crate (bordure rarete + glow pulse + corners + glints) mais sans les
-- elements mysteres. Le contenu (model preview, name, prix, boutons) est
-- ajoute en VGUI par-dessus (DHTML painte en premier dans l'ordre des childs).
-- IMPORTANT : declare AVANT CreateItemSlot pour etre visible comme upvalue.
-- DA dashboard 08/07 : plaque #0d0e11 + voile hover NEUTRE (le glow radial
-- teinte rarete a ete retire) + label ACHETER violet clair. La rarete reste LA
-- bordure fonctionnelle. 10 placeholders rgb + 1 barHTML.
-- ============================================================================
local CARD_FRAME_HTML_TEMPLATE = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
.wrap { position:relative; width:100%%; height:100%%; }
.border {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
}
.border::before {
	content:''; position:absolute; top:-4px; right:-4px; bottom:-4px; left:-4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity:0.35;
}
.border::after {
	content:''; position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:#0d0e11;
}
.crate {
	position:absolute; top:4px; right:4px; bottom:4px; left:4px;
	background: radial-gradient(ellipse at top, rgba(%s, 0.15) 0%%, rgba(0,0,0,0.96) 70%%), #0d0e11;
	overflow:hidden;
	z-index:1;
}
/* Top corners uniquement : le bottom bar (Lua-paint) sert de visual base */
.corner { display:none;
	position:absolute; width:22px; height:22px;
	border:2px solid rgba(%s, 0.9);
	z-index:3;
}
.corner.tl { top:12px; left:12px; border-right:none; border-bottom:none; }
.corner.tr { top:12px; right:12px; border-left:none; border-bottom:none; }
/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }

/* ========================================================================
   HOVER EFFECT (triggered via body.classList.add('hovered') from Lua)
   Toutes les transitions utilisent opacity / transform uniquement -> GPU.
   ======================================================================== */
/* PAS de scale au survol (fix 08/07) : le scale(1.015) rognait la bordure de
   rarete hors cadre, et le scale(0.99) au repos laissait un cadre sombre. La
   carte remplit son panneau ; le survol est signale par le voile .hover-glow. */
.wrap { transition: transform 0.2s ease-out; }

/* Voile clair NEUTRE au hover (recette carte DA dashboard). Remplace le glow
   radial teinte rarete ; la rarete garde bordure/fond/liseré. */
.hover-glow {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: rgba(226, 230, 238, 0.05);
	opacity: 0;
	transition: opacity 0.2s ease-out;
	pointer-events: none;
	z-index: 2;
}
body.hovered .hover-glow { opacity: 1; }

/* Corners s'epaississent et brightenent au hover */
.corner { display:none; transition: border-width 0.15s ease-out, border-color 0.15s ease-out; }
body.hovered .corner { display:none; border-color: rgba(%s, 1); }
/* Corners bottom : identiques au crate template (mirror exact) */
.corner.bl { bottom: 84px; left: 12px; top: auto; border-right: none; border-top: none; }
.corner.br { bottom: 84px; right: 12px; top: auto; border-left: none; border-top: none; }

/* "ACHETER" label : memes specs visuelles que "MYSTERY" du crate template :
   font Tungsten/Bebas/Impact, 36px, letter-spacing 10px, white. Position
   identique (top:73%%). Hidden par defaut, fade-in au hover. */
.action-label {
	position: absolute;
	top: 73%%; left: 0; right: 0;
	text-align: center;
	z-index: 5;
	opacity: 0;
	transition: opacity 0.2s ease-out;
	pointer-events: none;
}
body.hovered .action-label { opacity: 1; }
.action-main {
	display: block;
	font-size: 36px;
	font-weight: 900;
	letter-spacing: 10px;
	color: rgb(225, 165, 245); /* accent Black Market (violet clair) */
	text-shadow: 0 2px 16px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}

/* SOLD OUT : meme position et meme typo que ACHETER, mais persistent
   (pas hover-toggle) et rouge. Toggle via body.sold class poussee depuis
   Lua quand isSold initial ou OnItemSold. Cache aussi ACHETER + bar quand
   sold pour clarte. */
.sold-label {
	position: absolute;
	top: 73%%; left: 0; right: 0;
	text-align: center;
	z-index: 6;
	display: none;
	pointer-events: none;
}
/* SOLD OUT du DHTML desactive : dessine en PaintOver Lua (devant le model 3D).
   On garde le masquage de ACHETER + le fade de la barre. */
body.sold .sold-label { display: none; }
body.sold .action-label { display: none !important; }
body.sold .bar { opacity: 0.25; }
.sold-main {
	display: block;
	font-size: 36px;
	font-weight: 900;
	letter-spacing: 10px;
	color: rgb(255, 80, 80);
	text-shadow: 0 2px 18px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}

/* Bar bottom : structure identique au crate (.bar/bar-left/bar-right) mais
   avec contenu reel a la place des "???". L'ancien prix (strikethrough) est
   a gauche, "-X%%" + nouveau prix a droite. */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 72px;
	background: linear-gradient(to top, rgba(0,0,0,0.95) 0%%, rgba(0,0,0,0.5) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 26px;
	z-index: 5;
}
.bar::before {
	content: '';
	position: absolute;
	top: 0; left: 18px; right: 18px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.7), transparent);
}
.bar-old {
	font-size: 28px;
	color: rgba(255,255,255,0.5);
	text-decoration: line-through;
	text-decoration-color: rgba(255, 80, 80, 0.85);
	letter-spacing: 2px;
	font-weight: 700;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 14px; }
.bar-discount {
	font-size: 30px;
	color: rgb(255, 80, 80);
	font-weight: 800;
	letter-spacing: 2px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-new {
	font-size: 42px;
	color: rgb(0, 235, 120);
	font-weight: 800;
	letter-spacing: 2px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
/* Coin = meme image que les evocoins (materials/lzy_shop/coin.png) inline
   en base64. Place dans .bar-right a droite du prix. */
.bar-coin {
	width: 28px;
	height: 28px;
	vertical-align: middle;
	image-rendering: -webkit-optimize-contrast;
}
</style></head>
<body>
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="glint"></div>
			<div class="hover-glow"></div>
			<div class="action-label">
				<span class="action-main">ACHETER</span>
			</div>
			<div class="sold-label">
				<span class="sold-main">SOLD OUT</span>
			</div>
			%s
		</div>
	</div>
</body></html>
]]

function PANEL:CreateItemSlot(itemData, index, x)
	local name  = itemData.name  or "?"
	local basePrice = tonumber(itemData.price) or 0
	local nmDisc    = math.Clamp(tonumber(itemData.discount) or 0, 0, 100)
	-- Remise Night Market (5-15%), puis promo globale (promo_pct).
	local price = LZY_Shop_ApplyCosmetiquePromo(math.floor(basePrice * (100 - nmDisc) / 100))
	local isSold = itemData.sold or false
	-- Look up full item data from ITEMS for model rendering (supports head accessory zoom)
	local itemId = itemData.item_id or ""
	local itemDef = itemId ~= "" and ITEMS and ITEMS[itemId] or nil
	local useModel = LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and itemDef and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(itemDef)

	local background = gPanel(x, 115, 352, 764, self)
	table.insert(self._itemSlots, background)
	background._index = index
	background._isSold = isSold

	-- Background : Paint vide, le rendu du fond est entierement delegue au
	-- DHTML enfant ajoute en PREMIER (z-order = derriere les autres childs).
	-- Plus de rMaterials(mat, ...) - le visual cle est le frame Valorant +
	-- le model preview, pas l'image promo de l'item.
	background.Paint = function() end

	-- Frame Valorant : memes corners/glow/border que la crate pour continuite
	-- UI. Ajoute AVANT le model preview et le container pour que ces derniers
	-- peignent par-dessus dans l'ordre VGUI.
	local borderCol = GetRarityBorderColor(itemDef)
	local rgb = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local frame = vgui.Create("DHTML", background)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false) -- pass clicks aux VGUI au-dessus
	-- Construit le HTML de la bar bottom (mirror du crate `???` mais avec
	-- contenu reel). Si discount : prix barre a gauche + "-X%" + nouveau prix
	-- a droite. Sinon : juste prix a droite.
	local _finalPrice = GetDiscountedPrice(price)
	local _hasDisc = _finalPrice < basePrice
	local _discPct = math.floor((basePrice - _finalPrice) / math.max(basePrice, 1) * 100 + 0.5)
	local barHTML
	if _hasDisc then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-old">%d</span>
	<span class="bar-right">
		<span class="bar-discount">-%d%%</span>
		<span class="bar-new">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>]], basePrice, _discPct, _finalPrice, _COIN_DATA_URI)
	else
		barHTML = string.format([[
<div class="bar">
	<span></span>
	<span class="bar-right">
		<span class="bar-new">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>]], price, _COIN_DATA_URI)
	end

	frame:SetHTML(string.format(CARD_FRAME_HTML_TEMPLATE,
		rgb, rgb, rgb,  -- border (3)
		rgb, rgb, rgb,  -- border::before (3)
		rgb,            -- crate radial (1)
		rgb,            -- corner (1)
		rgb,            -- corner hover (1)
		rgb,            -- bar liseré rarete (1)
		barHTML         -- bar HTML (1)
	))

	-- Si l'item est deja vendu au load, push immediatement la class sold au
	-- DHTML (qui cache ACHETER + affiche SOLD OUT a la place). Le DHTML met
	-- ~50-200ms a charger -> retry court timer pour eviter race.
	background._dhtmlFrame = frame
	if isSold then
		timer.Simple(0.2, function()
			if IsValid(frame) then
				frame:RunJavascript("if(document.body){document.body.classList.add('sold');}")
			end
		end)
	end

	-- Plus de badge "Accessoire" : user-requested. Le nom de l'item est
	-- maintenant affiche en top-left, faded, juste le nom (pas de fond).
	-- PaintOver rend APRES les enfants (model 3D inclus) -> le SOLD OUT dessine
	-- ici passe DEVANT la tenue 3D (avant il etait masque par le model).
	background.PaintOver = function()
		-- Nom de l'item : DA Bebas (display), faded top-left.
		rSimpleText(string.upper(name), "Bebas Neue:22", 22, 28,
			Color(255, 255, 255, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if isSold then
			rRect(0, 0, 352, 764, Color(8, 8, 10, 160))
			local cx = 352 * 0.5
			local cy = 764 * 0.73
			rSimpleText("SOLD OUT", "Bebas Neue:44", cx + 2, cy + 2,
				Color(0, 0, 0, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText("SOLD OUT", "Bebas Neue:44", cx, cy,
				Color(255, 80, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	if useModel then
		-- Accessoires : margin tres serree (=zoom max). Le vrai levier de zoom
		-- c'est `margin` (multiplicateur de distance camera vs fit parfait),
		-- pas FOV (FOV-independant car dist scale avec FOV inversement).
		local isAcc = itemDef and itemDef.category == "accessory"
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(background, itemDef, 30, isAcc and 0.55 or nil, nil, true)
	end

	-- Container = 352x764 (plus de +50 pour buy slide-up). Le BUY est maintenant
	-- centre, hidden par defaut, fade-in on hover (pas de slide).
	local container = gPanel(0, 0, 352, 764, background)
	container._isSold = isSold
	background._container = container

	-- Container.Think : toggle DHTML hovered class uniquement (plus de buy
	-- button a fader, le BUY est maintenant juste un texte dans Paint).
	container.Think = function(selff)
		if not IsValid(selff) or selff._isSold then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			if IsValid(frame) then
				frame:RunJavascript(inside
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
		end
	end
	-- Bar bottom + SOLD OUT sont maintenant TOUS DEUX rendus dans le DHTML
	-- frame (mirror exact du crate). container.Paint vide.
	container.Paint = function() end

	if isSold then return end

	-- "ACHETER" n'est PLUS un bouton : juste une indication faded en bas de la
	-- carte. Le click se fait sur le CONTAINER entier qui ouvre la popup de
	-- confirmation native (LZY:Popup yesno).
	container:SetMouseInputEnabled(true)
	container:SetCursor("hand")
	container.OnMousePressed = function()
		if container._isSold then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup(
				"Confirmer l'achat de " .. name .. " ?",
				"LzyShop_NightMarket_Buy",
				{ index = index, item_id = itemId }
			)
		end
	end

	-- "ACHETER" est maintenant rendu DANS le DHTML frame (CSS .action-label,
	-- meme font/taille/position que MYSTERY de la crate). Il fade-in au hover
	-- via body.hovered class poussee par container.Think. Plus de Lua text ici.

	-- Eye preview button : TOP-RIGHT, faded, 3x plus gros, SANS encadre (pas
	-- de fond/bordure - juste l'icone "oeil" pur). Click ouvre la preview.
	-- Le cutout interieur de l'oeil utilise la couleur dominante du fond de
	-- la carte (~Color(10,10,14)) pour donner l'effet de "ring" sans bg.
	if itemDef and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open then
		-- Taille reduite (user-requested - encore plus petit) : button 36x22.
		local EYE_W, EYE_H = 36, 22
		local previewBtn = gPanel(352 - EYE_W - 12, 12, EYE_W, EYE_H, background)
		previewBtn:SetZPos(1000)
		previewBtn:SetCursor("hand")
		previewBtn:SetTooltip("Aperçu sur ton perso")
		previewBtn:SetAlpha(130)
		previewBtn.OnCursorEntered = function()
			previewBtn:Stop(); previewBtn:AlphaTo(255, 0.15, 0)
		end
		previewBtn.OnCursorExited = function()
			previewBtn:Stop(); previewBtn:AlphaTo(130, 0.15, 0)
		end
		previewBtn.OnMousePressed = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			LZY_SHOP_COSMETIC_PREVIEW.Open(itemDef)
		end
		-- Couleurs pre-cachees. Le bgCol passe a DrawEyeIcon est la couleur
		-- dominante du fond de la carte pour que le cutout interieur du oeil
		-- se fonde naturellement -> effet "ring" sans encadre visible.
		local _fg     = Color(230, 230, 240, 240)
		local _bgCol  = Color(10, 10, 14, 255)
		previewBtn.Paint = function(_, w, h)
			-- Responsive : icone proportionnelle a la taille du bouton
			-- (ratios 66/80 et 36/50 de l'ancien fix size) → scale auto avec
			-- le panel qui est deja responsive via gPanel.
			DrawEyeIcon(w / 2, h / 2, w * 0.825, h * 0.72, _fg, _bgCol)
		end
	end
end

function PANEL:Init()
	self._items = {}
	self._itemSlots = {}
	self._loaded = false
	self._nmResetAt = 0

	-- Hitbox invisible sur le countdown (rSimpleText n'est pas hoverable).
	-- Style sombre LZYCustomTooltip (meme UI que pity / premium du reroll).
	local tipText = "Réinitialisation chaque lundi à 00:00 pour tous les joueurs."
	local tip = vgui.Create("DPanel", self)
	tip:gSetPos(1840 / 2 - 160, 40)
	tip:gSetSize(320, 36)
	tip:SetPaintBackground(false)
	tip:SetMouseInputEnabled(true)
	tip:SetCursor("hand")
	tip:SetTooltip(tipText)
	tip.strTooltipText = tipText
	tip:SetTooltipPanelOverride("LZYCustomTooltip")
	self._nmResetTip = tip

	-- Request items from server
	net.Start("server:lzy_shop.night_market_request")
	net.SendToServer()

	if LZY_Shop_AttachModelDetailWarn then
		-- Crates/slots à y=115 h=764 → bas à 879 ; bandeau plus bas (sous les
		-- cartes, léger débord hors panneau) pour ne pas les chevaucher.
		LZY_Shop_AttachModelDetailWarn(self, { bottomPad = -35 })
	end
end

function PANEL:Think()
	if LZY_Shop_TickModelDetailWarn then
		LZY_Shop_TickModelDetailWarn(self)
	end
end

-- Mode TEST : si true, l'etat "revele" n'est PAS persiste. Chaque ouverture
-- du Night Market repart avec toutes les crates fermees. Mets a false (ou
-- delete le flag) une fois la feature validee pour revenir au cycle weekly.
local NM_TEST_RESET_EACH_OPEN = false

-- Cle hebdo pour persister l'etat "revele" des slots. MEME ancrage que le
-- serveur (lundi 00:00 local -> cle = date de ce lundi). %Y-%U basculait le
-- DIMANCHE : les caisses se refermaient avec encore ~1j au countdown. %Y-%W
-- cassait au Nouvel An (cle mid-semaine). Voir NightMarketWeekKey serveur.
local function NightMarketWeekKey()
	local t = os.date("*t")
	t.day = t.day - ((t.wday + 5) % 7)
	t.hour, t.min, t.sec = 0, 0, 0
	return os.date("%Y-%m-%d", os.time(t))
end

-- Cle cookie : on inclut aussi le SteamID pour eviter qu'un autre joueur sur
-- le meme PC partage l'etat revele.
local function RevealCookieKey(index)
	local lp = LocalPlayer()
	local sid = IsValid(lp) and lp:SteamID64() or "0"
	return string.format("lzy_nm_reveal_%s_%s_%d", NightMarketWeekKey(), sid, index)
end

local function IsSlotRevealed(index)
	if NM_TEST_RESET_EACH_OPEN then return false end
	return cookie.GetString(RevealCookieKey(index), "0") == "1"
end

local function MarkSlotRevealed(index)
	if NM_TEST_RESET_EACH_OPEN then return end
	cookie.Set(RevealCookieKey(index), "1")
end

-- Template HTML/CSS reproduisant l'esthetique du Night Market de Valorant.
-- OPTIMISATIONS PERF (best practices browser modern) :
--   * animations utilisent uniquement transform + opacity (GPU compositor,
--     pas de relayout/repaint cote CPU)
--   * will-change sur les elements anime longue duree pour hinter le GPU
--   * pulse de bordure passe par opacity d'un ::before au lieu de filter
--     drop-shadow (qui force un redraw du sous-arbre)
--   * glints animees via translate3d au lieu de `left` (declenche compositor
--     uniquement, pas layout)
--   * gradients statiques (computed une fois au layout, mis en cache)
--   * @media (prefers-reduced-motion) pour respecter l'accessibilite
--
-- TRANSITION REVEAL : declenchee via classList.add('revealing') :
--   Phase 1 (0-150ms)   : carte "charge", scale 1.04 + brightness x1.6
--   Phase 2 (150-280ms) : flash blanc explose, scale 1.08
--   Phase 3 (280-650ms) : carte se desintegre (scale 1.5 + opacity 0 + rotation
--                         legere du qmark)
-- Total : 650ms. Lua attend 600ms puis swap au slot item (legere overlap
-- pour cacher le flash de transition).
--
-- %s = rgb rarete (utilise 11 fois) ; %d = prix.
local CRATE_HTML_TEMPLATE = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; -webkit-user-select: none; }
html, body {
	width: 100%%; height: 100%%; overflow: hidden;
	background: transparent;
	cursor: pointer;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', 'Segoe UI', sans-serif;
}

/* Conteneur racine : sert d'origine pour le scale de reveal. */
.wrap {
	position: relative;
	width: 100%%; height: 100%%;
	transform-origin: center center;
	will-change: transform, opacity;
}

/* Bordure rareté : div statique avec gradient. Le pulse est un ::before
   superpose qui anime SEULEMENT son opacity (cheap GPU compositor).
   Note: position top/right/bottom/left explicites au lieu d'`inset` pour
   compat CEF older. */
.border {
	position: absolute;
	top: 0; right: 0; bottom: 0; left: 0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
	z-index: 0;
}
.border::before {
	content: '';
	position: absolute;
	top: -4px; right: -4px; bottom: -4px; left: -4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity: 0.35;
}
.border::after {
	content: '';
	position: absolute;
	top: 3px; right: 3px; bottom: 3px; left: 3px;
	background: #0d0e11;
}

/* Carte : fond sombre + gradient rarete subtil. OPTI : retire le
   repeating-linear-gradient diagonal (paint coute cher chaque frame quand on
   compose le background ; gain perf perceptible). On garde juste un radial
   gradient leger qui n'est pas anime. */
.crate {
	position: absolute;
	top: 4px; right: 4px; bottom: 4px; left: 4px;
	background:
		radial-gradient(ellipse at center, rgba(%s, 0.18) 0%%, rgba(0,0,0,0.97) 60%%),
		#0d0e11;
	overflow: hidden;
	z-index: 1;
}

/* Marqueurs angulaires : 4 traits aux coins facon HUD Valorant */
.corner { display:none;
	position: absolute;
	width: 26px; height: 26px;
	border: 2px solid rgba(%s, 0.9);
	z-index: 3;
}
.corner.tl { top: 14px; left: 14px; border-right: none; border-bottom: none; }
.corner.tr { top: 14px; right: 14px; border-left: none; border-bottom: none; }
.corner.bl { bottom: 84px; left: 14px; border-right: none; border-top: none; }
.corner.br { bottom: 84px; right: 14px; border-left: none; border-top: none; }

/* Halo radial pulse central : transform scale GPU-only */
.halo {
	position: absolute;
	top: 50%%; left: 50%%;
	transform: translate3d(-50%%, -50%%, 0);
	width: 80%%; height: 50%%;
	background: radial-gradient(ellipse at center, rgba(%s, 0.16) 0%%, transparent 70%%);
	animation: haloBreath 4.5s ease-in-out infinite;
	z-index: 1;
}
@keyframes haloBreath {
	0%%, 100%% { opacity: 0.5; transform: translate3d(-50%%, -50%%, 0) scale(0.95); }
	50%%      { opacity: 1;   transform: translate3d(-50%%, -50%%, 0) scale(1.05); }
}

/* "?" central massif */
.qmark {
	position: absolute;
	top: 42%%; left: 50%%;
	transform: translate3d(-50%%, -50%%, 0);
	font-size: 240px;
	font-weight: 900;
	color: #fff;
	text-shadow: 0 0 30px rgba(0,0,0,0.9), 0 0 60px rgba(0,0,0,0.6);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
	transition: transform 0.3s cubic-bezier(.2,.9,.3,1.2);
	will-change: transform;
	z-index: 2;
	letter-spacing: -8px;
}

.label { position: absolute; top: 73%%; left: 0; right: 0; text-align: center; z-index: 2; }
.label-main {
	display: block;
	font-size: 36px; font-weight: 900;
	letter-spacing: 10px;
	color: #fff;
	text-shadow: 0 2px 16px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.label-sub {
	display: block;
	margin-top: 6px;
	font-size: 14px; font-weight: 600;
	letter-spacing: 4px;
	color: rgba(255,255,255,0.55);
	animation: hintPulse 1.6s ease-in-out infinite;
}
@keyframes hintPulse { 0%%, 100%% { opacity: 0.4; } 50%% { opacity: 1; } }

.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 72px;
	background: linear-gradient(to top, rgba(0,0,0,0.95) 0%%, rgba(0,0,0,0.5) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 26px;
	z-index: 2;
}
.bar::before {
	content: '';
	position: absolute;
	top: 0; left: 18px; right: 18px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.7), transparent);
}
.bar-name { font-size: 28px; color: rgba(255,255,255,0.45); letter-spacing: 8px; font-weight: 700; }
.bar-price { font-size: 40px; color: rgba(255,255,255,0.7); font-weight: 800; }

/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }

/* Hover : subtle scale du qmark + brightness via box-shadow inset (cheap) */
body:hover .qmark { transform: translate3d(-50%%, -50%%, 0) scale(1.1); }

/* ========================================================================
   REVEAL TRANSITION : declenchee par body.classList.add('revealing')
   ======================================================================== */

/* Flash overlay (cache par defaut) */
.flash {
	position: absolute;
	top: 0; right: 0; bottom: 0; left: 0;
	background: radial-gradient(circle at center, rgba(255,255,255,0.95) 0%%, rgba(255,255,255,0.7) 30%%, transparent 70%%);
	opacity: 0;
	pointer-events: none;
	z-index: 10;
	will-change: opacity, transform;
	transform: scale(0.3);
}

/* Particules : 6 fragments qui partent en etoile vers l'exterieur.
   Rotations explicites par nth-child au lieu de CSS vars pour compat CEF.
   OPTI : box-shadow retire (un des plus chers en CSS quand anime ; le
   glow blanc du flash overlay couvre largement le besoin visuel). */
.particle {
	position: absolute;
	top: 50%%; left: 50%%;
	width: 60px; height: 4px;
	margin-top: -2px; margin-left: -30px;
	background: linear-gradient(90deg, rgba(255,255,255,0.95), rgba(%s, 0.95));
	border-radius:0;
	opacity: 0;
	transform: rotate(0deg) translate3d(0, 0, 0);
	pointer-events: none;
	z-index: 9;
}

/* Phase 1 (charge) + 2 (burst) + 3 (dissolve) sur le wrap */
body.revealing .wrap { animation: revealWrap 0.65s cubic-bezier(.5,0,.5,1) forwards; }
@keyframes revealWrap {
	0%%   { transform: scale(1); opacity: 1; }
	22%% { transform: scale(1.04); opacity: 1; }   /* charge */
	42%% { transform: scale(1.08); opacity: 1; }   /* burst */
	70%% { transform: scale(1.18); opacity: 0.6; } /* dissolve */
	100%% { transform: scale(1.45); opacity: 0; }
}

body.revealing .flash { animation: revealFlash 0.55s ease-out forwards; }
@keyframes revealFlash {
	0%%   { opacity: 0;   transform: scale(0.3); }
	28%% { opacity: 1;   transform: scale(1.1); }
	60%% { opacity: 0.8; transform: scale(1.4); }
	100%% { opacity: 0;   transform: scale(1.8); }
}

/* 6 keyframes distincts pour les 6 particules (compat CEF older : pas de
   var() dans les keyframes). Chaque particule part dans une direction
   differente, formant une etoile. */
body.revealing .particle:nth-child(1) { animation: revealParticle1 0.55s ease-out forwards; }
body.revealing .particle:nth-child(2) { animation: revealParticle2 0.55s ease-out forwards; }
body.revealing .particle:nth-child(3) { animation: revealParticle3 0.55s ease-out forwards; }
body.revealing .particle:nth-child(4) { animation: revealParticle4 0.55s ease-out forwards; }
body.revealing .particle:nth-child(5) { animation: revealParticle5 0.55s ease-out forwards; }
body.revealing .particle:nth-child(6) { animation: revealParticle6 0.55s ease-out forwards; }
@keyframes revealParticle1 {
	0%%   { opacity: 0; transform: rotate(0deg)   translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(0deg)   translate3d(280px, 0, 0); }
}
@keyframes revealParticle2 {
	0%%   { opacity: 0; transform: rotate(60deg)  translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(60deg)  translate3d(280px, 0, 0); }
}
@keyframes revealParticle3 {
	0%%   { opacity: 0; transform: rotate(120deg) translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(120deg) translate3d(280px, 0, 0); }
}
@keyframes revealParticle4 {
	0%%   { opacity: 0; transform: rotate(180deg) translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(180deg) translate3d(280px, 0, 0); }
}
@keyframes revealParticle5 {
	0%%   { opacity: 0; transform: rotate(240deg) translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(240deg) translate3d(280px, 0, 0); }
}
@keyframes revealParticle6 {
	0%%   { opacity: 0; transform: rotate(300deg) translate3d(0, 0, 0); }
	30%% { opacity: 1; }
	100%% { opacity: 0; transform: rotate(300deg) translate3d(280px, 0, 0); }
}

body.revealing .qmark { animation: revealQmark 0.45s ease-out forwards; }
@keyframes revealQmark {
	0%%   { transform: translate3d(-50%%, -50%%, 0) scale(1) rotate(0deg); opacity: 1; }
	100%% { transform: translate3d(-50%%, -50%%, 0) scale(2.2) rotate(15deg); opacity: 0; }
}

body.revealing .label, body.revealing .corner, body.revealing .bar { opacity: 0; transition: opacity 0.2s ease-out; }

/* Respect prefers-reduced-motion : transition courte sans particules */
@media (prefers-reduced-motion: reduce) {
	body.revealing .wrap { animation: revealWrap 0.2s ease-out forwards; }
	body.revealing .flash, body.revealing .particle { display: none; }
}
</style></head>
<body onclick="onCrateClick()">
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="halo"></div>
			<div class="glint"></div>
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="qmark">?</div>
			<div class="label">
				<span class="label-main">MYSTERY</span>
				<span class="label-sub">CLIQUE POUR REVELER</span>
			</div>
			<div class="bar">
				<span class="bar-name">???</span>
				<span class="bar-price">???</span>
			</div>
		</div>
		<div class="flash"></div>
		<div class="particle"></div>
		<div class="particle"></div>
		<div class="particle"></div>
		<div class="particle"></div>
		<div class="particle"></div>
		<div class="particle"></div>
	</div>
<script>
var _revealing = false;
function onCrateClick() {
	if (_revealing) return;
	_revealing = true;
	document.body.classList.add('revealing');
	// Bridge JS->Lua : on notifie immediatement, Lua attend 600ms (overlap
	// avec la fin de l'animation a 650ms) avant de swap au slot item.
	lua.Reveal();
}
</script>
</body></html>
]]

function PANEL:CreateCrateSlot(itemData, index, x)
	-- Le prix est cache sur la crate (??? dans le bottom bar) donc on ne le
	-- calcule plus ici. Reste juste la couleur rarete pour les degrades CSS.
	local itemId   = itemData.item_id or ""
	local itemDef  = itemId ~= "" and ITEMS and ITEMS[itemId] or nil
	local borderCol = GetRarityBorderColor(itemDef)

	local crate = gPanel(x, 115, 352, 764, self)
	table.insert(self._itemSlots, crate)
	crate._index = index
	crate._isCrate = true
	-- Paint vide : le rendu est entierement delegue au DHTML enfant.
	crate.Paint = function() end

	-- DHTML overlay : remplit toute la carte. Chromium embarque -> on a CSS
	-- gradients, animations, transitions sans recreer une lib draw cote Lua.
	local html = vgui.Create("DHTML", crate)
	html:Dock(FILL)
	html:SetMouseInputEnabled(true)
	html:SetCursor("hand")
	-- Bridge JS -> Lua : appele depuis onCrateClick() quand le user clique.
	-- L'anim CSS reveal dure 650ms. On laisse 600ms ecouler dans le DHTML
	-- (charge + burst + dissolve a 70%%), puis on swap au slot item -> ca
	-- masque la fin de l'anim derriere le slot et lisse la transition.
	html:AddFunction("lua", "Reveal", function()
		if not IsValid(crate) then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		-- Son de reveal dedie (cumule avec le UI_Cliquer pour feedback total).
		surface.PlaySound("a4xy732ex6yeop2/nqi6e6j88ig7brujm.mp3")
		MarkSlotRevealed(index)

		timer.Simple(0.6, function()
			if not IsValid(crate) then return end
			for k, v in ipairs(self._itemSlots or {}) do
				if v == crate then table.remove(self._itemSlots, k) break end
			end
			crate:Remove()
			if IsValid(self) then
				-- Entree du slot item : fade-in + slide-up leger pour rendre
				-- le swap moins brutal. CreateItemSlot push le slot a la fin
				-- de _itemSlots ; on le recupere juste apres pour animer.
				self:CreateItemSlot(itemData, index, x)
				local slot = self._itemSlots[#self._itemSlots]
				if IsValid(slot) then
					slot:SetAlpha(0)
					slot:AlphaTo(255, 0.25, 0)
					local origY = slot:GetY()
					slot:SetPos(slot:GetX(), origY + 20)
					slot:MoveTo(slot:GetX(), origY, 0.3, 0, 0.4)
				end
			end
		end)
	end)

	-- Couleurs CSS interpolees : 11x la meme RGB. Le prix est cache (???).
	local rgb = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)
	local htmlBody = string.format(CRATE_HTML_TEMPLATE,
		rgb, rgb, rgb,  -- border (3)
		rgb, rgb, rgb,  -- border::before (3)
		rgb,            -- crate radial (1, etait 3 avant l'opti)
		rgb,            -- corner (1)
		rgb,            -- halo (1)
		rgb,            -- bar::before (1)
		rgb             -- particle (1)
	)
	html:SetHTML(htmlBody)

	-- Hover lift : detecte via Think au lieu de OnCursorEntered/Exited car le
	-- DHTML enfant capture la souris -> les callbacks parent ne firent qu'au
	-- 1er hover puis sont silent. Le polling de mouse position dans Think est
	-- 100%% fiable (un check de mousepos par frame, negligeable en perf).
	crate.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local w, h = selff:GetWide(), selff:GetTall()
		local inside = mx >= sx and mx < sx + w and my >= sy and my < sy + h
		if inside ~= selff._hovered then
			selff._hovered = inside
			-- Repos à y=115 (MÊME baseline que les cases révélées via CreateItemSlot)
			-- pour ne pas faire dépasser/couper le bas de la crate, et éviter le saut
			-- de 30px à la révélation. Survol = petit lift de 10px vers le HAUT.
			selff:gMoveToY(inside and 105 or 115, 0.15, 0, 4)
		end
	end
end

function PANEL:OnItemsReceived(items)
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_night_market", true, self)
	end
	resetItemSlots(self)
	self._items = items
	self._loaded = true

	local x = 0
	for i, itemData in ipairs(items) do
		-- Mode "Black Market" : si le slot n'a pas encore ete revele cette
		-- semaine pour ce joueur, on affiche une crate au lieu de l'item. Une
		-- fois la crate cliquee, l'etat est persiste dans un cookie et le slot
		-- bascule sur le rendu classique.
		if itemData.sold or IsSlotRevealed(i) then
			self:CreateItemSlot(itemData, i, x)
		else
			self:CreateCrateSlot(itemData, i, x)
		end
		x = x + 352 + 20
	end
end

function PANEL:OnItemSold(offerIndex)
	for _, slot in ipairs(self._itemSlots or {}) do
		if IsValid(slot) and slot._index == offerIndex then
			slot._isSold = true
			if slot._container and IsValid(slot._container) then
				slot._container._isSold = true
			end
			-- Push la class `sold` au DHTML frame -> CSS show SOLD OUT, hide ACHETER.
			if slot._dhtmlFrame and IsValid(slot._dhtmlFrame) then
				slot._dhtmlFrame:RunJavascript("if(document.body){document.body.classList.add('sold');}")
			end
			if slot._buyButton and IsValid(slot._buyButton) then
				slot._buyButton._isSold = true
			end
			break
		end
	end
end

-- Format secondes -> "2j 14h" / "12h 34m" / "59m"
local function FormatTimeLeft(secs)
	secs = math.max(0, math.floor(secs or 0))
	local days  = math.floor(secs / 86400)
	local hours = math.floor((secs % 86400) / 3600)
	local mins  = math.floor((secs % 3600) / 60)
	if days  >= 1 then return string.format("%dj %02dh", days, hours)  end
	if hours >= 1 then return string.format("%02dh %02dm", hours, mins) end
	return string.format("%02dm", mins)
end

function PANEL:Paint()
	-- Countdown weekly : EN HAUT (à la place du titre interne retiré), MÊME
	-- position que la page Cosmétiques (top-center, juste sous le titre de
	-- catégorie affiché par l'accueil boutique). On utilise rSimpleText avec des
	-- coords DESIGN (1840/2, 50) exactement comme Cosmétiques — surtout PAS w/2
	-- (pixels actuels) qui serait double-scalé par rSimpleText.
	local secs = math.max(0, (self._nmResetAt or 0) - CurTime())
	rSimpleText("Reset dans " .. FormatTimeLeft(secs),
		"Avenir Next World:22", 1840 / 2, 50,
		Color(180, 180, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

-- Register net receivers
net.Receive("server:lzy_shop.night_market_data", function()
	-- Find the Night Market panel by walking the panel tree
	local function findPanel(root)
		if not IsValid(root) then return nil end
		if root.GetName and root:GetName() == "LZY:Shop:BlackMarket" then
			return root
		end
		if root.GetChildren then
			for _, child in ipairs(root:GetChildren()) do
				local found = findPanel(child)
				if found then return found end
			end
		end
		return nil
	end

	local panel = findPanel(vgui.GetWorldPanel())
	if not IsValid(panel) then return end

	local count = net.ReadUInt(8)
	local items = {}
	for i = 1, count do
		items[i] = {
			name     = net.ReadString(),
			title    = net.ReadString(),
			price    = net.ReadUInt(16),
			mat      = net.ReadString(),
			sold     = net.ReadBool(),
			item_id  = net.ReadString(),
			discount = net.ReadUInt(8),
		}
	end
	-- Meta : seconds_left jusqu'au reset weekly (countdown affiche dans Paint)
	local secondsLeft = net.ReadUInt(32)
	panel._nmResetAt  = CurTime() + secondsLeft
	panel:OnItemsReceived(items)
end)

net.Receive("server:lzy_shop.night_market_sold", function()
	local offerIndex = net.ReadUInt(8)

	local function findPanel(root)
		if not IsValid(root) then return nil end
		if root.GetName and root:GetName() == "LZY:Shop:BlackMarket" then
			return root
		end
		if root.GetChildren then
			for _, child in ipairs(root:GetChildren()) do
				local found = findPanel(child)
				if found then return found end
			end
		end
		return nil
	end

	local panel = findPanel(vgui.GetWorldPanel())
	if IsValid(panel) then
		panel:OnItemSold(offerIndex)
	end
end)

vgui.Register("LZY:Shop:BlackMarket", PANEL, "DPanel")
