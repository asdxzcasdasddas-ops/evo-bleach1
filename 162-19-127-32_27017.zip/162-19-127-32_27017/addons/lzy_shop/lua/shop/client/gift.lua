-- "addons\\lzy_shop\\lua\\shop\\client\\gift.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Register the gift confirmation callback
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.GiftConfirm = function(args)
	if not args then return end
	net.Start("server:lzy_shop.gift_buy")
		net.WriteString(args.targetSteamID64)
		net.WriteString(args.giftType)
		net.WriteUInt(args.configIndex, 8)
		net.WriteString(args.rerollCategory or "")
	net.SendToServer()
end

function PANEL:MakePlayerList()
	if IsValid(self.scroll) then self.scroll:Remove() end
	local scroll = vgui.Create("DScrollPanel", self)
	scroll:gSetPos(0, 80)
	scroll:gSetSize(406, 491 - 80 - 10)

	local vbar = scroll:GetVBar()
	vbar:SetHideButtons(true)
	vbar:gSetSize(0, 0)
	vbar:gSetPos(0, 0)
	function vbar:Paint(w, h) end
	function vbar.btnGrip:Paint(w, h) end

	-- Build filtered list
	local searchText = string.lower(self.searchEntry:GetValue() or "")
	local filtered = {}
	for _, ply in player.Iterator() do
		if not IsValid(ply) or ply == LocalPlayer() then continue end
		if searchText == "" or string.find(string.lower(ply:GetEvoNWString("Nickname")), searchText, 1, true) then
			table.insert(filtered, ply)
		end
	end

	local y = 0
	for _, ply in ipairs(filtered) do
		local ply_panel = gPanel(20, y, 406 - 40, 50, scroll)
		ply_panel.ply = ply
		ply_panel.Paint = function()
			rRect(0, 0, 406 - 40, 50, ply:GetEvoNWInt("premium", 0) > 0 and Color(255, 187, 0, 255 * 0.2) or Color(18, 18, 18), 6)
			rSimpleText(ply:GetEvoNWString("Nickname"), "Avenir Next World:20", 56, 25, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			if ply:GetEvoNWInt("premium", 0) > 0 then
				rSimpleText("Already Premium", "Avenir Next World Bold:20", 406 - 40 - 10, 25, Color(255, 187, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end

			if not ply_panel.hovered then return end
			rOutlinedRect(0, 0, 406 - 40, 50, ply:GetEvoNWInt("premium", 0) > 0 and Color(255, 187, 0, 255 * 0.15) or Color(103, 103, 103, 255 * 0.55), 6, 2)
		end

		local avatar = vgui.Create("AvatarImage", ply_panel)
		avatar:gSetPos(6, 6)
		avatar:gSetSize(38, 38)
		avatar:SetPlayer(ply, 38)

		ply_panel.OnCursorEntered = function() ply_panel.hovered = true ply_panel:SetCursor("hand") end
		ply_panel.OnCursorExited = function() ply_panel.hovered = false ply_panel:SetCursor("arrow") end
		ply_panel.OnMousePressed = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			local targetName = ply:GetEvoNWString("Nickname")
			LocalPlayer():OpenYesNoPopup(
				"Voulez-vous vraiment offrir cet article à " .. targetName .. " ?",
				"GiftConfirm",
				{
					targetSteamID64 = ply:SteamID64(),
					giftType = self.giftType,
					configIndex = self.configIndex,
					rerollCategory = self.rerollCategory,
				}
			)
			self:Close()
		end

		y = y + 60
	end

	self.scroll = scroll
end

function PANEL:Init()
	self:gSetSize(406, 491)
	self:Center()
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetDraggable(false)
	self:SetTitle("")
	self:ShowCloseButton(false)

	-- Fond MODAL plein écran (fix 08/07 : le panneau OFFRIR ne se fermait pas
	-- au clic en dehors, il passait juste DERRIÈRE la boutique). Le backdrop
	-- capte les clics hors du panneau et le ferme ; léger assombrissement pour
	-- signaler la modale. Créé APRÈS le MakePopup du panneau puis on remet le
	-- panneau au premier plan -> backdrop derrière, panneau devant.
	local backdrop = vgui.Create("DButton")
	self._backdrop = backdrop
	backdrop:SetText("")
	backdrop:SetSize(ScrW(), ScrH())
	backdrop:SetPos(0, 0)
	backdrop:MakePopup()
	backdrop.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 90)
		surface.DrawRect(0, 0, w, h)
	end
	backdrop.DoClick = function()
		if IsValid(self) then self:Close() end
	end
	self:MoveToFront()
	self:MakePopup()

	self.selected = nil
	self.giftType = ""
	self.configIndex = 0
	self.rerollCategory = ""

	-- Barre de recherche
	self.searchEntry = vgui.Create("DTextEntry", self)
	self.searchEntry:gSetPos(190, 35)
	self.searchEntry:gSetSize(143, 30)
	self.searchEntry:SetPlaceholderText("Rechercher un joueur...")
	self.searchEntry:SetDrawLanguageID(false)

	self.searchEntry.Paint = function()
		rRect(0, 0, 143, 30, Color(24, 24, 24), 6)
		rOutlinedRect(0, 0, 143, 30, Color(82, 82, 82), 6, 1)
		if not self.searchEntry:HasFocus() and self.searchEntry:GetValue() == "" then
			rSimpleText("RECHERCHER...", "Avenir Next World:20", 5, 5, Color(255, 255, 255, 255 * 0.22))
		else
			self.searchEntry:DrawTextEntryText(color_white, self.searchEntry:GetHighlightColor(), color_white)
		end
	end

	self.searchEntry.OnChange = function()
		self:MakePlayerList()
	end

	self:MakePlayerList()
end

-- Ferme = retire le backdrop modal PUIS le panneau (avant : Close() par défaut
-- ne faisait que cacher -> le panneau restait en mémoire et le backdrop pouvait
-- rester à bloquer les clics). Appelé au clic dehors, au clic joueur, à Échap.
function PANEL:Close()
	if IsValid(self._backdrop) then self._backdrop:Remove() end
	self:Remove()
end

function PANEL:OnRemove()
	if IsValid(self._backdrop) then self._backdrop:Remove() end
end

function PANEL:Paint()
	rRect(0, 0, 406, 491, Color(9, 9, 9), 12)
	rSimpleText("Offrir à", "Avenir Next World:30", 93, 36)
end

vgui.Register("LZY:Shop:Gift", PANEL, "DFrame")
