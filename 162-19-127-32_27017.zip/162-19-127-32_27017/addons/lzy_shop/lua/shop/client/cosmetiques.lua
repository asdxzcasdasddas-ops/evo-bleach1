-- "addons\\lzy_shop\\lua\\shop\\client\\cosmetiques.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- Confirmation d'achat (demande user 2026-07-16) : le clic ACHETER ouvre une popup
-- "Confirmer l'achat ?" (LZY:Popup yesno, meme pattern que le night market) ; l'achat
-- ne part au serveur QUE si le joueur confirme.
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_Cosmetique_Buy = function(args)
	if not args or not args.index then return end
	net.Start("server:lzy_shop.cosmetique_buy")
		net.WriteUInt(tonumber(args.index) or 0, 8)
		-- On envoie AUSSI l'objet qu'on croit acheter : le serveur refuse si sa vitrine
		-- ne correspond pas. Sans ca, un simple decalage d'affichage faisait acheter
		-- l'article que le serveur avait a cette position, pas celui affiche.
		net.WriteString(tostring(args.item_id or ""))
	net.SendToServer()
end

local function GetDiscountedPrice(price)
	if SHOP_CONFIG.CREATOR_CODE_DISCOUNT == 0 then return price, false end
	local ply = LocalPlayer()
	if not IsValid(ply) then return price, false end
	local code = ply:GetEvoNWString("CreatorCode", "")
	if code == "" then return price, false end
	local discounted = math.floor(price * (100 - SHOP_CONFIG.CREATOR_CODE_DISCOUNT) / 100)
	return discounted, true
end

-- (table `materials` retiree : la coin etait utilisee par text_label.Paint,
-- maintenant la coin est inline en base64 dans le DHTML bar.)

-- Palette bordure par rarete (memes cles que INVENTORY_CONFIG.raritiesColor)
local RARITY_BORDER_COLOR = {
	common    = Color(180, 180, 180, 200),
	rare      = Color(110, 170, 255, 220),
	epic      = Color(150, 70,  220, 240),
	legendary = Color(255, 210, 90,  240),
	mythic    = Color(255, 95,  95,  240),
}
local function GetRarityBorderColor(itemDef)
	local r = itemDef and isstring(itemDef.rarity) and string.lower(itemDef.rarity) or "common"
	return RARITY_BORDER_COLOR[r] or RARITY_BORDER_COLOR.common
end

-- Accent DA dashboard : ambiance ROUGE standard de la boutique (#cf444e).
local ACCENT = Color(207, 68, 78)

local CARD_W    = 352
local CARD_H    = 321
local COL_STEP  = 390
local ROW_STEP  = CARD_H + 20
local COLS      = 4
local GRID_X    = 226 - 40
local TITLE_H   = 125 -- design-unit height reserved above the scroll area for the title
local SBAR_W    = 6   -- design-unit scrollbar width

-- ============================================================================
-- DESIGN VALORANT (mirror du night market) : DHTML frame + helpers.
-- Le card est plus petit (321 vs 764) donc proportions adaptees : bar 50px
-- au lieu de 72, corners.bl/br a bottom:60 au lieu de 84.
-- ============================================================================

-- Coin image (memes evocoins) inline en base64.
local _COIN_DATA_URI = ""
do
	local raw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	if raw and raw ~= "" then
		_COIN_DATA_URI = "data:image/png;base64," .. util.Base64Encode(raw, true)
	end
end

-- Eye icon : cos/sin + polygons reutilises in-place pour eviter allocations
-- 3 tables x 18 entries par frame par icone. Avec ~8 cards visibles c'est
-- 432 allocations evitees / frame.
local _EYE_SEGS = 18
local _EYE_COS, _EYE_SIN = {}, {}
for i = 0, _EYE_SEGS - 1 do
	local a = (i / _EYE_SEGS) * math.pi * 2
	_EYE_COS[i + 1] = math.cos(a)
	_EYE_SIN[i + 1] = math.sin(a)
end
-- Polygons reutilises : tables avec entries pre-allouees, on update les
-- coords in-place a chaque draw.
local _EYE_POLY_OUTER = {}
local _EYE_POLY_INNER = {}
local _EYE_POLY_PUPIL = {}
for i = 1, _EYE_SEGS do
	_EYE_POLY_OUTER[i] = { x = 0, y = 0 }
	_EYE_POLY_INNER[i] = { x = 0, y = 0 }
	_EYE_POLY_PUPIL[i] = { x = 0, y = 0 }
end
local function DrawEyeIcon(cx, cy, w, h, col, bgCol)
	local hw, hh = w * 0.5, h * 0.5
	-- Inner ellipse offset PROPORTIONNEL a la taille (pas pixels fixes) pour
	-- que l'epaisseur du "ring" scale avec la resolution. ~10% du demi-axe.
	local ihw, ihh = hw * 0.88, hh * 0.85
	local pr = math.min(hw, hh) * 0.42
	for i = 1, _EYE_SEGS do
		local cosA, sinA = _EYE_COS[i], _EYE_SIN[i]
		local po = _EYE_POLY_OUTER[i]; po.x = cx + cosA * hw;  po.y = cy + sinA * hh
		local pi = _EYE_POLY_INNER[i]; pi.x = cx + cosA * ihw; pi.y = cy + sinA * ihh
		local pp = _EYE_POLY_PUPIL[i]; pp.x = cx + cosA * pr;  pp.y = cy + sinA * pr
	end
	draw.NoTexture()
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_OUTER)
	surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a or 255)
	surface.DrawPoly(_EYE_POLY_INNER)
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_PUPIL)
end

-- Template HTML/CSS du frame Valorant adapte au card 352x321 cosmetiques.
-- DA dashboard 08/07 : fond = plaque #0d0e11 (Color(13,14,17)) ; hover = voile
-- clair NEUTRE. La bordure de rarete reste LA bordure de la carte (fonctionnelle,
-- inchangee) -> pas de bordure accent en plus au survol.
-- 11 placeholders (10 rgb + 1 barHTML string).
local CARD_FRAME_HTML_COSM = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%%; height:100%%; overflow:hidden; background:transparent; }
.wrap { position:relative; width:100%%; height:100%%; transition: transform 0.2s ease-out; }
.border {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: linear-gradient(135deg, rgba(%s, 0.30), rgba(%s, 0.30) 50%%, rgba(%s, 0.30));
}
.border::before {
	content:''; position:absolute; top:-4px; right:-4px; bottom:-4px; left:-4px;
	background: linear-gradient(135deg, rgba(%s, 0.10), rgba(%s, 0.10) 50%%, rgba(%s, 0.10));
	opacity:0.35;
}
.border::after {
	content:''; position:absolute; top:3px; right:3px; bottom:3px; left:3px;
	background:#0d0e11;
}
.crate {
	position:absolute; top:4px; right:4px; bottom:4px; left:4px;
	background: radial-gradient(ellipse at top, rgba(%s, 0.15) 0%%, rgba(0,0,0,0.96) 70%%), #0d0e11;
	overflow:hidden; z-index:1;
}
/* Corners 4 coins (top + bottom), bottom au-dessus de la bar (60px) */
.corner { display:none;
	position:absolute; width:18px; height:18px;
	border:2px solid rgba(%s, 0.9); z-index:3;
	transition: border-color 0.15s ease-out;
}
.corner.tl { top:10px; left:10px; border-right:none; border-bottom:none; }
.corner.tr { top:10px; right:10px; border-left:none; border-bottom:none; }
.corner.bl { bottom:60px; left:10px; top:auto; border-right:none; border-top:none; }
.corner.br { bottom:60px; right:10px; top:auto; border-left:none; border-top:none; }
/* Glints retires (anim qui balayait la card) -- perf + user pref */
.glint { display: none; }
@keyframes sweep {
	0%%   { transform: translate3d(-120px, 0, 0) skewX(-25deg); }
	100%% { transform: translate3d(420px, 0, 0) skewX(-25deg); }
}
/* Hover : scale + voile clair NEUTRE (recette carte DA dashboard — remplace
   le glow radial teinte rarete ; la rarete garde bordure/fond/liseré).
   Scale INVERSE (fix 08/07 bords rognes) : repos retracte a 0.99, survol =
   scale(1) -> grossit sans sortir du viewport (avant scale(1.015) = rogne). */
body.hovered .wrap { -webkit-transform: translate(-4px, -4px); }
.hover-glow {
	position:absolute; top:0; right:0; bottom:0; left:0;
	background: rgba(226, 230, 238, 0.04);
	opacity: 0; transition: opacity 0.2s ease-out;
	pointer-events: none; z-index: 2;
}
body.hovered .hover-glow { opacity: 1; }
body.hovered .corner { display:none; border-color: rgba(%s, 1); }

/* SOLD OUT label : meme position top:73%% que MYSTERY/ACHETER */
.sold-label {
	position: absolute;
	top: 60%%; left: 0; right: 0;
	text-align: center;
	z-index: 6;
	display: none;
	pointer-events: none;
}
/* SOLD OUT du DHTML desactive : il est maintenant dessine en PaintOver Lua
   (devant le model 3D). On garde juste le fade de la barre. */
body.sold .sold-label { display: none; }
body.sold .bar { opacity: 0.25; }
.sold-main {
	display: block;
	font-size: 28px;
	font-weight: 900;
	letter-spacing: 8px;
	color: rgb(255, 80, 80);
	text-shadow: 0 2px 14px rgba(0,0,0,0.95);
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}

/* Bar bottom (50px, plus petite que night market 72px) */
.bar {
	position: absolute;
	bottom: 0; left: 0; right: 0;
	height: 50px;
	background: linear-gradient(to top, rgba(0,0,0,0.95) 0%%, rgba(0,0,0,0.5) 80%%, transparent);
	display: flex; align-items: center; justify-content: space-between;
	padding: 0 22px;
	z-index: 5;
}
.bar::before {
	content: ''; position: absolute;
	top: 0; left: 16px; right: 16px;
	height: 1px;
	background: linear-gradient(90deg, transparent, rgba(%s, 0.7), transparent);
}
.bar-old {
	font-size: 20px;
	color: rgba(255,255,255,0.5);
	text-decoration: line-through;
	text-decoration-color: rgba(255, 80, 80, 0.85);
	letter-spacing: 1px;
	font-weight: 700;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-right { display: flex; align-items: center; gap: 10px; }
.bar-discount {
	font-size: 20px;
	color: rgb(255, 80, 80);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-new {
	font-size: 28px;
	color: rgb(0, 235, 120);
	font-weight: 800;
	letter-spacing: 1px;
	font-family: 'Tungsten', 'Bebas Neue', 'Impact', sans-serif;
}
.bar-coin {
	width: 22px; height: 22px;
	vertical-align: middle;
	image-rendering: -webkit-optimize-contrast;
}
</style></head>
<body>
	<div class="wrap">
		<div class="border"></div>
		<div class="crate">
			<div class="corner tl"></div>
			<div class="corner tr"></div>
			<div class="corner bl"></div>
			<div class="corner br"></div>
			<div class="glint"></div>
			<div class="hover-glow"></div>
			<div class="sold-label">
				<span class="sold-main">SOLD OUT</span>
			</div>
			%s
		</div>
	</div>
</body></html>
]]

function PANEL:CreateItem(row, x, y, itemIndex, canvas)
	local itemData        = row.item_id and ITEMS and ITEMS[row.item_id]
	local name            = (itemData and itemData.name) or "?"
	local basePrice       = tonumber(row.price) or 0
	local nmDisc          = math.Clamp(tonumber(row.discount) or 0, 0, 100)
	-- Remise de vitrine, puis promo globale (COSMETIQUES_SHOP_CONFIG.promo_pct).
	local price           = LZY_Shop_ApplyCosmetiquePromo(math.floor(basePrice * (100 - nmDisc) / 100))
	local isSold          = row.sold or false
	-- (category, desc, mat retires : tout est rendu dans le DHTML frame)

	local useModel        = LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(itemData)
	local gift            = nil
	local buy             = nil
	local text_label      = nil
	local button_selected = false

	local container       = gPanel(x, y, CARD_W, CARD_H, canvas)
	container:SetMouseInputEnabled(true)
	container.selected = false

	-- ========================================================================
	-- DHTML frame Valorant (mirror du night market). Mount EN PREMIER pour
	-- qu'il paint derriere les autres VGUI children.
	-- ========================================================================
	local borderCol = GetRarityBorderColor(itemData)
	local rgb = string.format("%d, %d, %d", borderCol.r, borderCol.g, borderCol.b)

	-- Pre-calc des prix (final + discount %)
	local _finalPrice = GetDiscountedPrice(price)
	local _hasDisc = _finalPrice < basePrice
	local _discPct = math.floor((basePrice - _finalPrice) / math.max(basePrice, 1) * 100 + 0.5)

	-- Bar HTML : avec ou sans discount, prix + coin image (memes evocoins).
	local barHTML
	if _hasDisc then
		barHTML = string.format([[
<div class="bar">
	<span class="bar-old">%d</span>
	<span class="bar-right">
		<span class="bar-discount">-%d%%</span>
		<span class="bar-new">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>]], basePrice, _discPct, _finalPrice, _COIN_DATA_URI)
	else
		barHTML = string.format([[
<div class="bar">
	<span></span>
	<span class="bar-right">
		<span class="bar-new">%d</span>
		<img class="bar-coin" src="%s">
	</span>
</div>]], price, _COIN_DATA_URI)
	end

	local frame = vgui.Create("DHTML", container)
	frame:Dock(FILL)
	frame:SetMouseInputEnabled(false)
	frame:SetHTML(string.format(CARD_FRAME_HTML_COSM,
		rgb, rgb, rgb,  -- border (3)
		rgb, rgb, rgb,  -- border::before (3)
		rgb,            -- crate radial (1)
		rgb,            -- corner (1)
		rgb,            -- corner hover (1)
		rgb,            -- bar liseré (1)
		barHTML         -- bar HTML
	))
	container._dhtmlFrame = frame

	if isSold then
		timer.Simple(0.2, function()
			if IsValid(frame) then
				frame:RunJavascript("if(document.body){document.body.classList.add('sold');}")
			end
		end)
	end


	-- Hover : trigger sur TOUTE la carte SAUF badge categorie (top-left) et bouton preview
	-- (top-right). Exclusion zones en design units (CARD_W=352) :
	--   Badge categorie : x=0..120, y=0..36
	--   Bouton preview  : x=210..CARD_W, y=0..50
	local function inExclusionZone(lxDesign, lyDesign)
		if lyDesign < 36 and lxDesign < 120 then return true end
		if lyDesign < 50 and lxDesign >= 210 then return true end
		return false
	end

	container.Think = function(selff)
		if not IsValid(selff) then return end
		local mx, my = gui.MousePos()
		local sx, sy = selff:LocalToScreen(0, 0)
		local lx, ly = mx - sx, my - sy
		local w, h = selff:GetWide(), selff:GetTall()
		local lxDesign = (gRespX and gRespX(1) > 0) and (lx / gRespX(1)) or lx
		local lyDesign = (gRespY and gRespY(1) > 0) and (ly / gRespY(1)) or ly
		local insideCard = lx >= 0 and lx < w and ly >= 0 and ly < h
		local inHoverZone = insideCard and not inExclusionZone(lxDesign, lyDesign)
		if inHoverZone ~= selff._inHoverZone then
			selff._inHoverZone = inHoverZone
			-- Push hovered class au DHTML frame -> CSS scale + glow
			if IsValid(frame) then
				frame:RunJavascript(inHoverZone
					and "if(document.body){document.body.classList.add('hovered');}"
					or  "if(document.body){document.body.classList.remove('hovered');}")
			end
			if inHoverZone then
				selff.selected = true
				gift:gMoveToY(CARD_H - 50, 0.2, 0, 4)
				buy:gMoveToY(CARD_H - 50, 0.2, 0, 4)
				text_label:gMoveToY(0, 0.2, 0, 4)
			else
				timer.Simple(0, function()
					if IsValid(selff) and button_selected == false then
						selff.selected = false
						if IsValid(gift) then gift:gMoveToY(CARD_H, 0.2, 0, 4) end
						if IsValid(buy) then buy:gMoveToY(CARD_H, 0.2, 0, 4) end
						if IsValid(text_label) then text_label:gMoveToY(CARD_H - 50, 0.2, 0, 4) end
					end
				end)
			end
		end
	end
	-- container.Paint vide : le rendu (frame + bar + sold) est entierement dans
	-- le DHTML. Plus de rMaterials material bg, plus de badge category.
	container.Paint = function() end
	-- Name top-left faded (meme style que night market).
	-- PaintOver rend APRES les enfants (model 3D inclus), donc le SOLD OUT
	-- dessine ici passe DEVANT la tenue 3D (avant il etait masque par le model).
	container.PaintOver = function()
		-- Nom de l'item : DA Bebas (display), faded top-left.
		rSimpleText(string.upper(name), "Bebas Neue:20", 18, 22,
			Color(255, 255, 255, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if isSold then
			-- Au survol, les boutons (OFFRIR / ACHETE) montent dans la rangée du bas
			-- (y = CARD_H-50). On arrête le voile au-dessus pour laisser le bouton
			-- OFFRIR visible et cliquable même quand l'article est sold out.
			local veilBottom = container.selected and (CARD_H - 50) or CARD_H
			rRect(0, 0, CARD_W, veilBottom, Color(8, 8, 10, 160))
			local cx = CARD_W * 0.5
			local cy = veilBottom * 0.52
			-- Ombre (offset) puis texte rouge, pour la lisibilite sur fond clair.
			rSimpleText("SOLD OUT", "Bebas Neue:38", cx + 2, cy + 2,
				Color(0, 0, 0, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText("SOLD OUT", "Bebas Neue:38", cx, cy,
				Color(255, 80, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Install the loader after the card overlay so its spinner remains visible.
	if useModel then
		-- Accessoires : margin tres serree (=zoom max). Le vrai levier de zoom
		-- c'est `margin` (multiplicateur de distance camera vs fit parfait),
		-- pas FOV (FOV-independant car dist scale avec FOV inversement).
		local isAcc = itemData and itemData.category == "accessory"
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(container, itemData, 30, isAcc and 0.55 or nil, nil, true)
	end

	-- text_label : panel transparent qui sert juste de proxy pour le slide
	-- (vers y=0 on hover). La bar (prix + coin + SOLD OUT) est rendue dans
	-- le DHTML frame. text_label.Paint est vide.
	text_label = gPanel(0, CARD_H - 50, CARD_W, 50, container)
	text_label:SetMouseInputEnabled(false)
	text_label.Paint = function() end

	gift = gPanel(0, CARD_H, 176, 50, container)
	gift.opacity = 0.15
	gift.OnCursorEntered = function()
		gift:SetCursor("hand")
		gift.opacity = 0.30
		button_selected = true
		container.selected = true
	end
	gift.OnCursorExited = function()
		gift:SetCursor("arrow")
		gift.opacity = 0.15
		button_selected = false
		container.selected = false
		timer.Simple(0, function()
			if not IsValid(container) then return end
			if container.selected == false and button_selected == false then
				if IsValid(gift) then gift:gMoveToY(CARD_H, 0.2, 0, 4) end
				if IsValid(buy) then buy:gMoveToY(CARD_H, 0.2, 0, 4) end
				if IsValid(text_label) then text_label:gMoveToY(CARD_H - 50, 0.2, 0, 4) end
			end
		end)
	end
	gift.OnMousePressed = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		local giftPanel = vgui.Create("LZY:Shop:Gift", self:GetParent())
		giftPanel.giftType = "cosmetique"
		giftPanel.configIndex = itemIndex
	end
	gift.Paint = function(s, w, h)
		-- DA dashboard : aplat plein (vert = don), coin bas-GAUCHE coupé (chanfrein
		-- extérieur, symétrique du ACHETER à droite) + texte blanc Bebas.
		local base = (EVO_UI and EVO_UI.Col and EVO_UI.Col.green) or Color(78, 196, 128)
		if EVO_UI and EVO_UI.PaintCut then
			-- OFFRIR « plein » (demande user 08/07 : cartes cosmétiques CARRÉES ->
			-- les 2 boutons pleins). cut 0 = rectangle plein (pas de chanfrein).
			local pts = EVO_UI.PaintCut(0, 0, w, h, base, 0, "bl")
			if pts and gift.opacity > 0.16 then
				draw.NoTexture()
				surface.SetDrawColor(255, 255, 255, 26)
				surface.DrawPoly(pts)
			end
		else
			rRect(0, 0, 176, 50, base)
		end
		rSimpleText("OFFRIR", "Bebas Neue:22", 88, 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	buy = gPanel(176, CARD_H, 176, 50, container)
	buy.opacity = 0.25
	buy.OnCursorEntered = function()
		buy:SetCursor("hand")
		buy.opacity = 0.35
		button_selected = true
		container.selected = true
	end
	buy.OnCursorExited = function()
		buy:SetCursor("arrow")
		buy.opacity = 0.25
		button_selected = false
		container.selected = false
		timer.Simple(0, function()
			if not IsValid(container) then return end
			if container.selected == false and button_selected == false then
				if IsValid(gift) then gift:gMoveToY(CARD_H, 0.2, 0, 4) end
				if IsValid(buy) then buy:gMoveToY(CARD_H, 0.2, 0, 4) end
				if IsValid(text_label) then text_label:gMoveToY(CARD_H - 50, 0.2, 0, 4) end
			end
		end)
	end
	buy.OnMousePressed = function()
		if isSold then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(price) then return end
		-- Confirmation avant achat (demande user) : l'achat part dans le callback popup.
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Confirmer l'achat de " .. name .. " ?", "LzyShop_Cosmetique_Buy", { index = itemIndex, item_id = tostring(row.item_id or "") })
		end
	end
	buy.Paint = function(s, w, h)
		if isSold then
			rRect(0, 0, 176, 50, Color(34, 36, 42, 255))
			rSimpleText("ACHETE", "Bebas Neue:22", 88, 25, Color(140, 140, 140), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		-- ACHETER « complet » (demande user 08/07) : rectangle PLEIN, PAS de coin
		-- coupé (identique au reroll) + voile clair au survol + texte blanc Bebas.
		rRect(0, 0, 176, 50, ACCENT)
		if buy.opacity > 0.26 then
			rRect(0, 0, 176, 50, Color(255, 255, 255, 26))
		end
		rSimpleText("ACHETER", "Bebas Neue:22", 88, 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Eye preview button : TOP-RIGHT, faded, sans encadré (mirror du night
	-- market). Taille reduite (user feedback : trop gros) -> button 32x20.
	if itemData and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open then
		local EYE_W, EYE_H = 32, 20
		local previewBtn = gPanel(CARD_W - EYE_W - 10, 8, EYE_W, EYE_H, container)
		previewBtn:SetZPos(1000)
		previewBtn:SetCursor("hand")
		previewBtn:SetTooltip("Aperçu sur ton perso")
		previewBtn:SetAlpha(130)
		previewBtn.OnCursorEntered = function()
			previewBtn:Stop(); previewBtn:AlphaTo(255, 0.15, 0)
		end
		previewBtn.OnCursorExited = function()
			previewBtn:Stop(); previewBtn:AlphaTo(130, 0.15, 0)
		end
		previewBtn.OnMousePressed = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			LZY_SHOP_COSMETIC_PREVIEW.Open(itemData)
		end
		local _fg    = Color(230, 230, 240, 240)
		local _bgCol = Color(10, 10, 14, 255)
		previewBtn.Paint = function(_, w, h)
			-- Responsive : icone proportionnelle a la taille du bouton.
			DrawEyeIcon(w / 2, h / 2, w * 0.82, h * 0.72, _fg, _bgCol)
		end
	end

	-- Store ref to update isSold dynamically
	container._cosmetiqueIndex = itemIndex
	container.SetSold = function()
		isSold = true
		-- Push sold class au DHTML -> SOLD OUT visible + bar fadee.
		if container._dhtmlFrame and IsValid(container._dhtmlFrame) then
			container._dhtmlFrame:RunJavascript("if(document.body){document.body.classList.add('sold');}")
		end
	end
	canvas._cosmContainers = canvas._cosmContainers or {}
	canvas._cosmContainers[itemIndex] = container
end

function PANEL:Init()
	self._cosmResetAt       = 0
	self._cosmRefreshesLeft = 0

	-- Hitbox invisible sur le countdown (rSimpleText n'est pas hoverable).
	-- Style sombre LZYCustomTooltip (meme UI que reroll / night market).
	local tipText = "Réinitialisation tous les jours à 00:00 pour tous les joueurs."
	local tip = vgui.Create("DPanel", self)
	tip:gSetPos(1840 / 2 - 160, 40)
	tip:gSetSize(320, 36)
	tip:SetPaintBackground(false)
	tip:SetMouseInputEnabled(true)
	tip:SetCursor("hand")
	tip:SetTooltip(tipText)
	tip.strTooltipText = tipText
	tip:SetTooltipPanelOverride("LZYCustomTooltip")
	self._cosmResetTip = tip

	-- DScrollPanel pour les items
	local scroll = vgui.Create("DScrollPanel", self)
	scroll:gSetPos(0, TITLE_H)
	scroll:gSetSize(1840, 900 - TITLE_H)
	scroll.Paint = function() end
	self._scroll = scroll

	local vbar = scroll:GetVBar()
	vbar:SetWide(gRespX(SBAR_W))
	vbar.Paint         = function(_, w, h)
		surface.SetDrawColor(20, 20, 20, 255)
		surface.DrawRect(0, 0, w, h)
	end
	vbar.btnUp.Paint   = function() end
	vbar.btnDown.Paint = function() end
	vbar.btnGrip.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255, 60)
		surface.DrawRect(0, 0, w, h)
	end

	-- ============================================================================
	-- Bouton "RAFRAICHIR" : Valorant DA neutre (gris/noir, pas de gold).
	-- Layout 100%% en design space avec align LEFT/RIGHT pour eviter le mix
	-- screen-pixel / design-space qui faisait deborder le texte.
	-- ============================================================================
	local REFRESH_W, REFRESH_H = 240, 50
	local REFRESH_COST = math.floor(tonumber((COSMETIQUES_SHOP_CONFIG or {}).refresh_cost) or 500)
	local coinMat = Material("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "smooth")

	local refreshBtn = vgui.Create("DButton", self)
	refreshBtn:gSetPos(1580, 55)
	refreshBtn:gSetSize(REFRESH_W, REFRESH_H)
	refreshBtn:SetText("")
	refreshBtn:SetCursor("hand")
	refreshBtn:SetTooltip(string.format("Coût : %d coins", REFRESH_COST))
	self._refreshBtn = refreshBtn

	refreshBtn.Paint = function(s, w, h)
		-- DA dashboard 08/07 : plaque Atelier plate coin bas-droit coupé +
		-- bordure accent au survol (remplace le style Valorant gris à L-corners).
		local hf = (EVO_UI and EVO_UI.HoverFrac) and EVO_UI.HoverFrac(s, 10) or (s:IsHovered() and 1 or 0)
		local pts
		if EVO_UI and EVO_UI.PaintCut then
			pts = EVO_UI.PaintCut(0, 0, w, h,
				hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 220), gRespY(10), "br")
		else
			rRect(0, 0, REFRESH_W, REFRESH_H, Color(14, 14, 18, 240))
		end
		if pts and hf > 0.02 then
			-- Bordure INSET 1px (fix 08/07 : les bords droit/bas étaient coupés
			-- par le clipping du panneau).
			EVO_UI.HoverOutline(w, h, ColorAlpha(Color(207, 68, 78), 235 * hf), gRespY(10), "br")
		end

		-- Layout fixe en design space (no GetTextSize) :
		--   "RAFRAICHIR" align left a x=16
		--   Coin icon a x=REFRESH_W - 16 - coinSz (=210), 18x18 centre vertical
		--   Prix align right juste a gauche du coin (x=REFRESH_W - 38)
		local y        = REFRESH_H / 2
		local coinSize = 18
		local coinX    = REFRESH_W - 16 - coinSize

		rSimpleText("RAFRAÎCHIR", "Bebas Neue:22",
			16, y, hf > 0.02 and Color(238, 239, 243) or Color(200, 203, 209), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rSimpleText(tostring(REFRESH_COST), "Bebas Neue:20",
			coinX - 4, y, Color(255, 255, 255, 220), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		rMaterials(coinMat, coinX, y - coinSize / 2, coinSize, coinSize)
	end

	refreshBtn.DoClick = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		-- Pas assez de coins : LZY_Shop_CanAfford affiche la notif ; en plus on
		-- redirige vers l'onglet Coins pour en acheter (comme l'achat de rerolls).
		if LZY_Shop_CanAfford and not LZY_Shop_CanAfford(REFRESH_COST) then
			if LZY_Shop_OpenCoins then LZY_Shop_OpenCoins() end
			return
		end
		local lp = LocalPlayer()
		if IsValid(lp) and lp.OpenYesNoPopup then
			lp:OpenYesNoPopup(
				string.format("Rafraîchir la boutique cosmétique pour %d coins ?", REFRESH_COST),
				"LzyShop_CosmRefresh_Confirm",
				{}
			)
		else
			net.Start("server:lzy_shop.cosmetiques_refresh")
			net.SendToServer()
		end
	end

	-- Request initial data
	net.Start("server:lzy_shop.cosmetiques_request")
	net.SendToServer()

	if LZY_Shop_AttachModelDetailWarn then
		LZY_Shop_AttachModelDetailWarn(self)
	end
end

function PANEL:Think()
	if LZY_Shop_TickModelDetailWarn then
		LZY_Shop_TickModelDetailWarn(self)
	end
end

function PANEL:OnItemsReceived(items)
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("shop_cosmetiques", true, self)
	end
	if not IsValid(self._scroll) then return end
	-- Clear previous canvas
	local canvas = self._scroll:GetCanvas()
	canvas._cosmContainers = {}
	for _, child in ipairs(canvas:GetChildren()) do
		if IsValid(child) then child:Remove() end
	end

	local x = GRID_X
	local y = 20
	for i, row in ipairs(items) do
		self:CreateItem(row, x, y, i, canvas)
		x = x + COL_STEP
		if i % COLS == 0 then
			x = GRID_X
			y = y + ROW_STEP
		end
	end
	self._scroll:Rebuild()
end

-- Format secondes -> "2j 14h" / "12h 34m" / "59m"
local function FormatTimeLeft(secs)
	secs = math.max(0, math.floor(secs or 0))
	local days  = math.floor(secs / 86400)
	local hours = math.floor((secs % 86400) / 3600)
	local mins  = math.floor((secs % 3600) / 60)
	if days  >= 1 then return string.format("%dj %02dh", days, hours)  end
	if hours >= 1 then return string.format("%02dh %02dm", hours, mins) end
	return string.format("%02dm", mins)
end

function PANEL:Paint()
	-- (Titre interne RETIRÉ — 08/07 : le titre de la catégorie est affiché en
	-- haut-centre par l'accueil boutique, il était en DOUBLE ici. Le compteur
	-- de reset reste, remonté à la place du titre.)
	local secs = math.max(0, (self._cosmResetAt or 0) - CurTime())
	rSimpleText("Reset dans " .. FormatTimeLeft(secs),
		"Avenir Next World:22", 1840 / 2, 50,
		Color(180, 180, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

-- Net handlers
net.Receive("server:lzy_shop.cosmetiques_data", function()
	local function findPanel(root)
		if not IsValid(root) then return nil end
		if root.GetName and root:GetName() == "LZY:Shop:Cosmetiques" then return root end
		if root.GetChildren then
			for _, child in ipairs(root:GetChildren()) do
				local found = findPanel(child)
				if found then return found end
			end
		end
		return nil
	end

	local panel = findPanel(vgui.GetWorldPanel())
	if not IsValid(panel) then return end

	local count = net.ReadUInt(8)
	local items = {}
	for i = 1, count do
		items[i] = {
			item_id  = net.ReadString(),
			price    = net.ReadUInt(32),
			mat      = net.ReadString(),
			sold     = net.ReadBool(),
			discount = net.ReadUInt(8),
		}
	end
	local secondsLeft     = net.ReadUInt(32)
	local refreshesLeft   = net.ReadUInt(8)
	panel._cosmResetAt       = CurTime() + secondsLeft
	panel._cosmRefreshesLeft = refreshesLeft
	panel:OnItemsReceived(items)
end)

net.Receive("server:lzy_shop.cosmetique_sold", function()
	local offerIndex = net.ReadUInt(8)
	local function findPanel(root)
		if not IsValid(root) then return nil end
		if root.GetName and root:GetName() == "LZY:Shop:Cosmetiques" then return root end
		if root.GetChildren then
			for _, child in ipairs(root:GetChildren()) do
				local found = findPanel(child)
				if found then return found end
			end
		end
		return nil
	end
	local panel = findPanel(vgui.GetWorldPanel())
	if not IsValid(panel) or not IsValid(panel._scroll) then return end
	local canvas = panel._scroll:GetCanvas()
	if canvas._cosmContainers and IsValid(canvas._cosmContainers[offerIndex]) then
		canvas._cosmContainers[offerIndex].SetSold()
	end
end)

-- Callback du popup YesNo : envoie la requete refresh au serveur si confirme
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.LzyShop_CosmRefresh_Confirm = function(args)
	net.Start("server:lzy_shop.cosmetiques_refresh")
	net.SendToServer()
end

vgui.Register("LZY:Shop:Cosmetiques", PANEL, "DPanel")
