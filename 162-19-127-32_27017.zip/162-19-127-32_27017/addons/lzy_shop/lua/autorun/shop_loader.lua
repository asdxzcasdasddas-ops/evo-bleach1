-- "addons\\lzy_shop\\lua\\autorun\\shop_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("shop/shop_config.lua")
	AddCSLuaFile("shop/coffres_config.lua")
	AddCSLuaFile("shop/scratch_config.lua")
	AddCSLuaFile("shop/client/scratch.lua")
	AddCSLuaFile("shop/client/main.lua")
	AddCSLuaFile("shop/client/coffres.lua")
	AddCSLuaFile("shop/client/coins.lua")
	AddCSLuaFile("shop/client/grades.lua")
	AddCSLuaFile("shop/client/cut_line.lua")
	AddCSLuaFile("shop/client/gift.lua")
	AddCSLuaFile("shop/client/night_market.lua")
	AddCSLuaFile("shop/client/pack_opening.lua")
	AddCSLuaFile("shop/client/cosmetic_preview.lua")
	AddCSLuaFile("shop/client/cosmetiques.lua")
	AddCSLuaFile("shop/client/reroll.lua")

	include("shop/shop_config.lua")
	include("shop/coffres_config.lua")
	include("shop/scratch_config.lua")
	include("shop/server/sv_premium.lua")
	include("shop/server/sv_purchase_log.lua") -- avant sv_main : il y appelle LZY_ShopLog
	include("shop/server/sv_main.lua")
	include("shop/server/sv_net.lua")
	-- APRÈS sv_main : sv_coffres appelle LZY_Shop_DebitCoins / LZY_Shop_FetchAuth /
	-- LZY_Shop_RecordUnlock, tous définis là-bas.
	include("shop/server/sv_coffres.lua")
	include("shop/server/sv_scratch.lua") -- ticket à gratter : mêmes helpers que les coffres
end

if CLIENT then
	include("shop/shop_config.lua")
	include("shop/coffres_config.lua")
	include("shop/scratch_config.lua")

	include("shop/client/main.lua")
	include("shop/client/coffres.lua")
	include("shop/client/coins.lua")
	include("shop/client/grades.lua")
	include("shop/client/cut_line.lua")
	include("shop/client/gift.lua")
	include("shop/client/night_market.lua")
	include("shop/client/pack_opening.lua")
	include("shop/client/cosmetic_preview.lua")
	include("shop/client/cosmetiques.lua")
	include("shop/client/reroll.lua")
	include("shop/client/scratch.lua")
end
