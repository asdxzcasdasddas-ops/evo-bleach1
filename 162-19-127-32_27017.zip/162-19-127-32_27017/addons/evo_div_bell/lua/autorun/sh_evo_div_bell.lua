-- "addons\\evo_div_bell\\lua\\autorun\\sh_evo_div_bell.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO DIV BELL — sonnette devant la porte de chaque division / ordre.
-- Un joueur sur le point (ou qui le regarde) appuie sur E : les membres de
-- CETTE subdivision, en ligne, reçoivent une popup + un son de sonnette.
--
-- Placement : !config_positions → Divisions → Sonnettes. Les deux listes
-- (faction, puis division / ordre) choisissent QUOI poser ; Ajouter le met
-- à tes pieds. Le gizmo déplace ensuite le point. Une subdivision déjà posée
-- se déplace, elle ne se recrée pas.
-- ============================================================================

EVO_DivBell = EVO_DivBell or {}

EVO_DivBell.Spots = EVO_DivBell.Spots or {}

-- Rayon où E sonne. StandRadius : le point ajouté est aux PIEDS ; debout dessus,
-- regarder la porte (horizontal) ne vise pas le sol, donc le test de regard
-- échouerait. En dessous de ce rayon, E sonne sans avoir à viser le point.
EVO_DivBell.UseRadius   = 120
EVO_DivBell.StandRadius = 72
EVO_DivBell.UseFacing   = 0.45
EVO_DivBell.Cooldown    = 20
EVO_DivBell.Sound       = "buttons/bell1.wav"

local FACTION_ORDER = { "Shinigami", "Hollow" }

function EVO_DivBell.ParseId(id)
	if not isstring(id) then return nil end
	local fac, n = string.match(id, "^([^:]+):(%d+)$")
	n = tonumber(n)
	if not (fac and n and n > 1) then return nil end
	if not (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.IsValidDivision
		and LZY_FACTION_CONFIG.IsValidDivision(fac, n)) then
		return nil
	end
	local row = LZY_FACTION_CONFIG.divisions[fac]
	if not row or row[n] == "Aucune" then return nil end
	return fac, n
end

function EVO_DivBell.Put(map, id, pos)
	local fac, div = EVO_DivBell.ParseId(id)
	if not (fac and isvector(pos)) then return false end
	local name = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName(fac, div)) or ("Division " .. div)
	local spec = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionSpecialty
	spec = spec and spec[div]
	local editor = fac .. " · " .. name
	if isstring(spec) and spec ~= "" then editor = editor .. " · " .. spec end
	EVO_DivBell.Spots[map] = EVO_DivBell.Spots[map] or {}
	EVO_DivBell.Spots[map][id] = {
		id       = id,
		pos      = Vector(pos.x, pos.y, pos.z),
		faction  = fac,
		division = div,
		label    = string.upper(name),
		editor   = editor,
	}
	return true
end

-- Choix du menu (faction figée, divisions dans l'ordre des index, sans « Aucune »).
function EVO_DivBell.SlotChoices(faction)
	local out = {}
	local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions[faction]
	if not t then return out end
	local max = 0
	for k in pairs(t) do
		if isnumber(k) and k > max then max = k end
	end
	for i = 2, max do
		if t[i] and t[i] ~= "Aucune" then
			local name = LZY_FACTION_CONFIG.DivisionName(faction, i)
			local spec = LZY_FACTION_CONFIG.DivisionSpecialty and LZY_FACTION_CONFIG.DivisionSpecialty[i]
			local label = name
			if isstring(spec) and spec ~= "" then label = label .. " · " .. spec end
			out[#out + 1] = { id = faction .. ":" .. i, label = label }
		end
	end
	return out
end

-- Repli si le menu n'a rien envoyé. La faction de la map passe devant.
function EVO_DivBell.NextId(map)
	local spots = EVO_DivBell.Spots[map] or {}
	local mf = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.MAP_FACTION
	local pref = mf and mf[map]
	local order = {}
	if pref == "Hollow" or pref == "Shinigami" then order[1] = pref end
	for _, fac in ipairs(FACTION_ORDER) do
		if fac ~= pref then order[#order + 1] = fac end
	end
	for _, fac in ipairs(order) do
		local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions[fac]
		if t then
			local max = 0
			for k in pairs(t) do
				if isnumber(k) and k > max then max = k end
			end
			for i = 2, max do
				if t[i] and t[i] ~= "Aucune" then
					local id = fac .. ":" .. i
					if not spots[id] then return id end
				end
			end
		end
	end
end

local DOOR_CLASS = {
	prop_door_rotating = true,
	func_door = true,
	func_door_rotating = true,
}

-- Viser la porte garde le E de la porte. La sonnette est le sol / le mur à côté,
-- pas le battant : sinon chaque entrée sonnerait.
local function aimHitsDoor(ply)
	local tr = ply:GetEyeTrace()
	local ent = tr.Entity
	if not IsValid(ent) then return false end
	if ply:EyePos():DistToSqr(tr.HitPos) > (160 * 160) then return false end
	return DOOR_CLASS[ent:GetClass()] == true
end

-- La sonnette que ce joueur peut actionner, ou nil. Même règle des deux côtés :
-- le prompt ne s'affiche pas là où le serveur refuserait.
function EVO_DivBell.SpotAt(ply)
	if not IsValid(ply) then return nil end
	local spots = EVO_DivBell.Spots[game.GetMap()]
	if not spots then return nil end
	local origin = ply:GetPos()
	local r2 = EVO_DivBell.UseRadius * EVO_DivBell.UseRadius
	local stand2 = EVO_DivBell.StandRadius * EVO_DivBell.StandRadius
	local face = EVO_DivBell.UseFacing
	local eye, aim
	local best, bestD
	local sawDoor
	for _, s in pairs(spots) do
		local pos = s.pos
		if pos then
			local d = origin:DistToSqr(pos)
			if d <= r2 and (not bestD or d < bestD) then
				-- Trace seulement une fois qu'on est dans une bulle : pas à chaque frame
				-- de l'autre côté de la map.
				if sawDoor == nil then
					sawDoor = aimHitsDoor(ply)
					if not sawDoor then
						eye = ply:EyePos()
						aim = ply:GetAimVector()
					end
				end
				if sawDoor then return nil end
				local ok = d <= stand2
				if not ok then
					local dx, dy, dz = pos.x - eye.x, pos.y - eye.y, pos.z - eye.z
					local len = math.sqrt(dx * dx + dy * dy + dz * dz)
					if len > 1 then
						ok = (dx * aim.x + dy * aim.y + dz * aim.z) / len >= face
					end
				end
				if ok then best, bestD = s, d end
			end
		end
	end
	return best
end

function EVO_DivBell.RegisterProvider()
	if EVO_DivBell._prov then return true end
	if not (EVO_ConfigPos and EVO_ConfigPos.RegisterProvider) then return false end
	EVO_DivBell._prov = true

	local KIND = EVO_ConfigPos.KIND
	EVO_ConfigPos.RegisterProvider({
		id = "div_sonnette",
		cat = "divisions",
		label = "Sonnettes",
		List = function(map)
			local out = {}
			local spots = EVO_DivBell.Spots[map]
			if not spots then return out end
			local ids = {}
			for id in pairs(spots) do ids[#ids + 1] = id end
			local mf = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.MAP_FACTION
			local pref = mf and mf[map]
			table.sort(ids, function(a, b)
				local fa, da = string.match(a, "^([^:]+):(%d+)$")
				local fb, db = string.match(b, "^([^:]+):(%d+)$")
				da, db = tonumber(da) or 0, tonumber(db) or 0
				local function rank(fac)
					if fac == pref then return 0 end
					if fac == "Shinigami" then return 1 end
					return 2
				end
				local ra, rb = rank(fa), rank(fb)
				if ra ~= rb then return ra < rb end
				return da < db
			end)
			for _, id in ipairs(ids) do
				local s = spots[id]
				if s and isvector(s.pos) then
					out[#out + 1] = {
						id = id,
						label = s.editor or id,
						kind = KIND.POINT,
						pos = s.pos,
					}
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			if not (data and isvector(data.pos)) then return end
			EVO_DivBell.Put(map, id, data.pos)
		end,
		RestoreExtra = function(map, id, data)
			if not (data and isvector(data.pos)) then return end
			EVO_DivBell.Put(map, id, data.pos)
		end,
		Add = function(map, origin)
			if not (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions) then return nil, "factions" end
			if not (origin and isvector(origin.pos)) then return nil, "pos" end
			local requested = isstring(origin.model) and origin.model or ""
			local id
			if requested ~= "" then
				if not EVO_DivBell.ParseId(requested) then return nil, "division inconnue" end
				id = requested
			else
				id = EVO_DivBell.NextId(map)
			end
			if not id then return nil, "choisis une division" end
			local spots = EVO_DivBell.Spots[map]
			if spots and spots[id] then return nil, "deja placee" end
			EVO_DivBell.Put(map, id, origin.pos)
			return id
		end,
		Remove = function(map, id)
			local spots = EVO_DivBell.Spots[map]
			if not (spots and spots[id]) then return false end
			spots[id] = nil
			return true
		end,
		Refresh = function()
			if CLIENT then return end
			if EVO_DivBell.SyncSoon then EVO_DivBell.SyncSoon() end
		end,
	})
	return true
end

if not EVO_DivBell.RegisterProvider() then
	hook.Add("Initialize", "EVO_DivBell::Prov", EVO_DivBell.RegisterProvider)
end
