-- "addons\\evo_div_bell\\lua\\autorun\\client\\cl_evo_div_bell.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO DIV BELL — client. Prompt quand on peut sonner, popup + sonnette quand
-- un membre de notre subdivision a quelqu'un à la porte. Les positions viennent
-- du serveur (les extras de config_positions ne sont pas la liste joueur).
-- ============================================================================
if not CLIENT then return end

local function sy(v)
	return math.Round(v * (ScrH() / 1080))
end

net.Receive("EVO_DivBell:Sync", function()
	local n = net.ReadUInt(5)
	local map = game.GetMap()
	EVO_DivBell.Spots[map] = {}
	for _ = 1, n do
		local id = net.ReadString()
		local pos = net.ReadVector()
		EVO_DivBell.Put(map, id, pos)
	end
end)

net.Receive("EVO_DivBell:Notify", function()
	local title = net.ReadString()
	local msg = net.ReadString()
	surface.PlaySound(EVO_DivBell.Sound or "buttons/bell1.wav")
	local lp = LocalPlayer()
	if IsValid(lp) and lp.OpenPopup then
		lp:OpenPopup(msg, nil, title)
	end
end)

hook.Add("InitPostEntity", "EVO_DivBell::Ask", function()
	net.Start("EVO_DivBell:RequestSync")
	net.SendToServer()
end)

hook.Add("HUDPaint", "EVO_DivBell::Prompt", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	if vgui.CursorVisible() then return end
	local spot = EVO_DivBell.SpotAt(lp)
	if not spot then return end
	local name = spot.label or "SONNETTE"
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(ScrW() * 0.5, ScrH() * 0.5 + sy(66), name, "Sonner", "E")
		return
	end
	draw.SimpleText("[E] Sonner — " .. name, "DermaDefaultBold", ScrW() * 0.5, ScrH() * 0.5 + sy(66), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
