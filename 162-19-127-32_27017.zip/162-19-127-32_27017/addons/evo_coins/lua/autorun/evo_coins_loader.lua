-- "addons\\evo_coins\\lua\\autorun\\evo_coins_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- evo_coins_loader.lua — Loader evo_coins
-- Pont EVO BleachRP <-> site web : credit des coins achetes, livraison des
-- recompenses de ticket, application des sanctions du panel. Config (secret)
-- dans lua/evo_coins/config.lua (copier config.example.lua).
-- ============================================================================

local root = "evo_coins/"

if SERVER then
	AddCSLuaFile(root .. "cl_popup.lua")
	AddCSLuaFile(root .. "cl_playtime_reward.lua")

	-- TOUT PREMIER : interrupteur du pont site + de l'eco partagee (EVO_WEB).
	-- Defaut FERME pour le pont -> un clone du depot est muet par construction.
	include(root .. "sh_web_gate.lua")
	include(root .. "sv_shared.lua") -- config + utilitaires communs (EVO_COINS)
	-- Gate beta : lit MySQL directement, PAS le pont HTTP -> volontairement AVANT les
	-- pollers et indépendant du secret (il doit marcher même sans config.lua).
	include(root .. "sv_beta_gate.lua")
	-- Livre de comptes des achats site + moteur de livraison : AVANT les pollers
	-- (ils appellent EVO_STRIPE.Ingest) et lui aussi independant du secret (un
	-- serveur sans config.lua doit pouvoir LIVRER ce que les autres ont ingere).
	include(root .. "sh_config_stripe.lua") -- items des paliers, grades, colonnes reroll
	include(root .. "sv_stripe.lua")
	include(root .. "sv_coins.lua")
	include(root .. "sv_modactions.lua")
	include(root .. "sv_rewards.lua")
	include(root .. "sv_grants.lua") -- packs beta (cosmetiques + acces), APRES sv_beta_gate
	include(root .. "sv_grades.lua") -- grades premium/vip/platinium achetes sur le site
	include(root .. "sv_technique_retraits.lua") -- techniques retirees depuis le Grimoire du panel
	include(root .. "sv_coins_log.lua") -- journal unifie des coins (gains + depenses), AVANT le push
	include(root .. "sv_players_push.lua")
	-- APRES tout le reste : rattrapage d'affichage cross-serveur (la livraison ne
	-- rafraichit l'ecran que sur le serveur qui livre, cf. l'en-tete du fichier).
	include(root .. "sv_resync.lua")
	-- Recompense de temps de jeu (3 h actives = 300 coins, 1 fois par jour, partagee).
	-- Coupee par defaut ; fenetre SAM activer_temps_jeu (le jour se termine a 02:00).
	include(root .. "sv_playtime_reward.lua")
else
	include(root .. "cl_popup.lua")
	include(root .. "cl_playtime_reward.lua")
end
