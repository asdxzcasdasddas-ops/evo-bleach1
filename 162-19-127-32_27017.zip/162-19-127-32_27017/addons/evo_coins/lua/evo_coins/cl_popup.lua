-- "addons\\evo_coins\\lua\\evo_coins\\cl_popup.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BleachRP — popup "coins recus" (client), version SOBRE.
-- Carte compacte centree : coin a gauche, texte a droite. Metal sombre, accent
-- discret, fondu + leger slide, auto-disparition. Pas de pulsation ni flottement.
-- Declenche par le net "EVO:CoinsReceived".
-- ============================================================================

if not CLIENT then return end

-- Palette DA Atelier (07/07) : plaque métal noir + doré standard pour le montant.
local COL_BG       = Color(13, 14, 17, 250)
local COL_EDGE     = Color(146, 152, 161, 33)
local COL_LINE     = Color(255, 255, 255, 28)
local COL_ACCENT   = Color(232, 179, 75)    -- doré DA (montants d'argent)
local COL_WHITE    = Color(238, 238, 240)
local COL_MUTED    = Color(150, 154, 162)

local COIN_MAT = Material("a4xy732ex6yeop2/m3vznbexvus1qa1.png", "smooth")
local GLOW_MAT = Material("sprites/light_glow02_add")
local SND_OK   = "6515xw26amw1br/thui5lpdeagxqwqak.ogg"

local function RoundBox(r, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(r, x, y, w, h, col) else draw.RoundedBox(r, x, y, w, h, col) end
end

local function S() return math.max(0.6, ScrH() / 1080) end

local function MakeFonts()
	local s = S()
	surface.CreateFont("EvoCoins_Amount", { font = "Bebas Neue", size = math.floor(36 * s), weight = 400, antialias = true })
	surface.CreateFont("EvoCoins_Sub",    { font = "Roboto",     size = math.floor(15 * s), weight = 500, antialias = true })
	surface.CreateFont("EvoCoins_Tag",    { font = "Roboto",     size = math.floor(12 * s), weight = 600, antialias = true })
end
MakeFonts()
hook.Add("OnScreenSizeChanged", "EvoCoins:Fonts", MakeFonts)

local function Comma(n)
	local str = tostring(math.floor(tonumber(n) or 0))
	local k
	repeat str, k = string.gsub(str, "^(-?%d+)(%d%d%d)", "%1 %2") until k == 0
	return str
end

local function EaseOutCubic(x) x = math.Clamp(x, 0, 1) return 1 - (1 - x) ^ 3 end

local EvoCoinsPanel
local LIFE = 4.5
local FADE_IN  = 0.35
local FADE_OUT = 0.5

local function PopupCopy(kind)
	if kind == 1 then
		return "RÉCOMPENSE", "Merci de jouer sur notre serveur !"
	end
	return "ACHAT VALIDÉ", "Merci d'avoir acheté dans notre boutique !"
end

local function ShowCoinPopup(amount, kind)
	amount = math.floor(tonumber(amount) or 0)
	if amount <= 0 then return end
	kind = tonumber(kind) or 0
	local tag, sub = PopupCopy(kind)

	if IsValid(EvoCoinsPanel) then
		EvoCoinsPanel.amount = (EvoCoinsPanel.amount or 0) + amount
		EvoCoinsPanel.kind = kind
		EvoCoinsPanel.tag = tag
		EvoCoinsPanel.sub = sub
		EvoCoinsPanel.t0 = SysTime()
		surface.PlaySound(SND_OK)
		return
	end

	local s = S()
	local W, H = math.floor(440 * s), math.floor(108 * s)

	local p = vgui.Create("DPanel")
	EvoCoinsPanel = p
	p.amount = amount
	p.kind = kind
	p.tag = tag
	p.sub = sub
	p.t0 = SysTime()
	p.alpha = 0
	p:SetSize(W, H)
	p:SetMouseInputEnabled(false)
	p:SetPaintBackground(false)
	p:SetDrawOnTop(true)
	surface.PlaySound(SND_OK)

	p.Think = function(self)
		local t = SysTime() - self.t0
		local intro = EaseOutCubic(t / FADE_IN)
		local outro = 1 - math.Clamp((t - (LIFE - FADE_OUT)) / FADE_OUT, 0, 1)
		self.alpha = 255 * math.min(intro, outro)

		local sc = S()
		local rise = (1 - intro) * 14 * sc
		self:SetPos(math.floor((ScrW() - self:GetWide()) / 2),
			math.floor((ScrH() - self:GetTall()) / 2 + rise))

		if t >= LIFE then self:Remove() EvoCoinsPanel = nil end
	end

	p.Paint = function(self, w, h)
		local a = (self.alpha or 0) / 255
		if a < 0.02 then return end
		local s2 = S()

		-- Plaque de métal noir Atelier : coins coupés + liseré acier (DA 07/07,
		-- remplace la double carte arrondie + ombre + bordure blanche).
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL_BG, 250 * a), 12 * s2)
			EVO_UI.OutlineCut(pts, ColorAlpha(COL_EDGE, 33 * a))
		else
			RoundBox(0, 0, 0, w, h, ColorAlpha(COL_BG, 252 * a))
		end

		-- Coin a gauche (halo DORÉ très discret — plus de bleu, pas de pulse/bob)
		local coinSz = 56 * s2
		local cx = 18 * s2 + coinSz / 2
		local cy = h / 2
		surface.SetMaterial(GLOW_MAT)
		surface.SetDrawColor(232, 179, 75, 22 * a)
		local g = coinSz * 1.7
		surface.DrawTexturedRect(cx - g / 2, cy - g / 2, g, g)
		surface.SetMaterial(COIN_MAT)
		surface.SetDrawColor(255, 255, 255, 255 * a)
		surface.DrawTexturedRect(cx - coinSz / 2, cy - coinSz / 2, coinSz, coinSz)

		-- Separateur vertical fin
		local sepX = 18 * s2 + coinSz + 16 * s2
		surface.SetDrawColor(ColorAlpha(COL_LINE, 255 * a))
		surface.DrawRect(sepX, h * 0.24, 1, h * 0.52)

		-- Bloc texte a droite, aligne a gauche
		local tx = sepX + 16 * s2
		draw.SimpleText(self.tag or "ACHAT VALIDÉ", "EvoCoins_Tag", tx, h * 0.27,
			ColorAlpha(COL_MUTED, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("+ " .. Comma(self.amount) .. " coins", "EvoCoins_Amount", tx, h * 0.50,
			ColorAlpha(COL_ACCENT, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(self.sub or "Merci d'avoir acheté dans notre boutique !", "EvoCoins_Sub", tx, h * 0.74,
			ColorAlpha(COL_MUTED, 235 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

net.Receive("EVO:CoinsReceived", function()
	local amount = net.ReadUInt(32)
	local kind = 0
	if net.BytesLeft() >= 1 then
		kind = net.ReadUInt(8)
	end
	ShowCoinPopup(amount, kind)
end)

-- Test local : `lua_run_cl EvoCoinsTest(1100)`
function EvoCoinsTest(n) ShowCoinPopup(tonumber(n) or 1234) end
