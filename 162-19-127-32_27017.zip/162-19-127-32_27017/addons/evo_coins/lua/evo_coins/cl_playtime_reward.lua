-- "addons\\evo_coins\\lua\\evo_coins\\cl_playtime_reward.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- HUD progression récompense de présence : haut-droite, juste sous le bloc logo
-- (logo + discord.gg, mêmes constantes que lzy_hud/cl_logo.lua).
-- Largeur ≈ logo (0.13 × ScrH). Compact : menu C → bouton « − » (cookie local).

if not CLIENT then return end

local COIN_MAT = Material("fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "noclamp smooth")
local COL_BG     = Color(13, 14, 17, 220)
local COL_EDGE   = Color(146, 152, 161, 40)
local COL_TEXT   = Color(238, 238, 240, 255)
local COL_BAR_BG = Color(255, 255, 255, 22)
local COL_BAR    = Color(232, 179, 75, 255)
local COL_OUT    = Color(0, 0, 0, 200)
local COL_CAPT   = Color(220, 224, 230, 220)
local COL_HOVER  = Color(255, 255, 255, 28)

local COOKIE = "EVO_PTR_HudCompact"
local compact = cookie.GetString(COOKIE, "0") == "1"

local st = { sec = 0, req = 1, rew = 300, claimed = true, at = 0, ready = false }
local fontTitle = "EvoPTR_Hud"
local fontBar   = "EvoPTR_HudBar"
local barCacheKey, barCacheStr = -1, ""
local lastLayout

local function Mul()
	return compact and 0.78 or 1
end

-- Scalaires relatifs à la largeur logo (0.13 × ScrH), pas au 1920×1080.
local function S(v)
	local logoW = ScrH() * 0.13
	return math.max(1, math.Round(v * (logoW / 140) * Mul()))
end

local function MakeFont()
	surface.CreateFont(fontTitle, {
		font = "Avenir Next World",
		size = math.max(14, S(18)),
		weight = 800,
		antialias = true,
		extended = true,
	})
	surface.CreateFont(fontBar, {
		font = "Avenir Next World",
		size = math.max(11, S(13)),
		weight = 700,
		antialias = true,
		extended = true,
	})
end
MakeFont()
hook.Add("OnScreenSizeChanged", "EVO_PTR::Fonts", MakeFont)

local function SetCompact(b)
	b = b and true or false
	if compact == b then return end
	compact = b
	cookie.Set(COOKIE, compact and "1" or "0")
	MakeFont()
end

local function CtxOpen()
	return MUGEN and MUGEN.IsContextMenuOpen and MUGEN.IsContextMenuOpen()
end

net.Receive("EVO:PlaytimeReward", function()
	st.sec = net.ReadUInt(16)
	st.req = math.max(1, net.ReadUInt(16))
	st.rew = net.ReadUInt(16)
	st.claimed = net.ReadBool()
	st.at = CurTime()
	st.ready = not st.claimed
	barCacheKey = -1
end)

local function FmtHours(nSec)
	nSec = math.max(0, math.floor(nSec))
	local h = math.floor(nSec / 3600)
	local m = math.floor((nSec % 3600) / 60)
	return string.format("%dh%02d", h, m)
end

local function Layout()
	-- Aligné sur cl_logo.lua : pad 0.014, logoSize 0.13, gap -0.01, topY 0.012.
	local logoPad  = math.Round(ScrH() * 0.014)
	local logoSize = math.Round(ScrH() * 0.13)
	local logoGap  = math.Round(ScrH() * -0.01)
	local logoTop  = math.Round(ScrH() * 0.012)
	local discH    = math.max(11, math.Round(ScrH() * 0.013))
	local logoBot  = logoTop + logoSize + logoGap + discH

	local pad = S(6)
	local icon = S(20)
	local barH = S(20)
	local titleH = math.max(icon, S(20))
	local btnS = math.max(14, S(16))
	-- Même largeur que le logo, centrée sur le même axe.
	local w = math.max(S(100), math.Round(logoSize * Mul()))
	local h = pad + titleH + S(5) + barH + pad
	local cx = ScrW() - logoPad - logoSize / 2
	local x = math.Round(cx - w / 2)
	local y = logoBot + S(12)
	local innerW = w - pad * 2

	return {
		x = x, y = y, w = w, h = h,
		pad = pad, icon = icon, barH = barH, innerW = innerW, titleH = titleH,
		btnS = btnS,
		btnX = x + w - pad - btnS,
		btnY = y + pad,
	}
end

local function InCaption(lay, mx, my)
	return mx >= lay.btnX and my >= lay.btnY
		and mx <= lay.btnX + lay.btnS and my <= lay.btnY + lay.btnS
end

hook.Add("GUIMousePressed", "EVO_PTR::Caption", function(code)
	if code ~= MOUSE_LEFT then return end
	if not CtxOpen() then return end
	local lay = lastLayout
	if not lay or not st.ready or st.claimed then return end
	if InCaption(lay, gui.MouseX(), gui.MouseY()) then
		SetCompact(not compact)
	end
end)

local function DrawCaption(lay)
	local bx, by, bs = lay.btnX, lay.btnY, lay.btnS
	if InCaption(lay, gui.MouseX(), gui.MouseY()) then
		if RNDX and RNDX.Draw then
			RNDX.Draw(3, bx, by, bs, bs, COL_HOVER)
		else
			draw.RoundedBox(3, bx, by, bs, bs, COL_HOVER)
		end
	end
	surface.SetDrawColor(COL_CAPT)
	local cx, cy = bx + bs * 0.5, by + bs * 0.5
	local arm = math.max(3, math.floor(bs * 0.28))
	if compact then
		surface.DrawRect(cx - arm, cy - 1, arm * 2, 2)
		surface.DrawRect(cx - 1, cy - arm, 2, arm * 2)
	else
		surface.DrawRect(cx - arm, cy - 1, arm * 2, 2)
	end
end

hook.Add("HUDPaint", "EVO_PTR::HUD", function()
	lastLayout = nil
	if not st.ready or st.claimed then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	if lp:GetEvoNWBool("EVO_StaffMode", false) then return end

	local nShown = math.min(st.req, st.sec)
	local frac = math.Clamp(nShown / st.req, 0, 1)
	local key = nShown * 65536 + st.req
	if barCacheKey ~= key then
		barCacheKey = key
		barCacheStr = FmtHours(nShown) .. " / " .. FmtHours(st.req)
	end

	local lay = Layout()
	lastLayout = lay
	local x, y, w, h = lay.x, lay.y, lay.w, lay.h
	local pad, icon, barH, innerW, titleH = lay.pad, lay.icon, lay.barH, lay.innerW, lay.titleH

	if RNDX and RNDX.Draw then
		RNDX.Draw(S(5), x, y, w, h, COL_BG)
	else
		draw.RoundedBox(5, x, y, w, h, COL_BG)
	end
	surface.SetDrawColor(COL_EDGE)
	surface.DrawOutlinedRect(x, y, w, h, 1)

	-- Titre court : icône coin + montant (tient dans la largeur logo).
	local amount = tostring(st.rew)
	surface.SetFont(fontTitle)
	local tw = surface.GetTextSize(amount)
	local gap = S(3)
	local rowW = icon + gap + tw
	local textY = y + pad
	local rowX = x + (w - rowW) * 0.5

	surface.SetDrawColor(255, 255, 255, 255)
	surface.SetMaterial(COIN_MAT)
	surface.DrawTexturedRect(rowX, textY + (titleH - icon) * 0.5, icon, icon)
	draw.SimpleTextOutlined(amount, fontTitle, rowX + icon + gap, textY + titleH * 0.5, COL_TEXT,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, COL_OUT)

	local barX = x + pad
	local barY = textY + titleH + S(5)
	local barW = innerW
	if RNDX and RNDX.Draw then
		RNDX.Draw(barH * 0.5, barX, barY, barW, barH, COL_BAR_BG)
		if frac > 0 then
			RNDX.Draw(barH * 0.5, barX, barY, math.max(barH, barW * frac), barH, COL_BAR)
		end
	else
		draw.RoundedBox(barH * 0.5, barX, barY, barW, barH, COL_BAR_BG)
		if frac > 0 then
			draw.RoundedBox(barH * 0.5, barX, barY, math.max(barH, barW * frac), barH, COL_BAR)
		end
	end
	draw.SimpleTextOutlined(barCacheStr, fontBar, barX + barW * 0.5, barY + barH * 0.5, COL_TEXT,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, COL_OUT)

	if CtxOpen() then
		DrawCaption(lay)
	end
end)
