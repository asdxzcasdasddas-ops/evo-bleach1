-- "addons\\hit_damage\\lua\\hit_damage\\cl_hit.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local math_rad = math.rad
local math_random = math.random
local math_pow = math.pow
local math_sin = math.sin
local math_ceil = math.ceil
local math_Round = math.Round
local table_insert = table.insert
local table_remove = table.remove
local CurTime = CurTime
local Lerp = Lerp
local ScrW = ScrW
local ScrH = ScrH
local Vector = Vector
local Matrix = Matrix
local tostring = tostring
local tonumber = tonumber
local IsValid = IsValid

-- Config
HitDamage.Config = {
    Font = "Impact",
    Size = 80,
    Weight = 400,
    FadeTime = 1.0,
    Color = Color(255, 255, 255),
    CritColor = Color(255, 40, 40),
    SpellColor = Color(80, 170, 255), -- dégâts de sort (bleu) ; piloté par le bool is_spell (serveur)
    HealColor = Color(60, 220, 90), -- SOIN (vert) ; piloté par le bool is_heal (serveur) — même fonte/anim que les dégâts
    OutlineColor = Color(0, 0, 0),
    OutlineThickness = 2,
    -- Distance max (unites) au-dela de laquelle on n'affiche pas le texte (degats/Esquive).
    -- Evite de voir les messages de combat depuis l'autre bout de la carte.
    MaxRenderDist = 1500
}

local font_created = false
local function EnsureFont()
    if font_created then return end
    if not gCreateRespFont then return end
    gCreateRespFont("HitDamage.Font", HitDamage.Config.Font, HitDamage.Config.Size, HitDamage.Config.Weight, true, false, false, true)
    font_created = true
end

hook.Add("InitPostEntity", "HitDamage::CreateFont", EnsureFont)

local damage_numbers = {}

function HitDamage:Add(ent, pos, value, color, isText, isCrit, isSpell, isHeal)
    local angle = math_rad(math_random(-30, 30))

    local data = {
        ent = ent,
        value = value,
        isText = isText or false,
        isCrit = isCrit or false,
        isSpell = isSpell or false,
        isHeal = isHeal or false,
        time = CurTime(),
        pos = pos,
        angle = angle,
        randomX = gRespX(math_random(-30, 30))
    }

    -- perf : texte precompute UNE fois a la creation (evite tostring/math_ceil/tonumber a chaque frame de rendu)
    data.text = data.isText and data.value or tostring(math_ceil(tonumber(data.value)))

    table_insert(damage_numbers, 1, data)
end

net.Receive("HitDamage::Send", function()
    local ent = net.ReadEntity()
    local is_text = net.ReadBool()
    local value = net.ReadString()
    local origin_pos = net.ReadVector()
    local is_crit = net.ReadBool()
    local is_spell = net.ReadBool()
    local is_heal = net.ReadBool()

    if IsValid(ent) then
        HitDamage:Add(ent, origin_pos, value, nil, is_text, is_crit, is_spell, is_heal)
    end
end)

-- perf : objets scratch reutilises chaque frame (evite 2 Color, 1 Matrix et 3 Vector alloues par nombre affiche)
local scratch_text_color = Color(255, 255, 255, 255)
local scratch_outline_color = Color(0, 0, 0, 255)
local scratch_matrix = Matrix()
local scratch_vec = Vector(0, 0, 0)

local function DrawDamageNumber(data, screen_x, screen_y)
    local time_since = CurTime() - data.time
    local progress = time_since / HitDamage.Config.FadeTime

    local anim_scale = 1
    if time_since < 0.1 then
        anim_scale = Lerp(time_since / 0.1, 0.5, 1.5)
    elseif time_since < 0.25 then
        anim_scale = Lerp((time_since - 0.1) / 0.15, 1.5, 1.0)
    end

    local move_y = gRespY(-150) * math_pow(time_since, 0.8)
    local move_x = data.randomX + (math_sin(CurTime() * 5) * gRespX(15) * time_since)

    local x = screen_x + move_x
    local y = screen_y + move_y

    local alpha = 255
    if progress > 0.5 then
        alpha = Lerp((progress - 0.5) / 0.5, 255, 0)
    end

    local cfg = HitDamage.Config
    local base_color = data.isHeal and cfg.HealColor or (data.isCrit and cfg.CritColor or (data.isSpell and cfg.SpellColor or cfg.Color))
    -- perf : Colors scratch mutees par frame (l'alpha varie) au lieu de 2 Color() alloues par frame
    local text_color = scratch_text_color
    text_color.r, text_color.g, text_color.b, text_color.a = base_color.r, base_color.g, base_color.b, alpha
    local outline_color = scratch_outline_color
    outline_color.r, outline_color.g, outline_color.b, outline_color.a = cfg.OutlineColor.r, cfg.OutlineColor.g, cfg.OutlineColor.b, alpha

    -- perf : Matrix/Vector scratch re-initialises par frame au lieu d'etre re-alloues
    local m = scratch_matrix
    m:Identity()
    scratch_vec.x, scratch_vec.y, scratch_vec.z = x, y, 0
    m:Translate(scratch_vec)
    scratch_vec.x, scratch_vec.y, scratch_vec.z = anim_scale, anim_scale, 1
    m:Scale(scratch_vec)
    scratch_vec.x, scratch_vec.y, scratch_vec.z = -x, -y, 0
    m:Translate(scratch_vec)

    cam.PushModelMatrix(m)
        draw.SimpleTextOutlined(
            data.text, -- perf : texte precompute a la creation (HitDamage:Add)
            "HitDamage.Font",
            x,
            y,
            text_color,
            TEXT_ALIGN_CENTER,
            TEXT_ALIGN_CENTER,
            gRespX(cfg.OutlineThickness),
            outline_color
        )
    cam.PopModelMatrix()
end

local function DrawHitNumbers(is_third_person)
    local screen_w, screen_h = ScrW(), ScrH()
    local base_x = screen_w * 0.55
    local base_y = screen_h * 0.45

    -- Distance max : on n'affiche pas les textes trop loin du joueur local.
    local lp = LocalPlayer()
    local vMyPos = IsValid(lp) and lp:GetPos() or nil
    local maxDistSq = HitDamage.Config.MaxRenderDist and (HitDamage.Config.MaxRenderDist * HitDamage.Config.MaxRenderDist) or nil

    for i = #damage_numbers, 1, -1 do
        local data = damage_numbers[i]
        if CurTime() - data.time > HitDamage.Config.FadeTime then
            table_remove(damage_numbers, i)
        elseif vMyPos and maxDistSq and data.pos:DistToSqr(vMyPos) > maxDistSq then
            -- trop loin : on ne dessine pas (le data sera purge au fade)
        else
            local draw_x, draw_y
            local screen_pos = data.pos:ToScreen()

            if screen_pos.visible then
                draw_x, draw_y = screen_pos.x, screen_pos.y
            elseif not is_third_person then
                draw_x, draw_y = base_x, base_y
            end

            if draw_x and draw_y then
                DrawDamageNumber(data, draw_x, draw_y)
            end
        end
    end
end

-- Détection 3ème personne safe (compatible MUGEN.Camera si présent, sinon fallback)
local function IsThirdPerson()
    if MUGEN and MUGEN.Camera and MUGEN.Camera.Mode then
        return MUGEN.Camera:Mode()
    end
    local ply = LocalPlayer()
    if IsValid(ply) then
        return ply:ShouldDrawLocalPlayer()
    end
    return false
end

hook.Add("HUDPaint", "HitDamage::HUDPaint", function()
    EnsureFont()
    if not font_created then return end
    if not IsThirdPerson() then
        DrawHitNumbers(false)
    end
end)

hook.Add("PostDrawHUD", "HitDamage::PostDrawHUD", function()
    if not font_created then return end
    if IsThirdPerson() then
        DrawHitNumbers(true)
    end
end)

-- Rétrocompatibilité MUGEN.HitNumbers
if MUGEN then
    MUGEN.HitNumbers = MUGEN.HitNumbers or {}
    MUGEN.HitNumbers.Config = HitDamage.Config
    MUGEN.HitNumbers.Add = function(self, ...) return HitDamage:Add(...) end
end
