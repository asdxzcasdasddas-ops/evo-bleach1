-- "addons\\hit_damage\\lua\\autorun\\sh_hit_damage_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
HitDamage = HitDamage or {}

if SERVER then
    AddCSLuaFile("hit_damage/cl_hit.lua")
    include("hit_damage/sv_hit.lua")
end

if CLIENT then
    include("hit_damage/cl_hit.lua")
end
