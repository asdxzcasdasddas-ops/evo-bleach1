-- "addons\\lzy_popup\\lua\\lzy_popup\\cl_callbacks.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.FactionSetRank = function(args)
	if not args or not args.steamid64 or not args.character_id or not args.rank then return end
	net.Start("server:lzy_faction.SetRank")
	net.WriteString(tostring(args.steamid64))
	net.WriteString(tostring(args.character_id))
	net.WriteUInt(args.rank, 32)
	net.SendToServer()
end
LZY_POPUP_CALLBACKS.FactionSetDivision = function(args)
	if not args or not args.steamid64 or not args.character_id or not args.division then return end
	net.Start("server:lzy_faction.SetDivision")
	net.WriteString(tostring(args.steamid64))
	net.WriteString(tostring(args.character_id))
	net.WriteUInt(args.division, 32)
	net.SendToServer()
end
-- Formation d'un aspirant (livre de faction, vue des formateurs whitelistés) :
-- confirmation « Oui » -> net. Cible = ENTITÉ (le serveur relit tout en base).
LZY_POPUP_CALLBACKS.FactionFormerAspirant = function(args)
	if not args or not IsValid(args.ent) then return end
	net.Start("server:lzy_faction.FormerAspirant")
	net.WriteEntity(args.ent)
	net.SendToServer()
end

-- Coche FORMATEUR de l'onglet gestion (grade >= PromoteMinRank) : whitelist/retrait.
LZY_POPUP_CALLBACKS.FactionSetFormateur = function(args)
	if not args or not args.steamid64 or not args.character_id then return end
	net.Start("server:lzy_faction.SetFormateur")
	net.WriteString(args.steamid64)
	net.WriteString(args.character_id)
	net.WriteBool(args.value == true)
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.FactionSetSanction = function(args)
	if not args or not args.sanction or not args.steamid64 then return end
	net.Start("server:lzy_faction.SetSanction")
	net.WriteString(args.sanction)
	net.WriteString(args.steamid64)
	net.WriteString(args.character_id)
	net.SendToServer()
end

-- Revert visuel d'un selectbox quand l'utilisateur clique "Non" sur la confirmation.
-- Set selectedIndex directement (pas via SelectOption) pour ne PAS refire OnValueChanged
-- qui re-ouvrirait un popup en boucle.
LZY_POPUP_CALLBACKS.FactionRevertSelectbox = function(args)
	if not args or not IsValid(args._selectbox) or not args._oldIndex then return end
	args._selectbox.selectedIndex = args._oldIndex
end

LZY_POPUP_CALLBACKS.FactionExcludePlayer = function()
	-- Exclusion via le livre de faction desactivee (demande user 2026-08-21).
end

LZY_POPUP_CALLBACKS.FactionClearReports = function()
	net.Start("server:lzy_faction.ClearReports")
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.RerollConfirm = function(args)
	if not args or not args.panel then return end
	-- Check if panel is still valid
	if not IsValid(args.panel) then return end
	-- Proceed with reroll
	args.panel:DoReroll()
end

LZY_POPUP_CALLBACKS.RerollPremiumReplace = function(args)
	net.Start("lzy_reroll_premium_decision")
	net.WriteBool(true)
	net.SendToServer()
	-- Reponse envoyee : le serveur relache sa confirmation, le bouton reroll aussi.
	-- Avant le `return` ci-dessous, sinon un args incomplet laisserait le bouton mort.
	if args and IsValid(args.panel) then args.panel._decisionLockUntil = nil end
	-- Reroll panel mirrors equipped slot from self.* ; premium replace deferred win_function so we sync local state here (same as ApplyPendingRollUpdate for normal rolls)
	if not args or not IsValid(args.panel) or not args.category or not args.new_win_id or args.new_win_id == "" then
		return
	end
	local p = args.panel
	if args.category == "art_spirituel" then
		p.art_spirituel = args.new_win_id
	elseif args.category == "style_de_combat" then
		p.style_combat = args.new_win_id
	elseif args.category == "style_execution" then
		p.style_execution = args.new_win_id
	elseif args.category == "reiatsu_color" then
		p.reiatsu_color = args.new_win_id
	elseif args.category == "catalyseur" then
		p.catalyseur = args.new_win_id
	end
end

LZY_POPUP_CALLBACKS.RerollPremiumKeep = function(args)
	net.Start("lzy_reroll_premium_decision")
	net.WriteBool(false)
	net.SendToServer()
	-- lzy_popup passe les MEMES args au OUI et au NON : on relache donc le verrou du
	-- bouton reroll ici aussi, sinon garder son objet laissait le menu bloque.
	if args and IsValid(args.panel) then args.panel._decisionLockUntil = nil end
end

LZY_POPUP_CALLBACKS.BuyBattlePassPremium = function(args)
	net.Start("server:lzy_battlepass.BuyPremium")
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.GiftBattlePassPremium = function(args)
	if not args or not args.steamid64 then return end
	net.Start("server:lzy_battlepass.GiftPremium")
	net.WriteString(args.steamid64)
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.OpenTrade = function(args)
	if not args or not args.askingPlayerSteamid64 then return end
	net.Start("server:lzy_trade.OpenTrade")
	net.WriteString(args.askingPlayerSteamid64)
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.DeclineTradeOffer = function(args)
	if not args or not args.askingPlayerSteamid64 then return end
	net.Start("server:lzy_trade.DeclineTradeOffer")
	net.WriteString(args.askingPlayerSteamid64)
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.ResetSkills = function(args)
	net.Start("LZY:SkillTree:ResetSkills")
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.BuyStatReset = function(args)
	net.Start("LZY:SkillTree:BuyStatReset")
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.AcceptCarry = function(args)
	net.Start("Carry_Citron_AcceptCarry")
	net.SendToServer()
end

LZY_POPUP_CALLBACKS.BuyAllCategory = function(args)
	-- currentCategory is a local in skilltree.lua, so we use the NW-accessible approach
	-- The server will receive the category and process it
	net.Start("LZY:SkillTree:BuyAllCategory")
	net.WriteString(LZY_SKILLTREE_CURRENT_CATEGORY or "General")
	net.SendToServer()
end
-- Suppression d'une fiche de suivi (registre GESTION FORMATION) : confirmation
-- « Oui » -> net. Le serveur revalide grade + division avant de supprimer.
LZY_POPUP_CALLBACKS.FactionSuiviDelete = function(args)
	if not args or not args.id then return end
	net.Start("server:lzy_faction.SuiviDelete")
	net.WriteUInt(args.id, 32)
	net.SendToServer()
end

-- Jeton d'art spirituel (CK) : remplacer l'art actuel.
LZY_POPUP_CALLBACKS.ArtToken_Replace = function()
	net.Start("EVO:ArtToken:Answer")
	net.WriteBool(true)
	net.SendToServer()
end
LZY_POPUP_CALLBACKS.ArtToken_Cancel = function()
	net.Start("EVO:ArtToken:Answer")
	net.WriteBool(false)
	net.SendToServer()
end
