-- "addons\\lzy_popup\\lua\\lzy_popup\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ══════════════════════════════════════════════════════════
-- PALETTE — dark metallic (même style que property menu)
-- ══════════════════════════════════════════════════════════
-- Nouvelle DA EVO : carte sombre, AUCUNE bordure grise/blanche, accent rouge #cf444e.
local COL_BG          = Color(14, 14, 17, 250)
local COL_BORDER_HI   = Color(207, 68, 78, 150)   -- emphase rouge au survol
local COL_LINE        = Color(255, 255, 255, 14)  -- séparateur très discret
local COL_WHITE       = Color(237, 238, 242, 255)
local COL_GREY_LIGHT  = Color(150, 154, 162, 255)
local COL_BTN_NORMAL  = Color(24, 24, 29, 235)
local COL_BTN_HOVER   = Color(34, 34, 41, 245)
local COL_ACCENT      = Color(207, 68, 78, 255)   -- #cf444e (notif / confirmation)
local COL_ERROR       = Color(214, 84, 94, 255)
local COL_SUCCESS     = Color(70, 190, 120, 255)
local COL_BORDER_GREEN = Color(70, 190, 120, 160)  -- emphase verte au survol (bouton OUI / confirmation)

-- ══════════════════════════════════════════════════════════
-- FONTS (deferred — glibs may load after this file)
-- ══════════════════════════════════════════════════════════
local function InitFonts()
    -- DA Atelier : Bebas Neue SANS bold (titre/boutons), Roboto pour le message.
    if gCreateRespFont then
        gCreateRespFont("LzyPopup_Title", "Bebas Neue", 26, 400)
        gCreateRespFont("LzyPopup_Msg",   "Roboto",     15, 500)
        gCreateRespFont("LzyPopup_Btn",   "Bebas Neue", 19, 400)
    else
        surface.CreateFont("LzyPopup_Title", { font = "Bebas Neue", size = 26, weight = 400, antialias = true })
        surface.CreateFont("LzyPopup_Msg",   { font = "Roboto",     size = 15, weight = 500, antialias = true })
        surface.CreateFont("LzyPopup_Btn",   { font = "Bebas Neue", size = 19, weight = 400, antialias = true })
    end
end
hook.Add("Initialize",          "LzyPopup::InitFonts", InitFonts)
hook.Add("OnScreenSizeChanged", "LzyPopup::InitFonts", InitFonts)

-- ══════════════════════════════════════════════════════════
-- SIZES (base 1080p)
-- ══════════════════════════════════════════════════════════
local PAD   = 14
local BTN_H = 30
local BTN_GAP = 8
local POP_W = 340
local POP_H_BASE = 120 -- will grow with text

local PANEL = {}
local frame = nil
local popupQueue = {}

-- Exposed so fullscreen UIs (e.g. reroll) can keep this panel above them after clicks.
LZY_POPUP_ACTIVE = LZY_POPUP_ACTIVE or nil

-- ══════════════════════════════════════════════════════════
-- Helpers
-- ══════════════════════════════════════════════════════════
local function WrapText(sText, sFont, nMaxW)
	surface.SetFont(sFont)
	local lines = {}
	for _, raw in ipairs(string.Explode("\n", sText)) do
		local words = string.Explode(" ", raw)
		local cur = ""
		for _, word in ipairs(words) do
			local test = cur == "" and word or (cur .. " " .. word)
			if surface.GetTextSize(test) > nMaxW and cur ~= "" then
				table.insert(lines, cur)
				cur = word
			else
				cur = test
			end
		end
		if cur ~= "" then table.insert(lines, cur) end
	end
	if #lines == 0 then lines = { "" } end
	return lines
end

local function MakeStyledBtn(parent, sText, colNormal, colHover, fClick, colOutline)
	local btn = vgui.Create("DButton", parent)
	btn:SetText("")
	btn:SetMouseInputEnabled(true)
	btn:SetKeyboardInputEnabled(false)
	btn:SetZPos(1000)
	btn.DoClick = fClick
	btn.Paint = function(self, w, h)
		-- Bouton Atelier : coin bas-droit coupé, libellé teinté au survol —
		-- SANS contour (les liserés 1px sur coins coupés rendent crénelés).
		local bH = self:IsHovered()
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, bH and colHover or colNormal, gRespY(7), "br")
		else
			RNDX.Draw(0, 0, 0, w, h, bH and colHover or colNormal)
		end
		local cTxt = COL_WHITE
		if bH then
			local ct = self.colOutline or colOutline or COL_ACCENT
			cTxt = Color(ct.r, ct.g, ct.b, 255)
		end
		draw.SimpleText(sText, "LzyPopup_Btn", w * 0.5, h * 0.5,
			cTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return btn
end

-- ══════════════════════════════════════════════════════════
-- PANEL
-- ══════════════════════════════════════════════════════════

function PANEL:Init()
	self:SetDraggable(false)
	self:SetSizable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:SetPaintBackgroundEnabled(false)
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetVisible(true)
	self:SetDrawOnTop(true)
	self:SetZPos(32767)
	self:SetMouseInputEnabled(true)
	LZY_POPUP_ACTIVE = self

	-- Fullscreen hitbox so clicks outside the card never reach UIs behind (e.g. reroll).
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)

	self.Card = vgui.Create("DPanel", self)
	self.Card:SetZPos(10)
	self.Card:SetPaintBackground(false)
	self.Card:SetMouseInputEnabled(true)
	self.Card.Paint = function(card, cw, ch)
		local root = card:GetParent()
		if not IsValid(root) then return end
		local a = root._alpha / 255
		if a < 0.01 then return end

		-- Plaque de métal noir PLATE Atelier (remplace la carte arrondie).
		-- DA dashboard 08/07 : plus de liseré acier ; la teinte du titre/slash et
		-- des boutons OUI/NON reste fonctionnelle (gérée plus bas).
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, cw, ch, ColorAlpha(COL_BG, 255 * a), gRespY(12))
		else
			RNDX.Draw(0, 0, 0, cw, ch, ColorAlpha(COL_BG, 255 * a))
		end

		local nPad = gRespY(PAD)

		local colAccent = COL_ACCENT
		local sTitle = "NOTIFICATION"
		if root.type == "error" then
			colAccent = COL_ERROR
			sTitle = "ERREUR"
		elseif root.type == "success" then
			colAccent = COL_SUCCESS
			sTitle = "SUCCÈS"
		end
		if root.popupType == "yesno" then
			sTitle = "CONFIRMATION"
			colAccent = COL_SUCCESS -- confirmation = accent VERT (au lieu du rouge)
			-- DANGER (09/22) : acte irreversible ou mutilant (amputation). Accent ROUGE
			-- pour que le joueur ne confirme pas par reflexe sur un cadre vert.
			if root.danger then
				sTitle = "ATTENTION"
				colAccent = COL_ERROR
			end
		end
		-- Titre personnalisé optionnel (ex: "⚠ AVERTISSEMENT" suppression item boutique).
		if isstring(root.customTitle) and root.customTitle ~= "" then
			sTitle = root.customTitle
		end

		-- Titre + entaille slash1 COLLÉE dessous, teintée comme le titre
		-- (remplace la barre verticale) + filet DENTÉ en séparateur.
		draw.SimpleText(sTitle, "LzyPopup_Title",
			nPad + gRespX(2), nPad + gRespY(10),
			ColorAlpha(colAccent, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("LzyPopup_Title")
		local twT, thT = surface.GetTextSize(sTitle)
		if EVO_UI and EVO_UI.Ink then
			EVO_UI.Ink(EVO_UI.TexSlash, nPad, nPad + gRespY(10) + thT * 0.28, twT * 1.15, gRespY(8), ColorAlpha(colAccent, 245 * a))
		end

		-- (Séparateur denté RETIRÉ — demande user 06/07 : l'entaille sous le
		-- titre suffit, le message respire directement dessous.)

		surface.SetFont("LzyPopup_Msg")
		local lineH = select(2, surface.GetTextSize("A")) + gRespY(3)
		local ty = nPad + gRespY(38)
		for _, line in ipairs(root._lines) do
			draw.SimpleText(line, "LzyPopup_Msg",
				cw * 0.5, ty,
				ColorAlpha(COL_GREY_LIGHT, 230 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			ty = ty + lineH
		end
		if root._warnLines and #root._warnLines > 0 then
			ty = ty + gRespY(8)
			for _, line in ipairs(root._warnLines) do
				draw.SimpleText(line, "LzyPopup_Msg",
					cw * 0.5, ty,
					ColorAlpha(COL_ERROR, 245 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				ty = ty + lineH
			end
		end
	end

	self.message = ""
	self.warning = ""
	self.popupType = "normal"
	self._lines = {}
	self._warnLines = {}
	self._alpha = 0

	-- Create buttons (positioned in PerformLayout)
	self.yesBtn = MakeStyledBtn(self.Card, "OUI", COL_BTN_NORMAL, COL_BTN_HOVER, function()
		self:Close()
	end, COL_BORDER_GREEN) -- OUI = survol VERT (NON reste rouge = annuler)
	self.noBtn = MakeStyledBtn(self.Card, "NON", COL_BTN_NORMAL, COL_BTN_HOVER, function()
		self:Close()
	end)
	self._defaultNoClick = self.noBtn.DoClick
	self.closeBtn = MakeStyledBtn(self.Card, "FERMER", COL_BTN_NORMAL, COL_BTN_HOVER, function()
		LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
		self:Close()
	end)

	self.yesBtn:SetVisible(false)
	self.noBtn:SetVisible(false)
	self.closeBtn:SetVisible(true)
end

function PANEL:SetTextContent(message)
	self.message = message or ""
	self:_Recompute()
end

function PANEL:SetWarning(warning)
	self.warning = warning or ""
	self:_Recompute()
end

function PANEL:_Recompute()
	if not IsValid(self.Card) then return end
	local nPad = gRespY(PAD)
	local nMaxW = gRespY(POP_W) - nPad * 2
	self._lines = WrapText(self.message, "LzyPopup_Msg", nMaxW)
	self._warnLines = (self.warning and self.warning ~= "")
		and WrapText(self.warning, "LzyPopup_Msg", nMaxW) or {}

	surface.SetFont("LzyPopup_Msg")
	local lineH = select(2, surface.GetTextSize("A")) + gRespY(3)
	local nTextH = #self._lines * lineH
	if #self._warnLines > 0 then
		nTextH = nTextH + gRespY(8) + #self._warnLines * lineH
	end

	-- title area + separator + text + gap + buttons + pad
	local nTitleH = gRespY(30)
	local nH = nPad + nTitleH + gRespY(8) + nTextH + gRespY(12) + gRespY(BTN_H) + nPad
	local nW = gRespY(POP_W)

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self.Card:SetSize(nW, nH)
	self.Card:SetPos(math.floor((ScrW() - nW) / 2), math.floor((ScrH() - nH) / 2))
	self:_LayoutButtons()
end

function PANEL:_LayoutButtons()
	local w, h = self.Card:GetSize()
	local nPad = gRespY(PAD)
	local nBtnH = gRespY(BTN_H)
	local nBtnY = h - nPad - nBtnH

	if self.popupType == "yesno" then
		local nGap = gRespY(BTN_GAP)
		local nBtnW = (w - nPad * 2 - nGap) / 2
		self.yesBtn:SetPos(nPad, nBtnY)
		self.yesBtn:SetSize(nBtnW, nBtnH)
		self.noBtn:SetPos(nPad + nBtnW + nGap, nBtnY)
		self.noBtn:SetSize(nBtnW, nBtnH)
	else
		local nBtnW = w - nPad * 2
		self.closeBtn:SetPos(nPad, nBtnY)
		self.closeBtn:SetSize(nBtnW, nBtnH)
	end
end

function PANEL:SetPopupType(popupType)
	self.popupType = popupType

	if popupType == "yesno" then
		self.closeBtn:SetVisible(false)
		self.yesBtn:SetVisible(true)
		self.noBtn:SetVisible(true)
	else
		self.closeBtn:SetVisible(true)
		self.yesBtn:SetVisible(false)
		self.noBtn:SetVisible(false)
	end

	self:_Recompute()
end

function PANEL:SetYesCallback(callback, args)
	self.yesBtn.DoClick = function()
		self._answered = true
		callback(args or {})
		self:Close()
	end
end

function PANEL:SetNoCallback(callback, args)
	self._noCallback, self._noArgs = callback, args
	if callback then
		self.noBtn.DoClick = function()
			self._answered = true
			callback(args or {})
			self:Close()
		end
	else
		self.noBtn.DoClick = self._defaultNoClick or function()
			self:Close()
		end
	end
end

-- Fermeture SANS reponse (Echap, via EVO_MakeEscClosable -> openedFrame:Close()) :
-- rejouer le callback NON. OPT-IN, car pour la plupart des confirmations abandonner ne
-- doit RIEN envoyer. Reserve a celles qui laissent l'emetteur en attente : le reroll
-- garde le tirage en suspens cote serveur et refuse les suivants tant qu'il n'a pas de
-- reponse, donc y renoncer VAUT refuser — sinon le joueur se bloque lui-meme.
function PANEL:SetNoOnDismiss(bEnabled)
	self._noOnDismiss = bEnabled and true or false
end

function PANEL:SetType(type)
	self.type = type
end

function PANEL:SetCustomTitle(t)
	self.customTitle = t
end

-- Confirmation DANGEREUSE : accent rouge + bouton OUI rouge au survol. Le bouton NON
-- garde sa teinte par defaut, c'est deja le choix sans risque.
function PANEL:SetDanger(bEnabled)
	self.danger = bEnabled and true or false
	if IsValid(self.yesBtn) then
		self.yesBtn.colOutline = self.danger and COL_ERROR or nil
	end
end

function PANEL:Think()
	self._alpha = Lerp(FrameTime() * 10, self._alpha, 255)
	if IsValid(self.Card) and (self:GetWide() ~= ScrW() or self:GetTall() ~= ScrH()) then
		self:_Recompute()
	end
	self:MoveToFront()
end

function PANEL:Paint(w, h)
	local a = self._alpha / 255
	if a < 0.01 then return end
	draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(Color(0, 0, 0), 120 * a))
end

function PANEL:OnClose()
	if self._noOnDismiss and not self._answered and self._noCallback then
		self._answered = true
		self._noCallback(self._noArgs or {})
	end
	frame = nil
	LZY_POPUP_ACTIVE = nil
	ProcessPopupQueue()
end

-- ══════════════════════════════════════════════════════════
-- Queue system
-- ══════════════════════════════════════════════════════════

function ProcessPopupQueue()
	if frame then
		if IsValid(frame) then
			return
		else
			frame = nil
			LZY_POPUP_ACTIVE = nil
		end
	end

	if #popupQueue == 0 then return end

	local popupData = table.remove(popupQueue, 1)
	if not popupData then return end

	if popupData.type == "yesno" then
		frame = vgui.Create("lzy_popup")
		frame:SetTextContent(popupData.message)
		if isstring(popupData.warning) and popupData.warning ~= "" then
			frame:SetWarning(popupData.warning)
		end
		frame:SetYesCallback(LZY_POPUP_CALLBACKS[popupData.yesCallback], popupData.args)
		if isstring(popupData.noCallback) and popupData.noCallback ~= "" and LZY_POPUP_CALLBACKS[popupData.noCallback] then
			frame:SetNoCallback(LZY_POPUP_CALLBACKS[popupData.noCallback], popupData.args)
			frame:SetNoOnDismiss(popupData.noOnDismiss)
		else
			frame:SetNoCallback(nil)
		end
		if isstring(popupData.title) and popupData.title ~= "" then frame:SetCustomTitle(popupData.title) end
		if popupData.danger then frame:SetDanger(true) end
		frame:SetPopupType("yesno")
		LocalPlayer():EmitSound("6515xw26amw1br/thui5lpdeagxqwqak.ogg", 75, 100, 1, CHAN_AUTO)
	else
		frame = vgui.Create("lzy_popup")
		frame:SetTextContent(popupData.message)
		frame:SetType(popupData.popupType)
		if isstring(popupData.title) and popupData.title ~= "" then frame:SetCustomTitle(popupData.title) end
		frame:SetPopupType("normal")
		if popupData.popupType == "error" then
			LocalPlayer():EmitSound("6515xw26amw1br/dbkfm56fmkjrl.ogg", 75, 100, 1, CHAN_AUTO)
		else
			LocalPlayer():EmitSound("6515xw26amw1br/thui5lpdeagxqwqak.ogg", 75, 100, 1, CHAN_AUTO)
		end
	end
end

vgui.Register("lzy_popup", PANEL, "DFrame")

-- ══════════════════════════════════════════════════════════
-- Player meta methods (API inchangée)
-- ══════════════════════════════════════════════════════════
local metaPlayer = FindMetaTable("Player")

-- `noOnDismiss` : fermer la popup sans repondre (Echap) declenche le callback NON.
-- Cf. PANEL:SetNoOnDismiss. Non transmis par le message reseau : seul un appel CLIENT
-- direct peut le demander, faute de quoi le serveur pourrait faire "repondre" un joueur
-- qui n'a rien fait.
function metaPlayer:OpenYesNoPopup(message, yesCallback, args, noCallback, title, noOnDismiss, warning, danger)
	table.insert(popupQueue, {
		type = "yesno",
		message = message,
		yesCallback = yesCallback,
		noCallback = noCallback,
		noOnDismiss = noOnDismiss,
		args = args,
		title = title,
		warning = warning,
		danger = danger,
	})
	ProcessPopupQueue()
end

function metaPlayer:OpenPopup(message, type, title)
	table.insert(popupQueue, {
		type = "normal",
		message = message,
		popupType = type,
		title = title,
	})
	ProcessPopupQueue()
end

function metaPlayer:ClosePopup()
	if not frame or not IsValid(frame) then return end
	frame:Close()
end

function metaPlayer:ClearPopupQueue()
	popupQueue = {}
end

net.Receive("LZY:OpenYesNoPopup", function()
	local message = net.ReadString()
	local yesCallback = net.ReadString()
	local noCallback = net.ReadString()
	local args = net.ReadTable() or {}
	local warning
	if net.ReadBool() then
		warning = net.ReadString()
	end
	if noCallback == "" then noCallback = nil end
	LocalPlayer():OpenYesNoPopup(message, yesCallback, args, noCallback, nil, nil, warning)
end)

net.Receive("LZY:OpenPopup", function()
	local message = net.ReadString()
	local type = net.ReadString()
	local title
	if net.ReadBool() then
		title = net.ReadString()
	end
	LocalPlayer():OpenPopup(message, type, title)
end)