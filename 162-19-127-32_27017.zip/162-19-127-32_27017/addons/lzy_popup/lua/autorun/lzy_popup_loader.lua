-- "addons\\lzy_popup\\lua\\autorun\\lzy_popup_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_popup/cl_callbacks.lua")
	AddCSLuaFile("lzy_popup/cl_main.lua")
	include("lzy_popup/sv_net.lua")

	-- print("[LZY_POPUP] Starting resource loading...")
		
	-- Auto-add all material files as resources
	local materialFiles = file.Find("materials/lzy_popup/*", "GAME")
	if not materialFiles or #materialFiles == 0 then
		materialFiles = file.Find("materials/lzy_popup/*", "WORKSHOP")
	end
	if not materialFiles or #materialFiles == 0 then
		materialFiles = file.Find("materials/lzy_popup/*", "MOD")
	end
	for _, fileName in pairs(materialFiles) do
		if string.find(fileName, "%.") then
			local fileExt = string.lower(string.GetExtensionFromFilename(fileName))
			if fileExt == "png" or fileExt == "jpg" or fileExt == "jpeg" or fileExt == "vtf" or fileExt == "vmt" then
				resource.AddFile("materials/lzy_popup/" .. fileName)
				-- print("[LZY_POPUP] Added resource: materials/lzy_popup/" .. fileName)
			end
		end
	end

	-- Auto add all fonts files as resources
	local fontFiles = file.Find("resource/fonts/*", "GAME")
	if not fontFiles or #fontFiles == 0 then
		fontFiles = file.Find("resource/fonts/*", "WORKSHOP")
	end
	if not fontFiles or #fontFiles == 0 then
		fontFiles = file.Find("resource/fonts/*", "MOD")
	end
	for _, fileName in pairs(fontFiles) do
		if string.find(fileName, "%.") then
			local fileExt = string.lower(string.GetExtensionFromFilename(fileName))
			if fileExt == "ttf" or fileExt == "otf" then
				resource.AddFile("resource/fonts/" .. fileName)
				-- print("[LZY_POPUP] Added resource: resource/fonts/" .. fileName)
			end
		end
	end
	
	-- print("[LZY_POPUP] Resource loading complete")
else
	include("lzy_popup/cl_callbacks.lua")
	include("lzy_popup/cl_main.lua")
end