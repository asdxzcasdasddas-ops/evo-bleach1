-- "addons\\evo_bataille_factions\\lua\\autorun\\sh_loader_bataille_factions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BATAILLE DES FACTIONS — défi grade 10+ (last-faction-alive, dôme mobile).
-- ============================================================================

EVO_BATAILLE_FAC = EVO_BATAILLE_FAC or {}

if SERVER then
    AddCSLuaFile("evo_bataille_factions/sh_config.lua")
    AddCSLuaFile("evo_bataille_factions/cl_main.lua")

    util.AddNetworkString("EVO_BatailleFac:Propose")
    util.AddNetworkString("EVO_BatailleFac:Answer")
    util.AddNetworkString("EVO_BatailleFac:Cancel")
    util.AddNetworkString("EVO_BatailleFac:CancelGrant")
    util.AddNetworkString("EVO_BatailleFac:Preview")
    util.AddNetworkString("EVO_BatailleFac:State")
    util.AddNetworkString("EVO_BatailleFac:Banner")
    util.AddNetworkString("EVO_BatailleFac:ExitWarn")
    util.AddNetworkString("EVO_BatailleFac:Reward")
end

include("evo_bataille_factions/sh_config.lua")

if SERVER then
    include("evo_bataille_factions/sv_main.lua")
else
    include("evo_bataille_factions/cl_main.lua")
end
