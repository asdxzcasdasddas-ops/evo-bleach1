-- "addons\\evo_bataille_factions\\lua\\evo_bataille_factions\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Bataille des Factions — config partagée + helpers (faction / grade / dôme)
-- ============================================================================

EVO_BATAILLE_FAC = EVO_BATAILLE_FAC or {}
EVO_BATAILLE_FAC.Config = EVO_BATAILLE_FAC.Config or {}

local CFG = EVO_BATAILLE_FAC.Config

CFG.RadiusMin = 1000
CFG.RadiusMax = 8000
CFG.Height = 3000
CFG.JoinSeconds = 900
CFG.PendingTimeout = 30
CFG.KickPadding = 100
CFG.SpectatePadding = 1000
CFG.ProposeDistance = 400
CFG.ExitGraceSeconds = 5
CFG.FloorDropMin = 500
CFG.FloorDropMax = 1500
CFG.HighRankMin = 10
CFG.HighRankDelay = 600
CFG.HighRankDelayMessage = "Les grades 10 et plus ne peuvent pas entrer dans la zone pendant les 10 premières minutes de l'événement."
CFG.LeaveZoneMessage = "Tu as quitté la zone — exclus de la Bataille des Factions."
CFG.ReentryPopupCooldown = 5
CFG.HudTitle = "BATAILLE DES FACTIONS"
CFG.BannerDuration = 10
CFG.BannerSound = "friends/friend_online.wav"
CFG.RewardHudDuration = 8
CFG.RewardHudSound = "a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3"
CFG.ReentryBanMessage = "Il est interdit de réentrer dans la zone."
CFG.WrongFactionMessage = "Seules les deux factions du défi peuvent entrer dans le dôme."
CFG.MaxPerFacMin = 1
CFG.MaxPerFacMax = 64
CFG.MaxPerFacDefault = 10
CFG.FullFactionMessage = "Cette faction a atteint le nombre maximum de participants."
CFG.MaxHighRankMin = 0
CFG.MaxHighRankMax = 64
CFG.MaxHighRankDefault = 5
CFG.FullHighRankMessage = "Cette faction a atteint le nombre maximum de hauts gradés."
CFG.LaunchCooldown = 3600
CFG.CancelWindow = 180

function EVO_BATAILLE_FAC.MinRank()
    return (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.PromoteMinRank) or 10
end

function EVO_BATAILLE_FAC.PlayerFaction(ply)
    if not IsValid(ply) or not ply.GetEvoNWString then return "" end
    local f = ply:GetEvoNWString("FactionName", "")
    if f == "" then f = ply:GetEvoNWString("faction_name", "") end
    return f
end

function EVO_BATAILLE_FAC.IsValidFaction(f)
    return isstring(f) and f ~= "" and f ~= "LostSoul"
end

function EVO_BATAILLE_FAC.IsGradeOk(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= EVO_BATAILLE_FAC.MinRank()
end

function EVO_BATAILLE_FAC.IsEventLive()
    return EVO_BATAILLE_FAC._live == true
end

function EVO_BATAILLE_FAC.OtherEventActive()
    if CLIENT then
        local id = GetGlobalString("EVO_GM_ActiveEvent", "") or ""
        return id ~= ""
    end
    if EVO_BATAILLE_FAC.IsEventLive() then return true end
    if GameManager and GameManager.IsEventActive and GameManager.IsEventActive() then
        return true
    end
    return false
end

--- Seconds until another launch is allowed (0 = ready).
function EVO_BATAILLE_FAC.LaunchCooldownRemain()
    local cd = tonumber(EVO_BATAILLE_FAC.Config and EVO_BATAILLE_FAC.Config.LaunchCooldown) or 3600
    local last = tonumber(GetGlobalFloat("EVO_BF_LastLaunch", 0)) or 0
    if last <= 0 then return 0 end
    return math.max(0, (last + cd) - CurTime())
end

--- ok, reason (reason only when ok == false)
function EVO_BATAILLE_FAC.CanPropose(ply, target)
    if not (IsValid(ply) and IsValid(target) and ply:IsPlayer() and target:IsPlayer()) then
        return false
    end
    if target == ply then return false end
    if not ply:Alive() or not target:Alive() then return false end
    if ply:IsBot() or target:IsBot() then return false end

    local cfg = EVO_BATAILLE_FAC.Config
    local dist = tonumber(cfg.ProposeDistance) or 400
    if ply:GetPos():DistToSqr(target:GetPos()) > dist * dist then
        return false, "Rapproche-toi du joueur."
    end

    if not EVO_BATAILLE_FAC.IsGradeOk(ply) then return false end
    if not EVO_BATAILLE_FAC.IsGradeOk(target) then return false end

    local a = EVO_BATAILLE_FAC.PlayerFaction(ply)
    local b = EVO_BATAILLE_FAC.PlayerFaction(target)
    if not EVO_BATAILLE_FAC.IsValidFaction(a) then return false end
    if not EVO_BATAILLE_FAC.IsValidFaction(b) then return false end
    if a == b then return false end

    if MUGEN and MUGEN.IsPlayerBusyForActions then
        if MUGEN.IsPlayerBusyForActions(ply) then return false end
        if MUGEN.IsPlayerBusyForActions(target) then return false end
    end

    if EVO_BATAILLE_FAC.OtherEventActive() then
        return false, "Un événement est déjà en cours."
    end

    local left = EVO_BATAILLE_FAC.LaunchCooldownRemain and EVO_BATAILLE_FAC.LaunchCooldownRemain() or 0
    if left > 0 then
        local min = math.max(1, math.ceil(left / 60))
        return false, "Une Bataille des Factions a déjà été lancée. Prochaine dans " .. min .. " min."
    end

    return true
end

--- Hemi-ellipsoid (same formula as EVO_BATAILLE.IsInsideArena).
function EVO_BATAILLE_FAC.IsInsideArena(vPos, arena)
    if not vPos or not arena or not arena.center then return false end
    if EVO_BATAILLE and EVO_BATAILLE.IsInsideArenaCfg then
        return EVO_BATAILLE.IsInsideArenaCfg(vPos, arena)
    end
    local r = tonumber(arena.radius) or 0
    if r <= 0 then return false end
    local h = tonumber(arena.height) or 0
    if h <= 0 then h = r end
    local c = arena.center
    local dz = vPos.z - c.z
    if dz < -32 then return false end
    if dz > h then return false end
    local dx = vPos.x - c.x
    local dy = vPos.y - c.y
    return (dx * dx + dy * dy) / (r * r) + (dz * dz) / (h * h) <= 1
end
