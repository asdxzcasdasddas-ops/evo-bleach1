-- "addons\\evo_bataille_factions\\lua\\evo_bataille_factions\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Bataille des Factions — client : picker rayon, dôme, HUD, popups
-- ============================================================================

if not CLIENT then return end

EVO_BATAILLE_FAC = EVO_BATAILLE_FAC or {}
local CFG = EVO_BATAILLE_FAC.Config

local function R(v)
    return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local COL = {
    bg     = Color(13, 14, 17, 245),
    panel  = Color(22, 22, 28, 255),
    title  = Color(238, 239, 243),
    muted  = Color(150, 154, 162),
    accent = Color(207, 68, 78),
    yellow = Color(255, 200, 60),
    green  = Color(78, 196, 128),
    btn    = Color(30, 32, 38),
    btnH   = Color(50, 52, 62),
    border = Color(255, 255, 255, 18),
}

local function makeFonts()
    local mk = gCreateRespFont
    if not mk then
        local sc = math.max(1, ScrH() / 1080)
        mk = function(name, font, size)
            surface.CreateFont(name, { font = font, size = math.Round(size * sc), weight = 400, extended = true })
        end
    end
    mk("EVO_BF_Small", "Bebas Neue", 22, 400)
    mk("EVO_BF_Text",  "Bebas Neue", 28, 400)
    mk("EVO_BF_Head",  "Bebas Neue", 36, 400)
    mk("EVO_BF_AnnTitle", "Roboto", 17, 800)
    mk("EVO_BF_AnnName",  "Roboto", 30, 800)
    mk("EVO_BF_AnnSub",   "Roboto", 18, 500)
    mk("EVO_BF_Reward",   "Bebas Neue", 48, 400)
end
makeFonts()
hook.Add("Initialize", "EVO_BF::Fonts", makeFonts)
hook.Add("OnScreenSizeChanged", "EVO_BF::Fonts", makeFonts)

-- ── State ───────────────────────────────────────────────────────────────────

local st = {
    live = false,
    winner = "",
    center = Vector(0, 0, 0),
    radius = 0,
    height = 0,
    facA = "",
    facB = "",
    phase = 0,
    joinRemain = 0,
    recvAt = 0,
    nA = 0,
    nB = 0,
    maxPerFac = 0,
    maxHighRank = 0,
}

local preview = {
    on = false,
    center = Vector(0, 0, 0),
    radius = 0,
    height = 0,
}

local pickerFrame = nil
EVO_BATAILLE_FAC._Picker = nil

local cancelUntil = 0

function EVO_BATAILLE_FAC.CanLocalCancel()
    return cancelUntil > CurTime()
end

--- Client : le HUD event est affiché — masque le tracker quêtes (même pattern que EVO_BATAILLE).
local function isNearHudZone()
    if not st.live or not st.center then return false end
    local lp = LocalPlayer()
    if not IsValid(lp) then return false end
    local pad = tonumber(CFG and CFG.SpectatePadding) or 1000
    local r = (tonumber(st.radius) or 0) + pad
    local pos = lp:GetPos()
    local dx = pos.x - st.center.x
    local dy = pos.y - st.center.y
    if (dx * dx + dy * dy) > (r * r) then return false end
    local h = tonumber(st.height) or 0
    return pos.z >= (st.center.z - pad) and pos.z <= (st.center.z + h + pad)
end

function EVO_BATAILLE_FAC.IsLocalInEvent()
    return isNearHudZone()
end

--- Client : ce joueur est dans le dôme de Bataille des Factions (cosmétiques de grade).
function EVO_BATAILLE_FAC.IsPlayerInside(ent)
    if not EVO_BATAILLE_FAC._live then return false end
    if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return false end
    local a = EVO_BATAILLE_FAC._arena
    if not a or not a.center then return false end
    return EVO_BATAILLE_FAC.IsInsideArena(ent:GetPos(), a)
end

-- ── Draw dome (reuse Bataille des Clans mesh if loaded) ─────────────────────

local SEG_LON = 32
local SEG_LAT = 12
local FILL   = Color(255, 210, 40, 55)
local EDGE   = Color(255, 220, 60, 160)
local GROUND = Color(255, 200, 40, 40)

local function hemiPoint(center, radius, height, lat, lon)
    local c = math.cos(lat)
    return Vector(
        center.x + radius * c * math.cos(lon),
        center.y + radius * c * math.sin(lon),
        center.z + height * math.sin(lat)
    )
end

local function drawQuadBoth(a, b, c, d, col)
    render.DrawQuad(a, b, c, d, col)
    render.DrawQuad(d, c, b, a, col)
end

local function drawDomeLocal(center, radius, height)
    if not center or not radius or radius <= 0 then return end
    height = tonumber(height)
    if not height or height <= 0 then height = radius end
    render.SetColorMaterial()

    local halfPi = math.pi * 0.5
    local twoPi  = math.pi * 2

    for li = 0, SEG_LAT - 1 do
        local lat1 = (li / SEG_LAT) * halfPi
        local lat2 = ((li + 1) / SEG_LAT) * halfPi
        for lo = 0, SEG_LON - 1 do
            local lon1 = (lo / SEG_LON) * twoPi
            local lon2 = ((lo + 1) / SEG_LON) * twoPi
            local p1 = hemiPoint(center, radius, height, lat1, lon1)
            local p2 = hemiPoint(center, radius, height, lat1, lon2)
            local p3 = hemiPoint(center, radius, height, lat2, lon2)
            local p4 = hemiPoint(center, radius, height, lat2, lon1)
            drawQuadBoth(p1, p2, p3, p4, FILL)
        end
    end

    local origin = Vector(center.x, center.y, center.z)
    for lo = 0, SEG_LON - 1 do
        local lon1 = (lo / SEG_LON) * twoPi
        local lon2 = ((lo + 1) / SEG_LON) * twoPi
        local a = hemiPoint(center, radius, height, 0, lon1)
        local b = hemiPoint(center, radius, height, 0, lon2)
        drawQuadBoth(origin, a, b, origin, GROUND)
    end

    for lo = 0, SEG_LON - 1 do
        local lon1 = (lo / SEG_LON) * twoPi
        local lon2 = ((lo + 1) / SEG_LON) * twoPi
        render.DrawLine(hemiPoint(center, radius, height, 0, lon1), hemiPoint(center, radius, height, 0, lon2), EDGE, true)
    end
    local meridians = 8
    for mi = 0, meridians - 1 do
        local lon = (mi / meridians) * twoPi
        for li = 0, SEG_LAT - 1 do
            local lat1 = (li / SEG_LAT) * halfPi
            local lat2 = ((li + 1) / SEG_LAT) * halfPi
            render.DrawLine(hemiPoint(center, radius, height, lat1, lon), hemiPoint(center, radius, height, lat2, lon), EDGE, true)
        end
    end
end

local function drawDome(center, radius, height)
    if EVO_BATAILLE and EVO_BATAILLE.DrawHemiSphere then
        EVO_BATAILLE.DrawHemiSphere(center, radius, height)
        return
    end
    drawDomeLocal(center, radius, height)
end

hook.Add("PostDrawTranslucentRenderables", "EVO_BF::Dome", function(bDepth, bSky)
    if bDepth or bSky then return end
    local pk = EVO_BATAILLE_FAC._Picker
    if pk and pk.preview then
        local lp = LocalPlayer()
        local origin = IsValid(lp) and lp:GetPos() or pk.center or Vector(0, 0, 0)
        local drop = tonumber(pk.floorDrop) or 0
        local center = Vector(origin.x, origin.y, origin.z - drop)
        local h = (tonumber(pk.height) or 3000) + drop
        drawDome(center, pk.radius, h)
        return
    end
    if preview.on then
        drawDome(preview.center, preview.radius, preview.height)
        return
    end
    if st.live then
        drawDome(st.center, st.radius, st.height)
    end
end)

-- ── Nets ────────────────────────────────────────────────────────────────────

net.Receive("EVO_BatailleFac:Preview", function()
    local on = net.ReadBool()
    preview.on = on
    if on then
        preview.center = net.ReadVector()
        preview.radius = net.ReadUInt(16)
        preview.height = net.ReadUInt(16)
    end
end)

net.Receive("EVO_BatailleFac:State", function()
    local live = net.ReadBool()
    st.live = live
    EVO_BATAILLE_FAC._live = live
    if not live then
        EVO_BATAILLE_FAC._arena = nil
        st.winner = net.ReadString()
        st.facA = ""
        st.facB = ""
        preview.on = false
        return
    end
    preview.on = false
    st.center = net.ReadVector()
    st.radius = net.ReadUInt(16)
    st.height = net.ReadUInt(16)
    st.facA = net.ReadString()
    st.facB = net.ReadString()
    st.phase = net.ReadUInt(2)
    st.joinRemain = net.ReadUInt(16)
    st.recvAt = CurTime()
    st.nA = net.ReadUInt(8)
    st.nB = net.ReadUInt(8)
    st.maxPerFac = net.ReadUInt(8)
    st.maxHighRank = net.ReadUInt(8)
    EVO_BATAILLE_FAC._arena = {
        center = st.center,
        radius = st.radius,
        height = st.height,
    }
end)

local banner = nil -- { facA, facB, joinMin, born, expire }

net.Receive("EVO_BatailleFac:Banner", function()
    local facA = net.ReadString()
    local facB = net.ReadString()
    local joinMin = net.ReadUInt(8)
    local now = RealTime()
    local dur = (CFG and CFG.BannerDuration) or 10
    banner = {
        facA = facA,
        facB = facB,
        joinMin = joinMin,
        born = now,
        expire = now + dur,
    }
    surface.PlaySound((CFG and CFG.BannerSound) or "friends/friend_online.wav")
end)

local exitWarn = { active = false, endsAt = 0 }

net.Receive("EVO_BatailleFac:ExitWarn", function()
    local on = net.ReadBool()
    local grace = net.ReadFloat()
    if on then
        exitWarn.active = true
        exitWarn.endsAt = CurTime() + grace
    else
        exitWarn.active = false
    end
end)

hook.Add("HUDPaint", "EVO_BF::Banner", function()
    if not banner then return end
    local now = RealTime()
    if now >= banner.expire then banner = nil return end

    local appear = math.Clamp((now - banner.born) / 0.4, 0, 1)
    local fade = math.Clamp((banner.expire - now) / 1.0, 0, 1)
    local A = 255 * fade
    local accent = COL.yellow

    local label = "BATAILLE DES FACTIONS"
    local name = (banner.facA or "?") .. "  vs  " .. (banner.facB or "?")
    local sub = tostring(banner.joinMin or 15) .. " min pour entrer dans le dôme"

    surface.SetFont("EVO_BF_AnnTitle")
    local lw = surface.GetTextSize(label)
    surface.SetFont("EVO_BF_AnnName")
    local nw = surface.GetTextSize(name)
    surface.SetFont("EVO_BF_AnnSub")
    local sw = surface.GetTextSize(sub)

    local accW = R(46)
    local padX = R(42)
    local boxW = math.max(lw, nw, sw, accW) + padX * 2
    local boxH = R(16) + R(20) + R(9) + R(2) + R(11) + R(34) + R(7) + R(20) + R(16)
    local boxX = math.floor((ScrW() - boxW) * 0.5)
    local boxY = math.floor(Lerp(appear, -boxH - R(20), R(70)))
    local cx = math.floor(ScrW() * 0.5)

    local bg = Color(13, 13, 16, A)
    local outline = Color(accent.r, accent.g, accent.b, math.floor(A * 0.5))
    if RNDX and RNDX.Draw then
        RNDX.Draw(R(12), boxX, boxY, boxW, boxH, bg)
        if RNDX.DrawOutlined then
            RNDX.DrawOutlined(R(12), boxX, boxY, boxW, boxH, outline, 1.5)
        end
    else
        surface.SetDrawColor(bg)
        surface.DrawRect(boxX, boxY, boxW, boxH)
        surface.SetDrawColor(outline)
        surface.DrawOutlinedRect(boxX, boxY, boxW, boxH)
    end

    local y = boxY + R(16)
    draw.SimpleText(label, "EVO_BF_AnnTitle", cx, y, ColorAlpha(accent, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    y = y + R(20) + R(9)
    surface.SetDrawColor(accent.r, accent.g, accent.b, A)
    surface.DrawRect(math.floor(cx - accW * 0.5), y, accW, R(2))
    y = y + R(2) + R(11)
    draw.SimpleText(name, "EVO_BF_AnnName", cx, y, ColorAlpha(COL.title, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    y = y + R(34) + R(7)
    draw.SimpleText(sub, "EVO_BF_AnnSub", cx, y, ColorAlpha(COL.muted, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

-- ── Popups ──────────────────────────────────────────────────────────────────

LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.BatailleFacAccept = function(_args)
    net.Start("EVO_BatailleFac:Answer")
        net.WriteBool(true)
    net.SendToServer()
end
LZY_POPUP_CALLBACKS.BatailleFacDecline = function(_args)
    net.Start("EVO_BatailleFac:Answer")
        net.WriteBool(false)
    net.SendToServer()
end
LZY_POPUP_CALLBACKS.BatailleFacCancel = function(_args)
    if not EVO_BATAILLE_FAC.CanLocalCancel() then return end
    net.Start("EVO_BatailleFac:Cancel")
    net.SendToServer()
end

net.Receive("EVO_BatailleFac:CancelGrant", function()
    local on = net.ReadBool()
    if not on then
        cancelUntil = 0
        return
    end
    cancelUntil = CurTime() + net.ReadUInt(16)
end)

-- ── Radius picker ───────────────────────────────────────────────────────────

local function makeBtn(parent, text, colBg, colHover, onClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetText("")
    btn.Paint = function(s, w, h)
        local c = s:IsHovered() and colHover or colBg
        surface.SetDrawColor(c)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COL.border)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.SimpleText(text, "EVO_BF_Small", w / 2, h / 2, COL.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btn.DoClick = function()
        surface.PlaySound("buttons/button14.wav")
        if onClick then onClick() end
    end
    return btn
end

local function closePicker()
    EVO_BATAILLE_FAC._Picker = nil
    if IsValid(pickerFrame) then
        pickerFrame._closing = true
        pickerFrame:Remove()
    end
    pickerFrame = nil
end

local function hideLang(p)
    if not IsValid(p) then return end
    if p.SetDrawLanguageID then p:SetDrawLanguageID(false) end
    if IsValid(p.TextArea) and p.TextArea.SetDrawLanguageID then
        p.TextArea:SetDrawLanguageID(false)
    end
    for _, ch in ipairs(p:GetChildren()) do
        if IsValid(ch) and ch.SetDrawLanguageID then ch:SetDrawLanguageID(false) end
    end
end

function EVO_BATAILLE_FAC.OpenRadiusPicker(target)
    if not IsValid(target) then return end
    closePicker()

    local c = CFG or EVO_BATAILLE_FAC.Config or {}
    local rMin = tonumber(c.RadiusMin) or 1000
    local rMax = tonumber(c.RadiusMax) or 8000
    local dMin = tonumber(c.FloorDropMin) or 500
    local dMax = tonumber(c.FloorDropMax) or 1500
    local pMin = tonumber(c.MaxPerFacMin) or 1
    local pMax = tonumber(c.MaxPerFacMax) or 64
    local pDef = tonumber(c.MaxPerFacDefault) or 10
    local hMin = tonumber(c.MaxHighRankMin) or 0
    local hMax = tonumber(c.MaxHighRankMax) or 64
    local hDef = tonumber(c.MaxHighRankDefault) or 5
    local height = tonumber(c.Height) or 3000
    local defaultR = math.Clamp(4000, rMin, rMax)

    EVO_BATAILLE_FAC._Picker = {
        target    = target,
        radius    = defaultR,
        height    = height,
        floorDrop = dMin,
        maxPerFac = pDef,
        maxHighRank = math.Clamp(hDef, hMin, math.min(hMax, pDef)),
        preview   = true,
    }

    local W, H = R(420), R(530)
    pickerFrame = vgui.Create("DFrame")
    pickerFrame:SetSize(W, H)
    pickerFrame:SetTitle("")
    pickerFrame:ShowCloseButton(false)
    pickerFrame:SetDraggable(true)
    pickerFrame:MakePopup()
    pickerFrame:Center()
    pickerFrame.Paint = function(_, w, h)
        surface.SetDrawColor(COL.bg)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COL.accent)
        surface.DrawRect(0, 0, R(3), h)
        draw.SimpleText("BATAILLE DES FACTIONS", "EVO_BF_Text", R(18), R(14), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Rayon  ·  sol  ·  max / faction  ·  hauts gradés  ·  dôme " .. tostring(height), "EVO_BF_Small", R(18), R(42), COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    pickerFrame.OnClose = closePicker
    pickerFrame.OnRemove = function(s)
        if s._closing then return end
        EVO_BATAILLE_FAC._Picker = nil
        pickerFrame = nil
    end

    local y = R(78)
    local lbl = vgui.Create("DLabel", pickerFrame)
    lbl:SetPos(R(18), y)
    lbl:SetSize(W - R(36), R(20))
    lbl:SetFont("EVO_BF_Small")
    lbl:SetTextColor(COL.muted)
    lbl:SetText("RAYON")

    local pk = EVO_BATAILLE_FAC._Picker

    local num = vgui.Create("DNumberWang", pickerFrame)
    num:SetPos(R(18), y + R(24))
    num:SetSize(R(120), R(28))
    num:SetMin(rMin)
    num:SetMax(rMax)
    num:SetDecimals(0)
    num:SetValue(pk.radius)
    hideLang(num)

    local slider = vgui.Create("DNumSlider", pickerFrame)
    slider:SetPos(R(150), y + R(18))
    slider:SetSize(W - R(168), R(40))
    slider:SetText("")
    slider:SetMin(rMin)
    slider:SetMax(rMax)
    slider:SetDecimals(0)
    slider:SetValue(pk.radius)
    slider.Label:SetVisible(false)
    slider.TextArea:SetVisible(false)
    hideLang(slider)

    num.OnValueChanged = function(_, v)
        pk.radius = math.Clamp(tonumber(v) or pk.radius, rMin, rMax)
        if IsValid(slider) then slider:SetValue(pk.radius) end
    end
    slider.OnValueChanged = function(_, v)
        pk.radius = math.Clamp(tonumber(v) or pk.radius, rMin, rMax)
        if IsValid(num) then num:SetValue(pk.radius) end
    end

    y = y + R(70)
    local lblF = vgui.Create("DLabel", pickerFrame)
    lblF:SetPos(R(18), y)
    lblF:SetSize(W - R(36), R(20))
    lblF:SetFont("EVO_BF_Small")
    lblF:SetTextColor(COL.muted)
    lblF:SetText("SOL (ABAISSER LE PLANCHER)")

    local numF = vgui.Create("DNumberWang", pickerFrame)
    numF:SetPos(R(18), y + R(24))
    numF:SetSize(R(120), R(28))
    numF:SetMin(dMin)
    numF:SetMax(dMax)
    numF:SetDecimals(0)
    numF:SetValue(pk.floorDrop)
    hideLang(numF)

    local sliderF = vgui.Create("DNumSlider", pickerFrame)
    sliderF:SetPos(R(150), y + R(18))
    sliderF:SetSize(W - R(168), R(40))
    sliderF:SetText("")
    sliderF:SetMin(dMin)
    sliderF:SetMax(dMax)
    sliderF:SetDecimals(0)
    sliderF:SetValue(pk.floorDrop)
    sliderF.Label:SetVisible(false)
    sliderF.TextArea:SetVisible(false)
    hideLang(sliderF)

    numF.OnValueChanged = function(_, v)
        pk.floorDrop = math.Clamp(tonumber(v) or pk.floorDrop, dMin, dMax)
        if IsValid(sliderF) then sliderF:SetValue(pk.floorDrop) end
    end
    sliderF.OnValueChanged = function(_, v)
        pk.floorDrop = math.Clamp(tonumber(v) or pk.floorDrop, dMin, dMax)
        if IsValid(numF) then numF:SetValue(pk.floorDrop) end
    end

    y = y + R(70)
    local lblP = vgui.Create("DLabel", pickerFrame)
    lblP:SetPos(R(18), y)
    lblP:SetSize(W - R(36), R(20))
    lblP:SetFont("EVO_BF_Small")
    lblP:SetTextColor(COL.muted)
    lblP:SetText("MAX PARTICIPANTS / FACTION")

    local numP = vgui.Create("DNumberWang", pickerFrame)
    numP:SetPos(R(18), y + R(24))
    numP:SetSize(R(120), R(28))
    numP:SetMin(pMin)
    numP:SetMax(pMax)
    numP:SetDecimals(0)
    numP:SetValue(pk.maxPerFac)
    hideLang(numP)

    local sliderP = vgui.Create("DNumSlider", pickerFrame)
    sliderP:SetPos(R(150), y + R(18))
    sliderP:SetSize(W - R(168), R(40))
    sliderP:SetText("")
    sliderP:SetMin(pMin)
    sliderP:SetMax(pMax)
    sliderP:SetDecimals(0)
    sliderP:SetValue(pk.maxPerFac)
    sliderP.Label:SetVisible(false)
    sliderP.TextArea:SetVisible(false)
    hideLang(sliderP)

    local numH, sliderH

    numP.OnValueChanged = function(_, v)
        pk.maxPerFac = math.Clamp(tonumber(v) or pk.maxPerFac, pMin, pMax)
        if IsValid(sliderP) then sliderP:SetValue(pk.maxPerFac) end
        local hi = math.min(hMax, pk.maxPerFac)
        if pk.maxHighRank > hi then
            pk.maxHighRank = math.Clamp(pk.maxHighRank, hMin, hi)
            if IsValid(numH) then numH:SetValue(pk.maxHighRank) end
            if IsValid(sliderH) then sliderH:SetValue(pk.maxHighRank) end
        end
    end
    sliderP.OnValueChanged = function(_, v)
        pk.maxPerFac = math.Clamp(tonumber(v) or pk.maxPerFac, pMin, pMax)
        if IsValid(numP) then numP:SetValue(pk.maxPerFac) end
        local hi = math.min(hMax, pk.maxPerFac)
        if pk.maxHighRank > hi then
            pk.maxHighRank = math.Clamp(pk.maxHighRank, hMin, hi)
            if IsValid(numH) then numH:SetValue(pk.maxHighRank) end
            if IsValid(sliderH) then sliderH:SetValue(pk.maxHighRank) end
        end
    end

    y = y + R(70)
    local lblH = vgui.Create("DLabel", pickerFrame)
    lblH:SetPos(R(18), y)
    lblH:SetSize(W - R(36), R(20))
    lblH:SetFont("EVO_BF_Small")
    lblH:SetTextColor(COL.muted)
    lblH:SetText("MAX HAUTS GRADÉS / FACTION")

    numH = vgui.Create("DNumberWang", pickerFrame)
    numH:SetPos(R(18), y + R(24))
    numH:SetSize(R(120), R(28))
    numH:SetMin(hMin)
    numH:SetMax(hMax)
    numH:SetDecimals(0)
    numH:SetValue(pk.maxHighRank)
    hideLang(numH)

    sliderH = vgui.Create("DNumSlider", pickerFrame)
    sliderH:SetPos(R(150), y + R(18))
    sliderH:SetSize(W - R(168), R(40))
    sliderH:SetText("")
    sliderH:SetMin(hMin)
    sliderH:SetMax(hMax)
    sliderH:SetDecimals(0)
    sliderH:SetValue(pk.maxHighRank)
    sliderH.Label:SetVisible(false)
    sliderH.TextArea:SetVisible(false)
    hideLang(sliderH)

    numH.OnValueChanged = function(_, v)
        local hi = math.min(hMax, pk.maxPerFac or pDef)
        pk.maxHighRank = math.Clamp(tonumber(v) or pk.maxHighRank, hMin, hi)
        if IsValid(sliderH) then sliderH:SetValue(pk.maxHighRank) end
    end
    sliderH.OnValueChanged = function(_, v)
        local hi = math.min(hMax, pk.maxPerFac or pDef)
        pk.maxHighRank = math.Clamp(tonumber(v) or pk.maxHighRank, hMin, hi)
        if IsValid(numH) then numH:SetValue(pk.maxHighRank) end
    end

    timer.Simple(0, function()
        hideLang(num)
        hideLang(numF)
        hideLang(numP)
        hideLang(numH)
        hideLang(slider)
        hideLang(sliderF)
        hideLang(sliderP)
        hideLang(sliderH)
    end)

    y = y + R(90)
    local btnCancel = makeBtn(pickerFrame, "ANNULER", COL.btn, COL.btnH, closePicker)
    btnCancel:SetPos(R(18), y)
    btnCancel:SetSize(R(180), R(40))

    local btnOk = makeBtn(pickerFrame, "PROPOSER", Color(40, 90, 55), Color(55, 120, 70), function()
        if not IsValid(target) then closePicker() return end
        local r = math.Clamp(math.floor(pk.radius or defaultR), rMin, rMax)
        local drop = math.Clamp(math.floor(pk.floorDrop or dMin), dMin, dMax)
        local cap = math.Clamp(math.floor(pk.maxPerFac or pDef), pMin, pMax)
        local hg = math.Clamp(math.floor(pk.maxHighRank or hDef), hMin, math.min(hMax, cap))
        net.Start("EVO_BatailleFac:Propose")
            net.WriteEntity(target)
            net.WriteUInt(r, 16)
            net.WriteUInt(drop, 16)
            net.WriteUInt(cap, 8)
            net.WriteUInt(hg, 8)
        net.SendToServer()
        closePicker()
    end)
    btnOk:SetPos(W - R(18) - R(180), y)
    btnOk:SetSize(R(180), R(40))
end

-- ── HUD ─────────────────────────────────────────────────────────────────────

local function formatTimer(sec)
    sec = math.max(0, math.floor(sec))
    local m = math.floor(sec / 60)
    local s = sec % 60
    return string.format("%02d:%02d", m, s)
end

hook.Add("HUDPaint", "EVO_BF::Hud", function()
    if exitWarn.active then
        local left = math.max(0, exitWarn.endsAt - CurTime())
        if left <= 0 then
            exitWarn.active = false
        else
            draw.SimpleText(
                string.format("REVIENS DANS LA ZONE — %d", math.ceil(left)),
                "EVO_BF_Head",
                ScrW() * 0.5, ScrH() * 0.42,
                Color(255, 200, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
            )
        end
    end

    if not st.live then return end
    if not isNearHudZone() then return end

    local title = (CFG and CFG.HudTitle) or "BATAILLE DES FACTIONS"
    local openLabel
    local timerTxt
    if st.phase == 0 then
        local remain = math.max(0, st.joinRemain - math.floor(CurTime() - (st.recvAt or CurTime())))
        openLabel = "Zone ouverte :"
        timerTxt = formatTimer(remain)
    elseif st.phase == 1 then
        timerTxt = "EN ATTENTE"
    else
        timerTxt = "EN COURS"
    end

    local cap = tonumber(st.maxPerFac) or 0
    local hgCap = tonumber(st.maxHighRank)
    local function facLine(name, n)
        if cap > 0 then
            return string.format("%s  —  %d / %d", name, n or 0, cap)
        end
        return string.format("%s  —  %d", name, n or 0)
    end
    local lines = {
        facLine(st.facA ~= "" and st.facA or "?", st.nA),
        facLine(st.facB ~= "" and st.facB or "?", st.nB),
    }
    if hgCap ~= nil then
        lines[#lines + 1] = "Hauts gradés : max " .. tostring(hgCap) .. " / faction"
    end
    if EVO_BATAILLE_FAC.CanLocalCancel() then
        local left = math.max(0, math.ceil(cancelUntil - CurTime()))
        lines[#lines + 1] = "Annuler : menu C (" .. formatTimer(left) .. ")"
    end

    surface.SetFont("EVO_BF_Small")
    local tw = surface.GetTextSize(title)
    local openW = 0
    if openLabel then
        openW = select(1, surface.GetTextSize(openLabel))
    end
    surface.SetFont("EVO_BF_Head")
    local hw = surface.GetTextSize(timerTxt)
    local maxW = math.max(tw, hw)
    if openLabel then
        maxW = math.max(maxW, openW + R(10) + hw)
    end
    surface.SetFont("EVO_BF_Text")
    for _, ln in ipairs(lines) do
        maxW = math.max(maxW, surface.GetTextSize(ln))
    end

    local padX, padY = R(28), R(14)
    local lineH = R(26)
    local boxW = maxW + padX * 2
    local boxH = padY + R(22) + R(8) + R(34) + R(8) + (#lines * lineH) + padY
    local x = R(15)
    local y = R(12)

    surface.SetDrawColor(13, 14, 17, 230)
    surface.DrawRect(x, y, boxW, boxH)
    surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255)
    surface.DrawRect(x, y, R(3), boxH)

    local tx = x + padX
    local ty = y + padY
    draw.SimpleText(title, "EVO_BF_Small", tx, ty, COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    ty = ty + R(22) + R(4)
    local tCol = (st.phase == 2) and COL.yellow or COL.title
    if openLabel then
        draw.SimpleText(openLabel, "EVO_BF_Small", tx, ty + R(8), COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText(timerTxt, "EVO_BF_Head", tx + openW + R(10), ty, tCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    else
        draw.SimpleText(timerTxt, "EVO_BF_Head", tx, ty, tCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    ty = ty + R(34) + R(4)
    for _, ln in ipairs(lines) do
        draw.SimpleText(ln, "EVO_BF_Text", tx, ty, COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        ty = ty + lineH
    end
end)

-- ── Reward HUD (chest 3D + name) ────────────────────────────────────────────

local RARITY_COL = {
    common    = Color(200, 200, 200),
    uncommon  = Color(80, 200, 90),
    rare      = Color(110, 170, 255),
    epic      = Color(180, 90, 230),
    legendary = Color(255, 210, 80),
    mythic    = Color(255, 85, 85),
}

local RARITY_LABEL = {
    common    = "COMMUN",
    uncommon  = "PEU COMMUN",
    rare      = "RARE",
    epic      = "ÉPIQUE",
    legendary = "LÉGENDAIRE",
    mythic    = "MYTHIQUE",
}

local rewardHud = nil

local function closeRewardHud()
    if IsValid(rewardHud) then
        rewardHud:Remove()
    end
    rewardHud = nil
end

local function chestPreviewItem(chestId)
    local it = ITEMS and ITEMS[chestId]
    if it and isstring(it.model_path) and it.model_path ~= "" then
        return it
    end
    local chest = EVO_LOOT and EVO_LOOT.Chests and EVO_LOOT.Chests[chestId]
    if not chest then return it end
    return {
        name       = chest.name or chestId,
        rarity     = chest.rarity or "common",
        model_path = chest.model,
        bodygroup  = chest.bodygroup,
        icon       = chest.icon,
    }
end

local function showRewardHud(chestId)
    closeRewardHud()
    if not isstring(chestId) or chestId == "" then return end

    local it = chestPreviewItem(chestId)
    local chest = EVO_LOOT and EVO_LOOT.Chests and EVO_LOOT.Chests[chestId]
    local name = (chest and chest.name) or (it and it.name) or chestId
    local rarity = string.lower((chest and chest.rarity) or (it and it.rarity) or "common")
    local rCol = RARITY_COL[rarity] or COL.yellow
    local rLabel = RARITY_LABEL[rarity] or string.upper(rarity)
    local dur = tonumber(CFG and CFG.RewardHudDuration) or 8
    local born = RealTime()

    local W, H = R(440), R(520)
    local pnl = vgui.Create("DPanel")
    pnl:SetSize(W, H)
    pnl:SetPos(math.floor((ScrW() - W) * 0.5), math.floor((ScrH() - H) * 0.5))
    pnl:SetMouseInputEnabled(false)
    pnl:SetKeyboardInputEnabled(false)
    pnl:SetPaintBackground(false)
    rewardHud = pnl

    pnl.Paint = function(s, w, h)
        local now = RealTime()
        local elapsed = now - born
        local a = 1
        if elapsed < 0.4 then
            a = elapsed / 0.4
        elseif elapsed > dur - 1 then
            a = math.Clamp((dur - elapsed) / 1, 0, 1)
        end
        s:SetAlpha(math.floor(255 * a))

        surface.SetDrawColor(ColorAlpha(COL.bg, 245))
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(ColorAlpha(rCol, 255))
        surface.DrawRect(0, 0, R(3), h)
        surface.SetDrawColor(ColorAlpha(rCol, 70))
        surface.DrawOutlinedRect(0, 0, w, h)

        draw.SimpleText("VICTOIRE", "EVO_BF_Reward", w * 0.5, R(18), COL.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText("BATAILLE DES FACTIONS", "EVO_BF_Small", w * 0.5, R(66), COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(name, "EVO_BF_Head", w * 0.5, h - R(86), rCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(rLabel, "EVO_BF_Small", w * 0.5, h - R(50), COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText("Ajouté à l'inventaire", "EVO_BF_AnnSub", w * 0.5, h - R(28), COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end

    pnl.Think = function(s)
        if RealTime() - born >= dur then
            closeRewardHud()
        end
    end

    local holder = vgui.Create("DPanel", pnl)
    holder:SetPos(R(50), R(96))
    holder:SetSize(W - R(100), R(300))
    holder:SetMouseInputEnabled(false)
    holder:SetPaintBackground(false)

    if it and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel
        and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
        LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it, 28)
    elseif it and isstring(it.model_path) and it.model_path ~= "" then
        local mdl = vgui.Create("DModelPanel", holder)
        mdl:Dock(FILL)
        mdl:SetModel(it.model_path)
        mdl:SetFOV(28)
        mdl:SetAnimated(false)
        mdl:SetMouseInputEnabled(false)
        local ent = mdl:GetEntity()
        if IsValid(ent) and it.bodygroup ~= nil then
            local n = tonumber(it.bodygroup) or 0
            ent:SetBodygroup(0, n)
            ent:SetSkin(n)
        end
        mdl.LayoutEntity = function(_, e)
            if not IsValid(e) then return end
            e:SetAngles(Angle(0, RealTime() * 35, 0))
        end
    end

    local snd = (CFG and CFG.RewardHudSound) or "a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3"
    surface.PlaySound(snd)
end

net.Receive("EVO_BatailleFac:Reward", function()
    showRewardHud(net.ReadString())
end)
