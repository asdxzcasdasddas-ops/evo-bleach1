-- "addons\\evo_hollow_progression\\lua\\autorun\\sh_loader_hollow_progression.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[
    evo_hollow_progression
    ------------------------------------------------------------------
    Parcours de creation d'un personnage HOLLOW : au lieu d'aller dans le
    character creator, le joueur spawn en jeu en tant que "larva" (ame errante),
    progresse en tuant des PNJ (3 etapes), choisit 2 stats permanentes, devient
    Vasto Lorde, PUIS passe au creator pour finaliser son Arrancar.

    Design verrouille (cf memory project_hollow_progression) :
      - larva = VRAI perso Hollow sur un slot (combat/stats/HUD fonctionnent),
        marque par la table evo_hollow_progress -> reprise a la reconnexion.
      - les 2 stats choisies sont CONSERVEES sur l'Arrancar final.
      - style sans-katana = larva/vasto uniquement.
      - kill de n'importe quel PNJ (ncm_pnj_*) compte (hook OnNPCKilled).
      - fin = creer un NOUVEAU perso, copier les stats, supprimer la larva.

    SECURITE : intercepte le chemin CRITIQUE de creation de perso. Tout est
    derriere EVO_HollowProg.Config.Enabled (kill-switch) ET limite a la map Hueco.
--]]

if SERVER then
    AddCSLuaFile("evo_hollow_progression/sh_config.lua")
    AddCSLuaFile("evo_hollow_progression/sh_style.lua")
    AddCSLuaFile("evo_hollow_progression/cl_main.lua")

    include("evo_hollow_progression/sh_config.lua")
    include("evo_hollow_progression/sh_style.lua")
    include("evo_hollow_progression/sv_main.lua")
else
    include("evo_hollow_progression/sh_config.lua")
    include("evo_hollow_progression/sh_style.lua")
    include("evo_hollow_progression/cl_main.lua")
end
