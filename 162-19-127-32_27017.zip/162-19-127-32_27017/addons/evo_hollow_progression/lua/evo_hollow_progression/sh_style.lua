-- "addons\\evo_hollow_progression\\lua\\evo_hollow_progression\\sh_style.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- evo_hollow_progression : style de combat "Hollow1" (SANS KATANA) avec les VRAIES animations
-- Hollow (set "f606-grimmjow-*"). Deux morceaux complémentaires :
--   1) un HOLDTYPE "Hollow1" = anims de DÉPLACEMENT / SOL (idle, marche, course, saut,
--      atterrissage, idle au sol KO, relève, projeté) -> MUGEN.HoldTypes via les codes d'activité.
--   2) le STYLE "Hollow1" = anims de COMBAT (combos sol/air, parade, hit, stun, mort, saut, vol),
--      cloné de Commun1 (pour la structure/les timings) puis SURCHARGÉ avec les anims Grimmjow.
-- Enregistré dès que possible, avec filet Initialize/InitPostEntity (ordre de chargement).
--
-- Correspondance des 18 séquences fournies :
--   idle->idle | walk_f->marche | run->course | jump->saut | jump_land->atterrissage
--   jump_glide->chute/vol | ground_idle->KO au sol | ground_getup->relève | stunned_thrown_loop->projeté
--   attack_1/2/3->combo sol | attack_1_air/2_air->combo aérien | block_loop->parade
--   flinch1->coup encaissé (hit) | flinch4->stun / cassure de parade | death->mort

local HOLLOW_HOLDTYPE = "Hollow1"

-- Codes d'activité custom du système de holdtypes (cf. gamemode .../holdtypes/sh_holdtypes.lua).
local ACT_MP_LAND           = 9998
local ACT_MP_GROUND_IDLE    = 9997
local ACT_MP_GROUND_GETUP   = 9996
local ACT_MP_STUNNED_THROWN = 9989

-- 1) HOLDTYPE Hollow1 : DÉPLACEMENT + SOL.
local function RegisterHollowHoldType()
    if not (MUGEN and MUGEN.RegisterHoldType) then return false end
    if MUGEN.HoldTypes and MUGEN.HoldTypes[HOLLOW_HOLDTYPE] then return true end
    MUGEN.RegisterHoldType({
        HoldType     = HOLLOW_HOLDTYPE,
        Name         = "Hollow1 HoldType",
        BaseHoldType = "fist", -- sans arme
        Translations = {
            [ACT_MP_STAND_IDLE]     = { Sequence = "evo_y551qv5c25n2",                Weight = 1, Rate = 1 },
            [ACT_MP_RUN]            = { Sequence = "evo_gsls2weeuow3o",                 Weight = 1, Rate = 1 },
            [ACT_MP_WALK]           = { Sequence = "evo_liglkx56t4uex",                 Weight = 1, Rate = 1 }, -- marche de Rare2 (demande user ; remplace Rare1 evo_x07rsyob5wnxn / f606-grimmjow-walk_f)
            [ACT_MP_JUMP]           = { Sequence = "evo_ireza1hvbbcu0",                Weight = 1, Rate = 1 },
            [ACT_MP_LAND]           = { Sequence = "evo_jrredv6y3uwjrx",           Weight = 1, Rate = 1 },
            [ACT_MP_GROUND_IDLE]    = { Sequence = "evo_14k63zfh4gs4j6",         Weight = 1, Rate = 1 },
            [ACT_MP_GROUND_GETUP]   = { Sequence = "evo_x8igwfqppgouym",        Weight = 1, Rate = 1 },
            [ACT_MP_STUNNED_THROWN] = { Sequence = "evo_qc1uin1ymc03rcsmw", Weight = 1, Rate = 1 },
            -- Pas d'anim Grimmjow pour l'accroupi -> on garde le générique (comme Commun1).
            [ACT_MP_CROUCH_IDLE]    = { Sequence = "ytr__mwpassive crouch idle",        Weight = 1, Rate = 1 },
            [ACT_MP_CROUCHWALK]     = { Sequence = "ytr__mwpassive crouch walk",        Weight = 1, Rate = 1 },
        },
    })
    return true
end

-- 2) STYLE Hollow1 : COMBAT (cloné de Commun1 puis surchargé avec les anims Grimmjow).
local function RegisterHollowStyle()
    if not (EvoStyle and EvoStyle.StyleCombatCfg) then return false end
    -- On OVERWRITE TOUJOURS Hollow1 par le VRAI style Grimmjow (sRunHoldType="Hollow1", sans
    -- arme). Il y a un PLACEHOLDER (clone Commun1 posé par sh_config_combat.lua comme filet
    -- anti-crash) qu'il FAUT recouvrir, et l'ordre evo/ncm + les Lua refresh sont imprévisibles
    -- -> pas de bail "déjà fait" : idempotent, donc safe d'appeler plusieurs fois (hooks+timers).
    local base = EvoStyle.StyleCombatCfg["Commun1"]
    if not base then return false end
    if not (EvoStyle.MakeGroundCombo and EvoStyle.MakeAirCombo) then return false end

    local s = table.Copy(base) -- reprend la structure/les timings de base
    s.sWeaponModel = ""              -- Hollow = sans katana
    s.sIcon        = ""
    s.bNoTrail     = true            -- PAS de traînée d'épée (sans katana -> le sword_trail n'a aucun sens)
    s.sRunHoldType = HOLLOW_HOLDTYPE -- déplacement Hollow
    s.sFlyHoldType = HOLLOW_HOLDTYPE -- vol Hollow (worldmodel sans arme)
    s.tShikaiSlash = nil             -- pas de slash de shikai (style sans katana)

    -- Réactions / mort
    -- Hit encaissé (coup pris quand on subit des dégâts) = anim dédiée demandée par l'user
    -- (au lieu du sHitAnim de Commun1, et au lieu du flinch1 Grimmjow). Jouée sur la victime
    -- via pVictim:Animation(sHitAnim) (cf. citron_combat_weapons/init.lua + sorts).
    s.sHitAnim  = "evo_5lty8shtebls8gy"
    s.sStunAnim = "evo_csq2lu9vgrwbtrqv" -- stun (spell / cassure de parade subie) = autre flinch
    s.sDieAnim  = "evo_95kubqe4uj3pl"

    -- Vol spirituel (set Grimmjow : décollage = jump, plané/chute = jump_glide, pose = jump_land)
    s.tFlyAnims = {
        sTakeoff = "evo_ireza1hvbbcu0",
        sFly     = "evo_kv3rwto3a08g7oh",
        sEnd     = "evo_kv3rwto3a08g7oh",
        sFall    = "evo_kv3rwto3a08g7oh",
        sLanding = "evo_jrredv6y3uwjrx",
    }
    -- Petit saut
    s.tJumpAnims = {
        sIntro   = "evo_ireza1hvbbcu0",
        sJump    = "evo_ireza1hvbbcu0",
        sFall    = "evo_kv3rwto3a08g7oh",
        sLanding = "evo_jrredv6y3uwjrx",
    }
    -- Parade / blocage : pas d'anims dédiées start/end/perfect dans le set -> block_loop partout ;
    -- coup encaissé / cassure de garde -> flinch.
    s.tParadeAnims = {
        sParadeStart   = "evo_nparffki382m",
        sParadeLoop    = "evo_nparffki382m",
        sParadeEnd     = "evo_nparffki382m",
        sPerfectParade = "evo_csq2lu9vgrwbtrqv",  -- parade parfaite (réaction flinch)
        sBreakParade   = "evo_x95izvu25cmh3w",  -- cassure de garde = vrai coup encaissé
        sParadeHit     = "evo_9fce293r9wigy", -- hit reçu PENDANT la parade (demande user)
    }

    -- Combos SOL (mêmes timings que Commun1, anims Grimmjow). Sans tShikaiSlash (pas de katana).
    -- tHitSounds = EvoStyle.tMeleeHitSound : son de coup MAINS NUES (sans katana), comme les autres
    -- styles unarmed. Sinon MakeGroundCombo retombe sur le son de katana par défaut (tKatanaHitSound).
    local tHollowHitSfx = EvoStyle.tMeleeHitSound
    s.nMaxCombo = 3
    s.tCombo = {
        ["1"] = EvoStyle.MakeGroundCombo("evo_prp6lohm41dklg1", 15, 1, 1, { tHitSounds = tHollowHitSfx, tHitFrames = { 8 }, nContinueFrame = 20, nFPS = 30 }),
        ["2"] = EvoStyle.MakeGroundCombo("evo_t2o3dp6socrds", 15, 2, 1, { tHitSounds = tHollowHitSfx, tHitFrames = { 6 }, nContinueFrame = 20, nFPS = 30 }),
        ["3"] = EvoStyle.MakeGroundCombo("evo_0vuag3yq06ll11", 15, 3, 1, { tHitSounds = tHollowHitSfx, tHitFrames = { 8 }, nContinueFrame = 20, nFPS = 30 }),
    }
    -- Combos AÉRIENS (Grimmjow a 2 attaques en l'air).
    s.nMaxComboAir = 2
    s.tComboAir = {
        ["1"] = EvoStyle.MakeAirCombo("evo_u9k04w4twhnru", 15, 1, 1, { tHitSounds = tHollowHitSfx, tHitFrames = { 8 }, nContinueFrame = 20, nFPS = 30 }),
        ["2"] = EvoStyle.MakeAirCombo("evo_bz0n55w1ein9u1o", 15, 2, 1, { tHitSounds = tHollowHitSfx, tHitFrames = { 8 }, nContinueFrame = 20, nFPS = 30 }),
    }

    EvoStyle.StyleCombatCfg["Hollow1"] = s
    return true
end

local function RegisterHollowAll()
    local bHold  = RegisterHollowHoldType()
    local bStyle = RegisterHollowStyle()
    return bHold and bStyle
end

-- IMPORTANT : "Initialize"/"InitPostEntity" sont des hooks PARTAGÉS. Un callback de hook qui
-- renvoie une valeur NON-nil fait que hook.Call S'ARRÊTE et SAUTE les hooks suivants ; un
-- callback qui THROW idem. Or le combat (ncm_combat_system) enregistre EvoStyle_LoadAllSpells
-- sur "Initialize" lui aussi. Si notre hook tourne AVANT (l'ordre de chargement des addons est
-- ALPHABÉTIQUE : "evo_..." passe avant "ncm_..."), un retour non-nil/erreur ici tuait le
-- chargement des spells -> "Skill introuvable" sur TOUS les sorts. On isole donc : pcall +
-- AUCUN retour (nil), et on retire les hooks une fois le style posé.
local function RegisterHollowHook()
    local ok, done = pcall(RegisterHollowAll)
    if not ok then
        EVO_HollowProg._StyleErr = tostring(done) -- capturé pour le diagnostic evo_hollow_style
        ErrorNoHaltWithStack("[evo_hollow_progression] RegisterHollow: " .. tostring(done) .. "\n")
        return -- nil : ne casse pas la chaîne du hook
    end
    EVO_HollowProg._StyleErr = nil
    if done then
        hook.Remove("Initialize",     "EVO_HollowProg::RegisterStyle")
        hook.Remove("InitPostEntity", "EVO_HollowProg::RegisterStyle2")
    end
    -- retour nil dans tous les cas
end

local okInit, doneInit = pcall(RegisterHollowAll)
if not okInit then EVO_HollowProg._StyleErr = tostring(doneInit) end -- erreur de build capturée
if not (okInit and doneInit) then
    hook.Add("Initialize",     "EVO_HollowProg::RegisterStyle",  RegisterHollowHook)
    hook.Add("InitPostEntity", "EVO_HollowProg::RegisterStyle2", RegisterHollowHook)
end
-- Filet anti ordre-de-chargement / Lua refresh : les hooks Initialize/InitPostEntity peuvent
-- avoir DÉJÀ tiré (addon chargé tard / refresh) -> on retente via des timers qui s'exécutent
-- forcément APRÈS le chargement complet. RegisterHollowStyle OVERWRITE -> recouvre le placeholder.
if timer then
    timer.Simple(1, RegisterHollowHook)
    timer.Simple(6, RegisterHollowHook)
end
