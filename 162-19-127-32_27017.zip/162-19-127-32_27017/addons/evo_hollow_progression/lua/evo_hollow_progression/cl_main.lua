-- "addons\\evo_hollow_progression\\lua\\evo_hollow_progression\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- evo_hollow_progression : client (HUD, transition Vasto, dézoom évolution, interception creator)
EVO_HollowProg = EVO_HollowProg or {}
local CFG = EVO_HollowProg.Config

EVO_HollowProg.State = EVO_HollowProg.State or { active = false }

-- DA EVO : carte sombre + accent rouge unique.
local COL_BG     = Color(13, 14, 17, 230)              -- (DA Atelier 07/07) overlay HUD : plaque translucide
local COL_CARD   = Color(17, 18, 22, 235)              -- (DA Atelier 07/07) piste plate des barres de progression
local COL_ACCENT = Color(207, 68, 78)
local COL_TEXT   = Color(235, 235, 240)
local COL_SUB    = Color(160, 160, 170)
local COL_STEEL  = Color(146, 152, 161, 40)            -- (DA Atelier 07/07) liseré acier

-- Helpers responsives (échelle 1920x1080) pour caler le HUD comme les autres quêtes.
local function RX(n) return (MUGEN and MUGEN.ResponsiveX and MUGEN.ResponsiveX(n)) or (n * ScrW() / 1920) end
local function RY(n) return (MUGEN and MUGEN.ResponsiveY and MUGEN.ResponsiveY(n)) or (n * ScrH() / 1080) end

-- Polices RESPONSIVES : taille calée sur la HAUTEUR d'écran (comme le cadre via RY) et RECRÉÉES
-- au changement de résolution. Avant : tailles FIXES (30/22/21 px) -> le cadre se mettait à
-- l'échelle (RX/RY) mais PAS le texte -> « pas responsive » (texte minuscule en 1440p/4K, ou
-- débordant du cadre en 768p). FS() borne à 11 px mini pour rester lisible.
local function buildFonts()
    local function FS(n) return math.max(11, math.floor(RY(n))) end
    -- (DA Atelier 07/07) titres = Bebas Neue 400 (jamais gras), corps = Roboto ; tailles inchangées.
    surface.CreateFont("EVO_Hollow_Title", { font = "Bebas Neue", size = FS(30), weight = 400, extended = true, antialias = true })
    surface.CreateFont("EVO_Hollow_Head",  { font = "Bebas Neue", size = FS(24), weight = 400, extended = true, antialias = true })
    surface.CreateFont("EVO_Hollow_Sub",   { font = "Roboto",     size = FS(22), weight = 500, extended = true, antialias = true })
    surface.CreateFont("EVO_Hollow_Opt",   { font = "Roboto",     size = FS(21), weight = 600, extended = true, antialias = true })
    -- Indice "comment dévorer" : police DÉDIÉE plus petite que le sous-titre (FS(22)) et
    -- responsive (FS = mise à l'échelle hauteur), pour tenir sur une ligne sous "Âmes dévorées".
    surface.CreateFont("EVO_Hollow_Hint",  { font = "Roboto",     size = FS(14), weight = 500, extended = true, antialias = true })
end
buildFonts()
hook.Add("OnScreenSizeChanged", "EVO_HollowProg::Fonts", buildFonts)

-- ────────────────────────────────────────────────────────────
-- INTERCEPTION (appelee depuis lzy_character selectFaction)
-- ────────────────────────────────────────────────────────────
function EVO_HollowProg.ShouldInterceptHollow()
    return EVO_HollowProg.IsActiveMap() and not EVO_HollowProg._Finalizing
end

function EVO_HollowProg.BeginFromCreator(panel)
    -- Loading optimiste : feedback immédiat au clic (le serveur le confirme aussi).
    if LZY_SetLoadingScreen then LZY_SetLoadingScreen(true) end
    -- Ferme proprement le creator ET la scène HUB (sinon hooks HUD/caméra restent actifs).
    if NCM_CHAR_SELECT and isfunction(NCM_CHAR_SELECT.StopScene) then
        NCM_CHAR_SELECT.StopScene()
    end
    if LZY_CharacterCreator_ForceClose then
        LZY_CharacterCreator_ForceClose()
    elseif IsValid(panel) and panel.Close then
        panel:Close()
    end
    net.Start("EVO:HollowProg:Begin") net.SendToServer()
end

-- ────────────────────────────────────────────────────────────
-- ETAT + HUD
-- ────────────────────────────────────────────────────────────
net.Receive("EVO:HollowProg:State", function()
    local active = net.ReadBool()
    if not active then
        EVO_HollowProg.State = { active = false }
        return
    end
    EVO_HollowProg.State = {
        active = true,
        mode   = net.ReadString(),
        stage  = net.ReadUInt(4),
        kills  = net.ReadUInt(10),
        need   = net.ReadUInt(10),
    }
end)

-- Filet : après le chargement / spawn, redemander l'état HUD + réparer le modèle client.
hook.Add("EVO:Client:LoadingScreenClosed", "EVO_HollowProg::RequestState", function()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    if lp:GetEvoNWBool("EVO_IsLarva", false) or (EVO_HollowProg.State and EVO_HollowProg.State.active) then
        net.Start("EVO:HollowProg:RequestState") net.SendToServer()
        if LZY_Character_ScheduleClientModelRepairs then
            LZY_Character_ScheduleClientModelRepairs({ forceRebuild = true })
        end
    end
end)

-- Bandeau "PROTECTION PVP" en HAUT (centre), affiché tant qu'on incarne un Hollow (larva) : rappelle
-- CLAIREMENT qu'AUCUN dégât n'a lieu entre JOUEURS (on ne peut ni blesser ni être blessé ; les PNJ
-- restent normaux). Gardé sur EVO_IsLarva + CFG.PvpProtection -> si un admin coupe la protection
-- (CFG.PvpProtection=false), le bandeau disparaît. Caché pendant la finalisation Arrancar.
hook.Add("HUDPaint", "EVO_HollowProg::PvpProtectBanner", function()
    if not CFG.PvpProtection then return end
    local ply = LocalPlayer()
    if not (IsValid(ply) and ply:GetEvoNWBool("EVO_IsLarva", false)) then return end
    -- Animateur en mode hollow : la protection PvP est DÉSACTIVÉE pour lui -> pas de bandeau (sinon
    -- il afficherait "tu ne peux ni blesser ni être blessé" alors que le PvP est bien actif).
    if ply:GetEvoNWBool("EVO_AnimatorHollow", false) then return end
    if EVO_HollowProg._Finalizing then return end

    local sTitle = "PROTECTION PVP"
    local sSub   = "Tu ne peux ni blesser ni être blessé par les joueurs"

    surface.SetFont("EVO_Hollow_Head")
    local tw = surface.GetTextSize(sTitle)
    surface.SetFont("EVO_Hollow_Opt")
    local sw = surface.GetTextSize(sSub)

    local padX = RX(24)
    local w = math.max(tw, sw) + padX * 2
    local h = RY(60)
    local x = (ScrW() - w) * 0.5
    -- Sous la BOUSSOLE (bleach_compass, ~4% du haut d'écran) : même dégagement que le HUD
    -- spectateur de la Fosse (demande user 07/18, « pas par-dessus le compass »).
    local y = math.Round(ScrH() * 0.09)
    local cx = x + w * 0.5

    -- (DA Atelier 07/07) plaque Atelier : coin bas-droit coupé + liseré acier ; fallback rect carré.
    if EVO_UI and EVO_UI.PaintCut then
        local pts = EVO_UI.PaintCut(x, y, w, h, COL_BG, RY(10), "br")
        if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, COL_STEEL) end
    else
        draw.RoundedBox(0, x, y, w, h, COL_BG)                  -- carte sombre DA EVO (carrée)
    end
    surface.SetDrawColor(COL_ACCENT)
    surface.DrawRect(x, y, w, math.max(2, RY(2)))               -- liseré accent rouge en haut (2px DA)
    draw.SimpleText(sTitle, "EVO_Hollow_Head", cx, y + RY(21), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText(sSub,   "EVO_Hollow_Opt",  cx, y + RY(42), COL_SUB,    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("HUDPaint", "EVO_HollowProg::HUD", function()
    local st = EVO_HollowProg.State
    if not (st and st.active) or st.mode == "finalizing" then return end
    if EVO_HollowProg._Finalizing then return end

    -- En HAUT À GAUCHE, plus grand, comme les autres quêtes (tracker à 15,15).
    -- Pendant la chasse on ajoute une ligne "comment dévorer" -> carte un peu plus haute.
    local bHint = st.mode ~= "vasto" and (st.need or 0) > 0
    local w, h = RX(380), RY(bHint and 156 or 104)
    local x, y = RX(15), RY(15)
    -- (DA Atelier 07/07) carte tracker : coin bas-droit coupé + liseré acier ; fallback rect carré.
    if EVO_UI and EVO_UI.PaintCut then
        local pts = EVO_UI.PaintCut(x, y, w, h, COL_BG, RY(12), "br")
        if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, COL_STEEL) end
    else
        draw.RoundedBox(0, x, y, w, h, COL_BG)
    end
    surface.SetDrawColor(COL_ACCENT)
    surface.DrawRect(x, y, math.max(2, RX(2)), h) -- (DA Atelier 07/07) barre accent gauche 2px (signature DA)

    local title, sub
    if st.mode == "vasto" then
        title = "Vasto Lorde"
        if EVO_HollowProg._canFinalize then
            sub = "Appuie sur [" .. string.upper(input.GetKeyName(CFG.FinalizeKey or KEY_F) or "f") .. "] pour devenir Arrancar"
        else
            sub = "Ta forme se concrétise..."
        end
    else
        title = "Évolution Hollow : Étape " .. st.stage .. "/" .. CFG.MaxStage
        sub = "Âmes dévorées : " .. st.kills .. " / " .. st.need
    end
    draw.SimpleText(title, "EVO_Hollow_Title", x + RX(20), y + RY(16), COL_TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText(sub,   "EVO_Hollow_Sub",   x + RX(20), y + RY(52), COL_SUB,  TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    -- "Comment" PRÉCIS : on ne tue pas, on DÉVORE -> tuer un Hollow puis [E] sur son cadavre.
    if bHint then
        local sEat = string.upper(input.GetKeyName(CFG.EatKey or KEY_E) or "e")
        draw.SimpleText("Tue un Hollow puis [" .. sEat .. "] sur son corps pour le dévorer",
            "EVO_Hollow_Hint", x + RX(20), y + RY(84), COL_SUB, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        local sF = string.upper(input.GetKeyName(CFG.FinalizeKey or KEY_F) or "f")
        local bArme = (EVO_HollowProg._skipArmeJusqua or 0) > RealTime()
        draw.SimpleText(bArme and ("Appuie encore sur [" .. sF .. "] pour passer à la création d'Arrancar")
            or ("Appuie 2 fois sur [" .. sF .. "] pour passer l'évolution"),
            "EVO_Hollow_Hint", x + RX(20), y + RY(108), bArme and COL_TEXT or COL_SUB, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    -- barre de progression pleine largeur en bas (mode larva)
    if st.mode ~= "vasto" and (st.need or 0) > 0 then
        local bw, bh = w - RX(40), RY(8)
        local bx, by = x + RX(20), y + h - RY(20)
        draw.RoundedBox(0, bx, by, bw, bh, COL_CARD)
        local frac = math.Clamp(st.kills / st.need, 0, 1)
        draw.RoundedBox(0, bx, by, bw * frac, bh, COL_ACCENT)
    end
end)

-- ────────────────────────────────────────────────────────────
-- DIAGNOSTIC CLIENT (in-game) : état RÉEL du modèle joueur local. Sert à trancher
-- "composite arrancar monté" vs "modèle créature brut" sans deviner. Tape evo_hollow_cl en jeu.
-- ────────────────────────────────────────────────────────────
concommand.Add("evo_hollow_cl", function()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local A, B = Color(180, 120, 255), Color(235, 235, 240)
    local function P(s) MsgC(A, "[HollowCL] ", B, s, "\n") end
    P("model = " .. tostring(lp:GetModel()))
    P(string.format("skin = %s | scale = %.2f | HollowRaw = %s | IsLarva = %s",
        tostring(lp:GetSkin()), lp:GetModelScale() or 1,
        tostring(lp:GetEvoNWBool("EVO_HollowRaw", false)), tostring(lp:GetEvoNWBool("EVO_IsLarva", false))))
    -- LE point clé : si PlayerModelParts existe -> le COMPOSITE (corps arrancar bonemergé) est
    -- monté = mauvais (devrait être "non" pour une larva = modèle brut).
    P("composite PlayerModelParts = " .. (lp.PlayerModelParts and "OUI (= COMPOSITE monté, à corriger)" or "non (modèle brut OK)"))
    P("RenderOverride = " .. (lp.RenderOverride and "défini" or "nil"))
    for i = 0, lp:GetNumBodyGroups() - 1 do
        P(string.format("  bg[%d] %s = %d / %d", i, tostring(lp:GetBodygroupName(i)), lp:GetBodygroup(i), lp:GetBodygroupCount(i)))
    end
end)

-- DIAGNOSTIC : règle UN bodygroup (par nom) à une valeur, pour isoler ce qui contrôle ailes/queue.
--   evo_hollow_bgtest body 0   (puis 1, 2)   -> le body controle-t-il les ailes/queue ?
--   evo_hollow_bgtest ailes 0  (puis 1, 2)   -> y a-t-il une variante VIDE ?
--   evo_hollow_bgtest all 0                  -> met body+ailes+tails à 0 d'un coup (forme la + nue)
-- Dis-moi, pour CHAQUE test, ce que tu vois (ailes ? queue ? rien ?).
concommand.Add("evo_hollow_bgtest", function(_, _, args)
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local A, B = Color(180, 120, 255), Color(235, 235, 240)
    local name, v = string.lower(tostring(args[1] or "")), tonumber(args[2])
    if name == "" or not v then
        MsgC(A, "[HollowCL] ", B, "Usage : evo_hollow_bgtest <body|ailes|tails|masque|all> <valeur 0..2> — ex: evo_hollow_bgtest body 0", "\n")
        return
    end
    local targets = (name == "all") and { "body", "ailes", "tails" } or { name }
    for _, nm in ipairs(targets) do
        local i = lp:FindBodygroupByName(nm)
        if i and i >= 0 then
            lp:SetBodygroup(i, v)
            MsgC(A, "[HollowCL] ", B, nm .. " (bg " .. i .. ") = " .. v, "\n")
        else
            MsgC(A, "[HollowCL] ", B, "bodygroup '" .. nm .. "' introuvable.", "\n")
        end
    end
end)

-- ────────────────────────────────────────────────────────────
-- TÊTE NEUTRE in-game : sans ça le moteur oriente la tête/buste de la larva vers l'AIM
-- (pose params head_yaw/head_pitch/aim_yaw/aim_pitch) -> ça DÉFORME la tête du modèle
-- créature (« tête bizarre »). Le portrait HUD, lui, est rendu en séquence 0 STATIQUE
-- (pose params non pilotés) -> il reste correct : d'où « HUD bon / in-game bizarre ».
-- On neutralise donc ces pose params à chaque rendu de larva : la tête suit le corps,
-- comme dans le HUD. (Même technique que ncm_petit_saut NeutralizeHead.)
-- ────────────────────────────────────────────────────────────
local HOLLOW_HEAD_PARAMS = { "head_yaw", "head_pitch", "aim_yaw", "aim_pitch" }
hook.Add("PrePlayerDraw", "EVO_HollowProg::NeutralHead", function(ply)
    if not (IsValid(ply) and ply:GetEvoNWBool("EVO_HollowRaw", false)) then return end
    for i = 1, #HOLLOW_HEAD_PARAMS do
        local id = ply:LookupPoseParameter(HOLLOW_HEAD_PARAMS[i])
        if id and id >= 0 then ply:SetPoseParameter(HOLLOW_HEAD_PARAMS[i], 0) end
    end
    ply:InvalidateBoneCache()
end)

-- ────────────────────────────────────────────────────────────
-- MANGER (touche E) : dévorer un PNJ ncm_pnj_* devant soi -> progression
-- ────────────────────────────────────────────────────────────
local function CanEatNow()
    local st = EVO_HollowProg.State
    if st and st.active and st.mode == "larva" then return true end
    -- Filet : State HUD peut être désync juste après spawn/reconnect alors que le NWBool larva
    -- est déjà vrai — sinon kill OK mais [E] Dévorer jamais proposé.
    if st and st.active and st.mode and st.mode ~= "larva" then return false end
    local lp = LocalPlayer()
    return IsValid(lp) and lp:GetEvoNWBool("EVO_IsLarva", false)
end

local function FindEatTarget()
    local lp = LocalPlayer()
    if not IsValid(lp) then return nil end
    local range = tonumber(CFG.EatRange) or 170
    local closeRange = math.min(range, 90) -- melee : souvent debout SUR l'âme après le kill
    local function isEatable(e)
        return IsValid(e) and e:GetEvoNWBool("EVO_EatableCorpse", false) -- âme laissée par un PNJ tué (CFG.SoulModel)
    end
    -- 1) ce qu'on vise : MASK_SOLID rate COLLISION_GROUP_DEBRIS + prop_dynamic peu solide.
    --    On accepte l'entité touchée OU on cherche une âme près du point d'impact.
    local eye, aim = lp:EyePos(), lp:GetAimVector()
    local tr = util.TraceLine({
        start = eye, endpos = eye + aim * range, filter = lp,
        mask = bit.bor(MASK_SOLID, CONTENTS_DEBRIS),
    })
    if isEatable(tr.Entity) then return tr.Entity end
    if tr.Hit then
        local hitBest, hitBestD = nil, 48 * 48
        for _, e in ipairs(ents.FindInSphere(tr.HitPos, 48)) do
            if isEatable(e) then
                local d = tr.HitPos:DistToSqr(e:WorldSpaceCenter())
                if d < hitBestD then hitBest, hitBestD = e, d end
            end
        end
        if IsValid(hitBest) then return hitBest end
    end
    -- 2) plus proche dans le rayon. À bout portant (melee sur le cadavre) : PAS de cône de
    --    visée — aim:Dot(dir) échoue quand on est pile dessus (dir ~ verticale / nulle) alors
    --    que le joueur regarde horizontalement. Au-delà : cône assoupli (0.25 ≈ 75°).
    local origin = lp:GetPos()
    local best, bestD = nil, range * range
    local closeBest, closeBestD = nil, closeRange * closeRange
    for _, e in ipairs(ents.FindInSphere(origin, range)) do
        if not isEatable(e) then continue end
        local center = e:WorldSpaceCenter()
        local d = origin:DistToSqr(center)
        if d < closeBestD then
            closeBest, closeBestD = e, d
        end
        if d < bestD then
            local to = center - eye
            local len = to:Length()
            if len < 1 or aim:Dot(to / len) > 0.25 then
                best, bestD = e, d
            end
        end
    end
    return closeBest or best
end

local _nextEatScan = 0
hook.Add("Think", "EVO_HollowProg::EatScan", function()
    if not CanEatNow() then EVO_HollowProg._eatTarget = nil return end
    local t = SysTime()
    if t < _nextEatScan then return end
    _nextEatScan = t + 0.15
    EVO_HollowProg._eatTarget = FindEatTarget()
end)

local function IsEating()
    return EVO_HollowProg._eatUntil and EVO_HollowProg._eatUntil > SysTime()
end

hook.Add("PlayerButtonDown", "EVO_HollowProg::EatKey", function(p, btn)
    if p ~= LocalPlayer() then return end -- regle projet : filtrer le 1er arg de PlayerButtonDown
    if btn ~= (CFG.EatKey or KEY_E) then return end
    if not CanEatNow() or IsEating() then return end
    local target = FindEatTarget()
    if not IsValid(target) then return end
    net.Start("EVO:HollowProg:Eat") net.WriteEntity(target) net.SendToServer()
end)

-- Debut de canalisation (le manger dure EatDuration) : barre de progression.
net.Receive("EVO:HollowProg:EatStart", function()
    local dur = net.ReadFloat()
    EVO_HollowProg._eatDur = dur
    EVO_HollowProg._eatUntil = SysTime() + dur
end)

-- Invite "[E] Dévorer" + barre de "Dévoration..." pendant la canalisation.
hook.Add("HUDPaint", "EVO_HollowProg::EatPrompt", function()
    if not CanEatNow() then return end
    if IsEating() then
        local rem = EVO_HollowProg._eatUntil - SysTime()
        local dur = EVO_HollowProg._eatDur or 3
        local frac = 1 - math.Clamp(rem / dur, 0, 1)
        local w, h = RX(280), RY(16)
        local x, y = ScrW() * 0.5 - w * 0.5, ScrH() * 0.5 + RY(60)
        -- (DA Atelier 07/07) piste plate carrée + remplissage accent plat.
        draw.RoundedBox(0, x, y, w, h, COL_CARD)
        draw.RoundedBox(0, x, y, w * frac, h, COL_ACCENT)
        draw.SimpleText("Dévoration...", "EVO_Hollow_Sub", ScrW() * 0.5, y - RY(6), COL_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        return
    end
    if IsValid(EVO_HollowProg._eatTarget) then
        -- Style d'invite unifié (EVO_ZonePrompt) ; l'ancien texte reste en repli.
        if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
            EVO_ZonePrompt.Draw2D(ScrW() * 0.5, ScrH() * 0.5 + RY(64), "", "Dévorer", "E")
        else
            draw.SimpleText("[E] Dévorer", "EVO_Hollow_Opt", ScrW() * 0.5, ScrH() * 0.5 + RY(64), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end)

-- ────────────────────────────────────────────────────────────
-- WAYPOINT : DIRIGE la larva vers le Hollow (ncm_pnj_*) VIVANT le plus proche à TUER (il faut un
-- cadavre à dévorer pour progresser). Visible UNIQUEMENT pendant la chasse (étape à compléter) ET
-- tant qu'aucun cadavre dévorable n'est déjà à portée (sinon l'EatPrompt "[E] Dévorer" suffit).
-- ────────────────────────────────────────────────────────────
local function NeedsHunt()
    local st = EVO_HollowProg.State
    return st and st.active and st.mode == "larva"
        and (st.need or 0) > 0 and (st.kills or 0) < st.need
end

-- Scan throttlé (0.5 s) du PNJ hollow vivant le plus proche -> cache. ents.FindByClass("ncm_pnj_*")
-- est O(entités), donc throttlé ; re-scan immédiat si le PNJ caché meurt/disparaît.
local _nextHollowScan, _cachedHollow = 0, nil
hook.Add("Think", "EVO_HollowProg::HollowScan", function()
    if not NeedsHunt() or IsValid(EVO_HollowProg._eatTarget) then _cachedHollow = nil return end
    local t = SysTime()
    if t < _nextHollowScan and IsValid(_cachedHollow) and _cachedHollow:Health() > 0 then return end
    _nextHollowScan = t + 0.5
    local lp = LocalPlayer()
    if not IsValid(lp) then _cachedHollow = nil return end
    local best, bestD = nil, math.huge
    for _, e in ipairs(ents.FindByClass((CFG.EatNpcPrefix or "ncm_pnj_") .. "*")) do
        -- On IGNORE les PNJ de quête / progression (ncm_isQuestGiver / ncm_isProgressionNPC) :
        -- le waypoint "Dévore ce Hollow" ne doit viser QUE des Hollows chassables, pas le
        -- Maître d'Armes & co (PNJ statiques non tuables).
        if IsValid(e) and e:Health() > 0 and not EVO_HollowProg.IsNonHuntableNpc(e) then
            local d = lp:GetPos():DistToSqr(e:GetPos())
            if d < bestD then best, bestD = e, d end
        end
    end
    _cachedHollow = best
end)

-- Ramène un vecteur (depuis le centre écran) au bord d'un rect à marge -> indicateur DIRECTIONNEL
-- quand la cible est hors-champ / derrière.
local function HollowEdgeClamp(dx, dy)
    local hw, hh = ScrW() * 0.5 - RX(55), ScrH() * 0.5 - RY(80)
    local ax, ay = math.abs(dx), math.abs(dy)
    if ax < 0.001 and ay < 0.001 then return ScrW() * 0.5, ScrH() * 0.5 - hh end
    local s = math.min(ax > 0 and hw / ax or math.huge, ay > 0 and hh / ay or math.huge)
    return ScrW() * 0.5 + dx * s, ScrH() * 0.5 + dy * s
end

hook.Add("HUDPaint", "EVO_HollowProg::HollowWaypoint", function()
    if not NeedsHunt() or IsValid(EVO_HollowProg._eatTarget) then return end
    local npc = _cachedHollow
    if not IsValid(npc) then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    -- ROUTAGE PAR TÉLÉPORTEUR (MÊME logique que les quêtes, NCM_Quete_RouteWaypoint) : si le Hollow
    -- à dévorer est dans une AUTRE zone (reliée par téléporteur), on pointe d'abord le pad du
    -- téléporteur le plus proche ("prends le téléporteur") au lieu de viser à travers les murs ;
    -- une fois dans la bonne zone, on pointe le Hollow. Fallback DIRECT si le routeur n'est pas chargé.
    local vRaw = npc:GetPos() + Vector(0, 0, 72)
    local vTarget, sLabel, bIsTP = vRaw, "Dévore ce Hollow", false
    if NCM_Quete_RouteWaypoint then
        local rPos, rLabel, rTP = NCM_Quete_RouteWaypoint(vRaw, "Dévore ce Hollow")
        if rPos then vTarget, sLabel, bIsTP = rPos, rLabel, rTP and true or false end
    end

    local sc = vTarget:ToScreen()
    local onScreen = sc.visible and sc.x >= RX(20) and sc.x <= ScrW() - RX(20)
        and sc.y >= RY(20) and sc.y <= ScrH() - RY(20)
    local mx, my, bEdge
    if onScreen then
        mx, my, bEdge = sc.x, sc.y, false
    else
        local dx, dy = sc.x - ScrW() * 0.5, sc.y - ScrH() * 0.5
        if not sc.visible then dx, dy = -dx, -dy end -- derrière : inverser la direction
        mx, my = HollowEdgeClamp(dx, dy)
        bEdge = true
    end

    local dist = math.floor(lp:GetPos():Distance(vTarget) / 52.5) -- ~ mètres (52.5 u/m source)
    local s = RY(9)
    surface.SetDrawColor(COL_ACCENT)
    draw.NoTexture()
    surface.DrawPoly({ { x = mx, y = my - s }, { x = mx + s, y = my }, { x = mx, y = my + s }, { x = mx - s, y = my } })
    if not bEdge then
        draw.SimpleText(sLabel, "EVO_Hollow_Opt", mx, my - s - RY(13), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        -- Quand on guide vers un téléporteur intermédiaire, on rappelle l'objectif final.
        if bIsTP then
            draw.SimpleText("→ Dévore un Hollow", "EVO_Hollow_Hint", mx, my - s - RY(28), COL_SUB, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    draw.SimpleText(dist .. " m", "EVO_Hollow_Opt", mx, my + s + RY(11), COL_SUB, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- ────────────────────────────────────────────────────────────
-- SPELL larva : touche -> cast ; "rond vide" au sol à la réception
-- ────────────────────────────────────────────────────────────
hook.Add("PlayerButtonDown", "EVO_HollowProg::SpellKey", function(p, btn)
    if p ~= LocalPlayer() then return end -- regle projet : filtrer le 1er arg de PlayerButtonDown
    if not CFG.SpellEnabled then return end -- sort R DÉSACTIVÉ (demande user) : R ne fait rien
    if btn ~= (CFG.SpellKey or KEY_R) then return end
    local st = EVO_HollowProg.State
    if not (st and st.active and (st.mode == "larva" or st.mode == "vasto")) then return end
    net.Start("EVO:HollowProg:CastSpell") net.SendToServer()
end)

local _spellRings = {}
net.Receive("EVO:HollowProg:SpellRing", function()
    local pos    = net.ReadVector()
    local radius = net.ReadFloat()
    _spellRings[#_spellRings + 1] = { pos = pos, radius = radius, t0 = SysTime() }
end)

hook.Add("PostDrawTranslucentRenderables", "EVO_HollowProg::SpellRing", function(_, bSky)
    if bSky or #_spellRings == 0 then return end
    render.SetColorMaterial()
    for i = #_spellRings, 1, -1 do
        local ring = _spellRings[i]
        local age = SysTime() - ring.t0
        if age > 1.2 then
            table.remove(_spellRings, i)
        else
            local a = 1 - (age / 1.2)
            local col = Color(207, 68, 78, math.floor(220 * a))
            local base = ring.pos + Vector(0, 0, 4)
            local segs, prev = 48, nil
            for s = 0, segs do
                local ang = (s / segs) * math.pi * 2
                local pt = base + Vector(math.cos(ang) * ring.radius, math.sin(ang) * ring.radius, 0)
                if prev then render.DrawLine(prev, pt, col, false) end
                prev = pt
            end
        end
    end
end)

-- ────────────────────────────────────────────────────────────
-- TRANSITION VASTO (fx placeholder : flash + son)
-- ────────────────────────────────────────────────────────────
-- Eclair lumineux blanc + son, joué à CHAQUE amélioration (stat + Vasto).
net.Receive("EVO:HollowProg:UpgradeFlash", function()
    local dur = net.ReadFloat()
    if dur <= 0 then dur = 2.2 end
    surface.PlaySound("ambient/levels/labs/electric_explosion1.wav")
    local t0 = SysTime()
    hook.Add("HUDPaint", "EVO_HollowProg::UpgradeFlash", function()
        local a = 1 - math.Clamp((SysTime() - t0) / dur, 0, 1)
        if a <= 0 then hook.Remove("HUDPaint", "EVO_HollowProg::UpgradeFlash") return end
        surface.SetDrawColor(255, 255, 255, math.floor(a * 255))
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end)
end)

-- Post-Vasto : invite NON-BLOQUANTE dans le HUD de quête (pas de popup). On appuie sur
-- la touche quand on veut pour devenir Arrancar ; le jeu continue normalement.
net.Receive("EVO:HollowProg:VastoButton", function()
    EVO_HollowProg._canFinalize = true
end)

local FINALIZE_CLIENT_REPLY_TIMEOUT = 15

local function ArmFinalizeClientDeadline()
    EVO_HollowProg._FinalizeClientDeadline = RealTime() + FINALIZE_CLIENT_REPLY_TIMEOUT
end

hook.Add("PlayerButtonDown", "EVO_HollowProg::FinalizeKey", function(p, btn)
    if p ~= LocalPlayer() then return end -- regle projet : filtrer le 1er arg
    if btn ~= (CFG.FinalizeKey or KEY_F) then return end
    if not EVO_HollowProg._canFinalize then
        -- PASSER L'ÉVOLUTION (10/11, user, nouveaux joueurs compris) : larve en chasse, double
        -- appui en 3 s (anti fausse manip) -> même finalisation que le Vasto (créateur d'Arrancar).
        local st = EVO_HollowProg.State
        if not (st and st.active and st.mode ~= "vasto" and st.mode ~= "finalizing") or EVO_HollowProg._Finalizing then return end
        if gui.IsGameUIVisible() or vgui.GetKeyboardFocus() then return end
        if (EVO_HollowProg._skipArmeJusqua or 0) < RealTime() then
            EVO_HollowProg._skipArmeJusqua = RealTime() + 3
            return
        end
        EVO_HollowProg._skipArmeJusqua = nil
    end
    EVO_HollowProg._canFinalize = false
    -- IMMÉDIAT : avant la réponse serveur / PutInLimbo. Sinon EVO_HollowRaw=false
    -- peut répliquer avant OpenFinalizeCreator → Sync/RequestAllPM = freeze client.
    EVO_HollowProg._Finalizing = true
    EVO_HollowProg._FinalizePending = false
    ArmFinalizeClientDeadline()
    EVO_HollowProg.State = { active = false }
    local lp = LocalPlayer()
    if IsValid(lp) and LZY_Character_ClearCachedPlayerModel then
        LZY_Character_ClearCachedPlayerModel(lp)
    elseif IsValid(lp) and LZY_Character_DestroyPlayerClientModels then
        LZY_Character_DestroyPlayerClientModels(lp)
    end
    net.Start("EVO:HollowProg:Finalize") net.SendToServer()
end)

-- ────────────────────────────────────────────────────────────
-- FINALISATION : ouvre le creator (mode normal pour Hollow, transfert des stats serveur)
-- ────────────────────────────────────────────────────────────
local function OpenFinalizeCreatorClient(a, b)
    local resumeData = istable(b) and b or (istable(a) and a or nil)
    -- Flag IMMÉDIAT : doit précéder toute réplication PutInLimbo (HollowRaw false).
    EVO_HollowProg._Finalizing = true
    EVO_HollowProg._FinalizePending = false
    ArmFinalizeClientDeadline()
    EVO_HollowProg._FinalizeResumeData = resumeData
    EVO_HollowProg._canFinalize = false
    EVO_HollowProg.State = { active = false }
    -- Coupe tout rebuild modèle larva résiduel avant d'ouvrir le creator.
    local lp = LocalPlayer()
    if IsValid(lp) then
        if LZY_Character_ClearCachedPlayerModel then
            LZY_Character_ClearCachedPlayerModel(lp)
        elseif LZY_Character_DestroyPlayerClientModels then
            LZY_Character_DestroyPlayerClientModels(lp)
        elseif lp.RenderOverride then
            lp.RenderOverride = nil
        end
    end
    timer.Simple(0.1, function()
        if OpenCharacterCreator then OpenCharacterCreator() end
    end)
end
EVO_HollowProg.OpenFinalizeCreatorClient = OpenFinalizeCreatorClient

function EVO_HollowProg.ApplyFinalizeSelectionClient(slot, newCharId)
    EVO_HollowProg._FinalizePending = true
    EVO_HollowProg._Finalizing = false
    EVO_HollowProg._FinalizeClientDeadline = nil
    EVO_HollowProg._FinalizeSlot = tonumber(slot)
    if not EVO_HollowProg._FinalizeSlot or EVO_HollowProg._FinalizeSlot <= 0 then
        EVO_HollowProg._FinalizeSlot = nil
    end
    EVO_HollowProg._FinalizeNewCharId = tonumber(newCharId)
    if not EVO_HollowProg._FinalizeNewCharId or EVO_HollowProg._FinalizeNewCharId <= 0 then
        EVO_HollowProg._FinalizeNewCharId = nil
    end
    EVO_HollowProg._canFinalize = false
    EVO_HollowProg.State = { active = false }
    -- Purge CSM larva résiduel : le close Chargement post-Terminer ne doit pas
    -- TryCreate un composite monde pendant l'ouverture HUB.
    local lp = LocalPlayer()
    if IsValid(lp) and LZY_Character_ClearCachedPlayerModel then
        LZY_Character_ClearCachedPlayerModel(lp)
    elseif IsValid(lp) and LZY_Character_DestroyPlayerClientModels then
        LZY_Character_DestroyPlayerClientModels(lp)
    end
end

function EVO_HollowProg.ClearFinalizeClient()
    EVO_HollowProg._FinalizePending = false
    EVO_HollowProg._Finalizing = false
    EVO_HollowProg._FinalizeClientDeadline = nil
    EVO_HollowProg._FinalizeSlot = nil
    EVO_HollowProg._FinalizeNewCharId = nil
    EVO_HollowProg._FinalizeResumeData = nil
    EVO_HollowProg._canFinalize = false
    EVO_HollowProg.State = { active = false }
end

net.Receive("EVO:HollowProg:OpenFinalizeCreator", function()
    EVO_HollowProg._FinalizeSlot = net.ReadUInt(4)
    if EVO_HollowProg._FinalizeSlot == 0 then EVO_HollowProg._FinalizeSlot = nil end
    EVO_HollowProg._FinalizeNewCharId = net.ReadUInt(32)
    if EVO_HollowProg._FinalizeNewCharId == 0 then EVO_HollowProg._FinalizeNewCharId = nil end
    if net.BytesLeft() >= 1 and net.ReadBool() then
        local uid = net.ReadUInt(32)
        local gender = net.ReadString()
        if uid > 0 then
            LZY_CHARACTER_CK_MODE = true
            LZY_CHARACTER_CK_DATA = {
                unique_id = uid,
                faction = "Hollow",
                gender = (gender ~= "" and gender) or "m",
                slot = EVO_HollowProg._FinalizeSlot,
                _ckAfterHollow = true,
            }
        end
    end
    OpenFinalizeCreatorClient()
end)

-- Menu sélection : slot Hollow + « Continuer la création » (reconnect ou retour creator).
net.Receive("EVO:HollowProg:FinalizePending", function()
    EVO_HollowProg.ApplyFinalizeSelectionClient(net.ReadUInt(4), net.ReadUInt(32))
end)

net.Receive("EVO:HollowProg:ProgressComplete", function()
    EVO_HollowProg.ClearFinalizeClient()
end)

-- ────────────────────────────────────────────────────────────
-- CLIENT PRET : permet la reprise differee (spawn larva / creator) cote serveur
-- ────────────────────────────────────────────────────────────
hook.Add("InitPostEntity", "EVO_HollowProg::ClientReady", function()
    timer.Simple(1, function()
        net.Start("EVO:HollowProg:ClientReady") net.SendToServer()
    end)
end)
-- Filet : si InitPostEntity a deja passe (reload lua), envoyer quand meme.
timer.Simple(2, function()
    if LocalPlayer and IsValid(LocalPlayer()) then
        net.Start("EVO:HollowProg:ClientReady") net.SendToServer()
    end
end)
