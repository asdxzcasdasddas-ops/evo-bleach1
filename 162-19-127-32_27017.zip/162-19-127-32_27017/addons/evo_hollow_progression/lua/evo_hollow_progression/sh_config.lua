-- "addons\\evo_hollow_progression\\lua\\evo_hollow_progression\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- evo_hollow_progression : configuration partagee (client + serveur)
EVO_HollowProg = EVO_HollowProg or {}
local CFG = {}
EVO_HollowProg.Config = CFG

-- ────────────────────────────────────────────────────────────
-- KILL-SWITCH. Tant que false : AUCUNE interception, la creation d'un Hollow
-- suit le flux normal (character creator). Passer a true pour activer le parcours.
-- ────────────────────────────────────────────────────────────
CFG.Enabled = true

-- Maps où le parcours s'applique (Enabled doit aussi être true). Ailleurs : flux normal.
-- Hueco Mundo = "hueco_mundo_v1" (sans prefixe rp_, cf evo_crossserver).
-- gm_construct = map de dev / test local.
CFG.Maps = {
    "hueco_mundo_v1",
    "gm_construct",
}
CFG.Map = CFG.Maps[1] -- legacy / doc (première map « prod »)

-- ────────────────────────────────────────────────────────────
-- MODELES (rendu en "raw model" : le composite tete+corps bonemerge est saute
-- cote client via le flag NWBool EVO_HollowRaw, cf cl_models.lua)
-- ────────────────────────────────────────────────────────────
CFG.LarvaModel = "models/evo/characters/hollow/evo_hdyr4fdez1fzhxzf4e5gezdz/evo_hdyr4FDEZ1FZhxzf4e5gezdz.mdl"
CFG.VastoModel = "models/evo/characters/hollow/evo_2d96zfezhuefe5dz85fehufefxz/evo_2d96zfezHUEFE5dz85feHUFEFxz.mdl"

-- Style de combat sans katana (placeholder ; vraies anims fournies plus tard).
CFG.LarvaStyle = "Hollow1"

-- 1ère compétence Ars Hollow (le "Cero") débloquée pour la larva pendant le tutoriel (étape
-- "acheter une compétence" adaptée) et équipée sur la barre de sorts. Catégorie lzy_skilltree
-- "Ars_Hollow" (accès faction Hollow). Slot d'équipement par défaut.
CFG.HollowFirstSkill     = "Spell_ars_hollow_1"
CFG.HollowFirstSkillSlot = 1

-- Skin aléatoire FIGÉ : on tire une valeur par bodygroup NOMMÉ uniquement (pour NE PAS
-- toucher au bodygroup de la TÊTE/visage et le faire disparaître). Donne ici les noms à
-- varier. Re-randomisé à chaque NOUVELLE larva. Un nom absent du modèle est ignoré.
-- Apparence aléatoire FIGÉE (re-randomisée à chaque NOUVELLE larva). PAR MODÈLE, car le
-- Hollow et le Vasto Lorde n'ont PAS les mêmes bodygroups :
--   • Hollow/larva : skin 0-7 + bodygroups body(0-2) + masque(0-3)
--   • Vasto Lorde  : bodygroups hair(0-1) + horn(0-1) + acc(0-1)
-- Une entrée = un nom (string, plage 0..nb-1) OU { name=, min=, max= } pour borner.
-- masque min=1 : la valeur 0 = PAS de masque -> on l'exclut (le masque est toujours là).
CFG.Appearance = {
    larva = { skinMax = 7, bodygroups = { "body", { name = "masque", min = 1 } } },
    vasto = { skinMax = 0, bodygroups = { "hair", "horn", "acc" } },
}

-- Noms affiches pendant la progression (surcharge la NWString "Nickname" = nametag,
-- HUD, chat... ; display-only, ne touche pas la BDD). Evolution :
--   « Hollow #<numero> » (etapes 1-2) -> « Adjuchas » (apres la 2e amelioration) -> « Vasto Lorde ».
CFG.NameHollow   = "Hollow"      -- suffixe « #<numero> » ajoute automatiquement (stable par joueur)
CFG.NameAdjuchas = "Adjuchas"
CFG.NameVasto    = "Vasto Lorde"

-- ────────────────────────────────────────────────────────────
-- ETAPES (plus AUCUN choix/don de stat : chaque palier = simple évolution + FX)
--   stage 1 : dévore X PNJ -> évolution (FX, dézoom caméra)
--   stage 2 : dévore X PNJ -> évolution (FX, dézoom caméra)
--   stage 3 : dévore X PNJ -> Vasto Lorde -> character creator (finalisation)
-- ────────────────────────────────────────────────────────────
CFG.Stages = {
    [1] = { kills = 2, reward = "evolve" },
    [2] = { kills = 2, reward = "evolve" },
    [3] = { kills = 2, reward = "vasto" },
}
CFG.MaxStage = 3

-- FX d'évolution : à CHAQUE palier (étapes 1-2 + passage Vasto), le joueur est STUN (figé),
-- la particule joue sur lui et la caméra DÉZOOME (cf. CFG.UpgradeDezoom* plus bas).
CFG.UpgradeParticle  = "[28]_transformation_hollow"
-- Animation jouée à CHAQUE évolution (2 paliers + passage Vasto). Jouée via
-- ncm_combat_system PlayerMeta:Animation (sPath, bLoop=false, iCycle=0, iSpeed=rate).
CFG.UpgradeAnim      = "evo_j0350nqeszgfsi"
CFG.UpgradeAnimRate  = 1
CFG.UpgradeStunTime  = 2.5 -- secondes de stun (figement) pendant l'amélioration
-- Durée de la PARTICULE [28]_transformation_hollow (s). DÉCOUPLÉE du stun ; à 3 s elle couvre
-- toute l'évolution (déborde légèrement après le stun de 2.5 s, voulu pour un effet plus présent).
CFG.UpgradeParticleDuration = 3
CFG.FlashDuration    = 2.2  -- durée de l'éclair lumineux blanc (s) — joué à CHAQUE amélioration
-- Passage VASTO uniquement : délai (s) avant la bascule du modèle larve -> Vasto. On joue d'abord
-- l'animation d'évolution SUR LA LARVE (l'anim "soul_ignite" n'existe pas sur le modèle Vasto), puis
-- on bascule le modèle pendant l'éclair (swap masqué par le flash). Défaut = moitié du flash.
CFG.VastoSwapDelay   = 1.1
-- Son joué à CHAQUE évolution (cri du Hollow), émis sur le joueur (EmitSound 3D = audible autour).
-- Chemin relatif à sound/ SANS le préfixe (comme les téléporteurs tbfpvq7ot1yh/...).
CFG.UpgradeSound     = "tbfpvq7ot1yh/hollow_scream.mp3"
CFG.UpgradeSoundLevel = 90  -- portée du son (75 = normal, plus haut = plus loin)

-- DÉZOOM CAMÉRA à CHAQUE évolution (demande user) : la caméra RECULE légèrement (on ÉCARTE la
-- caméra, PAS le FOV -> aucun effet fisheye) pendant l'évolution puis revient en douceur. Réutilise
-- PlayerMeta:SpellCamEffect, la fonction de recul des sorts (ex. Barragan) -> marche aussi en caméra
-- orbitale. dist = distance caméra ABSOLUE (caméra normale ~100 ; plus haut = plus reculé). 0 désactive.
CFG.UpgradeDezoomDist     = 190  -- distance caméra pendant l'évolution (léger recul vs ~100 normal)
CFG.UpgradeDezoomRampFrac = 0.3  -- fraction de la durée pour atteindre le recul (le reste = maintien)
-- + un LÉGER élargissement de FOV PAR-DESSUS le recul (combinés). 114 = doux (+24 vs défaut ~90,
-- aucun fisheye). 0 / <= défaut désactive. SetFOV est networké tout seul.
CFG.UpgradeDezoomFOV     = 114  -- FOV cible pendant l'évolution
CFG.UpgradeDezoomFOVIn   = 0.45 -- s pour élargir le FOV
CFG.UpgradeDezoomFOVOut  = 0.9  -- s pour revenir au FOV par défaut (après le stun)

-- Après le Vasto Lorde : invite NON-BLOQUANTE dans le HUD de quête (pas de popup) ;
-- on appuie sur cette touche QUAND ON VEUT pour devenir Arrancar (le jeu continue).
CFG.FinalizeKey      = KEY_F

-- Protection PVP : tant que le joueur est larva (avant la transformation finale), il
-- ne peut ni être blessé ni blesser un autre JOUEUR (les PNJ restent normaux).
CFG.PvpProtection = true

-- Échelle du modèle larva : tirée (figée, stable par joueur) entre Min et Max.
CFG.ScaleMin = 1.4
CFG.ScaleMax = 1.9

-- Portrait HUD : caméra RECULÉE pour la larva (la tête d'hollow paraît plus petite,
-- vue de plus loin). Augmenter le X = reculer encore.
CFG.HudHeadCamPos  = Vector(30, 0, 68)
CFG.HudHeadCamLook = Vector(0, 0, 64)

-- Arme de combat (= la pose de combat). Le larva est VERROUILLÉ dessus : pas de
-- rengainement, pas d'autre arme -> toujours en pose de combat, sans katana visible
-- (style Hollow1 sans modèle d'arme).
CFG.CombatWeaponClass = "citron_combat_weapons"
CFG.AllowedWeapons = {
    ["citron_combat_weapons"] = true,
    ["citron_shinai_weapons"] = true,
    -- Caméra libre : la larva doit pouvoir passer sur le SWEP `citron_freecam` (donné à tous au
    -- spawn) — sinon le lock LockCombatWeapon bloque la bascule -> pas de caméra libre. La pose de
    -- combat n'est donc PLUS imposée : on peut ranger l'arme (sheathe laissé libre) ET ouvrir la
    -- caméra libre, comme un perso normal.
    ["citron_freecam"]        = true,
    -- Mains nues : arme de RANGEMENT. Permet de ranger l'arme de combat (sheathe) via le
    -- weapon selector — switcher combat -> mains déclenche Holster() (mode combat OFF), et
    -- mains -> combat re-dégaine. Sans ça le lock bloquait tout switch -> larve coincée en combat.
    ["mugen_hands"]           = true,
}

-- MANGER (touche E) : c'est DÉVORER un PNJ qui fait progresser la quête, PAS le tuer.
-- On vise les PNJ de classe ncm_pnj_* (Hollows / PNJ de combat).
-- Flux : on TUE le PNJ (combat) -> une ÂME (CFG.SoulModel) apparaît tout de suite à sa place
-- (pendant l'anim de mort), mangeable pendant CorpseLinger secondes -> on la MANGE
-- (canalisation EatDuration) -> progression, puis l'âme disparaît.
CFG.EatKey         = KEY_E   -- touche pour dévorer
CFG.EatRange       = 170     -- distance max pour dévorer une âme
CFG.EatCooldown    = 0.5     -- anti-spam (s)
CFG.EatDuration    = 3       -- le "manger" dure 3 s (figement + canalisation)
CFG.CorpseLinger   = 25      -- l'âme reste mangeable 25 s après la mort, puis disparaît (10 -> 25, user 08/24 : « dispawn trop vite »)
-- Modèle "âme" spawné dès le kill (début OnDeath) : c'est CE prop (et non plus le corps
-- figé du PNJ) qu'on dévore (touche E), y compris pendant l'anim de mort.
CFG.SoulModel      = "models/evo/props/items/evo_fryhbhbfefr65bhvfhudf/evo_FRYHBhbfefr65BHVFhudf.mdl"
CFG.SoulScaleMin   = 0.5     -- échelle ALÉATOIRE du prop âme (indépendante du scale du PNJ tué)
CFG.SoulScaleMax   = 1.5
CFG.EatHealPct     = 0.30    -- soin à chaque âme dévorée (% des PV max ; 30% demande user 07/22)
CFG.EatNpcPrefix   = "ncm_pnj_"
CFG.EatSound       = "npc/barnacle/barnacle_crunch2.wav"
-- Son joué à la FIN d'une dévoration RÉUSSIE (≠ EatSound = son de mastication au début).
CFG.EatSuccessSound = "r1n1mtedmal9vcf/eat_success.mp3"
-- Animation jouée pendant la dévoration (gérée par ncm_combat_system PlayerMeta:Animation :
-- args = sPath, bLoop, iCycle, iSpeed). iSpeed = vitesse de lecture -> 1.8 = x1.8.
CFG.EatAnim        = "evo_ehfje5f9e2dzdf94fefe"
CFG.EatAnimRate    = 1.8

-- ÉQUILIBRAGE évolution (demande user) : pour rendre TOUT le parcours larva plus simple, la larva
-- fait PLUS de dégâts aux PNJ hollow (ncm_pnj_*) et en REÇOIT MOINS de leur part. N'affecte que
-- les PNJ de classe EatNpcPrefix ("ncm_pnj_") — pas les joueurs (déjà gérés par la protection PvP).
CFG.DamageVsHollowMult   = 2.0  -- la larva fait x2 dégâts aux PNJ hollow
CFG.DamageFromHollowMult = 0.25 -- la larva prend x0.25 dégâts des PNJ hollow (-50% en plus de l'ancien x0.5, demande user)

-- SPELL larva (Hollow / Adjuchas / Vasto Lorde) : dégâts de ZONE + anim reprise
-- d'Aaroneiro + particule, avec un « rond vide » au sol (placeholder).
-- DÉSACTIVÉ (demande user) : la touche R ne fait plus RIEN en hollow (l'anim d'attaque rendait
-- un "coup spécial bizarre"). Repasser à true pour réactiver le sort R.
CFG.SpellEnabled   = false
CFG.SpellKey       = KEY_R                  -- touche pour lancer le spell
CFG.SpellCooldown  = 6                      -- s
CFG.SpellRadius    = 300                    -- rayon de la zone de dégâts (= rayon du rond)
CFG.SpellDamage    = 25
CFG.SpellHitDelay  = 0.3                    -- délai avant l'impact (calé sur l'anim)
CFG.SpellAnim      = "sda_atk15_inosuke"    -- anim reprise du spell Aaroneiro
CFG.SpellParticle  = "[1]_spectral_crying_add_1"

-- ────────────────────────────────────────────────────────────
-- (Retiré) CHOIX/DON DE STAT par évolution : le système a été supprimé (demande user).
-- Chaque palier d'évolution est désormais une simple transformation (FX + dézoom caméra),
-- sans menu de choix ni bonus de stat. La colonne BDD `picks` reste (vide) pour compat.
-- ────────────────────────────────────────────────────────────

-- Vrai si le parcours doit s'appliquer sur cette map (Enabled + liste CFG.Maps).
function EVO_HollowProg.IsActiveMap(mapName)
    if CFG.Enabled ~= true then return false end
    mapName = mapName or game.GetMap()
    for _, m in ipairs(CFG.Maps or {}) do
        if m == mapName then return true end
    end
    -- Fallback legacy si Maps vide mais CFG.Map défini.
    return isstring(CFG.Map) and CFG.Map ~= "" and mapName == CFG.Map
end

-- Vrai si le parcours doit s'appliquer sur ce serveur (active + bonne map).
function EVO_HollowProg.IsActiveServer()
    return EVO_HollowProg.IsActiveMap()
end

-- Vrai si ce PNJ NE doit PAS être chassé/dévoré par la larva. PARTAGÉ (client + serveur) : il ne
-- s'appuie que sur des NWBool lisibles des 2 côtés. Couvre les DONNEURS DE QUÊTE et les PNJ de
-- PROGRESSION (ncm_isQuestGiver / ncm_isProgressionNPC) — des PNJ ncm_pnj_* statiques/non tuables
-- (ex : Maître d'Armes) que le waypoint de chasse pointait à tort. Le flag SERVEUR _ncmNoDevour
-- (invocations de sort, non networké) est géré EN PLUS côté serveur dans MakeEatableCorpse.
function EVO_HollowProg.IsNonHuntableNpc(ent)
    if not IsValid(ent) then return true end
    if ent:GetEvoNWBool("ncm_isQuestGiver", false)            -- donneurs de quête
        or ent:GetEvoNWBool("ncm_isProgressionNPC", false)    -- PNJ de progression (Maître d'Armes...)
        or ent:GetEvoNWBool("ncm_isQuestMob", false) then     -- mobs d'OBJECTIF de quête (mode "quest")
        return true
    end
    -- BOSS (Menos Grande, world boss, boss de zone, mobs à barre "boss") : la larva ne chasse QUE
    -- des Hollows CLASSIQUES (demande user) -> jamais de waypoint ni de corps dévorable sur un boss.
    -- Détection PARTAGÉE client+serveur : NWInt ncm_bossZoneRadius (boss promus runtime) + config
    -- NCM_PNJ.Config (IsBoss / BarType "boss" / Tier 4 ; lisible côté client, cf. cl_healthbar).
    -- Prédicat PARTAGÉ (ncm_pnj/sh_config, centralisé le 2026-07-27) : couvre l'ancien test
    -- local (ncm_bossZoneRadius + IsBoss / Tier 4 / BarType "boss") et y ajoute les autres
    -- marqueurs de promotion runtime (ncm_isManagedBoss / ncm_isWorldBoss) — un boss d'événement
    -- doit de toute façon être non-chassable par la larva. Ces marqueurs sont TOUS networkés,
    -- donc client et serveur répondent la même chose : indispensable ici, la fonction étant
    -- appelée des DEUX côtés (cl_main waypoint « Dévore ce Hollow » / sv_main MakeEatableCorpse).
    if NCM_PNJ and NCM_PNJ.IsBossEntity then return NCM_PNJ.IsBossEntity(ent) end
    -- Chemin dégradé (ncm_pnj pas encore chargé) : on garde au moins le test NW d'origine,
    -- sinon un boss de zone redeviendrait chassable le temps du chargement.
    return ent:GetEvoNWInt("ncm_bossZoneRadius", 0) > 0
end

-- Vrai si ce body_model est un modèle de larva (larva ou vasto). Sert au preview de
-- sélection / creator pour afficher le modèle ENTIER (raw) au lieu du composite arrancar.
function EVO_HollowProg.IsLarvaBodyModel(model)
    if not isstring(model) or model == "" then return false end
    local low = string.lower(string.gsub(model, "\\", "/"))
    return low == string.lower(CFG.LarvaModel) or low == string.lower(CFG.VastoModel)
end

-- Vrai si ce joueur est un ARRANCAR = un Hollow ABOUTI (faction "Hollow") qui n'est PLUS une
-- larva. PARTAGÉ (NWBool/NWString lisibles des 2 côtés). Sert au scaling d'XP des mobs "faciles"
-- du world hunt : un Arrancar qui farm des Hollows faciles ne gagne presque pas d'XP (les mobs
-- faciles sont là pour les bas-gradés / la variété, pas pour le farm d'XP des Hollows aboutis).
function EVO_HollowProg.IsArrancar(ply)
    if not (IsValid(ply) and ply:IsPlayer()) then return false end
    if ply:GetEvoNWBool("EVO_IsLarva", false) then return false end -- encore en cours d'évolution
    local f = ply:GetEvoNWString("faction_name", "")
    if f == "" then f = ply:GetEvoNWString("FactionName", "") end
    return f == "Hollow"
end

-- ────────────────────────────────────────────────────────────
-- APPARENCE DÉTERMINISTE (PARTAGÉE serveur + client)
--   Skin + bodygroups NOMMÉS (par modèle larva/vasto, cf CFG.Appearance), tirés de façon
--   DÉTERMINISTE à partir de seedKey (= char_id). Donc :
--     • le SERVEUR pose cette apparence sur le joueur (sv_main RandomizeBodygroups),
--     • le CLIENT recalcule EXACTEMENT la même sur le ClientsideModel de preview (creator /
--       menu de sélection) -> la preview montre le VRAI hollow (skin + masque), pas une
--       version "propre" sans masque.
--   Fonctionne sur n'importe quelle entity (joueur OU ClientsideModel). Retourne la chaîne
--   encodée "skin=N,idx:val,..." (l'index réel du bodygroup, pour restauration à l'identique).
-- ────────────────────────────────────────────────────────────
local function HashFrac(s) -- 0..1 déterministe (util.CRC = stable cross-session/serveur/realm)
    return ((tonumber(util.CRC(tostring(s))) or 0) % 100000) / 100000
end
local function HashRange(s, lo, hi) -- entier déterministe dans [lo, hi] bornes incluses
    if hi <= lo then return lo end
    return lo + math.floor(HashFrac(s) * (hi - lo + 1))
end
EVO_HollowProg.HashRange = HashRange

-- Échelle DÉTERMINISTE de la larva (proportions), seedée par char_id -> MÊME valeur en jeu ET
-- dans la preview (creator / menu de sélection). Avant : in-game seedé par steamid + la preview
-- lisait playerData.scale (=1 en BDD) -> proportions DIFFÉRENTES à la reconnexion.
function EVO_HollowProg.GetScale(seedKey)
    local sMin = tonumber(CFG.ScaleMin) or 1.4
    local sMax = tonumber(CFG.ScaleMax) or 1.9
    return sMin + HashFrac(tostring(seedKey or "x") .. "|scale") * (sMax - sMin)
end

-- Pose l'échelle larva (utilisé aussi par evo_animateur).
function EVO_HollowProg.ApplyLarvaScale(ply, seedKey)
    if not IsValid(ply) then return nil end
    local sc = EVO_HollowProg.GetScale(seedKey or (ply.HollowProg and ply.HollowProg.char_id) or ply:GetUniqueID() or ply:SteamID64())
    if math.abs((ply:GetModelScale() or 1) - sc) < 0.001 then return sc end
    ply:SetModelScale(sc, 0)
    return sc
end

function EVO_HollowProg.ApplyAppearance(ent, isVasto, seedKey)
    if not IsValid(ent) then return "" end
    local cfg = (CFG.Appearance and CFG.Appearance[isVasto and "vasto" or "larva"]) or {}
    local seed = tostring(seedKey or "x")
    local parts = {}
    -- Skin 0..skinMax (déterministe par char)
    local skinMax = tonumber(cfg.skinMax) or 0
    local skin = (skinMax > 0) and HashRange(seed .. "|skin", 0, skinMax) or 0
    ent:SetSkin(skin)
    parts[#parts + 1] = "skin=" .. skin
    -- Bodygroups nommés : entrée = "nom" (0..count-1) OU { name=, min=, max= } pour borner.
    for _, entry in ipairs(cfg.bodygroups or {}) do
        local name = isstring(entry) and entry or entry.name
        local idx = name and ent:FindBodygroupByName(name)
        if idx and idx >= 0 then
            local count = ent:GetBodygroupCount(idx) or 1
            if count > 1 then
                local lo = math.Clamp((istable(entry) and tonumber(entry.min)) or 0, 0, count - 1)
                local hi = math.Clamp((istable(entry) and tonumber(entry.max)) or (count - 1), lo, count - 1)
                local v = HashRange(seed .. "|bg|" .. tostring(name), lo, hi)
                ent:SetBodygroup(idx, v)
                parts[#parts + 1] = idx .. ":" .. v
            end
        end
    end
    return table.concat(parts, ",")
end

-- ────────────────────────────────────────────────────────────
-- BODYGROUPS D'ÉVOLUTION (larva = les 2 premiers modes : Hollow / Adjuchas, PAS le Vasto)
-- PROGRESSION ADDITIVE (demande user) : étape 1 = AUCUNE part ; à la 1ʳᵉ évolution on GAGNE une
-- part AU HASARD (ailes OU queue) ; à la 2ᵉ évolution on gagne L'AUTRE en CONSERVANT la 1ʳᵉ.
-- L'ORDRE d'acquisition ET la VALEUR de chaque part (1..max) sont aléatoires mais DÉTERMINISTES
-- par char_id -> stables à la reconnexion, SANS colonne BDD (l'étape est déjà persistée, et la
-- progression est monotone : on ne reperd jamais une part gagnée). Posées SERVEUR uniquement
-- (networkées via le modèle brut) et ABSENTES de CFG.Appearance -> le client ne les écrase pas.
-- 1er nom candidat trouvé sur le modèle = utilisé (absents ignorés).
-- ⚠️ VÉRIFIE les vrais noms en jeu : `evo_hollow_cl` (liste bg[i] nom = val/count) et ajuste.
CFG.EvolutionBodygroups = {
    { names = { "wings", "ailes", "aile", "wing" },   max = 2 }, -- ailes : valeur gagnée 1..2
    { names = { "tails", "tail", "queue", "queues" }, max = 2 }, -- queue : valeur gagnée 1..2
}

-- Ordre d'acquisition ALÉATOIRE déterministe (permutation Fisher-Yates seedée par char_id) :
-- la part de rang r est gagnée à l'évolution r -> apparaît à l'étape larve (r+1).
local function EvolutionOrder(seed, n)
    local order = {}
    for i = 1, n do order[i] = i end
    for i = n, 2, -1 do
        local j = HashRange(seed .. "|perm|" .. i, 1, i)
        order[i], order[j] = order[j], order[i]
    end
    return order
end

-- Pose les bodygroups d'évolution (ailes/queue) sur ent selon l'ÉTAPE (progression additive).
-- No-op si le modèle n'a pas ces bodygroups. À appeler UNIQUEMENT pour la larva (pas le Vasto).
function EVO_HollowProg.ApplyEvolutionBodygroups(ent, seedKey, stage)
    if not IsValid(ent) then return end
    stage = tonumber(stage) or 1
    local seed    = tostring(seedKey or "x")
    local parts   = CFG.EvolutionBodygroups or {}
    local order   = EvolutionOrder(seed, #parts)
    local usedIdx = {}
    for rank, partIdx in ipairs(order) do
        local entry       = parts[partIdx]
        local gainedStage = rank + 1 -- rang 1 -> étape 2 (1ʳᵉ évo) ; rang 2 -> étape 3 (2ᵉ évo)
        local idx
        for _, nm in ipairs(entry.names or {}) do
            local i = ent:FindBodygroupByName(nm)
            if i and i >= 0 then idx = i break end
        end
        -- Garde anti-doublon : si 2 parts résolvent au MÊME slot (noms ambigus), on n'écrase pas.
        if idx and not usedIdx[idx] then
            usedIdx[idx] = true
            local count = ent:GetBodygroupCount(idx) or 1
            if count > 1 then
                local v = 0
                if stage >= gainedStage then -- part GAGNÉE -> valeur figée 1..max (conservée ensuite)
                    local hi = math.Clamp(tonumber(entry.max) or (count - 1), 1, count - 1)
                    -- Seed sur l'INDEX de part (position config, STABLE) et pas le nom matché : la valeur
                    -- d'une part reste identique même si le modèle expose un autre nom candidat (cross-serveur).
                    v = HashRange(seed .. "|val|" .. partIdx, 1, hi)
                end
                ent:SetBodygroup(idx, v) -- 0 si pas encore gagnée (étape < gainedStage)
            end
        end
    end
end
