-- "addons\\evo_bataille_clans\\lua\\evo_bataille_clans\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Bataille des Clans — configuration partagée
-- ============================================================================

EVO_BATAILLE = EVO_BATAILLE or {}

EVO_BATAILLE.Config = {
    -- Seuls ces maps hostent le combat. Les autres serveurs affichent seulement
    -- la bannière de victoire via le poll MySQL cross-server.
    HostMaps = {
        -- UN SEUL host à la fois (2 hosts = 2 batailles en parallèle + bannières
        -- croisées en double). Passage zone neutre 08/27 ANNULÉ le jour même (user) :
        -- retour au Hueco.
        ["hueco_mundo_v1"] = true, -- host officiel (demande user 08/14)
        -- ["rp_seireitei_v1"] = true,
        -- ["gm_construct"] = true,
    },

    -- Arène par map : centre + rayon (demi-sphère visuelle, sol plat).
    Arenas = {
	    ["hueco_mundo_v1"] = {
	        center = Vector(147.92, -1471.53, 8656.18), -- calage user 08/14 (Las Noches, via l'éditeur)
	        radius = 8000,
	        height = 5000,
			name = "Zone Neutre 2",
	    },
	    ["rp_seireitei_v1"] = {
	        center = Vector(3616.60, 844.63, -7509.47),
	        radius = 8000,
	        height = 8000, -- même axe Z que DrawHemiSphere / IsInsideArena (pas visual-only)
	    },
		["gm_construct"] = {
		    center = Vector(-2321.89, 1210.60, -130.83),
		    radius = 800,
		    height = 800,
		},
    },

    -- Jours : os.date("*t").wday — 1=dimanche, 2=lundi, …, 6=vendredi, 7=samedi.
    Days = {
        [2] = true, -- lundi
        [6] = true, -- vendredi
    },

    JoinStart          = { h = 21, m = 0 },  -- ouverture des entrées
    JoinEnd            = { h = 21, m = 10 }, -- fermeture des entrées
    RewardLeaveCutoff  = { h = 21, m = 5 }, -- départ volontaire avant → pas de reward
    SoftEnd            = { h = 21, m = 20 }, -- après : win si 1 clan alive / cancel si ≤1 showed

    -- Offsets (minutes depuis le lancement) pour `bataille_start` / force-start SA.
    ForceStart = {
        JoinMinutes          = 5,  -- fenêtre d'entrée
        LeaveCutoffMinutes   = 10, -- cutoff reward (départ volontaire avant = pas de reward)
        SoftEndMinutes       = 15, -- soft end (win / cancel)
    },

    ExitGraceSeconds   = 5,
    ZoneID             = "bataille_des_clans",

    -- God mode court à chaque entrée dans l'instance (semi-transparent).
    EnterGodDuration   = 5,    -- secondes d'invulnérabilité à l'entrée
    EnterGodCanDamage  = true, -- true = peut infliger des dégâts pendant le god

    -- true  = alliés de clan peuvent se blesser entre eux pendant l'event
    -- false = friendly fire OFF
    FriendlyFire       = true,

    -- Grade de combat EFFECTIF pendant l'event (RANK_STATS_BOOST + lecteurs
    -- combat). Ne touche PAS la NW FactionRank (uniformes / droits inchangés).
    CombatRankOverride = 7,

    WinCoins           = 500,
    CancelYens         = 5000,

    BannerDuration     = 10, -- secondes d'affichage bannière
    BannerSound        = "friends/friend_online.wav",

    PopupMessage       = "Voulez-vous rejoindre la Bataille des Clans ?",
    -- %s = liste des noms des sorts bloqués (barre active). Affiché en rouge.
    PopupSpellWarn     = "Attention : ces sorts de votre barre seront inutilisables (grade trop élevé pour l'événement) : %s. Retirez-les avant d'entrer pour préparer le combat.",
    PopupTransformWarn = "Attention : Shikai / Bankai (Resurrección) seront coupés et inutilisables pendant l'événement.",
    HudTitle           = "BATAILLE DES CLANS",
}

function EVO_BATAILLE.IsHostMap(sMap)
    sMap = sMap or game.GetMap()
    local cfg = EVO_BATAILLE.Config
    return cfg.HostMaps and cfg.HostMaps[sMap] == true
end

--- True si le joueur est dans l'instance de la Bataille des Clans
--- (zone partagée, flag combat, ou HUD event côté client).
function EVO_BATAILLE.IsInEventInstance(ply)
    if not IsValid(ply) then return false end
    local zone = (EVO_BATAILLE.Config and EVO_BATAILLE.Config.ZoneID) or "bataille_des_clans"
    if NCM_INSTANCE and NCM_INSTANCE.PlyZone and NCM_INSTANCE.PlyZone(ply) == zone then
        return true
    end
    if ply._EVO_BatailleCombatRank then return true end
    if CLIENT and EVO_BATAILLE.IsLocalInEvent and ply == LocalPlayer() then
        return EVO_BATAILLE.IsLocalInEvent() == true
    end
    return false
end

--- Grade de faction utilisé pour le COMBAT / stats. Pendant la Bataille,
--- `_EVO_BatailleCombatRank` force tout le monde au même palier (config
--- CombatRankOverride) sans écraser la NW FactionRank.
function EVO_BATAILLE.GetEffectiveFactionRank(ply, nDefault)
    nDefault = nDefault or 1
    if not IsValid(ply) then return nDefault end
    if ply._EVO_BatailleCombatRank then
        return ply._EVO_BatailleCombatRank
    end
    return ply:GetEvoNWInt("FactionRank", nDefault)
end

-- Index (1..9) d'un sort d'art spirituel dans sa catégorie skilltree, ou nil.
function EVO_BATAILLE.GetArtSpiSpellIndex(spellID)
    if not spellID or not LZY_SKILLTREE_CATEGORIES then return nil end
    for _, cat in pairs(LZY_SKILLTREE_CATEGORIES) do
        if cat and cat.type == "art_spirituel" and cat.spells then
            for _, row in ipairs(cat.spells) do
                for spellIndex, id in ipairs(row) do
                    if id == spellID then
                        return spellIndex
                    end
                end
            end
        end
    end
    return nil
end

-- Préfixes dont le grade de déblocage est celui du vendeur de parchemins
-- (hado / bakudo / ars hollow + voies katana / hakuda). Pas les arts spirituels :
-- GetRequirement retomberait sinon sur la rampe technique pour n'importe quel
-- Spell_*_N.
local BATAILLE_VENDOR_PREFIXES = {
    "Spell_ars_hollow_",
    "Spell_hado_",
    "Spell_bakudo_",
    "Spell_katana_",
    "Spell_hakuda_",
}

local function bataille_vendor_unlock_grade(spellID)
    if not isstring(spellID) then return nil end
    local vendor = NCM_PARCHEMIN_VENDOR
    if not (vendor and vendor.GetRequirement) then return nil end
    for _, prefix in ipairs(BATAILLE_VENDOR_PREFIXES) do
        if string.sub(spellID, 1, #prefix) == prefix then
            local req = vendor.GetRequirement(spellID)
            return req and tonumber(req.grade)
        end
    end
    return nil
end

-- True si le sort exige un grade > CombatRankOverride pour être débloqué
-- (art spirituel slots 5–9 ; techniques 4–7 ; voies 4–5, config actuelle).
-- Indépendant d'être dans l'event — le gate cast / overlay combine ceci avec
-- _EVO_BatailleCombatRank / IsLocalInEvent.
function EVO_BATAILLE.IsSpellBlockedInEvent(spellID)
    local cap = (EVO_BATAILLE.Config and tonumber(EVO_BATAILLE.Config.CombatRankOverride)) or 7
    local idx = EVO_BATAILLE.GetArtSpiSpellIndex(spellID)
    if idx then
        local req = LZY_SKILLTREE_ART_SPI_RANK_REQ and LZY_SKILLTREE_ART_SPI_RANK_REQ[idx]
        if req and req > cap then return true end
    end
    local grade = bataille_vendor_unlock_grade(spellID)
    return grade ~= nil and grade > cap
end

local function bataille_equipped_spell_id(entry)
    if type(entry) == "table" then return entry[1] or entry.id end
    return entry
end

local function bataille_spell_display_name(spellID)
    local cfg = EvoStyle and EvoStyle.SpellsConfig and EvoStyle.SpellsConfig[spellID]
    local name = cfg and cfg.sName
    if isstring(name) and name ~= "" and name ~= "Passif" then
        return name
    end
    return tostring(spellID)
end

-- Noms des sorts de la barre active (slots 1–6) bloqués pour l'event.
function EVO_BATAILLE.GetBlockedEquippedSpellNames(ply)
    local names = {}
    if not IsValid(ply) or not ply.GetEvoNWString then return names end
    local raw = util.JSONToTable(ply:GetEvoNWString("LZY_SpellSelector_Equipped", "[]")) or {}
    local seen = {}
    for k = 1, 6 do
        local sid = bataille_equipped_spell_id(raw[k] or raw[tostring(k)])
        if sid and EVO_BATAILLE.IsSpellBlockedInEvent(sid) and not seen[sid] then
            seen[sid] = true
            names[#names + 1] = bataille_spell_display_name(sid)
        end
    end
    return names
end

-- True si au moins un sort de la barre active (slots 1–6) est bloqué pour l'event.
function EVO_BATAILLE.HasBlockedEquippedSpells(ply)
    return #EVO_BATAILLE.GetBlockedEquippedSpellNames(ply) > 0
end

-- Texte d'avertissement popup (nil si aucun sort bloqué équipé).
function EVO_BATAILLE.FormatPopupSpellWarn(ply)
    local names = EVO_BATAILLE.GetBlockedEquippedSpellNames(ply)
    if #names == 0 then return nil end
    local cfg = EVO_BATAILLE.Config
    local tpl = (cfg and cfg.PopupSpellWarn)
        or "Attention : ces sorts de votre barre seront inutilisables : %s. Retirez-les avant d'entrer."
    return string.format(tpl, table.concat(names, ", "))
end

-- Avertissement d'entrée : transformations toujours + sorts de barre si concernés.
function EVO_BATAILLE.FormatPopupWarn(ply)
    local cfg = EVO_BATAILLE.Config
    local sTr = cfg and cfg.PopupTransformWarn
    local sSp = EVO_BATAILLE.FormatPopupSpellWarn(ply)
    if isstring(sTr) and sTr ~= "" and isstring(sSp) and sSp ~= "" then
        return sTr .. " " .. sSp
    end
    if isstring(sTr) and sTr ~= "" then return sTr end
    return sSp
end

function EVO_BATAILLE.GetArena(sMap)
    sMap = sMap or game.GetMap()
    local a = EVO_BATAILLE.Config.Arenas and EVO_BATAILLE.Config.Arenas[sMap]
    if not a or not a.center then return nil end
    return a
end

function EVO_BATAILLE.SetSoloArena(sMap, center, radius, height, name)
    if not (isstring(sMap) and sMap ~= "" and isvector(center)) then return end
    local r = tonumber(radius) or 800
    local h = tonumber(height) or r
    EVO_BATAILLE.Config.Arenas = {
        [sMap] = {
            center = Vector(center.x, center.y, center.z),
            radius = r,
            height = h,
            name = name or "Bataille des Clans",
        },
    }
    EVO_BATAILLE.Config.HostMaps = { [sMap] = true }
end

function EVO_BATAILLE.ClearSoloArena()
    EVO_BATAILLE.Config.Arenas = {}
    EVO_BATAILLE.Config.HostMaps = {}
end

--- Hauteur de la demi-ellipsoïde (Z). Défaut = radius. Même valeur pour draw + IsInsideArena.
function EVO_BATAILLE.GetArenaHeight(arena)
    if not arena then return 0 end
    local h = tonumber(arena.height)
    if h and h > 0 then return h end
    return tonumber(arena.radius) or 0
end

--- Seconds since local midnight for {h,m}
function EVO_BATAILLE.HMToSeconds(t)
    if not t then return 0 end
    return (tonumber(t.h) or 0) * 3600 + (tonumber(t.m) or 0) * 60
end

--- Absolute os.time() for today's {h,m} (local timezone)
function EVO_BATAILLE.TodayAt(tHM)
    local d = os.date("*t")
    d.hour = tonumber(tHM.h) or 0
    d.min  = tonumber(tHM.m) or 0
    d.sec  = 0
    return os.time(d)
end
