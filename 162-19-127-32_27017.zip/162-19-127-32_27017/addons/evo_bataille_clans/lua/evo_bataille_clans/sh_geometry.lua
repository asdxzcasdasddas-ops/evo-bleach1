-- "addons\\evo_bataille_clans\\lua\\evo_bataille_clans\\sh_geometry.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Géométrie demi-ellipsoïde (sol plat) — helpers partagés
-- Visual (DrawHemiSphere) et logique (entrée / exit grace / hunt) doivent matcher.
-- ============================================================================

EVO_BATAILLE = EVO_BATAILLE or {}

--- Distance horizontale (ignore Z) au centre
function EVO_BATAILLE.HorizDistSqr(vPos, vCenter)
    local dx = vPos.x - vCenter.x
    local dy = vPos.y - vCenter.y
    return dx * dx + dy * dy
end

--- Dans la demi-ellipsoïde (même formule que DrawHemiSphere) :
---   (dx/r)^2 + (dy/r)^2 + (dz/h)^2 <= 1  et  dz >= 0 (au-dessus du sol du centre).
--- nHeight omis / <= 0 → r (hémisphère). Tolérance légère sous le sol pour le terrain.
function EVO_BATAILLE.IsInsideArena(vPos, vCenter, nRadius, nHeight)
    if not vPos or not vCenter then return false end
    local r = tonumber(nRadius) or 0
    if r <= 0 then return false end
    local h = tonumber(nHeight) or 0
    if h <= 0 then h = r end

    local dz = vPos.z - vCenter.z
    if dz < -32 then return false end -- sous le plan du centre (hors dôme)
    if dz > h then return false end   -- au-dessus du pôle

    local dx = vPos.x - vCenter.x
    local dy = vPos.y - vCenter.y
    return (dx * dx + dy * dy) / (r * r) + (dz * dz) / (h * h) <= 1
end

--- Variante pratique : lit radius + height depuis la table arène.
function EVO_BATAILLE.IsInsideArenaCfg(vPos, arena)
    if not arena or not arena.center then return false end
    local h = EVO_BATAILLE.GetArenaHeight and EVO_BATAILLE.GetArenaHeight(arena) or arena.height
    return EVO_BATAILLE.IsInsideArena(vPos, arena.center, arena.radius, h)
end

--- Juste hors de la demi-ellipsoïde, même Z. Pour recracher un joueur
--- (réentrée interdite) sans down-trace long — ça pouvait le coller sous le sol.
function EVO_BATAILLE.PushOutsideArena(vPos, arena, nPad)
    if not vPos or not arena or not arena.center then return vPos end
    local c = arena.center
    local r = tonumber(arena.radius) or 0
    if r <= 0 then return vPos end
    local h = EVO_BATAILLE.GetArenaHeight and EVO_BATAILLE.GetArenaHeight(arena) or arena.height
    h = tonumber(h) or r
    if h <= 0 then h = r end
    local pad = tonumber(nPad) or 8

    local dx = vPos.x - c.x
    local dy = vPos.y - c.y
    local dz = math.Clamp(vPos.z - c.z, 0, h)
    local t = 1 - (dz * dz) / (h * h)
    if t < 0 then t = 0 end
    local rim = r * math.sqrt(t)
    local horizSqr = dx * dx + dy * dy
    if horizSqr < 1 then
        return Vector(c.x + rim + pad, c.y, vPos.z)
    end
    local scale = (rim + pad) / math.sqrt(horizSqr)
    return Vector(c.x + dx * scale, c.y + dy * scale, vPos.z)
end

--- Pose au sol autour de vPos (relief). Fenêtre bornée : on ne redescend
--- pas de 2000 u (ça collait le joueur dans une cave / sous la map).
function EVO_BATAILLE.SnapArenaGround(vPos, nUp, nDown)
    if not vPos then return vPos end
    local up = tonumber(nUp) or 256
    local down = tonumber(nDown) or 512
    local tr = util.TraceLine({
        start = vPos + Vector(0, 0, up),
        endpos = vPos - Vector(0, 0, down),
        mask = MASK_SOLID_BRUSHONLY,
    })
    if tr.Hit and not tr.StartSolid then
        return tr.HitPos + Vector(0, 0, 8)
    end
    -- Enfoui dans un relief : retente plus haut, toujours sans down-trace long.
    if tr.StartSolid then
        tr = util.TraceLine({
            start = vPos + Vector(0, 0, up * 2),
            endpos = vPos - Vector(0, 0, down),
            mask = MASK_SOLID_BRUSHONLY,
        })
        if tr.Hit and not tr.StartSolid then
            return tr.HitPos + Vector(0, 0, 8)
        end
    end
    return vPos
end

--- Recrache un joueur déjà DANS le dôme (start, pas de last-out) : on marche
--- vers le bord en collant le sol, comme un mur qui apparaît autour de lui.
function EVO_BATAILLE.EjectOutsideArena(vPos, arena, nPad)
    if not vPos or not arena or not arena.center then return vPos end
    local rim = EVO_BATAILLE.PushOutsideArena(vPos, arena, nPad)
    if not rim then return vPos end
    if not EVO_BATAILLE.IsInsideArenaCfg(vPos, arena) then
        return EVO_BATAILLE.SnapArenaGround(vPos)
    end

    local dx, dy = rim.x - vPos.x, rim.y - vPos.y
    local horiz = math.sqrt(dx * dx + dy * dy)
    if horiz < 8 then
        return EVO_BATAILLE.SnapArenaGround(rim)
    end

    local step = 64
    local n = math.max(1, math.ceil(horiz / step))
    local lastZ = vPos.z
    for i = 1, n do
        local t = i / n
        local cand = Vector(vPos.x + dx * t, vPos.y + dy * t, lastZ)
        local snapped = EVO_BATAILLE.SnapArenaGround(cand)
        if not EVO_BATAILLE.IsInsideArenaCfg(snapped, arena) then
            return snapped
        end
        lastZ = snapped.z
    end

    local dest = EVO_BATAILLE.SnapArenaGround(rim)
    if EVO_BATAILLE.IsInsideArenaCfg(dest, arena) then
        dest = EVO_BATAILLE.PushOutsideArena(dest, arena, nPad)
        dest = EVO_BATAILLE.SnapArenaGround(dest)
    end
    return dest
end
