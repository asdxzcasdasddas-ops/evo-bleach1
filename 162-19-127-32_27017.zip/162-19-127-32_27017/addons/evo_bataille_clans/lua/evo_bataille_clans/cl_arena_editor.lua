-- "addons\\evo_bataille_clans\\lua\\evo_bataille_clans\\cl_arena_editor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Bataille des Clans — éditeur d'arène SA (demi-sphère + copie config)
-- Ouverture : concommand `evo_bataille_arena` / SAM `bataille_arena`
-- ============================================================================

if not CLIENT then return end

EVO_BATAILLE = EVO_BATAILLE or {}

local function R(v)
    return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local COL = {
    bg     = Color(13, 14, 17, 245),
    panel  = Color(22, 22, 28, 255),
    field  = Color(16, 16, 20, 255),
    title  = Color(238, 239, 243),
    muted  = Color(150, 154, 162),
    accent = Color(207, 68, 78),
    yellow = Color(255, 200, 60),
    green  = Color(78, 196, 128),
    btn    = Color(30, 32, 38),
    btnH   = Color(50, 52, 62),
    border = Color(255, 255, 255, 18),
}

local frame = nil

local function ensureEditorState()
    local ed = EVO_BATAILLE._ArenaEditor
    if not ed then
        local arena = EVO_BATAILLE.GetArena and EVO_BATAILLE.GetArena(game.GetMap())
        local lp = LocalPlayer()
        local r = (arena and arena.radius) or 1500
        local h = (EVO_BATAILLE.GetArenaHeight and EVO_BATAILLE.GetArenaHeight(arena)) or r
        ed = {
            preview     = false, -- dessiner la demi-sphère
            keepPreview = false, -- conserver le dessin après fermeture du panneau
            center = (arena and arena.center) or (IsValid(lp) and lp:GetPos()) or Vector(0, 0, 0),
            radius = r,
            height = h,
        }
        EVO_BATAILLE._ArenaEditor = ed
    elseif ed.height == nil then
        ed.height = ed.radius or 1500
    end
    return ed
end

local function fmtVec(v)
    return string.format("%.2f, %.2f, %.2f", v.x, v.y, v.z)
end

local function buildSnippet(center, radius, height)
    local map = game.GetMap()
    return table.concat({
        '["' .. map .. '"] = {',
        string.format("    center = Vector(%s),", fmtVec(center)),
        string.format("    radius = %d,", math.floor(radius + 0.5)),
        string.format("    height = %d,", math.floor(height + 0.5)),
        "},",
    }, "\n")
end

local function makeBtn(parent, text, colBg, colHover, onClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetText("")
    btn.Paint = function(s, w, h)
        local c = s:IsHovered() and colHover or colBg
        surface.SetDrawColor(c)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COL.border)
        surface.DrawOutlinedRect(0, 0, w, h)
        draw.SimpleText(text, "EVO_Bataille_Small", w / 2, h / 2, COL.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btn.DoClick = function()
        surface.PlaySound("buttons/button14.wav")
        if onClick then onClick() end
    end
    return btn
end

local function closeEditor()
    local ed = EVO_BATAILLE._ArenaEditor
    if ed then
        ed.preview = ed.keepPreview == true
    end
    if IsValid(frame) then
        frame._closing = true
        frame:Remove()
    end
    frame = nil
end

function EVO_BATAILLE.OpenArenaEditorPanel()
    if IsValid(frame) then frame:Remove() end

    local ed = ensureEditorState()
    ed.preview = true -- toujours visible tant que le panneau est ouvert

    local W, H = R(420), R(480)
    frame = vgui.Create("DFrame")
    frame:SetSize(W, H)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(true)
    frame:MakePopup()
    frame:Center()
    frame.Paint = function(_, w, h)
        surface.SetDrawColor(COL.bg)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(COL.accent)
        surface.DrawRect(0, 0, R(3), h)
        draw.SimpleText("ARÈNE — BATAILLE DES CLANS", "EVO_Bataille_Text", R(18), R(14), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText(game.GetMap(), "EVO_Bataille_Small", R(18), R(42), COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    frame.OnClose = closeEditor
    frame.OnRemove = function(s)
        if s._closing then return end -- déjà géré par closeEditor
        local e = EVO_BATAILLE._ArenaEditor
        if e then e.preview = e.keepPreview == true end
    end

    local closeX = vgui.Create("DButton", frame)
    closeX:SetText("")
    closeX:SetSize(R(34), R(34))
    closeX:SetPos(W - R(42), R(10))
    closeX.Paint = function(s, w, h)
        draw.SimpleText("✕", "EVO_Bataille_Small", w / 2, h / 2, s:IsHovered() and COL.accent or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    closeX.DoClick = closeEditor

    -- Centre
    local y = R(78)
    local lblC = vgui.Create("DLabel", frame)
    lblC:SetPos(R(18), y)
    lblC:SetSize(W - R(36), R(20))
    lblC:SetFont("EVO_Bataille_Small")
    lblC:SetTextColor(COL.muted)
    lblC:SetText("CENTRE")

    local valC = vgui.Create("DLabel", frame)
    valC:SetPos(R(18), y + R(22))
    valC:SetSize(W - R(36), R(22))
    valC:SetFont("EVO_Bataille_Small")
    valC:SetTextColor(COL.yellow)
    valC:SetText(fmtVec(ed.center))

    local btnCenter = makeBtn(frame, "CENTRE = MA POSITION", COL.btn, COL.btnH, function()
        local lp = LocalPlayer()
        if not IsValid(lp) then return end
        ed.center = lp:GetPos()
        valC:SetText(fmtVec(ed.center))
    end)
    btnCenter:SetPos(R(18), y + R(50))
    btnCenter:SetSize(W - R(36), R(36))

    -- Rayon
    y = y + R(100)
    local lblR = vgui.Create("DLabel", frame)
    lblR:SetPos(R(18), y)
    lblR:SetSize(W - R(36), R(20))
    lblR:SetFont("EVO_Bataille_Small")
    lblR:SetTextColor(COL.muted)
    lblR:SetText("RAYON")

    local num = vgui.Create("DNumberWang", frame)
    num:SetPos(R(18), y + R(24))
    num:SetSize(R(120), R(28))
    num:SetMin(50)
    num:SetMax(20000)
    num:SetDecimals(0)
    num:SetValue(ed.radius)
    num.OnValueChanged = function(_, v)
        ed.radius = math.Clamp(tonumber(v) or ed.radius, 50, 20000)
    end

    local slider = vgui.Create("DNumSlider", frame)
    slider:SetPos(R(150), y + R(18))
    slider:SetSize(W - R(168), R(40))
    slider:SetText("")
    slider:SetMin(50)
    slider:SetMax(5000)
    slider:SetDecimals(0)
    slider:SetValue(ed.radius)
    slider.Label:SetVisible(false)
    slider.TextArea:SetVisible(false)
    slider.OnValueChanged = function(_, v)
        ed.radius = math.Clamp(tonumber(v) or ed.radius, 50, 20000)
        if IsValid(num) then num:SetValue(ed.radius) end
    end

    -- Hauteur visuelle (demi-sphère ellipsoïde)
    y = y + R(70)
    local lblH = vgui.Create("DLabel", frame)
    lblH:SetPos(R(18), y)
    lblH:SetSize(W - R(36), R(20))
    lblH:SetFont("EVO_Bataille_Small")
    lblH:SetTextColor(COL.muted)
    lblH:SetText("HAUTEUR (DÔME + LOGIQUE)")

    local numH = vgui.Create("DNumberWang", frame)
    numH:SetPos(R(18), y + R(24))
    numH:SetSize(R(120), R(28))
    numH:SetMin(50)
    numH:SetMax(20000)
    numH:SetDecimals(0)
    numH:SetValue(ed.height)
    numH.OnValueChanged = function(_, v)
        ed.height = math.Clamp(tonumber(v) or ed.height, 50, 20000)
    end

    local sliderH = vgui.Create("DNumSlider", frame)
    sliderH:SetPos(R(150), y + R(18))
    sliderH:SetSize(W - R(168), R(40))
    sliderH:SetText("")
    sliderH:SetMin(50)
    sliderH:SetMax(5000)
    sliderH:SetDecimals(0)
    sliderH:SetValue(ed.height)
    sliderH.Label:SetVisible(false)
    sliderH.TextArea:SetVisible(false)
    sliderH.OnValueChanged = function(_, v)
        ed.height = math.Clamp(tonumber(v) or ed.height, 50, 20000)
        if IsValid(numH) then numH:SetValue(ed.height) end
    end

    -- Garder la preview à la fermeture
    y = y + R(70)
    local chk = vgui.Create("DCheckBoxLabel", frame)
    chk:SetPos(R(18), y)
    chk:SetSize(W - R(36), R(24))
    chk:SetFont("EVO_Bataille_Small")
    chk:SetTextColor(COL.title)
    chk:SetText("Garder la demi-sphère après fermeture")
    chk:SetValue(ed.keepPreview and 1 or 0)
    chk:SizeToContents()
    chk.OnChange = function(_, b)
        ed.keepPreview = b and true or false
    end

    local hint = vgui.Create("DLabel", frame)
    hint:SetPos(R(18), y + R(30))
    hint:SetSize(W - R(36), R(36))
    hint:SetFont("EVO_Bataille_Small")
    hint:SetTextColor(COL.muted)
    hint:SetWrap(true)
    hint:SetText("Décoche puis referme le panneau pour masquer la preview persistante.")

    -- Copier
    local btnCopy = makeBtn(frame, "COPIER LE SNIPPET CONFIG", Color(40, 90, 55), COL.green, function()
        local snip = buildSnippet(ed.center, ed.radius, ed.height)
        SetClipboardText(snip)
        notification.AddLegacy("Snippet arène copié — colle-le dans Arenas de sh_config.lua", NOTIFY_GENERIC, 4)
        MsgC(COL.green, "[EVO_Bataille] ", COL.title, "Config copiée:\n", snip, "\n")
    end)
    btnCopy:SetPos(R(18), H - R(54))
    btnCopy:SetSize(W - R(36), R(40))
end

net.Receive("EVO_Bataille:OpenArenaEditor", function()
    EVO_BATAILLE.OpenArenaEditorPanel()
end)
