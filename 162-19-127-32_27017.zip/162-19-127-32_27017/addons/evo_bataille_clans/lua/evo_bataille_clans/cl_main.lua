-- "addons\\evo_bataille_clans\\lua\\evo_bataille_clans\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Bataille des Clans — client : demi-sphère, HUD, popup, bannière
-- ============================================================================

if not CLIENT then return end

EVO_BATAILLE = EVO_BATAILLE or {}
local CFG = EVO_BATAILLE.Config

local function R(v)
    return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local function COL()
    return EVO_UI and EVO_UI.Col or {
        bg = Color(16, 16, 19, 250), title = Color(238, 239, 243), muted = Color(150, 154, 162),
        dim = Color(106, 109, 118), accent = Color(207, 68, 78), green = Color(78, 196, 128),
        line = Color(255, 255, 255, 16),
    }
end

local function makeFonts()
    local mk = gCreateRespFont
    if not mk then
        local sc = math.max(1, ScrH() / 1080)
        mk = function(name, font, size)
            surface.CreateFont(name, { font = font, size = math.Round(size * sc), weight = 400, extended = true })
        end
    end
    mk("EVO_Bataille_Small", "Bebas Neue", 22, 400)
    mk("EVO_Bataille_Text",  "Bebas Neue", 28, 400)
    mk("EVO_Bataille_Head",  "Bebas Neue", 36, 400)
    mk("EVO_Bataille_AnnTitle", "Roboto", 17, 800)
    mk("EVO_Bataille_AnnName",  "Roboto", 30, 800)
    mk("EVO_Bataille_AnnSub",   "Roboto", 18, 500)
end
makeFonts()
hook.Add("Initialize", "EVO_Bataille::Fonts", makeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Bataille::Fonts", makeFonts)

-- Ancré haut-gauche (plus haut que les cartes d'event instructeur @ 13% H).
local function HudTopY()
    return R(12)
end

-- ── State ───────────────────────────────────────────────────────────────────

local elig = {
    see = false,
    hasArena = false,
    center = Vector(0, 0, 0),
    radius = 0,
    height = 0,
}

local killFeed = {} -- { { killer=, victim=, time= }, ... }

local hud = {
    active = false,
    sudden = false,
    remain = 0,
    clans = {}, -- { {name=, n=}, ... }
    recvAt = 0,
}

--- Client : le LP est dans la Bataille (HUD event actif) — masque le tracker quêtes.
function EVO_BATAILLE.IsLocalInEvent()
    return hud.active == true
end

local exitWarn = {
    active = false,
    endsAt = 0,
}

local banner = nil -- { kind, name, born, expire }

-- ── Nets ────────────────────────────────────────────────────────────────────

net.Receive("EVO_Bataille:Eligibility", function()
    elig.see = net.ReadBool()
    elig.hasArena = net.ReadBool()
    if elig.hasArena then
        elig.center = net.ReadVector()
        elig.radius = net.ReadFloat()
        elig.height = net.ReadFloat()
        if not elig.height or elig.height <= 0 then
            elig.height = elig.radius
        end
    end
end)

net.Receive("EVO_Bataille:KillFeed", function()
    local killer = net.ReadString()
    local victim = net.ReadString()
    table.insert(killFeed, 1, { killer = killer, victim = victim, time = CurTime() })
    while #killFeed > 5 do table.remove(killFeed) end
end)

net.Receive("EVO_Bataille:Hud", function()
    local active = net.ReadBool()
    if not active then
        hud.active = false
        hud.clans = {}
        killFeed = {}
        return
    end
    hud.active = true
    hud.sudden = net.ReadBool()
    hud.remain = net.ReadUInt(16)
    hud.recvAt = CurTime()
    local n = net.ReadUInt(8)
    hud.clans = {}
    for i = 1, n do
        hud.clans[i] = { name = net.ReadString(), n = net.ReadUInt(8) }
    end
end)

net.Receive("EVO_Bataille:ExitWarn", function()
    local on = net.ReadBool()
    local grace = net.ReadFloat()
    if on then
        exitWarn.active = true
        exitWarn.endsAt = CurTime() + grace
    else
        exitWarn.active = false
    end
end)

net.Receive("EVO_Bataille:Banner", function()
    local kind = net.ReadString()
    local name = net.ReadString()
    local now = RealTime()
    local dur = (CFG and CFG.BannerDuration) or 10
    banner = { kind = kind, name = name, born = now, expire = now + dur }
    local snd = (CFG and CFG.BannerSound) or "friends/friend_online.wav"
    surface.PlaySound(snd)
end)

-- Popup yes → confirm enter
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.BatailleEnter = function(_args)
    net.Start("EVO_Bataille:EnterConfirm")
    net.SendToServer()
end

-- ── Yellow demi-sphere (filled translucent shell) ───────────────────────────

local SEG_LON = 32
local SEG_LAT = 12
local FILL   = Color(255, 210, 40, 55)
local EDGE   = Color(255, 220, 60, 160)
local GROUND = Color(255, 200, 40, 40)

local function hemiPoint(center, radius, height, lat, lon)
    -- lat 0 = equator (sol), lat pi/2 = pôle — ellipsoïde (radius XY, height Z)
    local c = math.cos(lat)
    return Vector(
        center.x + radius * c * math.cos(lon),
        center.y + radius * c * math.sin(lon),
        center.z + height * math.sin(lat)
    )
end

local function drawQuadBoth(a, b, c, d, col)
    render.DrawQuad(a, b, c, d, col)
    render.DrawQuad(d, c, b, a, col) -- face arrière (visible de l'intérieur)
end

function EVO_BATAILLE.DrawHemiSphere(center, radius, height)
    if not center or not radius or radius <= 0 then return end
    height = tonumber(height)
    if not height or height <= 0 then height = radius end
    render.SetColorMaterial()

    local halfPi = math.pi * 0.5
    local twoPi  = math.pi * 2

    -- Coque remplie (bandes lat × lon)
    for li = 0, SEG_LAT - 1 do
        local lat1 = (li / SEG_LAT) * halfPi
        local lat2 = ((li + 1) / SEG_LAT) * halfPi
        for lo = 0, SEG_LON - 1 do
            local lon1 = (lo / SEG_LON) * twoPi
            local lon2 = ((lo + 1) / SEG_LON) * twoPi
            local p1 = hemiPoint(center, radius, height, lat1, lon1)
            local p2 = hemiPoint(center, radius, height, lat1, lon2)
            local p3 = hemiPoint(center, radius, height, lat2, lon2)
            local p4 = hemiPoint(center, radius, height, lat2, lon1)
            drawQuadBoth(p1, p2, p3, p4, FILL)
        end
    end

    -- Disque au sol (équateur) — fan depuis le centre
    local origin = Vector(center.x, center.y, center.z)
    for lo = 0, SEG_LON - 1 do
        local lon1 = (lo / SEG_LON) * twoPi
        local lon2 = ((lo + 1) / SEG_LON) * twoPi
        local a = hemiPoint(center, radius, height, 0, lon1)
        local b = hemiPoint(center, radius, height, 0, lon2)
        drawQuadBoth(origin, a, b, origin, GROUND)
    end

    -- Contour léger (équateur + quelques méridiens) pour lisibilité
    for lo = 0, SEG_LON - 1 do
        local lon1 = (lo / SEG_LON) * twoPi
        local lon2 = ((lo + 1) / SEG_LON) * twoPi
        render.DrawLine(hemiPoint(center, radius, height, 0, lon1), hemiPoint(center, radius, height, 0, lon2), EDGE, true)
    end
    local meridians = 8
    for mi = 0, meridians - 1 do
        local lon = (mi / meridians) * twoPi
        for li = 0, SEG_LAT - 1 do
            local lat1 = (li / SEG_LAT) * halfPi
            local lat2 = ((li + 1) / SEG_LAT) * halfPi
            render.DrawLine(hemiPoint(center, radius, height, lat1, lon), hemiPoint(center, radius, height, lat2, lon), EDGE, true)
        end
    end
end

hook.Add("PostDrawTranslucentRenderables", "EVO_Bataille::Dome", function(bDepth, bSky)
    if bDepth or bSky then return end
    -- Preview éditeur SA (panneau ouvert OU gardé après fermeture)
    local ed = EVO_BATAILLE._ArenaEditor
    if ed and ed.preview and ed.center and ed.radius then
        EVO_BATAILLE.DrawHemiSphere(ed.center, ed.radius, ed.height)
        return
    end
    if not elig.see or not elig.hasArena then return end
    EVO_BATAILLE.DrawHemiSphere(elig.center, elig.radius, elig.height)
end)

-- ── Live HUD ────────────────────────────────────────────────────────────────

local function formatTimer(sec)
    sec = math.max(0, math.floor(sec))
    local m = math.floor(sec / 60)
    local s = sec % 60
    return string.format("%02d:%02d", m, s)
end

hook.Add("HUDPaint", "EVO_Bataille::Hud", function()
    local col = COL()

    -- Exit grace warning (mid-screen)
    if exitWarn.active then
        local left = math.max(0, exitWarn.endsAt - CurTime())
        if left <= 0 then
            exitWarn.active = false
        else
            draw.SimpleText(
                string.format("REVIENS DANS LA ZONE — %d", math.ceil(left)),
                "EVO_Bataille_Head",
                ScrW() * 0.5, ScrH() * 0.42,
                Color(255, 200, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
            )
        end
    end

    if not hud.active then return end

    -- Local countdown from last snapshot
    local remain = hud.remain
    if not hud.sudden then
        remain = math.max(0, hud.remain - math.floor(CurTime() - (hud.recvAt or CurTime())))
    end

    local title = (CFG and CFG.HudTitle) or "BATAILLE DES CLANS"
    local timerTxt = hud.sudden and "EN COURS" or formatTimer(remain)

    local lines = {}
    for _, c in ipairs(hud.clans) do
        lines[#lines + 1] = string.format("%s  —  %d", c.name or "?", c.n or 0)
    end
    if #lines == 0 then
        lines[1] = "Aucun clan en vie"
    end

    surface.SetFont("EVO_Bataille_Small")
    local tw = surface.GetTextSize(title)
    surface.SetFont("EVO_Bataille_Head")
    local hw = surface.GetTextSize(timerTxt)
    local maxW = math.max(tw, hw)
    surface.SetFont("EVO_Bataille_Text")
    for _, ln in ipairs(lines) do
        maxW = math.max(maxW, surface.GetTextSize(ln))
    end

    local padX, padY = R(28), R(14)
    local lineH = R(26)
    local boxW = maxW + padX * 2
    local boxH = padY + R(22) + R(8) + R(34) + R(8) + (#lines * lineH) + padY
    local x = R(15)
    local y = HudTopY()

    -- Badge INSTANCE au-dessus du HUD event (remplace le badge centre de ncm_instance)
    local sZone = (CFG and CFG.ZoneID) or "bataille_des_clans"
    local sBadge = "INSTANCE : " .. string.upper(sZone)
    local badgeFont = "NCM_Instance_Badge"
    surface.SetFont(badgeFont)
    local btw, bth = surface.GetTextSize(sBadge)
    if btw <= 0 then
        badgeFont = "EVO_Bataille_Small"
        surface.SetFont(badgeFont)
        btw, bth = surface.GetTextSize(sBadge)
    end
    local badgeH = bth + R(10)
    local badgeW = math.max(boxW, btw + R(20))
    surface.SetDrawColor(13, 14, 17, 220)
    surface.DrawRect(x, y, badgeW, badgeH)
    surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 255)
    surface.DrawRect(x, y, R(2), badgeH)
    draw.SimpleText(sBadge, badgeFont, x + R(10), y + R(5), col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    y = y + badgeH + R(6)

    surface.SetDrawColor(13, 14, 17, 230)
    surface.DrawRect(x, y, boxW, boxH)
    surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 255)
    surface.DrawRect(x, y, R(3), boxH)

    local tx = x + padX
    local ty = y + padY
    draw.SimpleText(title, "EVO_Bataille_Small", tx, ty, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    ty = ty + R(22) + R(4)
    draw.SimpleText(timerTxt, "EVO_Bataille_Head", tx, ty, hud.sudden and Color(255, 200, 60) or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    ty = ty + R(34) + R(4)
    for _, ln in ipairs(lines) do
        draw.SimpleText(ln, "EVO_Bataille_Text", tx, ty, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        ty = ty + lineH
    end

    -- Killfeed sous le panneau event (uniquement pendant l'event)
    local feedY = y + boxH + R(8)
    local feedH = R(24)
    surface.SetFont("EVO_Bataille_Small")
    for i = #killFeed, 1, -1 do
        local feed = killFeed[i]
        local age = CurTime() - (feed.time or 0)
        if age > 6 then
            table.remove(killFeed, i)
        end
    end
    for i, feed in ipairs(killFeed) do
        local age = CurTime() - feed.time
        if age > 6 then continue end
        local alpha = age > 4.5 and math.floor(255 * (1 - (age - 4.5) / 1.5)) or 255
        local sep = "  →  "
        local killer = feed.killer or "?"
        local victim = feed.victim or "?"
        local tk = surface.GetTextSize(killer)
        local ts = surface.GetTextSize(sep)
        local tv = surface.GetTextSize(victim)
        local fW = tk + ts + tv + R(20)
        local fY = feedY + (i - 1) * (feedH + R(4))

        surface.SetDrawColor(13, 14, 17, math.floor(alpha * 0.9))
        surface.DrawRect(x, fY, fW, feedH)
        surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, alpha)
        surface.DrawRect(x, fY, R(2), feedH)

        local px = x + R(10)
        local cy = fY + feedH * 0.5
        draw.SimpleText(killer, "EVO_Bataille_Small", px, cy,
            Color(col.accent.r, col.accent.g, col.accent.b, alpha),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(sep, "EVO_Bataille_Small", px + tk, cy,
            Color(col.muted.r, col.muted.g, col.muted.b, alpha),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(victim, "EVO_Bataille_Small", px + tk + ts, cy,
            Color(col.title.r, col.title.g, col.title.b, alpha),
            TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end)

-- ── Win / cancel banner ─────────────────────────────────────────────────────

hook.Add("HUDPaint", "EVO_Bataille::Banner", function()
    if not banner then return end
    local now = RealTime()
    if now >= banner.expire then banner = nil return end

    local col = COL()
    local appear = math.Clamp((now - banner.born) / 0.4, 0, 1)
    local fade = math.Clamp((banner.expire - now) / 1.0, 0, 1)
    local A = 255 * fade

    local isWin = (banner.kind or "win") == "win"
    local label = isWin and "BATAILLE DES CLANS" or "BATAILLE ANNULÉE"
    local name = isWin
        and ((banner.name ~= "" and (banner.name .. " remporte la bataille")) or "Victoire")
        or "Un seul clan présent — consolation versée"
    local accent = isWin and Color(255, 200, 60) or col.muted

    surface.SetFont("EVO_Bataille_AnnTitle")
    local lw = surface.GetTextSize(label)
    surface.SetFont("EVO_Bataille_AnnName")
    local nw = surface.GetTextSize(name)
    local accW = R(46)
    local padX = R(42)
    local boxW = math.max(lw, nw, accW) + padX * 2
    local boxH = R(16) + R(20) + R(9) + R(2) + R(11) + R(34) + R(16)
    local boxX = math.floor((ScrW() - boxW) * 0.5)
    local boxY = math.floor(Lerp(appear, -boxH - R(20), R(70)))
    local cx = math.floor(ScrW() * 0.5)

    surface.SetDrawColor(13, 13, 16, A)
    surface.DrawRect(boxX, boxY, boxW, boxH)
    surface.SetDrawColor(accent.r, accent.g, accent.b, math.floor(A * 0.5))
    surface.DrawOutlinedRect(boxX, boxY, boxW, boxH)

    local y = boxY + R(16)
    draw.SimpleText(label, "EVO_Bataille_AnnTitle", cx, y, ColorAlpha(accent, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    y = y + R(20) + R(9)
    surface.SetDrawColor(accent.r, accent.g, accent.b, A)
    surface.DrawRect(math.floor(cx - accW * 0.5), y, accW, R(2))
    y = y + R(2) + R(11)
    draw.SimpleText(name, "EVO_Bataille_AnnName", cx, y, ColorAlpha(col.title, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)
