-- "addons\\evo_bataille_clans\\lua\\autorun\\sh_loader_bataille_clans.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BATAILLE DES CLANS — event PvP planifié (Mer/Sam 21h), instance partagée.
-- ============================================================================

EVO_BATAILLE = EVO_BATAILLE or {}

if SERVER then
    AddCSLuaFile("evo_bataille_clans/sh_config.lua")
    AddCSLuaFile("evo_bataille_clans/sh_geometry.lua")
    AddCSLuaFile("evo_bataille_clans/cl_main.lua")
    AddCSLuaFile("evo_bataille_clans/cl_arena_editor.lua")

    util.AddNetworkString("EVO_Bataille:Eligibility")
    util.AddNetworkString("EVO_Bataille:Arena")
    util.AddNetworkString("EVO_Bataille:EnterConfirm")
    util.AddNetworkString("EVO_Bataille:Hud")
    util.AddNetworkString("EVO_Bataille:ExitWarn")
    util.AddNetworkString("EVO_Bataille:Banner")
    util.AddNetworkString("EVO_Bataille:OpenArenaEditor")
    util.AddNetworkString("EVO_Bataille:KillFeed")
end

include("evo_bataille_clans/sh_config.lua")
include("evo_bataille_clans/sh_geometry.lua")

if SERVER then
    include("evo_bataille_clans/sv_cross.lua")
    include("evo_bataille_clans/sv_main.lua")
else
    include("evo_bataille_clans/cl_main.lua")
    include("evo_bataille_clans/cl_arena_editor.lua")
end
