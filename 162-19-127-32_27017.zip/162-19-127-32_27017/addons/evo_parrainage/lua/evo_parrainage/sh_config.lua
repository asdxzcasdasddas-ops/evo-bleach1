-- "addons\\evo_parrainage\\lua\\evo_parrainage\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PARRAINAGE — constantes partagées (seuils, pièces, cosmétiques de palier).
-- Pets d'épaule unisexes (lama + poupées), exclusifs palier (palier_only boutique).
-- ============================================================================

EVO_Parrainage = EVO_Parrainage or {}

EVO_Parrainage.CODE_MIN = 4
EVO_Parrainage.CODE_MAX = 16

EVO_Parrainage.SUCCESS_LEVEL = 10
EVO_Parrainage.COINS_PARRAIN = 100
EVO_Parrainage.COINS_FILLEUL = 300

-- Compte de succès (filleuls niveau 10) pour chaque palier cosmétique.
EVO_Parrainage.TIER_COUNTS = { 10, 20, 30, 40 }
EVO_Parrainage.TIER_COUNT = 4

EVO_Parrainage.HOW_IT_WORKS = {
	"Crée un code unique et partage-le. Un nouveau joueur le saisit à la création de son premier personnage.",
	"Quand ce personnage atteint le niveau 10, tu gagnes 1 succès de parrainage et 100 EVO Coins. Ton filleul gagne 300 EVO Coins.",
	"10, 20, 30 et 40 succès débloquent des cosmétiques exclusifs (barre du bas).",
}

-- Cosmétique du palier n (1..4) : pets d'épaule unisexes (même id faction + sexe).
EVO_Parrainage.TIER_OUTFITS = {
	["Shinigami"] = {
		m = { [1] = "pet_lama_peluche", [2] = "pet_doll_ikkaku", [3] = "pet_doll_nnoitra", [4] = "pet_doll_yamamoto" },
		f = { [1] = "pet_lama_peluche", [2] = "pet_doll_ikkaku", [3] = "pet_doll_nnoitra", [4] = "pet_doll_yamamoto" },
	},
	["Hollow"] = {
		m = { [1] = "pet_lama_peluche", [2] = "pet_doll_ikkaku", [3] = "pet_doll_nnoitra", [4] = "pet_doll_yamamoto" },
		f = { [1] = "pet_lama_peluche", [2] = "pet_doll_ikkaku", [3] = "pet_doll_nnoitra", [4] = "pet_doll_yamamoto" },
	},
}

-- Perso qui CONSOMME le droit au code : slot RP, ni âme errante, ni larve Hollow.
-- La larve n'est qu'un intermédiaire : le 1er vrai perso Hollow = l'Arrancar (finalisation).
function EVO_Parrainage.IsEligibleCharRow(row)
	if not istable(row) then return false end
	if EVO_LostSoul and EVO_LostSoul.IsRealCharRow then
		if not EVO_LostSoul.IsRealCharRow(row) then return false end
	else
		local slot = tonumber(row.slot)
		if slot and slot > 3 then return false end
	end
	if EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(row.body_model) then
		return false
	end
	return true
end

function EVO_Parrainage.CountEligibleChars(list)
	local n = 0
	for _, row in pairs(istable(list) and list or {}) do
		if EVO_Parrainage.IsEligibleCharRow(row) then n = n + 1 end
	end
	return n
end

function EVO_Parrainage.NormalizeCode(s)
	if not isstring(s) then return "" end
	s = string.upper(string.gsub(s, "%s+", ""))
	return s
end

function EVO_Parrainage.IsValidCodeFormat(s)
	s = EVO_Parrainage.NormalizeCode(s)
	local n = #s
	if n < EVO_Parrainage.CODE_MIN or n > EVO_Parrainage.CODE_MAX then return false end
	return string.match(s, "^[A-Z0-9]+$") ~= nil
end

function EVO_Parrainage.TierNeed(nTier)
	return EVO_Parrainage.TIER_COUNTS[nTier] or 0
end

function EVO_Parrainage.TierOutfit(ply, nTier)
	if not IsValid(ply) then return "" end
	local t = EVO_Parrainage.TIER_OUTFITS[ply:GetEvoNWString("FactionName", "")]
	local g = string.lower(ply:GetEvoNWString("Gender", "m"))
	g = (g == "f" or g == "female") and "f" or "m"
	return (t and t[g] and t[g][nTier]) or ""
end

-- Pet de palier parrainage ? Même garde que les tenues de dépense boutique :
-- unlock compte non révoqué si le joueur jette l'item (non rachetable).
local _parrainageTierIds
function EVO_Parrainage.IsTierOutfit(item_id)
	if not isstring(item_id) or item_id == "" then return false end
	if not _parrainageTierIds then
		_parrainageTierIds = {}
		for _, fac in pairs(EVO_Parrainage.TIER_OUTFITS or {}) do
			for _, g in pairs(fac) do
				for _, id in pairs(g) do
					if isstring(id) and id ~= "" then _parrainageTierIds[id] = true end
				end
			end
		end
	end
	return _parrainageTierIds[item_id] == true
end
