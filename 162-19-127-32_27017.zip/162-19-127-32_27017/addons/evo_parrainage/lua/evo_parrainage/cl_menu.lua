-- "addons\\evo_parrainage\\lua\\evo_parrainage\\cl_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PARRAINAGE — overlay menu (Échap). Plaque Atelier, code custom,
-- liste des filleuls, cosmétiques de palier visibles en bas (sans popup).
-- ============================================================================

local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)
local COL_OK     = Color(78, 196, 128)
local COL_GOLD   = Color(255, 205, 60)

EVO_Parrainage = EVO_Parrainage or {}
EVO_Parrainage.Client = EVO_Parrainage.Client or {
	code = "",
	success = 0,
	claimed = 0,
	filleuls = {},
}

local State = EVO_Parrainage.Client
local frame

local function makeFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("LZY.Parrain.Title", "Bebas Neue", 46, 400)
	gCreateRespFont("LZY.Parrain.Section", "Bebas Neue", 28, 400)
	gCreateRespFont("LZY.Parrain.Nav", "Bebas Neue", 22, 400)
	gCreateRespFont("LZY.Parrain.Body", "Avenir Next World", 17, 500)
	gCreateRespFont("LZY.Parrain.Code", "Bebas Neue", 36, 400)
	gCreateRespFont("LZY.Parrain.Chip", "Bebas Neue", 18, 400)
	gCreateRespFont("LZY.Parrain.Hint", "Avenir Next World", 15, 500)
end
hook.Add("Initialize", "LZY.Parrain.Fonts", makeFonts)
hook.Add("OnScreenSizeChanged", "LZY.Parrain.Fonts", makeFonts)
makeFonts()

local function wrapText(text, font, maxW)
	surface.SetFont(font)
	local lines, cur = {}, ""
	for _, wd in ipairs(string.Explode(" ", text or "")) do
		local try = cur == "" and wd or (cur .. " " .. wd)
		if select(1, surface.GetTextSize(try)) > maxW and cur ~= "" then
			lines[#lines + 1] = cur
			cur = wd
		else
			cur = try
		end
	end
	if cur ~= "" then lines[#lines + 1] = cur end
	return lines
end

local function requestSync()
	net.Start("evo_parrainage.sync")
	net.SendToServer()
end

net.Receive("evo_parrainage.state", function()
	State.code = net.ReadString() or ""
	State.success = net.ReadUInt(16) or 0
	State.claimed = net.ReadUInt(EVO_Parrainage.TIER_COUNT or 4) or 0
	local n = net.ReadUInt(8) or 0
	local list = {}
	for i = 1, n do
		list[i] = {
			name = net.ReadString() or "",
			level = net.ReadUInt(16) or 0,
			rewarded = net.ReadBool() or false,
		}
	end
	State.filleuls = list
	if IsValid(frame) and frame.RebuildFilleuls then
		frame:RebuildFilleuls()
	end
end)

net.Receive("evo_parrainage.result", function()
	net.ReadBool()
	net.ReadString()
	-- Notifs serveur (MUGEN.Notify) ; le state suit si succès.
end)

local function paintPlate(x, y, w, h, col, cut)
	col = col or Color(13, 14, 17, 245)
	cut = cut or gRespY(10)
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, w, h, col, cut, "br")
	else
		surface.SetDrawColor(col)
		surface.DrawRect(x, y, w, h)
	end
end

function EVO_OpenParrainage()
	if IsValid(frame) then frame:Remove() end
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	makeFonts()
	requestSync()

	frame = vgui.Create("DFrame")
	local f = frame
	openedFrame = f
	f:SetSize(ScrW(), ScrH())
	f:SetPos(0, 0)
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:SetDraggable(false)
	f:SetPaintBackgroundEnabled(false)
	f:MakePopup()
	f.OnRemove = function(s)
		if openedFrame == s then openedFrame = nil end
		if frame == s then frame = nil end
	end
	local function close()
		if IsValid(f) then f:Remove() end
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(f, 5)
		else
			Derma_DrawBackgroundBlur(f, f.m_fCreateTime)
		end
		surface.SetDrawColor(5, 5, 7, 220)
		surface.DrawRect(0, 0, w, h)
	end
	f.OnMousePressed = function() close() end

	local W, H = gRespX(1180), gRespY(820)
	local card = vgui.Create("DPanel", f)
	card:SetSize(W, H)
	card:Center()
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, gRespY(16))
		else
			surface.SetDrawColor(13, 14, 17, 250)
			surface.DrawRect(0, 0, w, h)
		end
		local tx, ty = gRespX(28), gRespY(36)
		draw.SimpleText("PARRAINAGE", "LZY.Parrain.Title", tx, ty, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("LZY.Parrain.Title")
		local tw, th = surface.GetTextSize("PARRAINAGE")
		local slashY = ty + th * 0.28
		if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, tx - gRespX(2), slashY, tw * 1.12, gRespY(10), ColorAlpha(COL_ACCENT, 245))) then
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(tx, ty + th * 0.34, tw, math.max(2, gRespY(2)))
		end
		draw.SimpleText("EVO BLEACH RP", "LZY.Parrain.Nav", w - gRespX(56), ty, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	do
		local xb = vgui.Create("DButton", card)
		xb:SetText("")
		xb:SetSize(gRespX(34), gRespY(34))
		xb:SetPos(W - gRespX(48), gRespY(16))
		xb:SetCursor("hand")
		xb.Paint = function(s, bw, bh)
			draw.SimpleText("✕", "Avenir Next World Bold:26", bw / 2, bh / 2,
				s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		xb.DoClick = function()
			if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			close()
		end
	end

	local pad = gRespX(28)
	local headerH = gRespY(78)
	local palierH = gRespY(138)
	local palierY = H - palierH - gRespY(16)
	local leftW = gRespX(520)
	local gap = gRespX(18)
	local bodyY = headerH
	local bodyH = palierY - bodyY - gRespY(12)
	local rightX = pad + leftW + gap
	local rightW = W - rightX - pad

	-- ── Gauche : comment ça marche ──────────────────────────────────────────
	local left = vgui.Create("DPanel", card)
	left:SetPos(pad, bodyY)
	left:SetSize(leftW, bodyH)
	left.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, Color(8, 8, 10, 160), gRespY(10))
		draw.SimpleText("COMMENT ÇA MARCHE", "LZY.Parrain.Section", gRespX(18), gRespY(22), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(COL_ACCENT, 200))
		surface.DrawRect(gRespX(18), gRespY(36), gRespX(90), math.max(1, gRespY(2)))
	end

	local howY = gRespY(52)
	local howW = leftW - gRespX(36)
	local texts = EVO_Parrainage.HOW_IT_WORKS or {}
	local lineH = gRespY(22)
	local cursorY = howY
	for _, txt in ipairs(texts) do
		local lines = wrapText(txt, "LZY.Parrain.Body", howW)
		local block = vgui.Create("DPanel", left)
		block:SetPos(gRespX(18), cursorY)
		block:SetSize(howW, #lines * lineH + gRespY(10))
		block.Paint = function(_, w, h)
			for i, ln in ipairs(lines) do
				draw.SimpleText(ln, "LZY.Parrain.Body", 0, (i - 1) * lineH, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
		end
		cursorY = cursorY + #lines * lineH + gRespY(14)
	end

	-- ── Droite : code + filleuls ────────────────────────────────────────────
	local right = vgui.Create("DPanel", card)
	right:SetPos(rightX, bodyY)
	right:SetSize(rightW, bodyH)
	right.Paint = function() end

	local codeH = gRespY(150)
	local codePanel = vgui.Create("DPanel", right)
	codePanel:SetPos(0, 0)
	codePanel:SetSize(rightW, codeH)
	codePanel.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, Color(8, 8, 10, 160), gRespY(10))
		draw.SimpleText("TON CODE", "LZY.Parrain.Section", gRespX(18), gRespY(22), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(COL_ACCENT, 200))
		surface.DrawRect(gRespX(18), gRespY(36), gRespX(70), math.max(1, gRespY(2)))
	end

	local codeEntry = vgui.Create("DTextEntry", codePanel)
	codeEntry:SetPos(gRespX(18), gRespY(52))
	codeEntry:SetSize(rightW - gRespX(150), gRespY(48))
	codeEntry:SetFont("LZY.Parrain.Nav")
	if codeEntry.SetDrawLanguageID then codeEntry:SetDrawLanguageID(false) end
	codeEntry:SetUpdateOnType(true)
	codeEntry:SetPlaceholderText("4–16 lettres ou chiffres")
	codeEntry.AllowInput = function(s, ch)
		if not string.match(ch, "[A-Za-z0-9]") then return true end
		if #(s:GetValue() or "") >= (EVO_Parrainage.CODE_MAX or 16) then return true end
		return false
	end
	codeEntry._ph = "4–16 lettres ou chiffres"
	codeEntry.Paint = function(s, w, h)
		local on = s:IsEditing() or s:IsHovered()
		paintPlate(0, 0, w, h, on and Color(19, 21, 26, 245) or Color(13, 14, 17, 235), gRespY(8))
		local txt = s:GetText()
		local show = (txt ~= "" or s:IsEditing()) and txt or (s._ph or "")
		local col = (txt ~= "" or s:IsEditing()) and COL_TITLE or Color(255, 255, 255, 40)
		draw.SimpleText(show, "LZY.Parrain.Nav", gRespX(12), h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local codeBtn = vgui.Create("DButton", codePanel)
	codeBtn:SetPos(rightW - gRespX(122), gRespY(52))
	codeBtn:SetSize(gRespX(104), gRespY(48))
	codeBtn:SetText("")
	codeBtn:SetCursor("hand")
	codeBtn.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
		local bg = Color(207, 68, 78, 200 + 55 * hf)
		paintPlate(0, 0, w, h, bg, gRespY(8))
		draw.SimpleText("VALIDER", "LZY.Parrain.Nav", w / 2, h / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local codeShow = vgui.Create("DButton", codePanel)
	codeShow:SetPos(gRespX(18), gRespY(48))
	codeShow:SetSize(rightW - gRespX(150), gRespY(56))
	codeShow:SetText("")
	codeShow:SetCursor("hand")
	codeShow.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
		paintPlate(0, 0, w, h, Color(19, 21, 26, 245), gRespY(8))
		surface.SetDrawColor(ColorAlpha(COL_GOLD, 80 + 80 * hf))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(State.code ~= "" and State.code or "—", "LZY.Parrain.Code", gRespX(14), h / 2, COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	codeShow.DoClick = function()
		if State.code == "" then return end
		if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
		SetClipboardText(State.code)
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Code copié.", NOTIFY_GENERIC, 3) end
	end

	local copyBtn = vgui.Create("DButton", codePanel)
	copyBtn:SetPos(rightW - gRespX(122), gRespY(52))
	copyBtn:SetSize(gRespX(104), gRespY(48))
	copyBtn:SetText("")
	copyBtn:SetCursor("hand")
	copyBtn.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
		paintPlate(0, 0, w, h, Color(255, 255, 255, 10 + 14 * hf), gRespY(8))
		draw.SimpleText("COPIER", "LZY.Parrain.Nav", w / 2, h / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	copyBtn.DoClick = function()
		if State.code == "" then return end
		if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
		SetClipboardText(State.code)
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Code copié.", NOTIFY_GENERIC, 3) end
	end

	local hint = vgui.Create("DLabel", codePanel)
	hint:SetPos(gRespX(18), gRespY(110))
	hint:SetSize(rightW - gRespX(36), gRespY(28))
	hint:SetFont("LZY.Parrain.Hint")
	hint:SetTextColor(COL_MUTED)
	hint:SetContentAlignment(4)

	local function refreshCodeWidgets()
		local has = State.code ~= nil and State.code ~= ""
		codeEntry:SetVisible(not has)
		codeBtn:SetVisible(not has)
		codeShow:SetVisible(has)
		copyBtn:SetVisible(has)
		if has then
			hint:SetText("Clique pour copier. Les cosmétiques exclusifs sont en bas.")
		else
			hint:SetText("Choisis-le une fois : il ne pourra plus être changé.")
		end
	end
	refreshCodeWidgets()

	codeBtn.DoClick = function()
		if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
		local raw = codeEntry:GetValue() or codeEntry:GetText() or ""
		local code = EVO_Parrainage.NormalizeCode(raw)
		if not EVO_Parrainage.IsValidCodeFormat(code) then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("Code invalide : 4 à 16 lettres ou chiffres.", NOTIFY_ERROR, 4)
			end
			return
		end
		net.Start("evo_parrainage.set_code")
			net.WriteString(code)
		net.SendToServer()
	end

	-- Rebuild filleuls + code visibility when state arrives.
	local listY = codeH + gRespY(14)
	local listH = bodyH - listY
	local listPanel = vgui.Create("DPanel", right)
	listPanel:SetPos(0, listY)
	listPanel:SetSize(rightW, listH)
	listPanel.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, Color(8, 8, 10, 160), gRespY(10))
		draw.SimpleText("TES FILLEULS", "LZY.Parrain.Section", gRespX(18), gRespY(22), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(COL_ACCENT, 200))
		surface.DrawRect(gRespX(18), gRespY(36), gRespX(80), math.max(1, gRespY(2)))
	end

	local scroll = vgui.Create("DScrollPanel", listPanel)
	scroll:SetPos(gRespX(10), gRespY(48))
	scroll:SetSize(rightW - gRespX(20), listH - gRespY(58))
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end

	local emptyLbl = vgui.Create("DLabel", listPanel)
	emptyLbl:SetPos(gRespX(18), gRespY(60))
	emptyLbl:SetSize(rightW - gRespX(36), gRespY(40))
	emptyLbl:SetFont("LZY.Parrain.Hint")
	emptyLbl:SetTextColor(COL_DIM)
	emptyLbl:SetText("Aucun personnage n'a encore utilisé ton code.")
	emptyLbl:SetWrap(true)

	function f:RebuildFilleuls()
		refreshCodeWidgets()
		scroll:Clear()
		local rows = State.filleuls or {}
		emptyLbl:SetVisible(#rows == 0)
		for _, row in ipairs(rows) do
			local line = vgui.Create("DPanel", scroll)
			line:Dock(TOP)
			line:DockMargin(gRespX(6), 0, gRespX(6), gRespY(4))
			line:SetTall(gRespY(36))
			line._row = row
			line.Paint = function(s, w, h)
				local r = s._row
				paintPlate(0, 0, w, h, Color(255, 255, 255, 6), gRespY(6))
				local nameCol = r.rewarded and COL_OK or COL_TITLE
				draw.SimpleText(r.name, "LZY.Parrain.Body", gRespX(10), h / 2, nameCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local tag = "Niv. " .. tostring(r.level or 0)
				if r.rewarded then tag = tag .. "  ·  succès" end
				draw.SimpleText(tag, "LZY.Parrain.Hint", w - gRespX(12), h / 2, r.rewarded and COL_OK or COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	if EVO_Parrainage.BuildPalierUI then
		EVO_Parrainage.BuildPalierUI(card, pad, palierY, W - pad * 2, palierH, card)
	end
end
