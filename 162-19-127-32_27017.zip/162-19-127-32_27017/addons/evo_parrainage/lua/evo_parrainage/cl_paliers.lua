-- "addons\\evo_parrainage\\lua\\evo_parrainage\\cl_paliers.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Use the shared preview queue without changing this menu's framing.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

-- ============================================================================
-- EVO PARRAINAGE — barre des cosmétiques exclusifs (paliers 10 / 20 / 30 / 40).
-- MÊME recette que la barre boutique (PaintSpendBar) : plaque or, filet, vis,
-- jauge dégradé + balayage, losanges, médaillons COSMÉTIQUE I–IV au-dessus.
-- ============================================================================

local COL_TITLE    = Color(238, 239, 243)
local COL_MUTED    = Color(150, 154, 162)
local COL_SBAR     = Color(255, 205, 60)
local COL_SBAR_B   = Color(196, 142, 26)
local COL_SBAR_TXT = Color(20, 16, 6, 255)
local COL_OK       = Color(78, 196, 128)
local COL_BAR_PLATE = Color(13, 14, 17, 242)
local COL_BAR_TRACK = Color(23, 24, 29, 235)
local COL_BAR_LOCK  = Color(70, 72, 80, 255)
local COL_SHINE     = Color(255, 255, 255, 70)

local MAT_GRAD_R = Material("vgui/gradient-r")
local MAT_GRAD_U = Material("vgui/gradient-u")
local ROMANS = { "I", "II", "III", "IV" }
local PALIER_MAX = 40

local function State()
	return EVO_Parrainage.Client or { success = 0, claimed = 0 }
end

local function tierClaimed(i)
	return bit.band(State().claimed or 0, bit.lshift(1, i - 1)) ~= 0
end

local function closeTip(panel)
	if IsValid(panel._tip) then panel._tip:Remove() end
	panel._tip = nil
end

local function paintMedallion(s, w, h)
	local i = s._tier
	local nNeed = EVO_Parrainage.TierNeed(i)
	local bReached = (State().success or 0) >= nNeed
	local bClaimed = tierClaimed(i)
	local counts = EVO_Parrainage.TIER_COUNTS or { 10, 20, 30, 40 }
	local prevNeed = counts[i - 1] or 0
	local bNext = not bReached and (State().success or 0) >= prevNeed
	local pulse = 0.5 + 0.5 * math.sin(CurTime() * 3)
	local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10)) or 0
	local sTxt = "COSMÉTIQUE " .. (ROMANS[i] or tostring(i))

	if bClaimed then
		EVO_UI.PaintCut(0, 0, w, h, COL_SBAR, gRespY(6), "br")
		draw.SimpleText(sTxt, "Bebas Neue:19", w / 2, h / 2, COL_SBAR_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	elseif bReached then
		EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL_SBAR, 200 + 55 * math.max(pulse, hf)), gRespY(6), "br")
		surface.SetDrawColor(255, 255, 255, 90 + 120 * math.max(pulse * 0.6, hf))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(hf > 0.4 and "RÉCUPÉRER" or sTxt, "Bebas Neue:19", w / 2, h / 2, COL_SBAR_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	else
		EVO_UI.PaintCut(0, 0, w, h, Color(10, 11, 13, 225), gRespY(6), "br")
		local cTxt = (hf > 0.02 and ColorAlpha(COL_SBAR, 220))
			or (bNext and ColorAlpha(COL_SBAR, 150 + 90 * pulse))
			or COL_MUTED
		draw.SimpleText(sTxt, "Bebas Neue:19", w / 2, h / 2, cTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if bNext or hf > 0.02 then
			surface.SetDrawColor(ColorAlpha(COL_SBAR, 60 + 80 * math.max(bNext and pulse or 0, hf)))
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
	end
end

local function openTip(tipParent, btn)
	closeTip(tipParent)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local i = btn._tier
	local sItem = EVO_Parrainage.TierOutfit(lp, i) or ""
	local tItem = (sItem ~= "" and ITEMS) and ITEMS[sItem] or nil
	local nNeed = EVO_Parrainage.TierNeed(i)
	local bReached = (State().success or 0) >= nNeed
	local bClaimed = tierClaimed(i)

	local tw, th = gRespX(280), tItem and gRespY(380) or gRespY(150)
	local sx, sy = btn:LocalToScreen(0, 0)
	local lx, ly = tipParent:ScreenToLocal(sx, sy)
	local px = math.Clamp(lx - tw / 2 + btn:GetWide() / 2, gRespX(8), tipParent:GetWide() - tw - gRespX(8))
	local py = ly - th - gRespY(8)
	if py < gRespY(8) then py = ly + btn:GetTall() + gRespY(8) end

	local tip = vgui.Create("DPanel", tipParent)
	tipParent._tip = tip
	tip:SetPos(px, py)
	tip:SetSize(tw, th)
	tip:SetMouseInputEnabled(false)
	tip:MoveToFront()

	local sState, cState
	if bClaimed then sState, cState = "Récupéré : il est dans ton inventaire.", COL_OK
	elseif not tItem then sState, cState = "Cosmétique exclusif : bientôt dévoilé !", COL_MUTED
	elseif bReached then sState, cState = "Palier atteint : clique pour le récupérer !", COL_SBAR
	else sState, cState = "Atteins ce palier pour le débloquer.", COL_MUTED end
	local sHint = tItem and "Clic droit : essayer sur ton personnage" or nil

	tip.Paint = function(_, w, h)
		EVO_UI.PaintTooltip(0, 0, w, h)
		draw.SimpleText("COSMÉTIQUE " .. (ROMANS[i] or tostring(i)), "Bebas Neue:26", w / 2, gRespY(22), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Palier " .. tostring(nNeed) .. " parrainages", "Avenir Next World:15", w / 2, gRespY(44), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if tItem and tItem.name then
			draw.SimpleText(tItem.name, "Bebas Neue:22", w / 2, h - gRespY(70), COL_SBAR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText(sState, "Avenir Next World:15", w / 2, h - gRespY(44), cState, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if sHint then
			draw.SimpleText(sHint, "Avenir Next World:14", w / 2, h - gRespY(20), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	if tItem and tItem.model_path then
		local mp = vgui.Create("DModelPanel", tip)
		mp:SetPos(gRespX(20), gRespY(58))
		mp:SetSize(tw - gRespX(40), gRespY(210))
		mp:SetMouseInputEnabled(false)
		QueuePreviewModel(mp, function(mp)
			mp:SetModel(tItem.model_path)
			local ent = mp.Entity
			if IsValid(ent) then
				if tItem.skin then ent:SetSkin(tItem.skin) end
				local mn, mx2 = ent:GetRenderBounds()
				local c = (mn + mx2) / 2
				local size = math.max(mx2.x - mn.x, mx2.y - mn.y, mx2.z - mn.z, 1)
				mp:SetCamPos(c + Vector(size * 0.9, size * 0.9, size * 0.35))
				mp:SetLookAt(c)
				mp:SetFOV(42)
				mp.LayoutEntity = function(_, e) e:SetAngles(Angle(0, (RealTime() * 30) % 360, 0)) end
			end
		end)
	end
end

local function previewTier(i)
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	local sItem = EVO_Parrainage.TierOutfit(lp, i) or ""
	local tItem = (sItem ~= "" and ITEMS) and ITEMS[sItem] or nil
	if not (tItem and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open) then
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Ce cosmétique arrive bientôt !", NOTIFY_GENERIC, 4) end
		return false
	end
	LZY_SHOP_COSMETIC_PREVIEW.Open(tItem)
	return true
end

local function clickTier(tipParent, i)
	closeTip(tipParent)
	if tierClaimed(i) then
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Cosmétique déjà récupéré.", NOTIFY_GENERIC, 3) end
		previewTier(i)
		return
	end
	local nNeed = EVO_Parrainage.TierNeed(i)
	if (State().success or 0) < nNeed then
		if MUGEN and MUGEN.Notify then
			MUGEN.Notify("Encore " .. (nNeed - (State().success or 0)) .. " succès pour débloquer ce palier.", NOTIFY_ERROR, 4)
		end
		previewTier(i)
		return
	end
	local lp = LocalPlayer()
	if ((EVO_Parrainage.TierOutfit(lp, i)) or "") == "" then
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Ce cosmétique arrive bientôt !", NOTIFY_GENERIC, 4) end
		return
	end
	net.Start("evo_parrainage.claim_tier")
		net.WriteUInt(i, 3)
	net.SendToServer()
end

-- Géométrie interne = barre boutique (design 1920 : piste y=82, h=16, médaillons au-dessus).
local function barGeom(bw, bh)
	local pad = gRespX(30)
	return {
		pad = pad,
		trackX = pad,
		trackY = gRespY(82),
		trackW = bw - pad * 2,
		trackH = gRespY(16),
		medY = gRespY(82) - gRespY(34),
		medW = gRespX(118),
		medH = gRespY(24),
	}
end

function EVO_Parrainage.BuildPalierUI(host, x, y, w, h, tipParent)
	if not IsValid(host) then return end
	tipParent = IsValid(tipParent) and tipParent or host

	local bar = vgui.Create("DPanel", host)
	bar:SetPos(x, y)
	bar:SetSize(w, h)
	bar._frac = 0
	bar:SetPaintBackgroundEnabled(false)

	local G = barGeom(w, h)
	local counts = EVO_Parrainage.TIER_COUNTS or { 10, 20, 30, 40 }

	bar.Paint = function(s, bw, bh)
		local now = CurTime()
		local nSucc = State().success or 0
		local frac = math.Clamp(nSucc / PALIER_MAX, 0, 1)
		s._frac = Lerp(math.min(FrameTime() * 5, 1), s._frac or 0, frac)
		local bFull = nSucc >= PALIER_MAX
		local g = barGeom(bw, bh)

		if RNDX and RNDX.DrawShadows then
			local glowA = (bFull and 52 or 30) + 12 * (0.5 + 0.5 * math.sin(now * 1.4))
			RNDX.DrawShadows(gRespY(16), 0, 0, bw, bh, ColorAlpha(COL_SBAR_B, glowA), gRespX(28))
		end
		EVO_UI.PaintCut(0, 0, bw, bh, COL_BAR_PLATE, gRespY(14), "br")
		surface.SetDrawColor(ColorAlpha(COL_SBAR, 110))
		surface.SetMaterial(MAT_GRAD_R)
		surface.DrawTexturedRect(bw * 0.05, 0, bw * 0.45, math.max(1, gRespY(2)))
		surface.DrawTexturedRectUV(bw * 0.5, 0, bw * 0.45, math.max(1, gRespY(2)), 1, 0, 0, 1)
		local sr = gRespY(4)
		if EVO_UI.Screw then
			EVO_UI.Screw(gRespX(16), gRespY(16), sr)
			EVO_UI.Screw(bw - gRespX(16), gRespY(16), sr)
			EVO_UI.Screw(bw - gRespX(16), bh - gRespY(16), sr)
			EVO_UI.Screw(gRespX(16), bh - gRespY(16), sr)
		end

		local hx, hy = g.pad, gRespY(20)
		draw.SimpleText("COSMÉTIQUES EXCLUSIFS", "Bebas Neue:32", hx, hy, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:32")
		local twT, thT = surface.GetTextSize("COSMÉTIQUES EXCLUSIFS")
		if not (EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, hx - gRespX(2), hy + thT * 0.28, twT * 1.15, gRespY(8), ColorAlpha(COL_SBAR, 235))) then
			surface.SetDrawColor(COL_SBAR)
			surface.DrawRect(hx, hy + thT * 0.34, twT, math.max(2, gRespY(2)))
		end
		draw.SimpleText("Un cosmétique exclusif offert à chaque palier de 10 parrainages réussis",
			"Avenir Next World:16", bw * 0.5 + gRespX(30), hy, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local sTotal = tostring(math.min(nSucc, PALIER_MAX)) .. " / " .. tostring(PALIER_MAX)
		draw.SimpleText(sTotal, "Bebas Neue:28", bw - g.pad, hy, COL_SBAR, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		local TX, TY, TW, TH = g.trackX, g.trackY, g.trackW, g.trackH
		local r = gRespY(8)
		if RNDX and RNDX.Draw then
			RNDX.Draw(r, TX, TY, TW, TH, COL_BAR_TRACK)
			if RNDX.DrawOutlined then RNDX.DrawOutlined(r, TX, TY, TW, TH, Color(255, 255, 255, 14), 1) end
		else
			surface.SetDrawColor(COL_BAR_TRACK)
			surface.DrawRect(TX, TY, TW, TH)
		end

		local fillW = math.max(TH, TW * s._frac)
		if s._frac > 0.004 then
			local ox, oy = s:LocalToScreen(0, 0)
			render.SetScissorRect(ox + TX, oy + TY, ox + TX + fillW, oy + TY + TH, true)
			if RNDX and RNDX.Draw then
				RNDX.Draw(r, TX, TY, fillW, TH, COL_SBAR_B)
			else
				surface.SetDrawColor(COL_SBAR_B)
				surface.DrawRect(TX, TY, fillW, TH)
			end
			surface.SetDrawColor(COL_SBAR)
			surface.SetMaterial(MAT_GRAD_R)
			surface.DrawTexturedRect(TX, TY, fillW, TH)
			surface.SetDrawColor(0, 0, 0, 55)
			surface.SetMaterial(MAT_GRAD_U)
			surface.DrawTexturedRectUV(TX, TY + TH * 0.5, fillW, TH * 0.5, 0, 1, 1, 0)
			surface.SetDrawColor(255, 255, 255, 60)
			surface.DrawRect(TX + gRespX(4), TY + math.max(1, gRespY(1)), math.max(0, fillW - gRespX(8)), math.max(1, gRespY(2)))
			local sw = TW * 0.10
			local shx = TX - sw + ((now * 0.30) % 1.35) * (TW + sw)
			surface.SetDrawColor(COL_SHINE)
			surface.SetMaterial(MAT_GRAD_R)
			surface.DrawTexturedRect(shx, TY, sw * 0.5, TH)
			surface.DrawTexturedRectUV(shx + sw * 0.5, TY, sw * 0.5, TH, 1, 0, 0, 1)
			render.SetScissorRect(0, 0, 0, 0, false)
		end

		if s._frac > 0.004 and not bFull then
			local px = TX + fillW
			if RNDX and RNDX.DrawShadows then
				RNDX.DrawShadows(gRespY(6), px - gRespX(9), TY - gRespY(5), gRespX(18), TH + gRespY(10), ColorAlpha(COL_SBAR, 120), gRespX(12))
			end
			local sp = gRespY(4) + gRespY(2) * (0.5 + 0.5 * math.sin(now * 5))
			local cyT = TY + TH / 2
			draw.NoTexture()
			surface.SetDrawColor(255, 240, 190, 235)
			surface.DrawPoly({
				{ x = px, y = cyT - sp }, { x = px + sp, y = cyT }, { x = px, y = cyT + sp }, { x = px - sp, y = cyT },
			})
		end

		local cy = TY + TH / 2
		for i, nNeed in ipairs(counts) do
			local px = TX + TW * (nNeed / PALIER_MAX) - ((i == #counts) and gRespX(8) or 0)
			local bReached = nSucc >= nNeed
			local prevNeed = counts[i - 1] or 0
			local bNext = not bReached and (nSucc >= prevNeed)
			local pulse = 0.5 + 0.5 * math.sin(now * 3)
			local a = gRespY(8)
			local col
			if bReached then col = COL_SBAR
			elseif bNext then col = ColorAlpha(COL_SBAR, 120 + 90 * pulse)
			else col = COL_BAR_LOCK end
			draw.NoTexture()
			surface.SetDrawColor(0, 0, 0, 160)
			surface.DrawPoly({
				{ x = px, y = cy - a - 2 }, { x = px + a + 2, y = cy }, { x = px, y = cy + a + 2 }, { x = px - a - 2, y = cy },
			})
			surface.SetDrawColor(col)
			surface.DrawPoly({
				{ x = px, y = cy - a }, { x = px + a, y = cy }, { x = px, y = cy + a }, { x = px - a, y = cy },
			})
			draw.SimpleText(tostring(nNeed), "Bebas Neue:20", px, TY + TH + gRespY(18),
				bReached and COL_SBAR or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	for i = 1, 4 do
		local nNeed = counts[i] or (i * 10)
		local px = G.trackX + G.trackW * (nNeed / PALIER_MAX) - ((i == 4) and gRespX(8) or 0)
		local mx = math.min(px - G.medW / 2, w - gRespX(24) - G.medW)
		mx = math.max(gRespX(24), mx)
		local b = vgui.Create("DButton", bar)
		b:SetPos(mx, G.medY)
		b:SetSize(G.medW, G.medH)
		b:SetText("")
		b:SetCursor("hand")
		b._tier = i
		b.Paint = paintMedallion
		b.OnCursorEntered = function(s)
			if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
			openTip(tipParent, s)
		end
		b.OnCursorExited = function()
			closeTip(tipParent)
		end
		b.DoClick = function()
			if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			clickTier(tipParent, i)
		end
		b.DoRightClick = function()
			closeTip(tipParent)
			previewTier(i)
		end
	end
	return bar
end
