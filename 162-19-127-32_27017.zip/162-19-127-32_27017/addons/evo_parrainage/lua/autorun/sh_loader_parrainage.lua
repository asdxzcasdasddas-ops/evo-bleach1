-- "addons\\evo_parrainage\\lua\\autorun\\sh_loader_parrainage.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PARRAINAGE — codes de parrainage (compte / SteamID64).
-- Le parrain choisit un code unique ; un nouveau joueur le saisit à la création
-- de son PREMIER personnage. Au niveau 10 du filleul : 1 succès + 100 coins
-- (parrain) / 300 coins (filleul). Paliers cosmétiques 10 / 20 / 30 / 40.
-- ============================================================================

EVO_Parrainage = EVO_Parrainage or {}

if SERVER then
	AddCSLuaFile("evo_parrainage/sh_config.lua")
	AddCSLuaFile("evo_parrainage/cl_menu.lua")
	AddCSLuaFile("evo_parrainage/cl_paliers.lua")

	util.AddNetworkString("evo_parrainage.sync")
	util.AddNetworkString("evo_parrainage.state")
	util.AddNetworkString("evo_parrainage.set_code")
	util.AddNetworkString("evo_parrainage.claim_tier")
	util.AddNetworkString("evo_parrainage.result")
	-- Check live du champ « code de parrainage » du créateur (perte de focus).
	util.AddNetworkString("evo_parrainage.check_ref")
	util.AddNetworkString("evo_parrainage.check_ref_result")
end

include("evo_parrainage/sh_config.lua")

if SERVER then
	include("evo_parrainage/sv_main.lua")
else
	include("evo_parrainage/cl_paliers.lua")
	include("evo_parrainage/cl_menu.lua")
end
