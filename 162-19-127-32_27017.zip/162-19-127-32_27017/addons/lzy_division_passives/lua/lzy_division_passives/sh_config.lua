-- "addons\\lzy_division_passives\\lua\\lzy_division_passives\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_DIVISION_PASSIVES = LZY_DIVISION_PASSIVES or {}

-- ══════════════════════════════════════════════════════════
-- PASSIFS DE DIVISION — état 2026-07-22 après nettoyage.
-- La plupart des passifs de division ont basculé vers les SORTS de division
-- (ncm_combat_system/sv_division_spells) : le passif scientifique (Analyse), le
-- keybind d'invisibilité assassin (-> sort « Camouflage de l'Ombre ») et le bonus
-- dégâts katana Div11 ont tous été RETIRÉS. Ce fichier ne porte plus que les VALEURS
-- scalées par grade des passifs encore VIVANTS : assassin (durée + drain, consommés
-- par le moteur du sort) et soins (réanimation plus rapide).
-- (RETIRÉS le 2026-07-22 : la table Config + GetPassives + GetKatanaDamageBonus +
--  GradeScaling.combat/.scientifique + GetScientifiqueDuration — cluster mort.)
-- RÉINTRODUIT le 2026-10-26 (user) : passif scientifique « Maîtrise alchimique » = CD de
-- consommation des potions réduit par grade (GetPotionCdMult, lu par sv_science_potions).
-- ══════════════════════════════════════════════════════════

-- ══════════════════════════════════════════════════════════
-- SCALING PAR GRADE : interpolation linéaire rang 1 (max_val) -> rang 16 (min_val)
-- ══════════════════════════════════════════════════════════

LZY_DIVISION_PASSIVES.GradeScaling = {
	-- Division 2 (assassin, index 3) — valeurs consommées par le MOTEUR du sort
	-- « Camouflage de l'Ombre » (ncm_assassin_passif) : durée + drain de reiatsu/s.
	assassin = {
		duration_min            = 12.5,  -- Rang 1 : 12.5s d'invisibilité (+25% 08/03, était 10)
		duration_max            = 37.5,  -- Rang 16 : 37.5s d'invisibilité (+25% 08/03, était 30)
		-- (mute_footsteps_min_rank RETIRÉ 08/13 : les bruits de pas sont désormais coupés
		--  à TOUS les grades pendant l'invisibilité — sv_assassin.lua. Clé supprimée plutôt
		--  que laissée là, un réglage qui ne pilote plus rien est un piège.)
		drain_pct_rank1         = 3,     -- Rang 1  : 3% du reiatsu MAX / seconde (drain invisibilité)
		drain_pct_rank16        = 0.5,   -- Rang 16 : 0.5% du reiatsu MAX / seconde
	},
	-- Division 4 (soins, index 5)
	soins = {
		revive_mult_max = 1 / 3,    -- Rang 1 : 3x plus rapide
		revive_mult_min = 1 / 10,   -- Rang 16 : 10x plus rapide
	},
	-- Division 12 (scientifique, index 4) — « Maîtrise alchimique » (10/26) : multiplicateur
	-- du CD de consommation des potions (HUB.PotionUseCD, 10 min) du scientifique qui BOIT.
	scientifique = {
		potion_cd_mult_max = 1,     -- Rang 1  : 10 min
		potion_cd_mult_min = 0.6,   -- Rang 16 : 6 min
	},
}

--- Interpole linéairement entre max_val (rang 1) et min_val (rang 16)
function LZY_DIVISION_PASSIVES.LerpByRank(max_val, min_val, rank)
	local t = math.Clamp((rank - 1) / 15, 0, 1)
	return max_val + t * (min_val - max_val)
end

--- Calcule le temps de réanimation effectif pour un joueur (scale avec le grade)
function LZY_DIVISION_PASSIVES.GetReviveTime(ply)
	local base_time = (EvoRevive and EvoRevive.Revive and EvoRevive.Revive.ReviveTime) or 30
	if not IsValid(ply) then return base_time end

	local division = ply:GetEvoNWInt("FactionDivision", 0)
	if division ~= 5 then return base_time end -- Division 4 (soins) = index 5

	local rank = ply:GetEvoNWInt("FactionRank", 1)
	local scaling = LZY_DIVISION_PASSIVES.GradeScaling.soins
	local mult = LZY_DIVISION_PASSIVES.LerpByRank(scaling.revive_mult_max, scaling.revive_mult_min, rank)

	return base_time * mult
end

--- Multiplicateur du CD de consommation des potions (passif scientifique, scale avec le grade).
--- 1 hors division scientifique.
function LZY_DIVISION_PASSIVES.GetPotionCdMult(ply)
	if not IsValid(ply) then return 1 end
	if ply:GetEvoNWInt("FactionDivision", 0) ~= 4 then return 1 end -- Division 12 (scientifique) = index 4

	local s = LZY_DIVISION_PASSIVES.GradeScaling.scientifique
	return LZY_DIVISION_PASSIVES.LerpByRank(s.potion_cd_mult_max, s.potion_cd_mult_min, ply:GetEvoNWInt("FactionRank", 1))
end

--- Durée du passif assassin (invisibilité) pour un joueur, scale avec le grade
function LZY_DIVISION_PASSIVES.GetAssassinDuration(ply)
	if not IsValid(ply) then return 10 end
	local s = LZY_DIVISION_PASSIVES.GradeScaling.assassin
	return LZY_DIVISION_PASSIVES.LerpByRank(s.duration_min, s.duration_max, ply:GetEvoNWInt("FactionRank", 1))
end

--- Drain de reiatsu PAR SECONDE du passif assassin (invisibilité), en POINTS de reiatsu : % du
--- reiatsu MAX scalé par grade (rang 1 = 3%/s, rang 16 = 0.5%/s). Valeur FRACTIONNAIRE -> le
--- caller accumule la partie décimale (le reiatsu est un entier).
function LZY_DIVISION_PASSIVES.GetAssassinDrainPerSec(ply)
	if not IsValid(ply) then return 0 end
	local s = LZY_DIVISION_PASSIVES.GradeScaling.assassin
	local pct = LZY_DIVISION_PASSIVES.LerpByRank(s.drain_pct_rank1, s.drain_pct_rank16, ply:GetEvoNWInt("FactionRank", 1))
	local maxR = ply:GetEvoNWInt("MaxReiatsu", 100)
	return (pct / 100) * maxR
end
