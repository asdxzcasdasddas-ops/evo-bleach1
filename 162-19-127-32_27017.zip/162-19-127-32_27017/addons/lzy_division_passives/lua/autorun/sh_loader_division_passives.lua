-- "addons\\lzy_division_passives\\lua\\autorun\\sh_loader_division_passives.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local root = "lzy_division_passives/"

-- Shared
AddCSLuaFile(root .. "sh_config.lua")
include(root .. "sh_config.lua")
