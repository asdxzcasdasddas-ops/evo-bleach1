-- "addons\\lzy_npcshop\\lua\\entities\\lzy_npcshop_npc\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- Font dediee pour le nametag 3D2D. Creee une fois au chargement client.
surface.CreateFont("LZY_Npcshop_NameTag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
	outline   = false,
})

-- RENDERGROUP_BOTH : le model est dessine en passe OPAQUE (ENT:Draw) et le
-- nametag en passe TRANSLUCIDE (ENT:DrawTranslucent). La passe translucide tourne
-- APRES toute la geometrie opaque (monde + props) -> avec cam.IgnoreZ le nametag
-- est garanti par-dessus tous les props (fini l'occlusion par un prop devant).
ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette de nom.
ENT.EVO_PromptZ = 80

-- Pré-alloc : évite 2 Color() + 1 GetTextSize par frame (le nom est constant).
local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Initialize()
end

-- Cull distance pour le nametag (au-dela on ne dessine pas le 3D2D).
-- Reduit de 1500u a 750u (portee trop large : on lisait le tag de tres loin).
local NAMETAG_CULL_SQR = 750 * 750

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > NAMETAG_CULL_SQR then return end

	local name = (NPCSHOP_CONFIG and NPCSHOP_CONFIG.NpcName) or "Urahara Shop"
	-- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 80, nil, 750, "parler") return end

	-- Position : ~80u au-dessus de l'origin (model humain ~72u + ~8u au-dessus
	-- de la tete pour separation visuelle).
	local pos = ePos + Vector(0, 0, 80)

	-- Billboard yaw-only : face TOUJOURS la caméra de rendu (EyePos), pas l'angle du
	-- joueur -> suit la caméra orbitale (citron_orbit_camera). roll = 90 redresse le texte.
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		if _tagName ~= name then
			_tagName = name
			surface.SetFont("LZY_Npcshop_NameTag")
			_tagTW, _tagTH = surface.GetTextSize(name)
		end
		draw.RoundedBox(8, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "LZY_Npcshop_NameTag", 0, 0,
			COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
