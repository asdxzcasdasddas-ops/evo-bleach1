-- "addons\\lzy_npcshop\\lua\\entities\\lzy_npcshop_npc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Entity NPC Urahara : anim simple, pas de NextBot/AI. Spawn via sv_spawn.lua.
-- L'interaction (E pour ouvrir le shop) est gere cote client via cl_npc.lua qui
-- detecte les entites par classe (au lieu de par modele, ce qui evite tout
-- conflit avec d'autres props qui auraient le meme model).

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Urahara Shop"
ENT.Author    = "lzy_npcshop"
ENT.Spawnable = false -- pas dans le Q menu, spawn auto via sv_spawn.lua
ENT.AdminOnly = true

-- Force l'engine a avancer les anims automatiquement. Sans ca, si Think n'est
-- pas appele (ou pas assez frequemment), la sequence reste sur la frame 0.
ENT.AutomaticFrameAdvance = true
