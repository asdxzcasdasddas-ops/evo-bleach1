-- "addons\\lzy_npcshop\\lua\\autorun\\lzy_npcshop_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_npcshop/config.lua")
	AddCSLuaFile("lzy_npcshop/vgui/cl_main.lua")
	AddCSLuaFile("lzy_npcshop/cl_npc.lua")
	include("lzy_npcshop/config.lua")
	include("lzy_npcshop/net.lua")
	include("lzy_npcshop/sv_chests.lua")
	include("lzy_npcshop/sv_spawn.lua")
else
	include("lzy_npcshop/config.lua")
	include("lzy_npcshop/vgui/cl_main.lua")
	include("lzy_npcshop/cl_npc.lua")
end