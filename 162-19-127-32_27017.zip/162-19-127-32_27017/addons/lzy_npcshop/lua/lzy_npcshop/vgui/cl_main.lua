-- "addons\\lzy_npcshop\\lua\\lzy_npcshop\\vgui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY_NPCSHOP — client : menu du shop Urahara.
-- REFONTE VISUELLE (DA Atelier 07/07) : tout le CHROME PNG workshop (bg,
-- header_title, close, cat_btn, slots, buy_btn, item_panel) est remplacé par
-- la recette Atelier : plaque métal noir #0E0E11 à coins coupés
-- (EVO_UI.PaintCut) + liseré acier + 4 vis d'angle, titre Bebas + entaille
-- slash1, filets DENTÉS, accent unique #cf444e, prix en OR. Les PNG de
-- CONTENU restent (icônes d'items, halos de rareté). Tout le FONCTIONNEL est
-- inchangé : mêmes net messages, mêmes DoClick, mêmes géométries de contenu,
-- mêmes sons.
-- ============================================================================

local frame = nil
local PANEL = {}
local can_open = true

-- Fond DA Atelier (08/07) : bc2 (workshop) dessinée en trame fantôme FLOUTÉE
-- (layer blur EVO_UI.GhostBlur) sur la plaque, sans zoom. Chaîne de secours
-- png -> jpg -> sans extension.
local bgShop2 = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc2.png", "smooth")
if bgShop2:IsError() then bgShop2 = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc2.jpg", "smooth") end
if bgShop2:IsError() then bgShop2 = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc2", "smooth") end

local materials = {
	bg = Material("materials/4lkv3nk9rxa1t2b23/941emmuj561076.png", "smooth"), -- 1920x1080 (plus dessiné — remplacé par bc2)
	close_btn = Material("materials/4lkv3nk9rxa1t2b23/jsxy24xzuaxqk.png", "smooth"), -- 60x60
	item_panel = Material("materials/4lkv3nk9rxa1t2b23/3081k8a5l6f4g488.png", "smooth"), -- 694x313
	header_title = Material("materials/4lkv3nk9rxa1t2b23/c85vhfapntmc.png", "smooth"), -- 236x41
	cat_btn = Material("materials/4lkv3nk9rxa1t2b23/8al1qbwn4jqtie3u.png", "smooth"), -- 205x44
	cat_btn_selected = Material("materials/4lkv3nk9rxa1t2b23/warysw2pol3w5sfv.png", "smooth"), -- 205x44
	item_slot_bg = Material("materials/4lkv3nk9rxa1t2b23/e8ej0y978qg3eel.png", "smooth"), -- 150x150
	item_slot_bg_selected = Material("materials/4lkv3nk9rxa1t2b23/1oo8qdc84mr3cg.png", "smooth"), -- 150x150
	item_slot_bg_hover = Material("materials/4lkv3nk9rxa1t2b23/f38vjmsjh1b00akb.png", "smooth"), -- 150x150
	buy_btn = Material("materials/4lkv3nk9rxa1t2b23/p6tzfu0nh6hs9pi5j.png", "smooth"), -- 654x56
	buy_btn_hover = Material("materials/4lkv3nk9rxa1t2b23/ojdash6syhiw.png", "smooth"), -- 654x56

	rarity_gray = Material("materials/4lkv3nk9rxa1t2b23/doepzxomy04c6nmje.png", "smooth"), -- 69x69
	rarity_green = Material("materials/4lkv3nk9rxa1t2b23/81op6nnnu74dg8e8.png", "smooth"), -- 69x69
	rarity_blue = Material("materials/4lkv3nk9rxa1t2b23/pfvj6v9kbfow.png", "smooth"), -- 69x69
	rarity_purple = Material("materials/4lkv3nk9rxa1t2b23/p4uxs1cmcqrut5.png", "smooth"), -- 69x69
	rarity_red = Material("materials/4lkv3nk9rxa1t2b23/8ybwy2ggzyqwgmmk3.png", "smooth"), -- 69x69
	rarity_yellow = Material("materials/4lkv3nk9rxa1t2b23/0skna15ovzfgf.png", "smooth"), -- 69x69
}

-- ── Palette DA Atelier (couleurs module-locales : rien de réalloué par frame) ──
local COL_WHITE          = Color(255, 255, 255, 255)
local COL_FOND           = Color(5, 5, 7, 216)        -- assombrissement plein écran
local COL_CARD           = Color(13, 14, 17, 250)     -- plaque métal noir (Atelier)
local COL_EDGE           = Color(146, 152, 161, 33)   -- liseré acier 1px
local COL_INPUT_EDGE     = Color(255, 255, 255, 24)   -- bordure recherche / onglets
local COL_TITLE          = Color(237, 238, 242)       -- titres / libellés forts
local COL_MUTED          = Color(150, 154, 162)       -- texte secondaire / ✕ au repos
local COL_DIM            = Color(108, 111, 120)       -- texte éteint (bouton désactivé)
local COL_ACCENT         = Color(207, 68, 78)         -- #cf444e (accent unique)
local COL_ACCENT_HOV     = Color(224, 92, 102)        -- accent éclairci (survols)
local COL_ACCENT_BTN     = Color(207, 68, 78, 230)    -- plaque accent (bouton plein)
local COL_ACCENT_BTN_HOV = Color(224, 92, 102, 255)   -- plaque accent survolée
local COL_GOLD           = Color(232, 179, 75)        -- argent / prix
local COL_PLATE_SUB      = Color(17, 18, 22, 205)     -- sous-plaque (onglets, neutre)
local COL_PLATE_SUB2     = Color(17, 18, 22, 235)     -- sous-plaque détails (plus opaque)
local COL_SLOT           = Color(20, 21, 26, 220)     -- case d'item plate
local COL_SLOT_HOV       = Color(27, 29, 35, 235)     -- case d'item survolée
local COL_SOLD           = Color(207, 68, 78, 240)    -- marqueur EPUISE (accent)
local COL_SCROLL         = Color(58, 58, 68, 220)     -- grip de l'ascenseur
local COL_DENTS          = Color(255, 255, 255, 26)   -- filets dentés (séparateurs)

-- ── Helpers de dessin DA Atelier (copies locales — mêmes recettes que
-- échap/squad/famille/forge). (DA Atelier 07/07) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = gRespX(6), gRespX(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

-- Plaque à coins coupés (garde EVO_UI : fallback rect sombre si l'addon UI
-- manque). PAS de liseré sur les mini-plaques (coins coupés = rendu crénelé).
local function shopPlate(x, y, w, h, col, cut, corners)
	if EVO_UI and EVO_UI.PaintCut then
		return EVO_UI.PaintCut(x, y, w, h, col, cut, corners)
	end
	surface.SetDrawColor(col)
	surface.DrawRect(x, y, w, h)
	return nil
end

-- Bordure 1px d'un onglet « br » : DrawRect (pas DrawLine) et pixels à
-- w-1 / h-1, sinon le clip VGUI mange le droit, le bas et la diagonale.
local function shopCatBorder(w, h, cut, col)
	cut = math.min(math.max(math.floor(cut or 0), 0), math.floor(math.min(w, h) / 2))
	surface.SetDrawColor(col)
	surface.DrawRect(0, 0, w, 1)
	surface.DrawRect(0, 0, 1, h)
	surface.DrawRect(w - 1, 0, 1, math.max(1, h - cut))
	surface.DrawRect(0, h - 1, math.max(1, w - cut), 1)
	for i = 0, cut - 1 do
		surface.DrawRect((w - 1) - i, (h - cut) + i, 1, 1)
	end
end

-- ── Plaque principale (unités design 1920x1080) : englobe la géométrie de
-- contenu EXISTANTE (colonne items 174..839, panneau droit 944..1638,
-- contenu 85..923) — les positions des enfants ne bougent pas. ──
local SHOP_CARD_X = 134
local SHOP_CARD_Y = 50
local SHOP_CARD_W = 1544
local SHOP_CARD_H = 915
-- Colonne gauche : recherche + onglets + grille partagent la même largeur.
local SHOP_LIST_X = 174
local SHOP_LIST_W = 665
local SHOP_CAT_Y = 220
local SHOP_CAT_H = 44
local SHOP_CAT_GAP = 15

local NPCSHOP_SLOT_MODEL_FOV = 30
local NPCSHOP_SELECTED_MODEL_FOV = 30

local function npcshopClearModelPreview(hostPanel)
	if IsValid(hostPanel._previewHost) then
		hostPanel._previewHost:Remove()
		hostPanel._previewHost = nil
	end
	hostPanel._hasModelPreview = nil
end

local function npcshopTryMountModelPreview(hostPanel, itemData, x, y, w, h, fov)
	npcshopClearModelPreview(hostPanel)
	local P = LZY_INVENTORY_ITEM_PREVIEW
	if not itemData or not P or not P.ItemHasModelPreview or not P.SetupModelPanel or not P.ItemHasModelPreview(itemData) then
		return false
	end
	local previewHost = vgui.Create("DPanel", hostPanel)
	previewHost:SetMouseInputEnabled(false)
	previewHost:SetPos(x, y)
	previewHost:SetSize(w, h)
	previewHost:SetZPos(1)
	P.SetupModelPanel(previewHost, itemData, fov or NPCSHOP_SLOT_MODEL_FOV)
	hostPanel._previewHost = previewHost
	hostPanel._hasModelPreview = true
	return true
end

local RARITY_COLOR_KEY_TO_TEXT_COLOR = {
	gray = Color(176, 176, 184, 255),
	green = Color(100, 220, 140, 255),
	blue = Color(110, 170, 255, 255),
	purple = Color(200, 130, 255, 255),
	yellow = Color(255, 210, 90, 255),
	red = Color(255, 95, 95, 255),
}

local function npcshopGetRarityTierLabel(rarity)
	if not isstring(rarity) or rarity == "" then return nil end
	local r = string.lower(rarity)
	return r:sub(1, 1):upper() .. r:sub(2)
end

local function npcshopGetRarityTierTextColor(rarity)
	local cfg = INVENTORY_CONFIG and INVENTORY_CONFIG.raritiesColor
	local rk = isstring(rarity) and string.lower(rarity) or ""
	local colorKey = (cfg and cfg[rk]) or "gray"
	return RARITY_COLOR_KEY_TO_TEXT_COLOR[colorKey] or RARITY_COLOR_KEY_TO_TEXT_COLOR.gray
end

local function npcshopCollectStatsLines(data)
	if not data or not istable(data.stats) then return {} end
	local names = INVENTORY_CONFIG and INVENTORY_CONFIG.STAT_DISPLAY_NAMES
	local rows = {}
	for k, v in pairs(data.stats) do
		if isstring(k) and type(v) == "number" then
			local label = (names and names[k]) or k
			rows[#rows + 1] = { label = label, value = v }
		end
	end
	table.sort(rows, function(a, b) return a.label < b.label end)
	local lines = {}
	for _, r in ipairs(rows) do
		local valStr = (math.abs(r.value - math.floor(r.value)) < 1e-6) and string.format("%d", r.value) or string.format("%.1f", r.value)
		lines[#lines + 1] = string.format("%s : +%s%%", r.label, valStr)
	end
	return lines
end

local function npcshopWrapText(text, font, maxWidth)
	if not isstring(text) or text == "" then return {} end
	surface.SetFont(font)
	local lines = {}
	local current = ""
	for word in string.gmatch(text, "%S+") do
		local candidate = (current == "") and word or (current .. " " .. word)
		local candidateW = surface.GetTextSize(candidate)
		if candidateW <= maxWidth or current == "" then
			current = candidate
		else
			lines[#lines + 1] = current
			current = word
		end
	end
	if current ~= "" then
		lines[#lines + 1] = current
	end
	return lines
end

local function getCategories()
	local categories = {}
	local visible = NPCSHOP_CONFIG.GetVisibleProducts and NPCSHOP_CONFIG.GetVisibleProducts(LocalPlayer()) or NPCSHOP_CONFIG.products
	for k, v in pairs(visible) do
		-- insert in categories table if not already in
		if ITEMS[v.item_id] and not table.HasValue(categories, ITEMS[v.item_id].category) then
			table.insert(categories, ITEMS[v.item_id].category)
		end
	end

	local configuredOrder = NPCSHOP_CONFIG.category_order
	local categoryOrderIndex = {}
	if istable(configuredOrder) then
		for idx, key in ipairs(configuredOrder) do
			if isstring(key) then
				categoryOrderIndex[key] = idx
			end
		end
	end

	local function getCategoryDisplayName(categoryKey)
		if categoryKey == "all" then
			return "Tous"
		end
		if categoryKey == "coffres" then
			return "Coffres"
		end
		return (INVENTORY_CONFIG.categoriesNames and INVENTORY_CONFIG.categoriesNames[categoryKey]) or categoryKey
	end

	-- include "all" + "coffres" (virtuels) dans la pipeline d'ordering
	local categoryKeys = {}
	for _, category in ipairs(categories) do
		table.insert(categoryKeys, category)
	end
	table.insert(categoryKeys, "all")
	if NPCSHOP_CONFIG.chest_slots then
		table.insert(categoryKeys, "coffres")
	end

	table.sort(categoryKeys, function(a, b)
		local orderA = categoryOrderIndex[a]
		local orderB = categoryOrderIndex[b]
		if orderA and orderB then return orderA < orderB end
		if orderA then return true end
		if orderB then return false end
		if a == "all" then return true end
		if b == "all" then return false end
		return tostring(getCategoryDisplayName(a)) < tostring(getCategoryDisplayName(b))
	end)

	-- return both category keys and display names
	local categoriesData = {}
	for _, category in ipairs(categoryKeys) do
		table.insert(categoriesData, {
			key = category,
			name = getCategoryDisplayName(category)
		})
	end
	return categoriesData
end

-- Nom affiche pour le filtre de recherche (insensible a la casse, meme recette
-- que l'inventaire). GetItemDisplayName si dispo, sinon ITEMS[].name.
local function npcshopGetSearchName(itemId)
	if not itemId then return "" end
	local item = ITEMS and ITEMS[itemId]
	local display = INVENTORY_CONFIG and INVENTORY_CONFIG.GetItemDisplayName
		and INVENTORY_CONFIG.GetItemDisplayName(itemId)
	return string.lower(display or (item and item.name) or itemId or "")
end

local function npcshopMatchesSearch(itemId, searchText)
	if not searchText or searchText == "" then return true end
	return string.find(npcshopGetSearchName(itemId), searchText, 1, true) ~= nil
end

-- Helper : bouton PREVIEW masque si l'item n'a pas de model OU si c'est un
-- coffre (is_lootbox). La preview cosmetique n'a pas de sens pour un coffre
-- (le modele est statique, pas un cosmetique a porter sur le perso).
local function npcshopPreviewBtnVisibleFor(itemData)
	if not itemData then return false end
	if itemData.is_lootbox then return false end
	return isstring(itemData.model_path) and itemData.model_path ~= ""
end

local function npcshopGetSelectedUnitPrice(pnl)
	if pnl.selected_chest_slot and pnl.chest_state and pnl.chest_state.slots then
		local slot = pnl.chest_state.slots[pnl.selected_chest_slot]
		local chestCfg = NPCSHOP_CONFIG.chest_slots
		if slot and chestCfg and chestCfg.chest_prices then
			return tonumber(chestCfg.chest_prices[slot.rarity])
		end
	end
	local pool = NPCSHOP_CONFIG.GetVisibleProducts and NPCSHOP_CONFIG.GetVisibleProducts(LocalPlayer()) or NPCSHOP_CONFIG.products
	for _, product in ipairs(pool or {}) do
		if product.item_id == pnl.selected_item then
			return tonumber(product.price)
		end
	end
	return nil
end

function PANEL:Init()
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("npcshop")
	end
	openedFrame = self
	self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	self:SetVisible(true)
	self:gSetSize(1920, 1080)
	self:gSetPos(0, 0)

	self.closeButton = vgui.Create("DButton", self)
	self.closeButton:gSetSize(60, 60)
	self.closeButton:gSetPos(1578, 90)
	self.closeButton:SetText("")
	self.closeButton:SetMouseInputEnabled(true)
	self.closeButton:SetKeyboardInputEnabled(false)
	self.closeButton.Paint = function(selff, w, h)
		-- Croix standard DA : glyphe ✕ sans fond, gris -> accent au survol
		-- (remplace le PNG close_btn). (DA Atelier 07/07)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			selff.hovered and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.closeButton.DoClick = function()
		self:Close()
	end
	self.closeButton.OnCursorEntered = function(selff)
		selff.hovered = true
	end
	self.closeButton.OnCursorExited = function(selff)
		selff.hovered = false
	end

	-- Barre de recherche : meme recette que l'inventaire (fond sombre, liseré
	-- accent au focus, placeholder maison car Paint custom masque SetPlaceholderText).
	-- Largeur = grille d'items ; coincée entre le titre et la rangée de catégories.
	self.searchText = ""
	self.searchEntry = vgui.Create("DTextEntry", self)
	self.searchEntry:gSetPos(SHOP_LIST_X, 160)
	self.searchEntry:gSetSize(SHOP_LIST_W, 36)
	self.searchEntry:SetFont("Bebas Neue:22")
	self.searchEntry:SetDrawLanguageID(false)
	self.searchEntry:SetPlaceholderText("Rechercher un objet...")
	self.searchEntry:SetPaintBackground(false)
	self.searchEntry:SetTextColor(COL_TITLE)
	self.searchEntry:SetCursorColor(COL_ACCENT)
	self.searchEntry.Paint = function(selff, w, h)
		local bFocus = selff:HasFocus()
		if RNDX and RNDX.Draw then
			RNDX.Draw(gRespY(8), 0, 0, w, h, Color(10, 10, 14, 210))
			if RNDX.DrawOutlined then
				RNDX.DrawOutlined(gRespY(8), 0, 0, w, h,
					bFocus and Color(207, 68, 78, 190) or COL_INPUT_EDGE,
					math.max(1, gRespX(1)))
			end
		else
			draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 14, 210))
		end
		selff:DrawTextEntryText(COL_TITLE, Color(207, 68, 78, 140), COL_TITLE)
		if selff:GetValue() == "" and not bFocus then
			draw.SimpleText("Rechercher un objet...", "Bebas Neue:22",
				gRespX(10), h * 0.5, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	self.searchEntry.OnChange = function(selff)
		self.searchText = string.lower(selff:GetValue() or "")
		self:FilterItemsByCategory()
	end

	local categories = getCategories()
	self.current_category = 1
	self.category_keys = {} -- Store category keys for filtering
	local nCats = #categories
	local catW = (nCats > 0) and math.floor((SHOP_LIST_W - (nCats - 1) * SHOP_CAT_GAP) / nCats) or SHOP_LIST_W
	local catExtra = (nCats > 0) and (SHOP_LIST_W - (nCats - 1) * SHOP_CAT_GAP - catW * nCats) or 0
	local catX = SHOP_LIST_X
	for i, categoryData in ipairs(categories) do
		self.category_keys[i] = categoryData.key
		local thisW = catW + (i == nCats and catExtra or 0)
		local category_btn = vgui.Create("DButton", self)
		category_btn:gSetSize(thisW, SHOP_CAT_H)
		category_btn:gSetPos(catX, SHOP_CAT_Y)
		catX = catX + thisW + SHOP_CAT_GAP
		category_btn:SetText(categoryData.name)
		category_btn:SetMouseInputEnabled(true)
		category_btn:SetKeyboardInputEnabled(false)
		category_btn:SetText("")
		category_btn.Paint = function(selff, w, h)
			-- Onglet catégorie DA (remplace les PNG cat_btn/cat_btn_selected) :
			-- mini-plaque à coin coupé (accent plein quand sélectionné), barre
			-- accent au survol. Bordure grise 1px sur TOUS les bords (y compris
			-- le coin coupé) : DrawRect inset, pas OutlineCut (clippé).
			local bSel = self.current_category == i
			local catCut = gRespY(8)
			shopPlate(0, 0, w, h, bSel and COL_ACCENT_BTN or COL_PLATE_SUB, catCut, "br")
			shopCatBorder(w, h, catCut, COL_INPUT_EDGE)
			if not bSel and selff.hovered then
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawRect(0, 0, math.max(2, gRespX(2)), h)
			end
			draw.SimpleText(categoryData.name, "Bebas Neue:20", w / 2, h / 2,
				bSel and COL_WHITE or (selff.hovered and COL_ACCENT_HOV or COL_MUTED),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		category_btn.DoClick = function()
			self.current_category = i
			self:FilterItemsByCategory()
		end
		category_btn.OnCursorEntered = function(selff)
			selff.hovered = true
		end
		category_btn.OnCursorExited = function(selff)
			selff.hovered = false
		end
	end

	self.selected_item = nil
	self._selectedHasModelPreview = false
	self.selectedDetailsScroll = nil
	self.selectedDetailsCanvas = nil

	-- Scroll panel (4 items per row) with buttons
	self.scroll_panel = vgui.Create("DScrollPanel", self)
	self.scroll_panel:gSetSize(665, 643)
	self.scroll_panel:gSetPos(174, 280)
	self.scroll_panel:SetPaintBackgroundEnabled(false)
	self.scroll_panel.Paint = function(selff, w, h) end

	-- Custom Scrollbar
	local vbar = self.scroll_panel:GetVBar()
	if IsValid(vbar) then
		-- Completely remove default arrow buttons
		if IsValid(vbar.btnUp) then
			vbar.btnUp:SetVisible(false)
			vbar.btnUp:SetSize(0, 0)
			vbar.btnUp.Paint = function() end
		end
		if IsValid(vbar.btnDown) then
			vbar.btnDown:SetVisible(false)
			vbar.btnDown:SetSize(0, 0)
			vbar.btnDown.Paint = function() end
		end

		-- Set scrollbar width
		vbar:SetWidth(gRespX(8))

		-- Custom scrollbar track
		vbar.Paint = function(_, w, h)
			-- Draw scrollbar track background
			RNDX.Draw(0, 0, 0, w, h, Color(255, 255, 255, 5))
		end

		-- Custom scrollbar grip
		vbar.btnGrip.Paint = function(_, w, h)
			-- Grip DA : pilule sombre -> accent au survol (remplace le vert
			-- hors-DA). (DA Atelier 07/07)
			local gripColor = COL_SCROLL
			if _.Hovered or _.Depressed then
				gripColor = COL_ACCENT
			end
			draw.RoundedBox(4, 2, 0, w - 4, h, gripColor)
		end
	end

	-- Store item buttons with their category info
	self.item_buttons = {}
	local items_per_row = 4
	local item_width = 150
	local item_height = 150
	local spacing = 15

	-- Add items inside scroll panel from NPCSHOP_CONFIG.products
	-- (filtre faction : Hollow ne voit que les produits Hollow/sans-faction, etc.)
	local visibleProducts = NPCSHOP_CONFIG.GetVisibleProducts and NPCSHOP_CONFIG.GetVisibleProducts(LocalPlayer()) or NPCSHOP_CONFIG.products
	for k, v in ipairs(visibleProducts) do
		local item_btn = vgui.Create("DButton", self.scroll_panel)
		item_btn:gSetSize(item_width, item_height)
		item_btn:SetText("")
		item_btn:SetMouseInputEnabled(true)
		item_btn:SetKeyboardInputEnabled(false)

		-- Store product data and category on the button
		item_btn.product_data = v
		item_btn.item_category = ITEMS[v.item_id].category

		item_btn.Paint = function(selff, w, h)
			-- Case d'item DA (remplace les PNG slot/hover/selected) : carré
			-- sombre plat + liseré acier 1px ; survol = fond éclairci + liseré
			-- accent ; sélection = liseré accent 2px. Les icônes/raretés (PNG
			-- de CONTENU) sont conservées. (DA Atelier 07/07)
			surface.SetDrawColor(selff.hovered and COL_SLOT_HOV or COL_SLOT)
			surface.DrawRect(0, 0, w, h)
			-- DA dashboard 08/07 : plus de liseré acier au repos ; sélection (accent
			-- 2px) et bordure accent au survol conservées.
			if self.selected_item == v.item_id then
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawOutlinedRect(0, 0, w, h, 2)
			elseif selff.hovered then
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			if not selff._hasModelPreview and ITEMS[v.item_id] and ITEMS[v.item_id].icon then
				RNDX.DrawMaterial(0, gRespX(35), gRespY(25), gRespX(80), gRespY(80), Color(255, 255, 255, 255), Material(ITEMS[v.item_id].icon))
			end
			draw.SimpleText(ITEMS[v.item_id].name, "Avenir Next World:16", w / 2, gRespY(125), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		item_btn.DoClick = function()
			self.selected_item = v.item_id
			self.selected_chest_slot = nil  -- reset chest selection si on switch sur un item normal
			self:UpdateSelectedItemPreview()
		end
		item_btn.OnCursorEntered = function(selff)
			selff.hovered = true
		end
		item_btn.OnCursorExited = function(selff)
			selff.hovered = false
		end

		table.insert(self.item_buttons, item_btn)

		npcshopTryMountModelPreview(item_btn, ITEMS[v.item_id], gRespX(35), gRespY(25), gRespX(80), gRespY(80), NPCSHOP_SLOT_MODEL_FOV)
	end

	-- Coffres journaliers : creation des 3 slots (population reelle a la reception
	-- du state serveur). Chaque slot a un index + un item_id qui est resolu une
	-- fois la rarete connue, en mappant via NPCSHOP_CONFIG.chest_slots.chest_items.
	self.chest_buttons = {}
	self.chest_state   = nil
	if NPCSHOP_CONFIG.chest_slots then
		local chestCfg = NPCSHOP_CONFIG.chest_slots
		local nSlots = math.floor(tonumber(chestCfg.daily_picks) or 3)
		for i = 1, nSlots do
			local btn = vgui.Create("DButton", self.scroll_panel)
			btn:gSetSize(150, 150)
			btn:SetText("")
			btn:SetMouseInputEnabled(true)
			btn:SetKeyboardInputEnabled(false)
			btn._chest_slot_idx = i

			btn.Paint = function(selff, w, h)
				local slot = self.chest_state and self.chest_state.slots and self.chest_state.slots[i]
				local isSelected = self.selected_chest_slot == i
				-- Case coffre DA : même recette que les cases d'items (carré
				-- sombre plat, liseré acier/accent). (DA Atelier 07/07)
				surface.SetDrawColor(selff.hovered and COL_SLOT_HOV or COL_SLOT)
				surface.DrawRect(0, 0, w, h)
				-- DA dashboard 08/07 : plus de liseré acier au repos ; sélection
				-- (accent 2px) et bordure accent au survol conservées.
				if isSelected then
					surface.SetDrawColor(COL_ACCENT)
					surface.DrawOutlinedRect(0, 0, w, h, 2)
				elseif selff.hovered then
					surface.SetDrawColor(COL_ACCENT)
					surface.DrawOutlinedRect(0, 0, w, h, 1)
				end
				if not slot then
					draw.SimpleText("...", "Avenir Next World:16", w / 2, h / 2,
						COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					return
				end
				local itemId = chestCfg.chest_items and chestCfg.chest_items[slot.rarity]
				local def = itemId and ITEMS and ITEMS[itemId]

				-- Lazy-mount du DModelPanel quand la rarete du slot change (apres reception state).
				-- evo_loot fournit `model_path` (chest_rewards.mdl) + `bodygroup` par rarete.
				if def and isstring(def.model_path) and def.model_path ~= "" and selff._mountedRarity ~= slot.rarity then
					selff._mountedRarity = slot.rarity
					npcshopTryMountModelPreview(selff, def, gRespX(15), gRespY(5), gRespX(120), gRespY(110), NPCSHOP_SLOT_MODEL_FOV)
				end

				-- Fallback icon 2D si la preview 3D n'a pas pu se monter.
				if not selff._hasModelPreview and def and def.icon then
					RNDX.DrawMaterial(0, gRespX(35), gRespY(25), gRespX(80), gRespY(80),
						Color(255, 255, 255, slot.sold and 80 or 255), Material(def.icon))
				end
				local name = (def and def.name) or string.upper(tostring(slot.rarity))
				draw.SimpleText(name, "Avenir Next World:16", w / 2, gRespY(125),
					Color(255, 255, 255, slot.sold and 120 or 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			-- « EPUISE » DEVANT le modèle 3D (07/22, demande user « le sold out se met derrière le
			-- model ») : la case coffre monte un DModelPanel ENFANT, dessiné APRÈS le Paint du bouton
			-- -> un marqueur dessiné en Paint passait DERRIÈRE le modèle. PaintOver tourne APRÈS les
			-- enfants -> voile sombre sur la zone du modèle + texte « EPUISE » repassent DEVANT.
			btn.PaintOver = function(selff, w, h)
				local slot = self.chest_state and self.chest_state.slots and self.chest_state.slots[i]
				if not (slot and slot.sold) then return end
				surface.SetDrawColor(8, 9, 11, 165)
				surface.DrawRect(0, 0, w, gRespY(118))
				draw.SimpleText("EPUISE", "Avenir Next World:16", w / 2, gRespY(75),
					COL_SOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			btn.DoClick = function()
				local slot = self.chest_state and self.chest_state.slots and self.chest_state.slots[i]
				if not slot then return end
				local itemId = chestCfg.chest_items and chestCfg.chest_items[slot.rarity]
				if not itemId then return end
				self.selected_chest_slot = i
				self.selected_item = itemId
				self:UpdateSelectedItemPreview()
			end
			btn.OnCursorEntered = function(selff) selff.hovered = true end
			btn.OnCursorExited  = function(selff) selff.hovered = false end
			btn:SetVisible(false)
			table.insert(self.chest_buttons, btn)
		end

		-- Demande le state au serveur
		net.Start("lzy_npcshop:chests:request")
		net.SendToServer()
	end

	-- Pre-selection du premier item visible : a l'ouverture, le panneau de
	-- droite (preview + nom + buy button) doit deja afficher quelque chose
	-- plutot que d'etre vide.
	if visibleProducts and visibleProducts[1] and ITEMS[visibleProducts[1].item_id] then
		self.selected_item = visibleProducts[1].item_id
	end

	-- Initial filter
	self:FilterItemsByCategory()
	self:EnsureSelectedDetailsScroll()

	-- Buy button (sous le slider de quantité)
	self.buy_btn = vgui.Create("DButton", self)
	self.buy_btn:gSetSize(654, 56)
	self.buy_btn:gSetPos(964, 866)
	self.buy_btn:SetText("")
	self.buy_btn:SetMouseInputEnabled(true)
	self.buy_btn:SetKeyboardInputEnabled(false)
	self.buy_btn.Paint = function(selff, w, h)
		-- Bouton ACHETER DA (remplace les PNG buy_btn/buy_btn_hover) : plaque
		-- accent à coin coupé + libellé Bebas + prix en OR ; sans sélection =
		-- plaque sombre + libellé éteint. (DA Atelier 07/07)
		if not self.selected_item then
			shopPlate(0, 0, w, h, COL_PLATE_SUB, gRespY(10), "br")
			draw.SimpleText("ACHETER", "Bebas Neue:22", gRespX(24), h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return
		end
		local qty = (self._getBuyQty and self._getBuyQty()) or 1
		shopPlate(0, 0, w, h, selff.hovered and COL_ACCENT_BTN_HOV or COL_ACCENT_BTN, gRespY(10), "br")
		local buyLabel = (qty > 1) and ("ACHETER  ×" .. qty) or "ACHETER"
		draw.SimpleText(buyLabel, "Bebas Neue:22", gRespX(24), h / 2, COL_WHITE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local product_price = npcshopGetSelectedUnitPrice(self)
		if product_price then
			draw.SimpleText(tostring(product_price * qty), "Bebas Neue:26", w - gRespX(24), h / 2, COL_WHITE, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
	self.buy_btn.cooldown = 0
	self.buy_btn.cooldownTime = 3 -- seconds between allowed buys

	self.buy_btn.DoClick = function(selff)
		if not self.selected_item then return end

		-- Simple anti-spam: block if still on cooldown
		if selff.cooldown and selff.cooldown > CurTime() then return end

		selff.cooldown = CurTime() + selff.cooldownTime

		-- Si un slot de coffre est selectionne, on emet le net specifique aux coffres.
		if self.selected_chest_slot then
			net.Start("lzy_npcshop:chests:buy")
			net.WriteUInt(self.selected_chest_slot, 4)
			net.SendToServer()
			return
		end

		local qty = (self._getBuyQty and self._getBuyQty()) or 1
		local maxCap = math.max(1, math.floor(tonumber(NPCSHOP_CONFIG.MaxBuyQty) or 64))
		net.Start("server:lzy_npcshop.buy_item")
		net.WriteString(self.selected_item)
		net.WriteUInt(math.Clamp(math.floor(qty), 1, maxCap), 8)
		net.SendToServer()
	end
	self.buy_btn.OnCursorEntered = function(selff)
		selff.hovered = true
	end
	self.buy_btn.OnCursorExited = function(selff)
		selff.hovered = false
	end

	-- Bouton PREVIEW : ouvre l'apercu cosmetique global du lzy_shop sur le perso
	-- du joueur (LZY_SHOP_COSMETIC_PREVIEW.Open). Visible uniquement quand l'item
	-- selectionne a un model_path (sinon la preview n'a rien a afficher).
	self.preview_btn = vgui.Create("DButton", self)
	self.preview_btn:gSetSize(140, 38)
	self.preview_btn:gSetPos(1478, 704)
	self.preview_btn:SetText("")
	self.preview_btn:SetMouseInputEnabled(true)
	self.preview_btn:SetKeyboardInputEnabled(false)
	self.preview_btn.Paint = function(selff, w, h)
		if not self.selected_item then return end
		local itemData = ITEMS and ITEMS[self.selected_item]
		if not npcshopPreviewBtnVisibleFor(itemData) then return end
		-- Mini-plaque neutre DA, libellé accent au survol (remplace le
		-- RoundedBox noir + cyan hors-DA). (DA Atelier 07/07)
		shopPlate(0, 0, w, h, selff.hovered and COL_SLOT_HOV or COL_PLATE_SUB2, gRespY(8), "br")
		draw.SimpleText("PREVIEW", "Bebas Neue:18", w / 2, h / 2,
			selff.hovered and COL_ACCENT_HOV or COL_MUTED,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.preview_btn.DoClick = function()
		if not self.selected_item then return end
		local itemData = ITEMS and ITEMS[self.selected_item]
		if not npcshopPreviewBtnVisibleFor(itemData) then return end
		if LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open then
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			LZY_SHOP_COSMETIC_PREVIEW.Open(itemData)
		end
	end
	self.preview_btn.OnCursorEntered = function(selff) selff.hovered = true end
	self.preview_btn.OnCursorExited  = function(selff) selff.hovered = false end

	self:UpdateSelectedItemPreview()
end

function PANEL:EnsureSelectedDetailsScroll()
	if IsValid(self.selectedDetailsScroll) and IsValid(self.selectedDetailsCanvas) then return end

	self.selectedDetailsScroll = vgui.Create("DScrollPanel", self)
	self.selectedDetailsScroll:gSetSize(615, 46)
	self.selectedDetailsScroll:gSetPos(983, 760)
	self.selectedDetailsScroll:SetPaintBackgroundEnabled(false)
	self.selectedDetailsScroll.Paint = function() end
	self.selectedDetailsScroll:SetVisible(false)

	local vbar = self.selectedDetailsScroll:GetVBar()
	if IsValid(vbar) then
		if IsValid(vbar.btnUp) then
			vbar.btnUp:SetVisible(false)
			vbar.btnUp:SetSize(0, 0)
			vbar.btnUp.Paint = function() end
		end
		if IsValid(vbar.btnDown) then
			vbar.btnDown:SetVisible(false)
			vbar.btnDown:SetSize(0, 0)
			vbar.btnDown.Paint = function() end
		end
		vbar:SetWidth(gRespX(8))
		vbar.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, Color(255, 255, 255, 5))
		end
		if IsValid(vbar.btnGrip) then
			vbar.btnGrip.Paint = function(_, w, h)
				-- Grip DA : sombre -> accent au survol. (DA Atelier 07/07)
				local gripColor = COL_SCROLL
				if _.Hovered or _.Depressed then
					gripColor = COL_ACCENT
				end
				draw.RoundedBox(4, 2, 0, w - 4, h, gripColor)
			end
		end
	end

	self.selectedDetailsCanvas = vgui.Create("DPanel", self.selectedDetailsScroll)
	self.selectedDetailsCanvas:SetPos(0, 0)
	self.selectedDetailsCanvas:SetSize(gRespX(605), gRespY(80))
	self.selectedDetailsCanvas.Paint = function() end
end

function PANEL:RefreshSelectedItemDetails()
	self:EnsureSelectedDetailsScroll()

	if not self.selected_item or not ITEMS or not ITEMS[self.selected_item] then
		self.selectedDetailsScroll:SetVisible(false)
		self.selectedDetailsCanvas:Clear()
		self.selectedDetailsCanvas:SetTall(gRespY(80))
		return
	end

	local itemData = ITEMS[self.selected_item]
	local description = isstring(itemData.description) and string.Trim(itemData.description) or ""
	local statsLines = npcshopCollectStatsLines(itemData)
	local y = 0
	local contentW = gRespX(592)

	self.selectedDetailsScroll:SetVisible(true)
	self.selectedDetailsCanvas:Clear()

	if description ~= "" then
		local _, descH = gGetMultilineTextSize(description, "Avenir Next World:16", 20, contentW)
		local descPanel = vgui.Create("DPanel", self.selectedDetailsCanvas)
		descPanel:SetPos(0, y)
		descPanel:SetSize(contentW, math.max(1, descH))
		descPanel.Paint = function(_, w, h)
			gRespDrawMultilineText(description, "Avenir Next World:16", 0, 0, Color(255, 255, 255, 180), TEXT_ALIGN_LEFT, 20, contentW, nil, TEXT_ALIGN_TOP)
		end
		y = y + descPanel:GetTall()
	end

	if #statsLines > 0 then
		if description ~= "" then
			y = y + gRespY(2)
		end
		local header = vgui.Create("DLabel", self.selectedDetailsCanvas)
		header:SetText("Statistiques")
		header:SetFont("Avenir Next World:16")
		header:SetTextColor(COL_MUTED) -- DA : plus de bleu chrome (DA Atelier 07/07)
		header:SetPos(0, y)
		header:SizeToContents()
		y = y + header:GetTall() + gRespY(2)

		local statsContent = table.concat(statsLines, "\n")
		local _, statsH = gGetMultilineTextSize(statsContent, "Avenir Next World:16", 20, contentW)
		local statsPanel = vgui.Create("DPanel", self.selectedDetailsCanvas)
		statsPanel:SetPos(0, y)
		statsPanel:SetSize(contentW, math.max(1, statsH))
		statsPanel.Paint = function(_, w, h)
			gRespDrawMultilineText(statsContent, "Avenir Next World:16", 0, 0, Color(140, 200, 160, 255), TEXT_ALIGN_LEFT, 20, contentW, nil, TEXT_ALIGN_TOP)
		end
		y = y + statsPanel:GetTall()
	end

	self.selectedDetailsCanvas:SetTall(math.max(y, gRespY(80)))
end

function PANEL:ClearSelectedItemPreview()
	npcshopClearModelPreview(self)
	self._selectedHasModelPreview = false
end

function PANEL:UpdateSelectedItemPreview()
	if not self.selected_item or not ITEMS or not ITEMS[self.selected_item] then
		self:ClearSelectedItemPreview()
		self:RefreshSelectedItemDetails()
		if IsValid(self.preview_btn) then self.preview_btn:SetVisible(false) end
		self:RebuildQtyPicker()
		return
	end
	self._selectedHasModelPreview = npcshopTryMountModelPreview(
		self,
		ITEMS[self.selected_item],
		gRespX(1141),
		gRespY(282),
		gRespX(300),
		gRespY(300),
		NPCSHOP_SELECTED_MODEL_FOV
	)
	self:RefreshSelectedItemDetails()
	if IsValid(self.preview_btn) then
		self.preview_btn:SetVisible(npcshopPreviewBtnVisibleFor(ITEMS[self.selected_item]))
	end
	self:RebuildQtyPicker()
end

function PANEL:RebuildQtyPicker()
	if not IsValid(self.qty_host) then
		self.qty_host = vgui.Create("DPanel", self)
		self.qty_host:SetPaintBackgroundEnabled(false)
		self.qty_host:SetMouseInputEnabled(true)
		self.qty_host:SetKeyboardInputEnabled(true)
		self.qty_host:SetZPos(20)
		self.qty_host.Paint = function() end
	else
		self.qty_host:Clear()
	end
	self._getBuyQty = function() return 1 end

	-- Coffres journaliers : 1 seul achat par slot, pas de slider.
	if self.selected_chest_slot or not self.selected_item then
		self.qty_host:SetVisible(false)
		return
	end
	if not (EVO_UI and EVO_UI.QtyPicker) then
		self.qty_host:SetVisible(false)
		return
	end

	local maxQ = math.max(1, math.floor(tonumber(NPCSHOP_CONFIG.MaxBuyQty) or 64))
	if maxQ <= 1 then
		self.qty_host:SetVisible(false)
		return
	end

	self.qty_host:gSetSize(654, 58)
	self.qty_host:gSetPos(964, 808)
	self.qty_host:SetVisible(true)
	self._getBuyQty = EVO_UI.QtyPicker(self.qty_host, 0, 0, self.qty_host:GetWide(), self.qty_host:GetTall(), maxQ, 1)
end

function PANEL:FilterItemsByCategory()
	if not self.item_buttons or not self.category_keys then return end

	local selected_category_key = self.category_keys[self.current_category]
	if not selected_category_key then return end

	local searchText = self.searchText or ""
	local items_per_row = 4
	local item_width = 150
	local item_height = 150
	local spacing = 15
	local visible_index = 0

	-- "coffres" est une categorie virtuelle. Les chest_buttons sont visibles sur
	-- "coffres" ET "all" (placés en tête de grille pour qu'on les voie tout de
	-- suite a l'ouverture du shop).
	local isChestsTab = selected_category_key == "coffres"
	local showChests  = isChestsTab or selected_category_key == "all"
	local chestCfg = NPCSHOP_CONFIG.chest_slots

	-- Chest slots positionnes en premier dans la grille pour qu'ils prennent
	-- les premieres cases (top-left).
	if self.chest_buttons then
		for _, btn in ipairs(self.chest_buttons) do
			if IsValid(btn) then
				local matchesSearch = true
				if showChests and searchText ~= "" then
					local slot = self.chest_state and self.chest_state.slots and self.chest_state.slots[btn._chest_slot_idx]
					local itemId = slot and chestCfg and chestCfg.chest_items and chestCfg.chest_items[slot.rarity]
					matchesSearch = npcshopMatchesSearch(itemId, searchText)
				end
				if showChests and matchesSearch then
					btn:SetVisible(true)
					local row = math.floor(visible_index / items_per_row)
					local col = visible_index % items_per_row
					btn:gSetPos(col * (item_width + spacing), row * (item_height + spacing))
					visible_index = visible_index + 1
				else
					btn:SetVisible(false)
				end
			end
		end
	end

	-- Items reguliers : caches quand "coffres" est selectionne.
	for _, item_btn in ipairs(self.item_buttons) do
		if IsValid(item_btn) then
			local itemId = item_btn.product_data and item_btn.product_data.item_id
			local matchesCat = not isChestsTab and (selected_category_key == "all" or item_btn.item_category == selected_category_key)
			if matchesCat and npcshopMatchesSearch(itemId, searchText) then
				item_btn:SetVisible(true)
				local row = math.floor(visible_index / items_per_row)
				local col = visible_index % items_per_row
				local x = col * (item_width + spacing)
				local y = row * (item_height + spacing)
				item_btn:gSetPos(x, y)
				visible_index = visible_index + 1
			else
				item_btn:SetVisible(false)
			end
		end
	end
end

function PANEL:Paint(w, h)
	-- Fond plein écran DA Atelier (remplace le PNG bg 1920x1080) : monde
	-- flouté + assombri, puis plaque métal noir à coins coupés + liseré acier
	-- + 4 vis d'angle. (DA Atelier 07/07)
	if RNDX and RNDX.Draw and RNDX.BLUR then
		RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
	end
	surface.SetDrawColor(COL_FOND)
	surface.DrawRect(0, 0, w, h)

	local cardX, cardY = gRespX(SHOP_CARD_X), gRespY(SHOP_CARD_Y)
	local cardW, cardH = gRespX(SHOP_CARD_W), gRespY(SHOP_CARD_H)
	if EVO_UI and EVO_UI.PaintCut then
		-- DA dashboard 08/07 : plus de liseré acier (plaque plate).
		EVO_UI.PaintCut(cardX, cardY, cardW, cardH, COL_CARD, gRespY(16))
	else
		surface.SetDrawColor(COL_CARD)
		surface.DrawRect(cardX, cardY, cardW, cardH)
	end

	-- bc2 en trame fantôme floutée sur la plaque, SANS zoom (étirée pile sur
	-- la carte, pas de cover/contain-crop). ENCORE plus translucide (x10,
	-- demande user 08/07) : alpha au minimum praticable.
	if bgShop2 and not bgShop2:IsError() then
		if EVO_UI and EVO_UI.GhostBlur then
			EVO_UI.GhostBlur(bgShop2, cardX, cardY, cardW, cardH, 1)
		else
			surface.SetDrawColor(255, 255, 255, 1)
			surface.SetMaterial(bgShop2)
			surface.DrawTexturedRect(cardX, cardY, cardW, cardH)
		end
	end

	-- 4 vis d'angle de la plaque (TR/BL décalées : coins coupés).
	-- DA dashboard 08/07 : vis alignées 18px sur les 2 axes.
	local sr = gRespY(5)
	drawScrew(cardX + gRespX(18), cardY + gRespY(18), sr)
	drawScrew(cardX + cardW - gRespX(18), cardY + gRespY(18), sr)
	drawScrew(cardX + cardW - gRespX(18), cardY + cardH - gRespY(18), sr)
	drawScrew(cardX + gRespX(18), cardY + cardH - gRespY(18), sr)

	-- Titre Bebas SANS bold + entaille slash1 (remplace le PNG header_title).
	local sTitle = string.upper((NPCSHOP_CONFIG and NPCSHOP_CONFIG.NpcName) or "URAHARA SHOP")
	draw.SimpleText(sTitle, "Bebas Neue:34", gRespX(174), gRespY(118), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:34")
	local twT, thT = surface.GetTextSize(sTitle)
	-- Titre center-aligné vertical à c=gRespY(118) -> haut = c - th/2, slash à
	-- haut + th*0.78 = c + th*0.28 (comme la réf BOUTIQUE : 78% de la hauteur
	-- mesurée). th en pixels écran s'additionne à c déjà scalé (gRespY).
	if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(172), gRespY(118) + thT * 0.28, twT * 1.15, gRespY(9), ColorAlpha(COL_ACCENT, 245))) then
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(gRespX(174), gRespY(118) + thT * 0.34, twT, math.max(2, gRespY(3)))
	end

	-- Selected item panel
	if self.selected_item then
		local itemData = ITEMS[self.selected_item]
		if not itemData then return end
		local itemName = itemData and itemData.name or self.selected_item
		local rarityLabel = itemData and npcshopGetRarityTierLabel(itemData.rarity) or nil

		-- Halo de rareté + icône : PNG de CONTENU (couleur = rareté), conservés.
		local rarityColor = INVENTORY_CONFIG.raritiesColor and INVENTORY_CONFIG.raritiesColor[itemData.rarity] or "gray"
		RNDX.DrawMaterial(0, gRespX(944), gRespY(85), gRespX(694), gRespY(694), Color(255, 255, 255, 255), materials["rarity_" .. rarityColor] or materials.rarity_gray)
		if not self._selectedHasModelPreview and itemData.icon then
			RNDX.DrawMaterial(0, gRespX(1141), gRespY(282), gRespX(300), gRespY(300), Color(255, 255, 255, 255), Material(itemData.icon))
		end

		-- Sous-plaque détails (remplace le PNG item_panel) — sans liseré
		-- (coins coupés = rendu crénelé). (DA Atelier 07/07)
		shopPlate(gRespX(944), gRespY(610.5), gRespX(694), gRespY(313), COL_PLATE_SUB2, gRespY(12))

		draw.SimpleText(itemName, "Bebas Neue:26", gRespX(983), gRespY(709), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if rarityLabel then
			draw.SimpleText("Rareté: ", "Avenir Next World:16", gRespX(983), gRespY(736), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(rarityLabel, "Avenir Next World:16", gRespX(1048), gRespY(736), npcshopGetRarityTierTextColor(itemData.rarity), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
end

function PANEL:OnClose()
	self:ClearSelectedItemPreview()
	if IsValid(self.selectedDetailsScroll) then
		self.selectedDetailsScroll:Remove()
		self.selectedDetailsScroll = nil
		self.selectedDetailsCanvas = nil
	end
	-- Ferme aussi la preview cosmetique du lzy_shop si elle etait ouverte
	-- depuis l'urahara shop (le bouton PREVIEW). Sinon elle reste a l'ecran
	-- meme apres fermeture du shop, ce qui est confusant pour le joueur.
	if LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Close then
		LZY_SHOP_COSMETIC_PREVIEW.Close()
	end
	timer.Simple(0.1, function() can_open = true end)
	frame = nil
	self:Remove()
end

function PANEL:OnKeyCodePressed(keycode)
	if keycode == KEY_ESCAPE and can_open == false then
		self:Close()
		return true
	end
end

vgui.Register("lzy_npcshop", PANEL, "DFrame")

-- Reception de l'etat des coffres journaliers (envoye par sv_chests.lua a
-- l'ouverture du shop et apres chaque achat). Met a jour le state local pour
-- que les chest_buttons s'affichent correctement.
net.Receive("lzy_npcshop:chests:state", function()
	local nSlots = net.ReadUInt(4)
	local slots = {}
	for i = 1, nSlots do
		slots[i] = {
			rarity = net.ReadString(),
			sold   = net.ReadBool(),
		}
	end
	local resetIn = net.ReadUInt(32)
	if not IsValid(frame) then return end
	frame.chest_state = { slots = slots, reset_in = resetIn }
	-- Re-filtre : les noms des coffres n'existent qu'apres reception du state.
	if frame.FilterItemsByCategory then
		frame:FilterItemsByCategory()
	end
end)


function OpenNPCShop()
	if IsValid(frame) then
		frame:Close()
	else
		frame = vgui.Create("lzy_npcshop")
		can_open = false
	end
end
