-- "addons\\lzy_npcshop\\lua\\lzy_npcshop\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
NPCSHOP_CONFIG = NPCSHOP_CONFIG or {}

NPCSHOP_CONFIG.NpcModel = "models/evo/summons/shinigami/evo_0my4bjfay05m/evo_0kp2wxsf1aou3.mdl"
NPCSHOP_CONFIG.NpcName = "Urahara Shop"
NPCSHOP_CONFIG.NpcIdleAnim = "evo_p1f8adr3s0zd2t" -- sequence jouee en boucle par l'entity
NPCSHOP_CONFIG.showNpcNameMaxDistance = 500
NPCSHOP_CONFIG.customUseDistance = 200 -- check ENT:Use large : interaction via evo_npc_interact (E client) jusqu'à PromptDistance
NPCSHOP_CONFIG.PromptDistance     = 160 -- portée d'interaction réelle (E marche jusque-là, demande user)
NPCSHOP_CONFIG.MaxZDelta          = 200 -- ecart Z max joueur<->npc pour afficher le prompt

-- Spawn auto par map (cote serveur, hook InitPostEntity dans sv_spawn.lua).
-- Le NPC est un prop_dynamic statique avec le model NpcModel ; l'interaction
-- passe par cl_npc.lua qui detecte les entites par modele.
NPCSHOP_CONFIG.SpawnPositions = {
	rp_seireitei_v1 = {
		-- Recul de 90u sur l'axe X uniquement (Y inchangé) — encore +20
		{ pos = Vector(-8146.940618, 7748.168141, 428.747803), ang = Angle(0, 179.819458, 0) },
	},
	hueco_mundo_v1 = {
		-- Pos user 2026-06 (setpos 1191.43 7953.03 5351.29, regard yaw 85.44).
		-- Yaw BRUT : le +180 le mettait pile à l'envers (vérifié in-game).
		{ pos = Vector(1191.425293, 7953.031250, 5351.293457), ang = Angle(0, 85.44, 0) },
	},
	gm_construct = {
		{ pos = Vector(200, 200, -135), ang = Angle(0, 270, 0) },
	},
}

-- Plafond d'achat par clic (slider quantité). Les coffres journaliers restent à 1.
NPCSHOP_CONFIG.MaxBuyQty = 64

-- Category tab order in the NPC shop UI.
-- Use category keys from ITEMS[...].category, plus optional "all".
-- Unlisted categories are appended afterward (alphabetical by display name).
-- "coffres" est une categorie virtuelle (slots quotidiens, voir NPCSHOP_CONFIG.chest_slots).
NPCSHOP_CONFIG.category_order = {
	"all",
	"coffres",
	"outfit",
	"accessory",
	"object",
}

-- ============================================================================
-- COFFRES JOURNALIERS
-- ----------------------------------------------------------------------------
-- Chaque jour a 00:00 (heure serveur), 3 coffres sont tires pour chaque
-- joueur. La rarete de chaque slot est pondere par rarity_weights. Une fois
-- achete, le slot est marque vendu pour ce joueur jusqu'au reset suivant.
-- Le coffre lui-meme (item_id) vient de evo_loot (coffre_commun/rare/...).
-- ============================================================================
NPCSHOP_CONFIG.chest_slots = {
	daily_picks = 3,
	-- Memes poids que la rotation cosmetiques du lzy_shop.
	rarity_weights = {
		common    = 50,
		rare      = 30,
		epic      = 10,
		legendary = 7.5,
		mythic    = 2.5,
	},
	-- Prix en money in-game (yens), par rarete. (Valeurs fixées par le user 07/22.)
	chest_prices = {
		common    = 1000,
		rare      = 2500,
		epic      = 5000,
		legendary = 10000,
		mythic    = 20000,
	},
	-- Mapping rarete -> item_id du coffre dans evo_loot.
	chest_items = {
		common    = "coffre_commun",
		rare      = "coffre_rare",
		epic      = "coffre_epique",
		legendary = "coffre_legendaire",
		mythic    = "coffre_mythique",
	},
}

-- Normalise un genre quelconque ("m"/"f"/"male"/"female"/...) en "male"/"female"
-- ou nil si indeterminable. Inline ici car LZY_CHARACTER_CONFIG.NormalizeGender
-- est defini cote client uniquement, alors que ce filtre tourne aussi serveur.
local function NormGender(g)
	if not g then return nil end
	g = string.lower(tostring(g))
	if g == "f" or g == "female" then return "female" end
	if g == "m" or g == "male" then return "male" end
	return nil
end

-- Filtrage faction + genre : un produit n'est visible (UI + achat) que si :
--   - faction : pas de `faction` => toutes factions, sinon match du NWString
--     "FactionName" du joueur.
--   - genre   : une tenue genree (gender male/female via INVENTORY_CONFIG.
--     GetItemGender) n'est visible que pour les joueurs du meme genre. Les items
--     sans genre (unisexe, accessoires, objets, coffres) restent visibles a tous.
-- Le genre du joueur est lu dans le NWString "Gender" (pose par lzy_character).
function NPCSHOP_CONFIG.IsProductVisibleForPlayer(product, ply)
	if not product then return false end
	if not IsValid(ply) then return false end

	-- Item INEXISTANT (addon fournisseur non chargé, id renommé) -> produit masqué.
	-- Sans ça le panneau plantait sur ITEMS[id].category (cl_main:412) et TOUT le shop
	-- devenait inouvrable. Le serveur passe par ici aussi : l'achat est refusé de même.
	-- Agri s'enregistre en retry : si le shop s'ouvre trop tôt, on retente ici.
	if not (ITEMS and ITEMS[product.item_id]) then
		if EVO_AGRI and EVO_AGRI.RegisterItems then EVO_AGRI.RegisterItems() end
		if not (ITEMS and ITEMS[product.item_id]) then return false end
	end

	-- Produit réservé au staff : masqué en rayon ET achat refusé, puisque le
	-- serveur repasse par cette même fonction avant de débiter.
	if product.superadmin and not ply:IsSuperAdmin() then return false end

	-- Produit réservé à la DIVISION SCIENTIFIQUE (user 08/19, ex. fiole vide) :
	-- même règle, masqué en rayon et achat refusé côté serveur.
	if product.scienceOnly then
		if not (EVO_SCIENCE and EVO_SCIENCE.IsScientist and EVO_SCIENCE.IsScientist(ply)) then
			return false
		end
	end

	-- Produit réservé aux membres du Bar (evo_business).
	-- Produit réservé aux membres d'un commerce kind « bar » (multi-bars).
	-- Exception : agriculture (graine + pots) reste publique.
	if product.barOnly and product.item_id ~= "graine_ble" and not (EVO_AGRI and EVO_AGRI.IsPotItem and EVO_AGRI.IsPotItem(product.item_id)) then
		if not (EVO_BUSINESS and EVO_BUSINESS.IsKindMember and EVO_BUSINESS.IsKindMember(ply, "bar")) then
			return false
		end
	end

	-- Filtre faction
	if product.faction and product.faction ~= "" then
		if ply:GetEvoNWString("FactionName", "") ~= product.faction then return false end
	end

	-- Filtre genre
	local itemData = ITEMS and ITEMS[product.item_id]
	local itemGender = itemData and INVENTORY_CONFIG and INVENTORY_CONFIG.GetItemGender
		and INVENTORY_CONFIG.GetItemGender(itemData) or nil
	if itemGender then
		local plyGender = NormGender(ply:GetEvoNWString("Gender", ""))
		-- Genre joueur connu et different => cache. Genre inconnu => on laisse voir.
		if plyGender and plyGender ~= itemGender then return false end
	end

	return true
end

function NPCSHOP_CONFIG.GetVisibleProducts(ply)
	local out = {}
	for _, p in ipairs(NPCSHOP_CONFIG.products or {}) do
		if NPCSHOP_CONFIG.IsProductVisibleForPlayer(p, ply) then
			out[#out + 1] = p
		end
	end
	return out
end

-- Urahara Shop : tenues par faction.
-- Le genre (Homme/Femme) est porte par l'item (champ `gender` ou derive du
-- model_path via INVENTORY_CONFIG.GetItemGender). Les tenues genrees ne sont
-- visibles/achetables que par les joueurs du meme genre (voir
-- IsProductVisibleForPlayer). Les items sans genre restent visibles a tous.
NPCSHOP_CONFIG.products = {
	-- ───── Tenues Arrancar (Hollow) ─────
	-- Equipe (male)
	{ item_id = "arrancar_equipe_bleu_outfit",   price = 10, faction = "Hollow" },
	{ item_id = "arrancar_equipe_orange_outfit", price = 10, faction = "Hollow" },
	{ item_id = "arrancar_equipe_rouge_outfit",  price = 10, faction = "Hollow" },
    { item_id = "arrancar_equipe_vert_outfit",        price = 10,    faction = "Hollow" },

	-- Autres male
	{ item_id = "arrancar_base_noir_outfit",     price = 25000, faction = "Hollow" },
    { item_id = "arrancar_del_socaccio_outfit",       price = 50000, faction = "Hollow" },
	-- Recolorations Del Socaccio SORTIES du coffre (user 09/06) : prix de l'originale.
	{ item_id = "arrancar_del_socaccio_boutique_bordeaux_bronze_outfit", price = 50000, faction = "Hollow" },
	{ item_id = "arrancar_del_socaccio_boutique_jade_ivoire_outfit", price = 50000, faction = "Hollow" },
	{ item_id = "arrancar_del_socaccio_boutique_nuit_argent_outfit", price = 50000, faction = "Hollow" },
	{ item_id = "arrancar_del_socaccio_boutique_violet_or_outfit", price = 50000, faction = "Hollow" },

	-- Base noir (female, user 09/19) : meme prix que le pendant male.
	{ item_id = "arrancar_base_noir_f_outfit",   price = 25000, faction = "Hollow" },

	-- Equipe / entrainement (female) : meme prix que les pendants male ci-dessus.
	{ item_id = "arrancar_equipe_bleu_f_outfit",   price = 10, faction = "Hollow" },
	{ item_id = "arrancar_equipe_orange_f_outfit", price = 10, faction = "Hollow" },
	{ item_id = "arrancar_equipe_rouge_f_outfit",  price = 10, faction = "Hollow" },
	{ item_id = "arrancar_equipe_vert_f_outfit",   price = 10, faction = "Hollow" },

	-- Tenues d'ENTRAINEMENT arrancar (user 08/17) : set distinct des "equipe",
	-- couleurs rouge/bleu/violet/vert, male + female.
	{ item_id = "arrancar_entrainement_rouge_outfit",    price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_bleu_outfit",     price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_violet_outfit",   price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_vert_outfit",     price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_rouge_f_outfit",  price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_bleu_f_outfit",   price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_violet_f_outfit", price = 10, faction = "Hollow" },
	{ item_id = "arrancar_entrainement_vert_f_outfit",   price = 10, faction = "Hollow" },

	-- Female
	{ item_id = "arrancar_apacci_outfit",        price = 50000, faction = "Hollow" },

	-- ───── Tenues Shinigami ─────
	-- Equipe (male)
	{ item_id = "shinigami_equipe_bleu_outfit",   price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_equipe_orange_outfit", price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_equipe_rouge_outfit",  price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_equipe_vert_outfit",   price = 10, faction = "Shinigami" },
	-- Autres male
	{ item_id = "shinigami_manche_longue_outfit", price = 15000, faction = "Shinigami" },
	{ item_id = "shinigami_shuhei_hisagi_outfit", price = 60000, faction = "Shinigami" },
	{ item_id = "shinigami_sans_manche_outfit",   price = 40000, faction = "Shinigami" },
	-- Recolorations SORTIES du Coffre de Tenues (user 09/06) : même prix que leur originale.
	{ item_id = "shinigami_sans_manche_boutique_bordeaux_bronze_outfit", price = 40000, faction = "Shinigami" },
	{ item_id = "shinigami_sans_manche_boutique_jade_ivoire_outfit", price = 40000, faction = "Shinigami" },
	{ item_id = "shinigami_sans_manche_boutique_nuit_argent_outfit", price = 40000, faction = "Shinigami" },
	{ item_id = "shinigami_sans_manche_boutique_rose_noir_outfit", price = 40000, faction = "Shinigami" },
	{ item_id = "shinigami_shuhei_hisagi_boutique_bordeaux_bronze_outfit", price = 60000, faction = "Shinigami" },
	{ item_id = "shinigami_shuhei_hisagi_boutique_jade_ivoire_outfit", price = 60000, faction = "Shinigami" },
	{ item_id = "shinigami_shuhei_hisagi_boutique_nuit_argent_outfit", price = 60000, faction = "Shinigami" },
	{ item_id = "shinigami_shuhei_hisagi_boutique_sable_cuivre_outfit", price = 60000, faction = "Shinigami" },
	{ item_id = "shinigami_Yumichika_outfit",      price = 25000, faction = "Shinigami" },
	{ item_id = "shinigami_Yumichika_bleu_outfit", price = 25000, faction = "Shinigami" },
	{ item_id = "shinigami_Yumichika_vert_outfit", price = 25000, faction = "Shinigami" },
	-- Tenues homme (ajouts 2026-07)
	{ item_id = "shinigami_brume_silencieuse_outfit", price = 50000, faction = "Shinigami" },
	{ item_id = "shinigami_encre_sacree_outfit",      price = 50000, faction = "Shinigami" },
	{ item_id = "shinigami_plumes_blanches_outfit",   price = 50000, faction = "Shinigami" },
    { item_id = "shinigami_eclipse_outfit",           price = 50000, faction = "Shinigami" },

	-- Equipe / entrainement (female) : meme prix que les pendants male ci-dessus.
	{ item_id = "shinigami_entrainement_bleu_f_outfit",   price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_entrainement_orange_f_outfit", price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_entrainement_rouge_f_outfit",  price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_entrainement_vert_f_outfit",   price = 10, faction = "Shinigami" },

	-- Female
	{ item_id = "shinigami_base_f_00_outfit",     price = 10, faction = "Shinigami" },
	{ item_id = "shinigami_base_f_01_outfit",     price = 10, faction = "Shinigami" },

	-- TENUES FEMMES (user 09/07) : 4 Shinigami + 4 Arrancar, 8 000 a 35 000 yens selon la rarete.
	{ item_id = "urahara_f_fumee_outfit", price = 8000, faction = "Shinigami" },
	{ item_id = "urahara_f_encre_outfit", price = 10000, faction = "Shinigami" },
	{ item_id = "urahara_f_terre_outfit", price = 20000, faction = "Shinigami" },
	{ item_id = "urahara_f_pin_outfit", price = 35000, faction = "Shinigami" },
	{ item_id = "urahara_f_lin_outfit", price = 8000, faction = "Hollow" },
	{ item_id = "urahara_f_lichen_outfit", price = 10000, faction = "Hollow" },
	{ item_id = "urahara_f_argile_claire_outfit", price = 20000, faction = "Hollow" },
	{ item_id = "urahara_f_galet_outfit", price = 35000, faction = "Hollow" },

	-- ───── Katanas (exclusifs Urahara Shop) ─────
	{ item_id = "katana_variant_014", price = 80000 },
	{ item_id = "katana_variant_020", price = 80000 },
	-- PALIER D'ENTREE en yens (user 09/06) : accessoires simples 2 000-3 000, katanas et
	-- gantelets de recrue a service 12 000-30 000 (meme echelle pour les deux voies).
	-- Sans faction = visibles par tous.
	{ item_id = "bourse_yens_toile", price = 2000 },
	{ item_id = "gourde_yens_bois", price = 2000 },
	{ item_id = "lunettes_yens_noires", price = 2500 },
	{ item_id = "lunettes_yens_rondes", price = 2500 },
	{ item_id = "chapeau_yens_paille", price = 3000 },
	{ item_id = "katana_yens_recrue", price = 12000 },
	{ item_id = "katana_yens_exercice", price = 15000 },
	{ item_id = "katana_yens_standard", price = 20000 },
	{ item_id = "katana_yens_patrouille", price = 25000 },
	{ item_id = "katana_yens_court_service", price = 30000 },
	{ item_id = "gauntlet_yens_entrainement", price = 12000 },
	{ item_id = "gauntlet_yens_cuir_simple", price = 15000 },
	{ item_id = "gauntlet_yens_bandes_croisees", price = 20000 },
	{ item_id = "gauntlet_yens_plaque_brute", price = 25000 },
	{ item_id = "gauntlet_yens_service", price = 30000 },

	-- ───── Masques d'anonymat (demande user 09/08) ─────
	-- PAS de champ `faction` : volontairement vendus aux DEUX factions. Le slot masque
	-- (case 7 de l'inventaire) n'est plus réservé aux Arrancar — un Shinigami peut donc
	-- en porter un. 4 variantes de texture du même modèle.
	-- Porté, le masque rend anonyme : le nom RP du porteur devient « ??? » partout
	-- (au-dessus des têtes, chat, menu C, voix...). Cf. INVENTORY_CONFIG.ItemHidesIdentity.
	{ item_id = "masque_anonyme_01", price = 2500 },
	{ item_id = "masque_anonyme_02", price = 2500 },
	{ item_id = "masque_anonyme_03", price = 2500 },
	{ item_id = "masque_anonyme_04", price = 2500 },

	-- ───── Objets ─────
	-- Papier à note (evo_note) : s'utilise (clic droit > Utiliser) pour écrire une note.
	{ item_id = "papier_note", price = 50 },
	-- Livre vierge (evo_livre) : s'utilise pour écrire SON livre, à ranger aux Archives.
	{ item_id = "livre_vierge", price = 250 },
	-- Affiche vierge (evo_affiche) : s'utilise pour rédiger une affiche, à accrocher au mur.
	-- Ouverte à TOUS (demande user 08\13, la réserve staff est levée). Une affiche
	-- accrochée disparaît d'elle-même au bout d'une heure (A.WallLifetime).
	{ item_id = "affiche_vierge", price = 250 },
	-- Pots de culture (evo_agri) : VISIBLES À TOUS (pas barOnly), 500¥.
	{ item_id = "pot_01",      price = 500 },
	{ item_id = "pot_02",      price = 500 },
	{ item_id = "pot_03",      price = 500 },
	{ item_id = "pot_04",      price = 500 },
	{ item_id = "pot_05",      price = 500 },
	{ item_id = "pot_06",      price = 500 },
	-- Bouteille vide (evo_science) : contenant des potions du laboratoire.
	-- RÉSERVÉE à la Division scientifique (user 08/19 : Urahara ne vend que
	-- l'utile, et les fioles vides aux seuls membres du labo).
	{ item_id = "bouteille_vide", price = 100, scienceOnly = true },

	-- ───── Verrerie de laboratoire (evo_science) ─────
	-- REMIS EN RAYON le 08/23 (user). Ils avaient été retirés le 08/19 au motif
	-- qu'Urahara ne vend que de l'utilisable : ne pas les re-supprimer au nom de
	-- cette ancienne règle, la demande a changé.
	-- ⚠ NE PAS confondre medic_seringue (ce prop décoratif) avec seringue_soin,
	-- la VRAIE seringue injectable : elle se CRAFTE à la table médicale, la mettre
	-- en rayon rendrait tout l'atelier médecin contournable pour 100 yens.
	-- Volontairement PAS scienceOnly (contrairement à la bouteille vide juste
	-- au-dessus) : cette verrerie sert autant aux médecins qu'au laboratoire, et
	-- n'a aucun effet de jeu.
	{ item_id = "medic_becher",             price = 100 },
	{ item_id = "medic_entonnoir",          price = 100 },
	{ item_id = "medic_eprouvette_graduee", price = 100 },
	{ item_id = "medic_erlenmeyer",         price = 100 },
	{ item_id = "medic_fiole_jaugee",       price = 100 },
	{ item_id = "medic_mortier",            price = 100 },
	{ item_id = "medic_pilon",              price = 100 },
	{ item_id = "medic_pipette",            price = 100 },
	{ item_id = "medic_seringue",           price = 100 },
	{ item_id = "medic_tube_essai",         price = 100 },
	{ item_id = "medic_verre_mesureur",     price = 100 },

	-- ───── Ingrédients du Bar (evo_business) + agriculture ─────
	-- Graine de blé : VISIBLE À TOUS (pas barOnly) — planter dans un pot + moulin.
	{ item_id = "graine_ble",  price = 600 },
	-- Eau : ouverte à tous (distillerie + arrosage agri). Houblon / levure : membres du Bar.
	-- Bois (res_bois) volontairement PAS en rayon.
	{ item_id = "bar_eau",     price = 20 },
	{ item_id = "bar_houblon", price = 80,  barOnly = true },
	{ item_id = "bar_levure",  price = 60,  barOnly = true },
	{ item_id = "graine_riz",  price = 600, barOnly = true }, -- planter ou cuire
	{ item_id = "bar_koji",    price = 80,  barOnly = true },

	-- ───── Fourreaux ─────
	-- Laque noire du ronin : sortie du Coffre à Fourreaux, vendue ici (09/30, user).
	{ item_id = "fourreau_cos_1", price = 1000 },
}

-- Audit au boot : un produit dont l'item n'existe pas est masqué SILENCIEUSEMENT
-- ci-dessus. On le signale une fois en console, sinon un id renommé disparaît du
-- shop sans que personne ne le remarque. Retardé : les items s'enregistrent en timer.
if SERVER then
	timer.Simple(20, function()
		if not istable(ITEMS) then return end
		local tMissing = {}
		for _, p in ipairs(NPCSHOP_CONFIG.products or {}) do
			if p.item_id and not ITEMS[p.item_id] then tMissing[#tMissing + 1] = p.item_id end
		end
		if #tMissing > 0 then
			print("[lzy_npcshop] " .. #tMissing .. " produit(s) MASQUE(S) — item inexistant : "
				.. table.concat(tMissing, ", "))
		end
	end)
end
