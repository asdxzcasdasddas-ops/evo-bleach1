-- "addons\\lzy_npcshop\\lua\\lzy_npcshop\\cl_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Note : le nametag 3D2D au-dessus de la tete est dessine par-entity dans
-- entities/lzy_npcshop_npc/cl_init.lua (ENT:Draw).

-- ===========================================================================
-- Proximity prompt HUD (pattern coiffeur) : affiche "[E] Parler a Urahara"
-- quand le joueur est a portee, et l'interaction se fait via ENT:Use serveur.
-- ===========================================================================

local function findNearestUrahara()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end

	local lpPos = lp:GetPos()
	local promptDist = tonumber(NPCSHOP_CONFIG.PromptDistance) or 250
	local maxZ = tonumber(NPCSHOP_CONFIG.MaxZDelta) or 200
	local promptDistSqr = promptDist * promptDist

	local best, bestDistSqr = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("lzy_npcshop_npc")) do
		if IsValid(ent) then
			local ePos = ent:GetPos()
			if math.abs(ePos.z - lpPos.z) <= maxZ then
				local d2 = ePos:DistToSqr(lpPos)
				if d2 <= promptDistSqr and d2 < bestDistSqr then
					best, bestDistSqr = ent, d2
				end
			end
		end
	end
	return best
end

surface.CreateFont("LZY_Npcshop_Prompt", {
	font      = "Roboto",
	size      = 22,
	weight    = 600,
	antialias = true,
})
surface.CreateFont("LZY_Npcshop_Subtitle", {
	font      = "Roboto",
	size      = 16,
	weight    = 400,
	antialias = true,
})

-- Prompt « [E] Parler … » : DESSINÉ PAR LE SYSTÈME CENTRAL evo_npc_core (même UI plaque
-- Atelier + même logique « le plus proche affiche » pour TOUS les PNJ, user 2026-07-17).
-- (Shop ouvert = curseur visible -> le core masque déjà le prompt.)
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["npcshop"] = {
	fGetTarget = findNearestUrahara,
	fLabel = function() return "[E] Parler a " .. (NPCSHOP_CONFIG.NpcName or "Urahara") end,
	fSub = function() return "Objets cosmetiques & coffres" end,
}

-- Reception du net "open" emis par ENT:Use serveur quand le joueur appuie
-- sur E sur le NPC.
net.Receive("lzy_npcshop:open", function()
	if OpenNPCShop then OpenNPCShop() end
end)
