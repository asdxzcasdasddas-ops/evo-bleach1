-- "addons\\evo_shikai_ui\\lua\\autorun\\sh_evo_shikai_ui_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- evo_shikai_ui — Menu plein écran des pouvoirs (Shikai/Bankai
-- côté Shinigami ; Resurrección Partielle/Resurrección côté Hollow).
-- DHTML plein écran : nom du pouvoir en dégradé animé, katana
-- équipé en 3D au centre (rotation souris), statistiques, et
-- améliorations d'effets achetables en yens. Gate : pouvoir
-- débloqué (NWBool EVO_ShikaiUnlocked / EVO_BankaiUnlocked).
-- ============================================================

if SERVER then
    AddCSLuaFile("evo_shikai_ui/sh_config.lua")
    AddCSLuaFile("evo_shikai_ui/cl_main.lua")
    AddCSLuaFile("evo_shikai_ui/cl_reglage_lame.lua")

    -- Réseau générique porté par un argument "mode" (shikai/bankai).
    util.AddNetworkString("EVO::PowerUI::Sync")    -- sv->cl : mode, upgrades JSON, stats JSON
    util.AddNetworkString("EVO::PowerUI::Request") -- cl->sv : mode (demande de sync à l'ouverture)
    util.AddNetworkString("EVO::PowerUI::SkinPick") -- cl->sv : choix du skin de shikai (id du catalogue ou "rituel")
    util.AddNetworkString("EVO::PowerUI::LameReglage") -- cl->sv : position, rotation et taille (7 floats)
    util.AddNetworkString("EVO::PowerUI::Buy")     -- cl->sv : mode, effectId
    util.AddNetworkString("EVO::PowerUI::Flash")   -- sv->cl : mode (éclair blanc + son sur achat réussi)

    include("evo_shikai_ui/sh_config.lua")
    include("evo_shikai_ui/sv_main.lua")
else
    include("evo_shikai_ui/sh_config.lua")
    include("evo_shikai_ui/cl_main.lua")
    include("evo_shikai_ui/cl_reglage_lame.lua")
end
