-- "addons\\evo_shikai_ui\\lua\\evo_shikai_ui\\cl_reglage_lame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- REGLAGE DE L'ARME DE SHIKAI EN MAIN (katana et hakuda).
-- Une grosse lame traversait le corps de certains PM : le joueur la decale et la
-- tourne dans sa main, camera a l'exterieur et apercu en direct, puis enregistre.
-- Bornes et stockage cote serveur (evo_blanc, R.PoserReglageLame), rendu chez tous
-- par citron_combat_weapons (ReglageLame, qui lit aussi l'apercu ci-dessous).
-- Ouvert par le bouton « Régler en main » du menu Shikai.
--   M.edition : editeur ouvert (l'arme locale montre la lame de shikai, meme hors shikai)
--   M.apercu  : valeurs en cours { lame, pos, ang, scale }, locales au skin regle
-- ============================================================================
EVO_REGLAGE_LAME = EVO_REGLAGE_LAME or {}
local M = EVO_REGLAGE_LAME

-- Memes bornes que le serveur : au-dela il couperait de toute facon.
local POS_MAX, ANG_MAX = 15, 180
local SCALE_MIN, SCALE_MAX = 0.5, 1.5

local function Taille(v)
	v = tonumber(v) or 1
	if v ~= v or v == math.huge or v == -math.huge then return 1 end
	return math.Clamp(v, SCALE_MIN, SCALE_MAX)
end

local COL_PLATE = Color(14, 14, 17, 245)
local COL_BTN   = Color(20, 21, 26, 252)
local COL_ACC   = Color(207, 68, 78)
local COL_TITLE = Color(237, 238, 242)
local COL_MUTED = Color(150, 154, 162)

local function RX(v) return gRespX and gRespX(v) or v end
local function RY(v) return gRespY and gRespY(v) or v end

-- Polices creees au premier usage : gRespFont (glibs) n'est pas garanti au chargement.
local bPolices = false
local function Polices()
	if bPolices then return end
	bPolices = true
	local function T(n) return (gRespFont and gRespFont(n)) or n end
	surface.CreateFont("EVO_ReglageLame_Titre", { font = "Bebas Neue", size = T(30), weight = 400, antialias = true, extended = true })
	surface.CreateFont("EVO_ReglageLame_Txt", { font = "Roboto", size = T(17), weight = 500, antialias = true, extended = true })
	surface.CreateFont("EVO_ReglageLame_Btn", { font = "Bebas Neue", size = T(22), weight = 400, antialias = true, extended = true })
end

-- Lecture commune a l'editeur, au katana et aux gantelets. Les sauvegardes
-- historiques a six valeurs gardent une taille de 100 %. Cache par joueur.
local reglages = setmetatable({}, { __mode = "k" })
function M.Lire(ply, bSansApercu)
	local skin = ply:GetEvoNWString("ShikaiSkin", "")
	local preview = not bSansApercu and ply == LocalPlayer() and M.apercu
	if preview and preview.lame == skin then return preview.pos, preview.ang, Taille(preview.scale) end
	local s = ply:GetEvoNWString("ShikaiLameReglage", "")
	local c = reglages[ply]
	if not c or c.raw ~= s then
		local parts = string.Explode("|", s)
		c = { raw = s, lame = parts[1], valid = #parts == 7 or #parts == 8,
			pos = Vector(tonumber(parts[2]) or 0, tonumber(parts[3]) or 0, tonumber(parts[4]) or 0),
			ang = Angle(tonumber(parts[5]) or 0, tonumber(parts[6]) or 0, tonumber(parts[7]) or 0),
			scale = Taille(parts[8]) }
		reglages[ply] = c
	end
	if not c.valid or c.lame ~= skin then return vector_origin, angle_zero, 1 end
	return c.pos, c.ang, c.scale
end

local function Fermer(bGarderApercu)
	local p = M._pnl
	M._pnl = nil -- AVANT Remove : son OnRemove ne doit pas couper un apercu garde
	M.edition = false
	if IsValid(p) then p:Remove() end
	-- Apres un enregistrement, l'apercu tient le temps que la valeur repliquee arrive :
	-- sans ca la lame sauterait une fraction de seconde a sa place d'origine.
	if bGarderApercu then
		local tGarde = M.apercu
		timer.Simple(1.5, function() if M.apercu == tGarde and not M.edition then M.apercu = nil end end)
	else
		M.apercu = nil
	end
end

-- Curseur maison (DA du menu Shikai) : glisser, molette pour le pas fin, clic droit = defaut.
local function Curseur(parent, sNom, nMin, nMax, nPas, nDefaut, fLire, fEcrire)
	local p = vgui.Create("DPanel", parent)
	p:Dock(TOP)
	p:DockMargin(0, 0, 0, RY(8))
	p:SetTall(RY(38))
	p:SetCursor("sizewe")
	local function Depuis(x)
		local v = nMin + math.Clamp(x / math.max(p:GetWide(), 1), 0, 1) * (nMax - nMin)
		fEcrire(math.Clamp(math.Round(v / nPas) * nPas, nMin, nMax))
	end
	p.Paint = function(s, w, h)
		local v = fLire()
		draw.SimpleText(sNom, "EVO_ReglageLame_Txt", 0, 0, COL_MUTED)
		draw.SimpleText(nPas < 1 and string.format("%.1f", v) or tostring(math.Round(v)), "EVO_ReglageLame_Txt", w, 0, COL_TITLE, TEXT_ALIGN_RIGHT)
		local yB, hB = h - RY(9), RY(4)
		surface.SetDrawColor(255, 255, 255, 18)
		surface.DrawRect(0, yB, w, hB)
		local x0 = math.Clamp((nDefaut - nMin) / (nMax - nMin), 0, 1) * w
		local xV = (v - nMin) / (nMax - nMin) * w
		surface.SetDrawColor(COL_ACC.r, COL_ACC.g, COL_ACC.b, s:IsHovered() and 255 or 200)
		surface.DrawRect(math.min(x0, xV), yB, math.max(math.abs(xV - x0), 1), hB)
		surface.SetDrawColor(COL_TITLE)
		surface.DrawRect(xV - RX(2), yB - RY(4), RX(4), hB + RY(8))
	end
	p.OnMousePressed = function(s, code)
		if code == MOUSE_RIGHT then fEcrire(nDefaut) return end
		if code ~= MOUSE_LEFT then return end
		s._drag = true
		s:MouseCapture(true)
		Depuis((s:CursorPos()))
	end
	p.OnMouseReleased = function(s)
		s._drag = false
		s:MouseCapture(false)
	end
	p.OnCursorMoved = function(s, x) if s._drag then Depuis(x) end end
	p.OnMouseWheeled = function(_, d)
		fEcrire(math.Clamp(fLire() + d * nPas, nMin, nMax))
		return true
	end
	return p
end

local function Bouton(parent, sTexte, fClic)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(s, w, h)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_BTN, RY(8), "br")
		else
			draw.RoundedBox(6, 0, 0, w, h, COL_BTN)
		end
		surface.SetDrawColor(COL_ACC.r, COL_ACC.g, COL_ACC.b, s:IsHovered() and 235 or 120)
		surface.DrawRect(0, 0, RX(3), h)
		draw.SimpleText(sTexte, "EVO_ReglageLame_Btn", w / 2, h / 2, s:IsHovered() and COL_TITLE or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function()
		surface.PlaySound(EVO_UI and EVO_UI.SndClick or "buttons/lightswitch2.wav")
		fClic()
	end
	return b
end

function M.Ouvrir()
	local lp = LocalPlayer()
	if not IsValid(lp) or IsValid(M._pnl) then return end
	local bHakuda = EvoStyle and EvoStyle.GetStyleFamily and EvoStyle.GetStyleFamily(lp:GetEvoNWString("StyleCombat", "")) == "hakuda"
	local catalogue = bHakuda and NCM_HAKUDA_GAUNTLETS or KATANA_SKINS
	if not (catalogue and catalogue.ShikaiModelOf and catalogue.ShikaiModelOf(lp) ~= "") then
		notification.AddLegacy("Aucune arme de libération sur ce personnage.", NOTIFY_ERROR, 4)
		return
	end
	local w = lp:GetActiveWeapon()
	if not (IsValid(w) and w:GetClass() == "citron_combat_weapons") then
		notification.AddLegacy("Sors ton arme de combat pour régler son apparence.", NOTIFY_HINT, 4)
		return
	end
	Polices()

	local vPos, aAng, scale = M.Lire(lp, true)
	M.apercu = { lame = lp:GetEvoNWString("ShikaiSkin", ""), pos = Vector(vPos), ang = Angle(aAng), scale = scale }
	M.edition = true
	M.vue, M.recul = M.vue or 0, M.recul or 80

	local pnl = vgui.Create("DPanel")
	M._pnl = pnl
	local nW, nH = RX(380), RY(610)
	pnl:SetSize(nW, nH)
	pnl:SetPos(ScrW() - nW - RX(40), math.floor((ScrH() - nH) / 2))
	pnl:DockPadding(RX(22), RY(64), RX(22), RY(20))
	pnl.Paint = function(_, pw, ph)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, pw, ph, COL_PLATE, RY(12))
		else
			draw.RoundedBox(8, 0, 0, pw, ph, COL_PLATE)
		end
		surface.SetDrawColor(COL_ACC)
		surface.DrawRect(0, RY(18), RX(3), RY(30))
		draw.SimpleText(bHakuda and "GANTELETS EN MAIN" or "LAME EN MAIN", "EVO_ReglageLame_Titre", RX(22), RY(33), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	pnl.Close = function() Fermer(false) end
	pnl.OnRemove = function(s)
		-- Fermeture par un autre chemin (Echap, mort, reconnexion d'UI) : apercu coupe.
		if M._pnl == s then
			M._pnl, M.edition, M.apercu = nil, false, nil
		end
	end
	pnl.Think = function()
		local me = LocalPlayer()
		if not IsValid(me) or not me:Alive() then Fermer(false) end
	end

	local croix = vgui.Create("DButton", pnl)
	croix:SetText("")
	croix:SetSize(RX(34), RY(34))
	croix:SetPos(nW - RX(48), RY(16))
	croix.Paint = function(s, cw, ch)
		draw.SimpleText("×", "EVO_ReglageLame_Titre", cw / 2, ch / 2, s:IsHovered() and COL_ACC or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	croix.DoClick = function() Fermer(false) end

	local t = M.apercu
	Curseur(pnl, "Position X", -POS_MAX, POS_MAX, 0.5, 0, function() return t.pos.x end, function(v) t.pos.x = v end)
	Curseur(pnl, "Position Y", -POS_MAX, POS_MAX, 0.5, 0, function() return t.pos.y end, function(v) t.pos.y = v end)
	Curseur(pnl, "Position Z", -POS_MAX, POS_MAX, 0.5, 0, function() return t.pos.z end, function(v) t.pos.z = v end)
	Curseur(pnl, "Inclinaison", -ANG_MAX, ANG_MAX, 1, 0, function() return t.ang.p end, function(v) t.ang.p = v end)
	Curseur(pnl, "Rotation", -ANG_MAX, ANG_MAX, 1, 0, function() return t.ang.y end, function(v) t.ang.y = v end)
	Curseur(pnl, "Roulis", -ANG_MAX, ANG_MAX, 1, 0, function() return t.ang.r end, function(v) t.ang.r = v end)
	Curseur(pnl, "Taille (%)", SCALE_MIN * 100, SCALE_MAX * 100, 5, 100, function() return t.scale * 100 end, function(v) t.scale = v / 100 end)

	local sep = vgui.Create("DPanel", pnl)
	sep:Dock(TOP)
	sep:SetTall(RY(14))
	sep.Paint = function(_, sw, sh)
		surface.SetDrawColor(255, 255, 255, 14)
		surface.DrawRect(0, sh / 2, sw, 1)
	end
	Curseur(pnl, "Vue", -180, 180, 5, 0, function() return M.vue end, function(v) M.vue = v end)
	Curseur(pnl, "Recul", 40, 150, 5, 80, function() return M.recul end, function(v) M.recul = v end)

	local rangee = vgui.Create("DPanel", pnl)
	rangee:Dock(BOTTOM)
	rangee:SetTall(RY(44))
	rangee.Paint = function() end
	local nBtnW = math.floor((nW - RX(44)) / 2) - RX(5)
	local bZero = Bouton(rangee, "Réinitialiser", function()
		t.pos.x, t.pos.y, t.pos.z = 0, 0, 0
		t.ang.p, t.ang.y, t.ang.r = 0, 0, 0
		t.scale = 1
	end)
	bZero:Dock(LEFT)
	bZero:SetWide(nBtnW)
	local bOk = Bouton(rangee, "Enregistrer", function()
		net.Start("EVO::PowerUI::LameReglage")
			net.WriteFloat(t.pos.x) net.WriteFloat(t.pos.y) net.WriteFloat(t.pos.z)
			net.WriteFloat(t.ang.p) net.WriteFloat(t.ang.y) net.WriteFloat(t.ang.r)
			net.WriteFloat(t.scale)
		net.SendToServer()
		Fermer(true)
	end)
	bOk:Dock(RIGHT)
	bOk:SetWide(nBtnW)

	pnl:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pnl) end -- APRES MakePopup (regle repo)
end

-- Camera exterieure pendant le reglage : face au joueur par defaut, a hauteur de torse,
-- tournee par le curseur Vue. Cible fixe sur la capsule (pas un os : les os du joueur
-- local ne sont pas a jour avant son premier rendu). Le trace garde la camera hors des murs.
hook.Add("CalcView", "EVO_ReglageLame::Vue", function(ply, _, _, fov)
	if not (M.edition and IsValid(M._pnl)) or ply ~= LocalPlayer() then return end
	local vCible = ply:LocalToWorld(ply:OBBCenter()) + Vector(0, 0, 10)
	local a = Angle(8, ply:EyeAngles().y + 180 + (M.vue or 0), 0)
	local tr = util.TraceHull({
		start = vCible, endpos = vCible - a:Forward() * (M.recul or 80),
		mins = Vector(-4, -4, -4), maxs = Vector(4, 4, 4), mask = MASK_SOLID_BRUSHONLY,
	})
	return { origin = tr.HitPos, angles = a, fov = fov, drawviewer = true }
end)
