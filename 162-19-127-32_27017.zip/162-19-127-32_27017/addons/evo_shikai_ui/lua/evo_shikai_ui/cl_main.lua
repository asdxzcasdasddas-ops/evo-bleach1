-- "addons\\evo_shikai_ui\\lua\\evo_shikai_ui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Share the one-model-per-frame queue while preserving this menu's camera setup.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

-- ============================================================
-- cl_main.lua — evo_shikai_ui (client)
-- UI plein écran paramétrée par MODE (shikai/bankai) :
--  • dim plein écran derrière (PAS de blur par frame : trop cher, cf Paint)
--  • DHTML de fond : nom du pouvoir (dégradé animé, libellé selon
--    faction), passif, barre de charge, STATISTIQUES
--  • DModelPanel central : katana équipé, zoomé, rotation clic gauche
--  • DHTML droit : améliorations cliquables (sons + éclair blanc)
-- Pattern DHTML repris de flagcapture/cl_flagmap.lua.
-- ============================================================

EVO_SHIKAI_UI = EVO_SHIKAI_UI or {}
-- Données synchronisées par mode : ClientData[mode] = { ups = {...}, stats = {...} }
EVO_SHIKAI_UI.ClientData = EVO_SHIKAI_UI.ClientData or {}

-- FRAMES PERSISTANTS par mode (fix "mini latence à l'ouverture", 2026-07-13) : le menu
-- est construit UNE fois (caché) — pages CEF, fontes base64, modèle — puis Open() ne
-- fait plus que l'afficher. Autorefresh : on purge les frames du chargement précédent
-- (sinon vieilles closures + doublons de hooks).
if EVO_SHIKAI_UI._Frames then
    for _, f in pairs(EVO_SHIKAI_UI._Frames) do
        if IsValid(f) then f:Remove() end
    end
end
EVO_SHIKAI_UI._Frames = {}
if IsValid(EVO_SHIKAI_UI._Frame) then EVO_SHIKAI_UI._Frame:Remove() end
EVO_SHIKAI_UI._Frame = nil

local MODEL_FOV    = 32
local DEFAULT_ZOOM = 2.10   -- caméra RAPPROCHÉE (demande user 2026-07-13 : lame "plus grosse /
                            -- plus zoomée", inverse des anciens dézooms ; molette 0.35-4.5 inchangée)

-- Sons custom du repo UNIQUEMENT — AUCUN son de base GMod dans cette UI (demande user :
-- ni hover, ni ouverture, ni refus).
local SND_CLICK   = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"       -- clic (repo UI)
local SND_UPGRADE = "a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3"     -- upgrade réussie (repo forge)

-- DA ATELIER : Bebas Neue + entaille slash1 injectées dans les pages au SetHTML.
-- CEF (autre process) ne voit NI les fontes resource/fonts NI les PNG workshop
-- via asset:// — mêmes recettes que le spell selector / questboard (@font-face
-- data URI ~61 Ko + masque data URI ; petits fichiers seulement).
local _bebasCss
local function bebas_face_css()
    if _bebasCss ~= nil then return _bebasCss end
    local raw = file.Read("resource/fonts/BebasNeue-Regular.ttf", "GAME")
    if raw and #raw > 0 then
        _bebasCss = "@font-face { font-family:'Bebas Neue'; src:url('data:font/ttf;base64,"
            .. string.gsub(util.Base64Encode(raw, true), "%s", "") .. "') format('truetype'); }"
    else
        _bebasCss = "" -- ttf absent : retombe sur Tungsten/Impact (stack CSS)
    end
    return _bebasCss
end
-- ABeeZee (police des chiffres de la SPELL BAR, demande user) injectée pareil : le TTF
-- est shippé par lzy_squad (resource/fonts, arbre GAME fusionné au runtime).
local _abeezeeCss
local function abeezee_face_css()
    if _abeezeeCss ~= nil then return _abeezeeCss end
    local raw = file.Read("resource/fonts/ABeeZee-Regular.ttf", "GAME")
    if raw and #raw > 0 then
        _abeezeeCss = "@font-face { font-family:'ABeeZee'; src:url('data:font/ttf;base64,"
            .. string.gsub(util.Base64Encode(raw, true), "%s", "") .. "') format('truetype'); }"
    else
        _abeezeeCss = "" -- ttf absent : retombe sur Trebuchet (stack CSS)
    end
    return _abeezeeCss
end
local _slashUrl
local function slash_mask_url()
    if _slashUrl ~= nil then return _slashUrl end
    local raw = file.Read("materials/evo_ui/tex/slash1.png", "GAME")
    if raw and #raw > 0 and #raw < 150 * 1024 then
        _slashUrl = "data:image/png;base64," .. string.gsub(util.Base64Encode(raw, true), "%s", "")
    else
        _slashUrl = "asset://garrysmod/materials/evo_ui/tex/slash1.png" -- filet (fichier posé en local)
    end
    return _slashUrl
end

-- Modèle par défaut ("Foudre Noire", = KATANA_SKINS.List["default"].model) : même fallback
-- que le SWEP citron_combat_weapons quand ni skin ni style ne donnent de modèle.
local DEFAULT_KATANA_MODEL = "models/evo/weapons/katana/divers/evo_corcng4pl3nd/evo_h40pjwloagtyg.mdl"

-- ------------------------------------------------------------
-- Résolution du modèle de lame ÉQUIPÉE (copie de la chaîne locale
-- ncm_ranger_katana ResolveWeaponModel). On SAUTE EVO_SheathedModel
-- (snapshot figé au rengainement, potentiellement périmé) : on veut
-- la lame "logique" du mode courant (le swap shikai passe par KatanaSkin).
-- ------------------------------------------------------------
local function ResolveKatanaModel(ply)
    -- HAKUDA (mains nues) : pas de katana -> on montre le GANTELET équipé (sinon le défaut du
    -- registry), jamais une lame. Priorité sur tout le reste (le joueur hakuda n'a pas de katana).
    if EvoStyle and EvoStyle.GetStyleFamily
        and EvoStyle.GetStyleFamily(ply:GetEvoNWString("StyleCombat", "")) == "hakuda"
        and NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.GetModelByID then
        -- ShikaiModelOf et PAS GetShikaiModel : l'apercu doit montrer les poings de
        -- shikai MEME hors transformation, c'est tout l'objet de cet ecran.
        local sPoings = NCM_HAKUDA_GAUNTLETS.ShikaiModelOf
            and NCM_HAKUDA_GAUNTLETS.ShikaiModelOf(ply) or ""
        if sPoings ~= "" then return sPoings end
        local sGid = ply:GetEvoNWString("NCM_HakudaGauntlet", "")
        if sGid == "" then sGid = NCM_HAKUDA_GAUNTLETS.DefaultID or "" end
        local sGModel = NCM_HAKUDA_GAUNTLETS.GetModelByID(sGid)
        if sGModel ~= "" then return sGModel end
    end

    local sBankaiOverride = ply:GetEvoNWString("BankaiWeaponOverride", "")
    if sBankaiOverride ~= "" then return sBankaiOverride end
    -- LAME DE SHIKAI, transformation active ou non (user 08/29) : c'est le menu du
    -- pouvoir, il montre TA lame de shikai et pas le katana que tu portes au
    -- quotidien. D'ou ShikaiModelOf plutot que GetShikaiModel.
    local sShikaiMdl = (KATANA_SKINS and KATANA_SKINS.ShikaiModelOf)
        and KATANA_SKINS.ShikaiModelOf(ply) or ""
    if sShikaiMdl ~= "" then return sShikaiMdl end
    local sSkinID = ply:GetEvoNWString("KatanaSkin", "")
    if sSkinID ~= "" and KATANA_SKINS and KATANA_SKINS.GetModelByID then
        local sSkinModel = KATANA_SKINS.GetModelByID(sSkinID)
        if sSkinModel then return sSkinModel end
    end
    local sStyleID = ply:GetEvoNWString("StyleCombat", "")
    if sStyleID ~= "" and EvoStyle and EvoStyle.StyleCombatCfg then
        local tCfg = EvoStyle.StyleCombatCfg[sStyleID]
        if tCfg and tCfg.sWeaponModel and tCfg.sWeaponModel ~= "" then return tCfg.sWeaponModel end
    end
    return DEFAULT_KATANA_MODEL
end

-- (ResolveBladeName SUPPRIMÉ 2026-07-13 : la ligne "LAME — x" est retirée de l'UI, demande user.)

-- Boîte ajustée à l'ASPECT d'un matériau (jamais étiré) dans un gabarit max — pour
-- les images d'ambiance dessinées dans frame.Paint.
local function FitBox(mat, maxW, maxH)
    local w, h = mat:Width(), mat:Height()
    if not w or w <= 0 or not h or h <= 0 then return maxW, maxH end
    local s = math.min(maxW / w, maxH / h)
    return w * s, h * s
end

-- Matériau d'ambiance avec REPLIS d'extension (même chaîne que le fond de l'inventaire :
-- l'extension réelle du pack workshop peut différer de celle attendue). nil si introuvable.
local function TryMaterial(sPath)
    if not sPath or sPath == "" then return nil end
    local mat = Material(sPath, "smooth")
    if not mat:IsError() then return mat end
    local base = sPath:gsub("%.%w+$", "")
    for _, ext in ipairs({ ".png", ".jpg", "" }) do
        local sTry = base .. ext
        if sTry ~= sPath then
            mat = Material(sTry, "smooth")
            if not mat:IsError() then return mat end
        end
    end
    return nil
end

-- ------------------------------------------------------------
-- État poussé aux pages DHTML (pour un mode)
-- ------------------------------------------------------------
local function BuildState(sMode)
    local m  = EVO_SHIKAI_UI.Modes[sMode]
    local lp = LocalPlayer()
    local sFaction = lp:GetEvoNWString("FactionName", "")
    local bShini   = (sFaction == EVO_SHIKAI_UI.ShinigamiFaction)

    local tDefs = {}
    for _, tDef in ipairs(m.upgrades) do
        -- (desc RETIRÉE de l'UI, demande user : le "+X% unité" dit tout.)
        tDefs[#tDefs + 1] = {
            id = tDef.id, name = tDef.name,
            unit = tDef.unit, color = tDef.color, perLevel = tDef.perLevel,
        }
    end

    local data  = EVO_SHIKAI_UI.ClientData[sMode] or {}
    local sName = lp:GetEvoNWString("KatanaName", "")
    local st    = data.stats or {}
    return {
        mode     = sMode,
        title    = EVO_SHIKAI_UI.GetLabel(sMode, sFaction),
        -- (subtitle "ÉVEIL DU ZANPAKUTO"/"LIBÉRATION FINALE" + "LAME — x" RETIRÉS, demande user.)
        name     = (sName ~= "" and sName or "Zanpakuto"),
        passive  = m.passiveLabels[lp:GetEvoNWString(m.passiveNW, "")] or "-",
        -- (état actif + charge RETIRÉS de l'UI, demande user — le HUD les montre déjà ;
        --  ne plus les envoyer évite aussi des repaints CEF à chaque tick de barre)
        maxLevel = EVO_SHIKAI_UI.MaxLevel,
        treqs    = m.timeReq or {}, -- prérequis de TEMPS par niveau (les yens ne s'achètent plus, 09/01)
        defs     = tDefs,
        ups      = data.ups or {},
        stats    = {
            hollow = tonumber(st.hollow_kills) or 0,
            enemy  = tonumber(st.enemy_kills) or 0,
            secs   = tonumber(st.active_seconds) or 0,
        },
        labels   = {
            hollow = "HOLLOWS VAINCUS",
            enemy  = bShini and "ARRANCARS VAINCUS" or "SHINIGAMI VAINCUS",
            time   = "TEMPS EN " .. EVO_SHIKAI_UI.GetLabel(sMode, sFaction),
        },
    }
end

-- ------------------------------------------------------------
-- Templates HTML (tokens @@KEY@@ remplacés via fonction -> sûr même
-- si la valeur contient des % ; CEF-safe : % + rem, pas de gap/inset).
-- ------------------------------------------------------------
local function Fill(sTpl, tVars)
    return (sTpl:gsub("@@(%w+)@@", function(k) return tVars[k] or "" end))
end

local BG_TEMPLATE = [==[
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    * { margin:0; padding:0; box-sizing:border-box; -webkit-user-select:none; user-select:none; }
    html { font-size:16px; }
    /* Corps de texte en ABeeZee (police des chiffres de la SPELL BAR, demande user) ;
       les titres/display restent en Bebas — même duo que la spell bar. */
    html, body { width:100%; height:100%; overflow:hidden; background:transparent;
        font-family:'ABeeZee',"Trebuchet MS","Segoe UI",sans-serif; color:#ECECEC; }

    /*@@BEBAS@@*/
    /*@@ABEEZEE@@*/

    #zone { position:absolute; top:0; left:0; width:71%; height:100%; }
    #glow { position:absolute; top:14%; left:6%; width:88%; height:70%;
        background: radial-gradient(ellipse at 50% 50%, @@GLOWA@@ 0%, @@GLOWB@@ 42%, rgba(0,0,0,0) 72%); }

    /* DA Atelier : titre en BEBAS (jamais de faux-bold), dégradé du mode conservé. */
    #head { position:absolute; top:3.6%; left:0; width:100%; text-align:center;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; font-weight:400; }
    /* Bloc titre RÉDUIT (~20%, demande user 2026-07-13 : "trop gros en haut"). */
    #title { display:inline-block; max-width:94%; font-size:3.5rem; font-weight:400;
        letter-spacing:.4rem; line-height:1.12; white-space:nowrap; overflow:hidden;
        background:linear-gradient(90deg,@@GRADIENT@@); background-size:300% 100%;
        -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        /* PERF : steps(80) = ~9 repaints CEF/s au lieu de 60+ avec linear (imperceptible sur 9s) */
        -webkit-animation:sweep 9s steps(80) infinite; }
    @-webkit-keyframes sweep { 0% { background-position:0% 0; } 100% { background-position:300% 0; } }
    /* Entaille slash1 (signature Atelier) sous le titre, teintée accent du mode. */
    #tslash { margin:.2rem auto 0 auto; width:15rem; height:.7rem; background:@@ACCENT@@;
        -webkit-mask-image:url('@@SLASHMASK@@'); -webkit-mask-size:100% 100%; -webkit-mask-repeat:no-repeat; }
    #kind { margin-top:.3rem; font-size:1rem; letter-spacing:.38rem; color:@@ACCENT@@; }
    #sub { margin-top:.5rem; font-size:1.05rem; letter-spacing:.26rem; color:#8A8A93; }
    #sub b { color:#cdcdd3; font-weight:400; }
    /* (#blade "LAME — x" SUPPRIMÉ, demande user 2026-07-13.) */

    #stats { position:absolute; top:29%; left:0; width:100%; text-align:center; }
    .stat { display:inline-block; width:11.5rem; margin:0 .8rem; vertical-align:top; }
    .stat-v { font-size:2.7rem; font-weight:400; color:#ECECEC; line-height:1;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; }
    .stat-k { margin-top:.5rem; font-size:.86rem; letter-spacing:.16rem; color:#7a7a84; font-weight:700; }

    /* (#hint "Maintenir clic gauche..." SUPPRIMÉ, demande user 2026-07-13.) */
</style>
</head>
<body>
    <div id="zone">
        <div id="glow"></div>
        <div id="head">
            <div id="title"></div>
            <div id="tslash"></div>
            <div id="kind"></div>
            <div id="sub">PASSIF — <b id="passive">—</b></div>
        </div>
        <div id="stats">
            <div class="stat"><div class="stat-v" id="s_hollow">0</div><div class="stat-k" id="k_hollow">HOLLOWS VAINCUS</div></div>
            <div class="stat"><div class="stat-v" id="s_enemy">0</div><div class="stat-k" id="k_enemy">ENNEMIS VAINCUS</div></div>
            <div class="stat"><div class="stat-v" id="s_time">0s</div><div class="stat-k" id="k_time">TEMPS</div></div>
        </div>
    </div>
<script>
    function setRootFont(){
        var s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
        if(s < 0.5) s = 0.5; // plancher bas : reste lisible ET tient sur les petites résolutions
        // 0.9 = réduction légère de la taille globale de l'UI (demande user)
        document.documentElement.style.fontSize = (16 * s * 0.9) + "px";
    }
    window.addEventListener("resize", setRootFont);
    setRootFont();

    function fmtTime(t){
        t = Math.floor(t || 0);
        var h = Math.floor(t / 3600), mn = Math.floor((t % 3600) / 60), s = t % 60;
        if(h > 0) return h + "h" + (mn < 10 ? "0" : "") + mn;
        if(mn > 0) return mn + "m" + (s < 10 ? "0" : "") + s + "s";
        return s + "s";
    }
    function fmtNum(n){
        return String(Math.floor(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    }

    var lastBGSig = null;
    window.EVO_SetBG = function(d){
        // PERF : le push périodique (0.5s) renvoie souvent des données IDENTIQUES (pouvoir
        // inactif = barre/stats/argent figés) -> aucune écriture DOM = aucun repaint CEF.
        var sig = JSON.stringify(d);
        if(sig === lastBGSig) return;
        lastBGSig = sig;
        var ttl = document.getElementById('title');
        ttl.innerText = d.name;
        // Responsive : taille du titre adaptée à la longueur du nom (jusqu'à 32 chars),
        // pour qu'un nom long tienne en entier au lieu d'être tronqué.
        ttl.style.fontSize = Math.min(3.5, 3.5 * 13 / Math.max(d.name.length, 13)).toFixed(2) + 'rem';
        document.getElementById('kind').innerText = d.title;
        document.getElementById('passive').innerText = d.passive;
        document.getElementById('s_hollow').innerText = fmtNum(d.stats.hollow);
        document.getElementById('s_enemy').innerText = fmtNum(d.stats.enemy);
        document.getElementById('s_time').innerText = fmtTime(d.stats.secs);
        document.getElementById('k_hollow').innerText = d.labels.hollow;
        document.getElementById('k_enemy').innerText = d.labels.enemy;
        document.getElementById('k_time').innerText = d.labels.time;
    };
    if(window.gmod && gmod.ready) gmod.ready();
</script>
</body>
</html>
]==]

-- REDESIGN (demande user) : plus de grosse carte flottante à cartes empilées.
-- FEUILLE dockée au bord DROIT, pleine hauteur : liseré accent du mode sur la
-- tranche, fondu vers le jeu à gauche, lignes fines par amélioration avec badge
-- LOSANGE de niveau, segments de progression, prix en pastille contour.
local PANEL_TEMPLATE = [==[
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    * { margin:0; padding:0; box-sizing:border-box; -webkit-user-select:none; user-select:none; }
    html { font-size:16px; }
    /* Corps de texte en ABeeZee (police des chiffres de la SPELL BAR, demande user) ;
       les titres/display restent en Bebas — même duo que la spell bar. */
    html, body { width:100%; height:100%; overflow:hidden; background:transparent;
        font-family:'ABeeZee',"Trebuchet MS","Segoe UI",sans-serif; color:#ECECEC; }

    /*@@BEBAS@@*/
    /*@@ABEEZEE@@*/

    /* Feuille = PLAQUE de métal noir Atelier PLATE dockée à droite : tons #0D0E11,
       tranche accent du mode conservée, SANS liseré acier (aligné dashboard 08/07),
       fondu vers le jeu à gauche conservé, vis d'angle. */
    /* Fond ALLÉGÉ (2026-07-13) : l'image d'ambiance du mode (m.images.panel) est dessinée
       en VGUI DERRIÈRE cette page (frame.Paint) — le dégradé sombre translucide la laisse
       transparaître tout en gardant les textes lisibles. */
    #sheet { position:absolute; top:0; left:0; right:0; bottom:0;
        background:linear-gradient(270deg, rgba(13,14,17,.84) 0%, rgba(11,12,15,.80) 72%, rgba(9,9,12,.38) 100%);
        border-left:.2rem solid @@ACCENT@@;
        display:flex; flex-direction:column; }
    .screw { position:absolute; width:.85rem; height:.85rem; border-radius:50%; z-index:5;
        background:-webkit-radial-gradient(circle, #33373d 0%, #17191d 70%);
        box-shadow:0 0 0 1px rgba(0,0,0,.6); }
    .screw i { position:absolute; top:44%; left:12%; width:76%; height:12%;
        background:rgba(0,0,0,.55); -webkit-transform:rotate(38deg); }
    #sc1 { top:.65rem; left:.9rem; }  #sc2 { top:.65rem; right:.65rem; }
    #sc3 { bottom:.65rem; right:.65rem; }  #sc4 { bottom:.65rem; left:.9rem; }

    #head { flex:0 0 auto; padding:2.1rem 1.9rem 1.15rem 1.9rem; position:relative; }
    #mode { font-size:1.02rem; letter-spacing:.5rem; color:@@ACCENT@@;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; font-weight:400; }
    #htitle { margin-top:.35rem; font-size:2.2rem; font-weight:400; letter-spacing:.2rem;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; }
    /* Entaille slash1 COLLÉE au titre (signature Atelier), teintée accent du mode. */
    #hslash { margin-top:.15rem; width:11.5rem; height:.7rem; background:@@ACCENT@@;
        -webkit-mask-image:url('@@SLASHMASK@@'); -webkit-mask-size:100% 100%; -webkit-mask-repeat:no-repeat; }
    /* Croix standard DA : glyphe seul, gris -> accent (plus de rond de fond). */
    #close { position:absolute; top:1.8rem; right:1.6rem; width:2.7rem; height:2.7rem;
        color:#8A8A93; font-size:1.5rem; line-height:2.7rem; text-align:center;
        cursor:pointer; transition:color .12s ease; }
    #close:hover { color:@@ACCENT@@; }
    #list { flex:1 1 auto; overflow-y:auto; }
    #list::-webkit-scrollbar { width:.45rem; }
    #list::-webkit-scrollbar-thumb { background:#2a2a31; }

    .row { position:relative; padding:1.3rem 1.7rem 1.3rem 6.1rem;
        border-top:1px solid rgba(255,255,255,.05); transition:background .12s ease; }
    .row:hover { background:rgba(255,255,255,.03); }

    /* Badge CARRÉ Atelier (l'ancien losange tournait à 45°) : niveau au centre
       en Bebas, bord de la couleur de l'effet. */
    .dia { position:absolute; left:1.9rem; top:50%; width:2.6rem; height:2.6rem; margin-top:-1.3rem;
        border:.16rem solid #5a5a64; background:rgba(255,255,255,.03); }
    .dia b { position:absolute; top:0; left:0; right:0; bottom:0;
        font-size:1.3rem; font-weight:400; color:#ECECEC; text-align:center; line-height:2.35rem;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; }

    .r-top { display:flex; justify-content:space-between; align-items:center; }
    .r-name { font-size:1.42rem; font-weight:400; letter-spacing:.12rem;
        font-family:'Bebas Neue','Tungsten','Impact',sans-serif; }
    /* (.r-desc SUPPRIMÉE, demande user : le "+X% unité" dit tout.) */
    .r-line { margin-top:.7rem; display:flex; justify-content:space-between; align-items:center; }
    .seg { display:inline-block; width:1.5rem; height:.32rem;
        background:#26262c; margin-right:.3rem; }
    .r-bonus { font-size:.94rem; font-weight:700; color:#b9b9c0; }
    .r-next { color:#5f5f68; font-weight:700; }

    /* Prix : plaque CARRÉE à contour accent (plus de pilule arrondie). */
    .price { min-width:8.4rem; padding:.42rem .85rem; text-align:center;
        font-size:.98rem; font-weight:800; cursor:pointer; transition:all .12s ease;
        border:.13rem solid @@ACCENT@@; color:#ECECEC; background:transparent; }
    /* Survol « dashboard » : le bouton se remplit d'accent + léger ressort (scale). */
    .price:hover { background:@@ACCENT@@; color:#fff; -webkit-transform:scale(1.05); }
    .price.no { border-color:#3a3a42; color:#5a5a64; cursor:default; }
    .price.no:hover { background:transparent; color:#5a5a64; -webkit-transform:none; }
    .price.max { border-color:rgba(232,179,75,.5); color:#e8b34b; cursor:default; }
    .price.max:hover { background:transparent; color:#e8b34b; -webkit-transform:none; }

</style>
</head>
<body>
    <div id="sheet">
        <div class="screw" id="sc1"><i></i></div><div class="screw" id="sc2"><i></i></div>
        <div class="screw" id="sc3"><i></i></div><div class="screw" id="sc4"><i></i></div>
        <div id="head">
            <div id="mode"></div>
            <div id="htitle">AMÉLIORATIONS</div>
            <div id="hslash"></div>
            <div id="close" onclick="gmod.close()">&#10005;</div>
        </div>
        <div id="list"></div>
    </div>
<script>
    function setRootFont(){
        var s = Math.min(window.innerWidth / 480, window.innerHeight / 1080);
        if(s < 0.5) s = 0.5; // plancher bas : le panneau tient sur les petites résolutions
        document.documentElement.style.fontSize = (16 * s) + "px";
    }
    window.addEventListener("resize", setRootFont);
    setRootFont();

    var lastSig = null;
    window.EVO_SetPanel = function(d){
        document.getElementById('mode').innerText = d.title;
        // Ne reconstruire le DOM que si les donnees ont CHANGE : le push periodique (0.5s)
        // detruirait/recreerait l'element sous le curseur (hover qui clignote).
        var sig = JSON.stringify([d.ups, d.maxLevel, d.treqs, d.stats && d.stats.secs, d.title]);
        if(sig === lastSig) return;
        lastSig = sig;
        var h = '';
        for(var i = 0; i < d.defs.length; i++){
            var def = d.defs[i];
            var lvl = (d.ups && d.ups[def.id]) || 0;
            var max = d.maxLevel;
            var segs = '';
            for(var p = 1; p <= max; p++){
                segs += '<span class="seg"' + (p <= lvl ? ' style="background:' + def.color + '"' : '') + '></span>';
            }
            var bonus;
            if(lvl > 0){ bonus = '+' + (def.perLevel * lvl) + '% ' + def.unit; }
            else { bonus = '<span style="color:#5a5a64">Aucun bonus</span>'; }
            if(lvl < max){ bonus += ' <span class="r-next">&#8594; +' + (def.perLevel * (lvl + 1)) + '%</span>'; }
            var btn;
            if(lvl >= max){
                btn = '<div class="price max">MAX</div>';
            } else {
                // Plus d'achat en yens (09/01) : la pastille montre le TEMPS D'UTILISATION
                // requis pour le prochain niveau, et devient cliquable une fois atteint.
                // treqs est un tableau Lua (base 1) serialise en JSON (base 0) :
                // le prerequis du niveau lvl+1 (Lua) est a l'indice lvl (JS).
                var need = (d.treqs && d.treqs[lvl]) || 0;
                var have = (d.stats && d.stats.secs) || 0;
                var fmtT = function(n){
                    n = Math.max(0, Math.floor(n));
                    if(n < 60) return n + ' s';
                    var hh = Math.floor(n / 3600), mm = Math.floor((n % 3600) / 60);
                    if(hh > 0) return mm > 0 ? (hh + ' h ' + mm) : (hh + ' h');
                    return mm + ' min';
                };
                if(have >= need){
                    btn = '<div class="price" onclick="gmod.buy(\'' + def.id + '\')">AM\u00c9LIORER</div>';
                } else {
                    btn = '<div class="price no">' + fmtT(need) + ' d\'usage</div>';
                }
            }
            h += '<div class="row">'
               + '<div class="dia" style="border-color:' + def.color + '"><b>' + lvl + '</b></div>'
               + '<div class="r-top"><span class="r-name" style="color:' + def.color + '">' + def.name + '</span>' + btn + '</div>'
               + '<div class="r-line"><span>' + segs + '</span><span class="r-bonus">' + bonus + '</span></div>'
               + '</div>';
        }
        document.getElementById('list').innerHTML = h;
    };
    if(window.gmod && gmod.ready) gmod.ready();
</script>
</body>
</html>
]==]

-- ------------------------------------------------------------
-- DModelPanel : cadrage auto + rotation drag + zoom molette
-- ------------------------------------------------------------
local function FrameModelCamera(pnl)
    local ent = pnl:GetEntity()
    if not IsValid(ent) then return end
    local vMin, vMax = ent:GetModelRenderBounds()
    if not vMin then vMin, vMax = ent:GetRenderBounds() end
    local vCenter = (vMin + vMax) * 0.5
    -- Bornes clampées : certains modèles riggés annoncent des bounds de séquence énormes ;
    -- un katana réel fait ~40-120u.
    local nLen  = math.Clamp((vMax - vMin):Length(), 12, 220)
    local nDist = math.max((nLen * 0.62) / math.tan(math.rad(MODEL_FOV * 0.5)) * (pnl._zoom or 1), 8)
    pnl._focus = vCenter
    pnl:SetLookAt(vCenter)
    pnl:SetCamPos(vCenter + Vector(nDist, 0, 0))
end

local function SetupModelPanel(pnl)
    pnl:SetFOV(MODEL_FOV)
    pnl:SetCursor("sizeall")
    pnl._yaw, pnl._pitch, pnl._zoom = 40, 0, DEFAULT_ZOOM

    -- Pas de FrameAdvance : lame STATIQUE (économie FPS + demande "ne bouge pas"). On remplace le
    -- LayoutEntity par défaut de DModelPanel (qui auto-rotationne) par une simple pose.
    function pnl:LayoutEntity(ent)
        ent:SetAngles(Angle(self._pitch, self._yaw, 0))
        -- Famille de textures : même règle que le fourreau / le mannequin inventaire
        -- (variante « _shikai » équipée ou shikai/bankai actif = famille 1). LOD 0 : les
        -- meshes LOD perdent souvent la 2e famille.
        local lp = LocalPlayer()
        local nSkin = 0
        -- Lame ATTRIBUEE affichee (ShikaiModelOf) : SA variante catalogue (09/01),
        -- comme l'apercu de la liste — et plus celle du katana du quotidien.
        local sAttribuee = IsValid(lp) and KATANA_SKINS and KATANA_SKINS.ShikaiModelOf
            and KATANA_SKINS.ShikaiModelOf(lp) or ""
        if sAttribuee ~= "" and ent:GetModel() == sAttribuee then
            nSkin = (KATANA_SKINS.ShikaiSkinIndexOf and KATANA_SKINS.ShikaiSkinIndexOf(lp)) or 0
            if nSkin > 0 and ent:SkinCount() <= nSkin then nSkin = 0 end
        elseif IsValid(lp) and ent:SkinCount() > 1 then
            if lp:GetEvoNWBool("EVO_ShikaiActive", false) or lp:GetEvoNWBool("EVO_Bankai", false) then
                nSkin = 1
            elseif KATANA_SKINS and KATANA_SKINS.GetBaseSkinByID then
                nSkin = KATANA_SKINS.GetBaseSkinByID(lp:GetEvoNWString("KatanaSkin", ""))
            end
        end
        if ent:GetSkin() ~= nSkin then ent:SetSkin(nSkin) end
        ent:SetLOD(0)
    end

    function pnl:OnMousePressed(code)
        if code ~= MOUSE_LEFT then return end
        self._drag = { x = gui.MouseX(), y = gui.MouseY(), yaw = self._yaw, pitch = self._pitch }
        self:MouseCapture(true)
    end

    function pnl:OnMouseReleased(_)
        self._drag = nil
        self:MouseCapture(false)
    end

    function pnl:Think()
        if not self._drag then return end
        if not input.IsMouseDown(MOUSE_LEFT) then
            self._drag = nil
            self:MouseCapture(false)
            return
        end
        self._yaw   = self._drag.yaw + (gui.MouseX() - self._drag.x) * 0.5
        self._pitch = math.Clamp(self._drag.pitch - (gui.MouseY() - self._drag.y) * 0.3, -45, 45)
    end

    function pnl:OnMouseWheeled(delta)
        self._zoom = math.Clamp((self._zoom or 1) - delta * 0.12, 0.35, 4.5)
        FrameModelCamera(self)
        return true
    end
end

-- ------------------------------------------------------------
-- Ouverture
-- ------------------------------------------------------------
-- Construit le menu d'un mode, CACHÉ (fix latence d'ouverture 2026-07-13) : les coûts
-- de création (2 pages CEF + parse des fontes base64 + modèle) sont payés UNE SEULE
-- fois — au precache de connexion pour les pouvoirs déjà débloqués, sinon au 1er open.
-- Ensuite Open() = ShowUI() (simple SetVisible) -> ouverture instantanée.
local function BuildFrame(sMode)
    local lp = LocalPlayer()
    local m = EVO_SHIKAI_UI.Modes[sMode]

    local scrW, scrH = ScrW(), ScrH()
    local panelW = math.floor(scrW * 0.24) -- feuille droite (hoisté : Paint dessine son fond)

    -- IMAGES D'AMBIANCE du mode (demande user 2026-07-13) : illustration à gauche de la
    -- lame, fond de la feuille d'améliorations, signature en bas-gauche. Dessinées en
    -- VGUI dans frame.Paint (fiable — pas de base64 CEF), DERRIÈRE les enfants (le
    -- modèle et la feuille DHTML translucide passent au-dessus).
    local imgs      = m.images or {}
    local matSide   = TryMaterial(imgs.side)
    local matPanel  = TryMaterial(imgs.panel)
    -- (image bas-gauche "corner" SUPPRIMÉE, demande user 2026-07-13 — shikai ET bankai.)
    -- DIAGNOSTIC TEMPORAIRE (le user teste en jeu) : signale précisément tout visuel
    -- introuvable dans le pack (mauvais chemin / extension) au lieu d'échouer en silence.
    for _, t in ipairs({ { "side", matSide }, { "panel", matPanel } }) do
        if imgs[t[1]] and not t[2] then
            MsgC(Color(207, 68, 78), "[ShikaiUI] ", Color(225, 225, 230),
                "Visuel introuvable : materials/" .. imgs[t[1]] .. " (extensions .png/.jpg testées)")
        end
    end

    local frame = vgui.Create("DFrame")
    frame:SetSize(scrW, scrH)
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:SetVisible(false) -- construit CACHÉ ; ShowUI() l'affiche (+ MakePopup)
    frame._mode = sMode
    frame.Paint = function(self, w, h)
        -- PERF : pas de EVO_UI.DrawBlur ici. Il coûte 4 passes × UpdateScreenEffectTexture
        -- (copies PLEIN ÉCRAN du framebuffer) PAR FRAME, pour un flou invisible derrière un
        -- dim quasi opaque. Fond TRÈS NOIR quasi total (demande user : "que ça montre
        -- moins le monde extérieur" — surtout la zone gauche/centre autour de la lame).
        surface.SetDrawColor(3, 3, 4, 254)
        surface.DrawRect(0, 0, w, h)

        surface.SetDrawColor(255, 255, 255, 255)
        -- Visuel de la FEUILLE d'améliorations (droite) : TOUTE la zone + layer blur
        -- (EVO_UI.GhostBlur = flou doux cuit une fois en RT, 1 seul draw/frame).
        if matPanel then
            if EVO_UI and EVO_UI.GhostBlur then
                EVO_UI.GhostBlur(matPanel, w - panelW, 0, panelW, h, 255)
            else
                surface.SetMaterial(matPanel)
                surface.DrawTexturedRect(w - panelW, 0, panelW, h)
            end
        end
        -- Illustration COLLÉE DANS L'ANGLE haut-gauche (demande user), TOURNÉE DE 90°,
        -- layer blur + TRÈS translucide — via le matériau flouté public (GhostBlurMat) +
        -- DrawTexturedRectRotated (empreinte écran d'un rect w×h tourné de 90° = h×w).
        -- AGRANDIE 560->900 (demande user) : le flou vient de l'upscale de la RT 512,
        -- donc plus grand = AUSSI nettement plus flou (les deux demandes d'un coup).
        if matSide then
            local iw, ih = FitBox(matSide, gRespX(900), gRespY(900))
            local bm = (EVO_UI and EVO_UI.GhostBlurMat and EVO_UI.GhostBlurMat(matSide)) or matSide
            surface.SetDrawColor(255, 255, 255, 12) -- encore plus "derrière" (demande user)
            surface.SetMaterial(bm)
            -- ENFONCÉE dans le coin haut-gauche (demande user) : ~28% sort par le haut
            -- et ~15% par la gauche (empreinte écran après rotation 90° = ih large × iw haut).
            surface.DrawTexturedRectRotated(ih * 0.5 - ih * 0.15, iw * 0.5 - iw * 0.28, iw, ih, 90)
            surface.SetDrawColor(255, 255, 255, 255)
        end
    end
    -- Éclair blanc AU-DESSUS de tout (PaintOver = après les enfants), sur achat réussi.
    frame.PaintOver = function(self, w, h)
        if not self._flashStart then return end
        local a = 1 - math.Clamp((SysTime() - self._flashStart) / 0.5, 0, 1)
        if a <= 0 then self._flashStart = nil return end
        surface.SetDrawColor(255, 255, 255, math.floor(a * 255))
        surface.DrawRect(0, 0, w, h)
    end
    -- Fermeture par RE-APPUI d'une touche bindée (poll input.IsButtonDown, jamais OnKeyCodePressed),
    -- debounce 0.25s post-ouverture (cf cl_flagmap). On écoute les binds des DEUX modes : avec la
    -- redirection shikai->bankai, le menu a pu être ouvert par l'un ou l'autre.
    frame._opened = CurTime()
    frame._bindWasDown = false
    function frame:Think()
        if not self:IsVisible() then return end -- frame persistant caché : aucune logique
        local me = LocalPlayer()
        if not IsValid(me) or not me.GetBindKey then return end
        local down = false
        for _, sM in ipairs(EVO_SHIKAI_UI.ModeOrder) do
            local k = me:GetBindKey(EVO_SHIKAI_UI.Modes[sM].bind)
            if k and k ~= KEY_NONE and input.IsButtonDown(k) then down = true break end
        end
        if down and not self._bindWasDown and (CurTime() - self._opened) > 0.25 then
            self:HideUI()
            return
        end
        self._bindWasDown = down
    end

    -- Fond DHTML : SOURIS OFF (sinon vole le drag du DModelPanel) ; CLAVIER OFF (sinon le 1er clic
    -- vole le clavier -> Échap mort).
    local htmlBG = vgui.Create("DHTML", frame)
    htmlBG:SetPos(0, 0)
    htmlBG:SetSize(scrW, scrH)
    htmlBG:SetAllowLua(false)
    htmlBG:SetMouseInputEnabled(false)
    htmlBG:SetKeyboardInputEnabled(false)

    -- Katana équipé : TOUTE LA PARTIE BASSE de la zone gauche (demande user 2026-07-13),
    -- sous le bloc titre + stats, jusqu'au bord bas de l'écran ; s'arrête juste avant la
    -- feuille d'améliorations (dockée à 76%). Le rapprochement vient de DEFAULT_ZOOM (2.10).
    local mdl = vgui.Create("DModelPanel", frame)
    mdl:SetPos(scrW * 0.01, scrH * 0.36)
    mdl:SetSize(scrW * 0.74, scrH * 0.64)
    mdl:SetModel(ResolveKatanaModel(lp))
    SetupModelPanel(mdl)
    FrameModelCamera(mdl)

    -- ── CHOIX DU SKIN DE LA LIBÉRATION (09/01, demande user) — mode shikai seul ──
    -- v3 : DA Atelier (plaque sombre à coin coupé, Bebas, accent) + APERÇU 3D par
    -- entrée + la liste se déroule VERS LE HAUT (la tête est collée au bas de
    -- l'écran). Sélection -> serveur (autorité) ; l'aperçu principal suit par
    -- NW_WATCH (ShikaiSkin).
    if sMode == "shikai" then
        surface.CreateFont("EVO_ShikUI_SkinBtn", { font = "Bebas Neue", size = (gRespFont and gRespFont(24)) or 24, weight = 400, antialias = true, extended = true })
        surface.CreateFont("EVO_ShikUI_SkinRow", { font = "Roboto", size = (gRespFont and gRespFont(17)) or 17, weight = 500, antialias = true, extended = true })
        local COL_PLATE  = Color(14, 14, 17, 250)
        local COL_PLATE2 = Color(20, 21, 26, 252)
        local COL_ACC    = Color(207, 68, 78)
        local COL_TITLE  = Color(237, 238, 242)
        local COL_MUTED  = Color(150, 154, 162)

        local nBtnW, nBtnH = gRespX(400), gRespY(44)
        local nBtnX = math.floor((scrW * 0.76 - nBtnW) / 2)
        local nBtnY = scrH - gRespY(58)
        local ROW_H = gRespY(52)

        local tEntrees = {} -- { label, choix, model, nSkin } (choix "rituel" = sans modele)
        local listPnl

        local head = vgui.Create("DButton", frame)
        head:SetText("")
        head:SetPos(nBtnX, nBtnY)
        head:SetSize(nBtnW, nBtnH)
        head._label = "Apparence de la libération"
        head.Paint = function(pb, w, h)
            if EVO_UI and EVO_UI.PaintCut then
                EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(10), "br")
            else
                draw.RoundedBox(8, 0, 0, w, h, COL_PLATE)
            end
            local bOpen = IsValid(listPnl)
            surface.SetDrawColor(COL_ACC.r, COL_ACC.g, COL_ACC.b, (pb:IsHovered() or bOpen) and 235 or 130)
            surface.DrawRect(0, 0, gRespX(3), h)
            draw.SimpleText(pb._label, "EVO_ShikUI_SkinBtn", gRespX(16), h / 2,
                (pb:IsHovered() or bOpen) and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            -- Chevron vers le HAUT : la liste se déroule au-dessus.
            draw.SimpleText(bOpen and "▼" or "▲", "EVO_ShikUI_SkinRow", w - gRespX(16), h / 2,
                COL_ACC, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        local function FermerListe()
            if IsValid(listPnl) then listPnl:Remove() end
            listPnl = nil
        end

        local function OuvrirListe()
            FermerListe()
            local nH = math.min(#tEntrees * ROW_H + gRespY(8), gRespY(340))
            listPnl = vgui.Create("DPanel", frame)
            listPnl:SetPos(nBtnX, nBtnY - nH - gRespY(6)) -- AU-DESSUS de la tête
            listPnl:SetSize(nBtnW, nH)
            listPnl.Paint = function(_, w, h)
                if EVO_UI and EVO_UI.PaintCut then
                    EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(10))
                else
                    draw.RoundedBox(8, 0, 0, w, h, COL_PLATE)
                end
            end

            local sc = vgui.Create("DScrollPanel", listPnl)
            sc:Dock(FILL)
            sc:DockMargin(gRespX(4), gRespY(4), gRespX(4), gRespY(4))
            local vbar = sc:GetVBar()
            if IsValid(vbar) then
                vbar:SetWide(gRespX(5))
                vbar.Paint = function() end
                if IsValid(vbar.btnUp) then vbar.btnUp.Paint = function() end end
                if IsValid(vbar.btnDown) then vbar.btnDown.Paint = function() end end
                vbar.btnGrip.Paint = function(_, w, h) draw.RoundedBox(3, 0, 0, w, h, ColorAlpha(COL_ACC, 150)) end
            end

            for _, en in ipairs(tEntrees) do
                local row = vgui.Create("DButton")
                row:SetText("")
                sc:AddItem(row)
                row:Dock(TOP)
                row:SetTall(ROW_H - gRespY(4))
                row:DockMargin(0, 0, gRespX(6), gRespY(4))
                row.Paint = function(pr, w, h)
                    draw.RoundedBox(gRespY(7), 0, 0, w, h, pr:IsHovered() and COL_PLATE2 or ColorAlpha(color_white, 6))
                    if pr:IsHovered() then
                        surface.SetDrawColor(COL_ACC)
                        surface.DrawRect(0, 0, gRespX(2), h)
                    end
                    draw.SimpleText(en.label, "EVO_ShikUI_SkinRow", gRespX(58), h / 2,
                        pr:IsHovered() and COL_TITLE or (en.choix == "rituel" and COL_ACC or COL_MUTED),
                        TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end
                row.DoClick = function()
                    surface.PlaySound("buttons/lightswitch2.wav")
                    head._label = en.label
                    net.Start("EVO::PowerUI::SkinPick")
                        net.WriteString(en.choix)
                    net.SendToServer()
                    FermerListe()
                end

                -- APERÇU 3D de la lame (pas pour « Lame du rituel » : son modèle exact
                -- vit côté serveur — un glyphe accent marque l'entrée à la place).
                if en.model and en.model ~= "" then
                    local prev = vgui.Create("DModelPanel", row)
                    prev:SetPos(gRespX(4), gRespY(2))
                    prev:SetSize(gRespX(50), ROW_H - gRespY(8))
                    prev:SetMouseInputEnabled(false)
                    QueuePreviewModel(prev, function(prev)
                        prev:SetModel(en.model)
                        local eMdl = prev.Entity
                        if IsValid(eMdl) then
                            local mn, mx = eMdl:GetRenderBounds()
                            local c = (mn + mx) * 0.5
                            local d = math.max(8, (mx - mn):Length())
                            prev:SetLookAt(c)
                            prev:SetCamPos(c + Vector(d * 0.42, d * 0.42, d * 0.16))
                            prev:SetFOV(30)
                        end
                    end)
                    local nSkinPrev = en.nSkin or 0
                    function prev:LayoutEntity(e2)
                        e2:SetAngles(Angle(0, RealTime() * 40 % 360, 0))
                        e2:SetSkin(nSkinPrev)
                    end
                else
                    local gl = vgui.Create("DLabel", row)
                    gl:SetText("千")
                    gl:SetFont("EVO_ShikUI_SkinBtn")
                    gl:SetTextColor(ColorAlpha(COL_ACC, 220))
                    gl:SetContentAlignment(5)
                    gl:SetPos(gRespX(4), 0)
                    gl:SetSize(gRespX(50), ROW_H - gRespY(4))
                    gl:SetMouseInputEnabled(false)
                end
            end
        end

        head.DoClick = function()
            surface.PlaySound(EVO_UI and EVO_UI.SndClick or "buttons/lightswitch2.wav")
            if IsValid(listPnl) then FermerListe() else OuvrirListe() end
        end

        -- REGLAGE EN MAIN (17/10/2026, demande joueur) : a droite du choix d'apparence.
        -- Ferme le menu et ouvre l'editeur commun aux katanas et aux hakuda.
        local btnRegler = vgui.Create("DButton", frame)
        btnRegler:SetText("")
        btnRegler:SetPos(nBtnX + nBtnW + gRespX(10), nBtnY)
        btnRegler:SetSize(gRespX(220), nBtnH)
        btnRegler.Paint = function(pb, w, h)
            if EVO_UI and EVO_UI.PaintCut then
                EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, gRespY(10), "br")
            else
                draw.RoundedBox(8, 0, 0, w, h, COL_PLATE)
            end
            surface.SetDrawColor(COL_ACC.r, COL_ACC.g, COL_ACC.b, pb:IsHovered() and 235 or 130)
            surface.DrawRect(0, 0, gRespX(3), h)
            draw.SimpleText("Régler en main", "EVO_ShikUI_SkinBtn", w / 2, h / 2,
                pb:IsHovered() and COL_TITLE or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        btnRegler.DoClick = function()
            surface.PlaySound(EVO_UI and EVO_UI.SndClick or "buttons/lightswitch2.wav")
            FermerListe()
            frame:HideUI()
            if EVO_REGLAGE_LAME and EVO_REGLAGE_LAME.Ouvrir then EVO_REGLAGE_LAME.Ouvrir() end
        end

        function frame:RebuildSkinStrip()
            FermerListe()
            head._label = "Apparence de la libération"
            tEntrees = { { label = "Lame du rituel", choix = "rituel" } }
            local me = LocalPlayer()
            local bHakuda = EvoStyle and EvoStyle.GetStyleFamily
                and EvoStyle.GetStyleFamily(me:GetEvoNWString("StyleCombat", "")) == "hakuda"
            local sItemPrefix = bHakuda and "gauntlet_" or "katana_"
            local tCat = bHakuda and (NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List)
                or (KATANA_SKINS and KATANA_SKINS.List)
            if not tCat or not me.GetInventoryItems then return end
            local seen = {}
            for _, sItem in ipairs(me:GetInventoryItems() or {}) do
                local sID = string.match(sItem, "^" .. sItemPrefix .. "(.+)$")
                if sID and not seen[sID] and tCat[sID] then
                    seen[sID] = true
                    tEntrees[#tEntrees + 1] = {
                        label = tostring(tCat[sID].name or sID),
                        choix = sID,
                        model = tCat[sID].model,
                        nSkin = tCat[sID].nSkin,
                    }
                end
            end
        end
        frame:RebuildSkinStrip()
    end

    -- Panneau d'améliorations à droite : SOURIS ON, CLAVIER OFF.
    -- Feuille DOCKÉE au bord droit, PLEINE hauteur (panelW hoisté en tête d'Open :
    -- frame.Paint dessine l'image de fond de la feuille au même rect).
    local htmlPanel = vgui.Create("DHTML", frame)
    htmlPanel:SetPos(scrW - panelW, 0)
    htmlPanel:SetSize(panelW, scrH)
    htmlPanel:SetAllowLua(false)
    htmlPanel:SetKeyboardInputEnabled(false)

    local function PushBG()
        if not IsValid(frame) or not IsValid(htmlBG) then return end
        htmlBG:RunJavascript("if(window.EVO_SetBG){EVO_SetBG(" .. util.TableToJSON(BuildState(sMode)) .. ");}")
    end
    local function PushPanel()
        if not IsValid(frame) or not IsValid(htmlPanel) then return end
        htmlPanel:RunJavascript("if(window.EVO_SetPanel){EVO_SetPanel(" .. util.TableToJSON(BuildState(sMode)) .. ");}")
    end
    -- Coche « cinématique d'activation » (user 08/28), menu SHIKAI uniquement :
    -- décochée, l'activation ne joue que la bande « Fracture » — la page blanche,
    -- le nom et la caméra sont sautés (convar userinfo evo_shikai_cinematique,
    -- lue côté serveur pour la caméra et côté client pour la page blanche).
    if sMode == "shikai" then
        local chkCine = vgui.Create("DCheckBoxLabel", frame)
        chkCine:SetPos(math.floor(scrW * 0.012), math.floor(scrH * 0.955))
        chkCine:SetText("Cinématique d'activation complète")
        chkCine:SetTextColor(Color(230, 230, 235))
        chkCine:SetConVar("evo_shikai_cinematique")
        chkCine:SizeToContents()
    end

    frame._PushBG, frame._PushPanel = PushBG, PushPanel

    htmlBG:AddFunction("gmod", "ready", PushBG)
    htmlBG:SetHTML(Fill(BG_TEMPLATE, {
        GRADIENT = m.gradient, ACCENT = m.accent, GLOWA = m.glowA, GLOWB = m.glowB,
        BEBAS = bebas_face_css(), ABEEZEE = abeezee_face_css(), SLASHMASK = slash_mask_url(),
    }))

    htmlPanel:AddFunction("gmod", "close", function()
        if IsValid(frame) then frame:HideUI() end -- frame persistant : on CACHE, on ne détruit plus
    end)
    htmlPanel:AddFunction("gmod", "buy", function(sId)
        if not isstring(sId) then return end
        local tDef = EVO_SHIKAI_UI.GetUpgrade(sMode, sId)
        if not tDef then return end
        if (EVO_SHIKAI_UI._buyCd or 0) > CurTime() then return end
        EVO_SHIKAI_UI._buyCd = CurTime() + 0.3
        -- Pré-checks confort (le serveur re-valide tout, fail-closed).
        local me = LocalPlayer()
        local data = EVO_SHIKAI_UI.ClientData[sMode] or {}
        -- AUCUN refus muet (user 08/29 : « ca marche pas ») : chaque cas qui bloque
        -- l'achat DOIT se dire. Avant, cliquer sans assez de yens ne faisait
        -- strictement rien et rien ne l'expliquait.
        local function Refus(sMsg)
            if MUGEN and MUGEN.Notify then MUGEN.Notify(sMsg, NOTIFY_ERROR or 1, 5) end
        end

        local nLevel = (data.ups and data.ups[sId]) or 0
        if not data.ups then
            Refus("Tes niveaux ne sont pas encore chargés, réessaie dans un instant.")
            return
        end
        if nLevel >= EVO_SHIKAI_UI.MaxLevel then
            Refus("Niveau maximum déjà atteint pour cette amélioration.")
            return
        end
        -- PLUS DE COUT EN YENS (09/01, demande user) : seule l'UTILISATION du
        -- pouvoir (temps cumule) debloque les niveaux.
        -- Miroir du verrou serveur, expliqué lui aussi.
        local nBesoin = EVO_SHIKAI_UI.GetTimeReq(sMode, nLevel) or 0
        local nFait   = tonumber((data.stats or {}).active_seconds) or 0
        if nBesoin > 0 and nFait < nBesoin then
            Refus(string.format("Il te faut %s d'utilisation pour ce niveau (tu en as %s).",
                EVO_SHIKAI_UI.FormatDuree(nBesoin), EVO_SHIKAI_UI.FormatDuree(nFait)))
            return
        end
        surface.PlaySound(SND_CLICK)
        net.Start("EVO::PowerUI::Buy")
        net.WriteString(sMode)
        net.WriteString(sId)
        net.SendToServer()
    end)
    htmlPanel:AddFunction("gmod", "ready", PushPanel)
    htmlPanel:SetHTML(Fill(PANEL_TEMPLATE, {
        ACCENT = m.accent, BEBAS = bebas_face_css(), ABEEZEE = abeezee_face_css(), SLASHMASK = slash_mask_url(),
    }))

    -- Push périodique (stats, nom) — 2 Hz, léger. Nom PAR MODE : les deux
    -- frames persistants (shikai + bankai) coexistent, chacun son timer.
    local PUSH_TIMER = "EVO_ShikaiUI::Push::" .. sMode
    timer.Create(PUSH_TIMER, 0.5, 0, function()
        if not IsValid(frame) then timer.Remove(PUSH_TIMER) return end
        if not frame:IsVisible() then return end -- caché : rien à pousser
        PushBG()
        PushPanel()
    end)

    -- Lame en direct : swap shikai (KatanaSkin, 1s après activation) / changement de skin.
    -- (nom de hook PAR MODE, même raison que le timer.)
    -- ShikaiSkin ET EVO_ShikaiActive : depuis le 08/29 c'est le MODELE qui change a
    -- la liberation, plus la texture ; sans ces deux cles l'apercu ne bougeait plus.
    local NW_WATCH = { KatanaSkin = true, StyleCombat = true, BankaiWeaponOverride = true, KatanaName = true,
        NCM_HakudaGauntlet = true, ShikaiSkin = true, EVO_ShikaiActive = true }
    local function OnLoadoutStateChanged(ent, sName)
        if not IsValid(frame) then return end
        if not NW_WATCH[sName] then return end
        if ent ~= LocalPlayer() then return end
        if sName ~= "KatanaName" and IsValid(mdl) then
            mdl:SetModel(ResolveKatanaModel(ent))
            FrameModelCamera(mdl)
        end
        if frame:IsVisible() then PushBG() end
    end
    hook.Add("EVO:Appearance:Changed", "EVO_ShikaiUI::Appearance::" .. sMode, OnLoadoutStateChanged)
    hook.Add("LZY:PlyState:Changed", "EVO_ShikaiUI::PlyState::" .. sMode, OnLoadoutStateChanged)

    frame.OnRemove = function(self)
        timer.Remove(PUSH_TIMER)
        hook.Remove("EVO:Appearance:Changed", "EVO_ShikaiUI::Appearance::" .. sMode)
        hook.Remove("LZY:PlyState:Changed", "EVO_ShikaiUI::PlyState::" .. sMode)
        EVO_SHIKAI_UI._closedAt = SysTime()
        if EVO_SHIKAI_UI._Frames and EVO_SHIKAI_UI._Frames[sMode] == self then
            EVO_SHIKAI_UI._Frames[sMode] = nil
        end
        if EVO_SHIKAI_UI._Frame == self then EVO_SHIKAI_UI._Frame = nil end
        if openedFrame == self then openedFrame = nil end
    end

    -- ── Show / Hide : le frame PERSISTE caché (Échap / croix / re-bind = HideUI) ──
    function frame:ShowUI()
        -- État à jour (niveaux + stats) : la réponse Sync re-push les pages.
        net.Start("EVO::PowerUI::Request")
        net.WriteString(sMode)
        net.SendToServer()
        if IsValid(mdl) then
            mdl:SetModel(ResolveKatanaModel(LocalPlayer()))
            FrameModelCamera(mdl)
        end
        -- Le sac a pu changer depuis la derniere ouverture : la bande de skins suit.
        if self.RebuildSkinStrip then self:RebuildSkinStrip() end
        PushBG()
        PushPanel()
        self._opened = CurTime()
        self._bindWasDown = true -- la touche d'ouverture est possiblement encore enfoncée
        self:SetVisible(true)
        self:MakePopup()
        EVO_SHIKAI_UI._Frame = self
        openedFrame = self
        if not self._escWired and EVO_MakeEscClosable then
            EVO_MakeEscClosable(self) -- APRÈS MakePopup (règle repo)
            self._escWired = true
        end
    end

    function frame:HideUI()
        self:SetVisible(false)
        EVO_SHIKAI_UI._closedAt = SysTime()
        if EVO_SHIKAI_UI._Frame == self then EVO_SHIKAI_UI._Frame = nil end
        if openedFrame == self then openedFrame = nil end
    end
    -- Convention globale : Échap (lzy_escape_menu / EVO_MakeEscClosable) appelle
    -- openedFrame:Close() -> on CACHE au lieu de détruire.
    frame.Close = frame.HideUI

    return frame
end

-- ------------------------------------------------------------
-- Ouverture : réutilise le frame persistant du mode (construction lazy au 1er open
-- si le precache ne l'a pas déjà préparé).
-- ------------------------------------------------------------
function EVO_SHIKAI_UI.Open(sMode)
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    if lp:GetEvoNWBool("EVO_StaffMode", false) then return end -- pas d'UI Shikai/Bankai en mode staff
    -- (Redirection shikai->bankai au déblocage du bankai RETIRÉE, demande user 08/07 :
    -- le bind Shikai doit garder SON PROPRE menu même une fois le Bankai débloqué.)
    local m = EVO_SHIKAI_UI.Modes[sMode]
    if not m then return end
    if IsValid(EVO_SHIKAI_UI._Frame) then return end -- un menu est déjà ouvert
    if not lp:GetEvoNWBool(m.unlockNW, false) then
        notification.AddLegacy("Pouvoir non débloqué.", NOTIFY_ERROR, 3)
        return
    end

    local frame = EVO_SHIKAI_UI._Frames[sMode]
    if not IsValid(frame) then
        frame = BuildFrame(sMode) -- 1er open de ce mode : coût one-shot (sinon precache)
        EVO_SHIKAI_UI._Frames[sMode] = frame
    end
    frame:ShowUI()
end

-- ------------------------------------------------------------
-- Sync serveur -> client
-- ------------------------------------------------------------
net.Receive("EVO::PowerUI::Sync", function()
    local sMode = net.ReadString()
    local tUps  = util.JSONToTable(net.ReadString() or "") or {}
    local tSt   = util.JSONToTable(net.ReadString() or "") or {}
    EVO_SHIKAI_UI.ClientData[sMode] = { ups = tUps, stats = tSt }
    local frame = EVO_SHIKAI_UI._Frame
    if IsValid(frame) and frame._mode == sMode and frame._PushPanel then
        frame._PushPanel()
        frame._PushBG()
    end
end)

-- Éclair blanc + son sur achat réussi.
net.Receive("EVO::PowerUI::Flash", function()
    local sMode = net.ReadString()
    surface.PlaySound(SND_UPGRADE)
    local frame = EVO_SHIKAI_UI._Frame
    if IsValid(frame) and frame._mode == sMode then
        frame._flashStart = SysTime()
    end
end)

-- ------------------------------------------------------------
-- Concommands + binds (un par mode). RÈGLE repo : PlayerButtonDown
-- filtre le 1er arg (prédiction) ; n'OUVRE que ; fermeture = Think + Échap.
-- ------------------------------------------------------------
for _, sMode in ipairs(EVO_SHIKAI_UI.ModeOrder) do
    local m = EVO_SHIKAI_UI.Modes[sMode]
    concommand.Add(m.concommand, function() EVO_SHIKAI_UI.Open(sMode) end)
end

-- Ferme le menu Shikai/Bankai s'il était ouvert au moment d'entrer en mode staff.
hook.Add("Think", "EVO_ShikaiUI::StaffClose", function()
    if not IsValid(EVO_SHIKAI_UI._Frame) then return end
    local lp = LocalPlayer()
    if IsValid(lp) and lp:GetEvoNWBool("EVO_StaffMode", false) then
        EVO_SHIKAI_UI._Frame:Remove()
    end
end)

hook.Add("PlayerButtonDown", "EVO_ShikaiUI::Bind", function(ply, button)
    if not IsValid(ply) or ply ~= LocalPlayer() then return end
    if IsValid(EVO_SHIKAI_UI._Frame) then return end
    if SysTime() - (EVO_SHIKAI_UI._closedAt or 0) < 0.3 then return end -- anti-réouverture même appui
    if not ply.GetBindKey then return end
    for _, sMode in ipairs(EVO_SHIKAI_UI.ModeOrder) do
        local m = EVO_SHIKAI_UI.Modes[sMode]
        local bindKey = ply:GetBindKey(m.bind)
        if bindKey and bindKey ~= KEY_NONE and button == bindKey then
            EVO_SHIKAI_UI.Open(sMode)
            return
        end
    end
end)

-- ------------------------------------------------------------
-- PRECACHE anti-lag du 1er OPEN (fix "mini chargement", 2026-07-13) — même recette
-- que le menu échap / la boutique : payer les coûts one-shot À LA CONNEXION, pas au
-- premier clic. Coûts couverts :
--  • fontes base64 (Bebas + ABeeZee, ~80 Ko chacune) + masque slash (file.Read + Base64Encode)
--  • images d'ambiance des DEUX modes : Material() = décodage jpg/png SYNCHRONE (le plus gros)
--  • bake des layer blurs (GhostBlurMat, RT 512) : one-shot en contexte de rendu (PreRender)
--  • prewarm CEF : le 1er navigateur DHTML de la session coûte ~0.5s -> on en crée un
--    jetable 1px tout de suite (les SetHTML suivants sont quasi instantanés)
-- ------------------------------------------------------------
hook.Add("InitPostEntity", "EVO_ShikaiUI::Precache", function()
    timer.Simple(8, function() -- après le rush d'assets de la connexion
        -- Fontes + masque (mis en cache module par leurs helpers).
        bebas_face_css()
        abeezee_face_css()
        slash_mask_url()

        -- Matériaux d'ambiance des deux modes (décodage disque -> cache moteur).
        local tMats = {}
        for _, sMode in ipairs(EVO_SHIKAI_UI.ModeOrder) do
            local imgs = (EVO_SHIKAI_UI.Modes[sMode] or {}).images or {}
            local mS, mP = TryMaterial(imgs.side), TryMaterial(imgs.panel)
            if mS then tMats[#tMats + 1] = mS end
            if mP then tMats[#tMats + 1] = mP end
        end

        -- Bake des layer blurs en contexte de rendu (ghostBlurredMat fait son propre
        -- PushRenderTarget + cam.Start2D -> OK dans un PreRender one-shot).
        if EVO_UI and EVO_UI.GhostBlurMat and tMats[1] then
            hook.Add("PreRender", "EVO_ShikaiUI::PrecacheBlur", function()
                for _, mat in ipairs(tMats) do
                    EVO_UI.GhostBlurMat(mat)
                end
                hook.Remove("PreRender", "EVO_ShikaiUI::PrecacheBlur")
            end)
        end

        -- Prewarm CEF : panneau DHTML jetable hors écran (init du process Chromium).
        local pWarm = vgui.Create("DHTML")
        if IsValid(pWarm) then
            pWarm:SetSize(1, 1)
            pWarm:SetPos(-16, -16)
            pWarm:SetPaintedManually(true) -- jamais dessiné : on ne veut que l'init CEF
            pWarm:SetHTML("<html><body></body></html>")
            timer.Simple(10, function()
                if IsValid(pWarm) then pWarm:Remove() end
            end)
        end

        -- PRÉ-CONSTRUCTION des menus des pouvoirs DÉJÀ DÉBLOQUÉS (cachés), une fois le
        -- CEF chaud : l'ouverture devient un simple Show -> AUCUNE création au clic.
        -- Un pouvoir débloqué plus tard se construira au 1er open (coût one-shot unique).
        timer.Simple(4, function()
            local me = LocalPlayer()
            if not IsValid(me) then return end
            for _, sM in ipairs(EVO_SHIKAI_UI.ModeOrder) do
                local md = EVO_SHIKAI_UI.Modes[sM]
                if me:GetEvoNWBool(md.unlockNW, false) and not IsValid(EVO_SHIKAI_UI._Frames[sM]) then
                    EVO_SHIKAI_UI._Frames[sM] = BuildFrame(sM)
                end
            end
        end)
    end)
end)

-- Changement de résolution : les frames persistants ont des tailles FIGÉES à la
-- construction -> purge (reconstruits au prochain open / precache).
hook.Add("OnScreenSizeChanged", "EVO_ShikaiUI::PurgeFrames", function()
    for sM, f in pairs(EVO_SHIKAI_UI._Frames or {}) do
        if IsValid(f) then f:Remove() end
        EVO_SHIKAI_UI._Frames[sM] = nil
    end
end)
