-- "addons\\evo_shikai_ui\\lua\\evo_shikai_ui\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- sh_config.lua — Config evo_shikai_ui (partagée client/serveur)
-- Deux "modes" (paliers de pouvoir) partageant le MÊME moteur :
--   shikai = palier 1 (EVO_ShikaiUnlocked / EVO_ShikaiActive)
--   bankai = palier 2 (EVO_BankaiUnlocked / EVO_Bankai)
-- Le NOM affiché dépend de la FACTION du joueur :
--   Shinigami : Shikai / Bankai
--   Hollow/Arrancar : Resurrección Partielle / Resurrección
-- (Le déblocage est le MÊME système pour les deux factions, seul
--  le libellé change — cf. Arrancar qui réutilise le shikai.)
-- ============================================================

EVO_SHIKAI_UI = EVO_SHIKAI_UI or {}

EVO_SHIKAI_UI.MaxLevel = 5

-- Faction "Shinigami" = libellés Shikai/Bankai ; tout le reste (Hollow/Arrancar) = Resurrección Partielle/Resurrección.
EVO_SHIKAI_UI.ShinigamiFaction = "Shinigami"

-- Modes. Les clés "shikai"/"bankai" sont STABLES (DB + réseau) quelle que soit la faction ;
-- seuls labelShinigami/labelHollow changent l'affichage.
EVO_SHIKAI_UI.Modes = {
    shikai = {
        id              = "shikai",
        order           = 1,
        unlockNW        = "EVO_ShikaiUnlocked",
        activeNW        = "EVO_ShikaiActive",
        passiveNW       = "ShikaiPassive",
        activatedHook   = "EVO::ShikaiActivated",
        deactivatedHook = "EVO::ShikaiDeactivated",
        bind            = "shikai_ui",
        concommand      = "evo_shikai_ui",
        labelShinigami  = "SHIKAI",
        labelHollow     = "RESURRECCIÓN PARTIELLE",
        subtitle        = "ÉVEIL DU ZANPAKUTO",
        dodgeKey        = "shikai_upgrade",   -- clé EnableScaleDodgeChance dédiée ("shikai" prise par le shikai de base)
        -- Thème (dégradé du titre + accent). Rouge/or (feu spirituel).
        gradient        = "#cf444e 0%,#e8b34b 22%,#f7f2e8 50%,#8fb8e8 78%,#cf444e 100%",
        accent          = "#cf444e",
        glowA           = "rgba(207,68,78,.16)",
        glowB           = "rgba(232,179,75,.07)",
        -- Images d'ambiance de l'UI (demande user 2026-07-13) : illustration fantôme dans
        -- l'angle haut-gauche + fond de la feuille d'améliorations (droite).
        -- (image bas-gauche "corner" retirée, demande user.)
        images          = {
            side   = "etgmnxxbvsadh9/etgmnxxbvsadh9/image_shikai_ui4.jpg",
            panel  = "etgmnxxbvsadh9/etgmnxxbvsadh9/image_shikai_ui.png",
        },
        -- Passif choisi à l'éveil (affichage seul).
        passiveLabels   = { hp = "VITALITÉ", dmg = "TRANCHANT", flashstep = "CÉLÉRITÉ" },
        -- Prix en YENS pour ATTEINDRE le niveau n (majorés +10% : mid/late game).
        prices          = { 8800, 17600, 33000, 55000, 88000 },
        -- PREREQUIS D'UTILISATION (user 08/29) : temps CUMULE passe sous le pouvoir,
        -- en secondes, pour pouvoir acheter le niveau n. Les yens ne suffisent plus :
        -- il faut s'en etre servi. Cumul persistant (active_seconds, table
        -- evo_power_stats), le chrono en cours compte.
        timeReq         = { 300, 900, 1800, 3600, 7200 }, -- 5 min, 15, 30, 1 h, 2 h
        upgrades = {
            { id = "vitalite",  name = "VITALITÉ",  statKey = "e_max_hp",        perLevel = 2, unit = "PV max",        color = "#4bd47f",
              desc = "Augmente les PV maximum pendant le pouvoir." },
            { id = "tranchant", name = "TRANCHANT", statKey = "e_katana_damage", perLevel = 2, unit = "dégâts d'arme", color = "#cf444e",
              desc = "Augmente les dégâts de votre arme (katana comme Hakuda) pendant le pouvoir." },
            { id = "celerite",  name = "CÉLÉRITÉ",  statKey = "e_flashstep_cd",  perLevel = 5, unit = "CD flashstep",  color = "#4b9fe8",
              desc = "Réduit le temps de recharge du flashstep pendant le pouvoir." },
            { id = "esquive",   name = "ESQUIVE",   scaleDodge = true,           perLevel = 1, unit = "esquive",       color = "#e8b34b",
              desc = "Augmente la chance d'esquive pendant le pouvoir." },
        },
    },
    bankai = {
        id              = "bankai",
        order           = 2,
        unlockNW        = "EVO_BankaiUnlocked",
        activeNW        = "EVO_Bankai",
        passiveNW       = "BankaiPassive",
        activatedHook   = "EVO::BankaiActivated",
        deactivatedHook = "EVO::BankaiDeactivated",
        bind            = "bankai_ui",
        concommand      = "evo_bankai_ui",
        labelShinigami  = "BANKAI",
        labelHollow     = "RESURRECCIÓN",
        subtitle        = "LIBÉRATION FINALE",
        dodgeKey        = "bankai_upgrade",
        -- Thème plus sombre/or-violet (aura finale).
        gradient        = "#8a5cf6 0%,#e8b34b 30%,#f7f2e8 52%,#e8b34b 72%,#8a5cf6 100%",
        accent          = "#b48af6",
        glowA           = "rgba(138,92,246,.18)",
        glowB           = "rgba(232,179,75,.08)",
        -- Images d'ambiance (mêmes emplacements que le shikai ; side partagée).
        images          = {
            side   = "etgmnxxbvsadh9/etgmnxxbvsadh9/image_shikai_ui4.jpg",
            panel  = "etgmnxxbvsadh9/etgmnxxbvsadh9/image_shikai_ui2.png",
        },
        passiveLabels   = { spell = "PUISSANCE", katana = "TRANCHANT", hp = "VITALITÉ" },
        -- Prix nettement plus élevés (endgame, +10%).
        prices          = { 22000, 44000, 77000, 121000, 176000 },
        -- Endgame : exigences de temps doublees par rapport au premier palier.
        timeReq         = { 600, 1800, 3600, 7200, 14400 }, -- 10 min, 30, 1 h, 2 h, 4 h
        upgrades = {
            { id = "puissance", name = "PUISSANCE", statKey = "e_spell_damage",  perLevel = 3, unit = "dégâts de sort", color = "#8a5cf6",
              desc = "Augmente les dégâts de sort pendant la libération." },
            { id = "tranchant", name = "TRANCHANT", statKey = "e_katana_damage", perLevel = 3, unit = "dégâts d'arme",  color = "#cf444e",
              desc = "Augmente les dégâts de votre arme (katana comme Hakuda) pendant la libération." },
            { id = "vitalite",  name = "VITALITÉ",  statKey = "e_max_hp",        perLevel = 3, unit = "PV max",         color = "#4bd47f",
              desc = "Augmente les PV maximum pendant la libération." },
            { id = "esquive",   name = "ESQUIVE",   scaleDodge = true,           perLevel = 2, unit = "esquive",        color = "#e8b34b",
              desc = "Augmente la chance d'esquive pendant la libération." },
        },
    },
}

-- Ordre d'itération déterministe (pairs() ne l'est pas).
EVO_SHIKAI_UI.ModeOrder = { "shikai", "bankai" }

function EVO_SHIKAI_UI.GetMode(sMode)
    return EVO_SHIKAI_UI.Modes[sMode]
end

-- Définition d'une amélioration dans un mode donné.
function EVO_SHIKAI_UI.GetUpgrade(sMode, sId)
    local m = EVO_SHIKAI_UI.Modes[sMode]
    if not m then return nil end
    for _, tDef in ipairs(m.upgrades) do
        if tDef.id == sId then return tDef end
    end
end

-- Coût pour passer du niveau nCurrent au suivant (nil si déjà au max).
--- Temps d'utilisation exige pour ATTEINDRE le niveau suivant (0 si non configure).
function EVO_SHIKAI_UI.GetTimeReq(sMode, nCurrent)
    local m = EVO_SHIKAI_UI.Modes[sMode]
    if not (m and istable(m.timeReq)) then return 0 end
    return m.timeReq[(nCurrent or 0) + 1] or 0
end

--- Duree lisible pour les messages ("1 h 30", "12 min", "45 s").
function EVO_SHIKAI_UI.FormatDuree(n)
    n = math.max(0, math.floor(tonumber(n) or 0))
    if n < 60 then return n .. " s" end
    local h, m2 = math.floor(n / 3600), math.floor((n % 3600) / 60)
    if h > 0 then return m2 > 0 and (h .. " h " .. m2) or (h .. " h") end
    return m2 .. " min"
end

function EVO_SHIKAI_UI.GetPrice(sMode, nCurrent)
    local m = EVO_SHIKAI_UI.Modes[sMode]
    if not m then return nil end
    return m.prices[(nCurrent or 0) + 1]
end

-- Libellé affiché selon la faction (Shinigami vs Hollow/Arrancar).
function EVO_SHIKAI_UI.GetLabel(sMode, sFaction)
    local m = EVO_SHIKAI_UI.Modes[sMode]
    if not m then return "" end
    if sFaction == EVO_SHIKAI_UI.ShinigamiFaction then return m.labelShinigami end
    return m.labelHollow
end

-- ============================================================
-- MOT DE LIBÉRATION (user 08/26) : le mot (ou début de phrase) qui s'affiche en
-- grand sur la bande d'activation du Shikai, choisi PAR LE JOUEUR au déblocage
-- (liste déroulante à côté du nom), modifiable chez le renommeur. Persisté par
-- perso (characters.shikai_word, NW "ShikaiWord"). Depuis le 09/29 (user) : un mot
-- de la liste OU un mot PERSONNALISÉ (ReleaseWordCustomValid : 3 mots max, lettres
-- accentuées permises, filtre de mots interdits). Vide = DefaultReleaseWord.
-- ============================================================
EVO_SHIKAI_UI.DefaultReleaseWord = "Fracture"
EVO_SHIKAI_UI.ReleaseWords = {
    -- "Joue" et "Teje" ajoutes le 08/30 (demande user). ⚠ "Joue" est banni comme
    -- NOM de zanpakuto (evo_wordfilter, liste NameOnly) : ce sont deux filtres
    -- distincts, la liste ci-dessous n'est jamais passee au filtre de mots.
    "Joue", "Teje",
    "Fracture", "Hurle", "Rugis", "Disperse-toi", "Fleuris",
    "Éveille-toi", "Tranche", "Déchire", "Brûle", "Consume-les",
    "Gèle", "Trône dans les cieux gelés", "Danse", "Chante", "Étincelle",
    "Foudroie", "Déferle", "Frappe", "Perce-les", "Mords",
    "Dévore", "Lève-toi", "Dresse-toi", "Fends-les", "Balaie",
    "Gronde", "Déchaîne-toi", "Fissure", "Réduis tout en cendres", "Siffle",
    "Pourfends les Cieux", -- ajoute le 09/07 (demande user)
}

-- ============================================================
-- NOM du Zanpakutō / de la Resurrección : SOURCE UNIQUE de la regle, lue par le
-- menu de deblocage (client ET serveur), le PNJ renommeur et la commande SAM.
-- Trois copies de cette regle vivaient chacune dans leur fichier : passer de
-- 2 a 3 mots (user 08/30) demandait quatre modifications dont deux textes d'aide,
-- avec la garantie qu'une finirait par diverger.
-- ============================================================
EVO_SHIKAI_UI.NameMaxWords = 3
EVO_SHIKAI_UI.NameMaxChars = 32

-- Lettres ASCII + espace + apostrophe/tiret. Pas d'accents : la classe %a de Lua
-- ne les reconnait pas et un nom accentue passerait ou casserait selon le site.
function EVO_SHIKAI_UI.NameValid(sName)
    if not isstring(sName) then return false end
    if #sName < 2 or #sName > EVO_SHIKAI_UI.NameMaxChars then return false end
    if not string.match(sName, "^[%a '%-]+$") then return false end
    if not string.match(sName, "%a") then return false end -- au moins une lettre
    local _, nSpaces = string.gsub(sName, " ", "")
    if nSpaces > (EVO_SHIKAI_UI.NameMaxWords - 1) then return false end
    if string.find(sName, "%-%-") or string.find(sName, "''") then return false end
    return true
end

-- Phrase d'aide ET de refus : l'UI et les messages d'erreur ne peuvent plus se
-- contredire sur le nombre de mots autorises.
function EVO_SHIKAI_UI.NameRule()
    return EVO_SHIKAI_UI.NameMaxWords .. " mots max, lettres uniquement (pas de chiffres ni symboles)"
end

EVO_SHIKAI_UI.ReleaseWordMaxWords = 3
EVO_SHIKAI_UI.ReleaseWordMaxChars = 32

-- Saisie libre : lettres ASCII ou latines accentuées (U+00C0..U+017F, sauf × et ÷),
-- espace simple, apostrophe, tiret. Un caractère hors de ça (chiffre, emoji) = refus.
function EVO_SHIKAI_UI.ReleaseWordCustomValid(sWord)
    if not isstring(sWord) or #sWord < 2 or #sWord > EVO_SHIKAI_UI.ReleaseWordMaxChars then return false end
    if sWord ~= string.Trim(sWord) or string.find(sWord, "  ", 1, true) then return false end
    if not utf8.len(sWord) then return false end
    local bLettre = false
    for _, c in utf8.codes(sWord) do
        local bAscii = (c >= 65 and c <= 90) or (c >= 97 and c <= 122)
        if bAscii or (c >= 0xC0 and c <= 0x17F and c ~= 0xD7 and c ~= 0xF7) then
            bLettre = true
        elseif c ~= 32 and c ~= 39 and c ~= 45 then
            return false
        end
    end
    if not bLettre then return false end
    local _, nEspaces = string.gsub(sWord, " ", "")
    if nEspaces > EVO_SHIKAI_UI.ReleaseWordMaxWords - 1 then return false end
    if EVO_WordFilter and EVO_WordFilter.Contains and EVO_WordFilter.Contains(sWord) then return false end
    return true
end

function EVO_SHIKAI_UI.ReleaseWordRule()
    return EVO_SHIKAI_UI.ReleaseWordMaxWords .. " mots max, lettres uniquement"
end

local _releaseSet
function EVO_SHIKAI_UI.ReleaseWordValid(sWord)
    if not isstring(sWord) then return false end
    if not _releaseSet then
        _releaseSet = {}
        for _, w in ipairs(EVO_SHIKAI_UI.ReleaseWords) do _releaseSet[w] = true end
    end
    return _releaseSet[sWord] == true or EVO_SHIKAI_UI.ReleaseWordCustomValid(sWord)
end

-- Mot à afficher pour une valeur stockée (vide / inconnue -> défaut).
function EVO_SHIKAI_UI.ReleaseWordOrDefault(sWord)
    if EVO_SHIKAI_UI.ReleaseWordValid(sWord) then return sWord end
    return EVO_SHIKAI_UI.DefaultReleaseWord
end
