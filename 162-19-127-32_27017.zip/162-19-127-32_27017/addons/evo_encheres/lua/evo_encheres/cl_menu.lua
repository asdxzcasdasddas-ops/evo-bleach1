-- "addons\\evo_encheres\\lua\\evo_encheres\\cl_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ENCHÈRES — page boutique LZY:Shop:Encheres (1–3 lots, mises coins).
-- ============================================================================

local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_GOLD   = Color(255, 205, 60)
local COL_ACCENT = Color(207, 68, 78)
local COL_OK     = Color(78, 196, 128)
local COL_DIM    = Color(106, 109, 118)

local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"
local COIN_MAT = Material("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "smooth")

-- Prix + icône evocoin (même material que cosmétiques / black market).
local function drawAmount(cx, cy, amount, font, col, coinPx)
	local text = tostring(amount)
	surface.SetFont(font)
	local tw = surface.GetTextSize(text)
	coinPx = math.max(8, math.floor(tonumber(coinPx) or 18))
	local gap = math.max(4, math.floor(coinPx * 0.22))
	local x0 = math.floor(cx - (tw + gap + coinPx) / 2)
	draw.SimpleText(text, font, x0, cy, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	if COIN_MAT and not COIN_MAT:IsError() then
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(COIN_MAT)
		surface.DrawTexturedRect(x0 + tw + gap, math.floor(cy - coinPx / 2), coinPx, coinPx)
	end
end

LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.EvoEncheres_Cancel = function()
	net.Start("evo_encheres.admin_cancel")
	net.SendToServer()
end

local function requestCancelAuction()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:IsSuperAdmin()) then return end
	local msg = "Annuler l'enchère en cours ? Les mises seront rendues. Tu pourras en recréer une pour aujourd'hui."
	if lp.OpenYesNoPopup then
		lp:OpenYesNoPopup(msg, "EvoEncheres_Cancel", {})
	else
		net.Start("evo_encheres.admin_cancel")
		net.SendToServer()
	end
end
EVO_Encheres.RequestCancel = requestCancelAuction

EVO_Encheres = EVO_Encheres or {}
EVO_Encheres.Client = EVO_Encheres.Client or {
	friday = "",
	phase = 0,
	serverNow = 0,
	recvRT = 0,
	nextOpen = 0,
	closeRemain = 0,
	lots = {},
	ready = false,
}

local State = EVO_Encheres.Client
local openPanel

local RARITY_COL = {
	common    = Color(180, 180, 180),
	rare      = Color(110, 170, 255),
	epic      = Color(150, 70, 220),
	legendary = Color(255, 210, 90),
	mythic    = Color(255, 95, 95),
}

local function itemDef(id)
	return (ITEMS and ITEMS[id]) or nil
end

local function itemName(id)
	local it = itemDef(id)
	if it and isstring(it.name) and it.name ~= "" then return it.name end
	return id ~= "" and id or "Item"
end

local function rarityCol(id)
	local it = itemDef(id)
	local r = it and isstring(it.rarity) and string.lower(it.rarity) or "common"
	return RARITY_COL[r] or RARITY_COL.common
end

local function fmtHMS(sec)
	sec = math.max(0, math.floor(tonumber(sec) or 0))
	local h = math.floor(sec / 3600)
	local m = math.floor((sec % 3600) / 60)
	local s = sec % 60
	if h > 0 then return string.format("%dh %02d:%02d", h, m, s) end
	return string.format("%02d:%02d", m, s)
end

local function skewedNow()
	return (State.serverNow or 0) + (RealTime() - (State.recvRT or RealTime()))
end

local function requestSync()
	net.Start("evo_encheres.sync")
	net.SendToServer()
end

local function unwatch()
	net.Start("evo_encheres.unwatch")
	net.SendToServer()
end

local function sendBid(slot, total)
	total = math.floor(tonumber(total) or 0)
	local lot
	for i = 1, #(State.lots or {}) do
		if State.lots[i].slot == slot then lot = State.lots[i] break end
	end
	local delta = total
	if lot then
		local lp = LocalPlayer()
		local sid = IsValid(lp) and tostring(lp:SteamID64() or "") or ""
		if sid ~= "" and tostring(lot.bidder_sid or "") == sid then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("Tu es déjà en tête sur cet item.", NOTIFY_ERROR, 3)
			end
			return
		end
		if total < EVO_Encheres.MinNextTotal(lot) then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("La mise doit dépasser l'enchère actuelle.", NOTIFY_ERROR, 3)
			end
			return
		end
	end
	if delta > 0 and LZY_Shop_CanAfford and not LZY_Shop_CanAfford(delta) then
		if LZY_Shop_OpenCoins then LZY_Shop_OpenCoins() end
		return
	end
	net.Start("evo_encheres.bid")
		net.WriteUInt(slot, 2)
		net.WriteUInt(math.max(0, total), 32)
	net.SendToServer()
end

net.Receive("evo_encheres.state", function()
	State.friday = net.ReadString() or ""
	State.phase = net.ReadUInt(3)
	State.serverNow = net.ReadUInt(32)
	State.nextOpen = net.ReadUInt(32)
	State.closeRemain = net.ReadUInt(32)
	State.recvRT = RealTime()
	local n = net.ReadUInt(2)
	local lots = {}
	for i = 1, n do
		lots[i] = EVO_Encheres.ReadLot()
	end
	State.lots = lots
	State.ready = true
	if IsValid(openPanel) and openPanel.Rebuild then
		openPanel:Rebuild()
	end
end)

net.Receive("evo_encheres.result", function()
	local ok = net.ReadBool()
	local reason = net.ReadString() or ""
	if ok then
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Enchère enregistrée.", NOTIFY_GENERIC or 0, 3) end
		return
	end
	if reason == "insufficient" then
		if LZY_Shop_OpenCoins then LZY_Shop_OpenCoins() end
		return
	end
	local msg = "Enchère refusée."
	if reason == "too_low" then msg = "Mise trop basse."
	elseif reason == "closed" then msg = "Les enchères sont fermées."
	elseif reason == "lost" then msg = "Quelqu'un a enchéri juste avant toi."
	elseif reason == "leading" then msg = "Tu es déjà en tête sur cet item."
	elseif reason == "rate" then msg = "Patiente une seconde."
	end
	if MUGEN and MUGEN.Notify then MUGEN.Notify(msg, NOTIFY_ERROR, 3) end
end)

-- Même preview 3D que cosmétiques / black market (cadrage Head1, mesh, etc.).
-- Chapeaux : un petit décalage ÉCRAN borné (pas de model_lift × bbox perso).
local function attachModel(parent, itemId, x, y, w, h)
	if IsValid(parent._mdlHold) then parent._mdlHold:Remove() end
	local it = itemDef(itemId)
	if not (it and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it)) then
		return
	end
	local hold = vgui.Create("DPanel", parent)
	parent._mdlHold = hold
	hold:gSetPos(x, y)
	hold:gSetSize(w, h)
	hold:SetMouseInputEnabled(false)
	hold:SetPaintBackground(false)
	hold.Paint = function() end

	local isAcc = it.category == "accessory"
	local slotL = isAcc and isstring(it.slot) and string.lower(it.slot) or ""
	local isHead = slotL == "head" or (LZY_INVENTORY_ITEM_PREVIEW.ItemIsHeadAccessory
		and LZY_INVENTORY_ITEM_PREVIEW.ItemIsHeadAccessory(it))
	local needDown = isAcc and slotL ~= "ring" and slotL ~= "belt"
	-- Hats : un peu plus de marge que 0.55 (sinon le bord haut est collé).
	local margin = isAcc and (isHead and 1.0 or 0.55) or nil
	LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(hold, it, 30, margin, nil, true, function(mp)
		if IsValid(mp) and needDown then
			local prev = mp.LayoutEntity
			mp.LayoutEntity = function(pnl, ent)
				if prev then prev(pnl, ent) end
				local look, cam = pnl:GetLookAt(), pnl:GetCamPos()
				local dir = look - cam
				if dir:LengthSqr() < 1e-6 then return end
				dir:Normalize()
				local worldUp = Vector(0, 0, 1)
				local right = dir:Cross(worldUp)
				if right:LengthSqr() < 1e-4 then right = dir:Cross(Vector(0, 1, 0)) end
				right:Normalize()
				local screenUp = right:Cross(dir)
				screenUp:Normalize()
				-- Borné : assez pour descendre le chapeau au centre, trop peu pour
				-- viser le vide (l'ancien * 0.28 * dist + lift×skeleton le faisait).
				local amount = math.Clamp(cam:Distance(look) * 0.12, 4, 8)
				local shift = screenUp * amount
				pnl:SetLookAt(look + shift)
				pnl:SetCamPos(cam + shift)
			end
		end
	end)
end

local PANEL = {}

function PANEL:Init()
	openPanel = self
	self._builtSig = ""
	requestSync()
	self:Rebuild()
end

function PANEL:OnRemove()
	if openPanel == self then openPanel = nil end
	unwatch()
end

function PANEL:Paint(w, h)
	local phase = State.phase or 0
	if phase == EVO_Encheres.PHASE_LIVE or phase == EVO_Encheres.PHASE_OVERTIME or (phase == EVO_Encheres.PHASE_DONE and #(State.lots or {}) > 0) then
		local left
		if phase == EVO_Encheres.PHASE_OVERTIME then
			left = nil
		elseif phase == EVO_Encheres.PHASE_DONE then
			draw.SimpleText("ENCHÈRES TERMINÉES", "Bebas Neue:22", w / 2, gRespY(8), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			return
		else
			local elapsed = RealTime() - (State.recvRT or RealTime())
			left = math.max(0, (State.closeRemain or 0) - elapsed)
		end
		if left then
			draw.SimpleText("FERMETURE " .. fmtHMS(left), "Bebas Neue:22", w / 2, gRespY(8), COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		else
			draw.SimpleText("PROLONGATION — 30s après la dernière mise", "Bebas Neue:22", w / 2, gRespY(8), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		end
		return
	end

	local title, sub = "ENCHÈRES", ""
	if not State.ready then
		title = "ENCHÈRES"
		sub = "Chargement…"
	elseif phase == EVO_Encheres.PHASE_EMPTY then
		title = "AUCUNE ENCHÈRE CETTE SEMAINE"
		sub = "Reviens vendredi prochain."
	elseif phase == EVO_Encheres.PHASE_DONE then
		title = "ENCHÈRES TERMINÉES"
		local elapsed = RealTime() - (State.recvRT or RealTime())
		sub = "Prochaine ouverture dans " .. fmtHMS((State.nextOpen or 0) - elapsed)
	else
		title = "PROCHAINE ENCHÈRE"
		local elapsed = RealTime() - (State.recvRT or RealTime())
		sub = "Ouverture vendredi dans " .. fmtHMS((State.nextOpen or 0) - elapsed)
	end
	draw.SimpleText(title, "Bebas Neue:42", w / 2, h * 0.38, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sub, "Avenir Next World:18", w / 2, h * 0.38 + gRespY(36), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function makeIncBtn(parent, label, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b.OnCursorEntered = function()
		if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
	end
	b.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 8)) or (s:IsHovered() and 1 or 0)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, hf > 0.02 and Color(36, 28, 12, 245) or Color(22, 18, 10, 235), 6, "br")
		else
			surface.SetDrawColor(22, 18, 10, 235)
			surface.DrawRect(0, 0, w, h)
		end
		surface.SetDrawColor(ColorAlpha(COL_GOLD, 160 + 80 * hf))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(label, "Bebas Neue:22", w / 2, h / 2, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function()
		surface.PlaySound(SND_CLICK)
		fn()
	end
	return b
end

function PANEL:Rebuild()
	if IsValid(self._host) then self._host:Remove() end
	self._host = vgui.Create("DPanel", self)
	self._host:Dock(FILL)
	self._host:SetPaintBackground(false)

	local lp = LocalPlayer()
	if IsValid(lp) and lp:IsSuperAdmin() then
		local admin = vgui.Create("DButton", self._host)
		admin:gSetPos(20, 8)
		admin:gSetSize(220, 40)
		admin:SetText("")
		admin:SetCursor("hand")
		admin.Paint = function(s, w, h)
			local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 8)) or (s:IsHovered() and 1 or 0)
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, hf > 0.02 and Color(36, 28, 12, 245) or Color(18, 16, 12, 230), 8, "br")
			end
			draw.SimpleText("GESTION ADMIN", "Bebas Neue:20", w / 2, h / 2, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		admin.DoClick = function()
			surface.PlaySound(SND_CLICK)
			if EVO_Encheres.OpenAdmin then EVO_Encheres.OpenAdmin() end
		end

		if (State.phase or 0) == EVO_Encheres.PHASE_EMPTY then
			local hint = vgui.Create("DPanel", self._host)
			hint:gSetPos(20, 52)
			hint:gSetSize(720, 28)
			hint:SetMouseInputEnabled(false)
			hint:SetPaintBackground(false)
			hint.Paint = function(_, w, h)
				draw.SimpleText("Recrée une vente dans Gestion Admin (1re ligne), puis enregistre.",
					"Avenir Next World:15", 0, h / 2, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end

		local hasOpen = false
		for i = 1, #(State.lots or {}) do
			if State.lots[i].status == "open" then hasOpen = true break end
		end
		if hasOpen then
			local cancel = vgui.Create("DButton", self._host)
			cancel:gSetPos(250, 8)
			cancel:gSetSize(240, 40)
			cancel:SetText("")
			cancel:SetCursor("hand")
			cancel.Paint = function(s, w, h)
				local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 8)) or (s:IsHovered() and 1 or 0)
				if EVO_UI and EVO_UI.PaintCut then
					EVO_UI.PaintCut(0, 0, w, h, hf > 0.02 and Color(48, 16, 18, 245) or Color(28, 12, 14, 230), 8, "br")
				end
				draw.SimpleText("ANNULER L'ENCHÈRE", "Bebas Neue:20", w / 2, h / 2, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			cancel.DoClick = function()
				surface.PlaySound(SND_CLICK)
				requestCancelAuction()
			end
		end
	end

	local phase = State.phase or 0
	local lots = State.lots or {}
	if phase ~= EVO_Encheres.PHASE_LIVE and phase ~= EVO_Encheres.PHASE_OVERTIME and phase ~= EVO_Encheres.PHASE_DONE then
		return
	end
	if #lots == 0 then return end

	local n = #lots
	local cw, ch = 540, 820
	local gap = 24
	local total = n * cw + (n - 1) * gap
	local x0 = math.floor((1840 - total) / 2)
	local y0 = 52

	for i = 1, n do
		local lot = lots[i]
		local card = vgui.Create("DPanel", self._host)
		card:gSetPos(x0 + (i - 1) * (cw + gap), y0)
		card:gSetSize(cw, ch)
		local rc = rarityCol(lot.item_id)
		local closed = lot.status ~= "open"
		card.Paint = function(s, w, h)
			local plate = Color(13, 14, 17, 235)
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, plate, gRespY(14), "br")
			else
				surface.SetDrawColor(plate)
				surface.DrawRect(0, 0, w, h)
			end
			surface.SetDrawColor(ColorAlpha(rc, 200))
			surface.DrawOutlinedRect(0, 0, w, h, 2)
			draw.SimpleText(itemName(lot.item_id), "Bebas Neue:28", w / 2, gRespY(16), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			local start = tonumber(lot.start_price) or 0
			local shown = EVO_Encheres.DisplayedPrice(lot)
			drawAmount(w / 2, gRespY(58), "Départ " .. start, "Avenir Next World:15", COL_MUTED, gRespY(16))
			drawAmount(w / 2, gRespY(448), shown, "Bebas Neue:48", COL_GOLD, gRespY(36))
			if lot.bidder_name ~= "" then
				draw.SimpleText("En tête : " .. lot.bidder_name, "Avenir Next World:16", w / 2, gRespY(500), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText("Aucune mise", "Avenir Next World:16", w / 2, gRespY(500), COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			if lot.status == "sold" then
				draw.SimpleText("VENDU", "Bebas Neue:26", w / 2, gRespY(536), COL_OK, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			elseif lot.status == "unsold" then
				draw.SimpleText("INVENDU", "Bebas Neue:26", w / 2, gRespY(536), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			elseif (tonumber(lot.overtime_end) or 0) > 0 then
				local left = math.max(0, (tonumber(lot.overtime_end) or 0) - skewedNow())
				draw.SimpleText("FIN DANS " .. fmtHMS(left), "Bebas Neue:22", w / 2, gRespY(536), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		-- Sous le titre, au-dessus du prix : assez de hauteur pour cadrer un hat
		-- sans coller le bord haut de la carte.
		attachModel(card, lot.item_id, 50, 95, 440, 310)

		local lpSid = IsValid(LocalPlayer()) and tostring(LocalPlayer():SteamID64() or "") or ""
		local amLeading = (not closed) and lpSid ~= "" and tostring(lot.bidder_sid or "") == lpSid
		if amLeading then
			local wait = vgui.Create("DPanel", card)
			wait:gSetPos(70, 580)
			wait:gSetSize(400, 100)
			wait.Paint = function(_, w, h)
				draw.SimpleText("TU ES EN TÊTE", "Bebas Neue:28", w / 2, h / 2 - gRespY(10), COL_OK, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("Tu pourras surenchérir si quelqu'un te dépasse.", "Avenir Next World:15", w / 2, h / 2 + gRespY(18), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		elseif not closed then
			local rowX, rowW, bh, gap = 70, 400, 42, 14
			local bw = math.floor((rowW - gap * 2) / 3)
			local by = 580
			local incs = { 100, 500, 1000 }
			for k = 1, 3 do
				local inc = incs[k]
				local b = makeIncBtn(card, "+" .. inc, function()
					local base = EVO_Encheres.DisplayedPrice(lot)
					local nxt = math.max(EVO_Encheres.MinNextTotal(lot), base + inc)
					sendBid(lot.slot, nxt)
				end)
				b:gSetPos(rowX + (k - 1) * (bw + gap), by)
				b:gSetSize(bw, bh)
			end

			local entry = vgui.Create("DTextEntry", card)
			entry:gSetPos(rowX, 640)
			entry:gSetSize(rowW - gap - 126, bh)
			entry:SetNumeric(true)
			entry:SetDrawLanguageID(false)
			entry.Paint = function(s, w, h)
				surface.SetDrawColor(22, 23, 28, 240)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(ColorAlpha(COL_GOLD, 120))
				surface.DrawOutlinedRect(0, 0, w, h, 1)
				s:DrawTextEntryText(COL_TITLE, COL_GOLD, COL_TITLE)
				if s:GetValue() == "" and not s:IsEditing() then
					draw.SimpleText("Mise totale", "Avenir Next World:16", 12, h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end

			local go = makeIncBtn(card, "OK", function()
				local v = math.floor(tonumber(entry:GetValue()) or 0)
				sendBid(lot.slot, v)
			end)
			go:gSetPos(rowX + rowW - 126, 640)
			go:gSetSize(126, bh)
		end
	end
end

vgui.Register("LZY:Shop:Encheres", PANEL, "DPanel")
