-- "addons\\evo_encheres\\lua\\evo_encheres\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ENCHÈRES — constantes partagées, horloge Paris (DST), serialize net.
-- ============================================================================

EVO_Encheres = EVO_Encheres or {}

EVO_Encheres.MAX_LOTS = 3
EVO_Encheres.OVERTIME = 30
EVO_Encheres.CLOSE_HOUR = 22
EVO_Encheres.CLOSE_MIN = 30
EVO_Encheres.BID_RATE = 0.4
EVO_Encheres.MAX_QUEUE = 12
EVO_Encheres.MAX_BID = 10000000
EVO_Encheres.MAX_ITEM_ID = 64

EVO_Encheres.PHASE_CLOSED = 0
EVO_Encheres.PHASE_EMPTY = 1
EVO_Encheres.PHASE_LIVE = 2
EVO_Encheres.PHASE_OVERTIME = 3
EVO_Encheres.PHASE_DONE = 4

EVO_Encheres.ST_OPEN = 0
EVO_Encheres.ST_SOLD = 1
EVO_Encheres.ST_UNSOLD = 2

local STATUS_TO_NET = {
	open = 0,
	sold = 1,
	unsold = 2,
}
local NET_TO_STATUS = {
	[0] = "open",
	[1] = "sold",
	[2] = "unsold",
}

-- UTC -> Paris : +1 hiver / +2 été. Bascule dernier dimanche mars / octobre 01:00 UTC.
function EVO_Encheres.ParisUTCOffset()
	local u = os.date("!*t")
	local m = u.month
	if m < 3 or m > 10 then return 1 end
	if m > 3 and m < 10 then return 2 end
	local wday31 = ((u.wday - 1 + (31 - u.day)) % 7) + 1
	local lastSunday = 32 - wday31
	local afterSwitch = (u.day > lastSunday) or (u.day == lastSunday and u.hour >= 1)
	if m == 3 then return afterSwitch and 2 or 1 end
	return afterSwitch and 1 or 2
end

local function daysInMonth(y, m)
	local d = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
	if m == 2 and (y % 4 == 0) and ((y % 100 ~= 0) or (y % 400 == 0)) then
		return 29
	end
	return d[m] or 30
end

--- Horloge civile Paris (indépendante du fuseau de l'OS).
function EVO_Encheres.ParisClock()
	local u = os.date("!*t")
	local hour = u.hour + EVO_Encheres.ParisUTCOffset()
	local day, month, year, wday = u.day, u.month, u.year, u.wday
	if hour >= 24 then
		hour = hour - 24
		day = day + 1
		wday = (wday % 7) + 1
		local dim = daysInMonth(year, month)
		if day > dim then
			day = 1
			month = month + 1
			if month > 12 then
				month = 1
				year = year + 1
			end
		end
	end
	return {
		year = year,
		month = month,
		day = day,
		hour = hour,
		min = u.min,
		sec = u.sec,
		wday = wday,
	}
end

function EVO_Encheres.IsFriday(p)
	p = p or EVO_Encheres.ParisClock()
	return p.wday == 6
end

function EVO_Encheres.FridayDate(p)
	p = p or EVO_Encheres.ParisClock()
	return string.format("%04d-%02d-%02d", p.year, p.month, p.day)
end

function EVO_Encheres.IsPastClose(p)
	p = p or EVO_Encheres.ParisClock()
	if p.hour > EVO_Encheres.CLOSE_HOUR then return true end
	if p.hour == EVO_Encheres.CLOSE_HOUR and p.min >= EVO_Encheres.CLOSE_MIN then return true end
	return false
end

function EVO_Encheres.SecondsUntilClose(p)
	p = p or EVO_Encheres.ParisClock()
	if p.wday ~= 6 then return 0 end
	local nowS = p.hour * 3600 + p.min * 60 + p.sec
	local closeS = EVO_Encheres.CLOSE_HOUR * 3600 + EVO_Encheres.CLOSE_MIN * 60
	return math.max(0, closeS - nowS)
end

--- Secondes jusqu'au prochain vendredi 00:00 Paris.
function EVO_Encheres.SecondsUntilNextOpen(p)
	p = p or EVO_Encheres.ParisClock()
	local secsInto = p.hour * 3600 + p.min * 60 + p.sec
	if p.wday == 6 then
		return (7 * 86400) - secsInto
	end
	local days = (6 - p.wday) % 7
	if days == 0 then days = 7 end
	return days * 86400 - secsInto
end

function EVO_Encheres.CleanItemId(s)
	s = tostring(s or "")
	s = string.sub(s, 1, EVO_Encheres.MAX_ITEM_ID)
	if s == "" or not string.match(s, "^[%w_%-]+$") then return "" end
	return s
end

function EVO_Encheres.ClampBid(n)
	n = math.floor(tonumber(n) or 0)
	if n < 0 then return 0 end
	if n > EVO_Encheres.MAX_BID then return EVO_Encheres.MAX_BID end
	return n
end

function EVO_Encheres.DisplayedPrice(lot)
	if not lot then return 0 end
	local bid = tonumber(lot.current_bid) or 0
	local start = tonumber(lot.start_price) or 0
	if isstring(lot.bidder_sid) and lot.bidder_sid ~= "" then
		return bid
	end
	return start
end

function EVO_Encheres.MinNextTotal(lot)
	return EVO_Encheres.DisplayedPrice(lot) + 1
end

function EVO_Encheres.WriteLot(lot)
	net.WriteUInt(tonumber(lot.slot) or 1, 2)
	net.WriteString(tostring(lot.item_id or ""))
	net.WriteUInt(EVO_Encheres.ClampBid(lot.start_price), 32)
	net.WriteUInt(EVO_Encheres.ClampBid(lot.current_bid), 32)
	net.WriteString(tostring(lot.bidder_sid or ""))
	net.WriteString(string.sub(tostring(lot.bidder_name or ""), 1, 48))
	net.WriteUInt(math.max(0, math.floor(tonumber(lot.overtime_end) or 0)), 32)
	net.WriteUInt(STATUS_TO_NET[lot.status] or 0, 2)
end

function EVO_Encheres.ReadLot()
	return {
		slot = net.ReadUInt(2),
		item_id = net.ReadString() or "",
		start_price = net.ReadUInt(32),
		current_bid = net.ReadUInt(32),
		bidder_sid = net.ReadString() or "",
		bidder_name = net.ReadString() or "",
		overtime_end = net.ReadUInt(32),
		status = NET_TO_STATUS[net.ReadUInt(2)] or "open",
	}
end

function EVO_Encheres.StatusNet(status)
	return STATUS_TO_NET[status] or 0
end
