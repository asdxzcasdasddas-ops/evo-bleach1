-- "addons\\evo_encheres\\lua\\evo_encheres\\cl_admin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ENCHÈRES — overlay superadmin : file des prochaines ventes (1–3 lots).
-- ============================================================================

local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_GOLD   = Color(255, 205, 60)
local COL_ACCENT = Color(207, 68, 78)
local COL_OK     = Color(78, 196, 128)

EVO_Encheres = EVO_Encheres or {}
EVO_Encheres.AdminQueue = EVO_Encheres.AdminQueue or {}

local adminFrame
local pickerFrame

local function itemDef(id)
	return (ITEMS and ITEMS[id]) or nil
end

local function itemName(id)
	local it = itemDef(id)
	if it and isstring(it.name) and it.name ~= "" then return it.name end
	return id ~= "" and id or "—"
end

local function canAuctionItem(id, it)
	if not isstring(id) or id == "" then return false end
	if not it then return false end
	if it.requires_instance_key then return false end
	return true
end

local function collectItems(query)
	query = string.lower(tostring(query or ""))
	local out = {}
	if not ITEMS then return out end
	for id, it in pairs(ITEMS) do
		if canAuctionItem(id, it) then
			local name = string.lower(it.name or id)
			if query == "" or string.find(name, query, 1, true) or string.find(string.lower(id), query, 1, true) then
				out[#out + 1] = { id = id, name = it.name or id }
			end
		end
	end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

local function paintCut(x, y, w, h, col)
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, w, h, col, 8, "br")
	else
		surface.SetDrawColor(col)
		surface.DrawRect(x, y, w, h)
	end
end

local function makeBtn(parent, label, col, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b._label = label
	b._col = col or COL_ACCENT
	b.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 8)) or (s:IsHovered() and 1 or 0)
		paintCut(0, 0, w, h, Color(s._col.r, s._col.g, s._col.b, 40 + 80 * hf))
		surface.SetDrawColor(ColorAlpha(s._col, 180))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(s._label, "Bebas Neue:20", w / 2, h / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		if fn then fn() end
	end
	return b
end

local function closePicker()
	if IsValid(pickerFrame) then pickerFrame:Remove() end
	pickerFrame = nil
end

local function openPicker(onPick)
	closePicker()
	local f = vgui.Create("DFrame")
	pickerFrame = f
	f:SetSize(math.min(720, ScrW() - 40), math.min(820, ScrH() - 40))
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	f.Paint = function(_, w, h)
		surface.SetDrawColor(14, 14, 17, 250)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_GOLD)
		surface.DrawRect(0, 0, w, 3)
		draw.SimpleText("CHOISIR UN ITEM", "Bebas Neue:28", 20, 16, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end

	local closeB = vgui.Create("DButton", f)
	closeB:SetText("")
	closeB:SetSize(36, 36)
	closeB.Paint = function(s, w, h)
		draw.SimpleText("×", "Bebas Neue:28", w / 2, h / 2 - 2, s:IsHovered() and COL_GOLD or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeB.DoClick = function() f:Close() end

	local search = vgui.Create("DTextEntry", f)
	search:SetTall(36)
	search:SetUpdateOnType(true)
	search:SetDrawLanguageID(false)
	search.Paint = function(s, w, h)
		surface.SetDrawColor(28, 28, 33)
		surface.DrawRect(0, 0, w, h)
		s:DrawTextEntryText(COL_TITLE, COL_GOLD, COL_TITLE)
		if s:GetValue() == "" and not s:IsEditing() then
			draw.SimpleText("Rechercher…", "Avenir Next World:16", 10, h / 2, Color(110, 113, 122), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local scroll = vgui.Create("DScrollPanel", f)
	local list = vgui.Create("DIconLayout", scroll)
	list:Dock(FILL)
	list:SetSpaceY(2)

	f.PerformLayout = function(_, w, h)
		closeB:SetPos(w - 44, 10)
		search:SetPos(20, 56)
		search:SetWide(w - 40)
		scroll:SetPos(20, 100)
		scroll:SetSize(w - 40, h - 120)
	end

	local function rebuild(q)
		list:Clear()
		local rows = collectItems(q)
		local cap = math.min(#rows, 400)
		for i = 1, cap do
			local row = rows[i]
			local b = list:Add("DButton")
			b:SetSize(math.max(200, (IsValid(f) and f:GetWide() or 720) - 64), 32)
			b:SetText("")
			b.Paint = function(s, w, h)
				surface.SetDrawColor(s:IsHovered() and Color(32, 34, 42) or Color(22, 23, 28))
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(row.name, "Avenir Next World:16", 10, h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(row.id, "Avenir Next World:13", w - 10, h / 2, COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				if onPick then onPick(row.id) end
				f:Close()
			end
		end
	end
	search.OnValueChange = function(_, val)
		rebuild(val)
	end
	rebuild("")
end

local function attachModel(parent, itemId, x, y, w, h)
	if IsValid(parent._mdlHold) then parent._mdlHold:Remove() end
	local it = itemDef(itemId)
	if not (it and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it)) then
		return
	end
	local hold = vgui.Create("DPanel", parent)
	parent._mdlHold = hold
	hold:SetPos(x, y)
	hold:SetSize(w, h)
	hold:SetMouseInputEnabled(false)
	hold.Paint = function() end
	local isAcc = it.category == "accessory"
	LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(hold, it, 30, isAcc and 0.55 or nil, nil, true)
end

function EVO_Encheres.OpenAdmin()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:IsSuperAdmin()) then return end
	if IsValid(adminFrame) then adminFrame:Remove() end
	closePicker()

	net.Start("evo_encheres.admin_sync")
	net.SendToServer()

	local f = vgui.Create("DFrame")
	adminFrame = f
	f:SetSize(math.min(1100, ScrW() - 30), math.min(860, ScrH() - 30))
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	f.sessions = {}
	f.Paint = function(_, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		end
		surface.SetDrawColor(10, 11, 14, 245)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_GOLD)
		surface.DrawRect(0, 0, w, 3)
		draw.SimpleText("GESTION ADMIN — ENCHÈRES", "Bebas Neue:32", 22, 14, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("1re ligne = prochaine vente. Vendredi sans enchère : Enregistrer l'ouvre aujourd'hui. 1 à 3 items.", "Avenir Next World:15", 24, 50, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.OnRemove = function()
		closePicker()
		if adminFrame == f then adminFrame = nil end
	end

	local closeB = vgui.Create("DButton", f)
	closeB:SetText("")
	closeB:SetSize(40, 40)
	closeB.Paint = function(s, w, h)
		draw.SimpleText("×", "Bebas Neue:30", w / 2, h / 2 - 2, s:IsHovered() and COL_GOLD or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeB.DoClick = function() f:Close() end

	local scroll = vgui.Create("DScrollPanel", f)
	f.scroll = scroll

	local function saveNow()
		local sessions = f.sessions or {}
		net.Start("evo_encheres.admin_save")
			net.WriteUInt(#sessions, 8)
			for i = 1, #sessions do
				local lots = sessions[i].lots or {}
				net.WriteUInt(#lots, 2)
				for j = 1, #lots do
					net.WriteString(lots[j].item_id or "")
					net.WriteUInt(math.floor(tonumber(lots[j].start_price) or 0), 32)
				end
			end
		net.SendToServer()
	end

	local function rebuild()
		f._needRebuild = false
		scroll:Clear()
		local sessions = f.sessions or {}
		local y = 0
		for i = 1, #sessions do
			local sess = sessions[i]
			sess.lots = sess.lots or {}
			local lotN = #sess.lots
			local h = 88 + lotN * 78
			local card = vgui.Create("DPanel", scroll)
			card:SetPos(0, y)
			card:SetSize(scroll:GetWide() - 16, h)
			card.Paint = function(_, w, hh)
				paintCut(0, 0, w, hh, Color(18, 19, 24, 240))
				draw.SimpleText("VENTE #" .. i, "Bebas Neue:22", 14, 10, COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end

			local up = makeBtn(card, "▲", COL_MUTED, function()
				if i <= 1 then return end
				sessions[i], sessions[i - 1] = sessions[i - 1], sessions[i]
				rebuild()
			end)
			up:SetPos(card:GetWide() - 220, 8)
			up:SetSize(36, 28)

			local down = makeBtn(card, "▼", COL_MUTED, function()
				if i >= #sessions then return end
				sessions[i], sessions[i + 1] = sessions[i + 1], sessions[i]
				rebuild()
			end)
			down:SetPos(card:GetWide() - 180, 8)
			down:SetSize(36, 28)

			local del = makeBtn(card, "SUPPR", COL_ACCENT, function()
				table.remove(sessions, i)
				rebuild()
			end)
			del:SetPos(card:GetWide() - 136, 8)
			del:SetSize(120, 28)

			for j = 1, lotN do
				local lot = sess.lots[j]
				local ly = 42 + (j - 1) * 78
				local row = vgui.Create("DPanel", card)
				row:SetPos(12, ly)
				row:SetSize(card:GetWide() - 24, 72)
				row.Paint = function(_, w, hh)
					surface.SetDrawColor(12, 13, 16, 220)
					surface.DrawRect(0, 0, w, hh)
					draw.SimpleText(itemName(lot.item_id), "Bebas Neue:20", 80, 10, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					draw.SimpleText(lot.item_id ~= "" and lot.item_id or "aucun item", "Avenir Next World:13", 80, 34, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					draw.SimpleText("MISE DE DÉPART", "Avenir Next World:12", w - 210, 8, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
				attachModel(row, lot.item_id, 4, 4, 64, 64)

				local pick = makeBtn(row, "ITEM", COL_GOLD, function()
					openPicker(function(id)
						lot.item_id = id
						rebuild()
					end)
				end)
				pick:SetPos(row:GetWide() - 360, 32)
				pick:SetSize(80, 28)

				local price = vgui.Create("DTextEntry", row)
				price:SetPos(row:GetWide() - 210, 28)
				price:SetSize(90, 28)
				price:SetNumeric(true)
				price:SetDrawLanguageID(false)
				price:SetValue(tostring(lot.start_price or 0))
				price.OnChange = function(s)
					lot.start_price = math.floor(tonumber(s:GetValue()) or 0)
				end

				local rm = makeBtn(row, "×", COL_ACCENT, function()
					table.remove(sess.lots, j)
					rebuild()
				end)
				rm:SetPos(row:GetWide() - 44, 22)
				rm:SetSize(32, 28)
			end

			if lotN < 3 then
				local addLot = makeBtn(card, "+ LOT", COL_OK, function()
					sess.lots[#sess.lots + 1] = { item_id = "", start_price = 0 }
					rebuild()
				end)
				addLot:SetPos(14, h - 34)
				addLot:SetSize(90, 26)
			end

			y = y + h + 10
		end
		if scroll.GetCanvas then
			local cnv = scroll:GetCanvas()
			if IsValid(cnv) then cnv:SetTall(math.max(y, 1)) end
		end
	end
	f.Rebuild = rebuild

	local addSess = makeBtn(f, "+ AJOUTER UNE ENCHÈRE", COL_OK, function()
		if #(f.sessions or {}) >= (EVO_Encheres.MAX_QUEUE or 12) then return end
		f.sessions[#f.sessions + 1] = { lots = { { item_id = "", start_price = 0 } } }
		rebuild()
	end)

	local save = makeBtn(f, "ENREGISTRER", COL_GOLD, saveNow)
	local cancelLive = makeBtn(f, "ANNULER L'ENCHÈRE", COL_ACCENT, function()
		if EVO_Encheres.RequestCancel then
			EVO_Encheres.RequestCancel()
		else
			local lp = LocalPlayer()
			if IsValid(lp) and lp.OpenYesNoPopup then
				lp:OpenYesNoPopup("Annuler l'enchère en cours ? Les mises seront rendues aux joueurs en tête.", "EvoEncheres_Cancel", {})
			else
				net.Start("evo_encheres.admin_cancel")
				net.SendToServer()
			end
		end
	end)

	f._needRebuild = true
	f.PerformLayout = function(_, w, h)
		closeB:SetPos(w - 48, 8)
		scroll:SetPos(18, 78)
		scroll:SetSize(w - 36, h - 140)
		addSess:SetPos(18, h - 50)
		addSess:SetSize(260, 36)
		cancelLive:SetPos(w - 430, h - 50)
		cancelLive:SetSize(210, 36)
		save:SetPos(w - 200, h - 50)
		save:SetSize(180, 36)
		if f._needRebuild then
			f._needRebuild = false
			rebuild()
		end
	end
end

net.Receive("evo_encheres.admin_state", function()
	local n = net.ReadUInt(8)
	local list = {}
	for i = 1, n do
		net.ReadUInt(32) -- id (server-assigned, ignored client-side)
		local nLots = net.ReadUInt(2)
		local lots = {}
		for j = 1, nLots do
			lots[j] = {
				item_id = net.ReadString() or "",
				start_price = net.ReadUInt(32),
			}
		end
		list[i] = { lots = lots }
	end
	EVO_Encheres.AdminQueue = list
	if IsValid(adminFrame) then
		adminFrame.sessions = list
		adminFrame._needRebuild = true
		if adminFrame.Rebuild then adminFrame.Rebuild() end
	end
end)
