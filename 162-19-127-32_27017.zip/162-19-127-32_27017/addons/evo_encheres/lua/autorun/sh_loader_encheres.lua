-- "addons\\evo_encheres\\lua\\autorun\\sh_loader_encheres.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ENCHÈRES — vente aux enchères du vendredi (EVO Coins, lots inventaire).
-- Entrée boutique : carte sous Reroll. État partagé Seireitei / Hueco (MySQL).
-- ============================================================================

EVO_Encheres = EVO_Encheres or {}

if SERVER then
	AddCSLuaFile("evo_encheres/sh_config.lua")
	AddCSLuaFile("evo_encheres/cl_menu.lua")
	AddCSLuaFile("evo_encheres/cl_admin.lua")

	util.AddNetworkString("evo_encheres.sync")
	util.AddNetworkString("evo_encheres.unwatch")
	util.AddNetworkString("evo_encheres.state")
	util.AddNetworkString("evo_encheres.bid")
	util.AddNetworkString("evo_encheres.result")
	util.AddNetworkString("evo_encheres.admin_sync")
	util.AddNetworkString("evo_encheres.admin_state")
	util.AddNetworkString("evo_encheres.admin_save")
	util.AddNetworkString("evo_encheres.admin_cancel")
end

include("evo_encheres/sh_config.lua")

if SERVER then
	include("evo_encheres/sv_main.lua")
else
	include("evo_encheres/cl_admin.lua")
	include("evo_encheres/cl_menu.lua")
end
