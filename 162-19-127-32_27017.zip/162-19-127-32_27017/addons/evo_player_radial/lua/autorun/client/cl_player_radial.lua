-- "addons\\evo_player_radial\\lua\\autorun\\client\\cl_player_radial.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PLAYER RADIAL — menu RADIAL sur un joueur en MAINTENANT E (user 07/23).
-- Vise un joueur proche + maintiens E 1 s : un ANNEAU DE CHARGEMENT se
-- remplit au réticule ; au bout du maintien, 3 icônes RONDES apparaissent
-- autour du joueur : PORTER (haut) / SE PRÉSENTER (bas-gauche) / DONNER DE
-- L'ARGENT (bas-droite). Au survol, l'icône S'AGRANDIT (anim lissée) et le
-- libellé COMPLET apparaît en grand (rien d'écrit hors survol — demande user
-- 07/23 v2 : ronds plus petits + hover agrandi + libellé complet + hold 1 s
-- avec mini chargement).
-- Chaque icône déclenche l'action du PROPERTY MENU existante (mêmes ids que le
-- menu C : "carry" / "presentation" / "giveMoney") via
-- MUGEN.PropertyMenu:SendAction -> AUCUNE logique serveur nouvelle, toutes les
-- revalidations (distance, busy, débit atomique) restent celles du menu C.
-- Une action dont CanRun est faux (trop loin, occupé...) est GRISÉE.
-- Fermeture : clic hors icônes ou Échap (pas de toggle E — sous MakePopup,
-- IsButtonDown blippe pendant les hitchs prod et refermait la roue aussitôt).
-- ============================================================================

if not CLIENT then return end

local HOLD_TIME    = 1.0           -- s de maintien de E avant ouverture (avec anneau de charge)
-- Portée d'ouverture : PROCHE / face-à-face (07/24, user « on peut le faire de super
-- loin ») — 150 u, comme le « Se présenter » du property menu. Les actions se
-- re-gatent ensuite chacune à leur propre portée (carry 100 u, argent 300 u serveur).
local MAX_DIST     = 150
local MAX_DIST_SQR = MAX_DIST * MAX_DIST
local REOPEN_CD    = 0.4           -- anti réouverture immédiate après fermeture
-- Graces dimensionnées pour un serveur PEUPLÉ (08/30) : un hitch y dure couramment
-- 300-500 ms sur UNE frame ; à 0.25/0.15 s une seule frame de retard suffisait à
-- dépasser la grace et à remettre tout le maintien à zéro — d'où « avec du monde,
-- la roue ne s'ouvre jamais ».
local AIM_GRACE    = 0.45          -- perte de visée tolérée sans perdre le maintien
local KEY_GRACE    = 0.45          -- blip de lecture de E toléré (hitch) sans annuler

-- Actions du property menu (id) + placement radial (direction unitaire écran).
local ACTIONS = {
	{ id = "carry",        label = "PORTER",             dx =  0,     dy = -1   },
	{ id = "presentation", label = "SE PRÉSENTER",       dx = -0.866, dy = 0.5  },
	{ id = "giveMoney",    label = "DONNER DE L'ARGENT", dx =  0.866, dy = 0.5  },
}

-- ── STYLE MÉDAILLON (demande user 07/24 : ronds plus PETITS, plus BEAUX/
-- designés, avec du DÉTAIL dedans — icône vectorielle). Chaque rond = ombre
-- douce + face sombre + fin liseré (net accent au survol) + GLYPHE vectoriel
-- AA (RNDX). Rendu uniquement quand le menu est ouvert (popup transitoire).
local COL_FACE     = Color(19, 19, 24, 244)    -- face du médaillon (dispo)
local COL_FACE_H   = Color(30, 30, 38, 248)    -- survol : légèrement éclairci
local COL_FACE_DIM = Color(17, 17, 21, 165)    -- action indisponible
local COL_EDGE     = Color(255, 255, 255, 26)  -- fin liseré interne (définition, toujours)
local COL_TXT      = Color(238, 239, 243, 255)
local COL_DIM      = Color(140, 143, 150, 150) -- glyphe indisponible
local COL_SHADOW   = Color(0, 0, 0, 42)         -- calque d'ombre douce (empilé)
local COL_ACCENT   = Color(207, 68, 78, 255)
local COL_OUTLINE  = Color(207, 68, 78, 0)     -- liseré de survol (alpha MUTÉ)
local COL_RING_BG  = Color(0, 0, 0, 140)       -- fond de l'anneau de chargement (hold)

local function S(v) return math.Round(v * (ScrH() / 1080)) end

local function makeFonts()
	surface.CreateFont("EVO_PRadial_Label", { font = "Bebas Neue", size = S(28), weight = 500, antialias = true })
	surface.CreateFont("EVO_PRadial_Yen",   { font = "Roboto",     size = S(14), weight = 800, antialias = true })
	surface.CreateFont("EVO_PRadial_E",     { font = "Bebas Neue", size = S(19), weight = 600, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO_PRadial::Fonts", makeFonts)

local pRadial
local closedAt = 0

local function drawCircle(cx, cy, r, col)
	if RNDX and RNDX.DrawCircle then
		RNDX.DrawCircle(cx, cy, r * 2, col)
		return
	end
	draw.RoundedBox(r, cx - r, cy - r, r * 2, r * 2, col) -- fallback (coins pleins ronds)
end

-- ── GLYPHES VECTORIELS AA (RNDX) — style CONTOUR/LIGNE (07/24 : les aplats
-- pleins faisaient des « ronds blancs »). Fins traits blancs sur la face
-- sombre. s = "unité" du glyphe (≈ rayon du rond × 0.5).
local NO_TOP = (RNDX and RNDX.NO_TL and RNDX.NO_TR) and (RNDX.NO_TL + RNDX.NO_TR) or 0
local function iconPerson(cx, cy, s, col)                             -- silhouette (contour)
	local t = math.max(1, S(1.5))
	RNDX.DrawCircleOutlined(cx, cy - s * 0.7, s * 0.9, col, t)        -- tête (anneau)
	local bw, bh = s * 1.75, s * 1.2
	RNDX.DrawOutlined(s * 0.58, cx - bw / 2, cy + s * 0.08, bw, bh, col, t, NO_TOP) -- épaules
end
local function iconSpeech(cx, cy, s, col)                             -- bulle de dialogue (contour)
	local t = math.max(1, S(1.5))
	local bw, bh = s * 2.0, s * 1.45
	RNDX.DrawOutlined(s * 0.5, cx - bw / 2, cy - bh * 0.62, bw, bh, col, t)
	draw.NoTexture() surface.SetDrawColor(col)                        -- petite queue bas-gauche
	surface.DrawPoly({
		{ x = cx - bw * 0.12, y = cy + bh * 0.30 },
		{ x = cx + bw * 0.04, y = cy + bh * 0.30 },
		{ x = cx - bw * 0.24, y = cy + bh * 0.66 },
	})
end
local function iconCoin(cx, cy, s, col)                               -- image ARGENT (celle de partout)
	-- Plus d'anneau dessiné (07/24 : faisait un rond différent des 2 autres) :
	-- l'icône argent officielle `MUGEN.MoneyIcon`, centrée, teintée par `col`
	-- (near-blanc = couleurs naturelles ; gris/alpha réduit = grisée si indispo).
	if MUGEN and MUGEN.MoneyIcon then
		local d = s * 2.9
		surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
		surface.SetMaterial(MUGEN.MoneyIcon)
		surface.DrawTexturedRect(cx - d / 2, cy - d / 2, d, d)
	else
		draw.SimpleText("¥", "EVO_PRadial_Yen", cx, cy, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end
local ICON_DRAW = { carry = iconPerson, presentation = iconSpeech, giveMoney = iconCoin }

-- DISQUE qui se REMPLIT en horloge (pie) : éventail de triangles centre->bord,
-- de -90° (haut) dans le sens horaire, sur `frac` du tour. Remplit un DISQUE
-- PLEIN (pas un anneau) — demande user 07/24.
local function drawPieDisc(cx, cy, r, frac, col)
	frac = math.Clamp(frac, 0, 1)
	if frac <= 0 then return end
	local segs = math.max(3, math.ceil(64 * frac))
	surface.SetDrawColor(col)
	draw.NoTexture()
	local a0 = -90
	for i = 0, segs - 1 do
		local aA = math.rad(a0 + frac * 360 * (i / segs))
		local aB = math.rad(a0 + frac * 360 * ((i + 1) / segs))
		surface.DrawPoly({
			{ x = cx, y = cy },
			{ x = cx + math.cos(aA) * r, y = cy + math.sin(aA) * r },
			{ x = cx + math.cos(aB) * r, y = cy + math.sin(aB) * r },
		})
	end
end

local function OpenRadial(target)
	if IsValid(pRadial) then pRadial:Remove() end
	if not IsValid(target) then return end

	local frame = vgui.Create("DFrame")
	pRadial = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.OnRemove = function() closedAt = RealTime() end

	-- Ronds PETITS par défaut, agrandis au survol (anim lissée par frame).
	local RADIUS, BTN_R = S(70), S(13)
	local HOVER_GROW = 1.4 -- rayon x1.4 au survol
	local lp = LocalPlayer()

	-- hoverFrac par action (0..1, lissé) -> taille + alpha du libellé complet.
	local tHover = { 0, 0, 0 }
	local tCenters = {}

	frame.Paint = function(_, w, h)
		if not IsValid(target) or not target:Alive() or target:GetEvoNWBool("EVO_IsKO", false)
			or lp:GetPos():DistToSqr(target:GetPos()) > MAX_DIST_SQR * 1.7 then
			frame:Remove() -- cible partie / morte / à terre / trop loin -> on referme
			return
		end
		-- Ancrage = CENTRE DU CORPS (demande user 07/24 : « au centre du joueur, pas la
		-- tête »). Milieu vertical des bornes de RENDU -> juste pour tout modèle/scale
		-- (character creator compris), x/y = axe du joueur.
		local _rmn, _rmx = target:GetRenderBounds()
		local scr = (target:GetPos() + Vector(0, 0, (_rmn.z + _rmx.z) * 0.5)):ToScreen()
		local cx = scr.visible and scr.x or (w * 0.5)
		local cy = scr.visible and scr.y or (h * 0.5)

		local mx, my = gui.MouseX(), gui.MouseY()
		local ft = FrameTime()
		-- Liseré accent quasi-fixe au survol (respiration très légère, clean).
		local nOutline = 215 + 25 * math.sin(CurTime() * 3)
		for i, a in ipairs(ACTIONS) do
			local bx, by = cx + a.dx * RADIUS, cy + a.dy * RADIUS
			tCenters[i] = { x = bx, y = by }
			-- Dispo ? (CanRun CLIENT du property menu : distance/busy — revalidé serveur.)
			local act = MUGEN and MUGEN.Config and MUGEN.Config.PropertyMenu
				and MUGEN.Config.PropertyMenu.Actions and MUGEN.Config.PropertyMenu.Actions[a.id]
			local bCan = act and act.CanRun and act.CanRun(lp, target) or false

			-- Hover : zone = rayon AGRANDI (pas d'effet yoyo au bord), anim lissée.
			local rNow = BTN_R * (1 + (HOVER_GROW - 1) * tHover[i])
			local bHover = bCan and ((mx - bx) ^ 2 + (my - by) ^ 2) <= (rNow + S(4)) ^ 2
			tHover[i] = math.Approach(tHover[i], bHover and 1 or 0, ft * 8)
			rNow = BTN_R * (1 + (HOVER_GROW - 1) * tHover[i])

			-- 1) Ombre douce (3 calques empilés + décalés bas = flou pauvre mais propre).
			drawCircle(bx, by + S(3), rNow + S(2), COL_SHADOW)
			drawCircle(bx, by + S(2), rNow + S(1), COL_SHADOW)
			-- 2) Face du médaillon.
			drawCircle(bx, by, rNow, bCan and (tHover[i] > 0.5 and COL_FACE_H or COL_FACE) or COL_FACE_DIM)
			-- 3) Fin liseré interne TOUJOURS présent (définition du bord = « designé »).
			if RNDX and RNDX.DrawCircleOutlined then
				RNDX.DrawCircleOutlined(bx, by, rNow * 2 - S(1), COL_EDGE, S(1))
			end
			-- 4) Liseré accent qui monte au survol (alpha mutée -> 0 alloc/frame).
			if tHover[i] > 0.01 and RNDX and RNDX.DrawCircleOutlined then
				COL_OUTLINE.a = math.floor(nOutline * tHover[i])
				RNDX.DrawCircleOutlined(bx, by, rNow * 2, COL_OUTLINE, S(2))
			end
			-- 5) GLYPHE vectoriel centré (le « détail dans le rond »).
			local fIcon = ICON_DRAW[a.id]
			if fIcon then fIcon(bx, by, rNow * 0.5, bCan and COL_TXT or COL_DIM) end
			-- 6) LIBELLÉ COMPLET : n'apparaît qu'au survol (fondu + suit le rond).
			if tHover[i] > 0.02 then
				local nA = math.floor(255 * tHover[i])
				draw.SimpleTextOutlined(a.label, "EVO_PRadial_Label", bx, by + rNow + S(11),
					ColorAlpha(bCan and COL_TXT or COL_DIM, nA), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP,
					1, ColorAlpha(color_black, math.floor(230 * tHover[i])))
			end
		end
	end

	-- Clic : sur une icône -> action property menu ; ailleurs -> fermer.
	frame.OnMousePressed = function(_, code)
		if code ~= MOUSE_LEFT then frame:Remove() return end
		local mx, my = gui.MouseX(), gui.MouseY()
		for i, a in ipairs(ACTIONS) do
			local c = tCenters[i]
			local rHit = BTN_R * (1 + (HOVER_GROW - 1) * (tHover[i] or 0)) + S(4)
			if c and ((mx - c.x) ^ 2 + (my - c.y) ^ 2) <= rHit * rHit then
				-- L'icone GRISEE n'envoie plus rien. Avant, un clic dessus partait quand
				-- meme : le serveur refusait et laissait une trace, alors que le client
				-- savait deja que l'action etait indisponible. Le menu s'ouvre a 150 u
				-- mais « porter » exige 100 u, donc l'ecart produisait un refus a chaque
				-- clic dans cette bande — d'ou des pages de [PropertyMenu][REFUS] carry.
				local act = MUGEN and MUGEN.Config and MUGEN.Config.PropertyMenu
					and MUGEN.Config.PropertyMenu.Actions and MUGEN.Config.PropertyMenu.Actions[a.id]
				local bCan = act and act.CanRun and act.CanRun(LocalPlayer(), target) or false
				if bCan and IsValid(target) and MUGEN and MUGEN.PropertyMenu and MUGEN.PropertyMenu.SendAction then
					-- Même canal que le menu C : Run CLIENT (CanRun compris) + net serveur.
					MUGEN.PropertyMenu:SendAction({ id = a.id }, target)
				end
				frame:Remove()
				return
			end
		end
		frame:Remove()
	end
end

-- ── DÉTECTION = MÊME LOGIQUE QUE LE MENU C (08/31, demande user — après la Nième
-- panne « je ne vois pas l'UI »). Les DEUX écarts qui tuaient le radial :
--   1. VISÉE CAMÉRA, pas tête du perso. Le serveur joue en caméra ORBITALE épaule :
--      l'œil du personnage et la caméra ne sont pas au même endroit, et à 150 u la
--      parallaxe suffisait à rater le joueur pourtant AU RÉTICULE, selon le côté de
--      la caméra. Le menu C trace depuis EyePos() de RENDU capturé chaque frame
--      (cl_property_menu) — capture identique ici.
--   2. REMONTÉE AU PORTEUR. Les joueurs traînent des entités attachées (katana
--      rengainé, pets d'épaule, accessoires) qui MANGENT les traces — d'autant plus
--      souvent qu'il y a du monde. Le menu C résout le parent (ResolveToTarget) ;
--      le radial, lui, jetait tout ce qui n'était pas un joueur.
-- Trois passes comme le menu C : ligne MASK_SHOT -> hull MASK_SHOT_HULL -> rayon vs
-- boîte de RENDU (le visuel réel). Portée mesurée du PERSONNAGE (150 u), occlusion
-- monde multi-hauteurs depuis la caméra (ce qu'on voit est ce qu'on vise).
local function rayAABB(o, d, mn, mx)                 -- t d'entrée (>=0) ou nil
	local tmin, tmax = 0, math.huge
	for _, ax in ipairs({ "x", "y", "z" }) do
		local oo, dd = o[ax], d[ax]
		if math.abs(dd) < 1e-9 then
			if oo < mn[ax] or oo > mx[ax] then return nil end
		else
			local t1, t2 = (mn[ax] - oo) / dd, (mx[ax] - oo) / dd
			if t1 > t2 then t1, t2 = t2, t1 end
			if t1 > tmin then tmin = t1 end
			if t2 < tmax then tmax = t2 end
			if tmin > tmax then return nil end
		end
	end
	if tmax < 0 then return nil end
	return tmin
end

local BODY_MARGIN = 4
local OCC_HEIGHTS = { 56, 36, 16 } -- hauteurs testées pour l'occlusion (torse haut / torse / bas)
local CAM_REACH   = MAX_DIST * 2 + 200 -- rayon caméra : la caméra orbitale est ~120 u derrière le perso

-- Rayon de VISÉE = la caméra de rendu, capturée chaque frame (même patron que
-- cl_property_menu : PreDrawEffects -> position/direction du RENDU).
local vCamPos, vCamDir = Vector(0, 0, 0), Vector(1, 0, 0)
hook.Add("PreDrawEffects", "EVO_PRadial::CamRay", function()
	vCamPos = EyePos()
	vCamDir = EyeVector()
end)

-- Remonte au PORTEUR (miroir de ResolveToTarget du menu C) + gates du radial :
-- joueur vivant, pas soi, à PORTÉE DU PERSONNAGE (pas de la caméra).
local function ResolvePlayer(ent, lp)
	if not IsValid(ent) then return nil end
	if not ent:IsPlayer() then
		local parent = ent:GetParent()
		if not IsValid(parent) then return nil end
		ent = parent
	end
	if not (ent:IsPlayer() and ent:Alive() and ent ~= lp) then return nil end
	if lp:GetPos():DistToSqr(ent:GetPos()) > MAX_DIST_SQR then return nil end
	return ent
end

local function findAimedPlayer(lp)
	local eye, dir = vCamPos, vCamDir
	-- Pass 1 : ligne MASK_SHOT (hitboxes du modèle) + remontée au porteur.
	local tr = util.TraceLine({ start = eye, endpos = eye + dir * CAM_REACH, filter = lp, mask = MASK_SHOT })
	local ent = ResolvePlayer(tr.Entity, lp)
	-- Pass 2 : hull 16 u MASK_SHOT_HULL (bbox de collision, indépendant des hitboxes).
	if not ent then
		local tr2 = util.TraceHull({ start = eye, endpos = eye + dir * CAM_REACH,
			mins = Vector(-8, -8, -8), maxs = Vector(8, 8, 8), filter = lp, mask = MASK_SHOT_HULL })
		ent = ResolvePlayer(tr2.Entity, lp)
	end
	-- Pass 3 : rayon caméra vs boîte de RENDU de chaque joueur proche (garanti, sans hitbox).
	if not ent then
		local best, bestT
		for _, cand in ipairs(ents.FindInSphere(lp:GetPos(), MAX_DIST)) do
			if cand ~= lp and cand:IsPlayer() and cand:Alive() then
				local rmn, rmx = cand:GetRenderBounds()
				local o = cand:GetPos()
				local ext = math.max(math.abs(rmn.x), math.abs(rmx.x), math.abs(rmn.y), math.abs(rmx.y)) + BODY_MARGIN
				local t = rayAABB(eye, dir, Vector(o.x - ext, o.y - ext, o.z + rmn.z), Vector(o.x + ext, o.y + ext, o.z + rmx.z))
				if t and (not bestT or t < bestT) then best, bestT = cand, t end
			end
		end
		ent = best
	end
	-- Occlusion MONDE multi-hauteurs depuis la CAMÉRA : un joueur derrière un mur
	-- n'est pas visable, mais un rebord qui coupe UNE seule ligne ne fait pas perdre
	-- la cible (même idée que le menu C).
	if IsValid(ent) then
		local o = ent:GetPos()
		for i = 1, #OCC_HEIGHTS do
			local occ = util.TraceLine({ start = eye, endpos = Vector(o.x, o.y, o.z + OCC_HEIGHTS[i]),
				filter = { lp, ent }, mask = MASK_SOLID_BRUSHONLY })
			if not occ.Hit then return ent end
		end
	end
	return nil
end

-- La cible d'un maintien EN COURS reste-t-elle visée ? Boîte élargie (plus
-- tolérante que la détection initiale) + même occlusion multi-hauteurs.
-- MÊME RAYON CAMÉRA que la détection : sinon la cible acquise à la caméra était
-- aussitôt « perdue » par le test à la tête, et le maintien ne finissait jamais.
local function stillAimed(lp, ply)
	if not (IsValid(ply) and ply:IsPlayer() and ply:Alive()) then return false end
	if lp:GetPos():DistToSqr(ply:GetPos()) > MAX_DIST_SQR then return false end
	local eye, dir = vCamPos, vCamDir
	local rmn, rmx = ply:GetRenderBounds()
	local o = ply:GetPos()
	local ext = math.max(math.abs(rmn.x), math.abs(rmx.x), math.abs(rmn.y), math.abs(rmx.y)) + BODY_MARGIN * 3
	if not rayAABB(eye, dir, Vector(o.x - ext, o.y - ext, o.z + rmn.z), Vector(o.x + ext, o.y + ext, o.z + rmx.z)) then return false end
	for i = 1, #OCC_HEIGHTS do
		local occ = util.TraceLine({ start = eye, endpos = Vector(o.x, o.y, o.z + OCC_HEIGHTS[i]),
			filter = { lp, ply }, mask = MASK_SOLID_BRUSHONLY })
		if not occ.Hit then return true end
	end
	return false
end

-- ── Détection du MAINTIEN de E sur un joueur (léger : traces seulement quand E est
-- enfoncé, rien sinon ; le fallback ne tourne que si la trace hull n'a rien touché) ──
local holdTarget, holdStart, holdSeenAt, keySeenAt

-- Lecture PHYSIQUE de la touche +use. Sous forte charge serveur, la prédiction se
-- fait rollback en continu et lp:KeyDown(IN_USE) reste FAUX des périodes entières
-- alors que E est réellement enfoncé (le disque, peint sur le temps, continuait de
-- se remplir : « ça charge mais rien ne s'ouvre »). input.* lit le clavier local,
-- immunisé au lag ; KeyDown reste en secours (bind introuvable).
local MOUSE_BINDS = { mouse1 = MOUSE_LEFT, mouse2 = MOUSE_RIGHT, mouse3 = MOUSE_MIDDLE, mouse4 = MOUSE_4, mouse5 = MOUSE_5 }
local nUseKey, nUseKeyAt = nil, 0
local function useDown(lp)
	if RealTime() - nUseKeyAt > 5 then -- re-résout le bind toutes les 5 s (rebind en jeu)
		nUseKeyAt = RealTime()
		local sBind = input.LookupBinding("+use")
		nUseKey = sBind and (MOUSE_BINDS[sBind] or input.GetKeyCode(sBind)) or nil
		if not nUseKey or nUseKey <= 0 then nUseKey = nil end
	end
	if nUseKey and input.IsButtonDown(nUseKey) then return true end
	return lp:KeyDown(IN_USE)
end

-- Aboutissement du maintien : appelable AUSSI pendant une grace (touche/visée
-- perdue une fraction de seconde pile à 100 % — le cas foule/lag). On ouvre sur la
-- cible MÉMORISÉE si elle est toujours vivante, à portée et DEVANT soi (cône ~60°,
-- garde le cas « demi-tour pendant la grace »). Le serveur revalide chaque action.
local function tryComplete(lp)
	if not (holdTarget and holdStart) then return false end
	if RealTime() - holdStart < HOLD_TIME then return false end
	local t = holdTarget
	if not (IsValid(t) and t:IsPlayer() and t:Alive()) or t:GetEvoNWBool("EVO_IsKO", false)
		or lp:GetPos():DistToSqr(t:GetPos()) > MAX_DIST_SQR * 1.3 then
		holdTarget, holdStart = nil, nil
		return false
	end
	-- Cone verifie sur le rayon CAMERA (pas la tete du perso) : en camera orbitale
	-- epaule, le test tete/GetAimVector pouvait echouer pile a 100 % du maintien
	-- alors que la cible etait AU RETICULE (meme parallaxe que la detection).
	local vTo = t:WorldSpaceCenter() - vCamPos
	vTo:Normalize()
	if vTo:Dot(vCamDir) < 0.5 then
		holdTarget, holdStart = nil, nil
		return false
	end
	holdTarget, holdStart = nil, nil
	OpenRadial(t)
	return true
end

hook.Add("Think", "EVO_PRadial::Detect", function()
	if IsValid(pRadial) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then holdTarget, holdStart = nil, nil return end

	if not useDown(lp) then
		if holdTarget and RealTime() - (keySeenAt or 0) < KEY_GRACE then
			-- Blip de touche (hitch) : le maintien peut ABOUTIR pendant la grace.
			if tryComplete(lp) then return end
			return
		end
		holdTarget, holdStart = nil, nil
		return
	end
	keySeenAt = RealTime()
	if RealTime() - closedAt < REOPEN_CD then return end
	if vgui.CursorVisible() then holdTarget, holdStart = nil, nil return end -- un menu est déjà ouvert
	if lp:GetEvoNWBool("InCharacterMenu", false) then holdTarget, holdStart = nil, nil return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then holdTarget, holdStart = nil, nil return end -- E au sol = self-respawn KO

	local ent = findAimedPlayer(lp)
	-- FOULE : un joueur qui croise le faisceau vole la détection une frame, et le
	-- changement de cible relançait le maintien à zéro -> avec du monde la roue ne
	-- s'ouvrait jamais. Tant que la cible d'ORIGINE reste visée, on la garde.
	if holdTarget and ent ~= holdTarget and stillAimed(lp, holdTarget) then
		ent = holdTarget
	end
	if not (IsValid(ent) and lp:GetPos():DistToSqr(ent:GetPos()) <= MAX_DIST_SQR) then
		-- Perte BRÈVE tolérée : la détection dépend de traces qui accrochent le décor, donc
		-- elle clignote. Le maintien peut aussi ABOUTIR pendant cette grace (cas foule :
		-- la visée se perd pile quand le disque atteint 100 %).
		if holdTarget and RealTime() - (holdSeenAt or 0) < AIM_GRACE then
			if tryComplete(lp) then return end
			return
		end
		holdTarget, holdStart = nil, nil
		return
	end
	-- Cible à terre : E sert à la réanimer (ncm_ko_system), pas à ouvrir la roue.
	if ent:GetEvoNWBool("EVO_IsKO", false) then holdTarget, holdStart = nil, nil return end
	holdSeenAt = RealTime()

	-- FOULE bis : le chrono appartient au MAINTIEN DE E, pas à la cible — une bascule
	-- de cible dans un attroupement GARDE la progression, et l'aboutissement est testé
	-- dans la MÊME frame (pas de frame « parfaite » à attendre).
	if holdTarget ~= ent then
		holdTarget = ent
		holdStart = holdStart or RealTime()
	end
	tryComplete(lp)
end)

-- ── MINI CHARGEMENT pendant le maintien : petit DISQUE qui SE REMPLIT en
-- horloge au réticule (demande user 07/24 : « remplir un disque, pas le
-- cercle ») + « E » au centre. Affiché seulement pendant un maintien valide.
hook.Add("HUDPaint", "EVO_PRadial::HoldRing", function()
	if not holdTarget or IsValid(pRadial) then return end
	if not IsValid(holdTarget) then return end
	local frac = (RealTime() - (holdStart or 0)) / HOLD_TIME
	if frac <= 0.03 then return end -- micro-appuis (spam E portes/PNJ) : rien d'affiché

	local cx, cy = ScrW() * 0.5, ScrH() * 0.5 + S(52) -- juste sous le réticule
	local r = S(12) -- -20% (demande user 07/24)
	drawCircle(cx, cy, r, COL_RING_BG)                          -- disque de fond sombre
	drawPieDisc(cx, cy, r, math.min(frac, 1), COL_ACCENT)       -- remplissage accent (horloge)
	if RNDX and RNDX.DrawCircleOutlined then
		RNDX.DrawCircleOutlined(cx, cy, r * 2, COL_EDGE, S(1))  -- fin bord blanc (net)
	end
	draw.SimpleText("E", "EVO_PRadial_E", cx, cy, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
