-- "addons\\evo_clan\\lua\\autorun\\sh_loader_clan.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CLAN — système de CLANS FIXES (remplace evo_famille, désactivé).
-- 8 clans prédéfinis (4 Shinigami / 4 Hollow, cf sh_config), par PERSONNAGE :
--  - Les SUPERADMINS nomment/retirent le LEADER de chaque clan (UI, onglet
--    Administration).
--  - Le LEADER invite des joueurs en ligne de sa faction et peut les exclure.
--  - PAS d'XP, PAS de PNJ gestionnaire, PAS de création libre : système à part.
--  - Cap membres par clan (15). Verrou de faction (clan Shinigami = persos
--    Shinigami, etc.), revalidé serveur.
--  - L'appartenance pilote les SORTS DE CLAN (ncm_combat_system
--    sv_clan_spells : NW EVO_ClanKey + hook EVO_Clan::PlayerSynced).
-- BDD : table MySQL partagée evo_clan_members (character_uid PK).
-- ============================================================================

EVO_CLAN = EVO_CLAN or {}

if SERVER then
    AddCSLuaFile("evo_clan/sh_config.lua")
    AddCSLuaFile("evo_clan/sh_domaine.lua")
    AddCSLuaFile("evo_clan/cl_main.lua")
    AddCSLuaFile("evo_clan/cl_domaine.lua")
    AddCSLuaFile("evo_clan/cl_coffre.lua")
    AddCSLuaFile("evo_clan/cl_spells.lua")

    util.AddNetworkString("evo_clan:openui")  -- sv -> cl : ouvre le menu (commande chat)
    util.AddNetworkString("evo_clan:get")     -- cl -> sv : demande l'état (arg optionnel SA : clé de clan à inspecter)
    util.AddNetworkString("evo_clan:state")   -- sv -> cl : état complet (mon clan + roster + admin SA)
    util.AddNetworkString("evo_clan:invite")  -- cl -> sv : leader invite (entité joueur)
    util.AddNetworkString("evo_clan:invited") -- sv -> cl : popup d'invitation chez la cible
    util.AddNetworkString("evo_clan:answer")  -- cl -> sv : réponse à l'invitation (bool)
    util.AddNetworkString("evo_clan:action")  -- cl -> sv : action (create/leave/kick/pot_deposit/pot_withdraw/pot_upgrade[=niveau]/spell_request/pay_tax/rank_create/rank_update/rank_delete/rank_assign/rename/setleader/sa_setleader/sa_warn/sa_spell_decision/...)
    util.AddNetworkString("evo_clan:lb")      -- cl -> sv : demande le classement ; sv -> cl : données agrégées
    util.AddNetworkString("evo_clan:warnlist") -- cl <-> sv : liste {key,label,faction,warns} pour l'UI WARNS staff (SA only)
    -- Domaine : invitation de visiteurs (marqueur INVITER dans le domaine)
    util.AddNetworkString("evo_clan:dom_liste")   -- sv -> cl : joueurs proches de l'entree (ouvre le menu)
    util.AddNetworkString("evo_clan:dom_invite")  -- cl -> sv : steamid choisi
    util.AddNetworkString("evo_clan:dom_invited") -- sv -> cl : popup chez la cible
    util.AddNetworkString("evo_clan:dom_answer")  -- cl -> sv : reponse de la cible (bool)
    util.AddNetworkString("evo_clan:dom_slots")   -- sv -> cl : emplacements occupes (id + nom du clan)
    util.AddNetworkString("evo_clan:dom_buyui")   -- sv -> cl : ouvre la confirmation d'achat d'un emplacement
    util.AddNetworkString("evo_clan:dom_buy")     -- cl -> sv : achat confirme (id d'emplacement)
    util.AddNetworkString("evo_clan:coffre_open") -- sv -> cl : ouvre l'UI du coffre
    util.AddNetworkString("evo_clan:coffre_snap") -- sv -> cl : rafraîchit le contenu
    util.AddNetworkString("evo_clan:coffre_don")  -- cl -> sv : dépose un objet du sac
    util.AddNetworkString("evo_clan:coffre_take") -- cl -> sv : retire un objet (PERM.COFFRE)
    util.AddNetworkString("evo_clan:coffre_sort") -- cl -> sv : empile + ordre par type
    util.AddNetworkString("evo_clan:coffre_close") -- cl -> sv : UI fermée
    util.AddNetworkString("evo_clan:coffre_folder_create")
    util.AddNetworkString("evo_clan:coffre_folder_rename")
    util.AddNetworkString("evo_clan:coffre_folder_delete")
    util.AddNetworkString("evo_clan:coffre_folder_move")
end

include("evo_clan/sh_config.lua")
include("evo_clan/sh_domaine.lua")

if SERVER then
    include("evo_clan/sv_main.lua")
    include("evo_clan/sv_domaine.lua")
    include("evo_clan/sv_coffre.lua")
    include("evo_clan/sv_spells.lua")
else
    include("evo_clan/cl_main.lua")
    include("evo_clan/cl_domaine.lua")
    include("evo_clan/cl_coffre.lua")
    include("evo_clan/cl_spells.lua")
end
