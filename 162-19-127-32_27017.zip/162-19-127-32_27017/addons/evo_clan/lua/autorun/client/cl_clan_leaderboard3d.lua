-- "addons\\evo_clan\\lua\\autorun\\client\\cl_clan_leaderboard3d.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CLAN — PANNEAU 3D « CLASSEMENT DES CLANS » (2026-07-23 ; refait AUTONOME
-- le 07/24 sur demande user : « le classement clan doit être créé de la MÊME
-- manière que le classement Hollow, au niveau du code »).
--
-- AVANT : dessiné DANS la matrice 3D2D du panneau evo_leaderboard (on lisait sa
-- pose dans AUTO_SPAWN_POSITIONS et on décalait de sa largeur en X). Résultat :
-- pas de pose propre -> il ne suivait pas correctement les rotations du panneau
-- Hollow (roll/yaw), d'où « c'est pas fait pareil ».
--
-- MAINTENANT : panneau À PART ENTIÈRE, exactement comme evo_leaderboard —
-- chaque entrée EVO_CLAN.Config.LbPanels[map] = { pos, angle, scale, faction }
-- est rendue SEULE via cam.Start3D2D(pos, angle, scale). La config est shared
-- (lue client-side) ; la SEULE différence avec evo_leaderboard est l'absence
-- d'un addpos runtime (inutile ici — pas de placement live pour le clan).
--
-- Données : cache client du net "evo_clan:lb" (UN seul receiver, dans cl_main)
-- via EVO_CLAN.LbData() / EVO_CLAN.LbRequest() — agrégats serveur cachés 60 s,
-- refresh demandé au plus 1x/60 s quand un joueur est près d'un panneau.
-- ============================================================================

if not CLIENT then return end

-- ── Panneau clans (pixels 3D2D) ─────────────────────────────────────────────
-- EMPREINTE ALIGNÉE sur evo_leaderboard (2026-07-31, demande user « le tableau est
-- coupé, il doit prendre toute l'UI ») : les deux panneaux sont côte à côte sur le
-- même mur au Seireitei (3,5u d'écart), même angle, même scale — celui-ci faisait
-- LA MOITIÉ de la largeur du voisin (1150 vs 2280 px) et 32 px de moins en hauteur,
-- d'où l'effet « tronqué ». Mêmes valeurs que drawPanel d'evo_leaderboard :
-- W = 4 colonnes × (540 + 24) + 24 = 2280 ; H = 100 + 80 + 25 × 32 + 24 = 1004.
-- ROW_H est DÉRIVÉ pour que les 18 rangées remplissent exactement la hauteur.
local PANEL_W  = 2280
local PANEL_H  = 1004
local PAD      = 24
local TITLE_H  = 100
local HEAD_H   = 80
local MAX_ROWS = 18
local ROW_H    = (PANEL_H - TITLE_H - HEAD_H - PAD) / MAX_ROWS -- 44.4 px, fractions OK en 3D2D

local DRAW_DIST_SQR = 3000 * 3000

local COL_BG     = Color(10, 10, 14, 235)
local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)
local COL_STRIPE = Color(255, 255, 255, 8)
local RANK_COLS = {
	Color(224, 178, 58),  -- or
	Color(188, 194, 204), -- argent
	Color(176, 116, 66),  -- bronze
}

-- Tailles alignées sur les fontes d'evo_leaderboard (72/44/30) : même mur, même
-- densité visuelle. La rangée reste un cran au-dessus (36) car il n'y a que 18
-- rangées sur la même hauteur, contre 25 chez le voisin.
surface.CreateFont("EVO_ClanLb_Title", { font = "Bebas Neue", size = 72, weight = 400, antialias = true })
surface.CreateFont("EVO_ClanLb_Head",  { font = "Bebas Neue", size = 44, weight = 400, antialias = true })
surface.CreateFont("EVO_ClanLb_Row",   { font = "Bebas Neue", size = 36, weight = 400, antialias = true })

-- Colonnes réparties sur la largeur : le NOM garde la zone gauche (jusqu'à
-- COLS_X0), les stats se partagent le reste à parts égales — même logique que
-- lbColCenter de l'onglet CLASSEMENT du menu clan.
local COLS_X0 = 820
local COLS = {
	{ label = "MEMBRES",   fmt = function(d) return tostring(d.members or 0) end },
	{ label = "HEURES",    fmt = function(d) return string.Comma(d.hours or 0) end },
	{ label = "PNJ TUÉS",  fmt = function(d) return string.Comma(d.kills or 0) end },
	{ label = "TOURNOIS",  fmt = function(d) return tostring(d.wins or 0) end },
	{ label = "BATAILLE",  fmt = function(d) return tostring(d.battles or 0) end },
	{ label = "BANQUE",    fmt = function(d) return string.Comma(d.pot or 0) .. "¥" end },
}
local function colCenter(i)
	return COLS_X0 + (PANEL_W - COLS_X0 - PAD) * (i - 0.5) / #COLS
end

-- ── Poses AUTONOMES du panneau clan (config shared, comme evo_leaderboard) ───
local function getPanels()
	local list = EVO_CLAN and EVO_CLAN.Config and EVO_CLAN.Config.LbPanels
		and EVO_CLAN.Config.LbPanels[game.GetMap()]
	return istable(list) and list or nil
end

-- ── Lignes affichées : clans de LA faction du panneau, triés au classement
-- général (toutes les colonnes). Cache 5 s : le tri/filtre ne tourne pas par
-- frame. Un seul cache partagé par faction.
local _rows, _rowsAt, _rowsFaction = nil, 0, nil
local function getRows(sFaction)
	if _rows and _rowsFaction == sFaction and RealTime() < _rowsAt + 5 then return _rows end
	local data = EVO_CLAN.LbData and EVO_CLAN.LbData()
	local out = {}
	if istable(data) then
		for _, d in ipairs(data) do
			if d.faction == sFaction then out[#out + 1] = d end
		end
		if EVO_CLAN.SortClansOverall then EVO_CLAN.SortClansOverall(out) end
	end
	_rows, _rowsAt, _rowsFaction = out, RealTime(), sFaction
	return out
end

-- ── Dessin d'UN panneau clan dans son PROPRE 3D2D (origine = coin haut-gauche) ─
local function drawClanPanel(vPos, aAng, nScale, sFaction)
	sFaction = sFaction or "Shinigami"
	local rows = getRows(sFaction)
	local h = PANEL_H

	cam.Start3D2D(vPos, aAng, nScale or 0.15)
		draw.RoundedBox(0, 0, 0, PANEL_W, h, COL_BG)
		-- Titre + filet accent (DA).
		draw.SimpleText("CLASSEMENT DES CLANS", "EVO_ClanLb_Title", PAD, 18, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(PAD, TITLE_H - 12, PANEL_W - PAD * 2, 3)
		draw.SimpleText(string.upper(sFaction), "EVO_ClanLb_Head", PANEL_W - PAD, 30, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		-- En-têtes de colonnes.
		local headY = TITLE_H + HEAD_H * 0.5
		draw.SimpleText("CLAN", "EVO_ClanLb_Head", PAD + 56, headY, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		for i, c in ipairs(COLS) do
			draw.SimpleText(c.label, "EVO_ClanLb_Head", colCenter(i), headY, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local nShown = math.min(#rows, MAX_ROWS)
		for i = 1, nShown do
			local d = rows[i]
			local ry = TITLE_H + HEAD_H + (i - 1) * ROW_H
			if i % 2 == 0 then
				draw.RoundedBox(0, PAD * 0.5, ry, PANEL_W - PAD, ROW_H - 4, COL_STRIPE)
			end
			local rankCol = RANK_COLS[i] or COL_DIM
			draw.SimpleText(i .. ".", "EVO_ClanLb_Row", PAD + 8, ry + ROW_H * 0.5, rankCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local nm = tostring(d.label or "?")
			if #nm > 28 then nm = string.sub(nm, 1, 27) .. "…" end -- zone nom réduite (6 colonnes stats)
			draw.SimpleText(nm, "EVO_ClanLb_Row", PAD + 56, ry + ROW_H * 0.5, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			for ci, c in ipairs(COLS) do -- ci : ne pas masquer le i des rangées
				draw.SimpleText(c.fmt(d), "EVO_ClanLb_Row", colCenter(ci), ry + ROW_H * 0.5, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		if nShown == 0 then
			draw.SimpleText("Aucun clan pour le moment.", "EVO_ClanLb_Row", PANEL_W * 0.5, TITLE_H + HEAD_H + 40, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	cam.End3D2D()
end

local _nextReq = 0

hook.Add("PostDrawTranslucentRenderables", "EVO_Clan::Lb3D", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	local panels = getPanels()
	if not panels then return end

	local eye    = EyePos()
	local eyeFwd = EyeVector()
	local bReq   = false

	-- Même schéma que evo_leaderboard (cl_main) : on itère les poses, cull par
	-- distance + « derrière la caméra », et on rend chaque panneau seul.
	for _, p in ipairs(panels) do
		-- LA CONFIG PRIME (demande user 2026-07-25) : positions du sh_config (LbPanels)
		-- UNIQUEMENT — plus d'override evo_placer, le code prédomine sur le placement
		-- in-game (un override obsolète ne peut plus écraser la config).
		local pos, ang, scale = p.pos, p.angle, p.scale or 0.15
		if eye:DistToSqr(pos) <= DRAW_DIST_SQR
			and (pos - eye):GetNormalized():Dot(eyeFwd) >= -0.2 then
			-- Refresh du cache (throttlé 60 s) dès qu'AU MOINS un panneau est visible.
			if not bReq and RealTime() >= _nextReq and EVO_CLAN.LbRequest then
				_nextReq = RealTime() + 60
				EVO_CLAN.LbRequest()
				bReq = true
			end
			drawClanPanel(pos, ang, scale, p.faction)
		end
	end
end)
