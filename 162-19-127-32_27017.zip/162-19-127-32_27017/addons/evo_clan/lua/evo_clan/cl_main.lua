-- "addons\\evo_clan\\lua\\evo_clan\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CLAN — client : menu (Mon Clan / Administration SA) + popup d'invitation.
-- DA EVO (pattern menu squad / evo_famille validé) : carte centrale #0E0E11,
-- accent unique #cf444e, Bebas sans bold, rangées fines, boutons typés,
-- AUCUNE bordure grise, 100% VGUI + RNDX.
-- Ouverture : bind "famille" (menu de binds, libellé « Mon Clan »), !clan /clan,
-- concommand evo_clan_menu. Fermeture : ✕, Échap, ré-appui du bind.
-- ============================================================================

EVO_CLAN = EVO_CLAN or {}
local CFG = EVO_CLAN.Config

-- ── Palette DA ──
local COL_FOND        = Color(5, 5, 7, 216)
local COL_CARD        = Color(13, 14, 17, 250)
local COL_ROW         = Color(26, 26, 32, 255)
local COL_ROW_HOV     = Color(36, 36, 44, 255)
local COL_ACCENT      = Color(207, 68, 78, 255)
local COL_ACCENT_HOV  = Color(224, 92, 102, 255)
local COL_ACCENT_SOFT = Color(207, 68, 78, 45)
local COL_TXT         = Color(235, 235, 240, 255)
local COL_TXT_DIM     = Color(150, 150, 160, 255)
local COL_SCROLL      = Color(58, 58, 68, 220)
local COL_GREEN       = Color(78, 196, 128, 255)
local COL_OFFLINE     = Color(90, 90, 98, 255)
local COL_DROP        = Color(8, 8, 10, 252)       -- fond des listes déroulantes DA
local COL_GOLD        = Color(224, 178, 58, 255)   -- doré BRAS DROIT / dons (hoisté : 0 alloc/frame)
local COL_FIELD       = Color(12, 12, 16, 255)     -- fond des champs texte DA
local COL_PLACEHOLDER = Color(255, 255, 255, 64)   -- placeholder des champs texte

-- ── Permissions des GRADES personnalisés (bits partagés, sh_config) ──
-- st.myPerms (serveur) = bitmask EFFECTIF du joueur (leader/bras droit = tout) :
-- ne sert qu'à MONTRER les contrôles permis — le serveur revalide chaque action.
local PERM = EVO_CLAN.PERM or {}
local function hasPermC(nPerms, nBit)
	return bit.band(nPerms or 0, nBit or 0) ~= 0
end

-- Palette passée aux helpers PARTAGÉS d'EVO_UI (extraction du kit VGUI 2026-07-14 :
-- MakeBtn/StyleScrollBar/drawBrushLabel/panel_contains_cursor/truncText/foldStr
-- vivent désormais dans EVO_UI ; ici de fins délégués gardent les appels intacts).
local EVO_CLAN_PAL = {
	accent = COL_ACCENT, accentHov = COL_ACCENT_HOV,
	row = COL_ROW, rowHov = COL_ROW_HOV, txt = COL_TXT, scroll = COL_SCROLL,
}

-- Son UI custom (même clic que les autres UIs).
local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"

-- Prompt « [E] Parler … » du Doyen des Clans : DESSINÉ PAR LE SYSTÈME CENTRAL evo_npc_core
-- (même UI plaque Atelier + même logique « le plus proche affiche » que tous les autres PNJ,
-- user 2026-07-17). Le Doyen n'avait AUCUN prompt bas-écran avant (nametag seul) alors que
-- sa PromptDistance existait déjà en config.
local function findNearestDoyen()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local lpPos      = lp:GetPos()
	local promptDist = tonumber(CFG.PromptDistance) or 160
	local maxZ       = tonumber(CFG.MaxZDelta) or 200
	local promptSqr  = promptDist * promptDist
	local best, bestD = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("evo_npc_clan")) do
		if IsValid(ent) then
			local ePos = ent:GetPos()
			if math.abs(ePos.z - lpPos.z) <= maxZ then
				local d2 = ePos:DistToSqr(lpPos)
				if d2 <= promptSqr and d2 < bestD then best, bestD = ent, d2 end
			end
		end
	end
	return best
end

EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["clan_doyen"] = {
	fGetTarget = findNearestDoyen,
	fLabel = function() return "[E] Parler au " .. (CFG.NPCName or "Doyen des Clans") end,
	fSub = function() return "Menu de clan" end,
}

-- Puce brush accent devant un intitulé de section (-> EVO_UI.DrawBrushLabel).
local function drawBrushLabel(sText, sFont, y, h, col)
	EVO_UI.DrawBrushLabel(sText, sFont, y, h, col, COL_ACCENT)
end

-- ── Fontes DA Atelier (GROSSES — demande user 07/13) ──
local F_TITLE     = "Bebas Neue:46"
local F_X         = "Avenir Next World Bold:34"
local F_TAB       = "Bebas Neue:32"
local F_SUBTITLE  = "Bebas Neue:38"
local F_LABEL     = "Bebas Neue:27"
local F_ROW       = "Bebas Neue:33"
local F_ROW_SUB   = "Bebas Neue:26"
local F_HINT      = "Avenir Next World:22"
local F_BTN       = "Bebas Neue:33"
local F_BTN_SMALL = "Bebas Neue:25"

-- ── Layout (unités design 1920x1080 -> gRespX/gRespY) — carte AGRANDIE ──
local CARD_W   = 920
local CARD_H   = 860
local HEADER_H = 74
local TAB_H    = 62
local PAD      = 28

local pClan          -- frame courant
local STATE  = nil   -- dernier état reçu du serveur
local sCurTab = "clan"   -- "clan" | "grades" | "banque" | "upgrades" | "classement" | "admin"
local sInspect = ""      -- clé du clan inspecté (onglet admin)
local clanClosedAt = 0   -- anti-rebond du toggle bind

local function panel_contains_cursor(pnl)
	return EVO_UI.PanelContainsCursor(pnl)
end

local function truncText(sText, sFont, nMaxW)
	return EVO_UI.TruncText(sText, sFont, nMaxW)
end

local function StyleScrollBar(scroll)
	EVO_UI.StyleScrollBar(scroll, EVO_CLAN_PAL)
end

local function MakeBtn(parent, x, y, w, h, sLabel, sFont, sStyle, fnClick)
	return EVO_UI.MakeBtn(parent, x, y, w, h, sLabel, sFont, sStyle, fnClick, EVO_CLAN_PAL)
end

-- ── Liste déroulante DA (pattern evo_famille validé) : carte sombre, hover
-- accent + liseré rouge, GROSSES rangées/fonte, flip au-dessus si ça déborde,
-- zone scrollable au-delà de 8 entrées. bSearch = champ de RECHERCHE en tête
-- (filtre en tapant, insensible casse/accents). Ferme : sélection ou clic
-- ailleurs. ──

-- Pliage accents -> ASCII pour le filtre de recherche (-> EVO_UI.FoldStr).
local function foldStr(s)
	return EVO_UI.FoldStr(s)
end

local activeDropdown
local function StyledDropdown(anchorBtn, items, onPick, bSearch)
	if IsValid(activeDropdown) then activeDropdown:Remove() activeDropdown = nil end
	local host = IsValid(pClan) and pClan._card or nil
	if not IsValid(host) or not IsValid(anchorBtn) or not items or #items == 0 then return end

	local itemH, pad = gRespY(56), gRespY(5)
	local nSearchH = bSearch and gRespY(60) or 0
	local w = math.max(anchorBtn:GetWide(), gRespX(320))
	local nShown = math.min(#items, 8)
	local h = pad * 2 + nSearchH + nShown * itemH

	local dd = vgui.Create("DPanel", host)
	activeDropdown = dd
	dd:SetMouseInputEnabled(true)
	dd:SetSize(w, h)

	-- Position : sous le bouton (écran -> local carte), flip au-dessus si ça
	-- déborde en bas, recale horizontalement pour rester dans la carte.
	local sx, sy = anchorBtn:LocalToScreen(0, anchorBtn:GetTall() + gRespY(4))
	local lx, ly = host:ScreenToLocal(sx, sy)
	if ly + h > host:GetTall() - gRespY(8) then
		local ax, ay = anchorBtn:LocalToScreen(0, -gRespY(4))
		local _, aly = host:ScreenToLocal(ax, ay)
		ly = aly - h
	end
	if lx + w > host:GetWide() - gRespX(8) then lx = host:GetWide() - gRespX(8) - w end
	if lx < gRespX(8) then lx = gRespX(8) end
	dd:SetPos(lx, ly)

	dd.Paint = function(_, bw, bh)
		RNDX.Draw(0, 0, 0, bw, bh, COL_DROP)
	end

	-- Fermeture au clic EN DEHORS (front montant du clic gauche).
	dd._wasDown = false
	dd.Think = function(s)
		local down = input.IsMouseDown(MOUSE_LEFT)
		if down and not s._wasDown then
			local mx, my = gui.MouseX(), gui.MouseY()
			local dx, dy = s:LocalToScreen(0, 0)
			local inDD = mx >= dx and my >= dy and mx <= dx + s:GetWide() and my <= dy + s:GetTall()
			local inBtn = false
			if IsValid(anchorBtn) then
				local bx, by = anchorBtn:LocalToScreen(0, 0)
				inBtn = mx >= bx and my >= by and mx <= bx + anchorBtn:GetWide() and my <= by + anchorBtn:GetTall()
			end
			if not inDD and not inBtn then
				s:Remove()
				if activeDropdown == s then activeDropdown = nil end
				return
			end
		end
		s._wasDown = down
	end

	-- Champ de RECHERCHE en tête (optionnel) : DA sombre, soulignement accent
	-- quand actif, placeholder. Filtre la liste en tapant (préfixe OU contenu,
	-- insensible casse/accents).
	local entry
	if bSearch then
		local box = vgui.Create("DPanel", dd)
		box:Dock(TOP)
		box:SetTall(nSearchH - pad)
		box:DockMargin(pad, pad, pad, 0)
		box.Paint = function(selff, bw, bh)
			RNDX.Draw(0, 0, 0, bw, bh, COL_ROW)
			if IsValid(selff.entry) and selff.entry:IsEditing() then
				RNDX.Draw(0, gRespX(10), bh - gRespY(2), bw - gRespX(20), gRespY(2), COL_ACCENT)
			end
		end
		entry = vgui.Create("DTextEntry", box)
		entry:Dock(FILL)
		entry:DockMargin(gRespX(14), 0, gRespX(14), 0)
		entry:SetFont(F_HINT)
		entry:SetDrawLanguageID(false)
		entry:SetDrawBackground(false)
		entry:SetDrawBorder(false)
		entry:SetTextColor(COL_TXT)
		entry:SetUpdateOnType(true)
		entry.Paint = function(self2, bw, bh)
			if not self2:HasFocus() and self2:GetValue() == "" then
				draw.SimpleText("Rechercher un joueur...", F_HINT, 0, bh / 2, Color(255, 255, 255, 64), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			else
				self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
			end
		end
		box.entry = entry
	end

	-- Conteneur scrollable (utile au-delà de 8 entrées).
	local list = vgui.Create("DScrollPanel", dd)
	list:Dock(FILL)
	list:DockMargin(pad, pad, pad, pad)
	StyleScrollBar(list)

	-- (Re)construit les options selon le filtre courant.
	local function Rebuild(sFilter)
		if not IsValid(list) then return end
		list:GetCanvas():Clear()
		local q = foldStr(sFilter)
		for _, it in ipairs(items) do
			if q == "" or string.find(foldStr(it.label), q, 1, true) then
				local sLbl = truncText(it.label, F_ROW, w - gRespX(44))
				local opt = vgui.Create("DButton", list)
				opt:SetText("")
				opt:SetCursor("hand")
				opt:SetTall(itemH)
				opt:Dock(TOP)
				opt.Paint = function(selff, bw, bh)
					local bHover = panel_contains_cursor(selff)
					if bHover then
						RNDX.Draw(0, 0, 0, bw, bh, COL_ACCENT_SOFT)
						RNDX.Draw(0, 0, 0, gRespX(3), bh, COL_ACCENT)
					end
					draw.SimpleText(sLbl, F_ROW, gRespX(14), bh / 2, bHover and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				opt.DoClick = function()
					surface.PlaySound(SND_CLICK)
					if onPick then onPick(it.id) end
					if IsValid(dd) then dd:Remove() end
					if activeDropdown == dd then activeDropdown = nil end
				end
			end
		end
	end
	Rebuild("")

	if IsValid(entry) then
		entry.OnValueChange = function(self2) Rebuild(self2:GetValue()) end
		entry:RequestFocus()
	end
	return dd
end

-- ── Réseau ──
local function requestState()
	net.Start("evo_clan:get")
	net.WriteString(sInspect or "")
	net.SendToServer()
end

local function sendAction(sAction, sArg, nArg)
	net.Start("evo_clan:action")
	net.WriteString(sAction)
	net.WriteString(sArg or "")
	net.WriteInt(nArg or 0, 32) -- int32 : EntIndex OU montant du pot
	net.SendToServer()
	timer.Simple(0.6, function() if IsValid(pClan) then requestState() end end)
end

-- ── Classement des clans (données serveur, mises en cache côté client) ──
local LB_DATA   = nil            -- dernière réponse "evo_clan:lb"
local lbFaction = nil            -- "Shinigami" | "Hollow" | "all" (défaut : TOUS)

local function requestLeaderboard()
	net.Start("evo_clan:lb")
	net.SendToServer()
end

-- Accès EXTERNE au classement (panneau 3D cl_clan_leaderboard3d, 07/23) : le
-- net "evo_clan:lb" n'a qu'UN receiver (ici) -> le panneau lit le même cache
-- et déclenche le même refresh (throttle 2 s serveur, agrégats cachés 60 s).
function EVO_CLAN.LbData() return LB_DATA end
EVO_CLAN.LbRequest = requestLeaderboard

-- ── Contenu : vue MON CLAN ──────────────────────────────────────────────────

-- Confirmation en 2 clics du transfert de lead : l'état doit survivre au re-rend
-- de l'onglet (push evo_clan:state), donc il vit ici et pas sur la rangée.
local leadArmUID, leadArmUntil = nil, 0

local function memberRow(parent, d, st, sMyUID)
	local row = vgui.Create("DPanel", parent)
	row:SetTall(gRespY(76))
	row:Dock(TOP)
	row:DockMargin(0, 0, gRespX(6), gRespY(8))
	row:SetPaintBackground(false)
	local bLeader  = st.isLeader
	local tRanks   = istable(st.ranks) and st.ranks or {}
	-- Boutons du LEADER sur les autres membres : bras droit + grade + exclure.
	local bLeaderBtns = bLeader and not d.isLeader and d.uid ~= sMyUID
	-- GRADE : leader OU bras droit, selon la règle PARTAGÉE EVO_CLAN.RankAssignAllowed
	-- (le serveur revalide rank_assign avec la même fonction). Pas de dropdown sans
	-- grade créé, et jamais sur soi-même.
	local bGradeBtn = #tRanks > 0 and d.uid ~= sMyUID
		and EVO_CLAN.RankAssignAllowed(bLeader, st.isOfficer, d.isLeader, d.isOfficer) == true
	-- EXCLURE : leader (jamais le leader ni soi) OU permission EXCLURE d'un grade
	-- (jamais le leader NI le bras droit — revalidé serveur de toute façon).
	local bKickBtn = d.uid ~= sMyUID and not d.isLeader
		and (bLeader or (hasPermC(st.myPerms, PERM.KICK) and not d.isOfficer))
	local sName = truncText(d.name, F_ROW, gRespX(CARD_W - 460))
	-- GRADE personnalisé affiché sous le nom (comme LEADER / BRAS DROIT), en
	-- VERT — couleur de la palette distincte des deux rôles fixes.
	local sRank = (not d.isLeader and not d.isOfficer and (d.rankName or "") ~= "")
		and truncText(string.upper(d.rankName), F_ROW_SUB, gRespX(260)) or nil
	row.Paint = function(selff, w, h)
		RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
		-- pastille en ligne / hors ligne
		local cy = h * 0.5
		draw.NoTexture()
		surface.SetDrawColor(d.online and COL_GREEN or COL_OFFLINE)
		surface.DrawTexturedRectRotated(gRespX(20), cy, gRespX(9), gRespX(9), 45)
		local bRole = d.isLeader or d.isOfficer or sRank ~= nil
		draw.SimpleText(sName, F_ROW, gRespX(40), cy - (bRole and gRespY(12) or 0), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- Rôle (droit) affiché sous le nom : LEADER / BRAS DROIT / grade custom.
		if d.isLeader then
			draw.SimpleText("LEADER", F_ROW_SUB, gRespX(40), cy + gRespY(16), COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		elseif d.isOfficer then
			draw.SimpleText("BRAS DROIT", F_ROW_SUB, gRespX(40), cy + gRespY(16), COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		elseif sRank then
			draw.SimpleText(sRank, F_ROW_SUB, gRespX(40), cy + gRespY(16), COL_GREEN, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		-- TRACE DES DONS : visible par le LEADER (qui a donné combien).
		if bLeader then
			MUGEN.DrawMoneyLine("don : " .. string.Comma(d.don or 0) .. " ¥", F_ROW_SUB,
				w - (bLeaderBtns and gRespX(384) or gRespX(16)), cy,
				COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
	local btnOff, btnKick, btnGrade, btnLead
	if bLeaderBtns then
		btnOff = MakeBtn(row, 0, 0, 210, 40, d.isOfficer and "RETIRER B. DROIT" or "BRAS DROIT",
			F_BTN_SMALL, d.isOfficer and "neutral" or "primary", function()
				sendAction(d.isOfficer and "removeofficer" or "setofficer", d.uid, 0)
			end)
		-- TRANSMETTRE LE LEAD : irréversible pour l'émetteur -> double-clic de
		-- confirmation, même patron que SUPPRIMER un grade.
		local sLeadUID = d.uid
		btnLead = MakeBtn(row, 0, 0, 180, 40, "DONNER LE LEAD", F_BTN_SMALL, "neutral", function()
			-- L'armement vit dans un LOCAL DE FICHIER, pas sur la rangée : l'onglet
			-- est reconstruit à chaque push d'état et un état porté par le
			-- panneau serait effacé en plein milieu de la fenêtre de confirmation.
			if leadArmUID == sLeadUID and CurTime() < leadArmUntil then
				leadArmUID, leadArmUntil = nil, 0
				sendAction("setleader", sLeadUID, 0)
			else
				leadArmUID, leadArmUntil = sLeadUID, CurTime() + 3
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Re-clique DONNER LE LEAD dans les 3 s : "
					.. d.name .. " deviendra leader et tu redeviendras simple membre.")
			end
		end)
	end
	if bGradeBtn then
		-- Assignation de GRADE : « AUCUN » + les grades du clan (dropdown DA).
		btnGrade = MakeBtn(row, 0, 0, 100, 40, "GRADE", F_BTN_SMALL, "neutral", function()
			local items = { { label = "AUCUN", id = 0 } }
			for _, rk in ipairs(tRanks) do
				items[#items + 1] = { label = rk.name, id = rk.id }
			end
			StyledDropdown(btnGrade, items, function(nId)
				sendAction("rank_assign", d.uid, nId)
			end)
		end)
	end
	if bKickBtn then
		btnKick = MakeBtn(row, 0, 0, 130, bLeaderBtns and 40 or 48, "EXCLURE", F_BTN_SMALL, "danger", function()
			sendAction("kick", d.uid, 0)
		end)
	end
	if bLeaderBtns then
		-- 2 lignes de boutons (bras droit + exclure / lead + grade) : la largeur
		-- réservée à droite ne change pas -> nom + dons ne bougent pas.
		-- Le 2e rang est ancré À DROITE et se remplit de droite à gauche, pour que
		-- l'absence de GRADE (aucun grade créé) ne laisse pas de trou.
		row:SetTall(gRespY(96))
		row.PerformLayout = function(_, w, h)
			local y1 = h * 0.5 - gRespY(44)
			local y2 = h * 0.5 + gRespY(4)
			if IsValid(btnKick) then btnKick:SetPos(w - gRespX(130) - gRespX(12), y1) end
			if IsValid(btnOff) then btnOff:SetPos(w - gRespX(130) - gRespX(12) - gRespX(210) - gRespX(10), y1) end
			local nRight = w - gRespX(12)
			if IsValid(btnGrade) then
				btnGrade:SetPos(nRight - gRespX(100), y2)
				nRight = nRight - gRespX(100) - gRespX(10)
			end
			if IsValid(btnLead) then btnLead:SetPos(nRight - gRespX(180), y2) end
		end
	elseif btnOff or btnKick or btnGrade then
		-- Une seule ligne, remplie de DROITE à gauche (exclure, bras droit, grade) :
		-- c'est ici qu'atterrit le bras droit avec son bouton GRADE (2026-09-18).
		-- Chaque bouton est centré sur SA hauteur (EXCLURE fait 48 ici, GRADE 40).
		row.PerformLayout = function(_, w, h)
			local nRight = w - gRespX(12)
			local function place(btn, nW)
				if not IsValid(btn) then return end
				btn:SetPos(nRight - gRespX(nW), (h - btn:GetTall()) / 2)
				nRight = nRight - gRespX(nW) - gRespX(10)
			end
			place(btnKick, 130)
			place(btnOff, 210)
			place(btnGrade, 100)
		end
	end
	return row
end

-- Popup d'erreur clan (création, dépôt banque, achats upgrades, …).
local function clanCreatePopup(msg)
	local lp = LocalPlayer()
	if IsValid(lp) and isfunction(lp.OpenPopup) then
		lp:OpenPopup(msg, "error")
	else
		chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, msg)
	end
end

-- ── Section ACHATS (onglet UPGRADES) : solde + cartes niveau/coffres/bâtiment/taxe.
-- Dépôt / retrait / historique vivent dans l'onglet BANQUE.
local function BuildPotSection(parent, st)
	local pot = vgui.Create("DPanel", parent)
	pot:Dock(TOP)
	pot:DockMargin(0, gRespY(6), gRespX(6), 0)
	pot:SetPaintBackground(false)

	local nPot = tonumber(st.pot) or 0
	local tNextLvl = st.nextLevel
	local nSpellCost = st.nextSpellCost
	local nSpells, nSpellsMax = st.spellsCount or 1, st.spellsMax or 5
	local tNextChest = EVO_CLAN.NextChestUpgrade and EVO_CLAN.NextChestUpgrade(st.chestUpgrades or 0) or nil
	local nChestCost = CFG.ChestUpgradeCost or 500000

	local bCanBuy  = st.isLeader or st.isOfficer
	local bCanBank = bCanBuy or hasPermC(st.myPerms, PERM.UPGRADE)
	local bCanTax  = bCanBuy or hasPermC(st.myPerms, PERM.TAX)

	local function chestStateStr()
		local tQ = st.rewardQuotas or {}
		local t = {}
		for _, c in ipairs(CFG.RewardChoices or {}) do
			local nQ = tQ[c.chest] or c.weekly or 0
			if nQ > 0 then t[#t + 1] = (c.short or c.label) .. " " .. nQ end
		end
		return table.concat(t, " · ")
	end

	pot.Paint = function(_, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_ROW)
		drawBrushLabel("AMÉLIORATIONS", F_LABEL, gRespY(12), gRespY(32), COL_TXT_DIM)
		draw.SimpleText("Payées depuis la banque du clan.", F_HINT, gRespX(20), gRespY(48), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		MUGEN.DrawMoneyLine("Solde : " .. string.Comma(nPot) .. " ¥", F_SUBTITLE, w - gRespX(20), gRespY(28), COL_TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local ROW_H, BTN_W, BTN_H = gRespY(76), gRespX(250), gRespY(42)
	local PAD_X, PAD_YT, PAD_YB = gRespX(20), gRespY(18), gRespY(18)
	local tRows = {}
	local function objRow(sTitle, sSub, colSub, nCost, sAct, bCanAct, sDoneLabel)
		local row = vgui.Create("DPanel", pot)
		row:SetPaintBackground(false)
		local sBuy = nCost and ("ACHETER · " .. string.Comma(nCost) .. " ¥") or nil
		row.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, Color(14, 14, 18, 255))
			local nTextMax = w - (bCanAct and nCost and (BTN_W + gRespX(48)) or gRespX(220))
			draw.SimpleText(truncText(sTitle, F_ROW, nTextMax), F_ROW, PAD_X, PAD_YT, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(truncText(sSub or "", F_ROW_SUB, nTextMax), F_ROW_SUB, PAD_X, h - PAD_YB,
				colSub or COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if not bCanAct then
				if sDoneLabel then
					draw.SimpleText(sDoneLabel, F_BTN_SMALL, w - PAD_X, h * 0.5, COL_GREEN, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif nCost then
					MUGEN.DrawMoneyLine("COÛT : " .. string.Comma(nCost) .. " ¥", F_ROW_SUB, w - PAD_X, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			elseif not nCost and sDoneLabel then
				draw.SimpleText(sDoneLabel, F_BTN_SMALL, w - PAD_X, h * 0.5, COL_GREEN, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		if bCanAct and nCost then
			local bCan = nPot >= nCost
			local btn = MakeBtn(row, 0, 0, 0, 0, sBuy, F_BTN_SMALL, bCan and "primary" or "neutral", function()
				if nPot >= nCost then
					sendAction(sAct, "", 0)
				else
					clanCreatePopup("Banque insuffisante : il manque "
						.. string.Comma(nCost - nPot) .. " ¥ (solde : " .. string.Comma(nPot) .. " ¥).")
				end
			end)
			row.PerformLayout = function(_, w, h)
				btn:SetSize(BTN_W, BTN_H)
				btn:SetPos(w - BTN_W - PAD_X, (h - BTN_H) * 0.5)
			end
		end
		tRows[#tRows + 1] = row
	end

	local nLvl = st.clanLevel or 1
	if tNextLvl then
		objRow("NIVEAU DE CLAN",
			nLvl .. " → " .. tNextLvl.level .. "  ·  plafond " .. tNextLvl.max .. " membres"
				.. (tNextLvl.spellRequest and "  ·  débloque spell unique" or ""),
			COL_TXT_DIM, tNextLvl.cost, "pot_upgrade", bCanBank)
	else
		objRow("NIVEAU DE CLAN", "Niveau " .. nLvl .. " (MAX)  ·  " .. (st.cap or 15) .. " membres", COL_GREEN, nil, nil, false, "MAX")
	end

	if not (EvoStyle and EvoStyle.ClanSpellsStandby) then
		if nSpellCost then
			objRow("SPELLS DE CLAN", nSpells .. " / " .. nSpellsMax .. " sorts débloqués", COL_TXT_DIM, nSpellCost, "pot_spell", bCanBuy)
		else
			objRow("SPELLS DE CLAN", "Maximum atteint (" .. nSpellsMax .. " / " .. nSpellsMax .. ")", COL_GREEN, nil, nil, false, "MAX")
		end
	end

	if tNextChest then
		local sCur = chestStateStr()
		objRow("COFFRES / SEMAINE",
			(sCur ~= "" and (sCur .. "  ·  ") or "") .. "prochain : +1 " .. (tNextChest.short or "coffre"),
			COL_TXT_DIM, nChestCost, "pot_chest", bCanBank)
	else
		objRow("COFFRES / SEMAINE", "Maximum  —  " .. chestStateStr(), COL_GREEN, nil, nil, false, "MAX")
	end

	local bBuildingOn = st.buildingEnabled
	if bBuildingOn == nil then bBuildingOn = CFG.BuildingUpgradeEnabled == true end
	if not bBuildingOn and not st.buildingAccess then
		-- Feature pas encore sorti : carte visible mais achat impossible.
		objRow("BÂTIMENT DE CLAN", "Arrive bientôt", COL_TXT_DIM, nil, nil, false, "BIENTÔT")
	elseif st.buildingAccess then
		if st.buildingEffective then
			objRow("BÂTIMENT DE CLAN", "Accès débloqué", COL_GREEN, nil, nil, false, "DÉBLOQUÉ")
		else
			objRow("BÂTIMENT DE CLAN", "Suspendu : taxe en retard", COL_ACCENT, nil, nil, false, "SUSPENDU")
		end
	else
		objRow("BÂTIMENT DE CLAN", "Verrouillé — achat unique depuis la banque", COL_TXT_DIM,
			st.buildingCost or 1000000, "pot_building", bCanBank)
	end

	-- EMPLACEMENT DU DOMAINE : payer le bail ne pose plus la porte, il faut aller
	-- la choisir en jeu. Sans cette ligne, un clan qui vient d'acheter n'a aucun
	-- moyen de savoir ou sont les points (demande user 08/22).
	if st.buildingAccess and #EVO_CLAN.DomaineEmplacements() > 0 then
		local sSlot = LocalPlayer():GetEvoNWString("EVO_ClanDomaineSlot", "")
		if sSlot ~= "" then
			objRow("EMPLACEMENT DU DOMAINE", "Entrée posée sur la carte", COL_GREEN, nil, nil, false, "CHOISI")
		else
			local row = vgui.Create("DPanel", pot)
			row:SetPaintBackground(false)
			row.Paint = function(_, w, h)
				RNDX.Draw(0, 0, 0, w, h, Color(14, 14, 18, 255))
				draw.SimpleText("EMPLACEMENT DU DOMAINE", F_ROW, PAD_X, PAD_YT, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText("Aucun emplacement choisi  ·  va sur un point libre et appuie sur E",
					F_ROW_SUB, PAD_X, h - PAD_YB, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			local btn = MakeBtn(row, 0, 0, 0, 0, "VOIR LES POSITIONS", F_BTN_SMALL, "primary", function()
				-- Ferme le menu : les reperes se lisent en jeu, pas derriere une
				-- fenetre qui prend tout l'ecran.
				EVO_CLAN.DomaineGuidage(240)
				if IsValid(pClan) then pClan:Remove() pClan = nil end
			end)
			row.PerformLayout = function(_, w, h)
				btn:SetSize(BTN_W, BTN_H)
				btn:SetPos(w - BTN_W - PAD_X, (h - BTN_H) * 0.5)
			end
			tRows[#tRows + 1] = row
		end
	end

	local bTaxOn = st.taxEnabled
	if bTaxOn == nil then
		bTaxOn = CFG.TaxEnabled ~= false and CFG.BuildingUpgradeEnabled == true
	end
	local sTaxLbl = st.taxDivLabel or "Division 1"
	if not bTaxOn then
		-- Liée au bâtiment : carte visible mais paiement impossible.
		objRow("TAXE " .. string.upper(sTaxLbl),
			"Arrive bientôt — sans taxe à jour, perte du bâtiment de clan",
			COL_TXT_DIM, nil, nil, false, "BIENTÔT")
	else
		local taxRow = vgui.Create("DPanel", pot)
		taxRow:SetPaintBackground(false)
		local nUntil = st.taxPaidUntil or 0
		local bTaxOk = st.taxOk
		local nDaily = st.taxDaily or 50000
		local nMaxDays = st.taxPrepayMaxDays or 7
		local nNow = os.time()
		local nRemainDays = 0
		if nUntil > nNow then
			nRemainDays = math.max(0, math.ceil((nUntil - nNow) / 86400))
		end
		local sTaxTitle = bTaxOk
			and ("TAXE " .. sTaxLbl .. " — " .. nRemainDays .. " J RESTANT" .. (nRemainDays > 1 and "S" or ""))
			or ("TAXE " .. sTaxLbl .. " — EN RETARD")
		local sWarn = "Sans taxe à jour : perte du bâtiment de clan."
		local sTaxSub
		if bTaxOk then
			if nRemainDays > 0 then
				sTaxSub = nRemainDays .. " jour" .. (nRemainDays > 1 and "s" or "")
					.. " restant" .. (nRemainDays > 1 and "s" or "")
					.. " (jusqu'au " .. os.date("%d/%m %H:%M", nUntil) .. ")  ·  "
					.. string.Comma(nDaily) .. " ¥ / jour  ·  " .. sWarn
			else
				sTaxSub = "Expire bientôt  ·  " .. string.Comma(nDaily) .. " ¥ / jour  ·  " .. sWarn
			end
		else
			sTaxSub = "Bâtiment de clan suspendu  ·  " .. string.Comma(nDaily)
				.. " ¥ / jour · max " .. nMaxDays .. " j d'avance  ·  " .. sWarn
		end
		taxRow.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, Color(14, 14, 18, 255))
			local nTextMax = w - (bCanTax and gRespX(320) or gRespX(40))
			draw.SimpleText(truncText(sTaxTitle, F_ROW, nTextMax), F_ROW, PAD_X, PAD_YT,
				bTaxOk and COL_TXT or COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine(truncText(sTaxSub, F_ROW_SUB, nTextMax), F_ROW_SUB, PAD_X, h - PAD_YB,
				bTaxOk and COL_TXT_DIM or COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		if bCanTax then
			local function tryPayTax(nDays)
				local nCost = nDaily * nDays
				if nPot < nCost then
					clanCreatePopup("Banque insuffisante : " .. nDays .. " jour(s) = "
						.. string.Comma(nCost) .. " ¥ (solde : " .. string.Comma(nPot) .. " ¥).")
					return
				end
				sendAction("pay_tax", "", nDays)
			end
			local btnTax7 = MakeBtn(taxRow, 0, 0, 0, 0, "+7 J  ·  " .. string.Comma(nDaily * 7) .. " ¥", F_BTN_SMALL, "primary", function()
				tryPayTax(7)
			end)
			local btnTax1 = MakeBtn(taxRow, 0, 0, 0, 0, "+1 J  ·  " .. string.Comma(nDaily) .. " ¥", F_BTN_SMALL, "primary", function()
				tryPayTax(1)
			end)
			taxRow.PerformLayout = function(_, w, h)
				local bh = gRespY(42)
				btnTax7:SetSize(gRespX(168), bh)
				btnTax7:SetPos(w - gRespX(168) - PAD_X, (h - bh) * 0.5)
				btnTax1:SetSize(gRespX(140), bh)
				btnTax1:SetPos(w - gRespX(168) - gRespX(140) - PAD_X - gRespX(10), (h - bh) * 0.5)
			end
		end
		tRows[#tRows + 1] = taxRow
	end

	local nHeaderH = gRespY(68)
	pot:SetTall(nHeaderH + #tRows * (ROW_H + gRespY(8)) + gRespY(16))

	pot.PerformLayout = function(_, w, h)
		local y = nHeaderH
		for _, row in ipairs(tRows) do
			row:SetPos(gRespX(16), y)
			row:SetSize(w - gRespX(32), ROW_H)
			y = y + ROW_H + gRespY(8)
		end
	end
	return pot
end

-- ── Onglet BANQUE : solde, dépôt, retrait, historique ───────────────────────
local function BuildBanqueTab(content)
	content:Clear()
	local st = STATE
	if not st then
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du clan...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestState()
		return
	end
	if (st.myKey or "") == "" then
		local lbl = vgui.Create("DPanel", content)
		lbl:Dock(FILL)
		lbl:SetPaintBackground(false)
		lbl.Paint = function(_, w, h)
			draw.SimpleText("Rejoins un clan pour accéder à sa banque.", F_SUBTITLE, w * 0.5, h * 0.4, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	local nPot = tonumber(st.pot) or 0
	local nDepositMin = st.depositMin or CFG.PotDepositMin or 1000
	local nWithdrawMin = st.withdrawMin or CFG.PotWithdrawMin or 1000
	local nTaxPct = st.withdrawTaxPercent
	if nTaxPct == nil then nTaxPct = CFG.PotWithdrawTaxPercent or 5 end
	nTaxPct = math.Clamp(math.floor(tonumber(nTaxPct) or 5), 0, 99)
	local bCanWithdraw = st.isLeader or st.isOfficer or hasPermC(st.myPerms, PERM.WITHDRAW)

	-- Layout : bandeau → dépôt (tous) → [retrait + taxe].
	local nPadX, nPadY = gRespX(20), gRespY(12)
	local nChipW, nChipH, nChipGap = gRespX(100), gRespY(32), gRespX(8)
	local tQuick = { 5000, 10000, 50000, 100000 }
	local head = vgui.Create("DPanel", content)
	head:SetTall(bCanWithdraw and gRespY(292) or gRespY(168))
	head:Dock(TOP)
	head:DockMargin(0, 0, 0, gRespY(8))
	head:SetPaintBackground(false)
	head.Paint = function(_, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_ROW)
		drawBrushLabel("BANQUE DU CLAN", F_LABEL, nPadY, gRespY(34), COL_TXT_DIM)
		draw.SimpleText("Tout membre peut déposer." .. (bCanWithdraw and " Retrait = permission RETRAIT." or ""),
			F_HINT, nPadX, gRespY(48), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		MUGEN.DrawMoneyLine("Solde : " .. string.Comma(nPot) .. " ¥", F_SUBTITLE, w - nPadX, gRespY(28), COL_TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		if bCanWithdraw then
			MUGEN.DrawMoneyLine("Taxe " .. nTaxPct .. "% : tu reçois " .. (100 - nTaxPct) .. "% du montant retiré.",
				F_HINT, nPadX, h - gRespY(18), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local depBox = vgui.Create("DPanel", head)
	depBox:gSetPos(20, 68)
	depBox:gSetSize(250, 44)
	depBox.Paint = function(selff, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_FIELD)
		if IsValid(selff.entry) and selff.entry:IsEditing() then
			RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
		end
	end
	local depEntry = vgui.Create("DTextEntry", depBox)
	depEntry:Dock(FILL)
	depEntry:DockMargin(gRespX(12), 0, gRespX(12), 0)
	depEntry:SetFont(F_HINT)
	depEntry:SetNumeric(true)
	depEntry:SetDrawLanguageID(false)
	depEntry:SetDrawBackground(false)
	depEntry:SetDrawBorder(false)
	depEntry:SetTextColor(COL_TXT)
	depEntry.Paint = function(self2, w, h)
		if not self2:HasFocus() and self2:GetValue() == "" then
			draw.SimpleText("Dépôt (min " .. string.Comma(nDepositMin) .. ")", F_HINT, 0, h / 2,
				COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
		end
	end
	depBox.entry = depEntry

	MakeBtn(head, 282, 68, 170, 44, "DÉPOSER", F_BTN_SMALL, "primary", function()
		local nAmount = math.floor(tonumber(depEntry:GetValue()) or 0)
		if nAmount < nDepositMin then
			clanCreatePopup("Dépôt minimum : " .. string.Comma(nDepositMin) .. " ¥.")
			return
		end
		local nMine = LocalPlayer():GetEvoNWInt("Money", 0)
		if nAmount > nMine then
			clanCreatePopup("Yens insuffisants : tu as " .. string.Comma(nMine) .. " ¥.")
			return
		end
		sendAction("pot_deposit", "", nAmount)
		depEntry:SetValue("")
	end)

	for i, nAmt in ipairs(tQuick) do
		local chip = MakeBtn(head, 0, 0, 0, 0, string.Comma(nAmt), F_BTN_SMALL, "neutral", function()
			depEntry:SetValue(tostring(nAmt))
			depEntry:RequestFocus()
		end)
		chip:SetSize(nChipW, nChipH)
		chip:SetPos(nPadX + (i - 1) * (nChipW + nChipGap), gRespY(120))
	end

	if bCanWithdraw then
		local wdBox = vgui.Create("DPanel", head)
		wdBox:gSetPos(20, 168)
		wdBox:gSetSize(250, 44)
		wdBox.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_FIELD)
			if IsValid(selff.entry) and selff.entry:IsEditing() then
				RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
			end
		end
		local wdEntry = vgui.Create("DTextEntry", wdBox)
		wdEntry:Dock(FILL)
		wdEntry:DockMargin(gRespX(12), 0, gRespX(12), 0)
		wdEntry:SetFont(F_HINT)
		wdEntry:SetNumeric(true)
		wdEntry:SetDrawLanguageID(false)
		wdEntry:SetDrawBackground(false)
		wdEntry:SetDrawBorder(false)
		wdEntry:SetTextColor(COL_TXT)
		wdEntry.Paint = function(self2, w, h)
			if not self2:HasFocus() and self2:GetValue() == "" then
				draw.SimpleText("Retrait (min " .. string.Comma(nWithdrawMin) .. ")", F_HINT, 0, h / 2,
					COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			else
				self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
			end
		end
		wdBox.entry = wdEntry

		MakeBtn(head, 282, 168, 170, 44, "RETIRER", F_BTN_SMALL, "danger", function()
			local nAmount = math.floor(tonumber(wdEntry:GetValue()) or 0)
			if nAmount < nWithdrawMin then
				clanCreatePopup("Retrait minimum : " .. string.Comma(nWithdrawMin) .. " ¥.")
				return
			end
			if nAmount > nPot then
				clanCreatePopup("Banque insuffisante : solde " .. string.Comma(nPot) .. " ¥.")
				return
			end
			local nNet = math.floor(nAmount * (100 - nTaxPct) / 100)
			if nNet < 1 then
				clanCreatePopup("Montant trop faible après la taxe de " .. nTaxPct .. "%.")
				return
			end
			sendAction("pot_withdraw", "", nAmount)
			wdEntry:SetValue("")
		end)

		for i, nAmt in ipairs(tQuick) do
			local chip = MakeBtn(head, 0, 0, 0, 0, string.Comma(nAmt), F_BTN_SMALL, "neutral", function()
				wdEntry:SetValue(tostring(nAmt))
				wdEntry:RequestFocus()
			end)
			chip:SetSize(nChipW, nChipH)
			chip:SetPos(nPadX + (i - 1) * (nChipW + nChipGap), gRespY(220))
		end
	end

	-- Historique
	local histHead = vgui.Create("DPanel", content)
	histHead:SetTall(gRespY(36))
	histHead:Dock(TOP)
	histHead:SetPaintBackground(false)
	histHead.Paint = function(_, _, h)
		drawBrushLabel("HISTORIQUE", F_LABEL, 0, h, COL_TXT_DIM)
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll

	local tLog = istable(st.bankLog) and st.bankLog or {}
	if #tLog == 0 then
		local empty = vgui.Create("DPanel", scroll)
		empty:SetTall(gRespY(64))
		empty:Dock(TOP)
		empty:SetPaintBackground(false)
		empty.Paint = function(_, w, h)
			draw.SimpleText("Aucun dépôt ni retrait pour l'instant.", F_HINT, w * 0.5, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	for _, e in ipairs(tLog) do
		local bDep = e.kind == "deposit"
		local row = vgui.Create("DPanel", scroll)
		row:SetTall(gRespY(72))
		row:Dock(TOP)
		row:DockMargin(0, 0, gRespX(6), gRespY(8))
		row:SetPaintBackground(false)
		local sWhen = (e.ts or 0) > 0 and os.date("%d/%m %H:%M", e.ts) or "—"
		local sTitle = bDep and "DÉPÔT" or "RETRAIT"
		local colKind = bDep and COL_GREEN or COL_ACCENT
		local sAmt = bDep
			and ("+" .. string.Comma(e.amount or 0) .. " ¥")
			or ("−" .. string.Comma(e.amount or 0) .. " ¥")
		local sSub = truncText((e.name or "?") .. "  ·  " .. sWhen
			.. (not bDep and (e.tax or 0) > 0 and ("  ·  taxe " .. string.Comma(e.tax) .. " ¥ → reçu " .. string.Comma(e.net or 0) .. " ¥") or ""),
			F_ROW_SUB, gRespX(CARD_W - 200))
		row.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
			RNDX.Draw(0, 0, 0, gRespX(4), h, colKind)
			draw.SimpleText(sTitle, F_ROW, gRespX(20), gRespY(18), colKind, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sSub, F_ROW_SUB, gRespX(20), h - gRespY(18), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine(sAmt, F_ROW, w - gRespX(20), h * 0.5, COL_TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
end

-- ── Section GRADES DU CLAN (onglet GRADES, LEADER pour l'édition) ────────────
-- Jusqu'à st.maxRanks grades nommés, chacun portant un bitmask de permissions
-- (EVO_CLAN.PERM, sh_config — le serveur revalide TOUT). Le BROUILLON de
-- création (nom tapé + chips cochées) et les brouillons d'édition des grades
-- existants vivent dans des locals de FICHIER : le refresh d'état (push serveur)
-- re-rend l'onglet et un état stocké dans les panneaux serait perdu entre deux
-- interactions (le rebuild n'est différé QUE pendant la frappe d'un champ focus,
-- pas après un clic de chip).
local rankDraftName  = ""
local rankDraftPerms = 0
local rankEditDrafts = {} -- [rank_id] = bitmask en cours d'édition (nil = valeur serveur)
local rankEditNames  = {} -- [rank_id] = nom en cours d'édition (nil = valeur serveur)

-- Résumé texte des permissions d'un bitmask — appelé au BUILD seulement
-- (précalculé avant les Paint : 0 allocation par frame).
local function permSummary(nPerms)
	local t = {}
	for _, p in ipairs(EVO_CLAN.PermList or {}) do
		if bit.band(nPerms or 0, p.bit or 0) ~= 0 then t[#t + 1] = p.label end
	end
	return #t > 0 and table.concat(t, " · ") or "aucune permission"
end

-- Chips permissions dans un DHorizontalScroller ; get/set via closures (draft fichier).
local function attachPermChips(parent, getBits, setBits)
	local chipScroll = vgui.Create("DHorizontalScroller", parent)
	chipScroll:SetOverlap(gRespX(-8))
	chipScroll.Paint = function() end
	if IsValid(chipScroll.btnLeft) then
		chipScroll.btnLeft:SetWide(gRespX(18))
		chipScroll.btnLeft.Paint = function(selff, w, h)
			draw.SimpleText("‹", F_BTN_SMALL, w * 0.5, h * 0.5,
				panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	if IsValid(chipScroll.btnRight) then
		chipScroll.btnRight:SetWide(gRespX(18))
		chipScroll.btnRight.Paint = function(selff, w, h)
			draw.SimpleText("›", F_BTN_SMALL, w * 0.5, h * 0.5,
				panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	chipScroll.OnMouseWheeled = function(self2, delta)
		self2.OffsetX = math.Clamp((self2.OffsetX or 0) - delta * gRespX(48), 0, math.max(0, (self2.pnlCanvas and self2.pnlCanvas:GetWide() or 0) - self2:GetWide()))
		self2:InvalidateLayout(true)
		return true
	end
	for _, p in ipairs(EVO_CLAN.PermList or {}) do
		local nBit = p.bit or 0
		local sLbl = p.label
		local chip = vgui.Create("DButton")
		chip:SetText("")
		chip:SetCursor("hand")
		chip:SetSize(gRespX(150), gRespY(38))
		chip.Paint = function(_, w, h)
			local bOn = bit.band(getBits() or 0, nBit) ~= 0
			RNDX.Draw(0, 0, 0, w, h, bOn and COL_ACCENT_SOFT or COL_FIELD)
			if bOn then RNDX.Draw(0, 0, 0, gRespX(3), h, COL_ACCENT) end
			draw.SimpleText(sLbl, F_BTN_SMALL, w * 0.5, h * 0.5, bOn and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		chip.DoClick = function()
			surface.PlaySound(SND_CLICK)
			setBits(bit.bxor(getBits() or 0, nBit))
		end
		chipScroll:AddPanel(chip)
	end
	return chipScroll
end

local function BuildRanksSection(scroll, st)
	local tRanks = istable(st.ranks) and st.ranks or {}
	local nMax = st.maxRanks or 10

	local head = vgui.Create("DPanel", scroll)
	head:SetTall(gRespY(40))
	head:Dock(TOP)
	head:DockMargin(0, gRespY(4), gRespX(6), 0)
	head:SetPaintBackground(false)
	local sHead = "GRADES DU CLAN (" .. #tRanks .. " / " .. nMax .. ")"
	head.Paint = function(_, _, h)
		drawBrushLabel(sHead, F_LABEL, 0, h, COL_TXT_DIM)
	end

	-- Grades existants : nom éditable + chips + ENREGISTRER / SUPPRIMER.
	for _, rk in ipairs(tRanks) do
		local nRankId, sServerName = rk.id, tostring(rk.name or "")
		local nServerPerms = rk.perms or 0
		-- Drafts syncés au serveur : une fois le push reçu, on nettoie.
		if rankEditDrafts[nRankId] ~= nil and rankEditDrafts[nRankId] == nServerPerms then
			rankEditDrafts[nRankId] = nil
		end
		if rankEditNames[nRankId] ~= nil and rankEditNames[nRankId] == sServerName then
			rankEditNames[nRankId] = nil
		end
		local function getEditBits()
			return rankEditDrafts[nRankId] ~= nil and rankEditDrafts[nRankId] or nServerPerms
		end
		local function setEditBits(nBits)
			rankEditDrafts[nRankId] = nBits
		end
		local function getEditName()
			return rankEditNames[nRankId] ~= nil and rankEditNames[nRankId] or sServerName
		end

		local row = vgui.Create("DPanel", scroll)
		row:SetTall(gRespY(118))
		row:Dock(TOP)
		row:DockMargin(0, gRespY(6), gRespX(6), 0)
		row:SetPaintBackground(false)
		local nMembers = rk.members or 0
		row.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
			draw.SimpleText(nMembers .. " membre" .. (nMembers > 1 and "s" or ""), F_HINT,
				w - gRespX(320) - gRespX(16), gRespY(28), COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local nameBox = vgui.Create("DPanel", row)
		nameBox:gSetPos(12, 12)
		nameBox:gSetSize(430, 46)
		nameBox.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_FIELD)
			if IsValid(selff.entry) and selff.entry:IsEditing() then
				RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
			end
		end
		local entry = vgui.Create("DTextEntry", nameBox)
		entry:Dock(FILL)
		entry:DockMargin(gRespX(12), 0, gRespX(12), 0)
		entry:SetFont(F_HINT)
		entry:SetDrawLanguageID(false)
		entry:SetDrawBackground(false)
		entry:SetDrawBorder(false)
		entry:SetTextColor(COL_TXT)
		entry:SetUpdateOnType(true)
		entry:SetValue(getEditName())
		entry.OnValueChange = function(self2) rankEditNames[nRankId] = self2:GetValue() end
		entry.Paint = function(self2, w, h)
			self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
		end
		nameBox.entry = entry

		local chipScroll = attachPermChips(row, getEditBits, setEditBits)

		local btnSave = MakeBtn(row, 0, 0, 150, 40, "ENREGISTRER", F_BTN_SMALL, "primary", function()
			local sName = string.Trim(getEditName() or "")
			local nBits = getEditBits()
			if sName == sServerName and nBits == nServerPerms then
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Aucune modification à enregistrer pour « " .. sServerName .. " ».")
				return
			end
			if (utf8.len(sName) or #sName) < (CFG.RankNameMinLen or 2) then
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Choisis un nom de grade (min " .. (CFG.RankNameMinLen or 2) .. " caractères).")
				return
			end
			sendAction("rank_update", tostring(nRankId) .. "\t" .. sName, nBits)
		end)
		local btnDel = MakeBtn(row, 0, 0, 150, 40, "SUPPRIMER", F_BTN_SMALL, "danger", function()
			if row._delArm and CurTime() < row._delArm then
				row._delArm = nil
				rankEditDrafts[nRankId] = nil
				rankEditNames[nRankId] = nil
				sendAction("rank_delete", "", nRankId)
			else
				row._delArm = CurTime() + 3
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Re-clique SUPPRIMER dans les 3 s pour confirmer la suppression du grade « "
					.. sServerName .. " » (ses porteurs redeviennent simples membres).")
			end
		end)
		row.PerformLayout = function(_, w, h)
			btnSave:SetPos(w - gRespX(150) - gRespX(12), gRespY(14))
			btnDel:SetPos(w - gRespX(150) - gRespX(12) - gRespX(150) - gRespX(8), gRespY(14))
			chipScroll:SetPos(gRespX(12), gRespY(68))
			chipScroll:SetSize(math.max(0, w - gRespX(24)), gRespY(38))
		end
	end

	-- Rangée de CRÉATION (tant que le cap n'est pas atteint) : champ nom (VRAI
	-- DTextEntry, protégé par le rebuild différé pendant la frappe) + chips de
	-- permissions (toggle, scroller horizontal) + CRÉER. Revalidé serveur.
	if #tRanks >= nMax then return end
	local create = vgui.Create("DPanel", scroll)
	create:SetTall(gRespY(118))
	create:Dock(TOP)
	create:DockMargin(0, gRespY(6), gRespX(6), 0)
	create.Paint = function(_, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_ROW)
	end

	local nameBox = vgui.Create("DPanel", create)
	nameBox:gSetPos(12, 12)
	nameBox:gSetSize(430, 46)
	nameBox.Paint = function(selff, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_FIELD)
		if IsValid(selff.entry) and selff.entry:IsEditing() then
			RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
		end
	end
	local sPlaceholder = "Nom du grade (" .. (CFG.RankNameMinLen or 2) .. " à " .. (CFG.RankNameMaxLen or 24) .. " caractères)..."
	local entry = vgui.Create("DTextEntry", nameBox)
	entry:Dock(FILL)
	entry:DockMargin(gRespX(12), 0, gRespX(12), 0)
	entry:SetFont(F_HINT)
	entry:SetDrawLanguageID(false)
	entry:SetDrawBackground(false)
	entry:SetDrawBorder(false)
	entry:SetTextColor(COL_TXT)
	entry:SetUpdateOnType(true)
	entry:SetValue(rankDraftName) -- re-remplit le brouillon si un rebuild est passé
	entry.OnValueChange = function(self2) rankDraftName = self2:GetValue() end
	entry.Paint = function(self2, w, h)
		if not self2:HasFocus() and self2:GetValue() == "" then
			draw.SimpleText(sPlaceholder, F_HINT, 0, h / 2, COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
		end
	end
	nameBox.entry = entry

	local chipScroll = attachPermChips(create, function() return rankDraftPerms end, function(n)
		rankDraftPerms = n
	end)

	local btnCreate = MakeBtn(create, 0, 0, 170, 46, "CRÉER", F_BTN_SMALL, "primary", function()
		local sName = string.Trim(rankDraftName or "")
		if (utf8.len(sName) or #sName) < (CFG.RankNameMinLen or 2) then
			chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Choisis un nom de grade (min " .. (CFG.RankNameMinLen or 2) .. " caractères).")
			return
		end
		sendAction("rank_create", sName, rankDraftPerms)
		rankDraftName, rankDraftPerms = "", 0 -- brouillon consommé
		if IsValid(entry) then entry:SetValue("") end
	end)
	create.PerformLayout = function(_, w, h)
		btnCreate:SetPos(w - gRespX(170) - gRespX(12), gRespY(12))
		chipScroll:SetPos(gRespX(12), gRespY(68))
		chipScroll:SetSize(math.max(0, w - gRespX(24)), gRespY(38))
	end
end

-- Popup RENOMMER LE CLAN (leader) : champ + confirmer. Mêmes bornes que la
-- création ; tout revalidé serveur (longueur, caractères, filtre, unicité).
local pRename
local function OpenRenameClanPopup()
	if IsValid(pRename) then pRename:Remove() end
	local nCost = CFG.RenameCost or 50000
	local nPot = (STATE and tonumber(STATE.pot)) or 0
	local W, H = 560, 240
	local frame = vgui.Create("DFrame")
	pRename = frame
	frame:gSetSize(W, H)
	local fw = frame:GetWide()
	frame:SetPos((ScrW() - fw) / 2, ScrH() * 0.28)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, gRespY(14))
			RNDX.Draw(0, 0, 0, w - gRespY(14), gRespY(4), COL_ACCENT)
		else
			RNDX.Draw(0, 0, 0, w, h, COL_CARD)
			RNDX.Draw(0, 0, 0, w, gRespY(4), COL_ACCENT)
		end
		draw.SimpleText("RENOMMER LE CLAN", F_SUBTITLE, w * 0.5, gRespY(32), COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		MUGEN.DrawMoneyLine("Coût : " .. string.Comma(nCost) .. " ¥ (banque du clan)", F_HINT, w * 0.5, gRespY(62),
			nPot >= nCost and COL_TXT_DIM or COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local rnBox = vgui.Create("DPanel", frame)
	rnBox:gSetPos(28, 84)
	rnBox:gSetSize(W - 56, 46)
	rnBox.Paint = function(selff, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_FIELD)
		if IsValid(selff.entry) and selff.entry:IsEditing() then
			RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
		end
	end
	local sPh = "Nouveau nom (" .. (CFG.ClanNameMinLen or 3) .. " à " .. (CFG.ClanNameMaxLen or 24) .. " caractères)..."
	local rnEntry = vgui.Create("DTextEntry", rnBox)
	rnEntry:Dock(FILL)
	rnEntry:DockMargin(gRespX(12), 0, gRespX(12), 0)
	rnEntry:SetFont(F_HINT)
	rnEntry:SetDrawLanguageID(false)
	rnEntry:SetDrawBackground(false)
	rnEntry:SetDrawBorder(false)
	rnEntry:SetTextColor(COL_TXT)
	rnEntry:SetUpdateOnType(true)
	rnEntry.Paint = function(self2, w, h)
		if not self2:HasFocus() and self2:GetValue() == "" then
			draw.SimpleText(sPh, F_HINT, 0, h / 2, COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
		end
	end
	rnBox.entry = rnEntry
	timer.Simple(0, function() if IsValid(rnEntry) then rnEntry:RequestFocus() end end)

	local function close()
		if IsValid(frame) then frame:Remove() end
		if pRename == frame then pRename = nil end
	end
	MakeBtn(frame, 28, 154, 230, 54, "ANNULER", F_BTN, "neutral", close)
	MakeBtn(frame, W - 28 - 230, 154, 230, 54, "CONFIRMER  " .. string.Comma(nCost) .. " ¥", F_BTN,
		nPot >= nCost and "primary" or "neutral", function()
		local sName = string.Trim(rnEntry:GetValue() or "")
		if (utf8.len(sName) or #sName) < (CFG.ClanNameMinLen or 3) then
			clanCreatePopup("Choisis un nom de clan (min " .. (CFG.ClanNameMinLen or 3) .. " caractères).")
			return
		end
		local nBank = (STATE and tonumber(STATE.pot)) or 0
		if nBank < nCost then
			clanCreatePopup("Banque insuffisante : renommer le clan coûte " .. string.Comma(nCost)
				.. " ¥ (banque : " .. string.Comma(nBank) .. " ¥).")
			return
		end
		sendAction("rename", sName, 0)
		close()
	end)
end

local function BuildClanTab(content)
	content:Clear()
	local st = STATE
	if not st then
		-- Premier open : STATE encore nil tant que evo_clan:state n'est pas arrivé.
		-- Sans ça l'onglet Mon Clan reste VIDE (il fallait rouvrir pour voir le cache).
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du clan...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestState()
		return
	end

	if (st.myKey or "") == "" then
		-- FONDER UN CLAN (bascule modèle famille) : nom libre + niveau min + coût.
		-- Tout est revalidé serveur (filtre de mots, nom libre, faction, yens).
		local lp = LocalPlayer()
		local nMyLevel = lp:GetEvoNWInt("Level", 0)
		local nMyMoney = lp:GetEvoNWInt("Money", 0)
		local nMinLvl  = CFG.CreateMinLevel or 30
		local nCost    = CFG.CreateCost or 200000
		local bCanLevel = nMyLevel >= nMinLvl
		local bCanMoney = nMyMoney >= nCost
		local bCanCreate = bCanLevel and bCanMoney

		local form = vgui.Create("DPanel", content)
		form:Dock(FILL)
		form:SetPaintBackground(false)
		form.Paint = function(_, w, h)
			draw.SimpleText("FONDER UN CLAN", F_SUBTITLE, w * 0.5, gRespY(26), COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine("Niveau " .. nMinLvl .. " requis  ·  " .. string.Comma(nCost) .. " ¥",
				F_LABEL, w * 0.5, gRespY(74), bCanCreate and COL_TXT_DIM or COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if not bCanLevel then
				draw.SimpleText("Tu es niveau " .. nMyLevel .. ".", F_HINT, w * 0.5, gRespY(104), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			elseif not bCanMoney then
				MUGEN.DrawMoneyLine("Il te manque " .. string.Comma(nCost - nMyMoney) .. " ¥.",
					F_HINT, w * 0.5, gRespY(104), COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			draw.SimpleText("Ou fais-toi inviter par un clan existant (va voir un leader).",
				F_HINT, w * 0.5, h - gRespY(28), COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		-- Champ nom (DA sombre, soulignement accent quand actif).
		local nameBox = vgui.Create("DPanel", form)
		nameBox.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_ROW)
			if IsValid(selff.entry) and selff.entry:IsEditing() then
				RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
			end
		end
		local nameEntry = vgui.Create("DTextEntry", nameBox)
		nameEntry:Dock(FILL)
		nameEntry:DockMargin(gRespX(16), 0, gRespX(16), 0)
		nameEntry:SetFont(F_ROW)
		nameEntry:SetDrawLanguageID(false)
		nameEntry:SetDrawBackground(false)
		nameEntry:SetDrawBorder(false)
		nameEntry:SetTextColor(COL_TXT)
		nameEntry:SetUpdateOnType(true)
		nameEntry.Paint = function(self2, w, h)
			if not self2:HasFocus() and self2:GetValue() == "" then
				draw.SimpleText("Nom du clan (" .. (CFG.ClanNameMinLen or 3) .. " à " .. (CFG.ClanNameMaxLen or 24) .. " caractères)...",
					F_HINT, 0, h / 2, Color(255, 255, 255, 64), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			else
				self2:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
			end
		end
		nameBox.entry = nameEntry

		local btnCreate = MakeBtn(form, 0, 0, 0, 0, "FONDER  " .. string.Comma(nCost) .. " ¥",
			F_BTN, bCanCreate and "primary" or "neutral", function()
				if not bCanLevel then
					clanCreatePopup("Il faut être niveau " .. nMinLvl .. " pour fonder un clan (tu es niveau " .. nMyLevel .. ").")
					return
				end
				if not bCanMoney then
					clanCreatePopup("Yens insuffisants : fonder un clan coûte " .. string.Comma(nCost) .. " ¥.")
					return
				end
				local sName = string.Trim(nameEntry:GetValue() or "")
				if (utf8.len(sName) or #sName) < (CFG.ClanNameMinLen or 3) then
					clanCreatePopup("Choisis un nom (min " .. (CFG.ClanNameMinLen or 3) .. " caractères).")
					return
				end
				sendAction("create", sName, 0)
			end)

		form.PerformLayout = function(_, w, h)
			local fw = math.min(gRespX(520), w - gRespX(40))
			nameBox:SetSize(fw, gRespY(54))
			nameBox:SetPos((w - fw) * 0.5, gRespY(150))
			btnCreate:SetSize(fw, gRespY(60))
			btnCreate:SetPos((w - fw) * 0.5, gRespY(220))
		end
		return
	end

	-- En-tête : nom du clan + faction + compteur membres.
	-- Mon GRADE personnalisé (affiché à droite si ni leader ni bras droit) :
	-- précalculé AVANT le Paint (0 allocation par frame).
	local sMyRankUp = ""
	if not st.isLeader and not st.isOfficer then
		local sMyUID0 = LocalPlayer():GetEvoNWString("Character::Unique::ID", "none")
		for _, m in ipairs(st.members or {}) do
			if m.uid == sMyUID0 then
				if (m.rankName or "") ~= "" then sMyRankUp = string.upper(m.rankName) end
				break
			end
		end
	end
	local head = vgui.Create("DPanel", content)
	head:SetTall(gRespY(86))
	head:Dock(TOP)
	head:SetPaintBackground(false)
	local sClanTitle = "CLAN " .. string.upper(st.myLabel or "")
	-- Boost XP total : +1 % par AUTRE membre en ligne. Précalculé (0 alloc/frame).
	local nCount = istable(st.members) and #st.members or 0
	local nBoostFrac = tonumber(st.boostOnline)
	if nBoostFrac == nil then
		local nOnline = 0
		for _, m in ipairs(st.members or {}) do
			if m.online then nOnline = nOnline + 1 end
		end
		nBoostFrac = EVO_CLAN.OnlineXPBoostFrac(math.max(0, nOnline - 1))
	end
	local nBoostPct = math.floor(nBoostFrac * 100 + 0.5)
	local sBoost = "BOOST XP +" .. nBoostPct .. "%"
	local colBoost = nBoostPct > 0 and COL_GREEN or COL_TXT_DIM
	local sRole, colRole = "", COL_TXT_DIM
	if st.isLeader then
		sRole, colRole = "TU ES LE LEADER", COL_ACCENT
	elseif st.isOfficer then
		sRole, colRole = "TU ES LE BRAS DROIT", Color(224, 178, 58)
	elseif sMyRankUp ~= "" then
		sRole, colRole = "GRADE : " .. sMyRankUp, COL_GREEN
	end
	surface.SetFont(F_ROW_SUB)
	local nRoleW = (sRole ~= "") and surface.GetTextSize(sRole) or 0
	-- Bouton RENOMMER (leader) sur la même rangée que le nom : ouvre un popup.
	local btnRename
	if st.isLeader then
		btnRename = MakeBtn(head, 0, 0, 140, 40, "RENOMMER", F_BTN_SMALL, "neutral", OpenRenameClanPopup)
	end
	head.Paint = function(_, w, h)
		-- Puce brush accent devant le nom du clan (signature Atelier).
		local nTx = 0
		surface.SetFont(F_SUBTITLE)
		local _, thS = surface.GetTextSize("A")
		local bw2, bh2 = gRespX(26), gRespY(13)
		if EVO_UI and EVO_UI.Ink and EVO_UI.Ink("evo_ui/tex/brush1.png", 0, gRespY(4) + thS / 2 - bh2 / 2, bw2, bh2, ColorAlpha(COL_ACCENT, 230)) then
			nTx = gRespX(34)
		end
		-- Laisse de la place au bouton RENOMMER + compteur MEMBRES à droite.
		local nRightReserve = gRespX(200) + (IsValid(btnRename) and gRespX(156) or 0)
		local sTitleDraw = truncText(sClanTitle, F_SUBTITLE, math.max(gRespX(120), w - nTx - nRightReserve))
		draw.SimpleText(sTitleDraw, F_SUBTITLE, nTx, gRespY(4), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText((st.myFaction or "") .. "  ·  NIVEAU " .. (st.clanLevel or 1) .. " / " .. (st.clanLevelMax or 3), F_ROW_SUB, nTx, gRespY(48), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("MEMBRES  " .. nCount .. " / " .. (st.cap or 15), F_LABEL, w, gRespY(12), COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		if sRole ~= "" then
			draw.SimpleText(sRole, F_ROW_SUB, w, gRespY(48), colRole, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			draw.SimpleText(sBoost, F_LABEL, w - nRoleW - gRespX(16), gRespY(48), colBoost, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		else
			draw.SimpleText(sBoost, F_LABEL, w, gRespY(48), colBoost, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
	end
	if IsValid(btnRename) then
		head.PerformLayout = function(_, w, h)
			btnRename:SetPos(w - gRespX(200) - gRespX(140) - gRespX(8), gRespY(6))
		end
	end

	-- DISSOLUTION SOUMISE AU STAFF (seuil de warns de clan atteint, user 09/15) : bandeau
	-- visible par tous les membres ; la décision appartient à un superadmin. Créé AVANT
	-- foot/scroll (dock TOP dans l'ordre de création, cf. commentaire plus bas).
	local nSpellLock = EVO_CLAN.ClanWarnSpellLockAt and EVO_CLAN.ClanWarnSpellLockAt() or 3
	local bSpellLocked = nSpellLock > 0 and (st.warns or 0) >= nSpellLock
	if (st.disbandReq or "") == "pending" then
		local warnp = vgui.Create("DPanel", content)
		warnp:SetTall(gRespY(44))
		warnp:Dock(TOP)
		warnp:DockMargin(0, gRespY(4), 0, 0)
		warnp:SetPaintBackground(false)
		local sMsg = "DISSOLUTION DU CLAN SOUMISE AU STAFF : " .. string.upper(tostring(st.disbandReason or ""))
		if bSpellLocked then sMsg = sMsg .. " — SORT DE CLAN DÉSACTIVÉ" end
		warnp.Paint = function(_, w, h)
			RNDX.Draw(gRespX(6), 0, 0, w, h, COL_ACCENT_SOFT)
			RNDX.Draw(0, 0, 0, gRespX(3), h, COL_ACCENT)
			draw.SimpleText(truncText(sMsg, F_ROW_SUB, w - gRespX(30)), F_ROW_SUB, gRespX(16), h * 0.5, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	elseif bSpellLocked then
		local warnp = vgui.Create("DPanel", content)
		warnp:SetTall(gRespY(44))
		warnp:Dock(TOP)
		warnp:DockMargin(0, gRespY(4), 0, 0)
		warnp:SetPaintBackground(false)
		local sMsg = "SORT DE CLAN DÉSACTIVÉ : " .. (st.warns or 0) .. " WARN" .. ((st.warns or 0) > 1 and "S" or "") .. " ACTIFS"
		warnp.Paint = function(_, w, h)
			RNDX.Draw(gRespX(6), 0, 0, w, h, COL_ACCENT_SOFT)
			RNDX.Draw(0, 0, 0, gRespX(3), h, COL_ACCENT)
			draw.SimpleText(truncText(sMsg, F_ROW_SUB, w - gRespX(30)), F_ROW_SUB, gRespX(16), h * 0.5, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	-- (Banque + historique = onglet BANQUE. Améliorations = UPGRADES. Grades = GRADES.)

	-- Boutons bas : INVITER (leader) + QUITTER. Créés AVANT la liste : le dock
	-- traite les enfants dans l'ordre de création -> un FILL créé avant un
	-- BOTTOM consommerait tout le rect et écraserait la barre de boutons.
	local foot = vgui.Create("DPanel", content)
	foot:SetTall(gRespY(62))
	foot:Dock(BOTTOM)
	foot:SetPaintBackground(false)

	-- Liste des membres.
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	scroll:DockMargin(0, gRespY(8), 0, gRespY(14))
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll -- restauration du scroll au re-rend (cf. RebuildContent)
	local myUID = LocalPlayer():GetEvoNWString("Character::Unique::ID", "none")
	for _, d in ipairs(st.members or {}) do
		memberRow(scroll, d, st, myUID)
	end
	-- INVITER : leader OU permission INVITER d'un grade (la liste st.invitable
	-- n'est envoyée par le serveur que dans ces cas ; revalidé à l'invite).
	if st.isLeader or hasPermC(st.myPerms, PERM.INVITE) then
		-- Liste déroulante DA des joueurs invitables (ancrée sur le bouton).
		local btnInvite
		btnInvite = MakeBtn(foot, 0, 0, 380, 62, "INVITER UN JOUEUR", F_BTN, "primary", function()
			local tInv = st.invitable or {}
			if #tInv == 0 then
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT,
					"Personne à inviter AUTOUR de toi (même faction, sans clan) — rapproche-toi du joueur.")
				return
			end
			local items = {}
			for _, e in ipairs(tInv) do
				items[#items + 1] = { label = e.name, id = e.idx }
			end
			StyledDropdown(btnInvite, items, function(nIdx)
				net.Start("evo_clan:invite")
				net.WriteInt(nIdx, 16)
				net.SendToServer()
			end, true) -- avec RECHERCHE (tape le début du nom)
		end)
	end
	local btnLeave = MakeBtn(foot, 0, 0, 300, 62, "QUITTER LE CLAN", F_BTN, "danger", function()
		-- Miroir du garde serveur : le leader avec d'autres membres doit
		-- transmettre le lead (bouton NOMINER LEADER sur une rangée) avant.
		local nCount = istable(st.members) and #st.members or 0
		if st.isLeader and nCount > 1 then
			chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT,
				"Tu es le leader : transmets d'abord le lead à quelqu'un d'autre avant de quitter.")
			return
		end
		sendAction("leave", "", 0)
	end)
	foot.PerformLayout = function(_, w, h)
		btnLeave:SetPos(w - gRespX(300), 0)
	end
end

-- ── Onglet GRADES (création / suppression — leader) ─────────────────────────
local function BuildGradesTab(content)
	content:Clear()
	local st = STATE
	if not st then
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du clan...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestState()
		return
	end
	if (st.myKey or "") == "" then
		local lbl = vgui.Create("DPanel", content)
		lbl:Dock(FILL)
		lbl:SetPaintBackground(false)
		lbl.Paint = function(_, w, h)
			draw.SimpleText("Rejoins un clan pour gérer ses grades.", F_SUBTITLE, w * 0.5, h * 0.4, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end
	if not st.isLeader then
		-- Lecture seule : liste des grades existants (assignation = bouton GRADE
		-- sur les membres, réservée au leader).
		local scroll = vgui.Create("DScrollPanel", content)
		scroll:Dock(FILL)
		StyleScrollBar(scroll)
		pClan.contentScroll = scroll
		local tRanks = istable(st.ranks) and st.ranks or {}
		local head = vgui.Create("DPanel", scroll)
		head:SetTall(gRespY(40))
		head:Dock(TOP)
		head:SetPaintBackground(false)
		head.Paint = function(_, _, h)
			drawBrushLabel("GRADES DU CLAN (" .. #tRanks .. ")", F_LABEL, 0, h, COL_TXT_DIM)
		end
		if #tRanks == 0 then
			local empty = vgui.Create("DPanel", scroll)
			empty:SetTall(gRespY(80))
			empty:Dock(TOP)
			empty:SetPaintBackground(false)
			empty.Paint = function(_, w, h)
				draw.SimpleText("Aucun grade pour l'instant — seul le leader peut en créer.", F_HINT, w * 0.5, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		for _, rk in ipairs(tRanks) do
			local row = vgui.Create("DPanel", scroll)
			row:SetTall(gRespY(64))
			row:Dock(TOP)
			row:DockMargin(0, gRespY(6), gRespX(6), 0)
			row:SetPaintBackground(false)
			local nMembers = rk.members or 0
			local sName = truncText(string.upper(rk.name or ""), F_ROW, gRespX(430))
			local sSub = truncText(permSummary(rk.perms) .. "  ·  " .. nMembers .. " membre" .. (nMembers > 1 and "s" or ""),
				F_ROW_SUB, gRespX(CARD_W - 80))
			row.Paint = function(selff, w, h)
				RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
				draw.SimpleText(sName, F_ROW, gRespX(16), gRespY(8), COL_GREEN, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(sSub, F_ROW_SUB, gRespX(16), gRespY(38), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
		end
		return
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll
	BuildRanksSection(scroll, st)
end

-- ── Contenu : vue ADMINISTRATION (SA) ───────────────────────────────────────

local function adminClanRow(parent, d)
	-- DISSOLUTION À VALIDER (seuil de warns de clan atteint, user 09/15) : liseré rouge,
	-- bandeau, et une 4e ligne de boutons VALIDER LA DISSOLUTION / GARDER LE CLAN.
	local bDisPending = (d.disbandReq or "") == "pending"
	local row = vgui.Create("DPanel", parent)
	row:SetTall(gRespY(130) + (bDisPending and gRespY(44) or 0))
	row:Dock(TOP)
	row:DockMargin(0, 0, gRespX(6), gRespY(8))
	row:SetPaintBackground(false)
	-- 2 lignes de texte à GAUCHE, tronquées AVANT la zone des boutons (3 rangées
	-- à droite) : jamais de chevauchement, même nom long.
	local bHasLeader = d.leader and d.leader ~= ""
	local nWarns = d.warns or 0
	local nTextW = gRespX(CARD_W - 560)
	local sTitle = truncText(string.upper(d.label), F_ROW, nTextW)
	local sSub = truncText(d.faction .. "  ·  " .. d.count .. " / " .. (d.cap or 15)
		.. "  ·  Niv." .. (d.level or 1)
		.. "  ·  " .. nWarns .. ((d.warnsMax or 0) > 0 and ("/" .. d.warnsMax) or "") .. " warn" .. (nWarns > 1 and "s" or "")
		.. "  ·  Leader : " .. (bHasLeader and d.leader or "aucun"), F_ROW_SUB, nTextW)
	-- Demande de spell unique EN ATTENTE : bandeau bien visible (2e ligne de sous-titre).
	local bPending = (d.spellReq or "") == "pending"
	row.Paint = function(selff, w, h)
		RNDX.Draw(0, 0, 0, w, h, (sInspect == d.key or panel_contains_cursor(selff)) and COL_ROW_HOV or COL_ROW)
		if sInspect == d.key then
			RNDX.Draw(0, 0, 0, gRespX(3), h, COL_ACCENT)
		elseif bDisPending then
			RNDX.Draw(0, 0, 0, gRespX(3), h, COL_ACCENT) -- liseré rouge = dissolution à valider
		elseif bPending then
			RNDX.Draw(0, 0, 0, gRespX(3), h, Color(224, 178, 58)) -- liseré doré = demande à traiter
		end
		draw.SimpleText(sTitle, F_ROW, gRespX(16), gRespY(12), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(sSub, F_ROW_SUB, gRespX(16), gRespY(48),
			(nWarns > 0 or not bHasLeader) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if bPending then
			draw.SimpleText("DEMANDE DE SPELL UNIQUE EN ATTENTE", F_ROW_SUB, gRespX(16), gRespY(82), Color(224, 178, 58), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		if bDisPending then
			draw.SimpleText(truncText("DISSOLUTION À VALIDER : " .. string.upper(tostring(d.disbandReason or "")), F_ROW_SUB, nTextW),
				F_ROW_SUB, gRespX(16), gRespY(bPending and 106 or 82), COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	-- Boutons : NOMMER LEADER / RETIRER LEADER / MEMBRES (affiche le roster du
	-- clan en dessous, avec EXCLURE sur chaque membre).
	local btnSee = MakeBtn(row, 0, 0, 130, 38, "MEMBRES", F_BTN_SMALL, "neutral", function()
		sInspect = (sInspect == d.key) and "" or d.key
		requestState()
	end)
	local btnRem = MakeBtn(row, 0, 0, 185, 38, "RETIRER LEADER", F_BTN_SMALL, "danger", function()
		sendAction("sa_removeleader", d.key, 0)
	end)
	-- Liste déroulante DA des joueurs en ligne de la faction (ancrée au bouton).
	local btnSet
	btnSet = MakeBtn(row, 0, 0, 195, 38, "NOMMER LEADER", F_BTN_SMALL, "neutral", function()
		local items = {}
		for _, p in player.Iterator() do
			if IsValid(p) and p:GetEvoNWString("FactionName", "") == d.faction
				and p:GetEvoNWString("Character::Unique::ID", "none") ~= "none" then
				local nm = p:GetEvoNWString("Nickname", "")
				if nm == "" then nm = p:Nick() end
				items[#items + 1] = { label = nm, id = p:EntIndex() }
			end
		end
		if #items == 0 then
			chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Aucun joueur " .. d.faction .. " en ligne.")
			return
		end
		table.sort(items, function(a, b) return a.label < b.label end)
		StyledDropdown(btnSet, items, function(nIdx)
			sendAction("sa_setleader", d.key, nIdx)
		end, true) -- avec RECHERCHE (tape le début du nom)
	end)
	-- 2e rangée (SA) : VICTOIRES DE TOURNOI + WARNS DE CLAN (+1 / -1 chacun).
	-- Le compteur de warns pilote le prérequis « 0 warn » de la demande de spell.
	local btnWinP = MakeBtn(row, 0, 0, 140, 32, "+1 VICT.", F_BTN_SMALL, "neutral", function()
		sendAction("sa_tourneywin", d.key, 1)
	end)
	local btnWinM = MakeBtn(row, 0, 0, 40, 32, "-1", F_BTN_SMALL, "danger", function()
		sendAction("sa_tourneywin", d.key, -1)
	end)
	local btnWarnP = MakeBtn(row, 0, 0, 140, 32, "+1 WARN", F_BTN_SMALL, "danger", function()
		sendAction("sa_warn", d.key, 1)
	end)
	local btnWarnM = MakeBtn(row, 0, 0, 40, 32, "-1", F_BTN_SMALL, "neutral", function()
		sendAction("sa_warn", d.key, -1)
	end)
	-- 3e rangée : DISSOUDRE + (si demande de spell EN ATTENTE) ACCEPTER / REFUSER.
	local btnDisband = MakeBtn(row, 0, 0, 150, 32, "DISSOUDRE", F_BTN_SMALL, "danger", function()
		if row._disbandArm and CurTime() < row._disbandArm then
			row._disbandArm = nil
			sendAction("sa_disband", d.key, 0)
		else
			row._disbandArm = CurTime() + 3
			chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Re-clique DISSOUDRE dans les 3 s pour confirmer la dissolution de « " .. d.label .. " ».")
		end
	end)
	local btnAccept, btnRefuse
	if bPending then
		btnAccept = MakeBtn(row, 0, 0, 165, 32, "ACCEPTER SPELL", F_BTN_SMALL, "primary", function()
			sendAction("sa_spell_decision", d.key, 1)
		end)
		btnRefuse = MakeBtn(row, 0, 0, 130, 32, "REFUSER", F_BTN_SMALL, "danger", function()
			sendAction("sa_spell_decision", d.key, 0)
		end)
	end
	-- 4e ligne : décision SA sur la dissolution en attente (user 09/15). VALIDER =
	-- 2 clics en 3 s (irréversible, même garde-fou que DISSOUDRE) ; GARDER = 1 clic.
	local btnDisYes, btnDisNo
	if bDisPending then
		btnDisYes = MakeBtn(row, 0, 0, 215, 32, "VALIDER LA DISSOLUTION", F_BTN_SMALL, "danger", function()
			if row._disDecArm and CurTime() < row._disDecArm then
				row._disDecArm = nil
				sendAction("sa_disband_decision", d.key, 1)
			else
				row._disDecArm = CurTime() + 3
				chat.AddText(COL_ACCENT, "[Clan] ", COL_TXT, "Re-clique VALIDER LA DISSOLUTION dans les 3 s pour dissoudre « " .. d.label .. " ».")
			end
		end)
		btnDisNo = MakeBtn(row, 0, 0, 165, 32, "GARDER LE CLAN", F_BTN_SMALL, "neutral", function()
			sendAction("sa_disband_decision", d.key, 0)
		end)
	end

	row.PerformLayout = function(_, w, h)
		local y1 = gRespY(8)
		btnSee:SetPos(w - gRespX(130) - gRespX(12), y1)
		btnRem:SetPos(w - gRespX(130) - gRespX(185) - gRespX(24), y1)
		btnSet:SetPos(w - gRespX(130) - gRespX(185) - gRespX(195) - gRespX(36), y1)
		-- 2e rangée : depuis la droite [-1 warn][+1 WARN]  [-1 vict][+1 VICT.].
		local y2 = gRespY(48)
		local x = w - gRespX(12)
		x = x - gRespX(40);  btnWarnM:SetPos(x, y2)
		x = x - gRespX(8) - gRespX(140);  btnWarnP:SetPos(x, y2)
		x = x - gRespX(22) - gRespX(40);  btnWinM:SetPos(x, y2)
		x = x - gRespX(8) - gRespX(140);  btnWinP:SetPos(x, y2)
		-- 3e rangée : DISSOUDRE à gauche du groupe décision (si demande en attente).
		local y3 = gRespY(88)
		local x3 = w - gRespX(12)
		if IsValid(btnRefuse) then
			x3 = x3 - gRespX(130);  btnRefuse:SetPos(x3, y3)
			x3 = x3 - gRespX(10) - gRespX(165);  btnAccept:SetPos(x3, y3)
			x3 = x3 - gRespX(22)
		end
		btnDisband:SetPos(x3 - gRespX(150), y3)
		-- 4e rangée : [GARDER LE CLAN] [VALIDER LA DISSOLUTION] depuis la droite.
		if IsValid(btnDisYes) then
			local y4 = gRespY(130)
			local x4 = w - gRespX(12)
			x4 = x4 - gRespX(165);  btnDisNo:SetPos(x4, y4)
			x4 = x4 - gRespX(10) - gRespX(215);  btnDisYes:SetPos(x4, y4)
		end
	end
	return row
end

local function BuildAdminTab(content)
	content:Clear()
	local st = STATE
	if not st then
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du clan...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestState()
		return
	end
	if not st.isSA then return end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll -- restauration du scroll au re-rend (cf. RebuildContent)

	-- Compte les demandes de spell EN ATTENTE (liseré doré sur les cartes concernées).
	local nPendingReq, nDisPending = 0, 0
	for _, d in ipairs(st.admin or {}) do
		if (d.spellReq or "") == "pending" then nPendingReq = nPendingReq + 1 end
		if (d.disbandReq or "") == "pending" then nDisPending = nDisPending + 1 end
	end
	local lbl = vgui.Create("DPanel", scroll)
	lbl:SetTall(gRespY(38))
	lbl:Dock(TOP)
	lbl:SetPaintBackground(false)
	lbl.Paint = function(_, w, h)
		drawBrushLabel("CLANS DU SERVEUR : leader / warns / dissolution", F_LABEL, 0, h, COL_TXT_DIM)
		-- À droite : dissolutions à valider (rouge, prioritaire) puis demandes de spell.
		local sRight = ""
		if nDisPending > 0 then
			sRight = nDisPending .. " DISSOLUTION" .. (nDisPending > 1 and "S" or "") .. " À VALIDER"
		end
		if nPendingReq > 0 then
			sRight = sRight .. (sRight ~= "" and "  ·  " or "")
				.. nPendingReq .. " DEMANDE" .. (nPendingReq > 1 and "S" or "") .. " DE SPELL EN ATTENTE"
		end
		if sRight ~= "" then
			draw.SimpleText(sRight, F_ROW_SUB, w, h * 0.5, nDisPending > 0 and COL_ACCENT or Color(224, 178, 58), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	-- Interrupteur GLOBAL : autorise/coupe la distribution des coffres par les
	-- leaders (persisté en BDD partagée, revalidé serveur au give).
	local bRewOn = st.rewardsEnabled ~= false
	local swp = vgui.Create("DPanel", scroll)
	swp:SetTall(gRespY(56))
	swp:Dock(TOP)
	swp:DockMargin(0, gRespY(4), gRespX(6), gRespY(8))
	swp:SetPaintBackground(false)
	swp.Paint = function(_, w, h)
		RNDX.Draw(0, 0, 0, w, h, COL_ROW)
		draw.SimpleText("COFFRES DES LEADERS :", F_ROW_SUB, gRespX(16), h * 0.5, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(bRewOn and "ACTIVÉS" or "COUPÉS", F_ROW_SUB, gRespX(300), h * 0.5,
			bRewOn and COL_GREEN or COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local swBtn
	swBtn = MakeBtn(swp, 0, 0, 250, 42, bRewOn and "COUPER" or "ACTIVER", F_BTN_SMALL, "primary", function()
		sendAction("sa_rewards_toggle", "", 0)
	end)
	swp.PerformLayout = function(_, w, h)
		swBtn:SetPos(w - gRespX(250) - gRespX(12), (h - gRespY(42)) / 2)
	end

	for _, d in ipairs(st.admin or {}) do
		adminClanRow(scroll, d)
	end

	-- Roster inspecté (VOIR) : membres du clan sélectionné, EXCLURE pour tous
	-- (SA peut retirer n'importe qui, leader compris — revalidé serveur).
	if st.inspectKey and istable(st.inspect) then
		local lbl2 = vgui.Create("DPanel", scroll)
		lbl2:SetTall(gRespY(44))
		lbl2:Dock(TOP)
		lbl2:DockMargin(0, gRespY(10), 0, 0)
		lbl2:SetPaintBackground(false)
		local sInspectLabel = st.inspectLabel or st.inspectKey
		lbl2.Paint = function(_, w, h)
			drawBrushLabel("MEMBRES : " .. string.upper(sInspectLabel), F_LABEL, 0, h, COL_ACCENT)
		end
		if #st.inspect == 0 then
			local none = vgui.Create("DPanel", scroll)
			none:SetTall(gRespY(38))
			none:Dock(TOP)
			none:SetPaintBackground(false)
			none.Paint = function(_, w, h)
				draw.SimpleText("Aucun membre.", F_HINT, 0, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		for _, d in ipairs(st.inspect) do
			local row = vgui.Create("DPanel", scroll)
			row:SetTall(gRespY(66))
			row:Dock(TOP)
			row:DockMargin(0, 0, gRespX(6), gRespY(8))
			row:SetPaintBackground(false)
			local sName = truncText(d.name, F_ROW, gRespX(CARD_W - 330))
			row.Paint = function(selff, w, h)
				RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
				draw.NoTexture()
				surface.SetDrawColor(d.online and COL_GREEN or COL_OFFLINE)
				surface.DrawTexturedRectRotated(gRespX(18), h * 0.5, gRespX(9), gRespX(9), 45)
				draw.SimpleText(sName .. (d.isLeader and "   (LEADER)" or (d.isOfficer and "   (BRAS DROIT)" or "")), F_ROW_SUB, gRespX(36), h * 0.5,
					d.isLeader and COL_ACCENT or (d.isOfficer and Color(224, 178, 58) or COL_TXT), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			local btnKick = MakeBtn(row, 0, 0, 130, 46, "EXCLURE", F_BTN_SMALL, "danger", function()
				sendAction("kick", d.uid, 0)
			end)
			row.PerformLayout = function(_, w, h)
				btnKick:SetPos(w - gRespX(130) - gRespX(12), (h - gRespY(46)) / 2)
			end
		end
	end
end

-- ── Contenu : vue UPGRADES (pot commun + objectifs + récompenses de dons) ───

-- Éligibilité HEBDO d'un membre aux coffres : temps de jeu ET dons DE LA
-- SEMAINE (reset chaque semaine ; revalidé serveur au give).
local function isWeeklyEligible(d)
	return (d.weekPlay or 0) >= (CFG.RewardMinWeeklyPlaytime or 0)
		and (d.weekDon or 0) >= (CFG.RewardMinWeeklyDons or 0)
end

local function fmtHours(nSec)
	nSec = nSec or 0
	return math.floor(nSec / 3600) .. "h" .. string.format("%02d", math.floor((nSec % 3600) / 60))
end

-- ── Section DEMANDE DE SPELL UNIQUE (onglet UPGRADES) ───────────────────────
-- Checklist des prérequis (calculés SERVEUR, st.spellReq) + bouton de demande
-- (leader/bras droit). Le niveau 3 débloque l'accès ; les autres prérequis
-- gèrent l'éligibilité. La demande validée part en file d'attente SA.
local function BuildSpellRequestSection(scroll, st)
	local req = st.spellReq
	if not istable(req) then return end
	local bCanAsk = st.isLeader or st.isOfficer
	local sStatus = req.status or ""
	local tChecks = {
		{ ok = req.checks.level,   label = "Clan niveau " .. req.minLevel,                              val = "Niv. " .. req.level },
		{ ok = req.checks.members, label = req.minMembers .. " membres",                                 val = req.members .. " / " .. req.minMembers },
		{ ok = req.checks.high,    label = req.minHigh .. " membres niveau " .. req.threshold .. "+",    val = req.high .. " / " .. req.minHigh },
		{ ok = req.checks.warns,   label = "Aucun warn de clan actif (7 j)",                             val = req.warns .. " actif" .. (req.warns > 1 and "s" or "") },
		{ ok = req.checks.age,     label = "1 semaine d'existence",                                      val = req.ageDays .. " / " .. req.minAgeDays .. " j" },
	}
	local nOk = 0
	for _, c in ipairs(tChecks) do if c.ok then nOk = nOk + 1 end end

	-- En-tête : titre + progression X/5 + statut courant.
	local head = vgui.Create("DPanel", scroll)
	head:SetTall(gRespY(44))
	head:Dock(TOP)
	head:DockMargin(0, gRespY(16), gRespX(6), 0)
	head:SetPaintBackground(false)
	local sStatusTxt, colStatus
	if sStatus == "pending" then sStatusTxt, colStatus = "EN ATTENTE DE VALIDATION", Color(224, 178, 58)
	elseif sStatus == "accepted" then sStatusTxt, colStatus = "SPELL UNIQUE ACCORDÉ", COL_GREEN
	elseif sStatus == "refused" then sStatusTxt, colStatus = "DEMANDE REFUSÉE — RE-SOUMISSION POSSIBLE", COL_ACCENT end
	head.Paint = function(_, w, h)
		drawBrushLabel("DEMANDE DE SPELL UNIQUE", F_LABEL, 0, h, COL_TXT_DIM)
		local sProg = nOk .. " / " .. #tChecks .. " prérequis"
		if sStatusTxt then
			draw.SimpleText(sStatusTxt, F_ROW_SUB, w, h * 0.5, colStatus, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			surface.SetFont(F_ROW_SUB)
			local tw = surface.GetTextSize(sStatusTxt)
			draw.SimpleText(sProg, F_HINT, w - tw - gRespX(16), h * 0.5,
				nOk >= #tChecks and COL_GREEN or COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText(sProg, F_ROW_SUB, w, h * 0.5,
				nOk >= #tChecks and COL_GREEN or COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	for _, c in ipairs(tChecks) do
		local rowc = vgui.Create("DPanel", scroll)
		rowc:SetTall(gRespY(42))
		rowc:Dock(TOP)
		rowc:DockMargin(0, gRespY(6), gRespX(6), 0)
		rowc:SetPaintBackground(false)
		rowc.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_ROW)
			local col = c.ok and COL_GREEN or COL_ACCENT
			draw.NoTexture()
			surface.SetDrawColor(col)
			surface.DrawTexturedRectRotated(gRespX(24), h * 0.5, gRespX(11), gRespX(11), 45)
			draw.SimpleText(c.label, F_ROW, gRespX(48), h * 0.5, c.ok and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(c.val, F_ROW_SUB, w - gRespX(16), h * 0.5, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	if bCanAsk then
		local bCanSubmit = req.eligible and (sStatus == "" or sStatus == "refused")
		local btnRow = vgui.Create("DPanel", scroll)
		btnRow:SetTall(gRespY(60))
		btnRow:Dock(TOP)
		btnRow:DockMargin(0, gRespY(10), gRespX(6), 0)
		btnRow:SetPaintBackground(false)
		local sBtn = (sStatus == "pending") and "DEMANDE EN ATTENTE"
			or (sStatus == "accepted") and "SPELL UNIQUE OBTENU"
			or "FAIRE LA DEMANDE"
		local btn = MakeBtn(btnRow, 0, 0, 0, 0, sBtn, F_BTN, bCanSubmit and "primary" or "neutral", function()
			if sStatus == "pending" then
				clanCreatePopup("Une demande est déjà en attente de validation par le staff.")
				return
			elseif sStatus == "accepted" then
				clanCreatePopup("Ton clan a déjà obtenu son spell unique.")
				return
			elseif not req.eligible then
				clanCreatePopup("Tous les prérequis ne sont pas remplis (" .. nOk .. " / " .. #tChecks .. ").")
				return
			end
			sendAction("spell_request", "", 0)
		end)
		btnRow.PerformLayout = function(_, w, h)
			btn:SetSize(w - gRespX(6), h)
			btn:SetPos(0, 0)
		end
	end
end

local function BuildUpgradesTab(content)
	content:Clear()
	local st = STATE
	if not st then
		-- État serveur pas encore reçu : avant, `return` nu = onglet VIDE sans
		-- explication (« l'onglet ne marche pas »). Le push evo_clan:state re-rend.
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du clan...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestState()
		return
	end

	if (st.myKey or "") == "" then
		local lbl = vgui.Create("DPanel", content)
		lbl:Dock(FILL)
		lbl:SetPaintBackground(false)
		lbl.Paint = function(_, w, h)
			draw.SimpleText("Rejoins un clan pour accéder à ses améliorations.", F_SUBTITLE, w * 0.5, h * 0.4, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll -- restauration du scroll au re-rend (cf. RebuildContent)

	-- ── ACHATS (niveau / coffres / bâtiment / taxe) ──
	BuildPotSection(scroll, st)

	-- ── DEMANDE DE SPELL UNIQUE (checklist des prérequis + bouton) ──
	BuildSpellRequestSection(scroll, st)

	-- ── RÉCOMPENSES DE DONS ──
	-- Distribution ouverte au leader, au bras droit ET aux grades porteurs de
	-- la permission COFFRES (2026-07-23) — revalidé serveur au give.
	local bCanChests = st.isLeader or st.isOfficer or hasPermC(st.myPerms, PERM.CHESTS)
	local nMinPlay = CFG.RewardMinWeeklyPlaytime or (30 * 3600)
	local nMinDons = CFG.RewardMinWeeklyDons or 50000
	local nMaxPer = st.rewardMaxPer or 2
	local sEligHint = math.floor(nMinPlay / 3600) .. " h de jeu  ·  "
		.. string.Comma(nMinDons) .. " ¥ de dons cette semaine  ·  max " .. nMaxPer .. " coffres / membre"

	local rewHead = vgui.Create("DPanel", scroll)
	rewHead:SetTall(gRespY(64))
	rewHead:Dock(TOP)
	rewHead:DockMargin(0, gRespY(10), gRespX(6), 0)
	rewHead:SetPaintBackground(false)
	rewHead.Paint = function(_, w, h)
		drawBrushLabel("COFFRES DU CLAN", F_LABEL, 0, gRespY(30), COL_TXT_DIM)
		MUGEN.DrawMoneyLine(sEligHint, F_HINT, 0, h - gRespY(8), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if bCanChests then
			local tUsed = st.rewardUsed or {}
			local tQ = st.rewardQuotas or {}
			local tTxt = {}
			for _, c in ipairs(CFG.RewardChoices or {}) do
				local nQuota = tQ[c.chest] or c.weekly or 0
				if nQuota > 0 then
					tTxt[#tTxt + 1] = (c.short or c.label) .. " " .. (tUsed[c.chest] or 0) .. "/" .. nQuota
				end
			end
			if #tTxt > 0 then
				draw.SimpleText("Semaine : " .. table.concat(tTxt, "  ·  "), F_ROW_SUB, w, gRespY(14), COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	if st.rewardsEnabled == false then
		local off = vgui.Create("DPanel", scroll)
		off:SetTall(gRespY(48))
		off:Dock(TOP)
		off:DockMargin(0, gRespY(6), gRespX(6), 0)
		off:SetPaintBackground(false)
		off.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_ROW)
			RNDX.Draw(0, 0, 0, gRespX(4), h, COL_ACCENT)
			draw.SimpleText("DISTRIBUTION DES COFFRES DÉSACTIVÉE PAR LE STAFF", F_BTN_SMALL, gRespX(16), h * 0.5, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local myUID = LocalPlayer():GetEvoNWString("Character::Unique::ID", "none")

	if not bCanChests then
		-- Membre sans droit de distribution : SA progression hebdo + seuils.
		local dMine
		for _, d in ipairs(st.members or {}) do
			if d.uid == myUID then dMine = d break end
		end
		dMine = dMine or {}
		local bOk = isWeeklyEligible(dMine)
		local mine = vgui.Create("DPanel", scroll)
		mine:SetTall(gRespY(100))
		mine:Dock(TOP)
		mine:DockMargin(0, gRespY(6), gRespX(6), 0)
		mine:SetPaintBackground(false)
		mine.Paint = function(_, w, h)
			RNDX.Draw(0, 0, 0, w, h, COL_ROW)
			MUGEN.DrawMoneyLine("CETTE SEMAINE : " .. fmtHours(dMine.weekPlay) .. " DE JEU  ·  "
				.. string.Comma(dMine.weekDon or 0) .. " ¥ DE DONS",
				F_ROW, gRespX(16), gRespY(22), bOk and COL_GREEN or COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("COFFRES REÇUS : " .. (dMine.rewardCount or 0) .. " / " .. nMaxPer,
				F_ROW_SUB, gRespX(16), gRespY(52), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine("Seuils : " .. sEligHint, F_HINT, gRespX(16), h - gRespY(16), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(bOk and "ÉLIGIBLE" or "PAS ENCORE ÉLIGIBLE", F_ROW,
				w - gRespX(16), gRespY(36), bOk and COL_GREEN or COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		return
	end

	-- Tri UX : éligibles en ligne d'abord, puis éligibles hors ligne, puis le reste ;
	-- à l'intérieur de chaque groupe, dons hebdo décroissants.
	local function chestSortKey(d)
		local bEl = isWeeklyEligible(d)
		local nGroup = (bEl and d.online and 0) or (bEl and 1) or 2
		return nGroup, -(d.weekDon or 0)
	end
	local tSorted = {}
	for _, d in ipairs(st.members or {}) do tSorted[#tSorted + 1] = d end
	table.sort(tSorted, function(a, b)
		local ga, da = chestSortKey(a)
		local gb, db = chestSortKey(b)
		if ga ~= gb then return ga < gb end
		return da < db
	end)

	local tUsed = st.rewardUsed or {}

	for _, d in ipairs(tSorted) do
		local row = vgui.Create("DPanel", scroll)
		row:SetTall(gRespY(92))
		row:Dock(TOP)
		row:DockMargin(0, gRespY(8), gRespX(6), 0)
		row:SetPaintBackground(false)
		local bEligible = isWeeklyEligible(d)
		local nGot = d.rewardCount or 0
		local bCanGive = st.rewardsEnabled ~= false and bEligible and d.online and not d.rewarded
		local sStatus
		if st.rewardsEnabled == false then sStatus = "DISTRIBUTION COUPÉE"
		elseif d.rewarded then sStatus = "SERVI (" .. nGot .. "/" .. nMaxPer .. ")"
		elseif not bEligible then sStatus = "NON ÉLIGIBLE"
		elseif not d.online then sStatus = "HORS LIGNE"
		elseif bCanGive then sStatus = "ÉLIGIBLE"
		end
		local colStatus = (sStatus == "ÉLIGIBLE" or (sStatus and string.sub(sStatus, 1, 5) == "SERVI")) and COL_GREEN
			or (sStatus == "DISTRIBUTION COUPÉE" and COL_ACCENT or COL_TXT_DIM)

		-- Nom tronqué pour laisser la place au scroller de boutons (~320 px).
		local sName = truncText(d.name, F_ROW, gRespX(bCanGive and 320 or 420))
		row.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
			draw.SimpleText(sName, F_ROW, gRespX(16), gRespY(22), bEligible and COL_GREEN or COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine(fmtHours(d.weekPlay) .. " DE JEU  ·  " .. string.Comma(d.weekDon or 0) .. " ¥  ·  COFFRES " .. nGot .. "/" .. nMaxPer,
				F_ROW_SUB, gRespX(16), h - gRespY(20), bEligible and COL_GREEN or Color(224, 178, 58), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if sStatus and not bCanGive then
				draw.SimpleText(sStatus, F_BTN_SMALL, w - gRespX(16), h * 0.5, colStatus, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end

		if bCanGive then
			local chipScroll = vgui.Create("DHorizontalScroller", row)
			chipScroll:SetOverlap(gRespX(-6))
			chipScroll.Paint = function() end
			if IsValid(chipScroll.btnLeft) then
				chipScroll.btnLeft:SetWide(gRespX(16))
				chipScroll.btnLeft.Paint = function(selff, w, h)
					draw.SimpleText("‹", F_BTN_SMALL, w * 0.5, h * 0.5,
						panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			if IsValid(chipScroll.btnRight) then
				chipScroll.btnRight:SetWide(gRespX(16))
				chipScroll.btnRight.Paint = function(selff, w, h)
					draw.SimpleText("›", F_BTN_SMALL, w * 0.5, h * 0.5,
						panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			chipScroll.OnMouseWheeled = function(self2, delta)
				self2.OffsetX = math.Clamp((self2.OffsetX or 0) - delta * gRespX(48), 0,
					math.max(0, (self2.pnlCanvas and self2.pnlCanvas:GetWide() or 0) - self2:GetWide()))
				self2:InvalidateLayout(true)
				return true
			end
			local tQ = st.rewardQuotas or {}
			for i, c in ipairs(CFG.RewardChoices or {}) do
				local nQuota = tQ[c.chest] or c.weekly or 0
				if nQuota > 0 then
					local nRemain = nQuota - (tUsed[c.chest] or 0)
					local sLbl = (c.short or c.label) .. " (" .. math.max(nRemain, 0) .. ")"
					local bCan = nRemain > 0
					local chip = vgui.Create("DButton")
					chip:SetText("")
					chip:SetCursor("hand")
					chip:SetSize(gRespX(118), gRespY(44))
					chip.Paint = function(selff, w, h)
						local bHover = panel_contains_cursor(selff)
						if bCan then
							RNDX.Draw(0, 0, 0, w, h, bHover and COL_ACCENT_HOV or COL_ACCENT)
							draw.SimpleText(sLbl, F_BTN_SMALL, w * 0.5, h * 0.5, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							RNDX.Draw(0, 0, 0, w, h, bHover and COL_ROW_HOV or COL_FIELD)
							draw.SimpleText(sLbl, F_BTN_SMALL, w * 0.5, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end
					chip.DoClick = function()
						surface.PlaySound(SND_CLICK)
						if not bCan then
							clanCreatePopup("Quota épuisé pour ce coffre cette semaine.")
							return
						end
						sendAction("reward_give", d.uid, i)
					end
					chipScroll:AddPanel(chip)
				end
			end
			row.PerformLayout = function(_, w, h)
				local nScrollW = math.min(gRespX(420), math.max(gRespX(200), w * 0.48))
				chipScroll:SetSize(nScrollW, gRespY(44))
				chipScroll:SetPos(w - nScrollW - gRespX(10), (h - gRespY(44)) / 2)
			end
		end
	end
end

-- ── Contenu : vue CLASSEMENT DES CLANS (visible par tous) ───────────────────
-- Clans de la faction choisie (toggle SHINIGAMI/HOLLOW/TOUS), triés au
-- CLASSEMENT GÉNÉRAL (rang dans chaque colonne, somme — plus petit = mieux).
-- Médaillons or/argent/bronze, MON clan surligné accent. Agrégats sv (cache 60s).

local RebuildContent -- forward (les builders d'onglet re-rendent au clic)

local LB_COLS = {
	{ id = "hours",   label = "HEURES" },
	{ id = "kills",   label = "PNJ TUÉS" },
	{ id = "lvl",     label = "NIVEAUX" },
	{ id = "wins",    label = "TOURNOIS" }, -- victoires de tournoi de clan (montées par les SA)
	{ id = "battles", label = "BATAILLE" }, -- victoires de Bataille des Clans
	{ id = "pot",     label = "BANQUE", fmt = function(n) return string.Comma(n) .. "¥" end },
}
local LB_NAME_W = 230 -- zone rang + nom (design px) ; le reste = colonnes égales
local LB_MEDALS = {
	Color(224, 178, 58),  -- 1er : or
	Color(188, 194, 204), -- 2e : argent
	Color(176, 116, 66),  -- 3e : bronze
	Color(90, 90, 98),    -- 4e : acier sombre
}

local function lbColCenter(i, w)
	return gRespX(LB_NAME_W) + (w - gRespX(LB_NAME_W)) * (i - 0.5) / #LB_COLS
end

local function BuildLeaderboardTab(content)
	content:Clear()
	-- Filtres : TOUS en premier (défaut), puis ma faction. Les SA gardent aussi
	-- Shinigami / Hollow pour inspecter l'autre camp.
	local bSA = LocalPlayer():IsSuperAdmin()
	local sMyFac = (LocalPlayer():GetEvoNWString("FactionName", "") == "Hollow") and "Hollow" or "Shinigami"
	if lbFaction ~= "Shinigami" and lbFaction ~= "Hollow" and lbFaction ~= "all" then
		lbFaction = "all"
	elseif not bSA and lbFaction ~= sMyFac and lbFaction ~= "all" then
		-- Non-SA : pas d'accès à la faction adverse seule (seulement la sienne + TOUS).
		lbFaction = "all"
	end

	local tFacTabs
	if bSA then
		tFacTabs = {
			{ id = "all",       label = "TOUS" },
			{ id = "Shinigami", label = "SHINIGAMI" },
			{ id = "Hollow",    label = "HOLLOW" },
		}
	else
		tFacTabs = {
			{ id = "all",   label = "TOUS" },
			{ id = sMyFac, label = string.upper(sMyFac) },
		}
	end

	local togg = vgui.Create("DPanel", content)
	togg:SetTall(gRespY(58))
	togg:Dock(TOP)
	togg:SetPaintBackground(false)
	local nTabW = gRespX((#tFacTabs >= 3) and 200 or 230)
	local nTabGap = gRespX(14)
	for i, t in ipairs(tFacTabs) do
		local b = vgui.Create("DButton", togg)
		b:SetText("")
		b:SetCursor("hand")
		b:SetPos((i - 1) * (nTabW + nTabGap), 0)
		b:SetSize(nTabW, gRespY(48))
		b.Paint = function(selff, w, h)
			local bActive = lbFaction == t.id
			RNDX.Draw(0, 0, 0, w, h, bActive and COL_ROW_HOV or (panel_contains_cursor(selff) and COL_ACCENT_SOFT or COL_ROW))
			draw.SimpleText(t.label, F_TAB, w * 0.5, h * 0.5, bActive and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if bActive then RNDX.Draw(0, 0, h - gRespY(3), w, gRespY(3), COL_ACCENT) end
		end
		b.DoClick = function()
			lbFaction = t.id
			RebuildContent()
		end
	end

	if not LB_DATA then
		local wait = vgui.Create("DPanel", content)
		wait:Dock(FILL)
		wait:SetPaintBackground(false)
		wait.Paint = function(_, w, h)
			draw.SimpleText("Chargement du classement...", F_HINT, w * 0.5, h * 0.35, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		requestLeaderboard()
		return
	end

	-- En-têtes de colonnes (toutes comptent pour le rang, pas de tri au clic).
	local head = vgui.Create("DPanel", content)
	head:SetTall(gRespY(40))
	head:Dock(TOP)
	head:DockMargin(0, gRespY(6), 0, gRespY(4))
	head:SetPaintBackground(false)
	head.Paint = function(_, w, h)
		draw.SimpleText("CLAN", F_LABEL, gRespX(16), h * 0.5, COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		for i, col in ipairs(LB_COLS) do
			draw.SimpleText(col.label, F_LABEL, lbColCenter(i, w), h * 0.5,
				COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Rangées : faction seule, ou TOUTES les factions réunies (lbFaction == "all").
	-- Le rang est recalculé DANS le filtre (meilleur Shinigami ≠ meilleur global).
	local bAllFac = lbFaction == "all"
	local tRows = {}
	for _, d in ipairs(LB_DATA) do
		if bAllFac or d.faction == lbFaction then tRows[#tRows + 1] = d end
	end
	EVO_CLAN.SortClansOverall(tRows)

	local sMyKey = (STATE and STATE.myKey) or LocalPlayer():GetEvoNWString("EVO_ClanKey", "")
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	StyleScrollBar(scroll)
	pClan.contentScroll = scroll -- restauration du scroll au re-rend (cf. RebuildContent)

	for nRank, d in ipairs(tRows) do
		local row = vgui.Create("DPanel", scroll)
		row:SetTall(gRespY(104))
		row:Dock(TOP)
		row:DockMargin(0, 0, gRespX(6), gRespY(10))
		row:SetPaintBackground(false)
		local colMedal = LB_MEDALS[nRank] or LB_MEDALS[4]
		local bMine = d.key == sMyKey
		local sSub = (d.members or 0) .. " membre" .. ((d.members or 0) > 1 and "s" or "")
		if bAllFac and (d.faction or "") ~= "" then
			sSub = string.upper(d.faction) .. "  ·  " .. sSub
		end
		row.Paint = function(selff, w, h)
			RNDX.Draw(0, 0, 0, w, h, panel_contains_cursor(selff) and COL_ROW_HOV or COL_ROW)
			if bMine then RNDX.Draw(0, 0, 0, gRespX(4), h, COL_ACCENT) end
			-- Médaillon de rang.
			local mcx, mcy, mr = gRespX(46), h * 0.5, gRespX(26)
			RNDX.DrawCircle(mcx, mcy, mr * 2, Color(12, 12, 16, 255))
			RNDX.DrawCircleOutlined(mcx, mcy, mr * 2, colMedal, gRespX(3))
			draw.SimpleText("#" .. nRank, F_ROW, mcx, mcy, colMedal, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			-- Nom du clan + effectif (+ faction en vue TOUS).
			draw.SimpleText("CLAN " .. string.upper(d.label or ""), F_ROW, gRespX(90), h * 0.5 - gRespY(14),
				bMine and COL_ACCENT or COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sSub, F_ROW_SUB, gRespX(90), h * 0.5 + gRespY(18), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			-- Les stats (une par colonne ; le rang # combine toutes).
			for i, col in ipairs(LB_COLS) do
				local nVal = tonumber(d[col.id]) or 0
				local sVal = col.fmt and col.fmt(nVal) or string.Comma(nVal)
				draw.SimpleText(sVal, F_ROW, lbColCenter(i, w), h * 0.5,
					COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- Note de fraîcheur.
	local note = vgui.Create("DPanel", scroll)
	note:SetTall(gRespY(30))
	note:Dock(TOP)
	note:SetPaintBackground(false)
	note.Paint = function(_, w, h)
		draw.SimpleText("Classement général : toutes les colonnes comptent. Mis à jour toutes les 60 s.", F_HINT, 0, h * 0.5, COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

-- ── Frame principal ─────────────────────────────────────────────────────────

-- True seulement si un DTextEntry de l'UI a le focus (frappe en cours).
-- MakePopup donne souvent le focus à un DButton d'onglet : ce n'est PAS de la
-- saisie — différer dans ce cas laissait « Chargement du clan... » figé jusqu'à
-- réouverture (STATE arrivait, rebuild reporté à jamais).
local function clanUIIsTyping()
	if not IsValid(pClan) then return false end
	local pFocus = vgui.GetKeyboardFocus()
	return IsValid(pFocus) and pFocus:HasParent(pClan) and isfunction(pFocus.IsEditing)
end

RebuildContent = function()
	if not IsValid(pClan) or not IsValid(pClan.content) then return end
	-- SAISIE EN COURS (bug user 07/23 : « quand j'écris ça supprime le texte ») : un push
	-- d'état serveur pendant la FRAPPE reconstruisait l'onglet -> les champs texte (nom du
	-- clan à fonder, recherche des dropdowns d'invite...) étaient DÉTRUITS et recréés vides.
	-- On DIFFÈRE le re-rendu tant qu'un DTextEntry de CETTE UI a le focus ; le Think du
	-- frame (OpenUI) rejoue le rebuild dès la fin de la frappe. STATE est déjà à jour.
	if clanUIIsTyping() then
		pClan._rebuildPending = true
		return
	end
	pClan._rebuildPending = nil
	-- PRÉSERVE LE SCROLL (bug user 07/23 + 08/11 upgrades) : chaque push evo_clan:state
	-- re-rend l'onglet. Un seul timer.Simple(0) SetScroll était trop TÔT — le canvas
	-- Dock n'avait pas encore sa hauteur -> SetScroll clampait à 0 (« ça me remonte »).
	-- On attend que le canvas soit plus grand que le viewport (retries sur frames
	-- suivantes), uniquement si on re-rend le MÊME onglet.
	local nScroll = 0
	if pClan._scrollTab == sCurTab and IsValid(pClan.contentScroll) then
		local vbar = pClan.contentScroll:GetVBar()
		nScroll = IsValid(vbar) and vbar:GetScroll() or 0
	end
	pClan._scrollTab = sCurTab
	pClan.contentScroll = nil -- re-posé par le builder de l'onglet (s'il a un scroll)
	if sCurTab == "admin" and STATE and STATE.isSA then
		BuildAdminTab(pClan.content)
	elseif sCurTab == "classement" then
		BuildLeaderboardTab(pClan.content)
	elseif sCurTab == "upgrades" then
		BuildUpgradesTab(pClan.content)
	elseif sCurTab == "banque" then
		BuildBanqueTab(pClan.content)
	elseif sCurTab == "grades" then
		BuildGradesTab(pClan.content)
	else
		BuildClanTab(pClan.content)
	end
	if nScroll > 0 and IsValid(pClan.contentScroll) then
		local pnl, nTarget = pClan.contentScroll, nScroll
		local function restoreScroll(nLeft)
			if not IsValid(pnl) or nLeft < 0 then return end
			local vb = pnl:GetVBar()
			local canvas = pnl.GetCanvas and pnl:GetCanvas() or nil
			if IsValid(vb) and IsValid(canvas) then
				local nMax = math.max(0, canvas:GetTall() - pnl:GetTall())
				-- Canvas encore à 0 / trop petit : retente la frame suivante.
				if nMax < nTarget and nLeft > 0 then
					timer.Simple(0, function() restoreScroll(nLeft - 1) end)
					return
				end
				vb:SetScroll(nTarget)
				return
			end
			if nLeft > 0 then
				timer.Simple(0, function() restoreScroll(nLeft - 1) end)
			end
		end
		timer.Simple(0, function() restoreScroll(8) end)
	end
end

local function OpenUI()
	if IsValid(pClan) then pClan:Remove() pClan = nil return end
	if CurTime() - clanClosedAt < 0.2 then return end

	sInspect = ""
	sCurTab = "clan"

	local frame = vgui.Create("DFrame")
	pClan = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.OnRemove = function()
		clanClosedAt = CurTime()
		if IsValid(pRename) then pRename:Remove() pRename = nil end
	end
	frame.Paint = function(_, w, h)
		surface.SetDrawColor(COL_FOND)
		surface.DrawRect(0, 0, w, h)
	end
	-- Clic hors carte = fermer.
	frame.OnMousePressed = function() frame:Remove() end

	local card = vgui.Create("DPanel", frame)
	card:gSetSize(CARD_W, CARD_H)
	card:Center()
	frame._card = card -- hôte des listes déroulantes DA (StyledDropdown)
	card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		-- Plaque DA Atelier à COINS COUPÉS (haut-droite / bas-gauche), comme
		-- le spell selector / menu échap.
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, gRespY(16))
		else
			RNDX.Draw(0, 0, 0, w, h, COL_CARD)
		end
		-- (Pas d'image d'ambiance bc12 : retirée sur demande user 07/13.)
		-- Vis alignées aux 4 coins (signature Atelier).
		if EVO_UI and EVO_UI.Screw then
			local mx, my, sr = gRespX(18), gRespY(18), gRespX(5)
			EVO_UI.Screw(mx, my, sr)
			EVO_UI.Screw(w - mx, my, sr)
			EVO_UI.Screw(w - mx, h - my, sr)
			EVO_UI.Screw(mx, h - my, sr)
		end
		-- Titre Bebas + ENTAILLE slash1 (règle titre-slash : CENTER + th*0.28,
		-- largeur tw*1.12 — jamais d'offset fixe, cf. réf BOUTIQUE).
		local nTitleY = gRespY(HEADER_H) * 0.5
		draw.SimpleText("CLAN", F_TITLE, gRespX(PAD + 4), nTitleY, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont(F_TITLE)
		local twT = surface.GetTextSize("CLAN")
		if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(PAD), nTitleY + select(2, surface.GetTextSize("CLAN")) * 0.28,
			twT * 1.12, gRespY(11), ColorAlpha(COL_ACCENT, 245))) then
			RNDX.Draw(0, gRespX(PAD), gRespY(HEADER_H) - 1, w - gRespX(PAD * 2), 1, COL_ACCENT)
		end
		-- Filet DENTÉ sous l'entête (pattern selector).
		surface.SetDrawColor(255, 255, 255, 14)
		local dashW, dashGap = gRespX(6), gRespX(5)
		local dx, dy = gRespX(PAD), gRespY(HEADER_H)
		while dx < w - gRespX(PAD) do
			surface.DrawRect(dx, dy, math.min(dashW, w - gRespX(PAD) - dx), 1)
			dx = dx + dashW + dashGap
		end
	end

	-- ✕
	local btnX = vgui.Create("DButton", card)
	btnX:SetText("")
	btnX:SetCursor("hand")
	btnX:gSetSize(52, 52)
	btnX:gSetPos(CARD_W - 64, 11)
	btnX.Paint = function(selff, w, h)
		draw.SimpleText("✕", F_X, w * 0.5, h * 0.5, panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btnX.DoClick = function() frame:Remove() end

	-- Onglets pour TOUS : MON CLAN / GRADES / BANQUE / UPGRADES / CLASSEMENT (+ ADMIN SA).
	-- Largeur calculée pour que les onglets tiennent sans déborder.
	local nContentTop = HEADER_H + TAB_H + 4
	local bSA = LocalPlayer():IsSuperAdmin()
	local tabs = vgui.Create("DPanel", card)
	tabs:gSetPos(PAD, HEADER_H + 4)
	tabs:gSetSize(CARD_W - PAD * 2, TAB_H - 8)
	tabs:SetPaintBackground(false)
	local tTabs = {
		{ id = "clan",       label = "MON CLAN" },
		{ id = "grades",     label = "GRADES" },
		{ id = "banque",     label = "BANQUE" },
		{ id = "upgrades",   label = "UPGRADES" },
		{ id = "classement", label = "CLASSEMENT" },
	}
	if bSA then tTabs[#tTabs + 1] = { id = "admin", label = "ADMIN" } end
	local nTabGap = gRespX(8)
	local nTabsW = gRespX(CARD_W - PAD * 2)
	local nTabW = math.floor((nTabsW - nTabGap * (#tTabs - 1)) / #tTabs)
	for i, t in ipairs(tTabs) do
		local b = vgui.Create("DButton", tabs)
		b:SetText("")
		b:SetCursor("hand")
		b:SetPos((i - 1) * (nTabW + nTabGap), 0)
		b:SetSize(nTabW, gRespY(TAB_H - 12))
		b.Paint = function(selff, w, h)
			local bActive = sCurTab == t.id
			if bActive or panel_contains_cursor(selff) then
				RNDX.Draw(0, 0, 0, w, h, bActive and COL_ROW or COL_ACCENT_SOFT)
			end
			draw.SimpleText(t.label, F_TAB, w * 0.5, h * 0.5, bActive and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if bActive then RNDX.Draw(0, 0, h - gRespY(2), w, gRespY(2), COL_ACCENT) end
		end
		b.DoClick = function()
			sCurTab = t.id
			if t.id == "classement" then requestLeaderboard() end -- rafraîchit (throttle sv 2s, cache 60s)
			RebuildContent()
		end
	end

	-- Zone de contenu.
	local content = vgui.Create("DPanel", card)
	content:gSetPos(PAD, nContentTop)
	content:gSetSize(CARD_W - PAD * 2, CARD_H - nContentTop - PAD)
	content:SetPaintBackground(false)
	frame.content = content

	-- Toggle-close par le bind (MakePopup vole PlayerButtonDown -> Think + IsButtonDown).
	frame._bindKey = (LocalPlayer().GetBindKey and LocalPlayer():GetBindKey("famille")) or 0
	frame._bindWasDown = true
	frame.Think = function(s)
		-- Rebuild DIFFÉRÉ (cf. RebuildContent) : un push d'état arrivé PENDANT la frappe
		-- a été mis en attente pour ne pas détruire les champs texte -> on le rejoue dès
		-- que plus aucun champ de l'UI n'a le focus clavier.
		if s._rebuildPending and not clanUIIsTyping() then
			s._rebuildPending = nil
			RebuildContent() -- netgate: edge -- _rebuildPending cleared just above, replays once
		end
		-- Liste déroulante ouverte = on peut être en train de TAPER dans la
		-- recherche : ne jamais toggle-close sur une lettre du filtre.
		if IsValid(activeDropdown) then s._bindWasDown = true return end
		-- Champ texte de l'UI focus (nom du clan à fonder...) : même règle que le
		-- dropdown — une lettre tapée ne doit JAMAIS fermer l'UI par le toggle-bind
		-- (cousin du gotcha dropdown, durci 07/23 avec le fix « saisie effacée »).
		if clanUIIsTyping() then s._bindWasDown = true return end
		local k = s._bindKey
		if k and k > 0 then
			local down = input.IsButtonDown(k)
			if down and not s._bindWasDown then s:Remove() return end
			s._bindWasDown = down
		end
	end

	RebuildContent() -- affiche l'état précédent (ou vide) en attendant le serveur
	requestState()
end
EVO_CLAN.OpenUI = OpenUI

net.Receive("evo_clan:state", function()
	STATE = net.ReadTable() or {}
	-- Ne re-rend que l'onglet Mon Clan / Admin : le classement a son propre flux.
	if sCurTab ~= "classement" then RebuildContent() end
end)

net.Receive("evo_clan:lb", function()
	LB_DATA = net.ReadTable() or {}
	if IsValid(pClan) and sCurTab == "classement" then RebuildContent() end
end)

net.Receive("evo_clan:openui", function()
	if not IsValid(pClan) then OpenUI() end
end)

concommand.Add("evo_clan_menu", function() OpenUI() end)

-- Ouverture par le bind du menu de binds (id "famille", libellé « Mon Clan »).
hook.Add("PlayerButtonDown", "EVO_Clan::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if IsValid(pClan) then return end
	if not ply.GetBindKey then return end
	local k = ply:GetBindKey("famille")
	if k and k > 0 and btn == k then OpenUI() end
end)

-- ── Popup d'invitation ──────────────────────────────────────────────────────

local pInvite

net.Receive("evo_clan:invited", function()
	local sLabel = net.ReadString()
	local sFrom = net.ReadString()
	local nTimeout = net.ReadFloat()
	if IsValid(pInvite) then pInvite:Remove() end

	local W, H = 600, 220
	local frame = vgui.Create("DFrame")
	pInvite = frame
	frame:gSetSize(W, H)
	local x, y = frame:GetSize()
	frame:SetPos((ScrW() - x) / 2, ScrH() * 0.16)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(false) -- ne bloque pas le clavier (jeu jouable)
	local nEnd = CurTime() + (nTimeout or 60)
	frame.Paint = function(_, w, h)
		-- Même plaque DA à coins coupés que la carte principale ; la barre
		-- accent s'arrête AVANT la coupe haut-droite pour ne pas la remplir.
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, gRespY(14))
			RNDX.Draw(0, 0, 0, w - gRespY(14), gRespY(4), COL_ACCENT)
		else
			RNDX.Draw(0, 0, 0, w, h, COL_CARD)
			RNDX.Draw(0, 0, 0, w, gRespY(4), COL_ACCENT)
		end
		draw.SimpleText("CLAN " .. string.upper(sLabel), F_SUBTITLE, w * 0.5, gRespY(38), COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sFrom .. " t'invite à rejoindre le clan.", F_HINT, w * 0.5, gRespY(78), COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local nLeft = math.max(0, math.ceil(nEnd - CurTime()))
		draw.SimpleText(nLeft .. " s", F_ROW_SUB, w - gRespX(20), gRespY(22), COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	frame.Think = function(s)
		if CurTime() >= nEnd then s:Remove() end
	end

	local function answer(bAccept)
		net.Start("evo_clan:answer")
		net.WriteBool(bAccept)
		net.SendToServer()
		if IsValid(frame) then frame:Remove() end
	end
	MakeBtn(frame, 36, 132, 245, 60, "ACCEPTER", F_BTN, "primary", function() answer(true) end)
	MakeBtn(frame, W - 36 - 245, 132, 245, 60, "REFUSER", F_BTN, "danger", function() answer(false) end)
end)

-- ── Aura alliés de clan (toggle Action Rapide : cookie NCM_AR_EVO_ClanAura) ──
-- Halo local soft autour des modèles des membres du même clan. Pas de wallhack
-- (ignoreZ=false). Préférence cosmétique pure client.

local CLAN_AURA_COOKIE = "NCM_AR_EVO_ClanAura"
local CLAN_AURA_COLOR  = Color(110, 230, 150, 255) -- vert plus vif (alliés bataille)
local CLAN_AURA_MAXDIST_SQR = 2500 * 2500
local tClanAuraEnts = {}

function EVO_CLAN.IsClanAuraEnabled()
	-- Défaut ON (cookie absent = "1")
	return cookie.GetString(CLAN_AURA_COOKIE, "1") == "1"
end

function EVO_CLAN.ToggleClanAura()
	local on = EVO_CLAN.IsClanAuraEnabled()
	cookie.Set(CLAN_AURA_COOKIE, on and "0" or "1")
end

hook.Add("PreDrawHalos", "EVO_Clan::FriendlyAura", function()
	if not EVO_CLAN.IsClanAuraEnabled() then return end
	if IsCinematicActive and IsCinematicActive() then return end
	-- Uniquement pendant la Bataille des Clans (instance event), pas en open world.
	if not (EVO_BATAILLE and EVO_BATAILLE.IsLocalInEvent and EVO_BATAILLE.IsLocalInEvent()) then
		return
	end

	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end

	local sMyKey = lp:GetEvoNWString("EVO_ClanKey", "")
	if sMyKey == "" then return end

	local lpPos = lp:GetPos()
	local n = 0
	for _, ply in ipairs(player.GetAll()) do
		if ply == lp then continue end
		if not IsValid(ply) or not ply:Alive() or ply:IsDormant() then continue end
		if ply:GetMoveType() == MOVETYPE_NOCLIP then continue end
		if ply:GetEvoNWBool("EVO_StaffMode", false) then continue end
		if ply:GetEvoNWString("EVO_ClanKey", "") ~= sMyKey then continue end
		if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal
			and NCM_INSTANCE.ShouldHideFromLocal(ply) then continue end
		if lpPos:DistToSqr(ply:GetPos()) > CLAN_AURA_MAXDIST_SQR then continue end

		n = n + 1
		tClanAuraEnts[n] = ply
	end
	if n == 0 then return end

	for i = n + 1, #tClanAuraEnts do
		tClanAuraEnts[i] = nil
	end

	-- blurX/Y=5, passes=3, additive=true, ignoreZ=false (halo plus visible, pas wallhack)
	halo.Add(tClanAuraEnts, CLAN_AURA_COLOR, 5, 5, 3, true, false)
end)
