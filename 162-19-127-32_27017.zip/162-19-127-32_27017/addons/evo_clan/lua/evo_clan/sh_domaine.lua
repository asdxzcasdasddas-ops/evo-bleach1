-- "addons\\evo_clan\\lua\\evo_clan\\sh_domaine.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- DOMAINE DE CLAN — configuration partagée (2026-08-15, demande user).
--
-- Le « bail » de la banque (upgrade ACCÈS BÂTIMENT 250 000 ¥, flag
-- building_access + NW EVO_ClanBuildingAccess) existait en logique seule depuis
-- le 07/14 avec la note « le bâtiment réel / téléport sera branché plus tard ».
-- Ce module EST ce branchement : un coin de la map devient le domaine du clan,
-- servi en INSTANCE PARTAGÉE (ncm_instance, même mécanique que la Bataille des
-- Clans) — chaque clan a SA copie du lieu, comme les appartements GTA. Les
-- membres d'un même clan s'y voient entre eux ; le reste du monde ne les voit
-- plus, et eux ne voient plus le monde.
--
-- TROIS POSES par map (à ramasser en jeu via `evo_clan_domaine_here`) :
--   entree  : le marqueur dans le MONDE où l'on appuie E pour entrer ;
--   arrivee : où l'on apparaît DANS le domaine (et le marqueur E de sortie) ;
--   sortie  : où l'on réapparaît dans le monde en ressortant.
-- Le marqueur de sortie est à la pose d'arrivée : E n'y ressort qu'après
-- SortieDelai secondes de présence, sinon un double-appui entrerait-sortirait.
-- ============================================================================

EVO_CLAN = EVO_CLAN or {}

EVO_CLAN.Domaine = {
    -- Interrupteur général du module. La CONDITION D'ACCÈS, elle, reste
    -- l'upgrade de la banque : BuildingUpgradeEnabled (sh_config) doit être true
    -- pour que le bouton d'achat existe, et EVO_ClanBuildingAccess pour entrer.
    Enabled = true,

    -- Portée du E autour d'un marqueur (unités), et distance d'affichage du
    -- marqueur côté client. InteractDistance > rayon du halo pour tolérer la
    -- visée approximative ; DrawDistance court car le marqueur est un point fixe.
    InteractDistance = 110,
    DrawDistance     = 2000,

    -- Un joueur qui vient d'arriver dans le domaine est DEBOUT SUR le marqueur
    -- de sortie : sans ce délai, réappuyer E (ou le maintenir) ressortirait
    -- aussitôt et le TP se lirait comme « rien ne s'est passé ».
    SortieDelai = 3,

    -- Sweep d'éjection (secondes) : un membre exclu du clan, un clan dissous ou
    -- un accès bâtiment perdu pendant qu'on est DANS le domaine doit en sortir
    -- sans attendre une reconnexion. 10 s suffisent, la perte d'accès est rare.
    SweepInterval = 10,

    -- Coffre de clan (entité evo_coffre_clan) : même modèle que l'HDV.
    -- Spawn si Poses[map].coffre est posé (`evo_clan_domaine_here coffre`).
    CoffreModel    = "models/evo/props/items/evo_efttede452hk/evo_efttede452hk.mdl",
    CoffreEscrow   = "__clanchest__",
    CoffreSnapMax  = 400,
    CoffreLogMax   = 80, -- lignes d'historique (dépôts / retraits)
    CoffreInteract = 220,

    -- Poses par map. AUCUNE pose sérieuse encore : le user les ramasse en jeu
    -- avec `evo_clan_domaine_here entree|arrivee|sortie` (superadmin) qui
    -- imprime la ligne exacte à coller ici. gm_construct = poses de test local.
    Poses = {
        -- `invite` (OPTIONNELLE) : le marqueur INVITER dans le domaine. E dessus
        -- (membre du clan) ouvre la liste des joueurs proches de l'entree, pour
        -- faire venir un visiteur exterieur au clan.
        -- `coffre` (OPTIONNELLE) : pose de l'entité evo_coffre_clan dans l'intérieur.
        -- Sans elle le coffre n'apparaît pas. Relever via config_positions
        -- (catégorie Domaine → Poses domaine) ou `evo_clan_domaine_here coffre`.
        --
        -- `retour` (OPTIONNELLE) : le marqueur RESSORTIR dans le domaine. Sans
        -- elle il est confondu avec `arrivee`, ce qui oblige a un delai
        -- anti-double-appui parce qu'on apparait DESSUS. La poser ailleurs vaut
        -- mieux : la sortie devient un endroit ou l'on va, pas un piege sous les
        -- pieds a l'arrivee.
        gm_construct = {
            entree  = { pos = Vector(980, -400, -79),  ang = Angle(0, 90, 0) },
            arrivee = { pos = Vector(2431, 1524, -135), ang = Angle(0, 180, 0) },
            sortie  = { pos = Vector(980, -520, -79),  ang = Angle(0, -90, 0) },
            invite  = { pos = Vector(2531, 1424, -135), ang = Angle(0, 0, 0) },
            coffre  = { pos = Vector(2531, 1624, -135), ang = Angle(0, 180, 0) },
            archive = { pos = Vector(2231, 1624, -135), ang = Angle(0, 180, 0) },
        },
        -- Releve user en jeu le 2026-08-15 (evo_clan_domaine_here). L'arrivee est
        -- a z=14320 : le domaine est la zone haute de la map, injoignable a pied.
        rp_seireitei_v1 = {
            entree  = { pos = Vector(-8131.38, 4738.57, 368.89), ang = Angle(0, -14.46, 0) },
            arrivee = { pos = Vector(-9340.39, -4218.00, 14320.03), ang = Angle(0, 90.53, 0) },
            sortie  = { pos = Vector(-8124.81, 4937.85, 368.47), ang = Angle(0, 161.92, 0) },
            -- Pousse de 150u dans la direction du regard au releve (yaw 0.72) :
            -- la pose brute tombait au milieu de la salle (constat user 08/15).
            invite  = { pos = Vector(-9299.51, -4002.32, 14438.10) + Angle(0, 0.72, 0):Forward() * 150, ang = Angle(0, 0.72, 0) },
            -- Releve user 2026-08-23 (getpos). Yaw seul : le pitch 89 était le regard.
            coffre  = { pos = Vector(-8204.478516, -2762.731201, 14530.723633), ang = Angle(0, -179.448639, 0) },
            -- Archives privées, devant le coffre ; ancrage au sol par evo_livre.
            archive = { pos = Vector(-8504.464626, -2765.618075, 14530.723633), ang = Angle(0, -179.448639, 0) },
        },
        -- HUECO, releve user le 2026-08-22. Ni `entree` ni `sortie` : les 24
        -- emplacements les remplacent, la porte du clan tient les deux roles.
        hueco_mundo_v1 = {
            coffre  = { pos = Vector(-8149.359375, 11963.882812, 13273.723633), ang = Angle(0, 178.479095, 0) },
            archive = { pos = Vector(-8449.253687, 11971.845317, 13273.723633), ang = Angle(0, 178.479095, 0) },
            arrivee = { pos = Vector(-9277.466797, 10609.054688, 13164.095703), ang = Angle(0, -89.121666, 0) },
            -- Repositionnes le 08/22 : les deux premiers releves tombaient a 114u
            -- l'un de l'autre, pour une portee de 110. Ceux-ci sont a 340u.
            retour  = { pos = Vector(-9270.303711, 10421.923828, 13273.723633), ang = Angle(0, -87.273033, 0) },
            invite  = { pos = Vector(-9119.311523, 10727.381836, 13273.723633), ang = Angle(0, 4.202911, 0) },
        },
    },

    -- ── EMPLACEMENTS ACHETABLES ───────────────────────────────────
    -- Un clan n'a plus l'entree du domaine des qu'il paie le bail : il achete
    -- ENSUITE un emplacement precis, et cet emplacement lui appartient seul
    -- (demande user 2026-08-22). L'INTERIEUR reste LE MEME pour tout le monde,
    -- ces poses ne sont QUE la porte vers l'instance du clan.
    --
    -- L'entree ET la sortie sont au meme point : on ressort par ou l'on est
    -- entre. Une pose de sortie distincte n'apporterait rien ici.
    --
    -- L'`id` est la cle stockee en base (evo_clan_domaine.slot) : il ne doit
    -- JAMAIS etre renumerote, sinon les clans changeraient d'emplacement au
    -- redemarrage. Pour retirer un emplacement, commenter sa ligne et laisser
    -- les autres id inchanges.
    Emplacements = {
        rp_seireitei_v1 = {
            { id = "s01", pos = Vector(-7933.889648, 6001.316406, 511.323792), ang = Angle(0, -1.895544, 0) },
            { id = "s02", pos = Vector(-8057.161621, 7757.367188, 493.069458), ang = Angle(0, 2.856367, 0) },
            { id = "s03", pos = Vector(-8577.830078, 8078.176758, 493.069458), ang = Angle(0, -177.227463, 0) },
            { id = "s04", pos = Vector(-7270.707520, 5988.630859, 511.323792), ang = Angle(0, 180.336395, 0) },
            { id = "s05", pos = Vector(-7477.631348, 4550.252930, 509.323792), ang = Angle(0, 162.912399, 0) },
            { id = "s06", pos = Vector(-837.993713, 12076.830078, 510.439819), ang = Angle(0, 88.200577, 0) },
            { id = "s07", pos = Vector(-832.093262, 12742.381836, 510.439819), ang = Angle(0, -84.491417, 0) },
            { id = "s08", pos = Vector(-1733.788452, 12374.963867, 573.723877), ang = Angle(0, -177.155365, 0) },
            { id = "s09", pos = Vector(-2231.211182, 12374.448242, 573.723877), ang = Angle(0, 1.740639, 0) },
            { id = "s10", pos = Vector(-3047.669678, 12742.320312, 510.439819), ang = Angle(0, -88.187332, 0) },
            { id = "s11", pos = Vector(-3057.903809, 12079.051758, 510.439819), ang = Angle(0, 89.220741, 0) },
            { id = "s12", pos = Vector(-3730.787842, 9969.963867, 573.723938), ang = Angle(0, -178.775070, 0) },
            { id = "s13", pos = Vector(-4228.311035, 9971.872070, 573.723938), ang = Angle(0, 0.912907, 0) },
            { id = "s14", pos = Vector(-3016.294434, 9611.707031, 510.439819), ang = Angle(0, 90.277069, 0) },
            { id = "s15", pos = Vector(-3010.710449, 10274.992188, 510.439819), ang = Angle(0, -86.902878, 0) },
            { id = "s16", pos = Vector(-2231.144531, 9971.721680, 573.723938), ang = Angle(0, -0.046876, 0) },
            { id = "s17", pos = Vector(-1731.838257, 9973.450195, 573.665649), ang = Angle(0, -178.378830, 0) },
            { id = "s18", pos = Vector(-1040.612793, 9611.577148, 510.439819), ang = Angle(0, 94.501068, 0) },
            { id = "s19", pos = Vector(-1026.312866, 10274.952148, 510.439819), ang = Angle(0, -91.390923, 0) },
            { id = "s20", pos = Vector(247.180740, 9611.658203, 510.439819), ang = Angle(0, 91.861046, 0) },
            { id = "s21", pos = Vector(257.284332, 10274.897461, 510.439819), ang = Angle(0, -92.015022, 0) },
        },
        -- Releve user le 2026-08-22. Les portes vont par paires qui SE FONT
        -- FACE a 450u : ce sont deux couloirs et leurs murs lateraux, le
        -- joueur s'est place devant chaque porte, dos au mur, et le yaw est
        -- donc la direction vers laquelle la porte REGARDE.
        hueco_mundo_v1 = {
            { id = "h01", pos = Vector(-6240.345215, 7577.031250, 6333.077637), ang = Angle(0, 86.617218, 0) },
            { id = "h02", pos = Vector(-6239.943359, 8026.968750, 6328.405762), ang = Angle(0, -90.394783, 0) },
            { id = "h03", pos = Vector(-5428.906250, 10040.968750, 6332.395996), ang = Angle(0, -90.754684, 0) },
            { id = "h04", pos = Vector(-5435.058594, 9591.031250, 6333.598145), ang = Angle(0, 89.461266, 0) },
            { id = "h05", pos = Vector(-4201.870117, 9591.031250, 6329.277344), ang = Angle(0, 90.649063, 0) },
            { id = "h06", pos = Vector(-4201.523438, 10040.968750, 6331.020020), ang = Angle(0, -91.246971, 0) },
            { id = "h07", pos = Vector(4204.968750, 4652.007324, 5340.619141), ang = Angle(0, -182.025696, 0) },
            { id = "h08", pos = Vector(3755.031250, 4659.454102, 5340.240234), ang = Angle(0, -0.621670, 0) },
            { id = "h09", pos = Vector(3755.031250, 6287.225586, 5353.398926), ang = Angle(0, -1.773534, 0) },
            { id = "h10", pos = Vector(4204.968750, 6283.794434, 5356.109375), ang = Angle(0, 177.086288, 0) },
            { id = "h11", pos = Vector(-508.968750, 6277.899902, 5354.679199), ang = Angle(0, -1.773622, 0) },
            { id = "h12", pos = Vector(-59.031250, 6285.187988, 5350.027344), ang = Angle(0, 179.894165, 0) },
            { id = "h13", pos = Vector(-508.968750, 4652.462402, 5342.694336), ang = Angle(0, -1.246280, 0) },
            { id = "h14", pos = Vector(-59.031250, 4653.262695, 5341.770996), ang = Angle(0, 178.441742, 0) },
            { id = "h15", pos = Vector(-545.865051, 11692.968750, 6334.156738), ang = Angle(0, -92.026711, 0) },
            { id = "h16", pos = Vector(-542.058228, 11243.031250, 6343.379395), ang = Angle(0, 88.453407, 0) },
            { id = "h17", pos = Vector(1080.438232, 11692.968750, 6339.821777), ang = Angle(0, -90.142693, 0) },
            { id = "h18", pos = Vector(1084.688477, 11243.031250, 6337.767090), ang = Angle(0, 90.733452, 0) },
            { id = "h19", pos = Vector(2885.968750, 10010.264648, 6353.403809), ang = Angle(0, 177.625366, 0) },
            { id = "h20", pos = Vector(2436.031250, 10013.913086, 6342.413086), ang = Angle(0, -4.270678, 0) },
            { id = "h21", pos = Vector(1176.239014, 8391.031250, 6333.811035), ang = Angle(0, 87.373436, 0) },
            { id = "h22", pos = Vector(1173.512695, 8840.968750, 6326.387207), ang = Angle(0, -94.522514, 0) },
            { id = "h23", pos = Vector(-2065.607178, 8391.031250, 6330.094238), ang = Angle(0, 87.541031, 0) },
            { id = "h24", pos = Vector(-2065.043213, 8840.968750, 6330.705566), ang = Angle(0, -91.186806, 0) },
        },
    },

    -- ── PORTE POSEE A CHAQUE EMPLACEMENT ──────────────────────────────
    -- Au Seireitei les entrees sont des points nus. Au Hueco elles portent un
    -- MODELE de porte, pose contre le mur (demande user 2026-08-22).
    --
    -- Le modele n'est PAS pose sur la pose relevee telle quelle : le serveur
    -- trace vers le mur DERRIERE la pose et colle la porte dessus, en prenant
    -- l'angle sur la NORMALE du mur et non sur le yaw releve. Un yaw ramasse a
    -- la main est toujours a quelques degres pres, et une porte de travers sur
    -- un mur se voit immediatement ; la normale, elle, est exacte.
    --
    -- Les trois reglages se retouchent EN JEU (`evo_clan_domaine_porte ...`)
    -- avant d'etre recopies ici : le modele vient d'un pack de contenu, on ne
    -- peut pas deviner ou est son origine sans le voir.
    Porte = {
        hueco_mundo_v1 = {
            modele = "models/propper/maptest2/thewatcher_stuff_evo_102_0.mdl",
            -- Correction de cap : le modele regarde a l'oppose de son +X local,
            -- constate en jeu le 08/22 (les 24 portes tournaient le dos au
            -- couloir).
            yaw = 180,
            -- Ecart laisse entre le mur et la porte (positif = vers le couloir).
            -- L'alignement au SOL, lui, est automatique : il se calcule sur la
            -- boite du modele, il n'y a rien a regler.
            avance = 0,
            -- Longueur de la trace qui cherche le mur. Au-dela, on considere
            -- qu'il n'y a pas de mur et on pose la porte sur la pose relevee.
            recul = 260,
        },
    },

    -- ── TERRAIN D'ENTRAÎNEMENT DU DOMAINE ───────────────────────────────────
    -- Une ou plusieurs BOÎTES no-KO (le systeme des « Zone Entrainement » de
    -- ncm_entrainement : pas de mort ni de KO, degats capes, full soin, reset
    -- des cooldowns du perdant) DANS le domaine. Ces boites ne s'appliquent
    -- QU'AUX JOUEURS EN INSTANCE DOMAINE, et pour eux les zones du monde
    -- cessent d'exister : deux clans peuvent s'entrainer au meme endroit
    -- chacun dans sa copie, et un joueur du MONDE qui traverse physiquement le
    -- coin n'est pas protege par accident.
    -- Chaque boite = deux coins OPPOSES { a, b } releves en jeu, dans n'importe
    -- quel ordre : `evo_clan_domaine_here terrain` a chaque coin, coller les
    -- deux Vector. Le tri mins/maxs est fait par DomaineTerrain().
    Terrain = {
        gm_construct = {
            { a = Vector(2131, 1224, -160), b = Vector(2731, 1924, 400) },
        },
        -- Releve user 2026-08-15. Les deux coins etaient au MEME z (15160, le
        -- sol du terrain) : boite plate, personne dedans. Z elargi a la main
        -- comme les Zones Entrainement du monde : -100 sous le sol, +1500
        -- au-dessus (sauts, shunpo, petits vols).
        -- Releve user 2026-08-22, remplace celui du 08-15 (boite plus large que
        -- le terrain reel). Les deux coins sont au meme z a 20u pres (15240 et
        -- 15261, le sol) : comme pour les Zones Entrainement du monde, le z est
        -- elargi a la main, -100 sous le sol et +1500 au-dessus pour couvrir les
        -- sauts, le shunpo et les petits vols.
        rp_seireitei_v1 = {
            { a = Vector(-10254.48, -4306.97, 15140), b = Vector(-7932.63, -2525.03, 16761) },
        },
        -- Releve user 2026-08-22. Les deux coins sont au meme z a 2u pres
        -- (13971 et 13970, le sol du terrain, 800u au-dessus de l'arrivee) :
        -- meme elargissement a la main que les autres, -100 sous le sol et
        -- +1500 au-dessus pour couvrir les sauts, le sonido et les petits vols.
        hueco_mundo_v1 = {
            { a = Vector(-10249.97, 12207.93, 13869.62), b = Vector(-7755.30, 10451.31, 15471.33) },
        },
    },
}

EVO_CLAN.CoffreModel = EVO_CLAN.Domaine.CoffreModel

-- POSE RAMENEE AU SOL, partagee client ET serveur (2026-08-22).
--
-- POURQUOI ELLE EST ICI ET PLUS DANS cl_domaine : le client snapait deja la
-- pose au sol pour dessiner le panneau, mais le serveur testait le E sur la
-- pose BRUTE. Un releve fait en volant mettait donc le panneau aux pieds du
-- joueur et le point d'interaction 118 unites au-dessus de sa tete (cas du
-- marqueur INVITER du Seireitei) : on voyait « [E] Faire venir un visiteur »
-- et le E ne repondait pas, parce que 118 > InteractDistance.
--
-- Une seule definition pour les deux cotes : c'est la seule facon que ce qui
-- est AFFICHE et ce qui est TESTE ne puissent plus diverger. Corriger le z a la
-- main dans la config aurait repare ce releve-la, et laisse le piege intact
-- pour le suivant.
--
-- Cache par pose : la geometrie ne bouge pas, et le serveur appelle ceci a
-- chaque appui sur E. Vider si l'editeur deplace une pose.
local _solCache = {}
function EVO_CLAN.InvalidateDomaineSol()
    _solCache = {}
end

function EVO_CLAN.DomainePoseAuSol(vPos)
    if not vPos then return vPos end
    local sCle = math.floor(vPos.x) .. "|" .. math.floor(vPos.y) .. "|" .. math.floor(vPos.z)
    local v = _solCache[sCle]
    if v then return v end
    local vSol = select(1, EVO_CLAN.DomaineSol(vPos))
    _solCache[sCle] = vSol
    return vSol
end

-- Descente maximale sous la pose relevee, et pas de la traverser vers le haut.
-- Une pose peut demarrer DANS du solide (relevee dans un chambranle, un mur, un
-- auvent) : on en sort alors PAR LE BAS, par pas de 16u. 640u de budget couvrent
-- largement l'epaisseur d'un batiment du Seireitei.
local DOM_PAS = 16
local DOM_ESSAIS = 40

-- Le SOL DE LA MAP seulement. Un filtre `e:IsWorld()` et pas le seul
-- MASK_SOLID_BRUSHONLY : celui-ci accroche aussi les brushes d'ENTITE, donc les
-- func_door du Seireitei.
local function DescendreJusquAuSol(vPos, vFin, tMask, fFiltre)
    local vCur = vPos + Vector(0, 0, 16)
    for _ = 1, DOM_ESSAIS do
        if vCur.z <= vFin.z then return nil end
        local tr = util.TraceLine({ start = vCur, endpos = vFin, mask = tMask, filter = fFiltre })
        -- DEPART DANS DU SOLIDE : HitPos vaut le point de depart, donc accepter
        -- ce resultat REMONTERAIT la pose. Repartir d'AU-DESSUS serait pire
        -- encore : la trace redescendante accroche alors le TOIT du batiment, et
        -- le marqueur se posait dessus (capture user 08/22, s03 493 -> 981).
        -- La seule direction qui mene au sol, c'est vers le bas.
        if tr.StartSolid then
            vCur = vCur - Vector(0, 0, DOM_PAS)
        elseif tr.Hit then
            return tr.HitPos.z
        else
            return nil
        end
    end
    return nil
end

-- Le detail du calcul, sans cache : sert au diagnostic (`evo_clan_domaine_sol`)
-- quand un marqueur se pose au mauvais endroit. Renvoie la pose retenue, le z du
-- monde et le z du prop (nil si rien touche).
function EVO_CLAN.DomaineSol(vPos)
    local vFin = Vector(vPos.x, vPos.y, vPos.z - DOM_PAS * DOM_ESSAIS)

    -- Le MONDE gagne : c'est le sol ou le joueur marche. Le prop ne sert que de
    -- filet, pour les maps dont le sol est un modele, sinon on garderait la pose
    -- en l'air.
    local nMonde = DescendreJusquAuSol(vPos, vFin, MASK_SOLID_BRUSHONLY,
        function(e) return e:IsWorld() end)
    local nProp = DescendreJusquAuSol(vPos, vFin, MASK_SOLID,
        function(e) return not (e:IsPlayer() or e:IsNPC()) end)

    local nZ = nMonde or nProp
    if not nZ then return vPos, nMonde, nProp end
    return Vector(vPos.x, vPos.y, nZ), nMonde, nProp
end

-- Poses de LA map courante, ou nil si le domaine n'y existe pas. Les trois
-- poses sont exigées ENSEMBLE : une config partielle (entrée sans sortie)
-- piégerait les joueurs dedans, on préfère un domaine absent.
function EVO_CLAN.DomainePoses()
    local t = EVO_CLAN.Domaine.Poses[game.GetMap()]
    if not t or not t.arrivee then return nil end
    -- Avec des emplacements achetables, `entree` et `sortie` ne servent plus :
    -- la porte du clan tient les deux roles. Continuer a les exiger obligerait
    -- a relever deux poses mortes pour ouvrir le domaine sur une nouvelle map.
    if #EVO_CLAN.DomaineEmplacements() > 0 then return t end
    if not t.entree or not t.sortie then return nil end
    return t
end

-- Le zoneID d'instance du domaine d'un clan. Préfixe dédié : le sweep serveur
-- et le rendu client reconnaissent « je suis dans UN domaine » par lui, sans
-- jamais confondre avec le tuto (zones par joueur) ni la Bataille.
function EVO_CLAN.DomaineZone(sClanKey)
    return "clan_dom_" .. (sClanKey or "")
end

function EVO_CLAN.IsDomaineZone(sZone)
    return isstring(sZone) and sZone:sub(1, 9) == "clan_dom_"
end

-- Le joueur est-il dans SON domaine ? Partage client/serveur : le serveur lit
-- l'etat d'instance reel, le client lit la NW NCM_InstanceZone (posee par
-- ncm_instance a l'Enter). Consomme par ncm_entrainement pour choisir quels
-- ronds existent pour ce joueur.
function EVO_CLAN.EstDansDomaine(ply)
    if not IsValid(ply) then return false end
    if SERVER and NCM_INSTANCE and NCM_INSTANCE.GetZoneID then
        return EVO_CLAN.IsDomaineZone(NCM_INSTANCE.GetZoneID(ply))
    end
    return EVO_CLAN.IsDomaineZone(ply:GetEvoNWString("NCM_InstanceZone", ""))
end

-- Boites du terrain d'entrainement du domaine pour la map courante, deja
-- normalisees en { mins, maxs } (les coins { a, b } de la config sont relevables
-- dans n'importe quel ordre). Calcule UNE FOIS par map (invalider via
-- InvalidateDomaineTerrain si l'editeur config_positions deplace la boite).
local _terrainCache
function EVO_CLAN.InvalidateDomaineTerrain()
    _terrainCache = nil
end

function EVO_CLAN.DomaineTerrain()
    if _terrainCache ~= nil then return _terrainCache or nil end
    local src = EVO_CLAN.Domaine.Terrain[game.GetMap()]
    if not src or #src == 0 then _terrainCache = false return nil end
    local out = {}
    for _, box in ipairs(src) do
        if box.a and box.b then
            out[#out + 1] = {
                mins = Vector(math.min(box.a.x, box.b.x), math.min(box.a.y, box.b.y), math.min(box.a.z, box.b.z)),
                maxs = Vector(math.max(box.a.x, box.b.x), math.max(box.a.y, box.b.y), math.max(box.a.z, box.b.z)),
            }
        end
    end
    _terrainCache = #out > 0 and out or false
    return _terrainCache or nil
end

-- ── EMPLACEMENTS : lecture partagee ───────────────────────────────

-- Les emplacements achetables de LA map courante, ou une table vide. Vide =
-- l'ancien fonctionnement reste en place (entree fixe de Poses) : c'est ce qui
-- permet d'activer le systeme map par map sans casser gm_construct.
function EVO_CLAN.DomaineEmplacements()
    return EVO_CLAN.Domaine.Emplacements[game.GetMap()] or {}
end

function EVO_CLAN.DomaineEmplacement(sId)
    for _, e in ipairs(EVO_CLAN.DomaineEmplacements()) do
        if e.id == sId then return e end
    end
    return nil
end

-- L'emplacement du clan d'un joueur, ou nil s'il n'en a pas achete.
-- Une seule source des deux cotes : le serveur pose EVO_ClanDomaineSlot au sync
-- clan, le client ne fait que la lire. Interroger la base cote client etait
-- impossible, et recopier la logique aurait produit deux verites.
function EVO_CLAN.DomaineSlotDe(ply)
    if not IsValid(ply) then return nil end
    local sId = ply:GetEvoNWString("EVO_ClanDomaineSlot", "")
    if sId == "" then return nil end
    return EVO_CLAN.DomaineEmplacement(sId)
end

-- La porte du joueur : son emplacement achete si le systeme est actif sur cette
-- map, sinon l'entree fixe historique. Sert A LA FOIS d'entree et de sortie,
-- les deux sont au meme point par choix.
function EVO_CLAN.DomainePorte(ply)
    local emp = EVO_CLAN.DomaineSlotDe(ply)
    if emp then return emp end
    if #EVO_CLAN.DomaineEmplacements() > 0 then return nil end
    local t = EVO_CLAN.Domaine.Poses[game.GetMap()]
    return t and t.entree or nil
end
