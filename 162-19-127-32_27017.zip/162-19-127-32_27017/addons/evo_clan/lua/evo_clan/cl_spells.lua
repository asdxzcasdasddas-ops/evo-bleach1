-- "addons\\evo_clan\\lua\\evo_clan\\cl_spells.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local frame
local accent = Color(235, 199, 113)
local muted = Color(165, 173, 190)
surface.CreateFont("EVOClanSpellsTitle", { font = "Roboto", size = 25, weight = 700 })
surface.CreateFont("EVOClanSpellsText", { font = "Roboto", size = 16, weight = 500 })

local function requestState()
    net.Start("evo_clan:spells_get")
    net.SendToServer()
end

local function open(data)
    local previousClan, previousSpell
    if IsValid(frame) then
        previousClan, previousSpell = frame.clanKey, frame.spellID
        frame:Remove()
    end
    frame = vgui.Create("DFrame")
    local panel = frame
    panel:SetSize(math.min(660, ScrW() - 32), math.min(510, ScrH() - 32))
    panel:Center()
    panel:SetTitle("")
    panel:MakePopup()
    panel:DockPadding(24, 54, 24, 22)
    panel.Paint = function(_, w, h)
        draw.RoundedBox(10, 0, 0, w, h, Color(19, 22, 30, 250))
        surface.SetDrawColor(accent)
        surface.DrawRect(24, 46, w - 48, 2)
        draw.SimpleText("SORTS DE CLAN", "EVOClanSpellsTitle", 24, 12, accent)
    end

    local scroll = vgui.Create("DScrollPanel", panel)
    scroll:Dock(FILL)
    local function label(text, color, height)
        local item = vgui.Create("DLabel", scroll)
        item:Dock(TOP)
        item:DockMargin(0, 8, 0, 4)
        item:SetTall(height or 24)
        item:SetFont("EVOClanSpellsText")
        item:SetTextColor(color or muted)
        item:SetText(text)
        return item
    end
    label("Attribution à tous les membres actuels et futurs du clan.", muted, 36):SetWrap(true)
    label("CLAN")
    local clans = vgui.Create("DComboBox", scroll)
    clans:Dock(TOP)
    clans:SetTall(36)
    clans:SetSortItems(false)
    clans:SetValue("Choisir un clan…")
    label("SORT")
    local spells = vgui.Create("DComboBox", scroll)
    spells:Dock(TOP)
    spells:SetTall(36)
    spells:SetSortItems(false)
    spells:SetValue("Choisir un sort…")
    local description = label("", color_white, 90)
    description:SetWrap(true)
    local status = label("Choisis un clan et un sort.", accent, 36)
    status:SetWrap(true)
    label("Les superadmins disposent de tous ces sorts par défaut.", muted, 36):SetWrap(true)

    local actions = vgui.Create("DPanel", panel)
    actions:Dock(BOTTOM)
    actions:DockMargin(0, 14, 0, 0)
    actions:SetTall(40)
    actions.Paint = nil
    local function button(text, dock, width, color)
        local item = vgui.Create("DButton", actions)
        item:Dock(dock)
        item:SetWide(width)
        item:DockMargin(0, 0, 8, 0)
        item:SetText(text)
        item:SetFont("EVOClanSpellsText")
        item:SetTextColor(color_white)
        item.Paint = function(self, w, h)
            draw.RoundedBox(6, 0, 0, w, h, self:IsEnabled()
                and (self:IsHovered() and Color(color.r + 12, color.g + 12, color.b + 12) or color)
                or Color(45, 48, 56))
        end
        return item
    end
    local grant = button("Attribuer", LEFT, 135, Color(57, 110, 86))
    local revoke = button("Retirer", LEFT, 115, Color(124, 61, 63))
    local refresh = button("Actualiser", RIGHT, 110, Color(58, 66, 83))
    refresh.DoClick = function() requestState() end

    local selectedClan, selectedSpell
    local function update()
        local selected = selectedClan ~= nil and selectedSpell ~= nil
        local assigned = selected and selectedClan.spells[selectedSpell.id] == true
        grant:SetEnabled(selected and not assigned)
        revoke:SetEnabled(selected and assigned)
        description:SetText(selectedSpell and selectedSpell.desc or "")
        status:SetText(selected and (assigned and "Ce clan possède déjà ce sort." or "Ce clan ne possède pas ce sort.")
            or (#(data.clans or {}) == 0 and "Aucun clan créé pour le moment." or "Choisis un clan et un sort."))
    end
    clans.OnSelect = function(_, _, _, clan)
        selectedClan, panel.clanKey = clan, clan.key
        update()
    end
    spells.OnSelect = function(_, _, _, spell)
        selectedSpell, panel.spellID = spell, spell.id
        update()
    end
    local clanChoice, spellChoice
    for _, clan in ipairs(data.clans or {}) do
        local choice = clans:AddChoice(clan.name .. " · " .. clan.faction, clan)
        if clan.key == previousClan then clanChoice = choice end
    end
    for _, spell in ipairs(data.spells or {}) do
        local choice = spells:AddChoice(spell.name, spell)
        if spell.id == previousSpell then spellChoice = choice end
    end
    if clanChoice then clans:ChooseOptionID(clanChoice) end
    if spellChoice or #(data.spells or {}) == 1 then spells:ChooseOptionID(spellChoice or 1) end
    local function submit(value)
        if not selectedClan or not selectedSpell then return end
        grant:SetEnabled(false)
        revoke:SetEnabled(false)
        status:SetText("Enregistrement…")
        net.Start("evo_clan:spells_set")
            net.WriteString(selectedClan.key)
            net.WriteString(selectedSpell.id)
            net.WriteBool(value)
        net.SendToServer()
        -- Réactive les actions en cas d'erreur BDD (message serveur dans le chat).
        timer.Simple(2, function() if IsValid(panel) then update() end end)
    end
    grant.DoClick = function() submit(true) end
    revoke.DoClick = function() submit(false) end
    update()
end

net.Receive("evo_clan:spells_state", function()
    local data = net.ReadTable()
    if not IsValid(LocalPlayer()) or not LocalPlayer():IsSuperAdmin() or not istable(data) then return end
    open(data)
end)
