-- "addons\\evo_clan\\lua\\evo_clan\\cl_domaine.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- DOMAINE DE CLAN — rendu client des marqueurs.
--
-- Jamais deux marqueurs visibles en même temps :
--   monde       : sur les EMPLACEMENTS de la map (le sien, ceux des autres
--                 clans sous leur nom, les libres), ou à la pose ENTREE quand
--                 la map n'a pas d'emplacements ;
--   dans domaine: à la pose ARRIVEE, « [E] Ressortir ».
-- L'état vient des NW (EVO_ClanKey / EVO_ClanBuildingAccess / NCM_InstanceZone),
-- donc le texte dit AVANT l'appui pourquoi ça refusera : un marqueur qui
-- promet puis refuse au E fabrique des tickets support.
--
-- Rendu : cercle a plat SUR LE SOL plus enseigne face au joueur, la recette
-- des zones ARCHIVES (evo_livre). Les poses sont des points au sol ramasses a
-- la volee, pas des surfaces orientees.
-- ============================================================================

local D = EVO_CLAN.Domaine

-- Memes tailles que les zones Archives : elles sont lues a l'echelle 0.22 et
-- une police plus petite y devenait illisible des 10 metres.
surface.CreateFont("EVO_Domaine_Titre", { font = "Bebas Neue", size = 96, weight = 600, antialias = true })
surface.CreateFont("EVO_Domaine_Sous",  { font = "Bebas Neue", size = 44, weight = 600, antialias = true })

local ACCENT = Color(207, 68, 78)
local BLANC  = Color(236, 236, 238)
local MUTED  = Color(150, 150, 158)

-- Le snap au sol vit dans sh_domaine (EVO_CLAN.DomainePoseAuSol) : le serveur
-- en a besoin AUSSI pour tester le E, et deux copies auraient fini par diverger
-- -- c'est exactement ce qui produisait un marqueur visible au sol avec un
-- point d'interaction hors de portee au-dessus.
local PoseAuSol = EVO_CLAN.DomainePoseAuSol

-- Meme recette que les zones ARCHIVES (evo_livre cl_livre) : un cercle a plat
-- SUR LE SOL qui dit ou se placer, et une enseigne lisible au-dessus. Le
-- panneau-carte precedent flottait a hauteur d'epaule et ne designait plus
-- rien (constat user 08/22) ; reprendre la recette qui marche deja ailleurs
-- evite d'en reinventer une troisieme.
local PAN_RAYON = 90      -- rayon du cercle au sol, cale sur InteractDistance
local PAN_ECHELLE = 0.22  -- echelle de l'enseigne (identique aux archives)
local PAN_HAUT = 78       -- hauteur de l'enseigne au-dessus du sol

-- Reglage vivant, pour finir de caler a l'oeil sans attendre un deploiement :
-- `evo_clan_domaine_hauteur -20` dans la console descend l'enseigne, une valeur
-- positive la remonte. Sauvegarde entre deux parties.
CreateClientConVar("evo_clan_domaine_hauteur", "0", true, false,
    "Decalage vertical de l'enseigne d'entree du domaine de clan (unites)")

-- `nPortee` (optionnelle) allonge la distance de rendu : le mode « voir les
-- positions » doit montrer des points a l'autre bout de la map, la portee
-- normale (2000u, environ 38 m) ne servirait a rien pour aller les chercher.
local function DessinerPanneau(vPosBrute, sTitre, sLigne, cLigne, nPortee)
    local vPos = PoseAuSol(vPosBrute)
    local ply = LocalPlayer()
    local nDistSqr = ply:GetPos():DistToSqr(vPos)
    nPortee = nPortee or D.DrawDistance or 2000
    if nDistSqr > nPortee ^ 2 then return end

    -- Respiration douce, et fondu sur la distance : le marqueur n'apparait pas
    -- d'un bloc quand on entre dans sa portee.
    local nPulse = 170 + math.sin(RealTime() * 2.2) * 60
    local nFondu = math.Clamp(1.6 - math.sqrt(nDistSqr) / nPortee, 0, 1)
    local cCercle = cLigne or MUTED

    -- Le cercle est A PLAT sur le sol : yaw, pitch et roll a zero, echelle 1.
    cam.Start3D2D(vPos + Vector(0, 0, 3), Angle(0, 0, 0), 1)
        surface.SetAlphaMultiplier(nFondu)
        surface.DrawCircle(0, 0, PAN_RAYON, cCercle.r, cCercle.g, cCercle.b, nPulse)
        surface.DrawCircle(0, 0, PAN_RAYON - 3, cCercle.r, cCercle.g, cCercle.b, nPulse * 0.55)
        surface.DrawCircle(0, 0, PAN_RAYON * 0.22, cCercle.r, cCercle.g, cCercle.b, nPulse * 0.45)
        surface.SetAlphaMultiplier(1)
    cam.End3D2D()

    -- Enseigne face au joueur. L'angle se prend sur EyePos et non sur la
    -- position du joueur : en vue a la troisieme personne les deux different et
    -- le texte partait de biais.
    local aAng = (EyePos() - vPos):Angle()
    local nHaut = PAN_HAUT + GetConVar("evo_clan_domaine_hauteur"):GetFloat()
    cam.Start3D2D(vPos + Vector(0, 0, nHaut), Angle(0, aAng.y + 90, 90), PAN_ECHELLE)
        surface.SetAlphaMultiplier(nFondu)
        if EVO_ZonePrompt and EVO_ZonePrompt.Row then
            -- Style invite partage : « [E]  Action » -> pastille E + action (prefixe
            -- « 12 m  · » en 3e ligne) ; sans [E], la ligne reste un texte d'info.
            local sPre, sAct = string.match(sLigne, "^(.-)%[E%]%s*(.+)$")
            if sAct then
                sPre = string.match(sPre, "^(.-)[%s\194\183]*$")
                EVO_ZonePrompt.Row(-40, sTitre, sAct, "E", "point", sPre ~= "" and sPre or nil)
            else
                EVO_ZonePrompt.Row(-40, sTitre, sLigne, "", "point")
            end
        else
            draw.SimpleText(sTitre, "EVO_Domaine_Titre", 0, -40,
                Color(ACCENT.r, ACCENT.g, ACCENT.b, math.min(255, nPulse + 70)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(sLigne, "EVO_Domaine_Sous", 0, 46,
                Color(cCercle.r, cCercle.g, cCercle.b, math.min(230, nPulse + 40)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        surface.SetAlphaMultiplier(1)
    cam.End3D2D()
end

-- ── EMPLACEMENTS ACHETABLES ─────────────────────────────────────────────────
-- Le serveur envoie l'occupation (evo_clan:dom_slots) : id d'emplacement ->
-- nom du clan proprietaire. Le client ne la calcule jamais lui-meme, il ne
-- connait ni la base ni les cles de clan.
local _occupes = {}

net.Receive("evo_clan:dom_slots", function()
    _occupes = {}
    for _ = 1, net.ReadUInt(8) do
        local sId = net.ReadString()
        _occupes[sId] = net.ReadString()
    end
end)

-- « Voir les positions » (banque du clan, onglet UPGRADES) : pendant ce temps
-- les emplacements LIBRES se dessinent de tres loin, avec leur distance. Sans
-- ce mode, un clan qui vient de payer le bail devrait longer la map au hasard
-- pour trouver un point a portee de rendu.
EVO_CLAN.DomaineGuidageFin = 0
function EVO_CLAN.DomaineGuidage(nDuree)
    EVO_CLAN.DomaineGuidageFin = CurTime() + (nDuree or 180)
end

local function EnGuidage() return CurTime() < (EVO_CLAN.DomaineGuidageFin or 0) end

local function DessinerEmplacements(ply)
    local tEmps = EVO_CLAN.DomaineEmplacements()
    if #tEmps == 0 then return false end

    local sMien = ply:GetEvoNWString("EVO_ClanDomaineSlot", "")
    local sKey = ply:GetEvoNWString("EVO_ClanKey", "")
    local bAcces = ply:GetEvoNWBool("EVO_ClanBuildingAccess", false)
    local bChef = ply:GetEvoNWBool("EVO_ClanLeader", false) or ply:GetEvoNWBool("EVO_ClanOfficer", false)
    local bGuide = EnGuidage()
    -- 20 000 unites : le diametre utile de rp_seireitei_v1. Assez pour voir tous
    -- les points depuis n'importe ou, sans dessiner ce qui est hors map.
    local nPortee = bGuide and 20000 or nil

    for _, emp in ipairs(tEmps) do
        local sProprio = _occupes[emp.id]
        if emp.id == sMien then
            DessinerPanneau(emp.pos, "DOMAINE DE TON CLAN", "[E]  Entrer", BLANC)
        elseif sProprio then
            -- Le domaine d'un autre clan reste VISIBLE : c'est une porte dans le
            -- decor, la cacher ferait croire l'emplacement libre a qui passe.
            DessinerPanneau(emp.pos, "DOMAINE", sProprio, MUTED)
        elseif sMien ~= "" then
            -- On a deja le sien : les autres points ne sont plus des offres.
            if bGuide then DessinerPanneau(emp.pos, "EMPLACEMENT", "Libre", MUTED, nPortee) end
        elseif sKey == "" then
            if bGuide then DessinerPanneau(emp.pos, "EMPLACEMENT", "Réservé aux clans", MUTED, nPortee) end
        elseif not bAcces then
            DessinerPanneau(emp.pos, "EMPLACEMENT LIBRE", "Bail requis : banque du clan, onglet UPGRADES", ACCENT, nPortee)
        elseif not bChef then
            DessinerPanneau(emp.pos, "EMPLACEMENT LIBRE", "Le chef de clan choisit l'emplacement", MUTED, nPortee)
        else
            local nM = math.floor(ply:GetPos():Distance(EVO_CLAN.DomainePoseAuSol(emp.pos)) / 52.5)
            DessinerPanneau(emp.pos, "EMPLACEMENT LIBRE",
                bGuide and (nM .. " m  ·  [E]  Acheter") or "[E]  Acheter", BLANC, nPortee)
        end
    end
    return true
end

hook.Add("PostDrawTranslucentRenderables", "EVO_Clan::DomaineMarqueurs", function(bDepth, bSkybox)
    if bSkybox or bDepth then return end
    if not D.Enabled then return end
    local tPoses = EVO_CLAN.DomainePoses()
    if not tPoses then return end

    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local sZone = ply:GetEvoNWString("NCM_InstanceZone", "")

    if EVO_CLAN.IsDomaineZone(sZone) then
        DessinerPanneau((tPoses.retour or tPoses.arrivee).pos, "DOMAINE DU CLAN", "[E]  Ressortir", BLANC)
        if tPoses.invite then
            DessinerPanneau(tPoses.invite.pos, "INVITER", "[E]  Faire venir un visiteur", BLANC)
        end
        return
    end

    -- Dans une AUTRE instance (tuto, Bataille) : aucun marqueur, le E ne
    -- fonctionnerait pas et le panneau mentirait.
    if ply:GetEvoNWBool("NCM_Instanced", false) then return end

    -- Map avec emplacements achetables : ils REMPLACENT l'entree fixe. Dessiner
    -- les deux montrerait une porte qui ne repond pas au E.
    if DessinerEmplacements(ply) then return end

    if not tPoses.entree then return end

    local sKey = ply:GetEvoNWString("EVO_ClanKey", "")
    if sKey == "" then
        DessinerPanneau(tPoses.entree.pos, "DOMAINE DE CLAN", "Réservé aux clans", MUTED)
    elseif not ply:GetEvoNWBool("EVO_ClanBuildingAccess", false) then
        DessinerPanneau(tPoses.entree.pos, "DOMAINE DE CLAN", "Achat requis : banque du clan, onglet UPGRADE", ACCENT)
    else
        DessinerPanneau(tPoses.entree.pos, "DOMAINE DE CLAN", "[E]  Entrer", BLANC)
    end
end)

-- ── Menus d'invitation ──────────────────────────────────────────────────────
-- Meme grammaire que le reste du panel clan : fond sombre, accent rouge, angles
-- nets. Deux ecrans : la LISTE (chez le membre qui invite) et le POPUP (chez le
-- visiteur invite).

local function FermerSi(frame)
    if IsValid(frame) then frame:Remove() end
end

-- DFrame sans chrome Derma (croix / réduction). Croix DA en haut à droite.
-- Échap : même chemin que l'inventaire (EVO_MakeEscClosable + Close).
local function SansChrome(f, onClose)
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:SetDraggable(false)
    local function doClose()
        if not IsValid(f) then return end
        if onClose then onClose() else FermerSi(f) end
    end
    local x = vgui.Create("DButton", f)
    x:SetText("")
    x:SetSize(28, 28)
    x:SetPos(f:GetWide() - 36, 8)
    x:SetZPos(1000)
    x:SetCursor("hand")
    x.Paint = function(s, w, h)
        draw.SimpleText("✕", "DermaDefaultBold", w / 2, h / 2,
            s:IsHovered() and ACCENT or MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = doClose
    f.Close = doClose
    f:MakePopup()
    if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
    return x
end

local _fListe
net.Receive("evo_clan:dom_liste", function()
    local n = net.ReadUInt(5)
    local t = {}
    for _ = 1, n do
        t[#t + 1] = { sid = net.ReadString(), nom = net.ReadString() }
    end

    FermerSi(_fListe)
    local f = vgui.Create("DFrame")
    _fListe = f
    f:SetSize(380, 110 + math.max(1, #t) * 40)
    f:Center()
    SansChrome(f, function() FermerSi(f) end)
    f.Paint = function(_, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 13, 245))
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, w, 3)
        draw.SimpleText("INVITER AU DOMAINE", "EVO_Domaine_Sous", w / 2, 26, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Joueurs proches de l'entrée du domaine", "DermaDefault", w / 2, 52, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local y = 72
    if #t == 0 then
        local l = vgui.Create("DLabel", f)
        l:SetPos(0, y + 8)
        l:SetSize(380, 20)
        l:SetText("Personne près de l'entrée pour l'instant.")
        l:SetContentAlignment(5)
        l:SetTextColor(MUTED)
    end
    for _, e in ipairs(t) do
        local b = vgui.Create("DButton", f)
        b:SetPos(20, y)
        b:SetSize(340, 32)
        b:SetText("")
        b.Paint = function(pnl, w, h)
            draw.RoundedBox(4, 0, 0, w, h, pnl:IsHovered() and Color(207, 68, 78, 40) or Color(255, 255, 255, 8))
            draw.SimpleText(e.nom, "DermaDefaultBold", 12, h / 2, BLANC, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("Inviter", "DermaDefault", w - 12, h / 2, pnl:IsHovered() and ACCENT or MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function()
            net.Start("evo_clan:dom_invite")
                net.WriteString(e.sid)
            net.SendToServer()
            FermerSi(f)
        end
        y = y + 40
    end
end)

local _fPopup
net.Receive("evo_clan:dom_invited", function()
    local sPar = net.ReadString()
    local sClan = net.ReadString()
    local nTimeout = net.ReadUInt(6)

    FermerSi(_fPopup)
    local f = vgui.Create("DFrame")
    _fPopup = f
    f:SetSize(400, 150)
    f:Center()
    local nFin = CurTime() + nTimeout
    f.Paint = function(_, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 13, 245))
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, w, 3)
        draw.SimpleText("INVITATION AU DOMAINE", "EVO_Domaine_Sous", w / 2, 28, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(sPar .. (sClan ~= "" and (" · clan " .. sClan) or "") .. " t'invite dans son domaine.",
            "DermaDefault", w / 2, 58, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local nReste = math.max(0, math.ceil(nFin - CurTime()))
        draw.SimpleText(nReste .. " s", "DermaDefault", w / 2, 78, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if nReste <= 0 then FermerSi(f) end
    end

    local function repondre(bOui)
        net.Start("evo_clan:dom_answer")
            net.WriteBool(bOui)
        net.SendToServer()
        FermerSi(f)
    end
    SansChrome(f, function() repondre(false) end)

    local bOk = vgui.Create("DButton", f)
    bOk:SetPos(40, 102)
    bOk:SetSize(150, 32)
    bOk:SetText("")
    bOk.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, pnl:IsHovered() and Color(207, 68, 78, 220) or Color(178, 55, 64, 200))
        draw.SimpleText("Accepter", "DermaDefaultBold", w / 2, h / 2, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    bOk.DoClick = function() repondre(true) end

    local bNo = vgui.Create("DButton", f)
    bNo:SetPos(210, 102)
    bNo:SetSize(150, 32)
    bNo:SetText("")
    bNo.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, pnl:IsHovered() and Color(255, 255, 255, 25) or Color(255, 255, 255, 10))
        draw.SimpleText("Refuser", "DermaDefaultBold", w / 2, h / 2, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    bNo.DoClick = function() repondre(false) end
end)

-- ── Achat d'un emplacement ──────────────────────────────────────────────────
-- Le serveur ouvre cette fenetre quand on appuie E sur un point libre et qu'on
-- a le droit d'acheter. Elle est VOLONTAIREMENT une confirmation et pas un
-- achat direct : le choix est definitif, l'emplacement devient celui du clan et
-- personne d'autre ne peut le prendre.
local _fAchat
net.Receive("evo_clan:dom_buyui", function()
    local sId = net.ReadString()
    local emp = EVO_CLAN.DomaineEmplacement(sId)
    if not emp then return end

    FermerSi(_fAchat)
    local CFG = EVO_CLAN.Config
    local bTaxe = CFG and CFG.TaxEnabled and CFG.BuildingUpgradeEnabled == true
    local nTaxe = (CFG and CFG.DailyTax) or 3333
    local nH = bTaxe and 236 or 190
    local f = vgui.Create("DFrame")
    _fAchat = f
    f:SetSize(440, nH)
    f:Center()
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:MakePopup()
    f.Paint = function(_, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 13, 245))
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, w, 3)
        draw.SimpleText("EMPLACEMENT DU DOMAINE", "EVO_Domaine_Sous", w / 2, 30, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Installer l'entrée du domaine de ton clan ici ?", "DermaDefault", w / 2, 66, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if bTaxe then
            draw.SimpleText("Le premier jour de taxe (" .. string.Comma(nTaxe) .. " ¥) est prélevé",
                "DermaDefault", w / 2, 90, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("automatiquement sur la banque du clan.", "DermaDefault", w / 2, 108, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("Ce point devient celui de ton clan. Le choix est définitif.",
                "DermaDefault", w / 2, 130, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText("Ce point devient celui de ton clan et personne d'autre", "DermaDefault", w / 2, 88, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("ne pourra le prendre. Le choix est définitif.", "DermaDefault", w / 2, 106, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    local bOk = vgui.Create("DButton", f)
    bOk:SetPos(40, nH - 52)
    bOk:SetSize(170, 34)
    bOk:SetText("")
    bOk.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, pnl:IsHovered() and Color(207, 68, 78, 220) or Color(178, 55, 64, 200))
        draw.SimpleText("Acheter celui-ci", "DermaDefaultBold", w / 2, h / 2, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    bOk.DoClick = function()
        net.Start("evo_clan:dom_buy")
            net.WriteString(sId)
        net.SendToServer()
        FermerSi(f)
    end

    local bNo = vgui.Create("DButton", f)
    bNo:SetPos(230, nH - 52)
    bNo:SetSize(170, 34)
    bNo:SetText("")
    bNo.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, pnl:IsHovered() and Color(255, 255, 255, 25) or Color(255, 255, 255, 10))
        draw.SimpleText("Annuler", "DermaDefaultBold", w / 2, h / 2, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    bNo.DoClick = function() FermerSi(f) end
end)
