-- "addons\\evo_clan\\lua\\evo_clan\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
EVO_CLAN = EVO_CLAN or {}

EVO_CLAN.Config = {
    -- ── NIVEAUX DE CLAN (2026-07-22, demande user) ──────────────────────────
    -- Chaque niveau = un plafond de membres (leader inclus). Le niveau se monte
    -- depuis la BANQUE DU CLAN (leader/bras droit), séquentiellement. Le NIVEAU 3
    -- débloque l'accès à la DEMANDE DE SPELL UNIQUE (voir SpellRequest).
    -- Le niveau d'un clan = objectives_done + 1 (compteur meta réutilisé) :
    --   objectives_done 0 -> Niveau 1, 1 -> Niveau 2, 2 -> Niveau 3.
    -- Plafonds de membres 6 / 8 / 12 (demande user 07/24).
    ClanLevels = {
        { max = 6 },                                        -- Niveau 1 (base, à la création)
        { max = 8, cost = 200000 },                         -- Niveau 2 (débloqué pour 200 000 ¥)
        { max = 12, cost = 300000, spellRequest = true },   -- Niveau 3 (300 000 ¥) + demande de spell unique
    },

    -- Plafond de membres au niveau 1 (= ClanLevels[1].max). Gardé pour les
    -- chemins « sans clan » qui ont besoin d'un défaut d'affichage.
    MaxMembers = 6,

    -- Boost d'XP : +1 % par AUTRE membre du clan CONNECTÉ (soi exclu).
    -- 4 membres en ligne -> chacun gagne +3 %. Appliqué dans Player:AddXP
    -- (après le grade premium) et affiché en total dans le menu clan.
    XPBoostPerMember = 0.01,

    -- Durée de validité d'une invitation (secondes).
    InviteTimeout = 60,

    -- Portée d'invitation (unités) : le leader n'invite que les joueurs AUTOUR
    -- de lui (liste ET action revalidées serveur, pattern evo_famille durci).
    InviteRadius = 600,

    -- Plafond de membres (hors chef) auxquels le leader peut apprendre le sort
    -- de clan attribué par un superadmin. Le chef l'a toujours, sans slot.
    MaxClanSpellHolders = 7,

    -- ── PNJ « Doyen des Clans » : point d'accès PHYSIQUE au menu de clan (E) ──
    -- Les clans étant FIXES, le Doyen ne CRÉE rien : parler au PNJ ouvre
    -- EVO_CLAN.OpenUI (exactement comme le bind « Mon Clan » / !clan), pour tout
    -- le monde (avec ou sans clan). Spawn par map via NPCSpawnPositions (provider
    -- EVO_NPC, catch-up boot) + commande de placement SA `evo_clan_npc_here`.
    -- Modèle repris du « Gestionnaire de clan » famille (casse exacte fournie par
    -- le user 2026-06), avec repli auto si le pack d'assets n'est pas monté.
    NPCModel         = "models/evo/summons/shinigami/evo_bdfze942fzd3sdaadxdzd/evo_Bdfze942fzd3sdaadXDZD.mdl",
    NPCName          = "Doyen des Clans",
    NPCSubtitle      = "", -- pas de sous-titre au-dessus de la tête (demande user 07/14)
    NPCScale         = 1.0,
    PromptDistance   = 160, -- portée d'affichage du prompt [E] (= portée d'interaction réelle)
    InteractDistance = 200, -- garde serveur du ENT:Use (marge au-dessus du prompt)
    MaxZDelta        = 200,
    -- Positions de spawn par map. Une entrée = un Doyen. pos/ang ramassés via
    -- `evo_clan_npc_here` (yaw BRUT, jamais +180). Seed : l'ancien spot du doyen
    -- famille au Seireitei (libre depuis la désactivation d'evo_famille) + test.
    NPCSpawnPositions = {
        rp_seireitei_v1 = {
            { pos = Vector(-3421.29, -12499.03, 461.41), ang = Angle(0, 91.39, 0) },
        },
        hueco_mundo_v1 = {
            -- À CÔTÉ du coiffeur (lzy_coiffeur hueco : 2710.77 7953.03 5359.37, yaw
            -- 85.40) : même orientation, décalé de 70u sur SA DROITE (yaw-90) pour
            -- rester adjacent sans se chevaucher. Z re-snappé au sol à l'init.
            { pos = Vector(2710.770752, 7953.031250, 5359.369629) + Angle(0, 85.40 - 90, 0):Forward() * 70, ang = Angle(0, 85.40, 0) },
        },
        gm_construct = {
            { pos = Vector(40, -80, -135), ang = Angle(0, 90, 0) },
        },
    },

    -- ── DEMANDE DE SPELL UNIQUE (2026-07-22, demande user) ───────────────────
    -- Un clan NIVEAU 3 peut DEMANDER un spell unique. La demande part en file
    -- d'attente pour les SUPERADMINS (onglet Admin) qui acceptent/refusent. Le
    -- clan doit remplir TOUS ces prérequis (revalidés serveur au moment du clic) :
    SpellRequest = {
        MinClanLevel        = 3,     -- clan niveau 3 minimum (débloque l'accès)
        MinMembers          = 10,    -- au moins 10 membres
        MaxWarns            = 0,     -- 0 warn de clan ACTIF (chaque warn dure 7 jours)
        HighLevelThreshold  = 60,    -- « membre haut niveau » = niveau perso >= 60
        MinHighLevelMembers = 10,    -- au moins 10 membres au-dessus du niveau 60
        MinAgeDays          = 7,     -- clan âgé d'au moins 1 semaine (created_at)
    },

    -- Warn de clan : chaque entrée reste ACTIVE 7 jours (prérequis spell unique
    -- = 0 warn ACTIF). L'historique est conservé après expiration / retrait.
    ClanWarnDuration = 7 * 86400,
    -- SEUIL DE DISSOLUTION (user 09/14-15) : dès que le clan atteint ce nombre de warns
    -- de clan ACTIFS (posés à la main par un SA OU hérités d'un warn / ban d'un membre,
    -- cf. hooks EVO_Warns::Added / SAM.Banned* dans sv_main), sa dissolution est SOUMISE
    -- à un superadmin (meta.disband_req_status = 'pending' ; décision par
    -- sa_disband_decision, jamais automatique). Repasser sous le seuil (warn levé)
    -- annule la demande. 0 = désactivé.
    ClanWarnDisbandAt = 3,
    -- Seuil de BLOCAGE DU SORT DE CLAN (user 09/19) : dès que le clan atteint ce
    -- nombre de warns ACTIFS, le sort attribué (flash / vide) est inutilisable.
    -- Repasser dessous le réactive. 0 = désactivé.
    ClanWarnSpellLockAt = 3,

    -- BANQUE DE CLAN + OBJECTIFS : les membres déposent des yens dans la
    -- banque du clan ; le LEADER ou le BRAS DROIT valide les objectifs.
    -- 1) NIVEAU DE CLAN : voir ClanLevels ci-dessus (8 -> 12 -> 15 membres).
    -- 2) SPELLS : chaque achat débloque le Spell de clan SUIVANT (les spells 2..5
    --    de la liste tSpells du clan, quand ils existeront). Achat k = k x 1M :
    --    1M -> 2e sort, 2M -> 3e, 3M -> 4e, 4M -> 5e. Max 5 sorts en tout.
    MaxSpells = 5,
    SpellCostBase = 1000000,
    PotDepositMin = 1000, -- dépôt minimum par versement
    -- RETRAIT banque (permission WITHDRAW) : le montant sort de la banque, le
    -- joueur reçoit (100 - PotWithdrawTaxPercent) % ; la taxe est brûlée.
    PotWithdrawMin = 1000,
    PotWithdrawTaxPercent = 5,
    BankLogLimit = 50, -- lignes d'historique envoyées à l'onglet BANQUE

    -- RÉCOMPENSES DE CLAN (onglet Upgrades) — le LEADER choisit la RARETÉ du
    -- coffre qu'il donne à un membre ÉLIGIBLE. Tout se RESET chaque semaine
    -- (clé de semaine, reset naturel au lundi — aucun cron) :
    --  - QUOTAS PAR RARETÉ et par clan / semaine (demande user : 2/2/2,
    --    PAS de légendaire), BOOSTÉS par les upgrades du clan (voir bonus).
    --  - ÉLIGIBILITÉ d'un membre = activité DE LA SEMAINE : temps de jeu
    --    hebdo min ET dons hebdo min (requirements in game).
    --  - 1 coffre max PAR MEMBRE et par semaine.
    -- Les SUPERADMINS peuvent COUPER toute la distribution (interrupteur,
    -- onglet Admin), stocké en BDD partagée.
    -- weekly = slots de BASE ; maxWeekly = plafond atteignable via la ligne
    -- « UPGRADE DES COFFRES » de la banque (voir ChestUpgradeCost).
    -- Le LÉGENDAIRE part de 0 : il n'existe qu'une fois Commun/Rare/Épique
    -- tous montés à 5 (demande user) — un quota 0 = rareté MASQUÉE partout.
    RewardChoices = {
        { chest = "coffre_commun",     label = "Coffre Commun",     short = "COMMUN",  weekly = 2, maxWeekly = 5 },
        { chest = "coffre_rare",       label = "Coffre Rare",       short = "RARE",    weekly = 2, maxWeekly = 5 },
        { chest = "coffre_epique",     label = "Coffre Épique",     short = "ÉPIQUE",  weekly = 2, maxWeekly = 5 },
        { chest = "coffre_legendaire", label = "Coffre Légendaire", short = "LÉGEND.", weekly = 0, maxWeekly = 5 },
    },
    -- 3e OBJECTIF de la banque (demande user) : tous les 500k, +1 slot de
    -- coffre hebdo, SÉQUENTIEL : Commun 2->5, puis Rare 2->5, puis Épique
    -- 2->5, puis Légendaire 0->5 (14 upgrades en tout — le légendaire
    -- n'apparaît qu'à partir du 10e, une fois les 3 autres au max).
    ChestUpgradeCost = 250000, -- (demande user 07/24 : upgrade coffre clan 250 000 ¥)
    RewardMinWeeklyPlaytime = 30 * 3600, -- temps de jeu MIN dans la semaine (30 h, demande user)
    RewardMinWeeklyDons     = 50000,     -- dons MIN dans la semaine (ajustable)
    RewardMaxPerMember      = 2,         -- coffres MAX par membre éligible et par semaine

    -- ── CRÉATION DE CLAN (bascule modèle FAMILLE, 2026-07-14) ────────────────
    -- Les clans ne sont plus FIXES : chaque joueur peut FONDER son clan (nom
    -- libre) chez le Doyen / dans le menu. La faction du clan = celle du
    -- fondateur (leader). Conditions revalidées serveur.
    CreateCost     = 200000, -- coût de création (yens, débité au fondateur)
    CreateMinLevel = 30,     -- niveau MINIMUM pour fonder un clan (NWInt "Level")
    ClanNameMinLen = 3,      -- longueur mini du nom
    ClanNameMaxLen = 24,     -- longueur maxi du nom
    RenameCost     = 50000,  -- coût pour renommer le clan (yens, débité sur la BANQUE du clan)

    -- ── GRADES PERSONNALISÉS (2026-07-23, demande user) ──────────────────────
    -- Le LEADER crée jusqu'à MaxRanks grades NOMMÉS par clan, chacun portant un
    -- bitmask de permissions (EVO_CLAN.PERM, plus bas). BDD : table partagée
    -- evo_clan_ranks + colonne rank_id de evo_clan_members (0 = simple membre).
    -- Créer / modifier / supprimer un grade = LEADER SEUL. L'ASSIGNER à un membre =
    -- leader OU bras droit (2026-09-18), règle unique : EVO_CLAN.RankAssignAllowed.
    MaxRanks       = 10, -- grades maximum par clan (revalidé serveur)
    RankNameMinLen = 2,  -- longueur mini du nom d'un grade
    RankNameMaxLen = 24, -- longueur maxi du nom d'un grade

    -- ── TAXE QUOTIDIENNE « Division 1 » (2026-07-14) ─────────────────────────
    -- Chaque clan doit une taxe PAR JOUR, versée à la 1ʳᵉ VRAIE division de sa
    -- faction (evo_division_bank, index >= 2 : l'index 1 = « Aucune »). Le
    -- LEADER ou le BRAS DROIT paient depuis la BANQUE DU CLAN (pot commun) ;
    -- payable jusqu'à TaxPrepayMaxDays jours à l'avance. Clan EN RETARD de taxe
    -- = PERD son emplacement de domaine (les autres clans peuvent l'acheter)
    -- et l'accès au bâtiment tant qu'il n'a pas régularisé. Une fois à jour,
    -- il peut racheter un emplacement libre.
    -- Activee avec le domaine (2026-08-22) : le premier jour est preleve a
    -- la selection d'un emplacement, puis la taxe court au quotidien.
    TaxEnabled       = true,
    DailyTax         = 3333,  -- coût d'UN jour de taxe (50 000 ÷ 15, demande user 2026-07-22)
    TaxPrepayMaxDays = 7,     -- on ne peut pré-payer que jusqu'à 7 jours d'avance
    TaxTargetDivision = 2,    -- index de division créditée (1ʳᵉ vraie division = 2)
    -- Libellé de la division-cible affiché dans l'UI de taxe, PAR FACTION : même
    -- index cible (2) mais nom différent — « Division 1 » (Shinigami) / « Ordre 1 »
    -- (Hollow). NB : purement d'affichage côté clan ; le système de faction global
    -- nomme encore les divisions Hollow « Division N » (renommage à part).
    TaxDivisionLabel = { Shinigami = "Division 1", Hollow = "Ordre 1" },

    -- ── UPGRADE « ACCÈS BÂTIMENT DE FACTION » (2026-07-14, LOGIQUE SEULE) ─────
    -- Achat unique dans la banque : débloque l'accès du clan à un bâtiment de
    -- faction. Pour l'instant = un simple FLAG (meta building_access + NW
    -- EVO_ClanBuildingAccess) ; le bâtiment réel / téléport sera branché plus
    -- tard. L'accès EFFECTIF exige d'être À JOUR de la taxe (voir ci-dessus).
    -- BuildingUpgradeEnabled = true depuis le 2026-08-15 : le DOMAINE DE CLAN
    -- est branché (sh/sv/cl_domaine.lua, instance partagée par clan). L'achat
    -- de la banque donne le droit de choisir un emplacement ; la taxe
    -- (TaxEnabled) est prelevee au premier jour de cette selection.
    BuildingUpgradeEnabled = true,
    BuildingUpgradeCost = 250000, -- (demande user 07/24 : acheter le bâtiment de clan 250 000 ¥)

    -- ── PANNEAU 3D « CLASSEMENT DES CLANS » — AUTONOME (07/24) ──────────────
    -- Refait sur le MÊME schéma que evo_leaderboard (AUTO_SPAWN_POSITIONS) : le
    -- classement clan est désormais un panneau À PART ENTIÈRE avec sa PROPRE
    -- pose, rendu seul via cam.Start3D2D(pos, angle, scale) — il n'est PLUS
    -- « collé » au panneau Hollow via un offset (d'où il ne suivait pas ses
    -- rotations). Par map : liste de { pos, angle, scale, faction } (faction =
    -- verrou des clans affichés, comme l'onglet Classement).
    -- Rendu : autorun/client/cl_clan_leaderboard3d.lua.
    -- Poses initiales = là où le panneau apparaissait collé (offset baké : la
    -- largeur du panneau leaderboard, 2304 px × 0.15 = 345,6 u le long du
    -- Forward) -> zéro régression visuelle, à ajuster librement ensuite.
    LbPanels = {
        ["rp_seireitei_v1"] = {
            { pos = Vector(-2295.508000, -12437.762727, 519.031250), angle = Angle(0, 178.680695, 90),  scale = 0.15, faction = "Shinigami" },
        },
        ["hueco_mundo_v1"] = {
            { pos = Vector(3184.968750, 8953.610352, 5534.065430), angle = Angle(0, -90, 90), scale = 0.15, faction = "Hollow" }, -- 07/25 : DEBOUT face -X (roll 90) ; décalé +200 en Y (vers la droite du panneau) ; côté Chirurgien esthétique
        },
    },

    -- Registre des clans : DYNAMIQUE. Rempli au runtime (serveur) depuis la
    -- table BDD evo_clans par RefreshClansCache -> { [clan_key] = { label, faction } }.
    -- Le code lit toujours CFG.Clans[key] / CFG.ClanOrder : ils reflètent l'état
    -- BDD courant (clans créés par les joueurs), plus une liste fixe.
    Clans = {},
    ClanOrder = {},
}

-- ── PERMISSIONS des grades personnalisés (bitmask, PARTAGÉ client/serveur) ──
-- Un grade accorde un SOUS-ENSEMBLE de ces bits à ses porteurs. Le LEADER et le
-- BRAS DROIT ont TOUJOURS tout (compat : ils avaient déjà ces droits). La
-- gestion des grades, la nomination du bras droit et la demande de spell
-- restent hors bitmask (leader, + bras droit pour la demande de spell et pour
-- l'ASSIGNATION d'un grade — cf. RankAssignAllowed plus bas).
EVO_CLAN.PERM = {
    INVITE   = 1,  -- inviter des joueurs (à proximité, mêmes règles que le leader)
    KICK     = 2,  -- exclure un membre (JAMAIS le leader ni le bras droit)
    UPGRADE  = 4,  -- achats depuis la banque (niveau / coffres / bâtiment) — label UI « UPGRADE »
    CHESTS   = 8,  -- distribuer les coffres hebdo aux membres éligibles
    TAX      = 16, -- payer la taxe quotidienne depuis la banque
    BATTLE   = 32, -- participer à la Bataille des Clans
    WITHDRAW = 64, -- retirer des yens de la banque (taxe PotWithdrawTaxPercent) — « RETRAIT »
    COFFRE   = 128, -- retirer un objet du coffre du domaine (le dépôt est ouvert à tout membre)
}

-- Liste ORDONNÉE pour l'UI (chips de création de grade + résumé par grade).
EVO_CLAN.PermList = {
    { bit = EVO_CLAN.PERM.INVITE,   label = "INVITER" },
    { bit = EVO_CLAN.PERM.KICK,     label = "EXCLURE" },
    { bit = EVO_CLAN.PERM.WITHDRAW, label = "RETRAIT" },
    { bit = EVO_CLAN.PERM.UPGRADE,  label = "UPGRADE" },
    { bit = EVO_CLAN.PERM.CHESTS,   label = "COFFRES" },
    { bit = EVO_CLAN.PERM.COFFRE,   label = "COFFRE" },
    { bit = EVO_CLAN.PERM.TAX,      label = "TAXE" },
    { bit = EVO_CLAN.PERM.BATTLE,   label = "BATAILLE" },
}

-- ── Qui peut ASSIGNER un grade à qui (2026-09-18, demande user : « le bras droit
-- doit pouvoir mettre des grades aux autres membres »). Créer / modifier /
-- supprimer un grade reste LEADER SEUL. SOURCE UNIQUE : le serveur gate
-- rank_assign avec cette fonction, le client cache ou montre le bouton GRADE
-- avec elle aussi — les deux ne peuvent pas diverger.
--  · le leader assigne à n'importe quel membre, jamais à lui-même (un leader
--    n'a pas de grade : il a déjà tout, et l'UI ne l'afficherait pas) ;
--  · le bras droit assigne aux membres SIMPLES seulement : ni au leader (qui le
--    dépasse), ni à un autre bras droit (son pair, que seul le leader nomme).
-- Renvoie true, ou (false, raison affichable).
function EVO_CLAN.RankAssignAllowed(bActorLeader, bActorOfficer, bTargetLeader, bTargetOfficer)
    if bActorLeader then
        if bTargetLeader then return false, "Le leader n'a pas de grade." end
        return true
    end
    if bActorOfficer then
        if bTargetLeader then return false, "Le bras droit ne peut pas donner de grade au leader." end
        if bTargetOfficer then return false, "Le bras droit ne peut pas donner de grade à un autre bras droit." end
        return true
    end
    return false, "Seuls le leader et le bras droit peuvent assigner un grade."
end

-- Union de tous les bits : bitmask effectif du leader / bras droit, et masque
-- de nettoyage des bits inconnus d'un net forgé (serveur, rank_create).
EVO_CLAN.PermAll = 0
for _, nBit in pairs(EVO_CLAN.PERM) do
    EVO_CLAN.PermAll = bit.bor(EVO_CLAN.PermAll, nBit)
end

-- Hueco Mundo = serveur Arrancar : le Doyen y est un Arrancar (demande user 2026-07-24).
-- Override AVANT le repli de validité ci-dessous (il protège donc aussi ce modèle).
-- Le Seireitei garde son modèle Shinigami.
if game.GetMap() == "hueco_mundo_v1" then
    EVO_CLAN.Config.NPCModel = "models/evo/summons/arrancar/evo_w42qywutq3awo/evo_k87h3m96ffoee2.mdl"
end

-- Repli auto du modèle du Doyen : pack d'assets absent -> modèle commun (le PNJ
-- reste un vendeur, pas un citoyen rose/noir). init.lua garde le repli citoyen
-- en tout dernier recours. Testé côté serveur (util.IsValidModel dispo au load).
if SERVER and not util.IsValidModel(EVO_CLAN.Config.NPCModel) then
    print("[evo_clan] modele du Doyen absent (" .. EVO_CLAN.Config.NPCModel .. ") -> fallback modele commun")
    EVO_CLAN.Config.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end

-- Infos d'un clan par clé (ou nil).
function EVO_CLAN.GetClan(sKey)
    return EVO_CLAN.Config.Clans[sKey or ""]
end

-- Classement GÉNÉRAL (menu + panneau 3D) : rang dans CHAQUE colonne (1 = meilleur),
-- somme des rangs (plus petit = mieux). Même idée que evo_famille weekly — les
-- unités hétérogènes (heures vs ¥ vs victoires) ne se marchent pas dessus.
-- Égalité dans une colonne = même rang (1, 1, 3).
EVO_CLAN.LbRankKeys = { "hours", "kills", "lvl", "wins", "battles", "pot" }

function EVO_CLAN.SortClansOverall(tRows)
    tRows = tRows or {}
    local n = #tRows
    if n <= 1 then return tRows end
    for i = 1, n do tRows[i]._lbPts = 0 end
    for _, key in ipairs(EVO_CLAN.LbRankKeys) do
        local ord = {}
        for i = 1, n do ord[i] = tRows[i] end
        table.sort(ord, function(a, b)
            return (tonumber(a[key]) or 0) > (tonumber(b[key]) or 0)
        end)
        local lastVal, lastRank, rankOf = nil, nil, {}
        for i = 1, n do
            local r = ord[i]
            local v = tonumber(r[key]) or 0
            if lastVal == nil or v ~= lastVal then
                lastRank, lastVal = i, v
            end
            rankOf[r] = lastRank
        end
        for i = 1, n do
            local r = tRows[i]
            r._lbPts = r._lbPts + (rankOf[r] or n)
        end
    end
    table.sort(tRows, function(a, b)
        local pa, pb = a._lbPts or 0, b._lbPts or 0
        if pa ~= pb then return pa < pb end
        local ba, bb = tonumber(a.battles) or 0, tonumber(b.battles) or 0
        if ba ~= bb then return ba > bb end
        local wa, wb = tonumber(a.wins) or 0, tonumber(b.wins) or 0
        if wa ~= wb then return wa > wb end
        local poa, pob = tonumber(a.pot) or 0, tonumber(b.pot) or 0
        if poa ~= pob then return poa > pob end
        return (tonumber(a.hours) or 0) > (tonumber(b.hours) or 0)
    end)
    return tRows
end

-- Fraction d'XP bonus pour n AUTRES membres en ligne (soi exclu).
function EVO_CLAN.OnlineXPBoostFrac(nOtherOnline)
    return math.max(0, math.floor(tonumber(nOtherOnline) or 0)) * (EVO_CLAN.Config.XPBoostPerMember or 0)
end

-- Compte les membres du clan CONNECTÉS sur CE serveur, hors pExclude.
function EVO_CLAN.CountOtherOnlineMembers(sKey, pExclude)
    if not sKey or sKey == "" then return 0 end
    local n = 0
    for _, p in player.Iterator() do
        if IsValid(p) and p ~= pExclude and not p:IsBot()
            and p:GetEvoNWString("EVO_ClanKey", "") == sKey then
            n = n + 1
        end
    end
    return n
end

-- Multiplicateur d'XP clan (1 + boost membres en ligne). AddXP l'applique
-- APRÈS le grade premium pour que +3 % survive le floor sur 20 XP.
function EVO_CLAN.GetXPMult(ply)
    if not IsValid(ply) then return 1 end
    local sKey = ply:GetEvoNWString("EVO_ClanKey", "")
    if sKey == "" then return 1 end
    local frac = EVO_CLAN.OnlineXPBoostFrac(EVO_CLAN.CountOtherOnlineMembers(sKey, ply))
    if frac <= 0 then return 1 end
    return 1 + frac
end

-- ── Niveaux de clan (plafond de membres) ────────────────────────────────────
-- Plafond de membres pour un niveau donné (clampé à la plage valide).
function EVO_CLAN.ClanCapForLevel(nLevel)
    local t = EVO_CLAN.Config.ClanLevels or {}
    nLevel = math.Clamp(math.floor(nLevel or 1), 1, math.max(#t, 1))
    return (t[nLevel] and t[nLevel].max) or 8
end

-- Seuil de blocage du sort de clan (warns actifs). 0 = pas de blocage.
function EVO_CLAN.ClanWarnSpellLockAt()
    return math.max(0, math.floor(tonumber((EVO_CLAN.Config or {}).ClanWarnSpellLockAt) or 3))
end

-- Niveau maximum atteignable (dernier palier de ClanLevels).
function EVO_CLAN.MaxClanLevel()
    return #(EVO_CLAN.Config.ClanLevels or { {} })
end

-- Palier du PROCHAIN niveau ({ level, cost, max, spellRequest }) ou nil si déjà
-- au maximum. nLevel = niveau ACTUEL.
function EVO_CLAN.NextClanLevel(nLevel)
    local t = EVO_CLAN.Config.ClanLevels or {}
    local nNext = math.floor(nLevel or 1) + 1
    local e = t[nNext]
    if not e then return nil end
    return { level = nNext, cost = e.cost or 0, max = e.max or 0, spellRequest = e.spellRequest == true }
end

-- ── Upgrades de coffres (ligne « coffres » de la banque) ────────────────────
-- Répartition SÉQUENTIELLE des upgrades : chaque palier de 500k ajoute +1 slot
-- hebdo à la 1re rareté pas encore au max (Commun, puis Rare, Épique, Légendaire).

-- Quotas hebdo PAR RARETÉ ({ [chest_id] = n }) pour n upgrades validés.
function EVO_CLAN.ChestQuotas(nUpgrades)
    local nUp = math.max(0, nUpgrades or 0)
    local t = {}
    for _, c in ipairs(EVO_CLAN.Config.RewardChoices) do
        local nRoom = math.max(0, (c.maxWeekly or c.weekly) - c.weekly)
        local nAdd = math.min(nUp, nRoom)
        t[c.chest] = (c.weekly or 0) + nAdd
        nUp = nUp - nAdd
    end
    return t
end

-- Rareté augmentée par le PROCHAIN upgrade (entrée de RewardChoices), ou nil
-- si tout est au maximum.
function EVO_CLAN.NextChestUpgrade(nUpgrades)
    local nUp = math.max(0, nUpgrades or 0)
    for _, c in ipairs(EVO_CLAN.Config.RewardChoices) do
        local nRoom = math.max(0, (c.maxWeekly or c.weekly) - c.weekly)
        if nUp < nRoom then return c end
        nUp = nUp - nRoom
    end
    return nil
end
