-- "addons\\evo_clan\\lua\\entities\\evo_npc_clan\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- Fonts du nametag 3D2D (créées une fois au chargement client).
surface.CreateFont("EVO_ClanNPC_NameTag", { font = "Roboto", size = 64, weight = 800, antialias = true })
surface.CreateFont("EVO_ClanNPC_Sub",     { font = "Roboto", size = 34, weight = 500, antialias = true })

-- RENDERGROUP_BOTH : model en passe OPAQUE (Draw), nametag en passe TRANSLUCIDE
-- (DrawTranslucent) qui tourne APRÈS tous les props -> avec IgnoreZ le nametag
-- ne peut plus être occluded par un prop dessiné devant.
ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette de nom.
ENT.EVO_PromptZ = 100

local COL_BG  = Color(0, 0, 0, 180)
local COL_TXT = Color(255, 255, 255, 255)
local COL_SUB = Color(224, 178, 58, 255) -- doré (couleur « rôle » du système de clan)

function ENT:Initialize()
end

function ENT:Draw()
    self:DrawModel()
end

function ENT:DrawTranslucent()
    -- Nametag 3D2D au-dessus de la tête, billboard yaw-only face à la caméra.
    -- Distance cull à 750u.
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local ePos = self:GetPos()
    if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

    local cfg  = EVO_CLAN and EVO_CLAN.Config or {}
    local name = cfg.NPCName or "Doyen des Clans"
    local sub  = cfg.NPCSubtitle or ""
    -- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
    if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 100, sub ~= "" and sub or nil, 750, "parler") return end

    local pos = ePos + Vector(0, 0, 100)
    -- face caméra de rendu (EyePos) -> suit la cam orbitale, pas l'angle du joueur.
    local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

    cam.IgnoreZ(true)
    cam.Start3D2D(pos, ang, 0.15)
        surface.SetFont("EVO_ClanNPC_NameTag")
        local tw, th = surface.GetTextSize(name)
        draw.RoundedBox(8, -tw * 0.5 - 16, -th * 0.5 - 6, tw + 32, th + 12, COL_BG)
        draw.SimpleText(name, "EVO_ClanNPC_NameTag", 0, 0,
            COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if sub ~= "" then
            draw.SimpleText(sub, "EVO_ClanNPC_Sub", 0, th * 0.5 + 22,
                COL_SUB, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    cam.End3D2D()
    cam.IgnoreZ(false)
end
