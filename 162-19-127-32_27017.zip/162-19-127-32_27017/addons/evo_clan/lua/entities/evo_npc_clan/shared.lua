-- "addons\\evo_clan\\lua\\entities\\evo_npc_clan\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- PNJ « Doyen des Clans » (anim simple, pas de NextBot/AI). Spawn via le code
-- serveur de l'addon evo_clan (CFG.NPCSpawnPositions, par map). Interaction E
-- (via +use natif OU evo_npc_core à distance) -> ouvre le menu de clan.
-- Les clans étant FIXES, le Doyen ne CRÉE rien : c'est un point d'accès physique
-- au menu (comme le bind « Mon Clan » / !clan). Même base que ncm_npc_soin.

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Doyen des Clans"
ENT.Author    = "evo_clan"
ENT.Spawnable = false -- pas dans le Q menu, spawn auto via config
ENT.AdminOnly = true

function ENT:SetupDataTables()
    -- Flag NW pour identifier l'entity rapidement sans lire la classe.
    self:NetworkVar("Bool", 0, "IsClanNPC")
end
