-- "addons\\evo_clan\\lua\\entities\\evo_coffre_clan\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Coffre de clan"
ENT.Author    = "EVO"
ENT.Spawnable = false
