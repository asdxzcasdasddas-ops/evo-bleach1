-- "addons\\lzy_faction\\lua\\lzy_faction\\cl_report_images.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY FACTION — IMAGES DE RAPPORT, client. Deux façons de joindre une preuve :
--   • CAPTURE : render.Capture (PostRender) = ce que le joueur voit à l'instant T.
--     Le vrai « glisser-déposer » depuis Windows n'existe pas dans GMod (drag&drop
--     VGUI interne uniquement, dialogues fichiers CEF désactivés) -> la capture
--     est la voie sans friction, et la plus probante (flag capture, HUD compris).
--   • DOSSIER : le joueur pose son image dans garrysmod/data/evo_preuves/ et la
--     choisit in-game (file.Find ne lit que les chemins du jeu, pas le Bureau).
-- Upload en chunks (plafond net ~64 Ko/message) ; lecture avec cache disque :
-- une image déjà reçue n'est jamais re-téléchargée (nom unique par upload).
-- ============================================================================

if not CLIENT then return end

LZYF_ReportImage = LZYF_ReportImage or {}

local MAX_SIZE  = 512 * 1024
local MAX_CHUNK = 45000

local DIR_USER  = "evo_preuves"          -- images déposées par le joueur (Explorateur)
local DIR_CACHE = "lzy_faction/cache"    -- images de rapport reçues du serveur
local DIR_TMP   = "lzy_faction/tmp"      -- previews de capture (nom unique anti-cache Material)
file.CreateDir(DIR_USER)
file.CreateDir(DIR_CACHE)
file.CreateDir(DIR_TMP)

local function imageExt(sData)
	if sData:sub(1, 2) == "\xFF\xD8" then return "jpg" end
	if sData:sub(1, 4) == "\x89PNG" then return "png" end
	return nil
end

-- ── RÉTENTION locale (1x par session, au chargement) : le cache des images de
-- rapport suit la même règle que le serveur (30 j, horodatage dans le nom) — au-delà,
-- le serveur a purgé l'original de toute façon. Les previews tmp ne servent que
-- pendant la session : on repart de zéro.
do
	local now = os.time()
	for _, f in ipairs(file.Find(DIR_CACHE .. "/*", "DATA") or {}) do
		local sStamp = f:match("^img_%d+_(%d+)%.")
		if sStamp and now - (tonumber(sStamp) or 0) > 30 * 86400 then
			file.Delete(DIR_CACHE .. "/" .. f)
		end
	end
	for _, f in ipairs(file.Find(DIR_TMP .. "/*", "DATA") or {}) do
		file.Delete(DIR_TMP .. "/" .. f)
	end
end

-- ── CAPTURE D'ÉCRAN ─────────────────────────────────────────────────────────
-- Masque les panneaux passés (le menu faction) le temps d'UNE frame, capture en
-- JPEG, puis les ré-affiche. Material() met en cache par chemin -> compteur dans
-- le nom du preview pour que chaque nouvelle capture s'affiche vraiment.
local nPreviewGen = 0

function LZYF_ReportImage.Capture(tHide, fDone)
	local tWasVisible = {}
	for _, p in ipairs(tHide or {}) do
		if IsValid(p) then tWasVisible[p] = p:IsVisible() p:SetVisible(false) end
	end
	hook.Add("PostRender", "LZYF::ImgCapture", function()
		hook.Remove("PostRender", "LZYF::ImgCapture")
		-- Qualité DESCENDANTE jusqu'à passer sous le plafond : à q82 un JPEG 1080p fait
		-- ~200-400 Ko mais un 1440p/4K dépasse facilement 512 Ko -> sans cette échelle,
		-- la capture échouait systématiquement sur les grands écrans.
		local sData
		for _, nQ in ipairs({ 82, 60, 45, 30 }) do
			sData = render.Capture({ format = "jpeg", x = 0, y = 0, w = ScrW(), h = ScrH(), quality = nQ })
			if not sData or #sData == 0 or #sData <= MAX_SIZE then break end
		end
		for p, bVis in pairs(tWasVisible) do
			if IsValid(p) then p:SetVisible(bVis) end
		end
		if not sData or #sData == 0 then fDone(nil, "Capture impossible (menu Échap ouvert ?)") return end
		if #sData > MAX_SIZE then fDone(nil, "Capture trop lourde.") return end
		nPreviewGen = nPreviewGen + 1
		local sPath = DIR_TMP .. "/preview_" .. nPreviewGen .. ".jpg"
		file.Write(sPath, sData)
		fDone(sData, nil, Material("data/" .. sPath, "smooth"))
	end)
end

-- ── IMAGES DU DOSSIER data/evo_preuves ──────────────────────────────────────
function LZYF_ReportImage.ListFolder()
	local out = {}
	for _, sPat in ipairs({ "*.jpg", "*.jpeg", "*.png" }) do
		for _, sName in ipairs(file.Find(DIR_USER .. "/" .. sPat, "DATA") or {}) do
			out[#out + 1] = { name = sName, size = file.Size(DIR_USER .. "/" .. sName, "DATA") or 0 }
		end
	end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

function LZYF_ReportImage.FolderDir() return DIR_USER end

--- Lit une image du dossier : data + Material de preview, ou nil + raison.
function LZYF_ReportImage.ReadFolderImage(sName, fDone)
	if not isstring(sName) or sName:find("[/\\]") then fDone(nil, "Nom invalide.") return end
	local sData = file.Read(DIR_USER .. "/" .. sName, "DATA")
	if not sData or #sData == 0 then fDone(nil, "Fichier illisible.") return end
	if #sData > MAX_SIZE then fDone(nil, "Image trop lourde (max " .. math.floor(MAX_SIZE / 1024) .. " Ko).") return end
	if not imageExt(sData) then fDone(nil, "Format non reconnu (JPEG ou PNG).") return end
	fDone(sData, nil, Material("data/" .. DIR_USER .. "/" .. sName, "smooth"))
end

-- ── UPLOAD (chunks espacés : le canal fiable n'aime pas 400 Ko d'un bloc) ──
local fUploadDone

function LZYF_ReportImage.Upload(sData, fDone)
	if fUploadDone then fDone(false, "Un envoi est déjà en cours.") return end
	if not isstring(sData) or #sData < 1024 or #sData > MAX_SIZE then fDone(false, "Image invalide.") return end
	fUploadDone = fDone

	local nChunks = math.ceil(#sData / MAX_CHUNK)
	net.Start("server:lzy_faction.ImgUpBegin")
		net.WriteUInt(#sData, 32)
		net.WriteUInt(nChunks, 8)
	net.SendToServer()

	for i = 1, nChunks do
		local sPart = sData:sub((i - 1) * MAX_CHUNK + 1, i * MAX_CHUNK)
		timer.Simple(i * 0.1, function()
			net.Start("server:lzy_faction.ImgUpChunk")
				net.WriteUInt(i, 8)
				net.WriteUInt(#sPart, 16)
				net.WriteData(sPart, #sPart)
			net.SendToServer()
		end)
	end
	timer.Simple(nChunks * 0.1 + 0.2, function()
		net.Start("server:lzy_faction.ImgUpEnd")
		net.SendToServer()
	end)
	-- Filet : si le serveur ne répond jamais (déco, purge), on libère le slot.
	timer.Create("LZYF::ImgUpTimeout", nChunks * 0.1 + 10, 1, function()
		if fUploadDone then local f = fUploadDone fUploadDone = nil f(false, "Pas de réponse du serveur.") end
	end)
end

net.Receive("client:lzy_faction.ImgUpDone", function()
	local bOk  = net.ReadBool()
	local sMsg = net.ReadString()
	timer.Remove("LZYF::ImgUpTimeout")
	if fUploadDone then local f = fUploadDone fUploadDone = nil f(bOk, sMsg) end
end)

-- ── LECTURE d'une image de rapport (lecteurs gradés) ────────────────────────
-- Cache disque par nom (unique par upload) -> une seule descente par image.
local tDownloads = {} -- [sFile] = { size, n, parts, got, cbs }
local downFinish -- forward : le timer de timeout du Request y réfère avant sa définition

--- fReady(mat|nil) — mat prêt à dessiner, nil si échec.
function LZYF_ReportImage.Request(nReportId, sFile, fReady)
	if not isstring(sFile) or sFile == "" then fReady(nil) return end
	local sCached = DIR_CACHE .. "/" .. sFile
	if file.Exists(sCached, "DATA") then
		fReady(Material("data/" .. sCached, "smooth"))
		return
	end
	local dl = tDownloads[sFile]
	if dl then dl.cbs[#dl.cbs + 1] = fReady return end -- déjà en cours : on s'abonne
	tDownloads[sFile] = { parts = {}, got = 0, cbs = { fReady } }
	net.Start("server:lzy_faction.ImgDownReq")
		net.WriteUInt(nReportId or 0, 32)
	net.SendToServer()
	-- Sans timeout, un refus serveur (gate) ou un fichier disparu du disque laissait
	-- « Chargement… » à l'écran POUR TOUJOURS, et l'entrée fuyait : toute demande
	-- suivante de la même image s'abonnait à un téléchargement mort.
	timer.Create("LZYF::ImgDown::" .. sFile, 15, 1, function()
		local d = tDownloads[sFile]
		if d then downFinish(sFile, nil) end
	end)
end

downFinish = function(sFile, mat)
	timer.Remove("LZYF::ImgDown::" .. sFile)
	local dl = tDownloads[sFile]
	tDownloads[sFile] = nil
	if not dl then return end
	for _, cb in ipairs(dl.cbs) do cb(mat) end
end

net.Receive("client:lzy_faction.ImgDownBegin", function()
	local sFile   = net.ReadString()
	local nSize   = net.ReadUInt(32)
	local nChunks = net.ReadUInt(8)
	local dl = tDownloads[sFile]
	if not dl then return end
	dl.size, dl.n = nSize, nChunks
end)

net.Receive("client:lzy_faction.ImgDownChunk", function()
	local sFile = net.ReadString()
	local nIdx  = net.ReadUInt(8)
	local nLen  = net.ReadUInt(16)
	local sPart = net.ReadData(nLen)
	local dl = tDownloads[sFile]
	if not dl or not dl.n or dl.parts[nIdx] then return end
	dl.parts[nIdx] = sPart
	dl.got = dl.got + 1
	if dl.got < dl.n then return end

	local sData = table.concat(dl.parts)
	-- Nom re-validé avant d'écrire (il vient du serveur, mais zéro traversal par principe).
	if #sData ~= dl.size or not sFile:match("^img_%d+_%d+%.%a+$") then downFinish(sFile, nil) return end
	local sCached = DIR_CACHE .. "/" .. sFile
	file.Write(sCached, sData)
	downFinish(sFile, Material("data/" .. sCached, "smooth"))
end)
