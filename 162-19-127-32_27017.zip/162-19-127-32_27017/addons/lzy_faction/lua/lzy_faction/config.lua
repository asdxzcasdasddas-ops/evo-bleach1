-- "addons\\lzy_faction\\lua\\lzy_faction\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_FACTION_CONFIG = LZY_FACTION_CONFIG or {}
LZY_FACTION_CONFIG.suspension_duration = 7 -- in days

-- Règlement RP affiché dans le livre (bouquin gestion faction) : PLUSIEURS règles par page.
-- Titre collé à sa description (simple \n) ; ligne vide (\n\n) pour séparer 2 règles.
-- 3 pages (4 / 3 / 3) : le texte finit AU-DESSUS de la pagination, plus de débordement en bas.
LZY_FACTION_CONFIG.rules = {
	-- Page 1 : règles 1 à 4
	"1. Restez dans votre personnage\n" ..
	"Votre comportement doit être cohérent avec votre personnage et l'univers de Bleach. Les comportements totalement hors contexte sont interdits.\n\n" ..
	"2. FearRP\n" ..
	"Votre personnage doit craindre le danger. Face à une menace crédible ou un adversaire largement supérieur, vous devez réagir de manière cohérente.\n\n" ..
	"3. PainRP\n" ..
	"Votre personnage doit prendre en compte ses blessures, sa fatigue et les conséquences d'un combat. Vous ne pouvez pas agir normalement après avoir subi de lourds dégâts.\n\n" ..
	"4. PowerGaming interdit\n" ..
	"Vous ne pouvez pas imposer une action ou son résultat à un autre joueur. Laissez toujours à l'autre personne la possibilité de réagir.",

	-- Page 2 : règles 5 à 7
	"5. Metagaming interdit\n" ..
	"Toute information obtenue hors RP ne doit pas être utilisée en RP : Discord, stream, chat HRP, spectateur ou discussion extérieure.\n\n" ..
	"6. Freekill / RDM interdit\n" ..
	"Il est interdit d'attaquer ou de tuer un joueur sans raison RP valable. Un conflit doit avoir un contexte cohérent.\n\n" ..
	"7. New Life Rule\n" ..
	"Après votre mort, vous oubliez les circonstances immédiates de celle-ci. Vous ne pouvez pas revenir directement sur la zone pour vous venger ou reprendre le combat.",

	-- Page 3 : règles 8 à 10
	"8. Combat RP et fair-play\n" ..
	"Ne fuyez pas sans raison en plein combat, ne forcez pas une scène et n'abusez pas de vos pouvoirs ou mécaniques pour obtenir un avantage injuste.\n\n" ..
	"9. Déconnexion en scène interdite\n" ..
	"Se déconnecter pour éviter une mort, une sanction, une conséquence RP ou un combat est interdit.\n\n" ..
	"10. Actions graves encadrées\n" ..
	"Les exécutions, kidnappings, pertes importantes de pouvoir ou morts définitives doivent avoir un contexte solide et peuvent nécessiter l'accord du staff.",
}
LZY_FACTION_CONFIG.missions = {
	"Capture de drapeau",
	"Guerre / Affrontement",
	"Event",
	"World boss / Boss",
	"Entrainement",
	"Patrouille",
	"Interrogatoire",
	"Autre",
}
LZY_FACTION_CONFIG.factions = {
	-- ⚠️ L'INDEX EST LA SEULE CHOSE QUI COMPTE, jamais le libellé : tout le jeu compare
	-- des NOMBRES (uniformes de capitaine à 15, brassard de vice-capitaine à 14, corps
	-- et masque d'Espada à 15+, PromoteMinRank 10, DivisionMinRank 10, NonSAMaxGrade 12).
	-- Renommer une ligne est donc sans risque ; DÉPLACER un rôle d'un index à un autre
	-- change en revanche tout ce qui précède. Table refaite le 2026-07-26 (libellés user).
	["Shinigami"] = {
		[1]  = "Aspirant shinigami",
		[2]  = "Shinigami de troisième classe",
		[3]  = "Shinigami de seconde classe",
		[4]  = "Shinigami de première classe",
		[5]  = "Kashikan de seconde classe",
		[6]  = "Kashikan de première classe",
		[7]  = "Junshikan de troisième classe",
		[8]  = "Junshikan de seconde classe",
		[9]  = "Junshikan de première classe",
		[10] = "6ème siège",
		[11] = "5ème siège",
		[12] = "4ème siège",
		[13] = "3ème siège",
		[14] = "Fukutaicho",   -- vice-capitaine : porte le brassard de division
		[15] = "Taicho",       -- capitaine : uniforme de division + assignation des divisions
		[16] = "Sotaicho",
	},
	-- Les libellés Hollow sont en ESPAGNOL (clase, primera, segunda...) comme dans l'œuvre,
	-- là où le côté Shinigami est en français/japonais. Ce n'est pas une faute de frappe.
	["Hollow"] = {
		[1]  = "Arrancar Aspirante",
		[2]  = "Arrancar de tercera clase",
		[3]  = "Arrancar de segunda clase",
		[4]  = "Arrancar de primera clase",
		[5]  = "Menor de segunda clase",
		[6]  = "Menor de primera clase",
		[7]  = "Fracción novicia",
		[8]  = "Fracción subalterna",
		[9]  = "Fracción avanzada",
		[10] = "Fracción principal",
		[11] = "Fracción Superior",
		[12] = "Fracción Suprema",
		[13] = "Grand Fracción",
		[14] = "Privaron Espada",
		[15] = "Espadas",      -- équivalent Taicho : assignation des divisions + corps/masque d'Espada
		[16] = "Roi du Hueco Mundo",
	},
	-- Pseudo-faction ONBOARDING (evo_lost_soul) : un nouveau joueur incarne une « Âme errante »
	-- pendant le tutoriel, AVANT de choisir Shinigami/Hollow. Un seul grade (départ). Déclarée ici
	-- pour débloquer d'un coup AddToFaction + le gate GetFaction du spawn + le check de création.
	-- TEMPORAIRE par perso : le perso est converti/supprimé au choix de faction (fin du tuto).
	["LostSoul"] = {
		[1] = "Âme errante",
	},
}
LZY_FACTION_CONFIG.divisions = {
	["Shinigami"] = {
		[1] = "Aucune",
		[2] = "Division 1",
		[3] = "Division 2",
		[4] = "Division 12",
		[5] = "Division 4",
		[6] = "Division 11",
	},
	-- ARRANCAR : chez les Hollow on parle d'ORDRE (Ordre 1..5), pas de « Division »
	-- (demande user 2026-07-14). MÊMES INDEX que Shinigami (le médical reste
	-- l'index 5) — seul le NOM change. ⚠️ Ces noms servent de CLÉS ailleurs :
	-- uniformes lzy_character RANK_OUTFITS["Hollow"], lit de soin ncm_heal_bed,
	-- POI carte evo_map (hueco) -> tenus synchronisés.
	["Hollow"] = {
		[1] = "Aucune",
		[2] = "Ordre 1",
		[3] = "Ordre 2",
		[4] = "Ordre 3",
		[5] = "Ordre 4",
		[6] = "Ordre 5",
	},
	-- Âme errante (onboarding) : aucune division réelle.
	["LostSoul"] = {
		[1] = "Aucune",
	}
}

-- SPÉCIALITÉ (rôle) de chaque subdivision — PARTAGÉE Shinigami/Hollow (mêmes index,
-- seul le NOM change, cf. table ci-dessus). SOURCE UNIQUE (10/08) : consommée par les
-- balises de division ET le menu « Former ce joueur » (lzy_onboarding). Les
-- commentaires d'evo_division_spawn décrivent le même mapping ; le menu SAM garde ses
-- propres libellés (« État-major »...) — assumé, c'est sa terminologie d'UI.
LZY_FACTION_CONFIG.DivisionSpecialty = {
	[2] = "Commandement",
	[3] = "Assassin",
	[4] = "Scientifique",
	[5] = "Médecin",
	[6] = "Combat",
}

-- ── Seuils de la GESTION de faction (bouquin) — demande user 07/26 ────────────────────
-- PromoteMinRank : à partir de ce grade on peut PROMOUVOIR (up) les membres de SA division
--   (cible de grade strictement inférieur, plafond NonSAMaxGrade, prérequis exigés) et on
--   voit l'onglet gestion (liste de sa division).
-- DivisionMinRank : à partir de ce grade on peut ASSIGNER les divisions, sur
--   TOUTE la faction (liste complète reçue dès ce grade). Le chef (grade max) garde en plus
--   ses exclusivités (sanctions, promotion toutes divisions).
-- Partagé client (visibilité UI) + serveur (gates net) -> jamais de désync.
LZY_FACTION_CONFIG.PromoteMinRank  = 10 -- 11 -> 10 (demande user 08/01 : les limites 11+ passent a 10+)
LZY_FACTION_CONFIG.DivisionMinRank = 10 -- 15 -> 10 (demande user 08/03) ; hors chef, on n'assigne que SA division (garde SetDivision)
-- FORMATEUR (10/08) = coche posée par un grade >= PromoteMinRank dans la gestion
-- (colonne lzy_faction_members.formateur, NW EVO_FactionFormateur). Ouvre la vue
-- formation du livre : recruter un aspirant dans SA division, au grade ci-dessous.
LZY_FACTION_CONFIG.FormateurGrantRank = 2
-- ENSEIGNEMENT DES TECHNIQUES (09/03, demande user) : un FORMATEUR de grade
-- >= EnseignementMinRank peut TRANSMETTRE les techniques — parchemins du Maitre
-- des Techniques (Hado / Bakudo / Ars Hollow) ET parchemin de division — mais
-- UNIQUEMENT celles qu'il connait deja lui-meme. Les hauts grades gardent leur
-- droit habituel (ProfessorGrade / DivisionScrollMinRank), sans cette restriction :
-- eux distribuent depuis un stock, un formateur ENSEIGNE ce qu'il maitrise.
-- SHARED : la visibilite des menus et les gates serveur lisent la MEME regle.
LZY_FACTION_CONFIG.EnseignementMinRank = 5

--- Ce joueur enseigne-t-il par la voie FORMATEUR ? (coche formateur + grade mini)
function LZY_FACTION_CONFIG.EstFormateurEnseignant(ply)
    if not IsValid(ply) then return false end
    if not ply:GetEvoNWBool("EVO_FactionFormateur", false) then return false end
    local nRank = tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0
    return nRank >= (LZY_FACTION_CONFIG.EnseignementMinRank or 5)
end
-- ReportReviewMinRank : à partir de ce grade on relit les RAPPORTS de SA division
-- (liste en attente, lecture complète, valider/refuser, archives). Avant : grade max-1 (15+).
LZY_FACTION_CONFIG.ReportReviewMinRank = 10 -- demande user 08/02
-- AnnonceMinRank : à partir de ce grade on émet l'ANNONCE FACTION (bannière
-- lzy_annonce_faction du bouquin de gestion). Avant : grade max-2 (14+).
LZY_FACTION_CONFIG.AnnonceMinRank = 10 -- demande user 08/03
-- DivAnnonceMinRank : à partir de ce grade on émet l'ANNONCE DE DIVISION (composer du
-- bouquin de gestion, diffusée à SA division). Avant : grade max-2 (14+).
LZY_FACTION_CONFIG.DivAnnonceMinRank = 10 -- demande user 08/05

-- ── JOURS DE PROMOTION (demande user 08/05) ──────────────────────────────────────────
-- Monter un grade n'est autorisé que ces jours-là (os.date wday : 1=dimanche, 4=mercredi,
-- 7=samedi), SAUF le passage AU GRADE 2 (toujours libre) et les rétrogradations.
-- Superadmin exempté (il sort avant tous les gates de SetRank). Table vide/nil = pas de
-- verrou. Partagé client (le menu ne propose pas la montée) + serveur (gate SetRank).
LZY_FACTION_CONFIG.PromoteDays = { [4] = true, [7] = true } -- mercredi + samedi

-- Le grade cible `nTargetGrade` est-il promouvable AUJOURD'HUI ? (grade <= 2 : toujours)
function LZY_FACTION_CONFIG.IsPromoteDayAllowed(nTargetGrade)
	local t = LZY_FACTION_CONFIG.PromoteDays
	if not t or not next(t) then return true end
	if (tonumber(nTargetGrade) or 0) <= 2 then return true end
	return t[os.date("*t").wday] == true
end

-- ── Validité grade / division (réutilisé par SetRank, SetDivision, set_faction) ──
-- Le grade/division DOIT exister dans la table de la faction (sinon valeur fantôme via net
-- forgé ou commande). Les listes déroulantes ne proposent déjà que ces valeurs ; ces helpers
-- font la même garantie CÔTÉ SERVEUR (l'autorité).
function LZY_FACTION_CONFIG.IsValidGrade(faction, rank)
	local t = LZY_FACTION_CONFIG.factions[faction]
	rank = tonumber(rank)
	return (t ~= nil and rank ~= nil and t[rank] ~= nil)
end
function LZY_FACTION_CONFIG.IsValidDivision(faction, division)
	local t = LZY_FACTION_CONFIG.divisions[faction]
	division = tonumber(division)
	return (t ~= nil and division ~= nil and t[division] ~= nil)
end

-- ── Résolution NOM depuis l'INDEX (source de vérité unique pour TOUT l'affichage) ──
-- L'index stocké (NWInt FactionDivision / FactionRank, colonnes DB) est une CLÉ 1..N ;
-- le NOM dépend de la faction : "Division X" (Shinigami) / "Ordre X" (Hollow). NE JAMAIS
-- afficher l'index brut ni "index-1" : passer par ces helpers pour rester cohérent partout.
-- `facteur` accepte un Player OU un nom de faction ("Shinigami"/"Hollow"/...).
function LZY_FACTION_CONFIG.DivisionName(facOrPly, index)
	local faction = facOrPly
	if isentity(facOrPly) then
		faction = IsValid(facOrPly) and facOrPly:GetEvoNWString("FactionName", "") or ""
	end
	index = tonumber(index)
	local t = LZY_FACTION_CONFIG.divisions[faction]
	if t and index and t[index] then return t[index] end
	if not index or index <= 1 then return "Aucune" end
	return "Division " .. index -- filet (faction inconnue) : rare
end

function LZY_FACTION_CONFIG.RankName(facOrPly, rank)
	local faction = facOrPly
	if isentity(facOrPly) then
		faction = IsValid(facOrPly) and facOrPly:GetEvoNWString("FactionName", "") or ""
	end
	rank = tonumber(rank)
	local t = LZY_FACTION_CONFIG.factions[faction]
	return (t and rank and t[rank]) or "—"
end

-- Le MOT générique de la subdivision d'une faction, pour les phrases génériques
-- ("ta division" / "banque de division"...). Déduit de la table (Shinigami "Division",
-- Hollow "Ordre") en enlevant le numéro. `lower` = true pour la version minuscule.
function LZY_FACTION_CONFIG.DivisionWord(facOrPly, lower)
	local faction = facOrPly
	if isentity(facOrPly) then
		faction = IsValid(facOrPly) and facOrPly:GetEvoNWString("FactionName", "") or ""
	end
	local t = LZY_FACTION_CONFIG.divisions[faction]
	local sample = t and (t[2] or t[5]) -- une entrée nommée ("Division 1" / "Ordre 1")
	local w = sample and string.Trim((string.gsub(sample, "%d+", ""))) or "Division"
	if w == "" then w = "Division" end
	return lower and string.lower(w) or w
end

-- Genre grammatical du mot de subdivision (Division = féminin, Ordre = masculin).
local DIV_GENDER = { Division = "f", Ordre = "m" }

-- Forme possessive 2e pers. : "ta division" (Shinigami) / "ton ordre" (Hollow).
function LZY_FACTION_CONFIG.DivisionPoss(facOrPly)
	local wUp = LZY_FACTION_CONFIG.DivisionWord(facOrPly)
	return ((DIV_GENDER[wUp] == "m") and "ton " or "ta ") .. string.lower(wUp)
end

-- Article défini avec élision : "la division" (Shinigami) / "l'ordre" (Hollow).
function LZY_FACTION_CONFIG.DivisionDef(facOrPly)
	local wUp = LZY_FACTION_CONFIG.DivisionWord(facOrPly)
	local w   = string.lower(wUp)
	if string.find("AEIOUÉÈÊÀH", string.upper(string.sub(wUp, 1, 1)), 1, true) then
		return "l'" .. w
	end
	return ((DIV_GENDER[wUp] == "m") and "le " or "la ") .. w
end
-- Grade max sur l'ensemble des factions (borne universelle de garde).
function LZY_FACTION_CONFIG.MaxGrade()
	local m = 0
	for _, t in pairs(LZY_FACTION_CONFIG.factions) do if #t > m then m = #t end end
	return m
end

-- ════════════════════════════════════════════════════════════════════════════════════
-- PRÉREQUIS DE MONTÉE EN GRADE
-- Pour PROMOUVOIR un perso au grade G, il doit remplir TOUS les critères ci-dessous. Sinon
-- le serveur REFUSE la promotion (et dit ce qui manque). Les SUPER ADMINS ignorent ces
-- prérequis (ils peuvent mettre n'importe quel grade à n'importe qui). La rétrogradation
-- (descendre un grade) n'est jamais bloquée par les prérequis.
--   • hours    = heures de jeu du perso        (characters.playtime_seconds / 3600)
--   • level    = niveau du perso               (characters.level)
--   • reports  = rapports VALIDÉS encore actifs (lzy_faction_reports status='validated', inactive=0)
--   • captures = captures de drapeau du perso   (characters.flag_captures, incrémenté par flagcapture)
-- Le grade 1 est le grade de départ -> aucun prérequis. Édite la rampe ci-dessous pour ajuster.
-- ════════════════════════════════════════════════════════════════════════════════════
LZY_FACTION_CONFIG.GradeRequirements = LZY_FACTION_CONFIG.GradeRequirements or {}

-- ÉLECTION (09/20, user) : un grade ElectMinRank+ nomme dans SA division UNE personne de son
-- choix au grade ElectGrade, sans prérequis ni jour de promotion ; au plus UN ElectGrade par
-- division ; révocable (retour au grade d'avant). Seule exception au plafond NonSAMaxGrade.
LZY_FACTION_CONFIG.ElectGrade   = 14
LZY_FACTION_CONFIG.ElectMinRank = 15

-- RÉTROGRADATION (09/26, user ; 14 inclus le 09/27) : Fukutaicho / Privaron et plus descendent
-- le grade des membres de SA division strictement sous le leur ; le chef, toute la faction.
LZY_FACTION_CONFIG.DemoteMinRank = 14

-- Grade MAX qu'un NON-super-admin peut attribuer (demande user). Au-delà (13-16), seul un
-- SUPER-ADMIN peut promouvoir. Appliqué côté client (dropdown + carnet) ET serveur (SetRank).
LZY_FACTION_CONFIG.NonSAMaxGrade = 12

do
	-- Rampe PAR DÉFAUT (mêmes valeurs pour les 2 factions ; édite ce tableau pour ajuster).
	--        grade =  {heures, niveau, rapports, captures}
	-- Grades 13-16 : PAS de prérequis ici car réservés au SUPER-ADMIN (cf. NonSAMaxGrade) ->
	-- un non-SA ne peut jamais y promouvoir, et un SA ignore les prérequis. Donc rampe 2->12.
	local ramp = {
		[2]  = { 0,   0,   0,   0 },  -- AUCUN prérequis (demande user 07/26 : grade 2 attribuable direct)
		-- Captures ADOUCIES (demande user 07/25) : +1 par grade depuis le grade 3 (5 -> 14 au 12)
		-- au lieu de 11 -> 20.
		-- Heures + niveaux : −30 % arrondis (demande user 08/13 : trop long à monter).
		[3]  = { 15,  12,  5,   5 },
		[4]  = { 25,  18,  12,  6 },
		[5]  = { 40,  25,  13,  7 },
		[6]  = { 50,  35,  14,  8 },
		[7]  = { 65,  45,  15,  9 },
		[8]  = { 85,  55,  16,  10 },
		[9]  = { 110, 65,  17,  11 },
		[10] = { 140, 75,  18,  12 },
		[11] = { 165, 80,  19,  13 },
		[12] = { 190, 90,  20,  14 },
	}
	local function buildFromRamp()
		local out = {}
		for g = 2, 16 do
			local r = ramp[g] or { 0, 0, 0, 0 }
			out[g] = { hours = r[1], level = r[2], reports = r[3], captures = r[4] }
		end
		return out
	end
	-- Par faction (dupliqué pour pouvoir différencier Shinigami / Hollow plus tard si besoin).
	-- Toujours reconstruire : sinon un lua_refresh garde l'ancienne rampe (le `or` court-circuite).
	LZY_FACTION_CONFIG.GradeRequirements["Shinigami"] = buildFromRamp()
	LZY_FACTION_CONFIG.GradeRequirements["Hollow"]    = buildFromRamp()
end

-- ── CRITÈRE PAR DIVISION (demande user 08/02) ────────────────────────────────────────
-- Le 4e prérequis dépend de la DIVISION du perso ; le NOMBRE requis reste la colonne
-- `captures` de la rampe (une seule rampe, seul le TYPE d'activité change) :
--   combat / assassin / commandement / sans division -> captures de drapeau (characters.flag_captures)
--   médical       -> opérations réussies au lit de soin (characters.heal_operations)
--   scientifique  -> AUCUN 4e critère (demande user 08/06 — plus de carcasses analysées)
--   commandement  -> recensements d'ennemis             (characters.enemy_census)
-- Clés = NOMS de division (mêmes clés stables que ncm_heal_bed / sorts de division).
-- false = pas de 4e critère d'activité (heures / niveau / rapports seuls restent).
LZY_FACTION_CONFIG.DivisionCriterion = {
	["Division 4"]  = "operations",   ["Ordre 4"] = "operations",
	["Division 12"] = false,          ["Ordre 3"] = false,
	["Division 1"]  = false,          ["Ordre 1"] = false,
	-- Division 2/11 et Ordre 2/5 (assassin/combat) + "Aucune" -> défaut "captures"
}
LZY_FACTION_CONFIG.CriterionLabels = {
	captures = "Captures", operations = "Opérations réussies",
	carcasses = "Carcasses analysées",
}
-- Clé de critère applicable pour (faction, index de division).
-- Défaut : "captures". false / nil explicite via DivisionCriterion -> aucun 4e critère.
function LZY_FACTION_CONFIG.GetDivisionCriterion(faction, division)
	local divs = LZY_FACTION_CONFIG.divisions and LZY_FACTION_CONFIG.divisions[faction]
	local sName = divs and divs[tonumber(division) or 0]
	if not sName then return "captures" end
	local crit = LZY_FACTION_CONFIG.DivisionCriterion[sName]
	if crit == false then return nil end -- division sans 4e critère (ex. scientifique)
	return crit or "captures"
end

-- Renvoie la table de prérequis {hours, level, reports, captures} pour atteindre `grade` dans
-- `faction`, ou nil si aucun prérequis (grade 1 / hors plage / faction inconnue).
function LZY_FACTION_CONFIG.GetGradeRequirement(faction, grade)
	grade = tonumber(grade)
	local fac = faction and LZY_FACTION_CONFIG.GradeRequirements[faction]
	if not (fac and grade) then return nil end
	return fac[grade]
end

-- Vérifie si `stats` remplit les prérequis du `grade` dans `faction`. PARTAGÉ serveur + client
-- (le serveur gate, le client affiche la progression à l'identique).
--   stats = { hours = <heures>, level = <niveau>, reports = <rapports validés>, captures = <captures> }
-- Retourne : bMet (bool), tDetails (liste de { key, label, have, need, ok }).
function LZY_FACTION_CONFIG.CheckGradeRequirements(faction, grade, stats)
	stats = stats or {}
	local req = LZY_FACTION_CONFIG.GetGradeRequirement(faction, grade)
	if not req then return true, {} end -- pas de prérequis (grade 1 / départ)
	-- 4e critère selon la DIVISION du perso (stats.division, cf. DivisionCriterion) ;
	-- le nombre requis reste req.captures (la rampe ne change pas). nil = pas de 4e critère.
	local sCrit = LZY_FACTION_CONFIG.GetDivisionCriterion(faction, stats.division)
	local fields = {
		{ key = "hours",   label = "Heures de jeu", have = tonumber(stats.hours)   or 0, need = tonumber(req.hours)   or 0 },
		{ key = "level",   label = "Niveau",        have = tonumber(stats.level)   or 0, need = tonumber(req.level)   or 0 },
		{ key = "reports", label = "Rapports",      have = tonumber(stats.reports) or 0, need = tonumber(req.reports) or 0 },
	}
	if sCrit then
		fields[#fields + 1] = {
			key = sCrit, label = LZY_FACTION_CONFIG.CriterionLabels[sCrit] or sCrit,
			have = tonumber(stats[sCrit]) or 0, need = tonumber(req.captures) or 0,
		}
	end
	local bMet, details = true, {}
	for _, f in ipairs(fields) do
		local ok = f.have >= f.need
		if not ok then bMet = false end
		details[#details + 1] = { key = f.key, label = f.label, have = f.have, need = f.need, ok = ok }
	end
	return bMet, details
end
-- ── GESTION FORMATION : registre de suivi des aspirants (user 2026-08-20) ────
-- Fiche par aspirant FORMÉ (parcours lzy_onboarding terminé) : capacités au
-- combat, comportement, objectif, verdict, note.
-- LECTURE : toutes les divisions de sa faction. ÉCRITURE : uniquement les
-- fiches de SA division/ordre (demande user).
LZY_FACTION_CONFIG.SuiviMinRank     = 8   -- grade qui peut ouvrir/écrire une fiche
-- « Former ce joueur » (division + grade 2) peut EXIGER une fiche au verdict
-- « Validé ». DÉSACTIVÉ le 08/20 (demande user « ce n'est pas obligatoire, ça ne
-- bloque rien ») : essayé une journée, trop contraignant en pratique — le registre
-- redevient un outil de suivi FACULTATIF, le recrutement ne regarde plus la fiche.
-- Remettre true pour réactiver le verrou (le code du gate est resté en place).
LZY_FACTION_CONFIG.SuiviRequiredToRecruit = false
LZY_FACTION_CONFIG.SuiviMaxRows     = 300 -- fiches renvoyées par faction (payload compressé)
