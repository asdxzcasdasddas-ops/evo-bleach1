-- "addons\\lzy_faction\\lua\\lzy_faction\\vgui\\cl_selectbox.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

-- FIX resolution non-16:9 : alias uniforme (min des axes) pour tout le fichier, cf.
-- cl_main.lua. Garde la selectbox et son dropdown proportionnels (pas ecrases en 1:1).
local function gRespX(v) return gRespU(v) end
local function gRespY(v) return gRespU(v) end

-- Default materials (can be overridden)
local defaultMaterials = {
    background = Material("hnztk71178zj/puw4w7h7f9l26j97f.png"),
    dropdown_bg = Material("hnztk71178zj/puw4w7h7f9l26j97f.png"),
}

function PANEL:Init()
    self:SetText("")
    self:SetDrawBackground(false)
    self:SetDrawBorder(false)
    
    -- Initialize properties
    self.options = {}
    self.selectedIndex = 1
    self.isOpen = false
    self.materials = defaultMaterials
    self.textColor = Color(255, 255, 255)
    self.font = "Ubuntu Mono:15"
    
    -- Create dropdown panel
    self.dropdown = vgui.Create("DPanel", self:GetParent())
	self.dropdown.width = self:GetParent():GetWide()
    self.dropdown:SetSize(self.dropdown.width, 0)
    self.dropdown:SetVisible(false)
    self.dropdown.Paint = function(panel, w, h)
        -- Draw white border around the dropdown
        draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
    end
    
    -- Create panel for options (no scroll panel)
    self.optionsPanel = vgui.Create("DPanel", self.dropdown)
    self.optionsPanel:SetPos(0, 0)
    self.optionsPanel:SetSize(100, 0) -- Will be updated in UpdateDropdownHeight
    self.optionsPanel.Paint = function(selff, w, h) 
		--draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0))
	end
    
    -- Make panel clickable
    self.DoClick = function()
        self:ToggleDropdown()
    end
end

function PANEL:cSetSize(width, height)
    self:gSetSizeU(width, height)
    -- PerformLayout sera trigger par gSetSize -> syncera dropdown.width automatiquement
end

-- Hook : sync dropdown.width = actual width du selectbox a chaque resize.
-- Ca marche pour cSetSize (= gSetSize), SetSize, gSetSize, peu importe l'appelant.
-- Avant : Init stockait parent:GetWide() (souvent enorme) qui n'etait jamais
-- mis a jour -> dropdown + options + arrow positionnees a partir de cette
-- valeur stale, completement decalees du vrai selectbox.
function PANEL:PerformLayout(w, h)
    if self.dropdown then
        self.dropdown.width = w
        if not self.isOpen then
            self.dropdown:SetSize(w, 0)
        else
            -- Si le dropdown est ouvert, garder sa hauteur, juste resync la width
            local _, dropdownH = self.dropdown:GetSize()
            self.dropdown:SetSize(w, dropdownH)
            if self.UpdateDropdownHeight then self:UpdateDropdownHeight() end
        end
    end
end

function PANEL:SetMaterials(background, dropdown_bg)
    self.materials.background = background or self.materials.background
    self.materials.dropdown_bg = dropdown_bg or self.materials.dropdown_bg
end

function PANEL:SetTextColor(color)
    self.textColor = color
end

function PANEL:SetFont(font)
    self.font = font
end

function PANEL:ClearOptionButtons()
    if not IsValid(self.dropdown) then return end
    for _, child in ipairs(self.dropdown:GetChildren()) do
        if child ~= self.optionsPanel then child:Remove() end
    end
    self._optionBtnsBuilt = false
end

function PANEL:CreateOptionButton(optionIndex, text)
    local optionBtn = vgui.Create("DButton", self.dropdown)
    optionBtn:SetSize(self.dropdown.width, gRespY(22))
    optionBtn:SetText("")
    optionBtn:SetDrawBackground(false)
    optionBtn:SetDrawBorder(false)
    optionBtn:SetPos(0, (optionIndex - 1) * gRespY(24))

    optionBtn.Paint = function(btn, w, h)
        if self.materials.dropdown_bg then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(self.materials.dropdown_bg)
            surface.DrawTexturedRect(0, 0, w, h)
        end

        if btn:IsHovered() then
            surface.SetDrawColor(200, 200, 200, 100)
            surface.DrawRect(0, 0, w, h)
        end

        draw.SimpleText(text, self.font, gRespX(5), h/2, self.textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    optionBtn.OnMousePressed = function(btn, mouseCode)
        if mouseCode == MOUSE_LEFT then
            self:SelectOption(optionIndex)
            self:ToggleDropdown()
        end
    end
end

-- Boutons d'options créés au premier OPEN seulement : SetOptions sur une
-- longue liste (grades × N membres) ne doit pas allouer des DButton tout de suite.
function PANEL:EnsureOptionButtons()
    if self._optionBtnsBuilt then return end
    self._optionBtnsBuilt = true
    for i, opt in ipairs(self.options) do
        self:CreateOptionButton(i, opt.text)
    end
    self:UpdateDropdownHeight()
end

function PANEL:AddOption(text, value)
    table.insert(self.options, {
        text = text,
        value = value or text
    })
    if self._optionBtnsBuilt then
        self:CreateOptionButton(#self.options, text)
        self:UpdateDropdownHeight()
    end
end

function PANEL:SetOptions(options)
    self:ClearOptionButtons()
    self.options = {}
    if IsValid(self.optionsPanel) then self.optionsPanel:Clear() end

    -- Défensif : options peut être nil si le joueur n'a pas de faction
    -- -> LZY_FACTION_CONFIG.divisions/factions[""] = nil ; liste vide au lieu de crash.
    for _, option in ipairs(options or {}) do
        if type(option) == "table" then
            self.options[#self.options + 1] = { text = option.text, value = option.value or option.text }
        else
            self.options[#self.options + 1] = { text = option, value = option }
        end
    end

    self.selectedIndex = 1
end

function PANEL:OnRemove()
    if IsValid(self.dropdown) then
        self.dropdown:Remove()
    end
end

function PANEL:SelectOption(index)
    if index >= 1 and index <= #self.options then
        if self.OnValueChanged and index ~= self.selectedIndex then
            self:OnValueChanged(self.options[index].value, self.options[index].text, index)
        end
        self.selectedIndex = index
    end
end

function PANEL:GetSelectedValue()
    if self.options[self.selectedIndex] then
        return self.options[self.selectedIndex].value
    end
    return nil
end

function PANEL:GetSelectedText()
    if self.options[self.selectedIndex] then
        return self.options[self.selectedIndex].text
    end
    return ""
end

function PANEL:ToggleDropdown()
    self.isOpen = not self.isOpen
    
    if self.isOpen then
        -- Position dropdown below the selectbox
        local x, y = self:GetPos()
        self.dropdown:SetPos(x, y + self:GetTall())
		self.dropdown:SetZPos(9999)

        -- Boutons + hauteur au premier open (SetOptions ne les crée plus tout de suite).
        -- PerformLayout remet le dropdown à hauteur 0 tant qu'il est fermé ; on recalcule ici.
        self:EnsureOptionButtons()
        self:UpdateDropdownHeight()
        
        -- Close other dropdowns (optional)
        local parent = self:GetParent()
        if parent then
            for _, child in pairs(parent:GetChildren()) do
                if child != self and child.ToggleDropdown then
                    child.isOpen = false
                    if child.dropdown then
                        child.dropdown:SetVisible(false)
                    end
                end
            end
        end
    end
    
    self.dropdown:SetVisible(self.isOpen)
end

function PANEL:UpdateDropdownHeight()
    -- Toutes les hauteurs scaled pour matcher les options qui utilisent gRespY(24).
    local maxHeight    = gRespY(150)
    local optionHeight = gRespY(24)
    local totalHeight  = #self.options * optionHeight

    if totalHeight > maxHeight then
        totalHeight = maxHeight
    end

    -- Ensure minimum height for at least one option
    if totalHeight < optionHeight then
        totalHeight = optionHeight
    end

    -- Add extra height to ensure last option is fully clickable
    local lastOptionBottom = (#self.options - 1) * gRespY(24) + gRespY(22)
    totalHeight = math.max(totalHeight, lastOptionBottom + gRespY(4))

    -- Largeur auto : prend le max entre la width du selectbox et le texte le
    -- plus long (sinon les options "Apprenti", "9eme Siege" etaient coupees).
    surface.SetFont(self.font)
    local maxTextW = 0
    for _, opt in ipairs(self.options) do
        local tw = surface.GetTextSize(opt.text)
        if tw > maxTextW then maxTextW = tw end
    end
    local computedW = maxTextW + gRespX(20) -- padding gauche+droit
    local dropdownW = math.max(self.dropdown.width or 0, computedW)

    -- RESPONSIVE : borner la largeur au bord DROIT du panneau parent, sinon une option longue
    -- (ex. missions "Guerre / Affrontement") elargit le dropdown au-dela du menu -> ca depasse.
    -- Le panneau parent clippe ses enfants, donc le texte en trop est rogne au bord (pas hors menu).
    local parent = self:GetParent()
    if IsValid(parent) then
        local nMax = parent:GetWide() - self:GetX() - gRespX(4)
        if nMax > gRespX(40) and dropdownW > nMax then dropdownW = nMax end
    end

    self.dropdown:SetSize(dropdownW, totalHeight)
    self.optionsPanel:SetSize(dropdownW, totalHeight)
    -- Resize tous les boutons d'options pour matcher la nouvelle width
    for _, child in ipairs(self.dropdown:GetChildren()) do
        if IsValid(child) and child ~= self.optionsPanel then
            local _, ch = child:GetSize()
            child:SetSize(dropdownW, ch)
        end
    end
end

function PANEL:Paint(w, h)
    -- Background material
    if self.materials.background then
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(self.materials.background)
        surface.DrawTexturedRect(0, 0, w, h)
    end

    -- Selected text (x=10 scaled, sinon texte colle au bord sur 4K)
    local selectedText = self:GetSelectedText()
    if selectedText != "" then
        draw.SimpleText(selectedText, self.font, gRespX(10), h/2, self.textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    -- Arrow alignee a droite (TEXT_ALIGN_RIGHT) avec un margin minime
    -- (3px) pour qu'elle soit pile contre le bord droit du selectbox.
    local arrowText = self.isOpen and "▼" or "▲"
    draw.SimpleText(arrowText, "Ubuntu Mono:" .. tostring(gRespFont(14)),
        w - gRespX(3), h/2, self.textColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

-- Helper : cursor strictement dans les bounds du panel (fiable a toute resolution
-- contrairement a IsHovered() qui peut rater les bords sur 4K a cause du gRespX/Y).
local function cursorInPanel(pnl)
    if not IsValid(pnl) or not pnl:IsVisible() then return false end
    local mx, my = gui.MousePos()
    local sx, sy = pnl:LocalToScreen(0, 0)
    local w, h = pnl:GetWide(), pnl:GetTall()
    return mx >= sx and mx < sx + w and my >= sy and my < sy + h
end

-- Close dropdown when clicking outside.
-- Avant : IsHovered() ratait les bords sur 4K -> Think fermait le dropdown
-- juste apres que DoClick l'ouvre -> le user devait re-cliquer pour le voir.
function PANEL:Think()
    if self.isOpen and not cursorInPanel(self) and not cursorInPanel(self.dropdown) then
        if input.IsMouseDown(MOUSE_LEFT) then
            self:ToggleDropdown()
        end
    end
end

vgui.Register("lzy_faction_selectbox", PANEL, "DButton")
