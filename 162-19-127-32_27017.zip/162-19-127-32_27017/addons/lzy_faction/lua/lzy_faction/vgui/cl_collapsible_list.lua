-- "addons\\lzy_faction\\lua\\lzy_faction\\vgui\\cl_collapsible_list.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Collapsible List — Effectifs faction
-- Pattern inventaire : DScrollPanel (viewport) + UN conteneur DPanel (hauteur = contenu).
-- Ne pas poser les lignes directement sur le canvas ni forcer SetTall à la main :
-- SizeToChildren / InvalidateLayout gèrent la scrollbar (comme inventory/cl_main.lua).

local function gRespX(v) return gRespU(v) end
local function gRespY(v) return gRespU(v) end

local HEADER_H = 40 -- design px entre headers
local ROW_H = 32    -- design px par joueur

local function StyleScrollBar(scroll)
	local vbar = scroll:GetVBar()
	if not IsValid(vbar) then return end
	vbar:SetWide(4)
	vbar:SetHideButtons(true)
	vbar.Paint = function(panel, w, h)
		if not panel.Enabled then return end
		surface.SetDrawColor(20, 20, 20, 100)
		surface.DrawRect(0, 0, w, h)
	end
	if IsValid(vbar.btnGrip) then
		vbar.btnGrip.Paint = function(panel, w, h)
			local bar = panel:GetParent()
			if IsValid(bar) and not bar.Enabled then return end
			local a = panel:IsHovered() and 160 or 110
			surface.SetDrawColor(40, 40, 40, a)
			surface.DrawRect(0, 0, w, h)
		end
	end
end

local function BuildInto(scroll, items, material, onToggle)
	-- Vide uniquement le canvas (préserve la VBar).
	local canvas = scroll:GetCanvas()
	if IsValid(canvas) then canvas:Clear() end

	local viewW = scroll:GetWide()
	-- Largeur contenu : laisse 6px pour la barre fine (inventory = 4px + marge).
	local innerW = math.max(1, viewW - 6)

	local container = vgui.Create("DPanel", scroll)
	container:SetPos(0, 0)
	container.Paint = function() end
	scroll._container = container

	local sections = {}

	for _, item in ipairs(items or {}) do
		local header = vgui.Create("DButton", container)
		header:SetSize(innerW, gRespY(30))
		header:SetText("")
		header:SetDrawBackground(false)
		header.expanded = item.expanded and true or false
		header.headerMaterial = material
		header.Paint = function(s, w, h)
			if s.headerMaterial then
				RNDX.DrawMaterial(0, 0, 0, w, h, color_white, s.headerMaterial)
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(200, 0, 0, 100))
			end
			draw.SimpleText(item.title or "", "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(20), h / 2, Color(255, 255, 255, 125), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(item.connectedPlayers or "", "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(320), h / 2, Color(255, 255, 255, 125), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(s.expanded and "▼" or "▶", "Ubuntu Mono:" .. tostring(gRespFont(20)), w - gRespX(20), h / 2, Color(255, 255, 255, 125), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local rows = item.rows or {}
		local content = vgui.Create("DPanel", container)
		content:SetSize(innerW, gRespY(#rows * ROW_H))
		content:SetVisible(header.expanded)
		content.Paint = function() end

		for j, row in ipairs(rows) do
			local rowBtn = vgui.Create("DButton", content)
			rowBtn:SetSize(innerW, gRespY(ROW_H - 2))
			rowBtn:SetPos(0, gRespY((j - 1) * ROW_H))
			rowBtn:SetText("")
			rowBtn:SetDrawBackground(false)
			rowBtn.Paint = function(_, w, h)
				if row.isConnected then
					draw.RoundedBox(100, gRespX(7), h / 2 - gRespY(2), gRespX(5), gRespY(5), Color(0, 255, 0))
				end
				draw.SimpleText(row.text or "", "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(20), h / 2, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if row.stats then
					draw.SimpleText(row.stats, "Ubuntu Mono:" .. tostring(gRespFont(17)), gRespX(200), h / 2, color_black, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			rowBtn.DoClick = function()
				if row.onClick then row.onClick(row.text) end
			end
		end

		local sec = { header = header, content = content, rowCount = #rows }
		sections[#sections + 1] = sec

		header.DoClick = function(s)
			s.expanded = not s.expanded
			content:SetVisible(s.expanded)
			-- Relayout + resize conteneur (même logique que inventory RefreshItemsForCategory).
			local y = 0
			for _, section in ipairs(sections) do
				section.header:SetPos(0, gRespY(y))
				y = y + HEADER_H
				if section.header.expanded then
					section.content:SetPos(0, gRespY(y))
					section.content:SetVisible(true)
					y = y + section.rowCount * ROW_H
				else
					section.content:SetVisible(false)
				end
			end
			container:SetSize(innerW, gRespY(math.max(y, 1) + 8))
			scroll:InvalidateLayout(true)
			if onToggle then onToggle(item, s.expanded) end
		end
	end

	-- Placement initial + hauteur conteneur = contenu total.
	local y = 0
	for _, section in ipairs(sections) do
		section.header:SetPos(0, gRespY(y))
		y = y + HEADER_H
		if section.header.expanded then
			section.content:SetPos(0, gRespY(y))
			y = y + section.rowCount * ROW_H
		end
	end
	container:SetSize(innerW, gRespY(math.max(y, 1) + 8))
	scroll:InvalidateLayout(true)
end

function CreateCollapsibleList(parent, x, y, width, height, items, material, onToggle)
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:SetSize(width, height)
	scroll:SetPos(x, y)
	scroll:SetPaintBackground(false)
	StyleScrollBar(scroll)

	scroll._material = material
	scroll._onToggle = onToggle
	function scroll:SetMaterial(mat)
		self._material = mat
	end
	function scroll:SetItems(list)
		BuildInto(self, list, self._material, self._onToggle)
	end

	scroll:SetItems(items or {})
	return scroll
end
