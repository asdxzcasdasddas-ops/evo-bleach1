-- "addons\\lzy_faction\\lua\\lzy_faction\\vgui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local frame = nil

-- ── RÈGLEMENT DE FACTION ÉDITABLE (demande user 2026-07-25) ───────────────────
-- Texte libre écrit par le chef de faction (grade 16) / SuperAdmin, reçu du serveur.
-- nil = pas encore reçu ; "" = reçu vide -> on affiche le règlement RP statique
-- (LZY_FACTION_CONFIG.rules) comme DÉFAUT. Par faction (chacun voit le sien).
local factionReglement = nil

-- Découpe le texte libre en pages qui tiennent VRAIMENT dans le livre : on wrappe avec la
-- MÊME mesure que le rendu (splitText, glibs) et on coupe au nombre de lignes disponibles
-- AU-DESSUS du bouton « Éditer ». Avant : découpe à l'aveugle sur ~1000 caractères + cap dur
-- de 30 lignes -> une page trop dense se dessinait PAR-DESSUS le bouton au lieu de déborder
-- sur la page suivante (report user 08/20). Désormais le surplus part à la page suivante.
local REGLEMENT_PAGE_CHARS = 1000
local function PaginateReglement(sText, sFont, nLineWidth, nMaxLines)
	sText = sText or ""
	nMaxLines = math.max(1, tonumber(nMaxLines) or 30)

	-- Filet : glibs pas encore chargé -> ancienne découpe au caractère (jamais pire qu'avant).
	if not (isfunction(splitText) and sFont and nLineWidth) then
		local pages, cur = {}, ""
		for _, para in ipairs(string.Explode("\n", sText)) do
			local candidate = (cur == "") and para or (cur .. "\n" .. para)
			if #candidate > REGLEMENT_PAGE_CHARS and cur ~= "" then
				pages[#pages + 1] = cur
				cur = para
			else
				cur = candidate
			end
		end
		if cur ~= "" or #pages == 0 then pages[#pages + 1] = cur end
		return pages
	end

	local tPages, tCur = {}, {}
	local function Flush()
		tPages[#tPages + 1] = table.concat(tCur, "\n")
		tCur = {}
	end
	for _, sPara in ipairs(string.Explode("\n", sText)) do
		-- Paragraphe vide = ligne vide VOULUE (respiration du texte), à conserver.
		local tWrapped = (sPara == "") and { "" } or splitText(sPara, sFont, nLineWidth)
		if not istable(tWrapped) or #tWrapped == 0 then tWrapped = { sPara } end
		for _, sLine in ipairs(tWrapped) do
			if #tCur >= nMaxLines then Flush() end
			tCur[#tCur + 1] = sLine
		end
	end
	if #tCur > 0 or #tPages == 0 then Flush() end
	return tPages
end

-- Popup « Raison du refus » (demande user 2026-07-31) : refuser un rapport EXIGE quelques
-- mots d'explication — stockés en BDD et montrés à l'auteur du rapport. fOnSent est appelé
-- après l'envoi réseau (retrait de la liste + refresh, propre à chaque site d'appel).
local function OpenRejectReasonPopup(nReportId, fOnSent)
	local COL_BG     = Color(14, 14, 17, 255)
	local COL_PANEL  = Color(24, 24, 30, 255)
	local COL_ACCENT = Color(207, 68, 78)
	local COL_TXT    = Color(236, 237, 242)
	local COL_DIM    = Color(150, 152, 160)

	local pop = vgui.Create("DFrame")
	pop:SetSize(gRespX(480), gRespY(240))
	pop:Center()
	pop:SetTitle("")
	pop:ShowCloseButton(false)
	pop:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pop) end

	local sError = nil
	pop.Paint = function(_, w, h)
		draw.RoundedBox(12, 0, 0, w, h, COL_BG)
		draw.RoundedBoxEx(12, 0, 0, w, gRespY(6), COL_ACCENT, true, true, false, false)
		draw.SimpleText("REFUSER LE RAPPORT", "Ubuntu Mono Bold:" .. tostring(gRespFont(22)), gRespX(24), gRespY(22), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(sError or "Explique en quelques mots pourquoi (obligatoire, montré à l'auteur).", "Ubuntu Mono:" .. tostring(gRespFont(14)), gRespX(24), gRespY(50), sError and COL_ACCENT or COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local entry = vgui.Create("DTextEntry", pop)
	entry:SetPos(gRespX(24), gRespY(78))
	entry:SetSize(gRespX(432), gRespY(92))
	entry:SetMultiline(true)
	entry.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, COL_PANEL)
		s:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
	end
	entry:RequestFocus()

	local cancel = vgui.Create("DButton", pop)
	cancel:SetText("")
	cancel:SetPos(gRespX(24), gRespY(186))
	cancel:SetSize(gRespX(200), gRespY(34))
	cancel.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, COL_PANEL)
		draw.SimpleText("Annuler", "Ubuntu Mono:" .. tostring(gRespFont(16)), w / 2, h / 2, s:IsHovered() and COL_TXT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	cancel.DoClick = function() pop:Close() end

	local confirm = vgui.Create("DButton", pop)
	confirm:SetText("")
	confirm:SetPos(gRespX(256), gRespY(186))
	confirm:SetSize(gRespX(200), gRespY(34))
	confirm.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and COL_ACCENT or Color(120, 45, 52))
		draw.SimpleText("Refuser le rapport", "Ubuntu Mono Bold:" .. tostring(gRespFont(16)), w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	confirm.DoClick = function()
		local sReason = string.Trim(entry:GetValue() or "")
		if #sReason < 3 then
			sError = "Écris au moins quelques mots — la raison est obligatoire."
			return
		end
		net.Start("server:lzy_faction.RejectReport")
		net.WriteUInt(nReportId, 32)
		net.WriteString(string.sub(sReason, 1, 200))
		net.SendToServer()
		pop:Close()
		if fOnSent then fOnSent() end
	end
end

-- Éditeur du règlement (grade 16 / SA). Fenêtre texte libre pré-remplie -> Enregistrer envoie
-- au serveur (qui revalide le grade et pousse à tous les membres de la faction).
local function OpenReglementEditor()
	local COL_BG     = Color(14, 14, 17, 255)   -- fond DA (#0E0E11)
	local COL_PANEL  = Color(24, 24, 30, 255)   -- zone de texte
	local COL_ACCENT = Color(207, 68, 78)        -- accent DA (#cf444e)
	local COL_TXT    = Color(236, 237, 242)
	local COL_DIM    = Color(150, 152, 160)
	local MAXLEN     = 8000

	local editor = vgui.Create("DFrame")
	-- Taille VIRTUELLE (scale uniforme, comme le reste du menu) : sinon un cap px fixe + des polices
	-- gRespFont (scalées par résolution) débordent en 4K. gRespX/Y = gRespU dans ce fichier.
	editor:SetSize(gRespX(760), gRespY(680))
	editor:Center()
	editor:SetTitle("")
	editor:ShowCloseButton(false)
	editor:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(editor) end -- APRES MakePopup
	editor.Paint = function(_, w, h)
		draw.RoundedBox(12, 0, 0, w, h, COL_BG)
		draw.RoundedBoxEx(12, 0, 0, w, gRespY(6), COL_ACCENT, true, true, false, false)
		draw.SimpleText("RÈGLEMENT DE FACTION", "Ubuntu Mono Bold:" .. tostring(gRespFont(28)), gRespX(28), gRespY(26), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Rédige les règles de ta faction : visibles par tous tes membres.", "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(28), gRespY(62), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local entry -- forward-declare : le footer (compteur) et Enregistrer le lisent.

	-- Croix de fermeture (coin haut-droit).
	local closeBtn = vgui.Create("DButton", editor)
	closeBtn:SetText("") closeBtn:SetSize(gRespX(36), gRespY(36))
	closeBtn:SetPos(editor:GetWide() - gRespX(46), gRespY(12)) -- frame de taille fixe -> position statique
	closeBtn.Paint = function(s, w, h)
		draw.SimpleText("✕", "Ubuntu Mono Bold:" .. tostring(gRespFont(24)), w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeBtn.DoClick = function() editor:Close() end

	-- Header : réserve l'espace du titre (dessiné par editor.Paint) ; input off -> DFrame déplaçable.
	local head = vgui.Create("DPanel", editor)
	head:Dock(TOP) head:SetTall(gRespY(92)) head:SetMouseInputEnabled(false) head.Paint = function() end

	-- Footer : compteur (gauche) + Annuler / Enregistrer (droite).
	local footer = vgui.Create("DPanel", editor)
	footer:Dock(BOTTOM) footer:SetTall(gRespY(54)) footer:DockMargin(gRespX(28), gRespY(6), gRespX(28), gRespY(16))
	footer.Paint = function(_, w, h)
		local n = #((IsValid(entry) and entry:GetValue()) or "")
		draw.SimpleText(n .. " / " .. MAXLEN .. " caractères", "Ubuntu Mono:" .. tostring(gRespFont(15)), 0, h / 2, n > MAXLEN and COL_ACCENT or COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local save = vgui.Create("DButton", footer)
	save:Dock(RIGHT) save:SetWide(gRespX(210)) save:SetText("")
	save.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and Color(0, 200, 108) or Color(0, 158, 84))
		draw.SimpleText("Enregistrer", "Ubuntu Mono Bold:" .. tostring(gRespFont(19)), w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	save.DoClick = function()
		local txt = (IsValid(entry) and entry:GetValue()) or ""
		if #txt > MAXLEN then txt = string.sub(txt, 1, MAXLEN) end -- borne (comme le serveur)
		net.Start("server:lzy_faction.SaveReglement")
			net.WriteString(txt)
		net.SendToServer()
		editor:Close()
	end

	local cancel = vgui.Create("DButton", footer)
	cancel:Dock(RIGHT) cancel:SetWide(gRespX(120)) cancel:DockMargin(0, 0, gRespX(10), 0) cancel:SetText("")
	cancel.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, s:IsHovered() and Color(52, 52, 62) or Color(38, 38, 46))
		draw.SimpleText("Annuler", "Ubuntu Mono:" .. tostring(gRespFont(18)), w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	cancel.DoClick = function() editor:Close() end

	-- Zone de texte : grande, sombre, SANS le petit « FR » de langue (SetDrawLanguageID).
	local paper = vgui.Create("DPanel", editor)
	paper:Dock(FILL) paper:DockMargin(gRespX(28), gRespY(2), gRespX(28), gRespY(2))
	paper.Paint = function(_, w, h) draw.RoundedBox(10, 0, 0, w, h, COL_PANEL) end

	entry = vgui.Create("DTextEntry", paper)
	entry:Dock(FILL) entry:DockMargin(gRespX(14), gRespY(12), gRespX(8), gRespY(12))
	entry:SetMultiline(true)
	entry:SetVerticalScrollbarEnabled(true)
	if entry.SetDrawLanguageID then entry:SetDrawLanguageID(false) end -- retire le « FR » (indicateur de langue)
	entry:SetFont("Ubuntu Mono:" .. tostring(gRespFont(21)))
	entry:SetText(factionReglement or "")
	entry:SetPaintBackground(false)
	entry:SetTextColor(COL_TXT)
	entry.Paint = function(s, w, h) s:DrawTextEntryText(COL_TXT, COL_ACCENT, color_white) end
	entry:RequestFocus()
end

-- FIX resolution non-16:9 (ex. 1080x1080 carre) : le menu faction est un POPUP CENTRE,
-- il ne doit pas subir le scale independant X/Y (qui ecrase icones / vignettes / PNG et
-- l'image du livre horizontalement). On aliase gRespX/gRespY sur le scale UNIFORME gRespU
-- (min des axes) pour TOUT ce fichier -> proportions conservees, STRICTEMENT identique en
-- 16:9, popup centre non-etire sur ultrawide. Wrappers lazy (gRespU resolu a l'appel) ->
-- aucun risque d'ordre de chargement. Les methodes meta (frame/selectbox) utilisent les
-- variantes gSet*U plus bas (elles, appellent les globales gRespX/gRespY, pas ces locales).
local function gRespX(v) return gRespU(v) end
local function gRespY(v) return gRespU(v) end

local materials = {
	bg = Material("hnztk71178zj/a2anpyxxj24sr/wqie3m8jdsak4vzij.png"),
	close = Material("hnztk71178zj/6slbdylhzhj3gcysk.png"), -- 48x48
	button1_text = Material("hnztk71178zj/43hy1yq8id4v3ddol.png"), -- 212x27
	button1_icon = Material("hnztk71178zj/ify3df4ea0ut.png"), -- 56x56
	button2_text = Material("hnztk71178zj/g8vdy69mhd9c3ijb.png"), -- 193x63
	button2_icon = Material("hnztk71178zj/o4jb52iwnt52p.png"), -- 63x63
	button3_text = Material("hnztk71178zj/o4r90ogbxfc3.png"), -- 195x27
	button3_icon = Material("hnztk71178zj/zyufyv28oqek6cqx.png"), -- 61x61
	button4_text = Material("hnztk71178zj/to13pt09jndb.png"), -- 226x68
	button4_icon = Material("hnztk71178zj/9nm2gd5xsn3fjq5bk.png"), -- 63x63
	button5_text = Material("hnztk71178zj/q8lamesoig72bh4rt.png"), -- 155x63
	button5_icon = Material("hnztk71178zj/0epq18e6m2p6ry.png"), -- 63x63
	tache = Material("hnztk71178zj/coenykhcnfzlu0.png"), -- 83x83
	small_tache = Material("hnztk71178zj/6z5w96gw08gvjw5.png"), -- 46x46
	long_tache = Material("hnztk71178zj/h4ihoz1gyqom4d8a.png"), -- 114x164
	timbre = Material("hnztk71178zj/bk4rc2e2md7pha3q5.png"), -- 180x180
	horizontal_line = Material("hnztk71178zj/j9nl0rxhqzq93.png"), -- 338x62
	reglement_text = Material("hnztk71178zj/3crwaya3fnxhqoj24.png"), -- 269x28
	page_suivante = Material("hnztk71178zj/wykoojbmim6ufwha.png"), -- 128x25
	page_precedente = Material("hnztk71178zj/eni5i1p0zlj1s.png"), -- 128x25
	category_selected = Material("hnztk71178zj/7ca4aecgegvl78.png"), -- 135x135 Overlay for selected category
	rapport_horizontal_line = Material("hnztk71178zj/800p6qotygz6ql9e.png"), -- 339x79
	rapport_text = Material("hnztk71178zj/c073fvm1ya9j.png"), -- 239x72
	envoyer_rapport = Material("hnztk71178zj/oib6o4gsl57la3.png"), -- 165x25
	left_side_bg = Material("hnztk71178zj/rs7h7gr2ip5iht.png"), -- 720x846
	right_side_bg = Material("hnztk71178zj/jse465mn2y01i.png"), -- 435x507
	effectifs_text = Material("hnztk71178zj/sqp2v5kw0k6eqylp.png"), -- 232x28
	rapport_a_valider_text = Material("hnztk71178zj/2syda3nuf3hwz0v.png"), -- 281x71
	gestion_faction_text = Material("hnztk71178zj/txrq2vzd2evi.png"), -- 194x72
	collapse_bg = Material("hnztk71178zj/puw4w7h7f9l26j97f.png"), -- 390x22
	selectbox_bg = Material("hnztk71178zj/tfghpzr87n94v.png"), -- 76x22
	valider_le_rapport = Material("hnztk71178zj/vlv0h4vs2j3g.png"), -- 157x25
	refuser_le_rapport = Material("hnztk71178zj/mrw8heii0mefo3eqe.png"), -- 162x25
	message_de_division = Material("hnztk71178zj/8ghv57yc2r18ps.png"), -- 261x26
	gestion_de_division = Material("hnztk71178zj/6994qx81t9g6a.png"), -- 248x21
	publier_btn = Material("hnztk71178zj/i7fiq5c2ztpsj.png"), -- 180x35

}

local book_sequence = {
	Material("hnztk71178zj/a2anpyxxj24sr/cadelpe3t7v2j05ac.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/71c0vrqgmsr4lw.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/d4l6etr8qyl2plqv.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/nzk76e4vf2nnxbpph.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/viki5h2zc61a.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/z5t6wka0fu4p.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/uhcfpdh7q2zovbme.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/brcqlpkzc8jlq.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/p2cwuw6qy3eic4r.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/z4j8ojlca6ua48f.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/5oe6sa0ibn988.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/zs0zelvdw32i.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/hitdxwa5r5fbyd.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/6akne7gcje33.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/12kejwt9sklm7hi.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/vxqivgvtodragj8.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/2odyvb2buaoz8bgz8.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/yrnvbvg0zffs3i.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/rtteubt5oxu26v.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/cgfnqrwvopev88r3k.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/minpdx5anhvc.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/ijrvnwse5kgyk.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/6si5zhy9ntwdss.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/ep9mi6lqmdg1bq.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/h12g8sem64si588je.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/y05gmcuub51s.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/xsqm5llt79dcr0.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/pso3c1m0bapzwor.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/uop4zpwd82q10.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/fp0syc67a5k4jku9.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/6un0j71w71s79.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/xndlmajp2p8dx.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/dgn12gp5h95s9.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/0lnaauxrg8i99r281.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/jtt1n1e351ge.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/3anyrc8dduv9pt.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/g8djhzipn97v5hz5.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/cso9v2k53cg97.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/8ilw7y770vuaztrc.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/nuu2gnf22ovd1o0g2.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/w4bdqb15ttctf.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/rtdslvs71elq9ca.png"),
	Material("hnztk71178zj/a2anpyxxj24sr/wqie3m8jdsak4vzij.png"),
}

local soundsData = {
	opening_book = {
		path = "hnztk71178zj/5zo1hwzpkxdtckv3.ogg",
		volume = 100,
		loop = false,
		sound = nil
	},
	closing_book = {
		path = "hnztk71178zj/2mok7z21c6op24.ogg",
		volume = 100,
		loop = false,
		sound = nil
	}
}

-- One-shot book sequence player. Plays once, then opens the faction panel.
local isPlayingBook = false
local BOOK_SEQUENCE_DELAY = 0.025 -- seconds per frame (20 fps)

-- Category definitions
local categories = {
	[1] = { name = "Category 1", title = "Category One", description = "This is the first category content." },
	[2] = { name = "Category 2", title = "Category Two", description = "This is the second category content." },
	[3] = { name = "Category 3", title = "Category Three", description = "This is the third category content." },
	[4] = { name = "Category 4", title = "Category Four", description = "This is the fourth category content." },
	[5] = { name = "Category 5", title = "Category Five", description = "This is the fifth category content." },
}

local playersListByDivision = {}
local effectifsSearchResults = nil
local effectifsSearchBuf = nil
local effectifsSearchPending = ""
local effectifsDivisionBuf = nil

local reportsToValidate = {
	{contentPreview = "Rapport de patrouille kljef wnef", author = "Agent Smith", rank = "Soldat", division = "3"},
}

-- Archives : rapports déjà traités (validés / refusés) de la division, envoyés à la demande
-- par le serveur quand on ouvre la vue Archives (demande user 2026-07-31).
local archivedReports = {}

-- Sample player data
local players = {
}

function PANEL:Init()
	self:SetAlpha(0)
	self:SetDraggable(false)
	self:SetSizable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetVisible(true)
	self:gSetSizeU(1200, 870)
	-- Centrage sur l'écran RÉEL (pas les coords virtuelles 1920x1080) pour rester centré à
	-- TOUTE résolution, carrée 1:1 comprise ; l'offset design +117 (décalage droite du livre)
	-- est conservé, mis à l'échelle uniforme. En 16:9 c'est identique à l'ancien gSetPos
	-- (ScrW = 1920*s -> (ScrW - gRespU(1200))/2 + gRespU(117) == gRespX(477) au pixel près).
	self:SetPos(math.floor((ScrW() - gRespU(1200)) / 2) + gRespU(117), math.floor((ScrH() - gRespU(870)) / 2))
	self.mainLeftPadding = 120
	self.categoryLeftPadding = 25

	self:CreateCategoriesButtons()
	self:CreateContentPanel()

	-- Set default category
	self:SwitchToCategory(1)

	-- Create close button using custom button
	self.closeButton = vgui.Create("lzy_faction_button", self)
	self.closeButton:SetSize(gRespX(48), gRespY(48))
	self.closeButton:SetPos(gRespX(1200 - 310 + self.mainLeftPadding), gRespY(43))
	self.closeButton:SetMaterials(nil, materials.close)
	self.closeButton:SetIconSize(gRespX(48), gRespY(48))
	self.closeButton.DoClick = function()
		self:Close()
	end

	net.Start("server:lzy_faction.GetInitData")
	net.WriteString(LocalPlayer():GetEvoNWString("FactionName"))
	net.SendToServer()

	-- Fade to full opacity
	self:AlphaTo(255, 0.2, 0)
end

function PANEL:CreateCategoriesButtons()
	-- Create button container
	self.buttonContainer = vgui.Create("DPanel", self)
	self.buttonContainer:SetSize(gRespX(420), gRespY(500))
	self.buttonContainer:SetPos(gRespX(110 + self.categoryLeftPadding), gRespY(215))
	self.buttonContainer.Paint = function() end

	-- Create 5 custom buttons
	self.buttons = {}

	-- Button 1
	self.buttons[1] = vgui.Create("lzy_faction_button", self.buttonContainer)
	self.buttons[1]:SetPos(0, 0)
	self.buttons[1]:SetMaterials(materials.button1_text, materials.button1_icon)
	self.buttons[1]:SetTextSize(gRespX(212), gRespY(27))
	self.buttons[1]:SetIconSize(gRespX(48), gRespY(48))
	self.buttons[1]:SetButtonSize(gRespX(350), gRespY(70))
	self.buttons[1].isSelected = false -- Add selected state
	self.buttons[1]:SetCategorySelectedMaterial(materials.category_selected)
	self.buttons[1]:SetSelectedMatOffset(-8)
	self.buttons[1].DoClick = function()
		self:SwitchToCategory(1)
	end

	-- Button 2
	self.buttons[2] = vgui.Create("lzy_faction_button", self.buttonContainer)
	self.buttons[2]:SetPos(gRespX(0), gRespY(80))
	self.buttons[2]:SetMaterials(materials.button2_text, materials.button2_icon)
	self.buttons[2]:SetTextSize(gRespX(193), gRespY(63))
	self.buttons[2]:SetIconSize(gRespX(48), gRespY(48))
	self.buttons[2]:SetButtonSize(gRespX(350), gRespY(90))
	self.buttons[2].isSelected = false -- Add selected state
	self.buttons[2]:SetCategorySelectedMaterial(materials.category_selected)
	self.buttons[2]:SetSelectedMatOffset(20)
	self.buttons[2].DoClick = function()
		self:SwitchToCategory(2)
	end

	-- Button 3
	self.buttons[3] = vgui.Create("lzy_faction_button", self.buttonContainer)
	self.buttons[3]:SetPos(gRespX(0), gRespY(170))
	self.buttons[3]:SetMaterials(materials.button3_text, materials.button3_icon)
	self.buttons[3]:SetIconSize(gRespX(48), gRespY(48))
	self.buttons[3]:SetTextSize(gRespX(195), gRespY(27))
	self.buttons[3]:SetButtonSize(gRespX(350), gRespY(70))
	self.buttons[3].isSelected = false -- Add selected state
	self.buttons[3]:SetCategorySelectedMaterial(materials.category_selected)
	self.buttons[3]:SetSelectedMatOffset(-8)
	self.buttons[3].DoClick = function()
		self:SwitchToCategory(3)
	end

	-- Boutons 4/5 : JAMAIS pour une faction sans hiérarchie (1 seul grade, ex. pseudo-faction
	-- LostSoul de l'âme errante). Sans cette garde, maxRank=1 rendait les seuils « max-1 » (0) et
	-- « max-2 » (-1) toujours vrais -> l'âme errante voyait validation + gestion débloquées
	-- (demande user 07/20 : elle ne garde que règlement / effectifs / écrire un rapport).
	local nCatMaxRank = #(LZY_FACTION_CONFIG.factions[LocalPlayer():GetEvoNWString("FactionName")] or {})
	if nCatMaxRank <= 1 then return end

	-- Button 4 (validation des rapports) : dès ReportReviewMinRank (10, demande user 08/02 —
	-- avant grade max-1). Même seuil que les gates serveur (net.lua), scope = SA division.
	if (LocalPlayer():GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.ReportReviewMinRank or 10)) then
		self.buttons[4] = vgui.Create("lzy_faction_button", self.buttonContainer)
		self.buttons[4]:SetPos(gRespX(0), gRespY(250))
		self.buttons[4]:SetMaterials(materials.button4_text, materials.button4_icon)
		self.buttons[4]:SetIconSize(gRespX(48), gRespY(48))
		self.buttons[4]:SetTextSize(gRespX(226), gRespY(68))
		self.buttons[4]:SetButtonSize(gRespX(400), gRespY(90))
		self.buttons[4].isSelected = false -- Add selected state
		self.buttons[4]:SetCategorySelectedMaterial(materials.category_selected)
		self.buttons[4]:SetSelectedMatOffset(20)
		self.buttons[4].DoClick = function()
			self:SwitchToCategory(4)
		end
	end

	-- Button 5 (gestion de faction) : ouvert dès le grade PromoteMinRank (10, demande user 08/01).
	-- Le CHEF (16) et les gradés (>= DivisionMinRank, 10) reçoivent la liste COMPLÈTE de la
	-- faction et peuvent assigner les DIVISIONS ; les grades 11-14 gèrent les membres de LEUR
	-- division (liste envoyée par le serveur) et peuvent les promouvoir SOUS leur propre grade.
	-- Tout est revalidé serveur (net.lua SetRank/SetDivision : seuils config, plafond hiérarchique,
	-- même division/faction, prérequis). Hors division, un 11-14 ne voit que le composer d'annonce.
	-- Ouvert aussi aux formateurs whitelistés (vue réduite seulement, cf. Category5).
	if LocalPlayer():GetEvoNWInt("FactionRank", 0) < (LZY_FACTION_CONFIG.PromoteMinRank or 10)
		and not LocalPlayer():GetEvoNWBool("EVO_FactionFormateur", false) then return end
	self.buttons[5] = vgui.Create("lzy_faction_button", self.buttonContainer)
	self.buttons[5]:SetPos(gRespX(0), gRespY(350))
	self.buttons[5]:SetMaterials(materials.button5_text, materials.button5_icon)
	self.buttons[5]:SetIconSize(gRespX(48), gRespY(48))
	self.buttons[5]:SetTextSize(gRespX(155), gRespY(63))
	self.buttons[5]:SetButtonSize(gRespX(350), gRespY(90))
	self.buttons[5].isSelected = false -- Add selected state
	self.buttons[5]:SetCategorySelectedMaterial(materials.category_selected)
	self.buttons[5]:SetSelectedMatOffset(20)
	self.buttons[5].DoClick = function()
		self:SwitchToCategory(5)
	end
end

function PANEL:CreateContentPanel()
	-- Create content panel on the right side
	self.contentPanel = vgui.Create("DPanel", self)
	self.contentPanel:SetSize(gRespX(450), gRespY(780))
	self.contentPanel:SetPos(gRespX(498 + self.mainLeftPadding - 30), gRespY(50))
	self.contentPanel.Paint = function(self, w, h)
		--draw.RoundedBox(8, 0, 0, w, h, Color(235, 17, 17, 200))
	end
end

function PANEL:SwitchToCategory(categoryId)
	if not categories[categoryId] then return end
	self.currentCategory = categoryId

	-- Clear existing content
	self.contentPanel:Clear()

	-- Create category-specific UI
	if categoryId == 1 then
		self:CreateCategory1UI()
	elseif categoryId == 2 then
		self:CreateCategory2UI()
	elseif categoryId == 3 then
		self:CreateCategory3UI()
	elseif categoryId == 4 then
		self:CreateCategory4UI()
	elseif categoryId == 5 then
		self:CreateCategory5UI()
	end

	-- Update button states (visual feedback for selected category)
	for i, button in ipairs(self.buttons) do
		if i == categoryId then
			-- Highlight selected button
			button:SetSelected(true) -- Set selected state
		else
			-- Unselect other buttons
			button:SetSelected(false) -- Set unselected state
		end
	end
end

-- Function to show detailed view of a report
function ShowReportDetail(contentPanel, report)
	-- Clear the content panel
	contentPanel:Clear()

	-- Override the contentPanel's Paint function to hide the report count text
	contentPanel.Paint = function(self, w, h)
		-- Empty paint function - no report count text
	end

	local width, height = contentPanel:GetSize()
	-- Rapport ARCHIVÉ (déjà validé / refusé) : lecture seule, on revient aux Archives.
	local mainPanel = contentPanel:GetParent():GetParent()
	local bArchived = report.status == "validated" or report.status == "rejected"
	-- On n'est plus sur la LISTE des archives : une arrivée tardive de celle-ci ne doit
	-- pas remplacer le détail qu'on est en train de lire.
	mainPanel._archiveView = false

	-- Back button
	local backBtn = vgui.Create("lzy_faction_button", contentPanel)
	backBtn:SetSize(gRespX(100), gRespY(30))
	backBtn:SetPos(gRespX(10), gRespY(0))
	backBtn:SetMaterials(nil, nil)
	backBtn:SetTextSize(gRespX(100), gRespY(30))
	backBtn:SetIconSize(gRespX(0), gRespY(0))
	backBtn:SetButtonSize(gRespX(100), gRespY(30))
	backBtn:SetUnderlineHover(true)
	backBtn:SetText("← Retour")
	backBtn:SetTextColor(Color(0, 0, 0, 255))
	backBtn:SetFont("Ubuntu Mono:" .. tostring(gRespFont(20)))
	backBtn.DoClick = function()
		-- Recreate the report list (ou la liste des archives si on en vient)
		if bArchived then
			mainPanel:CreateArchiveUI()
		else
			mainPanel:SwitchToCategory(4)
		end
	end

	-- Report title
	local titleLabel = vgui.Create("DLabel", contentPanel)
	titleLabel:SetSize(gRespX(400), gRespY(40))
	titleLabel:SetPos(120, gRespY(10))
	titleLabel:SetFont("Ubuntu Mono:" .. tostring(gRespFont(20)))
	titleLabel:SetTextColor(Color(0, 0, 0, 255))
	titleLabel:SetText(bArchived and "Rapport archivé" or "Détails du rapport")
	titleLabel:SetContentAlignment(4) -- Left align

	-- Report info panel
	local infoPanel = vgui.Create("DPanel", contentPanel)
	infoPanel:SetSize(gRespX(430), gRespY(100))
	infoPanel:SetPos(gRespX(10), gRespY(50))
	infoPanel.Paint = function(self, w, h)
		-- Border
		RNDX.DrawOutlined(gRespX(0), gRespX(0), gRespY(0), w, h, Color(0, 0, 0), 1)

		-- Info text
		draw.SimpleText("Auteur: " .. report.author, "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(10), gRespY(10), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Grade: " .. report.rank, "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(10), gRespY(30), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(LZY_FACTION_CONFIG.DivisionName(LocalPlayer(), report.division), "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(10), gRespY(50), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Catégorie: " .. (report.mission or "—"), "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(10), gRespY(70), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	-- Full content panel
	local contentScrollPanel = vgui.Create("DScrollPanel", contentPanel)
	contentScrollPanel:SetSize(gRespX(430), height - gRespY(270))
	contentScrollPanel:SetPos(gRespX(10), gRespY(160))

	-- Custom scroll bar for content
	local contentScrollBar = contentScrollPanel:GetVBar()
	contentScrollBar:SetWide(gRespX(8))
	contentScrollBar.Paint = function(self, w, h)
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 100))
	end
	contentScrollBar.btnGrip.Paint = function(self, w, h)
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 200))
		if self:IsHovered() then
			draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 250))
		end
	end

	-- Content text panel
	local textPanel = vgui.Create("DPanel", contentScrollPanel)
	textPanel:SetSize(gRespX(430), gRespY(0)) -- Height will be calculated
	textPanel:SetPos(gRespX(0), gRespY(0))
	textPanel.Paint = function(self, w, h)
		-- Border
		RNDX.DrawOutlined(gRespX(0), gRespX(0), gRespY(0), w, h, Color(0, 0, 0), 1)

		-- Full content text
		local fullContent = report.content or report.contentPreview
		gRespDrawMultilineText(fullContent, "Ubuntu Mono:" .. tostring(gRespFont(15)), gRespX(10), gRespY(10), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, gRespY(18), w - gRespX(20), h - gRespY(20))
	end

	-- Hauteur RÉELLE du contenu : même découpe que le rendu (splitText de glibs =
	-- wrap par largeur + sauts de ligne). L'ancienne estimation « 50 caractères par
	-- ligne » sous-estimait dès que le rapport contenait des retours à la ligne ->
	-- le canvas du scroll était trop court et le bas du rapport inatteignable
	-- (demande user 08/02 « pouvoir scroll le contenu d'un rapport »).
	local fullContent = report.content or report.contentPreview
	local nLines
	if splitText then
		nLines = #splitText(fullContent, "Ubuntu Mono:" .. tostring(gRespFont(15)), gRespX(430) - gRespX(20))
	else
		nLines = math.ceil(string.len(fullContent) / 50) -- repli : ancienne estimation
	end
	local textHeight = math.max(nLines * gRespY(18) + gRespY(20), height - gRespY(270))
	textPanel:SetSize(gRespX(430), textHeight)

	-- ── Preuve jointe (image) : téléchargée du serveur (chunks + cache disque), sous le
	-- texte, dans le scroll. Clic = plein écran. N'apparaît que si le rapport en a une.
	if isstring(report.image_file) and report.image_file ~= "" and LZYF_ReportImage then
		local imgPanel = vgui.Create("DButton", contentScrollPanel)
		imgPanel:SetSize(gRespX(430), gRespY(242))
		imgPanel:SetPos(gRespX(0), textHeight + gRespY(8))
		imgPanel:SetText("")
		imgPanel:SetTooltip("Cliquer pour agrandir")
		imgPanel._mat = nil
		LZYF_ReportImage.Request(report.reportId, report.image_file, function(mat)
			if IsValid(imgPanel) then imgPanel._mat = mat end
		end)
		imgPanel.Paint = function(s, w, h)
			RNDX.DrawOutlined(0, 0, 0, w, h, Color(0, 0, 0), 1)
			if not s._mat then
				draw.SimpleText("Chargement de la preuve…", "Ubuntu Mono:" .. tostring(gRespFont(16)), w / 2, h / 2, Color(0, 0, 0, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				return
			end
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(s._mat)
			surface.DrawTexturedRect(1, 1, w - 2, h - 2)
		end
		imgPanel.DoClick = function(s)
			if not s._mat then return end
			-- Visionneuse plein écran : fond sombre, image 16:9 centrée, clic/Échap ferme.
			local zoom = vgui.Create("DFrame")
			zoom:SetSize(ScrW(), ScrH()) zoom:SetTitle("") zoom:SetDraggable(false)
			zoom:ShowCloseButton(false) zoom:MakePopup()
			if EVO_MakeEscClosable then EVO_MakeEscClosable(zoom) end
			zoom.Paint = function(_, w, h)
				surface.SetDrawColor(0, 0, 0, 235) surface.DrawRect(0, 0, w, h)
				local iw = math.min(w * 0.9, (h * 0.9) * (16 / 9))
				local ih = iw * 9 / 16
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(s._mat)
				surface.DrawTexturedRect((w - iw) / 2, (h - ih) / 2, iw, ih)
			end
			zoom.OnMousePressed = function() zoom:Close() end
		end
	end

	-- Action buttons panel (right side)
	local actionPanel = vgui.Create("DPanel", contentPanel)
	actionPanel:SetSize(gRespX(430), gRespY(120))
	actionPanel:SetPos(gRespX(0), height - gRespY(80))
	actionPanel.Paint = function(self, w, h)
		if not bArchived then return end
		-- Archive : pas de boutons, on rappelle l'issue du rapport (et le motif du refus).
		local bValidated = report.status == "validated"
		local colStatus = bValidated and Color(30, 110, 55) or Color(150, 30, 35)
		draw.SimpleText(bValidated and "Rapport validé" or "Rapport refusé", "Ubuntu Mono:" .. tostring(gRespFont(18)), gRespX(15), gRespY(2), colStatus, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if not bValidated and (report.reject_reason or "") ~= "" then
			gRespDrawMultilineText("Motif : " .. report.reject_reason, "Ubuntu Mono:" .. tostring(gRespFont(15)), gRespX(15), gRespY(26), colStatus, TEXT_ALIGN_LEFT, gRespY(16), gRespX(400), 3)
		end
	end

	if bArchived then return end

	-- Boutons Valider/Refuser : la LARGEUR DU BOUTON est > largeur du MATÉRIAU texte pour que le
	-- matériau s'affiche EN ENTIER (avant : bouton = matériau -> le padding du composant compressait
	-- l'image = "crop", variable selon la résolution). Repositionnés proprement dans le panneau
	-- (gRespX, responsive) : Refuser à GAUCHE, Valider à DROITE, sans débordement.
	local validateBtn = vgui.Create("lzy_faction_button", actionPanel)
	validateBtn:SetSize(gRespX(187), gRespY(25))
	validateBtn:SetPos(gRespX(228), gRespY(0)) -- droite : 430 - 187 - 15
	validateBtn:SetMaterials(materials.valider_le_rapport, nil)
	validateBtn:SetTextSize(gRespX(157), gRespY(25))
	validateBtn:SetIconSize(gRespX(0), gRespY(0))
	validateBtn:SetButtonSize(gRespX(187), gRespY(25))
	validateBtn:SetUnderlineHover(true)
	validateBtn.DoClick = function()
		net.Start("server:lzy_faction.ValidateReport")
		net.WriteUInt(report.reportId, 32)
		net.SendToServer()
		-- Remove this report from the list
		for i, report in ipairs(reportsToValidate) do
			if report.reportId == report.reportId then
				table.remove(reportsToValidate, i)
				break
			end
		end
		contentPanel:GetParent():GetParent():SwitchToCategory(4)
	end

	-- Reject button
	local rejectBtn = vgui.Create("lzy_faction_button", actionPanel)
	rejectBtn:SetSize(gRespX(192), gRespY(25))
	rejectBtn:SetPos(gRespX(15), gRespY(0)) -- gauche
	rejectBtn:SetMaterials(materials.refuser_le_rapport, nil)
	rejectBtn:SetTextSize(gRespX(162), gRespY(25))
	rejectBtn:SetIconSize(gRespX(0), gRespY(0))
	rejectBtn:SetButtonSize(gRespX(192), gRespY(25))
	rejectBtn:SetUnderlineHover(true)
	rejectBtn.DoClick = function()
		-- Raison obligatoire : le net part depuis le popup, une fois la raison saisie.
		OpenRejectReasonPopup(report.reportId, function()
			-- Remove this report from the list (r, pas report : shadowing = comparaison toujours vraie)
			for i, r in ipairs(reportsToValidate) do
				if r.reportId == report.reportId then
					table.remove(reportsToValidate, i)
					break
				end
			end
			contentPanel:GetParent():GetParent():SwitchToCategory(4)
		end)
	end
end

function PANEL:CreateCategory1UI()
	local width, height = self.contentPanel:GetSize()

	-- Métriques du texte, PARTAGÉES par la pagination et le rendu (sinon les deux dérivent).
	-- ⚠ x / y / gap se donnent en unités DESIGN : gRespDrawMultilineText les convertit
	-- LUI-MÊME (draw à gRespX(x), gRespY(currentY)). On passait des valeurs déjà gResp'ées
	-- -> double conversion, donc un interligne qui grossissait avec la résolution (×1,78 en
	-- 1440p, ×4 en 4K) et un texte qui finissait par recouvrir le bouton « Éditer ».
	-- Invisible en 1920x1080 (facteur 1), d'où le « parfois » du report user.
	local sReglFont  = "Ubuntu Mono:" .. tostring(gRespFont(16))
	local nReglGap   = 14                  -- interligne, unités DESIGN
	local nReglWidth = width - gRespX(35)  -- largeur de wrap, en PIXELS (mesure surface)
	-- Lignes tenant AU-DESSUS du bouton « Éditer » (posé à height - gRespY(75)), repère
	-- local du panneau de texte (qui commence à gRespY(130)). Calculé pour TOUT LE MONDE,
	-- même sans le bouton : les pages doivent se couper au même endroit pour tous.
	local nReglLines = math.max(4, math.floor(
		((height - gRespY(75)) - gRespY(130) - gRespY(10)) / math.max(1, gRespY(nReglGap))))

	-- Pages : règlement ÉDITABLE de la faction (chef grade 16) s'il existe, sinon le règlement
	-- RP statique par défaut. Paginé pour tenir dans le livre.
	local pages = (factionReglement and factionReglement ~= "")
		and PaginateReglement(factionReglement, sReglFont, nReglWidth, nReglLines)
		or LZY_FACTION_CONFIG.rules
	self._reglPages = pages
	local totalPages = #pages
	-- Initialize page tracking (clamp : le nombre de pages peut avoir changé après une édition)
	self.currentRulePage = math.Clamp(self.currentRulePage or 1, 1, math.max(1, totalPages))

	-- Header
	local header = vgui.Create("DPanel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(130))
	header:SetPos(gRespX(0), gRespY(0))
	header.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		RNDX.DrawMaterial(0, gRespX(290), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(269), gRespY(28), Color(255, 255, 255, 255), materials.reglement_text)
		RNDX.DrawMaterial(0, gRespX(140), gRespY(70), gRespX(338), gRespY(62), Color(255, 255, 255, 255), materials.horizontal_line)
	end

	-- Bouton ÉDITER (chef de faction grade 16 = grade max, OU SuperAdmin) : ouvre l'éditeur.
	local lpEdit = LocalPlayer()
	local nMaxRankEdit = #(LZY_FACTION_CONFIG.factions[lpEdit:GetEvoNWString("FactionName")] or {})
	if lpEdit:IsSuperAdmin() or (nMaxRankEdit > 1 and lpEdit:GetEvoNWInt("FactionRank", 0) >= nMaxRankEdit) then
		local editBtn = vgui.Create("DButton", self.contentPanel)
		editBtn:SetSize(gRespX(128), gRespY(25))
		-- Juste AU-DESSUS du bouton « page suivante » (à height - gRespY(45)), aligné à droite (demande user).
		editBtn:SetPos(width - gRespX(153), height - gRespY(75))
		editBtn:SetText("")
		editBtn.Paint = function(s, w, h)
			draw.RoundedBox(gRespX(4), 0, 0, w, h, s:IsHovered() and Color(150, 45, 50, 255) or Color(90, 28, 30, 235))
			draw.SimpleText("Éditer", "Ubuntu Mono:" .. tostring(gRespFont(15)), w / 2, h / 2, Color(240, 228, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		editBtn.DoClick = OpenReglementEditor
	end

	-- Content
	local contentPanel = vgui.Create("DPanel", self.contentPanel)
	contentPanel:SetSize(gRespX(450), height - gRespY(135)) -- Reduced height to make room for navigation
	contentPanel:SetPos(gRespX(0), gRespY(130))
	-- Panneau d'AFFICHAGE du texte seulement : il ne doit PAS capter la souris, sinon il recouvre
	-- le bouton « Éditer » (créé avant lui) qui devient visible mais NON cliquable (fix user).
	contentPanel:SetMouseInputEnabled(false)
	local mainPanel = self -- Store reference to main panel
	contentPanel.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		local currentRules = mainPanel._reglPages[mainPanel.currentRulePage]
		if currentRules then
			-- Mêmes métriques que la pagination (nReglLines = ce qui tient au-dessus du
			-- bouton « Éditer ») : une page ne peut donc plus déborder dessus.
			gRespDrawMultilineText(currentRules, sReglFont, 25, 0, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, nReglGap, nReglWidth, nReglLines)
		end
	end

	-- Navigation buttons (only show if there are multiple pages)
	if totalPages > 1 then
		-- Page indicator (create this first so it's in scope)
		local pageLabel = vgui.Create("DLabel", self.contentPanel)
		pageLabel:SetSize(gRespX(200), gRespY(25))
		pageLabel:SetPos(width/2 - gRespX(100), height - gRespY(45))
		-- Font responsive : DermaDefault etait fige a 13px -> illisible sur 4K
		pageLabel:SetFont("Ubuntu Mono:" .. tostring(gRespFont(14)))
		pageLabel:SetTextColor(Color(0, 0, 0, 255))
		pageLabel:SetText(string.format("Page %d sur %d", self.currentRulePage, totalPages))
		pageLabel:SetContentAlignment(5) -- Center align

		-- Create both buttons first
		local prevButton = vgui.Create("lzy_faction_button", self.contentPanel)
		prevButton:SetSize(gRespX(128), gRespY(25))
		prevButton:SetPos(gRespX(25), height - gRespY(45))
		prevButton:SetMaterials(materials.page_precedente, nil)
		prevButton:SetTextSize(gRespX(128), gRespY(25))
		prevButton:SetIconSize(gRespX(0), gRespY(0))
		prevButton:SetButtonSize(gRespX(128), gRespY(25))
		prevButton:SetUnderlineHover(true)

		local nextButton = vgui.Create("lzy_faction_button", self.contentPanel)
		nextButton:SetSize(gRespX(128), gRespY(25))
		nextButton:SetPos(width - gRespX(153), height - gRespY(45))
		nextButton:SetMaterials(materials.page_suivante, nil)
		nextButton:SetTextSize(gRespX(128), gRespY(25))
		nextButton:SetIconSize(gRespX(0), gRespY(0))
		nextButton:SetButtonSize(gRespX(128), gRespY(25))
		nextButton:SetUnderlineHover(true)

		-- Add Think function to manage button states
		prevButton.Think = function(self)
			self:SetEnabled(mainPanel.currentRulePage > 1)
		end

		nextButton.Think = function(self)
			self:SetEnabled(mainPanel.currentRulePage < totalPages)
		end

		-- Now set up the click handlers after both buttons exist
		prevButton.DoClick = function()
			if mainPanel.currentRulePage > 1 then
				mainPanel.currentRulePage = mainPanel.currentRulePage - 1
				-- Refresh the content panel and update page label
				contentPanel:InvalidateLayout()
				contentPanel:InvalidateParent()
				pageLabel:SetText(string.format("Page %d sur %d", mainPanel.currentRulePage, totalPages))
			end
		end

		nextButton.DoClick = function()
			if mainPanel.currentRulePage < totalPages then
				mainPanel.currentRulePage = mainPanel.currentRulePage + 1
				-- Refresh the content panel and update page label
				contentPanel:InvalidateLayout()
				contentPanel:InvalidateParent()
				pageLabel:SetText(string.format("Page %d sur %d", mainPanel.currentRulePage, totalPages))
			end
		end
	end
end

function PANEL:CreateCategory2UI()
	local width, height = self.contentPanel:GetSize()

	-- Header
	local header = vgui.Create("DLabel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(150))
	header:SetPos(gRespX(0), gRespY(0))
	header:SetText("")
	header.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(239), gRespY(72), Color(255, 255, 255, 255), materials.rapport_text)
		RNDX.DrawMaterial(0, gRespX(14), gRespY(92), gRespX(339), gRespY(79), Color(255, 255, 255, 255), materials.rapport_horizontal_line)
	end

	-- Content
	local contentPanel = vgui.Create("DPanel", self.contentPanel)
	contentPanel:SetSize(gRespX(450), height - gRespY(150))
	contentPanel:SetPos(gRespX(0), gRespY(150))
	local mainPanel = self -- Store reference to main panel
	contentPanel.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		-- Horizontal line above envoyer_rapport button
		RNDX.Draw(8, gRespX(25), h - gRespY(60), w - gRespX(50), 2, Color(0, 0, 0, 255))

		local lp = LocalPlayer()
		local rpName = lp:GetEvoNWString("Nickname", "")
		if rpName == "" then rpName = lp:Nick() end

		draw.SimpleText("Nom : " .. rpName, "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(25), gRespY(20), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Grade : " .. LZY_FACTION_CONFIG.RankName(LocalPlayer(), LocalPlayer():GetEvoNWInt("FactionRank")), "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(25), gRespY(40), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Date : " .. os.date("%d/%m/%Y"), "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(25), gRespY(60), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(LZY_FACTION_CONFIG.DivisionName(LocalPlayer(), LocalPlayer():GetEvoNWInt("FactionDivision")), "Ubuntu Mono:" .. tostring(gRespFont(20)), gRespX(25), gRespY(80), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	-- Custom selectbox in top right of contentPanel.
	-- Taille et police AGRANDIES (demande user : texte illisible en font 13). La contrainte
	-- est la mission la plus longue, "Guerre / Affrontement" (21 car.) : en Ubuntu Mono
	-- l'avance vaut ~0,5 x la taille, donc 21 x 8 = ~168 px en font 16. Le Paint reserve
	-- 10 px de marge gauche et ~17 px pour la fleche a droite -> il faut >= 195 de large,
	-- d'ou 200 a x=245 (bord droit 445 < 450, le panneau). La largeur du DROPDOWN est en
	-- plus bornee au bord du panneau (cf. cl_selectbox.UpdateDropdownHeight) : responsive,
	-- il ne sort jamais du menu.
	local selectbox = vgui.Create("lzy_faction_selectbox", contentPanel)
	selectbox:cSetSize(200, 26)
	-- y=70 et non 35 (demande user) : la ligne "Grade : ..." est dessinee a y40 et les
	-- libelles longs ("Shinigami de troisieme classe" = 29 car. en Ubuntu Mono 20) courent
	-- jusqu'a x~395, donc en plein dans la selectbox qui occupait y35-57. A y70 elle passe
	-- sous cette ligne ; les suivantes sont courtes et ne l'atteignent pas (Date ~x195,
	-- Division ~x135 au plus long, "Division 12").
	selectbox:gSetPosU(245, 70)
	selectbox:SetMaterials(materials.selectbox_bg, materials.selectbox_bg)
	selectbox:SetTextColor(Color(255, 255, 255))
	selectbox:SetFont("Ubuntu Mono:" .. tostring(gRespFont(16)))
	selectbox:SetOptions(LZY_FACTION_CONFIG.missions)
	selectbox.OnValueChanged = function(panel, value, text)
	end

	-- ── Preuve jointe (capture d'écran OU image de data/evo_preuves) ─────────────
	-- Zone x25-245 / y103-205 : libre (l'en-tête texte s'arrête à y~100, le textArea
	-- démarre à y250, et le dropdown des missions ne couvre que x245+).
	local attachedData, attachedMat = nil, nil
	local bUploading = false
	local sAttachStatus = ""

	local function attachBtn(x, y, w, sLabel, fClick)
		local b = vgui.Create("DButton", contentPanel)
		b:SetSize(gRespX(w), gRespY(20))
		b:SetPos(gRespX(x), gRespY(y))
		b:SetText("")
		b.DoClick = function() fClick() end
		b.Paint = function(s, bw, bh)
			draw.RoundedBox(4, 0, 0, bw, bh, s:IsHovered() and Color(75, 57, 29, 220) or Color(75, 57, 29, 160))
			draw.SimpleText(sLabel, "Ubuntu Mono:" .. tostring(gRespFont(14)), bw / 2, bh / 2, Color(255, 248, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return b
	end

	-- Racine du menu faction (à masquer pendant la capture : la preuve doit montrer le JEU).
	local function menuRoot()
		local p = mainPanel
		while IsValid(p:GetParent()) and p:GetParent() ~= vgui.GetWorldPanel() do p = p:GetParent() end
		return p
	end

	attachBtn(25, 104, 210, "[+] Capture d'écran", function()
		if bUploading or not LZYF_ReportImage then return end
		LZYF_ReportImage.Capture({ menuRoot() }, function(sData, sErr, mat)
			if not sData then
				sAttachStatus = sErr or "Capture impossible."
				return
			end
			attachedData, attachedMat = sData, mat
			sAttachStatus = "Capture jointe (" .. math.floor(#sData / 1024) .. " Ko)"
		end)
	end)

	attachBtn(25, 127, 210, "[+] Image du dossier", function()
		if bUploading or not LZYF_ReportImage then return end
		local tImgs = LZYF_ReportImage.ListFolder()
		if #tImgs == 0 then
			sAttachStatus = "Dépose une image dans garrysmod/data/" .. LZYF_ReportImage.FolderDir() .. "/"
			return
		end
		-- Petit sélecteur : nom + taille, clic = joindre.
		local f = vgui.Create("DFrame")
		f:SetSize(gRespX(340), gRespY(60) + math.min(#tImgs, 10) * gRespY(24))
		f:Center() f:SetTitle("Choisir une image (data/evo_preuves)") f:MakePopup()
		local sc = vgui.Create("DScrollPanel", f)
		sc:Dock(FILL)
		for _, tImg in ipairs(tImgs) do
			local row = vgui.Create("DButton", sc)
			row:Dock(TOP) row:DockMargin(2, 0, 2, 2) row:SetTall(gRespY(22))
			row:SetText("  " .. tImg.name .. "  (" .. math.floor((tImg.size or 0) / 1024) .. " Ko)")
			row:SetContentAlignment(4)
			row.DoClick = function()
				LZYF_ReportImage.ReadFolderImage(tImg.name, function(sData, sErr, mat)
					if not sData then sAttachStatus = sErr or "Image illisible." f:Close() return end
					attachedData, attachedMat = sData, mat
					sAttachStatus = "Image jointe : " .. tImg.name
					f:Close()
				end)
			end
		end
	end)

	-- Aperçu + statut + retrait. Le panneau d'aperçu clique = retirer la pièce jointe.
	local preview = vgui.Create("DButton", contentPanel)
	preview:SetSize(gRespX(96), gRespY(54))
	preview:SetPos(gRespX(25), gRespY(151))
	preview:SetText("")
	preview:SetTooltip("Cliquer pour retirer la preuve jointe")
	preview.DoClick = function()
		attachedData, attachedMat = nil, nil
		sAttachStatus = ""
	end
	preview.Paint = function(s, w, h)
		if not attachedMat then return end
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(attachedMat)
		surface.DrawTexturedRect(0, 0, w, h)
		if s:IsHovered() then
			draw.RoundedBox(0, 0, 0, w, h, Color(120, 30, 30, 120))
			draw.SimpleText("✕", "Ubuntu Mono:" .. tostring(gRespFont(22)), w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	local statusLbl = vgui.Create("DLabel", contentPanel)
	statusLbl:SetSize(gRespX(300), gRespY(54))
	statusLbl:SetPos(gRespX(127), gRespY(151))
	statusLbl:SetText("")
	statusLbl:SetFont("Ubuntu Mono:" .. tostring(gRespFont(13)))
	statusLbl:SetTextColor(Color(60, 40, 10))
	statusLbl.Think = function(s) s:SetText(sAttachStatus) end

	-- Custom text area
	-- DESCENDU (demande user) : la liste déroulante des missions couvrait le haut-droite de la
	-- zone d'écriture quand elle était ouverte. On démarre le textArea SOUS l'extension max du
	-- dropdown, hauteur ajustée pour garder le même bas (560). À redescendre si on ajoute une
	-- 7e mission. Le dropdown part du BAS de la selectbox : y70 + 26 = 96, plus 146 de liste
	-- (6 missions, cf. UpdateDropdownHeight : 24/entrée) = ~242, d'où y250 ici. Ce calcul suit
	-- la selectbox : la redescendre ou la grandir de N impose de redescendre le textArea de N.
	local textArea = vgui.Create("DTextEntry", contentPanel)
	textArea:SetSize(gRespX(400), gRespY(310))
	textArea:SetPos(gRespX(25), gRespY(250))
	textArea:SetMultiline(true)
	textArea:SetText("")
	textArea:SetPlaceholderText("Cliquez pour commencer à écrire...")
	textArea:SetDrawBackground(false)
	textArea:SetDrawBorder(false)
	textArea:SetFont("Ubuntu Mono:" .. tostring(gRespFont(20)))
	textArea:SetTextColor(Color(0, 0, 0, 255))
	textArea:SetPlaceholderColor(Color(0, 0, 0, 255))
	textArea:SetDrawLanguageID(false)

	-- Envoyer rapport button
	local envoyerRapportBtn = vgui.Create("lzy_faction_button", self.contentPanel)
	-- Bouton élargi (matériau 165 dans un bouton 195) -> image "Envoyer rapport" pleine, plus de crop.
	envoyerRapportBtn:SetSize(gRespX(195), gRespY(25))
	envoyerRapportBtn:SetPos((width - gRespX(195)) / 2, height - gRespY(45)) -- centré horizontalement, 45px du bas
	envoyerRapportBtn:SetMaterials(materials.envoyer_rapport, nil)
	envoyerRapportBtn:SetTextSize(gRespX(165), gRespY(25))
	envoyerRapportBtn:SetIconSize(gRespX(0), gRespY(0))
	envoyerRapportBtn:SetButtonSize(gRespX(195), gRespY(25))
	envoyerRapportBtn:SetUnderlineHover(true) -- Enable underline hover effect
	-- Envoi : si une preuve est jointe, elle est UPLOADÉE d'abord (chunks, cf.
	-- cl_report_images) puis le rapport part avec bWithImage=true — le serveur
	-- consomme alors la pending. Sans preuve : comportement historique.
	-- Mission + texte sont CAPTURÉS AU CLIC : l'upload prend 1-2 s, et si le joueur
	-- ferme le menu entre-temps, le callback lirait des panneaux DÉTRUITS (« Tried
	-- to use invalid object ») et le rapport serait perdu. Avec la copie, le rapport
	-- part même menu fermé ; seul le nettoyage d'UI est conditionné à IsValid.
	local function sendReport(sMission, sText, bWithImage)
		net.Start("server:lzy_faction.NewFactionReport")
		net.WriteString(sMission)
		net.WriteString(sText)
		net.WriteBool(bWithImage == true)
		net.SendToServer()
		MUGEN.AddNotification("Rapport envoyé!", NOTIFY_GENERIC, 5)
		if IsValid(textArea) then textArea:SetText("") end
		attachedData, attachedMat, sAttachStatus = nil, nil, ""
	end
	envoyerRapportBtn.DoClick = function()
		if bUploading then return end
		local sMission, sText = selectbox:GetSelectedValue(), textArea:GetText()
		if not attachedData then sendReport(sMission, sText, false) return end
		bUploading = true
		sAttachStatus = "Envoi de la preuve…"
		LZYF_ReportImage.Upload(attachedData, function(bOk, sMsg)
			bUploading = false
			if not bOk then
				sAttachStatus = sMsg or "Échec de l'envoi de l'image."
				MUGEN.AddNotification("[Rapport] " .. sAttachStatus, NOTIFY_ERROR, 5)
				return -- le rapport n'est PAS parti : le joueur peut réessayer ou retirer l'image
			end
			sendReport(sMission, sText, true)
		end)
	end
end

function PANEL:CreateCategory3UI()
	local width, height = self.contentPanel:GetSize()

	-- Header
	local header = vgui.Create("DLabel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(130))
	header:SetPos(gRespX(0), gRespY(0))
	header:SetText("")
	header.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		RNDX.DrawMaterial(0, gRespX(125), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(232), gRespY(28), Color(255, 255, 255, 255), materials.effectifs_text)
		RNDX.DrawMaterial(0, gRespX(140), gRespY(70), gRespX(338), gRespY(62), Color(255, 255, 255, 255), materials.horizontal_line)
	end

	-- Bouton BANQUE (addon evo_division_bank, GLOBALE par faction depuis le 08/02) : dans
	-- EFFECTIF -> visible par TOUS les membres de la faction (division ou pas). Le trésor + le
	-- classement des donateurs sont publics ; seul l'onglet "Distribuer" est réservé aux grades
	-- 15+ (gate snap.isManager côté UI, revalidé serveur). Bas-droite.
	-- Boutons d'accès Atelier (Banque / Classements) : rectangles à coin bas-droit
	-- coupé, Bebas SANS bold, alignés proprement bas-droite avec un vrai espacement
	-- (retour user 06/07 : « les rectangles, mets-les bien »).
	local function makeAccessBtn(x, label, fn)
		local b = vgui.Create("DButton", self.contentPanel)
		b:SetText("") b:SetSize(gRespX(180), gRespY(36)) b:SetPos(x, height - gRespY(50))
		b:SetZPos(50) b:SetCursor("hand")
		b.Paint = function(s, w, h)
			local hov = s:IsHovered()
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230), gRespY(9), "br")
			else
				RNDX.Draw(0, 0, 0, w, h, hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230))
			end
			draw.SimpleText(label, "Bebas Neue:20", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
		return b
	end

	local hasBank = EVO_DIVBANK and EVO_DIVBANK.Open and EVO_DIVBANK.GetPlayerFaction and EVO_DIVBANK.GetPlayerFaction(LocalPlayer())
	if hasBank then
		makeAccessBtn(width - gRespX(194), "BANQUE", function() EVO_DIVBANK.Open() end)
	end
	if EVO_INSTRUCTEUR and EVO_INSTRUCTEUR.OpenClassement then
		local cx = hasBank and (width - gRespX(194 + 180 + 14)) or (width - gRespX(194))
		makeAccessBtn(cx, "CLASSEMENTS", function() EVO_INSTRUCTEUR.OpenClassement() end)
	end

	-- Content : laisse R(50) en bas pour BANQUE / CLASSEMENTS (sinon la liste passe dessous).
	local contentPanel = vgui.Create("DPanel", self.contentPanel)
	contentPanel:SetSize(gRespX(450), height - gRespY(135) - gRespY(50))
	contentPanel:SetPos(gRespX(0), gRespY(130))
	local mainPanel = self -- Store reference to main panel
	contentPanel.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
	end

	-- Create search bar for player list
	local searchBar = vgui.Create("DTextEntry", contentPanel)
	searchBar:SetSize(gRespX(150), gRespY(25))
	searchBar:SetPos(gRespX(430 - 152), gRespY(10))
	searchBar:SetText("")
	searchBar:SetFont("Ubuntu Mono:" .. tostring(gRespFont(20)))
	searchBar:SetPlaceholderText("Rechercher par nom...")
	searchBar:SetDrawBackground(false)
	searchBar:SetDrawBorder(false)
	searchBar:SetTextColor(Color(0, 0, 0, 255))
	searchBar:SetPlaceholderColor(Color(100, 100, 100, 255))
	searchBar:SetDrawLanguageID(false)

	-- Custom paint function for search bar with black border
	searchBar.Paint = function(self, w, h)
		-- Draw black border
		RNDX.DrawOutlined(6, gRespX(0), gRespY(0), w, h, Color(0, 0, 0), 1)

		-- Draw text
		if self:GetText() == "" and not self:IsEditing() then
			-- Draw placeholder text
			draw.SimpleText(self:GetPlaceholderText(), "Ubuntu Mono:" .. tostring(gRespFont(14)), gRespX(5), h/2, Color(100, 100, 100, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			-- Draw actual text
			draw.SimpleText(self:GetText(), "Ubuntu Mono:" .. tostring(gRespFont(14)), gRespX(5), h/2, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	-- Scroll viewport (même schéma que l'inventaire) : zone visible fixe sous la
	-- search bar ; le conteneur interne grandit avec les effectifs -> scrollbar.
	local listX, listY = gRespX(20), gRespY(42)
	local listW = gRespX(420)
	local listH = math.max(gRespY(120), contentPanel:GetTall() - listY)

	local function RequestDivisionEffectifs(divIdx)
		if not divIdx then return end
		net.Start("server:lzy_faction.GetDivisionEffectifs")
		net.WriteUInt(math.Clamp(tonumber(divIdx) or 1, 0, 255), 8)
		net.SendToServer()
	end

	local function OnDivisionToggle(item, expanded)
		local divIdx = item and item.division
		if not divIdx then return end
		for _, d in ipairs(playersListByDivision) do
			if d.division == divIdx then
				d.expanded = expanded and true or false
				if expanded and not d.loaded then
					RequestDivisionEffectifs(divIdx)
				end
				break
			end
		end
	end

	local collapsibleList = CreateCollapsibleList(contentPanel, listX, listY, listW, listH, playersListByDivision, materials.collapse_bg, OnDivisionToggle)

	-- Function to filter and recreate player list
	local function UpdatePlayerList()
		if not IsValid(collapsibleList) then return end
		local searchText = string.lower(searchBar:GetText())
		local source = effectifsSearchResults or playersListByDivision
		local filteredPlayersList = {}

		-- Filter players based on search text
		for _, division in ipairs(source) do
			local filteredDivision = {
				title = division.title,
				expanded = division.expanded,
				connectedPlayers = division.connectedPlayers,
				division = division.division,
				loaded = division.loaded,
				rows = {}
			}

			-- Filter rows in this division
			for _, row in ipairs(division.rows or {}) do
				if searchText == "" or effectifsSearchResults or string.find(string.lower(row.text or ""), searchText, 1, true) then
					table.insert(filteredDivision.rows, row)
				end
			end

			-- Only add division if it has matching players or if search is empty
			if searchText == "" or #filteredDivision.rows > 0 then
				-- Update connected players count for filtered results
				local connectedCount = 0
				for _, row in ipairs(filteredDivision.rows) do
					if row.isConnected then
						connectedCount = connectedCount + 1
					end
				end
				filteredDivision.connectedPlayers = connectedCount .. "/" .. #filteredDivision.rows
				table.insert(filteredPlayersList, filteredDivision)
			end
		end

		-- Update the collapsible list with filtered data
		collapsibleList:SetItems(filteredPlayersList)
	end

	-- Recherche : 0-1 char = filtre local (divisions déjà chargées). 2+ = serveur.
	searchBar.OnTextChanged = function()
		timer.Create("lzy_faction_eff_search", 0.25, 1, function()
			if not IsValid(searchBar) then return end
			local q = string.Trim(searchBar:GetText() or "")
			if #q < 2 then
				effectifsSearchPending = ""
				effectifsSearchResults = nil
				UpdatePlayerList()
				return
			end
			effectifsSearchPending = string.lower(q)
			net.Start("server:lzy_faction.SearchEffectifs")
			net.WriteString(string.sub(q, 1, 32))
			net.SendToServer()
		end)
	end

	-- Initialize the player list
	UpdatePlayerList()

	mainPanel.UpdateEffectifsList = UpdatePlayerList

	-- Divisions déjà marquées expanded (fakes / restore) : charger les membres.
	for _, d in ipairs(playersListByDivision) do
		if d.expanded and not d.loaded then
			RequestDivisionEffectifs(d.division)
		end
	end
end

-- Barre de défilement des listes de rapports (même habillage que la liste « à valider »).
local function StyleReportScrollBar(scrollPanel)
	local scrollBar = scrollPanel:GetVBar()
	scrollBar:SetWide(gRespX(8))
	scrollBar.Paint = function(self, w, h)
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 100))
	end
	scrollBar.btnUp.Paint = function() end
	scrollBar.btnDown.Paint = function() end
	scrollBar.btnGrip.Paint = function(self, w, h)
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, self:IsHovered() and 250 or 200))
	end
end

function PANEL:CreateCategory4UI()
	local width, height = self.contentPanel:GetSize()
	self._archiveView = false

	-- Header
	local header = vgui.Create("DLabel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(150))
	header:SetPos(gRespX(0), gRespY(0))
	header:SetText("")
	header.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		RNDX.DrawMaterial(0, gRespX(290), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(110), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(160), gRespY(40), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(281), gRespY(71), Color(255, 255, 255, 255), materials.rapport_a_valider_text)
		RNDX.DrawMaterial(0, gRespX(14), gRespY(92), gRespX(339), gRespY(79), Color(255, 255, 255, 255), materials.rapport_horizontal_line)
	end

	-- Content
	self.fullReportContentPanel = vgui.Create("DPanel", self.contentPanel)
	self.fullReportContentPanel:SetSize(gRespX(450), height - gRespY(150))
	self.fullReportContentPanel:SetPos(gRespX(0), gRespY(150))
	local mainPanel = self -- Store reference to main panel
	self.fullReportContentPanel.Paint = function(self, w, h)
		draw.SimpleText(#reportsToValidate .. " rapports", "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(420), gRespY(13), Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	if LocalPlayer():IsSuperAdmin() then
		local clearBtn = vgui.Create("lzy_faction_button", self.fullReportContentPanel)
		clearBtn:SetSize(gRespX(160), gRespY(25))
		clearBtn:SetPos(gRespX(10), gRespY(5))
		clearBtn:SetMaterials(nil, nil)
		clearBtn:SetTextSize(gRespX(160), gRespY(25))
		clearBtn:SetIconSize(gRespX(0), gRespY(0))
		clearBtn:SetButtonSize(gRespX(160), gRespY(25))
		clearBtn:SetUnderlineHover(true)
		clearBtn:SetText("Archiver tout")
		clearBtn:SetTextColor(Color(140, 0, 0, 255))
		clearBtn:SetFont("Ubuntu Mono:" .. tostring(gRespFont(14)))
		clearBtn.DoClick = function()
			LocalPlayer():OpenYesNoPopup(
				"Archiver tous les rapports actifs ? Ils resteront en base mais n'apparaîtront plus dans le menu.",
				"FactionClearReports"
			)
		end
	end

	-- Accès aux ARCHIVES (rapports déjà validés / refusés). Décalé à droite du bouton
	-- SuperAdmin « Archiver tout » quand il est présent.
	local archiveBtn = vgui.Create("lzy_faction_button", self.fullReportContentPanel)
	archiveBtn:SetSize(gRespX(130), gRespY(25))
	archiveBtn:SetPos(LocalPlayer():IsSuperAdmin() and gRespX(175) or gRespX(10), gRespY(5))
	archiveBtn:SetMaterials(nil, nil)
	archiveBtn:SetTextSize(gRespX(130), gRespY(25))
	archiveBtn:SetIconSize(gRespX(0), gRespY(0))
	archiveBtn:SetButtonSize(gRespX(130), gRespY(25))
	archiveBtn:SetUnderlineHover(true)
	archiveBtn:SetText("Archives →")
	archiveBtn:SetTextColor(Color(0, 0, 0, 255))
	archiveBtn:SetFont("Ubuntu Mono:" .. tostring(gRespFont(14)))
	archiveBtn.DoClick = function()
		-- Affiche tout de suite (liste en cache) et rafraîchit à la réception serveur.
		net.Start("server:lzy_faction.GetArchivedReports")
		net.SendToServer()
		self:CreateArchiveUI()
	end

	-- Create scrollable list for reports to validate
	local scrollPanel = vgui.Create("DScrollPanel", self.fullReportContentPanel)
	scrollPanel:SetSize(gRespX(430), height - gRespY(200)) -- Leave some margin
	scrollPanel:SetPos(gRespX(10), gRespY(30))

	-- Custom scroll bar
	local scrollBar = scrollPanel:GetVBar()
	scrollBar:SetWide(gRespX(8)) -- Make scroll bar thinner

	-- Custom scroll bar appearance
	scrollBar.Paint = function(self, w, h)
		-- Background of scroll bar track
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 100))
	end

	-- Custom scroll bar button (the draggable part)
	scrollBar.btnUp.Paint = function(self, w, h)
		-- Top button (usually hidden, but we'll style it)
		--draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100, 150))
	end

	scrollBar.btnDown.Paint = function(self, w, h)
		-- Bottom button (usually hidden, but we'll style it)
		--draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100, 150))
	end

	-- Custom scroll bar grip (the draggable part)
	scrollBar.btnGrip.Paint = function(self, w, h)
		-- Main scroll bar grip
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 200))

		-- Hover effect
		if self:IsHovered() then
			draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 250))
		end
	end

	local function paintReport(w, h, report, hovered)
		-- Borders
		RNDX.DrawOutlined(gRespX(0), gRespX(0), gRespY(0), w, h - gRespY(25), Color(0, 0, 0), 1)

		-- Vertical line to separate left and right side
		RNDX.Draw(gRespX(0), gRespX(130), gRespY(0), 1, h - gRespY(25), Color(0, 0, 0), 1)

		if hovered then
			RNDX.Draw(gRespX(0), gRespX(0), gRespY(0), w, h - gRespY(25), Color(75, 57, 29, 100), 1)
		end

		-- Left Side
		draw.SimpleText(report.author, "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(10), gRespY(18), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(report.rank, "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(10), gRespY(38), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(LZY_FACTION_CONFIG.DivisionName(LocalPlayer(), report.division), "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(10), gRespY(58), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Right Side : catégorie (mission) puis aperçu du contenu
		local sMission = report.mission or ""
		local yPreview = gRespY(8)
		if sMission ~= "" then
			draw.SimpleText(sMission, "Ubuntu Mono:" .. tostring(gRespFont(15)), gRespX(140), gRespY(6), Color(75, 57, 29, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			yPreview = gRespY(26)
		end
		gRespDrawMultilineText(report.contentPreview, "Ubuntu Mono:" .. tostring(gRespFont(16)), 140, yPreview, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, gRespY(15), gRespX(250), sMission ~= "" and 3 or 4)

		-- Bottom line
		RNDX.Draw(gRespX(0), h - gRespY(25), gRespX(0), w, 1, Color(0, 0, 0), 1)
	end

	-- Create report items
	for i, report in ipairs(reportsToValidate) do
		local reportPanel = vgui.Create("DPanel", scrollPanel)
		reportPanel:SetSize(gRespX(410), gRespY(105))
		reportPanel:SetPos(gRespX(0), (i-1) * gRespY(115))

		-- Hover effect
		reportPanel.Think = function(self)
			if self:IsHovered() then
				self.hovered = true
				self:SetCursor("hand") -- Set cursor to pointer when hovering
			else
				self.hovered = false
				self:SetCursor("arrow") -- Reset cursor when not hovering
			end
		end

		reportPanel.Paint = function(self, w, h)
			paintReport(w, h, report, self.hovered)
		end

		-- Make the panel clickable
		reportPanel.OnMousePressed = function(self, mouseCode)
			if mouseCode == MOUSE_LEFT then
				-- Request full report from server
				net.Start("server:lzy_faction.GetFullReport")
				net.WriteUInt(report.reportId, 32)
				net.SendToServer()
			end
		end

		-- Boutons Valider/Refuser dans la bande basse (le panneau fait 410×105, bande = y80..105).
		-- Largeur bouton > matériau -> image pleine (plus de "crop"). Positions gRespX (responsive) :
		-- Refuser à GAUCHE, Valider à DROITE, dans les 410px (avant : reject à x=-12 hors panneau,
		-- validate qui débordait à droite).
		local validateBtn = vgui.Create("lzy_faction_button", reportPanel)
		validateBtn:SetSize(gRespX(187), gRespY(25))
		validateBtn:SetPos(gRespX(215), gRespY(80)) -- droite : 410 - 187 - 8
		validateBtn:SetMaterials(materials.valider_le_rapport, nil)
		validateBtn:SetTextSize(gRespX(157), gRespY(25))
		validateBtn:SetIconSize(gRespX(0), gRespY(0))
		validateBtn:SetButtonSize(gRespX(187), gRespY(25))
		validateBtn:SetUnderlineHover(true)
		validateBtn.DoClick = function()
			net.Start("server:lzy_faction.ValidateReport")
			net.WriteUInt(report.reportId, 32)
			net.SendToServer()
			-- Remove this report from the list
			for i, report in ipairs(reportsToValidate) do
				if report.reportId == report.reportId then
					table.remove(reportsToValidate, i)
					break
				end
			end
			reportPanel:Remove()
		end

		local rejectBtn = vgui.Create("lzy_faction_button", reportPanel)
		rejectBtn:SetSize(gRespX(192), gRespY(25))
		rejectBtn:SetPos(gRespX(8), gRespY(80)) -- gauche
		rejectBtn:SetMaterials(materials.refuser_le_rapport, nil)
		rejectBtn:SetTextSize(gRespX(162), gRespY(25))
		rejectBtn:SetIconSize(gRespX(0), gRespY(0))
		rejectBtn:SetButtonSize(gRespX(192), gRespY(25))
		rejectBtn:SetUnderlineHover(true)
		rejectBtn.DoClick = function()
			-- Raison obligatoire : le net part depuis le popup, une fois la raison saisie.
			OpenRejectReasonPopup(report.reportId, function()
				-- Remove this report from the list (r, pas report : shadowing = comparaison toujours vraie)
				for i, r in ipairs(reportsToValidate) do
					if r.reportId == report.reportId then
						table.remove(reportsToValidate, i)
						break
					end
				end
				if IsValid(reportPanel) then reportPanel:Remove() end
			end)
		end

	end
end

-- ARCHIVES (demande user 2026-07-31) : historique des rapports déjà traités (validés /
-- refusés) de la division. Se substitue à la liste « à valider » DANS le même panneau
-- (self.fullReportContentPanel) -> l'en-tête du livre et l'onglet restent identiques,
-- « ← Retour » reconstruit la catégorie 4. Lecture seule : cliquer un rapport ouvre le
-- détail sans les boutons Valider/Refuser (le serveur refuse de re-traiter, cf. net.lua).
function PANEL:CreateArchiveUI()
	local panel = self.fullReportContentPanel
	if not IsValid(panel) then return end
	self._archiveView = true

	panel:Clear()
	local _, height = panel:GetSize()
	panel.Paint = function(self, w, h)
		draw.SimpleText(#archivedReports .. " rapports", "Ubuntu Mono:" .. tostring(gRespFont(16)), gRespX(420), gRespY(13), Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		if #archivedReports == 0 then
			draw.SimpleText("Aucun rapport traité pour le moment.", "Ubuntu Mono:" .. tostring(gRespFont(18)), w / 2, gRespY(120), Color(0, 0, 0, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	local backBtn = vgui.Create("lzy_faction_button", panel)
	backBtn:SetSize(gRespX(130), gRespY(25))
	backBtn:SetPos(gRespX(10), gRespY(5))
	backBtn:SetMaterials(nil, nil)
	backBtn:SetTextSize(gRespX(130), gRespY(25))
	backBtn:SetIconSize(gRespX(0), gRespY(0))
	backBtn:SetButtonSize(gRespX(130), gRespY(25))
	backBtn:SetUnderlineHover(true)
	backBtn:SetText("← À valider")
	backBtn:SetTextColor(Color(0, 0, 0, 255))
	backBtn:SetFont("Ubuntu Mono:" .. tostring(gRespFont(14)))
	backBtn.DoClick = function()
		self:SwitchToCategory(4)
	end

	local scrollPanel = vgui.Create("DScrollPanel", panel)
	scrollPanel:SetSize(gRespX(430), height - gRespY(40))
	scrollPanel:SetPos(gRespX(10), gRespY(30))
	StyleReportScrollBar(scrollPanel)

	local function paintArchivedReport(w, h, report, hovered)
		RNDX.DrawOutlined(gRespX(0), gRespX(0), gRespY(0), w, h, Color(0, 0, 0), 1)
		RNDX.Draw(gRespX(0), gRespX(130), gRespY(0), 1, h, Color(0, 0, 0), 1)
		if hovered then
			RNDX.Draw(gRespX(0), gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 100), 1)
		end

		local bValidated = report.status == "validated"
		local fMain = "Ubuntu Mono:" .. tostring(gRespFont(16))
		local fSmall = "Ubuntu Mono:" .. tostring(gRespFont(14))
		local colStatus = bValidated and Color(30, 110, 55) or Color(150, 30, 35)

		-- Left Side
		draw.SimpleText(report.author, fMain, gRespX(10), gRespY(16), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(report.rank, fMain, gRespX(10), gRespY(34), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(LZY_FACTION_CONFIG.DivisionName(LocalPlayer(), report.division), fMain, gRespX(10), gRespY(52), Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(report.date or "", fSmall, gRespX(10), gRespY(74), Color(90, 90, 90, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Right Side
		-- gRespDrawMultilineText applique déjà gRespX/gRespY : passer des unités design
		-- (140, 8, 15), pas gRespX(140) — sinon double-scale et le texte chevauche la barre.
		gRespDrawMultilineText(report.contentPreview, fMain, 140, 8, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, 15, gRespX(250), 3)
		draw.SimpleText(bValidated and "VALIDÉ" or "REFUSÉ", fSmall, w - gRespX(10), gRespY(74), colStatus, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		-- Motif tronqué ici (la ligne est étroite) ; le détail affiche le texte complet.
		local sReason = report.reject_reason or ""
		if not bValidated and sReason ~= "" then
			if string.len(sReason) > 34 then sReason = string.sub(sReason, 1, 34) .. "..." end
			draw.SimpleText("Motif : " .. sReason, fSmall, gRespX(140), gRespY(74), colStatus, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	for i, report in ipairs(archivedReports) do
		local reportPanel = vgui.Create("DPanel", scrollPanel)
		reportPanel:SetSize(gRespX(410), gRespY(90))
		reportPanel:SetPos(gRespX(0), (i - 1) * gRespY(100))

		reportPanel.Think = function(self)
			if self:IsHovered() then
				self.hovered = true
				self:SetCursor("hand")
			else
				self.hovered = false
				self:SetCursor("arrow")
			end
		end

		reportPanel.Paint = function(self, w, h)
			paintArchivedReport(w, h, report, self.hovered)
		end

		reportPanel.OnMousePressed = function(self, mouseCode)
			if mouseCode == MOUSE_LEFT then
				net.Start("server:lzy_faction.GetFullReport")
				net.WriteUInt(report.reportId, 32)
				net.SendToServer()
			end
		end
	end
end

-- Vue FORMATION (10/08) : formateurs whitelistés -> recruter un aspirant dans SA
-- division (grade 2). Liste construite client-side depuis les NW appearance : rien
-- du roster sensible (steamid64/playtime/niveau) n'est envoyé à un formateur.
function PANEL:CreateFormationUI()
	local height = select(2, self.contentPanel:GetSize())
	local lp     = LocalPlayer()

	-- Même en-tête peint que la gestion complète (repères visuels identiques).
	local header = vgui.Create("DLabel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(140))
	header:SetPos(gRespX(0), gRespY(0))
	header:SetText("")
	header.Paint = function(_, w, h)
		RNDX.DrawMaterial(0, gRespX(228), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(250), gRespY(45), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(150), gRespY(40), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(194), gRespY(72), Color(255, 255, 255, 255), materials.gestion_faction_text)
		RNDX.DrawMaterial(0, gRespX(130), gRespY(95), gRespX(338), gRespY(62), Color(255, 255, 255, 255), materials.horizontal_line)
	end

	local content = vgui.Create("DPanel", self.contentPanel)
	content:SetSize(gRespX(450), height - gRespY(140))
	content:SetPos(gRespX(0), gRespY(140))
	content.Paint = nil

	-- GESTION FORMATION aussi dans la vue RÉDUITE (user 08/24 « qu'importe le
	-- grade, si whitelist formateur ») : le bouton du registre n'existait que dans
	-- la vue complète (grade PromoteMinRank+), or les formateurs sous ce grade
	-- tombent ICI — ils ne le voyaient jamais. Même gate bCanSuivi que la vue
	-- complète, revalidée serveur (LZYF_CanSuivi). Posé AVANT les early returns
	-- (pas de division / pas d'aspirant) : le registre reste consultable.
	local bCanSuivi = lp:IsSuperAdmin()
		or lp:GetEvoNWBool("EVO_FactionFormateur", false)
		or (lp:GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.SuiviMinRank or 8))
	local nSuiviPad = 0
	if bCanSuivi then
		nSuiviPad = gRespY(46)
		local suiviBtn = vgui.Create("DButton", content)
		suiviBtn:SetText("") suiviBtn:SetSize(gRespX(400), gRespY(36))
		suiviBtn:SetPos(gRespX(25), content:GetTall() - gRespY(42))
		suiviBtn:SetZPos(50) suiviBtn:SetCursor("hand")
		suiviBtn.Paint = function(s, w, h)
			local hov = s:IsHovered()
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, hov and Color(52, 56, 66, 255) or Color(30, 32, 38, 235), gRespY(9), "br")
			else
				RNDX.Draw(0, 0, 0, w, h, hov and Color(52, 56, 66, 255) or Color(30, 32, 38, 235))
			end
			draw.SimpleText("GESTION FORMATION", "Bebas Neue:20", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		suiviBtn.DoClick = function()
			if LZY_Faction_OpenSuivi then LZY_Faction_OpenSuivi() end
		end
	end

	local nMyDiv = tonumber(lp:GetEvoNWInt("FactionDivision", 0)) or 0
	local sFac   = lp:GetEvoNWString("FactionName", "")

	local fTitle = "Ubuntu Mono:" .. tostring(gRespFont(17))
	local fBody  = "Ubuntu Mono:" .. tostring(gRespFont(15))

	-- Sans division soi-même, rien à proposer : on l'explique au lieu de cacher.
	if nMyDiv <= 1 then
		local lbl = vgui.Create("DLabel", content)
		lbl:SetSize(gRespX(400), gRespY(80))
		lbl:SetPos(gRespX(25), gRespY(30))
		lbl:SetFont(fBody)
		lbl:SetTextColor(Color(0, 0, 0, 255))
		lbl:SetWrap(true)
		lbl:SetText("Former un aspirant, c'est l'accueillir dans TA division : rejoins d'abord une division pour pouvoir former.")
		return
	end

	local sMyDivName = LZY_FACTION_CONFIG.DivisionName(lp, nMyDiv)

	local title = vgui.Create("DLabel", content)
	title:SetSize(gRespX(400), gRespY(40))
	title:SetPos(gRespX(25), gRespY(10))
	title:SetFont(fTitle)
	title:SetTextColor(Color(0, 0, 0, 255))
	title:SetWrap(true)
	title:SetText("Formation des aspirants  ·  tu recrutes dans " .. sMyDivName .. " (grade "
		.. LZY_FACTION_CONFIG.RankName(lp, LZY_FACTION_CONFIG.FormateurGrantRank or 2) .. ").")

	-- Aspirants EN LIGNE de ma faction : grade 1, sans division, ni larve/âme errante.
	-- (Un aspirant hors ligne se forme à sa reconnexion — la formation est un acte RP.)
	local tAspirants = {}
	for _, p in player.Iterator() do
		if p ~= lp and IsValid(p)
			and p:GetEvoNWString("FactionName", "") == sFac
			and (tonumber(p:GetEvoNWInt("FactionRank", 0)) or 0) == 1
			and (tonumber(p:GetEvoNWInt("FactionDivision", 0)) or 0) <= 1
			and not p:GetEvoNWBool("EVO_IsLarva", false)
			and not p:GetEvoNWBool("EVO_IsLostSoul", false) then
			tAspirants[#tAspirants + 1] = p
		end
	end

	if #tAspirants == 0 then
		local lbl = vgui.Create("DLabel", content)
		lbl:SetSize(gRespX(400), gRespY(60))
		lbl:SetPos(gRespX(25), gRespY(60))
		lbl:SetFont(fBody)
		lbl:SetTextColor(Color(90, 90, 90, 255))
		lbl:SetWrap(true)
		lbl:SetText("Aucun aspirant en ligne pour l'instant. (Rouvre l'onglet pour actualiser.)")
		return
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:SetSize(gRespX(400), height - gRespY(200) - nSuiviPad)
	scroll:SetPos(gRespX(25), gRespY(55))

	for i, p in ipairs(tAspirants) do
		-- Nom RP via le résolveur unique (respecte présentation + masque d'anonymat).
		local sName
		if EVO_GetRPDisplayName then
			sName = EVO_GetRPDisplayName(p)
		else
			sName = (p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname")) or p:Nick()
		end

		local row = vgui.Create("DPanel", scroll)
		row:SetSize(gRespX(400), gRespY(30))
		row:SetPos(0, (i - 1) * gRespY(35))
		row.Paint = function(_, w, h)
			draw.SimpleText(sName, fBody, gRespX(4), h / 2, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local btn = vgui.Create("DButton", row)
		btn:SetSize(gRespX(110), gRespY(24))
		btn:SetPos(gRespX(286), gRespY(3))
		btn:SetText("")
		btn.Paint = function(pnl, w, h)
			draw.RoundedBox(gRespX(4), 0, 0, w, h, pnl:IsHovered() and Color(207, 68, 78, 255) or Color(14, 14, 17, 235))
			draw.SimpleText("FORMER", fBody, w / 2, h / 2, Color(235, 236, 240, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = function()
			if not IsValid(p) then return end
			lp:OpenYesNoPopup(
				"Former " .. sName .. " dans " .. sMyDivName .. " (grade "
					.. LZY_FACTION_CONFIG.RankName(lp, LZY_FACTION_CONFIG.FormateurGrantRank or 2) .. ") ?",
				"FactionFormerAspirant",
				{ ent = p }
			)
		end
	end
end

function PANEL:CreateCategory5UI()
	-- Sous PromoteMinRank (= formateur whitelisté) : vue réduite uniquement.
	if not LocalPlayer():IsSuperAdmin()
		and LocalPlayer():GetEvoNWInt("FactionRank", 0) < (LZY_FACTION_CONFIG.PromoteMinRank or 10) then
		self:CreateFormationUI()
		return
	end

	-- Liste gestion : à la demande (plus poussée dans GetInitData — overflow + requête lourde).
	net.Start("server:lzy_faction.GetGestionList")
	net.SendToServer()

	local width, height = self.contentPanel:GetSize()

	-- Header
	local header = vgui.Create("DLabel", self.contentPanel)
	header:SetSize(gRespX(450), gRespY(140))
	header:SetPos(gRespX(0), gRespY(0))
	header:SetText("")
	header.Paint = function(self, w, h)
		--draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 40, 255))
		RNDX.DrawMaterial(0, gRespX(228), gRespY(0), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(250), gRespY(45), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(150), gRespY(40), gRespX(46), gRespY(46), Color(255, 255, 255, 255), materials.small_tache)
		RNDX.DrawMaterial(0, gRespX(0), gRespY(0), gRespX(83), gRespY(83), Color(255, 255, 255, 255), materials.tache)
		RNDX.DrawMaterial(0, gRespX(80), gRespY(27), gRespX(194), gRespY(72), Color(255, 255, 255, 255), materials.gestion_faction_text)
		RNDX.DrawMaterial(0, gRespX(130), gRespY(95), gRespX(338), gRespY(62), Color(255, 255, 255, 255), materials.horizontal_line)
	end

	-- (Le bouton "Banque de division" est désormais dans l'onglet EFFECTIF -> accessible à tous les membres.)

	-- Content
	local contentPanel = vgui.Create("DPanel", self.contentPanel)
	contentPanel:SetSize(gRespX(450), height - gRespY(140))
	contentPanel:SetPos(gRespX(0), gRespY(140))
	local mainPanel = self -- Store reference to main panel
	contentPanel.Paint = function(self, w, h)
		RNDX.DrawMaterial(0, gRespX(20), gRespY(0), gRespX(261), gRespY(26), Color(255, 255, 255, 255), materials.message_de_division)
		RNDX.Draw(gRespX(8), gRespX(75), gRespY(200), gRespX(300), 1, Color(0, 0, 0, 255))
	end

	-- GROS tooltip de prérequis de grade (le SetTooltip natif est minuscule -> "on voit rien").
	-- Données posées par OnCursorEntered des noms de membres (cf. _reqTip). Dessiné ici en PaintOver
	-- (au-dessus de tout, non clippé par le scroll). Multi-lignes, gros texte, couleur par critère.
	contentPanel.PaintOver = function(self, w, h)
		local tip = self._reqTip
		if not tip then return end
		local fTitle = "Ubuntu Mono:" .. tostring(gRespFont(21))
		local fLine  = "Ubuntu Mono:" .. tostring(gRespFont(18))
		local rows   = tip.lines or {}

		surface.SetFont(fTitle)
		local maxW = surface.GetTextSize(tip.head or "")
		surface.SetFont(fLine)
		for _, ln in ipairs(rows) do
			local s = tostring(ln.label) .. " : " .. tostring(ln.have) .. " / " .. tostring(ln.need)
			local tw = surface.GetTextSize(s)
			if tw > maxW then maxW = tw end
		end

		local pad    = gRespX(14)
		local titleH = gRespY(34)
		local lineH  = gRespY(26)
		local boxW   = maxW + pad * 2
		local boxH   = titleH + #rows * lineH + gRespY(12)

		local mx, my = self:CursorPos()
		local bx = math.Clamp(mx + gRespX(18), 0, math.max(0, w - boxW))
		local by = math.Clamp(my + gRespY(10), 0, math.max(0, h - boxH))

		draw.RoundedBox(gRespX(6), bx, by, boxW, boxH, Color(14, 14, 17, 248))
		surface.SetDrawColor(tip.ready and Color(120, 220, 130) or Color(207, 68, 78))
		surface.DrawRect(bx, by, gRespX(3), boxH) -- liseré accent : vert = prêt / rouge = manque

		draw.SimpleText(tip.head or "", fTitle, bx + pad, by + gRespY(8),
			tip.ready and Color(150, 230, 160) or Color(235, 236, 240), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		local ly = by + titleH
		for _, ln in ipairs(rows) do
			local s = tostring(ln.label) .. " : " .. tostring(ln.have) .. " / " .. tostring(ln.need)
			draw.SimpleText(s, fLine, bx + pad, ly,
				ln.ok and Color(120, 220, 130) or Color(232, 120, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			ly = ly + lineH
		end
	end

	-- Custom text area (same style as Category 2)
	local textArea = vgui.Create("DTextEntry", contentPanel)
	textArea:SetSize(gRespX(400), gRespY(100))
	textArea:SetPos(gRespX(25), gRespY(40))
	textArea:SetMultiline(true)
	textArea:SetText("")
	textArea:SetPlaceholderText("Ecrivez quelque chose...")
	textArea:SetDrawBackground(false)
	textArea:SetDrawBorder(false)
	textArea:SetFont("Ubuntu Mono:" .. tostring(gRespFont(15)))
	textArea:SetTextColor(Color(0, 0, 0, 255))
	textArea:SetPlaceholderColor(Color(0, 0, 0, 255))
	textArea:SetDrawLanguageID(false)

	-- Add character counter
	local charCounter = vgui.Create("DLabel", contentPanel)
	charCounter:SetSize(gRespX(100), gRespY(20))
	charCounter:SetPos(gRespX(380), gRespY(145))
	charCounter:SetFont("Ubuntu Mono:" .. tostring(gRespFont(15)))
	charCounter:SetTextColor(Color(100, 100, 100, 255))
	charCounter:SetText("0/100")
	charCounter:SetContentAlignment(4) -- Left align

	-- Store the last valid text to prevent exceeding limit
	local lastValidText = ""

	-- Update character counter and enforce limit when text changes
	textArea.OnTextChanged = function(self)
		local currentText = self:GetText()
		local currentLength = string.len(currentText)

		-- If text exceeds 100 characters, revert to last valid text
		if currentLength > 100 then
			self:SetText(lastValidText)
			currentText = lastValidText
			currentLength = string.len(currentText)
		else
			-- Update last valid text
			lastValidText = currentText
		end

		-- Update character counter
		charCounter:SetText(currentLength .. "/100")

		-- Change color based on character count
		if currentLength >= 100 then
			charCounter:SetTextColor(Color(255, 0, 0, 255)) -- Red when at limit
		elseif currentLength >= 80 then
			charCounter:SetTextColor(Color(204, 127, 11)) -- Orange when close to limit
		else
			charCounter:SetTextColor(Color(100, 100, 100, 255)) -- Gray when normal
		end
	end

	-- Publier button below text area
	local publierBtn = vgui.Create("lzy_faction_button", contentPanel)
	publierBtn:SetSize(gRespX(186), gRespY(41)) -- Larger to prevent clipping
	publierBtn:SetPos(gRespX(22), gRespY(147)) -- Adjusted position to center
	publierBtn:SetMaterials(materials.publier_btn, nil)
	publierBtn:SetTextSize(gRespX(180), gRespY(35))
	publierBtn:SetIconSize(gRespX(0), gRespY(0))
	publierBtn:SetButtonSize(gRespX(180), gRespY(35))
	publierBtn:SetUnderlineHover(true)
	publierBtn.DoClick = function()
		-- ANNONCE de division : dès DivAnnonceMinRank (10, demande user 08/05 — avant
		-- maxRank-2 = 14+). Gate serveur identique (ShowFactionAnnouncement) ; on informe
		-- ici au lieu d'échouer en silence + fausse notif « publiée ».
		local nMinRk = LZY_FACTION_CONFIG.DivAnnonceMinRank or 10
		if not LocalPlayer():IsSuperAdmin() and LocalPlayer():GetEvoNWInt("FactionRank", 0) < nMinRk then
			MUGEN.AddNotification("Annonce réservée aux grades " .. nMinRk .. "+.", NOTIFY_ERROR, 5)
			return
		end
		net.Start("server:lzy_faction.ShowFactionAnnouncement")
		net.WriteString(textArea:GetText())
		net.SendToServer()
		textArea:SetText("")
		MUGEN.AddNotification("Annonce publiée!", NOTIFY_GENERIC, 5)
	end
	-- Add custom paint
	publierBtn.Paint = function(self, w, h)
		-- Draw the original button material
		if self:IsHovered() then
			surface.SetDrawColor(255, 255, 255, 200)
		else
			surface.SetDrawColor(255, 255, 255, 255)
		end
		surface.SetMaterial(materials.publier_btn)
		surface.DrawTexturedRect(gRespX(0), gRespY(0), gRespX(180), gRespY(35))
	end

	-- Grade options ( `or {}` : nil si perso SANS faction — FactionName "" -> pas de clé dans
	-- la config. Évite le crash ipairs dans le selectbox / l'indexation nil plus bas.)
	local gradeOptions = LZY_FACTION_CONFIG.factions[LocalPlayer():GetEvoNWString("FactionName")] or {}

	-- Division options : liste DENSE de {text, value} où value = l'INDEX RÉEL de division
	-- (même idiome que le selectbox de grade). Indispensable dès que la liste est FILTRÉE :
	-- l'ancienne table à trous cassait ipairs dans SetOptions (dropdown réduit à « Aucune »)
	-- et l'envoi par POSITION ne partait jamais -> l'exclusion de division d'un capitaine
	-- ne faisait rien (bug user 2026-07-31).
	local divisionOptions = {}
	do
		local lp       = LocalPlayer()
		local sFaction = lp:GetEvoNWString("FactionName")
		local src      = LZY_FACTION_CONFIG.divisions[sFaction] or {}
		local nMaxRank = tonumber(#(LZY_FACTION_CONFIG.factions[sFaction] or {})) or 0
		local nMyRank  = tonumber(lp:GetEvoNWInt("FactionRank", 0)) or 0
		local nMyDiv   = tonumber(lp:GetEvoNWInt("FactionDivision", 0)) or 0
		-- Un CAPITAINE n'assigne que SA division (ou « Aucune » pour en sortir un membre).
		-- Le chef (grade max) et les SA gardent la liste complète. Le serveur revalide tout.
		local bOnlyMine = not lp:IsSuperAdmin() and not (nMaxRank > 1 and nMyRank >= nMaxRank) and nMyDiv > 1
		for idx = 1, #src do
			if not bOnlyMine or idx == 1 or idx == nMyDiv then
				divisionOptions[#divisionOptions + 1] = { text = src[idx], value = idx }
			end
		end
	end

	-- Create search bar for player list
	local searchBar = vgui.Create("DTextEntry", contentPanel)
	searchBar:SetSize(gRespX(150), gRespY(25))
	searchBar:SetPos(gRespX(430 - 152), gRespY(215))
	searchBar:SetText("")
	searchBar:SetFont("Ubuntu Mono:" .. tostring(gRespFont(18)))
	searchBar:SetPlaceholderText("Rechercher par nom...")
	searchBar:SetDrawBackground(false)
	searchBar:SetDrawBorder(false)
	searchBar:SetTextColor(Color(0, 0, 0, 255))
	searchBar:SetPlaceholderColor(Color(100, 100, 100, 255))
	searchBar:SetDrawLanguageID(false)

	-- Custom paint function for search bar with black border
	searchBar.Paint = function(self, w, h)
		-- Draw black border
		RNDX.DrawOutlined(gRespX(6), gRespX(0), gRespY(0), w, h, Color(0, 0, 0), 1)

		-- Draw text
		if self:GetText() == "" and not self:IsEditing() then
			-- Draw placeholder text
			draw.SimpleText(self:GetPlaceholderText(), "Ubuntu Mono:" .. tostring(gRespFont(14)), gRespX(5), h/2, Color(100, 100, 100, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			-- Draw actual text
			draw.SimpleText(self:GetText(), "Ubuntu Mono:" .. tostring(gRespFont(14)), gRespX(5), h/2, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	-- Add search functionality placeholder (will be set after scrollPanel is created)
	searchBar.OnTextChanged = function()
		-- This will be set after scrollPanel is created
	end

	-- Create scrollable list
	local scrollPanel = vgui.Create("DScrollPanel", contentPanel)
	scrollPanel:SetSize(gRespX(425), contentPanel:GetTall() - gRespY(255))
	scrollPanel:SetPos(gRespX(17), gRespY(250))
	scrollPanel.Paint = function(self, w, h)
		-- Background for scroll panel
	end

	-- Custom scroll bar styling
	local scrollBar = scrollPanel:GetVBar()
	scrollBar:SetWide(gRespX(8)) -- Make scroll bar thinner

	-- Custom scroll bar appearance
	scrollBar.Paint = function(self, w, h)
		-- Background of scroll bar track
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 100))
	end

	-- Custom scroll bar grip (the draggable part)
	scrollBar.btnGrip.Paint = function(self, w, h)
		-- Main scroll bar grip
		draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 200))

		-- Hover effect
		if self:IsHovered() then
			draw.RoundedBox(4, gRespX(0), gRespY(0), w, h, Color(75, 57, 29, 250))
		end
	end

	scrollBar.btnUp.Paint = function(self, w, h)
		-- Top button (usually hidden, but we'll style it)
		--draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100, 150))
	end

	scrollBar.btnDown.Paint = function(self, w, h)
		-- Bottom button (usually hidden, but we'll style it)
		--draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100, 150))
	end

	-- Bouton ANNONCE FACTION (bannière lzy_annonce_faction, ex-SA only) : gradés
	-- >= AnnonceMinRank (10+, config partagée — demande user 08/03) + SA.
	-- On raccourcit la liste pour lui faire de la place tout en bas de l'onglet ; l'émission
	-- (cible = SA propre faction pour un non-SA) est revalidée serveur.
	local nMaxRkAF = #(LZY_FACTION_CONFIG.factions[LocalPlayer():GetEvoNWString("FactionName")] or {})
	local bCanAnnonceFaction = LocalPlayer():IsSuperAdmin()
		or (nMaxRkAF > 1 and LocalPlayer():GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.AnnonceMinRank or 10))
	-- GESTION FORMATION (user 08/20) : registre de suivi des aspirants, à côté
	-- d'ANNONCE FACTION. Lecture pour tous les grades SuiviMinRank+ (toutes
	-- divisions), écriture limitée à SA division — le serveur revalide.
	-- Coche FORMATEUR incluse (08/20, demande user « quand tu es formateur ils l'ont
	-- pas ») : ce sont eux qui remplissent les fiches, beaucoup sont sous le grade 8.
	-- Miroir du serveur LZYF_CanSuivi ; la suppression reste grade 8+ (gate dédiée).
	local bCanSuivi = LocalPlayer():IsSuperAdmin()
		or LocalPlayer():GetEvoNWBool("EVO_FactionFormateur", false)
		or (LocalPlayer():GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.SuiviMinRank or 8))
	if bCanSuivi then
		scrollPanel:SetTall(scrollPanel:GetTall() - gRespY(46))
		local suiviBtn = vgui.Create("DButton", contentPanel)
		suiviBtn:SetText("") suiviBtn:SetSize(gRespX(425), gRespY(36))
		suiviBtn:SetPos(gRespX(17), contentPanel:GetTall() - (bCanAnnonceFaction and gRespY(88) or gRespY(42)))
		suiviBtn:SetZPos(50) suiviBtn:SetCursor("hand")
		suiviBtn.Paint = function(s, w, h)
			local hov = s:IsHovered()
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, hov and Color(52, 56, 66, 255) or Color(30, 32, 38, 235), gRespY(9), "br")
			else
				RNDX.Draw(0, 0, 0, w, h, hov and Color(52, 56, 66, 255) or Color(30, 32, 38, 235))
			end
			draw.SimpleText("GESTION FORMATION", "Bebas Neue:20", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		suiviBtn.DoClick = function()
			if LZY_Faction_OpenSuivi then LZY_Faction_OpenSuivi() end
		end
	end

	if bCanAnnonceFaction then
		scrollPanel:SetTall(scrollPanel:GetTall() - gRespY(46))
		local annonceBtn = vgui.Create("DButton", contentPanel)
		annonceBtn:SetText("") annonceBtn:SetSize(gRespX(425), gRespY(36))
		annonceBtn:SetPos(gRespX(17), contentPanel:GetTall() - gRespY(42))
		annonceBtn:SetZPos(50) annonceBtn:SetCursor("hand")
		annonceBtn.Paint = function(s, w, h)
			local hov = s:IsHovered()
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230), gRespY(9), "br")
			else
				RNDX.Draw(0, 0, 0, w, h, hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230))
			end
			draw.SimpleText("ANNONCE FACTION", "Bebas Neue:20", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		annonceBtn.DoClick = function()
			if LZY_AnnonceFaction_Open then LZY_AnnonceFaction_Open() end
		end
	end

	-- Prérequis du PROCHAIN grade pour un membre : renvoie (bReady, sTooltip).
	-- bReady = le perso remplit TOUS les prérequis du grade suivant (-> nom en vert + promotion
	-- débloquée côté serveur). sTooltip = détail have/need de chaque critère (au survol du nom).
	-- Les hauts gradés "connaissent ainsi les prérequis pour chaque joueur".
	local function FactionReqInfo(pdata)
		local faction  = pdata.faction or LocalPlayer():GetEvoNWString("FactionName")
		local curRank  = tonumber(pdata.rank) or 1
		local nextRank = curRank + 1
		local maxRank  = #(LZY_FACTION_CONFIG.factions[faction] or {})
		if nextRank > maxRank then return false, "Grade maximum atteint.", {} end
		-- Au-delà de NonSAMaxGrade (12) : seul un super-admin peut promouvoir -> pour un non-SA
		-- on n'affiche PAS de prérequis (et pas de "vert") mais un message clair.
		local nNonSAMax = LZY_FACTION_CONFIG.NonSAMaxGrade
		if nNonSAMax and nextRank > nNonSAMax and not LocalPlayer():IsSuperAdmin() then
			return false, "Grade " .. nextRank .. "+ : super-admin uniquement.", {}
		end
		local stats = {
			hours    = tonumber(pdata.hours)    or 0,
			level    = tonumber(pdata.level)    or 0,
			reports  = tonumber(pdata.reports)  or 0,
			captures = tonumber(pdata.captures) or 0,
			-- Critère de division (cf. DivisionCriterion config) : opérations (médical),
			-- carcasses (scientifique), recensements (commandement), sinon captures.
			operations   = tonumber(pdata.operations)   or 0,
			carcasses    = tonumber(pdata.carcasses)    or 0,
			recensements = tonumber(pdata.recensements) or 0,
			division     = tonumber(pdata.division)     or 1,
		}
		local met, details = LZY_FACTION_CONFIG.CheckGradeRequirements(faction, nextRank, stats)
		local gradeName = (LZY_FACTION_CONFIG.factions[faction] or {})[nextRank] or ("grade " .. nextRank)
		-- Lignes structurees (1 critere = 1 ligne, coloree have>=need) pour le GROS tooltip custom.
		local lines = {}
		for _, d in ipairs(details or {}) do
			local have = tonumber(d.have) or 0
			local need = tonumber(d.need) or 0
			lines[#lines + 1] = { label = d.label, have = d.have, need = d.need, ok = (have >= need) }
		end
		-- JOURS DE PROMOTION (demande user 08/05, assoupli 08/31) : les PRÉREQUIS
		-- restent VISIBLES tous les jours — les hauts gradés doivent pouvoir suivre la
		-- progression de leurs membres sans attendre la cérémonie. Hors mercredi/samedi
		-- seul le déblocage est verrouillé : bReady = false (pas de vert, pas de montée
		-- dans le menu), et l'en-tête du tooltip dit pourquoi. Le serveur revalide de
		-- toute façon (SetRank, heure serveur).
		if LZY_FACTION_CONFIG.IsPromoteDayAllowed and not LZY_FACTION_CONFIG.IsPromoteDayAllowed(nextRank)
			and not LocalPlayer():IsSuperAdmin() then
			local head = met and ("Prérequis remplis pour " .. gradeName .. " — promotion mercredi et samedi.")
				or ("Vers " .. gradeName .. " (promotion mercredi et samedi) :")
			return false, head, lines
		end
		local head = met and ("Prêt pour " .. gradeName) or ("Vers " .. gradeName .. " :")
		return met, head, lines
	end

	-- Roster virtualisé : on ne crée les VGUI (ligne + 2 selectbox + coche) QUE pour
	-- les ~15 rangées visibles. L'ancien rebuild de TOUS les membres dans la même
	-- frame (~5 panels + boutons d'options × N) gelait le client plusieurs secondes.
	local ROW_STEP = gRespY(35)
	local ROW_H    = gRespY(30)
	local OVERSCAN = 3
	local fName    = "Ubuntu Mono:" .. tostring(gRespFont(14))
	local fSel     = "Ubuntu Mono:" .. tostring(gRespFont(12))
	local fFmt     = "Ubuntu Mono:" .. tostring(gRespFont(13))
	local bCanAssignDiv = LocalPlayer():IsSuperAdmin()
		or LocalPlayer():GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.DivisionMinRank or 10)
	local bIsSA = LocalPlayer():IsSuperAdmin()
	local maxRankAll = #(gradeOptions or {})
	local nNonSAMax = LZY_FACTION_CONFIG.NonSAMaxGrade or maxRankAll

	local filteredPlayers = {}
	local visibleFrom, visibleTo = 0, 0
	local liveRows = {}

	-- Spacer : donne sa hauteur au canvas (scrollbar) sans allouer N lignes.
	local spacer = vgui.Create("DPanel", scrollPanel)
	spacer:SetPos(0, 0)
	spacer:SetSize(1, 1)
	spacer.Paint = function() end

	local function ClearLiveRows()
		for _, pack in ipairs(liveRows) do
			if IsValid(pack.row) then pack.row:Remove() end
			if IsValid(pack.gradeSB) then pack.gradeSB:Remove() end
			if IsValid(pack.divSB) then pack.divSB:Remove() end
			if IsValid(pack.fmtBtn) then pack.fmtBtn:Remove() end
		end
		liveRows = {}
		if IsValid(contentPanel) then
			contentPanel._reqTip = nil
			contentPanel._reqTipOwner = nil
		end
	end

	local function BuildPlayerRow(i, player)
		local playerName = isstring(player.name) and player.name or "Inconnu"
		local rowY = (i - 1) * ROW_STEP

		local rowPanel = vgui.Create("DPanel", scrollPanel)
		rowPanel:SetSize(gRespX(410), ROW_H)
		rowPanel:SetPos(gRespX(0), rowY)
		rowPanel.Paint = function(_, w, h)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(materials.collapse_bg)
			surface.DrawTexturedRect(gRespX(0), gRespY(0), w, h)
		end

		local nameLabel = vgui.Create("DLabel", rowPanel)
		nameLabel:SetSize(gRespX(140), ROW_H)
		nameLabel:SetPos(gRespX(10), gRespY(0))
		nameLabel:SetText(playerName)
		nameLabel:SetTextColor(Color(255, 255, 255))
		nameLabel:SetFont(fName)
		nameLabel:SetContentAlignment(4)

		local bReady, sHead, tLines = false, "", {}
		if LZY_FACTION_CONFIG.CheckGradeRequirements then
			bReady, sHead, tLines = FactionReqInfo(player)
			nameLabel:SetTextColor(bReady and Color(120, 220, 130) or Color(255, 255, 255))
			nameLabel:SetMouseInputEnabled(true)
			nameLabel.OnCursorEntered = function()
				contentPanel._reqTip = { head = sHead, lines = tLines, ready = bReady }
				contentPanel._reqTipOwner = nameLabel
			end
			nameLabel.OnCursorExited = function()
				if contentPanel._reqTipOwner == nameLabel then
					contentPanel._reqTip = nil
					contentPanel._reqTipOwner = nil
				end
			end
		end

		local gradeSelectbox = vgui.Create("lzy_faction_selectbox", scrollPanel)
		gradeSelectbox:SetSize(gRespX(108), gRespY(22))
		gradeSelectbox:SetPos(gRespX(176), rowY + gRespY(4))
		gradeSelectbox:SetMaterials(materials.selectbox_bg, materials.selectbox_bg)
		gradeSelectbox:SetTextColor(Color(255, 255, 255))
		gradeSelectbox:SetFont(fSel)
		local memberRank = tonumber(player.rank) or 1
		local gradeOpts = {}
		if bIsSA then
			for r = 1, maxRankAll do gradeOpts[#gradeOpts + 1] = { text = gradeOptions[r], value = r } end
		else
			-- RÉTROGRADATION (09/26) : Taicho / Espadas+, membres de SA division sous son autorité
			-- (le chef : toute la faction). Mêmes règles que SetRank, qui revalide tout.
			local nMyRank = LocalPlayer():GetEvoNWInt("FactionRank", 0)
			local nMyDivD = tonumber(LocalPlayer():GetEvoNWInt("FactionDivision", 0)) or 0
			local bChef = nMyRank >= maxRankAll
			local nElectD = LZY_FACTION_CONFIG.ElectGrade
			local bRevoque = nElectD and memberRank == nElectD and nMyRank >= (LZY_FACTION_CONFIG.ElectMinRank or 15)
			if nMyRank >= (LZY_FACTION_CONFIG.DemoteMinRank or 14) and memberRank < nMyRank
				and (bChef or (nMyDivD > 1 and (tonumber(player.division) or 1) == nMyDivD)) then
				for r = 1, memberRank - 1 do
					-- Élu (14) : le 13 est porté par « Révoquer l'élection » (même valeur envoyée).
					if not (bRevoque and r == nElectD - 1) then
						gradeOpts[#gradeOpts + 1] = { text = gradeOptions[r] or ("grade " .. r), value = r }
					end
				end
			end
			gradeOpts[#gradeOpts + 1] = { text = gradeOptions[memberRank] or ("grade " .. memberRank), value = memberRank }
			local bReadyNext = (not LZY_FACTION_CONFIG.CheckGradeRequirements) or bReady
			if bReadyNext and memberRank + 1 <= maxRankAll and memberRank + 1 <= nNonSAMax then
				gradeOpts[#gradeOpts + 1] = { text = gradeOptions[memberRank + 1], value = memberRank + 1 }
			end
			-- ÉLECTION (09/20) : un 15+ propose le grade 14 aux membres de SA division, et
			-- « révoquer » à son élu (le serveur rend le grade d'avant, revalide tout).
			local nElect = LZY_FACTION_CONFIG.ElectGrade
			local nMyDivE = tonumber(LocalPlayer():GetEvoNWInt("FactionDivision", 0)) or 0
			if nElect and LocalPlayer():GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.ElectMinRank or 15)
				and nMyDivE > 1 and (tonumber(player.division) or 1) == nMyDivE then
				if memberRank < nElect then
					gradeOpts[#gradeOpts + 1] = { text = "Élire " .. (gradeOptions[nElect] or ("grade " .. nElect)), value = nElect }
				elseif memberRank == nElect then
					gradeOpts[#gradeOpts + 1] = { text = "Révoquer l'élection", value = nElect - 1 }
				end
			end
		end
		gradeSelectbox:SetOptions(gradeOpts)
		for idx, opt in ipairs(gradeOpts) do
			if tonumber(opt.value) == memberRank then
				gradeSelectbox:SelectOption(idx)
				break
			end
		end
		gradeSelectbox.OnValueChanged = function(panel, value, text, index)
			local oldIndex = panel.selectedIndex
			LocalPlayer():OpenYesNoPopup(
				"Etes-vous sûr de vouloir changer le grade de " .. playerName .. " ?",
				"FactionSetRank",
				{steamid64 = player.steamid64, character_id = player.character_id, rank = tonumber(value), _selectbox = panel, _oldIndex = oldIndex},
				"FactionRevertSelectbox"
			)
		end

		local divisionSelectbox
		if bCanAssignDiv then
			divisionSelectbox = vgui.Create("lzy_faction_selectbox", scrollPanel)
			divisionSelectbox:SetSize(gRespX(72), gRespY(22))
			divisionSelectbox:SetPos(gRespX(292), rowY + gRespY(4))
			divisionSelectbox:SetMaterials(materials.selectbox_bg, materials.selectbox_bg)
			divisionSelectbox:SetTextColor(Color(255, 255, 255))
			divisionSelectbox:SetFont(fSel)
			divisionSelectbox:SetOptions(divisionOptions)
			local memberDiv = tonumber(player.division) or 1
			for idx, opt in ipairs(divisionOptions) do
				if tonumber(opt.value) == memberDiv then
					divisionSelectbox:SelectOption(idx)
					break
				end
			end
			divisionSelectbox.OnValueChanged = function(panel, value, text, index)
				local oldIndex = panel.selectedIndex
				LocalPlayer():OpenYesNoPopup(
					"Etes-vous sûr de vouloir changer " .. LZY_FACTION_CONFIG.DivisionDef(LocalPlayer()) .. " de " .. playerName .. " ?",
					"FactionSetDivision",
					{steamid64 = player.steamid64, character_id = player.character_id, division = tonumber(value), _selectbox = panel, _oldIndex = oldIndex},
					"FactionRevertSelectbox"
				)
			end
		end

		local fmtBtn = vgui.Create("DButton", scrollPanel)
		fmtBtn:SetSize(gRespX(18), gRespY(18))
		fmtBtn:SetPos(gRespX(152), rowY + gRespY(6))
		fmtBtn:SetText("")
		fmtBtn:SetDrawBackground(false)
		fmtBtn:SetDrawBorder(false)
		fmtBtn:SetTooltip("Formateur : peut recruter les aspirants (grade 1) dans sa division")
		local function estFormateur()
			return player.formateur == true or player.formateur == "1"
		end
		fmtBtn.Paint = function(self, w, h)
			local bOn = estFormateur()
			draw.RoundedBox(gRespX(3), 0, 0, w, h, bOn and Color(207, 68, 78, 255) or Color(14, 14, 17, 200))
			surface.SetDrawColor(255, 255, 255, self:IsHovered() and 255 or 160)
			surface.DrawOutlinedRect(0, 0, w, h)
			if bOn then
				draw.SimpleText("F", fFmt, w / 2, h / 2,
					Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		fmtBtn.DoClick = function()
			local bOn = estFormateur()
			LocalPlayer():OpenYesNoPopup(
				bOn and ("Retirer le rôle FORMATEUR de " .. playerName .. " ?")
					or ("Nommer " .. playerName .. " FORMATEUR ? Il pourra recruter les aspirants dans sa division (grade 2)."),
				"FactionSetFormateur",
				{ steamid64 = player.steamid64, character_id = player.character_id, value = not bOn }
			)
		end

		liveRows[#liveRows + 1] = {
			row = rowPanel, gradeSB = gradeSelectbox, divSB = divisionSelectbox, fmtBtn = fmtBtn,
		}
	end

	local function DropdownOpen()
		for _, pack in ipairs(liveRows) do
			if IsValid(pack.gradeSB) and pack.gradeSB.isOpen then return true end
			if IsValid(pack.divSB) and pack.divSB.isOpen then return true end
		end
		return false
	end

	local function SyncVisibleRows()
		if not IsValid(scrollPanel) then return end
		local n = #filteredPlayers
		if n == 0 then
			if #liveRows > 0 then
				ClearLiveRows()
				visibleFrom, visibleTo = 0, 0
			end
			return
		end
		-- Un dropdown ouvert : ne pas détruire la rangée sous le curseur.
		if DropdownOpen() then return end

		local scrollY = 0
		local vbar = scrollPanel:GetVBar()
		if IsValid(vbar) then scrollY = vbar:GetScroll() end
		local viewH = scrollPanel:GetTall()
		local first = math.max(1, math.floor(scrollY / ROW_STEP) + 1 - OVERSCAN)
		local last  = math.min(n, math.ceil((scrollY + viewH) / ROW_STEP) + OVERSCAN)
		if first == visibleFrom and last == visibleTo and #liveRows > 0 then return end

		ClearLiveRows()
		visibleFrom, visibleTo = first, last
		for i = first, last do
			BuildPlayerRow(i, filteredPlayers[i])
		end
	end

	local lastSearchText
	local function UpdatePlayerList()
		if not IsValid(scrollPanel) then return end
		local searchText = string.lower(searchBar:GetText())
		filteredPlayers = {}

		-- name nil-safe (08/03) : un membre BDD sans nom (fm.name NULL) faisait crasher
		-- string.lower/SetText et vidait TOUTE la liste. Le serveur normalise aussi ("?").
		for _, player in ipairs(players) do
			local playerName = isstring(player.name) and player.name or "Inconnu"
			if searchText == "" or string.find(string.lower(playerName), searchText, 1, true) then
				filteredPlayers[#filteredPlayers + 1] = player
			end
		end

		if IsValid(spacer) then
			spacer:SetSize(1, math.max(1, #filteredPlayers * ROW_STEP))
		end
		-- Reset scroll seulement si la recherche change (pas sur un patch formateur/grade).
		if searchText ~= lastSearchText and IsValid(scrollBar) then
			scrollBar:SetScroll(0)
		end
		lastSearchText = searchText
		visibleFrom, visibleTo = 0, 0
		ClearLiveRows()
		SyncVisibleRows()
		scrollPanel:InvalidateLayout(true)
	end

	local oldScrollThink = scrollPanel.Think
	scrollPanel.Think = function(s)
		if oldScrollThink then oldScrollThink(s) end
		SyncVisibleRows()
	end

	-- Set up search functionality now that scrollPanel exists
	searchBar.OnTextChanged = function()
		UpdatePlayerList()
	end

	mainPanel.UpdatePlayerList = UpdatePlayerList

	-- Initialize the player list
	UpdatePlayerList()
end

function PANEL:Paint(w, h)
	-- UI Background
	RNDX.DrawMaterial(0, gRespX(0), gRespY(0), w, h, Color(255, 255, 255, 255), materials.bg)

	-- Long Tache
	RNDX.DrawMaterial(0, gRespX(227 + self.categoryLeftPadding), gRespY(50), gRespX(114), gRespY(164), Color(255, 255, 255, 255), materials.long_tache)

	-- Timbre
	RNDX.DrawMaterial(0, gRespX(185 + self.categoryLeftPadding), h - gRespY(230), gRespX(180), gRespY(180), Color(255, 255, 255, 255), materials.timbre)

	-- Left Side Background
	RNDX.DrawMaterial(0, gRespX(30 + self.categoryLeftPadding), gRespY(10), gRespX(720), gRespY(846), Color(255, 255, 255, 255), materials.left_side_bg)

	-- Right Side Background
	RNDX.DrawMaterial(0, gRespX(515 + self.mainLeftPadding - 3), gRespY(325 + 19), gRespX(435), gRespY(507), Color(255, 255, 255, 255), materials.right_side_bg)
end

-- One-shot reverse book sequence player. Plays from last to first when closing.
local function PlayBookSequenceReverse()
	if isPlayingBook then return end
	isPlayingBook = true

	local startTime = CurTime()
	local totalDuration = #book_sequence * BOOK_SEQUENCE_DELAY

	hook.Add("HUDPaint", "LZY_Faction_BookSequence_HUD_Reverse", function()
		local elapsed = CurTime() - startTime
		local step = math.floor(elapsed / BOOK_SEQUENCE_DELAY)
		local frameIndex = math.Clamp(#book_sequence - step, 1, #book_sequence - 1)
		local mat = book_sequence[frameIndex]
		if mat then
			surface.SetMaterial(mat)
			surface.SetDrawColor(255, 255, 255)
			local w, h = gRespX(1200), gRespY(870)
			-- MÊME centrage écran-réel que la frame (PANEL:Init) : l'animation du livre doit
			-- rester SUPERPOSÉE au menu en résolution non-16:9 (ex. 1080x1080). Sinon la frame
			-- est centrée écran alors que l'anim reste en coords virtuelles -> décalage vertical.
			local x = math.floor((ScrW() - gRespX(1200)) / 2) + gRespX(117)
			local y = math.floor((ScrH() - gRespY(870)) / 2)
			surface.DrawTexturedRect(x, y, w, h)
		end
	end)

	timer.Simple(totalDuration, function()
		hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD_Reverse")
		isPlayingBook = false
	end)
end

function PANEL:OnClose()
	frame = nil
	PlaySoundBySoundData(soundsData.closing_book)
	timer.Simple(1, function()
		StopSoundBySoundData(soundsData.closing_book)
	end)
	PlayBookSequenceReverse()

	-- Demander au serveur d'arrêter l'animation de lecture + supprimer le livre
	net.Start("server:lzy_faction.StopReadAnim")
	net.SendToServer()
end

vgui.Register("lzy_faction", PANEL, "DFrame")

local function PlayBookSequenceThenOpenMenu()
	-- Defensif : on clear toujours l'etat avant d'ouvrir. Si l'anim reverse
	-- de fermeture etait encore en cours (isPlayingBook = true), l'early return
	-- d'avant skipait silencieusement l'anim d'ouverture -> le panel se chargeait
	-- sans intro. Maintenant on tue le reverse pour que le forward demarre clean.
	hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD")
	hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD_Reverse")
	timer.Remove("LZY_Faction_BookSeq_Stop")
	timer.Remove("LZY_Faction_BookSeq_Open")
	timer.Remove("LZY_Faction_BookSeq_RevStop")
	StopSoundBySoundData(soundsData.opening_book)
	StopSoundBySoundData(soundsData.closing_book)
	isPlayingBook = true

	-- Demander au serveur de jouer l'animation de lecture + spawn le livre
	net.Start("server:lzy_faction.StartReadAnim")
	net.SendToServer()

	PlaySoundBySoundData(soundsData.opening_book)
	timer.Create("LZY_Faction_BookSeq_StopSound", 2, 1, function()
		StopSoundBySoundData(soundsData.opening_book)
	end)

	local startTime = CurTime()
	local totalDuration = #book_sequence * BOOK_SEQUENCE_DELAY

	-- Draw sequence during play
	hook.Add("HUDPaint", "LZY_Faction_BookSequence_HUD", function()
		local elapsed = CurTime() - startTime
		local frameIndex = math.Clamp(math.floor(elapsed / BOOK_SEQUENCE_DELAY) + 1, 1, #book_sequence - 1)

		local mat = book_sequence[frameIndex]
		if mat then
			surface.SetMaterial(mat)
			surface.SetDrawColor(255, 255, 255)
			local w, h = gRespX(1200), gRespY(870)
			-- MÊME centrage écran-réel que la frame (PANEL:Init) : l'animation du livre doit
			-- rester SUPERPOSÉE au menu en résolution non-16:9 (ex. 1080x1080). Sinon la frame
			-- est centrée écran alors que l'anim reste en coords virtuelles -> décalage vertical.
			local x = math.floor((ScrW() - gRespX(1200)) / 2) + gRespX(117)
			local y = math.floor((ScrH() - gRespY(870)) / 2)
			surface.DrawTexturedRect(x, y, w, h)
		end
	end)

	-- Stop after one full pass and open the panel. Timers nomes pour pouvoir
	-- les annuler proprement si l'utilisateur reouvre/referme rapidement.
	timer.Create("LZY_Faction_BookSeq_Stop", totalDuration, 1, function()
		hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD")
		isPlayingBook = false
	end)
	timer.Create("LZY_Faction_BookSeq_Open", totalDuration - 0.2, 1, function()
		if not IsValid(frame) then
			-- Re-vérifier la faction au moment de la création DIFFÉRÉE : OpenFactionMenu a validé
			-- AVANT l'animation du livre, mais la faction peut avoir été purgée entre-temps
			-- (retour menu perso / suppression du perso -> NW FactionName remis à ""). Sans cette
			-- garde, Init indexerait factions[""] -> #nil -> erreur Lua client.
			local sFac = LocalPlayer():GetEvoNWString("FactionName", "")
			if sFac == "" or not (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.factions[sFac]) then return end
			frame = vgui.Create("lzy_faction")
		end
	end)
end

local metaPlayer = FindMetaTable("Player")

-- bSilent : ferme sans anim reverse / son (ex. transition forcée vers le créateur).
function metaPlayer:CloseFactionMenu(bSilent)
	-- Abort l'anim d'ouverture en cours (timers / HUD) : sinon le panel peut encore
	-- apparaître APRÈS un Close pendant la séquence livre (ex. skip tuto âme errante).
	hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD")
	hook.Remove("HUDPaint", "LZY_Faction_BookSequence_HUD_Reverse")
	timer.Remove("LZY_Faction_BookSeq_Stop")
	timer.Remove("LZY_Faction_BookSeq_Open")
	timer.Remove("LZY_Faction_BookSeq_RevStop")
	timer.Remove("LZY_Faction_BookSeq_StopSound")
	StopSoundBySoundData(soundsData.opening_book)
	StopSoundBySoundData(soundsData.closing_book)
	isPlayingBook = false

	if IsValid(frame) then
		if bSilent then
			local f = frame
			frame = nil
			f:Remove()
			net.Start("server:lzy_faction.StopReadAnim")
			net.SendToServer()
		else
			frame:Close() -- OnClose -> StopReadAnim serveur + anim reverse
		end
	else
		-- Mid-open sans frame encore : couper l'anim serveur démarrée au début de la séquence.
		net.Start("server:lzy_faction.StopReadAnim")
		net.SendToServer()
	end
end

-- Fermeture forcée depuis le serveur (dégâts reçus pendant la lecture)
net.Receive("client:lzy_faction.ForceCloseFactionMenu", function()
	local lp = LocalPlayer()
	if IsValid(lp) then
		lp:CloseFactionMenu()
	end
end)

function OpenFactionMenu()
	if not LZY_FACTION_CONFIG then
		return -- Config not loaded yet, skip this frame
	end
	if LocalPlayer():GetCharFaction() == "" then
		LocalPlayer():OpenPopup("Vous n'avez pas de faction", "error")
		return
	end
	if IsValid(frame) then
		frame:Close()
	else
		PlayBookSequenceThenOpenMenu()
	end
end

-- Forcer l'animation de lecture côté client pour tous les joueurs
local seqCache = {}
local function CachedLookupSequence(ply, seqName)
	local mdl = ply:GetModel()
	local key = mdl .. "_" .. seqName
	if seqCache[key] == nil then
		seqCache[key] = ply:LookupSequence(seqName) or -1
	end
	return seqCache[key]
end

hook.Add("UpdateAnimation", "LZY_Faction_ReadAnimForce", function(ply)
	if not IsValid(ply) then return end
	if not ply:GetEvoNWBool("EVO::IsReadingFaction", false) then
		ply._FactionReadSeqSet = nil
		return
	end

	local nSeq = CachedLookupSequence(ply, "evo_hwndw1d2gtqzzdvkf")
	if nSeq and nSeq > 0 then
		-- Ne reset la séquence qu'une seule fois pour ne pas bloquer l'animation
		if not ply._FactionReadSeqSet then
			ply:ResetSequence(nSeq)
			ply:SetCycle(0)
			ply._FactionReadSeqSet = true
		end
		ply:SetPlaybackRate(1)
		return true
	end
end)

net.Receive("client:lzy_faction.SetPlayersListByFaction", function()
	local n = net.ReadUInt(8)
	local list = {}
	local faction = LocalPlayer():GetEvoNWString("FactionName")
	for _ = 1, n do
		local divIdx = net.ReadUInt(8)
		local connected = net.ReadUInt(16)
		local total = net.ReadUInt(16)
		local expanded = net.ReadBool()
		list[#list + 1] = {
			division = divIdx,
			title = LZY_FACTION_CONFIG.DivisionName(faction, divIdx),
			expanded = expanded,
			connectedPlayers = connected .. "/" .. total,
			rows = {},
			loaded = false,
		}
	end
	playersListByDivision = list
	effectifsSearchResults = nil
	effectifsSearchPending = ""
	effectifsSearchBuf = nil
	effectifsDivisionBuf = nil
	if IsValid(frame) and frame.currentCategory == 3 then
		frame:SwitchToCategory(3)
	end
end)

local function EffectifRowStats(sanctions, reports)
	return "Sanctions : " .. (tonumber(sanctions) or 0) .. " | Rapports : " .. (tonumber(reports) or 0)
end

net.Receive("client:lzy_faction.SetDivisionEffectifs", function()
	local divIdx = net.ReadUInt(8)
	local total = net.ReadUInt(16)
	local chunkIdx = net.ReadUInt(8)
	local chunkCount = net.ReadUInt(8)
	local n = net.ReadUInt(16)
	if chunkIdx == 0 then
		effectifsDivisionBuf = { division = divIdx, rows = {} }
	end
	if not effectifsDivisionBuf or effectifsDivisionBuf.division ~= divIdx then return end
	for _ = 1, n do
		local name = net.ReadString()
		local sanctions = net.ReadUInt(16)
		local reports = net.ReadUInt(16)
		local connected = net.ReadBool()
		effectifsDivisionBuf.rows[#effectifsDivisionBuf.rows + 1] = {
			text = name,
			stats = EffectifRowStats(sanctions, reports),
			isConnected = connected,
		}
	end
	if chunkIdx + 1 < chunkCount then return end
	if #effectifsDivisionBuf.rows ~= total then effectifsDivisionBuf = nil return end
	local rows = effectifsDivisionBuf.rows
	effectifsDivisionBuf = nil
	for _, d in ipairs(playersListByDivision) do
		if d.division == divIdx then
			d.rows = rows
			d.loaded = true
			d.expanded = true
			local c = 0
			for _, row in ipairs(rows) do
				if row.isConnected then c = c + 1 end
			end
			d.connectedPlayers = c .. "/" .. #rows
			break
		end
	end
	if IsValid(frame) and frame.currentCategory == 3 and not effectifsSearchResults and frame.UpdateEffectifsList then
		frame:UpdateEffectifsList()
	end
end)

net.Receive("client:lzy_faction.SetEffectifsSearch", function()
	local query = string.lower(string.Trim(net.ReadString() or ""))
	local total = net.ReadUInt(16)
	local chunkIdx = net.ReadUInt(8)
	local chunkCount = net.ReadUInt(8)
	local n = net.ReadUInt(16)
	if chunkIdx == 0 then
		effectifsSearchBuf = { query = query, rows = {} }
	end
	if not effectifsSearchBuf or effectifsSearchBuf.query ~= query then
		-- Consommer le reste du paquet (protocole binaire) puis jeter.
		for _ = 1, n do
			net.ReadUInt(8)
			net.ReadString()
			net.ReadUInt(16)
			net.ReadUInt(16)
			net.ReadBool()
		end
		return
	end
	for _ = 1, n do
		local divIdx = net.ReadUInt(8)
		local name = net.ReadString()
		local sanctions = net.ReadUInt(16)
		local reports = net.ReadUInt(16)
		local connected = net.ReadBool()
		effectifsSearchBuf.rows[#effectifsSearchBuf.rows + 1] = {
			division = divIdx,
			text = name,
			stats = EffectifRowStats(sanctions, reports),
			isConnected = connected,
		}
	end
	if chunkIdx + 1 < chunkCount then return end
	if #effectifsSearchBuf.rows ~= total then effectifsSearchBuf = nil return end
	if query ~= effectifsSearchPending then effectifsSearchBuf = nil return end
	local byDiv, order = {}, {}
	for _, row in ipairs(effectifsSearchBuf.rows) do
		local d = row.division
		if not byDiv[d] then
			byDiv[d] = {
				division = d,
				title = LZY_FACTION_CONFIG.DivisionName(LocalPlayer(), d),
				expanded = true,
				loaded = true,
				rows = {},
			}
			order[#order + 1] = d
		end
		byDiv[d].rows[#byDiv[d].rows + 1] = {
			text = row.text,
			stats = row.stats,
			isConnected = row.isConnected,
		}
	end
	table.sort(order)
	local list = {}
	for _, d in ipairs(order) do
		local g = byDiv[d]
		local c = 0
		for _, r in ipairs(g.rows) do
			if r.isConnected then c = c + 1 end
		end
		g.connectedPlayers = c .. "/" .. #g.rows
		list[#list + 1] = g
	end
	effectifsSearchBuf = nil
	effectifsSearchResults = list
	if IsValid(frame) and frame.currentCategory == 3 and frame.UpdateEffectifsList then
		frame:UpdateEffectifsList()
	end
end)

-- Règlement de faction reçu (par faction). Rafraîchit l'onglet Règlement s'il est ouvert.
net.Receive("client:lzy_faction.SetReglement", function()
	factionReglement = net.ReadString()
	if IsValid(frame) and frame.currentCategory == 1 then
		frame:SwitchToCategory(1)
	end
end)

net.Receive("client:lzy_faction.SetPendingReports", function(len, ply)
	local pendingReports = net.ReadTable()
	reportsToValidate = pendingReports
	-- Pas de rebuild si on consulte les archives : ça renverrait à la liste « à valider ».
	if IsValid(frame) and frame.currentCategory == 4 and not frame._archiveView then
		frame:SwitchToCategory(4)
	end
end)

net.Receive("client:lzy_faction.SetArchivedReports", function()
	archivedReports = net.ReadTable()
	if IsValid(frame) and frame._archiveView then
		frame:CreateArchiveUI()
	end
end)

net.Receive("client:lzy_faction.SetFullReport", function()
	local fullReport = net.ReadTable()
	-- Show detailed view of the report
	if IsValid(frame) and frame.fullReportContentPanel then
		ShowReportDetail(frame.fullReportContentPanel, fullReport)
	end
end)

-- Liste gestion (cat.5) : format binaire compact + chunks (cf. SendFullPlayersList serveur).
-- Ancien net.ReadTable overflowait ~64 Ko sur les grosses factions.
local fullPlayersListBuf = nil
net.Receive("client:lzy_faction.SetFullPlayersListByFaction", function()
	local total = net.ReadUInt(16)
	local chunkIdx = net.ReadUInt(8)
	local chunkCount = net.ReadUInt(8)
	local n = net.ReadUInt(16)
	if chunkIdx == 0 then
		fullPlayersListBuf = {}
	end
	if not fullPlayersListBuf then return end
	for _ = 1, n do
		fullPlayersListBuf[#fullPlayersListBuf + 1] = {
			name = net.ReadString(),
			steamid64 = net.ReadString(),
			character_id = net.ReadString(),
			rank = net.ReadUInt(8),
			division = net.ReadUInt(8),
			hours = net.ReadUInt(16) / 10,
			level = net.ReadUInt(16),
			reports = net.ReadUInt(16),
			captures = net.ReadUInt(16),
			operations = net.ReadUInt(16),
			carcasses = net.ReadUInt(16),
			recensements = net.ReadUInt(16),
			-- ⚠ PROTOCOLE BINAIRE : doit lire au MÊME rang que SendFullPlayersList (net.lua).
			formateur = net.ReadBool(), -- whitelist formateur (10/08)
		}
	end
	if chunkIdx + 1 >= chunkCount then
		-- Garde-fou : si un chunk a sauté, on n'installe pas une liste tronquée.
		if #fullPlayersListBuf == total then
			players = fullPlayersListBuf
			if IsValid(frame) and frame.UpdatePlayerList then
				frame:UpdatePlayerList()
			end
		end
		fullPlayersListBuf = nil
	end
end)

net.Receive("client:lzy_faction.UpdatePlayerData", function(len, ply)
	local steamid64 = net.ReadString()
	local character_id = net.ReadString()
	local field = net.ReadString()
	local value = net.ReadString()

	for _, plyy in ipairs(players) do
		if plyy.steamid64 == steamid64 and plyy.character_id == character_id then
			plyy[field] = value
			if frame and frame.UpdatePlayerList then
				frame:UpdatePlayerList()
			end
			return
		end
	end
end)

-- ============================================================================
-- GESTION FORMATION — registre de suivi des aspirants (user 2026-08-20)
-- Ouvert par le bouton « GESTION FORMATION » du livre de faction (à côté
-- d'ANNONCE FACTION). Tableau : Aspirant / Combat / Comportement / Objectif /
-- Verdict / Formateur / Date, + note personnelle dans la fiche.
-- LECTURE : toutes les divisions de sa faction. ÉCRITURE : sa division
-- seulement (le serveur revalide tout, le client ne fait que griser).
-- DA maison (VGUI + kit EVO_UI), pas de page web — règle projet.
-- ============================================================================
local SUIVI = { rows = {}, search = "" }
local suiviFrame
-- Fenêtres FILLES du registre (fiche + sélecteur d'aspirant) : mémorisées pour être
-- fermées AVEC lui (demande user 08/20 — une fiche restée ouverte par-dessus le jeu
-- après avoir quitté la page). Une seule de chaque à la fois.
local suiviEditor, suiviPicker

local S_COL_BG    = Color(13, 14, 17, 246)
local S_COL_ROW   = Color(22, 24, 29, 235)
local S_COL_ROW2  = Color(17, 18, 23, 235)
local S_COL_TITLE = Color(238, 239, 243)
local S_COL_MUTED = Color(150, 154, 162)
local S_COL_ACC   = Color(207, 68, 78)

local function SuiviCanWrite(nDiv)
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:IsSuperAdmin() then return true end
	return (tonumber(lp:GetEvoNWInt("FactionDivision", 0)) or 0) == (tonumber(nDiv) or -1)
end

local function SuiviDivName(nDiv)
	local lp = LocalPlayer()
	if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName and nDiv and nDiv > 0 then
		return LZY_FACTION_CONFIG.DivisionName(lp, nDiv) or ("Division " .. nDiv)
	end
	return "Sans division"
end

-- La fiche appartient au formateur qui l'a ouverte (demande user 08/20) : lui seul
-- la modifie. Le serveur revalide ; ici on ne fait que griser / expliquer.
-- Fiche sans propriétaire (créée avant la règle) = ancienne règle par division.
local function SuiviCanEditRow(r)
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:IsSuperAdmin() then return true end
	if (r.fsid or "") ~= "" then return r.fsid == lp:SteamID64() end
	return SuiviCanWrite(r.div)
end

-- Valeurs proposées en liste déroulante : plus rapide à remplir et comparable
-- d'une fiche à l'autre (demande user 08/20). L'ordre est du pire au meilleur.
local SUIVI_CHOICES = {
	combat  = { "Insuffisant", "Correct", "Bon", "Très bon", "Exceptionnel" },
	compo   = { "Problématique", "Passable", "Correct", "Exemplaire" },
	verdict = { "En attente", "À revoir", "Refusé", "Validé" },
}

-- Divisions/ordres de SA faction (index de config), pour l'affectation souhaitée.
local function SuiviDivChoices()
	local out = { { label = "Non renseignée", data = 0 } }
	local lp = LocalPlayer()
	local sFac = IsValid(lp) and lp:GetEvoNWString("FactionName", "") or ""
	local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions and LZY_FACTION_CONFIG.divisions[sFac]
	if istable(t) then
		for i = 2, 64 do -- l'index 1 est « Aucune », il ne se souhaite pas
			if t[i] then out[#out + 1] = { label = t[i], data = i } end
		end
	end
	return out
end

-- Liste déroulante à la DA maison (le DMenu par défaut jure avec le reste).
local function SuiviCombo(parent, x, y, w, h, tChoices, curData)
	local cb = vgui.Create("DComboBox", parent)
	cb:SetPos(x, y) cb:SetSize(w, h)
	cb:SetFont("Bebas Neue:20")
	cb:SetTextColor(S_COL_TITLE)
	cb:SetTextInset(gRespX(10), 0)
	cb:SetSortItems(false)
	cb.Paint = function(_, ww, hh)
		EVO_UI.PaintCut(0, 0, ww, hh, Color(24, 26, 31, 235), gRespY(8), "br")
		draw.SimpleText("v", "Bebas Neue:18", ww - gRespX(14), hh / 2 - gRespY(1),
			S_COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	-- Valeur enregistrée absente de la liste (fiche écrite en texte libre avant
	-- les listes) : on l'ajoute pour ne PAS l'effacer en silence à la réouverture.
	local bFound = false
	for _, c in ipairs(tChoices) do
		if c.data == curData then bFound = true break end
	end
	if not bFound and curData ~= nil and curData ~= "" and curData ~= 0 then
		table.insert(tChoices, 2, { label = tostring(curData), data = curData })
	end
	for _, c in ipairs(tChoices) do
		cb:AddChoice(c.label, c.data, c.data == curData)
	end
	if not cb:GetSelected() then cb:ChooseOptionID(1) end
	cb.OnMenuOpened = function(_, menu)
		if not IsValid(menu) then return end
		menu.Paint = function(_, ww, hh)
			EVO_UI.PaintCut(0, 0, ww, hh, Color(18, 19, 24, 250), gRespY(8), "br")
		end
		for _, opt in ipairs(menu:GetCanvas():GetChildren()) do
			if opt.SetFont then opt:SetFont("Bebas Neue:19") end
			if opt.SetTextColor then opt:SetTextColor(S_COL_TITLE) end
		end
	end
	return cb
end

net.Receive("server:lzy_faction.SuiviData", function()
	-- Payload compressé (cf. sv) : clés courtes pour tenir dans le message.
	local nLen = net.ReadUInt(32)
	local raw  = util.Decompress(net.ReadData(nLen) or "") or "[]"
	local arr  = util.JSONToTable(raw) or {}
	local t = {}
	for i, r in ipairs(arr) do
		t[i] = {
			id        = tonumber(r.id) or 0,
			div       = tonumber(r.dv) or 0,
			dwant     = tonumber(r.dw) or 0,
			name      = r.n  or "",
			combat    = r.c  or "",
			compo     = r.cp or "",
			objectif  = r.o  or "",
			verdict   = r.v  or "",
			note      = r.nt or "",
			formateur = r.f  or "",
			fsid      = r.fs or "",
			date      = tonumber(r.d) or 0,
		}
	end
	SUIVI.rows = t
	if IsValid(suiviFrame) and suiviFrame.Rebuild then suiviFrame:Rebuild() end
end)

-- Fiche (création / édition). Listes déroulantes pour tout ce qui se compare
-- d'un aspirant à l'autre, texte libre pour ce qui se raconte.
local function OpenSuiviEditor(rowData, sTargetSid, sTargetName)
	-- Listes RECONSTRUITES à chaque ouverture : SuiviCombo peut y insérer une
	-- ancienne valeur libre, on ne veut pas polluer la table de référence.
	local function List(t)
		local out = { { label = "Non renseigné", data = "" } }
		for _, s in ipairs(t) do out[#out + 1] = { label = s, data = s } end
		return out
	end
	local tFields = {
		{ key = "combat",   label = "CAPACITÉS AU COMBAT",    kind = "list", choices = List(SUIVI_CHOICES.combat) },
		{ key = "compo",    label = "COMPORTEMENT",           kind = "list", choices = List(SUIVI_CHOICES.compo) },
		{ key = "dwant",    label = "AFFECTATION SOUHAITÉE",  kind = "div",  choices = SuiviDivChoices() },
		{ key = "objectif", label = "OBJECTIF",               kind = "text" },
		{ key = "verdict",  label = "VERDICT",                kind = "list", choices = List(SUIVI_CHOICES.verdict) },
		{ key = "note",     label = "NOTE PERSONNELLE",       kind = "text" },
	}
	-- Hauteur CALCULÉE (en-tête + N champs + bouton + marge) : en dur, le bouton
	-- ENREGISTRER sortait de la fenêtre dès 5 champs (retour user 08/20).
	local ROW_H, TOP_Y, BTN_H = 78, 86, 46
	local W = 560
	local H = TOP_Y + (#tFields * ROW_H) + BTN_H + 30

	if IsValid(suiviEditor) then suiviEditor:Remove() end
	local f = vgui.Create("DFrame")
	suiviEditor = f
	f:SetSize(gRespX(W), gRespY(H))
	f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, S_COL_BG, gRespY(14), "br")
		draw.SimpleText("FICHE DE SUIVI", "Bebas Neue:34", gRespX(24), gRespY(26), S_COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(sTargetName or (rowData and rowData.name) or "", "Bebas Neue:22", gRespX(24), gRespY(56), S_COL_ACC, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local tEntries, tKinds = {}, {}
	local y = TOP_Y
	for _, fd in ipairs(tFields) do
		tKinds[fd.key] = fd.kind
		local lbl = vgui.Create("DLabel", f)
		lbl:SetPos(gRespX(24), gRespY(y))
		lbl:SetSize(gRespX(W - 48), gRespY(20))
		lbl:SetFont("Bebas Neue:20")
		lbl:SetTextColor(S_COL_MUTED)
		lbl:SetText(fd.label)

		if fd.kind == "text" then
			local te = vgui.Create("DTextEntry", f)
			te:SetPos(gRespX(24), gRespY(y + 22))
			te:SetSize(gRespX(W - 48), gRespY(44))
			te:SetFont("Bebas Neue:20")
			te:SetDrawLanguageID(false) -- enlève l'indicateur de langue « FR » du champ
			te:SetText((rowData and rowData[fd.key]) or "")
			te:SetPlaceholderText("...")
			te.Paint = function(s, w, h)
				EVO_UI.PaintCut(0, 0, w, h, Color(24, 26, 31, 235), gRespY(8), "br")
				s:DrawTextEntryText(S_COL_TITLE, S_COL_ACC, S_COL_TITLE)
			end
			tEntries[fd.key] = te
		else
			local cur = rowData and rowData[fd.key]
			if fd.kind == "div" then cur = tonumber(cur) or 0 else cur = cur or "" end
			tEntries[fd.key] = SuiviCombo(f, gRespX(24), gRespY(y + 22),
				gRespX(W - 48), gRespY(44), fd.choices, cur)
		end
		y = y + ROW_H
	end

	-- Valeur d'un champ, quel que soit son type (texte libre ou liste).
	local function Val(sKey)
		local p = tEntries[sKey]
		if not IsValid(p) then return "" end
		if tKinds[sKey] == "text" then return p:GetValue() or "" end
		local _, data = p:GetSelected()
		return data or ""
	end

	EVO_UI.ActionButton(f, gRespX(24), gRespY(y + 6), gRespX(W - 48), gRespY(BTN_H), "ENREGISTRER", nil, function()
		net.Start("server:lzy_faction.SuiviSave")
			-- id de la fiche EXISTANTE (0 = création). Sur une fiche déjà ouverte, le
			-- serveur met à jour PAR ID : l'aspirant n'a pas besoin d'être connecté
			-- (demande user 08/20). Seule la CRÉATION exige qu'il soit en ligne.
			net.WriteUInt((rowData and tonumber(rowData.id)) or 0, 32)
			net.WriteString(sTargetSid or "")
			net.WriteUInt(math.Clamp(tonumber(Val("dwant")) or 0, 0, 63), 6)
			net.WriteString(tostring(Val("combat")))
			net.WriteString(tostring(Val("compo")))
			net.WriteString(tostring(Val("objectif")))
			net.WriteString(tostring(Val("verdict")))
			net.WriteString(tostring(Val("note")))
		net.SendToServer()
		f:Remove()
	end)

	local x = vgui.Create("DButton", f)
	x:SetText("") x:SetSize(gRespX(30), gRespY(30)) x:SetPos(gRespX(W - 44), gRespY(16))
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:24", w / 2, h / 2,
			s:IsHovered() and S_COL_ACC or S_COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() f:Remove() end
end

-- Choix de l'aspirant : TOUS les joueurs connectés (demande user 08/20 — un
-- aspirant tout juste formé n'a souvent PAS encore de division, filtrer sur la
-- sienne ne montrait personne). On affiche faction + division pour situer ; le
-- serveur reste seul juge (faction, division, formation terminée).
local function OpenSuiviPicker()
	local lp = LocalPlayer()

	local tCands = {}
	for _, p in player.Iterator() do
		if p ~= lp then tCands[#tCands + 1] = p end
	end
	table.sort(tCands, function(a, b)
		local na = (a:GetEvoNWString("Nickname", "") ~= "" and a:GetEvoNWString("Nickname")) or a:Nick()
		local nb = (b:GetEvoNWString("Nickname", "") ~= "" and b:GetEvoNWString("Nickname")) or b:Nick()
		return string.lower(na) < string.lower(nb)
	end)

	if IsValid(suiviPicker) then suiviPicker:Remove() end
	local f = vgui.Create("DFrame")
	suiviPicker = f
	f:SetSize(gRespX(420), gRespY(460))
	f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, S_COL_BG, gRespY(14), "br")
		draw.SimpleText("NOUVELLE FICHE", "Bebas Neue:30", gRespX(22), gRespY(26), S_COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Joueurs connectés  ·  choisis l'aspirant", "Avenir Next World:15", gRespX(22), gRespY(52), S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local scroll = vgui.Create("DScrollPanel", f)
	scroll:SetPos(gRespX(18), gRespY(72))
	scroll:SetSize(gRespX(384), gRespY(370))

	if #tCands == 0 then
		local lbl = scroll:Add("DLabel")
		lbl:Dock(TOP) lbl:SetTall(gRespY(60)) lbl:SetFont("Bebas Neue:20")
		lbl:SetTextColor(S_COL_MUTED) lbl:SetContentAlignment(5)
		lbl:SetText("Aucun autre joueur connecté.")
	end

	for _, p in ipairs(tCands) do
		local sName = (p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname")) or p:Nick()
		local sFacP = p:GetEvoNWString("FactionName", "")
		local nDivP = tonumber(p:GetEvoNWInt("FactionDivision", 0)) or 0
		local sSub  = (sFacP ~= "" and sFacP or "Sans faction")
			.. "  ·  " .. ((nDivP > 1) and SuiviDivName(nDivP) or "Sans division")
		local b = scroll:Add("DButton")
		b:Dock(TOP) b:DockMargin(0, 0, 0, gRespY(6)) b:SetTall(gRespY(52)) b:SetText("")
		b.Paint = function(s, w, h)
			EVO_UI.PaintCut(0, 0, w, h, s:IsHovered() and Color(30, 32, 38, 245) or S_COL_ROW, gRespY(8), "br")
			draw.SimpleText(sName, "Bebas Neue:22", gRespX(14), gRespY(15), S_COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sSub, "Avenir Next World:13", gRespX(14), gRespY(35), S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			f:Remove()
			OpenSuiviEditor(nil, p:SteamID64(), sName)
		end
	end

	local x = vgui.Create("DButton", f)
	x:SetText("") x:SetSize(gRespX(30), gRespY(30)) x:SetPos(gRespX(420 - 44), gRespY(16))
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:24", w / 2, h / 2,
			s:IsHovered() and S_COL_ACC or S_COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() f:Remove() end
end

-- ── Registre PLEIN ÉCRAN (refonte 08/20, demande user) ───────────────────────
-- Une page entière : bandeau, compteurs, filtres, tableau, et un panneau de
-- DÉTAIL à droite. C'est lui qui montre l'objectif et la note personnelle, que
-- les colonnes tronquaient — et il permet enfin de LIRE une fiche qu'on ne
-- possède pas. VGUI + RNDX uniquement (le kit EVO_UI porte la DA, pas Chromium).
local S_COL_LINE = Color(255, 255, 255, 20)
local S_COL_OK   = Color(96, 186, 122)
local S_COL_WARN = Color(224, 164, 74)

-- Couleurs de dessin RÉUTILISÉES (mutées avant chaque draw) : une rangée de
-- tableau redessine 60 fois par seconde, on n'y alloue pas une Color par frame.
local S_SCRATCH = Color(0, 0, 0, 240)
local S_PILL    = Color(0, 0, 0, 46)

local function SuiviVerdictCol(s)
	s = string.lower(tostring(s or ""))
	if string.find(s, "valid", 1, true) then return S_COL_OK end
	if string.find(s, "refus", 1, true) then return S_COL_ACC end
	if string.find(s, "revoir", 1, true) then return S_COL_WARN end
	return S_COL_MUTED
end

local SUIVI_FILTERS = {
	{ id = "all",    t = "TOUTES" },
	{ id = "mine",   t = "LES MIENNES" },
	{ id = "wait",   t = "EN ATTENTE" },
	{ id = "revoir", t = "À REVOIR" },
	{ id = "ok",     t = "VALIDÉES" },
	{ id = "ko",     t = "REFUSÉES" },
}

local function SuiviMatchFilter(r, sId)
	if sId == "all" then return true end
	if sId == "mine" then
		local lp = LocalPlayer()
		return (r.fsid or "") ~= "" and IsValid(lp) and r.fsid == lp:SteamID64()
	end
	local v = string.lower(tostring(r.verdict or ""))
	if sId == "ok"     then return string.find(v, "valid",   1, true) ~= nil end
	if sId == "ko"     then return string.find(v, "refus",   1, true) ~= nil end
	if sId == "revoir" then return string.find(v, "revoir",  1, true) ~= nil end
	if sId == "wait"   then return v == "" or string.find(v, "attente", 1, true) ~= nil end
	return true
end

function LZY_Faction_OpenSuivi()
	if IsValid(suiviFrame) then suiviFrame:Remove() end
	SUIVI.search, SUIVI.filter, SUIVI.sel = "", "all", nil

	local W, H  = ScrW(), ScrH()
	local M     = gRespX(44)
	local GAP   = gRespX(16)
	local TOPY  = gRespY(124)
	local BOTY  = gRespY(56)
	local RAILW = gRespX(300)
	local SIDEW = gRespX(430)
	local BODYH = H - TOPY - BOTY
	local TABX  = M + RAILW + GAP
	local SIDEX = W - M - SIDEW
	local TABW  = SIDEX - GAP - TABX
	local PADX  = gRespX(18)
	local HEADY = gRespY(74) -- bas de la zone de recherche, dans la carte tableau

	-- Colonnes en FRACTIONS : la page s'adapte à la résolution.
	local COLS = {
		{ t = "ASPIRANT",     f = 0.19, k = "name" },
		{ t = "AFFECTATION",  f = 0.16, k = "dwant" },
		{ t = "COMBAT",       f = 0.14, k = "combat" },
		{ t = "COMPORTEMENT", f = 0.15, k = "compo" },
		{ t = "VERDICT",      f = 0.14, k = "verdict" },
		{ t = "FORMATEUR",    f = 0.14, k = "formateur" },
		{ t = "DATE",         f = 0.08, k = "date" },
	}

	local f = vgui.Create("DFrame")
	suiviFrame = f
	f:SetSize(W, H) f:SetPos(0, 0)
	f:SetTitle("") f:ShowCloseButton(false) f:SetDraggable(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end

	-- Quitter la page ferme AUSSI la fiche / le sélecteur restés ouverts par-dessus
	-- (demande user 08/20) : ce sont des popups indépendants, sans ça ils survivaient
	-- au registre et restaient plantés au milieu de l'écran.
	f.OnRemove = function()
		if IsValid(suiviEditor) then suiviEditor:Remove() end
		if IsValid(suiviPicker) then suiviPicker:Remove() end
		suiviEditor, suiviPicker = nil, nil
	end

	-- Fondu d'ouverture, en Lua pur (aucune allocation par frame).
	f._a = 0
	f.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 1) end

	surface.SetFont("Bebas Neue:46")
	local nTitleW = surface.GetTextSize("GESTION FORMATION")

	local stats = { total = 0, mine = 0, ok = 0, wait = 0 }

	f.Paint = function(s, w, h)
		local a = s._a
		-- Flou UNE passe (shader RNDX) + voile sombre : pas de blur par frame.
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		end
		surface.SetDrawColor(9, 9, 12, 234 * a)
		surface.DrawRect(0, 0, w, h)

		draw.SimpleText("GESTION FORMATION", "Bebas Neue:46", M, gRespY(52),
			ColorAlpha(S_COL_TITLE, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(S_COL_ACC, 255 * a))
		surface.DrawRect(M, gRespY(74), nTitleW, gRespY(3))
		draw.SimpleText("Suivi des aspirants de ta faction", "Avenir Next World:16",
			M, gRespY(96), ColorAlpha(S_COL_MUTED, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		surface.SetDrawColor(ColorAlpha(S_COL_LINE, 255 * a))
		surface.DrawRect(M, h - gRespY(46), w - M * 2, 1)
		draw.SimpleText("Clic : ouvrir la fiche  ·  Double-clic : modifier  ·  une fiche n'appartient qu'au formateur qui l'a ouverte",
			"Avenir Next World:14", M, h - gRespY(26), ColorAlpha(S_COL_MUTED, 255 * a),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- Bouton maison (le kit place en unités design, ici tout est en pixels).
	local function MiniBtn(parent, x, y, w, h, sLabel, sStyle, fn)
		local b = vgui.Create("DButton", parent)
		b:SetText("") b:SetPos(x, y) b:SetSize(w, h) b:SetCursor("hand")
		b.Paint = function(sb, bw, bh)
			local hv = sb:IsHovered() and sb:IsEnabled()
			local txt = S_COL_TITLE
			if not sb:IsEnabled() then
				S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = 24, 25, 30, 200
				txt = S_COL_MUTED
			elseif sStyle == "primary" then
				S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = hv and 225 or 207, hv and 84 or 68, hv and 94 or 78, 255
			elseif sStyle == "danger" then
				S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = hv and 207 or 26, hv and 68 or 28, hv and 78 or 34, hv and 255 or 240
				txt = hv and S_COL_TITLE or S_COL_ACC
			else
				S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = hv and 34 or 26, hv and 37 or 28, hv and 44 or 34, 242
			end
			EVO_UI.PaintCut(0, 0, bw, bh, S_SCRATCH, gRespY(8), "br")
			draw.SimpleText(sLabel, "Bebas Neue:20", bw / 2, bh / 2, txt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
		return b
	end

	-- ── Colonne de gauche : compteurs + filtres + création ───────────────────
	local rail = vgui.Create("DPanel", f)
	rail:SetPos(M, TOPY) rail:SetSize(RAILW, BODYH)
	rail.Paint = function(_, w, h)
		EVO_UI.PaintCard(w, h, f._a, gRespY(14))
		local pad, cw = gRespX(18), 0
		cw = (w - pad * 2 - gRespX(10)) / 2
		local ch = gRespY(66)
		local tCards = {
			{ n = stats.total, t = "FICHES",      c = S_COL_TITLE },
			{ n = stats.mine,  t = "LES MIENNES", c = S_COL_ACC },
			{ n = stats.ok,    t = "VALIDÉES",    c = S_COL_OK },
			{ n = stats.wait,  t = "EN ATTENTE",  c = S_COL_WARN },
		}
		for i, cd in ipairs(tCards) do
			local cx = pad + ((i - 1) % 2) * (cw + gRespX(10))
			local cy = gRespY(20) + math.floor((i - 1) / 2) * (ch + gRespY(10))
			S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = 22, 24, 29, 235
			EVO_UI.PaintCut(cx, cy, cw, ch, S_SCRATCH, gRespY(8), "br")
			draw.SimpleText(cd.n, "Bebas Neue:30", cx + cw / 2, cy + gRespY(24), cd.c, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(cd.t, "Avenir Next World:12", cx + cw / 2, cy + gRespY(48), S_COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("FILTRER", "Bebas Neue:18", pad, gRespY(186), S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(S_COL_LINE)
		surface.DrawRect(pad, gRespY(198), w - pad * 2, 1)
	end

	for i, flt in ipairs(SUIVI_FILTERS) do
		local b = vgui.Create("DButton", rail)
		b:SetText("") b:SetCursor("hand")
		b:SetPos(gRespX(18), gRespY(210) + (i - 1) * gRespY(44))
		b:SetSize(RAILW - gRespX(36), gRespY(38))
		b.Paint = function(sb, bw, bh)
			local on = (SUIVI.filter == flt.id)
			local hv = sb:IsHovered()
			S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a =
				on and 44 or (hv and 30 or 22), on and 24 or (hv and 32 or 24),
				on and 28 or (hv and 38 or 29), 238
			EVO_UI.PaintCut(0, 0, bw, bh, S_SCRATCH, gRespY(7), "br")
			if on then
				surface.SetDrawColor(S_COL_ACC)
				surface.DrawRect(0, 0, gRespX(3), bh)
			end
			draw.SimpleText(flt.t, "Bebas Neue:19", gRespX(14), bh / 2,
				on and S_COL_TITLE or S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			SUIVI.filter = flt.id
			if IsValid(f) and f.Rebuild then f:Rebuild() end
		end
	end

	MiniBtn(rail, gRespX(18), BODYH - gRespY(64), RAILW - gRespX(36), gRespY(46),
		"NOUVELLE FICHE", "primary", function() OpenSuiviPicker() end)

	-- ── Tableau ─────────────────────────────────────────────────────────────
	local tab = vgui.Create("DPanel", f)
	tab:SetPos(TABX, TOPY) tab:SetSize(TABW, BODYH)
	tab.Paint = function(_, w, h)
		EVO_UI.PaintCard(w, h, f._a, gRespY(14))
		local cw = w - PADX * 2
		local x = PADX
		for _, c in ipairs(COLS) do
			draw.SimpleText(c.t, "Bebas Neue:17", x, HEADY + gRespY(18), S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			x = x + cw * c.f
		end
		surface.SetDrawColor(S_COL_LINE)
		surface.DrawRect(PADX, HEADY + gRespY(34), cw, 1)
	end

	local search = vgui.Create("DTextEntry", tab)
	search:SetPos(PADX, gRespY(20))
	search:SetSize(TABW - PADX * 2, gRespY(42))
	search:SetFont("Bebas Neue:20")
	search:SetDrawLanguageID(false) -- retire l'indicateur de langue « FR »
	search:SetPlaceholderText("Rechercher...")
	search:SetUpdateOnType(true)
	search.Paint = function(sp, w, h)
		S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = 24, 26, 31, 235
		EVO_UI.PaintCut(0, 0, w, h, S_SCRATCH, gRespY(8), "br")
		sp:DrawTextEntryText(S_COL_TITLE, S_COL_ACC, S_COL_TITLE)
		-- Placeholder dessiné À LA MAIN (pattern maison, cf. evo_carte / dashboard) :
		-- un Paint custom + DrawTextEntryText ne rend JAMAIS le placeholder natif —
		-- la barre avait l'air d'un bandeau, rien n'indiquait qu'on peut écrire dedans.
		if sp:GetValue() == "" and not sp:HasFocus() then
			draw.SimpleText(sp:GetPlaceholderText() or "", "Bebas Neue:20",
				gRespX(10), h / 2, S_COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	search.OnValueChange = function(_, v)
		SUIVI.search = string.lower(string.Trim(v or ""))
		if IsValid(f) and f.Rebuild then f:Rebuild() end
	end

	local scroll = vgui.Create("DScrollPanel", tab)
	scroll:SetPos(gRespX(10), HEADY + gRespY(42))
	scroll:SetSize(TABW - gRespX(20), BODYH - HEADY - gRespY(54))
	EVO_UI.StyleScrollBar(scroll)

	-- ── Panneau de détail ───────────────────────────────────────────────────
	local side = vgui.Create("DPanel", f)
	side:SetPos(SIDEX, TOPY) side:SetSize(SIDEW, BODYH)
	side.Paint = function(_, w, h) EVO_UI.PaintCard(w, h, f._a, gRespY(14)) end

	local sideScroll = vgui.Create("DScrollPanel", side)
	sideScroll:SetPos(gRespX(22), gRespY(22))
	sideScroll:SetSize(SIDEW - gRespX(44), BODYH - gRespY(102))
	EVO_UI.StyleScrollBar(sideScroll)

	local function CurrentRow()
		if not SUIVI.sel then return nil end
		for _, r in ipairs(SUIVI.rows) do
			if r.id == SUIVI.sel then return r end
		end
		return nil
	end

	-- SteamID64 du joueur EN LIGNE portant ce nom RP (le serveur exige qu'il
	-- soit connecté pour enregistrer ; hors ligne il refusera avec un message).
	local function SidOf(sName)
		for _, pl in player.Iterator() do
			local nm = (pl:GetEvoNWString("Nickname", "") ~= "" and pl:GetEvoNWString("Nickname")) or pl:Nick()
			if nm == sName then return pl:SteamID64() end
		end
		return ""
	end

	local btnEdit, btnDel
	local function AddField(sTitle, sVal, colVal)
		local head = sideScroll:Add("DLabel")
		head:Dock(TOP) head:DockMargin(0, gRespY(14), 0, gRespY(2))
		head:SetTall(gRespY(17)) head:SetFont("Avenir Next World:12")
		head:SetTextColor(S_COL_MUTED) head:SetText(string.upper(sTitle))

		local val = sideScroll:Add("DLabel")
		val:Dock(TOP) val:SetFont("Bebas Neue:21")
		val:SetTextColor(colVal or S_COL_TITLE)
		val:SetWrap(true) val:SetAutoStretchVertical(true)
		val:SetText((sVal ~= nil and tostring(sVal) ~= "") and tostring(sVal) or "-")
	end

	local function RebuildDetail()
		sideScroll:Clear()
		local r = CurrentRow()
		if not r then
			local l = sideScroll:Add("DLabel")
			l:Dock(TOP) l:DockMargin(0, gRespY(40), 0, 0)
			l:SetTall(gRespY(80)) l:SetFont("Bebas Neue:20")
			l:SetTextColor(S_COL_MUTED) l:SetContentAlignment(5) l:SetWrap(true)
			l:SetText("Sélectionne une fiche pour la lire en entier.")
			if IsValid(btnEdit) then btnEdit:SetEnabled(false) end
			if IsValid(btnDel) then btnDel:SetEnabled(false) end
			return
		end

		local name = sideScroll:Add("DLabel")
		name:Dock(TOP) name:SetTall(gRespY(40)) name:SetFont("Bebas Neue:32")
		name:SetTextColor(S_COL_ACC)
		name:SetText(r.name ~= "" and r.name or "Aspirant")

		AddField("Division actuelle", SuiviDivName(r.div))
		AddField("Affectation souhaitée", (r.dwant or 0) > 1 and SuiviDivName(r.dwant) or "-")
		AddField("Capacités au combat", r.combat)
		AddField("Comportement", r.compo)
		AddField("Objectif", r.objectif)
		AddField("Verdict", (r.verdict or "") ~= "" and r.verdict or "-", SuiviVerdictCol(r.verdict))
		AddField("Note personnelle", r.note)
		AddField("Formateur", r.formateur)
		AddField("Dernière mise à jour", (r.date or 0) > 0 and os.date("%d/%m/%Y", r.date) or "-")

		local bMine = SuiviCanEditRow(r)
		if not bMine then
			AddField("Accès", "Lecture seule : cette fiche est suivie par "
				.. (((r.formateur or "") ~= "") and r.formateur or "un autre formateur") .. ".", S_COL_MUTED)
		end
		if IsValid(btnEdit) then btnEdit:SetEnabled(bMine) end
		-- SUPPRIMER : sa fiche ET grade 8+ (miroir du serveur — la coche formateur
		-- ouvre le registre/l'écriture, pas la suppression, demande user).
		local lpDel = LocalPlayer()
		local bCanDelete = bMine and (lpDel:IsSuperAdmin()
			or lpDel:GetEvoNWInt("FactionRank", 0) >= (LZY_FACTION_CONFIG.SuiviMinRank or 8))
		if IsValid(btnDel) then btnDel:SetEnabled(bCanDelete) end
	end

	local bw = (SIDEW - gRespX(44) - gRespX(12)) / 2
	btnEdit = MiniBtn(side, gRespX(22), BODYH - gRespY(66), bw, gRespY(44), "MODIFIER", "primary", function()
		local r = CurrentRow()
		if not r or not SuiviCanEditRow(r) then return end
		OpenSuiviEditor(r, SidOf(r.name), r.name)
	end)
	btnDel = MiniBtn(side, gRespX(22) + bw + gRespX(12), BODYH - gRespY(66), bw, gRespY(44), "SUPPRIMER", "danger", function()
		local r = CurrentRow()
		if not r or not SuiviCanEditRow(r) then return end
		local lp = LocalPlayer()
		if lp.OpenYesNoPopup then
			lp:OpenYesNoPopup("Supprimer définitivement la fiche de "
				.. (r.name ~= "" and r.name or "cet aspirant") .. " ?", "FactionSuiviDelete", { id = r.id })
		else
			net.Start("server:lzy_faction.SuiviDelete") net.WriteUInt(r.id, 32) net.SendToServer()
		end
	end)

	-- ── Contenu ─────────────────────────────────────────────────────────────
	local function VisibleRows()
		local out = {}
		for _, r in ipairs(SUIVI.rows) do
			local bOk = SuiviMatchFilter(r, SUIVI.filter)
			if bOk and SUIVI.search ~= "" then
				bOk = string.find(string.lower(r.name or ""), SUIVI.search, 1, true) ~= nil
					or string.find(string.lower(r.formateur or ""), SUIVI.search, 1, true) ~= nil
			end
			if bOk then out[#out + 1] = r end
		end
		return out
	end

	function f:Rebuild()
		local lp = LocalPlayer()
		local sid = IsValid(lp) and lp:SteamID64() or ""
		stats.total, stats.mine, stats.ok, stats.wait = #SUIVI.rows, 0, 0, 0
		for _, r in ipairs(SUIVI.rows) do
			if (r.fsid or "") == sid then stats.mine = stats.mine + 1 end
			local v = string.lower(tostring(r.verdict or ""))
			if string.find(v, "valid", 1, true) then
				stats.ok = stats.ok + 1
			elseif v == "" or string.find(v, "attente", 1, true) then
				stats.wait = stats.wait + 1
			end
		end

		scroll:Clear()
		local tShown = VisibleRows()
		if #tShown == 0 then
			local lbl = scroll:Add("DLabel")
			lbl:Dock(TOP) lbl:DockMargin(0, gRespY(40), 0, 0)
			lbl:SetTall(gRespY(60)) lbl:SetFont("Bebas Neue:22")
			lbl:SetTextColor(S_COL_MUTED) lbl:SetContentAlignment(5)
			lbl:SetText((SUIVI.search ~= "" or SUIVI.filter ~= "all")
				and "Aucune fiche ne correspond." or "Aucune fiche pour le moment.")
			RebuildDetail()
			return
		end

		for i, r in ipairs(tShown) do
			local bMine = SuiviCanEditRow(r)
			local row = scroll:Add("DButton")
			row:Dock(TOP) row:DockMargin(gRespX(8), 0, gRespX(8), gRespY(5))
			row:SetTall(gRespY(52)) row:SetText("") row:SetCursor("hand")
			row.Paint = function(sb, w, h)
				local hf = EVO_UI.HoverFrac(sb, 10)
				local bSel = (SUIVI.sel == r.id)
				local base = (i % 2 == 0) and 17 or 22
				if bSel then
					S_SCRATCH.r, S_SCRATCH.g, S_SCRATCH.b, S_SCRATCH.a = 40, 26, 30, 246
				else
					S_SCRATCH.r = Lerp(hf, base, 34)
					S_SCRATCH.g = Lerp(hf, base + 2, 37)
					S_SCRATCH.b = Lerp(hf, base + 7, 44)
					S_SCRATCH.a = 238
				end
				EVO_UI.PaintCut(0, 0, w, h, S_SCRATCH, gRespY(7), "br")
				if bMine then
					surface.SetDrawColor(S_COL_ACC)
					surface.DrawRect(0, 0, gRespX(3), h)
				end

				local cw = w - gRespX(14) - gRespX(10)
				local x = gRespX(14)
				for _, c in ipairs(COLS) do
					local colw = cw * c.f
					local v
					if c.k == "date" then
						v = (r.date or 0) > 0 and os.date("%d/%m/%y", r.date) or "-"
					elseif c.k == "dwant" then
						v = (r.dwant or 0) > 1 and SuiviDivName(r.dwant) or "-"
					else
						v = r[c.k]
						if v == nil or v == "" then v = "-" end
					end
					v = tostring(v)
					if c.k == "verdict" and v ~= "-" then
						-- Pastille colorée : l'état se lit d'un coup d'œil.
						local col = SuiviVerdictCol(v)
						surface.SetFont("Bebas Neue:17")
						local tw = surface.GetTextSize(v)
						local pw = math.min(tw + gRespX(18), colw - gRespX(8))
						S_PILL.r, S_PILL.g, S_PILL.b = col.r, col.g, col.b
						RNDX.Draw(gRespY(10), x, h / 2 - gRespY(11), pw, gRespY(22), S_PILL)
						draw.SimpleText(EVO_UI.TruncText(v, "Bebas Neue:17", pw - gRespX(10)),
							"Bebas Neue:17", x + pw / 2, h / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(EVO_UI.TruncText(v, "Bebas Neue:19", colw - gRespX(10)),
							"Bebas Neue:19", x, h / 2, (c.k == "name") and S_COL_TITLE or S_COL_MUTED,
							TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
					x = x + colw
				end
			end
			row.DoClick = function()
				SUIVI.sel = r.id
				RebuildDetail()
			end
			-- Double-clic : ouvre directement l'éditeur (raccourci du bouton MODIFIER).
			row.DoDoubleClick = function()
				SUIVI.sel = r.id
				RebuildDetail()
				if not SuiviCanEditRow(r) then
					MUGEN.Notify("Fiche suivie par " .. (((r.formateur or "") ~= "") and r.formateur or "un autre formateur")
						.. " : lecture seule.", NOTIFY_ERROR, 5)
					return
				end
				OpenSuiviEditor(r, SidOf(r.name), r.name)
			end
		end
		RebuildDetail()
	end

	local x = vgui.Create("DButton", f)
	x:SetText("") x:SetSize(gRespX(38), gRespY(38)) x:SetPos(W - gRespX(62), gRespY(34))
	x.Paint = function(sb, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:28", w / 2, h / 2,
			sb:IsHovered() and S_COL_ACC or S_COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() f:Remove() end

	f:Rebuild()
	net.Start("server:lzy_faction.SuiviRequest") net.SendToServer()
end
