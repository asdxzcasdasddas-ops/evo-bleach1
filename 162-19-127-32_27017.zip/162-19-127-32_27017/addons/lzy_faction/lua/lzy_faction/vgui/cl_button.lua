-- "addons\\lzy_faction\\lua\\lzy_faction\\vgui\\cl_button.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Custom Button Panel for LZY Faction
local BUTTON = {}

-- FIX resolution non-16:9 : alias uniforme (min des axes) pour tout le fichier, cf.
-- cl_main.lua. Icones/PNG de texte et overlay category_selected restent carres/proportionnels.
local function gRespX(v) return gRespU(v) end
local function gRespY(v) return gRespU(v) end

function BUTTON:Init()
	self:SetText("")
	self:gSetSizeU(200, 60)
	self.textMaterial = nil
	self.iconMaterial = nil
	self.hovered = false
	self.enabled = true -- Add enabled state
	self.selected = false -- Add selected state
	self.textWidth = 120  -- Default text width
	self.textHeight = 30  -- Default text height
	self.iconWidth = 32   -- Default icon width
	self.iconHeight = 32  -- Default icon height
	self.iconScale = 1.0  -- Icon scale for hover effect
	self.targetIconScale = 1.0 -- Target icon scale for smooth animation
	self.centerIcon = false -- Whether to center the icon (for close button)
	self.underlineHover = false -- Whether to show underline on hover
	self.categorySelectedMaterial = nil
	self.selectedMatOffset = 0
end

function BUTTON:SetCategorySelectedMaterial(material)
	self.categorySelectedMaterial = material
end

function BUTTON:SetSelectedMatOffset(offset)
	self.selectedMatOffset = offset
end

function BUTTON:SetMaterials(textMat, iconMat)
	self.textMaterial = textMat
	self.iconMaterial = iconMat
	-- Auto-detect if we should center the icon (when no text material)
	self.centerIcon = (textMat == nil)
end

function BUTTON:SetUnderlineHover(enabled)
	self.underlineHover = enabled
end

function BUTTON:SetTextSize(width, height)
	self.textWidth = width or gRespX(120)
	self.textHeight = height or gRespY(30)
end

function BUTTON:SetIconSize(width, height)
	self.iconWidth = width or gRespX(32)
	self.iconHeight = height or gRespY(32)
end

function BUTTON:SetButtonSize(width, height)
	self:SetSize(width or gRespX(200), height or gRespY(60))
end

function BUTTON:SetSelected(selected)
	self.selected = selected
end

function BUTTON:IsSelected()
	return self.selected
end

function BUTTON:SetEnabled(enabled)
	self.enabled = enabled
end

function BUTTON:IsEnabled()
	return self.enabled
end

function BUTTON:OnCursorEntered()
	if not self.enabled then return end
	self.hovered = true
	self.targetIconScale = 1.2 -- Scale up icon by 20% on hover
end

function BUTTON:OnCursorExited()
	self.hovered = false
	self.targetIconScale = 1.0 -- Return icon to normal scale
end

function BUTTON:Think()
	-- Smooth icon scale animation
	if self.iconScale ~= self.targetIconScale then
		self.iconScale = self.iconScale + (self.targetIconScale - self.iconScale) * 0.1
	end
end

function BUTTON:Paint(w, h)
	-- Calculate opacity based on enabled state and hover
	local opacity
	if not self.enabled then
		opacity = 100 -- Very dim when disabled
	else
		opacity = self.hovered and 230 or 255 -- 230 = 255 * 0.9 (90% opacity)
	end
	
	local bgColor = self.hovered and Color(60, 60, 60, opacity) or Color(40, 40, 40, opacity)
	local borderColor = self.hovered and Color(100, 100, 100, opacity) or Color(80, 80, 80, opacity)
	
	-- Background
	-- draw.RoundedBox(8, 0, 0, w, h, bgColor)
	-- draw.RoundedBoxEx(8, 0, 0, w, 2, borderColor, true, true, false, false)
	-- draw.RoundedBoxEx(8, 0, h-2, w, 2, borderColor, false, false, true, true)
	-- draw.RoundedBoxEx(8, 0, 0, 2, h, borderColor, true, false, true, false)
	-- draw.RoundedBoxEx(8, w-2, 0, 2, h, borderColor, false, true, false, true)
	
	-- Icon (left side) - only icon scales on hover
	if self.iconMaterial then
		local iconW = self.iconWidth * self.iconScale
		local iconH = self.iconHeight * self.iconScale
		
		-- Position icon based on whether we're centering it or not
		local iconX, iconY
		if self.centerIcon then
			-- Center the icon in the button
			iconX = (w - iconW) / 2
			iconY = (h - iconH) / 2
		else
			-- Position icon on the left side (for buttons with text)
			iconX = 15 - ((iconW - self.iconWidth) / 2) -- Center the scaled icon
			iconY = (h - iconH) / 2
		end
		
		surface.SetDrawColor(255, 255, 255, opacity)
		surface.SetMaterial(self.iconMaterial)
		surface.DrawTexturedRect(iconX, iconY, iconW, iconH)
	end
	
	-- Text (right side) - positioned to show full text material (no scaling)
	if self.textMaterial then
		local textW = self.textWidth
		local textH = self.textHeight
		local iconSpace = self.iconMaterial and (self.iconWidth + 30) or 0 -- Space for icon + padding
		local availableWidth = w - iconSpace - 20 -- Available width after icon and padding
		
		-- Ensure text doesn't exceed available space
		local finalTextW = math.min(textW, availableWidth)
		local textX = iconSpace + 10 -- Start after icon space with some padding
		local textY = (h - textH) / 2
		
		surface.SetDrawColor(255, 255, 255, opacity)
		surface.SetMaterial(self.textMaterial)
		surface.DrawTexturedRect(textX, textY, finalTextW, textH)
	end
	
	-- Draw category selected overlay
	if self.selected and self.categorySelectedMaterial then
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(self.categorySelectedMaterial)
		surface.DrawTexturedRect(gRespX(90), gRespY(0 + self.selectedMatOffset), gRespX(135), gRespY(135))
	end
	
	-- Draw horizontal black line when hovered
	if self.underlineHover and self.hovered and self.enabled then
		surface.SetDrawColor(0, 0, 0, 230)
		surface.DrawRect(gRespX(15), h - gRespY(7), w - gRespX(30), gRespY(1))
	end
end

vgui.Register("lzy_faction_button", BUTTON, "DButton")
