-- "addons\\lzy_faction\\lua\\lzy_annonce_faction\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local announcementQueue = {}
local currentAnnouncement = nil
local announcementStartTime = 0
local fontCreated = false

-- Plaque DA de la bannière : coins coupés « Atelier » via EVO_UI si dispo, sinon
-- fallback RNDX arrondi. Remplace l'ex-texture PNG plein écran "lzy_annonce_bg.png"
-- (refonte DA EVO de la tête d'annonce, 2026-07-22).
local function AnnoncePlate(x, y, w, h, c, cut)
    if EVO_UI and EVO_UI.PaintCut then
        EVO_UI.PaintCut(x, y, w, h, c, cut)
    elseif RNDX then
        RNDX.Draw(cut, x, y, w, h, c)
    else
        surface.SetDrawColor(c) surface.DrawRect(x, y, w, h)
    end
end

-- Échelle responsive (base 1080) avec fallback si glibs pas encore prêt.
local function R(v)
    if gRespY then return gRespY(v) end
    return math.floor(v * (ScrH() / 1080))
end

local function EnsureFontCreated()
    if fontCreated then return end
    if gCreateRespFont then
        -- Bannière d'annonce (HUD) : polices d'origine conservées.
        gCreateRespFont("LZY_AnnonceFont", "Black Han Sans", 18, 500, true, false, false)
        gCreateRespFont("LZY_AnnonceFont_Bold", "Black Han Sans", 22, 800, true, false, false)
        -- Composer (DA EVO) — fontes AGRANDIES (demande user 07/23 « fonte + grosse »).
        gCreateRespFont("EVO_Annonce_Title", "Roboto", 25, 800)
        gCreateRespFont("EVO_Annonce_Body",  "Roboto", 20, 400)
        gCreateRespFont("EVO_Annonce_Btn",   "Roboto", 20, 700)
        gCreateRespFont("EVO_Annonce_Small", "Roboto", 16, 500)
        -- Bannière DA EVO (tête d'annonce à l'écran) : corps Roboto plus lisible.
        gCreateRespFont("EVO_Annonce_Banner_Body", "Roboto", 17, 500)
    else
        local ratio = ScrW() / 1920
        surface.CreateFont("LZY_AnnonceFont", {font = "Black Han Sans", size = 18 * ratio, weight = 500, antialias = true})
        surface.CreateFont("LZY_AnnonceFont_Bold", {font = "Black Han Sans", size = 22 * ratio, weight = 800, antialias = true})
        surface.CreateFont("EVO_Annonce_Title", {font = "Roboto", size = 25 * ratio, weight = 800, antialias = true})
        surface.CreateFont("EVO_Annonce_Body",  {font = "Roboto", size = 20 * ratio, weight = 400, antialias = true})
        surface.CreateFont("EVO_Annonce_Btn",   {font = "Roboto", size = 20 * ratio, weight = 700, antialias = true})
        surface.CreateFont("EVO_Annonce_Small", {font = "Roboto", size = 16 * ratio, weight = 500, antialias = true})
        surface.CreateFont("EVO_Annonce_Banner_Body", {font = "Roboto", size = 17 * ratio, weight = 500, antialias = true})
    end
    fontCreated = true
end

-- ============================================================================
-- COMPOSER « ANNONCE FACTION » (super-admin) — DA EVO : backdrop flouté, carte
-- sombre arrondie SANS bordure, un seul accent rouge (#cf444e), croix standard.
-- Sobre. (Ce n'est PAS l'annonce de division.)
-- ============================================================================
local function OpenAnnonceUI()
    EnsureFontCreated()
    local col = (EVO_UI and EVO_UI.Col) or {
        bg = Color(16, 16, 19, 250), divider = Color(255, 255, 255, 18),
        title = Color(238, 239, 243), muted = Color(150, 154, 162),
        dim = Color(106, 109, 118), accent = Color(207, 68, 78),
    }
    -- DESTINATAIRES (09/01, demande user) : un grade 10+ (non-SA) peut viser une
    -- division/ordre PRECIS de sa faction — meme pas la sienne — ou toute la
    -- faction. Chips construites depuis LZY_FACTION_CONFIG.divisions (1 = "Aucune",
    -- ignoree). La carte grandit d'une rangee quand le choix existe.
    local bSA = LocalPlayer():IsSuperAdmin()
    local sOwnFaction = LocalPlayer():GetEvoNWString("FactionName")
    local tDivChips = nil
    if not bSA then
        local tDivs = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions
            and LZY_FACTION_CONFIG.divisions[sOwnFaction]
        if istable(tDivs) then
            tDivChips = { { "Toute la faction", 0 } }
            for i = 2, #tDivs do
                if tDivs[i] and tDivs[i] ~= "Aucune" then
                    tDivChips[#tDivChips + 1] = { tDivs[i], i }
                end
            end
            if #tDivChips <= 1 then tDivChips = nil end
        end
    end
    local bDivRow = tDivChips ~= nil

    local CARD_W, CARD_H = 540, bDivRow and 424 or 320
    local maxCharsPerLine = 100 -- 60 -> 100 (08/16, demande user : ~200 caracteres au total)

    -- UI AGRANDIE (demande user 07/23 « augmente la taille de l'UI ») : on met à l'échelle TOUTE
    -- la mise en page en redéfinissant R localement (× US). Les fontes ont été grossies en
    -- parallèle -> tout grandit ensemble, mêmes proportions (aucun texte qui déborde).
    local US = 1.4
    local _R = R
    local R = function(v) return _R(v * US) end

    -- Backdrop plein écran (flou + assombrissement, fondu).
    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
    frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
    frame:SetPaintBackgroundEnabled(false) frame:MakePopup()
    if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
    frame._a = 0
    frame.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
    frame.Paint = function(s, w, h)
        local a = s._a / 255
        if a < 0.01 then return end
        if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 5) end
        surface.SetDrawColor(0, 0, 0, 150 * a) surface.DrawRect(0, 0, w, h)
    end
    frame.OnMousePressed = function() if IsValid(frame) then frame:Remove() end end

    -- Carte centrée.
    local cardW, cardH = R(CARD_W), R(CARD_H)
    local card = vgui.Create("DPanel", frame)
    card:SetSize(cardW, cardH)
    card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
    card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
    card.Paint = function(s, w, h)
        local a = (frame and frame._a or 255) / 255
        if EVO_UI then EVO_UI.PaintCard(w, h, a, R(16)) else RNDX.Draw(R(16), 0, 0, w, h, col.bg) end
        surface.SetDrawColor(ColorAlpha(col.accent, 255 * a)) surface.DrawRect(R(24), R(24), R(3), R(18))
        draw.SimpleText("ANNONCE FACTION", "EVO_Annonce_Title", R(38), R(33), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        surface.SetDrawColor(ColorAlpha(col.divider, 150 * a)) surface.DrawRect(R(24), R(64), w - R(48), 1)
        draw.SimpleText("FACTION CIBLÉE", "EVO_Annonce_Small", R(24), R(80), ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        if bDivRow then
            draw.SimpleText("DESTINATAIRES", "EVO_Annonce_Small", R(24), R(144), ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
        draw.SimpleText("MESSAGE", "EVO_Annonce_Small", R(24), R(bDivRow and 248 or 144), ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    -- Croix de fermeture standard (gris -> rouge au survol).
    local x = vgui.Create("DButton", card) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(CARD_W - 42), R(19))
    x.Paint = function(s, w, h)
        if s:IsHovered() then RNDX.Draw(R(8), 0, 0, w, h, Color(34, 34, 41, 245)) end
        draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = function() frame:Remove() end

    -- Sélecteur de faction : 3 chips pour les SA (valeurs EXACTES attendues par le serveur).
    -- Hauts gradés 14+ (demande user 07/26) : cible VERROUILLÉE sur leur faction — 1 seul
    -- chip, et le serveur force de toute façon la faction de l'émetteur.
    local target = bSA and "Shinigami" or sOwnFaction
    local chipDefs = bSA
        and { { "Shinigami", "Shinigami" }, { "Hollow", "Hollow" }, { "Les deux", "Shinigami & Hollow" } }
        or { { sOwnFaction, sOwnFaction } }
    local chipW, chipGap = 156, 10
    for i, d in ipairs(chipDefs) do
        local label, value = d[1], d[2]
        local b = vgui.Create("DButton", card)
        b:SetText("")
        b:SetPos(R(24 + (i - 1) * (chipW + chipGap)), R(102))
        b:SetSize(R(chipW), R(32))
        b.Paint = function(s, w, h)
            local sel, hov = (target == value), s:IsHovered()
            if sel then
                RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(col.accent, 235))
            else
                RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(color_white, hov and 14 or 6))
                RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.muted, hov and 60 or 26), 1)
            end
            draw.SimpleText(label, "EVO_Annonce_Btn", w / 2, h / 2, sel and color_white or (hov and col.title or col.muted), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function() target = value end
    end

    -- Chips DESTINATAIRES (grades non-SA) : "Toute la faction" + chaque
    -- division/ordre de SA faction, 3 par rangee. COCHABLES (multi-selection,
    -- 09/01) : plusieurs divisions peuvent recevoir la meme annonce ; aucune
    -- cochee = toute la faction. Le serveur revalide et filtre.
    local tDivSel = {} -- { [index] = true } ; vide = toute la faction
    if bDivRow then
        local dW, dGap = 156, 10
        for i, d in ipairs(tDivChips) do
            local label, value = d[1], d[2]
            local nRow, nCol = math.floor((i - 1) / 3), (i - 1) % 3
            local b = vgui.Create("DButton", card)
            b:SetText("")
            b:SetPos(R(24 + nCol * (dW + dGap)), R(166 + nRow * 38))
            b:SetSize(R(dW), R(32))
            b.Paint = function(s2, w, h)
                local sel = (value == 0) and (next(tDivSel) == nil) or (value ~= 0 and tDivSel[value] == true)
                local hov = s2:IsHovered()
                if sel then
                    RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(col.accent, 235))
                else
                    RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(color_white, hov and 14 or 6))
                    RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.muted, hov and 60 or 26), 1)
                end
                draw.SimpleText(label, "EVO_Annonce_Small", w / 2, h / 2, sel and color_white or (hov and col.title or col.muted), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            b.DoClick = function()
                if value == 0 then
                    tDivSel = {}
                else
                    tDivSel[value] = (not tDivSel[value]) or nil
                end
            end
        end
    end

    -- Zone de texte (2 lignes / 60 caractères max).
    local entry = vgui.Create("DTextEntry", card)
    entry:SetPos(R(24), R(bDivRow and 270 or 166)) entry:SetSize(R(CARD_W - 48), R(74))
    entry:SetFont("EVO_Annonce_Body")
    entry:SetMultiline(true)
    entry:SetDrawLanguageID(false)
    entry:SetUpdateOnType(true)
    entry:SetTextColor(col.title)
    entry:SetPaintBackground(false)
    entry.Paint = function(s, w, h)
        RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(Color(8, 8, 10), 230))
        RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.muted, s:HasFocus() and 70 or 30), 1)
        s:DrawTextEntryText(col.title, col.accent, col.title)
        if not s:HasFocus() and s:GetValue() == "" then
            draw.SimpleText("Écris ton annonce ici…  (2 lignes max, 100 car./ligne)", "EVO_Annonce_Body", R(10), R(10), ColorAlpha(col.dim, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
    end

    -- Compteur de caractères (sous la zone, aligné à droite).
    local lblCount = vgui.Create("DLabel", card)
    lblCount:SetPos(R(24), R(bDivRow and 348 or 244)) lblCount:SetSize(R(CARD_W - 48), R(16))
    lblCount:SetFont("EVO_Annonce_Small")
    lblCount:SetTextColor(col.dim)
    lblCount:SetContentAlignment(6) -- droite
    lblCount:SetText("L1 0/" .. maxCharsPerLine .. "   L2 0/" .. maxCharsPerLine)

    entry.OnValueChange = function(self, value)
        local changed = false
        local lines = string.Explode("\n", value)
        if #lines > 2 then lines = { lines[1], lines[2] } changed = true end
        for i, line in ipairs(lines) do
            if #line > maxCharsPerLine then lines[i] = string.sub(line, 1, maxCharsPerLine) changed = true end
        end
        local newText = table.concat(lines, "\n")
        if changed and newText ~= value then
            self:SetText(newText) self:SetCaretPos(#newText)
        end
        lblCount:SetText("L1 " .. #(lines[1] or "") .. "/" .. maxCharsPerLine .. "   L2 " .. #(lines[2] or "") .. "/" .. maxCharsPerLine)
    end

    -- Bouton ENVOYER (accent plein).
    local send = vgui.Create("DButton", card)
    send:SetText("")
    send:SetPos(R(24), R(bDivRow and 374 or 270)) send:SetSize(R(CARD_W - 48), R(34))
    send.Paint = function(s, w, h)
        local hov = s:IsHovered()
        RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(col.accent, hov and 255 or 220))
        draw.SimpleText("ENVOYER L'ANNONCE", "EVO_Annonce_Btn", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    send.DoClick = function()
        local text = entry:GetValue()
        if not target or string.Trim(text or "") == "" then return end
        frame:Remove()
        net.Start("LZY_SendAnnonce")
        net.WriteString(target)
        net.WriteString(text)
        local nDivMask = 0
        for i in pairs(tDivSel) do nDivMask = bit.bor(nDivMask, bit.lshift(1, i)) end
        net.WriteUInt(nDivMask, 32) -- masque des divisions cochees, 0 = toute la faction
        net.SendToServer()
    end
end

net.Receive("LZY_OpenAnnonceUI", function() OpenAnnonceUI() end)

-- Accès externe : bouton "ANNONCE FACTION" de l'onglet gestion de faction (hauts gradés
-- 14+ et SA — le serveur revalide l'émission de toute façon).
LZY_AnnonceFaction_Open = OpenAnnonceUI

net.Receive("LZY_AnnonceFaction", function()
    local faction = net.ReadString()
    local text = net.ReadString()
    local duration = net.ReadFloat()
    local author = string.sub(string.gsub(net.ReadString() or "", "[\r\n]", " "), 1, 48)
    table.insert(announcementQueue, {faction = faction, text = text, duration = duration, author = author, fadeInTime = 0.5, fadeOutTime = 0.5})
    -- Trace relisible dans le chat custom (canal ANNONCE) — la bannière HUD s'efface.
    local sChat = string.gsub(text or "", "[\r\n]+", " ")
    local sLine
    if author ~= "" and faction ~= "" then
        sLine = "[Annonce faction] " .. author .. " · " .. faction .. " : " .. sChat
    elseif author ~= "" then
        sLine = "[Annonce faction] " .. author .. " : " .. sChat
    else
        sLine = "[Annonce faction] " .. sChat
    end
    if LZY_Chat_AddAnnonceLine then
        LZY_Chat_AddAnnonceLine(sLine)
    elseif LZY_Chat_AddSystemLine then
        LZY_Chat_AddSystemLine("annonce", sLine)
    else
        chat.AddText(Color(207, 68, 78), sLine)
    end
end)

-- DrawOverlay (pas HUDPaint) : au-dessus du VGUI — menus inventaire / faction /
-- shop ouverts ne doivent pas masquer l'annonce (demande user 10/06).
hook.Add("DrawOverlay", "LZY_AnnonceFaction_Draw", function()
    EnsureFontCreated()
    if not currentAnnouncement and #announcementQueue > 0 then
        currentAnnouncement = table.remove(announcementQueue, 1)
        announcementStartTime = CurTime()
        -- Cloche à l'apparition de la bannière (demande user 08/05), comme les annonces
        -- de division (lzy_hud) : même son pour TOUTES les annonces faction.
        surface.PlaySound("tgw7tau20hu4/bell_sfx.wav")
    end
    if not currentAnnouncement then return end

    local currentTime = CurTime()
    local elapsed = currentTime - announcementStartTime
    local alpha = 255
    if elapsed < currentAnnouncement.fadeInTime then
        alpha = math.Round(255 * (elapsed / currentAnnouncement.fadeInTime))
    elseif elapsed > currentAnnouncement.duration - currentAnnouncement.fadeOutTime then
        local fadeOutProgress = (elapsed - (currentAnnouncement.duration - currentAnnouncement.fadeOutTime)) / currentAnnouncement.fadeOutTime
        alpha = math.Round(255 * (1 - fadeOutProgress))
    end
    if elapsed >= currentAnnouncement.duration then
        currentAnnouncement = nil
        announcementStartTime = 0
        return
    end
    if alpha <= 0 then return end

    -- ── Bannière DA EVO (2026-07-22) : plaque sombre à coins coupés + accent rouge,
    --    faction ciblée en chip, auto-dimensionnée au contenu, centrée près du haut.
    --    (Ex-texture PNG plein écran "lzy_annonce_bg.png" remplacée.) ──
    local a = alpha / 255
    local col = (EVO_UI and EVO_UI.Col) or {
        title = Color(238, 239, 243), muted = Color(150, 154, 162),
        dim = Color(106, 109, 118), accent = Color(207, 68, 78),
        divider = Color(255, 255, 255, 18),
    }

    local titleTxt  = "ANNONCE FACTION"
    local titleFont = "EVO_UI_Header"
    local bodyFont  = "EVO_Annonce_Banner_Body"
    local tagFont   = "EVO_Annonce_Small"

    local factionTag = string.upper(currentAnnouncement.faction or "")
    local authorTxt = (currentAnnouncement.author and currentAnnouncement.author ~= "") and ("par " .. currentAnnouncement.author) or ""
    local lines = string.Explode("\n", currentAnnouncement.text or "")
    if #lines > 2 then lines = { lines[1], lines[2] } end

    -- Mesures du contenu.
    surface.SetFont(titleFont)
    local titleW, titleH = surface.GetTextSize(titleTxt)
    surface.SetFont(tagFont)
    local tagW, tagH = surface.GetTextSize(factionTag)
    local authorW = 0
    if authorTxt ~= "" then authorW = surface.GetTextSize(authorTxt) end

    local bodyLineH = draw.GetFontHeight(bodyFont)
    local bodyGap   = gRespY(4)
    surface.SetFont(bodyFont)
    local bodyMaxW = 0
    for _, line in ipairs(lines) do
        local lw = surface.GetTextSize(line)
        if lw > bodyMaxW then bodyMaxW = lw end
    end
    local bodyH = #lines * bodyLineH + math.max(0, #lines - 1) * bodyGap

    -- Géométrie carte (auto-dimensionnée).
    local padX, padY   = gRespX(30), gRespY(20)
    local accentW      = gRespX(3)
    local accentGap    = gRespX(12)
    local tagPadX      = gRespX(10)
    local tagBoxW      = (factionTag ~= "") and (tagW + tagPadX * 2) or 0
    local tagChipGap   = (factionTag ~= "") and gRespX(18) or 0
    local headerW      = accentW + accentGap + titleW + tagChipGap + tagBoxW
    local titleBodyGap = gRespY(14)

    local authorGap = (authorTxt ~= "") and gRespY(4) or 0
    local authorH   = (authorTxt ~= "") and draw.GetFontHeight(tagFont) or 0
    local contentW = math.max(headerW, bodyMaxW, authorW)
    local cardW = math.min(contentW + padX * 2, gRespX(1100))
    local cardH = padY + titleH + authorGap + authorH + titleBodyGap + bodyH + padY
    local cardX = math.floor((ScrW() - cardW) / 2)
    -- Sous le bandeau de lieu (division / TP) et les libellés compass
    -- (terrain d'entraînement, RPK) : sinon la carte passe derrière.
    local cardY = gRespY(52)
    local occupied = 0
    if BleachCompass_ZoneLabelsBottomY then
        occupied = math.max(occupied, BleachCompass_ZoneLabelsBottomY())
    end
    if EVO_ZoneBanner and EVO_ZoneBanner.GetBottomY then
        occupied = math.max(occupied, EVO_ZoneBanner.GetBottomY())
    end
    if occupied > 0 then
        cardY = math.max(cardY, occupied + gRespY(16))
    end
    local cut   = gRespY(14)

    -- Plaque + liseré 1px subtil (DA : fond noir plat, pas de bordure grise franche).
    AnnoncePlate(cardX, cardY, cardW, cardH, ColorAlpha(Color(13, 14, 17), 250 * a), cut)
    if EVO_UI and EVO_UI.OutlineCut and EVO_UI.CutPoints then
        EVO_UI.OutlineCut(EVO_UI.CutPoints(cardX + 1, cardY + 1, cardW - 2, cardH - 2, cut), ColorAlpha(col.divider, 150 * a))
    end

    -- En-tête : barre d'accent rouge + titre (gauche) + chip faction ciblée (droite).
    local hx  = cardX + padX
    local hcy = cardY + padY + titleH / 2
    surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
    surface.DrawRect(hx, hcy - titleH / 2 + gRespY(2), accentW, titleH - gRespY(4))
    draw.SimpleText(titleTxt, titleFont, hx + accentW + accentGap, hcy, ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    if factionTag ~= "" then
        local chipH = tagH + gRespY(7)
        local chipX = cardX + cardW - padX - tagBoxW
        local chipY = hcy - chipH / 2
        AnnoncePlate(chipX, chipY, tagBoxW, chipH, ColorAlpha(col.accent, 45 * a), gRespY(5))
        draw.SimpleText(factionTag, tagFont, chipX + tagBoxW / 2, chipY + chipH / 2, ColorAlpha(col.accent, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    if authorTxt ~= "" then
        draw.SimpleText(authorTxt, tagFont, hx + accentW + accentGap, cardY + padY + titleH + authorGap, ColorAlpha(col.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    -- Corps (centré sous l'en-tête).
    local by = cardY + padY + titleH + authorGap + authorH + titleBodyGap
    for _, line in ipairs(lines) do
        draw.SimpleText(line, bodyFont, cardX + cardW / 2, by, ColorAlpha(col.title, 235 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        by = by + bodyLineH + bodyGap
    end
end)
