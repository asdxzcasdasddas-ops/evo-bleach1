-- "addons\\lzy_faction\\lua\\autorun\\lzy_faction_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_faction/config.lua")
	AddCSLuaFile("lzy_faction/cl_report_images.lua")
	AddCSLuaFile("lzy_faction/vgui/cl_button.lua")
	AddCSLuaFile("lzy_faction/vgui/cl_collapsible_list.lua")
	AddCSLuaFile("lzy_faction/vgui/cl_selectbox.lua")
	AddCSLuaFile("lzy_faction/vgui/cl_main.lua")

	include("lzy_faction/config.lua")
	include("lzy_faction/net.lua")
	include("lzy_faction/sv_report_images.lua") -- preuve image des rapports (upload/stream)
else
	include("lzy_faction/config.lua")
	include("lzy_faction/cl_report_images.lua") -- AVANT cl_main (qui consomme LZYF_ReportImage)
	include("lzy_faction/vgui/cl_button.lua")
	include("lzy_faction/vgui/cl_collapsible_list.lua")
	include("lzy_faction/vgui/cl_selectbox.lua")
	include("lzy_faction/vgui/cl_main.lua")
end
