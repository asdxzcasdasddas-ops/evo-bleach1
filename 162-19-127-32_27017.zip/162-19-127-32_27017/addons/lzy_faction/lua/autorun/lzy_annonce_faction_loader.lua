-- "addons\\lzy_faction\\lua\\autorun\\lzy_annonce_faction_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_annonce_faction/cl_main.lua")
    include("lzy_annonce_faction/sv_main.lua")
    
    resource.AddFile("materials/lzy_annonce_bg.png")
else
    include("lzy_annonce_faction/cl_main.lua")
end
