-- "addons\\evo_cachot\\lua\\autorun\\client\\cl_evo_cachot.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- EVO CACHOT — client : prompt « [F] Fermer / Ouvrir » devant une cellule.
-- Même patte graphique que le « [E] S'allonger » d'evo_repos (keycap + libellé
-- sur une plaque sombre) : c'est la même grammaire d'interaction, elle doit se
-- lire pareil.

local C = EVO_CACHOT

local COL_BG     = Color(14, 14, 17, 225)
local COL_TXT    = Color(238, 239, 243, 255)
local COL_KEY    = Color(207, 68, 78, 255) -- keycap : accent maison

local function S(v) return math.Round(v * (ScrH() / 1080)) end

local function makeFonts()
	surface.CreateFont("EVO_Cachot_Key",   { font = "Bebas Neue", size = S(20), weight = 600, antialias = true })
	surface.CreateFont("EVO_Cachot_Label", { font = "Bebas Neue", size = S(26), weight = 500, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO_Cachot::Fonts", makeFonts)

-- État reçu du serveur, par battant. Pas de variable réseau sur la porte : le
-- NW1 est banni du projet, le NW2 réservé à un fichier allowlisté. Table FAIBLE
-- pour ne pas retenir des portes détruites au changement de map.
local LOCKED = setmetatable({}, { __mode = "k" })

net.Receive("EVO_Cachot:State", function()
	local n = net.ReadUInt(8)
	for _ = 1, n do
		local d = net.ReadEntity()
		local b = net.ReadBool()
		if IsValid(d) then LOCKED[d] = b or nil end
	end
end)

-- Une cellule est verrouillée si AU MOINS un battant l'est (même règle que le
-- serveur) : sinon une cellule à moitié fermée proposerait « Fermer » et
-- resterait ouverte pour toujours.
local function zoneLocked(tDoors)
	for _, d in ipairs(tDoors) do
		if LOCKED[d] then return true end
	end
	return false
end

local function drawKeyRow(cy, sKey, sLabel)
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(ScrW() * 0.5, cy, "", sLabel, sKey)
		return
	end
	surface.SetFont("EVO_Cachot_Label")
	local lw = surface.GetTextSize(sLabel)
	local keyR, gap = S(13), S(9)
	local totalW = keyR * 2 + gap + lw
	local x0 = ScrW() * 0.5 - totalW * 0.5

	local padX, padY = S(10), S(7)
	draw.RoundedBox(S(6), x0 - padX, cy - keyR - padY, totalW + padX * 2, keyR * 2 + padY * 2, COL_BG)
	local kx = x0 + keyR
	draw.RoundedBox(S(4), kx - keyR, cy - keyR, keyR * 2, keyR * 2, COL_KEY)
	draw.SimpleText(sKey, "EVO_Cachot_Key", kx, cy + S(1), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sLabel, "EVO_Cachot_Label", x0 + keyR * 2 + gap, cy, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

-- Scan de zone THROTTLÉ (~7 Hz), partagé HUD + touche : la cellule devant soi
-- ne change pas à la frame près, et ZoneNear finit sur des NearestPoint qui
-- allouent. Le HUD lit le dernier résultat ; per-frame il ne reste que des
-- lectures pures.
local _nScanNext, _vZone, _tDoors = 0, nil, nil
local function scanZone(lp)
	if CurTime() < _nScanNext then return _vZone, _tDoors end
	_nScanNext = CurTime() + 0.15
	_vZone = C.ZoneNear(lp:GetPos())
	_tDoors = _vZone and C.DoorsOfZone(_vZone) or nil
	return _vZone, _tDoors
end

hook.Add("HUDPaint", "EVO_Cachot::Prompt", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if vgui.CursorVisible() then return end
	-- Rien à afficher à qui n'a pas le droit : un prompt qu'on ne peut pas
	-- suivre est pire qu'aucun prompt.
	if not C.CanUse(lp) then return end
	local vZone, tDoors = scanZone(lp)
	if not vZone or not tDoors or #tDoors == 0 then return end

	-- Plus bas que le prompt d'evo_repos (user 23/08) : 0.74, la même hauteur
	-- que le prompt des pièges assassin, ça dégage le centre de l'écran.
	drawKeyRow(ScrH() * 0.74, "F",
		zoneLocked(tDoors) and "Ouvrir la cellule" or "Fermer la cellule")
end)

-- Envoi à FRONT : la garde est le front de touche (down and not wasF), donc au
-- plus un paquet par appui, plus le throttle serveur de 0,4 s.
-- netgate: edge
local function sendToggle()
	net.Start("EVO_Cachot:Toggle")
	net.SendToServer()
end

local wasF = false
hook.Add("Think", "EVO_Cachot::Key", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then wasF = false return end
	local down = input.IsKeyDown(KEY_F)
	local edge = down and not wasF
	wasF = down
	if not edge then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	-- Filtre CLIENT seulement : le serveur revalide zone, distance et droits.
	-- Le scan throttlé suffit ici aussi (150 ms de latence max sur un appui,
	-- imperceptible), et l'appui tombe presque toujours prompt affiché = cache chaud.
	if not C.CanUse(lp) then return end
	if not scanZone(lp) then return end
	sendToggle()
end)
