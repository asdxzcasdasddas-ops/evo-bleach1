-- "addons\\evo_cachot\\lua\\autorun\\sh_evo_cachot.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- EVO CACHOT — verrouillage des cellules (config + politique PARTAGÉES).
-- Les cellules du cachot sont de vraies portes (func_door_rotating) MAIS elles
-- sont habillées par des prop_dynamic SOLIDES posés devant : une visée à l'œil
-- tape toujours le décor. On travaille donc par PROXIMITÉ, jamais par trace.
-- ⚠ ADDON NOUVEAU = restart serveur, pas un simple refresh.

EVO_CACHOT = EVO_CACHOT or {}
local C = EVO_CACHOT

-- ── Zones, EN DUR et par map ────────────────────────────────────────────────
-- Une entrée PAR CELLULE (elles ont deux battants chacune). C'est la source
-- unique : elle vit dans git, donc elle survit à un redéploiement, à un wipe du
-- dossier data et à une nouvelle machine.
--
-- ⚠ LEÇON DU 23/08 : ces points ont été relevés EN VOL. Ils sont ~211 u
-- AU-DESSUS du sol où le joueur se tient (plancher du cachot z~1844, points
-- z~2055). Mesurer une distance joueur <-> POINT est donc faussé d'un montant
-- arbitraire : à 250 ça passait de justesse (211 < 250), à 130 plus RIEN ne
-- déclenchait. Ne jamais resserrer ce rayon-là en croyant régler une portée.
--
-- RÈGLE ACTUELLE : le point ne sert QU'À désigner les battants de la cellule.
-- La proximité du joueur se mesure ensuite sur LE BATTANT lui-même, ce qui est
-- de toute façon ce qu'on veut dire par « être devant la porte », et ce qui ne
-- dépend plus de la hauteur à laquelle les coordonnées ont été prises.
--   Radius     : distance à la PORTE qui déclenche le prompt.
--   DoorRadius : portée de recherche des battants AUTOUR DU POINT relevé. Reste
--                large : un battant est à ~161 u du point.
C.Radius     = 80
C.DoorRadius = 250
C.Zones = {
	["rp_seireitei_v1"] = {
		Vector(-1889.186523, 2622.760010, 2055.223877),
		Vector(-2135.063477, 2611.945801, 2055.210938),
		Vector(-1890.722290, 1275.274536, 2055.195068),
		Vector(-2135.721436, 1270.293579, 2055.223877),
	},
	["hueco_mundo_v1"] = {
		Vector(5856.392090, 361.221802, 6782.724121),
		Vector(5308.279785, 383.614258, 6782.394043),
		Vector(5326.370605, 1115.557983, 6782.695312),
		Vector(5862.846191, 1111.848633, 6782.553711),
		-- 2e aile du cachot (user 08/24), un niveau plus bas (z 6632).
		Vector(4675.967773, 1116.828491, 6632.724121),
		Vector(4162.946289, 1117.031982, 6632.724121),
		Vector(4162.020020, 375.134338, 6632.724121),
		Vector(4669.500977, 375.168488, 6632.724121),
	},
}

-- ── Qui garde le cachot, par map ────────────────────────────────────────────
-- Les index de division sont PARTAGÉS entre les deux factions (même slot, seul
-- le nom change) : 2 = Division 1 / Ordre 1 (commandement), 3 = Division 2 /
-- Ordre 2 (assassin). Côté arrancar ce sont les deux qui gèrent les prisonniers.
C.Divisions = {
	["rp_seireitei_v1"] = { [2] = true },
	["hueco_mundo_v1"]  = { [2] = true, [3] = true },
}
C.DivisionsDefault = { [2] = true }
C.MinRank  = 3
C.HighRank = 15

-- Classes que le moteur sait verrouiller. Un prop_dynamic n'en est PAS une : il
-- n'a ni entrée Lock ni entrée Open, c'est de l'habillage.
C.DoorClasses = {
	["prop_door"] = true, ["prop_door_rotating"] = true,
	["func_door"] = true, ["func_door_rotating"] = true,
}

function C.IsDoor(ent)
	return IsValid(ent) and C.DoorClasses[ent:GetClass()] == true
end

--- Cellule devant laquelle se tient le joueur, ou nil. Mesure sur LE BATTANT le
--- plus proche et PAS sur le point de config : cf. la note en haut du fichier,
--- ces points sont relevés en vol et leur Z ne veut rien dire.
function C.ZoneNear(vPos)
	local t = C.Zones[game.GetMap()]
	if not t then return nil end
	local nR = C.Radius
	-- Préfiltre SANS allocation : une cellule plus loin que ce majorant ne peut
	-- avoir aucun battant à portée (battant ≤ DoorRadius du point, +300 de marge
	-- pour le Z relevé en vol). Évite NearestPoint (alloue un Vector) et la
	-- boucle des portes sur les 3 cellules où l'on n'est pas.
	local nFar2 = (C.DoorRadius + nR + 300) ^ 2
	for _, v in ipairs(t) do
		if vPos:DistToSqr(v) <= nFar2 then
			for _, d in ipairs(C.DoorsOfZone(v)) do
				if d:NearestPoint(vPos):DistToSqr(vPos) <= nR * nR then return v end
			end
		end
	end
	return nil
end

--- Les DEUX battants d'une cellule. On mesure sur NearestPoint et pas sur
--- l'origine : un func_door_rotating est un BRUSH, son origine ne dit rien de
--- l'endroit où se trouve réellement le battant.
--- MIS EN CACHE : ZoneNear l'appelle depuis un Think client, un FindInSphere par
--- cellule et par frame serait du gaspillage pur. Les portes d'une map ne
--- bougent pas ; le cache se reconstruit si l'une d'elles devient invalide.
local _doorCache = {}
local _tEmpty = {} -- retour vide PARTAGÉ : jamais une table neuve par appel
function C.DoorsOfZone(vZone)
	if not vZone then return _tEmpty end
	-- Clé = LE Vector de config lui-même (référence stable tant que la table de
	-- zones vit). L'ancien tostring(vZone) fabriquait une STRING par appel — dans
	-- un HUDPaint, c'était du garbage à chaque frame.
	local tHit = _doorCache[vZone]
	if tHit then
		local bOk = true
		for _, d in ipairs(tHit) do
			if not IsValid(d) then bOk = false break end
		end
		if bOk then return tHit end
	end
	local out = {}
	local nR = C.DoorRadius
	for _, e in ipairs(ents.FindInSphere(vZone, nR)) do
		if C.IsDoor(e) and e:NearestPoint(vZone):Distance(vZone) <= nR then
			out[#out + 1] = e
		end
	end
	-- On ne met en cache que si on a TROUVÉ : au tout premier spawn les portes de
	-- la map peuvent ne pas être prêtes, il ne faut pas figer un résultat vide.
	if #out > 0 then _doorCache[vZone] = out end
	return out
end

--- Droit d'ouvrir/fermer. SOURCE UNIQUE : le prompt client et la validation
--- serveur la lisent tous les deux, sinon l'un afficherait ce que l'autre refuse.
function C.CanUse(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	local nRank = ply:GetEvoNWInt("FactionRank", 0)
	if nRank >= C.HighRank then return true end
	local tDiv = C.Divisions[game.GetMap()] or C.DivisionsDefault
	return tDiv[ply:GetEvoNWInt("FactionDivision", 0)] == true and nRank >= C.MinRank
end

--- Libellé des divisions habilitées, pour les refus. Passe par les VRAIS noms :
--- « division 3 » ne veut rien dire pour un joueur, et le nom change de faction.
function C.AllowedLabel(ply)
	local tDiv = C.Divisions[game.GetMap()] or C.DivisionsDefault
	local t = {}
	for nIdx in pairs(tDiv) do
		local s = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName
			and LZY_FACTION_CONFIG.DivisionName(ply, nIdx)
		t[#t + 1] = (isstring(s) and s ~= "") and s or ("division " .. nIdx)
	end
	table.sort(t)
	return table.concat(t, " et ")
end
