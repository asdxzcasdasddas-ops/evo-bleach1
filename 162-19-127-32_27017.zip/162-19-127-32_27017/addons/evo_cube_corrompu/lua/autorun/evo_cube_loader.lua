-- "addons\\evo_cube_corrompu\\lua\\autorun\\evo_cube_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- EVO CUBE CORROMPU : événement staff (clignement, pression, détonation,
-- étoile filante rouge) + cube posé en Zone Neutre II qui rend agressif les
-- joueurs qui s'en approchent (aura ORANGE en vision d'aura). Le soin est une
-- plante précise, volontairement documentée NULLE PART en jeu (lore).
if SERVER then
	AddCSLuaFile("evo_cube/sh_config.lua")
	AddCSLuaFile("evo_cube/cl_cube.lua")
	include("evo_cube/sh_config.lua")
	include("evo_cube/sv_cube.lua")
else
	include("evo_cube/sh_config.lua")
	include("evo_cube/cl_cube.lua")
end
