-- "addons\\evo_cube_corrompu\\lua\\evo_cube\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Config PARTAGÉE de l'événement du Cube corrompu. La timeline client se
-- calcule entièrement d'ici : changer une durée décale tout le reste.
EVO_CUBE = EVO_CUBE or {}

EVO_CUBE.CFG = {
	-- ── Timeline (secondes, côté client à réception du top départ) ──
	nClinFerme  = 0.9,  -- paupières qui se ferment (recette evo_blanc)
	nClinNoir   = 0.5,  -- noir complet
	nClinOuvre  = 1.0,  -- réouverture lente
	nPression   = 4.0,  -- pression spirituelle plein écran, « assez importante »
	nDelaiPressionBoom = 5.0, -- long silence entre la fin de la pression et la détonation (le reclignement a été RETIRÉ, user 08/28)
	nDelaiBoomEtoile   = 1.5, -- la détonation annonce l'étoile un temps après
	nEtoile     = 7.0,  -- traversée de l'étoile filante rouge (4 -> 7 s, user 08/28 « plus longtemps »)
	nFlash      = 0.4,  -- flash rouge de la détonation finale

	-- ── Sons (fichiers dédiés user 08/28, dossier hnztk71178zj) ──
	sSonBoom     = "hnztk71178zj/atterrissage_resonance.wav",         -- les DEUX détonations
	sSonPression = "hnztk71178zj/BAM_pression_spirituelle_clair.wav", -- la pression
	nSonPressionDur = 2, -- repli si SoundDuration ne lit pas le fichier (relance pendant la pression)

	-- ── Étoile filante : directions MONDE (fixes, tout le serveur voit la même) ──
	aEtoileDebut = Angle(-52, 35, 0),
	aEtoileFin   = Angle(-14, 95, 0),
	nEtoileDist  = 11000, -- distance du ciel (repère evo_ciel : tailles à ~12000)
	nEtoileLarge = 380,   -- largeur du sillage (regrossie ENCORE le 08/28)
	nEtoileCoeur = 1200,  -- taille du cœur lumineux en tête

	-- ── Le cube ──
	sModel      = "models/evo/props/items/evo_967grzgrtpolkiuhow/evo_967grZGRTpolkiuhow.mdl",
	sParticule  = "[0]aura_rouge", -- doit être dans un pcf MONTÉ (pack workshop)
	sLabel      = "Objet étrange", -- écrit au-dessus du modèle (3D2D)
	nLabelDist  = 700,             -- distance d'affichage de l'étiquette
	sItemPickup = "cube_objet_etrange", -- l'item donné au ramassage (E), enregistré plus bas
	nPickupDist = 110,                 -- portée du [E] (même repère que les ressources)
	nRayon      = 100,             -- distance de corruption (« quelques unités »)

	-- Plante qui SOIGNE la corruption. Commune, et son lore colle (« sa sève
	-- apaise les circuits de reiatsu »). PAS documentée en jeu, c'est voulu.
	sPlanteSoin = "feuille_lune",

	-- Position du cube par map (setpos user 08/28). Le z (-6283) tombe dans la
	-- bande Zone Neutre II du SEIREITEI (etage median, -8000 a -4500, cf.
	-- HarvestExcluBands) : l'ancre est donc sur rp_seireitei_v1.
	tAncres = {
		["rp_seireitei_v1"] = { pos = Vector(1842.053589, 585.359619, -6283.339844), yaw = 170.16 },
	},

	-- ── Point de vue de la CINÉMATIQUE de l'étoile (setpos user 08/28) ──
	-- Pendant la chute, la caméra de TOUT LE MONDE se pose ici : un joueur en
	-- intérieur voyait son plafond, maintenant il voit le même plan que les
	-- autres. Ce doit être un endroit DÉGAGÉ et à ciel ouvert (un point en
	-- plein void donnait un écran noir). Angle ignoré : la caméra vise
	-- l'étoile. Map absente = repli au-dessus de la tête du joueur.
	tCamEtoile = {
		["rp_seireitei_v1"] = Vector(1714.608276, -25.183125, -5402.598633),
	},
	nCamEtoileZ = 64, -- hauteur des yeux au-dessus du setpos (qui pose les PIEDS)

	-- ── La Cuve (Seireitei, setpos user 08/28) : on y DÉPOSE l'Objet étrange ──
	tCuves = {
		["rp_seireitei_v1"] = { pos = Vector(5484.653320, 7605.430664, 14740.523438) },
	},
	nCuveDist  = 130,       -- portée du [E] et de l'invite
	nCuveTexteZ = 8,        -- hauteur du texte au-dessus du point (baissé, user 08/28 « trop haut »)
	sCuveLabel = "La Cuve", -- écrit au-dessus (3D2D)
}

-- Bornes dérivées de la timeline : UNE seule vérité pour client ET serveur.
function EVO_CUBE.Timeline()
	local C = EVO_CUBE.CFG
	local nClin = C.nClinFerme + C.nClinNoir + C.nClinOuvre
	local t = {}
	t.nClin       = nClin
	t.tPression0  = nClin                       -- la pression part à la fin du clin
	t.tPression1  = t.tPression0 + C.nPression
	t.tBoom1      = t.tPression1 + C.nDelaiPressionBoom -- long silence, puis la détonation
	t.tEtoile0    = t.tBoom1 + C.nDelaiBoomEtoile
	t.tEtoile1    = t.tEtoile0 + C.nEtoile
	t.tTotal      = t.tEtoile1 + C.nFlash + 0.4
	return t
end

-- ── L'item « Objet étrange » (ramassage du cube) ─────────────────────────────
-- Enregistré dans ITEMS des DEUX côtés (l'UI inventaire lit la table client).
-- Volontairement INERTE : pas d'usage, un objet de lore à garder. L'item des
-- drops Hollow (Cube blanc) garde son nom et son Garganta, il est distinct.
local function RegisterObjetEtrange()
	if not istable(ITEMS) then return end
	if ITEMS["cube_objet_etrange"] then return end
	ITEMS["cube_objet_etrange"] = {
		name = "Objet étrange",
		description = "Cube parfaitement lisse, d'un blanc qui absorbe la lumière. Il est chaud au toucher, et quelque chose à l'intérieur semble battre.",
		category = "object",
		rarity = "legendary",
		model_path = EVO_CUBE.CFG.sModel,
		is_droppable = true,
		is_deletable = true,
		stack_max = 1,
	}
end
-- Retry idempotent : l'addon inventory RÉASSIGNE ITEMS à son include (même
-- piège que les drops Hollow) — on re-pose l'entrée pendant 30 s.
timer.Create("EVO_Cube::RegisterItem", 1, 30, RegisterObjetEtrange)
RegisterObjetEtrange()
