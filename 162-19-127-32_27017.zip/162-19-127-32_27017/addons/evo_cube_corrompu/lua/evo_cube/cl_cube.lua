-- "addons\\evo_cube_corrompu\\lua\\evo_cube\\cl_cube.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Cube corrompu, côté client : la séquence plein écran (paupières -> pression
-- -> détonation -> reclignement -> étoile filante rouge -> détonation), le
-- texte dramatique de corruption/soin, et le set des corrompus lu par la
-- vision d'aura (halo ORANGE).
local CFG = EVO_CUBE.CFG

PrecacheParticleSystem(CFG.sParticule)

-- ── Set des corrompus (SID64 -> true) + index du cube, poussés par le serveur ──
local tCorrompus = {}
local _nCubeIdx = 0

function EVO_CUBE.EstCorrompu(ply)
	if not IsValid(ply) then return false end
	local sid = ply.SteamID64 and ply:SteamID64()
	return sid ~= nil and tCorrompus[sid] == true
end

net.Receive("EVO_Cube::Sync", function()
	local nIdx = net.ReadUInt(16)
	if nIdx ~= _nCubeIdx then
		-- Cube retiré ou remplacé : couper la particule bouclée AVANT que
		-- l'entité disparaisse (leçon des traînées : l'émetteur survit sinon).
		local eOld = _nCubeIdx > 0 and Entity(_nCubeIdx) or nil
		if IsValid(eOld) then eOld:StopParticles() end
		_nCubeIdx = nIdx
	end
	tCorrompus = {}
	local n = net.ReadUInt(8)
	for _ = 1, n do
		tCorrompus[net.ReadString()] = true
	end
end)

-- ── Étiquette « Objet étrange » + attache de la particule (lazy : dès que
-- l'entité entre dans le PVS ; marquée sur l'entité pour ne l'attacher qu'une fois).
surface.CreateFont("EVOCube_Label", { font = "Bebas Neue", size = 72, weight = 500, antialias = true })
surface.CreateFont("EVOCube_LabelPetit", { font = "Bebas Neue", size = 40, weight = 500, antialias = true })

hook.Add("PostDrawTranslucentRenderables", "EVO_Cube::Etiquette", function(bDepth, bSky)
	if bDepth or bSky then return end
	if _nCubeIdx <= 0 then return end
	local e = Entity(_nCubeIdx)
	if not IsValid(e) then return end
	if not e._evoCubeFx then
		e._evoCubeFx = true
		ParticleEffectAttach(EVO_CUBE.CFG.sParticule, PATTACH_ABSORIGIN_FOLLOW, e, 0)
	end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local vPos = e:GetPos()
	local nDist = EVO_CUBE.CFG.nLabelDist or 700
	if lp:EyePos():DistToSqr(vPos) > nDist * nDist then return end
	local a = Angle(0, EyeAngles().y - 90, 90) -- billboard face au joueur
	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		-- Style invite partage (echelle 0.14 : meme hauteur de titre qu'avant).
		local nPick = EVO_CUBE.CFG.nPickupDist or 110
		local bPres = lp:EyePos():DistToSqr(vPos) <= nPick * nPick
		cam.Start3D2D(vPos + Vector(0, 0, 42), a, 0.14)
			EVO_ZonePrompt.Row(0, EVO_CUBE.CFG.sLabel, bPres and "Récupérer", "E", "point")
		cam.End3D2D()
		return
	end
	cam.Start3D2D(vPos + Vector(0, 0, 42), a, 0.1)
		draw.SimpleText(EVO_CUBE.CFG.sLabel, "EVOCube_Label", 2, 2,
			Color(0, 0, 0, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(EVO_CUBE.CFG.sLabel, "EVOCube_Label", 0, 0,
			Color(255, 150, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local nPick = EVO_CUBE.CFG.nPickupDist or 110
		if lp:EyePos():DistToSqr(vPos) <= nPick * nPick then
			draw.SimpleText("[E] Récupérer", "EVOCube_LabelPetit", 0, 54,
				Color(235, 235, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	cam.End3D2D()
end)

-- ── Texte dramatique personnel ──
surface.CreateFont("EVOCube_Msg", { font = "Bebas Neue", size = 52, weight = 500, antialias = true })
surface.CreateFont("EVOCube_Statut", { font = "Bebas Neue", size = 34, weight = 500, antialias = true })

local _msgT, _msgTxt, _msgCol = 0, "", color_white
local MSG_DUR = 6

net.Receive("EVO_Cube::Message", function()
	local bCorrompu = net.ReadBool()
	_msgT = RealTime()
	if bCorrompu then
		_msgTxt = "Une chaleur étrange t'envahit. Une poussée de violence et d'émotion te submerge."
		_msgCol = Color(255, 140, 20)
	else
		_msgTxt = "Ton esprit s'apaise. La colère s'éloigne."
		_msgCol = Color(120, 200, 255)
	end
end)

-- ── La séquence ──
local _t0 = 0
local _b1, _b2, _sndP1, _sndP2 = false, false, false, false

net.Receive("EVO_Cube::Event", function()
	_t0 = RealTime()
	_b1, _b2, _sndP1, _sndP2 = false, false, false, false
end)

-- Part de paupière fermée (0 à 1) pour un clignement démarré à tDebut
-- (recette evo_blanc : sinus à la fermeture, cosinus à la réouverture).
local function Paupiere(t, tDebut)
	local d = t - tDebut
	local F, N, O = CFG.nClinFerme, CFG.nClinNoir, CFG.nClinOuvre
	if d < 0 or d >= F + N + O then return 0 end
	if d < F then return math.sin((d / F) * math.pi / 2) end
	if d < F + N then return 1 end
	return math.cos(((d - F - N) / O) * math.pi / 2)
end

-- Enveloppe de la pression : montée 0.4 s, descente 0.5 s.
local function Pression(t, T)
	if t < T.tPression0 or t > T.tPression1 + 0.5 then return 0 end
	return math.min((t - T.tPression0) / 0.4, 1) * math.Clamp((T.tPression1 + 0.5 - t) / 0.5, 0, 1)
end

-- Traits de pluie de pression (recette ncm_coup_pression : aléatoire tiré à la
-- naissance du trait, chute déterministe, aucune alloc par frame hors renaissance).
local _traits = {}
local function DessinerTraits(nCount, nAlpha)
	local w, h = ScrW(), ScrH()
	local now = RealTime()
	draw.NoTexture()
	for i = 1, nCount do
		local l = _traits[i]
		if not l or now >= l.t1 then
			local nAng = math.pi * 0.5 + math.Rand(-0.07, 0.07)
			local nLen = math.Rand(0.12, 0.34) * h
			l = {
				x = math.Rand(0, w), y = -nLen,
				dx = math.cos(nAng), dy = math.sin(nAng), rot = -math.deg(nAng),
				len = nLen, th = math.random(1, 3),
				spd = math.Rand(1.3, 2.0) * h,
				t0 = now, t1 = now + math.Rand(0.45, 0.7),
			}
			_traits[i] = l
		end
		local f = 1 - math.abs((now - l.t0) / (l.t1 - l.t0) * 2 - 1)
		local d = l.spd * (now - l.t0) + l.len * 0.5
		surface.SetDrawColor(0, 0, 0, math.min(nAlpha * f, 255))
		surface.DrawTexturedRectRotated(l.x + l.dx * d, l.y + l.dy * d, l.len, l.th, l.rot)
	end
end

local _matGradDown = Material("gui/gradient_down") -- opaque en haut, transparent en bas

hook.Add("HUDPaintBackground", "EVO_Cube::Ecran", function()
	local w, h = ScrW(), ScrH()

	-- Texte dramatique (hors séquence : il vit sa propre fenêtre de 6 s).
	if _msgT > 0 then
		local d = RealTime() - _msgT
		if d > MSG_DUR then
			_msgT = 0
		else
			local a = math.min(d / 0.5, 1) * math.Clamp((MSG_DUR - d) / 1, 0, 1)
			draw.SimpleText(_msgTxt, "EVOCube_Msg", w / 2 + 2, h * 0.30 + 2,
				Color(0, 0, 0, 220 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(_msgTxt, "EVOCube_Msg", w / 2, h * 0.30,
				ColorAlpha(_msgCol, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Statut PERMANENT tant que la corruption est là (user 08/28 : « qu'il y
	-- ait écrit sur l'écran que tu as la maladie ») : texte qui pulse doucement.
	local lpS = LocalPlayer()
	if IsValid(lpS) and EVO_CUBE.EstCorrompu(lpS) then
		local aPulse = 150 + math.sin(RealTime() * 2.2) * 60
		draw.SimpleText("POUSSÉE DE VIOLENCE ET D'ÉMOTION", "EVOCube_Statut", w / 2 + 1, h * 0.085 + 1,
			Color(0, 0, 0, aPulse * 0.8), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("POUSSÉE DE VIOLENCE ET D'ÉMOTION", "EVOCube_Statut", w / 2, h * 0.085,
			Color(255, 140, 20, aPulse), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	if _t0 <= 0 then return end
	local T = EVO_CUBE.Timeline()
	local t = RealTime() - _t0
	if t > T.tTotal then _t0 = 0 return end
	local lp = LocalPlayer()

	-- Sons, déclenchés au fil de la timeline (flags une-fois).
	if IsValid(lp) then
		if not _sndP1 and t >= T.tPression0 then
			_sndP1 = true
			lp:EmitSound(CFG.sSonPression, 75, 100, 1)
		end
		-- Relance UNIQUEMENT si le clip est plus court que la pression et qu'on
		-- est encore dedans (durée lue du fichier, repli sur la config).
		local nDurP = SoundDuration(CFG.sSonPression) or 0
		if nDurP <= 0 then nDurP = CFG.nSonPressionDur or 2 end
		if not _sndP2 and t <= T.tPression1 and t >= T.tPression0 + nDurP - 0.05 then
			_sndP2 = true
			lp:EmitSound(CFG.sSonPression, 75, 100, 1)
		end
		if not _b1 and t >= T.tBoom1 then
			_b1 = true
			lp:EmitSound(CFG.sSonBoom, 80, 100, 1)
		end
		if not _b2 and t >= T.tEtoile1 then
			_b2 = true
			lp:EmitSound(CFG.sSonBoom, 80, 92, 1)
		end
	end

	-- Pression : voile du haut, voile global, traits.
	local fP = Pression(t, T)
	if fP > 0 then
		surface.SetDrawColor(0, 0, 0, math.floor(70 * fP))
		surface.DrawRect(0, 0, w, h)
		surface.SetMaterial(_matGradDown)
		surface.SetDrawColor(0, 0, 0, math.floor(235 * fP))
		surface.DrawTexturedRect(0, 0, w, math.floor(h * 0.55))
		DessinerTraits(24, 180 * fP)
	end

	-- Bandes cinématiques + ciel assombri pendant le focus (fondu 0.4 s).
	if t >= T.tEtoile0 - 0.4 and t <= T.tEtoile1 + 0.4 then
		local fB = math.min(math.Clamp((t - (T.tEtoile0 - 0.4)) / 0.4, 0, 1),
			math.Clamp(((T.tEtoile1 + 0.4) - t) / 0.4, 0, 1))
		-- Voile sombre : la nuit tombe le temps de la chute (user 08/28).
		surface.SetDrawColor(6, 2, 10, math.floor(110 * fB))
		surface.DrawRect(0, 0, w, h)
		local nB = math.floor(h * 0.12 * fB)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(0, 0, w, nB)
		surface.DrawRect(0, h - nB, w, nB)
	end

	-- Flash rouge de la détonation finale.
	if t >= T.tEtoile1 and t <= T.tEtoile1 + CFG.nFlash then
		local a = 1 - (t - T.tEtoile1) / CFG.nFlash
		surface.SetDrawColor(255, 60, 35, math.floor(120 * a))
		surface.DrawRect(0, 0, w, h)
	end

	-- Paupières : premier clin au top, second à la détonation.
	local f = Paupiere(t, 0) -- un seul clignement, au tout début (le 2e a été RETIRÉ, user 08/28)
	if f > 0 then
		local n = math.ceil(h * 0.5 * f)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(0, 0, w, n)
		surface.DrawRect(0, h - n, w, n)
		surface.SetDrawColor(0, 0, 0, math.floor(f * f * 200))
		surface.DrawRect(0, n, w, h - n * 2)
	end
end)

-- Écrasement colorimétrique de la pression (recette VictimCrush).
local _tCrush = {
	["$pp_colour_addr"] = 0, ["$pp_colour_addg"] = 0, ["$pp_colour_addb"] = 0,
	["$pp_colour_mulr"] = 0, ["$pp_colour_mulg"] = 0, ["$pp_colour_mulb"] = 0,
	["$pp_colour_brightness"] = 0, ["$pp_colour_contrast"] = 1, ["$pp_colour_colour"] = 1,
}
hook.Add("RenderScreenspaceEffects", "EVO_Cube::Crush", function()
	if _t0 <= 0 then return end
	local T = EVO_CUBE.Timeline()
	local t = RealTime() - _t0
	local fP = Pression(t, T)
	-- Assombrissement colorimétrique doux pendant la chute de l'étoile.
	local fE = 0
	if t >= T.tEtoile0 - 0.4 and t <= T.tEtoile1 + 0.4 then
		fE = math.min(math.Clamp((t - (T.tEtoile0 - 0.4)) / 0.4, 0, 1),
			math.Clamp(((T.tEtoile1 + 0.4) - t) / 0.4, 0, 1))
	end
	if fP < 0.01 and fE < 0.01 then return end
	_tCrush["$pp_colour_brightness"] = -0.08 * fP - 0.06 * fE
	_tCrush["$pp_colour_contrast"]   = 1 + 0.18 * fP
	_tCrush["$pp_colour_colour"]     = 1 - 0.5 * fP - 0.2 * fE
	DrawColorModify(_tCrush)
	if fP > 0.01 then DrawMotionBlur(0.12, 0.8 * fP, 0.01) end
end)

-- ── L'étoile filante rouge : directions MONDE fixes, dessinée à distance de
-- ciel (repère evo_ciel ~12000), donc la même pour tout le serveur. Occlusion
-- naturelle par la géométrie : un joueur sous un toit ne la voit pas, normal.
local _matBeam = Material("sprites/physbeam")
local COL_ETOILE  = Color(255, 60, 40, 255)
local COL_COEUR   = Color(255, 150, 110, 255)
local COL_HALO    = Color(255, 55, 35, 140) -- halo large autour du sillage

-- Position de l'étoile à l'avancement u (0 -> 1), partagée dessin + caméra.
local function PosEtoile(u, vEye)
	local v = LerpVector(u, CFG.aEtoileDebut:Forward(), CFG.aEtoileFin:Forward())
	v:Normalize()
	return vEye + v * CFG.nEtoileDist
end

-- L'étoile est dessinée DANS LE CIEL, comme la faille Garganta d'evo_ciel
-- (user 08/28 « fais comme l'ouverture de la faille dans le hueco ») : passe
-- PostDrawSkyBox + depth forcé, à distance fixe de l'œil. Elle fait PARTIE du
-- ciel : chacun la voit depuis chez lui, occultée par les toits comme la
-- faille, et plus jamais « dans le noir » d'un point de vue déporté.
hook.Add("PostDrawSkyBox", "EVO_Cube::Etoile", function()
	if _t0 <= 0 then return end
	local T = EVO_CUBE.Timeline()
	local t = RealTime() - _t0
	if t < T.tEtoile0 or t > T.tEtoile1 then return end
	local u = (t - T.tEtoile0) / CFG.nEtoile

	local vEye = EyePos()
	local vHead = PosEtoile(u, vEye)
	local vTail = PosEtoile(math.max(u - 0.26, 0), vEye)

	render.OverrideDepthEnable(true, false) -- même astuce que la faille (evo_ciel)
	render.SetMaterial(_matBeam)
	render.DrawBeam(vTail, vHead, CFG.nEtoileLarge * 2.2, 0, 1, COL_HALO) -- halo doux
	render.DrawBeam(vTail, vHead, CFG.nEtoileLarge, 0, 1, COL_ETOILE)
	-- Trois couches de lueur en tête : large, cœur, puis un centre blanc brûlant.
	local nCoeur = CFG.nEtoileCoeur or 1200
	render.DrawSprite(vHead, nCoeur * 1.8, nCoeur * 1.8, COL_HALO)
	render.DrawSprite(vHead, nCoeur, nCoeur, COL_COEUR)
	render.DrawSprite(vHead, nCoeur * 0.45, nCoeur * 0.45, Color(255, 235, 220, 255))
	render.OverrideDepthEnable(false, false)
end)

-- FOCUS CINÉMATIQUE (user 08/28) : pendant la chute, la caméra de tout le
-- monde suit le truc dans le ciel. La position du joueur est conservée, seuls
-- les angles sont pris (avec les bandes noires dessinées plus haut).
hook.Add("CalcView", "EVO_Cube::Focus", function(ply, origin, angles, fov)
	if _t0 <= 0 then return end
	local T = EVO_CUBE.Timeline()
	local t = RealTime() - _t0
	if t < T.tEtoile0 or t > T.tEtoile1 then return end
	local u = (t - T.tEtoile0) / CFG.nEtoile
	-- POINT DE VUE PARTAGÉ (user 08/28) : la caméra de tout le monde se pose sur
	-- le point dégagé de la config — un joueur en INTÉRIEUR voyait son plafond
	-- pendant toute la chute, il voit désormais le même plan que les autres.
	-- (L'étoile reste dessinée dans le ciel, recette faille : même taille, même
	-- place du ciel pour tous.) Map sans point : repli au-dessus de la tête.
	local vCam = CFG.tCamEtoile and CFG.tCamEtoile[game.GetMap()]
	if vCam then
		vCam = vCam + Vector(0, 0, CFG.nCamEtoileZ or 64) -- le setpos pose les PIEDS
	else
		local tr = util.TraceLine({
			start = origin,
			endpos = origin + Vector(0, 0, 260),
			mask = MASK_SOLID_BRUSHONLY,
		})
		vCam = tr.Hit and (tr.HitPos - Vector(0, 0, 16)) or (origin + Vector(0, 0, 260))
	end
	local vDir = PosEtoile(u, vCam) - vCam
	vDir:Normalize()
	return { origin = vCam, angles = vDir:Angle(), fov = fov, drawviewer = false }
end)

-- ═══ LA CUVE : invite [E] + UI de dépôt ═══════════════════════════════════════
surface.CreateFont("EVOCube_UI", { font = "Bebas Neue", size = 26, weight = 500, antialias = true })

local function CuvePosCl()
	local t = CFG.tCuves and CFG.tCuves[game.GetMap()]
	return t and t.pos or nil
end

hook.Add("PostDrawTranslucentRenderables", "EVO_Cube::CuveInvite", function(bDepth, bSky)
	if bDepth or bSky then return end
	local vPos = CuvePosCl()
	if not vPos then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local nDist = CFG.nCuveDist or 130
	if lp:EyePos():DistToSqr(vPos) > (nDist * 3) ^ 2 then return end
	local a = Angle(0, EyeAngles().y - 90, 90) -- billboard face au joueur
	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		local bPres = lp:EyePos():DistToSqr(vPos) <= nDist * nDist
		cam.Start3D2D(vPos + Vector(0, 0, CFG.nCuveTexteZ or 8), a, 0.17)
			EVO_ZonePrompt.Row(0, CFG.sCuveLabel or "La Cuve", bPres and "Ouvrir la cuve", "E", "coffre")
		cam.End3D2D()
		return
	end
	cam.Start3D2D(vPos + Vector(0, 0, CFG.nCuveTexteZ or 8), a, 0.12)
		draw.SimpleText(CFG.sCuveLabel or "La Cuve", "EVOCube_Label", 1, 1,
			Color(0, 0, 0, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(CFG.sCuveLabel or "La Cuve", "EVOCube_Label", 0, 0,
			Color(200, 220, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if lp:EyePos():DistToSqr(vPos) <= nDist * nDist then
			draw.SimpleText("[E] Ouvrir la cuve", "EVOCube_LabelPetit", 0, 54,
				Color(235, 235, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	cam.End3D2D()
end)

local frameCuve

local function AJoueurLObjet()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp.ForEachBagSlot) then return false end
	local bA = false
	lp:ForEachBagSlot(function(_, id)
		if id == CFG.sItemPickup then bA = true end
	end)
	return bA
end

net.Receive("EVO_Cube::CuveOuvrir", function()
	local tRows = {}
	local n = net.ReadUInt(8)
	for _ = 1, n do
		local sItem = net.ReadString()
		local sNom = net.ReadString()
		tRows[#tRows + 1] = { item = sItem, nom = sNom }
	end

	if IsValid(frameCuve) then frameCuve:Remove() end
	local w, h = math.floor(ScrW() * 0.26), math.floor(ScrH() * 0.44)
	local f = vgui.Create("DFrame")
	frameCuve = f
	f:SetSize(w, h)
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	f.Paint = function(_, fw, fh)
		draw.RoundedBox(10, 0, 0, fw, fh, Color(14, 14, 17, 246))
		draw.SimpleText("LA CUVE", "EVOCube_Msg", fw / 2, 34,
			Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(207, 68, 78, 255)
		surface.DrawRect(math.floor(fw * 0.3), 62, math.floor(fw * 0.4), 2)
	end

	local list = vgui.Create("DScrollPanel", f)
	list:SetPos(16, 76)
	list:SetSize(w - 32, h - 76 - 70)
	list.Paint = nil
	if #tRows == 0 then
		local l = vgui.Create("DLabel", list)
		l:SetFont("EVOCube_UI")
		l:SetTextColor(Color(150, 152, 158))
		l:SetText("La cuve est vide. Elle semble attendre quelque chose.")
		l:SizeToContents()
		l:SetPos(4, 8)
	else
		for _, r in ipairs(tRows) do
			local sItemNom = (ITEMS and ITEMS[r.item] and ITEMS[r.item].name) or "Objet étrange"
			local sDepositaire = r.nom
			local row = vgui.Create("DPanel", list)
			row:SetTall(34)
			row:Dock(TOP)
			row:DockMargin(0, 0, 0, 6)
			row.Paint = function(_, rw, rh)
				draw.RoundedBox(6, 0, 0, rw, rh, Color(24, 24, 29, 240))
				draw.SimpleText(sItemNom, "EVOCube_UI", 10, rh / 2,
					Color(255, 150, 60), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if sDepositaire ~= "" then
					draw.SimpleText("déposé par " .. sDepositaire, "EVOCube_UI", rw - 10, rh / 2,
						Color(150, 152, 158), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
		end
	end

	local bA = AJoueurLObjet()
	local btn = vgui.Create("DButton", f)
	btn:SetSize(w - 32, 44)
	btn:SetPos(16, h - 58)
	btn:SetText("")
	btn.Paint = function(s2, bw, bh)
		local c = bA and (s2:IsHovered() and Color(227, 88, 98) or Color(207, 68, 78)) or Color(45, 45, 52)
		draw.RoundedBox(8, 0, 0, bw, bh, c)
		draw.SimpleText(bA and "Déposer l'Objet étrange" or "Tu n'as rien à déposer",
			"EVOCube_UI", bw / 2, bh / 2, bA and Color(255, 255, 255) or Color(150, 152, 158),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.DoClick = function()
		if not AJoueurLObjet() then return end
		net.Start("EVO_Cube::CuveDepot")
		net.SendToServer()
	end
end)

-- Échap ferme la Cuve (même interception OnPauseMenuShow que le reste du projet).
hook.Add("OnPauseMenuShow", "EVO_Cube::CuveEsc", function()
	if IsValid(frameCuve) then
		frameCuve:Remove()
		return false
	end
end)
