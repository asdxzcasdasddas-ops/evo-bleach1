-- "addons\\evo_esc_close\\lua\\autorun\\client\\cl_evo_esc_close.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ESC CLOSE — helper global EVO_MakeEscClosable(panel).
-- RECRÉÉ : l'ancienne version de cet addon a été supprimée alors que ~42 menus
-- l'appellent encore (guardés par `if EVO_MakeEscClosable then`) -> tous avaient
-- perdu la fermeture Échap en silence.
--
-- Fonctionnement : on pose la globale `openedFrame` (le hook OnPauseMenuShow de
-- lzy_escape_menu la ferme sur Échap puis return false = pas de menu pause).
-- À appeler APRÈS MakePopup. Le panneau est aussi "dé-référencé" quand il se
-- ferme autrement (croix, clic dehors) pour ne pas garder un openedFrame mort.
-- ============================================================================
if not CLIENT then return end

function EVO_MakeEscClosable(panel)
    if not IsValid(panel) then return end

    -- lzy_escape_menu fait openedFrame:Close() : les panels non-DFrame (DPanel...)
    -- n'ont pas Close -> on en fournit un equivalent pour ne pas casser le hook.
    if not isfunction(panel.Close) then
        panel.Close = function(s) s:Remove() end
    end

    -- Mémorise le menu déjà ouvert SOUS ce panneau (ex: un popup lzy_popup superposé à un
    -- autre menu) pour le RESTAURER à la fermeture, au lieu de nullifier openedFrame (sinon
    -- l'Échap du menu sous-jacent serait cassé). Garde `~= panel` : si le panneau gère déjà
    -- lui-même openedFrame (MakeWindow l'a posé avant d'appeler ici), on ne le prend pas pour
    -- son propre "précédent".
    local prevOpened = (openedFrame ~= panel) and IsValid(openedFrame) and openedFrame or nil
    openedFrame = panel

    -- Libère/restaure la globale quand le panneau disparaît par un autre chemin (croix,
    -- clic dehors, Remove direct) — en préservant un OnRemove existant.
    local oldOnRemove = panel.OnRemove
    panel.OnRemove = function(s, ...)
        if openedFrame == s then openedFrame = (IsValid(prevOpened) and prevOpened) or nil end
        if oldOnRemove then oldOnRemove(s, ...) end
    end
end
