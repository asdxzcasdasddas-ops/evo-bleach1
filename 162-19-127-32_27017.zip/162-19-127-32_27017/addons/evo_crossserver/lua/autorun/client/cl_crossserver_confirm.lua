-- "addons\\evo_crossserver\\lua\\autorun\\client\\cl_crossserver_confirm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CROSS-SERVER — confirmation "destination PLEINE" (client).
-- Quand on prend un Garganta/Senkaimon vers un serveur PLEIN, le serveur n'envoie plus une
-- erreur sèche : il propose d'ATTENDRE SUR PLACE. Ici on affiche la confirmation
-- « X est plein — veux-tu patienter dans la file ? ». OUI -> on reste en jeu, mis en file
-- pour cette destination, envoyé dès qu'une place se libère. NON -> rien.
-- ============================================================================
if not CLIENT then return end

local BLUR = Material("pp/blurscreen")
local C = {
	dim    = Color(0, 0, 0, 190),
	bg     = Color(14, 14, 17, 252),
	accent = Color(207, 68, 78),
	title  = Color(238, 239, 243),
	sub    = Color(165, 168, 176),
}

-- DA ATELIER (07/07) : Bebas SANS bold (weight 400, comme partout) ; les
-- Roboto restent pour le corps de texte.
local function makeFonts()
	local s = math.Clamp(ScrH() / 1080, 0.5, 2.5)
	surface.CreateFont("EVOXFull_Title", { font = "Bebas Neue", size = math.floor(40 * s), weight = 400, antialias = true })
	surface.CreateFont("EVOXFull_Sub",   { font = "Roboto",     size = math.floor(20 * s), weight = 500, antialias = true })
	surface.CreateFont("EVOXFull_Btn",   { font = "Bebas Neue", size = math.floor(26 * s), weight = 400, antialias = true })
	surface.CreateFont("EVOXFull_QHead", { font = "Bebas Neue", size = math.floor(19 * s), weight = 400, antialias = true })
	surface.CreateFont("EVOXFull_QSub",  { font = "Roboto",     size = math.floor(13 * s), weight = 500, antialias = true })
	surface.CreateFont("EVOXFull_QRow",  { font = "Roboto",     size = math.floor(14 * s), weight = 500, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO::XFull::Fonts", makeFonts)

local function rbox(r, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(r, x, y, w, h, col)
	else draw.RoundedBox(math.max(0, math.floor(r)), x, y, w, h, col) end
end

-- Helpers Atelier locaux (RÈGLE repo : chaque fichier client a ses copies).
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawBlur()
	surface.SetMaterial(BLUR)
	surface.SetDrawColor(255, 255, 255, 255)
	for i = 1, 5 do
		BLUR:SetFloat("$blur", (i / 5) * 6)
		BLUR:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	end
end

local frame
local function sendChoice(accept)
	net.Start("EVO:Cross:FullChoice")
		net.WriteBool(accept and true or false)
	net.SendToServer()
end

local function Open(destName)
	if IsValid(frame) then frame:Remove() end
	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:ShowCloseButton(false)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:MakePopup()
	frame.OnRemove = function() frame = nil end

	local function geo()
		local sx = math.Clamp(ScrH() / 1080, 0.5, 2.5)
		local S  = function(n) return math.floor(n * sx) end
		local cw, ch = S(520), S(300)
		return (ScrW() - cw) * 0.5, (ScrH() - ch) * 0.5, cw, ch, S
	end

	frame.Paint = function(_, w, h)
		local cx, cy, cw, ch, S = geo()
		-- Fond DA Atelier : blur RNDX (1 passe) + voile 5,5,7,216 (comme partout).
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		else
			drawBlur()
		end
		surface.SetDrawColor(5, 5, 7, 216) surface.DrawRect(0, 0, w, h)
		-- Plaque de métal noir Atelier : coins coupés + liseré acier + vis
		-- (remplace la carte arrondie + bandeau accent plein).
		-- DA dashboard 08/07 : plaque PLATE, plus de liseré acier.
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(cx, cy, cw, ch, C.bg, S(16))
		else
			rbox(0, cx, cy, cw, ch, C.bg)
		end
		local sr = S(5)
		drawScrew(cx + S(18), cy + S(18), sr)
		drawScrew(cx + cw - S(18), cy + S(18), sr)
		drawScrew(cx + cw - S(18), cy + ch - S(18), sr)
		drawScrew(cx + S(18), cy + ch - S(18), sr)
		local mid = cx + cw * 0.5
		-- Titre Bebas + entaille slash1 centrée dessous (signature Atelier).
		draw.SimpleText("SERVEUR PLEIN", "EVOXFull_Title", mid, cy + S(36), C.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		surface.SetFont("EVOXFull_Title")
		local twT, thT = surface.GetTextSize("SERVEUR PLEIN")
		local inked = EVO_UI and EVO_UI.Ink
			and EVO_UI.Ink(EVO_UI.TexSlash, mid - twT * 0.575, cy + S(36) + thT * 0.78, twT * 1.15, S(9), ColorAlpha(C.accent, 245))
		if not inked then
			surface.SetDrawColor(C.accent)
			surface.DrawRect(mid - twT * 0.5, cy + S(36) + thT * 0.84, twT, math.max(2, S(3)))
		end
		draw.SimpleText(destName .. " est plein.", "EVOXFull_Sub", mid, cy + S(100), C.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("Veux-tu attendre une place ? Tu RESTES ici en attendant,", "EVOXFull_Sub", mid, cy + S(128), C.sub, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("et tu y seras envoyé dès qu'une place se libère.", "EVOXFull_Sub", mid, cy + S(154), C.sub, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Boutons Atelier : plaques à coin bas-droit coupé (plus de pilules arrondies).
	local function styleBtn(b, label, primary)
		b:SetText("")
		b.Paint = function(s, w, h)
			local hov = s:IsHovered()
			local fill
			if primary then
				fill = hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230)
			else
				fill = hov and Color(26, 28, 34, 235) or Color(17, 18, 22, 205)
			end
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, fill, math.floor(h * 0.18), "br")
			else
				rbox(0, 0, 0, w, h, fill)
			end
			local txt = primary and color_white or (hov and C.accent or C.title)
			draw.SimpleText(label, "EVOXFull_Btn", w * 0.5, h * 0.5, txt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	local bYes = vgui.Create("DButton", frame)
	styleBtn(bYes, "ATTENDRE DANS LA FILE", true)
	bYes.DoClick = function() sendChoice(true) frame:Remove() end

	local bNo = vgui.Create("DButton", frame)
	styleBtn(bNo, "ANNULER", false)
	bNo.DoClick = function() sendChoice(false) frame:Remove() end

	frame.PerformLayout = function()
		local cx, cy, cw, ch, S = geo()
		local bw, bh = (cw - S(90)) / 2, S(54)
		bYes:SetSize(bw, bh) bYes:SetPos(cx + S(30), cy + ch - S(82))
		bNo:SetSize(bw, bh)  bNo:SetPos(cx + S(30) + bw + S(30), cy + ch - S(82))
	end

	-- Échap = annuler (helper projet ; le moteur n'envoie pas KEY_ESCAPE à OnKeyCodePressed).
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
end

net.Receive("EVO:Cross:FullConfirm", function()
	local _addr = net.ReadString() -- non utilisé client (la destination est tenue serveur)
	local name  = net.ReadString()
	Open(name)
end)

-- Etat de file recu du serveur (liste triee pour MA destination + ma position).
local queueUI = nil -- { dest=, pos=, total=, t=, entries = { {name=, self=, cut=}, ... } }
net.Receive("EVO:Cross:QueueState", function()
	local dest  = net.ReadString()
	local pos   = net.ReadUInt(16)
	local total = net.ReadUInt(16)
	local shown = net.ReadUInt(8)
	local entries = {}
	for i = 1, shown do
		entries[i] = { name = net.ReadString(), self = net.ReadBool(), cut = net.ReadBool() }
	end
	queueUI = { dest = dest, pos = pos, total = total, entries = entries, t = CurTime() }
end)

-- HUD « EN ATTENTE » : tant qu'on attend une place sur l'autre serveur, on RESTE en jeu mais on
-- affiche un rappel (haut-gauche, avec la liste) + comment annuler (re-presser la touche de voyage).
local QCOL = {
	bg   = Color(12, 12, 15, 214),
	self = Color(207, 68, 78, 42),
	num  = Color(120, 122, 130),
	gold = Color(230, 196, 120),
	hint = Color(112, 114, 122),
}
hook.Add("HUDPaint", "EVO::Cross::WaitHUD", function()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:GetEvoNWBool("EVO_CrossWaiting", false)) then return end
	local sx = math.Clamp(ScrH() / 1080, 0.5, 2.5)
	local S  = function(n) return math.floor(n * sx) end
	local name = lp:GetEvoNWString("EVO_CrossWaitName", "")
	local q = (queueUI and (CurTime() - queueUI.t) < 12) and queueUI or nil

	local x, y  = S(20), S(20)
	local w     = S(244)
	local padX  = S(12)
	local headH = S(44)
	local rowH  = S(21)
	local rows  = q and #q.entries or 0
	local hintH = S(24)
	local h     = headH + (rows > 0 and (rows * rowH + S(8)) or 0) + hintH

	-- Mini-plaque Atelier PLATE (coin bas-droit coupé) + barre accent gauche.
	-- DA dashboard 08/07 : plus de liseré acier.
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, w, h, QCOL.bg, S(10), "br")
	else
		rbox(0, x, y, w, h, QCOL.bg)
	end
	surface.SetDrawColor(C.accent)
	surface.DrawRect(x, y, S(2), h)

	local dots = string.rep(".", math.floor(CurTime() * 2) % 4)
	draw.SimpleText("FILE D'ATTENTE" .. dots, "EVOXFull_QHead", x + padX, y + S(11), C.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	local sub = (q and q.dest ~= "" and q.dest) or (name ~= "" and name) or "Destination"
	if q then sub = sub .. "   " .. q.pos .. "/" .. q.total end
	draw.SimpleText(sub, "EVOXFull_QSub", x + padX, y + S(29), C.sub, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	if rows > 0 then
		local ly = y + headH
		for i, e in ipairs(q.entries) do
			local ry = ly + (i - 1) * rowH
			-- Surlignage de SA ligne : rect CARRÉ (DA, plus d'arrondi).
			if e.self then rbox(0, x + S(6), ry, w - S(12), rowH - S(2), QCOL.self) end
			draw.SimpleText(i .. ".", "EVOXFull_QRow", x + padX, ry + rowH * 0.5, e.self and C.accent or QCOL.num, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(e.name, "EVOXFull_QRow", x + padX + S(22), ry + rowH * 0.5, e.self and C.title or C.sub, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if e.cut then rbox(0, x + w - padX - S(7), ry + rowH * 0.5 - S(3), S(6), S(6), QCOL.gold) end
		end
	end

	local extra = (q and q.total > #q.entries) and ("  +" .. (q.total - #q.entries)) or ""
	draw.SimpleText("Re-presse ta touche de voyage pour annuler" .. extra, "EVOXFull_QSub", x + padX, y + h - hintH + S(3), QCOL.hint, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end)
