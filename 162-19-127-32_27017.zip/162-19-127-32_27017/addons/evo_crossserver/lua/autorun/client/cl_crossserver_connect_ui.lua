-- "addons\\evo_crossserver\\lua\\autorun\\client\\cl_crossserver_connect_ui.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CROSS-SERVER (client) — voyage inter-serveur = boîte NATIVE de GMod.
-- ----------------------------------------------------------------------------
-- AVANT, ce fichier RE-SKINNAIT la boîte "askconnect" de GMod : il la détectait,
-- la cachait hors écran, affichait un panneau stylé « VOYAGE INTER-SERVEUR » par
-- dessus, et son bouton « Voyager » RELAYAIT le clic sur le « Oui » natif.
--
-- Ce re-skin était la source du bug « premier coup bizarre » sur garganta/senkaimon :
--   1) la détection VGUI avait un angle mort (jusqu'à ~3 s de retard si un autre
--      panneau disparaissait pile quand l'askconnect apparaissait) ;
--   2) le clic PROGRAMMATIQUE sur le bouton natif (yesBtn:DoClick()) était
--      capricieux à la 1re connexion d'une session — alors que le clic À LA MAIN
--      sur la boîte native, lui, marche (cf. char-select qui n'utilise pas ce relai).
--
-- À la demande de l'utilisateur : on REVIENT à la boîte native de GMod (le truc de
-- base, la voie la plus fiable). On ne touche donc PLUS à l'askconnect :
-- RunConsoleCommand('connect', ip) côté client (cf. EVO_Cross.Redirect serveur /
-- lzy_character) déclenche la boîte native, le joueur clique « Oui », il part.
--
-- Ce fichier n'absorbe plus que le signal serveur EVO:Cross:ExpectConnect (no-op),
-- pour éviter un avertissement console « unhandled net message ». (Le serveur peut
-- continuer à l'envoyer sans effet.)
-- ============================================================================
if SERVER then return end

net.Receive("EVO:Cross:ExpectConnect", function() end)
