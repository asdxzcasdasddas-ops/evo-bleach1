-- "addons\\evo_cloche\\lua\\autorun\\sh_evo_cloche.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CLOCHE — cloche d'annonce posée sur chaque map (demande user 08/31).
-- E dessus -> ouvre l'UI d'annonce de faction (lzy_annonce_faction), qui
-- n'avait jusqu'ici AUCUNE entrée en jeu : seule la commande console
-- `annonce_faction` (SuperAdmin) l'ouvrait, alors que le DROIT D'ÉMETTRE est
-- ouvert aux gradés 10+. La cloche est cette entrée manquante.
-- Position déplaçable en jeu via evo_config_positions (catégorie « Modeles »).
-- ============================================================================

EVO_CLOCHE = EVO_CLOCHE or {}

-- Modèle fourni par le user (casse conservée EXACTEMENT : serveur Linux).
EVO_CLOCHE.Model = "models/evo/props/props_anim/bell_animated/bell_animated.mdl"

-- Portée de la garde serveur sur ENT:Use (large, même valeur que le PNJ du
-- rituel) ; le prompt client, lui, exige de VISER la cloche de plus près.
EVO_CLOCHE.InteractDistance = 200

-- POINT DU « E », SÉPARÉ du modèle (demande user 08/31 : bouger le E ET la
-- cloche indépendamment). Utile quand la cloche est haute ou encastrée : on pose
-- le point d'interaction là où le joueur se tient vraiment.
-- Non configuré -> retombe sur la position de la cloche (comportement d'origine).
EVO_CLOCHE.UsePoints = EVO_CLOCHE.UsePoints or {}
EVO_CLOCHE.UseRadius = 110  -- rayon d'activation autour du point du E
EVO_CLOCHE.UseFacing = 0.5  -- il faut REGARDER vers le point (dot mini) : E sert à
                            -- tout (portes, PNJ, roue joueur) -- sans ça on ouvrirait
                            -- l'UI par accident en passant à côté.

function EVO_CLOCHE.UsePointFor(sMap)
	sMap = sMap or game.GetMap()
	local v = EVO_CLOCHE.UsePoints[sMap]
	if isvector(v) then return v end
	local t = EVO_CLOCHE.Spawns[sMap]
	return (istable(t) and isvector(t.pos)) and t.pos or nil
end

-- Le joueur est-il en position de sonner ? PARTAGÉ : le client l'utilise pour le
-- prompt, le serveur pour valider le E. Une seule règle -> le prompt ne peut pas
-- mentir sur ce que le serveur acceptera.
function EVO_CLOCHE.EstAuPoint(ply)
	if not IsValid(ply) then return false end
	local v = EVO_CLOCHE.UsePointFor()
	if not v then return false end
	local nR = EVO_CLOCHE.UseRadius or 110
	if ply:GetPos():DistToSqr(v) > nR * nR then return false end
	local vTo = v - ply:EyePos()
	vTo:Normalize()
	return vTo:Dot(ply:GetAimVector()) >= (EVO_CLOCHE.UseFacing or 0.5)
end

-- Poses fournies par le user (relevées in-game). ⚠ On ne garde que le YAW :
-- les setang relevés ont un pitch de ~88° (le joueur regardait le sol en
-- copiant sa position), l'appliquer coucherait la cloche face contre terre.
-- Même règle que les tableaux de map (cf. provider evo_config_positions).
EVO_CLOCHE.Spawns = {
	["hueco_mundo_v1"] = { pos = Vector(-7166.434082, -4288.930176, 6472.724121), ang = Angle(0, -9.840415, 0) }, -- repositionnee 09/01 (yaw seul, pitch 89 du setang jete)
	["rp_seireitei_v1"] = { pos = Vector(123.011024, -3206.561035, 585.808228), ang = Angle(0, -88.956146, 0) },
}

function EVO_CLOCHE.SpawnFor(sMap)
	local t = EVO_CLOCHE.Spawns[sMap or game.GetMap()]
	if not (istable(t) and isvector(t.pos)) then return nil end
	return t
end

-- Qui peut se servir de la cloche ? EXACTEMENT qui a le droit d'émettre une
-- annonce — sinon on ouvrirait une UI dont l'envoi serait refusé derrière.
-- Source de vérité = LZY_Faction_AnnonceRights (lzy_annonce_faction/sv_main),
-- serveur uniquement ; le client rejoue la même règle pour l'affichage du
-- prompt (le serveur reste autoritatif sur le Use).
function EVO_CLOCHE.PeutAnnoncer(ply)
	if not IsValid(ply) then return false end
	if SERVER and LZY_Faction_AnnonceRights then
		local bOk = LZY_Faction_AnnonceRights(ply)
		return bOk == true
	end
	if ply:IsSuperAdmin() then return true end
	local sFaction = ply:GetEvoNWString("FactionName", "")
	local tGrades = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.factions and LZY_FACTION_CONFIG.factions[sFaction]
	if not istable(tGrades) or #tGrades <= 1 then return false end -- faction sans hiérarchie
	local nMin = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.AnnonceMinRank) or 10
	return ply:GetEvoNWInt("FactionRank", 0) >= nMin
end
