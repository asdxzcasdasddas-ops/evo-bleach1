-- "addons\\evo_cloche\\lua\\autorun\\client\\cl_evo_cloche.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CLOCHE — prompt « [E] Sonner l'annonce ».
-- MÊME patte graphique que le « [E] S'allonger » d'evo_repos / evo_assise :
-- keycap accent + libellé, fond discret, centré sous le réticule. Affiché
-- seulement en VISANT la cloche de près, et seulement si le joueur a le droit
-- d'émettre une annonce (le serveur revalide dans ENT:Use).
-- ============================================================================
if not CLIENT then return end

local COL_BG     = Color(16, 16, 19, 205)
local COL_ACCENT = Color(207, 68, 78)
local COL_TXT    = Color(238, 239, 243)

local function S(v) return math.Round(v * (ScrH() / 1080)) end

local function makeFonts()
	surface.CreateFont("EVO_Cloche_Key",   { font = "Roboto", size = S(15), weight = 800, antialias = true })
	surface.CreateFont("EVO_Cloche_Label", { font = "Roboto", size = S(17), weight = 600, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO_Cloche::Fonts", makeFonts)

local VIS_DIST_SQR = 130 * 130 -- portée du prompt (le Use serveur tolère plus large)

-- La cloche visée, ou nil. Trace courte : rien à calculer quand on regarde ailleurs.
local function aimedBell(lp)
	local tr = util.TraceLine({
		start  = lp:EyePos(),
		endpos = lp:EyePos() + lp:GetAimVector() * 130,
		filter = lp,
	})
	local e = tr.Entity
	if not (IsValid(e) and e:GetClass() == "evo_cloche_prop") then return nil end
	if e:GetPos():DistToSqr(lp:GetPos()) > VIS_DIST_SQR then return nil end
	return e
end

hook.Add("HUDPaint", "EVO_Cloche::Prompt", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if vgui.CursorVisible() then return end
	-- Deux chemins, comme le serveur : visée du modèle OU présence au point du E
	-- (déplaçable séparément). EstAuPoint est la fonction PARTAGÉE, donc le prompt
	-- ne s'affiche jamais là où le serveur refuserait.
	local bAuPoint = EVO_CLOCHE and EVO_CLOCHE.EstAuPoint and EVO_CLOCHE.EstAuPoint(lp)
	if not bAuPoint and not aimedBell(lp) then return end

	-- Droit d'émettre : sinon on annoncerait une action qui sera refusée.
	local bPeut = EVO_CLOCHE and EVO_CLOCHE.PeutAnnoncer and EVO_CLOCHE.PeutAnnoncer(lp)
	local label = bPeut and "Sonner l'annonce" or "Réservée aux haut gradés"
	-- Style d'invite unifié ; refus = motif seul, sans touche.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(ScrW() * 0.5, ScrH() * 0.5 + S(66), "Cloche d'annonce", label, bPeut and "E" or "")
		return
	end

	surface.SetFont("EVO_Cloche_Label")
	local lw = surface.GetTextSize(label)
	local keyR, gap = S(13), S(9)
	local totalW = keyR * 2 + gap + lw
	local cx, cy = ScrW() * 0.5, ScrH() * 0.5 + S(66)
	local x0 = cx - totalW * 0.5

	local padX, padY = S(10), S(7)
	draw.RoundedBox(S(6), x0 - padX, cy - keyR - padY, totalW + padX * 2, keyR * 2 + padY * 2, COL_BG)
	local kx = x0 + keyR
	draw.RoundedBox(S(4), kx - keyR, cy - keyR, keyR * 2, keyR * 2, bPeut and COL_ACCENT or Color(70, 70, 78))
	draw.SimpleText("E", "EVO_Cloche_Key", kx, cy + S(1), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(label, "EVO_Cloche_Label", x0 + keyR * 2 + gap, cy,
		bPeut and COL_TXT or Color(150, 154, 162), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)
