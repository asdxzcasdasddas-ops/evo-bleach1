-- "addons\\evo_cloche\\lua\\entities\\evo_cloche_prop\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Initialize() end
function ENT:Draw() self:DrawModel() end
