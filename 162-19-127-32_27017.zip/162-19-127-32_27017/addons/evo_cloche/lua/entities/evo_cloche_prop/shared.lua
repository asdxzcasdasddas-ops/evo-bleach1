-- "addons\\evo_cloche\\lua\\entities\\evo_cloche_prop\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type           = "anim"
ENT.Base           = "base_gmodentity"
ENT.PrintName      = "Cloche d'annonce"
ENT.Author         = "Evo"
ENT.Category       = "Evo"
ENT.Spawnable      = true
ENT.AdminSpawnable = true
ENT.Model          = "models/evo/props/props_anim/bell_animated/bell_animated.mdl"
