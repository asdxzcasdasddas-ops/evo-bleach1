-- "addons\\evo_lost_soul\\lua\\autorun\\sh_lost_soul.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ════════════════════════════════════════════════════════════════════════════════════
-- evo_lost_soul : ONBOARDING « âme errante » faction-neutre (partagé client + serveur)
-- ────────────────────────────────────────────────────────────────────────────────────
-- Flux : un NOUVEAU joueur (compte sans tutoriel) ne choisit PAS sa faction tout de suite.
-- Il incarne d'abord une « Âme errante » (modèle lost_soul, pseudo-faction LostSoul, nom
-- auto « Âme errante #NNNN »), fait le TUTORIEL, puis choisit sa faction À LA FIN :
--   • Shinigami -> création du vrai perso Shinigami (apparence via créateur) + Seireitei ;
--   • Hollow    -> larve (evo_hollow_progression, EVO_HollowProg.Begin).
--
-- Réutilise la machinerie « raw model » de evo_hollow_progression (larve) : SetModel plein
-- corps + NWBool EVO_HollowRaw pour SAUTER le composite tête+corps côté client — cf.
-- lzy_character/cl_models.lua LZY_IsLarvaCharacter (qui consulte EVO_LostSoul.IsLostSoulBodyModel).
-- ════════════════════════════════════════════════════════════════════════════════════
EVO_LostSoul = EVO_LostSoul or {}
local CFG = EVO_LostSoul.Config or {}
EVO_LostSoul.Config = CFG

-- Kill-switch. false = flux normal (créateur classique, faction d'abord) ; le lost-soul
-- ne s'active pas. Passer à true pour activer l'onboarding « âme errante ».
CFG.Enabled = true

-- Modèle « âme errante » (playermodel workshop monté). Rendu en RAW model (comme la larve) :
-- le composite tête+corps est sauté côté client, on voit le modèle ENTIER via SetModel.
-- ⚠️ Si le rendu montre « que la tête » : vérifier la CASSE exacte du .mdl monté et corriger ici.
CFG.Model = "models/evo/characters/lost_soul/evo_92dmditbgbzig2e9fjjfe/evo_92dmditbgbzig2e9fjjfe.mdl"

-- Pseudo-faction interne pendant l'onboarding (déclarée dans LZY_FACTION_CONFIG.factions /
-- .divisions). La VRAIE faction (Shinigami/Hollow) est posée à la fin du tutoriel.
CFG.Faction = "LostSoul"

-- Nom RP affiché pendant l'onboarding : « Âme errante #<numéro CRC> » (SoulName).
-- Unicité BDD = lastname SteamID64 (BuildLostSoulData), pas ce numéro d'affichage.
CFG.Name = "Âme errante"

-- Échelle du modèle (1 = taille native du .mdl).
CFG.ModelScale = 1

-- ─────────────────────────────────────────────────────────────────────────────
-- Vrai si `model` est le modèle de l'âme errante. Consulté PAR :
--   • cl_models.lua (LZY_IsLarvaCharacter) -> rendu raw model ;
--   • sv_main.lua (SanitizeCharacterData)  -> ne PAS écraser le body_model + vider hair/tattoo.
-- (même rôle que EVO_HollowProg.IsLarvaBodyModel pour la larve).
function EVO_LostSoul.IsLostSoulBodyModel(model)
    return isstring(model) and CFG.Model ~= "" and string.lower(model) == string.lower(CFG.Model)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- COMPTAGE DES « VRAIS » PERSOS (demande user 2026-07-17) : le déclencheur de l'âme errante
-- passe du flag compte NCM_TutorialDone au critère « 0 personnage RÉEL ». Un perso réel =
-- slot RP (<=3) qui n'est NI l'âme errante (modèle lost_soul / pseudo-faction LostSoul) NI un
-- slot ANIMATION (slots 4/5, staff). Définition CANONIQUE réutilisée client (charactersData)
-- ET serveur (charactersList) — les deux tables sont indexées par slot avec body_model+faction.
-- ─────────────────────────────────────────────────────────────────────────────
function EVO_LostSoul.IsRealCharRow(row)
    if not istable(row) then return false end
    local slot = tonumber(row.slot)
    if slot and slot > 3 then return false end                 -- slot ANIMATION (4/5)
    if EVO_LostSoul.IsLostSoulBodyModel(row.body_model) then return false end
    if row.faction == CFG.Faction then return false end        -- pseudo-faction LostSoul
    return true
end

-- Nombre de persos RÉELS dans une liste (charactersData client OU charactersList serveur).
function EVO_LostSoul.CountRealChars(list)
    if not istable(list) then return 0 end
    local n = 0
    for _, row in pairs(list) do
        if EVO_LostSoul.IsRealCharRow(row) then n = n + 1 end
    end
    return n
end

-- Retourne la ligne (et son slot) de l'âme errante existante dans une liste, sinon nil. Sert
-- au receiver Begin serveur pour REPRENDRE une âme persistante au lieu d'en créer une 2e.
function EVO_LostSoul.FindSoulRow(list)
    if not istable(list) then return nil end
    for slot, row in pairs(list) do
        if istable(row) and (EVO_LostSoul.IsLostSoulBodyModel(row.body_model) or row.faction == CFG.Faction) then
            return row, tonumber(slot)
        end
    end
    return nil
end

-- Numéro d'AFFICHAGE (nametag « Âme errante #NNNN »). CRC 1000-9999 : collisions
-- possibles, volontairement OK à l'écran. L'unicité BDD (firstname+lastname) N'utilise
-- PLUS ce numéro — voir BuildLostSoulData (lastname = SteamID64).
function EVO_LostSoul.SoulNumber(ply)
    if not IsValid(ply) then return 0 end
    return (tonumber(util.CRC(ply:SteamID64())) or 0) % 9000 + 1000
end

-- Nom RP complet (« Âme errante #NNNN »).
function EVO_LostSoul.SoulName(ply)
    return CFG.Name .. " #" .. EVO_LostSoul.SoulNumber(ply)
end

-- Vrai si l'onboarding « âme errante » peut s'appliquer sur cette map : activé + une map de
-- tutoriel configurée (sinon pas d'intro possible -> flux normal, créateur classique).
function EVO_LostSoul.IsActiveMap(mapName)
    if CFG.Enabled ~= true or CFG.Model == "" then return false end
    if NCM_TUTORIEL and NCM_TUTORIEL.IsMapConfigured then
        return NCM_TUTORIEL.IsMapConfigured()
    end
    -- ncm_tutoriel pas encore chargé : on laisse passer (le serveur re-vérifie au Begin).
    return true
end
