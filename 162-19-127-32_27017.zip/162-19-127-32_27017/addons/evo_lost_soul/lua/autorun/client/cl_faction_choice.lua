-- "addons\\evo_lost_soul\\lua\\autorun\\client\\cl_faction_choice.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- evo_lost_soul (CLIENT) : helper local IsLostSoulLocal (le joueur incarne-t-il une âme errante ?).
-- Lu par le tutoriel (skip des étapes « capacité ») + la bascule vers le créateur en fin de tuto.
-- (L'ancien écran de choix de faction custom a été retiré : le choix se fait dans le vrai créateur.)
EVO_LostSoul = EVO_LostSoul or {}

-- Vrai si le joueur local incarne actuellement une âme errante (NWBool posé serveur).
function EVO_LostSoul.IsLostSoulLocal()
    local lp = LocalPlayer()
    return IsValid(lp) and lp:GetEvoNWBool("EVO_IsLostSoul", false)
end
