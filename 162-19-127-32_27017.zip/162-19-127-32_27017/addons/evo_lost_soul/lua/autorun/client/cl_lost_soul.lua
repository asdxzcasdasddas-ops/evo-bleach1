-- "addons\\evo_lost_soul\\lua\\autorun\\client\\cl_lost_soul.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- evo_lost_soul : logique CLIENT de l'onboarding « âme errante ».
-- Décide si le clic « créer un personnage » doit lancer l'âme errante (nouveau joueur) ou
-- ouvrir le créateur classique (persos suivants), et envoie le net de création au serveur.
EVO_LostSoul = EVO_LostSoul or {}
local CFG = EVO_LostSoul.Config

-- Vrai si le clic « créer » doit basculer sur l'onboarding « âme errante » plutôt que sur le
-- créateur classique. CRITÈRE (demande user 2026-07-17) : « 0 personnage RÉEL » — plus de
-- dépendance au flag compte NCM_TutorialDone. Le COMPTAGE 0-perso est fait par l'APPELANT
-- (branches count==0 de cl_character_selection / RealFilledCount de ncm_char_select) ; ici on
-- ne garde que les gates qui NE dépendent PAS du nombre de persos :
--   • map d'onboarding active (sinon pas d'âme errante possible) ;
--   • pas un animateur (staff = créateur classique, jamais d'âme errante) — DOIT vivre ici car
--     CreateFocused appelle ShouldIntercept, et un animateur cliquant un slot RP serait sinon
--     intercepté ;
--   • pas en pleine finalisation larve->Arrancar.
-- Le serveur re-valide le vrai « 0 perso réel » (anti-forge) dans le receiver EVO:LostSoul:Begin.
function EVO_LostSoul.ShouldIntercept()
    if not EVO_LostSoul.IsActiveMap() then return false end
    -- LE BUG « créateur Shinigami au lieu de l'âme errante » (trouvé 07/20) : le net d'ouverture
    -- (CharacterSelection:Open à 0 perso) arrive TRÈS tôt à la première connexion — AVANT que
    -- LocalPlayer() ne soit une entité valide. L'ancien `if not IsValid(lp) then return false end`
    -- abandonnait alors l'interception -> créateur classique (page faction) pour un compte vierge.
    -- On n'abandonne PLUS pour ça : le seul usage de lp ici est le gate animateur, qu'on n'évalue
    -- que si lp est valide — sinon on laisse passer, le SERVEUR revalide de toute façon au Begin
    -- (un animateur y est renvoyé au menu, anti-forge 0-perso inclus).
    local lp = LocalPlayer()
    if IsValid(lp) and lp.GetUserGroup and EVO_ANIM ~= nil and EVO_ANIM.IsAnimGroupName(lp:GetUserGroup()) then return false end -- staff animation : créateur classique
    if EVO_HollowProg and EVO_HollowProg._Finalizing then return false end
    return true
end

-- Anti-boucle : Open 0 perso auto-appelle ceci ; si CreateCharacter échoue le serveur
-- renvoie Open vide -> sans garde on re-HoldBlack à l'infini (Escape mort, pas de hub).
local AUTO_BEGIN_COOLDOWN = 12
local _lastAutoBegin = -999

-- bAuto = true : ouverture menu à 0 perso (connexion / fail serveur). nil/false = clic Créer.
-- Retourne false si l'auto-begin est ignoré (l'appelant doit ouvrir le hub).
function EVO_LostSoul.BeginFromSelect(bAuto)
    if bAuto and (RealTime() - _lastAutoBegin) < AUTO_BEGIN_COOLDOWN then
        return false
    end
    if bAuto then _lastAutoBegin = RealTime() end
    if NCM_CHAR_SELECT and NCM_CHAR_SELECT.StopScene then NCM_CHAR_SELECT.StopScene() end
    -- Écran NOIR immédiat (0 latence) dès le clic « créer » -> le joueur ne voit jamais le spawn
    -- au point par défaut ; la cine prend le relais. (Le serveur renvoie aussi un Hold pour la
    -- commande de test qui bypasse ce clic.)
    if EVO_IntroCine and EVO_IntroCine.HoldBlack then EVO_IntroCine.HoldBlack() end
    net.Start("EVO:LostSoul:Begin")
    net.SendToServer()
    return true
end

-- FIN DU TUTORIEL (âme errante) : on demande au serveur de supprimer l'âme errante puis d'ouvrir
-- LE CRÉATEUR (page de choix de faction = la vraie logique existante : Shinigami→apparence,
-- Hollow→larve, cross-serveur→transfert). Remplace l'ancienne popup VGUI custom.
function EVO_LostSoul.FinishTutorial()
    net.Start("EVO:LostSoul:FinishTutorial")
    net.SendToServer()
end

-- BOUTON « PASSER LE TUTORIEL » (revenant uniquement, demande user 2026-07-17) : saute TOUT le
-- tuto d'un coup -> le serveur supprime l'âme errante, ouvre le créateur et pose un art spirituel
-- COMMUN (FinishToCreator bReturning). Le serveur re-vérifie que le compte a déjà fini le tuto.
function EVO_LostSoul.SkipTutorial()
    net.Start("EVO:LostSoul:SkipTutorial")
    net.SendToServer()
end

-- Ferme les UI de jeu encore ouvertes avant le créateur (skip / fin du tuto âme errante).
-- Sans ça, un menu ouvert pendant le tuto (faction, boutique, C, openedFrame…) reste AU-DESSUS
-- de la page de création. Couvre skip ET fin naturelle (même net OpenCreator).
function EVO_LostSoul.CloseLingeringUIs()
    local lp = LocalPlayer()
    if IsValid(lp) and lp.CloseFactionMenu then
        lp:CloseFactionMenu(true) -- silencieux : pas d'anim livre par-dessus le créateur
    end
    if MUGEN and MUGEN.IsContextMenuOpen and MUGEN.IsContextMenuOpen() then
        hook.Run("OnContextMenuClose")
    end
    -- Boutique / inventaire / binds / etc. s'enregistrent sur openedFrame (convention projet).
    if IsValid(openedFrame) then
        if openedFrame.Close then openedFrame:Close() end
        if IsValid(openedFrame) then openedFrame:Remove() end
        openedFrame = nil
    end
    CloseDermaMenus()
end

-- Le serveur a supprimé l'âme errante et mis le joueur en limbo -> on ouvre le créateur (Page 1
-- faction). Le créateur enchaîne ensuite le choix + l'apparence / la larve, comme d'habitude.
net.Receive("EVO:LostSoul:OpenCreator", function()
    EVO_LostSoul.CloseLingeringUIs()
    if OpenCharacterCreator then OpenCharacterCreator() end
end)

-- PHASE CAPACITÉ (post-création) : rejoue sur le VRAI perso les étapes reroll + compétence
-- retirées du tuto de l'âme errante. Séquences d'étapes (indices ncm_tutoriel) par faction :
--   Shinigami : art (3), ouvrir skilltree (6), acheter (7), équiper (9) ;
-- Shinigami / Arrancar : art + skilltree. HollowLarva : uniquement équiper le Cero (pendant progression).
-- bAutoCommon (2e+ perso) : étape 3 donne un art COMMUN auto (pas de vrai reroll joueur).
local ABILITY_SEQ = {
    Shinigami   = { 3, 6, 7, 9 },
    Hollow      = { 3, 6, 7, 9 },
    HollowLarva = { 9 },
}
net.Receive("EVO:LostSoul:StartAbilityPhase", function()
    local faction = net.ReadString()
    local bAutoCommon = net.ReadBool()
    local seq = ABILITY_SEQ[faction]
    if seq and NCM_TUTORIEL and NCM_TUTORIEL.StartAbilityPhase then
        NCM_TUTORIEL.StartAbilityPhase(seq, bAutoCommon)
    end
end)

-- Fin de la phase capacité -> le serveur efface le flag PData (pas de re-run à la reconnexion).
hook.Add("NCM::Tutorial::AbilityPhaseDone", "EVO_LostSoul::AbilityDone", function()
    net.Start("EVO:LostSoul:AbilityPhaseDone")
    net.SendToServer()
end)

-- ══════════════════════════════════════════════════════════
-- PANEL « grant auto-common » (2e+ perso) : affiche le win reçu + explique pourquoi
-- pas de reroll. Réutilisé pour Art Spirituel (tuto) et Style de combat (Maître d'Armes).
-- ══════════════════════════════════════════════════════════

surface.CreateFont("EVO_AutoCommon_Title", { font = "Roboto", size = 32, weight = 800, antialias = true })
surface.CreateFont("EVO_AutoCommon_Name",  { font = "Roboto", size = 28, weight = 700, antialias = true })
surface.CreateFont("EVO_AutoCommon_Body",  { font = "Roboto", size = 18, weight = 400, antialias = true })
surface.CreateFont("EVO_AutoCommon_Btn",   { font = "Roboto", size = 20, weight = 700, antialias = true })

local COL_TXT    = Color(235, 235, 240)
local COL_SUB    = Color(160, 162, 170)
local COL_ACCENT = Color(207, 68, 78)
local COL_CARD   = Color(14, 14, 17)
local COL_NAME   = Color(245, 200, 110)

local _autoCommonFrame

--- Résout le nom d'affichage d'un win_id dans REROLL_DROPS (toutes factions si faction omise).
function EVO_LostSoul.LookupDropName(category, winId, faction)
    if not winId or winId == "" or not REROLL_DROPS then return tostring(winId or "") end
    local function scan(fac)
        local pool = REROLL_DROPS[fac] and REROLL_DROPS[fac][category]
        if not istable(pool) then return nil end
        for _, drop in ipairs(pool) do
            if drop.win_id == winId then
                -- Pour un ART, on affiche le POUVOIR (« Sang ») et pas le personnage
                -- de Bleach (« Unohana »). Table partagée posée par lzy_reroll/sh_config
                -- (fichier SHARED) ; le `and EVO_ArtPowerName` protège d'un ordre de
                -- chargement d'addons défavorable.
                if category == "art_spirituel" and EVO_ArtPowerName then
                    return EVO_ArtPowerName(winId, drop.name)
                end
                return drop.name or winId
            end
        end
        return nil
    end
    if faction and faction ~= "" then
        local n = scan(faction)
        if n then return n end
    end
    for fac in pairs(REROLL_DROPS) do
        local n = scan(fac)
        if n then return n end
    end
    return tostring(winId)
end

--- Ouvre le panel de grant. opts = { kind, winId, name, onClose }
--- kind = "art_spirituel" | "style_de_combat"
function EVO_LostSoul.OpenAutoCommonGrantPanel(opts)
    opts = opts or {}
    if IsValid(_autoCommonFrame) then _autoCommonFrame:Remove() end

    local kind = opts.kind or "art_spirituel"
    local winId = opts.winId or ""
    local fac = IsValid(LocalPlayer()) and LocalPlayer():GetEvoNWString("FactionName", "") or ""
    local name = opts.name
    if not name or name == "" then
        name = EVO_LostSoul.LookupDropName(kind, winId, fac)
    end

    local bArt = (kind == "art_spirituel")
    local sTitle = bArt and "ART SPIRITUEL REÇU" or "STYLE DE COMBAT REÇU"
    local sKindLabel = bArt and "Art spirituel" or "Style de combat"
    local sExplain = "Ce n'est pas ton premier personnage : tu reçois un "
        .. (bArt and "art spirituel" or "style de combat")
        .. " commun aléatoire (pas de reroll sur ce personnage)."

    local W, H = 620, 360
    local frame = vgui.Create("DFrame")
    frame:SetSize(W, H)
    frame:Center()
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    _autoCommonFrame = frame

    frame.Paint = function(_, w, h)
        draw.RoundedBox(10, 0, 0, w, h, COL_CARD)
        surface.SetDrawColor(COL_ACCENT)
        surface.DrawRect(0, 0, w, 3)
        draw.SimpleText(sTitle, "EVO_AutoCommon_Title", w * 0.5, 42,
            COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(sKindLabel .. " commun", "EVO_AutoCommon_Body", w * 0.5, 82,
            COL_SUB, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(name, "EVO_AutoCommon_Name", w * 0.5, 130,
            COL_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local lbl = vgui.Create("DLabel", frame)
    lbl:SetPos(48, 170)
    lbl:SetSize(W - 96, 90)
    lbl:SetFont("EVO_AutoCommon_Body")
    lbl:SetWrap(true)
    lbl:SetContentAlignment(5)
    lbl:SetTextColor(COL_SUB)
    lbl:SetText(sExplain)
    lbl:SetMouseInputEnabled(false)

    local btn = vgui.Create("DButton", frame)
    btn:SetText("")
    btn:SetSize(220, 48)
    btn:SetPos((W - 220) * 0.5, H - 72)
    btn.Paint = function(pnl, w, h)
        local hov = pnl:IsHovered()
        draw.RoundedBox(8, 0, 0, w, h, hov and COL_ACCENT or Color(40, 40, 46))
        draw.SimpleText("Continuer", "EVO_AutoCommon_Btn", w * 0.5, h * 0.5,
            COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btn.DoClick = function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        if IsValid(frame) then frame:Remove() end
        if isfunction(opts.onClose) then opts.onClose() end
    end
end
