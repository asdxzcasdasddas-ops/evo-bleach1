-- "addons\\evo_ui\\lua\\autorun\\client\\cl_evo_ui.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_UI — kit d'interface partagé (DA serveur EVO BleachRP) — v2 « Seireitei »
-- DA : angles CARRÉS avec coins coupés à 45° (haut-droit / bas-gauche), liseré
-- 1px, palette sombre + un seul accent rouge (#cf444e), typo display Bebas Neue
-- (livrée par sh_evo_ui_resources), détails en mono (Consolas), kanji « EVO
-- Kanji » (subset Noto Serif JP livré, 22 KB) pour l'identité Bleach.
-- API v1 conservée : Backdrop / PaintCard / Header / CloseButton / DrawBlur /
-- MakeFonts / Col. Nouveaux helpers : PaintCut, OutlineCut, HoverFrac, Chip,
-- RowButton, ActionButton, Watermark, FooterHints, KanjiNums.
-- ============================================================================

if not CLIENT then return end

EVO_UI = EVO_UI or {}

EVO_UI.Col = {
	bg      = Color(15, 15, 18, 250),
	border  = Color(15, 15, 18, 255),   -- = couleur du fond : contours v1 invisibles (compat)
	line    = Color(255, 255, 255, 16), -- liseré 1px de la v2 (cartes, chips, touches)
	divider = Color(255, 255, 255, 18),
	title   = Color(238, 239, 243),
	muted   = Color(150, 154, 162),
	dim     = Color(106, 109, 118),
	accent  = Color(207, 68, 78),   -- #cf444e : réservé à l'accent/action
	green   = Color(78, 196, 128),
	red     = Color(199, 70, 80),
	shadow  = Color(0, 0, 0, 85),
}

-- Sons UI CUSTOM du projet (mêmes fichiers que le module central ncm_ui_sounds :
-- UI_Hover.mp3 / UI_Cliquer.mp3). On aligne le kit dessus pour que TOUTES les UIs
-- qui passent par EVO_UI.SndHover/SndClick (menu Échap, boutons kit, etc.) jouent
-- le son maison au lieu du stock HL2. Le click custom est déjà joué globalement
-- par ncm_ui_sounds (patch DButton) ; comme c'est le MÊME fichier, l'éventuel
-- recouvrement est inaudible (identique superposé, pas un « double »).
EVO_UI.SndHover = "a4xy732ex6yeop2/g1kpyv29gwai.mp3"
EVO_UI.SndClick = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"

-- « Dégainage » de zanpakuto joué sur les ACTIONS (lancer/valider), pas au
-- survol. Vrai schling du serveur : version workshop (addon crypté) d'abord,
-- sinon la source git, sinon le son stock. Résolu UNE fois au premier appel.
local sndDraw
function EVO_UI.PlayDraw()
	if sndDraw == nil then
		if file.Exists("sound/srvtjl3ecp3ies4/8vhhuhno3u26404/yp7bi1cw95k7ms1u5.wav", "GAME") then
			sndDraw = "srvtjl3ecp3ies4/8vhhuhno3u26404/yp7bi1cw95k7ms1u5.wav"
		elseif file.Exists("sound/constant_sounds/custom_characters/sword_ready.wav", "GAME") then
			sndDraw = "constant_sounds/custom_characters/sword_ready.wav"
		else
			sndDraw = "npc/roller/blade_out.wav"
		end
	end
	surface.PlaySound(sndDraw)
end
EVO_UI.SndDraw = "npc/roller/blade_out.wav" -- compat v2 (préférer EVO_UI.PlayDraw())

-- ── Encres DA v3 (PNG blancs livrés par l'addon workshop UI — teintables). ──
-- Tout est optionnel : si un PNG manque, chaque helper retombe sur le rendu v2.
EVO_UI.TexBrush  = "evo_ui/tex/brush2.png"  -- triple trait horizontal
EVO_UI.TexSlash  = "evo_ui/tex/slash1.png"  -- entaille fine (soulignés)
EVO_UI.TexSplat  = "evo_ui/tex/splat1.png"  -- grosse éclaboussure
EVO_UI.TexSplat2 = "evo_ui/tex/splat2.png"  -- éclaboussure éclatée
EVO_UI.TexGrain  = "evo_ui/tex/grain.png"   -- grain papier (déprécié, rendu neige)
EVO_UI.TexWave   = "evo_ui/tex/seigaiha.png" -- vagues japonaises tileables (fond des cartes)

local matCache = {}
function EVO_UI.Mat(path)
	local m = matCache[path]
	if m == nil then
		m = Material(path, "smooth mips")
		matCache[path] = m
	end
	return m
end
function EVO_UI.HasMat(path)
	local m = EVO_UI.Mat(path)
	return m ~= nil and not m:IsError()
end

-- Entaille de titre STANDARD : largeur mini imposée (un titre court comme
-- « SQUAD » écrasait le trait en gribouillis), épaisseur liée à la largeur.
-- x = bord gauche du titre, y = juste sous le titre, titleW = largeur du texte.
function EVO_UI.TitleSlash(x, y, titleW, a, col)
	local w = math.max((titleW or 0) * 1.30, gRespX(240))
	local h = math.Clamp(math.floor(w * 0.05), gRespY(9), gRespY(14))
	return EVO_UI.Ink(EVO_UI.TexSlash, x, y, w, h, ColorAlpha(col or EVO_UI.Col.accent, 245 * (a or 1)))
end

-- Dessine une encre teintée. Renvoie false si la texture manque (fallback v2).
function EVO_UI.Ink(path, x, y, w, h, col)
	if not EVO_UI.HasMat(path) then return false end
	surface.SetDrawColor(col)
	surface.SetMaterial(EVO_UI.Mat(path))
	surface.DrawTexturedRect(x, y, w, h)
	return true
end

-- Image FANTÔME FLOUTÉE — vrai « LAYER BLUR » (retour user 07/07 : les passes
-- décalées faisaient des copies fantômes, pas un flou). L'image est cuite UNE
-- FOIS dans un render target 512² puis étirée à l'écran : le filtrage
-- bilinéaire de l'upscale produit un vrai flou doux et uniforme, sans coût par
-- frame (1 seul draw, cache par matériau). Baisser GHOST_RT_SIZE = flou plus
-- fort. `alpha` = opacité perçue ; u/v optionnels (cover-crop) — les fractions
-- UV calculées sur l'image d'origine restent valides (squash/stretch s'annulent).
local GHOST_RT_SIZE = 512
local _ghostCache = {} -- Material source -> material RT floutée (false = KO)
local _ghostN = 0
local function ghostBlurredMat(mat)
	local c = _ghostCache[mat]
	if c ~= nil then return c or nil end
	_ghostN = _ghostN + 1
	local name = "evo_ui_ghostblur_" .. _ghostN
	-- Version mips du matériau source : minification PROPRE vers 512px (sans
	-- mips, le downscale échantillonne 1 pixel sur N -> bruit cuit dans la RT).
	local src = mat
	local sName = mat.GetName and mat:GetName() or ""
	if sName ~= "" then
		local m2 = Material(sName, "smooth mips")
		if m2 and not m2:IsError() then src = m2 end
	end
	local rt
	if GetRenderTargetEx and IMAGE_FORMAT_BGRA8888 ~= nil then
		local fl = (bit and bit.bor) and bit.bor(2, 4, 8, 256, 32768) or (2 + 4 + 8 + 256 + 32768)
		rt = GetRenderTargetEx(name, GHOST_RT_SIZE, GHOST_RT_SIZE, RT_SIZE_LITERAL or 1,
			MATERIAL_RT_DEPTH_NONE, fl, 0, IMAGE_FORMAT_BGRA8888)
	end
	if not rt then rt = GetRenderTarget(name, GHOST_RT_SIZE, GHOST_RT_SIZE) end
	if not rt then _ghostCache[mat] = false return nil end
	render.PushRenderTarget(rt)
	render.Clear(0, 0, 0, 0, true, true)
	cam.Start2D()
	surface.SetDrawColor(255, 255, 255, 255)
	surface.SetMaterial(src)
	surface.DrawTexturedRect(0, 0, GHOST_RT_SIZE, GHOST_RT_SIZE)
	cam.End2D()
	render.PopRenderTarget()
	local m = CreateMaterial(name .. "_m", "UnlitGeneric", {
		["$basetexture"] = rt:GetName(),
		["$translucent"] = "1",
		["$vertexalpha"] = "1",
		["$vertexcolor"] = "1",
	})
	_ghostCache[mat] = m
	return m
end

function EVO_UI.GhostBlur(mat, x, y, w, h, alpha, spread, u0, v0, u1, v1)
	if not mat or mat:IsError() then return end
	if (alpha or 0) < 0.5 then return end -- fondu d'ouverture : rien à dessiner
	u0, v0, u1, v1 = u0 or 0, v0 or 0, u1 or 1, v1 or 1
	surface.SetMaterial(ghostBlurredMat(mat) or mat)
	surface.SetDrawColor(255, 255, 255, math.max(1, math.Round(alpha)))
	surface.DrawTexturedRectUV(x, y, w, h, u0, v0, u1, v1)
end

-- Accès PUBLIC au matériau flouté (layer blur) d'une image : pour les écrans
-- qui dessinent l'image en POLYGONE (UV par sommet, ex. cartes à coins coupés
-- du dashboard Échap) au lieu d'un rect. nil si le bake est impossible.
function EVO_UI.GhostBlurMat(mat)
	if not mat or mat:IsError() then return nil end
	return ghostBlurredMat(mat)
end

-- Motif de fond de carte : la « matière » qui casse le rendu plastique, quasi
-- subliminale. `style` évite que TOUTES les UI tilent le même seigaiha :
--   "wave" (défaut) : seigaiha tilé (alpha max 12 cuit dans le PNG)
--   "rain"          : traits verticaux fins irréguliers (pluie)
--   "diag"          : hachures 45°, même angle que les coins coupés
--   "none"          : aplat pur
-- rain/diag sont procéduraux (déterministes, stables frame à frame) : aucune
-- texture de plus à livrer dans l'addon workshop.
function EVO_UI.Grain(w, h, a, style)
	a = a or 1
	style = style or "wave"
	if style == "none" then return end
	if style == "rain" then
		surface.SetDrawColor(255, 255, 255, 11 * a)
		local step = gRespX(34)
		for i = 0, math.floor(w / step) do
			-- hash entier par colonne (pas de math.random : rendu stable)
			local r1 = (i * 7919 + 131) % 100 / 100
			local r2 = (i * 4271 + 59) % 100 / 100
			local r3 = (i * 2657 + 17) % 100 / 100
			local len = math.floor(h * (0.18 + 0.45 * r2))
			surface.DrawRect(i * step + math.floor(r1 * step * 0.7), math.floor(r3 * (h - len)), 1, len)
		end
		return
	end
	if style == "diag" then
		surface.SetDrawColor(255, 255, 255, 9 * a)
		local gap = gRespX(64)
		for x = -h, w, gap do
			surface.DrawLine(x, h, x + h, 0)
		end
		return
	end
	if not EVO_UI.HasMat(EVO_UI.TexWave) then return end
	-- opacité /6 au total (retours user successifs : motif à peine perceptible)
	surface.SetDrawColor(255, 255, 255, 42 * a)
	surface.SetMaterial(EVO_UI.Mat(EVO_UI.TexWave))
	local ts = gRespY(512)
	for ty = 0, math.ceil(h / ts) - 1 do
		for tx = 0, math.ceil(w / ts) - 1 do
			surface.DrawTexturedRect(tx * ts, ty * ts, ts, ts)
		end
	end
end

-- Perso en grand, ancré bas-droit du rect (x, y, w, h), éclaboussure accent
-- derrière (façon poster). key = nom du PNG dans evo_ui/chars/ (sans ext).
-- Panneau-local : EVO_UI.Char(0, 0, w, h, ...). opts : scale (part de la
-- hauteur du rect, déf .92), alpha (déf 80 : filigrane lisible ; ~230 sur une
-- zone dédiée), splat=false, ox/oy. NB : pas de clipping ici — si le rect ne
-- correspond pas au panneau peint, poser un render.SetScissorRect autour.
function EVO_UI.Char(x, y, w, h, key, a, opts)
	if not key or key == "" then return false end
	opts = opts or {}
	local path = "evo_ui/chars/" .. key .. ".png"
	if not EVO_UI.HasMat(path) then return false end
	a = a or 1
	local mat = EVO_UI.Mat(path)
	local mw, mh = mat:Width(), mat:Height()
	if mw <= 0 or mh <= 0 then return false end
	local ph = math.floor(h * (opts.scale or 0.92))
	local pw = math.floor(ph * mw / mh)
	local px = x + w - pw + (opts.ox or gRespX(12))
	local py = y + h - ph + (opts.oy or gRespY(4))
	if opts.splat ~= false then
		EVO_UI.Ink(EVO_UI.TexSplat, px - pw * 0.20, py + ph * 0.10, pw * 1.3, pw * 1.3,
			ColorAlpha(EVO_UI.Col.accent, 20 * a))
	end
	-- Teinté TRÈS sombre (~35%) : le perso est une présence dans l'ombre de la
	-- carte, pas une image posée dessus (retour user, assombri 2x).
	local t = opts.tint or 88
	surface.SetDrawColor(t, t, t + 4, (opts.alpha or 185) * a)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(px, py, pw, ph)
	return true
end

-- Chiffres kanji (divisions du Gotei, numérotation d'écrans...).
EVO_UI.KanjiNums = { "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三" }

local BLUR = Material("pp/blurscreen")

function EVO_UI.MakeFonts()
	if not gCreateRespFont then return end
	-- Display (Bebas Neue, livrée par le kit). Poids 400 : depuis le fix du
	-- remap glibs (06/07) le VRAI TTF rend — un poids 700 déclenchait un
	-- faux-bold synthétique (retours user répétés « pas de bold »).
	gCreateRespFont("EVO_UI_Header",  "Bebas Neue", 23, 400)
	gCreateRespFont("EVO_UI_Display", "Bebas Neue", 32, 400)
	gCreateRespFont("EVO_UI_Big",     "Bebas Neue", 44, 400)
	gCreateRespFont("EVO_UI_Item",    "Bebas Neue", 19, 400)
	-- Texte courant / détails techniques.
	gCreateRespFont("EVO_UI_Sub",     "Roboto", 12, 500)
	gCreateRespFont("EVO_UI_Mono",    "Consolas", 13, 500)
	-- Kanji (subset « EVO Kanji » livré par le kit).
	gCreateRespFont("EVO_UI_Kanji",   "EVO Kanji", 17, 700)
	gCreateRespFont("EVO_UI_KanjiXL", "EVO Kanji", 150, 700)
	gCreateRespFont("EVO_UI_X",       "Roboto", 28, 500)
end
-- evo_ui charge AVANT glibs (ordre alpha) -> gCreateRespFont pas encore prêt.
-- On crée les fonts à Initialize (glibs chargé) + au resize, sans planter au load.
hook.Add("Initialize", "EVO_UI::FontsInit", EVO_UI.MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_UI::Fonts", EVO_UI.MakeFonts)
EVO_UI.MakeFonts()

-- Flou plein écran (helper du gamemode, sinon fallback manuel non-clippé).
function EVO_UI.DrawBlur(panel, amount)
	if MUGEN and MUGEN.DrawBlur then MUGEN.DrawBlur(panel, amount) return end
	local x, y = panel:LocalToScreen(0, 0)
	surface.SetMaterial(BLUR)
	surface.SetDrawColor(255, 255, 255, 255)
	for i = 1, 4 do
		BLUR:SetFloat("$blur", (i / 4) * (amount or 5))
		BLUR:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
end

-- Fraction de survol animée (0..1), à appeler dans un Paint. Stockée sur le
-- panneau -> chaque bouton anime indépendamment.
function EVO_UI.HoverFrac(s, speed)
	s._hf = Lerp(FrameTime() * (speed or 10), s._hf or 0, s:IsHovered() and 1 or 0)
	return s._hf
end

-- ── Formes « coins coupés » ──────────────────────────────────────────────────
-- Polygone plein avec coins coupés à 45°. corners : "tr-bl" (défaut, cartes),
-- "br" (boutons d'action), "tl". Renvoie les points (pour OutlineCut).
-- FIX « petit contour noir » (08/07) : draw.NoTexture() -> la texture blanche
-- de l'atlas vgui BAVE une frange sombre de 1px sur les bords filtrés des
-- polygones. On dessine avec un matériau BLANC PUR ($vertexcolor/$vertexalpha)
-- -> les bords se fondent proprement, plus de contour noir autour des plaques.
local MAT_POLY_WHITE = CreateMaterial("evo_ui_poly_white", "UnlitGeneric", {
	["$basetexture"] = "color/white",
	["$vertexcolor"] = 1,
	["$vertexalpha"] = 1,
})
-- Points du polygone à coins coupés SANS le dessiner (géométrie seule —
-- sert aux bordures tracées ailleurs qu'aux bornes exactes de la plaque).
function EVO_UI.CutPoints(x, y, w, h, cut, corners)
	cut = math.min(cut or gRespY(14), math.floor(math.min(w, h) / 2))
	corners = corners or "tr-bl"
	if corners == "br" then
		return { { x = x, y = y }, { x = x + w, y = y }, { x = x + w, y = y + h - cut },
			{ x = x + w - cut, y = y + h }, { x = x, y = y + h } }
	elseif corners == "tl" then
		return { { x = x + cut, y = y }, { x = x + w, y = y }, { x = x + w, y = y + h },
			{ x = x, y = y + h }, { x = x, y = y + cut } }
	elseif corners == "bl" then
		return { { x = x, y = y }, { x = x + w, y = y }, { x = x + w, y = y + h },
			{ x = x + cut, y = y + h }, { x = x, y = y + h - cut } }
	elseif corners == "tr" then
		return { { x = x, y = y }, { x = x + w - cut, y = y }, { x = x + w, y = y + cut },
			{ x = x + w, y = y + h }, { x = x, y = y + h } }
	end
	return { { x = x, y = y }, { x = x + w - cut, y = y }, { x = x + w, y = y + cut },
		{ x = x + w, y = y + h }, { x = x + cut, y = y + h }, { x = x, y = y + h - cut } }
end

function EVO_UI.PaintCut(x, y, w, h, col, cut, corners)
	local pts = EVO_UI.CutPoints(x, y, w, h, cut, corners)
	surface.SetMaterial(MAT_POLY_WHITE)
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
	return pts
end

-- Bordure de survol PROPRE dans un panneau CLIPPÉ (fix 08/07 « hovers pas
-- clean ») : une ligne tracée à x=w ou y=h est HORS de la zone de dessin du
-- panneau -> les bords droit/bas de la bordure manquaient. On trace donc le
-- liseré 1px À L'INTÉRIEUR des bornes (inset 1px), en 2 passes (plus dense).
-- À utiliser pour toute bordure accent au survol d'une plaque dessinée à
-- (0,0,w,h) sans NoClipping. cut/corners = les mêmes que la plaque.
function EVO_UI.HoverOutline(w, h, col, cut, corners)
	local pts = EVO_UI.CutPoints(1, 1, w - 2, h - 2, cut, corners)
	EVO_UI.OutlineCut(pts, col)
	EVO_UI.OutlineCut(pts, col)
end

-- Liseré 1px le long d'un polygone renvoyé par PaintCut.
function EVO_UI.OutlineCut(pts, col)
	surface.SetDrawColor(col)
	local n = #pts
	for i = 1, n do
		local a, b = pts[i], pts[i % n + 1]
		surface.DrawLine(a.x, a.y, b.x, b.y)
	end
end

-- Shared by native Derma tooltips and the richer, hand-painted item tooltips.
function EVO_UI.PaintTooltip(x, y, w, h)
	local cut = math.min(6, w * 0.25, h * 0.25)
	local pts = EVO_UI.PaintCut(x, y, w - 1, h - 1, Color(22, 22, 27), cut)
	EVO_UI.OutlineCut(pts, EVO_UI.Col.divider)
	surface.SetDrawColor(EVO_UI.Col.accent)
	surface.DrawRect(x, y + 2, 2, math.max(0, h - cut - 4))
end

-- DTooltip copies its target's skin in OpenForPanel. Paint explicitly so even
-- a target that still uses Default (e.g. an already open UI) gets the EVO style.
local TOOLTIP = {}
function TOOLTIP:Init()
	self:SetDrawOnTop(true)
	self.DeleteContentsOnClose = false
	self:SetText("")
	self:SetFont("EVO_UI_Item")
	self:SetTextColor(EVO_UI.Col.title)
end
function TOOLTIP:UpdateColours()
	self:SetTextStyleColor(EVO_UI.Col.title)
end
function TOOLTIP:PerformLayout()
	local padX, padY = 12, 6
	if IsValid(self.Contents) then
		self:SetSize(self.Contents:GetWide() + padX * 2, self.Contents:GetTall() + padY * 2)
		self.Contents:SetPos(padX, padY)
		self.Contents:SetVisible(true)
	else
		local w, h = self:GetContentSize()
		self:SetSize(w + padX * 2, h + padY * 2)
		self:SetContentAlignment(5)
	end
end
function TOOLTIP:Paint(w, h)
	self:PositionTooltip()
	EVO_UI.PaintTooltip(0, 0, w, h)
end
vgui.Register("EVO_Tooltip", TOOLTIP, "DTooltip")

-- Crée un backdrop plein écran flouté + assombri (fondu). `fClose` est appelé
-- au clic dans le vide / Échap. Le menu se crée APRÈS pour passer au-dessus.
function EVO_UI.Backdrop(fClose)
	local p = vgui.Create("DFrame")
	p:SetSize(ScrW(), ScrH())
	p:SetPos(0, 0)
	p:SetTitle("")
	p:ShowCloseButton(false)
	p:SetDraggable(false)
	p:MakePopup()
	p._a = 0
	p.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	p.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		EVO_UI.DrawBlur(s, 5)
		surface.SetDrawColor(0, 0, 0, 150 * a)
		surface.DrawRect(0, 0, w, h)
	end
	if isfunction(fClose) then
		p.OnMousePressed = fClose
		if EVO_MakeEscClosable then EVO_MakeEscClosable(p, fClose) end
	end
	return p
end

-- Dessine la carte standard v2 : fond sombre à coins coupés + liseré 1px.
-- À appeler en tête du Paint d'un panneau-carte. `a` = alpha (0..1).
-- (compat v1 : le paramètre `radius` devient la taille du coin coupé)
-- `pattern` optionnel : cf. EVO_UI.Grain ("wave" défaut, "rain", "diag", "none").
-- Vis d'angle Atelier (anneau sombre / tête / centre clair / fente 38°,
-- SANS reflet blanc — règle DA). Publique : réutilisable par les écrans.
local function _screwCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local ang = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(ang) * r, y = cy + math.sin(ang) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end
function EVO_UI.Screw(cx, cy, r)
	_screwCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	_screwCircle(cx, cy, r, Color(23, 25, 29, 255))
	_screwCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

function EVO_UI.PaintCard(w, h, a, radius, pattern)
	a = a or 1
	local cut = radius or gRespY(16)
	-- DA ATELIER v2 (08/07, « reprendre la DA du dashboard partout ») : plaque de
	-- métal noir PLATE + vis d'angle. Le LISERÉ ACIER a été RETIRÉ (c'était le
	-- « contour noir » que le user voulait enlever ; le bord rouge n'apparaît
	-- plus qu'au SURVOL via EVO_UI.HoverPlate). Tous les écrans qui passent par
	-- PaintCard/Header (dialogues, events instructeur, stafflogs, warns…)
	-- héritent de la DA d'un coup.
	EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250 * a), cut)
	-- Vis UNIQUEMENT sur les vraies cartes (pas les mini-chips HUD), et une fois
	-- le fondu d'ouverture passé (les vis ne se fondent pas). Retrait UNIFORME
	-- 18px aux 4 coins (« bien aligné », même recette que le dashboard) — assez
	-- rentré pour passer sous les coins coupés 45°.
	if a > 0.5 and w > gRespX(300) and h > gRespY(150) then
		local sr = gRespY(5)
		local mx, my = gRespX(18), gRespY(18)
		EVO_UI.Screw(mx, my, sr)
		EVO_UI.Screw(w - mx, my, sr)
		EVO_UI.Screw(w - mx, h - my, sr)
		EVO_UI.Screw(mx, h - my, sr)
	end
end

-- ── Plaque INTERACTIVE « dashboard » (08/07, DA validée sur le menu Échap) ────
-- À appeler en tête du Paint d'un DButton-carte (le bouton DOIT être en
-- s:NoClipping(true) pour que la plaque déborde au survol). Dessine : plaque
-- PLATE (éclaircie au survol) + vis d'angle alignées + RESSORT au survol (la
-- carte grossit un peu et glisse vers le haut-gauche) + BORDURE ROUGE
-- extérieure au survol. Renvoie gx, gy, gw, gh (bornes ÉTENDUES : positionner
-- le contenu par rapport à elles), plus hf (fraction de survol) et pts.
-- opts (option) : { cut=, corners="tr-bl", speed=10, grow=6, screws=true,
--                   growPx=6, offPx=5, a=1 }.
function EVO_UI.HoverPlate(s, w, h, opts)
	opts = opts or {}
	local a = opts.a or 1
	local hf = opts.static and 0 or EVO_UI.HoverFrac(s, opts.speed or 10)
	local grow = hf * gRespY(opts.growPx or 6)
	local offX = -hf * gRespX(opts.offPx or 5)
	local offY = -hf * gRespY(opts.offPx or 5)
	local gx, gy = -grow + offX, -grow + offY
	local gw, gh = w + grow * 2, h + grow * 2
	local cut = opts.cut or gRespY(14)
	-- Plaque plate : un cran plus claire au survol (comme les cartes du dashboard).
	local plate = hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 235)
	local pts = EVO_UI.PaintCut(gx, gy, gw, gh, ColorAlpha(plate, plate.a * a), cut, opts.corners)
	if opts.screws ~= false and gw > gRespX(120) and gh > gRespY(70) then
		local sr = gRespY(4)
		local mx, my = gRespX(16), gRespY(16)
		EVO_UI.Screw(gx + mx, gy + my, sr)
		EVO_UI.Screw(gx + gw - mx, gy + my, sr)
		EVO_UI.Screw(gx + gw - mx, gy + gh - my, sr)
		EVO_UI.Screw(gx + mx, gy + gh - my, sr)
	end
	-- Survol : léger voile clair + BORDURE ROUGE extérieure (2 passes ≈ 2px).
	if hf > 0.02 then
		draw.NoTexture()
		surface.SetDrawColor(226, 230, 238, 10 * hf * a)
		surface.DrawPoly(pts)
		local bcol = ColorAlpha(EVO_UI.Col.accent, 235 * hf * a)
		EVO_UI.OutlineCut(pts, bcol)
		EVO_UI.OutlineCut(pts, bcol)
	end
	return gx, gy, gw, gh, hf, pts
end

-- Header standard v2 : carré d'accent rouge + titre Bebas + texte mono à
-- droite + filet. Retourne la hauteur du header (pour positionner le contenu).
function EVO_UI.Header(w, title, rightText, a, padX)
	a = a or 1
	padX = padX or gRespX(26)
	local cyH = gRespY(33)
	-- v4 : plus de carré d'accent — le titre est signé par l'ENTAILLE de
	-- pinceau, calibrée sur la largeur du titre (retour user : trop petite).
	draw.SimpleText(title or "", "EVO_UI_Header", padX, cyH, ColorAlpha(EVO_UI.Col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	if rightText and rightText ~= "" then
		draw.SimpleText(rightText, "EVO_UI_Mono", w - padX - gRespX(34), cyH, ColorAlpha(EVO_UI.Col.dim, 255 * a), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	-- Filet DENTÉ Atelier sous le header (remplace le trait plein).
	surface.SetDrawColor(ColorAlpha(EVO_UI.Col.divider, 55 * a))
	local dashW, dashGap = gRespX(6), gRespX(5)
	local dx = padX
	while dx < w - padX do
		surface.DrawRect(dx, gRespY(58), math.min(dashW, w - padX - dx), 1)
		dx = dx + dashW + dashGap
	end
	surface.SetFont("EVO_UI_Header")
	local tw = surface.GetTextSize(title or "")
	if not EVO_UI.TitleSlash(padX - gRespX(4), gRespY(46), tw, a) then
		surface.SetDrawColor(ColorAlpha(EVO_UI.Col.accent, 255 * a))
		surface.DrawRect(padX, gRespY(52), tw, gRespY(3))
	end
	return 60
end

-- Petite croix de fermeture standard (à parenter sur la carte).
function EVO_UI.CloseButton(parent, cardW, fClose)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(gRespX(34), gRespY(34))
	b:SetPos(gRespX(cardW - 48), gRespY(16))
	b.Paint = function(s, w, h)
		-- Croix standard DA (07/07) : glyphe ✕ seul, AUCUN fond, gris -> accent.
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			s:IsHovered() and EVO_UI.Col.accent or EVO_UI.Col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClose
	return b
end

-- ── Nouveaux composants v2 ───────────────────────────────────────────────────

-- Rangée de liste (menu hub, pickers) : numéro mono + libellé Bebas + kanji à
-- droite. data = { num=, label=, kanji=, fill= (accent alternatif) }.
-- Sélection via b:SetSel(true) : fond accent plein + barre blanche à gauche.
function EVO_UI.RowButton(parent, x, y, w, h, data, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(x, y)
	b:SetSize(w, h)
	b._sel = false
	function b:SetSel(v) self._sel = v end
	b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	b.Paint = function(s, bw, bh)
		local col = EVO_UI.Col
		local accent = data.fill or col.accent
		local hf = EVO_UI.HoverFrac(s, 10)
		if s._sel then
			-- sélection FLATE : aplat accent + barre blanche, rien d'autre
			-- (l'éclaboussure d'encre v3 sur la rangée active surchargeait)
			surface.SetDrawColor(accent)
			surface.DrawRect(0, 0, bw, bh)
			surface.SetDrawColor(255, 255, 255, 230)
			surface.DrawRect(0, 0, gRespX(2), bh)
		else
			if hf > 0.01 then
				surface.SetDrawColor(ColorAlpha(accent, 26 * hf))
				surface.DrawRect(0, 0, bw, bh)
				surface.SetDrawColor(ColorAlpha(accent, 255 * hf))
				surface.DrawRect(0, 0, gRespX(2), bh)
			end
			surface.SetDrawColor(ColorAlpha(col.divider, 45))
			surface.DrawRect(gRespX(2), bh - 1, bw - gRespX(4), 1)
		end
		local px = gRespX(14)
		if data.num then
			-- data.numFont / data.numPad : override optionnel (comme data.font).
			draw.SimpleText(data.num, data.numFont or "EVO_UI_Mono", px, bh / 2, s._sel and ColorAlpha(color_white, 200) or col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			px = px + gRespX(data.numPad or 28)
		end
		draw.SimpleText(data.label or "", data.font or "EVO_UI_Item", px, bh / 2, s._sel and color_white or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if data.kanji then
			draw.SimpleText(data.kanji, "EVO_UI_Kanji", bw - gRespX(12), bh / 2, s._sel and ColorAlpha(color_white, 220) or ColorAlpha(col.dim, 190), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
	b.DoClick = function(s)
		surface.PlaySound(EVO_UI.SndClick)
		if fn then fn(s) end
	end
	return b
end

-- Bouton d'action : plein accent, coin bas-droit coupé, hover animé + son.
-- `fill` optionnel (défaut accent rouge ; passer Col.green pour valider, etc.)
function EVO_UI.ActionButton(parent, x, y, w, h, label, fill, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(x, y)
	b:SetSize(w, h)
	b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	b.Paint = function(s, bw, bh)
		local base = fill or EVO_UI.Col.accent
		local hf = EVO_UI.HoverFrac(s, 8)
		local c = Color(
			Lerp(hf, base.r * 0.80, base.r),
			Lerp(hf, base.g * 0.80, base.g),
			Lerp(hf, base.b * 0.80, base.b), base.a or 255)
		-- hover FLAT : seul l'aplat s'éclaircit (l'encre v3 au survol surchargeait)
		EVO_UI.PaintCut(0, 0, bw, bh, c, gRespY(10), "br")
		-- s._font : override de fonte par bouton (posé par l'appelant après création).
		draw.SimpleText(s._lbl or label, s._font or "EVO_UI_Item", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	-- Bouton d'action = VRAI dégainage de zanpakuto (schling). Les boutons +/-
	-- passent un flag pour rester sur un tick discret.
	b.DoClick = function(s)
		if s._quietClick then surface.PlaySound(EVO_UI.SndClick) else EVO_UI.PlayDraw() end
		if fn then fn(s) end
	end
	return b
end

-- Sélecteur de quantité (slider + champ). Renvoie get() → entier 1..maxQ.
-- Hauteur utile : ~58 à 1080p (label + piste), ~32 si opts.hideLabel.
-- Invisible côté appelant si maxQ <= 1.
function EVO_UI.QtyPicker(parent, x, y, w, h, maxQ, initial, opts)
	maxQ = math.max(1, math.floor(tonumber(maxQ) or 1))
	local want = math.Clamp(math.floor(tonumber(initial) or maxQ), 1, maxQ)
	local val = want
	local col = EVO_UI.Col
	local syncing = false
	opts = istable(opts) and opts or {}
	-- DSlider fire OnValueChanged(0) au premier layout : sans ce garde, « Récupérer »
	-- une pile de 2 envoie 1 alors que le slider affiche encore le max.
	local armed = false

	local bLabel = opts.hideLabel ~= true
	if bLabel then
		local lbl = vgui.Create("DLabel", parent)
		lbl:SetPos(x, y)
		lbl:SetSize(w, gRespY(20))
		lbl:SetFont("Bebas Neue:22")
		lbl:SetTextColor(col.muted)
		lbl:SetText("QUANTITÉ")
	end

	local entryW = gRespX(62)
	local trackY = y + (bLabel and gRespY(26) or 0)
	local trackH = gRespY(22)

	local slider = vgui.Create("DSlider", parent)
	slider:SetPos(x, trackY)
	slider:SetSize(math.max(gRespX(40), w - entryW - gRespX(10)), trackH)
	slider:SetLockY(0.5)
	slider:SetTrapInside(true)
	slider:SetSlideX(maxQ > 1 and ((val - 1) / (maxQ - 1)) or 1)
	if IsValid(slider.Knob) then
		slider.Knob:SetSize(gRespX(14), gRespY(14))
		slider.Knob.Paint = function(_, kw, kh)
			draw.RoundedBox(kh / 2, 0, 0, kw, kh, col.accent)
		end
	end
	slider.Paint = function(s, pw, ph)
		local frac = maxQ > 1 and ((val - 1) / (maxQ - 1)) or 1
		surface.SetDrawColor(40, 42, 50, 255)
		surface.DrawRect(0, ph / 2 - 2, pw, 4)
		surface.SetDrawColor(col.accent)
		surface.DrawRect(0, ph / 2 - 2, math.max(4, pw * frac), 4)
	end

	local entryBg = vgui.Create("DPanel", parent)
	entryBg:SetPos(x + w - entryW, trackY - gRespY(2))
	entryBg:SetSize(entryW, trackH + gRespY(4))
	entryBg.Paint = function(_, ew, eh)
		EVO_UI.PaintCut(0, 0, ew, eh, Color(24, 26, 31, 235), gRespY(6))
	end
	local entry = vgui.Create("DTextEntry", entryBg)
	entry:Dock(FILL)
	entry:DockMargin(gRespX(6), gRespY(2), gRespX(6), gRespY(2))
	entry:SetFont("Bebas Neue:22")
	entry:SetTextColor(col.title)
	entry:SetCursorColor(col.title)
	entry:SetPaintBackground(false)
	entry:SetDrawLanguageID(false)
	entry:SetNumeric(true)
	entry:SetUpdateOnType(true)
	entry:SetText(tostring(val))
	entry.Paint = function(s, ew, eh)
		s:DrawTextEntryText(col.title, col.accent, col.title)
	end

	local function apply(n, fromSlider)
		n = math.Clamp(math.floor(tonumber(n) or val), 1, maxQ)
		val = n
		if not fromSlider then
			slider:SetSlideX(maxQ > 1 and ((n - 1) / (maxQ - 1)) or 1)
		end
		if not syncing then
			syncing = true
			if entry:GetText() ~= tostring(n) then entry:SetText(tostring(n)) end
			syncing = false
		end
	end

	function slider:OnValueChanged(sx)
		if not armed or maxQ <= 1 then return end
		apply(1 + math.Round((tonumber(sx) or self:GetSlideX()) * (maxQ - 1)), true)
	end
	slider.Think = function(s)
		if not s._qtyPrimed then
			s._qtyPrimed = true
			apply(want, false)
			armed = true
			return
		end
		if maxQ > 1 and s:GetDragging() then
			apply(1 + math.Round(s:GetSlideX() * (maxQ - 1)), true)
		end
	end
	slider.OnMouseWheeled = function(_, delta)
		apply(val + (delta > 0 and 1 or -1), false)
		return true
	end
	entry.OnValueChange = function(_, v)
		if syncing then return end
		local n = tonumber(v)
		if n then apply(n, false) end
	end
	entry.OnEnter = function() apply(entry:GetValue(), false) end
	entry.OnLoseFocus = function() apply(entry:GetValue(), false) end

	return function()
		return val
	end
end

-- Chip technique (mono encadré 1px). Dessine à (x, y), renvoie sa largeur
-- pour enchaîner : x = x + EVO_UI.Chip(...) + gRespX(6).
function EVO_UI.Chip(x, y, label, a, colText)
	a = a or 1
	surface.SetFont("EVO_UI_Mono")
	local tw, th = surface.GetTextSize(label)
	local padX, padY = gRespX(8), gRespY(3)
	local w, h = tw + padX * 2, th + padY * 2
	surface.SetDrawColor(ColorAlpha(EVO_UI.Col.line, 45 * a))
	surface.DrawOutlinedRect(x, y, w, h)
	draw.SimpleText(label, "EVO_UI_Mono", x + padX, y + h / 2, ColorAlpha(colText or EVO_UI.Col.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	return w
end

-- Portrait de perso : dessine materials/evo_ui/chars/<key>.png à (x,y,w,h).
-- Renvoie false si la clé est vide ou le PNG absent (l'appelant retombe alors
-- sur le kanji filigrane). Matériaux mis en cache.
local portraitCache = {}
function EVO_UI.Portrait(x, y, w, h, key, a)
	if not key or key == "" then return false end
	local mat = portraitCache[key]
	if mat == nil then
		mat = Material("evo_ui/chars/" .. key .. ".png", "smooth mips")
		portraitCache[key] = mat or false
	end
	if not mat or mat:IsError() then return false end
	surface.SetDrawColor(255, 255, 255, 255 * (a or 1))
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(x, y, w, h)
	return true
end

-- Gros kanji en filigrane, ancré bas-droit (clippé par le panneau).
function EVO_UI.Watermark(w, h, kanji, a)
	if not kanji or kanji == "" then return end
	draw.SimpleText(kanji, "EVO_UI_KanjiXL", w - gRespX(4), h + gRespY(18), ColorAlpha(EVO_UI.Col.accent, 18 * (a or 1)), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
end

-- ── Helpers VGUI de menu PARTAGÉS (extraction 2026-07-14) ────────────────────
-- Ces briques étaient COPIÉES à l'identique dans ~15 menus (evo_clan, lzy_squad,
-- evo_famille, lzy_bindmenu, lzy_spell_selector, lzy_animation_menu...). On les
-- centralise ici. Les fonctions qui DESSINENT prennent une PALETTE en dernier
-- argument (chaque menu passe SES couleurs) : { accent, accentHov, row, rowHov,
-- txt, scroll }. Requièrent glibs (RNDX/gSetPos/gRespX) — présent au call-time.

-- Le panneau contient-il le curseur ? (hover géométrique fiable en clip). Pur.
function EVO_UI.PanelContainsCursor(pnl)
	if not IsValid(pnl) or not pnl:IsVisible() then return false end
	local mx, my = gui.MousePos()
	local lx, ly = pnl:ScreenToLocal(mx, my)
	local w, h = pnl:GetWide(), pnl:GetTall()
	return lx >= 0 and ly >= 0 and lx < w and ly < h
end

-- Tronque un texte à nMaxW px, ajoute "..." (UTF-8 sûr). Pur.
function EVO_UI.TruncText(sText, sFont, nMaxW)
	surface.SetFont(sFont)
	if surface.GetTextSize(sText) <= nMaxW then return sText end
	local nLen = (utf8 and utf8.len and utf8.len(sText)) or #sText
	while nLen and nLen > 1 do
		nLen = nLen - 1
		local sCut = (utf8 and utf8.sub) and utf8.sub(sText, 1, nLen) or string.sub(sText, 1, nLen)
		if surface.GetTextSize(sCut .. "...") <= nMaxW then return sCut .. "..." end
	end
	return sText
end

-- Pliage accents -> ASCII minuscule (recherche insensible casse/accents). Pur.
local _foldTbl = {
	["à"]="a", ["â"]="a", ["ä"]="a", ["é"]="e", ["è"]="e", ["ê"]="e", ["ë"]="e",
	["î"]="i", ["ï"]="i", ["ô"]="o", ["ö"]="o", ["ù"]="u", ["û"]="u", ["ü"]="u", ["ç"]="c",
	["À"]="a", ["Â"]="a", ["Ä"]="a", ["É"]="e", ["È"]="e", ["Ê"]="e", ["Ë"]="e",
	["Î"]="i", ["Ï"]="i", ["Ô"]="o", ["Ö"]="o", ["Ù"]="u", ["Û"]="u", ["Ü"]="u", ["Ç"]="c",
}
function EVO_UI.FoldStr(s)
	s = string.lower(tostring(s or ""))
	for a, p in pairs(_foldTbl) do s = string.gsub(s, a, p) end
	return s
end

-- Puce brush accent devant un intitulé de section, puis le texte décalé.
-- (y = haut de zone, h = hauteur de zone, col = couleur texte, accentCol = puce.)
function EVO_UI.DrawBrushLabel(sText, sFont, y, h, col, accentCol)
	local bw, bh = gRespX(26), gRespY(13)
	if EVO_UI.Ink("evo_ui/tex/brush1.png", 0, y + h / 2 - bh / 2, bw, bh, ColorAlpha(accentCol or EVO_UI.Col.accent, 230)) then
		draw.SimpleText(sText, sFont, gRespX(34), y + h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		return
	end
	draw.SimpleText(sText, sFont, 0, y + h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

-- Scrollbar DA : grip fin, accent au survol. pal = { accent, scroll }.
function EVO_UI.StyleScrollBar(scroll, pal)
	local vbar = scroll:GetVBar()
	if not IsValid(vbar) then return end
	vbar:SetHideButtons(true)
	vbar:SetWide(math.max(4, gRespX(6)))
	vbar.Paint = function() end
	vbar.btnGrip.Paint = function(selff, w, h)
		local cA = pal and pal.accent or EVO_UI.Col.accent
		local cS = pal and pal.scroll or EVO_UI.Col.dim
		RNDX.Draw(w * 0.5, 0, 0, w, h, EVO_UI.PanelContainsCursor(selff) and cA or cS)
	end
end

-- Bouton typé DA (RNDX plein, styles "primary"/"danger"/"neutral"/autre=neutral).
-- pal = { accent, accentHov, row, rowHov, txt }. Tolère x/y/w/h nil (=0).
function EVO_UI.MakeBtn(parent, x, y, w, h, sLabel, sFont, sStyle, fnClick, pal)
	pal = pal or {}
	local cAccent    = pal.accent    or EVO_UI.Col.accent
	local cAccentHov = pal.accentHov or EVO_UI.Col.accent
	local cRow       = pal.row       or EVO_UI.Col.bg
	local cRowHov    = pal.rowHov    or EVO_UI.Col.bg
	local cTxt       = pal.txt       or EVO_UI.Col.title
	local btn = vgui.Create("DButton", parent)
	btn:gSetPos(x or 0, y or 0)
	btn:gSetSize(w or 0, h or 0)
	btn:SetText("")
	btn:SetCursor("hand")
	btn.Paint = function(selff, ww, hh)
		local bHover = EVO_UI.PanelContainsCursor(selff)
		-- DrawMoneyLine = drop-in de draw.SimpleText qui rend l'icône argent à la place du « ¥ »
		-- (les libellés à prix « ACHETER · X ¥ » affichent l'icône ; les libellés sans ¥ inchangés).
		local dtext = (MUGEN and MUGEN.DrawMoneyLine) or draw.SimpleText
		if sStyle == "primary" then
			RNDX.Draw(0, 0, 0, ww, hh, bHover and cAccentHov or cAccent)
			dtext(sLabel, sFont, ww * 0.5, hh * 0.5, cTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif sStyle == "danger" then
			RNDX.Draw(0, 0, 0, ww, hh, bHover and cAccent or cRow)
			dtext(sLabel, sFont, ww * 0.5, hh * 0.5, bHover and cTxt or cAccent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			RNDX.Draw(0, 0, 0, ww, hh, bHover and cRowHov or cRow)
			dtext(sLabel, sFont, ww * 0.5, hh * 0.5, bHover and cAccent or cTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	btn.DoClick = fnClick
	return btn
end

-- Pied de carte : filet + texte mono à gauche + hints de touches à droite
-- ({ { key = "F4", label = "FERMER" }, ... }). Renvoie sa hauteur.
function EVO_UI.FooterHints(w, h, leftText, hints, a, padX)
	a = a or 1
	padX = padX or gRespX(26)
	local fh = gRespY(36)
	local fy = h - fh
	surface.SetDrawColor(ColorAlpha(EVO_UI.Col.divider, 55 * a))
	surface.DrawRect(padX, fy, w - padX * 2, 1)
	local cy = fy + math.floor(fh / 2) + gRespY(1)
	if leftText and leftText ~= "" then
		draw.SimpleText(leftText, "EVO_UI_Mono", padX, cy, ColorAlpha(EVO_UI.Col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	if not hints then return fh end
	surface.SetFont("EVO_UI_Mono")
	local x = w - padX
	for i = #hints, 1, -1 do
		local hnt = hints[i]
		local lw = surface.GetTextSize(hnt.label)
		x = x - lw
		draw.SimpleText(hnt.label, "EVO_UI_Mono", x, cy, ColorAlpha(EVO_UI.Col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local kw = surface.GetTextSize(hnt.key)
		local bw, bh = kw + gRespX(10), gRespY(18)
		x = x - gRespX(6) - bw
		surface.SetDrawColor(ColorAlpha(EVO_UI.Col.line, 50 * a))
		surface.DrawOutlinedRect(x, cy - math.floor(bh / 2), bw, bh)
		draw.SimpleText(hnt.key, "EVO_UI_Mono", x + math.floor(bw / 2), cy, ColorAlpha(EVO_UI.Col.muted, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		x = x - gRespX(16)
	end
	return fh
end

-- ── Icône « œil » (aperçu sur ton perso) ────────────────────────────────────
-- Amande PLEINE + pupille sombre, sans anneau ni plaque (user 08/27). Version
-- PARTAGÉE (09/05) : l'icône était recopiée en `local` dans cinq addons, cette
-- copie-ci fait foi pour tout nouvel usage. Polygones précalculés, 0 alloc par frame.
local EYE_SEGS = 24
local EYE_COS, EYE_SIN, EYE_OUT, EYE_PUP = {}, {}, {}, {}
for i = 1, EYE_SEGS do
	local a = (i - 1) / EYE_SEGS * math.pi * 2
	EYE_COS[i], EYE_SIN[i] = math.cos(a), math.sin(a)
	EYE_OUT[i], EYE_PUP[i] = {}, {}
end
function EVO_UI.DrawEye(cx, cy, w, h, col, pupilCol)
	local hw, hh = w * 0.5, h * 0.5
	local pr = math.min(hw, hh) * 0.5
	for i = 1, EYE_SEGS do
		local c, sn = EYE_COS[i], EYE_SIN[i]
		local po, pp = EYE_OUT[i], EYE_PUP[i]
		po.x, po.y = cx + c * hw, cy + sn * hh
		pp.x, pp.y = cx + c * pr * 0.95, cy + sn * pr
	end
	draw.NoTexture()
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(EYE_OUT)
	surface.SetDrawColor(pupilCol.r, pupilCol.g, pupilCol.b, pupilCol.a or 255)
	surface.DrawPoly(EYE_PUP)
end

-- Bouton « œil » posé sur une carte : ouvre la visionneuse cosmétique (l'objet porté
-- par le perso du joueur). Discret au repos, blanc franc et un peu plus grand au survol.
-- nil si la visionneuse n'est pas chargée -> l'appelant n'a rien à gérer.
function EVO_UI.EyeButton(parent, def, tip)
	if not (def and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open) then return nil end
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b:SetTooltip(tip or "Aperçu sur ton perso")
	b:SetTooltipPanelOverride("EVO_Tooltip")
	b:SetZPos(60)
	b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	b.Paint = function(s, w, h)
		local hf = EVO_UI.HoverFrac(s, 10)
		local sc = 0.66 + 0.14 * hf
		EVO_UI.DrawEye(w / 2, h / 2, w * sc, h * sc, Color(235, 236, 240, 140 + 115 * hf), Color(12, 13, 17, 230))
	end
	b.DoClick = function()
		surface.PlaySound(EVO_UI.SndClick)
		LZY_SHOP_COSMETIC_PREVIEW.Open(def)
	end
	return b
end
