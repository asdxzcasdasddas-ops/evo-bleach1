-- "addons\\evo_ui\\lua\\autorun\\client\\cl_evo_ui_skin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if not CLIENT then return end

-- Keep Derma's layout, input, placeholders, checked items and submenus. Only
-- replace its drawing resources; panels with their own Paint keep that design.
-- Le skin Default n'existe pas encore quand l'autorun client tourne (le moteur charge
-- skins/*.lua apres) : construit d'emblee, ce skin plantait a chaque connexion
-- (« attempt to index local 'base' ») et le gamemode (ForceDermaSkin "EVO") retombait
-- sur Default. Le corps attend donc que Default existe (essai ici, puis a Initialize).
local function PoserSkinEvo()
local base = derma.GetNamedSkin("Default")
if not base then return false end
local skin = { PrintName = "EVO", Author = "EVO", DermaVersion = 1 }
local bg = Color(15, 15, 18)
local field = Color(22, 22, 27)
local hover = Color(42, 25, 30)
local accent = Color(207, 68, 78)
local text = Color(238, 239, 243)
local muted = Color(150, 154, 162)
local dim = Color(106, 109, 118)
local line = Color(255, 255, 255, 18)

local function plate(col, active)
	return function(x, y, w, h)
		if w <= 0 or h <= 0 then return end
		local cut = math.min(6, w * 0.25, h * 0.25)
		local pts = EVO_UI.PaintCut(x, y, w - 1, h - 1, col, cut)
		EVO_UI.OutlineCut(pts, active and accent or line)
	end
end
local normal, hot, disabled = plate(field), plate(hover, true), plate(bg)
local background = plate(bg)

local function arrow(direction, col)
	return function(x, y, w, h)
		local cx, cy = x + w * 0.5, y + h * 0.5
		local r = math.min(3, w * 0.25, h * 0.25)
		surface.SetDrawColor(col)
		if direction == "Up" then
			surface.DrawLine(cx - r, cy + r / 2, cx, cy - r / 2)
			surface.DrawLine(cx, cy - r / 2, cx + r, cy + r / 2)
		elseif direction == "Down" then
			surface.DrawLine(cx - r, cy - r / 2, cx, cy + r / 2)
			surface.DrawLine(cx, cy + r / 2, cx + r, cy - r / 2)
		elseif direction == "Left" then
			surface.DrawLine(cx + r / 2, cy - r, cx - r / 2, cy)
			surface.DrawLine(cx - r / 2, cy, cx + r / 2, cy + r)
		else
			surface.DrawLine(cx - r / 2, cy - r, cx + r / 2, cy)
			surface.DrawLine(cx + r / 2, cy, cx - r / 2, cy + r)
		end
	end
end

-- Copy nested tables so this theme never modifies the engine's Default skin.
skin.Colours = table.Copy(base.Colours)
local c = skin.Colours
c.Window = { TitleActive = text, TitleInactive = muted }
c.Button = { Normal = text, Hover = accent, Down = accent, Disabled = dim }
c.Label = { Default = text, Bright = text, Dark = text, Highlight = accent }
c.Tab.Active = table.Copy(c.Button)
c.Tab.Inactive = table.Copy(c.Button)
c.Tree = { Lines = line, Normal = text, Hover = accent, Selected = accent }
c.TooltipText = text
for name in pairs(c.Properties) do
	if name:find("Label") or name == "Title" then
		c.Properties[name] = name:find("Disabled") and dim or text
	else
		c.Properties[name] = name == "Border" and line or (name:find("Selected") and hover or field)
	end
end
c.Category.Header, c.Category.Header_Closed = text, muted
for _, row in ipairs({ c.Category.Line, c.Category.LineAlt }) do
	row.Text, row.Text_Hover, row.Text_Selected, row.Text_Disabled = text, text, accent, dim
	row.Button, row.Button_Hover, row.Button_Selected, row.Button_Disabled = field, hover, hover, bg
end
skin.colTextEntryText = text
skin.colTextEntryBG = field
skin.colTextEntryBorder = line
skin.colTextEntryTextHighlight = accent
skin.colTextEntryTextCursor = text
skin.colTextEntryTextPlaceholder = muted
skin.colNumSliderNotch = dim
skin.bg_color, skin.bg_color_dark, skin.bg_color_bright = bg, bg, field
skin.text_bright, skin.text_normal, skin.text_dark, skin.text_highlight = text, text, muted, accent

skin.tex = table.Copy(base.tex)
local t = skin.tex
t.Panels.Normal, t.Panels.Dark, t.Panels.Bright, t.Panels.Highlight = background, background, normal, hot
t.Button, t.Button_Hovered, t.Button_Down, t.Button_Dead = normal, hot, hot, disabled
t.TextBox, t.TextBox_Focus, t.TextBox_Disabled = normal, hot, disabled
t.MenuBG, t.MenuBG_Column, t.MenuBG_Hover, t.Menu_Strip = background, background, hot, background
t.Selection, t.Tree = hot, background
t.Tab_Control = background
for _, edge in ipairs({ "T", "B", "L", "R" }) do
	t["Tab" .. edge .. "_Active"] = hot
	t["Tab" .. edge .. "_Inactive"] = normal
end
t.Window.Normal, t.Window.Inactive = background, background
t.Input.ComboBox.Normal, t.Input.ComboBox.Hover = normal, hot
t.Input.ComboBox.Down, t.Input.ComboBox.Disabled = hot, disabled
for state in pairs(t.Input.ComboBox.Button) do
	t.Input.ComboBox.Button[state] = arrow("Down", state == "Disabled" and dim or text)
end
t.Menu.RightArrow = arrow("Right", text)
for _, dir in ipairs({ "Up", "Down", "Left", "Right" }) do
	for _, state in ipairs({ "Normal", "Hover", "Down", "Disabled", "Dead" }) do
		local col = (state == "Disabled" or state == "Dead") and dim or (state == "Normal" and muted or accent)
		t.Scroller[dir .. "Button_" .. state] = arrow(dir, col)
		if t.Input.UpDown[dir] then t.Input.UpDown[dir][state] = arrow(dir, col) end
	end
end
t.Scroller.TrackV, t.Scroller.TrackH = background, background
for _, axis in ipairs({ "V", "H" }) do
	for _, state in ipairs({ "Normal", "Hover", "Down", "Disabled" }) do
		t.Scroller["Button" .. axis .. "_" .. state] = plate(state == "Disabled" and field or (state == "Normal" and dim or accent))
	end
end
for _, axis in pairs(t.Input.Slider) do
	for state in pairs(axis) do axis[state] = plate(state == "Disabled" and dim or accent) end
end
for name in pairs(t.Input.ListBox) do
	t.Input.ListBox[name] = (name:find("Selected") or name == "Hovered") and hot or normal
end
for name in pairs(t.CategoryList) do t.CategoryList[name] = normal end
t.ProgressBar.Back, t.ProgressBar.Front = background, plate(accent)
t.Tooltip = function(x, y, w, h) EVO_UI.PaintTooltip(x, y, w, h) end

local function check(checked, dead)
	return function(x, y, w, h)
		normal(x, y, w, h)
		if not checked then return end
		surface.SetDrawColor(dead and dim or accent)
		surface.DrawLine(x + w * 0.22, y + h * 0.5, x + w * 0.43, y + h * 0.72)
		surface.DrawLine(x + w * 0.43, y + h * 0.72, x + w * 0.8, y + h * 0.25)
	end
end
for _, prefix in ipairs({ "Checkbox", "RadioButton" }) do
	t[prefix], t[prefix .. "_Checked"] = check(false), check(true)
	t[prefix .. "D"], t[prefix .. "D_Checked"] = check(false, true), check(true, true)
end
t.Menu_Check = check(true)

local function windowGlyph(kind, col)
	return function(x, y, w, h)
		local cx, cy, r = x + w / 2, y + h / 2, math.min(4, h / 4)
		surface.SetDrawColor(col)
		if kind == "Close" then
			surface.DrawLine(cx - r, cy - r, cx + r, cy + r)
			surface.DrawLine(cx - r, cy + r, cx + r, cy - r)
		elseif kind == "Mini" then
			surface.DrawLine(cx - r, cy + r, cx + r, cy + r)
		else
			surface.DrawOutlinedRect(cx - r, cy - r, r * 2, r * 2, 1)
		end
	end
end
for _, kind in ipairs({ "Close", "Mini", "Maxi", "Restore" }) do
	t.Window[kind] = windowGlyph(kind, muted)
	t.Window[kind .. "_Hover"], t.Window[kind .. "_Down"] = windowGlyph(kind, accent), windowGlyph(kind, accent)
end
function skin:PaintMenuSpacer(_, w, h)
	surface.SetDrawColor(line)
	surface.DrawRect(0, math.floor(h / 2), w, 1)
end

derma.DefineSkin("EVO", "EVO dark panels, cut corners and red accents", skin)
return true
end

if not PoserSkinEvo() then
	-- 40 essais sur 20 s au plus : DefineSkin fait reevaluer leur skin aux panneaux deja crees.
	local nEssais = 0
	local function Reessayer()
		nEssais = nEssais + 1
		if PoserSkinEvo() or nEssais >= 40 then return end
		timer.Simple(0.5, Reessayer)
	end
	hook.Add("Initialize", "EVO_UI::SkinDerma", Reessayer)
end
