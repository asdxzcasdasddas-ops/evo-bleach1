-- "addons\\evo_ui\\lua\\autorun\\sh_evo_ui_resources.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_UI — ressources téléchargées par les clients (fonts de la DA).
--   BebasNeue-Regular : police display des titres (EVO_UI_Header & co). Elle
--   était déclarée dans le kit mais JAMAIS livrée -> fallback silencieux vers
--   la police par défaut chez les joueurs.
--   EVOKanji-Bold : subset de Noto Serif JP (56 glyphes utiles Bleach : 飛走闘
--   剣王虚防, 卍解, chiffres de divisions...) renommé « EVO Kanji » — 22 KB.
-- ============================================================================

if SERVER then
	resource.AddFile("resource/fonts/BebasNeue-Regular.ttf")
	resource.AddFile("resource/fonts/EVOKanji-Bold.ttf")

	-- Assets DA v3 (persos + encres) : distribués via l'addon WORKSHOP UI ; ce
	-- scan est un filet de secours (download direct) si les fichiers sont aussi
	-- posés dans un addon serveur. Ajoute un PNG -> il part au (re)démarrage.
	for _, dir in ipairs({ "chars", "tex" }) do
		local files = file.Find("materials/evo_ui/" .. dir .. "/*.png", "GAME") or {}
		for _, f in ipairs(files) do
			resource.AddFile("materials/evo_ui/" .. dir .. "/" .. f)
		end
	end
end
