-- "addons\\evo_ui_fixes\\lua\\autorun\\client\\cl_dscrollpanel_vbar_fix.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- cl_dscrollpanel_vbar_fix.lua — Garde-fou GLOBAL DScrollPanel
--
-- Bug recurrent : [ERROR] lua/vgui/dscrollpanel.lua:117
--   « attempt to call method 'SetUp' (a nil value) »
--
-- Cause : la VBar interne a ete Remove()e. Un panel supprime peut encore
-- passer IsValid() un instant, mais a deja perdu ses methodes Lua
-- (-> :SetUp est nil). PerformLayoutInternal appelle quand meme SetUp.
--
-- Declencheurs typiques :
--   - Clear()/canvas:Clear() apres que OnChildAdded ait reparente la VBar
--     DANS le canvas (AddItem) — Clear du moteur ne touche que le canvas,
--     donc emporte la scrollbar si elle y a ete deplacee.
--   - boucle GetChildren()->Remove() sur le scroll panel.
--
-- Fix (2 volets) sur la table de controle derma, avant toute UI :
--   1. Clear() epargne explicitement la VBar.
--   2. Self-heal : avant layout/molette/scroll-to, si VBar morte OU sans
--      SetUp, on en recree une (comme PANEL:Init moteur).
--
-- ⚠ Addon autorun client -> redemarrage client (reconnect) pour charger.
-- ============================================================

local ctl = (vgui.GetControlTable and vgui.GetControlTable("DScrollPanel"))
	or (baseclass and baseclass.Get and baseclass.Get("DScrollPanel"))
if not istable(ctl) or not ctl.PerformLayoutInternal then return end

-- VBar utilisable = panel valide ET methode SetUp encore presente.
-- IsValid seul ne suffit PAS : apres Remove(), SetUp peut etre nil
-- pendant que IsValid reste true -> ancien check regressait le crash.
local function VBarOk(vb)
	return IsValid(vb) and isfunction(vb.SetUp)
end

local function EnsureVBar(self)
	if VBarOk(self.VBar) then return end
	self.VBar = vgui.Create("DVScrollBar", self)
	if IsValid(self.VBar) then self.VBar:Dock(RIGHT) end
end

-- 1) Clear sur : ne retire que le contenu, jamais la VBar (quel que soit
--    son parent — self ou canvas apres OnChildAdded/AddItem).
function ctl:Clear()
	local canvas = self.GetCanvas and self:GetCanvas()
	if not IsValid(canvas) then return end
	local vb = self.VBar
	for _, child in ipairs(canvas:GetChildren()) do
		if IsValid(child) and child ~= vb then
			child:Remove()
		end
	end
end

-- 2) Self-heal avant chaque point d'entree moteur qui touche self.VBar.
local oldPLI = ctl.PerformLayoutInternal
function ctl:PerformLayoutInternal()
	EnsureVBar(self)
	if not VBarOk(self.VBar) then return end
	return oldPLI(self)
end

local oldWheel = ctl.OnMouseWheeled
function ctl:OnMouseWheeled(dlta)
	EnsureVBar(self)
	if not VBarOk(self.VBar) then return false end
	return oldWheel(self, dlta)
end

local oldScrollTo = ctl.ScrollToChild
function ctl:ScrollToChild(panel)
	EnsureVBar(self)
	if not VBarOk(self.VBar) then return end
	return oldScrollTo(self, panel)
end
