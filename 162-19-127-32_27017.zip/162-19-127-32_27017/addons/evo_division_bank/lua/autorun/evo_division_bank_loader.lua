-- "addons\\evo_division_bank\\lua\\autorun\\evo_division_bank_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO DIVISION BANK — trésorerie partagée par DIVISION de faction.
--   • Dépôts ¥ par les membres ; distribution (¥ + coffres ≤ épique) par les
--     officiers (grade >= ManagerMinRank).
--   • Revenus : dons + amendes redirigées + taxe (drapeaux/quêtes) + primes (war/boss).
--   • Incitations : classement + badge donateur, tombola + cashback en coffres.
--   Argent ATOMIQUE (patron evo_famille) + MySQL PARTAGÉE cross-serveur.
-- ============================================================================
if SERVER then
    AddCSLuaFile("evo_division_bank/sh_config.lua")
    AddCSLuaFile("evo_division_bank/cl_bank.lua")
    include("evo_division_bank/sh_config.lua")
    include("evo_division_bank/sv_bank.lua")
else
    include("evo_division_bank/sh_config.lua")
    include("evo_division_bank/cl_bank.lua")
end
