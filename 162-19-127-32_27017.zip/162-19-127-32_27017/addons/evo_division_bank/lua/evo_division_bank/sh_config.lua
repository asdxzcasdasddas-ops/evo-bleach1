-- "addons\\evo_division_bank\\lua\\evo_division_bank\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO DIVISION BANK — configuration PARTAGÉE.
-- ============================================================================
EVO_DIVBANK = EVO_DIVBANK or {}
local C = EVO_DIVBANK
C.Config = C.Config or {}
local CFG = C.Config

-- ── Accès ───────────────────────────────────────────────────────────────────
CFG.ManagerMinRank = 15   -- grade mini pour DISTRIBUER/retirer (15-16 : Taicho/Sotaicho, Espadas/Roi — demande user 08/02)
-- ── COMPTABLES (demande user 08/31) : le CHEF de faction (grade 16) nomme jusqu'à
-- ComptableMax membres (grade ComptableMinRank+) qui peuvent RETIRER du trésor
-- (versements ¥) sans être grade 15+. Les coffres restent réservés aux gradés 15+.
-- Persistés en MySQL PARTAGÉE (table evo_divbank_comptables) : valables sur les
-- deux serveurs, revalidés en base à CHAQUE retrait (jamais un cache seul).
CFG.ChiefMinRank     = 16
CFG.ComptableMinRank = 4
CFG.ComptableMax     = 2
CFG.MinDivision    = 2    -- index de division >= 2 = vraie division (1 = "Aucune")
-- BANQUE GLOBALE PAR FACTION (demande user 08/02) : le trésor n'est plus par division/ordre
-- mais COMMUN à toute la faction. On garde le schéma SQL (colonne division) : tout est rangé
-- dans le compartiment GlobalDivision (0). Migration des anciens trésors par division :
-- MUGEN.MigrateDivBankToFactionGlobal (sv_database.lua, concommand evo_divbank_migrate_global).
CFG.GlobalDivision = 0

-- ── Revenus (taxe / primes vers le trésor) ──────────────────────────────────
CFG.FineToBank     = true  -- les amendes vont au trésor de la division de l'émetteur
CFG.FlagCaptureTax = 0.10  -- % du gain de CAPTURE de drapeau prélevé pour la division
CFG.FlagPassiveTax = 0.10  -- % du revenu PASSIF des drapeaux tenus
CFG.QuestTax       = 0.05  -- % des récompenses ¥ de quête
CFG.WarPrize       = 50000 -- prime ¥ versée au trésor de la division gagnante d'une war
CFG.BossPrize      = 15000 -- prime ¥ par boss/world-boss tué (division du tueur)
CFG.TaxNotify      = false -- petite notif "X¥ versés à ta division" (off : le passif tick souvent)

-- ── Quota de coffres (par semaine) — PLAFONNÉ À ÉPIQUE ───────────────────────
-- L'officier dépense 1 crédit de quota + un coût ¥ du trésor pour offrir un coffre.
CFG.Quota = { common = 12, rare = 6, epic = 3 }
CFG.QuotaResetInterval = 7 * 86400 -- recharge hebdo
CFG.ChestCost = { common = 2000, rare = 8000, epic = 25000 } -- ¥ ponctionnés au trésor par coffre offert
CFG.ChestItem = { common = "coffre_commun", rare = "coffre_rare", epic = "coffre_epique" } -- ids evo_loot

-- ── Distribution (anti-abus) ─────────────────────────────────────────────────
CFG.MaxGivePerTx   = 5000000  -- ¥ max par don d'officier
CFG.GiveCooldown   = 3        -- s entre 2 distributions d'un même officier
-- (Le quota hebdo de division 12/6/3 plafonne déjà le total de coffres distribuables.)

-- ── Dépôts ───────────────────────────────────────────────────────────────────
CFG.MinDeposit = 100
CFG.MaxDeposit = 50000000

-- ── Incitations : badge donateur (seuil ¥ cumulés -> palier) ────────────────
-- De haut en bas : le 1er seuil atteint donne le titre. NWString EVO_DivBankBadge.
CFG.Badges = {
    { min = 2000000, name = "Pilier",      col = Color(255, 215, 90) },
    { min = 500000,  name = "Mécène",      col = Color(190, 110, 220) },
    { min = 100000,  name = "Bienfaiteur", col = Color(70, 140, 230) },
    { min = 20000,   name = "Donateur",    col = Color(90, 200, 120) },
}

-- ── Incitations : cashback en coffres (1 coffre offert tous les X¥ donnés) ───
CFG.CashbackEnabled  = true
CFG.CashbackPer      = 20000      -- chaque tranche de 20k¥ cumulés donnés -> 1 coffre offert
CFG.CashbackWeights  = { coffre_commun = 60, coffre_rare = 30, coffre_epique = 10 } -- cap épique
CFG.CashbackWeeklyMax = 15       -- SÉCURITÉ anti-farm : plafond de coffres de cashback par membre et par SEMAINE.
                                 -- Sans ça : dépôt -> cashback -> le trésor est reversé à un complice non-donateur
                                 -- (GiveMoney) puis retradé à l'officier en boucle = coffres INFINIS (coût net 0¥).
                                 -- Remis à 0 au cycle tombola. Généreux pour les vrais donateurs (borne le farm).

-- ── Incitations : tombola hebdo (lots à plusieurs gagnants) ──────────────────
CFG.LotteryEnabled       = true
CFG.LotteryInterval      = 7 * 86400
-- TOMBOLA : il faut avoir donné AU MOINS LotteryMinDonated ¥ SUR LA SEMAINE pour débloquer les
-- tickets — en dessous de ce seuil = AUCUN ticket (demande user). Une fois le seuil atteint :
-- 1 ticket par tranche de LotteryTicketPer ¥ donnés sur la semaine (donc à 200k = 10 tickets,
-- à 220k = 11, etc.). Cumul hebdo `week_donated` (par donateur), remis à 0 chaque semaine.
CFG.LotteryMinDonated = 200000  -- seuil ¥/semaine pour débloquer la tombola (sinon 0 ticket)
CFG.LotteryTicketPer  = 20000   -- 1 ticket par tranche de 20k¥ donnés sur la semaine (au-delà du seuil)
CFG.LotteryMinWeeklyPlay = 15 * 3600 -- éligible SEULEMENT si >= 15h jouées DANS la semaine (depuis le 1er don du cycle)
-- Lots (1 tirage par division, pondéré par les tickets, SANS REMISE) : 1er, 2e, 3e place.
-- RÉDUITS (était mythique/légendaire/épique). Demande user.
CFG.LotteryPrizes = { "coffre_legendaire", "coffre_epique", "coffre_rare" }

-- ── Helpers partagés ─────────────────────────────────────────────────────────
-- Renvoie faction, division (>= MinDivision) du joueur, ou nil si pas de vraie division.
function C.GetPlayerDiv(ply)
    if not IsValid(ply) then return nil end
    local fac = ply:GetEvoNWString("FactionName", "")
    local div = tonumber(ply:GetEvoNWInt("FactionDivision", 0)) or 0
    if fac == "" or div < CFG.MinDivision then return nil end
    return fac, div
end

-- Faction "bancable" du joueur (banque GLOBALE) : les factions à hiérarchie uniquement
-- (LostSoul, 1 seul grade, n'a pas de banque). nil si pas de faction.
function C.GetPlayerFaction(ply)
    if not IsValid(ply) then return nil end
    local fac = ply:GetEvoNWString("FactionName", "")
    if fac == "" then return nil end
    local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.factions and LZY_FACTION_CONFIG.factions[fac]
    if not (t and #t > 1) then return nil end
    return fac
end

-- Banque globale : plus besoin d'être DANS une division pour gérer (un Sotaicho/Roi sans
-- division doit pouvoir retirer) — la faction + le grade suffisent.
function C.IsManager(ply)
    local fac = C.GetPlayerFaction(ply)
    if not fac then return false end
    if ply:IsSuperAdmin() then return true end
    return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= CFG.ManagerMinRank
end

-- Le CHEF de faction (grade 16) : seul habilité à nommer/retirer les comptables.
function C.IsChief(ply)
    local fac = C.GetPlayerFaction(ply)
    if not fac then return false end
    if ply:IsSuperAdmin() then return true end
    return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= CFG.ChiefMinRank
end

-- Clé "Faction:Division" (pour les NWString / tables runtime).
function C.DivKey(fac, div) return tostring(fac) .. ":" .. tostring(div) end

-- Nom lisible de la division (réutilise lzy_faction si dispo).
function C.DivName(fac, div)
    local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions and LZY_FACTION_CONFIG.divisions[fac]
    return (t and t[div]) or ("Division " .. tostring(div))
end

-- Sous-titre de la banque GLOBALE (affiché dans l'en-tête de l'UI).
function C.BankName(fac)
    return "Faction " .. tostring(fac) .. " · trésor commun"
end

-- Palier de badge pour un total donné (ou nil).
function C.BadgeFor(total)
    total = tonumber(total) or 0
    for _, b in ipairs(CFG.Badges) do
        if total >= b.min then return b end
    end
    return nil
end
