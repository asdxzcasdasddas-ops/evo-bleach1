-- "addons\\evo_division_bank\\lua\\evo_division_bank\\cl_bank.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO DIVISION BANK — client. UI ouverte par EVO_DIVBANK.Open() (bouton dans la
-- Gestion de faction). Onglets : Trésor (dépôt) · Classement · Distribuer · Journal.
-- ============================================================================
local C   = EVO_DIVBANK
local CFG = C.Config

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local COL_BG    = Color(13, 14, 17, 250)           -- plaque métal noir (Atelier)
local COL_EDGE  = Color(146, 152, 161, 33)         -- liseré acier 1px
local COL_CARD2 = Color(8, 8, 10, 255)
local COL_ACC   = Color(207, 68, 78)
local COL_TITLE = Color(237, 238, 242)
local COL_MUTED = Color(150, 154, 162)
local COL_DIM   = Color(106, 109, 118)
local COL_GREEN = Color(90, 200, 120)
local COL_GOLD  = Color(235, 200, 70)

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/support) ──
local function drawCircle(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
    drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
    drawCircle(cx, cy, r, Color(23, 25, 29, 255))
    drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = R(6), R(5)
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
        cx = cx + dw + gap
    end
end

local function rndx(r, x, y, w, h, c) if RNDX then RNDX.Draw(r, x, y, w, h, c) else draw.RoundedBox(r, x, y, w, h, c) end end
local function comma(n) return string.Comma(math.floor(tonumber(n) or 0)) end
local function badgeColor(name)
    for _, b in ipairs(CFG.Badges) do if b.name == name then return b.col end end
    return COL_MUTED
end

local function MakeFonts()
    local sz = function(n) return (gRespY and gRespY(n)) or n end
    -- DA Atelier : Bebas Neue SANS bold pour l'affichage, Roboto pour le corps.
    surface.CreateFont("EVO_DB_H",     { font = "Bebas Neue", size = sz(30), weight = 400, antialias = true, extended = true })
    surface.CreateFont("EVO_DB_Big",   { font = "Bebas Neue", size = sz(38), weight = 400, antialias = true, extended = true })
    surface.CreateFont("EVO_DB_Btn",   { font = "Bebas Neue", size = sz(21), weight = 400, antialias = true, extended = true })
    surface.CreateFont("EVO_DB_Lbl",   { font = "Roboto", size = sz(16), weight = 500, antialias = true, extended = true })
    surface.CreateFont("EVO_DB_Small", { font = "Roboto", size = sz(14), weight = 500, antialias = true, extended = true })
end
MakeFonts()
hook.Add("Initialize", "EVO_DivBank_Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_DivBank_Fonts2", MakeFonts)

-- ── Widgets ──────────────────────────────────────────────────────────────────
local function Btn(parent, label, x, y, w, h, filled, fClick, enabled)
    local b = vgui.Create("DButton", parent)
    b:SetText("") b:SetPos(R(x), R(y)) b:SetSize(R(w), R(h))
    b.Paint = function(s, bw, bh)
        local on = (enabled == nil) or enabled()
        local hov = s:IsHovered() and on
        if filled then
            rndx(R(8), 0, 0, bw, bh, ColorAlpha(COL_ACC, on and (hov and 255 or 225) or 60))
            MUGEN.DrawMoneyLine(label, "EVO_DB_Btn", bw / 2, bh / 2, ColorAlpha(color_white, on and 255 or 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            rndx(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 16 or 8))
            MUGEN.DrawMoneyLine(label, "EVO_DB_Btn", bw / 2, bh / 2, on and (hov and COL_TITLE or COL_MUTED) or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    b.DoClick = function() if (enabled == nil) or enabled() then fClick() end end
    return b
end

local function Entry(parent, x, y, w, h, placeholder, numeric)
    local e = vgui.Create("DTextEntry", parent)
    e:SetPos(R(x), R(y)) e:SetSize(R(w), R(h)) e:SetFont("EVO_DB_Lbl")
    e:SetDrawLanguageID(false) e:SetNumeric(numeric or false) e:SetPlaceholderText(placeholder or "")
    e.Paint = function(s, bw, bh)
        rndx(R(7), 0, 0, bw, bh, COL_CARD2)
        s:DrawTextEntryText(COL_TITLE, COL_ACC, COL_TITLE)
        if s:GetValue() == "" then MUGEN.DrawMoneyLine(s:GetPlaceholderText() or "", "EVO_DB_Lbl", R(8), bh / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
    end
    return e
end

-- ── État + ouverture ─────────────────────────────────────────────────────────
C._snap = C._snap or nil
C._sel  = nil -- SteamID64 du membre sélectionné (onglet Distribuer)

-- ── JOURNAL : libellé, sens et nature de chaque mouvement ───────────────────
-- `credit` = l'argent ENTRE dans le trésor. `joueur` = action décidée par un
-- joueur (dépôt, retrait, coffre offert, prime versée), par opposition aux
-- revenus automatiques (taxes, primes de guerre, tombola, laboratoire).
-- Toute clé inconnue retombe sur « Mouvement » : jamais d'identifiant brut à
-- l'écran.
local TX = {
    deposit     = { l = "Dépôt",                  credit = true,  joueur = true },
    give_money  = { l = "Retrait",                credit = false, joueur = true },
    give_chest  = { l = "Coffre offert",          credit = false, joueur = true },
    prime       = { l = "Prime versée",           credit = false, joueur = true },
    bounty      = { l = "Prime versée",           credit = false, joueur = true },
    fine        = { l = "Amende",                 credit = true },
    flag        = { l = "Drapeaux",               credit = true },
    quest       = { l = "Quête",                  credit = true },
    war         = { l = "Guerre",                 credit = true },
    boss        = { l = "Boss",                   credit = true },
    fosse       = { l = "La Fosse",               credit = true },
    clan_tax    = { l = "Taxe de clan",           credit = true },
    science     = { l = "Recherche",              credit = true },
    science_ref = { l = "Recherche remboursée",   credit = true },
    science_op  = { l = "Analyse au laboratoire", credit = false },
    lottery     = { l = "Tombola",                credit = false },
    comptable_add = { l = "Comptable nommé",      credit = true,  joueur = true },
    comptable_del = { l = "Comptable révoqué",    credit = true,  joueur = true },
}
local TX_DEF = { l = "Mouvement", credit = true }
local function TxInfo(sKind) return TX[sKind] or TX_DEF end

-- Filtres du journal (mémorisés entre deux ouvertures, comme l'onglet courant).
local LOG_FILTRES = {
    { id = "tout",    label = "TOUT" },
    { id = "joueur",  label = "JOUEURS" },
    { id = "depot",   label = "DÉPÔTS" },
    { id = "retrait", label = "RETRAITS" },
}
local LOG_FILTRE = "tout"

local function LogVisible(e)
    local t = TxInfo(e.kind)
    if LOG_FILTRE == "joueur"  then return t.joueur == true end
    if LOG_FILTRE == "depot"   then return e.kind == "deposit" end
    if LOG_FILTRE == "retrait" then return t.credit == false end
    return true
end

local Build -- forward (défini plus bas)
function C.Open()
    net.Start("EVO:DivBank:Open") net.SendToServer()
    if C._snap and Build then Build() end -- ouvre tout de suite avec la dernière donnée connue (throttle-safe)
end

local PANEL_TAB = "tresor"

-- Membres EN LIGNE de MA faction (banque GLOBALE : on distribue à toute la faction).
local function onlineFactionMembers()
    local lp = LocalPlayer()
    local fac = lp:GetEvoNWString("FactionName", "")
    local t = {}
    for _, p in player.Iterator() do
        if IsValid(p) and p:GetEvoNWString("FactionName", "") == fac then
            t[#t + 1] = p
        end
    end
    return t
end

local function rpn(p) local n = IsValid(p) and p:GetEvoNWString("Nickname", "") or "" return (n ~= "" and n) or (IsValid(p) and p:Nick()) or "?" end

-- ── Construction du panneau ──────────────────────────────────────────────────
function Build()
    local snap = C._snap
    if not snap then return end
    if IsValid(C._win) then C._win:Remove() end
    local CARD_W, CARD_H, SIDE = 860, 560, 190
    local cardW, cardH = R(CARD_W), R(CARD_H)

    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
    frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false) frame:SetPaintBackgroundEnabled(false)
    frame:MakePopup()
    if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
    frame._a = 0
    frame.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
    frame.Paint = function(s, w, h)
        -- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
        if RNDX and RNDX.Draw and RNDX.BLUR then
            RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
        elseif EVO_UI and EVO_UI.DrawBlur then
            EVO_UI.DrawBlur(s, 5)
        end
        surface.SetDrawColor(5, 5, 7, 216 * (s._a / 255)) surface.DrawRect(0, 0, w, h)
    end
    frame.OnMousePressed = function() if IsValid(frame) then frame:Remove() end end -- clic hors carte = fermer
    C._win = frame

    local card = vgui.Create("DPanel", frame)
    card:SetMouseInputEnabled(true) card.OnMousePressed = function() end -- absorbe le clic (ne ferme pas)
    card:SetSize(cardW, cardH) card:SetPos((ScrW() - cardW) / 2, (ScrH() - cardH) / 2) -- CENTRÉ
    card.Paint = function(s, w, h)
        -- Plaque de métal noir Atelier : coins coupés (plaque plate), SANS image ;
        -- kanji 千 gravé clair, titre Bebas + entaille slash1 réduite + dents.
        -- DA dashboard 08/07 : plaque plate (plus de liseré acier).
        EVO_UI.PaintCut(0, 0, w, h, COL_BG, R(16))
        draw.SimpleText("千", "EVO_UI_KanjiXL", w - R(8), h - R(2),
            Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
        -- 4 vis d'angle alignées (retrait 18px uniforme — DA dashboard 08/07).
        local sr = R(5)
        drawScrew(R(18), R(18), sr)
        drawScrew(w - R(18), R(18), sr)
        drawScrew(w - R(18), h - R(18), sr)
        drawScrew(R(18), h - R(18), sr)
        -- En-tête 2 lignes : titre + division À GAUCHE, solde À DROITE.
        draw.SimpleText("BANQUE", "EVO_DB_H", R(22), R(12), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        surface.SetFont("EVO_DB_H")
        local twT, thT = surface.GetTextSize("BANQUE")
        if not EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(12) + thT * 0.78, twT * 1.1, R(8), ColorAlpha(COL_ACC, 245)) then
            surface.SetDrawColor(COL_ACC)
            surface.DrawRect(R(22), R(12) + thT * 0.84, twT, math.max(2, R(3)))
        end
        draw.SimpleText(snap and snap.divName or "", "EVO_DB_Lbl", R(22) + twT + R(14), R(20), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        MUGEN.DrawMoneyLine("Trésor : " .. comma(snap and snap.money or 0) .. " ¥", "EVO_DB_Lbl", w - R(54), R(20), COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
        surface.SetDrawColor(255, 255, 255, 18) surface.DrawRect(R(SIDE), R(66), 1, h - R(78))
        drawDashes(R(20), R(60), w - R(40), Color(255, 255, 255, 26))
    end

    -- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
    local x = vgui.Create("DButton", card) x:SetText("") x:SetSize(R(32), R(32)) x:SetPos(R(CARD_W - 44), R(12))
    x:SetCursor("hand")
    x.Paint = function(s, w, h)
        draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL_ACC or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = function() frame:Remove() end

    local content = vgui.Create("DPanel", card)
    content:SetPos(R(SIDE + 18), R(72)) content:SetSize(R(CARD_W - SIDE - 40), R(CARD_H - 88))
    content:SetPaintBackground(false)
    local cw, ch = CARD_W - SIDE - 40, CARD_H - 88

    -- Onglets (sidebar)
    local TABS = { { id = "tresor", label = "Trésor" }, { id = "rank", label = "Classement" } }
    -- Distribuer : gradés 15+ ET comptables nommés par le chef (retrait ¥ ; les
    -- coffres restent réservés aux gradés 15+ dans l'onglet lui-même).
    if snap and (snap.isManager or snap.canWithdraw) then TABS[#TABS + 1] = { id = "give", label = "Distribuer" } end
    if snap and snap.isChief then TABS[#TABS + 1] = { id = "compta", label = "Comptables" } end
    TABS[#TABS + 1] = { id = "log", label = "Journal" }

    local buildTab -- forward
    local function selectTab(id) PANEL_TAB = id content:Clear() buildTab(id) end

    -- Cases sidebar = items du menu échap (puce brush1 acier -> rouge, plaque
    -- acier à coin coupé + barre accent en survol/sélection, dents entre items).
    for i, t in ipairs(TABS) do
        local b = vgui.Create("DButton", card) b:SetText("")
        b:SetPos(R(16), R(74 + (i - 1) * 46)) b:SetSize(R(SIDE - 24), R(40))
        b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
        b.Paint = function(s, w, h)
            local on = PANEL_TAB == t.id
            local hf = EVO_UI.HoverFrac(s, 10)
            local vis = on and 1 or hf
            if vis > 0.02 then
                EVO_UI.PaintCut(0, R(2), w, h - R(4), Color(17, 18, 22, 205 * vis), R(9), "br")
                -- Liseré tracé à l'INTÉRIEUR (bord droit à x=w-1) : sinon le bord
                -- droit de la plaque (x=w) était clippé par le panneau (08/07).
                local ol = EVO_UI.CutPoints(0, R(2), w - 1, h - R(4), R(9), "br")
                EVO_UI.OutlineCut(ol, Color(226, 230, 238, 26 * vis))
                surface.SetDrawColor(207, 68, 78, 235 * vis)
                surface.DrawRect(0, R(2), R(2), h - R(4))
            end
            local brushPath = (EVO_UI.HasMat("evo_ui/tex/brush1.png") and "evo_ui/tex/brush1.png")
                or (EVO_UI.HasMat(EVO_UI.TexBrush) and EVO_UI.TexBrush or nil)
            if brushPath then
                local c = (on or hf > 0.5) and ColorAlpha(COL_ACC, 240) or Color(150, 154, 162, 150)
                EVO_UI.Ink(brushPath, R(9), h / 2 - R(5), R(18), R(11), c)
            end
            draw.SimpleText(t.label, "EVO_DB_Btn", R(34) + vis * R(5), h / 2,
                (on or hf > 0.01) and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            if i < #TABS and vis < 0.98 then
                drawDashes(R(8), h - 1, w - R(16), Color(255, 255, 255, 22 * (1 - vis)))
            end
        end
        b.DoClick = function() surface.PlaySound(EVO_UI.SndClick) selectTab(t.id) end
    end

    -- ── Builders d'onglets ──
    function buildTab(id)
        if id == "tresor" then
            local lbl = vgui.Create("DLabel", content) lbl:SetFont("EVO_DB_H") lbl:SetTextColor(COL_TITLE)
            lbl:SetText("Soutiens ta faction") lbl:SetPos(R(0), R(0)) lbl:SetSize(R(cw), R(26))
            -- Ma contribution + badge + MES TICKETS (bien visibles).
            local info = vgui.Create("DPanel", content) info:SetPos(R(0), R(36)) info:SetSize(R(cw), R(72)) info:SetPaintBackground(false)
            local ticketDivPhrase = "dans ta faction"
            info.Paint = function(s, w, h)
                rndx(R(10), 0, 0, w, h, ColorAlpha(color_white, 6))
                local badge = LocalPlayer():GetEvoNWString("EVO_DivBankBadge", "")
                MUGEN.DrawMoneyLine("Mes dons : " .. comma(snap.myTotal) .. " ¥", "EVO_DB_Lbl", R(14), R(14), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                if badge ~= "" then draw.SimpleText("Statut : " .. badge, "EVO_DB_Lbl", R(14), R(40), badgeColor(badge), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                else MUGEN.DrawMoneyLine("1 coffre offert / " .. comma(CFG.CashbackPer) .. "¥", "EVO_DB_Small", R(14), R(42), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) end
                if CFG.LotteryEnabled then
                    local tot = snap.totalTickets or 0
                    draw.SimpleText(tostring(snap.myTickets or 0), "EVO_DB_Big", w - R(16), R(8), COL_GREEN, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                    draw.SimpleText("mes tickets · sur " .. tot .. " " .. ticketDivPhrase, "EVO_DB_Small", w - R(16), R(48), COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                end
            end
            -- Déposer (le placeholder rappelle le minimum)
            local dep = Entry(content, 0, 124, cw - 150, 36, "Dépôt min " .. comma(CFG.MinDeposit) .. " ¥", true)
            Btn(content, "Déposer", cw - 140, 124, 140, 36, true, function()
                local amt = math.floor(tonumber(dep:GetValue()) or 0)
                if amt < (CFG.MinDeposit or 1) then -- feedback au lieu d'un clic muet
                    if MUGEN and MUGEN.Notify then MUGEN.Notify("Dépôt minimum : " .. comma(CFG.MinDeposit) .. " ¥", NOTIFY_ERROR or 1, 4)
                    elseif LocalPlayer().ChatPrint then LocalPlayer():ChatPrint("[Banque] Dépôt minimum : " .. comma(CFG.MinDeposit) .. " ¥") end
                    return
                end
                net.Start("EVO:DivBank:Deposit") net.WriteDouble(amt) net.SendToServer()
                dep:SetText("")
            end)
            local why = vgui.Create("DLabel", content) why:SetFont("EVO_DB_Small") why:SetTextColor(COL_MUTED) why:SetWrap(true) why:SetAutoStretchVertical(true)
            why:SetPos(R(0), R(174)) why:SetSize(R(cw), R(ch - 174))
            local prz = CFG.LotteryPrizes or {}
            local function pl(i) return tostring(prz[i] or ""):gsub("coffre_", "") end
            local hrs = math.floor((CFG.LotteryMinWeeklyPlay or 0) / 3600)
            why:SetText("Pourquoi donner ? Tu montes dans le classement (badge évolutif) et tu reçois 1 coffre tous les " .. comma(CFG.CashbackPer) .. "¥ donnés. Tombola hebdo : donne au moins " .. comma(CFG.LotteryMinDonated) .. "¥ sur la semaine pour la débloquer (sinon aucun ticket), puis 1 ticket par " .. comma(CFG.LotteryTicketPer) .. "¥ donnés : réservée aux joueurs ayant joué au moins " .. hrs .. "h dans la semaine. Lots : 1er = coffre " .. pl(1) .. ", 2e = " .. pl(2) .. ", 3e = " .. pl(3) .. ". Les officiers récompensent aussi les plus généreux.")
        elseif id == "rank" then
            local lbl = vgui.Create("DLabel", content) lbl:SetFont("EVO_DB_H") lbl:SetTextColor(COL_TITLE)
            lbl:SetText("Classement des donateurs") lbl:SetPos(R(0), R(0)) lbl:SetSize(R(cw), R(26))
            local sc = vgui.Create("DScrollPanel", content) sc:SetPos(R(0), R(36)) sc:SetSize(R(cw), R(ch - 36))
            if (not snap.donors) or #snap.donors == 0 then
                local l = vgui.Create("DLabel", sc) l:SetFont("EVO_DB_Lbl") l:SetTextColor(COL_DIM) l:SetText("Aucun don pour l'instant. Sois le premier !") l:Dock(TOP) l:SetTall(R(24))
            else
                for i, d in ipairs(snap.donors) do
                    local r = vgui.Create("DPanel", sc) r:Dock(TOP) r:SetTall(R(36)) r:DockMargin(0, 0, R(6), R(6)) r:SetPaintBackground(false)
                    r.Paint = function(s, w, h)
                        rndx(R(8), 0, 0, w, h, ColorAlpha(color_white, 7))
                        local medal = (i == 1 and COL_GOLD) or (i == 2 and Color(200, 200, 210)) or (i == 3 and Color(205, 130, 80)) or COL_DIM
                        draw.SimpleText("#" .. i, "EVO_DB_Lbl", R(12), h / 2, medal, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                        draw.SimpleText(d.name or "?", "EVO_DB_Lbl", R(54), h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                        if CFG.LotteryEnabled then
                            MUGEN.DrawMoney(d.total, "EVO_DB_Lbl", w - R(14), h / 2 - R(8), COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                            draw.SimpleText((tonumber(d.tickets) or 0) .. " ticket(s)", "EVO_DB_Small", w - R(14), h / 2 + R(9), COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                        else
                            MUGEN.DrawMoney(d.total, "EVO_DB_Lbl", w - R(14), h / 2, COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                        end
                    end
                end
            end
        elseif id == "give" then
            local lbl = vgui.Create("DLabel", content) lbl:SetFont("EVO_DB_H") lbl:SetTextColor(COL_TITLE)
            lbl:SetText("Récompenser un membre") lbl:SetPos(R(0), R(0)) lbl:SetSize(R(cw), R(26))
            -- Liste membres en ligne (sélection) : TOUTE la faction (banque globale), avec la
            -- division/ordre de chacun pour s'y retrouver.
            local sc = vgui.Create("DScrollPanel", content) sc:SetPos(R(0), R(34)) sc:SetSize(R(cw), R(ch - 150))
            for _, p in ipairs(onlineFactionMembers()) do
                if p ~= LocalPlayer() then
                    local sid = p:SteamID64()
                    local row = vgui.Create("DButton", sc) row:SetText("") row:Dock(TOP) row:SetTall(R(30)) row:DockMargin(0, 0, R(6), R(4))
                    local divName = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName
                        and LZY_FACTION_CONFIG.DivisionName(p, p:GetEvoNWInt("FactionDivision", 0)) or ""
                    row.Paint = function(s, w, h)
                        local on = C._sel == sid
                        rndx(R(7), 0, 0, w, h, on and ColorAlpha(COL_ACC, 230) or ColorAlpha(color_white, s:IsHovered() and 13 or 7))
                        draw.SimpleText(rpn(p) .. "  ·  " .. divName .. "  ·  grade " .. p:GetEvoNWInt("FactionRank", 0), "EVO_DB_Lbl", R(10), h / 2, on and color_white or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    end
                    row.DoClick = function() C._sel = sid selectTab("give") end
                end
            end
            -- Actions
            local hasSel = function() return C._sel ~= nil end
            local amt = Entry(content, 0, ch - 108, cw - 150, 34, "¥ à donner", true)
            Btn(content, "Donner ¥", cw - 140, ch - 108, 140, 34, true, function()
                local v = math.floor(tonumber(amt:GetValue()) or 0)
                if not C._sel or v <= 0 then return end
                net.Start("EVO:DivBank:GiveMoney") net.WriteString(C._sel) net.WriteDouble(v) net.SendToServer()
                amt:SetText("")
            end, hasSel)
            if snap.isManager then
                local tiers = { { "common", "Commun (" .. snap.qc .. ")", snap.qc }, { "rare", "Rare (" .. snap.qr .. ")", snap.qr }, { "epic", "Épique (" .. snap.qe .. ")", snap.qe } }
                for i, t in ipairs(tiers) do
                    Btn(content, "Coffre " .. t[2], (i - 1) * ((cw) / 3), ch - 62, (cw) / 3 - 8, 34, false, function()
                        if not C._sel then return end
                        net.Start("EVO:DivBank:GiveChest") net.WriteString(C._sel) net.WriteString(t[1]) net.SendToServer()
                    end, function() return hasSel() and t[3] > 0 end)
                end
            end
            local hint = vgui.Create("DLabel", content) hint:SetFont("EVO_DB_Small") hint:SetTextColor(COL_DIM)
            hint:SetText(not snap.isManager and "Comptable : tu peux verser des ¥ du trésor aux membres (pas de coffres)."
                or (C._sel and "Clique une rareté = 1 seul coffre offert au membre. (Quota = coffres restants cette semaine.)"
                or "Sélectionne d'abord un membre ci-dessus, puis clique une rareté."))
            hint:SetPos(R(0), R(ch - 24)) hint:SetSize(R(cw), R(20))
        elseif id == "compta" then
            local lbl = vgui.Create("DLabel", content) lbl:SetFont("EVO_DB_H") lbl:SetTextColor(COL_TITLE)
            lbl:SetText("Comptables du trésor") lbl:SetPos(R(0), R(0)) lbl:SetSize(R(cw), R(26))
            local sub = vgui.Create("DLabel", content) sub:SetFont("EVO_DB_Small") sub:SetTextColor(COL_MUTED) sub:SetWrap(true) sub:SetAutoStretchVertical(true)
            sub:SetPos(R(0), R(28)) sub:SetSize(R(cw), R(30))
            sub:SetText("Jusqu'à " .. (CFG.ComptableMax or 2) .. " membres de grade " .. (CFG.ComptableMinRank or 4) .. "+ peuvent verser des ¥ du trésor (pas de coffres). Valable sur les deux serveurs.")

            -- Comptables ACTUELS (retirables d'un clic).
            local yy = 66
            local tCompta = snap.comptables or {}
            if #tCompta == 0 then
                local l = vgui.Create("DLabel", content) l:SetFont("EVO_DB_Lbl") l:SetTextColor(COL_DIM)
                l:SetText("Aucun comptable nommé.") l:SetPos(R(0), R(yy)) l:SetSize(R(cw), R(22))
                yy = yy + 28
            else
                for _, cpt in ipairs(tCompta) do
                    local row = vgui.Create("DPanel", content) row:SetPaintBackground(false)
                    row:SetPos(R(0), R(yy)) row:SetSize(R(cw), R(32))
                    row.Paint = function(sP, w, h)
                        rndx(R(7), 0, 0, w, h, ColorAlpha(color_white, 8))
                        draw.SimpleText(cpt.name or "?", "EVO_DB_Lbl", R(10), h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    end
                    Btn(row, "Révoquer", cw - 110, 2, 110, 28, false, function()
                        net.Start("EVO:DivBank:SetComptable") net.WriteString(cpt.sid) net.WriteBool(false) net.SendToServer()
                    end)
                    yy = yy + 38
                end
            end

            -- Nomination (si une place reste) : recherche + liste déroulante.
            if #tCompta < (CFG.ComptableMax or 2) then
                local search = Entry(content, 0, yy, cw, 32, "Rechercher un membre (grade " .. (CFG.ComptableMinRank or 4) .. "+)…")
                local sc = vgui.Create("DScrollPanel", content) sc:SetPos(R(0), R(yy + 40)) sc:SetSize(R(cw), R(ch - yy - 44))
                local function rebuildList()
                    sc:Clear()
                    local sFiltre = string.lower(search:GetValue() or "")
                    local n = 0
                    for _, m in ipairs(C._members or {}) do
                        if sFiltre == "" or string.find(string.lower(m.name or ""), sFiltre, 1, true) then
                            n = n + 1
                            if n > 60 then break end -- la recherche affine, inutile d'empiler 250 lignes
                            local row = vgui.Create("DButton") row:SetText("")
                            sc:AddItem(row) row:Dock(TOP) row:SetTall(R(30)) row:DockMargin(0, 0, R(6), R(4))
                            row.Paint = function(sP, w, h)
                                rndx(R(7), 0, 0, w, h, ColorAlpha(color_white, sP:IsHovered() and 14 or 7))
                                draw.SimpleText((m.name or "?") .. "  ·  grade " .. (m.rank or 0), "EVO_DB_Lbl", R(10), h / 2,
                                    sP:IsHovered() and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                                draw.SimpleText("Nommer", "EVO_DB_Small", w - R(12), h / 2, sP:IsHovered() and COL_ACC or COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                            end
                            row.DoClick = function()
                                net.Start("EVO:DivBank:SetComptable") net.WriteString(m.sid) net.WriteBool(true) net.SendToServer()
                            end
                        end
                    end
                    if n == 0 then
                        local l = vgui.Create("DLabel") l:SetFont("EVO_DB_Lbl") l:SetTextColor(COL_DIM)
                        l:SetText(C._members and "Aucun membre ne correspond." or "Chargement des membres…")
                        sc:AddItem(l) l:Dock(TOP) l:SetTall(R(24))
                    end
                end
                search.OnChange = rebuildList
                C._rebuildCompta = rebuildList
                rebuildList()
                net.Start("EVO:DivBank:Members") net.SendToServer()
            end
        elseif id == "log" then
            local lbl = vgui.Create("DLabel", content) lbl:SetFont("EVO_DB_H") lbl:SetTextColor(COL_TITLE)
            lbl:SetText("Journal des transactions") lbl:SetPos(R(0), R(0)) lbl:SetSize(R(cw), R(26))

            -- Barre de filtres : cliquer reconstruit l'onglet (LOG_FILTRE est mémorisé).
            local nFx = 0
            for _, f in ipairs(LOG_FILTRES) do
                local bw = R(96)
                local b = vgui.Create("DButton", content) b:SetText("") b:SetCursor("hand")
                b:SetPos(R(0) + nFx, R(32)) b:SetSize(bw, R(26))
                b.Paint = function(s2, w, h)
                    local on = (LOG_FILTRE == f.id)
                    rndx(R(7), 0, 0, w, h, on and COL_ACC or ColorAlpha(color_white, s2:IsHovered() and 18 or 8))
                    draw.SimpleText(f.label, "EVO_DB_Small", w / 2, h / 2,
                        on and color_white or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                b.DoClick = function()
                    if LOG_FILTRE == f.id then return end
                    LOG_FILTRE = f.id
                    selectTab("log")
                end
                nFx = nFx + bw + R(6)
            end

            local sc = vgui.Create("DScrollPanel", content) sc:SetPos(R(0), R(66)) sc:SetSize(R(cw), R(ch - 66))
            local vbar = sc:GetVBar()
            if IsValid(vbar) then
                vbar:SetWide(R(6))
                vbar.Paint = function() end
                if IsValid(vbar.btnUp) then vbar.btnUp.Paint = function() end end
                if IsValid(vbar.btnDown) then vbar.btnDown.Paint = function() end end
                vbar.btnGrip.Paint = function(_, w, h) rndx(R(3), 0, 0, w, h, ColorAlpha(COL_ACC, 150)) end
            end

            -- Lignes retenues par le filtre courant.
            local tRows = {}
            for _, e in ipairs(snap.logs or {}) do
                if LogVisible(e) then tRows[#tRows + 1] = e end
            end

            if #tRows == 0 then
                local l = vgui.Create("DLabel") l:SetFont("EVO_DB_Lbl") l:SetTextColor(COL_DIM)
                l:SetText(LOG_FILTRE == "tout" and "Aucune transaction."
                    or "Aucune transaction pour ce filtre.")
                sc:AddItem(l) -- ⚠ AddItem (reparente vers le CANEVAS) puis Dock : avec un
                l:Dock(TOP)   -- simple parentage, rien n'entre dans le canevas et le
                l:SetTall(R(24)) -- journal ne défile pas.
            else
                for _, e in ipairs(tRows) do
                    local t = TxInfo(e.kind)
                    local r = vgui.Create("DPanel") r:SetPaintBackground(false)
                    -- AddItem = ajout AU CANEVAS du DScrollPanel (il REPARENTE seulement,
                    -- le Dock reste à notre charge). Avec un simple parentage les lignes se
                    -- posaient DANS le cadre sans faire grandir le canevas : au-delà d'une
                    -- douzaine d'entrées, le reste était injoignable.
                    sc:AddItem(r)
                    r:Dock(TOP)
                    r:SetTall(R(34))
                    r:DockMargin(0, 0, R(10), R(5))
                    r.Paint = function(s, w, h)
                        rndx(R(8), 0, 0, w, h, ColorAlpha(color_white, 6))
                        local credit = t.credit ~= false
                        MUGEN.DrawMoneyLine(t.l, "EVO_DB_Small", R(12), R(7), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                        local who = (e.actor ~= "—" and e.actor ~= "" and e.actor or "") .. (e.target ~= "—" and e.target ~= "" and ("  →  " .. e.target) or "")
                        MUGEN.DrawMoneyLine(who .. (e.detail ~= "" and ("  (" .. e.detail .. ")") or ""), "EVO_DB_Small", R(12), R(20), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                        if e.amount and e.amount > 0 then
                            MUGEN.DrawMoneyLine((credit and "+" or "−") .. comma(e.amount) .. " ¥", "EVO_DB_Small", w - R(12), h / 2, credit and COL_GREEN or COL_ACC, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                        end
                    end
                end
            end
        end
    end

    -- Restaure l'onglet précédent UNIQUEMENT s'il existe encore (un ex-officier rétrogradé ne doit
    -- pas retomber sur "Distribuer" qui n'a plus d'onglet dans la barre).
    local validTab = {} for _, t in ipairs(TABS) do validTab[t.id] = true end
    selectTab((PANEL_TAB and validTab[PANEL_TAB]) and PANEL_TAB or "tresor")
end

net.Receive("EVO:DivBank:Members", function()
    C._members = net.ReadTable() or {}
    if C._rebuildCompta and IsValid(C._win) and PANEL_TAB == "compta" then C._rebuildCompta() end
end)

net.Receive("EVO:DivBank:Snapshot", function()
    local ok = net.ReadBool()
    if not ok then
        if MUGEN and MUGEN.Notify then MUGEN.Notify("Tu dois être dans une faction.", NOTIFY_ERROR or 1, 5)
        else chat.AddText(COL_ACC, "[Banque] ", COL_TITLE, "Tu dois être dans une faction.") end
        return
    end
    C._snap = {
        faction = net.ReadString(), division = net.ReadUInt(8), divName = net.ReadString(),
        isManager = net.ReadBool(),
        canWithdraw = net.ReadBool(), isChief = net.ReadBool(),
        comptables = net.ReadTable(),
        money = net.ReadDouble(),
        qc = net.ReadUInt(16), qr = net.ReadUInt(16), qe = net.ReadUInt(16),
        myTotal = net.ReadDouble(), myTickets = net.ReadUInt(16),
        totalTickets = net.ReadUInt(32),
        donors = net.ReadTable(), logs = net.ReadTable(),
    }
    Build()
end)
