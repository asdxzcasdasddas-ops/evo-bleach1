-- "addons\\evo_placer\\lua\\autorun\\client\\cl_evo_placer.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PLACER — CLIENT : UI SuperAdmin (liste + éditeur boutons + "à ma visée").
-- Réglage FIN en direct : Avancer/Reculer/Gauche/Droite/Monter/Descendre (repère
-- sol dérivé du yaw de l'objet), Yaw/Pitch/Roll, Échelle, pas fin/moyen/gros.
-- "Viser & placer" : masque le menu, clic G = poser sur la visée, clic D = annuler.
-- Feedback instantané : on écrit l'override en local (optimiste) + on l'envoie ;
-- le serveur re-sync et re-broadcast (rendu serveur) ou le renderer client relit.
-- ============================================================================

if not CLIENT then return end

EVO_PLACER = EVO_PLACER or {} -- filet ordre de chargement (sh_ définit les fonctions partagées)

local COL_BG     = Color(14, 14, 18, 245)
local COL_PANEL  = Color(24, 24, 30, 255)
local COL_ROW    = Color(32, 32, 40, 255)
local COL_ROWSEL = Color(60, 48, 52, 255)
local COL_ACCENT = Color(207, 68, 78)
local COL_TXT    = Color(232, 232, 238)
local COL_DIM    = Color(150, 154, 162)

local frame, sel      -- sel = { provider, id, label, hasScale, pos, ang, scale }
local stepName = "moyen"

-- ── Miroir des overrides (reçu du serveur) ──────────────────────────────────
net.Receive("EVO_Placer:Sync", function()
	local map = game.GetMap()
	local provs = {}
	local nProv = net.ReadUInt(8)
	for _ = 1, nProv do
		local prov  = net.ReadString()
		local insts = {}
		local nInst = net.ReadUInt(16)
		for _ = 1, nInst do
			local id  = net.ReadString()
			local pos = net.ReadVector()
			local ang = net.ReadBool() and net.ReadAngle() or nil
			local scale = net.ReadBool() and net.ReadFloat() or nil
			insts[id] = { pos = pos, ang = ang, scale = scale }
		end
		provs[prov] = insts
	end
	EVO_PLACER.Overrides[map] = provs
end)

-- ── Envoi d'un transform (optimiste : override local immédiat) ───────────────
local function sendSet()
	if not sel then return end
	local map = game.GetMap()
	EVO_PLACER.Overrides[map] = EVO_PLACER.Overrides[map] or {}
	EVO_PLACER.Overrides[map][sel.provider] = EVO_PLACER.Overrides[map][sel.provider] or {}
	EVO_PLACER.Overrides[map][sel.provider][sel.id] = { pos = sel.pos, ang = sel.ang, scale = sel.scale }
	net.Start("EVO_Placer:Set")
		net.WriteString(sel.provider)
		net.WriteString(sel.id)
		net.WriteVector(sel.pos)
		net.WriteAngle(sel.ang)
		net.WriteFloat(sel.scale)
	net.SendToServer()
end

-- ── Repère sol dérivé du yaw (mouvement intuitif quel que soit le roll) ──────
local function frames(yaw)
	local r = math.rad(yaw)
	local c, s = math.cos(r), math.sin(r)
	return Vector(c, s, 0), Vector(s, -c, 0), Vector(0, 0, 1) -- forward, right, up
end

-- ── Preview live (ghost) ─────────────────────────────────────────────────────
local previewEnt -- ClientsideModel translucide pour les PNJ (nil pour les panneaux)
local function killPreviewEnt()
	if IsValid(previewEnt) then previewEnt:Remove() end
	previewEnt = nil
end

-- Transform de placement COURANT (ce que le ghost + le repère suivent) :
--   • mode visée -> la trace caméra (le ghost suit le réticule, WYSIWYG) ;
--   • édition    -> l'override courant (ou sel) = position live.
local function placementTransform()
	if not sel then return nil end
	if EVO_PLACER._aim then
		local tr = LocalPlayer():GetEyeTrace()
		return tr.HitPos + tr.HitNormal * 2, sel.ang, sel.scale
	end
	local o = EVO_PLACER.GetOverride(game.GetMap(), sel.provider, sel.id)
	return (o and o.pos) or sel.pos, (o and o.ang) or sel.ang, (o and o.scale) or sel.scale
end

-- ── Éditeur (reconstruit à chaque sélection) ────────────────────────────────
local editor
local function refreshLabels() end -- redéfini dans buildEditor

local function nudgePos(dir) -- dir : "fwd","back","right","left","up","down"
	if not sel then return end
	local step = EVO_PLACER.Steps.pos[stepName]
	local fwd, right, up = frames(sel.ang.y)
	local d = ({ fwd = fwd, back = -fwd, right = right, left = -right, up = up, down = -up })[dir]
	sel.pos = sel.pos + d * step
	sendSet(); refreshLabels()
end

local function nudgeAng(axis, sign) -- axis : "y","p","r"
	if not sel then return end
	local step = EVO_PLACER.Steps.ang[stepName] * sign
	sel.ang = Angle(sel.ang.p, sel.ang.y, sel.ang.r)
	sel.ang[axis] = sel.ang[axis] + step
	sendSet(); refreshLabels()
end

local function nudgeScale(sign)
	if not sel or not sel.hasScale then return end
	local step = EVO_PLACER.Steps.scale[stepName] * sign
	sel.scale = math.Clamp(math.Round(sel.scale + step, 3), 0.01, 5)
	sendSet(); refreshLabels()
end

-- ── "Viser & placer" : masque le menu, clic G = poser, clic D = annuler ─────
EVO_PLACER._aim = nil
local function enterAim()
	if not sel then return end
	EVO_PLACER._aim = { provider = sel.provider, id = sel.id, ang = sel.ang, scale = sel.scale }
	if IsValid(frame) then frame:SetVisible(false) end -- relâche le curseur -> la vue tourne
end
local function exitAim()
	EVO_PLACER._aim = nil
	if IsValid(frame) then frame:SetVisible(true) frame:MakePopup() end
end

hook.Add("PlayerBindPress", "EVO_Placer:AimClick", function(ply, bind, pressed)
	if not EVO_PLACER._aim or not pressed then return end
	bind = string.lower(bind)
	if bind == "+attack" then
		local a = EVO_PLACER._aim
		net.Start("EVO_Placer:Aim")
			net.WriteString(a.provider)
			net.WriteString(a.id)
			net.WriteAngle(a.ang)
			net.WriteFloat(a.scale)
		net.SendToServer()
		exitAim()
		return true
	elseif bind == "+attack2" then
		exitAim()
		return true
	end
end)

-- HUD du mode visée + highlight de l'objet sélectionné.
hook.Add("HUDPaint", "EVO_Placer:AimHUD", function()
	if not EVO_PLACER._aim then return end
	local sw, sh = ScrW(), ScrH()
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(sw / 2 - 10, sh / 2 - 1, 20, 2)
	surface.DrawRect(sw / 2 - 1, sh / 2 - 10, 2, 20)
	draw.SimpleText("Clic GAUCHE = placer ici   •   Clic DROIT = annuler", "DermaLarge",
		sw / 2, sh * 0.62, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("PostDrawTranslucentRenderables", "EVO_Placer:Highlight", function(bDepth, bSky)
	if bDepth or bSky or not sel then return end
	if not (IsValid(frame) or EVO_PLACER._aim) then return end
	local pos, ang, scale = placementTransform()
	if not pos then return end

	-- Repère : boîte + axes (avant=vert, droite=bleu, haut=rouge).
	render.DrawWireframeBox(pos, ang, Vector(-6, -6, -6), Vector(6, 6, 6), COL_ACCENT, true)
	local fwd, right, up = frames(ang.y)
	render.DrawLine(pos, pos + fwd * 40, Color(90, 200, 90), true)
	render.DrawLine(pos, pos + right * 40, Color(90, 140, 255), true)
	render.DrawLine(pos, pos + up * 40, Color(255, 90, 90), true)

	-- Ghost : modèle 3D translucide (PNJ) — SEULEMENT en visée (en édition, le vrai
	-- PNJ bouge déjà en direct -> pas de doublon).
	if IsValid(previewEnt) and EVO_PLACER._aim then
		previewEnt:SetPos(pos)
		previewEnt:SetAngles(ang)
		previewEnt:SetModelScale(scale or 1)
		previewEnt:SetupBones()
		render.SetBlend(0.5)
		render.SetColorModulation(0.55, 0.8, 1)
		previewEnt:DrawModel()
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
	-- ...ou empreinte 3D2D du panneau (classements) à l'échelle réelle.
	elseif sel.pW and sel.pW > 0 then
		cam.Start3D2D(pos, ang, scale or 0.15)
			surface.SetDrawColor(207, 68, 78, 55)
			surface.DrawRect(0, 0, sel.pW, sel.pH)
			surface.SetDrawColor(207, 68, 78, 220)
			surface.DrawOutlinedRect(0, 0, sel.pW, sel.pH, 6)
		cam.End3D2D()
	end
end)

-- ── Construction de l'éditeur pour l'objet sélectionné ──────────────────────
local function styleBtn(b, col)
	b:SetTextColor(COL_TXT)
	b.Paint = function(s, w, h)
		draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and (col or COL_ACCENT) or COL_ROW)
	end
end

local function buildEditor(parent)
	if IsValid(editor) then editor:Remove() end
	editor = vgui.Create("DPanel", parent)
	editor:Dock(FILL)
	editor:DockMargin(6, 6, 6, 6)
	editor.Paint = function(_, w, h) draw.RoundedBox(6, 0, 0, w, h, COL_PANEL) end

	if not sel then
		local hint = vgui.Create("DLabel", editor)
		hint:Dock(FILL)
		hint:SetText("  Sélectionne un objet à gauche.")
		hint:SetTextColor(COL_DIM)
		return
	end

	local title = vgui.Create("DLabel", editor)
	title:Dock(TOP); title:DockMargin(10, 10, 10, 0); title:SetTall(24)
	title:SetFont("DermaDefaultBold"); title:SetTextColor(COL_TXT)
	title:SetText(sel.label)

	local coords = vgui.Create("DLabel", editor)
	coords:Dock(TOP); coords:DockMargin(10, 2, 10, 6); coords:SetTall(34)
	coords:SetTextColor(COL_DIM)

	refreshLabels = function()
		coords:SetText(string.format("pos %.1f  %.1f  %.1f\nyaw %.1f  pitch %.1f  roll %.1f%s",
			sel.pos.x, sel.pos.y, sel.pos.z, sel.ang.y, sel.ang.p, sel.ang.r,
			sel.hasScale and ("   scale " .. string.format("%.3f", sel.scale)) or ""))
	end
	refreshLabels()

	-- Sélecteur de pas.
	local stepRow = vgui.Create("DPanel", editor)
	stepRow:Dock(TOP); stepRow:DockMargin(10, 0, 10, 6); stepRow:SetTall(26)
	stepRow.Paint = nil
	local stepBtns = {}
	for _, sName in ipairs({ "fin", "moyen", "gros" }) do
		local b = vgui.Create("DButton", stepRow)
		b:Dock(LEFT); b:DockMargin(0, 0, 4, 0); b:SetWide(70); b:SetText("Pas : " .. sName)
		b:SetTextColor(COL_TXT)
		b.Paint = function(s, w, h)
			draw.RoundedBox(4, 0, 0, w, h, (stepName == sName) and COL_ACCENT or COL_ROW)
		end
		b.DoClick = function() stepName = sName end
		stepBtns[sName] = b
	end

	-- Helper : ligne de boutons.
	local function row(h)
		local p = vgui.Create("DPanel", editor)
		p:Dock(TOP); p:DockMargin(10, 0, 10, 5); p:SetTall(h or 30); p.Paint = nil
		return p
	end
	local function btn(parentRow, text, fn, col)
		local b = vgui.Create("DButton", parentRow)
		b:Dock(FILL); b:DockMargin(0, 0, 4, 0); b:SetText(text)
		styleBtn(b, col); b.DoClick = fn
		return b
	end

	-- Déplacement.
	local r1 = row(); btn(r1, "◄ Reculer", function() nudgePos("back") end); btn(r1, "Avancer ►", function() nudgePos("fwd") end)
	local r2 = row(); btn(r2, "◄ Gauche", function() nudgePos("left") end);  btn(r2, "Droite ►", function() nudgePos("right") end)
	local r3 = row(); btn(r3, "▼ Descendre", function() nudgePos("down") end); btn(r3, "▲ Monter", function() nudgePos("up") end)

	-- Rotation.
	local r4 = row(); btn(r4, "Yaw −", function() nudgeAng("y", -1) end);   btn(r4, "Yaw +", function() nudgeAng("y", 1) end)
	local r5 = row(); btn(r5, "Pitch −", function() nudgeAng("p", -1) end); btn(r5, "Pitch +", function() nudgeAng("p", 1) end)
	local r6 = row(); btn(r6, "Roll −", function() nudgeAng("r", -1) end);  btn(r6, "Roll +", function() nudgeAng("r", 1) end)

	-- Échelle.
	if sel.hasScale then
		local r7 = row(); btn(r7, "Échelle −", function() nudgeScale(-1) end); btn(r7, "Échelle +", function() nudgeScale(1) end)
	end

	-- Actions.
	local r8 = row(34); btn(r8, "🎯 Viser & placer", enterAim, Color(60, 110, 70))
	local r9 = row(30)
	btn(r9, "Reset (config)", function()
		net.Start("EVO_Placer:Reset") net.WriteString(sel.provider) net.WriteString(sel.id) net.SendToServer()
		local m = EVO_PLACER.Overrides[game.GetMap()]
		if m and m[sel.provider] then m[sel.provider][sel.id] = nil end
	end, Color(120, 60, 60))
	btn(r9, "Copier coords", function()
		net.Start("EVO_Placer:Print") net.SendToServer()
	end, Color(70, 70, 90))
end

-- ── Liste des instances ──────────────────────────────────────────────────────
local listPanel
local function rebuildList(rows)
	if not IsValid(listPanel) then return end
	listPanel:GetCanvas():Clear()
	local lastProv
	for _, r in ipairs(rows) do
		if r.plabel ~= lastProv then
			lastProv = r.plabel
			local head = vgui.Create("DLabel", listPanel)
			head:Dock(TOP); head:DockMargin(2, 6, 2, 2); head:SetTall(18)
			head:SetFont("DermaDefaultBold"); head:SetTextColor(COL_ACCENT)
			head:SetText(string.upper(r.plabel))
		end
		local b = vgui.Create("DButton", listPanel)
		b:Dock(TOP); b:DockMargin(2, 0, 2, 3); b:SetTall(26); b:SetText("")
		b.Paint = function(s, w, h)
			local isSel = sel and sel.provider == r.provider and sel.id == r.id
			draw.RoundedBox(4, 0, 0, w, h, isSel and COL_ROWSEL or COL_ROW)
			draw.SimpleText(r.label, "DermaDefault", 8, h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			sel = { provider = r.provider, id = r.id, label = r.label, hasScale = r.hasScale,
				pos = Vector(r.pos), ang = Angle(r.ang.p, r.ang.y, r.ang.r), scale = r.scale,
				pModel = r.pModel, pW = r.pW, pH = r.pH }
			-- Ghost : ClientsideModel translucide pour les PNJ (dessiné à la main dans le hook).
			killPreviewEnt()
			if isstring(sel.pModel) and sel.pModel ~= "" and util.IsValidModel(sel.pModel) then
				previewEnt = ClientsideModel(sel.pModel)
				if IsValid(previewEnt) then previewEnt:SetNoDraw(true) end
			end
			buildEditor(frame._right)
		end
	end
end

net.Receive("EVO_Placer:List", function()
	local rows = {}
	local n = net.ReadUInt(16)
	for _ = 1, n do
		local provider = net.ReadString()
		local plabel   = net.ReadString()
		local hasScale = net.ReadBool()
		local id       = net.ReadString()
		local label    = net.ReadString()
		local pos      = net.ReadVector()
		local ang      = net.ReadAngle()
		local scale    = net.ReadFloat()
		local pModel   = net.ReadString()
		local pW       = net.ReadFloat()
		local pH       = net.ReadFloat()
		rows[#rows + 1] = { provider = provider, plabel = plabel, hasScale = hasScale,
			id = id, label = label, pos = pos, ang = ang, scale = scale,
			pModel = pModel, pW = pW, pH = pH }
	end
	rebuildList(rows)
end)

net.Receive("EVO_Placer:Print", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do print(net.ReadString()) end
	chat.AddText(COL_ACCENT, "[Placer] ", COL_TXT, "Coords copiées dans la console (~).")
end)

-- ── Ouverture du menu ────────────────────────────────────────────────────────
local function openMenu()
	if not LocalPlayer():IsSuperAdmin() then
		chat.AddText(Color(200, 80, 80), "[Placer] SuperAdmin uniquement.")
		return
	end
	if IsValid(frame) then frame:Remove() end
	EVO_PLACER._aim = nil -- (LOW-1) évite un réticule d'aim fantôme si on rouvre le menu en plein mode visée
	sel = nil
	killPreviewEnt()
	frame = vgui.Create("DFrame")
	frame.OnRemove = function() killPreviewEnt() end -- pas de ghost qui traîne après fermeture
	frame:SetSize(math.min(720, ScrW() * 0.6), math.min(560, ScrH() * 0.75))
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame.Paint = function(_, w, h)
		draw.RoundedBox(8, 0, 0, w, h, COL_BG)
		draw.SimpleText("EVO PLACER", "DermaLarge", 14, 12, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Placement in-game : SuperAdmin", "DermaDefault", 15, 40, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	local close = vgui.Create("DButton", frame)
	close:SetText("✕"); close:SetSize(28, 24); close:SetPos(frame:GetWide() - 34, 8)
	close:SetTextColor(COL_TXT)
	close.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and COL_ACCENT or COL_ROW) end
	close.DoClick = function() frame:Remove() end

	-- Corps : liste (gauche) + éditeur (droite).
	local body = vgui.Create("DPanel", frame)
	body:Dock(FILL); body:DockMargin(8, 60, 8, 8); body.Paint = nil

	local left = vgui.Create("DPanel", body)
	left:Dock(LEFT); left:SetWide(230); left:DockMargin(0, 0, 6, 0)
	left.Paint = function(_, w, h) draw.RoundedBox(6, 0, 0, w, h, COL_PANEL) end
	local refreshBtn = vgui.Create("DButton", left)
	refreshBtn:Dock(TOP); refreshBtn:DockMargin(6, 6, 6, 4); refreshBtn:SetTall(24); refreshBtn:SetText("↻ Rafraîchir la liste")
	refreshBtn:SetTextColor(COL_TXT)
	refreshBtn.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and COL_ACCENT or COL_ROW) end
	refreshBtn.DoClick = function() net.Start("EVO_Placer:List") net.SendToServer() end
	listPanel = vgui.Create("DScrollPanel", left)
	listPanel:Dock(FILL); listPanel:DockMargin(6, 0, 4, 6)

	frame._right = vgui.Create("DPanel", body)
	frame._right:Dock(FILL); frame._right.Paint = nil
	buildEditor(frame._right)

	-- Demande la liste au serveur.
	net.Start("EVO_Placer:List") net.SendToServer()
end

concommand.Add("evo_placer", openMenu)

-- Ouverture demandée par la commande SAM "placer" (serveur -> client). Robuste :
-- SAM intercepte les messages chat "!..." avant OnPlayerChat, donc on passe par
-- une vraie commande SAM (cf. sam/modules/evo_placer.lua) qui envoie ce net.
net.Receive("EVO_Placer:Open", openMenu)

-- Raccourci chat SuperAdmin : "!placer" (en plus de la concommand evo_placer).
hook.Add("OnPlayerChat", "EVO_Placer:ChatOpen", function(ply, text)
	if ply == LocalPlayer() and string.lower(string.Trim(text or "")) == "!placer" then
		openMenu()
		return true
	end
end)
