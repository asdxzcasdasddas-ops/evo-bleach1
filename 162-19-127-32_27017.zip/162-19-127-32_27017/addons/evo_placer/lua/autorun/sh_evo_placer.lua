-- "addons\\evo_placer\\lua\\autorun\\sh_evo_placer.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PLACER — Outil de placement in-game SuperAdmin (2026-07-24, demande user).
-- ----------------------------------------------------------------------------
-- Généralise le pattern d'evo_repos (placer + persistance data/ + net live) et
-- d'evo_leaderboard (re-broadcast des positions) en un OUTIL UNIVERSEL : un SA
-- sélectionne un objet plaçable de la map et l'ajuste EN DIRECT (avancer/reculer,
-- gauche/droite, monter/descendre, yaw/pitch/roll, échelle, "à ma visée"), sans
-- redémarrage. Les réglages sont persistés (data/evo_placer.json) et networkés.
--
-- COUCHE D'OVERRIDES (générique) : Overrides[map][provider][id] = {pos,ang,scale}.
-- Elle vit CÔTÉ SERVEUR (source de vérité, data/) ET est mirrorée aux clients.
-- N'importe quel renderer — serveur (classement faction : getActivePositions
-- applique l'override puis re-broadcast) ou client (panneau clan : getPanels lit
-- sa config chaque frame + applique l'override) — appelle GetOverride().
--
-- REGISTRE DE PROVIDERS (serveur) : un addon expose { id, label, hasScale, List,
-- Refresh } via EVO_PLACER.RegisterProvider. List(map) renvoie les instances
-- EFFECTIVES { id, label, pos, ang, scale } (override déjà appliqué) ; Refresh()
-- ré-applique en live après un changement (re-broadcast pour un rendu serveur ;
-- no-op pour un rendu client qui relit chaque frame).
-- ============================================================================

EVO_PLACER = EVO_PLACER or {}

-- Overrides[map][providerId][instanceId] = { pos = Vector, ang = Angle, scale = number }
-- Serveur : chargé de data/. Client : miroir reçu par net "EVO_Placer:Sync".
EVO_PLACER.Overrides = EVO_PLACER.Overrides or {}

-- Renvoie l'override {pos, ang, scale} pour un objet (ou nil). Partagé.
function EVO_PLACER.GetOverride(sMap, sProvider, sId)
	local m = EVO_PLACER.Overrides[sMap]
	local p = m and m[sProvider]
	return p and p[sId] or nil
end

-- Applique un override (s'il existe) sur un transform de base -> pos, ang, scale.
-- Helper unique utilisé par tous les renderers pour rester cohérents.
function EVO_PLACER.Apply(vPos, aAng, nScale, sMap, sProvider, sId)
	local o = EVO_PLACER.GetOverride(sMap, sProvider, sId)
	if not o then return vPos, aAng, nScale end
	return o.pos or vPos, o.ang or aAng, o.scale or nScale
end

-- ── Pas de réglage (fin / moyen / gros) : position (u) et rotation (°) ───────
EVO_PLACER.Steps = {
	pos = { fin = 2, moyen = 10, gros = 50 },
	ang = { fin = 1, moyen = 5, gros = 45 },
	scale = { fin = 0.01, moyen = 0.02, gros = 0.05 },
}

if SERVER then
	util.AddNetworkString("EVO_Placer:Sync")     -- sv -> cl : overrides de la map
	util.AddNetworkString("EVO_Placer:List")     -- cl <-> sv : demande / envoi de la liste d'instances
	util.AddNetworkString("EVO_Placer:Set")      -- cl -> sv : nouveau transform d'une instance
	util.AddNetworkString("EVO_Placer:Aim")      -- cl -> sv : placer l'instance sur la visée du SA
	util.AddNetworkString("EVO_Placer:Reset")    -- cl -> sv : retour à la config (retire l'override)
	util.AddNetworkString("EVO_Placer:Print")    -- cl <-> sv : dump des coords (console) pour "baker" au config
	util.AddNetworkString("EVO_Placer:Open")     -- sv -> cl : ordre d'ouverture du menu (commande SAM)
end
