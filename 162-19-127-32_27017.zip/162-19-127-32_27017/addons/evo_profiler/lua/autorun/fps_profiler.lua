-- "addons\\evo_profiler\\lua\\autorun\\fps_profiler.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ===========================================================================
-- EVO FPS PROFILER (client) — OUTIL DE DEV.
-- Mesure le temps réel (SysTime) passé dans chaque hook par frame, pour
-- repérer ce qui consomme le plus de FPS côté client.
--
-- Console (F10) :
--   fps_prof_start    -> démarre la mesure (réinitialise à chaque appel)
--   ... joue 10-20 s dans la zone qui rame ...
--   fps_prof_report   -> imprime le TOP dans la CONSOLE
--   fps_prof_stop     -> retire l'instrumentation (hooks remis d'origine)
--
-- 100 % client, aucun impact gameplay. Les valeurs de retour des hooks
-- (CalcView, HUDShouldDraw, NeedsDepthPass, ...) sont préservées telles quelles
-- donc rien n'est cassé pendant la mesure. fps_prof_stop remet tout en place.
-- ===========================================================================
if SERVER then
    -- Fichier en realm AUTORUN (shared) : on l'AddCSLuaFile pour qu'il soit
    -- envoyé au client, puis on s'arrête (le corps ne tourne que côté client).
    AddCSLuaFile()
    return
end

-- Events par-frame instrumentés (tous ceux passant par hook.Add).
local EVENTS = {
    "Think", "Tick",
    "HUDPaint", "HUDPaintBackground", "HUDShouldDraw", "PostDrawHUD", "PreDrawHUD",
    "PreRender", "PostRender",
    "PreDrawOpaqueRenderables", "PostDrawOpaqueRenderables",
    "PreDrawTranslucentRenderables", "PostDrawTranslucentRenderables",
    "PreDrawHalos", "RenderScene", "RenderScreenspaceEffects",
    "CalcView", "DrawOverlay", "PostDrawEffects", "NeedsDepthPass",
}

local SysTime  = SysTime
local stats    = {}    -- stats[key] = { time=, calls=, ev=, name=, key= }
local wrapped  = {}    -- wrapped[ev][name] = { orig=, wrap= }
local active   = false
local startSys = 0
local frameCount = 0

-- Remet en place les fonctions d'origine. On NE restaure QUE si notre wrapper
-- est toujours posé (sinon on écraserait un hook re-ajouté pendant la mesure).
local function restore()
    local tbl = hook.GetTable()
    for ev, names in pairs(wrapped) do
        local evHooks = tbl[ev]
        if evHooks then
            for name, entry in pairs(names) do
                -- ne restaure QUE si notre wrapper est encore en place (sinon on
                -- écraserait un hook re-ajouté pendant la mesure). Restauration via
                -- hook.Add (même raison que l'instrumentation : dispatch interne).
                if evHooks[name] == entry.wrap then
                    hook.Add(ev, name, entry.orig)
                end
            end
        end
    end
    wrapped = {}
end

-- Enrobe chaque hook string des events ciblés par un chrono. Les "object hooks"
-- (clé = table/entity) sont ignorés pour ne rien casser.
local function instrument()
    local tbl = hook.GetTable()
    for _, ev in ipairs(EVENTS) do
        local evHooks = tbl[ev]
        if evHooks then
            wrapped[ev] = {}
            for name, fn in pairs(evHooks) do
                if isstring(name) and isfunction(fn) and name ~= "EVO_FPSProf_FrameCounter" then
                    local key = ev .. " :: " .. name
                    local st  = { time = 0, calls = 0, ev = ev, name = name, key = key }
                    stats[key] = st
                    local wrap
                    wrap = function(...)
                        local t0 = SysTime()
                        -- fn(...) reçoit TOUS les args ; on renvoie jusqu'à 6 valeurs
                        -- de retour (couvre CalcView/HUDShouldDraw/NeedsDepthPass...).
                        local r1, r2, r3, r4, r5, r6 = fn(...)
                        st.time  = st.time + (SysTime() - t0)
                        st.calls = st.calls + 1
                        return r1, r2, r3, r4, r5, r6
                    end
                    wrapped[ev][name] = { orig = fn, wrap = wrap }
                    -- IMPORTANT : on passe par hook.Add (et PAS par une mutation
                    -- directe de hook.GetTable()) : sur les GMod récents, le dispatch
                    -- itère une liste interne séparée, donc muter la table ne change
                    -- rien. hook.Add(même nom) remplace bien le hook dans le dispatch.
                    hook.Add(ev, name, wrap)
                end
            end
        end
    end
end

-- Compteur de frames dédié : 1x/frame garanti, indépendant des autres addons.
-- Sert de dénominateur fiable pour les "ms/frame" du rapport. Exclu de
-- l'instrumentation (cf. instrument()) pour ne pas se mesurer lui-même.
hook.Add("Think", "EVO_FPSProf_FrameCounter", function()
    if active then frameCount = frameCount + 1 end
end)

concommand.Add("fps_prof_start", function()
    restore()          -- repart propre (anti double-enrobage si déjà lancé)
    stats      = {}
    startSys   = SysTime()
    frameCount = 0
    instrument()
    active = true
    MsgC(Color(80, 200, 120), "[FPS PROF] Mesure démarrée. Joue 10-20 s puis : fps_prof_report", "\n")
end)

concommand.Add("fps_prof_stop", function()
    restore()
    active = false
    MsgC(Color(220, 140, 80), "[FPS PROF] Arrêté, hooks restaurés.", "\n")
end)

concommand.Add("fps_prof_report", function()
    if not next(stats) then
        MsgC(Color(230, 90, 90), "[FPS PROF] Rien à afficher — lance d'abord fps_prof_start.", "\n")
        return
    end

    local elapsed = math.max(0.0001, SysTime() - startSys)

    -- Nombre de frames mesurées : compteur dédié (hook Think tirant 1x/frame),
    -- fiable même si aucun autre addon n'a de hook Think string.
    local frames = math.max(1, frameCount)

    local list, evTotal = {}, {}
    for _, s in pairs(stats) do
        list[#list + 1] = s
        evTotal[s.ev] = (evTotal[s.ev] or 0) + s.time
    end
    table.sort(list, function(a, b) return a.time > b.time end)

    MsgC(Color(120, 180, 255), "\n================= EVO FPS PROFILER =================\n")
    MsgN(string.format("Mesure : %.1f s   ~%d frames   (~%.0f FPS moyens)", elapsed, frames, frames / elapsed))
    MsgN("")
    MsgN("--- TOP HOOKS (tri par coût total) ---")
    MsgN(string.format("%-52s %10s %10s %9s", "HOOK", "ms/frame", "ms total", "appels"))
    for i = 1, math.min(30, #list) do
        local s = list[i]
        MsgN(string.format("%-52s %10.4f %10.1f %9d", s.key, (s.time / frames) * 1000, s.time * 1000, s.calls))
    end

    local evList = {}
    for ev, t in pairs(evTotal) do evList[#evList + 1] = { ev = ev, t = t } end
    table.sort(evList, function(a, b) return a.t > b.t end)
    MsgN("")
    MsgN("--- TOTAL PAR EVENT (somme de ses hooks) ---")
    for _, e in ipairs(evList) do
        MsgN(string.format("%-46s %10.4f ms/frame", e.ev, (e.t / frames) * 1000))
    end
    MsgC(Color(120, 180, 255), "====================================================\n")
    MsgC(Color(120, 180, 255), "[FPS PROF] Rapport imprimé dans la CONSOLE (top 30 + total par event).", "\n")
end)

-- (bannière console de chargement retirée 07/20 — spam au join, demande user.
--  Commandes toujours dispo : fps_prof_start / fps_prof_report / fps_prof_stop)
