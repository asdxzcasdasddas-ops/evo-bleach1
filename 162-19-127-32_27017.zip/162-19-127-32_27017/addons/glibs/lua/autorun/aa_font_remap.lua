-- "addons\\glibs\\lua\\autorun\\aa_font_remap.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ══════════════════════════════════════════════════════════
-- Font remap : substitution des familles non shippées par
-- des familles disponibles. On wrap surface.CreateFont au plus
-- tôt (autorun file préfixé "aa_" pour passer avant les
-- autres files de glibs et avant la plupart des includes
-- d'autres addons), comme ça toute création de font qui passe
-- ensuite récupère la famille substituée et le moteur ne crie
-- plus "Couldn't find/load font 'X'".
-- ══════════════════════════════════════════════════════════

if not CLIENT then return end
if _G._LZY_FONT_REMAP_INSTALLED then return end
_G._LZY_FONT_REMAP_INSTALLED = true

-- Familles non disponibles → substituts présents sur la quasi-totalité des
-- systèmes (Windows par défaut, plus polices shippées via lzy_faction/glibs).
-- "Impact" est le plus proche visuellement de Bebas Neue (condensed bold).
local FONT_SUBSTITUTES = {
	["Bebas Neue"] = "Impact",
}

-- evo_ui livre désormais BebasNeue-Regular.ttf (resource/fonts, resource.AddFile) :
-- si le client possède le fichier, on NE substitue PLUS -> le VRAI Bebas rend en
-- VGUI (avant : Impact partout, perçu « bold » par le user — 2026-07-06). Testé à
-- chaque appel (pas de cache : le contenu peut monter après les tout premiers
-- CreateFont) ; client sans le fichier -> Impact comme avant.
local _origCreateFont = surface.CreateFont
function surface.CreateFont(name, data)
	if istable(data) and isstring(data.font) then
		local sub = FONT_SUBSTITUTES[data.font]
		if sub then
			if data.font == "Bebas Neue"
				and file.Exists("resource/fonts/BebasNeue-Regular.ttf", "GAME") then
				sub = nil -- vrai TTF présent : pas de substitution
			end
			if sub then data.font = sub end
		end
	end
	return _origCreateFont(name, data)
end
