-- "addons\\glibs\\lua\\autorun\\sh_loader_glibs.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
GPYMOUSSS = GPYMOUSSS or {}
GPYMOUSSS.GLibs = false

if SERVER then
	-- Module responsive
	AddCSLuaFile("libraries/resp/rndx.lua")
	AddCSLuaFile("libraries/resp/responsive.lua")
	AddCSLuaFile("libraries/resp/panel.lua")
	AddCSLuaFile("libraries/resp/materials.lua")
	AddCSLuaFile("libraries/resp/anims.lua")
	-- Module Anims (libraries/anims/anims.lua) retiré : gSetAnim/net gAnims morts (0 appel).
end

if CLIENT then
	-- Module responsive
	include("libraries/resp/responsive.lua")
	include("libraries/resp/panel.lua")
	include("libraries/resp/materials.lua")
	include("libraries/resp/anims.lua")
end

GPYMOUSSS.GLibs = true
