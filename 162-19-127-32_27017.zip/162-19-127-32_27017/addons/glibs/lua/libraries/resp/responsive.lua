-- "addons\\glibs\\lua\\libraries\\resp\\responsive.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local BASE_WIDTH = 1920
local BASE_HEIGHT = 1080
local scaleX, scaleY
-- Scales bruts (non-uniformises) exposes pour le code qui doit calculer
-- en vraies dimensions ecran (HUD edge-anchored, full-width overlays).
local rawScaleX, rawScaleY

-- Scaling indépendant X / Y (logique d'origine) : gRespX suit le ratio largeur
-- et gRespY le ratio hauteur, donc les UIs designees en 1920x1080 s'etendent
-- jusqu'aux bords sur n'importe quelle resolution (ultrawide compris). Sans ca,
-- sur ultrawide le contenu positionne via gRespX(1920) ne touche plus le bord
-- droit -> UI compressee/coupee a droite.
-- gRespRawX/gRespRawY restent disponibles comme alias explicites pour le code
-- qui veut etre clair sur l'usage des vraies dimensions ecran.
local function UpdateScaleFactors()
	rawScaleX = ScrW() / BASE_WIDTH
	rawScaleY = ScrH() / BASE_HEIGHT
	scaleX = rawScaleX
	scaleY = rawScaleY
end

-- Helpers exposes pour calculer en vraies dimensions ecran.
function gRawScaleX() return rawScaleX end
function gRawScaleY() return rawScaleY end
function gRespRawX(value) return math.Round(value * rawScaleX) end
function gRespRawY(value) return math.Round(value * rawScaleY) end

function gRespX(value)
	return math.Round(value * scaleX)
end

function gRespY(value)
	return math.Round(value * scaleY)
end

-- Scale UNIFORME (min des deux axes) : conserve les proportions (les carres restent
-- carres) sur les resolutions non-16:9. gRespX/gRespY (scale independant par axe) sont
-- conserves tels quels pour les HUD edge-anchored / overlays plein ecran ; gRespU est
-- l'alternative OPT-IN pour les UI CENTREES (popups) et les elements carres (icones,
-- vignettes) qui sinon sont ecrases horizontalement en 1:1 / portrait.
function gUScale()
	return math.min(scaleX, scaleY)
end

function gRespU(value)
	return math.Round(value * math.min(scaleX, scaleY))
end

function gRespFont(size)
	-- return math.Round(size * math.min(scaleX, scaleY))

	-- Use square root scaling for more conservative font scaling across resolutions
	-- This prevents fonts from becoming too large on high-res displays
	local scale = math.min(scaleX, scaleY)
	local fontScale = 1 + (math.sqrt(scale) - 1) * 0.7 -- More conservative scaling
	return math.Round(size * fontScale)
end

function gCreateRespFont(name, fontFamily, baseSize, weight, antialias, shadow, outline, italic)
	local fontData = {
		font = fontFamily,
		size = gRespFont(baseSize),
		weight = weight or 500,
		antialias = antialias or true,
		shadow = shadow or false,
		outline = outline or false,
		italic = italic or false
	}
	surface.CreateFont(name, fontData)
end

-- Custom split function that preserves empty lines
local function splitWithEmptyLines(str, delimiter)
	local lines = {}
	local current = ""
	for i = 1, #str do
		local char = string.sub(str, i, i)
		if char == delimiter then
			table.insert(lines, current)
			current = ""
		else
			current = current .. char
		end
	end
	table.insert(lines, current) -- Add the last line
	return lines
end

function splitText(content, font, lineWidth, maxLines)
	if not content or not font or not lineWidth then
		return {}
	end
	
	surface.SetFont(font)
	local lines = {}
	local words = string.Split(content, " ")
	local currentLine = ""
	local lineCount = 0
	
	for i, word in ipairs(words) do
		-- Check if the word contains newlines
		if string.find(word, "\n") then
			-- Split the word on newlines
			local parts = splitWithEmptyLines(word, "\n")
			for j, part in ipairs(parts) do
				if j == 1 then
					-- First part goes with current line
					local testLine = currentLine .. (currentLine ~= "" and " " or "") .. part
					local width = select(1, surface.GetTextSize(testLine))
					
					if width <= lineWidth then
						currentLine = testLine
					else
						if currentLine ~= "" then
							table.insert(lines, currentLine)
							currentLine = part
							lineCount = lineCount + 1
						else
							table.insert(lines, part)
							currentLine = ""
							lineCount = lineCount + 1
						end
					end
				else
					-- Subsequent parts start new lines
					if currentLine ~= "" then
						table.insert(lines, currentLine)
						lineCount = lineCount + 1
					end
					
					if part == "" then
						-- Empty part means newline - add empty line
						table.insert(lines, "")
						lineCount = lineCount + 1
						currentLine = ""
					else
						-- Non-empty part starts new line
						currentLine = part
					end
				end
				
				-- Check maxLines
				if maxLines and lineCount >= maxLines then
					break
				end
			end
		else
			-- Normal word processing
			local testLine = currentLine .. (currentLine ~= "" and " " or "") .. word
			local width = select(1, surface.GetTextSize(testLine))
			
			if width <= lineWidth then
				currentLine = testLine
			else
				if currentLine ~= "" then
					table.insert(lines, currentLine)
					currentLine = word
					lineCount = lineCount + 1
				else
					-- If a single word is too long, we have to break it
					table.insert(lines, word)
					currentLine = ""
					lineCount = lineCount + 1
				end
				
				-- Check if we've reached maxLines
				if maxLines and lineCount >= maxLines then
					-- If we have more words to process, add "..." to the last line
					if i < #words then
						local lastLine = lines[#lines]
						local ellipsisLine = lastLine .. "..."
						local ellipsisWidth = select(1, surface.GetTextSize(ellipsisLine))
						
						-- If "..." fits on the last line, use it
						if ellipsisWidth <= lineWidth then
							lines[#lines] = ellipsisLine
						else
							-- If "..." doesn't fit, try to fit it by removing some text
							local truncatedLine = lastLine
							while #truncatedLine > 0 do
								truncatedLine = string.sub(truncatedLine, 1, -2) -- Remove last character
								local testEllipsis = truncatedLine .. "..."
								local testWidth = select(1, surface.GetTextSize(testEllipsis))
								if testWidth <= lineWidth then
									lines[#lines] = testEllipsis
									break
								end
							end
						end
					end
					break
				end
			end
		end
	end
	
	-- Add the last line if it's not empty and we haven't reached maxLines
	if currentLine ~= "" and (not maxLines or lineCount < maxLines) then
		table.insert(lines, currentLine)
	end
	
	return lines
end

--- Width = widest line; height = sum of each line's pixel height plus `gap` between lines (not after last).
function gGetMultilineTextSize(content, font, gap, lineWidth, maxLines)
	local lines
	if lineWidth then
		lines = splitText(content, font, lineWidth, maxLines)
	else
		lines = splitWithEmptyLines(content or "", "\n")
	end
	surface.SetFont(font)
	local contentWidth = 0
	local contentHeight = 0
	for i, line in ipairs(lines) do
		if line == "" then
			local _, h = surface.GetTextSize(" ")
			contentHeight = contentHeight + h
		else
			local w, h = surface.GetTextSize(line)
			contentWidth = math.max(contentWidth, w)
			contentHeight = contentHeight + h
		end
		if i < #lines and gap then
			contentHeight = contentHeight + gap
		end
	end
	return contentWidth, contentHeight
end

function gRespDrawMultilineText(content, font, x, y, color, align, gap, lineWidth, maxLines, yAlign)
	local lines = {}
	if lineWidth then
		lines = splitText(content, font, lineWidth, maxLines)
	else
		-- Use custom split function that preserves empty lines
		lines = splitWithEmptyLines(content, "\n")
	end
	
	local currentY = y
	for i, line in ipairs(lines) do
		if line == "" then
			-- Empty line - add extra spacing
			currentY = currentY + gap
		else
			-- Regular line - draw it and advance position
			draw.SimpleText(line, font, gRespX(x), gRespY(currentY), color, align, yAlign and yAlign or nil)
			currentY = currentY + gap
		end
	end
end

local function Initialize()
	UpdateScaleFactors()
	for i = 1, 100 do
		gCreateRespFont("Ubuntu Mono:" .. i, "Ubuntu Mono", i, 400)
		gCreateRespFont("Ubuntu Mono Italic:" .. i, "Ubuntu Mono", i, 400, true, false, false, true)
		gCreateRespFont("Ubuntu Mono Bold:" .. i, "Ubuntu Mono", i, 700)
		gCreateRespFont("Inter Bold:" .. i, "Inter 18pt", i, 700)
		gCreateRespFont("Inter:" .. i, "Inter 18pt", i, 400)
		gCreateRespFont("Black Han Sans:" .. i, "Black Han Sans", i, 400)
		gCreateRespFont("Black Han Sans Bold:" .. i, "Black Han Sans", i, 900)
		gCreateRespFont("ABeeZee:" .. i, "ABeeZee", i, 400)
		gCreateRespFont("ABeeZee Bold:" .. i, "ABeeZee", i, 700)
		gCreateRespFont("HeliosExt:" .. i, "HeliosExt", i, 400)
		gCreateRespFont("HeliosExt Bold:" .. i, "HeliosExt", i, 800)
		gCreateRespFont("Helvetica Neue:" .. i, "Helvetica Neue", i, 400)
		gCreateRespFont("Helvetica Neue Bold:" .. i, "Helvetica Neue", i, 700)
		gCreateRespFont("Avenir Next World:" .. i, "Avenir Next World Medium", i+7, 600)
		-- "Avenir Next World" sans suffixe n'est pas shippée comme .ttf. On
		-- reroute le bold sur Medium et on laisse Source faux-bold via weight.
		gCreateRespFont("Avenir Next World Bold:" .. i, "Avenir Next World Medium", i+7, 800)
		-- Display DA Atelier (TTF livré par evo_ui ; aa_font_remap retombe sur
		-- Impact si le client ne l'a pas). Poids 400 : JAMAIS de faux-bold (user).
		gCreateRespFont("Bebas Neue:" .. i, "Bebas Neue", i, 400)
	end
end

hook.Add("Initialize", "InitializeResponsiveSystem", Initialize)

hook.Add("OnScreenSizeChanged", "UpdateResponsiveFactors", function()
	Initialize()
end)

Initialize()