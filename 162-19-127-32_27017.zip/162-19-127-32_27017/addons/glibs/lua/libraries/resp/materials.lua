-- "addons\\glibs\\lua\\libraries\\resp\\materials.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
RNDX = include("libraries/resp/rndx.lua")

function gMaterials(name, posx, posy, sizex, sizey, color)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)
	surface.DrawTexturedRect(
		gRespX(posx) or 0,
		gRespY(posy) or 0,
		gRespX(sizex) or 0,
		gRespY(sizey) or 0
	)
end

function pMaterials(name, posx, posy, sizex, sizey, color)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)
	surface.DrawTexturedRect(
		posx or 0,
		posy or 0,
		sizex or 0,
		sizey or 0
	)
end

function gMaterialsUV(name, posx, posy, sizex, sizey, color, u0, v0, u1, v1)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)
	surface.DrawTexturedRectUV(
		gRespX(posx) or 0,
		gRespY(posy) or 0,
		gRespX(sizex) or 0,
		gRespY(sizey) or 0,
		u0 or 0,
		v0 or 0,
		u1 or 1,
		v1 or 1
	)
end

function pMaterialsUV(name, posx, posy, sizex, sizey, color, u0, v0, u1, v1)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)
	surface.DrawTexturedRectUV(
		posx or 0,
		posy or 0,
		sizex or 0,
		sizey or 0,
		u0 or 0,
		v0 or 0,
		u1 or 1,
		v1 or 1
	)
end

function gCroppedMaterial(name, posx, posy, sizex, sizey, percent, color)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)

	local crop = math.Clamp(percent or 1, 0, 1)

	surface.DrawTexturedRectUV(
		gRespX(posx),
		gRespY(posy),
		gRespX(sizex) * crop,
		gRespY(sizey),
		0, 0,
		crop, 1
	)
end

function gCroppedMaterialV(name, posx, posy, sizex, sizey, percent, color)
	surface.SetMaterial(name)
	surface.SetDrawColor(color or color_white)

	local crop = math.Clamp(percent or 1, 0, 1)

	surface.DrawTexturedRectUV(
		gRespX(posx),
		gRespY(posy),
		gRespX(sizex),
		gRespY(sizey) * crop,
		0, 1 - crop,
		1, 1
	)
end

function gImageRotated(material, x, y, w, h, angle, parent, color)
	local img = vgui.Create("DPanel", parent)
	img:gSetSize(w, h)
	img:gSetPos(x, y)

	if not color then color = Color(255, 255, 255) end

	local mat = Material(material)
	img.GetMaterial = function() return mat end
	img.Paint = function()
		surface.SetMaterial(mat)
		surface.SetDrawColor(color)
		surface.DrawTexturedRectRotated(w / 2, h / 2, w, h, angle)
	end

	return img
end

function gPanel(x, y, w, h, parent)
	local panel = vgui.Create("DPanel", parent)
	panel:gSetSize(w, h)
	panel:gSetPos(x, y)
	return panel
end

function rImage(material, x, y, w, h, r, parent, flags, color)
	if not RNDX then return nil end
	local img = vgui.Create("DPanel", parent)
	img:gSetPos(x, y)
	img:gSetSize(w, h)

	img.mat = material
	img.flags = flags
	img.col = color or Color(255, 255, 255, 255)

	img.Paint = function()
		RNDX.DrawMaterial(r or 0, 0, 0, img:GetWide(), img:GetTall(), img.col, img.mat, img.flags)
	end

	return img
end

function rMaterials(name, x, y, w, h, r, flags, color)
	RNDX.DrawMaterial(r or 0, gRespX(x), gRespY(y), gRespX(w), gRespY(h), color or Color(255, 255, 255, 255), name, flags)
end

function rRect(x, y, w, h, color, radius, flags)
	RNDX.Draw(radius or 0, gRespX(x), gRespY(y), gRespX(w), gRespY(h), color or Color(255, 255, 255, 255), flags or 0)
end

function rOutlinedRect(x, y, w, h, color, radius, thickness, flags)
	RNDX.DrawOutlined(radius or 0, gRespX(x), gRespY(y), gRespX(w), gRespY(h), color or Color(255, 255, 255, 255), thickness or 1, flags or 0)
end

function rSimpleText(text, font, x, y, color, xalign, yalign)
	draw.SimpleText(text, font, gRespX(x), gRespY(y), color or Color(255, 255, 255, 255), xalign or TEXT_ALIGN_LEFT, yalign or TEXT_ALIGN_TOP)
end
