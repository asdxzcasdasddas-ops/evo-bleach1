-- "addons\\bleach_compass\\lua\\autorun\\client\\cl_compass.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Police des lettres cardinales (N, NE, E…). DA : Bebas Neue (titres, vrai TTF poids 400,
-- cf. evo_ui) au lieu d'Impact -> cohérent avec le reste de l'UI EVO (le libellé terrain
-- d'entraînement plus bas l'utilise déjà). Taille RESPONSIVE (~ScrH), recréée si la
-- résolution change. surface.CreateFont n'est PAS touché par le FONT_BOOST glibs.
local function createCompassDirFont()
    surface.CreateFont("BleachCompassDir", {
        font = "Bebas Neue",
        size = math.Round(ScrH() * 0.026),
        weight = 400,
        antialias = true,
    })
end
createCompassDirFont()
hook.Add("OnScreenSizeChanged", "BleachCompassDir::Refont", createCompassDirFont)

-- Police du libellé « TERRAIN D'ENTRAÎNEMENT » sous la boussole. Taille RESPONSIVE (~ScrH),
-- recréée si la résolution change. DA : Bebas Neue (titres, poids 400 = vrai TTF,
-- cf. evo_ui) + « EVO Kanji » pour le kanji gravé derrière (motif #platekanji).
local _trainTxtW, _trainTxtH
local _rpkTxtW, _rpkTxtH
local function createTrainingFont()
    surface.CreateFont("BleachTrainingZone", {
        font = "Bebas Neue",
        size = math.Round(ScrH() * 0.034),
        weight = 400,
        antialias = true,
    })
    surface.CreateFont("BleachTrainingKanji", {
        font = "EVO Kanji",
        size = math.Round(ScrH() * 0.062),
        weight = 700,
        antialias = true,
    })
    _trainTxtW, _trainTxtH = nil, nil
    _rpkTxtW, _rpkTxtH = nil, nil
end
createTrainingFont()
hook.Add("OnScreenSizeChanged", "BleachTrainingZone::Refont", createTrainingFont)

local directions = {
    [0] = "N",
    [45] = "NE",
    [90] = "E",
    [135] = "SE",
    [180] = "S",
    [225] = "SO",
    [270] = "O",
    [315] = "NO"
}

local matGradientL = Material("vgui/gradient-l")
local matGradientR = Material("vgui/gradient-r")

local headMarkerRange = 2000
local headMarkerRangeSq = headMarkerRange * headMarkerRange

-- Localize frequently used functions
local math_sin = math.sin
local math_abs = math.abs
local math_Clamp = math.Clamp
local math_AngleDifference = math.AngleDifference
local surface_SetDrawColor = surface.SetDrawColor
local surface_DrawRect = surface.DrawRect
local surface_DrawPoly = surface.DrawPoly
local surface_SetMaterial = surface.SetMaterial
local surface_DrawTexturedRect = surface.DrawTexturedRect
local draw_SimpleText = draw.SimpleText
local CurTime = CurTime
local ScrW = ScrW
local ScrH = ScrH

-- Pre-cached colors (avoid GC pressure)
local color_shadow_text = Color(0, 0, 0, 255)
local color_white_text = Color(255, 255, 255, 255)
-- Couleurs DÉDIÉES au libellé terrain d'entraînement (les 2 ci-dessus voient leur alpha muté par
-- le fade des lettres de direction -> ne pas les réutiliser).
local TRAIN_TXT_COL    = Color(255, 255, 255, 235)
local TRAIN_TXT_SHADOW = Color(0, 0, 0, 200)
local TRAIN_ACCENT     = Color(207, 68, 78, 210)  -- accent DA #cf444e
local TRAIN_KANJI_COL  = Color(207, 68, 78, 60)
local TRAIN_KANJI_SHDW = Color(0, 0, 0, 80)

-- ── TERRITOIRE ENNEMI (demande user 2026-08-02) : « RPK CONSTANT DANS CETTE ZONE »
-- sous la boussole pour un Shinigami dans Las Noches / un Hollow dans le Seireitei.
-- Volumes AABB par map ; home = la faction chez elle (jamais de RPK pour elle).
local RPK_TXT        = "RPK CONSTANT DANS CETTE ZONE"
local RPK_TXT_COL    = Color(235, 80, 90, 245)
local RPK_TXT_SHADOW = Color(0, 0, 0, 210)
local ENEMY_TERRITORY = {
    ["hueco_mundo_v1"] = {
        home = "Hollow",
        -- LAS NOCHES = le complexe SURÉLEVÉ (parvis z≈5380, quartiers des Ordres
        -- z≈6340-6400) ; le désert (z≈130) reste Hueco Mundo, sans RPK.
        -- Plafond 8000 (08/03) : la ZONE NEUTRE II flotte à z≈8900-9700 (Croisée,
        -- Dunes — cf. drapeaux flagcapture) et tombait dans l'ancien plafond 10000.
        zones = { { mins = Vector(-16000, -11000, 4200), maxs = Vector(8000, 9000, 8000) } },
    },
    ["rp_seireitei_v1"] = {
        home = "Shinigami",
        -- SEIREITEI = toute la zone principale (intérieurs hauts compris) ; les abords
        -- « HORS DU SEIREITEI » (arrivée Garganta, z≈-15000) restent sans RPK.
        -- Plancher -2500 (08/03) : la ville est à z≥-300 (zones ncm_entrainement) mais la
        -- ZONE NEUTRE II est à l'étage z≈-5800..-7300 et tombait dans l'ancien plancher -10000.
        zones = { { mins = Vector(-30000, -30000, -2500), maxs = Vector(30000, 30000, 17000) } },
    },
}
local _rpkCheckAt, _rpkInZone = 0, false
local function localInEnemyTerritory()
    local now = CurTime()
    if now < _rpkCheckAt then return _rpkInZone end
    _rpkCheckAt = now + 0.25
    _rpkInZone = false
    local t = ENEMY_TERRITORY[game.GetMap()]
    local lp = LocalPlayer()
    if not (t and IsValid(lp) and lp:Alive()) then return false end
    local fac = lp:GetEvoNWString("FactionName", "")
    if fac == "" or fac == t.home or (fac ~= "Shinigami" and fac ~= "Hollow") then return false end
    local p = lp:GetPos()
    for i = 1, #t.zones do
        local z = t.zones[i]
        if p:WithinAABox(z.mins, z.maxs) then _rpkInZone = true break end
    end
    return _rpkInZone
end
-- Lettres cardinales : Nord en accent DA #cf444e (repère naturel), primaires E/S/O en
-- blanc, inter-cardinales (NE/SE/SO/NO) atténuées -> hiérarchie de lecture. Couleurs
-- DÉDIÉES : leur .a est muté par le fondu des lettres, ne pas réutiliser les 2 ci-dessus.
local color_dir_north = Color(207, 68, 78, 255)
local color_dir_sub   = Color(198, 203, 210, 255)
local color_grad15 = Color(230, 230, 230, 220)
local color_grad5 = Color(180, 180, 180, 190)
local color_marker = Color(255, 100, 100, 255)
local color_shadow_marker = Color(0, 0, 0, 153)

-- Pre-allocated polygon tables (reused each frame, mutated in-place)
local vShape = { {x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0} }
local markerShape = { {x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0} }
local shadowShape = { {x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0} }
local headMarkerShape = { {x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0} }
local headShadowShape = { {x = 0, y = 0}, {x = 0, y = 0}, {x = 0, y = 0} }

-- Pre-allocated vector for head offset (reused)
local _headOffset = Vector(0, 0, 0)

-- Table to store compass markers (indexed by uniqueID)
-- Structure: compassMarkers[uniqueID] = {entity = entity, position = Vector}
local compassMarkers = {}

-- Network receiver for marker positions from server
net.Receive("LZY:client:UpdateCompassMarkers", function()
    local markersData = net.ReadTable()

    -- Update positions from server
    for uniqueID, position in pairs(markersData) do
        local unique_id_str = tostring(uniqueID)
        if compassMarkers[unique_id_str] and IsValid(compassMarkers[unique_id_str].entity) then
            compassMarkers[unique_id_str].position = position
        end
    end
end)

-- Function to add a marker to the compass
function AddCompassMarker(entity)
    if not IsValid(entity) then
        return false
    end

    local uniqueID = entity:GetUniqueID()
    local unique_id_str = tostring(uniqueID)
    if not uniqueID or unique_id_str == "none" then
        return false
    end

    compassMarkers[unique_id_str] = {
        entity = entity,
        position = entity:GetPos()
    }

    -- Request server to track this marker
	net.Start("LZY:server:AddCompassMarker")
	net.WriteEntity(entity)
	net.SendToServer()

    return true
end

-- Function to remove a marker from the compass
function RemoveCompassMarker(uniqueID)
    if not uniqueID or uniqueID == "none" then
        return false
    end

    local unique_id_str = tostring(uniqueID)
    if unique_id_str ~= "none" and compassMarkers[unique_id_str] then
        local marker = compassMarkers[unique_id_str]
        local ent = marker and marker.entity
        compassMarkers[unique_id_str] = nil

        -- Request server to stop tracking this marker
        if IsValid(ent) then
			net.Start("LZY:server:RemoveCompassMarker")
			net.WriteEntity(ent)
			net.SendToServer()
        end

        return true
    end
    return false
end

-- Le joueur local est-il sur un TERRAIN D'ENTRAÎNEMENT ? Check AABB des zones PARTAGÉES
-- (NCM_ENTRAINEMENT.Zones, sh_config). Throttlé 0.25s -> pas d'itération des zones à chaque frame.
local _trainCheckAt, _trainInZone = 0, false
local function localInTrainingZone()
    local now = CurTime()
    if now < _trainCheckAt then return _trainInZone end
    _trainCheckAt = now + 0.25
    _trainInZone = false
    local zones = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[game.GetMap()]
    local lp = LocalPlayer()
    if not (istable(zones) and IsValid(lp) and lp:Alive()) then return false end
    local p = lp:GetPos()
    for i = 1, #zones do
        local z = zones[i]
        -- Helper partagé (sh_config) : plafond borné au sol réel, pas les étages.
        if NCM_ENTRAINEMENT.PosDansZone and NCM_ENTRAINEMENT.PosDansZone(p, z) then
            _trainInZone = true
            break
        end
    end
    return _trainInZone
end

-- Pixel Y sous les libellés de zone (terrain d'entraînement / RPK). 0 si aucun.
-- Même géométrie que le bloc HUDPaint plus bas — les annonces faction s'y calent
-- pour ne plus passer derrière « TERRAIN D'ENTRAÎNEMENT ».
function BleachCompass_ZoneLabelsBottomY()
    local train = localInTrainingZone()
    local rpk = localInEnemyTerritory()
    if not train and not rpk then return 0 end

    local scrH = ScrH()
    local ty = scrH * 0.04 + 2 + scrH * 0.02
    local bottom = 0
    if train then
        local txtH = _trainTxtH or math.Round(scrH * 0.034)
        local kanjiH = math.Round(scrH * 0.062)
        bottom = math.max(ty + txtH + 5, ty + txtH * 0.5 + kanjiH * 0.5)
        ty = ty + txtH + scrH * 0.012
    end
    if rpk then
        local txtH = _rpkTxtH or math.Round(scrH * 0.034)
        bottom = math.max(bottom, ty + txtH + 5)
    end
    return bottom
end

-- Single merged HUDPaint hook for compass + 3D markers
hook.Add("HUDPaint", "BleachStylizedCompass", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if ply:GetEvoNWBool("InCharacterMenu", false) then return end -- hub / sélection / créateur de perso : pas de boussole ni marqueur de quête

    local scrW, scrH = ScrW(), ScrH()
    local centerX = scrW / 2
    local posY = scrH * 0.04
    local scale = scrW * 0.0038
    -- Cap de la boussole : en CAMÉRA ORBITALE, l'aim/EyeAngles du perso est GELÉ
    -- (cf. citron_orbit_camera). On lit donc l'angle RÉEL de la caméra via GetView()
    -- pour que la boussole tourne avec l'orbite ; sinon EyeAngles (vue normale).
    local yaw = ply:EyeAngles().y
    if CitronOrbitCam and CitronOrbitCam.GetView then
        local _, oang = CitronOrbitCam.GetView()
        if oang then yaw = oang.y end
    end
    yaw = yaw % 360
    local time = CurTime()

    local barWidth = scrW * 0.4
    local barStart = centerX - (barWidth / 2)
    local barEnd = barStart + barWidth
    local barHeight = 2
    local halfBarWidth = barWidth / 2
    local shift = math_sin(time * 0.5 + yaw * math.pi / 180) * 5

    -- Dégradé blanc -> noir à gauche
    surface_SetMaterial(matGradientR)
    surface_SetDrawColor(255, 255, 255, 255)
    surface_DrawTexturedRect(barStart + shift, posY, halfBarWidth, barHeight)

    -- Dégradé blanc -> noir à droite
    surface_SetMaterial(matGradientL)
    surface_SetDrawColor(255, 255, 255, 255)
    surface_DrawTexturedRect(centerX + shift, posY, halfBarWidth, barHeight)

    -- Encoche pour le V inversé
    surface_SetDrawColor(0, 0, 0, 0)
    surface_DrawRect(centerX - 6, posY - 1, 12, barHeight + 2)

    -- « TERRAIN D'ENTRAÎNEMENT » centré SOUS la boussole quand le joueur local est dans une zone
    -- d'entraînement (demande user 2026-07-22). Style DA : kanji 闘 gravé derrière
    -- (motif #platekanji), titre Bebas Neue, filet accent sous le texte.
    if localInTrainingZone() then
        local ty = posY + barHeight + scrH * 0.02
        if not _trainTxtW then
            surface.SetFont("BleachTrainingZone")
            _trainTxtW, _trainTxtH = surface.GetTextSize("TERRAIN D'ENTRAÎNEMENT")
        end
        local midY = ty + _trainTxtH * 0.5
        draw_SimpleText("闘", "BleachTrainingKanji", centerX + 2, midY + 2, TRAIN_KANJI_SHDW, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw_SimpleText("闘", "BleachTrainingKanji", centerX, midY, TRAIN_KANJI_COL, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw_SimpleText("TERRAIN D'ENTRAÎNEMENT", "BleachTrainingZone", centerX + 2, ty + 2, TRAIN_TXT_SHADOW, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw_SimpleText("TERRAIN D'ENTRAÎNEMENT", "BleachTrainingZone", centerX, ty, TRAIN_TXT_COL, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        surface_SetDrawColor(TRAIN_ACCENT.r, TRAIN_ACCENT.g, TRAIN_ACCENT.b, TRAIN_ACCENT.a)
        surface_DrawRect(centerX - _trainTxtW * 0.5, ty + _trainTxtH + 3, _trainTxtW, 2)
    end

    -- « RPK CONSTANT DANS CETTE ZONE » : faction ADVERSE en territoire ennemi
    -- (Shinigami dans Las Noches / Hollow dans le Seireitei). Même style que le
    -- libellé d'entraînement, empilé dessous si les deux s'affichent.
    if localInEnemyTerritory() then
        local ty = posY + barHeight + scrH * 0.02
        if localInTrainingZone() then
            ty = ty + (_trainTxtH or 0) + scrH * 0.012
        end
        if not _rpkTxtW then
            surface.SetFont("BleachTrainingZone")
            _rpkTxtW, _rpkTxtH = surface.GetTextSize(RPK_TXT)
        end
        draw_SimpleText(RPK_TXT, "BleachTrainingZone", centerX + 2, ty + 2, RPK_TXT_SHADOW, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw_SimpleText(RPK_TXT, "BleachTrainingZone", centerX, ty, RPK_TXT_COL, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        surface_SetDrawColor(TRAIN_ACCENT.r, TRAIN_ACCENT.g, TRAIN_ACCENT.b, TRAIN_ACCENT.a)
        surface_DrawRect(centerX - _rpkTxtW * 0.5, ty + _rpkTxtH + 3, _rpkTxtW, 2)
    end

    -- Effet de pulsation du V inversé
    local pulse = 1.0 + math_sin(time * 4) * 0.1
    local alphaPulse = 180 + math_sin(time * 4) * 40
    local vSize = 8

    -- V inversé (pointe vers le haut) — reuse pre-allocated table
    surface_SetDrawColor(255, 255, 255, alphaPulse)
    vShape[1].x = centerX - vSize * pulse; vShape[1].y = posY
    vShape[2].x = centerX;                 vShape[2].y = posY - vSize * pulse
    vShape[3].x = centerX + vSize * pulse; vShape[3].y = posY
    surface_DrawPoly(vShape)

    local lastDirX = nil
    local minSpacing = 40

    -- Graduation + Directions cardinales
    -- OPTIM FPS : seuls les ticks dans la fenêtre visible (|diff| <= demi-barre/scale)
    -- sont dessinés ; inutile de boucler les 72 ticks (0→360). On restreint la boucle
    -- à yaw ± fenêtre (+ marge), ang normalisé %360. Le test x in [barStart,barEnd]
    -- reste la vérité du dessin → visuel identique, ~3× moins d'itérations.
    local maxDiff = halfBarWidth / scale + 10
    local angLo = math.floor((yaw - maxDiff) / 5) * 5
    local angHi = math.ceil((yaw + maxDiff) / 5) * 5

    for a = angLo, angHi, 5 do
        local ang = a % 360
        local diff = math_AngleDifference(yaw, ang)
        local x = centerX - diff * scale

        if x >= barStart and x <= barEnd then
            if ang % 45 == 0 then
                if not lastDirX or math_abs(x - lastDirX) > minSpacing then
                    if directions[ang] then
                        local dir = directions[ang]
                        local fadeAlpha = 220 * math_Clamp(1 - (math_abs(centerX - x) / halfBarWidth), 0, 1)

                        color_shadow_text.a = fadeAlpha * 0.8
                        draw_SimpleText(dir, "BleachCompassDir", x + 1, posY - 13, color_shadow_text, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)

                        -- Nord en accent rouge, primaires E/S/O en blanc, inter-cardinales atténuées.
                        local col
                        if ang == 0 then col = color_dir_north
                        elseif ang % 90 == 0 then col = color_white_text
                        else col = color_dir_sub end
                        col.a = fadeAlpha
                        draw_SimpleText(dir, "BleachCompassDir", x, posY - 14, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)

                        -- Trait sous la lettre, teinté comme elle (filet rouge sous le Nord).
                        surface_SetDrawColor(col.r, col.g, col.b, fadeAlpha)
                        surface_DrawRect(x - 1, posY - 12, 2, 12)
                    end
                    lastDirX = x
                end
            else
                local gradHeight, gradColor
                if ang % 15 == 0 then
                    gradHeight = 8
                    gradColor = color_grad15
                else
                    gradHeight = 4
                    gradColor = color_grad5
                end
                surface_SetDrawColor(0, 0, 0, gradColor.a * 0.6)
                surface_DrawRect(x + 1, posY - gradHeight, 1, gradHeight)
                surface_SetDrawColor(gradColor.r, gradColor.g, gradColor.b, gradColor.a)
                surface_DrawRect(x - 0.5, posY - gradHeight, 1, gradHeight)
            end
        end
    end

    -- Draw compass markers + 3D head markers (merged loop)
    local plyPos = ply:GetPos()

    for uniqueID, markerData in pairs(compassMarkers) do
        if not IsValid(markerData.entity) then
            compassMarkers[uniqueID] = nil
        else
            local entityPos = markerData.position
            local dirToEntity = (entityPos - plyPos)

            local angleToEntity = dirToEntity:Angle().y
            if angleToEntity < 0 then
                angleToEntity = angleToEntity + 360
            end

            local diff = math_AngleDifference(yaw, angleToEntity)
            local x = centerX - diff * scale

            -- Compass bar marker
            if x >= barStart and x <= barEnd then
                local fadeAlpha = 255 * math_Clamp(1 - (math_abs(centerX - x) / halfBarWidth), 0, 1)
                local markerSize = 6

                -- Shadow — reuse pre-allocated table
                shadowShape[1].x = x - markerSize + 1; shadowShape[1].y = posY + 1
                shadowShape[2].x = x + 1;              shadowShape[2].y = posY - markerSize * 1.5 + 1
                shadowShape[3].x = x + markerSize + 1;  shadowShape[3].y = posY + 1
                surface_SetDrawColor(0, 0, 0, fadeAlpha * 0.6)
                surface_DrawPoly(shadowShape)

                -- Main marker — reuse pre-allocated table
                markerShape[1].x = x - markerSize; markerShape[1].y = posY
                markerShape[2].x = x;              markerShape[2].y = posY - markerSize * 1.5
                markerShape[3].x = x + markerSize;  markerShape[3].y = posY
                surface_SetDrawColor(255, 100, 100, fadeAlpha)
                surface_DrawPoly(markerShape)
            end

            -- 3D head marker
            local distSq = dirToEntity:LengthSqr()
            if distSq <= headMarkerRangeSq then
                local entity = markerData.entity
                local zOffset
                if entity:IsPlayer() or entity:IsNPC() then
                    local mins, maxs = entity:GetModelBounds()
                    zOffset = maxs and (maxs.z + 60) or 110
                else
                    local mins, maxs = entity:GetCollisionBounds()
                    zOffset = maxs and (maxs.z + 20) or 50
                end

                _headOffset.z = zOffset
                local headPos = entityPos + _headOffset
                _headOffset.z = 0

                local screenPos = headPos:ToScreen()

                if screenPos and screenPos.visible then
                    local distance = math.sqrt(distSq)
                    local mSize = math_Clamp(20 - (distance / 100), 10, 20)
                    local alpha = math_Clamp(255 - (distance / 1000 * 255), 100, 255)

                    -- Shadow — reuse pre-allocated table
                    headShadowShape[1].x = screenPos.x - mSize + 1; headShadowShape[1].y = screenPos.y + 1
                    headShadowShape[2].x = screenPos.x + 1;          headShadowShape[2].y = screenPos.y - mSize * 1.5 + 1
                    headShadowShape[3].x = screenPos.x + mSize + 1;  headShadowShape[3].y = screenPos.y + 1
                    surface_SetDrawColor(0, 0, 0, alpha * 0.6)
                    surface_DrawPoly(headShadowShape)

                    -- Main marker — reuse pre-allocated table
                    headMarkerShape[1].x = screenPos.x - mSize; headMarkerShape[1].y = screenPos.y
                    headMarkerShape[2].x = screenPos.x;          headMarkerShape[2].y = screenPos.y - mSize * 1.5
                    headMarkerShape[3].x = screenPos.x + mSize;  headMarkerShape[3].y = screenPos.y
                    surface_SetDrawColor(255, 100, 100, alpha)
                    surface_DrawPoly(headMarkerShape)
                end
            end
        end
    end

    -- POINT DE QUÊTE actif (système ncm_quete) : affiché sur la boussole EN PLUS de la
    -- map de base, repère DORÉ pour le distinguer des marqueurs rouges (entités). On lit
    -- la position du waypoint exposée par cl_quete (NCM_Quete_GetWaypoint), ou rien.
    if NCM_Quete_GetWaypoint then
        local wpPos = NCM_Quete_GetWaypoint()
        if wpPos then
            local dir = wpPos - plyPos
            local angTo = dir:Angle().y
            if angTo < 0 then angTo = angTo + 360 end
            local diff = math_AngleDifference(yaw, angTo)
            local x = centerX - diff * scale
            if x >= barStart and x <= barEnd then
                local fadeAlpha = 255 * math_Clamp(1 - (math_abs(centerX - x) / halfBarWidth), 0, 1)
                local mSize = 7 -- un poil plus gros que les marqueurs d'entité (6)
                -- Ombre (réutilise les tables pré-allouées : la boucle d'entités est finie).
                shadowShape[1].x = x - mSize + 1; shadowShape[1].y = posY + 1
                shadowShape[2].x = x + 1;          shadowShape[2].y = posY - mSize * 1.6 + 1
                shadowShape[3].x = x + mSize + 1;  shadowShape[3].y = posY + 1
                surface_SetDrawColor(0, 0, 0, fadeAlpha * 0.6)
                surface_DrawPoly(shadowShape)
                -- Triangle DORÉ = point de quête.
                markerShape[1].x = x - mSize; markerShape[1].y = posY
                markerShape[2].x = x;          markerShape[2].y = posY - mSize * 1.6
                markerShape[3].x = x + mSize;  markerShape[3].y = posY
                surface_SetDrawColor(255, 205, 90, fadeAlpha)
                surface_DrawPoly(markerShape)
            end
        end
    end
end)
