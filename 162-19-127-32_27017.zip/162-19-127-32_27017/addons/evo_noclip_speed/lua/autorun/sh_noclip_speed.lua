-- "addons\\evo_noclip_speed\\lua\\autorun\\sh_noclip_speed.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — NOCLIP (legacy addon folder)
-- CTRL=descendre est géré par le gamemode :
--   mangarp/.../holdtypes/sh_holdtypes.lua → Move "EVO::Noclip::Override"
-- (le noclip GMod vanilla mappe CTRL→ralentir ; l'override le remplace)
-- ============================================================================

-- Nettoie UNIQUEMENT l'ancien CTRL=slow de cet addon (ne pas toucher au hook gamemode).
hook.Remove("SetupMove", "EVO::Noclip::CtrlSlow")
hook.Remove("SetupMove", "EVO::Noclip::ShiftSlow")
