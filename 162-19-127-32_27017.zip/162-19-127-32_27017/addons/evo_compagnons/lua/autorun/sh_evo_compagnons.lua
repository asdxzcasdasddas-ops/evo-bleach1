-- "addons\\evo_compagnons\\lua\\autorun\\sh_evo_compagnons.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- COMPAGNONS, partagé (10/08) : NOM du compagnon + PNJ « Dresseur ».
-- Premier nom GRATUIT (proposé à l'équipement d'un compagnon jamais nommé), ensuite le
-- Dresseur le change contre CoutCoins OU CoutYens (au choix, une seule monnaie débitée).
-- Nom par PERSONNAGE et par compagnon (table evo_compagnon_noms), affiché au-dessus de lui.
-- ============================================================================
EVO_COMP = EVO_COMP or {}
local C = EVO_COMP.Dresseur or {}
EVO_COMP.Dresseur = C

C.NPCName  = "Dresseur"
C.NPCModel = "models/player/group01/male_07.mdl" -- à remplacer par un modèle de PNJ du serveur
C.CoutCoins = 300
C.CoutYens  = 30000
C.InteractDistance = 200
C.PromptDistance = 160
C.MaxZDelta = 200
-- Positions par map ({ pos = Vector(...), ang = Angle(...) }) : se règlent aussi en jeu avec
-- l'éditeur de positions (evo_config_positions, entrée « PNJ Dresseur »).
C.SpawnPositions = C.SpawnPositions or {}

-- Perso animation : gratuit (même règle que le Scribe, NWBool posé serveur, non falsifiable).
function C.Prix(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0, 0 end
	return C.CoutCoins, C.CoutYens
end

-- Nom valide ? 2 à 20 caractères, lettres (accents compris), chiffres, espace, apostrophe,
-- tiret ; pas de soulignement ni de symbole. Renvoie le nom nettoyé ou nil + raison.
function EVO_COMP.NomNettoye(s)
	s = string.Trim(string.gsub(tostring(s or ""), "%s+", " "))
	local n = utf8.len(s) or 99
	if n < 2 or n > 20 then return nil, "Le nom doit faire entre 2 et 20 caractères." end
	if string.find(s, "[%c_%%%[%]%(%){}<>\"\\/|;:=+*&^$#@!?~`]") then
		return nil, "Lettres, chiffres, espaces, apostrophes et tirets seulement."
	end
	if EVO_WordFilter and EVO_WordFilter.Contains and EVO_WordFilter.Contains(s) then
		return nil, "Ce nom n'est pas autorisé."
	end
	return s
end
