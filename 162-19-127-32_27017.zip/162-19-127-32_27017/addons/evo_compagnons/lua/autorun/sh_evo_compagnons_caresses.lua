-- "addons\\evo_compagnons\\lua\\autorun\\sh_evo_compagnons_caresses.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- GÉNÉRÉ par le pack POUR_LE_DEV/CARESSES_JOUEUR (10/08) : ne pas éditer à la main.
-- Par compagnon : sit = durée de sit_down (pet_start suit, 0,8 s), stand = durée de stand_up
-- (après pet_end, 0,8 s) ; cote = propriétaire à côté (même yaw, compagnon en (x, y) dans le
-- repère du joueur) ; face = visiteur tourné vers l'animal (compagnon à d devant lui, yaw +180).
-- s / l / e = séquences JOUEUR entrée / boucle (3,2 s) / sortie (anim_extension_nmrih).
EVO_COMP = EVO_COMP or {}
EVO_COMP.Caresses = {
	["rabbit"] = { sit = 1.2, stand = 1.2,
		cote = { x = 4.839, y = -15.743, s = "evo_kwy1zaoo02i3cgcd", l = "evo_wpa1gkknr4fj966h", e = "evo_0uwzf7py6uurorvs" },
		face = { d = 26.661, s = "evo_nzqpt1sromiiptez", l = "evo_esncjfc7k7edey62", e = "evo_qkqt24z847u80880" } },
	["hayate"] = { sit = 1.2, stand = 1.2,
		cote = { x = -5.384, y = -17.292, s = "evo_h8n2uoqyrpoeault", l = "evo_hihxdle49zlbdtki", e = "evo_se8jpi5zjepdn6y4" },
		face = { d = 36.884, s = "evo_ppqbp76kirqtxqpl", l = "evo_jodq5krm98pi9ccd", e = "evo_6bjuk7fg6htnflno" } },
	["divine_white"] = { sit = 1.2, stand = 1.2,
		cote = { x = -29.25, y = -22, s = "evo_qeyv7yz52i4seht6", l = "evo_25vpgjpyd5w2xwzl", e = "evo_joppjszjn32btur6" },
		face = { d = 60.75, s = "evo_5qpw3ww59phbxj6c", l = "evo_4axbzz96uze83lvw", e = "evo_vb4gn5tqqmgqbm2v" } },
	["divine_black"] = { sit = 1.2, stand = 1.2,
		cote = { x = -29.255, y = -22, s = "evo_uckqn6qw0uhq8505", l = "evo_b5gn54zyn1e1cxxb", e = "evo_uvgwxltxz9lu5r18" },
		face = { d = 60.755, s = "evo_wormnj14nb2pvk6t", l = "evo_sju3sa9vptst1a0w", e = "evo_5hir1wrqfpjwef7j" } },
	["yoruichi_chat"] = { sit = 1.2, stand = 1.2,
		cote = { x = -7.056, y = -17.273, s = "evo_9d2cg4g3bo2co2h5", l = "evo_ko427hng7fy32qzq", e = "evo_a6z9aoct4kp2irux" },
		face = { d = 38.556, s = "evo_zexi64h6391lwxsb", l = "evo_j0y86j1zx6b0rhxg", e = "evo_za67rzuvkrzamtlo" } },
	["panthere_spirituelle"] = { sit = 1.6, stand = 1.6,
		cote = { x = -23.372, y = -22, s = "evo_k83hddyxjautbtjj", l = "evo_k978uj3u7aev7z01", e = "evo_3l5uu9i293m20t4h" },
		face = { d = 54.872, s = "evo_kq1koscgqwjkwegi", l = "evo_vxzjqel0fuhzndq0", e = "evo_anz46fb45m839dqu" } },
	["renard_roux"] = { sit = 1.2, stand = 1.2,
		cote = { x = 0.534, y = -16.352, s = "evo_zg5b281obrcr91tg", l = "evo_t35z6bjl3e7a82et", e = "evo_jd3o0g5k4hg1xs64" },
		face = { d = 30.966, s = "evo_c05t6smunnjkotx7", l = "evo_pn42odxx84zaa7pz", e = "evo_cqz8ut6klyskud0w" } },
	["chien_cartoon"] = { sit = 1.2, stand = 1.2,
		cote = { x = 7.896, y = -22, s = "evo_ivgn5fna9sqbxas2", l = "evo_mfg6cgz8ox8dlu6p", e = "evo_f8ycid20uxunw6fm" },
		face = { d = 23.604, s = "evo_h9ha0b9ki7gf033v", l = "evo_zb8fd9jfqmcpk5qf", e = "evo_vtgh96n5tvmzasdf" } },
	["chat_cartoon"] = { sit = 1.2, stand = 1.2,
		cote = { x = 7.515, y = -20.1, s = "evo_zk7yu8tduyhzx7jz", l = "evo_uid2t8t1spjbq8vp", e = "evo_00nm63q4ozrxpvef" },
		face = { d = 23.985, s = "evo_q17tk9vzvf81kh5t", l = "evo_8hgg27ay58m0jr7z", e = "evo_8of5wg2zrr6onk5z" } },
	["bond"] = { sit = 1.6, stand = 1.6,
		cote = { x = -6.947, y = -21.293, s = "evo_slb2cvm1y5ke69tj", l = "evo_e7conwwjl63g7by6", e = "evo_3e2h8aily0s1m7ta" },
		face = { d = 38.447, s = "evo_h8tdlvavuwhtzqap", l = "evo_ka7zql5wf4xgfkb3", e = "evo_r0dl1rjd9lgm546z" } },
	["chien_brun"] = { sit = 1.2, stand = 1.2,
		cote = { x = 5.84, y = -16.435, s = "evo_ji5jl6d2g12b75rg", l = "evo_s0f8la379whnqz07", e = "evo_gi7vbbzv6cmb1rxt" },
		face = { d = 25.66, s = "evo_yq6zkzy7s9rmt3s6", l = "evo_rovooe7esrtdzjwv", e = "evo_wd6ypfw6n964tvyn" } },
	["chien_blanc"] = { sit = 1.2, stand = 1.2,
		cote = { x = 5.84, y = -16.435, s = "evo_32n71fk6pfprn8dr", l = "evo_ark3rnzprlxbsm7y", e = "evo_6lkul2lj7m58lmub" },
		face = { d = 25.66, s = "evo_5otnjxytdqpbanuq", l = "evo_3nv3p7k14csa0wdj", e = "evo_ciguyjmd6x8912d0" } },
}
EVO_COMP.CaressePetStart = 0.8 -- pet_start
EVO_COMP.CaressePetEnd = 0.8   -- pet_end
EVO_COMP.CaresseBoucle = 3.2   -- pet_loop / boucle joueur

-- Ajout MANUEL 10/10 : pack 3 sans données de caresse, gabarit le plus proche en attendant.
for sId, sRef in pairs({ chien_ninja_a = "chien_brun", chien_ninja_s = "chien_brun", chien_ninja_ss = "chien_brun", mic_jaguar = "panthere_spirituelle" }) do
	EVO_COMP.Caresses[sId] = EVO_COMP.Caresses[sId] or EVO_COMP.Caresses[sRef]
end
