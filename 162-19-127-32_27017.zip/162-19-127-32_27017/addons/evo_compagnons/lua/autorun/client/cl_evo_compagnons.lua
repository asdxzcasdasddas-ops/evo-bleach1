-- "addons\\evo_compagnons\\lua\\autorun\\client\\cl_evo_compagnons.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- COMPAGNONS (10/06) : animal qui SUIT son joueur au sol. Équipé dans la case 9 de
-- l'inventaire -> NW EVO_Compagnon = id d'item (sv lzy_character, œil fermé = ""). 100 %
-- CLIENT : chaque client proche simule le compagnon (ClientsideModel, aucune entité ni
-- réseau en plus ; un écart d'un client à l'autre n'a aucune importance visuelle).
-- Modèles du pack COMPAGNONS_GMOD_ET_DEV : locomotion SUR PLACE (le contrôleur déplace,
-- oriente et règle la vitesse de lecture), axe avant +X. Repos : idle -> sit_down ->
-- sit_idle -> stand_up ; spawn / despawn à l'apparition et au rappel.
-- ============================================================================
local EVO_COMP = EVO_COMP or {}
_G.EVO_COMP = EVO_COMP
EVO_COMP.tActifs = EVO_COMP.tActifs or {} -- survit au rechargement à chaud
local tActifs = EVO_COMP.tActifs           -- [ply] = état

local CFG = {
	Dist      = 2500,  -- au-delà, pas de compagnon (simulation coupée)
	Recul     = 55,    -- place visée : derrière le joueur...
	Cote      = 45,    -- ...et à sa droite
	Arret     = 22,    -- assez près : il s'arrête
	Marche    = 70,    -- au-delà il marche
	Trot      = 140,   -- puis trotte
	Course    = 260,   -- puis court
	Teleport  = 700,   -- trop loin (flashstep, TP) : réapparaît près du joueur
	Etage     = 300,   -- écart de hauteur (joueur au sol) = autre étage : réapparition
	Vitesses  = { walk = 80, trot = 170, run = 330 }, -- unités/s (rythme de base des anims)
	Rotation  = 300,   -- degrés/s
	Assis     = 9,     -- s immobile (lui ET le joueur) avant de s'asseoir
	Emote     = { 14, 28 }, -- s entre deux regards / emotes au repos
	SolTrace  = 0.1,   -- s entre deux traces de sol
	-- Pivots (10/08, animateur) : à l'arrêt, au-delà de PivotDebut degrés il pivote sur place
	-- (pivot_left / pivot_right) jusqu'à moins de PivotFin ; en marche, au-delà de VirageMarche
	-- il joue turn_left / turn_right ; un demi-tour (GrandVirage) au départ = pivot d'abord.
	PivotDebut   = 35,
	PivotFin     = 8,
	PivotVitesse = 70,  -- degrés/s (lecture = PivotVitesse / référence du modèle, ~34,7°/s)
	VirageMarche = 25,
	GrandVirage  = 100,
	Echelle   = 1,     -- taille des modèles (le pack est à l'échelle : lapin ~33 u, chiens ~57 u)
}
EVO_COMP.CFG = CFG

local tSeq = {} -- [modèle][nom] = index (ou -1)
local function seq(e, sName)
	local sMdl = e:GetModel()
	local t = tSeq[sMdl]
	if not t then t = {} tSeq[sMdl] = t end
	local n = t[sName]
	if n == nil then
		n = e:LookupSequence(sName) or -1
		-- Nom exact absent (export « Rabbit_Walk », « walk_loop »...) : 1re séquence qui le contient.
		if n < 0 then
			for i, sSeq in pairs(e:GetSequenceList() or {}) do
				if string.find(string.lower(sSeq), sName, 1, true) then n = i break end
			end
		end
		t[sName] = n
	end
	return n
end

-- Animation pilotée À LA MAIN (cycle avancé par le code, pas FrameAdvance) : la marche ne
-- se voyait pas sur ces modèles clients (10/07, user : « il doit faire les animations de marche »).
local BOUCLE = { idle = true, walk = true, trot = true, run = true, sit_idle = true,
	pivot_left = true, pivot_right = true, turn_left = true, turn_right = true, pet_loop = true }

-- Joue sName (une fois ou en boucle) ; rien à faire si c'est déjà celle-là. Sans séquence
-- (modèle absent / ERROR) : anim = nil, que `finie` traite comme terminée (pas de blocage).
local function jouer(st, sName, nRate)
	local e = st.ent
	local n = seq(e, sName)
	if n < 0 then n = seq(e, "idle") sName = "idle" end
	if n < 0 then st.anim = nil return end
	st.rate = nRate or 1
	if st.anim ~= sName then
		st.anim, st.boucle, st.cyc = sName, BOUCLE[sName] == true, 0
		local d = e:SequenceDuration(n)
		st.dur = (d and d > 0.01) and d or 1
		e:ResetSequence(n)
		e:SetCycle(0)
		e:SetPlaybackRate(0)
	end
end

local function finie(st) return st.anim == nil or (not st.boucle and st.cyc >= 0.98) end

local vHaut, vBas = Vector(0, 0, 60), Vector(0, 0, 4096)
local function sol(x, y, z)
	local v = Vector(x, y, z)
	local tr = util.TraceLine({ start = v + vHaut, endpos = v - vBas, mask = MASK_SOLID_BRUSHONLY })
	return tr.Hit and tr.HitPos.z or z
end

-- Place visée (derrière, à droite du joueur) en nombres : pas de Vector/Angle par image.
local function placeVisee(ply)
	local p = ply:GetPos()
	-- Yaw du CORPS affiché (10/07, user) : GetAngles / EyeAngles suivent la caméra orbitale,
	-- le corps est orienté à part (vitesse, petit saut -> SetRenderAngles).
	local nYaw = ply:GetRenderAngles().y
	local r = math.rad(nYaw)
	local c, s = math.cos(r), math.sin(r)
	-- avant = (c, s), droite = (s, -c)
	return p.x - c * CFG.Recul + s * CFG.Cote, p.y - s * CFG.Recul - c * CFG.Cote, p.z, nYaw
end

-- Locomotions SUR PLACE dans le pack (fiche dev) : le code déplace et oriente, +X = avant.
local aTmp = Angle()
local function poser(st)
	st.ent:SetPos(st.pos)
	aTmp:SetUnpacked(0, st.yaw, 0)
	st.ent:SetAngles(aTmp)
end

local function animer(st, nDt)
	if st.anim then
		st.cyc = st.cyc + nDt * (st.rate or 1) / (st.dur or 1)
		st.cyc = st.boucle and st.cyc % 1 or math.min(st.cyc, 1)
		st.ent:SetCycle(st.cyc)
	end
	poser(st)
end

local function retirer(ply)
	local st = tActifs[ply]
	if st and IsValid(st.ent) then st.ent:Remove() end
	tActifs[ply] = nil
end
EVO_COMP.Retirer = retirer

local function creer(ply, sItem, it)
	-- Pack absent : rien plutôt qu'un ERROR. PAS util.IsValidModel : côté client il répond
	-- false pour un modèle que le serveur n'a pas préchargé (10/07, diagnostic user).
	if not file.Exists(it.model_path, "GAME") then return end
	local e = ClientsideModel(it.model_path, RENDERGROUP_OPAQUE)
	if not IsValid(e) then return end
	local x, y, z, nYaw = placeVisee(ply)
	if CFG.Echelle ~= 1 then e:SetModelScale(CFG.Echelle, 0) end
	local nSol = sol(x, y, z)
	local st = { ent = e, item = sItem, cid = it.compagnon_id, emote = it.compagnon_emote or "look", pos = Vector(x, y, nSol), yaw = nYaw,
		mode = "spawn", idleT = 0, nextEmote = CurTime() + math.Rand(CFG.Emote[1], CFG.Emote[2]),
		nextSol = 0, solZ = nSol }
	tActifs[ply] = st
	poser(st)
	jouer(st, "spawn")
	return st
end

-- Le joueur doit-il avoir un compagnon visible chez nous ? Même porte que l'arme tenue / les
-- gants (dormant, instance, invisibilité d'assassin, illusion, LOD, distance) : un compagnon
-- ne doit jamais trahir un joueur caché ni rester planté hors PVS.
local function voulu(ply, lp)
	if not ply:Alive() or ply:GetNoDraw() or ply:InVehicle() then return nil end
	if ply:GetEvoNWBool("InCharacterMenu", false) or ply:GetEvoNWBool("EVO_StaffMode", false) then return nil end
	-- 10/13 (user) : en vol (toggle fly) le compagnon repart, il revient à l'atterrissage.
	if ply:GetEvoNWBool("IsEvoFLying", false) then return nil end
	if ply ~= lp then
		if ply:IsDormant() then return nil end
		if LZY_Character_ShouldDrawOtherPlayer and not LZY_Character_ShouldDrawOtherPlayer(ply) then return nil end
		if ply:GetPos():DistToSqr(lp:GetPos()) > CFG.Dist * CFG.Dist then return nil end
	end
	if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(ply) then return nil end
	local sItem = ply:GetEvoNWString("EVO_Compagnon", "")
	local it = sItem ~= "" and ITEMS and ITEMS[sItem]
	if not (it and it.compagnon_id and isstring(it.model_path)) then return nil end
	return sItem, it
end

-- Repérage des joueurs (2 Hz) : création / rappel. La simulation, elle, tourne à chaque image.
timer.Create("EVO::Compagnons::Scan", 0.5, 0, function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	for _, ply in player.Iterator() do
		local sItem, it = voulu(ply, lp)
		local st = tActifs[ply]
		if sItem then
			if st and st.item ~= sItem then retirer(ply) st = nil end
			if not st then creer(ply, sItem, it)
			elseif st.mode == "despawn" then st.mode = "spawn" jouer(st, "spawn") end
		elseif st and st.mode ~= "despawn" then
			st.mode = "despawn" -- rappel / masqué : anim de départ puis retrait
			jouer(st, "despawn")
		end
	end
	for ply in pairs(tActifs) do
		if not IsValid(ply) then retirer(ply) end
	end
end)

local function approcheYaw(nCur, nCible, nDt)
	local d = math.AngleDifference(nCible, nCur)
	local m = CFG.Rotation * nDt
	return nCur + math.Clamp(d, -m, m)
end

-- ── CARESSE (10/08) : place et horloge fixées par le serveur (sv_evo_compagnons). Le
-- compagnon rejoint sa place, s'oriente, puis joue sit_down -> pet_start -> pet_loop (en
-- phase, cycle dérivé de l'heure commune) -> pet_end -> stand_up, puis reprend le suivi.
local function phaseCaresse(c, nNow)
	local def = c.def
	if c.tEnd then
		local t = nNow - c.tEnd
		if t < EVO_COMP.CaressePetEnd then return "pet_end", t / EVO_COMP.CaressePetEnd end
		t = t - EVO_COMP.CaressePetEnd
		if t < def.stand then return "stand_up", t / def.stand end
		return nil
	end
	local t = nNow - c.t0
	if t < def.sit then return c.assis and "sit_idle" or "sit_down", c.assis and (t / def.sit) % 1 or t / def.sit end
	t = t - def.sit
	if t < EVO_COMP.CaressePetStart then return "pet_start", t / EVO_COMP.CaressePetStart end
	t = t - EVO_COMP.CaressePetStart
	return "pet_loop", (t % EVO_COMP.CaresseBoucle) / EVO_COMP.CaresseBoucle
end

local function caresser(st, nDt, nNow)
	local c = st.caresse
	local sSeq, nCyc = phaseCaresse(c, nNow)
	if not sSeq then
		st.caresse, st.mode, st.loco, st.idleT = nil, "suivre", nil, 0
		jouer(st, "idle")
		return false
	end
	-- Rejoint sa place (vite, sans téléport visible) et s'aligne sur le yaw imposé.
	local dx, dy = c.pos.x - st.pos.x, c.pos.y - st.pos.y
	local nD = math.sqrt(dx * dx + dy * dy)
	if nD > 0.5 then
		local k = math.min(1, (CFG.Vitesses.run * nDt) / nD)
		st.pos:SetUnpacked(st.pos.x + dx * k, st.pos.y + dy * k, Lerp(math.min(1, nDt * 10), st.pos.z, c.pos.z))
	end
	st.yaw = approcheYaw(st.yaw, c.yaw, nDt * 2)
	jouer(st, sSeq, 1)
	st.cyc = math.Clamp(nCyc, 0, 1)
	st.ent:SetCycle(st.cyc)
	poser(st)
	return true
end

local nYawCaresse, nYawCaresseFin -- regard figé de celui qui caresse (sinon le corps pivote)
hook.Add("CreateMove", "EVO_COMP::Caresse::Regard", function(cmd)
	if not nYawCaresse then return end
	if CurTime() > nYawCaresseFin then nYawCaresse = nil return end
	local a = cmd:GetViewAngles()
	cmd:SetViewAngles(Angle(a.p, nYawCaresse, 0))
end)

net.Receive("EVO_COMP:Caresse", function()
	local owner, actor = net.ReadEntity(), net.ReadEntity()
	local nPhase, t0 = net.ReadUInt(2), net.ReadFloat()
	local lp = LocalPlayer()
	local st = IsValid(owner) and tActifs[owner]
	if nPhase == 1 then
		local bFace, vPos, nYawComp, nYawAct = net.ReadBool(), net.ReadVector(), net.ReadFloat(), net.ReadFloat()
		local it = ITEMS and ITEMS[owner:GetEvoNWString("EVO_Compagnon", "")]
		local def = it and it.compagnon_id and EVO_COMP.Caresses[it.compagnon_id]
		if actor == lp then nYawCaresse, nYawCaresseFin = nYawAct, CurTime() + 60 end
		if st and def then
			st.caresse = { def = def, t0 = t0, pos = vPos, yaw = nYawComp, assis = st.mode == "assis", actor = actor }
		end
	elseif nPhase == 2 then
		if st and st.caresse then st.caresse.tEnd = t0 end
		if actor == lp and nYawCaresse then
			local def = st and st.caresse and st.caresse.def
			nYawCaresseFin = CurTime() + EVO_COMP.CaressePetEnd + (def and def.stand or 1.6)
		end
	else
		if st and st.caresse then st.caresse, st.mode, st.loco = nil, "suivre", nil jouer(st, "idle") end
		if actor == lp then nYawCaresse = nil end
	end
end)

-- Rotation de référence des cycles pivot_left / pivot_right (INTERACTIONS_COMPAGNONS.json).
local PIVOT_REF = { bond = 21.7 }
-- Pivot sur place vers d (écart d'angle signé, + = à gauche). Renvoie false une fois aligné.
local function pivoter(st, d, nDt, nNow)
	if math.abs(d) <= CFG.PivotFin and nNow >= (st.pivotMin or 0) then return false end
	if st.mode ~= "pivot" then st.mode, st.pivotMin = "pivot", nNow + 0.15 end
	local m = CFG.PivotVitesse * nDt
	st.yaw = st.yaw + math.Clamp(d, -m, m)
	local sSeq = d > 0 and "pivot_left" or "pivot_right"
	if nNow < st.pivotMin and (st.anim == "pivot_left" or st.anim == "pivot_right") then sSeq = st.anim end -- pas de gauche/droite en rafale
	jouer(st, sSeq, math.Clamp(CFG.PivotVitesse / (PIVOT_REF[st.cid] or 34.7), 0.7, 2))
	return true
end

local function simuler(ply, st, nDt, nNow)
	local e = st.ent
	if st.caresse and st.mode ~= "despawn" and caresser(st, nDt, nNow) then return end
	if st.mode == "despawn" then
		animer(st, nDt)
		if finie(st) then retirer(ply) end
		return
	end

	local x, y, z, nYawJoueur = placeVisee(ply)
	local dx, dy = x - st.pos.x, y - st.pos.y
	local nDist = math.sqrt(dx * dx + dy * dy)
	local nVitJoueur = ply:GetVelocity():Length2D()

	-- Trop loin (flashstep, téléport) ou autre étage : réapparition près du joueur. En pleine
	-- course (run mode 750 u/s) pas d'anim d'apparition : elle immobiliserait le compagnon
	-- 1,2 s, le joueur serait de nouveau à plus de Teleport et il réapparaîtrait en boucle.
	if nDist > CFG.Teleport or (ply:IsOnGround() and math.abs(z - st.pos.z) > CFG.Etage) then
		local nSol = sol(x, y, z)
		st.pos:SetUnpacked(x, y, nSol)
		st.solZ, st.yaw = nSol, nYawJoueur
		if nVitJoueur < 100 then
			st.mode = "spawn"
			jouer(st, "spawn")
		else
			st.mode = "suivre"
		end
		poser(st)
		return
	end

	if st.mode == "spawn" then
		animer(st, nDt)
		if finie(st) then st.mode = "suivre" end
		return
	end

	local sLoco, nVit
	if nDist > CFG.Course or (nDist > CFG.Trot and nVitJoueur > 250) then
		sLoco, nVit = "run", math.max(CFG.Vitesses.run, nVitJoueur * 1.1)
	elseif nDist > CFG.Trot then
		sLoco, nVit = "trot", CFG.Vitesses.trot
	elseif nDist > CFG.Marche or (st.loco and nDist > CFG.Arret) then
		sLoco, nVit = "walk", CFG.Vitesses.walk
	end

	if sLoco then
		-- Debout d'abord s'il était assis.
		if st.mode == "assis" or st.mode == "assoit" then
			st.mode = "leve"
			jouer(st, "stand_up")
		end
		if st.mode == "leve" then
			animer(st, nDt)
			if finie(st) then st.mode = "suivre" end
			return
		end
		local nCible = math.deg(math.atan2(dy, dx))
		local dV = math.AngleDifference(nCible, st.yaw)
		if sLoco ~= "run" and (st.mode == "pivot" or (not st.loco and math.abs(dV) > CFG.GrandVirage))
			and pivoter(st, dV, nDt, nNow) then
			st.idleT = 0 -- demi-tour : il pivote sur place avant de partir
		else
			st.mode, st.loco, st.idleT = "suivre", sLoco, 0
			local k = math.min(nVit * nDt, nDist) / math.max(nDist, 0.001)
			st.pos:SetUnpacked(st.pos.x + dx * k, st.pos.y + dy * k, st.pos.z)
			st.yaw = approcheYaw(st.yaw, nCible, nDt)
			local sAnim = sLoco
			if sLoco == "walk" and math.abs(dV) > CFG.VirageMarche then sAnim = dV > 0 and "turn_left" or "turn_right" end
			jouer(st, sAnim, math.Clamp(nVit / CFG.Vitesses[sLoco], 0.7, 2))
		end
	else
		st.loco = nil
		local dJ = math.AngleDifference(nYawJoueur, st.yaw)
		if (st.mode == "pivot" or (st.mode == "suivre" and math.abs(dJ) > CFG.PivotDebut)) and pivoter(st, dJ, nDt, nNow) then
			st.idleT = 0
		elseif st.mode == "pivot" then
			st.mode = "suivre"
			jouer(st, "idle")
		end
		st.idleT = st.idleT + nDt
		if st.mode == "suivre" then
			if st.idleT > CFG.Assis and nVitJoueur < 5 then
				st.mode = "assoit"
				jouer(st, "sit_down")
			elseif nNow > st.nextEmote then
				st.nextEmote = nNow + math.Rand(CFG.Emote[1], CFG.Emote[2])
				st.mode = "emote"
				jouer(st, math.random(2) == 1 and st.emote or "look")
			else
				jouer(st, "idle")
			end
		elseif st.mode == "emote" then
			if finie(st) then st.mode = "suivre" jouer(st, "idle") end
		elseif st.mode == "assoit" then
			if finie(st) then st.mode = "assis" jouer(st, "sit_idle") end
		elseif st.mode == "leve" then
			if finie(st) then st.mode = "suivre" jouer(st, "idle") end
		end
	end

	-- Sol : trace espacée, hauteur lissée (escaliers, pentes).
	if nNow >= st.nextSol then
		st.nextSol = nNow + CFG.SolTrace
		st.solZ = sol(st.pos.x, st.pos.y, st.pos.z)
	end
	st.pos.z = Lerp(math.min(1, nDt * 12), st.pos.z, st.solZ)
	animer(st, nDt)
end

hook.Add("Think", "EVO::Compagnons::Simuler", function()
	if not next(tActifs) then return end
	local nDt, nNow = FrameTime(), CurTime()
	for ply, st in pairs(tActifs) do
		if IsValid(ply) and IsValid(st.ent) then
			simuler(ply, st, nDt, nNow)
		else
			retirer(ply)
		end
	end
end)

hook.Add("EntityRemoved", "EVO::Compagnons::Cleanup", function(ent)
	if tActifs[ent] then retirer(ent) end
end)

-- Diagnostic (superadmin) : chaque étape de la chaîne pour SON compagnon, dans le chat.
concommand.Add("evo_compagnon_debug", function()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:IsSuperAdmin()) then return end
	local sItem = lp:GetEvoNWString("EVO_Compagnon", "")
	local it = ITEMS and ITEMS[sItem]
	local st = tActifs[lp]
	local function l(s) chat.AddText(Color(120, 200, 255), "[Compagnon] ", color_white, s) end
	l("Objet réseau : " .. (sItem ~= "" and sItem or "AUCUN (case 9 vide, œil fermé ou synchro absente)"))
	l("Modèle : " .. tostring(it and it.model_path) .. " fichier=" .. tostring(it and file.Exists(it.model_path or "", "GAME")))
	l("Conditions : en vie=" .. tostring(lp:Alive()) .. " nodraw=" .. tostring(lp:GetNoDraw())
		.. " staff=" .. tostring(lp:GetEvoNWBool("EVO_StaffMode", false)) .. " voulu=" .. tostring(voulu(lp, lp) ~= nil))
	if it and file.Exists(it.model_path or "", "GAME") then
		local e = (st and IsValid(st.ent)) and st.ent or ClientsideModel(it.model_path)
		local tNoms = {}
		for _, sSeq in pairs(e:GetSequenceList() or {}) do tNoms[#tNoms + 1] = sSeq end
		l("Séquences : " .. table.concat(tNoms, ", "))
		if not (st and e == st.ent) then e:Remove() end
	end
	if st and IsValid(st.ent) then
		local vMin, vMax = st.ent:GetModelBounds()
		l(string.format("Actif : mode=%s anim=%s échelle=%.2f hauteur modèle=%.1f distance=%.0f",
			st.mode, tostring(st.anim), st.ent:GetModelScale(), vMax.z - vMin.z, st.pos:Distance(lp:GetPos())))
	else
		l("Actif : NON (aucun modèle créé)")
	end
end)

-- ── Invite au-dessus du compagnon (même rendu que les PNJ) : nom (si donné) de loin,
-- « (E) Caresser » de près. E = demande au serveur, qui valide et synchronise.
local PORTEE_CARESSE, PORTEE_NOM = 90, 500
local function hauteur(st)
	if not st.h then
		local _, vMax = st.ent:GetModelBounds()
		st.h = (vMax and vMax.z or 30) * (st.ent:GetModelScale() or 1)
	end
	return st.h
end

local function viseCompagnon(lp)
	local vMe, vAim = lp:GetPos(), lp:GetAimVector()
	local best, bestOwner, nBest = nil, nil, PORTEE_CARESSE * PORTEE_CARESSE
	for ply, st in pairs(tActifs) do
		if IsValid(ply) and IsValid(st.ent) and st.mode ~= "despawn" and not st.caresse then
			local v = st.pos - vMe
			local d = v.x * v.x + v.y * v.y
			if d < nBest and math.abs(v.z) < 80 then
				v.z = 0
				local n = v:Length()
				if n < 30 or (v / n):Dot(Vector(vAim.x, vAim.y, 0):GetNormalized()) > 0.3 then best, bestOwner, nBest = st, ply, d end
			end
		end
	end
	return best, bestOwner
end

local vTag = Vector()
hook.Add("PostDrawTranslucentRenderables", "EVO_COMP::Invite", function(bDepth, bSky)
	if bDepth or bSky or not EVO_ZonePrompt or not next(tActifs) then return end
	if render.GetRenderTarget() then return end -- reflets / passes RT : vue principale seulement
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local stVise = (not nYawCaresse) and viseCompagnon(lp)
	local vMe = lp:GetPos()
	for ply, st in pairs(tActifs) do
		if IsValid(ply) and IsValid(st.ent) and st.mode ~= "despawn" then
			local d2 = st.pos:DistToSqr(vMe)
			if d2 < PORTEE_NOM * PORTEE_NOM then
				local sNom = ply:GetEvoNWString("EVO_CompagnonNom", "")
				vTag:SetUnpacked(st.pos.x, st.pos.y, st.pos.z + hauteur(st) + 12)
				if st == stVise then
					EVO_ZonePrompt.DrawAt(vTag, sNom ~= "" and sNom or "Compagnon", "Caresser", "E", "parler", nil, 0.12)
				elseif sNom ~= "" then
					EVO_ZonePrompt.DrawAt(vTag, sNom, false, nil, "", nil, 0.12)
				end
			end
		end
	end
end)

hook.Add("KeyPress", "EVO_COMP::Caresser", function(ply, key)
	if key ~= IN_USE or not IsFirstTimePredicted() or ply ~= LocalPlayer() then return end
	-- Pendant SA caresse, E la termine (le serveur retrouve laquelle) ; sinon le compagnon visé.
	local owner
	if nYawCaresse then
		for p, st in pairs(tActifs) do
			if st.caresse and st.caresse.actor == ply then owner = p break end
		end
	else
		if EVO_ZonePrompt and IsValid(EVO_ZonePrompt.Target) then return end -- un PNJ a la priorité
		local _, o = viseCompagnon(ply)
		owner = o
	end
	if not IsValid(owner) then return end
	net.Start("EVO_COMP:Caresser")
		net.WriteEntity(owner)
	net.SendToServer()
end)
