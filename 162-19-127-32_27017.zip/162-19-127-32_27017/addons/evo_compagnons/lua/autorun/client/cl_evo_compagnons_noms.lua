-- "addons\\evo_compagnons\\lua\\autorun\\client\\cl_evo_compagnons_noms.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- COMPAGNONS, client : fenêtre du NOM (10/08) + invite « [E] Parler au Dresseur ».
-- Même fenêtre que le Scribe (lzy_renommeur) : gratuit = Valider / Plus tard, payant = deux
-- boutons au choix (coins ou yens, grisés si pas assez) + Annuler. Le serveur valide tout.
-- ============================================================================
local C = EVO_COMP.Dresseur

local function plusProcheDresseur()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local v, best, nBest = lp:GetPos(), nil, (C.PromptDistance or 160) ^ 2
	for _, e in ipairs(ents.FindByClass("evo_npc_dresseur")) do
		if IsValid(e) and math.abs(e:GetPos().z - v.z) <= (C.MaxZDelta or 200) then
			local d = e:GetPos():DistToSqr(v)
			if d < nBest then best, nBest = e, d end
		end
	end
	return best
end

EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["evo_compagnons_dresseur"] = {
	fGetTarget = plusProcheDresseur,
	fLabel = function() return "[E] Parler au " .. (C.NPCName or "Dresseur") end,
	fSub = function()
		local nCoins, nYens = C.Prix(LocalPlayer())
		if nCoins <= 0 and nYens <= 0 then return "Nom du compagnon : gratuit" end
		return "Nom du compagnon : " .. nCoins .. " coins ou " .. string.Comma(nYens) .. " ¥"
	end,
}

surface.CreateFont("EVOComp_Titre", { font = "Roboto", size = 26, weight = 800 })
surface.CreateFont("EVOComp_Texte", { font = "Roboto", size = 18, weight = 500 })
surface.CreateFont("EVOComp_Champ", { font = "Roboto", size = 20, weight = 600 })
surface.CreateFont("EVOComp_Bouton", { font = "Roboto", size = 18, weight = 700 })

local COL_BG, COL_BORD = Color(18, 18, 22, 245), Color(255, 255, 255, 25)
local COL_CHAMP, COL_TXT, COL_DIM = Color(30, 31, 37), Color(236, 236, 240), Color(150, 150, 162)
local COL_OK, COL_OKH = Color(45, 150, 85), Color(60, 180, 100)
local COL_NON, COL_NONH = Color(60, 60, 65), Color(85, 85, 92)
local fenetreNom

net.Receive("EVO_COMP:NomResultat", function()
	local id, succes, message = net.ReadUInt(32), net.ReadBool(), net.ReadString()
	local f = fenetreNom
	if IsValid(f) and f.nomId ~= id then return end
	if IsValid(f) then
		if succes then f:Remove() else f.FinirEnvoi(message) end
	end
	if MUGEN and MUGEN.Notify then MUGEN.Notify(message, succes and (NOTIFY_GENERIC or 0) or (NOTIFY_ERROR or 1), 4) end
end)

net.Receive("EVO_COMP:NomOuvrir", function()
	local id = net.ReadUInt(32)
	local sObjet, sActuel, bGratuit = net.ReadString(), net.ReadString(), net.ReadBool()
	local bPaye = net.ReadBool()
	local bValidationSimple = bGratuit or bPaye
	if IsValid(fenetreNom) then
		if fenetreNom.nomId == id then return end
		fenetreNom:Remove()
	end
	local lp = LocalPlayer()
	local nCoins, nYens = C.Prix(lp)
	local bCoinsOK = nCoins > 0 and lp:GetEvoNWInt("coins", 0) >= nCoins
	local bYensOK = nYens > 0 and lp:GetEvoNWInt("Money", 0) >= nYens
	local W, H = 460, bValidationSimple and 300 or 352

	local f = vgui.Create("DFrame")
	fenetreNom = f
	f.nomId = id
	f:SetSize(W, H) f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		surface.SetDrawColor(COL_BG) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_BORD) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText(bGratuit and "Nomme ton compagnon" or "Renommer ton compagnon", "EVOComp_Titre", w / 2, 26, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sObjet, "EVOComp_Texte", w / 2, 56, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(bPaye and "Paiement déjà effectué. Valide pour réessayer la sauvegarde."
			or bGratuit and "Premier nom offert. Les suivants sont payants."
			or ("Coût : " .. nCoins .. " coins ou " .. string.Comma(nYens) .. " ¥"),
			"EVOComp_Texte", w / 2, 80, bGratuit and COL_DIM or Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local e = vgui.Create("DTextEntry", f)
	e:SetPos(28, 106) e:SetSize(W - 56, 40)
	e:SetFont("EVOComp_Champ") e:SetText(sActuel) e:SetTextColor(COL_TXT) e:SetCursorColor(COL_TXT)
	e:SetPaintBackground(false) e:SetUpdateOnType(false)
	if e.SetDrawLanguageID then e:SetDrawLanguageID(false) end
	e:SetPlaceholderText("Nom (2 à 20 caractères)")
	e.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, COL_CHAMP)
		self:DrawTextEntryText(COL_TXT, Color(207, 68, 78), COL_TXT)
		if self:GetValue() == "" then draw.SimpleText(self:GetPlaceholderText(), "EVOComp_Champ", 8, h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
	end
	timer.Simple(0, function() if IsValid(e) then e:RequestFocus() end end)
	local statut = vgui.Create("DLabel", f)
	statut:SetPos(28, 154) statut:SetSize(W - 56, 62)
	statut:SetFont("EVOComp_Texte") statut:SetTextColor(COL_TXT)
	statut:SetWrap(true) statut:SetText("")
	local envoi = false
	f.FinirEnvoi = function(message)
		envoi = false
		e:SetEnabled(true)
		statut:SetText(message)
		e:RequestFocus()
	end

	local function envoyer(sMode)
		if envoi then return end
		local sNom, sErr = EVO_COMP.NomNettoye(e:GetValue())
		if not sNom then
			if MUGEN and MUGEN.Notify then MUGEN.Notify(sErr, NOTIFY_ERROR, 4) end
			return
		end
		envoi = true
		e:SetEnabled(false)
		statut:SetText("Enregistrement du nom…")
		net.Start("EVO_COMP:NomSave")
			net.WriteUInt(id, 32)
			net.WriteString(sNom)
			net.WriteString(sMode)
		net.SendToServer()
	end
	e.OnEnter = function() if bValidationSimple then envoyer("") elseif bCoinsOK or bYensOK then envoyer(bCoinsOK and "coins" or "yens") end end

	local function bouton(x, y, sLabel, bActif, fn)
		local b = vgui.Create("DButton", f)
		b:SetText("") b:SetSize(185, 42) b:SetPos(x, y)
		b.Paint = function(_, w, h)
			draw.RoundedBox(6, 0, 0, w, h, bActif and (b:IsHovered() and COL_OKH or COL_OK) or (b:IsHovered() and COL_NONH or COL_NON))
			draw.SimpleText(sLabel, "EVOComp_Bouton", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
	end
	if bValidationSimple then
		bouton(W / 2 - 195, H - 70, "Valider", true, function() envoyer("") end)
		bouton(W / 2 + 10, H - 70, "Plus tard", false, function() f:Remove() end)
	else
		bouton(W / 2 - 195, H - 122, "Payer " .. nCoins .. " coins", bCoinsOK, function() if bCoinsOK then envoyer("coins") end end)
		bouton(W / 2 + 10, H - 122, "Payer " .. string.Comma(nYens) .. " ¥", bYensOK, function() if bYensOK then envoyer("yens") end end)
		bouton(W / 2 - 92, H - 66, "Annuler", false, function() f:Remove() end)
	end
end)
