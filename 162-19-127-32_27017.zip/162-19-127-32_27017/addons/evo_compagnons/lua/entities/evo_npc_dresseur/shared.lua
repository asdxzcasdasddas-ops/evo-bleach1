-- "addons\\evo_compagnons\\lua\\entities\\evo_npc_dresseur\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Dresseur"
ENT.Author = "EVO"
ENT.Spawnable = false
ENT.AdminOnly = true
