-- "addons\\evo_compagnons\\lua\\entities\\evo_npc_dresseur\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

ENT.RenderGroup = RENDERGROUP_BOTH
ENT.EVO_PromptZ = 100 -- hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then
		EVO_ZonePrompt.NpcTag(self, (EVO_COMP and EVO_COMP.Dresseur and EVO_COMP.Dresseur.NPCName) or "Dresseur", 100, nil, 750, "parler")
	end
end
