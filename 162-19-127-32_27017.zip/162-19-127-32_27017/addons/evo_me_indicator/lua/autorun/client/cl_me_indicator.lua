-- "addons\\evo_me_indicator\\lua\\autorun\\client\\cl_me_indicator.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ME INDICATOR — client. Quand un joueur OUVRE le chat (lzy_chat), une
-- bulle DA Atelier s'affiche au-dessus de sa tête chez les joueurs proches
-- (indicateur "en train d'écrire") : mini plaque métal noir à coins coupés +
-- liseré acier, 3 points qui pulsent, petite queue de bulle et entaille slash1.
--
-- Détection : hook LZY_ChatFocusChanged (SetFocused dans lzy_chat) -> net bool
-- vers le serveur SEULEMENT au changement d'état ; le serveur miroir en NWBool
-- "EVO_MeTyping" (sv_me_indicator.lua). Fallback stock : StartChat / FinishChat.
-- Rendu : PostDrawTranslucentRenderables (respecte le Z : la bulle ne
-- transperce pas les murs), billboard face caméra, cull distance + dos caméra.
-- ============================================================================

local DIST_MAX_SQR = 800 * 800 -- portée d'affichage (~ portée RP d'un /me)

-- ── Détection locale : chat ouvert ? ───────────────────────────────────────
local lastSent = false
local function setTyping(b)
	if b == lastSent then return end
	lastSent = b
	net.Start("EVO:MeTyping")
	net.WriteBool(b)
	net.SendToServer()
end

hook.Add("LZY_ChatFocusChanged", "EVO_MeInd::Focus", function(focused)
	setTyping(focused and true or false)
end)
-- Fallback si le chat stock GMod est utilisé (hors lzy_chat).
hook.Add("StartChat", "EVO_MeInd::Start", function()
	setTyping(true)
end)
hook.Add("FinishChat", "EVO_MeInd::Finish", function()
	setTyping(false)
end)

-- ── Dessin de la bulle (pixels 3D2D, palette Atelier) ──────────────────────
local COL_PLATE = Color(13, 14, 17, 235)
local COL_EDGE  = Color(146, 152, 161, 60)
local COL_DOT   = Color(237, 238, 242)
local COL_ACC   = Color(207, 68, 78, 220)

local function drawDot(cx, cy, r, a)
	local pts = {}
	for i = 0, 11 do
		local ang = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(ang) * r, y = cy + math.sin(ang) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(COL_DOT.r, COL_DOT.g, COL_DOT.b, a)
	surface.DrawPoly(pts)
end

local function drawBubble(ply)
	local headPos = ply:GetPos() + Vector(0, 0, 92 * (ply:GetModelScale() or 1))
	local dir = (EyePos() - headPos):Angle()
	local ang = Angle(0, dir.y, 0)
	ang:RotateAroundAxis(ang:Right(), 90)
	ang:RotateAroundAxis(ang:Up(), -90)
	ang:RotateAroundAxis(ang:Right(), 180)

	cam.Start3D2D(headPos, ang, 0.12)
		-- Mini plaque Atelier (coins coupés + liseré acier), pixels 3D2D fixes.
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(-42, -30, 84, 46, COL_PLATE, 10)
			EVO_UI.OutlineCut(pts, COL_EDGE)
		else
			draw.RoundedBox(0, -42, -30, 84, 46, COL_PLATE)
		end
		-- Queue de bulle (petit triangle sous la plaque).
		draw.NoTexture()
		surface.SetDrawColor(COL_PLATE)
		surface.DrawPoly({ { x = -10, y = 16 }, { x = 8, y = 16 }, { x = -4, y = 28 } })

		-- 3 points « en train d'écrire » : pulsation décalée par point.
		local t = CurTime() * 3
		for i = 0, 2 do
			local pulse = math.max(0, math.sin(t - i * 0.7))
			drawDot(-18 + i * 18, -12, 4 + 1.5 * pulse, 110 + 145 * pulse)
		end

		-- Entaille slash1 accent en pied de plaque (signature Atelier).
		if EVO_UI and EVO_UI.Ink then
			EVO_UI.Ink(EVO_UI.TexSlash, -24, 2, 48, 8, COL_ACC)
		end
	cam.End3D2D()
end

hook.Add("PostDrawTranslucentRenderables", "EVO_MeInd::Draw", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Créateur / HUB : pas de bulle au-dessus de joueurs masqués (même filet que lzy_meet).
	if lp:GetEvoNWBool("InCharacterMenu", false)
		or (LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu()) then return end
	local eye, fwd = EyePos(), EyeVector()

	for _, ply in player.Iterator() do
		if ply ~= lp and IsValid(ply) and ply:Alive()
			and ply:GetEvoNWBool("EVO_MeTyping", false)
			and not ply:GetEvoNWBool("EVO_StaffMode", false)
			and ply:GetMoveType() ~= MOVETYPE_NOCLIP
			and not ply:GetEvoNWBool("InCharacterMenu", false)
			and not ply:GetNoDraw() then
			-- Salle de portail : pas de bulle qui fuit entre deux mondes isolés.
			if not (EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(lp, ply))
				and not (NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal
					and NCM_INSTANCE.ShouldHideFromLocal(ply)) then
				local pos = ply:GetPos()
				if eye:DistToSqr(pos) <= DIST_MAX_SQR
					and (pos - eye):GetNormalized():Dot(fwd) >= -0.2 then
					drawBubble(ply)
				end
			end
		end
	end
end)
