-- "addons\\evo_event_announce\\lua\\autorun\\sh_event_announce.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENT ANNOUNCE — bannière HUD haut-centre (15 min puis 5 min avant un
-- event PvP). API partagée : Push / Register / ShouldFire / HostWhere.
-- ============================================================================

EVO_EventAnnounce = EVO_EventAnnounce or {}

EVO_EventAnnounce.OFFSETS = { 15 * 60, 5 * 60 } -- secondes avant le début
EVO_EventAnnounce.SHOW_SECONDS = 10
EVO_EventAnnounce.KICKER_PVP = "ÉVÉNEMENT PVP"
EVO_EventAnnounce.KICKER_CAL = "ÉVÉNEMENT À VENIR"

local MAP_LABEL = {
	["hueco_mundo_v1"] = "Hueco Mundo",
	["rp_seireitei_v1"] = "Seireitei",
	["rp_shinonome_evo"] = "Monde des vivants", -- zone neutre (3e serveur)
}

--- Libellé de lieu depuis HostMaps + Arenas (ex. "Hueco Mundo · Zone Neutre 2").
function EVO_EventAnnounce.HostWhere(cfg)
	if not istable(cfg) then return "" end
	local labels = {}
	for sMap, bOn in pairs(cfg.HostMaps or {}) do
		if bOn then
			local arena = (cfg.Arenas or {})[sMap]
			local mapName = MAP_LABEL[sMap] or sMap
			local zone = arena and isstring(arena.name) and arena.name ~= "" and arena.name
			labels[#labels + 1] = zone and (mapName .. " · " .. zone) or mapName
		end
	end
	table.sort(labels)
	return table.concat(labels, " & ")
end

--- Choisit le palier à annoncer (15 min, puis 5 min). `fired` est muté.
--- Un reboot dans la fenêtre n'envoie qu'un palier (le plus serré), avec les
--- minutes réellement restantes. `SLACK` évite un double envoi à la frontière.
function EVO_EventAnnounce.ShouldFire(remain, fired, offsets)
	remain = tonumber(remain)
	if not remain or remain <= 0 then return nil end
	fired = istable(fired) and fired or {}
	offsets = istable(offsets) and offsets or EVO_EventAnnounce.OFFSETS

	local sorted = {}
	for i = 1, #offsets do
		sorted[i] = offsets[i]
	end
	table.sort(sorted, function(a, b) return a > b end)

	local slack = 15
	local chosen
	for i = 1, #sorted do
		if remain <= sorted[i] + slack then
			chosen = sorted[i]
		end
	end
	if not chosen or fired[chosen] then return nil end

	for i = 1, #sorted do
		if sorted[i] >= chosen then
			fired[sorted[i]] = true
		end
	end
	return math.max(1, math.floor(remain / 60))
end
