-- "addons\\evo_event_announce\\lua\\autorun\\client\\cl_event_announce.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENT ANNOUNCE — client : bannière haut-centre (slide-in + fondu).
-- DA alignée sur le calendrier / les events PvP (Bebas + accent, pas d'emoji).
-- ============================================================================

if not CLIENT then return end

EVO_EventAnnounce = EVO_EventAnnounce or {}

local function R(v)
	return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local COL_TITLE = Color(238, 239, 243)
local COL_MUTED = Color(150, 154, 162)

local function makeFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("EVO_EA_Kicker", "Roboto", 16, 800)
	gCreateRespFont("EVO_EA_Name", "Bebas Neue", 34, 400)
	gCreateRespFont("EVO_EA_Sub", "Roboto", 17, 500)
end
hook.Add("Initialize", "EVO_EventAnnounce::Fonts", makeFonts)
hook.Add("OnScreenSizeChanged", "EVO_EventAnnounce::Fonts", makeFonts)
makeFonts()

local current = nil
local queue = {}
local SHOW = EVO_EventAnnounce.SHOW_SECONDS or 10

function EVO_EventAnnounce.Show(opts)
	if not istable(opts) then return end
	local now = RealTime()
	local card = {
		kicker = opts.kicker or EVO_EventAnnounce.KICKER_PVP,
		name = opts.name or "Événement",
		loc = opts.loc or "",
		detail = opts.detail or "",
		mins = math.max(1, tonumber(opts.mins) or 1),
		col = opts.col or Color(207, 68, 78),
		born = now,
		expire = now + SHOW,
	}
	if current and (current.expire or 0) > now then
		queue[#queue + 1] = card
		return
	end
	current = card
	surface.PlaySound("friends/friend_online.wav")
end

net.Receive("EVO_EventAnnounceChat", function()
	local text = net.ReadString()
	if text == "" then return end
	if LZY_Chat_AddEventLine then
		LZY_Chat_AddEventLine(text)
	elseif LZY_Chat_AddSystemLine then
		LZY_Chat_AddSystemLine("events", text)
	else
		chat.AddText(Color(255, 132, 56), "[EVENT] ", Color(255, 255, 255), text)
	end
end)

net.Receive("EVO_EventAnnounce", function()
	local kicker = net.ReadString()
	local name = net.ReadString()
	local loc = net.ReadString()
	local detail = net.ReadString()
	local mins = net.ReadUInt(16)
	local r, g, b = net.ReadUInt(8), net.ReadUInt(8), net.ReadUInt(8)
	EVO_EventAnnounce.Show({
		kicker = kicker, name = name, loc = loc, detail = detail, mins = mins,
		col = Color(r, g, b),
	})
end)

hook.Add("HUDPaint", "EVO_EventAnnounce::Banner", function()
	if not current then
		if #queue == 0 then return end
		current = table.remove(queue, 1)
		current.born = RealTime()
		current.expire = current.born + SHOW
		surface.PlaySound("friends/friend_online.wav")
	end

	local now = RealTime()
	if now >= current.expire then
		current = nil
		return
	end

	local appear = math.Clamp((now - current.born) / 0.4, 0, 1)
	local fade = math.Clamp((current.expire - now) / 1.0, 0, 1)
	local A = 255 * fade
	local accent = current.col or Color(207, 68, 78)

	local mins = current.mins or 1
	local sub = (mins <= 1) and "Commence dans 1 min" or ("Commence dans " .. mins .. " min")
	if current.loc ~= "" then
		sub = sub .. "   ·   " .. current.loc
	end

	surface.SetFont("EVO_EA_Kicker")
	local kw = select(1, surface.GetTextSize(current.kicker))
	surface.SetFont("EVO_EA_Name")
	local nw = select(1, surface.GetTextSize(current.name))
	local detail = current.detail or ""
	surface.SetFont("EVO_EA_Sub")
	local sw = select(1, surface.GetTextSize(sub))
	local dw = (detail ~= "") and select(1, surface.GetTextSize(detail)) or 0

	local accW = R(52)
	local padX = R(42)
	local boxW = math.max(kw, nw, sw, dw, accW) + padX * 2
	local boxH = R(16) + R(18) + R(8) + R(2) + R(10) + R(36) + R(6) + R(20) + R(16)
	if detail ~= "" then boxH = boxH + R(4) + R(20) end
	local boxX = math.floor((ScrW() - boxW) * 0.5)
	local boxY = math.floor(Lerp(appear, -boxH - R(20), R(70)))
	local cx = math.floor(ScrW() * 0.5)

	local bg = Color(13, 13, 16, A)
	local outline = Color(accent.r, accent.g, accent.b, math.floor(A * 0.55))
	if RNDX and RNDX.Draw then
		RNDX.Draw(R(12), boxX, boxY, boxW, boxH, bg)
		if RNDX.DrawOutlined then
			RNDX.DrawOutlined(R(12), boxX, boxY, boxW, boxH, outline, 1.5)
		end
	else
		surface.SetDrawColor(bg)
		surface.DrawRect(boxX, boxY, boxW, boxH)
		surface.SetDrawColor(outline)
		surface.DrawOutlinedRect(boxX, boxY, boxW, boxH)
	end

	local y = boxY + R(16)
	draw.SimpleText(current.kicker, "EVO_EA_Kicker", cx, y, ColorAlpha(accent, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	y = y + R(18) + R(8)
	surface.SetDrawColor(accent.r, accent.g, accent.b, A)
	surface.DrawRect(math.floor(cx - accW * 0.5), y, accW, R(2))
	y = y + R(2) + R(10)
	draw.SimpleText(current.name, "EVO_EA_Name", cx, y, ColorAlpha(COL_TITLE, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	y = y + R(36) + R(6)
	draw.SimpleText(sub, "EVO_EA_Sub", cx, y, ColorAlpha(COL_MUTED, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	if detail ~= "" then
		y = y + R(20) + R(4)
		draw.SimpleText(detail, "EVO_EA_Sub", cx, y, ColorAlpha(COL_MUTED, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)
