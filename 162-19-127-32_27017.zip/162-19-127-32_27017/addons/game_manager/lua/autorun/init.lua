-- "addons\\game_manager\\lua\\autorun\\init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- lua/autorun/game_manager_loader.lua

-- Chargement optimisé des fichiers GameManager dans le bon ordre
-- pour garantir les performances avec 128 joueurs

-- Game Manager - Interface pour ZoneCapture avec base de données
-- Structure: server.lua (serveur) + client.lua (interface) + shared.lua (networking)

-- NOTE : l'UI Game Manager (menu à onglets) a été RETIRÉE. Toute la configuration et le
-- déclenchement des events (zones, paramètres, horaires) passent désormais PAR LE CALENDRIER
-- (addon evo_calendrier) : un event = un événement du calendrier, validé par un SuperAdmin.
-- On ne charge donc plus les interfaces client ; seuls les modules SERVEUR (qui spawnent
-- bombes / vagues / capture) et shared.lua (net strings + verrou) restent.
if SERVER then
    -- Charger modules serveur (via server_main)
    include("game_manager/server_main.lua")
    include("game_manager/shared.lua")

    -- Envoyer le shared au client (compat + net strings) ; plus aucune UI.
    AddCSLuaFile("game_manager/shared.lua")

elseif CLIENT then
    include("game_manager/shared.lua")
end