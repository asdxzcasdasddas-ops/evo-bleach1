-- "addons\\game_manager\\lua\\game_manager\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- lua/game_manager/shared.lua
-- Networking simplifié pour GameManager

GameManager = GameManager or {}

if SERVER then
    -- Network strings
    util.AddNetworkString("GM_RequestConfig")
    util.AddNetworkString("GM_SendConfig")
    util.AddNetworkString("GM_DoAction")
    util.AddNetworkString("GM_RequestRiftConfig")
    util.AddNetworkString("GM_SendRiftConfig")
    util.AddNetworkString("GM_DoRiftAction")
    util.AddNetworkString("GM_RequestFlagConfig")
    util.AddNetworkString("GM_SendFlagConfig")
    util.AddNetworkString("GM_DoFlagAction")

    -- ══════════════════════════════════════════════════════
    --  Verrou d'exclusivité mutuelle entre events
    --  Un seul event peut être actif à la fois sur le serveur
    --  (ZoneCapture / RiftEvents / FlagCapture / Defusal).
    --  Le scheduler auto + start manuel respectent tous le verrou.
    -- ══════════════════════════════════════════════════════
    GameManager.ActiveEvent = GameManager.ActiveEvent or nil

    function GameManager.IsEventActive()
        return GameManager.ActiveEvent ~= nil
    end

    function GameManager.GetActiveEvent()
        return GameManager.ActiveEvent
    end

    function GameManager.SetActiveEvent(sID)
        GameManager.ActiveEvent = sID
        -- Miroir RÉPLIQUÉ : le calendrier (client) lit GetGlobalString pour afficher / proposer l'arrêt.
        SetGlobalString("EVO_GM_ActiveEvent", sID or "")
    end

    --- Libère le verrou. Si sID est passé, ne libère QUE si l'event courant
    --- correspond (évite qu'un Stop d'un event coupe le verrou d'un autre).
    function GameManager.ClearActiveEvent(sID)
        if not sID or GameManager.ActiveEvent == sID then
            GameManager.ActiveEvent = nil
            SetGlobalString("EVO_GM_ActiveEvent", "")
        end
    end

    --- Arrête l'event moteur actuellement actif (quel qu'il soit). Renvoie l'id arrêté ou nil.
    --- Utilisé par le calendrier (« Arrêter l'event en cours ») puisque l'UI GM n'existe plus.
    function GameManager.StopActive()
        local a = GameManager.ActiveEvent
        if not a then return nil end
        if a == "ZoneCapture" and GameManager.ZoneCapture and GameManager.ZoneCapture.StopEvent then
            GameManager.ZoneCapture.StopEvent()
        elseif a == "Defusal" and GameManager.Defusal and GameManager.Defusal.StopEvent then
            GameManager.Defusal.StopEvent()
        elseif a == "RiftEvents" and GameManager.RiftEvents and GameManager.RiftEvents.StopEvent then
            GameManager.RiftEvents.StopEvent()
        elseif a == "FlagCapture" and GameManager.FlagCapture and GameManager.FlagCapture.StopGame then
            GameManager.FlagCapture.StopGame()
        elseif a == "BatailleFactions" and EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.ForceStop then
            EVO_BATAILLE_FAC.ForceStop(nil)
        else
            GameManager.ClearActiveEvent(a) -- filet : libère au moins le verrou
        end
        return a
    end

    -- WATCHDOG : les events qui finissent NATURELLEMENT (temps écoulé / victoire / vagues finies /
    -- bombes désamorcées) ne passent PAS par les wrappers Stop -> sans ça le verrou resterait
    -- bloqué et le calendrier ne pourrait déclencher qu'UN SEUL event moteur. On libère donc le
    -- verrou dès que l'event sous-jacent n'est plus actif.
    timer.Create("GM_ActiveWatchdog", 3, 0, function()
        local a = GameManager.ActiveEvent
        if not a then return end
        local live = false
        if a == "ZoneCapture" then
            live = ZoneCapture and ZoneCapture.ActiveZone ~= nil and not ZoneCapture.EventFinished
        elseif a == "RiftEvents" then
            live = RiftEvents and RiftEvents.ActiveZone ~= nil
        elseif a == "Defusal" then
            live = DefusalEvent and DefusalEvent.Active == true
        elseif a == "FlagCapture" then
            live = FlagCapture and FlagCapture.GameActive == true
        elseif a == "BatailleFactions" then
            live = EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.IsEventLive and EVO_BATAILLE_FAC.IsEventLive()
        end
        if not live then GameManager.ClearActiveEvent(a) end
    end)

else -- CLIENT
    
    -- Fonctions de base pour compatibilité avec les anciens appels
    function GameManager.RequestConfig()
        return GameManager.ZoneCapture.RequestConfig()
    end
    
    function GameManager.SendAction(action, data)
        return GameManager.ZoneCapture.SendAction(action, data)
    end
    
    function GameManager.RequestRiftConfig()
        return GameManager.RiftEvents.RequestConfig()
    end
    
    function GameManager.SendRiftAction(action, data)
        return GameManager.RiftEvents.SendAction(action, data)
    end

    function GameManager.RequestFlagConfig()
        return GameManager.FlagCapture.RequestConfig()
    end
    
    function GameManager.SendFlagAction(action, data)
        return GameManager.FlagCapture.SendAction(action, data)
    end
    
end