-- "addons\\evo_faction_wall\\lua\\entities\\evo_faction_wall\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type           = "anim"
ENT.Base           = "base_anim"
ENT.PrintName      = "Faction Cube"
ENT.Author         = "Evo"
ENT.Spawnable      = false
ENT.AdminSpawnable = false
ENT.AutomaticFrameAdvance = false

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "BlockCsv")
end

function ENT:IsFactionWall()
	return true
end

function ENT:GetBlockSet()
	local csv = self:GetBlockCsv() or ""
	local t = {}
	if csv == "" then return t end
	for fac in string.gmatch(csv, "([^,]+)") do
		fac = string.Trim(fac)
		if fac ~= "" then t[fac] = true end
	end
	return t
end
