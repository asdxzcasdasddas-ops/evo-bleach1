-- "addons\\evo_faction_wall\\lua\\entities\\evo_faction_wall\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Initialize()
	self:SetNoDraw(true)
	self:SetCustomCollisionCheck(true)
end

function ENT:Draw() end
