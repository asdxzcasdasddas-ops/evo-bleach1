-- "addons\\evo_faction_wall\\lua\\autorun\\sh_loader_faction_wall.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO FACTION WALL — cubes AABB invisibles qui bloquent une faction.
-- Config : mins / maxs / faction (édition via !config_positions → Zones).
-- Debug  : evo_factionwall_draw (superadmin)
-- Rebuild: evo_factionwall_rebuild (superadmin)
-- ============================================================================

EVO_FACTION_WALL = EVO_FACTION_WALL or {}

if SERVER then
	AddCSLuaFile("evo_faction_wall/sh_config.lua")
	AddCSLuaFile("evo_faction_wall/sh_geometry.lua")
	AddCSLuaFile("evo_faction_wall/sh_collide.lua")
	AddCSLuaFile("evo_faction_wall/cl_main.lua")

	include("evo_faction_wall/sh_config.lua")
	include("evo_faction_wall/sh_geometry.lua")
	include("evo_faction_wall/sh_collide.lua")
	include("evo_faction_wall/sv_main.lua")
else
	include("evo_faction_wall/sh_config.lua")
	include("evo_faction_wall/sh_geometry.lua")
	include("evo_faction_wall/sh_collide.lua")
	include("evo_faction_wall/cl_main.lua")
end
