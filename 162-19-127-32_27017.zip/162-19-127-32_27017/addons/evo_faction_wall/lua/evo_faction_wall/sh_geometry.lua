-- "addons\\evo_faction_wall\\lua\\evo_faction_wall\\sh_geometry.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Géométrie partagée des cubes AABB (serveur + client debug draw).
-- ============================================================================

EVO_FACTION_WALL = EVO_FACTION_WALL or {}

--- Construit les AABB pour une map (ou la map courante).
--- @return table[] { mins, maxs, mid, half, faction, block, message }
function EVO_FACTION_WALL.BuildCubesForMap(sMap)
	local out = {}
	sMap = sMap or game.GetMap()
	local list = EVO_FACTION_WALL.Cubes and EVO_FACTION_WALL.Cubes[sMap]
	if not istable(list) then return out end

	for i = 1, #list do
		local c = list[i]
		if not (istable(c) and isvector(c.mins) and isvector(c.maxs) and isstring(c.faction) and c.faction ~= "") then
			continue
		end

		local mn = Vector(
			math.min(c.mins.x, c.maxs.x),
			math.min(c.mins.y, c.maxs.y),
			math.min(c.mins.z, c.maxs.z)
		)
		local mx = Vector(
			math.max(c.mins.x, c.maxs.x),
			math.max(c.mins.y, c.maxs.y),
			math.max(c.mins.z, c.maxs.z)
		)
		local size = mx - mn
		if size.x < 1 or size.y < 1 or size.z < 1 then continue end

		local mid = (mn + mx) * 0.5
		out[#out + 1] = {
			mins    = mn,
			maxs    = mx,
			mid     = mid,
			half    = size * 0.5,
			faction = c.faction,
			block   = { [c.faction] = true },
			message = c.message,
		}
	end

	return out
end
