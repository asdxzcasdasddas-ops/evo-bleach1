-- "addons\\evo_faction_wall\\lua\\evo_faction_wall\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Debug draw des cubes de faction (superadmin).
-- Commande : evo_factionwall_draw
-- ============================================================================

if not CLIENT then return end

EVO_FACTION_WALL = EVO_FACTION_WALL or {}

local _draw = false
local _cubes = {}
local COL_EDGE  = Color(255, 60, 60, 220)
local COL_FILL  = Color(255, 40, 40, 40)
local COL_LABEL = Color(255, 220, 220, 255)

local function Refresh()
	_cubes = EVO_FACTION_WALL.BuildCubesForMap(game.GetMap())
end

local function BlockList(cube)
	local t = {}
	for fac, on in pairs(cube.block or {}) do
		if on then t[#t + 1] = fac end
	end
	table.sort(t)
	return table.concat(t, ", ")
end

concommand.Add("evo_factionwall_draw", function(ply)
	if IsValid(ply) and ply ~= LocalPlayer() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then
		print("[FactionWall] Superadmin only.")
		return
	end

	_draw = not _draw
	if _draw then
		Refresh()
		local fac = lp:GetEvoNWString("FactionName", "")
		print(string.format(
			"[FactionWall] DRAW ON — map='%s' cubes=%d faction='%s' noclip=%s",
			game.GetMap(), #_cubes, fac, tostring(lp:GetMoveType() == MOVETYPE_NOCLIP)
		))
		if #_cubes == 0 then
			print("[FactionWall] Aucun cube pour cette map — ajoute-en via !config_positions → Zones.")
		end
		for i = 1, #_cubes do
			local c = _cubes[i]
			local blocked = fac ~= "" and c.block[fac] == true
			print(string.format(
				"  #%d block={%s} size=%.0fx%.0fx%.0f YOU_BLOCKED=%s",
				i, BlockList(c), c.half.x * 2, c.half.y * 2, c.half.z * 2, tostring(blocked)
			))
		end
	else
		print("[FactionWall] DRAW OFF")
	end
end)

hook.Add("PostDrawTranslucentRenderables", "EVO::FactionWall::Draw", function(_, bSkybox)
	if bSkybox or not _draw then return end
	if #_cubes == 0 then return end

	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then
		_draw = false
		return
	end

	render.SetColorMaterial()

	for i = 1, #_cubes do
		local c = _cubes[i]
		local mins = Vector(-c.half.x, -c.half.y, -c.half.z)
		local maxs = Vector( c.half.x,  c.half.y,  c.half.z)

		render.SetBlend(COL_FILL.a / 255)
		render.DrawBox(c.mid, angle_zero, mins, maxs, COL_FILL, true)
		render.SetBlend(1)
		render.DrawWireframeBox(c.mid, angle_zero, mins, maxs, COL_EDGE, true)

		local labelPos = c.mid + Vector(0, 0, c.half.z + 16)
		local a = (labelPos - EyePos()):Angle()
		a:RotateAroundAxis(a:Up(), -90)
		a:RotateAroundAxis(a:Forward(), 90)
		cam.Start3D2D(labelPos, a, 0.25)
			draw.SimpleTextOutlined(
				string.format("#%d [%s]", i, BlockList(c)),
				"DermaLarge", 0, 0, COL_LABEL,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black
			)
			draw.SimpleTextOutlined(
				string.format("%.0f × %.0f × %.0f", c.half.x * 2, c.half.y * 2, c.half.z * 2),
				"DermaDefault", 0, 28, COL_LABEL,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black
			)
		cam.End3D2D()
	end
end)
