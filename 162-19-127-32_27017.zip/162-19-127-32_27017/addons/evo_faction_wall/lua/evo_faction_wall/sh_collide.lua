-- "addons\\evo_faction_wall\\lua\\evo_faction_wall\\sh_collide.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- ShouldCollide partagé : le cube physique ne collisionne qu'avec les
-- joueurs dont FactionName est dans BlockCsv. Noclip = pas de collision.
-- Les deux côtés (cube + player) ont SetCustomCollisionCheck.
-- ============================================================================

EVO_FACTION_WALL = EVO_FACTION_WALL or {}

local function IsFactionWall(ent)
	return IsValid(ent) and ent.IsFactionWall and ent:IsFactionWall()
end

local function PlayerBlockedByWall(ply, wall)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if not ply:Alive() then return false end
	if ply:GetMoveType() == MOVETYPE_NOCLIP then return false end
	if ply:GetEvoNWBool("NCM_Instanced", false) then return false end

	local fac = ply:GetEvoNWString("FactionName", "")
	if fac == "" then return false end
	local block = wall:GetBlockSet()
	return block[fac] == true
end

hook.Add("ShouldCollide", "EVO::FactionWall::Collide", function(a, b)
	local wall, other
	if IsFactionWall(a) then
		wall, other = a, b
	elseif IsFactionWall(b) then
		wall, other = b, a
	else
		return
	end

	-- Mur ↔ non-joueur : pas de collision (évite de bloquer props / PNJ).
	if not IsValid(other) or not other:IsPlayer() then
		return false
	end

	if PlayerBlockedByWall(other, wall) then
		return true
	end
	return false
end)
