-- "addons\\evo_faction_wall\\lua\\evo_faction_wall\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Cubes de faction — config partagée
--
-- Chaque cube = AABB (mins / maxs) + faction bloquée (Hollow ou Shinigami).
-- Les joueurs dont FactionName == faction ne peuvent pas entrer.
-- Édition live : !config_positions → Zones → Bloque Hollow / Bloque Shinigami.
-- ============================================================================

EVO_FACTION_WALL = EVO_FACTION_WALL or {}

EVO_FACTION_WALL.Message         = "Passage interdit à ta faction."
EVO_FACTION_WALL.MessageCooldown = 3    -- secondes entre deux notifs

-- Cubes[map] = { { mins, maxs, faction = "Hollow"|"Shinigami", message? }, ... }
EVO_FACTION_WALL.Cubes = {
	-- ["rp_seireitei_v1"] = {
	-- 	{
	-- 		mins    = Vector(0, 0, 0),
	-- 		maxs    = Vector(128, 128, 128),
	-- 		faction = "Hollow",
	-- 	},
	-- },
}
