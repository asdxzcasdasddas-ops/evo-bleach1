-- "addons\\evo_slow_fx\\lua\\autorun\\client\\cl_slow_fx.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ════════════════════════════════════════════════════════════════════════════
--  EVO — EFFET D'ÉCRAN « RALENTI » (client). Demande user 06/08 :
--  « un petit flou du mouvement, comme si t'avais mal au crâne, MAIS PAS ABUSÉ ».
--
--  RÉVISION 08/08 : « c'est pas beau, mets juste un truc de blur ». On a donc
--  RETIRÉ les deux effets qui cherchaient le « mal au crâne » :
--    - la PULSATION : un flou qui respire attire l'oeil sur lui-même au lieu de
--      rester une ambiance, et en combat ça se lit comme un écran qui clignote ;
--    - l'assombrissement des BORDS : deux bandes noires en haut et en bas, c'est
--      la lettrbox d'une cinématique, pas un état de personnage.
--  Il ne reste que le flou de mouvement, constant, faible, qui monte et descend
--  avec l'effet. Un seul réglage à toucher si c'est encore trop : BLUR_MAX.
--
--  PARTI PRIS DE LISIBILITÉ, inchangé : le flou reste FAIBLE et l'écran n'est
--  jamais assombri. Un ralentissement arrive en plein combat ; un voile épais
--  ne serait pas une ambiance, ce serait un handicap qui s'ajoute au handicap.
--
--  COÛT : une seule passe plein écran (DrawMotionBlur) et seulement quand l'effet
--  est actif. Le hook de rendu est POSÉ et RETIRÉ, il ne coûte donc rigoureusement
--  rien aux joueurs qui ne sont pas ralentis — soit presque tout le monde, presque
--  tout le temps (même principe que les repères staff).
-- ════════════════════════════════════════════════════════════════════════════
if not CLIENT then return end

local CV = CreateClientConVar("evo_slow_fx", "1", true, false,
    "Effet d'ecran quand on est ralenti (0 = aucun effet)")

-- Fondu d'entrée et de sortie : un effet qui apparaît d'un coup se lit comme un
-- bug d'affichage, pas comme un état.
local FONDU_IN, FONDU_OUT = 0.35, 0.55

-- Plafonds ASSUMÉS. Ce sont eux qui garantissent le « pas abusé » : même à force
-- maximale, le flou reste sous ces valeurs. À comparer au blur cinématique du
-- finisher (0.30) : on est volontairement en dessous.
local BLUR_MIN, BLUR_MAX = 0.07, 0.16

local actif, force, finLe, debutLe = false, 0, 0, 0

local function alphaCourant()
    if not actif then return 0 end
    local now = CurTime()
    local monte = math.Clamp((now - debutLe) / FONDU_IN, 0, 1)
    local reste = finLe - now
    local descend = math.Clamp(reste / FONDU_OUT, 0, 1)
    return math.min(monte, descend)
end

local function couper()
    -- `finLe` est remis à zéro AVEC le reste : sinon une fin de slow lointaine
    -- (menottes) survivrait à la coupure, et le math.max de la réception ferait
    -- démarrer le prochain effet avec une échéance héritée de l'ancien.
    actif, force, finLe, debutLe = false, 0, 0, 0
    hook.Remove("RenderScreenspaceEffects", "EVO_SlowFX::Ecran")
end

local function dessinerEcran()
    local a = alphaCourant()
    if a <= 0 then couper() return end
    -- Flou CONSTANT. Le seul mouvement, c'est le fondu d'entree et de sortie
    -- porte par `a` : l'effet arrive, tient, repart. Rien ne respire entre-temps.
    local q = BLUR_MIN + (BLUR_MAX - BLUR_MIN) * force
    DrawMotionBlur(0.62, q * a, 0.016)
end

local function poser()
    if actif then return end
    actif = true
    debutLe = CurTime()
    hook.Add("RenderScreenspaceEffects", "EVO_SlowFX::Ecran", dessinerEcran)
end

net.Receive("EVO::SlowFX", function()
    local duree = net.ReadFloat()
    local f = net.ReadFloat()

    if duree <= 0 or f <= 0 or not CV:GetBool() then couper() return end

    -- Ré-application : on PROLONGE sans refaire le fondu d'entrée, sinon une entrave
    -- renouvelée ferait clignoter l'écran à chaque renouvellement.
    if not actif then poser() end
    force = math.max(force, math.Clamp(f, 0, 1))
    finLe = math.max(finLe, CurTime() + duree)
end)

-- FILETS DE SÉCURITÉ CÔTÉ CLIENT. Le serveur coupe déjà à la mort et au spawn, mais
-- un paquet peut se perdre et un effet d'écran collé est bien pire que pas d'effet :
-- on se donne les moyens de sortir tout seul.
hook.Add("Think", "EVO_SlowFX::Securite", function()
    if not actif then return end
    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:Alive() or CurTime() > finLe then couper() end
end)

-- Changement de map / reconnexion : rien ne doit survivre.
hook.Add("InitPostEntity", "EVO_SlowFX::Reset", couper)

cvars.AddChangeCallback("evo_slow_fx", function(_, _, new)
    if tonumber(new) == 0 then couper() end
end, "EVO_SlowFX")
