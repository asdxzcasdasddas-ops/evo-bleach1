-- "addons\\evo_affiche\\lua\\autorun\\sh_evo_affiche_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AFFICHE — loader. Affiche vierge (Urahara Shop) : on écrit dedans, on y
-- glisse un visuel, puis on l'accroche sur un mur, on la montre, on la donne,
-- ou on l'imprime en plusieurs exemplaires.
-- Le CONTENU d'une affiche est persisté (l'item vit dans le sac). Une affiche
-- ACCROCHÉE ordinaire ne l'est pas (elle expire en une heure, un redémarrage
-- la décroche) ; une affiche VERROUILLÉE, si : elle revient sur son mur au
-- démarrage (table evo_affiche_murs, sv_affiche.lua).
-- ============================================================================
EVO_AFFICHE = EVO_AFFICHE or {}

if SERVER then
	AddCSLuaFile("evo_affiche/sh_config.lua")
	AddCSLuaFile("evo_affiche/cl_images.lua")
	AddCSLuaFile("evo_affiche/cl_affiche.lua")
	AddCSLuaFile("evo_affiche/cl_place.lua")
	include("evo_affiche/sh_config.lua")
	include("evo_affiche/sv_images.lua")
	include("evo_affiche/sv_affiche.lua")
else
	include("evo_affiche/sh_config.lua")
	include("evo_affiche/cl_images.lua")
	include("evo_affiche/cl_affiche.lua")
	include("evo_affiche/cl_place.lua")
end
