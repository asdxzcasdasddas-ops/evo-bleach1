-- "addons\\evo_affiche\\lua\\entities\\evo_affiche_murale\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type           = "anim"
ENT.Base           = "base_gmodentity"
ENT.PrintName      = "Affiche murale"
ENT.Author         = "Evo"
ENT.Category       = "Evo"
ENT.Spawnable      = false
ENT.AdminSpawnable = false
-- Modèle porté mais JAMAIS dessiné : il ne sert qu'à donner des bornes de
-- réseau à l'entité. Tout le visible est le contenu rendu en 3D2D (cl_init).
-- Chemin en dur : les entités sont chargées avant l'autorun de l'addon.
ENT.Model          = "models/evo/props/items/evo_e63565fz3ferezfz/evo_e63565fz3FERezfz.mdl"

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "DocId")
	-- Affiche VERROUILLÉE (posée par un animateur / SA, user 08/26) : le STAFF la
	-- retire (EVO_AFFICHE.CanUnlock, sh_config), elle n'expire pas et revient au
	-- mur après un redémarrage. Lu par l'invite « Prendre ».
	self:NetworkVar("Bool", 0, "Locked")
end
