-- "addons\\evo_affiche\\lua\\entities\\evo_affiche_murale\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- L'affiche accrochée ne dessine PAS son modèle : seul son contenu est rendu, à
-- plat sur le mur. Le repère vient des ANGLES de l'entité (posées par le serveur
-- depuis la normale du mur), la taille de A.PosterW / A.PosterH. Tout le calcul
-- lourd est mis en cache : une affiche accrochée ne bouge plus.

local A = EVO_AFFICHE

ENT.RenderGroup = RENDERGROUP_OPAQUE

surface.CreateFont("EVO_Affiche_Titre", { font = "Bebas Neue", size = 40, weight = 700, extended = true, antialias = true })
surface.CreateFont("EVO_Affiche_Corps", { font = "Roboto",     size = 17, weight = 500, extended = true, antialias = true })
surface.CreateFont("EVO_Affiche_Sign",  { font = "Roboto",     size = 14, weight = 400, extended = true, antialias = true })

local CANVAS_W = 320           -- toile virtuelle, mise à l'échelle sur A.PosterW
local COL_PAPER    = Color(232, 226, 212, 255)
local COL_INK      = Color(26, 24, 22)
local COL_INK_SOFT = Color(92, 86, 78)
local COL_ACCENT   = Color(176, 52, 58)

local function wrapLines(sText, sFont, nMaxW, nMaxLines)
	local tOut = {}
	nMaxLines = nMaxLines or 0
	if nMaxLines < 1 then return tOut end -- plus de place : zéro ligne, pas une
	surface.SetFont(sFont)

	local function push(s)
		tOut[#tOut + 1] = s
		return #tOut >= nMaxLines
	end

	--- Plus long préfixe qui tient dans la largeur, sans couper un caractère
	--- accentué en deux (UTF-8 : les octets de continuation valent 10xxxxxx).
	local function fits(sWord)
		local n = #sWord
		while n > 1 and surface.GetTextSize(string.sub(sWord, 1, n)) > nMaxW do n = n - 1 end
		while n > 1 do
			local b = string.byte(sWord, n + 1)
			if not b or bit.band(b, 0xC0) ~= 0x80 then break end
			n = n - 1
		end
		return n
	end

	for _, sPara in ipairs(string.Explode("\n", sText or "")) do
		local sLine = ""
		for _, sWord in ipairs(string.Explode(" ", sPara)) do
			-- Un mot plus large que la ligne entière (titre sans espace) ne se
			-- coupe pas tout seul : il déborderait de l'affiche.
			while surface.GetTextSize(sWord) > nMaxW do
				if sLine ~= "" then
					if push(sLine) then return tOut end
					sLine = ""
				end
				local n = fits(sWord)
				if push(string.sub(sWord, 1, n)) then return tOut end
				sWord = string.sub(sWord, n + 1)
			end
			local sTry = sLine == "" and sWord or (sLine .. " " .. sWord)
			if sLine ~= "" and surface.GetTextSize(sTry) > nMaxW then
				if push(sLine) then return tOut end
				sLine = sWord
			else
				sLine = sTry
			end
		end
		if sLine ~= "" and push(sLine) then return tOut end
	end
	return tOut
end

function ENT:Initialize()
	self._lay = nil
	self._defAsked = false
	-- Le modèle n'est pas dessiné et il est plus petit que le contenu : sans
	-- bornes élargies, l'affiche serait cullée dès qu'elle frôle le bord de
	-- l'écran alors que sa surface est encore visible.
	local n = math.max(A.PosterW, A.PosterH)
	self:SetRenderBounds(Vector(-n, -n, -n), Vector(n, n, n))
end

--- Reconstruit la mise en page. Ne repasse que si la définition de l'affiche ou
--- son visuel viennent d'arriver (les deux sont asynchrones).
function ENT:BuildLayout(def, mat)
	local aAng = self:GetAngles()
	local vW, vH = aAng:Forward(), -aAng:Right() -- largeur, hauteur (cf. PosterFrame)
	local nScale = A.PosterW / CANVAS_W
	local nCanvH = A.PosterH / nScale
	local nPad   = CANVAS_W * 0.07

	local lay = {
		pos = A.PosterOrigin(self:GetPos(), vW, vH), ang = aAng, scale = nScale,
		w = CANVAS_W, h = nCanvH, pad = nPad, def = def, mat = mat,
		-- Normale sortante : le repère 3D2D la porte sur Up. Figée ici, le test
		-- de dos tourne à chaque frame et ne doit allouer aucun vecteur.
		normal = aAng:Up(),
		-- ⚠️ Les dimensions d'un Material mentent tant que la texture n'est pas
		-- résolue. On les mémorise pour refaire la mise en page quand elles
		-- changent, sinon un cadrage faux resterait figé pour toujours.
		matW = mat and mat:Width() or 0,
	}

	local nY = nPad
	-- Titre optionnel (user 08/26) : vide = aucune ligne, le visuel / le texte
	-- remontent et prennent la place.
	lay.titleLines = def.title ~= "" and wrapLines(def.title, "EVO_Affiche_Titre", CANVAS_W - nPad * 2, 3) or {}
	surface.SetFont("EVO_Affiche_Titre")
	local _, nTitleH = surface.GetTextSize("A")
	lay.titleY, lay.titleH = nY, nTitleH
	if #lay.titleLines > 0 then nY = nY + nTitleH * #lay.titleLines + nPad * 0.5 end

	-- Le visuel prend ce qui reste, moins la signature en pied de page.
	surface.SetFont("EVO_Affiche_Sign")
	local _, nSignH = surface.GetTextSize("A")
	local nFootY = nCanvH - nPad - nSignH
	lay.signY, lay.signH = nFootY, nSignH

	if mat then
		local nMaxW, nMaxH = CANVAS_W - nPad * 2, (nFootY - nPad * 0.5) - nY
		if nMaxH > 12 then
			local nIw, nIh = mat:Width(), mat:Height()
			if nIw > 0 and nIh > 0 then
				local nK = math.min(nMaxW / nIw, nMaxH / nIh)
				lay.imgW, lay.imgH = nIw * nK, nIh * nK
				lay.imgX = (CANVAS_W - lay.imgW) * 0.5
				lay.imgY = nY
				nY = nY + lay.imgH + nPad * 0.4
			end
		end
	end

	-- Le corps ne remplit que la place restante : la lecture complète se fait
	-- une fois l'affiche prise, depuis le sac.
	local nBodyH = nFootY - nPad * 0.3 - nY
	if nBodyH > 10 and (def.excerpt or "") ~= "" then
		surface.SetFont("EVO_Affiche_Corps")
		local _, nLineH = surface.GetTextSize("A")
		lay.bodyLines = wrapLines(def.excerpt, "EVO_Affiche_Corps", CANVAS_W - nPad * 2,
			math.max(0, math.floor(nBodyH / nLineH)))
		lay.bodyY, lay.bodyH = nY, nLineH
	end

	self._lay = lay
end

function ENT:Draw()
	-- Volontairement PAS de DrawModel : seule l'affiche imprimée est visible.
	local sId = self:GetDocId()
	if sId == "" then return end

	local vMe = EyePos()
	local d2 = vMe:DistToSqr(self:GetPos())
	if d2 > A.DrawRange * A.DrawRange then return end

	local def = A.Defs and A.Defs[sId]
	if not def then
		-- Def pas encore reçue : une seule relance, jamais en boucle de rendu.
		if not self._defAsked then
			self._defAsked = true
			if A.AskDefs then A.AskDefs() end
		end
		return
	end
	if not self._imgAsked and (def.img or "") ~= "" then
		self._imgAsked = true
		A.EnsureImage(sId, def.img)
	end

	local mat = A.PosterMat(def.img)
	local lay = self._lay
	if not lay or lay.def ~= def or lay.mat ~= mat or (mat and lay.matW ~= mat:Width()) then
		self:BuildLayout(def, mat)
		lay = self._lay
	end

	-- Dos de l'affiche : inutile de dessiner ce qui est derrière le mur. Produit
	-- scalaire écrit à la main pour ne rien allouer par frame.
	local vP, vNn = lay.pos, lay.normal
	if (vMe.x - vP.x) * vNn.x + (vMe.y - vP.y) * vNn.y + (vMe.z - vP.z) * vNn.z < 0 then return end

	local bDetail = d2 <= A.DetailRange * A.DetailRange

	cam.Start3D2D(lay.pos, lay.ang, lay.scale)
		surface.SetDrawColor(COL_PAPER)
		surface.DrawRect(0, 0, lay.w, lay.h)
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(0, 0, lay.w, math.max(2, lay.pad * 0.12))

		local nY = lay.titleY
		for _, sLine in ipairs(lay.titleLines) do
			draw.SimpleText(sLine, "EVO_Affiche_Titre", lay.w * 0.5, nY, COL_INK,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			nY = nY + lay.titleH
		end

		if lay.imgW then
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(mat)
			surface.DrawTexturedRect(lay.imgX, lay.imgY, lay.imgW, lay.imgH)
		end

		-- Le corps et la signature ne sont de toute façon pas lisibles de loin :
		-- au delà du palier de détail, on économise une quinzaine de textes par
		-- affiche et par frame.
		if bDetail then
			if lay.bodyLines then
				local nBy = lay.bodyY
				for _, sLine in ipairs(lay.bodyLines) do
					draw.SimpleText(sLine, "EVO_Affiche_Corps", lay.pad, nBy, COL_INK,
						TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					nBy = nBy + lay.bodyH
				end
			end
			if (def.ownerName or "") ~= "" then -- anonyme (animateur / SA) : pas de signature
				draw.SimpleText(def.ownerName, "EVO_Affiche_Sign", lay.w - lay.pad, lay.signY,
					COL_INK_SOFT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			end
		end
	cam.End3D2D()
end
