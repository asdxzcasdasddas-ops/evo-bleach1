-- "addons\\evo_affiche\\lua\\evo_affiche\\cl_images.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AFFICHE — visuels, client. Deux façons d'illustrer une affiche :
--   • CAPTURE : render.Capture, ce que le joueur voit à l'instant T.
--   • DOSSIER : le joueur pose son visuel dans garrysmod/data/evo_affiche/visuels/ et
--     le choisit en jeu (le vrai glisser-déposer Windows n'existe pas dans GMod).
-- Montée en paquets (plafond net ~64 Ko) ; descente avec cache disque : une
-- image déjà reçue n'est jamais re-téléchargée (nom unique par envoi).
-- ============================================================================
if not CLIENT then return end

local A = EVO_AFFICHE

file.CreateDir("evo_affiche")
file.CreateDir(A.ImgUserDir)
file.CreateDir(A.ImgCacheDir)
file.CreateDir(A.ImgTmpDir)

-- Reprise de l'ancien dossier data/evo_affiches (avant regroupement sous une
-- racine unique) : les images déjà déposées sont déplacées, pas perdues.
do
	local sOld = "evo_affiches"
	for _, sPat in ipairs({ "*.jpg", "*.jpeg", "*.png" }) do
		for _, sName in ipairs(file.Find(sOld .. "/" .. sPat, "DATA") or {}) do
			if not file.Exists(A.ImgUserDir .. "/" .. sName, "DATA") then
				local sData = file.Read(sOld .. "/" .. sName, "DATA")
				if sData and #sData > 0 then
					file.Write(A.ImgUserDir .. "/" .. sName, sData)
					file.Delete(sOld .. "/" .. sName)
				end
			end
		end
	end
end

local function imageExt(sData)
	if sData:sub(1, 2) == "\xFF\xD8" then return "jpg" end
	if sData:sub(1, 4) == "\x89PNG" then return "png" end
	return nil
end

-- Rétention locale, une fois au chargement : au-delà de la fenêtre de purge le
-- serveur a de toute façon supprimé l'original. Les previews tmp ne servent que
-- pendant la session.
do
	local now = os.time()
	for _, f in ipairs(file.Find(A.ImgCacheDir .. "/*", "DATA") or {}) do
		local sStamp = f:match("^aff_%d+_(%d+)%.")
		if sStamp and now - (tonumber(sStamp) or 0) > A.ImgKeepDays * 86400 then
			file.Delete(A.ImgCacheDir .. "/" .. f)
		end
	end
	for _, f in ipairs(file.Find(A.ImgTmpDir .. "/*", "DATA") or {}) do
		file.Delete(A.ImgTmpDir .. "/" .. f)
	end
end

-- ── CAPTURE D'ÉCRAN ─────────────────────────────────────────────────────────
-- Material() met en cache par chemin : compteur dans le nom du preview pour que
-- chaque nouvelle capture s'affiche vraiment.
local nPreviewGen = 0

function A.Capture(tHide, fDone)
	local tWasVisible = {}
	for _, p in ipairs(tHide or {}) do
		if IsValid(p) then tWasVisible[p] = p:IsVisible() p:SetVisible(false) end
	end
	hook.Add("PostRender", "EVO_Affiche::Capture", function()
		hook.Remove("PostRender", "EVO_Affiche::Capture")
		-- Qualité DESCENDANTE jusqu'à passer sous le plafond : à q82 un JPEG 1080p
		-- fait 200 à 400 Ko mais un 1440p/4K dépasse facilement 512 Ko.
		local sData
		for _, nQ in ipairs({ 82, 60, 45, 30 }) do
			sData = render.Capture({ format = "jpeg", x = 0, y = 0, w = ScrW(), h = ScrH(), quality = nQ })
			if not sData or #sData == 0 or #sData <= A.ImgMaxSize then break end
		end
		for p, bVis in pairs(tWasVisible) do
			if IsValid(p) then p:SetVisible(bVis) end
		end
		if not sData or #sData == 0 then fDone(nil, "Capture impossible (menu Échap ouvert ?)") return end
		if #sData > A.ImgMaxSize then fDone(nil, "Capture trop lourde.") return end
		nPreviewGen = nPreviewGen + 1
		local sPath = A.ImgTmpDir .. "/preview_" .. nPreviewGen .. ".jpg"
		file.Write(sPath, sData)
		fDone(sData, nil, Material("data/" .. sPath, "smooth"))
	end)
end

-- ── VISUELS DU DOSSIER data/evo_affiche/visuels ─────────────────────────────
function A.ListFolder()
	local out = {}
	for _, sPat in ipairs({ "*.jpg", "*.jpeg", "*.png" }) do
		for _, sName in ipairs(file.Find(A.ImgUserDir .. "/" .. sPat, "DATA") or {}) do
			out[#out + 1] = { name = sName, size = file.Size(A.ImgUserDir .. "/" .. sName, "DATA") or 0 }
		end
	end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

function A.ReadFolderImage(sName, fDone)
	if not isstring(sName) or sName:find("[/\\]") then fDone(nil, "Nom invalide.") return end
	local sData = file.Read(A.ImgUserDir .. "/" .. sName, "DATA")
	if not sData or #sData == 0 then fDone(nil, "Fichier illisible.") return end
	if #sData > A.ImgMaxSize then fDone(nil, "Visuel trop lourd (max " .. math.floor(A.ImgMaxSize / 1024) .. " Ko).") return end
	if not imageExt(sData) then fDone(nil, "Format non reconnu (JPEG ou PNG).") return end
	fDone(sData, nil, Material("data/" .. A.ImgUserDir .. "/" .. sName, "smooth"))
end

-- ── MONTÉE ──────────────────────────────────────────────────────────────────
local fUploadDone

function A.Upload(sData, fDone)
	if fUploadDone then fDone(false, "Un envoi est déjà en cours.") return end
	if not isstring(sData) or #sData < 512 or #sData > A.ImgMaxSize then fDone(false, "Visuel invalide.") return end
	fUploadDone = fDone

	local nChunks = math.ceil(#sData / A.ImgChunk)
	net.Start("EVO:Affiche:ImgUpBegin")
		net.WriteUInt(#sData, 32)
		net.WriteUInt(nChunks, 8)
	net.SendToServer()

	for i = 1, nChunks do
		local sPart = sData:sub((i - 1) * A.ImgChunk + 1, i * A.ImgChunk)
		timer.Simple(i * 0.1, function()
			net.Start("EVO:Affiche:ImgUpChunk")
				net.WriteUInt(i, 8)
				net.WriteUInt(#sPart, 16)
				net.WriteData(sPart, #sPart)
			net.SendToServer()
		end)
	end
	timer.Simple(nChunks * 0.1 + 0.2, function()
		net.Start("EVO:Affiche:ImgUpEnd")
		net.SendToServer()
	end)
	-- Filet : si le serveur ne répond jamais, on libère le créneau.
	timer.Create("EVO_Affiche::UpTimeout", nChunks * 0.1 + 10, 1, function()
		if fUploadDone then local f = fUploadDone fUploadDone = nil f(false, "Pas de réponse du serveur.") end
	end)
end

net.Receive("EVO:Affiche:ImgUpDone", function()
	local bOk  = net.ReadBool()
	local sMsg = net.ReadString()
	timer.Remove("EVO_Affiche::UpTimeout")
	if fUploadDone then local f = fUploadDone fUploadDone = nil f(bOk, sMsg) end
end)

-- ── DESCENTE + CACHE ────────────────────────────────────────────────────────
-- tMats est le SEUL chemin de lecture en rendu : simple lecture de table, aucun
-- accès disque ni allocation par frame sur un mur qui dessine son affiche.
local tMats  = {}   -- sFile -> IMaterial
local tAsked = {}   -- sFile -> true (déjà demandé au serveur, ne pas redemander)
local tQueue = {}   -- sFile -> docId à demander
local tDown  = {}   -- sFile -> { size, n, parts, got }

function A.PosterMat(sFile) return tMats[sFile or ""] end

--- Rend le visuel d'une affiche disponible : cache mémoire, puis disque, puis
--- demande au serveur. Appelé à l'apparition d'une affiche, jamais en rendu.
function A.EnsureImage(sDocId, sFile)
	if not isstring(sFile) or sFile == "" or tMats[sFile] then return end
	local sPath = A.ImgCacheDir .. "/" .. sFile
	if file.Exists(sPath, "DATA") then
		tMats[sFile] = Material("data/" .. sPath, "smooth")
		return
	end
	if tAsked[sFile] then return end
	tQueue[sFile] = sDocId
end

-- netgate: edge — ne parle au serveur que quand une affiche jamais vue apparaît.
local function drainImageQueue()
	local sFile, sDocId = next(tQueue)
	if not sFile then return end
	tQueue[sFile] = nil
	tAsked[sFile] = true
	tDown[sFile] = { parts = {}, got = 0 }
	net.Start("EVO:Affiche:ImgReq")
		net.WriteString(sDocId or "")
	net.SendToServer()
	-- Sans garde-fou, un refus serveur ou un fichier disparu laisserait l'entrée
	-- en vol pour toujours et bloquerait le créneau suivant. tAsked retombe aussi :
	-- le serveur a plusieurs refus SILENCIEUX (cooldown, flux déjà en vol), et un
	-- visuel simplement retardé ne doit pas devenir définitivement inaccessible.
	timer.Create("EVO_Affiche::Down::" .. sFile, 20, 1, function()
		tDown[sFile] = nil
		tAsked[sFile] = nil
	end)
end
timer.Create("EVO_Affiche::ImgQueue", 1.5, 0, drainImageQueue)

-- Visuel introuvable côté serveur : sans ce signal le lecteur resterait sur
-- « Chargement… » et l'entrée fuirait dans la file (le créneau suivant serait
-- bloqué jusqu'au timeout).
net.Receive("EVO:Affiche:ImgMissing", function()
	local sFile = net.ReadString()
	tDown[sFile] = nil
	timer.Remove("EVO_Affiche::Down::" .. sFile)
	A.ImgGone = A.ImgGone or {}
	A.ImgGone[sFile] = true
end)

net.Receive("EVO:Affiche:ImgBegin", function()
	local sFile = net.ReadString()
	local nSize = net.ReadUInt(32)
	local nCh   = net.ReadUInt(8)
	local dl = tDown[sFile]
	if not dl then return end
	dl.size, dl.n = nSize, nCh
end)

net.Receive("EVO:Affiche:ImgChunk", function()
	local sFile = net.ReadString()
	local nIdx  = net.ReadUInt(8)
	local nLen  = net.ReadUInt(16)
	local sPart = net.ReadData(nLen)
	local dl = tDown[sFile]
	if not dl or not dl.n or dl.parts[nIdx] then return end
	dl.parts[nIdx] = sPart
	dl.got = dl.got + 1
	if dl.got < dl.n then return end

	tDown[sFile] = nil
	timer.Remove("EVO_Affiche::Down::" .. sFile)
	local sData = table.concat(dl.parts)
	-- Nom re-validé avant écriture : il vient du serveur, mais zéro traversée par principe.
	if #sData ~= dl.size or not sFile:match("^aff_%d+_%d+%.%a+$") then return end
	local sPath = A.ImgCacheDir .. "/" .. sFile
	file.Write(sPath, sData)
	tMats[sFile] = Material("data/" .. sPath, "smooth")
end)
