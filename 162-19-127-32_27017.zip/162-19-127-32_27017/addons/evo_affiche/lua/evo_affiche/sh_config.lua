-- "addons\\evo_affiche\\lua\\evo_affiche\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AFFICHE — config partagée + géométrie de la face imprimable.
-- ============================================================================
EVO_AFFICHE = EVO_AFFICHE or {}
local A = EVO_AFFICHE

A.Model       = "models/evo/props/items/evo_e63565fz3ferezfz/evo_e63565fz3FERezfz.mdl"
A.ModelLift   = 0.05
A.BlankItemId = "affiche_vierge"
A.WrittenItemId = "evo_affiche"
A.ItemPrefix  = "evo_affiche_"   -- legacy item_id (migration boot)

A.MaxTitleLen = 48
A.MaxTextLen  = 2800             -- de quoi écrire un vrai article
A.MaxPrint    = 10               -- copies imprimables en une fois
A.CreateCD    = 3
A.PrintCD     = 5
A.GiveRadius  = 150
A.ShowRadius  = 250
A.PurgeDays   = 30               -- purge BDD des affiches plus vieilles que N jours

-- Accrochage : de SESSION pour les affiches ordinaires (elles expirent en une
-- heure de toute façon). Les affiches VERROUILLÉES, elles, sont PERSISTÉES en
-- base et remises au mur au démarrage (table evo_affiche_murs, sv_affiche).
A.PlaceRange   = 170             -- portée du regard pour viser le mur
A.PlaceMinDot  = 0.45            -- surface trop horizontale (sol / plafond) = refus
A.MaxPerPlayer = 6
A.MaxWorld     = 80
-- Plafond des affiches VERROUILLÉES, dans MaxWorld (08/28). Elles n'expirent
-- pas ET survivent aux redémarrages : sans plafond à elles, une saison
-- d'animations finirait par occuper les 80 places et plus personne ne pourrait
-- rien accrocher. Le staff en retire une pour en poser une autre.
A.MaxWallLocked = 40
-- Durée de vie AU MUR (secondes) : passé ce délai l'affiche disparaît d'elle-même,
-- SANS rendre l'exemplaire (accrocher consomme l'item ; décrocher avant l'heure
-- le rend). Le document reste en base jusqu'à la purge PurgeDays.
A.WallLifetime = 3600
A.ReadRange    = 130             -- tolérance SERVEUR pour prendre
-- Taille de l'affiche au mur, en unités monde (un joueur fait 72 de haut). Le
-- modèle n'étant plus dessiné, ces deux valeurs décident seules de la taille du
-- contenu : c'est ici qu'on agrandit ou rétrécit une affiche.
A.PosterW      = 54
A.PosterH      = 76
-- Le +use du moteur porte à ~90 unités : le rappel « Appuyer sur E » doit
-- apparaître là où la touche marche vraiment, pas plus loin.
A.HintRange    = 82
A.DrawRange    = 1000            -- au-delà, l'affiche ne dessine plus son contenu
A.DetailRange  = 480             -- au-delà, ni corps de texte ni signature

-- Images. Même mécanique que les preuves de rapport faction : capture d'écran
-- ou fichier déposé par le joueur, transport en paquets, cache disque.
-- 256 Ko : le visuel est aussi stocké en base (partagée entre les serveurs),
-- doubler ce plafond doublerait le poids de la table.
A.ImgMaxSize  = 256 * 1024
A.ImgChunk    = 45000
-- UNE seule racine data/evo_affiche. Le dossier joueur s'appelait "evo_affiches",
-- à un « s » près du dossier interne : deux dossiers presque homonymes, personne
-- ne savait lequel servait à quoi.
A.ImgUserDir  = "evo_affiche/visuels" -- le joueur y dépose ses images
A.ImgSrvDir   = "evo_affiche/img"
A.ImgCacheDir = "evo_affiche/cache"
A.ImgTmpDir   = "evo_affiche/tmp"
A.ImgKeepDays = 30

function A.ItemId(sId) return A.ItemPrefix .. sId end

-- Qui peut poser une affiche VERROUILLÉE (user 08/26) : superadmin, ou perso
-- animateur (EVO_AnimChar, posé serveur, non spoofable). Partagé : le client
-- affiche le bouton, le serveur tranche à la pose.
function A.CanLock(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return ply:GetEvoNWBool("EVO_AnimChar", false) == true
end

-- Qui peut DÉCROCHER une affiche verrouillée (user 08/28 : « le staff doit
-- pouvoir enlever les affiches protégées »). EVO_EstStaff vit dans
-- evo_staff/lua/autorun/sh_staff_grades.lua : fichier autorun nu, donc SERVEUR
-- ET CLIENT -- indispensable ici, le serveur autorise et le client affiche (ou
-- non) l'invite « Prendre ». Il répond en service ou non, helpeurs et animateurs
-- compris : c'est la même liste que celle du HUD staff.
-- ⚠ Test `EVO_EstStaff ~= nil` obligatoire : rien ne garantit l'ordre de
-- chargement des addons, et un serveur sans evo_staff doit continuer à tourner
-- (le droit se referme alors sur les superadmins) plutôt que planter.
-- ⚠ PAS `ply:IsStaff()` : dans ce gamemode il vaut SUPERADMIN SEUL
-- (config/core/sh_config.lua, cfg.Admins), il exclurait tout le staff.
function A.CanUnlock(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return EVO_EstStaff ~= nil and EVO_EstStaff(ply) == true
end

-- ── Géométrie ───────────────────────────────────────────────────────────────
-- L'affiche accrochée ne DESSINE PAS son modèle : seul son contenu est rendu, à
-- plat sur le mur. Le repère ne vient donc plus de l'OBB du modèle (dont l'axe
-- de face était indevinable) mais directement de la normale du mur.

--- Angles dont l'avant est vF et le haut vU. Passe par un roll mesuré plutôt
--- que par une Matrix : SetRight/SetUp piègent sur le sens des axes.
function A.AnglesFromBasis(vF, vU)
	local a = vF:Angle()
	a:RotateAroundAxis(vF, math.deg(math.atan2(vU:Dot(a:Right()), vU:Dot(a:Up()))))
	return a
end

--- Direction "haut" de l'affiche posée sur un mur de normale vN, après le roll
--- choisi par le poseur.
function A.PosterUp(vN, nRoll)
	local vUp = Vector(0, 0, 1) - vN * vN.z
	if vUp:LengthSqr() < 0.001 then vUp = vN:Cross(Vector(0, 1, 0)) end
	vUp:Normalize()
	if nRoll and nRoll ~= 0 then
		-- vUp et vN sont perpendiculaires : la combinaison cos/sin suffit.
		local vR = vN:Cross(vUp)
		local r = math.rad(nRoll)
		vUp = vUp * math.cos(r) + vR * math.sin(r)
		vUp:Normalize()
	end
	return vUp
end

--- Repère 3D2D d'une affiche sur un mur de normale vN : angle, largeur monde,
--- hauteur monde. Renvoie aussi vW et vH pour placer le coin haut gauche.
--- ⚠️ vH:Cross(vN) et PAS l'inverse : celui qui regarde l'affiche la voit dans
--- le sens -vN, donc sa droite vaut vH x vN. L'inverse dessinerait EN MIROIR.
--- ⚠️ cam.Start3D2D : +X suit Forward, +Y suit RIGHT, et UP est la normale du
--- plan. D'où AnglesFromBasis(vW, vN) et non (vW, vH).
function A.PosterFrame(vN, nRoll)
	local vH = A.PosterUp(vN, nRoll)
	local vW = vH:Cross(vN)
	vW:Normalize()
	return A.AnglesFromBasis(vW, vN), vW, vH
end

--- Coin HAUT GAUCHE de l'affiche à partir de son centre.
function A.PosterOrigin(vCenter, vW, vH)
	return vCenter - vW * (A.PosterW * 0.5) + vH * (A.PosterH * 0.5)
end

-- ── Item AFFICHE VIERGE, enregistré au RUNTIME ──────────────────────────────
-- L'inventaire ré-assigne la table ITEMS à son include : un enregistrement trop
-- tôt serait écrasé. Appelé en boucle courte par sv_affiche / cl_affiche.
function A.RegisterBlankItem()
	if not istable(ITEMS) then return false end
	ITEMS[A.BlankItemId] = {
		name         = "Affiche vierge",
		description  = "Une grande feuille d'affichage, encore vierge."
			.. "\nClic droit > Utiliser pour la rédiger.",
		category     = "object",
		rarity       = "common",
		model_path   = A.Model,
		model_lift   = A.ModelLift,
		is_droppable = true,
		is_deletable = true,
		bDocumentItem = true, -- document RP : un perso animation peut le jeter (gate inventory net.lua)
		stack_max    = 64,
		-- Client : ouvre l'éditeur. Serveur : no op, la création passe par le net
		-- EVO:Affiche:Create, revalidé (détention, longueurs, censure).
		on_use       = CLIENT and function() if A.OpenWrite then A.OpenWrite() end end or function() end,
	}
	return true
end

function A.RegisterWrittenItem()
	if not istable(ITEMS) then return false end
	ITEMS[A.WrittenItemId] = {
		name         = "Affiche",
		description  = "Une affiche rédigée. Clic droit > Utiliser pour la lire.",
		category     = "object",
		rarity       = "common",
		model_path   = A.Model,
		model_lift   = A.ModelLift,
		is_droppable = true,
		is_deletable = true,
		bDocumentItem = true,
		requires_instance_key = true,
		evo_affiche  = true,
		instance_name = function(key)
			local d = (CLIENT and A.Defs and A.Defs[key]) or (SERVER and A.Docs and A.Docs[key])
			local title = d and d.title or ""
			return title ~= "" and ("Affiche : " .. title) or "Affiche" -- sans titre : rien d'écrit
		end,
		instance_description = function(key)
			local d = (CLIENT and A.Defs and A.Defs[key]) or (SERVER and A.Docs and A.Docs[key])
			if d then
				if (d.ownerName or "") == "" then return "Une affiche. Clic droit > Utiliser pour la lire." end
				return "Affiche rédigée par " .. d.ownerName .. ".\nClic droit > Utiliser pour la lire."
			end
			return "Une affiche rédigée. Clic droit > Utiliser pour la lire."
		end,
		on_use = CLIENT and function(_, slot)
			local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
			local key = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
			if key and A.OpenRead then A.OpenRead(key) end
		end or function() end,
	}
	return true
end
