-- "addons\\evo_affiche\\lua\\evo_affiche\\cl_place.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AFFICHE — mode de pose. Aperçu du RECTANGLE de l'affiche collé au mur visé
-- (le modèle n'est jamais dessiné, ni ici ni une fois posé), molette pour
-- pivoter, clic gauche pour accrocher. Le serveur revalide tout : ici on ne fait
-- que montrer où l'affiche atterrira.
-- ============================================================================
if not CLIENT then return end

local A = EVO_AFFICHE

local sDoc, nRoll, sReason
local bLockPose = false -- affiche verrouillée (animateur / SA), revalidé serveur
local COL_OK   = Color(120, 220, 140, 70)
local COL_EDGE = Color(150, 245, 170, 220)
local COL_BAD  = Color(220, 90, 90, 220)

surface.CreateFont("EVO_Affiche_Aide", { font = "Bebas Neue", size = 30, weight = 700, extended = true, antialias = true })

function A.StopPlacement()
	sDoc, sReason = nil, nil
	hook.Remove("PostDrawTranslucentRenderables", "EVO_Affiche::Ghost")
	hook.Remove("HUDPaint", "EVO_Affiche::GhostHUD")
	hook.Remove("PlayerButtonDown", "EVO_Affiche::GhostKeys")
	hook.Remove("PlayerBindPress", "EVO_Affiche::GhostBinds")
end

--- Surface visée : position et normale, ou nil plus la raison du refus.
local function aimSurface()
	local ply = LocalPlayer()
	if not IsValid(ply) then return nil, "" end
	local vEye = ply:EyePos()
	local tr = util.TraceLine({
		start = vEye, endpos = vEye + ply:GetAimVector() * A.PlaceRange, filter = ply,
	})
	if not tr.Hit then return nil, "APPROCHE TOI D'UN MUR" end
	if math.abs(tr.HitNormal.z) > (1 - A.PlaceMinDot) then return nil, "SUR UN MUR, PAS AU SOL" end
	if IsValid(tr.Entity) and (tr.Entity:IsPlayer() or tr.Entity:IsNPC()) then
		return nil, "PAS SUR QUELQU'UN"
	end
	-- FindInSphere et pas un balayage complet : ce test tourne à chaque frame
	-- pendant toute la pose.
	for _, e in ipairs(ents.FindInSphere(tr.HitPos, 26)) do
		if e:GetClass() == "evo_affiche_murale" then return nil, "EMPLACEMENT DÉJÀ OCCUPÉ" end
	end
	return tr.HitPos, tr.HitNormal
end

function A.StartPlacement(sId, bLock)
	A.StopPlacement()
	if not isstring(sId) or sId == "" then return end
	sDoc, nRoll = sId, 0
	bLockPose = bLock == true

	-- Aperçu : le rectangle exact que l'affiche occupera, dans le même repère
	-- que le rendu final (A.PosterFrame), donc ce qu'on voit est ce qu'on aura.
	hook.Add("PostDrawTranslucentRenderables", "EVO_Affiche::Ghost", function(bDepth, bSkybox)
		if bDepth or bSkybox or not sDoc then return end
		local vPos, vN = aimSurface()
		if not vPos then sReason = vN return end
		sReason = nil

		local aAng, vW, vH = A.PosterFrame(vN, nRoll)
		local vOrigin = A.PosterOrigin(vPos + vN * 0.5, vW, vH)
		cam.Start3D2D(vOrigin, aAng, 1)
			surface.SetDrawColor(COL_OK)
			surface.DrawRect(0, 0, A.PosterW, A.PosterH)
			surface.SetDrawColor(COL_EDGE)
			surface.DrawOutlinedRect(0, 0, A.PosterW, A.PosterH, 1)
			-- Repère du HAUT : sans lui, impossible de voir dans quel sens la
			-- molette a fait tourner l'affiche.
			surface.DrawRect(0, 0, A.PosterW, 2)
		cam.End3D2D()
	end)

	hook.Add("HUDPaint", "EVO_Affiche::GhostHUD", function()
		local w, y = ScrW(), ScrH() - 110
		if sReason then
			draw.SimpleText(sReason, "EVO_Affiche_Aide", w / 2, y, COL_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText((bLockPose and "CLIC GAUCHE ACCROCHER (VERROUILLÉE)" or "CLIC GAUCHE ACCROCHER") .. "     MOLETTE PIVOTER     CLIC DROIT ANNULER",
			"EVO_Affiche_Aide", w / 2, y + 34, Color(235, 235, 240, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)

	-- Molette et clics sont avalés pendant la pose : le joueur est dans un mode
	-- modal, il ne se bat pas.
	hook.Add("PlayerBindPress", "EVO_Affiche::GhostBinds", function(_, sBind)
		if not sDoc then return end
		if sBind == "+attack" or sBind == "+attack2" or sBind == "invnext" or sBind == "invprev" then
			return true
		end
	end)

	hook.Add("PlayerButtonDown", "EVO_Affiche::GhostKeys", function(_, nBtn)
		if not sDoc then return end
		if nBtn == MOUSE_WHEEL_UP then nRoll = math.NormalizeAngle(nRoll + 15) return end
		if nBtn == MOUSE_WHEEL_DOWN then nRoll = math.NormalizeAngle(nRoll - 15) return end
		if nBtn == MOUSE_RIGHT or nBtn == KEY_ESCAPE then A.StopPlacement() return end
		if nBtn ~= MOUSE_LEFT then return end

		local vPos, vN = aimSurface()
		if not vPos then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(vN or "Emplacement invalide.", NOTIFY_ERROR, 3) end
			return
		end
		-- 6 flottants plutôt qu'un WriteVector : ce dernier compresse et arrondit,
		-- ce qui détruirait la normale (0.7071 deviendrait 0.75).
		net.Start("EVO:Affiche:Place")
			net.WriteString(sDoc)
			net.WriteFloat(vPos.x) net.WriteFloat(vPos.y) net.WriteFloat(vPos.z)
			net.WriteFloat(vN.x)   net.WriteFloat(vN.y)   net.WriteFloat(vN.z)
			net.WriteFloat(nRoll)
			net.WriteBool(bLockPose)
		net.SendToServer()
		A.StopPlacement()
	end)
end

-- Mort ou déconnexion pendant la pose : on ne laisse pas les hooks collés.
hook.Add("PlayerDeath", "EVO_Affiche::GhostDeath", function(ply)
	if ply == LocalPlayer() then A.StopPlacement() end
end)
