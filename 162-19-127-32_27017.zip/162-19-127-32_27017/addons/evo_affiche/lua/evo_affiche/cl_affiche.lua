-- "addons\\evo_affiche\\lua\\evo_affiche\\cl_affiche.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AFFICHE — client. Définitions des affiches (items dynamiques), éditeur
-- (écriture + visuel), lecteur (accrocher / montrer / donner / imprimer), et
-- lecteur d'une affiche déjà accrochée. DA Atelier : plaque coins coupés,
-- accent #cf444e.
-- ============================================================================
local A = EVO_AFFICHE

A.Defs = A.Defs or {}   -- id -> { id, title, ownerName, img, excerpt, createdAt }

local COL_CARD   = Color(13, 14, 17, 250)
local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)
local COL_FIELD  = Color(8, 8, 10, 230)
local COL_OK     = Color(118, 190, 128)

local function R(v)
	if gRespY then return gRespY(v) end
	return math.floor(v * (ScrH() / 1080))
end
local function plate(x, y, w, h, col, rad)
	if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(x, y, w, h, col, rad or R(12))
	else draw.RoundedBox(8, x, y, w, h, col) end
end
local function titleSlash(txt, x, y, font)
	draw.SimpleText(txt, font, x, y, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont(font)
	local tw, th = surface.GetTextSize(txt)
	if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
		EVO_UI.Ink(EVO_UI.TexSlash, x - R(3), y + th * 0.28, tw * 1.1, R(9), ColorAlpha(COL_ACCENT, 245))
	else
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(x, y + th * 0.34, tw, math.max(2, R(2)))
	end
end
local function notify(sMsg, bErr)
	if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(sMsg, bErr and NOTIFY_ERROR or NOTIFY_GENERIC, 4) end
end

local function makeBackdrop()
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
	frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false) frame:MakePopup()
	openedFrame = frame
	frame.OnRemove = function(s) if openedFrame == s then openedFrame = nil end end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.Paint = function(s, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR) end
		surface.SetDrawColor(5, 5, 7, 210) surface.DrawRect(0, 0, w, h)
	end
	frame.OnMousePressed = function(s) s:Remove() end
	return frame
end

local function mkBtn(parent, label, fill, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetCursor("hand")
	b.Paint = function(s, w, h)
		local hov = s:IsHovered()
		if fill then
			if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(COL_ACCENT, hov and 255 or 220))
			else draw.RoundedBox(6, 0, 0, w, h, COL_ACCENT) end
		else
			if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, hov and 22 or 10))
			else draw.RoundedBox(6, 0, 0, w, h, Color(255, 255, 255, hov and 22 or 10)) end
		end
		draw.SimpleText(label, "Bebas Neue:24", w / 2, h / 2, fill and color_white or (hov and COL_TITLE or COL_MUTED),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fn
	return b
end

local function mkClose(card, W, frame)
	local x = vgui.Create("DButton", card)
	x:SetText("") x:SetSize(R(30), R(30)) x:SetPos(W - R(44), R(18)) x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() frame:Remove() end
	return x
end

-- ── CHOIX DU VISUEL ─────────────────────────────────────────────────────────
-- Liste des fichiers déposés dans data/evo_affiche/visuels. fPick(nom) au clic.
local function OpenFolderPicker(fPick)
	local frame = makeBackdrop()
	local W, H = R(560), R(560)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end

	local tFiles = A.ListFolder()
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		titleSlash("CHOISIR UN VISUEL", R(26), R(34), "Bebas Neue:38")
		draw.SimpleText("Dépose tes images dans garrysmod/data/" .. A.ImgUserDir,
			"Avenir Next World:16", R(26), R(62), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if #tFiles == 0 then
			draw.SimpleText("Aucune image dans ce dossier.", "Avenir Next World:20", w / 2, h / 2,
				COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	mkClose(card, W, frame)

	local scroll = vgui.Create("DScrollPanel", card)
	scroll:SetPos(R(24), R(100)) scroll:SetSize(W - R(48), H - R(124))
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	for _, f in ipairs(tFiles) do
		local row = vgui.Create("DButton", scroll)
		row:Dock(TOP) row:DockMargin(0, 0, 0, R(6)) row:SetTall(R(46))
		row:SetText("") row:SetCursor("hand")
		local sSize = math.floor(f.size / 1024) .. " Ko"
		row.Paint = function(s, w, h)
			draw.RoundedBox(6, 0, 0, w, h, Color(255, 255, 255, s:IsHovered() and 24 or 10))
			draw.SimpleText(f.name, "Avenir Next World:18", R(12), h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sSize, "Avenir Next World:16", w - R(12), h / 2, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			frame:Remove()
			fPick(f.name)
		end
	end
end

-- ── ÉDITEUR (Utiliser une affiche vierge) ───────────────────────────────────
function A.OpenWrite()
	if IsValid(A._writeUI) then A._writeUI:Remove() end
	local frame = makeBackdrop()
	A._writeUI = frame

	-- Carte plus haute que les autres : à 2800 caractères la zone de texte doit
	-- rester lisible sans scroller à chaque phrase.
	local W, H = R(680), R(900)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end

	-- État du visuel : matériau de preview + drapeau "le serveur a bien reçu".
	local visMat, visSent = nil, false

	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		titleSlash("RÉDIGER L'AFFICHE", R(26), R(34), "Bebas Neue:42")
		draw.SimpleText("TITRE", "Bebas Neue:22", R(26), R(78), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("TEXTE", "Bebas Neue:22", R(26), R(158), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("VISUEL", "Bebas Neue:22", R(26), H - R(232), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	mkClose(card, W, frame)

	local titleE = vgui.Create("DTextEntry", card)
	titleE:SetPos(R(24), R(102)) titleE:SetSize(W - R(48), R(40))
	titleE:SetFont("Avenir Next World:20") titleE:SetDrawLanguageID(false)
	titleE:SetTextColor(COL_TITLE) titleE:SetCursorColor(COL_TITLE) titleE:SetPaintBackground(false)
	titleE:SetUpdateOnType(true)
	titleE.Paint = function(s, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Titre de l'affiche…", "Avenir Next World:20", R(10), h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	titleE.OnValueChange = function(s, v)
		if #v > A.MaxTitleLen then s:SetText(string.sub(v, 1, A.MaxTitleLen)) s:SetCaretPos(A.MaxTitleLen) end
	end

	local textE = vgui.Create("DTextEntry", card)
	textE:SetPos(R(24), R(182)) textE:SetSize(W - R(48), H - R(182) - R(266))
	textE:SetFont("Avenir Next World:20") textE:SetDrawLanguageID(false)
	textE:SetMultiline(true) textE:SetUpdateOnType(true)
	textE:SetTextColor(COL_TITLE) textE:SetCursorColor(COL_TITLE) textE:SetPaintBackground(false)
	textE.Paint = function(s, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Ce que l'affiche annonce…", "Avenir Next World:20", R(10), R(8), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local counter = vgui.Create("DLabel", card)
	counter:SetPos(R(24), H - R(258)) counter:SetSize(W - R(48), R(18))
	counter:SetFont("Avenir Next World:16") counter:SetTextColor(COL_DIM) counter:SetContentAlignment(6)
	counter:SetText("0/" .. A.MaxTextLen)
	textE.OnValueChange = function(s, v)
		if #v > A.MaxTextLen then s:SetText(string.sub(v, 1, A.MaxTextLen)) s:SetCaretPos(A.MaxTextLen) v = s:GetText() end
		counter:SetText(#v .. "/" .. A.MaxTextLen)
	end

	-- Aperçu du visuel choisi
	local prevW, prevH = R(200), R(132)
	local prev = vgui.Create("DPanel", card)
	prev:SetPos(R(24), H - R(206)) prev:SetSize(prevW, prevH)
	prev.Paint = function(_, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		if visMat then
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(visMat)
			-- Aperçu à l'échelle : une image large ne doit pas être écrasée.
			local iw, ih = visMat:Width(), visMat:Height()
			local k = math.min((w - 8) / math.max(iw, 1), (h - 8) / math.max(ih, 1))
			surface.DrawTexturedRect((w - iw * k) / 2, (h - ih * k) / 2, iw * k, ih * k)
		else
			draw.SimpleText("Aucun visuel", "Avenir Next World:17", w / 2, h / 2, COL_DIM,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	local statut = vgui.Create("DLabel", card)
	statut:SetPos(R(24) + prevW + R(14), H - R(76)) statut:SetSize(W - R(48) - prevW - R(14), R(20))
	statut:SetFont("Avenir Next World:16") statut:SetTextColor(COL_DIM)
	statut:SetText("")

	local function setVisual(sData, sErr, mat, sName)
		if not sData then
			visMat, visSent = nil, false
			statut:SetTextColor(COL_ACCENT)
			statut:SetText(sErr or "Visuel refusé.")
			return
		end
		visMat, visSent = mat, false
		statut:SetTextColor(COL_MUTED)
		statut:SetText("Envoi du visuel…")
		A.Upload(sData, function(bOk, sMsg)
			if not IsValid(statut) then return end
			visSent = bOk
			statut:SetTextColor(bOk and COL_OK or COL_ACCENT)
			statut:SetText(bOk and "Visuel prêt." or (sMsg ~= "" and sMsg or "Envoi échoué."))
			if not bOk then visMat = nil end
		end)
	end

	local bx, bw = R(24) + prevW + R(14), W - R(48) - prevW - R(14)
	local bCap = mkBtn(card, "CAPTURER L'ÉCRAN", false, function()
		frame:SetVisible(false)
		-- Une frame de délai : le panneau doit avoir disparu AVANT la capture.
		timer.Simple(0.05, function()
			A.Capture({}, function(sData, sErr, mat)
				if IsValid(frame) then frame:SetVisible(true) end
				setVisual(sData, sErr, mat, "capture")
			end)
		end)
	end)
	bCap:SetPos(bx, H - R(206)) bCap:SetSize(bw, R(38))

	-- Le sélecteur s'ouvre PAR DESSUS l'éditeur (sa propre fenêtre plein écran) :
	-- rouvrir l'éditeur effacerait le texte déjà saisi.
	local bFile = mkBtn(card, "CHOISIR UN FICHIER", false, function()
		OpenFolderPicker(function(sName)
			A.ReadFolderImage(sName, function(sData, sErr, mat) setVisual(sData, sErr, mat, sName) end)
		end)
	end)
	bFile:SetPos(bx, H - R(162)) bFile:SetSize(bw, R(38))

	local bClr = mkBtn(card, "RETIRER LE VISUEL", false, function()
		visMat, visSent = nil, false
		statut:SetText("")
	end)
	bClr:SetPos(bx, H - R(118)) bClr:SetSize(bw, R(38))

	local send = mkBtn(card, "RÉDIGER L'AFFICHE (consomme l'affiche vierge)", true, function()
		local sTitle = titleE:GetValue() or ""
		local sText  = textE:GetValue() or ""
		-- Titre optionnel : il faut un titre, un texte OU un visuel (miroir serveur).
		if string.Trim(sTitle) == "" and string.Trim(sText) == "" and not visSent then
			notify("L'affiche est vide : donne lui un titre, un texte ou un visuel.", true)
			return
		end
		if visMat and not visSent then
			notify("Le visuel n'est pas encore envoyé, patiente une seconde.", true)
			return
		end
		net.Start("EVO:Affiche:Create")
			net.WriteString(sTitle)
			net.WriteString(sText)
			net.WriteBool(visSent) -- sinon un visuel abandonné serait repris ici
		net.SendToServer()
		frame:Remove()
	end)
	send:SetPos(R(24), H - R(66)) send:SetSize(W - R(48), R(44))
end

-- ── LECTEUR ─────────────────────────────────────────────────────────────────
-- opts : { afficheId } détenteur (accrocher / montrer / donner / imprimer)
--        { shower }    quelqu'un te la montre (lecture seule)
-- Une affiche AU MUR ne passe pas par ici : E la prend directement, et son
-- contenu se lit sur la feuille elle même.
local function OpenViewer(sDocId, sTitle, sAuthor, nAt, sText, sImg, opts)
	opts = opts or {}
	if IsValid(A._viewUI) then A._viewUI:Remove() end
	local frame = makeBackdrop()
	A._viewUI = frame

	-- L'identifiant sert à réclamer le visuel au serveur : il doit être passé
	-- même quand aucun bouton de détenteur n'est affiché (affiche montrée,
	-- affiche accrochée), sinon l'image ne se charge jamais dans ces deux cas.
	if sImg and sImg ~= "" then A.EnsureImage(sDocId or "", sImg) end

	-- Pose de lecture : uniquement pour l'affiche qu'on DÉTIENT, puisqu'elle se
	-- tient en main. Devant une affiche au mur, on ne tient rien.
	if opts.afficheId then
		frame._holdAnim = true
		net.Start("EVO:Affiche:ReadStart")
			net.WriteString(opts.afficheId)
		net.SendToServer()
		local fPrev = frame.OnRemove
		frame.OnRemove = function(s)
			if fPrev then fPrev(s) end
			if not s._holdAnim then return end
			s._holdAnim = nil
			net.Start("EVO:Affiche:ReadStop")
			net.SendToServer()
		end
	end

	local bBtns = opts.afficheId ~= nil
	-- Même hauteur que l'éditeur : un article de 2800 caractères se lit mal dans
	-- une lucarne (le corps reste scrollable de toute façon).
	local W, H = R(680), R(900)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end

	local sWhen = os.date("%d/%m à %H:%M", nAt or os.time())
	local nTop  = opts.shower and R(126) or R(108)
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		local y = R(34)
		if opts.shower then
			draw.SimpleText(opts.shower .. " te montre une affiche :", "Avenir Next World:18", R(26), R(14),
				COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			y = R(52)
		end
		-- Sans titre : rien n'est écrit à sa place (user 08/26), la signature monte.
		if sTitle ~= "" then titleSlash(sTitle, R(26), y, "Bebas Neue:42") end
		draw.SimpleText(((sAuthor or "") ~= "" and ("Rédigée par " .. sAuthor .. " · ") or "") .. sWhen, "Avenir Next World:16",
			R(26), sTitle ~= "" and (y + R(30)) or y, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	mkClose(card, W, frame)

	-- Visuel : hauteur fixe, l'image est ajustée dedans sans déformation.
	local nImgH = 0
	if sImg and sImg ~= "" then
		nImgH = R(250)
		local img = vgui.Create("DPanel", card)
		img:SetPos(R(24), nTop) img:SetSize(W - R(48), nImgH)
		img.Paint = function(_, w, h)
			if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
			local mat = A.PosterMat(sImg)
			if not mat then
				local bGone = A.ImgGone and A.ImgGone[sImg]
				draw.SimpleText(bGone and "Visuel indisponible" or "Chargement du visuel…",
					"Avenir Next World:17", w / 2, h / 2, bGone and COL_MUTED or COL_DIM,
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				return
			end
			local iw, ih = mat:Width(), mat:Height()
			local k = math.min((w - 8) / math.max(iw, 1), (h - 8) / math.max(ih, 1))
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(mat)
			surface.DrawTexturedRect((w - iw * k) / 2, (h - ih * k) / 2, iw * k, ih * k)
		end
		nImgH = nImgH + R(12)
	end

	local nBottom = bBtns and R(84) or R(24)
	local scroll = vgui.Create("DScrollPanel", card)
	scroll:SetPos(R(24), nTop + nImgH)
	scroll:SetSize(W - R(48), H - nTop - nImgH - nBottom)
	scroll.Paint = function(_, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
	end
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	local lbl = vgui.Create("DLabel", scroll)
	lbl:Dock(TOP) lbl:DockMargin(R(12), R(10), R(12), R(10))
	lbl:SetFont("Avenir Next World:20") lbl:SetTextColor(COL_TITLE)
	lbl:SetWrap(true) lbl:SetAutoStretchVertical(true)
	lbl:SetText(sText ~= "" and sText or " ")

	if not opts.afficheId then return end
	local id = opts.afficheId
	-- Animateur / SA : 5e bouton « VERROUILLÉE » (affiche officielle sans expiration,
	-- remise au mur après un redémarrage, retirée par le STAFF seul : A.CanUnlock).
	-- Le serveur revalide le droit à la pose.
	local bAnim = A.CanLock and A.CanLock(LocalPlayer())
	local nCols = bAnim and 5 or 4
	local bw = (W - R(48) - R(8) * (nCols - 1)) / nCols
	local nBy = H - R(66)
	local nCol = 0
	local function place(b) b:SetPos(R(24) + (bw + R(8)) * nCol, nBy) b:SetSize(bw, R(44)) nCol = nCol + 1 end

	place(mkBtn(card, "ACCROCHER", true, function()
		frame:Remove()
		A.StartPlacement(id, false)
	end))
	if bAnim then
		place(mkBtn(card, "VERROUILLÉE", true, function()
			frame:Remove()
			A.StartPlacement(id, true)
		end))
	end
	place(mkBtn(card, "MONTRER", false, function()
		net.Start("EVO:Affiche:ShowNearby") net.WriteString(id) net.SendToServer()
	end))
	place(mkBtn(card, "DONNER", false, function()
		net.Start("EVO:Affiche:GiveNearby") net.WriteString(id) net.SendToServer()
		frame:Remove()
	end))
	place(mkBtn(card, "IMPRIMER", false, function()
		frame:Remove()
		A.OpenPrint(id, sTitle)
	end))
end

-- ── IMPRESSION : combien de copies ? ────────────────────────────────────────
function A.OpenPrint(id, sTitle)
	local frame = makeBackdrop()
	local W, H = R(520), R(300)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		titleSlash("IMPRIMER", R(26), R(34), "Bebas Neue:40")
		if (sTitle or "") ~= "" then draw.SimpleText("« " .. sTitle .. " »", "Avenir Next World:17", R(26), R(64),
			COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) end
		draw.SimpleText("Chaque copie consomme une affiche vierge.", "Avenir Next World:16", R(26), R(90),
			COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	mkClose(card, W, frame)

	local tQty = { 1, 3, 5, A.MaxPrint }
	local bw = (W - R(48) - R(24)) / #tQty
	for i, n in ipairs(tQty) do
		local b = mkBtn(card, n .. (n > 1 and " COPIES" or " COPIE"), i == 1, function()
			net.Start("EVO:Affiche:Print")
				net.WriteString(id)
				net.WriteUInt(n, 8)
			net.SendToServer()
			frame:Remove()
		end)
		b:SetPos(R(24) + (bw + R(8)) * (i - 1), H - R(86)) b:SetSize(bw, R(48))
	end
end

-- ── Lecture d'une affiche détenue ───────────────────────────────────────────
-- netgate: edge — appelée depuis le rendu d'une affiche dont la définition manque,
-- mais ne parle au serveur qu'une fois toutes les 5 secondes au maximum.
function A.AskDefs()
	if (A._defsAskAt or 0) > CurTime() then return end
	A._defsAskAt = CurTime() + 5
	net.Start("EVO:Affiche:RequestDefs")
	net.SendToServer()
end

function A.OpenRead(id)
	if id and not A.Defs[id] then A.AskDefs() end
	A._pendingRead = id
	net.Start("EVO:Affiche:RequestText") net.WriteString(id) net.SendToServer()
end

net.Receive("EVO:Affiche:Text", function()
	local id     = net.ReadString()
	local sTitle = net.ReadString()
	local sText  = net.ReadString()
	local sAuth  = net.ReadString()
	local sImg   = net.ReadString()
	local nAt    = net.ReadUInt(32)
	if A._pendingRead ~= id then return end
	A._pendingRead = nil
	OpenViewer(id, sTitle, sAuth, nAt, sText, sImg, { afficheId = id })
end)

net.Receive("EVO:Affiche:Shown", function()
	local sWho   = net.ReadString()
	local id     = net.ReadString()
	local sTitle = net.ReadString()
	local sText  = net.ReadString()
	local sAuth  = net.ReadString()
	local sImg   = net.ReadString()
	local nAt    = net.ReadUInt(32)
	OpenViewer(id, sTitle, sAuth, nAt, sText, sImg, { shower = sWho })
end)

-- ── Defs -> items d'inventaire CLIENT ───────────────────────────────────────
local function installDef(d)
	A.Defs[d.id] = d
	-- ⚠️ PAS de EnsureImage ici. Une définition ne sert qu'à nommer un item et à
	-- dessiner un titre ; réclamer le visuel de CHAQUE affiche du serveur à la
	-- connexion ferait descendre des dizaines de Mo par joueur. Le tirage est
	-- paresseux : le rendu d'une affiche vraiment visible, ou l'ouverture du
	-- lecteur, s'en chargent.
end
local function readDef()
	return {
		id = net.ReadString(), title = net.ReadString(), ownerName = net.ReadString(),
		img = net.ReadString(), excerpt = net.ReadString(), createdAt = net.ReadUInt(32),
	}
end

net.Receive("EVO:Affiche:DefAdd", function() installDef(readDef()) end)
net.Receive("EVO:Affiche:DefRemove", function()
	local id = net.ReadString()
	A.Defs[id] = nil
end)
net.Receive("EVO:Affiche:DefAll", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do installDef(readDef()) end
end)

-- Fermeture imposée par le serveur (dégâts pendant la lecture) : la pose est
-- déjà coupée là-bas, on ne renvoie pas de ReadStop.
net.Receive("EVO:Affiche:ForceClose", function()
	if not IsValid(A._viewUI) then return end
	A._viewUI._holdAnim = nil
	A._viewUI:Remove()
end)

-- Force la pose de lecture sur TOUS les clients qui voient un porteur. Sans ça,
-- ply:Animation n'ayant émis qu'en PVS, un joueur arrivé après ne verrait rien.
local tPoseSeq = {}
hook.Add("UpdateAnimation", "EVO_Affiche::HoldPose", function(ply)
	if not IsValid(ply) then return end
	if not ply:GetEvoNWBool("EVO::IsHoldingAffiche", false) then
		ply._affPoseSet = nil
		return
	end
	local sKey = ply:GetModel()
	local nSeq = tPoseSeq[sKey]
	if nSeq == nil then
		nSeq = ply:LookupSequence("evo_hwndw1d2gtqzzdvkf") or -1
		tPoseSeq[sKey] = nSeq
	end
	if nSeq <= 0 then return end
	-- Un seul ResetSequence : le rejouer chaque frame figerait l'animation.
	if not ply._affPoseSet then
		ply:ResetSequence(nSeq)
		ply:SetCycle(0)
		ply._affPoseSet = true
	end
	ply:SetPlaybackRate(1)
	return true
end)

-- ── Rappel « [E] » devant une affiche accrochée ─────────────────────────────
-- Même présentation que les points « S'asseoir » (evo_assise) : pastille accent
-- avec la touche, libellé à côté, fond discret. Le libellé annonce la PRISE :
-- sans ça, rien ne dit qu'on peut décrocher une affiche et la mettre au sac.
if gCreateRespFont then
	gCreateRespFont("EVO_Affiche_PromptKey", "Bebas Neue", 20, 700)
	gCreateRespFont("EVO_Affiche_PromptTxt", "Bebas Neue", 24, 700)
else
	surface.CreateFont("EVO_Affiche_PromptKey", { font = "Bebas Neue", size = 20, weight = 700, extended = true })
	surface.CreateFont("EVO_Affiche_PromptTxt", { font = "Bebas Neue", size = 24, weight = 700, extended = true })
end

local COL_PROMPT_BG = Color(8, 8, 11, 205)
local nNextScan, entNear = 0, nil

--- L'affiche accrochée la plus proche, re-cherchée au plus 6 fois par seconde :
--- le rappel vit dans HUDPaint, hors de question de balayer à chaque frame.
local function nearestPlaced(lp)
	if CurTime() < nNextScan then return IsValid(entNear) and entNear or nil end
	nNextScan = CurTime() + 0.15
	entNear = nil
	local vMe, bestD = lp:GetPos(), nil
	for _, e in ipairs(ents.FindInSphere(vMe, A.HintRange)) do
		if e:GetClass() == "evo_affiche_murale" then
			local d = e:GetPos():DistToSqr(vMe)
			if not bestD or d < bestD then entNear, bestD = e, d end
		end
	end
	return entNear
end

--- Le joueur peut-il agir sur une affiche là, maintenant ?
local function promptTarget()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return nil end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return nil end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return nil end
	if vgui.CursorVisible() then return nil end
	local ent = nearestPlaced(lp)
	-- Affiche VERROUILLÉE : pas d'invite « Prendre » (ni de touche) hors STAFF.
	-- Même verdict que le serveur (A.CanUnlock, sh_config) : une invite qui
	-- s'affiche pour un refus est pire que pas d'invite du tout.
	if IsValid(ent) and ent.GetLocked and ent:GetLocked() and not A.CanUnlock(lp) then return nil end
	return ent, lp
end

-- Touche USE détectée CÔTÉ CLIENT, comme les points « S'asseoir » : le +use du
-- moteur ne porte pas de façon fiable sur une entité plaquée contre un mur, donc
-- l'appui est lu ici et le serveur revalide la distance.
local bWasUse = false
hook.Add("Think", "EVO_Affiche::TakeKey", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then bWasUse = false return end
	-- KeyDown(IN_USE) et pas la touche physique : le joueur peut avoir rebindé.
	local bDown = lp:KeyDown(IN_USE)
	local bEdge = bDown and not bWasUse
	bWasUse = bDown
	if not bEdge then return end
	local ent = promptTarget()
	if not ent then return end
	-- Ne pas voler le E d'une entité usable visée de plus près (PNJ, porte).
	local tr = lp:GetEyeTrace()
	if IsValid(tr.Entity) and tr.Entity ~= ent and tr.Entity:EntIndex() > 0
		and tr.HitPos:DistToSqr(lp:EyePos()) < 70 * 70 then
		return
	end
	if EVO_AFFICHE.SendTake then EVO_AFFICHE.SendTake(ent) end
end)

-- netgate: edge — un seul envoi par appui (front montant bWasUse).
function A.SendTake(ent)
	net.Start("EVO:Affiche:Take")
		net.WriteEntity(ent)
	net.SendToServer()
end

hook.Add("HUDPaint", "EVO_Affiche::Prompt", function()
	if not promptTarget() then return end
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(ScrW() * 0.5, ScrH() * 0.5 + R(66), "Affiche", "Prendre", "E")
		return
	end

	local sTxt = "Prendre"
	surface.SetFont("EVO_Affiche_PromptTxt")
	local nTw = surface.GetTextSize(sTxt)
	local nKey, nGap = R(13), R(9)
	local nTotal = nKey * 2 + nGap + nTw
	local nCx, nCy = ScrW() * 0.5, ScrH() * 0.5 + R(66)
	local nX0 = nCx - nTotal * 0.5
	local nPadX, nPadY = R(10), R(7)

	draw.RoundedBox(R(6), nX0 - nPadX, nCy - nKey - nPadY, nTotal + nPadX * 2, nKey * 2 + nPadY * 2, COL_PROMPT_BG)
	draw.RoundedBox(R(4), nX0, nCy - nKey, nKey * 2, nKey * 2, COL_ACCENT)
	draw.SimpleText("E", "EVO_Affiche_PromptKey", nX0 + nKey, nCy + R(1), color_white,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sTxt, "EVO_Affiche_PromptTxt", nX0 + nKey * 2 + nGap, nCy, COL_TITLE,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)

-- ⚠️ Gardien PERMANENT : l'inventaire ré-assigne ITEMS à son include, un timer
-- qui se retire au premier succès laisserait tous nos items disparaître.
timer.Create("EVO_Affiche::EnsureItemsCL", 2, 0, function()
	if not istable(ITEMS) then return end
	if not ITEMS[A.BlankItemId] then A.RegisterBlankItem() end
	if not ITEMS[A.WrittenItemId] then A.RegisterWrittenItem() end
end)
A.RegisterBlankItem()
A.RegisterWrittenItem()
