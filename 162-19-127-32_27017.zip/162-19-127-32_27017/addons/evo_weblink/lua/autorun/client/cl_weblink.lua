-- "addons\\evo_weblink\\lua\\autorun\\client\\cl_weblink.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO WEBLINK — EVO_OpenWeb(url, title) : ouvre une page web DANS LE JEU
-- (fenêtre DHTML, DA EVO). Pourquoi : gui.OpenURL ne fait qu'ouvrir l'OVERLAY
-- Steam — s'il est désactivé/capricieux, RIEN ne s'affiche ("ça n'ouvre pas").
-- Ici la fenêtre s'ouvre toujours, avec en secours : [Ouvrir via Steam]
-- (overlay) et [Copier le lien] (à coller dans un vrai navigateur).
-- Fermeture : Échap (globale openedFrame, hook OnPauseMenuShow de
-- lzy_escape_menu) ou la croix. Réutilisé par : boutique coins (lzy_shop),
-- boutons Discord/TikTok/Steam du menu Échap.
-- ============================================================================
if not CLIENT then return end

-- 1 = réaffiche dans la console les messages JS/HTML des pages ouvertes (debug).
CreateClientConVar("evo_weblink_debug", "0", true, false)

local COL_BG     = Color(14, 14, 17, 250)
local COL_PANEL  = Color(28, 28, 33, 255)
local COL_HOVER  = Color(40, 40, 46, 255)
local COL_ACCENT = Color(207, 68, 78)
local COL_TXT    = Color(235, 235, 240)
local COL_MUTED  = Color(150, 154, 162)
local COL_OK     = Color(78, 196, 128)

-- Barre AGRANDIE (demande user : tout était trop petit sur l'UI d'achat de coins).
-- Titre en Bebas (DA Seireitei) ; le reste en Roboto (texte courant).
surface.CreateFont("EVO_Web_Title", { font = "Bebas Neue", size = 30, weight = 700, extended = true })
surface.CreateFont("EVO_Web_Btn",   { font = "Roboto", size = 20, weight = 600, extended = true })
surface.CreateFont("EVO_Web_Hint",  { font = "Roboto", size = 17, weight = 500, extended = true })
surface.CreateFont("EVO_Web_X",     { font = "Roboto", size = 30, weight = 600, extended = true })
surface.CreateFont("EVO_Web_At",    { font = "Roboto", size = 26, weight = 800, extended = true })

function EVO_OpenWeb(url, title)
	if not isstring(url) or url == "" then return end
	if IsValid(EVO_WebFrame) then EVO_WebFrame:Remove() end

	local w, h = math.floor(ScrW() * 0.8), math.floor(ScrH() * 0.85)
	local TOP = 78 -- barre haute AGRANDIE (boutons + fontes plus gros)

	local frame = vgui.Create("DFrame")
	EVO_WebFrame = frame
	frame:SetSize(w, h)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	-- Fermeture Échap : pattern standard du projet (le moteur n'envoie pas
	-- KEY_ESCAPE à OnKeyCodePressed) -> openedFrame fermé par lzy_escape_menu.
	-- On RESTAURE l'openedFrame précédent à la fermeture : ouverte depuis une UI
	-- qui l'utilise aussi (ex: le shop), elle récupère sa fermeture Échap —
	-- sinon le 2e Échap ouvrirait le menu pause PAR-DESSUS l'UI restée ouverte.
	local prevOpened = openedFrame
	openedFrame = frame
	frame.OnRemove = function(s)
		if openedFrame == s then
			openedFrame = IsValid(prevOpened) and prevOpened or nil
		end
	end
	frame.Paint = function(s, ww, hh)
		-- DA « Seireitei » : coins coupés 45° + liseré 1px, titre Bebas + entaille
		-- (remplace l'arrondi + la barre accent pleine largeur).
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(0, 0, ww, hh, COL_BG, 14)
			EVO_UI.OutlineCut(pts, Color(255, 255, 255, 20))
		else
			draw.RoundedBox(0, 0, 0, ww, hh, COL_BG)
		end
		draw.SimpleText(title or "Site EVO", "EVO_Web_Title", 18, TOP / 2 - 6, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.TitleSlash then
			surface.SetFont("EVO_Web_Title")
			local tw = surface.GetTextSize(title or "Site EVO")
			EVO_UI.TitleSlash(16, TOP / 2 + 8, tw)
		end
		-- Explication du bouton @ (les claviers AZERTY ne peuvent pas taper @ en jeu),
		-- alignée juste à gauche du bouton @.
		if s._hintX then
			draw.SimpleText("Utilise ce @ si besoin pour ton mail (le clavier ne le tape pas en jeu) →",
				"EVO_Web_Hint", s._hintX, TOP / 2, COL_MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	-- × fermer
	local closeB = vgui.Create("DButton", frame)
	closeB:SetText("") closeB:SetSize(40, 40) closeB:SetPos(w - 50, (TOP - 40) / 2)
	closeB.Paint = function(s, bw, bh)
		draw.SimpleText("×", "EVO_Web_X", bw / 2, bh / 2 - 1, s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeB.DoClick = function() frame:Remove() end

	local html -- créé plus bas (référencé par le bouton @)

	-- Insère un caractère DANS le champ actif de la page, à la position du curseur,
	-- en déclenchant les événements input/change (validation des formulaires type
	-- Stripe). Pourquoi : le navigateur intégré de GMod (CEF) ne reçoit PAS les
	-- caractères AltGr (@, #, … sur AZERTY) -> impossible de taper un email.
	local function injectChar(c)
		if not IsValid(html) then return end
		html:RunJavascript([[
(function(){
	var el = document.activeElement;
	if (!el) return;
	if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
		var s = (el.selectionStart != null) ? el.selectionStart : el.value.length;
		var e = (el.selectionEnd   != null) ? el.selectionEnd   : el.value.length;
		el.value = el.value.slice(0, s) + ']] .. c .. [[' + el.value.slice(e);
		try { el.selectionStart = el.selectionEnd = s + 1; } catch (ex) {}
		el.dispatchEvent(new Event('input',  { bubbles: true }));
		el.dispatchEvent(new Event('change', { bubbles: true }));
	} else if (el.isContentEditable) {
		document.execCommand('insertText', false, ']] .. c .. [[');
	}
})();
]])
	end

	-- Boutons d'appoint (droite -> gauche) : [@] [Copier le lien] [Ouvrir via Steam] [×]
	-- AGRANDIS (hauteur 40, fontes 20) — demande user sur l'UI d'achat de coins.
	local BTN_H = 40
	local function makeBtn(label, rightEdge, wide, fn)
		local b = vgui.Create("DButton", frame)
		b:SetText("") b:SetSize(wide, BTN_H) b:SetPos(rightEdge - wide, (TOP - BTN_H) / 2)
		b.Paint = function(s, bw, bh)
			-- flat carré + liseré 1px (DA : plus d'arrondi)
			surface.SetDrawColor(s:IsHovered() and COL_HOVER or COL_PANEL)
			surface.DrawRect(0, 0, bw, bh)
			surface.SetDrawColor(255, 255, 255, s:IsHovered() and 34 or 18)
			surface.DrawOutlinedRect(0, 0, bw, bh)
			draw.SimpleText(s._fb or label, "EVO_Web_Btn", bw / 2, bh / 2, s._fb and COL_OK or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function(s) fn(s) end
		return b
	end
	local steamB = makeBtn("Ouvrir via Steam", w - 50 - 12, 210, function()
		gui.OpenURL(url) -- overlay Steam (si activé)
	end)
	local copyB = makeBtn("Copier le lien", steamB:GetX() - 10, 180, function(s)
		SetClipboardText(url)
		s._fb = "Lien copié !"
		timer.Simple(2, function() if IsValid(s) then s._fb = nil end end)
	end)
	-- Tape un @ dans le champ actif (l'AltGr ne marche pas dans le navigateur GMod).
	-- Bouton ACCENT bien visible + texte d'explication peint à sa gauche (frame.Paint).
	local atB = makeBtn("@", copyB:GetX() - 10, 56, function() injectChar("@") end)
	atB.Paint = function(s, bw, bh)
		-- bouton d'action DA : aplat accent, coin bas-droit coupé
		local c = s:IsHovered() and Color(226, 84, 94) or COL_ACCENT
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, bw, bh, c, 10, "br")
		else
			draw.RoundedBox(0, 0, 0, bw, bh, c)
		end
		draw.SimpleText("@", "EVO_Web_At", bw / 2, bh / 2 - 1, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	atB:SetTooltip("Insérer un @ dans le champ sélectionné (AltGr ne marche pas en jeu)")
	frame._hintX = atB:GetX() - 14 -- ancre du texte d'explication (aligné à droite)

	-- La page, dans le jeu (Chromium intégré).
	html = vgui.Create("DHTML", frame)
	html:SetPos(8, TOP)
	html:SetSize(w - 16, h - TOP - 8)
	-- Coupe le bruit console des pages web : par défaut DHTML imprime chaque message
	-- JS/HTML de la page dans la console GMod ("[HTML] [Warn] <link rel=preload>…",
	-- typique de Stripe sur le Chromium intégré qui ne connaît pas ces optimisations).
	-- Inoffensif mais ça spamme — réactivable avec evo_weblink_debug 1 pour déboguer.
	html.ConsoleMessage = function(_, msg)
		local cv = GetConVar("evo_weblink_debug")
		if cv and cv:GetBool() then print("[evo_weblink] " .. tostring(msg)) end
	end
	html:OpenURL(url)
end
