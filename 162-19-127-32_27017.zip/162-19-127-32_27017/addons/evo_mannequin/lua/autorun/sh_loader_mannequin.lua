-- "addons\\evo_mannequin\\lua\\autorun\\sh_loader_mannequin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- evo_mannequin — mannequins d'entraînement statiques.
-- Même idée que ncm_forge : entité + positions auto par map.
-- L'entité (lua/entities/evo_mannequin) s'enregistre toute seule.
-- ============================================================

if SERVER then
    AddCSLuaFile("evo_mannequin/sh_config.lua")
    include("evo_mannequin/sh_config.lua")
    include("evo_mannequin/sv_autospawn.lua")
else
    include("evo_mannequin/sh_config.lua")
end
