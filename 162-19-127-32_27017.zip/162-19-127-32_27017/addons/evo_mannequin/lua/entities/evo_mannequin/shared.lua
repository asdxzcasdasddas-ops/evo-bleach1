-- "addons\\evo_mannequin\\lua\\entities\\evo_mannequin\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Base = "base_nextbot"
ENT.Type = "nextbot"
ENT.PrintName = "Mannequin d'entraînement"
ENT.Author = "EVO"
ENT.Spawnable = false
ENT.AdminSpawnable = false

-- Compteur de dégâts au-dessus de la tête : cumul depuis le début de la rafale,
-- remis à zéro après 5 s sans coup (même fenêtre que la réparation des PV).
-- DTVars moteur (PVS) : rien à router côté LZY_PlyState.
function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "DmgAccum")
    self:NetworkVar("Float", 0, "LastHit")
end
