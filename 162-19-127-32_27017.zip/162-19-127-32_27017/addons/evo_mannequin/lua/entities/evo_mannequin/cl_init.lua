-- "addons\\evo_mannequin\\lua\\entities\\evo_mannequin\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- Plaques « Mannequin d'entraînement » + cumul de dégâts, au-dessus de la tête.
-- Dessinées depuis un hook GLOBAL et PAS ENT:Draw : derrière un objet, le moteur
-- peut occlusion-culler l'entité -> son Draw ne tourne plus et la plaque
-- disparaissait. Le hook tourne tant que le mannequin existe côté client (PVS),
-- et IgnoreZ garde les plaques visibles par-dessus le décor.
surface.CreateFont("EVO_Mannequin_Tag", {
    font      = "Roboto",
    size      = 64,
    weight    = 800,
    antialias = true,
})
surface.CreateFont("EVO_Mannequin_Dmg", {
    font      = "Roboto",
    size      = 78,
    weight    = 900,
    antialias = true,
})

local TAG_TEXT  = "Mannequin d'entraînement"
local TAG_DIST  = 350 -- visible d'assez loin : le mannequin sert de cible, il doit se repérer
local DMG_WINDOW = 5  -- s sans coup avant que le cumul disparaisse (= REGEN_DELAY serveur)
local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local COL_DMG     = Color(240, 95, 100, 255)

local nTagTW, nTagTH -- taille du nom, calculée une fois (libellé statique)

function ENT:Draw()
    self:DrawModel()
end

local function DrawPlaques(ent, ePos)
    if not nTagTW then
        surface.SetFont("EVO_Mannequin_Tag")
        nTagTW, nTagTH = surface.GetTextSize(TAG_TEXT)
    end

    -- Cumul de dégâts de la rafale en cours (DTVars serveur), affiché tant que le
    -- dernier coup date de moins de 5 s. Chaîne + mesure mémoïsées par valeur.
    local nDmg = ent:GetDmgAccum()
    local bShowDmg = nDmg > 0 and (CurTime() - ent:GetLastHit()) <= DMG_WINDOW
    if bShowDmg and ent._dmgVal ~= nDmg then
        ent._dmgVal = nDmg
        ent._dmgStr = (string.Comma(nDmg):gsub(",", " ")) .. (nDmg >= 2 and " dégâts" or " dégât")
        surface.SetFont("EVO_Mannequin_Dmg")
        ent._dmgTW, ent._dmgTH = surface.GetTextSize(ent._dmgStr)
    end

    local top = ent:OBBMaxs().z
    if not isnumber(top) or top <= 0 then top = 72 end
    local pos = ePos + Vector(0, 0, top + 14)
    local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

    cam.IgnoreZ(true)
    cam.Start3D2D(pos, ang, 0.12)
        draw.RoundedBox(0, -nTagTW * 0.5 - 16, -nTagTH * 0.5 - 6, nTagTW + 32, nTagTH + 12, COL_TAG_BG)
        draw.SimpleText(TAG_TEXT, "EVO_Mannequin_Tag", 0, 0,
            COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if bShowDmg and ent._dmgStr then
            local nDmgY = -(nTagTH * 0.5 + 6) - (ent._dmgTH or 0) * 0.5 - 10
            draw.RoundedBox(0, -(ent._dmgTW or 0) * 0.5 - 16, nDmgY - (ent._dmgTH or 0) * 0.5 - 6,
                (ent._dmgTW or 0) + 32, (ent._dmgTH or 0) + 12, COL_TAG_BG)
            draw.SimpleText(ent._dmgStr, "EVO_Mannequin_Dmg", 0, nDmgY,
                COL_DMG, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    cam.End3D2D()
    cam.IgnoreZ(false)
end

-- Liste des mannequins rafraîchie toutes les 2 s (rien d'alloué par frame).
local tMannequins, nNextScan = {}, 0

hook.Add("PostDrawTranslucentRenderables", "EVO_Mannequin::Plaques", function(bDepth, bSky)
    if bDepth or bSky then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local now = CurTime()
    if now >= nNextScan then
        nNextScan = now + 2
        tMannequins = ents.FindByClass("evo_mannequin")
    end
    if #tMannequins == 0 then return end

    local vMe = lp:GetPos()
    for i = 1, #tMannequins do
        local ent = tMannequins[i]
        if IsValid(ent) then
            local ePos = ent:GetPos()
            if ePos:DistToSqr(vMe) <= TAG_DIST * TAG_DIST then
                DrawPlaques(ent, ePos)
            end
        end
    end
end)
