-- "addons\\evo_mannequin\\lua\\evo_mannequin\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- sh_config.lua — Config evo_mannequin
-- ============================================================

EVO_MANNEQUIN = EVO_MANNEQUIN or {}

EVO_MANNEQUIN.ENTITY_CLASS = "evo_mannequin"

-- Modèle DÉDIÉ du mannequin d'entraînement (user 08/19) : le même partout,
-- plus de corps shinigami/arrancar par map. ⚠ casse du fichier respectée
-- (serveur Linux sensible à la casse).
EVO_MANNEQUIN.DEFAULT_MODEL = "models/evo/props/items/evo_ez2tdezrg45453tfbj/evo_ez2tdezRG45453TFbj.mdl"

-- Positions par map (user 08/17). Le Z est resnappé au sol par TraceLine dans
-- sv_autospawn (comme la forge) ; yaw BRUT du setang (jamais +180).
-- (Sans champ `model`, chaque spawn prend DEFAULT_MODEL.)
EVO_MANNEQUIN.AUTO_SPAWN_POSITIONS = {
    ["hueco_mundo_v1"] = {
        { pos = Vector(5062.823242, 4111.043945, 6472.724121), ang = Angle(0, 71.338562, 0) },
        { pos = Vector(5019.471680, 5855.803223, 6472.724121), ang = Angle(0, -47.101509, 0) },
        { pos = Vector(5539.229492, 5827.250488, 6472.724121), ang = Angle(0, -119.965561, 0) },
        -- Lot user 08/19.
        { pos = Vector(-6762.382324, 6647.929688, -5783.109375), ang = Angle(0, -64.189194, 0) },
        { pos = Vector(5075.880859, 1707.038940, 6472.724121), ang = Angle(0, -88.249725, 0) },
        { pos = Vector(-6222.581543, 6797.479004, -5779.790039), ang = Angle(0, -80.557129, 0) },
        { pos = Vector(-5080.515625, 6664.763184, -5736.176758), ang = Angle(0, -110.125114, 0) },
        { pos = Vector(11188.259766, 114.187889, 5480.695312), ang = Angle(0, -185.689941, 0) },
        { pos = Vector(11181.216797, -1208.573730, 5480.724121), ang = Angle(0, 173.782333, 0) },
        { pos = Vector(10045.489258, -2592.777100, 5480.695312), ang = Angle(0, 85.341759, 0) },
    },
    ["rp_seireitei_v1"] = {
        { pos = Vector(-15432.341797, 10480.963867, 574.642212), ang = Angle(0, 19.380016, 0) },
        { pos = Vector(-15471.660156, 10991.695312, 574.723938), ang = Angle(0, -0.551917, 0) },
        { pos = Vector(-15487.220703, 11463.939453, 574.723938), ang = Angle(0, 3.672062, 0) },
        -- Lot user 08/19.
        { pos = Vector(-12442.199219, -3518.748535, 574.725830), ang = Angle(0, 35.819595, 0) },
        { pos = Vector(-12061.476562, -3724.988525, 574.725830), ang = Angle(0, 76.211586, 0) },
        { pos = Vector(-12529.693359, -2858.571289, 574.732056), ang = Angle(0, 6.383603, 0) },
        { pos = Vector(-15126.975586, -14157.436523, 565.723938), ang = Angle(0, 34.403496, 0) },
        { pos = Vector(-14803.408203, -14405.688477, 565.723938), ang = Angle(0, 53.015491, 0) },
        { pos = Vector(-14424.367188, -14563.696289, 565.723938), ang = Angle(0, 56.711491, 0) },
        { pos = Vector(14174.835938, -12081.695312, 590.723938), ang = Angle(0, 89.219315, 0) },
        { pos = Vector(13679.655273, -12086.020508, 590.723938), ang = Angle(0, 90.143318, 0) },
        { pos = Vector(14710.395508, -12053.800781, 590.723938), ang = Angle(0, 90.275429, 0) },
        { pos = Vector(13673.238281, -8151.561523, 590.723938), ang = Angle(0, -90.468414, 0) },
        { pos = Vector(14205.197266, -8138.903809, 590.723938), ang = Angle(0, -90.732361, 0) },
        { pos = Vector(14698.718750, -8159.004395, 590.723938), ang = Angle(0, -89.544472, 0) },
        { pos = Vector(6735.693359, -12662.316406, 566.723877), ang = Angle(0, 89.483459, 0) },
        { pos = Vector(6135.941406, -12657.242188, 566.723877), ang = Angle(0, 86.051491, 0) },
        { pos = Vector(5393.734375, -12727.326172, 571.057678), ang = Angle(0, 88.559448, 0) },
    },
}
