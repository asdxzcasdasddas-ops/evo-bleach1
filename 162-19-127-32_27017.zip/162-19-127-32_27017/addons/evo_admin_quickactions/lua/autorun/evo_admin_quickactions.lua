-- "addons\\evo_admin_quickactions\\lua\\autorun\\evo_admin_quickactions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ════════════════════════════════════════════════════════════════════
--  EVO ADMIN — ACTIONS RAPIDES (Super Admin uniquement)
--  Onglets par FACTION -> liste des joueurs -> clic sur un joueur = panneau
--  d'actions qui se déplie juste en dessous (accordéon).
--  SÉCURITÉ : ouverture gatée client IsSuperAdmin, mais surtout CHAQUE action
--  est revalidée ply:IsSuperAdmin() CÔTÉ SERVEUR (net appelable par tout client).
--  Ouvrir : console `evo_admin` (ou `evo_aqa`) -> à binder.
-- ════════════════════════════════════════════════════════════════════

if SERVER then
    util.AddNetworkString("evo_aqa_action")
    util.AddNetworkString("evo_aqa_spec") -- serveur -> client : autorise le POV spectate
    util.AddNetworkString("evo_aqa_spec_end") -- client -> serveur : sortie du spectate (Échap)

    -- Fin de surveillance (Échap client / cible invalide) : on coupe juste le PVS secondaire
    -- + le routage voix. RIEN à restaurer : l'admin n'a JAMAIS été déplacé.
    net.Receive("evo_aqa_spec_end", function(_, ply)
        ply._aqaSpecTarget = nil
    end)

    -- SURVEILLANCE À DISTANCE SANS DÉPLACEMENT : on ajoute la zone de la cible au PVS de l'admin
    -- (caméra/PVS secondaire) -> son client reçoit la scène autour de la cible et peut la RENDRE
    -- dans une fenêtre, à n'importe quelle distance, SANS bouger le corps/la caméra de l'admin.
    hook.Add("SetupPlayerVisibility", "EVO_AQA_SpecPVS", function(ply, viewEnt)
        local t = ply._aqaSpecTarget
        if IsValid(t) then AddOriginToPVS(t:EyePos()) end
    end)

    -- Coupe la surveillance si l'admin OU la cible se déconnecte.
    hook.Add("PlayerDisconnected", "EVO_AQA_SpecCleanup", function(leaver)
        if IsValid(leaver) then leaver._aqaSpecTarget = nil end
        for _, a in player.Iterator() do
            if a._aqaSpecTarget == leaver then a._aqaSpecTarget = nil end
        end
    end)

    local function isSA(ply)
        return IsValid(ply) and ply:IsPlayer() and ply:IsSuperAdmin()
    end

    local function notify(admin, msg)
        if MUGEN and MUGEN.Notify then MUGEN.Notify(admin, msg)
        elseif IsValid(admin) then admin:ChatPrint("[Admin] " .. msg) end
    end

    -- GOD (action admin) : le GodEnable() natif ne suffit PAS — le pipeline de combat
    -- custom (lzy_stats / sorts / KO) applique les dégâts via EntityTakeDamage et IGNORE
    -- FL_GODMODE -> le joueur « god » prenait quand même des dégâts. On bloque donc
    -- EXPLICITEMENT, exactement comme le staff mode : SetDamage(0) + ScaleDamage(0) +
    -- return true (mute le dmginfo partagé quel que soit l'ordre des hooks). Préfixe
    -- "AAA" = passe avant les autres hooks de dégâts. Gated sur le NWBool aqa_god.
    hook.Add("EntityTakeDamage", "AAA::EVO::AQA::GodBlock", function(target, dmg)
        if not IsValid(target) or not target:IsPlayer() then return end
        if not target:GetEvoNWBool("aqa_god", false) then return end
        dmg:SetDamage(0)
        dmg:ScaleDamage(0)
        return true
    end)

    -- FREEZE (action admin) : le Freeze() natif peut être ANNULÉ par EvoUnfreeze du
    -- système de combat (fin de parade/sort/charge/throw -> Freeze(false) inconditionnel)
    -- -> le joueur « gelé » redevenait mobile dès qu'il était en combat. On verrouille
    -- donc AUSSI le mouvement via StartCommand tant que aqa_frozen est posé (input de
    -- déplacement + boutons vidés) : il reste bloqué même si le freeze moteur saute. La
    -- vue reste libre (freeze admin classique). Le dégel = l'admin retire aqa_frozen.
    hook.Add("StartCommand", "EVO_AQA_FreezeLock", function(ply, cmd)
        if not (IsValid(ply) and ply:GetEvoNWBool("aqa_frozen", false)) then return end
        cmd:ClearMovement()
        cmd:ClearButtons()
    end)

    -- Actions PAR JOUEUR : f(admin, target, extra). target déjà validé player valide.
    local PLAYER_ACTIONS = {
        heal    = function(a, t) t:SetHealth(t:GetMaxHealth()) end,
        kill    = function(a, t) t:Kill() end,
        respawn = function(a, t) t:Spawn() end,
        ["god"] = function(a, t)
            -- Source de vérité = NWBool aqa_god (lu par le hook de blocage ci-dessus),
            -- pas HasGodMode() natif qui peut être remis à zéro par d'autres systèmes.
            local on = not t:GetEvoNWBool("aqa_god", false)
            if on then t:GodEnable() else t:GodDisable() end
            t:SetEvoNWBool("aqa_god", on)
        end,
        freeze  = function(a, t)
            local on = not t:GetEvoNWBool("aqa_frozen", false)
            t:Freeze(on) ; t:SetEvoNWBool("aqa_frozen", on)
        end,
        mute_voice = function(a, t) t:SetEvoNWBool("aqa_mute_voice", not t:GetEvoNWBool("aqa_mute_voice", false)) end,
        mute_text  = function(a, t) t:SetEvoNWBool("aqa_mute_text",  not t:GetEvoNWBool("aqa_mute_text",  false)) end,
        -- Instance (domaine de clan, user 08/24) : bring ramène la cible dans NOTRE
        -- zone, goto nous emmène dans la sienne (NCM_INSTANCE.MatchZone, AVANT le SetPos).
        bring   = function(a, t)
            if NCM_INSTANCE and NCM_INSTANCE.MatchZone then NCM_INSTANCE.MatchZone(t, NCM_INSTANCE.GetZoneID(a), a) end
            t:SetPos(a:GetPos() + a:GetForward() * 60 + Vector(0, 0, 10)) t:SetVelocity(Vector(0,0,0))
        end,
        ["goto"]= function(a, t)
            if NCM_INSTANCE and NCM_INSTANCE.MatchZone then NCM_INSTANCE.MatchZone(a, NCM_INSTANCE.GetZoneID(t), a) end
            a:SetVelocity(-a:GetVelocity())
            a:SetPos(t:GetPos() + Vector(0, 0, 10))
        end,
        kick    = function(a, t, extra) t:Kick(extra ~= "" and extra or "Expulsé par un Super Admin") end,

        -- "Spectate" = SURVEILLANCE À DISTANCE SANS SE DÉPLACER (demande user). On ne touche NI
        -- à la position NI à la caméra de l'admin : il continue à jouer normalement. On pose juste
        -- _aqaSpecTarget, qui pilote DEUX choses :
        --   * SetupPlayerVisibility -> AddOriginToPVS(cible) : sa zone est networkée vers l'admin
        --     (sans le bouger) -> le client peut RENDRE sa vue dans une fenêtre (haut-droite).
        --   * lzy_voice -> l'admin ENTEND la voix de la cible + des joueurs autour d'elle (ce
        --     qu'elle entend), en 2D plein volume.
        -- Résultat : l'admin VOIT + ENTEND la POV de la cible dans une fenêtre, à toute distance.
        spectate = function(a, t)
            if a == t then notify(a, "Impossible de se regarder soi-même.") return end
            a._aqaSpecTarget = t
            net.Start("evo_aqa_spec")
            net.WriteEntity(t)
            net.Send(a)
        end,

        -- Warn via le système evo_warns (escalade auto -> ban gérée par EVO_Warn).
        warn = function(a, t, extra)
            if EVO_Warn then EVO_Warn(a, t, "Avertissement", extra or "") end
        end,

        -- Whitelist EVO (toggle, persistée en BDD via l'addon evo_whitelist).
        whitelist = function(a, t)
            if not (EVO_WL and EVO_WL.Add) then notify(a, "Système whitelist indisponible (addon evo_whitelist).") return end
            local sid = t:SteamID()
            if EVO_WL.Has(sid) then
                EVO_WL.Remove(sid)
                notify(a, t:Nick() .. " RETIRÉ de la whitelist.")
                if t.ChatPrint then t:ChatPrint("[Whitelist] Tu as été retiré de la whitelist.") end
            else
                EVO_WL.Add(sid, a:Nick())
                notify(a, t:Nick() .. " AJOUTÉ à la whitelist.")
                if t.ChatPrint then t:ChatPrint("[Whitelist] Tu as été ajouté à la whitelist !") end
            end
        end,

        -- Ban via SAM (méthode Player:sam_ban). extra = "minutes|raison". 0 min = définitif.
        ban = function(a, t, extra)
            local mins, reason = string.match(extra or "", "^(%-?%d+)|(.*)$")
            mins = tonumber(mins) or 0
            if reason == nil or reason == "" then reason = "Banni par un Super Admin" end
            if t.sam_ban then
                local ok = pcall(function() t:sam_ban(mins, reason) end)
                if not ok then t:Kick("Ban (fallback) : " .. reason) end
            else
                t:Kick("Ban indisponible (SAM absent) : " .. reason)
            end
        end,
    }

    local GLOBAL_ACTIONS = {
        heal_all     = function(a) for _, p in player.Iterator() do if p:Alive() then p:SetHealth(p:GetMaxHealth()) end end end,
        freeze_all   = function(a) for _, p in player.Iterator() do if p ~= a then p:Freeze(true) p:SetEvoNWBool("aqa_frozen", true) end end end,
        unfreeze_all = function(a) for _, p in player.Iterator() do p:Freeze(false) p:SetEvoNWBool("aqa_frozen", false) end end,
        announce     = function(a, _, extra)
            extra = string.sub(extra or "", 1, 200)
            if extra == "" then return end
            for _, p in player.Iterator() do p:PrintMessage(HUD_PRINTTALK, "[ANNONCE] " .. extra) end
        end,
    }

    net.Receive("evo_aqa_action", function(_, ply)
        if not isSA(ply) then return end -- ⚠ SÉCURITÉ : super admin uniquement

        local action = net.ReadString()
        local target = net.ReadEntity()
        local extra  = net.ReadString()

        local g = GLOBAL_ACTIONS[action]
        if g then
            g(ply, nil, extra)
            ServerLog(("[EVO_AQA] %s -> global '%s'\n"):format(ply:Nick(), action))
            return
        end

        local f = PLAYER_ACTIONS[action]
        if not f then return end
        if not (IsValid(target) and target:IsPlayer()) then return end

        f(ply, target, extra)
        ServerLog(("[EVO_AQA] %s -> '%s' sur %s\n"):format(ply:Nick(), action, target:Nick()))
        notify(ply, action .. " sur " .. target:Nick())
    end)

    -- MUTE (gag chat + voix)
    hook.Add("PlayerSay", "EVO_AQA_MuteChat", function(speaker)
        if IsValid(speaker) and speaker:GetEvoNWBool("aqa_mute_text", false) then return "" end
    end)
    hook.Add("PlayerCanHearPlayersVoice", "EVO_AQA_MuteVoice", function(listener, talker)
        if IsValid(talker) and talker:GetEvoNWBool("aqa_mute_voice", false) then return false end
    end)

    return
end

-- ════════════════════════════════════════════════════════════════════
--  CLIENT
-- ════════════════════════════════════════════════════════════════════

-- Échelle UNIFORME (facteur min largeur/hauteur) pour un panneau CENTRÉ : garde les
-- proportions sur TOUT ratio (16:10, ultrawide 21:9, 4:3). gRespX/gRespY scalent PAR AXE
-- (largeur/hauteur séparément) -> ça déformait la carte + désalignait texte/boîtes sur
-- écran non-16:9. Sur 16:9 c'est identique. (Même approche que le menu support / R().)
local function RS(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function RX(v) return RS(v) end
local function RY(v) return RS(v) end

local COL = {
    card   = Color(14, 14, 17, 255),
    sub    = Color(21, 21, 26, 255),
    sub2   = Color(27, 27, 33, 255),
    subhov = Color(34, 34, 41, 255),
    text   = Color(236, 236, 236),
    muted  = Color(140, 140, 150),
    accent = Color(207, 68, 78),
    green  = Color(90, 200, 120),
    red    = Color(214, 69, 63),
    -- DA Atelier (07/07) : plus de bleu — utilitaire = acier ; ambre -> doré DA.
    blue   = Color(150, 154, 162),
    amber  = Color(232, 179, 75),
}
-- Fontes RESPONSIVE (gCreateRespFont scale selon la résolution -> plus de texte minuscule sur
-- les grands écrans). Créées au load ET à Initialize (au cas où le load précède glibs/hot-reload).
local F_TITLE, F_TAB, F_ROW, F_BTN, F_SMALL, F_SEC, F_INFO =
    "EVO_AQA_Title", "EVO_AQA_Tab", "EVO_AQA_Row", "EVO_AQA_Btn", "EVO_AQA_Small", "EVO_AQA_Sec", "EVO_AQA_Info"
local function EVO_AQA_CreateFonts()
    if not gCreateRespFont then return end
    gCreateRespFont(F_TITLE, "Avenir Next World Bold", 30)
    gCreateRespFont(F_TAB,   "Avenir Next World Bold", 20)
    gCreateRespFont(F_ROW,   "Avenir Next World Bold", 20)
    gCreateRespFont(F_BTN,   "Avenir Next World Bold", 17)
    gCreateRespFont(F_SEC,   "Avenir Next World Bold", 16)
    gCreateRespFont(F_SMALL, "Avenir Next World", 15)
    gCreateRespFont(F_INFO,  "Avenir Next World", 16)
end
EVO_AQA_CreateFonts()
hook.Add("Initialize", "EVO_AQA_CreateFonts", EVO_AQA_CreateFonts)

local function rpName(p)
    if not IsValid(p) then return "?" end
    local n = p:GetEvoNWString("Nickname", "")
    return (n ~= "" and n) or p:Nick()
end

local function SendAction(action, target, extra)
    net.Start("evo_aqa_action")
    net.WriteString(action)
    net.WriteEntity(target or NULL)
    net.WriteString(extra or "")
    net.SendToServer()
end

-- Actions du panneau accordéon. kind : nil=direct, "confirm", "warn", "ban", "steamid".
local ACTS = {
    { id = "spectate",   label = "Spectate",    col = COL.blue  },
    { id = "inspect",    label = "Inspecter",   col = COL.blue,  kind = "inspect" },
    { id = "goto",       label = "TP",          col = COL.blue  },
    { id = "bring",      label = "Amener",      col = COL.blue  },
    { id = "heal",       label = "Soigner",     col = COL.green },
    { id = "respawn",    label = "Respawn",     col = COL.green },
    { id = "freeze",     label = "Geler",       col = COL.amber, toggle = "aqa_frozen" },
    { id = "god",        label = "God",         col = COL.amber, toggle = "aqa_god" },
    { id = "mute_voice", label = "Mute Micro",  col = COL.amber, toggle = "aqa_mute_voice" },
    { id = "mute_text",  label = "Mute Chat",   col = COL.amber, toggle = "aqa_mute_text" },
    { id = "whitelist",  label = "Whitelist",   col = COL.green, toggle = "evo_whitelisted" },
    { id = "warn",       label = "Avertir",     col = COL.amber, kind = "warn"    },
    { id = "ban",        label = "Bannir",      col = COL.red,   kind = "ban"     },
    { id = "kick",       label = "Kick",        col = COL.red,   kind = "confirm" },
    { id = "kill",       label = "Tuer",        col = COL.red,   kind = "confirm" },
    { id = "steamid",    label = "Copier SteamID", col = COL.sub2, kind = "steamid", full = true },
}

local function MakeBtn(parent, x, y, w, h, label, col, onClick, getOn)
    local b = vgui.Create("DButton", parent)
    b:SetText("") b:SetPos(x, y) b:SetSize(w, h) b:SetCursor("hand")
    b.Paint = function(s, bw, bh)
        -- Plaque Atelier "br" (coin bas-droit coupé) ; survol = fond clair +
        -- libellé teinté (JAMAIS de contour sur coins coupés — règle DA).
        local hov, on = s:IsHovered(), getOn and getOn() or false
        local fill = on and col or (hov and COL.subhov or COL.sub2)
        if EVO_UI and EVO_UI.PaintCut then
            EVO_UI.PaintCut(0, 0, bw, bh, fill, RY(7), "br")
        else
            draw.RoundedBox(0, 0, 0, bw, bh, fill)
        end
        local txt = label
        if getOn ~= nil then txt = label .. (on and " ✓" or "") end
        local colTxt = on and color_white or (hov and col or COL.text)
        draw.SimpleText(txt, F_BTN, bw / 2, bh / 2, colTxt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = onClick
    return b
end

-- Popup modale STYLÉE EVO (remplace Derma_Query/StringRequest) : fond assombri + carte sombre
-- (accent rouge), titre, description, champs texte optionnels, boutons Annuler/Confirmer.
-- opts = { title, desc, fields = {{label,default,placeholder}...}, confirmText, confirmCol,
-- onConfirm(values) }. Échap = Annuler (openedFrame, restaure le panneau au close).
local function EVO_AQA_Prompt(opts)
    opts = opts or {}
    local fields = opts.fields or {}
    local nf = #fields
    local cardW = RX(500)
    local headH = RY(58) + (opts.desc and RY(26) or 0)
    local fieldH = RY(76)
    local cardH = headH + nf * fieldH + RY(64)

    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
    frame:MakePopup()
    frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
    frame.Paint = function(s, w, h)
        surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h)
    end
    openedFrame = frame
    frame.OnRemove = function()
        if openedFrame == frame then openedFrame = IsValid(EVO_AQA_Frame) and EVO_AQA_Frame or nil end
    end

    local card = vgui.Create("DPanel", frame)
    card:SetSize(cardW, cardH)
    card:SetPos((ScrW() - cardW) / 2, (ScrH() - cardH) / 2)
    card.Paint = function(s, w, h)
        -- Plaque Atelier + entaille slash1 sous le titre (DA 07/07).
        if EVO_UI and EVO_UI.PaintCut then
            local pts = EVO_UI.PaintCut(0, 0, w, h, COL.card, RY(12))
            EVO_UI.OutlineCut(pts, Color(146, 152, 161, 33))
        else
            draw.RoundedBox(0, 0, 0, w, h, COL.card)
        end
        draw.SimpleText(opts.title or "", F_ROW, RX(22), RY(24), COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        -- Slash1 calé sur la HAUTEUR MESURÉE du titre (réf boutique : haut + th*0.78 ;
        -- titre center-aligné à c=RY(24) -> haut = c - th/2 -> slashY = c + th*0.28).
        surface.SetFont(F_ROW) local _tw, _th = surface.GetTextSize(opts.title or "")
        local inked = EVO_UI and EVO_UI.Ink
            and EVO_UI.Ink(EVO_UI.TexSlash, RX(20), RY(24) + _th * 0.28, RX(60), RY(8), ColorAlpha(COL.accent, 245))
        if not inked then
            surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255)
            surface.DrawRect(RX(22), RY(24) + _th * 0.34, RX(36), RY(3))
        end
        if opts.desc then
            draw.SimpleText(opts.desc, F_INFO, RX(22), RY(60), COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end

    local getters = {}
    local firstTextEntry = nil
    local confirm -- forward decl (utilisé par OnEnter + les boutons)
    local y = headH
    for i, f in ipairs(fields) do
        local lbl = vgui.Create("DLabel", card)
        lbl:SetPos(RX(22), y) lbl:SetText(f.label or "") lbl:SetFont(F_INFO)
        lbl:SetTextColor(COL.muted) lbl:SizeToContents()

        if f.choices then
            -- LISTE DÉROULANTE (presets, ex : durées de ban)
            local combo = vgui.Create("DComboBox", card)
            combo:SetPos(RX(22), y + RY(22)) combo:SetSize(cardW - RX(44), RY(40))
            combo.selText, combo.selValue = nil, f.default
            for _, c in ipairs(f.choices) do
                combo:AddChoice(c.text, c.value)
                if c.value == f.default then combo.selText = c.text end
            end
            combo.selText = combo.selText or (f.choices[1] and f.choices[1].text) or ""
            if combo.selValue == nil then combo.selValue = f.choices[1] and f.choices[1].value end
            combo.OnSelect = function(s, idx, txt, data) s.selText, s.selValue = txt, data end
            combo.Paint = function(s, w, h)
                draw.RoundedBox(RX(6), 0, 0, w, h, s:IsHovered() and COL.subhov or COL.sub2)
                draw.SimpleText(s.selText or "", F_INFO, RX(12), h / 2, COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("▼", F_SMALL, w - RX(14), h / 2, COL.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
            getters[i] = function() return tostring(combo.selValue == nil and "" or combo.selValue) end
        else
            -- CHAMP TEXTE. SetDrawLanguageID(false) = enlève l'indicateur de langue "FR" du clavier.
            local entry = vgui.Create("DTextEntry", card)
            entry:SetPos(RX(22), y + RY(22)) entry:SetSize(cardW - RX(44), RY(40))
            entry:SetFont(F_INFO) entry:SetText(f.default or "") entry:SetUpdateOnType(true)
            entry:SetDrawLanguageID(false)
            entry.Paint = function(s, w, h)
                draw.RoundedBox(RX(6), 0, 0, w, h, COL.sub2)
                s:DrawTextEntryText(COL.text, COL.accent, COL.text)
                if s:GetText() == "" and f.placeholder then
                    draw.SimpleText(f.placeholder, F_INFO, RX(10), h / 2, COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end
            end
            entry.OnEnter = function() if confirm then confirm() end end
            firstTextEntry = firstTextEntry or entry
            getters[i] = function() return string.Trim(entry:GetText()) end
        end
        y = y + fieldH
    end

    confirm = function()
        local vals = {}
        for i = 1, #fields do vals[i] = getters[i] and getters[i]() or "" end
        frame:Remove()
        if opts.onConfirm then opts.onConfirm(vals) end
    end
    if firstTextEntry then firstTextEntry:RequestFocus() end

    local by = cardH - RY(56)
    local bw = (cardW - RX(44) - RX(12)) / 2
    MakeBtn(card, RX(22), by, bw, RY(40), "Annuler", COL.sub2, function() frame:Remove() end)
    MakeBtn(card, RX(22) + bw + RX(12), by, bw, RY(40), opts.confirmText or "Confirmer", opts.confirmCol or COL.accent, confirm)
end

-- Fiche d'inspection STYLÉE (lecture seule) : infos du joueur (NW vars client-lisibles).
local function EVO_AQA_Inspect(p)
    if not IsValid(p) then return end
    local fac = p:GetEvoNWString("FactionName", "")
    if fac == "" then fac = "Sans faction" end
    local function yn(b) return b and "Oui" or "Non" end
    local rows = {
        { "Nom RP",       rpName(p) },
        { "Pseudo Steam", p:Nick() },
        { "SteamID",      p:SteamID() },
        { "SteamID64",    p:SteamID64() },
        { "Faction",      fac },
        { "Grade",        LZY_FACTION_CONFIG.RankName(p, p:GetEvoNWInt("FactionRank", 0)) },
        { LZY_FACTION_CONFIG.DivisionWord(p), LZY_FACTION_CONFIG.DivisionName(p, p:GetEvoNWInt("FactionDivision", 0)) },
        { "Niveau",       tostring(p:GetEvoNWInt("Level", 0)) },
        { "Argent",       string.Comma(p:GetEvoNWInt("Money", 0)) .. " ¥" },
        { "Vie",          p:Health() .. " / " .. p:GetMaxHealth() },
        { "Armure",       tostring(p:Armor()) },
        { "Ping",         p:Ping() .. " ms" },
        { "Gelé",         yn(p:GetEvoNWBool("aqa_frozen", false)) },
        { "Mute micro",   yn(p:GetEvoNWBool("aqa_mute_voice", false)) },
        { "Mute chat",    yn(p:GetEvoNWBool("aqa_mute_text", false)) },
    }

    local cardW = RX(560)
    local rowH  = RY(28)
    local headH = RY(60)
    local cardH = headH + #rows * rowH + RY(64)

    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
    frame:MakePopup()
    frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
    frame.Paint = function(s, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
    openedFrame = frame
    frame.OnRemove = function()
        if openedFrame == frame then openedFrame = IsValid(EVO_AQA_Frame) and EVO_AQA_Frame or nil end
    end

    local card = vgui.Create("DPanel", frame)
    card:SetSize(cardW, cardH)
    card:SetPos((ScrW() - cardW) / 2, (ScrH() - cardH) / 2)
    card.Paint = function(s, w, h)
        -- Plaque Atelier + entaille slash1 sous le titre (DA 07/07).
        if EVO_UI and EVO_UI.PaintCut then
            local pts = EVO_UI.PaintCut(0, 0, w, h, COL.card, RY(12))
            EVO_UI.OutlineCut(pts, Color(146, 152, 161, 33))
        else
            draw.RoundedBox(0, 0, 0, w, h, COL.card)
        end
        draw.SimpleText("INSPECTER : " .. rpName(p), F_ROW, RX(22), RY(24), COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        -- Slash1 calé sur la HAUTEUR MESURÉE du titre (réf boutique : haut + th*0.78 ;
        -- titre center-aligné à c=RY(24) -> haut = c - th/2 -> slashY = c + th*0.28).
        surface.SetFont(F_ROW) local _tw, _th = surface.GetTextSize("INSPECTER — " .. rpName(p))
        local inked = EVO_UI and EVO_UI.Ink
            and EVO_UI.Ink(EVO_UI.TexSlash, RX(20), RY(24) + _th * 0.28, RX(60), RY(8), ColorAlpha(COL.accent, 245))
        if not inked then
            surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255)
            surface.DrawRect(RX(22), RY(24) + _th * 0.34, RX(36), RY(3))
        end
        local ry = headH
        for _, r in ipairs(rows) do
            draw.SimpleText(r[1], F_INFO, RX(22), ry, COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText(r[2], F_INFO, RX(200), ry, COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            ry = ry + rowH
        end
    end

    local by = cardH - RY(54)
    local bw = (cardW - RX(44) - RX(12)) / 2
    MakeBtn(card, RX(22), by, bw, RY(38), "Copier SteamID", COL.sub2, function()
        SetClipboardText(p:SteamID())
        if MUGEN and MUGEN.Notify then MUGEN.Notify(p:SteamID() .. " copié", NOTIFY_GENERIC or 0, 3) end
    end)
    MakeBtn(card, RX(22) + bw + RX(12), by, bw, RY(38), "Fermer", COL.accent, function() frame:Remove() end)
end

local function DoAction(def, p)
    if not IsValid(p) then return end
    if def.kind == "steamid" then
        SetClipboardText(p:SteamID())
        if MUGEN and MUGEN.Notify then MUGEN.Notify(p:SteamID() .. " copié", NOTIFY_GENERIC or 0, 3) end
        MsgC(COL.blue, "[Admin] ", COL.text, rpName(p) .. " — " .. p:SteamID() .. " / " .. p:SteamID64() .. " (copié)", "\n")
    elseif def.kind == "confirm" then
        EVO_AQA_Prompt({
            title = def.label .. " - " .. rpName(p),
            desc = "Confirmer cette action ?",
            confirmText = def.label, confirmCol = COL.red,
            onConfirm = function() SendAction(def.id, p) end,
        })
    elseif def.kind == "warn" then
        EVO_AQA_Prompt({
            title = "Avertir : " .. rpName(p),
            desc = "Motif de l'avertissement envoyé au joueur.",
            fields = { { label = "Raison", placeholder = "Ex : RDM, propos déplacés..." } },
            confirmText = "Avertir", confirmCol = COL.amber,
            onConfirm = function(v) SendAction("warn", p, v[1] or "") end,
        })
    elseif def.kind == "ban" then
        EVO_AQA_Prompt({
            title = "Bannir : " .. rpName(p),
            fields = {
                { label = "Durée", default = 60, choices = {
                    { text = "5 minutes",  value = 5 },
                    { text = "30 minutes", value = 30 },
                    { text = "1 heure",    value = 60 },
                    { text = "3 heures",   value = 180 },
                    { text = "12 heures",  value = 720 },
                    { text = "1 jour",     value = 1440 },
                    { text = "1 semaine",  value = 10080 },
                    { text = "Définitif",  value = 0 },
                } },
                { label = "Raison", placeholder = "Motif du ban..." },
            },
            confirmText = "Bannir", confirmCol = COL.red,
            onConfirm = function(v)
                local mins = tostring(tonumber(v[1]) or 0)
                SendAction("ban", p, mins .. "|" .. (v[2] or ""))
            end,
        })
    elseif def.kind == "inspect" then
        EVO_AQA_Inspect(p)
    else
        SendAction(def.id, p)
    end
end

-- ── Spectate POV (vue 1ère personne, autorisée par le serveur) ──
-- SURVEILLANCE À DISTANCE : on NE touche PAS à la caméra ni au corps de l'admin (il continue à
-- jouer normalement). SpecTarget pilote la FENÊTRE POV (haut-droite) + l'audio : la VOIX (routée
-- par lzy_voice) ET les SONS d'ambiance autour de la cible (hook EntityEmitSound plus bas).
local SpecTarget = nil
-- netgate: edge -- clears SpecTarget
local function StopSpec()
    SpecTarget = nil
    net.Start("evo_aqa_spec_end") -- serveur : coupe le PVS secondaire + le routage voix
    net.SendToServer()
end
local function StartSpec(t)
    SpecTarget = t
    if IsValid(EVO_AQA_Frame) then EVO_AQA_Frame:Remove() end -- ferme le panneau (rend la souris au jeu)
end
net.Receive("evo_aqa_spec", function()
    local t = net.ReadEntity()
    if IsValid(t) and t:IsPlayer() then StartSpec(t) end
end)
-- SURVEILLANCE À DISTANCE SANS DÉPLACEMENT : l'admin n'est PAS mis en observateur et n'est PAS
-- déplacé — il continue à jouer normalement. Le serveur ajoute juste la zone de la cible à son
-- PVS (SetupPlayerVisibility/AddOriginToPVS) -> le client reçoit la scène autour de la cible et
-- la rend dans la fenêtre POV ci-dessous. On NE cache PLUS le HUD et on NE prend PLUS la caméra.
-- Fermeture via Échap (OnPauseMenuShow ci-dessous), l'indice est DANS la fenêtre.

-- ── Fenêtre HAUT-DROITE : la vue 3ÈME PERSONNE du joueur spectaté, en temps réel ──
-- On RE-REND la scène en 3ème personne (render.RenderView), comme la caméra du jeu : on réplique
-- l'orbite (mêmes distance / hauteur / offset / collision que MUGEN.Camera.Config), vue depuis sa
-- direction de regard (EyeAngles networkées). Garde anti-réentrance + kill-switch evo_aqa_spec_pip.
local cvPiP = CreateClientConVar("evo_aqa_spec_pip", "1", true, false, "Affiche la vue du joueur spectaté (fenêtre haut-droite).")
local _aqaInPiP = false
local PIP_TR_MIN, PIP_TR_MAX = Vector(-4, -4, -4), Vector(4, 4, 4)
hook.Add("HUDPaint", "EVO_AQA_Spec_PiP", function()
    if not IsValid(SpecTarget) or not SpecTarget:IsPlayer() then return end
    if _aqaInPiP or not cvPiP:GetBool() then return end

    local boxW, boxH = RX(460), RX(259)            -- fenêtre 16:9
    local hdrH       = RY(24)
    local bx         = ScrW() - boxW - RX(20)
    local by         = RY(78) + hdrH               -- la vue commence sous le bandeau du nom

    -- Bandeau (nom) + fond, HORS du rect de RenderView pour ne pas être écrasés.
    surface.SetDrawColor(8, 8, 10, 240)
    surface.DrawRect(bx - RX(3), by - hdrH, boxW + RX(6), boxH + hdrH + RX(3))
    draw.SimpleText(string.upper(rpName(SpecTarget)), F_SEC, bx + RX(4), by - hdrH * 0.5, COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    draw.SimpleText("ÉCHAP POUR FERMER", F_SMALL, bx + boxW - RX(4), by - hdrH * 0.5, COL.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

    -- Caméra 3ÈME PERSONNE répliquant l'orbite du jeu : depuis ses yeux, reculée de `maxDistance`
    -- le long de sa direction de regard, + hauteur + offset latéral, avec trace anti-mur (buffer).
    local ccfg     = (MUGEN and MUGEN.Camera and MUGEN.Camera.Config) or {}
    local eye      = SpecTarget:EyePos()
    local ang      = SpecTarget:EyeAngles()
    local vDesired = eye - ang:Forward() * (ccfg.maxDistance or 100)
        + Vector(0, 0, ccfg.height or 20)
        + ang:Right() * (ccfg.offsetX or 0)
    local tr = util.TraceHull({
        start = eye, endpos = vDesired, mins = PIP_TR_MIN, maxs = PIP_TR_MAX,
        filter = SpecTarget, mask = MASK_SOLID,
    })
    local origin = tr.Hit and (tr.HitPos + tr.HitNormal * (ccfg.cameraBuffer or 8)) or vDesired

    _aqaInPiP = true
    pcall(render.RenderView, {
        origin        = origin,
        angles        = ang,
        x = bx, y = by, w = boxW, h = boxH,
        fov           = 90,
        drawviewmodel = false,
        dopostprocess = false,
        drawhud       = false,
        drawmonitors  = false,
    })
    _aqaInPiP = false

    surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255)
    surface.DrawOutlinedRect(bx, by, boxW, boxH, RX(2))
end)

-- ── AUDIO de surveillance : entendre les SONS AUTOUR de la cible (ce qu'elle entend) ──
-- L'écoute du moteur suit TON corps (tu n'es pas déplacé), donc les sons autour de la cible te
-- parviennent (via le PVS secondaire ajouté serveur) mais très ATTÉNUÉS par la distance. On
-- intercepte donc les sons émis DANS la zone d'écoute de la cible et on les passe en NON atténué
-- (SoundLevel 0) -> tu les entends plein volume, comme si tu étais à sa place. La VOIX, elle, est
-- déjà routée par lzy_voice (_aqaSpecTarget). Clientside-only : ne modifie QUE ta lecture locale
-- (les autres joueurs ne sont pas affectés). Kill-switch : convar evo_aqa_spec_audio.
local cvSpecAudio = CreateClientConVar("evo_aqa_spec_audio", "1", true, false, "Entendre les sons autour du joueur spectaté.")
local SPEC_HEAR_RANGE_SQR = 2200 * 2200 -- rayon "d'écoute" autour de la cible
hook.Add("EntityEmitSound", "EVO_AQA_SpecAudio", function(data)
    if not IsValid(SpecTarget) or not cvSpecAudio:GetBool() then return end
    local pos = data.Pos
    if not pos and IsValid(data.Entity) then pos = data.Entity:GetPos() end
    if not pos then return end
    if pos:DistToSqr(SpecTarget:GetPos()) <= SPEC_HEAR_RANGE_SQR then
        data.SoundLevel = 0 -- non atténué -> audible plein volume pour toi (= ce que la cible entend)
        return true
    end
end)

hook.Add("Think", "EVO_AQA_Spec_Valid", function()
    -- Cible déconnectée / invalide -> on coupe la surveillance proprement (la fenêtre disparaît).
    if not IsValid(SpecTarget) and SpecTarget ~= nil then StopSpec() end
end)
hook.Add("OnPauseMenuShow", "EVO_AQA_Spec_Exit", function()
    if IsValid(SpecTarget) then StopSpec() return false end
end)

-- ════════════════════════════════════════════════════════════════════
--  PANNEAU
-- ════════════════════════════════════════════════════════════════════
local PANEL = {}

function PANEL:Init()
    openedFrame = self
    self:SetSize(RX(920), RY(748))
    self:Center()
    self:MakePopup()
    self:SetTitle("") self:ShowCloseButton(false) self:SetDraggable(false)
    if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end

    self.activeTab = "Tous"
    self.openRow = nil
    self.searchQuery = ""

    self.Paint = function(s, w, h)
        -- Plaque Atelier + entaille slash1 sous le titre (DA 07/07).
        if EVO_UI and EVO_UI.PaintCut then
            local pts = EVO_UI.PaintCut(0, 0, w, h, COL.card, RY(12))
            EVO_UI.OutlineCut(pts, Color(146, 152, 161, 33))
        else
            draw.RoundedBox(0, 0, 0, w, h, COL.card)
        end
        draw.SimpleText("ACTIONS RAPIDES", F_TITLE, RX(26), RY(30), COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        surface.SetFont(F_TITLE) local tw, th = surface.GetTextSize("ACTIONS RAPIDES")
        draw.SimpleText("SUPER ADMIN", F_SEC, RX(26) + tw + RX(14), RY(32), COL.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        -- Slash1 calé sur la HAUTEUR MESURÉE du titre (réf boutique : haut + th*0.78 ;
        -- titre center-aligné à c=RY(30) -> haut = c - th/2 -> slashY = c + th*0.28).
        local inked = EVO_UI and EVO_UI.Ink
            and EVO_UI.Ink(EVO_UI.TexSlash, RX(24), RY(30) + th * 0.28, tw * 1.15, RY(9), ColorAlpha(COL.accent, 245))
        if not inked then
            surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255)
            surface.DrawRect(RX(28), RY(30) + th * 0.34, RX(48), RY(3))
        end
    end

    local close = vgui.Create("DButton", self)
    close:SetText("") close:SetSize(RX(30), RX(30)) close:SetPos(self:GetWide() - RX(48), RY(20))
    close.Paint = function(s, w, h)
        -- Croix standard DA : glyphe ✕, pas de fond, gris -> accent au survol.
        draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
            s:IsHovered() and COL.accent or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    close.DoClick = function() self:Remove() end

    -- Barre de RECHERCHE (nom RP / Steam nick / SteamID / SteamID64). Ignore les onglets.
    local search = vgui.Create("DTextEntry", self)
    search:SetSize(RX(340), RY(34))
    search:SetPos(self:GetWide() - RX(340) - RX(64), RY(18))
    search:SetFont(F_INFO) search:SetUpdateOnType(true) search:SetDrawLanguageID(false)
    search.Paint = function(s, w, h)
        draw.RoundedBox(RX(6), 0, 0, w, h, COL.sub2)
        s:DrawTextEntryText(COL.text, COL.accent, COL.text)
        if s:GetText() == "" then
            draw.SimpleText("Rechercher : nom / SteamID / SteamID64...", F_INFO, RX(10), h / 2, COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    search.OnChange = function(s) self.searchQuery = s:GetValue() self:BuildList() end
    self.searchEntry = search

    -- Barre d'onglets (factions)
    self.tabBar = vgui.Create("DPanel", self)
    self.tabBar:SetPos(RX(22), RY(70))
    self.tabBar:SetSize(self:GetWide() - RX(44), RY(40))
    self.tabBar:SetPaintBackground(false)

    -- Liste accordéon
    self.list = vgui.Create("DScrollPanel", self)
    self.list:SetPos(RX(22), RY(120))
    self.list:SetSize(self:GetWide() - RX(44), self:GetTall() - RY(120) - RY(24))
    local sb = self.list:GetVBar()
    sb:SetWide(RX(6)) ; sb.Paint = function() end
    sb.btnUp.Paint, sb.btnDown.Paint = function() end, function() end
    sb.btnGrip.Paint = function(s, w, h) draw.RoundedBox(RX(3), 0, 0, w, h, Color(45, 45, 53)) end

    self:BuildTabs()
    self:BuildList()

    self._nextRefresh = CurTime() + 1.5
end

function PANEL:GatherFactions()
    local seen, order = {}, {}
    for _, p in player.Iterator() do
        if not IsValid(p) then continue end
        local f = p:GetEvoNWString("FactionName", "")
        if f == "" then f = "Sans faction" end
        if not seen[f] then seen[f] = true order[#order + 1] = f end
    end
    table.sort(order)
    table.insert(order, 1, "Tous")
    return order
end

function PANEL:BuildTabs()
    if not IsValid(self.tabBar) then return end
    self.tabBar:Clear()
    local x = 0
    for _, fac in ipairs(self:GatherFactions()) do
        surface.SetFont(F_TAB)
        local label = fac .. (fac == "Tous" and "" or "")
        local bw = surface.GetTextSize(label) + RX(28)
        local tab = vgui.Create("DButton", self.tabBar)
        tab:SetText("") tab:SetPos(x, 0) tab:SetSize(bw, RY(34)) tab:SetCursor("hand")
        tab.Paint = function(s, w, h)
            local act = (self.activeTab == fac)
            draw.RoundedBox(RX(6), 0, 0, w, h, act and COL.sub or (s:IsHovered() and COL.sub or Color(0,0,0,0)))
            draw.SimpleText(label, F_TAB, w / 2, h / 2, act and COL.text or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if act then surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255) surface.DrawRect(RX(10), h - RY(3), w - RX(20), RY(3)) end
        end
        tab.DoClick = function()
            self.activeTab = fac
            self.openRow = nil
            self.searchQuery = "" -- cliquer un onglet efface la recherche
            if IsValid(self.searchEntry) then self.searchEntry:SetText("") end
            self:BuildList()
        end
        x = x + bw + RX(6)
    end
end

function PANEL:BuildList()
    if not IsValid(self.list) then return end
    self.list:GetCanvas():Clear()
    self.openRow = nil

    local HEADER_H = RY(56)
    -- Largeur DISPO dans une ligne (largeur liste - scrollbar - petite marge). CONNUE ICI ->
    -- on construit les boutons EN DUR (fini le timer.Simple/GetWide qui partait en course :
    -- la largeur valait 0 -> boutons de largeur nulle = invisibles).
    local contentW = self.list:GetWide() - RX(16)
    local pad, cols, gap = RX(12), 4, RX(8)
    local bw = (contentW - pad * 2 - gap * (cols - 1)) / cols
    local bh = RY(42)
    local gridRows = math.ceil((#ACTS - 1) / cols) -- -1 : le bouton SteamID est pleine largeur
    local ACTIONS_H = pad + gridRows * (bh + gap) + (bh + gap) + RY(4)

    local q = string.lower(self.searchQuery or "")
    for _, ply in player.Iterator() do
        if not IsValid(ply) then continue end
        local fac = ply:GetEvoNWString("FactionName", "")
        if fac == "" then fac = "Sans faction" end
        if q ~= "" then
            -- RECHERCHE active : on ignore l'onglet, on matche nom RP / nick / SteamID / SteamID64
            local hay = string.lower(rpName(ply) .. " " .. ply:Nick() .. " " .. ply:SteamID() .. " " .. ply:SteamID64())
            if not string.find(hay, q, 1, true) then continue end
        elseif self.activeTab ~= "Tous" and fac ~= self.activeTab then
            continue
        end

        local p = ply
        local row = vgui.Create("DPanel", self.list)
        row:Dock(TOP) row:DockMargin(0, 0, 0, RY(8)) row:SetTall(HEADER_H)
        row:SetPaintBackground(false)
        row.expanded = false

        local header = vgui.Create("DButton", row)
        header:SetPos(0, 0) header:SetSize(contentW, HEADER_H) header:SetText("") header:SetCursor("hand")
        header.Paint = function(s, w, h)
            draw.RoundedBox(RX(7), 0, 0, w, h, (row.expanded or s:IsHovered()) and COL.subhov or COL.sub)
            if row.expanded then surface.SetDrawColor(COL.accent.r, COL.accent.g, COL.accent.b, 255) surface.DrawRect(0, 0, RX(3), h) end
            if not IsValid(p) then draw.SimpleText("(déconnecté)", F_ROW, RX(14), h/2, COL.muted, 0, 1) return end
            draw.SimpleText(rpName(p), F_ROW, RX(14), RY(13), COL.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            local grade = p:GetEvoNWInt("FactionRank", 0)
            draw.SimpleText(fac .. "  ·  Grade " .. grade .. "  ·  " .. p:Health() .. " HP  ·  " .. p:Ping() .. " ms",
                F_SMALL, RX(14), RY(37), COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(row.expanded and "▲" or "▼", F_TAB, w - RX(18), h / 2, COL.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        local actions = vgui.Create("DPanel", row)
        actions:SetPos(0, HEADER_H + RY(4))
        actions:SetSize(contentW, ACTIONS_H)
        actions:SetVisible(false)
        actions.Paint = function(s, w, h) draw.RoundedBox(RX(7), 0, 0, w, h, COL.sub) end

        -- Boutons construits EN DUR (largeur connue) -> toujours visibles à l'ouverture.
        local col, rowi = 0, 0
        for _, def in ipairs(ACTS) do
            if def.full then -- SteamID : pleine largeur, affiche l'ID + le copie au clic
                local y = pad + gridRows * (bh + gap)
                local label = def.label
                if def.id == "steamid" and IsValid(p) then label = "Copier SteamID : " .. p:SteamID() end
                MakeBtn(actions, pad, y, contentW - pad * 2, bh, label, def.col, function() DoAction(def, p) end)
            else
                local x = pad + col * (bw + gap)
                local y = pad + rowi * (bh + gap)
                local getOn = def.toggle and function() return IsValid(p) and p:GetEvoNWBool(def.toggle, false) end or nil
                MakeBtn(actions, x, y, bw, bh, def.label, def.col, function() DoAction(def, p) end, getOn)
                col = col + 1
                if col >= cols then col = 0 rowi = rowi + 1 end
            end
        end

        header.DoClick = function()
            if IsValid(self.openRow) and self.openRow ~= row then
                self.openRow.expanded = false
                self.openRow:SetTall(HEADER_H)
                if IsValid(self.openRow._actions) then self.openRow._actions:SetVisible(false) end
            end
            row.expanded = not row.expanded
            row:SetTall(HEADER_H + (row.expanded and (ACTIONS_H + RY(10)) or 0))
            actions:SetVisible(row.expanded)
            self.openRow = row.expanded and row or nil
            self.list:InvalidateLayout(true)
        end
        row._actions = actions
    end
end

function PANEL:Think()
    if self._nextRefresh and CurTime() < self._nextRefresh then return end
    self._nextRefresh = CurTime() + 1.5
    -- rebuild seulement si aucune ligne ouverte (pour ne pas casser l'accordéon en cours)
    if not IsValid(self.openRow) then
        self:BuildTabs()
        self:BuildList()
    end
end

function PANEL:OnRemove()
    if openedFrame == self then openedFrame = nil end
end

vgui.Register("EVO_AQA_Panel", PANEL, "DFrame")

local function OpenPanel()
    if not LocalPlayer():IsSuperAdmin() then return end
    if IsValid(EVO_AQA_Frame) then EVO_AQA_Frame:Remove() return end
    EVO_AQA_Frame = vgui.Create("EVO_AQA_Panel")
end

concommand.Add("evo_admin", OpenPanel)
concommand.Add("evo_aqa", OpenPanel)

-- Ouverture / FERMETURE via le bind "admin_panel" (menu bind, catégorie Menu, défaut TAB, SA).
-- ⚠ On POLL la touche via input.IsButtonDown dans Think : lit l'état BRUT de la touche,
-- IMMUNISÉ contre le vol de focus clavier. Le MakePopup du panneau capte le clavier ->
-- input.IsKeyDown / OnKeyCodePressed deviennent muets pendant que le panneau est ouvert
-- (= le ré-appui ne fermait pas), mais PAS input.IsButtonDown (même solution que le flagmap).
-- PlayerButtonDown est exclu car lzy_hud désactive le scoreboard TAB. Front montant ->
-- OpenPanel = TOGGLE (ouvre si fermé, FERME si ouvert) => ré-appuyer sur la touche ferme l'UI.
local aqa_keyDown, aqa_cachedKey, aqa_nextRefresh = false, nil, 0
hook.Add("Think", "EVO_AQA_BindToggle", function()
    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:IsSuperAdmin() then return end
    if IsValid(SpecTarget) then return end -- en spectate : la touche ne touche pas au panneau (Échap pour sortir)
    -- Panneau FERMÉ + un autre menu/curseur ouvert -> on n'ouvre pas par-dessus.
    -- Panneau OUVERT -> on NE coupe PAS : on veut détecter le ré-appui pour FERMER (toggle).
    if not IsValid(EVO_AQA_Frame) and vgui.CursorVisible() then aqa_keyDown = false return end
    local now = CurTime()
    if now >= aqa_nextRefresh then
        aqa_cachedKey = (lp.GetBindKey and lp:GetBindKey("admin_panel")) or KEY_TAB
        aqa_nextRefresh = now + 2
    end
    if not aqa_cachedKey then return end
    local pressed = input.IsButtonDown(aqa_cachedKey)
    if pressed and not aqa_keyDown then OpenPanel() end -- OpenPanel = toggle (ouvre si fermé, FERME si ouvert)
    aqa_keyDown = pressed
end)
