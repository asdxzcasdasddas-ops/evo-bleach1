-- "addons\\evo_blanc\\lua\\entities\\evo_npc_zanpakuto\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("EVO_Rituel_NameTag", {
	font = "Roboto", size = 64, weight = 800, antialias = true, outline = false,
})

-- RENDERGROUP_BOTH : modele en passe opaque, nametag en passe translucide (qui
-- passe APRES les props) -> avec IgnoreZ le tag ne peut plus etre masque.
ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'etiquette de nom.
ENT.EVO_PromptZ = 100

-- Pre-alloue : le nom est constant, pas de Color() ni de GetTextSize par image.
local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

	local name = (EVO_BLANC and EVO_BLANC.Rituel and EVO_BLANC.Rituel.NPCName) or "Gardien des Lames"
	-- Etiquette unifiee (EVO_ZonePrompt) ; l'ancienne boite noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 100, nil, 750, "parler") return end
	local pos = ePos + Vector(0, 0, 100)
	-- Billboard yaw-only face a la CAMERA de rendu (pas a l'angle du joueur) :
	-- suit la camera orbitale quand on tourne la vue sans bouger.
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		if _tagName ~= name then
			_tagName = name
			surface.SetFont("EVO_Rituel_NameTag")
			_tagTW, _tagTH = surface.GetTextSize(name)
		end
		draw.RoundedBox(0, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "EVO_Rituel_NameTag", 0, 0, COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
