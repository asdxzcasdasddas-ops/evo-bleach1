-- "addons\\evo_blanc\\lua\\entities\\evo_npc_zanpakuto\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- PNJ « Gardien des Lames » : vend le rituel de la Salle Blanche (evo_blanc).
-- Anim simple, pas de NextBot/AI, spawn par le code serveur de l'addon.

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Gardien des Lames"
ENT.Author    = "evo_blanc"
ENT.Spawnable = false -- pas dans le menu Q : spawn auto via la config
ENT.AdminOnly = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsGardienLames")
end
