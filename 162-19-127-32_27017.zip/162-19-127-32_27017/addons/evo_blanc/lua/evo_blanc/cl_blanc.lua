-- "addons\\evo_blanc\\lua\\evo_blanc\\cl_blanc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BLANC - cote client : le rendu du panneau, et l'UI de reglage.
--
-- LE BLANC PUR : materiau UnlitGeneric cree en code. Le moteur ne lui applique
-- NI eclairage, ni ombre, ni brouillard ($nofog) : chaque pixel sort a
-- 255,255,255 exactement, meme sous une nuit d'evo_ciel ou dans une cave.
-- C'est tout l'interet ; un panneau eclaire serait gris des qu'on quitte le
-- plein jour.
--
-- C'est un BLOC, pas un plan : render.DrawBox dessine les six faces autour de
-- la base. La position est le CENTRE DE LA BASE, donc poser au sol pose le
-- bloc dessus au lieu de l'enterrer a moitie. Grace au $nocull du materiau, le
-- bloc est aussi blanc DEDANS que dehors : on peut y entrer et jouer dans un
-- vide tout blanc, sol et plafond compris.
-- ============================================================================

-- $nofog : sans lui, le brouillard d'une ambiance evo_ciel delaverait le
-- panneau vers la couleur du brouillard, exactement ce qu'on veut eviter.
-- $nocull : les faces se dessinent des DEUX cotes. C'est ce qui permet
-- d'entrer DANS le bloc et d'etre entoure de blanc, sol compris : sans lui, le
-- moteur saute les faces vues de dos et l'interieur du bloc est invisible.
-- Nom en _v2 : CreateMaterial rend le materiau existant si le nom a deja servi
-- dans la session, et l'ancien n'avait pas $nocull.
local MAT = CreateMaterial("evo_blanc_pur_v2", "UnlitGeneric", {
    ["$basetexture"] = "color/white",
    ["$model"] = 1,
    ["$nofog"] = 1,
    ["$nocull"] = 1,
    ["$vertexcolor"] = 1,
})

local BLANC = Color(255, 255, 255, 255)
-- Le noir du meme materiau : sans eclairage ni brouillard, c'est un noir
-- absolu, aucun relief -- un vide noir, comme le blanc est un vide blanc.
local NOIR = Color(0, 0, 0, 255)

-- Le pas des fleches de position, reglable : gros pas pour amener le bloc,
-- petit pas pour l'affleurer.
local cvPas = CreateClientConVar("evo_blanc_pas", "8", true, false,
    "Pas des fleches de position du bloc blanc (unites)")

-- Reutilises chaque image : deux Vector neufs par image seraient du dechet
-- pour le ramasse-miettes (regle maison, voir evo_perf).
local _mins, _maxs = Vector(), Vector()

-- LES LAMES DE SCENE ---------------------------------------------------------
-- Le cercle de katanas d'un bloc, rendu chez chacun depuis la globale « Lames »
-- (indices dans R.LamesScene, ordre STABLE des deux cotes). Un ClientsideModel
-- par lame, reconstruits SEULEMENT quand la globale change : le reste du temps
-- c'est une comparaison de string, zero allocation par image. Elles vivent
-- comme dans le rituel : rotation lente sur elles-memes, respiration.
local _lames = {}
for i = 1, EVO_BLANC.MAX do _lames[i] = { sig = "", voie = "", ents = {}, pos = {}, blocSig = nil, seed = 0, n = 0 } end
local _v1, _ang = Vector(), Angle()

local function DetruireLames(t)
    for k = #t.ents, 1, -1 do
        local m = t.ents[k]
        if IsValid(m) then m:Remove() end
        t.ents[k] = nil
    end
    t.sig = ""
    t.voie = ""
    t.n = 0
    t.blocSig = nil
end

-- Un GANTELET est rigge sur le squelette joueur (il se bonemerge d'habitude) :
-- dessine seul, il sort en pose de reference, bras en T, origine aux pieds. On
-- reprend la recette du gantelet « range » (cl_hakuda_gauntlet) : repli des bras
-- via NCM_HAKUDA_GAUNTLETS.SheathedAttach, puis on ANCRE le milieu des deux
-- mains sur le point du cercle (offset local calcule une fois, tourne par image).
local function PreparerGantelet(m)
    local att = NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.SheathedAttach
    if att then
        for sBone, aFold in pairs(att.tBoneFold or {}) do
            local nBone = m:LookupBone(sBone)
            if nBone then m:ManipulateBoneAngles(nBone, aFold) end
        end
        for sBone, vPos in pairs(att.tBonePos or {}) do
            local nBone = m:LookupBone(sBone)
            if nBone then m:ManipulateBonePosition(nBone, vPos) end
        end
    end
    m:SetPos(vector_origin)
    m:SetAngles(angle_zero)
    m:SetupBones()
    local vAnc, nMains = Vector(0, 0, 0), 0
    for _, sBone in ipairs({ "ValveBiped.Bip01_R_Hand", "ValveBiped.Bip01_L_Hand" }) do
        local nBone = m:LookupBone(sBone)
        local v = nBone and m:GetBonePosition(nBone)
        if v then vAnc = vAnc + v nMains = nMains + 1 end
    end
    if nMains > 0 then vAnc = vAnc / nMains end
    m._evoAnc = vAnc -- offset local (yaw 0) du milieu des mains, depuis l'origine
    m._evoGant = true
end

local function ConstruireLames(t, sSig, sVoie)
    -- Tentative espacee apres un echec (cf. plus bas) : sans ce garde, une voie
    -- au vivier vide relancait tout le calcul a CHAQUE image.
    if t.reessaiA and RealTime() < t.reessaiA then return end
    local R = EVO_BLANC.Rituel
    local a, b = string.match(sSig, "^(%d+),(%d+)$")
    local nSeed, n = tonumber(a), tonumber(b)
    local tListe = (R and R.ListeBloc and nSeed) and R.ListeBloc(sVoie, nSeed, n) or nil
    -- Rien a poser : soit le catalogue n'est pas encore charge (ca finit par
    -- converger), soit la voie n'a aucun modele (ca ne convergera jamais). On ne
    -- fige PAS la signature -- un joueur qui arrive en cours de scene doit
    -- pouvoir rattraper -- mais on espace les tentatives d'une demi-seconde.
    if not tListe or #tListe == 0 then
        t.reessaiA = RealTime() + 0.5
        return
    end
    t.reessaiA = nil
    DetruireLames(t)
    t.sig, t.voie, t.seed, t.n = sSig, sVoie, nSeed, #tListe
    for k = 1, #tListe do
        local e = tListe[k]
        -- PAS de util.IsValidModel en garde : FAUX NEGATIF cote client sur les
        -- modeles workshop (lecon evo_loot), aucune lame n'apparaissait.
        local m = e.model and ClientsideModel(e.model, RENDERGROUP_OPAQUE) or nil
        if IsValid(m) then
            m:SetNoDraw(true) -- dessines a la main, passe opaque avec le bloc
            if m.DrawShadow then m:DrawShadow(false) end
            if e.voie == "hakuda" then PreparerGantelet(m) end
        end
        -- Un modele rate garde sa CASE (false) : le k-ieme objet reste a la
        -- k-ieme pose, celle que le serveur valide pour le rituel.
        t.ents[k] = IsValid(m) and m or false
    end
end

-- Les poses ne bougent que si le BLOC bouge : une empreinte numerique comparee
-- par image, et seulement au changement le recalcul (grille + graine) et la
-- re-pose des modeles. Le reste du temps : DrawModel, rien d'autre (cent objets).
local function PoserLames(t, iSlot)
    local R = EVO_BLANC.Rituel
    if not (R and R.SignatureBloc) or t.n == 0 then return end
    local nSig = R.SignatureBloc(iSlot)
    if nSig == t.blocSig then return end
    t.blocSig = nSig
    R.PosLamesDuBloc(iSlot, t.n, t.seed, t.pos)
    for k = 1, t.n do
        local m, v = t.ents[k], t.pos[k]
        if m and IsValid(m) and v then
            local nYaw, nInc = R.PoseObjet(t.seed, k)
            if m._evoGant then
                -- Gantelets poses au sol, le milieu des mains sur le point.
                local o = m._evoAnc
                local c, s = math.cos(math.rad(nYaw)), math.sin(math.rad(nYaw))
                _v1.x = v.x - (o.x * c - o.y * s)
                _v1.y = v.y - (o.x * s + o.y * c)
                _v1.z = v.z + (R.PoseGantHauteur or 10) - o.z
                _ang.p, _ang.y, _ang.r = 0, nYaw, 0
            else
                -- Katana PLANTE : la pointe dans le sol, legerement incline.
                _v1.x, _v1.y, _v1.z = v.x, v.y, v.z + (R.PlanteHauteur or 34)
                _ang.p, _ang.y, _ang.r = (R.PlantePitch or 90) - nInc, nYaw, 0
            end
            m:SetPos(_v1)
            m:SetAngles(_ang)
            m:SetupBones()
            m._evoPose = m._evoPose or Vector()
            m._evoPose.x, m._evoPose.y, m._evoPose.z = _v1.x, _v1.y, _v1.z -- pose de repos (pour l'enfouissement)
        end
    end
end

-- A la prise, chez le gagnant, TOUT le champ s'enfonce dans le sol puis disparait
-- (cl_rituel pose R.ChampCacheSig = la globale du champ enfoui). Il reste enfoui
-- tant que ce champ est le meme ; un nouveau rituel ou un nouveau champ le fait
-- re-poser (blocSig remis a nil -> PoserLames).
local function DessinerLames(t, iSlot)
    local R = EVO_BLANC.Rituel
    if R and R.ChampCacheSig ~= nil and R.ChampCacheSig == t.sig then
        local nDuree = R.ChampCacheDuree or 1.6
        local dt = RealTime() - (R.ChampCacheDepuis or 0)
        t.enfoui = true
        if dt >= nDuree then return end
        local nZ = -(dt / nDuree) * (dt / nDuree) * 90 -- accelere en s'enfoncant
        for k = 1, t.n do
            local m = t.ents[k]
            if m and IsValid(m) and t.pos[k] and m._evoPose then
                _v1.x, _v1.y, _v1.z = m._evoPose.x, m._evoPose.y, m._evoPose.z + nZ
                m:SetPos(_v1)
                m:SetupBones()
                m:DrawModel()
            end
        end
        return
    end
    if t.enfoui then
        t.enfoui = false
        t.blocSig = nil
        PoserLames(t, iSlot)
    end
    for k = 1, t.n do
        local m = t.ents[k]
        if m and IsValid(m) and t.pos[k] then m:DrawModel() end
    end
end

hook.Add("ShutDown", "EVO_Blanc::LamesNettoyage", function()
    for i = 1, EVO_BLANC.MAX do DetruireLames(_lames[i]) end
end)

-- PASSE OPAQUE, et c'est capital : les particules (sorts, impacts, fumees)
-- sont des translucides, dessinees APRES les opaques et sans ecrire la
-- profondeur. Dessine dans la passe translucide, le bloc arrivait apres elles
-- et les REPEIGNAIT : aucune particule ne se voyait dans le cube (constate en
-- jeu le 24/08). Dans la passe opaque, le bloc ecrit sa profondeur d'abord,
-- puis les particules se dessinent par-dessus, exactement comme sur un mur de
-- la map.
hook.Add("PostDrawOpaqueRenderables", "EVO_Blanc::Rendu", function(_, bSkybox)
    if bSkybox then return end
    for i = 1, EVO_BLANC.MAX do
        local t = _lames[i]
        if GetGlobalBool(EVO_BLANC.Cle("Actif", i), false) then
            local vPos = GetGlobalVector(EVO_BLANC.Cle("Pos", i), vector_origin)
            local vNorm = GetGlobalVector(EVO_BLANC.Cle("Normale", i), Vector(0, 1, 0))
            local nLarg = GetGlobalFloat(EVO_BLANC.Cle("Largeur", i), 600)
            local nHaut = GetGlobalFloat(EVO_BLANC.Cle("Hauteur", i), 400)
            local nProf = GetGlobalFloat(EVO_BLANC.Cle("Profondeur", i), 600)
            local aAng = vNorm:Angle()

            _mins.x, _mins.y, _mins.z = -nProf / 2, -nLarg / 2, 0
            _maxs.x, _maxs.y, _maxs.z = nProf / 2, nLarg / 2, nHaut
            -- Le materiau se repose a chaque bloc : DrawModel des lames l'a change.
            render.SetMaterial(MAT)
            render.DrawBox(vPos, aAng, _mins, _maxs,
                GetGlobalBool(EVO_BLANC.Cle("Noir", i), false) and NOIR or BLANC)

            -- Les lames de scene, meme passe : la profondeur tranche avec le bloc.
            -- Le cercle de SA voie : que des katanas pour un katana, que des
            -- gantelets pour un Hakuda (meme nombre, memes poses). Un changement
            -- de style change la globale lue, donc reconstruit.
            local R = EVO_BLANC.Rituel
            local sVoie = (R and R.VoieLocale and R.VoieLocale()) or "katana"
            local sSig = GetGlobalString(EVO_BLANC.Cle("Lames", i), "")
            -- SEULEMENT pour qui joue son rituel dans ce bloc (ou le staff) : les
            -- autres joueurs presents ne voient rien, rien ne leur arrive.
            if sSig ~= "" and not (R and R.VoitLeChamp and R.VoitLeChamp(i)) then sSig = "" end
            if sSig ~= t.sig or sVoie ~= t.voie then
                if sSig == "" then DetruireLames(t) t.voie = sVoie else ConstruireLames(t, sSig, sVoie) end
            end
            PoserLames(t, i)
            DessinerLames(t, i)
        elseif t.sig ~= "" or t.ents[1] then
            DetruireLames(t) -- bloc retire : les lames partent avec
        end
    end
end)

-- LES PAUPIERES ---------------------------------------------------------------
-- La sequence d'endormissement, jouee UNIQUEMENT chez le teleporte : deux
-- rideaux noirs se ferment comme des paupieres (0,9 s), noir complet pendant
-- le TP, reouverture lente (1 s). L'easing en sinus fait le mouvement d'une
-- paupiere qui tombe, pas d'un store venitien.

local _dodoDebut = 0
local D_FERME, D_NOIR, D_OUVRE = 0.9, 0.5, 1.0

net.Receive("evo_blanc:dodo", function()
    _dodoDebut = RealTime()
end)

hook.Add("HUDPaint", "EVO_Blanc::Paupieres", function()
    if _dodoDebut <= 0 then return end
    local t = RealTime() - _dodoDebut
    local nTotal = D_FERME + D_NOIR + D_OUVRE
    if t >= nTotal then _dodoDebut = 0 return end

    -- Part fermee des paupieres, entre 0 (ouvertes) et 1 (noir complet).
    local f
    if t < D_FERME then
        f = math.sin((t / D_FERME) * math.pi / 2)
    elseif t < D_FERME + D_NOIR then
        f = 1
    else
        f = math.cos(((t - D_FERME - D_NOIR) / D_OUVRE) * math.pi / 2)
    end

    local w, h = ScrW(), ScrH()
    local nRideau = math.ceil(h / 2 * f)
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawRect(0, 0, w, nRideau)
    surface.DrawRect(0, h - nRideau, w, nRideau)
    -- Un voile qui s'assombrit avec la fermeture : des paupieres reelles
    -- laissent de moins en moins de lumiere avant de se toucher.
    surface.SetDrawColor(0, 0, 0, math.floor(f * f * 200))
    surface.DrawRect(0, nRideau, w, h - nRideau * 2)
end)

-- QUI EST DANS QUEL BLOC ------------------------------------------------------
-- Le serveur diffuse la liste a chaque endormissement et a chaque retour. Sans
-- elle, le bouton RAMENER serait un pari : on ne saurait ni combien de monde
-- attend dans le bloc, ni de quel bloc il s'agit.
local _dodos = {}

net.Receive("evo_blanc:etat", function()
    _dodos = {}
    local n = net.ReadUInt(8)
    for _ = 1, n do
        local p = net.ReadPlayer()
        local iSlot = net.ReadUInt(2)
        if IsValid(p) then _dodos[p] = iSlot end
    end
end)

local function CombienDansBloc(iSlot)
    local n = 0
    for p, s in pairs(_dodos) do
        if IsValid(p) and s == iSlot then n = n + 1 end
    end
    return n
end

-- L'UI -----------------------------------------------------------------------
-- Meme grammaire que le reste du serveur : fond sombre, accent rouge, angle
-- coupe, Bebas Neue. Les reglages s'envoient a CHAQUE geste : on voit le
-- panneau bouger en direct, pas apres un bouton Appliquer.

surface.CreateFont("EVO_Blanc_Titre", { font = "Bebas Neue", size = 30, weight = 500, antialias = true })
surface.CreateFont("EVO_Blanc_Info", { font = "Roboto", size = 15, weight = 400, antialias = true })

local ACCENT = Color(207, 68, 78)
local BLANC_UI = Color(236, 236, 238)
local MUTED = Color(150, 150, 158)

local _frame
-- Le bloc en cours de reglage (1 ou 2). Retenu entre deux ouvertures du menu.
local _slot = 1
-- Nombre de lames de scene demande, retenu lui aussi.
local _nLames = 100

local function ActifSlot()
    return GetGlobalBool(EVO_BLANC.Cle("Actif", _slot), false)
end

-- L'etat LOCAL du reglage en cours. On part de l'etat replique pour pouvoir
-- retoucher un panneau deja pose sans le faire sauter.
local _pos, _norm, _larg, _haut, _prof
local _noir = false

local function Envoyer(bActif)
    net.Start("evo_blanc:set")
    net.WriteUInt(_slot, 2)
    net.WriteBool(bActif)
    if bActif then
        net.WriteVector(_pos)
        net.WriteVector(_norm)
        net.WriteFloat(_larg)
        net.WriteFloat(_haut)
        net.WriteFloat(_prof)
        net.WriteBool(_noir)
    end
    net.SendToServer()
end

-- Pose le panneau la ou le joueur regarde : contre le mur vise (oriente selon
-- le mur), ou a 300 unites en l'air face a lui si rien n'est vise. C'est le
-- geste de base ; les fleches de l'UI affinent ensuite.
local function PoserAuRegard()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local tr = lp:GetEyeTrace()
    if tr.Hit and tr.HitPos:DistToSqr(lp:EyePos()) < 2000 * 2000 then
        -- Legerement decolle de la surface, sinon la base du bloc z-fighte
        -- avec le sol vise.
        _pos = tr.HitPos + tr.HitNormal * 0.5
    else
        _pos = lp:EyePos() + lp:GetAimVector() * 300
    end
    -- Le bloc fait toujours FACE au poseur (la base reste horizontale) : un
    -- bloc oriente selon la normale d'un mur partirait couche.
    _norm = -lp:GetAimVector()
    _norm.z = 0
    if _norm:LengthSqr() < 0.01 then _norm = Vector(0, 1, 0) end
    _norm:Normalize()
    Envoyer(true)
end

local function Fermer()
    if IsValid(_frame) then _frame:Remove() end
    _frame = nil
end

local function Ouvrir()
    Fermer()

    -- L'etat des endormis n'est pas replique en permanence : on le demande a
    -- l'ouverture, sinon un staff qui prend la suite d'un autre ouvrirait un
    -- menu qui croit le bloc vide.
    net.Start("evo_blanc:etat")
    net.SendToServer()

    -- Reprendre l'etat replique : retoucher un panneau deja pose, pas le
    -- remplacer par les valeurs par defaut.
    -- Defauts d'un volume PRATICABLE (600 x 600 x 400) et plus d'un panneau :
    -- avec l'ancien defaut de 120 de haut, un coup aerien collait le joueur au
    -- plafond au premier tick et il retombait aussitot -- vecu comme « le coup
    -- me remet au sol », alors que c'etait le plafond, desormais bien reel.
    _pos = GetGlobalVector(EVO_BLANC.Cle("Pos", _slot), vector_origin)
    _norm = GetGlobalVector(EVO_BLANC.Cle("Normale", _slot), Vector(0, 1, 0))
    _larg = GetGlobalFloat(EVO_BLANC.Cle("Largeur", _slot), 600)
    _haut = GetGlobalFloat(EVO_BLANC.Cle("Hauteur", _slot), 400)
    _prof = GetGlobalFloat(EVO_BLANC.Cle("Profondeur", _slot), 600)
    _noir = GetGlobalBool(EVO_BLANC.Cle("Noir", _slot), false)

    local L, H = 460, 984
    local f = vgui.Create("DFrame")
    _frame = f
    f:SetSize(L, H)
    f:Center()
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:MakePopup()
    f.Paint = function(_, w, h)
        draw.NoTexture()
        surface.SetDrawColor(12, 12, 15, 250)
        surface.DrawPoly({
            { x = 0, y = 0 }, { x = w - 22, y = 0 }, { x = w, y = 22 },
            { x = w, y = h }, { x = 0, y = h },
        })
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, 5, h)
        draw.SimpleText("BLOC BLANC " .. _slot .. "/" .. EVO_BLANC.MAX,
            "EVO_Blanc_Titre", 22, 26, BLANC_UI, 0, 1)
        draw.SimpleText("Visible par TOUS les joueurs.", "EVO_Blanc_Info", 23, 56, MUTED, 0, 1)
    end

    local x = vgui.Create("DButton", f)
    x:SetSize(26, 26)
    x:SetPos(L - 34, 6)
    x:SetText("")
    x.Paint = function(pnl, w, h)
        draw.SimpleText("X", "EVO_Blanc_Titre", w / 2, h / 2,
            pnl:IsHovered() and ACCENT or MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = Fermer

    local y = 84

    -- Les onglets de slot. Basculer FERME et ROUVRE le menu : tous les champs
    -- relisent alors l'etat replique du bloc choisi, sans etat a moitie migre.
    do
        local nDemi = (L - 32 - 6) / 2
        for i = 1, EVO_BLANC.MAX do
            local b = vgui.Create("DButton", f)
            b:SetPos(16 + (i - 1) * (nDemi + 6), y)
            b:SetSize(nDemi, 28)
            b:SetText("")
            b.Paint = function(pnl, w, h)
                local bCourant = (_slot == i)
                surface.SetDrawColor(bCourant and Color(30, 18, 20)
                    or (pnl:IsHovered() and Color(26, 26, 32) or Color(18, 18, 22)))
                surface.DrawRect(0, 0, w, h)
                if bCourant then
                    surface.SetDrawColor(ACCENT)
                    surface.DrawRect(0, h - 2, w, 2)
                end
                local bPose = GetGlobalBool(EVO_BLANC.Cle("Actif", i), false)
                draw.SimpleText("BLOC " .. i .. (bPose and " (pose)" or ""),
                    "EVO_Blanc_Info", w / 2, h / 2,
                    bCourant and BLANC_UI or MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            b.DoClick = function()
                if _slot == i then return end
                surface.PlaySound("ui/buttonclickrelease.wav")
                _slot = i
                Ouvrir()
            end
        end
        y = y + 36
    end

    local function Bouton(sTexte, nX, nY, nL, fClic)
        local b = vgui.Create("DButton", f)
        b:SetPos(nX, nY)
        b:SetSize(nL, 30)
        b:SetText("")
        b.Paint = function(pnl, w, h)
            surface.SetDrawColor(pnl:IsHovered() and Color(30, 18, 20) or Color(18, 18, 22))
            surface.DrawRect(0, 0, w, h)
            if pnl:IsHovered() then
                surface.SetDrawColor(ACCENT)
                surface.DrawRect(0, h - 2, w, 2)
            end
            -- Libelle fixe ou fonction : « RAMENER (3) » doit suivre l'etat
            -- en direct, pas l'etat qu'il avait a l'ouverture du menu.
            draw.SimpleText(isfunction(sTexte) and sTexte() or sTexte,
                "EVO_Blanc_Info", w / 2, h / 2,
                pnl:IsHovered() and BLANC_UI or MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = fClic
        return b
    end

    Bouton("POSER LA OU JE REGARDE", 16, y, L - 32, function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        PoserAuRegard()
    end)
    y = y + 40

    local function Curseur(sNom, nMin, nMax, fLire, fEcrire, bLocal)
        local s = vgui.Create("DNumSlider", f)
        s:SetPos(16, y)
        s:SetSize(L - 32, 34)
        s:SetText(sNom)
        s:SetMin(nMin)
        s:SetMax(nMax)
        s:SetDecimals(0)
        s:SetValue(fLire())
        s.Label:SetTextColor(BLANC_UI)
        s.OnValueChanged = function(_, v)
            fEcrire(v)
            -- Envoi seulement si le panneau est pose : regler la taille avant
            -- de poser ne doit pas faire apparaitre un panneau a l'origine.
            -- bLocal : reglage qui ne touche pas au bloc, rien a renvoyer (et
            -- surtout pas une reconstruction de la collision).
            if not bLocal and ActifSlot() then Envoyer(true) end
        end
        y = y + 40
    end

    -- Bornes alignees sur le serveur : le pavage de collision plafonne la
    -- taille (chaque plaque est une entite reseau).
    Curseur("Largeur", 8, 4000, function() return _larg end, function(v) _larg = v end)
    Curseur("Hauteur", 8, 1600, function() return _haut end, function(v) _haut = v end)
    Curseur("Profondeur", 8, 4000, function() return _prof end, function(v) _prof = v end)
    Curseur("Pas des fleches", 1, 128, function() return cvPas:GetInt() end,
        function(v) cvPas:SetInt(math.max(1, math.floor(v))) end, true)

    -- Blanc ou noir : le meme bloc, le meme materiau sans eclairage, juste la
    -- couleur. Un vide noir sert autant qu'un vide blanc en animation.
    local c = vgui.Create("DButton", f)
    c:SetPos(16, y)
    c:SetSize(L - 32, 30)
    c:SetText("")
    c.Paint = function(pnl, w, h)
        surface.SetDrawColor(pnl:IsHovered() and Color(30, 18, 20) or Color(18, 18, 22))
        surface.DrawRect(0, 0, w, h)
        local sTxt = _noir and "COULEUR : NOIR (cliquer pour blanc)" or "COULEUR : BLANC (cliquer pour noir)"
        draw.SimpleText(sTxt, "EVO_Blanc_Info", w / 2, h / 2,
            _noir and MUTED or BLANC_UI, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    c.DoClick = function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        _noir = not _noir
        if ActifSlot() then Envoyer(true) end
    end
    y = y + 40

    -- Les fleches de position : des pas de 8 unites RELATIFS AU PANNEAU
    -- (droite = la droite du panneau, pas l'axe X de la map), sinon les fleches
    -- s'inversent selon l'orientation et on se bat avec.
    local function Deplacer(vDelta)
        if not ActifSlot() then return end
        local nPas = math.max(1, cvPas:GetInt())
        local aBase = _norm:Angle()
        _pos = _pos + (aBase:Right() * vDelta.x + Vector(0, 0, vDelta.z) + _norm * vDelta.y) * nPas
        Envoyer(true)
    end

    draw.NoTexture()
    local lbl = vgui.Create("DLabel", f)
    lbl:SetPos(16, y)
    lbl:SetSize(L - 32, 18)
    lbl:SetFont("EVO_Blanc_Info")
    lbl:SetTextColor(MUTED)
    lbl:SetText("Ajuster la position (pas reglable ci-dessus)")
    y = y + 22

    local nCol = (L - 32 - 12) / 3
    Bouton("GAUCHE", 16, y, nCol, function() Deplacer(Vector(-1, 0, 0)) end)
    Bouton("MONTER", 16 + nCol + 6, y, nCol, function() Deplacer(Vector(0, 0, 1)) end)
    Bouton("DROITE", 16 + (nCol + 6) * 2, y, nCol, function() Deplacer(Vector(1, 0, 0)) end)
    y = y + 36
    Bouton("RECULER", 16, y, nCol, function() Deplacer(Vector(0, -1, 0)) end)
    Bouton("DESCENDRE", 16 + nCol + 6, y, nCol, function() Deplacer(Vector(0, 0, -1)) end)
    Bouton("AVANCER", 16 + (nCol + 6) * 2, y, nCol, function() Deplacer(Vector(0, 1, 0)) end)
    y = y + 36

    -- Rotation autour de la verticale, par crans de 15 degres : assez fin pour
    -- s'aligner sur un mur, assez gros pour ne pas y passer la soiree.
    local function Tourner(nDeg)
        if not ActifSlot() then return end
        _norm:Rotate(Angle(0, nDeg, 0))
        Envoyer(true)
    end
    local nDemi = (L - 32 - 6) / 2
    Bouton("TOURNER -15", 16, y, nDemi, function() Tourner(-15) end)
    Bouton("TOURNER +15", 16 + nDemi + 6, y, nDemi, function() Tourner(15) end)
    y = y + 44

    -- LES LAMES DE SCENE : un cercle de katanas qui flottent dans le bloc, a
    -- distance egale, visibles de tous. AUTRE chose que le rituel du PNJ
    -- (prive, paye, une gagnante) : ici c'est un decor, la scene se joue en RP.
    -- Re-cliquer tire un nouveau jeu de lames.
    local nMaxLames = (EVO_BLANC.Rituel and EVO_BLANC.Rituel.SceneMax) or 120
    Curseur("Lames dans le bloc", 2, nMaxLames,
        function() return _nLames end,
        function(v) _nLames = math.Clamp(math.floor(v), 2, nMaxLames) end, true)

    -- Miroir du verrou serveur (PeutRituelLames) : sans ce garde, un animateur
    -- cliquait, entendait le son, et le serveur jetait le message sans un mot.
    local function PeutLames()
        local lp = LocalPlayer()
        if EVO_BLANC.PeutRituelLames and EVO_BLANC.PeutRituelLames(lp) then return true end
        chat.AddText(Color(230, 180, 120), "[Blanc] Le rituel des lames est reserve au gérant animateur et au MJ+.")
        return false
    end

    local function EnvoyerLames(n)
        if not PeutLames() then return end
        net.Start("evo_blanc:lames")
        net.WriteUInt(_slot, 2)
        net.WriteUInt(n, 7)
        net.SendToServer()
    end
    local nDemiLm = (L - 32 - 6) / 2
    Bouton(function() return "FAIRE APPARAITRE " .. _nLames .. " LAMES" end, 16, y, nDemiLm, function()
        if not ActifSlot() then
            chat.AddText(Color(230, 180, 120), "[Blanc] Pose d'abord le bloc " .. _slot .. ".")
            return
        end
        surface.PlaySound("ui/buttonclickrelease.wav")
        EnvoyerLames(_nLames)
    end)
    Bouton("RETIRER LES LAMES", 16 + nDemiLm + 6, y, nDemiLm, function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        EnvoyerLames(0)
    end)
    y = y + 44

    -- LA TELEPORTATION. La liste montre les NOMS RP (cle Nickname, celle du
    -- reste du serveur), avec le nom Steam en petit pour lever les doublons.
    -- On coche, on envoie : les coches s'endorment et se reveillent dans le
    -- bloc de l'onglet COURANT, donc les deux blocs se peuplent separement.
    local lblTp = vgui.Create("DLabel", f)
    lblTp:SetPos(16, y)
    lblTp:SetSize(L - 32, 18)
    lblTp:SetFont("EVO_Blanc_Info")
    lblTp:SetTextColor(MUTED)
    lblTp:SetText("Endormir dans le bloc " .. _slot .. ", ou ramener a leur place")
    -- On ne reecrit le libelle QUE s'il change : SetText invalide la mise en
    -- page du label, et l'appeler a chaque image pour le meme texte est du
    -- travail pur perte.
    local nVuTp = -1
    lblTp.Think = function(pnl)
        local n = CombienDansBloc(_slot)
        if n == nVuTp then return end
        nVuTp = n
        pnl:SetText(n > 0
            and (n .. " dans le bloc " .. _slot .. " -- RAMENER les renvoie a leur place")
            or ("Endormir dans le bloc " .. _slot .. ", ou ramener a leur place"))
    end
    y = y + 22

    local tCoches = {}
    local liste = vgui.Create("DScrollPanel", f)
    liste:SetPos(16, y)
    liste:SetSize(L - 32, 150)
    liste.Paint = function(_, w, h)
        surface.SetDrawColor(16, 16, 20)
        surface.DrawRect(0, 0, w, h)
    end
    y = y + 156

    local lp = LocalPlayer()
    local tJoueurs = {}
    for _, p in player.Iterator() do
        if IsValid(p) then tJoueurs[#tJoueurs + 1] = p end
    end
    -- Tri par nom RP : c'est comme ca qu'on cherche quelqu'un en animation.
    table.sort(tJoueurs, function(a, b)
        local na = a:GetEvoNWString("Nickname", a:Nick())
        local nb = b:GetEvoNWString("Nickname", b:Nick())
        return na < nb
    end)

    for _, p in ipairs(tJoueurs) do
        local ligne = vgui.Create("DButton", liste)
        ligne:Dock(TOP)
        ligne:DockMargin(2, 2, 2, 0)
        ligne:SetTall(26)
        ligne:SetText("")
        ligne.Paint = function(pnl, w, h)
            if not IsValid(p) then return end
            local bCoche = tCoches[p]
            surface.SetDrawColor(bCoche and Color(30, 18, 20)
                or (pnl:IsHovered() and Color(26, 26, 32) or Color(20, 20, 24)))
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(bCoche and ACCENT or Color(60, 60, 68))
            surface.DrawOutlinedRect(6, 6, 14, 14)
            if bCoche then
                surface.SetDrawColor(ACCENT)
                surface.DrawRect(9, 9, 8, 8)
            end
            local iDort = _dodos[p]
            if iDort then
                surface.SetDrawColor(ACCENT)
                surface.DrawRect(0, 0, 2, h)
            end
            local sRP = p:GetEvoNWString("Nickname", "")
            if sRP == "" then sRP = p:Nick() end
            local sBout = p == lp and " (toi)" or ""
            draw.SimpleText(sRP .. sBout, "EVO_Blanc_Info", 28, h / 2,
                bCoche and BLANC_UI or MUTED, 0, TEXT_ALIGN_CENTER)
            draw.SimpleText(iDort and ("BLOC " .. iDort) or p:Nick(),
                "EVO_Blanc_Info", w - 8, h / 2,
                iDort and ACCENT or Color(90, 90, 98), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end
        ligne.DoClick = function()
            if not IsValid(p) then return end
            tCoches[p] = not tCoches[p] or nil
        end
    end

    -- Les deux gestes de la scene, cote a cote : on envoie, on ramene. Demi
    -- largeur chacun, sinon le menu depasse de l'ecran en 1080.
    local function Coches()
        local t = {}
        for p in pairs(tCoches) do
            if IsValid(p) then t[#t + 1] = p end
        end
        return t
    end

    local nDemiTp = (L - 32 - 6) / 2
    Bouton("ENDORMIR ICI", 16, y, nDemiTp, function()
        local tEnvoi = Coches()
        if #tEnvoi == 0 then
            chat.AddText(Color(230, 180, 120), "[Blanc] Personne de coche.")
            return
        end
        if not ActifSlot() then
            chat.AddText(Color(230, 180, 120), "[Blanc] Pose d'abord le bloc " .. _slot .. ".")
            return
        end
        surface.PlaySound("ui/buttonclickrelease.wav")
        net.Start("evo_blanc:tp")
        net.WriteUInt(_slot, 2)
        net.WriteUInt(math.min(#tEnvoi, 100), 7)
        for i = 1, math.min(#tEnvoi, 100) do
            net.WritePlayer(tEnvoi[i])
        end
        net.SendToServer()
        tCoches = {}
    end)

    -- Rien de coche = tout le bloc rentre. C'est le geste de fin de scene, et
    -- le libelle le DIT : un bouton qui agit sur un nombre invisible fait
    -- hesiter, donc le compte est ecrit dessus.
    local function CochesEndormis()
        local t = {}
        for p in pairs(tCoches) do
            if IsValid(p) and _dodos[p] then t[#t + 1] = p end
        end
        return t
    end

    -- Compter SANS construire de liste : ce libelle est calcule a chaque image
    -- tant que le menu est ouvert, et une table jetee par frame nourrit le
    -- ramasse-miettes pour rien.
    local function NbCochesEndormis()
        local n = 0
        for p in pairs(tCoches) do
            if IsValid(p) and _dodos[p] then n = n + 1 end
        end
        return n
    end

    Bouton(function()
        local k = NbCochesEndormis()
        if k > 0 then return "RAMENER " .. k .. " COCHE(S)" end
        return "RAMENER TOUT (" .. CombienDansBloc(_slot) .. ")"
    end, 16 + nDemiTp + 6, y, nDemiTp, function()
        local tEnvoi = CochesEndormis()
        if #tEnvoi == 0 and CombienDansBloc(_slot) == 0 then
            chat.AddText(Color(230, 180, 120),
                "[Blanc] Personne a ramener du bloc " .. _slot .. ".")
            return
        end
        surface.PlaySound("ui/buttonclickrelease.wav")
        net.Start("evo_blanc:retour")
        net.WriteUInt(_slot, 2)
        net.WriteUInt(math.min(#tEnvoi, 100), 7)
        for i = 1, math.min(#tEnvoi, 100) do
            net.WritePlayer(tEnvoi[i])
        end
        net.SendToServer()
        tCoches = {}
    end)
    y = y + 44

    local r = Bouton("RETIRER LE BLOC", 16, y, L - 32, function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        Envoyer(false)
    end)
    r.Paint = function(pnl, w, h)
        surface.SetDrawColor(pnl:IsHovered() and Color(60, 18, 22) or Color(28, 14, 16))
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("RETIRER LE BLOC", "EVO_Blanc_Info", w / 2, h / 2,
            pnl:IsHovered() and BLANC_UI or ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

concommand.Add("evo_blanc", function()
    local lp = LocalPlayer()
    -- Filtre de confort : le serveur revalide de toute facon, mais ouvrir une
    -- UI qui ne marchera pas est pire que de refuser tout de suite.
    -- Meme droit que le serveur (PeutGerer) : SA ou animateur palier 2+.
    local bOk = EVO_BLANC.PeutGerer and EVO_BLANC.PeutGerer(lp)
    if not bOk then
        chat.AddText(Color(230, 120, 120), "[Blanc] Reserve au staff animateur.")
        return
    end
    Ouvrir()
end)
