-- "addons\\evo_blanc\\lua\\evo_blanc\\sh_rituel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BLANC — MODE RITUEL : « La Salle Blanche » (le choix de la lame).
--
-- LE RITUEL SE JOUE DANS UN BLOC D'ANIMATION (panneau evo_blanc, staff) : le
-- staff PLANTE un champ d'objets dans le sol d'un bloc blanc (une centaine, avec
-- des copies : « meme des faux ») et y endort des joueurs.
-- LE CHAMP EST RENDU CHEZ CHACUN DANS SA VOIE : un joueur katana ne voit que
-- des katanas, un Hakuda que des gantelets, aux memes poses et en meme nombre.
-- Chacun recoit SON objet (tirage SERVEUR, a chance egale parmi ceux du champ
-- de SA voie qu'il peut equiper), cherche, tente (E devant un objet), et le bon
-- lui est remis + eveille son Shikai. Rien ne distingue le bon AVANT d'approcher :
-- sinon ce n'est plus un rituel, juste un trajet. Pas de salle privee : le bloc
-- EST la salle, et le staff garde la main (retirer les objets ou ramener coupe tout).
--
-- UNE GRAINE, PAS UNE LISTE : la globale du bloc porte « graine,nombre » (une
-- string NW plafonne a 199 caracteres, cent indices n'y tiendraient pas). Les
-- poses (grille sur le sol) et la liste de chaque voie (avec copies) en sont
-- DERIVEES par un generateur deterministe : serveur et clients retombent sur
-- exactement les memes objets aux memes points.
--
-- LES VOIES vivent dans le registre R.Voies (source unique = la famille du
-- style, EvoStyle.GetPlayerFamily). Ajouter une voie = une entree la-dedans.
--
-- LE PNJ « Gardien des Lames » ne sert qu'APRES : a un joueur qui a DEJA son
-- Shikai, il vend (R.Prix) le droit d'entendre sa lame autrement = REROLL du
-- Shikai (nom, passif, mot de liberation choisis de nouveau).
--
-- Fichier PARTAGE : config + helpers communs serveur/client.
-- ============================================================================

EVO_BLANC = EVO_BLANC or {}
EVO_BLANC.Rituel = EVO_BLANC.Rituel or {}

local R = EVO_BLANC.Rituel

-- ── PRIX ────────────────────────────────────────────────────────────────────
R.Prix = 300 -- EVO Coins : reroll du Shikai au PNJ

-- ── LE CHAMP PLANTE DANS LE BLOC ────────────────────────────────────────────
R.SceneMax          = 120 -- objets au plus dans un bloc (index reseau en UInt 7)
R.SceneDefaut       = 100 -- « genre 100 plantes » (demande user 08/28)
R.PlanteEcart       = 90  -- ecart vise entre objets (grille sur tout le sol)
R.PlanteEcartMin    = 55  -- ecart plancher quand le bloc est petit
R.SceneMarge        = 80  -- marge entre le champ et les murs du bloc
R.PlanteHauteur     = 34  -- z de l'origine d'un katana plante : la pointe dans le sol, le manche sort
R.PlantePitch       = -90 -- pointe vers le BAS (a +90 la lame sortait vers le haut, constate en jeu 08/28)
R.PlanteInclinaison = 14  -- inclinaison max (+/- degres), chacune la sienne
R.PoseGantHauteur   = 10  -- gantelets poses au sol
R.ChampCacheDuree   = 1.6 -- a la prise, TOUT le champ s'enfonce dans le sol en autant de s (chez le gagnant)

R.DistanceChoix = 48  -- au contact du bon objet : intensite maximale
R.DistanceAura  = 420 -- distance a laquelle les effets commencent a monter
R.DistanceEssai = 70  -- portee du E devant un objet (tenter sa chance) : le plus proche
-- La MONTEE doit se sentir depuis presque partout dans le champ (avec 100 objets
-- sur un grand bloc, 420 u ne couvraient plus rien : « il n'y a pas de pression »).
R.AuraPartDiag  = 0.55 -- portee = au moins DistanceAura, sinon cette part de la diagonale du bloc
R.AuraCourbe    = 0.85 -- < 1 : la montee se sent tot (loin), puis s'emballe au contact (0,6 = trop lourd de loin)

-- Sons (stock HL2/GMod : jamais de fichier manquant en jeu).
R.SonEntree   = "ambient/levels/labs/teleport_postblast_thunder1.wav"
R.SonCoeur    = "player/heartbeat1.wav"
R.SonChoix    = "ambient/levels/labs/electric_explosion1.wav"
R.SonRefus    = "buttons/combine_button_locked.wav" -- E sur un objet muet
R.SonPression = "ambient/machines/thumper_hit.wav"  -- coup sourd des gros battements

-- La PRESSION pres du bon objet : secousse camera servie par le SERVEUR (view
-- punch + balancement, le meme canal que le coup de pression spirituelle),
-- proportionnelle a l'intensite f (0 loin, 1 au contact).
R.PressionTick  = 0.2 -- cadence des envois (s), vers le seul joueur concerne
R.PressionPunch = 6   -- degres de view punch par envoi au contact (x f^2)
R.PressionAmp   = 14  -- amplitude du balancement de position
R.PressionFreq  = 9   -- BASSE : suivie par le lissage camera (haute = aliasee, invisible)

-- ── LES VOIES : deux configs, un champ par voie ─────────────────────────────
-- Source unique de verite = le style (EvoStyle.GetPlayerFamily, derivee du
-- style, jamais un flag a part -- cf. sh_config_styles_noweapon). Chaque voie
-- declare son catalogue (la meme liste que l'inventaire et la boutique), son
-- prefixe d'item (celui de la generation inventaire), ses exclusions et son nom
-- d'affichage. Le champ est rendu chez chacun dans sa voie ; un joueur n'est
-- reconnu que par un objet de sa voie.
R.Voies = {
	katana = {
		prefixe = "katana_",
		liste   = function() return KATANA_SKINS and KATANA_SKINS.List end,
		-- SEULEMENT les lames de Shikai dédiées (user 08/29) : le champ n'offre
		-- plus tout le catalogue de skins achetables, mais les modèles compilés
		-- POUR le shikai. Marqueur `is_shikai` dans KATANA_SKINS.
		exclure = function(id, def) return def.is_shikai ~= true end,
		nom     = function(id, def) return def.named and def.name or ("Katana " .. tostring(def.name)) end,
	},
	hakuda = {
		prefixe = "gauntlet_",
		liste   = function() return NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List end,
		-- Idem katana : seulement les poings de Shikai dédiés (les armes
		-- d'entrainement base/bois n'ont de toute façon pas le marqueur).
		exclure = function(id, def) return def.is_shikai ~= true end,
		nom     = function(id, def) return tostring(def.name or ("Gantelet " .. id)) end,
	},
}
-- Ordre STABLE des voies (la graine de liste depend de ce rang).
R.VoiesOrdre = { "katana", "hakuda" }

-- ── LE PNJ (reroll du Shikai) ───────────────────────────────────────────────
R.NPCModel = "models/evo/summons/shinigami/evo_bdfze942fzd3sdaadxdzd/evo_Bdfze942fzd3sdaadXDZD.mdl"
if game.GetMap() == "hueco_mundo_v1" then
	R.NPCModel = "models/evo/summons/arrancar/evo_w42qywutq3awo/evo_k87h3m96ffoee2.mdl"
end
if SERVER and not util.IsValidModel(R.NPCModel) then
	print("[evo_blanc/rituel] modele dedie absent (" .. R.NPCModel .. ") -> fallback modele commun")
	R.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end

R.NPCSkin       = 0
R.NPCBodygroups = {}
R.NPCScale      = 1.0
R.NPCName       = "Gardien des Lames"
R.NPCSubtitle   = "Entendre sa lame autrement"

R.InteractDistance = 200 -- garde ENT:Use (large, cf. coiffeur)
R.PromptDistance   = 160 -- portee du prompt ET du E a distance

-- Positions de spawn du PNJ, PAR MAP. Deplacables en jeu :
-- menu SAM -> positions -> « PNJ Gardien des Lames » (evo_config_positions).
-- Poses calees A COTE DU TATOUEUR (demande user 08/27) : meme regard que lui,
-- decale de 100 u sur SON axe droit. L'entite fait son propre snap au sol. Si
-- le PNJ tombe dans un decor, le corriger EN JEU (menu SAM) plutot qu'ici.
R.SpawnPositions = {
	rp_seireitei_v1 = {
		{ pos = Vector(-3063.077838, -11604.406914, 439.970215), ang = Angle(0, -2.689282, 0) },
	},
	hueco_mundo_v1  = {
		{ pos = Vector(2553.014082, 8994.533474, 5369.023926), ang = Angle(0, -93.19, 0) },
	},
	gm_construct    = {
		{ pos = Vector(260, -80, -135), ang = Angle(0, 90, 0) },
	},
}

-- ============================================================================
-- HELPERS PARTAGES
-- ============================================================================

--- Generateur deterministe (Park-Miller) : la meme graine donne la meme suite
--- des deux cotes. Entiers < 2^31 multiplies par 48271 : toujours exacts en double.
function R.PRNG(nSeed)
	local x = (math.floor(math.abs(nSeed or 1)) % 2147483646) + 1
	return function()
		x = (x * 48271) % 2147483647
		return x
	end
end

--- Valeur 0..1 deterministe pour (graine, k).
function R.Hash01(nSeed, k)
	local x = ((math.floor(math.abs(nSeed or 1)) + k * 7919) % 2147483646) + 1
	x = (x * 48271) % 2147483647
	x = (x * 48271) % 2147483647
	return x / 2147483647
end

--- Voie du joueur ("katana" / "hakuda"), "katana" si inconnue.
function R.VoieDe(ply)
	if EvoStyle and EvoStyle.GetPlayerFamily then
		local s = EvoStyle.GetPlayerFamily(ply)
		if R.Voies[s] then return s end
	end
	return "katana"
end

--- Voie de CE client (le champ est rendu dans la sienne).
function R.VoieLocale()
	return CLIENT and R.VoieDe(LocalPlayer()) or "katana"
end

--- Une definition (skin de katana, gantelet) typee faction est-elle pour CE
--- joueur ? Un objet de l'autre camp serait gagne sans pouvoir etre equipe :
--- meme regle que la boutique, cf. INVENTORY_CONFIG.GetItemFaction.
function R.FactionOK(ply, def)
	if not (IsValid(ply) and istable(def)) then return false end
	local sFac = string.Trim(string.lower(tostring(def.faction or "all")))
	if sFac == "all" or sFac == "" then return true end
	local sPly = ply:GetEvoNWString("FactionName", "")
	if sFac == "shinigami" then return sPly == "Shinigami" end
	if sFac == "hollow" or sFac == "arrancar" then return sPly == "Hollow" end
	return true
end

--- Catalogue d'une voie : { voie, id, item, model, nom, def }, cles triees =
--- ORDRE STABLE des deux cotes (la liste du champ en est derivee par la graine).
--- Fige au premier appel utile seulement : les autoruns arrivent dans le
--- desordre et evo_blanc charge AVANT le combat system.
local EMPTY = {}
local _scene = {}
--- La lame memorisee correspond-elle a la VOIE actuelle du joueur ? Un changement
--- de style (katana <-> mains nues) rend l'ancienne inexploitable : il faut en
--- re-tirer une, sinon le shikai n'a plus aucun visuel. Renvoie l'id complet ou nil.
function R.SkinDeLaVoie(ply)
	if not IsValid(ply) then return nil end
	local sID = ply:GetEvoNWString("ShikaiSkin", "")
	if sID == "" then return nil end
	local sVoie = R.VoieDe(ply)
	local v = sVoie and R.Voies[sVoie]
	if not v then return nil end
	local sBrut = string.match(sID, "^" .. string.PatternSafe(v.prefixe) .. "(.+)$")
	if not sBrut then return nil end
	local L = v.liste()
	return (istable(L) and L[sBrut]) and sID or nil
end

function R.LamesScene(sVoie)
	if _scene[sVoie] then return _scene[sVoie] end
	local v = R.Voies[sVoie]
	local L = v and v.liste()
	if not istable(L) then return EMPTY end
	local ids = {}
	for id, def in pairs(L) do
		if istable(def) and isstring(def.model) and def.model ~= "" and not v.exclure(id, def) then
			ids[#ids + 1] = id
		end
	end
	if #ids == 0 then return EMPTY end
	table.sort(ids)
	local t = {}
	for _, id in ipairs(ids) do
		local def = L[id]
		t[#t + 1] = { voie = sVoie, id = id, item = v.prefixe .. id, model = def.model, nom = v.nom(id, def), def = def }
	end
	_scene[sVoie] = t
	return t
end

-- Même vivier côté UI et paiement. Le taux est uniforme, sans poids de rareté.
function R.CatalogueReroll(ply, voie, exclude_current)
	local catalogue = {}
	local current_id = exclude_current and R.SkinDeLaVoie(ply)
	for _, entry in ipairs(R.LamesScene(voie)) do
		if entry.item ~= current_id and R.FactionOK(ply, entry.def) then catalogue[#catalogue + 1] = entry end
	end
	return catalogue
end

--- Le contenu du champ pour une voie : nCount entrees tirees AVEC remise (des
--- copies, c'est voulu : « genre 100 plantes, meme des faux ») dans le catalogue
--- de la voie, deterministes depuis la graine du bloc. Vide si le catalogue
--- n'est pas charge.
function R.ListeBloc(sVoie, nSeed, nCount)
	local out = {}
	local tCat = R.LamesScene(sVoie)
	if #tCat == 0 or not nCount or nCount <= 0 then return out end
	local iVoie = 1
	for i, s in ipairs(R.VoiesOrdre) do
		if s == sVoie then iVoie = i end
	end
	local rnd = R.PRNG(nSeed * 31 + iVoie * 1000003)
	for k = 1, nCount do
		out[k] = tCat[(rnd() % #tCat) + 1]
	end
	return out
end

--- Graine et nombre d'objets du bloc iSlot (globale "Lames" = "graine,nombre"),
--- nil si le bloc n'a rien.
function R.ParamsBloc(iSlot)
	local s = GetGlobalString(EVO_BLANC.Cle("Lames", iSlot), "")
	if s == "" then return nil end
	local a, b = string.match(s, "^(%d+),(%d+)$")
	if not a then return nil end
	return tonumber(a), tonumber(b)
end

--- Les objets du bloc iSlot pour une voie (entrees du catalogue, avec copies,
--- dans l'ordre des poses). Vide si le bloc n'a rien.
function R.LamesBloc(iSlot, sVoie)
	local nSeed, n = R.ParamsBloc(iSlot)
	if not nSeed then return {} end
	return R.ListeBloc(sVoie, nSeed, n)
end

--- Le bloc iSlot a-t-il un champ plante ?
function R.BlocALames(iSlot)
	return R.ParamsBloc(iSlot) ~= nil
end

--- Poses des objets PLANTES dans un bloc : grille sur tout le sol (ecart
--- R.PlanteEcart, resserre jusqu'a PlanteEcartMin si le bloc est petit), cases
--- choisies et jitter tires de la GRAINE : serveur et clients retombent sur les
--- memes points. Le nombre rendu peut etre INFERIEUR a nCount si le sol ne
--- porte pas tout (le serveur s'en sert pour borner). tOut = table de Vectors
--- REUTILISEE ; z = niveau du SOL, la hauteur depend de l'objet (cf. cl_blanc).
function R.PosLamesBloc(vPos, nYaw, nLarg, nProf, nCount, nSeed, tOut)
	tOut = tOut or {}
	local m = R.SceneMarge or 80
	local L, P = math.max(0, nLarg - 2 * m), math.max(0, nProf - 2 * m)
	local S = R.PlanteEcart or 90
	local nx, ny = math.floor(P / S), math.floor(L / S)
	if nx * ny < nCount then
		S = math.max(R.PlanteEcartMin or 55, math.sqrt(L * P / math.max(1, nCount)))
		nx, ny = math.floor(P / S), math.floor(L / S)
	end
	local nCases = nx * ny
	nCount = math.min(nCount, nCases)
	-- Axes du bloc a plat (la normale n'a pas de z) : avant = (cos, sin), droite = (sin, -cos).
	local fx, fy = math.cos(math.rad(nYaw)), math.sin(math.rad(nYaw))
	local rx, ry = fy, -fx
	local rnd = R.PRNG(nSeed)
	-- Cases sans remise (Fisher-Yates partiel) : jamais deux objets dans la meme.
	local tCase = {}
	for i = 1, nCases do tCase[i] = i end
	for k = 1, nCount do
		local j = k + (rnd() % (nCases - k + 1))
		tCase[k], tCase[j] = tCase[j], tCase[k]
		local c = tCase[k] - 1
		local ix, iy = c % nx, math.floor(c / nx)
		local lx = -P / 2 + (ix + 0.5) * S + (rnd() / 2147483647 - 0.5) * 0.5 * S
		local ly = -L / 2 + (iy + 0.5) * S + (rnd() / 2147483647 - 0.5) * 0.5 * S
		local v = tOut[k]
		if not v then v = Vector() tOut[k] = v end
		v.x = vPos.x + fx * lx + rx * ly
		v.y = vPos.y + fy * lx + ry * ly
		v.z = vPos.z
	end
	for k = #tOut, nCount + 1, -1 do tOut[k] = nil end
	return tOut
end

--- Orientation d'un objet plante, deterministe : yaw quelconque, inclinaison
--- +/- R.PlanteInclinaison. Retourne yaw, inclinaison.
function R.PoseObjet(nSeed, k)
	local a, b = R.Hash01(nSeed, k), R.Hash01(nSeed, k + 100003)
	return a * 360, (b * 2 - 1) * (R.PlanteInclinaison or 14)
end

--- Cote minimal d'un bloc (carre) pour planter nCount objets a l'ecart vise.
function R.TailleBlocPour(nCount)
	return math.ceil(math.sqrt(math.max(1, nCount)) * (R.PlanteEcart or 90) + 2 * (R.SceneMarge or 80))
end

--- Empreinte numerique de la geometrie d'un bloc (pos, orientation, taille) :
--- comparer deux nombres par image, recalculer les poses seulement au changement.
function R.SignatureBloc(iSlot)
	local vPos  = GetGlobalVector(EVO_BLANC.Cle("Pos", iSlot), vector_origin)
	local vNorm = GetGlobalVector(EVO_BLANC.Cle("Normale", iSlot), Vector(0, 1, 0))
	return vPos.x + vPos.y * 3 + vPos.z * 7 + vNorm.x * 1013 + vNorm.y * 2027
		+ GetGlobalFloat(EVO_BLANC.Cle("Largeur", iSlot), 600) * 13
		+ GetGlobalFloat(EVO_BLANC.Cle("Profondeur", iSlot), 600) * 17
end

--- Poses des objets du bloc iSlot, lues dans ses globales (nil si le bloc n'est
--- pas pose). tOut reutilisable comme ci-dessus.
function R.PosLamesDuBloc(iSlot, nCount, nSeed, tOut)
	if not GetGlobalBool(EVO_BLANC.Cle("Actif", iSlot), false) then return nil end
	local vPos  = GetGlobalVector(EVO_BLANC.Cle("Pos", iSlot), vector_origin)
	local vNorm = GetGlobalVector(EVO_BLANC.Cle("Normale", iSlot), Vector(0, 1, 0))
	local nLarg = GetGlobalFloat(EVO_BLANC.Cle("Largeur", iSlot), 600)
	local nProf = GetGlobalFloat(EVO_BLANC.Cle("Profondeur", iSlot), 600)
	return R.PosLamesBloc(vPos, vNorm:Angle().y, nLarg, nProf, nCount, nSeed, tOut)
end

--- Portee de la montee dans le bloc iSlot : au moins R.DistanceAura, et plus si
--- le bloc est grand (une part de sa diagonale).
function R.AuraBloc(iSlot)
	local nLarg = GetGlobalFloat(EVO_BLANC.Cle("Largeur", iSlot), 600)
	local nProf = GetGlobalFloat(EVO_BLANC.Cle("Profondeur", iSlot), 600)
	return math.max(R.DistanceAura or 420, (R.AuraPartDiag or 0.55) * math.sqrt(nLarg * nLarg + nProf * nProf))
end

--- Intensite 0..1 pour une distance d au bon objet, avec la portee nAura.
--- Courbe concave (R.AuraCourbe < 1) : on sent la montee tot, elle s'emballe pres.
--- MEME calcul serveur (secousse) et client (effets) : les deux montent ensemble.
function R.Intensite(d, nAura)
	local a, b = R.DistanceChoix or 48, nAura or R.DistanceAura or 420
	if d <= a then return 1 end
	if d >= b then return 0 end
	return (1 - (d - a) / (b - a)) ^ (R.AuraCourbe or 0.6)
end
