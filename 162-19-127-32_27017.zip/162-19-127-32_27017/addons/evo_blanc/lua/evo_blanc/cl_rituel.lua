-- "addons\\evo_blanc\\lua\\evo_blanc\\cl_rituel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BLANC — MODE RITUEL, cote client : ce qu'on ressent dans le bloc.
--
-- Le bloc et ses lames sont dessines par cl_blanc (visibles de tous). ICI, chez
-- le joueur qui a une lame assignee et lui seul : « APPUYER SUR E » au-dessus
-- de chaque lame, et surtout la MONTEE -- plus on approche de la bonne lame,
-- plus le monde se derobe : la PRESSION tombe du haut (la meme grammaire que
-- l'activation du Shikai, cf. cl_pression : voile violace, pluie de traits
-- noirs, image ecrasee et floue), du noir rampe depuis les bords, tout tremble,
-- un coeur bat, et la lame parle.
-- E devant une lame = on tente sa chance : la mauvaise repond par une phrase de
-- refus (cent, cf. cl_rituel_phrases), la bonne par la revelation.
-- La SECOUSSE de camera vient du SERVEUR (view punch, comme la pression
-- spirituelle) : un CalcView client etait coupe par la camera orbitale (premier
-- retour non nul gagne) et faisait sauter la vue en premiere personne.
-- Le PNJ, lui, ne fait qu'ouvrir l'offre de REROLL du Shikai (panneau).
--
-- REGLE DE PERF MAISON : zero allocation par image. Couleurs, textes, largeurs,
-- descripteurs de coulees et de traits : tout est fige au chargement, et les
-- Vector/Angle de travail sont reutilises (jamais un Vector() neuf en rendu).
-- ============================================================================

local R = EVO_BLANC.Rituel

local MAT_GRAD_D = Material("gui/gradient_down")
local MAT_GRAD_U = Material("gui/gradient_up")
local MAT_GRAD_H = Material("gui/gradient")

surface.CreateFont("EVO_Rituel_Titre",   { font = "Roboto", size = 74, weight = 900, antialias = true })
surface.CreateFont("EVO_Rituel_Nom",     { font = "Roboto", size = 44, weight = 800, antialias = true })
surface.CreateFont("EVO_Rituel_Voix",    { font = "Roboto", size = 34, weight = 600, antialias = true })
surface.CreateFont("EVO_Rituel_Refus",   { font = "Roboto", size = 30, weight = 500, antialias = true, italic = true })
surface.CreateFont("EVO_Rituel_Petit",   { font = "Roboto", size = 20, weight = 500, antialias = true })
surface.CreateFont("EVO_Rituel_Tag",     { font = "Roboto", size = 54, weight = 900, antialias = true })
surface.CreateFont("EVO_Rituel_TagSous", { font = "Roboto", size = 30, weight = 500, antialias = true })

local COL_ACCENT = Color(207, 68, 78)
local COL_TXT    = Color(236, 236, 236)
local COL_DIM    = Color(138, 138, 147)
-- Couleurs MUTEES chaque image (alpha variable) : allouees une fois ici.
local _cVoix  = Color(236, 236, 236, 0)
local _cVoix2 = Color(160, 160, 168, 0)
local _cRefus = Color(236, 236, 236, 0)
local _cOut   = Color(0, 0, 0, 0)
local _cTend  = Color(0, 0, 0, 0)
local _cFlash = Color(255, 255, 255, 0)
local _cTitre = Color(236, 236, 236, 0)
local _cNom   = Color(207, 68, 78, 0)
local _cSous  = Color(138, 138, 147, 0)
local _cTag   = Color(255, 255, 255, 0)
local _cTagA  = Color(207, 68, 78, 0)

-- Etat du rituel en cours (nil = pas de lame assignee).
local RIT = nil

--- Ce client voit-il le champ du bloc iSlot ? Seulement s'il y joue SON rituel
--- (endormi dedans, objet assigne) : les autres joueurs du bloc ne voient rien
--- et rien ne leur arrive (user 08/28). Le staff qui peut planter les lames
--- (SA / gérant / mj_plus) le voit toujours, pour verifier ce qu'il a plante.
function R.VoitLeChamp(iSlot)
	if RIT and RIT.bloc == iSlot then return true end
	local lp = LocalPlayer()
	return EVO_BLANC.PeutRituelLames and EVO_BLANC.PeutRituelLames(lp)
end

-- Vecteurs/angles de travail (jamais realloues).
local _v1 = Vector()
local _angTag = Angle()

-- ── COULEES NOIRES : descripteurs figes au chargement ───────────────────────
-- 4 bords, des bandes de largeurs et de vitesses variees : c'est la variete des
-- phases qui donne l'impression d'une matiere vivante, pas du hasard par image.
local TENDRILS = {}
for i = 1, 26 do
	TENDRILS[i] = {
		bord    = (i % 4) + 1,             -- 1 haut, 2 bas, 3 gauche, 4 droite
		pos     = ((i * 0.37) % 1),        -- position le long du bord (0..1)
		epais   = 0.035 + ((i * 0.13) % 1) * 0.07,
		vitesse = 0.7 + ((i * 0.29) % 1) * 1.9,
		phase   = (i * 1.7) % 6.283,
		gain    = 0.55 + ((i * 0.19) % 1) * 0.75,
	}
end

-- ── TRAITS DE PRESSION : la pluie noire de l'activation du Shikai ───────────
-- Meme recette que cl_pression (traits qui naissent au-dessus de l'ecran et
-- tombent quasi verticalement, fondu triangulaire), mais le pool est fige :
-- chaque trait est une table MUTEE a sa renaissance, jamais reallouee.
local LIGNES_N = 44
local LIGNES = {}
for i = 1, LIGNES_N do
	LIGNES[i] = { x = 0, y = 0, dx = 0, dy = 1, rot = -90, len = 100, th = 2, spd = 1000, t0 = -1, t1 = -1 }
end

local function DessinerPression(nCount, nAlpha)
	local w, h = ScrW(), ScrH()
	local now = RealTime()
	draw.NoTexture()
	for i = 1, nCount do
		local l = LIGNES[i]
		if now >= l.t1 then
			local nAng = math.pi * 0.5 + math.Rand(-0.07, 0.07)
			local nLen = math.Rand(0.12, 0.34) * h
			l.x, l.y = math.Rand(0, w), -nLen - math.Rand(0, h * 0.05)
			l.dx, l.dy = math.cos(nAng), math.sin(nAng)
			l.rot = -math.deg(nAng)
			l.len = nLen
			l.th = math.random(1, 3)
			l.spd = math.Rand(1.6, 2.4) * h
			l.t0, l.t1 = now, now + math.Rand(0.35, 0.6)
		end
		local f = 1 - math.abs((now - l.t0) / (l.t1 - l.t0) * 2 - 1)
		local d = l.spd * (now - l.t0) + l.len * 0.5
		surface.SetDrawColor(0, 0, 0, math.min(nAlpha * f, 255))
		surface.DrawTexturedRectRotated(l.x + l.dx * d, l.y + l.dy * d, l.len, l.th, l.rot)
	end
end

-- ── LE DIALOGUE : ce que la lame dit, palier par palier, en approchant ──────
-- Chaque replique dit de plus en plus clairement que c'est ELLE ; la derniere
-- donne le geste. La precedente reste affichee en petit : un echange, pas une
-- ligne isolee.
local DIALOGUE = {
	{ seuil = 0.14, txt = "Quelqu'un t'observe." },
	{ seuil = 0.28, txt = "Tu la sens ? Cette pression, c'est moi." },
	{ seuil = 0.42, txt = "Plus près. N'aie pas peur." },
	{ seuil = 0.56, txt = "Je t'ai attendu. Longtemps." },
	{ seuil = 0.70, txt = "C'est toi. C'est bien toi." },
	{ seuil = 0.84, txt = "Prends-moi. Appuie sur E." },
}

local REFUS_DUREE = 3.2 -- affichage d'une phrase de refus (s)

-- ============================================================================
-- L'OFFRE DU PNJ (reroll du Shikai)
-- ============================================================================

net.Receive("evo_blanc:rituel_offre", function()
	local price, refusal = net.ReadUInt(32), net.ReadString()
	if NCM_SHIKAI_RENAMER and NCM_SHIKAI_RENAMER.OpenReroll then
		NCM_SHIKAI_RENAMER.OpenReroll(price, refusal, false)
	end
end)

-- Prompt « [E] » partage (evo_npc_core) : un seul style de plaque pour tous les
-- PNJ, et jamais deux prompts superposes.
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["zanpakuto"] = {
	fGetTarget = function()
		if RIT then return nil end -- en plein rituel
		local lp = LocalPlayer()
		if not IsValid(lp) then return nil end
		local nMaxSqr = (R.PromptDistance or 160) ^ 2
		local best, bestD
		for _, e in ipairs(ents.FindByClass("evo_npc_zanpakuto")) do
			if IsValid(e) then
				local d = e:GetPos():DistToSqr(lp:GetPos())
				if d <= nMaxSqr and (not bestD or d < bestD) then best, bestD = e, d end
			end
		end
		return best
	end,
	fLabel = function() return "[E] Parler au " .. (R.NPCName or "Gardien des Lames") end,
	fSub   = function() return R.Prix .. " coins : " .. (R.NPCSubtitle or "") end,
}

-- ============================================================================
-- LE RITUEL (une lame assignee dans un bloc)
-- ============================================================================

-- heartbeat1.wav est un son BOUCLE du moteur : joue par surface.PlaySound il
-- s'empilait a l'infini et ne s'arretait jamais (lecon de cl_pression). On le
-- joue sur le joueur, StopSound avant chaque battement et a la sortie.
local function StopCoeur()
	local lp = LocalPlayer()
	if IsValid(lp) then lp:StopSound(R.SonCoeur) end
end

net.Receive("evo_blanc:rituel_debut", function()
	local iBloc = net.ReadUInt(2)
	local n = net.ReadUInt(7)
	local iGagnant = net.ReadUInt(7)

	StopCoeur()
	RIT = {
		bloc     = iBloc,
		n        = n,     -- objets dans le cercle (les poses viennent des globales du bloc)
		gagnant  = iGagnant,
		pos      = {},    -- poses des objets (graine du bloc), recalculees si le bloc bouge
		seed     = nil,   -- graine du bloc (globale) : parfois repliquee APRES ce net, on attend
		blocSig  = nil,
		debut    = RealTime(),
		f        = 0,     -- intensite lissee 0..1
		coeur    = 0,     -- prochain battement
		punch    = 0,     -- secousse du HUD apres un battement (decroit)
		verrou   = false, -- prise deja envoyee
		flash    = 0,
		gagne    = nil,
		-- E : on attend un FRONT (un E peut encore etre enfonce a l'arrivee).
		useWasDown = true,
		essaiNext  = 0,
		refusTxt   = nil, refusT = -10, refusIdx = 0,
		dial       = 0,   dialT  = -10,
	}
	RIT.seed = R.ParamsBloc and R.ParamsBloc(iBloc) or nil
	R.ChampCacheSig = nil -- nouveau rituel : le champ reapparait s'il avait ete enfoui
	surface.PlaySound(R.SonEntree)
end)

net.Receive("evo_blanc:rituel_fin", function()
	local bGagne = net.ReadBool()
	-- Fin sans prise (staff, mort, lames retirees) : le champ redevient visible.
	-- Apres une prise, il reste enfoui jusqu'au prochain rituel ou champ.
	if not bGagne then R.ChampCacheSig = nil end
	StopCoeur()
	RIT = nil
end)

net.Receive("evo_blanc:rituel_gagne", function()
	local sNom = net.ReadString() -- ce qu'il recoit (katana ou gantelet selon sa voie), nomme par le serveur
	local bShikai = net.ReadBool()
	if not RIT then return end
	RIT.gagne = true
	RIT.nomGagne = sNom
	RIT.shikai = bShikai
	RIT.flash = RealTime()
	-- « Quand ca se finit, ca enleve tous les katanas » (user 08/28) : chez le
	-- gagnant, tout le champ s'enfonce dans le sol (cl_blanc lit ces deux champs).
	R.ChampCacheSig = GetGlobalString(EVO_BLANC.Cle("Lames", RIT.bloc), "")
	R.ChampCacheDepuis = RealTime()
	StopCoeur()
	surface.PlaySound(R.SonChoix)
end)

--- Intensite 0..1 : 0 loin de la bonne lame, 1 au contact.
local function Intensite()
	local lp = LocalPlayer()
	if not (RIT and IsValid(lp)) then return 0 end
	local v = RIT.pos[RIT.gagnant]
	if not v then return 0 end
	return R.Intensite(lp:GetPos():Distance(v), RIT.aura)
end

-- Au-dessus de chaque lame, face a la camera : « APPUYER SUR E / pour tenter sa
-- chance ». En accent quand la lame est a portee du E, discret sinon. RIEN ne
-- marque la bonne lame (pas de halo, demande user 08/28) : c'est au joueur de
-- choisir et de lire la reponse ; seule la pression trahit la proximite.
hook.Add("PostDrawTranslucentRenderables", "EVO_Blanc::Rituel::Tags", function(_, bSkybox)
	if bSkybox or not RIT then return end

	if not RIT.gagne then
		local lp = LocalPlayer()
		local vEye = EyePos()
		local vPly = IsValid(lp) and lp:GetPos() or vEye
		local nPortee = R.DistanceEssai or 95
		for i = 1, #RIT.pos do
			local v = RIT.pos[i]
			local nD = vPly:Distance(v)
			-- Une centaine d'objets plantes : l'etiquette seulement autour de soi.
			if nD <= 240 then
				_v1.x, _v1.y, _v1.z = v.x, v.y, v.z + 58
				-- Billboard yaw-only face a la camera de rendu (suit la camera orbitale).
				_angTag.p, _angTag.y, _angTag.r = 0, math.deg(math.atan2(_v1.y - vEye.y, _v1.x - vEye.x)) - 90, 90
				local bProche = nD <= nPortee
				if EVO_ZonePrompt and EVO_ZonePrompt.Row then
					-- Style invite partage : nom discret autour, touche + action a portee du E.
					cam.Start3D2D(_v1, _angTag, 0.12)
						surface.SetAlphaMultiplier(bProche and 1 or 0.45)
						EVO_ZonePrompt.Row(-20, "Lame scellée", bProche and "Tenter sa chance", "E", "point")
						surface.SetAlphaMultiplier(1)
					cam.End3D2D()
				else
					_cTag.a  = bProche and 255 or 110
					_cTagA.a = bProche and 255 or 0
					cam.Start3D2D(_v1, _angTag, 0.12)
						draw.SimpleText("APPUYER SUR E", "EVO_Rituel_Tag", 0, -20,
							bProche and _cTagA or _cTag, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						draw.SimpleText("pour tenter sa chance", "EVO_Rituel_TagSous", 0, 22,
							_cTag, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					cam.End3D2D()
				end
			end
		end
	end

end)

-- ── TENTER SA CHANCE (E devant une lame) ────────────────────────────────────
-- Le client CONSTATE que le joueur tente une lame ; pour la bonne, le SERVEUR
-- decide (distance reelle revalidee). Un seul envoi par rituel -- le verrou
-- `RIT.verrou` se pose avant l'envoi et ne se leve qu'au rituel suivant.
-- Les mauvaises lames ne voyagent pas : elles repondent ici, par une phrase.
-- netgate: edge -- verrou RIT.verrou : un seul envoi par rituel
local function TenterChance(lp)
	if not RIT or RIT.verrou or RIT.gagne then return end
	local t = RealTime()
	if t < RIT.essaiNext then return end
	RIT.essaiNext = t + 0.6

	-- La lame la plus proche a portee, sans exiger de viser : dans un vide blanc
	-- ou tout tourne, viser une lame fine serait une epreuve de plus.
	local vP = lp:GetPos()
	local nPortee = R.DistanceEssai or 95
	local best, bestD
	for i = 1, #RIT.pos do
		local d = vP:Distance(RIT.pos[i])
		if d <= nPortee and (not bestD or d < bestD) then best, bestD = i, d end
	end
	if not best then return end

	if best == RIT.gagnant then
		RIT.verrou = true
		net.Start("evo_blanc:rituel_prendre")
		net.SendToServer()
		return
	end

	-- Lame muette : une phrase au hasard, jamais deux fois la meme de suite.
	local tP = R.PhrasesRefus
	if tP and #tP > 0 then
		local k = math.random(1, #tP)
		if k == RIT.refusIdx and #tP > 1 then k = (k % #tP) + 1 end
		RIT.refusIdx = k
		RIT.refusTxt = tP[k]
		RIT.refusT = t
	end
	surface.PlaySound(R.SonRefus)
end

-- ── LE SUIVI (une fois par image) ───────────────────────────────────────────
hook.Add("Think", "EVO_Blanc::Rituel::Suivi", function()
	if not RIT then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Les poses viennent de la graine du bloc ; recalculees seulement si le bloc
	-- bouge (empreinte numerique). Graine pas encore repliquee : on attend.
	if not RIT.seed then RIT.seed = R.ParamsBloc(RIT.bloc) end
	if not RIT.seed then return end
	local nSig = R.SignatureBloc(RIT.bloc)
	if nSig ~= RIT.blocSig then
		if not R.PosLamesDuBloc(RIT.bloc, RIT.n, RIT.seed, RIT.pos) then return end
		RIT.blocSig = nSig
		RIT.aura = R.AuraBloc(RIT.bloc) -- meme portee que le serveur (secousse)
	end
	local ft = FrameTime()
	-- Lissage : l'intensite ne saute pas quand on longe la lame.
	RIT.f = Lerp(math.min(1, ft * 6), RIT.f, Intensite())
	RIT.punch = RIT.punch * math.max(0, 1 - ft * 7)

	local t, f = RealTime(), RIT.f
	-- Le coeur bat de plus en plus vite (0,95 s au loin, 0,24 s au contact) et de
	-- plus en plus haut ; les gros battements s'accompagnent d'un coup sourd.
	if not RIT.gagne and f > 0.12 and t >= RIT.coeur then
		RIT.coeur = t + Lerp(f, 0.95, 0.24)
		lp:StopSound(R.SonCoeur)
		lp:EmitSound(R.SonCoeur, 70, math.floor(85 + 35 * f), 0.9)
		RIT.punch = RIT.punch + 1 + 5 * f * f
		if f > 0.55 then lp:EmitSound(R.SonPression, 70, math.floor(70 + 30 * f), 0.5 * f) end
	end

	-- La replique du palier atteint (dans les deux sens : s'eloigner la retire).
	local k = 0
	for i = #DIALOGUE, 1, -1 do
		if f >= DIALOGUE[i].seuil then k = i break end
	end
	if k ~= RIT.dial then RIT.dial, RIT.dialT = k, t end

	-- E sur FRONT montant : un appui = une tentative.
	local bUse = lp:KeyDown(IN_USE)
	if bUse and not RIT.useWasDown then TenterChance(lp) end
	RIT.useWasDown = bUse
end)

-- ── L'ECRAN QUI SE DEROBE ───────────────────────────────────────────────────
hook.Add("HUDPaint", "EVO_Blanc::Rituel::Ecran", function()
	if not RIT then return end
	local w, h = ScrW(), ScrH()
	local f, t = RIT.f, RealTime()
	-- Tout ce qui est ecrit tremble avec la pression (et saute a chaque battement).
	local jx = (math.sin(t * 47) * 7 + math.sin(t * 91) * RIT.punch * 2) * f * f
	local jy = (math.cos(t * 61) * 6 + math.cos(t * 83) * RIT.punch * 2) * f * f

	-- 1) LA PRESSION : le haut de l'ecran noircit, un voile violace ecrase
	--    l'image, et une pluie de traits noirs s'abat, de plus en plus dense.
	if f > 0.03 then
		surface.SetDrawColor(14, 10, 22, math.floor(130 * f))
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(4, 3, 9, math.floor(255 * math.min(1, f * 1.1)))
		surface.SetMaterial(MAT_GRAD_D)
		surface.DrawTexturedRect(0, 0, w, h * (0.35 + 0.35 * f))
		DessinerPression(math.ceil(LIGNES_N * math.min(1, f * 1.1)), 230 * math.min(1, f * 1.2))
	end

	-- 2) Les coulees noires : elles rampent depuis les bords vers le centre.
	if f > 0.03 then
		for i = 1, #TENDRILS do
			local d = TENDRILS[i]
			local nLong = f * d.gain * (0.62 + 0.38 * math.sin(t * d.vitesse + d.phase))
			if nLong > 0.01 then
				_cTend.a = math.floor(255 * math.min(1, f * 1.35))
				surface.SetDrawColor(_cTend)
				if d.bord == 1 then
					surface.SetMaterial(MAT_GRAD_D)
					surface.DrawTexturedRect(d.pos * w, 0, d.epais * w, nLong * h)
				elseif d.bord == 2 then
					surface.SetMaterial(MAT_GRAD_U)
					surface.DrawTexturedRect(d.pos * w, h - nLong * h, d.epais * w, nLong * h)
				elseif d.bord == 3 then
					surface.SetMaterial(MAT_GRAD_H)
					surface.DrawTexturedRect(0, d.pos * h, nLong * w, d.epais * h)
				else
					surface.SetMaterial(MAT_GRAD_H)
					-- U inverse : opaque a DROITE, transparent vers le centre.
					surface.DrawTexturedRectUV(w - nLong * w, d.pos * h, nLong * w, d.epais * h, 1, 0, 0, 1)
				end
			end
		end
	end

	-- 3) Vignette : les bords s'assombrissent en bloc, ca serre l'image.
	if f > 0.15 then
		_cTend.a = math.floor(190 * (f - 0.15) / 0.85)
		surface.SetDrawColor(_cTend)
		surface.SetMaterial(MAT_GRAD_D)
		surface.DrawTexturedRect(0, 0, w, h * 0.30)
		surface.SetMaterial(MAT_GRAD_U)
		surface.DrawTexturedRect(0, h * 0.70, w, h * 0.30)
	end

	-- 4) Le dialogue de la lame : la replique du palier en grand, la precedente
	--    au-dessus en petit. Tout tremble.
	if RIT.dial > 0 and not RIT.gagne then
		local nIn = math.min(1, (t - RIT.dialT) / 0.25)
		_cVoix.a = math.floor(235 * nIn * (0.72 + 0.28 * math.sin(t * 2.6)))
		_cOut.a = math.floor(200 * nIn)
		draw.SimpleTextOutlined(DIALOGUE[RIT.dial].txt, "EVO_Rituel_Voix", w * 0.5 + jx, h * 0.30 + jy,
			_cVoix, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, _cOut)
		if RIT.dial > 1 then
			_cVoix2.a = math.floor(150 * nIn)
			draw.SimpleText(DIALOGUE[RIT.dial - 1].txt, "EVO_Rituel_Petit", w * 0.5 - jx * 0.5, h * 0.30 - 36 + jy * 0.5,
				_cVoix2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- 5) La phrase de refus (E sur une lame muette) : entre vite, s'efface lentement.
	if RIT.refusTxt and not RIT.gagne then
		local dt = t - RIT.refusT
		if dt < REFUS_DUREE then
			local a = math.min(1, dt / 0.15) * math.min(1, (REFUS_DUREE - dt) / 0.6)
			_cRefus.a = math.floor(240 * a)
			_cOut.a = math.floor(200 * a)
			draw.SimpleTextOutlined(RIT.refusTxt, "EVO_Rituel_Refus", w * 0.5 + jx * 0.4, h * 0.60 + jy * 0.4,
				_cRefus, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, _cOut)
		end
	end

	-- 6) Le flash de la prise, puis la revelation.
	if RIT.gagne then
		local dt = t - RIT.flash
		if dt < 1.2 then
			_cFlash.a = math.floor(255 * math.max(0, 1 - dt / 1.2))
			surface.SetDrawColor(_cFlash)
			surface.DrawRect(0, 0, w, h)
		end
		if dt > 0.5 then
			local a = math.floor(255 * math.min(1, (dt - 0.5) / 0.8))
			_cTitre.a, _cNom.a, _cSous.a = a, a, a
			draw.SimpleText("TU AS ÉTÉ CHOISI", "EVO_Rituel_Titre", w * 0.5, h * 0.34,
				_cTitre, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			-- Nom fige a la victoire (recu du serveur) : rien a resoudre par image.
			draw.SimpleText(RIT.nomGagne or "Zanpakuto", "EVO_Rituel_Nom", w * 0.5, h * 0.44,
				_cNom, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if RIT.shikai then
				draw.SimpleText("Ta lame s'éveille.", "EVO_Rituel_Petit", w * 0.5, h * 0.51,
					_cSous, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	elseif f < 0.05 then
		-- Consigne d'entree : sans elle, on tourne en rond dans un vide blanc
		-- sans savoir ce qu'on cherche.
		draw.SimpleText("Une lame te reconnaîtra. Devant l'une d'elles, appuie sur E pour tenter ta chance.",
			"EVO_Rituel_Petit", w * 0.5, h * 0.86, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end)

-- « Poids » sur l'image pres de la bonne lame : desaturation, contraste, flou
-- de mouvement (meme grammaire que la victime de la pression, en plus fort).
local _tCrush = {
	["$pp_colour_addr"] = 0, ["$pp_colour_addg"] = 0, ["$pp_colour_addb"] = 0,
	["$pp_colour_mulr"] = 0, ["$pp_colour_mulg"] = 0, ["$pp_colour_mulb"] = 0,
	["$pp_colour_brightness"] = 0, ["$pp_colour_contrast"] = 1, ["$pp_colour_colour"] = 1,
}
hook.Add("RenderScreenspaceEffects", "EVO_Blanc::Rituel::Ecrasement", function()
	if not RIT then return end
	local f = RIT.f
	if f < 0.02 then return end
	_tCrush["$pp_colour_brightness"] = -0.10 * f
	_tCrush["$pp_colour_contrast"]   = 1 + 0.35 * f
	_tCrush["$pp_colour_colour"]     = 1 - 0.7 * f
	DrawColorModify(_tCrush)
	DrawMotionBlur(0.1, 0.9 * f, 0.01)
end)

-- Pendant le rituel, le HUD du jeu n'a plus lieu d'etre : on est nulle part.
local HUD_CACHE = {
	CHudHealth = true, CHudBattery = true, CHudAmmo = true,
	CHudSecondaryAmmo = true, CHudCrosshair = true, CHudDamageIndicator = true,
}
hook.Add("HUDShouldDraw", "EVO_Blanc::Rituel::HUD", function(sNom)
	if RIT and HUD_CACHE[sNom] then return false end
end)

-- Filet : un changement de map laisse le coeur boucler.
hook.Add("ShutDown", "EVO_Blanc::Rituel::Nettoyage", StopCoeur)
