-- "addons\\evo_blanc\\lua\\autorun\\sh_loader_blanc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BLANC - un panneau d'un blanc PUR pose dans le monde, pour le staff.
--
-- A QUOI CA SERT : une surface parfaitement blanche pour les animations (ecran
-- de projection, fond de scene, flash de lumiere). Le point dur n'est pas le
-- carre, c'est le BLANC : un panneau eclaire par la map prend l'ombre et la
-- teinte ambiantes, et sous une nuit d'evo_ciel il sortirait gris-bleu. On
-- passe donc par un materiau UnlitGeneric, que le moteur n'eclaire PAS : il
-- s'affiche a 255,255,255 quel que soit l'eclairage, de jour, de nuit, dans
-- une cave.
--
-- Visible par TOUT LE MONDE : l'etat (position, taille, orientation) vit
-- dans des variables globales repliquees, donc un joueur qui se connecte
-- en cours d'animation voit le meme panneau que les autres.
--
--   evo_blanc         ouvre le reglage (SA ou animateur palier 2+ sur perso anim)
--   evo_blanc_off     retire le panneau (meme droit)
--   planter les lames : SA, gérant animateur (palier 3+) ou mj_plus
--
-- MODE RITUEL (sh/sv/cl_rituel) : LA SALLE BLANCHE se joue DANS UN BLOC. Le
-- staff pose un cercle de lames dans un bloc (curseur + bouton du panneau) et
-- y endort des joueurs : chacun recoit SA lame (tirage serveur), la cherche
-- (pression, dialogue), la tente (E) et la bonne lui remet katana + Shikai.
-- Le PNJ « Gardien des Lames » ne sert qu'a qui a deja son Shikai : reroll.
--   evo_rituel_off    coupe tous les rituels en cours (superadmin)
-- ============================================================================

EVO_BLANC = EVO_BLANC or {}

--- Poser / deplacer / endormir / ramener : SA ou palier animateur 2+ (perso anim).
function EVO_BLANC.PeutGerer(ply)
    if not (IsValid(ply) and ply:IsPlayer()) then return false end
    if ply:IsSuperAdmin() then return true end
    return ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0) >= 2
end

--- Planter les lames et lancer le rituel (donne un Shikai) : SA, palier 3+
--- (gérant animateur / gérant RP) ou mj_plus. Toujours via PeutGerer : un
--- MJ+ sur perso RP ne doit pas forger le net.
function EVO_BLANC.PeutRituelLames(ply)
    if not EVO_BLANC.PeutGerer(ply) then return false end
    if ply:IsSuperAdmin() then return true end
    if EVO_IsMJPlus and EVO_IsMJPlus(ply) then return true end
    if EVO_IsGerantAnim and EVO_IsGerantAnim(ply) then return true end
    return ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0) >= 3
end

-- DEUX blocs maximum, chacun son jeu de globales repliquees. Deux et pas N :
-- chaque bloc pave sa collision en entites reseau (~460 au maximum), et une
-- liste ouverte finirait par en poser dix un soir d'event.
EVO_BLANC.MAX = 2

function EVO_BLANC.Cle(sNom, iSlot)
    return "EVO_Blanc" .. sNom .. iSlot
end

if SERVER then
    -- Mode rituel
    util.AddNetworkString("evo_blanc:rituel_offre")
    util.AddNetworkString("evo_blanc:rituel_payer")
    util.AddNetworkString("evo_blanc:rituel_debut")
    util.AddNetworkString("evo_blanc:rituel_prendre")
    util.AddNetworkString("evo_blanc:rituel_gagne")
    util.AddNetworkString("evo_blanc:rituel_fin")

    util.AddNetworkString("evo_blanc:set")
    util.AddNetworkString("evo_blanc:tp")
    util.AddNetworkString("evo_blanc:dodo")
    util.AddNetworkString("evo_blanc:retour")
    util.AddNetworkString("evo_blanc:etat")
    util.AddNetworkString("evo_blanc:lames")
    AddCSLuaFile("evo_blanc/sh_rituel.lua")
    AddCSLuaFile("evo_blanc/cl_blanc.lua")
    AddCSLuaFile("evo_blanc/cl_rituel_phrases.lua")
    AddCSLuaFile("evo_blanc/cl_rituel.lua")
    -- sh_rituel AVANT sv/cl_blanc : le panneau lit EVO_BLANC.Rituel (lames de scene).
    include("evo_blanc/sh_rituel.lua")
    include("evo_blanc/sv_blanc.lua")
    include("evo_blanc/sv_rituel.lua")
else
    include("evo_blanc/sh_rituel.lua")
    include("evo_blanc/cl_blanc.lua")
    include("evo_blanc/cl_rituel_phrases.lua")
    include("evo_blanc/cl_rituel.lua")
end
