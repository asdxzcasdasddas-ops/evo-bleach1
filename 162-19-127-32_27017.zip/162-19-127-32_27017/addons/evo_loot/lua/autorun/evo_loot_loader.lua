-- "addons\\evo_loot\\lua\\autorun\\evo_loot_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ilvl RETIRÉ (user 08/14) : brouillon de mars supplanté par la forge (ncm_forge) en mai,
-- jamais eu d'UI, mais son receveur net restait adressable (achat de stats invisible).
-- Les fichiers sh_ilvl / sv_ilvl / cl_ilvl ne doivent PAS être rechargés sans décision.
if SERVER then
	AddCSLuaFile("evo_loot/sh_config.lua")
	AddCSLuaFile("evo_loot/cl_loot.lua")
	include("evo_loot/sh_config.lua")
	include("evo_loot/sv_loot.lua")
else
	include("evo_loot/sh_config.lua")
	include("evo_loot/cl_loot.lua")
end
