-- "addons\\evo_loot\\lua\\evo_loot\\cl_loot.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO LOOT SYSTEM - Client VFX (ouverture de coffre)
-- ============================================================================

local active_chest = nil -- table contenant les infos de l'animation en cours
local chest_queue = {}   -- file d'attente des coffres à ouvrir

-- Tables de couleurs cachees (evite de recreer a chaque frame/appel)
local RARITY_COLORS = {
	common    = Color(200, 200, 200),
	uncommon  = Color(50, 200, 50),
	rare      = Color(50, 100, 255),
	epic      = Color(200, 100, 0),
	legendary = Color(255, 215, 0),
	mythic    = Color(255, 50, 50),
}

-- Couleurs pre-cachees pour le rendu (evite GC pressure a chaque frame)
local color_white = Color(255, 255, 255)
local color_black = Color(0, 0, 0)
local color_temp = Color(0, 0, 0, 0) -- reutilisee pour eviter les allocations

local math_sin = math.sin
local math_cos = math.cos
local math_rad = math.rad
local math_abs = math.abs
local math_max = math.max
local math_Clamp = math.Clamp

-- ============================================================================
-- Demande d'ouverture (envoie au serveur)
-- ============================================================================

function EVO_LOOT.RequestOpen(chest_id)
	if not EVO_LOOT.Chests[chest_id] then return end
	net.Start("evo_loot:OpenChest")
		net.WriteString(chest_id)
	net.SendToServer()
end

--- Ouverture GROUPEE d'une pile (user 09/09) : n coffres du meme type, une seule animation.
function EVO_LOOT.RequestOpenMany(chest_id, n)
	if not EVO_LOOT.Chests[chest_id] then return end
	n = math.Clamp(math.floor(tonumber(n) or 1), 1, EVO_LOOT.MaxOpenAtOnce or 64)
	net.Start("evo_loot:OpenChests")
		net.WriteString(chest_id)
		net.WriteUInt(n, 8)
	net.SendToServer()
end

-- ============================================================================
-- Reception du resultat du serveur
-- ============================================================================

-- Debug toggle : true = log lifecycle dans la console pour diagnostiquer les
-- problemes de chainage (queue stuck, cleanup rate, etc.)
EVO_LOOT.DebugClient = false
local function DBG(msg)
	if not EVO_LOOT.DebugClient then return end
	print(string.format("[evo_loot/cl] %.2f | %s", CurTime(), msg))
end

-- Traiter le prochain coffre dans la file d'attente
local function ProcessNextChest()
	if active_chest then
		DBG("ProcessNextChest skip : active_chest deja set (queue=" .. #chest_queue .. ")")
		return
	end
	if #chest_queue == 0 then
		DBG("ProcessNextChest skip : queue vide")
		return
	end

	local next = table.remove(chest_queue, 1)
	DBG("ProcessNextChest -> " .. tostring(next.chest_id) .. " (queue restante=" .. #chest_queue .. ")")
	EVO_LOOT.PlayChestAnimation(next.chest_id, next.won_item, next.opener, next.multi)
end

-- Protocole serveur :
--   string  chest_id
--   string  reward_type ("money"|"item"|"reroll")
--   variant payload selon type
--   entity  opener
net.Receive("evo_loot:ChestResult", function()
	local chest_id    = net.ReadString()
	local reward_type = net.ReadString()

	local won_item, money_amt, reroll_cat, reroll_amt

	if reward_type == "money" then
		money_amt = net.ReadUInt(32)
	elseif reward_type == "reroll" then
		reroll_cat = net.ReadString()
		reroll_amt = net.ReadUInt(8)
	else -- "item"
		won_item = net.ReadString()
	end

	local opener = net.ReadEntity()

	-- Le reveal (coffre 3D + son + popup "RÉCOMPENSE") ne concerne QUE l'ouvreur.
	-- Si le message a ete diffuse (broadcast/SendPVS, ou un appelant qui force
	-- broadcast=true), les AUTRES clients l'ignorent ici -> plus de popup de
	-- recompense chez tout le serveur. (Garde cote client, robuste quel que soit
	-- le reglage EVO_LOOT.BroadcastChest.)
	if IsValid(opener) and opener ~= LocalPlayer() then return end

	DBG("ChestResult recv : chest=" .. tostring(chest_id) .. " type=" .. tostring(reward_type) ..
		" payload=" .. tostring(won_item or money_amt or (reroll_cat .. "x" .. reroll_amt)))

	if not EVO_LOOT.Chests[chest_id] then
		DBG("ChestResult abort : chest_id inconnu cote client")
		return
	end

	-- Si on a tire un item, on lance l'animation classique de coffre
	if reward_type == "item" then
		if not ITEMS or not ITEMS[won_item] then
			DBG("ChestResult abort : item inconnu cote client : " .. tostring(won_item))
			return
		end
		table.insert(chest_queue, {
			chest_id = chest_id,
			won_item = won_item,
			opener   = opener,
		})
		DBG("Queue +1 : " .. tostring(won_item) .. " (queue=" .. #chest_queue .. ")")
		ProcessNextChest()
		return
	end

	-- Pour money / reroll : notification simple (pas d'animation de coffre).
	-- IMPORTANT : MUGEN.Notify cote CLIENT a la signature (description, type, len, disableSound)
	-- - PAS de Player en premier arg (c'est la signature serveur). On passait LocalPlayer()
	-- ce qui fait : description = Player object => CheckType "string" expected -> ERROR runtime.
	if reward_type == "money" then
		if MUGEN and MUGEN.Notify then
			MUGEN.Notify("+ " .. money_amt .. " yens", NOTIFY_MONEY or 0, 5)
		end
		surface.PlaySound("a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3")
	elseif reward_type == "reroll" then
		if MUGEN and MUGEN.Notify then
			local label = reroll_cat or "?"
			MUGEN.Notify("+ " .. (reroll_amt or 1) .. " reroll " .. label,
				NOTIFY_GENERIC or 0, 5)
		end
		surface.PlaySound("a4xy732ex6yeop2/bvx4ly7j2rbiu5.mp3")
	end
end)

-- Rang de rarete : choisit l'objet MIS EN AVANT au-dessus du coffre et trie le recap.
local RARITY_RANK = { common = 1, uncommon = 2, rare = 3, epic = 4, legendary = 5, mythic = 6 }
local function rarityRank(item_id)
	local it = ITEMS and ITEMS[item_id]
	return RARITY_RANK[(it and it.rarity) or "common"] or 1
end

-- Resultat GROUPE (plusieurs coffres d'une pile, cf. RequestOpenMany) : tout est agrege
-- en UNE animation de coffre. Le meilleur objet trone au-dessus, le recapitulatif complet
-- (objets groupes, yens, rerolls) arrive dans le popup. Protocole : string chest_id,
-- uint8 nb, puis (type + payload) x nb.
net.Receive("evo_loot:ChestResults", function()
	local chest_id = net.ReadString()
	local n = net.ReadUInt(8)
	local chest_data = EVO_LOOT.Chests[chest_id]
	if not chest_data or n < 1 then return end

	local counts, order, money, rerolls = {}, {}, 0, {}
	for _ = 1, n do
		local rtype = net.ReadString()
		if rtype == "money" then
			money = money + net.ReadUInt(32)
		elseif rtype == "reroll" then
			local cat, amt = net.ReadString(), net.ReadUInt(8)
			rerolls[cat] = (rerolls[cat] or 0) + amt
		else
			local iid = net.ReadString()
			if ITEMS and ITEMS[iid] then
				if not counts[iid] then order[#order + 1] = iid end
				counts[iid] = (counts[iid] or 0) + 1
			end
		end
	end
	-- Rarete decroissante, puis ordre de tirage : le meilleur objet en tete.
	table.sort(order, function(a, b)
		local ra, rb = rarityRank(a), rarityRank(b)
		if ra ~= rb then return ra > rb end
		return a < b
	end)

	local lines = {}
	for _, iid in ipairs(order) do
		local it = ITEMS[iid]
		lines[#lines + 1] = {
			text  = (counts[iid] > 1 and ("x" .. counts[iid] .. "  ") or "") .. (it.name or iid),
			color = RARITY_COLORS[it.rarity or "common"] or RARITY_COLORS.common,
		}
	end
	if money > 0 then
		lines[#lines + 1] = { text = "+ " .. string.Comma(money) .. " yens", color = RARITY_COLORS.legendary }
	end
	for cat, amt in pairs(rerolls) do
		lines[#lines + 1] = { text = "+ " .. amt .. " reroll " .. tostring(cat), color = RARITY_COLORS.rare }
	end
	if #lines == 0 then return end

	local best = order[1]
	local chest_col = RARITY_COLORS[chest_data.rarity or "common"] or RARITY_COLORS.common
	table.insert(chest_queue, {
		chest_id = chest_id,
		won_item = best,
		opener   = LocalPlayer(),
		multi = {
			count = n,
			lines = lines,
			color = best and (RARITY_COLORS[ITEMS[best].rarity or "common"] or chest_col) or chest_col,
			title = best and (ITEMS[best].name or best) or lines[1].text,
		},
	})
	DBG("Queue +1 (groupe x" .. n .. ", " .. #lines .. " lignes)")
	ProcessNextChest()
end)

-- ============================================================================
-- Calcul position devant le joueur
-- ============================================================================

local function GetChestSpawnPos(target_ply)
	local ply = target_ply or LocalPlayer()
	if not IsValid(ply) then return Vector(0, 0, 0) end

	local forward = ply:GetForward()
	forward.z = 0
	forward:Normalize()

	local pos = ply:GetPos() + forward * EVO_LOOT.SpawnDistance
	-- Trace pour poser au sol
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 50),
		endpos = pos - Vector(0, 0, 200),
		filter = ply,
		mask = MASK_SOLID_BRUSHONLY,
	})

	return tr.Hit and tr.HitPos or pos
end

-- ============================================================================
-- Animation principale
-- ============================================================================

-- `multi` (facultatif) = resultat groupe : { count, lines, color, title }. Le coffre joue
-- la meme animation ; seuls le nom au-dessus, la couleur du halo et le popup changent.
function EVO_LOOT.PlayChestAnimation(chest_id, won_item, opener, multi)
	DBG("PlayChestAnimation start : chest=" .. tostring(chest_id) .. " item=" .. tostring(won_item))

	-- Garde-fou : si une anim precedente a laisse active_chest non-nil (timer
	-- cleanup foire, changement de map en plein milieu, Lua error...), on force
	-- le cleanup au lieu de silent return. Sans ca, tous les coffres suivants
	-- echouent en silence et le joueur ne voit JAMAIS rien.
	if active_chest then
		local elapsed = CurTime() - (active_chest.start_time or 0)
		if elapsed > (EVO_LOOT.OpenDuration + 5) then
			DBG("active_chest stuck (elapsed=" .. string.format("%.1f", elapsed) .. "s) -> force cleanup")
			EVO_LOOT.CleanupChest()
		else
			DBG("active_chest legit (elapsed=" .. string.format("%.1f", elapsed) .. "s) -> requeue")
			-- Le coffre actuel tourne legit. On re-insere notre item EN TETE de
			-- queue pour qu'il soit traite des le prochain cleanup. Sans ca, si
			-- ProcessNextChest fire pendant active_chest set, l'item est perdu.
			table.insert(chest_queue, 1, { chest_id = chest_id, won_item = won_item, opener = opener, multi = multi })
			return
		end
	end

	local chest_data = EVO_LOOT.Chests[chest_id]
	local item_data = won_item and ITEMS[won_item] or nil
	if not chest_data or (not item_data and not multi) then
		DBG("PlayChestAnimation abort : chest_data=" .. tostring(chest_data ~= nil) .. " item_data=" .. tostring(item_data ~= nil))
		-- Important : on enchaine sur le suivant pour ne pas bloquer la queue
		timer.Simple(0.1, ProcessNextChest)
		return
	end

	local target_ply = IsValid(opener) and opener or LocalPlayer()
	local spawn_pos = GetChestSpawnPos(target_ply)
	local ang = Angle(0, target_ply:EyeAngles().y + 180, 0)

	-- Creer l'entite client-side (CSEnt)
	local chest_ent = ClientsideModel(chest_data.model or EVO_LOOT.ChestModel, RENDERGROUP_OPAQUE)
	if not IsValid(chest_ent) then
		DBG("PlayChestAnimation abort : ClientsideModel invalide pour " .. tostring(chest_data.model or EVO_LOOT.ChestModel))
		timer.Simple(0.1, ProcessNextChest)
		return
	end

	chest_ent:SetPos(spawn_pos)
	chest_ent:SetAngles(ang)
	chest_ent:SetModelScale(2, 0)

	-- Appliquer le skin selon la rareté du coffre (0=commun, 1=rare, 2=epique, 3=legendaire, 4=mythique)
	if chest_data.bodygroup then
		chest_ent:SetSkin(chest_data.bodygroup)
	end

	-- Phase 1 : animation "spawn"
	local spawn_seq = chest_ent:LookupSequence("spawn")
	if spawn_seq and spawn_seq > 0 then
		chest_ent:SetSequence(spawn_seq)
		chest_ent:SetPlaybackRate(1)
		chest_ent:SetCycle(0)
	end

	-- Son d'ouverture (EmitSound : joue une seule fois, pas de boucle)
	LocalPlayer():EmitSound("tgw7tau20hu4/b0v19orypm6j1lj.mp3", 75, 100, 1, CHAN_STATIC)

	-- Phase 2 : animation "open" 3s avant la fin de la musique
	timer.Create("EVO_Loot_OpenAnim", EVO_LOOT.OpeningPhase - 3, 1, function()
		if not active_chest or not IsValid(active_chest.entity) then return end
		local open_seq = active_chest.entity:LookupSequence("open")
		if open_seq and open_seq > 0 then
			active_chest.entity:SetSequence(open_seq)
			active_chest.entity:SetPlaybackRate(1)
			active_chest.entity:SetCycle(0)
		end
	end)

	-- Phase 2.5 : glow + particules apparaissent a 10.5 secondes (BIM)
	timer.Create("EVO_Loot_RevealGlow", 10.5, 1, function()
		if not active_chest then return end
		active_chest.opened = true
		active_chest.opened_time = CurTime()
	end)

	-- Charger l'icone de l'item gagne (FALLBACK uniquement si pas de modèle 3D)
	local item_icon_mat = nil
	if item_data and item_data.icon then
		item_icon_mat = Material(item_data.icon, "smooth mips")
	end

	-- Plus de modèle 3D de l'item : au rayonnement on affiche juste le NOM de l'item en
	-- gros au-dessus du coffre (hook EVO_Loot_DrawItemIcon3D) + le popup récompense bas-droite.

	-- Couleur du glow selon la rarete
	local rarity = (item_data and item_data.rarity) or "common"
	local glow_color = (multi and multi.color) or RARITY_COLORS[rarity] or RARITY_COLORS["common"]

	active_chest = {
		entity = chest_ent,
		start_time = CurTime(),
		spawn_pos = spawn_pos,
		won_item = won_item,
		item_icon_mat = item_icon_mat,
		glow_color = glow_color,
		item_name = (multi and multi.title) or (item_data and item_data.name) or won_item,
		multi = multi,
		rarity = rarity,
		angle_offset = ang.y,
	}

	-- Popup de recompense (apparait quand le son d'ouverture se termine)
	timer.Create("EVO_Loot_Popup", EVO_LOOT.OpeningPhase, 1, function()
		if multi then EVO_LOOT.ShowMultiPopup(multi) else EVO_LOOT.ShowItemPopup(won_item) end
	end)

	-- Phase 3 : animation "close" 2s avant la fin, puis nettoyage
	timer.Create("EVO_Loot_CloseAnim", EVO_LOOT.OpenDuration - 2, 1, function()
		if not active_chest or not IsValid(active_chest.entity) then return end
		local close_seq = active_chest.entity:LookupSequence("close")
		if close_seq and close_seq > 0 then
			active_chest.entity:SetSequence(close_seq)
			active_chest.entity:SetPlaybackRate(1)
			active_chest.entity:SetCycle(0)
		end
	end)

	-- Timer de nettoyage automatique
	timer.Create("EVO_Loot_Cleanup", EVO_LOOT.OpenDuration, 1, function()
		EVO_LOOT.CleanupChest()
	end)
end

-- ============================================================================
-- Nettoyage
-- ============================================================================

function EVO_LOOT.CleanupChest()
	if not active_chest then
		DBG("CleanupChest skip : active_chest deja nil")
		return
	end

	DBG("CleanupChest : chest=" .. tostring(active_chest.won_item) .. " (queue=" .. #chest_queue .. ")")

	if IsValid(active_chest.entity) then
		active_chest.entity:Remove()
	end

	-- Stopper le son d'ouverture s'il tourne encore
	LocalPlayer():StopSound("tgw7tau20hu4/b0v19orypm6j1lj.mp3")

	active_chest = nil
	timer.Remove("EVO_Loot_Cleanup")
	timer.Remove("EVO_Loot_Popup")
	timer.Remove("EVO_Loot_OpenAnim")
	timer.Remove("EVO_Loot_RevealGlow")
	timer.Remove("EVO_Loot_CloseAnim")

	-- Lancer le prochain coffre dans la file d'attente (petit délai pour éviter le chevauchement)
	timer.Simple(0.5, function()
		ProcessNextChest()
	end)
end

-- ============================================================================
-- Popup loot : image pop_back + texte par dessus (responsive glibs)
-- ============================================================================

local active_popups = {}
local pop_bg = Material("tgw7tau20hu4/dnlxuuvmx7xj1ovte.png", "noclamp smooth")

-- Polices pour le popup de recompense (glib responsive). On reutilise Bebas Neue
-- pour le titre item et Roboto pour le sous-titre "RECOMPENSE" - meme palette
-- typographique que le property menu (PropMenu_Title / PropMenu_Action) pour
-- garder une coherence visuelle dans le HUD.
-- (DA Atelier 07/07 : Bebas SANS bold — weight 400 partout.)
if gCreateRespFont then
	gCreateRespFont("EVO_Loot_PopupTitle", "Roboto",     20, 600)
	gCreateRespFont("EVO_Loot_PopupItem",  "Bebas Neue", 38, 400)
	gCreateRespFont("EVO_Loot_PopupMulti", "Bebas Neue", 28, 400)
	gCreateRespFont("EVO_Loot_PopupLine",  "Roboto",     17, 500)
else
	surface.CreateFont("EVO_Loot_PopupTitle", { font = "Roboto",     size = 20, weight = 600, antialias = true })
	surface.CreateFont("EVO_Loot_PopupItem",  { font = "Bebas Neue", size = 38, weight = 400, antialias = true })
	surface.CreateFont("EVO_Loot_PopupMulti", { font = "Bebas Neue", size = 28, weight = 400, antialias = true })
	surface.CreateFont("EVO_Loot_PopupLine",  { font = "Roboto",     size = 17, weight = 500, antialias = true })
	hook.Add("InitPostEntity", "EVO_Loot_RespFont", function()
		if gCreateRespFont then
			gCreateRespFont("EVO_Loot_PopupTitle", "Roboto",     20, 600)
			gCreateRespFont("EVO_Loot_PopupItem",  "Bebas Neue", 38, 400)
			gCreateRespFont("EVO_Loot_PopupMulti", "Bebas Neue", 28, 400)
			gCreateRespFont("EVO_Loot_PopupLine",  "Roboto",     17, 500)
		end
	end)
end

function EVO_LOOT.ShowItemPopup(item_id)
	local item_data = ITEMS and ITEMS[item_id]
	if not item_data then return end

	local snd_drop = CreateSound(LocalPlayer(), "a4xy732ex6yeop2/mscqj10ctef8jng8.wav")
	if snd_drop then
		snd_drop:Play()
		timer.Simple(1, function() if snd_drop then snd_drop:Stop() end end)
	end

	local rarity = item_data.rarity or "common"
	local icon_mat = item_data.icon and Material(item_data.icon, "smooth mips") or nil

	table.insert(active_popups, {
		start_time = CurTime(),
		duration = 5,
		name = item_data.name or item_id,
		color = RARITY_COLORS[rarity] or RARITY_COLORS["common"],
		icon_mat = icon_mat,
	})
end

-- Palette DA Atelier (07/07) : plaque métal noir + liseré acier + barre accent.
local COL_POP_BG     = Color(13, 14, 17, 235)
local COL_POP_EDGE   = Color(146, 152, 161, 33)
local COL_POP_ACCENT = Color(207, 68, 78)
local COL_POP_GREY   = Color(150, 154, 162, 255)

-- Popup GROUPE (ouverture d'une pile) : titre « N COFFRES OUVERTS » puis une ligne par
-- recompense, couleur de rarete. Au-dela de 8 lignes on resume, le popup doit rester
-- lisible en bas a droite. Meme son et meme plaque que le popup simple.
local MULTI_MAX_LINES = 8
function EVO_LOOT.ShowMultiPopup(multi)
	if not (istable(multi) and istable(multi.lines) and #multi.lines > 0) then return end

	local snd_drop = CreateSound(LocalPlayer(), "a4xy732ex6yeop2/mscqj10ctef8jng8.wav")
	if snd_drop then
		snd_drop:Play()
		timer.Simple(1, function() if snd_drop then snd_drop:Stop() end end)
	end

	local lines = {}
	for i = 1, math.min(#multi.lines, MULTI_MAX_LINES) do lines[i] = multi.lines[i] end
	if #multi.lines > MULTI_MAX_LINES then
		lines[#lines + 1] = { text = "... et " .. (#multi.lines - MULTI_MAX_LINES) .. " autres", color = COL_POP_GREY }
	end
	local nCount = tonumber(multi.count) or #multi.lines
	table.insert(active_popups, {
		start_time = CurTime(),
		duration = 5 + #lines * 0.8,
		name = string.format("%d COFFRE%s OUVERT%s", nCount, nCount > 1 and "S" or "", nCount > 1 and "S" or ""),
		color = multi.color or color_white,
		lines = lines,
	})
end

hook.Add("HUDPaint", "EVO_Loot_DrawPopup", function()
	if #active_popups == 0 then return end

	local now = CurTime()
	-- Box agrandie (480x100 au lieu de 420x80) pour accomoder la nouvelle police
	-- Bebas Neue 38pt en titre item. Un popup groupe est plus haut : une ligne par recompense.
	local nW = gRespX(480)
	local nHBase = gRespY(100)
	local nLine = gRespY(24)

	-- 1) purge des popups expires
	for i = #active_popups, 1, -1 do
		if now - active_popups[i].start_time > active_popups[i].duration then
			table.remove(active_popups, i)
		end
	end
	if #active_popups == 0 then return end

	-- 2) dessin, empiles depuis le bas : chaque popup a sa propre hauteur
	local yCursor = ScrH() - gRespY(20)
	for i = 1, #active_popups do
		local p = active_popups[i]
		local elapsed = now - p.start_time
		local nH = p.lines and (gRespY(70) + #p.lines * nLine) or nHBase

		-- Fade in / out
		local a = 1
		if elapsed < 0.5 then
			a = elapsed / 0.5
		elseif elapsed > p.duration - 0.8 then
			a = (p.duration - elapsed) / 0.8
		end

		-- Position : bas-droit
		local x = ScrW() - nW - gRespX(20)
		local y = yCursor - nH
		yCursor = y - gRespY(8)

		-- Scale pop-in
		local scale = math.Clamp(elapsed / 0.3, 0, 1)
		scale = 0.8 + scale * 0.2

		local sw = nW * scale
		local sh = nH * scale
		local sx = x + (nW - sw) / 2
		local sy = y + (nH - sh) / 2

		-- Mini-plaque Atelier (coin bas-droit coupé + liseré acier) + barre
		-- accent gauche (remplace le double fond + bordure grise + highlight).
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(sx, sy, sw, sh, ColorAlpha(COL_POP_BG, 235 * a), gRespY(10), "br")
			EVO_UI.OutlineCut(pts, ColorAlpha(COL_POP_EDGE, 33 * a))
		else
			RNDX.Draw(0, sx, sy, sw, sh, ColorAlpha(COL_POP_BG, 255 * a))
		end
		surface.SetDrawColor(ColorAlpha(COL_POP_ACCENT, 255 * a))
		surface.DrawRect(sx, sy, gRespX(2), sh)

		local col = p.color
		local nPad = gRespX(14)

		-- Plus d'icône PNG dans la notif (souvent absente -> damier noir/violet) :
		-- texte aligné directement à gauche de la carte.
		local textX = sx + nPad

		-- "RÉCOMPENSE" petit en haut
		draw.SimpleText(p.lines and "RÉCOMPENSES" or "RÉCOMPENSE", "EVO_Loot_PopupTitle", textX, sy + gRespY(22), ColorAlpha(COL_POP_GREY, 200 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if p.lines then
			-- Popup groupe : compte des coffres, puis une ligne par recompense.
			draw.SimpleText(p.name, "EVO_Loot_PopupMulti", textX, sy + gRespY(48), Color(col.r, col.g, col.b, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			for k, ln in ipairs(p.lines) do
				local c = ln.color or color_white
				draw.SimpleText(ln.text, "EVO_Loot_PopupLine", textX, sy + gRespY(70) + (k - 0.5) * nLine * scale,
					Color(c.r, c.g, c.b, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		else
			-- Nom de l'item en gros, couleur de rareté
			draw.SimpleText(p.name, "EVO_Loot_PopupItem", textX, sy + gRespY(62), Color(col.r, col.g, col.b, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
end)

-- ============================================================================
-- Rendu 3D : glow + icone flottante qui tourne
-- ============================================================================

local glow_mat = Material("sprites/light_glow02_add")
local beam_mat = Material("effects/lamp_beam")

hook.Add("PostDrawTranslucentRenderables", "EVO_Loot_DrawChestVFX", function(depth, skybox)
	if skybox then return end
	if not active_chest then return end
	if not IsValid(active_chest.entity) then
		EVO_LOOT.CleanupChest()
		return
	end

	local ent = active_chest.entity
	local elapsed = CurTime() - active_chest.start_time

	-- Animer le cycle si le modele a une animation
	ent:FrameAdvance(FrameTime())

	-- Position au dessus du coffre
	local chest_pos = ent:GetPos()
	local mins, maxs = ent:GetRenderBounds()
	local chest_top = chest_pos + Vector(0, 0, maxs.z or 30)
	local float_pos = chest_top + Vector(0, 0, EVO_LOOT.FloatHeight)

	-- L'item apparait quand le coffre s'ouvre
	if not active_chest.opened then return end
	local item_alpha = 1
	-- Fade in rapide apres ouverture
	if active_chest.opened_time then
		item_alpha = math_Clamp((CurTime() - active_chest.opened_time) / 0.5, 0, 1)
	end

	-- Fade out pendant la fermeture (2 dernieres secondes)
	local fade_out = 1
	if elapsed > (EVO_LOOT.OpenDuration - 2) then
		fade_out = math_Clamp((EVO_LOOT.OpenDuration - elapsed) / 1, 0, 1)
	end

	local final_alpha = item_alpha * fade_out
	if final_alpha <= 0 then return end

	-- ===== GLOW au dessus du coffre =====
	local glow_col = active_chest.glow_color
	local glow_size = 30 + math_sin(elapsed * 3) * 8 -- pulsation
	local glow_alpha = 180 * final_alpha

	color_temp.r = glow_col.r
	color_temp.g = glow_col.g
	color_temp.b = glow_col.b
	color_temp.a = glow_alpha

	render.SetMaterial(glow_mat)
	render.DrawSprite(float_pos + Vector(0, 0, -10), glow_size, glow_size, color_temp)

	-- Deuxieme couche de glow plus grand et plus transparent
	color_temp.a = glow_alpha * 0.3
	render.DrawSprite(float_pos + Vector(0, 0, -10), glow_size * 2.5, glow_size * 2.5, color_temp)

	-- ===== Rayon de lumiere vertical =====
	color_temp.a = 100 * final_alpha

	render.SetMaterial(beam_mat)
	render.DrawBeam(
		chest_top + Vector(0, 0, 5),
		float_pos + Vector(0, 0, 30),
		8 + math_sin(elapsed * 2) * 3,
		0, 1,
		color_temp
	)

	-- ===== Petites particules scintillantes =====
	render.SetMaterial(glow_mat)
	color_temp.a = 200 * final_alpha
	for i = 1, 6 do
		local offset_angle = (elapsed * 60 + i * 60) % 360
		local radius = 15 + math_sin(elapsed * 2 + i) * 5
		local particle_pos = float_pos + Vector(
			math_cos(math_rad(offset_angle)) * radius,
			math_sin(math_rad(offset_angle)) * radius,
			math_sin(elapsed * 3 + i * 0.8) * 10
		)
		local sparkle_size = 3 + math_sin(elapsed * 5 + i * 1.2) * 2
		render.DrawSprite(particle_pos, sparkle_size, sparkle_size, color_temp)
	end
end)

-- ============================================================================
-- Rendu au-dessus du coffre : le NOM de l'item EN GROS (texte 3D2D face caméra, couleur
-- de rareté), affiché au moment du RAYONNEMENT. (Le popup récompense est géré plus bas.)
-- ============================================================================

hook.Add("PostDrawTranslucentRenderables", "EVO_Loot_DrawItemIcon3D", function(depth, skybox)
	if skybox then return end
	if not active_chest then return end
	if not IsValid(active_chest.entity) then return end
	-- N'APPARAÎT QU'AU RAYONNEMENT : on attend que le coffre soit "ouvert" (même flag que
	-- le glow/faisceau, posé ~10.5s après le début par le timer EVO_Loot_RevealGlow).
	if not active_chest.opened then return end

	local elapsed = CurTime() - active_chest.start_time
	-- fondu d'entrée 0.5s à partir de l'ouverture + fondu de sortie sur les 2 dernières s
	local final_alpha = 1
	if active_chest.opened_time then
		final_alpha = math_Clamp((CurTime() - active_chest.opened_time) / 0.5, 0, 1)
	end
	if elapsed > (EVO_LOOT.OpenDuration - 2) then
		final_alpha = final_alpha * math_Clamp((EVO_LOOT.OpenDuration - elapsed) / 1, 0, 1)
	end
	if final_alpha <= 0 then return end

	-- ===== NOM de l'item EN GROS, face caméra, au-dessus du coffre =====
	local ent = active_chest.entity
	local _, maxs = ent:GetRenderBounds()
	local name_pos = ent:GetPos() + Vector(0, 0, (maxs.z or 30) + EVO_LOOT.FloatHeight + 14 + math.sin(elapsed * 2) * 2)
	-- Billboard face caméra via EyePos() (= VRAIE position de vue) -> marche aussi avec la
	-- CAM ORBITALE ; LocalPlayer():EyeAngles() serait gelé/faux pendant l'orbite.
	local ang = Angle(0, (name_pos - EyePos()):Angle().y - 90, 90)
	local col = active_chest.glow_color or color_white
	cam.Start3D2D(name_pos, ang, 0.32) -- ← taille du nom (↓ pour + petit)
		draw.SimpleText(active_chest.item_name or "", "EVO_Loot_PopupItem", 0, 0,
			Color(col.r, col.g, col.b, 255 * final_alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end)

-- ============================================================================
-- Nettoyage quand le joueur change de map ou respawn
-- ============================================================================

hook.Add("InitPostEntity", "EVO_Loot_CleanupOnLoad", function()
	EVO_LOOT.CleanupChest()
end)

