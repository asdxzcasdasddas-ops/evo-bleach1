-- "addons\\evo_loot\\lua\\evo_loot\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO LOOT SYSTEM - Configuration partagee (shared)
-- ============================================================================

EVO_LOOT = EVO_LOOT or {}

-- Model du coffre
EVO_LOOT.ChestModel = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl"

-- Duree de la phase d'ouverture (son opening.mp3 ~11s, on attend 13s)
EVO_LOOT.OpeningPhase = 13

-- Duree totale de l'animation (ouverture + affichage item)
EVO_LOOT.OpenDuration = 20

-- Distance devant le joueur ou spawn le coffre
EVO_LOOT.SpawnDistance = 80

-- Hauteur au dessus du coffre pour l'item qui flotte
EVO_LOOT.FloatHeight = 30

-- Vitesse de rotation de l'icone (degres/sec)
EVO_LOOT.IconRotateSpeed = 90

-- Taille de l'icone flottante (pixels)
EVO_LOOT.IconSize = 96

-- Afficher le coffre a tous les joueurs (true) ou seulement a celui qui ouvre (false)
-- false (2026-06-11, demande user) : le son + l'UI de récompense ne sont visibles/audibles
-- QUE par le joueur qui ouvre (avant : broadcast PVS = tout le monde autour).
EVO_LOOT.BroadcastChest = false

-- Coffres EMPILABLES (user 09/09) : quete, chasse, boss se rangent en piles, et une pile
-- s'ouvre en plusieurs exemplaires d'un coup (menu « Ouvrir plusieurs »). Une pile pleine
-- s'ouvre entierement en UNE demande, d'ou MaxOpenAtOnce = ChestStackMax.
EVO_LOOT.ChestStackMax = 64
EVO_LOOT.MaxOpenAtOnce = 64

-- ============================================================================
-- DEFINITION DES SETS D'EQUIPEMENT
-- ============================================================================

EVO_LOOT.Sets = {
	-- Set bonus = appliqué quand 3/3 pièces équipées, TOUTES DE LA MÊME RARETÉ
	-- (demande user 08/01 : raretés mélangées = set non validé).
	-- BARÈME 08/01 (demande user, itéré : « ~3% » puis « fais un ×2 pour tous les sets ») :
	-- les valeurs ci-dessous sont la BASE (set commun, ×1) ; la rareté multiplie
	-- (×1.5/×2/×3/×5), donc un set MYTHIQUE donne base×5 = 4% à 8% selon la stat.
	-- La description affichée est GÉNÉRÉE depuis `bonus` (SetBonusDesc ci-dessous,
	-- centralisation 08/15) : plus de bonus_desc à maintenir à la main.
	["brasier"] = {
		name = "Brasier",
		identity = "Pression d'arme : dégâts réguliers au katana comme au Hakuda.",
		bonus = { e_katana_damage = 1.2, e_katana_cc_damage = 0.8 },
		pieces = 3,
	},
	["tempete"] = {
		name = "Tempête",
		flashstep_attack = { bonus_pct = 10, window = 3, cooldown = 4, min_distance = 64 },
		identity = "Mobilité et esquive : déplacement accéléré hors run mode, combos plus rapides et attaque renforcée après flashstep.",
		dodge_points = 2, -- +2/3/4/6/10 points de chance, après les multiplicateurs.
		combo_speed_pct = 2, -- +2/3/4/6/10 % : animations, impacts et récupération des combos.
		-- Réduc CD ×2 (08/15, demande user : « le set tempête doit être légèrement plus
		-- fort ») : 1.2 -> 2.4 en base, la rareté multiplie ensuite (rare 3,6% / épique
		-- 4,8% / légendaire 7,2% / mythique 12%). La portée ne change pas.
		-- COÛT EN REIATSU DU FLASHSTEP (08/22, demande user « le set doit être plus
		-- intéressant, notamment le coût en reiatsu ») : 3e ligne du set, et de LOIN
		-- la plus forte — c'est elle qui change le style de jeu (le flashstep coûte
		-- 100 de reiatsu fixe, cf. sv_flashstep).
		-- Base CALÉE SUR LE MYTHIQUE (demande user : « mythique ça doit être 50 ») :
		-- le mythique multiplie par 5, donc base 10 -> 50% de coût en moins, soit un
		-- flashstep à 50 de reiatsu. L'échelle complète : commun 10% (90), rare 15%
		-- (85), épique 20% (80), légendaire 30% (70), mythique 50% (50).
		-- ⚠ Toucher à la base DÉPLACE tout le barème : c'est le mythique qui fixe le
		-- pas (base = cible mythique / 5).
		-- VITESSE DE DEPLACEMENT (09/22, demande user) : bonus de SET uniquement, les
		-- pieces gardent leurs stats. Base 7 depuis le 23/10 (avant 4) :
		-- commun 7 / rare 10,5 / epique 14 / legendaire 21 / mythique 35 %.
		-- Appliquee APRES le plafond de course de 400
		-- (cf. SetPlayerBaseSpeed), sans quoi un haut grade deja au plafond ne
		-- sentirait strictement rien.
		bonus = { e_flashstep_range = -1.2, e_flashstep_cd = 2.4, e_flashstep_cost = 10, e_speed = 7 },
		pieces = 3,
	},
	["glacier"] = {
		name = "Glacier",
		identity = "Défense : davantage de vie et de garde, garde récupérée plus vite, soin hors combat.",
		bonus = { e_max_hp = 1.2, e_parade_max = 1, e_regen_hp = 0.8, e_parade_regen = 3.4 },
		-- Multiplicateur PASSIF supplémentaire : +20/30/40/60/100 % selon la rareté.
		-- Compense le pool accru même avec les pièces forgées, sans changer les stats des pièces.
		passive_regen = { hp = 20 },
		pieces = 3,
	},
	["foudre"] = {
		name = "Foudre",
		identity = "Critiques : pics de dégâts sur les armes et les sorts, au prix d'une puissance moins régulière.",
		forge_gain = { katana_cc_chance = 0.2, katana_cc_damage = 0.2 },
		bonus = { e_katana_cc_chance = 1.2, e_katana_cc_damage = 1.2 },
		pieces = 3,
	},
	["abysses"] = {
		name = "Abysses",
		identity = "Maîtrise des sorts : dégâts, cadence et autonomie en reiatsu.",
		spell_cost_reduction = 2, -- 2/3/4/6/10 % ; uniquement le coût au lancement des sorts.
		bonus = { e_spell_damage = 1.2, e_max_reiatsu = 1.6, e_regen_reiatsu = 1.2, e_spell_cd_reduction = 1 },
		-- Séparé d'e_regen_reiatsu : ce renfort ne modifie pas la recharge manuelle (V).
		passive_regen = { reiatsu = 20 },
		pieces = 3,
	},
}

-- ── DESCRIPTION DE SET GÉNÉRÉE (08/15, demande user : « il faut que ce soit
-- centralisé ») — l'ancien bonus_desc était un miroir écrit à la main de la table
-- `bonus`, donc un oubli = UI qui ment. Ici la desc sort DE la table : impossible
-- de désynchroniser. Consommé par l'UI inventaire (carte SETS + tooltip).
-- `flip` = stats appliquées en réduction : la VALEUR positive s'affiche en "-"
-- (moins de cooldown) et la négative en "+" (plus de portée).
local SET_STAT_ORDER = {
	{ k = "e_katana_damage",     label = "Dégâts d'Arme" },
	{ k = "e_katana_cc_chance",  label = "Chance Crit" },
	{ k = "e_katana_cc_damage",  label = "Dégâts Crit" },
	{ k = "e_max_hp",            label = "PV Max" },
	{ k = "e_parade_max",        label = "Parade Max" },
	{ k = "e_regen_hp",          label = "Régén PV" },
	{ k = "e_parade_regen",      label = "Temps de régén garde", flip = true },
	{ k = "e_spell_damage",      label = "Dégâts de Sort" },
	{ k = "e_max_reiatsu",       label = "Reiatsu Max" },
	{ k = "e_regen_reiatsu",     label = "Régén Reiatsu" },
	{ k = "e_spell_cd_reduction", label = "Réduc CD Sorts" },
	{ k = "e_flashstep_range",   label = "Portée Flashstep",   flip = true },
	{ k = "e_flashstep_cd",      label = "Cooldown Flashstep", flip = true },
	{ k = "e_flashstep_cost",    label = "Coût Flashstep",     flip = true },
	{ k = "e_speed",             label = "Vitesse de déplacement" },
}

-- Nombre -> texte FR sans zéros inutiles : 0.8 -> "0,8" ; 1 -> "1" ; 2.4 -> "2,4".
-- ⚠ virgule SANS espace après : la carte SETS coupe les lignes sur ", ".
local function SetNumFR(n)
	local s = string.format("%.3f", n)
	s = s:gsub("0+$", ""):gsub("%.$", "")
	return (s:gsub("%.", ","))
end

--- Description d'un set depuis sa table bonus. nMult optionnel (défaut 1 = valeurs
--- de BASE, celles qu'affiche l'UI à côté du « ×rareté »).
function EVO_LOOT.SetBonusDesc(set_id, nMult, bCompact)
	local cfg = EVO_LOOT.Sets and EVO_LOOT.Sets[set_id]
	if not cfg or not istable(cfg.bonus) then return "" end
	nMult = tonumber(nMult) or 1
	local tParts = {}
	for _, def in ipairs(SET_STAT_ORDER) do
		local v = tonumber(cfg.bonus[def.k])
		if v and v ~= 0 then
			v = v * nMult
			if def.flip then v = -v end
			tParts[#tParts + 1] = (v >= 0 and "+" or "-") .. SetNumFR(math.abs(v)) .. "% " .. def.label
		end
	end
	-- Stat hors barème (clé absente de SET_STAT_ORDER) : on l'affiche quand même,
	-- clé brute, plutôt que de la taire — une stat appliquée mais invisible est pire.
	for k, v in pairs(cfg.bonus) do
		local bKnown = false
		for _, def in ipairs(SET_STAT_ORDER) do
			if def.k == k then bKnown = true break end
		end
		if not bKnown and tonumber(v) and v ~= 0 then
			tParts[#tParts + 1] = "+" .. SetNumFR(math.abs(v * nMult)) .. "% " .. tostring(k)
		end
	end
	for _, def in ipairs({ { "hp", "Régén PV passive" }, { "reiatsu", "Régén Reiatsu passive" } }) do
		local pct = cfg.passive_regen and tonumber(cfg.passive_regen[def[1]]) or 0
		if pct ~= 0 then
			tParts[#tParts + 1] = "+" .. SetNumFR(pct * nMult) .. "% " .. def[2]
		end
	end
	if (cfg.spell_cost_reduction or 0) > 0 then
		tParts[#tParts + 1] = "-" .. SetNumFR(cfg.spell_cost_reduction * nMult) .. "% Coût des sorts"
	end
	if (cfg.dodge_points or 0) > 0 then
		tParts[#tParts + 1] = "+" .. SetNumFR(cfg.dodge_points * nMult) .. " points de chance d’esquive"
	end
	if (cfg.combo_speed_pct or 0) > 0 then
		tParts[#tParts + 1] = "+" .. SetNumFR(cfg.combo_speed_pct * nMult) .. "% Vitesse des combos (sol et air)"
	end
	if cfg.flashstep_attack then
		local proc = cfg.flashstep_attack
		local pct = "+" .. SetNumFR(proc.bonus_pct * nMult) .. "%"
		if bCompact then
			tParts[#tParts + 1] = pct .. " attaque après flashstep"
			tParts[#tParts + 1] = "Fenêtre " .. proc.window .. " s / Recharge " .. proc.cooldown .. " s"
			tParts[#tParts + 1] = "Bonus plafonné (détails en infobulle)"
		else
			tParts[#tParts + 1] = pct .. " sur la prochaine attaque légère dans les " .. proc.window .. " s après un flashstep (déplacement min. " .. proc.min_distance .. " unités ; recharge " .. proc.cooldown .. " s). Bonus plafonné sur une attaque moyenne du cycle, partagé entre les impacts, sur une seule cible ; consommé au lancement."
		end
	end
	return table.concat(tParts, ", ")
end

-- Formule partagée serveur/affichage ; les sorts payants ne deviennent pas gratuits.
function EVO_LOOT.SpellReiatsuCost(baseCost, reduction, potionMultiplier)
	local cost = math.max(0, tonumber(baseCost) or 0)
	if cost == 0 then return 0 end
	cost = cost * (1 - math.Clamp(tonumber(reduction) or 0, 0, 20) / 100)
	cost = cost * math.max(0, tonumber(potionMultiplier) or 1)
	return math.max(1, math.floor(cost + 0.000001))
end

-- ── RÈGLES DE SET (demande user 08/01) — SHARED, source UNIQUE serveur + UI ─────────
-- 1) COMPLÉTION : un set n'est complet que si les pièces requises équipées sont TOUTES
--    de la MÊME RARETÉ (3 épiques = actif ; 2 épiques + 1 rare = pas actif).
-- 2) PUISSANCE : le bonus de set est MULTIPLIÉ selon la rareté du set complété, même
--    échelle que les stats des pièces (×1 / ×1.5 / ×2 / ×3 / ×5).
-- Consommé par : ncm_forge sv_stats_hook (application réelle) ET l'UI inventaire
-- (tooltip + carte SETS) -> jamais de désync affichage/effet.

EVO_LOOT.SetRarityMult = {
	common = 1, rare = 1.5, epic = 2, legendary = 3, mythic = 5,
}

-- Comptage des pièces de set ÉQUIPÉES, groupées par (set_id, rareté).
-- tEquipped : table dont les VALEURS sont des ids d'items (format des clés ignoré ;
-- les items sans set_id — katana, tenues... — sont filtrés naturellement).
function EVO_LOOT.CountSetPieces(tEquipped, durability)
	local counts = {}
	for slot, item_id in pairs(tEquipped or {}) do
		local it = ITEMS and ITEMS[item_id]
		local broken = false
		if durability and tonumber(slot) and INVENTORY_CONFIG and INVENTORY_CONFIG.ItemHasDurability
			and INVENTORY_CONFIG.ItemHasDurability(item_id) then
			local sid = (INVENTORY_CONFIG.DB_EQUIP_SLOT_BASE or 1000) + tonumber(slot)
			local dur = durability[sid] or durability[tostring(sid)]
			broken = dur ~= nil and (tonumber(dur) or 0) <= 0
		end
		if it and it.set_id and not broken then
			local r = tostring(it.rarity or "?")
			counts[it.set_id] = counts[it.set_id] or {}
			counts[it.set_id][r] = (counts[it.set_id][r] or 0) + 1
		end
	end
	return counts
end

-- Meilleur groupe MONO-RARETÉ d'un set : count + rareté (0, nil si aucune pièce).
function EVO_LOOT.BestSetCount(countsForSet)
	local best, bestRarity = 0, nil
	for r, n in pairs(countsForSet or {}) do
		if n > best then best, bestRarity = n, r end
	end
	return best, bestRarity
end

-- ============================================================================
-- DEFINITION DES 75 PIECES D'EQUIPEMENT
-- 5 sets × 5 raretés (common/rare/epic/legendary/mythic) × 3 slots (bracelet/collier/bague)
-- Scaling stats : ×1 / ×1.5 / ×2 / ×3 / ×5
-- Tous les sets donnent un peu de reiatsu — Abysses en donne le plus
-- ============================================================================

EVO_LOOT.Equipment = {
	-- ============================== BRASIER (feu → dégâts katana) ==============================
	-- COMMON
	["bracelet_brasier"] = {
		name = "Bracelet du Brasier", description = "Bracelet orné de flammes spirituelles",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yabibke3l8wvr79l.png",
		model_path = "models/evo/accessories/equipement/evo_xpor7532frefe32ze2fgza/evo_XPor7532FREFE32ze2fgzA.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "brasier", slot = "belt",
		stats = { { "e_katana_damage", 0.7 }, { "e_katana_cc_damage", 0.46 }, { "e_max_reiatsu", 0.3 } },
	},
	["collier_brasier"] = {
		name = "Collier du Brasier", description = "Collier aux reflets ardents",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/vqv72ofleonqem6qv.png",
		model_path = "models/evo/accessories/equipement/evo_y4tyedt75ndisq62/evo_zsxmdcqnhvee.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "brasier", slot = "necklace",
		stats = { { "e_katana_damage", 0.46 }, { "e_max_hp", 0.46 }, { "e_max_reiatsu", 0.3 } },
	},
	["bague_brasier"] = {
		name = "Bague du Brasier", description = "Anneau chaud au toucher",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yve7f885qws5icv4n.png",
		model_path = "models/evo/accessories/equipement/evo_47863fefdezjubu5f515ejf/evo_47863FEFdezjubu5F515ejf.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "brasier", slot = "ring",
		stats = { { "e_katana_damage", 0.46 }, { "e_max_reiatsu", 0.6 } },
	},
	-- RARE
	["bracelet_brasier_rare"] = {
		name = "Bracelet du Brasier", description = "Bracelet orné de flammes spirituelles",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yabibke3l8wvr79l.png",
		model_path = "models/evo/accessories/equipement/evo_xpor7532frefe32ze2fgza/evo_XPor7532FREFE32ze2fgzA.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "brasier", slot = "belt",
		stats = { { "e_katana_damage", 1.16 }, { "e_katana_cc_damage", 0.7 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_brasier_rare"] = {
		name = "Collier du Brasier", description = "Collier aux reflets ardents",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/vqv72ofleonqem6qv.png",
		model_path = "models/evo/accessories/equipement/evo_y4tyedt75ndisq62/evo_zsxmdcqnhvee.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "brasier", slot = "necklace",
		stats = { { "e_katana_damage", 0.7 }, { "e_max_hp", 0.7 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_brasier_rare"] = {
		name = "Bague du Brasier", description = "Anneau chaud au toucher",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yve7f885qws5icv4n.png",
		model_path = "models/evo/accessories/equipement/evo_47863fefdezjubu5f515ejf/evo_47863FEFdezjubu5F515ejf.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "brasier", slot = "ring",
		stats = { { "e_katana_damage", 0.7 }, { "e_max_reiatsu", 0.9 } },
	},
	-- EPIC
	["bracelet_brasier_epic"] = {
		name = "Bracelet du Brasier", description = "Bracelet orné de flammes spirituelles",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yabibke3l8wvr79l.png",
		model_path = "models/evo/accessories/equipement/evo_xpor7532frefe32ze2fgza/evo_XPor7532FREFE32ze2fgzA.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "brasier", slot = "belt",
		stats = { { "e_katana_damage", 1.38 }, { "e_katana_cc_damage", 0.92 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_brasier_epic"] = {
		name = "Collier du Brasier", description = "Collier aux reflets ardents",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/vqv72ofleonqem6qv.png",
		model_path = "models/evo/accessories/equipement/evo_y4tyedt75ndisq62/evo_zsxmdcqnhvee.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "brasier", slot = "necklace",
		stats = { { "e_katana_damage", 0.92 }, { "e_max_hp", 0.92 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_brasier_epic"] = {
		name = "Bague du Brasier", description = "Anneau chaud au toucher",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yve7f885qws5icv4n.png",
		model_path = "models/evo/accessories/equipement/evo_47863fefdezjubu5f515ejf/evo_47863FEFdezjubu5F515ejf.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "brasier", slot = "ring",
		stats = { { "e_katana_damage", 0.92 }, { "e_max_reiatsu", 1.18 } },
	},
	-- LEGENDARY
	["bracelet_brasier_legendary"] = {
		name = "Bracelet du Brasier", description = "Bracelet orné de flammes spirituelles",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yabibke3l8wvr79l.png",
		model_path = "models/evo/accessories/equipement/evo_xpor7532frefe32ze2fgza/evo_XPor7532FREFE32ze2fgzA.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "brasier", slot = "belt",
		stats = { { "e_katana_damage", 2.08 }, { "e_katana_cc_damage", 1.38 }, { "e_max_reiatsu", 0.9 } },
	},
	["collier_brasier_legendary"] = {
		name = "Collier du Brasier", description = "Collier aux reflets ardents",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/vqv72ofleonqem6qv.png",
		model_path = "models/evo/accessories/equipement/evo_y4tyedt75ndisq62/evo_zsxmdcqnhvee.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "brasier", slot = "necklace",
		stats = { { "e_katana_damage", 1.38 }, { "e_max_hp", 1.38 }, { "e_max_reiatsu", 0.9 } },
	},
	["bague_brasier_legendary"] = {
		name = "Bague du Brasier", description = "Anneau chaud au toucher",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yve7f885qws5icv4n.png",
		model_path = "models/evo/accessories/equipement/evo_47863fefdezjubu5f515ejf/evo_47863FEFdezjubu5F515ejf.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "brasier", slot = "ring",
		stats = { { "e_katana_damage", 1.38 }, { "e_max_reiatsu", 1.78 } },
	},
	-- MYTHIC
	["bracelet_brasier_mythic"] = {
		name = "Bracelet du Brasier", description = "Bracelet orné de flammes spirituelles",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yabibke3l8wvr79l.png",
		model_path = "models/evo/accessories/equipement/evo_xpor7532frefe32ze2fgza/evo_XPor7532FREFE32ze2fgzA.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "brasier", slot = "belt",
		stats = { { "e_katana_damage", 3.46 }, { "e_katana_cc_damage", 2.3 }, { "e_max_reiatsu", 1.48 } },
	},
	["collier_brasier_mythic"] = {
		name = "Collier du Brasier", description = "Collier aux reflets ardents",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/vqv72ofleonqem6qv.png",
		model_path = "models/evo/accessories/equipement/evo_y4tyedt75ndisq62/evo_zsxmdcqnhvee.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "brasier", slot = "necklace",
		stats = { { "e_katana_damage", 2.3 }, { "e_max_hp", 2.3 }, { "e_max_reiatsu", 1.48 } },
	},
	["bague_brasier_mythic"] = {
		name = "Bague du Brasier", description = "Anneau chaud au toucher",
		icon = "tgw7tau20hu4/fqq5j987vtiyifc/yve7f885qws5icv4n.png",
		model_path = "models/evo/accessories/equipement/evo_47863fefdezjubu5f515ejf/evo_47863FEFdezjubu5F515ejf.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "brasier", slot = "ring",
		stats = { { "e_katana_damage", 2.3 }, { "e_max_reiatsu", 2.98 } },
	},

	-- ============================== TEMPETE (vent → flashstep) ==============================
	-- BUFF 08/29, 2e passe (demande user : « booste encore plus, notamment le reiatsu
	-- max, et encore un peu le cd flashstep surtout, et la portée »).
	-- Les 15 pièces suivent le barème du fichier (×1 / ×1,5 / ×2 / ×3 / ×5) appliqué à
	-- ces bases : portée flashstep 1,2 (bracelet) et 0,8 (collier/bague), cooldown
	-- flashstep 1,5, reiatsu max 0,8 sur les trois pièces.
	-- Set complet en MYTHIQUE, pièces seules : +14 % de portée, -15 % de cooldown,
	-- +12 % de reiatsu max (avant : +10,5 / -9 / +9). Avec le bonus 3/3 (inchangé) :
	-- +20 % de portée, -27 % de cooldown, -50 % de coût en reiatsu.
	-- ⚠ PLAFOND : le reiatsu max reste SOUS Abysses à CHAQUE rareté (12 % contre
	-- 13,38 % en mythique) — l'en-tête du fichier fait d'Abysses le set de reiatsu.
	-- Monter la base au-dessus de 0,8 franchirait ce plafond.
	-- COMMON
	["bracelet_tempete"] = {
		name = "Bracelet de la Tempête", description = "Bracelet qui vibre au vent",
		icon = "wzl_loot/equipment/bracelet_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_wnr7g69gh1erhd6d/evo_Wnr7G69gH1ERHD6d.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "tempete", slot = "belt",
		stats = { { "e_flashstep_range", -1.2 }, { "e_max_reiatsu", 0.8 } },
	},
	["collier_tempete"] = {
		name = "Collier de la Tempête", description = "Collier qui siffle doucement",
		icon = "wzl_loot/equipment/collier_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_mlf8l906syitiuqt/evo_y887vo2t060yt1xko.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "tempete", slot = "necklace",
		stats = { { "e_flashstep_range", -0.8 }, { "e_flashstep_cd", 1.5 }, { "e_max_reiatsu", 0.8 } },
	},
	["bague_tempete"] = {
		name = "Bague de la Tempête", description = "Anneau léger comme l'air",
		icon = "wzl_loot/equipment/bague_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_chdge1691fcz619z6fezf5ff/evo_Chdge1691fCZ619z6FEZF5ff.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "tempete", slot = "ring",
		stats = { { "e_flashstep_cd", 1.5 }, { "e_flashstep_range", -0.8 }, { "e_max_reiatsu", 0.8 } },
	},
	-- RARE
	["bracelet_tempete_rare"] = {
		name = "Bracelet de la Tempête", description = "Bracelet qui vibre au vent",
		icon = "wzl_loot/equipment/bracelet_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_wnr7g69gh1erhd6d/evo_Wnr7G69gH1ERHD6d.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "tempete", slot = "belt",
		stats = { { "e_flashstep_range", -1.8 }, { "e_max_reiatsu", 1.2 } },
	},
	["collier_tempete_rare"] = {
		name = "Collier de la Tempête", description = "Collier qui siffle doucement",
		icon = "wzl_loot/equipment/collier_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_mlf8l906syitiuqt/evo_y887vo2t060yt1xko.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "tempete", slot = "necklace",
		stats = { { "e_flashstep_range", -1.2 }, { "e_flashstep_cd", 2.25 }, { "e_max_reiatsu", 1.2 } },
	},
	["bague_tempete_rare"] = {
		name = "Bague de la Tempête", description = "Anneau léger comme l'air",
		icon = "wzl_loot/equipment/bague_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_chdge1691fcz619z6fezf5ff/evo_Chdge1691fCZ619z6FEZF5ff.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "tempete", slot = "ring",
		stats = { { "e_flashstep_cd", 2.25 }, { "e_flashstep_range", -1.2 }, { "e_max_reiatsu", 1.2 } },
	},
	-- EPIC
	["bracelet_tempete_epic"] = {
		name = "Bracelet de la Tempête", description = "Bracelet qui vibre au vent",
		icon = "wzl_loot/equipment/bracelet_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_wnr7g69gh1erhd6d/evo_Wnr7G69gH1ERHD6d.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "tempete", slot = "belt",
		stats = { { "e_flashstep_range", -2.4 }, { "e_max_reiatsu", 1.6 } },
	},
	["collier_tempete_epic"] = {
		name = "Collier de la Tempête", description = "Collier qui siffle doucement",
		icon = "wzl_loot/equipment/collier_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_mlf8l906syitiuqt/evo_y887vo2t060yt1xko.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "tempete", slot = "necklace",
		stats = { { "e_flashstep_range", -1.6 }, { "e_flashstep_cd", 3 }, { "e_max_reiatsu", 1.6 } },
	},
	["bague_tempete_epic"] = {
		name = "Bague de la Tempête", description = "Anneau léger comme l'air",
		icon = "wzl_loot/equipment/bague_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_chdge1691fcz619z6fezf5ff/evo_Chdge1691fCZ619z6FEZF5ff.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "tempete", slot = "ring",
		stats = { { "e_flashstep_cd", 3 }, { "e_flashstep_range", -1.6 }, { "e_max_reiatsu", 1.6 } },
	},
	-- LEGENDARY
	["bracelet_tempete_legendary"] = {
		name = "Bracelet de la Tempête", description = "Bracelet qui vibre au vent",
		icon = "wzl_loot/equipment/bracelet_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_wnr7g69gh1erhd6d/evo_Wnr7G69gH1ERHD6d.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "tempete", slot = "belt",
		stats = { { "e_flashstep_range", -3.6 }, { "e_max_reiatsu", 2.4 } },
	},
	["collier_tempete_legendary"] = {
		name = "Collier de la Tempête", description = "Collier qui siffle doucement",
		icon = "wzl_loot/equipment/collier_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_mlf8l906syitiuqt/evo_y887vo2t060yt1xko.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "tempete", slot = "necklace",
		stats = { { "e_flashstep_range", -2.4 }, { "e_flashstep_cd", 4.5 }, { "e_max_reiatsu", 2.4 } },
	},
	["bague_tempete_legendary"] = {
		name = "Bague de la Tempête", description = "Anneau léger comme l'air",
		icon = "wzl_loot/equipment/bague_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_chdge1691fcz619z6fezf5ff/evo_Chdge1691fCZ619z6FEZF5ff.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "tempete", slot = "ring",
		stats = { { "e_flashstep_cd", 4.5 }, { "e_flashstep_range", -2.4 }, { "e_max_reiatsu", 2.4 } },
	},
	-- MYTHIC
	["bracelet_tempete_mythic"] = {
		name = "Bracelet de la Tempête", description = "Bracelet qui vibre au vent",
		icon = "wzl_loot/equipment/bracelet_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_wnr7g69gh1erhd6d/evo_Wnr7G69gH1ERHD6d.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "tempete", slot = "belt",
		stats = { { "e_flashstep_range", -6 }, { "e_max_reiatsu", 4 } },
	},
	["collier_tempete_mythic"] = {
		name = "Collier de la Tempête", description = "Collier qui siffle doucement",
		icon = "wzl_loot/equipment/collier_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_mlf8l906syitiuqt/evo_y887vo2t060yt1xko.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "tempete", slot = "necklace",
		stats = { { "e_flashstep_range", -4 }, { "e_flashstep_cd", 7.5 }, { "e_max_reiatsu", 4 } },
	},
	["bague_tempete_mythic"] = {
		name = "Bague de la Tempête", description = "Anneau léger comme l'air",
		icon = "wzl_loot/equipment/bague_tempete.png",
		model_path = "models/evo/accessories/equipement/evo_chdge1691fcz619z6fezf5ff/evo_Chdge1691fCZ619z6FEZF5ff.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "tempete", slot = "ring",
		stats = { { "e_flashstep_cd", 7.5 }, { "e_flashstep_range", -4 }, { "e_max_reiatsu", 4 } },
	},

	-- ============================== GLACIER (glace → HP/tank) ==============================
	-- COMMON
	["bracelet_glacier"] = {
		name = "Bracelet du Glacier", description = "Bracelet d'un froid mordant",
		icon = "wzl_loot/equipment/bracelet_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_hgfp726fr6f18rggjerkfa/evo_HgfP726FR6f18rGgjerkFa.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "glacier", slot = "belt",
		stats = { { "e_max_hp", 0.92 }, { "e_parade_regen", 0.24 }, { "e_max_reiatsu", 0.3 } },
	},
	["collier_glacier"] = {
		name = "Collier du Glacier", description = "Collier de glace pure",
		icon = "wzl_loot/equipment/collier_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_2l9dln9qu2wv/evo_azu25qryc169.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "glacier", slot = "necklace",
		stats = { { "e_max_hp", 0.46 }, { "e_regen_hp", 0.46 }, { "e_max_reiatsu", 0.3 } },
	},
	["bague_glacier"] = {
		name = "Bague du Glacier", description = "Anneau qui gèle au toucher",
		icon = "wzl_loot/equipment/bague_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_cpjfpe9f18zfeudzuhdp/evo_cpJFPE9f18zfeUDZUHDp.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "glacier", slot = "ring",
		stats = { { "e_parade_max", 0.7 }, { "e_max_hp", 0.46 }, { "e_max_reiatsu", 0.3 } },
	},
	-- RARE
	["bracelet_glacier_rare"] = {
		name = "Bracelet du Glacier", description = "Bracelet d'un froid mordant",
		icon = "wzl_loot/equipment/bracelet_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_hgfp726fr6f18rggjerkfa/evo_HgfP726FR6f18rGgjerkFa.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "glacier", slot = "belt",
		stats = { { "e_max_hp", 1.38 }, { "e_parade_regen", 0.38 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_glacier_rare"] = {
		name = "Collier du Glacier", description = "Collier de glace pure",
		icon = "wzl_loot/equipment/collier_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_2l9dln9qu2wv/evo_azu25qryc169.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "glacier", slot = "necklace",
		stats = { { "e_max_hp", 0.7 }, { "e_regen_hp", 0.7 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_glacier_rare"] = {
		name = "Bague du Glacier", description = "Anneau qui gèle au toucher",
		icon = "wzl_loot/equipment/bague_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_cpjfpe9f18zfeudzuhdp/evo_cpJFPE9f18zfeUDZUHDp.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "glacier", slot = "ring",
		stats = { { "e_parade_max", 1.16 }, { "e_max_hp", 0.7 }, { "e_max_reiatsu", 0.6 } },
	},
	-- EPIC
	["bracelet_glacier_epic"] = {
		name = "Bracelet du Glacier", description = "Bracelet d'un froid mordant",
		icon = "wzl_loot/equipment/bracelet_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_hgfp726fr6f18rggjerkfa/evo_HgfP726FR6f18rGgjerkFa.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "glacier", slot = "belt",
		stats = { { "e_max_hp", 1.84 }, { "e_parade_regen", 0.46 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_glacier_epic"] = {
		name = "Collier du Glacier", description = "Collier de glace pure",
		icon = "wzl_loot/equipment/collier_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_2l9dln9qu2wv/evo_azu25qryc169.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "glacier", slot = "necklace",
		stats = { { "e_max_hp", 0.92 }, { "e_regen_hp", 0.92 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_glacier_epic"] = {
		name = "Bague du Glacier", description = "Anneau qui gèle au toucher",
		icon = "wzl_loot/equipment/bague_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_cpjfpe9f18zfeudzuhdp/evo_cpJFPE9f18zfeUDZUHDp.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "glacier", slot = "ring",
		stats = { { "e_parade_max", 1.38 }, { "e_max_hp", 0.92 }, { "e_max_reiatsu", 0.6 } },
	},
	-- LEGENDARY
	["bracelet_glacier_legendary"] = {
		name = "Bracelet du Glacier", description = "Bracelet d'un froid mordant",
		icon = "wzl_loot/equipment/bracelet_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_hgfp726fr6f18rggjerkfa/evo_HgfP726FR6f18rGgjerkFa.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "glacier", slot = "belt",
		stats = { { "e_max_hp", 2.76 }, { "e_parade_regen", 0.7 }, { "e_max_reiatsu", 0.9 } },
	},
	["collier_glacier_legendary"] = {
		name = "Collier du Glacier", description = "Collier de glace pure",
		icon = "wzl_loot/equipment/collier_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_2l9dln9qu2wv/evo_azu25qryc169.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "glacier", slot = "necklace",
		stats = { { "e_max_hp", 1.38 }, { "e_regen_hp", 1.38 }, { "e_max_reiatsu", 0.9 } },
	},
	["bague_glacier_legendary"] = {
		name = "Bague du Glacier", description = "Anneau qui gèle au toucher",
		icon = "wzl_loot/equipment/bague_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_cpjfpe9f18zfeudzuhdp/evo_cpJFPE9f18zfeUDZUHDp.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "glacier", slot = "ring",
		stats = { { "e_parade_max", 2.08 }, { "e_max_hp", 1.38 }, { "e_max_reiatsu", 0.9 } },
	},
	-- MYTHIC
	["bracelet_glacier_mythic"] = {
		name = "Bracelet du Glacier", description = "Bracelet d'un froid mordant",
		icon = "wzl_loot/equipment/bracelet_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_hgfp726fr6f18rggjerkfa/evo_HgfP726FR6f18rGgjerkFa.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "glacier", slot = "belt",
		stats = { { "e_max_hp", 4.6 }, { "e_parade_regen", 1.16 }, { "e_max_reiatsu", 1.48 } },
	},
	["collier_glacier_mythic"] = {
		name = "Collier du Glacier", description = "Collier de glace pure",
		icon = "wzl_loot/equipment/collier_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_2l9dln9qu2wv/evo_azu25qryc169.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "glacier", slot = "necklace",
		stats = { { "e_max_hp", 2.3 }, { "e_regen_hp", 2.3 }, { "e_max_reiatsu", 1.48 } },
	},
	["bague_glacier_mythic"] = {
		name = "Bague du Glacier", description = "Anneau qui gèle au toucher",
		icon = "wzl_loot/equipment/bague_glacier.png",
		model_path = "models/evo/accessories/equipement/evo_cpjfpe9f18zfeudzuhdp/evo_cpJFPE9f18zfeUDZUHDp.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "glacier", slot = "ring",
		stats = { { "e_parade_max", 3.46 }, { "e_max_hp", 2.3 }, { "e_max_reiatsu", 1.48 } },
	},

	-- ============================== FOUDRE (éclair → crit) ==============================
	-- Critiques additifs : chaque pièce apporte chance ET dégâts de critique.
	-- Mythique complet + bonus de set : 29 % de chance, +50 % par critique
	-- (socle inclus), soit environ +14,2 % de dégâts moyens face au socle seul.
	-- COMMON
	["bracelet_foudre"] = {
		name = "Bracelet de la Foudre", description = "Bracelet crépitant d'électricité",
		icon = "wzl_loot/equipment/bracelet_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_fa879grgre9gf26r6fgorp/evo_Fa879grGRE9gf26r6FGORp.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "foudre", slot = "belt",
		stats = { { "e_katana_cc_chance", 1.6 }, { "e_katana_cc_damage", 2 }, { "e_max_reiatsu", 0.3 } },
	},
	["collier_foudre"] = {
		name = "Collier de la Foudre", description = "Collier traversé d'éclairs",
		icon = "wzl_loot/equipment/collier_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_qxuledhd5fdf/evo_3kbysn1y5ze7ha.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "foudre", slot = "necklace",
		stats = { { "e_katana_cc_chance", 1.2 }, { "e_katana_cc_damage", 2.6 }, { "e_max_reiatsu", 0.3 } },
	},
	["bague_foudre"] = {
		name = "Bague de la Foudre", description = "Anneau aux étincelles vives",
		icon = "wzl_loot/equipment/bague_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_vadzf862fhuezfd3429zhdfzz/evo_Vadzf862fHUEZFD3429zHDFZz.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "foudre", slot = "ring",
		stats = { { "e_katana_cc_chance", 0.8 }, { "e_katana_cc_damage", 3.2 }, { "e_max_reiatsu", 0.3 } },
	},
	-- RARE
	["bracelet_foudre_rare"] = {
		name = "Bracelet de la Foudre", description = "Bracelet crépitant d'électricité",
		icon = "wzl_loot/equipment/bracelet_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_fa879grgre9gf26r6fgorp/evo_Fa879grGRE9gf26r6FGORp.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "foudre", slot = "belt",
		stats = { { "e_katana_cc_chance", 2.72 }, { "e_katana_cc_damage", 3.4 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_foudre_rare"] = {
		name = "Collier de la Foudre", description = "Collier traversé d'éclairs",
		icon = "wzl_loot/equipment/collier_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_qxuledhd5fdf/evo_3kbysn1y5ze7ha.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "foudre", slot = "necklace",
		stats = { { "e_katana_cc_chance", 2.04 }, { "e_katana_cc_damage", 4.42 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_foudre_rare"] = {
		name = "Bague de la Foudre", description = "Anneau aux étincelles vives",
		icon = "wzl_loot/equipment/bague_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_vadzf862fhuezfd3429zhdfzz/evo_Vadzf862fHUEZFD3429zHDFZz.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "foudre", slot = "ring",
		stats = { { "e_katana_cc_chance", 1.36 }, { "e_katana_cc_damage", 5.44 }, { "e_max_reiatsu", 0.6 } },
	},
	-- EPIC
	["bracelet_foudre_epic"] = {
		name = "Bracelet de la Foudre", description = "Bracelet crépitant d'électricité",
		icon = "wzl_loot/equipment/bracelet_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_fa879grgre9gf26r6fgorp/evo_Fa879grGRE9gf26r6FGORp.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "foudre", slot = "belt",
		stats = { { "e_katana_cc_chance", 3.2 }, { "e_katana_cc_damage", 4 }, { "e_max_reiatsu", 0.6 } },
	},
	["collier_foudre_epic"] = {
		name = "Collier de la Foudre", description = "Collier traversé d'éclairs",
		icon = "wzl_loot/equipment/collier_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_qxuledhd5fdf/evo_3kbysn1y5ze7ha.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "foudre", slot = "necklace",
		stats = { { "e_katana_cc_chance", 2.4 }, { "e_katana_cc_damage", 5.2 }, { "e_max_reiatsu", 0.6 } },
	},
	["bague_foudre_epic"] = {
		name = "Bague de la Foudre", description = "Anneau aux étincelles vives",
		icon = "wzl_loot/equipment/bague_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_vadzf862fhuezfd3429zhdfzz/evo_Vadzf862fHUEZFD3429zHDFZz.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "foudre", slot = "ring",
		stats = { { "e_katana_cc_chance", 1.6 }, { "e_katana_cc_damage", 6.4 }, { "e_max_reiatsu", 0.6 } },
	},
	-- LEGENDARY
	["bracelet_foudre_legendary"] = {
		name = "Bracelet de la Foudre", description = "Bracelet crépitant d'électricité",
		icon = "wzl_loot/equipment/bracelet_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_fa879grgre9gf26r6fgorp/evo_Fa879grGRE9gf26r6FGORp.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "foudre", slot = "belt",
		stats = { { "e_katana_cc_chance", 4.8 }, { "e_katana_cc_damage", 6 }, { "e_max_reiatsu", 0.9 } },
	},
	["collier_foudre_legendary"] = {
		name = "Collier de la Foudre", description = "Collier traversé d'éclairs",
		icon = "wzl_loot/equipment/collier_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_qxuledhd5fdf/evo_3kbysn1y5ze7ha.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "foudre", slot = "necklace",
		stats = { { "e_katana_cc_chance", 3.6 }, { "e_katana_cc_damage", 7.8 }, { "e_max_reiatsu", 0.9 } },
	},
	["bague_foudre_legendary"] = {
		name = "Bague de la Foudre", description = "Anneau aux étincelles vives",
		icon = "wzl_loot/equipment/bague_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_vadzf862fhuezfd3429zhdfzz/evo_Vadzf862fHUEZFD3429zHDFZz.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "foudre", slot = "ring",
		stats = { { "e_katana_cc_chance", 2.4 }, { "e_katana_cc_damage", 9.6 }, { "e_max_reiatsu", 0.9 } },
	},
	-- MYTHIC
	["bracelet_foudre_mythic"] = {
		name = "Bracelet de la Foudre", description = "Bracelet crépitant d'électricité",
		icon = "wzl_loot/equipment/bracelet_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_fa879grgre9gf26r6fgorp/evo_Fa879grGRE9gf26r6FGORp.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "foudre", slot = "belt",
		stats = { { "e_katana_cc_chance", 8 }, { "e_katana_cc_damage", 10 }, { "e_max_reiatsu", 1.48 } },
	},
	["collier_foudre_mythic"] = {
		name = "Collier de la Foudre", description = "Collier traversé d'éclairs",
		icon = "wzl_loot/equipment/collier_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_qxuledhd5fdf/evo_3kbysn1y5ze7ha.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "foudre", slot = "necklace",
		stats = { { "e_katana_cc_chance", 6 }, { "e_katana_cc_damage", 13 }, { "e_max_reiatsu", 1.48 } },
	},
	["bague_foudre_mythic"] = {
		name = "Bague de la Foudre", description = "Anneau aux étincelles vives",
		icon = "wzl_loot/equipment/bague_foudre.png",
		model_path = "models/evo/accessories/equipement/evo_vadzf862fhuezfd3429zhdfzz/evo_Vadzf862fHUEZFD3429zHDFZz.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "foudre", slot = "ring",
		stats = { { "e_katana_cc_chance", 4 }, { "e_katana_cc_damage", 16 }, { "e_max_reiatsu", 1.48 } },
	},

	-- ============================== ABYSSES (ombre/spirituel → reiatsu) ==============================
	-- COMMON
	["bracelet_abysses"] = {
		name = "Bracelet des Abysses", description = "Bracelet imprégné de reiatsu obscur",
		icon = "wzl_loot/equipment/bracelet_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_9dfrt52g1v6s9gjvgpoejjg6c/evo_9Dfrt52g1v6s9gJVGPOEJjg6c.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "abysses", slot = "belt",
		stats = { { "e_max_reiatsu", 1.18 }, { "e_regen_reiatsu", 0.6 }, { "e_spell_damage", 0.7 } },
	},
	["collier_abysses"] = {
		name = "Collier des Abysses", description = "Collier qui aspire la lumière",
		icon = "wzl_loot/equipment/collier_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_7z1enz6ecseohxfa/evo_q554yfotokke.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "abysses", slot = "necklace",
		stats = { { "e_max_reiatsu", 0.9 }, { "e_regen_reiatsu", 0.6 }, { "e_spell_cd_reduction", 0.24 }, { "e_spell_damage", 0.46 } },
	},
	["bague_abysses"] = {
		name = "Bague des Abysses", description = "Anneau d'un noir insondable",
		icon = "wzl_loot/equipment/bague_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_vdsz7521gfhuz319efhjzjfn/evo_Vdsz7521gfHUZ319efhJZJFN.mdl",
		bodygroup = 0,
		category = "accessory", rarity = "common", set_id = "abysses", slot = "ring",
		stats = { { "e_regen_reiatsu", 0.9 }, { "e_max_reiatsu", 0.6 }, { "e_spell_cd_reduction", 0.24 }, { "e_spell_damage", 0.46 } },
	},
	-- RARE
	["bracelet_abysses_rare"] = {
		name = "Bracelet des Abysses", description = "Bracelet imprégné de reiatsu obscur",
		icon = "wzl_loot/equipment/bracelet_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_9dfrt52g1v6s9gjvgpoejjg6c/evo_9Dfrt52g1v6s9gJVGPOEJjg6c.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "abysses", slot = "belt",
		stats = { { "e_max_reiatsu", 1.78 }, { "e_regen_reiatsu", 0.9 }, { "e_spell_damage", 1.16 } },
	},
	["collier_abysses_rare"] = {
		name = "Collier des Abysses", description = "Collier qui aspire la lumière",
		icon = "wzl_loot/equipment/collier_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_7z1enz6ecseohxfa/evo_q554yfotokke.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "abysses", slot = "necklace",
		stats = { { "e_max_reiatsu", 1.48 }, { "e_regen_reiatsu", 0.9 }, { "e_spell_cd_reduction", 0.46 }, { "e_spell_damage", 0.7 } },
	},
	["bague_abysses_rare"] = {
		name = "Bague des Abysses", description = "Anneau d'un noir insondable",
		icon = "wzl_loot/equipment/bague_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_vdsz7521gfhuz319efhjzjfn/evo_Vdsz7521gfHUZ319efhJZJFN.mdl",
		bodygroup = 1,
		category = "accessory", rarity = "rare", set_id = "abysses", slot = "ring",
		stats = { { "e_regen_reiatsu", 1.48 }, { "e_max_reiatsu", 0.9 }, { "e_spell_cd_reduction", 0.38 }, { "e_spell_damage", 0.7 } },
	},
	-- EPIC
	["bracelet_abysses_epic"] = {
		name = "Bracelet des Abysses", description = "Bracelet imprégné de reiatsu obscur",
		icon = "wzl_loot/equipment/bracelet_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_9dfrt52g1v6s9gjvgpoejjg6c/evo_9Dfrt52g1v6s9gJVGPOEJjg6c.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "abysses", slot = "belt",
		stats = { { "e_max_reiatsu", 2.38 }, { "e_regen_reiatsu", 1.18 }, { "e_spell_damage", 1.38 } },
	},
	["collier_abysses_epic"] = {
		name = "Collier des Abysses", description = "Collier qui aspire la lumière",
		icon = "wzl_loot/equipment/collier_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_7z1enz6ecseohxfa/evo_q554yfotokke.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "abysses", slot = "necklace",
		stats = { { "e_max_reiatsu", 1.78 }, { "e_regen_reiatsu", 1.18 }, { "e_spell_cd_reduction", 0.46 }, { "e_spell_damage", 0.92 } },
	},
	["bague_abysses_epic"] = {
		name = "Bague des Abysses", description = "Anneau d'un noir insondable",
		icon = "wzl_loot/equipment/bague_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_vdsz7521gfhuz319efhjzjfn/evo_Vdsz7521gfHUZ319efhJZJFN.mdl",
		bodygroup = 2,
		category = "accessory", rarity = "epic", set_id = "abysses", slot = "ring",
		stats = { { "e_regen_reiatsu", 1.78 }, { "e_max_reiatsu", 1.18 }, { "e_spell_cd_reduction", 0.46 }, { "e_spell_damage", 0.92 } },
	},
	-- LEGENDARY
	["bracelet_abysses_legendary"] = {
		name = "Bracelet des Abysses", description = "Bracelet imprégné de reiatsu obscur",
		icon = "wzl_loot/equipment/bracelet_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_9dfrt52g1v6s9gjvgpoejjg6c/evo_9Dfrt52g1v6s9gJVGPOEJjg6c.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "abysses", slot = "belt",
		stats = { { "e_max_reiatsu", 3.56 }, { "e_regen_reiatsu", 1.78 }, { "e_spell_damage", 2.08 } },
	},
	["collier_abysses_legendary"] = {
		name = "Collier des Abysses", description = "Collier qui aspire la lumière",
		icon = "wzl_loot/equipment/collier_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_7z1enz6ecseohxfa/evo_q554yfotokke.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "abysses", slot = "necklace",
		stats = { { "e_max_reiatsu", 2.68 }, { "e_regen_reiatsu", 1.78 }, { "e_spell_cd_reduction", 0.7 }, { "e_spell_damage", 1.38 } },
	},
	["bague_abysses_legendary"] = {
		name = "Bague des Abysses", description = "Anneau d'un noir insondable",
		icon = "wzl_loot/equipment/bague_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_vdsz7521gfhuz319efhjzjfn/evo_Vdsz7521gfHUZ319efhJZJFN.mdl",
		bodygroup = 3,
		category = "accessory", rarity = "legendary", set_id = "abysses", slot = "ring",
		stats = { { "e_regen_reiatsu", 2.68 }, { "e_max_reiatsu", 1.78 }, { "e_spell_cd_reduction", 0.7 }, { "e_spell_damage", 1.38 } },
	},
	-- MYTHIC
	["bracelet_abysses_mythic"] = {
		name = "Bracelet des Abysses", description = "Bracelet imprégné de reiatsu obscur",
		icon = "wzl_loot/equipment/bracelet_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_9dfrt52g1v6s9gjvgpoejjg6c/evo_9Dfrt52g1v6s9gJVGPOEJjg6c.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "abysses", slot = "belt",
		stats = { { "e_max_reiatsu", 5.94 }, { "e_regen_reiatsu", 2.98 }, { "e_spell_damage", 3.46 } },
	},
	["collier_abysses_mythic"] = {
		name = "Collier des Abysses", description = "Collier qui aspire la lumière",
		icon = "wzl_loot/equipment/collier_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_7z1enz6ecseohxfa/evo_q554yfotokke.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "abysses", slot = "necklace",
		stats = { { "e_max_reiatsu", 4.46 }, { "e_regen_reiatsu", 2.98 }, { "e_spell_cd_reduction", 1.16 }, { "e_spell_damage", 2.3 } },
	},
	["bague_abysses_mythic"] = {
		name = "Bague des Abysses", description = "Anneau d'un noir insondable",
		icon = "wzl_loot/equipment/bague_abysses.png",
		model_path = "models/evo/accessories/equipement/evo_vdsz7521gfhuz319efhjzjfn/evo_Vdsz7521gfHUZ319efhJZJFN.mdl",
		bodygroup = 4,
		category = "accessory", rarity = "mythic", set_id = "abysses", slot = "ring",
		stats = { { "e_regen_reiatsu", 4.46 }, { "e_max_reiatsu", 2.98 }, { "e_spell_cd_reduction", 1.16 }, { "e_spell_damage", 2.3 } },
	},
}

-- (SYSTÈME D'ITEM LEVEL RETIRÉ, user 08/14 : brouillon de mars supplanté par la forge
--  ncm_forge en mai, jamais eu d'UI. Sa table BDD equipment_levels reste en base, inerte.)

-- ============================================================================
-- Poids de drop par set selon le tier du coffre
-- Chaque tier de coffre ne drop QUE des items de la rareté correspondante
-- (filtrage assuré par BuildChestLootPool)
-- ============================================================================

local CHEST_TIER_TO_RARITY = {
	commun     = "common",
	rare       = "rare",
	epique     = "epic",
	legendaire = "legendary",
	mythique   = "mythic",
}

-- Poids par set : équiprobables par défaut (20 pour chacun des 5 sets).
-- Tu peux déséquilibrer ici pour qu'un set soit plus rare qu'un autre.
local CHEST_TIER_WEIGHTS = {
	commun     = { brasier = 20, tempete = 20, glacier = 20, foudre = 20, abysses = 20 },
	rare       = { brasier = 20, tempete = 20, glacier = 20, foudre = 20, abysses = 20 },
	epique     = { brasier = 20, tempete = 20, glacier = 20, foudre = 20, abysses = 20 },
	legendaire = { brasier = 20, tempete = 20, glacier = 20, foudre = 20, abysses = 20 },
	mythique   = { brasier = 20, tempete = 20, glacier = 20, foudre = 20, abysses = 20 },
}

-- Poids par defaut (utilise si aucun tier specifie)
local SET_DROP_WEIGHTS = CHEST_TIER_WEIGHTS.rare

-- ============================================================================
-- Generer automatiquement le loot pool du coffre
-- Filtre par rareté = chaque chest tier ne donne que sa rareté.
-- ============================================================================

local function BuildChestLootPool(sTier)
	local tWeights = CHEST_TIER_WEIGHTS[sTier] or SET_DROP_WEIGHTS
	local targetRarity = CHEST_TIER_TO_RARITY[sTier]
	local pool = {}
	for item_id, item in pairs(EVO_LOOT.Equipment) do
		if not targetRarity or item.rarity == targetRarity then
			local set_weight = tWeights[item.set_id] or 10
			if set_weight > 0 then
				table.insert(pool, { item = item_id, weight = set_weight })
			end
		end
	end
	return pool
end

-- ============================================================================
-- TABLE DE RECOMPENSES PAR TIER DE COFFRE
-- ----------------------------------------------------------------------------
-- À chaque ouverture, on roll d'abord LE TYPE de récompense (money/item/reroll)
-- selon `weights`, puis on roll la valeur :
--   • money  → montant random entre money_range.min et money_range.max
--   • item   → un item de la rareté du coffre, set tiré via CHEST_TIER_WEIGHTS
--   • reroll → catégorie tirée parmi reroll_categories (art/style/finisher/aura)
--
-- Plus le coffre est rare, plus les chances d'item/reroll montent et la money
-- aussi (en montant). Tout est configurable ici, séparément par tier.
--
-- MONTANTS DIVISES PAR 10 (2026-07-26, demande user, en deux passes : /5 puis /2). Mesure a l'origine du reglage :
-- un joueur avait fait 40 000 yens en 4 h de farm de Hollows. Le modele economique
-- (0,042 coffre par kill x 1 664 yens moyens x ~142 kills/h) donnait 40 064 sur 4 h,
-- soit exactement l'observe. Apres division : ~2 000 yens/h, donc ~8 000 sur 4 h.
-- Le levier choisi est le MONTANT, pas le taux de drop : ouvrir un coffre reste
-- gratifiant et les raretes gardent leur interet, c'est la pluie de yens qui s'arrete.
-- ============================================================================

EVO_LOOT.RewardConfig = {
	coffre_commun = {
		-- Probabilités du type de récompense (la somme n'a pas besoin de faire 100, c'est pondéré)
		weights           = { money = 85, item = 5.5, reroll = 0 },
		-- Montant d'argent en yens (random uniforme entre min et max)
		money_range       = { min = 50, max = 200 },
		-- Catégories de reroll : poids égal entre les 4, +1 reroll à chaque tirage
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	coffre_rare = {
		weights           = { money = 90, item = 5, reroll = 0 },
		money_range       = { min = 150, max = 500 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	coffre_epique = {
		weights           = { money = 94.5, item = 5, reroll = 0.5 },
		money_range       = { min = 400, max = 1200 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	coffre_legendaire = {
		weights           = { money = 97, item = 2.5, reroll = 1 },
		money_range       = { min = 1000, max = 3000 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	coffre_mythique = {
		weights           = { money = 97.5, item = 1, reroll = 2 },
		money_range       = { min = 2500, max = 6000 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	-- World boss : item drop tres eleve (gros loot pour top 5 dommages).
	-- Pool = items mythiques. Pas d'argent : c'est un coffre prestige.
	coffre_world_boss = {
		-- reroll 5 -> 1 (demande user) : item = le reste. money=0 (prestige) -> 99% item / 1% reroll.
		weights           = { money = 0, item = 99, reroll = 1 },
		money_range       = { min = 0, max = 0 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 25, amount = 1 },
			{ category = "style_de_combat", weight = 25, amount = 1 },
			{ category = "style_execution", weight = 25, amount = 1 },
			{ category = "reiatsu_color",   weight = 25, amount = 1 },
		},
	},
	-- Ancien coffre "equipment_chest" — fallback identique au rare
	equipment_chest = {
		weights           = { money = 65, item = 30, reroll = 5 },
		money_range       = { min = 150, max = 500 },
		reroll_categories = {
			{ category = "art_spirituel",   weight = 40, amount = 1 },
			{ category = "style_de_combat", weight = 30, amount = 1 },
			{ category = "style_execution", weight = 20, amount = 1 },
			{ category = "reiatsu_color",   weight = 10, amount = 1 },
		},
	},
}

-- ============================================================================
-- DEFINITION DES COFFRES (lootbox) — 5 tiers
-- ============================================================================

EVO_LOOT.Chests = {
	["coffre_commun"] = {
		name = "Coffre Commun",
		description = "Un coffre basique contenant un equipement aleatoire",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/ualnv621fijxeq6i.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "common",
		bodygroup = 1,
		loot = BuildChestLootPool("commun"),
	},
	["coffre_rare"] = {
		name = "Coffre Rare",
		description = "Un coffre contenant un equipement de bonne qualite",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/106izg714ke4.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "rare",
		bodygroup = 2,
		loot = BuildChestLootPool("rare"),
	},
	["coffre_epique"] = {
		name = "Coffre Epique",
		description = "Un coffre precieux contenant un equipement puissant",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/zgzcshbyolkyp4i5o.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "epic",
		bodygroup = 3,
		loot = BuildChestLootPool("epique"),
	},
	["coffre_legendaire"] = {
		name = "Coffre Legendaire",
		description = "Un coffre tres rare contenant un equipement exceptionnel",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/yt01p52onca2hns.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "legendary",
		bodygroup = 4,
		loot = BuildChestLootPool("legendaire"),
	},
	["coffre_mythique"] = {
		name = "Coffre Mythique",
		description = "Le coffre ultime contenant les equipements les plus puissants",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/6np1c3kygusd0n.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "mythic",
		bodygroup = 5,
		loot = BuildChestLootPool("mythique"),
	},
	-- World boss : recompense top 5 du combat de boss mondial
	["coffre_world_boss"] = {
		name = "Coffre du Boss Mondial",
		description = "Recompense pour avoir vaincu un boss mondial (top 5 dommages)",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/6np1c3kygusd0n.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "mythic",
		bodygroup = 5,
		loot = BuildChestLootPool("mythique"),
	},
	-- Ancien coffre unique (conserve pour compatibilite)
	["equipment_chest"] = {
		name = "Coffre d'Equipement",
		description = "Un coffre contenant un equipement aleatoire",
		icon = "tgw7tau20hu4/yq5s4kdaudn9/106izg714ke4.png",
		model = "models/evo/props/items/evo_nltz5g51zk7t5lxs/evo_pi9pji7tt7esso4hk.mdl",
		rarity = "epic",
		loot = BuildChestLootPool("rare"),
	},
}

-- ============================================================================
-- POURCENTAGES DANS LA DESCRIPTION (demande user 2026-07-16) : chaque coffre
-- affiche ses probabilites REELLES quand on l'inspecte (tooltip inventaire /
-- shop Urahara = tout ce qui lit ITEMS[].description). Les % sont CALCULES
-- depuis EVO_LOOT.RewardConfig (source unique) -> impossible de desynchroniser
-- l'affichage d'un futur equilibrage des poids.
-- ============================================================================
local function ChestOddsText(chest_id)
	local rc = EVO_LOOT.RewardConfig and EVO_LOOT.RewardConfig[chest_id]
	if not rc or not istable(rc.weights) then return nil end
	local w = rc.weights
	local total = (tonumber(w.money) or 0) + (tonumber(w.item) or 0) + (tonumber(w.reroll) or 0)
	if total <= 0 then return nil end
	local function pct(x)
		local p = (tonumber(x) or 0) / total * 100
		if math.abs(p - math.Round(p)) < 0.05 then return string.format("%d%%", math.Round(p)) end
		return string.format("%.1f%%", p)
	end
	local lines = { "Contenu :" }
	if (tonumber(w.money) or 0) > 0 then
		local mr = rc.money_range or {}
		lines[#lines + 1] = string.format("- %s Argent (%s a %s yens)", pct(w.money), string.Comma(mr.min or 0), string.Comma(mr.max or 0))
	end
	if (tonumber(w.item) or 0) > 0 then
		lines[#lines + 1] = "- " .. pct(w.item) .. " Equipement"
	end
	if (tonumber(w.reroll) or 0) > 0 then
		lines[#lines + 1] = "- " .. pct(w.reroll) .. " Reroll (art / style / execution / couleur)"
	end
	return table.concat(lines, "\n")
end

for chest_id, chest in pairs(EVO_LOOT.Chests) do
	local odds = ChestOddsText(chest_id)
	if odds then
		chest.description = (chest.description or "") .. "\n\n" .. odds
	end
end

-- ============================================================================
-- Odds CANONIQUES pour "gagner un coffre aleatoire" (toute recompense du jeu).
-- Source unique de verite : utilise par EVO_LOOT.GiveRandomChest (sv_loot.lua)
-- pour que n'importe quel systeme puisse donner n'importe quel coffre avec ces
-- memes raretes, sans dupliquer la table. Cumul = 100.
-- ============================================================================
-- (07/24, demande user : hautes raretés RÉDUITES ; commun = le reste pour cumul = 100.)
EVO_LOOT.RANDOM_CHEST_WEIGHTS = {
	coffre_commun     = 63.5, -- le reste (100 - somme des autres)
	coffre_rare       = 30,
	coffre_epique     = 5,
	coffre_legendaire = 1,
	coffre_mythique   = 0.5,
}

-- ============================================================================
-- Odds "PNJ BASIQUES" (demande user 2026-07-23 : « vraiment difficile d'avoir
-- un coffre epique/legendaire/mythique sur les NPC de merde »). Utilisees par
-- les Hollows de la CHASSE (ncm_pnj sv_pnj_world_hunt) + le partage squad de ces
-- memes drops. Les hautes raretes restent l'apanage du world boss (ncm_world_boss,
-- table dediee), des quetes et des events.
-- (07/24, demande user « que tout soit plus dur » : hautes raretes RE-REDUITES +
-- chances de drop des Hollows halvees dans sv_pnj_world_hunt.) Commun = le reste
-- pour cumul = 100. Ordres de grandeur (grunt normal, desormais 1% de drop apres la
-- 2e halve du 07/27) :
--   epique ~1/10 000 kills · legendaire ~1/50 000 · mythique ~1/200 000.
-- ============================================================================
EVO_LOOT.TRASH_CHEST_WEIGHTS = {
	coffre_commun     = 72.75, -- le reste (100 - somme des autres)
	coffre_rare       = 26,
	coffre_epique     = 1,
	coffre_legendaire = 0.2,
	coffre_mythique   = 0.05,
}

-- ============================================================================
-- Enregistrement automatique dans ITEMS
-- (coffres + equipements)
-- ============================================================================

local function RegisterEvoLootItems()
	if not ITEMS then return false end

	-- Enregistrer les coffres
	-- On transfere `model` -> `model_path` + `bodygroup` pour que la preview 3D
	-- fonctionne dans les cases (urahara shop + inventaire). Le bouton "PREVIEW"
	-- du urahara shop est masque pour les is_lootbox (geree cote UI).
	for chest_id, chest in pairs(EVO_LOOT.Chests) do
		if not ITEMS[chest_id] then
			ITEMS[chest_id] = {
				name = chest.name,
				description = chest.description,
				icon = chest.icon,
				model_path = chest.model,
				bodygroup = chest.bodygroup,
				category = "object",
				rarity = chest.rarity or "common",
				is_lootbox = true,
				is_droppable = true,
				stack_max = EVO_LOOT.ChestStackMax,
			}
		else
			ITEMS[chest_id].is_lootbox = true
			ITEMS[chest_id].stack_max = ITEMS[chest_id].stack_max or EVO_LOOT.ChestStackMax
			if chest.model and (not ITEMS[chest_id].model_path or ITEMS[chest_id].model_path == "") then
				ITEMS[chest_id].model_path = chest.model
			end
			if chest.bodygroup ~= nil and ITEMS[chest_id].bodygroup == nil then
				ITEMS[chest_id].bodygroup = chest.bodygroup
			end
		end
	end

	-- Enregistrer aussi les equipements
	for equip_id, equip in pairs(EVO_LOOT.Equipment) do
		if not ITEMS[equip_id] then
			ITEMS[equip_id] = {
				name = equip.name,
				description = equip.description,
				icon = equip.icon,
				model_path = equip.model_path,
				bodygroup = equip.bodygroup,
				skin = equip.skin,
				category = equip.category,
				rarity = equip.rarity,
				stats = equip.stats,
				set_id = equip.set_id,
				slot = equip.slot,
				is_droppable = true,
			}
		else
			-- Mise à jour des champs visuels au cas où l'item existait déjà sans
			-- ces champs (hot-reload de la config / item pré-enregistré ailleurs).
			ITEMS[equip_id].model_path = equip.model_path or ITEMS[equip_id].model_path
			ITEMS[equip_id].bodygroup  = equip.bodygroup  or ITEMS[equip_id].bodygroup
			ITEMS[equip_id].skin       = equip.skin       or ITEMS[equip_id].skin
			-- Les STATS aussi, pour TOUS les sets : ce fichier est la seule source de ces
			-- items (aucun autre addon ne les définit), donc un rechargement à chaud ou le
			-- second passage du fallback doit reprendre le barème courant. Une version
			-- limitée au set Foudre (09/10) aurait laissé le piège aux autres sets.
			ITEMS[equip_id].stats      = equip.stats      or ITEMS[equip_id].stats
		end
	end

	-- local realm = SERVER and "SERVER" or "CLIENT"
	-- print("[EVO_LOOT] Items enregistres dans ITEMS (" .. realm .. ")")
	return true
end

-- Retry jusqu'a ce que ITEMS soit disponible (ordre de chargement des addons)
timer.Create("EVO_Loot_RegisterItems", 0.5, 20, function()
	if RegisterEvoLootItems() then
		timer.Remove("EVO_Loot_RegisterItems")
	end
end)

-- Fallback : hook Initialize (serveur) et InitPostEntity (client)
hook.Add("Initialize", "EVO_Loot_RegisterItemsInit", function()
	timer.Simple(0, function()
		RegisterEvoLootItems()
	end)
end)

hook.Add("InitPostEntity", "EVO_Loot_RegisterItemsFallback", function()
	timer.Simple(1, function()
		RegisterEvoLootItems()
	end)
end)
