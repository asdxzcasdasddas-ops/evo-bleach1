-- "addons\\inventory\\lua\\inventory\\cl_drop.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Dropped inventory props: optional sphere + floating item name (3D2D)
-- (World pickup hints live here; cl_item_preview_model.lua is only for bag/slot model panels.)

local FLOAT_BOB_AMP = 7 -- world units up/down
local FLOAT_BOB_SPEED = 2.6
local FLOAT_SCALE_PULSE = 0.06 -- ±6% scale breathing
local FLOAT_SWAY_DEG = 4 -- gentle roll on the label plane

-- Fonts FIXES (pas Inter:56 responsive) : en 3D2D une fonte HUD scale avec la
-- résolution *dans le monde*, et le suffixe " xN" d'une pile rendait le texte
-- énorme / cassé. `extended` = glyphes UTF-8 (accents, ★).
local FONT_NAME = "LZY_InvDropName"
local FONT_QTY = "LZY_InvDropQty"
local FONT_HINT = "LZY_InvDropHint"
local dropFontsReady = false
local function ensureDropFonts()
	if dropFontsReady then return end
	dropFontsReady = true
	surface.CreateFont(FONT_NAME, {
		font = "Inter 18pt", size = 48, weight = 600,
		antialias = true, extended = true,
	})
	surface.CreateFont(FONT_QTY, {
		font = "Inter 18pt", size = 34, weight = 700,
		antialias = true, extended = true,
	})
	surface.CreateFont(FONT_HINT, {
		font = "Inter 18pt", size = 28, weight = 500,
		antialias = true, extended = true,
	})
end

local function dropSphereRadius()
	return (INVENTORY_CONFIG and INVENTORY_CONFIG.DROP_VIS_SPHERE_RADIUS) or 80
end

local function dropPickupRadius()
	return (INVENTORY_CONFIG and INVENTORY_CONFIG.DROP_USE_RADIUS) or 72
end

local function playerInPickupRangeForDrop(lp, ent)
	if not IsValid(lp) or not IsValid(ent) or not lp:Alive() then return false end
	-- Miroir du refus serveur (net.lua, KeyPress) : en noclip le ramassage est
	-- bloqué sauf superadmin, donc pas de prompt qu'on ne peut pas suivre.
	if lp:GetMoveType() == MOVETYPE_NOCLIP and not lp:IsSuperAdmin() then return false end
	local rad = dropPickupRadius()
	local c = ent:LocalToWorld(ent:OBBCenter())
	return c:DistToSqr(lp:GetPos()) <= rad * rad
end

local function parseDropPayload(ent, raw)
	if not isstring(raw) then raw = "" end
	local itemId, key = raw, nil
	local a, b = string.match(raw, "^([^#]+)#(.+)$")
	if a then itemId, key = a, b end

	local name
	if itemId ~= "" and INVENTORY_CONFIG and INVENTORY_CONFIG.GetItemDisplayName then
		name = INVENTORY_CONFIG.GetItemDisplayName(itemId, nil, key)
	end
	if (not name or name == "") and ITEMS and ITEMS[itemId] then
		name = ITEMS[itemId].name
	end
	-- Anciens drops : le NW portait encore le libellé FR ("Nom x3"), pas un item_id.
	local qty
	if not (ITEMS and ITEMS[itemId]) then
		local legacy, n = string.match(raw, "^(.*)\x1E(%d+)$")
		if not legacy then legacy, n = string.match(raw, "^(.*) x(%d+)$") end
		if legacy and legacy ~= "" then
			name = legacy
			qty = tonumber(n)
		elseif raw ~= "" then
			name = raw
		end
	end
	if not qty then
		local skin = IsValid(ent) and ent:GetSkin() or 0
		if ITEMS and ITEMS[itemId] and skin >= 1 then
			qty = skin
		else
			qty = 1
		end
	end
	return name, qty
end

local function outlinedText(text, font, x, y, col, outlineCol, outline)
	outline = outline or 2
	local oc = outlineCol or Color(0, 0, 0, 220)
	for dx = -outline, outline, outline do
		for dy = -outline, outline, outline do
			if dx ~= 0 or dy ~= 0 then
				draw.SimpleText(text, font, x + dx, y + dy, oc, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			end
		end
	end
	draw.SimpleText(text, font, x, y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
end

-- « ×N » mis en cache (aucune concat par frame).
local tQtyText = {}
local function qtyText(n)
	local s = tQtyText[n]
	if not s then s = "×" .. n tQtyText[n] = s end
	return s
end

local function drawDropLabel(ent, rawLabel)
	local label, qty = parseDropPayload(ent, rawLabel)
	if not label or label == "" then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	ensureDropFonts()

	local t = CurTime()
	local phase = ent:EntIndex() * 0.37 + ent:MapCreationID() * 0.02
	local bob = math.sin(t * FLOAT_BOB_SPEED + phase) * FLOAT_BOB_AMP
		+ math.sin(t * (FLOAT_BOB_SPEED * 0.47) + phase * 1.3) * (FLOAT_BOB_AMP * 0.22)

	-- World-up only: stay above entity origin; lift is rotation-invariant (physics
	-- roll does not move the anchor along the prop's local axes).
	local rad = ent:BoundingRadius()
	if not rad or rad < 1 then
		local sz = ent:OBBMaxs() - ent:OBBMins()
		rad = sz:Length() * 0.5
	end
	local p = ent:GetPos()
	local top = Vector(p.x, p.y, p.z + rad + 8 + bob)

	local sway = math.sin(t * 1.9 + phase * 0.8) * FLOAT_SWAY_DEG
	-- Billboard face à la CAMÉRA RÉELLE (EyePos), pas à l'aim du joueur : la caméra orbitale gèle
	-- EyeAngles (découplé de la vue), donc l'ancien lp:EyeAngles().y laissait l'écriture de travers
	-- quand la cam orbitait. (top - EyePos()) suit la vraie caméra dans tous les cas — orbitale OU
	-- normale (chaque label se tourne individuellement vers la cam). Même patron que le billboard drapeau.
	local ang = Angle(0, (top - EyePos()):Angle().y - 90, 90 + sway)

	local scale = 0.12 * (1 + math.sin(t * 2.2 + phase) * FLOAT_SCALE_PULSE)
	local font = "Inter:56"
	local hintFont = "Inter:36"
	-- Pas de hint pendant qu'on mange/boit (prédicat central evo_science).
	local bEating = EVO_SCIENCE and EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy()
	local bPickup = (not bEating) and playerInPickupRangeForDrop(lp, ent)
	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		-- Style invite partage : nom, touche + « Ramasser » a portee, quantite en 3e ligne.
		local bQty = qty and qty > 1
		cam.Start3D2D(top, ang, scale)
			EVO_ZonePrompt.Row(bQty and -110 or -60, label, bPickup and "Ramasser",
				bPickup and LZY_INVENTORY_GetUseKeyDisplay() or "E", "coffre", bQty and qtyText(qty) or nil)
		cam.End3D2D()
		return
	end
	local pickupHint = bPickup
		and string.format("Appuyez sur %s pour ramasser", LZY_INVENTORY_GetUseKeyDisplay())
		or nil

	cam.Start3D2D(top, ang, scale)
		surface.SetFont(FONT_NAME)
		local _, nameH = surface.GetTextSize(label)
		local qtyH, qtyGap = 0, 0
		if qty and qty > 1 then
			surface.SetFont(FONT_QTY)
			_, qtyH = surface.GetTextSize("×" .. qty)
			qtyGap = 8
		end
		local y = 0
		outlinedText(label, FONT_NAME, 0, y, Color(255, 255, 255), Color(0, 0, 0, 220), 2)
		if qty and qty > 1 then
			y = y - nameH - qtyGap
			outlinedText("×" .. qty, FONT_QTY, 0, y, Color(255, 220, 140), Color(0, 0, 0, 220), 2)
		end
		if pickupHint then
			y = y - ((qty and qty > 1) and qtyH or nameH) - 10
			outlinedText(pickupHint, FONT_HINT, 0, y, Color(200, 220, 255), Color(0, 0, 0, 200), 1)
		end
	cam.End3D2D()
end

-- Cache des props droppées proches : le ents.FindInSphere ne tourne plus CHAQUE
-- frame (c'etait le seul vrai cout permanent), mais ~4x/s. Entre deux scans on
-- reutilise la liste (typiquement vide) et on redessine aux positions courantes.
local DROP_SCAN_INTERVAL = 0.25
local nNextDropScan = 0
local tCachedDrops = {}

hook.Add("PostDrawTranslucentRenderables", "LZY_InventoryDropDraw", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local cfg = INVENTORY_CONFIG
	if not cfg then return end

	local maxDist = 900
	local maxDistSq = maxDist * maxDist
	local lpPos = lp:GetPos()

	-- Rescan throttlé (capture jusqu'à maxDist+200 pour anticiper l'approche).
	local now = CurTime()
	if now >= nNextDropScan then
		nNextDropScan = now + DROP_SCAN_INTERVAL
		tCachedDrops = {}
		local scan = ents.FindInSphere(lpPos, maxDist + 200)
		for i = 1, #scan do
			local e = scan[i]
			if IsValid(e) and e:GetClass() == "prop_physics" and e:GetEvoNWBool("LZY_InventoryDropped") then
				tCachedDrops[#tCachedDrops + 1] = e
			end
		end
	end

	if #tCachedDrops == 0 then return end -- cas normal : rien au sol -> 0 rendu

	for i = 1, #tCachedDrops do
		local e = tCachedDrops[i]
		-- Re-check par frame : validité (ramassé = retiré) + portée 900u exacte.
		if IsValid(e) and e:GetEvoNWBool("LZY_InventoryDropped") and e:GetPos():DistToSqr(lpPos) <= maxDistSq then
			drawDropLabel(e, e:GetEvoNWString("LZY_InventoryDropName"))

			-- Uncomment for wireframe pickup sphere:
			-- local rad = dropSphereRadius()
			-- local c = e:LocalToWorld(e:OBBCenter())
			-- render.DrawWireframeSphere(c, rad, 16, 16, Color(120, 200, 255, 100), true)
		end
	end
end)
