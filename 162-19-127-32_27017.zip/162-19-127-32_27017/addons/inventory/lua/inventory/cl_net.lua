-- "addons\\inventory\\lua\\inventory\\cl_net.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local inventory = {
	items = {},
	equipped_items = {},
	durability = {}
}

local function normalizeClientBag(tbl)
	local max = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
	local out = {}
	if not istable(tbl) then
		for i = 1, max do out[i] = false end
		return out
	end
	for i = 1, max do
		-- JSON peut renvoyer des clés string ("5") : lire les deux formes.
		local v = tbl[i]
		if v == nil then v = tbl[tostring(i)] end
		out[i] = (isstring(v) and v ~= "") and v or false
	end
	return out
end

-- Player Meta --

local metaPlayer = FindMetaTable("Player")

function metaPlayer:GetInventory()
	return table.Copy(inventory)
end

function metaPlayer:GetInventoryItems()
	local max = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
	local dense = {}
	for i = 1, max do
		local v = inventory.items[i]
		if isstring(v) and v ~= "" then
			dense[#dense + 1] = v
		end
	end
	return dense
end

--- Unités d'un item_id dans le sac (piles comprises). Lit le cache LIVE —
--- GetInventory() renvoie une copie, à ne pas utiliser pour compter.
function metaPlayer:CountInventoryItem(item_id)
	if not isstring(item_id) or item_id == "" then return 0 end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.CountBagItem then
		return INVENTORY_CONFIG.CountBagItem(inventory, item_id)
	end
	return 0
end

--- Parcourt le sac LIVE : fn(slot, item_id, quantity).
function metaPlayer:ForEachBagSlot(fn)
	if not isfunction(fn) then return end
	local max = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
	for i = 1, max do
		local id = inventory.items[i]
		if isstring(id) and id ~= "" then
			local q = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inventory, i) or 1
			fn(i, id, q)
		end
	end
end

function metaPlayer:GetInventoryEquippedItems()
	return table.Copy(inventory.equipped_items)
end

-- Network --

-- Defer heavy Decompress/JSON while Chargement… is open (character.Load race).
local function LZY_Inventory_ApplySyncPayload(hasItems, itemsData, hasEquipped, eqData, durData, enchData, keyData, qtyData)
	if hasItems then
		local itemsJson = itemsData and util.Decompress(itemsData) or "[]"
		local itemsTbl = util.JSONToTable(itemsJson) or {}
		inventory.items = normalizeClientBag(itemsTbl)
	end

	if hasEquipped then
		local eqJson = eqData and util.Decompress(eqData) or "[]"
		local eqTbl = util.JSONToTable(eqJson) or {}

		-- Convert array format to object format if needed
		-- JSON parsers sometimes convert {"1":"item"} to ["item"] if keys are sequential
		if istable(eqTbl) then
			local hasNumericKeys = false
			local hasStringKeys = false
			local maxNumericKey = 0

			for k, v in pairs(eqTbl) do
				if type(k) == "number" then
					hasNumericKeys = true
					if k > maxNumericKey then
						maxNumericKey = k
					end
				elseif type(k) == "string" then
					hasStringKeys = true
				end
			end

			if hasNumericKeys and not hasStringKeys then
				local converted = {}
				for i, itemId in ipairs(eqTbl) do
					if itemId then
						converted[tostring(i)] = itemId
					end
				end
				for k, v in pairs(eqTbl) do
					if type(k) == "number" and v and not converted[tostring(k)] then
						converted[tostring(k)] = v
					end
				end
				eqTbl = converted
			end
		end

		inventory.equipped_items = (INVENTORY_CONFIG and INVENTORY_CONFIG.NormalizeEquippedKeysForClient and INVENTORY_CONFIG.NormalizeEquippedKeysForClient(eqTbl)) or
			eqTbl
	end

	local durJson = durData and util.Decompress(durData) or "{}"
	local durTbl = util.JSONToTable(durJson) or {}
	local durOut = {}
	if istable(durTbl) then
		for k, v in pairs(durTbl) do
			local nk = tonumber(k) or k
			local nv = tonumber(v)
			if nv then
				durOut[nk] = math.Clamp(nv, 0, 100)
			end
		end
	end
	inventory.durability = durOut

	-- Enchantements par slot ("stat:pct;...") : lus par le tooltip d'inventaire.
	local enchJson = enchData and util.Decompress(enchData) or "{}"
	local enchTbl = util.JSONToTable(enchJson) or {}
	local enchOut = {}
	if istable(enchTbl) then
		for k, v in pairs(enchTbl) do
			local nk = tonumber(k)
			if nk and isstring(v) and v ~= "" then
				enchOut[nk] = v
			end
		end
	end
	inventory.enchants = enchOut

	-- instance_key par slot (documents).
	local keyJson = keyData and util.Decompress(keyData) or "{}"
	local keyTbl = util.JSONToTable(keyJson) or {}
	local keyOut = {}
	if istable(keyTbl) then
		for k, v in pairs(keyTbl) do
			local nk = tonumber(k)
			if nk and isstring(v) and v ~= "" then
				keyOut[nk] = v
			end
		end
	end
	inventory.instance_keys = keyOut

	local qtyJson = qtyData and util.Decompress(qtyData) or "{}"
	local qtyTbl = util.JSONToTable(qtyJson) or {}
	local qtyOut = {}
	if istable(qtyTbl) then
		for k, v in pairs(qtyTbl) do
			local nk = tonumber(k)
			local nv = math.floor(tonumber(v) or 0)
			if nk and nv > 1 then qtyOut[nk] = nv end
		end
	end
	inventory.quantities = qtyOut

	hook.Run("LZY_Inventory_Synced", inventory.items, inventory.equipped_items)
end

-- Seq : si plusieurs Sync arrivent pendant l'écran de chargement, seul le DERNIER
-- s'applique à la fermeture (évite un sync shinai-seul qui écrase shinai+katana).
local _lzyInvSyncSeq = 0

net.Receive("client:inventory.Sync", function()
	local hasItems = net.ReadBool()
	local itemsData = nil
	if hasItems then
		local itemsLen = net.ReadUInt(32)
		itemsData = itemsLen > 0 and net.ReadData(itemsLen) or nil
	end

	local hasEquipped = net.ReadBool()
	local eqData = nil
	if hasEquipped then
		local eqLen = net.ReadUInt(32)
		eqData = eqLen > 0 and net.ReadData(eqLen) or nil
	end

	local durLen = net.ReadUInt(32)
	local durData = durLen > 0 and net.ReadData(durLen) or nil

	local enchLen = net.ReadUInt(32)
	local enchData = enchLen > 0 and net.ReadData(enchLen) or nil

	local keyLen = net.ReadUInt(32)
	local keyData = keyLen > 0 and net.ReadData(keyLen) or nil

	local qtyLen = net.ReadUInt(32)
	local qtyData = qtyLen > 0 and net.ReadData(qtyLen) or nil

	_lzyInvSyncSeq = _lzyInvSyncSeq + 1
	local seq = _lzyInvSyncSeq

	local function apply()
		if seq ~= _lzyInvSyncSeq then return end
		LZY_Inventory_ApplySyncPayload(hasItems, itemsData, hasEquipped, eqData, durData, enchData, keyData, qtyData)
	end

	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		-- Reçu = OK pour fermer Chargement… ; apply toujours différé (anti-hitch).
		if LZY_Character_MarkLoadingReadyFlag then
			LZY_Character_MarkLoadingReadyFlag("inv")
		end
		hook.Add("EVO:Client:LoadingScreenClosed", "LZY:InvSyncAfterLoading", function()
			hook.Remove("EVO:Client:LoadingScreenClosed", "LZY:InvSyncAfterLoading")
			timer.Simple(0, apply)
		end)
		return
	end
	apply()
	if LZY_Character_MarkLoadingReadyFlag then
		LZY_Character_MarkLoadingReadyFlag("inv")
	end
end)

-- net to clear inventory cached
net.Receive("EVO:Client:Inventory.ClearCache", function()
	-- Clear cached inventory data
	inventory.items = {}
	inventory.equipped_items = {}
	inventory.durability = {}
	inventory.enchants = {}
	inventory.instance_keys = {}
	inventory.quantities = {}

	-- Notify that inventory was cleared
	hook.Run("LZY_Inventory_Cleared", inventory.items, inventory.equipped_items)
end)

-- Filet désync SWEP : le katana à la hanche (EVO_SheathedKatana) et le slot inventaire
-- peuvent rester équipés alors que citron_combat_weapons a disparu de GetWeapons()
-- (AFK ~30 min / snapshot manqué). Le sélecteur ne liste que GetWeapons() -> arme
-- invisible jusqu'à un reconnect. On demande au serveur de recréer le SWEP.
local COMBAT_WEP_CLASS = { citron_combat_weapons = true, citron_shinai_weapons = true }
local _lzyInvWepResyncAt = 0

local function clientHasCombatWeapon(ply)
	for _, w in ipairs(ply:GetWeapons()) do
		if IsValid(w) and COMBAT_WEP_CLASS[w:GetClass()] then return true end
	end
	return false
end

local function clientShouldHaveCombatWeapon(ply)
	if ply:GetEvoNWBool("InCharacterMenu", false) then return false end
	if ply:GetEvoNWBool("EVO_IsLarva", false) then return false end
	-- Injured / menottes / KO / carry : ne pas demander de re-Give (ForceSheathe s'en charge).
	if ply:GetEvoNWBool("EVO::IsInjured", false) then return false end
	if ply:GetEvoNWBool("EVO_Handcuffed", false) then return false end
	if ply:GetEvoNWBool("EVO_IsKO", false) then return false end
	if ply.IsCarrying and ply:IsCarrying() then return false end
	if ply.IsCarryied and ply:IsCarryied() then return false end
	if ply:GetEvoNWString("EVO_SheathedKatana", "") ~= "" then return true end
	if ply:GetEvoNWString("NCM_HakudaGauntlet", "") ~= "" then return true end
	local kid = inventory.equipped_items and inventory.equipped_items["katana"]
	return isstring(kid) and kid ~= ""
end

function LZY_Inventory_TryResyncMissingCombatWeapon()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
	if not clientShouldHaveCombatWeapon(lp) then return end
	if clientHasCombatWeapon(lp) then return end
	local now = RealTime()
	if now < _lzyInvWepResyncAt then return end
	_lzyInvWepResyncAt = now + 8
	net.Start("server:inventory.ResyncCombatWeapon")
	net.SendToServer()
end

timer.Create("LZY_Inv_CombatWepResync", 1, 0, LZY_Inventory_TryResyncMissingCombatWeapon)
