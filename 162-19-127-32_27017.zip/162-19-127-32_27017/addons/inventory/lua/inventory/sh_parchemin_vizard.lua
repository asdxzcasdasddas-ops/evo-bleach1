-- "addons\\inventory\\lua\\inventory\\sh_parchemin_vizard.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- =====================================================================
-- Parchemin du VIZARD
-- Objet d'inventaire qui DÉBLOQUE la maîtrise du Masque Hollow.
-- Voie normale = DEUX verrous (demande user, « en plus de ça ») :
--   1) ÉLIGIBILITÉ : avoir réussi la chaîne de progression « Maître de l'Ombre »
--      (niveau 120 + grade 10 + quêtes) -> flag EVO_HollowEligible.
--   2) PARCHEMIN  : un membre du staff remet ce parchemin (getitem parchemin_vizard) ;
--      l'utiliser (si éligible + Shinigami) débloque réellement le masque + ouvre le
--      choix du pouvoir, puis consomme le parchemin.
-- La commande admin hollowmask_unlock reste un override total (sans parchemin).
-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm.
-- =====================================================================

ITEMS = ITEMS or {}

ITEMS["parchemin_vizard"] = {
	name        = "Parchemin du Vizard",
	description = "Scelle le Hollow qui sommeille en toi. À utiliser pour maîtriser le Masque Hollow — réservé aux Shinigami ayant survécu à l'épreuve du Maître de l'Ombre. Choisis ensuite ton pouvoir.",
	-- PNG parchemin générique = REPLI hors preview 3D.
	icon        = "1bhn2d03mwm1/parchemin.png",
	icon_scale  = 0.6,
	-- Rendu 3D dans la case (au lieu du PNG, demande user) : modèle parchemin commun, variante
	-- MYTHIQUE. Le modèle porte ses variantes en SKINS 0..4 (4 = mythique), cf. parchemins technique.
	model_path  = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl",
	skin        = 4,
	category    = "object",
	rarity      = "mythic",
	-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm
	-- via claim -> trade -> reclaim, ni de doublon.
	is_droppable = false,
	is_deletable = false,
	is_vizard_scroll = true,
	on_use = function(ply)
		-- Déblocage + consommation strictement serveur.
		if not SERVER then return end
		if not IsValid(ply) then return end
		if not (HollowMask and HollowMask.Unlock) then return end -- addon citron_hollow_mask absent

		-- Réservé aux Shinigami (le masque l'est aussi pour le moment).
		if ply:GetEvoNWString("FactionName", "") ~= "Shinigami" then
			MUGEN.Notify(ply, "Seuls les Shinigami peuvent maîtriser le Masque Hollow.", NOTIFY_ERROR, 4)
			return
		end

		-- Déjà maîtrisé : on ne consomme PAS le parchemin.
		if ply:GetEvoNWBool("EVO_HollowMaskUnlocked", false) then
			MUGEN.Notify(ply, "Tu maîtrises déjà le Masque Hollow.", NOTIFY_ERROR, 4)
			return
		end

		-- 1er verrou : éligibilité (chaîne « Maître de l'Ombre » accomplie). Le parchemin
		-- vient EN PLUS de la quête -> sans la quête, il ne fait rien et n'est pas consommé.
		if not (HollowMask.IsEligible and HollowMask.IsEligible(ply)) then
			MUGEN.Notify(ply, "Tu dois d'abord réussir l'épreuve du Maître de l'Ombre.", NOTIFY_ERROR, 5)
			return
		end

		-- 2e verrou franchi : débloque réellement le masque + ouvre le choix du pouvoir,
		-- puis consomme le parchemin. Échec de persistance (pas de perso chargé) -> on ne
		-- consomme PAS : le parchemin est irremplaçable (remis par le staff).
		if not HollowMask.Unlock(ply) then
			MUGEN.Notify(ply, "Impossible pour le moment, réessaie dans un instant.", NOTIFY_ERROR, 4)
			return
		end
		ply:RemoveItem("parchemin_vizard", function() end)
	end,
}
