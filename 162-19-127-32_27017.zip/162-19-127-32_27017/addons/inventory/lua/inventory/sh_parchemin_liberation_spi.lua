-- "addons\\inventory\\lua\\inventory\\sh_parchemin_liberation_spi.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- =====================================================================
-- Parchemin de LIBÉRATION SPIRITUELLE (transformation faction HOLLOW)
-- Équivalent Hollow du Parchemin du Vizard. DÉBLOQUE la maîtrise de la
-- Libération Spirituelle (addon citron_liberation_spi).
-- Voie normale = DEUX verrous (« en plus de ça ») :
--   1) ÉLIGIBILITÉ : avoir réussi la chaîne de progression Hollow « Maître du Néant »
--      -> flag EVO_LiberationSpiEligible.
--   2) PARCHEMIN  : un membre du staff remet ce parchemin (getitem parchemin_liberation_spirituelle) ;
--      l'utiliser (si éligible + Hollow) débloque réellement la libération + ouvre le choix
--      du pouvoir, puis consomme le parchemin.
-- La commande admin liberation_spi_unlock reste un override total (sans parchemin).
-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm.
-- =====================================================================

ITEMS = ITEMS or {}

ITEMS["parchemin_liberation_spirituelle"] = {
	name        = "Parchemin de Libération Spirituelle",
	description = "Brise les chaînes scellant ta vraie nature. À utiliser pour maîtriser la Libération Spirituelle — réservé aux Hollow ayant survécu à l'épreuve du Maître du Néant. Choisis ensuite ton pouvoir.",
	-- PNG parchemin générique = REPLI hors preview 3D.
	icon        = "1bhn2d03mwm1/parchemin.png",
	icon_scale  = 0.6,
	-- Rendu 3D dans la case (au lieu du PNG, demande user) : modèle parchemin commun, variante
	-- MYTHIQUE. Le modèle porte ses variantes en SKINS 0..4 (4 = mythique), cf. parchemins technique.
	model_path  = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl",
	skin        = 4,
	category    = "object",
	rarity      = "mythic",
	-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm.
	is_droppable = false,
	is_deletable = false,
	is_liberation_spi_scroll = true,
	on_use = function(ply)
		-- Déblocage + consommation strictement serveur.
		if not SERVER then return end
		if not IsValid(ply) then return end
		if not (LiberationSpi and LiberationSpi.Unlock) then return end -- addon citron_liberation_spi absent

		-- Réservé à la faction Hollow (la libération l'est aussi).
		if ply:GetEvoNWString("FactionName", "") ~= "Hollow" then
			MUGEN.Notify(ply, "Seuls les Hollow peuvent maîtriser la Libération Spirituelle.", NOTIFY_ERROR, 4)
			return
		end

		-- Déjà maîtrisée : on ne consomme PAS le parchemin.
		if ply:GetEvoNWBool("EVO_LiberationSpiUnlocked", false) then
			MUGEN.Notify(ply, "Tu maîtrises déjà ta Libération Spirituelle.", NOTIFY_ERROR, 4)
			return
		end

		-- 1er verrou : éligibilité (chaîne « Maître du Néant » accomplie). Le parchemin vient
		-- EN PLUS de la quête -> sans la quête, il ne fait rien et n'est pas consommé.
		if not (LiberationSpi.IsEligible and LiberationSpi.IsEligible(ply)) then
			MUGEN.Notify(ply, "Tu dois d'abord réussir l'épreuve du Maître du Néant.", NOTIFY_ERROR, 5)
			return
		end

		-- 2e verrou franchi : débloque réellement la libération + ouvre le choix du pouvoir,
		-- puis consomme le parchemin. Échec de persistance (pas de perso chargé) -> on ne
		-- consomme PAS : le parchemin est irremplaçable (remis par le staff).
		if not LiberationSpi.Unlock(ply) then
			MUGEN.Notify(ply, "Impossible pour le moment, réessaie dans un instant.", NOTIFY_ERROR, 4)
			return
		end
		ply:RemoveItem("parchemin_liberation_spirituelle", function() end)
	end,
}
