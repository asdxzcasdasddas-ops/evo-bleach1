-- "addons\\inventory\\lua\\inventory\\cl_item_tooltip.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Inventory and trade share this renderer and its item detail sections.
return function(self, helpers)
	local InventoryCollectSetTooltipText = helpers.InventoryCollectSetTooltipText
	local InventoryCollectStatsTooltipLines = helpers.InventoryCollectStatsTooltipLines
	local InventoryClientDurabilityPercent = helpers.InventoryClientDurabilityPercent
	local InvTooltipDescDrawHeight = helpers.InvTooltipDescDrawHeight
	local InvSplitDescNewlines = helpers.InvSplitDescNewlines
	local GetRarityTierTextColor = helpers.GetRarityTierTextColor
	function self:HideItemDescriptionTooltip()
		if IsValid(self._itemDescTooltip) then
			self._itemDescTooltip:Remove()
			self._itemDescTooltip = nil
		end
	end

	function self:ShowItemDescriptionTooltip(itemId, hoverPanel, context)
		self:HideItemDescriptionTooltip()
		local data = ITEMS and ITEMS[itemId]
		if not data then return end
		local inv = (context and context.inventory) or (LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil)
		local sid = (context and context.slot) or (IsValid(hoverPanel) and hoverPanel._invDbSlotId)
		local desc = (INVENTORY_CONFIG.GetItemDescription and INVENTORY_CONFIG.GetItemDescription(itemId, sid, inv)) or (isstring(data.description) and data.description or "")

		-- Ligne dynamique optionnelle (ex. carcasse de Hollow : temps restant avant évaporation)
		if isfunction(data.dynamic_description) then
			local ok, extra = pcall(data.dynamic_description)
			if ok and isstring(extra) and extra ~= "" then
				desc = desc ~= "" and (desc .. "\n" .. extra) or extra
			end
		end

		-- État du SET (evo_loot) : pièces équipées + bonus, marqué ACTIF quand complet.
		-- Injecté dans la description -> wrap/mesure par la machinerie existante du tooltip.
		local setText = InventoryCollectSetTooltipText(data)
		if setText then
			desc = desc ~= "" and (desc .. "\n" .. setText) or setText
		end

		-- Niveau de forge + multiplicateur stats (accessoire avec stats — voir ncm_forge addon).
		local lvlLine
		local forge_mult = 1.0
		if data.category == "accessory" and istable(data.stats) and NCM_FORGE and NCM_FORGE.GetClientLevel then
			if sid then
				local lvl = context and context.remote and (inv.forge_levels and inv.forge_levels[sid] or 1) or NCM_FORGE.GetClientLevel(sid)
				local maxLvl = NCM_FORGE.MAX_LEVEL or 20
				lvlLine = string.format("Niveau: %d / %d", lvl, maxLvl)
				if NCM_FORGE.GetStatMultiplier then
					forge_mult = NCM_FORGE.GetStatMultiplier(lvl) or 1.0
				end
			end
		end

		local statsLines = InventoryCollectStatsTooltipLines(data, forge_mult)
		local durLine
		if data.has_durability then
			local pct
			if context and context.remote then
				pct = inv.durability and inv.durability[sid]
			else
				pct = sid and InventoryClientDurabilityPercent(sid) or 100
			end
			if pct ~= nil then durLine = string.format("Durabilité: %.1f%%", pct) end
		end

		-- État de CET exemplaire (ex. masque médical stérile/usé/contaminé) :
		-- l'item fournit tooltip_state(sid, inv) -> texte, couleur.
		local stateLine, stateCol
		if isfunction(data.tooltip_state) then
			local ok, txt, col = pcall(data.tooltip_state, sid, inv)
			if ok and isstring(txt) and txt ~= "" then
				stateLine = txt
				stateCol = IsColor(col) and col or Color(200, 210, 255, 255)
			end
		end

		-- Enchantements gravés sur CET exemplaire (atelier Combat) : cache client
		-- syncé par client:inventory.Sync, lignes colorées par boost.
		local enchTipLines = {}
		do
			if sid and INVENTORY_CONFIG.ParseEnchantList then
				local m = inv and inv.enchants
				local raw = istable(m) and (m[sid] or m[tonumber(sid)]) or nil
				if EVO_CRAFT and EVO_CRAFT.EnchantMigrateString then
					raw = EVO_CRAFT.EnchantMigrateString(raw, itemId)
				end
				for _, e in ipairs(INVENTORY_CONFIG.ParseEnchantList(raw)) do
					local def = EVO_CRAFT and EVO_CRAFT.EnchantByKey and EVO_CRAFT.EnchantByKey(e.stat)
					-- Valeur FORGÉE (09/19) : le recalcul des stats multiplie la gravure par le
					-- niveau de forge, comme les stats de base affichées au-dessus. La valeur
					-- gravée reste entre parenthèses pour que les deux chiffres se comprennent.
					local sVal = string.format("+%.2f%%", e.pct * forge_mult)
					if forge_mult > 1.001 then
						sVal = sVal .. string.format(" (gravé +%.2f%%)", e.pct)
					end
					if e.stat == "flashstep_cd" then
						desc = desc .. "\nGravures de recharge shunpo : plafond cumulé de 40%, combiné séparément avec le set."
					end
					enchTipLines[#enchTipLines + 1] = {
						txt = sVal .. " " .. ((def and def.label) or e.stat),
						col = (def and def.color) or Color(216, 185, 106),
					}
				end
			end
		end

		if desc == "" and #statsLines == 0 and not durLine and not stateLine and not lvlLine and #enchTipLines == 0 and not (context and context.showNameOnly) then return end

		-- Match glibs responsive.lua design resolution (for gRespDrawMultilineText x/y).
		local BASE_WIDTH, BASE_HEIGHT = 1920, 1080

		local maxTipW = math.min(gRespX(340), ScrW() - 24)
		local pad = gRespX(10)
		local maxInner = math.max(8, maxTipW - pad * 2)
		local nameFont = "Avenir Next World:22"
		local descFont = "Avenir Next World:18"
		-- Line spacing inside wrapped description (gGetMultilineTextSize / gRespDrawMultilineText).
		local descLineGap = gRespY(20)
		local statsLineGap = gRespY(4)
		local sectionGap = gRespY(8)
		local statsHeader = "Statistiques"
		local statAccent = Color(140, 200, 160, 255)
		local statHeaderColor = Color(180, 210, 255, 255)

		local nameText = (INVENTORY_CONFIG.GetItemDisplayName and INVENTORY_CONFIG.GetItemDisplayName(itemId, sid, inv)) or (data.name or itemId)
		local qTip = (context and context.quantity) or (INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inv, sid) or 1)
		if qTip > 1 then nameText = nameText .. " x" .. qTip end
		surface.SetFont(nameFont)
		local nameW, nameH = surface.GetTextSize(nameText)

		local rarityPrefix = "Rareté: "
		local rarityTierLabel
		local rarityVal = (INVENTORY_CONFIG.GetItemRarity and INVENTORY_CONFIG.GetItemRarity(itemId, sid, inv)) or data.rarity
		if isstring(rarityVal) and rarityVal ~= "" then
			local r = string.lower(rarityVal)
			rarityTierLabel = r:sub(1, 1):upper() .. r:sub(2)
		end
		local rarityText = rarityTierLabel and (rarityPrefix .. rarityTierLabel) or nil

		local rarityW, rarityH = 0, 0
		if rarityText then
			surface.SetFont(descFont)
			rarityW, rarityH = surface.GetTextSize(rarityText)
		end

		local durW, durH = 0, 0
		if durLine then
			surface.SetFont(descFont)
			durW, durH = surface.GetTextSize(durLine)
		end

		local stateW, stateH = 0, 0
		if stateLine then
			surface.SetFont(descFont)
			stateW, stateH = surface.GetTextSize(stateLine)
		end

		local lvlW, lvlH = 0, 0
		if lvlLine then
			surface.SetFont(descFont)
			lvlW, lvlH = surface.GetTextSize(lvlLine)
		end

		-- Bloc enchantements : en-tête en descFont + lignes en StatBoldItalic,
		-- mesurés chacun avec leur fonte (même recette que le bloc stats).
		local enchHeaderText = #enchTipLines > 1 and "Enchantements" or "Enchantement"
		local enchHeaderH, enchBlockH, enchMaxW = 0, 0, 0
		if #enchTipLines > 0 then
			surface.SetFont(descFont)
			enchMaxW = select(1, surface.GetTextSize(enchHeaderText))
			enchHeaderH = select(2, surface.GetTextSize(enchHeaderText))
			enchBlockH = enchHeaderH + gRespY(4)
			surface.SetFont("LZY_Inventory_StatBoldItalic")
			for i, l in ipairs(enchTipLines) do
				enchMaxW = math.max(enchMaxW, select(1, surface.GetTextSize(l.txt)))
				enchBlockH = enchBlockH + select(2, surface.GetTextSize(l.txt))
				if i < #enchTipLines then
					enchBlockH = enchBlockH + gRespY(4)
				end
			end
		end

		local statsMaxW = 0
		if #statsLines > 0 then
			-- En-tête "Statistiques" dessiné en descFont, lignes en StatBoldItalic :
			-- on mesure chaque partie avec sa propre fonte pour dimensionner la boîte.
			surface.SetFont(descFont)
			statsMaxW = math.max(statsMaxW, select(1, surface.GetTextSize(statsHeader)))
			surface.SetFont("LZY_Inventory_StatBoldItalic")
			for _, ln in ipairs(statsLines) do
				statsMaxW = math.max(statsMaxW, select(1, surface.GetTextSize(ln)))
			end
		end

		local innerW, descH
		local naturalDescW = 0

		if desc ~= "" then
			if gGetMultilineTextSize then
				naturalDescW = select(1, gGetMultilineTextSize(desc, descFont, descLineGap, nil))
				local innerNeeded = math.max(nameW, rarityW, durW, stateW, lvlW, enchMaxW, naturalDescW, statsMaxW, 8)
				if innerNeeded <= maxInner then
					innerW = innerNeeded
					descH = InvTooltipDescDrawHeight(InvSplitDescNewlines(desc), descFont, descLineGap)
				else
					innerW = maxInner
					descH = InvTooltipDescDrawHeight(splitText(desc, descFont, innerW), descFont, descLineGap)
				end
			else
				surface.SetFont(descFont)
				local naturalLines = string.Explode("\n", desc)
				local ndw = 0
				for _, line in ipairs(naturalLines) do
					ndw = math.max(ndw, select(1, surface.GetTextSize(line)))
				end
				local innerNeeded = math.max(nameW, rarityW, durW, stateW, lvlW, enchMaxW, ndw, statsMaxW, 8)
				if innerNeeded <= maxInner then
					innerW = innerNeeded
				else
					innerW = maxInner
				end
				local lines = splitText and splitText(desc, descFont, innerW) or string.Explode("\n", desc)
				descH = InvTooltipDescDrawHeight(lines, descFont, descLineGap)
			end
		else
			descH = 0
			innerW = math.min(maxInner, math.max(nameW, rarityW, durW, stateW, lvlW, enchMaxW, statsMaxW, 8))
		end

		local statsHeaderH = 0
		local statsBlockH = 0
		if #statsLines > 0 then
			surface.SetFont(descFont)
			statsHeaderH = select(2, surface.GetTextSize(statsHeader))
			statsBlockH = statsHeaderH + statsLineGap
			surface.SetFont("LZY_Inventory_StatBoldItalic")
			for i, ln in ipairs(statsLines) do
				statsBlockH = statsBlockH + select(2, surface.GetTextSize(ln))
				if i < #statsLines then
					statsBlockH = statsBlockH + statsLineGap
				end
			end
		end

		local showRarity = rarityTierLabel ~= nil
		local showDur = durLine ~= nil
		local showState = stateLine ~= nil
		local showLvl = lvlLine ~= nil
		local showEnch = #enchTipLines > 0
		local showDesc = desc ~= ""
		local showStats = #statsLines > 0

		local bodyH = 0
		if showRarity then
			bodyH = bodyH + rarityH
			if showDur or showState or showLvl or showEnch or showDesc or showStats then bodyH = bodyH + sectionGap end
		end
		if showDur then
			bodyH = bodyH + durH
			if showState or showLvl or showEnch or showDesc or showStats then bodyH = bodyH + sectionGap end
		end
		if showState then
			bodyH = bodyH + stateH
			if showLvl or showEnch or showDesc or showStats then bodyH = bodyH + sectionGap end
		end
		if showLvl then
			bodyH = bodyH + lvlH
			if showEnch or showDesc or showStats then bodyH = bodyH + sectionGap end
		end
		if showEnch then
			bodyH = bodyH + enchBlockH
			if showDesc or showStats then bodyH = bodyH + sectionGap end
		end
		if showDesc then
			bodyH = bodyH + descH
			if showStats then bodyH = bodyH + sectionGap end
		end
		if showStats then
			bodyH = bodyH + statsBlockH
		end

		local nameDisplay = nameText
		surface.SetFont(nameFont)
		if select(1, surface.GetTextSize(nameText)) > innerW then
			local ell = "..."
			local base = nameText
			nameDisplay = ell
			while #base > 0 do
				if select(1, surface.GetTextSize(base .. ell)) <= innerW then
					nameDisplay = base .. ell
					break
				end
				base = string.sub(base, 1, -2)
			end
			nameH = select(2, surface.GetTextSize(nameDisplay))
		end

		local tipW = pad * 2 + innerW
		local totalH = pad + nameH + sectionGap + bodyH + pad

		-- Parent = nil (global) so the tooltip uses screen coordinates directly.
		-- Fixes mispositioning after Alt+Tab when the parent panel re-layouts.
		local tip = vgui.Create("DPanel")
		tip:SetPaintBackground(false)
		tip:SetDrawOnTop(true)
		tip:SetZPos(32767)
		tip:SetMouseInputEnabled(false)
		tip._hoverPanel = hoverPanel
		self._itemDescTooltip = tip

		tip.Paint = function(pnl, w, h)
			if EVO_UI and EVO_UI.PaintTooltip then
				EVO_UI.PaintTooltip(0, 0, w, h)
			else
				draw.RoundedBox(8, 0, 0, w, h, Color(12, 12, 16, 248))
				surface.SetDrawColor(60, 60, 70, 200)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end

			draw.SimpleText(nameDisplay, nameFont, pad, pad, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

			local y = pad + nameH + sectionGap
			if rarityTierLabel then
				surface.SetFont(descFont)
				local muted = Color(200, 200, 205, 255)
				draw.SimpleText(rarityPrefix, descFont, pad, y, muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				local pw = select(1, surface.GetTextSize(rarityPrefix))
				draw.SimpleText(rarityTierLabel, descFont, pad + pw, y, GetRarityTierTextColor(rarityVal),
					TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + rarityH
				if durLine or stateLine or lvlLine or #enchTipLines > 0 or desc ~= "" or #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if durLine then
				surface.SetFont(descFont)
				draw.SimpleText(durLine, descFont, pad, y, Color(200, 210, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + durH
				if stateLine or lvlLine or #enchTipLines > 0 or desc ~= "" or #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if stateLine then
				surface.SetFont(descFont)
				draw.SimpleText(stateLine, descFont, pad, y, stateCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + stateH
				if lvlLine or #enchTipLines > 0 or desc ~= "" or #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if lvlLine then
				surface.SetFont(descFont)
				draw.SimpleText(lvlLine, descFont, pad, y, Color(255, 200, 110, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + lvlH
				if #enchTipLines > 0 or desc ~= "" or #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if #enchTipLines > 0 then
				surface.SetFont(descFont)
				draw.SimpleText(enchHeaderText, descFont, pad, y, Color(216, 185, 106, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + enchHeaderH + gRespY(4)
				surface.SetFont("LZY_Inventory_StatBoldItalic")
				for i, l in ipairs(enchTipLines) do
					draw.SimpleText(l.txt, "LZY_Inventory_StatBoldItalic", pad, y, l.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					y = y + select(2, surface.GetTextSize(l.txt))
					if i < #enchTipLines then
						y = y + gRespY(4)
					end
				end
				if desc ~= "" or #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if desc ~= "" then
				local dx = pad * BASE_WIDTH / ScrW()
				local dy = y * BASE_HEIGHT / ScrH()
				gRespDrawMultilineText(desc, descFont, dx, dy, Color(200, 200, 205, 255), TEXT_ALIGN_LEFT, descLineGap,
					innerW, nil, TEXT_ALIGN_TOP)
				y = y + descH
				if #statsLines > 0 then
					y = y + sectionGap
				end
			end
			if #statsLines > 0 then
				surface.SetFont(descFont)
				draw.SimpleText(statsHeader, descFont, pad, y, statHeaderColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + statsHeaderH + statsLineGap
				-- Stats en gras + italique pour les distinguer du reste du tooltip
				surface.SetFont("LZY_Inventory_StatBoldItalic")
				for i, line in ipairs(statsLines) do
					draw.SimpleText(line, "LZY_Inventory_StatBoldItalic", pad, y, statAccent, TEXT_ALIGN_LEFT,
						TEXT_ALIGN_TOP)
					y = y + select(2, surface.GetTextSize(line))
					if i < #statsLines then
						y = y + statsLineGap
					end
				end
			end
		end

		tip:SetSize(tipW, totalH)

		local function positionTooltip(pnl)
			local mx, my = gui.MouseX(), gui.MouseY()
			local x = mx + gRespX(14)
			local y = my + gRespY(14)
			local w, h = pnl:GetWide(), pnl:GetTall()
			if x + w > ScrW() - 8 then x = ScrW() - w - 8 end
			if y + h > ScrH() - 8 then y = ScrH() - h - 8 end
			if x < 8 then x = 8 end
			if y < 8 then y = 8 end
			pnl:SetPos(x, y)
		end

		-- Position before first paint (otherwise it flashes at 0,0 until Think runs).
		positionTooltip(tip)

		tip.Think = function(pnl)
			if not IsValid(self) then
				pnl:Remove()
				return
			end
			if not IsValid(pnl._hoverPanel) or not pnl._hoverPanel:IsHovered() then
				self:HideItemDescriptionTooltip()
				return
			end
			positionTooltip(pnl)
		end
	end

end
