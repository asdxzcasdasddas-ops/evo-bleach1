-- "addons\\inventory\\lua\\inventory\\cl_accessory_editor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Éditeur d'offset accessoire — décalage corps (droite / avant / haut) + bonemerge.

LZY_AccessoryEditor = LZY_AccessoryEditor or {}

local editor = {
	active = false,
	gearSlot = nil,
	pos = Vector(),
	savedPos = Vector(),
	ang = Angle(),
	savedAng = Angle(),
	scale = 1,
	savedScale = 1,
	mode = "move",
	dragAxis = nil,
	camYaw = 0,
	camDist = 95,
	camLookAtOffset = Vector(),
	orbitDrag = false,
	panDrag = false,
	axisDragActive = false,
	dragReady = false,
	inputUnlockTime = 0,
	bodyYaw = 0,
	camPitch = 14,
	lastMouseX = nil,
	lastMouseY = nil,
	savedStateDefault = true,
	userEdited = false,
	poseReady = false,
	toolbarWasDown = false,
	modeToggleWasDown = false,
	scaleSliderWasDown = false,
	keyGWasDown = false,
	keyRWasDown = false,
	hoverPick = nil,
	gizmoFrame = nil,
	gizmoScreen = nil,
	lastHoverUiTarget = nil,
	_camCache = nil,
	_camCacheDirty = true,
	_cameraAsserted = false,
	accessoryMdl = nil,
	_accessoryPartsGen = -1,
}

local SND_UI_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"
local SND_UI_HOVER = "a4xy732ex6yeop2/g1kpyv29gwai.mp3"
local UI_HOVER_THROTTLE = 0.04
local lastUiHoverTime = 0

local function playUiHover()
	local t = CurTime()
	if t < lastUiHoverTime + UI_HOVER_THROTTLE then return end
	lastUiHoverTime = t
	local lp = LocalPlayer()
	if IsValid(lp) then
		lp:EmitSound(SND_UI_HOVER, 75, 100, 1, CHAN_AUTO)
	else
		surface.PlaySound(SND_UI_HOVER)
	end
end

local function playUiClick()
	surface.PlaySound(SND_UI_CLICK)
end

local AXIS_COLORS = {
	Color(207, 68, 78),
	Color(78, 196, 128),
	Color(90, 140, 240),
}

local AXIS_NAMES = { "Droite", "Avant", "Haut" }
local ROT_AXIS_NAMES = { "Pitch", "Yaw", "Roll" }

local GIZMO_PICK_PX = 22
local GIZMO_CENTER_PICK_PX = 18
local ROT_GIZMO_SEGMENTS = 36
local ROT_GIZMO_PICK_SAMPLES = 64
local ROT_GIZMO_PICK_PX = 32
local ROT_GIZMO_RADIUS_SCALE = 0.88
local DRAG_START_PX_SQ = 4

local closeEditor, saveEditor
local mouseInputAllowed, stopGizmoDrag, setTransformMode, pollModeKeys, updateCameraCursor

local function R(v)
	return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local COL = {
	sub = Color(22, 22, 27),
	sub2 = Color(30, 30, 36),
	line = Color(255, 255, 255, 20),
	bg = Color(16, 16, 19, 250),
	divider = Color(255, 255, 255, 18),
	title = Color(238, 239, 243),
	muted = Color(150, 154, 162),
	dim = Color(106, 109, 118),
	accent = Color(207, 68, 78),
	green = Color(78, 196, 128),
	red = Color(199, 70, 80),
}
if EVO_UI and EVO_UI.Col then
	table.Merge(COL, EVO_UI.Col)
end

local function MakeEditorFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("LZY_AccEd_Title", "Roboto", 15, 700)
	gCreateRespFont("LZY_AccEd_Sub", "Roboto", 12, 500)
	gCreateRespFont("LZY_AccEd_Btn", "Roboto", 13, 700)
end
hook.Add("Initialize", "LZY_AccEd::Fonts", MakeEditorFonts)
hook.Add("OnScreenSizeChanged", "LZY_AccEd::Fonts", MakeEditorFonts)
MakeEditorFonts()

local function notify(msg, kind)
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify(msg, kind == "error" and NOTIFY_ERROR or NOTIFY_GENERIC, 4)
	end
end

local function combatBlocked(gearSlot)
	local lp = LocalPlayer()
	if not IsValid(lp) then return true end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then
		notify("Impossible sous forme de Hollow.", "error")
		return true
	end
	-- Masque de base Arrancar / body de division : cosmétiques de grade, déplaçables
	-- librement (comme un accessoire sans stats).
	if INVENTORY_CONFIG.IsMasqueBaseSlot and INVENTORY_CONFIG.IsMasqueBaseSlot(gearSlot) then
		return false
	end
	if INVENTORY_CONFIG.IsDivisionBodySlot and INVENTORY_CONFIG.IsDivisionBodySlot(gearSlot) then
		return false
	end
	if INVENTORY_CONFIG.IsGradeSlot and INVENTORY_CONFIG.IsGradeSlot(gearSlot) then
		return false
	end
	if INVENTORY_CONFIG.IsRankOffsetSlot and INVENTORY_CONFIG.IsRankOffsetSlot(gearSlot) then
		return false
	end
	-- Accessoire cosmétique (sans stats) : déplaçable librement même en combat (demande
	-- user). Seuls les accessoires à stats restent verrouillés. Le serveur reste autoritatif
	-- (SaveAccessoryOffset). gearSlot fourni -> on résout l'item équipé sur ce slot.
	if gearSlot and INVENTORY_CONFIG.ItemAffectsStats then
		local eq = lp.GetInventoryEquippedItems and lp:GetInventoryEquippedItems() or {}
		local itemId = eq[tostring(gearSlot)]
		if itemId and not INVENTORY_CONFIG.ItemAffectsStats(itemId) then
			return false
		end
	end
	local nRemaining = math.ceil((lp:GetEvoNWFloat("EVO_CombatSwapUntil", 0) or 0) - CurTime())
	if nRemaining > 0 then
		notify("Impossible en combat : encore " .. nRemaining .. "s.", "error")
		return true
	end
	return false
end

local function getCharData()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	return GetPlayerCharacterData and GetPlayerCharacterData(lp) or nil
end

local function offsetTableFromState()
	return INVENTORY_CONFIG.AccessoryOffsetPack(editor.pos, editor.ang, editor.scale)
end

local function stateIsDefault()
	if editor.userEdited then return false end
	return INVENTORY_CONFIG.AccessoryOffsetIsZero(offsetTableFromState())
end

function LZY_AccessoryEditor_IsActive()
	return editor.active
end

function LZY_AccessoryEditor_IsDragging()
	return editor.active and editor.dragReady == true
end

function LZY_AccessoryEditor_GetBodyYaw()
	return editor.active and editor.bodyYaw or nil
end

function LZY_AccessoryEditor_GetGearSlot()
	return editor.active and editor.gearSlot or nil
end

function LZY_AccessoryEditor_GetPreviewOffset(slotKey)
	if not editor.active then return nil end
	slotKey = slotKey or editor.gearSlot
	if slotKey and tostring(editor.gearSlot) ~= tostring(slotKey) then return nil end
	return offsetTableFromState()
end

function LZY_AccessoryEditor_ShouldPreviewOffset(slotKey)
	if not editor.active then return false end
	slotKey = slotKey or editor.gearSlot
	if slotKey and tostring(editor.gearSlot) ~= tostring(slotKey) then return false end
	return editor.poseReady
end

local function offsetNearZero()
	return stateIsDefault()
end

local function getAxisLabels()
	if editor.mode == "rotate" then return ROT_AXIS_NAMES end
	return AXIS_NAMES
end

local function invalidateAccessoryModelCache()
	editor.accessoryMdl = nil
	editor._accessoryPartsGen = -1
end

local function getAccessoryModel()
	local lp = LocalPlayer()
	if not IsValid(lp) then
		invalidateAccessoryModelCache()
		return nil
	end

	local gen = lp._lzyAccessoryPartsGen or 0
	local cached = editor.accessoryMdl
	if IsValid(cached) and editor._accessoryPartsGen == gen
		and cached._lzyAccessorySlot == tostring(editor.gearSlot) then
		return cached
	end

	editor.accessoryMdl = LZY_Character_FindAccessoryModelOnPlayer(lp, editor.gearSlot)
	editor._accessoryPartsGen = gen
	return editor.accessoryMdl
end

local function clearLivePreviewModel()
	local mdl = getAccessoryModel()
	if IsValid(mdl) and LZY_Character_DestroyAccessoryOffsetGhost then
		LZY_Character_DestroyAccessoryOffsetGhost(mdl)
	end
end

local function markCamDirty()
	editor._camCacheDirty = true
end

local function getEditorCam(eyeOrigin)
	if not editor._camCacheDirty and editor._camCache then
		local c = editor._camCache
		return c.pos, c.ang
	end

	local lp = LocalPlayer()
	if not IsValid(lp) then return vector_origin, angle_zero end
	local lookAt = (eyeOrigin or lp:EyePos()) + Vector(0, 0, 28) + editor.camLookAtOffset
	local orbitAng = Angle(editor.camPitch, editor.camYaw, 0)
	local dir = orbitAng:Forward()
	local camPos = lookAt - dir * editor.camDist
	local tr = util.TraceLine({
		start = lookAt,
		endpos = camPos,
		filter = lp,
		mask = MASK_SOLID_BRUSHONLY,
	})
	if tr.Hit then
		camPos = tr.HitPos + tr.HitNormal * 6
	end
	local camAng = (lookAt - camPos):Angle()
	editor._camCache = { pos = camPos, ang = camAng }
	editor._camCacheDirty = false
	return camPos, camAng
end

local function getGizmoWorldFrame()
	local mdl = getAccessoryModel()
	local lp = LocalPlayer()
	if not IsValid(mdl) or not IsValid(lp) then return nil end
	if not LZY_Character_GetAccessoryEditorGizmoOrigin then return nil end

	local origin = LZY_Character_GetAccessoryEditorGizmoOrigin(mdl, editor.pos, editor.bodyYaw)
	if not origin then return nil end

	-- Même repère que le rendu (os porteur), sinon le gizmo et la pièce divergent hors idle.
	local right, forward, up
	if LZY_Character_GetAccessoryAxes then
		right, forward, up = LZY_Character_GetAccessoryAxes(mdl, lp, editor.bodyYaw)
	else
		right, forward, up = LZY_Character_GetBodyLocalMoveAxes(lp, editor.bodyYaw)
	end
	local camPos = select(1, getEditorCam())
	local arm = math.Clamp(origin:Distance(camPos) * 0.075, 6, 28)

	return {
		origin = origin,
		right = right,
		forward = forward,
		up = up,
		arm = arm,
		camPos = camPos,
	}
end

local function getReadoutLayout()
	local w = R(228)
	local h = R(56)
	return {
		x = ScrW() - R(16) - w,
		y = R(150),
		w = w,
		h = h,
	}
end

local function distPointSq(px, py, x, y)
	local ax, ay = px - x, py - y
	return ax * ax + ay * ay
end

local function distPointToSegmentSq(px, py, x1, y1, x2, y2)
	local dx, dy = x2 - x1, y2 - y1
	local lenSq = dx * dx + dy * dy
	if lenSq < 1e-6 then
		return distPointSq(px, py, x1, y1)
	end
	local t = ((px - x1) * dx + (py - y1) * dy) / lenSq
	t = math.Clamp(t, 0, 1)
	local cx, cy = x1 + dx * t, y1 + dy * t
	return distPointSq(px, py, cx, cy)
end

local function getGizmoAxisWorldDir(frame, axis)
	if axis == 1 then
		return frame.right
	elseif axis == 2 then
		return frame.forward
	else
		return frame.up
	end
end

local function getGizmoRotatePlaneAxes(frame, axis)
	if axis == 1 then
		return frame.forward, frame.up
	elseif axis == 2 then
		return frame.right, frame.up
	else
		return frame.right, frame.forward
	end
end

local function getGizmoRingEdgeOn(frame, axis)
	if not frame or not frame.camPos then return 0 end
	local axisDir = getGizmoAxisWorldDir(frame, axis)
	local viewDir = (frame.camPos - frame.origin)
	if viewDir:LengthSqr() < 1e-6 then return 0 end
	viewDir:Normalize()
	return math.abs(axisDir:Dot(viewDir))
end

local function getGizmoRingAlpha(frame, axis)
	return math.floor(Lerp(getGizmoRingEdgeOn(frame, axis), 255, 72))
end

local function getGizmoRingFaceOn(frame, axis)
	return 1 - getGizmoRingEdgeOn(frame, axis)
end

local function buildGizmoMoveScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end

	local cache = {
		kind = "move",
		origin = { x = originScr.x, y = originScr.y },
		axes = {},
		arm = frame.arm,
	}

	for axis = 1, 3 do
		local dir = getGizmoAxisWorldDir(frame, axis)
		local endScr = (frame.origin + dir * frame.arm):ToScreen()
		if endScr.visible then
			cache.axes[axis] = {
				x1 = originScr.x,
				y1 = originScr.y,
				x2 = endScr.x,
				y2 = endScr.y,
			}
		end
	end

	return cache
end

local function buildGizmoRotateScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end

	local cache = {
		kind = "rotate",
		origin = { x = originScr.x, y = originScr.y },
		rings = {},
		arm = frame.arm,
	}

	local radius = frame.arm * ROT_GIZMO_RADIUS_SCALE
	for axis = 1, 3 do
		local u, v = getGizmoRotatePlaneAxes(frame, axis)
		local points = {}
		local segs = {}
		local alpha = getGizmoRingAlpha(frame, axis)
		local faceOn = getGizmoRingFaceOn(frame, axis)
		local su = (frame.origin + u * radius):ToScreen()
		local sv = (frame.origin + v * radius):ToScreen()

		for i = 0, ROT_GIZMO_SEGMENTS - 1 do
			local t0 = (i / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local t1 = ((i + 1) / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local w0 = frame.origin + (u * math.cos(t0) + v * math.sin(t0)) * radius
			local w1 = frame.origin + (u * math.cos(t1) + v * math.sin(t1)) * radius
			local s0, s1 = w0:ToScreen(), w1:ToScreen()
			points[#points + 1] = { x = s0.x, y = s0.y, visible = s0.visible }
			if s0.visible or s1.visible then
				segs[#segs + 1] = {
					x1 = s0.x, y1 = s0.y,
					x2 = s1.x, y2 = s1.y,
					visible = s0.visible and s1.visible,
				}
			end
		end

		cache.rings[axis] = {
			points = points,
			segs = segs,
			alpha = alpha,
			faceOn = faceOn,
			basis = {
				ux = su.x - originScr.x,
				uy = su.y - originScr.y,
				vx = sv.x - originScr.x,
				vy = sv.y - originScr.y,
			},
		}
	end

	return cache
end

local function buildGizmoScreenCache(frame)
	if editor.mode == "rotate" then
		return buildGizmoRotateScreenCache(frame)
	end
	return buildGizmoMoveScreenCache(frame)
end

local function ensureGizmoScreenCache()
	editor.gizmoFrame = getGizmoWorldFrame()
	if not editor.gizmoFrame then
		return editor.gizmoScreen
	end
	local fresh = buildGizmoScreenCache(editor.gizmoFrame)
	if fresh then
		editor.gizmoScreen = fresh
	end
	return editor.gizmoScreen
end

--- 0 = origine (grab), 1..3 = axe, nil = rien
local function pickGizmoMoveFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end

	local centerPick = GIZMO_CENTER_PICK_PX * GIZMO_CENTER_PICK_PX
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= centerPick then
		return 0
	end

	local bestPick, bestScore = nil, GIZMO_PICK_PX * GIZMO_PICK_PX
	for axis = 1, 3 do
		local seg = cache.axes[axis]
		if seg then
			local distSq = distPointToSegmentSq(mx, my, seg.x1, seg.y1, seg.x2, seg.y2)
			if distSq < bestScore then
				bestScore = distSq
				bestPick = axis
			end
		end
	end
	return bestPick
end

local function distToRingCurveSq(mx, my, origin, ring)
	if not ring or not ring.basis or not origin then return math.huge end
	local ox, oy = origin.x, origin.y
	local ux, uy = ring.basis.ux, ring.basis.uy
	local vx, vy = ring.basis.vx, ring.basis.vy
	local best = math.huge
	for i = 0, ROT_GIZMO_PICK_SAMPLES - 1 do
		local t = (i / ROT_GIZMO_PICK_SAMPLES) * math.pi * 2
		local cosT, sinT = math.cos(t), math.sin(t)
		local px = ox + ux * cosT + vx * sinT
		local py = oy + uy * cosT + vy * sinT
		local d = distPointSq(mx, my, px, py)
		if d < best then best = d end
	end
	return best
end

local function pickGizmoRotateFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end

	local ox, oy = cache.origin.x, cache.origin.y
	local centerDistSq = distPointSq(mx, my, ox, oy)
	local centerPickPx = GIZMO_CENTER_PICK_PX + R(4)
	if centerDistSq <= centerPickPx * centerPickPx then
		return 0
	end

	local pickPx = ROT_GIZMO_PICK_PX + R(4)
	local bestPick, bestScore = nil, math.huge
	for axis = 1, 3 do
		local ring = cache.rings and cache.rings[axis]
		if ring then
			local distSq = distToRingCurveSq(mx, my, cache.origin, ring)
			local faceOn = ring.faceOn or 0.5
			local edgeOn = 1 - faceOn
			local pickBonus = edgeOn * pickPx * 0.75
			local threshold = (pickPx + pickBonus) * (pickPx + pickBonus)
			if distSq <= threshold then
				local score = distSq / (0.15 + faceOn * 0.85)
				if score < bestScore then
					bestScore = score
					bestPick = axis
				end
			end
		end
	end
	return bestPick
end

local function pickGizmoFromCache(mx, my, cache)
	if cache and cache.kind == "rotate" then
		return pickGizmoRotateFromCache(mx, my, cache)
	end
	return pickGizmoMoveFromCache(mx, my, cache)
end

local function screenDeltaToBodyLocal(dx, dy, camAng, scale, parent, yawOverride)
	local worldDelta = camAng:Right() * (dx * scale) - camAng:Up() * (dy * scale)
	local mdl = getAccessoryModel()
	local right, forward, up
	if IsValid(mdl) and LZY_Character_GetAccessoryAxes then
		right, forward, up = LZY_Character_GetAccessoryAxes(mdl, parent, yawOverride)
	else
		right, forward, up = LZY_Character_GetBodyLocalMoveAxes(parent, yawOverride)
	end
	return Vector(
		worldDelta:Dot(right),
		worldDelta:Dot(forward),
		worldDelta:Dot(up)
	)
end

local function axisDragBodyDeltaFromCache(axis, dx, dy, cache)
	local seg = cache and cache.axes[axis]
	if not seg then return 0 end

	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.sqrt(sx * sx + sy * sy)
	if len < 0.01 then return 0 end
	sx, sy = sx / len, sy / len

	local alongPx = dx * sx + dy * sy
	return (alongPx / len) * (cache.arm or 0)
end

local function ringDragBodyAngleFromCache(mx, my, anchorMx, anchorMy, cache)
	if not cache or not cache.origin then return 0 end
	local cx, cy = cache.origin.x, cache.origin.y
	local a0 = math.atan2(anchorMy - cy, anchorMx - cx)
	local a1 = math.atan2(my - cy, mx - cx)
	local delta = math.deg(a1 - a0)
	if delta > 180 then
		delta = delta - 360
	elseif delta < -180 then
		delta = delta + 360
	end
	return delta
end

local function screenDeltaToBodyLocalAngle(dx, dy)
	return Angle(-dy * 0.35, dx * 0.35, 0)
end

local function drawWorldGizmoAxisFromCache(seg, col, highlight, label)
	if not seg then return end

	local drawCol = highlight and COL.title or col
	surface.SetDrawColor(drawCol)
	surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)

	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.max(math.sqrt(sx * sx + sy * sy), 0.01)
	sx, sy = sx / len, sy / len
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) + sy * R(4), seg.y2 - sy * R(7) - sx * R(4))
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) - sy * R(4), seg.y2 - sy * R(7) + sx * R(4))

	if label then
		draw.SimpleText(label, "LZY_AccEd_Sub", seg.x2 + sx * R(10), seg.y2 + sy * R(10), drawCol, TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER)
	end
end

local function drawWorldGizmoRingFromCache(ring, col, highlight, label)
	if not ring or not ring.segs then return end

	local alpha = ring.alpha or 255
	local drawCol = highlight and COL.title or ColorAlpha(col, alpha)
	surface.SetDrawColor(drawCol)
	for _, seg in ipairs(ring.segs) do
		if seg.visible ~= false then
			surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
		end
	end

	if highlight then
		surface.SetDrawColor(ColorAlpha(drawCol, math.min(alpha + 40, 255)))
		for _, seg in ipairs(ring.segs) do
			if seg.visible ~= false then
				surface.DrawLine(seg.x1 + 1, seg.y1, seg.x2 + 1, seg.y2)
				surface.DrawLine(seg.x1, seg.y1 + 1, seg.x2, seg.y2 + 1)
			end
		end
	end

	if label and ring.points then
		local n = #ring.points
		local pt = ring.points[math.floor(n * 0.125) + 1] or ring.points[1]
		if pt then
			draw.SimpleText(label, "LZY_AccEd_Sub", pt.x, pt.y, drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

local function paintWorldGizmo(mx, my)
	editor.gizmoFrame = getGizmoWorldFrame()
	local frame = editor.gizmoFrame
	if not frame then
		editor.gizmoScreen = nil
		editor.hoverPick = nil
		return
	end

	editor.gizmoScreen = buildGizmoScreenCache(frame)
	local cache = editor.gizmoScreen
	if not cache then
		editor.hoverPick = nil
		return
	end

	editor.hoverPick = pickGizmoFromCache(mx, my, cache)
	local activePick = editor.axisDragActive and editor.dragAxis or nil
	local ox, oy = cache.origin.x, cache.origin.y

	local centerHl = editor.hoverPick == 0 or activePick == 0
	local centerR = R(centerHl and 9 or 7)
	if RNDX then
		RNDX.Draw(centerR, ox - centerR, oy - centerR, centerR * 2, centerR * 2,
			centerHl and COL.title or ColorAlpha(COL.title, 180))
	else
		draw.RoundedBox(centerR, ox - centerR, oy - centerR, centerR * 2, centerR * 2,
			centerHl and COL.title or ColorAlpha(COL.title, 180))
	end
	surface.SetDrawColor(COL.bg)
	surface.DrawRect(ox - R(3), oy - R(3), R(6), R(6))

	local labels = getAxisLabels()
	if cache.kind == "rotate" then
		for axis = 1, 3 do
			local hl = editor.hoverPick == axis or activePick == axis
			drawWorldGizmoRingFromCache(cache.rings[axis], AXIS_COLORS[axis], hl, labels[axis])
		end
	else
		for axis = 1, 3 do
			local hl = editor.hoverPick == axis or activePick == axis
			drawWorldGizmoAxisFromCache(cache.axes[axis], AXIS_COLORS[axis], hl, labels[axis])
		end
	end
end

local function paintEvoCard(rx, ry, rw, rh, title, subtitle)
	if RNDX then
		RNDX.Draw(R(12), rx, ry, rw, rh, COL.bg)
	else
		draw.RoundedBox(R(12), rx, ry, rw, rh, COL.bg)
	end
	if EVO_UI and EVO_UI.Header then
		local pad = R(14)
		surface.SetDrawColor(COL.accent)
		surface.DrawRect(rx + pad, ry + R(24), R(3), R(18))
		draw.SimpleText(title, "EVO_UI_Header", rx + pad + R(12), ry + R(33), COL.title, TEXT_ALIGN_LEFT,
			TEXT_ALIGN_CENTER)
		if subtitle and subtitle ~= "" then
			draw.SimpleText(subtitle, "LZY_AccEd_Sub", rx + rw - pad, ry + R(33), COL.dim, TEXT_ALIGN_RIGHT,
				TEXT_ALIGN_CENTER)
		end
		surface.SetDrawColor(COL.divider)
		surface.DrawRect(rx + pad, ry + R(54), rw - pad * 2, 1)
	else
		surface.SetDrawColor(COL.accent)
		surface.DrawRect(rx + R(14), ry + R(16), R(3), R(16))
		draw.SimpleText(title, "LZY_AccEd_Title", rx + R(24), ry + R(18), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if subtitle then
			draw.SimpleText(subtitle, "LZY_AccEd_Sub", rx + R(24), ry + R(38), COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		surface.SetDrawColor(COL.divider)
		surface.DrawRect(rx + R(14), ry + R(54), rw - R(28), 1)
	end
end

local function paintOffsetReadout()
	local layout = getReadoutLayout()
	local title = editor.mode == "rotate" and "Rotation" or "Déplacer"
	local posLabel
	if editor.mode == "rotate" then
		posLabel = string.format("P %.1f  Y %.1f  R %.1f", editor.ang.p, editor.ang.y, editor.ang.r)
	else
		posLabel = string.format("R %.1f  A %.1f  H %.1f", editor.pos.x, editor.pos.y, editor.pos.z)
	end
	paintEvoCard(layout.x, layout.y, layout.w, layout.h, title, posLabel)
end

local function getModeToggleLayout()
	local layout = getReadoutLayout()
	return {
		x = layout.x,
		y = layout.y + layout.h + R(8),
		w = layout.w,
		h = R(80),
	}
end

local function getModeToggleSegments(btn)
	local segPad = R(8)
	local segGap = R(6)
	local segY = btn.y + R(38)
	local segH = btn.h - R(38) - segPad
	local segW = (btn.w - segPad * 2 - segGap) * 0.5
	return segPad, segGap, segY, segH, segW
end

local function hitModeToggle(mx, my)
	local btn = getModeToggleLayout()
	if mx < btn.x or mx > btn.x + btn.w or my < btn.y or my > btn.y + btn.h then return nil end
	local segPad, segGap, segY, segH, segW = getModeToggleSegments(btn)
	if my < segY or my > segY + segH then return nil end
	if mx < btn.x + segPad + segW then return "move" end
	if mx <= btn.x + segPad + segW + segGap + segW then return "rotate" end
end

local function paintModeToggleSegment(sx, sy, segW, segH, label, active, hov)
	if active then
		local bg = ColorAlpha(COL.accent, hov and 255 or 220)
		if RNDX then RNDX.Draw(R(8), sx, sy, segW, segH, bg) else draw.RoundedBox(R(8), sx, sy, segW, segH, bg) end
		draw.SimpleText(label, "LZY_AccEd_Btn", sx + segW / 2, sy + segH / 2, color_white, TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER)
	else
		if RNDX then
			RNDX.Draw(R(8), sx, sy, segW, segH, ColorAlpha(color_white, hov and 14 or 7))
			RNDX.DrawOutlined(R(8), sx, sy, segW, segH, ColorAlpha(COL.line, hov and 60 or 32), 1)
		else
			draw.RoundedBox(R(8), sx, sy, segW, segH, ColorAlpha(color_white, hov and 14 or 7))
		end
		draw.SimpleText(label, "LZY_AccEd_Btn", sx + segW / 2, sy + segH / 2, hov and COL.title or COL.muted,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local function paintModeToggle(mx, my)
	local btn = getModeToggleLayout()
	if RNDX then
		RNDX.Draw(R(12), btn.x, btn.y, btn.w, btn.h, COL.bg)
	else
		draw.RoundedBox(R(12), btn.x, btn.y, btn.w, btn.h, COL.bg)
	end

	local pad = R(14)
	surface.SetDrawColor(COL.accent)
	surface.DrawRect(btn.x + pad, btn.y + R(12), R(3), R(16))
	draw.SimpleText("Mode", "EVO_UI_Header", btn.x + pad + R(12), btn.y + R(20), COL.title, TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER)

	local segPad, segGap, segY, segH, segW = getModeToggleSegments(btn)
	local modes = {
		{ id = "move",   label = "Déplacer", x = btn.x + segPad },
		{ id = "rotate", label = "Rotation", x = btn.x + segPad + segW + segGap },
	}

	for _, mode in ipairs(modes) do
		local hov = mx >= mode.x and mx <= mode.x + segW and my >= segY and my <= segY + segH
		paintModeToggleSegment(mode.x, segY, segW, segH, mode.label, editor.mode == mode.id, hov)
	end
end

local function getScaleSliderLayout()
	local btn = getModeToggleLayout()
	return {
		x = btn.x,
		y = btn.y + btn.h + R(8),
		w = btn.w,
		h = R(72),
	}
end

local function getScaleSliderTrack(layout)
	local pad = R(14)
	local trackY = layout.y + R(44)
	local trackH = R(8)
	local trackX = layout.x + pad
	local trackW = layout.w - pad * 2
	return trackX, trackY, trackW, trackH
end

local function scaleToSliderT(scale)
	local sMin, sMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind)
	if sMax <= sMin then return 0.5 end
	return math.Clamp(((tonumber(scale) or 1) - sMin) / (sMax - sMin), 0, 1)
end

local function sliderTToScale(t)
	local sMin, sMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind)
	return INVENTORY_CONFIG.ClampAccessoryOffsetScale(sMin + math.Clamp(t, 0, 1) * (sMax - sMin), editor.limitKind)
end

local function hitScaleSlider(mx, my)
	local layout = getScaleSliderLayout()
	if mx < layout.x or mx > layout.x + layout.w or my < layout.y or my > layout.y + layout.h then
		return false
	end
	return true
end

local function setScaleFromMouseX(mx)
	local layout = getScaleSliderLayout()
	local trackX, _, trackW = getScaleSliderTrack(layout)
	local t = 0
	if trackW > 0 then
		t = (mx - trackX) / trackW
	end
	editor.scale = sliderTToScale(t)
	editor.userEdited = true
end

local function paintScaleSlider(mx, my)
	local layout = getScaleSliderLayout()
	local hov = hitScaleSlider(mx, my)
	if RNDX then
		RNDX.Draw(R(12), layout.x, layout.y, layout.w, layout.h, COL.bg)
	else
		draw.RoundedBox(R(12), layout.x, layout.y, layout.w, layout.h, COL.bg)
	end

	local pad = R(14)
	surface.SetDrawColor(COL.accent)
	surface.DrawRect(layout.x + pad, layout.y + R(12), R(3), R(16))
	draw.SimpleText("Échelle", "EVO_UI_Header", layout.x + pad + R(12), layout.y + R(20), COL.title,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText(string.format("%.2f", editor.scale or 1), "LZY_AccEd_Sub", layout.x + layout.w - pad,
		layout.y + R(20), COL.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	local trackX, trackY, trackW, trackH = getScaleSliderTrack(layout)
	if RNDX then
		RNDX.Draw(R(4), trackX, trackY, trackW, trackH, ColorAlpha(color_white, 10))
	else
		draw.RoundedBox(R(4), trackX, trackY, trackW, trackH, ColorAlpha(color_white, 10))
	end

	local t = scaleToSliderT(editor.scale)
	local fillW = math.floor(trackW * t)
	if fillW > 0 then
		if RNDX then
			RNDX.Draw(R(4), trackX, trackY, fillW, trackH, ColorAlpha(COL.accent, hov and 255 or 200))
		else
			draw.RoundedBox(R(4), trackX, trackY, fillW, trackH, ColorAlpha(COL.accent, hov and 255 or 200))
		end
	end

	local knobR = R(7)
	local knobX = trackX + fillW - knobR
	local knobY = trackY + trackH * 0.5 - knobR
	if RNDX then
		RNDX.Draw(knobR, knobX, knobY, knobR * 2, knobR * 2, hov and color_white or COL.title)
	else
		draw.RoundedBox(knobR, knobX, knobY, knobR * 2, knobR * 2, hov and color_white or COL.title)
	end
end

local function handleScaleSliderInput()
	local mx, my = gui.MouseX(), gui.MouseY()
	local over = hitScaleSlider(mx, my)
	local down = input.IsMouseDown(MOUSE_LEFT)
	if down and (editor.scaleSliderWasDown or over) then
		if not editor.scaleSliderWasDown and over then
			playUiClick()
		end
		setScaleFromMouseX(mx)
		editor.scaleSliderWasDown = true
		return true
	end
	if not down then editor.scaleSliderWasDown = false end
	return false
end

local function pointerOverScaleSlider()
	return hitScaleSlider(gui.MouseX(), gui.MouseY())
end

local TOOLBAR_H = R(78)

local function toolbarY()
	return ScrH() - TOOLBAR_H
end

local function rebuildToolbarButtons()
	local y = toolbarY() + R(14)
	local h = R(44)
	local gap = R(10)
	local bw = R(148)
	local total = bw * 3 + gap * 2
	local startX = ScrW() / 2 - total / 2
	editor.buttons = {
		{ x = startX,            y = y, w = bw, h = h, label = "Valider", filled = true,  fn = saveEditor },
		{ x = startX + bw + gap, y = y, w = bw, h = h, label = "Annuler", filled = false, fn = function() closeEditor(true) end },
		{
			x = startX + (bw + gap) * 2,
			y = y,
			w = bw,
			h = h,
			label = "Réinitialiser",
			filled = false,
			fn = function()
				editor.pos = Vector()
				editor.ang = Angle()
				editor.scale = 1
				editor.userEdited = false
			end
		},
	}
end

local function ensureToolbarButtons()
	if not editor.buttons then rebuildToolbarButtons() end
end

local function handleModeToggleInput()
	local mx, my = gui.MouseX(), gui.MouseY()
	local pick = hitModeToggle(mx, my)
	if not pick then return false end
	local down = input.IsMouseDown(MOUSE_LEFT)
	if down and not editor.modeToggleWasDown then
		playUiClick()
		setTransformMode(pick)
		editor.modeToggleWasDown = true
		return true
	end
	if not down then editor.modeToggleWasDown = false end
	return false
end

local function pointerOverModeToggle()
	local mx, my = gui.MouseX(), gui.MouseY()
	return hitModeToggle(mx, my) ~= nil
end

local function pointerOverToolbar()
	return gui.MouseY() >= toolbarY()
end

local function pointerOverEditorUI()
	return pointerOverToolbar() or pointerOverModeToggle() or pointerOverScaleSlider()
end

local function hitToolbarButton(mx, my)
	ensureToolbarButtons()
	for _, btn in ipairs(editor.buttons) do
		if mx >= btn.x and mx <= btn.x + btn.w and my >= btn.y and my <= btn.y + btn.h then
			return btn
		end
	end
end

local function handleToolbarInput()
	local mx, my = gui.MouseX(), gui.MouseY()
	local btn = hitToolbarButton(mx, my)
	local down = input.IsMouseDown(MOUSE_LEFT)
	if btn and down and not editor.toolbarWasDown then
		playUiClick()
		btn.fn()
		editor.toolbarWasDown = true
		return true
	end
	if not down then editor.toolbarWasDown = false end
	return false
end

local function clampEditorOffsetState()
	editor.pos = INVENTORY_CONFIG.ClampAccessoryOffsetPos(editor.pos, editor.limitKind, editor.scale)
	-- itemId conservé pour ClampAccessoryOffsetAng (masques désormais ±5 comme le reste, 07/24).
	editor.ang = INVENTORY_CONFIG.ClampAccessoryOffsetAng(editor.ang, editor.itemId)
	editor.scale = INVENTORY_CONFIG.ClampAccessoryOffsetScale(editor.scale, editor.limitKind)
end

local function clampEditorCameraState()
	editor.camDist = INVENTORY_CONFIG.ClampAccessoryEditorCamDist(editor.camDist)
	editor.camPitch = INVENTORY_CONFIG.ClampAccessoryEditorCamPitch(editor.camPitch)
	editor.camYaw = INVENTORY_CONFIG.ClampAccessoryEditorCamYaw(editor.camYaw, editor.bodyYaw)
	editor.camLookAtOffset = INVENTORY_CONFIG.ClampAccessoryEditorCamPan(editor.camLookAtOffset)
	markCamDirty()
end

local function zoomCamera(delta)
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	local step = ed.CAM_ZOOM_STEP or 8
	editor.camDist = INVENTORY_CONFIG.ClampAccessoryEditorCamDist(editor.camDist - delta * step)
	markCamDirty()
end

mouseInputAllowed = function()
	return CurTime() >= (editor.inputUnlockTime or 0)
end

local function pollMouseDelta()
	local mx, my = gui.MouseX(), gui.MouseY()
	local mdx, mdy = 0, 0
	if editor.lastMouseX and editor.lastMouseY then
		mdx = mx - editor.lastMouseX
		mdy = my - editor.lastMouseY
	end
	editor.lastMouseX = mx
	editor.lastMouseY = my
	return mdx, mdy
end

local function tryStartGizmoDrag()
	if not mouseInputAllowed() or editor.axisDragActive or pointerOverEditorUI() then
		return
	end
	-- FIX serveur dédié : on prend le cache écran construit par le DESSIN (paintWorldGizmo, en
	-- HUDPaint = APRÈS le rendu = BONNE vue éditeur), au lieu de le RECONSTRUIRE via ToScreen ici dans
	-- CreateMove (où ToScreen projetait avec une vue ≠ celle du dessin -> le gizmo était "pensé"
	-- ailleurs que là où il est dessiné -> PICK NIL alors que tu cliques bien dessus). Fallback rebuild
	-- uniquement si le dessin n'a pas encore tourné (1re frame).
	local cache = editor.gizmoScreen or ensureGizmoScreenCache()
	if not cache then return end
	local mx, my = gui.MouseX(), gui.MouseY()
	local pick = pickGizmoFromCache(mx, my, cache)
	if pick == nil then return end
	editor.dragAxis = pick
	editor.axisDragActive = true
	editor.dragReady = false
	editor._dragAnchorX = mx
	editor._dragAnchorY = my
	editor._dragStartPos = Vector(editor.pos)
	editor._dragStartAng = Angle(editor.ang)
	editor._dragGizmoScreen = cache
end

local function updateGizmoDrag()
	if not editor.axisDragActive or editor.dragAxis == nil or not input.IsMouseDown(MOUSE_LEFT) then return end
	local mx, my = gui.MouseX(), gui.MouseY()
	local ax, ay = editor._dragAnchorX or mx, editor._dragAnchorY or my
	local dx, dy = mx - ax, my - ay
	if not editor.dragReady then
		if (dx * dx + dy * dy) >= DRAG_START_PX_SQ then
			editor.dragReady = true
		else
			return
		end
	end

	local cache = editor.gizmoScreen or editor._dragGizmoScreen -- cache du DESSIN (bonne vue), cf fix ci-dessus
	if not cache then return end
	local frame = editor.gizmoFrame or getGizmoWorldFrame()
	if not frame then return end
	local dragCache = editor._dragGizmoScreen or cache

	editor.userEdited = true

	if editor.mode == "rotate" then
		local startA = editor._dragStartAng or editor.ang
		if editor.dragAxis == 0 then
			local d = screenDeltaToBodyLocalAngle(dx, dy)
			editor.ang = Angle(startA.p + d.p, startA.y + d.y, startA.r + d.r)
		else
			local delta = ringDragBodyAngleFromCache(
				mx, my, editor._dragAnchorX, editor._dragAnchorY, dragCache)
			if editor.dragAxis == 1 then
				editor.ang = Angle(startA.p + delta, startA.y, startA.r)
			elseif editor.dragAxis == 2 then
				editor.ang = Angle(startA.p, startA.y + delta, startA.r)
			else
				editor.ang = Angle(startA.p, startA.y, startA.r + delta)
			end
		end
	else
		local start = editor._dragStartPos or editor.pos
		local lp = LocalPlayer()
		local _, camAng = getEditorCam()
		local scale = frame.origin:Distance(frame.camPos) * 0.0012

		if editor.dragAxis == 0 then
			local delta = screenDeltaToBodyLocal(dx, dy, camAng, scale, lp, editor.bodyYaw)
			editor.pos = start + delta
		else
			local along = axisDragBodyDeltaFromCache(editor.dragAxis, dx, dy, cache)
			if editor.dragAxis == 1 then
				editor.pos = Vector(start.x + along, start.y, start.z)
			elseif editor.dragAxis == 2 then
				editor.pos = Vector(start.x, start.y + along, start.z)
			else
				editor.pos = Vector(start.x, start.y, start.z + along)
			end
		end
	end

	clampEditorOffsetState()
end

stopGizmoDrag = function()
	editor.dragAxis = nil
	editor.axisDragActive = false
	editor.dragReady = false
	editor._dragGizmoScreen = nil
end

setTransformMode = function(mode)
	if editor.mode == mode then return end
	editor.mode = mode
	stopGizmoDrag()
end

pollModeKeys = function()
	if not mouseInputAllowed() then return end
	if gui.IsConsoleVisible() or gui.IsGameUIVisible() then return end
	local kb = vgui.GetKeyboardFocus()
	if IsValid(kb) and kb.GetClassName and kb:GetClassName() == "TextEntry" then return end

	local keyG = input.IsKeyDown(KEY_G)
	local keyR = input.IsKeyDown(KEY_R)

	if keyG and not editor.keyGWasDown then
		setTransformMode("move")
	elseif keyR and not editor.keyRWasDown then
		setTransformMode("rotate")
	end

	editor.keyGWasDown = keyG
	editor.keyRWasDown = keyR
end

local function setEditorCursor(cursor)
	local pnl = editor.inputPanel
	if IsValid(pnl) then
		pnl:SetCursor(cursor or "arrow")
		return
	end
	local world = vgui.GetWorldPanel()
	if IsValid(world) then world:SetCursor(cursor or "arrow") end
end

local function isCameraDragging()
	return (editor.orbitDrag and input.IsMouseDown(MOUSE_RIGHT))
		or (editor.panDrag and input.IsMouseDown(MOUSE_MIDDLE))
end

local function getHoverUiTarget()
	local mx, my = gui.MouseX(), gui.MouseY()
	local btn = hitToolbarButton(mx, my)
	if btn then return "toolbar:" .. btn.label end
	local mode = hitModeToggle(mx, my)
	if mode then return "mode:" .. mode end
	if hitScaleSlider(mx, my) then return "scale" end
end

local function pointerOverHoverableUI()
	return getHoverUiTarget() ~= nil
end

local function updateUiHoverSound()
	if isCameraDragging() then
		editor.lastHoverUiTarget = nil
		return
	end
	local target = getHoverUiTarget()
	if target and target ~= editor.lastHoverUiTarget then
		playUiHover()
	end
	editor.lastHoverUiTarget = target
end

updateCameraCursor = function()
	if isCameraDragging() or pointerOverHoverableUI() then
		setEditorCursor("hand")
	else
		setEditorCursor("arrow")
	end
end

local function destroyInputPanel()
	if IsValid(editor.inputPanel) then
		editor.inputPanel:Remove()
	end
	editor.inputPanel = nil
end

local function createInputPanel()
	destroyInputPanel()
	local pnl = vgui.Create("EditablePanel")
	pnl:SetSize(ScrW(), ScrH())
	pnl:SetPos(0, 0)
	pnl:MakePopup()
	pnl:SetMouseInputEnabled(true)
	pnl:SetKeyboardInputEnabled(false)
	pnl:SetPaintBackgroundEnabled(false)
	pnl:SetWorldClicker(false)
	pnl.Think = function(self)
		if not editor.active then return end
		if self:GetWide() ~= ScrW() or self:GetTall() ~= ScrH() then
			self:SetSize(ScrW(), ScrH())
		end
		updateCameraCursor()
		updateUiHoverSound()
	end
	editor.inputPanel = pnl
	updateCameraCursor()
end

local function stopOrbitDrag()
	editor.orbitDrag = false
end

local function stopPanDrag()
	editor.panDrag = false
end

local function panCamera(mdx, mdy)
	if mdx == 0 and mdy == 0 then return end
	local _, camAng = getEditorCam()
	local scale = editor.camDist * 0.0015
	editor.camLookAtOffset = editor.camLookAtOffset - camAng:Right() * mdx * scale + camAng:Up() * mdy * scale
	editor.camLookAtOffset = INVENTORY_CONFIG.ClampAccessoryEditorCamPan(editor.camLookAtOffset)
	markCamDirty()
end

local function restoreMugenCamera(lp)
	if not IsValid(lp) then return end
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = false end
	lp.ActiveCamera = true
end

local function assertEditorCamera(lp)
	if not IsValid(lp) or editor._cameraAsserted then return end
	lp.ActiveCamera = false
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = true end
	editor._cameraAsserted = true
end

local function removeHooks()
	hook.Remove("CalcView", "LZY_AccessoryEditor:CalcView")
	hook.Remove("CreateMove", "LZY_AccessoryEditor:Input")
	hook.Remove("HUDPaint", "LZY_AccessoryEditor:HUD")
	hook.Remove("PlayerBindPress", "LZY_AccessoryEditor:Binds")
	hook.Remove("LZY_HUD_WeaponSelector_Enabled", "LZY_AccessoryEditor:NoWeaponScroll")
	hook.Remove("OnScreenSizeChanged", "LZY_AccessoryEditor:Layout")
end

closeEditor = function(revert)
	if not editor.active then return end
	local lp = LocalPlayer()
	if revert then
		editor.pos = Vector(editor.savedPos)
		editor.ang = Angle(editor.savedAng)
		editor.scale = editor.savedScale or 1
	end
	editor.active = false
	editor.mode = "move"
	stopGizmoDrag()
	stopOrbitDrag()
	stopPanDrag()
	editor.camLookAtOffset = Vector()
	editor.inputUnlockTime = 0
	editor.bodyYaw = 0
	editor.lastMouseX = nil
	editor.lastMouseY = nil
	editor.savedStateDefault = true
	editor.userEdited = false
	editor.poseReady = false
	editor.toolbarWasDown = false
	editor.modeToggleWasDown = false
	editor.scaleSliderWasDown = false
	editor.keyGWasDown = false
	editor.keyRWasDown = false
	editor.hoverPick = nil
	editor.gizmoFrame = nil
	editor.gizmoScreen = nil
	editor._dragGizmoScreen = nil
	editor.buttons = nil
	editor.lastHoverUiTarget = nil
	editor._camCache = nil
	editor._camCacheDirty = true
	editor._cameraAsserted = false
	invalidateAccessoryModelCache()
	lastUiHoverTime = 0
	clearLivePreviewModel()
	if LZY_Character_ResetAccessoryEditorPreviewDraw then
		LZY_Character_ResetAccessoryEditorPreviewDraw()
	end
	removeHooks()
	destroyInputPanel()
	gui.EnableScreenClicker(false)
	if IsValid(lp) then
		if lp.DisableBindKeys then lp:DisableBindKeys(false) end
		restoreMugenCamera(lp)
	end
end

saveEditor = function()
	clampEditorOffsetState()
	local pos = Vector(editor.pos)
	local ang = Angle(editor.ang)
	local scale = editor.scale or 1
	local off = INVENTORY_CONFIG.AccessoryOffsetPack(pos, ang, scale)

	net.Start("server:inventory.SaveAccessoryOffset")
	net.WriteString(tostring(editor.gearSlot or ""))
	net.WriteFloat(pos.x)
	net.WriteFloat(pos.y)
	net.WriteFloat(pos.z)
	net.WriteFloat(ang.p)
	net.WriteFloat(ang.y)
	net.WriteFloat(ang.r)
	net.WriteString("")
	net.WriteFloat(scale)
	net.SendToServer()

	local data = getCharData()
	if data then
		data.equipped_accessory_offsets = data.equipped_accessory_offsets or {}
		local slotKey = tostring(editor.gearSlot)
		if INVENTORY_CONFIG.AccessoryOffsetIsDefault(off) then
			data.equipped_accessory_offsets[slotKey] = nil
			if INVENTORY_CONFIG.IsMasqueBaseSlot and INVENTORY_CONFIG.IsMasqueBaseSlot(slotKey) then
				data.masque_base_offset = nil
			end
			if INVENTORY_CONFIG.IsDivisionBodySlot and INVENTORY_CONFIG.IsDivisionBodySlot(slotKey) then
				data.division_body_offset = nil
			end
			if INVENTORY_CONFIG.IsRankOffsetSlot and INVENTORY_CONFIG.IsRankOffsetSlot(slotKey)
				and istable(data.rank_offsets) then
				data.rank_offsets[slotKey] = nil
			end
		else
			data.equipped_accessory_offsets[slotKey] = off
			if INVENTORY_CONFIG.IsMasqueBaseSlot and INVENTORY_CONFIG.IsMasqueBaseSlot(slotKey) then
				data.masque_base_offset = off
			end
			if INVENTORY_CONFIG.IsDivisionBodySlot and INVENTORY_CONFIG.IsDivisionBodySlot(slotKey) then
				data.division_body_offset = off
			end
			if INVENTORY_CONFIG.IsRankOffsetSlot and INVENTORY_CONFIG.IsRankOffsetSlot(slotKey) then
				data.rank_offsets = data.rank_offsets or {}
				data.rank_offsets[slotKey] = off
			end
		end
	end

	notify("Transform de l'accessoire enregistrée.", "ok")
	closeEditor(false)
end

local function paintToolbar()
	local w = ScrW()
	local y = toolbarY()
	if RNDX then
		RNDX.Draw(0, 0, y, w, TOOLBAR_H, ColorAlpha(COL.bg, 245))
	else
		draw.RoundedBox(0, 0, y, w, TOOLBAR_H, ColorAlpha(COL.bg, 245))
	end
	surface.SetDrawColor(COL.divider)
	surface.DrawRect(0, y, w, 1)
	local mx, my = gui.MouseX(), gui.MouseY()
	ensureToolbarButtons()
	for _, btn in ipairs(editor.buttons) do
		local hov = mx >= btn.x and mx <= btn.x + btn.w and my >= btn.y and my <= btn.y + btn.h
		if btn.filled then
			local bg = ColorAlpha(COL.accent, hov and 255 or 220)
			if RNDX then
				RNDX.Draw(R(8), btn.x, btn.y, btn.w, btn.h, bg)
			else
				draw.RoundedBox(R(8), btn.x, btn.y, btn.w,
					btn.h, bg)
			end
			draw.SimpleText(btn.label, "LZY_AccEd_Btn", btn.x + btn.w / 2, btn.y + btn.h / 2, color_white,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			if RNDX then
				RNDX.Draw(R(8), btn.x, btn.y, btn.w, btn.h, ColorAlpha(color_white, hov and 14 or 7))
				RNDX.DrawOutlined(R(8), btn.x, btn.y, btn.w, btn.h, ColorAlpha(COL.line, hov and 60 or 32), 1)
			else
				draw.RoundedBox(R(8), btn.x, btn.y, btn.w, btn.h, ColorAlpha(color_white, hov and 14 or 7))
			end
			draw.SimpleText(btn.label, "LZY_AccEd_Btn", btn.x + btn.w / 2, btn.y + btn.h / 2,
				hov and COL.title or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

local function paintEditorHUD()
	local mx, my = gui.MouseX(), gui.MouseY()
	surface.SetDrawColor(0, 0, 0, 72)
	surface.DrawRect(0, 0, ScrW(), ScrH())
	draw.SimpleText("Éditeur d'accessoire", "EVO_UI_Header", ScrW() / 2, R(80), COL.title, TEXT_ALIGN_CENTER,
		TEXT_ALIGN_CENTER)
	draw.SimpleText("G = déplacer · R = rotation · molette sur échelle · RMB = orbite · MMB = caméra", "LZY_AccEd_Sub",
		ScrW() / 2, R(100), COL.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	paintOffsetReadout()
	paintModeToggle(mx, my)
	paintScaleSlider(mx, my)
	paintWorldGizmo(mx, my)
	paintToolbar()
end

local function installHooks()
	createInputPanel()

	hook.Add("CalcView", "LZY_AccessoryEditor:CalcView", function(ply, origin, angles, fov)
		if not editor.active or ply ~= LocalPlayer() then return end
		local camPos, camAng = getEditorCam(origin)
		return { origin = camPos, angles = camAng, fov = fov, drawviewer = true, znear = 4 }
	end)

	hook.Add("CreateMove", "LZY_AccessoryEditor:Input", function(cmd)
		if not editor.active then return end
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then
			closeEditor(true)
			return
		end

		cmd:SetViewAngles(Angle(0, editor.bodyYaw or 0, 0))

		local mdx, mdy = pollMouseDelta()

		-- Fronts d'appui souris FIABLES. input.WasMousePressed/WasMouseReleased ne sont PAS fiables
		-- dans CreateMove sur un serveur DÉDIÉ : la prédiction ré-exécute CreateMove plusieurs fois par
		-- frame -> le one-shot est raté/consommé -> le drag du gizmo ne démarrait JAMAIS (offset figé à
		-- 0 = "ça bouge pas"). On reproduit le pattern déjà utilisé par la toolbar / mode-toggle ici :
		-- IsMouseDown (état, fiable) + mémorisation du front. (En local/listen CreateMove ≈ 1x/frame
		-- donc WasMousePressed marchait par chance -> bug "local OK / serveur KO".)
		local lmbDown = input.IsMouseDown(MOUSE_LEFT)
		local rmbDown = input.IsMouseDown(MOUSE_RIGHT)
		local mmbDown = input.IsMouseDown(MOUSE_MIDDLE)
		local lmbPressed, lmbReleased = (lmbDown and not editor._lmbDownPrev), ((not lmbDown) and editor._lmbDownPrev)
		local rmbPressed, rmbReleased = (rmbDown and not editor._rmbDownPrev), ((not rmbDown) and editor._rmbDownPrev)
		local mmbPressed, mmbReleased = (mmbDown and not editor._mmbDownPrev), ((not mmbDown) and editor._mmbDownPrev)
		editor._lmbDownPrev, editor._rmbDownPrev, editor._mmbDownPrev = lmbDown, rmbDown, mmbDown

		if mouseInputAllowed() then
			pollModeKeys()

			if input.WasMousePressed(MOUSE_WHEEL_UP) then
				if pointerOverScaleSlider() then
					local bMin, bMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind) local step = (bMax - bMin) * 0.05
					editor.scale = INVENTORY_CONFIG.ClampAccessoryOffsetScale((editor.scale or 1) + step, editor.limitKind)
					editor.userEdited = true
				else
					zoomCamera(1)
				end
			elseif input.WasMousePressed(MOUSE_WHEEL_DOWN) then
				if pointerOverScaleSlider() then
					local bMin, bMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind) local step = (bMax - bMin) * 0.05
					editor.scale = INVENTORY_CONFIG.ClampAccessoryOffsetScale((editor.scale or 1) - step, editor.limitKind)
					editor.userEdited = true
				else
					zoomCamera(-1)
				end
			end
		end

		if pointerOverToolbar() then
			handleToolbarInput()
		elseif handleModeToggleInput() then
		elseif handleScaleSliderInput() then
		elseif mouseInputAllowed() then
			if lmbPressed and not pointerOverEditorUI() then
				tryStartGizmoDrag()
			elseif rmbPressed and not editor.axisDragActive then
				editor.orbitDrag = true
			elseif mmbPressed and not editor.axisDragActive then
				editor.panDrag = true
			end
		end

		if mouseInputAllowed() then
			updateGizmoDrag()

			if lmbReleased then
				stopGizmoDrag()
			elseif rmbReleased then
				stopOrbitDrag()
			elseif mmbReleased then
				stopPanDrag()
			end

			if editor.orbitDrag and input.IsMouseDown(MOUSE_RIGHT) then
				if mdx ~= 0 then editor.camYaw = editor.camYaw - mdx * 0.35 end
				if mdy ~= 0 then editor.camPitch = editor.camPitch + mdy * 0.25 end
				clampEditorCameraState()
			end

			if editor.panDrag and input.IsMouseDown(MOUSE_MIDDLE) then
				panCamera(mdx, mdy)
			end
		end

		cmd:ClearButtons()
		cmd:ClearMovement()
	end)

	hook.Add("HUDPaint", "LZY_AccessoryEditor:HUD", function()
		if not editor.active then return end
		paintEditorHUD()
	end)

	hook.Add("PlayerBindPress", "LZY_AccessoryEditor:Binds", function(ply, bind, pressed)
		if not editor.active or ply ~= LocalPlayer() or not pressed then return end
		local b = string.lower(bind)
		if b == "+reload" or b == "reload" then
			setTransformMode("rotate")
			return true
		end
		if b == "phys_swap" or b == "gmod_tool" then
			setTransformMode("move")
			return true
		end
		if b == "invnext" or b == "+invnext" or b == "mwheeldown" then
			if pointerOverScaleSlider() then
				local bMin, bMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind) local step = (bMax - bMin) * 0.05
				editor.scale = INVENTORY_CONFIG.ClampAccessoryOffsetScale((editor.scale or 1) - step, editor.limitKind)
				editor.userEdited = true
			else
				zoomCamera(-1)
			end
			return true
		end
		if b == "invprev" or b == "+invprev" or b == "mwheelup" then
			if pointerOverScaleSlider() then
				local bMin, bMax = INVENTORY_CONFIG.AccessoryScaleBounds(editor.limitKind) local step = (bMax - bMin) * 0.05
				editor.scale = INVENTORY_CONFIG.ClampAccessoryOffsetScale((editor.scale or 1) + step, editor.limitKind)
				editor.userEdited = true
			else
				zoomCamera(1)
			end
			return true
		end
		if b == "+attack3" or b == "attack3" then
			return true
		end
	end, 100)

	hook.Add("LZY_HUD_WeaponSelector_Enabled", "LZY_AccessoryEditor:NoWeaponScroll", function()
		if editor.active then return false end
	end)

	hook.Add("OnScreenSizeChanged", "LZY_AccessoryEditor:Layout", function()
		if not editor.active then return end
		editor.buttons = nil
	end)
end

function LZY_AccessoryEditor_Open(gearSlot)
	if editor.active then closeEditor(true) end
	if combatBlocked(gearSlot) then return false end

	local lp = LocalPlayer()
	if not IsValid(lp) then return false end

	local isMasqueBase = INVENTORY_CONFIG.IsMasqueBaseSlot and INVENTORY_CONFIG.IsMasqueBaseSlot(gearSlot)
	local isDivisionBody = INVENTORY_CONFIG.IsDivisionBodySlot and INVENTORY_CONFIG.IsDivisionBodySlot(gearSlot)
	local isGrade = INVENTORY_CONFIG.IsGradeSlot and INVENTORY_CONFIG.IsGradeSlot(gearSlot)
	local isRankOffset = INVENTORY_CONFIG.IsRankOffsetSlot and INVENTORY_CONFIG.IsRankOffsetSlot(gearSlot)
	local itemId = nil

	if isDivisionBody then
		gearSlot = INVENTORY_CONFIG.DIVISION_BODY_SLOT or "division_body"
		local divPath = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankDivisionBody
			and LZY_CHARACTER_CONFIG.GetRankDivisionBody(
				lp:GetEvoNWString("FactionName", ""),
				lp:GetEvoNWInt("FactionRank", 0),
				lp:GetEvoNWInt("FactionDivision", 0))
		if not isstring(divPath) or divPath == "" then
			notify("Aucun accessoire de division à éditer.", "error")
			return false
		end
		-- Masqué par la coche dédiée : rien ne s'afficherait dans l'éditeur,
		-- autant le dire plutôt que d'ouvrir une scène vide.
		if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody
			and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(getCharData()) then
			notify("Décoche « Cacher la tenue de division » pour éditer cet accessoire.", "error")
			return false
		end
	elseif isMasqueBase then
		gearSlot = INVENTORY_CONFIG.MASQUE_BASE_SLOT or "masque_base"
		if lp:GetEvoNWString("FactionName", "") ~= "Hollow" then
			notify("Masque de base réservé aux Hollow.", "error")
			return false
		end
		local dataCheck = getCharData()
		if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasBoughtMask
			and LZY_CHARACTER_CONFIG.CharacterHasBoughtMask(dataCheck) then
			notify("Équipe le masque inventaire pour l'éditer.", "error")
			return false
		end
		local rank = lp:GetEvoNWInt("FactionRank", 0)
		local masquePath = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetArrancarMaskModel
			and LZY_CHARACTER_CONFIG.GetArrancarMaskModel("Hollow", rank)
		if not isstring(masquePath) or masquePath == "" then
			notify("Aucun masque de base à éditer.", "error")
			return false
		end
	elseif isGrade then
		gearSlot = INVENTORY_CONFIG.GRADE_SLOT or "grade"
		-- Masquée par la coche dédiée : rien ne s'afficherait dans l'éditeur.
		if lp:GetEvoNWBool("EVO_HideEpaulette", false) then
			notify("Décoche « Cacher l'épaulette » pour éditer cet accessoire.", "error")
			return false
		end
		local epPath = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankEpauletteModel
			and LZY_CHARACTER_CONFIG.GetRankEpauletteModel(
				lp:GetEvoNWString("FactionName", ""),
				lp:GetEvoNWInt("FactionRank", 0))
		if not isstring(epPath) or epPath == "" then
			notify("Aucune épaulette de grade à éditer.", "error")
			return false
		end
	elseif isRankOffset then
		gearSlot = tostring(gearSlot)
		local path = INVENTORY_CONFIG.ResolveRankCosmeticModel
			and INVENTORY_CONFIG.ResolveRankCosmeticModel(lp, gearSlot)
		if not isstring(path) or path == "" then
			notify("Aucun accessoire de grade à éditer.", "error")
			return false
		end
		if INVENTORY_CONFIG.IsRankCosmeticHidden and INVENTORY_CONFIG.IsRankCosmeticHidden(lp, gearSlot) then
			notify("Décoche « Cacher la tenue de grade » pour éditer cet accessoire.", "error")
			return false
		end
	else
		gearSlot = tonumber(gearSlot) or 0
		local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
		-- MAX_GEAR_SLOT (7) : le slot MASQUE est éditable (rotation aux bornes standard, comme tout le reste, 07/24).
		if gearSlot < 1 or gearSlot > (INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) or gearSlot == outfitSlot then return false end

		local eq = lp.GetInventoryEquippedItems and lp:GetInventoryEquippedItems() or {}
		itemId = eq[tostring(gearSlot)]
		local it = itemId and ITEMS and ITEMS[itemId]
		if not it or it.category ~= "accessory" or not isstring(it.model_path) or it.model_path == "" then
			notify("Cet accessoire ne peut pas être édité.", "error")
			return false
		end
	end

	local data = getCharData()
	local offTbl = data and data.equipped_accessory_offsets and data.equipped_accessory_offsets[tostring(gearSlot)]
	if isMasqueBase and (not offTbl) and data and istable(data.masque_base_offset) then
		offTbl = data.masque_base_offset
	end
	if isDivisionBody and (not offTbl) and data and istable(data.division_body_offset) then
		offTbl = data.division_body_offset
	end
	if isGrade and (not offTbl) and data and istable(data.epaulette_offset) then
		offTbl = data.epaulette_offset
	end
	if isRankOffset and (not offTbl) and data and istable(data.rank_offsets) then
		offTbl = data.rank_offsets[tostring(gearSlot)]
	end
	local v = INVENTORY_CONFIG.AccessoryOffsetToBodyLocal(offTbl)
	local a = INVENTORY_CONFIG.AccessoryOffsetToBodyLocalAngle(offTbl)
	local s = INVENTORY_CONFIG.AccessoryOffsetToScale(offTbl)
	editor.savedStateDefault = INVENTORY_CONFIG.AccessoryOffsetIsDefault(offTbl)

	editor.active = true
	editor.gearSlot = gearSlot
	editor.limitKind = isGrade and "grade" or nil -- épaulette : marge élargie (10/01)
	editor.itemId = itemId -- passé à ClampAccessoryOffsetAng (bornes uniformes ±5, cf. clampEditorOffsetState)
	editor.mode = "move"
	editor.pos = Vector(v)
	editor.savedPos = Vector(v)
	editor.ang = Angle(a)
	editor.savedAng = Angle(a)
	editor.scale = s
	editor.savedScale = s
	clampEditorOffsetState()
	editor.savedPos = Vector(editor.pos)
	editor.savedAng = Angle(editor.ang)
	editor.savedScale = editor.scale
	stopGizmoDrag()
	stopOrbitDrag()
	stopPanDrag()
	editor.bodyYaw = lp:EyeAngles().y
	editor.camYaw = editor.bodyYaw
	editor.camPitch = 14
	editor.camLookAtOffset = Vector()
	editor.inputUnlockTime = CurTime() + 0.3
	editor.camDist = 95
	clampEditorCameraState()
	editor.lastMouseX = gui.MouseX()
	editor.lastMouseY = gui.MouseY()
	editor.userEdited = not editor.savedStateDefault
	editor.poseReady = true
	editor.scaleSliderWasDown = false

	assertEditorCamera(lp)
	if lp.DisableBindKeys then lp:DisableBindKeys(true) end
	gui.EnableScreenClicker(true)
	rebuildToolbarButtons()
	installHooks()

	local function tryFindAccessory(attempt)
		if not editor.active then return end
		if LZY_Character_EnsureAccessoryModelForSlot then
			LZY_Character_EnsureAccessoryModelForSlot(lp, gearSlot)
		end
		local found = IsValid(getAccessoryModel())
		if not found and attempt < 8 then
			timer.Simple(0.15, function() tryFindAccessory(attempt + 1) end)
			return
		end
		if not found then
			notify("Accessoire introuvable sur le personnage.", "error")
			closeEditor(true)
			return
		end
	end
	timer.Simple(0, function() tryFindAccessory(0) end)

	return true
end
