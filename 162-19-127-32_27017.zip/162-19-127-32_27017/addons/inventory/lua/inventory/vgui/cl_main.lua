-- "addons\\inventory\\lua\\inventory\\vgui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local frame = nil
local can_open = true

-- ════════════════════════════════════════════════════════════════════════════
-- PRESETS D'ÉQUIPEMENT — cache + API client (FUSIONNÉ ICI 2026-07-17).
-- Auparavant dans un fichier séparé cl_presets.lua, mais un NOUVEAU fichier client
-- ne se transférait pas de façon fiable au client (fragilité CS-Lua connue de ce
-- projet, cf. reference_csllua_loader_limit) -> LZY_InvPresets restait nil et TOUS
-- les clics des presets tombaient dans le vide. cl_main.lua, lui, arrive toujours
-- chez le client -> on met le code ICI. Serveur = sv_presets.lua (include, fiable).
-- ════════════════════════════════════════════════════════════════════════════
LZY_InvPresets = LZY_InvPresets or {}

local presetCache = {} -- { ["1"]={ ["1"]=id,... }, ["2"]={...}, ["3"]={...} }

function LZY_InvPresets.Get(idx)
	if idx == nil then return presetCache end
	return presetCache[tostring(idx)] or {}
end

function LZY_InvPresets.IsFilled(idx)
	return next(LZY_InvPresets.Get(idx)) ~= nil
end

function LZY_InvPresets.Request()
	net.Start("EVO:Inv:Presets:Request")
	net.SendToServer()
end

function LZY_InvPresets.Apply(idx)
	net.Start("EVO:Inv:Presets:Apply")
	net.WriteUInt(idx, 8)
	net.SendToServer()
end

function LZY_InvPresets.Save(idx)
	net.Start("EVO:Inv:Presets:Save")
	net.WriteUInt(idx, 8)
	net.SendToServer()
end

function LZY_InvPresets.Clear(idx)
	net.Start("EVO:Inv:Presets:Clear")
	net.WriteUInt(idx, 8)
	net.SendToServer()
end

net.Receive("EVO:Inv:Presets:Sync", function()
	local parsed = util.JSONToTable(net.ReadString() or "{}")
	-- Re-stringifie les clés aux 2 niveaux (l'aller-retour JSON peut les rendre numériques,
	-- cf. cl_net.lua). Sans ça, Get("1")/p["2"] seraient nil.
	local out = {}
	if istable(parsed) then
		for k, v in pairs(parsed) do
			if istable(v) then
				out[tostring(k)] = (INVENTORY_CONFIG and INVENTORY_CONFIG.NormalizeEquippedKeysForClient
					and INVENTORY_CONFIG.NormalizeEquippedKeysForClient(v)) or v
				-- La normalisation des slots retire les métadonnées. Garder le marqueur
				-- permet d'appliquer un preset enregistré sans aucun objet équipé.
				if v.set == "1" then out[tostring(k)].set = "1" end
			end
		end
	end
	presetCache = out
	hook.Run("EVO::InvPresetsUpdated")
end)

-- Fond DA Atelier (08/07, revu) : image dédiée bc_inventaire, SANS zoom (pas
-- de cover/contain-crop, cover-crop retiré) — juste flouée (layer blur
-- EVO_UI.GhostBlur). Chaîne de secours png -> jpg -> sans extension.
local bgInv = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc_inventaire.png", "smooth")
if bgInv:IsError() then bgInv = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc_inventaire.jpg", "smooth") end
if bgInv:IsError() then bgInv = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/bc_inventaire", "smooth") end

local materials = {
	bg = Material("u8vokkrj1ohi9uuy/yhxq4o8jdt6lna.png", "smooth"),                 -- 1920x1080 (plus dessiné — remplacé par le fond DA)
	close = Material("u8vokkrj1ohi9uuy/wkgtbq3b2ps957ic.png", "smooth"),            -- 60x60
	category = Material("u8vokkrj1ohi9uuy/8v6kg74f5blodm4r.png", "smooth"),         -- 150x44
	category_hover = Material("u8vokkrj1ohi9uuy/dbhrfwahjptw75xt.png", "smooth"),   -- 150x44
	slot = Material("u8vokkrj1ohi9uuy/fy5nzukicuoqnhrho.png", "smooth"),            -- 150x150
	slot_hover = Material("u8vokkrj1ohi9uuy/kt3ykzq4lkqe7r.png", "smooth"),         -- 150x150
	slot_hover_blue = Material("u8vokkrj1ohi9uuy/5k4erhy15f1p2p.png", "smooth"),    -- 150x150
	slot_hover_green = Material("u8vokkrj1ohi9uuy/o5rbb9drof65ia27.png", "smooth"), -- 150x150
	slot_hover_red = Material("u8vokkrj1ohi9uuy/u5ux6qr12q8vmq.png", "smooth"),     -- 150x150
	slot_hover_purple = Material("u8vokkrj1ohi9uuy/68r7xc7jv28ssky.png", "smooth"), -- 150x150
	slot_hover_yellow = Material("u8vokkrj1ohi9uuy/dies37412u1phf95.png", "smooth"), -- 150x150
	equipement_slot = Material("u8vokkrj1ohi9uuy/hm3i286d6slt.png", "smooth"),      -- 150x150
	slot_icon_katana = Material("u8vokkrj1ohi9uuy/ema7bphwqiflwb.png", "smooth"),   -- 100x100
	slot_icon_head = Material("u8vokkrj1ohi9uuy/2w67mclhzuyi3khlz.png", "smooth"),  -- 100x100
	slot_icon_outfit = Material("u8vokkrj1ohi9uuy/c8b44vq00vdc.png", "smooth"),     -- 100x100
	slot_icon_mask = Material("y9evfrcxcxxo48/icone_masque.png", "smooth"),         -- masque Arrancar (slot 7, user 07/23)
	slot_icon_cape = Material("u8vokkrj1ohi9uuy/ko15q0d1ceajv3ucn.png", "smooth"),  -- 100x100
	slot_icon_necklace = Material("u8vokkrj1ohi9uuy/cno8mbztjbtd4lzck.png", "smooth"), -- 100x100
	slot_icon_ring = Material("u8vokkrj1ohi9uuy/7xj062mmpp216r.png", "smooth"),     -- 100x100
	slot_icon_belt = Material("u8vokkrj1ohi9uuy/hrxfhk1qr0ehem7fa.png", "smooth"),  -- 100x100
}

-- ════════════════════════════════════════════════════════════════════════════
-- DISPOSITION (design 1920x1080) — PORTEE DE L'INVENTAIRE evo-ds (demande user 09/03).
-- L'inventaire n'est plus plein ecran : c'est un PANNEAU CENTRE, le jeu reste visible
-- autour de lui. A gauche le sac, a droite le personnage entoure de son equipement,
-- STATS / SETS en bas a droite, coches sous le sac.
-- La zone « personnage » est un TROU : le VRAI joueur y est cadre par la camera
-- (hooks CalcView / ShouldDrawLocalPlayer en fin de fichier), pas un modele client.
-- ⚠ TOUT dans UNE table : LuaJIT plafonne a 60 upvalues par fonction, et PANEL:Init
-- en frole deja la limite (c'est la raison du regroupement cote evo-ds aussi).
-- ⚠ Le LOOK n'a PAS ete porte : on garde nos PNG workshop et la DA Atelier, la
-- version evo-ds etant sur une autre DA (Aurora) absente de ce depot.
-- ════════════════════════════════════════════════════════════════════════════
local INV = {}
-- Panneau centre : 295 + 1330 + 295 = 1920, 170 + 740 + 170 = 1080.
INV.PX, INV.PY, INV.PW, INV.PH = 295, 170, 1330, 740
INV.PAD = 21
-- Sac : 5 colonnes de 120 (nos cases PNG rendent a n'importe quelle taille), 4 rangees
-- visibles = 20 cases a l'ecran, soit PLUS que les ~16 d'avant malgre le panneau reduit.
INV.CELL, INV.GAP, INV.COLS = 110, 14, 5
INV.ROWS_VISIBLE = 4
INV.GRID_X, INV.GRID_Y = INV.PX + INV.PAD, INV.PY + 180
INV.GRID_W = INV.COLS * INV.CELL + (INV.COLS - 1) * INV.GAP                   -- 606
INV.GRID_H = INV.ROWS_VISIBLE * INV.CELL + (INV.ROWS_VISIBLE - 1) * INV.GAP   -- 482
INV.SEARCH_W = INV.GRID_W  -- la barre fait exactement la largeur du sac
-- Titre, puis BARRE DE RECHERCHE, puis rangee de categories, au-dessus du sac.
INV.TITLE_X, INV.TITLE_Y = INV.PX + INV.PAD, INV.PY + 42
INV.SEARCH_X, INV.SEARCH_Y, INV.SEARCH_H = INV.PX + INV.PAD, INV.PY + 78, 36
INV.CATS_X, INV.CATS_Y = INV.PX + INV.PAD, INV.PY + 126
INV.CAT_N, INV.CAT_H, INV.CAT_GAP = 4, 44, 15
-- Onglets : même largeur totale que la rangée de 5 cases (reste éventuel sur le dernier).
INV.CAT_W = math.floor((INV.GRID_W - (INV.CAT_N - 1) * INV.CAT_GAP) / INV.CAT_N)
-- Colonne de droite : equipement autour de la zone personnage.
INV.EQUIP_PX = 110
INV.EQUIP_GAP = 30
INV.EQUIP_STEP = INV.EQUIP_PX + INV.EQUIP_GAP
-- Zone personnage : agrandie (les cartes STATS / SETS sont sorties du panneau), mais
-- elle s'arrete au-dessus des coches qui reviennent juste en dessous.
-- La colonne de coches fait 5 x 30 = 150 px : le trou demarre en dessous. La hauteur
-- perdue ici est LARGEMENT reprise par le cadrage (INV_CAM_Z, en fin de fichier), qui
-- fait remonter le personnage DANS le trou.
INV.VP_X, INV.VP_Y, INV.VP_W, INV.VP_H = INV.PX + 855, INV.PY + 320, 300, 400
-- TENUE a gauche (tete / tenue / cape), ACCESSOIRES a droite (collier / anneau /
-- ceinture) : 3 par colonne, centrees sur le personnage.
INV.EQUIP_POS = {
	[1] = { INV.PX + 706, INV.PY + 200 }, [2] = { INV.PX + 706, INV.PY + 200 + INV.EQUIP_STEP }, [3] = { INV.PX + 706, INV.PY + 200 + 2 * INV.EQUIP_STEP },
	[4] = { INV.PX + 1194, INV.PY + 200 }, [5] = { INV.PX + 1194, INV.PY + 200 + INV.EQUIP_STEP }, [6] = { INV.PX + 1194, INV.PY + 200 + 2 * INV.EQUIP_STEP },
	[7] = { INV.PX + 950, INV.PY + 44 },
	[8] = { INV.PX + 1070, INV.PY + 44 }, -- FOURREAU (09/30) : à droite du masque
	[9] = { INV.PX + 1194, INV.PY + 200 + 3 * INV.EQUIP_STEP }, -- COMPAGNON (10/06) : sous la colonne des accessoires
}
-- Katana + masque + fourreau : rangée CENTRÉE au-dessus du personnage (milieu du trou =
-- PX + 1005 ; 3 cases de 110 + 2 écarts de 10 = 350 -> départ PX + 830).
INV.KATANA_POS = { INV.PX + 830, INV.PY + 44 }
-- Coches « cacher ... » : à GAUCHE du slot d'arme (katana / gantelet).
-- Elles pilotent ce qu'on masque SUR LE PERSONNAGE (cheveux, epaulette, tenue de grade,
-- accessoire de division).
-- DEUX COLONNES de 3 : empilees sur une seule, les 6 coches possibles depassaient.
INV.CHECKS_STEP = 30
-- UNE SEULE COLONNE (user 09/03 : « ils doivent etre en colonne, un a la suite »).
-- CHECKS_PER_COL est volontairement plus grand que le nombre de coches possibles (6) :
-- la boucle de placement ne passera donc JAMAIS a une 2e colonne.
-- Leave a left margin after the bag; keep the right edge 8 px from the weapon slot.
INV.CHECKS_LEFT_GAP = 14
INV.CHECKS_COL_W, INV.CHECKS_PER_COL, INV.CHECK_W = 200, 99, 195 - INV.CHECKS_LEFT_GAP
-- Coches à GAUCHE de l'arme : bord droit collé au slot, haut aligné sur le slot.
-- Le relayout (InvRelayoutHideChecks) empile les coches visibles vers le bas.
INV.CHECKS_X = INV.KATANA_POS[1] - INV.CHECK_W - 8
INV.CHECKS_Y = INV.KATANA_POS[2]
-- STATS / SETS : EN DEHORS du panneau, en colonne dans la marge DROITE (user 09/03).
-- Elles flottent donc sur le decor du jeu : c'est volontaire, leur fond est quasi
-- opaque (BSTAT_COL_CARD alpha 246), inutile d'ajouter un flou derriere.
-- ⚠ Ces deux cartes sont les SEULS elements hors panneau : les tests de disposition
-- les excluent du « tout doit tenir dans le panneau » mais verifient qu'elles restent
-- a l'ecran et ne mordent pas sur le panneau.
INV.SIDE_X = INV.PX + INV.PW + 16                 -- colle a droite du panneau
INV.SIDE_W = 1920 - INV.SIDE_X - 16               -- jusqu'au bord de l'ecran
-- STATS plus HAUTE : etroite, elle passe a 2 colonnes donc 5 rangees de tuiles.
INV.STATS_X, INV.STATS_Y, INV.STATS_W, INV.STATS_H = INV.SIDE_X, INV.PY + 30, INV.SIDE_W, 360
INV.SETS_X,  INV.SETS_Y,  INV.SETS_W,  INV.SETS_H  = INV.SIDE_X, INV.PY + 400, INV.SIDE_W, 200
INV.CLOSE_X, INV.CLOSE_Y, INV.CLOSE_PX = INV.PX + INV.PW - 58, INV.PY + 16, 40
-- Bouton d'édition : même largeur et même espacement que les slots, sous la cape (3).
INV.GRADE_BTN_W, INV.GRADE_BTN_H = INV.EQUIP_PX, 54
INV.GRADE_BTN_X = INV.EQUIP_POS[3][1]
INV.GRADE_BTN_Y = INV.EQUIP_POS[3][2] + INV.EQUIP_STEP

-- CAMERA DE L'INVENTAIRE : distance (molette), orbite (glisser sur le personnage) et
-- transition a l'ouverture. Remis a zero a chaque ouverture (PANEL:Init).
-- dist 120 = arrivee ZOOMEE sur le personnage (user 09/03 : « plus zoomé »).
local INV_CAM = { dist = 120, yaw = 0, pitch = 0, t0 = 0 }
-- Bornes de l'elevation : au-dela on basculerait par-dessus la tete ou sous les pieds,
-- et l'image se retournerait. On s'arrete franchement avant.
local INV_CAM_PITCH_MIN, INV_CAM_PITCH_MAX = -55, 60
-- Duree du mouvement de camera. L'INTERFACE N'APPARAIT QU'APRES (user 09/03 :
-- « d'abord la caméra tourne, ensuite ça te met l'inventaire ») : cf. PANEL:Think.
-- ARRIVEE EN ORBITE = recette evo-ds reprise a l'identique (user 09/07) : coupe franche
-- DERRIERE le personnage (yaw +INV_CAM_INTRO_YAW, distance INV_CAM_INTRO_DIST), puis
-- demi-tour ease-out jusqu'au cadrage de face pendant que la distance se resserre a
-- INV_CAM.dist. Aucun fondu depuis la vue du joueur (la variante « depuis la vue du
-- joueur en tournant » du 05/09 avait ete jugee bizarre ; celle-ci est celle d'evo-ds).
local INV_CAM_INTRO      = 0.9
local INV_CAM_INTRO_YAW  = 180
local INV_CAM_INTRO_DIST = 150
-- Interrupteur joueur (menu Actions Rapides du gamemode, cl_context_menu.lua) : a 0 la
-- camera se pose directement sur le cadrage de face, sans demi-tour, et l'interface
-- apparait tout de suite. Archive : le choix survit aux sessions.
CreateClientConVar("evo_inv_cam_orbite", "1", true, false,
	"Camera tournante a l'ouverture de l'inventaire (1) ou cadrage direct (0)")
local function InvCamOrbiteActive()
	local cv = GetConVar("evo_inv_cam_orbite")
	return not cv or cv:GetInt() > 0
end
local INV_UI_FADE   = 0.28

-- Flou + voile BORNES AU PANNEAU : en dehors du contour le jeu reste normal.
local COL_INV_WHITE = Color(255, 255, 255, 255)
local COL_INV_VEIL  = Color(10, 10, 14, 214) -- le decor floute reste devinable dessous
local COL_INV_SCREEN = Color(8, 8, 12, 120)  -- voile LEGER sur le reste de l'ecran
local INV_BLUR_PASSES = 3

-- Le VRAI joueur dessine NET par-dessus le panneau floute, avec la vue posee par le
-- CalcView ci-dessous. ClearDepth : jamais masque par le decor qui passerait devant.
-- ⚠ PIEGE MAJEUR DE CE DEPOT (corrige 09/03) : le personnage est COMPOSITE. lzy_character
-- pose ply.RenderOverride et met TOUTES les parts (corps, tenue, cheveux, barbe,
-- accessoires) en SetNoDraw(true) (convar lzy_parts_singledraw = 1). Or :
--   * un lp:DrawModel() appele depuis du Lua ne repasse PAS par RenderOverride ;
--   * le modele du JOUEUR est le modele de VISAGE (le corps vient de body_model).
-- Un simple DrawModel + boucle sur GetChildren ne dessinait donc qu'une TETE FLOTTANTE,
-- et le filtre « not GetNoDraw » eliminait justement toutes les parts. On passe par le
-- helper que le projet expose pour exactement ce cas (deja utilise par evo_staff).
local function invDrawLocalPlayerSharp()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	lp:SetupBones()
	cam.Start3D()
		render.ClearDepth()
		if LZY_Character_ForceDrawPlayerComposite then
			LZY_Character_ForceDrawPlayerComposite(lp)
		else
			lp:DrawModel() -- repli : mieux que rien si lzy_character n'est pas charge
		end
		-- Katana range : ClientsideModel en NoDraw, dessine a la main dans PostPlayerDraw,
		-- hook qui ne tourne pas depuis un DrawModel manuel. On appelle CE hook precis par
		-- son nom — surtout PAS hook.Run("PostPlayerDraw"), qui declencherait aussi les
		-- nametags, halos et autres addons hors de leur contexte de rendu.
		local tHooks = hook.GetTable()["PostPlayerDraw"]
		local fKatana = tHooks and tHooks["EVO::DrawSheathedKatana"]
		if fKatana then fKatana(lp) end
	cam.End3D()
end

-- Rarity → hover frame (gray uses default slot_hover per INVENTORY_CONFIG.raritiesColor)
local RARITY_COLOR_TO_SLOT_HOVER = {
	gray = materials.slot_hover,
	green = materials.slot_hover_green,
	blue = materials.slot_hover_blue,
	purple = materials.slot_hover_purple,
	yellow = materials.slot_hover_yellow,
	red = materials.slot_hover_red,
}

-- Same keys as INVENTORY_CONFIG.raritiesColor values (tier label color in tooltips)
local RARITY_COLOR_KEY_TO_TEXT_COLOR = {
	gray = Color(176, 176, 184, 255),
	green = Color(100, 220, 140, 255),
	blue = Color(110, 170, 255, 255),
	purple = Color(200, 130, 255, 255),
	yellow = Color(255, 210, 90, 255),
	red = Color(255, 95, 95, 255),
}

local function GetRarityTierTextColor(rarity)
	local cfg = INVENTORY_CONFIG and INVENTORY_CONFIG.raritiesColor
	local rk = isstring(rarity) and string.lower(rarity) or ""
	local colorKey = (cfg and cfg[rk]) or "gray"
	return RARITY_COLOR_KEY_TO_TEXT_COLOR[colorKey] or RARITY_COLOR_KEY_TO_TEXT_COLOR.gray
end

-- ════════════════════════════════════════════════════════════════════════════
-- STATS BONUS DU PERSONNAGE (carte en BAS de la colonne de preview).
-- Ce sont les bonus qui s'ajoutent EN PLUS du grade (skilltree + points généraux +
-- équipement + buffs + métiers) — calculés serveur (self.stats = server-only), poussés à la
-- demande via EVO:Inventory:BonusStats. Ordre = miroir de net.lua (INV_BONUS_STAT_ORDER).
-- ════════════════════════════════════════════════════════════════════════════
local BONUS_STAT_ORDER = { "hp", "katana", "spell", "reiatsu", "crit_chance", "crit_dmg", "dodge", "flash_cd", "flash_range" }
local bonusStats = {}            -- clé -> valeur (% effectif)
local bonusStatsEnch = {}        -- clé -> true si boostée par un ENCHANTEMENT porté (masque serveur)
local bonusStatsReceived = false

net.Receive("EVO:Inventory:BonusStats", function()
	for _, k in ipairs(BONUS_STAT_ORDER) do
		bonusStats[k] = net.ReadFloat()
	end
	local mask = net.ReadUInt(9)
	for i, k in ipairs(BONUS_STAT_ORDER) do
		bonusStatsEnch[k] = bit.band(mask, bit.lshift(1, i - 1)) ~= 0
	end
	bonusStatsReceived = true
end)

local function RequestBonusStats()
	net.Start("EVO:Inventory:ReqBonusStats")
	net.SendToServer()
end

-- Métadonnées d'affichage (grille 3×3, ordre de lecture). mode : true = signe +/- ;
-- false = valeur brute (chance) ; "neg" = réduction affichée en -X%.
-- Couleurs : 9 teintes CATÉGORIELLES maximalement distinctes (vert/rouge/violet/bleu/or/
-- orange/turquoise/magenta/lime), validées par le validateur dataviz sur fond sombre
-- (bande de clarté L 0.48–0.67, chroma, contraste ≥3:1 OK ; séparation normale ΔE ~35).
-- L'identité reste portée AUSSI par le libellé texte + la barre d'accent (jamais couleur seule).
local BONUS_STATS_DISPLAY = {
	{ key = "hp",          label = "PV",            col = Color(31, 157, 85),   mode = true  }, -- vert
	{ key = "katana",      label = "DÉGÂTS D'ARME", col = Color(216, 67, 63),   mode = true  }, -- rouge
	{ key = "spell",       label = "DÉGÂTS SORT",   col = Color(154, 103, 221), mode = true  }, -- violet
	{ key = "reiatsu",     label = "REIATSU",       col = Color(39, 101, 184),  mode = true  }, -- bleu
	{ key = "crit_chance", label = "CHANCE CRIT.",  col = Color(184, 137, 15),  mode = false }, -- or
	{ key = "crit_dmg",    label = "DÉGÂTS CRIT.",  col = Color(217, 102, 42),  mode = false }, -- orange
	{ key = "dodge",       label = "ESQUIVE",       col = Color(15, 148, 136),  mode = false }, -- turquoise
	{ key = "flash_cd",    label = "CD FLASHSTEP",  col = Color(207, 68, 153),  mode = "neg" }, -- magenta
	{ key = "flash_range", label = "PORTÉE FLASH.", col = Color(127, 160, 24),  mode = true  }, -- lime
}

-- Formatte une valeur : 1 décimale max (trim des .0), signe selon le mode.
local function FmtBonusStat(v, mode)
	v = tonumber(v) or 0
	local r = math.Round(v * 10) / 10
	local a = math.abs(r)
	local num = (a == math.floor(a)) and tostring(math.floor(a)) or string.format("%.1f", a)
	if mode == "neg" then
		return (r > 0 and "-" or "") .. num .. "%"
	elseif mode == true then
		return ((r > 0 and "+") or (r < 0 and "-") or "") .. num .. "%"
	end
	return num .. "%"
end

-- Carte "Statistiques" (bas de la colonne perso) : ambiance CALME et COLORÉE — fond profond
-- légèrement bleuté (pas de gris/métal), tuiles arrondies avec un VOILE de couleur par stat
-- (dégradé doux) + reflet supérieur discret. 100 % VGUI/RNDX. Modèle raccourci (vpH) pour la place.
local GRAD_D = Material("vgui/gradient-d") -- opaque en haut -> transparent en bas
local GRAD_TEX = (GRAD_D and not GRAD_D:IsError()) and GRAD_D:GetTexture("$basetexture") or nil

-- Éclaircit une couleur vers le blanc (f=0 inchangé .. 1 blanc) : la valeur ressort sur
-- le voile coloré de sa propre tuile. Appelé au CHARGEMENT uniquement (précalculs).
local function lightenCol(c, f)
	return Color(c.r + (255 - c.r) * f, c.g + (255 - c.g) * f, c.b + (255 - c.b) * f)
end

-- PERF : toutes les couleurs du dessin sont PRÉCALCULÉES (module-locales / par stat) —
-- aucune alloc Color() par frame dans DrawBonusStatsCard (même règle que le spell selector).
local BSTAT_COL_CARD    = Color(20, 20, 28, 246)   -- fond carte bleu-nuit
local BSTAT_COL_GLOSS7  = Color(255, 255, 255, 7)  -- reflet haut de carte
local BSTAT_COL_GLOSS10 = Color(255, 255, 255, 10) -- reflet haut de tuile
local BSTAT_COL_TILE    = Color(30, 30, 39, 255)   -- base de tuile
local BSTAT_COL_TITLE   = Color(236, 238, 245)
local BSTAT_COL_SLASH   = Color(207, 68, 78, 230)
local BSTAT_COL_LABEL   = Color(210, 212, 220)
local BSTAT_COL_DIM     = Color(120, 124, 132)     -- valeur à 0 / pas encore reçue
local BSTAT_COL_OUTLINE = Color(0, 0, 0, 150)
-- Précalcul par stat : voile (alpha selon présence du dégradé) + couleur de valeur éclaircie.
for _, st in ipairs(BONUS_STATS_DISPLAY) do
	st.washCol = GRAD_TEX and Color(st.col.r, st.col.g, st.col.b, 66)
		or Color(st.col.r, st.col.g, st.col.b, 36)
	st.valCol = lightenCol(st.col, 0.30)
end

-- Voile de couleur (dégradé précalculé) clippé aux coins arrondis ; repli aplat doux.
local function tileWash(rad, x, y, w, h, washCol)
	if GRAD_TEX then
		RNDX.DrawTexture(rad, x, y, w, h, washCol, GRAD_TEX)
	else
		RNDX.Draw(rad, x, y, w, h, washCol)
	end
end

-- Texte de valeur MÉMOÏSÉ par stat (les valeurs ne changent qu'au poll ~0.75s ;
-- pas de string.format par frame).
local bstatTxtCache = {} -- key -> { val = ..., txt = ... }
local function BonusStatText(st, val)
	local c = bstatTxtCache[st.key]
	if c and c.val == val then return c.txt end
	local txt = FmtBonusStat(val, st.mode)
	bstatTxtCache[st.key] = { val = val, txt = txt }
	return txt
end

-- ── Valeur ENCHANTÉE = DÉGRADÉ horizontal par caractère (demande user 08/18) :
-- teinte du boost evo_craft -> version éclaircie. Mémoïsé par stat (itération
-- utf8 + Lerp au CHANGEMENT de texte seulement, aucune alloc par frame).
local BSTAT_BONUS_TO_ENCH = { hp = "max_hp", katana = "katana_damage", spell = "spell_damage",
	reiatsu = "max_reiatsu", flash_cd = "flashstep_cd" }
local BSTAT_ENCH_FALLBACK = Color(216, 185, 106)

local function bstatEnchBaseCol(key)
	local eKey = BSTAT_BONUS_TO_ENCH[key]
	if eKey and EVO_CRAFT and EVO_CRAFT.EnchantByKey then
		local e = EVO_CRAFT.EnchantByKey(eKey)
		if e and e.color then return e.color end
	end
	return BSTAT_ENCH_FALLBACK
end

local bstatGradCache = {} -- key -> { txt = ..., chars = { {ch=, x=, col=} } }
local function BonusStatGradChars(key, txt, font)
	local c = bstatGradCache[key]
	if c and c.txt == txt then return c.chars end
	local colA = bstatEnchBaseCol(key)
	local colB = lightenCol(colA, 0.72)
	surface.SetFont(font)
	local totalW = surface.GetTextSize(txt)
	local chars, x = {}, 0
	for _, cp in utf8.codes(txt) do
		local ch = utf8.char(cp)
		local w = surface.GetTextSize(ch)
		local f = totalW > 0 and ((x + w / 2) / totalW) or 0
		chars[#chars + 1] = {
			ch = ch, x = x,
			col = Color(Lerp(f, colA.r, colB.r), Lerp(f, colA.g, colB.g), Lerp(f, colA.b, colB.b)),
		}
		x = x + w
	end
	bstatGradCache[key] = { txt = txt, chars = chars }
	return chars
end

local function DrawBonusStatsCard()
	-- Carte compacte, recentrée sur la colonne perso (centre x=1350).
	local cx, cy = gRespX(INV.STATS_X), gRespY(INV.STATS_Y)
	local cw, ch = gRespX(INV.STATS_W), gRespY(INV.STATS_H)

	-- Fond profond LÉGÈREMENT bleu-nuit (pas gris plat) + coins bien arrondis + reflet
	-- lumineux très doux vers le haut (profondeur, ambiance tranquille).
	RNDX.Draw(gRespY(16), cx, cy, cw, ch, BSTAT_COL_CARD)
	if GRAD_TEX then
		RNDX.DrawTexture(gRespY(16), cx, cy, cw, math.floor(ch * 0.6), BSTAT_COL_GLOSS7, GRAD_TEX)
	end

	-- Titre + entaille slash1 dessous (signature DA, discrète). Fallback tiret plein.
	local titleX, titleY = cx + gRespX(22), cy + gRespY(24)
	draw.SimpleText("STATISTIQUES", "Bebas Neue:28", titleX, titleY,
		BSTAT_COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:28")
	local titleW, titleH = surface.GetTextSize("STATISTIQUES")
	local inked = EVO_UI and EVO_UI.Ink
		and EVO_UI.Ink(EVO_UI.TexSlash, titleX - gRespX(2), titleY + titleH * 0.28, titleW * 1.1, gRespY(7), BSTAT_COL_SLASH)
	if not inked then
		surface.SetDrawColor(207, 68, 78, 215)
		surface.DrawRect(titleX, titleY + titleH * 0.34, titleW, math.max(1, gRespY(2)))
	end

	-- La carte est sortie du panneau (09/03) et donc plus etroite : a 3 colonnes les tuiles
	-- tombaient a ~72 px et les libelles debordaient sur la voisine. On passe a 2 colonnes
	-- sous un certain seuil, et le nombre de rangees en decoule au lieu d'etre fige a 3.
	local bEtroit = cw < gRespX(360)
	local cols = bEtroit and 2 or 3
	local rows = math.ceil(#BONUS_STATS_DISPLAY / cols)
	local sFontLbl = bEtroit and "Avenir Next World:6" or "Avenir Next World:12"
	local sFontVal = bEtroit and "Bebas Neue:21" or "Bebas Neue:28"
	local padX, padTop, padBot = gRespX(16), gRespY(48), gRespY(14)
	local gap, vgap = gRespX(8), gRespY(6)
	-- Marges gauche/droite ÉGALES (= padX) : le gap est réparti UNIQUEMENT ENTRE les tuiles
	-- (cols-1 gaps), jamais après la dernière -> bord droit == bord gauche.
	local tileW = (cw - padX * 2 - (cols - 1) * gap) / cols
	local tileH = (ch - padTop - padBot - (rows - 1) * vgap) / rows
	-- Retrait du texte PROPORTIONNEL a la tuile (il etait fige a 15 px : sur une tuile
	-- etroite, le libelle demarrait au tiers de la largeur et sortait aussitot).
	local inset = math.max(gRespX(5), tileW * 0.13)
	local rad = gRespY(9)

	for i, st in ipairs(BONUS_STATS_DISPLAY) do
		local ci = (i - 1) % cols
		local ri = math.floor((i - 1) / cols)
		local tx = cx + padX + ci * (tileW + gap)
		local ty = cy + padTop + ri * (tileH + vgap)
		local iw, ih = tileW, tileH

		-- Tuile arrondie : base un peu plus claire (relief doux) + VOILE coloré de la stat
		-- (dégradé précalculé) + reflet supérieur discret -> vivant mais tranquille.
		RNDX.Draw(rad, tx, ty, iw, ih, BSTAT_COL_TILE)
		tileWash(rad, tx, ty, iw, ih, st.washCol)
		if GRAD_TEX then
			RNDX.DrawTexture(rad, tx, ty, iw, math.floor(ih * 0.5), BSTAT_COL_GLOSS10, GRAD_TEX)
		end
		-- Pilule d'accent gauche (arrondie, pleine couleur = identité nette).
		RNDX.Draw(gRespY(2), tx + gRespX(5), ty + ih * 0.24, math.max(2, gRespX(3)), ih * 0.52, st.col)

		-- Libellé (doux) en haut.
		draw.SimpleText(st.label, sFontLbl, tx + inset, ty + gRespY(15),
			BSTAT_COL_LABEL, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Valeur en bas : couleur ÉCLAIRCIE précalculée (ressort sur le voile) + contour doux.
		-- Stat boostée par un ENCHANTEMENT porté : valeur en DÉGRADÉ (teinte du boost).
		local val = bonusStats[st.key]
		local hasVal = bonusStatsReceived and val ~= nil
		local dim = (not hasVal) or (tonumber(val) or 0) == 0
		local txt = hasVal and BonusStatText(st, val) or "—"
		local vx, vy = tx + inset, ty + ih - gRespY(13)
		if not dim and bonusStatsEnch[st.key] then
			local chars = BonusStatGradChars(st.key, txt, sFontVal)
			for gi = 1, #chars do
				local g = chars[gi]
				draw.SimpleTextOutlined(g.ch, "Bebas Neue:28", vx + g.x, vy,
					g.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, BSTAT_COL_OUTLINE)
			end
		else
			draw.SimpleTextOutlined(txt, "Bebas Neue:28", vx, vy,
				dim and BSTAT_COL_DIM or st.valCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, BSTAT_COL_OUTLINE)
		end
	end
end

-- (Carte EFFETS retirée 08/09 : les buffs potions vivent dans le HUD, en
-- pilules sous la barre de reiatsu — cf. lzy_hud cl_hud + EVO_SCIENCE.GetActiveEffects.)

-- ── Carte SETS (demande user 08/01) : état des sets d'accessoires écrit EN GROS
-- directement dans l'inventaire, à droite de la carte STATISTIQUES (même DA).
-- Règles rareté (même rareté requise, bonus ×1->×5) via les helpers SHARED evo_loot
-- — la même source que le serveur qui applique le bonus.
local SETS_COL_ACTIVE  = Color(140, 200, 160)
local SETS_COL_PARTIAL = Color(210, 212, 220)
local SETS_COL_BONUS   = Color(226, 228, 236)
local SETS_COL_WARN    = Color(230, 160, 90)

local function DrawSetsCard()
	if not (EVO_LOOT and EVO_LOOT.Sets and EVO_LOOT.CountSetPieces and EVO_LOOT.BestSetCount) then return end
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
	local counts = EVO_LOOT.CountSetPieces((istable(inv) and inv.equipped_items) or {}, inv and inv.durability)

	local cx, cy = gRespX(INV.SETS_X), gRespY(INV.SETS_Y)
	local cw, ch = gRespX(INV.SETS_W), gRespY(INV.SETS_H)
	RNDX.Draw(gRespY(16), cx, cy, cw, ch, BSTAT_COL_CARD)
	if GRAD_TEX then
		RNDX.DrawTexture(gRespY(16), cx, cy, cw, math.floor(ch * 0.6), BSTAT_COL_GLOSS7, GRAD_TEX)
	end

	local x = cx + gRespX(18)
	local y = cy + gRespY(24)
	draw.SimpleText("SETS", "Bebas Neue:28", x, y, BSTAT_COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:28")
	local tW, tH = surface.GetTextSize("SETS")
	local inked = EVO_UI and EVO_UI.Ink
		and EVO_UI.Ink(EVO_UI.TexSlash, x - gRespX(2), y + tH * 0.28, tW * 1.1, gRespY(7), BSTAT_COL_SLASH)
	if not inked then
		surface.SetDrawColor(207, 68, 78, 215)
		surface.DrawRect(x, y + tH * 0.34, tW, math.max(1, gRespY(2)))
	end
	y = y + gRespY(28)

	-- Ordre stable (pairs est non déterministe) : tri par id de set.
	local ids = {}
	for set_id in pairs(counts) do ids[#ids + 1] = set_id end
	table.sort(ids)

	-- Polices RÉDUITES (demande user 08/01 : « ça déborde du cadre, tout trop gros »).
	-- NB : les décimales des bonus utilisent la VIRGULE -> le split des lignes se fait
	-- sur ", " (virgule+espace), pas sur la virgule seule (sinon "+0,031%" est coupé).
	local bAny = false
	for _, set_id in ipairs(ids) do
		local cfg = EVO_LOOT.Sets[set_id]
		if cfg then
			bAny = true
			local byRarity = counts[set_id]
			local n, r = EVO_LOOT.BestSetCount(byRarity)
			local nPieces = cfg.pieces or 3
			local nTotal = 0
			for _, c in pairs(byRarity) do nTotal = nTotal + c end
			local sRar = isstring(r) and (r:sub(1, 1):upper() .. r:sub(2)) or ""
			if n >= nPieces then
				local nMult = (EVO_LOOT.SetRarityMult and EVO_LOOT.SetRarityMult[r]) or 1
				draw.SimpleText(string.format("%s %s — ACTIF", cfg.name or set_id, sRar),
					"Bebas Neue:20", x, y, SETS_COL_ACTIVE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + gRespY(22)
				-- Desc GÉNÉRÉE depuis la table bonus (source unique, 08/15), directement
				-- aux valeurs FINALES (base × rareté, demande user 08/15 : « plus de ×5
				-- écrit avec la valeur de base ») ; repli bonus_desc si générateur absent.
				local sSetDesc = (EVO_LOOT.SetBonusDesc and EVO_LOOT.SetBonusDesc(set_id, nMult, true)) or cfg.bonus_desc or ""
				for part in string.gmatch(sSetDesc .. ", ", "(.-), ") do
					draw.SimpleText(string.Trim(part), "Avenir Next World Bold:13", x, y,
						SETS_COL_BONUS, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					y = y + gRespY(15)
				end
				y = y + gRespY(3)
			else
				-- Rareté du meilleur groupe affichée (demande user 08/01 « dise la rareté à 2/3 ») ;
				-- raretés mélangées -> l'expliquer en orange.
				local bMixed = nTotal >= nPieces and nTotal > n
				draw.SimpleText(string.format("%s %d/%d%s%s", cfg.name or set_id, n, nPieces,
						(n > 0 and sRar ~= "") and (" " .. sRar) or "",
						bMixed and " — raretés mélangées !" or ""),
					"Bebas Neue:18", x, y, bMixed and SETS_COL_WARN or SETS_COL_PARTIAL,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + gRespY(20)
			end
		end
	end
	if not bAny then
		draw.SimpleText("Aucune pièce de set équipée", "Avenir Next World:16", x, y + gRespY(8),
			BSTAT_COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
end

local function InventoryItemHasDescriptionTooltipContent(d)
	if not d then return false end
	if d.has_durability then return true end
	if isfunction(d.tooltip_state) then return true end
	if d.set_id then return true end -- pièce de set : le tooltip affiche l'état du set
	if isstring(d.description) and d.description ~= "" then return true end
	if not istable(d.stats) then return false end
	for _ in pairs(d.stats) do return true end
	return false
end

local function InventoryClientDurabilityPercent(dbSlotId)
	if not dbSlotId then return nil end
	local inv = LocalPlayer():GetInventory()
	local m = inv and inv.durability
	if not istable(m) then return nil end
	local v = m[dbSlotId] or m[tonumber(dbSlotId)] or m[tostring(dbSlotId)]
	if v == nil then return nil end
	return math.Clamp(tonumber(v) or 0, 0, 100)
end

--- Physical bag slot (1..MAX_BAG_SLOTS): block equip in UI when durability is known and <= 0 (matches server).
local function InventoryClientBagDurabilityEquipBlocked(itemId, bagPhysicalSlot)
	if not itemId or not INVENTORY_CONFIG or not INVENTORY_CONFIG.ItemHasDurability(itemId) then return false end
	if not bagPhysicalSlot or bagPhysicalSlot < 1 then return false end
	local d = InventoryClientDurabilityPercent(bagPhysicalSlot)
	if d == nil then d = 100 end
	return tonumber(d) <= 0
end

local function InventoryNotifyDurabilityEquipBlocked()
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify("Cet objet est cassé (0% durabilité).", NOTIFY_ERROR, 4)
	end
end

--- Hollow sans masque inventaire : le masque de base Arrancar (masque_base) est éditable.
local function InventoryCanEditMasqueBase()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then return false end
	if lp:GetEvoNWString("FactionName", "") ~= "Hollow" then return false end
	local data = GetPlayerCharacterData and GetPlayerCharacterData(lp)
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasBoughtMask
		and LZY_CHARACTER_CONFIG.CharacterHasBoughtMask(data) then
		return false
	end
	local rank = lp:GetEvoNWInt("FactionRank", 0)
	local path = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetArrancarMaskModel
		and LZY_CHARACTER_CONFIG.GetArrancarMaskModel("Hollow", rank)
	return isstring(path) and path ~= ""
end

-- Le joueur porte-t-il un accessoire body de DIVISION éditable ? Miroir du masque
-- de base : il faut le porter (division avec un modèle) et ne pas l'avoir masqué
-- par « Cacher la tenue de grade » (rien ne s'afficherait dans l'éditeur).
-- Empile les coches de grade SANS TROU : « tenue de grade » n'est visible que
-- pour les capitaines et « tenue de division » que pour les membres d'une
-- division. Des positions fixes laissaient un vide de 30 px là où une coche
-- invisible gardait sa place (report user 08\16 : « écrit super bas »).
-- ⚠️ LARGEUR 208 MAX (x 1295 -> 1503) : la colonne DROITE des cases d'équipement
-- commence à x = 1508 et la case du haut (slot 4, collier) démarre à y = 282,
-- son œil « cacher cet accessoire » dans le coin. À 340 de large, ces coches
-- (ZPos 10000) recouvraient l'œil : cliquer l'œil togglait la coche (report
-- user 08\16, « cacher le collier coche la tenue de division »).
local function InventoryIsHakudaFamily()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	return EvoStyle and EvoStyle.GetPlayerFamily and EvoStyle.GetPlayerFamily(lp) == "hakuda"
end

local function InvRelayoutHideChecks(self)
	-- Range les coches VISIBLES en colonnes de INV.CHECKS_PER_COL : sur une seule
	-- colonne elles sortaient du panneau des que 4 ou 5 etaient affichees.
	-- hideHairCheck EST DANS LA LISTE (fix 09/03) : sans elle, Init la posait en dur sur la
	-- 1re case et cette boucle y remettait la premiere des autres -> superposition, on ne
	-- voyait plus que « Cacher Cheveux ».
	local tVis = {}
	for _, chk in ipairs({
		self.hideHairCheck,
		self.hakudaAlwaysWearCheck,
		self.hideEpauletteCheck,
		self.hideRankOutfitCheck,
		self.hideDivisionBodyCheck,
		self.catalyseurOffCheck,
	}) do
		if IsValid(chk) and chk:IsVisible() then tVis[#tVis + 1] = chk end
	end
	if #tVis == 0 then return end

	local nX0 = INV.CHECKS_X -- bord gauche : à gauche du slot d'arme
	for i, chk in ipairs(tVis) do
		local col = math.floor((i - 1) / INV.CHECKS_PER_COL)
		local lig = (i - 1) % INV.CHECKS_PER_COL
		chk:gSetSize(INV.CHECK_W, 28)
		chk:gSetPos(nX0 + col * INV.CHECKS_COL_W, INV.CHECKS_Y + lig * INV.CHECKS_STEP)
	end
end

local function InventoryCanEditDivisionBody()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then return false end
	-- Drapeau DÉDIÉ, lu dans la data perso (plus EVO_HideRankOutfit).
	local data = GetPlayerCharacterData and GetPlayerCharacterData(lp) or nil
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody
		and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(data) then return false end
	local path = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankDivisionBody
		and LZY_CHARACTER_CONFIG.GetRankDivisionBody(
			lp:GetEvoNWString("FactionName", ""),
			lp:GetEvoNWInt("FactionRank", 0),
			lp:GetEvoNWInt("FactionDivision", 0))
	return isstring(path) and path ~= ""
end

-- Épaulette de grade : éditable si le perso en PORTE une (faction+rang avec
-- modèle) et qu'elle n'est pas masquée par la coche (NWBool EVO_HideEpaulette).
local function InventoryCanEditGrade()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then return false end
	if lp:GetEvoNWBool("EVO_HideEpaulette", false) then return false end
	local path = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankEpauletteModel
		and LZY_CHARACTER_CONFIG.GetRankEpauletteModel(
			lp:GetEvoNWString("FactionName", ""),
			lp:GetEvoNWInt("FactionRank", 0))
	return isstring(path) and path ~= ""
end

-- Pièces de grade que le joueur porte ET qui ne sont pas masquées par une coche.
-- L'épaulette d'abord, puis brassard / haori / tenue Espada / cape.
local RANK_EDIT_ORDER = { "brassard", "haori", "espada", "cape_roi" }
local function InventoryEditableGradeCosmetics()
	local lp = LocalPlayer()
	local out = {}
	if not IsValid(lp) or lp:GetEvoNWBool("EVO_IsLarva", false) then return out end
	if InventoryCanEditGrade() then
		out[#out + 1] = { slot = (INVENTORY_CONFIG.GRADE_SLOT or "grade"), label = "Épaulette" }
	end
	local labels = INVENTORY_CONFIG.RANK_OFFSET_SLOT
	if not istable(labels) or not INVENTORY_CONFIG.ResolveRankCosmeticModel then return out end
	for i = 1, #RANK_EDIT_ORDER do
		local slot = RANK_EDIT_ORDER[i]
		if labels[slot] then
			local path = INVENTORY_CONFIG.ResolveRankCosmeticModel(lp, slot)
			local hidden = INVENTORY_CONFIG.IsRankCosmeticHidden and INVENTORY_CONFIG.IsRankCosmeticHidden(lp, slot)
			if isstring(path) and path ~= "" and not hidden then
				out[#out + 1] = { slot = slot, label = labels[slot] }
			end
		end
	end
	return out
end

-- Combat-lock : empêche de changer d'équipement pendant un combat. Pré-check client
-- (notif instantanée + pas de MAJ optimiste) doublé d'un garde serveur autoritatif
-- (cf. sv_swap_combat_lock). Lit le NWFloat "EVO_CombatSwapUntil" posé par le serveur.
-- itemId (optionnel) : l'item qu'on équipe/déséquipe. displacedItemId (optionnel) :
-- l'item DÉPLACÉ par un swap (équiper dans un slot déjà occupé le renvoie au sac). Si
-- AUCUN des deux ne modifie les stats (accessoires cosmétiques : masque tête / épaules
-- sans stats / tenue), le lock est ignoré (demande user) — seuls les items à stats sont
-- bloqués en combat, y compris "remplacer un item à stats pour le retirer". Le serveur
-- reste autoritatif.
local function InventoryCombatSwapBlocked(itemId, displacedItemId)
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	-- Mode Hollow (larva) : créature brute SANS slots d'équipement -> aucun changement
	-- d'équipement (notif instantanée + pas de MAJ optimiste). Doublé du garde serveur
	-- autoritatif (Equip/Unequip/EquipKatana/UnequipKatana dans net.lua).
	if lp:GetEvoNWBool("EVO_IsLarva", false) then
		if MUGEN and MUGEN.Notify then
			MUGEN.Notify("Impossible de s'équiper sous forme de Hollow.", NOTIFY_ERROR, 4)
		end
		return true
	end
	-- Aucun item à stats impliqué (ni équipé ni déplacé) -> jamais bloqué en combat.
	if INVENTORY_CONFIG.ItemAffectsStats and (itemId or displacedItemId) then
		local involvesStats =
			(itemId and INVENTORY_CONFIG.ItemAffectsStats(itemId)) or
			(displacedItemId and INVENTORY_CONFIG.ItemAffectsStats(displacedItemId))
		if not involvesStats then return false end
	end
	local nRemaining = math.ceil((lp:GetEvoNWFloat("EVO_CombatSwapUntil", 0) or 0) - CurTime())
	if nRemaining <= 0 then return false end
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify("Impossible de changer d'équipement en combat : encore " .. nRemaining .. "s.", NOTIFY_ERROR, 4)
	end
	return true
end

-- Gate FACTION : pré-check client (notif INSTANTANÉE au moment où on essaie de
-- mettre l'item — pas d'aller-retour réseau ni de MAJ optimiste annulée), doublé
-- du garde serveur autoritatif (EquipItem/EquipKatana dans net.lua).
local function InventoryFactionEquipBlocked(itemId)
	local lp = LocalPlayer()
	local itemData = ITEMS and ITEMS[itemId]
	if not (IsValid(lp) and itemData and INVENTORY_CONFIG.CanFactionUseItem) then return false end
	-- GENRE : tenue/accessoire genré non équipable par l'autre genre (pré-check client,
	-- doublé du gate serveur EquipItem). Notif instantanée.
	if INVENTORY_CONFIG.CanGenderUseItem and not INVENTORY_CONFIG.CanGenderUseItem(lp, itemData) then
		if MUGEN and MUGEN.Notify then
			local glbl = INVENTORY_CONFIG.GetItemGenderLabel(itemData)
			MUGEN.Notify("Cet équipement est réservé aux " .. (glbl == "Femme" and "femmes" or "hommes") .. ".",
				NOTIFY_ERROR, 4)
		end
		return true
	end
	if INVENTORY_CONFIG.CanFactionUseItem(lp, itemData) then return false end
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify(
			"Cet équipement est réservé à la faction " .. tostring(INVENTORY_CONFIG.GetItemFaction(itemData)) .. ".",
			NOTIFY_ERROR, 4)
	end
	return true
end

-- FAMILLE DE COMBAT : une épée (skin_id) ne s'équipe QU'EN style Katana ; un gantelet (gauntlet_id)
-- QU'EN style Hakuda. Doublé du gate serveur EquipKatana. SILENCIEUX (pour le hover de la case) :
-- true si l'équip est permis (true aussi si ce n'est pas une arme cosmétique).
local function InventoryWeaponFamilyOk(itemId)
	local itemData = ITEMS and ITEMS[itemId]
	if not itemData then return true end
	if not (itemData.skin_id or itemData.gauntlet_id) then return true end -- pas une arme cosmétique
	if not (EvoStyle and EvoStyle.GetStyleFamily) then return true end -- fail-open
	local lp = LocalPlayer()
	if not IsValid(lp) then return true end
	local fam = EvoStyle.GetStyleFamily(lp:GetEvoNWString("StyleCombat", ""))
	if itemData.gauntlet_id then return fam == "hakuda" end
	return fam ~= "hakuda" -- skin_id (épée) : ok si PAS hakuda
end

-- Version NOTIFIANTE (pour les actions d'équip) : true si BLOQUÉ + notif instantanée.
local function InventoryWeaponFamilyBlocked(itemId)
	if InventoryWeaponFamilyOk(itemId) then return false end
	if MUGEN and MUGEN.Notify then
		local lp = LocalPlayer()
		local fam = (IsValid(lp) and EvoStyle and EvoStyle.GetStyleFamily)
			and EvoStyle.GetStyleFamily(lp:GetEvoNWString("StyleCombat", "")) or "katana"
		if fam == "hakuda" then
			MUGEN.Notify("Tu es en Hakuda : tu ne peux équiper que des gantelets, pas une épée.", NOTIFY_ERROR, 5)
		else
			MUGEN.Notify("Tu es au Katana : tu ne peux équiper qu'une épée, pas un gantelet.", NOTIFY_ERROR, 5)
		end
	end
	return true
end

-- Accessoires CACHÉS du joueur local (NWString JSON "EVO_HiddenAccessories" posé
-- par le serveur, clé = slot équipement "1".."6"). Parsé seulement quand la
-- chaîne change (pas de JSONToTable par frame de Paint).
local _hidStr, _hidTbl = nil, {}
local function InventoryHiddenAccessories()
	local lp = LocalPlayer()
	local s = IsValid(lp) and lp:GetEvoNWString("EVO_HiddenAccessories", "") or ""
	if s ~= _hidStr then
		_hidStr = s
		_hidTbl = util.JSONToTable(s) or {}
	end
	return _hidTbl
end

-- Police du tooltip de l'œil (responsive via glibs). 18 -> 15 (demande user).
if gCreateRespFont then
	gCreateRespFont("EVO_EyeTip", "Roboto", 15, 600)
else
	surface.CreateFont("EVO_EyeTip", { font = "Roboto", size = 15, weight = 600, extended = true })
end

--- Sorted lines like "PV max : +10%%" for tooltip (ITEMS[].stats).
--- Supporte deux formats :
---   1. Dict       : { max_hp = 10, regen_hp = 5 }            (bague_de_lamour, items inventory)
---   2. Array pair : { { "e_max_hp", 10 }, { "e_regen_hp", 5 } } (items evo_loot)
--- Le préfixe "e_" est strippé pour la lookup dans STAT_DISPLAY_NAMES.
local function InventoryCollectStatsTooltipLines(data, forge_mult)
	if not data or not istable(data.stats) then return {} end
	forge_mult = tonumber(forge_mult) or 1.0
	local names = INVENTORY_CONFIG and INVENTORY_CONFIG.STAT_DISPLAY_NAMES
	local rows = {}

	-- Stats qui RÉDUISENT un cooldown : la valeur (stockée positive) doit s'afficher en -%
	-- (un flashstep_cd de 20 = -20% de CD), pas +%.
	local REDUCTION_STATS = { flashstep_cd = true, spell_cd_reduction = true, parade_regen = true }

	-- Le signe porté par la valeur est une convention de STOCKAGE, pas ce qu'il faut
	-- afficher : la portée de flashstep est rangée en négatif (négatif = PLUS de
	-- portée), et les 15 pièces du set Tempête affichaient donc « +-0.4% ». Le signe
	-- montré vient uniquement de REDUCTION_STATS ; la valeur, elle, s'affiche en
	-- valeur absolue. C'est la seule stat stockée négative, la règle est sans risque.

	local function pushRow(rawKey, value)
		if not isstring(rawKey) or type(value) ~= "number" then return end
		-- Strip le préfixe "e_" pour matcher les labels de STAT_DISPLAY_NAMES
		local lookupKey = rawKey
		if string.sub(rawKey, 1, 2) == "e_" then
			lookupKey = string.sub(rawKey, 3)
		end
		local label = (names and names[lookupKey]) or lookupKey
		rows[#rows + 1] = {
			label = label,
			base = value,
			value = NCM_FORGE and NCM_FORGE.ScaleItemStat and NCM_FORGE.ScaleItemStat(data, rawKey, value, forge_mult) or value * forge_mult,
			reduction = REDUCTION_STATS
				[lookupKey] or false
		}
	end

	-- Détection du format : si stats[1] est une table, c'est du array de pairs
	if istable(data.stats[1]) then
		for _, pair in ipairs(data.stats) do
			if istable(pair) then pushRow(pair[1], pair[2]) end
		end
	else
		for k, v in pairs(data.stats) do
			pushRow(k, v)
		end
	end

	table.sort(rows, function(a, b) return a.label < b.label end)
	local lines = {}
	local showBoth = forge_mult > 1.0001
	for _, r in ipairs(rows) do
		local function fmt(n)
			n = math.abs(n)
			return (math.abs(n - math.floor(n)) < 1e-6) and string.format("%d", n) or string.format("%.1f", n)
		end
		local sign = r.reduction and "-" or "+"
		if showBoth then
			lines[#lines + 1] = string.format("%s : %s%s%% → %s%s%%", r.label, sign, fmt(r.base), sign, fmt(r.value))
		else
			lines[#lines + 1] = string.format("%s : %s%s%%", r.label, sign, fmt(r.value))
		end
	end
	return lines
end

-- Font bold + italic spécifique pour les lignes de stats du tooltip — permet
-- de distinguer les stats du reste de la description et du nom de l'item.
if gCreateRespFont then
	gCreateRespFont("LZY_Inventory_StatBoldItalic", "Avenir Next World", 18, 800, true, false, false)
else
	surface.CreateFont("LZY_Inventory_StatBoldItalic", {
		font      = "Avenir Next World",
		size      = 18,
		weight    = 800,
		italic    = true,
		antialias = true,
	})
end

-- Newline split matching glibs responsive.lua splitWithEmptyLines (preserves blank lines).
local function InvSplitDescNewlines(str)
	str = str or ""
	local lines = {}
	local current = ""
	for i = 1, #str do
		local ch = string.sub(str, i, i)
		if ch == "\n" then
			lines[#lines + 1] = current
			current = ""
		else
			current = current .. ch
		end
	end
	lines[#lines + 1] = current
	return lines
end

-- Height of description as actually laid out by gRespDrawMultilineText (differs from gGetMultilineTextSize).
local function InvTooltipDescDrawHeight(lines, font, gap)
	surface.SetFont(font)
	local currentY = 0
	local maxBottom = 0
	for _, line in ipairs(lines) do
		if line == "" then
			currentY = currentY + gap
		else
			local py = gRespY(currentY)
			local _, h = surface.GetTextSize(line)
			maxBottom = math.max(maxBottom, py + h)
			currentY = currentY + gap
		end
	end
	return maxBottom
end

local function GetItemSlotHoverMaterial(itemId, slotIndex)
	if not itemId or not ITEMS or not ITEMS[itemId] then
		return materials.slot_hover
	end
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
	local rarity = (INVENTORY_CONFIG.GetItemRarity and INVENTORY_CONFIG.GetItemRarity(itemId, slotIndex, inv)) or ITEMS[itemId].rarity
	local cfg = INVENTORY_CONFIG and INVENTORY_CONFIG.raritiesColor
	local colorKey = (rarity and cfg and cfg[rarity]) or "gray"
	return RARITY_COLOR_TO_SLOT_HOVER[colorKey] or materials.slot_hover
end

local function InventorySlotStackQty(inv, slotIndex)
	if INVENTORY_CONFIG.GetSlotQuantity then
		return INVENTORY_CONFIG.GetSlotQuantity(inv, slotIndex)
	end
	return 1
end

--- Prélève 1 du slot sac côté UI (optimistic). true = case vidée.
local function InventoryOptimisticTakeOne(frame, fromSlotIndex)
	if not fromSlotIndex then return true end
	frame.quantityMap = frame.quantityMap or {}
	local q = tonumber(frame.quantityMap[fromSlotIndex]) or 1
	if q > 1 then
		frame.quantityMap[fromSlotIndex] = q - 1
		return false
	end
	frame.inventoryMap[fromSlotIndex] = nil
	frame.quantityMap[fromSlotIndex] = nil
	return true
end

local function PaintInventorySlotItemName(w, h, itemId, hovered, slotIndex, stackQty)
	if not itemId or not ITEMS or not ITEMS[itemId] then return end
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
	local name = (INVENTORY_CONFIG.GetItemDisplayName and INVENTORY_CONFIG.GetItemDisplayName(itemId, slotIndex, inv)) or ITEMS[itemId].name
	if not name then return end
	draw.SimpleText(name, "Avenir Next World:14", w / 2, hovered and h - gRespY(25) or h - gRespY(10),
		hovered and Color(255, 255, 255, 255) or Color(255, 255, 255, 255 / 2),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	-- stackQty : quantité qui voyage avec le drag (inventoryMap). Sans ça, un swap
	-- d'icônes laisse le "xN" sur l'ancien slot physique (GetSlotQuantity).
	local q = tonumber(stackQty)
	if not q then
		q = InventorySlotStackQty(inv, slotIndex)
	end
	if q > 1 then
		draw.SimpleText("x" .. q, "Avenir Next World:14", w - gRespX(8), gRespY(8),
			Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	end
end

local function AttachInventorySlotNameOverlay(slot, getItemId)
	local overlay = vgui.Create("DPanel", slot)
	overlay:Dock(FILL)
	overlay:SetMouseInputEnabled(false)
	overlay:SetZPos(100)
	overlay.Paint = function(_, w, h)
		PaintInventorySlotItemName(w, h, getItemId(slot), slot.hovered, slot.slotIndex, slot.stackQty)
	end
end

-- Fourreau en traits fins : corps courbe fermé, embouchure et cordon, sans lame ni poignée.
-- Coordonnées normalisées pour conserver les proportions à toutes les résolutions.
INV.FOURREAU_ICON_STROKES = {
	{ 0.15, 0.84, 0.20, 0.71, 0.31, 0.56, 0.46, 0.41, 0.66, 0.23,
		0.76, 0.14, 0.86, 0.25, 0.73, 0.35, 0.54, 0.50, 0.39, 0.64,
		0.25, 0.80, 0.18, 0.88, 0.15, 0.84 },
	{ 0.72, 0.18, 0.82, 0.28 }, -- bague de l'embouchure
	{ 0.20, 0.71, 0.28, 0.77 }, -- renfort du bout fermé
	{ 0.61, 0.28, 0.71, 0.37, 0.67, 0.40, 0.57, 0.32 }, -- attache du cordon
	{ 0.68, 0.38, 0.80, 0.35, 0.85, 0.39, 0.80, 0.43, 0.68, 0.38,
		0.70, 0.50, 0.66, 0.54, 0.62, 0.49, 0.68, 0.38 }, -- nœud
	{ 0.68, 0.38, 0.81, 0.51, 0.84, 0.57 },
	{ 0.68, 0.38, 0.76, 0.55, 0.75, 0.61 },
}

-- Empty equipment slots: materials or a drawing function.
local EQUIP_SLOT_PLACEHOLDER = {
	materials.slot_icon_head,
	materials.slot_icon_outfit,
	materials.slot_icon_cape,
	materials.slot_icon_necklace,
	materials.slot_icon_ring,
	materials.slot_icon_belt,
	materials.slot_icon_mask, -- 7 = masque Arrancar (icône dédiée, user 07/23)
	function(x, y, size, col) -- 8 = fourreau : icône dédiée, même gris que les autres slots
		surface.SetDrawColor(125, 125, 125, col.a)
		for _, stroke in ipairs(INV.FOURREAU_ICON_STROKES) do
			for i = 1, #stroke - 2, 2 do
				surface.DrawLine(x + stroke[i] * size, y + stroke[i + 1] * size,
					x + stroke[i + 2] * size, y + stroke[i + 3] * size)
			end
		end
	end,
	function(x, y, size, col) -- 9 = compagnon : empreinte de patte
		-- Plus discrète : centrée, 25 % plus petite, gris des autres pictogrammes.
		x, y = x + size * 0.125, y + size * 0.125
		size = size * 0.75
		col = Color(125, 125, 125, col.a)
		-- Garder la surprise jusqu'à l'ouverture publique du coffre compagnon.
		-- Lecture au dessin : suit la config boutique même si elle charge après l'inventaire.
		local released = false
		if COFFRES_CONFIG and COFFRES_CONFIG.enabled ~= false then
			for _, tier in ipairs(COFFRES_CONFIG.tiers or {}) do
				if tier.id == "compagnons" then
					released = not tier.superadmin_only and not tier.soon
					break
				end
			end
		end
		if not released then
			draw.SimpleText("?", "Avenir Next World:32", x + size * 0.5, y + size * 0.5,
				col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		RNDX.DrawCircle(x + size * 0.20, y + size * 0.40, size * 0.22, col)
		RNDX.DrawCircle(x + size * 0.40, y + size * 0.23, size * 0.23, col)
		RNDX.DrawCircle(x + size * 0.65, y + size * 0.23, size * 0.23, col)
		RNDX.DrawCircle(x + size * 0.84, y + size * 0.40, size * 0.22, col)
		RNDX.Draw(size * 0.16, x + size * 0.28, y + size * 0.49,
			size * 0.48, size * 0.37, col, RNDX.SHAPE_CIRCLE)
	end,
}

local inventory = {}

local equipped_items = {}

local categories = {
	[1] = "Tous",
	[2] = "Vetements",
	[3] = "Accessoires",
	[4] = "Autres",
}

-- ── SETS D'ACCESSOIRES (evo_loot) : état du set d'un item pour le tooltip ─────────
-- Demande user 08/01 : « afficher dans l'inventaire que tu as le set complet et que
-- ça active tel ou tel boost », complétion par MÊME RARETÉ et bonus scalé par la
-- rareté. Comptage + règles via les helpers SHARED evo_loot (les mêmes que le
-- serveur qui APPLIQUE le bonus — une seule source, jamais de désync texte/effet).

local function InventoryRarityLabel(r)
	if not isstring(r) or r == "" then return "" end
	return r:sub(1, 1):upper() .. r:sub(2)
end

-- Compte les pièces équipées du set (source FRAÎCHE : GetInventory, comme
-- RefreshEquippedItems — le local equipped_items n'est rafraîchi qu'à l'ouverture).
-- Renvoie : meilleur count mono-rareté, sa rareté, total toutes raretés.
local function InventoryGetSetState(set_id)
	if not (EVO_LOOT and EVO_LOOT.CountSetPieces and EVO_LOOT.BestSetCount) then return 0, nil, 0 end
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
	local equipped = (istable(inv) and inv.equipped_items) or equipped_items or {}
	local byRarity = EVO_LOOT.CountSetPieces(equipped, inv and inv.durability)[set_id]
	local nBest, sRarity = EVO_LOOT.BestSetCount(byRarity)
	local nTotal = 0
	for _, c in pairs(byRarity or {}) do nTotal = nTotal + c end
	return nBest, sRarity, nTotal
end

local function InventoryCollectSetTooltipText(data)
	if not (data and data.set_id and EVO_LOOT and EVO_LOOT.Sets) then return nil end
	local set_cfg = EVO_LOOT.Sets[data.set_id]
	if not set_cfg then return nil end
	local nPieces = set_cfg.pieces or 3
	local nCount, sRarity, nTotal = InventoryGetSetState(data.set_id)
	local sName  = set_cfg.name or data.set_id
	local identity = set_cfg.identity and (set_cfg.identity .. "\n") or ""
	if nCount >= nPieces then
		-- Set ACTIF : valeurs FINALES directement (base × rareté, demande user 08/15),
		-- plus de « ×N » à côté de valeurs de base. Repli bonus_desc (alors en base).
		local nMult = (EVO_LOOT.SetRarityMult and EVO_LOOT.SetRarityMult[sRarity]) or 1
		local sBonus = (EVO_LOOT.SetBonusDesc and EVO_LOOT.SetBonusDesc(data.set_id, nMult)) or set_cfg.bonus_desc or ""
		return identity .. string.format("Set %s (%d/%d %s) — BONUS ACTIF :\n%s",
			sName, nPieces, nPieces, InventoryRarityLabel(sRarity), sBonus)
	end
	-- Set incomplet : pas de rareté validée -> valeurs de BASE + rappel de l'échelle.
	local sBonus = (EVO_LOOT.SetBonusDesc and EVO_LOOT.SetBonusDesc(data.set_id)) or set_cfg.bonus_desc or ""
	-- Raretés mélangées : le total suffirait mais pas en mono-rareté -> expliquer pourquoi.
	-- La rareté du meilleur groupe est affichée dès 1 pièce (demande user 08/01).
	local sWhy = (nTotal >= nPieces and nTotal > nCount) and " — raretés mélangées !" or ""
	local sRar = (nCount > 0) and InventoryRarityLabel(sRarity) or ""
	return identity .. string.format("Set %s (%d/%d%s%s) — bonus à %d pièces de MÊME rareté (×1 à ×5 selon rareté) :\n%s",
		sName, nCount, nPieces, sRar ~= "" and (" " .. sRar) or "", sWhy, nPieces, sBonus)
end

-- Expose inventory details without requiring the inventory window to be open.
local InstallItemTooltip = include("inventory/cl_item_tooltip.lua")
LZY_INVENTORY_ITEM_TOOLTIP = LZY_INVENTORY_ITEM_TOOLTIP or {}
function LZY_INVENTORY_ITEM_TOOLTIP.Install(self)
	InstallItemTooltip(self, {
		InventoryCollectSetTooltipText = InventoryCollectSetTooltipText,
		InventoryCollectStatsTooltipLines = InventoryCollectStatsTooltipLines,
		InventoryClientDurabilityPercent = InventoryClientDurabilityPercent,
		InvTooltipDescDrawHeight = InvTooltipDescDrawHeight,
		InvSplitDescNewlines = InvSplitDescNewlines,
		GetRarityTierTextColor = GetRarityTierTextColor,
	})
end

function PANEL:Init()
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.OnInventoryOpen then
		LZY_INVENTORY_ITEM_PREVIEW.OnInventoryOpen(self)
	end
	openedFrame = self
	-- Lu par le CalcView pour savoir qu'il doit cadrer le joueur, et remis a neuf a
	-- chaque ouverture (sinon on rouvre avec l'orbite et le zoom de la fois d'avant).
	LZY_INVENTORY_FRAME = self
	-- ARBITRAGE DES CAMERAS (fix 09/03) : ncm_orbit_camera pose lui aussi un CalcView, et
	-- l'ordre d'iteration des hooks n'est pas garanti — il pouvait manger le notre. Meme
	-- geste que cl_accessory_editor (assertEditorCamera) : on desarme l'orbite, son
	-- CreateMove sort proprement et sa vue rend nil.
	local lpCam = LocalPlayer()
	if IsValid(lpCam) then lpCam.ActiveCamera = false end
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = true end
	-- VERROU D'INTRO (user 09/03) : pendant le mouvement de camera la fenetre est cachee,
	-- donc la souris pilote encore la vue et le personnage tournait sous la camera. On fige
	-- l'angle de vue du moment et on coupe le deplacement, le temps de l'intro seulement.
	self._invIntroLock = true
	self._invIntroAng = IsValid(lpCam) and lpCam:EyeAngles() or Angle(0, 0, 0)
	INV_CAM.yaw, INV_CAM.pitch, INV_CAM.dist = 0, 0, 120
	-- Orbite coupee par le joueur : on date l'ouverture d'une intro en arriere, le
	-- CalcView se retrouve a f = 1 des la premiere image (cadrage direct).
	local bOrbite = InvCamOrbiteActive()
	INV_CAM.t0 = bOrbite and RealTime() or (RealTime() - INV_CAM_INTRO)
	self._invIntroDuree = bOrbite and INV_CAM_INTRO or 0
	-- La camera reste active meme fenetre CACHEE : elle se pilote sur ce drapeau, pas sur
	-- la visibilite (sinon masquer la fenetre couperait le mouvement qu'on veut voir).
	self._invCamOn = true
	bonusStatsReceived = false
	self._bonusStatReqAttempts = 1
	self._nextBonusStatReq = CurTime() + 0.75
	RequestBonusStats()
	local inventoryData = LocalPlayer():GetInventory()
	inventory = inventoryData.items or {}
	equipped_items = inventoryData.equipped_items or {}

	-- Convert array format to object format if needed
	if istable(equipped_items) then
		local hasNumericKeys = false
		local hasStringKeys = false

		for k, v in pairs(equipped_items) do
			if type(k) == "number" then
				hasNumericKeys = true
			elseif type(k) == "string" then
				hasStringKeys = true
			end
		end

		-- Only convert if it has numeric keys but no string keys (pure array)
		-- If it has string keys (like {"3":"item_2"}), it's already in the correct format
		if hasNumericKeys and not hasStringKeys then
			local converted = {}
			for i, itemId in ipairs(equipped_items) do
				if itemId then
					converted[tostring(i)] = itemId
				end
			end
			-- Also check for sparse arrays (like [nil, nil, "item"])
			for k, v in pairs(equipped_items) do
				if type(k) == "number" and v and not converted[tostring(k)] then
					converted[tostring(k)] = v
				end
			end
			equipped_items = converted
		end
	end

	-- Debug: Print equipped items to see what we're getting
	-- print("[INVENTORY] Equipped items on init:", util.TableToJSON(equipped_items))

	self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetVisible(true)
	self:gSetSize(1920, 1080)
	self:gSetPos(0, 0)

	-- MASQUAGE REEL pendant le mouvement de camera (user 09/03 : « on voit les items avant
	-- que l'inventaire apparaisse »). SetAlpha ne suffit PAS : les icones d'objets et
	-- l'apercu du personnage sont des DModelPanel, donc du rendu 3D, qui ignore l'alpha 2D ;
	-- seul SetVisible(false) les fait vraiment disparaitre.
	-- ⚠ CE BLOC DOIT RESTER APRES le self:SetVisible(true) ci-dessus : place avant, il
	-- etait annule dans la foulee (bug constate en jeu le 09/03).
	self:SetVisible(false)
	timer.Simple(self._invIntroDuree or INV_CAM_INTRO, function()
		if not IsValid(self) then return end
		self:SetVisible(true)
		self._invIntroLock = nil  -- l'intro est finie : la souris rend la main a l'interface
		self:MakePopup()          -- rend le focus clavier / souris perdu par le masquage
		self._uiT0 = RealTime()   -- point de depart du fondu d'apparition
		self:SetAlpha(0)
	end)

	self.closeBtn = vgui.Create("DButton", self)
	self.closeBtn:gSetSize(INV.CLOSE_PX, INV.CLOSE_PX)
	self.closeBtn:gSetPos(INV.CLOSE_X, INV.CLOSE_Y)
	self.closeBtn:SetText("")
	self.closeBtn.Paint = function(selff, w, h)
		-- Croix standard DA : glyphe ✕, pas de fond, gris -> accent au survol
		-- (remplace le PNG materials.close).
		draw.SimpleText("✕", "Avenir Next World Bold:30", w / 2, h / 2,
			selff:IsHovered() and Color(207, 68, 78) or Color(150, 154, 162),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.closeBtn.DoClick = function()
		self:Close()
	end
	self.closeBtn.OnCursorEntered = function(selff)
		selff.hovered = true
	end
	self.closeBtn.OnCursorExited = function(selff)
		selff.hovered = false
	end

	self.hideHairCheck = vgui.Create("DCheckBoxLabel", self)
	self.hideHairCheck:SetText("Cacher Cheveux")
	self.hideHairCheck:SetZPos(10000)
	self.hideHairCheck:SetPaintBackground(false)
	self.hideHairCheck:SetIndent(4)
	local lpInit = LocalPlayer()
	self._hideHairCheckSyncing = false
	self.hideHairCheck:SetChecked(IsValid(lpInit) and lpInit:GetEvoNWBool("hide_hair", false))
	self.hideHairCheck.OnChange = function(_, val)
		if self._hideHairCheckSyncing then return end
		net.Start("server:inventory.SetHideHair")
		net.WriteBool(val)
		net.SendToServer()
		self._lastInvPreviewSig = nil
	end
	-- JUSTE EN DESSOUS du slot katana (remonté à cet effet) et au-dessus du modèle : le bas
	-- de la colonne est occupé par la carte de statistiques (cf. DrawBonusStatsCard).
	self.hideHairCheck:gSetPos(INV.CHECKS_X + 0, INV.CHECKS_Y + 0)
	self.hideHairCheck:gSetSize(208, 28)

	local hideHairBoxSz = 18
	self.hideHairCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideHairBoxSz, hideHairBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideHairBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideHairBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideHairBoxSz - 4 - ind, pnl:GetTall())
		end
	end

	local chk = self.hideHairCheck.Button
	local lbl = self.hideHairCheck.Label
	if IsValid(chk) then
		chk:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chk.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			-- simple check (two segments)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				local ax = Lerp(t, x1, x2)
				local ay = Lerp(t, y1, y2)
				surface.DrawRect(ax, ay, 2, 2)
			end
			for t = 0, 1, 0.1 do
				local ax = Lerp(t, x2, x3)
				local ay = Lerp(t, y2, y3)
				surface.DrawRect(ax, ay, 2, 2)
			end
		end
	end
	if IsValid(lbl) then
		lbl:SetTextColor(Color(210, 210, 218))
		lbl:SetFont("Avenir Next World:14")
		lbl:SetPaintBackground(false)
	end
	self.hideHairCheck:InvalidateLayout(true)

	-- ── Coche « Cacher l'épaulette de grade » (mirroir exact de hideHairCheck) ──
	-- Préférence PAR PERSO networkée (NWBool EVO_HideEpaulette). Visible SEULEMENT si le joueur a
	-- réellement une épaulette (cf. LZY_CHARACTER_CONFIG.HasRankMarker) — pas haori / Espada.
	self.hideEpauletteCheck = vgui.Create("DCheckBoxLabel", self)
	self.hideEpauletteCheck:SetText("Cacher l'épaulette de grade")
	self.hideEpauletteCheck:SetZPos(10000)
	self.hideEpauletteCheck:SetPaintBackground(false)
	self.hideEpauletteCheck:SetIndent(4)
	self._hideEpauletteCheckSyncing = false
	self.hideEpauletteCheck:SetChecked(IsValid(lpInit) and lpInit:GetEvoNWBool("EVO_HideEpaulette", false))
	self.hideEpauletteCheck.OnChange = function(_, val)
		if self._hideEpauletteCheckSyncing then return end
		net.Start("server:inventory.SetHideEpaulette")
		net.WriteBool(val)
		net.SendToServer()
		self._lastInvPreviewSig = nil
	end
	self.hideEpauletteCheck:gSetPos(INV.CHECKS_X + 0, INV.CHECKS_Y + 30)
	self.hideEpauletteCheck:gSetSize(208, 28)
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasRankMarker and IsValid(lpInit) then
		self.hideEpauletteCheck:SetVisible(LZY_CHARACTER_CONFIG.HasRankMarker(
			lpInit:GetEvoNWString("FactionName", ""),
			lpInit:GetEvoNWInt("FactionRank", 0),
			lpInit:GetEvoNWInt("FactionDivision", 0)))
	end

	local hideEpBoxSz = 18
	self.hideEpauletteCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideEpBoxSz, hideEpBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideEpBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideEpBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideEpBoxSz - 4 - ind, pnl:GetTall())
		end
	end

	local chkEp = self.hideEpauletteCheck.Button
	local lblEp = self.hideEpauletteCheck.Label
	if IsValid(chkEp) then
		chkEp:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chkEp.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				surface.DrawRect(Lerp(t, x1, x2), Lerp(t, y1, y2), 2, 2)
			end
			for t = 0, 1, 0.1 do
				surface.DrawRect(Lerp(t, x2, x3), Lerp(t, y2, y3), 2, 2)
			end
		end
	end
	if IsValid(lblEp) then
		lblEp:SetTextColor(Color(210, 210, 218))
		lblEp:SetFont("Avenir Next World:14")
		lblEp:SetPaintBackground(false)
	end
	self.hideEpauletteCheck:InvalidateLayout(true)

	-- ── Coche « Cacher la tenue de grade » (haori / corps Espada). L'accessoire
	-- de DIVISION a désormais SA coche dédiée plus bas (report user 08\16 : une
	-- seule coche cachait les deux, dans les deux sens) ──
	self.hideRankOutfitCheck = vgui.Create("DCheckBoxLabel", self)
	self.hideRankOutfitCheck:SetText("Cacher la tenue de grade")
	self.hideRankOutfitCheck:SetZPos(10000)
	self.hideRankOutfitCheck:SetPaintBackground(false)
	self.hideRankOutfitCheck:SetIndent(4)
	self._hideRankOutfitCheckSyncing = false
	self.hideRankOutfitCheck:SetChecked(IsValid(lpInit) and lpInit:GetEvoNWBool("EVO_HideRankOutfit", false))
	self.hideRankOutfitCheck.OnChange = function(_, val)
		if self._hideRankOutfitCheckSyncing then return end
		net.Start("server:inventory.SetHideRankOutfit")
		net.WriteBool(val)
		net.SendToServer()
		self._lastInvPreviewSig = nil
	end
	self.hideRankOutfitCheck:gSetPos(INV.CHECKS_X + 0, INV.CHECKS_Y + 60)
	self.hideRankOutfitCheck:gSetSize(208, 28)
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasRankOutfit and IsValid(lpInit) then
		-- Grade 15+ (hors SA / animateur) : tenue verrouillée, la coche disparaît.
		self.hideRankOutfitCheck:SetVisible(LZY_CHARACTER_CONFIG.HasRankOutfit(
			lpInit:GetEvoNWString("FactionName", ""),
			lpInit:GetEvoNWInt("FactionRank", 0),
			lpInit:GetEvoNWInt("FactionDivision", 0))
			and not (LZY_CHARACTER_CONFIG.IsRankOutfitLocked and LZY_CHARACTER_CONFIG.IsRankOutfitLocked(lpInit)))
	else
		self.hideRankOutfitCheck:SetVisible(false)
	end

	local hideRoBoxSz = 18
	self.hideRankOutfitCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideRoBoxSz, hideRoBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideRoBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideRoBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideRoBoxSz - 4 - ind, pnl:GetTall())
		end
	end

	local chkRo = self.hideRankOutfitCheck.Button
	local lblRo = self.hideRankOutfitCheck.Label
	if IsValid(chkRo) then
		chkRo:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chkRo.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				surface.DrawRect(Lerp(t, x1, x2), Lerp(t, y1, y2), 2, 2)
			end
			for t = 0, 1, 0.1 do
				surface.DrawRect(Lerp(t, x2, x3), Lerp(t, y2, y3), 2, 2)
			end
		end
	end
	if IsValid(lblRo) then
		lblRo:SetTextColor(Color(210, 210, 218))
		lblRo:SetFont("Avenir Next World:14")
		lblRo:SetPaintBackground(false)
	end
	self.hideRankOutfitCheck:InvalidateLayout(true)

	-- ── Coche « Cacher la tenue de division » : drapeau DÉDIÉ, porté par la DATA
	-- perso (characters.hide_division_body) et pas par un NWBool — cf. serveur
	-- LZY_Character_SetHideDivisionBody. État lu depuis GetPlayerCharacterData.
	local function InvGetHideDivisionBody()
		local lp2 = LocalPlayer()
		local data = IsValid(lp2) and GetPlayerCharacterData and GetPlayerCharacterData(lp2) or nil
		return LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody
			and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(data) or false
	end
	self.hideDivisionBodyCheck = vgui.Create("DCheckBoxLabel", self)
	self.hideDivisionBodyCheck:SetText("Cacher la tenue de division")
	self.hideDivisionBodyCheck:SetZPos(10000)
	self.hideDivisionBodyCheck:SetPaintBackground(false)
	self.hideDivisionBodyCheck:SetIndent(4)
	self._hideDivisionBodyCheckSyncing = false
	self.hideDivisionBodyCheck:SetChecked(InvGetHideDivisionBody())
	self.hideDivisionBodyCheck.OnChange = function(_, val)
		if self._hideDivisionBodyCheckSyncing then return end
		net.Start("server:inventory.SetHideDivisionBody")
		net.WriteBool(val)
		net.SendToServer()
		self._lastInvPreviewSig = nil
	end
	self.hideDivisionBodyCheck:gSetPos(INV.CHECKS_X, INV.CHECKS_Y)
	self.hideDivisionBodyCheck:gSetSize(208, 28)
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasDivisionBody and IsValid(lpInit) then
		self.hideDivisionBodyCheck:SetVisible(LZY_CHARACTER_CONFIG.HasDivisionBody(
			lpInit:GetEvoNWString("FactionName", ""),
			lpInit:GetEvoNWInt("FactionRank", 0),
			lpInit:GetEvoNWInt("FactionDivision", 0)))
	else
		self.hideDivisionBodyCheck:SetVisible(false)
	end
	self.hideDivisionBodyCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideRoBoxSz, hideRoBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideRoBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideRoBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideRoBoxSz - 4 - ind, pnl:GetTall())
		end
	end
	local chkDb = self.hideDivisionBodyCheck.Button
	local lblDb = self.hideDivisionBodyCheck.Label
	if IsValid(chkDb) then
		chkDb:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chkDb.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				surface.DrawRect(Lerp(t, x1, x2), Lerp(t, y1, y2), 2, 2)
			end
			for t = 0, 1, 0.1 do
				surface.DrawRect(Lerp(t, x2, x3), Lerp(t, y2, y3), 2, 2)
			end
		end
	end
	if IsValid(lblDb) then
		lblDb:SetTextColor(Color(210, 210, 218))
		lblDb:SetFont("Avenir Next World:14")
		lblDb:SetPaintBackground(false)
	end
	self.hideDivisionBodyCheck:InvalidateLayout(true)

	-- ── Coche « Porter les gantelets » (Hakuda) : le bonemerge reste visible
	-- hors arme de combat. Visuel uniquement, aucune logique de combat.
	-- Visible SEULEMENT en famille hakuda (miroir des coches de grade).
	self.hakudaAlwaysWearCheck = vgui.Create("DCheckBoxLabel", self)
	self.hakudaAlwaysWearCheck:SetText("Porter les gantelets")
	self.hakudaAlwaysWearCheck:SetZPos(10000)
	self.hakudaAlwaysWearCheck:SetPaintBackground(false)
	self.hakudaAlwaysWearCheck:SetIndent(4)
	self._hakudaAlwaysWearCheckSyncing = false
	self.hakudaAlwaysWearCheck:SetChecked(IsValid(lpInit) and lpInit:GetEvoNWBool("NCM_HakudaAlwaysWear", false))
	self.hakudaAlwaysWearCheck.OnChange = function(_, val)
		if self._hakudaAlwaysWearCheckSyncing then return end
		net.Start("server:inventory.SetHakudaAlwaysWear")
		net.WriteBool(val)
		net.SendToServer()
		self._lastInvPreviewSig = nil
	end
	self.hakudaAlwaysWearCheck:gSetPos(INV.CHECKS_X, INV.CHECKS_Y + 30)
	self.hakudaAlwaysWearCheck:gSetSize(208, 28)
	self.hakudaAlwaysWearCheck:SetVisible(InventoryIsHakudaFamily())
	self.hakudaAlwaysWearCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideRoBoxSz, hideRoBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideRoBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideRoBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideRoBoxSz - 4 - ind, pnl:GetTall())
		end
	end
	local chkHk = self.hakudaAlwaysWearCheck.Button
	local lblHk = self.hakudaAlwaysWearCheck.Label
	if IsValid(chkHk) then
		chkHk:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chkHk.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				surface.DrawRect(Lerp(t, x1, x2), Lerp(t, y1, y2), 2, 2)
			end
			for t = 0, 1, 0.1 do
				surface.DrawRect(Lerp(t, x2, x3), Lerp(t, y2, y3), 2, 2)
			end
		end
	end
	if IsValid(lblHk) then
		lblHk:SetTextColor(Color(210, 210, 218))
		lblHk:SetFont("Avenir Next World:14")
		lblHk:SetPaintBackground(false)
	end
	self.hakudaAlwaysWearCheck:InvalidateLayout(true)

	-- ── Coche « Cacher le catalyseur » : coupe l'effet de particules, l'id reste.
	-- Visible seulement si le perso a un catalyseur tiré.
	self.catalyseurOffCheck = vgui.Create("DCheckBoxLabel", self)
	self.catalyseurOffCheck:SetText("Cacher le catalyseur")
	self.catalyseurOffCheck:SetZPos(10000)
	self.catalyseurOffCheck:SetPaintBackground(false)
	self.catalyseurOffCheck:SetIndent(4)
	self._catalyseurOffCheckSyncing = false
	self.catalyseurOffCheck:SetChecked(IsValid(lpInit) and lpInit:GetEvoNWBool("EVO_CatalyseurOff", false))
	self.catalyseurOffCheck.OnChange = function(_, val)
		if self._catalyseurOffCheckSyncing then return end
		net.Start("server:inventory.SetCatalyseurOff")
		net.WriteBool(val)
		net.SendToServer()
	end
	self.catalyseurOffCheck:gSetPos(INV.CHECKS_X, INV.CHECKS_Y)
	self.catalyseurOffCheck:gSetSize(208, 28)
	self.catalyseurOffCheck:SetVisible(IsValid(lpInit) and lpInit:GetEvoNWString("EvoCatalyseur", "") ~= "")
	self.catalyseurOffCheck.PerformLayout = function(pnl, sw, sh)
		local ind = pnl.m_iIndent or 0
		local btn = pnl.Button
		local lab = pnl.Label
		if IsValid(btn) then
			btn:SetSize(hideRoBoxSz, hideRoBoxSz)
			btn:SetPos(0, math.floor((pnl:GetTall() - hideRoBoxSz) * 0.5))
		end
		if IsValid(lab) then
			lab:SetPos(hideRoBoxSz + 4 + ind, 0)
			lab:SetSize(pnl:GetWide() - hideRoBoxSz - 4 - ind, pnl:GetTall())
		end
	end
	local chkCat = self.catalyseurOffCheck.Button
	local lblCat = self.catalyseurOffCheck.Label
	if IsValid(chkCat) then
		chkCat:SetText("")
		local colBox = Color(18, 18, 20)
		local colBorder = Color(52, 52, 58)
		local colBorderHover = Color(78, 78, 88)
		local colMark = Color(232, 232, 238)
		chkCat.Paint = function(selff, bw, bh)
			local hover = selff:IsHovered()
			draw.RoundedBox(3, 0, 0, bw, bh, colBox)
			surface.SetDrawColor(hover and colBorderHover or colBorder)
			surface.DrawOutlinedRect(0, 0, bw, bh, 1)
			if not selff:GetChecked() then return end
			surface.SetDrawColor(colMark)
			local x1, y1 = math.floor(bw * 0.22), math.floor(bh * 0.52)
			local x2, y2 = math.floor(bw * 0.42), math.floor(bh * 0.72)
			local x3, y3 = math.floor(bw * 0.78), math.floor(bh * 0.28)
			for t = 0, 1, 0.12 do
				surface.DrawRect(Lerp(t, x1, x2), Lerp(t, y1, y2), 2, 2)
			end
			for t = 0, 1, 0.1 do
				surface.DrawRect(Lerp(t, x2, x3), Lerp(t, y2, y3), 2, 2)
			end
		end
	end
	if IsValid(lblCat) then
		lblCat:SetTextColor(Color(210, 210, 218))
		lblCat:SetFont("Avenir Next World:14")
		lblCat:SetPaintBackground(false)
	end
	self.catalyseurOffCheck:InvalidateLayout(true)
	InvRelayoutHideChecks(self)

	-- Set default category to "Tous" (1)
	self.currentCategory = 1
	self.searchText = ""

	-- Function to check if item passes category filter
	function self:ItemPassesCategory(itemId)
		if not itemId or not ITEMS or not ITEMS[itemId] then return false end

		local item = ITEMS[itemId]
		local category = item.category or ""

		-- RECHERCHE (user 09/03) : filtre AVANT la categorie, pour que « Tous » comme une
		-- categorie precise soient tous les deux filtres par le texte saisi. Comparaison
		-- insensible a la casse et aux accents absents : on se contente de string.find
		-- en minuscules, sans motif (4e argument true), pour qu'un tiret ou une
		-- parenthese dans la recherche ne soit pas interprete comme un motif Lua.
		if self.searchText and self.searchText ~= "" then
			local sNom = string.lower((INVENTORY_CONFIG.GetItemDisplayName
				and INVENTORY_CONFIG.GetItemDisplayName(itemId)) or item.name or itemId or "")
			if not string.find(sNom, self.searchText, 1, true) then return false end
		end

		-- Category 1: "Tous" - show all items
		if self.currentCategory == 1 then
			return true
			-- Category 2: "Vetements" - show outfit
		elseif self.currentCategory == 2 then
			return category == "outfit"
			-- Category 3: "Accessoires" - show accessory
		elseif self.currentCategory == 3 then
			return category == "accessory"
			-- Category 4: "Autres" - show object, combat_style, finisher, katana
		elseif self.currentCategory == 4 then
			return category == "object" or category == "combat_style" or category == "finisher"
		end

		return false
	end

	-- Packs items that match the current category (including "Tous") into consecutive slots; physical indices stay on panels for drag/drop.
	function self:RefreshItemsForCategory()
		if not self.slots or not self.inventoryMap then return end

		local numSlots = #self.slots
		local filteredOrdered = {}
		for physIdx = 1, numSlots do
			local itemId = self.inventoryMap[physIdx]
			if itemId and self:ItemPassesCategory(itemId) then
				filteredOrdered[#filteredOrdered + 1] = { physIdx = physIdx, itemId = itemId }
			end
		end

		-- Every visual row must map to a real bag physical index. Occupied-but-filtered slots are "fill" targets (no icon) but keep a valid slotIndex.
		local usedPhys = {}
		for _, e in ipairs(filteredOrdered) do
			usedPhys[e.physIdx] = true
		end
		local fillPhys = {}
		for physIdx = 1, numSlots do
			if not usedPhys[physIdx] then
				fillPhys[#fillPhys + 1] = physIdx
			end
		end

		for vis = 1, numSlots do
			local slot = self.slots[vis]
			if IsValid(slot) then
				if IsValid(slot.ItemPanel) then
					slot.ItemPanel:Remove()
					slot.ItemPanel = nil
				end
				slot.itemId = nil
				slot.stackQty = nil

				if vis <= #filteredOrdered then
					local e = filteredOrdered[vis]
					slot.slotIndex = e.physIdx
					slot.itemId = e.itemId
					slot.stackQty = self.quantityMap and self.quantityMap[e.physIdx] or nil
					slot.ItemPanel = self:CreateItemPanel(slot, e.itemId, e.physIdx)
				else
					local off = vis - #filteredOrdered
					slot.slotIndex = fillPhys[off]
					slot.stackQty = nil
				end
			end
		end

		-- Resize the container so the scrollbar only appears when items overflow.
		-- Minimum 4 rows = exactly one viewport (645px), keeping a clean empty grid
		-- for drop targets when the bag is mostly empty. Beyond 16 items the
		-- container grows row-by-row and DVScrollBar.Enabled flips to true.
		if IsValid(self.slotsContainer) then
			local _slotSize, _spacing, _columns = INV.CELL, INV.GAP, INV.COLS
			local rowsUsed = math.max(4, math.ceil(#filteredOrdered / _columns))
			local newH = rowsUsed * _slotSize + (rowsUsed - 1) * _spacing
			self.slotsContainer:SetSize(self.slotsContainer:GetWide(), gRespY(newH))
			if IsValid(self.scrollPanel) then self.scrollPanel:InvalidateLayout(true) end
		end
	end

	-- ── BARRE DE RECHERCHE (user 09/03), au-dessus des categories ──────────────
	self.searchEntry = vgui.Create("DTextEntry", self)
	self.searchEntry:gSetPos(INV.SEARCH_X, INV.SEARCH_Y)
	self.searchEntry:gSetSize(INV.SEARCH_W, INV.SEARCH_H)
	self.searchEntry:SetFont("Bebas Neue:22")
	self.searchEntry:SetDrawLanguageID(false)
	self.searchEntry:SetPlaceholderText("Rechercher un objet...")
	self.searchEntry:SetPaintBackground(false)
	self.searchEntry:SetTextColor(Color(232, 233, 238))
	self.searchEntry:SetCursorColor(Color(207, 68, 78))
	self.searchEntry.Paint = function(selff, w, h)
		local bFocus = selff:HasFocus()
		if RNDX and RNDX.Draw then
			RNDX.Draw(gRespY(8), 0, 0, w, h, Color(10, 10, 14, 210))
			if RNDX.DrawOutlined then
				RNDX.DrawOutlined(gRespY(8), 0, 0, w, h,
					bFocus and Color(207, 68, 78, 190) or Color(255, 255, 255, 24),
					math.max(1, gRespX(1)))
			end
		else
			draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 14, 210))
		end
		selff:DrawTextEntryText(Color(232, 233, 238), Color(207, 68, 78, 140),
			Color(232, 233, 238))
		-- Placeholder maison : SetPlaceholderText n'est pas dessine quand on reprend Paint.
		if selff:GetValue() == "" and not bFocus then
			draw.SimpleText("Rechercher un objet...", "Bebas Neue:22",
				gRespX(10), h * 0.5, Color(150, 152, 160), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	self.searchEntry.OnChange = function(selff)
		-- Filtre en direct : on repacke la grille a chaque frappe (la liste est courte,
		-- c'est le meme chemin que le changement de categorie).
		self.searchText = string.lower(selff:GetValue() or "")
		if self.RefreshItemsForCategory then self:RefreshItemsForCategory() end
	end

	self.categoryBtns = {}
	local catExtra = INV.GRID_W - (INV.CAT_N - 1) * INV.CAT_GAP - INV.CAT_W * INV.CAT_N
	local catX = INV.CATS_X
	for i = 1, INV.CAT_N do
		local thisW = INV.CAT_W + (i == INV.CAT_N and catExtra or 0)
		self.categoryBtns[i] = vgui.Create("DButton", self)
		self.categoryBtns[i]:gSetSize(thisW, INV.CAT_H)
		self.categoryBtns[i]:gSetPos(catX, INV.CATS_Y)
		catX = catX + thisW + INV.CAT_GAP
		self.categoryBtns[i]:SetText("")
		self.categoryBtns[i].categoryIndex = i
		self.categoryBtns[i].Paint = function(selff, w, h)
			local isSelected = self.currentCategory == selff.categoryIndex
			local material = isSelected and materials.category_hover or
				(selff.hovered and materials.category_hover or materials.category)
			RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), material)
			draw.SimpleText(categories[i], "Avenir Next World:16", w / 2, h / 2,
				isSelected and Color(255, 255, 255, 255) or
				(selff.hovered and Color(255, 255, 255, 255) or Color(255, 255, 255, 255 / 2)), TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER)
		end
		self.categoryBtns[i].DoClick = function()
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			self.currentCategory = i
			self:RefreshItemsForCategory()
		end
		self.categoryBtns[i].OnCursorEntered = function(selff)
			selff.hovered = true
		end
		self.categoryBtns[i].OnCursorExited = function(selff)
			selff.hovered = false
		end
	end

	-- Create scrollable area with slots
	local slotSize = INV.CELL
	local slotSpacing = INV.GAP
	local columns = INV.COLS
	-- "JAMAIS PLEIN" : la grille s'étend pour contenir TOUS les items du sac (min 20
	-- rangées pour garder l'aspect actuel), plafonnée à MAX_BAG_SLOTS. Au-delà du
	-- viewport, le conteneur scrolle (cf. RefreshItemsForCategory).
	local _maxBag = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
	local _highestUsed = 0
	if istable(inventory) then
		for sidx, v in pairs(inventory) do
			local n = tonumber(sidx)
			if n and isstring(v) and v ~= "" and n > _highestUsed then _highestUsed = n end
		end
	end
	local rows = math.Clamp(math.max(20, math.ceil(_highestUsed / columns) + 3), 20, math.ceil(_maxBag / columns))
	local gridWidth = columns * slotSize + (columns - 1) * slotSpacing + 20
	local gridHeight = rows * slotSize + (rows - 1) * slotSpacing
	local scrollHeight = INV.GRID_H -- hauteur visible = INV.ROWS_VISIBLE rangees

	self.scrollPanel = vgui.Create("DScrollPanel", self)
	self.scrollPanel:gSetSize(gridWidth, scrollHeight)
	self.scrollPanel:gSetPos(INV.GRID_X, INV.GRID_Y)

	-- Custom scrollbar styling. The bar is only painted when scrolling is actually
	-- needed (content overflows the viewport). DVScrollBar.Enabled is true when
	-- CanvasSize > BarSize — DScrollPanel sets this each PerformLayout.
	local vbar = self.scrollPanel:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(4)
		vbar:SetHideButtons(true)
		vbar.Paint = function(panel, w, h)
			if not panel.Enabled then return end
			surface.SetDrawColor(20, 20, 20, 140)
			surface.DrawRect(0, 0, w, h)
		end
		if IsValid(vbar.btnGrip) then
			vbar.btnGrip.Paint = function(panel, w, h)
				local bar = panel:GetParent()
				if IsValid(bar) and not bar.Enabled then return end
				local hovered = panel:IsHovered()
				local base = hovered and 150 or 100
				surface.SetDrawColor(255, 255, 255, base)
				surface.DrawRect(0, 0, w, h)
			end
		end
	end

	-- Container panel for slots
	self.slotsContainer = vgui.Create("DPanel", self.scrollPanel)
	self.slotsContainer:SetSize(gRespX(gridWidth), gRespY(gridHeight))
	self.slotsContainer:SetPos(0, 0)
	self.slotsContainer.Paint = function() end -- Transparent background

	-- Drag and drop name
	local droppableName = "INV_ITEM"
	self.equipDroppableName = droppableName

	local DESC_TOOLTIP_DELAY = 0.3

	LZY_INVENTORY_ITEM_TOOLTIP.Install(self)

	-- Function to create item panel inside a slot (panel method so it's accessible from RefreshItemsForCategory)
	function self:OnInvItemDropped(rcv, panels, bDoDrop)
		if not bDoDrop then return end
		local dragged = panels and panels[1]
		if not IsValid(dragged) then return end

		-- Drop on the item (child) : the bag slot is the parent.
		if IsValid(rcv) then
			local p = rcv:GetParent()
			if IsValid(p) and p.ItemPanel == rcv then
				rcv = p
			end
		end

		if dragged.isKatanaEquipped then
			if self.DoUnequipKatana then self:DoUnequipKatana() end
			return
		end

		if dragged.equipSlotId then
			local equipSlotId = dragged.equipSlotId
			local itemId = dragged.itemId
			local toIndex = rcv.slotIndex
			if not toIndex then return end
			if InventoryCombatSwapBlocked(itemId) then return end

			if IsValid(rcv.ItemPanel) then
				local prevId = rcv.ItemPanel.itemId
				self.inventoryMap[toIndex] = nil
				for j = 1, #self.slots do
					if j ~= toIndex and not self.inventoryMap[j] then
						self.inventoryMap[j] = prevId
						break
					end
				end
			end

			self.inventoryMap[toIndex] = itemId

			local eqSlot = self.equipSlots[equipSlotId]
			if IsValid(eqSlot) and IsValid(eqSlot.ItemPanel) then
				eqSlot.ItemPanel:Remove()
				eqSlot.ItemPanel = nil
			end

			self.equippedMap[equipSlotId] = nil
			dragged:Remove()

			net.Start("server:inventory.Unequip")
			net.WriteUInt(equipSlotId, 32)
			net.SendToServer()

			self:RefreshItemsForCategory()
			return
		end

		if not dragged.slotIndex then return end
		local fromIndex = dragged.slotIndex
		local toIndex = rcv and rcv.slotIndex
		local itemId = dragged.itemId
		if not toIndex or not fromIndex then return end
		if self.inventoryMap[toIndex] and not IsValid(rcv.ItemPanel) then return end
		if fromIndex == toIndex then return end

		self.quantityMap = self.quantityMap or {}
		local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
		local qFrom = self.quantityMap[fromIndex] or InventorySlotStackQty(inv, fromIndex)
		if IsValid(rcv.ItemPanel) then
			if INVENTORY_CONFIG.CanMergeBagSlots and INVENTORY_CONFIG.CanMergeBagSlots(inv, fromIndex, toIndex) then
				net.Start("server:inventory.MergeStacks")
				net.WriteUInt(fromIndex, 32)
				net.WriteUInt(toIndex, 32)
				net.SendToServer()
				return
			end
			local prevId = rcv.ItemPanel.itemId
			local qTo = self.quantityMap[toIndex] or InventorySlotStackQty(inv, toIndex)
			self.inventoryMap[fromIndex] = prevId
			self.quantityMap[fromIndex] = qTo
			self.quantityMap[toIndex] = qFrom
		else
			self.inventoryMap[fromIndex] = nil
			self.quantityMap[fromIndex] = nil
			self.quantityMap[toIndex] = qFrom
		end
		self.inventoryMap[toIndex] = itemId

		dragged:Remove()
		self:RefreshItemsForCategory()
	end

	function self:CreateItemPanel(parentSlot, itemId, slotIndex)
		local item = vgui.Create("DPanel", parentSlot)
		item:Dock(FILL)
		item:DockMargin(0, 0, 0, 0)
		item.itemId = itemId
		item.slotIndex = slotIndex
		item._invDbSlotId = tonumber(slotIndex)
		item:SetCursor("hand")

		local it = ITEMS and ITEMS[itemId]

		if LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(item, it, 30, nil, 1)
		else
			item.Paint = function(panel, w, h)
				if it and it.icon then
					-- icon_scale (optionnel, défaut 1) : réduit l'icône en la gardant centrée dans la case.
					local sc = it.icon_scale or 1
					-- Marges PROPORTIONNELLES (fix 09/03) : elles etaient en dur (50 px)
					-- pour des cases de 150 ; a 110 l'icone devenait un timbre-poste.
					-- w * 25/150 redonne exactement la taille des autres chemins d'icone,
					-- qui utilisent deja math.min(w, h) * (100 / 150).
					local mx, my = w * (25 / 150), h * (14 / 150)
					local bw, bh = w - mx * 2, h - mx * 2
					RNDX.DrawMaterial(0, mx + bw * (1 - sc) * 0.5, my + bh * (1 - sc) * 0.5, bw * sc, bh * sc,
						Color(255, 255, 255, 255), Material(it.icon))
				end
			end
		end

		item._descHoverStart = nil
		item._descTooltipShown = false
		item.OnCursorEntered = function(panel)
			panel._descHoverStart = CurTime()
			panel._descTooltipShown = false
			if IsValid(parentSlot) then
				parentSlot.hovered = true
			end
		end
		item.OnCursorExited = function(panel)
			panel._descHoverStart = nil
			panel._descTooltipShown = false
			self:HideItemDescriptionTooltip()
			if IsValid(parentSlot) then
				parentSlot.hovered = false
			end
		end
		item.Think = function(panel)
			if not panel._descHoverStart or panel._descTooltipShown then return end
			if CurTime() - panel._descHoverStart < DESC_TOOLTIP_DELAY then return end
			local id = panel.itemId
			local d = id and ITEMS and ITEMS[id]
			if not InventoryItemHasDescriptionTooltipContent(d) then return end
			panel._descTooltipShown = true
			self:ShowItemDescriptionTooltip(id, panel)
		end
		-- Enable dragging
		item:Droppable(droppableName)
		item:Receiver(droppableName, function(_, panels, bDoDrop)
			self:OnInvItemDropped(parentSlot, panels, bDoDrop)
		end)
		item.OnMousePressed = function(panel, m)
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			if m == MOUSE_LEFT then
				panel:DragMousePress(m)
				local world = vgui and vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
				if IsValid(world) then world:SetCursor("hand") end
			elseif m == MOUSE_RIGHT then
				self:HideItemDescriptionTooltip()
				self.contextmenu = DermaMenu()
				self.contextmenu:SetDrawOnTop(true)
				self.contextmenu:SetMinimumWidth(gRespX(100))
				self.contextmenu.Paint = function(p, w, h)
					draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 10, 235))
				end

				-- DMenuOption:PerformLayout hardcodes height 22; override so row height actually applies.
				local menuOptH = gRespY(35)
				local function inventoryMenuOptionLayout(pnl, lw, lh)
					pnl:SizeToContents()
					pnl:SetWide(pnl:GetWide() + 30)
					lw = math.max(pnl:GetParent():GetWide(), pnl:GetWide())
					pnl:SetSize(lw, menuOptH)
					if IsValid(pnl.SubMenuArrow) then
						pnl.SubMenuArrow:SetSize(15, 15)
						pnl.SubMenuArrow:CenterVertical()
						pnl.SubMenuArrow:AlignRight(4)
					end
					DButton.PerformLayout(pnl, lw, lh)
				end

				local optUse = self.contextmenu:AddOption("Utiliser", function()
					local itemId = panel.itemId
					if not itemId then return end
					local itemData = ITEMS and ITEMS[itemId]
					if not itemData then return end

					-- Si c'est un coffre (lootbox), ouvrir via EVO_LOOT
					if itemData.is_lootbox and EVO_LOOT and EVO_LOOT.RequestOpen then
						EVO_LOOT.RequestOpen(itemId)
						self:Close()
						return
					end

					-- Si c'est un katana, équiper
					if itemData.skin_id then
						if InventoryClientBagDurabilityEquipBlocked(itemId, panel.slotIndex) then
							InventoryNotifyDurabilityEquipBlocked()
							return
						end
						self:DoEquipKatana(itemId, panel.slotIndex)
						return
					end

					-- Si c'est un gantelet Hakuda, équiper via le MÊME slot que le katana (il le
					-- remplace ; en Hakuda tu ne peux équiper que des gantelets, pas d'épée).
					if itemData.gauntlet_id then
						self:DoEquipKatana(itemId, panel.slotIndex)
						return
					end

					-- Tenue (outfit) : équiper sur le slot tenue (même flux que glisser-déposer)
					if itemData.category == "outfit" and isstring(itemData.model_path) and itemData.model_path ~= "" then
						if InventoryClientBagDurabilityEquipBlocked(itemId, panel.slotIndex) then
							InventoryNotifyDurabilityEquipBlocked()
							return
						end
						self:DoEquipOutfit(itemId, panel.slotIndex)
						return
					end

					if itemData.category == "accessory" and INVENTORY_CONFIG.GetAccessoryEquipSlot and INVENTORY_CONFIG.GetAccessoryEquipSlot(itemData) then
						if InventoryClientBagDurabilityEquipBlocked(itemId, panel.slotIndex) then
							InventoryNotifyDurabilityEquipBlocked()
							return
						end
						self:DoEquipAccessory(itemId, panel.slotIndex)
						return
					end

					-- ITEMS[itemId].on_use : exécuté ici (client) puis validé et réexécuté sur le serveur
					if itemData.on_use then
						local lp = LocalPlayer()
						if IsValid(lp) then
							itemData.on_use(lp, panel.slotIndex)
						end
						net.Start("server:inventory.UseItem")
						net.WriteString(itemId)
						net.WriteUInt(panel.slotIndex or 0, 32)
						net.SendToServer()
						-- Équipement assassin (pièges/grenades, visée en 2 temps) :
						-- l'item devient AUSSI le consommable rapide assigné — la
						-- touche d'action rapide confirme la pose direct (user 08/20).
						if EVO_CRAFT and EVO_CRAFT.AssassinGearByKey and EVO_CRAFT.AssassinGearByKey(itemId) then
							RunConsoleCommand("evo_quickitem", itemId)
							local keyName = "ta touche d'action rapide"
							local binds = LZY_BindMenu and LZY_BindMenu.GetLocalBinds and LZY_BindMenu.GetLocalBinds()
							local be = binds and binds.combatBinds and binds.combatBinds.quick_item
							if be and be.bind and IsValid(lp) and lp.ConvertBindToDisplayName then
								keyName = "la touche " .. lp:ConvertBindToDisplayName(be.bind)
							end
							notification.AddLegacy("Appuie sur " .. keyName .. " pour poser directement.", NOTIFY_GENERIC, 4)
						end
						self:Close()
						return
					end

					-- Autres items: hook generique
					hook.Run("LZY_Inventory_UseItem", itemId, panel.slotIndex)
					self:Close()
				end)
				optUse:SetTextColor(Color(230, 230, 230))
				optUse:SetFont("Avenir Next World:16")
				optUse.PerformLayout = inventoryMenuOptionLayout
				optUse.Paint = function(p, w, h)
					local bg = p:IsHovered() and Color(255, 255, 255, 20) or Color(255, 255, 255, 6)
					draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
				end


				-- « Consommable rapide » (renommé user 08/19) : l'assigner au PETIT SLOT de la
				-- spell bar (convar client evo_quickitem, bind combat quick_item).
				-- Éligibilité = prédicat UNIQUE partagé avec le radial (potions +
				-- équipement assassin, jamais les champignons).
				local ctxItemData = ITEMS and ITEMS[panel.itemId]
				if INVENTORY_CONFIG and INVENTORY_CONFIG.IsQuickConsumable
					and INVENTORY_CONFIG.IsQuickConsumable(panel.itemId) then

					local optQuick = self.contextmenu:AddOption("Consommable rapide", function()
						local itemId = panel.itemId
						if not itemId then return end
						-- Mode PLACEMENT (user 08/20) : la roue s'ouvre avec le curseur
						-- de l'inventaire et on CLIQUE la bulle où RANGER l'item.
						if LZY_SpellBar_QuickRadialPlace then
							LZY_SpellBar_QuickRadialPlace(itemId)
							return
						end
						-- Repli (spell bar absente) : assignation directe du petit slot.
						RunConsoleCommand("evo_quickitem", itemId)
						local keyName = "?"
						local lp = LocalPlayer()
						local binds = LZY_BindMenu and LZY_BindMenu.GetLocalBinds and LZY_BindMenu.GetLocalBinds()
						local be = binds and binds.combatBinds and binds.combatBinds.quick_item
						if be and be.bind and IsValid(lp) and lp.ConvertBindToDisplayName then
							keyName = lp:ConvertBindToDisplayName(be.bind)
						end
						notification.AddLegacy("Consommable rapide : « " .. ((ctxItemData and ctxItemData.name) or itemId)
							.. " » (touche " .. keyName .. ").", NOTIFY_GENERIC, 4)
					end)
					optQuick:SetTextColor(Color(125, 195, 235))
					optQuick:SetFont("Avenir Next World:16")
					optQuick.PerformLayout = inventoryMenuOptionLayout
					optQuick.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(125, 195, 235, 25) or Color(125, 195, 235, 8)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end
				end

				-- Jeter only if item allows world drop (see INVENTORY_CONFIG.IsItemDroppable —
				-- gate UNIQUE drop+trade : cosmétiques accessoires/vêtements réservés superadmin).
				-- LocalPlayer() : un superadmin voit l'option même sur un is_droppable=false.
				local invNow = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
				local slotQty = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(invNow, panel.slotIndex) or 1

				if slotQty > 1 then
					-- Pile de COFFRES (user 09/09) : en ouvrir plusieurs d'un coup, une seule
					-- animation et un recapitulatif. Le serveur borne la quantite a la pile.
					local itemDataQ = ITEMS and ITEMS[panel.itemId]
					if itemDataQ and itemDataQ.is_lootbox and EVO_LOOT and EVO_LOOT.RequestOpenMany and INVENTORY_CONFIG.PromptQuantity then
						local itemIdQ = panel.itemId
						local maxOpen = math.min(slotQty, EVO_LOOT.MaxOpenAtOnce or 64)
						local optOpenMany = self.contextmenu:AddOption("Ouvrir plusieurs", function()
							INVENTORY_CONFIG.PromptQuantity(
								"Ouvrir des coffres",
								"Combien de coffres ouvrir ? (1–" .. maxOpen .. ")",
								maxOpen,
								function(n)
									EVO_LOOT.RequestOpenMany(itemIdQ, n)
									if IsValid(self) then self:Close() end
								end,
								{ min = 1, default = maxOpen, confirm = "Ouvrir" }
							)
						end)
						optOpenMany:SetTextColor(Color(240, 200, 110))
						optOpenMany:SetFont("Avenir Next World:16")
						optOpenMany.PerformLayout = inventoryMenuOptionLayout
						optOpenMany.Paint = function(p, w, h)
							local bg = p:IsHovered() and Color(240, 200, 110, 25) or Color(240, 200, 110, 8)
							draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
						end
					end

					local optSplit = self.contextmenu:AddOption("Séparer", function()
						local slotIdx = panel.slotIndex
						if not slotIdx then return end
						INVENTORY_CONFIG.PromptQuantity(
							"Séparer",
							"Combien d'exemplaires mettre dans un nouveau slot ? (1–" .. (slotQty - 1) .. ")",
							slotQty - 1,
							function(n)
								net.Start("server:inventory.SplitStack")
								net.WriteUInt(slotIdx, 32)
								net.WriteUInt(n, 16)
								net.SendToServer()
							end,
							{ min = 1, default = 1, confirm = "Séparer" }
						)
					end)
					optSplit:SetTextColor(Color(220, 200, 140))
					optSplit:SetFont("Avenir Next World:16")
					optSplit.PerformLayout = inventoryMenuOptionLayout
					optSplit.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(220, 200, 140, 25) or Color(220, 200, 140, 8)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end
				end

				-- Perso animation : « Jeter » seulement pour les documents RP (bDocumentItem),
				-- miroir du gate serveur (server:inventory.DropItem).
				local bAnimNoDrop = LocalPlayer():GetEvoNWBool("EVO_AnimChar", false)
					and not (ITEMS and ITEMS[panel.itemId] and ITEMS[panel.itemId].bDocumentItem)
				if not bAnimNoDrop and INVENTORY_CONFIG.IsItemDroppable(panel.itemId, LocalPlayer(), panel.slotIndex) then
					local optDrop = self.contextmenu:AddOption("Jeter", function()
						local slotIdx = panel.slotIndex
						if not slotIdx then return end
						local function sendDrop(n)
							net.Start("server:inventory.DropItem")
							net.WriteUInt(slotIdx, 32)
							net.WriteUInt(n or 0, 16)
							net.SendToServer()
							self:Close()
						end
						if slotQty > 1 and INVENTORY_CONFIG.PromptQuantity then
							INVENTORY_CONFIG.PromptQuantity(
								"Jeter",
								"Combien jeter au sol ? (1–" .. slotQty .. ")",
								slotQty,
								sendDrop,
								{ min = 1, default = slotQty, confirm = "Jeter" }
							)
						else
							sendDrop(slotQty)
						end
					end)
					optDrop:SetTextColor(Color(230, 80, 80))
					optDrop:SetFont("Avenir Next World:16")
					optDrop.PerformLayout = inventoryMenuOptionLayout
					optDrop.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(255, 120, 120, 25) or Color(255, 120, 120, 8)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end
				end
				self.contextmenu:Open()

				-- Option "Supprimer" : ouverte à TOUT joueur (confirmation par popup).
				-- is_deletable=false (armes d'entraînement, parchemins...) -> pas d'option (sauf superadmin).
				if INVENTORY_CONFIG.IsItemDeletable(panel.itemId, LocalPlayer()) then
					local optDelete = self.contextmenu:AddOption("Supprimer", function()
						local itemId = panel.itemId
						if not itemId then return end
						local slotIdx = panel.slotIndex
						local itemName = INVENTORY_CONFIG.GetItemDisplayName
							and INVENTORY_CONFIG.GetItemDisplayName(itemId, slotIdx, LocalPlayer():GetInventory())
							or (ITEMS and ITEMS[itemId] and ITEMS[itemId].name or itemId)
						local function askConfirm(n)
							n = math.max(1, math.floor(tonumber(n) or 1))
							LZY_POPUP_CALLBACKS["Inventory_DeleteItem"] = function()
								net.Start("server:inventory.DeleteItem")
								net.WriteString(itemId)
								net.WriteUInt(slotIdx or 0, 32)
								net.WriteUInt(n, 16)
								net.SendToServer()
							end
							local qtyTxt = n > 1 and (" ×" .. n) or ""
							-- GROS WARNING : coffre-only (pas de rachat boutique) > shop coins > simple.
							if isfunction(LZY_Shop_IsCoffreOnlyItem) and LZY_Shop_IsCoffreOnlyItem(itemId) then
								LocalPlayer():OpenYesNoPopup(
									"ATTENTION : « " ..
									itemName .. qtyTxt ..
									" » ne s'obtient QU'EN COFFRE.\n\nSi tu le supprimes, il ne pourra pas être racheté : il faudra le retirer à nouveau d'un coffre, sans garantie.\n\nSupprimer quand même ?",
									"Inventory_DeleteItem", nil, nil, "AVERTISSEMENT")
							elseif isfunction(LZY_Shop_IsShopItem) and LZY_Shop_IsShopItem(itemId) then
								LocalPlayer():OpenYesNoPopup(
									"ATTENTION : « " ..
									itemName .. qtyTxt ..
									" » a été acheté avec des COINS en boutique.\n\nSi tu le supprimes, il faudra le RACHETER avec des coins pour le récupérer.\n\nSupprimer quand même ?",
									"Inventory_DeleteItem", nil, nil, "AVERTISSEMENT")
							else
								LocalPlayer():OpenYesNoPopup("Supprimer définitivement « " .. itemName .. qtyTxt .. " » ?",
									"Inventory_DeleteItem")
							end
						end
						if slotQty > 1 and INVENTORY_CONFIG.PromptQuantity then
							INVENTORY_CONFIG.PromptQuantity(
								"Supprimer",
								"Combien supprimer ? (1–" .. slotQty .. ")",
								slotQty,
								askConfirm,
								{ min = 1, default = 1, confirm = "Continuer" }
							)
						else
							askConfirm(1)
						end
					end)
					optDelete:SetTextColor(Color(255, 60, 60))
					optDelete:SetFont("Avenir Next World:16")
					optDelete.PerformLayout = inventoryMenuOptionLayout
					optDelete.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(255, 60, 60, 30) or Color(255, 60, 60, 10)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end
				end
			end
		end
		item.OnMouseReleased = function(panel, m)
			panel:DragMouseRelease(m)
			local world = vgui and vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
			if IsValid(world) then world:SetCursor("arrow") end
		end
		return item
	end

	-- Create slots (4 per row)
	self.slots = {}
	self.inventoryMap = {}
	self.quantityMap = {}
	local slotIndex = 1
	for row = 0, rows - 1 do
		for col = 0, columns - 1 do
			local slot = vgui.Create("DPanel", self.slotsContainer)
			slot:gSetSize(slotSize, slotSize)
			slot:gSetPos(col * (slotSize + slotSpacing), row * (slotSize + slotSpacing))
			slot:SetMouseInputEnabled(true)
			slot.slotIndex = slotIndex
			slot.ItemPanel = nil
			local bagVal = inventory[slotIndex]
			slot.itemId = (isstring(bagVal) and bagVal ~= "") and bagVal or nil
			slot.hovered = false
			if slot.itemId then
				self.inventoryMap[slotIndex] = slot.itemId
				self.quantityMap[slotIndex] = InventorySlotStackQty(inventoryData, slotIndex)
				slot.stackQty = self.quantityMap[slotIndex]
			end

			slot.Paint = function(selff, w, h)
				local itemId = selff.itemId or (IsValid(selff.ItemPanel) and selff.ItemPanel.itemId) or nil
				local material = selff.hovered and GetItemSlotHoverMaterial(itemId, selff.slotIndex) or materials.slot
				RNDX.Draw(8, 0, 0, w, h, Color(255, 255, 255, 255), RNDX.BLUR)
				RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), material)
			end

			AttachInventorySlotNameOverlay(slot, function(s)
				return s.itemId or (IsValid(s.ItemPanel) and s.ItemPanel.itemId) or nil
			end)

			slot.OnCursorEntered = function(selff)
				selff.hovered = true
			end
			slot.OnCursorExited = function(selff)
				selff.hovered = false
			end

			-- Prevent slot from being draggable (only items should be draggable)
			slot.OnMousePressed = function(selff, m)
				-- Do nothing - prevent dragging the slot itself
			end

			-- Accept drops (but don't make it draggable)
			slot:Droppable(droppableName)
			slot:Receiver(droppableName, function(rcv, panels, bDoDrop)
				self:OnInvItemDropped(rcv, panels, bDoDrop)
			end)

			-- Create item panel if slot has item
			if slot.itemId then
				slot.ItemPanel = self:CreateItemPanel(slot, slot.itemId, slotIndex)
			end

			self.slots[slotIndex] = slot
			slotIndex = slotIndex + 1
		end
	end

	-- Refresh items to show all items initially (category "Tous" is selected by default)
	self:RefreshItemsForCategory()

	-- Create 6 equipment slots
	self.equipSlots = {}
	self.equippedMap = {}

	function self:CreateEquipItemPanel(parentSlot, itemId, equipSlotId)
		local item = vgui.Create("DPanel", parentSlot)
		item:Dock(FILL)
		item:DockMargin(0, 0, 0, 0)
		item.itemId = itemId
		item.equipSlotId = equipSlotId
		item._invDbSlotId = (INVENTORY_CONFIG and INVENTORY_CONFIG.DB_EQUIP_SLOT_BASE or 1000) + tonumber(equipSlotId)
		item:SetCursor("hand")
		local itEquip = ITEMS and ITEMS[itemId]
		if LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(itEquip) then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(item, itEquip, 25, nil, 1)
		else
			item.Paint = function(panel, w, h)
				local it = ITEMS and ITEMS[itemId]
				if it and it.icon then
					local iconSize = math.min(w, h) * (100 / 150)
					local ox = (w - iconSize) / 2
					local oy = (h - iconSize) / 2
					RNDX.DrawMaterial(0, ox, oy, iconSize, iconSize, Color(255, 255, 255, 255), Material(it.icon))
				end
			end
		end
		item._descHoverStart = nil
		item._descTooltipShown = false
		item.OnCursorEntered = function(panel)
			panel._descHoverStart = CurTime()
			panel._descTooltipShown = false
			if IsValid(parentSlot) then
				parentSlot.hovered = true
			end
		end
		item.OnCursorExited = function(panel)
			panel._descHoverStart = nil
			panel._descTooltipShown = false
			self:HideItemDescriptionTooltip()
			if IsValid(parentSlot) then
				parentSlot.hovered = false
			end
		end
		item.Think = function(panel)
			if not panel._descHoverStart or panel._descTooltipShown then return end
			if CurTime() - panel._descHoverStart < DESC_TOOLTIP_DELAY then return end
			local id = panel.itemId
			local d = id and ITEMS and ITEMS[id]
			if not InventoryItemHasDescriptionTooltipContent(d) then return end
			panel._descTooltipShown = true
			self:ShowItemDescriptionTooltip(id, panel)
		end
		-- Enable dragging
		item:Droppable(droppableName)
		item.OnMousePressed = function(panel, m)
			surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
			if m == MOUSE_LEFT then
				panel:DragMousePress(m)
				local world = vgui and vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
				if IsValid(world) then world:SetCursor("hand") end
			elseif m == MOUSE_RIGHT then
				local it = ITEMS and ITEMS[itemId]
				local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
				-- Sa case, ou une autre case libre si c'est un cosmetique (CanAccessoryUseSlot).
				local accHere = it and it.category == "accessory"
					and INVENTORY_CONFIG.CanAccessoryUseSlot(itemId, equipSlotId)
				local showUnequip = (equipSlotId == outfitSlot and it and it.category == "outfit")
					or accHere
				local showEdit = accHere
					and isstring(it.model_path) and it.model_path ~= "" and not it.fourreau_cosmetic and not it.compagnon_id
				if showUnequip or showEdit then
					self:HideItemDescriptionTooltip()
					self.contextmenu = DermaMenu()
					self.contextmenu:SetDrawOnTop(true)
					self.contextmenu:SetMinimumWidth(gRespX(100))
					self.contextmenu.Paint = function(p, w, h)
						draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 10, 235))
					end

					local menuOptH = gRespY(35)
					local function outfitEquipMenuOptionLayout(pnl, lw, lh)
						pnl:SizeToContents()
						pnl:SetWide(pnl:GetWide() + 30)
						lw = math.max(pnl:GetParent():GetWide(), pnl:GetWide())
						pnl:SetSize(lw, menuOptH)
						if IsValid(pnl.SubMenuArrow) then
							pnl.SubMenuArrow:SetSize(15, 15)
							pnl.SubMenuArrow:CenterVertical()
							pnl.SubMenuArrow:AlignRight(4)
						end
						DButton.PerformLayout(pnl, lw, lh)
					end

					local optUnequip = self.contextmenu:AddOption("Déséquiper", function()
						if equipSlotId == outfitSlot and it and it.category == "outfit" then
							self:DoUnequipOutfit(equipSlotId)
						else
							self:DoUnequipAccessorySlot(equipSlotId)
						end
					end)
					optUnequip:SetTextColor(Color(230, 230, 230))
					optUnequip:SetFont("Avenir Next World:16")
					optUnequip.PerformLayout = outfitEquipMenuOptionLayout
					optUnequip.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(255, 255, 255, 20) or Color(255, 255, 255, 6)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end

					if showEdit then
						local optEdit = self.contextmenu:AddOption("Editer", function()
							self:Close()
							timer.Simple(0, function()
								if LZY_AccessoryEditor_Open then
									LZY_AccessoryEditor_Open(equipSlotId)
								end
							end)
						end)
						optEdit:SetTextColor(Color(180, 210, 255))
						optEdit:SetFont("Avenir Next World:16")
						optEdit.PerformLayout = outfitEquipMenuOptionLayout
						optEdit.Paint = function(p, w, h)
							local bg = p:IsHovered() and Color(120, 170, 255, 28) or Color(120, 170, 255, 10)
							draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
						end
					end
					-- Tenue ÉQUIPÉE : l'accessoire de division coexiste avec elle, il
					-- reste éditable d'ici (la case vide a sa propre entrée plus bas).
					if equipSlotId == outfitSlot and InventoryCanEditDivisionBody() then
						local optDiv = self.contextmenu:AddOption("Editer l'accessoire de division", function()
							self:Close()
							timer.Simple(0, function()
								if LZY_AccessoryEditor_Open then
									LZY_AccessoryEditor_Open(INVENTORY_CONFIG.DIVISION_BODY_SLOT or "division_body")
								end
							end)
						end)
						optDiv:SetTextColor(Color(180, 210, 255))
						optDiv:SetFont("Avenir Next World:16")
						optDiv.PerformLayout = outfitEquipMenuOptionLayout
						optDiv.Paint = function(p, w, h)
							local bg = p:IsHovered() and Color(120, 170, 255, 28) or Color(120, 170, 255, 10)
							draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
						end
					end
					-- Épaulette de grade : même technique que l'accessoire de division
					-- (user 08/30) — elle coexiste avec la tenue, équipée ou non.
					if equipSlotId == outfitSlot and InventoryCanEditGrade() then
						local optGrade = self.contextmenu:AddOption("Editer l'épaulette de grade", function()
							self:Close()
							timer.Simple(0, function()
								if LZY_AccessoryEditor_Open then
									LZY_AccessoryEditor_Open(INVENTORY_CONFIG.GRADE_SLOT or "grade")
								end
							end)
						end)
						optGrade:SetTextColor(Color(180, 210, 255))
						optGrade:SetFont("Avenir Next World:16")
						optGrade.PerformLayout = outfitEquipMenuOptionLayout
						optGrade.Paint = function(p, w, h)
							local bg = p:IsHovered() and Color(120, 170, 255, 28) or Color(120, 170, 255, 10)
							draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
						end
					end
					self.contextmenu:Open()
				end
			end
		end
		item.OnMouseReleased = function(panel, m)
			panel:DragMouseRelease(m)
			local world = vgui and vgui.GetWorldPanel and vgui.GetWorldPanel() or nil
			if IsValid(world) then world:SetCursor("arrow") end
		end
		return item
	end

	for i = 1, (INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) do
		local equipSlot = vgui.Create("DPanel", self)
		equipSlot:gSetSize(INV.EQUIP_PX, INV.EQUIP_PX)
		equipSlot:SetMouseInputEnabled(true)
		equipSlot.slotId = i
		equipSlot.ItemPanel = nil
		equipSlot.hovered = false

		equipSlot.Paint = function(selff, w, h)
			local itemId = (IsValid(selff.ItemPanel) and selff.ItemPanel.itemId) or nil
			local material = selff.hovered and GetItemSlotHoverMaterial(itemId, selff._invDbSlotId) or materials.equipement_slot
			RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), material)

			if not itemId then
				local ph = EQUIP_SLOT_PLACEHOLDER[selff.slotId]
				if ph and (isfunction(ph) or not ph:IsError()) then
					local iconSize = math.min(w, h) * (100 / 150)
					local ox = (w - iconSize) / 2
					local oy = (h - iconSize) / 2
					local a = selff.hovered and 200 or 115
					if isfunction(ph) then
						ph(ox, oy, iconSize, Color(255, 255, 255, a))
					else
						RNDX.DrawMaterial(0, ox, oy, iconSize, iconSize, Color(255, 255, 255, a), ph)
					end
				end
			end
		end

		AttachInventorySlotNameOverlay(equipSlot, function(s)
			return IsValid(s.ItemPanel) and s.ItemPanel.itemId or nil
		end)

		equipSlot.OnCursorEntered = function(selff)
			selff.hovered = true
		end
		equipSlot.OnCursorExited = function(selff)
			selff.hovered = false
		end

		-- Prevent slot from being draggable (only items should be draggable).
		-- Case MASQUE vide + Hollow : clic droit → éditer le masque de base Arrancar.
		-- Case TENUE : clic droit → éditer l'accessoire body de DIVISION (posé
		-- d'office, il coexiste avec la tenue, équipée ou non).
		equipSlot.OnMousePressed = function(selff, m)
			if m ~= MOUSE_RIGHT then return end
			local maskSlot = INVENTORY_CONFIG.MASK_EQUIP_SLOT or 7
			local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
			-- Chaque entrée = { libellé, pseudo-slot } ; la case tenue peut en offrir
			-- DEUX (division + épaulette de grade, user 08/30), le masque une seule.
			local editEntries = {}
			if selff.slotId == maskSlot then
				if IsValid(selff.ItemPanel) then return end
				if not InventoryCanEditMasqueBase() then return end
				editEntries[1] = { label = "Editer", slot = INVENTORY_CONFIG.MASQUE_BASE_SLOT or "masque_base" }
			elseif selff.slotId == outfitSlot then
				-- La tenue équipée a son propre menu (Déséquiper) via l'item : cette
				-- entrée ne sert que la case VIDE, comme le masque.
				if IsValid(selff.ItemPanel) then return end
				if InventoryCanEditDivisionBody() then
					editEntries[#editEntries + 1] = { label = "Editer l'accessoire de division", slot = INVENTORY_CONFIG.DIVISION_BODY_SLOT or "division_body" }
				end
				if InventoryCanEditGrade() then
					editEntries[#editEntries + 1] = { label = "Editer l'épaulette de grade", slot = INVENTORY_CONFIG.GRADE_SLOT or "grade" }
				end
				if #editEntries == 0 then return end
			else
				return
			end

			self:HideItemDescriptionTooltip()
			if IsValid(self.contextmenu) then self.contextmenu:Remove() end
			self.contextmenu = DermaMenu()
			self.contextmenu:SetDrawOnTop(true)
			self.contextmenu:SetMinimumWidth(gRespX(100))
			self.contextmenu.Paint = function(p, w, h)
				draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 10, 235))
			end

			local menuOptH = gRespY(35)
			local function masqueBaseMenuOptionLayout(pnl, lw, lh)
				pnl:SizeToContents()
				pnl:SetWide(pnl:GetWide() + 30)
				lw = math.max(pnl:GetParent():GetWide(), pnl:GetWide())
				pnl:SetSize(lw, menuOptH)
				if IsValid(pnl.SubMenuArrow) then
					pnl.SubMenuArrow:SetSize(15, 15)
					pnl.SubMenuArrow:CenterVertical()
					pnl.SubMenuArrow:AlignRight(4)
				end
				DButton.PerformLayout(pnl, lw, lh)
			end

			for _, entry in ipairs(editEntries) do
				local sSlot = entry.slot
				local optEdit = self.contextmenu:AddOption(entry.label, function()
					self:Close()
					timer.Simple(0, function()
						if LZY_AccessoryEditor_Open then
							LZY_AccessoryEditor_Open(sSlot)
						end
					end)
				end)
				optEdit:SetTextColor(Color(180, 210, 255))
				optEdit:SetFont("Avenir Next World:16")
				optEdit.PerformLayout = masqueBaseMenuOptionLayout
				optEdit.Paint = function(p, w, h)
					local bg = p:IsHovered() and Color(120, 170, 255, 28) or Color(120, 170, 255, 10)
					draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
				end
			end
			self.contextmenu:Open()
		end

		-- Accept drops (but don't make it draggable)
		equipSlot:Droppable(droppableName)
		equipSlot:Receiver(droppableName, function(rcv, panels, bDoDrop)
			if not bDoDrop then return end
			local dragged = panels and panels[1]
			if not IsValid(dragged) then return end

			-- Block katana items from general equipment slots (use katana slot instead)
			local dragItemData = ITEMS and dragged.itemId and ITEMS[dragged.itemId]
			if dragItemData and dragItemData.skin_id then return end

			local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
			if dragItemData and dragItemData.category == "outfit" and rcv.slotId ~= outfitSlot then return end
			if rcv.slotId == outfitSlot then
				if not dragItemData or dragItemData.category ~= "outfit" then return end
			end

			if dragItemData and dragItemData.category == "accessory" then
				-- Sa case, ou une autre case libre si c'est un cosmetique (CanAccessoryUseSlot).
				if not INVENTORY_CONFIG.CanAccessoryUseSlot(dragged.itemId, rcv.slotId) then return end
			elseif rcv.slotId ~= outfitSlot and rcv.slotId >= 1 and rcv.slotId <= 6 then
				return
			end

			-- If dragged from inventory grid
			if dragged.slotIndex then
				local fromIndex = dragged.slotIndex
				local itemId = dragged.itemId
				if not fromIndex then return end
				-- Lock combat ignoré pour TENUES + accessoires cosmétiques (sans stats) ;
				-- gardé pour les items à stats (cf. InventoryCombatSwapBlocked/ItemAffectsStats).
				-- On passe aussi l'item DÉPLACÉ (slot occupé) : remplacer un item à stats = bloqué.
				local dispId = IsValid(rcv.ItemPanel) and rcv.ItemPanel.itemId or nil
				if InventoryCombatSwapBlocked(itemId, dispId) then return end
				if InventoryFactionEquipBlocked(itemId) then return end
				if InventoryClientBagDurabilityEquipBlocked(itemId, fromIndex) then
					InventoryNotifyDurabilityEquipBlocked()
					return
				end

				if IsValid(rcv.ItemPanel) then
					local prevItemId = rcv.ItemPanel.itemId
					rcv.ItemPanel:Remove()
					rcv.ItemPanel = nil

					for j = 1, #self.slots do
						if j ~= fromIndex and not self.inventoryMap[j] then
							self.inventoryMap[j] = prevItemId
							break
						end
					end
				end

				self.equippedMap[rcv.slotId] = itemId
				rcv.ItemPanel = self:CreateEquipItemPanel(rcv, itemId, rcv.slotId)

				dragged:Remove()
				self.inventoryMap[fromIndex] = nil

				-- Nouvel accessoire sur ce slot -> REINITIALISE l'edition (offset) cote client
				-- (rendu cl_models + editeur) : le nouvel item ne reprend PAS la position editee
				-- de l'ancien (demande user). Le serveur reinitialise deja sa copie autoritative.
				local _cdEq = GetPlayerCharacterData and GetPlayerCharacterData(LocalPlayer())
				if _cdEq and _cdEq.equipped_accessory_offsets then _cdEq.equipped_accessory_offsets[tostring(rcv.slotId)] = nil end
				net.Start("server:inventory.Equip")
				net.WriteString(itemId)
				net.WriteUInt(rcv.slotId, 32)
				net.WriteUInt(fromIndex, 32)
				net.SendToServer()

				self:RefreshItemsForCategory()
			end
		end)

		-- Check if slot has equipped item (will be handled by RefreshEquippedItems)
		-- This is kept for initial load, but RefreshEquippedItems will handle it properly

		-- Œil "cacher/afficher SUR LE PERSONNAGE" (slots ACCESSOIRES uniquement :
		-- bague/collier/bracelet/etc., pas la tenue). Visuel seulement — les stats
		-- restent actives. État synchronisé par le serveur (NWString), persistant
		-- par perso/slot ; visible seulement quand un item est équipé dans la case.
		local eyeOutfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
		if i ~= eyeOutfitSlot then
			local eye = vgui.Create("DButton", equipSlot)
			eye:SetText("")
			-- RÉDUIT (18) + responsive UNIFORME (min largeur/hauteur, comme R() des
			-- autres UIs) : carré parfait sur tous les ratios, pas d'étirement gRespX/Y.
			local eyeScale = math.min(ScrW() / 1920, ScrH() / 1080)
			local eyeSize = math.Round(18 * eyeScale)
			eye:SetSize(eyeSize, eyeSize)
			eye:SetPos(math.Round(3 * eyeScale), math.Round(3 * eyeScale))
			-- ZPos haut + MoveToFront (Think) : l'ItemPanel (vignette draggable) est
			-- (re)créé PAR-DESSUS à chaque équipement et volerait le clic sinon.
			eye:SetZPos(1000)

			-- Œil en DHTML (SVG inline, fond transparent — demande user). Le SVG n'est
			-- ré-écrit QUE quand l'état caché/visible change (pas de SetHTML par frame).
			local html = vgui.Create("DHTML", eye)
			html:Dock(FILL)
			html:SetMouseInputEnabled(false)
			html:SetKeyboardInputEnabled(false)
			local function eyeSVG(hidden)
				local col = hidden and "#cf444e" or "#ebebf0"
				local slash = hidden
					and ('<line x1="4" y1="20" x2="20" y2="4" stroke="#101013" stroke-width="4.2" stroke-linecap="round"/>'
						.. '<line x1="4" y1="20" x2="20" y2="4" stroke="' .. col .. '" stroke-width="2.4" stroke-linecap="round"/>')
					or ""
				-- PAS de fond : juste l'œil (DA serveur : blanc #ebebf0 / accent #cf444e).
				-- Chaque trait est doublé d'un liseré sombre #101013 (lisible sur l'icône
				-- de l'item). Le div .w grossit au survol (transition CSS, cf setHover).
				return [[<!DOCTYPE html><html><body style="margin:0;padding:0;background:transparent;overflow:hidden;">
					<div id="w" style="width:100%;height:100%;transition:transform .12s ease-out;transform-origin:50% 50%;">
					<svg viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
					<path d="M12 5C6.5 5 2.6 9.3 1.5 11.4a1.2 1.2 0 0 0 0 1.2C2.6 14.7 6.5 19 12 19s9.4-4.3 10.5-6.4a1.2 1.2 0 0 0 0-1.2C21.4 9.3 17.5 5 12 5z" fill="none" stroke="#101013" stroke-width="3.8"/>
					<path d="M12 5C6.5 5 2.6 9.3 1.5 11.4a1.2 1.2 0 0 0 0 1.2C2.6 14.7 6.5 19 12 19s9.4-4.3 10.5-6.4a1.2 1.2 0 0 0 0-1.2C21.4 9.3 17.5 5 12 5z" fill="none" stroke="]] ..
					col .. [[" stroke-width="2"/>
					<circle cx="12" cy="12" r="4" fill="#101013"/>
					<circle cx="12" cy="12" r="3.2" fill="]] .. col .. [["/>
					]] .. slash .. [[</svg></div>
					<script>function setHover(h){var w=document.getElementById("w");w.style.transform=h?"scale(1.05)":"scale(1)";w.style.filter=h?"brightness(1.25)":"none";}</script>
					</body></html>]]
			end

			-- Visible DÈS qu'un bijou (collier/bracelet/bague) est équipé dans la case
			-- (Think = la frame même de l'équipement) ; jamais pour les autres accessoires.
			-- Tooltip CUSTOM en DA (carte sombre + barre accent, police EVO_EyeTip 18) :
			-- le tooltip GMod natif était trop petit (demande user). Parenté au panneau
			-- inventaire pour pouvoir déborder de la case.
			local tip = vgui.Create("DPanel", self)
			tip:SetVisible(false)
			tip:SetZPos(3000)
			tip:SetMouseInputEnabled(false)
			tip.Paint = function(t, w, h)
				if EVO_UI and EVO_UI.PaintTooltip then
					EVO_UI.PaintTooltip(0, 0, w, h)
				else
					RNDX.Draw(math.Round(8 * eyeScale), 0, 0, w, h, Color(14, 14, 17, 250))
				end
				draw.SimpleText(t._txt or "", "EVO_EyeTip", w / 2 + math.Round(2 * eyeScale), h / 2,
					Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			-- Tooltip AU CURSEUR (demande user : au niveau de la souris, pas
			-- mécaniquement au-dessus de la case) ; bascule de l'autre côté du
			-- curseur s'il déborde du panneau. Suit la souris via tip.Think.
			local function placeTipAtCursor()
				local mx, my = self:ScreenToLocal(gui.MousePos())
				local off = math.Round(14 * eyeScale)
				local tx, ty = mx + off, my + off
				if tx + tip:GetWide() > self:GetWide() then tx = mx - tip:GetWide() - off end
				if ty + tip:GetTall() > self:GetTall() then ty = my - tip:GetTall() - off end
				tip:SetPos(math.max(0, tx), math.max(0, ty))
			end
			local function showTip()
				tip._txt = (eye._state and "Cliquer : AFFICHER cet accessoire sur ton personnage")
					or "Cliquer : CACHER cet accessoire sur ton personnage"
				surface.SetFont("EVO_EyeTip")
				local tw, th = surface.GetTextSize(tip._txt)
				local padX, padY = math.Round(14 * eyeScale), math.Round(8 * eyeScale)
				tip:SetSize(tw + padX * 2, th + padY * 2)
				placeTipAtCursor()
				tip:SetVisible(true)
				tip:MoveToFront()
			end
			tip.Think = placeTipAtCursor -- ne tourne que tip visible (panel caché = pas de Think)

			eye._state = nil
			-- IMPORTANT : un panel SetVisible(false) ne reçoit PLUS de Think — la
			-- logique de visibilité vit donc sur la CASE (toujours visible). Sinon,
			-- après un déséquipe l'œil se cachait et ne réapparaissait jamais au
			-- rééquipe (tant qu'on ne rouvrait pas l'inventaire).
			equipSlot.Think = function()
				local s = eye
				if not IsValid(s) then return end
				local iid = IsValid(equipSlot.ItemPanel) and equipSlot.ItemPanel.itemId or nil
				local show = iid ~= nil and INVENTORY_CONFIG.IsHideableAccessory
					and INVENTORY_CONFIG.IsHideableAccessory(iid) or false
				s:SetVisible(show)
				if not show then
					s._state = nil
					if tip:IsVisible() then tip:SetVisible(false) end
					return
				end
				s:MoveToFront()
				local hid = InventoryHiddenAccessories()[tostring(i)] and true or false
				if s._state ~= hid then
					s._state = hid
					html:SetHTML(eyeSVG(hid))
					-- état changé (clic) : rafraîchit le texte du tooltip s'il est affiché
					if tip:IsVisible() then showTip() end
				end
			end
			-- AUCUN fond (demande user : "que l'œil") — la lisibilité vient du liseré
			-- sombre intégré au SVG. Survol = léger zoom CSS + curseur main + tooltip DA.
			eye.Paint = function() end
			eye:SetCursor("hand")
			eye.OnCursorEntered = function()
				html:RunJavascript("if(window.setHover)setHover(1)")
				showTip()
			end
			eye.OnCursorExited = function()
				html:RunJavascript("if(window.setHover)setHover(0)")
				tip:SetVisible(false)
			end
			eye.DoClick = function()
				net.Start("server:inventory.ToggleHideAccessory")
				net.WriteUInt(i, 8)
				net.SendToServer()
			end
		end

		self.equipSlots[i] = equipSlot
	end

	-- === KATANA EQUIPMENT SLOT ===
	self.equippedKatana = nil
	self.katanaSlotHovered = false
	self.modelDragHover = false
	self.modelDragHoverAlpha = 0

	self.katanaSlot = vgui.Create("DPanel", self)
	self.katanaSlot:gSetSize(INV.EQUIP_PX, INV.EQUIP_PX)
	self.katanaSlot:SetMouseInputEnabled(true)
	self.katanaSlot.hovered = false

	self.katanaSlot.Paint = function(selff, w, h)
		local isHover = selff.hovered
		local material = isHover and GetItemSlotHoverMaterial(self.equippedKatana) or materials.equipement_slot
		RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), material)

		if not self.equippedKatana then
			local ph = materials.slot_icon_katana
			if ph and not ph:IsError() then
				local iconSize = math.min(w, h) * (100 / 150)
				local ox = (w - iconSize) / 2
				local oy = (h - iconSize) / 2
				local a = isHover and 200 or 115
				RNDX.DrawMaterial(0, ox, oy, iconSize, iconSize, Color(255, 255, 255, a), ph)
			end
		end
	end

	AttachInventorySlotNameOverlay(self.katanaSlot, function()
		return self.equippedKatana
	end)

	self.katanaSlot.OnCursorEntered = function(selff) selff.hovered = true end
	self.katanaSlot.OnCursorExited = function(selff) selff.hovered = false end
	self.katanaSlot.OnMousePressed = function() end

	-- Accept katana drops on the slot
	self.katanaSlot:Droppable(droppableName)
	self.katanaSlot:Receiver(droppableName, function(rcv, panels, bDoDrop)
		if not bDoDrop then
			-- Hover preview
			local dragged = panels and panels[1]
			if IsValid(dragged) and dragged.itemId then
				local it = ITEMS and ITEMS[dragged.itemId]
				rcv.hovered = (it and (it.skin_id ~= nil or it.gauntlet_id ~= nil) and InventoryWeaponFamilyOk(dragged.itemId))
			end
			return
		end
		local dragged = panels and panels[1]
		if not IsValid(dragged) then return end

		local itemId = dragged.itemId
		if not itemId then return end
		local itemData = ITEMS and ITEMS[itemId]
		if not itemData or not (itemData.skin_id or itemData.gauntlet_id) then return end

		-- From inventory slot
		if dragged.slotIndex then
			if self:DoEquipKatana(itemId, dragged.slotIndex) then
				dragged:Remove()
			end
		end
	end)

	-- Helper: equip katana from inventory
	function self:DoEquipKatana(itemId, fromSlotIndex)
		-- Mauvaise famille (épée en Hakuda / gantelet en Katana) : bloque + notif. Couvre "Utiliser"
		-- ET le glisser-sur-case (les deux passent ici). Doublé du gate serveur EquipKatana.
		if InventoryWeaponFamilyBlocked(itemId) then return false end
		if InventoryFactionEquipBlocked(itemId) then return false end
		if InventoryClientBagDurabilityEquipBlocked(itemId, fromSlotIndex) then
			InventoryNotifyDurabilityEquipBlocked()
			return false
		end
		-- Put old katana back in inventory
		if self.equippedKatana then
			local freeSlot = nil
			for j = 1, #self.slots do
				if not self.inventoryMap[j] then
					freeSlot = j
					break
				end
			end
			if freeSlot then
				self.inventoryMap[freeSlot] = self.equippedKatana
			end
		end

		InventoryOptimisticTakeOne(self, fromSlotIndex)

		-- Set equipped katana
		self.equippedKatana = itemId
		self:RefreshKatanaSlot()
		self:RefreshItemsForCategory()

		-- Network to server
		net.Start("server:inventory.EquipKatana")
		net.WriteString(itemId)
		net.WriteUInt(fromSlotIndex or 0, 32)
		net.SendToServer()
		return true
	end

	-- Helper: equip outfit from bag (outfit equip slot, same rules as dropping on slot 2)
	function self:DoEquipOutfit(itemId, fromSlotIndex)
		-- Pas de cooldown combat pour les TENUES (cosmétique, aucune stat) — demande user.
		if InventoryFactionEquipBlocked(itemId) then return false end
		if InventoryClientBagDurabilityEquipBlocked(itemId, fromSlotIndex) then
			InventoryNotifyDurabilityEquipBlocked()
			return false
		end
		local itemData = ITEMS and ITEMS[itemId]
		if not itemData or itemData.category ~= "outfit" or not isstring(itemData.model_path) or itemData.model_path == "" then return false end
		if itemData.skin_id then return false end

		local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
		if not fromSlotIndex or fromSlotIndex < 1 then return false end

		local rcv = self.equipSlots and self.equipSlots[outfitSlot]
		if not IsValid(rcv) then return false end

		if self.equippedMap and self.equippedMap[outfitSlot] == itemId then return false end

		if IsValid(rcv.ItemPanel) then
			local prevItemId = rcv.ItemPanel.itemId
			if isstring(prevItemId) and prevItemId ~= "" and prevItemId ~= itemId then
				local freeSlot = nil
				for j = 1, #self.slots do
					if j ~= fromSlotIndex and not self.inventoryMap[j] then
						freeSlot = j
						break
					end
				end
				if not freeSlot then
					if MUGEN and MUGEN.Notify then
						MUGEN.Notify("Inventaire plein : libérez un emplacement pour retirer la tenue actuelle.",
							NOTIFY_ERROR, 4)
					end
					return false
				end
				self.inventoryMap[freeSlot] = prevItemId
				rcv.ItemPanel:Remove()
				rcv.ItemPanel = nil
				self.equippedMap[outfitSlot] = nil
			end
		end

		InventoryOptimisticTakeOne(self, fromSlotIndex)
		self.equippedMap[outfitSlot] = itemId
		rcv.ItemPanel = self:CreateEquipItemPanel(rcv, itemId, outfitSlot)

		self:RefreshItemsForCategory()

		net.Start("server:inventory.Equip")
		net.WriteString(itemId)
		net.WriteUInt(outfitSlot, 32)
		net.WriteUInt(fromSlotIndex, 32)
		net.SendToServer()
		return true
	end

	-- Helper: equip accessory from bag onto its configured gear slot only
	function self:DoEquipAccessory(itemId, fromSlotIndex)
		-- Item DÉPLACÉ si le slot cible est déjà occupé (swap) -> compte pour le lock combat
		-- (remplacer un item à stats = le retirer). cf. InventoryCombatSwapBlocked.
		local _eqItd = ITEMS and ITEMS[itemId]
		local _eqTgt = _eqItd and INVENTORY_CONFIG.GetAccessoryEquipSlot
			and INVENTORY_CONFIG.GetAccessoryEquipSlot(_eqItd)
		local _eqDisp = _eqTgt and self.equippedMap and self.equippedMap[_eqTgt] or nil
		if InventoryCombatSwapBlocked(itemId, _eqDisp) then return false end
		if InventoryFactionEquipBlocked(itemId) then return false end
		if InventoryClientBagDurabilityEquipBlocked(itemId, fromSlotIndex) then
			InventoryNotifyDurabilityEquipBlocked()
			return false
		end
		local itemData = ITEMS and ITEMS[itemId]
		local targetSlot = INVENTORY_CONFIG.GetAccessoryEquipSlot and INVENTORY_CONFIG.GetAccessoryEquipSlot(itemData)
		if not itemData or itemData.category ~= "accessory" or not targetSlot then return false end
		if itemData.skin_id then return false end
		if not fromSlotIndex or fromSlotIndex < 1 then return false end

		local rcv = self.equipSlots and self.equipSlots[targetSlot]
		if not IsValid(rcv) then return false end

		if self.equippedMap and self.equippedMap[targetSlot] == itemId then return false end

		if IsValid(rcv.ItemPanel) then
			local prevItemId = rcv.ItemPanel.itemId
			if isstring(prevItemId) and prevItemId ~= "" and prevItemId ~= itemId then
				local freeSlot = nil
				for j = 1, #self.slots do
					if j ~= fromSlotIndex and not self.inventoryMap[j] then
						freeSlot = j
						break
					end
				end
				if not freeSlot then
					if MUGEN and MUGEN.Notify then
						MUGEN.Notify("Inventaire plein : libérez un emplacement pour retirer l'accessoire actuel.",
							NOTIFY_ERROR, 4)
					end
					return false
				end
				self.inventoryMap[freeSlot] = prevItemId
				rcv.ItemPanel:Remove()
				rcv.ItemPanel = nil
				self.equippedMap[targetSlot] = nil
			end
		end

		InventoryOptimisticTakeOne(self, fromSlotIndex)
		self.equippedMap[targetSlot] = itemId
		rcv.ItemPanel = self:CreateEquipItemPanel(rcv, itemId, targetSlot)

		self:RefreshItemsForCategory()

		-- Nouvel accessoire sur ce slot -> REINITIALISE l'edition (offset) cote client
		-- (rendu cl_models + editeur) : le nouvel item ne reprend PAS la position editee
		-- de l'ancien (demande user). Le serveur reinitialise deja sa copie autoritative.
		local _cdEq = GetPlayerCharacterData and GetPlayerCharacterData(LocalPlayer())
		if _cdEq and _cdEq.equipped_accessory_offsets then _cdEq.equipped_accessory_offsets[tostring(targetSlot)] = nil end
		net.Start("server:inventory.Equip")
		net.WriteString(itemId)
		net.WriteUInt(targetSlot, 32)
		net.WriteUInt(fromSlotIndex, 32)
		net.SendToServer()
		return true
	end

	-- Helper: unequip outfit from equip slot back to bag (same net flow as drag to inventory)
	function self:DoUnequipOutfit(equipSlotId)
		equipSlotId = tonumber(equipSlotId) or (INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2)
		local itemId = self.equippedMap and self.equippedMap[equipSlotId]
		if not isstring(itemId) or itemId == "" then return end
		local it = ITEMS and ITEMS[itemId]
		if not it or it.category ~= "outfit" then return end

		local freeSlot = nil
		for j = 1, #self.slots do
			if not self.inventoryMap[j] then
				freeSlot = j
				break
			end
		end
		if not freeSlot then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("Inventaire plein.", NOTIFY_ERROR, 4)
			end
			return
		end

		local eqSlot = self.equipSlots and self.equipSlots[equipSlotId]
		if IsValid(eqSlot) and IsValid(eqSlot.ItemPanel) then
			eqSlot.ItemPanel:Remove()
			eqSlot.ItemPanel = nil
		end

		self.inventoryMap[freeSlot] = itemId
		self.equippedMap[equipSlotId] = nil

		self:RefreshItemsForCategory()

		net.Start("server:inventory.Unequip")
		net.WriteUInt(equipSlotId, 32)
		net.SendToServer()
	end

	function self:DoUnequipAccessorySlot(equipSlotId)
		equipSlotId = tonumber(equipSlotId) or 0
		local outfitSlot = INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
		if equipSlotId == outfitSlot or equipSlotId < 1 or equipSlotId > (INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) then return end

		local itemId = self.equippedMap and self.equippedMap[equipSlotId]
		if not isstring(itemId) or itemId == "" then return end
		local it = ITEMS and ITEMS[itemId]
		if not it or it.category ~= "accessory" then return end
		-- Combat : on ne peut pas non plus DÉSÉQUIPER un accessoire à stats (cosmétique OK).
		if InventoryCombatSwapBlocked(itemId) then return end

		local freeSlot = nil
		for j = 1, #self.slots do
			if not self.inventoryMap[j] then
				freeSlot = j
				break
			end
		end
		if not freeSlot then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("Inventaire plein.", NOTIFY_ERROR, 4)
			end
			return
		end

		local eqSlot = self.equipSlots and self.equipSlots[equipSlotId]
		if IsValid(eqSlot) and IsValid(eqSlot.ItemPanel) then
			eqSlot.ItemPanel:Remove()
			eqSlot.ItemPanel = nil
		end

		self.inventoryMap[freeSlot] = itemId
		self.equippedMap[equipSlotId] = nil

		self:RefreshItemsForCategory()

		net.Start("server:inventory.Unequip")
		net.WriteUInt(equipSlotId, 32)
		net.SendToServer()
	end

	-- Helper: unequip katana back to inventory
	function self:DoUnequipKatana()
		if not self.equippedKatana then return end

		-- Block if katana weapon is currently drawn
		local lp = LocalPlayer()
		local wep = IsValid(lp) and lp:GetActiveWeapon()
		if IsValid(wep) and (wep:GetClass() == "citron_combat_weapons" or wep:GetClass() == "citron_shinai_weapons") then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify("Rangez votre arme avant de la déséquiper.", NOTIFY_ERROR, 4)
			end
			return
		end

		local itemId = self.equippedKatana
		-- Find free inventory slot
		local freeSlot = nil
		for j = 1, #self.slots do
			if not self.inventoryMap[j] then
				freeSlot = j
				break
			end
		end
		if freeSlot then
			self.inventoryMap[freeSlot] = itemId
		end

		self.equippedKatana = nil
		self:RefreshKatanaSlot()
		self:RefreshItemsForCategory()

		-- Network to server
		net.Start("server:inventory.UnequipKatana")
		net.SendToServer()
	end

	-- Refresh katana slot display
	function self:RefreshKatanaSlot()
		local slot = self.katanaSlot
		if not IsValid(slot) then return end

		-- Remove existing item panel
		if IsValid(slot.ItemPanel) then
			slot.ItemPanel:Remove()
			slot.ItemPanel = nil
		end

		if self.equippedKatana then
			local itemId = self.equippedKatana
			local item = vgui.Create("DPanel", slot)
			item:Dock(FILL)
			item:DockMargin(0, 0, 0, 0)
			item.itemId = itemId
			item.isKatanaEquipped = true
			item._invDbSlotId = INVENTORY_CONFIG and INVENTORY_CONFIG.DB_KATANA_SLOT or 2000
			item:SetCursor("hand")

			local it = ITEMS and ITEMS[itemId]
			if LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
				LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(item, it, 25, nil, 1)
			else
				item.Paint = function(panel, w, h)
					if it and it.icon then
						-- Idem : marge proportionnelle, plus 25 px en dur (fix 09/03).
						local mq = w * (25 / 150)
						RNDX.DrawMaterial(0, mq, mq, w - mq * 2, h - mq * 2, Color(255, 255, 255, 255), Material(it.icon))
					end
				end
			end

			item._descHoverStart = nil
			item._descTooltipShown = false
			item.OnCursorEntered = function(panel)
				panel._descHoverStart = CurTime()
				panel._descTooltipShown = false
				slot.hovered = true
			end
			item.OnCursorExited = function(panel)
				panel._descHoverStart = nil
				panel._descTooltipShown = false
				self:HideItemDescriptionTooltip()
				slot.hovered = false
			end
			item.Think = function(panel)
				if not panel._descHoverStart or panel._descTooltipShown then return end
				if CurTime() - panel._descHoverStart < DESC_TOOLTIP_DELAY then return end
				local id = panel.itemId
				local d = id and ITEMS and ITEMS[id]
				if not InventoryItemHasDescriptionTooltipContent(d) then return end
				panel._descTooltipShown = true
				self:ShowItemDescriptionTooltip(id, panel)
			end
			-- Draggable (to remove from katana slot)
			item:Droppable(droppableName)
			item.OnMousePressed = function(panel, m)
				surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
				if m == MOUSE_LEFT then
					panel:DragMousePress(m)
				elseif m == MOUSE_RIGHT then
					self:HideItemDescriptionTooltip()
					-- Context menu to unequip
					self.contextmenu = DermaMenu()
					self.contextmenu:SetDrawOnTop(true)
					self.contextmenu:SetMinimumWidth(gRespX(100))
					self.contextmenu.Paint = function(p, w, h)
						draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 10, 235))
					end

					local menuOptH = gRespY(35)
					local function katanaMenuOptionLayout(pnl, lw, lh)
						pnl:SizeToContents()
						pnl:SetWide(pnl:GetWide() + 30)
						lw = math.max(pnl:GetParent():GetWide(), pnl:GetWide())
						pnl:SetSize(lw, menuOptH)
						if IsValid(pnl.SubMenuArrow) then
							pnl.SubMenuArrow:SetSize(15, 15)
							pnl.SubMenuArrow:CenterVertical()
							pnl.SubMenuArrow:AlignRight(4)
						end
						DButton.PerformLayout(pnl, lw, lh)
					end

					local optUnequip = self.contextmenu:AddOption("Déséquiper", function()
						self:DoUnequipKatana()
					end)
					optUnequip:SetTextColor(Color(230, 230, 230))
					optUnequip:SetFont("Avenir Next World:16")
					optUnequip.PerformLayout = katanaMenuOptionLayout
					optUnequip.Paint = function(p, w, h)
						local bg = p:IsHovered() and Color(255, 255, 255, 20) or Color(255, 255, 255, 6)
						draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
					end
					self.contextmenu:Open()
				end
			end
			item.OnMouseReleased = function(panel, m)
				panel:DragMouseRelease(m)
			end
			slot.ItemPanel = item
		end
	end

	-- Make inventory slots also accept katana items dragged from the katana slot
	for idx = 1, #self.slots do
		local slot = self.slots[idx]
		if IsValid(slot) then
			local oldReceiver = slot._origReceiver
			slot:Receiver(droppableName, function(rcv, panels, bDoDrop)
				self:OnInvItemDropped(rcv, panels, bDoDrop)
			end)
		end
	end

	-- Presets de tenues : colonne dans la bande vide entre le sac et la colonne
	-- d'équipement. Rafraîchie quand le serveur repousse les presets (hook).
	self:CreatePresetsButton()
	self:CreateSortButton()
	self:CreateGradeEditButton()

	-- Refresh equipped items display
	self:RefreshEquippedItems()
end

local PRE_CARD   = Color(14, 14, 17, 250)
local PRE_SUB    = Color(24, 24, 29, 255)
local PRE_TITLE  = Color(237, 238, 242)
local PRE_MUTED  = Color(150, 154, 162)
local PRE_DIM    = Color(108, 111, 120)
local PRE_ACCENT = Color(207, 68, 78)
local PRE_LINE   = Color(255, 255, 255, 16)

local function preRound(r, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(r, x, y, w, h, col) else draw.RoundedBox(r, x, y, w, h, col) end
end

local function preTrunc(text, font, maxW)
	if EVO_UI and EVO_UI.TruncText then return EVO_UI.TruncText(text, font, maxW) end
	surface.SetFont(font)
	if (select(1, surface.GetTextSize(text))) <= maxW then return text end
	local s = text
	while #s > 1 and (select(1, surface.GetTextSize(s .. "…"))) > maxW do
		s = string.sub(s, 1, #s - 1)
	end
	return s .. "…"
end

-- ════════════════════════════════════════════════════════════════════════════
-- PRESETS — bouton pres du titre + POPUP (redesign user 2026-07-17).
-- Les slots lisent leur etat EN DIRECT (LZY_InvPresets) a chaque frame -> la popup
-- se met a jour toute seule apres un SAUVER/PORTER, SANS dependre d'un hook de
-- refresh (qui pouvait rater la MAJ live -> l'ancien slot ne passait pas en PORTER).
-- (Les anciennes fonctions BuildOutfitPresets/CreatePresetCard/RefreshPresetCards
-- ne sont plus appelees.)
-- ════════════════════════════════════════════════════════════════════════════
local function presetOutfitName(idx)
	local p = LZY_InvPresets and LZY_InvPresets.Get(idx) or {}
	local id = p["2"] or p.katana
	local oit = id and ITEMS and ITEMS[id] or nil
	return oit and oit.name or nil
end

-- Une LIGNE de la popup (badge + nom + PORTER + SAUVER). Tout lit l'etat EN DIRECT.
function PANEL:BuildPresetRow(parent, idx, y)
	local row = vgui.Create("DPanel", parent)
	row:gSetPos(20, y)
	row:gSetSize(420, 64)
	row.Paint = function(_, w, h)
		local filled = LZY_InvPresets and LZY_InvPresets.IsFilled(idx)
		local rad = math.max(4, gRespY(8))
		if filled then
			preRound(rad, 0, 0, w, h, Color(32, 23, 26))
			if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(rad, 0, 0, w, h, Color(207, 68, 78, 130), math.max(1, gRespX(1))) end
			surface.SetDrawColor(207, 68, 78)
			surface.DrawRect(0, gRespY(8), math.max(2, gRespX(4)), h - gRespY(16))
		else
			preRound(rad, 0, 0, w, h, Color(255, 255, 255, 8))
			if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(rad, 0, 0, w, h, Color(255, 255, 255, 26), math.max(1, gRespX(1))) end
		end
		local bs = gRespY(34)
		local bx, by = gRespX(12), (h - bs) * 0.5
		preRound(math.max(3, gRespY(5)), bx, by, bs, bs, filled and PRE_ACCENT or Color(255, 255, 255, 20))
		draw.SimpleText(tostring(idx), "Bebas Neue:27", bx + bs * 0.5, by + bs * 0.5, filled and Color(245, 245, 245) or PRE_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("PRESET " .. idx, "Bebas Neue:23", gRespX(58), gRespY(15), filled and PRE_TITLE or PRE_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local nm = presetOutfitName(idx)
		draw.SimpleText(filled and preTrunc(nm or "Équipement enregistré", "Avenir Next World:14", gRespX(150)) or "Emplacement vide",
			"Avenir Next World:14", gRespX(58), gRespY(43), filled and PRE_MUTED or PRE_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- PORTER (charger) — actif seulement si le preset est rempli.
	local porter = vgui.Create("DButton", row)
	porter:SetText("")
	porter:gSetPos(224, 12)
	porter:gSetSize(94, 40)
	porter.Paint = function(selff, w, h)
		local filled = LZY_InvPresets and LZY_InvPresets.IsFilled(idx)
		local hov = selff:IsHovered() and filled
		preRound(gRespY(6), 0, 0, w, h, hov and PRE_ACCENT or (filled and Color(207, 68, 78, 150) or Color(255, 255, 255, 8)))
		draw.SimpleText("PORTER", "Bebas Neue:22", w * 0.5, h * 0.5, filled and Color(245, 245, 245) or PRE_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	porter.DoClick = function()
		if LZY_InvPresets and LZY_InvPresets.IsFilled(idx) then LZY_InvPresets.Apply(idx) end
	end

	-- SAUVER (enregistrer tout l'équipement actuel dans ce slot) — toujours actif.
	local save = vgui.Create("DButton", row)
	save:SetText("")
	save:SetTooltip("Enregistrer les vêtements, l'arme et tous les équipements actuellement équipés.")
	save:gSetPos(324, 12)
	save:gSetSize(84, 40)
	save.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		preRound(gRespY(6), 0, 0, w, h, hov and PRE_SUB or Color(255, 255, 255, 10))
		if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(gRespY(6), 0, 0, w, h, hov and Color(207, 68, 78, 150) or PRE_LINE, math.max(1, gRespX(1))) end
		draw.SimpleText("SAUVER", "Bebas Neue:21", w * 0.5, h * 0.5, hov and PRE_TITLE or PRE_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	save.DoClick = function()
		if LZY_InvPresets then LZY_InvPresets.Save(idx) end
	end

	return row
end

function PANEL:OpenPresetsPopup()
	if IsValid(self._presetPopup) then self._presetPopup:Remove() end
	local pop = vgui.Create("DFrame", self)
	pop:SetTitle("")
	pop:ShowCloseButton(false)
	pop:SetDraggable(false)
	pop:gSetSize(460, 340)
	pop:Center()
	pop:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pop) end
	self._presetPopup = pop

	pop.Paint = function(_, w, h)
		preRound(gRespY(12), 0, 0, w, h, Color(14, 14, 17, 252))
		if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(gRespY(12), 0, 0, w, h, PRE_LINE, math.max(1, gRespX(1))) end
		draw.SimpleText("PRESETS", "Bebas Neue:34", gRespX(22), gRespY(29), PRE_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:34")
		local tw = surface.GetTextSize("PRESETS")
		surface.SetDrawColor(207, 68, 78)
		surface.DrawRect(gRespX(22), gRespY(48), tw, math.max(2, gRespY(3)))
	end

	local closeBtn = vgui.Create("DButton", pop)
	closeBtn:SetText("")
	closeBtn:gSetPos(460 - 44, 12)
	closeBtn:gSetSize(32, 32)
	closeBtn.Paint = function(selff, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:20", w * 0.5, h * 0.5, selff:IsHovered() and PRE_ACCENT or PRE_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeBtn.DoClick = function() pop:Remove() end

	for i = 1, 3 do
		self:BuildPresetRow(pop, i, 82 + (i - 1) * 76)
	end

	if LZY_InvPresets then LZY_InvPresets.Request() end
end

-- Bouton "PRESETS" au niveau du titre INVENTAIRE, au-dessus de la categorie "Autres".
function PANEL:CreatePresetsButton()
	local btn = vgui.Create("DButton", self)
	btn:SetText("")
	btn:gSetPos(INV.CATS_X + INV.GRID_W - 150, INV.TITLE_Y - 22)
	btn:gSetSize(150, 44)
	btn.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		preRound(gRespY(8), 0, 0, w, h, hov and Color(207, 68, 78, 45) or PRE_CARD)
		if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(gRespY(8), 0, 0, w, h, hov and Color(207, 68, 78, 160) or PRE_LINE, math.max(1, gRespX(1))) end
		draw.SimpleText("PRESETS", "Bebas Neue:23", w * 0.5, h * 0.5, hov and Color(245, 245, 245) or PRE_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.DoClick = function() self:OpenPresetsPopup() end
	self.presetsButton = btn
end

function PANEL:CreateSortButton()
	local btn = vgui.Create("DButton", self)
	btn:SetText("")
	btn:gSetPos(INV.CATS_X + INV.GRID_W - 315, INV.TITLE_Y - 22)
	btn:gSetSize(150, 44)
	btn.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		preRound(gRespY(8), 0, 0, w, h, hov and Color(207, 68, 78, 45) or PRE_CARD)
		if RNDX and RNDX.DrawOutlined then RNDX.DrawOutlined(gRespY(8), 0, 0, w, h, hov and Color(207, 68, 78, 160) or PRE_LINE, math.max(1, gRespX(1))) end
		draw.SimpleText("TRIER", "Bebas Neue:23", w * 0.5, h * 0.5, hov and Color(245, 245, 245) or PRE_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.DoClick = function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		net.Start("server:inventory.SortBag")
		net.SendToServer()
	end
	self.sortButton = btn
end

-- Bouton d'édition des pièces de grade (épaulette, haori, cape, brassard, Espada).
-- Une seule pièce : ouvre l'éditeur. Plusieurs : menu pour choisir laquelle.
function PANEL:CreateGradeEditButton()
	local btn = vgui.Create("DButton", self)
	btn:SetText("")
	btn:SetTooltip("Éditer cape/épaulette")
	btn:SetZPos(10001)
	btn:gSetPos(INV.GRADE_BTN_X, INV.GRADE_BTN_Y)
	btn:gSetSize(INV.GRADE_BTN_W, INV.GRADE_BTN_H)
	btn:SetVisible(#InventoryEditableGradeCosmetics() > 0)
	btn.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		preRound(gRespY(4), 0, 0, w, h, hov and Color(207, 68, 78, 45) or PRE_CARD)
		if RNDX and RNDX.DrawOutlined then
			RNDX.DrawOutlined(gRespY(4), 0, 0, w, h, hov and Color(207, 68, 78, 160) or PRE_LINE, math.max(1, gRespX(1)))
		end
		draw.SimpleText("Éditer cape/", "Avenir Next World:14", w * 0.5, h * 0.5 - gRespY(10),
			hov and Color(245, 245, 245) or PRE_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("épaulette", "Avenir Next World:14", w * 0.5, h * 0.5 + gRespY(10),
			hov and Color(245, 245, 245) or PRE_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btn.DoClick = function()
		local list = InventoryEditableGradeCosmetics()
		if #list == 0 then return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		local function openSlot(sSlot)
			self:Close()
			timer.Simple(0, function()
				if LZY_AccessoryEditor_Open then LZY_AccessoryEditor_Open(sSlot) end
			end)
		end
		if #list == 1 then
			openSlot(list[1].slot)
			return
		end
		self:HideItemDescriptionTooltip()
		if IsValid(self.contextmenu) then self.contextmenu:Remove() end
		self.contextmenu = DermaMenu()
		self.contextmenu:SetDrawOnTop(true)
		self.contextmenu:SetMinimumWidth(gRespX(160))
		self.contextmenu.Paint = function(p, w, h)
			draw.RoundedBox(6, 0, 0, w, h, Color(10, 10, 10, 235))
		end
		local menuOptH = gRespY(35)
		for _, entry in ipairs(list) do
			local sSlot = entry.slot
			local opt = self.contextmenu:AddOption(entry.label, function()
				openSlot(sSlot)
			end)
			opt:SetTextColor(Color(180, 210, 255))
			opt:SetFont("Avenir Next World:16")
			opt.PerformLayout = function(pnl, lw, lh)
				pnl:SizeToContents()
				pnl:SetWide(pnl:GetWide() + 30)
				lw = math.max(pnl:GetParent():GetWide(), pnl:GetWide())
				pnl:SetSize(lw, menuOptH)
				DButton.PerformLayout(pnl, lw, lh)
			end
			opt.Paint = function(p, w, h)
				local bg = p:IsHovered() and Color(120, 170, 255, 28) or Color(120, 170, 255, 10)
				draw.RoundedBox(4, gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), bg)
			end
		end
		self.contextmenu:Open()
	end
	self.gradeEditBtn = btn
end

-- Function to refresh equipped items display
function PANEL:RefreshEquippedItems()
	if not self.equipSlots then return end

	-- Get fresh inventory data
	local inventoryData = LocalPlayer():GetInventory()
	local equipped_items = inventoryData.equipped_items or {}

	-- Convert array format to object format if needed
	if istable(equipped_items) then
		local hasNumericKeys = false
		local hasStringKeys = false

		for k, v in pairs(equipped_items) do
			if type(k) == "number" then
				hasNumericKeys = true
			elseif type(k) == "string" then
				hasStringKeys = true
			end
		end

		-- Only convert if it has numeric keys but no string keys (pure array)
		-- If it has string keys (like {"3":"item_2"}), it's already in the correct format
		if hasNumericKeys and not hasStringKeys then
			local converted = {}
			for i, itemId in ipairs(equipped_items) do
				if itemId then
					converted[tostring(i)] = itemId
				end
			end
			-- Also check for sparse arrays (like [nil, nil, "item"])
			for k, v in pairs(equipped_items) do
				if type(k) == "number" and v and not converted[tostring(k)] then
					converted[tostring(k)] = v
				end
			end
			equipped_items = converted
		end
	end

	if INVENTORY_CONFIG and INVENTORY_CONFIG.NormalizeEquippedKeysForClient then
		equipped_items = INVENTORY_CONFIG.NormalizeEquippedKeysForClient(equipped_items)
	end

	for i = 1, (INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) do
		local equipSlot = self.equipSlots[i]
		if IsValid(equipSlot) then
			local slotKey = tostring(i)
			local itemId = equipped_items[slotKey]

			-- Remove existing item panel if slot should be empty or has different item
			if IsValid(equipSlot.ItemPanel) then
				if not itemId or equipSlot.ItemPanel.itemId ~= itemId then
					equipSlot.ItemPanel:Remove()
					equipSlot.ItemPanel = nil
					self.equippedMap[i] = nil
				end
			end

			-- Create item panel if slot has item and doesn't have one
			if itemId and not IsValid(equipSlot.ItemPanel) then
				self.equippedMap[i] = itemId
				equipSlot.ItemPanel = self:CreateEquipItemPanel(equipSlot, itemId, i)
			end
		end
	end

	-- Refresh katana slot from synced data
	local katanaItemId = equipped_items["katana"]
	if katanaItemId ~= self.equippedKatana then
		self.equippedKatana = katanaItemId or nil
		self:RefreshKatanaSlot()
	end
end

function PANEL:Paint(w, h)
	-- PANNEAU CENTRE (portage evo-ds, user 09/03) : le flou et le voile sont BORNES au
	-- panneau — en dehors du contour le jeu reste normal, on n'assombrit plus tout l'ecran.
	-- Puis le VRAI joueur est redessine NET par-dessus (il est cadre dans le trou de droite
	-- par le CalcView de fin de fichier) : sans ce redessin il serait noye sous le voile.
	-- FLOU PLEIN ECRAN derriere tout l'inventaire (user 09/03). Le panneau garde en plus
	-- son propre flou renforce, et les cartes STATS / SETS sorties a droite reposent
	-- desormais elles aussi sur un fond floute au lieu du decor net.
	if RNDX and RNDX.BLUR then
		RNDX.Draw(0, 0, 0, w, h, COL_INV_WHITE, RNDX.BLUR)
	end
	surface.SetDrawColor(COL_INV_SCREEN)
	surface.DrawRect(0, 0, w, h)

	local px, py, pw, ph = gRespX(INV.PX), gRespY(INV.PY), gRespX(INV.PW), gRespY(INV.PH)
	local prad = gRespY(18)
	if RNDX and RNDX.BLUR then
		for _ = 1, INV_BLUR_PASSES do RNDX.Draw(prad, px, py, pw, ph, COL_INV_WHITE, RNDX.BLUR) end
	end
	RNDX.Draw(prad, px, py, pw, ph, COL_INV_VEIL)
	-- Trame du fond d'inventaire, tres discrete, uniquement DANS le panneau.
	if bgInv and not bgInv:IsError() then
		RNDX.DrawMaterial(prad, px, py, pw, ph, Color(255, 255, 255, 6), bgInv)
	end
	if RNDX and RNDX.DrawOutlined then
		RNDX.DrawOutlined(prad, px, py, pw, ph, Color(207, 68, 78, 120), math.max(2, gRespY(2)))
	end
	invDrawLocalPlayerSharp()

	-- Titre INVENTAIRE (Bebas SANS bold) + entaille slash1 collée dessous.
	draw.SimpleText("INVENTAIRE", "Bebas Neue:48", gRespX(INV.TITLE_X), gRespY(INV.TITLE_Y),
		Color(237, 238, 242), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:48")
	local twT, thT = surface.GetTextSize("INVENTAIRE")
	-- Distance titre->slash calée sur la référence BOUTIQUE (78% de la hauteur
	-- mesurée du texte sous le HAUT du titre). Titre CENTER-aligné vertical à
	-- Y=gRespY(130) : haut = 130 - th/2, donc slashY = centre + th*0.28.
	local slashY = gRespY(INV.TITLE_Y) + thT * 0.28
	local inked = EVO_UI and EVO_UI.Ink
		and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(INV.TITLE_X - 2), slashY, twT * 1.15, gRespY(10), Color(207, 68, 78, 245))
	if not inked then
		surface.SetDrawColor(207, 68, 78)
		surface.DrawRect(gRespX(INV.TITLE_X), gRespY(INV.TITLE_Y) + thT * 0.34, twT, math.max(2, gRespY(3)))
	end

	-- Draw the player model on the right side viewport
	-- vpH réduit (650->580) pour dégager le bas de la colonne : la carte STATISTIQUES
	-- (DrawBonusStatsCard) s'installe sous le modèle. Carte réduite -> modèle un peu restauré.
	local vpW, vpH = INV.VP_W, INV.VP_H
	local vpX, vpY = INV.VP_X, INV.VP_Y
	self:DrawClientPlayerModel(gRespX(vpX), gRespY(vpY), gRespX(vpW), gRespY(vpH))

	-- Equipement AUTOUR du personnage, aux positions de la disposition portee : TENUE a
	-- gauche (tete / tenue / cape), ACCESSOIRES a droite (collier / anneau / ceinture),
	-- katana + masque en paire au-dessus. La case MASQUE reste visible pour TOUT LE MONDE
	-- (09/08) : les Shinigami ont leur propre masque, le slot 7 n'est pas un privilege
	-- Arrancar — cote serveur il a toujours accepte n'importe quel accessoire.
	-- HAKUDA (09/30, user) : pas de katana donc pas de case FOURREAU ; gantelet + masque
	-- se recentrent (décalage d'une demi-case + écart = 60).
	local bHakuda = InventoryIsHakudaFamily()
	local nDecal = bHakuda and 60 or 0
	local nFourreauSlot = INVENTORY_CONFIG.FOURREAU_EQUIP_SLOT or 8
	local nMasqueSlot = INVENTORY_CONFIG.MASK_EQUIP_SLOT or 7
	if self.equipSlots then
		for nSlotId, tPos in pairs(INV.EQUIP_POS) do
			local pSlot = self.equipSlots[nSlotId]
			if IsValid(pSlot) then
				pSlot:SetVisible(not (bHakuda and nSlotId == nFourreauSlot))
				pSlot:gSetPos(tPos[1] + (nSlotId == nMasqueSlot and nDecal or 0), tPos[2])
			end
		end
	end
	if IsValid(self.katanaSlot) then
		self.katanaSlot:gSetPos(INV.KATANA_POS[1] + nDecal, INV.KATANA_POS[2])
	end

	-- Drag hover glow on model viewport when dragging katana / outfit / accessory onto preview
	if self.modelDragHover then
		self.modelDragHoverAlpha = math.Approach(self.modelDragHoverAlpha or 0, 60, FrameTime() * 200)
	else
		self.modelDragHoverAlpha = math.Approach(self.modelDragHoverAlpha or 0, 0, FrameTime() * 300)
	end
	if self.modelDragHoverAlpha > 0 then
		local a = self.modelDragHoverAlpha
		local gx, gy = gRespX(vpX), gRespY(vpY)
		local gw, gh = gRespX(vpW), gRespY(vpH)
		-- Subtle inner tint
		draw.RoundedBox(4, gx, gy, gw, gh, Color(255, 220, 120, a * 0.06))
		-- Thin border
		surface.SetDrawColor(Color(255, 220, 120, a * 0.4))
		surface.DrawOutlinedRect(gx, gy, gw, gh, 1)
	end

	-- Carte de statistiques (bonus hors grade) en bas de la colonne perso.
	DrawBonusStatsCard()
	-- Carte SETS (état des sets d'accessoires) à sa droite.
	DrawSetsCard()
end

function PANEL:Think()
	-- FONDU D'APPARITION, une fois la camera arrivee (la fenetre etait masquee jusque-la).
	if self._uiT0 then
		local nA = math.Clamp((RealTime() - self._uiT0) / INV_UI_FADE, 0, 1)
		self:SetAlpha(nA * 255)
		if nA >= 1 then self._uiT0 = nil end
	end

	-- Le chargement des stats personnage est asynchrone : si la demande d'ouverture
	-- arrive trop tôt, réessayer au maximum quatre fois puis s'arrêter. Dès la
	-- première réponse, le garde se ferme ; aucun polling ne persiste.
	if not bonusStatsReceived
		and (self._bonusStatReqAttempts or 0) < 5
		and (self._nextBonusStatReq or 0) <= CurTime()
	then
		self._bonusStatReqAttempts = (self._bonusStatReqAttempts or 0) + 1
		self._nextBonusStatReq = CurTime() + 0.75
		-- netgate: edge (bounded startup retry, stops after response or five attempts)
		RequestBonusStats()
	end

	-- Reset model drag hover if no longer hovering the model panel
	if self.modelDragHover and IsValid(self.modelPanel) then
		if not self.modelPanel:IsHovered() then
			self.modelDragHover = false
		end
	end
	local lp = LocalPlayer()
	if IsValid(self.hideHairCheck) and IsValid(lp) then
		local w = lp:GetEvoNWBool("hide_hair", false)
		if self.hideHairCheck:GetChecked() ~= w then
			self._hideHairCheckSyncing = true
			self.hideHairCheck:SetChecked(w)
			self._hideHairCheckSyncing = false
			self._lastInvPreviewSig = nil
		end
	end
	if IsValid(self.hideEpauletteCheck) and IsValid(lp) then
		local w = lp:GetEvoNWBool("EVO_HideEpaulette", false)
		if self.hideEpauletteCheck:GetChecked() ~= w then
			self._hideEpauletteCheckSyncing = true
			self.hideEpauletteCheck:SetChecked(w)
			self._hideEpauletteCheckSyncing = false
			self._lastInvPreviewSig = nil
		end
		-- Visibilité live : si le grade change pendant que l'inventaire est ouvert (promotion),
		-- afficher/masquer la coche selon la présence d'une épaulette — sinon coche fantôme figée.
		if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasRankMarker then
			local vis = LZY_CHARACTER_CONFIG.HasRankMarker(
				lp:GetEvoNWString("FactionName", ""),
				lp:GetEvoNWInt("FactionRank", 0),
				lp:GetEvoNWInt("FactionDivision", 0))
			if self.hideEpauletteCheck:IsVisible() ~= vis then
				self.hideEpauletteCheck:SetVisible(vis)
			end
		end
	end
	if IsValid(self.hideRankOutfitCheck) and IsValid(lp) then
		local w = lp:GetEvoNWBool("EVO_HideRankOutfit", false)
		if self.hideRankOutfitCheck:GetChecked() ~= w then
			self._hideRankOutfitCheckSyncing = true
			self.hideRankOutfitCheck:SetChecked(w)
			self._hideRankOutfitCheckSyncing = false
			self._lastInvPreviewSig = nil
		end
		if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasRankOutfit then
			local vis = LZY_CHARACTER_CONFIG.HasRankOutfit(
				lp:GetEvoNWString("FactionName", ""),
				lp:GetEvoNWInt("FactionRank", 0),
				lp:GetEvoNWInt("FactionDivision", 0))
				and not (LZY_CHARACTER_CONFIG.IsRankOutfitLocked and LZY_CHARACTER_CONFIG.IsRankOutfitLocked(lp))
			if self.hideRankOutfitCheck:IsVisible() ~= vis then
				self.hideRankOutfitCheck:SetVisible(vis)
			end
		end
	end

	-- Coche de la tenue de DIVISION : état lu dans la DATA perso (pas de NWBool).
	if IsValid(self.hideDivisionBodyCheck) and IsValid(lp) then
		local data = GetPlayerCharacterData and GetPlayerCharacterData(lp) or nil
		local w = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody
			and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(data) or false
		if self.hideDivisionBodyCheck:GetChecked() ~= w then
			self._hideDivisionBodyCheckSyncing = true
			self.hideDivisionBodyCheck:SetChecked(w)
			self._hideDivisionBodyCheckSyncing = false
			self._lastInvPreviewSig = nil
		end
		if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.HasDivisionBody then
			local vis = LZY_CHARACTER_CONFIG.HasDivisionBody(
				lp:GetEvoNWString("FactionName", ""),
				lp:GetEvoNWInt("FactionRank", 0),
				lp:GetEvoNWInt("FactionDivision", 0))
			if self.hideDivisionBodyCheck:IsVisible() ~= vis then
				self.hideDivisionBodyCheck:SetVisible(vis)
			end
		end
	end

	-- Coche Hakuda « Porter les gantelets » : état + visibilité famille live
	-- (swap chez le Maître des Arts pendant que l'inventaire est ouvert).
	if IsValid(self.hakudaAlwaysWearCheck) and IsValid(lp) then
		local w = lp:GetEvoNWBool("NCM_HakudaAlwaysWear", false)
		if self.hakudaAlwaysWearCheck:GetChecked() ~= w then
			self._hakudaAlwaysWearCheckSyncing = true
			self.hakudaAlwaysWearCheck:SetChecked(w)
			self._hakudaAlwaysWearCheckSyncing = false
			self._lastInvPreviewSig = nil
		end
		local vis = InventoryIsHakudaFamily()
		if self.hakudaAlwaysWearCheck:IsVisible() ~= vis then
			self.hakudaAlwaysWearCheck:SetVisible(vis)
		end
	end

	-- Coche catalyseur : visible dès qu'un id est tiré. L'état suit le NW
	-- (un reroll ou un autre client peut le changer pendant que le menu est ouvert).
	if IsValid(self.catalyseurOffCheck) and IsValid(lp) then
		local w = lp:GetEvoNWBool("EVO_CatalyseurOff", false)
		if self.catalyseurOffCheck:GetChecked() ~= w then
			self._catalyseurOffCheckSyncing = true
			self.catalyseurOffCheck:SetChecked(w)
			self._catalyseurOffCheckSyncing = false
		end
		local vis = lp:GetEvoNWString("EvoCatalyseur", "") ~= ""
		if self.catalyseurOffCheck:IsVisible() ~= vis then
			self.catalyseurOffCheck:SetVisible(vis)
		end
	end

	-- Re-tasse la colonne : une promotion/rétrogradation change quelles coches
	-- existent, les positions doivent suivre sans trou.
	InvRelayoutHideChecks(self)

	if IsValid(self.gradeEditBtn) then
		local vis = #InventoryEditableGradeCosmetics() > 0
		if self.gradeEditBtn:IsVisible() ~= vis then
			self.gradeEditBtn:SetVisible(vis)
		end
	end
end

function PANEL:OnKeyCodePressed(keycode)
	if keycode == LocalPlayer():GetBindKey("inventory") and can_open == false then
		timer.Simple(0.1, function() can_open = true end)
		self:Close()
	end
end

-- Overlay CRÉÉ par cette frame (pas l'overlay partagé du HUD, réutilisé ailleurs) : retiré.
function PANEL:LibererOverlayPropre()
	if not IsValid(self.modelOverlay) then return end
	local sh = LZY_Character_PlayerModel_GetSharedOverlay and LZY_Character_PlayerModel_GetSharedOverlay()
	if self.modelOverlay ~= sh then self.modelOverlay:Remove() end
	self.modelOverlay = nil
end

-- FUITES corrigées (10/08) : la mort / le respawn suppriment la frame par Remove() direct
-- (cl_ko_networking, lost soul), sans OnClose : katana / gantelet d'aperçu et overlay restaient.
function PANEL:OnRemove()
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.OnInventoryClose then
		LZY_INVENTORY_ITEM_PREVIEW.OnInventoryClose(self)
	end
	SafeRemoveEntity(self.previewKatana)
	SafeRemoveEntity(self.previewGauntlet)
	self.previewKatana, self.previewGauntlet = nil, nil
	self:LibererOverlayPropre()
	if LZY_INVENTORY_FRAME == self then LZY_INVENTORY_FRAME = nil end
	if frame == self then
		frame = nil
		timer.Simple(0.1, function() can_open = true end)
	end
end

function PANEL:OnClose()
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.OnInventoryClose then
		LZY_INVENTORY_ITEM_PREVIEW.OnInventoryClose(self)
	end
	self._lastInvPreviewSig = nil
	self:HideItemDescriptionTooltip()
	if IsValid(self.contextmenu) then
		self.contextmenu:Remove()
	end
	-- Detach from shared panel rig; do not Remove() shared CSEnts (HUD rebake may reuse them).
	if IsValid(self.modelPanel) then
		self.modelPanel.PreDrawModel = function() return true end
	end
	if IsValid(self.modelPanel) and IsValid(self.modelPanel.Entity) then
		local ent = self.modelPanel.Entity
		if LZY_Character_PlayerModel_ReleaseEntityParts then
			LZY_Character_PlayerModel_ReleaseEntityParts(ent)
		else
			ent.PlayerModelParts = nil
			ent.RenderOverride = nil
		end
		ent._inventoryModelOverlay = nil
		ent._lzySharedOverlayBoneMap = nil
	end
	if IsValid(self.modelPanel) then
		self.modelPanel:Remove()
		self.modelPanel = nil
	end
	if IsValid(self.modelOverlay) then
		local shared = LZY_Character_PlayerModel_GetSharedOverlay and LZY_Character_PlayerModel_GetSharedOverlay()
		if not IsValid(shared) or self.modelOverlay ~= shared then
			self.modelOverlay:Remove()
		end
		self.modelOverlay = nil
	end
	if IsValid(self.previewKatana) then
		SafeRemoveEntity(self.previewKatana)
		self.previewKatana = nil
	end
	if IsValid(self.previewGauntlet) then
		SafeRemoveEntity(self.previewGauntlet)
		self.previewGauntlet = nil
	end

	hook.Remove("PlayerButtonUp", "LZY_Inventory_ModelDrag")
	if IsValid(self._presetPopup) then self._presetPopup:Remove() end
	-- La camera d'inventaire s'arrete des que la frame n'est plus valide (le self:Remove()
	-- ci-dessous suffit), mais on lache la reference explicitement : ca evite de garder un
	-- panneau detruit en global entre deux ouvertures.
	self._invCamOn = nil -- coupe la camera d'inventaire : la vue revient au joueur
	self._invIntroLock = nil -- filet : fermeture pendant l'intro, la vue ne reste pas figee
	-- Rend la camera orbitale au jeu (miroir de l'arbitrage pose dans Init).
	local lpCam = LocalPlayer()
	if IsValid(lpCam) then lpCam.ActiveCamera = true end
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = false end
	LZY_INVENTORY_FRAME = nil
	frame = nil
	timer.Simple(0.1, function() can_open = true end)
	self:Remove()
end

function PANEL:UpdatePreviewKatana(ent)
	local ply = LocalPlayer()
	if not IsValid(ply) or not IsValid(ent) then
		if IsValid(self.previewKatana) then
			SafeRemoveEntity(self.previewKatana)
			self.previewKatana = nil
		end
		return
	end

	-- Source de vérité : le slot inventaire. Si vide → pas de katana à afficher,
	-- même si KatanaSkin/StyleCombat NWStrings restent set (ils représentent le
	-- skin/style, pas l'état d'équipement). Note : `ply.inventory` n'existe QUE
	-- côté serveur ; côté client il faut passer par GetInventoryEquippedItems().
	local equipped = ply.GetInventoryEquippedItems and ply:GetInventoryEquippedItems() or nil
	local katanaItemId = equipped and equipped["katana"]
	if not katanaItemId or katanaItemId == "" then
		if IsValid(self.previewKatana) then
			SafeRemoveEntity(self.previewKatana)
			self.previewKatana = nil
		end
		return
	end

	-- HAKUDA (bNoWeapon) : JAMAIS de katana rangé dans la preview non plus — même
	-- court-circuit EN PREMIER que le katana rangé in-game (cl_sheathed_katana) et
	-- le worldmodel (citron_combat_weapons/cl_init). Sans ça, après un swap
	-- katana -> hakuda chez le Maître des Arts, l'inventaire montrait encore le
	-- katana rangé alors que le perso n'en a plus (bug user 2026-07-26).
	do
		local sStyleID = ply:GetEvoNWString("StyleCombat", "")
		local tStyleCfg = (sStyleID ~= "" and EvoStyle and EvoStyle.StyleCombatCfg)
			and EvoStyle.StyleCombatCfg[sStyleID] or nil
		if tStyleCfg and tStyleCfg.bNoWeapon then
			if IsValid(self.previewKatana) then
				SafeRemoveEntity(self.previewKatana)
				self.previewKatana = nil
			end
			return
		end
	end

	-- Lookup the model the same way the in-game sheathed katana does
	-- (ncm_ranger_katana/cl_sheathed_katana.lua → ResolveWeaponModel) so any
	-- skin/style/bankai override the player has applied shows up in the preview too.
	local model = nil
	local sOverride = ply:GetEvoNWString("EVO_SheathedModel", "")
	if sOverride ~= "" then
		model = sOverride
	else
		local sBankai = ply:GetEvoNWString("BankaiWeaponOverride", "")
		if sBankai ~= "" then
			model = sBankai
		else
			local sSkinID = ply:GetEvoNWString("KatanaSkin", "")
			if sSkinID ~= "" and KATANA_SKINS and KATANA_SKINS.GetModelByID then
				model = KATANA_SKINS.GetModelByID(sSkinID)
			end
			if not model then
				local sStyleID = ply:GetEvoNWString("StyleCombat", "")
				if sStyleID ~= "" and EvoStyle and EvoStyle.StyleCombatCfg then
					local tCfg = EvoStyle.StyleCombatCfg[sStyleID]
					if tCfg and tCfg.sWeaponModel then model = tCfg.sWeaponModel end
				end
			end
		end
	end
	-- Last-resort fallback : the equipped katana item's model_path (from inventory)
	if not model then
		local itemData = ITEMS and ITEMS[katanaItemId] or nil
		if itemData and isstring(itemData.model_path) and itemData.model_path ~= "" then
			model = itemData.model_path
		end
	end

	if not model then
		if IsValid(self.previewKatana) then
			SafeRemoveEntity(self.previewKatana)
			self.previewKatana = nil
		end
		return
	end

	if IsValid(self.previewKatana) and self.previewKatana:GetModel() ~= model then
		SafeRemoveEntity(self.previewKatana)
		self.previewKatana = nil
	end

	if not IsValid(self.previewKatana) then
		self.previewKatana = ClientsideModel(model, RENDERGROUP_OPAQUE)
		if not IsValid(self.previewKatana) then return end
		self.previewKatana:SetRenderBounds(Vector(-100, -100, -100), Vector(100, 100, 100))
		self.previewKatana:SetSolid(SOLID_NONE)
		self.previewKatana:SetMoveType(MOVETYPE_NONE)
		self.previewKatana:SetNoDraw(true)
	end

	-- Use the player's current sheath position (set via the in-game katana editor)
	-- instead of hardcoding "hip". Fall back to "hip" if the NWString is empty.
	local sMode = ply:GetEvoNWString("EVO_SheathedKatana", "")
	if sMode == "" then sMode = ply:GetEvoNWString("NCM_KatanaPos", "hip") end
	if sMode == "" then sMode = "hip" end
	local tCfg = NCM_KATANA_CONFIG and NCM_KATANA_CONFIG.tAttach and NCM_KATANA_CONFIG.tAttach[sMode]
	if not tCfg then return end

	ent:SetupBones()
	local nBone = ent:LookupBone(tCfg.sBone)
	if not nBone then return end

	local matrix = ent:GetBoneMatrix(nBone)
	if not matrix then return end

	local vBonePos = matrix:GetTranslation()
	local aBoneAng = matrix:GetAngles()

	local vFinal = vBonePos + aBoneAng:Forward() * tCfg.vOffset.x + aBoneAng:Right() * tCfg.vOffset.y +
		aBoneAng:Up() * tCfg.vOffset.z

	local aFinal = Angle(aBoneAng)
	aFinal:RotateAroundAxis(aBoneAng:Right(), tCfg.aOffset.p)
	aFinal:RotateAroundAxis(aBoneAng:Up(), tCfg.aOffset.y)
	aFinal:RotateAroundAxis(aBoneAng:Forward(), tCfg.aOffset.r)

	self.previewKatana:SetPos(vFinal)
	self.previewKatana:SetAngles(aFinal)
	self.previewKatana:SetupBones()
	-- Famille de textures : MÊME règle que le fourreau en jeu (cl_sheathed_katana) —
	-- 1 en shikai/bankai ou pour une variante « _shikai » équipée, 0 sinon. Sans ça le
	-- mannequin montrait la version de base d'une variante (user 08/26). LOD 0 forcé :
	-- les meshes LOD perdent souvent la 2e famille.
	local nSkin = 0
	if self.previewKatana:SkinCount() > 1 then
		if ply:GetEvoNWBool("EVO_ShikaiActive", false) or ply:GetEvoNWBool("EVO_Bankai", false) then
			nSkin = 1
		elseif KATANA_SKINS and KATANA_SKINS.GetBaseSkinByID then
			nSkin = KATANA_SKINS.GetBaseSkinByID(ply:GetEvoNWString("KatanaSkin", ""))
		end
	end
	if self.previewKatana:GetSkin() ~= nSkin then self.previewKatana:SetSkin(nSkin) end
	self.previewKatana:SetLOD(0)
	self.previewKatana:DrawModel()
end

-- Gantelets Hakuda dans la preview inventaire (bonemerge sur le modèle du
-- panel). Même règle que le monde : visibles seulement si la coche
-- « Porter les gantelets » est active — hors combat, pas de katana rangé.
function PANEL:UpdatePreviewGauntlet(ent)
	local ply = LocalPlayer()
	local function clear()
		if IsValid(self.previewGauntlet) then
			SafeRemoveEntity(self.previewGauntlet)
			self.previewGauntlet = nil
		end
	end
	if not IsValid(ply) or not IsValid(ent) then return clear() end
	if not InventoryIsHakudaFamily() then return clear() end
	if not ply:GetEvoNWBool("NCM_HakudaAlwaysWear", false) then return clear() end

	local sID = ply:GetEvoNWString("NCM_HakudaGauntlet", "")
	if sID == "" then
		sID = (NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.DefaultID) or ""
	end
	local mdl = NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.GetModelByID(sID) or ""
	if mdl == "" then return clear() end

	if IsValid(self.previewGauntlet)
		and (self.previewGauntlet:GetModel() ~= mdl or self.previewGauntlet:GetParent() ~= ent)
	then
		clear()
	end
	if not IsValid(self.previewGauntlet) then
		self.previewGauntlet = ClientsideModel(mdl, RENDERGROUP_OPAQUE)
		if not IsValid(self.previewGauntlet) then return end
		self.previewGauntlet:SetParent(ent)
		self.previewGauntlet:SetLocalPos(vector_origin)
		self.previewGauntlet:SetLocalAngles(angle_zero)
		self.previewGauntlet:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
		self.previewGauntlet:SetNoDraw(true)
		if self.previewGauntlet.DrawShadow then self.previewGauntlet:DrawShadow(false) end
	end
	ent:SetupBones()
	self.previewGauntlet:DrawModel()
end

function PANEL:DrawClientPlayerModel(x, y, w, h)
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	-- Display helper : uniforme de grade + identité faction LIVE (rank/division). Le monde lit les
	-- NW ; playersModels.rank reste un snapshot de sélection tant que le CSM n'a pas re-poussé.
	local characterData = (GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply))
		or (GetPlayerCharacterData and GetPlayerCharacterData(ply))
		or nil
	local faceModel = nil
	if characterData and LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
		faceModel = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
	end
	faceModel = faceModel or ply:GetModel()

	-- evo_hollow_progression : larva = modèle créature brut dans le preview inventaire.
	local isLarvaRaw = ply:GetEvoNWBool("EVO_HollowRaw", false)
		or (LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply, characterData))
	if isLarvaRaw then
		faceModel = ply:GetModel()
	end

	if not IsValid(self.modelPanel) then
		self.modelPanel = vgui.Create("DModelPanel", self)
		self.modelPanel:SetMouseInputEnabled(true)
		self.modelPanel:SetZPos(9999)
		self.modelPanel.mouseX = 0
		self.modelPanel.mouseY = 0
		self.modelPanel.rotationX = 0
		self.modelPanel.rotationY = 0
		self.modelPanel.isDragging = false

		if MUGEN and MUGEN.ModelView then
			MUGEN.ModelView(self.modelPanel, w, h, x, y, 55, faceModel, false, true)
		else
			self.modelPanel:SetCamPos(Vector(50, 50, 50))
			self.modelPanel:SetLookAt(Vector(0, 0, 0))
			self.modelPanel:SetFOV(45)
			self.modelPanel:SetAnimated(true)
		end

		-- TROU TRANSPARENT (portage evo-ds) : le modele client n'est plus dessine, c'est le
		-- VRAI joueur qui est cadre ici par la camera. Le panel reste pour le glisser-deposer
		-- d'equipement, le survol et les apercus internes.
		self.modelPanel.DrawModel = function() end
		self.modelPanel.OnMousePressed = function(panel, key)
			if key == MOUSE_LEFT then
				panel.isDragging = true
				panel.mouseX = gui.MouseX()
				panel.mouseY = gui.MouseY()
			end
		end
		self.modelPanel.OnMouseReleased = function(panel, key)
			if key == MOUSE_LEFT then panel.isDragging = false end
		end

		-- Zoom à la molette (FOV constant, pas de distorsion) qui VISE LA TÊTE en
		-- zoomant. camDist <1 = zoom avant, >1 arrière. La vue de base est un peu
		-- dézoomée (corps entier visible).
		self.modelPanel.camDist = 1.2
		self.modelPanel.isLarvaPreview = false
		self.modelPanel.ApplyZoom = function(panel)
			local d       = panel.camDist
			local isLarva = panel.isLarvaPreview
			local lz, camMul, maxDist
			if isLarva then
				-- Larva hollow : modèle plus grand + caméra reculée pour voir le corps entier.
				lz = -152
				camMul = 58
				maxDist = 2.8
				if d < 1.0 then
					lz = Lerp((1.0 - d) / 0.6, -152, -124)
				end
			else
				lz = 38 -- centre du corps par défaut (corps entier visible)
				camMul = 40
				maxDist = 2.0
				if d < 1.0 then
					lz = Lerp((1.0 - d) / 0.6, 38, 63) -- en zoomant -> on monte vers la tête
				end
			end
			panel.camDist = math.Clamp(d, 0.4, maxDist)
			panel:SetLookAt(Vector(0, 0, lz))
			panel:SetCamPos(Vector(camMul * panel.camDist, 0, lz))
		end
		-- Molette : c'est la CAMERA qui se rapproche / s'eloigne du joueur.
		self.modelPanel.OnMouseWheeled = function(panel, delta)
			INV_CAM.dist = math.Clamp(INV_CAM.dist - delta * 14, 80, 280)
			return true
		end
		self.modelPanel:ApplyZoom()
		hook.Add("PlayerButtonUp", "LZY_Inventory_ModelDrag", function(_, button)
			if button == MOUSE_LEFT and IsValid(self.modelPanel) then
				self.modelPanel.isDragging = false
			end
		end)
		-- Glisser : VRAIE ORBITE autour du joueur (le personnage ne pivote pas sur
		-- lui-meme, c'est le point de vue qui tourne autour de lui, a distance constante).
		-- Horizontal = tour du joueur, vertical = on monte / descend sur la meme sphere.
		self.modelPanel.Think = function(panel)
			if panel.isDragging then
				local newMouseX, newMouseY = gui.MouseX(), gui.MouseY()
				INV_CAM.yaw = INV_CAM.yaw - (newMouseX - panel.mouseX) * 0.4
				-- Glisser vers le BAS fait MONTER la camera (on regarde alors d'en haut),
				-- convention des vues 3D.
				INV_CAM.pitch = math.Clamp(INV_CAM.pitch + (newMouseY - panel.mouseY) * 0.3,
					INV_CAM_PITCH_MIN, INV_CAM_PITCH_MAX)
				panel.mouseX, panel.mouseY = newMouseX, newMouseY
			end
		end
		self.modelPanel.LayoutEntity = function(panel, ent)
			if IsValid(ent) then
				if panel.isLarvaPreview then
					ent:SetLocalPos(Vector(0, 0, -248))
				else
					ent:SetLocalPos(vector_origin)
				end
				ent:SetAngles(Angle(panel.rotationX, panel.rotationY, 0))
				ent:FrameAdvance(RealFrameTime())
				-- katana draw is done in PreDrawModel (set in SetupPanelEntity below)
				-- which runs inside the panel's 3D render context. LayoutEntity is
				-- positioning only and DrawModel() doesn't work from here.
			end
		end

		-- Accept katana / outfit / accessory drag-and-drop from bag onto the preview (same idea as katana slot)
		self.modelPanel:Receiver("INV_ITEM", function(rcv, panels, bDoDrop)
			local dragged = panels and panels[1]
			if not IsValid(dragged) or not dragged.itemId then
				self.modelDragHover = false
				return
			end
			local it = ITEMS and ITEMS[dragged.itemId]
			local equipKind = nil
			if it and it.skin_id then
				equipKind = "katana"
			elseif it and it.category == "outfit" and isstring(it.model_path) and it.model_path ~= "" then
				equipKind = "outfit"
			elseif it and it.category == "accessory" and INVENTORY_CONFIG.GetAccessoryEquipSlot and INVENTORY_CONFIG.GetAccessoryEquipSlot(it) then
				equipKind = "accessory"
			end

			if not equipKind then
				self.modelDragHover = false
				return
			end

			if not bDoDrop then
				self.modelDragHover = true
				return
			end

			self.modelDragHover = false
			if not dragged.slotIndex then return end

			local ok = false
			if equipKind == "katana" then
				ok = self:DoEquipKatana(dragged.itemId, dragged.slotIndex)
			elseif equipKind == "outfit" then
				ok = self:DoEquipOutfit(dragged.itemId, dragged.slotIndex)
			else
				ok = self:DoEquipAccessory(dragged.itemId, dragged.slotIndex)
			end
			if ok then dragged:Remove() end
		end)
	end

	self.modelPanel:SetPos(x, y)
	self.modelPanel:SetSize(w, h)
	self.modelPanel:SetVisible(true)

	-- Re-run SetupPanelEntity when body, hair, skin, bodygroups, or equipped accessories change (outfit / accessory equip).
	local buildSig = (characterData and LZY_Character_PlayerModel_ComputeBuildSig)
		and LZY_Character_PlayerModel_ComputeBuildSig(characterData) or ""
	local previewSig = buildSig
	if characterData and buildSig ~= "" then
		previewSig = buildSig .. "\n" .. tostring(characterData.skin_color) .. "\n"
			.. tostring(characterData.bodygroupsString) .. "\n"
			.. tostring(characterData.hide_hair) .. "\n"
			.. tostring(IsValid(ply) and ply:GetEvoNWBool("hide_hair", false)) .. "\n"
			.. tostring(characterData.hide_epaulette) .. "\n"
			.. tostring(IsValid(ply) and ply:GetEvoNWBool("EVO_HideEpaulette", false)) .. "\n"
			.. tostring(characterData.hide_rank_outfit) .. "\n"
			.. tostring(IsValid(ply) and ply:GetEvoNWBool("EVO_HideRankOutfit", false)) .. "\n"
			.. tostring(characterData.hide_division_body)
	elseif characterData and util.TableToJSON then
		previewSig = util.TableToJSON({
			b = characterData.body_model,
			h = characterData.hair_model,
			a = characterData.equipped_accessories,
			sk = characterData.skin_color,
			bg = characterData.bodygroupsString,
			dh = characterData.hide_hair,
			hh = IsValid(ply) and ply:GetEvoNWBool("hide_hair", false),
			de = characterData.hide_epaulette,
			he = IsValid(ply) and ply:GetEvoNWBool("EVO_HideEpaulette", false),
			dro = characterData.hide_rank_outfit,
			hro = IsValid(ply) and ply:GetEvoNWBool("EVO_HideRankOutfit", false),
		}) or ""
	end
	local previewChanged = self._lastInvPreviewSig ~= previewSig
	if previewChanged then
		self._lastInvPreviewSig = previewSig
	end

	local modelOrDataChanged = (self._lastModelName ~= faceModel) or
		(self._lastHadCharacterData ~= (characterData and true))
	if modelOrDataChanged then
		self._lastModelName = faceModel
		self._lastHadCharacterData = (characterData and true) or false
		self.modelPanel:SetModel(faceModel)
	end

	local ent = self.modelPanel.Entity
	if not IsValid(ent) then return end

	if isLarvaRaw then
		if ent.PlayerModelParts then
			for _, e in pairs(ent.PlayerModelParts) do
				if istable(e) then
					for _, sub in ipairs(e) do
						if IsValid(sub) then SafeRemoveEntity(sub) end
					end
				elseif IsValid(e) then
					SafeRemoveEntity(e)
				end
			end
		end
		ent.PlayerModelParts = nil
		ent.RenderOverride = nil
		ent._inventoryModelOverlay = nil
		ent:SetSkin(ply:GetSkin() or 0)
		for i = 0, ent:GetNumBodyGroups() - 1 do
			ent:SetBodygroup(i, ply:GetBodygroup(i))
		end
		if ent.SetModelScale then
			-- In-game larva scale is 1.4–1.9 ; réduit pour cadrer le corps entier dans le panel.
			ent:SetModelScale((ply:GetModelScale() or 1) * 1.4)
		end
		self.modelPanel.isLarvaPreview = true
		self.modelPanel.camDist = 2.0
		if self.modelPanel.ApplyZoom then self.modelPanel:ApplyZoom() end
		self.modelPanel.PreDrawModel = function(panel, e)
			if IsValid(e) then self:UpdatePreviewKatana(e) end
		end
		return
	end

	if IsValid(self.modelPanel) and self.modelPanel.isLarvaPreview then
		self.modelPanel.isLarvaPreview = false
		self.modelPanel.camDist = 1.2
		if self.modelPanel.ApplyZoom then self.modelPanel:ApplyZoom() end
	end

	local needSetup = modelOrDataChanged or previewChanged
	if not needSetup and characterData and characterData.body_model and characterData.hair_model then
		needSetup = (not ent.PlayerModelParts or not ent.RenderOverride)
			or ent._lzyPanelBuildSig ~= buildSig
			or (LZY_Character_PlayerModel_IsSharedRigReady and not LZY_Character_PlayerModel_IsSharedRigReady())
	end
	if needSetup then
		if characterData and characterData.body_model and characterData.hair_model then
			ent:SetSkin(characterData.skin_color or 0)
			if characterData.bodygroupsString and ent.SetBodyGroups then
				ent:SetBodyGroups(characterData
					.bodygroupsString)
			end
			LZY_Character_PlayerModel_SetupPanelEntity(ent, characterData, nil)
			self:LibererOverlayPropre()
			self.modelOverlay = LZY_Character_PlayerModel_GetSharedOverlay and
				LZY_Character_PlayerModel_GetSharedOverlay()
			-- Draw equipped katana on top of the character (positioned via hip bone).
			-- Must run inside the panel's 3D render context (PreDrawModel), NOT LayoutEntity.
			self.modelPanel.PreDrawModel = function(panel, e)
				if IsValid(e) then
					self:UpdatePreviewKatana(e)
					self:UpdatePreviewGauntlet(e)
				end
			end
		else
			ent:SetSkin(ply:GetSkin() or 0)
			ent.PlayerModelParts = nil
			ent.RenderOverride = nil
			ent._inventoryModelOverlay = nil
			for k = 0, (ply:GetNumBodyGroups() or 0) - 1 do
				ent:SetBodygroup(k, ply:GetBodygroup(k) or 0)
			end
			if MUGEN and MUGEN.Character and MUGEN.Character.Config then
				if LZY_Character_PlayerModel_GetSharedOverlay then
					local sh = LZY_Character_PlayerModel_GetSharedOverlay()
					if IsValid(sh) then self:LibererOverlayPropre() self.modelOverlay = sh end
				end
				if not IsValid(self.modelOverlay) then
					self.modelOverlay = ClientsideModel(
						MUGEN.Character.Config.StandartModel or "models/ali/bleach/vetement_homme.mdl",
						RENDERGROUP_OPAQUE)
				end
				if IsValid(self.modelOverlay) then
					self.modelOverlay:SetNoDraw(true)
					self.modelOverlay:SetSkin(ply:GetSkin() or 0)
					local bodygroupsTable = util.JSONToTable(ply:GetEvoNWString("OverlayBodygroups", "{}"))
					if istable(bodygroupsTable) then
						for indexStr, value in pairs(bodygroupsTable) do
							local index = tonumber(indexStr)
							if index and isnumber(value) and self.modelOverlay:GetBodygroupCount(index) > 1 then
								self.modelOverlay:SetBodygroup(index, value)
							end
						end
					end
					self.modelPanel.PreDrawModel = function(panel, e)
						if IsValid(self.modelOverlay) and IsValid(e) then
							e:SetupBones()
							self.modelOverlay:SetupBones()
							for i = 0, self.modelOverlay:GetBoneCount() - 1 do
								local boneName = self.modelOverlay:GetBoneName(i)
								local entBone = e:LookupBone(boneName)
								if entBone then
									local matrix = e:GetBoneMatrix(entBone)
									if matrix then self.modelOverlay:SetBoneMatrix(i, matrix) end
								end
							end
							self.modelOverlay:SetPos(e:GetPos())
							self.modelOverlay:SetAngles(e:GetAngles())
							self.modelOverlay:DrawModel()
						end
						if IsValid(e) then
							self:UpdatePreviewKatana(e)
							self:UpdatePreviewGauntlet(e)
						end
					end
				end
			end
		end
	end
end

vgui.Register("lzy_inventory", PANEL, "DFrame")

function OpenInventory()
	if LZY_AccessoryEditor_IsActive and LZY_AccessoryEditor_IsActive() then return end
	if IsValid(LocalPlayer()) and LocalPlayer():GetEvoNWBool("NCM_TF_Active", false) then return end -- pas d'inventaire en possession (boss)
	if IsValid(frame) then
		frame:Close()
	else
		frame = vgui.Create("lzy_inventory")
	end
end

hook.Add("PlayerButtonDown", "LZY_Inventory_KeyBind", function(ply, button)
	if ply:GetEvoNWBool("NCM_TF_Active", false) then return end -- pas d'inventaire en possession (boss)
	if LZY_AccessoryEditor_IsActive and LZY_AccessoryEditor_IsActive() then return end
	if button == LocalPlayer():GetBindKey("inventory") and can_open == true then
		if IsValid(frame) then
			frame:Close()
		end
		frame = vgui.Create("lzy_inventory")
		can_open = false
	end
end)

-- Refresh bag + equipment when inventory syncs while panel is open
hook.Add("LZY_Inventory_Synced", "LZY_Inventory_RefreshOnSync", function()
	if not IsValid(frame) then return end
	-- Force inventory preview to re-apply LZY_Character_PlayerModel_SetupPanelEntity on next Draw
	frame._lastInvPreviewSig = nil
	local data = LocalPlayer():GetInventory()
	local items = data.items
	if items then
		frame.inventoryMap = {}
		frame.quantityMap = {}
		local maxSlots = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
		for i = 1, maxSlots do
			local itemId = items[i]
			if isstring(itemId) and itemId ~= "" then
				frame.inventoryMap[i] = itemId
				frame.quantityMap[i] = InventorySlotStackQty(data, i)
			end
		end
	end
	frame:RefreshItemsForCategory()
	frame:RefreshEquippedItems()
end)

hook.Add("LZY_Character:RepairPanelModels", "LZY_Inventory_RepairPreview", function()
	if not IsValid(frame) then return end
	frame._lastInvPreviewSig = nil
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if ply:GetEvoNWBool("EVO_HollowRaw", false) then return end
	-- Display helper : body uniforme + grade LIVE (sinon Repair reconstruit l'épaulette stale).
	local characterData = (GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply))
		or (GetPlayerCharacterData and GetPlayerCharacterData(ply))
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply, characterData) then return end
	local ent = IsValid(frame.modelPanel) and frame.modelPanel.Entity
	if IsValid(ent) and characterData and characterData.body_model and characterData.hair_model
		and LZY_Character_PlayerModel_SetupPanelEntity then
		ent:SetSkin(characterData.skin_color or 0)
		if characterData.bodygroupsString and ent.SetBodyGroups then
			ent:SetBodyGroups(characterData.bodygroupsString)
		end
		LZY_Character_PlayerModel_SetupPanelEntity(ent, characterData, frame.modelOverlay)
	end
end)

hook.Add("LZY_Inventory_Cleared", "LZY_Inventory_ClearCache", function()
	inventory = {}
	equipped_items = {}
	if IsValid(frame) then
		frame.inventoryMap = {}
		frame.quantityMap = {}
		frame:RefreshItemsForCategory()
		frame:RefreshEquippedItems()
	end
end)

-- ════════════════════════════════════════════════════════════════════════════
-- CAMERA DE L'INVENTAIRE (portage evo-ds, user 09/03). Tant que l'inventaire est
-- ouvert, la vue quitte la premiere personne et cadre le VRAI joueur dans le trou
-- transparent du panneau : ce qu'on voit est le personnage REEL, avec sa tenue, ses
-- accessoires et son katana range, pas un modele d'apercu.
-- ⚠ AUCUNE logique serveur : tout est client, la vue est purement locale.
-- ════════════════════════════════════════════════════════════════════════════
-- Hauteur VISEE sur le corps. Ce point est ramene au centre du trou par le decalage
-- angulaire plus bas : plus on vise BAS, plus le personnage MONTE a l'ecran.
-- 09/03 : abaissee de 36 a 24 — le user trouvait son personnage trop bas. Baisser
-- encore le fait monter davantage ; a l'inverse, remonter cette valeur le redescend.
-- C'EST LE SEUL REGLAGE A TOUCHER pour la hauteur du personnage a l'ecran.
-- Puis 24 -> 19 : en descendant les cases du haut et les coches, le trou est descendu
-- de 36 px ; on abaisse la visee d'autant (~7,8 px d'ecran par unite monde a ce zoom)
-- pour que le personnage reste EXACTEMENT a la meme hauteur qu'avant a l'ecran.
local INV_CAM_Z = 19

local function invCamFrame()
	-- On teste le DRAPEAU, pas IsVisible : la fenetre est volontairement cachee pendant
	-- le mouvement d'ouverture, et c'est justement la que la camera doit agir.
	local f = LZY_INVENTORY_FRAME
	if not IsValid(f) or not f._invCamOn then return nil end
	return f
end

hook.Add("CalcView", "LZY_Inventory::CharCam", function(ply, pos, ang, fov)
	if not invCamFrame() then return end
	if not IsValid(ply) or not ply:Alive() then return end

	-- ARRIVEE EN ORBITE (recette evo-ds, cf. INV_CAM_INTRO_*) : f va de 0 (derriere le
	-- personnage, loin) a 1 (cadrage de face, distance de la molette), en ease-out.
	local f = math.Clamp((RealTime() - INV_CAM.t0) / INV_CAM_INTRO, 0, 1)
	f = 1 - (1 - f) ^ 3
	local dist = Lerp(f, INV_CAM_INTRO_DIST, INV_CAM.dist)

	-- Zoom : plus la camera se rapproche, plus le point vise remonte le long du corps
	-- (19 au repos -> 39 au zoom maxi). Voir INV_CAM_Z pour regler la hauteur du cadrage.
	local zf = math.Clamp((180 - dist) / 100, 0, 1)
	local center = ply:GetPos() + Vector(0, 0, INV_CAM_Z + 20 * zf)
	-- ORBITE SPHERIQUE autour du joueur : le yaw fait le tour (demi-tour d'intro, puis
	-- glisser a la souris), le pitch monte ou descend sur la meme sphere. Hors intro la
	-- distance ne bouge qu'a la molette : la camera reste bien « autour » du joueur.
	local fwd = ply:GetForward()
	fwd.z = 0
	fwd:Normalize()
	fwd:Rotate(Angle(0, INV_CAM.yaw + (1 - f) * INV_CAM_INTRO_YAW, 0))
	local aOrbite = fwd:Angle()
	aOrbite.p = aOrbite.p - INV_CAM.pitch -- pitch > 0 -> la camera monte
	fwd = aOrbite:Forward()
	local camPos = center + fwd * dist

	-- Vue DROITE sur le personnage : cet angle n'est plus jamais modifie.
	local a = (center - camPos):Angle()

	-- ⚠ NE JAMAIS FAIRE PIVOTER LA CAMERA POUR RECADRER (user 09/03 : « tu courbes la
	-- cam, arrete »). Une rotation regarde le personnage DE BIAIS : les verticales
	-- fuient et le corps parait penche. Pour l'amener dans le trou (qui n'est pas au
	-- centre de l'ecran) on DEPLACE la camera sans la tourner — le decentrage optique
	-- du cinema : le sujet glisse dans le cadre en restant vu de face.
	-- Deplacer la camera vers la DROITE fait glisser le sujet vers la GAUCHE, d'ou les
	-- signes ci-dessous ; idem en vertical (l'axe ecran descend).
	local aspect = ScrW() / ScrH()
	local hfov = 2 * math.deg(math.atan(math.tan(math.rad(fov) * 0.5) * aspect / (4 / 3)))
	local vfov = 2 * math.deg(math.atan(math.tan(math.rad(fov) * 0.5) * 3 / 4))
	local fracX = gRespX(INV.VP_X + INV.VP_W * 0.5) / ScrW() - 0.5
	local fracY = gRespY(INV.VP_Y + INV.VP_H * 0.5) / ScrH() - 0.5
	-- Demi-largeur / demi-hauteur du champ a la distance du personnage, en unites monde.
	local nDemiL = math.tan(math.rad(hfov) * 0.5) * dist
	local nDemiH = math.tan(math.rad(vfov) * 0.5) * dist
	camPos = camPos - a:Right() * (2 * fracX * nDemiL) + a:Up() * (2 * fracY * nDemiH)

	-- Recul contre le DECOR seulement (murs, sols), calcule sur la position FINALE de la
	-- camera : un joueur, un PNJ ou un prop colle au personnage ne doit pas la rapprocher
	-- de force, le joueur etant de toute facon redessine net par-dessus.
	local tr = util.TraceLine({ start = center, endpos = camPos, mask = MASK_SOLID_BRUSHONLY })
	if tr.Hit then camPos = tr.HitPos + (center - camPos):GetNormalized() * 8 end

	-- Coupe franche, comme evo-ds : aucun fondu depuis la vue du joueur, c'est l'orbite
	-- ci-dessus qui fait toute l'arrivee.
	return { origin = camPos, angles = a, fov = fov, drawviewer = true }
end)

-- Le joueur doit etre dessine dans la passe monde (il y est floute sous le voile du
-- panneau) AVANT d'etre redessine net par invDrawLocalPlayerSharp : sans cette passe,
-- DrawModel sur le joueur local ne rend rien du tout.
hook.Add("ShouldDrawLocalPlayer", "LZY_Inventory::CharCam", function()
	if invCamFrame() then return true end
end)

-- VERROU PENDANT L'OUVERTURE (user 09/03) : tant que la camera se place, la vue et le
-- deplacement sont figes — sinon on tourne le personnage sous la camera qui le cadre.
-- On NE touche PAS aux boutons : la touche d'inventaire doit rester relachable, et un
-- ClearButtons ici bloquerait aussi la fermeture.
hook.Add("CreateMove", "LZY_Inventory::IntroLock", function(cmd)
	local f = LZY_INVENTORY_FRAME
	if not IsValid(f) or not f._invIntroLock then return end
	if f._invIntroAng then cmd:SetViewAngles(f._invIntroAng) end
	cmd:ClearMovement()
	return true
end)
