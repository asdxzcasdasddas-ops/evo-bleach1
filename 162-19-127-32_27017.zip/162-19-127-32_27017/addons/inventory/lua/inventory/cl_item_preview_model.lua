-- "addons\\inventory\\lua\\inventory\\cl_item_preview_model.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client: shared 3D item slot preview (inventory bag/equip + lzy_trade). Depends on ITEMS from config.
-- World drop pickup prompts (cl_drop.lua) call LZY_INVENTORY_GetUseKeyDisplay() below.

LZY_INVENTORY_ITEM_PREVIEW = LZY_INVENTORY_ITEM_PREVIEW or {}

-- Palier de rareté -> valeur de bodygroup/skin du modèle (variante "colorée" par rareté).
-- Uniquement pour les objets SANS `skin`/`bodygroup` explicite ET qui ne sont PAS un
-- accessoire/tenue/arme (cf. applyVariant). Les $texturegroup des chapeaux, masques,
-- écharpes… sont des familles de COULEUR, pas de rareté.
local RARITY_BODYGROUP_TIER = { common = 0, rare = 1, epic = 2, legendary = 3, mythic = 4 }

-- Modèles dont les SKINS sont des COULEURS, pas des raretés : d'autres items du même
-- modèle posent un `skin = n` explicite (écharpes, chapeaux, capes, colliers...). Sur
-- eux la retombée « rareté = skin » collait une mauvaise couleur en case (écharpe
-- Toshiro rare -> skin 1 = la blanche) alors que le perso porte le skin 0 (user 08/25).
-- Cache reconstruit quand ITEMS change de taille (items générés en différé).
local colorSkinModels, colorSkinCount = nil, -1
local function ModelUsesColorSkins(sPath)
	if not isstring(sPath) or not istable(ITEMS) then return false end
	local n = 0
	for _ in pairs(ITEMS) do n = n + 1 end
	if colorSkinModels == nil or n ~= colorSkinCount then
		colorSkinModels, colorSkinCount = {}, n
		for _, d in pairs(ITEMS) do
			if istable(d) and d.skin ~= nil and isstring(d.model_path) then colorSkinModels[d.model_path] = true end
		end
	end
	return colorSkinModels[sPath] == true
end

-- All item previews and custom thumbnail loaders share one model load per frame.
-- Precaching does not create entities or upload textures, so cached paths also queue.
local previewLoadQueue = {}
local previewLoadQueueHook = "LZY_Inventory_ItemPreviewLazyLoad"
local previewLoadQueueRunning = false
local previewWarmedPaths = {}
local inventoryPreviewScope
local previewLastLoadFrame = -1

-- Compatibility for existing menus. Loading is now always lazy, including refreshes
-- and subsequent opens; callers no longer need to start a first-open session.
function LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession(key, bAlways, pnlScope) end

function LZY_INVENTORY_ITEM_PREVIEW.OnInventoryOpen(scope)
	-- PrecacheModel does not create entities or upload their textures. Queue even
	-- warmed models, and keep this scope active for filtering/equipping later on.
	inventoryPreviewScope = scope
end

function LZY_INVENTORY_ITEM_PREVIEW.OnInventoryClose(scope)
	scope = scope or inventoryPreviewScope
	if not scope then return end
	for i = #previewLoadQueue, 1, -1 do
		if previewLoadQueue[i].inventoryScope == scope then
			local job = table.remove(previewLoadQueue, i)
			if IsValid(job.parent) then
				job.parent._previewLoadJob = nil
				job.parent._previewLoading = nil
				if job.parent.PaintOver == job.loadingPaint then job.parent.PaintOver = job.paintOver end
			end
		end
	end
	if inventoryPreviewScope == scope then inventoryPreviewScope = nil end
end

local function PreviewDrawLoadingSpinner(cx, cy, size)
	local count = 8
	local phase = math.floor(RealTime() * 8) % count
	local orbit = size * 0.35
	local dotR = math.max(2, size * 0.08)

	if RNDX and RNDX.DrawCircle then
		RNDX.DrawCircle(cx, cy, size * 0.55, Color(10, 10, 14, 140))
	end

	for i = 0, count - 1 do
		local ang = math.rad((i / count) * 360 - 90)
		local px = cx + math.cos(ang) * orbit
		local py = cy + math.sin(ang) * orbit
		local fade = 1 - (((i - phase + count) % count) / count) * 0.85
		local col = Color(235, 235, 245, math.floor(200 * fade))
		if RNDX and RNDX.DrawCircle then
			RNDX.DrawCircle(px, py, dotR * 2, col)
		else
			surface.SetDrawColor(col)
			surface.DrawRect(px - dotR, py - dotR, dotR * 2, dotR * 2)
		end
	end
end

local function PreviewFinishJob(job)
	local parent = job.parent
	if not IsValid(parent) or parent._previewLoadJob ~= job then return end
	parent._previewLoadJob = nil
	parent._previewLoading = nil
	if parent.PaintOver == job.loadingPaint then parent.PaintOver = job.paintOver end
end

local function PreviewCanLoad(parent)
	-- A hidden tab must not block a visible menu or create models behind it.
	local p = parent
	while IsValid(p) do
		if not p:IsVisible() then return false end
		p = p:GetParent()
	end
	return true
end

-- Defer SetModel and its camera/skin setup on an existing empty DModelPanel.
-- PaintOver keeps custom card backgrounds and interaction handlers intact.
function LZY_INVENTORY_ITEM_PREVIEW.QueueModelLoad(parent, load)
	if not IsValid(parent) or not isfunction(load) then return end
	if parent._previewLoadJob then PreviewFinishJob(parent._previewLoadJob) end
	local inInventory = IsValid(inventoryPreviewScope)
		and (parent == inventoryPreviewScope or parent:HasParent(inventoryPreviewScope))
	local job = {
		parent = parent,
		inventoryScope = inInventory and inventoryPreviewScope or nil,
		queuedFrame = FrameNumber(),
		load = load,
		paintOver = parent.PaintOver,
	}
	parent._previewLoadJob = job
	parent._previewLoading = true
	job.loadingPaint = function(panel, w, h)
		if job.paintOver then job.paintOver(panel, w, h) end
		-- Storage quantity overlays can retain this callback after PaintOver is
		-- replaced. Only the current pending job may draw a spinner.
		if panel._previewLoadJob ~= job or not panel._previewLoading then return end
		PreviewDrawLoadingSpinner(w * 0.5, h * 0.5, math.min(w, h) * 0.3)
	end
	parent.PaintOver = job.loadingPaint
	previewLoadQueue[#previewLoadQueue + 1] = job
	if previewLoadQueueRunning then return end
	previewLoadQueueRunning = true
	hook.Add("Think", previewLoadQueueHook, function()
		if previewLastLoadFrame == FrameNumber() then return end
		local i = 1
		while i <= #previewLoadQueue do
			local pending = previewLoadQueue[i]
			if not IsValid(pending.parent) or pending.parent._previewLoadJob ~= pending
				or (pending.inventoryScope and not IsValid(pending.inventoryScope)) then
				table.remove(previewLoadQueue, i)
				PreviewFinishJob(pending)
			elseif pending.queuedFrame < FrameNumber() and PreviewCanLoad(pending.parent) then
				table.remove(previewLoadQueue, i)
				previewLastLoadFrame = FrameNumber()
				-- Clear the placeholder before setup so callbacks can install PaintOver.
				PreviewFinishJob(pending)
				local ok, err = xpcall(function() pending.load(pending.parent) end, debug.traceback)
				if not ok then ErrorNoHalt("[item preview] " .. tostring(err) .. "\n") end
				break
			else
				i = i + 1
			end
		end
		if #previewLoadQueue == 0 then
			hook.Remove("Think", previewLoadQueueHook)
			previewLoadQueueRunning = false
		end
	end)
end

local function PreviewEnqueueModelPanel(parent, it, fov, marginOverride, slotInset, forceHighestLOD, onReady)
	parent.Paint = function() end
	LZY_INVENTORY_ITEM_PREVIEW.QueueModelLoad(parent, function(panel)
		if IsValid(panel._modelPanel) then panel._modelPanel:Remove() end
		LZY_INVENTORY_ITEM_PREVIEW._DoSetupModelPanel(panel, it, fov, marginOverride, slotInset, forceHighestLOD)
		if isstring(it.model_path) and it.model_path ~= "" then previewWarmedPaths[it.model_path] = true end
		if onReady then onReady(panel._modelPanel) end
	end)
end

--- Bound key for +use (e.g. "E"), uppercased — for prompts like "Appuyez sur … pour ramasser".
function LZY_INVENTORY_GetUseKeyDisplay()
	local bound = input.LookupBinding("+use")
	if not isstring(bound) or bound == "" then return "E" end
	bound = (string.gsub(bound, "^%s*(.-)%s*$", "%1"))
	if bound == "" then return "E" end
	return string.upper(bound)
end

function LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it)
	return it and isstring(it.model_path) and it.model_path ~= ""
end

function LZY_INVENTORY_ITEM_PREVIEW.ItemIsHeadAccessory(it)
	return it and it.category == "accessory" and isstring(it.slot) and string.lower(it.slot) == "head"
end

-- Bounds RÉELS du mesh (cache par modèle). Sur certains accessoires rigés (BAGUES…),
-- GetModelRenderBounds renvoie une boîte ÉNORME (bounds de séquence du squelette) ->
-- le cadrage dézoome à fond et l'item devient un point minuscule "introuvable" dans la
-- case. On mesure une fois les sommets réels (bind pose) via util.GetModelMeshes.
local meshBoundsCache = {}
local function GetMeshBounds(mdlPath)
	if not isstring(mdlPath) or mdlPath == "" then return nil end
	local c = meshBoundsCache[mdlPath]
	if c == false then return nil end
	if c then return c[1], c[2] end
	local meshes = util.GetModelMeshes(mdlPath)
	if not istable(meshes) or not meshes[1] then meshBoundsCache[mdlPath] = false return nil end
	local mn = Vector(math.huge, math.huge, math.huge)
	local mx = Vector(-math.huge, -math.huge, -math.huge)
	for _, m in ipairs(meshes) do
		for _, v in ipairs(m.triangles or {}) do
			local p = v.pos
			if p then
				if p.x < mn.x then mn.x = p.x end
				if p.y < mn.y then mn.y = p.y end
				if p.z < mn.z then mn.z = p.z end
				if p.x > mx.x then mx.x = p.x end
				if p.y > mx.y then mx.y = p.y end
				if p.z > mx.z then mx.z = p.z end
			end
		end
	end
	if mn.x == math.huge then meshBoundsCache[mdlPath] = false return nil end
	meshBoundsCache[mdlPath] = { mn, mx }
	return mn, mx
end

-- Os PORTEURS du mesh (indices), lus une fois dans les poids des sommets. Pour un
-- accessoire rigé (pet d'épaule), le mesh se rend LÀ OÙ SONT CES OS dans la pose de
-- la séquence — ni au centre de la boîte de rendu (boîte de séquence, décentrée),
-- ni aux bounds du mesh (pose de référence, ailleurs) : viser ces os est le seul
-- cadrage juste. nil si le modèle n'a pas de poids exploitables.
local meshBonesCache = {}
local function GetMeshBones(mdlPath)
	if not isstring(mdlPath) or mdlPath == "" then return nil end
	local c = meshBonesCache[mdlPath]
	if c == false then return nil end
	if c then return c end
	local meshes = util.GetModelMeshes(mdlPath)
	if not istable(meshes) or not meshes[1] then meshBonesCache[mdlPath] = false return nil end
	local set, out = {}, {}
	for _, m in ipairs(meshes) do
		for _, v in ipairs(m.triangles or {}) do
			for _, w in ipairs(v.weights or {}) do
				local b = tonumber(w.bone)
				if b and b >= 0 and (tonumber(w.weight) or 0) > 0.3 and not set[b] then
					set[b] = true
					out[#out + 1] = b
				end
			end
		end
	end
	if #out == 0 then meshBonesCache[mdlPath] = false return nil end
	meshBonesCache[mdlPath] = out
	return out
end

-- [DIAG] evo_item_bounds <item_id> : affiche en chat les bounds du modèle d'un item
-- (render vs mesh réels) pour diagnostiquer un cadrage de case qui semble vide.
concommand.Add("evo_item_bounds", function(_, _, args)
	local id = args and args[1] or ""
	local it = ITEMS and ITEMS[id]
	local mdlPath = (it and it.model_path) or id
	if not isstring(mdlPath) or mdlPath == "" then
		MsgC(Color(255, 120, 120), "[preview] item/modèle introuvable : " .. tostring(id), "\n") return
	end
	local ent = ClientsideModel(mdlPath, RENDERGROUP_OTHER)
	if not IsValid(ent) then MsgC(Color(255, 120, 120), "[preview] ClientsideModel FAIL : " .. mdlPath, "\n") return end
	local rmn, rmx = ent:GetModelRenderBounds()
	local mmn, mmx = GetMeshBounds(mdlPath)
	MsgC(Color(120, 200, 255), string.format("[preview] %s\nrender: %s -> %s\nmesh:   %s -> %s",
		id, tostring(rmn), tostring(rmx), tostring(mmn), tostring(mmx)))
	-- Bodygroups : si la VALEUR 0 d'un groupe est un sous-modèle VIDE, l'item de rareté
	-- common (bodygroup = 0) ne rend RIEN -> "invisible" quel que soit le zoom.
	for _, bg in ipairs(ent:GetBodyGroups() or {}) do
		MsgC(Color(180, 180, 190), string.format("  bodygroup #%d '%s' : %d valeurs", bg.id or -1, bg.name or "?", bg.num or 0), "\n")
	end
	MsgC(Color(180, 180, 190), "  skins : " .. tostring(ent:SkinCount()), "\n")
	ent:Remove()
end)

--- parent: DPanel in a slot; it: ITEMS entry; fov: bag slots ~30, compact slots ~25, small UI ~32
--- marginOverride: optional camera distance multiplier override (lower = more zoom).
---   Use this when the default per-category margin is too unzoomed for a specific
---   context (eg. shop cards need accessories bigger than inventory slots).
--- slotInset: optional design-pixel inset from the slot edges (keeps slot borders visible).
--- forceHighestLOD: optional, kept for callers; previews always lock LOD 0 (see applyVariant).
function LZY_INVENTORY_ITEM_PREVIEW._DoSetupModelPanel(parent, it, fov, marginOverride, slotInset, forceHighestLOD)
	parent._previewLoading = nil
	parent.Paint = function() end
	local mdl = vgui.Create("DModelPanel", parent)
	mdl:Dock(FILL)
	local inset = tonumber(slotInset) or 0
	if inset > 0 then
		local ix = (gRespX and gRespX(inset)) or inset
		local iy = (gRespY and gRespY(inset)) or inset
		mdl:DockMargin(ix, iy, ix, iy)
	end
	mdl:SetModel(it.model_path)
	-- Apply the rarity / color variant. evo_loot's chest convention uses `bodygroup = N`
	-- but actually applies it as a SKIN (see citron equipment chest). We mirror
	-- that: apply on BOTH skin and bodygroup 0 so the model's variant system
	-- (whichever it uses) gets the right value. Table form is also supported
	-- for multi-group models: `bodygroup = { [groupId] = value, ... }`.
	local function applyVariant(ent)
		if not IsValid(ent) then return end
		-- LOD 0 toujours : les meshes LOD des modèles evo droppent souvent les
		-- familles $texturegroup, donc une case inventaire (caméra un peu loin)
		-- affichait le skin 0 pour toutes les variantes de couleur. Boutique
		-- forçait déjà LOD 0 via forceHighestLOD ; l'inventaire non.
		ent:SetLOD(0)
		if it.skin ~= nil then
			ent:SetSkin(tonumber(it.skin) or 0)
		end
		if it.bodygroup ~= nil then
			if istable(it.bodygroup) then
				for groupId, value in pairs(it.bodygroup) do
					local nId = tonumber(groupId) or ent:FindBodygroupByName(tostring(groupId)) -- clé = index ou NOM
					if nId >= 0 then ent:SetBodygroup(nId, tonumber(value) or 0) end
				end
			else
				local n = tonumber(it.bodygroup) or 0
				ent:SetBodygroup(0, n)
				ent:SetSkin(n)
			end
		elseif it.skin == nil then
			-- ⚠ ARMES EXCEPTÉES. Sur un katana (skin_id) ou un gantelet Hakuda (gauntlet_id),
			-- la 2e famille de skins n'est PAS une variante de rareté : c'est le SHIKAI
			-- ($texturegroup "skinfamilies", 0 = normal, 1 = shikai — cf. le rendu dans
			-- citron_combat_weapons/cl_init et cl_hakuda_gauntlet). La rareté « rare » vaut
			-- justement le palier 1 : toutes les lames rares s'affichaient donc LIBÉRÉES en
			-- boutique, au marché noir et en case, au lieu de leur couleur de base.
			if it.skin_id ~= nil or it.gauntlet_id ~= nil then
				-- Katana sans `skin` copié (ordre de génération) : MÊME résolution que l'arme
				-- portée (cl_init / fourreau) = famille 1 pour une variante « _shikai », 0 sinon.
				if it.skin_id ~= nil and KATANA_SKINS and KATANA_SKINS.GetBaseSkinByID then
					ent:SetSkin(KATANA_SKINS.GetBaseSkinByID(it.skin_id))
				end
				return
			end
			-- Accessoires : $texturegroup = famille de COULEUR (chapeaux Urahara, masques
			-- d'anonymat, écharpes…). Sans `skin` explicite le palier de rareté était
			-- poussé comme numéro de skin — un chapeau légendaire s'affichait en teinte
			-- « 3 » (rouge) au lieu du groupe 0. Le monde, lui, fait `tonumber(it.skin) or 0`.
			if it.category == "accessory" then return end
			-- Tenues : $texturegroup = couleur de PEAU, pas de rareté. Aligner sur le
			-- rendu porté (shop cosmetic_preview fait la même chose).
			if it.category == "outfit" then
				local lp = LocalPlayer()
				ent:SetSkin((IsValid(lp) and lp.GetSkin and lp:GetSkin()) or 0)
				return
			end
			-- Autre modèle à skins de COULEUR (variantes explicites sur d'autres items) : skin 0,
			-- comme le rendu en jeu (cl_models : it.skin or 0). Cf. ModelUsesColorSkins.
			-- APRÈS accessory/outfit : une tenue à skins couleur garde sa teinte de peau.
			if ModelUsesColorSkins(it.model_path) then return end
			-- Objets sans variante explicite (parchemins ont déjà `skin`) : variante de
			-- RARETÉ (0 commun … 4 mythique), en skin ET bodygroup 0 (no-op pour celui qui
			-- n'existe pas). Pour outrepasser : poser un bodygroup/skin explicite sur l'item.
			local tier = RARITY_BODYGROUP_TIER[isstring(it.rarity) and string.lower(it.rarity) or ""]
			if tier then
				ent:SetSkin(tier)
				ent:SetBodygroup(0, tier)
			end
		end
	end
	applyVariant(mdl:GetEntity())
	local isHeadAccessory = LZY_INVENTORY_ITEM_PREVIEW.ItemIsHeadAccessory(it)
	-- Bracelets (slot "belt") ET bagues (slot "ring") : cadrage dédié — plein centre +
	-- fit + vue 3/4 (réglages itérés avec le user). Les réglages "collier" (top-down 89°,
	-- margin 0.2, focus haut de bbox) sortaient ces modèles du cadre -> invisibles en case.
	local slotL = it and it.category == "accessory" and isstring(it.slot) and string.lower(it.slot) or ""
	local isBelt = (slotL == "belt")
	local isRing = (slotL == "ring") -- bagues : PLEIN CENTRE de la case + zoom (pas de décalage)
	local isEquipAcc = isBelt or isRing
	local fovDeg = fov or 30
	if isHeadAccessory then
		fovDeg = fovDeg * 0.82
	end
	mdl:SetFOV(fovDeg)
	mdl:SetAnimated(false)
	mdl:SetMouseInputEnabled(false)
	-- LOD 0 forcé AU MOMENT du draw (recette boutique cosmetic_preview) : le SetLOD posé
	-- dans LayoutEntity ne tenait pas toujours dans une case (caméra loin) et la famille
	-- de textures d'une variante retombait sur un mesh LOD sans $texturegroup.
	mdl.PreDrawModel = function(_, ent)
		if IsValid(ent) then ent:SetLOD(0) end
	end
	mdl.LayoutEntity = function(pnl, ent)
		if not IsValid(ent) then return end
		-- Os POSÉS avant le 1er cadrage (09/08) : les branches os (tête, bague, pets) lisent
		-- GetBoneMatrix ; avant le 1er DrawModel les matrices peuvent exister sans être posées
		-- (à l'origine) -> cadrage faux, et pour les pets FIGÉ sur le vide.
		if not pnl._bonesReady then
			pnl._bonesReady = true
			ent:SetupBones()
		end
		-- Re-apply the rarity variant each layout in case GetEntity() returned nil
		-- in SetupModelPanel (model loads async). SetSkin/SetBodygroup are idempotent.
		applyVariant(ent)
		-- Accessories stay static; other items keep the slow yaw rotation.
		if it and it.category == "accessory" then
			if isRing then
				-- Bagues : VUE DE FACE — (0,0,0) = orientation native du modèle. Si l'anneau
				-- apparaît par la tranche, ajuster le yaw/pitch ici (degrés).
				ent:SetAngles(Angle(0, 0, 0))
			elseif isEquipAcc then
				-- Bracelets : ROTATION DU MODÈLE dans la case, en degrés (pitch, yaw, roll).
				-- ← ajuste le yaw (2e valeur) pour le faire pivoter sur lui-même.
				ent:SetAngles(Angle(-20, 130, 0))
			elseif it.preview_bone_focus then
				-- Pets d'épaule : PAS de bascule (le mesh est loin de l'origine, un pitch
				-- le ferait tourner autour des pieds du squelette). preview_angles = override.
				ent:SetAngles(it.preview_angles or Angle(0, 0, 0))
			else
				ent:SetAngles(Angle(-30, 40, 0))
			end
		elseif it and it.preview_static then
			-- Opt-in par ITEM (ex. livres evo_livre) ou copie StaticItem (aperçus
			-- FIGÉS : slot consommable rapide, radial, atelier assassin) : pas de
			-- turntable. preview_angles (Angle) pour choisir l'orientation.
			ent:SetAngles(it.preview_angles or Angle(0, 0, 0))
		else
			ent:SetAngles(Angle(0, CurTime() * 30 % 360, 0))
		end

		local mn, mx = ent:GetModelRenderBounds()
		if not mn or not mx then return end
		-- BAGUES : bounds RÉELS du mesh (cf. GetMeshBounds) — GetModelRenderBounds renvoie
		-- une boîte de séquence énorme sur ces modèles rigés -> l'anneau paraissait un point
		-- perdu dans la case. (Bracelets non touchés : leur cadrage est déjà réglé.)
		if isRing then
			local m1, m2 = GetMeshBounds(it.model_path)
			if m1 then mn, mx = m1, m2 end
		end

		local dx = math.abs(mx.x - mn.x)
		local dy = math.abs(mx.y - mn.y)
		local dz = math.abs(mx.z - mn.z)
		local maxDim = math.max(dx, dy, dz, 1)

		local center = (mn + mx) * 0.5
		local half = maxDim * 0.5
		local focus = center
		-- Non-accessoires : le modèle tourne sur lui-même autour de l'axe vertical.
		-- GetModelRenderBounds est en espace LOCAL, d'où deux corrections :
		--  (1) Centrage : si le mesh est décentré par rapport à l'origine du modèle
		--      (ex. une arme dont le manche est à l'origine), viser le centre local
		--      fait dériver l'item sur le côté pendant la rotation. On tourne donc le
		--      focus par les angles de l'entité pour viser le vrai centre en monde.
		--  (2) Cadrage : on cadre sur le "cylindre" balayé par la rotation (rayon
		--      horizontal = diagonale XY, demi-hauteur = Z) au lieu du plus grand axe
		--      seul -> cadrage CONSTANT d'un modèle à l'autre et jamais rogné quel que
		--      soit l'angle (les objets larges/plats ne sont plus coupés en tournant).
		if not (it and it.category == "accessory") then
			focus = Vector(center.x, center.y, center.z)
			focus:Rotate(ent:GetAngles())
			local halfX, halfY, halfZ = dx * 0.5, dy * 0.5, dz * 0.5
			local horizR = math.sqrt(halfX * halfX + halfY * halfY)
			half = math.max(horizR, halfZ, 1)
			-- Décalage vertical PAR ITEM (fraction de la hauteur du modèle) :
			-- monter le focus fait apparaître le modèle PLUS BAS dans la case
			-- (ex. livres evo_livre, preview_focus_up = 0.35).
			if tonumber(it and it.preview_focus_up) then
				focus.z = focus.z + dz * tonumber(it.preview_focus_up)
			end
		end
		-- margin = camera-distance multiplier vs perfect fit. <1 zooms in (crops),
		-- >1 zooms out (padding). Per-item override via `it.model_margin`. Accessories
		-- (necklace/ring/belt) zoom in aggressively because their models are small.
		local margin
		if tonumber(marginOverride) then
			margin = tonumber(marginOverride)
		elseif tonumber(it and it.model_margin) then
			margin = tonumber(it.model_margin)
		elseif isRing then
			-- ⚠ Une bague = un ANNEAU : trop zoomer vise le TROU du tore et pousse le bord
			-- hors cadre ("un bout en bas à gauche"). 0.7 = anneau entier garanti visible ;
			-- on resserre ensuite par petits pas si besoin.
			margin = 0.7   -- ← bagues : ↓ pour zoomer encore, ↑ pour dézoomer
		elseif isBelt then
			margin = 0.16  -- ← bracelets : ↓ pour zoomer encore, ↑ pour dézoomer
		elseif it and it.category == "accessory" then
			margin = 0.2   -- ← distance caméra : ↑ pour voir + de l'item (unzoom), ↓ pour zoomer
			              --   bbox model est calculé sur les axes locaux → si le collier est
			              --   long horizontalement il faut + de margin pour qu'il rentre en entier
		else
			margin = 1.38
		end

		-- Vertical framing : raising focus.z makes the model appear LOWER in the slot
		-- (camera tilts up). Accessories' bbox-center sits a bit high → push focus up.
		-- Note: GetModelRenderBounds() is LOCAL space. When SetAngles is non-zero,
		-- we must rotate the local focus point through the same angles so the camera
		-- actually looks at where the visible mesh ends up in world space (otherwise
		-- modifying pitch/roll makes the model fly out of view).
		if it and it.category == "accessory" and not isHeadAccessory then
			local ringBoneFocus = false
			if isRing then
				-- BAGUE riggée sur l'os du DOIGT (ValveBiped.Bip01_R_Finger2, info user) :
				-- le mesh est à la position de l'os (pose de référence), PAS au centre des
				-- bounds -> on vise L'OS directement, comme les accessoires de tête avec
				-- Bip01_Head1. half FIXE = demi-taille d'une bague (le zoom devient stable).
				local b = ent:LookupBone("ValveBiped.Bip01_R_Finger2")
				if b and b >= 0 then
					local mat = ent:GetBoneMatrix(b)
					local bp = mat and mat:GetTranslation() or select(1, ent:GetBonePosition(b))
					if isvector(bp) then
						focus = bp -- GetBoneMatrix est déjà en espace "monde" du panel (pas de Rotate)
						half = 4.0 -- ← demi-taille cadrée (unités) : ↓ zoome (bague + grosse), ↑ dézoome (+ petite)
						ringBoneFocus = true
					end
				end
			end
			-- preview_bone_focus (opt-in, pets d'épaule 08/27) : viser la MOYENNE des os
			-- porteurs du mesh dans la pose rendue, taille = bounds réels du mesh × 0,75
			-- (le mesh dépasse de l'os d'à peu près sa propre taille). Figé sur le panel
			-- dès le premier calcul réussi (bones prêts après le premier rendu).
			if not ringBoneFocus and it and it.preview_bone_focus then
				if pnl._boneFocusV then
					focus, half = pnl._boneFocusV, pnl._boneFocusHalf
					ringBoneFocus = true
				else
					local tBones = GetMeshBones(it.model_path)
					if tBones then
						local vSum, nB = Vector(0, 0, 0), 0
						for _, b in ipairs(tBones) do
							local mat = ent:GetBoneMatrix(b)
							if mat then vSum = vSum + mat:GetTranslation() nB = nB + 1 end
						end
						if nB > 0 then
							local m1, m2 = GetMeshBounds(it.model_path)
							local nSize = m1 and math.max(m2.x - m1.x, m2.y - m1.y, m2.z - m1.z) or maxDim
							local vFocus = vSum / nB
							focus, half = vFocus, math.max(nSize * 0.75, 2)
							ringBoneFocus = true
							-- Ne FIGER qu'un résultat non nul : des matrices pas encore posées donnent
							-- l'origine, et un cadrage figé là reste vide pour toute la vie du panneau.
							if vFocus:LengthSqr() > 1 then
								pnl._boneFocusV, pnl._boneFocusHalf = vFocus, half
							end
						end
					end
				end
			end
			if not ringBoneFocus then
				if isEquipAcc then
					-- Bracelet (ou bague sans os trouvé) : viser le PLEIN CENTRE de la bbox.
					focus = Vector(center.x, center.y, center.z)
				else
					focus = Vector(center.x, center.y, mn.z + dz * 0.75)
				end
				focus:Rotate(ent:GetAngles())
			end
		end

		if isHeadAccessory then
			-- Si l'appelant a fourni un marginOverride explicite, on le
			-- respecte (sinon la branche head-accessory ecrasait l'override
			-- en forcant 1.10 -> les masques/lunettes/cache-oeil restaient
			-- petits dans les cases shop malgre l'override).
			if not tonumber(marginOverride) then
				margin = 1.10
			end
			local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
			if headBone and headBone >= 0 then
				local mat = ent:GetBoneMatrix(headBone)
				if mat then
					focus = mat:GetTranslation()
				else
					local bp = select(1, ent:GetBonePosition(headBone))
					if isvector(bp) then focus = bp end
				end
				half = math.max(half * 0.42, 3)
			else
				-- Standalone accessory : centre bbox + rotation par les angles
				-- de l'entite (sinon le focus est en coords LOCALES mais le mesh
				-- est rendu en coords MONDE rotated -> camera regarde a cote).
				focus = Vector(center.x, center.y, center.z)
				focus:Rotate(ent:GetAngles())
				half  = math.max(maxDim * 0.5, 2)
			end
		end

		-- Décalage vertical PAR ITEM (`model_lift`, fraction de la taille du modèle) :
		-- POSITIF = le modèle apparaît PLUS HAUT dans la case (on ABAISSE le focus, cf.
		-- note "Vertical framing" plus haut). Ex. papier evo_note, légèrement trop bas.
		local lift = tonumber(it and it.model_lift) or 0
		if lift ~= 0 then focus.z = focus.z - lift * maxDim end

		local tanHalf = math.tan(math.rad(fovDeg * 0.5))
		if tanHalf < 1e-4 then tanHalf = 1e-4 end
		local dist = (half / tanHalf) * margin
		-- Accessories are small (necklaces ≈ 1-3 units) — lower the minimum so the
		-- tight margin actually takes effect instead of being clamped to 6.
		local distMin = (it and it.category == "accessory") and 0.5 or 6
		dist = math.Clamp(dist, distMin, 320)

		-- Caméra trop PROCHE (modèles minuscules type BAGUE : dist calculée ~1u) = la
		-- caméra passe sous le plan de clipping (znear) du DModelPanel -> modèle INVISIBLE
		-- dans la case quel que soit le cadrage. Fix générique : on RECULE la caméra à une
		-- distance sûre et on compense le zoom par le FOV (équivalence optique stricte :
		-- dist × tan(fov/2) constant) -> même taille à l'écran, plus jamais clippé.
		local SAFE_DIST = 6
		if dist < SAFE_DIST then
			local newTan = tanHalf * (dist / SAFE_DIST)
			pnl:SetFOV(math.max(math.deg(math.atan(newTan)) * 2, 0.5))
			dist = SAFE_DIST
		else
			pnl:SetFOV(fovDeg)
		end

		-- Camera offset direction. For accessories, use an explicit elevation angle
		-- in degrees so it's intuitive : 0° = camera at model height (front view),
		-- 90° = camera straight overhead. yaw = horizontal angle around the model.
		-- Bumping elev past 90 doesn't do anything (vertical is the cap).
		local dir
		if it and it.category == "accessory" and not isHeadAccessory then
			-- elevDeg : 0=devant, 90=pile au-dessus, 180=derrière à même hauteur, 270=pile en dessous.
			-- yawDeg  : angle horizontal autour du modèle (0=face avant, 90=côté droit, etc.).
			-- ← élévation : bagues vues quasi de FACE (15), bracelets en 3/4 (35), colliers top-down (89).
			-- Pets d'épaule (preview_bone_focus) : 3/4 face, un peu de haut — le 89° des
			-- colliers les montrait de DESSUS. preview_elev / preview_yaw = override par item.
			local elevDeg = isRing and 15 or (isEquipAcc and 35
				or ((it and it.preview_bone_focus) and (tonumber(it.preview_elev) or 18) or 89))
			local yawDeg  = (it and tonumber(it.preview_yaw)) or 40   -- ← angle horizontal autour du modèle.
			local er = math.rad(elevDeg)
			local yr = math.rad(yawDeg)
			dir = Vector(math.cos(er) * math.cos(yr), math.cos(er) * math.sin(yr), math.sin(er))
		else
			dir = Vector(0.72, 0.52, 0.45)
		end
		dir:Normalize()
		-- Screen-space framing offset : pour les accessoires, on translate la cam ET
		-- le LookAt du même vecteur en SCREEN-UP, ce qui shift l'item dans le slot
		-- sans changer l'angle de vue. Marche même quand elevDeg=89 (top-down pur).
		--   itemShift > 0 → l'item apparaît plus bas dans le slot
		--   itemShift < 0 → l'item apparaît plus haut
		local lookAt = focus
		local camPos = focus + dir * dist
		if it and it.category == "accessory" and not isHeadAccessory then
			-- ← shift VERTICAL écran : >0 = l'item apparaît PLUS BAS dans la case, <0 = plus haut.
			-- Bagues : AUCUN décalage (plein centre demandé) ; bracelets : réglage itéré.
			local itemShift = (isRing or (it and it.preview_bone_focus)) and 0 or (isBelt and (maxDim * 0.22) or 3)
			-- Compute screen-up vector (perpendicular to view direction). For non-vertical
			-- views, screen-up ≈ world +Z. For top-down views (dir ≈ ±Z) the cross product
			-- with world Y gives a stable horizontal axis as fallback.
			local worldUp = Vector(0, 0, 1)
			local right = dir:Cross(worldUp)
			if right:LengthSqr() < 1e-4 then right = dir:Cross(Vector(0, 1, 0)) end
			right:Normalize()
			local screenUp = right:Cross(dir)
			screenUp:Normalize()
			local shift = screenUp * itemShift
			-- ← shift HORIZONTAL écran : >0 = l'item part vers la GAUCHE de la case, <0 = vers
			-- la DROITE. Proportionnel à la taille du modèle (stable entre les 5 sets).
			local itemShiftX = isBelt and (-maxDim * 0.06) or 0
			-- PETS D'ÉPAULE (user 08/29 : « ils sont trop vers la gauche dans les cases »).
			-- La visée est l'ATTACHE (la moyenne des os qui portent le mesh, cf. plus haut),
			-- pas le centre du pet : un pet qui pend d'un côté de l'épaule paraît donc
			-- décalé. On le recentre en screen-space -- viser le centre du mesh exigerait
			-- de transformer les sommets dans la pose rendue, chemin déjà tenté et abandonné
			-- (pose de référence ≠ pose rendue, cf. evo_loot).
			-- ÉCHELLE = `half` (la taille du PET) et surtout pas maxDim : sur ces modèles
			-- rigés, maxDim est la boîte du SQUELETTE ENTIER (~72 u pour un pet de 12).
			-- Réglage : `preview_shift_left` sur l'item (fraction de la taille du pet),
			-- NÉGATIF = vers la DROITE de la case. Valeur commune posée dans PetItem.
			if it and it.preview_bone_focus then
				itemShiftX = (tonumber(it.preview_shift_left) or 0) * half
			end
			if itemShiftX ~= 0 then shift = shift - right * itemShiftX end
			lookAt = lookAt + shift
			camPos = camPos + shift
		end
		-- Décalage HORIZONTAL écran PAR ITEM (`preview_shift_left`, fraction de la
		-- taille du modèle, >0 = l'item part vers la GAUCHE de la case) : même
		-- mécanique screen-space que les accessoires (ex. livres evo_livre).
		local shiftLeft = tonumber(it and it.preview_shift_left) or 0
		if shiftLeft ~= 0 and not (it and it.category == "accessory") then
			local worldUp = Vector(0, 0, 1)
			local right = dir:Cross(worldUp)
			if right:LengthSqr() < 1e-4 then right = dir:Cross(Vector(0, 1, 0)) end
			right:Normalize()
			local shift = right * (-shiftLeft * maxDim)
			lookAt = lookAt + shift
			camPos = camPos + shift
		end
		pnl:SetLookAt(lookAt)
		pnl:SetCamPos(camPos)
	end
	parent._modelPanel = mdl
end

-- Copie d'item FIGÉE (opt-in preview_static PAR PANNEAU, sans toucher l'entrée
-- ITEMS partagée) : aperçus sans turntable, vue de trois quarts par défaut.
-- Consommé par l'atelier assassin, le slot consommable rapide et son radial.
function LZY_INVENTORY_ITEM_PREVIEW.StaticItem(it, aAngles)
	if not it then return nil end
	local t = table.Copy(it)
	t.preview_static = true
	t.preview_angles = aAngles or t.preview_angles or Angle(0, 40, 0)
	return t
end

function LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(parent, it, fov, marginOverride, slotInset, forceHighestLOD, onReady)
	if not IsValid(parent) or not it then return end
	-- Fourreau : même repère qu'un katana -> même aperçu (3/4 en rotation), pas le cadrage
	-- serré vu de dessus des bijoux. Copie : l'entrée ITEMS partagée reste un accessoire.
	if (it.fourreau_cosmetic or it.compagnon_id) and it.category == "accessory" then -- compagnon : idem
		it = table.Copy(it)
		it.category = "object"
	end
	PreviewEnqueueModelPanel(parent, it, fov, marginOverride, slotInset, forceHighestLOD, onReady)
end

-- ============================================================
-- PRÉCHARGEMENT AU DÉMARRAGE (demande user) : la 1ère ouverture d'un UI à cases
-- (inventaire/shop/trade/forge) payait le chargement DISQUE de chaque .mdl de case
-- -> file de spinners visible + hitchs. On précharge ici, ÉTALÉ sur les frames
-- (aucun freeze), tous les modèles d'items (ITEMS.model_path — katanas inclus,
-- générés depuis KATANA_SKINS dans config.lua avant ce warm-up) + les ICÔNES 2D
-- (Material(it.icon) était aussi chargé à la volée dans le Paint des cases).
-- All screens still queue precached paths: creating entities and uploading textures
-- is separate work, spread over frames by the shared loader.
-- Même intention que spell_system/sh_spell_model_precache.lua (freeze au 1er cast).
-- Démarre APRÈS le join (délai) pour ne pas concurrencer le chargement de la map.
-- ============================================================
local WARMUP_DELAY            = 10 -- secondes après InitPostEntity
local WARMUP_MODELS_PER_FRAME = 2
local WARMUP_ICONS_PER_FRAME  = 6

hook.Add("InitPostEntity", "LZY_Inventory_PreviewWarmup", function()
	timer.Simple(WARMUP_DELAY, function()
		if not istable(ITEMS) then return end
		local models, icons, seenM, seenI = {}, {}, {}, {}
		for _, it in pairs(ITEMS) do
			if istable(it) then
				local m = it.model_path
				if isstring(m) and m ~= "" and not seenM[m] and not previewWarmedPaths[m] then
					seenM[m] = true
					models[#models + 1] = m
				end
				-- Sans paramètre, comme les sites d'affichage (Paint des cases) : même clé de cache Material.
				local ic = it.icon
				if isstring(ic) and ic ~= "" and not seenI[ic] then
					seenI[ic] = true
					icons[#icons + 1] = ic
				end
			end
		end
		local mi, ii = 1, 1
		hook.Add("Think", "LZY_Inventory_PreviewWarmupTick", function()
			-- Avoid background precaching competing with the visible inventory queue.
			if previewLoadQueueRunning or IsValid(inventoryPreviewScope) then return end
			for _ = 1, WARMUP_MODELS_PER_FRAME do
				if mi > #models then break end
				local path = models[mi]
				mi = mi + 1
				-- ⚠ PrecacheModel SEULEMENT (retour 09/08 soir). La version « + matériaux »
				-- (ClientsideModel + Material() de chaque VMT, 1 modèle par image) chargeait
				-- toutes les textures de cosmétiques dès l'arrivée : 10 à 30 s de saccades
				-- après le spawn et VRAM saturée. Les textures se chargent au 1er affichage.
				util.PrecacheModel(path)
				previewWarmedPaths[path] = true
			end
			for _ = 1, WARMUP_ICONS_PER_FRAME do
				if ii > #icons then break end
				Material(icons[ii])
				ii = ii + 1
			end
			if mi > #models and ii > #icons then
				hook.Remove("Think", "LZY_Inventory_PreviewWarmupTick")
			end
		end)
	end)
end)
