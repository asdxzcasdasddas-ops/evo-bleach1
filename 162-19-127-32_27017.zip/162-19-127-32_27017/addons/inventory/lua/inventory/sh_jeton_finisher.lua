-- "addons\\inventory\\lua\\inventory\\sh_jeton_finisher.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Compensation des anciens finishers : un tirage garanti dans la rareté du jeton.
ITEMS = ITEMS or {}
EVO_FinisherToken = EVO_FinisherToken or {}
local T = EVO_FinisherToken

T.Rarities = {
	commun = { label = "Commun", item = "common", skin = 0 },
	rare = { label = "Rare", item = "rare", skin = 1 },
	epique = { label = "Épique", item = "epic", skin = 2 },
	legendary = { label = "Légendaire", item = "legendary", skin = 3 },
	mythique = { label = "Mythique", item = "mythic", skin = 4 },
}

function T.ItemId(rarity) return "jeton_finisher_" .. rarity end

-- IDs historiques conservés même si un ancien finisher disparaît du pool.
local LEGACY_RARITIES = {
	Commun = "commun", Commun2 = "commun", Rare = "rare", Rare2 = "rare",
	Epique = "epique", Epique2 = "epique", ["Légendaire"] = "legendary",
	["Légendaire2"] = "legendary", Mythique = "mythique", Mythique2 = "mythique",
}

function T.Rarity(winId)
	local want = string.lower(string.Trim(tostring(winId or "")))
	for id, rarity in pairs(LEGACY_RARITIES) do
		if string.lower(id) == want then return rarity end
	end
	for _, categories in pairs(REROLL_DROPS or {}) do
		for _, drop in ipairs(categories.style_execution or {}) do
			if string.lower(tostring(drop.win_id or "")) == want and T.Rarities[drop.rarity] then
				return drop.rarity
			end
		end
	end
end

local function Pool(faction, rarity, exclude)
	local cats = REROLL_DROPS and REROLL_DROPS[faction]
	local picks, seen = {}, {}
	for _, drop in ipairs(cats and cats.style_execution or {}) do
		if drop.rarity == rarity and drop.win_id and drop.win_id ~= ""
			and not drop.superadmin_only and not seen[drop.win_id] then
			seen[drop.win_id] = true
			picks[#picks + 1] = drop
		end
	end
	if #picks > 1 and exclude ~= "" then
		for i = #picks, 1, -1 do
			if picks[i].win_id == exclude then table.remove(picks, i) end
		end
	end
	return picks
end

if SERVER then
	util.AddNetworkString("EVO:FinisherToken:Answer")
	util.AddNetworkString("EVO:FinisherToken:Granted")
	local pending = {}
	local function Notify(ply, msg, error)
		if IsValid(ply) and MUGEN and MUGEN.Notify then
			MUGEN.Notify(ply, msg, error and NOTIFY_ERROR or NOTIFY_GENERIC, 6)
		end
	end
	local function Current(ply, request)
		return IsValid(ply) and tonumber(ply:GetUniqueID()) == request.cid
			and ply:GetEvoNWString("FactionName", "") == request.faction
			and ply:GetEvoNWString("EvoFinisher", "") == request.current
			and not ply.InCharacterMenu and not ply:GetEvoNWBool("InCharacterMenu", false)
			and not ply:GetEvoNWBool("EVO_IsLarva", false)
	end
	local function Grant(ply, request)
		if not Current(ply, request) or ply._finisherTokenBusy then return end
		if not (MYSQLOO_DB and MYSQLOO_DB.CreateTransaction and LZY_Inventory_WithSQLLock) then
			Notify(ply, "Jeton indisponible : base de données non connectée.", true)
			return
		end
		local picks = Pool(request.faction, request.rarity, request.current)
		if #picks == 0 then Notify(ply, "Aucun finisher de cette rareté dans ta faction.", true) return end
		local drop = picks[math.random(#picks)]
		local itemId = T.ItemId(request.rarity)
		ply._finisherTokenBusy = true
		LZY_Inventory_WithSQLLock(ply, request.cid, function(done)
			local inv = ply.inventory
			local rowId = inv.row_by_slot and tonumber(inv.row_by_slot[request.slot])
			if inv.items[request.slot] ~= itemId or not rowId then done(false) return end
			local tx = MYSQLOO_DB:CreateTransaction()
			-- Le débit et le finisher sont dans la même transaction : un échec SQL
			-- laisse le jeton et le pouvoir précédent intacts, même après un crash.
			local update = tx:Query(string.format([[
				UPDATE characters c JOIN inventory i ON i.character_id = c.unique_id
				SET c.style_execution = %s, i.quantity = i.quantity - 1
				WHERE c.unique_id = %d AND c.steamid64 = %s
				  AND COALESCE(c.style_execution, '') = %s
				  AND i.id = %d AND i.slot_id = %d AND i.item_id = %s AND i.quantity >= 1
				  AND EXISTS (SELECT 1 FROM lzy_faction_members f WHERE f.character_id = c.unique_id
				    AND f.steamid64 = c.steamid64 AND f.faction = %s)
			]], sql.SQLStr(drop.win_id), request.cid, sql.SQLStr(ply:SteamID64()),
				sql.SQLStr(request.current), rowId, request.slot, sql.SQLStr(itemId), sql.SQLStr(request.faction)))
			tx:Query(string.format("DELETE FROM inventory WHERE id = %d AND character_id = %d AND quantity = 0", rowId, request.cid))
			tx:Start(function(_, ok, err)
				if not ok then ErrorNoHalt("[FinisherToken] " .. tostring(err) .. "\n") end
				local granted = ok and (tonumber(update:affectedRows()) or 0) > 0
				done(granted, function(bag)
					local qty = INVENTORY_CONFIG.GetSlotQuantity(bag, request.slot)
					if qty > 1 then
						bag.quantities = bag.quantities or {}
						bag.quantities[request.slot] = qty > 2 and qty - 1 or nil
					else
						bag.items[request.slot] = false
						for _, key in ipairs({ "row_by_slot", "durability", "forge_levels", "accessory_offsets", "enchants", "instance_keys", "quantities" }) do
							if bag[key] then bag[key][request.slot] = nil end
						end
					end
					ply:SetEvoNWString("EvoFinisher", drop.win_id)
				end)
			end)
		end, function(ok)
			if IsValid(ply) then ply._finisherTokenBusy = nil end
			if not IsValid(ply) or tonumber(ply:GetUniqueID()) ~= request.cid then return end
			if not ok then
				Notify(ply, "Le jeton n'a pas pu être utilisé. Il est conservé, réessaie.", true)
				return
			end
			-- La révélation est envoyée uniquement après l'attribution SQL réussie.
			net.Start("EVO:FinisherToken:Granted")
				net.WriteString(tostring(drop.win_id))
				net.WriteString(request.rarity)
				net.WriteString(tostring(drop.icon or ""))
				net.WriteString(tostring(drop.name or drop.win_id))
				net.WriteUInt(request.cid, 32)
			net.Send(ply)
		end)
	end

	function T.Use(ply, rarity, slot)
		if not IsValid(ply) or ply._finisherTokenBusy or not T.Rarities[rarity] then return end
		local request = {
			cid = tonumber(ply:GetUniqueID()), faction = ply:GetEvoNWString("FactionName", ""),
			current = ply:GetEvoNWString("EvoFinisher", ""), rarity = rarity,
			slot = tonumber(slot), expires = CurTime() + 30,
		}
		if not request.cid or not request.slot or not Current(ply, request) then return end
		if request.current == "" then Grant(ply, request) return end
		if not ply.OpenYesNoPopup then Notify(ply, "Confirmation indisponible.", true) return end
		pending[ply] = request
		ply:OpenYesNoPopup("Tu as déjà un finisher.\nLe remplacer par un finisher " .. T.Rarities[rarity].label
			.. " tiré au hasard ?", "FinisherToken_Replace", {}, "FinisherToken_Cancel")
	end

	net.Receive("EVO:FinisherToken:Answer", function(_, ply)
		if not IsValid(ply) or not ply:RateLimit("finisher_token_answer", 0.4) then return end
		local accepted = net.ReadBool()
		local request = pending[ply]
		pending[ply] = nil
		if not accepted or not request then return end
		if CurTime() > request.expires or not Current(ply, request) then
			Notify(ply, "La confirmation a expiré ou ton personnage a changé. Réutilise le jeton.", true)
			return
		end
		Grant(ply, request)
	end)
	hook.Add("PlayerDisconnected", "EVO:FinisherToken:Pending", function(ply) pending[ply] = nil end)
else
	net.Receive("EVO:FinisherToken:Granted", function()
		local winId, rarity = net.ReadString(), net.ReadString()
		local icon, name = net.ReadString(), net.ReadString()
		local cid = net.ReadUInt(32)
		local ply = LocalPlayer()
		if not IsValid(ply) or tonumber(ply:GetUniqueID()) ~= cid then return end
		if EVO_TokenReward and EVO_TokenReward.ShowGranted then
			EVO_TokenReward.ShowGranted(winId, rarity, icon, name, "NOUVEAU FINISHER")
		end
	end)
	LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
	LZY_POPUP_CALLBACKS.FinisherToken_Replace = function()
		net.Start("EVO:FinisherToken:Answer") net.WriteBool(true) net.SendToServer()
	end
	LZY_POPUP_CALLBACKS.FinisherToken_Cancel = function()
		net.Start("EVO:FinisherToken:Answer") net.WriteBool(false) net.SendToServer()
	end
end

for rarity, config in pairs(T.Rarities) do
	local r = rarity
	ITEMS[T.ItemId(r)] = {
		name = "Jeton de Finisher (" .. config.label .. ")",
		description = "Compensation d'un ancien finisher. Donne un finisher " .. config.label
			.. " de ta faction, tiré au hasard. Reste sur ce personnage.",
		icon = "1bhn2d03mwm1/parchemin.png", icon_scale = 0.6,
		model_path = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl",
		skin = config.skin, category = "object", rarity = config.item,
		is_droppable = false, is_deletable = false, is_finisher_token = true,
		on_use = function(ply, slot) if SERVER then T.Use(ply, r, slot) end end,
	}
end
