-- "addons\\inventory\\lua\\inventory\\sh_parchemin_shikai.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- =====================================================================
-- Parchemin d'ÉVEIL DE LA LAME — Shikai (Shinigami) / Resurrección Partielle (Arrancar).
-- Modèle IDENTIQUE au Parchemin du Vizard et de Libération Spirituelle : la chaîne de
-- quêtes « prog_shikai » rend seulement ÉLIGIBLE (EVO_ShikaiEligible), et c'est CE
-- parchemin, remis par le staff, qui débloque réellement — les deux sont requis.
-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm.
-- =====================================================================

ITEMS = ITEMS or {}

ITEMS["parchemin_shikai"] = {
	-- name/description ne peuvent PAS être dynamiques (l'UI d'inventaire les teste en
	-- isstring) : libellé neutre couvrant les deux factions. Les NOTIFICATIONS, elles,
	-- utilisent le bon nom selon la faction.
	name        = "Parchemin d'Éveil de la Lame",
	description = "La première libération de ta lame : le Shikai pour un Shinigami, la Resurrección Partielle pour un Arrancar. Il faut d'abord avoir accompli l'épreuve du Zanpakuto. Choisis ensuite le nom et le passif de ta lame.",
	-- PNG parchemin générique = REPLI hors preview 3D.
	icon        = "1bhn2d03mwm1/parchemin.png",
	icon_scale  = 0.6,
	-- Rendu 3D dans la case (au lieu du PNG) : modèle parchemin commun, variante MYTHIQUE
	-- (skin 4), comme les parchemins Vizard / Libération Spirituelle.
	model_path  = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl",
	skin        = 4,
	category    = "object",
	rarity      = "mythic",
	-- Non échangeable / non jetable / non supprimable (sauf superadmin) -> pas de farm.
	is_droppable = false,
	is_deletable = false,
	is_shikai_scroll = true,
	on_use = function(ply)
		-- Déblocage + consommation strictement serveur.
		if not SERVER then return end
		if not IsValid(ply) then return end
		if not (EVO and isfunction(EVO.GrantShikaiUnlock)) then return end -- citron_combat_system absent

		-- Nom du pouvoir selon la faction (le libellé UI vient d'evo_shikai_ui).
		local sFaction = ply:GetEvoNWString("FactionName", "")
		local sNom = (sFaction == "Hollow") and "Resurrección Partielle" or "Shikai"

		-- LISTE BLANCHE de factions, et PAS une simple exclusion : une larve / un Vasto
		-- Lorde a FactionName == "Hollow" alors qu'il est encore en amont du parcours
		-- Arrancar, et une âme errante n'a rien à faire ici non plus.
		if sFaction ~= "Shinigami" and sFaction ~= "Hollow" then
			MUGEN.Notify(ply, "Ta nature ne te permet pas de libérer ta lame.", NOTIFY_ERROR, 4)
			return
		end
		if ply:GetEvoNWBool("EVO_IsLostSoul", false) or ply:GetEvoNWBool("EVO_IsLarva", false)
			or (EVO_LostSoul and EVO_LostSoul.IsLostSoul and EVO_LostSoul.IsLostSoul(ply)) then
			MUGEN.Notify(ply, "Ta nature ne te permet pas de libérer ta lame.", NOTIFY_ERROR, 4)
			return
		end

		-- Déjà maîtrisé : on ne consomme PAS le parchemin. Ce test doit rester AVANT
		-- l'éligibilité, sinon les joueurs déjà débloqués tomberaient sur le refus d'éligibilité.
		if ply:GetEvoNWBool("EVO_ShikaiUnlocked", false) then
			MUGEN.Notify(ply, "Tu maîtrises déjà ton " .. sNom .. ".", NOTIFY_ERROR, 4)
			return
		end

		-- 1er verrou : éligibilité (chaîne du Zanpakuto accomplie). Le parchemin vient
		-- EN PLUS de la quête -> sans elle, il ne fait rien et n'est pas consommé.
		if not (EVO.IsShikaiEligible and EVO.IsShikaiEligible(ply)) then
			MUGEN.Notify(ply, "Tu dois d'abord accomplir l'épreuve du Zanpakuto.", NOTIFY_ERROR, 5)
			return
		end

		-- 2e verrou franchi. Échec de persistance (pas de perso chargé) -> on ne consomme
		-- PAS : le parchemin est irremplaçable (remis par le staff).
		if not EVO.GrantShikaiUnlock(ply) then
			MUGEN.Notify(ply, "Impossible pour le moment, réessaie dans un instant.", NOTIFY_ERROR, 4)
			return
		end
		ply:RemoveItem("parchemin_shikai", function() end)
	end,
}
