-- "addons\\inventory\\lua\\inventory\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
INVENTORY_CONFIG = INVENTORY_CONFIG or {}

-- Capacité du sac. "JAMAIS PLEIN" : valeur très élevée — la grille UI s'étend et scrolle
-- pour contenir tous les items (cf. vgui/cl_main.lua : `rows` dynamique).
-- DOIT rester < DB_EQUIP_SLOT_BASE (1000) : l'encodage slot_id réserve 1000+ aux
-- équipements et 2000 au katana (cf. GetInventory). 990 = plafond sûr.
INVENTORY_CONFIG.MAX_BAG_SLOTS = 990

-- DB slot_id encoding (INTEGER): bag uses 1..MAX_BAG_SLOTS; equipment uses an offset range.
INVENTORY_CONFIG.DB_EQUIP_SLOT_BASE = 1000
INVENTORY_CONFIG.DB_KATANA_SLOT = 2000
-- UI equip column order: 1=head, 2=outfit, 3=cape, 4=necklace, 5=ring, 6=belt,
-- 7=masque (slot DÉDIÉ Arrancar, à côté du katana — see vgui/cl_main.lua EQUIP_SLOT_PLACEHOLDER)
INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT = 2
-- Slot d'équipement RÉSERVÉ aux masques d'Arrancar (demande user 07/23) : seul un masque
-- (IsMaskAccessory) peut y aller, et un masque ne peut aller QUE là (même logique que la
-- tenue sur OUTFIT_EQUIP_SLOT). Routage central dans GetAccessoryEquipSlot ci-dessous.
INVENTORY_CONFIG.MASK_EQUIP_SLOT = 7
-- Slot FOURREAU (09/30) : items `fourreau_cosmetic`, rendus par ncm_ranger_katana (jamais
-- comme accessoire). Vide ou œil fermé = sans fourreau (ancien katana rangé).
INVENTORY_CONFIG.FOURREAU_EQUIP_SLOT = 8
-- Slot COMPAGNON (10/06) : items `compagnon_id`, animal qui SUIT le joueur au sol (evo_compagnons,
-- jamais rendu comme accessoire). Vide ou œil fermé = pas de compagnon.
INVENTORY_CONFIG.COMPAGNON_EQUIP_SLOT = 9
-- Borne haute des slots d'équipement "gear" (accessoires + tenue + masque + fourreau + compagnon, hors katana).
INVENTORY_CONFIG.MAX_GEAR_SLOT = 9
-- Slot string du masque de base Arrancar (rank cosmetic lzy_character, hors inventaire 1–7).
-- Éditable via le même éditeur d'offset que les accessoires équipés.
INVENTORY_CONFIG.MASQUE_BASE_SLOT = "masque_base"

function INVENTORY_CONFIG.IsMasqueBaseSlot(slot)
	return tostring(slot) == (INVENTORY_CONFIG.MASQUE_BASE_SLOT or "masque_base")
end

-- Slot string de l'accessoire body de DIVISION (rank cosmetic lzy_character, posé
-- d'office). Éditable via le même éditeur d'offset que le masque de base.
INVENTORY_CONFIG.DIVISION_BODY_SLOT = "division_body"

function INVENTORY_CONFIG.IsDivisionBodySlot(slot)
	return tostring(slot) == (INVENTORY_CONFIG.DIVISION_BODY_SLOT or "division_body")
end

-- Slot string de l'ÉPAULETTE DE GRADE (rank cosmetic lzy_character, posée d'office
-- par faction+rang). "grade" = la clé DÉJÀ portée par la pièce au rendu
-- (_lzyAccessorySlot, cl_models + char-select) : l'offset s'applique donc partout
-- sans toucher aux chemins de rendu. Même éditeur que division_body.
INVENTORY_CONFIG.GRADE_SLOT = "grade"

function INVENTORY_CONFIG.IsGradeSlot(slot)
	return tostring(slot) == (INVENTORY_CONFIG.GRADE_SLOT or "grade")
end

-- Autres cosmétiques de GRADE (hors inventaire), même éditeur que l'épaulette.
-- L'offset vit dans characters.rank_offsets (JSON { slot = offset }), pas une
-- colonne par pièce. La clé = le slot déjà porté au rendu (_lzyAccessorySlot).
-- La valeur est le libellé du menu d'édition.
INVENTORY_CONFIG.RANK_OFFSET_SLOT = {
	brassard = "Brassard",
	haori = "Haori",
	espada = "Tenue d'Espada",
	cape_roi = "Cape",
}

function INVENTORY_CONFIG.IsRankOffsetSlot(slot)
	return INVENTORY_CONFIG.RANK_OFFSET_SLOT[tostring(slot or "")] ~= nil
end

--- Modèle porté pour ce slot de grade, ou nil. ply = joueur (NW faction/rang/division).
function INVENTORY_CONFIG.ResolveRankCosmeticModel(ply, slot)
	if not (IsValid(ply) and ply.GetEvoNWString) then return nil end
	local cfg = LZY_CHARACTER_CONFIG
	if not cfg then return nil end
	local faction = ply:GetEvoNWString("FactionName", "")
	local rank = ply:GetEvoNWInt("FactionRank", 0)
	local division = ply:GetEvoNWInt("FactionDivision", 0)
	slot = tostring(slot or "")
	local mdl
	if slot == "brassard" and cfg.GetRankBrassard then
		mdl = cfg.GetRankBrassard(faction, rank, division)
	elseif slot == "haori" and cfg.GetRankHaori then
		mdl = cfg.GetRankHaori(faction, rank, division)
	elseif slot == "espada" and cfg.GetRankEspadaBody then
		mdl = cfg.GetRankEspadaBody(faction, rank, division)
	elseif slot == "cape_roi" and cfg.GetRankHollowKingCape then
		mdl = cfg.GetRankHollowKingCape(faction, rank)
	end
	return (isstring(mdl) and mdl ~= "") and mdl or nil
end

--- La pièce est masquée par une coche inventaire : l'éditeur n'aurait rien à montrer.
--- Le brassard n'a pas de coche. La tenue verrouillée reste visible (donc éditable).
function INVENTORY_CONFIG.IsRankCosmeticHidden(ply, slot)
	if not (IsValid(ply) and ply.GetEvoNWBool) then return true end
	slot = tostring(slot or "")
	if slot == (INVENTORY_CONFIG.GRADE_SLOT or "grade") then
		return ply:GetEvoNWBool("EVO_HideEpaulette", false)
	end
	if slot == "brassard" then return false end
	if not INVENTORY_CONFIG.IsRankOffsetSlot(slot) then return false end
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.IsRankOutfitLocked
		and LZY_CHARACTER_CONFIG.IsRankOutfitLocked(ply) then
		return false
	end
	return ply:GetEvoNWBool("EVO_HideRankOutfit", false)
end

-- `ITEMS[id].slot` for category "accessory" → equip slot index (2 is outfit-only)
INVENTORY_CONFIG.ACCESSORY_SLOT_BY_NAME = {
	head = 1,
	cape = 3,
	necklace = 4,
	ring = 5,
	belt = 6,
	mask = 7,
	fourreau = 8,
	compagnon = 9,
}

function INVENTORY_CONFIG.GetAccessoryEquipSlot(itemData)
	if not itemData or itemData.category ~= "accessory" then return nil end
	-- MASQUES : routés vers le slot dédié QUEL QUE SOIT leur champ `slot` déclaré (les
	-- arr_mask_* historiques portent slot="head") -> chokepoint unique, l'UI (DoEquipAccessory)
	-- et la validation serveur (EquipItem, sid ~= accWant) suivent sans autre changement.
	-- (Même convention de chemin que IsMaskAccessory — ici on a déjà l'itemData en main.)
	if isstring(itemData.model_path) and string.find(string.lower(itemData.model_path), "/arr_mask/", 1, true) then
		return INVENTORY_CONFIG.MASK_EQUIP_SLOT or 7
	end
	if not isstring(itemData.slot) or itemData.slot == "" then return nil end
	local n = INVENTORY_CONFIG.ACCESSORY_SLOT_BY_NAME[itemData.slot]
	return tonumber(n)
end

-- Cases ou un accessoire COSMETIQUE peut aussi se porter, en plus de la sienne (suggestion
-- du joueur Katana, 19/10/2026 : le brin de riz pose dans la case cape pour garder un
-- chapeau sur la tete). Le rendu ne depend pas de la case : le modele est bonemerge, il se
-- place tout seul la ou il a ete modele. Hors liste : le masque (anonymat, masque de base),
-- le fourreau et le compagnon, que leurs addons lisent dans LEUR case.
INVENTORY_CONFIG.ACCESSORY_FREE_SLOTS = { [1] = true, [3] = true, [4] = true, [5] = true, [6] = true }

-- L'accessoire peut-il etre equipe dans la case `sid` ? Sa propre case, toujours. Une autre
-- case de la liste, seulement s'il ne touche pas aux stats : un bijou a stats ou a bonus de
-- set reste chez lui, sinon on en porterait deux du meme type (deux colliers).
-- Partage : gate SERVEUR (EquipItem) + glisser-deposer et menu clic droit de l'inventaire.
function INVENTORY_CONFIG.CanAccessoryUseSlot(item_id, sid)
	local it = ITEMS and ITEMS[item_id]
	if not istable(it) or it.category ~= "accessory" then return false end
	local own = INVENTORY_CONFIG.GetAccessoryEquipSlot(it)
	sid = tonumber(sid)
	if not own or not sid then return false end
	if sid == own then return true end
	local free = INVENTORY_CONFIG.ACCESSORY_FREE_SLOTS
	if not (free[sid] and free[own]) then return false end
	if it.fourreau_cosmetic or it.compagnon_id then return false end
	return not INVENTORY_CONFIG.ItemAffectsStats(item_id)
end

--- JSON accessory_offset -> décalage corps (droite / avant / haut, relatif au yaw du joueur).
function INVENTORY_CONFIG.AccessoryOffsetToBodyLocal(off)
	if not istable(off) then return Vector() end
	return Vector(tonumber(off.px) or 0, tonumber(off.py) or 0, tonumber(off.pz) or 0)
end

--- Rotation locale corps (pitch / yaw / roll autour des axes droite / avant / haut).
function INVENTORY_CONFIG.AccessoryOffsetToBodyLocalAngle(off)
	if not istable(off) then return Angle() end
	return Angle(tonumber(off.ap) or 0, tonumber(off.ay) or 0, tonumber(off.ar) or 0)
end

function INVENTORY_CONFIG.AccessoryOffsetToVectorAngle(off)
	return INVENTORY_CONFIG.AccessoryOffsetToBodyLocal(off), INVENTORY_CONFIG.AccessoryOffsetToBodyLocalAngle(off)
end

--- Échelle uniforme de l'accessoire (1 = taille d'origine). Absent / invalide -> 1.
function INVENTORY_CONFIG.AccessoryOffsetToScale(off)
	if not istable(off) then return 1 end
	local s = tonumber(off.s)
	if not s then return 1 end
	return s
end

function INVENTORY_CONFIG.AccessoryOffsetPack(pos, ang, scale)
	pos = pos or vector_origin
	ang = ang or angle_zero
	scale = tonumber(scale)
	if not scale then scale = 1 end
	return {
		px = math.Round(pos.x, 3),
		py = math.Round(pos.y, 3),
		pz = math.Round(pos.z, 3),
		ap = math.Round(ang.p, 2),
		ay = math.Round(ang.y, 2),
		ar = math.Round(ang.r, 2),
		s = math.Round(scale, 3),
	}
end

function INVENTORY_CONFIG.AccessoryOffsetNeedsManualAttach(off)
	return not INVENTORY_CONFIG.AccessoryOffsetIsZero(off)
end

function INVENTORY_CONFIG.AccessoryOffsetIsDefault(off)
	return INVENTORY_CONFIG.AccessoryOffsetIsZero(off)
end

function INVENTORY_CONFIG.AccessoryOffsetIsZero(off)
	if not istable(off) then return true end
	if INVENTORY_CONFIG.AccessoryOffsetToBodyLocal(off):LengthSqr() > 0.0001 then return false end
	local a = INVENTORY_CONFIG.AccessoryOffsetToBodyLocalAngle(off)
	if a.p * a.p + a.y * a.y + a.r * a.r >= 0.0001 then return false end
	local s = INVENTORY_CONFIG.AccessoryOffsetToScale(off)
	return math.abs(s - 1) < 0.001
end

--- Limites éditeur d'offset accessoire (caméra client + validation serveur des offsets).
-- px/py/pz = droite / avant / haut (unités corps). ap/ay/ar = pitch / yaw / roll (degrés).
-- s = échelle uniforme (1 = taille d'origine).
INVENTORY_CONFIG.ACCESSORY_EDITOR = {
	-- Bornes de déplacement à l'échelle 1 (+50% le 10/14 : ±5.2 -> ±7.8).
	-- ClampAccessoryOffsetPos les élargit avec l'échelle, côté client et serveur.
	-- Ces bornes servent à TOUS les éditeurs : slots d'équipement (masque compris), masque de
	-- base, accessoire de division, épaulette de grade, haori / brassard / tenue Espada / cape.
	POS_MIN = { x = -7.8, y = -7.8, z = -7.8 },
	POS_MAX = { x = 7.8, y = 7.8, z = 7.8 },
	-- +20% de taille donne +40% de déplacement ; les petites pièces gardent la marge de base.
	POS_SCALE_GROWTH = 2,
	-- Rotation bornée ±10° par axe, UNIFORME pour TOUS les équipements, MASQUES COMPRIS.
	-- Historique ±4->±15 (07/22)->±45 (07/23)->±180 masques (07/23)->±5 partout (07/24,
	-- « rends tout plus strict, masque ou autre »)->±10 partout (10/01, limites x2). Tables
	-- (non nil) ACTIVE le clamp dans ClampAccessoryOffsetAng. Revalidé serveur au save (net.lua).
	ANG_MIN = { p = -10, y = -10, r = -10 },
	ANG_MAX = { p = 10, y = 10, r = 10 },
	-- (MASK_ANG_MIN/MAX RETIRÉS 07/24 : l'ancienne rotation libre ±180 des masques est supprimée —
	-- les masques suivent désormais les bornes standard ci-dessus, comme tout le reste.)
	-- Échelle : marge autour de 1 élargie de 50% le 10/14 (0.74 - 1.26 -> 0.61 - 1.39).
	-- Échelle uniforme bornée (revalidée serveur dans ClampAccessoryOffsetScale).
	SCALE_MIN = 0.61,
	SCALE_MAX = 1.39,
	CAM_DIST_MIN = 50,
	CAM_DIST_MAX = 160,
	CAM_PITCH_MIN = nil,
	CAM_PITCH_MAX = nil,
	CAM_YAW_DELTA_MAX = nil,
	CAM_PAN_MAX = 35,
	CAM_ZOOM_STEP = 8,
	-- ÉPAULETTE DE GRADE (10/01, user : « mon personnage est trop petit ») : plus de marge
	-- que les autres accessoires. Kind "grade" (éditeur + LZY_Character_SetEpauletteOffset) ;
	-- le rendu borne avec "any" = enveloppe la plus large (chaque save est déjà borné par kind).
	GRADE = {
		-- Même élargissement de 50% pour le déplacement et la marge d'échelle autour de 1.
		POS_MIN = { x = -11.7, y = -11.7, z = -11.7 },
		POS_MAX = { x = 11.7, y = 11.7, z = 11.7 },
		SCALE_MIN = 0.025,
		SCALE_MAX = 1.585,
	},
}

local function accessoryEditorLimit(tblKey, field, fallback, sKind)
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR
	if not istable(ed) then return fallback end
	if (sKind == "grade" or sKind == "any") and istable(ed.GRADE) and istable(ed.GRADE[tblKey]) then ed = ed.GRADE end
	local t = ed[tblKey]
	if not istable(t) then return fallback end
	return tonumber(t[field]) or fallback
end

-- sKind (optionnel) : "grade" = bornes de l'épaulette, "any" = enveloppe la plus large (rendu).
function INVENTORY_CONFIG.ClampAccessoryOffsetPos(pos, sKind, scale)
	pos = pos or vector_origin
	-- Conserver la marge de déplacement relative aux grandes pièces, sans réduire celle
	-- des petites. Borner l'échelle ici aussi : le serveur reçoit une valeur non fiable.
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	local growth = math.max(1, tonumber(ed.POS_SCALE_GROWTH) or 2)
	local extraScale = math.max(0, INVENTORY_CONFIG.ClampAccessoryOffsetScale(scale, sKind) - 1)
	local moveScale = 1 + extraScale * growth
	return Vector(
		math.Clamp(pos.x, accessoryEditorLimit("POS_MIN", "x", -12, sKind) * moveScale, accessoryEditorLimit("POS_MAX", "x", 12, sKind) * moveScale),
		math.Clamp(pos.y, accessoryEditorLimit("POS_MIN", "y", -12, sKind) * moveScale, accessoryEditorLimit("POS_MAX", "y", 12, sKind) * moveScale),
		math.Clamp(pos.z, accessoryEditorLimit("POS_MIN", "z", -12, sKind) * moveScale, accessoryEditorLimit("POS_MAX", "z", 12, sKind) * moveScale)
	)
end

function INVENTORY_CONFIG.ClampAccessoryOffsetAng(ang, item_id)
	ang = ang or angle_zero
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR
	if not istable(ed) or not istable(ed.ANG_MIN) or not istable(ed.ANG_MAX) then
		return Angle(ang)
	end
	-- MASQUE : bornes de rotation dédiées bien plus larges (±180 = libre, demande user
	-- 07/23). item_id optionnel : sans lui (appelant historique), bornes standard.
	local sMin, sMax = "ANG_MIN", "ANG_MAX"
	if item_id and INVENTORY_CONFIG.IsMaskAccessory and INVENTORY_CONFIG.IsMaskAccessory(item_id)
		and istable(ed.MASK_ANG_MIN) and istable(ed.MASK_ANG_MAX) then
		sMin, sMax = "MASK_ANG_MIN", "MASK_ANG_MAX"
	end
	return Angle(
		math.Clamp(ang.p, accessoryEditorLimit(sMin, "p", -45), accessoryEditorLimit(sMax, "p", 45)),
		math.Clamp(ang.y, accessoryEditorLimit(sMin, "y", -45), accessoryEditorLimit(sMax, "y", 45)),
		math.Clamp(ang.r, accessoryEditorLimit(sMin, "r", -45), accessoryEditorLimit(sMax, "r", 45))
	)
end

--- Bornes d'échelle (min, max) d'un kind (nil = standard, "grade", "any").
function INVENTORY_CONFIG.AccessoryScaleBounds(sKind)
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	if (sKind == "grade" or sKind == "any") and istable(ed.GRADE) and ed.GRADE.SCALE_MIN then ed = ed.GRADE end
	return tonumber(ed.SCALE_MIN) or 0.5, tonumber(ed.SCALE_MAX) or 1.5
end

function INVENTORY_CONFIG.ClampAccessoryOffsetScale(scale, sKind)
	scale = tonumber(scale) or 1
	local sMin, sMax = INVENTORY_CONFIG.AccessoryScaleBounds(sKind)
	return math.Clamp(scale, sMin, sMax)
end

function INVENTORY_CONFIG.ClampAccessoryOffsetVectorAngle(pos, ang, item_id, sKind, scale)
	return INVENTORY_CONFIG.ClampAccessoryOffsetPos(pos, sKind, scale), INVENTORY_CONFIG.ClampAccessoryOffsetAng(ang, item_id)
end

function INVENTORY_CONFIG.ClampAccessoryEditorCamDist(dist)
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	return math.Clamp(tonumber(dist) or 95, ed.CAM_DIST_MIN or 50, ed.CAM_DIST_MAX or 160)
end

function INVENTORY_CONFIG.ClampAccessoryEditorCamPitch(pitch)
	pitch = tonumber(pitch) or 14
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	if ed.CAM_PITCH_MIN == nil and ed.CAM_PITCH_MAX == nil then
		return pitch
	end
	return math.Clamp(pitch, ed.CAM_PITCH_MIN or -89, ed.CAM_PITCH_MAX or 89)
end

function INVENTORY_CONFIG.ClampAccessoryEditorCamYaw(camYaw, bodyYaw)
	camYaw = tonumber(camYaw) or 0
	bodyYaw = tonumber(bodyYaw) or 0
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	if ed.CAM_YAW_DELTA_MAX == nil then
		return camYaw
	end
	local maxDelta = ed.CAM_YAW_DELTA_MAX
	local delta = math.NormalizeAngle(camYaw - bodyYaw)
	delta = math.Clamp(delta, -maxDelta, maxDelta)
	return bodyYaw + delta
end

function INVENTORY_CONFIG.ClampAccessoryEditorCamPan(offset)
	offset = offset or vector_origin
	local ed = INVENTORY_CONFIG.ACCESSORY_EDITOR or {}
	local panMax = ed.CAM_PAN_MAX or 35
	if offset:LengthSqr() <= panMax * panMax then return Vector(offset) end
	return offset:GetNormalized() * panMax
end

function INVENTORY_CONFIG.ParseAccessoryOffsetJSON(raw)
	if not isstring(raw) or raw == "" then return nil end
	local t = util.JSONToTable(raw)
	return istable(t) and t or nil
end

-- Enchantements d'équipement (atelier Combat evo_craft), colonne inventory.enchant :
-- "stat:pct" ou "stat:pct;stat2:pct2" (2 MAX, le 2e emplacement = crafteur niveau 20).
-- `pct` = ajout plat d'e_* (depuis le passage hors % de la pièce). Le clamp 100
-- borne une valeur corrompue en BDD ; le vrai plafond = maxPct du boost evo_craft.
-- Les anciennes valeurs 0-50 (08/28) sont ramenées à l'affichage/application.
INVENTORY_CONFIG.ENCHANT_MAX_SLOTS = 2

-- raw -> liste { {stat=, pct=}, ... } (vide si rien). Entrées invalides ignorées,
-- stats DUPLIQUÉES dédupliquées (la première gagne : jamais 2× le même boost).
function INVENTORY_CONFIG.ParseEnchantList(raw)
	local out = {}
	if not isstring(raw) or raw == "" then return out end
	local seen = {}
	for part in string.gmatch(raw, "[^;]+") do
		part = string.Trim(part)
		local stat, val = string.match(part, "^([%w_]+):%s*(%d+%.?%d*)%s*$")
		local pct = tonumber(val)
		if stat and pct and pct > 0 and not seen[stat] then
			seen[stat] = true
			out[#out + 1] = { stat = stat, pct = math.min(pct, 100) }
			if #out >= INVENTORY_CONFIG.ENCHANT_MAX_SLOTS then break end
		end
	end
	return out
end

-- Lua : t[1001] ≠ t["1001"]. Les maps par slot (enchants, forge, durabilité) peuvent
-- porter l'un ou l'autre selon la source (SELECT tonumber vs JSON). Un miss silencieux
-- droppe le bonus (HP gravé visible au tooltip, 0 e_max_hp en jeu).
function INVENTORY_CONFIG.SlotMapGet(map, sid)
	if not istable(map) or sid == nil then return nil end
	local v = map[sid]
	if v ~= nil then return v end
	local n = tonumber(sid)
	if n == nil then return map[tostring(sid)] end
	v = map[n]
	if v ~= nil then return v end
	return map[tostring(n)]
end

-- Compat : première entrée seulement (affichages simples).
function INVENTORY_CONFIG.ParseEnchant(raw)
	local e = INVENTORY_CONFIG.ParseEnchantList(raw)[1]
	if not e then return nil end
	return e.stat, e.pct
end

function INVENTORY_CONFIG.EnchantString(stat, pct)
	if not isstring(stat) or stat == "" then return nil end
	pct = tonumber(pct)
	if not pct or pct <= 0 then return nil end
	return string.format("%s:%.2f", stat, pct)
end

-- liste -> chaîne BDD (nil si vide). Tronquée à ENCHANT_MAX_SLOTS.
function INVENTORY_CONFIG.EnchantListString(list)
	if not istable(list) or #list == 0 then return nil end
	local parts = {}
	for i = 1, math.min(#list, INVENTORY_CONFIG.ENCHANT_MAX_SLOTS) do
		local s = INVENTORY_CONFIG.EnchantString(list[i].stat, list[i].pct)
		if s then parts[#parts + 1] = s end
	end
	if #parts == 0 then return nil end
	return table.concat(parts, ";")
end

-- Genre d'un skin/tenue : "male" / "female" / nil (unisexe ou inconnu).
-- Priorite au champ explicite `gender` de l'item, sinon derive du model_path
-- (les models perso suivent la convention .../<faction>/male/... ou /female/...).
function INVENTORY_CONFIG.GetItemGender(itemData)
	if not itemData then return nil end
	if itemData.gender == "male" or itemData.gender == "female" then
		return itemData.gender
	end
	local mp = itemData.model_path
	if isstring(mp) then
		local lower = string.lower(mp)
		if string.find(lower, "/female/", 1, true) then return "female" end
		if string.find(lower, "/male/", 1, true) then return "male" end
	end
	return nil
end

-- Libelle FR du genre pour l'affichage UI.
function INVENTORY_CONFIG.GetItemGenderLabel(itemData)
	local g = INVENTORY_CONFIG.GetItemGender(itemData)
	if g == "male" then return "Homme" end
	if g == "female" then return "Femme" end
	return nil
end

-- Faction d'un item : "Shinigami" / "Hollow" / nil (neutre = équipable par tous).
-- Priorité au champ explicite `faction` de l'item, sinon dérivé du model_path
-- (convention des packs : .../shinigami/... = Shinigami, .../arrancar/... = Hollow).
function INVENTORY_CONFIG.GetItemFaction(itemData)
	if not istable(itemData) then return nil end
	-- "all" = explicitement UNIVERSEL (ex. katana vendu aux DEUX factions, comme ichigo4) :
	-- aucune restriction d'équip, même si le model_path est typé (shinigami / arrancar).
	if itemData.faction == "all" then return nil end
	if itemData.faction == "Shinigami" or itemData.faction == "Hollow" then
		return itemData.faction
	end
	local mp = itemData.model_path
	if isstring(mp) then
		local lower = string.lower(mp)
		if string.find(lower, "/shinigami/", 1, true) then return "Shinigami" end
		if string.find(lower, "/arrancar/", 1, true) then return "Hollow" end
		-- Masques d'Arrancar (accessoires) : rangés sous .../head/arr_mask/...
		-- (pas de /arrancar/ dans le chemin) -> Hollow uniquement.
		if string.find(lower, "/arr_mask/", 1, true) then return "Hollow" end
	end
	return nil
end

-- L'item est-il utilisable par la faction de ce joueur ? (item neutre = oui).
-- Partagé : gate SERVEUR dans EquipItem/EquipKatana + pré-check UI côté client.
function INVENTORY_CONFIG.CanFactionUseItem(ply, itemData)
	local fac = INVENTORY_CONFIG.GetItemFaction(itemData)
	if not fac then return true end
	-- Animateur en mode hollow (outil d'animation) : équipe TOUT sans limite de faction.
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimatorHollow", false) then return true end
	-- SUPERADMIN : équipe N'IMPORTE QUEL accessoire/équipement, quelle que soit la faction
	-- (demande user). Ce helper est le chokepoint PARTAGÉ -> couvre le gate serveur
	-- (EquipItem/EquipKatana) ET le pré-check UI client en un seul endroit. IsSuperAdmin est
	-- répliqué côté client (LocalPlayer), donc fiable des deux côtés.
	if IsValid(ply) and ply:IsSuperAdmin() then return true end
	return IsValid(ply) and ply:GetEvoNWString("FactionName", "") == fac
end

-- L'item modifie-t-il réellement les stats du joueur une fois équipé ?
-- SEULS ces items sont soumis au lock de combat (anti-swap de stats en plein combat,
-- cf. sv_swap_combat_lock). Les accessoires PUREMENT cosmétiques (masques tête / épaules
-- sans champ `stats`) + les tenues peuvent être (dé)équipés / déplacés librement, même
-- en combat — ils ne changent rien aux stats, donc aucun exploit possible.
-- Partagé : gate SERVEUR (Equip/Unequip/SaveAccessoryOffset) + pré-check UI client.
function INVENTORY_CONFIG.ItemAffectsStats(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not istable(it) then return false end
	-- Tenue : cosmétique pur, jamais de stats.
	if it.category == "outfit" then return false end
	-- Stats directes (dict { max_hp = 10 } OU array de pairs { { "e_max_hp", 10 } }).
	-- next() couvre les deux formats + détecte une table vide.
	if istable(it.stats) and next(it.stats) ~= nil then return true end
	-- Bonus de set : (dé)équiper change le nombre de pièces -> change les stats du set.
	if it.set_id then return true end
	return false
end

-- Normalise un genre ("m"/"f"/"male"/"female"/"homme"/"femme") -> "male"/"female"/nil.
-- Inline (pas de dépendance à LZY_CHARACTER_CONFIG.NormalizeGender, défini client only)
-- pour tourner AUSSI serveur (gate d'équipement autoritatif).
function INVENTORY_CONFIG.NormalizeGender(g)
	if not g then return nil end
	g = string.lower(tostring(g))
	if g == "f" or g == "female" or g == "femme" then return "female" end
	if g == "m" or g == "male" or g == "homme" then return "male" end
	return nil
end

-- L'item est-il utilisable par le GENRE de ce joueur ? Une tenue/accessoire genré
-- ("male"/"female" via GetItemGender) n'est équipable QUE par un joueur du même genre.
-- Item sans genre (unisexe) OU genre joueur inconnu = autorisé (fail-open, comme la
-- faction). Partagé : gate SERVEUR (EquipItem) + pré-check UI client + filtrage boutiques.
function INVENTORY_CONFIG.CanGenderUseItem(ply, itemData)
	local g = INVENTORY_CONFIG.GetItemGender(itemData)
	if not g then return true end
	if not IsValid(ply) then return true end
	-- Animateur en mode hollow : équipe TOUT sans limite de genre.
	if ply:GetEvoNWBool("EVO_AnimatorHollow", false) then return true end
	local pg = INVENTORY_CONFIG.NormalizeGender(ply:GetEvoNWString("Gender", ""))
	if not pg then return true end -- genre joueur inconnu -> on n'empêche pas
	return pg == g
end

-- L'item est-il assignable au CONSOMMABLE RAPIDE (petit slot de la spell bar,
-- convar client evo_quickitem) ? Prédicat UNIQUE des deux points d'assignation :
-- le radial de lzy_spell_bar ET l'option « Action rapide » du menu contextuel.
-- Potions evo_science ("potion_*" seulement, jamais les champignons, demande
-- user 08/09) + équipement de l'ombre assassin (grenades/pièges evo_craft)
-- + produits de la table médicale (infusions/pilules/tubes/vaccins/seringue,
-- source unique EVO_SCIENCE.MedQuickConsumable, demande user 08/18)
-- + plantes À EFFET (EVO_SCIENCE.PlantQuickConsumable) et appâts à Hollow
-- (EVO_CRAFT.IsHollowBait), demande user 2026-09-18. Les CHAMPIGNONS restent
-- exclus : c'est toujours la règle du 08/09, et une plante n'est pas un champignon.
function INVENTORY_CONFIG.IsQuickConsumable(item_id)
	if not (isstring(item_id) and ITEMS and ITEMS[item_id] and ITEMS[item_id].on_use) then return false end
	if string.match(item_id, "^potion_") then
		local hubItems = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub and EVO_SCIENCE.CFG.Hub.Items
		return hubItems ~= nil and hubItems[item_id] ~= nil
	end
	if EVO_CRAFT and EVO_CRAFT.AssassinGearByKey and EVO_CRAFT.AssassinGearByKey(item_id) ~= nil then
		return true
	end
	if EVO_SCIENCE and EVO_SCIENCE.MedQuickConsumable and EVO_SCIENCE.MedQuickConsumable(item_id) then
		return true
	end
	if EVO_SCIENCE and EVO_SCIENCE.PlantQuickConsumable and EVO_SCIENCE.PlantQuickConsumable(item_id) then
		return true
	end
	if EVO_CRAFT and EVO_CRAFT.IsHollowBait and EVO_CRAFT.IsHollowBait(item_id) then
		return true
	end
	return false
end

-- Classification d'un item d'inventaire : accessoire A STATS = PAR PERSONNAGE
-- (demande user : « les items avec des statistiques »). Critere = un accessoire qui
-- porte une table `stats` NON VIDE (ex. bague_de_lamour) OU qui appartient a un set
-- (set_id -> il donne forcement des stats, ex. les bracelet/collier/bague _brasier...
-- d'evo_loot). Les accessoires PUREMENT cosmetiques (cape, tete : model_path sans stats)
-- ne sont PAS concernes et restent partages au niveau du compte.
-- NOTE : logique d'INVENTAIRE -> definie ici (l'addon inventory possede la table ITEMS).
-- Le nom historique `LZY_Shop_*` est conserve pour ne rien casser cote lzy_shop (appelants).
function LZY_Shop_IsPerCharAccessory(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it or it.category ~= "accessory" then return false end
	if it.set_id ~= nil then return true end
	return istable(it.stats) and next(it.stats) ~= nil
end

-- Masque d'Arrancar ? Convention des packs : accessoires rangés sous .../head/arr_mask/.
-- PARTAGÉ : rotation élargie de l'éditeur (ClampAccessoryOffsetAng client + revalidation
-- serveur) + slot d'équipement dédié aux masques.
function INVENTORY_CONFIG.IsMaskAccessory(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not istable(it) or it.category ~= "accessory" then return false end
	local mp = it.model_path
	return isstring(mp) and string.find(string.lower(mp), "/arr_mask/", 1, true) ~= nil
end

-- Cet item REND SON PORTEUR ANONYME ? (masques d'anonymat, demande user 09/08).
-- On teste un CHAMP MÉTIER (`hide_name`) et pas une liste d'ids : ajouter un nouveau
-- masque anonymisant ne demandera aucune modification de code, juste le champ sur l'item.
-- PARTAGÉ serveur+client : le SERVEUR s'en sert pour dériver le drapeau réseau
-- EVO_AnonMask (lzy_character/server/sv_main.lua), le CLIENT pour l'affichage.
function INVENTORY_CONFIG.ItemHidesIdentity(item_id)
	local it = ITEMS and ITEMS[item_id]
	return istable(it) and it.hide_name == true
end

-- Accessoire "bijou" masquable via l'œil de l'inventaire (demande user : SEULEMENT
-- colliers / bracelets / bagues — pas les masques/capes/écharpes). Champ explicite
-- `hideable = true/false` sur l'item prioritaire, sinon heuristique id+nom.
-- Partagé : gate SERVEUR (ToggleHideAccessory) + affichage de l'œil côté UI.
function INVENTORY_CONFIG.IsHideableAccessory(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it or it.category ~= "accessory" then return false end
	if it.hideable ~= nil then return it.hideable == true end
	local s = string.lower(tostring(item_id) .. " " .. tostring(it.name or ""))
	return string.find(s, "bague", 1, true) ~= nil
		or string.find(s, "collier", 1, true) ~= nil
		or string.find(s, "bracelet", 1, true) ~= nil
		or string.find(s, "anneau", 1, true) ~= nil
end

-- Accessoire TOUJOURS VISIBLE (user 09/16, Cape Yamamoto modifiée) : champ explicite
-- `always_visible = true` sur l'item. Côté client (lzy_character/cl_models.lua) ces
-- accessoires suivent le régime des insignes de grade : dessinés sur les autres joueurs
-- même si le menu Optimisations masque les accessoires (préréglage Faible) ou au-delà
-- de la distance d'affichage des accessoires (ils disparaissent avec le CORPS, pas avant).
-- Jamais sur les bots de simulation ni les figurants de foule (pools filtrés).
-- Clé = model_path (characterData ne transporte que les chemins de modèle, pas les ids
-- d'item), casse ignorée. Deux caches : le set des chemins always_visible (parcours
-- d'ITEMS une fois) + un verdict par chemin TEL QUE REÇU (évite le string.lower par
-- accessoire et par image dans le rendu). D'autres addons enregistrent des accessoires
-- dans ITEMS APRÈS ce fichier (evo_loot : timer 0,5 s x 20 + InitPostEntity) : le cache
-- est donc vidé après cette fenêtre (hook plus bas) et tout registrar tardif d'un item
-- always_visible doit appeler INVENTORY_CONFIG.InvalidateAlwaysVisibleAccessoryCache().
local alwaysVisibleAccessoryModels -- { [model_path minuscule] = true }
local alwaysVisibleByPath = {}     -- { [model_path tel que reçu] = true/false }
function INVENTORY_CONFIG.InvalidateAlwaysVisibleAccessoryCache()
	alwaysVisibleAccessoryModels = nil
	alwaysVisibleByPath = {}
end
function INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel(model_path)
	if not isstring(model_path) or model_path == "" then return false end
	local v = alwaysVisibleByPath[model_path]
	if v ~= nil then return v end
	if alwaysVisibleAccessoryModels == nil then
		alwaysVisibleAccessoryModels = {}
		for _, it in pairs(ITEMS or {}) do
			if istable(it) and it.category == "accessory" and it.always_visible == true
				and isstring(it.model_path) and it.model_path ~= "" then
				alwaysVisibleAccessoryModels[string.lower(it.model_path)] = true
			end
		end
	end
	v = alwaysVisibleAccessoryModels[string.lower(model_path)] == true
	alwaysVisibleByPath[model_path] = v
	return v
end
if CLIENT then
	-- Après la fenêtre d'enregistrement tardif (evo_loot : jusqu'à ~10 s après le chargement).
	hook.Add("InitPostEntity", "INV:AlwaysVisibleAcc:Reset", function()
		timer.Simple(12, INVENTORY_CONFIG.InvalidateAlwaysVisibleAccessoryCache)
	end)
end

--- Client equip UI expects string keys "1".."7" and "katana" (7 = slot masque).
--- JSON / sparse tables may use numeric keys only.
function INVENTORY_CONFIG.NormalizeEquippedKeysForClient(eq)
	if not istable(eq) then return {} end
	local nMax = INVENTORY_CONFIG.MAX_GEAR_SLOT or 7
	local norm = {}
	for k, v in pairs(eq) do
		if isstring(v) and v ~= "" then
			if k == "katana" then
				norm["katana"] = v
			elseif type(k) == "number" and k >= 1 and k <= nMax then
				norm[tostring(k)] = v
			elseif isstring(k) then
				local d = tonumber(k)
				if d and d >= 1 and d <= nMax then
					norm[tostring(d)] = v
				end
			end
		end
	end
	return norm
end

-- World drop / pickup (inventory row gets character_id & slot_id NULL while on ground)
INVENTORY_CONFIG.DROP_USE_RADIUS = 72
INVENTORY_CONFIG.DROP_VIS_SPHERE_RADIUS = 80
INVENTORY_CONFIG.DROP_SPAWN_DISTANCE = 52
INVENTORY_CONFIG.DEFAULT_DROP_MODEL = "models/evo/props/items/evo_w5kr9ubn8wriaxu/evo_b047knj3x9qqj.mdl"

-- Tous les objets droppés au sol utilisent le MÊME sac de butin neutre
-- (DEFAULT_DROP_MODEL = evo_neutral_bag01.mdl), avec le nom de l'objet flottant
-- au-dessus (NWString LZY_InventoryDropName = item_id, qté = skin du prop).
function INVENTORY_CONFIG.GetDropModelForItem(item_id)
	return INVENTORY_CONFIG.DEFAULT_DROP_MODEL
end

-- Katana (skin_id) never droppable; set is_droppable = false to block world drop and trading (lzy_trade) for other items.
-- ply optionnel : un SUPERADMIN contourne le verrou (peut drop/trade même un is_droppable=false).
-- Gate UNIQUE de sortie d'item (drop au sol "Jeter" + échange lzy_trade — tous les
-- consommateurs passent par ici) : les COSMÉTIQUES (accessoires / vêtements) ne sortent
-- JAMAIS de l'inventaire d'un joueur normal ; seul un SUPERADMIN contourne.
-- slot optionnel : pour les items à instance_key (livres classifiés, etc.) la
-- droppabilité peut dépendre de CET exemplaire via ITEMS[id].instance_droppable.
local COSMETIC_CATEGORIES = { accessory = true, outfit = true }
function INVENTORY_CONFIG.IsItemDroppable(item_id, ply, slot)
	local it = ITEMS and ITEMS[item_id]
	if not it then return false end
	if IsValid(ply) and ply:IsSuperAdmin() then return true end
	-- Équipement À STATS (sets evo_loot) : rangé en category "accessory" alors que ce n'est
	-- PAS un cosmétique -> il ne dépend que de son `is_droppable`. Sans cette exception le
	-- verrou ci-dessous l'attrapait par sa catégorie et son is_droppable n'était jamais lu.
	-- Même exception pour le masque médical (bMedicalMask) : il DOIT circuler,
	-- c'est le vecteur du gameplay de contagion (evo_science).
	-- Lunettes d'analyse (bAnalysisGlasses) : équipement technique échangeable.
	if COSMETIC_CATEGORIES[it.category] and not INVENTORY_CONFIG.ItemAffectsStats(item_id)
		and not it.bMedicalMask and not it.bAnalysisGlasses then
		return false -- cosmétiques : réservé superadmin
	end
	if slot and isfunction(it.instance_droppable) then
		local inv
		if SERVER and IsValid(ply) then
			inv = ply.inventory
		elseif CLIENT and IsValid(ply) and ply.GetInventory then
			inv = ply:GetInventory()
		end
		local key = INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
		if key then
			local ok, drop = pcall(it.instance_droppable, key, ply)
			if ok and drop == false then return false end
		end
	end
	return it.is_droppable ~= false
end

-- Superadmin delete from inventory; set is_deletable = false to block (server + UI).
-- ply optionnel : un SUPERADMIN contourne le verrou.
function INVENTORY_CONFIG.IsItemDeletable(item_id, ply)
	local it = ITEMS and ITEMS[item_id]
	if not it then return false end
	if IsValid(ply) and ply:IsSuperAdmin() then return true end
	return it.is_deletable ~= false
end

--- instance_key du slot (inventaire serveur ou copie client GetInventory).
function INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
	if not istable(inv) or not slot then return nil end
	local keys = inv.instance_keys
	if not istable(keys) then return nil end
	local k = keys[slot] or keys[tonumber(slot)] or keys[tostring(slot)]
	if isstring(k) and k ~= "" then return k end
	return nil
end

--- COSMÉTIQUES EMPILABLES (user 09/07) : tenues, accessoires purement cosmétiques, skins de
--- katana et gantelets se rangent en piles (doublons de coffre). Exclus : équipement à stats /
--- sets (méta propre, par perso) et items à clé d'instance obligatoire.
INVENTORY_CONFIG.COSMETIC_STACK_MAX = 99
function INVENTORY_CONFIG.IsStackableCosmetic(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it or it.requires_instance_key or it.set_id ~= nil then return false end
	if istable(it.stats) and next(it.stats) ~= nil then return false end
	return it.category == "outfit" or it.category == "accessory" or it.skin_id ~= nil or it.gauntlet_id ~= nil
end

--- CONSOMMABLES EMPILABLES (user 09/07) : potions, pièges/grenades assassin, produits
--- médicaux rapides, parchemins de quête. Cap 64 (Minecraft-like). Un stack_max
--- explicite sur l'item reste prioritaire.
INVENTORY_CONFIG.CONSUMABLE_STACK_MAX = 64
function INVENTORY_CONFIG.IsStackableConsumable(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it or it.requires_instance_key then return false end
	if it.is_quest_scroll then return true end
	if INVENTORY_CONFIG.IsQuickConsumable(item_id) then return true end
	if not isstring(item_id) or it.category ~= "object" then return false end
	-- Prefixes : le hub / evo_craft peut ne pas être chargé au 1er appel de GetItemStackMax.
	return string.match(item_id, "^potion_") ~= nil or string.match(item_id, "^assassin_") ~= nil
end

--- stack_max déclaré sur ITEMS[id] ; sinon cosmétique / consommable empilable ; sinon 1.
function INVENTORY_CONFIG.GetItemStackMax(item_id)
	local it = ITEMS and ITEMS[item_id]
	local n = it and tonumber(it.stack_max)
	if not n or n < 1 then
		if INVENTORY_CONFIG.IsStackableCosmetic(item_id) then
			n = INVENTORY_CONFIG.COSMETIC_STACK_MAX
		elseif INVENTORY_CONFIG.IsStackableConsumable(item_id) then
			n = INVENTORY_CONFIG.CONSUMABLE_STACK_MAX
		end
	end
	if not n or n < 1 then return 1 end
	return math.min(9999, math.floor(n))
end

--- Exemplaire INTACT = fusionnable : durabilité pleine (ou absente), pas de niveau de forge,
--- pas d'enchant, pas d'offset d'éditeur. Une pile ne porte qu'UNE méta : y fondre un katana
--- usé ou un accessoire réglé écraserait (ou propagerait) cette méta.
function INVENTORY_CONFIG.IsSlotPristine(inv, slot)
	if not istable(inv) or not slot then return false end
	local d = inv.durability and tonumber(inv.durability[slot] or inv.durability[tostring(slot)])
	if d and d < 100 then return false end
	local lvl = inv.forge_levels and tonumber(inv.forge_levels[slot] or inv.forge_levels[tostring(slot)])
	if lvl and lvl > 1 then return false end
	local e = inv.enchants and (inv.enchants[slot] or inv.enchants[tostring(slot)])
	if isstring(e) and e ~= "" then return false end
	local o = inv.accessory_offsets and (inv.accessory_offsets[slot] or inv.accessory_offsets[tostring(slot)])
	if o ~= nil and o ~= false then return false end
	return true
end

--- Même règle pour une méta de don (GiveItem tMeta) : nil = exemplaire neuf.
function INVENTORY_CONFIG.MetaIsPristine(tMeta)
	if not istable(tMeta) then return true end
	if isnumber(tMeta.durability) and tMeta.durability < 100 then return false end
	if isnumber(tMeta.forge_level) and tMeta.forge_level > 1 then return false end
	if isstring(tMeta.enchant) and tMeta.enchant ~= "" then return false end
	if tMeta.accessory_offset ~= nil and tMeta.accessory_offset ~= false then return false end
	return true
end

--- Quantité d'une row SQL (JOIN coffre / HDV : alias `qty` ou colonne `quantity`).
function INVENTORY_CONFIG.SQLRowQuantity(row)
	if not istable(row) then return 1 end
	return math.max(1, math.floor(tonumber(row.qty or row.quantity) or 1))
end

--- Quantité du slot. Absent / 0 = 1 (lignes existantes, sync partiel).
function INVENTORY_CONFIG.GetSlotQuantity(inv, slot)
	if not istable(inv) or not slot then return 0 end
	local id = inv.items and (inv.items[slot] or inv.items[tonumber(slot)] or inv.items[tostring(slot)])
	if not isstring(id) or id == "" then return 0 end
	local qs = inv.quantities
	local q
	if istable(qs) then
		q = tonumber(qs[slot] or qs[tonumber(slot)] or qs[tostring(slot)])
	end
	if not q or q < 1 then return 1 end
	return math.floor(q)
end

--- Deux slots sac se fusionnent si même item, même instance_key, et pile pas pleine.
function INVENTORY_CONFIG.CanMergeBagSlots(inv, from, to)
	from, to = tonumber(from), tonumber(to)
	if not (istable(inv) and istable(inv.items) and from and to and from ~= to) then return false end
	local a, b = inv.items[from], inv.items[to]
	if not (isstring(a) and a ~= "" and a == b) then return false end
	local max = INVENTORY_CONFIG.GetItemStackMax(a)
	if max <= 1 then return false end
	if INVENTORY_CONFIG.GetSlotInstanceKey(inv, from) ~= INVENTORY_CONFIG.GetSlotInstanceKey(inv, to) then
		return false
	end
	-- Exemplaires intacts seulement (cf. IsSlotPristine) : un katana usé reste seul.
	if not (INVENTORY_CONFIG.IsSlotPristine(inv, from) and INVENTORY_CONFIG.IsSlotPristine(inv, to)) then
		return false
	end
	return INVENTORY_CONFIG.GetSlotQuantity(inv, to) < max
end

--- Somme des quantités d'un item_id dans le sac (piles comprises).
function INVENTORY_CONFIG.CountBagItem(inv, item_id)
	if not istable(inv) or not istable(inv.items) or not isstring(item_id) then return 0 end
	local max = INVENTORY_CONFIG.MAX_BAG_SLOTS or 80
	local n = 0
	for i = 1, max do
		if inv.items[i] == item_id then
			n = n + INVENTORY_CONFIG.GetSlotQuantity(inv, i)
		end
	end
	return n
end

function INVENTORY_CONFIG.ItemRequiresInstanceKey(item_id)
	local it = ITEMS and ITEMS[item_id]
	return it and it.requires_instance_key == true
end

-- Rang de type pour TRIER (sac + coffres). Préfère la taxonomie coffre
-- (armes / équipement / tenues…) ; sinon ITEMS.category.
local ITEM_TYPE_RANK_FALLBACK = {
	outfit = 1, accessory = 2, combat_style = 3, finisher = 4, object = 5,
}

function INVENTORY_CONFIG.ItemTypeRank(item_id)
	if EVO_CRAFT and EVO_CRAFT.CoffreCatOf and istable(EVO_CRAFT.CoffreCats) then
		local cat = EVO_CRAFT.CoffreCatOf(item_id)
		for i = 1, #EVO_CRAFT.CoffreCats do
			if EVO_CRAFT.CoffreCats[i].id == cat then return i end
		end
		return 99
	end
	local it = ITEMS and ITEMS[item_id]
	return ITEM_TYPE_RANK_FALLBACK[it and it.category or ""] or 6
end

--- true si idA doit précéder idB (type, puis item_id, puis nom).
function INVENTORY_CONFIG.CompareItemsForSort(idA, idB)
	idA, idB = tostring(idA or ""), tostring(idB or "")
	local rA = INVENTORY_CONFIG.ItemTypeRank(idA)
	local rB = INVENTORY_CONFIG.ItemTypeRank(idB)
	if rA ~= rB then return rA < rB end
	if idA ~= idB then return idA < idB end
	local nA = INVENTORY_CONFIG.GetItemDisplayName(idA)
	local nB = INVENTORY_CONFIG.GetItemDisplayName(idB)
	if nA ~= nB then return tostring(nA) < tostring(nB) end
	return false
end

--- Nom affiché d'un exemplaire. invOrKey = table inventaire, ou la clé string.
function INVENTORY_CONFIG.GetItemDisplayName(item_id, slot, invOrKey)
	local it = ITEMS and ITEMS[item_id]
	if not it then return item_id or "?" end
	local key
	if isstring(invOrKey) and invOrKey ~= "" then
		key = invOrKey
	elseif istable(invOrKey) then
		key = INVENTORY_CONFIG.GetSlotInstanceKey(invOrKey, slot)
	end
	if key and isfunction(it.instance_name) then
		local ok, name = pcall(it.instance_name, key, slot)
		if ok and isstring(name) and name ~= "" then return name end
	end
	return it.name or item_id
end

function INVENTORY_CONFIG.GetItemRarity(item_id, slot, inv)
	local it = ITEMS and ITEMS[item_id]
	if not it then return nil end
	local key = INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
	if key and isfunction(it.instance_rarity) then
		local ok, r = pcall(it.instance_rarity, key)
		if ok and isstring(r) and r ~= "" then return r end
	end
	return it.rarity
end

function INVENTORY_CONFIG.GetItemDescription(item_id, slot, inv)
	local it = ITEMS and ITEMS[item_id]
	if not it then return "" end
	local key = INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
	if key and isfunction(it.instance_description) then
		local ok, d = pcall(it.instance_description, key)
		if ok and isstring(d) then return d end
	end
	return isstring(it.description) and it.description or ""
end

--- Anciens item_id dynamiques (evo_note_<id>, livre_42, …) → canonique + clé.
--- Nil si l'id n'est pas un document legacy.
function INVENTORY_CONFIG.SplitLegacyDocumentItemId(item_id)
	if not isstring(item_id) or item_id == "" then return nil end
	local pairs_ = {
		{ "evo_note_", "evo_note" },
		{ "evo_affiche_", "evo_affiche" },
		{ "evo_carte_", "evo_carte" },
		{ "evo_missive_", "evo_missive" },
	}
	for i = 1, #pairs_ do
		local prefix, canon = pairs_[i][1], pairs_[i][2]
		if string.StartWith(item_id, prefix) then
			local key = string.sub(item_id, #prefix + 1)
			if key ~= "" then return canon, key end
		end
	end
	local n = string.match(item_id, "^livre_(%d+)$")
	if n then return "evo_livre", n end
	return nil
end

INVENTORY_CONFIG.categoriesNames = {
	["accessory"] = "Accessoires",
	["outfit"] = "Vêtements",
	["object"] = "Autres",
	["combat_style"] = "Style de combat",
	["finisher"] = "Finisher",
}

INVENTORY_CONFIG.raritiesColor = {
	["common"] = "gray",
	["rare"] = "blue",
	["epic"] = "purple",
	["legendary"] = "yellow",
	["mythic"] = "red",
}

--- Tooltip labels for ITEMS[id].stats keys (percent bonuses, shown as +N%%).
INVENTORY_CONFIG.STAT_DISPLAY_NAMES = {
	max_hp = "PV max",
	regen_hp = "Régén. PV",
	max_reiatsu = "Reiatsu max",
	regen_reiatsu = "Régén. reiatsu",
	katana_damage = "Dégâts d'arme",
	katana_cc_chance = "Chance CC",
	katana_cc_damage = "Dégâts CC",
	flashstep_cd = "CD Flashstep",
	flashstep_range = "Portée Flashstep",
	spell_cd_reduction = "Réduction CD spells",
	parade_max = "Parade max",
	parade_regen = "Temps de régén. garde",
	parade_damage = "Dégâts parade",
	dodge_chance = "Chance d'esquive",
	speed = "Vitesse",
	jump_power = "Force de saut",
}

-- Item variables
-- name: Item name
-- description: Item description
-- icon: Item icon
-- stats: Item stats (max_hp, regen_hp, max_reiatsu, regen_reiatsu, katana_damage, katana_cc_chance, katana_cc_damage, flashstep_cd, flashstep_range, spell_cd_reduction, parade_max, parade_regen, parade_damage, dodge_chance)
-- category: Item category (outfit, accessory, object)
-- slot: Item slot (head, cape, necklace, ring, belt)
-- model_path: For outfit, required to equip. For accessory, optional (stats-only ring etc.); if set, merged on character preview.
-- rarity: Item rarity (common, rare, epic, legendary, mythic)
-- on_use: Item use function (for items that can be used)
-- is_droppable: Item droppable (for items that can be dropped)
-- is_deletable: Item deletable (for items that can be deleted)
-- has_durability: If true, item has durability 0–100%. Katana: drains on successful melee hits. Accessory: drains per minute while equipped. At 0% cannot equip or use (on_use).
-- stack_max: max copies per bag slot (same item_id + same instance_key). Default 1 = no stacking.
INVENTORY_CONFIG.ACCESSORY_DURABILITY_DRAIN_PER_MIN = 0.02
INVENTORY_CONFIG.KATANA_DURABILITY_PER_HIT = 0.1
-- Délai min entre deux usures d'arme : l'usure compte par SWING, pas par coup. Un combo
-- Hakuda place 2 à 5 coups par swing et userait le gantelet ~5× plus vite qu'un katana.
-- Sous la cadence de swing la plus rapide (~0.36s) pour ne pas rater de coup légitime.
INVENTORY_CONFIG.WEAPON_DURABILITY_MIN_INTERVAL = 0.25

function INVENTORY_CONFIG.ItemHasDurability(item_id)
	local it = ITEMS and ITEMS[item_id]
	return it and it.has_durability == true
end

-- Pets d'épaule (user 08/26) : entrée d'item commune. Modèle canonique
-- models/evo/accessories/body/pet_epaule/<dir>/<dir>.mdl (clé de
-- LZY_CHARACTER_CONFIG.SHOULDER_PETS, rendu + animations dans lzy_character cl_models).
-- Slot "cape" (accessoire de corps). nSkin = variante de couleur (champignon).
local function PetItem(sName, sDir, sRarity, nSkin)
	return {
		name = "Pet d'épaule : " .. sName,
		description = "Un petit compagnon perché sur ton épaule.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = sRarity or "rare",
		-- sDir peut avoir un sous-dossier (« tickets/loutre_lotus ») : le .mdl porte le DERNIER segment.
		model_path = "models/evo/accessories/body/pet_epaule/" .. sDir .. "/" .. string.GetFileFromFilename(sDir) .. ".mdl",
		skin = nSkin,
		-- Cadrage des aperçus (08/27, pets coupés au bord de la case) : modèles rigés
		-- sur le squelette -> la caméra vise les OS PORTEURS du mesh dans la pose rendue
		-- (cf. preview_bone_focus, cl_item_preview_model). model_margin : ↑ dézoome.
		preview_bone_focus = true,
		model_margin = 1.0,
		-- Décalage horizontal dans la case (user 08/29 : les pets tiraient trop à
		-- GAUCHE). Fraction de la taille du pet ; NÉGATIF = vers la DROITE.
		-- C'est LE seul nombre à bouger si le cadrage ne tombe pas juste, et il vaut
		-- pour tous les pets d'un coup (même attache, même décalage).
		preview_shift_left = -0.45,
	}
end

-- Fourreaux V7 (09/30) : cosmétique n (bodygroup « cosmetic ») valable sur TOUS les katanas
-- pris en charge (NCM_FOURREAUX.ByKatana). Aperçu = fourreau vide (katana_range 0).
-- V13 (10/01) : 10..19 = banque collection_v13, bodygroups cosmetic ET vfx = n - 10.
local function FourreauItem(n, sName, sRarity)
	local bV13 = n >= 10
	return {
		name = "Fourreau : " .. sName,
		description = "Cosmétique de fourreau, il s'adapte au katana équipé.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/ins47h5c6uuvy3at4.png",
		category = "accessory",
		slot = "fourreau",
		coffre_cat = "fourreaux",
		fourreau_cosmetic = n,
		hideable = true, -- œil de la case = sans fourreau
		rarity = sRarity,
		model_path = "models/evo/accessories/fourreaux/" .. (bV13 and "collection_v13" or "collection_v7") .. "/k003.mdl",
		skin = 0,
		bodygroup = bV13 and { cosmetic = n - 10, vfx = n - 10, katana_range = 0 } or { cosmetic = n, katana_range = 0 },
	}
end

-- Compagnons (10/06, pack COMPAGNONS_GMOD_ET_DEV) : animal qui suit le joueur, un par rareté.
-- Modèles models/compagnons/<id>.mdl (séquences idle/walk/trot/run/sit…, cf. evo_compagnons).
local function CompagnonItem(sId, sName, sRarity, sEmote)
	return {
		name = "Compagnon : " .. sName,
		description = "Un compagnon qui te suit partout. Ferme l'œil de sa case pour le renvoyer.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "compagnon",
		coffre_cat = "compagnons",
		compagnon_id = sId,
		compagnon_emote = sEmote,
		hideable = true, -- œil de la case = compagnon renvoyé
		rarity = sRarity,
		model_path = "models/compagnons/" .. sId .. ".mdl",
		skin = 0,
	}
end

ITEMS = {
	["compagnon_rabbit"] = CompagnonItem("rabbit", "Rabbit Escape", "common", "groom"),
	["compagnon_hayate"] = CompagnonItem("hayate", "Black Hayate", "rare", "bark"),
	["compagnon_divine_white"] = CompagnonItem("divine_white", "Divine Dog blanc", "legendary", "bark"), -- 10/10 : épique -> légendaire
	["compagnon_divine_black"] = CompagnonItem("divine_black", "Divine Dog noir", "legendary", "bark"),
	["compagnon_yoruichi_chat"] = CompagnonItem("yoruichi_chat", "Yoruichi (chat)", "mythic", "groom"),
	-- Pack 2 (10/07, user : raretés montées d'un rang ; le pack les laissait vides).
	["compagnon_chien_cartoon"] = CompagnonItem("chien_cartoon", "Chien cartoon", "rare", "bark"),
	["compagnon_chat_cartoon"] = CompagnonItem("chat_cartoon", "Chat cartoon", "epic", "groom"),
	["compagnon_renard_roux"] = CompagnonItem("renard_roux", "Renard roux", "epic", "bark"), -- 10/10 : légendaire -> épique
	["compagnon_panthere_spirituelle"] = CompagnonItem("panthere_spirituelle", "Panthère spirituelle", "mythic", "groom"),
	-- Pack 3 (10/10) : raretés non fournies, A rare / S épique / SS légendaire / Mic mythique.
	["compagnon_chien_ninja_a"] = CompagnonItem("chien_ninja_a", "Chien ninja (rang A)", "rare", "bark"),
	["compagnon_chien_ninja_s"] = CompagnonItem("chien_ninja_s", "Chien ninja (rang S)", "epic", "bark"),
	["compagnon_chien_ninja_ss"] = CompagnonItem("chien_ninja_ss", "Chien ninja (rang SS)", "legendary", "bark"),
	["compagnon_mic_jaguar"] = CompagnonItem("mic_jaguar", "Mic le jaguar", "mythic", "groom"),
	["evo_pocket_map"] = {
		name = "Carte de poche",
		description =
		"Une carte du monde pliable. Clic droit > Utiliser pour pouvoir ouvrir la carte partout avec la touche M.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		icon_scale = 1.3, -- ↑ icône agrandie dans la case (trop petite par défaut). Monter si besoin (déborde vers ~1.45).
		-- Rendu 3D dans la case (au lieu de l'icône PNG) : le système LZY_INVENTORY_ITEM_PREVIEW
		-- affiche le modèle dès qu'un item a un model_path (cl_item_preview_model.lua). L'icône
		-- reste en repli pour les contextes qui ne font pas de preview 3D (drop monde, etc.).
		model_path = "models/evo/props/items/evo_bcg35f6ehhfhehfhzfdzfcn/evo_bcg35f6ehhfhehfhzfdzfcn.mdl",
		category = "object",
		rarity = "legendary",
		is_droppable = true,
		is_deletable = true,
		-- L'utilisation (clic droit) débloque la touche M. Logique 100% serveur
		-- dans evo_map/lua/autorun/server/sv_pocket_map.lua (EVO_PocketMap.Unlock).
		on_use = function(ply)
			if not SERVER then return end
			if EVO_PocketMap and EVO_PocketMap.Unlock then EVO_PocketMap.Unlock(ply) end
		end,
	},
	["carcasse_hollow"] = {
		name = "Carcasse de Hollow",
		description =
		"Dépouille instable d'un Hollow, récupérée sur le terrain. S'analyse au POSTE D'ANALYSE du laboratoire ([E] dans un cercle blanc).",
		-- Ajoutée à la volée dans le tooltip (hover) : temps restant avant évaporation,
		-- lu depuis la besace science côté client (les items miroir sont indistinguables).
		dynamic_description = function()
			if CLIENT and EVO_SCIENCE and EVO_SCIENCE.PouchTooltipLine then
				return EVO_SCIENCE.PouchTooltipLine()
			end
		end,
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png", -- repli : le rendu 3D (model_path) prime dans la case
		-- Rendu 3D dans la case (LZY_INVENTORY_ITEM_PREVIEW) : même prop d'âme que le drop au sol.
		model_path = "models/evo/props/items/evo_fryhbhbfefr65bhvfhudf/evo_FRYHBhbfefr65BHVFhudf.mdl",
		category = "object",
		rarity = "epic",
		is_droppable = false,
		is_deletable = false, -- géré par evo_science (analyse / décomposition) : pas de suppression manuelle
		on_use = function(ply)
			if not SERVER then return end
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify(ply, "Apporte la carcasse au laboratoire : [E] dans un cercle blanc pour l'analyser.", NOTIFY_GENERIC or 0, 5)
			end
		end,
	},
	["parchemin_quete"] = {
		name = "Parchemin de quête",
		description = "Un vieux parchemin scellé. Utilisez-le pour découvrir une mission.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "common",
        is_quest_scroll = true,
        is_droppable = false,
		is_deletable = false,
		stack_max = 64,
	},
	["parchemin_commun"] = {
		name = "Parchemin Commun",
		description = "Un parchemin de quête ordinaire.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "common",
		is_quest_scroll = true,
		stack_max = 64,
	},
	["parchemin_rare"] = {
		name = "Parchemin Rare",
		description = "Un parchemin de quête rare. Récompenses x1.5.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "rare",
		is_quest_scroll = true,
		stack_max = 64,
	},
	["parchemin_epique"] = {
		name = "Parchemin Épique",
		description = "Un parchemin de quête épique. Récompenses x2.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "epic",
		is_quest_scroll = true,
		stack_max = 64,
	},
	["parchemin_legendaire"] = {
		name = "Parchemin Légendaire",
		description = "Un parchemin de quête légendaire. Récompenses x3.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "legendary",
		is_quest_scroll = true,
		stack_max = 64,
	},
	["parchemin_mythique"] = {
		name = "Parchemin Mythique",
		description = "Un parchemin de quête mythique. Récompenses x5.",
		icon = "a8pi8v5e07z97o/iwjnbnd6ira9.png",
		category = "object",
		rarity = "mythic",
		is_quest_scroll = true,
		stack_max = 64,
	},

	-- Bar / distillerie (evo_business) — définis ici pour exister dès le load inventory.
	["bar_eau"] = {
		name = "Eau",
		description = "Eau claire. Distillerie du Bar, et arrosage des cultures.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/items/evo_526NJIEFRVGiojefrbh51fer/evo_526NJIEFRVGiojefrbh51fer.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_houblon"] = {
		name = "Houblon",
		description = "Cônes aromatiques. Donnent l'amertume du moût dans la distillerie.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/items/evo_1fe5262NJEFRHBufreer/evo_1fe5262NJEFRHBufreer.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_levure"] = {
		name = "Levure",
		description = "Levure de fermentation pour la bière et le saké de la distillerie.",
		category = "object",
		rarity = "rare",
		model_path = "models/evo/props/items/evo_7e4d1764cdf18e055a/evo_7e4d1764cdf18e055a.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_malt_moulu"] = {
		name = "Malt moulu",
		description = "Graine de blé broyée à la distillerie. Prête à chauffer avec l'eau et le houblon.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/items/evo_d009544811718b694e/evo_d009544811718b694e.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_mout"] = {
		name = "Moût",
		description = "Moût chaud sorti de la distillerie. À fermenter avec de la levure.",
		category = "object",
		rarity = "rare",
		model_path = "models/evo/props/items/evo_c3b8c0d1f5ec3e7904/evo_c3b8c0d1f5ec3e7904.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["graine_riz"] = {
		name = "Grains de riz",
		description = "Grains de riz dorés : planter dans un pot (Utiliser) ou cuire à la distillerie du Bar. Récolte 8–20 unités.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/recolte/riz_grains.mdl",
		is_droppable = true,
		is_deletable = true,
		stack_max = 64,
		on_use = function(ply, slot)
			if SERVER then return end
			if not (EVO_AGRI and EVO_AGRI.IsPlantable("graine_riz")) then return end
			net.Start("EVO_Agri:Plant")
			net.WriteString("riz")
			net.WriteUInt(math.Clamp(math.floor(tonumber(slot) or 0), 0, 65535), 16)
			net.SendToServer()
		end,
	},
	["bar_koji"] = {
		name = "Kōji",
		description = "Grains de kōji blancs. Transforment l'amidon du riz en sucres pour préparer le saké.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/recolte/koji_grains.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_riz_cuit"] = {
		name = "Riz cuit",
		description = "Riz cuit de la distillerie. À fermenter avec du kōji et de la levure pour obtenir du saké.",
		category = "object",
		rarity = "common",
		model_path = "models/evo/props/items/evo_d009544811718b694e/evo_d009544811718b694e.mdl",
		is_droppable = true,
		stack_max = 64,
	},
	["bar_sake"] = {
		name = "Saké",
		description = "Saké de riz du Bar. Clic droit > Utiliser pour le boire. Un saké compte comme deux bières pour l'ivresse.",
		category = "object",
		rarity = "rare",
		model_path = "models/evo/props/items/evo_783fad311d9a3df0fa/evo_783fad311d9a3df0fa.mdl",
		is_droppable = true,
		stack_max = 64,
		on_use = function(ply)
			if not SERVER then return end
			if EVO_BUSINESS and EVO_BUSINESS.DrinkAlcohol then EVO_BUSINESS.DrinkAlcohol(ply, "bar_sake") end
		end,
	},
	["bar_biere"] = {
		name = "Bière",
		description = "Bière du Bar. Clic droit > Utiliser pour la boire : la tête tourne un moment.",
		category = "object",
		rarity = "rare",
		model_path = "models/evo/props/items/evo_26fgrbh5reg1nhre62r/evo_26FGRBH5reg1nhRE62r.mdl",
		is_droppable = true,
		stack_max = 64,
		on_use = function(ply)
			if not SERVER then return end
			if EVO_BUSINESS and EVO_BUSINESS.DrinkBeer then EVO_BUSINESS.DrinkBeer(ply) end
		end,
	},

	-- TENUE ARRANCAR/HOLLOW "FEMME" Boutique
	["arrancar_apacci_outfit"] = {
		name = "Tenue apacci",
		description = "Tenue de apacci",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_mnc2u39rlkyh/evo_iy4458kp20jro5r.mdl",
	},
	["arrancar_base_f_outfit"] = {
		name = "Tenue base f",
		description = "Tenue de base feminin",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_pvg59ubjcjt5i5v7j/evo_eiosl74snv8xpz.mdl",
	},
	["arrancar_cirucci_outfit"] = {
		name = "Tenue cirucci",
		description = "Tenue de cirucci",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_986qlbqnjg68eh/evo_yw1ys7kecrjglfb.mdl",
	},
	["arrancar_valkyrie_outfit"] = {
		name = "Tenue valkyrie",
		description = "Tenue de valkyrie",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_e6wd88rxb62g/evo_vyhnlihm1c919zev6.mdl",
	},
	["arrancar_nelliel_outfit"] = {
		name = "Tenue Nelliel",
		description = "Tenue d'arrancar féminine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path =
		"models/evo/characters/arrancar/female/evo_bdgfjjhfe518gr6dhhcfjejfd/evo_bdgfjJHFE518gr6dhhcfjejFd.mdl",
	},
	["arrancar_tier_modifier_outfit"] = {
		name = "Tenue Tier Modifier",
		description = "Tenue d'arrancar féminine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_efr542edznlihm1yh9zev6/evo_efr542EDZnlihm1YH9zev6.mdl",
	},

	-- TENUE ARRANCAR/HOLLOW "HOMME" Boutique
	["arrancar_torse_nu_outfit"] = {
		name = "Tenue Arrancar torse nu",
		description = "Tenue d'Arrancar torse nu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_zd58grfen684r1bjezdx/evo_zd58GRFEn684r1BJezdx.mdl",
	},
	["arrancar_aaroniero_outfit"] = {
		name = "Tenue Aaroniero",
		description = "Tenue de Aaroniero",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_adtu5akdhg508kmkk/evo_hof6fg9m8wcj7.mdl",
	},
	["arrancar_aizen_outfit"] = {
		name = "Tenue Aizen",
		description = "Tenue de Aizen",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_9pim1ocvk5lg9fga8/evo_r00hcjix8osq.mdl",
	},
	["arrancar_aizen_fusion_3_outfit"] = {
		name = "Tenue Aizen Fusion",
		description = "Tenue de Aizen en mode forme 3",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_ptdzt5t6kktah/evo_j6qfzwd10e86l7.mdl",
	},
	["arrancar_aizen_noir_outfit"] = {
		name = "Tenue Aizen noir",
		description = "Tenue de Aizen en noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_92l3yswj4s8t7n8o/evo_da8uai1qr98qf4x.mdl",
	},
	["arrancar_base_outfit"] = {
		name = "Tenue arrancar base",
		description = "Tenue de arrancar basique",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_b3xr7ovm2oob1ef6e/evo_4916psnf6mgwm.mdl",
	},

	-- Male — Boutique Arrancar
	["arrancar_torse_ouvert_piques_outfit"] = {
		name = "Tenue ouverte (piques)",
		description = "Tenue ouverte à piques (Arrancar)",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_cnf6g5ergjhge9v2hgrge/evo_cnf6g5ergjHGE9V2hgrge.mdl",
    },

	-- Tenues « service secret » Arrancar (16/09/2026, demande user) — à GIVE en inventaire
	-- (getitem service_secret_arrancar_homme / _femme), pas de vente boutique.
	-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte) : le serveur
	-- est Linux (FS sensible à la casse), un nom lowercasé ne matche AUCUN fichier -> tenue invisible.
	["service_secret_arrancar_homme"] = {
		name = "Tenue service secret Arrancar (homme)",
		description = "Tenue du service secret Arrancar, version masculine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_852hygtropmlik52tgr/evo_852HYgtropmlik52tgr.mdl",
	},
	["service_secret_arrancar_femme"] = {
		name = "Tenue service secret Arrancar (femme)",
		description = "Tenue du service secret Arrancar, version féminine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_vghb415gert25fre62efr/evo_vghb415GERT25fre62efr.mdl",
	},

	-- Female — tenues d'entraînement Shinigami (Urahara Shop)
	["shinigami_entrainement_vert_f_outfit"] = {
		name = "Tenue d'entraînement (verte)",
		description = "Tenue d'entraînement verte",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_vyzdch4hbfcedkoedfhrfe/evo_VYZDCH4hbfcedkoedFHrfe.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_entrainement_bleu_f_outfit"] = {
		name = "Tenue d'entraînement (bleue)",
		description = "Tenue d'entraînement bleue",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_oefazj45bkvsju54efkdnje/evo_oefazj45BKVSJU54efkdnje.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_entrainement_rouge_f_outfit"] = {
		name = "Tenue d'entraînement (rouge)",
		description = "Tenue d'entraînement rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_hbavsij59sghbjufsz/evo_hbaVSIJ59sghbjufsz.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_entrainement_orange_f_outfit"] = {
		name = "Tenue d'entraînement (orange)",
		description = "Tenue d'entraînement orange",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_apokj654fzhubhcgcs/evo_apokj654FZHUbhcgcs.mdl",
		is_droppable = true,
		is_deletable = true,
    },

	-- Accessoire universel (tête) — toutes factions Boutique
	["baton_bouche_01"] = {
		name = "Bâton dans la bouche",
		description = "Bâton tenu dans la bouche",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_hp9x049s34kcq9/evo_j72eerhf7n14.mdl",
    },

	-- Récompenses Battle Pass (accessoires tête universels, demande user 2026-07-25). Casse du
	-- .mdl conservée EXACTEMENT (serveur Linux sensible à la casse).
	["lunette_simple"] = {
		name = "Lunette simple",
		description = "Une simple paire de lunettes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_efrlmqbdek57rgtoe5/evo_efrlmqbdek57RGToe5.mdl",
	},
	["cigare_croco"] = {
		name = "Cigare de croco",
		description = "Un cigare tenu dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_efr57yhtfgbj72eerhf7n14/evo_efr57YHTfgbj72eerhf7n14.mdl",
    },

	-- Female — Boutique Arrancar (variantes noires)
	["arrancar_cirucci_noir_f_outfit"] = {
		name = "Tenue Cirucci (noir)",
		description = "Tenue de Cirucci, variante noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_azsgvhvgydz1erfdz/evo_azsgvhVGYDZ1ERFdz.mdl",
	},
	["arrancar_apacci_noir_f_outfit"] = {
		name = "Tenue Apacci (noir)",
		description = "Tenue d'Apacci, variante noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_dezuba81zddzbhazdss/evo_dezubA81ZDdzbhaZDSs.mdl",
	},
	["arrancar_harribel_noir_f_outfit"] = {
		name = "Tenue Tier Harribel (noir)",
		description = "Tenue de Tier Harribel, variante noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_efrhybuqfeydhbu6fer652efr/evo_efrhybuQFEYDHBU6fer652efr.mdl",
	},
	["arrancar_luppi_noir_f_outfit"] = {
		name = "Tenue Luppi (noir)",
		description = "Tenue de Luppi, variante noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_fehyb526dezhnbijvgdez/evo_fehyb526DEZHNBIJvgdez.mdl",
	},
	["arrancar_valkyrie_noir_f_outfit"] = {
		name = "Tenue Valkyrie (noir)",
		description = "Tenue de Valkyrie, variante noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_feyhbru63dezbuhbze9ze/evo_feyhbru63DEZBUhbze9ze.mdl",
	},
	["arrancar_base_noir_outfit"] = {
		name = "Tenue arrancar base noir",
		description = "Tenue de arrancar basique noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_5g29a2zfyk0lh6z2m/evo_wjbig57x4t4j5mc.mdl",
	},
	-- Pendant FÉMININ de la base noir (Urahara Shop, user 09/19).
	["arrancar_base_noir_f_outfit"] = {
		name = "Tenue arrancar base noir (Femme)",
		description = "Tenue de arrancar basique noir, coupe féminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_52dcfvgbKOJJGBbg5f/evo_52dcfvgbKOJJGBbg5f.mdl",
	},
	["arrancar_masquee_outfit"] = {
		name = "Tenue arrancar masquée",
		description = "Tenue d'arrancar masquée",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_efefr5nh69abgfvxtg54aa/evo_efEFR5nh69abgfvxtg54aa.mdl",
	},
	["arrancar_coyote_starrk_outfit"] = {
		name = "Tenue coyote starrk",
		description = "Tenue de coyote starrk",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_g9d11h1et5ordn0j/evo_bsb3a93l5kpxz0k.mdl",
	},
	["arrancar_coyote_starrk_res_outfit"] = {
		name = "Tenue coyote starrk Resurrección",
		description = "Tenue de coyote starrk en mode Resurrección",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_13fum83l2m68d/evo_53scmh8i1qbv.mdl",
	},
	["arrancar_del_socaccio_outfit"] = {
		name = "Tenue del socaccio",
		description = "Tenue de del socaccio",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_iatx52kx9vowkt/evo_ibdqi1zx0o0yefj.mdl",
	},
	["arrancar_gin_outfit"] = {
		name = "Tenue arrancar gin",
		description = "Tenue de arrancar gin",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_ckq4jy4nj9fb4w/evo_7l8msxinp4m6xj.mdl",
	},
	["arrancar_granz_outfit"] = {
		name = "Tenue arrancar granz",
		description = "Tenue de arrancar granz",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_pbxf571m1swwdor/evo_su117u8894ci1hl.mdl",
	},
	["arrancar_granz_design_outfit"] = {
		name = "Tenue arrancar granz design",
		description = "Tenue de arrancar granz design",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_c6njhkql2hem/evo_83iyq820jz1d7xiux.mdl",
	},
	["arrancar_granz_noir_outfit"] = {
		name = "Tenue arrancar granz noir",
		description = "Tenue de arrancar granz noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_15pzjo6wjmfp/evo_rdhbdb4q94oeuf.mdl",
	},
	["arrancar_granz_rouge_outfit"] = {
		name = "Tenue arrancar granz rouge",
		description = "Tenue de arrancar granz rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_g5lv2gicnks96/evo_7526wz8loans0v.mdl",
	},
	["arrancar_grimmjow_outfit"] = {
		name = "Tenue arrancar grimmjow",
		description = "Tenue de arrancar grimmjow",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_accz9ajqvb9n9/evo_lur2831ujyyp.mdl",
	},
	["arrancar_mosqueda_outfit"] = {
		name = "Tenue arrancar mosqueda",
		description = "Tenue de arrancar mosqueda",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_dtq9wfntlyujoz37/evo_cc9tmnh69avx3laa.mdl",
	},
	["arrancar_torse_ouvert_outfit"] = {
		name = "Tenue arrancar torse ouvert",
		description = "Tenue de arrancar torse ouvert",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_9amr1lxpmmtzbb/evo_77m88rtm7ualnpk.mdl",
	},
	["arrancar_torse_ouvert_noir_outfit"] = {
		name = "Tenue arrancar torse ouvert noir",
		description = "Tenue de arrancar torse ouvert en noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_hx23xkjxx2fb/evo_q06a5gevp50q.mdl",
	},
	["arrancar_torse_ouvert_rose_outfit"] = {
		name = "Tenue arrancar torse ouvert rose",
		description = "Tenue de arrancar torse ouvert en rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_tg8h6mptwr7q428y/evo_ssgv4peglcbe1p.mdl",
	},
	["arrancar_torse_ouvert_violet_outfit"] = {
		name = "Tenue arrancar torse ouvert violet",
		description = "Tenue de arrancar torse ouvert en violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_hr1x80zfmvq0i75w/evo_4eeyhrhji8ef.mdl",
    },

    -- Tenue arrancar équipe (Uahara)
    ["arrancar_equipe_bleu_outfit"] = {
		name = "Tenue arrancar equipe bleu",
		description = "Tenue arrancar equipe bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/arrancar/male/evo_b0xqursm4v8x7wj6/evo_at4m4fqta7d288.mdl",
        is_droppable = true,
		is_deletable = true,
    },
	["arrancar_equipe_orange_outfit"] = {
		name = "Tenue arrancar equipe orange",
		description = "Tenue arrancar equipe orange",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/arrancar/male/evo_t2ebzt3kv58ft2e/evo_mgc0yo9k2n6hgh.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["arrancar_equipe_rouge_outfit"] = {
		name = "Tenue arrancar equipe rouge",
		description = "Tenue arrancar equipe rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/arrancar/male/evo_5adzbqt1km4lz0ufg/evo_npfls3lejzj7n.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["arrancar_equipe_vert_outfit"] = {
		name = "Tenue arrancar equipe vert",
		description = "Tenue arrancar equipe vert",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/arrancar/male/evo_64tqpxh5kxp0pope/evo_pzarobv62vbbjz4bi.mdl",
        is_droppable = true,
		is_deletable = true,
	},

	-- Equipe / entrainement (female) : pendants feminins des 4 tenues ci-dessus.
	-- Le genre est derive du /female/ du model_path (GetItemGender) : pas de champ
	-- `gender` a poser, le filtre boutique + la gate d'equipement suivent tout seuls.
	["arrancar_equipe_bleu_f_outfit"] = {
		-- "entrainement" -> "equipe" (08/17) : le nom historique entrait en collision
		-- avec le NOUVEAU set arrancar_entrainement_* ; aligne sur le pendant male.
		name = "Tenue arrancar equipe bleu (F)",
		description = "Tenue arrancar equipe bleue, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_fefrgtref254grtz/evo_fEFRgtref254grtz.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_equipe_orange_f_outfit"] = {
		name = "Tenue arrancar equipe orange (F)",
		description = "Tenue arrancar equipe orange, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_fersl7opmnref524pz/evo_FERsl7opmnREF524pz.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_equipe_rouge_f_outfit"] = {
		name = "Tenue arrancar equipe rouge (F)",
		description = "Tenue arrancar equipe rouge, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_ref74ferv52zefrefr/evo_ref74FERv52zEFREFR.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_equipe_vert_f_outfit"] = {
		name = "Tenue arrancar equipe vert (F)",
		description = "Tenue arrancar equipe verte, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_erfsl74ferv653ujyz/evo_ERFsl74ferv653ujyz.mdl",
		is_droppable = true,
		is_deletable = true,
	},

	-- Tenues arrancar d'ENTRAINEMENT (Urahara Shop, user 08/17) : set distinct
	-- des tenues "equipe" ci-dessus (couleurs rouge/bleu/violet/vert, pas
	-- d'orange). Genre derive du /male/ ou /female/ du model_path.
	["arrancar_entrainement_rouge_outfit"] = {
		name = "Tenue arrancar entrainement rouge",
		description = "Tenue arrancar d'entrainement rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_dez256dzfe6mferfez/evo_dez256dzfe6mFERfez.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_bleu_outfit"] = {
		name = "Tenue arrancar entrainement bleu",
		description = "Tenue arrancar d'entrainement bleue",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_56perfdzwferref/evo_56pERFdzwFERref.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_violet_outfit"] = {
		name = "Tenue arrancar entrainement violet",
		description = "Tenue arrancar d'entrainement violette",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_dz3rref16psnrefgpmolikjfgm/evo_dz3rREF16psnrefgpmolikjFGm.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_vert_outfit"] = {
		name = "Tenue arrancar entrainement vert",
		description = "Tenue arrancar d'entrainement verte",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_apyh68rferefgwfer/evo_apyh68rFERefgwfer.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_rouge_f_outfit"] = {
		name = "Tenue arrancar entrainement rouge (F)",
		description = "Tenue arrancar d'entrainement rouge, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_azmpoijurgtnv8xpfre/evo_azmpoijuRGTnv8xpFRE.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_bleu_f_outfit"] = {
		name = "Tenue arrancar entrainement bleu (F)",
		description = "Tenue arrancar d'entrainement bleue, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_zdeosl524snv8xerfe/evo_zdeosl524snv8xeRFE.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_violet_f_outfit"] = {
		name = "Tenue arrancar entrainement violet (F)",
		description = "Tenue arrancar d'entrainement violette, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_zed5274snv8xfrrfeedz/evo_zed5274snv8xfrRFEedz.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["arrancar_entrainement_vert_f_outfit"] = {
		name = "Tenue arrancar entrainement vert (F)",
		description = "Tenue arrancar d'entrainement verte, variante feminine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_zed52774snv8xzeehn/evo_zed52774snv8xzeEhn.mdl",
		is_droppable = true,
		is_deletable = true,
	},

	-- TENUE SHINIGAMI Division 2 (Onmitsukidō / assassin) "FEMME"
	["shinigami_assassin_f_outfit"] = {
		name = "Tenue Shinigami assassin feminin",
		description = "Tenue de Shinigami assassin feminin",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_ze2kbmcj0qhi/evo_ejxq5afj8kpi0efe.mdl",
	},

	-- Tenues Division 2 (Onmitsukidō / assassin) — à GIVE en inventaire (pas tenue de base).
	["shinigami_div2_incomplete_f_outfit"] = {
		name = "Tenue Division 2 incomplète (Femme)",
		description = "Tenue d'assassin de la Division 2, version incomplète.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_cygfb52dehzbuvf51njvff/evo_cygfb52DEHZBUvf51NJVFf.mdl",
	},
	["shinigami_div2_complete_f_outfit"] = {
		name = "Tenue Division 2 complète (Femme)",
		description = "Tenue d'assassin de la Division 2, version complète.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_dfgvb6hcb52vejnizfez/evo_dfgvb6HCB52vejniZfez.mdl",
	},

	-- Tenues Shinigami femme de base
	["shinigami_base_f_00_outfit"] = {
		name = "Tenue Shinigami (Femme)",
		description = "Tenue de Shinigami base feminin 00",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_jsypfd09tj73b/evo_c5yvg6qqlcldvywdd.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_base_f_01_outfit"] = {
		name = "Tenue Shinigami Ajustée (Femme)",
		description = "Tenue de Shinigami base feminin 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/female/evo_hv192cuz9jauqlj/evo_5en23p0p6ms18xb.mdl",
		is_droppable = true,
		is_deletable = true,
	},

	-- TENUE SHINIGAMI "HOMME"
	["shinigami_getsuga_base_outfit"] = {
		name = "Tenue Getsuga de base",
		description = "Tenue Getsuga de base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_bsb58ma3xvg3lhrdgkn/evo_bSB58ma3xvg3lhrdgkn.mdl",
	},
	["shinigami_getsuga_design_outfit"] = {
		name = "Tenue Getsuga design",
		description = "Tenue Getsuga design.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_bfdea3xvc253rdgkn/evo_bfdea3xvC253rdgkn.mdl",
	},
	["shinigami_getsuga_dechiree_outfit"] = {
		name = "Tenue Getsuga déchirée",
		description = "Tenue Getsuga déchirée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_qbxr58ma3xhrhrd74kn/evo_QBxr58ma3xhrhrd74kn.mdl",
	},
	["shinigami_getsuga_sombre_outfit"] = {
		name = "Tenue Getsuga sombre",
		description = "Tenue Getsuga sombre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_bedz442a3xvc2ezddgkn/evo_bedz442a3xvC2ezddgkn.mdl",
    },

    -- Tenue Shinigami base
	["shinigami_base_outfit"] = {
		name = "Tenue Shinigami Base",
		description = "Tenue de Shinigami Base",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ahs3t42aet16yyuy4/evo_et09u5e24jmxvdo98.mdl",
    },

	-- Tenues Division 2 (Onmitsukidō / assassin) — à GIVE en inventaire (pas tenue de base).
	["shinigami_service_secret_outfit"] = {
		name = "Tenue Division 2 incomplète",
		description = "Tenue d'assassin de la Division 2, version incomplète.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_jhs4ro28ne0xqfm/evo_mvy95s8x5o5n68f6f.mdl",
	},
	["shinigami_service_secret_special_outfit"] = {
		name = "Tenue Division 2 complète",
		description = "Tenue d'assassin de la Division 2, version complète.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_5c00693tw73z086m/evo_egop39anu34hw.mdl",
	},

	-- Capitaine commandant Homme
	["shinigami_capitaine_commandant_outfit"] = {
		name = "Tenue shinigami capitaine commandant",
		description = "Tenue de capitaine commandant",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_l8vew1895j9of802e/evo_h4o6u313ge02tcier.mdl",
    },

    ["shinigami_equipe_bleu_outfit"] = {
		name = "Tenue shinigami equipe bleu",
		description = "Tenue de shinigami equipe bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_rtfp3v9g40r77r/evo_20z3ij9494dv.mdl",
		is_droppable = true,
		is_deletable = true,
	},

    -- Boutique Shinigami Homme
    ["shinigami_demi_torse_bandage_outfit"] = {
		name = "Tenue shinigami demi torse bandage",
		description = "Tenue de shinigami torse ouvert avec bandage",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_m8tyhg900grem/evo_ub7x325acphuv.mdl",
	},
	["shinigami_demi_torse_bandage_overlay_outfit"] = {
		name = "Tenue shinigami demi torse bandage overlay",
		description = "Tenue de shinigami torse ouvert avec bandage et tissu noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_l4mmfn91rlmoebe3d/evo_56tw8j0ac7zwr4.mdl",
    },

    -- Boutique
	["shinigami_ichigo_chaine_outfit"] = {
		name = "Tenue shinigami ichigo chaine",
		description = "Tenue de shinigami ichigo chaine",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_2z9npx5ja275hsb/evo_fy8ues3qp0ws3s4dp.mdl",
	},
	["shinigami_ichigo_chaine_bleu_outfit"] = {
		name = "Tenue shinigami ichigo chaine bleu",
		description = "Tenue de shinigami ichigo chaine en bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_nvglan8qhop8f3t/evo_yeliktpz19p5xjpgu.mdl",
	},
	["shinigami_ichigo_chaine_dore_outfit"] = {
		name = "Tenue shinigami ichigo chaine dore",
		description = "Tenue de shinigami ichigo chaine en dore",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_hqvd50bcnchg/evo_xrfnlmecmmv7udr.mdl",
	},
	["shinigami_ichigo_chaine_rouge_outfit"] = {
		name = "Tenue shinigami ichigo chaine rouge",
		description = "Tenue de shinigami ichigo chaine en rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_z64oy2er5az9/evo_ujmtvb3s1daf6ouf.mdl",
	},
	["shinigami_ichigo_chaine_violet_outfit"] = {
		name = "Tenue shinigami ichigo chaine violet",
		description = "Tenue de shinigami ichigo chaine en violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_9fsbowoq2xk8/evo_0yg0704aaa15px.mdl",
	},
	["shinigami_ichigo_tybw_outfit"] = {
		name = "Tenue shinigami ichigo tybw",
		description = "Tenue de ichigo tybw",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_146mtio42ykg809/evo_stl4ijxam5nuk.mdl",
	},
	["shinigami_kenpachi_special_red_outfit"] = {
		name = "Tenue shinigami kenpachi or",
		description = "Tenue de kenpachi or",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_6oj43hm9v0vnf4ndr/evo_oldqyde0w75i.mdl",
	},
	["shinigami_kenpachi_special_blanc_outfit"] = {
		name = "Tenue shinigami kenpachi blanc",
		description = "Tenue de kenpachi blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_qgj2h72l6bxbadf/evo_yz67yxmnov2dl6.mdl",
	},
	["shinigami_kenpachi_special_noir_outfit"] = {
		name = "Tenue shinigami kenpachi noir",
		description = "Tenue de kenpachi noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_d6ghmgfi905u71p/evo_b0belqp6868lw4ju.mdl",
	},
	["shinigami_martiale_outfit"] = {
		name = "Tenue shinigami martiale",
		description = "Tenue de shinigami martiale",
		icon = "inventory/items/item_2.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_1kaxdpn9ibrw4n2j/evo_tyh4as0culm1d53.mdl",
	},
	["shinigami_martiale_noir_outfit"] = {
		name = "Tenue shinigami martiale noire",
		description = "Tenue de shinigami martiale, version noire",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_98jvhrbjceuhvfn3v62rk/evo_98JVHRBjceuhvfn3v62rk.mdl",
	},
	["shinigami_martiale_design_outfit"] = {
		name = "Tenue shinigami martiale design",
		description = "Tenue de shinigami martiale, version design",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_hvgf9ea1g6jhe4e8efuehf/evo_hvGF9ea1g6JHE4e8efUEHF.mdl",
    },

	-- ─── Tenues Shinigami homme (ajouts 2026-07) ───
	-- Urahara Shop (Yens)
	["shinigami_brume_silencieuse_outfit"] = {
		name = "Tenue brume silencieuse",
		description = "Tenue de shinigami — brume silencieuse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_958ijurgtgtejfge/evo_958IJURGTgtejfge.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_encre_sacree_outfit"] = {
		name = "Tenue de l'encre sacrée",
		description = "Tenue de shinigami — encre sacrée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_devg63fvrin62grokiehuz/evo_devg63FVRIN62grokiehuz.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_plumes_blanches_outfit"] = {
		name = "Tenue de plumes blanches",
		description = "Tenue de shinigami — plumes blanches.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path =
        "models/evo/characters/shinigami/male/evo_fhbu62656rgtrfehbuarefref/evo_FHBU62656rgtRFEHBUAREFref.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_eclipse_outfit"] = {
		name = "Tenue de l'Éclipse",
		description = "Tenue de shinigami — l'Éclipse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_fhbuferjhbfehnbj/evo_fhbuFERJHBfehnbj.mdl",
        is_droppable = true,
		is_deletable = true,
    },
	["shinigami_equipe_orange_outfit"] = {
		name = "Tenue shinigami equipe orange",
		description = "Tenue de shinigami equipe orange",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_zzws3b3z9ajzdjx/evo_u7rvuj51qzf0cvodn.mdl",
        is_droppable = true,
		is_deletable = true,
	},
	["shinigami_equipe_rouge_outfit"] = {
		name = "Tenue shinigami equipe rouge",
		description = "Tenue de shinigami equipe rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_wo1qbfcdtzs4mmu5/evo_9u63qptm9puvny8.mdl",
		is_droppable = true,
		is_deletable = true,
	},
	["shinigami_equipe_vert_outfit"] = {
		name = "Tenue shinigami equipe vert",
		description = "Tenue de shinigami equipe vert",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_w66jkifp2tp9b2/evo_m768wkzqwv23ho6.mdl",
		is_droppable = true,
		is_deletable = true,
    },
    ["shinigami_manche_longue_outfit"] = {
		name = "Tenue shinigami manche longue",
		description = "Tenue de shinigami avec manche longue",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_cb3f2s3r371ev9ye/evo_tlrt3p20bir9.mdl",
		is_droppable = true,
		is_deletable = true,
    },
    ["shinigami_sans_manche_outfit"] = {
		name = "Tenue shinigami sans manche",
		description = "Tenue de shinigami sans manche",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_jn3fhp7c048ia/evo_c4lqn0hzhnyyu.mdl",
		is_droppable = true,
		is_deletable = true,
    },
	["shinigami_shuhei_hisagi_outfit"] = {
		name = "Tenue shinigami shuhei hisagi",
		description = "Tenue de shuhei hisagi",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
        model_path = "models/evo/characters/shinigami/male/evo_xquhn0z0b1jk8/evo_a2342mygla2xg.mdl",
        is_droppable = true,
		is_deletable = true,
	},

	-- Boutique (coins)
	["shinigami_ombres_pourpres_outfit"] = {
		name = "Tenue des ombres pourpres",
		description = "Tenue de shinigami — ombres pourpres.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_bggfoeyhbbr5d6rhvgfr/evo_bGGFOEYHbbr5d6rhVGfr.mdl",
	},
	["shinigami_aube_doree_outfit"] = {
		name = "Tenue de l'aube dorée",
		description = "Tenue de shinigami — aube dorée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_fvhbu62htoitgrhrgef/evo_FVHBU62htoiTGRHrgef.mdl",
	},
	["shinigami_tempete_spirituelle_outfit"] = {
		name = "Tenue tempête spirituelle",
		description = "Tenue de shinigami — tempête spirituelle.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_gvhnbjgb62ze9ihgbfg/evo_GVHNBJgb62ze9IHGBfg.mdl",
	},
	["shinigami_renji_design_outfit"] = {
		name = "Tenue shinigami renji blanc",
		description = "Tenue de shinigami renji blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_vr295ywk1nzfyx9h/evo_sgzchiddn6spjqez.mdl",
	},
	["shinigami_renji_design_blanc_outfit"] = {
		name = "Tenue shinigami renji blanc",
		description = "Tenue de shinigami renji blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_a6xg2vyqsp0r00vgy/evo_nbfhq605jgzt2yb8.mdl",
	},
	["shinigami_renji_design_bleu_outfit"] = {
		name = "Tenue shinigami renji bleu",
		description = "Tenue de shinigami renji bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_s901tsxzh2htdx/evo_zova3i4u69eqv7.mdl",
	},
	["shinigami_renji_design_rose_outfit"] = {
		name = "Tenue shinigami renji rose",
		description = "Tenue de shinigami renji rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_406z4uaehwp78cuvk/evo_u3mtzgt3ox8usx2.mdl",
	},
	["shinigami_renji_design_vert_outfit"] = {
		name = "Tenue shinigami renji vert",
		description = "Tenue de shinigami renji vert",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_tngcsj1oi78m/evo_6zai899bb8zn.mdl",
	},
	["shinigami_torse_nue_outfit"] = {
		name = "Tenue shinigami torse nue",
		description = "Tenue torse nue",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_ye0xuxc1y3wcnjf/evo_gbj2bve3nk4rkhkqx.mdl",
	},
	["shinigami_veteran_outfit"] = {
		name = "Tenue shinigami veteran",
		description = "Tenue de shinigami veteran",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_85yolymyfm4i8/evo_0kj98n1oiz6s1.mdl",
	},
	["shinigami_veteran_design_outfit"] = {
		name = "Tenue shinigami veteran design",
		description = "Tenue de shinigami veteran design",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_20g91lsd72y9/evo_gysk5g5eyfsch3w4.mdl",
	},
	["shinigami_veteran_inverse_outfit"] = {
		name = "Tenue shinigami veteran inverse",
		description = "Tenue de shinigami veteran inverse",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_1k8bhgclrqng3u8d/evo_oriqgykpuhzc.mdl",
	},
	["shinigami_veteran_noir_blanc_outfit"] = {
		name = "Tenue shinigami veteran noir & blanc",
		description = "Tenue de shinigami veteran noir et blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_jw7f96emroisc5as/evo_yov9fp3y52b3j5yhh.mdl",
	},
	["shinigami_Yumichika_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_hoy9n24a4me03/evo_nroa4mz75lxtsi.mdl",
	},
	["shinigami_Yumichika_blanc_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_vyycr5o5hg9ndmx24/evo_nhdhcgjlxrcwj5bxc.mdl",
	},
	["shinigami_Yumichika_bleu_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_xztj3hkvlmdxugs1/evo_mponkuxf64p7.mdl",
	},
	["shinigami_Yumichika_jaune_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_glou4s3tgu92mth/evo_364c44g7drlqg.mdl",
	},
	["shinigami_Yumichika_rouge_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_tw2lg7so16seb96/evo_qy5zev60b4xe2r.mdl",
	},
	["shinigami_Yumichika_vert_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_nv3m3w2f5i62hbi20/evo_uc91zylaijrx.mdl",
	},
	["shinigami_Yumichika_violet_outfit"] = {
		name = "Tenue shinigami Yumichika",
		description = "Tenue de Yumichika",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ftrfdycpwmg2yh/evo_h2tlswt1wqplc5y.mdl",
	},
	["shinigami_zabimaru_outfit"] = {
		name = "Tenue Shinigami zabimaru",
		description = "Tenue de Shinigami style zabimaru",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_2b8lcj16icob/evo_bbvzi43hn4mg0h99.mdl",
	},
	["shinigami_zabimaru_blanc_outfit"] = {
		name = "Tenue Shinigami zabimaru en blanc",
		description = "Tenue de Shinigami style zabimaru en blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_vwybb0b5ywqkgl/evo_9d532qyf64ff.mdl",
	},
	["shinigami_zabimaru_bleu_outfit"] = {
		name = "Tenue Shinigami zabimaru en bleu",
		description = "Tenue de Shinigami style zabimaru en bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_cuk4see8z234/evo_89iohmppkwzq.mdl",
	},
	["shinigami_zabimaru_rose_outfit"] = {
		name = "Tenue Shinigami zabimaru en rose",
		description = "Tenue de Shinigami style zabimaru en rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_tfapx6ptvvr4j03m/evo_h96ik5zxar9e.mdl",
	},
	["shinigami_zabimaru_vert_outfit"] = {
		name = "Tenue Shinigami zabimaru en vert",
		description = "Tenue de Shinigami style zabimaru en vert",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_cflxqb3z24auhvinx/evo_yadit43g37ur11i.mdl",
	},

	-- Exclusif T2 T3
	["lunette_large_04"] = {
		name = "Lunettes d'Aizen",
		description = "Les lunettes d'Aizen Sosuke",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_9rshshwiuq63m4/evo_fvq1qlot78lh3mz7p.mdl",
	},

	-- Sac de la Division 4 : à GIVE en inventaire à TOUS les membres de la division.
	["sac_division_4"] = {
		name = "Sac Division 4",
		description = "Sac de secours des membres de la Division 4.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/evo_sjp4twaalatsdzlev/evo_9fll4f1uyp2trha.mdl",
    },

    -- Clan
    ["gourde_shiba"] = {
		name = "gourde shiba",
		description = "gourde de la famille shiba",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/evo_ovjv25alv0sx1/evo_fxr8rwzyisehek11i.mdl",
	},

	-- Accessoire boutique
	["arr_mask_forehead_01"] = {
		name = "Masque Frontal",
		description = "Arr Mask forehead 01",
		icon = "inventory/items/item_2.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_gsxceg4xdlb9mbw/evo_rexojs3p0953g7r0.mdl",
	},
	["arr_mask_full_01"] = {
		name = "Masque du Vide",
		description = "Arr Mask Full 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_3y7lrln17l2ic/evo_6ns2txuap1pyqb2h3.mdl",
	},
	["arr_mask_full_02"] = {
		name = "Masque Spectral",
		description = "Arr Mask Full 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_5cmv3yiefamx2/evo_axldp7nzl17o6yw79.mdl",
	},
	["arr_mask_full_03"] = {
		name = "Masque Abyssal",
		description = "Arr Mask Full 03",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_wkywacjapr5no1f/evo_6wfn5jxisdxmbxzb.mdl",
	},
	["arr_mask_full_04"] = {
		name = "Masque du Néant",
		description = "Arr Mask Full 04",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_052ekb4cizf73/evo_o5utadh0tzm1rv0z.mdl",
	},
	["arr_mask_full_05"] = {
		name = "Masque Fantomatique",
		description = "Arr Mask Full 05",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_wx9f2gdthmho6k9/evo_4li202bcmthl226w.mdl",
	},
	["arr_mask_full_06"] = {
		name = "Masque Maudit",
		description = "Arr Mask Full 06",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_khnx730j8lfnbwn/evo_tts9phj12b6zql.mdl",
	},
	["arr_mask_full_07"] = {
		name = "Masque Démoniaque",
		description = "Arr Mask Full 07",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_6t4o53906yrof/evo_17l82wl75llpt5.mdl",
	},
	["arr_mask_full_08"] = {
		name = "Masque Sépulcral",
		description = "Arr Mask Full 08",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_j9mhn58i20f50c1/evo_qza963n1puyum5r8.mdl",
	},
	["arr_mask_full_09"] = {
		name = "Masque Nocturne",
		description = "Arr Mask Full 09",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_e8ya4ii6sfvzt/evo_alupk3griu8iumv9o.mdl",
	},
	["arr_mask_full_10"] = {
		name = "Masque Souverain",
		description = "Arr Mask Full 10",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_i6b62nzxmqqpghp4w/evo_x1ltpjw4bmdmxqt.mdl",
	},
	["arr_mask_half_left_01"] = {
		name = "Demi-Masque Gauche",
		description = "Arr Mask horn left 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_fnz3l4e1pdqsu0p/evo_pf5wke9l0qld1.mdl",
	},
	["arr_mask_half_full_01"] = {
		name = "Demi-Masque",
		description = "Arr Mask horn full 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_tg3c1bsbnl840xm/evo_suxziw9w56bl.mdl",
	},
	["arr_mask_horn_left_01"] = {
		name = "Corne Gauche Ichigo TYWB",
		description = "Arr Mask horn left 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_c3pfghd9yjy4nd/evo_6ydtsxbv824s39lp.mdl",
	},
	["arr_mask_horn_right_01"] = {
		name = "Masque Corne Droite",
		description = "Arr Mask horn right 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_30nsqb2s2ubnacoa/evo_8y9ea4ek00jncr7x.mdl",
	},
	["arr_mask_jaw_01"] = {
		name = "Masque Mâchoire",
		description = "Arr Mask jaw 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_ex8ywr1632ctwf/evo_e8o9hfzl9du9rzp.mdl",
	},
	["arr_mask_jaw_01_left"] = {
		name = "Arr Mask jaw 01 left",
		description = "Arr Mask jaw 01 left",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_49hs7plaroso9/evo_8yhn2esj2pk3.mdl",
	},
	["arr_mask_jaw_01_right"] = {
		name = "Arr Mask jaw 01 right",
		description = "Arr Mask jaw 01 right",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_tkisi290krwxo/evo_c61xbadjbvt3jt9c9.mdl",
	},
	["arr_mask_jaw_02"] = {
		name = "Masque Grimmjow",
		description = "Arr Mask jaw 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_175k3bks52m9ae/evo_95rjwhf301m4b.mdl",
	},
	["arr_mask_jaw_02_full"] = {
		name = "Arr Mask jaw 02 full",
		description = "Arr Mask jaw 02 full",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/evo_ymc1kp8n43fy2peoa/evo_j51la238udw8.mdl",
	},
	["arr_mask_jaw_02_left"] = {
		name = "Arr Mask jaw 02 left",
		description = "Arr Mask jaw 02 left",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/evo_5ul7sfash9p9qq/evo_jyxzw4qb1mqmz.mdl",
	},
	["arr_mask_skull_horn_01"] = {
		name = "Masque Crâne Cornu",
		description = "Arr Mask Skull Horn 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_c42l2f7xerxf/evo_cw8nls87f1x9.mdl",
	},
	["arr_mask_skull_horn_02"] = {
		name = "Masque Ichigo TYWB",
		description = "Arr Mask Skull Horn 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_4si66cbmqdpnasl/evo_m3jzi0ebalc1ttim.mdl",
	},
	["arr_mask_skull_horn_02_full"] = {
		name = "Arr Mask Skull Horn 02 full",
		description = "Arr Mask Skull Horn 02 full",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_95ofzh372j70jee/evo_nh45akaw0ebvx.mdl",
	},
	["arr_mask_skull_horn_02_right"] = {
		name = "Arr Mask Skull Horn 02 right",
		description = "Arr Mask Skull Horn 02 right",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_a4i7j9j2eunroh/evo_9860tnx7zrased.mdl",
	},
	["arr_mask_skull_horn_03"] = {
		name = "Masque du Damné",
		description = "Arr Mask Skull Horn 03",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/evo_14uwrrj4ufl500zv/evo_hz3sa0hc7a87f.mdl",
	},
	["arr_mask_skull_horn_03_full"] = {
		name = "Arr Mask Skull Horn 03 full",
		description = "Arr Mask Skull Horn 03 full",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_ttj669roym51e6/evo_82ehvdq82ssmbrfc.mdl",
	},
	["arr_mask_skull_horn_03_right"] = {
		name = "Arr Mask Skull Horn 03 right",
		description = "Arr Mask Skull Horn 03 right",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_m55tzmjm1cwosev/evo_7xqk1ckjnu2c4d.mdl",
	},
	["arr_mask_skull_horn_04"] = {
		name = "Masque du Faucheur",
		description = "Arr Mask Skull Horn 04",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/evo_i2zxzzp6q8oq7ft/evo_aea5bd6mrb99mvnwx.mdl",
	},
	["arr_mask_skull_horn_05"] = {
		name = "Masque Ossuaire",
		description = "Arr Mask Skull Horn 05",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_mhsv45ukocwdk/evo_0up6ccj9knc7t.mdl",
	},

	-- ══════════════════════════════════════════════════════════════════════════
	-- MASQUES D'ANONYMAT (demande user 09/08) — vendus chez Urahara, TOUTES FACTIONS.
	-- Un seul modèle, 4 variantes de texturegroup -> 4 entrées avec le MÊME model_path
	-- et un `skin` différent. Même patron que chapeau_urahara_violet/jaune/rouge/bleu.
	--
	-- `slot = "mask"` (et NON "head") : c'est CE champ qui les route vers le slot 7,
	-- la case masque à côté du katana (ACCESSORY_SLOT_BY_NAME.mask = 7). Les masques
	-- Arrancar, eux, y arrivent par leur chemin « /arr_mask/ » — ce modèle-ci n'est pas
	-- rangé là, donc GetItemFaction lui renvoie nil : il est NEUTRE, un Shinigami peut
	-- l'équiper sans aucun gate à lever côté serveur.
	--
	-- ⚠️ `skin` EXPLICITE sur les quatre, y compris la variante 0 : sans ce champ,
	-- l'aperçu 3D de l'inventaire applique la RARETÉ comme numéro de skin — la vignette
	-- ne montrerait pas la même texture que le masque réellement porté.
	-- ⚠️ CASSE DU CHEMIN : dossier en minuscules, fichier en casse MIXTE (...ERG52.mdl).
	-- Le serveur est Linux : tout lowercaser rend le masque INVISIBLE.
	-- ⚠️ Les skins sont 0-indexés côté moteur : « texturegroup 1 à 4 » = skins 0,1,2,3.
	-- Pour vérifier en jeu : evo_item_bounds <chemin du .mdl> imprime le nombre de skins.
	--
	-- `hide_name = true` est le champ MÉTIER lu par INVENTORY_CONFIG.ItemHidesIdentity :
	-- c'est lui, et pas l'id de l'item, qui déclenche l'anonymat. Un futur masque
	-- anonymisant n'aura qu'à porter ce champ.
	["masque_anonyme_01"] = {
		name = "Masque d'Anonymat I",
		description = "Un masque sans marque. Tant que tu le portes, personne ne peut mettre un nom sur ton visage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "mask",
		rarity = "rare",
		faction = "all",
		hideable = false, -- pas d'œil « cacher » : sinon nom masqué ET masque invisible
		hide_name = true,
		skin = 0,
		model_path = "models/evo/accessories/head/evo_dez9ref73rgfterg52/evo_dez9ref73rgftERG52.mdl",
	},
	["masque_anonyme_02"] = {
		name = "Masque d'Anonymat II",
		description = "Un masque sans marque. Tant que tu le portes, personne ne peut mettre un nom sur ton visage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "mask",
		rarity = "rare",
		faction = "all",
		hideable = false,
		hide_name = true,
		skin = 1,
		model_path = "models/evo/accessories/head/evo_dez9ref73rgfterg52/evo_dez9ref73rgftERG52.mdl",
	},
	["masque_anonyme_03"] = {
		name = "Masque d'Anonymat III",
		description = "Un masque sans marque. Tant que tu le portes, personne ne peut mettre un nom sur ton visage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "mask",
		rarity = "rare",
		faction = "all",
		hideable = false,
		hide_name = true,
		skin = 2,
		model_path = "models/evo/accessories/head/evo_dez9ref73rgfterg52/evo_dez9ref73rgftERG52.mdl",
	},
	["masque_anonyme_04"] = {
		name = "Masque d'Anonymat IV",
		description = "Un masque sans marque. Tant que tu le portes, personne ne peut mettre un nom sur ton visage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "mask",
		rarity = "rare",
		faction = "all",
		hideable = false,
		hide_name = true,
		skin = 3,
		model_path = "models/evo/accessories/head/evo_dez9ref73rgfterg52/evo_dez9ref73rgftERG52.mdl",
	},
	["bandeau_front_01"] = {
		name = "Bandeau Frontal",
		description = "Bandeau Front 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_jd9l6pjy3wogrd2sc/evo_xzu35ih0ktfzd.mdl",
	},
	["cache_oeil_droit_01"] = {
		name = "Cache-Œil Droit",
		description = "cache oeil droit",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_8ncfknhamu7b2ks6/evo_7ofvecgtcdw6ks.mdl",
	},
	["cache_oeil_droit_02"] = {
		name = "Bandeau Œil Droit",
		description = "cache oeil droit",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_8dda4xyqghdp4625/evo_r9icemq1z3z5gbox4.mdl",
	},
	["cache_oeil_droit_03"] = {
		name = "Cache-Œil Droit Renforcé",
		description = "cache oeil droit",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_dorfd8653f7e59/evo_8q0fixz42hwecsc.mdl",
	},
	["cache_oeil_gauche_01"] = {
		name = "Cache-Œil Gauche",
		description = "Cache Oeil Gauche 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_qh9rii1kb4bifk/evo_vxuoqntqusomeych.mdl",
	},
	["cache_oeil_gauche_02"] = {
		name = "Bandeau Œil Gauche",
		description = "Cache Oeil Gauche 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_fd1nsa7feej433gq/evo_eeqfsb54y0abbqqs.mdl",
	},
	["cache_oeil_gauche_03"] = {
		name = "Cache-Œil Gauche Renforcé",
		description = "Cache Oeil Gauche 03",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_bqruubqii1pfaww/evo_35vgwf8uumhty3.mdl",
	},
	["cache_oeil_large_01"] = {
		name = "Cache-Œil Large",
		description = "cache oeil large",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_nn3k9cv5jp465o/evo_c3de3rc1urjo6.mdl",
	},
	["cache_oeil_large_02"] = {
		name = "Grand Cache-Œil",
		description = "cache oeil large",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_b8uxtf7h6rkviycmb/evo_fbxxz0atyr7xsy0.mdl",
	},
	["lunette_detective"] = {
		name = "lunette detective",
		description = "lunette de detective",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_7hcznewyxq04b/evo_2fblr0pixlcd.mdl",
	},
	["lunette_large_01"] = {
		name = "Grandes Lunettes",
		description = "Lunette Large 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_x8r36j3wpj2tuw1/evo_3qanlmqbdekzspoe5.mdl",
	},
	["lunette_large_02"] = {
		name = "Lunettes Larges",
		description = "Lunette Large 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_xkh4hqtm1w5o32a/evo_3n5ndo6ecvlkelz.mdl",
	},
	["lunette_large_03"] = {
		name = "Lunettes Rétro",
		description = "Lunette Large 03",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_n6alqecu5cylprunh/evo_9qeuz0lggzbi8oghr.mdl",
	},
	["lunette_renji_01"] = {
		name = "Lunettes de Renji",
		description = "Lunette Renji 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_yg2ll15eecawvbi/evo_hqq3qc97kj2u.mdl",
	},
	["lunette_renji_02"] = {
		name = "Lunettes de Renji Sombres",
		description = "Lunette Renji 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_9jve1jwm7xbnbu/evo_yi6qrgpqt97zqm9g.mdl",
	},
	["lunette_ronde_01"] = {
		name = "lunette ronde",
		description = "lunette ronde",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_hx3uianwi9lx/evo_nijwaf7u3gmc5xjy.mdl",
	},
	["lunette_sans_verre_00"] = {
		name = "lunette sans verre",
		description = "lunette sans verre",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_i1ewlff13xiruqa/evo_3g4ztsx5uifkm.mdl",
	},
	["lunette_sans_verre_01"] = {
		name = "Lunettes sans Verre Fines",
		description = "lunette sans verre 01",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "common",
		model_path = "models/evo/accessories/head/evo_5a9g5bd9bgs5w/evo_ilfshh4oniijvbp1.mdl",
	},
	["lunette_tosen_01"] = {
		name = "Lunettes de Tosen",
		description = "Les lunettes de Kaname Tosen",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_5vsfei3n568jgrg/evo_5vsfei3n568jgrg.mdl",
	},
	["lunette_tosen_02"] = {
		name = "Lunettes de Tosen Sombres",
		description = "Lunette Tosen 02",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_5gb6oei3n5cpy7a0n/evo_5gb6oei3n5CPY7a0n.mdl",
	},
	["cache_oeil_nnoitra"] = {
		name = "Cache-Œil de Nnoitra",
		description = "Le cache-oeil de Nnoitra Gilga",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_fzh4on85trgqrfbp1/evo_fzh4on85trgqRFbp1.mdl",
	},
	["lunette_zangetsu"] = {
		name = "Lunettes de Zangetsu",
		description = "Les lunettes de Zangetsu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_ifrgr5jgfhedz3unhefdz/evo_ifrgr5JGFHedz3UNHefdz.mdl",
	},
	["lunette_granz"] = {
		name = "Lunettes de Granz",
		description = "Les lunettes de Szayelaporro Granz",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_izdh4oniij963yhvfdp1/evo_izdh4oniij963yhVFDp1.mdl",
	},
	["chapeau_urahara"] = {
		name = "Chapeau d'Urahara",
		description = "Le chapeau de Kisuke Urahara",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_731ezfdoei3n5z72tg7nn/evo_731ezfdoei3n5z72tg7nn.mdl",
	},
	["chapeau_shunsui"] = {
		name = "Chapeau de Shunsui",
		description = "Le chapeau de Shunsui Kyoraku",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		model_path = "models/evo/accessories/head/evo_bfbbfi3n69qupyegn/evo_bfbbfi3n69QUPYegn.mdl",
	},
	["chapeau_urahara_violet"] = {
		name = "Chapeau d'Urahara (Violet)",
		description = "Le chapeau de Kisuke Urahara, teinte violette",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 1,
		model_path = "models/evo/accessories/head/evo_731ezfdoei3n5z72tg7nn/evo_731ezfdoei3n5z72tg7nn.mdl",
	},
	["chapeau_urahara_jaune"] = {
		name = "Chapeau d'Urahara (Jaune)",
		description = "Le chapeau de Kisuke Urahara, teinte jaune",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 2,
		model_path = "models/evo/accessories/head/evo_731ezfdoei3n5z72tg7nn/evo_731ezfdoei3n5z72tg7nn.mdl",
	},
	["chapeau_urahara_rouge"] = {
		name = "Chapeau d'Urahara (Rouge)",
		description = "Le chapeau de Kisuke Urahara, teinte rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 3,
		model_path = "models/evo/accessories/head/evo_731ezfdoei3n5z72tg7nn/evo_731ezfdoei3n5z72tg7nn.mdl",
	},
	["chapeau_urahara_bleu"] = {
		name = "Chapeau d'Urahara (Bleu)",
		description = "Le chapeau de Kisuke Urahara, teinte bleue",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 4,
		model_path = "models/evo/accessories/head/evo_731ezfdoei3n5z72tg7nn/evo_731ezfdoei3n5z72tg7nn.mdl",
	},
	["chapeau_shunsui_noir_rouge"] = {
		name = "Chapeau de Shunsui (Noir-Rouge)",
		description = "Le chapeau de Shunsui Kyoraku, teinte noir et rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 1,
		model_path = "models/evo/accessories/head/evo_bfbbfi3n69qupyegn/evo_bfbbfi3n69QUPYegn.mdl",
	},
	["chapeau_shunsui_beige_violet"] = {
		name = "Chapeau de Shunsui (Beige-Violet)",
		description = "Le chapeau de Shunsui Kyoraku, teinte beige et violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 2,
		model_path = "models/evo/accessories/head/evo_bfbbfi3n69qupyegn/evo_bfbbfi3n69QUPYegn.mdl",
	},
	["chapeau_shunsui_vert"] = {
		name = "Chapeau de Shunsui (Vert)",
		description = "Le chapeau de Shunsui Kyoraku, teinte verte",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 3,
		model_path = "models/evo/accessories/head/evo_bfbbfi3n69qupyegn/evo_bfbbfi3n69QUPYegn.mdl",
	},
	["chapeau_shunsui_noir_bleu"] = {
		name = "Chapeau de Shunsui (Noir-Bleu)",
		description = "Le chapeau de Shunsui Kyoraku, teinte noir et bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head", -- head, cape, necklace, ring, belt
		rarity = "legendary",
		skin = 4,
		model_path = "models/evo/accessories/head/evo_bfbbfi3n69qupyegn/evo_bfbbfi3n69QUPYegn.mdl",
	},
	["aile_cirucci"] = {
		name = "aile cirucci",
		description = "aile de cirucci",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/evo_e9gkxt6ft803u33vu/evo_wakky5lndqll4g2.mdl",
	},
	["cape_shini_base"] = {
		name = "cape shinigami base",
		description = "cape shinigami de base",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/evo_itblmwhw1wa6kn/evo_vwxv2u8abin1h.mdl",
	},
	-- Cape Yamamoto MODIFIÉE (user 09/16) : donnée par le menu SAM (giveitem)
	-- uniquement — dans aucune boutique, aucun coffre, aucune table de loot.
	-- always_visible (user 09/16) : dessinée sur les AUTRES joueurs même quand leur
	-- menu Optimisations masque les accessoires (préréglage Faible / distance) — même
	-- régime que les insignes de grade (cf. INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel).
	["cape_yamamoto_modifiee"] = {
		name = "Cape Yamamoto modifiée",
		description = "Version modifiée de la cape de Yamamoto.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		always_visible = true,
		model_path = "models/evo/accessories/body/evo_526HRFVGfer5263fg/evo_526HRFVGfer5263fg.mdl",
	},

	-- ── ACCESSOIRES DES PASSES PLANIFIÉS (demande user 2026-09-16) ─────────────────────────
	-- Récompenses de lzy_battlepass/config.lua `BATTLEPASS_CONFIG.seasons` (palier 15 de
	-- chaque piste). Ni boutique ni coffre (absents de COSMETIQUES_CONFIG / coffre_only) :
	-- exclusifs au pass. head = tenu en bouche / dans les cheveux / dans la nuque ; cape =
	-- slot des accessoires de CORPS (ceinture, corde), comme les pets d'épaule et les capes.
	-- Aperçu 3D via model_path (cl_item_preview_model), l'icône n'est qu'un repli.
	-- Gratuit = epic, premium = legendary (comme les armes du pass).
	["bp_bouche_brin_riz"] = { -- pass « octobre » (2026-10-08 -> 2026-11-17), GRATUIT
		name = "Brin de riz",
		description = "Un brin de riz tenu dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bp_bouche_brin_riz/bp_bouche_brin_riz.mdl",
	},
	["bp_peigne_vagues"] = { -- pass « octobre » (2026-10-08 -> 2026-11-17), PREMIUM
		name = "Peigne des vagues",
		description = "Un peigne orné de vagues, porté dans les cheveux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bp_peigne_vagues/bp_peigne_vagues.mdl",
	},
	["bp_bouche_pinceau"] = { -- pass « novembre » (2026-11-17 -> 2026-12-27), GRATUIT
		name = "Pinceau de voyage",
		description = "Un pinceau de voyage tenu dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bp_bouche_pinceau/bp_bouche_pinceau.mdl",
	},
	["bp_bourse_sel_rituel"] = { -- pass « novembre » (2026-11-17 -> 2026-12-27), PREMIUM
		name = "Bourse de sel rituel",
		description = "Une bourse de sel rituel accrochée à la ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/bp_bourse_sel_rituel/bp_bourse_sel_rituel.mdl",
	},
	["bp_bouche_billet_plie"] = { -- pass « décembre » (2026-12-27 -> 2027-02-05), GRATUIT
		name = "Billet de prière plié",
		description = "Un billet de prière plié tenu dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bp_bouche_billet_plie/bp_bouche_billet_plie.mdl",
	},
	["bp_eventail_nuque"] = { -- pass « décembre » (2026-12-27 -> 2027-02-05), PREMIUM
		name = "Éventail de nuque",
		description = "Un éventail glissé dans la nuque.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bp_eventail_nuque/bp_eventail_nuque.mdl",
	},
	["bp_bouche_prunier"] = { -- pass « janvier » (2027-02-05 -> 2027-03-17), GRATUIT
		name = "Branche de prunier",
		description = "Une branche de prunier tenue dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bp_bouche_prunier/bp_bouche_prunier.mdl",
	},
	["bp_renard_ceinture"] = { -- pass « janvier » (2027-02-05 -> 2027-03-17), PREMIUM
		name = "Renard de ceinture",
		description = "Un petit renard accroché à la ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/bp_renard_ceinture/bp_renard_ceinture.mdl",
	},
	["bp_corde_shimenawa"] = { -- pass « février » (2027-03-17 -> 2027-04-26), GRATUIT
		name = "Corde shimenawa",
		description = "Une corde shimenawa portée autour du corps.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/bp_corde_shimenawa/bp_corde_shimenawa.mdl",
	},
	["bp_bouche_kiseru"] = { -- pass « février » (2027-03-17 -> 2027-04-26), PREMIUM
		name = "Kiseru de jade",
		description = "Une pipe kiseru de jade tenue dans la bouche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bp_bouche_kiseru/bp_bouche_kiseru.mdl",
	},
	["cape_epaule_gauche"] = {
		name = "cape epaule gauche",
		description = "cape sur l'epaule gauche",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/evo_3l1y79inj5gy7hazj/evo_p6d8kwjvofyvyl1.mdl",
	},
	["echarpe_courte"] = {
		name = "echarpe courte",
		description = "echarpe courte",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_kuchiki"] = {
		name = "echarpe kuchiki",
		description = "echarpe de la famille kuchiki",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_rangiku"] = {
		name = "echarpe rangiku",
		description = "echarpe de rangiku",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["shini_bandouliere"] = {
		name = "shini bandouliere",
		description = "bandouliere de shinigami",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["shini_bandouliere_toshiro"] = {
		name = "shini bandouliere toshiro",
		description = "bandouliere du capitain toshiro",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/evo_jhpdf4rgq5udj71o1/evo_hp9slg7qkyso.mdl",
	},
	["collier_ichibe"] = {
		name = "collier ichibe",
		description = "collier d'Ichibei",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/evo_erfl4f1uy658frttgrtrha/evo_erfl4f1uy658frtTGRtrha.mdl",
	},
	["collier_ichibe_blanc"] = {
		name = "collier ichibe blanc",
		description = "collier d'Ichibei, blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_erfl4f1uy658frttgrtrha/evo_erfl4f1uy658frtTGRtrha.mdl",
	},
	["collier_ichibe_noir"] = {
		name = "collier ichibe noir",
		description = "collier d'Ichibei, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_erfl4f1uy658frttgrtrha/evo_erfl4f1uy658frtTGRtrha.mdl",
	},
	["collier_ichibe_rouge"] = {
		name = "collier ichibe rouge",
		description = "collier d'Ichibei, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_erfl4f1uy658frttgrtrha/evo_erfl4f1uy658frtTGRtrha.mdl",
	},
	["collier_ichibe_violet"] = {
		name = "collier ichibe violet",
		description = "collier d'Ichibei, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_erfl4f1uy658frttgrtrha/evo_erfl4f1uy658frtTGRtrha.mdl",
	},
	["echarpe_toshiro"] = {
		name = "echarpe toshiro",
		description = "echarpe du capitaine Toshiro",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/evo_zdf1urfeed2572frha/evo_zdf1uRFEed2572frha.mdl",
	},
	["echarpe_toshiro_blanc"] = {
		name = "echarpe toshiro blanc",
		description = "echarpe du capitaine Toshiro, blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_zdf1urfeed2572frha/evo_zdf1uRFEed2572frha.mdl",
	},
	["echarpe_toshiro_noir"] = {
		name = "echarpe toshiro noir",
		description = "echarpe du capitaine Toshiro, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_zdf1urfeed2572frha/evo_zdf1uRFEed2572frha.mdl",
	},
	["echarpe_toshiro_rouge"] = {
		name = "echarpe toshiro rouge",
		description = "echarpe du capitaine Toshiro, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_zdf1urfeed2572frha/evo_zdf1uRFEed2572frha.mdl",
	},
	["echarpe_toshiro_violet"] = {
		name = "echarpe toshiro violet",
		description = "echarpe du capitaine Toshiro, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_zdf1urfeed2572frha/evo_zdf1uRFEed2572frha.mdl",
	},
	["cache_oeil_gojo"] = {
		name = "Cache-Œil de Gojo",
		description = "Le cache-œil de Gojo",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_56rfhg9fll4gbuyp2trhga/evo_56rfHG9fll4gbuyp2trhga.mdl",
	},
	["cache_oeil_gojo_blanc"] = {
		name = "Cache-Œil de Gojo Blanc",
		description = "Le cache-œil de Gojo, blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		skin = 1,
		model_path = "models/evo/accessories/head/evo_56rfhg9fll4gbuyp2trhga/evo_56rfHG9fll4gbuyp2trhga.mdl",
	},
	["cache_oeil_gojo_bleu"] = {
		name = "Cache-Œil de Gojo Bleu",
		description = "Le cache-œil de Gojo, bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		skin = 2,
		model_path = "models/evo/accessories/head/evo_56rfhg9fll4gbuyp2trhga/evo_56rfHG9fll4gbuyp2trhga.mdl",
	},
	["cache_oeil_gojo_jaune"] = {
		name = "Cache-Œil de Gojo Jaune",
		description = "Le cache-œil de Gojo, jaune",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		skin = 3,
		model_path = "models/evo/accessories/head/evo_56rfhg9fll4gbuyp2trhga/evo_56rfHG9fll4gbuyp2trhga.mdl",
	},
	["cache_oeil_gojo_rouge"] = {
		name = "Cache-Œil de Gojo Rouge",
		description = "Le cache-œil de Gojo, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		skin = 4,
		model_path = "models/evo/accessories/head/evo_56rfhg9fll4gbuyp2trhga/evo_56rfHG9fll4gbuyp2trhga.mdl",
	},
	["cape_epaule_gauche_noir"] = {
		name = "cape epaule gauche noir",
		description = "cape sur l'epaule gauche, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_3l1y79inj5gy7hazj/evo_p6d8kwjvofyvyl1.mdl",
	},
	["cape_epaule_gauche_or"] = {
		name = "cape epaule gauche or",
		description = "cape sur l'epaule gauche, or",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_3l1y79inj5gy7hazj/evo_p6d8kwjvofyvyl1.mdl",
	},
	["cape_epaule_gauche_n_r_b"] = {
		name = "cape epaule gauche noir rouge blanc",
		description = "cape sur l'epaule gauche, noir rouge et blanc",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_3l1y79inj5gy7hazj/evo_p6d8kwjvofyvyl1.mdl",
	},
	["cape_epaule_gauche_noir_rouge"] = {
		name = "cape epaule gauche noir et rouge",
		description = "cape sur l'epaule gauche, noir et rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_3l1y79inj5gy7hazj/evo_p6d8kwjvofyvyl1.mdl",
	},
	["cape_shini_base_bleu"] = {
		name = "cape shinigami bleu",
		description = "cape shinigami, bleu",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_itblmwhw1wa6kn/evo_vwxv2u8abin1h.mdl",
	},
	["cape_shini_base_noir"] = {
		name = "cape shinigami noir",
		description = "cape shinigami, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_itblmwhw1wa6kn/evo_vwxv2u8abin1h.mdl",
	},
	["cape_shini_base_gris"] = {
		name = "cape shinigami gris",
		description = "cape shinigami, gris",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_itblmwhw1wa6kn/evo_vwxv2u8abin1h.mdl",
	},
	["cape_shini_base_rouge"] = {
		name = "cape shinigami rouge",
		description = "cape shinigami, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "legendary",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_itblmwhw1wa6kn/evo_vwxv2u8abin1h.mdl",
	},
	["echarpe_courte_rouge"] = {
		name = "echarpe courte rouge",
		description = "echarpe courte, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_courte_violet"] = {
		name = "echarpe courte violet",
		description = "echarpe courte, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_courte_rose"] = {
		name = "echarpe courte rose",
		description = "echarpe courte, rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_courte_gris"] = {
		name = "echarpe courte gris",
		description = "echarpe courte, gris",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_courte_noir"] = {
		name = "echarpe courte noir",
		description = "echarpe courte, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 5,
		model_path = "models/evo/accessories/body/evo_ifgcfo7lyhrzls7/evo_2e848p939k0yxcts1.mdl",
	},
	["echarpe_kuchiki_rouge"] = {
		name = "echarpe kuchiki rouge",
		description = "echarpe de la famille kuchiki, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_kuchiki_violet"] = {
		name = "echarpe kuchiki violet",
		description = "echarpe de la famille kuchiki, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_kuchiki_rose"] = {
		name = "echarpe kuchiki rose",
		description = "echarpe de la famille kuchiki, rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_kuchiki_gris"] = {
		name = "echarpe kuchiki gris",
		description = "echarpe de la famille kuchiki, gris",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_kuchiki_noir"] = {
		name = "echarpe kuchiki noir",
		description = "echarpe de la famille kuchiki, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 5,
		model_path = "models/evo/accessories/body/evo_yk1x2so8vl2mnn1x6/evo_zsk0zahqnmyj9n3zf.mdl",
	},
	["echarpe_rangiku_rouge"] = {
		name = "echarpe rangiku rouge",
		description = "echarpe de rangiku, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["echarpe_rangiku_violet"] = {
		name = "echarpe rangiku violet",
		description = "echarpe de rangiku, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["echarpe_rangiku_rose"] = {
		name = "echarpe rangiku rose",
		description = "echarpe de rangiku, rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["echarpe_rangiku_gris"] = {
		name = "echarpe rangiku gris",
		description = "echarpe de rangiku, gris",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["echarpe_rangiku_noir"] = {
		name = "echarpe rangiku noir",
		description = "echarpe de rangiku, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "rare",
		skin = 5,
		model_path = "models/evo/accessories/body/evo_6norg3svb8kwbtdgs/evo_9st85o9difvut3.mdl",
	},
	["shini_bandouliere_rouge"] = {
		name = "shini bandouliere rouge",
		description = "bandouliere de shinigami, rouge",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 1,
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["shini_bandouliere_violet"] = {
		name = "shini bandouliere violet",
		description = "bandouliere de shinigami, violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 2,
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["shini_bandouliere_rose"] = {
		name = "shini bandouliere rose",
		description = "bandouliere de shinigami, rose",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 3,
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["shini_bandouliere_gris"] = {
		name = "shini bandouliere gris",
		description = "bandouliere de shinigami, gris",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 4,
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["shini_bandouliere_noir"] = {
		name = "shini bandouliere noir",
		description = "bandouliere de shinigami, noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		skin = 5,
		model_path = "models/evo/accessories/body/evo_l80sw276zyt74skr0/evo_9xcy9u3z8si7t.mdl",
	},
	["arrancar_nnoitra_outfit"] = {
		name = "Tenue Nnoitra",
		description = "Tenue de Nnoitra",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_gucdxtcdn6n4o/evo_k2sul4kmms6koa.mdl",
	},
	["arrancar_nnoitra_noir_outfit"] = {
		name = "Tenue Nnoitra noir",
		description = "Tenue de Nnoitra en noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/evo_srdczer572cfz2d3z/evo_SRdcZER572cfz2d3z.mdl",
	},
	["arrancar_tosen_outfit"] = {
		name = "Tenue Tosen",
		description = "Tenue de Tosen",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_nztd7vlyjt9xja6/evo_qkgmcs7jibrhplo.mdl",
	},
	["arrancar_tosen_noir_outfit"] = {
		name = "Tenue Tosen noir",
		description = "Tenue de Tosen en noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_s489z5d9z5d947/evo_S489Z5d9z5D947.mdl",
	},
	["arrancar_ulquiorra_outfit"] = {
		name = "Tenue Ulquiorra",
		description = "Tenue de Ulquiorra",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_7vnghkn8rrmu/evo_kh4y25kvc9k53trf.mdl",
	},
	["arrancar_ulquiorra_violet_outfit"] = {
		name = "Tenue Ulquiorra violet",
		description = "Tenue de Ulquiorra en violet",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_15frodkg9f3ldor/evo_15FRodkg9f3LDOR.mdl",
	},
	["arrancar_ulquiorra_noir_outfit"] = {
		name = "Tenue Ulquiorra noir",
		description = "Tenue de Ulquiorra en noir",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_783saqdgoep4cd6bhfd/evo_783Saqdgoep4cd6bHFD.mdl",
	},
	["arrancar_assassin_outfit"] = {
		name = "Arrancar Assassin",
		description = "Modèle d'Arrancar Assassin (féminin).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_che496dheinjcef5ge5gr9z/evo_che496DHEInjcef5ge5gr9z.mdl",
	},
	["arrancar_veteran_outfit"] = {
		name = "Arrancar Vétéran",
		description = "Modèle d'Arrancar Vétéran.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_fzddzeg183nty58agrhf/evo_fzdDZEg183nty58AGRHf.mdl",
	},
	["arrancar_berserker_outfit"] = {
		name = "Arrancar Berserker",
		description = "Modèle d'Arrancar Berserker.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_hb59eghiegr56fefjuizfzs/evo_HB59EGhiegr56fefjuizfzs.mdl",
	},
	["arrancar_vasto_lorde_outfit"] = {
		name = "Arrancar Vasto Lorde",
		description = "Modèle d'Arrancar Vasto Lorde.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_69fejhduef559egek95egrfueiaa/evo_69fejHDUEF559egek95egrFUEIaa.mdl",
	},
	["arrancar_experimental_outfit"] = {
		name = "Arrancar Expérimental",
		description = "Modèle d'Arrancar Expérimental.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_cue5grj6grkfe5jvor2feirz/evo_cue5grj6GRKFE5jvor2feiRz.mdl",
	},

	-- ─── COFFRE DE TENUES : lot COMMUN (demande user 08\13) ───────────────────
	-- Tirables UNIQUEMENT au coffre : leur ligne COSMETIQUES_CONFIG porte
	-- coffre_only = true et price = 0, ce qui les sort de la vitrine hebdo et du
	-- Night Market. Genre et faction se DÉDUISENT du model_path (/male/, /female/,
	-- /shinigami/, /arrancar/) : cf. GetItemGender et GetItemFaction plus haut,
	-- rien à déclarer à la main tant que le chemin respecte la convention.
	["shinigami_base_dechire_outfit"] = {
		name = "Shinigami Base Déchirée",
		description = "Tenue de Shinigami de base, déchirée au combat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ze24jmxzedf52zdszadfv/evo_ze24jmxzedf52zdsZADfv.mdl",
	},
	["shinigami_base_dechire_blanc_outfit"] = {
		name = "Shinigami Base Déchirée Blanche",
		description = "Tenue de Shinigami de base blanche, déchirée au combat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ef75zdszefrrgb/evo_ef75zdsZEFRrgb.mdl",
	},
	["shinigami_base_dechire_f_outfit"] = {
		name = "Shinigami Base Déchirée (Femme)",
		description = "Tenue de Shinigami de base, déchirée au combat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_zedd35fer3efdegrerefom/evo_zedd35fer3efdEGrerEFom.mdl",
	},
	["shinigami_base_dechire_blanc_f_outfit"] = {
		name = "Shinigami Base Déchirée Blanche (Femme)",
		description = "Tenue de Shinigami de base blanche, déchirée au combat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_zdg6qqfd356dvefdegrgtpom/evo_zdg6qqfd356dvefdEGrgtpom.mdl",
	},
	["arrancar_sans_ceinture_blanc_outfit"] = {
		name = "Arrancar Sans Ceinture Blanc",
		description = "Tenue d'Arrancar de base, portée sans ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_zedsnf536gwdzed/evo_zedsnf536gwdZED.mdl",
	},
	["arrancar_sans_ceinture_noir_outfit"] = {
		name = "Arrancar Sans Ceinture Noir",
		description = "Tenue d'Arrancar de base noire, portée sans ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_zedsnrefjyureggw635m/evo_zedsnrefjyuREGgw635m.mdl",
	},
	["arrancar_sans_ceinture_blanc_f_outfit"] = {
		name = "Arrancar Sans Ceinture Blanc (Femme)",
		description = "Tenue d'Arrancar de base, portée sans ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_dzl74sng4528xefr/evo_dzl74sng4528xefr.mdl",
	},
	["arrancar_sans_ceinture_noir_f_outfit"] = {
		name = "Arrancar Sans Ceinture Noir (Femme)",
		description = "Tenue d'Arrancar de base noire, portée sans ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_ed4snv8feryh563zefd/evo_ed4snv8feryh563zefd.mdl",
	},

	-- ─── COFFRE DE TENUES : lots RARE a MYTHIQUE (demande user 08\13) ────────
	-- Meme regime que le lot commun ci-dessus : coffre_only cote COSMETIQUES_CONFIG.
	-- Genre et faction se DEDUISENT du model_path, rien a declarer ici.

	["shinigami_base_emeraude_outfit"] = {
		name = "Base Emeraude",
		description = "Tenue Base Emeraude.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_efe24jm245erfedefr/evo_efe24jm245ERFEDefr.mdl",
	},
	["shinigami_base_glycines_outfit"] = {
		name = "Base Glycines",
		description = "Tenue Base Glycines.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/evo_apm55e24jmerfefrvdo958/evo_apm55e24jmerfEFRvdo958.mdl",
	},
	["shinigami_base_lys_outfit"] = {
		name = "Base Lys",
		description = "Tenue Base Lys.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_efre24jmefrxv53efr/evo_EFRe24jmefrxv53efr.mdl",
	},
	["shinigami_base_brode_outfit"] = {
		name = "Base Brodee",
		description = "Tenue Base Brodee.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/evo_efx5qtyhgro98/evo_efx5qTYHgro98.mdl",
	},
	["shinigami_base_nocturne_outfit"] = {
		name = "Base Nocturne",
		description = "Tenue Base Nocturne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_feu5e24j524xvref9erfedz/evo_feu5e24j524xvREF9erfedz.mdl",
	},
	["shinigami_base_cendre_outfit"] = {
		name = "Base Cendre",
		description = "Tenue Base Cendre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_efr4efcx4598rg/evo_efr4EFCx4598rg.mdl",
	},
	["shinigami_urahara_base_outfit"] = {
		name = "Urahara de Base",
		description = "Tenue Urahara de Base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_44ma3xvg45thgd9tyrn/evo_44ma3xvg45THGd9tyrn.mdl",
	},
	["shinigami_urahara_bleu_blanc_outfit"] = {
		name = "Urahara Bleu et Blanc",
		description = "Tenue Urahara Bleu et Blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_4rfemgtrxvgefrrythyrn/evo_4rfemGTRxvgefrrythyrn.mdl",
	},
	["shinigami_urahara_noir_bleu_outfit"] = {
		name = "Urahara Noir et Bleu",
		description = "Tenue Urahara Noir et Bleu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_ebamdxfrg45re69trgtn/evo_eBAmDxFRg45re69tRGTn.mdl",
	},
	["shinigami_urahara_noir_blanc_outfit"] = {
		name = "Urahara Noir et Blanc",
		description = "Tenue Urahara Noir et Blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/evo_efma3xvgtrd4tytyrtgn/evo_efma3xvgtrd4TYtyrtgn.mdl",
	},
	["shinigami_base_obsidienne_outfit"] = {
		name = "Base Obsidienne",
		description = "Tenue Base Obsidienne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ef5425e24jmxgrt9refny/evo_ef5425e24jmxGRT9REFny.mdl",
	},
	["shinigami_base_shogun_outfit"] = {
		name = "Base Shogun",
		description = "Tenue Base Shogun.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/evo_er54e24jmrefo9pmoyuj8/evo_er54e24jmrefo9pmoyuj8.mdl",
	},
	["shinigami_base_carpes_outfit"] = {
		name = "Base Carpes",
		description = "Tenue Base Carpes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/evo_ef635e256xvgr98/evo_ef635e256xvGR98.mdl",
	},
	["shinigami_omoeda_base_outfit"] = {
		name = "Omoeda de Base",
		description = "Tenue Omoeda de Base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_rgt6ukioizyubez/evo_rgt6UKIoizYUbez.mdl",
	},
	["shinigami_shunsui_alt_base_outfit"] = {
		name = "Shunsui Alt Base",
		description = "Tenue Shunsui Alt Base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_5rgtmatgr21rgthruyjqythn/evo_5RGTmaTGR21rgthruyjqYTHn.mdl",
	},
	["shinigami_shunsui_alt_design_outfit"] = {
		name = "Shunsui Alt Design",
		description = "Tenue Shunsui Alt Design.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_75r1hytruyt1zedfern/evo_75r1HYTruyT1ZEDfern.mdl",
	},
	["shinigami_shunsui_alt_noir_outfit"] = {
		name = "Shunsui Alt Noir",
		description = "Tenue Shunsui Alt Noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_ht542gthruyezfrgt63/evo_ht542gthruyezfRGT63.mdl",
	},
	["shinigami_urahara_noir_rouge_outfit"] = {
		name = "Urahara Noir et Rouge",
		description = "Tenue Urahara Noir et Rouge.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_4zamdza3xvgedzzde9tyrn/evo_4ZAmdza3xvgEDZzde9tyrn.mdl",
	},
	["shinigami_urahara_blanc_noir_outfit"] = {
		name = "Urahara Blanc et Noir",
		description = "Tenue Urahara Blanc et Noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_4tyamaefrxverfrrd9efn/evo_4tyAmaefrxverfrrd9efn.mdl",
	},

	["arrancar_obsidian_outfit"] = {
		name = "Obsidian",
		description = "Tenue Obsidian.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_HPMziDbzvWNGT/evo_HPMziDbzvWNGT.mdl",
	},
	["arrancar_royal_outfit"] = {
		name = "Royal",
		description = "Tenue Royal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_prYX0EB7BhNma/evo_prYX0EB7BhNma.mdl",
	},
	["arrancar_emerald_outfit"] = {
		name = "Emerald",
		description = "Tenue Emerald.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_CeYjA1b5X6NzR/evo_CeYjA1b5X6NzR.mdl",
	},
	["arrancar_imperial_outfit"] = {
		name = "Imperial",
		description = "Tenue Imperial.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/evo_8QzK8ketQdrCQ/evo_8QzK8ketQdrCQ.mdl",
	},
	["arrancar_crimson_outfit"] = {
		name = "Crimson",
		description = "Tenue Crimson.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/male/evo_iz3Sfkm68mDbW/evo_iz3Sfkm68mDbW.mdl",
	},
	["arrancar_amethyst_outfit"] = {
		name = "Amethyst",
		description = "Tenue Amethyst.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_NH2AsXbJ2nQba/evo_NH2AsXbJ2nQba.mdl",
	},
	["arrancar_ulquiorra_modif_noir_outfit"] = {
		name = "Ulquiorra Modifie Noir",
		description = "Tenue Ulquiorra Modifie Noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_ef755kvcdek5refrf/evo_ef755kvcdek5refrf.mdl",
	},
	["arrancar_ulquiorra_modif_base_outfit"] = {
		name = "Ulquiorra Modifie Base",
		description = "Tenue Ulquiorra Modifie Base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_ze562r63c9rgeffr/evo_ze562r63c9rgeffr.mdl",
	},
	["arrancar_ulquiorra_modif_marron_outfit"] = {
		name = "Ulquiorra Modifie Marron",
		description = "Tenue Ulquiorra Modifie Marron.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_efkvc963863rtgrh/evo_efkvc963863RTGrh.mdl",
	},
	["arrancar_coyote_modif_base_outfit"] = {
		name = "Coyote Modifie Base",
		description = "Tenue Coyote Modifie Base.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_95grta93l5grtpgtr0rg/evo_95GRTa93l5grtpGTR0rg.mdl",
	},
	["arrancar_coyote_modif_noir_outfit"] = {
		name = "Coyote Modifie Noir",
		description = "Tenue Coyote Modifie Noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_9gju05grtpgrefefr0trgg/evo_9GJU05grtpGrefEFR0trgg.mdl",
	},
	["arrancar_coyote_modif_marron_outfit"] = {
		name = "Coyote Modifie Marron",
		description = "Tenue Coyote Modifie Marron.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_efr63rta93l5grtpgt7572rgtg/evo_efr63RTa93l5grtpGT7572RGTg.mdl",
	},

	["shinigami_base_emeraude_f_outfit"] = {
		name = "Base Emeraude (Femme)",
		description = "Tenue Base Emeraude.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_efr24552trgertg/evo_efr24552TRGeRTG.mdl",
	},
	["shinigami_base_glycines_f_outfit"] = {
		name = "Base Glycines (Femme)",
		description = "Tenue Base Glycines.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/evo_edrfjmfrferrvfer58/evo_edrfjmfrFERRvfer58.mdl",
	},
	["shinigami_base_lys_f_outfit"] = {
		name = "Base Lys (Femme)",
		description = "Tenue Base Lys.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_frejfrreffrxv525fr/evo_frejfrREFfrxv525fr.mdl",
	},
	["shinigami_base_nocturne_f_outfit"] = {
		name = "Base Nocturne (Femme)",
		description = "Tenue Base Nocturne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_rfe4rfexvre25rgtde/evo_rfe4RFExvRE25RGTde.mdl",
	},
	["shinigami_base_brode_f_outfit"] = {
		name = "Base Brodee (Femme)",
		description = "Tenue Base Brodee.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/evo_rfefr5jnffv1jnfefrfvfec8/evo_rfefr5JNFFV1jnfefrFVfec8.mdl",
	},
	["shinigami_base_cendre_f_outfit"] = {
		name = "Base Cendre (Femme)",
		description = "Tenue Base Cendre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_efg5tx258rg5t/evo_efG5Tx258rG5T.mdl",
	},
	["shinigami_base_shogun_f_outfit"] = {
		name = "Base Shogun (Femme)",
		description = "Tenue Base Shogun.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/evo_fedferref529pfreruj8/evo_fedferref529pFREruj8.mdl",
	},
	["shinigami_base_carpes_f_outfit"] = {
		name = "Base Carpes (Femme)",
		description = "Tenue Base Carpes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_efrrg6524grt8/evo_efrRG6524GRT8.mdl",
	},
	["shinigami_base_obsidienne_f_outfit"] = {
		name = "Base Obsidienne (Femme)",
		description = "Tenue Base Obsidienne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/evo_fre4jmgtrrt52fnyfre/evo_fre4jmGTRRT52FnyFRE.mdl",
	},
	["shinigami_nemu_style_f_outfit"] = {
		name = "Style Nemu (Femme)",
		description = "Tenue Style Nemu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/female/evo_erferfthgte635dnje/evo_erfERFthgte635dnje.mdl",
	},

	["arrancar_obsidian_f_outfit"] = {
		name = "Obsidian (Femme)",
		description = "Tenue Obsidian.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_9pLd3SvQh6YtNe/evo_9pLd3SvQh6YtNe.mdl",
	},
	["arrancar_royal_f_outfit"] = {
		name = "Royal (Femme)",
		description = "Tenue Royal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_3vHp9DaLw5ZnRu/evo_3vHp9DaLw5ZnRu.mdl",
	},
	["arrancar_emerald_f_outfit"] = {
		name = "Emerald (Femme)",
		description = "Tenue Emerald.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_8cJm2QxFs4VeNy/evo_8cJm2QxFs4VeNy.mdl",
	},
	["arrancar_imperial_f_outfit"] = {
		name = "Imperial (Femme)",
		description = "Tenue Imperial.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/evo_1mQj8LsVx2PdKa/evo_1mQj8LsVx2PdKa.mdl",
	},
	["arrancar_crimson_f_outfit"] = {
		name = "Crimson (Femme)",
		description = "Tenue Crimson.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/evo_7nRb4YkTq6XcMe/evo_7nRb4YkTq6XcMe.mdl",
	},
	["arrancar_amethyst_f_outfit"] = {
		name = "Amethyst (Femme)",
		description = "Tenue Amethyst.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_5tKw7BnMz1RaXu/evo_5tKw7BnMz1RaXu.mdl",
	},

	-- PALIERS DE DÉPENSE 5 et 6 (10/08, pack V2.3.1 textile_v2) : faction et sexe EXPLICITES,
	-- les chemins textile_v2 ne contiennent ni /shinigami/ ni /male/.
	["shinigami_tigre_ecarlate_outfit"] = {
		name = "Tigre écarlate",
		description = "Tenue exclusive du palier de dépense 5.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_kenpachi_special_noir.mdl",
	},
	["shinigami_ailes_cendre_f_outfit"] = {
		name = "Ailes de cendre (Femme)",
		description = "Tenue exclusive du palier de dépense 5.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/sh_f_base_f_00.mdl",
	},
	["arrancar_ciel_creux_outfit"] = {
		name = "Ciel creux",
		description = "Tenue exclusive du palier de dépense 5.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_ulquiorra.mdl",
	},
	["arrancar_lame_iris_f_outfit"] = {
		name = "Lame d'iris (Femme)",
		description = "Tenue exclusive du palier de dépense 5.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_valkyrie_f.mdl",
	},
	["shinigami_eclipse_souveraine_outfit"] = {
		name = "Éclipse souveraine",
		description = "Tenue exclusive du palier de dépense 6.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_ichigo_bankai.mdl",
	},
	["shinigami_lys_obsidienne_f_outfit"] = {
		name = "Lys d'obsidienne (Femme)",
		description = "Tenue exclusive du palier de dépense 6.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/sh_f_capitain_assassin_f.mdl",
	},
	["arrancar_monarque_nacre_outfit"] = {
		name = "Monarque de nacre",
		description = "Tenue exclusive du palier de dépense 6.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_aizen.mdl",
	},
	["arrancar_prune_celeste_f_outfit"] = {
		name = "Prune céleste (Femme)",
		description = "Tenue exclusive du palier de dépense 6.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_cirucci.mdl",
	},

	-- PALIERS DE DÉPENSE 7 à 10 (10/10, user) : mythiques, faction + sexe EXPLICITES.
	["palier7_sh_m_heraut_constellations_outfit"] = {
		name = "Héraut des constellations",
		description = "Tenue exclusive du palier de dépense 7.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/paliers_7_10/heraut_constellations.mdl",
	},
	["palier7_sh_f_vestale_constellations_outfit"] = {
		name = "Vestale des constellations (Femme)",
		description = "Tenue exclusive du palier de dépense 7.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/paliers_7_10/vestale_constellations.mdl",
	},
	["palier7_ar_m_oracle_nacre_outfit"] = {
		name = "Oracle de nacre",
		description = "Tenue exclusive du palier de dépense 7.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/paliers_7_10/oracle_nacre.mdl",
	},
	["palier7_ar_f_sibylle_nacre_outfit"] = {
		name = "Sibylle de nacre (Femme)",
		description = "Tenue exclusive du palier de dépense 7.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/paliers_7_10/sibylle_nacre.mdl",
	},
	["palier8_sh_m_souverain_dernier_ciel_outfit"] = {
		name = "Souverain du dernier ciel",
		description = "Tenue exclusive du palier de dépense 8.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/paliers_7_10/souverain_dernier_ciel.mdl",
	},
	["palier8_sh_f_souveraine_dernier_ciel_outfit"] = {
		name = "Souveraine du dernier ciel (Femme)",
		description = "Tenue exclusive du palier de dépense 8.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/paliers_7_10/souveraine_dernier_ciel.mdl",
	},
	["palier8_ar_m_seraphin_solaire_outfit"] = {
		name = "Séraphin solaire",
		description = "Tenue exclusive du palier de dépense 8.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/paliers_7_10/seraphin_solaire.mdl",
	},
	["palier8_ar_f_seraphine_solaire_outfit"] = {
		name = "Séraphine solaire (Femme)",
		description = "Tenue exclusive du palier de dépense 8.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/paliers_7_10/seraphine_solaire.mdl",
	},
	["palier9_sh_m_monarque_eclipse_outfit"] = {
		name = "Monarque de l'éclipse",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/paliers_7_10/monarque_eclipse.mdl",
	},
	["palier9_sh_f_imperatrice_eclipse_outfit"] = {
		name = "Impératrice de l'éclipse (Femme)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/paliers_7_10/imperatrice_eclipse.mdl",
	},
	["palier9_ar_m_roi_neant_outfit"] = {
		name = "Roi du néant",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/paliers_7_10/roi_neant.mdl",
	},
	["palier9_ar_f_reine_neant_outfit"] = {
		name = "Reine du néant (Femme)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/paliers_7_10/reine_neant.mdl",
	},
	["palier10_sh_m_ichigo_armure_osseuse_outfit"] = {
		name = "Ichigo (Armure osseuse)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ichigo_armure_osseuse/ichigo_armure_osseuse.mdl",
	},
	["palier10_sh_f_ichigo_armure_osseuse_outfit"] = {
		name = "Ichigo (Armure osseuse, Femme)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ichigo_armure_osseuse/ichigo_armure_osseuse.mdl",
	},
	["palier10_ar_m_ichigo_armure_osseuse_outfit"] = {
		name = "Ichigo (Armure osseuse)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ichigo_armure_osseuse/ichigo_armure_osseuse.mdl",
	},
	["palier10_ar_f_ichigo_armure_osseuse_outfit"] = {
		name = "Ichigo (Armure osseuse, Femme)",
		description = "Tenue exclusive du palier de dépense 9.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ichigo_armure_osseuse/ichigo_armure_osseuse.mdl",
	},

	-- BOUTIQUE TEXTILE V2 (10/08, pack TENUES_BLEACH_60, prix du propriétaire) : 52 tenues
	-- retexturées, faction + sexe EXPLICITES, rareté déduite du prix (tirage de la vitrine).
	["tv2_sh_m_academy_sans_manche_outfit"] = {
		name = "Marée d'argent",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_academy_sans_manche.mdl",
	},
	["tv2_sh_m_base_outfit"] = {
		name = "Ailes de cendre (Classique)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_base.mdl",
	},
	["tv2_sh_m_base_dechire_outfit"] = {
		name = "Ailes de cendre (Déchirée)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_base_dechire.mdl",
	},
	["tv2_sh_m_base_manche_dechiree_outfit"] = {
		name = "Ailes de cendre (Manches déchirées)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_base_manche_dechiree.mdl",
	},
	["tv2_sh_m_demi_torse_bandage_outfit"] = {
		name = "Sceau de jade (Bandages)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_demi_torse_bandage.mdl",
	},
	["tv2_sh_m_demi_torse_bandage_overlay_outfit"] = {
		name = "Sceau de jade (Variante bandages)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_demi_torse_bandage_overlay.mdl",
	},
	["tv2_sh_m_getsuga_outfit"] = {
		name = "Braise silencieuse (Classique)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_getsuga.mdl",
	},
	["tv2_sh_m_getsuga_chaines_outfit"] = {
		name = "Braise silencieuse (Chaînes)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_getsuga_chaines.mdl",
	},
	["tv2_sh_m_getsuga_dechire_outfit"] = {
		name = "Braise silencieuse (Déchirée)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_getsuga_dechire.mdl",
	},
	["tv2_sh_m_ichigo_chaine_outfit"] = {
		name = "Tourbillon pourpre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_ichigo_chaine.mdl",
	},
	["tv2_sh_m_ichigo_dangai_outfit"] = {
		name = "Orage d'encre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_ichigo_dangai.mdl",
	},
	["tv2_sh_m_manche_longue_outfit"] = {
		name = "Ailes de cendre (Manches longues)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_manche_longue.mdl",
	},
	["tv2_sh_m_martiale_outfit"] = {
		name = "Ronin des pins",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_martiale.mdl",
	},
	["tv2_sh_m_renji_design_outfit"] = {
		name = "Carpes vermillon (Classique)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_renji_design.mdl",
	},
	["tv2_sh_m_sans_manche_outfit"] = {
		name = "Lotus de braise",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_sans_manche.mdl",
	},
	["tv2_sh_m_shuhei_hisagi_outfit"] = {
		name = "Rosée d'encre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_shuhei_hisagi.mdl",
	},
	["tv2_sh_m_shunsui_alt_outfit"] = {
		name = "Prunier au crépuscule",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_shunsui_alt.mdl",
	},
	["tv2_sh_m_torse_nue_outfit"] = {
		name = "Gardien des marées",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_torse_nue.mdl",
	},
	["tv2_sh_m_urahara_base_outfit"] = {
		name = "Forêt spectrale",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_urahara_base.mdl",
	},
	["tv2_sh_m_veteran_outfit"] = {
		name = "Dernier couchant",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_veteran.mdl",
	},
	["tv2_sh_m_yumichika_outfit"] = {
		name = "Paon impérial",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_yumichika.mdl",
	},
	["tv2_sh_m_zabimaru_outfit"] = {
		name = "Carpes vermillon (Ornements osseux)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/sh_m_zabimaru.mdl",
	},
	["tv2_sh_f_assassin_f_outfit"] = {
		name = "Lys d'obsidienne (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/sh_f_assassin_f.mdl",
	},
	["tv2_sh_f_base_f_01_outfit"] = {
		name = "Ailes de cendre (Variante 01, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/sh_f_base_f_01.mdl",
	},
	["tv2_ar_m_aaroniero_outfit"] = {
		name = "Crépuscule de cuivre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_aaroniero.mdl",
	},
	["tv2_ar_m_aizen_fusion_3_outfit"] = {
		name = "Voile du vide",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_aizen_fusion_3.mdl",
	},
	["tv2_ar_m_capitaine_div_outfit"] = {
		name = "Fauve de jade (Veste fermée)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_capitaine_div.mdl",
	},
	["tv2_ar_m_coyote_stark_outfit"] = {
		name = "Cuivre turbulent (Classique)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_coyote_stark.mdl",
	},
	["tv2_ar_m_coyote_stark_res_outfit"] = {
		name = "Cuivre turbulent (Résurrection)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_coyote_stark_res.mdl",
	},
	["tv2_ar_m_del_socaccio_outfit"] = {
		name = "Cendres royales",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_del_socaccio.mdl",
	},
	["tv2_ar_m_experimental_outfit"] = {
		name = "Miroir grenat",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_experimental.mdl",
	},
	["tv2_ar_m_gin_outfit"] = {
		name = "Lune d'automne",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_gin.mdl",
	},
	["tv2_ar_m_granz_outfit"] = {
		name = "Orchidée impériale (Ensemble complet)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_granz.mdl",
	},
	["tv2_ar_m_grimmjow_outfit"] = {
		name = "Fauve de jade (Veste ouverte)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_grimmjow.mdl",
	},
	["tv2_ar_m_laporro_outfit"] = {
		name = "Orchidée impériale (Torse nu)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_laporro.mdl",
	},
	["tv2_ar_m_masque_outfit"] = {
		name = "Fauve de jade (Col montant)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_masque.mdl",
	},
	["tv2_ar_m_mosqueda_outfit"] = {
		name = "Grenat du désert",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_mosqueda.mdl",
	},
	["tv2_ar_m_nnoitra_outfit"] = {
		name = "Scarabée d'émeraude",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_nnoitra.mdl",
	},
	["tv2_ar_m_torse_ouvert_outfit"] = {
		name = "Dunes dorées (Classique)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_torse_ouvert.mdl",
	},
	["tv2_ar_m_torse_ouvert_pique_outfit"] = {
		name = "Dunes dorées (Pointes aux épaules)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_torse_ouvert_pique.mdl",
	},
	["tv2_ar_m_tosen_outfit"] = {
		name = "Mirage de cuivre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_tosen.mdl",
	},
	["tv2_ar_m_ulqu_modif_outfit"] = {
		name = "Ciel creux (Ulqu modif)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_ulqu_modif.mdl",
	},
	["tv2_ar_m_vasto_lorde_outfit"] = {
		name = "Cendre funèbre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_vasto_lorde.mdl",
	},
	["tv2_ar_m_yammy_outfit"] = {
		name = "Caldeira",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_yammy.mdl",
	},
	["tv2_ar_m_zangetsu_fused_outfit"] = {
		name = "Serment du néant",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_zangetsu_fused.mdl",
	},
	["tv2_ar_m_zommari_outfit"] = {
		name = "Royaume prismatique",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/boutique/textile_v2/ar_m_zommari.mdl",
	},
	["tv2_ar_f_base_f_outfit"] = {
		name = "Pavillon du désert (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_base_f.mdl",
	},
	["tv2_ar_f_base_modif_f_outfit"] = {
		name = "Oasis souveraine (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_base_modif_f.mdl",
	},
	["tv2_ar_f_luppi_outfit"] = {
		name = "Aurore cuivrée (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_luppi.mdl",
	},
	["tv2_ar_f_nelliel_outfit"] = {
		name = "Verdure ancienne (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_nelliel.mdl",
	},
	["tv2_ar_f_tier_harribel_outfit"] = {
		name = "Éclipse solaire (Grand col, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_tier_harribel.mdl",
	},
	["tv2_ar_f_tier_modif_outfit"] = {
		name = "Éclipse solaire (Col bas, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/boutique/textile_v2/ar_f_tier_modif.mdl",
	},

	-- BOUTIQUE SÉRIE 2 (10/10) : 16 ensembles, prix et raretés du propriétaire, faction + sexe EXPLICITES.
	["s2_sh_m_sillage_argent_outfit"] = {
		name = "Sillage d'argent",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles_serie2/sillage_argent.mdl",
	},
	["s2_sh_m_phenix_cendre_outfit"] = {
		name = "Phénix de cendre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles_serie2/phenix_cendre.mdl",
	},
	["s2_sh_m_chrysantheme_nuit_outfit"] = {
		name = "Chrysanthème de nuit",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles_serie2/chrysantheme_nuit.mdl",
	},
	["s2_sh_m_orage_indigo_outfit"] = {
		name = "Orage indigo",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles_serie2/orage_indigo.mdl",
	},
	["s2_sh_f_neige_lotus_outfit"] = {
		name = "Neige de lotus (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles_serie2/neige_lotus.mdl",
	},
	["s2_sh_f_plume_carmin_outfit"] = {
		name = "Plume carmin (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles_serie2/plume_carmin.mdl",
	},
	["s2_sh_f_jardin_minuit_outfit"] = {
		name = "Jardin de minuit (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles_serie2/jardin_minuit.mdl",
	},
	["s2_sh_f_maree_nocturne_outfit"] = {
		name = "Marée nocturne (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles_serie2/maree_nocturne.mdl",
	},
	["s2_ar_m_astre_ivoire_outfit"] = {
		name = "Astre d'ivoire",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles_serie2/astre_ivoire.mdl",
	},
	["s2_ar_m_serpent_azur_outfit"] = {
		name = "Serpent d'azur",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles_serie2/serpent_azur.mdl",
	},
	["s2_ar_m_orchidee_sable_outfit"] = {
		name = "Orchidée des sables",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles_serie2/orchidee_sable.mdl",
	},
	["s2_ar_m_regent_ambre_outfit"] = {
		name = "Régent d'ambre",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles_serie2/regent_ambre.mdl",
	},
	["s2_ar_f_perle_desert_outfit"] = {
		name = "Perle du désert (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles_serie2/perle_desert.mdl",
	},
	["s2_ar_f_mirage_azur_outfit"] = {
		name = "Mirage d'azur (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles_serie2/mirage_azur.mdl",
	},
	["s2_ar_f_orchidee_minuit_outfit"] = {
		name = "Orchidée de minuit (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles_serie2/orchidee_minuit.mdl",
	},
	["s2_ar_f_ambre_souveraine_outfit"] = {
		name = "Ambre souveraine (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles_serie2/ambre_souveraine.mdl",
	},

	-- BOUTIQUE PACK 28 (10/10) : Yamamoto, brassières, ensembles, prix et raretés du propriétaire, faction + sexe EXPLICITES.
	["tb_sh_m_yamamoto_torse_nu_outfit"] = {
		name = "Yamamoto",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/yamamoto_torse_nu/yamamoto_torse_nu.mdl",
	},
	["tb_sh_f_yamamoto_brassiere_outfit"] = {
		name = "Yamamoto (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/yamamoto_brassiere/yamamoto_brassiere.mdl",
	},
	["tb_ar_m_yamamoto_torse_nu_outfit"] = {
		name = "Yamamoto",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/yamamoto_torse_nu/yamamoto_torse_nu.mdl",
	},
	["tb_ar_f_yamamoto_brassiere_outfit"] = {
		name = "Yamamoto (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/yamamoto_brassiere/yamamoto_brassiere.mdl",
	},
	["tb_sh_f_ailes_cendre_outfit"] = {
		name = "Ailes de cendre (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/brassiere_collection/ailes_cendre.mdl",
	},
	["tb_sh_f_lys_obsidienne_outfit"] = {
		name = "Lys d'obsidienne (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/brassiere_collection/lys_obsidienne.mdl",
	},
	["tb_sh_f_lys_capitaine_outfit"] = {
		name = "Lys d'obsidienne capitaine (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/brassiere_collection/lys_capitaine.mdl",
	},
	["tb_sh_f_eclipse_souveraine_outfit"] = {
		name = "Éclipse souveraine (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/brassiere_collection/eclipse_souveraine.mdl",
	},
	["tb_ar_f_pavillon_desert_outfit"] = {
		name = "Pavillon du désert (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/brassiere_collection/pavillon_desert.mdl",
	},
	["tb_ar_f_aurore_cuivree_outfit"] = {
		name = "Aurore cuivrée (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/brassiere_collection/aurore_cuivree.mdl",
	},
	["tb_ar_f_prune_celeste_outfit"] = {
		name = "Prune céleste (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/brassiere_collection/prune_celeste.mdl",
	},
	["tb_ar_f_lame_iris_outfit"] = {
		name = "Lame d'iris (Brassière, Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/brassiere_collection/lame_iris.mdl",
	},
	["tb_sh_m_paon_souverain_outfit"] = {
		name = "Paon souverain",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles/paon_souverain.mdl",
	},
	["tb_sh_m_lotus_vermillon_outfit"] = {
		name = "Lotus vermillon",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles/lotus_vermillon.mdl",
	},
	["tb_sh_m_ronin_jade_outfit"] = {
		name = "Ronin de jade",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles/ronin_jade.mdl",
	},
	["tb_sh_m_tigre_couchant_outfit"] = {
		name = "Tigre du couchant",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "male",
		model_path = "models/evo/characters/shinigami/male/ensembles/tigre_couchant.mdl",
	},
	["tb_sh_f_lys_nocturne_outfit"] = {
		name = "Lys nocturne (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles/lys_nocturne.mdl",
	},
	["tb_sh_f_grue_souveraine_outfit"] = {
		name = "Grue souveraine (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles/grue_souveraine.mdl",
	},
	["tb_sh_f_ombre_fleurie_outfit"] = {
		name = "Ombre fleurie (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles/ombre_fleurie.mdl",
	},
	["tb_sh_f_iris_crepuscule_outfit"] = {
		name = "Iris du crépuscule (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Shinigami",
		gender = "female",
		model_path = "models/evo/characters/shinigami/female/ensembles/iris_crepuscule.mdl",
	},
	["tb_ar_m_fauve_emeraude_outfit"] = {
		name = "Fauve d'émeraude",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles/fauve_emeraude.mdl",
	},
	["tb_ar_m_orchidee_cendree_outfit"] = {
		name = "Orchidée cendrée",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles/orchidee_cendree.mdl",
	},
	["tb_ar_m_lune_cuivree_outfit"] = {
		name = "Lune cuivrée",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles/lune_cuivree.mdl",
	},
	["tb_ar_m_sultan_amethyste_outfit"] = {
		name = "Sultan d'améthyste",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "male",
		model_path = "models/evo/characters/arrancar/male/ensembles/sultan_amethyste.mdl",
	},
	["tb_ar_f_oasis_jade_outfit"] = {
		name = "Oasis de jade (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles/oasis_jade.mdl",
	},
	["tb_ar_f_lance_nacree_outfit"] = {
		name = "Lance nacrée (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles/lance_nacree.mdl",
	},
	["tb_ar_f_iris_royal_outfit"] = {
		name = "Iris royal (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles/iris_royal.mdl",
	},
	["tb_ar_f_aurore_solaire_outfit"] = {
		name = "Aurore solaire (Femme)",
		description = "Tenue de la boutique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		faction = "Hollow",
		gender = "female",
		model_path = "models/evo/characters/arrancar/female/ensembles/aurore_solaire.mdl",
	},

	-- ─── TENUES COFFRE V2 (demande user 09/05) ──────────────────────────────
	-- 156 recolorations « boutique » (4 teintes par famille : les 2 premieres
	-- communes, jade ivoire rare, la 4e epique) + 3 series SIGNATURE dont la base
	-- est mythique et les declinaisons legendaires. Toutes en coffre_only cote
	-- shop_config : tirables au Coffre de Tenues, jamais en vitrine ni au NM.
	-- Le genre n'est PAS declare : il se deduit du model_path (/male/ ou /female/).
	["shinigami_base_dechire_boutique_nuit_argent_outfit"] = {
		name = "Base dechiree - Nuit argent",
		description = "Tenue Base dechiree - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/shinigami_base_dechire_boutique_nuit_argent/shinigami_base_dechire_boutique_nuit_argent.mdl",
	},
	["shinigami_base_dechire_boutique_bordeaux_bronze_outfit"] = {
		name = "Base dechiree - Bordeaux bronze",
		description = "Tenue Base dechiree - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/shinigami_base_dechire_boutique_bordeaux_bronze/shinigami_base_dechire_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_dechire_boutique_jade_ivoire_outfit"] = {
		name = "Base dechiree - Jade ivoire",
		description = "Tenue Base dechiree - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/shinigami_base_dechire_boutique_jade_ivoire/shinigami_base_dechire_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_dechire_boutique_violet_or_outfit"] = {
		name = "Base dechiree - Violet or",
		description = "Tenue Base dechiree - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/shinigami_base_dechire_boutique_violet_or/shinigami_base_dechire_boutique_violet_or.mdl",
	},
	["shinigami_demi_torse_bandage_boutique_nuit_argent_outfit"] = {
		name = "Demi-torse bandage - Nuit argent",
		description = "Tenue Demi-torse bandage - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_boutique_nuit_argent/shinigami_demi_torse_bandage_boutique_nuit_argent.mdl",
	},
	["shinigami_demi_torse_bandage_boutique_bordeaux_bronze_outfit"] = {
		name = "Demi-torse bandage - Bordeaux bronze",
		description = "Tenue Demi-torse bandage - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_boutique_bordeaux_bronze/shinigami_demi_torse_bandage_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_demi_torse_bandage_boutique_jade_ivoire_outfit"] = {
		name = "Demi-torse bandage - Jade ivoire",
		description = "Tenue Demi-torse bandage - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_boutique_jade_ivoire/shinigami_demi_torse_bandage_boutique_jade_ivoire.mdl",
	},
	["shinigami_demi_torse_bandage_boutique_rose_noir_outfit"] = {
		name = "Demi-torse bandage - Rose noir",
		description = "Tenue Demi-torse bandage - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_boutique_rose_noir/shinigami_demi_torse_bandage_boutique_rose_noir.mdl",
	},
	["shinigami_demi_torse_bandage_overlay_boutique_nuit_argent_outfit"] = {
		name = "Demi-torse bandage superpose - Nuit argent",
		description = "Tenue Demi-torse bandage superpose - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_overlay_boutique_nuit_argent/shinigami_demi_torse_bandage_overlay_boutique_nuit_argent.mdl",
	},
	["shinigami_demi_torse_bandage_overlay_boutique_bordeaux_bronze_outfit"] = {
		name = "Demi-torse bandage superpose - Bordeaux bronze",
		description = "Tenue Demi-torse bandage superpose - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_overlay_boutique_bordeaux_bronze/shinigami_demi_torse_bandage_overlay_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_demi_torse_bandage_overlay_boutique_jade_ivoire_outfit"] = {
		name = "Demi-torse bandage superpose - Jade ivoire",
		description = "Tenue Demi-torse bandage superpose - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_overlay_boutique_jade_ivoire/shinigami_demi_torse_bandage_overlay_boutique_jade_ivoire.mdl",
	},
	["shinigami_demi_torse_bandage_overlay_boutique_sable_cuivre_outfit"] = {
		name = "Demi-torse bandage superpose - Sable cuivre",
		description = "Tenue Demi-torse bandage superpose - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_demi_torse_bandage_overlay_boutique_sable_cuivre/shinigami_demi_torse_bandage_overlay_boutique_sable_cuivre.mdl",
	},
	["shinigami_getsuga_boutique_nuit_argent_outfit"] = {
		name = "Getsuga - Nuit argent",
		description = "Tenue Getsuga - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/shinigami_getsuga_boutique_nuit_argent/shinigami_getsuga_boutique_nuit_argent.mdl",
	},
	["shinigami_getsuga_boutique_bordeaux_bronze_outfit"] = {
		name = "Getsuga - Bordeaux bronze",
		description = "Tenue Getsuga - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/shinigami_getsuga_boutique_bordeaux_bronze/shinigami_getsuga_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_getsuga_boutique_jade_ivoire_outfit"] = {
		name = "Getsuga - Jade ivoire",
		description = "Tenue Getsuga - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/shinigami_getsuga_boutique_jade_ivoire/shinigami_getsuga_boutique_jade_ivoire.mdl",
	},
	["shinigami_getsuga_boutique_violet_or_outfit"] = {
		name = "Getsuga - Violet or",
		description = "Tenue Getsuga - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/shinigami_getsuga_boutique_violet_or/shinigami_getsuga_boutique_violet_or.mdl",
	},
	["shinigami_ichigo_chaine_boutique_nuit_argent_outfit"] = {
		name = "Ichigo chaine - Nuit argent",
		description = "Tenue Ichigo chaine - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_chaine_boutique_nuit_argent/shinigami_ichigo_chaine_boutique_nuit_argent.mdl",
	},
	["shinigami_ichigo_chaine_boutique_bordeaux_bronze_outfit"] = {
		name = "Ichigo chaine - Bordeaux bronze",
		description = "Tenue Ichigo chaine - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_chaine_boutique_bordeaux_bronze/shinigami_ichigo_chaine_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_ichigo_chaine_boutique_jade_ivoire_outfit"] = {
		name = "Ichigo chaine - Jade ivoire",
		description = "Tenue Ichigo chaine - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_chaine_boutique_jade_ivoire/shinigami_ichigo_chaine_boutique_jade_ivoire.mdl",
	},
	["shinigami_ichigo_chaine_boutique_cobalt_blanc_outfit"] = {
		name = "Ichigo chaine - Cobalt blanc",
		description = "Tenue Ichigo chaine - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_chaine_boutique_cobalt_blanc/shinigami_ichigo_chaine_boutique_cobalt_blanc.mdl",
	},
	["shinigami_ichigo_new_boutique_nuit_argent_outfit"] = {
		name = "Ichigo nouvelle - Nuit argent",
		description = "Tenue Ichigo nouvelle - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_new_boutique_nuit_argent/shinigami_ichigo_new_boutique_nuit_argent.mdl",
	},
	["shinigami_ichigo_new_boutique_bordeaux_bronze_outfit"] = {
		name = "Ichigo nouvelle - Bordeaux bronze",
		description = "Tenue Ichigo nouvelle - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_new_boutique_bordeaux_bronze/shinigami_ichigo_new_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_ichigo_new_boutique_jade_ivoire_outfit"] = {
		name = "Ichigo nouvelle - Jade ivoire",
		description = "Tenue Ichigo nouvelle - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_new_boutique_jade_ivoire/shinigami_ichigo_new_boutique_jade_ivoire.mdl",
	},
	["shinigami_ichigo_new_boutique_rose_noir_outfit"] = {
		name = "Ichigo nouvelle - Rose noir",
		description = "Tenue Ichigo nouvelle - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/shinigami_ichigo_new_boutique_rose_noir/shinigami_ichigo_new_boutique_rose_noir.mdl",
	},
	["shinigami_martiale_boutique_nuit_argent_outfit"] = {
		name = "Martiale - Nuit argent",
		description = "Tenue Martiale - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_martiale_boutique_nuit_argent/shinigami_martiale_boutique_nuit_argent.mdl",
	},
	["shinigami_martiale_boutique_bordeaux_bronze_outfit"] = {
		name = "Martiale - Bordeaux bronze",
		description = "Tenue Martiale - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_martiale_boutique_bordeaux_bronze/shinigami_martiale_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_martiale_boutique_jade_ivoire_outfit"] = {
		name = "Martiale - Jade ivoire",
		description = "Tenue Martiale - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_martiale_boutique_jade_ivoire/shinigami_martiale_boutique_jade_ivoire.mdl",
	},
	["shinigami_martiale_boutique_sable_cuivre_outfit"] = {
		name = "Martiale - Sable cuivre",
		description = "Tenue Martiale - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_martiale_boutique_sable_cuivre/shinigami_martiale_boutique_sable_cuivre.mdl",
	},
	["shinigami_omaeda_boutique_nuit_argent_outfit"] = {
		name = "Omaeda - Nuit argent",
		description = "Tenue Omaeda - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_omaeda_boutique_nuit_argent/shinigami_omaeda_boutique_nuit_argent.mdl",
	},
	["shinigami_omaeda_boutique_bordeaux_bronze_outfit"] = {
		name = "Omaeda - Bordeaux bronze",
		description = "Tenue Omaeda - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_omaeda_boutique_bordeaux_bronze/shinigami_omaeda_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_omaeda_boutique_jade_ivoire_outfit"] = {
		name = "Omaeda - Jade ivoire",
		description = "Tenue Omaeda - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_omaeda_boutique_jade_ivoire/shinigami_omaeda_boutique_jade_ivoire.mdl",
	},
	["shinigami_omaeda_boutique_violet_or_outfit"] = {
		name = "Omaeda - Violet or",
		description = "Tenue Omaeda - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_omaeda_boutique_violet_or/shinigami_omaeda_boutique_violet_or.mdl",
	},
	["shinigami_renji_design_boutique_nuit_argent_outfit"] = {
		name = "Renji - Nuit argent",
		description = "Tenue Renji - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/shinigami_renji_design_boutique_nuit_argent/shinigami_renji_design_boutique_nuit_argent.mdl",
	},
	["shinigami_renji_design_boutique_bordeaux_bronze_outfit"] = {
		name = "Renji - Bordeaux bronze",
		description = "Tenue Renji - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/male/shinigami_renji_design_boutique_bordeaux_bronze/shinigami_renji_design_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_renji_design_boutique_jade_ivoire_outfit"] = {
		name = "Renji - Jade ivoire",
		description = "Tenue Renji - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/shinigami_renji_design_boutique_jade_ivoire/shinigami_renji_design_boutique_jade_ivoire.mdl",
	},
	["shinigami_renji_design_boutique_cobalt_blanc_outfit"] = {
		name = "Renji - Cobalt blanc",
		description = "Tenue Renji - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_renji_design_boutique_cobalt_blanc/shinigami_renji_design_boutique_cobalt_blanc.mdl",
	},
	["shinigami_sans_manche_boutique_nuit_argent_outfit"] = {
		name = "Sans manche - Nuit argent",
		description = "Tenue Sans manche - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_sans_manche_boutique_nuit_argent/shinigami_sans_manche_boutique_nuit_argent.mdl",
	},
	["shinigami_sans_manche_boutique_bordeaux_bronze_outfit"] = {
		name = "Sans manche - Bordeaux bronze",
		description = "Tenue Sans manche - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_sans_manche_boutique_bordeaux_bronze/shinigami_sans_manche_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_sans_manche_boutique_jade_ivoire_outfit"] = {
		name = "Sans manche - Jade ivoire",
		description = "Tenue Sans manche - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_sans_manche_boutique_jade_ivoire/shinigami_sans_manche_boutique_jade_ivoire.mdl",
	},
	["shinigami_sans_manche_boutique_rose_noir_outfit"] = {
		name = "Sans manche - Rose noir",
		description = "Tenue Sans manche - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_sans_manche_boutique_rose_noir/shinigami_sans_manche_boutique_rose_noir.mdl",
	},
	["shinigami_shuhei_hisagi_boutique_nuit_argent_outfit"] = {
		name = "Shuhei Hisagi - Nuit argent",
		description = "Tenue Shuhei Hisagi - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_shuhei_hisagi_boutique_nuit_argent/shinigami_shuhei_hisagi_boutique_nuit_argent.mdl",
	},
	["shinigami_shuhei_hisagi_boutique_bordeaux_bronze_outfit"] = {
		name = "Shuhei Hisagi - Bordeaux bronze",
		description = "Tenue Shuhei Hisagi - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_shuhei_hisagi_boutique_bordeaux_bronze/shinigami_shuhei_hisagi_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_shuhei_hisagi_boutique_jade_ivoire_outfit"] = {
		name = "Shuhei Hisagi - Jade ivoire",
		description = "Tenue Shuhei Hisagi - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_shuhei_hisagi_boutique_jade_ivoire/shinigami_shuhei_hisagi_boutique_jade_ivoire.mdl",
	},
	["shinigami_shuhei_hisagi_boutique_sable_cuivre_outfit"] = {
		name = "Shuhei Hisagi - Sable cuivre",
		description = "Tenue Shuhei Hisagi - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/male/shinigami_shuhei_hisagi_boutique_sable_cuivre/shinigami_shuhei_hisagi_boutique_sable_cuivre.mdl",
	},
	["shinigami_assassin_f_boutique_nuit_argent_outfit"] = {
		name = "Assassin - Nuit argent",
		description = "Tenue Assassin - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_assassin_f_boutique_nuit_argent/shinigami_assassin_f_boutique_nuit_argent.mdl",
	},
	["shinigami_assassin_f_boutique_bordeaux_bronze_outfit"] = {
		name = "Assassin - Bordeaux bronze",
		description = "Tenue Assassin - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_assassin_f_boutique_bordeaux_bronze/shinigami_assassin_f_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_assassin_f_boutique_jade_ivoire_outfit"] = {
		name = "Assassin - Jade ivoire",
		description = "Tenue Assassin - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_assassin_f_boutique_jade_ivoire/shinigami_assassin_f_boutique_jade_ivoire.mdl",
	},
	["shinigami_assassin_f_boutique_violet_or_outfit"] = {
		name = "Assassin - Violet or",
		description = "Tenue Assassin - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/female/shinigami_assassin_f_boutique_violet_or/shinigami_assassin_f_boutique_violet_or.mdl",
	},
	["shinigami_base_brode_boutique_nuit_argent_outfit"] = {
		name = "Base brodee - Nuit argent",
		description = "Tenue Base brodee - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_brode_boutique_nuit_argent/shinigami_base_brode_boutique_nuit_argent.mdl",
	},
	["shinigami_base_brode_boutique_bordeaux_bronze_outfit"] = {
		name = "Base brodee - Bordeaux bronze",
		description = "Tenue Base brodee - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_brode_boutique_bordeaux_bronze/shinigami_base_brode_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_brode_boutique_jade_ivoire_outfit"] = {
		name = "Base brodee - Jade ivoire",
		description = "Tenue Base brodee - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_brode_boutique_jade_ivoire/shinigami_base_brode_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_brode_boutique_violet_or_outfit"] = {
		name = "Base brodee - Violet or",
		description = "Tenue Base brodee - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_brode_boutique_violet_or/shinigami_base_brode_boutique_violet_or.mdl",
	},
	["shinigami_base_carpes_boutique_nuit_argent_outfit"] = {
		name = "Base carpes - Nuit argent",
		description = "Tenue Base carpes - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_carpes_boutique_nuit_argent/shinigami_base_carpes_boutique_nuit_argent.mdl",
	},
	["shinigami_base_carpes_boutique_bordeaux_bronze_outfit"] = {
		name = "Base carpes - Bordeaux bronze",
		description = "Tenue Base carpes - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_carpes_boutique_bordeaux_bronze/shinigami_base_carpes_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_carpes_boutique_jade_ivoire_outfit"] = {
		name = "Base carpes - Jade ivoire",
		description = "Tenue Base carpes - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_carpes_boutique_jade_ivoire/shinigami_base_carpes_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_carpes_boutique_cobalt_blanc_outfit"] = {
		name = "Base carpes - Cobalt blanc",
		description = "Tenue Base carpes - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_carpes_boutique_cobalt_blanc/shinigami_base_carpes_boutique_cobalt_blanc.mdl",
	},
	["shinigami_base_dechire_blanc_f_boutique_nuit_argent_outfit"] = {
		name = "Base dechiree blanche - Nuit argent",
		description = "Tenue Base dechiree blanche - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_blanc_f_boutique_nuit_argent/shinigami_base_dechire_blanc_f_boutique_nuit_argent.mdl",
	},
	["shinigami_base_dechire_blanc_f_boutique_bordeaux_bronze_outfit"] = {
		name = "Base dechiree blanche - Bordeaux bronze",
		description = "Tenue Base dechiree blanche - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_blanc_f_boutique_bordeaux_bronze/shinigami_base_dechire_blanc_f_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_dechire_blanc_f_boutique_jade_ivoire_outfit"] = {
		name = "Base dechiree blanche - Jade ivoire",
		description = "Tenue Base dechiree blanche - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_blanc_f_boutique_jade_ivoire/shinigami_base_dechire_blanc_f_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_dechire_blanc_f_boutique_cobalt_blanc_outfit"] = {
		name = "Base dechiree blanche - Cobalt blanc",
		description = "Tenue Base dechiree blanche - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_blanc_f_boutique_cobalt_blanc/shinigami_base_dechire_blanc_f_boutique_cobalt_blanc.mdl",
	},
	["shinigami_base_dechire_f_boutique_nuit_argent_outfit"] = {
		name = "Base dechiree - Nuit argent",
		description = "Tenue Base dechiree - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_f_boutique_nuit_argent/shinigami_base_dechire_f_boutique_nuit_argent.mdl",
	},
	["shinigami_base_dechire_f_boutique_bordeaux_bronze_outfit"] = {
		name = "Base dechiree - Bordeaux bronze",
		description = "Tenue Base dechiree - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_f_boutique_bordeaux_bronze/shinigami_base_dechire_f_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_dechire_f_boutique_jade_ivoire_outfit"] = {
		name = "Base dechiree - Jade ivoire",
		description = "Tenue Base dechiree - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_f_boutique_jade_ivoire/shinigami_base_dechire_f_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_dechire_f_boutique_rose_noir_outfit"] = {
		name = "Base dechiree - Rose noir",
		description = "Tenue Base dechiree - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_dechire_f_boutique_rose_noir/shinigami_base_dechire_f_boutique_rose_noir.mdl",
	},
	["shinigami_base_f_00_boutique_nuit_argent_outfit"] = {
		name = "Base 00 - Nuit argent",
		description = "Tenue Base 00 - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_00_boutique_nuit_argent/shinigami_base_f_00_boutique_nuit_argent.mdl",
	},
	["shinigami_base_f_00_boutique_bordeaux_bronze_outfit"] = {
		name = "Base 00 - Bordeaux bronze",
		description = "Tenue Base 00 - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_00_boutique_bordeaux_bronze/shinigami_base_f_00_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_f_00_boutique_jade_ivoire_outfit"] = {
		name = "Base 00 - Jade ivoire",
		description = "Tenue Base 00 - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_00_boutique_jade_ivoire/shinigami_base_f_00_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_f_00_boutique_sable_cuivre_outfit"] = {
		name = "Base 00 - Sable cuivre",
		description = "Tenue Base 00 - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_00_boutique_sable_cuivre/shinigami_base_f_00_boutique_sable_cuivre.mdl",
	},
	["shinigami_base_f_01_boutique_nuit_argent_outfit"] = {
		name = "Base 01 - Nuit argent",
		description = "Tenue Base 01 - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_01_boutique_nuit_argent/shinigami_base_f_01_boutique_nuit_argent.mdl",
	},
	["shinigami_base_f_01_boutique_bordeaux_bronze_outfit"] = {
		name = "Base 01 - Bordeaux bronze",
		description = "Tenue Base 01 - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_01_boutique_bordeaux_bronze/shinigami_base_f_01_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_f_01_boutique_jade_ivoire_outfit"] = {
		name = "Base 01 - Jade ivoire",
		description = "Tenue Base 01 - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_01_boutique_jade_ivoire/shinigami_base_f_01_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_f_01_boutique_violet_or_outfit"] = {
		name = "Base 01 - Violet or",
		description = "Tenue Base 01 - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_f_01_boutique_violet_or/shinigami_base_f_01_boutique_violet_or.mdl",
	},
	["shinigami_base_glycines_boutique_nuit_argent_outfit"] = {
		name = "Base glycines - Nuit argent",
		description = "Tenue Base glycines - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_glycines_boutique_nuit_argent/shinigami_base_glycines_boutique_nuit_argent.mdl",
	},
	["shinigami_base_glycines_boutique_bordeaux_bronze_outfit"] = {
		name = "Base glycines - Bordeaux bronze",
		description = "Tenue Base glycines - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_glycines_boutique_bordeaux_bronze/shinigami_base_glycines_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_glycines_boutique_jade_ivoire_outfit"] = {
		name = "Base glycines - Jade ivoire",
		description = "Tenue Base glycines - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_glycines_boutique_jade_ivoire/shinigami_base_glycines_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_glycines_boutique_rose_noir_outfit"] = {
		name = "Base glycines - Rose noir",
		description = "Tenue Base glycines - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_glycines_boutique_rose_noir/shinigami_base_glycines_boutique_rose_noir.mdl",
	},
	["shinigami_base_lys_boutique_nuit_argent_outfit"] = {
		name = "Base lys - Nuit argent",
		description = "Tenue Base lys - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_lys_boutique_nuit_argent/shinigami_base_lys_boutique_nuit_argent.mdl",
	},
	["shinigami_base_lys_boutique_bordeaux_bronze_outfit"] = {
		name = "Base lys - Bordeaux bronze",
		description = "Tenue Base lys - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_lys_boutique_bordeaux_bronze/shinigami_base_lys_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_lys_boutique_jade_ivoire_outfit"] = {
		name = "Base lys - Jade ivoire",
		description = "Tenue Base lys - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_lys_boutique_jade_ivoire/shinigami_base_lys_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_lys_boutique_sable_cuivre_outfit"] = {
		name = "Base lys - Sable cuivre",
		description = "Tenue Base lys - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_lys_boutique_sable_cuivre/shinigami_base_lys_boutique_sable_cuivre.mdl",
	},
	["shinigami_base_nocturne_boutique_nuit_argent_outfit"] = {
		name = "Base nocturne - Nuit argent",
		description = "Tenue Base nocturne - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_nocturne_boutique_nuit_argent/shinigami_base_nocturne_boutique_nuit_argent.mdl",
	},
	["shinigami_base_nocturne_boutique_bordeaux_bronze_outfit"] = {
		name = "Base nocturne - Bordeaux bronze",
		description = "Tenue Base nocturne - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_nocturne_boutique_bordeaux_bronze/shinigami_base_nocturne_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_nocturne_boutique_jade_ivoire_outfit"] = {
		name = "Base nocturne - Jade ivoire",
		description = "Tenue Base nocturne - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_nocturne_boutique_jade_ivoire/shinigami_base_nocturne_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_nocturne_boutique_violet_or_outfit"] = {
		name = "Base nocturne - Violet or",
		description = "Tenue Base nocturne - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_nocturne_boutique_violet_or/shinigami_base_nocturne_boutique_violet_or.mdl",
	},
	["shinigami_base_shogun_boutique_nuit_argent_outfit"] = {
		name = "Base shogun - Nuit argent",
		description = "Tenue Base shogun - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_shogun_boutique_nuit_argent/shinigami_base_shogun_boutique_nuit_argent.mdl",
	},
	["shinigami_base_shogun_boutique_bordeaux_bronze_outfit"] = {
		name = "Base shogun - Bordeaux bronze",
		description = "Tenue Base shogun - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_shogun_boutique_bordeaux_bronze/shinigami_base_shogun_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_base_shogun_boutique_jade_ivoire_outfit"] = {
		name = "Base shogun - Jade ivoire",
		description = "Tenue Base shogun - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_shogun_boutique_jade_ivoire/shinigami_base_shogun_boutique_jade_ivoire.mdl",
	},
	["shinigami_base_shogun_boutique_cobalt_blanc_outfit"] = {
		name = "Base shogun - Cobalt blanc",
		description = "Tenue Base shogun - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/shinigami_base_shogun_boutique_cobalt_blanc/shinigami_base_shogun_boutique_cobalt_blanc.mdl",
	},
	["shinigami_nemu_style_boutique_nuit_argent_outfit"] = {
		name = "Style Nemu - Nuit argent",
		description = "Tenue Style Nemu - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/female/shinigami_nemu_style_boutique_nuit_argent/shinigami_nemu_style_boutique_nuit_argent.mdl",
	},
	["shinigami_nemu_style_boutique_bordeaux_bronze_outfit"] = {
		name = "Style Nemu - Bordeaux bronze",
		description = "Tenue Style Nemu - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/female/shinigami_nemu_style_boutique_bordeaux_bronze/shinigami_nemu_style_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_nemu_style_boutique_jade_ivoire_outfit"] = {
		name = "Style Nemu - Jade ivoire",
		description = "Tenue Style Nemu - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/female/shinigami_nemu_style_boutique_jade_ivoire/shinigami_nemu_style_boutique_jade_ivoire.mdl",
	},
	["shinigami_nemu_style_boutique_sable_cuivre_outfit"] = {
		name = "Style Nemu - Sable cuivre",
		description = "Tenue Style Nemu - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/female/shinigami_nemu_style_boutique_sable_cuivre/shinigami_nemu_style_boutique_sable_cuivre.mdl",
	},
	["shinigami_service_secret_f_boutique_nuit_argent_outfit"] = {
		name = "Service secret - Nuit argent",
		description = "Tenue Service secret - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_f_boutique_nuit_argent/shinigami_service_secret_f_boutique_nuit_argent.mdl",
	},
	["shinigami_service_secret_f_boutique_bordeaux_bronze_outfit"] = {
		name = "Service secret - Bordeaux bronze",
		description = "Tenue Service secret - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_f_boutique_bordeaux_bronze/shinigami_service_secret_f_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_service_secret_f_boutique_jade_ivoire_outfit"] = {
		name = "Service secret - Jade ivoire",
		description = "Tenue Service secret - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_f_boutique_jade_ivoire/shinigami_service_secret_f_boutique_jade_ivoire.mdl",
	},
	["shinigami_service_secret_f_boutique_violet_or_outfit"] = {
		name = "Service secret - Violet or",
		description = "Tenue Service secret - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_f_boutique_violet_or/shinigami_service_secret_f_boutique_violet_or.mdl",
	},
	["shinigami_service_secret_special_f_boutique_nuit_argent_outfit"] = {
		name = "Service secret special - Nuit argent",
		description = "Tenue Service secret special - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_special_f_boutique_nuit_argent/shinigami_service_secret_special_f_boutique_nuit_argent.mdl",
	},
	["shinigami_service_secret_special_f_boutique_bordeaux_bronze_outfit"] = {
		name = "Service secret special - Bordeaux bronze",
		description = "Tenue Service secret special - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_special_f_boutique_bordeaux_bronze/shinigami_service_secret_special_f_boutique_bordeaux_bronze.mdl",
	},
	["shinigami_service_secret_special_f_boutique_jade_ivoire_outfit"] = {
		name = "Service secret special - Jade ivoire",
		description = "Tenue Service secret special - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_special_f_boutique_jade_ivoire/shinigami_service_secret_special_f_boutique_jade_ivoire.mdl",
	},
	["shinigami_service_secret_special_f_boutique_cobalt_blanc_outfit"] = {
		name = "Service secret special - Cobalt blanc",
		description = "Tenue Service secret special - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/shinigami_service_secret_special_f_boutique_cobalt_blanc/shinigami_service_secret_special_f_boutique_cobalt_blanc.mdl",
	},
	["arrancar_aaroniero_boutique_nuit_argent_outfit"] = {
		name = "Aaroniero - Nuit argent",
		description = "Tenue Aaroniero - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_aaroniero_boutique_nuit_argent/arrancar_aaroniero_boutique_nuit_argent.mdl",
	},
	["arrancar_aaroniero_boutique_bordeaux_bronze_outfit"] = {
		name = "Aaroniero - Bordeaux bronze",
		description = "Tenue Aaroniero - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_aaroniero_boutique_bordeaux_bronze/arrancar_aaroniero_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_aaroniero_boutique_jade_ivoire_outfit"] = {
		name = "Aaroniero - Jade ivoire",
		description = "Tenue Aaroniero - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_aaroniero_boutique_jade_ivoire/arrancar_aaroniero_boutique_jade_ivoire.mdl",
	},
	["arrancar_aaroniero_boutique_rose_noir_outfit"] = {
		name = "Aaroniero - Rose noir",
		description = "Tenue Aaroniero - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_aaroniero_boutique_rose_noir/arrancar_aaroniero_boutique_rose_noir.mdl",
	},
	["arrancar_aizen_boutique_nuit_argent_outfit"] = {
		name = "Aizen - Nuit argent",
		description = "Tenue Aizen - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_aizen_boutique_nuit_argent/arrancar_aizen_boutique_nuit_argent.mdl",
	},
	["arrancar_aizen_boutique_bordeaux_bronze_outfit"] = {
		name = "Aizen - Bordeaux bronze",
		description = "Tenue Aizen - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_aizen_boutique_bordeaux_bronze/arrancar_aizen_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_aizen_boutique_jade_ivoire_outfit"] = {
		name = "Aizen - Jade ivoire",
		description = "Tenue Aizen - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_aizen_boutique_jade_ivoire/arrancar_aizen_boutique_jade_ivoire.mdl",
	},
	["arrancar_aizen_boutique_sable_cuivre_outfit"] = {
		name = "Aizen - Sable cuivre",
		description = "Tenue Aizen - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_aizen_boutique_sable_cuivre/arrancar_aizen_boutique_sable_cuivre.mdl",
	},
	["arrancar_del_socaccio_boutique_nuit_argent_outfit"] = {
		name = "Del Socaccio - Nuit argent",
		description = "Tenue Del Socaccio - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_del_socaccio_boutique_nuit_argent/arrancar_del_socaccio_boutique_nuit_argent.mdl",
	},
	["arrancar_del_socaccio_boutique_bordeaux_bronze_outfit"] = {
		name = "Del Socaccio - Bordeaux bronze",
		description = "Tenue Del Socaccio - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_del_socaccio_boutique_bordeaux_bronze/arrancar_del_socaccio_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_del_socaccio_boutique_jade_ivoire_outfit"] = {
		name = "Del Socaccio - Jade ivoire",
		description = "Tenue Del Socaccio - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_del_socaccio_boutique_jade_ivoire/arrancar_del_socaccio_boutique_jade_ivoire.mdl",
	},
	["arrancar_del_socaccio_boutique_violet_or_outfit"] = {
		name = "Del Socaccio - Violet or",
		description = "Tenue Del Socaccio - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_del_socaccio_boutique_violet_or/arrancar_del_socaccio_boutique_violet_or.mdl",
	},
	["arrancar_experimental_boutique_nuit_argent_outfit"] = {
		name = "Experimental - Nuit argent",
		description = "Tenue Experimental - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_experimental_boutique_nuit_argent/arrancar_experimental_boutique_nuit_argent.mdl",
	},
	["arrancar_experimental_boutique_bordeaux_bronze_outfit"] = {
		name = "Experimental - Bordeaux bronze",
		description = "Tenue Experimental - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_experimental_boutique_bordeaux_bronze/arrancar_experimental_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_experimental_boutique_jade_ivoire_outfit"] = {
		name = "Experimental - Jade ivoire",
		description = "Tenue Experimental - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_experimental_boutique_jade_ivoire/arrancar_experimental_boutique_jade_ivoire.mdl",
	},
	["arrancar_experimental_boutique_cobalt_blanc_outfit"] = {
		name = "Experimental - Cobalt blanc",
		description = "Tenue Experimental - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_experimental_boutique_cobalt_blanc/arrancar_experimental_boutique_cobalt_blanc.mdl",
	},
	["arrancar_gin_boutique_nuit_argent_outfit"] = {
		name = "Gin - Nuit argent",
		description = "Tenue Gin - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_gin_boutique_nuit_argent/arrancar_gin_boutique_nuit_argent.mdl",
	},
	["arrancar_gin_boutique_bordeaux_bronze_outfit"] = {
		name = "Gin - Bordeaux bronze",
		description = "Tenue Gin - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_gin_boutique_bordeaux_bronze/arrancar_gin_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_gin_boutique_jade_ivoire_outfit"] = {
		name = "Gin - Jade ivoire",
		description = "Tenue Gin - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_gin_boutique_jade_ivoire/arrancar_gin_boutique_jade_ivoire.mdl",
	},
	["arrancar_gin_boutique_rose_noir_outfit"] = {
		name = "Gin - Rose noir",
		description = "Tenue Gin - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_gin_boutique_rose_noir/arrancar_gin_boutique_rose_noir.mdl",
	},
	["arrancar_granz_boutique_nuit_argent_outfit"] = {
		name = "Granz - Nuit argent",
		description = "Tenue Granz - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_granz_boutique_nuit_argent/arrancar_granz_boutique_nuit_argent.mdl",
	},
	["arrancar_granz_boutique_bordeaux_bronze_outfit"] = {
		name = "Granz - Bordeaux bronze",
		description = "Tenue Granz - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_granz_boutique_bordeaux_bronze/arrancar_granz_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_granz_boutique_jade_ivoire_outfit"] = {
		name = "Granz - Jade ivoire",
		description = "Tenue Granz - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_granz_boutique_jade_ivoire/arrancar_granz_boutique_jade_ivoire.mdl",
	},
	["arrancar_granz_boutique_sable_cuivre_outfit"] = {
		name = "Granz - Sable cuivre",
		description = "Tenue Granz - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_granz_boutique_sable_cuivre/arrancar_granz_boutique_sable_cuivre.mdl",
	},
	["arrancar_grimmjow_boutique_nuit_argent_outfit"] = {
		name = "Grimmjow - Nuit argent",
		description = "Tenue Grimmjow - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_grimmjow_boutique_nuit_argent/arrancar_grimmjow_boutique_nuit_argent.mdl",
	},
	["arrancar_grimmjow_boutique_bordeaux_bronze_outfit"] = {
		name = "Grimmjow - Bordeaux bronze",
		description = "Tenue Grimmjow - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_grimmjow_boutique_bordeaux_bronze/arrancar_grimmjow_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_grimmjow_boutique_jade_ivoire_outfit"] = {
		name = "Grimmjow - Jade ivoire",
		description = "Tenue Grimmjow - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_grimmjow_boutique_jade_ivoire/arrancar_grimmjow_boutique_jade_ivoire.mdl",
	},
	["arrancar_grimmjow_boutique_violet_or_outfit"] = {
		name = "Grimmjow - Violet or",
		description = "Tenue Grimmjow - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_grimmjow_boutique_violet_or/arrancar_grimmjow_boutique_violet_or.mdl",
	},
	["arrancar_laporro_boutique_nuit_argent_outfit"] = {
		name = "Laporro - Nuit argent",
		description = "Tenue Laporro - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_laporro_boutique_nuit_argent/arrancar_laporro_boutique_nuit_argent.mdl",
	},
	["arrancar_laporro_boutique_bordeaux_bronze_outfit"] = {
		name = "Laporro - Bordeaux bronze",
		description = "Tenue Laporro - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_laporro_boutique_bordeaux_bronze/arrancar_laporro_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_laporro_boutique_jade_ivoire_outfit"] = {
		name = "Laporro - Jade ivoire",
		description = "Tenue Laporro - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_laporro_boutique_jade_ivoire/arrancar_laporro_boutique_jade_ivoire.mdl",
	},
	["arrancar_laporro_boutique_cobalt_blanc_outfit"] = {
		name = "Laporro - Cobalt blanc",
		description = "Tenue Laporro - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_laporro_boutique_cobalt_blanc/arrancar_laporro_boutique_cobalt_blanc.mdl",
	},
	["arrancar_nnoitra_boutique_nuit_argent_outfit"] = {
		name = "Nnoitra - Nuit argent",
		description = "Tenue Nnoitra - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_nnoitra_boutique_nuit_argent/arrancar_nnoitra_boutique_nuit_argent.mdl",
	},
	["arrancar_nnoitra_boutique_bordeaux_bronze_outfit"] = {
		name = "Nnoitra - Bordeaux bronze",
		description = "Tenue Nnoitra - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_nnoitra_boutique_bordeaux_bronze/arrancar_nnoitra_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_nnoitra_boutique_jade_ivoire_outfit"] = {
		name = "Nnoitra - Jade ivoire",
		description = "Tenue Nnoitra - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_nnoitra_boutique_jade_ivoire/arrancar_nnoitra_boutique_jade_ivoire.mdl",
	},
	["arrancar_nnoitra_boutique_rose_noir_outfit"] = {
		name = "Nnoitra - Rose noir",
		description = "Tenue Nnoitra - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/male/arrancar_nnoitra_boutique_rose_noir/arrancar_nnoitra_boutique_rose_noir.mdl",
	},
	["arrancar_tosen_boutique_nuit_argent_outfit"] = {
		name = "Tosen - Nuit argent",
		description = "Tenue Tosen - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_tosen_boutique_nuit_argent/arrancar_tosen_boutique_nuit_argent.mdl",
	},
	["arrancar_tosen_boutique_bordeaux_bronze_outfit"] = {
		name = "Tosen - Bordeaux bronze",
		description = "Tenue Tosen - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_tosen_boutique_bordeaux_bronze/arrancar_tosen_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_tosen_boutique_jade_ivoire_outfit"] = {
		name = "Tosen - Jade ivoire",
		description = "Tenue Tosen - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_tosen_boutique_jade_ivoire/arrancar_tosen_boutique_jade_ivoire.mdl",
	},
	["arrancar_tosen_boutique_sable_cuivre_outfit"] = {
		name = "Tosen - Sable cuivre",
		description = "Tenue Tosen - Sable cuivre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_tosen_boutique_sable_cuivre/arrancar_tosen_boutique_sable_cuivre.mdl",
	},
	["arrancar_vasto_lorde_boutique_nuit_argent_outfit"] = {
		name = "Vasto Lorde - Nuit argent",
		description = "Tenue Vasto Lorde - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_vasto_lorde_boutique_nuit_argent/arrancar_vasto_lorde_boutique_nuit_argent.mdl",
	},
	["arrancar_vasto_lorde_boutique_bordeaux_bronze_outfit"] = {
		name = "Vasto Lorde - Bordeaux bronze",
		description = "Tenue Vasto Lorde - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_vasto_lorde_boutique_bordeaux_bronze/arrancar_vasto_lorde_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_vasto_lorde_boutique_jade_ivoire_outfit"] = {
		name = "Vasto Lorde - Jade ivoire",
		description = "Tenue Vasto Lorde - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_vasto_lorde_boutique_jade_ivoire/arrancar_vasto_lorde_boutique_jade_ivoire.mdl",
	},
	["arrancar_vasto_lorde_boutique_violet_or_outfit"] = {
		name = "Vasto Lorde - Violet or",
		description = "Tenue Vasto Lorde - Violet or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_vasto_lorde_boutique_violet_or/arrancar_vasto_lorde_boutique_violet_or.mdl",
	},
	["arrancar_yammy_boutique_nuit_argent_outfit"] = {
		name = "Yammy - Nuit argent",
		description = "Tenue Yammy - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_yammy_boutique_nuit_argent/arrancar_yammy_boutique_nuit_argent.mdl",
	},
	["arrancar_yammy_boutique_bordeaux_bronze_outfit"] = {
		name = "Yammy - Bordeaux bronze",
		description = "Tenue Yammy - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_yammy_boutique_bordeaux_bronze/arrancar_yammy_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_yammy_boutique_jade_ivoire_outfit"] = {
		name = "Yammy - Jade ivoire",
		description = "Tenue Yammy - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_yammy_boutique_jade_ivoire/arrancar_yammy_boutique_jade_ivoire.mdl",
	},
	["arrancar_yammy_boutique_cobalt_blanc_outfit"] = {
		name = "Yammy - Cobalt blanc",
		description = "Tenue Yammy - Cobalt blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_yammy_boutique_cobalt_blanc/arrancar_yammy_boutique_cobalt_blanc.mdl",
	},
	["arrancar_zommari_boutique_nuit_argent_outfit"] = {
		name = "Zommari - Nuit argent",
		description = "Tenue Zommari - Nuit argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_zommari_boutique_nuit_argent/arrancar_zommari_boutique_nuit_argent.mdl",
	},
	["arrancar_zommari_boutique_bordeaux_bronze_outfit"] = {
		name = "Zommari - Bordeaux bronze",
		description = "Tenue Zommari - Bordeaux bronze.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_zommari_boutique_bordeaux_bronze/arrancar_zommari_boutique_bordeaux_bronze.mdl",
	},
	["arrancar_zommari_boutique_jade_ivoire_outfit"] = {
		name = "Zommari - Jade ivoire",
		description = "Tenue Zommari - Jade ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_zommari_boutique_jade_ivoire/arrancar_zommari_boutique_jade_ivoire.mdl",
	},
	["arrancar_zommari_boutique_rose_noir_outfit"] = {
		name = "Zommari - Rose noir",
		description = "Tenue Zommari - Rose noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arrancar_zommari_boutique_rose_noir/arrancar_zommari_boutique_rose_noir.mdl",
	},
	["arrancar_zangetsu_fused_base_outfit"] = {
		name = "Zangetsu fusionne",
		description = "Tenue Zangetsu fusionne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/male/evo_345yegrefzy83ucefrefc/evo_345YEGrefZy83ucefREFc.mdl",
	},
	["arrancar_zangetsu_fused_corrompu_outfit"] = {
		name = "Zangetsu fusionne - Corrompu",
		description = "Tenue Zangetsu fusionne - Corrompu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_7Kp3mN8vQ2xR5dT9aW4cY/evo_7Kp3mN8vQ2xR5dT9aW4cY.mdl",
	},
	["arrancar_zangetsu_fused_inverse_outfit"] = {
		name = "Zangetsu fusionne - Inverse",
		description = "Tenue Zangetsu fusionne - Inverse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_B6rF2zN9qL4sX7mC8vP1H/evo_B6rF2zN9qL4sX7mC8vP1H.mdl",
	},
	["arrancar_zangetsu_fused_nocturne_outfit"] = {
		name = "Zangetsu fusionne - Nocturne",
		description = "Tenue Zangetsu fusionne - Nocturne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_M9tV4kQ7dR2xN6pZ8cL3S/evo_M9tV4kQ7dR2xN6pZ8cL3S.mdl",
	},
	["arrancar_zangetsu_fused_royal_outfit"] = {
		name = "Zangetsu fusionne - Royal",
		description = "Tenue Zangetsu fusionne - Royal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_G4yK8mT2qW7nR5vD9xC6P/evo_G4yK8mT2qW7nR5vD9xC6P.mdl",
	},
	["arrancar_zangetsu_fused_sanguin_outfit"] = {
		name = "Zangetsu fusionne - Sanguin",
		description = "Tenue Zangetsu fusionne - Sanguin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/evo_R8cN3zV6pK1mQ9tL4xD7F/evo_R8cN3zV6pK1mQ9tL4xD7F.mdl",
	},
	["arrancar_nelliel_v2_base_outfit"] = {
		name = "Nelliel",
		description = "Tenue Nelliel.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/evo_apmo541tgef57txr/evo_apmo541TGef57txr.mdl",
	},
	["arrancar_nelliel_v2_noir_charbon_outfit"] = {
		name = "Nelliel - Noir charbon",
		description = "Tenue Nelliel - Noir charbon.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_K8vN2qR6mX4cT9pL3dF7Y/evo_K8vN2qR6mX4cT9pL3dF7Y.mdl",
	},
	["arrancar_nelliel_v2_blanc_ivoire_outfit"] = {
		name = "Nelliel - Blanc ivoire",
		description = "Tenue Nelliel - Blanc ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_W4mP9xC2rT7vK5qN8dL3F/evo_W4mP9xC2rT7vK5qN8dL3F.mdl",
	},
	["arrancar_nelliel_v2_bleu_nuit_outfit"] = {
		name = "Nelliel - Bleu nuit",
		description = "Tenue Nelliel - Bleu nuit.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_B5nQ8vD2mT7xK4pR9cL3Y/evo_B5nQ8vD2mT7xK4pR9cL3Y.mdl",
	},
	["arrancar_nelliel_v2_violet_royal_outfit"] = {
		name = "Nelliel - Violet royal",
		description = "Tenue Nelliel - Violet royal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_V9pC4xM7qR2dK8tN5yL3F/evo_V9pC4xM7qR2dK8tN5yL3F.mdl",
	},
	["arrancar_nelliel_v2_or_beige_outfit"] = {
		name = "Nelliel - Or beige",
		description = "Tenue Nelliel - Or beige.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_G6mT2vQ9xP4cR7kN3dL8Y/evo_G6mT2vQ9xP4cR7kN3dL8Y.mdl",
	},
	["arrancar_nelliel_v2_bordeaux_outfit"] = {
		name = "Nelliel - Bordeaux",
		description = "Tenue Nelliel - Bordeaux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_D3rK8mV5qX9tP2cN7yL4F/evo_D3rK8mV5qX9tP2cN7yL4F.mdl",
	},
	["arrancar_nelliel_v2_gris_acier_outfit"] = {
		name = "Nelliel - Gris acier",
		description = "Tenue Nelliel - Gris acier.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/evo_S8xN4qT7mC2vR9pK5dL3Y/evo_S8xN4qT7mC2vR9pK5dL3Y.mdl",
	},
	["shinigami_ichigo_dangai_base_outfit"] = {
		name = "Ichigo Dangai",
		description = "Tenue Ichigo Dangai.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/shinigami/male/evo_zdexa254dzpomuk/evo_ZDExa254dzpomuk.mdl",
	},
	["shinigami_ichigo_dangai_noir_profond_outfit"] = {
		name = "Ichigo Dangai - Noir profond",
		description = "Tenue Ichigo Dangai - Noir profond.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Jn7Pz4RwCxD/evo_Jn7Pz4RwCxD.mdl",
	},
	["shinigami_ichigo_dangai_ivoire_inverse_outfit"] = {
		name = "Ichigo Dangai - Ivoire inverse",
		description = "Tenue Ichigo Dangai - Ivoire inverse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Qf5Nw8YaHsK/evo_Qf5Nw8YaHsK.mdl",
	},
	["shinigami_ichigo_dangai_rouge_sang_outfit"] = {
		name = "Ichigo Dangai - Rouge sang",
		description = "Tenue Ichigo Dangai - Rouge sang.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Bm3Xv9LeTuR/evo_Bm3Xv9LeTuR.mdl",
	},
	["shinigami_ichigo_dangai_bleu_nuit_outfit"] = {
		name = "Ichigo Dangai - Bleu nuit",
		description = "Tenue Ichigo Dangai - Bleu nuit.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Zp6Cd2KyWqF/evo_Zp6Cd2KyWqF.mdl",
	},
	["shinigami_ichigo_dangai_reiatsu_corrompu_outfit"] = {
		name = "Ichigo Dangai - Reiatsu corrompu",
		description = "Tenue Ichigo Dangai - Reiatsu corrompu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Hr8Vn4AsMjP/evo_Hr8Vn4AsMjP.mdl",
	},
	["shinigami_ichigo_dangai_noir_et_or_outfit"] = {
		name = "Ichigo Dangai - Noir et or",
		description = "Tenue Ichigo Dangai - Noir et or.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Lx2Gt7QeNkC/evo_Lx2Gt7QeNkC.mdl",
	},
	["shinigami_ichigo_dangai_ivoire_hollow_outfit"] = {
		name = "Ichigo Dangai - Ivoire Hollow",
		description = "Tenue Ichigo Dangai - Ivoire Hollow.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Wd9Sj5UfBaM/evo_Wd9Sj5UfBaM.mdl",
	},
	["shinigami_ichigo_dangai_gris_acier_outfit"] = {
		name = "Ichigo Dangai - Gris acier",
		description = "Tenue Ichigo Dangai - Gris acier.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Tk4Ry8PcVzG/evo_Tk4Ry8PcVzG.mdl",
	},
	["shinigami_ichigo_dangai_vert_spirituel_outfit"] = {
		name = "Ichigo Dangai - Vert spirituel",
		description = "Tenue Ichigo Dangai - Vert spirituel.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/evo_Nc7Hb3XmQjE/evo_Nc7Hb3XmQjE.mdl",
	},


	-- ─── ACCESSOIRES COFFRE (demande user 09/05) ────────────────────────────
	-- 16 tete + 10 corps, exclusifs au Coffre d'Accessoires (coffre_only cote
	-- shop_config, donc jamais en vitrine ni au Night Market). Slot par CHEMIN,
	-- comme les 49 accessoires de corps deja en place : head -> head, body -> cape.
	["lunettes_reishi"] = {
		name = "Lunettes Reishi",
		description = "Lunettes Reishi.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_reishi/lunettes_reishi.mdl",
	},
	["lunettes_rondes"] = {
		name = "Lunettes rondes dorees",
		description = "Lunettes rondes dorees.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_rondes/lunettes_rondes.mdl",
	},
	["bandeau_sceau"] = {
		name = "Bandeau du sceau",
		description = "Bandeau du sceau.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/bandeau_sceau/bandeau_sceau.mdl",
	},
	["bandeau_eventail"] = {
		name = "Bandeau eventail",
		description = "Bandeau eventail.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/bandeau_eventail/bandeau_eventail.mdl",
	},
	["boucles_anneaux"] = {
		name = "Boucles doubles anneaux",
		description = "Boucles doubles anneaux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/boucles_anneaux/boucles_anneaux.mdl",
	},
	["boucles_eventail"] = {
		name = "Boucles eventails",
		description = "Boucles eventails.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/boucles_eventail/boucles_eventail.mdl",
	},
	["kasa_ronin"] = {
		name = "Kasa du ronin",
		description = "Kasa du ronin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/kasa_ronin/kasa_ronin.mdl",
	},
	["cache_oeil_onyx"] = {
		name = "Cache-oeil Onyx",
		description = "Cache-oeil Onyx.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/cache_oeil_onyx/cache_oeil_onyx.mdl",
	},
	["cache_oeil_bandage"] = {
		name = "Cache-oeil Bandages",
		description = "Cache-oeil Bandages.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/cache_oeil_bandage/cache_oeil_bandage.mdl",
	},
	["boucles_ofuda"] = {
		name = "Boucles talismans",
		description = "Boucles talismans.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/boucles_ofuda/boucles_ofuda.mdl",
	},
	["boucles_croissant"] = {
		name = "Boucles lunaires",
		description = "Boucles lunaires.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/boucles_croissant/boucles_croissant.mdl",
	},
	["masque_kage"] = {
		name = "Demi-masque Kage",
		description = "Demi-masque Kage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/masque_kage/masque_kage.mdl",
	},
	["cache_oeil_ecarlate"] = {
		name = "Cache-oeil Ecarlate",
		description = "Cache-oeil Ecarlate.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_ecarlate/cache_oeil_ecarlate.mdl",
	},
	["cache_oeil_indigo"] = {
		name = "Cache-oeil Indigo gauche",
		description = "Cache-oeil Indigo gauche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_indigo/cache_oeil_indigo.mdl",
	},
	["diademe_croissant"] = {
		name = "Diademe du croissant",
		description = "Diademe du croissant.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/diademe_croissant/diademe_croissant.mdl",
	},
	["cache_oeil_laque"] = {
		name = "Cache-œil Laque dorée",
		description = "Cache-œil Laque dorée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_laque/cache_oeil_laque.mdl",
	},
	["gourde_bambou"] = {
		name = "Gourde en bambou",
		description = "Gourde en bambou.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/gourde_bambou/gourde_bambou.mdl",
	},
	["gourde_ceramique"] = {
		name = "Gourde en ceramique",
		description = "Gourde en ceramique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/gourde_ceramique/gourde_ceramique.mdl",
	},
	["rouleau_pelerin"] = {
		name = "Rouleau du pelerin",
		description = "Rouleau du pelerin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/rouleau_pelerin/rouleau_pelerin.mdl",
	},
	["echarpe_ecarlate"] = {
		name = "Echarpe ecarlate",
		description = "Echarpe ecarlate.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/echarpe_ecarlate/echarpe_ecarlate.mdl",
	},
	["gourde_ronin"] = {
		name = "Gourde du ronin",
		description = "Gourde du ronin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/gourde_ronin/gourde_ronin.mdl",
	},
	["rouleau_ecarlate"] = {
		name = "Rouleau ecarlate de ceinture",
		description = "Rouleau ecarlate de ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/rouleau_ecarlate/rouleau_ecarlate.mdl",
	},
	["collier_magatama"] = {
		name = "Collier Magatama",
		description = "Collier Magatama.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/collier_magatama/collier_magatama.mdl",
	},
	["baudrier_ofuda"] = {
		name = "Baudrier de talismans",
		description = "Baudrier de talismans.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/baudrier_ofuda/baudrier_ofuda.mdl",
	},
	["rouleaux_jumeaux"] = {
		name = "Rouleaux jumeaux",
		description = "Rouleaux jumeaux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/rouleaux_jumeaux/rouleaux_jumeaux.mdl",
	},
	["cape_veilleur"] = {
		name = "Cape du veilleur",
		description = "Cape du veilleur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/cape_veilleur/cape_veilleur.mdl",
	},


	-- ─── ACCESSOIRES COFFRE, 2e lot (09/05) ─────────────────────────────────
	-- Chapeaux, lunettes, cache-oeil et pieces de voyage. Memes regles que le lot
	-- precedent : slot deduit du chemin, coffre_only cote shop_config.
	["kasa_voyageur"] = {
		name = "Kasa du voyageur",
		description = "Kasa du voyageur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/kasa_voyageur/kasa_voyageur.mdl",
	},
	["amigasa_tresse"] = {
		name = "Amigasa tresse",
		description = "Amigasa tresse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/amigasa_tresse/amigasa_tresse.mdl",
	},
	["lunettes_hexagonales"] = {
		name = "Lunettes hexagonales",
		description = "Lunettes hexagonales.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_hexagonales/lunettes_hexagonales.mdl",
	},
	["lunettes_demi_lune"] = {
		name = "Lunettes demi-lune",
		description = "Lunettes demi-lune.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_demi_lune/lunettes_demi_lune.mdl",
	},
	["sandogasa"] = {
		name = "Sandogasa a large bord",
		description = "Sandogasa a large bord.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/sandogasa/sandogasa.mdl",
	},
	["eboshi"] = {
		name = "Eboshi noir",
		description = "Eboshi noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/eboshi/eboshi.mdl",
	},
	["lunettes_etroites"] = {
		name = "Lunettes etroites fumees",
		description = "Lunettes etroites fumees.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/lunettes_etroites/lunettes_etroites.mdl",
	},
	["lunettes_pince_nez"] = {
		name = "Lunettes pince-nez",
		description = "Lunettes pince-nez.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/lunettes_pince_nez/lunettes_pince_nez.mdl",
	},
	["cache_oeil_tresse"] = {
		name = "Cache-oeil tresse",
		description = "Cache-oeil tresse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/cache_oeil_tresse/cache_oeil_tresse.mdl",
	},
	["jingasa_laque"] = {
		name = "Jingasa laque",
		description = "Jingasa laque.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/jingasa_laque/jingasa_laque.mdl",
	},
	["cache_oeil_croissant"] = {
		name = "Cache-oeil du croissant",
		description = "Cache-oeil du croissant.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_croissant/cache_oeil_croissant.mdl",
	},
	["cache_oeil_renforce"] = {
		name = "Cache-oeil renforce",
		description = "Cache-oeil renforce.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/cache_oeil_renforce/cache_oeil_renforce.mdl",
	},
	["gourde_plate_hanche"] = {
		name = "Gourde plate indigo",
		description = "Gourde plate indigo.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/gourde_plate_hanche/gourde_plate_hanche.mdl",
	},
	["gourde_petite_voyage"] = {
		name = "Petite gourde de voyage",
		description = "Petite gourde de voyage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/gourde_petite_voyage/gourde_petite_voyage.mdl",
	},
	["gourdes_bambou_jumelles"] = {
		name = "Gourdes bambou jumelles",
		description = "Gourdes bambou jumelles.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/gourdes_bambou_jumelles/gourdes_bambou_jumelles.mdl",
	},
	["eventail_ceinture"] = {
		name = "Eventail de ceinture",
		description = "Eventail de ceinture.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/eventail_ceinture/eventail_ceinture.mdl",
	},
	["gourde_geante_dos"] = {
		name = "Grande gourde dorsale",
		description = "Grande gourde dorsale.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/gourde_geante_dos/gourde_geante_dos.mdl",
	},
	["ombrelle_dos"] = {
		name = "Ombrelle de voyage",
		description = "Ombrelle de voyage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/ombrelle_dos/ombrelle_dos.mdl",
	},


	-- ─── MASQUES D'ARRANCAR, coffre (demande user 09/05) ─────────────────────
	-- ⚠ Les 10 legendaires/mythiques de ce bloc (loup blanc ... chimere blanche) ne sont
	-- vendus NULLE PART depuis le 09/06 (aucune ligne shop_config) : fiches DORMANTES,
	-- gardees pour qu'un exemplaire deja tire reste valide. Supprimables si personne n'en a.
	-- 25 masques, 5 par palier jusqu'a mythique (raretes fournies). Chemin /arr_mask/ =
	-- reconnus masques par IsMaskAccessory (slot dedie, rotation). Faction Hollow cote
	-- shop_config, coffre_only : jamais en vitrine ni au Night Market.
	["arr_eclat_joue"] = {
		name = "Éclat de joue",
		description = "Masque d'Arrancar : Éclat de joue.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/arr_mask/arr_eclat_joue/arr_eclat_joue.mdl",
	},
	["arr_croc_isole"] = {
		name = "Croc isolé",
		description = "Masque d'Arrancar : Croc isolé.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/arr_mask/arr_croc_isole/arr_croc_isole.mdl",
	},
	["arr_front_fendu"] = {
		name = "Front fendu",
		description = "Masque d'Arrancar : Front fendu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/arr_mask/arr_front_fendu/arr_front_fendu.mdl",
	},
	["arr_menton_osseux"] = {
		name = "Menton osseux",
		description = "Masque d'Arrancar : Menton osseux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/arr_mask/arr_menton_osseux/arr_menton_osseux.mdl",
	},
	["arr_tempe_brisee"] = {
		name = "Tempe brisée",
		description = "Masque d'Arrancar : Tempe brisée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/arr_mask/arr_tempe_brisee/arr_tempe_brisee.mdl",
	},
	["arr_machoire_fauve"] = {
		name = "Mâchoire fauve",
		description = "Masque d'Arrancar : Mâchoire fauve.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/arr_machoire_fauve/arr_machoire_fauve.mdl",
	},
	["arr_orbite_fendue"] = {
		name = "Orbite fendue",
		description = "Masque d'Arrancar : Orbite fendue.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/arr_orbite_fendue/arr_orbite_fendue.mdl",
	},
	["arr_corne_naissante"] = {
		name = "Corne naissante",
		description = "Masque d'Arrancar : Corne naissante.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/arr_corne_naissante/arr_corne_naissante.mdl",
	},
	["arr_crete_nasale"] = {
		name = "Crête nasale",
		description = "Masque d'Arrancar : Crête nasale.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/arr_crete_nasale/arr_crete_nasale.mdl",
	},
	["arr_double_eclat"] = {
		name = "Double éclat",
		description = "Masque d'Arrancar : Double éclat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/arr_double_eclat/arr_double_eclat.mdl",
	},
	["arr_demi_predateur"] = {
		name = "Demi-prédateur",
		description = "Masque d'Arrancar : Demi-prédateur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/arr_demi_predateur/arr_demi_predateur.mdl",
	},
	["arr_belier_brise"] = {
		name = "Bélier brisé",
		description = "Masque d'Arrancar : Bélier brisé.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/arr_belier_brise/arr_belier_brise.mdl",
	},
	["arr_mante_osseuse"] = {
		name = "Mante osseuse",
		description = "Masque d'Arrancar : Mante osseuse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/arr_mante_osseuse/arr_mante_osseuse.mdl",
	},
	["arr_crane_fissure"] = {
		name = "Crâne fissuré",
		description = "Masque d'Arrancar : Crâne fissuré.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/arr_crane_fissure/arr_crane_fissure.mdl",
	},
	["arr_croissant_funebre"] = {
		name = "Croissant funèbre",
		description = "Masque d'Arrancar : Croissant funèbre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/arr_croissant_funebre/arr_croissant_funebre.mdl",
	},
	["arr_loup_blanc"] = {
		name = "Loup blanc",
		description = "Masque d'Arrancar : Loup blanc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/arr_loup_blanc/arr_loup_blanc.mdl",
	},
	["arr_oni_asymetrique"] = {
		name = "Oni asymétrique",
		description = "Masque d'Arrancar : Oni asymétrique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/arr_oni_asymetrique/arr_oni_asymetrique.mdl",
	},
	["arr_scorpion"] = {
		name = "Scorpion",
		description = "Masque d'Arrancar : Scorpion.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/arr_scorpion/arr_scorpion.mdl",
	},
	["arr_dragon_brise"] = {
		name = "Dragon brisé",
		description = "Masque d'Arrancar : Dragon brisé.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/arr_dragon_brise/arr_dragon_brise.mdl",
	},
	["arr_visage_du_neant"] = {
		name = "Visage du néant",
		description = "Masque d'Arrancar : Visage du néant.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_mask/arr_visage_du_neant/arr_visage_du_neant.mdl",
	},
	["arr_couronne_du_vide"] = {
		name = "Couronne du vide",
		description = "Masque d'Arrancar : Couronne du vide.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/arr_couronne_du_vide/arr_couronne_du_vide.mdl",
	},
	["arr_leviathan"] = {
		name = "Léviathan",
		description = "Masque d'Arrancar : Léviathan.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/arr_leviathan/arr_leviathan.mdl",
	},
	["arr_eclipse_osseuse"] = {
		name = "Éclipse osseuse",
		description = "Masque d'Arrancar : Éclipse osseuse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/arr_eclipse_osseuse/arr_eclipse_osseuse.mdl",
	},
	["arr_souverain_cornu"] = {
		name = "Souverain cornu",
		description = "Masque d'Arrancar : Souverain cornu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/arr_souverain_cornu/arr_souverain_cornu.mdl",
	},
	["arr_chimere_blanche"] = {
		name = "Chimère blanche",
		description = "Masque d'Arrancar : Chimère blanche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/arr_mask/arr_chimere_blanche/arr_chimere_blanche.mdl",
	},


	-- ─── ACCESSOIRES COFFRE, 3e lot (09/06) ─────────────────────────────────
	-- 25 pieces, 5 par palier jusqu'a mythique (raretes fournies). Memes regles :
	-- slot deduit du chemin, coffre_only cote shop_config, sans faction.
	["pochette_indigo"] = {
		name = "Pochette indigo",
		description = "Pochette indigo.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/pochette_indigo/pochette_indigo.mdl",
	},
	["peigne_ambre"] = {
		name = "Peigne d’ambre",
		description = "Peigne d’ambre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/peigne_ambre/peigne_ambre.mdl",
	},
	["lunettes_hexagonales_argent"] = {
		name = "Lunettes hexagonales argent",
		description = "Lunettes hexagonales argent.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_hexagonales_argent/lunettes_hexagonales_argent.mdl",
	},
	["soroban_voyage"] = {
		name = "Boulier de voyage",
		description = "Boulier de voyage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/soroban_voyage/soroban_voyage.mdl",
	},
	["boite_encens"] = {
		name = "Boîte à encens",
		description = "Boîte à encens.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/boite_encens/boite_encens.mdl",
	},
	["inro_laque"] = {
		name = "Inrō laqué",
		description = "Inrō laqué.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/inro_laque/inro_laque.mdl",
	},
	["gourde_octogonale_jade"] = {
		name = "Flasque octogonale de jade",
		description = "Flasque octogonale de jade.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/gourde_octogonale_jade/gourde_octogonale_jade.mdl",
	},
	["boucles_suzu"] = {
		name = "Boucles Suzu",
		description = "Boucles Suzu.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/boucles_suzu/boucles_suzu.mdl",
	},
	["lunettes_double_pont"] = {
		name = "Lunettes à double pont",
		description = "Lunettes à double pont.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/lunettes_double_pont/lunettes_double_pont.mdl",
	},
	["chapeau_tresse_indigo"] = {
		name = "Chapeau tressé indigo",
		description = "Chapeau tressé indigo.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/chapeau_tresse_indigo/chapeau_tresse_indigo.mdl",
	},
	["cache_oeil_grue"] = {
		name = "Cache-œil de la grue",
		description = "Cache-œil de la grue.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_grue/cache_oeil_grue.mdl",
	},
	["cache_oeil_kitsune"] = {
		name = "Cache-œil du renard",
		description = "Cache-œil du renard.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_kitsune/cache_oeil_kitsune.mdl",
	},
	["lunettes_papillon"] = {
		name = "Lunettes Papillon",
		description = "Lunettes Papillon.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/lunettes_papillon/lunettes_papillon.mdl",
	},
	["tambour_tsuzumi"] = {
		name = "Tambour Tsuzumi",
		description = "Tambour Tsuzumi.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/tambour_tsuzumi/tambour_tsuzumi.mdl",
	},
	["gourde_porcelain_vagues"] = {
		name = "Gourde de porcelaine aux vagues",
		description = "Gourde de porcelaine aux vagues.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/gourde_porcelain_vagues/gourde_porcelain_vagues.mdl",
	},
	["cache_oeil_kintsugi"] = {
		name = "Cache-œil Kintsugi",
		description = "Cache-œil Kintsugi.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/cache_oeil_kintsugi/cache_oeil_kintsugi.mdl",
	},
	["kanzashi_prunier"] = {
		name = "Kanzashi du prunier",
		description = "Kanzashi du prunier.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/kanzashi_prunier/kanzashi_prunier.mdl",
	},
	["boucles_carpes"] = {
		name = "Boucles carpes",
		description = "Boucles carpes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/boucles_carpes/boucles_carpes.mdl",
	},
	["tonnelet_brasseur"] = {
		name = "Tonnelet du brasseur",
		description = "Tonnelet du brasseur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/tonnelet_brasseur/tonnelet_brasseur.mdl",
	},
	["etui_parchemins"] = {
		name = "Étui à parchemins",
		description = "Étui à parchemins.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/etui_parchemins/etui_parchemins.mdl",
	},
	["chapeau_komuso"] = {
		name = "Panier du Komusō",
		description = "Panier du Komusō.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/chapeau_komuso/chapeau_komuso.mdl",
	},
	["jingasa_couronne"] = {
		name = "Jingasa couronné",
		description = "Jingasa couronné.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/jingasa_couronne/jingasa_couronne.mdl",
	},
	["kanzashi_phenix"] = {
		name = "Kanzashi Phénix",
		description = "Kanzashi Phénix.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/kanzashi_phenix/kanzashi_phenix.mdl",
	},
	["eventail_dorsal_sakura"] = {
		name = "Éventail dorsal Sakura",
		description = "Éventail dorsal Sakura.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "mythic",
		model_path = "models/evo/accessories/body/eventail_dorsal_sakura/eventail_dorsal_sakura.mdl",
	},
	["astrolabe_jade"] = {
		name = "Astrolabe de jade",
		description = "Astrolabe de jade.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps", -- coffre spécialisé (09/08)
		slot = "cape",
		rarity = "mythic",
		model_path = "models/evo/accessories/body/astrolabe_jade/astrolabe_jade.mdl",
	},


	-- ─── ACCESSOIRES COFFRE, 4e lot (09/06) : 6 pieces de tete, une par palier ─────
	["lunettes_oracle_unibranche"] = {
		name = "Lunettes de l’Oracle",
		description = "Lunettes de l’Oracle.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_oracle_unibranche/lunettes_oracle_unibranche.mdl",
	},
	["monocle_sept_sceaux"] = {
		name = "Monocle des Sept Sceaux",
		description = "Monocle des Sept Sceaux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/monocle_sept_sceaux/monocle_sept_sceaux.mdl",
	},
	["bandeau_serment_ecarlate"] = {
		name = "Bandeau du Serment écarlate",
		description = "Bandeau du Serment écarlate.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08), Visage & ornements (user 09/08)
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/bandeau_serment_ecarlate/bandeau_serment_ecarlate.mdl",
	},
	["cache_oeil_orage_carmin"] = {
		name = "Cache-œil Orage carmin",
		description = "Cache-œil Orage carmin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/cache_oeil_orage_carmin/cache_oeil_orage_carmin.mdl",
	},
	["bandeau_silence_imperial"] = {
		name = "Bandeau du Silence impérial",
		description = "Bandeau du Silence impérial.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bandeau_silence_imperial/bandeau_silence_imperial.mdl",
	},
	["cache_oeil_eclipse_souveraine"] = {
		name = "Cache-œil Éclipse souveraine",
		description = "Cache-œil Éclipse souveraine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/cache_oeil_eclipse_souveraine/cache_oeil_eclipse_souveraine.mdl",
	},


	-- ─── TENUES ARRANCAR neuves, coffre (user 09/06) : 2 sets x 2 genres, epic ────
	["arrancar_errant_du_sable_m_outfit"] = {
		name = "Errant du sable",
		description = "Tenue Errant du sable.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_errant_du_sable_m/arrancar_errant_du_sable_m.mdl",
	},
	["arrancar_nomade_du_crepuscule_m_outfit"] = {
		name = "Nomade du crépuscule",
		description = "Tenue Nomade du crépuscule.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arrancar_nomade_du_crepuscule_m/arrancar_nomade_du_crepuscule_m.mdl",
	},
	["arrancar_errant_du_sable_f_outfit"] = {
		name = "Errant du sable (Femme)",
		description = "Tenue Errant du sable (Femme).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/arrancar_errant_du_sable_f/arrancar_errant_du_sable_f.mdl",
	},
	["arrancar_nomade_du_crepuscule_f_outfit"] = {
		name = "Nomade du crépuscule (Femme)",
		description = "Tenue Nomade du crépuscule (Femme).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/arrancar_nomade_du_crepuscule_f/arrancar_nomade_du_crepuscule_f.mdl",
	},


	-- ─── TENUES ARRANCAR FEMMES, coffre (user 09/06) : 25, 10 common / 5 rare / 5 epic / 5 mythic ─
	-- Genre deduit du chemin (/female/). coffre_only + faction Hollow cote shop_config.
	["af_uniforme_craie_outfit"] = {
		name = "Uniforme de craie",
		description = "Tenue Uniforme de craie.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_craie/af_uniforme_craie.mdl",
	},
	["af_uniforme_sable_outfit"] = {
		name = "Uniforme de sable",
		description = "Tenue Uniforme de sable.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_sable/af_uniforme_sable.mdl",
	},
	["af_uniforme_argile_outfit"] = {
		name = "Uniforme d’argile",
		description = "Tenue Uniforme d’argile.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_argile/af_uniforme_argile.mdl",
	},
	["af_uniforme_cendre_outfit"] = {
		name = "Uniforme de cendre",
		description = "Tenue Uniforme de cendre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_cendre/af_uniforme_cendre.mdl",
	},
	["af_uniforme_ardoise_outfit"] = {
		name = "Uniforme d’ardoise",
		description = "Tenue Uniforme d’ardoise.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_ardoise/af_uniforme_ardoise.mdl",
	},
	["af_uniforme_olive_outfit"] = {
		name = "Uniforme olive",
		description = "Tenue Uniforme olive.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_olive/af_uniforme_olive.mdl",
	},
	["af_uniforme_marine_outfit"] = {
		name = "Uniforme marine",
		description = "Tenue Uniforme marine.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_marine/af_uniforme_marine.mdl",
	},
	["af_uniforme_prune_outfit"] = {
		name = "Uniforme prune",
		description = "Tenue Uniforme prune.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_prune/af_uniforme_prune.mdl",
	},
	["af_uniforme_rouille_outfit"] = {
		name = "Uniforme rouille",
		description = "Tenue Uniforme rouille.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_rouille/af_uniforme_rouille.mdl",
	},
	["af_uniforme_sauge_outfit"] = {
		name = "Uniforme sauge",
		description = "Tenue Uniforme sauge.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/af_uniforme_sauge/af_uniforme_sauge.mdl",
	},
	["af_vigie_petrole_outfit"] = {
		name = "Vigie pétrole",
		description = "Tenue Vigie pétrole.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/af_vigie_petrole/af_vigie_petrole.mdl",
	},
	["af_vigie_carmin_outfit"] = {
		name = "Vigie carmin",
		description = "Tenue Vigie carmin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/af_vigie_carmin/af_vigie_carmin.mdl",
	},
	["af_duelliste_safran_outfit"] = {
		name = "Duelliste safran",
		description = "Tenue Duelliste safran.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/af_duelliste_safran/af_duelliste_safran.mdl",
	},
	["af_duelliste_lilas_outfit"] = {
		name = "Duelliste lilas",
		description = "Tenue Duelliste lilas.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/af_duelliste_lilas/af_duelliste_lilas.mdl",
	},
	["af_voyageuse_cuivree_outfit"] = {
		name = "Voyageuse cuivrée",
		description = "Tenue Voyageuse cuivrée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/af_voyageuse_cuivree/af_voyageuse_cuivree.mdl",
	},
	["af_amazone_lagune_outfit"] = {
		name = "Amazone lagune",
		description = "Tenue Amazone lagune.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/af_amazone_lagune/af_amazone_lagune.mdl",
	},
	["af_amazone_grenat_outfit"] = {
		name = "Amazone grenat",
		description = "Tenue Amazone grenat.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/af_amazone_grenat/af_amazone_grenat.mdl",
	},
	["af_danseuse_iris_outfit"] = {
		name = "Danseuse iris",
		description = "Tenue Danseuse iris.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/af_danseuse_iris/af_danseuse_iris.mdl",
	},
	["af_danseuse_minuit_outfit"] = {
		name = "Danseuse de minuit",
		description = "Tenue Danseuse de minuit.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/af_danseuse_minuit/af_danseuse_minuit.mdl",
	},
	["af_vestige_foret_outfit"] = {
		name = "Vestige de la forêt",
		description = "Tenue Vestige de la forêt.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/af_vestige_foret/af_vestige_foret.mdl",
	},
	["af_valkyrie_aube_outfit"] = {
		name = "Valkyrie de l’aube",
		description = "Tenue Valkyrie de l’aube.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/af_valkyrie_aube/af_valkyrie_aube.mdl",
	},
	["af_valkyrie_eclipse_outfit"] = {
		name = "Valkyrie de l’éclipse",
		description = "Tenue Valkyrie de l’éclipse.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/af_valkyrie_eclipse/af_valkyrie_eclipse.mdl",
	},
	["af_valkyrie_givre_outfit"] = {
		name = "Valkyrie du givre",
		description = "Tenue Valkyrie du givre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/af_valkyrie_givre/af_valkyrie_givre.mdl",
	},
	["af_imperatrice_rose_outfit"] = {
		name = "Impératrice de la rose",
		description = "Tenue Impératrice de la rose.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/af_imperatrice_rose/af_imperatrice_rose.mdl",
	},
	["af_souveraine_braise_outfit"] = {
		name = "Souveraine des braises",
		description = "Tenue Souveraine des braises.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "mythic",
		model_path = "models/evo/characters/arrancar/female/af_souveraine_braise/af_souveraine_braise.mdl",
	},


	-- ─── ACCESSOIRES URAHARA (yens), palier d'entree (user 09/06) : 5, common ─────────
	["bourse_yens_toile"] = {
		name = "Bourse en toile",
		description = "Bourse en toile.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/bourse_yens_toile/bourse_yens_toile.mdl",
	},
	["gourde_yens_bois"] = {
		name = "Gourde en bois",
		description = "Gourde en bois.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/gourde_yens_bois/gourde_yens_bois.mdl",
	},
	["lunettes_yens_noires"] = {
		name = "Lunettes noires simples",
		description = "Lunettes noires simples.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_yens_noires/lunettes_yens_noires.mdl",
	},
	["lunettes_yens_rondes"] = {
		name = "Lunettes rondes simples",
		description = "Lunettes rondes simples.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/lunettes_yens_rondes/lunettes_yens_rondes.mdl",
	},
	["chapeau_yens_paille"] = {
		name = "Chapeau de paille simple",
		description = "Chapeau de paille simple.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/chapeau_yens_paille/chapeau_yens_paille.mdl",
	},


	-- ─── TENUES SHINIGAMI HOMMES, coffre (user 09/06) : Manche déchirée rare, Getsuga chaînes légendaire ─
	["shinigami_base_manche_dechiree_outfit"] = {
		name = "Manche déchirée",
		description = "Tenue Manche déchirée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/male/shinigami_base_manche_dechiree/shinigami_base_manche_dechiree.mdl",
	},
	["shinigami_getsuga_chaines_outfit"] = {
		name = "Getsuga chaînes",
		description = "Tenue Getsuga chaînes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/shinigami/male/shinigami_getsuga_chaines/shinigami_getsuga_chaines.mdl",
	},

	-- Coffre d'accessoires (user 09/06) : mythique.
	["chapeau_voiles_lunaires"] = {
		name = "Chapeau aux voiles lunaires",
		description = "Accessoire Chapeau aux voiles lunaires.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/chapeau_voiles_lunaires/chapeau_voiles_lunaires.mdl",
	},

	-- ─── TENUES FEMMES URAHARA (yens), user 09/07 : 4 Shinigami + 4 Arrancar, common/rare/epic ─
	-- Genre déduit du chemin (/female/), faction du chemin (/shinigami/ ou /arrancar/).
	["urahara_f_fumee_outfit"] = {
		name = "Uniforme fumée",
		description = "Tenue Uniforme fumée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/urahara_f_fumee/urahara_f_fumee.mdl",
	},
	["urahara_f_encre_outfit"] = {
		name = "Uniforme encre",
		description = "Tenue Uniforme encre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/shinigami/female/urahara_f_encre/urahara_f_encre.mdl",
	},
	["urahara_f_terre_outfit"] = {
		name = "Uniforme terre",
		description = "Tenue Uniforme terre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/shinigami/female/urahara_f_terre/urahara_f_terre.mdl",
	},
	["urahara_f_pin_outfit"] = {
		name = "Uniforme pin",
		description = "Tenue Uniforme pin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/shinigami/female/urahara_f_pin/urahara_f_pin.mdl",
	},
	["urahara_f_lin_outfit"] = {
		name = "Uniforme lin",
		description = "Tenue Uniforme lin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/urahara_f_lin/urahara_f_lin.mdl",
	},
	["urahara_f_lichen_outfit"] = {
		name = "Uniforme lichen",
		description = "Tenue Uniforme lichen.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "common",
		model_path = "models/evo/characters/arrancar/female/urahara_f_lichen/urahara_f_lichen.mdl",
	},
	["urahara_f_argile_claire_outfit"] = {
		name = "Uniforme argile claire",
		description = "Tenue Uniforme argile claire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "rare",
		model_path = "models/evo/characters/arrancar/female/urahara_f_argile_claire/urahara_f_argile_claire.mdl",
	},
	["urahara_f_galet_outfit"] = {
		name = "Uniforme galet",
		description = "Tenue Uniforme galet.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/urahara_f_galet/urahara_f_galet.mdl",
	},

	-- ─── BANDEAUX + CACHE-ŒIL, coffre d'accessoires (user 09/07) : 3 epic / 4 legendary / 3 mythic ─
	["bandeau_vagues_saphir"] = {
		name = "Bandeau des Vagues saphir",
		description = "Accessoire Bandeau des Vagues saphir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bandeau_vagues_saphir/bandeau_vagues_saphir.mdl",
	},
	["bandeau_bambou_jade"] = {
		name = "Bandeau du Bambou de jade",
		description = "Accessoire Bandeau du Bambou de jade.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bandeau_bambou_jade/bandeau_bambou_jade.mdl",
	},
	["bandeau_prunier_amethyste"] = {
		name = "Bandeau du Prunier améthyste",
		description = "Accessoire Bandeau du Prunier améthyste.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/bandeau_prunier_amethyste/bandeau_prunier_amethyste.mdl",
	},
	["bandeau_grue_ivoire"] = {
		name = "Bandeau de la Grue d’ivoire",
		description = "Accessoire Bandeau de la Grue d’ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bandeau_grue_ivoire/bandeau_grue_ivoire.mdl",
	},
	["bandeau_soleil_carmin"] = {
		name = "Bandeau du Soleil carmin",
		description = "Accessoire Bandeau du Soleil carmin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/bandeau_soleil_carmin/bandeau_soleil_carmin.mdl",
	},
	["cache_oeil_cristal_azur"] = {
		name = "Cache-œil Cristal azur",
		description = "Accessoire Cache-œil Cristal azur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/cache_oeil_cristal_azur/cache_oeil_cristal_azur.mdl",
	},
	["cache_oeil_vague_jade"] = {
		name = "Cache-œil Vague de jade",
		description = "Accessoire Cache-œil Vague de jade.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/cache_oeil_vague_jade/cache_oeil_vague_jade.mdl",
	},
	["cache_oeil_plumes_amethyste"] = {
		name = "Cache-œil Plumes d’améthyste",
		description = "Accessoire Cache-œil Plumes d’améthyste.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/cache_oeil_plumes_amethyste/cache_oeil_plumes_amethyste.mdl",
	},
	["cache_oeil_rosace_ivoire"] = {
		name = "Cache-œil Rosace d’ivoire",
		description = "Accessoire Cache-œil Rosace d’ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/cache_oeil_rosace_ivoire/cache_oeil_rosace_ivoire.mdl",
	},
	["cache_oeil_eclats_braise"] = {
		name = "Cache-œil Éclats de braise",
		description = "Accessoire Cache-œil Éclats de braise.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "visage", -- coffre spécialisé (09/08)
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/cache_oeil_eclats_braise/cache_oeil_eclats_braise.mdl",
	},

	-- ─── BOUTIQUE ARRANCAR, vitrine coins (user 09/08) : 4 tenues + 6 accessoires, Hollow ───
	["arr_gardien_dunes_male_outfit"] = {
		name = "Gardien des Dunes",
		description = "Tenue Gardien des Dunes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/male/arr_gardien_dunes_male/arr_gardien_dunes_male.mdl",
	},
	["arr_gardien_dunes_female_outfit"] = {
		name = "Gardien des Dunes (Femme)",
		description = "Tenue Gardien des Dunes (Femme).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "epic",
		model_path = "models/evo/characters/arrancar/female/arr_gardien_dunes_female/arr_gardien_dunes_female.mdl",
	},
	["arr_arpenteur_cendres_male_outfit"] = {
		name = "Arpenteur des Cendres",
		description = "Tenue Arpenteur des Cendres.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/male/arr_arpenteur_cendres_male/arr_arpenteur_cendres_male.mdl",
	},
	["arr_arpenteur_cendres_female_outfit"] = {
		name = "Arpenteur des Cendres (Femme)",
		description = "Tenue Arpenteur des Cendres (Femme).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "outfit",
		rarity = "legendary",
		model_path = "models/evo/characters/arrancar/female/arr_arpenteur_cendres_female/arr_arpenteur_cendres_female.mdl",
	},
	["arr_etui_lames_os"] = {
		name = "Étui des Lames d’os",
		description = "Accessoire Étui des Lames d’os.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "rare",
		model_path = "models/evo/accessories/body/arr_etui_lames_os/arr_etui_lames_os.mdl",
	},
	["arr_reliquaire_amethyste"] = {
		name = "Reliquaire d’Améthyste",
		description = "Accessoire Reliquaire d’Améthyste.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "epic",
		model_path = "models/evo/accessories/body/arr_reliquaire_amethyste/arr_reliquaire_amethyste.mdl",
	},
	["arr_parchemin_sceaux"] = {
		name = "Parchemin des Sceaux",
		description = "Accessoire Parchemin des Sceaux.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "epic",
		model_path = "models/evo/accessories/body/arr_parchemin_sceaux/arr_parchemin_sceaux.mdl",
	},
	["arr_vase_reliques"] = {
		name = "Vase des Reliques",
		description = "Accessoire Vase des Reliques.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "legendary",
		model_path = "models/evo/accessories/body/arr_vase_reliques/arr_vase_reliques.mdl",
	},
	["arr_chapeau_pelerin"] = {
		name = "Chapeau du Pèlerin pâle",
		description = "Accessoire Chapeau du Pèlerin pâle.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "legendary",
		model_path = "models/evo/accessories/head/arr_chapeau_pelerin/arr_chapeau_pelerin.mdl",
	},
	["arr_eventail_crepuscule"] = {
		name = "Éventail du Crépuscule",
		description = "Accessoire Éventail du Crépuscule.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Hollow", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "legendary",
		model_path = "models/evo/accessories/body/arr_eventail_crepuscule/arr_eventail_crepuscule.mdl",
	},

	-- ─── BOUTIQUE SHINIGAMI, vitrine coins (user 09/08) : 6 accessoires, Shinigami ───
	["shinobi_etui_kunai"] = {
		name = "Étui de kunai des Sables",
		description = "Accessoire Étui de kunai des Sables.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "rare",
		model_path = "models/evo/accessories/body/shinobi_etui_kunai/shinobi_etui_kunai.mdl",
	},
	["naruto_chapeau_deserteur"] = {
		name = "Chapeau du déserteur",
		description = "Accessoire Chapeau du déserteur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "legendary",
		model_path = "models/evo/accessories/head/naruto_chapeau_deserteur/naruto_chapeau_deserteur.mdl",
	},
	["naruto_pochette_cuisse"] = {
		name = "Pochette de cuisse shinobi",
		description = "Accessoire Pochette de cuisse shinobi.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "rare",
		model_path = "models/evo/accessories/body/naruto_pochette_cuisse/naruto_pochette_cuisse.mdl",
	},
	["naruto_sacoche_nuages"] = {
		name = "Sacoche aux nuages rouges",
		description = "Accessoire Sacoche aux nuages rouges.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "epic",
		model_path = "models/evo/accessories/body/naruto_sacoche_nuages/naruto_sacoche_nuages.mdl",
	},
	["naruto_grand_rouleau_dorsal"] = {
		name = "Grand rouleau dorsal",
		description = "Accessoire Grand rouleau dorsal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "legendary",
		model_path = "models/evo/accessories/body/naruto_grand_rouleau_dorsal/naruto_grand_rouleau_dorsal.mdl",
	},
	["naruto_sacoche_son"] = {
		name = "Sacoche du Son",
		description = "Accessoire Sacoche du Son.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "cape",
		faction = "Shinigami", -- chemin sans marqueur de faction : gate d'équip explicite
		rarity = "epic",
		model_path = "models/evo/accessories/body/naruto_sacoche_son/naruto_sacoche_son.mdl",
	},

	-- ─── LOT COFFRES 09/08 (bis) : 11 coiffes (chapeaux) + 8 accessoires de corps (corps) ───
	["tenugui_pecheur"] = {
		name = "Kasa de paille du pêcheur",
		description = "Accessoire Kasa de paille du pêcheur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/tenugui_pecheur/tenugui_pecheur.mdl",
	},
	["bonnet_lin_porteur"] = {
		name = "Kasa du porteur",
		description = "Accessoire Kasa du porteur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/bonnet_lin_porteur/bonnet_lin_porteur.mdl",
	},
	["calot_marchand"] = {
		name = "Sugegasa du marchand",
		description = "Accessoire Sugegasa du marchand.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/calot_marchand/calot_marchand.mdl",
	},
	["happuri_cuir_laque"] = {
		name = "Jingasa de laque sombre",
		description = "Accessoire Jingasa de laque sombre.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/happuri_cuir_laque/happuri_cuir_laque.mdl",
	},
	["coiffe_cloche_bambou"] = {
		name = "Kasa du bambou tressé",
		description = "Accessoire Kasa du bambou tressé.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/coiffe_cloche_bambou/coiffe_cloche_bambou.mdl",
	},
	["capuche_route_indigo"] = {
		name = "Kasa indigo du voyageur",
		description = "Accessoire Kasa indigo du voyageur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/capuche_route_indigo/capuche_route_indigo.mdl",
	},
	["kabuto_lune_descendante"] = {
		name = "Kasa des vagues nocturnes",
		description = "Accessoire Kasa des vagues nocturnes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/kabuto_lune_descendante/kabuto_lune_descendante.mdl",
	},
	["toque_ginkgo_carmin"] = {
		name = "Kasa du prunier carmin",
		description = "Accessoire Kasa du prunier carmin.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/toque_ginkgo_carmin/toque_ginkgo_carmin.mdl",
	},
	["coiffe_corde_rituelle"] = {
		name = "Kasa du sanctuaire",
		description = "Accessoire Kasa du sanctuaire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/coiffe_corde_rituelle/coiffe_corde_rituelle.mdl",
	},
	["kabuto_tempete_jade"] = {
		name = "Kasa de la marée de jade",
		description = "Accessoire Kasa de la marée de jade.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/kabuto_tempete_jade/kabuto_tempete_jade.mdl",
	},
	["kabuto_phoenix_cendre"] = {
		name = "Kasa du crépuscule doré",
		description = "Accessoire Kasa du crépuscule doré.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/kabuto_phoenix_cendre/kabuto_phoenix_cendre.mdl",
	},
	["sandales_route_hanche"] = {
		name = "Sandales de route à la hanche",
		description = "Accessoire Sandales de route à la hanche.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/sandales_route_hanche/sandales_route_hanche.mdl",
	},
	["etui_pinceaux_voyage"] = {
		name = "Étui de pinceaux de voyage",
		description = "Accessoire Étui de pinceaux de voyage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "common",
		model_path = "models/evo/accessories/body/etui_pinceaux_voyage/etui_pinceaux_voyage.mdl",
	},
	["coffret_tisanes"] = {
		name = "Coffret des tisanes",
		description = "Accessoire Coffret des tisanes.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "rare",
		model_path = "models/evo/accessories/body/coffret_tisanes/coffret_tisanes.mdl",
	},
	["autel_miroir_dorsal"] = {
		name = "Autel du miroir dorsal",
		description = "Accessoire Autel du miroir dorsal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/autel_miroir_dorsal/autel_miroir_dorsal.mdl",
	},
	["mantelet_ginkgo"] = {
		name = "Coffret d’encens du sanctuaire",
		description = "Accessoire Coffret d’encens du sanctuaire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/mantelet_ginkgo/mantelet_ginkgo.mdl",
	},
	["flutes_bambou_dorsales"] = {
		name = "Flûtes de bambou dorsales",
		description = "Accessoire Flûtes de bambou dorsales.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/flutes_bambou_dorsales/flutes_bambou_dorsales.mdl",
	},
	["necessaire_calligraphe"] = {
		name = "Nécessaire du calligraphe",
		description = "Accessoire Nécessaire du calligraphe.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "epic",
		model_path = "models/evo/accessories/body/necessaire_calligraphe/necessaire_calligraphe.mdl",
	},
	["biwa_ambre_dorsal"] = {
		name = "Biwa d’ambre dorsal",
		description = "Accessoire Biwa d’ambre dorsal.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "corps",
		slot = "cape",
		rarity = "legendary",
		model_path = "models/evo/accessories/body/biwa_ambre_dorsal/biwa_ambre_dorsal.mdl",
	},

	-- ─── LOT COFFRES 09/08 (ter) : 10 coiffes (chapeaux) ───
	["kasa_jonc_ouvrier"] = {
		name = "Kasa de jonc de l’ouvrier",
		description = "Accessoire Kasa de jonc de l’ouvrier.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/kasa_jonc_ouvrier/kasa_jonc_ouvrier.mdl",
	},
	["tenugui_noue_indigo"] = {
		name = "Tenugui noué indigo",
		description = "Accessoire Tenugui noué indigo.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/tenugui_noue_indigo/tenugui_noue_indigo.mdl",
	},
	["coiffe_tatami_voyage"] = {
		name = "Coiffe de tatami de voyage",
		description = "Accessoire Coiffe de tatami de voyage.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "common",
		model_path = "models/evo/accessories/head/coiffe_tatami_voyage/coiffe_tatami_voyage.mdl",
	},
	["kasa_renforts_jonc"] = {
		name = "Kasa aux renforts de jonc",
		description = "Accessoire Kasa aux renforts de jonc.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/kasa_renforts_jonc/kasa_renforts_jonc.mdl",
	},
	["jingasa_carpe_ivoire"] = {
		name = "Jingasa de la carpe d’ivoire",
		description = "Accessoire Jingasa de la carpe d’ivoire.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/jingasa_carpe_ivoire/jingasa_carpe_ivoire.mdl",
	},
	["kasa_pluie_azur"] = {
		name = "Kasa de pluie azur",
		description = "Accessoire Kasa de pluie azur.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/kasa_pluie_azur/kasa_pluie_azur.mdl",
	},
	["coiffe_grue_celeste"] = {
		name = "Coiffe de la grue céleste",
		description = "Accessoire Coiffe de la grue céleste.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/coiffe_grue_celeste/coiffe_grue_celeste.mdl",
	},
	["kasa_aube_cuivree"] = {
		name = "Kasa de l’aube cuivrée",
		description = "Accessoire Kasa de l’aube cuivrée.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/kasa_aube_cuivree/kasa_aube_cuivree.mdl",
	},
	["kasa_erable_automne"] = {
		name = "Kasa de l’érable d’automne",
		description = "Accessoire Kasa de l’érable d’automne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "legendary",
		model_path = "models/evo/accessories/head/kasa_erable_automne/kasa_erable_automne.mdl",
	},
	["kasa_constellations"] = {
		name = "Kasa des constellations",
		description = "Accessoire Kasa des constellations.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		coffre_cat = "chapeaux",
		slot = "head",
		rarity = "mythic",
		model_path = "models/evo/accessories/head/kasa_constellations/kasa_constellations.mdl",
	},

	-- ─── ACCESSOIRES BOUTIQUE (demande user 08\13) ───────────────────────────
	-- Vendus normalement (prix reel, pas coffre_only) : ils entreront donc aussi
	-- dans le pool du Coffre d Accessoires le jour ou il sortira.
	["arr_mask_ichigo_modifie"] = {
		name = "Masque d Ichigo Modifie",
		description = "Masque d Ichigo Modifie.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/arr_mask/evo_zeerfuap1425q52gt524rg/evo_zeerfuap1425q52GT524rg.mdl",
	},
	["arr_mask_machoire_complete"] = {
		name = "Masque de Machoire Complete",
		description = "Masque de Machoire Complete.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/arr_mask/evo_zeduap1rgtq52gthrg/evo_zeduap1rgtq52GThrg.mdl",
	},
	["cache_cou_noir"] = {
		name = "Cache-cou Noir",
		description = "Cache-cou Noir.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_zf52erhtgngrtref/evo_zf52erhtgnGRTref.mdl",
	},
	["chapeau_style_corne"] = {
		name = "Chapeau Style Corne",
		description = "Chapeau Style Corne.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = "models/evo/accessories/head/evo_ezedn69q73egzed52/evo_eZEDn69Q73egZED52.mdl",
	},

	-- ── PETS D'ÉPAULE (user 08/26) : 23 modèles, champignon en 4 couleurs (skins 0-3).
	-- Ticket à gratter : axolotl + chat cartoon (SCRATCH_CONFIG.accessories) ;
	-- parrainage (paliers 10/20/30/40) : lama + poupées Ikkaku / Nnoitra / Yamamoto (skin 0) ;
	-- variantes skin 1 de ces 4 = item exclusif, do not reuse (pas au coffre) ;
	-- le reste = exclusivités du Coffre d'Accessoires (lzy_shop shop_config, coffre_only).
	["pet_anole_vert"]           = PetItem("Anole vert", "anole_vert", "common"),
	["pet_axolotl"]              = PetItem("Axolotl", "axolotl", "epic"),
	["fourreau_cos_0"] = FourreauItem(0, "Honoki du dojo", "common"),
	["fourreau_cos_1"] = FourreauItem(1, "Laque noire du ronin", "common"),
	["fourreau_cos_2"] = FourreauItem(2, "Indigo des courants", "rare"),
	["fourreau_cos_3"] = FourreauItem(3, "Bambou de cuivre", "rare"),
	["fourreau_cos_4"] = FourreauItem(4, "Prunier de cinabre", "epic"),
	["fourreau_cos_5"] = FourreauItem(5, "Écume d'ivoire", "epic"),
	["fourreau_cos_6"] = FourreauItem(6, "Chrysanthème impérial", "legendary"),
	["fourreau_cos_7"] = FourreauItem(7, "Nuages du shogun", "legendary"),
	["fourreau_cos_8"] = FourreauItem(8, "Ryujin des abysses", "mythic"),
	["fourreau_cos_9"] = FourreauItem(9, "Phénix du palais blanc", "mythic"),
	["fourreau_cos_10"] = FourreauItem(10, "Cuir cousu", "common"),
	["fourreau_cos_11"] = FourreauItem(11, "Bambou des marais", "common"),
	["fourreau_cos_12"] = FourreauItem(12, "Obsidienne fendue", "rare"),
	["fourreau_cos_13"] = FourreauItem(13, "Armure écarlate", "rare"),
	["fourreau_cos_14"] = FourreauItem(14, "Rose de sang", "epic"),
	["fourreau_cos_15"] = FourreauItem(15, "Carcasse abyssale", "epic"),
	["fourreau_cos_16"] = FourreauItem(16, "Orage fracturé", "legendary"),
	["fourreau_cos_17"] = FourreauItem(17, "Reliquaire de jade", "legendary"),
	["fourreau_cos_18"] = FourreauItem(18, "Ryujin enroulé", "mythic"),
	["fourreau_cos_19"] = FourreauItem(19, "Croissant de l'éclipse", "mythic"),
	["pet_baleine_cartoon"]      = PetItem("Baleine cartoon", "baleine_cartoon", "legendary"),
	["pet_champignon_bleu"]      = PetItem("Champignon bleu", "champignon", "common", 0),
	["pet_champignon_rose"]      = PetItem("Champignon rose", "champignon", "common", 1),
	["pet_champignon_rouge"]     = PetItem("Champignon rouge", "champignon", "common", 2),
	["pet_champignon_vert"]      = PetItem("Champignon vert", "champignon", "common", 3),
	["pet_chat_cartoon"]         = PetItem("Chat cartoon", "chat_cartoon", "rare"),
	["pet_chien_cartoon"]        = PetItem("Chien cartoon", "chien_cartoon", "rare"),
	["pet_corbeau"]              = PetItem("Corbeau", "corbeau", "rare"),
	["pet_demon_garcon"]         = PetItem("Petit démon", "demon_garcon", "legendary"),
	["pet_fantome"]              = PetItem("Fantôme", "fantome", "epic"),
	["pet_grenouille"]           = PetItem("Grenouille", "grenouille_lowpoly", "common"),
	["pet_koi"]                  = PetItem("Koï", "koi_anime", "epic"),
	["pet_lama_peluche"]         = PetItem("Lama en peluche", "lama_peluche", "rare", 0),
	["pet_lama_peluche_alt"]     = PetItem("Lama en peluche (variante)", "lama_peluche", "rare", 1), -- item exclusif, do not reuse
	["pet_doll_ikkaku"]          = PetItem("Poupée Ikkaku", "doll_ikkaku", "epic", 0),
	["pet_doll_ikkaku_alt"]      = PetItem("Poupée Ikkaku (variante)", "doll_ikkaku", "epic", 1), -- item exclusif, do not reuse
	["pet_doll_nnoitra"]         = PetItem("Poupée Nnoitra", "doll_nnoitra", "legendary", 0),
	["pet_doll_nnoitra_alt"]     = PetItem("Poupée Nnoitra (variante)", "doll_nnoitra", "legendary", 1), -- item exclusif, do not reuse
	["pet_doll_yamamoto"]        = PetItem("Poupée Yamamoto", "doll_yamamoto", "mythic", 0),
	["pet_doll_yamamoto_alt"]    = PetItem("Poupée Yamamoto (variante)", "doll_yamamoto", "mythic", 1), -- item exclusif, do not reuse
	["pet_lezard_cartoon"]       = PetItem("Lézard cartoon", "lezard_cartoon", "common"),
	["pet_oeil_tentacules"]      = PetItem("Oeil à tentacules", "oeil_tentacules", "legendary"),
	["pet_papillon"]             = PetItem("Papillon", "papillon", "epic"),
	["pet_papillon_arc_en_ciel"] = PetItem("Papillon arc-en-ciel", "papillon_arc_en_ciel", "legendary"),
	["pet_pingouin_peluche"]     = PetItem("Pingouin en peluche", "pingouin_peluche", "rare"),
	["pet_poisson"]              = PetItem("Poisson", "poisson_anime", "rare"),
	["pet_poulet"]               = PetItem("Poulet", "poulet_anime", "rare"),
	["pet_serpent"]              = PetItem("Serpent", "serpent", "epic"),
	-- Compagnons 09/08 (bis) : 4, idle seul (boucle par le Think des pets).
	["pet_tanuki_bois"]          = PetItem("Tanuki des bois", "tanuki_bois", "rare"),
	["pet_tortue_jardin"]        = PetItem("Tortue-jardin", "tortue_jardin", "epic"),
	["pet_hibou_veilleuse"]      = PetItem("Hibou à veilleuse", "hibou_veilleuse", "legendary"),
	["pet_dragon_perle"]         = PetItem("Dragon à perle", "dragon_perle", "mythic"),
	-- Compagnons 09/08 (ter) : 10, idle seul (boucle par le Think des pets).
	["pet_souris_des_greniers"]  = PetItem("Souris des greniers", "souris_des_greniers", "common"),
	["pet_grue_des_roseaux"]     = PetItem("Grue des roseaux", "grue_des_roseaux", "rare"),
	["pet_lapin_de_neige"]       = PetItem("Lapin de neige", "lapin_de_neige", "rare"),
	["pet_axolotl_de_jade"]      = PetItem("Axolotl de jade", "axolotl_de_jade", "epic"),
	["pet_furet_voyageur"]       = PetItem("Furet voyageur", "furet_voyageur", "epic"),
	["pet_baku_des_songes"]      = PetItem("Baku des songes", "baku_des_songes", "legendary"),
	["pet_panda_roux_erable"]    = PetItem("Panda roux de l’érable", "panda_roux_erable", "legendary"),
	["pet_kirin_clochettes"]     = PetItem("Kirin aux clochettes", "kirin_clochettes", "mythic"),
	["pet_kitsune_trois_queues"] = PetItem("Kitsune aux trois queues", "kitsune_trois_queues", "mythic"),
	["pet_phoenix_de_braise"]    = PetItem("Phénix de braise", "phoenix_de_braise", "mythic"),
	["pet_kon"]                  = PetItem("Kon", "kon", "epic"),
	-- Pets V2 animés des 4 tickets à gratter thématiques (user 10/01) : jamais au coffre (palier_only).
	["pet_loutre_lotus"]         = PetItem("Loutre du Lotus", "tickets/loutre_lotus", "legendary"),
	["pet_scarabee_jade"]        = PetItem("Scarabée de Jade", "tickets/scarabee_jade", "legendary"),
	["pet_griffon_solaire"]      = PetItem("Griffon solaire", "tickets/griffon_solaire", "legendary"),
	["pet_salamandre_braise"]    = PetItem("Salamandre de Braise", "tickets/salamandre_braise", "legendary"),
	["pet_lapin_lunaire"]        = PetItem("Lapin lunaire", "tickets/lapin_lunaire", "legendary"),
	["pet_raie_celeste"]         = PetItem("Raie céleste", "tickets/raie_celeste", "legendary"),
	["pet_chauve_souris_oni"]    = PetItem("Chauve-souris Oni", "tickets/chauve_souris_oni", "legendary"),
	["pet_crabe_oni"]            = PetItem("Crabe gardien Oni", "tickets/crabe_oni", "legendary"),
}

-- Auto-generate katana items from KATANA_SKINS (deferred to ensure KATANA_SKINS is loaded)
local function GenerateKatanaItems()
	if not KATANA_SKINS or not KATANA_SKINS.List then return end
	local katanaRarities = {
		["default"] = "common",
		["ichigo1"] = "rare",
		["ichigo2"] = "epic",
		["ichigo3"] = "legendary",
		["yamamoto"] = "mythic",
		["aizen"] = "mythic",
		["kenpachi"] = "legendary",
		["byakuya"] = "legendary",
		["toshiro"] = "epic",
		["urahara"] = "epic",
		["grimmjow"] = "legendary",
		["ulquiorra"] = "mythic",
		["baraggan"] = "legendary",
		["harribel"] = "epic",
		["coyote_stark"] = "legendary",
	}
	for skinID, skinData in pairs(KATANA_SKINS.List) do
		local itemKey = "katana_" .. skinID
		-- Lames de SHIKAI : l'objet existe UNIQUEMENT pour que les superadmins
		-- puissent s'en sortir une (getitem/giveitem, user 08/30). Ce n'est PAS
		-- ainsi qu'un joueur l'obtient : l'apparence de shikai reste ATTRIBUEE au
		-- personnage (NW ShikaiSkin, rituel de la Salle Blanche ou reroll au PNJ).
		-- Aucune ligne boutique, aucun coffre, aucun loot ne les reference, et le
		-- generateur les pose non droppables + non supprimables (defaut false).
		if not ITEMS[itemKey] then
			-- KATANA_SKINS = source UNIQUE. Options par skin (cf. sh_katana_skin_loader) :
			--   named  = true   -> nom exact (sinon préfixé "Katana ")
			--   rarity = "epic" -> surcharge la rareté
			--   desc   = "..."  -> surcharge la description
			-- Faction d'ÉQUIPEMENT = celle du SKIN (source unique = KATANA_SKINS), PAS dérivée
			-- du model_path : sinon un katana vendu "all" mais au modèle typé (ex. ichigo4 =
			-- modèle shinigami) était ACHETABLE par un Hollow mais PAS équipable. On aligne donc
			-- achat ET équip. Tolère le trailing-space des configs ("shinigami "). "arrancar"=Hollow.
			local sFac = string.Trim(string.lower(tostring(skinData.faction or "all")))
			local itemFaction = "all"
			if sFac == "shinigami" then itemFaction = "Shinigami"
			elseif sFac == "hollow" or sFac == "arrancar" then itemFaction = "Hollow" end
			ITEMS[itemKey] = {
				name = skinData.named and skinData.name or ("Katana " .. skinData.name),
				description = skinData.desc
					or (skinData.is_shikai and "Apparence de lame de Shikai. Elle est normalement attribuée au personnage, jamais vendue ni trouvée : cette copie est un outil de staff."
					or (skinData.named and skinData.name or ("Le katana de " .. skinData.name))),
				icon = "zw7x2d061ill/6assh2s06ssp2u7n/ins47h5c6uuvy3at4.png",
				category = "object",
				skin_id = skinID,
				model_path = skinData.model,
				faction = itemFaction, -- aligne le gate d'équip sur la faction de vente du skin
				rarity = skinData.rarity or katanaRarities[skinData.base or skinID] or "rare",
				skin = skinData.nSkin, -- variante shikai : famille 1 dans les aperçus (nil = rareté auto)
				is_droppable = skinData.is_droppable or false,
				is_deletable = skinData.is_deletable or false,
				has_durability = true,
			}
		end
	end
end

-- Also defer to next frame to handle addon load order
timer.Simple(1, GenerateKatanaItems)

-- Auto-generate HAKUDA GAUNTLET items from NCM_HAKUDA_GAUNTLETS (parallèle aux skins de katana).
-- Discriminateur = gauntlet_id (comme skin_id pour le katana). Équipé via le MÊME slot d'arme que
-- le katana (EquipKatana, slot 2000) : le gantelet REMPLACE le katana. Équip -> NWString
-- NCM_HakudaGauntlet, rendu bonemergé côté client (cl_hakuda_gauntlet.lua).
local function GenerateGauntletItems()
	if not (NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List) then return end
	for gauntletID, gData in pairs(NCM_HAKUDA_GAUNTLETS.List) do
		-- On génère AUSSI "base"/"bois" (armes d'entraînement Hakuda données par le Maître d'Armes) :
		-- ce sont de VRAIS items, juste PAS en boutique (COSMETIQUES_CONFIG ne les liste pas).
		local itemKey = "gauntlet_" .. gauntletID
		-- Poings de SHIKAI : meme regime que les lames (cf. GenerateKatanaItems) —
		-- objet reserve au staff, l'apparence reste attribuee au personnage.
		if not ITEMS[itemKey] then
			ITEMS[itemKey] = {
				name = gData.name or ("Gantelet " .. gauntletID),
				description = gData.desc
					or (gData.is_shikai and "Apparence de poings de Shikai. Elle est normalement attribuée au personnage, jamais vendue ni trouvée : cette copie est un outil de staff."
					or "Arme de mains nues (Hakuda). Remplace le katana quand tu combats en Hakuda."),
				icon = gData.icon or "zw7x2d061ill/6assh2s06ssp2u7n/ins47h5c6uuvy3at4.png",
				category = "object",
				gauntlet_id = gauntletID,   -- discriminateur PARALLÈLE à skin_id
				model_path = gData.model,
				faction = "all",
				rarity = gData.rarity or "rare",
				is_droppable = false,
				-- S'use et se répare comme un katana : même slot d'arme, même traitement.
				-- Active à la fois l'usure au coup porté et la réparation à la forge.
				has_durability = true,
			}
		end
	end
end

timer.Simple(1, GenerateGauntletItems)

if EVO_BUSINESS and EVO_BUSINESS.RegisterBeerItems then EVO_BUSINESS.RegisterBeerItems() end
