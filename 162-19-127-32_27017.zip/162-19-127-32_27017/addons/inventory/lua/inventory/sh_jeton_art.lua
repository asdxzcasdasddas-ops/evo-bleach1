-- "addons\\inventory\\lua\\inventory\\sh_jeton_art.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Jeton d'Art Spirituel. Posé au changement de faction d'un CK, à la rareté
-- de l'art quitté. L'usage tire un art de CETTE rareté dans la faction actuelle.
-- Non échangeable : le jeton reste sur le personnage qui a changé de faction.

ITEMS = ITEMS or {}

local RARITY_FR = {
	commun    = "Commun",
	rare      = "Rare",
	epique    = "Épique",
	legendary = "Légendaire",
	mythique  = "Mythique",
}

local RARITY_ITEM = {
	commun    = "common",
	rare      = "rare",
	epique    = "epic",
	legendary = "legendary",
	mythique  = "mythic",
}

local RARITY_SKIN = {
	commun = 0, rare = 1, epique = 2, legendary = 3, mythique = 4,
}

local function TokenItemId(rarity)
	return "jeton_art_" .. tostring(rarity or "")
end

local function FindArtDrop(faction, winId)
	winId = tostring(winId or "")
	if winId == "" then return nil end
	local pool = REROLL_DROPS and REROLL_DROPS[faction] and REROLL_DROPS[faction].art_spirituel
	if not istable(pool) then return nil end
	local want = string.lower(winId)
	for i = 1, #pool do
		local drop = pool[i]
		if drop and string.lower(tostring(drop.win_id or "")) == want then
			return drop
		end
	end
	return nil
end

local function RollArt(faction, rarity, exclude)
	local pool = REROLL_DROPS and REROLL_DROPS[faction] and REROLL_DROPS[faction].art_spirituel
	if not istable(pool) then return nil end
	local picks = {}
	for i = 1, #pool do
		local drop = pool[i]
		-- superadmin_only = art EN TEST (reroll) : jamais tiré par un jeton (09/30).
		if drop and drop.rarity == rarity and drop.win_id and drop.win_id ~= "" and not drop.superadmin_only then
			picks[#picks + 1] = drop.win_id
		end
	end
	if #picks > 1 and exclude and exclude ~= "" then
		local filtered = {}
		for i = 1, #picks do
			if picks[i] ~= exclude then filtered[#filtered + 1] = picks[i] end
		end
		if #filtered > 0 then picks = filtered end
	end
	if #picks == 0 then return nil end
	return picks[math.random(#picks)]
end

if SERVER then
	util.AddNetworkString("EVO:ArtToken:Answer")
	util.AddNetworkString("EVO:ArtToken:Granted")

	EVO_ArtToken = EVO_ArtToken or {}
	local PENDING = {}

	local function Notify(ply, msg, kind)
		if MUGEN and MUGEN.Notify then
			MUGEN.Notify(ply, msg, kind or NOTIFY_GENERIC, 5)
		end
	end

	local function SendGranted(ply, fac, winId, rarity)
		if not IsValid(ply) then return end
		local drop = FindArtDrop(fac, winId)
		local nom = (EVO_ArtPowerName and EVO_ArtPowerName(winId, drop and drop.name)) or winId
		net.Start("EVO:ArtToken:Granted")
			net.WriteString(tostring(winId or ""))
			net.WriteString(tostring(rarity or ""))
			net.WriteString(tostring((drop and drop.icon) or ""))
			net.WriteString(tostring(nom or ""))
		net.Send(ply)
	end

	local function ConsumeAndGrant(ply, rarity, replace)
		if not IsValid(ply) then return end
		local fac = ply:GetEvoNWString("FactionName", "")
		if fac ~= "Shinigami" and fac ~= "Hollow" then
			Notify(ply, "Ce jeton ne sert qu'à un Shinigami ou un Hollow.", NOTIFY_ERROR)
			return
		end
		local curArt = ply:GetEvoNWString("ArtSpirituel", "")
		if curArt ~= "" and not replace then
			Notify(ply, "Tu as déjà un art spirituel.", NOTIFY_ERROR)
			return
		end
		local winId = RollArt(fac, rarity, curArt)
		if not winId then
			Notify(ply, "Aucun art de cette rareté dans ta faction.", NOTIFY_ERROR)
			return
		end
		local itemId = TokenItemId(rarity)
		if not ply.RemoveItem or not ply.GiveArtSpirituel then return end
		ply._artTokenBusy = true
		ply:RemoveItem(itemId, function(ok)
			if not IsValid(ply) then return end
			if not ok then
				ply._artTokenBusy = nil
				Notify(ply, "Jeton introuvable.", NOTIFY_ERROR)
				return
			end
			ply:GiveArtSpirituel(winId, function(given)
				if not IsValid(ply) then return end
				ply._artTokenBusy = nil
				if not given then
					ply:GiveItem(itemId, function() end)
					Notify(ply, "L'art n'a pas pu être attribué. Le jeton est rendu.", NOTIFY_ERROR)
					return
				end
				-- 1er sort gratuit : GiveArtSpirituel (GrantSkillFree).
				SendGranted(ply, fac, winId, rarity)
			end)
		end)
	end

	function EVO_ArtToken.Use(ply, rarity)
		if not IsValid(ply) or ply._artTokenBusy then return end
		if not RARITY_FR[rarity] then return end
		local fac = ply:GetEvoNWString("FactionName", "")
		if fac ~= "Shinigami" and fac ~= "Hollow" then
			Notify(ply, "Ce jeton ne sert qu'à un Shinigami ou un Hollow.", NOTIFY_ERROR)
			return
		end
		if ply:GetEvoNWBool("EVO_IsLarva", false) then
			Notify(ply, "Tu pourras utiliser ce jeton une fois Arrancar.", NOTIFY_ERROR)
			return
		end
		local curArt = ply:GetEvoNWString("ArtSpirituel", "")
		if curArt == "" then
			ConsumeAndGrant(ply, rarity, false)
			return
		end
		local sid = ply:SteamID64()
		PENDING[sid] = { rarity = rarity, untilAt = CurTime() + 30 }
		local nom = (EVO_ArtPowerName and EVO_ArtPowerName(curArt)) or curArt
		local rarityFr = RARITY_FR[rarity] or rarity
		local msg = "Tu as déjà l'art spirituel « " .. nom .. " ».\nLe remplacer par un art " .. rarityFr .. " tiré au hasard de ta faction ?"
		if ply.OpenYesNoPopup then
			ply:OpenYesNoPopup(msg, "ArtToken_Replace", {}, "ArtToken_Cancel")
		else
			Notify(ply, "Confirmation indisponible. Réessaie.", NOTIFY_ERROR)
			PENDING[sid] = nil
		end
	end

	net.Receive("EVO:ArtToken:Answer", function(_, ply)
		if not IsValid(ply) then return end
		if not ply:RateLimit("art_token_answer", 0.4) then return end
		local yes = net.ReadBool()
		local pend = PENDING[ply:SteamID64()]
		PENDING[ply:SteamID64()] = nil
		if not pend or CurTime() > (pend.untilAt or 0) then
			if yes then Notify(ply, "La confirmation a expiré. Réutilise le jeton.", NOTIFY_ERROR) end
			return
		end
		if not yes then return end
		ConsumeAndGrant(ply, pend.rarity, true)
	end)
end

if CLIENT then
	local RARITY_COL = {
		commun    = Color(210, 210, 220),
		rare      = Color(80, 160, 255),
		epique    = Color(190, 90, 255),
		legendary = Color(255, 215, 0),
		mythique  = Color(255, 60, 60),
	}

	local COL_BG    = Color(13, 14, 17, 250)
	local COL_EDGE  = Color(146, 152, 161, 40)
	local COL_WHITE = Color(238, 238, 240)
	local COL_MUTED = Color(150, 154, 162)
	local GLOW_MAT  = Material("sprites/light_glow02_add")
	local SND_OK    = "4wsd81r0bjysb8vy/417iarkuz4el6024d.ogg"

	local function S() return math.max(0.6, ScrH() / 1080) end
	local function EaseOutBack(x)
		x = math.Clamp(x, 0, 1)
		local c1, c3 = 1.70158, 1.70158 + 1
		return 1 + c3 * (x - 1) ^ 3 + c1 * (x - 1) ^ 2
	end
	local function EaseOutCubic(x)
		x = math.Clamp(x, 0, 1)
		return 1 - (1 - x) ^ 3
	end

	local function MakeFonts()
		local s = S()
		surface.CreateFont("EvoArtToken_Title", { font = "Bebas Neue", size = math.floor(22 * s), weight = 400, antialias = true, extended = true })
		surface.CreateFont("EvoArtToken_Name",  { font = "Bebas Neue", size = math.floor(42 * s), weight = 400, antialias = true, extended = true })
		surface.CreateFont("EvoArtToken_Sub",   { font = "Roboto",     size = math.floor(15 * s), weight = 500, antialias = true, extended = true })
		surface.CreateFont("EvoArtToken_Tag",   { font = "Roboto",     size = math.floor(13 * s), weight = 600, antialias = true, extended = true })
	end
	MakeFonts()
	hook.Add("OnScreenSizeChanged", "EvoArtToken:Fonts", MakeFonts)

	local ArtTokenPanel
	local LIFE, FADE_IN, FADE_OUT = 5.2, 0.45, 0.55

	-- Même révélation pour les arts et les finishers obtenus par jeton.
	local function ShowTokenGranted(winId, rarity, iconPath, name, title)
		name = (name and name ~= "") and name or tostring(winId or "Art spirituel")
		rarity = tostring(rarity or "")
		local rarityFr = RARITY_FR[rarity] or rarity
		local accent = RARITY_COL[rarity] or COL_WHITE
		local mat = (isstring(iconPath) and iconPath ~= "") and Material(iconPath, "smooth") or nil
		if mat and mat:IsError() then mat = nil end

		if IsValid(ArtTokenPanel) then ArtTokenPanel:Remove() ArtTokenPanel = nil end

		local s = S()
		local W, H = math.floor(400 * s), math.floor(300 * s)
		local p = vgui.Create("DPanel")
		ArtTokenPanel = p
		p.title = title or "NOUVEL ART SPIRITUEL"
		p.name = name
		-- Les noms de finishers peuvent être longs : garder le nom entier dans la carte.
		surface.SetFont("EvoArtToken_Name")
		local nameWidth = surface.GetTextSize(name)
		local nameSize = math.floor(42 * s * math.min(1, (W - 40 * s) / math.max(1, nameWidth)))
		surface.CreateFont("EvoArtToken_RewardName", { font = "Bebas Neue", size = math.max(math.floor(16 * s), nameSize), weight = 400, antialias = true, extended = true })
		p.rarityFr = rarityFr
		p.accent = accent
		p.mat = mat
		p.t0 = SysTime()
		p.alpha = 0
		p.pop = 0
		p:SetSize(W, H)
		p:SetPos(math.floor((ScrW() - W) / 2), math.floor((ScrH() - H) / 2))
		p:SetMouseInputEnabled(true)
		p:SetKeyboardInputEnabled(false)
		p:SetPaintBackground(false)
		p:SetDrawOnTop(true)
		p:MakePopup()
		p:SetKeyboardInputEnabled(false)
		surface.PlaySound(SND_OK)

		p.OnMousePressed = function(self)
			self.t0 = SysTime() - (LIFE - FADE_OUT)
		end

		p.Think = function(self)
			local t = SysTime() - self.t0
			local intro = EaseOutCubic(t / FADE_IN)
			local outro = 1 - math.Clamp((t - (LIFE - FADE_OUT)) / FADE_OUT, 0, 1)
			self.alpha = 255 * math.min(intro, outro)
			self.pop = EaseOutBack(math.min(1, t / (FADE_IN * 1.2)))

			local sc = S()
			local rise = (1 - intro) * 24 * sc
			self:SetPos(math.floor((ScrW() - self:GetWide()) / 2),
				math.floor((ScrH() - self:GetTall()) / 2 + rise))

			if t >= LIFE then self:Remove() ArtTokenPanel = nil end
		end

		p.Paint = function(self, w, h)
			local a = (self.alpha or 0) / 255
			if a < 0.02 then return end
			local s2 = S()
			local pop = self.pop or 1
			local pad = (1 - pop) * 18 * s2
			local x, y, pw, ph = pad, pad, w - pad * 2, h - pad * 2
			if pw < 8 or ph < 8 then return end

			if EVO_UI and EVO_UI.PaintCut then
				local pts = EVO_UI.PaintCut(x, y, pw, ph, ColorAlpha(COL_BG, 252 * a), 14 * s2)
				EVO_UI.OutlineCut(pts, ColorAlpha(COL_EDGE, 45 * a))
				local ac = self.accent or COL_WHITE
				EVO_UI.OutlineCut(pts, Color(ac.r, ac.g, ac.b, 50 * a))
			else
				draw.RoundedBox(8, x, y, pw, ph, ColorAlpha(COL_BG, 252 * a))
			end

			local ac = self.accent or COL_WHITE
			draw.SimpleText(self.title, "EvoArtToken_Title", w * 0.5, y + ph * 0.10,
				ColorAlpha(COL_MUTED, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			local iconSz = math.floor(math.min(pw, ph) * 0.40)
			local cx, cy = w * 0.5, y + ph * 0.42
			local pulse = 0.5 + 0.5 * math.sin(SysTime() * 3.2)
			surface.SetMaterial(GLOW_MAT)
			surface.SetDrawColor(ac.r, ac.g, ac.b, (30 + 20 * pulse) * a)
			local g = iconSz * (1.6 + 0.1 * pulse)
			surface.DrawTexturedRect(cx - g * 0.5, cy - g * 0.5, g, g)

			if self.mat then
				surface.SetMaterial(self.mat)
				surface.SetDrawColor(255, 255, 255, 255 * a)
				surface.DrawTexturedRect(cx - iconSz * 0.5, cy - iconSz * 0.5, iconSz, iconSz)
			else
				draw.SimpleText("?", "EvoArtToken_Name", cx, cy, ColorAlpha(ac, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end

			local nameY = cy + iconSz * 0.5 + 22 * s2
			draw.SimpleText(self.name or "", "EvoArtToken_RewardName", w * 0.5, nameY,
				ColorAlpha(COL_WHITE, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if self.rarityFr and self.rarityFr ~= "" then
				draw.SimpleText(string.upper(self.rarityFr), "EvoArtToken_Tag", w * 0.5, nameY + 28 * s2,
					ColorAlpha(ac, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			draw.SimpleText("Clique pour fermer", "EvoArtToken_Sub", w * 0.5, y + ph * 0.92,
				ColorAlpha(COL_MUTED, 200 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	EVO_TokenReward = EVO_TokenReward or {}
	EVO_TokenReward.ShowGranted = ShowTokenGranted

	net.Receive("EVO:ArtToken:Granted", function()
		local winId = net.ReadString()
		local rarity = net.ReadString()
		local icon = net.ReadString()
		local name = net.ReadString()
		ShowTokenGranted(winId, rarity, icon, name)
	end)
end

for rarity, label in pairs(RARITY_FR) do
	local r = rarity
	ITEMS[TokenItemId(r)] = {
		name        = "Jeton d'Art Spirituel (" .. label .. ")",
		description = "Issu d'un changement de faction. À utiliser pour recevoir un art spirituel " .. label .. " de ta faction actuelle, tiré au hasard parmi cette rareté. Reste sur ce personnage.",
		icon        = "1bhn2d03mwm1/parchemin.png",
		icon_scale  = 0.6,
		model_path  = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl",
		skin        = RARITY_SKIN[r] or 0,
		category    = "object",
		rarity      = RARITY_ITEM[r] or "common",
		is_droppable = false,
		is_deletable = false,
		is_art_token = true,
		on_use = function(ply)
			if not SERVER then return end
			if EVO_ArtToken and EVO_ArtToken.Use then
				EVO_ArtToken.Use(ply, r)
			end
		end,
	}
end
