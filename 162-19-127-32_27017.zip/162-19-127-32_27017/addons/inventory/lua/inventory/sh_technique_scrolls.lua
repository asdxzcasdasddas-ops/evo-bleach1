-- "addons\\inventory\\lua\\inventory\\sh_technique_scrolls.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- =====================================================================
-- Parchemins de TECHNIQUE
-- Un objet d'inventaire par sort Hado / Bakudo / Ars Hollow.
-- Utiliser le parchemin n'ENSEIGNE PAS le sort : il DÉBLOQUE son ACHAT dans
-- l'arbre de compétences (le joueur l'achète ensuite avec des points). Le
-- déblocage ET le sort une fois appris survivent au reset-stat / reroll d'art
-- (flag parch_<spell> + entrée spell).
-- Prérequis pour utiliser le parchemin : niveau + grade + 1 technique/perso
-- (gérés par NCM_PARCHEMIN_VENDOR.CanUseTechnique).
--
-- NB : distribution via le PNJ ncm_parchemin_vendor (et admin "getitem <id>",
-- ex: getitem parchemin_hado_1). Items non échangeables/jetables/supprimables
-- (sauf superadmin).
-- =====================================================================

ITEMS = ITEMS or {}

-- Icône PNG commune à TOUS les parchemins de technique (repli hors preview 3D).
local GENERIC_PARCHEMIN_ICON = "1bhn2d03mwm1/parchemin.png"

-- Modèle 3D commun affiché DANS la case d'inventaire (au lieu de l'icône PNG) via
-- LZY_INVENTORY_ITEM_PREVIEW (cl_item_preview_model.lua). La VARIANTE visuelle (bodygroup
-- groupe 0) suit le palier du sort : 1er sort = 0, 2e = 1, … 5e = 4, et au-delà (6e/7e) on
-- reste à 4 (clamp). Bodygroup en forme TABLE { [0] = n } -> on ne touche QUE le bodygroup
-- (pas le skin), conforme à "il y a un bodygroup".
local PARCHEMIN_SPELL_MODEL = "models/evo/props/items/evo_vb5fg6eggheg5ehhez/evo_vb5fg6eggheg5ehhez.mdl"

-- Rareté du parchemin = palier du bodygroup (= palier du sort) : 0 commun, 1 rare, 2 épique,
-- 3 légendaire, 4 mythique. (Chaînes de rareté de l'inventaire, cf. config.lua RARITY_COLORS.)
local RARITY_BY_BODYGROUP = { [0] = "common", [1] = "rare", [2] = "epic", [3] = "legendary", [4] = "mythic" }

-- Sorts par catégorie. La catégorie/faction est déjà gérée par le skilltree
-- (Shinigami -> Hado/Bakudo, Hollow -> Ars_Hollow) via GrantSkillFree.
local TECHNIQUE_SPELLS = {
	"Spell_hado_1", "Spell_hado_2", "Spell_hado_3", "Spell_hado_4", "Spell_hado_5", "Spell_hado_6",
	"Spell_bakudo_1", "Spell_bakudo_2", "Spell_bakudo_3", "Spell_bakudo_4", "Spell_bakudo_5", "Spell_bakudo_6", "Spell_bakudo_7",
	"Spell_ars_hollow_1", "Spell_ars_hollow_2", "Spell_ars_hollow_3", "Spell_ars_hollow_4", "Spell_ars_hollow_5", "Spell_ars_hollow_6", "Spell_ars_hollow_7",
	-- Sorts de VOIE (user 08/20 « comme bakudo/hado ») : même pipeline complet
	-- parchemin -> achat aux points -> apprentissage. Prérequis de NIVEAU dans
	-- NCM_PARCHEMIN_VENDOR.WayRequirements.
	"Spell_katana_1", "Spell_katana_2", "Spell_katana_3", "Spell_katana_4", "Spell_katana_5",
	"Spell_hakuda_1", "Spell_hakuda_2", "Spell_hakuda_3", "Spell_hakuda_4", "Spell_hakuda_5",
}

-- "Spell_hado_1" -> "parchemin_hado_1"
local function spellToItemID(spellID)
	return (string.gsub(spellID, "^Spell_", "parchemin_"))
end

local function buildOne(spellID)
	local itemID = spellToItemID(spellID)
	local cfg = EvoStyle and EvoStyle.SpellsConfig and EvoStyle.SpellsConfig[spellID]

	local sName = (cfg and cfg.sName) or spellID
	local sDesc = (cfg and cfg.sDesc) or ""

	-- Index du sort (Spell_hado_1 -> 1, Spell_bakudo_7 -> 7) -> bodygroup du modèle 3D :
	-- 1er = 0, 2e = 1, … 5e = 4, au-delà on reste à 4 (clamp 0..4).
	local nSpellIdx   = tonumber(string.match(spellID, "_(%d+)$")) or 1
	local nBodygroup  = math.Clamp(nSpellIdx - 1, 0, 4)
	local sRarity     = RARITY_BY_BODYGROUP[nBodygroup] or "rare"

	-- Icône : PNG parchemin commun à tous les parchemins de technique (demande user).
	-- (avant : on réutilisait l'icône du sort -> remis sur le PNG parchemin unique).
	local icon = GENERIC_PARCHEMIN_ICON

	-- Description auto depuis la config du sort
	local desc
	if sDesc ~= "" then
		desc = "Débloque l'achat de la technique « " .. sName .. " » dans l'arbre (puis achat aux points) : " .. sDesc
	else
		desc = "Débloque l'achat de la technique « " .. sName .. " » dans l'arbre de compétences (puis achat aux points)."
	end

	ITEMS[itemID] = {
		name        = "Parchemin : " .. sName,
		description = desc,
		icon        = icon,
		-- Rendu 3D dans la case (au lieu de l'icône PNG) + variante selon le palier du sort.
		-- Le modèle parchemin porte ses variantes en SKINS (0..4), PAS en bodygroup (vérifié via
		-- evo_item_bounds : bodygroup #0 = 1 valeur, skins = 5). -> on sélectionne le SKIN.
		model_path  = PARCHEMIN_SPELL_MODEL,
		skin        = nBodygroup,
		category    = "object",
		rarity      = sRarity, -- palier du bodygroup : 0 commun … 4 mythique

		-- UN SEUL par personnage (genre vraiment) : non echangeable, non jetable, non
		-- supprimable -> pas de farm via claim->trade->reclaim, pas de "reset" de sa copie.
		-- Seuls les SUPERADMINS contournent (bypass dans IsItemDroppable/IsItemDeletable).
		icon_scale   = 0.6, -- PNG plus petit dans la case d'inventaire (0.7 -> 0.6, encore + fin, demande user)
		is_droppable = false,
		is_deletable = false,
		is_technique_scroll = true,
		teach_spell = spellID,
		on_use = function(ply)
			-- Le déblocage + la consommation sont strictement serveur.
			if not SERVER then return end
			if not (IsValid(ply) and ply.GrantTechniquePurchaseUnlock) then return end

			-- Prérequis pour UTILISER le parchemin (pas seulement pour l'acheter) :
			-- niveau + grade + verrou + 1 technique/personnage. Géré par l'addon
			-- ncm_parchemin_vendor s'il est chargé (anti-bypass via trade). On NE
			-- consomme PAS le parchemin si refusé.
			if NCM_PARCHEMIN_VENDOR and NCM_PARCHEMIN_VENDOR.CanUseTechnique then
				local okUse, reason = NCM_PARCHEMIN_VENDOR.CanUseTechnique(ply, spellID)
				if not okUse then
					MUGEN.Notify(ply, reason or "Vous ne remplissez pas les prérequis.", NOTIFY_ERROR, 4)
					return
				end
			end

			-- Le parchemin n'ENSEIGNE PAS le sort : il DÉBLOQUE son ACHAT dans l'arbre de
			-- compétences. Le joueur l'achète ensuite avec des POINTS (UnlockSkill, gaté sur
			-- ce déblocage). Le déblocage persiste même à travers un reset d'arbre.
			local res = ply:GrantTechniquePurchaseUnlock(spellID)
			if res == "ok" then
				-- Consomme le parchemin uniquement en cas de succès
				ply:RemoveItem(itemID, function() end)
				MUGEN.Notify(ply, "Achat débloqué : « " .. sName .. " ». Achète-la dans l'arbre, puis entraîne-toi 5 fois sur un TERRAIN D'ENTRAÎNEMENT pour la maîtriser.", NOTIFY_GENERIC, 7)
				-- Démarre la quête d'apprentissage (tracker visible). La maîtrise réelle =
				-- 5 lancers sur un terrain d'entraînement (cf type_quete_apprentissage.lua).
				-- Skip les sorts exemptés de parchemin (ex. Cero = NoParcheminSpells).
				if (not NCM_PARCHEMIN_VENDOR or not NCM_PARCHEMIN_VENDOR.IsTechniqueSpell
					or NCM_PARCHEMIN_VENDOR.IsTechniqueSpell(spellID))
					and NCM_APPRENTISSAGE and NCM_APPRENTISSAGE.TryStartQuest then
					NCM_APPRENTISSAGE.TryStartQuest(ply, spellID)
				end
			elseif res == "already" then
				-- Le parchemin ne sert plus à rien : on le CONSOMME quand même,
				-- sinon il reste à vie dans le sac (ni jetable ni supprimable).
				-- Cas courant depuis que les sorts 1 de voie sont offerts (08/21).
				ply:RemoveItem(itemID, function() end)
				MUGEN.Notify(ply, "« " .. sName .. " » était déjà acquis : le parchemin part en fumée.", NOTIFY_ERROR, 5)
			end
			-- "notloaded" / "unknown" : ne consomme rien (silencieux)
		end,
	}
end

-- Construit/rafraîchit tous les parchemins de technique.
-- Idempotent : ré-exécutable sans effet de bord (réécrit les mêmes clés).
function INVENTORY_BuildTechniqueScrolls()
	for _, spellID in ipairs(TECHNIQUE_SPELLS) do
		buildOne(spellID)
	end
end

-- Build immédiat (citron_combat_system se charge avant inventory, donc
-- EvoStyle.SpellsConfig est normalement déjà peuplé), puis re-build une fois
-- tout chargé pour garantir les descriptions/icônes auto.
INVENTORY_BuildTechniqueScrolls()
hook.Add("Initialize", "INVENTORY_BuildTechniqueScrolls", INVENTORY_BuildTechniqueScrolls)
