-- "addons\\inventory\\lua\\inventory\\cl_stack.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Saisie de quantité (séparer / jeter / supprimer / échange / HDV).
-- Carte sombre DA, pas de Derma_StringRequest gris.

local COL_BG     = Color(14, 14, 17, 250)
local COL_TXT    = Color(237, 238, 242, 255)
local COL_DIM    = Color(150, 154, 162, 255)
local COL_FIELD  = Color(24, 24, 29, 235)
local COL_ACCENT = Color(207, 68, 78, 255)
local COL_BTN    = Color(24, 24, 29, 235)
local COL_BTN_H  = Color(34, 34, 41, 245)

local _prompt

local function R(n)
	if gRespX then return gRespX(n) end
	return math.floor(n * (ScrH() / 1080))
end

function INVENTORY_CONFIG.PromptQuantity(title, message, maxQty, onConfirm, opts)
	opts = istable(opts) and opts or {}
	maxQty = math.floor(tonumber(maxQty) or 1)
	if maxQty < 1 then return end
	local minQty = math.max(1, math.floor(tonumber(opts.min) or 1))
	if minQty > maxQty then minQty = maxQty end
	local default = math.floor(tonumber(opts.default) or maxQty)
	if default < minQty then default = minQty end
	if default > maxQty then default = maxQty end

	if maxQty == 1 and minQty == 1 then
		if onConfirm then onConfirm(1) end
		return
	end

	if IsValid(_prompt) then _prompt:Remove() end

	local back = vgui.Create("DFrame")
	back:SetSize(ScrW(), ScrH())
	back:SetPos(0, 0)
	back:SetTitle("")
	back:SetDraggable(false)
	back:ShowCloseButton(false)
	back:MakePopup()
	back:SetKeyboardInputEnabled(true)
	back.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 190)
		surface.DrawRect(0, 0, w, h)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end
	_prompt = back

	local bPicker = EVO_UI and isfunction(EVO_UI.QtyPicker)
	local W, H = R(420), bPicker and R(248) or R(210)
	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H)
	card:Center()
	card.Paint = function(_, w, h)
		draw.RoundedBox(8, 0, 0, w, h, COL_BG)
		draw.SimpleText(string.upper(title or "Quantité"), "Avenir Next World:18", R(22), R(22), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if isstring(message) and message ~= "" then
			draw.SimpleText(message, "Avenir Next World:16", R(22), R(54), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local getQty
	local entry
	if bPicker then
		-- Même slider + champ que le coffre de clan (EVO_UI.QtyPicker).
		getQty = EVO_UI.QtyPicker(card, R(22), R(84), W - R(44), R(32), maxQty, default, { hideLabel = true })
	else
		entry = vgui.Create("DTextEntry", card)
		entry:SetPos(R(22), R(92))
		entry:SetSize(W - R(44), R(38))
		entry:SetFont("Avenir Next World:18")
		entry:SetNumeric(true)
		entry:SetText(tostring(default))
		entry:SetTextColor(COL_TXT)
		entry:SetCursorColor(COL_TXT)
		entry:SetPaintBackground(false)
		entry:SetDrawLanguageID(false)
		entry.Paint = function(s, w, h)
			draw.RoundedBox(4, 0, 0, w, h, COL_FIELD)
			s:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
		end
	end

	local function parse()
		local n
		if getQty then
			n = math.floor(tonumber(getQty()) or 0)
		else
			n = math.floor(tonumber(entry:GetValue()) or 0)
		end
		if n < minQty then n = minQty end
		if n > maxQty then n = maxQty end
		return n
	end

	local function finish(ok)
		local n = parse()
		local cb = onConfirm
		_prompt = nil
		-- Un Droppable peut avoir ouvert ce prompt SANS DragMouseRelease :
		-- m_DragWatch / MouseCapture restent, le drag « gèle » et le clic
		-- Annuler/Valider retombe sur la case en dessous. On casse ça ici.
		if dragndrop then
			local main = dragndrop.m_DraggingMain
			if dragndrop.StopDragging then dragndrop.StopDragging() end
			if IsValid(main) then main:MouseCapture(false) end
		end
		-- Remove au tick suivant : DoClick+Remove immédiat laisse le mouse-up
		-- traverser le overlay et recliquer le panel sous le curseur.
		timer.Simple(0, function()
			if IsValid(back) then back:Remove() end
			if ok and cb then cb(n) end
		end)
	end

	if IsValid(entry) then
		entry.OnEnter = function() finish(true) end
		timer.Simple(0, function() if IsValid(entry) then entry:RequestFocus() entry:SelectAllText() end end)
	end
	back.OnKeyCodePressed = function(_, key)
		if key == KEY_ENTER or key == KEY_PAD_ENTER then finish(true) end
	end

	local function mkBtn(label, x, primary, fn)
		local b = vgui.Create("DButton", card)
		b:SetText("")
		b:SetPos(x, H - R(54))
		b:SetSize(R(140), R(36))
		b.Paint = function(s, w, h)
			local hov = s:IsHovered()
			local bg = primary and (hov and COL_ACCENT or Color(180, 55, 64)) or (hov and COL_BTN_H or COL_BTN)
			draw.RoundedBox(4, 0, 0, w, h, bg)
			draw.SimpleText(label, "Avenir Next World:16", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
		return b
	end

	mkBtn("Annuler", W - R(22) - R(140) - R(12) - R(140), false, function() finish(false) end)
	mkBtn(opts.confirm or "Valider", W - R(22) - R(140), true, function() finish(true) end)
end
