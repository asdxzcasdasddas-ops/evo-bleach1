-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_retirer_technique.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : retirer_technique (superadmin). Retire une TECHNIQUE DE
-- VOIE (katana/hakuda 2..5) apprise par un joueur : sort du skilltree, flag
-- « parchemin utilisé » (il faudra un nouveau parchemin pour racheter), barre
-- équipée nettoyée, et les POINTS dépensés sont REMBOURSÉS au prix courant.
-- Le sort 1 de chaque voie est le socle offert (re-accordé par la
-- réconciliation) : le retirer serait sans effet, il n'est pas proposé.
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command
command.set_category("Commandes - EVO")

-- Libellés depuis la config des sorts quand elle est chargée (menu client aussi).
local function NomSort(sSpellID)
	local t = EvoStyle and EvoStyle.SpellsConfig and EvoStyle.SpellsConfig[sSpellID]
	return (t and t.sName) or sSpellID
end

local _options = {}
for _, sWay in ipairs({ "katana", "hakuda" }) do
	for i = 2, 5 do
		local sID = "Spell_" .. sWay .. "_" .. i
		_options[#_options + 1] = (sWay == "katana" and "Katana " or "Hakuda ") .. i .. " (" .. NomSort(sID) .. ") [" .. sID .. "]"
	end
end
_options[#_options + 1] = "TOUTES les techniques de voie [toutes]"

local function extraireChoix(input)
	if not isstring(input) then return tostring(input) end
	return string.match(input, "%[([^%[%]]+)%]%s*$") or input
end

-- Retire UN sort de voie du perso : sort + flag parchemin + barre équipée,
-- points remboursés. Renvoie true si quelque chose a réellement été retiré.
local function RetirerSort(target, sSpellID)
	local skills = target.LZY_Skills
	if not istable(skills) then return false, 0 end
	local bRetire, nRembourse = false, 0

	-- Remboursement SEULEMENT si des points ont vraiment été dépensés : l'achat
	-- aux points exige le flag « parchemin utilisé » (parch_<sort>) et le laisse
	-- en place. Sans lui, le sort vient d'un grant gratuit (admin/dev) : rien à
	-- rembourser, sinon on créerait des points qui n'ont jamais existé.
	local bAchete = skills["parch_" .. sSpellID] ~= nil

	if skills[sSpellID] ~= nil then
		skills[sSpellID] = nil
		bRetire = true
		if bAchete then
			-- Prix COURANT (source unique : la config des sorts).
			local tCfg = EvoStyle and EvoStyle.SpellsConfig and EvoStyle.SpellsConfig[sSpellID]
			local nPrix = (tCfg and tonumber(tCfg.price)) or 0
			if nPrix > 0 then
				target:SetEvoNWInt("LZY_SkillTree_SkillPoints",
					target:GetEvoNWInt("LZY_SkillTree_SkillPoints", 0) + nPrix)
				nRembourse = nPrix
			end
		end
	end
	if skills["parch_" .. sSpellID] ~= nil then
		skills["parch_" .. sSpellID] = nil
		bRetire = true
	end

	-- Barre équipée : l'entrée du sort saute (format canonique {id, niveau}).
	local tEq = util.JSONToTable(target:GetEvoNWString("LZY_SpellSelector_Equipped", "[]"))
	if istable(tEq) then
		local bEqChange = false
		for k, e in pairs(tEq) do
			local id = istable(e) and (e[1] or e.id) or e
			if id == sSpellID then tEq[k] = nil bEqChange = true end
		end
		if bEqChange then
			target:SetEvoNWString("LZY_SpellSelector_Equipped", util.TableToJSON(tEq))
			bRetire = true
		end
	end

	return bRetire, nRembourse
end

command.new("retirer_technique")
	:Aliases("remove_technique", "retirer_spell")

	:SetPermission("retirer_technique", "superadmin")

	:AddArg("player")
	:AddArg("dropdown", { hint = "technique", options = _options })

	:Help("Retire une technique de voie (katana/hakuda) apprise par le joueur : sort, parchemin utilisé et barre équipée ; les points dépensés sont remboursés. Superadmin.")

	:OnExecute(function(ply, targets, sInput)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		local sChoix = extraireChoix(sInput)
		local tCibles = {}
		if sChoix == "toutes" then
			for _, sWay in ipairs({ "katana", "hakuda" }) do
				for i = 2, 5 do tCibles[#tCibles + 1] = "Spell_" .. sWay .. "_" .. i end
			end
		elseif string.match(sChoix, "^Spell_katana_[2-5]$") or string.match(sChoix, "^Spell_hakuda_[2-5]$") then
			tCibles[1] = sChoix
		else
			if IsValid(ply) then ply:sam_send_message("Technique inconnue : " .. tostring(sChoix)) end
			return
		end

		for _, target in ipairs(targets) do
			if IsValid(target) then
				local tRetires, nTotalRemb = {}, 0
				for _, sSpellID in ipairs(tCibles) do
					local bOk, nRemb = RetirerSort(target, sSpellID)
					if bOk then
						tRetires[#tRetires + 1] = NomSort(sSpellID)
						nTotalRemb = nTotalRemb + (nRemb or 0)
					end
				end
				if #tRetires > 0 then
					-- Une seule sauvegarde : sorts + points + barre (SaveSkillsToDB lit tout).
					if target.SaveSkillsToDB then target:SaveSkillsToDB() end
					if target.LZY_SkillTree_PushSkillsToClient then target:LZY_SkillTree_PushSkillsToClient() end
					-- Le remboursement n'est annoncé QUE s'il a eu lieu (sort acheté aux points).
					local sRemb = nTotalRemb > 0 and (" " .. nTotalRemb .. " point(s) remboursé(s).") or ""
					MUGEN.Notify(target, "Le staff t'a retiré : " .. table.concat(tRetires, ", ") .. "." .. sRemb, NOTIFY_GENERIC, 6)
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : retiré " .. table.concat(tRetires, ", ") .. (nTotalRemb > 0 and (" (" .. nTotalRemb .. " pts remboursés).") or " (aucun point remboursé, sort non acheté).")) end
					if EVO_StaffLog then EVO_StaffLog(ply, "spell.retirer_technique", target, table.concat(tRetires, ", ")) end
				else
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : rien à retirer (technique non apprise).") end
				end
			end
		end
	end)
:End()
