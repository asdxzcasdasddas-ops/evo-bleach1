-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_shikai_etapes.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : shikai_etape (superadmin). BANC DE TEST des 3 étapes du
-- Shikai (08/31) : lancer / terminer / annuler chaque étape sans attendre les
-- prérequis ni les délais de 24 h. Ne réinvente RIEN : chaque action appelle la
-- machinerie réelle (NCM_QUETE.StartCloneFight / EndCloneFight /
-- StartShikaiRituel, EVO_BLANC.Rituel, EVO_SharedData) — exactement ce que le
-- flux joueur déclenche, donc tester ici teste le vrai parcours.
--
--   Étape 1 = chaîne de quêtes 1-9 du Maître du Zanpakuto
--   Étape 2 = combat contre son clone (quête 10, instancié, CD 24 h à l'échec)
--   Étape 3 = rituel de la Salle Blanche (J+1, instancié, automatisé)
--
-- (Complète les concommands existantes : ncm_force_shikai_quest propose la
--  prochaine quête, ncm_force_shikai_unlock donne le Shikai directement.)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command
command.set_category("Commandes - EVO")

local _actions = {
	"Étape 1 — TERMINER les 9 quêtes [e1_finir]",
	"Étape 1 — RÉINITIALISER toute la progression [e1_reset]",
	"Étape 2 — LANCER le combat de clone [e2_lancer]",
	"Étape 2 — VICTOIRE immédiate (arme le J+1) [e2_gagner]",
	"Étape 2 — ANNULER sans cooldown [e2_annuler]",
	"Étape 2 — PURGER le cooldown 24 h [e2_cd_off]",
	"Étape 3 — OUVRIR maintenant (saute les 24 h) [e3_maintenant]",
	"Étape 3 — LANCER le rituel directement [e3_lancer]",
	"Étape 3 — ANNULER le rituel en cours [e3_annuler]",
}

local function extraireAction(input)
	if not isstring(input) then return tostring(input) end
	return string.match(input, "%[([^%[%]]+)%]%s*$") or input
end

-- Marque une quête de la chaîne comme faite (le vrai marquage : même champ +
-- même sauvegarde que la complétion normale, récompenses exclues — c'est un test).
local function marquerFaite(target, sQuestID)
	target._ncmCompletedQuests = target._ncmCompletedQuests or {}
	target._ncmCompletedQuests[sQuestID] = true
end

local function sauver(target)
	if NCM_QUETE.SavePlayerState then NCM_QUETE.SavePlayerState(target) end
end

-- Purge une clé partagée PAR PERSONNAGE (clone_cd / rituel_at / ping80).
local function purgerCle(target, sBase)
	if not (EVO_SharedData and NCM_QUETE.ShikaiCle) then return end
	local k = NCM_QUETE.ShikaiCle(target, sBase)
	if k and EVO_SharedData.Delete then EVO_SharedData.Delete(target, k) end
end

local ACTIONS = {
	e1_finir = function(ply, target)
		for i = 1, 9 do marquerFaite(target, "shikai_" .. i) end
		sauver(target)
		return "quêtes shikai 1 à 9 marquées FAITES (parle au PNJ pour la quête 10)."
	end,

	e1_reset = function(ply, target)
		-- Coupe un éventuel combat/rituel en cours, puis remet le personnage à zéro
		-- sur TOUTE la progression Shikai (quêtes, éligibilité, délais, ping).
		if target._ncmProgClone then
			target._ncmCloneFightStarted = nil -- pas de CD posé par CE nettoyage
			NCM_QUETE.EndCloneFight(target, false)
		end
		if EVO_BLANC and EVO_BLANC.Rituel and EVO_BLANC.Rituel.TerminerBlocJoueur then
			EVO_BLANC.Rituel.TerminerBlocJoueur(target)
		end
		target._ncmCompletedQuests = target._ncmCompletedQuests or {}
		for i = 1, 10 do target._ncmCompletedQuests["shikai_" .. i] = nil end
		local tActive = target._ncmActiveQuest
		if tActive and tostring(tActive.id or ""):find("^shikai_") then
			target._ncmActiveQuest = nil
			target:SetEvoNWString("ncm_questState", "none")
			target:SetEvoNWString("ncm_questPNJType", "")
		end
		target:SetEvoNWBool("EVO_ShikaiEligible", false)
		if EVO_SharedData then EVO_SharedData.Set(target, "EVO_ShikaiEligible", "0") end
		purgerCle(target, "shikai_clone_cd")
		purgerCle(target, "shikai_rituel_at")
		purgerCle(target, "shikai_ping80")
		sauver(target)
		return "progression Shikai réinitialisée (quêtes, éligibilité, délais, ping). Le déblocage Shikai lui-même n'est PAS retiré."
	end,

	e2_lancer = function(ply, target)
		if target._ncmProgClone then return "un combat de clone est déjà en cours." end
		NCM_QUETE.StartCloneFight(target, "shikai")
		return "combat de clone lancé (Salle Blanche instanciée si posée, sinon repli)."
	end,

	e2_gagner = function(ply, target)
		if IsValid(target._ncmProgClone) then
			-- Tuer le clone = le VRAI chemin de victoire (mort -> hook -> EndCloneFight).
			target._ncmProgClone:Kill()
		end
		-- Valide l'étape côté progression : quête 10 faite + fin de chaîne (arme le J+1).
		for i = 1, 10 do marquerFaite(target, "shikai_" .. i) end
		sauver(target)
		hook.Run("NCM_Quete::QuestCompleted", target, "shikai_10")
		return "victoire : chaîne complète, Salle Blanche armée pour DEMAIN (e3_maintenant pour sauter l'attente)."
	end,

	e2_annuler = function(ply, target)
		if not target._ncmProgClone then return "aucun combat de clone en cours." end
		target._ncmCloneFightStarted = nil -- l'annulation de TEST ne pose pas le CD 24 h
		NCM_QUETE.EndCloneFight(target, false)
		purgerCle(target, "shikai_clone_cd") -- ceinture : aucun CD résiduel
		return "combat annulé, aucun cooldown posé."
	end,

	e2_cd_off = function(ply, target)
		purgerCle(target, "shikai_clone_cd")
		return "cooldown de défaite purgé : le clone est retentable tout de suite."
	end,

	e3_maintenant = function(ply, target)
		if not (EVO_SharedData and NCM_QUETE.ShikaiCle) then return "EVO_SharedData indisponible." end
		local k = NCM_QUETE.ShikaiCle(target, "shikai_rituel_at")
		if not k then return "personnage pas chargé." end
		EVO_SharedData.Set(target, k, tostring(os.time()))
		return "attente de 24 h sautée : le PNJ lancera le rituel à la prochaine visite."
	end,

	e3_lancer = function(ply, target)
		if not NCM_QUETE.StartShikaiRituel then return "StartShikaiRituel indisponible (restart requis ?)." end
		if NCM_QUETE.StartShikaiRituel(target) then
			return "rituel lancé (Salle Blanche instanciée)."
		end
		return "rituel refusé : Salle Blanche non posée/plantée sur ce serveur, ou rituel déjà en cours."
	end,

	e3_annuler = function(ply, target)
		if not (EVO_BLANC and EVO_BLANC.Rituel and EVO_BLANC.Rituel.TerminerBlocJoueur) then
			return "evo_blanc indisponible."
		end
		EVO_BLANC.Rituel.TerminerBlocJoueur(target) -- Terminer(false) -> retour + sortie d'instance
		return "rituel annulé, joueur ramené à sa position."
	end,
}

command.new("shikai_etape")
	:Aliases("shikaietape", "shikai_test")

	:SetPermission("shikai_etape", "superadmin")

	:AddArg("player")
	:AddArg("dropdown", { hint = "action", options = _actions })

	:Help("Banc de test des 3 étapes du Shikai : lancer / terminer / annuler chaque étape, sauter les 24 h, purger les cooldowns. Superadmin.")

	:OnExecute(function(ply, targets, sInput)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		local sAction = extraireAction(sInput)
		local f = ACTIONS[sAction]
		if not f then
			if IsValid(ply) then ply:sam_send_message("Action inconnue : " .. tostring(sAction)) end
			return
		end
		for _, target in ipairs(targets) do
			if IsValid(target) then
				local sMsg = f(ply, target) or "fait."
				if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : " .. sMsg) end
				if EVO_StaffLog then EVO_StaffLog(ply, "test.shikai_etape", target, sAction) end
			end
		end
	end)
:End()
