-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_bataille_arena.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- ============================================================================
-- SAM : Bataille des Clans — éditeur d'arène + force-start
-- ============================================================================

local command = sam.command

command.set_category("Commandes - EVO")

command.new("bataille_arena")
	:SetPermission("bataille_arena", "superadmin")
	:Help("Ouvre l'éditeur d'arène de la Bataille des Clans (centre / rayon / copie config).")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if EVO_BATAILLE and EVO_BATAILLE.OpenArenaEditor then
			EVO_BATAILLE.OpenArenaEditor(ply)
		elseif util.NetworkStringToID("EVO_Bataille:OpenArenaEditor") ~= 0 then
			net.Start("EVO_Bataille:OpenArenaEditor")
			net.Send(ply)
		else
			ply:sam_send_message("evo_bataille_clans indisponible (addon non chargé ?).")
		end
	end)
:End()

local forceDefaults = (EVO_BATAILLE and EVO_BATAILLE.Config and EVO_BATAILLE.Config.ForceStart) or {}
local defJoin  = tonumber(forceDefaults.JoinMinutes) or 5
local defLeave = tonumber(forceDefaults.LeaveCutoffMinutes) or 10
local defSoft  = tonumber(forceDefaults.SoftEndMinutes) or 15

command.new("bataille_start")
	:SetPermission("bataille_start", "superadmin")
	:AddArg("number", { hint = "join (min)", optional = true, default = defJoin, round = true, min = 1, max = 180 })
	:AddArg("number", { hint = "cutoff reward (min)", optional = true, default = defLeave, round = true, min = 1, max = 180 })
	:AddArg("number", { hint = "soft end (min)", optional = true, default = defSoft, round = true, min = 1, max = 180 })
	:Help("Démarre manuellement la Bataille (minutes depuis maintenant : join / cutoff reward / soft end).")
	:OnExecute(function(ply, joinMin, leaveMin, softMin)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_BATAILLE and EVO_BATAILLE.ForceStart) then
			ply:sam_send_message("evo_bataille_clans indisponible (addon non chargé ?).")
			return
		end
		local ok, msg = EVO_BATAILLE.ForceStart(ply, joinMin, leaveMin, softMin)
		ply:sam_send_message(msg or (ok and "Bataille démarrée." or "Échec du force-start."))
	end)
:End()

command.new("bataille_stop")
	:SetPermission("bataille_stop", "superadmin")
	:Help("Arrête / annule la Bataille des Clans en cours (pas de rewards).")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_BATAILLE and EVO_BATAILLE.ForceStop) then
			ply:sam_send_message("evo_bataille_clans indisponible (addon non chargé ?).")
			return
		end
		local ok, msg = EVO_BATAILLE.ForceStop(ply)
		ply:sam_send_message(msg or (ok and "Bataille arrêtée." or "Échec de l'arrêt."))
	end)
:End()
