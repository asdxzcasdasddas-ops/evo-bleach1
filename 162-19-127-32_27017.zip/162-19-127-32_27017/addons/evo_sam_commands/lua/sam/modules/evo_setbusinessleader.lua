-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_setbusinessleader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : setbusinessleader
-- Usage : !setbusinessleader <joueur> [business]
-- Le 2e argument est optionnel (défaut : bar). Transfère la direction :
-- l'ancien leader devient employé, la cible devient leader (déplacée si besoin).
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("setbusinessleader")
	:Aliases("setbizleader", "barleader")

	:SetPermission("setbusinessleader", "superadmin")

	:AddArg("player", { single_target = true })
	:AddArg("text", { hint = "business (défaut: bar)", optional = true, default = "bar" })

	:Help("Nomme le leader d'un commerce (Bar par défaut). L'ancien leader reste employé.")

	:OnExecute(function(ply, targets, sBiz)
		sBiz = string.lower(string.Trim(tostring(sBiz or "bar")))
		if sBiz == "" then sBiz = "bar" end
		local target = targets[1]
		if not (IsValid(target) and EVO_BUSINESS and EVO_BUSINESS.SetLeader) then
			return
		end
		EVO_BUSINESS.SetLeader(target, sBiz, ply, function(ok)
			if ok then
				sam.player.send_message(nil, "{A} a nommé {T} leader du commerce {V}", {
					A = ply, T = { target }, V = sBiz,
				})
			end
		end)
	end)
:End()
