-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_agri_editor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — Commande SAM "agri_editor" : preview pot + gizmo de pose plante.
-- ============================================================================
if SAM_LOADED then return end

local command = sam.command

command.set_category("Commandes - EVO")

command.new("agri_editor")
	:Aliases("agripot", "agripreview")
	:SetPermission("agri_editor", "superadmin")
	:Help("Éditeur de pots agri (variant + plante + phases + gizmo). Superadmin. Maintiens C pour la souris.")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_AGRI and EVO_AGRI.OpenEditor) then
			ply:sam_send_message("evo_agri indisponible — l'addon n'est pas chargé (restart serveur requis ?).")
			return
		end
		if util.NetworkStringToID("EVO_Agri:EditorOpen") == 0 then
			ply:sam_send_message("evo_agri editor indisponible — net strings absentes.")
			return
		end
		EVO_AGRI.OpenEditor(ply)
	end)
:End()
