-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_config_positions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — Commande SAM "config_positions" : toggle le mode gizmo SuperAdmin
-- pour déplacer les positions de config (domaine, entraînement, PNJ...).
-- ============================================================================
if SAM_LOADED then return end

local command = sam.command

command.set_category("Commandes - EVO")

command.new("config_positions")
	:Aliases("configpos", "cfgpos")
	:SetPermission("config_positions", "superadmin")
	:Help("Toggle le mode d'édition des positions de config (gizmos). Superadmin. Maintiens C pour la souris.")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_ConfigPos and EVO_ConfigPos.ToggleEditor) then
			ply:sam_send_message("evo_config_positions indisponible — l'addon n'est pas chargé (restart serveur requis ?).")
			return
		end
		if util.NetworkStringToID("EVO_ConfigPos:Toggle") == 0 then
			ply:sam_send_message("evo_config_positions indisponible — net strings absentes.")
			return
		end
		EVO_ConfigPos.ToggleEditor(ply)
	end)
:End()

command.new("config_positions_export")
	:Aliases("cfgpos_export")
	:SetPermission("config_positions_export", "superadmin")
	:Help("Ecrit le bundle des positions (data/evo_config_positions_bundle.json) pour le copier sur un autre serveur.")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_ConfigPos and EVO_ConfigPos.ExportBundle) then
			ply:sam_send_message("evo_config_positions indisponible.")
			return
		end
		EVO_ConfigPos.ExportBundle(ply)
	end)
:End()

command.new("config_positions_import")
	:Aliases("cfgpos_import")
	:SetPermission("config_positions_import", "superadmin")
	:Help("Charge garrysmod/data/evo_config_positions_bundle.json et applique les positions en live.")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_ConfigPos and EVO_ConfigPos.ImportBundle) then
			ply:sam_send_message("evo_config_positions indisponible.")
			return
		end
		local ok, err = EVO_ConfigPos.ImportBundle(ply)
		if not ok then
			ply:sam_send_message(err or "import echoue")
		end
	end)
:End()
