-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_enchant_repair.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commandes SAM : enchant_repair_check / enchant_repair (superadmin)
-- Répare les gravures massacrées par la migration du 08/28, en relisant les
-- valeurs d'origine dans une COPIE de `inventory` antérieure au 08/28.
-- Une pièce regravée depuis n'est jamais touchée (appariement par empreinte).
-- Usage : !enchant_repair_check [table]   (simulation, aucune écriture)
--         !enchant_repair [table]         (applique)
-- Table par défaut : inventory_backup_0828
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Craft")

local function report(ply, bDry, bOk, st, sErr)
	if not bOk then
		local fail = sErr or "Échec de la réparation des gravures."
		if IsValid(ply) then ply:sam_send_message(fail) else print("[SAM] " .. fail) end
		return false
	end
	local info = string.format("Réparation gravures%s : %d %s sur %d gravure(s) sauvegardée(s).",
		bDry and " — SIMULATION" or "",
		tonumber(st and st.repaired) or 0,
		bDry and "à réparer" or "réparée(s)",
		tonumber(st and st.backup) or 0)
	local tLines = EVO_CRAFT.EnchantRepairReport(st, bDry)
	if IsValid(ply) then
		ply:sam_send_message(info .. " Détail dans votre console.")
		ply:PrintMessage(HUD_PRINTCONSOLE, info)
		for _, l in ipairs(tLines) do ply:PrintMessage(HUD_PRINTCONSOLE, l) end
	else
		print("[SAM] " .. info)
		for _, l in ipairs(tLines) do print(l) end
	end
	return true, tonumber(st and st.repaired) or 0
end

local function available(ply)
	if EVO_CRAFT and EVO_CRAFT.EnchantRepairFromBackup then return true end
	if IsValid(ply) then ply:sam_send_message("EVO_CRAFT.EnchantRepairFromBackup indisponible.") end
	return false
end

-- ============================================================================
-- LA COMMANDE SIMPLE : aucune sauvegarde, aucune manip SQL.
-- Inverse la formule cassée du 08/28 et ne réécrit que les gravures dont
-- l'origine est PROUVÉE unique. Une gravure faite après le 08/28 (donc déjà
-- correcte) n'est jamais touchée : sa valeur est dans la plage d'un tirage
-- légitime, ce qui la rend indiscernable -> la commande passe son tour.
-- ============================================================================
local function reportAuto(ply, bDry, bOk, tStats, sErr)
	if not bOk then
		local fail = sErr or "Échec de la réparation des gravures."
		if IsValid(ply) then ply:sam_send_message(fail) else print("[SAM] " .. fail) end
		return false
	end
	local nFix = 0
	for _, s in pairs(tStats or {}) do
		if istable(s) then nFix = nFix + (tonumber(s.fixed) or 0) end
	end
	local info = string.format("Gravures%s : %d boost(s) %s.",
		bDry and " — SIMULATION" or "", nFix,
		bDry and "réparable(s)" or "restauré(s)")
	local tLines = EVO_CRAFT.EnchantAutoFixReport(tStats, bDry)
	if IsValid(ply) then
		ply:sam_send_message(info .. " Détail dans votre console.")
		ply:PrintMessage(HUD_PRINTCONSOLE, info)
		for _, l in ipairs(tLines) do ply:PrintMessage(HUD_PRINTCONSOLE, l) end
	else
		print("[SAM] " .. info)
		for _, l in ipairs(tLines) do print(l) end
	end
	return true, nFix
end

local function availableAuto(ply)
	if EVO_CRAFT and EVO_CRAFT.EnchantAutoFix then return true end
	if IsValid(ply) then ply:sam_send_message("EVO_CRAFT.EnchantAutoFix indisponible.") end
	return false
end

command.new("enchant_fix_check")
	:Aliases("gravure_check", "fix_gravure_check")

	:SetPermission("enchant_fix_check", "superadmin")

	:Help("Simule la réparation des gravures cassées par la migration du 08/28 (aucune écriture, aucune sauvegarde requise).")

	:OnExecute(function(ply)
		if not availableAuto(ply) then return end
		EVO_CRAFT.EnchantAutoFix({ dry = true }, function(bOk, tStats, sErr)
			reportAuto(ply, true, bOk, tStats, sErr)
		end)
	end)
:End()

command.new("enchant_fix")
	:Aliases("gravure_fix", "fix_gravure", "reparer_gravures")

	:SetPermission("enchant_fix", "superadmin")

	:Help("Répare les gravures cassées par la migration du 08/28, partout, sans sauvegarde. Ne touche jamais une gravure récente.")

	:OnExecute(function(ply)
		if not availableAuto(ply) then return end
		EVO_CRAFT.EnchantAutoFix({}, function(bOk, tStats, sErr)
			local ok, n = reportAuto(ply, false, bOk, tStats, sErr)
			if not ok then return end
			sam.player.send_message(nil, "{A} a réparé les gravures d'équipement ("
				.. tostring(n) .. " boost(s) restauré(s))", { A = ply })
		end)
	end)
:End()

command.new("enchant_repair_check")
	:Aliases("gravure_repair_check", "repair_gravure_check")

	:SetPermission("enchant_repair_check", "superadmin")

	:AddArg("text", { name = "table", optional = true, default = "" })

	:Help("Simule la réparation des gravures du 08/28 depuis une sauvegarde (aucune écriture).")

	:OnExecute(function(ply, sTable)
		if not available(ply) then return end
		EVO_CRAFT.EnchantRepairFromBackup({ dry = true, table = sTable }, function(bOk, st, sErr)
			report(ply, true, bOk, st, sErr)
		end)
	end)
:End()

command.new("enchant_repair")
	:Aliases("gravure_repair", "repair_gravure")

	:SetPermission("enchant_repair", "superadmin")

	:AddArg("text", { name = "table", optional = true, default = "" })

	:Help("Répare les gravures massacrées par la migration du 08/28 depuis une sauvegarde pré-08/28.")

	:OnExecute(function(ply, sTable)
		if not available(ply) then return end
		EVO_CRAFT.EnchantRepairFromBackup({ table = sTable }, function(bOk, st, sErr)
			local ok, n = report(ply, false, bOk, st, sErr)
			if not ok then return end
			sam.player.send_message(nil, "{A} a réparé les gravures d'équipement ("
				.. tostring(n) .. " restaurée(s))", { A = ply })
		end)
	end)
:End()
