-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_ck_rpk.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- ============================================================================
-- EVO — Commandes SAM "ck", "rename_identity" et "rpk" (demande user 08/08). Superadmin.
--
--   CK  (Character Kill) : grade 1 + aucune division, wipe TOTAL des sorts (y compris
--        parch_/mastered_), flag ck_pending → retour sélection → recréation nom /
--        esthétique / genre. Retire l'ACCÈS shikai ET bankai (shikai_unlocked = 0,
--        bankai_unlocked = 0) et efface le nom du katana + mot de libération (re-choisis
--        au prochain unlock). GARDE les niveaux d'amélioration (evo_power_upgrades)
--        et les passifs (inactifs tant que le shikai/bankai n'est pas relancé).
--        GARDE level perso, autres
--        unlocks majeurs, money, inventaire, quêtes.
--        REMET À ZÉRO le passé de l'ancien perso (10/17, suggestion joueurs) :
--        captures de drapeau, morts, rapports de faction (archivés). GARDE les
--        heures de jeu et l'équipement.
--        QUITTE le clan (même sans changement de faction). À la recréation, le
--        joueur peut changer de faction : l'art spirituel devient un jeton de
--        la même rareté, les unlocks incompatibles et les chaînes shikai /
--        bankai / masque / libération sont retirés.
--        Cible : joueur connecté (liste SAM) ou hors-ligne (SteamID / nom RP).
--
--   rename_identity : ancien CK (nom seulement). Conservé pour un rename staff sans
--        demote / wipe.
--
--   RPK (RP Kill)        : le personnage MEURT. Il repart au GRADE 1, niveau 1,
--        sans rien de ce qu'il avait appris. Il GARDE tout ce qui a été PAYÉ.
--
-- ⚠ RÈGLE D'OR : ne JAMAIS appeler DeleteCharacter ni recréer la ligne du perso.
-- DeleteCharacter fait une cascade qui emporte `inventory`.
-- ============================================================================
local command = sam.command

command.set_category("Commandes - EVO")

local NAME_MAX = 32
local DELAI_CONFIRM = 20

local function cleanName(s)
	s = string.Trim(tostring(s or ""))
	s = string.gsub(s, "%s+", " ")
	return string.sub(s, 1, NAME_MAX)
end

local function uidDe(ply)
	local uid = ply:GetEvoNWString("Character::Unique::ID", "none")
	if uid == nil or uid == "" or uid == "none" then return nil end
	return uid
end

local function nomRp(ply)
	local n = ply:GetEvoNWString("Nickname", "")
	return (n ~= "" and n) or ply:Nick()
end

-- Confirmation partagée SAM + dashboard (clé = steamid64 admin).
local CK_EN_ATTENTE = {} -- adminSid -> { cible = sid, uid = ..., jusqua = CurTime() }

function EVO_CK_ArmConfirmId(admin, sid64, uid, nom)
	if not sid64 or not uid then return false, "Cible invalide." end
	sid64, uid = tostring(sid64), tostring(uid)
	nom = nom or sid64
	local cleAdmin = IsValid(admin) and admin:SteamID64() or "console"
	local att = CK_EN_ATTENTE[cleAdmin]
	if not (att and tostring(att.cible) == sid64 and tostring(att.uid) == uid and CurTime() < att.jusqua) then
		CK_EN_ATTENTE[cleAdmin] = { cible = sid64, uid = uid, jusqua = CurTime() + DELAI_CONFIRM }
		return false, "pending", nom
	end
	CK_EN_ATTENTE[cleAdmin] = nil
	return true, nil, nom
end

function EVO_CK_ArmConfirm(admin, target)
	if not IsValid(target) then return false, "Cible invalide." end
	local uid = uidDe(target)
	if not uid then return false, target:Nick() .. " n'a aucun personnage chargé." end
	return EVO_CK_ArmConfirmId(admin, target:SteamID64(), uid, nomRp(target))
end

-- CK : plus d'accès shikai ni bankai, niveaux d'upgrade intacts (table evo_power_upgrades).
-- Passifs conservés (ne s'appliquent que quand le shikai/bankai est actif).
-- Nom du katana et mot de libération effacés : le joueur les re-choisit au prochain unlock.
-- netgate: edge
local function revokePowerAccess(sid, uid, target)
	if not sid or not uid then return end
	if MUGEN and MUGEN.Query then
		MUGEN.Query(string.format(
			"UPDATE characters SET shikai_unlocked = 0, bankai_unlocked = 0, katana_name = '', shikai_word = '' WHERE unique_id = %s AND steamid64 = %s",
			sql.SQLStr(uid), sql.SQLStr(sid)))
	end
	if not IsValid(target) then return end
	if target:GetEvoNWBool("EVO_ShikaiUnlocked", false) then
		target:SetEvoNWBool("EVO_ShikaiUnlocked", false)
		if target.SetPData then target:SetPData("EVO_ShikaiUnlocked", "0") end
	end
	if target:GetEvoNWBool("EVO_BankaiUnlocked", false) then
		target:SetEvoNWBool("EVO_BankaiUnlocked", false)
	end
	target:SetEvoNWString("KatanaName", "")
	target:SetEvoNWString("ShikaiWord", "")
end

-- Parchemins de technique (achetés au PNJ OU donnés par un professeur) : ni jetables ni
-- supprimables, le perso recréé les gardait au sac (09/28, user). Joueur sur ce perso = retrait
-- live (inventaire en mémoire synchro) ; sinon DELETE en BDD.
local function RetirerParchemins(sid, uid, target)
	if IsValid(target) and tostring(uidDe(target) or "") == tostring(uid)
		and target.inventory and istable(target.inventory.items) and target.RemoveItem then
		for slot, iid in pairs(target.inventory.items) do
			local it = iid and ITEMS and ITEMS[iid]
			if it and it.is_technique_scroll then
				local q = (INVENTORY_CONFIG and INVENTORY_CONFIG.GetSlotQuantity) and INVENTORY_CONFIG.GetSlotQuantity(target.inventory, slot) or 1
				target:RemoveItem(iid, nil, nil, slot, q)
			end
		end
		return
	end
	local tIds = {}
	for id, it in pairs(ITEMS or {}) do
		if istable(it) and it.is_technique_scroll then tIds[#tIds + 1] = sql.SQLStr(id) end
	end
	if #tIds > 0 and tonumber(uid) then
		MUGEN.Query(string.format("DELETE FROM inventory WHERE character_id = %d AND item_id IN (%s)",
			tonumber(uid), table.concat(tIds, ",")))
	end
end

-- Passe de l'ancien perso (10/17, suggestion joueurs validee par axxou) : le CK garde la
-- meme ligne `characters`, donc le perso « neuf » affichait les morts de l'ancien, et ses
-- rapports et captures deja faits remplissaient les prerequis de grade (plus personne ne
-- refaisait les drapeaux). Captures et morts a zero ; rapports ARCHIVES (inactive = 1, comme
-- le nettoyage SA des rapports) : ils restent en base mais ne comptent plus et quittent la
-- file a valider. Une requete par colonne : une migration absente ne bloque pas l'autre.
-- Heures de jeu et equipement gardes (refuses par les joueurs : trop decourageant).
local function EffacerPasseCk(sid, uid)
	if not sid or not uid or not (MUGEN and MUGEN.Query) then return end
	MUGEN.Query(string.format(
		"UPDATE characters SET flag_captures = 0 WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	MUGEN.Query(string.format(
		"UPDATE characters SET deaths = 0 WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	MUGEN.Query(string.format(
		"UPDATE lzy_faction_reports SET inactive = 1 WHERE steamid64 = %s AND character_id = %s AND inactive = 0",
		sql.SQLStr(sid), sql.SQLStr(uid)))
end

-- Applique le CK complet. Retourne ok, msgOrName.
function EVO_ApplyCharacterKill(admin, target)
	if not IsValid(target) then return false, "Cible invalide." end
	if not (MUGEN and MUGEN.Query) then return false, "Base de données indisponible (MUGEN)." end

	local uid = uidDe(target)
	if not uid then return false, target:Nick() .. " n'a aucun personnage chargé." end

	local sid = target:SteamID64()
	local nom = nomRp(target)

	if EVO_FAMILLE and EVO_FAMILLE.ForceLeaveCharacter then
		EVO_FAMILLE.ForceLeaveCharacter(sid, uid)
	end

	-- 1) Flag recreate AVANT demote (survit au Clear du menu perso).
	MUGEN.Query(string.format(
		"UPDATE characters SET ck_pending = 1 WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	revokePowerAccess(sid, uid, target)
	RetirerParchemins(sid, uid, target)
	EffacerPasseCk(sid, uid)
	-- Membres coupés remis (09/26) : le nouveau personnage repart entier.
	if EVO_AMPUT and EVO_AMPUT.RestoreForCk then EVO_AMPUT.RestoreForCk(sid, uid, admin) end

	-- 2) Grade 1 + aucune division, puis reset TOTAL de l'arbre (techniques, parch_ et
	--    mastered_ inclus) : la rétrogradation seule ne touche plus aux sorts (09/28).
	local fait = false
	local function finirSkills()
		if fait or not IsValid(target) then return end
		fait = true
		if LZY_ResetSkillsForCharacter then
			LZY_ResetSkillsForCharacter(sid, uid, true)
		end
		if target.SetDivision then
			target:SetDivision(1)
		end
		-- 3) Retour forcé au choix de perso (bypass verrou combat).
		if target.ReOpenCharacterMenu then
			target:ReOpenCharacterMenu(true)
		end
		target:sam_send_message("CK : ton personnage est Character Kill. Grade 1, sorts perdus, clan quitté, shikai et bankai verrouillés (niveaux d'amélioration conservés). Captures de drapeau, rapports et morts repartent de zéro (heures de jeu et équipement gardés). Depuis la sélection, recrée son identité : tu peux aussi changer de faction. Si tu changes, ton art spirituel devient un jeton de la même rareté.")
	end

	if target.SetRank then
		target:SetRank(1, finirSkills)
		timer.Simple(2, finirSkills)
	else
		finirSkills()
	end

	if EVO_StaffLog and IsValid(admin) then
		EVO_StaffLog(admin, "rp.ck", target, "full " .. nom .. " (perso " .. tostring(uid) .. ")")
	end
	return true, nom
end

-- CK hors-ligne (ou autre perso que celui chargé) : flag + grade/division + wipe sorts en BDD.
-- Si le joueur est connecté SUR ce perso, on reprend le chemin live (menu + message).
function EVO_ApplyCharacterKillById(admin, sid64, uid, nom)
	sid64, uid = tostring(sid64 or ""), tostring(uid or "")
	if sid64 == "" or not tonumber(uid) then return false, "Cible invalide." end
	if not (MUGEN and MUGEN.Query) then return false, "Base de données indisponible (MUGEN)." end

	local live = player.GetBySteamID64(sid64)
	if IsValid(live) and tostring(uidDe(live) or "") == uid then
		return EVO_ApplyCharacterKill(admin, live)
	end

	nom = nom or sid64

	if EVO_FAMILLE and EVO_FAMILLE.ForceLeaveCharacter then
		EVO_FAMILLE.ForceLeaveCharacter(sid64, uid)
	end

	MUGEN.Query(string.format(
		"UPDATE characters SET ck_pending = 1 WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid64)))
	revokePowerAccess(sid64, uid, live)
	RetirerParchemins(sid64, uid, live)
	EffacerPasseCk(sid64, uid)
	if EVO_AMPUT and EVO_AMPUT.RestoreForCk then EVO_AMPUT.RestoreForCk(sid64, uid, admin) end
	MUGEN.Query(string.format(
		"UPDATE lzy_faction_members SET `rank` = '1', division = '1' WHERE steamid64 = %s AND character_id = %s",
		sql.SQLStr(sid64), sql.SQLStr(uid)))
	if LZY_ResetSkillsForCharacter then
		LZY_ResetSkillsForCharacter(sid64, uid, true)
	end

	-- Déjà dans le hub : rafraîchir la liste pour que le slot affiche le recreate.
	if IsValid(live) and live.InCharacterMenu and live.GetCharactersList then
		live:GetCharactersList(function(charactersList)
			if not IsValid(live) then return end
			live.charactersList = charactersList
			net.Start("EVO:Client:CharacterSelection:Open")
			net.WriteTable(charactersList or {})
			net.Send(live)
		end)
	end

	if EVO_StaffLog and IsValid(admin) then
		EVO_StaffLog(admin, "rp.ck", sid64, "full " .. nom .. " (perso " .. uid .. ", hors-ligne)")
	end
	return true, nom
end

local function nomDeRow(r)
	local n = string.Trim((tostring(r.firstname or "") .. " " .. tostring(r.lastname or "")))
	if n == "" then n = "uid " .. tostring(r.unique_id) end
	return n
end

local function fmtRow(r)
	return nomDeRow(r) .. " (uid " .. tostring(r.unique_id) .. ")"
end

local function toSid64(s)
	s = string.Trim(tostring(s or ""))
	if s == "" then return nil end
	if sam.is_steamid64 and sam.is_steamid64(s) then return s end
	if sam.is_steamid and sam.is_steamid(s) then return util.SteamIDTo64(s) end
	return nil
end

-- "STEAM_0:0:1 Ichigo Kurosaki" -> steamid + filtre perso. Sinon spec brute.
local function parseSpec(spec)
	spec = string.Trim(tostring(spec or ""))
	local first, rest = string.match(spec, "^(%S+)%s+(.+)$")
	if first and toSid64(first) then
		return first, string.Trim(rest)
	end
	return spec, nil
end

local function pickRows(rows, charHint)
	if not istable(rows) or #rows == 0 then return nil, {} end
	charHint = string.Trim(string.lower(tostring(charHint or "")))
	if #rows == 1 and charHint == "" then return rows[1], rows end
	if charHint == "" then return nil, rows end
	local exact, partial = {}, {}
	for _, r in ipairs(rows) do
		local nom = string.lower(nomDeRow(r))
		local uid = string.lower(tostring(r.unique_id or ""))
		if uid == charHint or nom == charHint then
			exact[#exact + 1] = r
		elseif string.find(nom, charHint, 1, true) then
			partial[#partial + 1] = r
		end
	end
	if #exact == 1 then return exact[1], rows end
	if #exact > 1 then return nil, exact end
	if #partial == 1 then return partial[1], rows end
	if #partial > 1 then return nil, partial end
	return nil, rows
end

local function tellRows(ply, prefix, rows)
	if not IsValid(ply) then return end
	ply:sam_send_message(prefix)
	for i = 1, math.min(#rows, 12) do
		local r = rows[i]
		ply:sam_send_message("  • " .. fmtRow(r) .. "  " .. tostring(r.steamid64 or ""))
	end
end

local function finishCk(ply, sid64, uid, nom)
	local okArm, errOrPending, n = EVO_CK_ArmConfirmId(ply, sid64, uid, nom)
	if not okArm then
		if errOrPending == "pending" then
			if IsValid(ply) then
				ply:sam_send_message("CK sur " .. tostring(n) .. " : grade 1, sorts effacés, clan quitté, shikai et bankai verrouillés (niveaux d'amélioration conservés), recreate identité/apparence (changement de faction possible). Level/inventaire/quêtes CONSERVÉS.")
				ply:sam_send_message("Relance « ck » sur la même cible dans les " .. DELAI_CONFIRM .. " s pour confirmer.")
			end
		elseif IsValid(ply) then
			ply:sam_send_message(tostring(errOrPending or "Impossible."))
		end
		return
	end
	local ok, msg = EVO_ApplyCharacterKillById(ply, sid64, uid, n)
	if not IsValid(ply) then return end
	if ok then
		local live = player.GetBySteamID64(tostring(sid64))
		local suite = IsValid(live) and "Il doit recréer nom / apparence / genre."
			or "Il devra recréer nom / apparence / genre à sa prochaine connexion."
		ply:sam_send_message("CK appliqué à " .. tostring(msg) .. ". " .. suite)
	else
		ply:sam_send_message(tostring(msg or "Échec CK."))
	end
end

local function resolveAndCk(ply, spec)
	local who, charHint = parseSpec(spec)
	local sid64 = toSid64(who)

	if sid64 then
		local live = player.GetBySteamID64(sid64)
		if IsValid(live) and (not charHint or charHint == "") then
			local uid = uidDe(live)
			if uid then
				finishCk(ply, sid64, uid, nomRp(live))
				return
			end
		end
		MUGEN.Query(string.format(
			"SELECT steamid64, unique_id, firstname, lastname FROM characters WHERE steamid64 = %s ORDER BY unique_id DESC",
			sql.SQLStr(sid64)
		), function(rows)
			if isstring(rows) then
				if IsValid(ply) then ply:sam_send_message("Erreur BDD.") end
				return
			end
			rows = istable(rows) and rows or {}
			local picked, pool = pickRows(rows, charHint)
			if not picked then
				if #rows == 0 then
					if IsValid(ply) then ply:sam_send_message("Aucun personnage pour " .. sid64 .. ".") end
				else
					tellRows(ply, "CK : plusieurs personnages. Relance avec le nom RP exact (ex : ck STEAM_0:0:xxx Prénom Nom) :", pool)
				end
				return
			end
			finishCk(ply, tostring(picked.steamid64), tostring(picked.unique_id), nomDeRow(picked))
		end)
		return
	end

	local q = string.gsub(who, "[%%_\\]", "")
	q = string.gsub(q, "%s+", " ")
	if #q < 2 then
		if IsValid(ply) then ply:sam_send_message("Donne un SteamID ou un nom RP (au moins 2 caractères).") end
		return
	end
	local like, exact = sql.SQLStr("%" .. q .. "%"), sql.SQLStr(q)
	MUGEN.Query(string.format(
		"SELECT steamid64, unique_id, firstname, lastname FROM characters"
		.. " WHERE unique_id = %s OR CONCAT(TRIM(firstname), ' ', TRIM(COALESCE(lastname, ''))) LIKE %s OR firstname LIKE %s"
		.. " ORDER BY (CONCAT(TRIM(firstname), ' ', TRIM(COALESCE(lastname, ''))) = %s) DESC, unique_id DESC LIMIT 20",
		sql.SQLStr(q), like, like, exact
	), function(rows)
		if isstring(rows) then
			if IsValid(ply) then ply:sam_send_message("Erreur BDD.") end
			return
		end
		rows = istable(rows) and rows or {}
		local picked, pool = pickRows(rows, q)
		if not picked then
			if #rows == 0 then
				if IsValid(ply) then ply:sam_send_message("Aucun personnage « " .. q .. " ».") end
			else
				tellRows(ply, "CK : plusieurs correspondances. Relance avec le nom exact :", pool)
			end
			return
		end
		finishCk(ply, tostring(picked.steamid64), tostring(picked.unique_id), nomDeRow(picked))
	end)
end

-- ════════════════════════════════════════════════════════════════════════════
--  rename_identity — ancien CK (nom seulement).
-- ════════════════════════════════════════════════════════════════════════════
command.new("rename_identity")
	:SetPermission("rename_identity", "superadmin")
	:AddArg("player")
	:AddArg("text", { hint = "nouvelle identité (Prénom Nom)" })
	:Help("Rename identité : change le NOM du personnage seulement (ancien !ck). Garde grade, niveau, sorts. Superadmin.")
	:OnExecute(function(ply, targets, fullname)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then ply:sam_send_message("Base de données indisponible (MUGEN).") end
			return
		end

		local firstname, lastname = string.match(string.Trim(tostring(fullname or "")), "^(%S+)%s+(.+)$")
		if not firstname then
			if IsValid(ply) then ply:sam_send_message("Donne un PRÉNOM et un NOM séparés par une espace (ex : Ichigo Kurosaki).") end
			return
		end
		firstname, lastname = cleanName(firstname), cleanName(lastname)
		if firstname == "" or lastname == "" then
			if IsValid(ply) then ply:sam_send_message("Nom invalide.") end
			return
		end
		if EVO_WordFilter and EVO_WordFilter.Contains
			and (EVO_WordFilter.Contains(firstname) or EVO_WordFilter.Contains(lastname)) then
			if IsValid(ply) then ply:sam_send_message("Nom refusé (filtre de mots).") end
			return
		end

		local complet = firstname .. " " .. lastname
		for _, target in ipairs(targets) do
			if IsValid(target) then
				local uid = uidDe(target)
				if not uid then
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " n'a aucun personnage chargé.") end
				else
					local avant = nomRp(target)
					MUGEN.Query(string.format(
						"UPDATE characters SET firstname = %s, lastname = %s WHERE unique_id = %s AND steamid64 = %s",
						sql.SQLStr(firstname), sql.SQLStr(lastname), sql.SQLStr(uid), sql.SQLStr(target:SteamID64())))
					target:SetEvoNWString("Nickname", complet)

					if EVO_StaffLog then EVO_StaffLog(ply, "rp.rename_identity", target, avant .. " -> " .. complet) end
					if IsValid(ply) then ply:sam_send_message("Identité : " .. avant .. " est désormais " .. complet .. ".") end
					if target ~= ply then
						target:sam_send_message("Ton personnage change d'identité. Tu t'appelles désormais " .. complet .. ".")
					end
				end
			end
		end
	end)
:End()

-- Cible CK : joueur connecté (liste SAM) OU SteamID / nom RP hors-ligne.
command.new_argument("ck_target")
	:OnExecute(function(arg, input, ply, cmd, result, i)
		if input == nil or input == "" then
			if IsValid(ply) then
				ply:sam_send_message("Choisis un joueur, ou entre un SteamID / nom RP.")
			end
			return false
		end
		input = string.Trim(tostring(input))

		local function takeOnline(target)
			if not IsValid(target) or not target:IsPlayer() then return false end
			if target.sam_get_nwvar and not target:sam_get_nwvar("is_authed") then return false end
			if IsValid(ply) and not sam.isconsole(ply) and ply.CanTarget and not ply:CanTarget(target) then
				ply:sam_send_message("cant_target_player", { S = target:Name() })
				return false
			end
			result[i] = { online = target }
			return true
		end

		if input == "^" then
			return takeOnline(ply)
		end
		if input == "@" and IsValid(ply) and not sam.isconsole(ply) then
			if takeOnline(ply:GetEyeTrace().Entity) then return end
			if IsValid(ply) then ply:sam_send_message("cant_find_target", { S = input }) end
			return false
		end
		if input:sub(1, 1) == "#" then
			local idx = tonumber(string.Trim(input:sub(2)))
			local ent = idx and Entity(idx)
			if takeOnline(ent) then return end
			if not (IsValid(ent) and ent:IsPlayer()) and IsValid(ply) then
				ply:sam_send_message("cant_find_target", { S = input })
			end
			return false
		end

		local sidOnly, charHint = parseSpec(input)
		local sid64 = toSid64(sidOnly)
		if sid64 then
			local live = player.GetBySteamID64(sid64)
			if IsValid(live) then
				if not charHint or charHint == "" then
					return takeOnline(live)
				end
				if IsValid(ply) and not sam.isconsole(ply) and ply.CanTarget and not ply:CanTarget(live) then
					ply:sam_send_message("cant_target_player", { S = live:Name() })
					return false
				end
			end
			result[i] = { spec = input }
			return
		end
		local needle = input
		if needle:sub(1, 1) == "%" and #needle > 1 then
			needle = needle:sub(2)
		end
		local found = sam.player.find_by_name(needle)
		if IsValid(found) then
			return takeOnline(found)
		elseif sam.istable(found) then
			if IsValid(ply) then ply:sam_send_message("found_multi_players", { T = found }) end
			return false
		end

		result[i] = { spec = input }
	end)
	:Menu(function(set_result, body, buttons, argument, childs)
		local selectedPlayer, typed = nil, ""
		local function emit()
			if typed ~= "" then
				set_result(typed)
			elseif selectedPlayer then
				set_result(selectedPlayer)
			else
				set_result(nil)
			end
		end

		local playerArg = sam.command.get_arguments()["player"]
		if playerArg and playerArg.menu then
			playerArg.menu(function(v)
				selectedPlayer = (isstring(v) and v ~= "") and v or nil
				emit()
			end, body, buttons, { single_target = true, name = "player" }, childs)
		end

		local entry = buttons:Add("SAM.TextEntry")
		entry:SetTall(25)
		entry:SetUpdateOnType(true)
		entry:SetPlaceholder("hors-ligne : SteamID ou Prénom Nom")
		entry:SetCheck(function(text)
			typed = string.Trim(tostring(text or ""))
			emit()
			return true
		end)
		return entry
	end)
:End()

-- ════════════════════════════════════════════════════════════════════════════
--  CK — Character Kill complet (double confirmation). Online + hors-ligne.
-- ════════════════════════════════════════════════════════════════════════════
command.new("ck")
	:SetPermission("ck", "superadmin")
	:AddArg("ck_target")
	:GetRestArgs()
	:Help("CK : Character Kill (grade 1, aucune division, sorts effacés, shikai et bankai verrouillés mais niveaux d'amélioration conservés, recreate nom/esthétique/genre). Level, inventaire, quêtes CONSERVÉS. Joueur connecté OU SteamID / nom RP hors-ligne. À confirmer en relançant. Superadmin.")
	:OnExecute(function(ply, target)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then ply:sam_send_message("Base de données indisponible (MUGEN).") end
			return
		end
		if not istable(target) then
			if IsValid(ply) then ply:sam_send_message("CK : cible invalide.") end
			return
		end

		if IsValid(target.online) then
			local uid = uidDe(target.online)
			if not uid then
				if IsValid(ply) then ply:sam_send_message(target.online:Nick() .. " n'a aucun personnage chargé.") end
				return
			end
			finishCk(ply, target.online:SteamID64(), uid, nomRp(target.online))
			return
		end

		if isstring(target.spec) and target.spec ~= "" then
			resolveAndCk(ply, target.spec)
			return
		end

		if IsValid(ply) then ply:sam_send_message("CK : une SEULE cible (joueur, SteamID ou nom RP).") end
	end)
:End()

-- ════════════════════════════════════════════════════════════════════════════
--  RPK — mort RP. Irréversible : confirmation obligatoire.
-- ════════════════════════════════════════════════════════════════════════════
local enAttente = {} -- steamid64 de l'admin -> { cible = steamid64, uid = ..., jusqua = ... }

local SQL_VERROUS = "shikai_unlocked = 0, bankai_unlocked = 0, hollow_mask_unlocked = 0, liberation_spi_unlocked = 0, portal_unlocked = 0"

local function appliquerRpk(admin, target)
	local uid = uidDe(target)
	local sid = target:SteamID64()
	local nom = nomRp(target)

	MUGEN.Query(string.format(
		"UPDATE characters SET level = 1, exp = 0 WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	target:SetEvoNWInt("Level", 1)
	target:SetEvoNWInt("Exp", 0)

	MUGEN.Query(string.format(
		"UPDATE characters SET " .. SQL_VERROUS .. " WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	MUGEN.Query(string.format(
		"UPDATE characters SET katana_name = '', shikai_word = '' WHERE unique_id = %s AND steamid64 = %s",
		sql.SQLStr(uid), sql.SQLStr(sid)))
	target:SetEvoNWBool("EVO_ShikaiUnlocked", false)
	target:SetEvoNWBool("EVO_BankaiUnlocked", false)
	target:SetEvoNWBool("EVO_HollowMaskUnlocked", false)
	target:SetEvoNWBool("EVO_LiberationSpiUnlocked", false)
	target:SetEvoNWBool("EVO_PortalUnlocked", false)
	RetirerParchemins(sid, uid, target)

	local fait = false
	local function finir()
		if fait or not IsValid(target) then return end
		fait = true
		if LZY_ResetSkillsForCharacter then
			LZY_ResetSkillsForCharacter(sid, uid, true) -- true = total, rien d'épargné
		end
		target:sam_send_message("RPK : ton personnage est mort. Grade 1, niveau 1, tout ce qu'il avait appris est perdu. Tes coins et tes achats boutique sont intacts.")
	end

	if target.SetRank then
		target:SetRank(1, finir)
		timer.Simple(2, finir)
	else
		finir()
	end

	if EVO_StaffLog and IsValid(admin) then
		EVO_StaffLog(admin, "rp.rpk", target, nom .. " (perso " .. tostring(uid) .. ")")
	end
	return nom
end

command.new("rpk")
	:SetPermission("rpk", "superadmin")
	:AddArg("player")
	:Help("RPK : mort RP du personnage (grade 1, niveau 1, apprentissages perdus). Coins, grades payants et achats boutique CONSERVÉS. À confirmer en relançant la commande. Superadmin.")
	:OnExecute(function(ply, targets)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then ply:sam_send_message("Base de données indisponible (MUGEN).") end
			return
		end

		if #targets ~= 1 then
			if IsValid(ply) then ply:sam_send_message("RPK : une SEULE cible à la fois (jamais @all ni un groupe).") end
			return
		end

		local target = targets[1]
		if not IsValid(target) then return end
		local uid = uidDe(target)
		if not uid then
			if IsValid(ply) then ply:sam_send_message(target:Nick() .. " n'a aucun personnage chargé : rien à tuer.") end
			return
		end

		local cleAdmin = IsValid(ply) and ply:SteamID64() or "console"
		local att = enAttente[cleAdmin]
		local nom = nomRp(target)

		if not (att and att.cible == target:SteamID64() and att.uid == uid and CurTime() < att.jusqua) then
			enAttente[cleAdmin] = { cible = target:SteamID64(), uid = uid, jusqua = CurTime() + DELAI_CONFIRM }
			if IsValid(ply) then
				ply:sam_send_message("RPK sur " .. nom .. " : grade 1, niveau 1, apprentissages effacés. Coins et achats CONSERVÉS.")
				ply:sam_send_message("Relance « rpk » sur la même cible dans les " .. DELAI_CONFIRM .. " s pour confirmer.")
			end
			return
		end

		enAttente[cleAdmin] = nil
		appliquerRpk(ply, target)
		if IsValid(ply) then ply:sam_send_message("RPK appliqué à " .. nom .. ". Coins, grades payants et achats boutique intacts.") end
	end)
:End()
