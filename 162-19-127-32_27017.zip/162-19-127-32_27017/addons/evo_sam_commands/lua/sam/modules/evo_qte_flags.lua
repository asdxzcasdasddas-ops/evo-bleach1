-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_qte_flags.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : qteflags
-- Consulte les flags anti-cheat QTE (réactions suspectes). Superadmin.
-- Usage : !qteflags              → liste tous les flags de la session
--         !qteflags <joueur>    → détail d'un joueur (flag + histo live)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - EVO")

local function fmtMs(nSec)
	return string.format("%.0fms", (tonumber(nSec) or 0) * 1000)
end

local function fmtFlag(f)
	return string.format(
		"%s (%s) | median=%s mean=%s n=%d | last=%s | %s",
		f.name or "?",
		f.steamid or f.steamid64 or "?",
		fmtMs(f.median),
		fmtMs(f.mean),
		f.samples or 0,
		fmtMs(f.lastReact),
		f.reason or "?"
	)
end

local function findPlayer(sInput)
	if not sInput or sInput == "" then return nil end
	sInput = string.Trim(sInput)

	if sam.is_steamid and sam.is_steamid(sInput) then
		return player.GetBySteamID(sInput)
	end
	if sam.is_steamid64 and sam.is_steamid64(sInput) then
		return player.GetBySteamID64(sInput)
	end

	sInput = string.lower(sInput)
	local tMatch = nil
	for _, ply in ipairs(player.GetAll()) do
		if string.find(string.lower(ply:Nick()), sInput, 1, true) then
			if tMatch then return nil end -- ambigu
			tMatch = ply
		end
	end
	return tMatch
end

local function liveStats(ply)
	if not IsValid(ply) then return nil end
	local sID = ply:SteamID64()
	if not sID or not NCM_ENTRAINEMENT or not NCM_ENTRAINEMENT.GetQTEReactHistory then return nil end
	local tHist = NCM_ENTRAINEMENT.GetQTEReactHistory(sID)
	if not tHist or #tHist == 0 then return nil end

	local nSum, nMin, nMax = 0, tHist[1], tHist[1]
	for i = 1, #tHist do
		local v = tHist[i]
		nSum = nSum + v
		if v < nMin then nMin = v end
		if v > nMax then nMax = v end
	end

	local tSorted = {}
	for i = 1, #tHist do tSorted[i] = tHist[i] end
	table.sort(tSorted)
	local n = #tSorted
	local nMed
	if n % 2 == 1 then
		nMed = tSorted[math.ceil(n / 2)]
	else
		nMed = (tSorted[n / 2] + tSorted[n / 2 + 1]) / 2
	end

	return {
		samples = n,
		mean = nSum / n,
		median = nMed,
		min = nMin,
		max = nMax,
	}
end

command.new("qteflags")
	:Aliases("qteflag", "trainingflags")

	:SetPermission("qteflags", "superadmin")

	:AddArg("text", { hint = "joueur/steamid", optional = true })

	:Help("Consulte les flags anti-cheat QTE (réactions trop rapides). Sans argument : liste tous les flags.")

	:OnExecute(function(ply, sTarget)
		if not (NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.GetQTEFlags) then
			sam.player.send_message(ply, "Système QTE indisponible.", {})
			return
		end

		-- Détail d'un joueur (flag + histo live si online)
		if sTarget and sTarget ~= "" then
			local t = findPlayer(sTarget)
			if not IsValid(t) then
				-- Joueur offline : chercher un flag par steamid / nick mémorisé
				local tFlags = NCM_ENTRAINEMENT.GetQTEFlags()
				local sNeedle = string.lower(string.Trim(sTarget))
				local fOffline = nil
				for _, f in pairs(tFlags) do
					if (f.steamid and string.lower(f.steamid) == sNeedle)
						or (f.steamid64 and f.steamid64 == sTarget)
						or (f.name and string.find(string.lower(f.name), sNeedle, 1, true))
					then
						fOffline = f
						break
					end
				end
				if fOffline then
					sam.player.send_message(ply, "[QTE-AC] FLAGGÉ (offline) : " .. fmtFlag(fOffline), {})
				else
					sam.player.send_message(ply, "[QTE-AC] Joueur introuvable : " .. sTarget, {})
				end
				return
			end

			local sID = t:SteamID64()
			local f = sID and NCM_ENTRAINEMENT.GetQTEFlag(sID) or nil
			local live = liveStats(t)

			if f then
				sam.player.send_message(ply, "[QTE-AC] FLAGGÉ : " .. fmtFlag(f), {})
			else
				sam.player.send_message(ply, "[QTE-AC] " .. t:Nick() .. " : aucun flag.", {})
			end

			if live then
				sam.player.send_message(ply, string.format(
					"[QTE-AC] Live : n=%d median=%s mean=%s min=%s max=%s",
					live.samples, fmtMs(live.median), fmtMs(live.mean), fmtMs(live.min), fmtMs(live.max)
				), {})
			else
				sam.player.send_message(ply, "[QTE-AC] Aucune réaction QTE enregistrée cette session.", {})
			end
			return
		end

		-- Liste globale
		local tFlags = NCM_ENTRAINEMENT.GetQTEFlags()
		local tList = {}
		for _, f in pairs(tFlags) do
			tList[#tList + 1] = f
		end
		table.sort(tList, function(a, b)
			return (a.flaggedAt or 0) > (b.flaggedAt or 0)
		end)

		if #tList == 0 then
			sam.player.send_message(ply, "[QTE-AC] Aucun flag cette session.", {})
			return
		end

		sam.player.send_message(ply, "[QTE-AC] " .. #tList .. " flag(s) :", {})
		for i = 1, #tList do
			sam.player.send_message(ply, "  • " .. fmtFlag(tList[i]), {})
		end
	end)
:End()
