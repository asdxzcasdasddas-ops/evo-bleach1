-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_give_argent_online.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : give_argent_online (superadmin)
-- Donne de l'argent (¥) aux joueurs actuellement connectés (personnage chargé).
-- Persisté comme give_argent : UPDATE relatif characters.money + resync NWInt.
-- Usage : !give_argent_online <quantité> [message]
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Argent")

command.new("give_argent_online")
	:Aliases("giveargentonline", "argentonline", "yenonline")

	:SetPermission("give_argent_online", "superadmin")

	:AddArg("number", { hint = "quantité (¥)", min = 1, round = true })
	:AddArg("text", { hint = "message popup (optionnel)", optional = true, default = "" })
	:GetRestArgs()

	:Help("Donne de l'argent (¥) à tous les joueurs actuellement connectés (personnage chargé).")

	:OnExecute(function(ply, amount, msg)
		amount = math.floor(tonumber(amount) or 0)
		if amount < 1 then
			if IsValid(ply) then
				ply:sam_send_message("Quantité invalide.")
			end
			return
		end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then
				ply:sam_send_message("Base indisponible.")
			else
				print("[SAM] give_argent_online : base indisponible.")
			end
			return
		end

		msg = string.sub(string.Trim(tostring(msg or ""):gsub("[%c]", " ")), 1, 200)
		local notif = msg ~= "" and ("Vous avez reçu " .. amount .. " ¥\n" .. msg)
			or ("[ADMIN] Vous avez reçu " .. amount .. "¥.")

		local delivered = 0
		local skipped = 0

		for _, target in ipairs(player.GetAll()) do
			if not IsValid(target) or not target:IsPlayer() or target:IsBot() then
				continue
			end

			local uid = target.GetUniqueID and tostring(target:GetUniqueID() or "") or ""
			if uid == "" or uid == "none" then
				skipped = skipped + 1
				continue
			end

			local sid64 = target:SteamID64()
			MUGEN.Query(string.format(
				"UPDATE characters SET money = money + %d WHERE steamid64 = %s AND unique_id = %s",
				amount, sql.SQLStr(sid64), sql.SQLStr(uid)
			), function()
				if not IsValid(target) then return end
				target:SetEvoNWInt("Money", target:GetEvoNWInt("Money", 0) + amount)
				if target.OpenPopup then
					target:OpenPopup(notif, "success")
				elseif target.Notif then
					target:Notif(0, 4, notif)
				end
			end)
			delivered = delivered + 1
		end

		local info = string.format(
			"Argent online : +%d ¥ — %d joueur(s) crédité(s)%s.",
			amount, delivered,
			skipped > 0 and (", " .. skipped .. " sans personnage chargé") or ""
		)
		if IsValid(ply) then
			ply:sam_send_message(info)
		else
			print("[SAM] " .. info)
		end

		sam.player.send_message(nil, "{A} a donné " .. tostring(amount) .. " ¥ aux joueurs connectés (" .. tostring(delivered) .. ")", {
			A = ply,
		})
	end)
:End()
