-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_setlevel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commandes SAM custom : setlevel
-- Chargé automatiquement par SAM (sam/autorun/sam.lua inclut tous les
-- sam/modules/*.lua trouvés dans le search path LUA, tous addons confondus).
-- Usage : !setlevel <joueur> <niveau>  (ou via le menu SAM, catégorie Utility)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("setlevel")
	:Aliases("setlvl")

	:SetPermission("setlevel", "superadmin")

	:AddArg("player")
	:AddArg("number", { hint = "niveau", round = true, min = 1, max = 299 })

	:Help("Définit le niveau du personnage d'un joueur (les points de compétence des niveaux gagnés sont crédités).")

	:OnExecute(function(ply, targets, level)
		-- SetLevel (gamemode, sv_level.lua) refuse lvl >= MAX_LEVEL -> on borne à MAX_LEVEL - 1.
		local maxLvl = (MUGEN and MUGEN.Level and MUGEN.Level.LEVELING_CONFIG
			and MUGEN.Level.LEVELING_CONFIG.MAX_LEVEL) or 300
		level = math.Clamp(math.floor(level), 1, maxLvl - 1)

		for i = 1, #targets do
			local t = targets[i]
			-- Il faut un PERSONNAGE chargé (SetLevel écrit characters par unique_id).
			if IsValid(t) and t.SetLevel and t.GetUniqueID and t:GetUniqueID() then
				t:SetLevel(level)
			end
		end

		sam.player.send_message(nil, "{A} a défini le niveau de {T} à {V}", {
			A = ply, T = targets, V = level,
		})
	end)
:End()
