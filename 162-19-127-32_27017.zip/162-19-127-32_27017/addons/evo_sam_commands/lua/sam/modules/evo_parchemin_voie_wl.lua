-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_parchemin_voie_wl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : parchemin_voie_wl (superadmin). WHITELIST des comptes
-- autorisés à DONNER les parchemins de voie (katana/hakuda) via le menu de don
-- du PNJ des techniques — droit réservé aux superadmins sinon (09/01).
-- Stockage : clé evo_shared_data « evo_parch_voie_wl » sur le COMPTE (MySQL
-- partagée -> vaut sur les deux serveurs, survit aux reboots). Le donneur doit
-- toujours remplir les conditions du menu de don (grade professeur 10+, même
-- faction que la cible) : la whitelist ne débloque QUE les parchemins de voie.
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command
command.set_category("Commandes - EVO")

local WL_KEY = "evo_parch_voie_wl"

local _actions = {
	"AUTORISER à donner les parchemins de voie [on]",
	"RETIRER l'autorisation [off]",
	"VOIR l'état [voir]",
}

local function extraireAction(input)
	if not isstring(input) then return tostring(input) end
	return string.match(input, "%[([^%[%]]+)%]%s*$") or input
end

command.new("parchemin_voie_wl")
	:Aliases("parcheminvoiewl", "wl_parchemin_voie")

	:SetPermission("parchemin_voie_wl", "superadmin")

	:AddArg("player")
	:AddArg("dropdown", { hint = "action", options = _actions })

	:Help("Whitelist des comptes autorisés à donner les parchemins de voie (katana/hakuda) au menu de don du PNJ des techniques. Partagée entre serveurs, persistante. Superadmin.")

	:OnExecute(function(ply, targets, sInput)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		local sAction = extraireAction(sInput)
		if not (EVO_SharedData and EVO_SharedData.Set) then
			if IsValid(ply) then ply:sam_send_message("evo_shared_data indisponible.") end
			return
		end

		for _, target in ipairs(targets) do
			if IsValid(target) then
				-- Donnée de compte pas encore chargée : écrire écraserait à l'aveugle.
				if not EVO_SharedData.IsReady(target) then
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : données de compte pas encore chargées, réessaie dans quelques secondes.") end
					continue
				end
				if sAction == "on" then
					EVO_SharedData.Set(target, WL_KEY, "1")
					MUGEN.Notify(target, "Tu peux désormais donner les parchemins de voie (katana et hakuda) au menu de don du Maître des Techniques.", NOTIFY_GENERIC, 6)
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : AUTORISÉ à donner les parchemins de voie.") end
					if EVO_StaffLog then EVO_StaffLog(ply, "parchemin.voie_wl_on", target, "") end
				elseif sAction == "off" then
					EVO_SharedData.Delete(target, WL_KEY)
					MUGEN.Notify(target, "Tu ne peux plus donner les parchemins de voie.", NOTIFY_GENERIC, 5)
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : autorisation RETIRÉE.") end
					if EVO_StaffLog then EVO_StaffLog(ply, "parchemin.voie_wl_off", target, "") end
				elseif sAction == "voir" then
					local bWL = EVO_SharedData.Get(target, WL_KEY, "0") == "1"
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : " .. (bWL and "SUR la whitelist des parchemins de voie." or "pas sur la whitelist.")) end
				else
					if IsValid(ply) then ply:sam_send_message("Action inconnue : " .. tostring(sAction)) end
				end
			end
		end
	end)
:End()
