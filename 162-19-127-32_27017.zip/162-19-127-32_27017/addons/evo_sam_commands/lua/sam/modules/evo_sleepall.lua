-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_sleepall.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : evo_sleepall (superadmin)
-- Somnifère (clignement fatigué) + titre HUD sur TOUS les joueurs connectés.
-- Usage : !evo_sleepall <titre> [durée]
-- Console serveur (pas les joueurs) : evo_sleepall <titre> [durée]
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Événements")

command.new("evo_sleepall")
	:Aliases("sleepall")

	:SetPermission("evo_sleepall", "superadmin")

	:AddArg("text", { hint = "titre affiché" })
	:AddArg("number", { hint = "durée (s)", optional = true, default = 5, min = 1, max = 30 })

	:Help("Déclenche le somnifère (yeux fatigués) + un titre sur tous les joueurs connectés.")

	:OnExecute(function(ply, title, duration)
		if not EVO_SleepAll or not EVO_SleepAll.Run then
			ply:sam_send_message("EVO_SleepAll indisponible.")
			return
		end

		local n, err, dur, tit = EVO_SleepAll.Run(title, duration)
		if err then
			ply:sam_send_message(err)
			return
		end

		ply:sam_send_message(n .. " joueur(s) : somnifère " .. dur .. "s — « " .. tit .. " »")
	end)
:End()

command.new("evo_sleep")
	:Aliases("sleep")

	:SetPermission("evo_sleep", "superadmin")

	:AddArg("player", { single_target = true })
	:AddArg("text", { hint = "titre affiché" })
	:AddArg("number", { hint = "durée (s)", optional = true, default = 5, min = 1, max = 30 })

	:Help("Déclenche le somnifère (yeux fatigués) + un titre sur le joueur sélectionné.")

	:OnExecute(function(ply, targets, title, duration)
		if not EVO_SleepAll or not EVO_SleepAll.RunTarget then
			ply:sam_send_message("EVO_SleepAll indisponible.")
			return
		end

		local target = targets[1]
		local ok, err, dur, tit = EVO_SleepAll.RunTarget(target, title, duration)
		if not ok then
			ply:sam_send_message(err)
			return
		end

		ply:sam_send_message(target:Nick() .. " : somnifère " .. dur .. "s — « " .. tit .. " »")
	end)
:End()
