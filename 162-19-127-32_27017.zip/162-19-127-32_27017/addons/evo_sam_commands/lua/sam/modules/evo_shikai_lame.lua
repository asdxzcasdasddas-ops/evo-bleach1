-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_shikai_lame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- Commande SAM "shikailame" (09/25) : pose l'arme de Shikai d'un joueur (modèle pris à la
-- libération), au choix parmi tous les skins de katana et de poings. Même écriture que la
-- prise de lame de la Salle Blanche (R.PoserSkin) : par personnage et par voie.
local command = sam.command

command.set_category("Commandes - EVO")

-- Label "Nom (Katana|Poings[, Shikai]) [katana_id]" : l'id complet dans les crochets.
-- Refill en place + timers : les catalogues peuvent charger après ce module.
local _lameList = {}

local function RefreshLameList()
	for i = #_lameList, 1, -1 do _lameList[i] = nil end
	local tSources = {
		{ "katana_",   "Katana", KATANA_SKINS and KATANA_SKINS.List },
		{ "gauntlet_", "Poings", NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List },
	}
	for _, src in ipairs(tSources) do
		if istable(src[3]) then
			for id, def in pairs(src[3]) do
				if istable(def) and isstring(def.model) and def.model ~= "" then
					local sType = def.is_shikai and (src[2] .. ", Shikai") or src[2]
					_lameList[#_lameList + 1] = string.format("%s (%s) [%s%s]",
						tostring(def.name or id), sType, src[1], id)
				end
			end
		end
	end
	table.sort(_lameList)
end
RefreshLameList()
timer.Simple(2, RefreshLameList)
timer.Simple(10, RefreshLameList)

local function extraireID(input)
	if not isstring(input) then return tostring(input) end
	return string.match(input, "%[([^%[%]]+)%]%s*$") or input
end

local function defDe(sID)
	local sBrut = string.match(sID, "^katana_(.+)$")
	if sBrut then return KATANA_SKINS and KATANA_SKINS.List[sBrut], "katana" end
	sBrut = string.match(sID, "^gauntlet_(.+)$")
	if sBrut then return NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List[sBrut], "hakuda" end
	return nil
end

command.new("shikailame")
	:Aliases("shikai_lame", "armeshikai")

	:SetPermission("shikailame", "superadmin")

	:AddArg("player")
	:AddArg("dropdown", { hint = "arme (Nom (Type) [id])", options = _lameList })

	:Help("Pose l'arme de Shikai d'un joueur (modèle pris à la libération). Persiste sur le personnage. Superadmin.")

	:OnExecute(function(ply, targets, sInput)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		local R = EVO_BLANC and EVO_BLANC.Rituel
		if not (R and R.PoserSkin) then
			if IsValid(ply) then ply:sam_send_message("evo_blanc indisponible.") end
			return
		end

		local sID = extraireID(sInput)
		local def, sVoie = defDe(sID)
		if not istable(def) then
			if IsValid(ply) then ply:sam_send_message("Arme inconnue : " .. tostring(sID)) end
			return
		end
		local sNom = tostring(def.name or sID)

		for _, target in ipairs(targets) do
			if IsValid(target) then
				if target:GetEvoNWString("Character::Unique::ID", "none") == "none" then
					if IsValid(ply) then ply:sam_send_message(target:Nick() .. " n'a aucun personnage chargé.") end
				elseif R.PoserSkin(target, sID) then
					if EVO_StaffLog then EVO_StaffLog(ply, "rp.shikai_lame", target, sID) end
					if IsValid(ply) then
						ply:sam_send_message(string.format("Arme de Shikai de %s : %s.", target:Nick(), sNom))
						-- La lame d'une voie ne s'affiche que dans cette voie (katana / mains nues).
						if R.VoieDe and R.VoieDe(target) ~= sVoie then
							ply:sam_send_message("(" .. target:Nick() .. " n'est pas dans cette voie de combat : l'arme s'affichera au retour dans cette voie.)")
						end
						if not target:GetEvoNWBool("EVO_ShikaiUnlocked", false) then
							ply:sam_send_message("(" .. target:Nick() .. " n'a pas encore débloqué sa libération : l'arme est enregistrée mais ne se verra qu'après.)")
						end
					end
					if target ~= ply then
						target:sam_send_message("Ta lame de Shikai prend désormais la forme : " .. sNom .. ".")
					end
				elseif IsValid(ply) then
					ply:sam_send_message("Échec pour " .. target:Nick() .. ".")
				end
			end
		end
	end)
:End()
