-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_zonecapture.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- ============================================================================
-- SAM : Capture de Zone — force-start / stop (même schéma que la Bataille)
-- ============================================================================

local command = sam.command

command.set_category("Commandes - EVO")

command.new("zonecapture_start")
	:SetPermission("zonecapture_start", "superadmin")
	:Help("Démarre manuellement la Capture de Zone (arène Hueco Mundo).")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (ZoneCapture and ZoneCapture.ForceStart) then
			ply:sam_send_message("zonecapture indisponible (addon non chargé ?).")
			return
		end
		local ok, msg = ZoneCapture.ForceStart(ply)
		ply:sam_send_message(msg or (ok and "Capture de Zone démarrée." or "Échec du lancement."))
	end)
:End()

command.new("zonecapture_stop")
	:SetPermission("zonecapture_stop", "superadmin")
	:Help("Arrête / annule la Capture de Zone en cours (pas de rewards).")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (ZoneCapture and ZoneCapture.ForceStop) then
			ply:sam_send_message("zonecapture indisponible (addon non chargé ?).")
			return
		end
		local ok, msg = ZoneCapture.ForceStop(ply)
		ply:sam_send_message(msg or (ok and "Capture de Zone arrêtée." or "Échec de l'arrêt."))
	end)
:End()
