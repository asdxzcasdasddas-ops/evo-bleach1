-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_give_coins_all.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : give_coins_all (superadmin)
-- Donne des coins à TOUS les joueurs (comptes en BDD) avec un message popup.
-- Connectés : immédiat. Offline : pending, livré 1× à la prochaine connexion.
-- Usage : !give_coins_all <quantité> <message>
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Argent")

command.new("give_coins_all")
	:Aliases("givecoinsall", "coinsall")

	:SetPermission("give_coins_all", "superadmin")

	:AddArg("number", { hint = "quantité", min = 1, round = true })
	:AddArg("text", { hint = "message popup" })
	:GetRestArgs()

	:Help("Donne des coins à tous les joueurs (online immédiat, offline au prochain login, 1×). Message personnalisé dans la popup.")

	:OnExecute(function(ply, amount, msg)
		if not EVO_GiveCoinsAll or not EVO_GiveCoinsAll.Run then
			if IsValid(ply) then
				ply:sam_send_message("EVO_GiveCoinsAll indisponible.")
			end
			return
		end

		msg = tostring(msg or "")
		EVO_GiveCoinsAll.Run(amount, msg, function(ok, onlineDelivered, pendingTotal, err)
			if not ok then
				local fail = err or "Échec du don global."
				if IsValid(ply) then
					ply:sam_send_message(fail)
				else
					print("[SAM] give_coins_all : " .. fail)
				end
				return
			end

			local onlineN = tonumber(onlineDelivered) or 0
			local totalN = tonumber(pendingTotal) or 0
			local offlineN = math.max(0, totalN - onlineN)
			local info = string.format(
				"Coins all : +%d coins — %d online maintenant, %d offline au prochain login (%d comptes).",
				tonumber(amount) or 0, onlineN, offlineN, totalN
			)
			if IsValid(ply) then
				ply:sam_send_message(info)
			else
				print("[SAM] " .. info)
			end

			sam.player.send_message(nil, "{A} a donné " .. tostring(amount) .. " coins à tous (" .. tostring(onlineN) .. " online / " .. tostring(offlineN) .. " offline)", {
				A = ply,
			})
		end)
	end)
:End()
