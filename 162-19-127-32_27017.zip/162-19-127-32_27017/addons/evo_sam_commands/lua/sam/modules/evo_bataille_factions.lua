-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_bataille_factions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- ============================================================================
-- SAM : Bataille des Factions — stop SuperAdmin (lancement = menu C grade 10+)
-- ============================================================================

local command = sam.command

command.set_category("Commandes - EVO")

command.new("bataille_factions_stop")
	:SetPermission("bataille_factions_stop", "superadmin")
	:Help("Arrête / annule la Bataille des Factions en cours (pas de rewards).")
	:OnExecute(function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end
		if not (EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.ForceStop) then
			ply:sam_send_message("bataille des factions indisponible (addon non chargé ?).")
			return
		end
		local ok, msg = EVO_BATAILLE_FAC.ForceStop(ply)
		ply:sam_send_message(msg or (ok and "Bataille des Factions arrêtée." or "Échec de l'arrêt."))
	end)
:End()
