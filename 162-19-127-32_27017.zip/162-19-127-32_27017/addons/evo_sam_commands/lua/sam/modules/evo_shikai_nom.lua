-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_shikai_nom.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end

-- ============================================================================
-- EVO — Commande SAM "shikainom" (demande user 08/30) : change le NOM du
-- Zanpakutō d'un joueur — côté Hollow, le nom de sa Resurrección partielle,
-- c'est le même champ, seul le libellé affiché diffère selon la faction.
--
-- Apparaît dans "Commandes - EVO" du SAM menu : sélecteur de joueur + champ
-- texte. Persiste dans `characters.katana_name` (clé unique_id = NWString
-- "Character::Unique::ID") ET applique en direct via la NWString "KatanaName",
-- exactement comme le PNJ renommeur — rien de réinventé, le nom tient au
-- prochain chargement du personnage.
--
-- La règle de nom vient d'EVO_SHIKAI_UI.NameValid (source unique partagée avec
-- le menu de déblocage et le renommeur) et le filtre de mots reste appliqué :
-- un nom refusé aux joueurs n'a pas à passer par la porte de service.
--
-- Permission "superadmin" (politique EVO). Loggée par le hook SAM.RanCommand.
-- ============================================================================
local command = sam.command

command.set_category("Commandes - EVO")

-- Repli local si evo_shikai_ui n'est pas chargé — garder en phase avec
-- EVO_SHIKAI_UI.NameValid (sh_config.lua).
local function nomValide(s)
	if EVO_SHIKAI_UI and EVO_SHIKAI_UI.NameValid then return EVO_SHIKAI_UI.NameValid(s) end
	if #s < 2 or #s > 32 then return false end
	if not string.match(s, "^[%a '%-]+$") then return false end
	if not string.match(s, "%a") then return false end
	local _, nEspaces = string.gsub(s, " ", "")
	if nEspaces > 2 then return false end
	if string.find(s, "%-%-") or string.find(s, "''") then return false end
	return true
end

local function regleNom()
	if EVO_SHIKAI_UI and EVO_SHIKAI_UI.NameRule then return EVO_SHIKAI_UI.NameRule() end
	return "3 mots max, lettres uniquement (pas de chiffres ni symboles)"
end

-- "SHIKAI" ou "RESURRECCIÓN PARTIELLE" selon la faction de la CIBLE : les
-- messages staff parlent la langue du joueur concerné.
local function libelle(target)
	if EVO_SHIKAI_UI and EVO_SHIKAI_UI.GetLabel then
		local s = EVO_SHIKAI_UI.GetLabel("shikai", target:GetEvoNWString("FactionName", ""))
		if s and s ~= "" then return s end
	end
	return "Shikai"
end

local function uidDe(ply)
	local uid = ply:GetEvoNWString("Character::Unique::ID", "none")
	if uid == nil or uid == "" or uid == "none" then return nil end
	return uid
end

command.new("shikainom")
	:Aliases("nomshikai", "zanpakuto")

	:SetPermission("shikainom", "superadmin")

	:AddArg("player")
	:AddArg("text", { hint = "nouveau nom du Zanpakutō" })

	:Help("Change le nom du Zanpakutō (Resurrección partielle côté Hollow) d'un joueur. Persiste en BDD. Superadmin.")

	:OnExecute(function(ply, targets, sNom)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then ply:sam_send_message("Base de données indisponible (MUGEN).") end
			return
		end

		sNom = string.Trim(tostring(sNom or ""))
		sNom = string.gsub(sNom, "%s+", " ") -- espaces multiples : un seul séparateur
		if sNom == "" then
			if IsValid(ply) then ply:sam_send_message("Usage : shikainom <joueur> <nom>") end
			return
		end
		-- ⚠ La validation passe AVANT la requête : sql.SQLStr n'échappe PAS
		-- l'antislash (piège connu du projet). Le motif de nomValide n'accepte
		-- que lettres/espace/apostrophe/tiret, donc rien d'injectable ne survit.
		if not nomValide(sNom) then
			if IsValid(ply) then ply:sam_send_message("Nom invalide : " .. regleNom() .. ".") end
			return
		end
		if EVO_WordFilter and EVO_WordFilter.Contains and EVO_WordFilter.Contains(sNom) then
			if IsValid(ply) then ply:sam_send_message("Nom refusé (filtre de mots).") end
			return
		end

		for _, target in ipairs(targets) do
			if IsValid(target) then
				local uid = uidDe(target)
				if not uid then
					if IsValid(ply) then
						ply:sam_send_message(target:Nick() .. " n'a aucun personnage chargé.")
					end
				else
					local sAvant = target:GetEvoNWString("KatanaName", "")
					if sAvant == "" then sAvant = "(sans nom)" end
					local sLib = libelle(target)

					MUGEN.Query(string.format(
						"UPDATE characters SET katana_name = %s WHERE unique_id = %s AND steamid64 = %s",
						sql.SQLStr(sNom), sql.SQLStr(uid), sql.SQLStr(target:SteamID64())))
					target:SetEvoNWString("KatanaName", sNom)

					if EVO_StaffLog then
						EVO_StaffLog(ply, "rp.shikai_nom", target, sAvant .. " -> " .. sNom)
					end
					if IsValid(ply) then
						ply:sam_send_message(string.format("%s de %s : « %s » devient « %s ».",
							sLib, target:Nick(), sAvant, sNom))
						-- Le nom se voit à la libération : prévenir si elle n'est pas débloquée.
						if not target:GetEvoNWBool("EVO_ShikaiUnlocked", false) then
							ply:sam_send_message("(" .. target:Nick() .. " n'a pas encore débloqué sa libération : le nom est enregistré mais ne s'affichera qu'après.)")
						end
					end
					if target ~= ply then
						target:sam_send_message("Ta lame porte désormais le nom « " .. sNom .. " ».")
					end
				end
			end
		end
	end)
:End()
