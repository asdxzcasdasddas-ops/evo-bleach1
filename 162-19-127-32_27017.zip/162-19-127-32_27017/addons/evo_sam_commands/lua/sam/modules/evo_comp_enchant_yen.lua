-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_comp_enchant_yen.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : comp_enchant_yen / comp_enchant_yen_online (superadmin)
-- Dédommage 50 % du coût actuel des enchantements encore présents. 1× par perso.
-- Usage : !comp_enchant_yen            (tous les personnages)
--         !comp_enchant_yen_online     (connectés uniquement)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Argent")

local function report(ply, tag, ok, nCredited, nSkipped, totalYen, err, nFailed)
	if not ok then
		local fail = err or "Échec de la compensation gravure."
		if IsValid(ply) then
			ply:sam_send_message(fail)
		else
			print("[SAM] " .. tag .. " : " .. fail)
		end
		return false
	end

	nFailed = tonumber(nFailed) or 0
	local info = string.format(
		"Compensation gravure%s : +%s ¥ — %d crédité(s)%s%s.",
		tag == "comp_enchant_yen_online" and " (online)" or "",
		string.Comma(tonumber(totalYen) or 0),
		tonumber(nCredited) or 0,
		(tonumber(nSkipped) or 0) > 0 and (", " .. nSkipped .. " déjà compensé(s)") or "",
		nFailed > 0 and (", " .. nFailed .. " échec(s)") or ""
	)
	if IsValid(ply) then
		ply:sam_send_message(info)
	else
		print("[SAM] " .. info)
	end
	return true
end

command.new("comp_enchant_yen")
	:Aliases("compgravure", "enchantcomp", "refundgravure")

	:SetPermission("comp_enchant_yen", "superadmin")

	:Help("Compensation gravure : 50 % du coût actuel des enchantements présents (1× par personnage, y compris hors-ligne).")

	:OnExecute(function(ply)
		if not EVO_CompEnchantYen or not EVO_CompEnchantYen.Run then
			if IsValid(ply) then
				ply:sam_send_message("EVO_CompEnchantYen indisponible.")
			end
			return
		end

		EVO_CompEnchantYen.Run(function(ok, nCredited, nSkipped, totalYen, err, nFailed)
			if not report(ply, "comp_enchant_yen", ok, nCredited, nSkipped, totalYen, err, nFailed) then return end
			sam.player.send_message(nil, "{A} a compensé 50 % des yens de gravure (" .. tostring(nCredited) .. " perso(s), +" .. tostring(totalYen) .. " ¥)", {
				A = ply,
			})
		end)
	end)
:End()

command.new("comp_enchant_yen_online")
	:Aliases("compgravureonline", "enchantcomponline")

	:SetPermission("comp_enchant_yen_online", "superadmin")

	:Help("Compensation gravure (connectés uniquement) : 50 % du coût actuel des enchantements présents (1× par personnage).")

	:OnExecute(function(ply)
		if not EVO_CompEnchantYen or not EVO_CompEnchantYen.RunOnline then
			if IsValid(ply) then
				ply:sam_send_message("EVO_CompEnchantYen.RunOnline indisponible.")
			end
			return
		end

		EVO_CompEnchantYen.RunOnline(function(ok, nCredited, nSkipped, totalYen, err, nFailed)
			if not report(ply, "comp_enchant_yen_online", ok, nCredited, nSkipped, totalYen, err, nFailed) then return end
			sam.player.send_message(nil, "{A} a compensé 50 % des yens de gravure aux joueurs connectés (" .. tostring(nCredited) .. ", +" .. tostring(totalYen) .. " ¥)", {
				A = ply,
			})
		end)
	end)
:End()
