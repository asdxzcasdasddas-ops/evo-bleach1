-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_feux.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO - commandes SAM custom : feu
--
-- Poser des feux la ou l'on regarde, qui restent (base + cache, voir
-- evo_feux/sv_evo_feux.lua), et les retirer. Superadmin.
--
-- Usage :
--   !feu                      aide et nombre de feux sur la carte
--   !feu petit|moyen|grand|enorme|geant   pose un feu la ou tu vises (a moins de 95 m),
--                             sinon au sol sous toi (noclip, visee dans le ciel)
--   !feu grand sans           ... sans lueur ; !feu petit lueur : avec
--   !feu retirer              retire le feu le plus proche de ce que tu vises
--   !feu eteindre             eteint le plus proche, en douceur (feu de
--                             l'incendie compris)
--   !feu eteindre tout        eteint TOUS les feux d'un coup (trois secondes)
--   !feu eteindre 15          les eteint petit a petit sur 15 minutes
--   !feu liste                les feux de la carte, du plus proche au plus loin
--   !feu vider oui            eteint et oublie TOUS les feux de la carte
--   !feu sauver               enregistre les feux poses comme PLAN DE L'INCENDIE
--                             de la carte, puis les eteint : le Ciel en flammes
--                             les rallume peu a peu, dans l'ordre de pose
--   !feu plan                 repose le plan pour le retoucher (puis !feu sauver)
--   !feu plan effacer         supprime le plan de la carte
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("feu")
    :Aliases("feux", "fire")
    :SetPermission("feu", "superadmin")
    :AddArg("text", { hint = "petit|moyen|grand|enorme|geant, retirer, liste, vider, sauver, plan", optional = true, default = "" })
    :AddArg("text", { hint = "lueur|sans (ou 'oui' pour vider)", optional = true, default = "" })
    :Help("Pose un feu persistant la ou tu regardes, ou le retire. !feu liste, !feu vider oui.")
    :OnExecute(function(ply, sArg1, sArg2)
        if not SERVER then return end
        local F = EVO_FEUX
        if not (F and F.Ajouter) then
            sam.player.send_message(ply, "Module feux indisponible (addon evo_feux absent ?).")
            return
        end
        local a1 = string.lower(string.Trim(tostring(sArg1 or "")))
        local a2 = string.lower(string.Trim(tostring(sArg2 or "")))
        local liste = F.Liste()

        if a1 == "" or a1 == "aide" or a1 == "help" then
            sam.player.send_message(ply, #liste .. " feu(x) sur cette carte, " .. #F.Plan() .. " dans le plan de l'incendie. "
                .. "!feu petit|moyen|grand|enorme|geant [lueur|sans], !feu eteindre [tout|minutes], !feu liste, !feu vider oui, !feu sauver, !feu plan.")
            return
        end

        if a1 == "sauver" or a1 == "save" then
            local n = F.SauverPlan()
            if n == 0 then
                sam.player.send_message(ply, "Aucun feu pose sur la carte. Pose-les avec !feu, puis !feu sauver. (!feu plan effacer pour supprimer le plan.)")
                return
            end
            sam.player.send_message(nil, "{A} a enregistre le plan de l'incendie : {N} feu(x). Ils ont ete eteints et reviendront peu a peu avec le Ciel en flammes.", { A = ply, N = n })
            return
        end

        if a1 == "plan" then
            if a2 == "effacer" or a2 == "supprimer" then
                local n = F.EffacerPlan()
                sam.player.send_message(nil, "{A} a supprime le plan de l'incendie ({N} feu(x)).", { A = ply, N = n })
                return
            end
            if #F.Plan() == 0 then
                sam.player.send_message(ply, "Pas encore de plan sur cette carte : pose des feux avec !feu, puis !feu sauver.")
                return
            end
            local n = F.MontrerPlan(ply:SteamID())
            sam.player.send_message(ply, n .. " feu(x) du plan reposes. Retouche-les (!feu ..., !feu retirer), puis !feu sauver pour enregistrer.")
            return
        end

        if a1 == "liste" then
            if #liste == 0 then sam.player.send_message(ply, "Aucun feu sur cette carte.") return end
            local vMoi = ply:GetPos()
            local l = {}
            for _, f in ipairs(liste) do l[#l + 1] = f end
            table.sort(l, function(a, b) return a.pos:DistToSqr(vMoi) < b.pos:DistToSqr(vMoi) end)
            local lignes = {}
            for i = 1, math.min(#l, 15) do
                local f = l[i]
                lignes[#lignes + 1] = string.format("%s%s a %d m (%s)", f.taille, f.lueur and " + lueur" or "",
                    math.Round(f.pos:Distance(vMoi) / 52.5), IsValid(f.ent) and "allume" or "eteint")
            end
            if #l > 15 then lignes[#lignes + 1] = "... et " .. (#l - 15) .. " de plus" end
            sam.player.send_message(ply, #l .. " feu(x) :\n" .. table.concat(lignes, "\n"))
            return
        end

        if a1 == "vider" then
            if a2 ~= "oui" then
                sam.player.send_message(ply, "Ca eteint et oublie les " .. #liste .. " feux de la carte. Pour confirmer : !feu vider oui")
                return
            end
            local n = F.Vider()
            sam.player.send_message(nil, "{A} a eteint tous les feux de la carte ({N}).", { A = ply, N = n })
            return
        end

        if a1 == "eteindre" or a1 == "eteins" or a1 == "stop" then
            -- a2 vide : le plus proche. « tout » : tous d'un coup. Un nombre
            -- (ou « tout 15 », selon comment SAM coupe la ligne) : tous, sur
            -- ce nombre de minutes.
            local mots = string.Explode(" ", a2)
            local nMin = tonumber(mots[#mots])
            if a2 == "" then
                local tr = ply:GetEyeTrace()
                local sTaille = F.EteindreProche(tr.Hit and tr.HitPos or ply:GetPos()) or F.EteindreProche(ply:GetPos())
                if not sTaille then
                    sam.player.send_message(ply, "Aucun feu a moins de 5 m de ce que tu vises (ni de toi). !feu eteindre tout, ou !feu eteindre 15 pour tout eteindre sur 15 min.")
                    return
                end
                sam.player.send_message(nil, "{A} a eteint un feu {T}.", { A = ply, T = sTaille })
                return
            end
            if not nMin and mots[1] ~= "tout" then
                sam.player.send_message(ply, "!feu eteindre (le plus proche), !feu eteindre tout (d'un coup), !feu eteindre 15 (sur 15 minutes).")
                return
            end
            nMin = math.Clamp(nMin or 0, 0, 180)
            local n = F.EteindreTout(nMin)
            if n == 0 then
                sam.player.send_message(ply, "Aucun feu allume sur la carte.")
                return
            end
            if nMin > 0 then
                sam.player.send_message(nil, "{A} eteint l'incendie : {N} feu(x) s'eteignent petit a petit sur {M} min.", { A = ply, N = n, M = nMin })
            else
                sam.player.send_message(nil, "{A} a eteint les {N} feu(x) de la carte.", { A = ply, N = n })
            end
            return
        end

        if a1 == "retirer" or a1 == "enlever" then
            local tr = ply:GetEyeTrace()
            local f = F.Retirer(tr.Hit and tr.HitPos or ply:GetPos()) or F.Retirer(ply:GetPos())
            if not f then
                sam.player.send_message(ply, "Aucun feu a moins de 5 m de ce que tu vises (ni de toi).")
                return
            end
            sam.player.send_message(nil, "{A} a eteint un feu {T}.", { A = ply, T = f.taille })
            return
        end

        local T = F.Tailles[a1]
        if not T then
            sam.player.send_message(ply, "Taille inconnue : petit, moyen, grand, enorme ou geant. (!feu pour l'aide)")
            return
        end
        -- OU LE POSER. La ou l'on vise, si c'est une surface a moins de 95 m ;
        -- sinon AU SOL SOUS SOI. Refuser au-dela de 30 m laissait le staff sans
        -- rien (23/09/2026) : en noclip, ou en regardant l'horizon, la visee
        -- part dans le ciel et la commande ne posait rien, avec un message
        -- perdu dans le chat.
        local tr = ply:GetEyeTrace()
        local vPos, sOu
        if tr.Hit and not tr.HitSky and tr.HitPos:Distance(ply:GetPos()) <= 5000 then
            vPos, sOu = tr.HitPos + tr.HitNormal * 6, "la ou tu vises"
        else
            local bas = util.TraceLine({ start = ply:GetPos() + Vector(0, 0, 16), endpos = ply:GetPos() - Vector(0, 0, 20000),
                filter = ply, mask = MASK_SOLID })
            if not bas.Hit or bas.HitSky then
                sam.player.send_message(ply, "Aucun sol sous toi ni la ou tu vises : vise une surface a moins de 95 m.")
                return
            end
            vPos, sOu = bas.HitPos + Vector(0, 0, 4), "au sol sous toi"
        end
        local bLueur = nil
        if a2 == "lueur" or a2 == "glow" then bLueur = true end
        if a2 == "sans" or a2 == "noglow" then bLueur = false end

        local f, err = F.Ajouter(vPos, a1, bLueur, ply:SteamID())
        if not f then
            sam.player.send_message(ply, err or "Impossible.")
            return
        end
        sam.player.send_message(nil, "{A} a allume un feu {T}{L} {O} ({N} sur la carte).", {
            A = ply, T = a1, L = f.lueur and " avec lueur" or "", O = sOu, N = #F.Liste(),
        })
    end)
:End()
