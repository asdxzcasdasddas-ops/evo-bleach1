-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_espada_tenue.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO - commandes SAM custom : espadatenue
--
-- A QUOI CA SERT : choisir EN JEU quelle tenue (skin du modele d'Espada) va a
-- quel Ordre, sans repasser par le code. La correspondance vivait uniquement
-- dans LZY_CHARACTER_CONFIG.ESPADA_BODY.skinByOrdreNum (lzy_character/config.lua)
-- et demandait donc un push + un redemarrage pour changer une seule tenue.
--
-- COMMENT : la surcharge voyage en variables globales repliquees
-- (EVO_EspadaSkin1..5). Le resolveur GetRankEspadaBody les lit EN PRIORITE sur
-- la table en dur, cote serveur comme cote client -- indispensable, c'est le
-- CLIENT qui construit le modele composite. Une globale a -1 = pas de
-- surcharge, on retombe sur la valeur du code.
--
-- Pourquoi cinq globales entieres plutot qu'un JSON dans une seule : c'est
-- replique nativement, il n'y a rien a parser, et une valeur corrompue ne peut
-- pas emporter les quatre autres.
--
-- PERSISTANCE (22/09/2026) : EN BASE, table evo_espada_tenues, partagee par
-- tous les serveurs (Hueco, Seireitei, hub) : une tenue choisie sur l'un vaut
-- partout, et elle survit a tout redemarrage. L'ancien fichier
-- data/evo_espada_tenues.txt etait propre a chaque serveur et, surtout, il
-- n'etait JAMAIS relu : son rechargement vivait dans un hook « Initialize »
-- qui ne tourne pas pour un module charge par SAM (dev HM : fichier ecrit le
-- 26/08, redemarrage le 20/09, aucune ligne de rechargement au journal). Tout
-- se pose maintenant AU CHARGEMENT du module, sans attendre aucun hook ; la
-- base est relue toutes les minutes pour suivre les autres serveurs. Un cache
-- disque (evo_espada_tenues_cache.txt) couvre le demarrage, avant la reponse
-- de la base, et une base injoignable.
--
-- Usage :
--   !espadatenue                 affiche la correspondance courante
--   !espadatenue <ordre> <tenue> Ordre 1-5 -> tenue 0-4, ou son nom (medicale...)
--     (la « tenue N » est la (N+1)e du modele : tenue 0 = Espada 1 ... tenue 4 = Espada 5)
--   !espadatenue <ordre> -1      rend cet Ordre a la valeur du code
--   !espadatenue reset           rend TOUS les Ordres a la valeur du code
--
-- Superadmin. Les Espadas connectes voient le changement tout de suite.
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

local ORDRE_MIN, ORDRE_MAX = 1, 5
local TENUE_MIN, TENUE_MAX = 0, 4
local CLE_GLOBALE = "EVO_EspadaSkin"

-- ── Cote serveur : persistance + application ───────────────────────────────
if SERVER then
    local TABLE = "evo_espada_tenues"
    local CACHE = "evo_espada_tenues_cache.txt"
    local S = sql.SQLStr

    -- La valeur du CODE pour un Ordre, quand aucune surcharge n'est posee.
    local function DefautCode(iOrdre)
        local cfg = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.ESPADA_BODY
        local t = cfg and cfg.skinByOrdreNum
        return (istable(t) and t[iOrdre]) or nil
    end

    -- L'etat courant : Ordre -> tenue, -1 = valeur du code.
    local function Lire()
        local t = {}
        for i = ORDRE_MIN, ORDRE_MAX do t[i] = GetGlobalInt(CLE_GLOBALE .. i, -1) end
        return t
    end

    -- Rafraichit les Espadas CONNECTES : sans ca le staff devrait demander a
    -- chacun de se reconnecter pour voir sa tenue changer.
    local function Rafraichir()
        for _, ply in player.Iterator() do
            if IsValid(ply)
                and ply:GetEvoNWString("FactionName", "") == "Hollow"
                and ply.RefreshClientPlayerModelSoon then
                ply:RefreshClientPlayerModelSoon()
            end
        end
    end

    -- Applique une surcharge (ou -1 pour rendre l'Ordre au code).
    local function Poser(iOrdre, iTenue, bSansRefresh)
        SetGlobalInt(CLE_GLOBALE .. iOrdre, iTenue)
        if bSansRefresh then return end
        Rafraichir()
    end

    -- Applique une table Ordre -> tenue (cles entieres ou chaines, ce que
    -- donnent la base et le JSON). Une valeur absente ou hors bornes vaut -1.
    -- Renvoie le nombre d'Ordres qui ont change ; les Espadas ne sont
    -- rafraichis que s'il y en a.
    local function Appliquer(t)
        local n = 0
        for i = ORDRE_MIN, ORDRE_MAX do
            local v = tonumber(t[i])
            if v == nil then v = tonumber(t[tostring(i)]) end
            if v == nil or v < TENUE_MIN or v > TENUE_MAX then v = -1 end
            v = math.floor(v)
            if GetGlobalInt(CLE_GLOBALE .. i, -1) ~= v then
                SetGlobalInt(CLE_GLOBALE .. i, v)
                n = n + 1
            end
        end
        if n > 0 then Rafraichir() end
        return n
    end

    -- Le cache disque : ce que la base a dit la derniere fois.
    local function EcrireCache()
        local t = {}
        for i, v in pairs(Lire()) do t[tostring(i)] = v end
        file.Write(CACHE, util.TableToJSON(t))
    end

    -- La base : une ligne par Ordre. MUGEN.Query rend une CHAINE d'erreur en
    -- premier argument quand ca rate (voir evo_affiche), une table de lignes
    -- sinon. La creation de table n'est faite qu'au premier passage.
    local nEssais, bBaseLue = 0, false
    local function LireLaBase(bCreer)
        if not (MUGEN and MUGEN.Query) then
            nEssais = nEssais + 1
            if nEssais <= 30 then timer.Simple(2, function() LireLaBase(bCreer) end) end
            return
        end
        local function lire()
            MUGEN.Query("SELECT ordre, tenue FROM " .. TABLE, function(res)
                if isstring(res) or not istable(res) then
                    MsgN("[evo_espada_tenue] lecture de la base impossible : " .. tostring(res))
                    return
                end
                local t = {}
                for _, row in ipairs(res) do
                    local i = tonumber(row.ordre)
                    if i then t[i] = tonumber(row.tenue) end
                end
                local n = Appliquer(t)
                if not bBaseLue then
                    bBaseLue = true
                    MsgN(string.format("[evo_espada_tenue] base lue : %d ligne(s), %d changement(s).", #res, n))
                elseif n > 0 then
                    MsgN("[evo_espada_tenue] tenues changees depuis un autre serveur : " .. n .. " Ordre(s) mis a jour.")
                end
                EcrireCache()
            end)
        end
        if not bCreer then return lire() end
        MUGEN.Query("CREATE TABLE IF NOT EXISTS " .. TABLE .. [[ (
            ordre TINYINT     NOT NULL,
            tenue TINYINT     NOT NULL DEFAULT -1,
            maj   INT         NOT NULL DEFAULT 0,
            par   VARCHAR(64) NOT NULL DEFAULT '',
            PRIMARY KEY (ordre)
        )]], function(res)
            if isstring(res) then
                MsgN("[evo_espada_tenue] creation de la table impossible : " .. res)
                return
            end
            lire()
        end)
    end

    -- Ecrit l'etat courant : cache disque tout de suite, base ensuite. Les
    -- cinq Ordres a chaque fois (REPLACE) : une ligne par Ordre, jamais de trou.
    local function Sauver(sPar)
        EcrireCache()
        if not (MUGEN and MUGEN.Query) then
            MsgN("[evo_espada_tenue] base absente : tenues gardees sur le cache disque seulement.")
            return
        end
        local l = {}
        for i, v in pairs(Lire()) do
            l[#l + 1] = string.format("(%d, %d, %d, %s)", i, v, os.time(), S(tostring(sPar or "")))
        end
        MUGEN.Query("REPLACE INTO " .. TABLE .. " (ordre, tenue, maj, par) VALUES " .. table.concat(l, ", "),
            function(res)
                if isstring(res) then MsgN("[evo_espada_tenue] sauvegarde en base refusee : " .. res) end
            end)
    end

    -- AU CHARGEMENT, TOUT DE SUITE, pas dans un hook. L'ordre compte : une
    -- globale jamais posee vaut 0, ce qui serait lu comme « tenue 0 » et
    -- ecraserait silencieusement le defaut du code. Donc -1 partout, puis le
    -- cache disque, puis la base des qu'elle repond.
    for i = ORDRE_MIN, ORDRE_MAX do SetGlobalInt(CLE_GLOBALE .. i, -1) end
    do
        local brut = file.Read(CACHE, "DATA")
        local t = brut and util.JSONToTable(brut)
        if istable(t) then
            local n = Appliquer(t)
            if n > 0 then MsgN("[evo_espada_tenue] cache disque : " .. n .. " surcharge(s) d'Ordre reposee(s).") end
        end
    end
    LireLaBase(true)
    -- Les autres serveurs partagent la table : on la relit toutes les minutes.
    timer.Create("EVO::EspadaTenue::Sync", 60, 0, function()
        if bBaseLue then LireLaBase(false) end
    end)

    EVO_EspadaTenue = { Poser = Poser, Sauver = Sauver, DefautCode = DefautCode }
end

-- ── Noms des tenues ───────────────────────────────────────────────────────
-- Les cinq tenues du modele portent un nom de metier (config du personnage,
-- ESPADA_BODY.tenueNoms) : le staff dit « la medicale », pas « la tenue 3 ».
-- Le jeu, lui, ne travaille que sur le numero de skin.
local function NomTenue(iTenue)
    local cfg = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.ESPADA_BODY
    local t = cfg and cfg.tenueNoms
    return (istable(t) and t[tonumber(iTenue) or -1]) or nil
end

-- « tenue 3 (Medicale) », ou juste « tenue 3 » si elle n'a pas de nom.
local function Etiquette(iTenue)
    local nom = NomTenue(iTenue)
    return nom and (iTenue .. " (" .. nom .. ")") or tostring(iTenue)
end

-- Comparaison sans accent ni casse : personne ne tape « Médicale » en jeu.
local ACCENTS = { ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["ë"] = "e", ["à"] = "a", ["â"] = "a",
    ["î"] = "i", ["ï"] = "i", ["ô"] = "o", ["ö"] = "o", ["û"] = "u", ["ù"] = "u", ["ü"] = "u", ["ç"] = "c" }
local function Simplifier(s)
    s = string.lower(string.Trim(tostring(s or "")))
    for accent, simple in pairs(ACCENTS) do s = string.gsub(s, accent, simple) end
    return s
end

-- Un nom de tenue (« medicale », « Scientifique ») -> son numero de skin, ou nil.
local function TenueParNom(sNom)
    local cherche = Simplifier(sNom)
    if cherche == "" then return nil end
    local cfg = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.ESPADA_BODY
    local t = cfg and cfg.tenueNoms
    if not istable(t) then return nil end
    for i = TENUE_MIN, TENUE_MAX do
        if t[i] and Simplifier(t[i]) == cherche then return i end
    end
    return nil
end

-- La liste des noms, pour les messages d'aide et de refus.
local function ListeNoms()
    local l = {}
    for i = TENUE_MIN, TENUE_MAX do
        if NomTenue(i) then l[#l + 1] = i .. "=" .. NomTenue(i) end
    end
    return table.concat(l, ", ")
end

-- ── La commande ────────────────────────────────────────────────────────────
command.set_category("Utility")

command.new("espadatenue")
    :Aliases("espadaskin", "tenueespada")
    :SetPermission("espadatenue", "superadmin")
    -- Les deux arguments sont OPTIONNELS : sans rien on AFFICHE, ce qui evite
    -- de modifier a l'aveugle quand on ne sait plus quelle tenue va ou.
    :AddArg("text", { hint = "ordre 1-5, ou 'reset'", optional = true, default = "" })
    :AddArg("text", { hint = "tenue 0-4 ou son nom (-1 = defaut)", optional = true, default = "" })
    :Help("Choisit la tenue (skin) portee par chaque Ordre d'Espada. Sans argument : affiche la correspondance.")
    :OnExecute(function(ply, sArg1, sArg2)
        if not SERVER then return end
        local E = EVO_EspadaTenue
        if not E then
            sam.player.send_message(ply, "Module tenue d'Espada indisponible.")
            return
        end
        -- Qui a change quoi : garde en base, pour retrouver l'auteur d'une tenue.
        local sPar = (IsValid(ply) and ply.SteamID) and ply:SteamID() or "console"

        local function Etat()
            local l = {}
            for i = ORDRE_MIN, ORDRE_MAX do
                local sur = GetGlobalInt(CLE_GLOBALE .. i, -1)
                local def = E.DefautCode(i)
                l[#l + 1] = "Ordre " .. i .. " -> tenue "
                    .. (sur >= 0 and (Etiquette(sur) .. " [choisie]") or (Etiquette(def) .. " [defaut]"))
            end
            sam.player.send_message(ply, "Tenues d'Espada :\n" .. table.concat(l, "\n"))
        end

        sArg1 = string.lower(string.Trim(tostring(sArg1 or "")))
        if sArg1 == "" then return Etat() end

        if sArg1 == "reset" then
            for i = ORDRE_MIN, ORDRE_MAX do E.Poser(i, -1, true) end
            E.Poser(ORDRE_MIN, -1)   -- le dernier appel declenche le rafraichissement
            E.Sauver(sPar)
            sam.player.send_message(nil, "{A} a rendu TOUTES les tenues d'Espada a leur valeur par defaut.", { A = ply })
            return Etat()
        end

        local iOrdre = tonumber(sArg1)
        -- Le staff peut donner le NOM de la tenue (« medicale ») plutot que son numero.
        local iTenue = tonumber(sArg2) or TenueParNom(sArg2)
        if not iOrdre or iOrdre < ORDRE_MIN or iOrdre > ORDRE_MAX then
            sam.player.send_message(ply, "Ordre invalide. Attendu " .. ORDRE_MIN .. " a " .. ORDRE_MAX .. ", ou 'reset'.")
            return
        end
        if not iTenue then
            sam.player.send_message(ply, "Tenue manquante. Attendu " .. TENUE_MIN .. " a " .. TENUE_MAX
                .. ", un nom (" .. ListeNoms() .. "), ou -1 pour le defaut.")
            return
        end
        iTenue = math.floor(iTenue)
        if iTenue ~= -1 and (iTenue < TENUE_MIN or iTenue > TENUE_MAX) then
            sam.player.send_message(ply, "Tenue invalide. Attendu " .. TENUE_MIN .. " a " .. TENUE_MAX
                .. ", un nom (" .. ListeNoms() .. "), ou -1 pour le defaut.")
            return
        end

        E.Poser(iOrdre, iTenue)
        E.Sauver(sPar)
        sam.player.send_message(nil, "{A} a mis l'Ordre {O} d'Espada sur la tenue {V}.", {
            A = ply, O = iOrdre,
            V = iTenue == -1 and ("defaut (" .. Etiquette(E.DefautCode(iOrdre)) .. ")") or Etiquette(iTenue),
        })
    end)
:End()
