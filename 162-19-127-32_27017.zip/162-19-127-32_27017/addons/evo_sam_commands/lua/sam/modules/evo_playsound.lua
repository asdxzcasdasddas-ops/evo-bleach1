-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_playsound.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — SAM : tester un son (chemin relatif à sound/, sans préfixe "sound/").
-- !playsound <path> [volume 0-1]
-- Ex. : !playsound 6515xw26amw1br/boiling_sfx.wav
-- ============================================================================
if SAM_LOADED then return end

if SERVER then
	util.AddNetworkString("EVO_PlaySound:Test")
end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("playsound")
	:Aliases("testsound", "psnd")
	:SetPermission("playsound", "superadmin")
	:AddArg("text", { hint = "chemin (ex: 6515xw26amw1br/boiling_sfx.wav)" })
	:AddArg("number", {
		hint = "volume 0-1",
		optional = true,
		default = 1,
		min = 0,
		max = 1,
	})
	:Help("Joue un son sur TOI + diagnostic file.Exists / SoundDuration (client).")
	:OnExecute(function(ply, sPath, nVol)
		if not IsValid(ply) then return end
		sPath = string.Trim(tostring(sPath or ""))
		if sPath == "" then
			sam.player.send_message(ply, "Chemin vide.")
			return
		end
		-- Accepte un éventuel préfixe sound/ tapé par erreur.
		if string.StartWith(string.lower(sPath), "sound/") then
			sPath = string.sub(sPath, 7)
		end
		nVol = math.Clamp(tonumber(nVol) or 1, 0, 1)

		util.PrecacheSound(sPath)
		-- Emit serveur (3D sur le joueur) : les proches entendent aussi si le client a le fichier.
		ply:EmitSound(sPath, 75, 100, nVol, CHAN_AUTO)

		net.Start("EVO_PlaySound:Test")
			net.WriteString(sPath)
			net.WriteFloat(nVol)
		net.Send(ply)

		sam.player.send_message(ply, "Son testé : {V} (vol {V_2}) — vois le chat client pour le diagnostic.", {
			V = sPath,
			V_2 = string.format("%.2f", nVol),
		})
	end)
:End()
