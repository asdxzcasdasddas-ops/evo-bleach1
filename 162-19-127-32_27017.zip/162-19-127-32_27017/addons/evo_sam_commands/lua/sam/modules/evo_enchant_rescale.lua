-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_enchant_rescale.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commandes SAM : enchant_rescale_check / enchant_rescale (superadmin)
-- Re-normalise les gravures déjà posées à l'échelle de config COURANTE
-- (EVO_CRAFT.ENCHANT_REV), sur inventaire + coffres division/clan + annonces HDV.
-- Le balayage tourne déjà tout seul au boot ; ces commandes servent à le
-- PRÉVISUALISER, et à le rejouer après une édition de config à chaud (elles
-- ignorent le verrou cross-serveur, la passe étant idempotente).
-- Usage : !enchant_rescale_check   (simulation, aucune écriture)
--         !enchant_rescale         (applique + resynchronise les connectés)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Craft")

local function report(ply, bDryRun, bOk, tStats, sErr)
	if not bOk then
		local fail = sErr or "Échec du balayage des gravures."
		if IsValid(ply) then ply:sam_send_message(fail) else print("[SAM] " .. fail) end
		return false
	end

	local nTotal, nChanged = 0, 0
	for _, s in pairs(tStats or {}) do
		if istable(s) then
			nTotal = nTotal + (tonumber(s.scanned) or 0)
			nChanged = nChanged + (tonumber(s.changed) or 0)
		end
	end

	local info = string.format(
		"Gravures (rev %s)%s : %d analysée(s), %d %s.",
		tostring(EVO_CRAFT.ENCHANT_REV),
		bDryRun and " — SIMULATION" or "",
		nTotal, nChanged,
		bDryRun and "à convertir" or "convertie(s)"
	)
	-- Le détail par table part en CONSOLE (F10) : trop long pour le chat.
	local tLines = EVO_CRAFT.EnchantRescaleReport(tStats, bDryRun)
	if IsValid(ply) then
		ply:sam_send_message(info .. " Détail dans votre console.")
		ply:PrintMessage(HUD_PRINTCONSOLE, info)
		for _, l in ipairs(tLines) do ply:PrintMessage(HUD_PRINTCONSOLE, l) end
	else
		print("[SAM] " .. info)
		for _, l in ipairs(tLines) do print(l) end
	end
	return true, nChanged
end

local function available(ply)
	if EVO_CRAFT and EVO_CRAFT.EnchantRescaleAll then return true end
	if IsValid(ply) then ply:sam_send_message("EVO_CRAFT.EnchantRescaleAll indisponible.") end
	return false
end

command.new("enchant_rescale_check")
	:Aliases("gravure_simul", "rescale_gravure_check")

	:SetPermission("enchant_rescale_check", "superadmin")

	:Help("Simule la re-normalisation des gravures à l'échelle de config courante (aucune écriture).")

	:OnExecute(function(ply)
		if not available(ply) then return end
		EVO_CRAFT.EnchantRescaleAll({ dry = true }, function(bOk, tStats, sErr)
			report(ply, true, bOk, tStats, sErr)
		end)
	end)
:End()

command.new("enchant_rescale")
	:Aliases("gravure_rescale", "regravure")

	:SetPermission("enchant_rescale", "superadmin")

	:Help("Re-normalise TOUTES les gravures (inventaire, coffres, HDV) à l'échelle courante et resynchronise les connectés.")

	:OnExecute(function(ply)
		if not available(ply) then return end
		-- silent = false EXPRÈS : _bSilentMaxAdjust remettrait la HP à plein de
		-- tous les connectés (lzy_stats). Réservé au boot ; en jeu on applique le
		-- delta, comme un (dé)équipement.
		EVO_CRAFT.EnchantRescaleAll({ silent = false }, function(bOk, tStats, sErr)
			local ok, nChanged = report(ply, false, bOk, tStats, sErr)
			if not ok then return end
			sam.player.send_message(nil, "{A} a re-normalisé les gravures d'équipement ("
				.. tostring(nChanged) .. " converties)", { A = ply })
		end)
	end)
:End()
