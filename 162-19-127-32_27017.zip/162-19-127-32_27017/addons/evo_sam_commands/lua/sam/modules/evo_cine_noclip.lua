-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_cine_noclip.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : cine_noclip (superadmin). Whitelist TEMPORAIRE (RAM,
-- vidée au reboot et à la déconnexion) donnant accès à un NOCLIP CINÉMATIQUE :
-- pendant qu'il vole, le client du joueur est forcé en rendu cinématique — aucun
-- HUD, aucun nom, aucune info sur les joueurs — et il ne gagne RIEN d'autre :
-- pas de god, pas de cloak (l'auto-cloak du gamemode est gate IsStaff), pas
-- d'outils. Un joueur normal, visible et vulnérable, qui vole pour filmer.
--
-- Tout est ICI (demande user : une commande, pas un addon) :
--   • serveur : whitelist + toggle joueur (evo_cine_noclip) + watch du movetype.
--     SetMoveType DIRECT = le chemin noclip établi du serveur (la commande SAM
--     noclip fait pareil, cf. sv_staffmode) -> aucun ordre de hooks à arbitrer,
--     le gate lockdown sur PlayerNoClip n'est même pas concerné.
--   • client : rendu forcé pendant EVO_CineNoclip (NWBool posé par le watch),
--     relayé à TOUT le projet via IsCinematicActive (chat, auras, halos, barres
--     de KO, science... suivent comme pour le F7). Indépendant du F7 : la touche
--     cinématique du joueur ne peut pas réafficher son HUD.
-- Les nametags (lzy_meet, rendu 3D hors scissor) ont leur garde dédiée là-bas.
-- ⚠ La commande est déclarée HORS des blocs de realm : SAM enregistre les
-- commandes des DEUX côtés (le menu client en a besoin), OnExecute ne tourne
-- que serveur — même contrat que tous les modules du dossier.
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command
command.set_category("Commandes - EVO")

if SERVER then
	EVO_CineWL = EVO_CineWL or {} -- [sid64] = nom (RAM : un reboot vide tout)

	local function estWhiteliste(ply)
		local sid = IsValid(ply) and ply:SteamID64() or nil
		return sid ~= nil and EVO_CineWL[sid] ~= nil
	end

	-- Vrai noclip seulement : un joueur assis/porté/grab est en MOVETYPE_NOCLIP
	-- moteur sans voler (piège connu, cf. evo_noclip_portal / sv_staffmode).
	local function enNoclip(ply)
		return ply:GetMoveType() == MOVETYPE_NOCLIP and not ply:InVehicle()
	end

	function EVO_CineWL_Sortir(ply)
		if IsValid(ply) and enNoclip(ply) then ply:SetMoveType(MOVETYPE_WALK) end
		if IsValid(ply) then ply:SetEvoNWBool("EVO_CineNoclip", false) end
	end

	-- Toggle du JOUEUR whitelisté (bindable : bind <touche> evo_cine_noclip).
	concommand.Add("evo_cine_noclip", function(ply)
		if not (IsValid(ply) and ply:IsPlayer()) then return end
		if not estWhiteliste(ply) then return end -- pas whitelisté : la commande n'existe pas pour toi
		if enNoclip(ply) then
			EVO_CineWL_Sortir(ply)
			return
		end
		-- Garde d'état minimale : pas depuis le sol (KO), une prise, un portage
		-- ou un siège — le laissez-passer ne sert qu'à filmer, pas à s'échapper.
		if not ply:Alive() or ply:GetEvoNWBool("EVO_IsKO", false) then return end
		if ply:GetEvoNWBool("NCM_IsGrabbed", false) or ply:GetEvoNWBool("NCM_IsGrabbing", false) then return end
		if (ply.IsCarrying and ply:IsCarrying()) or (ply.IsCarryied and ply:IsCarryied()) then return end
		if ply:InVehicle() then return end
		ply:SetMoveType(MOVETYPE_NOCLIP)
	end)

	-- Watch 0.25 s (uniquement les whitelistés, table minuscule) : le NWBool suit
	-- l'état RÉEL du movetype — c'est lui qui force le rendu cinématique client.
	timer.Create("EVO_CineWL::Watch", 0.25, 0, function()
		if not next(EVO_CineWL) then return end
		for _, ply in player.Iterator() do
			local sid = ply:SteamID64()
			if sid and EVO_CineWL[sid] then
				local bOn = enNoclip(ply)
				if ply:GetEvoNWBool("EVO_CineNoclip", false) ~= bOn then
					-- netgate: edge -- garde d'inegalite juste au-dessus : ecrit au changement seulement
					ply:SetEvoNWBool("EVO_CineNoclip", bOn)
				end
			end
		end
	end)

	-- Le laissez-passer ne survit pas à la session (encore moins qu'au reboot).
	hook.Add("PlayerDisconnected", "EVO_CineWL::Purge", function(ply)
		local sid = ply:SteamID64()
		if sid then EVO_CineWL[sid] = nil end
	end)
end

if CLIENT then
	-- Lu par lzy_meet (nametags) et quiconque veut savoir si le rendu est forcé.
	function EVO_CineNoclipHidden()
		local lp = LocalPlayer()
		return IsValid(lp) and lp:GetEvoNWBool("EVO_CineNoclip", false)
	end

	-- Relais IsCinematicActive : posé après le chargement de tous les addons
	-- (l'ordre de chargement ne garantit pas que ncm_cinematic soit déjà passé).
	hook.Add("InitPostEntity", "EVO_CineWL::WrapCinematic", function()
		local fOrig = IsCinematicActive
		function IsCinematicActive()
			if EVO_CineNoclipHidden() then return true end
			if fOrig then return fOrig() end
			return false
		end
	end)

	-- HUD : mêmes verrous que le mode cinématique F7 (le scissor bloque AUSSI les
	-- HUDPaint d'addons, pas seulement les éléments déclarés).
	hook.Add("PreDrawHUD", "EVO_CineWL::BlockHUD", function()
		if EVO_CineNoclipHidden() then render.SetScissorRect(0, 0, 0, 0, true) end
	end)
	hook.Add("PostDrawHUD", "EVO_CineWL::BlockHUD", function()
		if EVO_CineNoclipHidden() then render.SetScissorRect(0, 0, 0, 0, false) end
	end)
	hook.Add("HUDShouldDraw", "EVO_CineWL::HideHUD", function()
		if EVO_CineNoclipHidden() then return false end
	end)
	hook.Add("HUDDrawTargetID", "EVO_CineWL::HideTargetID", function()
		if EVO_CineNoclipHidden() then return true end
	end)
	-- Scoreboard = la liste des joueurs : exactement l'info que ce mode interdit.
	hook.Add("ScoreboardShow", "EVO_CineWL::BlockScoreboard", function()
		if EVO_CineNoclipHidden() then return false end
	end)
end

command.new("cine_noclip")
	:Aliases("cinenoclip", "noclipcine")

	:SetPermission("cine_noclip", "superadmin")

	:AddArg("player")

	:Help("Whitelist TEMPORAIRE (vidée au reboot) : noclip cinématique sans HUD ni info joueurs, aucune autre permission. Re-lancer = retirer. Superadmin.")

	:OnExecute(function(ply, targets)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		for _, target in ipairs(targets) do
			if IsValid(target) then
				local sid = target:SteamID64()
				if sid then
					local bAccorde
					if EVO_CineWL[sid] then
						EVO_CineWL[sid] = nil
						bAccorde = false
						if EVO_CineWL_Sortir then EVO_CineWL_Sortir(target) end
						if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : accès noclip cinématique RETIRÉ.") end
						target:sam_send_message("Ton accès au noclip cinématique t'a été retiré.")
					else
						EVO_CineWL[sid] = target:Nick()
						bAccorde = true
						if IsValid(ply) then ply:sam_send_message(target:Nick() .. " : accès noclip cinématique ACCORDÉ (jusqu'au reboot ou sa déconnexion).") end
						target:sam_send_message("Accès noclip cinématique accordé : tape evo_cine_noclip en console (ou bind une touche dessus) pour voler. Aucun HUD pendant le vol, c'est voulu.")
					end
					if EVO_StaffLog then
						EVO_StaffLog(ply, "staff.cine_noclip", target, bAccorde and "accorde" or "retire")
					end
				end
			end
		end
	end)
:End()
