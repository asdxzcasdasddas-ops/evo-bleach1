-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_take_coins.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : take_coins (superadmin)
-- Retire des coins à un joueur CONNECTÉ (sélecteur SAM). Miroir du crédit staff
-- (sv_evo_give_coins_all.lua CreditAndNotify) : players.coins est la vérité, le
-- NWInt "coins" n'est qu'un miroir resynchronisé après coup, le mouvement part
-- au journal coins (EVO_CoinsLog) et le site est re-poussé (EVO_PlayersPush).
--
-- Débit en UN statement : coins - LEAST(coins, N). Jamais de solde négatif, et
-- pas d'underflow si la colonne est UNSIGNED — LEAST(coins, N) <= coins par
-- construction. On ne se fie PAS aux lignes affectées (MUGEN.Query : nAff est
-- toujours nil) : le montant réellement retiré vient d'un SELECT avant/après.
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Argent")

local function retirer(staff, target, amount, reason)
	local sid = target:SteamID64()
	if not sid or sid == "" then return end
	local S = sql.SQLStr

	MUGEN.Query(string.format(
		"SELECT coins FROM players WHERE steamid64 = %s LIMIT 1", S(sid)),
		function(rows)
			if not (istable(rows) and rows[1]) then
				if IsValid(staff) then
					staff:sam_send_message(target:Nick() .. " : compte introuvable dans players.")
				end
				return
			end
			local nAvant = math.max(0, tonumber(rows[1].coins) or 0)
			if nAvant <= 0 then
				if IsValid(staff) then
					staff:sam_send_message(target:Nick() .. " n'a aucun coin à retirer.")
				end
				return
			end
			local nRetire = math.min(nAvant, amount)

			MUGEN.Query(string.format(
				"UPDATE players SET coins = coins - LEAST(coins, %d) WHERE steamid64 = %s",
				amount, S(sid)),
				function()
					-- Relecture = source de vérité pour le miroir NW (une course avec un
					-- gain simultané resterait juste, contrairement à un calcul local).
					MUGEN.Query(string.format(
						"SELECT coins FROM players WHERE steamid64 = %s LIMIT 1", S(sid)),
						function(rows2)
							local nApres = (istable(rows2) and rows2[1]) and (tonumber(rows2[1].coins) or 0) or math.max(0, nAvant - nRetire)

							if IsValid(target) then
								target:SetEvoNWInt("coins", nApres)
								local sMsg = "Retrait staff : " .. nRetire .. " coins retirés."
									.. (reason ~= "" and ("\n" .. reason) or "")
								if target.OpenPopup then target:OpenPopup(sMsg, "error") end
								target:ChatPrint("[STAFF] " .. nRetire .. " coins retirés."
									.. (reason ~= "" and (" Motif : " .. reason) or ""))
							end

							if EVO_CoinsLog and EVO_CoinsLog.EcrireAvecSolde then
								EVO_CoinsLog.EcrireAvecSolde(sid, -nRetire, "retrait_staff", reason)
							end
							if EVO_PlayersPush and EVO_PlayersPush.MarkDirty then
								EVO_PlayersPush.MarkDirty()
							end

							if IsValid(staff) then
								staff:sam_send_message(string.format("%s : %d coins retirés (%d avant, %d après).",
									IsValid(target) and target:Nick() or "?", nRetire, nAvant, nApres))
							end
						end)
				end)
		end)
end

command.new("take_coins")
	:Aliases("takecoins", "retirercoins")

	:SetPermission("take_coins", "superadmin")

	:AddArg("player")
	:AddArg("number", { hint = "quantité", min = 1, round = true })
	:AddArg("text", { hint = "motif (optionnel)", optional = true, default = "" })
	:GetRestArgs()

	:Help("Retire des coins à un joueur connecté (plafonné à son solde, jamais négatif). Superadmin.")

	:OnExecute(function(ply, targets, amount, reason)
		-- Défense en profondeur (la permission gate déjà à superadmin).
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		if not (MUGEN and MUGEN.Query) then
			if IsValid(ply) then ply:sam_send_message("Base de données indisponible (MUGEN).") end
			return
		end

		amount = math.floor(tonumber(amount) or 0)
		if amount < 1 then return end
		reason = string.sub(string.Trim(tostring(reason or "")), 1, 200)
		if EVO_WordFilter and EVO_WordFilter.Censor and reason ~= "" then
			reason = EVO_WordFilter.Censor(reason)
		end

		for _, target in ipairs(targets) do
			if IsValid(target) then
				retirer(ply, target, amount, reason)
			end
		end
	end)
:End()
