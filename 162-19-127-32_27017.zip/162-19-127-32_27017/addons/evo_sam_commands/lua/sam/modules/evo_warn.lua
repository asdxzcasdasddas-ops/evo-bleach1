-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_warn.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM `evo_warn` (superadmin, onglet Commands du menu SAM).
-- Passe par EVO_Warn : même table, immunité, escalade 5/14j, popup joueur.
-- Nom volontairement PAS `warn` : `!warn` ouvre déjà le menu staff (PlayerSay).
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Modération")

command.new("evo_warn")
	:SetPermission("evo_warn", "superadmin")
	:AddArg("player", { single_target = true, cant_target_self = true })
	:AddArg("text", { hint = "titre (ex : RDM, Insultes…)" })
	:AddArg("text", { hint = "raison (optionnel)", optional = true, default = "" })
	:GetRestArgs()
	:Help("Avertit un joueur (même système que le dashboard staff : popup + historique + escalade).")
	:OnExecute(function(ply, targets, title, reason)
		local target = targets and targets[1]
		if not (IsValid(target) and target:IsPlayer()) then return end
		if not EVO_Warn then
			if IsValid(ply) then ply:sam_send_message("Système de warns indisponible.") end
			return
		end
		EVO_Warn(ply, target, title, reason)
	end)
:End()
