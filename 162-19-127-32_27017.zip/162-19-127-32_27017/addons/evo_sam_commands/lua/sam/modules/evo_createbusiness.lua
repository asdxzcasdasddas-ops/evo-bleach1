-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_createbusiness.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — SAM : créer / lister / supprimer des commerces (multi-bars).
-- !createbusiness <id> [label]
-- !listbusinesses
-- !deletebusiness <id>   (extras seulement ; refuse s'il reste des membres)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("createbusiness")
	:Aliases("addbusiness", "newbusiness")
	:SetPermission("createbusiness", "superadmin")
	:AddArg("text", { hint = "id (ex: bar_ouest)" })
	:AddArg("text", { hint = "label", optional = true, default = "" })
	:Help("Crée un commerce kind bar (distillerie/coffre à lier via !config_positions).")
	:OnExecute(function(ply, sId, sLabel)
		if not (EVO_BUSINESS and EVO_BUSINESS.RegisterBusiness) then return end
		sLabel = string.Trim(tostring(sLabel or ""))
		if sLabel == "" then sLabel = sId end
		local ok, err = EVO_BUSINESS.RegisterBusiness(sId, sLabel, "bar", true)
		if not ok then
			sam.player.send_message(ply, "Création impossible : {V}", { V = tostring(err) })
			return
		end
		sam.player.send_message(nil, "{A} a créé le commerce {V} ({V_2})", {
			A = ply, V = err, V_2 = sLabel,
		})
	end)
:End()

command.new("listbusinesses")
	:Aliases("businesses", "listbiz")
	:SetPermission("listbusinesses", "superadmin")
	:Help("Liste les commerces enregistrés.")
	:OnExecute(function(ply)
		if not (EVO_BUSINESS and EVO_BUSINESS.CFG and EVO_BUSINESS.CFG.Businesses) then return end
		local bits = {}
		for _, id in ipairs(EVO_BUSINESS.ListBusinessIds and EVO_BUSINESS.ListBusinessIds() or {}) do
			local d = EVO_BUSINESS.BusinessById(id)
			bits[#bits + 1] = id .. " = " .. ((d and d.label) or id)
				.. (d and d._extra and " [extra]" or " [builtin]")
		end
		sam.player.send_message(ply, #bits > 0 and table.concat(bits, " | ") or "(aucun)")
	end)
:End()

command.new("deletebusiness")
	:Aliases("removebusiness")
	:SetPermission("deletebusiness", "superadmin")
	:AddArg("text", { hint = "id" })
	:Help("Supprime un commerce extra (pas le builtin bar). Refuse s'il a encore des membres.")
	:OnExecute(function(ply, sId)
		if not (EVO_BUSINESS and EVO_BUSINESS.UnregisterBusiness) then return end
		sId = string.lower(string.Trim(tostring(sId or "")))
		local def = EVO_BUSINESS.BusinessById(sId)
		if not def then
			sam.player.send_message(ply, "Commerce inconnu.")
			return
		end
		if not def._extra then
			sam.player.send_message(ply, "Impossible de supprimer un commerce builtin.")
			return
		end
		if not (MUGEN and MUGEN.Query) then
			sam.player.send_message(ply, "BDD indisponible.")
			return
		end
		MUGEN.Query("SELECT COUNT(*) n FROM evo_business_members WHERE business_id = " .. sql.SQLStr(sId), function(res)
			local n = istable(res) and res[1] and tonumber(res[1].n) or 0
			if n > 0 then
				sam.player.send_message(ply, "Il reste {V} membre(s) : retire-les d'abord.", { V = n })
				return
			end
			local ok, err = EVO_BUSINESS.UnregisterBusiness(sId)
			if not ok then
				sam.player.send_message(ply, "Suppression impossible : {V}", { V = tostring(err) })
				return
			end
			sam.player.send_message(nil, "{A} a supprimé le commerce {V}", { A = ply, V = sId })
		end)
	end)
:End()
