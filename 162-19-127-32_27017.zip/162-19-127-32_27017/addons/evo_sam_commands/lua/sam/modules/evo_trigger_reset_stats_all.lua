-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_trigger_reset_stats_all.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : Trigger Reset Stats All (superadmin)
-- Reset stat forcé pour tous les joueurs connectés + pending BDD pour les
-- personnages offline (appliqué au prochain chargement de perso, une seule fois).
-- Usage : !trigger_reset_stats_all   (menu SAM : même nom)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - EVO")

command.new("trigger_reset_stats_all")
	:Aliases("resetstatsall", "triggerresetstatsall")

	:SetPermission("trigger_reset_stats_all", "superadmin")

	:Help("Trigger Reset Stats All : reset compétences de tous les joueurs connectés ; pending BDD pour les offline (1× par personnage).")

	:OnExecute(function(ply)
		if not LZY_TriggerResetStatsAll then
			if IsValid(ply) then
				ply:sam_send_message("LZY_TriggerResetStatsAll indisponible (skilltree).")
			end
			return
		end

		LZY_TriggerResetStatsAll(function(ok, onlineReset, pendingTotal)
			if not ok then
				if IsValid(ply) then
					ply:sam_send_message("Échec du trigger reset stats (erreur SQL).")
				end
				return
			end

			local msg = string.format(
				"Reset stats déclenché : %d joueur(s) online reset maintenant, %d personnage(s) inscrits en pending (les offline au prochain chargement).",
				tonumber(onlineReset) or 0,
				tonumber(pendingTotal) or 0
			)
			if IsValid(ply) then
				ply:sam_send_message(msg)
			else
				print("[SAM] " .. msg)
			end

			sam.player.send_message(nil, "{A} a déclenché Trigger Reset Stats All (" .. tostring(onlineReset) .. " online / " .. tostring(pendingTotal) .. " pending)", {
				A = ply,
			})
		end)
	end)
:End()
