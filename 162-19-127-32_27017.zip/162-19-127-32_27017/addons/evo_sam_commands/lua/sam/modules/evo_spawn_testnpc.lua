-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_spawn_testnpc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM custom : spawntestnpc
-- Spawn un PNJ ncm_pnj ALÉATOIRE devant toi avec peu de PV (10 par défaut), pour
-- tester rapidement (ex : la dévoration des Hollows / la progression larva).
-- Usage : !spawntestnpc [pv]   (ou via le menu SAM, catégorie Utility)
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Utility")

command.new("spawntestnpc")
	:Aliases("testnpc")

	:SetPermission("spawntestnpc", "superadmin")

	:AddArg("number", { hint = "PV (défaut 10)", optional = true, default = 10, round = true, min = 1, max = 100000 })

	:Help("Spawn un PNJ aléatoire à faibles PV (défaut 10) devant toi, pour tester.")

	:OnExecute(function(ply, hp)
		if not IsValid(ply) then return end
		if not (NCM_PNJ and NCM_PNJ.Config and NCM_PNJ.Spawn) then
			sam.player.send_message(ply, "NCM_PNJ indisponible.", {})
			return
		end
		hp = math.max(1, math.floor(tonumber(hp) or 10))

		-- classe aléatoire parmi toutes les classes de PNJ déclarées
		local classes = {}
		for class in pairs(NCM_PNJ.Config) do classes[#classes + 1] = class end
		if #classes == 0 then return end
		local class = classes[math.random(#classes)]

		local tr  = ply:GetEyeTrace()
		local pos = tr.HitPos + Vector(0, 0, 10)
		local ent = NCM_PNJ.Spawn(class, pos, Angle(0, ply:EyeAngles().y + 180, 0))
		if IsValid(ent) then
			ent:SetMaxHealth(hp)
			ent:SetHealth(hp)
			ent._ncmTestNpc = true
			-- filet : re-applique les PV au cas où le factory les pose en différé.
			timer.Simple(0.1, function()
				if IsValid(ent) then ent:SetMaxHealth(hp) ent:SetHealth(hp) end
			end)
		end

		sam.player.send_message(nil, "{A} a spawné un PNJ test (" .. class .. ") à {V} PV", {
			A = ply, V = hp,
		})
	end)
:End()
