-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_reset_finishers_all.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SAM_LOADED then return end
local command = sam.command
command.set_category("Commandes - EVO")

command.new("evo_reset_finishers_all")
	:Aliases("resetfinishersall")
	:SetPermission("evo_reset_finishers_all", "superadmin")
	:Help("Convertit une fois les finishers de TOUS les personnages de la DB en jetons de même rareté, connectés ou non. Les sacs pleins gardent un jeton en attente.")
	:OnExecute(function(ply)
		local function Reply(msg)
			if IsValid(ply) then ply:sam_send_message(msg) else print("[SAM] " .. msg) end
		end
		if IsValid(ply) and not ply:IsSuperAdmin() then Reply("Commande réservée aux superadmins.") return end
		if not EVO_FinisherCompensation then Reply("Conversion des finishers indisponible.") return end
		Reply("Conversion des finishers de toute la DB en cours...")
		EVO_FinisherCompensation.Run(function(ok, stats, err)
			if not stats then Reply(err or "Échec de la conversion.") return end
			Reply(string.format("Finishers : %d converti(s), %d jeton(s) attribué(s), %d en attente, %d rareté(s) inconnue(s), %d erreur(s).",
				stats.converted, stats.delivered, stats.pending, stats.unknown, stats.failed))
			if not ok then Reply(err or "Les erreurs sont détaillées dans la console serveur. Une relance reprend les attributions manquantes.") end
		end)
	end)
:End()
