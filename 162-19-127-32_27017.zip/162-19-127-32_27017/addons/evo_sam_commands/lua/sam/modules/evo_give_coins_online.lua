-- "addons\\evo_sam_commands\\lua\\sam\\modules\\evo_give_coins_online.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO — commande SAM : give_coins_online (superadmin)
-- Donne des coins aux joueurs actuellement connectés uniquement (pas d'offline).
-- Usage : !give_coins_online <quantité> <message>
-- ============================================================================
if SAM_LOADED then return end

local sam, command = sam, sam.command

command.set_category("Commandes - Argent")

command.new("give_coins_online")
	:Aliases("givecoinsonline", "coinsonline")

	:SetPermission("give_coins_online", "superadmin")

	:AddArg("number", { hint = "quantité", min = 1, round = true })
	:AddArg("text", { hint = "message popup" })
	:GetRestArgs()

	:Help("Donne des coins aux joueurs actuellement connectés uniquement, avec un message popup.")

	:OnExecute(function(ply, amount, msg)
		if not EVO_GiveCoinsAll or not EVO_GiveCoinsAll.RunOnline then
			if IsValid(ply) then
				ply:sam_send_message("EVO_GiveCoinsAll.RunOnline indisponible.")
			end
			return
		end

		msg = tostring(msg or "")
		EVO_GiveCoinsAll.RunOnline(amount, msg, function(ok, delivered, err)
			if not ok then
				local fail = err or "Échec du don aux joueurs connectés."
				if IsValid(ply) then
					ply:sam_send_message(fail)
				else
					print("[SAM] give_coins_online : " .. fail)
				end
				return
			end

			local n = tonumber(delivered) or 0
			local info = string.format(
				"Coins online : +%d coins — %d joueur(s) connecté(s).",
				tonumber(amount) or 0, n
			)
			if IsValid(ply) then
				ply:sam_send_message(info)
			else
				print("[SAM] " .. info)
			end

			sam.player.send_message(nil, "{A} a donné " .. tostring(amount) .. " coins aux joueurs connectés (" .. tostring(n) .. ")", {
				A = ply,
			})
		end)
	end)
:End()
