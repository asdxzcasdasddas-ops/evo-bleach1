-- "addons\\evo_sam_commands\\lua\\autorun\\client\\cl_evo_playsound.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- Client : diagnostic + relecture locale pour !playsound.
-- ============================================================================
if not CLIENT then return end

net.Receive("EVO_PlaySound:Test", function()
	local sPath = net.ReadString() or ""
	local nVol = math.Clamp(net.ReadFloat() or 1, 0, 1)
	if sPath == "" then return end

	local sDisk = "sound/" .. sPath
	local bOk = file.Exists(sDisk, "GAME")
	local nDur = tonumber(SoundDuration(sPath)) or 0

	chat.AddText(Color(207, 68, 78), "[playsound] ", color_white, sPath)
	chat.AddText(Color(150, 150, 160), "  file.Exists(\"" .. sDisk .. "\", GAME) = ",
		bOk and Color(78, 196, 128) or Color(207, 68, 78), tostring(bOk))
	chat.AddText(Color(150, 150, 160), "  SoundDuration = ", color_white, string.format("%.3f", nDur))

	local lp = LocalPlayer()
	if IsValid(lp) then
		lp:EmitSound(sPath, 75, 100, nVol, CHAN_AUTO)
	end
	if not bOk then
		chat.AddText(Color(207, 68, 78), "  → Fichier ABSENT côté client : ", color_white, sDisk)
	end
end)
