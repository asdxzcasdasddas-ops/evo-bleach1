-- "addons\\evo_zone_banner\\lua\\autorun\\sh_zone_banner.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ZONE BANNER — table des lieux (partagée client + serveur)
-- ----------------------------------------------------------------------------
-- SOURCE UNIQUE des centres de zone. Consommateurs :
--   • cl_zone_banner     — bandeau d'arrivée (détection sphère + titre)
--   • lzy_onboarding     — balises de division grade 1 + étape « tour des
--                          divisions » de la formation guidée
--
-- `div` = index FactionDivision (2..6) pour les casernes / ordres. Plusieurs
-- lignes avec le même `div` (ex. 3 accès Commandement) : la PREMIÈRE sert de
-- pose de balise ; les suivantes ne déclenchent que le bandeau.
-- Ajouter un lieu = une ligne ici. Bouger un centre déplace bandeau ET balise.
-- ============================================================================
EVO_ZoneBanner = EVO_ZoneBanner or {}

-- pos    = centre du lieu (coords monde du setpos de TP)
-- radius = rayon de déclenchement (u) autour de pos (sphère : le TP dépose au centre)
-- name   = libellé affiché
-- kanji  = filigrane (défaut 虚 « hollow » ; garder des glyphes du subset EVO Kanji :
--          飛走闘剣王虚防, 卍解, chiffres de division — sinon carré vide)
-- hold   = durée d'affichage PLEINE (s), hors fondus
-- map    = (optionnel) ne déclenche que sur cette map ; nil = n'importe quelle map
-- div    = (optionnel) index de division/ordre — pose de balise onboarding
EVO_ZoneBanner.ZONES = {
	-- map = "hueco_mundo_v1" OBLIGATOIRE (fix user 07/24) : ces deux lieux SONT à Hueco Mundo.
	-- Sans restriction, leur sphère (r=1500/1600) se déclenchait sur TOUTE map — le centre
	-- HUECO MUNDO (-13024, 2066, 133) tombe dans l'emprise jouable du Seireitei -> un joueur
	-- du Seireitei y voyait « HUECO MUNDO ». Scopées comme toutes les autres entrées de la map.
	{ name = "LAS NOCHES",  pos = Vector( 1860.30, -10236.02, 5378.42), radius = 1500, kanji = "虚", hold = 2.2, map = "hueco_mundo_v1" },
	{ name = "HUECO MUNDO", pos = Vector(-13024.97,  2066.75,  133.32), radius = 1600, kanji = "虚", hold = 2.2, map = "hueco_mundo_v1" },

	-- ── LAS NOCHES : quartiers des ORDRES (hueco_mundo_v1) ──
	-- Balises de FORMATION posées DEVANT chaque ordre (user 08/22 : un joueur en
	-- formation n'a pas à entrer là où il n'a pas le droit). PREMIÈRE ligne d'un
	-- `div` = pose de balise (règle du fichier) ; les entrées historiques 07/23
	-- restent DERRIÈRE comme déclencheurs de bandeau dans les quartiers.
	{ name = "ORDRE ASSASSIN",     pos = Vector( -2322.71,   745.91, 6379.69), radius = 1000, kanji = "剣", hold = 2.2, map = "hueco_mundo_v1", div = 3 },
	{ name = "ORDRE DE COMBAT",    pos = Vector( -2322.83,  4934.24, 6380.12), radius = 1000, kanji = "闘", hold = 2.2, map = "hueco_mundo_v1", div = 6 },
	{ name = "ORDRE MÉDECIN",      pos = Vector( -7188.66,  4937.53, 6392.14), radius = 1000, kanji = "防", hold = 2.2, map = "hueco_mundo_v1", div = 5 },
	{ name = "ORDRE SCIENTIFIQUE", pos = Vector( -7179.25,   678.92, 6391.93), radius = 1000, kanji = "虚", hold = 2.2, map = "hueco_mundo_v1", div = 4 },
	{ name = "ORDRE ASSASSIN",     pos = Vector(  3286.39,   755.63, 6401.60), radius = 1000, kanji = "剣", hold = 2.2, map = "hueco_mundo_v1", div = 3 },
	{ name = "ORDRE DE COMBAT",    pos = Vector(  3288.61,  4932.08, 6351.93), radius = 1000, kanji = "闘", hold = 2.2, map = "hueco_mundo_v1", div = 6 },
	{ name = "ORDRE MÉDECIN",      pos = Vector( -9994.50,  4937.57, 6340.44), radius = 1000, kanji = "防", hold = 2.2, map = "hueco_mundo_v1", div = 5 },
	{ name = "ORDRE SCIENTIFIQUE", pos = Vector( -9994.50,   660.26, 6341.42), radius = 1000, kanji = "虚", hold = 2.2, map = "hueco_mundo_v1", div = 4 },
	-- Commandement : 3 accès relevés -> 3 déclencheurs, même libellé. Balise = 1er.
	{ name = "ORDRE COMMANDEMENT", pos = Vector( -9991.13, -5147.07, 6347.72), radius = 1000, kanji = "王", hold = 2.2, map = "hueco_mundo_v1", div = 2 },
	{ name = "ORDRE COMMANDEMENT", pos = Vector(-10654.45, -2962.53, 6393.82), radius =  900, kanji = "王", hold = 2.2, map = "hueco_mundo_v1", div = 2 },
	{ name = "ORDRE COMMANDEMENT", pos = Vector(-10628.53, -7352.62, 6367.61), radius =  900, kanji = "王", hold = 2.2, map = "hueco_mundo_v1", div = 2 },

	-- ── SEIREITEI : casernes des DIVISIONS (rp_seireitei_v1, relevés user 07/23) ──
	{ name = "DIVISION 11", pos = Vector(-11844.14, 11158.34,  454.46), radius = 1000, kanji = "十一", hold = 2.2, map = "rp_seireitei_v1", div = 6 },
	{ name = "DIVISION 4",  pos = Vector( -5699.53, -7580.93,  436.70), radius = 1000, kanji = "四",   hold = 2.2, map = "rp_seireitei_v1", div = 5 },
	{ name = "DIVISION 2",  pos = Vector(  1896.82, -10105.53, 469.82), radius = 1000, kanji = "二",   hold = 2.2, map = "rp_seireitei_v1", div = 3 },
	{ name = "DIVISION 12", pos = Vector(  5278.57, 11656.10,  457.25), radius = 1000, kanji = "十二", hold = 2.2, map = "rp_seireitei_v1", div = 4 },
	{ name = "DIVISION 1",  pos = Vector(  -169.95, -4408.50,  475.64), radius =  900, kanji = "一",   hold = 2.2, map = "rp_seireitei_v1", div = 2 },

	-- ── ARRIVÉES DE TP (rp_seireitei_v1) : annonce du lieu en sortant du téléporteur ──
	{ name = "HORS DU SEIREITEI", pos = Vector(-6719.35,     67.18, -15018.97), radius = 700, kanji = "走", hold = 2.2, map = "rp_seireitei_v1" },
	{ name = "SEIREITEI",         pos = Vector( -185.67, -14196.97,    502.88), radius = 700, kanji = "剣", hold = 2.2, map = "rp_seireitei_v1" },
}

-- Pose de balise pour (map, index de division) : première zone taguée `div`.
-- nil si cette map n'a pas de caserne pour cet index (gm_construct, lieu sans div…).
function EVO_ZoneBanner.GetDivisionPos(sMap, nDiv)
	nDiv = tonumber(nDiv) or 0
	if nDiv < 1 then return nil end
	local t = EVO_ZoneBanner.ZONES
	for i = 1, #t do
		local z = t[i]
		if z.div == nDiv and z.pos and (not z.map or z.map == sMap) then
			return z.pos
		end
	end
end
