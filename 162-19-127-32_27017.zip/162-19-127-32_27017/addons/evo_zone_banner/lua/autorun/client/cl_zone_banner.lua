-- "addons\\evo_zone_banner\\lua\\autorun\\client\\cl_zone_banner.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ZONE BANNER — annonce de LIEU à l'arrivée (TP).
-- ----------------------------------------------------------------------------
-- Quand le joueur ENTRE dans une zone-lieu (rayon autour d'une position), un
-- grand titre stylisé s'affiche ~2s puis disparaît (fade in/out). Même DA que le
-- titre « TERRAIN D'ENTRAÎNEMENT » : Bebas Neue (police des titres, livrée par
-- evo_ui) + kanji 虚 gravé en filigrane + filet accent #cf444e.
--
-- Il n'existe PAS de hook GMod « arrivé après TP ». On détecte la TRANSITION
-- DEHORS -> DEDANS d'une zone : comme ces lieux ne se rejoignent que par TP, ça
-- déclenche pile à l'arrivée. Pas de re-trigger tant qu'on reste dedans ; si on
-- ressort et revient, ça re-annonce (voulu).
-- Ajouter un lieu = une ligne dans lua/autorun/sh_zone_banner.lua (source unique,
-- partagée avec les balises de division lzy_onboarding).
-- ============================================================================
if not CLIENT then return end

local ZONES = EVO_ZoneBanner and EVO_ZoneBanner.ZONES
if not ZONES then return end

-- Sous le SOL de la zone (pos.z), on NE déclenche PAS (demande user 07/24) : la détection
-- est une SPHÈRE 3D -> un quartier en hauteur (ex. « ORDRE ASSASSIN » à Z≈6401, r=1000) se
-- déclenchait aussi quand on est EN DESSOUS (autre étage sous la plateforme, jusqu'à ~1000u
-- plus bas). On chope donc le bas de la sphère : le joueur doit être ~au niveau du sol du
-- lieu (marge = station debout / terrain). Le TP dépose pile à pos.z, donc l'arrivée
-- déclenche toujours ; seul « être sous la zone » est exclu. (Tunable : monter pour plus permissif.)
local ZONE_BELOW_TOL = 150

local FADE_IN, FADE_OUT = 0.45, 0.75

local TXT_COL    = Color(255, 255, 255, 240)
local TXT_SHADOW = Color(0, 0, 0, 210)
local ACCENT     = Color(207, 68, 78)          -- accent DA #cf444e
local KANJI_COL  = Color(207, 68, 78, 60)
local KANJI_SHDW = Color(0, 0, 0, 80)

-- ── Polices RESPONSIVE (recréées au changement de résolution) ────────────────
local _txtW, _txtH
local function createFonts()
	surface.CreateFont("EVOZoneBanner", {
		font = "Bebas Neue", size = math.Round(ScrH() * 0.052), weight = 400, antialias = true,
	})
	surface.CreateFont("EVOZoneBannerKanji", {
		font = "EVO Kanji", size = math.Round(ScrH() * 0.115), weight = 700, antialias = true,
	})
	_txtW, _txtH = nil, nil
end
createFonts()
hook.Add("OnScreenSizeChanged", "EVO::ZoneBanner::Refont", createFonts)

-- ── État bannière ────────────────────────────────────────────────────────────
local banner = { name = nil, kanji = "虚", t0 = 0, hold = 2.2 }
local function fire(z)
	banner.name  = z.name
	banner.kanji = z.kanji or "虚"
	banner.hold  = z.hold or 2.2
	banner.t0    = RealTime()
	_txtW, _txtH = nil, nil -- re-mesure (le libellé a changé)
end

-- ── Détection d'entrée de zone (throttle 0.2s, transition DEHORS->DEDANS) ─────
local _nextCheck = 0
local _wasInside = {}
hook.Add("Think", "EVO::ZoneBanner::Detect", function()
	local now = RealTime()
	if now < _nextCheck then return end
	_nextCheck = now + 0.2

	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end -- hub / sélection / créateur

	local map = game.GetMap()
	local p   = lp:GetPos()
	for i = 1, #ZONES do
		local z = ZONES[i]
		local inside = (not z.map or z.map == map)
			and p:DistToSqr(z.pos) <= (z.radius * z.radius)
			and (p.z - z.pos.z) >= -(z.belowTol or ZONE_BELOW_TOL) -- pas sous le sol du lieu
		if inside and not _wasInside[i] then fire(z) end
		_wasInside[i] = inside
	end
end)

-- Layout du bandeau actif (nil si rien à l'écran). Partagé par le rendu et par
-- GetBottomY : les annonces faction se calent sous le titre au lieu de passer
-- dedans (report : bandeau de division / lieu recouvre l'annonce).
local function bannerLayout()
	if not banner.name then return nil end
	local e     = RealTime() - banner.t0
	local total = FADE_IN + banner.hold + FADE_OUT
	if e >= total then return nil end

	local a
	if e < FADE_IN then
		a = e / FADE_IN
	elseif e < FADE_IN + banner.hold then
		a = 1
	else
		a = 1 - (e - FADE_IN - banner.hold) / FADE_OUT
	end
	a = math.Clamp(a, 0, 1)
	if a <= 0 then return nil end

	local scrH = ScrH()
	-- léger drift vers le haut pendant l'apparition (subtil, sans jank)
	local ty = scrH * 0.30 - (1 - a) * scrH * 0.012
	if not _txtW then
		surface.SetFont("EVOZoneBanner")
		_txtW, _txtH = surface.GetTextSize(banner.name)
	end
	local txtH = _txtH or math.Round(scrH * 0.052)
	local kanjiH = math.Round(scrH * 0.115)
	local midY = ty + txtH * 0.5
	local bottom = math.max(ty + txtH + 6, midY + kanjiH * 0.5)
	return a, ty, midY, bottom
end

-- Pixel Y sous le bandeau (0 si inactif). Lu par lzy_annonce_faction / lzy_hud.
function EVO_ZoneBanner.GetBottomY()
	local _, _, _, bottom = bannerLayout()
	return bottom or 0
end

-- ── Rendu (fade in -> hold -> fade out), centré haut-tiers ───────────────────
hook.Add("HUDPaint", "EVO::ZoneBanner::Draw", function()
	local a, ty, midY = bannerLayout()
	if not a then
		if banner.name and (RealTime() - banner.t0) >= (FADE_IN + banner.hold + FADE_OUT) then
			banner.name = nil
		end
		return
	end

	local cx = ScrW() * 0.5

	-- kanji filigrane gravé (motif #platekanji)
	draw.SimpleText(banner.kanji, "EVOZoneBannerKanji", cx + 2, midY + 2, ColorAlpha(KANJI_SHDW, KANJI_SHDW.a * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(banner.kanji, "EVOZoneBannerKanji", cx,     midY,     ColorAlpha(KANJI_COL,  KANJI_COL.a  * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	-- titre Bebas + ombre
	draw.SimpleText(banner.name, "EVOZoneBanner", cx + 2, ty + 2, ColorAlpha(TXT_SHADOW, TXT_SHADOW.a * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	draw.SimpleText(banner.name, "EVOZoneBanner", cx,     ty,     ColorAlpha(TXT_COL,    TXT_COL.a    * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	-- filet accent sous le texte
	surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 220 * a)
	surface.DrawRect(cx - _txtW * 0.5, ty + _txtH + 4, _txtW, 2)
end)

-- ── Test rapide : `evo_zone_banner_test [Nom]` (aperçu sans se déplacer) ──────
concommand.Add("evo_zone_banner_test", function(_, _, args)
	fire({ name = string.upper(args[1] or "LAS NOCHES"), kanji = "虚", hold = 2.2 })
end)
