-- "addons\\evo_map\\lua\\entities\\evo_carte_prop\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type          = "anim"
ENT.Base          = "base_gmodentity"
ENT.PrintName     = "Carte du Monde"
ENT.Author        = "Evo"
ENT.Category      = "Evo"
ENT.Spawnable     = true
ENT.AdminSpawnable = true
-- Tableau de map (skins 0/1/2 assignés par position dans sv_map_spawn.lua).
-- Modèle d'axxou (sain et monté sur CE serveur/contenu ; questboard.mdl n'y est pas).
ENT.Model         = "models/evo/props/items/evo_sd79ffzzq42f6zfdz952a/evo_sD79fFZZQ42F6Zfdz952A.mdl"
