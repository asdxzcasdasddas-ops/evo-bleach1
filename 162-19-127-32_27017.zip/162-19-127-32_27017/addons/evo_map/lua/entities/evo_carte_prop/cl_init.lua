-- "addons\\evo_map\\lua\\entities\\evo_carte_prop\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- UI flottante au-dessus du tableau : MÊME rendu que le Tableau des Quêtes
-- (ncm_quete cl_questboard.lua) — titre Bebas Neue blanc contouré en billboard
-- + hint "Appuyer sur E" quand on est proche. Remplace l'ancien prompt écran
-- (visée crosshair) pour homogénéiser les tableaux.

if gCreateRespFont then
	gCreateRespFont("EVO_Carte_TitleBig", "Bebas Neue", 26, 700)
	gCreateRespFont("EVO_Carte_Body",     "Roboto",     14, 500)
else
	surface.CreateFont("EVO_Carte_TitleBig", { font = "Bebas Neue", size = 26, weight = 700, extended = true })
	surface.CreateFont("EVO_Carte_Body",     { font = "Roboto",     size = 14, weight = 500, extended = true })
end

ENT.RenderGroup = RENDERGROUP_BOTH

local RENDER_DIST_SQR = 2000 * 2000 -- même cull que le tableau de quêtes
local HINT_DIST_SQR   = 160 * 160   -- hint "Appuyer sur E" (= 2× le radius 80 des quêtes)
local COL_LABEL   = Color(255, 255, 255, 200)
local COL_OUTLINE = Color(0, 0, 0, 200)

function ENT:Initialize() end
function ENT:Draw() self:DrawModel() end

function ENT:DrawTranslucent()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	local vPos    = self:GetPos()
	local vPlyPos = ply:GetPos()
	local d2 = vPlyPos:DistToSqr(vPos)
	if d2 > RENDER_DIST_SQR then return end

	-- Texte flottant billboard (math d'angles identique à cl_questboard.lua)
	local vTextPos = vPos + Vector(0, 0, 120)
	local dir = (EyePos() - vTextPos):Angle()
	local angBB = Angle(0, dir.y, 0)
	angBB:RotateAroundAxis(angBB:Right(), 90)
	angBB:RotateAroundAxis(angBB:Up(), -90)
	angBB:RotateAroundAxis(angBB:Right(), 180)

	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		-- Style invite partage (0.13 = meme hauteur de titre qu'avant) : touche a portee seulement.
		cam.Start3D2D(vTextPos, angBB, 0.13)
			EVO_ZonePrompt.Row(0, "Carte du Monde", d2 <= HINT_DIST_SQR and "Consulter", "E", "point")
		cam.End3D2D()
		return
	end
	cam.Start3D2D(vTextPos, angBB, 0.25)
		draw.SimpleTextOutlined(
			"Carte du Monde", "EVO_Carte_TitleBig", 0, 0,
			COL_LABEL, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
			1, COL_OUTLINE
		)
		if d2 <= HINT_DIST_SQR then
			draw.SimpleTextOutlined(
				"Appuyer sur E", "EVO_Carte_Body", 0, 35,
				color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
				1, COL_OUTLINE
			)
		end
	cam.End3D2D()
end
