-- "addons\\evo_map\\lua\\evo_carte\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CARTE — configuration PARTAGÉE + helpers réseau (encodage compact des traits).
-- ============================================================================
EVO_CARTE = EVO_CARTE or {}
local C = EVO_CARTE

-- ── Règles ──────────────────────────────────────────────────────────────────
C.ExpireSeconds  = 30 * 60   -- 30 min : la carte (et TOUTES ses copies) se détruit.
C.MinFactionRank = 7         -- "grade > 6" (demande user) -> rang faction >= 7.
C.WrittenItemId  = "evo_carte"
C.ItemPrefix     = "evo_carte_" -- legacy item_id (migration boot)
C.Icon           = "a8pi8v5e07z97o/iwjnbnd6ira9.png" -- repli 2D (hors preview 3D)
C.IconScale      = 1.3
-- Modèle 3D affiché DANS la case d'inventaire (au lieu de l'icône) via LZY_INVENTORY_ITEM_PREVIEW.
-- MÊME modèle que la "Carte de poche" (evo_pocket_map) -> les 2 items carte restent identiques.
C.Model          = "models/evo/props/items/evo_bcg35f6ehhfhehfhzfdzfcn/evo_bcg35f6ehhfhehfhzfdzfcn.mdl"
C.MaxCopies      = 20        -- nb max de copies imprimables par carte (anti-spam)
C.CreateCooldown = 3         -- secondes entre 2 créations par joueur
C.GiveRadius     = 400       -- portée du "donner au joueur visé" (unités)
C.PresentRadius  = 700       -- portée de la PRÉSENTATION LIVE (la carte s'affiche chez les proches)
C.PresentTick    = 0.1       -- fréquence d'envoi du tracé EN COURS (s) -> temps réel

-- ── Limites anti-abus (réseau + perf) ───────────────────────────────────────
C.MaxStrokes         = 60
C.MaxPointsPerStroke = 90
C.MaxTitleLen        = 40

-- ── Palette de tracé (index 1..N) ───────────────────────────────────────────
C.Palette = {
    Color(207, 68, 78),   -- 1 rouge (accent EVO)
    Color(70, 140, 230),  -- 2 bleu
    Color(90, 200, 120),  -- 3 vert
    Color(235, 200, 70),  -- 4 jaune
    Color(237, 238, 242), -- 5 blanc
    Color(18, 18, 22),    -- 6 noir
    Color(190, 110, 220), -- 7 violet
    Color(240, 150, 60),  -- 8 orange
}
C.Widths = { 2, 5, 9 }     -- épaisseurs (index 1..3)

-- ── Cartes par faction (mêmes assets que evo_map) ───────────────────────────
-- mapId -> { id, label, path }. Le 1er de la liste = carte par défaut à la création.
C.MapsByFaction = {
    ["Shinigami"] = {
        { id = "seireitei",   label = "Seireitei",      path = "m0q3cwmieqogu5/seireitei_map.png" },
        { id = "zoneneutre1", label = "Zone Neutre I",  path = "m0q3cwmieqogu5/zoneneutre1_map.png" },
        { id = "zoneneutre2", label = "Zone Neutre II", path = "m0q3cwmieqogu5/zoneneutre2_map.png" },
    },
    ["Hollow"] = {
        { id = "hueco_lasnoches",   label = "Las Noches",     path = "m0q3cwmieqogu5/hueco_lasnoches.png" },
        { id = "hueco_zoneneutre1", label = "Zone Neutre I",  path = "m0q3cwmieqogu5/hueco_zoneneutre1.png" },
        { id = "hueco_zoneneutre2", label = "Zone Neutre II", path = "m0q3cwmieqogu5/hueco_zoneneutre2.png" },
    },
}

function C.GetFactionMaps(faction)
    return C.MapsByFaction[faction]
end

-- Le mapId appartient-il bien à la faction (validation serveur) ? renvoie l'entrée ou nil.
function C.IsValidMapForFaction(faction, mapId)
    for _, m in ipairs(C.MapsByFaction[faction] or {}) do
        if m.id == mapId then return m end
    end
    return nil
end

-- Recherche d'un mapId toutes factions confondues (pour le viewer : on affiche le
-- fond avec lequel la carte a été dessinée, peu importe la faction de qui regarde).
function C.GetMapById(mapId)
    for _, list in pairs(C.MapsByFaction) do
        for _, m in ipairs(list) do
            if m.id == mapId then return m end
        end
    end
    return nil
end

-- Droit de CRÉER une carte : faction valide + grade suffisant. Revalidé serveur.
function C.CanCreate(ply)
    if not IsValid(ply) then return false end
    local fac = ply:GetEvoNWString("FactionName", "")
    if fac == "" or not C.MapsByFaction[fac] then return false end -- besoin d'une faction (= des cartes)
    if ply:IsSuperAdmin() then return true end                     -- superadmin : bypass grade (tests)
    return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= C.MinFactionRank
end

C.DocItemId = function(docId) return C.ItemPrefix .. tostring(docId) end

-- ── Sanitation des traits (commune client/serveur) ──────────────────────────
-- Force le format { {col=1..#Palette, w=1..#Widths, pts={x,y,...}} }, coords [0..1].
function C.SanitizeStrokes(strokes)
    local out = {}
    if not istable(strokes) then return out end
    local nCol, nW = #C.Palette, #C.Widths
    for _, s in ipairs(strokes) do
        if #out >= C.MaxStrokes then break end
        if istable(s) and istable(s.pts) and #s.pts >= 4 then
            local pts, src = {}, s.pts
            local np = math.min(math.floor(#src / 2), C.MaxPointsPerStroke)
            for k = 1, np do
                pts[#pts + 1] = math.Clamp(tonumber(src[(k - 1) * 2 + 1]) or 0, 0, 1)
                pts[#pts + 1] = math.Clamp(tonumber(src[(k - 1) * 2 + 2]) or 0, 0, 1)
            end
            if #pts >= 4 then
                out[#out + 1] = {
                    col = math.Clamp(math.floor(tonumber(s.col) or 1), 1, nCol),
                    w   = math.Clamp(math.floor(tonumber(s.w) or 1), 1, nW),
                    pts = pts,
                }
            end
        end
    end
    return out
end

-- ── Encodage réseau COMPACT (coords 12 bits = /4095, ~3 octets/point) ───────
function C.NetWriteStrokes(strokes)
    strokes = C.SanitizeStrokes(strokes)
    net.WriteUInt(#strokes, 8)
    for _, s in ipairs(strokes) do
        net.WriteUInt(s.col - 1, 4)
        net.WriteUInt(s.w - 1, 3)
        local np = math.floor(#s.pts / 2)
        net.WriteUInt(np, 8)
        for k = 1, np do
            net.WriteUInt(math.Clamp(math.floor(s.pts[(k - 1) * 2 + 1] * 4095), 0, 4095), 12)
            net.WriteUInt(math.Clamp(math.floor(s.pts[(k - 1) * 2 + 2] * 4095), 0, 4095), 12)
        end
    end
end

function C.NetReadStrokes()
    local out = {}
    local n = math.min(net.ReadUInt(8), C.MaxStrokes)
    for i = 1, n do
        local col = net.ReadUInt(4) + 1
        local w   = net.ReadUInt(3) + 1
        local np  = math.min(net.ReadUInt(8), C.MaxPointsPerStroke)
        local pts = {}
        for k = 1, np do
            pts[#pts + 1] = net.ReadUInt(12) / 4095
            pts[#pts + 1] = net.ReadUInt(12) / 4095
        end
        if #pts >= 4 then out[#out + 1] = { col = col, w = w, pts = pts } end
    end
    return C.SanitizeStrokes(out)
end

-- ── Encodage d'UN trait (présentation live : tracé en cours + commit) ───────
function C.NetWriteOneStroke(col, w, pts)
    net.WriteUInt(math.Clamp(math.floor((col or 1) - 1), 0, 15), 4)
    net.WriteUInt(math.Clamp(math.floor((w or 1) - 1), 0, 7), 3)
    local np = math.min(math.floor(#(pts or {}) / 2), C.MaxPointsPerStroke)
    net.WriteUInt(np, 8)
    for k = 1, np do
        net.WriteUInt(math.Clamp(math.floor((pts[(k - 1) * 2 + 1] or 0) * 4095), 0, 4095), 12)
        net.WriteUInt(math.Clamp(math.floor((pts[(k - 1) * 2 + 2] or 0) * 4095), 0, 4095), 12)
    end
end

function C.NetReadOneStroke()
    local col = math.Clamp(net.ReadUInt(4) + 1, 1, #C.Palette)
    local w   = math.Clamp(net.ReadUInt(3) + 1, 1, #C.Widths)
    local np  = math.min(net.ReadUInt(8), C.MaxPointsPerStroke)
    local pts = {}
    for k = 1, np do
        pts[#pts + 1] = net.ReadUInt(12) / 4095
        pts[#pts + 1] = net.ReadUInt(12) / 4095
    end
    return { col = col, w = w, pts = pts }
end

function C.RegisterWrittenItem()
    if not istable(ITEMS) then return false end
    ITEMS[C.WrittenItemId] = {
        name        = "Carte annotée",
        description = "Carte annotée. Clic droit > Utiliser pour la regarder. Se détruit 30 min après sa création.",
        icon        = C.Icon,
        icon_scale  = C.IconScale,
        model_path  = C.Model,
        category    = "object",
        rarity      = "legendary",
        is_droppable = true,
        is_deletable = true,
        bDocumentItem = true, -- document RP : un perso animation peut le jeter (gate inventory net.lua)
        requires_instance_key = true,
        evo_carte   = true,
        instance_name = function(key)
            local d = (CLIENT and ((C._defs and C._defs[key]) or (C.Defs and C.Defs[key]))) or (SERVER and C.Docs and C.Docs[key])
            local title = d and d.title or ""
            return "Carte : " .. (title ~= "" and title or "annotée")
        end,
        on_use = CLIENT and function(_, slot)
            local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
            local key = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
            if key and C.OpenView then C.OpenView(key) end
        end or function() end,
    }
    return true
end

-- ── Tableaux de carte du monde (props evo_carte_prop) ────────────────────────
-- Édités par evo_config_positions (cat. Tableaux). yaw uniquement ; le spawn
-- serveur snappe encore au sol + evo_carte_zoffset + zoff optionnel.
C.BoardModels = {
    ["rp_seireitei_v1"] = "models/evo/props/items/evo_sd79ffzzq42f6zfdz952a/evo_sD79fFZZQ42F6Zfdz952A.mdl",
    ["hueco_mundo_v1"]  = "models/evo/props/items/evo_spor813dhpzo942f5/evo_SPor813dHPZO942f5.mdl",
}

C.BoardSpawns = {
    ["gm_construct"] = {
        { pos = Vector(-100, -80, -143), ang = Angle(0, 90, 0), skin = 0 },
    },
    ["rp_seireitei_v1"] = {
        { pos = Vector(  -582.968750, -10945.792969,  346.052246), ang = Angle(0,    0.936230, 0), skin = 0 },
        { pos = Vector(  5624.968750, -10413.589844,  356.078400), ang = Angle(0,  174.252548, 0), skin = 1 },
        { pos = Vector( 12655.968750, -10375.152344,  343.671936), ang = Angle(0, -182.675354, 0), skin = 2 },
        { pos = Vector( -7374.968750,  -7856.480469,  420.897095), ang = Angle(0,   -1.834345, 0), skin = 0, zoff = 70 },
        { pos = Vector(    37.826187,    466.968750, 1807.630981), ang = Angle(0,  -92.482315, 0), skin = 1, zoff = -6 },
        { pos = Vector(-13712.968750,  11387.711914,  366.167511), ang = Angle(0,   -3.345543, 0), skin = 2 },
        { pos = Vector( -5015.031250,  13031.052734,  349.699402), ang = Angle(0, -179.433746, 0), skin = 0 },
        { pos = Vector(  5506.689453,  14161.968750,  368.946747), ang = Angle(0,  -92.049507, 0), skin = 1 },
        { pos = Vector(  -562.971450, -10926.294254,  438.925507), ang = Angle(0,    0.936230, 0), skin = 1, zoff = -10 },
        { pos = Vector( 12655.897777, -10368.580928,  467.468842), ang = Angle(0, -182.675354, 0), skin = 0, zoff = -10 },
    },
    ["hueco_mundo_v1"] = {
        { pos = Vector(  4309.031250,   4605.241699, 6327.642578), ang = Angle(0,   -5.004312, 0), skin = 0 },
        { pos = Vector(-10996.968750,   4548.963379, 6329.057617), ang = Angle(0,   -3.516305, 0), skin = 1 },
        { pos = Vector(-10474.968750,    -25.225372, 6335.306152), ang = Angle(0,    0.119404, 0), skin = 2 },
        { pos = Vector(  3265.031250,    342.063599, 6329.539551), ang = Angle(0,   -1.778666, 0), skin = 0 },
        { pos = Vector(-10346.313477,  -6526.986816, 6331.941406), ang = Angle(0,  140.638275, 0), skin = 1 },
        { pos = Vector(  1624.705933,  -7490.013184, 5439.005371), ang = Angle(0,    1.026028, 0), skin = 2 },
    },
}

local function mapKeywordFallback(t, map)
    if not (istable(t) and isstring(map)) then return nil end
    if t[map] then return t[map] end
    for _, kw in ipairs({ "seireitei", "hueco" }) do
        if string.find(map, kw, 1, true) then
            for k, v in pairs(t) do
                if string.find(k, kw, 1, true) then return v end
            end
        end
    end
    return nil
end

function C.BoardSpawnsFor(map)
    return mapKeywordFallback(C.BoardSpawns, map)
end

function C.BoardModelFor(map)
    return mapKeywordFallback(C.BoardModels, map)
end
