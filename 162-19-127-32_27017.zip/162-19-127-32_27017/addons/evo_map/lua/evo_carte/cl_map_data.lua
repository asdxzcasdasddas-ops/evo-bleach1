-- "addons\\evo_map\\lua\\evo_carte\\cl_map_data.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Sources 2D historiques : coordonnées conservées pour les cartes annotées et murales.
-- L’atlas 3D reprend les noms ; ses ancrages de relief sont dans cl_atlas_config.lua.
local data = {}

local WORLD_CALIB = {
	seireitei = { ax = 2.5562e-5, bx = -3.9139e-6, cx = 0.4946,
	              ay = -7.2011e-7, by = -2.9355e-5, cy = 0.4968,
	              zmin = -2500 },
	-- Las Noches (10/08) : même méthode — moindres carrés sur les 5 Ordres
	-- (spawns evo_division_spawn <-> POI "Ordre N"). Erreur max 6,1 %.
	hueco_lasnoches = { ax = 3.850928e-5, bx = -2.113656e-6, cx = 0.605734,
	                    ay = -3.568784e-7, by = -3.825103e-5, cy = 0.542366,
	                    zmin = 4200, zmax = 8000 },
	-- Zones Neutres (10/08) : moindres carrés sur les paires drapeau (CFG.FlagZones
	-- de flagcapture <-> marqueurs de la carte). hueco_zoneneutre1 ABSENTE : sa carte
	-- dessine DEUX niveaux superposés (Clairière/Lisière quasi au même pixel, 18 000u
	-- d'écart monde) — aucune affine ne peut la représenter, pas de « tu es ici ».
	zoneneutre1 = { ax = 4.463016e-5, bx = -2.455936e-6, cx = 0.377221,
	                ay = -1.170263e-6, by = -3.799687e-5, cy = 0.486969,
	                zmin = -15500, zmax = -13500 },
	zoneneutre2 = { ax = 2.984815e-5, bx = 4.578607e-7, cx = 0.406274,
	                ay = 2.243590e-6, by = -3.236438e-5, cy = 0.497273,
	                zmin = -8800, zmax = -4800 },
	hueco_zoneneutre2 = { ax = 3.181076e-5, bx = -1.805722e-7, cx = 0.486551,
	                      ay = -8.026903e-7, by = -3.664127e-5, cy = 0.524994,
	                      zmin = 8000, zmax = 10500 },
}

-- Sur quelle MAP DE SERVEUR cette carte est-elle valable ? Afficher "tu es ici" sur
-- la carte du Seireitei alors qu'on joue sur Hueco donnerait une position inventee.
local CALIB_SERVER = {
	seireitei = "rp_seireitei_v1",
	hueco_lasnoches = "hueco_mundo_v1",
	zoneneutre1 = "rp_seireitei_v1",
	zoneneutre2 = "rp_seireitei_v1",
	hueco_zoneneutre2 = "hueco_mundo_v1",
}

-- Renvoie x,y (0..1) ou nil si la carte n'est pas calibree / mauvais serveur / pos hors cadre.
local function worldToImage(mapId, pos)
	local c = WORLD_CALIB[mapId]
	if not c then return nil end
	local srv = CALIB_SERVER[mapId]
	if srv and game.GetMap() ~= srv then return nil end
	if (c.zmin and pos.z < c.zmin) or (c.zmax and pos.z > c.zmax) then return nil end
	local ix = c.ax * pos.x + c.bx * pos.y + c.cx
	local iy = c.ay * pos.x + c.by * pos.y + c.cy
	-- Hors cadre : on ne dessine pas plutot que de coller le marqueur au bord.
	if ix < -0.02 or ix > 1.02 or iy < -0.02 or iy > 1.02 then return nil end
	return math.Clamp(ix, 0, 1), math.Clamp(iy, 0, 1)
end

-- Inverse : image (0..1) -> monde (x, y). nil si non calibrée / autre serveur.
-- Sert au repère cliqué (EVO_MapPin).
local function imageToWorld(mapId, ix, iy)
	local c = WORLD_CALIB[mapId]
	if not c then return nil end
	local srv = CALIB_SERVER[mapId]
	if srv and game.GetMap() ~= srv then return nil end
	local det = c.ax * c.by - c.bx * c.ay
	if math.abs(det) < 1e-18 then return nil end
	local dx, dy = ix - c.cx, iy - c.cy
	return (c.by * dx - c.bx * dy) / det, (c.ax * dy - c.ay * dx) / det
end

-- ── Marqueurs (x,y = 0..1). kind = "poi" | "sword" | "flag" ──────────────────
-- flagId + danger : à VÉRIFIER/AJUSTER (mapping drapeau-carte <-> flagcapture).
local MARKERS = {
	seireitei = {
		{ x = 0.494, y = 0.465, name = "Division 1",            kind = "poi" },
		{ x = 0.708, y = 0.852, name = "Division 2",            kind = "poi" },
		{ x = 0.287, y = 0.769, name = "Division 4",            kind = "poi" },
		{ x = 0.072, y = 0.178, name = "Division 11",           kind = "poi" },
		{ x = 0.653, y = 0.068, name = "Division 12",           kind = "poi" },
		{ x = 0.821, y = 0.853, name = "Académie",              kind = "poi" },
		{ x = 0.712, y = 0.395, name = "Senkaimon",             kind = "poi" },
		{ x = 0.254, y = 0.289, name = "Urahara Shop",          kind = "poi" },
		{ x = 0.242, y = 0.289, name = "Chirurgien esthétique", kind = "poi" },
		{ x = 0.447, y = 0.895, name = "Coiffeur",              kind = "poi" },
		{ x = 0.407, y = 0.896, name = "Tatoueur",              kind = "poi" },
		{ x = 0.209, y = 0.628, name = "Entraînement I",        kind = "sword" },
		{ x = 0.104, y = 0.888, name = "Entraînement II",       kind = "sword" },
		{ x = 0.086, y = 0.070, name = "Entraînement III",      kind = "sword" },
		{ x = 0.863, y = 0.195, name = "Entraînement IV",       kind = "sword" },
	},
	-- `zone` = nom EXACT dans CFG.FlagZones (flagcapture) quand le libellé de la carte
	-- diffère — sert au repère cliqué (position 3D réelle du drapeau).
	zoneneutre1 = {
		{ x = 0.797, y = 0.400, name = "Place des Veilleurs", kind = "flag", flagId = 1, danger = "Faible" },
		{ x = 0.296, y = 0.806, name = "Bois du Jugement",    kind = "flag", flagId = 2, danger = "Moyen" },
		{ x = 0.290, y = 0.381, name = "Drapeau",             kind = "flag", flagId = 3, danger = "Élevée", zone = "Bois de la Cascade" },
	},
	zoneneutre2 = {
		{ x = 0.616, y = 0.791, name = "Pic du Nic",        kind = "flag", flagId = 4, danger = "Moyen", zone = "Pic des Esprits" },
		{ x = 0.583, y = 0.347, name = "Ravin des Âmes",    kind = "flag", flagId = 5, danger = "Faible" },
		{ x = 0.787, y = 0.611, name = "Gorge des Esprits", kind = "flag", flagId = 6, danger = "Élevée" },
	},

	-- ── HUECO MUNDO ──────────────────────────────────────────────────────────
	-- Carte Las Noches (POI : ordres/Espadas, salles, boutiques, entrées).
	hueco_lasnoches = {
		{ x = 0.023, y = 0.434, name = "Las Noches",             kind = "poi" },
		{ x = 0.596, y = 0.942, name = "Entrée",                 kind = "poi" },
		{ x = 0.452, y = 0.751, name = "Portes Désert",          kind = "poi" },
		{ x = 0.384, y = 0.851, name = "Salle de rassemblement", kind = "poi" },
		{ x = 0.077, y = 0.756, name = "Salle des Espadas",      kind = "poi" },
		{ x = 0.594, y = 0.424, name = "Duel de sang",           kind = "poi" },
		{ x = 0.165, y = 0.754, name = "Ordre 1",                kind = "poi" },
		{ x = 0.847, y = 0.533, name = "Ordre 2",                kind = "poi" },
		{ x = 0.140, y = 0.324, name = "Ordre 4",                kind = "poi" },
		{ x = 0.707, y = 0.327, name = "Ordre 5",                kind = "poi" }, -- ex-Ordre 11 (index 6)
		{ x = 0.175, y = 0.506, name = "Ordre 3",                kind = "poi" }, -- ex-Ordre 12 (index 4)
		{ x = 0.619, y = 0.175, name = "Tatoueur",               kind = "poi" },
		{ x = 0.630, y = 0.191, name = "Chirurgien esthétique",  kind = "poi" },
		{ x = 0.620, y = 0.207, name = "Coiffeur",               kind = "poi" },
		{ x = 0.570, y = 0.207, name = "Hollow Shop",            kind = "poi" },
	},
	-- Zone Neutre I (Hueco) : Oasis, Arène, Clairière, Lisière. flagId/danger = config flagcapture.
	hueco_zoneneutre1 = {
		{ x = 0.301, y = 0.909, name = "Oasis des Âmes Perdues",       kind = "flag", flagId = 7,  danger = "Élevée" },
		{ x = 0.870, y = 0.140, name = "Arène des Exilés",            kind = "flag", flagId = 8,  danger = "Moyen" },
		{ x = 0.871, y = 0.785, name = "Clairière des Menos Anciens", kind = "flag", flagId = 9,  danger = "Élevée" },
		{ x = 0.873, y = 0.816, name = "Lisière des Hurlements",       kind = "flag", flagId = 10, danger = "Moyen" },
	},
	-- Zone Neutre II (Hueco) : Dunes, Croisée, Falaises.
	hueco_zoneneutre2 = {
		{ x = 0.170, y = 0.833, name = "Dunes du Croissant Noir",     kind = "flag", flagId = 13, danger = "Faible" },
		{ x = 0.573, y = 0.285, name = "Croisée des Âmes",            kind = "flag", flagId = 12, danger = "Faible" },
		{ x = 0.826, y = 0.886, name = "Falaises de la Lune Blanche", kind = "flag", flagId = 11, danger = "Moyen" },
	},
}


data.markers = MARKERS
data.calibration = WORLD_CALIB
data.servers = CALIB_SERVER
data.world_to_image = worldToImage
data.image_to_world = imageToWorld
return data
