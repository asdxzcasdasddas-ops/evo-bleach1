-- "addons\\evo_map\\lua\\evo_carte\\cl_carte.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CARTE — client. Items dynamiques (reçus en broadcast), panneau de DESSIN
-- (création, gradé 7+), et VIEWER lecture seule (ouvert via "Utiliser" l'item).
-- ============================================================================
local C = EVO_CARTE

-- Échelle uniforme (proportions conservées sur tout ratio), comme le menu support.
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

local COL_BG     = Color(13, 14, 17, 250)          -- plaque métal noir (Atelier)
local COL_EDGE   = Color(146, 152, 161, 33)        -- liseré acier 1px (= inset .13 du selector)
local COL_CARD2  = Color(8, 8, 10, 255)
local COL_ACCENT = Color(207, 68, 78)
local COL_TITLE  = Color(237, 238, 242)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_BORDER = Color(255, 255, 255, 26)
local whiteMat   = Material("vgui/white")

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/OST/forge) ──
local function drawCircle(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
    drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
    drawCircle(cx, cy, r, Color(23, 25, 29, 255))
    drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = R(6), R(5)
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
        cx = cx + dw + gap
    end
end

local matCache = {}
local function getMat(path)
    if not matCache[path] then matCache[path] = Material(path, "smooth mips") end
    return matCache[path]
end

local function cnotify(msg, err)
    if MUGEN and MUGEN.Notify then MUGEN.Notify(msg, err and (NOTIFY_ERROR or 1) or (NOTIFY_GENERIC or 0), 5)
    else chat.AddText(err and COL_ACCENT or COL_TITLE, "[Carte] ", COL_TITLE, msg) end
end

local function rndx(r, x, y, w, h, col)
    -- DA v2 « Seireitei » : angles CARRÉS partout (le rayon passé est ignoré).
    if RNDX then RNDX.Draw(0, x, y, w, h, col) else draw.RoundedBox(0, x, y, w, h, col) end
end

-- Projette une image (mw×mh) au mieux dans (w×h), centrée. -> dx,dy,dw,dh.
local function fitRect(mw, mh, w, h)
    if not mw or mw <= 0 or not mh or mh <= 0 then return 0, 0, w, h end
    local sc = math.min(w / mw, h / mh)
    local dw, dh = mw * sc, mh * sc
    return math.floor((w - dw) / 2), math.floor((h - dh) / 2), dw, dh
end

-- Trait épais : segments via rect tourné + jointures carrées (rendu "feutre").
local function renderStroke(s, dx, dy, dw, dh)
    local col = C.Palette[s.col] or C.Palette[1]
    local wpx = math.max(1, (C.Widths[s.w] or 4) * dw / 1000)
    local pts, n = s.pts, math.floor(#(s.pts or {}) / 2)
    local px, py
    surface.SetDrawColor(col.r, col.g, col.b, 255)
    for k = 1, n do
        local x = dx + pts[(k - 1) * 2 + 1] * dw
        local y = dy + pts[(k - 1) * 2 + 2] * dh
        if px then
            local ddx, ddy = x - px, y - py
            local len = math.sqrt(ddx * ddx + ddy * ddy)
            if len >= 0.5 then
                surface.SetMaterial(whiteMat)
                surface.DrawTexturedRectRotated((px + x) / 2, (py + y) / 2, len, wpx, -math.deg(math.atan2(ddy, ddx)))
            end
        end
        surface.DrawRect(x - wpx / 2, y - wpx / 2, wpx, wpx) -- jointure
        px, py = x, y
    end
end

local function drawStrokes(s, dx, dy, dw, dh)
    for _, st in ipairs(s) do renderStroke(st, dx, dy, dw, dh) end
end

-- Marqueurs DÉJÀ présents sur la carte du monde (divisions, drapeaux, POI…),
-- réutilisés depuis evo_map pour qu'ils restent visibles sous le dessin.
local function drawMarkers(mapId, dx, dy, dw, dh)
    if not (EVO_Map_GetMarkers and EVO_Map_DrawMarker) then return end
    for _, m in ipairs(EVO_Map_GetMarkers(mapId)) do
        if m.x and m.y then EVO_Map_DrawMarker(m, dx + m.x * dw, dy + m.y * dh, false) end
    end
end

-- Polices : display en Bebas Neue SANS bold (DA Atelier), Roboto conservée
-- pour la saisie / le texte courant (lisible en bas-de-casse).
local function MakeCarteFonts()
    local sz = function(n) return (gRespY and gRespY(n)) or n end
    surface.CreateFont("EVO_Carte_H",     { font = "Bebas Neue", size = sz(32), weight = 400, antialias = true, extended = true })
    surface.CreateFont("EVO_Carte_Btn",   { font = "Bebas Neue", size = sz(22), weight = 400, antialias = true, extended = true })
    surface.CreateFont("EVO_Carte_Lbl",   { font = "Roboto", size = sz(17), weight = 500, antialias = true, extended = true })
    surface.CreateFont("EVO_Carte_Small", { font = "Roboto", size = sz(15), weight = 500, antialias = true, extended = true })
end
MakeCarteFonts()
hook.Add("Initialize", "EVO_Carte_Fonts", MakeCarteFonts)
hook.Add("OnScreenSizeChanged", "EVO_Carte_Fonts2", MakeCarteFonts)

-- ── Petits widgets ──────────────────────────────────────────────────────────
local function StyledButton(parent, label, x, y, w, h, filled, fClick)
    local b = vgui.Create("DButton", parent)
    b:SetText("") b:SetPos(R(x), R(y)) b:SetSize(R(w), R(h))
    b.Paint = function(s, bw, bh)
        local hov = s:IsHovered()
        if filled then
            rndx(R(8), 0, 0, bw, bh, ColorAlpha(COL_ACCENT, hov and 255 or 225))
            draw.SimpleText(label, "EVO_Carte_Btn", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            rndx(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 16 or 8))
            draw.SimpleText(label, "EVO_Carte_Btn", bw / 2, bh / 2, hov and COL_TITLE or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    b.DoClick = fClick
    return b
end

local function CloseBtn(parent, x, y, fClick)
    -- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
    local b = vgui.Create("DButton", parent)
    b:SetText("") b:SetPos(R(x), R(y)) b:SetSize(R(32), R(32))
    b:SetCursor("hand")
    b.Paint = function(s, w, h)
        draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = fClick
    return b
end

-- Fenêtre plein écran + carte centrée (backdrop flouté). Renvoie frame, card.
local function MakeWindow(cardW, cardH, headerTxt)
    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
    frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
    frame:SetPaintBackgroundEnabled(false)
    frame:MakePopup()
    local prevOpened = openedFrame
    openedFrame = frame
    frame.OnRemove = function() if openedFrame == frame then openedFrame = (IsValid(prevOpened) and prevOpened) or nil end end
    if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
    frame._a = 0
    frame.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
    frame.Paint = function(s, w, h)
        local a = s._a / 255
        -- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
        if RNDX and RNDX.Draw and RNDX.BLUR then
            RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
        elseif EVO_UI and EVO_UI.DrawBlur then
            EVO_UI.DrawBlur(s, 5)
        end
        surface.SetDrawColor(5, 5, 7, 216 * a) surface.DrawRect(0, 0, w, h)
    end
    frame.OnMousePressed = function() end

    local card = vgui.Create("DPanel", frame)
    card:SetSize(R(cardW), R(cardH))
    card:SetPos((ScrW() - R(cardW)) / 2, (ScrH() - R(cardH)) / 2)
    card.Paint = function(s, w, h)
        -- Plaque de métal noir Atelier : coins coupés 45° + liseré acier,
        -- SANS image (demande user 06/07), kanji 界 gravé clair.
        local cut = R(16)
        -- DA dashboard 08/07 : plaque plate, plus de lisere acier.
        EVO_UI.PaintCut(0, 0, w, h, COL_BG, cut)
        draw.SimpleText("界", "EVO_UI_KanjiXL", w - R(8), h - R(2),
            Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)

        -- 4 vis d'angle (TR/BL décalées : coins coupés).
        local sr = R(5)
        drawScrew(R(18), R(18), sr)
        drawScrew(w - R(18), R(18), sr)
        drawScrew(w - R(18), h - R(18), sr)
        drawScrew(R(18), h - R(18), sr)

        -- Titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
        draw.SimpleText(headerTxt, "EVO_Carte_H", R(22), R(31), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        surface.SetFont("EVO_Carte_H")
        local twT, thT = surface.GetTextSize(headerTxt)
        -- Titre CENTER-aligné vertical à Y=R(31) : haut = R(31) - thT/2 ; slash à haut + thT*0.78 (= R(31) + thT*0.28), réf. BOUTIQUE.
        if not EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(31) + thT * 0.28, twT * 1.15, R(9), ColorAlpha(COL_ACCENT, 245)) then
            surface.SetDrawColor(COL_ACCENT)
            surface.DrawRect(R(22), R(31) + thT * 0.34, twT, math.max(2, R(3)))
        end
        drawDashes(R(20), R(60), w - R(40), Color(255, 255, 255, 26))
    end
    return frame, card
end

-- ════════════════════════════════════════════════════════════════════════════
-- CRÉATION / DESSIN
-- ════════════════════════════════════════════════════════════════════════════
function C.OpenCreator(startId)
    local lp = LocalPlayer()
    if not C.CanCreate(lp) then cnotify("Réservé aux gradés (grade " .. C.MinFactionRank .. "+) d'une faction.", true) return end
    if not (lp:GetEvoNWBool("EvoPocketMap", false) or lp:IsSuperAdmin()) then cnotify("Carte de poche requise (achète-la et utilise-la).", true) return end
    local maps = C.GetFactionMaps(lp:GetEvoNWString("FactionName", ""))
    if not maps or #maps == 0 then cnotify("Aucune carte disponible pour ta faction.", true) return end
    if IsValid(C._win) then C._win:Remove() end

    local CARD_W, CARD_H, PAD = 1180, 870, 20
    local frame, card = MakeWindow(CARD_W, CARD_H, "CRÉER UNE CARTE")
    C._win = frame

    -- Pré-sélectionne la région passée (= celle affichée dans la carte du monde).
    local startIdx = 1
    if startId then for i, m in ipairs(maps) do if m.id == startId then startIdx = i break end end end
    local state = { col = 1, w = 2, mapIdx = startIdx, present = false, lastCur = 0 }

    -- Le serveur peut ARRÊTER DE FORCE la présentation (mort/rétrogradation/refus de start) :
    -- il envoie PresentEnded -> on remet le bouton en non-présent (sinon "● EN COURS" fantôme
    -- qui dessine dans le vide). Enregistre le reset tant que l'éditeur est ouvert.
    C._onPresentEnded = function() state.present = false end

    -- Fermer le panneau en pleine présentation -> on arrête proprement le flux.
    local baseRemove = frame.OnRemove
    frame.OnRemove = function(s)
        if state.present then net.Start("EVO:Carte:PresentStop") net.SendToServer() state.present = false end
        C._onPresentEnded = nil
        if baseRemove then baseRemove(s) end
    end

    -- Titre (saisie)
    local title = vgui.Create("DTextEntry", card)
    title:SetPos(R(330), R(18)) title:SetSize(R(330), R(28))
    title:SetFont("EVO_Carte_Lbl") title:SetDrawLanguageID(false) title:SetUpdateOnType(true)
    title:SetPlaceholderText("Titre de la carte (ex : Plan d'assaut)")
    title.Paint = function(s, w, h)
        rndx(R(7), 0, 0, w, h, COL_CARD2)
        s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
        if s:GetValue() == "" then draw.SimpleText(s:GetPlaceholderText() or "", "EVO_Carte_Lbl", R(8), h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
    end

    -- Sélecteur de région (boutons)
    local regX = 680
    for i, m in ipairs(maps) do
        local bx = regX + (i - 1) * 130
        local b = vgui.Create("DButton", card)
        b:SetText("") b:SetPos(R(bx), R(18)) b:SetSize(R(124), R(28))
        b.Paint = function(s, w, h)
            local on = state.mapIdx == i
            rndx(R(7), 0, 0, w, h, on and ColorAlpha(COL_ACCENT, 230) or ColorAlpha(color_white, s:IsHovered() and 14 or 7))
            draw.SimpleText(m.label, "EVO_Carte_Lbl", w / 2, h / 2, on and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function()
            if state.present then cnotify("Arrête la présentation pour changer de région.", true) return end
            state.mapIdx = i
        end
    end

    CloseBtn(card, CARD_W - 42, 16, function() frame:Remove() end)

    -- Zone de dessin
    local mapY = 70
    local mapH = CARD_H - mapY - 78
    local mapP = vgui.Create("DPanel", card)
    mapP:SetPos(R(PAD), R(mapY)) mapP:SetSize(R(CARD_W - PAD * 2), R(mapH))
    mapP:SetMouseInputEnabled(true)
    mapP._strokes = {}
    mapP._cur = nil
    mapP._drawing = false

    local function toImg(lx, ly)
        local f = mapP._fit
        if not f then return 0, 0, false end
        local ix, iy = (lx - f[1]) / f[3], (ly - f[2]) / f[4]
        return math.Clamp(ix, 0, 1), math.Clamp(iy, 0, 1), (ix >= 0 and ix <= 1 and iy >= 0 and iy <= 1)
    end
    -- Présentation live : envoi du trait EN COURS / TERMINÉ / resynchro complète.
    local function sendCur(st) net.Start("EVO:Carte:PresentCur") C.NetWriteOneStroke(st.col, st.w, st.pts) net.SendToServer() end
    local function sendCommit(st) net.Start("EVO:Carte:PresentCommit") C.NetWriteOneStroke(st.col, st.w, st.pts) net.SendToServer() end
    local function resyncAll()
        net.Start("EVO:Carte:PresentClear") net.SendToServer()
        for _, st in ipairs(mapP._strokes) do sendCommit(st) end
    end

    local function finalize()
        local cur = mapP._cur
        mapP._cur = nil mapP._drawing = false
        if cur and #cur.pts >= 4 then
            mapP._strokes[#mapP._strokes + 1] = cur
            if state.present then sendCommit(cur) end -- commit -> viewers : push + efface le current
        elseif state.present then
            -- trait trop court (clic sans glisser) : efface le "current" résiduel chez les viewers
            net.Start("EVO:Carte:PresentCur") C.NetWriteOneStroke(1, 1, {}) net.SendToServer()
        end
    end

    mapP.Paint = function(s, w, h)
        rndx(R(8), 0, 0, w, h, COL_CARD2)
        local m = maps[state.mapIdx]
        local mat = getMat(m.path)
        local dx, dy, dw, dh = fitRect(mat:Width(), mat:Height(), w, h)
        s._fit = { dx, dy, dw, dh }
        surface.SetDrawColor(255, 255, 255, 255) surface.SetMaterial(mat) surface.DrawTexturedRect(dx, dy, dw, dh)
        drawMarkers(m.id, dx, dy, dw, dh)
        drawStrokes(s._strokes, dx, dy, dw, dh)
        if s._cur then renderStroke(s._cur, dx, dy, dw, dh) end
    end
    mapP.OnMousePressed = function(s, code)
        if code ~= MOUSE_LEFT then return end
        local x, y = s:CursorPos()
        local ix, iy, inside = toImg(x, y)
        if not inside then return end
        if #s._strokes >= C.MaxStrokes then cnotify("Limite de traits atteinte. Efface pour continuer.", true) return end
        s._cur = { col = state.col, w = state.w, pts = { ix, iy } }
        s._drawing = true
        s:MouseCapture(true) -- garde les events de déplacement même si le curseur sort un instant
    end
    mapP.OnCursorMoved = function(s, x, y)
        if not s._drawing or not s._cur then return end
        local ix, iy = toImg(x, y)
        local pts = s._cur.pts
        local lx, ly = pts[#pts - 1], pts[#pts]
        if lx then
            local a, b = ix - lx, iy - ly
            if (a * a + b * b) < (0.004 * 0.004) then return end -- min distance (lissage)
        end
        if #pts / 2 >= C.MaxPointsPerStroke then
            finalize()
            if #s._strokes < C.MaxStrokes then
                s._cur = { col = state.col, w = state.w, pts = { lx or ix, ly or iy, ix, iy } }
                s._drawing = true
            end
            return
        end
        pts[#pts + 1] = ix pts[#pts + 1] = iy
    end
    mapP.OnMouseReleased = function(s, code) if code == MOUSE_LEFT then finalize() s:MouseCapture(false) end end
    -- Streaming ~10 Hz du trait EN COURS pendant une présentation (temps réel).
    mapP.Think = function(s)
        if not state.present or not (s._drawing and s._cur) then return end
        if CurTime() < (state.lastCur or 0) then return end
        state.lastCur = CurTime() + C.PresentTick
        -- Rejeu du trait en direct : la répétition EST la fonctionnalité, plafonnée à
        -- 1/C.PresentTick et uniquement pendant une présentation, en cours de tracé.
        -- netgate: stream
        sendCur(s._cur)
    end

    -- ── Barre d'outils ──
    local toolY = CARD_H - 62
    -- Palette
    for i, col in ipairs(C.Palette) do
        local sw = vgui.Create("DButton", card)
        sw:SetText("") sw:SetPos(R(PAD + (i - 1) * 38), R(toolY)) sw:SetSize(R(32), R(32))
        sw.Paint = function(s, w, h)
            rndx(R(6), 0, 0, w, h, col)
            if state.col == i then surface.SetDrawColor(255, 255, 255, 255) surface.DrawOutlinedRect(0, 0, w, h, R(2)) end
        end
        sw.DoClick = function() state.col = i end
    end
    -- Épaisseurs
    local wX = PAD + #C.Palette * 38 + 12
    for i = 1, #C.Widths do
        local b = vgui.Create("DButton", card)
        b:SetText("") b:SetPos(R(wX + (i - 1) * 38), R(toolY)) b:SetSize(R(32), R(32))
        b.Paint = function(s, w, h)
            local on = state.w == i
            rndx(R(6), 0, 0, w, h, ColorAlpha(color_white, on and 22 or (s:IsHovered() and 14 or 7)))
            local d = C.Widths[i]
            surface.SetDrawColor(on and COL_ACCENT.r or 230, on and COL_ACCENT.g or 230, on and COL_ACCENT.b or 230, 255)
            draw.NoTexture()
            surface.DrawRect(w / 2 - R(d) / 2, h / 2 - R(d) / 2, R(d), R(d))
        end
        b.DoClick = function() state.w = i end
    end
    -- Undo / Effacer
    local uX = wX + #C.Widths * 38 + 12
    StyledButton(card, "Annuler", uX, toolY, 86, 32, false, function()
        if #mapP._strokes > 0 then mapP._strokes[#mapP._strokes] = nil end
        if state.present then resyncAll() end
    end)
    StyledButton(card, "Effacer", uX + 94, toolY, 86, 32, false, function()
        mapP._strokes = {} mapP._cur = nil
        if state.present then net.Start("EVO:Carte:PresentClear") net.SendToServer() end
    end)

    -- Présenter (live) : invite les joueurs autour (popup) + stream temps réel.
    local presentBtn = vgui.Create("DButton", card)
    presentBtn:SetText("") presentBtn:SetPos(R(uX + 192), R(toolY)) presentBtn:SetSize(R(150), R(32))
    presentBtn.Paint = function(s, w, h)
        local on = state.present
        rndx(R(8), 0, 0, w, h, on and ColorAlpha(Color(90, 200, 120), 235) or ColorAlpha(color_white, s:IsHovered() and 16 or 8))
        draw.SimpleText(on and "● EN COURS" or "Présenter (live)", "EVO_Carte_Btn", w / 2, h / 2, on and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    presentBtn.DoClick = function()
        if state.present then
            state.present = false
            net.Start("EVO:Carte:PresentStop") net.SendToServer()
        else
            state.present = true
            net.Start("EVO:Carte:PresentStart") net.WriteString(maps[state.mapIdx].id) net.SendToServer()
            for _, st in ipairs(mapP._strokes) do sendCommit(st) end -- envoie l'état déjà dessiné
        end
    end

    -- Re-présenter : relance le popup d'invitation aux joueurs autour (arrivants + refus).
    local repBtn = vgui.Create("DButton", card)
    repBtn:SetText("") repBtn:SetPos(R(uX + 350), R(toolY)) repBtn:SetSize(R(126), R(32))
    repBtn.Paint = function(s, w, h)
        local on = state.present
        rndx(R(8), 0, 0, w, h, ColorAlpha(color_white, on and (s:IsHovered() and 16 or 8) or 5))
        draw.SimpleText("↻ Relancer", "EVO_Carte_Btn", w / 2, h / 2, on and (s:IsHovered() and COL_TITLE or COL_MUTED) or ColorAlpha(COL_DIM, 110), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    repBtn.DoClick = function()
        if not state.present then return end
        net.Start("EVO:Carte:PresentRepresent") net.SendToServer()
        cnotify("Invitation renvoyée aux joueurs autour.")
    end

    -- Imprimer
    StyledButton(card, "Imprimer la carte", CARD_W - PAD - 220, toolY, 220, 32, true, function()
        if #mapP._strokes == 0 then cnotify("Dessine quelque chose avant d'imprimer.", true) return end
        net.Start("EVO:Carte:Create")
        net.WriteString(string.sub(title:GetValue() or "", 1, C.MaxTitleLen))
        net.WriteString(maps[state.mapIdx].id)
        C.NetWriteStrokes(mapP._strokes)
        net.SendToServer()
        frame:Remove()
    end)
end

concommand.Add("evo_carte_create", function() C.OpenCreator() end)

-- ════════════════════════════════════════════════════════════════════════════
-- VIEWER (lecture seule)
-- ════════════════════════════════════════════════════════════════════════════
function C.OpenView(docId)
    if docId and not (C._defs and C._defs[docId]) then
        net.Start("EVO:Carte:RequestDefs")
        net.SendToServer()
    end
    C._pendingView = docId
    net.Start("EVO:Carte:RequestStrokes") net.WriteString(docId) net.SendToServer()
end

local function ShowView(v)
    if IsValid(C._view) then C._view:Remove() end
    local CARD_W, CARD_H, PAD = 1180, 870, 20
    local frame, card = MakeWindow(CARD_W, CARD_H, "CARTE")
    C._view = frame

    -- Carte d'inventaire qu'on t'a donnée : carte en main + MÊME anim de lecture que
    -- « gestion faction » (cf. EVO_MapHold). On CHAÎNE le OnRemove de MakeWindow.
    local baseRemove = frame.OnRemove
    frame.OnRemove = function(s)
        if baseRemove then baseRemove(s) end
        if EVO_MapHold then EVO_MapHold.Stop() end
    end
    if EVO_MapHold then EVO_MapHold.Start(frame) end

    local m = C.GetMapById(v.mapId)
    local expireAt = CurTime() + (v.remain or 0)
    local isOwner = v.ownerSid ~= "" and v.ownerSid == LocalPlayer():SteamID64()

    -- En-tête : titre + auteur + compte à rebours
    card.PaintOver = function(s, w, h)
        draw.SimpleText("« " .. (v.title ~= "" and v.title or "Sans titre") .. " »", "EVO_Carte_Btn", R(330), R(31), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("par " .. (v.ownerName or "?"), "EVO_Carte_Lbl", R(640), R(31), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        local left = math.max(0, expireAt - CurTime())
        local mm, ss = math.floor(left / 60), math.floor(left % 60)
        draw.SimpleText(string.format("se détruit dans %d:%02d", mm, ss), "EVO_Carte_Lbl", w - R(60), R(31), left < 60 and COL_ACCENT or COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    -- Auto-fermeture quand la carte expire (dans Think, JAMAIS dans un Paint).
    card.Think = function() if (expireAt - CurTime()) <= 0 and IsValid(frame) then frame:Remove() end end

    CloseBtn(card, CARD_W - 42, 16, function() frame:Remove() end)

    local mapY = 70
    local mapH = CARD_H - mapY - (isOwner and 78 or 28)
    local mapP = vgui.Create("DPanel", card)
    mapP:SetPos(R(PAD), R(mapY)) mapP:SetSize(R(CARD_W - PAD * 2), R(mapH))
    mapP.Paint = function(s, w, h)
        rndx(R(8), 0, 0, w, h, COL_CARD2)
        if not m then
            draw.SimpleText("Fond de carte introuvable.", "EVO_Carte_Lbl", w / 2, h / 2, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            local mat = getMat(m.path)
            local dx, dy, dw, dh = fitRect(mat:Width(), mat:Height(), w, h)
            surface.SetDrawColor(255, 255, 255, 255) surface.SetMaterial(mat) surface.DrawTexturedRect(dx, dy, dw, dh)
            drawMarkers(v.mapId, dx, dy, dw, dh)
            drawStrokes(v.strokes or {}, dx, dy, dw, dh)
        end
    end

    -- Actions du créateur : imprimer une copie / donner au plus proche
    if isOwner then
        local by = CARD_H - 62
        StyledButton(card, "Imprimer une copie", PAD, by, 220, 32, false, function()
            net.Start("EVO:Carte:PrintCopy") net.WriteString(v.id) net.SendToServer()
        end)
        StyledButton(card, "Donner (joueur le plus proche)", PAD + 232, by, 280, 32, true, function()
            net.Start("EVO:Carte:GiveNearby") net.WriteString(v.id) net.SendToServer()
        end)
        draw.SimpleText(" ", "EVO_Carte_Lbl", 0, 0, color_white) -- no-op
    end
end

net.Receive("EVO:Carte:Strokes", function()
    local id = net.ReadString()
    local ok = net.ReadBool()
    if not ok then
        if C._pendingView == id then C._pendingView = nil end
        cnotify("Cette carte n'est plus disponible (expirée).", true)
        return
    end
    local v = {
        id = id, title = net.ReadString(), ownerName = net.ReadString(), ownerSid = net.ReadString(),
        mapId = net.ReadString(), remain = net.ReadUInt(16),
    }
    v.strokes = C.NetReadStrokes()
    if C._pendingView == id then C._pendingView = nil end
    ShowView(v)
end)

-- ════════════════════════════════════════════════════════════════════════════
-- ITEMS DYNAMIQUES (reçus en broadcast) -> injectés dans la table ITEMS du sac
-- ════════════════════════════════════════════════════════════════════════════
C._defs = C._defs or {}

local function installDef(d)
    C._defs[d.id] = d
end
local function removeDef(id)
    C._defs[id] = nil
end
local function readDef()
    return {
        id = net.ReadString(), title = net.ReadString(), ownerName = net.ReadString(),
        ownerSid = net.ReadString(), mapId = net.ReadString(), faction = net.ReadString(),
        createdAt = net.ReadUInt(32),
    }
end

net.Receive("EVO:Carte:DefAdd", function() installDef(readDef()) end)
net.Receive("EVO:Carte:DefRemove", function() removeDef(net.ReadString()) end)
net.Receive("EVO:Carte:DefAll", function()
    local n = net.ReadUInt(16)
    for _ = 1, n do installDef(readDef()) end
end)

timer.Create("EVO_Carte::EnsureItemsCL", 2, 0, function()
    if istable(ITEMS) then C.RegisterWrittenItem() end
end)
C.RegisterWrittenItem()

-- ════════════════════════════════════════════════════════════════════════════
-- VIEWER LIVE — overlay NON-BLOQUANT (HUDPaint) chez les joueurs autour du
-- présentateur : la carte + ce qu'il dessine s'affichent automatiquement, en
-- temps réel. Apparaît sur PresentOpen, disparaît sur PresentClose (hors zone / arrêt).
-- ════════════════════════════════════════════════════════════════════════════
-- Le client ne regarde qu'UNE présentation à la fois (C._watch.presenterSid). On
-- n'applique que les maj du présentateur regardé (robuste au chevauchement).
net.Receive("EVO:Carte:PresentOpen", function()
    local sid = net.ReadString()
    local name = net.ReadString()
    local mapId = net.ReadString()
    local committed = C.NetReadStrokes()
    -- Bascule CONFIRMÉE seulement ici : on ne quitte l'ancienne présentation qu'à la réception
    -- de PresentOpen(B). Si l'accept de B avait échoué serveur, on serait resté sur A (pas de
    -- perte de session). Cf. fix du dead-end de bascule.
    if C._watch and C._watch.presenterSid and C._watch.presenterSid ~= sid then
        net.Start("EVO:Carte:PresentLeave") net.WriteString(C._watch.presenterSid) net.SendToServer()
    end
    C._watch = { presenterSid = sid, name = name, mapId = mapId, committed = committed, current = nil }
end)
net.Receive("EVO:Carte:PresentCur", function()
    local sid = net.ReadString()
    if not (C._watch and C._watch.presenterSid == sid) then return end
    C._watch.current = C.NetReadOneStroke()
end)
net.Receive("EVO:Carte:PresentCommit", function()
    local sid = net.ReadString()
    if not (C._watch and C._watch.presenterSid == sid) then return end
    local st = C.NetReadOneStroke()
    C._watch.committed = C._watch.committed or {}
    -- Gate >=4 points : ignore les traits vides (forge) -> pas de saturation du plafond MaxStrokes.
    if #st.pts >= 4 and #C._watch.committed < C.MaxStrokes then C._watch.committed[#C._watch.committed + 1] = st end
    C._watch.current = nil
end)
net.Receive("EVO:Carte:PresentClear", function()
    local sid = net.ReadString()
    if C._watch and C._watch.presenterSid == sid then C._watch.committed = {} C._watch.current = nil end
end)
net.Receive("EVO:Carte:PresentClose", function()
    local sid = net.ReadString()
    if C._watch and C._watch.presenterSid == sid then C._watch = nil end
end)
-- Le serveur a ARRÊTÉ DE FORCE notre présentation (mort/rétrogradation/refus de start) :
-- resync le bouton "Présenter" du créateur (sinon faux "● EN COURS").
net.Receive("EVO:Carte:PresentEnded", function()
    if C._onPresentEnded then C._onPresentEnded() end
end)

-- ── Invitation à regarder (popup oui/non, via lzy_popup) ────────────────────
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
C._pendingInvites = C._pendingInvites or {}
LZY_POPUP_CALLBACKS["EVO_Carte_AcceptWatch"] = function(args)
    if not (args and args.sid) then return end
    C._pendingInvites[args.sid] = nil
    -- NE PAS quitter l'ancienne présentation ni vider C._watch ici : optimiste = perte de
    -- session si l'accept est refusé serveur (hors-zone/stoppé). On garde l'ancienne ; le
    -- switch se fait à la réception de PresentOpen (cf. fix dead-end de bascule).
    net.Start("EVO:Carte:PresentAccept") net.WriteString(args.sid) net.SendToServer()
end
LZY_POPUP_CALLBACKS["EVO_Carte_DeclineWatch"] = function(args)
    if args and args.sid then C._pendingInvites[args.sid] = nil end -- réinvité seulement via "Relancer"
end

net.Receive("EVO:Carte:PresentInvite", function()
    local sid = net.ReadString()
    local name = net.ReadString()
    local _mapId = net.ReadString()
    if C._watch and C._watch.presenterSid == sid then return end -- on la regarde déjà
    -- Dédup : ignore si un popup pour CE présentateur est déjà en attente (auto-expire en 12s
    -- au cas où il serait fermé par Échap sans callback -> évite de bloquer un futur invite).
    if (C._pendingInvites[sid] or 0) > CurTime() then return end
    C._pendingInvites[sid] = CurTime() + 12
    local lp = LocalPlayer()
    if not (IsValid(lp) and lp.OpenYesNoPopup) then return end
    local msg = (C._watch and (name .. " présente aussi une carte. Basculer vers la sienne ?"))
        or (name .. " présente une carte. La regarder ?")
    lp:OpenYesNoPopup(msg, "EVO_Carte_AcceptWatch", { sid = sid }, "EVO_Carte_DeclineWatch")
end)

-- Échap pour FERMER l'overlay live (le spectateur quitte la présentation). L'overlay est
-- un HUDPaint (pas un VGUI), donc on intercepte OnPauseMenuShow comme le reste du projet :
-- on prévient le serveur qu'on quitte, on ferme l'overlay, et on BLOQUE le menu pause.
hook.Add("OnPauseMenuShow", "EVO_Carte::WatchEscClose", function()
    if not C._watch then return end
    if C._watch.presenterSid then
        net.Start("EVO:Carte:PresentLeave") net.WriteString(C._watch.presenterSid) net.SendToServer()
    end
    C._watch = nil
    return false
end)

hook.Add("HUDPaint", "EVO_Carte::PresentOverlay", function()
    local wch = C._watch
    if not wch then return end
    local m = C.GetMapById(wch.mapId)
    local ow = math.floor(ScrW() * 0.42)
    local headH = R(34)
    local aspect = 0.62
    if m then local mat = getMat(m.path) if mat:Width() > 0 then aspect = mat:Height() / mat:Width() end end
    local mapAreaW = ow - R(16)
    local mapAreaH = math.floor(mapAreaW * aspect)
    local oh = headH + mapAreaH + R(12)
    local ox = math.floor((ScrW() - ow) / 2)
    local oy = R(58)

    rndx(R(10), ox, oy, ow, oh, ColorAlpha(COL_BG, 235))
    surface.SetDrawColor(COL_ACCENT) surface.DrawRect(ox + R(14), oy + R(11), R(3), R(13))
    draw.SimpleText((wch.name or "?") .. " présente une carte", "EVO_Carte_Btn", ox + R(26), oy + R(9), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

    local mx, my = ox + R(8), oy + headH
    if m then
        local mat = getMat(m.path)
        local dx, dy, dw, dh = fitRect(mat:Width(), mat:Height(), mapAreaW, mapAreaH)
        dx, dy = mx + dx, my + dy
        surface.SetDrawColor(255, 255, 255, 255) surface.SetMaterial(mat) surface.DrawTexturedRect(dx, dy, dw, dh)
        drawMarkers(wch.mapId, dx, dy, dw, dh)
        drawStrokes(wch.committed or {}, dx, dy, dw, dh)
        if wch.current then renderStroke(wch.current, dx, dy, dw, dh) end
    else
        draw.SimpleText("Carte indisponible", "EVO_Carte_Lbl", ox + ow / 2, my + mapAreaH / 2, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)
