-- "addons\\evo_map\\lua\\evo_carte\\cl_atlas_scene.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Scène isolée : un seul ClientsideModel, rendu uniquement pendant l'ouverture.
-- Le modèle est ramené à 200 unités pour éviter les near/far planes liés à l'export.
return function(atlas)
    local PANEL = {}
    local clamp, exp, rad, tan = math.Clamp, math.exp, math.rad, math.tan
    local min, max, abs = math.min, math.max, math.abs
    local ipairs, is_valid = ipairs, IsValid
    local WHITE = Color(225, 235, 239)
    local MUTED = Color(137, 156, 168)
    local UP = Vector(0, 0, 1)
    local FOV = 40
    -- Matériaux propres : aucune atténuation sRGB du matériau smokegrenade.
    local CLOUDS = {}
    for i, texture in ipairs({ "0001", "0133", "0265" }) do
        CLOUDS[i] = CreateMaterial("evo_atlas_cloud_v2_" .. i, "UnlitGeneric", {
            ["$basetexture"] = "particle/smokesprites" .. texture,
            ["$vertexcolor"] = "1", ["$vertexalpha"] = "1",
            ["$translucent"] = "1", ["$nocull"] = "1",
        })
    end
    local BEAM = Material("sprites/physbeam")
    local sin, cos = math.sin, math.cos
    local WATER = CreateMaterial("evo_atlas_water_color_v1", "UnlitGeneric", {
        ["$basetexture"] = "color/white", ["$vertexcolor"] = "1",
        ["$vertexalpha"] = "1", ["$translucent"] = "1", ["$nocull"] = "1",
    })

    function PANEL:Init()
        self:SetMouseInputEnabled(true)
        self:SetKeyboardInputEnabled(false)
        self:SetCursor("sizeall")
        self.points = {}
        self.projected = {}
        self.motes = nil
        self.clouds = {}
        self.target = Vector(0, 0, 0)
        self.look = Vector(0, 0, 0)
        self.yaw, self.pitch = -65, 50
        self.goal_yaw, self.goal_pitch = self.yaw, self.pitch
        self.distance, self.goal_distance = 380, 380
        self.labels = true
    end

    function PANEL:ReleaseModel()
        if self.water_mesh then self.water_mesh:Destroy() end
        self.water_mesh, self.water_glints = nil, nil
        if is_valid(self.entity) then self.entity:Remove() end
        self.entity = nil
        self.meshes = nil
        self.motes, self.clouds = nil, {}
        self.projected = {}
    end

    function PANEL:OnRemove()
        self:MouseCapture(false)
        self:ReleaseModel()
    end

    function PANEL:LoadRegion(region)
        self:ReleaseModel()
        self.region = region
        self.palette = atlas.config.palettes[region.id] or atlas.config.palettes.seireitei
        self.points = {}
        self.selected, self.hovered = nil, nil
        self.player_pos, self.player_ahead = nil, nil
        self.drag = nil
        self:MouseCapture(false)
        self.missing = nil
        self.model_angle = region.model_angle or angle_zero
        self.floor_id = "all"
        self.body_value = 0
        self.mins, self.maxs = Vector(-100, -100, 0), Vector(100, 100, 30)
        self.center, self.model_scale = Vector(0, 0, 15), 1
        -- Ne jamais faire apparaître un modèle ERROR au milieu de l'atlas.
        if not file.Exists(region.model, "GAME") then
            self.missing = "Le relief de cette région n'est pas installé."
        else
            self.entity = ClientsideModel(region.model, RENDERGROUP_OTHER)
            if is_valid(self.entity) then
                self.entity:SetNoDraw(true)
                self.entity:DrawShadow(false)
                self.entity:SetAngles(self.model_angle)
                self.mins, self.maxs = self.entity:GetRenderBounds()
                self.center = (self.mins + self.maxs) * 0.5
                local size = self.maxs - self.mins
                self.model_scale = 200 / max(size.x, size.y, size.z, 1)
                self.entity:SetModelScale(self.model_scale, 0)
                local offset = -self.center * self.model_scale
                offset:Rotate(self.model_angle)
                self.entity:SetPos(offset)
                self.entity:SetupBones()
            else
                self.missing = "Le relief n'a pas pu être chargé."
            end
        end
        self:SetFloor("all")
        self:BuildClouds()
        self:BuildAtmosphere()
        self:BuildWater()
        self:ResetView(true)
        self:SetAlpha(0)
        self:AlphaTo(255, 0.28, 0)
    end

    -- Amas répartis dans une bande extérieure, sans rangées ni hauteurs fixes.
    -- Générateur local stable : ne modifie pas math.random du reste du jeu.
    function PANEL:BuildClouds()
        self.clouds = {}
        local half = (self.maxs - self.mins) * (self.model_scale * 0.5)
        local mist = self.palette.mist
        local seed = 1729
        for i = 1, #self.region.id do seed = (seed * 31 + string.byte(self.region.id, i)) % 2147483647 end
        local function random()
            seed = seed * 48271 % 2147483647
            return seed / 2147483647
        end
        -- Échantillonnage borné, réalisé seulement au chargement de la région.
        for _ = 1, 720 do
            if #self.clouds >= 112 then break end
            local x, y = (random() * 2 - 1) * (half.x + 48), (random() * 2 - 1) * (half.y + 48)
            local dx, dy = max(abs(x) - half.x, 0), max(abs(y) - half.y, 0)
            local outside = math.sqrt(dx * dx + dy * dy)
            if outside > 2 and outside < 43 then
                local raw = Vector(self.center.x + x / self.model_scale, self.center.y + y / self.model_scale,
                    max(0, self.mins.z) + (2 + random() * 18) / self.model_scale)
                local size = 32 + random() * 33
                local shade = 0.88 + random() * 0.16
                self.clouds[#self.clouds + 1] = {
                    pos = self:RawToScene(raw), phase = random() * 6.28,
                    width = size, height = size * (0.85 + random() * 0.3),
                    rotation = random() * 360, spin = (random() - 0.5) * 1.5,
                    material = CLOUDS[1 + math.floor(random() * #CLOUDS)],
                    color = Color(mist.r * shade, mist.g * shade, mist.b * shade, 135 + random() * 55),
                }
            end
        end
    end

    local function cloud_depth(a, b) return a.depth > b.depth end

    function PANEL:DrawClouds(camera, angle)
        local forward, now = angle:Forward(), CurTime()
        for _, cloud in ipairs(self.clouds) do
            cloud.draw_pos = cloud.pos + Vector(sin(now * 0.12 + cloud.phase) * 2,
                cos(now * 0.1 + cloud.phase) * 2, sin(now * 0.16 + cloud.phase) * 1.5)
            cloud.depth = (cloud.draw_pos - camera):Dot(forward)
        end
        table.sort(self.clouds, cloud_depth)
        for _, cloud in ipairs(self.clouds) do
            render.SetMaterial(cloud.material)
            -- Face à la caméra à TOUS les angles, y compris exactement du dessus.
            render.DrawQuadEasy(cloud.draw_pos, -forward, cloud.width, cloud.height, cloud.color,
                cloud.rotation + now * cloud.spin)
        end
    end

    -- Surfaces d'eau exportées une fois : aucun parcours du modèle en Paint.
    -- Les triangles respectent les berges, même dans les petits bassins de la cité.
    function PANEL:BuildWater()
        if self.water_mesh then self.water_mesh:Destroy() end
        self.water_mesh, self.water_glints = nil, {}
        local water = atlas.config.water_surfaces[self.region.id]
        if self.missing or not is_valid(self.entity) or not water then return end
        local vertices = {}
        local deep, shallow = self.palette.water_deep, self.palette.water_shallow
        for i = 1, #water - 2, 3 do
            local a, b, c = self:RawToScene(water[i]), self:RawToScene(water[i + 1]), self:RawToScene(water[i + 2])
            local center = (a + b + c) / 3 + UP * 0.06
            -- Distance du centroïde aux trois côtés : l'éclat reste dans l'eau.
            local area = (b - a):Cross(c - a):Length()
            local radius = min(area / max((b - a):Length(), 0.001), area / max((c - b):Length(), 0.001),
                area / max((a - c):Length(), 0.001)) / 3
            if radius > 0.10 and #self.water_glints < 48 then
                self.water_glints[#self.water_glints + 1] = { pos = center, size = min(radius, 1.4), phase = i * 0.73 }
            end
            for _, pos in ipairs({ a, b, c }) do
                local mix = 0.5 + sin(pos.x * 0.06 + pos.y * 0.043) * 0.5
                local color = Color(deep.r + (shallow.r - deep.r) * mix,
                    deep.g + (shallow.g - deep.g) * mix, deep.b + (shallow.b - deep.b) * mix, deep.a)
                vertices[#vertices + 1] = { pos = pos + UP * 0.04, normal = UP, u = 0, v = 0, color = color }
            end
        end
        if #vertices > 0 then
            self.water_mesh = Mesh(WATER)
            self.water_mesh:BuildFromTriangles(vertices)
        end
        local glint = self.palette.glint
        self.water_glint_color = Color(glint.r, glint.g, glint.b, glint.a)
    end

    function PANEL:DrawWater()
        if not self.water_mesh then return end
        render.SetMaterial(WATER)
        self.water_mesh:Draw()
        render.SetMaterial(atlas.glow)
        local color, now = self.water_glint_color, CurTime()
        for _, glint in ipairs(self.water_glints) do
            local pulse = (0.5 + 0.5 * sin(now * 1.3 + glint.phase)) ^ 3
            color.a = self.palette.glint.a * pulse
            render.DrawQuadEasy(glint.pos, UP, glint.size * 1.8, glint.size * 0.55, color, 28)
        end
    end

    function PANEL:BuildAtmosphere()
        self.motes = {}
        local size, accent = self.maxs - self.mins, self.region.accent
        self.mote_color = Color(accent.r, accent.g, accent.b, 65)
        self.beacon_color = Color(accent.r, accent.g, accent.b, 130)
        for i = 1, 24 do
            local raw = Vector(self.mins.x + size.x * ((i * 0.618034) % 1),
                self.mins.y + size.y * ((i * 0.414214) % 1), self.maxs.z + (i % 5) / self.model_scale)
            self.motes[i] = { pos = self:RawToScene(raw), phase = i * 1.9 }
        end
    end

    function PANEL:DrawAtmosphere()
        local now = CurTime()
        render.SetMaterial(atlas.glow)
        for _, mote in ipairs(self.motes or {}) do
            local phase = mote.phase
            local pos = mote.pos + Vector(sin(now * 0.2 + phase) * 5, cos(now * 0.17 + phase) * 3,
                sin(now * 0.3 + phase) * 2)
            local radius = 0.6 + (sin(now + phase) + 1) * 0.35
            render.DrawSprite(pos, radius, radius, self.mote_color)
        end
        local selected = self.owner and self.owner.selected
        if self.clean or not selected or not selected.scene_pos or not self.owner:Matches(selected) then return end
        local base = selected.scene_pos + UP * 0.2
        local radius = 9 + sin(now * 2) * 1.5
        render.DrawQuadEasy(base, UP, radius, radius, self.beacon_color, 0)
        local tip = base + UP * (12 + sin(now * 2) * 1.5)
        render.DrawSprite(tip, 3, 3, self.beacon_color)
        render.SetMaterial(BEAM)
        render.DrawBeam(base, tip, 0.8, 0, 1, self.beacon_color)
    end

    function PANEL:RawToScene(pos)
        local result = (pos - self.center) * self.model_scale
        result:Rotate(self.model_angle)
        return result
    end

    function PANEL:SceneToRaw(pos)
        local result = Vector(pos.x, pos.y, pos.z)
        result:Rotate(Angle(0, -self.model_angle.y, 0))
        return result / self.model_scale + self.center
    end

    function PANEL:SetFloor(id)
        local floors = self.region and self.region.floors
        local floor = floors and floors[id]
        if id ~= "all" and not floor then return end
        self.floor_id = id
        self.body_value = floor and floor.body_value or 0
        self.meshes = nil
        self.projected = {}
        if floors and is_valid(self.entity) then
            self.entity:SetBodygroup(0, floor and floor.hide_upper or 0)
            self.entity:SetBodygroup(1, floor and floor.hide_ground or 0)
            self.entity:SetupBones()
        end
    end

    function PANEL:ShowsFloor(id)
        return self.floor_id == "all" or not id or self.floor_id == id
    end

    function PANEL:WorldFloor(pos)
        local split = self.region and self.region.floor_split
        if split and pos then return pos.z < split and "ground" or "upper" end
    end

    function PANEL:ImageToRaw(x, y)
        local r = self.region
        if r.image_origin and r.image_u and r.image_v then
            return r.image_origin + r.image_u * x + r.image_v * y
        end
        -- Repli pour une région ajoutée sans calibration.
        local size = self.maxs - self.mins
        return Vector(self.mins.x + x * size.x, self.maxs.y - y * size.y,
            self.mins.z + size.z * (r.marker_height or 0.25))
    end

    function PANEL:WorldToRaw(pos)
        local r = self.region
        if not atlas.Contains(r, pos) then return nil end
        local t = r.world_transform
        if t then
            local delta = pos - t.origin
            delta:Rotate(Angle(0, t.yaw or 0, 0))
            local raw = t.model_origin + Vector(delta.x * t.scale.x, delta.y * t.scale.y, delta.z * t.scale.z)
            local floor_id = self:WorldFloor(pos)
            local floor = r.floors and r.floors[floor_id]
            if floor then raw.z = floor.height end
            return raw
        end
        local x, y = atlas.data.world_to_image(r.id, pos)
        if x then return self:ImageToRaw(x, y) end
    end

    function PANEL:MarkerPosition(marker)
        local overrides = self.region.marker_positions
        local raw = (overrides and overrides[marker.zone or marker.name]) or marker.model_pos
        if not raw and self.region.world_transform and marker.pos then raw = self:WorldToRaw(marker.pos) end
        if not raw and marker.x and marker.y then raw = self:ImageToRaw(marker.x, marker.y) end
        return raw and self:RawToScene(raw) or nil
    end

    function PANEL:SetPoints(points)
        self.points = points
        for _, point in ipairs(points) do point.scene_pos = self:MarkerPosition(point) end
        self.projected = {}
    end

    function PANEL:FitDistance()
        local aspect = max(self:GetWide(), 1) / max(self:GetTall(), 1)
        local size = (self.maxs - self.mins) * self.model_scale
        local radius = size:Length() * 0.5
        -- FOV horizontal : sur un panneau large, l'angle vertical est le plus
        -- étroit. Le diviser par l'aspect évite de couper le haut de la maquette.
        local half_fov = math.atan(tan(rad(FOV * 0.5)) / max(1, aspect))
        return radius / math.sin(half_fov) * 1.08
    end

    function PANEL:ResetView(immediate)
        self:SetCursor("sizeall")
        self.base_distance = self:FitDistance()
        self.goal_distance = self.base_distance
        self.goal_yaw = self.region and self.region.yaw or -65
        self.goal_pitch = self.region and self.region.pitch or 50
        self.target = Vector(0, 0, 0)
        self.touring = false
        if immediate then
            self.look = Vector(0, 0, 0)
            self.yaw, self.pitch = self.goal_yaw - 9, self.goal_pitch
            self.distance = self.goal_distance * 1.12
        end
    end

    function PANEL:PerformLayout(w, h)
        if not self.mins then return end
        local previous = self.base_distance or self:FitDistance()
        self.base_distance = self:FitDistance()
        self.goal_distance = self.goal_distance * self.base_distance / previous
    end

    function PANEL:Focus(pos)
        if not pos then return end
        self.target = Vector(pos.x, pos.y, pos.z)
        self.goal_distance = self.base_distance * 0.36
        self.touring = false
        self:ClampTarget()
    end

    function PANEL:ClampTarget()
        -- Borner dans le repère du modèle : après une rotation, les deux coins
        -- de la boîte ne sont plus nécessairement ordonnés dans la scène.
        local raw = self:SceneToRaw(self.target)
        local margin = 35 / self.model_scale
        raw.x = clamp(raw.x, self.mins.x - margin, self.maxs.x + margin)
        raw.y = clamp(raw.y, self.mins.y - margin, self.maxs.y + margin)
        raw.z = clamp(raw.z, self.mins.z, self.maxs.z)
        self.target = self:RawToScene(raw)
    end

    function PANEL:Camera()
        local angle = Angle(self.pitch, self.yaw, 0)
        return self.look - angle:Forward() * self.distance, angle
    end

    function PANEL:ViewFOV()
        return FOV
    end

    -- Même projection que cam.Start, indépendante de la caméra du joueur.
    function PANEL:Project(pos)
        local camera, angle = self:Camera()
        local delta = pos - camera
        local depth = delta:Dot(angle:Forward())
        if depth <= 0.5 then return nil end
        local focal = self:GetWide() * 0.5 / tan(rad(self:ViewFOV() * 0.5))
        return self:GetWide() * 0.5 + delta:Dot(angle:Right()) * focal / depth,
            self:GetTall() * 0.5 - delta:Dot(angle:Up()) * focal / depth, depth
    end

    function PANEL:Ray(x, y)
        local camera, angle = self:Camera()
        local focal = self:GetWide() * 0.5 / tan(rad(self:ViewFOV() * 0.5))
        local direction = angle:Forward() + angle:Right() * ((x - self:GetWide() * 0.5) / focal)
            - angle:Up() * ((y - self:GetTall() * 0.5) / focal)
        return camera, direction:GetNormalized()
    end

    function PANEL:PlaneAt(x, y)
        local origin, direction = self:Ray(x, y)
        if abs(direction.z) < 0.001 then return nil end
        local distance = (self.target.z - origin.z) / direction.z
        if distance <= 0 then return nil end
        return origin + direction * distance
    end

    function PANEL:Zoom(delta, x, y)
        self.touring = false
        local old = self.goal_distance
        self.goal_distance = clamp(old * exp(-delta * 0.17), self.base_distance * 0.09, self.base_distance * 1.7)
        -- Le point sous la souris reste l'ancre du zoom sur le plan de navigation.
        local point = x and self:PlaneAt(x, y)
        if point then self.target = self.target + (point - self.target) * (1 - self.goal_distance / old) end
        self:ClampTarget()
    end

    function PANEL:OnMouseWheeled(delta)
        local x, y = self:CursorPos()
        self:Zoom(delta, x, y)
        return true
    end

    function PANEL:OnMousePressed(code)
        if code ~= MOUSE_LEFT and code ~= MOUSE_RIGHT and code ~= MOUSE_MIDDLE then return end
        if self.owner and is_valid(self.owner.search) then self.owner.search:KillFocus() end
        local x, y = gui.MousePos()
        self.drag = { code = code, x = x, y = y, moved = false, down_x = x, down_y = y }
        self.touring = false
        self:MouseCapture(true)
    end

    function PANEL:HitMarker(x, y)
        local best, best_distance = nil, atlas.Scale(21) ^ 2
        for _, point in ipairs(self.projected) do
            local distance = (x - point.x) ^ 2 + (y - point.y) ^ 2
            if distance < best_distance then best, best_distance = point.marker, distance end
        end
        return best
    end

    function PANEL:OnMouseReleased(code)
        local drag = self.drag
        if not drag or drag.code ~= code then return end
        self.drag = nil
        self:MouseCapture(false)
        if drag.moved or code ~= MOUSE_LEFT then return end
        local x, y = self:CursorPos()
        if atlas.dev:GetBool() and input.IsKeyDown(KEY_LCONTROL) then
            local hit = self:PickSurface(x, y)
            if hit then
                atlas.calibration_hit = { region = self.region.id, pos = hit }
                local line = string.format("Vector(%.6f, %.6f, %.6f)", hit.x, hit.y, hit.z)
                SetClipboardText(line)
                MsgN("[Atlas] " .. self.region.id .. " : " .. line)
                atlas.Feedback("Position du relief copiée. Voir evo_atlas_calib dans le guide.")
            else
                atlas.Feedback("Aucune surface sous le curseur.")
            end
            return
        end
        local marker = self:HitMarker(x, y)
        if marker and self.owner then self.owner:SelectMarker(marker) end
    end

    -- Picking triangle exact uniquement sur Ctrl+clic en mode calibration.
    -- Ni extraction des meshes, ni parcours des triangles dans Paint/Think.
    function PANEL:PickSurface(x, y)
        if not is_valid(self.entity) then return nil end
        if not self.meshes then
            self.meshes = util.GetModelMeshes(self.region.model, 0, self.body_value) or {}
            -- GetModelMeshes renvoie la pose de référence ; ces exports ont
            -- une rotation de racine de +90° dans leur séquence idle.
            local angle = Angle(0, self.region.mesh_yaw or 0, 0)
            for _, mesh in ipairs(self.meshes) do
                for i, vertex in ipairs(mesh.triangles or {}) do
                    local pos = Vector(vertex.pos.x, vertex.pos.y, vertex.pos.z)
                    pos:Rotate(angle)
                    -- Plusieurs triangles peuvent référencer le même vertex.
                    mesh.triangles[i] = { pos = pos }
                end
            end
        end
        local start, direction = self:Ray(x, y)
        local origin = self:SceneToRaw(start)
        direction:Rotate(Angle(0, -self.model_angle.y, 0))
        local closest, hit = math.huge, nil
        for _, mesh in ipairs(self.meshes) do
            local vertices = mesh.triangles or {}
            for i = 1, #vertices - 2, 3 do
                local a, b, c = vertices[i].pos, vertices[i + 1].pos, vertices[i + 2].pos
                local e1, e2 = b - a, c - a
                local p = direction:Cross(e2)
                local determinant = e1:Dot(p)
                if abs(determinant) > 0.0000001 then
                    local inv = 1 / determinant
                    local t = origin - a
                    local u = t:Dot(p) * inv
                    if u >= 0 and u <= 1 then
                        local q = t:Cross(e1)
                        local v = direction:Dot(q) * inv
                        local distance = e2:Dot(q) * inv
                        if v >= 0 and u + v <= 1 and distance > 0 and distance < closest then
                            closest, hit = distance, origin + direction * distance
                        end
                    end
                end
            end
        end
        return hit
    end

    -- Think nécessaire : inertie de caméra et glisser à la cadence d'affichage.
    -- Aucune recherche d'entités / écriture réseau dans cette boucle.
    function PANEL:Think()
        local dt = min(RealFrameTime(), 0.05)
        if self.drag then
            local x, y = gui.MousePos()
            local drag = self.drag
            local dx, dy = x - drag.x, y - drag.y
            if (x - drag.down_x) ^ 2 + (y - drag.down_y) ^ 2 > 16 then drag.moved = true end
            drag.x, drag.y = x, y
            if drag.moved then
                if drag.code == MOUSE_LEFT then
                    self.goal_yaw = self.goal_yaw - dx * 0.32
                    self.goal_pitch = clamp(self.goal_pitch + dy * 0.24, 15, 89)
                else
                    local angle = Angle(0, self.yaw, 0)
                    local factor = self.distance * 2 * tan(rad(FOV * 0.5)) / max(self:GetWide(), 1)
                    self.target = self.target - angle:Right() * dx * factor
                        + angle:Forward() * dy * factor / max(math.sin(rad(self.pitch)), 0.25)
                    self:ClampTarget()
                end
            end
        end
        if self.touring then self.goal_yaw = self.goal_yaw + dt * 7 end
        local search_focused = self.owner and is_valid(self.owner.search) and self.owner.search:HasFocus()
        if not search_focused and self:IsHovered() and not self.drag then
            local horizontal = (input.IsKeyDown(KEY_D) and 1 or 0) - (input.IsKeyDown(KEY_Q) and 1 or 0)
            local vertical = (input.IsKeyDown(KEY_Z) and 1 or 0) - (input.IsKeyDown(KEY_S) and 1 or 0)
            if horizontal ~= 0 or vertical ~= 0 then
                local angle = Angle(0, self.yaw, 0)
                self.target = self.target + (angle:Right() * horizontal + angle:Forward() * vertical) * dt * self.distance * 0.4
                self.touring = false
                self:ClampTarget()
            end
        end
        local smooth = 1 - exp(-dt * 12)
        self.yaw = self.yaw + (self.goal_yaw - self.yaw) * smooth
        self.pitch = self.pitch + (self.goal_pitch - self.pitch) * smooth
        self.distance = self.distance + (self.goal_distance - self.distance) * smooth
        self.look = LerpVector(smooth, self.look, self.target)
    end

    function PANEL:Paint(w, h)
        if not self.region then return end
        local scale = atlas.Scale
        local palette = self.palette
        surface.SetDrawColor(palette.background)
        surface.DrawRect(0, 0, w, h)
        -- Halo diffus derrière la maquette, aucun asset additionnel requis.
        surface.SetMaterial(atlas.glow)
        local accent = self.region.accent
        surface.SetDrawColor(palette.haze.r, palette.haze.g, palette.haze.b, 42)
        surface.DrawTexturedRect(w * 0.1, h * 0.05, w * 0.8, h * 0.85)
        surface.SetDrawColor(palette.mist.r, palette.mist.g, palette.mist.b, 24)
        surface.DrawTexturedRect(-w * 0.12, h * 0.37, w * 0.9, h * 0.85)
        if self.missing then
            draw.SimpleText("RELIEF INDISPONIBLE", "EVO_Atlas_Heading", w * 0.5, h * 0.44, WHITE, TEXT_ALIGN_CENTER)
            draw.SimpleText(self.missing, "EVO_Atlas_Body", w * 0.5, h * 0.44 + scale(38), MUTED, TEXT_ALIGN_CENTER)
            draw.SimpleText("Les lieux restent consultables dans la liste.", "EVO_Atlas_Body", w * 0.5, h * 0.44 + scale(66), MUTED, TEXT_ALIGN_CENTER)
            return
        end
        if not is_valid(self.entity) then
            self.missing = "Sélectionne à nouveau la région pour recharger son relief."
            return
        end
        local sx, sy = self:LocalToScreen(0, 0)
        local camera, angle = self:Camera()
        -- cam.Start utilise "aspect" ("aspectratio" appartient à RenderView).
        -- Le ratio explicite garde les marqueurs alignés avec le relief.
        cam.Start({ type = "3D", origin = camera, angles = angle, fov = self:ViewFOV(),
            x = sx, y = sy, w = w, h = h, aspect = w / max(h, 1), znear = 0.5, zfar = 5000 })
        render.ClearDepth(false)
        render.SetScissorRect(sx, sy, sx + w, sy + h, true)
        render.SuppressEngineLighting(true)
        render.ResetModelLighting(palette.ambient.x, palette.ambient.y, palette.ambient.z)
        render.SetModelLighting(BOX_TOP, palette.sun.x, palette.sun.y, palette.sun.z)
        render.SetModelLighting(BOX_FRONT, palette.fill.x, palette.fill.y, palette.fill.z)
        render.SetModelLighting(BOX_RIGHT, palette.rim.x, palette.rim.y, palette.rim.z)
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(self:GetAlpha() / 255)
        render.MaterialOverride(nil)
        self.entity:DrawModel()
        render.SuppressEngineLighting(false)
        render.ResetModelLighting(1, 1, 1)
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(self:GetAlpha() / 255)
        self:DrawWater()
        self:DrawAtmosphere()
        self:DrawClouds(camera, angle)
        render.SetBlend(1)
        render.SetScissorRect(0, 0, 0, 0, false)
        cam.End3D()

        self.projected = {}
        if not self.clean then
            for _, marker in ipairs(self.points) do
                if marker.scene_pos and (not self.owner or self.owner:Matches(marker)) then
                    local x, y, depth = self:Project(marker.scene_pos)
                    -- La pointe de la tige doit toucher la surface projetée,
                    -- le cercle reste au-dessus pour ne pas masquer le lieu.
                    if y then y = y - scale(17) end
                    if x and x > scale(22) and x < w - scale(22) and y > scale(70) and y < h - scale(60) then
                        self.projected[#self.projected + 1] = { marker = marker, x = x, y = y, depth = depth }
                    end
                end
            end
            local mx, my = self:CursorPos()
            self.hovered = self:IsHovered() and not self.drag and self:HitMarker(mx, my) or nil
            -- Dessiner tous les points, puis réserver le libellé actif avant les
            -- autres : deux boutiques proches ne recouvrent plus la sélection.
            local occupied, labels = {}, {}
            for _, point in ipairs(self.projected) do
                local m = point.marker
                local selected = self.selected == m.key
                local hovered = self.hovered == m
                atlas.DrawMarker(m, point.x, point.y, hovered or selected)
            end
            for priority = 1, 2 do
                for _, point in ipairs(self.projected) do
                    local m = point.marker
                    local active = self.selected == m.key or self.hovered == m
                    if (priority == 1 and active) or (priority == 2 and not active and self.labels) then
                        surface.SetFont("EVO_Atlas_Small")
                        local tw, th = surface.GetTextSize(m.name)
                        local bw = min(tw + scale(24), w - scale(20))
                        local x = clamp(point.x - bw * 0.5, scale(8), w - bw - scale(8))
                        local y = point.y - scale(30) - (th + scale(10)) * 0.5
                        local box = { x = x, y = y, right = x + bw, bottom = y + th + scale(12) }
                        local overlaps = false
                        for _, other in ipairs(occupied) do
                            if box.x < other.right and box.right > other.x and box.y < other.bottom and box.bottom > other.y then
                                overlaps = true break
                            end
                        end
                        if not overlaps then
                            occupied[#occupied + 1] = box
                            labels[#labels + 1] = { point = point, active = active }
                        end
                    end
                end
            end
            for _, label in ipairs(labels) do
                local point = label.point
                atlas.DrawLabel(point.marker.name, point.x, point.y - scale(30), w, label.active)
            end
            if self.player_pos then
                local x, y = self:Project(self.player_pos)
                if x and x > 16 and x < w - 16 and y > 60 and y < h - 45 then
                    local ax, ay
                    if self.player_ahead then ax, ay = self:Project(self.player_ahead) end
                    atlas.DrawPlayer(x, y, ax and ax - x or 0, ay and ay - y or -1)
                end
            end
            local pin = EVO_MapPin and EVO_MapPin.Get()
            local raw = pin and self:WorldToRaw(pin.pos)
            if raw then
                local x, y = self:Project(self:RawToScene(raw))
                if x and x > 20 and x < w - 20 and y > 60 and y < h - 45 then
                    surface.DrawCircle(x, y, scale(22), accent.r, accent.g, accent.b, 220)
                    atlas.DrawLabel("REPÈRE ACTIF", x, y + scale(32), w, true)
                end
            end
        end
        -- Rose des vents discrète, toujours cohérente avec la rotation de la vue.
        local cx, cy, radius = w - scale(61), h - scale(66), scale(25)
        surface.DrawCircle(cx, cy, radius, 109, 131, 148, 110)
        local nx = cx - math.cos(rad(self.yaw)) * radius
        local ny = cy + math.sin(rad(self.yaw)) * radius
        surface.SetDrawColor(accent)
        surface.DrawLine(cx, cy, nx, ny)
        draw.SimpleText("N", "EVO_Atlas_Small", nx, ny - scale(13), WHITE, TEXT_ALIGN_CENTER)
        draw.SimpleText(string.format("%.1f×", (self.base_distance or self.distance) / self.distance),
            "EVO_Atlas_Small", cx, cy + scale(37), MUTED, TEXT_ALIGN_CENTER)
    end

    vgui.Register("EVO_AtlasScene", PANEL, "DPanel")
end
