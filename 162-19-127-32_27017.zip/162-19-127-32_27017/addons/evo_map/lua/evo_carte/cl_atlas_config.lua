-- "addons\\evo_map\\lua\\evo_carte\\cl_atlas_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Atlas 3D. Coordonnées des maquettes AVANT leur normalisation par le viewer.
-- Les modèles/content restent distribués par le Workshop du serveur.
local config = {}
config.water_surfaces = include("evo_carte/cl_atlas_water.lua")

-- Soleil / ombres colorées : les textures du relief gardent leurs couleurs.
-- Les valeurs d'éclairage Source sont linéaires (1 = pleine intensité).
config.palettes = {
    seireitei = {
        background = Color(15, 20, 29), ground = Color(28, 35, 43),
        haze = Color(235, 159, 128), mist = Color(151, 183, 202),
        ambient = Vector(0.44, 0.46, 0.51), sun = Vector(1.10, 0.97, 0.80),
        fill = Vector(0.43, 0.64, 0.76), rim = Vector(0.65, 0.35, 0.30),
        water_deep = Color(17, 94, 126, 225), water_shallow = Color(64, 203, 187, 225),
        glint = Color(201, 248, 244, 150),
    },
    zoneneutre1 = {
        background = Color(10, 23, 26), ground = Color(22, 37, 34),
        haze = Color(155, 215, 139), mist = Color(139, 190, 176),
        ambient = Vector(0.40, 0.49, 0.43), sun = Vector(1.03, 1.03, 0.78),
        fill = Vector(0.34, 0.64, 0.68), rim = Vector(0.61, 0.43, 0.24),
        water_deep = Color(12, 103, 133, 225), water_shallow = Color(57, 210, 179, 225),
        glint = Color(184, 251, 223, 150),
    },
    zoneneutre2 = {
        background = Color(23, 22, 25), ground = Color(40, 36, 30),
        haze = Color(228, 179, 103), mist = Color(187, 187, 168),
        ambient = Vector(0.44, 0.44, 0.43), sun = Vector(1.14, 0.97, 0.69),
        fill = Vector(0.34, 0.53, 0.74), rim = Vector(0.69, 0.45, 0.24),
        water_deep = Color(23, 100, 154, 225), water_shallow = Color(63, 203, 198, 225),
        glint = Color(220, 248, 246, 155),
    },
    hueco_lasnoches = {
        background = Color(18, 17, 31), ground = Color(31, 29, 44),
        haze = Color(169, 143, 216), mist = Color(171, 169, 203),
        ambient = Vector(0.42, 0.42, 0.51), sun = Vector(0.91, 0.94, 1.12),
        fill = Vector(0.49, 0.39, 0.66), rim = Vector(0.25, 0.55, 0.62),
    },
    hueco_desert = {
        background = Color(26, 20, 23), ground = Color(43, 34, 28),
        haze = Color(235, 163, 88), mist = Color(202, 172, 143),
        ambient = Vector(0.47, 0.40, 0.34), sun = Vector(1.16, 0.90, 0.58),
        fill = Vector(0.44, 0.49, 0.65), rim = Vector(0.78, 0.40, 0.24),
    },
    hueco_zoneneutre1 = {
        background = Color(12, 19, 30), ground = Color(26, 34, 46),
        haze = Color(130, 184, 217), mist = Color(150, 180, 201),
        ambient = Vector(0.36, 0.42, 0.49), sun = Vector(0.84, 0.95, 1.13),
        fill = Vector(0.36, 0.50, 0.66), rim = Vector(0.51, 0.38, 0.65),
    },
    hueco_zoneneutre2 = {
        background = Color(17, 19, 34), ground = Color(29, 32, 48),
        haze = Color(156, 151, 222), mist = Color(165, 174, 211),
        ambient = Vector(0.39, 0.41, 0.49), sun = Vector(0.94, 0.92, 1.14),
        fill = Vector(0.38, 0.48, 0.72), rim = Vector(0.56, 0.35, 0.65),
    },
}

config.regions = {
    { id = "seireitei", name = "Seireitei", realm = "SOUL SOCIETY", faction = "Shinigami",
      model = "models/evo/bleach_carte/seireitei.mdl", server = "rp_seireitei_v1",
      subtitle = "Au cœur de la cité des âmes.", accent = Color(217, 102, 92),
      zmin = -2500, zmax = 16384, pitch = 48, yaw = -65 },
    { id = "zoneneutre1", name = "Zone neutre I", realm = "SOUL SOCIETY", faction = "Shinigami",
      model = "models/evo/bleach_carte/ss_zone_1.mdl", server = "rp_seireitei_v1",
      subtitle = "Sous les frondaisons, les frontières se disputent.", accent = Color(133, 184, 145),
      zmin = -16384, zmax = -11000, pitch = 52, yaw = -65 },
    { id = "zoneneutre2", name = "Zone neutre II", realm = "SOUL SOCIETY", faction = "Shinigami",
      model = "models/evo/bleach_carte/ss_zone_2.mdl", server = "rp_seireitei_v1",
      subtitle = "Ravins, plateaux et territoires à conquérir.", accent = Color(195, 173, 115),
      zmin = -11000, zmax = -2500, pitch = 52, yaw = -65 },
    { id = "hueco_lasnoches", name = "Las Noches · Bâtiment", short = "Le palais", realm = "HUECO MUNDO", faction = "Hollow",
      model = "models/evo/bleach_carte/las_noches_batiment.mdl", server = "hueco_mundo_v1",
      subtitle = "Les couloirs du pouvoir, sous la lune éternelle.", accent = Color(183, 160, 212),
      zmin = 4200, zmax = 8000, pitch = 58, yaw = -65 },
    { id = "hueco_desert", name = "Las Noches · Désert", short = "Le désert", realm = "HUECO MUNDO", faction = "Hollow",
      model = "models/evo/bleach_carte/las_noches_desert.mdl", server = "hueco_mundo_v1",
      subtitle = "Une mer de sable aux portes de Las Noches.", accent = Color(219, 176, 109),
      -- Cet onglet n'a pas encore de sélection automatique ni de catalogue.
      auto_select = false, pitch = 52, yaw = -65 },
    { id = "hueco_zoneneutre1", name = "Zone neutre I", realm = "HUECO MUNDO", faction = "Hollow",
      model = "models/evo/bleach_carte/hm_zone_1.mdl", server = "hueco_mundo_v1",
      subtitle = "Arènes oubliées et étendues silencieuses.", accent = Color(144, 182, 197),
      zmin = -16384, zmax = 4200, pitch = 52, yaw = -65 },
    { id = "hueco_zoneneutre2", name = "Zone neutre II", realm = "HUECO MUNDO", faction = "Hollow",
      model = "models/evo/bleach_carte/hm_zone_2.mdl", server = "hueco_mundo_v1",
      subtitle = "Les reliefs pâles du royaume des Hollows.", accent = Color(153, 168, 201),
      zmin = 8000, zmax = 16384, pitch = 52, yaw = -65 },
}

-- marker_positions : ancrages sur la géométrie ; world_positions : destinations.
-- Ces deux espaces sont distincts, les maquettes étant des reliefs stylisés.
-- Les sources historiques 2D restent dans cl_map_data.lua.
config.by_id = {}
for _, region in ipairs(config.regions) do config.by_id[region.id] = region end

-- Relevés sur les meshes Workshop du 08/09/2026. La séquence idle tourne
-- leur racine de +90° : les coordonnées ci-dessous sont celles du mesh (VVD),
-- puis converties UNE fois vers le repère local animé utilisé par le viewer.
local function mesh_point(x, y, z)
    return Vector(-y, x, z)
end

local placements = {
    seireitei = {
        ["Division 1"] = mesh_point(-1.800000, 3.000000, 29.183408),
        ["Division 2"] = mesh_point(20.000000, -44.000000, 2.762979),
        ["Division 4"] = mesh_point(-25.500000, -29.000000, 4.987584),
        ["Division 11"] = mesh_point(-48.500000, 33.500000, 5.839861),
        ["Division 12"] = mesh_point(20.000000, 43.000000, 3.928543),
        ["Académie"] = mesh_point(42.000000, -39.000000, 0.280000),
        ["Senkaimon"] = mesh_point(24.000000, 10.500000, 28.955993),
        ["Urahara Shop"] = mesh_point(-27.600000, 17.500000, 5.498978),
        ["Chirurgien esthétique"] = mesh_point(-31.000000, 17.500000, 7.261767),
        ["Coiffeur"] = mesh_point(-6.000000, -43.000000, 3.536729),
        ["Tatoueur"] = mesh_point(-10.000000, -43.000000, 0.280000),
        ["Entraînement I"] = mesh_point(-38.000000, -15.000000, 2.915564),
        ["Entraînement II"] = mesh_point(-43.000000, -40.000000, 0.240000),
        ["Entraînement III"] = mesh_point(-44.000000, 44.000000, 1.733542),
        ["Entraînement IV"] = mesh_point(44.000000, 27.000000, 0.240000),
    },
    zoneneutre1 = {
        ["Place des Veilleurs"] = mesh_point(29.700000, 10.000000, 0.482022),
        ["Bois du Jugement"] = mesh_point(-20.400000, -30.600000, 0.628869),
        ["Bois de la Cascade"] = mesh_point(-21.000000, 11.900000, 0.478362),
    },
    zoneneutre2 = {
        ["Pic des Esprits"] = mesh_point(10.544400, -29.100000, 4.586901),
        ["Ravin des Âmes"] = mesh_point(7.544700, 15.300000, 3.996217),
        ["Gorge des Esprits"] = mesh_point(26.088300, -11.100000, 0.518676),
    },
    hueco_lasnoches = {
        ["Las Noches"] = mesh_point(-15.000000, 10.000000, 6.120000),
        ["Entrée"] = mesh_point(9.000000, -40.000000, 0.120000),
        ["Portes Désert"] = mesh_point(-20.000000, -4.000000, 0.120000),
        ["Salle de rassemblement"] = mesh_point(-16.000000, -25.000000, 6.120000),
        ["Salle des Espadas"] = mesh_point(-39.000000, -29.000000, 6.120000),
        ["Duel de sang"] = mesh_point(8.000000, 6.000000, 9.120000),
        ["Ordre 1"] = mesh_point(-39.890916, -30.141259, 6.120000),
        ["Ordre 2"] = mesh_point(22.212817, -0.630602, 6.120000),
        ["Ordre 3"] = mesh_point(-38.878239, 2.186992, 6.120000),
        ["Ordre 4"] = mesh_point(-43.524716, 13.909196, 6.120000),
        ["Ordre 5"] = mesh_point(12.666019, 16.529877, 6.120000),
        ["Tatoueur"] = mesh_point(12.052744, 25.958633, 0.120000),
        ["Chirurgien esthétique"] = mesh_point(13.673619, 24.883388, 0.120000),
        ["Coiffeur"] = mesh_point(12.094742, 20.913832, 0.120000),
        ["Hollow Shop"] = mesh_point(6.013059, 21.530415, 0.120000),
    },
    hueco_zoneneutre1 = {
        ["Oasis des Âmes Perdues"] = mesh_point(-19.900000, -40.900000, 0.430422),
        ["Arène des Exilés"] = mesh_point(37.000000, 36.000000, 0.120000),
        ["Clairière des Menos Anciens"] = mesh_point(37.100000, -28.500000, 0.440370),
        ["Lisière des Hurlements"] = mesh_point(37.300000, -31.600000, 0.351744),
    },
    hueco_zoneneutre2 = {
        ["Dunes du Croissant Noir"] = mesh_point(-33.000000, -33.300000, 0.269796),
        ["Croisée des Âmes"] = mesh_point(7.300000, 21.500000, 4.215024),
        ["Falaises de la Lune Blanche"] = mesh_point(32.600000, -38.600000, 0.308098),
    },
}

local world_positions = {
    seireitei = {
        ["Division 1"] = Vector(-1279.372070, 955.712158, 1913.285278),
        ["Division 2"] = Vector(5771.198242, -12520.874023, 436.439850),
        ["Division 12"] = Vector(9286.904297, 14569.867188, 465.752472),
        ["Division 4"] = Vector(-7776.101562, -8634.447266, 457.119019),
        ["Division 11"] = Vector(-15300.145508, 11030.975586, 456.108551),
        ["Coiffeur"] = Vector(-1573.928023, -11399.395728, 427.765717),
        ["Tatoueur"] = Vector(-3058.385879, -11504.517047, 439.970215),
        ["Chirurgien esthétique"] = Vector(-8514.040039, 7909.192811, 428.948334),
        ["Urahara Shop"] = Vector(-8146.940618, 7748.168141, 428.747803),
    },
    hueco_lasnoches = {
        ["Ordre 1"] = Vector(-11431.647461, -5971.002441, 6344.722168),
        ["Ordre 2"] = Vector(5584.005371, 2002.663330, 7107.063477),
        ["Ordre 3"] = Vector(-11157.060547, 2649.864502, 6354.633789),
        ["Ordre 4"] = Vector(-12416.951172, 5775.785645, 6382.202148),
        ["Ordre 5"] = Vector(2819.148438, 6474.633789, 6585.856445),
        ["Coiffeur"] = Vector(2710.770752, 7953.031250, 5359.369629),
        ["Tatoueur"] = Vector(2652.859131, 8988.968750, 5369.023926),
        ["Chirurgien esthétique"] = Vector(3184.968750, 8529.166992, 5376.593262),
        ["Hollow Shop"] = Vector(1191.425293, 7953.031250, 5351.293457),
    },
}

for _, region in ipairs(config.regions) do
    region.mesh_yaw = 90
    region.marker_positions = placements[region.id]
    region.world_positions = world_positions[region.id]
    local half_x = region.id == "seireitei" and 54.52 or (region.id == "zoneneutre2" and 45.45 or 50)
    region.image_origin = mesh_point(-half_x, 50, 0.5)
    region.image_u = mesh_point(half_x * 2, 0, 0)
    region.image_v = mesh_point(0, -100, 0)
end

local palace = config.by_id.hueco_lasnoches
palace.model_angle = Angle(0, -90, 0)
palace.image_origin = mesh_point(-58.4, 44.2, 0.12)
palace.image_u = mesh_point(115, 0, 0)
palace.image_v = mesh_point(0, -87.5, 0)
-- Calage XY sur les murs de la salle centrale et les ailes du BSP. Les
-- maquettes simplifient les hauteurs : on utilise le sol du bodygroup choisi.
palace.world_transform = { origin = Vector(0, 0, 5270), model_origin = mesh_point(2.269, -7.75, 0.12),
    scale = Vector(0.00375, 0.003688, 0.006048), yaw = 90 }
palace.floor_split = 6000
palace.floors = {
    ground = { label = "RDC", hide_upper = 1, hide_ground = 0, body_value = 1, height = 0.12 },
    upper = { label = "Étage", hide_upper = 0, hide_ground = 1, body_value = 2, height = 6.12 },
}
palace.marker_floors = {}
for name, pos in pairs(placements.hueco_lasnoches) do
    palace.marker_floors[name] = pos.z < 3 and "ground" or "upper"
end

return config
