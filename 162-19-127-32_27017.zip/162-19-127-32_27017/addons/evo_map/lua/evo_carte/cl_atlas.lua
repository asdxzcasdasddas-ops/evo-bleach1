-- "addons\\evo_map\\lua\\evo_carte\\cl_atlas.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Interface native de l'atlas : la maquette occupe la scène, les outils restent
-- en périphérie. Pas de CEF ni de texture de carte dans le viewer du monde.
return function(atlas)
    local config, data = atlas.config, atlas.data
    local ipairs, is_valid = ipairs, IsValid
    local floor, min, max = math.floor, math.min, math.max
    local scale = atlas.Scale
    local C = {
        bg = Color(9, 13, 18, 248), panel = Color(16, 22, 29, 250),
        raised = Color(23, 31, 40), hover = Color(31, 42, 52), line = Color(48, 60, 71, 160),
        text = Color(229, 235, 238), muted = Color(146, 161, 173), dim = Color(101, 119, 134),
        gold = Color(221, 190, 125), green = Color(132, 204, 156), blue = Color(123, 203, 236),
    }
    local KIND = { poi = "LIEU", sword = "ENTRAÎNEMENT", flag = "TERRITOIRE", boss = "BOSS VIVANT" }
    local COLORS = { poi = C.blue, sword = C.gold, flag = C.green, boss = Color(241, 132, 108) }
    local SYMBOLS = { poi = "·", sword = "/", flag = "F", boss = "!" }
    local diamond = { {}, {}, {}, {} }
    -- Carnet de consultation pour cette session client, partagé entre ouvertures.
    atlas.consulted = atlas.consulted or {}
    local DESCRIPTIONS = {
        ["Académie"] = "Repère l'académie et les accès autour du bâtiment.",
        ["Senkaimon"] = "Localise le passage du Senkaimon dans la cité.",
        ["Urahara Shop"] = "Retrouve la boutique d'Urahara dans le quartier.",
        ["Hollow Shop"] = "Localise la boutique parmi les couloirs du palais.",
        ["Coiffeur"] = "Prépare ta visite chez le coiffeur.",
        ["Tatoueur"] = "Repère l'atelier du tatoueur.",
        ["Chirurgien esthétique"] = "Localise le service de personnalisation du visage.",
        ["Las Noches"] = "Explore les ailes du palais en changeant de niveau.",
        ["Entrée"] = "Repère l'accès principal du palais au rez-de-chaussée.",
        ["Portes Désert"] = "Retrouve les portes du palais qui donnent sur le désert.",
        ["Salle de rassemblement"] = "Prépare un point de rendez-vous dans le palais.",
        ["Salle des Espadas"] = "Repère la salle des Espadas et ses accès à l'étage.",
        ["Duel de sang"] = "Observe les abords du lieu avant de t'y rendre.",
    }

    local function description(marker)
        if DESCRIPTIONS[marker.name] then return DESCRIPTIONS[marker.name] end
        if string.find(marker.name, "Division ", 1, true) == 1 then return "Repère les quartiers de cette division et leurs accès." end
        if string.find(marker.name, "Ordre ", 1, true) == 1 then return "Retrouve les quartiers de cet ordre à l'étage du palais." end
        return marker.kind == "sword" and "Repère cette aire pour ton prochain entraînement."
            or "Observe ce lieu et prépare ton point de rendez-vous."
    end

    function atlas.DrawMarker(marker, x, y, active)
        local color = COLORS[marker.kind] or C.blue
        local radius = scale(active and 13 or 10)
        surface.SetDrawColor(color.r, color.g, color.b, active and 125 or 70)
        surface.DrawLine(x, y, x, y + scale(17))
        surface.SetMaterial(atlas.glow)
        surface.SetDrawColor(color.r, color.g, color.b, active and 145 or 55)
        surface.DrawTexturedRect(x - radius * 2, y - radius * 2, radius * 4, radius * 4)
        draw.RoundedBox(radius, x - radius, y - radius, radius * 2, radius * 2, C.bg)
        surface.DrawCircle(x, y, radius, color.r, color.g, color.b, 240)
        draw.SimpleText(SYMBOLS[marker.kind] or "·", "EVO_Atlas_Small", x, y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if active or marker.kind == "boss" then
            local pulse = 0.5 + 0.5 * math.sin(SysTime() * 3)
            surface.DrawCircle(x, y, radius + scale(4 + pulse * 3), color.r, color.g, color.b, 70 + pulse * 90)
        end
    end

    function atlas.DrawLabel(label, x, y, width, active)
        surface.SetFont("EVO_Atlas_Small")
        local tw, th = surface.GetTextSize(label)
        local bw, bh = min(tw + scale(20), width - scale(20)), th + scale(10)
        local left = math.Clamp(x - bw * 0.5, scale(8), width - bw - scale(8))
        draw.RoundedBox(scale(4), left, y - bh * 0.5, bw, bh, C.bg)
        draw.SimpleText(label, "EVO_Atlas_Small", left + bw * 0.5, y,
            active and C.text or C.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    function atlas.DrawPlayer(x, y, direction_x, direction_y)
        local color = C.blue
        surface.DrawCircle(x, y, scale(17), color.r, color.g, color.b, 150)
        local length_2d = math.sqrt(direction_x * direction_x + direction_y * direction_y)
        local dx, dy = 0, -1
        if length_2d > 0.001 then dx, dy = direction_x / length_2d, direction_y / length_2d end
        local length, width = scale(11), scale(7)
        diamond[1].x, diamond[1].y = x + dx * length, y + dy * length
        diamond[2].x, diamond[2].y = x - dx * length * 0.7 - dy * width, y - dy * length * 0.7 + dx * width
        diamond[3].x, diamond[3].y = x - dx * length * 0.3, y - dy * length * 0.3
        diamond[4].x, diamond[4].y = x - dx * length * 0.7 + dy * width, y - dy * length * 0.7 - dx * width
        draw.NoTexture()
        surface.SetDrawColor(color)
        surface.DrawPoly(diamond)
    end

    local function text_fit(text, font, width)
        surface.SetFont(font)
        if surface.GetTextSize(text) <= width then return text end
        local length = utf8.len(text) or #text
        while length > 0 do
            local part = utf8.sub(text, 1, length) .. "…"
            if surface.GetTextSize(part) <= width then return part end
            length = length - 1
        end
        return ""
    end

    local function button(parent, label, action, primary)
        local b = vgui.Create("DButton", parent)
        b:SetText("")
        b.label = label
        b:SetCursor("hand")
        b.Paint = function(s, w, h)
            local accent = atlas.frame and atlas.frame.region and atlas.frame.region.accent or C.gold
            local active = s.active and s.active()
            draw.RoundedBox(scale(5), 0, 0, w, h, s:IsHovered() and C.hover or C.raised)
            if primary or active then
                surface.SetDrawColor(accent.r, accent.g, accent.b, s:IsEnabled() and 190 or 70)
                surface.DrawRect(0, h - scale(2), w, scale(2))
            end
            draw.SimpleText(text_fit(s.label, "EVO_Atlas_Small", w - scale(14)), "EVO_Atlas_Small", w * 0.5, h * 0.5,
                s:IsEnabled() and (active and accent or C.text) or C.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function(s)
            surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
            action(s)
        end
        return b
    end

    local function normalize(text)
        text = string.lower(text or "")
        -- Remplacement explicite : les classes de motifs Lua coupent l'UTF-8.
        for a, b in pairs({ ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["ë"] = "e", ["É"] = "e",
            ["à"] = "a", ["â"] = "a", ["Â"] = "a", ["î"] = "i", ["ï"] = "i", ["ô"] = "o",
            ["ù"] = "u", ["û"] = "u", ["ç"] = "c" }) do text = string.Replace(text, a, b) end
        return text
    end

    function atlas.Feedback(text)
        if is_valid(atlas.frame) then
            atlas.frame.feedback = text
            atlas.frame.feedback_until = SysTime() + 5
        end
    end

    local function current_region(regions)
        local player = LocalPlayer()
        if is_valid(player) then
            -- Une emprise précise prime toujours sur une simple bande Z.
            for _, r in ipairs(regions) do
                if r.world_bounds and atlas.Contains(r, player:GetPos()) then return r end
            end
            for _, r in ipairs(regions) do
                if r.auto_select ~= false and atlas.Contains(r, player:GetPos()) then return r end
            end
        end
        return regions[1]
    end

    function atlas.Open(start_id, personal)
        if is_valid(atlas.frame) then atlas.frame:Remove() end
        atlas.RequestState()
        atlas.Fonts()
        local regions = atlas.RegionsForPlayer()
        local region = current_region(regions)
        for _, r in ipairs(regions) do if r.id == start_id then region = r break end end
        local frame = vgui.Create("DFrame")
        atlas.frame = frame
        frame:SetTitle("")
        frame:ShowCloseButton(false)
        frame:SetDraggable(false)
        frame:SetSizable(false)
        frame:SetDeleteOnClose(true)
        frame:SetSize(ScrW(), ScrH())
        frame:SetPos(0, 0)
        frame:MakePopup()
        frame.regions, frame.region = regions, region
        frame.filter, frame.query, frame.selected = "all", "", nil
        frame.opened_at = SysTime()
        frame.Paint = function(s, w, h)
            surface.SetDrawColor(C.bg)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(s.region.accent)
            surface.DrawRect(scale(28), scale(27), scale(3), scale(42))
            draw.SimpleText("ATLAS DES MONDES", "EVO_Atlas_Title", scale(45), scale(24), C.text)
            draw.SimpleText("CHANGER DE ZONE", "EVO_Atlas_Tiny", scale(28), scale(89), C.muted)
            if s.feedback and SysTime() < (s.feedback_until or 0) then
                draw.SimpleText(text_fit(s.feedback, "EVO_Atlas_Small", w * 0.52), "EVO_Atlas_Small", w - scale(32), h - scale(26), C.gold, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            else
                draw.SimpleText("ÉCHAP   Fermer l'atlas", "EVO_Atlas_Small", w - scale(32), h - scale(26), C.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end

        frame.close_button = button(frame, "FERMER   ×", function() frame:Close() end)
        frame.buy_button = button(frame, "Carte de poche · 10 000 ¥", function()
            local player = LocalPlayer()
            if not is_valid(player) or player:GetEvoNWBool("EvoPocketMap", false) then return end
            if SysTime() < (frame.buy_next or 0) then return end
            frame.buy_next = SysTime() + 0.7
            net.Start("EVO:Map:Buy")
            net.SendToServer()
            atlas.Feedback("Achat en cours…")
        end)
        frame.create_button = button(frame, "Annoter une carte", function()
            if not (EVO_CARTE and EVO_CARTE.CanCreate(LocalPlayer()) and EVO_CARTE.OpenCreator) then return end
            local id = frame.region.id
            if not EVO_CARTE.GetMapById(id) then atlas.Feedback("Les annotations ne sont pas encore disponibles pour ce relief.") return end
            frame:Remove()
            EVO_CARTE.OpenCreator(id)
        end)

        frame.tabs = vgui.Create("DPanel", frame)
        frame.tabs:SetPaintBackground(false)
        frame.tab_buttons = {}
        for i, r in ipairs(regions) do
            local number = string.format("%02d", i)
            local b = button(frame.tabs, r.name, function()
                if frame.region.id ~= r.id then frame:SetRegion(r) end
            end)
            b.active = function() return frame.region.id == r.id end
            -- Toutes les régions restent visibles, notamment les deux zones
            -- neutres : le clic change directement le relief dans cette fenêtre.
            b.Paint = function(s, w, h)
                local active = s.active()
                draw.RoundedBox(scale(5), 0, 0, w, h, (active or s:IsHovered()) and C.hover or C.raised)
                surface.SetDrawColor(r.accent.r, r.accent.g, r.accent.b, active and 255 or 120)
                surface.DrawRect(0, scale(8), scale(3), h - scale(16))
                draw.SimpleText(number, "EVO_Atlas_Body", scale(25), h * 0.5, r.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(text_fit(r.name, "EVO_Atlas_Body", w - scale(80)), "EVO_Atlas_Body", scale(51), scale(11), C.text)
                draw.SimpleText(active and "CARTE AFFICHÉE" or "CLIQUER POUR EXPLORER", "EVO_Atlas_Tiny", scale(51), scale(38), active and r.accent or C.muted)
                if not active then
                    draw.SimpleText("›", "EVO_Atlas_Body", w - scale(15), h * 0.5, C.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
            frame.tab_buttons[#frame.tab_buttons + 1] = b
        end

        local scene = vgui.Create("EVO_AtlasScene", frame)
        frame.scene, scene.owner = scene, frame
        frame.scene_header = vgui.Create("DPanel", scene)
        frame.scene_header:SetMouseInputEnabled(false)
        frame.scene_header.Paint = function(_, w, h)
            draw.SimpleText(frame.region.realm .. "   /   EXPLORATION", "EVO_Atlas_Tiny", scale(26), scale(19), frame.region.accent)
            draw.SimpleText(frame.region.name, "EVO_Atlas_Heading", scale(26), scale(39), C.text)
            local subtitle = frame.region.subtitle
            draw.SimpleText(text_fit(subtitle, "EVO_Atlas_Small", w - scale(52)), "EVO_Atlas_Small", scale(27), scale(77), C.muted)
        end

        frame.toolbar = vgui.Create("DPanel", scene)
        frame.toolbar:SetPaintBackground(false)
        frame.tools = {
            button(frame.toolbar, "+", function() scene:Zoom(1) end),
            button(frame.toolbar, "−", function() scene:Zoom(-1) end),
            button(frame.toolbar, "Vue d'ensemble", function() scene:ResetView() end),
            button(frame.toolbar, "Vue du dessus", function() scene:ResetView() scene.goal_pitch = 89 end),
            button(frame.toolbar, "Contempler", function() scene.touring = not scene.touring end),
            button(frame.toolbar, "Noms", function() scene.labels = not scene.labels end),
            button(frame.toolbar, "Lieu précédent", function() frame:NextStop(-1) end),
            button(frame.toolbar, "Lieu suivant", function() frame:NextStop() end),
        }
        frame.tools[5].active = function() return scene.touring end
        frame.tools[6].active = function() return scene.labels end
        frame.floor_bar = vgui.Create("DPanel", scene)
        frame.floor_bar:SetPaintBackground(false)
        frame.floor_buttons = {}
        for _, option in ipairs({ { "all", "Tout" }, { "ground", "RDC" }, { "upper", "Étage" } }) do
            local id = option[1]
            local b = button(frame.floor_bar, option[2], function() frame:SetFloor(id) end)
            b.active = function() return scene.floor_id == id end
            frame.floor_buttons[#frame.floor_buttons + 1] = b
        end
        frame.clean_button = button(scene, "Masquer les repères", function(s)
            scene.clean = not scene.clean
            s.label = scene.clean and "Afficher les repères" or "Masquer les repères"
            frame:InvalidateLayout(true)
        end)

        frame.hints = vgui.Create("DPanel", scene)
        frame.hints:SetMouseInputEnabled(false)
        frame.hints.Paint = function(_, w, h)
            local first = "GLISSER GAUCHE  Tourner     /     GLISSER DROIT  Déplacer"
            local second = "MOLETTE  Zoomer     /     Z Q S D  Déplacer la vue     /     CLIC  Choisir un lieu"
            draw.SimpleText(first, "EVO_Atlas_Tiny", scale(24), scale(5), C.muted)
            draw.SimpleText(second, "EVO_Atlas_Tiny", scale(24), scale(25), C.dim)
        end

        frame.sidebar = vgui.Create("DPanel", frame)
        frame.sidebar.Paint = function(_, w, h)
            draw.RoundedBox(scale(6), 0, 0, w, h, C.panel)
            draw.SimpleText("CARNET D'EXPLORATION", "EVO_Atlas_Small", scale(20), scale(19), C.text)
            local count = frame.filtered_count or 0
            draw.SimpleText((frame.consulted_count or 0) .. " / " .. count .. " lieux consultés · cette session", "EVO_Atlas_Tiny", scale(20), scale(44), C.muted)
        end
        frame.search = vgui.Create("DTextEntry", frame.sidebar)
        frame.search:SetFont("EVO_Atlas_Body")
        frame.search:SetUpdateOnType(true)
        frame.search:SetPlaceholderText("Rechercher un lieu…")
        frame.search:SetTextColor(C.text)
        frame.search:SetCursorColor(C.text)
        frame.search:SetHighlightColor(Color(68, 90, 110))
        frame.search.Paint = function(s, w, h)
            draw.RoundedBox(scale(4), 0, 0, w, h, C.raised)
            if s:GetValue() == "" and not s:HasFocus() then
                draw.SimpleText("Rechercher un lieu…", "EVO_Atlas_Body", scale(10), h * 0.5, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            s:DrawTextEntryText(C.text, C.blue, C.text)
        end
        frame.search.OnValueChange = function(_, value)
            frame.query = normalize(value)
            frame:SetFilter(frame.filter)
        end
        frame.search.OnEnter = function(s) s:KillFocus() end
        frame.filters = {}
        for _, item in ipairs({ {"all", "Tout"}, {"poi", "Lieux"}, {"flag", "Drapeaux"}, {"sword", "Entraîn."}, {"boss", "Boss"} }) do
            local id, label = item[1], item[2]
            local b = button(frame.sidebar, label, function() frame:SetFilter(id) end)
            b.active = function() return frame.filter == id end
            frame.filters[#frame.filters + 1] = b
        end
        frame.list = vgui.Create("DScrollPanel", frame.sidebar)
        local bar = frame.list:GetVBar()
        bar:SetWide(scale(4))
        bar:SetHideButtons(true)
        bar.Paint = function() end
        bar.btnGrip.Paint = function(_, w, h) draw.RoundedBox(2, 0, 0, w, h, C.dim) end
        frame.empty = vgui.Create("DLabel", frame.list)
        frame.empty:SetFont("EVO_Atlas_Body")
        frame.empty:SetTextColor(C.muted)
        frame.empty:SetWrap(true)
        frame.empty:Dock(TOP)
        frame.empty:SetTall(scale(110))

        frame.detail = vgui.Create("DPanel", frame.sidebar)
        frame.detail.Paint = function(_, w, h)
            surface.SetDrawColor(C.line)
            surface.DrawRect(0, 0, w, 1)
            local m = frame.selected
            if not m then
                draw.SimpleText("CHOISIS TA DESTINATION", "EVO_Atlas_Tiny", 0, scale(17), frame.region.accent)
                draw.SimpleText("Sélectionne un lieu sur le relief", "EVO_Atlas_Small", 0, scale(47), C.muted)
                draw.SimpleText("ou dans le carnet pour l'explorer.", "EVO_Atlas_Small", 0, scale(68), C.muted)
                return
            end
            draw.SimpleText(KIND[m.kind] or "LIEU", "EVO_Atlas_Tiny", 0, scale(17), COLORS[m.kind] or C.blue)
            draw.SimpleText(text_fit(m.name, "EVO_Atlas_Body", w), "EVO_Atlas_Body", 0, scale(40), C.text)
            local lines = frame.detail_lines or {}
            for i, line in ipairs(lines) do
                draw.SimpleText(text_fit(line, "EVO_Atlas_Small", w), "EVO_Atlas_Small", 0, scale(68 + (i - 1) * 22), C.muted)
            end
        end
        function frame:ToggleGuidance()
            if not frame.selected then return end
            local pos = atlas.ResolveDestination(frame.region, frame.selected)
            if not pos or not EVO_MapPin then atlas.Feedback("Destination indisponible sur ce serveur.") return end
            EVO_MapPin.Toggle(pos + Vector(0, 0, 48), frame.selected.name, frame.selected.key)
            frame:RefreshDetail()
        end
        frame.pin_button = button(frame.detail, "Guider vers ce lieu", function() frame:ToggleGuidance() end, true)
        frame.locate_button = button(frame.sidebar, "Recentrer sur moi", function()
            local r = current_region(frame.regions)
            local player = LocalPlayer()
            if not is_valid(player) or not atlas.Contains(r, player:GetPos()) then
                atlas.Feedback("Ta position n'est pas disponible dans cet atlas.") return
            end
            if frame.region ~= r then frame:SetRegion(r) end
            local floor_id = scene:WorldFloor(player:GetPos())
            if floor_id then frame:SetFloor(floor_id) end
            local raw = scene:WorldToRaw(player:GetPos())
            if raw then scene:Focus(scene:RawToScene(raw))
            else atlas.Feedback("Le relief de ta zone n'est pas encore calibré pour ta position.") end
        end)
        frame.clear_button = button(frame.sidebar, "Retirer le repère", function()
            if EVO_MapPin then EVO_MapPin.Clear() end
            frame:RefreshDetail()
        end)

        function frame:SetFilter(id)
            self.filter = id
            if self.selected and not self:Matches(self.selected) then self.selected, scene.selected = nil, nil end
            self:BuildList()
            self:RefreshDetail()
            self:InvalidateLayout(true)
        end

        function frame:Matches(marker)
            local floor_id = marker.floor or scene:WorldFloor(marker.pos)
            if not scene:ShowsFloor(floor_id) then return false end
            if self.filter ~= "all" and marker.kind ~= self.filter then return false end
            return self.query == "" or string.find(marker.search_name or normalize(marker.name), self.query, 1, true) ~= nil
        end

        function frame:RefreshDetail()
            local m = self.selected
            self.pin_button:SetVisible(m ~= nil)
            if not m then return end
            local lines = {}
            if m.kind == "flag" then
                local zone, cfg = atlas.FlagState(m)
                lines[#lines + 1] = "Contrôle : " .. (zone and zone.owner or "état indisponible")
                local danger = (cfg and cfg.danger) or m.danger_level
                lines[#lines + 1] = "Danger : " .. ({ "Faible", "Moyen", "Élevé" })[danger or 1]
                local fc = FlagCapture and FlagCapture.Config or {}
                lines[#lines + 1] = string.format("%d ¥ / %d min · Capture %d ¥", (fc.PassiveYenPerFlag or 100) * (danger or 1),
                    max(1, floor((fc.PassiveRewardInterval or 300) / 60)), fc.CaptureYenReward or 500)
                if zone and zone.capturingTeam and zone.capturingTeam ~= "" then
                    lines[#lines + 1] = "Capture : " .. zone.capturingTeam .. " " .. floor(zone.displayProgress or zone.progress or 0) .. "%"
                elseif zone and (zone.unlockTime or 0) > CurTime() then
                    lines[#lines + 1] = "Verrouillé : " .. math.ceil((zone.unlockTime - CurTime()) / 60) .. " min"
                else
                    lines[#lines + 1] = "Butin : jusqu'à " .. (fc.RewardMaxChests or 5) .. " coffres"
                end
            elseif m.kind == "boss" then
                lines[#lines + 1] = "Présence signalée · " .. tostring(m.tier or "boss")
            else
                lines[#lines + 1] = description(m)
            end
            local destination, approximate = atlas.ResolveDestination(self.region, m)
            local player = LocalPlayer()
            if destination and is_valid(player) then
                lines[#lines + 1] = (approximate and "≈ " or "") .. floor(player:GetPos():Distance(destination) / 52.5) .. " m · à vol d'oiseau"
            else
                lines[#lines + 1] = self.region.server ~= game.GetMap() and "Guidage disponible sur le serveur de cette région." or "Destination à relever en jeu."
            end
            self.detail_lines = lines
            self.pin_button:SetEnabled(destination ~= nil and EVO_MapPin ~= nil)
            local pin = EVO_MapPin and EVO_MapPin.Get()
            self.pin_button.label = pin and pin.key == m.key and "Retirer ce repère" or "Guider vers ce lieu"
        end

        function frame:SelectMarker(marker)
            self.selected = marker
            atlas.consulted[marker.key] = true
            scene.selected = marker.key
            scene:Focus(marker.scene_pos)
            self:RefreshDetail()
            self:BuildList()
            self:InvalidateLayout(true)
        end

        function frame:NextStop(direction)
            local stops, current = {}, 0
            for _, marker in ipairs(self.points or {}) do
                if marker.scene_pos and self:Matches(marker) then
                    stops[#stops + 1] = marker
                    if marker == self.selected then current = #stops end
                end
            end
            if #stops == 0 then atlas.Feedback("Aucun lieu disponible avec ces filtres.") return end
            local index = current == 0 and (direction == -1 and #stops or 1) or (current - 1 + (direction or 1)) % #stops + 1
            self:SelectMarker(stops[index])
            atlas.Feedback("Étape " .. index .. " / " .. #stops .. " · " .. self.selected.name)
        end

        function frame:SetFloor(id)
            scene:SetFloor(id)
            if self.selected and not self:Matches(self.selected) then
                self.selected, scene.selected = nil, nil
            end
            -- Éviter un ancien indicateur du joueur pendant les 500 ms avant
            -- l'actualisation suivante, et garder zoom / rotation / recherche.
            scene.player_pos, scene.player_ahead = nil, nil
            self:BuildList()
            self:RefreshDetail()
            self:InvalidateLayout(true)
        end

        function frame:BuildList()
            if self.rows then for _, row in ipairs(self.rows) do row:Remove() end end
            self.rows = {}
            self.consulted_count = 0
            for _, marker in ipairs(self.points or {}) do
                if self:Matches(marker) then
                    if atlas.consulted[marker.key] then self.consulted_count = self.consulted_count + 1 end
                    local row = vgui.Create("DButton", self.list)
                    row:SetText("")
                    row:Dock(TOP)
                    row:DockMargin(0, 0, scale(5), scale(5))
                    row:SetTall(scale(56))
                    row:SetCursor("hand")
                    row.Paint = function(s, w, h)
                        local active = scene.selected == marker.key
                        draw.RoundedBox(scale(4), 0, 0, w, h, active and C.hover or (s:IsHovered() and C.raised or C.panel))
                        if active then surface.SetDrawColor(frame.region.accent) surface.DrawRect(0, scale(9), scale(2), h - scale(18)) end
                        local color = COLORS[marker.kind] or C.blue
                        draw.SimpleText(SYMBOLS[marker.kind] or "·", "EVO_Atlas_Body", scale(19), h * 0.5, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                        draw.SimpleText(text_fit(marker.name, "EVO_Atlas_Small", w - scale(49)), "EVO_Atlas_Small", scale(39), scale(11), C.text)
                        local caption = (KIND[marker.kind] or "LIEU") .. (atlas.consulted[marker.key] and "  ·  CONSULTÉ" or "")
                        draw.SimpleText(caption, "EVO_Atlas_Tiny", scale(39), scale(33), C.dim)
                    end
                    row.DoClick = function() frame:SelectMarker(marker) end
                    self.rows[#self.rows + 1] = row
                end
            end
            self.filtered_count = #self.rows
            self.empty:SetVisible(#self.rows == 0)
            self.empty:SetText(#(self.points or {}) == 0 and "Explore librement ce relief.\nLes points d'intérêt de cette zone restent à relever." or "Aucun lieu ne correspond.\nEssaie un autre nom ou filtre.")
        end

        function frame:RefreshPoints(preserve_rows)
            local points = atlas.Points(self.region)
            if preserve_rows and self.points and #points == #self.points then
                local same = true
                for i, m in ipairs(points) do if self.points[i].key ~= m.key then same = false break end end
                if same then
                    local visibility_changed = false
                    for i, m in ipairs(points) do
                        local current = self.points[i]
                        local was_visible = self:Matches(current)
                        current.pos, current.x, current.y = m.pos, m.x, m.y
                        current.scene_pos = scene:MarkerPosition(current)
                        local visible = self:Matches(current)
                        if was_visible ~= visible then visibility_changed = true end
                        if self.selected == current and not visible then self.selected, scene.selected = nil, nil end
                    end
                    if visibility_changed then
                        self:BuildList()
                        self:RefreshDetail()
                        self:InvalidateLayout(true)
                    end
                    return
                end
            end
            local selected_key = self.selected and self.selected.key
            self.points = points
            self.selected = nil
            for _, m in ipairs(self.points) do
                m.search_name = normalize(m.name)
                if selected_key == m.key then self.selected = m end
            end
            scene:SetPoints(self.points)
            scene.selected = self.selected and self.selected.key
            self:BuildList()
            self:RefreshDetail()
        end

        function frame:SetRegion(r)
            self.region, self.selected = r, nil
            self.filter, self.query = "all", ""
            self.search:SetText("")
            scene:LoadRegion(r)
            self.floor_bar:SetVisible(r.floors ~= nil)
            self:RefreshPoints()
            self:InvalidateLayout(true)
            self.create_button:SetEnabled(EVO_CARTE and EVO_CARTE.CanCreate(LocalPlayer()) and EVO_CARTE.GetMapById(r.id) ~= nil or false)
        end

        function frame:PerformLayout(w, h)
            local margin, gutter = scale(28), scale(14)
            local side = scale(330)
            local top, bottom = scale(184), scale(49)
            self.close_button:SetPos(w - margin - scale(110), scale(30))
            self.close_button:SetSize(scale(110), scale(40))
            self.buy_button:SetPos(w - margin - scale(354), scale(30))
            self.buy_button:SetSize(scale(230), scale(40))
            self.create_button:SetPos(w - margin - scale(540), scale(30))
            self.create_button:SetSize(scale(172), scale(40))
            self.tabs:SetPos(margin, scale(108))
            self.tabs:SetSize(w - margin * 2, scale(62))
            local tab_w = (self.tabs:GetWide() - gutter * (#self.tab_buttons - 1)) / #self.tab_buttons
            for i, b in ipairs(self.tab_buttons) do b:SetPos((i - 1) * (tab_w + gutter), 0) b:SetSize(tab_w, scale(62)) end
            local scene_w = w - margin * 2 - (side + gutter)
            local body_h = h - top - bottom
            self.sidebar:SetVisible(true)
            scene:SetPos(margin, top)
            scene:SetSize(scene_w, body_h)
            self.scene_header:SetPos(0, 0)
            self.scene_header:SetSize(scene_w, scale(108))
            self.toolbar:SetPos(scale(24), scale(117))
            self.toolbar:SetSize(scene_w - scale(48), scale(34))
            local tool_w = { 34, 34, 130, 125, 105, 65, 120, 110 }
            local tool_x = 0
            for i, b in ipairs(self.tools) do
                b:SetPos(tool_x, 0) b:SetSize(scale(tool_w[i]), scale(34)) tool_x = tool_x + scale(tool_w[i] + 6)
            end
            self.floor_bar:SetPos(scale(24), scale(160))
            self.floor_bar:SetSize(scale(234), scale(32))
            for i, b in ipairs(self.floor_buttons) do
                b:SetPos(scale((i - 1) * 80), 0)
                b:SetSize(scale(74), scale(32))
            end
            self.clean_button:SetPos(scale(24), body_h - scale(102))
            self.clean_button:SetSize(scale(172), scale(30))
            self.hints:SetPos(0, body_h - scale(55))
            self.hints:SetSize(scene_w - scale(120), scale(48))
            self.sidebar:SetPos(w - margin - side, top)
            self.sidebar:SetSize(side, body_h)
            self.search:SetPos(scale(18), scale(76))
            self.search:SetSize(side - scale(36), scale(39))
            local filter_w = (side - scale(36) - scale(16)) / 5
            for i, b in ipairs(self.filters) do b:SetPos(scale(18) + (i - 1) * (filter_w + scale(4)), scale(126)) b:SetSize(filter_w, scale(30)) end
            local detail_h = scale(self.selected and 253 or 143)
            local detail_top = body_h - detail_h - scale(92)
            self.list:SetPos(scale(15), scale(173))
            self.list:SetSize(side - scale(30), max(scale(80), detail_top - scale(185)))
            self.detail:SetPos(scale(20), detail_top)
            self.detail:SetSize(side - scale(40), detail_h)
            self.pin_button:SetPos(0, detail_h - scale(45))
            self.pin_button:SetSize(side - scale(40), scale(37))
            self.locate_button:SetPos(scale(18), body_h - scale(85))
            self.locate_button:SetSize(side - scale(36), scale(34))
            self.clear_button:SetPos(scale(18), body_h - scale(44))
            self.clear_button:SetSize(side - scale(36), scale(28))
        end

        frame.OnRemove = function(s)
            timer.Remove("EVO_Atlas::Refresh")
            scene:ReleaseModel()
            if atlas.frame == s then atlas.frame = nil end
            if personal and EVO_MapHold then EVO_MapHold.Stop() end
        end
        if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
        frame.OnKeyCodePressed = function(s, code)
            if code == KEY_ESCAPE then s:Close() return end
            if frame.search:HasFocus() then return end
            if code == KEY_HOME then scene:ResetView() end
            if code == KEY_LEFT or code == KEY_RIGHT then
                for i, r in ipairs(regions) do
                    if r == frame.region then frame:SetRegion(regions[(i - 1 + (code == KEY_LEFT and -1 or 1)) % #regions + 1]) break end
                end
            end
        end
        frame:InvalidateLayout(true)
        frame:SetRegion(region)
        frame:SetAlpha(0)
        frame:AlphaTo(255, 0.22, 0)

        local function refresh()
            if not is_valid(frame) then return end
            local player = LocalPlayer()
            local raw = is_valid(player) and scene:WorldToRaw(player:GetPos())
            if raw and not scene:ShowsFloor(scene:WorldFloor(player:GetPos())) then raw = nil end
            scene.player_pos = raw and scene:RawToScene(raw) or nil
            local ahead = is_valid(player) and scene:WorldToRaw(player:GetPos() + player:EyeAngles():Forward() * 80)
            scene.player_ahead = raw and ahead and scene:RawToScene(ahead) or nil
            local version = (NCM_WORLD_BOSS and NCM_WORLD_BOSS.EtatVersion or 0)
            local changed = version ~= frame.boss_version or atlas.anchor_version ~= frame.anchor_version
            frame.boss_version, frame.anchor_version = version, atlas.anchor_version
            frame:RefreshPoints(not changed)
            frame:RefreshDetail()
            local unlocked = is_valid(player) and player:GetEvoNWBool("EvoPocketMap", false)
            frame.buy_button.label = unlocked and "Carte de poche débloquée" or "Carte de poche · 10 000 ¥"
            frame.buy_button:SetEnabled(not unlocked)
            frame.clear_button:SetEnabled(EVO_MapPin and EVO_MapPin.Get() ~= nil or false)
        end
        refresh()
        timer.Create("EVO_Atlas::Refresh", 0.5, 0, refresh)
        if personal and EVO_MapHold then EVO_MapHold.Start(frame) end
    end

    hook.Add("OnScreenSizeChanged", "EVO_Atlas::Resize", function()
        atlas.Fonts()
        if is_valid(atlas.frame) then
            atlas.frame:SetSize(ScrW(), ScrH())
            atlas.frame:InvalidateLayout(true)
            atlas.frame:BuildList()
        end
    end)
end
