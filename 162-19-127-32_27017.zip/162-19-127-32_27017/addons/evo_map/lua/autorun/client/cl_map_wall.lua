-- "addons\\evo_map\\lua\\autorun\\client\\cl_map_wall.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MAP — CARTE DU MONDE MURALE (user 08/28) : la carte du monde en GRAND,
-- accrochée dans le monde (3D2D), IDENTIQUE pour tous et EN DIRECT : mêmes
-- tables/caches client que le viewer Échap (POI, drapeaux qui clignotent
-- pendant une capture, boss vivants), PLUS un état partagé serveur : la
-- RÉGION affichée (commutable) et les TRAITS dessinés au feutre (grade 10+),
-- diffusés en direct. [E] près du panneau : éditeur (lecture pour tous).
-- Position/angles/échelle : gizmo SA (evo_config_positions > Tableaux).
-- ============================================================================
if not CLIENT then return end

local PANEL_W, PANEL_H = 1240, 1360
local PAD, TITLE_H = 20, 100
local IMG = PANEL_W - PAD * 2 -- surface carrée de la carte
local DRAW_DIST_SQR = 2600 * 2600

local COL_BG     = Color(10, 10, 14, 240)
local COL_TITLE  = Color(238, 239, 243)
local COL_ACCENT = Color(207, 68, 78)
local COL_NAME   = Color(225, 227, 232, 230)
local COL_SHAD   = Color(0, 0, 0, 200)
local COL_MUTED  = Color(150, 154, 162)

surface.CreateFont("EVO_MapWall_Title", { font = "Bebas Neue", size = 84, weight = 400, antialias = true })
surface.CreateFont("EVO_MapWall_Name",  { font = "Bebas Neue", size = 26, weight = 400, antialias = true })
surface.CreateFont("EVO_MapWall_UI",    { font = "Bebas Neue", size = 26, weight = 400, antialias = true })

local whiteMat = Material("vgui/white")

-- ── État PARTAGÉ reçu du serveur : région courante + traits par région ──────
local sRegionCourante = nil
local tTraits = {} -- [regionId] = { {col, w, pts}, ... }

net.Receive("EVO:MapWall:Region", function()
	local sCour = net.ReadString()
	local sId = net.ReadString()
	if sCour ~= "" then sRegionCourante = sCour end
	if EVO_CARTE and EVO_CARTE.NetReadStrokes then
		tTraits[sId] = EVO_CARTE.NetReadStrokes()
	end
end)

net.Receive("EVO:MapWall:Stroke", function()
	local sId = net.ReadString()
	if not (EVO_CARTE and EVO_CARTE.NetReadOneStroke) then return end
	local st = EVO_CARTE.NetReadOneStroke()
	tTraits[sId] = tTraits[sId] or {}
	tTraits[sId][#tTraits[sId] + 1] = st
end)

net.Receive("EVO:MapWall:Retire", function()
	local sId = net.ReadString()
	local t = tTraits[sId]
	if t and #t > 0 then t[#t] = nil end
end)

-- ── Rendu feutre (recette renderStroke d'evo_carte, coords 0..1 -> rect) ────
local function RenderTrait(st, dx, dy, dw, dh)
	local C = EVO_CARTE
	if not C then return end
	local col = C.Palette[st.col] or C.Palette[1]
	local wpx = math.max(1, (C.Widths[st.w] or 4) * dw / 1000)
	local pts, n = st.pts, math.floor(#(st.pts or {}) / 2)
	local px, py
	surface.SetDrawColor(col.r, col.g, col.b, 255)
	for k = 1, n do
		local x = dx + pts[(k - 1) * 2 + 1] * dw
		local y = dy + pts[(k - 1) * 2 + 2] * dh
		if px then
			local ddx, ddy = x - px, y - py
			local len = math.sqrt(ddx * ddx + ddy * ddy)
			if len >= 0.5 then
				surface.SetMaterial(whiteMat)
				surface.DrawTexturedRectRotated((px + x) / 2, (py + y) / 2, len, wpx, -math.deg(math.atan2(ddy, ddx)))
			end
		end
		surface.DrawRect(x - wpx / 2, y - wpx / 2, wpx, wpx) -- jointure carrée
		px, py = x, y
	end
end

local function RegionAffichee(p)
	local sId = sRegionCourante or p.region
	local r = EVO_MAP_WALL.RegionById(game.GetMap(), sId)
	if r then return sId, r.path, r.nom end
	return p.region, p.path, ""
end

local _mats = {}
local function mapMat(path)
	if _mats[path] == nil then
		local m = Material(path, "smooth mips")
		_mats[path] = (not m or m:IsError()) and false or m
	end
	return _mats[path]
end

-- Dessine la carte + traits + marqueurs dans un rect (partagé mur/éditeur).
local function DessinerCarte(sId, sPath, ix, iy, dw, dh)
	local mat = mapMat(sPath)
	if mat then
		surface.SetMaterial(mat)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(ix, iy, dw, dh)
	end
	for _, st in ipairs(tTraits[sId] or {}) do
		RenderTrait(st, ix, iy, dw, dh)
	end
	-- Marqueurs FIXES du viewer Échap (mêmes tables live) + boss vivants.
	if EVO_Map_DrawMarker and EVO_Map_GetMarkers then
		for _, m in ipairs(EVO_Map_GetMarkers(sId)) do
			pcall(EVO_Map_DrawMarker, m, ix + m.x * dw, iy + m.y * dh, false)
		end
		if EVO_Map_BossMarks then
			for _, b in ipairs(EVO_Map_BossMarks(sId) or {}) do
				pcall(EVO_Map_DrawMarker, b, ix + b.x * dw, iy + b.y * dh, false)
			end
		end
	end
	return mat ~= false
end

local function drawPanel(p)
	draw.RoundedBox(16, 0, 0, PANEL_W, PANEL_H, COL_BG)
	local sId, sPath, sNom = RegionAffichee(p)
	draw.SimpleText("CARTE DU MONDE", "EVO_MapWall_Title", PANEL_W / 2, TITLE_H / 2 - 4,
		COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(math.floor(PANEL_W * 0.32), TITLE_H - 20, math.floor(PANEL_W * 0.36), 3)
	if sNom ~= "" then
		draw.SimpleText(sNom, "EVO_MapWall_Name", PANEL_W / 2, TITLE_H - 2,
			COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local ix, iy = PAD, TITLE_H + math.floor(PAD * 0.5)
	if not DessinerCarte(sId, sPath, ix, iy, IMG, IMG) then
		draw.SimpleText("Carte indisponible", "EVO_MapWall_Name", PANEL_W / 2, iy + IMG / 2,
			COL_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	-- Noms des lieux (le mur n'a pas de survol souris).
	if EVO_Map_GetMarkers then
		for _, m in ipairs(EVO_Map_GetMarkers(sId)) do
			if m.name then
				local fx, fy = ix + m.x * IMG, iy + m.y * IMG
				draw.SimpleText(m.name, "EVO_MapWall_Name", fx + 1, fy + 25,
					COL_SHAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				draw.SimpleText(m.name, "EVO_MapWall_Name", fx, fy + 24,
					COL_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			end
		end
	end
end

hook.Add("PostDrawTranslucentRenderables", "EVO_MapWall::Draw", function(bDepth, bSky)
	if bDepth or bSky then return end
	local tList = EVO_MAP_WALL and EVO_MAP_WALL.Panels and EVO_MAP_WALL.Panels[game.GetMap()]
	if not istable(tList) then return end
	local vEye = EyePos()
	for _, p in ipairs(tList) do
		if isvector(p.pos) and vEye:DistToSqr(p.pos) <= DRAW_DIST_SQR then
			local s = p.scale or 0.2
			local a = p.ang or angle_zero
			-- p.pos = CENTRE du panneau. Repère de cam.Start3D2D (documenté dans
			-- evo_affiche/sh_config) : l'origine est le coin HAUT-GAUCHE, +x2D suit
			-- Forward, +y2D suit RIGHT, et Up est la NORMALE du plan. On recule donc
			-- d'une demi-taille sur Forward ET sur Right — les deux axes DU PLAN.
			-- (Un + sur Right décalait la carte de sa largeur ; passer par Up la
			-- sortait carrément de son plan, elle flottait au-dessus.)
			local vCorner = p.pos - a:Forward() * (PANEL_W / 2 * s) - a:Right() * (PANEL_H / 2 * s)
			cam.Start3D2D(vCorner, a, s)
				local ok, err = pcall(drawPanel, p)
				cam.End3D2D()
				if not ok then ErrorNoHalt("[evo_map_wall] " .. tostring(err) .. "\n") end
		end
	end
end)

-- ════ L'ÉDITEUR ([E] près du panneau) : lecture pour tous, outils grade 10+ ══
local frameWall

local function EnvoyerTrait(sId, st)
	net.Start("EVO:MapWall:Trait")
	net.WriteString(sId)
	EVO_CARTE.NetWriteOneStroke(st.col, st.w, st.pts)
	net.SendToServer()
end

net.Receive("EVO:MapWall:Menu", function()
	if IsValid(frameWall) then frameWall:Remove() end
	local tRegions = EVO_MAP_WALL.RegionsDeLaMap()
	if not tRegions then return end
	local lp = LocalPlayer()
	local bOutils = EVO_MAP_WALL.PeutDessiner(lp)

	local h = math.floor(ScrH() * 0.86)
	local w = math.floor(h * 0.86)
	local f = vgui.Create("DFrame")
	frameWall = f
	f:SetSize(w, h)
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(true)
	f:MakePopup()
	f._col, f._w = 1, 2 -- couleur / épaisseur choisies
	f.Paint = function(_, fw, fh)
		draw.RoundedBox(10, 0, 0, fw, fh, Color(14, 14, 17, 248))
		draw.SimpleText("CARTE DU MONDE", "EVO_MapWall_UI", fw / 2, 22,
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Onglets de région (le CHANGEMENT est partagé par tout le serveur, grade 10+).
	local nTabW = math.floor((w - 32) / #tRegions)
	for i, r in ipairs(tRegions) do
		local b = vgui.Create("DButton", f)
		b:SetText("")
		b:SetPos(16 + (i - 1) * nTabW, 40)
		b:SetSize(nTabW - 6, 30)
		b.Paint = function(s2, bw, bh)
			local bActive = (sRegionCourante or tRegions[1].id) == r.id
			draw.RoundedBox(7, 0, 0, bw, bh, bActive and COL_ACCENT or Color(255, 255, 255, s2:IsHovered() and 22 or 10))
			draw.SimpleText(r.nom, "EVO_MapWall_UI", bw / 2, bh / 2,
				bActive and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			if not bOutils then
				notification.AddLegacy(string.format("Changer la carte est réservé au grade %d et plus.", EVO_MAP_WALL.GradeMin), NOTIFY_ERROR, 3)
				return
			end
			net.Start("EVO:MapWall:ChoixRegion")
			net.WriteString(r.id)
			net.SendToServer()
		end
	end

	-- Zone de dessin (recette de l'éditeur evo_carte : capture souris, coords 0..1).
	local mapY = 78
	local mapH = h - mapY - 76
	local mapP = vgui.Create("DPanel", f)
	mapP:SetPos(16, mapY)
	mapP:SetSize(w - 32, mapH)
	mapP:SetMouseInputEnabled(true)
	mapP._cur = nil
	mapP._drawing = false

	local function toImg(lx, ly)
		local ft = mapP._fit
		if not ft then return 0, 0, false end
		local ix, iy = (lx - ft[1]) / ft[3], (ly - ft[2]) / ft[4]
		return math.Clamp(ix, 0, 1), math.Clamp(iy, 0, 1), (ix >= 0 and ix <= 1 and iy >= 0 and iy <= 1)
	end
	local function finalize()
		local cur = mapP._cur
		mapP._cur = nil
		mapP._drawing = false
		-- L'append LOCAL vient du broadcast serveur (pas d'optimiste : sinon le
		-- trait se dédoublerait au retour du net).
		if cur and #cur.pts >= 4 then
			EnvoyerTrait(sRegionCourante or tRegions[1].id, cur)
		end
	end
	mapP.Paint = function(s2, pw, ph)
		draw.RoundedBox(8, 0, 0, pw, ph, Color(20, 20, 25, 245))
		local sId = sRegionCourante or tRegions[1].id
		local r = EVO_MAP_WALL.RegionById(game.GetMap(), sId) or tRegions[1]
		local nSide = math.min(pw, ph) - 8
		local dx, dy = (pw - nSide) / 2, (ph - nSide) / 2
		s2._fit = { dx, dy, nSide, nSide }
		DessinerCarte(sId, r.path, dx, dy, nSide, nSide)
		if s2._cur then RenderTrait(s2._cur, dx, dy, nSide, nSide) end
	end
	mapP.OnMousePressed = function(s2, code)
		if code ~= MOUSE_LEFT or not bOutils then return end
		local x, y = s2:CursorPos()
		local ix, iy, inside = toImg(x, y)
		if not inside then return end
		s2._cur = { col = f._col, w = f._w, pts = { ix, iy } }
		s2._drawing = true
		s2:MouseCapture(true)
	end
	mapP.OnCursorMoved = function(s2, x, y)
		if not (s2._drawing and s2._cur) then return end
		local ix, iy = toImg(x, y)
		local pts = s2._cur.pts
		local lx, ly = pts[#pts - 1], pts[#pts]
		if lx then
			local a2, b2 = ix - lx, iy - ly
			if (a2 * a2 + b2 * b2) < (0.004 * 0.004) then return end
		end
		if #pts / 2 >= ((EVO_CARTE and EVO_CARTE.MaxPointsPerStroke) or 90) then
			finalize()
			return
		end
		pts[#pts + 1] = ix
		pts[#pts + 1] = iy
	end
	mapP.OnMouseReleased = function(s2, code)
		if code == MOUSE_LEFT then
			finalize()
			s2:MouseCapture(false)
		end
	end

	-- Barre d'outils : palette + épaisseurs + annuler (grade 10+ seulement).
	local yBar = h - 66
	if bOutils and EVO_CARTE then
		for i, c in ipairs(EVO_CARTE.Palette) do
			local b = vgui.Create("DButton", f)
			b:SetText("")
			b:SetPos(16 + (i - 1) * 40, yBar)
			b:SetSize(34, 34)
			b.Paint = function(s2, bw, bh)
				draw.RoundedBox(8, 0, 0, bw, bh, c)
				if f._col == i then
					surface.SetDrawColor(255, 255, 255, 235)
					surface.DrawOutlinedRect(0, 0, bw, bh, 2)
				end
			end
			b.DoClick = function() f._col = i end
		end
		for i, nW in ipairs(EVO_CARTE.Widths) do
			local b = vgui.Create("DButton", f)
			b:SetText("")
			b:SetPos(16 + #EVO_CARTE.Palette * 40 + 12 + (i - 1) * 40, yBar)
			b:SetSize(34, 34)
			b.Paint = function(s2, bw, bh)
				draw.RoundedBox(8, 0, 0, bw, bh, Color(35, 35, 42, 240))
				local nT = 2 + i * 2
				surface.SetDrawColor(f._w == i and COL_ACCENT or Color(200, 200, 210))
				surface.DrawRect(7, bh / 2 - nT / 2, bw - 14, nT)
			end
			b.DoClick = function() f._w = i end
		end
		local undo = vgui.Create("DButton", f)
		undo:SetText("")
		undo:SetPos(w - 176, yBar)
		undo:SetSize(160, 34)
		undo.Paint = function(s2, bw, bh)
			draw.RoundedBox(8, 0, 0, bw, bh, s2:IsHovered() and Color(60, 60, 70, 245) or Color(35, 35, 42, 240))
			draw.SimpleText("Annuler le dernier trait", "EVO_MapWall_UI", bw / 2, bh / 2,
				COL_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		undo.DoClick = function()
			net.Start("EVO:MapWall:Annule")
			net.WriteString(sRegionCourante or tRegions[1].id)
			net.SendToServer()
		end
	else
		local l = vgui.Create("DLabel", f)
		l:SetFont("EVO_MapWall_UI")
		l:SetTextColor(COL_MUTED)
		l:SetText(string.format("Le dessin et le choix de la carte sont réservés au grade %d et plus.", EVO_MAP_WALL.GradeMin))
		l:SizeToContents()
		l:SetPos(16, yBar + 6)
	end
end)

-- Échap ferme l'éditeur (même interception que le reste du projet).
hook.Add("OnPauseMenuShow", "EVO_MapWall::Esc", function()
	if IsValid(frameWall) then
		frameWall:Remove()
		return false
	end
end)

-- Invite [E] aux points d'interaction (séparés du tableau, gizmo SAM).
hook.Add("PostDrawTranslucentRenderables", "EVO_MapWall::InviteE", function(bDepth, bSky)
	if bDepth or bSky then return end
	local tPts = EVO_MAP_WALL.PointsE and EVO_MAP_WALL.PointsE(game.GetMap())
	if not istable(tPts) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local nR = EVO_MAP_WALL.PorteeE or 260
	local vEye = lp:EyePos()
	for _, p in ipairs(tPts) do
		if isvector(p.pos) and vEye:DistToSqr(p.pos) <= nR * nR then
			local a = Angle(0, EyeAngles().y - 90, 90) -- billboard face au joueur
			if EVO_ZonePrompt and EVO_ZonePrompt.Row then
				cam.Start3D2D(p.pos + Vector(0, 0, 8), a, 0.07)
					EVO_ZonePrompt.Row(0, "Carte du monde", "Consulter", "E", "point")
				cam.End3D2D()
			else
				cam.Start3D2D(p.pos + Vector(0, 0, 8), a, 0.12)
					draw.SimpleText("[E] Carte du monde", "EVO_MapWall_Name", 1, 1,
						COL_SHAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.SimpleText("[E] Carte du monde", "EVO_MapWall_Name", 0, 0,
						COL_NAME, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				cam.End3D2D()
			end
		end
	end
end)
