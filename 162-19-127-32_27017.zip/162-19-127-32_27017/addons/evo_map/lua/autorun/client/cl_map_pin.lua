-- "addons\\evo_map\\lua\\autorun\\client\\cl_map_pin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Repère personnel posé depuis la carte (clic sur un POI, 10/08). Un seul actif :
-- marqueur monde + distance en mètres, retiré de lui-même à l'arrivée.

EVO_MapPin = EVO_MapPin or {}

local ARRIVE_R2   = 600 * 600
local UNITS_PER_M = 52.5 -- même conversion que la chasse au Hollow / flagcapture

local _pin = nil -- { pos, label, key }

local function BuildFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("EVO_MapPin_Name", "Bebas Neue", 21, 400)
	gCreateRespFont("EVO_MapPin_Dist", "Roboto", 12, 500)
end
BuildFonts()
hook.Add("OnScreenSizeChanged", "EVO_MapPin::Refont", BuildFonts)
hook.Add("InitPostEntity", "EVO_MapPin::FontsLate", BuildFonts)

function EVO_MapPin.Get() return _pin end
function EVO_MapPin.Clear() _pin = nil end

-- Re-cliquer le même POI retire le repère.
function EVO_MapPin.Toggle(vPos, sLabel, sKey)
	sKey = sKey or tostring(vPos)
	if _pin and _pin.key == sKey then
		_pin = nil
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Repère retiré.", NOTIFY_GENERIC or 0, 3) end
		return false
	end
	_pin = { pos = vPos, label = string.upper(sLabel or "Repère"), key = sKey }
	if MUGEN and MUGEN.Notify then
		local lp = LocalPlayer()
		local m = IsValid(lp) and math.floor(lp:GetPos():Distance(vPos) / UNITS_PER_M) or 0
		MUGEN.Notify("Repère posé : " .. (sLabel or "?") .. " (" .. m .. " m).", NOTIFY_GENERIC or 0, 4)
	end
	return true
end

local _cMark = Color(220, 225, 235, 255)
local _cAcc  = Color(207, 68, 78, 255)
local _cDist = Color(170, 170, 180, 255)
local _cShad = Color(0, 0, 0, 180)
local _poly  = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }

local function Diamond(x, y, s)
	_poly[1].x, _poly[1].y = x, y - s
	_poly[2].x, _poly[2].y = x + s, y
	_poly[3].x, _poly[3].y = x, y + s
	_poly[4].x, _poly[4].y = x - s, y
	draw.NoTexture()
	surface.DrawPoly(_poly)
end

local _next, _vTarget, _bTP, _dist, _label, _vFor = 0, nil, false, "", "", nil

hook.Add("HUDPaint", "EVO_MapPin::Draw", function()
	if not _pin then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not gRespX then return end
	if not lp:Alive() then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end

	-- Routage téléporteur + distance : 4×/s ; le dessin tourne sur le cache.
	-- _vFor : cle du repere pour lequel le cache est calcule -> pas de flash de
	-- l'ancien cache (<= 0,25 s) quand on remplace un repere par un autre.
	local now = CurTime()
	if now >= _next or _pin.key ~= _vFor then
		_next = now + 0.25
		_vFor = _pin.key
		-- Arrivée testée en 2D : le z du repère vient d'une trace verticale et peut
		-- être un toit très au-dessus du vrai lieu (salles couvertes).
		local vP = lp:GetPos()
		local ddx, ddy = vP.x - _pin.pos.x, vP.y - _pin.pos.y
		if ddx * ddx + ddy * ddy < ARRIVE_R2 then
			_pin = nil
			if MUGEN and MUGEN.Notify then MUGEN.Notify("Tu es arrivé : repère retiré.", NOTIFY_GENERIC or 0, 3) end
			return
		end
		_vTarget, _bTP = _pin.pos, false
		if NCM_Quete_RouteWaypoint then
			local rPos, _, rTP = NCM_Quete_RouteWaypoint(_pin.pos, _pin.label)
			if rPos then _vTarget, _bTP = rPos, rTP and true or false end
		end
		-- Libellé honnête quand on route : le pad est une ÉTAPE vers le repère.
		_label = _bTP and ("TÉLÉPORTEUR → " .. _pin.label) or _pin.label
		_dist  = math.floor(lp:GetPos():Distance(_vTarget) / UNITS_PER_M) .. "m"
	end
	if not _vTarget then return end

	local RX, RY = gRespX, gRespY
	local sw, sh = ScrW(), ScrH()
	local mgx, mgy = RX(70), RY(95)
	local sc = _vTarget:ToScreen()
	local bOn = sc.visible and sc.x >= mgx and sc.x <= sw - mgx and sc.y >= mgy and sc.y <= sh - mgy
	local mx, my
	if bOn then
		mx, my = sc.x, sc.y
	else
		local dx, dy = sc.x - sw * 0.5, sc.y - sh * 0.5
		if not sc.visible then dx, dy = -dx, -dy end -- ToScreen = coordonnées miroir derrière la caméra
		local hw, hh = sw * 0.5 - mgx, sh * 0.5 - mgy
		local ax, ay = math.abs(dx), math.abs(dy)
		local sf = math.min(ax > 0 and hw / ax or math.huge, ay > 0 and hh / ay or math.huge)
		mx, my = sw * 0.5 + dx * sf, sh * 0.5 + dy * sf
	end
	local nA = bOn and 255 or 165
	_cMark.a, _cAcc.a, _cDist.a, _cShad.a = nA, nA, nA, math.floor(nA * 0.7)

	local s = RY(8)
	surface.SetDrawColor(_cShad)
	Diamond(mx + 1, my + 1, s + 1)
	surface.SetDrawColor(_cAcc)
	Diamond(mx, my, s)
	draw.SimpleTextOutlined(_label, "EVO_MapPin_Name",
		mx, my - s - RY(6), _cMark, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, _cShad)
	draw.SimpleTextOutlined(_dist, "EVO_MapPin_Dist",
		mx, my + s + RY(4), _cDist, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, _cShad)
end)
