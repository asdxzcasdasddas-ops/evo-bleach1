-- "addons\\evo_map\\lua\\autorun\\client\\cl_map_hold.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MAP — « Map en main » (client).
-- Force la MÊME pose full-body que « gestion faction » (séquence
-- evo_hwndw1d2gtqzzdvkf) sur tout joueur dont le NWBool EVO::IsHoldingMap est vrai
-- (posé par le serveur, cf. sv_map_hold.lua). Mécanisme identique au livre de
-- faction : ResetSequence tenu chaque frame via UpdateAnimation (le prop carte est
-- attaché à la main côté serveur).
--
-- Helper EVO_MapHold.Start(frame)/Stop() : appelé par les UI carte PERSONNELLES
--   • carte de poche (menu Échap -> EVO_OpenMap(nil, true), cl_map.lua)
--   • carte d'inventaire qu'on t'a donnée (ShowView, evo_carte/cl_carte.lua)
-- PAS le panneau mural physique (E) : ce n'est pas « ta map dans la main ».
-- ============================================================================
if not CLIENT then return end

EVO_MapHold = EVO_MapHold or {}

-- Démarre le maintien : mémorise l'UI carte ouverte (pour la fermeture forcée serveur)
-- puis demande au serveur le prop + le freeze + le NWBool d'anim.
function EVO_MapHold.Start(frame)
	EVO_MapHold._frame = IsValid(frame) and frame or nil
	net.Start("EVO:MapHold:Start")
	net.SendToServer()
end

-- Arrête le maintien (fermeture normale de l'UI carte).
function EVO_MapHold.Stop()
	EVO_MapHold._frame = nil
	net.Start("EVO:MapHold:Stop")
	net.SendToServer()
end

-- Le serveur demande de fermer l'UI (dégâts / mort en pleine lecture) : on retire la
-- frame mémorisée -> son OnRemove rappelle EVO_MapHold.Stop() (idempotent côté serveur).
net.Receive("EVO:MapHold:ForceClose", function()
	local f = EVO_MapHold._frame
	EVO_MapHold._frame = nil
	if IsValid(f) then f:Remove() end
end)

-- ── Forçage de la pose (calqué sur lzy_faction : ResetSequence full-body) ────────
local seqCache = {}
local function CachedLookupSequence(ply, seqName)
	local mdl = ply:GetModel()
	local key = mdl .. "_" .. seqName
	if seqCache[key] == nil then
		seqCache[key] = ply:LookupSequence(seqName) or -1
	end
	return seqCache[key]
end

hook.Add("UpdateAnimation", "EVO_MapHold_ReadAnimForce", function(ply)
	if not IsValid(ply) then return end
	if not ply:GetEvoNWBool("EVO::IsHoldingMap", false) then
		ply._MapHoldSeqSet = nil
		return
	end

	local nSeq = CachedLookupSequence(ply, "evo_hwndw1d2gtqzzdvkf")
	if nSeq and nSeq > 0 then
		-- Ne reset la séquence qu'UNE fois pour ne pas bloquer l'animation à cycle 0.
		if not ply._MapHoldSeqSet then
			ply:ResetSequence(nSeq)
			ply:SetCycle(0)
			ply._MapHoldSeqSet = true
		end
		ply:SetPlaybackRate(1)
		return true
	end
end)
