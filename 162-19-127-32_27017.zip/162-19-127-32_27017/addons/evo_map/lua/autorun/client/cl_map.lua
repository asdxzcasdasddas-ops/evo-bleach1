-- "addons\\evo_map\\lua\\autorun\\client\\cl_map.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- EVO MAP — atlas 3D des mondes. Même entrée publique pour les panneaux,
-- le menu Échap et evo_carte. L'éditeur de cartes annotées reste indépendant.
if not CLIENT then return end

hook.Run("EVO_Atlas::BeforeReload")
local atlas = {
    data = include("evo_carte/cl_map_data.lua"),
    config = include("evo_carte/cl_atlas_config.lua"),
    anchors = {}, anchor_version = 0, next_request = 0,
    glow = Material("sprites/light_glow02_add", "smooth"),
}
local data, config = atlas.data, atlas.config
local ipairs, is_valid = ipairs, IsValid
local DANGER = { [1] = "Faible", [2] = "Moyen", [3] = "Élevée" }
hook.Add("EVO_Atlas::BeforeReload", "EVO_Atlas::Close", function()
    if is_valid(atlas.frame) then atlas.frame:Remove() end
end)

atlas.dev = CreateClientConVar("evo_map_dev", "0", true, false)
function atlas.Scale(value)
    return math.Round(value * math.min(ScrW() / 1600, ScrH() / 900))
end

function atlas.Fonts()
    for name, spec in pairs({
        Title = { "Bebas Neue", 35, 400 }, Heading = { "Bebas Neue", 32, 400 },
        Body = { "Roboto", 16, 500 }, Small = { "Roboto", 13, 500 }, Tiny = { "Roboto", 10, 600 },
    }) do
        surface.CreateFont("EVO_Atlas_" .. name, { font = spec[1], size = math.max(9, atlas.Scale(spec[2])),
            weight = spec[3], extended = true, antialias = true })
    end
end
atlas.Fonts()

function atlas.RegionsForPlayer()
    local player = LocalPlayer()
    local faction = is_valid(player) and player:GetEvoNWString("FactionName", "") or ""
    if faction ~= "Shinigami" and faction ~= "Hollow" then
        faction = string.find(game.GetMap(), "hueco", 1, true) and "Hollow" or "Shinigami"
    end
    local regions = {}
    for _, region in ipairs(config.regions) do
        if region.faction == faction then regions[#regions + 1] = region end
    end
    return regions
end

function atlas.Contains(region, pos)
    if not region or not pos or game.GetMap() ~= region.server then return false end
    local bounds = region.world_bounds
    if bounds then return pos:WithinAABox(bounds.mins, bounds.maxs) end
    if not region.zmin or not region.zmax then return false end
    return pos.z >= region.zmin and pos.z < region.zmax
end

local function flag_config(marker)
    local zones = FlagCapture and FlagCapture.Config and FlagCapture.Config.FlagZones
    local name = marker.zone or marker.name
    for id, zone in ipairs(zones or {}) do
        if zone.name == name then return zone, id end
    end
end

function atlas.FlagState(marker)
    local cfg, id = flag_config(marker)
    -- Les anciens flagId de la carte divergeaient de CFG.FlagZones : le NOM est
    -- l'identité stable. Ne pas attribuer le propriétaire d'un autre territoire.
    if not id then return nil, cfg end
    local local_region = FlagCapture.Config.RegionByMap and FlagCapture.Config.RegionByMap[game.GetMap()]
    if cfg.region == local_region then
        for _, zone in ipairs(FlagCapture.Zones or {}) do
            if zone.id == id then return zone, cfg end
        end
    end
    return nil, cfg
end

local function copy_marker(marker, region)
    local copy = table.Copy(marker)
    copy.key = region.id .. "|" .. marker.name
    if marker.kind == "flag" then
        local cfg, id = flag_config(marker)
        if cfg then
            copy.flagId, copy.danger_level, copy.danger = id, cfg.danger, DANGER[cfg.danger]
            -- Coordonnée exacte disponible indépendamment de la transmission PVS.
            copy.pos = cfg.pos
            copy.name = cfg.name
        end
    end
    if not copy.pos then
        copy.pos = game.GetMap() == region.server and atlas.anchors[copy.name] or nil
        copy.pos = copy.pos or (region.world_positions and region.world_positions[copy.name])
    end
    copy.floor = region.marker_floors and region.marker_floors[copy.name]
    return copy
end

function atlas.Points(region)
    local points = {}
    for _, marker in ipairs(data.markers[region.id] or {}) do
        points[#points + 1] = copy_marker(marker, region)
    end
    for _, marker in ipairs(region.extra_markers or {}) do
        points[#points + 1] = copy_marker(marker, region)
    end
    local active = NCM_WORLD_BOSS and NCM_WORLD_BOSS.GetActifs and NCM_WORLD_BOSS.GetActifs() or {}
    for _, boss in ipairs(active) do
        if atlas.Contains(region, boss.pos) then
            local x, y = data.world_to_image(region.id, boss.pos)
            if x or region.world_transform then
                local name = "Boss : " .. (boss.name or "Présence inconnue")
                points[#points + 1] = { name = name, kind = "boss", tier = boss.tier, pos = boss.pos,
                    x = x, y = y, key = region.id .. "|boss|" .. tostring(boss.tier) .. "|" .. tostring(boss.name) }
            end
        end
    end
    return points
end

function atlas.ResolveDestination(region, marker)
    if game.GetMap() ~= region.server then return nil end
    if marker.pos then return marker.pos, false end
    if atlas.anchors[marker.name] then return atlas.anchors[marker.name], false end
    if marker.destination_checked then return marker.destination, true end
    marker.destination_checked = true
    if not marker.x or not marker.y then return nil end
    local x, y = data.image_to_world(region.id, marker.x, marker.y)
    if not x then return nil end
    local calibration = data.calibration[region.id]
    local top = calibration.zmax and calibration.zmax + 400 or 16384
    local bottom = calibration.zmin and calibration.zmin - 200 or -16384
    local start_z, ground = top, nil
    -- Uniquement lors de la sélection, puis cache : choisir le sol sous les toits
    -- et ne pas traverser les étages de la map vers un autre téléporteur.
    for _ = 1, 8 do
        if start_z <= bottom then break end
        local trace = util.TraceLine({ start = Vector(x, y, start_z), endpos = Vector(x, y, bottom), mask = MASK_SOLID_BRUSHONLY })
        if trace.StartSolid then start_z = start_z - 64
        elseif trace.Hit then ground, start_z = trace.HitPos.z, trace.HitPos.z - 24
        else break end
    end
    -- Pas de destination inventée si aucune surface n'est trouvée.
    if not ground then return nil end
    if calibration.zmin and ground < calibration.zmin then return nil end
    if calibration.zmax and ground > calibration.zmax then return nil end
    marker.destination = Vector(x, y, ground)
    return marker.destination, true
end

function atlas.RequestState()
    if CurTime() >= atlas.next_request then
        atlas.next_request = CurTime() + 6
        net.Start("EVO:Map:AnchorsReq")
        net.SendToServer()
    end
    if NCM_WORLD_BOSS and NCM_WORLD_BOSS.DemanderEtat then NCM_WORLD_BOSS.DemanderEtat() end
end
net.Receive("EVO:Map:Anchors", function()
    local anchors = {}
    for _ = 1, net.ReadUInt(5) do
        local name = net.ReadString()
        anchors[name] = net.ReadVector()
    end
    atlas.anchors = anchors
    atlas.anchor_version = atlas.anchor_version + 1
end)

include("evo_carte/cl_atlas_scene.lua")(atlas)
include("evo_carte/cl_atlas.lua")(atlas)

-- API historique : utilisée par les PANNEAUX MURAUX et les cartes annotées.
-- Garder les coordonnées image de ces documents existants, ainsi que leurs IDs.
EVO_Map_DrawMarker = atlas.DrawMarker
function EVO_Map_GetMarkers(map_id) return data.markers[map_id] or {} end
local boss_cache, boss_at, boss_map = {}, 0, nil
function EVO_Map_BossMarks(map_id)
    if boss_map == map_id and CurTime() - boss_at < 0.5 then return boss_cache end
    boss_cache, boss_at, boss_map = {}, CurTime(), map_id
    local region = config.by_id[map_id]
    if not region then return boss_cache end
    for _, marker in ipairs(atlas.Points(region)) do
        if marker.kind == "boss" and marker.x and marker.y then boss_cache[#boss_cache + 1] = marker end
    end
    return boss_cache
end

function EVO_OpenMap(start_id, personal) atlas.Open(start_id, personal) end
net.Receive("EVO:Map:Open", function() EVO_OpenMap() end)
concommand.Add("evo_carte", function() EVO_OpenMap() end)
-- Menu Échap = carte personnelle. Ne pas réintroduire le raccourci M / !carte.

net.Receive("EVO:Map:BuyResult", function()
    local code = net.ReadString()
    local messages = {
        ok = "Carte achetée : utilise-la dans ton inventaire.", owned = "Tu possèdes déjà une carte dans ton inventaire.",
        unlocked = "Carte de poche déjà débloquée.", poor = "Tu n'as pas assez de Yens.",
        wrongfaction = "Cette carte n'est pas disponible pour ta faction.", fail = "L'achat a échoué. Réessaie.",
    }
    if messages[code] then atlas.Feedback(messages[code]) end
    if code == "ok" then surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3") end
end)

-- Relevé précis sur les triangles du modèle : 3 points image -> modèle,
-- non alignés (par exemple trois divisions éloignées). Application immédiate
-- locale + export Lua dans le presse-papiers, à reporter dans cl_atlas_config.lua.
local samples = {}
concommand.Add("evo_atlas_calib", function(_, _, args)
    local hit = atlas.calibration_hit
    local x, y = tonumber(args[1]), tonumber(args[2])
    if not atlas.dev:GetBool() or not hit or not x or not y or x ~= x or y ~= y or x < 0 or x > 1 or y < 0 or y > 1 then
        MsgN("[Atlas] evo_map_dev 1 ; Ctrl+clic sur un lieu du relief ; evo_atlas_calib <x image 0..1> <y image 0..1>.")
        return
    end
    samples[hit.region] = samples[hit.region] or {}
    local list = samples[hit.region]
    list[#list + 1] = { x = x, y = y, pos = hit.pos }
    atlas.calibration_hit = nil
    MsgN("[Atlas] Ancrage " .. #list .. "/3 enregistré pour " .. hit.region)
    if #list < 3 then return end
    local a, b, c = list[1], list[2], list[3]
    local ux, uy, vx, vy = b.x - a.x, b.y - a.y, c.x - a.x, c.y - a.y
    local det = ux * vy - vx * uy
    if math.abs(det) < 0.01 then
        samples[hit.region] = {}
        MsgN("[Atlas] Points trop proches ou alignés : recommencer avec trois lieux éloignés.")
        return
    end
    local u = ((b.pos - a.pos) * vy - (c.pos - a.pos) * uy) / det
    local v = ((c.pos - a.pos) * ux - (b.pos - a.pos) * vx) / det
    -- Les ancrages peuvent être des toits de hauteurs différentes : le plan XY
    -- est calibré, les altitudes individuelles restent marker_positions.
    u.z, v.z = 0, 0
    local origin = a.pos - u * a.x - v * a.y
    origin.z = (a.pos.z + b.pos.z + c.pos.z) / 3
    local region = config.by_id[hit.region]
    region.image_origin, region.image_u, region.image_v = origin, u, v
    local function vec(value) return string.format("Vector(%.6f, %.6f, %.6f)", value.x, value.y, value.z) end
    local output = "-- " .. hit.region .. "\nimage_origin = " .. vec(origin) .. ",\nimage_u = " .. vec(u) .. ",\nimage_v = " .. vec(v) .. ","
    SetClipboardText(output)
    MsgN(output)
    samples[hit.region] = {}
    if is_valid(atlas.frame) then atlas.frame:RefreshPoints() end
    atlas.Feedback("Calibration appliquée et copiée. Enregistre-la dans la configuration.")
end)
concommand.Add("evo_atlas_calib_reset", function() samples = {} atlas.calibration_hit = nil end)
concommand.Add("evo_atlas_markers", function()
    if not atlas.dev:GetBool() or not is_valid(atlas.frame) then return end
    for _, marker in ipairs(data.markers[atlas.frame.region.id] or {}) do
        MsgN(string.format("%s : %.3f %.3f", marker.name, marker.x, marker.y))
    end
end)

-- Conserver le relevé monde -> image historique pour les cartes murales/documents.
local image_samples = {}
concommand.Add("evo_map_calib_reset", function() image_samples = {} end)
concommand.Add("evo_map_calib", function(_, _, args)
    local player = LocalPlayer()
    local x, y = tonumber(args[1]), tonumber(args[2])
    if not is_valid(player) or not x or not y then MsgN("evo_map_calib <x image> <y image>") return end
    image_samples[#image_samples + 1] = { pos = player:GetPos(), x = x, y = y }
    if #image_samples < 2 then MsgN("[Atlas] Relever un deuxième point éloigné sur X et Y.") return end
    local a, b = image_samples[1], image_samples[2]
    image_samples = {}
    local dx, dy = b.pos.x - a.pos.x, b.pos.y - a.pos.y
    if math.abs(dx) < 500 or math.abs(dy) < 500 then MsgN("[Atlas] Points trop proches, recommencer.") return end
    local ax, ay = (b.x - a.x) / dx, (b.y - a.y) / dy
    MsgN(string.format("{ ax = %.9g, bx = 0, cx = %.6f, ay = 0, by = %.9g, cy = %.6f }", ax, a.x - ax * a.pos.x, ay, a.y - ay * a.pos.y))
end)
