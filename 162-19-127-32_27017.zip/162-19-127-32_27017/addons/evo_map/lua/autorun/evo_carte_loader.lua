-- "addons\\evo_map\\lua\\autorun\\evo_carte_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CARTE — cartes annotables / imprimables / partageables.
--   Un gradé (FactionRank >= MinFactionRank) dessine par-dessus la carte du monde
--   de sa faction, puis l'IMPRIME en objet d'inventaire transférable. Les copies
--   ET l'original se DÉTRUISENT 30 min après la création (cf. sh_config.ExpireSeconds).
--   Aucune modification du cœur de l'inventaire : l'item est un ITEMS[id] DYNAMIQUE
--   (broadcast aux clients), les traits vivent dans une table SQL dédiée.
-- ============================================================================
if SERVER then
    AddCSLuaFile("evo_carte/cl_map_data.lua")
    AddCSLuaFile("evo_carte/cl_atlas_config.lua")
    AddCSLuaFile("evo_carte/cl_atlas_water.lua")
    AddCSLuaFile("evo_carte/cl_atlas_scene.lua")
    AddCSLuaFile("evo_carte/cl_atlas.lua")
    -- Parchemin d'ouverture de la carte (porte d'evo-ds 09/06) : l'image est dans le
    -- content workshop, le fichier d'animation est inclus par cl_map.lua cote client.
    AddCSLuaFile("evo_carte/cl_scroll.lua")
    AddCSLuaFile("evo_carte/sh_config.lua")
    AddCSLuaFile("evo_carte/cl_carte.lua")
    include("evo_carte/sh_config.lua")
    include("evo_carte/sv_carte.lua")
else
    include("evo_carte/sh_config.lua")
    include("evo_carte/cl_carte.lua")
end
