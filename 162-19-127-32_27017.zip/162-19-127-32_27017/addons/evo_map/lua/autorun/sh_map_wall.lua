-- "addons\\evo_map\\lua\\autorun\\sh_map_wall.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MAP — CARTE DU MONDE MURALE : config PARTAGÉE des panneaux accrochés
-- dans le monde (rendu : cl_map_wall.lua, état : sv_map_wall.lua). Position,
-- angles et échelle : gizmo SA (evo_config_positions > Tableaux).
-- La RÉGION affichée et les DESSINS (grade 10+) sont un état PARTAGÉ serveur :
-- tout le monde voit la même chose, en direct.
-- ============================================================================
EVO_MAP_WALL = EVO_MAP_WALL or {}
EVO_MAP_WALL.Panels = EVO_MAP_WALL.Panels or {}

-- setpos user 08/28 (le staff regardait le SOL, pitch 89) : la carte est posée
-- À PLAT pile sous ce point. `region` = région affichée par DÉFAUT (avant le
-- premier choix), l'état serveur prend ensuite la main.
EVO_MAP_WALL.Panels["rp_seireitei_v1"] = EVO_MAP_WALL.Panels["rp_seireitei_v1"] or {
	{
		-- pos = CENTRE du panneau (et non son coin). Le panneau est À PLAT : son
		-- plan est porté par Forward et Right, Up en est la normale — donc juste
		-- au-dessus du sol, comme le setpos d'origine.
		pos = Vector(7379.36, 8081.26, 14597.8),
		ang = Angle(0, 100.2, 0), -- à plat (Up = plafond), lisible depuis le setpos
		scale = 0.2, -- réduite (user 08/28 « trop grande ») : ~250 unités de large
		region = "seireitei",
		path = "m0q3cwmieqogu5/seireitei_map.png",
	},
}

-- Les régions commutables du panneau, par map (mêmes assets que le viewer Échap).
EVO_MAP_WALL.Regions = {
	["rp_seireitei_v1"] = {
		{ id = "seireitei",   nom = "Seireitei",      path = "m0q3cwmieqogu5/seireitei_map.png" },
		{ id = "zoneneutre1", nom = "Zone Neutre I",  path = "m0q3cwmieqogu5/zoneneutre1_map.png" },
		{ id = "zoneneutre2", nom = "Zone Neutre II", path = "m0q3cwmieqogu5/zoneneutre2_map.png" },
	},
	["hueco_mundo_v1"] = {
		{ id = "hueco_lasnoches",   nom = "Las Noches",     path = "m0q3cwmieqogu5/hueco_lasnoches.png" },
		{ id = "hueco_zoneneutre1", nom = "Zone Neutre I",  path = "m0q3cwmieqogu5/hueco_zoneneutre1.png" },
		{ id = "hueco_zoneneutre2", nom = "Zone Neutre II", path = "m0q3cwmieqogu5/hueco_zoneneutre2.png" },
	},
}

function EVO_MAP_WALL.RegionsDeLaMap(sMap)
	return EVO_MAP_WALL.Regions[sMap or game.GetMap()]
end

function EVO_MAP_WALL.RegionById(sMap, sId)
	for _, r in ipairs(EVO_MAP_WALL.RegionsDeLaMap(sMap) or {}) do
		if r.id == sId then return r end
	end
	return nil
end

-- Droit de DESSINER / changer la région / annuler : grade de faction 10 et
-- plus (user 08/28), superadmin en bypass. Partagé : UI client + refus serveur.
EVO_MAP_WALL.GradeMin = 10
function EVO_MAP_WALL.PeutDessiner(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= EVO_MAP_WALL.GradeMin
end

-- Portée du [E] et des actions (revalidée serveur : pas de dessin à distance).
EVO_MAP_WALL.PorteeE = 260

-- Zones du [E] (user 08/28) : le point d'interaction est SÉPARÉ du tableau —
-- déplaçable seul au gizmo (Tableaux > Zone E de la carte murale). Sans zone
-- configurée pour la map : repli sur la position des panneaux.
EVO_MAP_WALL.ZonesE = EVO_MAP_WALL.ZonesE or {}
EVO_MAP_WALL.ZonesE["rp_seireitei_v1"] = EVO_MAP_WALL.ZonesE["rp_seireitei_v1"] or {
	{ pos = Vector(7379.36, 8081.26, 14595.7) },
}

-- Points d'interaction de la map. Une liste DÉCLARÉE mais vide veut dire
-- « aucun [E] ici » (le SA a supprimé la zone au gizmo) : sans cette nuance, le
-- repli remettait le [E] au ras du panneau, exactement ce qu'il venait d'enlever.
-- Le repli ne joue donc que pour une map qui n'a JAMAIS déclaré de zone.
function EVO_MAP_WALL.PointsE(sMap)
	sMap = sMap or game.GetMap()
	local t = EVO_MAP_WALL.ZonesE[sMap]
	if istable(t) then return t end
	return EVO_MAP_WALL.Panels[sMap]
end
