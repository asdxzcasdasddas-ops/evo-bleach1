-- "addons\\lzy_escape_menu\\lua\\lzy_escape_menu\\cl_events.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY ESCAPE MENU — ÉVÉNEMENTS PvP. Overlay DA dashboard (même recette que le
-- menu Échap : plaques métal à coins coupés, vis, Bebas + slash, images de
-- cartes). Liste de cartes → fiche détaillée (horaires, déroulement, rewards).
-- Ouvert depuis la carte ÉVENTS du menu Échap.
-- ============================================================================

local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)

local WDAY = {
	[1] = "Dimanche", [2] = "Lundi", [3] = "Mardi", [4] = "Mercredi",
	[5] = "Jeudi", [6] = "Vendredi", [7] = "Samedi",
}

local logo = Material("materials/etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png", "smooth")

-- Visuels nommés du dossier workshop (fichiers fournis 08/17). On essaie le
-- chemin exact d'abord (le nom peut déjà porter .png), puis jpeg/jpg/sans ext.
local _wsCache = {}
local function eventMat(sFile)
	if _wsCache[sFile] ~= nil then return _wsCache[sFile] or nil end
	local base = "etgmnxxbvsadh9/etgmnxxbvsadh9/" .. sFile
	local m = Material(base, "smooth")
	if m:IsError() then m = Material(base .. ".png", "smooth") end
	if m:IsError() then m = Material(base .. ".jpeg", "smooth") end
	if m:IsError() then m = Material(base .. ".jpg", "smooth") end
	_wsCache[sFile] = (not m:IsError()) and m or false
	return _wsCache[sFile] or nil
end

local IMG_BATAILLE = "BLEACH__teaserPV_8.png"
local IMG_FLAGS    = "latest.png"
local IMG_ZONE     = "gotei-13-shinigami-bleach-thousand-year-blood-war-2k-wallpaper-uhdpaper-com-780-1-i-cropped.png"
local IMG_DEFUSE   = "adazazdazdda.png"
eventMat(IMG_BATAILLE)
eventMat(IMG_FLAGS)
eventMat(IMG_ZONE)
eventMat(IMG_DEFUSE)

local function makeEventFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("LZY.Events.Title", "Bebas Neue", 58, 400)
	gCreateRespFont("LZY.Events.Nav", "Bebas Neue", 40, 400)
	gCreateRespFont("LZY.Events.CardTitle", "Bebas Neue", 40, 400)
	gCreateRespFont("LZY.Events.CardTitleBig", "Bebas Neue", 52, 400)
	gCreateRespFont("LZY.Events.Desc", "Avenir Next World", 18, 600)
	gCreateRespFont("LZY.Events.Body", "Avenir Next World", 17, 500)
	gCreateRespFont("LZY.Events.Chip", "Bebas Neue", 22, 400)
	gCreateRespFont("LZY.Events.Section", "Bebas Neue", 28, 400)
	gCreateRespFont("LZY.Events.Hint", "Avenir Next World", 15, 500)
end
hook.Add("Initialize", "LZY.Events.Fonts", makeEventFonts)
hook.Add("OnScreenSizeChanged", "LZY.Events.Fonts", makeEventFonts)
makeEventFonts()

local function wrapText(text, font, maxW)
	surface.SetFont(font)
	local lines, cur = {}, ""
	for _, wd in ipairs(string.Explode(" ", text or "")) do
		local try = cur == "" and wd or (cur .. " " .. wd)
		if select(1, surface.GetTextSize(try)) > maxW and cur ~= "" then
			lines[#lines + 1] = cur
			cur = wd
		else
			cur = try
		end
	end
	if cur ~= "" then lines[#lines + 1] = cur end
	return lines
end

local function fmtHM(t)
	if not t then return "-" end
	return string.format("%02dh%02d", tonumber(t.h) or 0, tonumber(t.m) or 0)
end

local function fmtHour(h)
	return string.format("%02dh00", tonumber(h) or 0)
end

local function joinDays(days)
	local names = {}
	for w = 1, 7 do
		if days and days[w] then names[#names + 1] = WDAY[w] end
	end
	if #names == 0 then return "Jours à confirmer" end
	if #names == 1 then return names[1] end
	local last = table.remove(names)
	return table.concat(names, ", ") .. " et " .. last
end

local function mapLabel(sMap)
	if sMap == "hueco_mundo_v1" then return "Hueco Mundo" end
	if sMap == "rp_seireitei_v1" then return "Seireitei" end
	return sMap or "?"
end

local function hostMapsList(cfg)
	local labels = {}
	local hostMaps = cfg and cfg.HostMaps
	local arenas = (cfg and cfg.Arenas) or {}
	if istable(hostMaps) then
		for sMap, bOn in pairs(hostMaps) do
			if bOn then
				local arena = arenas[sMap]
				local zone = arena and isstring(arena.name) and arena.name ~= "" and arena.name
				local map = mapLabel(sMap)
				labels[#labels + 1] = zone and (map .. " · " .. zone) or map
			end
		end
		table.sort(labels)
	end
	if #labels == 0 then return "serveur hôte" end
	return table.concat(labels, " & ")
end

-- Catalogue construit à l'ouverture (lit les configs live : jours / heures / rewards).
local function buildEvents()
	local list = {}

	do
		local cfg = (EVO_BATAILLE and EVO_BATAILLE.Config) or {}
		local days = joinDays(cfg.Days or { [2] = true, [6] = true })
		local joinS = fmtHM(cfg.JoinStart or { h = 21, m = 0 })
		local joinE = fmtHM(cfg.JoinEnd or { h = 21, m = 10 })
		local cut   = fmtHM(cfg.RewardLeaveCutoff or { h = 21, m = 5 })
		local soft  = fmtHM(cfg.SoftEnd or { h = 21, m = 30 })
		local where = hostMapsList(cfg)
		local rank  = tonumber(cfg.CombatRankOverride) or 7
		local coins = tonumber(cfg.WinCoins) or 500
		local yens  = tonumber(cfg.CancelYens) or 5000
		list[#list + 1] = {
			id    = "bataille_clans",
			title = "BATAILLE DES CLANS",
			img   = eventMat(IMG_BATAILLE),
			when  = days .. "  ·  " .. joinS .. " – " .. soft,
			where = where,
			desc  = "Les clans s'affrontent dans l'arène : le dernier clan debout l'emporte.",
			sections = {
				{
					title = "HORAIRES",
					lines = {
						days .. " - rendez-vous à " .. joinS .. " sur " .. where .. ".",
						"Entrées ouvertes de " .. joinS .. " à " .. joinE .. " (le dôme d'arène n'apparaît que pendant cette fenêtre).",
						"Départ volontaire avant " .. cut .. " : pas de récompense.",
						"Le dernier clan en vie après " .. soft .. " remporte la bataille.",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						"Il faut être membre d'un clan et avoir la permission Bataille sur son grade (réglée par le chef de clan).",
						"Pendant la fenêtre d'entrée, approchez le dôme sur " .. where .. " : une invitation s'affiche. Acceptez pour rejoindre l'arène.",
						"Tous les combattants sont alignés au même palier de combat (grade " .. rank .. ") : les sorts qui se débloquent à un grade supérieur (art spirituel, Hadō, Bakudō, Ars Hollow, voies katana et hakuda) sont inutilisables, retirez-les de votre barre avant d'entrer.",
						"Le tir allié entre membres du même clan est désactivé. Quitter l'arène vous exclut de l'événement.",
						"Objectif : éliminer les autres clans. Le dernier clan encore présent l'emporte.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						"Clan vainqueur : " .. coins .. " coins par participant encore éligible (même déconnecté).",
						"Annulation (pas de vainqueur) : " .. tostring(yens) .. " yens de consolation.",
					},
				},
			},
		}
	end

	-- LA FAILLE (evo_faille, 08/24) : vagues de Hollows en instance partagée.
	do
		local cfg = (EVO_FAILLE and EVO_FAILLE.Config) or {}
		local bAuto = cfg.AutoStart ~= false -- verrou test : pas d'horaire annoncé tant que c'est faux
		local days  = bAuto and joinDays(cfg.Days or { [4] = true }) or "Bientôt"
		local joinS = fmtHM(cfg.JoinStart or { h = 21, m = 0 })
		local joinE = fmtHM(cfg.JoinEnd or { h = 21, m = 10 })
		local soft  = fmtHM(cfg.SoftEnd or { h = 21, m = 45 })
		local where = hostMapsList(cfg)
		local nWaves = istable(cfg.Waves) and #cfg.Waves or 6
		local yens  = tonumber(cfg.WinYens) or 0
		local nTop  = tonumber(cfg.RewardTop) or 10
		local nMax  = tonumber(cfg.MaxPlayers) or 20
		list[#list + 1] = {
			id    = "faille",
			title = "LA FAILLE",
			-- Phase de test (EVO_FAILLE.Config.AutoStart = false) : carte GRISÉE et non
			-- ouvrable, comme les COFFRES en boutique. Repasser AutoStart à true la
			-- rouvre toute seule, aucun autre geste à faire.
			soon  = not bAuto,
			img   = eventMat(IMG_ZONE),
			when  = bAuto and (days .. "  ·  " .. joinS .. " – " .. soft) or "Bientôt  ·  lancée par le staff pour l'instant",
			where = where,
			desc  = "Une Faille s'ouvre : des vagues de Hollows déferlent sur la Zone Neutre, tenez la ligne jusqu'au bout.",
			sections = {
				{
					title = "HORAIRES",
					lines = bAuto and {
						days .. " - rendez-vous à " .. joinS .. " sur " .. where .. ".",
						"Entrées ouvertes de " .. joinS .. " à " .. joinE .. " (le dôme n'apparaît que pendant cette fenêtre).",
						"La première vague franchit la Faille à " .. joinE .. ". Quoi qu'il arrive, elle se referme à " .. soft .. ".",
					} or {
						"Pas d'horaire fixe pour l'instant : la Faille est ouverte par le staff, sur " .. where .. ", et annoncée en jeu quelques minutes avant.",
						"Le rendez-vous hebdomadaire sera communiqué quand l'événement sortira de sa phase de test.",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						"Ouvert à tout le monde, sans condition de clan ni de grade, dans la limite de " .. nMax .. " défenseurs par serveur. La Faille a lieu en même temps sur chaque serveur, dans sa Zone Neutre.",
						"Pendant la fenêtre d'entrée, approchez le dôme sur " .. where .. " : une invitation s'affiche. Acceptez pour rejoindre la défense.",
						"Les défenseurs sont isolés dans la Faille : ils ne voient que les Hollows et les autres défenseurs. Le tir allié est désactivé.",
						nWaves .. " vagues de plus en plus fortes : les Hollows sortent de Gargantas ouvertes aux quatre coins de la zone, des Menos Grande en finale. Chaque vague a un temps limite : si elle n'est pas repoussée à temps, la Faille vous submerge.",
						"Tomber au combat vous élimine (pas de KO). Quitter le dôme aussi. La Faille est repoussée quand la dernière vague est abattue.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						"Événement coopératif : les " .. nTop .. " défenseurs ayant infligé le plus de dégâts reçoivent un coffre (légendaire au 1er, épique aux 2e et 3e, rare ensuite), même en cas de défaite.",
						yens > 0 and ("Faille repoussée : +" .. yens .. " yens pour chaque défenseur récompensé.") or "Faille repoussée : récompenses majorées.",
					},
				},
			},
		}
	end

	do
		local cfg = (EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.Config) or {}
		local joinSec = tonumber(cfg.JoinSeconds) or 900
		local joinMin = math.max(1, math.floor(joinSec / 60))
		local rMin = tonumber(cfg.RadiusMin) or 1000
		local rMax = tonumber(cfg.RadiusMax) or 8000
		local height = tonumber(cfg.Height) or 3000
		local minRank = (EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.MinRank and EVO_BATAILLE_FAC.MinRank()) or 10
		local cancelSec = tonumber(cfg.CancelWindow) or 180
		local cancelMin = math.max(1, math.ceil(cancelSec / 60))
		list[#list + 1] = {
			id    = "bataille_factions",
			title = "BATAILLE DES FACTIONS",
			img   = eventMat(IMG_BATAILLE),
			when  = "Lancé par un grade " .. tostring(minRank) .. "+",
			where = "Position du proposant",
			desc  = "Deux factions s'affrontent dans un dôme : la dernière encore en vie l'emporte.",
			sections = {
				{
					title = "LANCEMENT",
					lines = {
						"Un joueur grade " .. tostring(minRank) .. "+ utilise le menu C sur un joueur grade " .. tostring(minRank) .. "+ de l'autre faction.",
						"Le proposant choisit le rayon du dôme (" .. tostring(rMin) .. "–" .. tostring(rMax) .. ", hauteur " .. tostring(height) .. "), peut abaisser le plancher, et fixe le maximum de participants par faction. L'autre joueur accepte ou refuse.",
						"Le dôme s'ouvre à la position du proposant. Un seul événement peut tourner à la fois.",
						"Pendant les " .. tostring(cancelMin) .. " premières minutes, l'un des deux lanceurs peut annuler (menu C sur un joueur). Cette annulation retire le délai avant d'en relancer une.",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						"Entrez dans le dôme pour participer : pas d'invitation, il suffit d'être présent. Seules les deux factions du défi comptent ; les autres sont téléportés à l'extérieur.",
						joinMin .. " min pour entrer, puis le combat s'arme dès que les deux factions ont au moins un vivant (hors KO / hors blessé) dans le dôme. Dernière faction encore présente : victoire.",
						"Quand une faction atteint le max de participants fixé au lancement, les suivants de cette faction ne peuvent plus entrer.",
						"Les grades 10 et plus ne peuvent pas entrer pendant les 10 premières minutes (téléportés à l'extérieur s'ils y sont déjà).",
						"Si vous mourez dans la zone, vous mourrez directement (pas de KO) et vous ne pouvez plus y rentrer.",
						"Quitter le dôme : 5 secondes pour revenir, sinon vous êtes exclus jusqu'à la fin.",
						"Un joueur en mode blessé (pain) ne compte pas pour la victoire.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						"Chaque participant de la faction gagnante (entré au moins une fois dans le dôme) : 1 coffre de rareté aléatoire, mêmes chances que le shop Urahara.",
						"Les récompenses sont ajoutées à l'inventaire même en cas de déconnexion. Annulation (staff ou aucune faction restante) : pas de coffre.",
					},
				},
			},
		}
	end

	do
		local cfg = (FlagCapture and FlagCapture.Config) or {}
		local sc  = cfg.Schedule or { StartHour = 20, EndHour = 1 }
		local startH = fmtHour(sc.StartHour or 20)
		local endH   = fmtHour(sc.EndHour or 1)
		local capMin = math.max(1, math.floor((tonumber(cfg.CaptureTime) or 300) / 60))
		local minP   = tonumber(cfg.MinPlayersToCapture) or 3
		local maxP   = tonumber(cfg.MaxPlayersToCapture) or 5
		local resetM = math.max(1, math.floor((tonumber(cfg.ResetAfterCapture) or 2400) / 60))
		local lockH  = math.max(1, math.floor((tonumber(cfg.CaptureCooldown) or 3600) / 60))
		local yenCap = tonumber(cfg.CaptureYenReward) or 100
		local yenPas = tonumber(cfg.PassiveYenPerFlag) or 50
		local pasM   = math.max(1, math.floor((tonumber(cfg.PassiveRewardInterval) or 1800) / 60))
		local heavyN = tonumber(cfg.HeavyCaptureMinPlayers) or 10
		local heavyR = tonumber(cfg.HeavyCaptureMinHighRank) or 2
		list[#list + 1] = {
			id    = "flag_capture",
			title = "CAPTURE DE DRAPEAUX",
			img   = eventMat(IMG_FLAGS),
			when  = "Tous les jours  ·  " .. startH .. " – " .. endH,
			where = "Seireitei & Hueco Mundo",
			desc  = "Shinigami et Hollows s'affrontent pour contrôler les drapeaux de la map.",
			sections = {
				{
					title = "HORAIRES",
					lines = {
						"Tous les jours, de " .. startH .. " à " .. endH .. ".",
						"Seireitei et Hueco Mundo ont chacun leurs zones, la carte (menu Échap) affiche l'état des deux régions.",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						"Il faut de " .. minP .. " à " .. maxP .. " joueurs de la même faction dans la zone (3ème siège et plus exclus), pour un total d'équipe de 10 points maximum. La capture dure " .. capMin .. " minutes, tant que vous tenez la position.",
						"Règle de progression : capturez d'abord le drapeau le plus proche de votre QG avant d'en attaquer un autre.",
						"Exactement 5 joueurs dans la zone, personne ne reste à l'extérieur pour empêcher l'adversaire d'entrer et de défendre.",
						"Après une capture, le drapeau est verrouillé " .. lockH .. " min (sauf lourde capture : " .. heavyN .. " adversaires dans la zone, dont " .. heavyR .. " de rang 10+).",
						"Le drapeau redevient neutre au bout de " .. resetM .. " min : chaque soirée repart d'une carte disputable.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						yenCap .. " yens à chaque membre de la faction présent sur le drapeau à la capture, plus des coffres tirés au sort.",
						"Revenu passif : " .. yenPas .. " yens par drapeau détenu par votre faction, toutes les " .. pasM .. " min.",
						"Suprématie (faction qui en possède le plus) : petite chance de coffre à chaque tick passif, et +10 % de dégâts contre les PNJ.",
					},
				},
			},
		}
	end

	do
		local cfg = (ZoneCapture and ZoneCapture.Config) or {}
		local days = joinDays(cfg.Days or { [3] = true, [5] = true })
		local startHM = cfg.StartTime or { h = 21, m = 0 }
		local start = fmtHM(startHM)
		local dur = tonumber(cfg.MaxCaptureTime) or 1800
		local startSec = (tonumber(startHM.h) or 0) * 3600 + (tonumber(startHM.m) or 0) * 60
		local endSec = startSec + dur
		local finish = fmtHM({
			h = math.floor(endSec / 3600) % 24,
			m = math.floor((endSec % 3600) / 60),
		})
		local pts = tonumber(cfg.TargetPoints) or 36000
		local where = hostMapsList(cfg)
		list[#list + 1] = {
			id    = "zone_capture",
			title = "CAPTURE DE ZONE",
			img   = eventMat(IMG_ZONE),
			when  = days .. "  ·  " .. start .. " – " .. finish,
			where = where,
			desc  = "Shinigami et Hollows s'affrontent pour tenir le dôme : le camp qui marque assez de points l'emporte.",
			sections = {
				{
					title = "HORAIRES",
					lines = {
						days .. " - rendez-vous à " .. start .. " sur " .. where .. ".",
						"L'événement se lance tout seul à " .. start .. " et se termine à " .. finish .. ".",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						"Entrez dans le dôme pour participer : pas d'invitation, il suffit d'être présent dans la zone.",
						"Les 5 premières minutes : seuls les grades 1 à 4 peuvent entrer. Les 5 minutes suivantes : grades 1 à 9. Ensuite, tous les grades. Un grade trop élevé déjà dans la zone est téléporté à l'extérieur.",
						"20 minutes avant le début, les joueurs en ligne sur Seireitei et sur Hueco Mundo sont comptés ensemble, par faction et par tranche (grades 1-4, 5-9, 10-16). Dans le dôme, chaque faction est limitée en même temps au plus petit de ces deux nombres, pour chaque tranche.",
						"Restez dans le dôme (hors KO) pour faire monter les points de votre faction. Premier camp à " .. tostring(pts) .. " points : victoire immédiate.",
						"Si personne n'a atteint " .. tostring(pts) .. " points à " .. finish .. ", la faction qui a le plus de points gagne.",
						"Si vous mourez dans la zone, vous ne pouvez plus y rentrer jusqu'à la fin de l'événement : une tentative de retour vous téléporte à l'extérieur.",
						"Un KO (au sol) ne vous exclut pas : vous pouvez être réanimé sur place et continuer à vous battre.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						"Tous les participants de la faction gagnante : 1 coffre épique, 1 coffre légendaire et 1 coffre mythique (ajoutés à l'inventaire même en cas de déconnexion).",
						"Les récompenses sont distribuées automatiquement à la fin.",
					},
				},
			},
		}
	end

	do
		local t = EVO_Calendrier and EVO_Calendrier.GetType and EVO_Calendrier.GetType("gm_defuse")
		list[#list + 1] = {
			id    = "defusal",
			title = "DÉSAMORÇAGE",
			img   = eventMat(IMG_DEFUSE),
			when  = "Annoncé par les animateurs",
			where = "Zone indiquée à l'annonce",
			desc  = "Une faction défend les bombes, l'autre doit les désamorcer avant la fin du compte à rebours.",
			sections = {
				{
					title = "HORAIRES",
					lines = {
						"Pas d'horaire fixe : l'événement est programmé par les animateurs et annoncé en jeu (~15 min avant le début).",
						"La faction défenseuse est prévenue de la zone quelques minutes avant l'attaquante, pour se mettre en place.",
					},
				},
				{
					title = "COMMENT ÇA MARCHE",
					lines = {
						t and t.description or "Des bombes sont amorcées. Une faction les défend (et gagne si elles explosent), l'autre doit les désamorcer.",
						"Seul le camp attaquant peut désamorcer. Les défenseurs tiennent la zone et empêchent le désamorçage.",
						"Événement automatisé : le système fait apparaître les bombes, alerte chaque camp et gère le minuteur.",
					},
				},
				{
					title = "RÉCOMPENSES",
					lines = {
						"Pas de distribution automatique : l'animateur récompense les joueurs méritants (coffres / yens) à la fin.",
					},
				},
			},
		}
	end

	return list
end

-- Image bord-à-bord dans le polygone de la plaque (cover-crop, UV par sommet).
local function paintCoverImg(mat, pts, gx, gy, gw, gh, alpha)
	if not mat or not pts or gw <= 0 or gh <= 0 then return end
	local iw, ih = mat:Width(), mat:Height()
	if iw <= 0 or ih <= 0 then return end
	local sc = math.max(gw / iw, gh / ih)
	local sw2, sh2 = gw / (iw * sc), gh / (ih * sc)
	local u0, v0 = (1 - sw2) / 2, (1 - sh2) / 2
	local ipts = {}
	for k, p in ipairs(pts) do
		ipts[k] = {
			x = p.x, y = p.y,
			u = u0 + ((p.x - gx) / gw) * sw2,
			v = v0 + ((p.y - gy) / gh) * sh2,
		}
	end
	surface.SetDrawColor(255, 255, 255, alpha)
	surface.SetMaterial(mat)
	surface.DrawPoly(ipts)
end

local function paintDashCard(s, w, h)
	local cd = s._cd
	local col = (EVO_UI and EVO_UI.Col) or {
		title = COL_TITLE, muted = COL_MUTED, accent = COL_ACCENT,
	}
	local hf = ((cd.static or cd.soon) and 0) or (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10) or (s:IsHovered() and 1 or 0))
	local at = math.Clamp((SysTime() - (s._born or 0)) * 5, 0, 1)
	at = 1 - (1 - at) ^ 3
	if at <= 0.01 then return end

	local grow = hf * gRespY(6)
	local offX, offY = -hf * gRespX(5), -hf * gRespY(5)
	local gx, gy = -grow + offX, -grow + offY
	local gw, gh = w + grow * 2, h + grow * 2

	local plate = hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 235)
	local pts
	if EVO_UI and EVO_UI.PaintCut then
		pts = EVO_UI.PaintCut(gx, gy, gw, gh, ColorAlpha(plate, plate.a * at), gRespY(14))
	else
		surface.SetDrawColor(ColorAlpha(plate, plate.a * at))
		surface.DrawRect(gx, gy, gw, gh)
		pts = {
			{ x = gx, y = gy }, { x = gx + gw, y = gy },
			{ x = gx + gw, y = gy + gh }, { x = gx, y = gy + gh },
		}
	end

	if cd.img then
		paintCoverImg(cd.img, pts, gx, gy, gw, gh, 82 * at)
		draw.NoTexture()
		surface.SetDrawColor(8, 9, 12, 70 * at)
		surface.DrawPoly(pts)
	end

	if hf > 0.02 then
		draw.NoTexture()
		surface.SetDrawColor(226, 230, 238, 10 * hf * at)
		surface.DrawPoly(pts)
		if EVO_UI and EVO_UI.OutlineCut then
			local bcol = ColorAlpha(col.accent, 235 * hf * at)
			EVO_UI.OutlineCut(pts, bcol)
			EVO_UI.OutlineCut(pts, bcol)
		end
	end

	if at > 0.5 and EVO_UI and EVO_UI.Screw then
		local sr = gRespY(4)
		local mx, my = gRespX(16), gRespY(16)
		EVO_UI.Screw(gx + mx, gy + my, sr)
		EVO_UI.Screw(gx + gw - mx, gy + my, sr)
		EVO_UI.Screw(gx + gw - mx, gy + gh - my, sr)
		EVO_UI.Screw(gx + mx, gy + gh - my, sr)
	end

	local tFont = cd.hero and "LZY.Events.CardTitleBig" or "LZY.Events.CardTitle"
	local tx = gRespX(24)
	local ty = cd.hero and (h - gRespY(128)) or gRespY(32)
	local ctitle = hf > 0.01 and col.title or Color(222, 224, 230)
	draw.SimpleText(cd.title, tFont, tx, ty, ColorAlpha(ctitle, 255 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont(tFont)
	local twT, thT = surface.GetTextSize(cd.title)
	local slashY = ty + thT * 0.28
	if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, tx - gRespX(2), slashY, twT * 1.15, gRespY(9), ColorAlpha(col.accent, 245 * at))) then
		surface.SetDrawColor(ColorAlpha(col.accent, 255 * at))
		surface.DrawRect(tx, ty + thT * 0.34, twT, math.max(2, gRespY(2)))
	end

	local dy = ty + thT * 0.28 + gRespY(18)
	if cd.when then
		draw.SimpleText(cd.when, "LZY.Events.Chip", tx, dy, ColorAlpha(col.accent, 255 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		dy = dy + gRespY(26)
	end
	if cd.where then
		draw.SimpleText(cd.where, "LZY.Events.Hint", tx, dy, ColorAlpha(COL_MUTED, 235 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		dy = dy + gRespY(22)
	end
	if cd._lines then
		for i, ln in ipairs(cd._lines) do
			draw.SimpleText(ln, "LZY.Events.Desc", tx, dy + (i - 1) * gRespY(24),
				ColorAlpha(COL_MUTED, 235 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	-- Événement pas encore ouvert : voile + mention (même recette que les catégories
	-- « BIENTÔT » de la boutique). Dessiné EN DERNIER pour couvrir titre et texte.
	if cd.soon then
		draw.NoTexture()
		surface.SetDrawColor(8, 8, 11, 188 * at)
		surface.DrawPoly(pts)
		draw.SimpleText("BIENTÔT", "LZY.Events.CardTitle", w / 2, h / 2,
			ColorAlpha(COL_MUTED, 235 * at), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

function LZY_OpenEvents()
	if IsValid(LZY_EventsFrame) then LZY_EventsFrame:Remove() end
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	makeEventFonts()

	local events = buildEvents()
	local frame = vgui.Create("DFrame")
	LZY_EventsFrame = frame
	openedFrame = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	frame.OnRemove = function(s)
		if openedFrame == s then openedFrame = nil end
		if LZY_EventsFrame == s then LZY_EventsFrame = nil end
	end

	local function close()
		if IsValid(frame) then frame:Remove() end
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame, close) end

	frame.Paint = function(_, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(frame, 5)
		else
			Derma_DrawBackgroundBlur(frame, frame.m_fCreateTime)
		end
		surface.SetDrawColor(5, 5, 7, 242)
		surface.DrawRect(0, 0, w, h)
		if logo and not logo:IsError() then
			local lw, lh = logo:Width(), logo:Height()
			local dh = gRespY(160)
			local dw = (lw > 0 and lh > 0) and dh * (lw / lh) or dh
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(logo)
			surface.DrawTexturedRect(w / 2 - dw / 2, gRespY(14), dw, dh)
		end
	end

	local host = vgui.Create("DPanel", frame)
	host:SetPos(0, 0)
	host:SetSize(ScrW(), ScrH())
	host:SetPaintBackgroundEnabled(false)
	host.Paint = function() end

	local nStagger = 0
	local function stagger(pnl)
		nStagger = nStagger + 1
		pnl._born = SysTime() + nStagger * 0.025
	end

	local function navBtn(label, cx, fn, danger)
		surface.SetFont("LZY.Events.Nav")
		local tw = surface.GetTextSize(label)
		local b = vgui.Create("DButton", host)
		b:SetSize(tw + gRespX(30), gRespY(48))
		b:SetPos(gRespX(cx) - (tw + gRespX(30)) / 2, gRespY(46))
		b:SetText("")
		stagger(b)
		b.OnCursorEntered = function()
			if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
		end
		b.Paint = function(s, bw, bh)
			local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 10)) or (s:IsHovered() and 1 or 0)
			local at = math.Clamp((SysTime() - (s._born or 0)) * 5, 0, 1)
			if at <= 0 then return end
			local ctxt = danger
				and (hf > 0.5 and COL_ACCENT or Color(160, 96, 102))
				or (hf > 0.01 and COL_TITLE or COL_MUTED)
			draw.SimpleText(label, "LZY.Events.Nav", bw / 2, bh / 2, ColorAlpha(ctxt, 255 * at), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if hf > 0.02 then
				surface.SetDrawColor(207, 68, 78, 235 * hf * at)
				surface.DrawRect(bw / 2 - tw / 2, bh - gRespY(4), tw, math.max(1, gRespY(2)))
			end
		end
		b.DoClick = function()
			if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			fn()
		end
		return b
	end

	local function makeCard(parent, cd)
		local b = vgui.Create(cd.static and "DPanel" or "DButton", parent)
		b:NoClipping(true)
		b:SetPos(gRespX(cd.x), gRespY(cd.y))
		b:SetSize(gRespX(cd.w), gRespY(cd.h))
		if not cd.static then b:SetText("") end
		b:SetCursor((cd.static or cd.soon) and "arrow" or "hand")
		b._cd = cd
		if cd.desc then
			cd._lines = wrapText(cd.desc, "LZY.Events.Desc", gRespX(cd.w - 60))
		end
		stagger(b)
		if not cd.static and not cd.soon then
			b.OnCursorEntered = function()
				if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
			end
			b.DoClick = function()
				if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
				if cd.action then cd.action() end
			end
		end
		b.Paint = paintDashCard
		return b
	end

	local function clearHost()
		local kids = host:GetChildren()
		for i = #kids, 1, -1 do
			if IsValid(kids[i]) then kids[i]:Remove() end
		end
		nStagger = 0
	end

	local showList, showDetail

	showList = function()
		clearHost()
		navBtn("RETOUR", 430, close)

		local n = #events
		local cols = (n <= 2) and n or 2
		local gapX, gapY = 30, 24
		local totalW = 1400
		local cardW = math.floor((totalW - gapX * (cols - 1)) / cols)
		local rows = math.ceil(n / cols)
		local cardH = (n <= 2) and 420 or math.floor((520 - gapY * (rows - 1)) / rows)
		local startX = 260
		local startY = 230

		for i, ev in ipairs(events) do
			local colN = ((i - 1) % cols)
			local row = math.floor((i - 1) / cols)
			makeCard(host, {
				x = startX + colN * (cardW + gapX),
				y = startY + row * (cardH + gapY),
				w = cardW, h = cardH,
				title = ev.title, img = ev.img, soon = ev.soon,
				when = ev.when, where = ev.where, desc = ev.desc,
				action = function() showDetail(ev) end,
			})
		end
	end

	showDetail = function(ev)
		clearHost()
		navBtn("RETOUR", 430, showList)

		local bannerH = 280
		makeCard(host, {
			x = 260, y = 210, w = 1400, h = bannerH,
			title = ev.title, img = ev.img, hero = true, static = true,
			when = ev.when, where = ev.where,
		})

		local bodyY = 210 + bannerH + 18
		local bodyH = 1080 - bodyY - 40
		local scroll = vgui.Create("DScrollPanel", host)
		scroll:SetPos(gRespX(260), gRespY(bodyY))
		scroll:SetSize(gRespX(1400), gRespY(bodyH))
		if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
		scroll.Paint = function(_, w, h)
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 220), gRespY(14))
			else
				surface.SetDrawColor(13, 14, 17, 220)
				surface.DrawRect(0, 0, w, h)
			end
		end

		local canvas = scroll:GetCanvas()
		local pad = gRespX(28)
		local textMaxW = gRespX(1400) - pad * 2 - gRespX(16)
		local lineH = gRespY(24)

		for si, sec in ipairs(ev.sections or {}) do
			local head = vgui.Create("DPanel", canvas)
			head:Dock(TOP)
			head:DockMargin(pad, si == 1 and gRespY(18) or gRespY(22), pad, gRespY(6))
			head:SetTall(gRespY(36))
			head.Paint = function(_, w, h)
				draw.SimpleText(sec.title, "LZY.Events.Section", 0, h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				surface.SetFont("LZY.Events.Section")
				local tw = surface.GetTextSize(sec.title)
				surface.SetDrawColor(ColorAlpha(COL_ACCENT, 200))
				surface.DrawRect(0, h - gRespY(2), math.min(tw * 0.55, gRespX(140)), math.max(1, gRespY(2)))
			end

			for _, para in ipairs(sec.lines or {}) do
				local lines = wrapText(para, "LZY.Events.Body", textMaxW - gRespX(28))
				local block = vgui.Create("DPanel", canvas)
				block:Dock(TOP)
				block:DockMargin(pad, 0, pad, gRespY(8))
				block:SetTall(gRespY(12) + #lines * lineH + gRespY(10))
				block.Paint = function(_, w, h)
					if EVO_UI and EVO_UI.PaintCut then
						EVO_UI.PaintCut(0, 0, w, h, Color(255, 255, 255, 6), gRespY(8))
					else
						surface.SetDrawColor(255, 255, 255, 6)
						surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(COL_ACCENT)
					surface.DrawRect(gRespX(10), gRespY(14), math.max(2, gRespX(3)), h - gRespY(28))
					for li, ln in ipairs(lines) do
						draw.SimpleText(ln, "LZY.Events.Body", gRespX(28), gRespY(12) + (li - 1) * lineH,
							COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end
				end
			end
		end

		local bottomPad = vgui.Create("DPanel", canvas)
		bottomPad:Dock(TOP)
		bottomPad:SetTall(gRespY(24))
		bottomPad.Paint = function() end
	end

	showList()
end
