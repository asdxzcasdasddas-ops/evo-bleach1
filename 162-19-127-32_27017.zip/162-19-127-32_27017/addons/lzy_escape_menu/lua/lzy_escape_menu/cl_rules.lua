-- "addons\\lzy_escape_menu\\lua\\lzy_escape_menu\\cl_rules.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY ESCAPE MENU — RÈGLES DU SERVEUR. Overlay Atelier (plaque coins coupés,
-- Bebas + slash, accent #cf444e) : chapitres à gauche, articles scrollables
-- à droite, sanctions mises en avant. Ouvert depuis la carte RÈGLES du menu.
-- ============================================================================

local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)

local REPORT_URL = "https://evo-roleplay.com/BleachRP/panel/report"

-- Règlement officiel du site (onglets Joueur + Faction). `sanction` optionnel.
local CATS = {
	{
		id = "joueur", nav = "JOUEUR",
		title = "RÈGLEMENT JOUEUR",
		sections = {
			{
				num = "1", title = "PROPRIÉTÉ DU COMPTE", nav = "COMPTE",
				articles = {
					{
						num = "1.1",
						text = "Un compte qui a été créé est la propriété de son créateur. Votre compte ne peut être partagé ou échangé.",
						sanction = "Ban permanent",
					},
					{
						num = "1.2",
						text = "Le joueur est entièrement responsable de son compte. L'administration d'EVO ne porte pas la responsabilité de votre propre compte. Si l'accès à votre compte est perdu (compte piraté par exemple), la même sanction sera appliquée à votre compte.",
					},
					{
						num = "1.3",
						text = "Toute fraude contre les joueurs est interdite. Nous ne compensons pas les pertes monétaires.",
						sanction = "Ban permanent",
					},
					{
						num = "1.4",
						text = "La tentative de vente ou d'achat de propriétés contenues dans le jeu contre de l'argent véritable est interdite.",
						sanction = "Ban permanent",
					},
					{
						num = "1.5",
						text = "Il est interdit d'interagir entre votre personnage principal et votre personnage secondaire. Tout transfert de propriété ou d'argent entraînera une sanction.",
						sanction = "Ban permanent",
					},
					{
						num = "1.6",
						text = "Toute tentative de contourner une sanction, notamment en utilisant un autre compte pour échapper à un bannissement, est strictement interdite.",
						sanction = "Ban permanent (des deux comptes)",
					},
				},
			},
			{
				num = "2", title = "CRÉATION DE PSEUDO", nav = "PSEUDO",
				articles = {
					{
						num = "2.1",
						text = "Les noms doivent être réalistes et se rapporter à des noms du monde réel ou du monde de Bleach. Les noms de personnes célèbres ne peuvent pas être utilisés.",
						sanction = "Obligation de changer de pseudo, jusqu'à 3 jours de ban si récidive ou troll",
					},
				},
			},
			{
				num = "3", title = "RÈGLES DE COMMUNICATION", nav = "COMMUNICATION",
				articles = {
					{
						num = "3.1",
						text = "L'insulte d'une personne (HRP) est strictement interdite.",
						sanction = "Avertissement à ban jusqu'à 7 jours",
					},
					{
						num = "3.2",
						text = "Les insultes parentales ou racistes sont strictement interdites (RP comme HRP).",
						sanction = "Ban jusqu'à 7 jours",
					},
					{
						num = "3.3",
						text = "Tous les joueurs doivent pouvoir communiquer en français et le chat doit être en français uniquement. Les autres langues peuvent être utilisées en privé, à condition que tous ceux qui peuvent le voir ou l'entendre l'acceptent.",
						sanction = "Ban 1 jour",
					},
					{
						num = "3.4",
						text = "Le double vocal est interdit. Pendant que vous jouez, vous ne devez utiliser aucun canal vocal extérieur au serveur (Discord, TeamSpeak, appel privé, etc.) avec d'autres joueurs connectés en jeu. Toute communication passe par le vocal du serveur, à portée de voix de votre personnage : parler en dehors revient à faire circuler des informations que votre personnage ne peut pas connaître. Font exception les vocaux tenus par le staff (BDA, aide, formation) et les animations qui l'annoncent explicitement.",
						sanction = "Avertissement à ban 3 jours",
					},
				},
			},
			{
				num = "4", title = "PIRATAGE ET LOGICIELS", nav = "PIRATAGE",
				articles = {
					{
						num = "4.1",
						text = "Les joueurs ne doivent avoir aucun type de logiciel qui leur donne un avantage (cheat, bots, macro, etc.).",
						sanction = "Ban permanent",
					},
				},
			},
			{
				num = "5", title = "RAPPORTS AVEC L'ADMINISTRATION", nav = "ADMINISTRATION",
				articles = {
					{
						num = "5.1",
						text = "Il est strictement interdit d'utiliser le système de rapports pour des questions qui ne sont pas liées au jeu ou à des problèmes sur le serveur.",
						sanction = "Avertissement à ban 1 jour",
					},
					{
						num = "5.2",
						text = "Tous les joueurs doivent être respectueux lorsqu'ils communiquent avec l'administration. En cas de désaccord avec une décision, vous pouvez déposer une plainte contre un membre du staff afin que la direction l'examine.",
						sanction = "Avertissement à ban 7 jours",
					},
				},
			},
			{
				num = "6", title = "RÈGLES DE JEU", nav = "JEU",
				articles = {
					{
						num = "6.1",
						text = "L'utilisation incorrecte des commandes /me /na /it /roll est interdite. Le joueur est obligé de ne jouer que la vérité. À noter : /roll ne peut être utilisé que 2 fois par situation.",
						sanction = "Avertissement à ban 1 jour",
					},
					{
						num = "6.2",
						text = "Il est interdit de se soustraire à une situation RP en refusant de la poursuivre, en rejetant les premiers soins, en quittant le jeu, en passant AFK ou en se réfugiant dans un bâtiment.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.3",
						text = "Il est interdit d'utiliser le coffre d'une faction à des fins personnelles.",
						sanction = "Ban 30 jours à permanent",
					},
					{
						num = "6.4",
						text = "En cas de mort, il est interdit de revenir sur les lieux pendant une durée de 15 minutes.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.5",
						text = "Il est interdit de faire des actions amorales en relation avec une personne inconsciente ou KO (cracher sur la personne, l'insulter, etc.).",
						sanction = "Ban jusqu'à 7 jours",
					},
					{
						num = "6.6",
						text = "Toute scène et tout propos à caractère sexuel, explicites ou implicites, sont strictement interdits. Il est autorisé de quitter la situation RP si vous êtes victime de harcèlement sexuel.",
						sanction = "Ban permanent",
					},
					{
						num = "6.7",
						text = "Il est interdit de transférer des situations RP vers le HRP, par exemple insulter quelqu'un sur le Discord au sujet d'une situation RP. Tout cas de ce genre sera sanctionné sur Discord comme en jeu.",
						sanction = "Avertissement à ban jusqu'à 7 jours",
					},
					{
						num = "6.8",
						text = "Il est interdit d'utiliser les informations récoltées avec votre personnage secondaire (d'une autre faction) pour saboter la faction de votre personnage principal, et inversement.",
						sanction = "Ban de 7 à 30 jours",
					},
					{
						num = "6.9",
						text = "Il est interdit de finir une personne inconsciente pour l'aider à éviter une situation RP (mercy kill).",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.10",
						text = "En dehors des zones PVP (entraînement, capture, désamorçage), vous devez vous engager en RP avant d'attaquer quelqu'un. Formulez des demandes ; s'ils ne vous écoutent pas dans les 5 secondes, vous pouvez attaquer. Pour vous entraîner, vous devez être dans une zone d'entraînement.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.11",
						text = "Lors d'un braquage ou d'une tentative d'enlèvement, un minimum de deux personnes est requis pour interpeller et braquer un individu.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.12",
						text = "Tout type d'abus de bug est interdit. Si vous trouvez un bug qui donne un avantage critique et que vous le signalez, vous pouvez recevoir une récompense.",
						sanction = "Ban jusqu'à permanent",
					},
					{
						num = "6.13",
						text = "Il est interdit de braquer, kidnapper ou attaquer des personnes dans les zones vertes (zone du Seireitei, zone de Las Noches).",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.14",
						text = "L'AFK farm est interdit.",
						sanction = "Kick",
					},
					{
						num = "6.15",
						text = "La fuite en combat est autorisée. Cependant, un joueur ou un groupe ayant quitté un combat ne peut pas revenir dans le même combat ou dans la même action en cours.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.16",
						text = "Toute intervention extérieure dans un combat déjà engagé est interdite lorsqu'elle n'était pas prévue ou justifiée par la situation RP avant le début de l'affrontement.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.17",
						text = "La temporisation est autorisée dans la limite du raisonnable. Il est interdit d'en abuser afin de prolonger volontairement un combat ou d'attendre systématiquement la récupération de ses capacités. L'utilisation répétée d'une capacité de déplacement, telle que l'Air Walk, dans le seul but de maintenir une distance et de prolonger le combat est également considérée comme de la temporisation abusive.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.18",
						text = "Les soins en combat sont autorisés uniquement à l'aide de spells de soin. Il est interdit de quitter la zone de combat afin de se faire opérer puis d'y retourner. Les opérations sont également interdites pendant qu'un joueur est encore engagé dans un combat.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.19",
						text = "Lorsqu'une animation mobilise plus des trois quarts des membres d'une faction, il est interdit à la faction adverse de profiter de cette mobilisation à son avantage pendant toute la durée de l'animation.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.20",
						text = "Durant une guerre ou une scène RP inter-faction, les Hauts Gradés doivent rester clairement reconnaissables. Il leur est interdit de désactiver l'affichage de leur tenue de grade, de modifier leur tenue ou leur apparence dans le but de dissimuler leur identité ou de tromper la faction adverse.",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.21",
						text = "Lorsqu'un joueur est braqué, le montant maximal pouvant lui être demandé est fixé à 5 000 yens (ce montant s'applique à l'ensemble du braquage : même si plusieurs joueurs participent, ils ne peuvent pas demander 5 000 yens chacun, mais seulement 5 000 yens au total).",
						sanction = "Avertissement à ban jusqu'à 3 jours",
					},
					{
						num = "6.22",
						text = "Tout comportement toxique, malveillant ou visant volontairement à nuire à un joueur, à un membre du staff ou au projet EVO dans son ensemble est strictement interdit. Cela inclut notamment le harcèlement, les provocations répétées, le dénigrement, les fausses accusations, l’incitation à nuire ou toute tentative de porter atteinte à l’ambiance, à l’image ou au bon fonctionnement du projet.",
						sanction = "Ban 7 jours à ban permanent",
					},
				},
			},
			{
				num = "7", title = "RÈGLES RP", nav = "RP",
				articles = {
					{
						num = "7.1",
						text = "Vous incarnez un personnage dans l'univers Bleach : restez cohérent avec le lore et votre rôle.",
						sanction = "Avertissement à ban 1 jour",
					},
					{
						num = "7.2",
						text = "Fear RP : vous devez manifester une peur réaliste en présence d'êtres puissants ou inconnus.",
						sanction = "Avertissement à ban 1 jour",
					},
					{
						num = "7.3",
						text = "Pain RP : vous devez agir en fonction de l'état de santé de votre personnage et ne pas ignorer la douleur qu'il ressent.",
						sanction = "Avertissement à ban 1 jour",
					},
					{
						num = "7.4",
						text = "Si vous êtes en état de Pain, vous devez vous soumettre à vos adversaires et jouer le Pain RP et le Fear RP.",
						sanction = "Avertissement à ban 2 jours",
					},
					{
						num = "7.5",
						text = "Metagaming : vous ne devez pas utiliser des informations RP collectées autrement que par le RP (streams, Discord, etc.).",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.6",
						text = "Win RP : vous ne devez pas chercher à gagner impérativement. Il y a des situations où vous vous retrouverez en posture de défaite, il faut les accepter.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.7",
						text = "Un joueur ne peut effectuer un RPK sur un autre joueur sans l'autorisation préalable d'un animateur ou d'un responsable animateur.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.8",
						text = "Certains événements ou animations peuvent être définis comme « à risque RPK ». Cette information est précisée dans l'annonce de l'événement, et ceux-ci sont encadrés par une équipe de staff. Toute tentative de contournement du RPK est strictement interdite.",
						sanction = "Avertissement à ban 7 jours",
					},
					{
						num = "7.9",
						text = "Les voids signifient l'annulation de scènes RP ou de trames. Quand un void est prononcé, tous les événements concernés sont supprimés et ne sont plus pris en compte dans le RP. Les joueurs peuvent demander un void, sans garantie qu'il soit appliqué : chaque demande est analysée.",
					},
					{
						num = "7.10",
						text = "Le fair-play doit être respecté. En cas de non-respect (une attaque en groupe sans justification valable par exemple), le joueur victime sera considéré comme légitime lors de l'ouverture d'une plainte.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.11",
						text = "L'abus de braquages, rackets ou enlèvements est interdit, notamment le fait de cibler et de s'acharner sur une même personne de manière répétée (plus d'une fois par jour).",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.12",
						text = "Couper la main ou le bras d'un autre joueur est interdit sans motif RP valable. L'amputation n'est justifiée en punition, après une défaite, que si la victime a d'abord eu le choix d'éviter le combat et l'a refusé : par exemple, vous lui laissez la possibilité de fuir, elle choisit de se battre, et vous lui coupez la main ou le bras une fois vaincue.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.13",
						text = "Toute scène RP doit laisser une porte de sortie au joueur visé. Par exemple, si vous capturez un joueur et souhaitez lui couper un membre, il doit pouvoir éviter l'amputation en payant ou en livrant des informations de valeur.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.14",
						text = "Il est interdit de relever un joueur dans le but de le prendre en otage ou de le capturer. Cette action n'est autorisée que si le joueur est en état de Pain.",
						sanction = "Avertissement à ban 2 jours",
					},
					{
						num = "7.15",
						text = "Un joueur relevé ne peut plus intervenir dans la scène RP en cours. Il doit se retirer via un RP de récupération (retour au QG, soins, etc.) et ne peut en aucun cas reprendre part à cette scène, que ce soit pour reprendre le combat ou pour toute autre forme d'implication.",
						sanction = "Avertissement à ban 3 jours",
					},
					{
						num = "7.16",
						text = "Il est interdit de nuire volontairement au RP d'un autre joueur sans justification cohérente (ex. : bloquer ou interrompre une scène en cours, forcer une situation qui casse l'immersion, empêcher un joueur de jouer normalement).",
						sanction = "Avertissement à ban jusqu'à 7 jours",
					},
				},
			},
		},
	},
	{
		id = "faction", nav = "FACTION",
		title = "RÈGLEMENT FACTION",
		sections = {
			{
				num = "1", title = "CAPTURE DE DRAPEAU · COMPOSITION D'ÉQUIPE", nav = "COMPOSITION",
				articles = {
					{
						num = "1.1",
						text = "Une équipe de capture doit être composée de 5 joueurs de la même faction. En dessous, la capture n'est pas valable et peut être annulée.",
						sanction = "Annulation de la capture",
					},
					{
						num = "1.2",
						text = "Chaque grade vaut un nombre de points. 4 points : 4ème, 5ème et 6ème siège (Fracción principal, Superior, Suprema). 3 points : Junshikan de 1ère, 2ème et 3ème classe (Fracción novicia, subalterna, avanzada). 2 points : Kashikan de 1ère et 2ème classe (Menor de primera et segunda clase). 1 point : Shinigami de 1ère, 2ème, 3ème classe et Aspirant shinigami (Arrancar de primera, segunda, tercera clase et Arrancar Aspirante).",
					},
					{
						num = "1.3",
						text = "Le total de l'équipe ne peut pas dépasser 10 points. Une équipe au-dessus de 10 points ne capture pas valablement, même si elle est bien à 5 joueurs.",
						sanction = "Annulation de la capture, avertissement de division en cas de récidive",
					},
					{
						num = "1.4",
						text = "Le 3ème siège, le Fukutaicho, le Taicho et leurs équivalents (Grand Fracción, Privaron Espada, Espadas) ne comptent pas dans une équipe de capture. Ils peuvent défendre, escorter ou observer, mais leur présence ne fait pas monter la progression.",
						sanction = "Annulation de la capture",
					},
					{
						num = "1.5",
						text = "Le grade retenu est celui porté au moment de la capture. Se faire promouvoir ou rétrograder pour contourner la limite de points est interdit.",
						sanction = "Avertissement de division à rétrogradation",
					},
					{
						num = "1.6",
						text = "Les hauts gradés ne sortent pas sur les drapeaux. Un 3ème siège, un Fukutaicho, un Taicho ou leur équivalent (Grand Fracción, Privaron Espada, Espadas) ne vient pas combattre sur un point en cours de capture, même sans faire partie de l'équipe. Les drapeaux sont le terrain des bas gradés : c'est là qu'ils jouent, se font remarquer et progressent.",
						sanction = "Annulation de la capture, avertissement de division",
					},
					{
						num = "1.7",
						text = "Si un haut gradé adverse enfreint la règle 1.6, les hauts gradés d'en face peuvent répondre sur ce point sans être en faute. La sanction reste pour celui qui est sorti le premier.",
					},
				},
			},
			{
				num = "2", title = "CAPTURE DE DRAPEAU · DÉROULEMENT", nav = "DÉROULEMENT",
				articles = {
					{
						num = "2.1",
						text = "Camper le point de réapparition adverse pour empêcher toute sortie est interdit.",
						sanction = "Avertissement de division à sanction staff",
					},
					{
						num = "2.2",
						text = "Il est interdit de transmettre la position d'un drapeau, d'une équipe ou d'une défense en dehors du jeu (Discord, vocal externe, stream). L'information se transmet en jeu.",
						sanction = "Avertissement de division à sanction staff",
					},
					{
						num = "2.3",
						text = "Se déconnecter puis se reconnecter pour réapparaître plus près d'un point contesté est interdit.",
						sanction = "Annulation de la capture, avertissement de division",
					},
					{
						num = "2.4",
						text = "Une équipe qui a capturé un point doit le tenir. Enchaîner les captures en abandonnant chaque point derrière soi est interdit.",
						sanction = "Annulation des captures concernées",
					},
					{
						num = "2.5",
						text = "Les zones se prennent DANS L'ORDRE, de la plus éloignée du camp adverse à la plus proche. La zone neutre II se prend en entier avant d'ouvrir la zone neutre I. Une capture faite dans une zone dont la précédente n'est pas tenue ne compte pas, même si le point a été pris dans les règles.",
						sanction = "Annulation de la capture",
					},
					{
						num = "2.6",
						text = "« En entier » veut dire TOUS les points de la zone tenus par la même faction EN MÊME TEMPS. Perdre un point rouvre la zone : il faut le reprendre avant de continuer à avancer.",
						sanction = "Annulation des captures faites en avance",
					},
					{
						num = "2.7",
						text = "Les zones du camp adverse ne s'ouvrent qu'une fois les zones neutres tenues en entier, et se prennent dans le même ordre. On ne saute pas une zone parce qu'elle est mieux défendue.",
						sanction = "Annulation de la capture, avertissement de division",
					},
				},
			},
			{
				num = "3", title = "HIÉRARCHIE ET ORDRES", nav = "HIÉRARCHIE",
				articles = {
					{
						num = "3.1",
						text = "Un ordre donné en jeu par un supérieur de sa propre unité se respecte, tant qu'il ne demande pas d'enfreindre le règlement joueur.",
						sanction = "Avertissement de division",
					},
					{
						num = "3.2",
						text = "Un ordre qui contredit le règlement joueur ne se suit pas, et celui qui l'a donné en répond. Avoir obéi n'excuse pas la faute.",
						sanction = "Sanction pour celui qui a donné l'ordre",
					},
					{
						num = "3.3",
						text = "Un gradé ne peut pas se servir de son rang pour obtenir un avantage personnel : équipement, argent, passe-droit sur un affrontement ou promotion contre service.",
						sanction = "Rétrogradation à exclusion de la division",
					},
					{
						num = "3.4",
						text = "Les sanctions internes (avertissement, mise à l'écart, rétrogradation) appartiennent au commandement de l'unité. Tout ce qui relève du règlement joueur remonte au staff, jamais réglé en interne.",
					},
					{
						num = "3.5",
						text = "Les montées en grade suivent des délais fixes selon le grade concerné. Du grade 1 au grade 5, une montée est possible à chaque cérémonie. Du grade 6 au grade 9, une montée est possible toutes les semaines. Du grade 10 au grade 14, une montée est possible toutes les semaines, dans la limite des slots ouverts par division ou par ordre : 2 slots pour chacun des grades 10, 11 et 12, 1 slot pour chacun des grades 13, 14 et 15. Un grade dont les slots sont tous occupés n'ouvre aucune montée, même si le délai est écoulé.",
						sanction = "Rétrogradation et avertissement",
					},
					{
						num = "3.6",
						text = "Les doubles montées en grade sont interdites par défaut. Deux conditions les autorisent, et elles doivent être réunies toutes les deux : une seule personne par semaine peut en bénéficier, et la double montée doit être validée en réunion par l'ensemble des Capitaines ou des Espadas.",
						sanction = "Rétrogradation et avertissement",
					},
				},
			},
			{
				num = "4", title = "APPARTENANCE ET TRANSFERTS", nav = "TRANSFERTS",
				articles = {
					{
						num = "4.1",
						text = "Un personnage appartient à une seule division ou à un seul ordre à la fois.",
						sanction = "Retrait de la division",
					},
					{
						num = "4.2",
						text = "Un changement de division demande l'accord du commandement de l'unité quittée et de celle rejointe.",
						sanction = "Retour à l'unité d'origine",
					},
					{
						num = "4.3",
						text = "Quitter une unité juste avant un affrontement pour rejoindre celle d'en face est interdit.",
						sanction = "Retour à l'unité d'origine, avertissement de division",
					},
					{
						num = "4.4",
						text = "Faire passer des informations, du matériel ou de l'argent d'une faction à l'autre en dehors du cadre RP est interdit.",
						sanction = "Exclusion de la division à sanction staff",
					},
				},
			},
			{
				num = "5", title = "AFFRONTEMENTS ENTRE FACTIONS", nav = "AFFRONTEMENTS",
				articles = {
					{
						num = "5.1",
						text = "Attaquer une unité entière demande un motif RP. Une attaque sans raison, répétée sur la même cible, relève du harcèlement.",
						sanction = "Avertissement de division à sanction staff",
					},
					{
						num = "5.2",
						text = "Un joueur capturé en RP doit se voir laisser une chance de s'en sortir : rançon, échange, évasion. Le garder indéfiniment hors-jeu est interdit.",
						sanction = "Avertissement de division",
					},
					{
						num = "5.3",
						text = "Les accords passés en RP entre unités (trêve, alliance, reddition) engagent ceux qui les ont signés tant qu'ils ne sont pas rompus en RP.",
						sanction = "Avertissement de division",
					},
				},
			},
			{
				num = "6", title = "HAUTS GRADÉS", nav = "HAUTS GRADÉS",
				articles = {
					{
						num = "6.1",
						text = "Les grades 12 et plus doivent justifier d'une activité RP minimale de 15 heures par semaine.",
						sanction = "Avertissement à Rétrogradation",
					},
					{
						num = "6.2",
						text = "L'usage excessif de l'autorité, sans motif RP logique et cohérent avec le rôle du grade, est interdit. Cela inclut : sanctions arbitraires, ordres contradictoires ou purement punitifs, utilisation du rang pour intimider, bloquer ou nuire à un membre sans raison RP valable.",
						sanction = "Avertissement à ban 7 jours",
					},
					{
						num = "6.3",
						text = "Tout comportement abusif, répété ou humiliant envers un membre de sa propre faction est interdit, qu'il vienne d'un pair ou d'un supérieur. Cela couvre : harcèlement verbal, moqueries dégradantes, punitions collectives injustifiées, mise à l'écart abusive, ou tout acte visant à dégrader volontairement l'expérience RP d'un membre.",
						sanction = "Avertissement à ban 7 jours",
					},
					{
						num = "6.4",
						text = "Les hauts gradés (grade 10 et plus) sont tenus de gérer et organiser activement leur division/ordre : répartition des rôles, planification d'événements, suivi des membres, transmission des consignes, cohérence RP de l'unité. Le grade implique des responsabilités : un haut gradé qui ne remplit pas ces missions peut être considéré comme inactif ou inapte à son rang.",
						sanction = "Avertissement à rétrogradation",
					},
				},
			},
		},
	},
}

local function makeRulesFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("LZY.Rules.Title", "Bebas Neue", 46, 400)
	gCreateRespFont("LZY.Rules.Chapter", "Bebas Neue", 28, 400)
	gCreateRespFont("LZY.Rules.Nav", "Bebas Neue", 22, 400)
	gCreateRespFont("LZY.Rules.ArtNum", "Bebas Neue", 24, 400)
	-- Avenir Next World Medium est le TTF shippé ; +7 = même compensation que
	-- les fontes nommées "Avenir Next World:N" (la face rend plus petite).
	gCreateRespFont("LZY.Rules.Body", "Avenir Next World Medium", 20 + 7, 600)
	gCreateRespFont("LZY.Rules.Sanction", "Avenir Next World Medium", 16 + 7, 700)
	gCreateRespFont("LZY.Rules.Footer", "Avenir Next World Medium", 16 + 7, 600)
end
hook.Add("Initialize", "LZY.Rules.Fonts", makeRulesFonts)
hook.Add("OnScreenSizeChanged", "LZY.Rules.Fonts", makeRulesFonts)
makeRulesFonts()

local function wrapText(text, font, maxW)
	surface.SetFont(font)
	local lines = {}
	for _, para in ipairs(string.Explode("\n", text or "")) do
		local cur = ""
		for _, wd in ipairs(string.Explode(" ", para)) do
			if wd ~= "" then
				local try = cur == "" and wd or (cur .. " " .. wd)
				if select(1, surface.GetTextSize(try)) > maxW and cur ~= "" then
					lines[#lines + 1] = cur
					cur = wd
				else
					cur = try
				end
			end
		end
		if cur ~= "" then lines[#lines + 1] = cur end
	end
	return lines
end

function LZY_OpenRules()
	if IsValid(LZY_RulesFrame) then LZY_RulesFrame:Remove() end
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	makeRulesFonts()

	local frame = vgui.Create("DFrame")
	LZY_RulesFrame = frame
	openedFrame = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	frame.OnRemove = function(s)
		if openedFrame == s then openedFrame = nil end
		if LZY_RulesFrame == s then LZY_RulesFrame = nil end
	end
	local function close()
		if IsValid(frame) then frame:Remove() end
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame, close) end
	frame.Paint = function(_, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(frame, 5)
		else
			Derma_DrawBackgroundBlur(frame, frame.m_fCreateTime)
		end
		surface.SetDrawColor(5, 5, 7, 220)
		surface.DrawRect(0, 0, w, h)
	end
	frame.OnMousePressed = function() close() end

	local W, H = gRespX(1180), gRespY(820)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H)
	card:Center()
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, gRespY(16))
		else
			surface.SetDrawColor(13, 14, 17, 250)
			surface.DrawRect(0, 0, w, h)
		end
		local tx, ty = gRespX(28), gRespY(36)
		draw.SimpleText("RÈGLES DU SERVEUR", "LZY.Rules.Title", tx, ty, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("LZY.Rules.Title")
		local tw, th = surface.GetTextSize("RÈGLES DU SERVEUR")
		local slashY = ty + th * 0.28
		if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, tx - gRespX(2), slashY, tw * 1.12, gRespY(10), ColorAlpha(COL_ACCENT, 245))) then
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(tx, ty + th * 0.34, tw, math.max(2, gRespY(2)))
		end
		draw.SimpleText("EVO BLEACH RP", "LZY.Rules.Nav", w - gRespX(56), ty, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	do
		local xb = vgui.Create("DButton", card)
		xb:SetText("")
		xb:SetSize(gRespX(34), gRespY(34))
		xb:SetPos(W - gRespX(48), gRespY(16))
		xb:SetCursor("hand")
		xb.Paint = function(s, w, h)
			draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
				s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		xb.DoClick = function()
			if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			close()
		end
	end

	local pad = gRespX(28)
	local headerH = gRespY(78)
	local tabH = gRespY(40)
	local footerH = gRespY(88)
	local navW = gRespX(250)
	local bodyX = pad + navW + gRespX(18)
	local bodyW = W - bodyX - pad
	local bodyY = headerH + tabH + gRespY(6)
	local bodyH = H - bodyY - footerH

	local activeCat = 1
	local selected = 1
	local sectionAnchors = {}

	local function clearCanvas(scroll)
		if not IsValid(scroll) then return end
		for _, child in ipairs(scroll:GetCanvas():GetChildren()) do
			child:Remove()
		end
	end

	-- ── Navigation chapitres (gauche) ───────────────────────────────────────
	local navScroll = vgui.Create("DScrollPanel", card)
	navScroll:SetPos(pad, bodyY)
	navScroll:SetSize(navW, bodyH)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(navScroll) end

	local contentScroll = vgui.Create("DScrollPanel", card)
	contentScroll:SetPos(bodyX, bodyY)
	contentScroll:SetSize(bodyW, bodyH)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(contentScroll) end
	contentScroll.Paint = function(_, w, h)
		surface.SetDrawColor(8, 8, 10, 160)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, Color(8, 8, 10, 160), gRespY(10))
		else
			surface.DrawRect(0, 0, w, h)
		end
	end

	local artPad = gRespX(18)
	local textMaxW = bodyW - artPad * 2 - gRespX(12)

	local function jumpTo(i)
		selected = i
		local anchor = sectionAnchors[i]
		if IsValid(contentScroll) and IsValid(anchor) then
			contentScroll:ScrollToChild(anchor)
		end
	end

	local fillNav, fillContent

	fillNav = function()
		clearCanvas(navScroll)
		local chapters = CATS[activeCat].sections
		for i, ch in ipairs(chapters) do
			local row = vgui.Create("DButton", navScroll)
			row:Dock(TOP)
			row:DockMargin(0, 0, gRespX(6), gRespY(4))
			row:SetTall(gRespY(40))
			row:SetText("")
			row:SetCursor("hand")
			row.Paint = function(s, w, h)
				local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
				local on = selected == i
				local bg = on and Color(207, 68, 78, 38 + 20 * hf) or Color(255, 255, 255, 6 + 10 * hf)
				if EVO_UI and EVO_UI.PaintCut then
					EVO_UI.PaintCut(0, 0, w, h, bg, gRespY(8))
				else
					surface.SetDrawColor(bg)
					surface.DrawRect(0, 0, w, h)
				end
				if on then
					surface.SetDrawColor(COL_ACCENT)
					surface.DrawRect(0, gRespY(8), math.max(2, gRespX(3)), h - gRespY(16))
				end
				local tcol = on and COL_TITLE or (hf > 0.01 and COL_TITLE or COL_MUTED)
				draw.SimpleText(ch.num, "LZY.Rules.ArtNum", gRespX(14), h / 2, on and COL_ACCENT or COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(ch.nav or ch.title, "LZY.Rules.Nav", gRespX(40), h / 2, tcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			row.OnCursorEntered = function()
				if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
			end
			row.DoClick = function()
				if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
				jumpTo(i)
			end
		end
	end

	fillContent = function()
		clearCanvas(contentScroll)
		sectionAnchors = {}
		local canvas = contentScroll:GetCanvas()
		local chapters = CATS[activeCat].sections
		for i, ch in ipairs(chapters) do
			local head = vgui.Create("DPanel", canvas)
			head:Dock(TOP)
			head:DockMargin(artPad, i == 1 and gRespY(14) or gRespY(22), artPad, gRespY(6))
			head:SetTall(gRespY(36))
			head.Paint = function(_, w, h)
				draw.SimpleText(ch.num .. " · " .. ch.title, "LZY.Rules.Chapter", 0, h / 2, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				surface.SetFont("LZY.Rules.Chapter")
				local tw = surface.GetTextSize(ch.num .. " · " .. ch.title)
				surface.SetDrawColor(ColorAlpha(COL_ACCENT, 200))
				surface.DrawRect(0, h - gRespY(2), math.min(tw * 0.55, gRespX(120)), math.max(1, gRespY(2)))
			end
			sectionAnchors[i] = head

			surface.SetFont("LZY.Rules.Body")
			local lineH = select(2, surface.GetTextSize("Ag")) + gRespY(8)
			surface.SetFont("LZY.Rules.Footer")
			local noteLineH = select(2, surface.GetTextSize("Ag")) + gRespY(6)

			for _, art in ipairs(ch.articles) do
				local lines = wrapText(art.text, "LZY.Rules.Body", textMaxW - gRespX(58))
				local noteLines = art.note and wrapText(art.note, "LZY.Rules.Footer", textMaxW - gRespX(58)) or {}
				local bodyHgt = math.max(#lines, 1) * lineH
				local noteH = (#noteLines > 0) and (gRespY(8) + #noteLines * noteLineH) or 0
				local sancH = art.sanction and gRespY(30) or 0
				local blockH = gRespY(16) + bodyHgt + noteH + sancH + gRespY(14)

				local block = vgui.Create("DPanel", canvas)
				block:Dock(TOP)
				block:DockMargin(artPad, 0, artPad, gRespY(6))
				block:SetTall(blockH)
				block.Paint = function(_, w, h)
					if EVO_UI and EVO_UI.PaintCut then
						EVO_UI.PaintCut(0, 0, w, h, Color(255, 255, 255, 6), gRespY(8))
					else
						surface.SetDrawColor(255, 255, 255, 6)
						surface.DrawRect(0, 0, w, h)
					end
					draw.SimpleText(art.num, "LZY.Rules.ArtNum", gRespX(14), gRespY(14), COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					local tx = gRespX(58)
					local ty = gRespY(14)
					for li, ln in ipairs(lines) do
						draw.SimpleText(ln, "LZY.Rules.Body", tx, ty + (li - 1) * lineH, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end
					local y = ty + bodyHgt
					if #noteLines > 0 then
						y = y + gRespY(6)
						for li, ln in ipairs(noteLines) do
							draw.SimpleText(ln, "LZY.Rules.Footer", tx, y + (li - 1) * noteLineH, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
						end
						y = y + noteH
					end
					if art.sanction then
						local sy = h - gRespY(26)
						local label = "→  " .. art.sanction
						surface.SetFont("LZY.Rules.Sanction")
						local sw, sh = surface.GetTextSize(label)
						local bx, by, bw, bh = tx - gRespX(4), sy - gRespY(4), sw + gRespX(14), sh + gRespY(8)
						surface.SetDrawColor(207, 68, 78, 28)
						surface.DrawRect(bx, by, bw, bh)
						draw.SimpleText(label, "LZY.Rules.Sanction", tx, sy + sh / 2, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
			end
		end

		local bottomPad = vgui.Create("DPanel", canvas)
		bottomPad:Dock(TOP)
		bottomPad:SetTall(gRespY(28))
		bottomPad.Paint = function() end

		local vbar = contentScroll:GetVBar()
		if IsValid(vbar) then vbar:SetScroll(0) end
	end

	-- ── Onglets Joueur / Faction (comme le site) ────────────────────────────
	local tabBar = vgui.Create("DPanel", card)
	tabBar:SetPos(pad, headerH)
	tabBar:SetSize(W - pad * 2, tabH)
	tabBar.Paint = function() end
	for ci, cat in ipairs(CATS) do
		local tb = vgui.Create("DButton", tabBar)
		tb:SetSize(gRespX(168), tabH - gRespY(4))
		tb:SetPos((ci - 1) * gRespX(176), 0)
		tb:SetText("")
		tb:SetCursor("hand")
		tb.Paint = function(s, w, h)
			local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
			local on = activeCat == ci
			local bg = on and Color(207, 68, 78, 38 + 20 * hf) or Color(255, 255, 255, 6 + 10 * hf)
			if EVO_UI and EVO_UI.PaintCut then
				EVO_UI.PaintCut(0, 0, w, h, bg, gRespY(8))
			else
				surface.SetDrawColor(bg)
				surface.DrawRect(0, 0, w, h)
			end
			if on then
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawRect(0, h - math.max(2, gRespY(2)), w, math.max(2, gRespY(2)))
			end
			local tcol = on and COL_TITLE or (hf > 0.01 and COL_TITLE or COL_MUTED)
			draw.SimpleText(cat.nav, "LZY.Rules.Nav", w / 2, h / 2, tcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		tb.OnCursorEntered = function()
			if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
		end
		tb.DoClick = function()
			if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			if activeCat == ci then return end
			activeCat = ci
			selected = 1
			fillNav()
			fillContent()
		end
	end

	fillNav()
	fillContent()

	-- ── Pied : signalement ──────────────────────────────────────────────────
	local footer = vgui.Create("DPanel", card)
	footer:SetPos(pad, H - footerH)
	footer:SetSize(W - pad * 2, footerH - gRespY(16))
	footer.Paint = function(_, w, h)
		surface.SetDrawColor(ColorAlpha(COL_DIM, 55))
		local dashW, dashGap = gRespX(6), gRespX(5)
		local dx = 0
		while dx < w do
			surface.DrawRect(dx, 0, math.min(dashW, w - dx), 1)
			dx = dx + dashW + dashGap
		end
		local tip = "Témoin d'une infraction ? Ouvre un ticket avec le n° de règle + preuves (POV / témoins)."
		draw.SimpleText(tip, "LZY.Rules.Footer", 0, gRespY(14), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local footerW = W - pad * 2
	local reportBtn = vgui.Create("DButton", footer)
	reportBtn:SetSize(gRespX(220), gRespY(36))
	reportBtn:SetPos(footerW - gRespX(220), gRespY(34))
	reportBtn:SetText("")
	reportBtn:SetCursor("hand")
	reportBtn.Paint = function(s, w, h)
		local hf = (EVO_UI and EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 12)) or (s:IsHovered() and 1 or 0)
		local bg = Color(207, 68, 78, 200 + 55 * hf)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, bg, gRespY(8))
		else
			surface.SetDrawColor(bg)
			surface.DrawRect(0, 0, w, h)
		end
		draw.SimpleText("OUVRIR UN TICKET", "LZY.Rules.Nav", w / 2, h / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	reportBtn.OnCursorEntered = function()
		if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end
	end
	reportBtn.DoClick = function()
		if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
		gui.OpenURL(REPORT_URL)
	end
end
