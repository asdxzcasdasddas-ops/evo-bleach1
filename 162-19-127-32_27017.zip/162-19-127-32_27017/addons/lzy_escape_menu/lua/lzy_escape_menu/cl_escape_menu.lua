-- "addons\\lzy_escape_menu\\lua\\lzy_escape_menu\\cl_escape_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY ESCAPE MENU — DA v7 « DASHBOARD ATELIER » (08/07, demande user d'après
-- une référence type "Origin") : plus de colonne de gauche — un TABLEAU DE
-- BORD plein écran en grille de cartes. Barre de navigation en haut
-- (REPRENDRE / DÉCONNEXION · logo centré · DISCORD / SUPPORT), grande carte
-- héros BOUTIQUE avec visuel + badge d'argent, cartes PARAMÈTRES / PERSONNAGE
-- / OPTIMISATIONS / CARTE / BIND / RÉSEAUX + carte info EN LIGNE. Le tout en
-- recette Atelier : plaques métal noir à coins coupés + liseré acier + vis,
-- Bebas SANS bold + entaille slash1, accent rouge unique (PAS le doré de la
-- référence). Visuels de cartes = images bc1..bc9 (workshop, fournies user).
-- FONCTIONNEL inchangé : mêmes actions qu'avant (boutique, binds,
-- optimisations, personnage, carte gated carte de poche,
-- paramètres GMod, déconnexion, réseaux via gui.OpenURL, règles), toggle/fade,
-- reconstruction sur changement de condition, hook OnPauseMenuShow.
-- ============================================================================

-- Création des fontes : appelée à Initialize (session neuve), IMMÉDIATEMENT au
-- chargement (autorefresh en cours de session : Initialize ne re-tire pas ->
-- "isn't a valid font") et au resize — même pattern que EVO_UI.MakeFonts.
local function makeEscFonts()
    if not gCreateRespFont then return end -- glibs pas encore chargé (1er load)
    -- Fontes héritées (peuvent servir ailleurs) + fontes du kit.
    gCreateRespFont("LZY.Escape.Button", "Gilroy-Bold", 20)
    gCreateRespFont("LZY.Escape.ButtonBig", "Gilroy-Bold", 28)
    gCreateRespFont("LZY.Escape.PlayerCount", "Gilroy-Bold", 16)
    -- Fontes DA Atelier — Bebas Neue explicites (demande user : fonte plus
    -- grosse, Bebas partout), SANS bold (demande user 06/07 : poids 400, pas
    -- de graisse synthétique). Plus de fontes kanji : hanko + kanji d'items
    -- RETIRÉS (demande user 06/07).
    gCreateRespFont("LZY.Esc.Title", "Bebas Neue", 58, 400)
    gCreateRespFont("LZY.Esc.Item", "Bebas Neue", 40, 400)
    -- Infos session : plus gros (user) + MÊME police que le spell selector (user)
    -- -> Bebas Neue, pas de mono.
    gCreateRespFont("LZY.Esc.Info", "Bebas Neue", 21, 400)
    -- Fontes du DASHBOARD (v7) : nav, titres de cartes, descriptions, badge.
    -- (Agrandies 08/07 — retour user « fontes pas assez grosses », alors que la
    -- grille, elle, a été RÉDUITE : cartes plus fines, textes plus présents.)
    gCreateRespFont("LZY.Esc.Nav", "Bebas Neue", 40, 400)
    gCreateRespFont("LZY.Esc.CardTitle", "Bebas Neue", 40, 400)
    gCreateRespFont("LZY.Esc.CardTitleSm", "Bebas Neue", 28, 400)
    gCreateRespFont("LZY.Esc.CardTitleBig", "Bebas Neue", 52, 400)
    gCreateRespFont("LZY.Esc.CardDesc", "Avenir Next World", 18, 600)
    gCreateRespFont("LZY.Esc.Badge", "Bebas Neue", 28, 400)
    gCreateRespFont("LZY.Esc.Online", "Bebas Neue", 56, 400)
    -- Compteur compact (carte EN LIGNE réduite à côté de RÈGLES).
    gCreateRespFont("LZY.Esc.OnlineSm", "Bebas Neue", 36, 400)
end
hook.Add("Initialize", "LZY.Escape.Menu", function()
    makeEscFonts()
    if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
end)
hook.Add("OnScreenSizeChanged", "LZY.Escape.Fonts", makeEscFonts)
makeEscFonts()

local logo = Material("materials/etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png", "smooth")

-- Visuels de cartes bc1..bc9 (workshop, fournis user 08/07). Chargement lazy
-- + chaîne de secours png -> jpg -> sans extension ; nil si l'image manque.
local _bcCache = {}
local function bcMat(n)
    if _bcCache[n] ~= nil then return _bcCache[n] or nil end
    local base = "etgmnxxbvsadh9/etgmnxxbvsadh9/bc" .. n
    local m = Material(base .. ".png", "smooth")
    if m:IsError() then m = Material(base .. ".jpg", "smooth") end
    if m:IsError() then m = Material(base, "smooth") end
    _bcCache[n] = (not m:IsError()) and m or false
    return _bcCache[n] or nil
end

-- Visuels NOMMÉS du même dossier workshop (battle pass, règlement évents...),
-- même chaîne de secours que bcMat + .jpeg (les fichiers fournis 08/16 le sont).
local _wsCache = {}
local function wsMat(sName)
    if _wsCache[sName] ~= nil then return _wsCache[sName] or nil end
    local base = "etgmnxxbvsadh9/etgmnxxbvsadh9/" .. sName
    local m = Material(base .. ".jpeg", "smooth")
    if m:IsError() then m = Material(base .. ".png", "smooth") end
    if m:IsError() then m = Material(base .. ".jpg", "smooth") end
    if m:IsError() then m = Material(base, "smooth") end
    _wsCache[sName] = (not m:IsError()) and m or false
    return _wsCache[sName] or nil
end

-- PRECACHE des visuels de cartes AU CHARGEMENT (et non a la 1re ouverture). Material()
-- lit la texture sur le disque de facon SYNCHRONE -> gel d'une frame ; charger les 9
-- images une fois au load (moment deja lourd, donc invisible) fait que la 1re ouverture
-- du menu ne freeze plus. Idempotent (bcMat met en cache dans _bcCache).
for n = 1, 9 do bcMat(n) end
wsMat("battlepass_boutique")
wsMat("reglement")

-- ── Helpers de dessin DA Atelier ─────────────────────────────────────────────

-- Cercle plein (12 segments : suffisant pour des têtes de vis de ~12 px).
local function drawCircle(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

-- Vis d'angle — COPIE du .screw du spell selector : bague externe SOMBRE
-- (box-shadow 1px noir), tête en dégradé radial #33373d -> #17191d (centre
-- CLAIR), fente sombre à 38° (MÊME angle pour toutes, comme le CSS).
-- (Reflet 1px du haut RETIRÉ — user 06/07 : « mini trait blanc bizarre ».)
local function drawScrew(cx, cy, r)
    drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
    drawCircle(cx, cy, r, Color(23, 25, 29, 255))
    drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

-- Losange (puce Atelier) : contour (repos) ou plein (survol / actif).
local function drawDiamond(cx, cy, r, col, filled)
    if filled then
        draw.NoTexture()
        surface.SetDrawColor(col)
        surface.DrawTexturedRectRotated(cx, cy, r * 1.42, r * 1.42, 45)
    else
        surface.SetDrawColor(col)
        surface.DrawLine(cx, cy - r, cx + r, cy)
        surface.DrawLine(cx + r, cy, cx, cy + r)
        surface.DrawLine(cx, cy + r, cx - r, cy)
        surface.DrawLine(cx - r, cy, cx, cy - r)
    end
end

-- Filet DENTÉ (pointillés industriels — écho des alvéoles du spell selector).
local function drawDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = gRespX(6), gRespX(5)
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
        cx = cx + dw + gap
    end
end

-- Ferme le menu (fondu) puis exécute l'action — mutualise l'ancien pattern
-- répété dans chaque bouton.
local function escRun(fn)
    LZY_EscapeOpen = false
    if IsValid(LZY_EscFrame) then
        LZY_EscFrame:AlphaTo(0, 0.1, 0, function()
            LZY_EscFrame:SetVisible(false)
            if fn then fn() end
        end)
    elseif fn then
        fn()
    end
end

-- Découpe un texte en lignes qui tiennent dans maxW (descriptions des cartes).
local function wrapText(text, font, maxW)
    surface.SetFont(font)
    local lines, cur = {}, ""
    for _, wd in ipairs(string.Explode(" ", text or "")) do
        local try = cur == "" and wd or (cur .. " " .. wd)
        if select(1, surface.GetTextSize(try)) > maxW and cur ~= "" then
            lines[#lines + 1] = cur
            cur = wd
        else
            cur = try
        end
    end
    if cur ~= "" then lines[#lines + 1] = cur end
    return lines
end

-- Verrou PERSONNAGE juste après un spawn : Échap → Personnage pendant le
-- chargement cassait l'état (limbo / double load). Armé par ncm_char_select
-- au clic JOUER ; le serveur refuse aussi ReOpenCharacterMenu pendant 5 s.
local PERSONNAGE_SPAWN_LOCK = 5
function LZY_ArmPersonnageSpawnLock()
    LZY_PersonnageSpawnLockUntil = CurTime() + PERSONNAGE_SPAWN_LOCK
end
local function personnageSpawnRemain()
    return math.ceil((LZY_PersonnageSpawnLockUntil or 0) - CurTime())
end
local function personnageSpawnLocked()
    if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return true end
    return personnageSpawnRemain() > 0
end

-- ── Actions (FONCTIONNEL identique à la liste v6) ───────────────────────────
local ACT = {}
ACT.resume = function() escRun() end
ACT.personnage = function()
    local remain = personnageSpawnRemain()
    if personnageSpawnLocked() then
        if MUGEN and MUGEN.Notify then
            local msg = (remain > 0)
                and ("Attends " .. remain .. "s avant de changer de personnage.")
                or "Chargement du personnage en cours."
            MUGEN.Notify(msg, NOTIFY_ERROR, 3)
        end
        return
    end
    -- Retour au choix de personnage (garde-fous côté serveur, cf. ReOpenCharacterMenu).
    escRun(function()
        net.Start("EVO:Server:ReOpenCharacterMenu")
        net.SendToServer()
    end)
end
ACT.parametres = function()
    escRun(function()
        gui.ActivateGameUI()
        RunConsoleCommand("gamemenucommand", "openoptionsdialog")
    end)
end
ACT.boutique = function() escRun(function() vgui.Create("LZY:Shop") end) end
ACT.bind = function()
    escRun(function()
        if LocalPlayer().OpenBindMenu then
            LocalPlayer():OpenBindMenu()
        else
            RunConsoleCommand("mugen_bind_menu")
        end
    end)
end
ACT.optimisations = function()
    escRun(function()
        if LocalPlayer().OpenOptimisationsMenu then
            LocalPlayer():OpenOptimisationsMenu()
        else
            RunConsoleCommand("lzy_optimisations_menu")
        end
    end)
end
-- true = carte PERSONNELLE (carte de poche) -> carte en main + anim de lecture (EVO_MapHold).
ACT.carte = function() escRun(function() if EVO_OpenMap then EVO_OpenMap(nil, true) end end) end
ACT.parrainage = function() escRun(function() if EVO_OpenParrainage then EVO_OpenParrainage() end end) end
ACT.deconnexion = function() RunConsoleCommand("disconnect") end
ACT.support = function() escRun(function() if EVO_OpenSupport then EVO_OpenSupport() end end) end
ACT.rules = function() escRun(function() if LZY_OpenRules then LZY_OpenRules() end end) end
-- Battle pass (08/16, demande user) : même panneau que la touche dédiée.
ACT.battlepass = function() escRun(function() if OpenBattlePass then OpenBattlePass() end end) end

-- Catalogue PvP (08/17) : grille de cartes + fiche (horaires, règles, rewards).
ACT.evenements = function() escRun(function() if LZY_OpenEvents then LZY_OpenEvents() end end) end

-- Conditions d'affichage : CARTE liée à la carte de poche.
local COND = {
    personnage = function() return true end,
    carte = function()
        local lp = LocalPlayer()
        return IsValid(lp) and lp:GetEvoNWBool("EvoPocketMap", false)
    end,
}

-- Conditions surveillées pour la reconstruction (cf. condSig dans LZY_EscMenu).
local buttons = {
    { cond = COND.personnage },
    { cond = COND.carte },
}

-- AUTOREFRESH : la frame déjà construite garde les VIEUX closures de Paint
-- (les retouches semblaient « pas appliquées » en jeu) -> on la jette au
-- rechargement du fichier, elle est reconstruite à la prochaine ouverture.
if IsValid(LZY_EscFrame) then LZY_EscFrame:Remove() end
LZY_EscapeOpen = false
function LZY_EscMenu()
        -- Boutons conditionnels (ex: CARTE liée à la carte de poche) : la frame est
        -- construite UNE fois puis réutilisée -> si l'état d'une condition a changé
        -- (déblocage en cours de session), on jette la frame pour la reconstruire.
        local condSig = ""
        for _, btn in ipairs(buttons) do
            if btn.cond then condSig = condSig .. (btn.cond() and "1" or "0") end
        end
        if IsValid(LZY_EscFrame) and LZY_EscFrame._condSig ~= condSig then
            LZY_EscFrame:Remove()
            LZY_EscapeOpen = false
        end

        if IsValid(LZY_EscFrame) and LZY_EscapeOpen then
            LZY_EscapeOpen = false
            LZY_EscFrame:AlphaTo(0, 0.1, 0, function()
                LZY_EscFrame:SetVisible(false)
            end)
            return
        elseif IsValid(LZY_EscFrame) and not LZY_EscapeOpen then
            LZY_EscapeOpen = true
            LZY_EscFrame:SetVisible(true)
            LZY_EscFrame:SetAlpha(0)
            LZY_EscFrame:AlphaTo(255, 0.12, 0)
            -- Rejoue l'entrée en escalier des items à chaque réouverture.
            if LZY_EscFrame._items then
                for i, it in ipairs(LZY_EscFrame._items) do
                    if IsValid(it) then it._born = SysTime() + i * 0.02 end
                end
            end
            return
        end

        LZY_EscFrame = vgui.Create("DFrame")
        LZY_EscFrame._condSig = condSig -- état des boutons conditionnels au moment du build
        LZY_EscFrame:SetSize(ScrW(), ScrH())
        LZY_EscFrame:Center()
        LZY_EscFrame:SetTitle("")
        LZY_EscFrame:ShowCloseButton(false)
        LZY_EscFrame:SetDraggable(false)
        LZY_EscFrame:MakePopup()

        LZY_EscFrame:SetAlpha(0)
        LZY_EscFrame:AlphaTo(255, 0.12, 0)
        LZY_EscapeOpen = true

        local col = EVO_UI.Col

        LZY_EscFrame.Paint = function(self, w, h)
            -- Fond = EXACTEMENT les appels du spell selector (flou RNDX.BLUR +
            -- voile 5,5,7,216) : le DrawBlur d'avant rendait plus clair (user).
            if RNDX and RNDX.Draw and RNDX.BLUR then
                RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
            else
                Derma_DrawBackgroundBlur(self, self.m_fCreateTime)
            end
            -- Voile PLUS opaque que le selector nu (retour user 08/07 : le
            -- dashboard montre plus de jeu entre les cartes -> on compense).
            surface.SetDrawColor(5, 5, 7, 242)
            surface.DrawRect(0, 0, w, h)
            -- Logo serveur CENTRÉ dans la barre de navigation (réf. dashboard).
            -- (Agrandi 08/07 avec les libellés de nav — retour user.)
            if not logo:IsError() then
                local lw, lh = logo:Width(), logo:Height()
                local dh = gRespY(160) -- meme taille que le logo de la boutique (retour user)
                local dw = (lw > 0 and lh > 0) and dh * (lw / lh) or dh
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(logo)
                surface.DrawTexturedRect(w / 2 - dw / 2, gRespY(14), dw, dh)
            end
        end

        LZY_EscFrame._items = {}
        local nStagger = 0
        local function stagger(pnl)
            nStagger = nStagger + 1
            pnl._born = SysTime() + nStagger * 0.025
            table.insert(LZY_EscFrame._items, pnl)
        end

        -- Ouvre un lien social via l'overlay Steam / navigateur (gui.OpenURL).
        local function openSocial(url)
            gui.OpenURL(url)
        end
        local socials = {
            { mat = "discord_icon.png", url = "https://discord.gg/evobleach" },
            { mat = "tiktok_icon.png",  url = "https://www.tiktok.com/@evo_bleach" },
            { mat = "evo_lg.png",       url = "https://evo-roleplay.com/" },
        }

        -- ── BARRE DE NAVIGATION (haut) : libellés Bebas, soulignement accent au
        -- survol ; DÉCONNEXION en rouge danger. Logo centré (peint par la frame). ──
        local navDefs = {
            { label = "REPRENDRE",   cx = 430,  action = ACT.resume },
            { label = "DÉCONNEXION", cx = 680,  action = ACT.deconnexion, danger = true },
            { label = "DISCORD",     cx = 1240, action = function() openSocial(socials[1].url) end },
            { label = "SUPPORT",     cx = 1490, action = ACT.support },
        }
        for _, nd in ipairs(navDefs) do
            surface.SetFont("LZY.Esc.Nav")
            local tw = surface.GetTextSize(nd.label)
            local b = vgui.Create("DButton", LZY_EscFrame)
            b:SetSize(tw + gRespX(30), gRespY(48))
            b:SetPos(gRespX(nd.cx) - (tw + gRespX(30)) / 2, gRespY(46))
            b:SetText("")
            stagger(b)
            b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
            b.Paint = function(s, bw, bh)
                local hf = EVO_UI.HoverFrac(s, 10)
                local at = math.Clamp((SysTime() - s._born) * 5, 0, 1)
                if at <= 0 then return end
                local ctxt = nd.danger
                    and (hf > 0.5 and col.accent or Color(160, 96, 102))
                    or  (hf > 0.01 and col.title or col.muted)
                draw.SimpleText(nd.label, "LZY.Esc.Nav", bw / 2, bh / 2, ColorAlpha(ctxt, 255 * at), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                if hf > 0.02 then
                    surface.SetDrawColor(207, 68, 78, 235 * hf * at)
                    surface.DrawRect(bw / 2 - tw / 2, bh - gRespY(4), tw, math.max(1, gRespY(2)))
                end
            end
            b.DoClick = function()
                surface.PlaySound(EVO_UI.SndClick)
                nd.action()
            end
        end

        -- ── CARTES DU DASHBOARD ─────────────────────────────────────────────
        -- Peintre générique : plaque Atelier + vis + image (héros = visible avec
        -- voile bas ; sinon trame fantôme floutée) + titre Bebas + slash + desc.
        local function isCardLocked(cd)
            if not cd then return false end
            if isfunction(cd.lockFn) then return cd.lockFn() == true end
            return cd.locked == true
        end
        local function paintDashCard(s, w, h)
            local cd = s._cd
            local locked = isCardLocked(cd)
            s:SetCursor(locked and "no" or (cd.action and "hand" or "arrow"))
            -- Verrouillée (ex. CARTE sans carte de poche) : pas de survol animé.
            local hf = (cd.static or locked) and 0 or EVO_UI.HoverFrac(s, 10)
            local at = math.Clamp((SysTime() - s._born) * 5, 0, 1)
            at = 1 - (1 - at) ^ 3
            if at <= 0.01 then return end

            -- Survol CLASSIQUE (retour user 08/07 : plus de barre rouge) : la
            -- carte GROSSIT légèrement (plaque étendue hors bornes, NoClipping
            -- posé à la création) + « RESSORT » (léger décalage haut-gauche,
            -- retour user 08/07) + SURBRILLANCE (plaque éclaircie, léger voile
            -- clair) + bordure extérieure rouge.
            local grow = hf * gRespY(6)
            local offX, offY = -hf * gRespX(5), -hf * gRespY(5)
            local gx, gy = -grow + offX, -grow + offY
            local gw, gh = w + grow * 2, h + grow * 2

            local plate = hf > 0.02 and Color(19, 21, 26, 245) or Color(13, 14, 17, 235)
            local pts = EVO_UI.PaintCut(gx, gy, gw, gh, ColorAlpha(plate, plate.a * at), gRespY(14))
            -- (Liseré acier OutlineCut RETIRÉ — demande user 08/07 « pour voir » —
            -- remplacé au survol par la bordure rouge ci-dessous.)

            -- Visuel de carte (images bc1..bc9 fournies user 08/07) : dessiné
            -- BORD À BORD dans le POLYGONE de la plaque (UV par sommet) — plus
            -- de cadre sombre autour de l'image ni de dépassement des coins
            -- coupés, et plus de dégradé du bas (retours user 08/07 : « image
            -- normale, pas de dégradé bizarre, enlève la bordure noire »).
            if cd.img then
                local iw, ih = cd.img:Width(), cd.img:Height()
                if iw > 0 and ih > 0 then
                    local sc = math.max(gw / iw, gh / ih)
                    local sw2, sh2 = gw / (iw * sc), gh / (ih * sc)
                    local u0, v0 = (1 - sw2) / 2, (1 - sh2) / 2
                    -- Cartes normales = version FLOUTÉE (layer blur) très discrète ;
                    -- héros = image d'origine, un peu translucide.
                    local m = cd.hero and cd.img
                        or ((EVO_UI.GhostBlurMat and EVO_UI.GhostBlurMat(cd.img)) or cd.img)
                    local ipts = {}
                    for k, p in ipairs(pts) do
                        ipts[k] = {
                            x = p.x, y = p.y,
                            u = u0 + ((p.x - gx) / gw) * sw2,
                            v = v0 + ((p.y - gy) / gh) * sh2,
                        }
                    end
                    surface.SetDrawColor(255, 255, 255, (cd.hero and 70 or 7) * at)
                    surface.SetMaterial(m)
                    surface.DrawPoly(ipts)
                end
            end

            -- Verrouillée : voile grisé par-dessus la plaque + l'image (retour user
            -- 08/07 : CARTE sans carte de poche = VISIBLE mais grisée).
            if locked then
                draw.NoTexture()
                surface.SetDrawColor(9, 10, 13, 180 * at)
                surface.DrawPoly(pts)
            end

            -- Surbrillance : léger voile clair sur toute la plaque au survol.
            if hf > 0.02 then
                draw.NoTexture()
                surface.SetDrawColor(226, 230, 238, 10 * hf * at)
                surface.DrawPoly(pts)
            end

            -- Bordure extérieure ROUGE au survol (retour user 08/07). Deux
            -- passes du liseré 1px pour un trait ~2px, plus visible qu'un
            -- simple liseré acier.
            if hf > 0.02 then
                local bcol = ColorAlpha(col.accent, 235 * hf * at)
                EVO_UI.OutlineCut(pts, bcol)
                EVO_UI.OutlineCut(pts, bcol)
            end

            -- Vis : retrait UNIFORME 16px sur les 2 axes aux 4 coins (retour
            -- user 08/07 « bien aligné ») — assez rentré pour passer sous les
            -- coins coupés (diagonale à ~12.7px du centre > rayon de la vis).
            if at > 0.5 then
                local sr = gRespY(4)
                local mx, my = gRespX(16), gRespY(16)
                drawScrew(gx + mx, gy + my, sr)
                drawScrew(gx + gw - mx, gy + my, sr)
                drawScrew(gx + gw - mx, gy + gh - my, sr)
                drawScrew(gx + mx, gy + gh - my, sr)
            end

            -- Titre Bebas + entaille slash1 COLLÉE au titre + description.
            local tFont = cd.titleFont or (cd.hero and "LZY.Esc.CardTitleBig" or "LZY.Esc.CardTitle")
            local tx = gRespX(24)
            local ty = cd.hero and (h - gRespY(112)) or gRespY(32)
            local ctitle = locked and col.muted or (hf > 0.01 and col.title or Color(222, 224, 230))
            draw.SimpleText(cd.title, tFont, tx, ty, ColorAlpha(ctitle, 255 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            surface.SetFont(tFont)
            local twT, thT = surface.GetTextSize(cd.title)
            local sy = ty + (cd.hero and gRespY(14) or gRespY(10))
            -- Distance titre->slash = 78% de la HAUTEUR MESURÉE du texte sous son
            -- haut (réf. titre BOUTIQUE de la boutique). Le titre est CENTER-aligné
            -- vertical à Y=ty -> haut = ty - thT/2 -> slashY = ty + thT*0.28.
            local slashY = ty + thT * 0.28
            -- Slash muet (gris) si verrouillée, accent rouge sinon.
            local slashCol = locked and Color(120, 124, 132) or col.accent
            if not EVO_UI.Ink(EVO_UI.TexSlash, tx - gRespX(2), slashY, twT * 1.15, gRespY(9), ColorAlpha(slashCol, 245 * at)) then
                surface.SetDrawColor(ColorAlpha(slashCol, 255 * at))
                surface.DrawRect(tx, ty + thT * 0.34, twT, math.max(2, gRespY(2)))
            end
            if cd._lines then
                local dy = sy + gRespY(18)
                for i, ln in ipairs(cd._lines) do
                    draw.SimpleText(ln, "LZY.Esc.CardDesc", tx, dy + (i - 1) * gRespY(24),
                        ColorAlpha(col.muted, 235 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
            end

            if cd.extra then cd.extra(s, w, h, hf, at) end
        end

        -- Fabrique une carte (DButton) sur la grille design 1920x1080.
        local function makeCard(cd)
            local b = vgui.Create("DButton", LZY_EscFrame)
            b:NoClipping(true) -- la plaque déborde des bornes quand la carte grossit au survol
            b:SetPos(gRespX(cd.x), gRespY(cd.y))
            b:SetSize(gRespX(cd.w), gRespY(cd.h))
            b:SetText("")
            b:SetCursor(isCardLocked(cd) and "no" or (cd.action and "hand" or "arrow"))
            b._cd = cd
            -- Desc découpée UNE fois (largeur utile de la carte).
            if cd.desc then
                cd._lines = wrapText(cd.desc, "LZY.Esc.CardDesc", gRespX(cd.w - 60))
            end
            stagger(b)
            if cd.action then
                b.OnCursorEntered = function()
                    if isCardLocked(cd) then return end
                    surface.PlaySound(EVO_UI.SndHover)
                end
                b.DoClick = function()
                    if isCardLocked(cd) then
                        -- PERSONNAGE cooldown / CARTE verrouillée : l'action notifie, pas de clic.
                        cd.action()
                        return
                    end
                    surface.PlaySound(EVO_UI.SndClick)
                    cd.action()
                end
            else
                b.DoClick = function() end
            end
            b.Paint = paintDashCard
            return b
        end

        -- ── Grille (RÉDUITE 08/07 — retour user « trop gros, plus fin » :
        -- contenu recentré 260..1660 au lieu de 120..1800, cartes plus basses) ──
        -- Carte HÉROS : BOUTIQUE (visuel bc1, retour user) + badge argent.
        makeCard({
            x = 260, y = 210, w = 640, h = 400,
            title = "BOUTIQUE", hero = true, img = bcMat(1),
            desc = "Accède à la boutique du serveur pour obtenir des cosmétiques, des objets exclusifs et d'autres récompenses.",
            action = ACT.boutique,
            -- (Badge argent ¥ RETIRÉ — demande user 08/07.)
        })

        -- Haut-droite : PARAMÈTRES + BATTLE PASS côte à côte (la grande carte 730
        -- a été scindée en deux 355 le 08/16, demande user : case battle pass).
        makeCard({
            x = 930, y = 210, w = 355, h = 190,
            title = "PARAMÈTRES", img = bcMat(3),
            desc = "Personnalise graphismes, audio, commandes et préférences de l'interface.",
            action = ACT.parametres,
        })
        makeCard({
            x = 1305, y = 210, w = 355, h = 190,
            title = "BATTLE PASS", img = wsMat("battlepass_boutique"),
            desc = "Consulte tes paliers, ta progression et les récompenses de la saison.",
            action = ACT.battlepass,
        })

        -- Zone droite (2×2) : cartes conditionnelles assignées aux slots 1–3 ;
        -- le slot bas-droite est partagé EN LIGNE (compact) + RÈGLES.
        local rightSlots = {
            { x = 930,  y = 420, w = 355, h = 190 },
            { x = 1305, y = 420, w = 355, h = 190 },
            { x = 930,  y = 630, w = 355, h = 190 },
        }
        local rightCards = {}
        if COND.personnage() then
            rightCards[#rightCards + 1] = {
                title = "PERSONNAGE", img = bcMat(4),
                desc = "Retourne au choix de personnage pour changer d'identité.",
                action = ACT.personnage,
                lockFn = personnageSpawnLocked,
                extra = function(s, w, h, hf, at)
                    local remain = personnageSpawnRemain()
                    if remain <= 0 then return end
                    draw.SimpleText("Dans " .. remain .. "s", "LZY.Esc.CardDesc", gRespX(24), h - gRespY(28),
                        ColorAlpha(col.muted, 235 * at), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end,
            }
        end
        rightCards[#rightCards + 1] = {
            title = "OPTIMISATIONS", img = bcMat(5),
            desc = "Règle les options de performance pour gagner des FPS.",
            action = ACT.optimisations,
        }
        -- CARTE + PARRAINAGE : le slot 3 (355) est scindé en deux (~170) pour
        -- loger le bouton parrainage à droite de la carte (demande user 08/27).
        for i, cd in ipairs(rightCards) do
            local slot = rightSlots[i]
            if not slot then break end
            cd.x, cd.y, cd.w, cd.h = slot.x, slot.y, slot.w, slot.h
            makeCard(cd)
        end

        local mapPairX, mapPairY, mapPairW, mapPairH = 930, 630, 355, 190
        local mapGap = 15
        local mapW = math.floor((mapPairW - mapGap) / 2)
        local parrainW = mapPairW - mapW - mapGap
        local hasMap = COND.carte()
        makeCard({
            x = mapPairX, y = mapPairY, w = mapW, h = mapPairH,
            title = "CARTE", img = bcMat(6),
            titleFont = "LZY.Esc.CardTitleSm",
            locked = not hasMap,
            desc = hasMap and "Consulte la carte du monde grâce à ta carte de poche."
                or "Verrouillée : débloque la carte de poche pour ce personnage.",
            action = hasMap and ACT.carte or function()
                if MUGEN and MUGEN.Notify then
                    MUGEN.Notify("Carte de poche requise pour ce personnage.", NOTIFY_ERROR, 4)
                end
            end,
        })
        makeCard({
            x = mapPairX + mapW + mapGap, y = mapPairY, w = parrainW, h = mapPairH,
            title = "PARRAINAGE", img = bcMat(2),
            titleFont = "LZY.Esc.CardTitleSm",
            desc = "Invite tes amis et gagne des récompenses exclusives.",
            action = ACT.parrainage,
        })

        -- Bas-droite : EN LIGNE (compact) + RÈGLES côte à côte.
        local pairX, pairY, pairW, pairH = 1305, 630, 355, 190
        local pairGap = 15
        local onlineW = 168
        local rulesW = pairW - onlineW - pairGap
        makeCard({
            x = pairX, y = pairY, w = onlineW, h = pairH,
            title = "EN LIGNE", static = true,
            extra = function(s, w, h, hf, at)
                local nPlayers = (player and player.GetCount and player.GetCount()) or 0
                local maxPlayers = game and game.MaxPlayers and game.MaxPlayers() or 0
                draw.SimpleText(nPlayers .. " / " .. maxPlayers, "LZY.Esc.OnlineSm", w / 2, h * 0.55,
                    ColorAlpha(col.title, 255 * at), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("JOUEURS", "LZY.Esc.CardDesc", w / 2, h * 0.55 + gRespY(28),
                    ColorAlpha(col.muted, 235 * at), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end,
        })
        makeCard({
            x = pairX + onlineW + pairGap, y = pairY, w = rulesW, h = pairH,
            title = "RÈGLES", img = bcMat(8),
            desc = "Règlement officiel du serveur.",
            action = ACT.rules,
        })

        -- Rangée du bas (sous la carte héros) : BINDS + RÉSEAUX + ÉVENTS
        -- (2 -> 3 cartes le 08/16, demande user : case règlement des évents).
        local botW = 203
        local botGap = 15
        makeCard({
            x = 260, y = 630, w = botW, h = 190,
            title = "BINDS", img = bcMat(7),
            desc = "Configure les touches des fonctionnalités du serveur.",
            action = ACT.bind,
        })
        local reseauxCard = makeCard({
            x = 260 + botW + botGap, y = 630, w = botW, h = 190,
            title = "RÉSEAUX", img = bcMat(9),
            desc = "Nos réseaux officiels pour suivre les actualités.",
        })
        makeCard({
            x = 260 + (botW + botGap) * 2, y = 630, w = 640 - (botW + botGap) * 2, h = 190,
            title = "ÉVENTS", img = wsMat("reglement"),
            desc = "Horaires, règles et récompenses des événements PvP du serveur.",
            action = ACT.evenements,
        })
        -- Icônes sociales DANS la carte RÉSEAUX (justifiées en bas).
        local iconSize = gRespY(34)
        local rw = gRespX(botW)
        local rpad = gRespX(24)
        local usable = rw - rpad * 2
        local gap = (#socials > 1) and (usable - iconSize * #socials) / (#socials - 1) or 0
        for i, so in ipairs(socials) do
            local sb = vgui.Create("DButton", reseauxCard)
            sb:SetSize(iconSize, iconSize)
            sb:SetPos(rpad + (i - 1) * (iconSize + gap), gRespY(190) - iconSize - gRespY(18))
            sb:SetText("")
            local mat = Material(so.mat, "smooth")
            sb.Paint = function(s, w, h)
                local hf = EVO_UI.HoverFrac(s, 12)
                surface.SetDrawColor(150 + 105 * hf, 150 + 105 * hf, 155 + 100 * hf, 255)
                surface.SetMaterial(mat)
                surface.DrawTexturedRect(0, 0, w, h)
            end
            sb.DoClick = function() openSocial(so.url) end
        end

end

hook.Add("OnPauseMenuShow", "LZY::OnPauseMenuShow::Escape", function()
	-- Cinématique d'intro / écran noir d'onboarding (âme errante = réveil, 1er spawn) actif :
	-- Échap NE DOIT RIEN ouvrir (demande user 2026-07-17). On BLOQUE (return false) sans ouvrir
	-- LZY_EscMenu — l'ordre des hooks OnPauseMenuShow n'étant PAS garanti, sans ce court-circuit
	-- le menu échap s'ouvrait EN FOCUS sous la cine (invisible via r_drawvgui 0) puis apparaissait
	-- à la fin. NB : ne couvre QUE la cinématique (EVO_IntroCine.Active), PAS le tutoriel qui
	-- suit — l'étape 1 du tuto a besoin d'Échap pour ouvrir le menu BIND.
	if EVO_IntroCine and EVO_IntroCine.Active then return false end

	-- Cam libre (citron_free_camera) active : on NE traite PAS Échap ici (return nil = on
	-- laisse la chaîne de hooks continuer). C'est le hook OnPauseMenuShow du freecam qui coupe
	-- la cam + return false. Sans ce défer, on ouvrait le menu échap par-dessus la cam libre
	-- (ordre des hooks non garanti en GMod -> le préfixe `!` du freecam ne suffit pas).
	if IsFreeCamActive and IsFreeCamActive() then return end

	-- Char-select (ncm_char_select) zoomé sur un perso : Échap DÉZOOME (return false = pas de
	-- menu pause). Sinon laisse ouvrir le menu échap normalement. (Même principe que la cam libre.)
	if NCM_CHAR_SELECT and NCM_CHAR_SELECT.OnEscape and NCM_CHAR_SELECT.OnEscape() then return false end

	-- Mode pose instructeur (evo_instructeur) actif : Échap annule la pose, pas le menu pause.
	if EVO_INSTRUCTEUR and EVO_INSTRUCTEUR.OnEscape and EVO_INSTRUCTEUR.OnEscape() then return false end

	if LocalPlayer().isChatOpen and LocalPlayer().isChatOpen == true then return false end
	if IsValid(openedFrame) then
		-- Close menu and prevent escape menu
		local f = openedFrame
		f:Close()
		if IsValid(f) then
			f:Remove()
		end
		-- Un menu fermé par-dessus un autre (aperçu cosmétique, popup lzy_popup sur la
		-- boutique / le ticket à gratter) RESTAURE le menu du dessous dans son OnRemove
		-- (EVO_MakeEscClosable). Avant, on écrasait ce rétablissement avec nil : la 2e
		-- pression d'Échap n'avait plus rien à fermer et ouvrait le menu pause PAR-DESSUS
		-- la boutique (retour user 08/27). On ne vide que si rien n'a été restauré.
		if openedFrame == f then openedFrame = nil end
		return false -- Prevent escapemenu from showing
	end

	if chatIsOpen and IsValid(chatFrame) then
		chatFrame:SetFocused(false)
		chatIsOpen = false
		return false
	end

	LZY_EscMenu()
	return false
end)
