-- "addons\\lzy_escape_menu\\lua\\autorun\\lzy_escape_menu_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_escape_menu/cl_escape_menu.lua")
    AddCSLuaFile("lzy_escape_menu/cl_rules.lua")
    AddCSLuaFile("lzy_escape_menu/cl_events.lua")
    resource.AddFile("materials/evo_lg.png")
    resource.AddFile("materials/discord_icon.png")
    resource.AddFile("materials/tiktok_icon.png")
else
    include("lzy_escape_menu/cl_rules.lua")
    include("lzy_escape_menu/cl_events.lua")
    include("lzy_escape_menu/cl_escape_menu.lua")
end
