-- "addons\\evo_afk\\lua\\autorun\\client\\cl_evo_afk.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- EVO AFK — client (09/30, user) : badge « AFK » au-dessus de la tête des joueurs AFK,
-- visible par qui est en NOCLIP (staff qui survole la map), à travers les murs.
-- AFK = mode AFK du gamemode (MUGEN.AFK:Check, écran flouté) OU inactivité evo_afk
-- (NW EVO_AFK, 5 min sans entrée).
-- ============================================================
surface.CreateFont("EVO_AFK_Tag", { font = "Bebas Neue", size = 64, weight = 400, antialias = true, extended = true })
surface.CreateFont("EVO_AFK_Zz",  { font = "Bebas Neue", size = 34, weight = 400, antialias = true, extended = true })

local COL_BG, COL_TXT, COL_ACC = Color(14, 14, 17, 225), Color(238, 239, 243), Color(207, 68, 78)
local DIST_SQ = 3000 * 3000
local vHaut, aFace = Vector(), Angle()

local function EstAFK(p)
    if p:GetEvoNWBool("EVO_AFK", false) then return true end
    return (MUGEN and MUGEN.AFK and MUGEN.AFK.Check and MUGEN.AFK:Check(p)) or false
end

hook.Add("PostDrawTranslucentRenderables", "EVO_AFK::Badge", function(bDepth, bSkybox)
    if bDepth or bSkybox then return end
    local lp = LocalPlayer()
    if not IsValid(lp) or lp:GetMoveType() ~= MOVETYPE_NOCLIP then return end
    local vEye = EyePos()
    aFace.p, aFace.y, aFace.r = 0, EyeAngles().y - 90, 90
    cam.IgnoreZ(true)
    for _, p in player.Iterator() do
        if p ~= lp and p:Alive() and EstAFK(p) and vEye:DistToSqr(p:GetPos()) <= DIST_SQ
            and not (NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(p)) then
            vHaut:Set(p:GetPos())
            vHaut.z = vHaut.z + 96 * (p:GetModelScale() or 1) -- au-dessus du nametag (80 × échelle)
            cam.Start3D2D(vHaut, aFace, 0.12)
                draw.RoundedBox(20, -80, -30, 160, 60, COL_BG)
                surface.SetDrawColor(COL_ACC)
                surface.DrawRect(-80, 26, 160, 4)
                draw.SimpleText("AFK", "EVO_AFK_Tag", -8, 0, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("zZ", "EVO_AFK_Zz", 52, -10, COL_ACC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            cam.End3D2D()
        end
    end
    cam.IgnoreZ(false)
end)
