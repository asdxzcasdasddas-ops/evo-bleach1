-- "addons\\lzy_optimisations\\lua\\lzy_optimisations\\vgui\\main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY OPTIMISATIONS — menu client (DA EVO, même style que le menu de binds).
-- ============================================================================

local PANEL = {}

local CARD_W, CARD_H = 760, 560

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

local COL = {
	card   = Color(13, 14, 17),                 -- plaque métal noir (Atelier)
	edge   = Color(146, 152, 161, 33),          -- liseré acier 1px
	sub    = Color(22, 22, 27),
	sub2   = Color(30, 30, 36),
	line   = Color(255, 255, 255, 20),
	title  = Color(237, 238, 242),
	muted  = Color(150, 154, 162),
	dim    = Color(108, 111, 120),
	accent = Color(207, 68, 78),
}

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/support) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

local function MakeFonts()
	if not gCreateRespFont then return end
	-- DA Atelier : Bebas Neue SANS bold pour l'affichage, Roboto pour les
	-- petits textes d'aide.
	gCreateRespFont("LZY_Opt_Title", "Bebas Neue", 30, 400)
	gCreateRespFont("LZY_Opt_Sub", "Roboto", 13, 500)
	gCreateRespFont("LZY_Opt_Name", "Bebas Neue", 20, 400)
	gCreateRespFont("LZY_Opt_Small", "Roboto", 12, 500)
	gCreateRespFont("LZY_Opt_Value", "Bebas Neue", 18, 400)
	gCreateRespFont("LZY_Opt_Btn", "Bebas Neue", 19, 400)
	gCreateRespFont("LZY_Opt_X", "Roboto", 26, 400)
end

hook.Add("Initialize", "LZY:Optimisations:FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "LZY:Optimisations:Fonts", MakeFonts)
MakeFonts()

local function StyledButton(parent, label, x, y, w, h, filled)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b:SetPos(R(x), R(y))
	b:SetSize(R(w), R(h))
	b.Paint = function(s, bw, bh)
		local hov = s:IsHovered()
		if filled then
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(COL.accent, hov and 255 or 220))
			draw.SimpleText(label, "LZY_Opt_Btn", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 14 or 7))
			RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(COL.line, hov and 60 or 32), 1)
			draw.SimpleText(label, "LZY_Opt_Btn", bw / 2, bh / 2, hov and COL.title or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	return b
end

local PRESET_BAR_Y = 68
local SCROLL_TOP = 122

local function CreatePresetButton(parent, x, y, w, h, presetId, label)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b:SetPos(R(x), R(y))
	b:SetSize(R(w), R(h))
	b.Paint = function(s, bw, bh)
		local active = LZY_OPTIMISATIONS.GetActivePreset() == presetId
		local hov = s:IsHovered()
		if active then
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(COL.accent, hov and 255 or 220))
			draw.SimpleText(label, "LZY_Opt_Btn", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 14 or 7))
			RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(COL.line, hov and 60 or 32), 1)
			draw.SimpleText(label, "LZY_Opt_Btn", bw / 2, bh / 2, hov and COL.title or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	return b
end

local function FormatUnits(value)
	return tostring(math.floor(tonumber(value) or 0)) .. " u"
end

local function CreateSliderRow(parent, key, meta, getValue, setValue, formatter)
	local lim = LZY_OPTIMISATIONS_LIMITS[key] or { min = 0, max = 1000, step = 1 }
	local fmt = formatter or FormatUnits
	local row = vgui.Create("DPanel", parent)
	row:Dock(TOP)
	row:DockMargin(R(24), R(8), R(24), 0)
	row:SetTall(R(86))
	row:SetMouseInputEnabled(true)
	row:SetCursor("hand")

	local dragging = false
	local pendingFrac = 0

	local function ValueFromFrac(f)
		f = math.Clamp(f, 0, 1)
		local raw = lim.min + (lim.max - lim.min) * f
		local step = lim.step or 1
		return math.Clamp(math.Round(raw / step) * step, lim.min, lim.max)
	end

	local function FracFromValue(val)
		if lim.max <= lim.min then return 0 end
		return math.Clamp((val - lim.min) / (lim.max - lim.min), 0, 1)
	end

	pendingFrac = FracFromValue(getValue())

	local function SetFracFromMouse(mx, commit)
		local trackX = R(16)
		local trackW = row:GetWide() - R(32)
		if trackW <= 0 then return end
		local f = (mx - trackX) / trackW
		pendingFrac = math.Clamp(f, 0, 1)
		if commit then
			setValue(ValueFromFrac(pendingFrac))
			-- (son de clic ui/buttonclickrelease retiré : absent du disque sur certains setups -> spam)
		end
	end

	row.Paint = function(s, w, h)
		local val = dragging and ValueFromFrac(pendingFrac) or getValue()
		local drawFrac = dragging and pendingFrac or FracFromValue(val)
		RNDX.Draw(R(10), 0, 0, w, h, COL.sub)
		draw.SimpleText(meta.title or key, "LZY_Opt_Name", R(16), R(14), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(meta.hint or "", "LZY_Opt_Small", R(16), R(34), COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(fmt(val), "LZY_Opt_Value", w - R(16), R(16), COL.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		local trackY = R(58)
		local trackH = R(6)
		local trackX = R(16)
		local trackW = w - R(32)
		RNDX.Draw(R(3), trackX, trackY, trackW, trackH, COL.sub2)
		local fillW = math.max(R(6), math.floor(trackW * drawFrac))
		RNDX.Draw(R(3), trackX, trackY, fillW, trackH, COL.accent)

		local knobX = trackX + math.floor(trackW * drawFrac)
		local knobR = R(7)
		RNDX.Draw(knobR, knobX - knobR, trackY + trackH / 2 - knobR, knobR * 2, knobR * 2, color_white)
		RNDX.DrawOutlined(knobR, knobX - knobR, trackY + trackH / 2 - knobR, knobR * 2, knobR * 2, ColorAlpha(COL.line, 80), 1)
	end

	row.OnMousePressed = function(s, code)
		if code ~= MOUSE_LEFT then return end
		dragging = true
		pendingFrac = FracFromValue(getValue())
		s:MouseCapture(true)
		SetFracFromMouse(s:ScreenToLocal(gui.MouseX(), gui.MouseY()), false)
	end

	row.OnMouseReleased = function(s, code)
		if code ~= MOUSE_LEFT then return end
		if dragging then
			SetFracFromMouse(s:ScreenToLocal(gui.MouseX(), gui.MouseY()), true)
		end
		dragging = false
		s:MouseCapture(false)
	end

	row.OnCursorMoved = function(s, mx, my)
		if not dragging then return end
		SetFracFromMouse(mx, false)
	end

	return row
end

local function CreateToggleRow(parent, meta, getValue, setValue)
	local row = vgui.Create("DPanel", parent)
	row:Dock(TOP)
	row:DockMargin(R(24), R(8), R(24), 0)
	row:SetTall(R(72))
	row:SetMouseInputEnabled(true)
	row:SetCursor("hand")

	local switchW, switchH = R(44), R(24)

	row.Paint = function(s, w, h)
		local on = getValue()
		RNDX.Draw(R(10), 0, 0, w, h, on and Color(34, 22, 24) or COL.sub)
		if on then
			RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(COL.accent, 40), 1)
		end
		draw.SimpleText(meta.title or "", "LZY_Opt_Name", R(16), R(16), on and COL.title or COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(meta.hint or "", "LZY_Opt_Small", R(16), R(36), COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		local sx = w - R(16) - switchW
		local sy = h / 2 - switchH / 2
		RNDX.Draw(R(12), sx, sy, switchW, switchH, on and ColorAlpha(COL.accent, 220) or COL.sub2)
		local knob = R(9)
		local kx = on and (sx + switchW - knob * 2 - R(3)) or (sx + R(3))
		RNDX.Draw(knob, kx, sy + switchH / 2 - knob, knob * 2, knob * 2, color_white)
	end

	row.OnMousePressed = function(s, code)
		if code ~= MOUSE_LEFT then return end
		setValue(not getValue())
		-- (son de clic ui/buttonclickrelease retiré : absent du disque sur certains setups -> spam)
	end

	return row
end

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:SetTitle("")
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetPaintBackgroundEnabled(false)
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	openedFrame = self
	self._a = 0

	local cardW, cardH = R(CARD_W), R(CARD_H)
	local cardX, cardY = math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2)

	self.Paint = function(s, w, h)
		local a = (s._a or 0) / 255
		if a < 0.01 then return end
		-- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * a)
		surface.DrawRect(0, 0, w, h)
	end
	self.OnMousePressed = function() self:Close() end

	local card = vgui.Create("DPanel", self)
	card:SetSize(cardW, cardH)
	card:SetPos(cardX, cardY)
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (self._a or 255) / 255
		if a < 0.01 then return end
		-- Plaque de métal noir PLATE Atelier + vis.
		-- DA dashboard 08/07 : plus de liseré acier (plaque plate).
		EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL.card, 250 * a), R(16))

		-- (Image background8 RETIRÉE — demande user 06/07.)
		-- DA dashboard 08/07 : vis alignées 18px sur les 2 axes.
		local sr = R(5)
		drawScrew(R(18), R(18), sr)
		drawScrew(w - R(18), R(18), sr)
		drawScrew(w - R(18), h - R(18), sr)
		drawScrew(R(18), h - R(18), sr)

		-- Titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
		draw.SimpleText("OPTIMISATIONS", "LZY_Opt_Title", R(22), R(26), ColorAlpha(COL.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("LZY_Opt_Title")
		local tw, th = surface.GetTextSize("OPTIMISATIONS")
		-- Titre CENTER-aligné vertical à Y=R(26) : slash à 78% de la hauteur
		-- mesurée sous le HAUT du texte (haut = R(26) - th/2) => R(26) + th*0.28.
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(26) + th * 0.28, tw * 1.15, R(9), ColorAlpha(COL.accent, 245 * a)) then
			surface.SetDrawColor(ColorAlpha(COL.accent, 255 * a))
			surface.DrawRect(R(22), R(26) + th * 0.34, tw, math.max(2, R(3)))
		end
		draw.SimpleText("PERFORMANCE & AFFICHAGE", "LZY_Opt_Sub", R(22) + tw + R(14), R(28), ColorAlpha(COL.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		drawDashes(R(24), R(58), w - R(48), Color(255, 255, 255, 26 * a))
	end
	self.card = card

	local close = vgui.Create("DButton", card)
	close:SetText("")
	close:SetCursor("hand")
	close:SetSize(R(28), R(28))
	close:SetPos(R(CARD_W - 42), R(19))
	close.Paint = function(s, w, h)
		-- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL.accent or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() self:Close() end

	local presetGap = 8
	local presetBarW = CARD_W - 48
	local presetBtnW = (presetBarW - presetGap * 2) / 3
	local presetOrder = LZY_OPTIMISATIONS_PRESET_ORDER or { "low", "mid", "high" }
	local presets = LZY_OPTIMISATIONS_PRESETS or {}
	for i = 1, #presetOrder do
		local id = presetOrder[i]
		local preset = presets[id]
		if preset then
			local x = 24 + (i - 1) * (presetBtnW + presetGap)
			local btn = CreatePresetButton(card, x, PRESET_BAR_Y, presetBtnW, 36, id, string.upper(preset.label or id))
			btn.DoClick = function()
				if LZY_OPTIMISATIONS.ApplyPreset(id) then
					self:RebuildRows()
					-- (son de clic ui/buttonclickrelease retiré : absent du disque sur certains setups -> spam)
				end
			end
		end
	end

	local reset = StyledButton(card, "Réinitialiser les valeurs", CARD_W - 24 - 220, CARD_H - 24 - 32, 220, 32, false)
	reset.DoClick = function()
		if LZY_OPTIMISATIONS and LZY_OPTIMISATIONS.ResetToDefaults then
			LZY_OPTIMISATIONS.ResetToDefaults()
			self:RebuildRows()
		end
	end

	self.scroll = vgui.Create("DScrollPanel", card)
	self.scroll:SetPos(R(0), R(SCROLL_TOP))
	self.scroll:SetSize(R(CARD_W), R(CARD_H - SCROLL_TOP - 64))
	local sb = self.scroll:GetVBar()
	sb:SetWide(R(6))
	sb.Paint = function() end
	sb.btnUp.Paint, sb.btnDown.Paint = function() end, function() end
	sb.btnGrip.Paint = function(s, w, h) RNDX.Draw(R(3), 0, 0, w, h, Color(70, 70, 80)) end
	sb.btnGrip:SetCursor("hand")

	self:RebuildRows()
end

function PANEL:RebuildRows()
	if not IsValid(self.scroll) then return end
	self.scroll:GetCanvas():Clear()

	local labels = LZY_OPTIMISATIONS_LABELS or {}

	CreateSliderRow(self.scroll, "distance_face_body_hair", labels.distance_face_body_hair or {}, function()
		return LZY_OPTIMISATIONS.GetDistanceFaceBodyHair()
	end, function(v)
		LZY_OPTIMISATIONS.SetDistanceFaceBodyHair(v)
	end)

	CreateSliderRow(self.scroll, "distance_accessories", labels.distance_accessories or {}, function()
		return LZY_OPTIMISATIONS.GetDistanceAccessories()
	end, function(v)
		LZY_OPTIMISATIONS.SetDistanceAccessories(v)
	end)

	CreateSliderRow(self.scroll, "distance_tattoo", labels.distance_tattoo or {}, function()
		return LZY_OPTIMISATIONS.GetDistanceTattoo()
	end, function(v)
		LZY_OPTIMISATIONS.SetDistanceTattoo(v)
	end)

	CreateSliderRow(self.scroll, "detail_budget", labels.detail_budget or {}, function()
		return LZY_OPTIMISATIONS.GetDetailBudget()
	end, function(v)
		LZY_OPTIMISATIONS.SetDetailBudget(v)
	end, function(value)
		value = math.floor(tonumber(value) or 0)
		if value <= 0 then return "Illimité" end
		return tostring(value)
	end)

	CreateSliderRow(self.scroll, "max_characters_drawn", labels.max_characters_drawn or {}, function()
		return LZY_OPTIMISATIONS.GetMaxCharactersDrawn()
	end, function(v)
		LZY_OPTIMISATIONS.SetMaxCharactersDrawn(v)
	end, function(value)
		value = math.floor(tonumber(value) or 0)
		if value <= 0 then return "Illimité" end
		return tostring(value)
	end)

	local sep = vgui.Create("DPanel", self.scroll)
	sep:Dock(TOP)
	sep:DockMargin(R(24), R(12), R(24), R(4))
	sep:SetTall(R(1))
	sep.Paint = function(s, w, h)
		surface.SetDrawColor(ColorAlpha(COL.line, 120))
		surface.DrawRect(0, 0, w, 1)
	end

	CreateToggleRow(self.scroll, labels.hide_other_accessories or {}, function()
		return LZY_OPTIMISATIONS.GetHideOtherAccessories()
	end, function(v)
		LZY_OPTIMISATIONS.SetHideOtherAccessories(v)
	end)

	CreateToggleRow(self.scroll, labels.hide_other_tattoos or {}, function()
		return LZY_OPTIMISATIONS.GetHideOtherTattoos()
	end, function(v)
		LZY_OPTIMISATIONS.SetHideOtherTattoos(v)
	end)

	-- ── Section Boost FPS / moteur ──
	local sep2 = vgui.Create("DPanel", self.scroll)
	sep2:Dock(TOP)
	sep2:DockMargin(R(24), R(12), R(24), R(4))
	sep2:SetTall(R(1))
	sep2.Paint = function(s, w, h)
		surface.SetDrawColor(ColorAlpha(COL.line, 120))
		surface.DrawRect(0, 0, w, 1)
	end

	CreateToggleRow(self.scroll, labels.disable_sword_trail or {}, LZY_OPTIMISATIONS.GetDisableSwordTrail, LZY_OPTIMISATIONS.SetDisableSwordTrail)

	-- ── Paliers de detail des autres joueurs (evo_persos_fps, convars evo_persos_*) ──
	if GetConVar("evo_persos_actif") then
		local sep3 = vgui.Create("DPanel", self.scroll)
		sep3:Dock(TOP)
		sep3:DockMargin(R(24), R(12), R(24), R(4))
		sep3:SetTall(R(1))
		sep3.Paint = function(s, w, h)
			surface.SetDrawColor(ColorAlpha(COL.line, 120))
			surface.DrawRect(0, 0, w, 1)
		end

		local function cvBool(nom) return function() return GetConVar(nom):GetBool() end end
		local function cvSetBool(nom) return function(v) RunConsoleCommand(nom, v and "1" or "0") end end
		local function cvInt(nom) return function() return GetConVar(nom):GetInt() end end
		local function cvSetInt(nom) return function(v) RunConsoleCommand(nom, tostring(math.floor(tonumber(v) or 0))) end end

		-- Plus de reglage du palier lointain ni de l'eclairage partage : palier retire
		-- le 28/09/2026 (zero gain mesure, voir cl_persos_paliers.lua).
		CreateToggleRow(self.scroll, labels.persos_actif or {}, cvBool("evo_persos_actif"), cvSetBool("evo_persos_actif"))
		-- Plancher de 1000 : les limites du curseur (config.lua) et la convar le bornent.
		CreateSliderRow(self.scroll, "persos_dist_imposteur", labels.persos_dist_imposteur or {}, cvInt("evo_persos_dist_imposteur"), cvSetInt("evo_persos_dist_imposteur"), function(value)
			return FormatUnits(math.max(1000, math.floor(tonumber(value) or 0)))
		end)
	end
end

function PANEL:Think()
	self._a = Lerp(FrameTime() * 12, self._a or 0, 255)
end

function PANEL:OnRemove()
	if openedFrame == self then openedFrame = nil end
end

vgui.Register("LZY:OptimisationsMenu", PANEL, "DFrame")

local Player = FindMetaTable("Player")

function Player:OpenOptimisationsMenu()
	vgui.Create("LZY:OptimisationsMenu")
end
