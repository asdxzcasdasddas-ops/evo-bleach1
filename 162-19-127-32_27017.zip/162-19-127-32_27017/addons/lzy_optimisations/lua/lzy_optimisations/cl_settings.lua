-- "addons\\lzy_optimisations\\lua\\lzy_optimisations\\cl_settings.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client-side optimisation settings (distances LOD + masquage accessoires/tatouages).

LZY_OPTIMISATIONS = LZY_OPTIMISATIONS or {}

local LZY_OPT_FILE = "lzy_optimisations.txt"
local settings = {}

local function WarnOptimisations(msg)
	timer.Simple(8, function()
		if IsValid(LocalPlayer()) then
			chat.AddText(Color(207, 68, 78), "[Optimisations] ", Color(235, 235, 240), msg)
		end
	end)
end

local function BuildDefaultSettings()
	local cfg = LZY_CHARACTER_CONFIG or {}
	local defs = LZY_OPTIMISATIONS_DEFAULTS or {}
	return {
		distance_face_body_hair = tonumber(cfg.DISTANCE_FACE_BODY_HAIR) or defs.distance_face_body_hair or 4000,
		distance_accessories = tonumber(cfg.DISTANCE_ACCESSORIES) or defs.distance_accessories or 2000,
		distance_tattoo = tonumber(cfg.DISTANCE_TATTOO) or defs.distance_tattoo or 1000,
		detail_budget = tonumber(defs.detail_budget) or 8,
		max_characters_drawn = tonumber(defs.max_characters_drawn) or 0,
		hide_other_accessories = defs.hide_other_accessories == true,
		hide_other_tattoos = defs.hide_other_tattoos == true,
		disable_sword_trail = defs.disable_sword_trail == true,
	}
end

local function ClampDistance(key, value)
	local lim = LZY_OPTIMISATIONS_LIMITS and LZY_OPTIMISATIONS_LIMITS[key]
	if not lim then return tonumber(value) or 0 end
	local step = lim.step or 1
	value = math.Round((tonumber(value) or lim.min) / step) * step
	return math.Clamp(value, lim.min, lim.max)
end

local function SanitizeSettings(raw)
	local out = BuildDefaultSettings()
	if not istable(raw) then return out end

	out.distance_face_body_hair = ClampDistance("distance_face_body_hair", raw.distance_face_body_hair or out.distance_face_body_hair)
	out.distance_accessories = ClampDistance("distance_accessories", raw.distance_accessories or out.distance_accessories)
	out.distance_tattoo = ClampDistance("distance_tattoo", raw.distance_tattoo or out.distance_tattoo)
	out.detail_budget = ClampDistance("detail_budget", raw.detail_budget ~= nil and raw.detail_budget or out.detail_budget)
	out.max_characters_drawn = ClampDistance("max_characters_drawn", raw.max_characters_drawn ~= nil and raw.max_characters_drawn or out.max_characters_drawn)
	out.hide_other_accessories = raw.hide_other_accessories == true
	out.hide_other_tattoos = raw.hide_other_tattoos == true
	out.disable_sword_trail = raw.disable_sword_trail == true
	return out
end

local function SaveLocalSettings()
	local content = util.TableToJSON(settings, true)
	file.Write(LZY_OPT_FILE, content)
	if file.Size(LZY_OPT_FILE, "DATA") ~= #content then
		WarnOptimisations("Impossible d'écrire le fichier local (data/" .. LZY_OPT_FILE .. ") — tes réglages ne survivront pas au prochain redémarrage.")
	end
end

local function LoadLocalSettings()
	if file.Exists(LZY_OPT_FILE, "DATA") then
		local content = file.Read(LZY_OPT_FILE, "DATA")
		if content and content ~= "" then
			local ok, data = pcall(util.JSONToTable, content)
			if ok and istable(data) then
				settings = SanitizeSettings(data)
				return true
			end
			file.Write("lzy_optimisations_corrupt.bak.txt", content)
			WarnOptimisations("Fichier local illisible — réglages réinitialisés (copie : data/lzy_optimisations_corrupt.bak.txt).")
		end
	end
	settings = BuildDefaultSettings()
	return false
end

function LZY_OPTIMISATIONS.GetSettings()
	return table.Copy(settings)
end

function LZY_OPTIMISATIONS.GetDistanceFaceBodyHair()
	return settings.distance_face_body_hair or 4000
end

function LZY_OPTIMISATIONS.GetDistanceAccessories()
	return settings.distance_accessories or 2000
end

function LZY_OPTIMISATIONS.GetDistanceTattoo()
	return settings.distance_tattoo or 1000
end

function LZY_OPTIMISATIONS.GetHideOtherAccessories()
	return settings.hide_other_accessories == true
end

function LZY_OPTIMISATIONS.GetHideOtherTattoos()
	return settings.hide_other_tattoos == true
end

function LZY_OPTIMISATIONS.GetDetailBudget()
	return tonumber(settings.detail_budget) or 8
end

function LZY_OPTIMISATIONS.GetMaxCharactersDrawn()
	return tonumber(settings.max_characters_drawn) or 0
end

function LZY_OPTIMISATIONS.SetDistanceFaceBodyHair(value)
	settings.distance_face_body_hair = ClampDistance("distance_face_body_hair", value)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetDistanceAccessories(value)
	settings.distance_accessories = ClampDistance("distance_accessories", value)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetDistanceTattoo(value)
	settings.distance_tattoo = ClampDistance("distance_tattoo", value)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetDetailBudget(value)
	settings.detail_budget = ClampDistance("detail_budget", value)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetMaxCharactersDrawn(value)
	settings.max_characters_drawn = ClampDistance("max_characters_drawn", value)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetHideOtherAccessories(value)
	settings.hide_other_accessories = value == true
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

function LZY_OPTIMISATIONS.SetHideOtherTattoos(value)
	settings.hide_other_tattoos = value == true
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end

-- ── Boost FPS / moteur (toggle indépendant des presets) ──
function LZY_OPTIMISATIONS.GetDisableSwordTrail() return settings.disable_sword_trail == true end

local function SetBoolOption(key, value)
	settings[key] = value == true
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
end
function LZY_OPTIMISATIONS.SetDisableSwordTrail(v) SetBoolOption("disable_sword_trail", v) end

function LZY_OPTIMISATIONS.ResetToDefaults()
	settings = BuildDefaultSettings()
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
	-- Les paliers de detail (evo_persos_fps) vivent dans des convars : on les
	-- remet a leur valeur par defaut avec le reste.
	for _, cv in ipairs({ "evo_persos_actif", "evo_persos_dist_loin", "evo_persos_dist_imposteur", "evo_persos_lumiere" }) do
		local c = GetConVar(cv)
		if c then RunConsoleCommand(cv, c:GetDefault()) end
	end
end

local function SettingsMatchPreset(preset)
	if not istable(preset) then return false end
	return settings.distance_face_body_hair == ClampDistance("distance_face_body_hair", preset.distance_face_body_hair)
		and settings.distance_accessories == ClampDistance("distance_accessories", preset.distance_accessories)
		and settings.distance_tattoo == ClampDistance("distance_tattoo", preset.distance_tattoo)
		and settings.detail_budget == ClampDistance("detail_budget", preset.detail_budget ~= nil and preset.detail_budget or 8)
		and settings.max_characters_drawn == ClampDistance("max_characters_drawn", preset.max_characters_drawn ~= nil and preset.max_characters_drawn or 0)
		and settings.hide_other_accessories == (preset.hide_other_accessories == true)
		and settings.hide_other_tattoos == (preset.hide_other_tattoos == true)
		and settings.disable_sword_trail == (preset.disable_sword_trail == true)
end

function LZY_OPTIMISATIONS.GetActivePreset()
	local presets = LZY_OPTIMISATIONS_PRESETS or {}
	local order = LZY_OPTIMISATIONS_PRESET_ORDER or { "low", "mid", "high" }
	for i = 1, #order do
		local id = order[i]
		if SettingsMatchPreset(presets[id]) then
			return id
		end
	end
	return nil
end

function LZY_OPTIMISATIONS.ApplyPreset(presetId)
	local preset = LZY_OPTIMISATIONS_PRESETS and LZY_OPTIMISATIONS_PRESETS[presetId]
	if not preset then return false end
	-- Fusion du preset PAR-DESSUS les réglages actuels : le preset pilote distances + masquages +
	-- toggles FPS/moteur (Faible = tout coupé). SEUL fps_cap (absent des presets) est préservé.
	local merged = table.Copy(settings)
	for k, v in pairs(preset) do
		if k ~= "label" then merged[k] = v end
	end
	settings = SanitizeSettings(merged)
	SaveLocalSettings()
	LZY_OPTIMISATIONS.ApplySettings()
	return true
end

function LZY_OPTIMISATIONS.ApplySettings()
	-- Sync convar legacy (cl_models / console) avec le réglage menu.
	local budget = LZY_OPTIMISATIONS.GetDetailBudget()
	if GetConVar then
		local cv = GetConVar("evo_player_lod_budget")
		if cv and cv:GetInt() ~= budget then
			RunConsoleCommand("evo_player_lod_budget", tostring(budget))
		end
	end

	-- Retag immédiat pour que le nouveau budget s'applique sans attendre le prochain Think.
	if LZY_Character_UpdateDetailBudgetTags then
		LZY_Character_UpdateDetailBudgetTags()
	end

	if LZY_Character_InvalidateDrawState then
		for _, ply in player.Iterator() do
			if IsValid(ply) then
				LZY_Character_InvalidateDrawState(ply)
			end
		end
	end
	-- Composites manquants (ex. après reconnect) : sync sans tout forcer.
	-- Le retag ci-dessus déclenche aussi les remontées de budget (TryCreate).
	if LZY_Character_RepairAllClientModels then
		LZY_Character_RepairAllClientModels({})
	end
	-- Re-bake les faces APRÈS avoir vidé les caches RT. Sinon les submaterials de face pointent
	-- sur des RT vidées -> TÊTE NOIRE (HUD + in-game) jusqu'à l'alt-tab. RefreshAllPlayerFaceMaterials
	-- (invalidateCaches=true) vide les caches PUIS ré-applique peau + tatouage = exactement le chemin
	-- du handler d'alt-tab/restauration VRAM. ApplySettings n'est appelé qu'au RELÂCHÉ du slider /
	-- clic toggle/preset (pas par frame) -> aucun coût de re-bake pendant le drag.
	if LZY_Character_RefreshAllPlayerFaceMaterials then
		LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = true })
	elseif LZY_InvalidateFaceRenderCaches then
		LZY_InvalidateFaceRenderCaches()
	end

	-- Rayon de dessin / plafond modifiés : des joueurs peuvent entrer dans le rayon
	-- sans données PM — cl_models rescanne et les demande via RequestPM.
	hook.Run("LZY:Optimisations:SettingsApplied")
end

-- Patch client distance getters so cl_models.lua picks up local overrides.
if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.DistanceSqr then
	function LZY_CHARACTER_CONFIG.GetFaceBodyHairDistanceSqr()
		return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_OPTIMISATIONS.GetDistanceFaceBodyHair())
	end

	function LZY_CHARACTER_CONFIG.GetAccessoriesDistanceSqr()
		return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_OPTIMISATIONS.GetDistanceAccessories())
	end

	function LZY_CHARACTER_CONFIG.GetTattooDistanceSqr()
		return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_OPTIMISATIONS.GetDistanceTattoo())
	end
end

hook.Add("Initialize", "LZY:Optimisations:ClientInit", function()
	LoadLocalSettings()
end)

LoadLocalSettings()

concommand.Add("lzy_optimisations_menu", function()
	if IsValid(LocalPlayer()) and LocalPlayer().OpenOptimisationsMenu then
		LocalPlayer():OpenOptimisationsMenu()
	end
end)
