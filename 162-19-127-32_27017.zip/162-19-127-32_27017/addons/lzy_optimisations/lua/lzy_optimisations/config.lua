-- "addons\\lzy_optimisations\\lua\\lzy_optimisations\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_OPTIMISATIONS_DEFAULTS = LZY_OPTIMISATIONS_DEFAULTS or {}
LZY_OPTIMISATIONS_DEFAULTS.distance_face_body_hair = LZY_OPTIMISATIONS_DEFAULTS.distance_face_body_hair or 4000
LZY_OPTIMISATIONS_DEFAULTS.distance_accessories = LZY_OPTIMISATIONS_DEFAULTS.distance_accessories or 2000
LZY_OPTIMISATIONS_DEFAULTS.distance_tattoo = LZY_OPTIMISATIONS_DEFAULTS.distance_tattoo or 1000
LZY_OPTIMISATIONS_DEFAULTS.detail_budget = LZY_OPTIMISATIONS_DEFAULTS.detail_budget or 8
-- 0 = ILLIMITE, et c'est un CHOIX, pas un oubli (tranché par le user le 06/08).
-- Ne pas le « corriger » : plafonner ferait disparaître des joueurs du décor, et sur un
-- RP voir qui est là passe avant les FPS. Le coût est connu et assumé — à 104 joueurs au
-- même endroit (05/08) le client assemble 104 personnages composites par image.
-- Le plafond existe et reste disponible : c'est au JOUEUR de le poser, via le menu
-- Optimisations ou le préréglage « Faible » (16) / « Moyen » (25).
LZY_OPTIMISATIONS_DEFAULTS.max_characters_drawn = LZY_OPTIMISATIONS_DEFAULTS.max_characters_drawn or 0
if LZY_OPTIMISATIONS_DEFAULTS.hide_other_accessories == nil then LZY_OPTIMISATIONS_DEFAULTS.hide_other_accessories = false end
if LZY_OPTIMISATIONS_DEFAULTS.hide_other_tattoos == nil then LZY_OPTIMISATIONS_DEFAULTS.hide_other_tattoos = false end
if LZY_OPTIMISATIONS_DEFAULTS.disable_sword_trail == nil then LZY_OPTIMISATIONS_DEFAULTS.disable_sword_trail = false end

LZY_OPTIMISATIONS_LIMITS = LZY_OPTIMISATIONS_LIMITS or {}
LZY_OPTIMISATIONS_LIMITS.distance_face_body_hair = LZY_OPTIMISATIONS_LIMITS.distance_face_body_hair or { min = 500, max = 8000, step = 100 }
LZY_OPTIMISATIONS_LIMITS.distance_accessories = LZY_OPTIMISATIONS_LIMITS.distance_accessories or { min = 250, max = 4000, step = 50 }
LZY_OPTIMISATIONS_LIMITS.distance_tattoo = LZY_OPTIMISATIONS_LIMITS.distance_tattoo or { min = 250, max = 2000, step = 50 }
LZY_OPTIMISATIONS_LIMITS.detail_budget = LZY_OPTIMISATIONS_LIMITS.detail_budget or { min = 0, max = 32, step = 1 }
LZY_OPTIMISATIONS_LIMITS.max_characters_drawn = LZY_OPTIMISATIONS_LIMITS.max_characters_drawn or { min = 0, max = 64, step = 1 }
-- Paliers de detail des autres joueurs (evo_persos_fps) : convars evo_persos_*.
LZY_OPTIMISATIONS_LIMITS.persos_dist_loin = LZY_OPTIMISATIONS_LIMITS.persos_dist_loin or { min = 500, max = 6000, step = 100 }
LZY_OPTIMISATIONS_LIMITS.persos_dist_imposteur = LZY_OPTIMISATIONS_LIMITS.persos_dist_imposteur or { min = 1000, max = 6000, step = 100 }

-- Préréglages rapides (low = perf, mid = défaut serveur, high = qualité max).
-- NB : les presets pilotent les distances, les masquages ET la traînée d'épée (Faible = coupée).
LZY_OPTIMISATIONS_PRESET_ORDER = LZY_OPTIMISATIONS_PRESET_ORDER or { "low", "mid", "high" }

LZY_OPTIMISATIONS_PRESETS = LZY_OPTIMISATIONS_PRESETS or {}
LZY_OPTIMISATIONS_PRESETS.low = LZY_OPTIMISATIONS_PRESETS.low or {
	label = "Faible",
	distance_face_body_hair = 2000,
	distance_accessories = 1000,
	distance_tattoo = 500,
	detail_budget = 4,
	max_characters_drawn = 16,
	hide_other_accessories = true,
	hide_other_tattoos = true,
	disable_sword_trail = true,
}
LZY_OPTIMISATIONS_PRESETS.low.detail_budget = LZY_OPTIMISATIONS_PRESETS.low.detail_budget or 4
LZY_OPTIMISATIONS_PRESETS.low.max_characters_drawn = LZY_OPTIMISATIONS_PRESETS.low.max_characters_drawn or 16

LZY_OPTIMISATIONS_PRESETS.mid = LZY_OPTIMISATIONS_PRESETS.mid or {
	label = "Moyen",
	distance_face_body_hair = 4000,
	distance_accessories = 2000,
	distance_tattoo = 1000,
	detail_budget = 8,
	max_characters_drawn = 25,
	hide_other_accessories = false,
	hide_other_tattoos = false,
	disable_sword_trail = false,
}
LZY_OPTIMISATIONS_PRESETS.mid.detail_budget = LZY_OPTIMISATIONS_PRESETS.mid.detail_budget or 8
LZY_OPTIMISATIONS_PRESETS.mid.max_characters_drawn = LZY_OPTIMISATIONS_PRESETS.mid.max_characters_drawn or 32

LZY_OPTIMISATIONS_PRESETS.high = LZY_OPTIMISATIONS_PRESETS.high or {
	label = "Eleve",
	distance_face_body_hair = 7000,
	distance_accessories = 3500,
	distance_tattoo = 1750,
	detail_budget = 0,
	max_characters_drawn = 0,
	hide_other_accessories = false,
	hide_other_tattoos = false,
	disable_sword_trail = false,
}
if LZY_OPTIMISATIONS_PRESETS.high.detail_budget == nil then
	LZY_OPTIMISATIONS_PRESETS.high.detail_budget = 0
end
if LZY_OPTIMISATIONS_PRESETS.high.max_characters_drawn == nil then
	LZY_OPTIMISATIONS_PRESETS.high.max_characters_drawn = 0
end

LZY_OPTIMISATIONS_LABELS = LZY_OPTIMISATIONS_LABELS or {}
LZY_OPTIMISATIONS_LABELS.distance_face_body_hair = LZY_OPTIMISATIONS_LABELS.distance_face_body_hair or {
	title = "Corps, tête & cheveux",
	hint = "Distance d'affichage du modèle principal des autres joueurs.",
}
LZY_OPTIMISATIONS_LABELS.distance_accessories = LZY_OPTIMISATIONS_LABELS.distance_accessories or {
	title = "Accessoires & barbe",
	hint = "Distance d'affichage des accessoires équipés et de la barbe/moustache.",
}
LZY_OPTIMISATIONS_LABELS.distance_tattoo = LZY_OPTIMISATIONS_LABELS.distance_tattoo or {
	title = "Tatouages",
	hint = "Distance d'affichage des tatouages sur le visage (joueurs en détail complet).",
}
LZY_OPTIMISATIONS_LABELS.detail_budget = LZY_OPTIMISATIONS_LABELS.detail_budget or {
	title = "Persos en détail complet (max)",
	hint = "Nombre max d'autres joueurs proches avec accessoires, barbe et tatouages. 0 = illimité. Priorité à ceux devant toi. Les autres gardent cheveux + tenue.",
}
LZY_OPTIMISATIONS_LABELS.max_characters_drawn = LZY_OPTIMISATIONS_LABELS.max_characters_drawn or {
	title = "Persos dessinés (max)",
	hint = "Nombre max d'autres joueurs dessinés (corps/tête/cheveux). 0 = illimité. Priorité à ceux devant toi ; les autres sont masqués.",
}
LZY_OPTIMISATIONS_LABELS.hide_other_accessories = LZY_OPTIMISATIONS_LABELS.hide_other_accessories or {
	title = "Masquer les accessoires des autres joueurs",
	hint = "Masque barbe, moustache et accessoires des autres joueurs (hors insignes et cosmétiques staff).",
}
LZY_OPTIMISATIONS_LABELS.hide_other_tattoos = LZY_OPTIMISATIONS_LABELS.hide_other_tattoos or {
	title = "Masquer les tatouages des autres joueurs",
	hint = "Désactive complètement les tatouages sur les autres joueurs.",
}
LZY_OPTIMISATIONS_LABELS.disable_sword_trail = LZY_OPTIMISATIONS_LABELS.disable_sword_trail or {
	title = "Désactiver la traînée d'épée",
	hint = "Coupe la traînée des katanas (tous les joueurs).",
}
LZY_OPTIMISATIONS_LABELS.persos_actif = LZY_OPTIMISATIONS_LABELS.persos_actif or {
	title = "Images plates des joueurs lointains",
	hint = "Au-delà de la distance choisie ci-dessous, un joueur est remplacé par une image plate. Gros gain d'images par seconde en rassemblement.",
}
LZY_OPTIMISATIONS_LABELS.persos_dist_loin = LZY_OPTIMISATIONS_LABELS.persos_dist_loin or {
	title = "Détail réduit à partir de",
	hint = "Distance à partir de laquelle un joueur passe en détail réduit.",
}
LZY_OPTIMISATIONS_LABELS.persos_dist_imposteur = LZY_OPTIMISATIONS_LABELS.persos_dist_imposteur or {
	title = "Image plate à partir de",
	hint = "Au-delà, le joueur est remplacé par une image plate mise à jour plusieurs fois par seconde. 1000 minimum (par défaut). Pour les couper, décoche l'option au-dessus.",
}
LZY_OPTIMISATIONS_LABELS.persos_lumiere = LZY_OPTIMISATIONS_LABELS.persos_lumiere or {
	title = "Éclairage partagé sur les joueurs loin",
	hint = "L'éclairage est calculé une fois par joueur au lieu d'une fois par pièce (tenue, cheveux, insignes).",
}
