-- "addons\\lzy_optimisations\\lua\\autorun\\lzy_optimisations_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_optimisations/config.lua")
	AddCSLuaFile("lzy_optimisations/cl_settings.lua")
	AddCSLuaFile("lzy_optimisations/vgui/main.lua")
end

if CLIENT then
	include("lzy_optimisations/config.lua")
	include("lzy_optimisations/cl_settings.lua")
	include("lzy_optimisations/vgui/main.lua")
end
