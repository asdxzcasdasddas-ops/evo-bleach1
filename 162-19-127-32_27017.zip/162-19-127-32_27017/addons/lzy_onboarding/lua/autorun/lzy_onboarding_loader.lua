-- "addons\\lzy_onboarding\\lua\\autorun\\lzy_onboarding_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_onboarding/config.lua")
	AddCSLuaFile("lzy_onboarding/cl_main.lua")
	AddCSLuaFile("lzy_onboarding/cl_division_ping.lua")
	AddCSLuaFile("lzy_onboarding/cl_formation.lua")
	include("lzy_onboarding/config.lua")
	include("lzy_onboarding/sv_main.lua")
	include("lzy_onboarding/sv_division_ping.lua")
	include("lzy_onboarding/sv_formation.lua")
else
	include("lzy_onboarding/config.lua")
	include("lzy_onboarding/cl_main.lua")
	include("lzy_onboarding/cl_division_ping.lua")
	include("lzy_onboarding/cl_formation.lua")
end
