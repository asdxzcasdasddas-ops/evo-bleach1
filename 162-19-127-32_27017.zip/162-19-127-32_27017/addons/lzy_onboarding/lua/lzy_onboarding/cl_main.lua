-- "addons\\lzy_onboarding\\lua\\lzy_onboarding\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local frame = nil
local PANEL = {}

local stepState = {
	[1] = false,
	[2] = false,
}

-- Base DA EVO (carte sombre, accent UNIQUE rouge #cf444e, sans bordure).
local COL_CARD   = Color(14, 14, 17, 240)
local COL_TITLE  = Color(237, 238, 242)
local COL_TEXT   = Color(232, 234, 238)
local COL_DONE   = Color(120, 124, 132)
local COL_ACCENT = Color(207, 68, 78)

function PANEL:Init()
	self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:SetVisible(true)
	self.panelWidth = 400 -- 350 rognait la 2e étape (texte allongé le 08/20)
	self.panelHeight = 88
	self:gSetSize(self.panelWidth, self.panelHeight)
	-- Descendu sous le tracker de quêtes (haut-gauche : ~y15 -> ~y165) pour ne pas
	-- recouvrir l'UI des quêtes ni les autres HUD du coin haut-gauche.
	self:gSetPos(50, 230)

	-- (La formation ne se passe plus : le bouton « Passer la formation » a été
	-- retiré le 08/20 sur demande user — se présenter à un formateur est le SEUL
	-- moyen de terminer l'onboarding.)
end

function PANEL:Paint(w, h)
	-- L'onboarding formateur (« Objectifs de votre premier jour ») ne s'affiche PAS :
	--   • dans le HUB / menu perso (InCharacterMenu) -> pas avant d'avoir spawné le perso ;
	--   • pendant le TUTORIEL (NCM_TUTORIEL.Active) -> il doit arriver APRÈS le tuto.
	local lp = LocalPlayer()
	if not IsValid(lp) or lp:GetEvoNWBool("InCharacterMenu", false)
		or (NCM_TUTORIEL and NCM_TUTORIEL.Active) then
		return
	end

	-- Flou + carte sombre arrondie (base DA EVO), SANS bordure blanche.
	RNDX.Draw(gRespY(10), 0, 0, w, h, Color(255, 255, 255, 255), RNDX.BLUR)
	RNDX.Draw(gRespY(10), 0, 0, w, h, COL_CARD)

	local titleFont = "Ubuntu Mono Bold:" .. tostring(gRespFont(15))
	local stepFont  = "Ubuntu Mono:" .. tostring(gRespFont(15))

	local titleY = gRespY(21)
	local step1Y = gRespY(50)
	local step2Y = gRespY(71)

	-- Titre (blanc) + fine ligne d'accent rouge (seul élément coloré)
	draw.SimpleText(string.upper("Objectifs de votre premier jour"), titleFont, w / 2, titleY, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(w / 2 - gRespX(58), gRespY(34), gRespX(116), gRespY(2))

	-- Étape 1 : grisée + barrée en rouge une fois validée
	draw.SimpleText("1. Présentez-vous à un formateur", stepFont, w / 2, step1Y, stepState[1] and COL_DONE or COL_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	if stepState[1] then
		surface.SetFont(stepFont)
		local sw = surface.GetTextSize("1. Présentez-vous à un formateur")
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(w / 2 - sw / 2, step1Y - gRespY(1), sw, gRespY(2))
	end

	-- Étape 2
	draw.SimpleText("2. Demandez-lui de lancer votre formation", stepFont, w / 2, step2Y, stepState[2] and COL_DONE or COL_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	if stepState[2] then
		surface.SetFont(stepFont)
		local sw = surface.GetTextSize("2. Demandez-lui de lancer votre formation")
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(w / 2 - sw / 2, step2Y - gRespY(1), sw, gRespY(2))
	end

end

function PANEL:OnClose()
	frame = nil
	self:Remove()
end

vgui.Register("LZYOnboarding", PANEL, "DFrame")

function OpenOnboarding()
	if IsValid(frame) then
		frame:Close()
	end
	frame = vgui.Create("LZYOnboarding")
end

function CloseOnboarding()
	if IsValid(frame) then
		frame:Close()
	end
	-- reset des objectifs pour la prochaine session d'onboarding (nouveau perso)
	stepState[1] = false
	stepState[2] = false
end

net.Receive("LZY:client:StartOnboarding", function()
	local hasInstructor = net.ReadBool()
	OpenOnboarding()
	if hasInstructor then
		-- On lit l'entite pour garder la symetrie avec l'ecriture serveur, mais on ne
		-- pose AUCUN marqueur boussole : le guidage vers le formateur passe desormais par
		-- le waypoint de quete (net "NCM_Quete::UpdateWaypoint", rendu par ncm_quete_system
		-- = marqueur a l'ecran + fleche directionnelle hors-champ + label/distance),
		-- pilote cote serveur (lzy_onboarding sv_main : il suit le formateur qui bouge).
		-- (08/20, demande user) Etre LOCALISE ne valide PLUS l'objectif 1 : c'est SE
		-- PRESENTER au formateur qui le valide (net OnboardingPresented, via lzy_meet).
		net.ReadEntity()
	end
end)

-- L'aspirant vient de faire « Se Présenter » à un guide éligible : objectif 1 validé.
net.Receive("LZY:client:OnboardingPresented", function()
	stepState[1] = true
end)

net.Receive("LZY:client:StopOnboarding", function()
	net.ReadString() -- payload ignore (symetrie d'ecriture serveur)
	-- Le waypoint formateur est coupe cote serveur (StopFormateurGuide -> net
	-- "NCM_Quete::UpdateWaypoint" false), rien a retirer cote client ici.
	CloseOnboarding()
end)

-- (Résidu de debug retiré 10/08 : concommand "testt" qui togglait le panneau sans
-- aucune garde — n'importe quel joueur pouvait s'ouvrir un faux panneau d'objectifs.)
