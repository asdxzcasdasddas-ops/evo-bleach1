-- "addons\\lzy_onboarding\\lua\\lzy_onboarding\\cl_formation.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- FORMATION — CLIENT : checklist HUD (haut-gauche, sous le panneau
-- d'onboarding) + popup de notation du formateur en fin de parcours.
-- L'état vient exclusivement du serveur (LZY:Formation:Sync, edge).
-- Formateur : liste compacte (nom + étape) de TOUS ses élèves.
-- Élève : checklist complète, inchangée.
-- ============================================================

-- Base DA EVO : mêmes couleurs que le panneau d'onboarding (cl_main.lua).
local COL_CARD   = Color(14, 14, 17, 240)
local COL_TITLE  = Color(237, 238, 242)
local COL_TEXT   = Color(232, 234, 238)
local COL_DONE   = Color(120, 124, 132)
local COL_DIM    = Color(150, 152, 158)
local COL_ACCENT = Color(207, 68, 78)
local COL_STAR   = Color(224, 178, 58)

-- Élève : { isFormateur=false, stepIdx, visited, total, other }
-- Formateur : { isFormateur=true, trainees = { { ply, stepIdx, visited, total }, ... } }
local state = nil

-- Libellés : « ordre » sur Hueco, « division » ailleurs (même monde que les balises).
local function StepLabels()
	local sLieu = (game.GetMap() == "hueco_mundo_v1") and "chaque ordre" or "chaque division"
	return {
		"Se présenter au formateur",
		"Interagir avec la Carte du Monde",
		"Interagir avec le Urahara Shop",
		"Aller devant le Maître d'Armes",
		"Aller devant " .. sLieu,
	}
end

local function CompactStep(t)
	local tLabels = StepLabels()
	if t.stepIdx > #tLabels then return "En attente de la note" end
	local s = t.stepIdx .. ". " .. tLabels[t.stepIdx]
	if t.stepIdx == 5 and (t.total or 0) > 0 then
		s = s .. " (" .. t.visited .. "/" .. t.total .. ")"
	end
	return s
end

local function TraineeName(ply)
	if IsValid(ply) and EVO_GetRPDisplayName then return EVO_GetRPDisplayName(ply) end
	if IsValid(ply) then return ply:Nick() end
	return "élève"
end

-- ── Checklist HUD (pattern du panneau d'onboarding : DFrame passif, Paint only) ──
local frame = nil
local PANEL = {}

local TRAINEE_H = 186
local HEADER_H  = 50
local ROW_H     = 22
local PAD_H     = 12

function PANEL:Init()
	self:SetDraggable(false)
	self:SetSizable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:gSetSize(350, TRAINEE_H)
	-- Sous le panneau d'onboarding (50,230) pour ne recouvrir ni lui ni le tracker.
	self:gSetPos(50, 340)
	self:SetMouseInputEnabled(false)
end

function PANEL:ClearScroll()
	if IsValid(self.scroll) then self.scroll:Remove() end
	self.scroll = nil
end

function PANEL:ApplyState()
	if not state then return end
	if not state.isFormateur then
		self:ClearScroll()
		self:SetMouseInputEnabled(false)
		self:gSetSize(350, TRAINEE_H)
		return
	end

	local n      = #(state.trainees or {})
	local needH  = HEADER_H + n * ROW_H + PAD_H
	-- 40 % d'un 1080p (gSetSize scale ensuite) : ~17 élèves avant scroll.
	local maxH   = math.floor(1080 * 0.4)
	local bScroll = needH > maxH
	self:gSetSize(350, math.min(needH, maxH))
	self:SetMouseInputEnabled(bScroll)

	if not bScroll then
		self:ClearScroll()
		return
	end

	if not IsValid(self.scroll) then
		self.scroll = vgui.Create("DScrollPanel", self)
		self.scroll.Paint = function() end
	end
	local s = self.scroll
	s:gSetPos(0, HEADER_H)
	s:gSetSize(350, math.min(needH, maxH) - HEADER_H)
	s:GetCanvas():Clear()

	local stepFont = "Ubuntu Mono:" .. tostring(gRespFont(13))
	local nameFont = "Ubuntu Mono Bold:" .. tostring(gRespFont(13))
	for _, t in ipairs(state.trainees) do
		local row = s:Add("DPanel")
		row:SetTall(gRespY(ROW_H))
		row:Dock(TOP)
		row:SetPaintBackground(false)
		row.Paint = function(_, w, h)
			local sName = TraineeName(t.ply)
			local sStep = CompactStep(t)
			local col   = t.stepIdx > 5 and COL_ACCENT or COL_TEXT
			draw.SimpleText(sName, nameFont, gRespX(12), h * 0.5, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sStep, stepFont, w - gRespX(12), h * 0.5, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
end

function PANEL:Paint(w, h)
	local lp = LocalPlayer()
	if not state or not IsValid(lp) or lp:GetEvoNWBool("InCharacterMenu", false) then return end

	RNDX.Draw(gRespY(10), 0, 0, w, h, Color(255, 255, 255, 255), RNDX.BLUR)
	RNDX.Draw(gRespY(10), 0, 0, w, h, COL_CARD)

	local titleFont = "Ubuntu Mono Bold:" .. tostring(gRespFont(15))
	local stepFont  = "Ubuntu Mono:" .. tostring(gRespFont(14))

	local sTitle = "FORMATION EN COURS"
	draw.SimpleText(sTitle, titleFont, w / 2, gRespY(21), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(w / 2 - gRespX(58), gRespY(34), gRespX(116), gRespY(2))

	if state.isFormateur then
		-- Liste compacte : peinte ici si ça tient, sinon les rows sont dans le scroll.
		if IsValid(self.scroll) then return end
		local y = gRespY(HEADER_H)
		local compactFont = "Ubuntu Mono:" .. tostring(gRespFont(13))
		local nameFont    = "Ubuntu Mono Bold:" .. tostring(gRespFont(13))
		for _, t in ipairs(state.trainees or {}) do
			local sName = TraineeName(t.ply)
			local sStep = CompactStep(t)
			local col   = t.stepIdx > 5 and COL_ACCENT or COL_TEXT
			draw.SimpleText(sName, nameFont, gRespX(12), y, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(sStep, compactFont, w - gRespX(12), y, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			y = y + gRespY(ROW_H)
		end
		return
	end

	local tLabels = StepLabels()
	local y = gRespY(50)
	for i, sLabel in ipairs(tLabels) do
		local sText = i .. ". " .. sLabel
		if i == 5 and state.total > 0 then
			sText = sText .. " (" .. state.visited .. "/" .. state.total .. ")"
		end
		local bDone = i < state.stepIdx
		local col = bDone and COL_DONE or (i == state.stepIdx and COL_TEXT or COL_DIM)
		draw.SimpleText(sText, stepFont, w / 2, y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if bDone then
			surface.SetFont(stepFont)
			local sw = surface.GetTextSize(sText)
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(w / 2 - sw / 2, y - gRespY(1), sw, gRespY(2))
		end
		y = y + gRespY(22)
	end

	-- Parcours fini (stepIdx > 5) : l'élève a sa popup.
	if state.stepIdx > #tLabels then
		draw.SimpleText("Note ton formateur !",
			"Ubuntu Mono Bold:" .. tostring(gRespFont(13)), w / 2, y, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

function PANEL:OnClose()
	frame = nil
	self:Remove()
end

vgui.Register("LZYFormationHUD", PANEL, "DFrame")

local function CloseHUD()
	if IsValid(frame) then frame:Close() end
end

-- ── Popup de notation (fin de parcours) ─────────────────────────────────────────
local noteFrame = nil

local function OpenNoteUI()
	if IsValid(noteFrame) then noteFrame:Remove() end

	local W, H = 420, 190
	local f = vgui.Create("DFrame")
	noteFrame = f
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:SetDraggable(false)
	f:gSetSize(W, H)
	f:Center()
	f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end

	-- Nom RP du formateur, règle des nametags (présentation + masque).
	-- (`other` = le formateur, puisque seule l'élève reçoit AskNote.)
	local sWho = "ton formateur"
	if state and not state.isFormateur and IsValid(state.other) and EVO_GetRPDisplayName then
		sWho = EVO_GetRPDisplayName(state.other)
	end

	f.Paint = function(_, w, h)
		RNDX.Draw(gRespY(10), 0, 0, w, h, Color(255, 255, 255, 255), RNDX.BLUR)
		RNDX.Draw(gRespY(10), 0, 0, w, h, COL_CARD)
		local titleFont = "Ubuntu Mono Bold:" .. tostring(gRespFont(16))
		local subFont   = "Ubuntu Mono:" .. tostring(gRespFont(13))
		draw.SimpleText("FORMATION TERMINÉE", titleFont, w / 2, gRespY(26), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(w / 2 - gRespX(58), gRespY(40), gRespX(116), gRespY(2))
		draw.SimpleText("Quelle note donnes-tu à " .. sWho .. " ?", subFont, w / 2, gRespY(58), COL_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- 5 étoiles : le survol « remplit » jusqu'à l'étoile visée, le clic envoie.
	local nHover = 0
	local starFont = "Ubuntu Mono Bold:" .. tostring(gRespFont(34))
	for i = 1, 5 do
		local b = vgui.Create("DButton", f)
		b:SetText("")
		b:gSetSize(56, 56)
		b:gSetPos(W / 2 - (5 * 56) / 2 + (i - 1) * 56, 78)
		b.OnCursorEntered = function() nHover = i end
		b.OnCursorExited  = function() if nHover == i then nHover = 0 end end
		b.Paint = function(_, w, h)
			local bFilled = i <= nHover
			draw.SimpleText("★", starFont, w / 2, h / 2, bFilled and COL_STAR or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			net.Start("LZY:Formation:Note") -- netgate: edge -- un clic, une note, la fenêtre se ferme
				net.WriteUInt(i, 3)
			net.SendToServer()
			if IsValid(noteFrame) then noteFrame:Remove() end
			noteFrame = nil
		end
	end

	local hint = vgui.Create("DLabel", f)
	hint:SetText("1 = décevant · 5 = excellent (la note récompense ton formateur)")
	hint:SetFont("Ubuntu Mono:" .. tostring(gRespFont(11)))
	hint:SetTextColor(COL_DIM)
	hint:SizeToContents()
	hint:gSetPos(0, 148)
	hint:CenterHorizontal()

	surface.PlaySound("buttons/button14.wav")
end

-- ── Réseau ───────────────────────────────────────────────────────────────────────
-- Payload branché sur isFormateur (⚠ même rang que sv_formation Send*).
net.Receive("LZY:Formation:Sync", function()
	local bActive = net.ReadBool()
	if not bActive then
		state = nil
		CloseHUD()
		-- Annulation pendant la notation : plus rien à noter, on ferme la popup.
		if IsValid(noteFrame) then noteFrame:Remove() noteFrame = nil end
		return
	end

	local bFormateur = net.ReadBool()
	if bFormateur then
		local n = net.ReadUInt(8)
		local t = {}
		for _ = 1, n do
			t[#t + 1] = {
				ply     = net.ReadEntity(),
				stepIdx = net.ReadUInt(3),
				visited = net.ReadUInt(4),
				total   = net.ReadUInt(4),
			}
		end
		state = { isFormateur = true, trainees = t }
	else
		state = {
			isFormateur = false,
			stepIdx     = net.ReadUInt(3),
			visited     = net.ReadUInt(4),
			total       = net.ReadUInt(4),
			other       = net.ReadEntity(),
		}
	end
	if not IsValid(frame) then frame = vgui.Create("LZYFormationHUD") end
	if frame.ApplyState then frame:ApplyState() end
end)

net.Receive("LZY:Formation:AskNote", function()
	OpenNoteUI()
end)

-- ── Drapeaux « en formation » (tous les joueurs) ─────────────────────────────────
-- Poussés par le serveur à chaque début/fin (+ rattrapage à la connexion). Servent
-- au menu C : cacher « Valider la formation (étape) » sur une cible sans formation
-- (08/16, demande user). Clé = entité ; purge quand elle disparaît.
local tFormationFlags = {}

net.Receive("LZY:Formation:Flag", function()
	local ent = net.ReadEntity()
	local bOn = net.ReadBool()
	if not IsValid(ent) then return end
	tFormationFlags[ent] = bOn or nil
end)

hook.Add("EntityRemoved", "LZY_Formation::FlagPurge", function(ent)
	if tFormationFlags[ent] then tFormationFlags[ent] = nil end
end)

-- Helper GLOBAL consommé par le CanRun de sh_formation_property (client).
function LZY_FORMATION_IsInFormation(ent)
	return IsValid(ent) and tFormationFlags[ent] == true
end
