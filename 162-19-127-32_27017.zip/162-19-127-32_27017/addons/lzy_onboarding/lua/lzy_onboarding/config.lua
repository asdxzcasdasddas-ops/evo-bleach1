-- "addons\\lzy_onboarding\\lua\\lzy_onboarding\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_ONBOARDING_CONFIG = LZY_ONBOARDING_CONFIG or {}

LZY_ONBOARDING_CONFIG.InstructorFactionRank = 6

-- Un joueur dont le grade de faction DÉPASSE cette valeur n'a PAS besoin d'onboarding
-- -> la logique formateur le skip, et le filet de sécurité ne le relance pas.
-- 6 -> 1 (report user 21/08 : « un grade 2 ne doit pas avoir le pop-up trouve un
-- formateur »). Le grade 1 est l'ASPIRANT ; dès le grade 2 le joueur est recruté, sa
-- formation est finie par définition. À 6, tout recruté sous le grade formateur restait
-- éligible : suffisait d'une promotion hors du parcours de formation (bouton du panneau
-- faction, SAM) pour que `boarded` reste à 0 et que le filet lui repousse le pop-up
-- toutes les 20 s.
LZY_ONBOARDING_CONFIG.SkipOnboardingAboveRank = 1

-- ══════════════════════════════════════════════════════════════════════════════
-- FORMATION DES ASPIRANTS : elle ne vit PLUS ici. La 1re version (10/08 matin) était
-- une action du menu C portée par cet addon ; remplacée le jour même (demande user)
-- par la vue réduite de l'onglet gestion du LIVRE DE FACTION — voir lzy_faction :
-- config.lua (FormateurGrantRank), net.lua (FormerAspirant + coche SetFormateur,
-- whitelist par les grade 10+), vgui/cl_main.lua (CreateFormationUI). Ce fichier ne
-- garde que le guidage
-- d'onboarding (InstructorFactionRank ci-dessus) et les balises ci-dessous.
-- ══════════════════════════════════════════════════════════════════════════════

-- ══════════════════════════════════════════════════════════════════════════════
-- BALISES DE DIVISION / ORDRE (demande user 2026-08-10)
--
-- « Une fois que tu as terminé le fait de prendre ton katana, il faudrait que ça te
--   ping en permanence sur la map les endroits où sont les ordres / divisions en
--   fonction de ta map, tant que tu es grade 1. »
--
-- La suite naturelle de la formation : le nouveau a son arme, il doit maintenant
-- trouver une division — d'où sa place ici et pas dans un addon séparé.
-- ══════════════════════════════════════════════════════════════════════════════
local PING = {}
LZY_ONBOARDING_CONFIG.DivisionPing = PING

-- Grade EXACT auquel les balises s'affichent. Égalité STRICTE, pas « <= » : le grade
-- vaut 0 tant que le bag réseau du perso n'est pas arrivé, et on n'affiche rien là.
PING.ShowAtRank = 1

-- Bornes d'index de division parcourues (NWInt "FactionDivision").
-- ⚠️ index 1 = « Aucune ». Sur Hueco, EVO_DivisionSpawn.Spawns possède bien une entrée
-- [1] (zone « sans ordre » de Las Noches) : la borne basse à 2 est ce qui l'exclut.
PING.FirstIndex = 2
PING.LastIndex  = 6

-- Rôle affiché sous le nom (sans lui, « DIVISION 12 » ne dit rien à un débutant).
-- SOURCE UNIQUE : LZY_FACTION_CONFIG.DivisionSpecialty (lzy_faction). Ordre garanti :
-- les autoruns se chargent par NOM DE FICHIER, et lzy_faction_loader.lua passe avant
-- lzy_onboarding_loader.lua. ⚠️ Renommer un de ces deux loaders casserait ce snapshot
-- en silence (PING.Roles = {}). Ne PAS redéclarer de table ici : les
-- consommateurs (balises + menu « Former ce joueur ») ont leur propre repli d'affichage
-- si la clé manque.
PING.Roles = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionSpecialty) or {}

-- SOURCE UNIQUE des positions : EVO_ZoneBanner.GetDivisionPos (centres des bandeaux
-- de caserne / ordre). Rien n'est recopié : déplacer un centre dans sh_zone_banner
-- déplace le bandeau ET la balise. Le spawn de division (EVO_DivisionSpawn.Spawns)
-- n'est qu'un repli si le bandeau n'a pas d'entrée `div` pour cet index.
--
-- OVERRIDE si une balise tombe mal (cour fermée, derrière un mur) : ajouter la position
-- ici plutôt que de toucher au bandeau. Relevé : `getpos` en jeu donne les YEUX,
-- retirer 64 au z pour obtenir les pieds. Ne surcharge QUE la division listée.
PING.PosOverride = {
	-- ["rp_seireitei_v1"] = {
	--     [6] = Vector(0, 0, 0), -- Division 11
	-- },
}

-- Pose monde d'une balise (map, index de division). Ordre : override local, puis
-- centre du bandeau, puis spawn de division (repli). Appelé au runtime : les deux
-- addons sources peuvent ne pas être chargés au parse de ce fichier.
function PING.WorldPos(sMap, nIdx)
	sMap = sMap or game.GetMap()
	local ov = PING.PosOverride and PING.PosOverride[sMap]
	if ov and ov[nIdx] then return ov[nIdx] end
	local fn = EVO_ZoneBanner and EVO_ZoneBanner.GetDivisionPos
	local v  = fn and fn(sMap, nIdx)
	if v then return v end
	local t    = EVO_DivisionSpawn and EVO_DivisionSpawn.Spawns and EVO_DivisionSpawn.Spawns[sMap]
	local spot = t and t[nIdx]
	return spot and spot.pos
end

-- TABLEAU DE QUÊTES QUOTIDIENNES (demande user 2026-08-10) : le grade 1 voit aussi une
-- balise vers le tableau LE PLUS PROCHE, exactement dans les mêmes conditions que les
-- divisions. Positions lues dans NCM_QUETE.QUEST_BOARD_POSITIONS (config PARTAGÉE de
-- ncm_quete_system, donc déjà côté client) — rien n'est recopié ici non plus.
PING.ShowQuestBoard = true
PING.BoardRole      = "Quêtes quotidiennes"
PING.CarteRole      = "S'orienter"

-- Tableaux D'ENTRÉE pointés au grade 1 (demande user 10/08 : celui du spawn, pas le
-- plus proche). Indices dans les tables SOURCES : quete = NCM_QUETE.QUEST_BOARD_POSITIONS,
-- carte = SPAWNS d'evo_map/sv_map_spawn (via EVO_Map_BoardSpawns). ⚠️ Réordonner ces
-- listes là-bas décale ces indices. Index absent = repli « le plus proche » (quêtes).
PING.EntranceBoards = {
	["rp_seireitei_v1"] = { quete = 2, carte = 1 }, -- « Début du Seireitei » + tableau du spawn
	["hueco_mundo_v1"]  = { quete = 6, carte = 6 }, -- « ville arrancar » (entrée Las Noches), les 2
}

-- Hauteur de la balise au-dessus du point relevé (les poses sont au SOL).
PING.MarkerZ = 48

-- Dans ce rayon, le joueur EST arrivé -> la balise s'efface (sinon elle reste plantée
-- dans ses pieds pendant tout son passage à la caserne).
PING.HideRadius = 700

-- Période de recalcul de la liste visible. Le dessin, lui, tourne à chaque frame sur
-- le résultat mis en cache.
PING.Refresh = 0.25

-- Marges du rectangle sur lequel une balise hors-champ est rabattue (base 1920×1080).
-- ⚠️ Elles servent AUSSI de seuil « la balise est-elle à l'écran ». Les deux DOIVENT
-- rester égales : un seuil plus serré que le rectangle fait sauter la balise d'un bloc
-- entier au moment où elle bascule en mode bord.
PING.EdgeMarginX = 70
PING.EdgeMarginY = 95

-- Écart vertical minimum entre deux balises rabattues sur le bord.
-- INDISPENSABLE : le rabattement ne conserve que la DIRECTION, et les casernes sont
-- toutes à la même altitude -> sans écartement, 3 ou 4 balises se dessinent au même
-- pixel dès qu'elles sont dans le dos du joueur. Valeur = hauteur d'un bloc de bord
-- (nom + losange + distance), ~59 px en 1080p.
PING.EdgeMinGap = 60

-- ══════════════════════════════════════════════════════════════════════════════
-- FORMATION GUIDÉE PAR UN FORMATEUR (demande user 08/15)
--
-- Le formateur lance « Commencer la formation » sur un joueur (menu C). Il peut
-- encadrer PLUSIEURS élèves en parallèle (parcours indépendants). Chaque élève
-- suit des étapes SÉQUENTIELLES (présentation, carte du monde, Urahara Shop,
-- Maître d'Armes, tour des divisions/ordres). À la fin, l'élève NOTE son
-- formateur (1 à 5), et la note décide du coffre remis au formateur.
-- Une formation par PERSONNAGE (table lzy_formation_done) : pas de farm de coffres.
-- ══════════════════════════════════════════════════════════════════════════════
local FORM = {}
LZY_ONBOARDING_CONFIG.Formation = FORM

-- L'élève doit être EXACTEMENT à ce grade (08/16, demande user : « seulement les
-- personnages de grade 1 »). Égalité STRICTE comme PING.ShowAtRank : le grade vaut
-- 0 tant que le bag réseau du perso n'est pas arrivé, et on ne forme pas ça.
FORM.TraineeRank = 1

-- Distance max (unités) entre formateur et élève pour LANCER la formation.
FORM.StartDistance = 300

-- Plafond d'élèves simultanés par formateur. 0 = pas de limite.
FORM.MaxTrainees = 0

-- « Aller devant » : rayons d'arrivée. Divisions = même rayon que les balises de
-- grade 1 (PING.HideRadius) pour que balise et étape se valident au même endroit.
FORM.MaitreRadius   = 300
FORM.DivisionRadius = PING.HideRadius or 700

-- Filet : une formation abandonnée en cours de route s'annule seule au bout de N s.
FORM.MaxDuration = 1800

-- Coffre remis au formateur : TIRAGE PONDÉRÉ par la note de l'élève (08/16,
-- demande user « aléatoire mais la note donne plus de chances »). Une entrée
-- par note (1..5), poids relatifs (pas besoin de sommer 100) sur les ids
-- EVO_LOOT.Chests. Liste ORDONNÉE (pas un dict) : le tirage doit être
-- déterministe à parcourir, pairs() ne l'est pas.
FORM.ChestOddsByNote = {
	[1] = { { id = "coffre_rare", w = 75 }, { id = "coffre_epique", w = 22 }, { id = "coffre_legendaire", w = 3 } },
	[2] = { { id = "coffre_rare", w = 60 }, { id = "coffre_epique", w = 33 }, { id = "coffre_legendaire", w = 7 } },
	[3] = { { id = "coffre_rare", w = 45 }, { id = "coffre_epique", w = 42 }, { id = "coffre_legendaire", w = 13 } },
	[4] = { { id = "coffre_rare", w = 30 }, { id = "coffre_epique", w = 48 }, { id = "coffre_legendaire", w = 22 } },
	[5] = { { id = "coffre_rare", w = 15 }, { id = "coffre_epique", w = 50 }, { id = "coffre_legendaire", w = 35 } },
}

-- Note appliquée quand l'élève se déconnecte APRÈS avoir tout terminé mais sans
-- avoir noté : le formateur a fait le travail, il n'est pas puni par la déco.
FORM.AutoNoteOnDisconnect = 3

-- Déco de l'élève EN COURS de parcours : la formation est SUSPENDUE et reprend à
-- l'étape exacte s'il revient avec le MÊME personnage dans ce délai (s), tant que
-- le formateur est encore en ligne (il peut déjà encadrer d'autres élèves).
-- Au-delà : abandonnée.
FORM.ResumeGraceSeconds = 600
