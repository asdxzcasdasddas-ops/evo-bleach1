-- "addons\\lzy_onboarding\\lua\\lzy_onboarding\\cl_division_ping.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- cl_division_ping.lua — Balises permanentes vers les divisions / ordres
--
-- Visible UNIQUEMENT pour un joueur de grade 1 ayant reçu son arme au Maître d'Armes :
-- la formation est finie, il lui reste à trouver sa division.
--
-- POURQUOI PAS LE WAYPOINT DE QUÊTE : "NCM_Quete::UpdateWaypoint" n'a QU'UN SEUL slot
-- (3 scalaires écrasés à chaque envoi, ncm_quete/cl_quete.lua). Il en faut 5 en même
-- temps, et ce slot est déjà occupé chez un grade 1 (tracker de quête + rappel du
-- Maître d'Armes au niveau 9+). D'où un rendu séparé, purement additif.
--
-- PERF (règle projet : 0 alloc/frame en code chaud) : la liste visible — routage
-- téléporteur, distances, textes — est recalculée 4×/s ; la frame ne fait que du
-- ToScreen et du dessin sur des tables et des couleurs réutilisées en place.
-- ============================================================

local PING = LZY_ONBOARDING_CONFIG.DivisionPing

-- Couleurs DA, MUTÉES en place au dessin (fondu des balises hors-champ) : leur .a est
-- réécrit à chaque itération -> jamais de Color() par frame, et ne pas les partager.
local _cMark = Color(220, 225, 235, 255)   -- blanc cassé (même repère que le waypoint de quête)
local _cRole = Color(207, 68, 78, 255)     -- accent DA #cf444e
local _cDist = Color(170, 170, 180, 255)
local _cShad = Color(0, 0, 0, 180)

local _poly = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }

-- Conversion unités Source -> mètres : alignée sur la MAJORITÉ du dépôt (chasse au
-- Hollow evo_hollow_progression, flagcapture). ⚠️ Le waypoint de quête, lui, divise
-- par 50 : ~5 % d'écart d'affichage assumé entre les deux tant qu'il n'existe pas de
-- constante partagée unique.
local UNITS_PER_M = 52.5

local function BuildFonts()
	if not gCreateRespFont then return end
	-- Bebas Neue en weight 400 : le vrai TTF rend un faux-bold à 700 (cf. glibs).
	gCreateRespFont("LZY_DivPing_Name", "Bebas Neue", 21, 400)
	gCreateRespFont("LZY_DivPing_Role", "Roboto", 13, 600)
	gCreateRespFont("LZY_DivPing_Dist", "Roboto", 12, 500)
end
BuildFonts()
hook.Add("OnScreenSizeChanged", "LZY:Onboarding:DivPingRefont", BuildFonts)
-- glibs peut charger APRÈS cet addon : sans ce filet les polices n'existeraient jamais.
hook.Add("InitPostEntity", "LZY:Onboarding:DivPingFontsLate", BuildFonts)

-- ── DONNÉES SERVEUR ─────────────────────────────────────────────────────────────
-- _points = nil  -> pas encore demandé / à re-demander
-- _points = {}   -> le serveur a répondu « rien ici » (on arrête de demander)
-- _ptsFac : faction pour laquelle la demande/le cache vaut. Stampée à l'ENVOI de la
--           demande (pas à la réception) : si la faction change pendant que la
--           réponse est en vol, la comparaison du recalc invalide au tick suivant au
--           lieu de garder une réponse périmée étiquetée fraîche.
local _points = nil
local _askAt  = 0
local _ptsFac = nil
local _carte  = nil -- tableau de carte du monde de l'entrée (envoyé avec les divisions)

net.Receive("LZY:client:DivisionPoints", function()
	local n   = net.ReadUInt(4)
	local lp  = LocalPlayer()
	local out = {}

	for _ = 1, n do
		local idx  = net.ReadUInt(4)
		local vPos = net.ReadVector()
		-- Nom + rôle résolus UNE FOIS ici (et non à chaque recalcul) : DivisionName
		-- dépend de la faction, déjà connue puisqu'on n'a demandé qu'une fois éligible.
		-- string.upper alloue -> hors du chemin chaud.
		local sName = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName(lp, idx)) or ("Division " .. idx)
		out[#out + 1] = {
			idx  = idx,
			pos  = vPos + Vector(0, 0, PING.MarkerZ), -- les poses relevées sont au SOL
			name = string.upper(sName),
			role = PING.Roles[idx] or "",
		}
	end

	_points = out

	-- ⚠ Doit lire au même rang que l'écriture serveur (sv_division_ping).
	_carte = nil
	if net.ReadBool() then
		_carte = net.ReadVector() + Vector(0, 0, PING.MarkerZ)
	end
end)

-- ── ÉLIGIBILITÉ ─────────────────────────────────────────────────────────────────
-- Ce que le joueur DOIT être pour vouloir des balises.
local function Wants(lp)
	if lp:GetEvoNWInt("FactionRank", 0) ~= PING.ShowAtRank then return false end
	if not lp:GetEvoNWBool("NCM_WeaponTrainingDone", false) then return false end
	local fac = lp:GetEvoNWString("FactionName", "")
	if fac == "" or fac == "LostSoul" then return false end
	return true
end

-- Contextes où AUCUN HUD de guidage ne doit sortir, quel que soit le grade.
local function Blocked(lp)
	if not lp:Alive() then return true end                               -- le voile de mort n'est pas opaque
	if lp:GetEvoNWBool("InCharacterMenu", false) then return true end
	if LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu() then return true end
	if lp:GetEvoNWBool("EVO_StaffMode", false) then return true end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return true end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then return true end
	if lp:GetEvoNWBool("NCM_Instanced", false) then return true end
	return false
end

-- ── TABLEAUX DE QUÊTES QUOTIDIENNES ─────────────────────────────────────────────
-- Les positions vivent dans ncm_quete_system/sh_config_quete.lua, chargé des DEUX côtés
-- (AddCSLuaFile + include inconditionnels dans son loader) : le client les lit
-- directement, aucun net à ajouter.
--
-- _boards = nil   -> pas encore construit
-- _boards = false -> cette map n'a aucun tableau (on arrête de chercher)
local _boards = nil

-- Libellé mis en majuscules UNE fois (string.upper alloue ; le recalcul tourne 4×/s).
local _boardLabel = nil
local function BoardLabel()
	if not _boardLabel then
		_boardLabel = string.upper(
			(NCM_QUETE and NCM_QUETE.QUEST_BOARD and NCM_QUETE.QUEST_BOARD.label)
			or "Tableau des Quêtes")
	end
	return _boardLabel
end

local function BuildBoards()
	if _boards ~= nil then return _boards or nil end

	local t = NCM_QUETE and NCM_QUETE.QUEST_BOARD_POSITIONS
		and NCM_QUETE.QUEST_BOARD_POSITIONS[game.GetMap()]
	if not istable(t) then
		-- NCM_QUETE peut ne pas être encore chargé : ne pas marquer « aucun » trop tôt.
		if NCM_QUETE and NCM_QUETE.QUEST_BOARD_POSITIONS then _boards = false end
		return nil
	end

	-- Indexés comme la table SOURCE (PING.EntranceBoards pointe dedans par index).
	-- Snap au sol partagé avec le spawn du prop (même Z), fait une fois hors chemin chaud.
	local out, nOut = {}, 0
	for i = 1, #t do
		local v = istable(t[i]) and t[i].pos
		if v then
			local vGround = (NCM_QUETE.SnapBoardToGround and NCM_QUETE.SnapBoardToGround(v)) or v
			out[i] = vGround + Vector(0, 0, PING.MarkerZ)
			nOut = nOut + 1
		end
	end

	_boards = (nOut > 0) and out or false
	return _boards or nil
end

-- ── LISTE VISIBLE (recalculée 4×/s) ─────────────────────────────────────────────
local _draw     = {}
local _drawN    = 0
local _nextCalc = 0

-- Ajoute une entrée à la liste visible. Renvoie false si elle a été fusionnée dans un
-- marqueur de téléporteur déjà présent, ou si le joueur est déjà arrivé dessus.
-- sRole   : sous-titre quand on pointe la cible réelle.
-- sTpRole : sous-titre quand la cible est routée vers un téléporteur (le nom devient
--           « TÉLÉPORTEUR », afficher le rôle de la cible n'aurait plus de sens).
local function Push(vPly, nHideR, vRaw, sName, sRole, sTpRole)
	-- ROUTAGE PAR TÉLÉPORTEUR : même guidage que les quêtes. Sans ça, un grade 1 au
	-- Rukongai / dans le désert voit des flèches pointer à travers le sol vers un étage
	-- qu'aucun chemin à pied ne relie.
	local vTarget, bTP = vRaw, false
	if NCM_Quete_RouteWaypoint then
		local rPos, _, rTP = NCM_Quete_RouteWaypoint(vRaw, sName)
		if rPos then
			vTarget = rPos
			bTP     = rTP and true or false
		end
	end

	if bTP then
		-- Tout ce qui est à un autre étage route vers le MÊME pad : sans fusion on
		-- empilerait plusieurs marqueurs identiques au pixel près. Le tableau de quêtes
		-- se fond donc dans le marqueur « téléporteur » quand il est de l'autre côté —
		-- l'instruction est de toute façon la même, et il réapparaît à l'arrivée.
		for j = 1, _drawN do
			local e = _draw[j]
			if e.tp and e.pos:DistToSqr(vTarget) < 4096 then return false end -- 64 u
		end
	elseif vPly:DistToSqr(vTarget) < nHideR then
		return false -- déjà sur place : la balise n'a plus rien à dire
	end

	_drawN = _drawN + 1
	local e = _draw[_drawN]
	if not e then
		e = {}
		_draw[_drawN] = e
	end
	e.pos  = vTarget
	e.tp   = bTP
	e.name = bTP and "TÉLÉPORTEUR" or sName
	e.role = (bTP and sTpRole or sRole) or ""
	e.d    = vPly:Distance(vTarget)
	e.dist = math.floor(e.d / UNITS_PER_M) .. "m"
	return true
end

local function Rebuild(lp)
	_drawN = 0

	local vPly   = lp:GetPos()
	local nHideR = PING.HideRadius * PING.HideRadius

	-- Les deux blocs sont INDÉPENDANTS : une map peut avoir un tableau de quêtes sans
	-- divisions configurées (gm_construct), et un joueur en visite chez la faction d'en
	-- face ne reçoit aucune division mais garde le tableau.
	if _points and #_points > 0 then
		-- Mot de subdivision de SA faction : « Division » / « Ordre » (jamais en dur).
		-- Concaténé UNE fois par recalcul, pas une fois par balise.
		local sWord  = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionWord
			and LZY_FACTION_CONFIG.DivisionWord(lp)) or "Division"
		local sTpDiv = "vers les " .. sWord .. "s"

		for i = 1, #_points do
			local p = _points[i]
			Push(vPly, nHideR, p.pos, p.name, p.role, sTpDiv)
		end
	end

	-- MÊME règle « faction de la map » que les divisions (un visiteur adverse n'est
	-- guidé vers rien).
	local bFacOk
	do
		local mf     = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.MAP_FACTION
		local mapFac = mf and mf[game.GetMap()]
		bFacOk = not mapFac or lp:GetEvoNWString("FactionName", "") == mapFac
	end

	-- TABLEAU DE QUÊTES : celui de l'ENTRÉE (PING.EntranceBoards, demande user 10/08),
	-- repli « le plus proche » si non configuré (gm_construct).
	if PING.ShowQuestBoard and bFacOk then
		local tB = BuildBoards()
		if tB then
			local tEnt  = PING.EntranceBoards and PING.EntranceBoards[game.GetMap()]
			local vBest = tEnt and tEnt.quete and tB[tEnt.quete]
			if not vBest then
				local nBestD2 = math.huge
				for _, v in pairs(tB) do
					local d2 = vPly:DistToSqr(v)
					if d2 < nBestD2 then nBestD2, vBest = d2, v end
				end
			end
			if vBest then
				Push(vPly, nHideR, vBest, BoardLabel(), PING.BoardRole or "", "vers le tableau de quêtes")
			end
		end
	end

	-- TABLEAU DE CARTE DU MONDE de l'entrée (position envoyée par le serveur).
	if _carte and bFacOk then
		Push(vPly, nHideR, _carte, "CARTE DU MONDE", PING.CarteRole or "", "vers la carte du monde")
	end

	-- Le plus proche dessiné EN DERNIER -> il passe au-dessus des autres.
	-- Tri par INSERTION sur _drawN (7 max : 5 divisions + quêtes + carte) : table.sort
	-- trierait tout _draw, y compris les entrées recyclées au-delà de _drawN, et il
	-- faudrait donc les détruire à chaque passe — soit une table réallouée par balise, 4×/s.
	for i = 2, _drawN do
		local e = _draw[i]
		local j = i - 1
		while j >= 1 and _draw[j].d < e.d do
			_draw[j + 1] = _draw[j]
			j = j - 1
		end
		_draw[j + 1] = e
	end
end

-- Positions écran calculées en début de frame, puis écartées, puis dessinées.
-- Tableaux préalloués (réutilisés tels quels) : aucune allocation par frame.
local _mx, _my, _mOn = {}, {}, {}

-- Ramène un vecteur (depuis le centre écran) sur le bord d'un rect à marge.
local function EdgeClamp(dx, dy, hw, hh)
	local ax, ay = math.abs(dx), math.abs(dy)
	if ax < 0.001 and ay < 0.001 then return ScrW() * 0.5, ScrH() * 0.5 - hh end
	local s = math.min(ax > 0 and hw / ax or math.huge, ay > 0 and hh / ay or math.huge)
	return ScrW() * 0.5 + dx * s, ScrH() * 0.5 + dy * s
end

local function Diamond(x, y, s)
	_poly[1].x = x;     _poly[1].y = y - s
	_poly[2].x = x + s; _poly[2].y = y
	_poly[3].x = x;     _poly[3].y = y + s
	_poly[4].x = x - s; _poly[4].y = y
	draw.NoTexture()
	surface.DrawPoly(_poly)
end

hook.Add("HUDPaint", "LZY:Onboarding:DivPingDraw", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if not gRespX then return end -- glibs pas encore chargé (premières frames)

	local now = CurTime()
	if now >= _nextCalc then
		_nextCalc = now + PING.Refresh

		if Blocked(lp) or not Wants(lp) then
			_drawN = 0
		else
			-- INVALIDATION PAR COMPARAISON, au rythme du recalc (O(1), 4×/s) : la
			-- réponse serveur ne dépend que de (map, faction), et la map ne change pas
			-- sans reconnexion. Un hook FullApplied ne suffisait pas : un set_faction
			-- admin à chaud passe par les DELTAS, jamais par un Full, et laissait les
			-- balises de l'ancienne faction à l'écran. (Et surtout ne PAS invalider
			-- inconditionnellement sur FullApplied : il part 3× par chargement de perso,
			-- les re-demandes tombaient dans le throttle serveur -> balises absentes
			-- plusieurs secondes à chaque connexion.)
			local sFac = lp:GetEvoNWString("FactionName", "")
			if _ptsFac ~= nil and _ptsFac ~= sFac then
				_points = nil
				_ptsFac = nil
				_carte  = nil
			end
			if _points == nil and now >= _askAt then
				_askAt  = now + 6 -- borne les demandes si le serveur ne répond pas
				_ptsFac = sFac    -- stampé à l'ENVOI (cf. déclaration)
				-- netgate: edge -- _points nil latch + _askAt throttle (re-ask only when cache miss)
				net.Start("LZY:server:AskDivisionPoints")
				net.SendToServer()
			end
			Rebuild(lp)
		end
	end

	if _drawN == 0 then return end
	-- Gardes IMMÉDIATES : 0,25 s de balise fantôme se verrait par-dessus l'écran de
	-- mort et la sélection de personnage. Les autres contextes peuvent attendre.
	if not lp:Alive() then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end

	local RX, RY   = gRespX, gRespY
	local sw, sh   = ScrW(), ScrH()
	local mgx, mgy = RX(PING.EdgeMarginX), RY(PING.EdgeMarginY)
	local hw, hh   = sw * 0.5 - mgx, sh * 0.5 - mgy
	local nGap     = RY(PING.EdgeMinGap)

	-- ① PROJECTION. Le seuil « à l'écran » utilise EXACTEMENT les marges du rectangle
	-- de rabattement : avec un seuil plus serré, la balise sautait de plusieurs dizaines
	-- de pixels d'un coup au moment de basculer en mode bord.
	for i = 1, _drawN do
		local sc = _draw[i].pos:ToScreen()
		if sc.visible and sc.x >= mgx and sc.x <= sw - mgx
			and sc.y >= mgy and sc.y <= sh - mgy then
			_mx[i], _my[i], _mOn[i] = sc.x, sc.y, true
		else
			local dx, dy = sc.x - sw * 0.5, sc.y - sh * 0.5
			-- ToScreen renvoie des coordonnées MIROIR derrière la caméra.
			if not sc.visible then dx, dy = -dx, -dy end
			_mx[i], _my[i] = EdgeClamp(dx, dy, hw, hh)
			_mOn[i] = false
		end
	end

	-- ② ÉCARTEMENT des balises de bord. EdgeClamp ne conserve que la DIRECTION : comme
	-- les casernes sont toutes à la même altitude, la composante verticale est quasi
	-- nulle et TOUTES les balises hors-champ atterrissent au même point, à mi-hauteur
	-- du bord gauche ou droit. Sans cette passe, 3 ou 4 blocs de texte se superposent
	-- au pixel près dès que le joueur tourne le dos aux divisions.
	-- Glouton sur ≤ 5 entrées, dans l'ordre de tri (stable) -> pas de tremblement.
	for i = 2, _drawN do
		if not _mOn[i] then
			for j = 1, i - 1 do
				-- Seuil horizontal large (≈ largeur d'un libellé) : deux balises sur des
				-- bords OPPOSÉS ne se gênent pas et ne doivent pas être écartées.
				if not _mOn[j] and math.abs(_mx[i] - _mx[j]) < nGap * 2 then
					local d = _my[i] - _my[j]
					if math.abs(d) < nGap then
						_my[i] = _my[j] + (d < 0 and -nGap or nGap)
					end
				end
			end
			_my[i] = math.Clamp(_my[i], mgy, sh - mgy)
		end
	end

	-- ③ DESSIN.
	for i = 1, _drawN do
		local e      = _draw[i]
		local bOn    = _mOn[i]
		local mx, my = _mx[i], _my[i]
		local nAlpha = bOn and 255 or 165

		_cMark.a = nAlpha
		_cRole.a = nAlpha
		_cDist.a = nAlpha
		_cShad.a = math.floor(nAlpha * 0.7)

		local s = RY(8)
		surface.SetDrawColor(_cShad)
		Diamond(mx + 1, my + 1, s + 1)
		surface.SetDrawColor(e.tp and _cRole or _cMark)
		Diamond(mx, my, s)

		draw.SimpleTextOutlined(e.name, "LZY_DivPing_Name", mx, my - s - RY(6),
			_cMark, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, _cShad)

		-- Le rôle n'est affiché qu'à l'écran : au bord, les balises sont serrées les
		-- unes sous les autres, une 3e ligne les rendrait illisibles.
		local ty = my + s + RY(4)
		if bOn and e.role ~= "" then
			draw.SimpleTextOutlined(e.role, "LZY_DivPing_Role", mx, ty,
				_cRole, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, _cShad)
			ty = ty + RY(14)
		end
		draw.SimpleTextOutlined(e.dist, "LZY_DivPing_Dist", mx, ty,
			_cDist, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, _cShad)
	end
end)
