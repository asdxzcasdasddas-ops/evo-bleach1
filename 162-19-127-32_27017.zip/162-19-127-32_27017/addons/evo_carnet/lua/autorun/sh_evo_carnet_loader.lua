-- "addons\\evo_carnet\\lua\\autorun\\sh_evo_carnet_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Carnet de commande : commandes prépayées entre joueurs, par métier de craft.
EVO_CARNET = EVO_CARNET or {}

if SERVER then
	AddCSLuaFile("evo_carnet/sh_config.lua")
	AddCSLuaFile("evo_carnet/sh_catalog.lua")
	AddCSLuaFile("evo_carnet/cl_carnet.lua")
	include("evo_carnet/sh_config.lua")
	include("evo_carnet/sh_catalog.lua")
	include("evo_carnet/sv_carnet.lua")
else
	include("evo_carnet/sh_config.lua")
	include("evo_carnet/sh_catalog.lua")
	include("evo_carnet/cl_carnet.lua")
end
