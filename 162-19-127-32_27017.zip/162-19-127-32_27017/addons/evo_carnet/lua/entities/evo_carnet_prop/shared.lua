-- "addons\\evo_carnet\\lua\\entities\\evo_carnet_prop\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Carnet de commande"
ENT.Author = "Evo"
ENT.Category = "Evo"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.Model = "models/evo/props/items/evo_yr1lyd7hayljp/evo_7vuqmq8a3show.mdl"
