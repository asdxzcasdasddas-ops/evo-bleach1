-- "addons\\evo_carnet\\lua\\entities\\evo_carnet_prop\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("EVO_CarnetProp_Title", { font = "Bebas Neue", size = 26, weight = 700, extended = true })
surface.CreateFont("EVO_CarnetProp_Hint", { font = "Roboto", size = 14, weight = 500, extended = true })

ENT.RenderGroup = RENDERGROUP_BOTH

local RENDER_DIST_SQR = 2000 * 2000
local HINT_DIST_SQR = 160 * 160
local COL_LABEL = Color(255, 255, 255, 200)
local COL_OUTLINE = Color(0, 0, 0, 200)

function ENT:Initialize() end
function ENT:Draw() self:DrawModel() end

function ENT:DrawTranslucent()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	local vPos = self:GetPos()
	local d2 = ply:GetPos():DistToSqr(vPos)
	if d2 > RENDER_DIST_SQR then return end

	local vTextPos = vPos + Vector(0, 0, 120)
	local dir = (EyePos() - vTextPos):Angle()
	local angBB = Angle(0, dir.y, 0)
	angBB:RotateAroundAxis(angBB:Right(), 90)
	angBB:RotateAroundAxis(angBB:Up(), -90)
	angBB:RotateAroundAxis(angBB:Right(), 180)

	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		-- Style invite partage (0.13 = meme hauteur de titre qu'avant) : touche a portee seulement.
		cam.Start3D2D(vTextPos, angBB, 0.13)
			EVO_ZonePrompt.Row(0, "Carnet de commande", d2 <= HINT_DIST_SQR and "Consulter", "E", "point")
		cam.End3D2D()
		return
	end
	cam.Start3D2D(vTextPos, angBB, 0.25)
		draw.SimpleTextOutlined("Carnet de commande", "EVO_CarnetProp_Title", 0, 0,
			COL_LABEL, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, COL_OUTLINE)
		if d2 <= HINT_DIST_SQR then
			draw.SimpleTextOutlined("Appuyer sur E", "EVO_CarnetProp_Hint", 0, 32,
				color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, COL_OUTLINE)
		end
	cam.End3D2D()
end
