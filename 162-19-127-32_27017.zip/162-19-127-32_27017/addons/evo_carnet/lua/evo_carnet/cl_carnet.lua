-- "addons\\evo_carnet\\lua\\evo_carnet\\cl_carnet.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- UI du Carnet de commande. Kit EVO_UI (carte, rangées, champ). Le serveur reste juge.
EVO_CARNET = EVO_CARNET or {}

local frame
local view = { faction = "", metiers = {}, orders = {} }
local tab = "new"
local selMetier = "assassin"
local selItem = nil

local STATUS = {
	open = "DISPONIBLE",
	claimed = "PRISE",
	ready = "À RETIRER",
}

local function rx(n) return gRespX and gRespX(n) or n end
local function ry(n) return gRespY and gRespY(n) or n end

local function readView()
	view.faction = net.ReadString()
	view.metiers = {}
	local nM = net.ReadUInt(3)
	for _ = 1, nM do view.metiers[#view.metiers + 1] = net.ReadString() end
	view.orders = {}
	local n = net.ReadUInt(16)
	for _ = 1, n do
		view.orders[#view.orders + 1] = {
			id = net.ReadString(),
			status = net.ReadString(),
			metier = net.ReadString(),
			itemId = net.ReadString(),
			itemName = net.ReadString(),
			qty = net.ReadUInt(8),
			price = net.ReadUInt(32),
			buyerName = net.ReadString(),
			crafterName = net.ReadString(),
			mine = net.ReadBool(),
			mineClaim = net.ReadBool(),
		}
	end
end

local function hasMetier(id)
	for _, m in ipairs(view.metiers) do
		if m == id then return true end
	end
	return false
end

local function sendAct(sNet, id)
	net.Start(sNet)
	net.WriteString(id)
	net.SendToServer()
end

local function textLine(sText, sFont, x, y, col, ax, ay)
	if MUGEN and MUGEN.DrawMoneyLine then
		MUGEN.DrawMoneyLine(sText, sFont, x, y, col, ax, ay)
	else
		draw.SimpleText(sText, sFont, x, y, col, ax, ay)
	end
end

-- Même champ que EVO_UI.QtyPicker : plaque à coin coupé, texte Bebas, caret accent.
local function cutEntry(parent, x, y, w, h, placeholder, numeric)
	local col = EVO_UI.Col
	local bg = vgui.Create("DPanel", parent)
	bg:SetPos(x, y)
	bg:SetSize(w, h)
	bg.Paint = function(s, ew, eh)
		EVO_UI.PaintCut(0, 0, ew, eh, Color(24, 26, 31, 235), ry(6))
		if IsValid(s.entry) and s.entry:IsEditing() then
			surface.SetDrawColor(col.accent)
			surface.DrawRect(rx(8), eh - ry(2), ew - rx(16), ry(2))
		end
	end
	local entry = vgui.Create("DTextEntry", bg)
	entry:Dock(FILL)
	entry:DockMargin(rx(8), ry(2), rx(8), ry(2))
	entry:SetFont("EVO_UI_Item")
	entry:SetTextColor(col.title)
	entry:SetCursorColor(col.title)
	entry:SetPaintBackground(false)
	entry:SetDrawLanguageID(false)
	entry:SetUpdateOnType(true)
	if numeric then entry:SetNumeric(true) end
	entry.Paint = function(s, _, eh)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText(placeholder or "", "EVO_UI_Item", 0, eh / 2, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			s:DrawTextEntryText(col.title, col.accent, col.title)
		end
	end
	bg.entry = entry
	bg.OnMousePressed = function() entry:RequestFocus() end
	return entry
end

-- Liseré autour des champs (quantité + prix). Accent tant que le champ est édité.
local function borderFields(parent)
	for _, pnl in ipairs(parent:GetChildren()) do
		local entry
		for _, ch in ipairs(pnl:GetChildren()) do
			if ch.DrawTextEntryText and ch.IsEditing then entry = ch break end
		end
		if not (entry and not pnl._evoFieldBorder) then continue end
		pnl._evoFieldBorder = true
		local old = pnl.Paint
		pnl.Paint = function(s, w, h)
			if old then old(s, w, h) end
			local focused = IsValid(entry) and entry:IsEditing()
			local pts = EVO_UI.CutPoints(1, 1, math.max(2, w - 2), math.max(2, h - 2), ry(6))
			local c = focused and EVO_UI.Col.accent or Color(255, 255, 255, 70)
			EVO_UI.OutlineCut(pts, c)
			EVO_UI.OutlineCut(pts, c)
		end
	end
end

local function itemInfo(sId)
	local cat = EVO_CARNET.FindItem(selMetier, sId)
	local def = ITEMS and ITEMS[sId]
	return {
		name = (def and def.name) or (cat and cat.name) or sId,
		desc = (def and (def.description or def.desc)) or "",
		def = def,
	}
end

local function notifyLocal(msg, err)
	if MUGEN and MUGEN.AddNotification then
		MUGEN.AddNotification(msg, err and NOTIFY_ERROR or NOTIFY_GENERIC, 4)
	else
		chat.AddText(EVO_UI.Col.accent, "[Carnet] ", color_white, msg)
	end
end

local function fillDetail(pnl, sId)
	if not IsValid(pnl) then return end
	pnl:Clear()
	pnl.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, Color(18, 19, 23, 245), ry(12))
		local pts = EVO_UI.CutPoints(1, 1, w - 2, h - 2, ry(12))
		EVO_UI.OutlineCut(pts, Color(255, 255, 255, 40))
	end
	if not sId then
		local hint = vgui.Create("DLabel", pnl)
		hint:Dock(FILL)
		hint:DockMargin(rx(16), ry(16), rx(16), ry(16))
		hint:SetFont("EVO_UI_Item")
		hint:SetTextColor(EVO_UI.Col.dim)
		hint:SetWrap(true)
		hint:SetText("Choisissez un objet pour voir sa fiche.")
		return
	end
	local info = itemInfo(sId)
	local preview = vgui.Create("DPanel", pnl)
	preview:Dock(TOP)
	preview:SetTall(ry(180))
	preview:DockMargin(rx(12), ry(12), rx(12), 0)
	preview.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, Color(10, 11, 14, 255), ry(8))
	end
	if info.def and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(info.def) then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(preview, info.def, 28, nil, 1)
	end
	local name = vgui.Create("DLabel", pnl)
	name:Dock(TOP)
	name:DockMargin(rx(14), ry(12), rx(14), 0)
	name:SetTall(ry(28))
	name:SetFont("EVO_UI_Item")
	name:SetTextColor(EVO_UI.Col.title)
	name:SetText(info.name)
	local desc = vgui.Create("DLabel", pnl)
	desc:Dock(FILL)
	desc:DockMargin(rx(14), ry(6), rx(14), ry(14))
	desc:SetFont("EVO_UI_Sub")
	desc:SetTextColor(EVO_UI.Col.muted)
	desc:SetWrap(true)
	desc:SetContentAlignment(7)
	desc:SetText(info.desc ~= "" and info.desc or "Aucune description.")
end

local function confirmPublish(sName, nQty, nPrice, fn)
	if not IsValid(frame) then return end
	local overlay = vgui.Create("DPanel", frame)
	overlay:SetSize(ScrW(), ScrH())
	overlay:SetPos(0, 0)
	overlay:MakePopup()
	overlay.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 170)
		surface.DrawRect(0, 0, w, h)
	end
	local cw, ch = rx(460), ry(210)
	local card = vgui.Create("DPanel", overlay)
	card:SetSize(cw, ch)
	card:Center()
	card.Paint = function(_, w, h)
		EVO_UI.PaintCard(w, h, 1, ry(12), "none")
		draw.SimpleText("PUBLIER LA COMMANDE", "EVO_UI_Header", rx(22), ry(28), EVO_UI.Col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		textLine(string.format("%s  x%d   ·   %d ¥", sName, nQty, nPrice), "EVO_UI_Item", rx(22), ry(78), EVO_UI.Col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("L'argent est débité immédiatement.", "EVO_UI_Sub", rx(22), ry(108), EVO_UI.Col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	EVO_UI.ActionButton(card, rx(22), ch - ry(56), rx(180), ry(36), "ANNULER", Color(40, 42, 48), function()
		if IsValid(overlay) then overlay:Remove() end
	end)
	EVO_UI.ActionButton(card, cw - rx(202), ch - ry(56), rx(180), ry(36), "CONFIRMER", EVO_UI.Col.accent, function()
		if IsValid(overlay) then overlay:Remove() end
		if fn then fn() end
	end)
end

local function snapshot()
	if not IsValid(frame) then return end
	if frame._getQty then frame._qty = frame._getQty() end
	if IsValid(frame._price) then frame._priceText = frame._price:GetValue() end
end

local function rebuild()
	if not IsValid(frame) then return end
	local body = frame.Body
	if not IsValid(body) then return end
	snapshot()
	body:Clear()
	frame._getQty = nil
	frame._price = nil
	local col = EVO_UI.Col

	if tab == "new" then
		local pad = rx(12)
		local leftW = rx(200)
		local bottomH = ry(78)
		local bh = body:GetTall()
		local y = pad
		for _, m in ipairs(EVO_CARNET.Metiers) do
			local id = m.id
			local b = EVO_UI.RowButton(body, pad, y, leftW, ry(40), { label = string.upper(m.label) }, function()
				if selMetier == id then return end
				selMetier = id
				selItem = nil
				rebuild()
			end)
			b:SetSel(selMetier == id)
			y = y + ry(44)
		end

		local cardW = rx(270)
		local listX = pad + leftW + rx(12)
		local listH = bh - bottomH - pad * 2
		local listW = body:GetWide() - listX - cardW - pad - rx(8)
		local scroll = vgui.Create("DScrollPanel", body)
		scroll:SetPos(listX, pad)
		scroll:SetSize(math.max(rx(160), listW), listH)
		EVO_UI.StyleScrollBar(scroll)
		local detail = vgui.Create("DPanel", body)
		detail:SetPos(listX + scroll:GetWide() + rx(8), pad)
		detail:SetSize(cardW, listH)
		frame.Detail = detail
		fillDetail(detail, selItem)
		local rowW = scroll:GetWide() - rx(8)
		for _, it in ipairs(EVO_CARNET.Catalog(selMetier)) do
			local holder = vgui.Create("DPanel", scroll)
			holder:Dock(TOP)
			holder:SetTall(ry(36))
			holder:DockMargin(0, 0, rx(8), ry(4))
			holder.Paint = function() end
			local itemId = it.id
			local b = EVO_UI.RowButton(holder, 0, 0, rowW, ry(36), { label = it.name }, function(s)
				selItem = itemId
				local canvas = scroll:GetCanvas()
				if IsValid(canvas) then
					for _, child in ipairs(canvas:GetChildren()) do
						local btn = child:GetChildren()[1]
						if IsValid(btn) and btn.SetSel then btn:SetSel(btn._itemId == selItem) end
					end
				end
				s:SetSel(true)
				fillDetail(frame.Detail, selItem)
			end)
			b._itemId = itemId
			b:SetSel(selItem == itemId)
		end

		local by = bh - bottomH + ry(4)
		local qtyW = rx(280)
		frame._getQty = EVO_UI.QtyPicker(body, pad + leftW + rx(12), by, qtyW, ry(32), EVO_CARNET.QtyMax, frame._qty or 1)

		local priceX = pad + leftW + rx(12) + qtyW + rx(16)
		local priceLbl = vgui.Create("DLabel", body)
		priceLbl:SetPos(priceX, by)
		priceLbl:SetSize(rx(160), ry(20))
		priceLbl:SetFont("Bebas Neue:22")
		priceLbl:SetTextColor(col.muted)
		priceLbl:SetText("PRIX")
		local price = cutEntry(body, priceX, by + ry(26), rx(160), ry(26), "¥", true)
		price:SetValue(tostring(frame._priceText or ""))
		frame._price = price
		borderFields(body)

		EVO_UI.ActionButton(body, body:GetWide() - rx(200) - pad, by + ry(22), rx(200), ry(36), "PUBLIER", col.accent, function()
			if not selItem then
				notifyLocal("Choisissez un objet.", true)
				return
			end
			local nPrice = math.floor(tonumber(price:GetValue()) or 0)
			local nQty = math.floor(tonumber(frame._getQty and frame._getQty() or 1) or 1)
			if nPrice < EVO_CARNET.PriceMin or nPrice > EVO_CARNET.PriceMax then
				notifyLocal("Prix invalide.", true)
				return
			end
			if (LocalPlayer():GetEvoNWInt("Money", 0) or 0) < nPrice then
				notifyLocal("Pas assez d'argent.", true)
				return
			end
			local info = itemInfo(selItem)
			local sMetier, sItem = selMetier, selItem
			confirmPublish(info.name, nQty, nPrice, function()
				net.Start("EVO:Carnet:Create")
				net.WriteString(sMetier)
				net.WriteString(sItem)
				net.WriteUInt(math.Clamp(nQty, 1, 255), 8)
				net.WriteUInt(math.max(0, nPrice), 32)
				net.SendToServer()
				notifyLocal("Commande publiée.")
			end)
		end)
		return
	end

	local scroll = vgui.Create("DScrollPanel", body)
	scroll:Dock(FILL)
	scroll:DockMargin(rx(8), ry(8), rx(8), ry(8))
	EVO_UI.StyleScrollBar(scroll)
	local shown = 0
	for _, o in ipairs(view.orders) do
		local show = false
		if tab == "mine" then show = o.mine
		elseif tab == "job" then show = (not o.mine) and (o.status == "open" or o.mineClaim) end
		if not show then continue end
		shown = shown + 1
		local order = o
		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(ry(64))
		row:DockMargin(0, 0, rx(8), ry(6))
		row._acts = {}
		row.Paint = function(_, w, h)
			local hf = EVO_UI.HoverFrac(row, 10)
			if hf > 0.01 then
				surface.SetDrawColor(ColorAlpha(col.accent, 18 * hf))
				surface.DrawRect(0, 0, w, h)
			end
			surface.SetDrawColor(ColorAlpha(col.divider, 45))
			surface.DrawRect(rx(2), h - 1, w - rx(4), 1)
			draw.SimpleText(order.itemName .. "  x" .. order.qty, "EVO_UI_Item", rx(14), ry(18), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local who = order.mine and "Pour vous" or ("De " .. order.buyerName)
			if order.mineClaim then who = "Prise par vous" end
			local sub = string.format("%s   ·   %s   ·   %s   ·   %d ¥",
				STATUS[order.status] or order.status, EVO_CARNET.MetierLabel(order.metier), who, order.price)
			textLine(sub, "EVO_UI_Sub", rx(14), ry(42), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		row.PerformLayout = function(s, w, h)
			local x = w - rx(8)
			for i = #s._acts, 1, -1 do
				local b = s._acts[i]
				if IsValid(b) then
					x = x - b:GetWide()
					b:SetPos(x, math.floor((h - b:GetTall()) / 2))
					x = x - rx(8)
				end
			end
		end
		local function act(label, fill, fn)
			local b = EVO_UI.ActionButton(row, 0, 0, rx(108), ry(32), label, fill, fn)
			row._acts[#row._acts + 1] = b
		end
		if order.mine and order.status == "open" then
			act("ANNULER", col.red, function() sendAct("EVO:Carnet:Cancel", order.id) end)
		elseif order.mine and order.status == "ready" then
			act("RETIRER", col.green, function() sendAct("EVO:Carnet:Withdraw", order.id) end)
		elseif order.status == "open" and not order.mine and hasMetier(order.metier) then
			act("PRENDRE", col.green, function() sendAct("EVO:Carnet:Claim", order.id) end)
		elseif order.mineClaim and order.status == "claimed" then
			act("DÉPOSER", col.green, function() sendAct("EVO:Carnet:Deliver", order.id) end)
			act("LÂCHER", col.red, function() sendAct("EVO:Carnet:Abandon", order.id) end)
		end
	end
	if shown == 0 then
		local empty = vgui.Create("DLabel", body)
		empty:SetPos(rx(20), ry(20))
		empty:SetSize(rx(480), ry(24))
		empty:SetFont("EVO_UI_Item")
		empty:SetTextColor(col.muted)
		empty:SetText(tab == "mine" and "Aucune commande en cours." or "Aucune commande pour vos métiers.")
	end
end

local function tabBtn(parent, x, y, w, h, id, label)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(x, y)
	b:SetSize(w, h)
	b:SetCursor("hand")
	b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
	b.Paint = function(s, bw, bh)
		local on = tab == id
		local cut = ry(8)
		if on then
			EVO_UI.PaintCut(0, 0, bw, bh, EVO_UI.Col.accent, cut, "br")
			draw.SimpleText(label, "EVO_UI_Item", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			EVO_UI.PaintCut(0, 0, bw, bh, Color(24, 26, 31, 235), cut, "br")
			local hf = EVO_UI.HoverFrac(s, 10)
			if hf > 0.02 then
				EVO_UI.HoverOutline(bw, bh, ColorAlpha(EVO_UI.Col.accent, 220 * hf), cut, "br")
			end
			draw.SimpleText(label, "EVO_UI_Item", bw / 2, bh / 2, EVO_UI.Col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	b.DoClick = function()
		surface.PlaySound(EVO_UI.SndClick)
		if tab == id then return end
		tab = id
		rebuild()
	end
end

local function openUI()
	if not EVO_UI then return end
	if EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	if IsValid(frame) then frame:Remove() end
	local back
	back = EVO_UI.Backdrop(function()
		if IsValid(back) then back:Remove() end
	end)
	frame = back

	local dw, dh = 1100, 680
	local card = vgui.Create("DPanel", back)
	card:SetSize(rx(dw), ry(dh))
	card:Center()
	card.Paint = function(_, w, h)
		EVO_UI.PaintCard(w, h, 1, ry(16), "diag")
		EVO_UI.Header(w, "CARNET DE COMMANDE", view.faction or "", 1)
		EVO_UI.FooterHints(w, h, "Vous payez la commande. Un métier de votre faction livre l'objet et encaisse. Vous le retirez ici.", { { key = "ESC", label = "FERMER" } })
	end
	EVO_UI.CloseButton(card, dw, function()
		if IsValid(back) then back:Remove() end
	end)

	local tabs = {
		{ id = "new", label = "NOUVELLE" },
		{ id = "mine", label = "MES COMMANDES" },
		{ id = "job", label = "À RÉALISER" },
	}
	local tabY = ry(72)
	local tabW = rx(200)
	for i, t in ipairs(tabs) do
		tabBtn(card, rx(26) + (i - 1) * (tabW + rx(10)), tabY, tabW, ry(32), t.id, t.label)
	end

	local body = vgui.Create("DPanel", card)
	body:SetPos(rx(14), ry(116))
	body:SetSize(card:GetWide() - rx(28), card:GetTall() - ry(116) - ry(44))
	body.Paint = function() end
	frame.Body = body
	rebuild()
end

net.Receive("EVO:Carnet:Open", function()
	readView()
	openUI()
end)

net.Receive("EVO:Carnet:Sync", function()
	readView()
	if IsValid(frame) then rebuild() end
end)
