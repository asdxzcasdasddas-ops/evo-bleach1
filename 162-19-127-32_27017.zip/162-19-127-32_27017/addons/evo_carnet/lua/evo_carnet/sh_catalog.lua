-- "addons\\evo_carnet\\lua\\evo_carnet\\sh_catalog.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Liste partagée des objets commandables. Le serveur revalide chaque id.
EVO_CARNET = EVO_CARNET or {}

local function add(out, sId, sName)
	if not isstring(sId) or sId == "" then return end
	out[#out + 1] = { id = sId, name = sName or sId }
end

local function starName(sName, nStar)
	if (nStar or 1) <= 1 then return sName end
	return sName .. " " .. nStar .. "★"
end

function EVO_CARNET.Catalog(sMetier)
	local out = {}
	if sMetier == "assassin" then
		local list = EVO_CRAFT and EVO_CRAFT.AssassinGear
		if not list then return out end
		for _, g in ipairs(list) do
			if g.kind ~= "materiau" then add(out, g.key, g.name) end
		end
		return out
	end

	local hub = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub
	if not hub then return out end

	if sMetier == "soin" then
		for _, r in ipairs(hub.MedRecipes or {}) do
			if EVO_SCIENCE.MedStarrable and EVO_SCIENCE.MedStarrable(r.id) then
				for n = 1, 3 do
					add(out, EVO_SCIENCE.MedStarId(r.id, n), starName(r.sName, n))
				end
			else
				add(out, r.id, r.sName)
			end
		end
		add(out, "masque_medical_arr", "Masque médical (Arrancar)")
		return out
	end

	if sMetier == "science" then
		for _, r in ipairs(hub.PotionRecipes or {}) do
			if EVO_SCIENCE.RecipeHasStars and EVO_SCIENCE.RecipeHasStars(r) then
				for n = 1, 3 do
					add(out, EVO_SCIENCE.PotionStarResult(r, n), starName(r.sName, n))
				end
			else
				add(out, r.sResult or ("potion_" .. r.id), r.sName)
			end
		end
		add(out, "masque_medical_arr", "Masque médical (Arrancar)")
		return out
	end

	return out
end

function EVO_CARNET.FindItem(sMetier, sItemId)
	for _, it in ipairs(EVO_CARNET.Catalog(sMetier)) do
		if it.id == sItemId then return it end
	end
	return nil
end
