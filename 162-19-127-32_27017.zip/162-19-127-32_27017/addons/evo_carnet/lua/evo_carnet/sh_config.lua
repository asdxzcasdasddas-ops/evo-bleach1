-- "addons\\evo_carnet\\lua\\evo_carnet\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
EVO_CARNET = EVO_CARNET or {}

EVO_CARNET.PriceMin = 1
EVO_CARNET.PriceMax = 1000000
EVO_CARNET.QtyMax = 10
EVO_CARNET.MaxActive = 8

-- Même modèle que le tableau des quêtes (repli si ncm_quete n'est pas chargé).
EVO_CARNET.Model = "models/evo/props/items/evo_yr1lyd7hayljp/evo_7vuqmq8a3show.mdl"

function EVO_CARNET.ModelFor(map)
	local cfg = NCM_QUETE and NCM_QUETE.QUEST_BOARD
	map = map or game.GetMap()
	if cfg then
		local byMap = cfg.modelByMap and cfg.modelByMap[map]
		if isstring(byMap) and byMap ~= "" then return byMap end
		if isstring(cfg.model) and cfg.model ~= "" then return cfg.model end
	end
	return EVO_CARNET.Model
end

EVO_CARNET.Metiers = {
	{ id = "assassin", label = "Assassin" },
	{ id = "soin",     label = "Médecin" },
	{ id = "science",  label = "Scientifique" },
}

EVO_CARNET.Spawns = EVO_CARNET.Spawns or {}

function EVO_CARNET.MetierLabel(sId)
	for _, m in ipairs(EVO_CARNET.Metiers) do
		if m.id == sId then return m.label end
	end
	return sId
end

function EVO_CARNET.MetierValid(sId)
	return EVO_CARNET.MetierLabel(sId) ~= sId or sId == "assassin" or sId == "soin" or sId == "science"
end
