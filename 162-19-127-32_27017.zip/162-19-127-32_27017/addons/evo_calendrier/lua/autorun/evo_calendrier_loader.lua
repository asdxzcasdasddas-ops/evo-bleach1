-- "addons\\evo_calendrier\\lua\\autorun\\evo_calendrier_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CALENDRIER — calendrier des événements d'animation (loader).
-- RÉSERVÉ aux ANIMATEURS / admins / superadmins (PAS accessible aux joueurs) : gate IsAnimator
-- client + serveur sur TOUT (ouverture, lecture, inscription, création). Les "inscrits" sont
-- donc uniquement des animateurs. Rappel "préparez-vous" 15 min avant à l'hôte + aux inscrits.
-- Stockage CROSS-SERVEUR via MySQL partagée (MUGEN.Query) -> events communs Seireitei + Hueco.
-- ============================================================================

if SERVER then
    AddCSLuaFile("evo_calendrier/sh_config.lua")
    AddCSLuaFile("evo_calendrier/cl_main.lua")
    include("evo_calendrier/sh_config.lua")
    include("evo_calendrier/sv_main.lua")
    include("evo_calendrier/sv_web_intake.lua") -- absorption des demandes venues du site (panel Animations)
else
    include("evo_calendrier/sh_config.lua")
    include("evo_calendrier/cl_main.lua")
end
