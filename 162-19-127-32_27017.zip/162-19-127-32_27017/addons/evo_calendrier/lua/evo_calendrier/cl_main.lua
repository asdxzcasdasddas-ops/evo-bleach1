-- "addons\\evo_calendrier\\lua\\evo_calendrier\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CALENDRIER — UI client : GRILLE MENSUELLE (vrai calendrier).
--   Volet GAUCHE  : la grille du mois (nav < mois >), pastilles d'événements,
--                   aujourd'hui surligné, clic sur un jour = le sélectionne.
--   Volet DROITE  : 3 modes -> "day" (events du jour sélectionné), "detail"
--                   (fiche + mode d'emploi + inscription), "add" (formulaire,
--                   ANIMATEURS uniquement).
--   RÉSERVÉ aux ANIMATEURS / admins / superadmins (PAS accessible aux joueurs) : gate
--   IsAnimator client ET serveur sur tout (ouverture, lecture, inscription, création).
--   Données reçues du serveur (table MySQL partagée -> cross-serveur).
-- ============================================================================

if not CLIENT then return end

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function C() return EVO_UI and EVO_UI.Col or {
    bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18),
    title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118),
    accent = Color(207,68,78), green = Color(78,196,128) } end

local MONTHS = { "Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre" }
local WDAYS_SHORT = { "Lun","Mar","Mer","Jeu","Ven","Sam","Dim" }
local WDAYS_LONG  = { "Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche" }

local function MakeFonts()
    if not gCreateRespFont then return end
    -- Polices AGRANDIES (demande user : titres + tout plus gros).
    gCreateRespFont("EVO_Cal_Title", "Roboto", 22, 700)
    gCreateRespFont("EVO_Cal_H",     "Roboto", 18, 600)
    gCreateRespFont("EVO_Cal_Btn",   "Roboto", 16, 600)
    gCreateRespFont("EVO_Cal_Day",   "Roboto", 15, 600)
    gCreateRespFont("EVO_Cal_Small", "Roboto", 14, 500)
    gCreateRespFont("EVO_Cal_Instr", "Roboto", 18, 500) -- mode d'emploi : plus gros / lisible (demande user)
    -- Bannière d'annonce serveur-entier (notification d'événement à venir).
    gCreateRespFont("EVO_Cal_AnnTitle", "Roboto", 17, 800)
    gCreateRespFont("EVO_Cal_AnnName",  "Roboto", 30, 800)
    gCreateRespFont("EVO_Cal_AnnSub",   "Roboto", 18, 500)
end
hook.Add("Initialize", "EVO_Cal::Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Cal::Fonts2", MakeFonts)
MakeFonts()

-- État module-local de l'UI.
local cal = { events = {}, viewY = nil, viewM = nil, sel = nil, mode = "day", selEvent = nil, addType = nil }
local closedAt = 0
local lastDenied = 0 -- anti-spam de la notif "réservé aux animateurs" (re-press / multi-sources)

-- ── Helpers date ──────────────────────────────────────────────────────────────
local function typeColor(t) return t and t.color and Color(t.color[1], t.color[2], t.color[3]) or C().accent end
local function dayKey(y, m, d) return y * 10000 + m * 100 + d end
local function daysInMonth(y, m)
    return tonumber(os.date("%d", os.time({ year = y, month = m + 1, day = 0, hour = 12 })))
end
-- Index de colonne (lundi=0 … dimanche=6) du 1er jour du mois.
local function firstColumn(y, m)
    local wday = tonumber(os.date("%w", os.time({ year = y, month = m, day = 1, hour = 12 }))) -- 0=dim … 6=sam
    return (wday + 6) % 7
end
-- Date FR complète depuis un timestamp (os.date %A/%B sont en ANGLAIS selon la locale -> on
-- formate nous-mêmes avec nos tables). t.wday : 1=dimanche … 7=samedi.
local function frDateTime(ts)
    local t = os.date("*t", ts)
    return string.format("%s %d %s %d · %02dh%02d",
        WDAYS_LONG[((t.wday + 5) % 7) + 1], t.day, MONTHS[t.month], t.year, t.hour, t.min)
end
-- Range les events par jour (clé y/m/j), triés par heure croissante.
local function bucketByDay()
    -- Un event EN ATTENTE de validation (approved == 0) n'est visible que par un SuperAdmin ou son hôte.
    local sa  = LocalPlayer():IsSuperAdmin()
    local sid = LocalPlayer():SteamID64()
    local b = {}
    for _, e in ipairs(cal.events) do
        if (tonumber(e.approved) or 1) ~= 0 or sa or e.host == sid then
            local t = os.date("*t", e.time)
            local k = dayKey(t.year, t.month, t.day)
            b[k] = b[k] or {}
            b[k][#b[k] + 1] = e
        end
    end
    for _, list in pairs(b) do
        table.sort(list, function(a, c) return a.time < c.time end)
    end
    return b
end
local function findEvent(id)
    for _, e in ipairs(cal.events) do if e.id == id then return e end end
    return nil
end
local function localSid() return LocalPlayer():SteamID64() end
local function isSignedUp(e)
    local sid = localSid()
    for _, p in ipairs(e.parts or {}) do if p.sid == sid then return true end end
    return false
end

-- ── Boutons réseau ────────────────────────────────────────────────────────────
local function NetAdd(typeId, ts, loc, note, cname, announceBoth, gmJSON)
    net.Start("EVO_Cal_Add")
        net.WriteString(typeId) net.WriteUInt(ts, 32)
        net.WriteString(loc or "") net.WriteString(note or "")
        net.WriteString(cname or "")
        net.WriteBool(announceBoth ~= false) -- annonce sur les 2 serveurs (défaut oui)
        net.WriteString(gmJSON or "")        -- config event moteur ("" si non-moteur)
    net.SendToServer()
end
local function NetSimple(name, id)
    net.Start(name) net.WriteUInt(id, 32) net.SendToServer()
end

-- ── Petits widgets ──────────────────────────────────────────────────────────
local function flatBtn(parent, label, fill, fn)
    local b = vgui.Create("DButton", parent) b:SetText("")
    b.Paint = function(s, w, h)
        RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(fill, s:IsHovered() and 255 or 205))
        draw.SimpleText(label, "EVO_Cal_Btn", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = fn
    return b
end
local function styleEntry(p)
    local col = C()
    p:SetPaintBackground(false)
    if p.SetDrawLanguageID then p:SetDrawLanguageID(false) end
    p.Paint = function(s, w, h)
        RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, 12))
        RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(col.border, 50), 1)
        s:DrawTextEntryText(col.title, col.accent, col.title)
    end
end
local function styleScroll(sp)
    local col = C()
    local sb = sp:GetVBar()
    if not IsValid(sb) then return end
    sb:SetWide(R(5)) sb.Paint = function() end
    if IsValid(sb.btnUp) then sb.btnUp.Paint = function() end end
    if IsValid(sb.btnDown) then sb.btnDown.Paint = function() end end
    sb.btnGrip.Paint = function(_, w, h) RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(col.accent, 130)) end
end

-- Dropdown générique de types d'événements (popup sous le bouton).
local function OpenTypeDropdown(dd)
    if not IsValid(cal.frame) or not IsValid(dd) then return end
    local col = C()
    local sx, sy = dd:LocalToScreen(0, dd:GetTall() + R(4))
    local back = vgui.Create("DButton", cal.frame) back:SetText("") back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0) back:SetZPos(900) back.Paint = function() end
    local pop = vgui.Create("DPanel", cal.frame) pop:SetSize(dd:GetWide(), R(40 * (#EVO_Calendrier.EventTypes + 1) + 8)) pop:SetPos(sx, sy) pop:SetZPos(901) pop:SetMouseInputEnabled(true)
    pop.Paint = function(_, w, h) RNDX.Draw(R(8), 0, 0, w, h, col.bg) RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.accent, 130), 1.5) end
    dd._pop = pop
    local function closeAll() dd._pop = nil if IsValid(pop) then pop:Remove() end if IsValid(back) then back:Remove() end end
    back.DoClick = closeAll
    pop.OnRemove = function() if IsValid(back) then back:Remove() end end
    local yy = 4
    for _, t in ipairs(EVO_Calendrier.EventTypes) do
        local row = vgui.Create("DButton", pop) row:SetText("") row:SetPos(R(4), R(yy)) row:SetSize(dd:GetWide() - R(8), R(34))
        row.Paint = function(rs, rw, rh)
            local sel = (cal.addType == t.id)
            if rs:IsHovered() or sel then RNDX.Draw(R(5), 0, 0, rw, rh, ColorAlpha(typeColor(t), sel and 90 or 55)) end
            RNDX.Draw(R(2), R(8), rh / 2 - R(7), R(4), R(14), typeColor(t))
            draw.SimpleText(t.name, "EVO_Cal_Small", R(20), rh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        row.DoClick = function() cal.addType = t.id closeAll() if IsValid(cal.right) then cal._rebuildRight() end end
        yy = yy + 38
    end
    -- Entrée "Événement personnalisé" : l'animateur spécifie tout lui-même (nom + description).
    local crow = vgui.Create("DButton", pop) crow:SetText("") crow:SetPos(R(4), R(yy)) crow:SetSize(dd:GetWide() - R(8), R(34))
    crow.Paint = function(rs, rw, rh)
        local sel = (cal.addType == EVO_Calendrier.CUSTOM_ID)
        if rs:IsHovered() or sel then RNDX.Draw(R(5), 0, 0, rw, rh, ColorAlpha(col.accent, sel and 90 or 55)) end
        RNDX.Draw(R(2), R(8), rh / 2 - R(7), R(4), R(14), col.accent)
        draw.SimpleText("Événement personnalisé", "EVO_Cal_Small", R(20), rh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    crow.DoClick = function() cal.addType = EVO_Calendrier.CUSTOM_ID closeAll() if IsValid(cal.right) then cal._rebuildRight() end end
end

-- ── Volet DROITE : construit selon cal.mode ──────────────────────────────────
local function RebuildRight()
    if not IsValid(cal.right) then return end
    local col = C()
    for _, c in ipairs(cal.right:GetChildren()) do c:Remove() end
    local W = cal.right:GetWide()
    local PAD = R(14)
    local INNER = W - PAD * 2
    local amAnim = EVO_Calendrier.IsAnimator(LocalPlayer())

    -- ── MODE AJOUT (animateurs) ──
    if cal.mode == "add" and amAnim and cal.sel then
        cal.addType = cal.addType or (EVO_Calendrier.EventTypes[1] and EVO_Calendrier.EventTypes[1].id)
        if cal._annBoth == nil then cal._annBoth = true end
        local isCustom = (cal.addType == EVO_Calendrier.CUSTOM_ID)
        local theme    = EVO_Calendrier.GetType(cal.addType)
        local gmParams = theme and theme.gm_params

        -- En-tête FIXE (retour + titre + date).
        local back = vgui.Create("DButton", cal.right) back:SetText("") back:SetPos(PAD, R(10)) back:SetSize(R(90), R(24))
        back.Paint = function(s, w, h) draw.SimpleText("‹ Retour", "EVO_Cal_Btn", 0, h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
        back.DoClick = function() cal.mode = "day" RebuildRight() end
        local title = vgui.Create("DLabel", cal.right) title:SetFont("EVO_Cal_Title") title:SetTextColor(col.title)
        title:SetPos(PAD, R(38)) title:SetSize(INNER, R(26)) title:SetText("Nouvel événement")
        local subt = vgui.Create("DLabel", cal.right) subt:SetFont("EVO_Cal_Small") subt:SetTextColor(col.muted)
        subt:SetPos(PAD, R(64)) subt:SetSize(INNER, R(18))
        subt:SetText(string.format("Le %s %d %s", WDAYS_LONG[((tonumber(os.date("%w", os.time({year=cal.sel.y,month=cal.sel.m,day=cal.sel.d,hour=12}))) + 6) % 7) + 1], cal.sel.d, MONTHS[cal.sel.m]))

        -- Zone SCROLLABLE pour les champs (le bouton Créer reste fixe en bas).
        local form = vgui.Create("DScrollPanel", cal.right) form:SetPos(PAD, R(86)) form:SetSize(INNER, cal.right:GetTall() - R(86 + 46)) styleScroll(form)
        local function fLabel(txt)
            local l = vgui.Create("DLabel", form) l:Dock(TOP) l:DockMargin(0, R(8), R(6), R(2))
            l:SetTall(R(18)) l:SetFont("EVO_Cal_Small") l:SetTextColor(col.muted) l:SetText(txt) return l
        end
        local function fEntry(numeric, default, tall)
            local e = vgui.Create("DTextEntry", form) e:Dock(TOP) e:DockMargin(0, 0, R(6), 0)
            e:SetTall(R(tall or 30)) e:SetFont("EVO_Cal_Btn") if numeric then e:SetNumeric(true) end
            e:SetText(default or "") styleEntry(e) return e
        end

        -- TYPE
        fLabel("Type d'événement")
        local dd = vgui.Create("DButton", form) dd:Dock(TOP) dd:DockMargin(0, 0, R(6), 0) dd:SetTall(R(32)) dd:SetText("")
        dd.Paint = function(s, w, h)
            local t = EVO_Calendrier.GetType(cal.addType)
            RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14)) RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(IsValid(s._pop) and col.accent or col.border, IsValid(s._pop) and 150 or 60), 1.5)
            if t then RNDX.Draw(R(2), R(10), h / 2 - R(8), R(4), R(16), typeColor(t))
            elseif isCustom then RNDX.Draw(R(2), R(10), h / 2 - R(8), R(4), R(16), col.accent) end
            local label = (t and t.name) or (isCustom and "Événement personnalisé") or "Choisir…"
            draw.SimpleText(label, "EVO_Cal_Btn", R(22), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(IsValid(s._pop) and "▴" or "▾", "EVO_Cal_Btn", w - R(16), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        dd.DoClick = function(s) if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end OpenTypeDropdown(s) end

        -- NOM (custom uniquement)
        local nameE
        if isCustom then fLabel("Nom de l'événement *") nameE = fEntry(false, "") end

        -- HEURE (HH : MM) sur une ligne
        fLabel("Heure (HH : MM)")
        local hrow = vgui.Create("DPanel", form) hrow:Dock(TOP) hrow:DockMargin(0, 0, R(6), 0) hrow:SetTall(R(30)) hrow.Paint = function() end
        local hhE = vgui.Create("DTextEntry", hrow) hhE:SetNumeric(true) hhE:SetFont("EVO_Cal_Btn") hhE:SetPos(0, 0) hhE:SetSize(R(54), R(30)) hhE:SetText(os.date("%H")) styleEntry(hhE)
        local colon = vgui.Create("DLabel", hrow) colon:SetFont("EVO_Cal_Title") colon:SetTextColor(col.title) colon:SetPos(R(58), 0) colon:SetSize(R(12), R(30)) colon:SetText(":") colon:SetContentAlignment(5)
        local mmE = vgui.Create("DTextEntry", hrow) mmE:SetNumeric(true) mmE:SetFont("EVO_Cal_Btn") mmE:SetPos(R(72), 0) mmE:SetSize(R(54), R(30)) mmE:SetText(os.date("%M")) styleEntry(mmE)

        -- LIEU
        fLabel("Lieu (où ça se passe)")
        local locE = fEntry(false, "", 28)

        -- NOTE / DESCRIPTION
        fLabel(isCustom and "Description de l'événement *" or "Précisions (optionnel) : détails / lore")
        local noteE = fEntry(false, "", 56) noteE:SetMultiline(true)

        -- ── EVENT MOTEUR : zone (ma position) + paramètres (data-driven via gm_params) ──
        local paramGetters = {}
        if gmParams then
            fLabel("Zone de l'événement")
            local zb = vgui.Create("DButton", form) zb:Dock(TOP) zb:DockMargin(0, 0, R(6), 0) zb:SetTall(R(32)) zb:SetText("")
            zb.Paint = function(s, w, h)
                local set = cal._gmPos ~= nil
                RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(set and col.green or col.accent, s:IsHovered() and 255 or 205))
                draw.SimpleText(set and "Zone définie : recliquer pour la redéfinir" or "Définir la zone à ma position", "EVO_Cal_Btn", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            zb.DoClick = function() cal._gmPos = LocalPlayer():GetPos() surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3") end -- click custom projet

            for _, p in ipairs(gmParams) do
                fLabel(p.label)
                if p.choices then
                    local cb = vgui.Create("DComboBox", form) cb:Dock(TOP) cb:DockMargin(0, 0, R(6), 0) cb:SetTall(R(30))
                    cb:SetFont("EVO_Cal_Btn") cb:SetTextColor(col.title)
                    cb.Paint = function(s, w, h) RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, 12)) RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(col.border, 50), 1) end
                    for _, c in ipairs(p.choices) do cb:AddChoice(c, c, c == p.default) end
                    paramGetters[p.key] = function() local _, d = cb:GetSelected() return d or p.default end
                else
                    -- numeric strict pour les entiers ; désactivé pour les float (sinon le point
                    -- décimal est bloqué) — le serveur re-clampe de toute façon via NormalizeGMParams.
                    local e = fEntry(not p.float, tostring(p.default))
                    paramGetters[p.key] = function() return e:GetValue() end
                end
            end
        end

        -- ── ANNONCE : sur les 2 serveurs, ou seulement celui où l'event se déroule ──
        fLabel("Annonce")
        local ab = vgui.Create("DButton", form) ab:Dock(TOP) ab:DockMargin(0, 0, R(6), 0) ab:SetTall(R(30)) ab:SetText("")
        ab.Paint = function(s, w, h)
            RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, s:IsHovered() and 18 or 10))
            local on = cal._annBoth ~= false
            RNDX.Draw(R(4), R(8), h / 2 - R(8), R(16), R(16), on and col.green or Color(70, 70, 80))
            if on then draw.SimpleText("x", "EVO_Cal_Btn", R(16), h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
            draw.SimpleText("Annoncer sur les 2 serveurs (sinon : seulement celui de l'event)", "EVO_Cal_Small", R(34), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        ab.DoClick = function() if cal._annBoth == false then cal._annBoth = true else cal._annBoth = false end end

        -- Hint validation : TOUS les events (même créés par un SA) doivent être VALIDÉS avant de se lancer.
        do
            local hint = vgui.Create("DLabel", form) hint:Dock(TOP) hint:DockMargin(0, R(8), R(6), 0)
            hint:SetFont("EVO_Cal_Small") hint:SetTextColor(Color(230, 160, 60)) hint:SetWrap(true) hint:SetAutoStretchVertical(true)
            hint:SetText("Cet événement devra être VALIDÉ par un SuperAdmin (bouton Valider) avant d'apparaître au calendrier et de se lancer.")
        end
        local pad = vgui.Create("DPanel", form) pad:Dock(TOP) pad:SetTall(R(10)) pad.Paint = function() end

        -- Bouton Créer (FIXE en bas).
        local create = flatBtn(cal.right, "Créer l'événement", col.accent, function()
            local function refuse(m) if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(m, NOTIFY_ERROR, 4) end end
            if not cal.addType then return refuse("Choisis un type d'événement.") end
            local hh = tonumber(hhE:GetValue()) local mm = tonumber(mmE:GetValue())
            if not hh or hh < 0 or hh > 23 then return refuse("Heure invalide (0 à 23).") end
            if not mm or mm < 0 or mm > 59 then return refuse("Minutes invalides (0 à 59).") end
            local cname = ""
            if isCustom then
                cname = string.Trim(nameE and nameE:GetValue() or "")
                if cname == "" then return refuse("Donne un nom à ton événement.") end
                if string.Trim(noteE:GetValue() or "") == "" then return refuse("Ajoute une description à ton événement.") end
            end
            local gmJSON = ""
            if gmParams then
                if not cal._gmPos then return refuse("Définis d'abord la zone (bouton « Définir la zone à ma position »).") end
                local params = {}
                for k, getter in pairs(paramGetters) do params[k] = getter() end
                gmJSON = util.TableToJSON({ pos = { x = cal._gmPos.x, y = cal._gmPos.y, z = cal._gmPos.z }, params = params })
            end
            local ts = os.time({ year = cal.sel.y, month = cal.sel.m, day = cal.sel.d, hour = hh, min = mm, sec = 0 })
            NetAdd(cal.addType, ts, string.sub(locE:GetValue() or "", 1, 80), string.sub(noteE:GetValue() or "", 1, 500), string.sub(cname, 1, 96), cal._annBoth ~= false, gmJSON)
            cal._gmPos = nil cal._annBoth = true
            cal.mode = "day" RebuildRight()
        end)
        create:SetPos(PAD, cal.right:GetTall() - R(42)) create:SetSize(INNER, R(36))
        return
    end

    -- ── MODE DÉTAIL ──
    if cal.mode == "detail" and cal.selEvent then
        local e = findEvent(cal.selEvent)
        if not e then cal.mode = "day" RebuildRight() return end
        local t = EVO_Calendrier.GetEventInfo(e) -- thème prédéfini OU custom (toujours non-nil)
        local back = vgui.Create("DButton", cal.right) back:SetText("") back:SetPos(PAD, R(10)) back:SetSize(R(90), R(24))
        back.Paint = function(s, w, h) draw.SimpleText("‹ Retour", "EVO_Cal_Btn", 0, h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER) end
        back.DoClick = function() cal.mode = "day" RebuildRight() end

        local sc = vgui.Create("DScrollPanel", cal.right) sc:SetPos(PAD, R(40)) sc:SetSize(INNER, cal.right:GetTall() - R(96)) styleScroll(sc)
        -- Labels DOCKÉS (auto-stack) + auto-stretch vertical pour le texte multi-lignes
        -- (évite le chevauchement d'un empilement manuel à hauteur fixe).
        local function lbl(font, color, txt, wrap, topGap)
            local l = sc:Add(vgui.Create("DLabel")) l:SetFont(font) l:SetTextColor(color)
            l:Dock(TOP) l:DockMargin(0, R(topGap or 3), R(6), 0) l:SetText(txt)
            if wrap then l:SetWrap(true) l:SetAutoStretchVertical(true) else l:SetTall(R(22)) end
            return l
        end
        -- En-tête : nom du type (couleur) + date/heure FR. Si l'event est passé : titre grisé +
        -- barré + libellé "Événement terminé" (DLabel n'a pas de strikethrough -> PaintOver).
        local past = EVO_Calendrier.IsEventPast(e)
        local hd = lbl("EVO_Cal_Title", past and col.muted or typeColor(t), t.name) hd:SetTall(R(26))
        if past then
            hd.PaintOver = function(s, w, hh)
                surface.SetFont("EVO_Cal_Title")
                local tw = surface.GetTextSize(t.name)
                local lh = math.max(1, R(2))
                local ix = s:GetTextInset() or 0 -- aligne le trait sur le DEBUT reel des glyphes (inset DLabel)
                surface.SetDrawColor(col.muted.r, col.muted.g, col.muted.b, 255)
                surface.DrawRect(ix, math.floor(hh / 2 - lh / 2), tw, lh)
            end
        end
        lbl("EVO_Cal_Small", col.muted, frDateTime(e.time))
        if past then lbl("EVO_Cal_H", col.muted, "Événement terminé", false, 4) end
        if e.loc ~= "" then lbl("EVO_Cal_Small", col.title, "Lieu : " .. e.loc, true) end
        lbl("EVO_Cal_Small", col.muted, "Animé par " .. (e.hostname or "?") .. (e.region ~= "" and ("  ·  " .. e.region) or ""), true)

        -- Statut de validation (en attente / validé par qui).
        local pending = (tonumber(e.approved) or 1) == 0
        if pending then
            lbl("EVO_Cal_Small", Color(230, 160, 60), "En attente de validation d'un SuperAdmin", true)
        elseif e.approvedby and e.approvedby ~= "" then
            lbl("EVO_Cal_Small", col.dim, "Validé par " .. e.approvedby, true)
        end
        -- Portée de l'annonce (pour tous les events).
        lbl("EVO_Cal_Small", col.dim, "Annonce : " .. (((tonumber(e.announceboth) or 1) ~= 0) and "les 2 serveurs" or "serveur de l'événement uniquement"), true)
        -- Event moteur : prévenir qu'il se déclenche tout seul + récap des réglages (pour la validation SA).
        local _gt = EVO_Calendrier.GetType and EVO_Calendrier.GetType(e.type)
        if _gt and _gt.gm_event then
            lbl("EVO_Cal_Small", col.dim, "Événement automatisé : se déclenche tout seul à l'heure prévue (une fois validé).", true)
            if istable(e.gmconfig) then
                local g = e.gmconfig
                if istable(g.pos) then
                    lbl("EVO_Cal_Small", col.muted, string.format("Zone : %.0f, %.0f, %.0f", tonumber(g.pos.x) or 0, tonumber(g.pos.y) or 0, tonumber(g.pos.z) or 0), true)
                end
                if istable(g.params) and _gt.gm_params then
                    for _, p in ipairs(_gt.gm_params) do
                        local v = g.params[p.key]
                        if v ~= nil then lbl("EVO_Cal_Small", col.muted, "• " .. p.label .. " : " .. tostring(v)) end
                    end
                end
            end
        end

        -- DESCRIPTION (en évidence, pour tout le monde) : le « quoi/pourquoi » de l'événement.
        -- (Custom -> la description saisie ; thème -> sa description prédéfinie.)
        if t.description and t.description ~= "" then
            lbl("EVO_Cal_H", col.title, "Description", false, 12)
            lbl("EVO_Cal_Btn", col.muted, t.description, true)
        end
        -- Note libre de l'animateur — UNIQUEMENT pour les thèmes (pour un custom, la note EST déjà
        -- la description ci-dessus -> on ne la répète pas).
        if not t.isCustom and e.note ~= "" then
            lbl("EVO_Cal_H", col.title, "Précisions de l'animateur", false, 10)
            lbl("EVO_Cal_Small", col.title, e.note, true)
        end

        -- Inscrits
        lbl("EVO_Cal_H", col.title, "Inscrits (" .. #(e.parts or {}) .. ")", false, 12)
        if #(e.parts or {}) == 0 then lbl("EVO_Cal_Small", col.dim, "Personne pour l'instant.")
        else for _, p in ipairs(e.parts) do lbl("EVO_Cal_Small", col.muted, "• " .. (p.name or "?")) end end

        -- Mode d'emploi
        if t.instructions then
            lbl("EVO_Cal_H", col.title, "Mode d'emploi", false, 12)
            for i, step in ipairs(t.instructions) do lbl("EVO_Cal_Instr", col.muted, i .. ". " .. step, true) end
        end

        -- Barre d'actions (bas, hors scroll).
        local bottomY = cal.right:GetTall() - R(46)
        -- Event EN ATTENTE + SuperAdmin -> Valider (publie) / Refuser (supprime).
        if pending and LocalPlayer():IsSuperAdmin() then
            local bV = flatBtn(cal.right, "Valider", col.green, function() NetSimple("EVO_Cal_Approve", e.id) cal.mode = "day" RebuildRight() end)
            bV:SetPos(PAD, bottomY) bV:SetSize(INNER * 0.58, R(34))
            local bR = flatBtn(cal.right, "Refuser", col.accent, function() NetSimple("EVO_Cal_Reject", e.id) cal.mode = "day" RebuildRight() end)
            bR:SetPos(PAD + INNER * 0.58 + R(8), bottomY) bR:SetSize(INNER * 0.42 - R(8), R(34))
            return
        end
        -- Sinon : S'inscrire = tout animateur présent ; Supprimer = hôte/admin.
        local signed = isSignedUp(e)
        local canDelete = (e.host == localSid()) or LocalPlayer():IsAdmin()
        local b1 = flatBtn(cal.right, signed and "Se désinscrire" or "S'inscrire", signed and col.muted or col.green, function()
            NetSimple(signed and "EVO_Cal_Leave" or "EVO_Cal_Signup", e.id)
        end)
        b1:SetPos(PAD, bottomY) b1:SetSize(canDelete and INNER * 0.58 or INNER, R(34))
        if canDelete then
            local b2 = flatBtn(cal.right, "Supprimer", col.accent, function() NetSimple("EVO_Cal_Delete", e.id) cal.mode = "day" RebuildRight() end)
            b2:SetPos(PAD + INNER * 0.58 + R(8), bottomY) b2:SetSize(INNER * 0.42 - R(8), R(34))
        end
        return
    end

    -- ── MODE JOUR (par défaut) ──
    if not cal.sel then
        local l = vgui.Create("DLabel", cal.right) l:SetFont("EVO_Cal_Small") l:SetTextColor(col.dim) l:SetPos(PAD, R(20)) l:SetSize(INNER, R(40)) l:SetWrap(true) l:SetText("Sélectionne un jour dans le calendrier pour voir ses événements.")
        return
    end
    local sd = cal.sel
    local wlong = WDAYS_LONG[((tonumber(os.date("%w", os.time({ year = sd.y, month = sd.m, day = sd.d, hour = 12 }))) + 6) % 7) + 1]
    local hdr = vgui.Create("DLabel", cal.right) hdr:SetFont("EVO_Cal_Title") hdr:SetTextColor(col.title)
    hdr:SetPos(PAD, R(12)) hdr:SetSize(INNER, R(24)) hdr:SetText(string.format("%s %d %s", wlong, sd.d, MONTHS[sd.m]))

    local bottomReserve = amAnim and 48 or 8
    local sc = vgui.Create("DScrollPanel", cal.right) sc:SetPos(PAD, R(44)) sc:SetSize(INNER, cal.right:GetTall() - R(44 + bottomReserve)) styleScroll(sc)

    local list = bucketByDay()[dayKey(sd.y, sd.m, sd.d)] or {}
    if #list == 0 then
        local none = vgui.Create("DLabel", sc) none:SetFont("EVO_Cal_Small") none:SetTextColor(col.dim) none:Dock(TOP) none:DockMargin(0, R(6), 0, 0) none:SetTall(R(20)) none:SetText("Aucun événement ce jour.")
    else
        for _, e in ipairs(list) do
            local t = EVO_Calendrier.GetEventInfo(e)
            local row = vgui.Create("DButton", sc) row:SetText("") row:Dock(TOP) row:DockMargin(0, R(6), R(4), 0) row:SetTall(R(58))
            row.Paint = function(s, w, h)
                local past = EVO_Calendrier.IsEventPast(e)
                local nameCol = past and col.muted or typeColor(t)
                RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, s:IsHovered() and 22 or 12))
                RNDX.Draw(R(3), 0, 0, R(4), h, past and col.dim or typeColor(t))
                draw.SimpleText(os.date("%Hh%M", e.time), "EVO_Cal_H", R(14), R(12), past and col.muted or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText(t.name, "EVO_Cal_Btn", R(62), R(12), nameCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                if past then
                    -- Barre le nom (draw.SimpleText n'a pas de strikethrough natif) + tag "TERMINÉ"
                    -- (qui prime sur "EN ATTENTE" : un event jamais validé puis dépassé = terminé).
                    surface.SetFont("EVO_Cal_Btn")
                    local tw = surface.GetTextSize(t.name)
                    local lh = math.max(1, R(2))
                    surface.SetDrawColor(nameCol.r, nameCol.g, nameCol.b, 255)
                    surface.DrawRect(R(62), R(12) - math.floor(lh / 2), tw, lh)
                    draw.SimpleText("TERMINÉ", "EVO_Cal_Small", w - R(12), R(12), col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                elseif (tonumber(e.approved) or 1) == 0 then
                    draw.SimpleText("EN ATTENTE", "EVO_Cal_Small", w - R(12), R(12), Color(230, 160, 60), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                end
                draw.SimpleText("par " .. (e.hostname or "?") .. "  ·  " .. #(e.parts or {}) .. " inscrit" .. (#(e.parts or {}) > 1 and "s" or ""), "EVO_Cal_Small", R(14), R(34), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                if e.loc ~= "" then draw.SimpleText("" .. e.loc, "EVO_Cal_Small", w - R(12), R(34), col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) end
            end
            row.DoClick = function() cal.selEvent = e.id cal.mode = "detail" RebuildRight() end
        end
    end

    if amAnim then
        local add = flatBtn(cal.right, "+ Ajouter un événement", col.accent, function() cal._gmPos = nil cal._annBoth = true cal.mode = "add" RebuildRight() end)
        add:SetPos(PAD, cal.right:GetTall() - R(42)) add:SetSize(INNER, R(32))
    end
end
cal._rebuildRight = RebuildRight

-- ── Volet GAUCHE : la grille du mois ─────────────────────────────────────────
local function RebuildGrid()
    if not IsValid(cal.grid) then return end
    local col = C()
    for _, c in ipairs(cal.grid:GetChildren()) do c:Remove() end
    local W, H = cal.grid:GetWide(), cal.grid:GetTall()
    local y, m = cal.viewY, cal.viewM

    -- Barre de navigation < Mois Année >
    local prev = vgui.Create("DButton", cal.grid) prev:SetText("") prev:SetPos(0, 0) prev:SetSize(R(34), R(30))
    prev.Paint = function(s, w, h) draw.SimpleText("‹", "EVO_Cal_Title", w / 2, h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
    prev.DoClick = function() cal.viewM = cal.viewM - 1 if cal.viewM < 1 then cal.viewM = 12 cal.viewY = cal.viewY - 1 end RebuildGrid() end
    local nxt = vgui.Create("DButton", cal.grid) nxt:SetText("") nxt:SetPos(W - R(34), 0) nxt:SetSize(R(34), R(30))
    nxt.Paint = function(s, w, h) draw.SimpleText("›", "EVO_Cal_Title", w / 2, h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
    nxt.DoClick = function() cal.viewM = cal.viewM + 1 if cal.viewM > 12 then cal.viewM = 1 cal.viewY = cal.viewY + 1 end RebuildGrid() end
    local mlbl = vgui.Create("DLabel", cal.grid) mlbl:SetFont("EVO_Cal_Title") mlbl:SetTextColor(col.title) mlbl:SetPos(R(34), 0) mlbl:SetSize(W - R(68), R(30)) mlbl:SetContentAlignment(5) mlbl:SetText(MONTHS[m] .. " " .. y)

    -- En-tête des jours de la semaine
    local cellW = W / 7
    for i = 1, 7 do
        local wd = vgui.Create("DLabel", cal.grid) wd:SetFont("EVO_Cal_Small") wd:SetTextColor(col.muted)
        wd:SetPos(math.floor((i - 1) * cellW), R(38)) wd:SetSize(math.floor(cellW), R(16)) wd:SetContentAlignment(5) wd:SetText(WDAYS_SHORT[i])
    end

    -- Cellules
    local first = firstColumn(y, m)
    local dim = daysInMonth(y, m)
    local rows = math.ceil((first + dim) / 7)
    local gridTop = R(58)
    local cellH = (H - gridTop) / rows
    local buckets = bucketByDay()
    local today = os.date("*t")

    for d = 1, dim do
        local idx = first + (d - 1)
        local cx = math.floor((idx % 7) * cellW)
        local cy = gridTop + math.floor(math.floor(idx / 7) * cellH)
        local cellWi, cellHi = math.floor(cellW) - R(4), math.floor(cellH) - R(4)
        local cell = vgui.Create("DButton", cal.grid) cell:SetText("") cell:SetPos(cx, cy) cell:SetSize(cellWi, cellHi)
        local dayEvents = buckets[dayKey(y, m, d)] or {}
        local isToday = (today.year == y and today.month == m and today.day == d)
        cell.Paint = function(s, w, h)
            local isSel = cal.sel and cal.sel.y == y and cal.sel.m == m and cal.sel.d == d
            RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, s:IsHovered() and 20 or (isSel and 26 or 8)))
            if isSel then RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(col.accent, 220), 1.5)
            elseif isToday then RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(col.green, 150), 1) end
            draw.SimpleText(d, "EVO_Cal_Day", R(7), R(6), isToday and col.green or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            -- Pastilles d'événements (couleur du type), max 3 + "+N"
            local n = #dayEvents
            if n > 0 then
                local dotY = h - R(11)
                local shown = math.min(n, 3)
                for i = 1, shown do
                    local ev = dayEvents[i]
                    local dotCol = EVO_Calendrier.IsEventPast(ev) and col.dim or typeColor(EVO_Calendrier.GetEventInfo(ev))
                    RNDX.Draw(R(8), R(7) + (i - 1) * R(11), dotY, R(7), R(7), dotCol)
                end
                if n > 3 then draw.SimpleText("+" .. (n - 3), "EVO_Cal_Small", w - R(6), dotY - R(1), col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP) end
            end
        end
        cell.DoClick = function()
            cal.sel = { y = y, m = m, d = d }
            if cal.mode == "add" then cal.mode = "day" end -- on quitte un formulaire en cours si on change de jour
            if cal.mode == "detail" then cal.mode = "day" end
            RebuildRight()
        end
    end
end

-- ── Fenêtre ──────────────────────────────────────────────────────────────────
function EVO_OpenCalendrier()
    MakeFonts()
    if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
    if IsValid(cal.frame) then cal.frame:Remove() cal.frame = nil return end

    -- ACCÈS RÉSERVÉ aux animateurs / admins / superadmins (PAS les joueurs). Le serveur re-gate
    -- la requête de données -> aucune donnée n'arrive à un non-animateur.
    if not EVO_Calendrier.IsAnimator(LocalPlayer()) then
        -- Notif anti-spam : au plus une fois / 3 s (évite le doublon et le spam au re-press).
        if (SysTime() - (lastDenied or 0)) > 3 then
            lastDenied = SysTime()
            if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Le calendrier est réservé aux animateurs.", NOTIFY_ERROR, 4) end
        end
        return
    end

    -- Demande l'état frais (réponse depuis le cache serveur), et part de ce qu'on a déjà.
    net.Start("EVO_Cal_Request") net.SendToServer()

    local col = C()
    local CARD_W, CARD_H = 960, 640
    local cardW, cardH = R(CARD_W), R(CARD_H)
    local now = os.date("*t")
    cal.viewY, cal.viewM = cal.viewY or now.year, cal.viewM or now.month
    cal.sel = cal.sel or { y = now.year, m = now.month, d = now.day }
    cal.mode = "day"

    local f = vgui.Create("DFrame") cal.frame = f
    f:SetSize(ScrW(), ScrH()) f:SetPos(0, 0) f:SetTitle("") f:ShowCloseButton(false) f:SetDraggable(false)
    f:SetPaintBackgroundEnabled(false) f:MakePopup()
    openedFrame = f -- fermeture Échap (lzy_escape_menu)
    f._a = 0 f._opened = false f._keyDown = false
    timer.Simple(0.3, function() if IsValid(f) then f._opened = true end end)
    f.Think = function(s)
        s._a = Lerp(FrameTime() * 12, s._a, 255)
        local lp = LocalPlayer()
        local k = (IsValid(lp) and lp.GetBindKey) and lp:GetBindKey("calendrier") or 0
        if k ~= 0 then
            local down = input.IsButtonDown(k)
            -- Re-press de la touche = FERME (toggle), comme le menu animateur. La fenêtre est
            -- MakePopup -> vgui.GetKeyboardFocus() est TOUJOURS vrai (d'où l'ancien blocage) :
            -- on ne bloque donc QUE si un CHAMP TEXTE est réellement focus (saisie en cours).
            local kf = vgui.GetKeyboardFocus()
            local typing = IsValid(kf) and kf ~= s and kf.GetText ~= nil
            if down and not s._keyDown and s._opened and not typing then s:Remove() return end
            s._keyDown = down
        end
    end
    f.OnRemove = function(self) if openedFrame == self then openedFrame = nil end cal.frame = nil closedAt = SysTime() end
    f.Paint = function(s, w, h)
        local a = s._a / 255
        if a < 0.01 then return end
        if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 5) end
        surface.SetDrawColor(0, 0, 0, 150 * a) surface.DrawRect(0, 0, w, h)
    end
    f.OnMousePressed = function() if IsValid(f) then f:Remove() end end

    local card = vgui.Create("DPanel", f) card:SetSize(cardW, cardH) card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
    card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
    card.Paint = function(s, w, h)
        local a = (cal.frame and cal.frame._a or 255) / 255
        if EVO_UI then EVO_UI.PaintCard(w, h, a, R(16)) else RNDX.Draw(R(16), 0, 0, w, h, col.bg) end
        surface.SetDrawColor(ColorAlpha(col.accent, 255 * a)) surface.DrawRect(R(24), R(24), R(3), R(18))
        draw.SimpleText("CALENDRIER DES ÉVÉNEMENTS", "EVO_UI_Header", R(38), R(33), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        surface.SetDrawColor(ColorAlpha(col.divider, 150 * a)) surface.DrawRect(R(24), R(64), w - R(48), 1)
        -- Séparateur vertical entre la grille et le volet droit.
        surface.SetDrawColor(ColorAlpha(col.divider, 120 * a)) surface.DrawRect(R(24 + 560), R(80), 1, h - R(104))
    end

    -- Volets (positions en unités base, scalées par R).
    local LEFT_W = 540
    cal.grid  = vgui.Create("DPanel", card) cal.grid:SetPaintBackground(false)
    cal.grid:SetPos(R(24), R(82)) cal.grid:SetSize(R(LEFT_W), cardH - R(82 + 20))
    cal.grid:SetMouseInputEnabled(true)
    cal.right = vgui.Create("DPanel", card) cal.right:SetPaintBackground(false)
    cal.right:SetPos(R(24 + LEFT_W + 32), R(82)) cal.right:SetSize(cardW - R(24 + LEFT_W + 32 + 24), cardH - R(82 + 20))
    cal.right:SetMouseInputEnabled(true)

    RebuildGrid()
    RebuildRight()

    -- Croix de fermeture (au-dessus de tout).
    local x = vgui.Create("DButton", card) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(CARD_W - 42), R(19)) x:SetZPos(1000)
    x.Paint = function(s, w, h) draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.title or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
    x.DoClick = function() if IsValid(cal.frame) then cal.frame:Remove() end end

    -- Gestion d'un event MOTEUR en cours : bouton « Arrêter » qui APPARAÎT quand un event tourne
    -- sur CE serveur (état répliqué via la globale EVO_GM_ActiveEvent). Animateurs / SA.
    if EVO_Calendrier.IsAnimator(LocalPlayer()) then
        local gmLabels = { ZoneCapture = "Capture de Zone", Defusal = "Désamorçage", RiftEvents = "Faille", FlagCapture = "Drapeau", BatailleFactions = "Bataille des Factions" }
        local stopBtn = vgui.Create("DButton", card) stopBtn:SetText("") stopBtn:SetZPos(1000)
        stopBtn:SetSize(R(232), R(26)) stopBtn:SetPos(R(CARD_W - 42 - 240), R(20))
        stopBtn.Think = function(s) s:SetVisible((GetGlobalString("EVO_GM_ActiveEvent", "") or "") ~= "") end
        stopBtn.Paint = function(s, w, h)
            local id = GetGlobalString("EVO_GM_ActiveEvent", "")
            RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(col.accent, s:IsHovered() and 255 or 210))
            draw.SimpleText("Arrêter l'event : " .. (gmLabels[id] or id), "EVO_Cal_Small", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        stopBtn.DoClick = function() net.Start("EVO_Cal_GMStop") net.SendToServer() end
    end
end

-- ── Réception des données ────────────────────────────────────────────────────
net.Receive("EVO_Cal_Sync", function()
    cal.events = util.JSONToTable(net.ReadString() or "[]") or {}
    if IsValid(cal.frame) then
        RebuildGrid()
        -- On NE reconstruit pas le volet droit en plein formulaire d'ajout (préserve la saisie).
        if cal.mode ~= "add" then RebuildRight() end
    end
end)

-- ── Ouverture : commande + bind "calendrier" (tout le monde) ──────────────────
concommand.Add("evo_calendrier", function() EVO_OpenCalendrier() end)

hook.Add("PlayerButtonDown", "EVO_Cal::OpenBind", function(ply, btn)
    if ply ~= LocalPlayer() then return end
    if vgui.GetKeyboardFocus() then return end
    if IsValid(cal.frame) then return end
    if SysTime() - (closedAt or 0) < 0.3 then return end
    if not ply.GetBindKey then return end
    local k = ply:GetBindKey("calendrier")
    if k and k ~= 0 and btn == k then EVO_OpenCalendrier() end
end)

-- ── ANNONCE PUBLIQUE serveur-entier : un événement approche (UI de notification) ──
-- Reçue ~15 min avant (sv_main). Bannière animée en HAUT de l'écran, pour TOUS les joueurs
-- (pas seulement les animateurs : cl_main est chargé pour tout le monde). Slide-in + fondu.
-- DA propre : AUCUN emoji (Roboto ne les a pas -> carrés) ; accents/contours DESSINÉS.
local announce = nil -- { name, loc, mins, col, born, expire }
local ANNOUNCE_SHOW = 10 -- s à l'écran

net.Receive("EVO_Cal_Announce", function()
    local name = net.ReadString()
    local loc  = net.ReadString()
    local mins = net.ReadUInt(16)
    local r, g, b = net.ReadUInt(8), net.ReadUInt(8), net.ReadUInt(8)
    if EVO_EventAnnounce and EVO_EventAnnounce.Show then
        EVO_EventAnnounce.Show({
            kicker = EVO_EventAnnounce.KICKER_CAL,
            name = name, loc = loc, mins = mins,
            col = Color(r, g, b),
        })
        return
    end
    local now = RealTime()
    announce = { name = name, loc = loc, mins = mins, col = Color(r, g, b), born = now, expire = now + ANNOUNCE_SHOW }
    surface.PlaySound("friends/friend_online.wav") -- chime de notification
end)

hook.Add("HUDPaint", "EVO_Cal::AnnounceBanner", function()
    if not announce then return end
    local now = RealTime()
    if now >= announce.expire then announce = nil return end
    local col    = C()
    local appear = math.Clamp((now - announce.born) / 0.4, 0, 1)              -- slide-in 0,4s
    local fade   = math.Clamp((announce.expire - now) / 1.0, 0, 1)           -- fondu sur la dernière sec
    local A      = 255 * fade

    local label = "ÉVÉNEMENT À VENIR"
    local name  = announce.name
    local sub   = "Commence dans " .. announce.mins .. " min"
    if announce.loc ~= "" then sub = sub .. "   ·   " .. announce.loc end -- " · " = OK dans Roboto (pas un emoji)

    surface.SetFont("EVO_Cal_AnnTitle") local lw, lh = surface.GetTextSize(label)
    surface.SetFont("EVO_Cal_AnnName")  local nw, nh = surface.GetTextSize(name)
    surface.SetFont("EVO_Cal_AnnSub")   local sw, sh = surface.GetTextSize(sub)

    local accW = R(46)                                 -- petit trait d'accent (remplace le carré)
    local padX = R(42)
    local boxW = math.max(lw, nw, sw, accW) + padX * 2
    local boxH = R(16) + lh + R(9) + R(2) + R(11) + nh + R(7) + sh + R(16)
    local boxX = math.floor((ScrW() - boxW) * 0.5)
    local boxY = math.floor(Lerp(appear, -boxH - R(20), R(70)))             -- glisse depuis le haut
    local cx   = math.floor(ScrW() * 0.5)

    -- Carte arrondie + fin contour à la couleur du thème (élégant, pas de barre carrée).
    RNDX.Draw(R(12), boxX, boxY, boxW, boxH, ColorAlpha(Color(13, 13, 16), A))
    RNDX.DrawOutlined(R(12), boxX, boxY, boxW, boxH, ColorAlpha(announce.col, A * 0.5), 1.5)

    local y = boxY + R(16)
    draw.SimpleText(label, "EVO_Cal_AnnTitle", cx, y, ColorAlpha(announce.col, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    y = y + lh + R(9)
    -- Petit trait d'accent centré, DESSINÉ (remplace l'ancien carré/emoji).
    surface.SetDrawColor(announce.col.r, announce.col.g, announce.col.b, A)
    surface.DrawRect(math.floor(cx - accW * 0.5), y, accW, R(2))
    y = y + R(2) + R(11)
    draw.SimpleText(name, "EVO_Cal_AnnName", cx, y, ColorAlpha(col.title, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    y = y + nh + R(7)
    draw.SimpleText(sub, "EVO_Cal_AnnSub", cx, y, ColorAlpha(col.muted, A), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)
