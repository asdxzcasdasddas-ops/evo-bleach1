-- "addons\\evo_calendrier\\lua\\evo_calendrier\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CALENDRIER — config PARTAGÉE (client + serveur).
--   * EVO_Calendrier.EventTypes : les TYPES d'événements prédéfinis. Chaque type
--     porte un mode d'emploi (instructions) qui EXPLIQUE à l'animateur quoi faire.
--     -> Pour ajouter un type : copier une entrée et l'ajouter à la table.
--   * EVO_Calendrier.IsAnimator : qui peut PLACER/animer un événement (mêmes droits
--     que l'UI Animateur : groupe animateur / admin / superadmin / staff).
-- ============================================================================

EVO_Calendrier = EVO_Calendrier or {}

EVO_Calendrier.Config = {
    -- Lecture cross-serveur ADAPTATIVE (comme flagcapture) : tant que rien ne change
    -- côté DB, l'intervalle double jusqu'au max ; un changement/ouverture le ramène au base.
    ReadInterval    = 20,        -- s : cadence de lecture de base de la table partagée
    ReadMaxInterval = 120,       -- s : cadence max quand rien ne bouge
    -- On GARDE un événement jusqu'à X après son heure de début (utile pour les events en cours /
    -- récap), puis il est purgé automatiquement de la DB.
    PurgePastAfter  = 6 * 3600,  -- 6 h après l'heure de début
    PurgeInterval   = 300,       -- s : cadence de la purge des events passés
    -- Bornes de saisie (anti-abus / réseau).
    MaxLocationLen  = 80,
    MaxNoteLen      = 500,       -- note libre de l'animateur (multi-lignes, assez longue pour détailler)
    MaxFutureDays   = 366,       -- on refuse un event à plus d'un an
    MaxPastHours    = 6,         -- on refuse un event à plus de 6 h dans le passé
    MaxEventsPerAnimator = 20,   -- garde-fou : max d'events futurs créés par un même animateur
    -- Rappel "préparez-vous" : notif envoyée à l'hôte + aux inscrits ce délai AVANT le début.
    NotifyBeforeSeconds = 15 * 60, -- 15 min (hôte + inscrits)
    NotifyCheckInterval = 30,      -- s : cadence de vérification des rappels/annonces
    -- ANNONCE PUBLIQUE serveur-entier : bannière HUD 15 min puis 5 min avant le début.
    AnnounceBeforeSeconds = 15 * 60,
    AnnounceOffsets = { 15 * 60, 5 * 60 },
    -- Events MOTEUR (game_manager) : fenêtre de grâce après l'heure prévue pendant laquelle on
    -- (re)tente de démarrer l'event (utile si le verrou global game_manager est occupé). Au-delà,
    -- on abandonne et on prévient les SuperAdmins.
    GMTriggerGrace = 300, -- 5 min
}

-- ── Qui peut animer (placer / s'inscrire / supprimer) ─────────────────────────
-- MÊME logique que evo_animateur (isAnimator) : le calendrier (ouverture + gestion + bind) est
-- réservé au PERSO ANIMATEUR (slot 4/5 + groupe "animateur" -> NWBool serveur EVO_AnimChar, non
-- spoofable) ou superadmin. Un compte animateur sur un perso RP NORMAL n'y a PAS accès, et un
-- joueur lambda ne voit pas le calendrier. NWBool + IsSuperAdmin marchent client ET serveur.
function EVO_Calendrier.IsAnimator(ply)
    if not IsValid(ply) then return false end
    if ply:IsSuperAdmin() then return true end
    return ply:GetEvoNWBool("EVO_AnimChar", false) == true
end

-- Libellé du serveur courant (déduit de la map) : affiché sur l'event ("créé sur …").
function EVO_Calendrier.GetServerLabel()
    return (game.GetMap() == "hueco_mundo_v1") and "Hueco Mundo" or "Seireitei"
end

-- ── TYPES / THÈMES D'ÉVÉNEMENTS PRÉDÉFINIS ───────────────────────────────────
-- Une liste de thèmes prêts à l'emploi (il suffit d'en rajouter pour en avoir plus).
-- Chaque type : id unique, nom, couleur {r,g,b}, résumé court, description (affichée en
-- évidence), durée indicative (min) et des INSTRUCTIONS pas-à-pas (ce que l'animateur fait).
EVO_Calendrier.EventTypes = {
    {
        id       = "chasse_hollow",
        name     = "Chasse aux Hollows",
        color    = { 207, 68, 78 },
        short    = "Chasse à une horde de Hollows menée par l'animateur.",
        -- DESCRIPTION (affichée bien en évidence dans la fiche) : doit suffire à comprendre
        -- l'événement sans explication supplémentaire (demande user).
        description = "Des Gargantas s'ouvrent et déversent une horde de Hollows sur la zone, menée par " ..
            "un Hollow surpuissant. Partez à la chasse : traquez et éliminez tous les Hollows qui surgissent, " ..
            "combattez en groupe et ne vous laissez pas déborder. Les chasseurs les plus efficaces seront " ..
            "récompensés par l'animateur à la fin de l'événement. Rendez-vous sur le lieu indiqué à l'heure " ..
            "prévue — soyez prêts au combat (réiatsu plein, équipement en ordre).",
        duration = 30, -- minutes (indicatif, affiché)
        instructions = {
            "Fais une NARRATION pour planter le décor et annoncer la zone où l'événement se déroule (des Gargantas s'ouvrent...).",
            "Transforme-toi en Hollow / Vasto Lorde avec BEAUCOUP de PV (UI Animateur ▸ HOLLOW — mets une grosse valeur de PV) : tu es le Hollow surpuissant à abattre.",
            "Ouvre un Garganta pour faire surgir une vague de Hollows (UI Animateur ▸ CHASSE AUX HOLLOWS ▸ « Garganta + Hollows »).",
            "Vagues plus dures : « Garganta + Hollows DURS (boostés) » ; relance des Gargantas selon le nombre de joueurs présents.",
            "Combats les joueurs en tant que Hollow et laisse-les chasser la horde ; maintiens la pression.",
            "Récompense 5 joueurs AU HASARD avec tes 5 coffres (UI Animateur ▸ COFFRES) — distribution aléatoire.",
            "Termine par une NARRATION de fin, puis reviens humain (UI Animateur ▸ HOLLOW ▸ Revenir).",
        },
    },
    {
        id       = "tournoi_pvp",
        name     = "Tournoi PvP",
        color    = { 74, 144, 226 },
        short    = "Duels en élimination directe.",
        description = "Un tournoi de combat singulier : les participants s'affrontent en duels jusqu'au " ..
            "dernier debout. Inscrivez-vous, respectez les règles annoncées (zone de combat, sorts autorisés) " ..
            "et prouvez votre maîtrise du katana et du réiatsu. Le vainqueur remporte la récompense de l'animateur.",
        duration = 45,
        instructions = {
            "Rassemble les participants dans une ZONE D'ENTRAÎNEMENT (ils ne peuvent pas y mourir).",
            "Active le Mode Tournoi (UI Animateur ▸ TOURNOI) et invite tous les joueurs ; relance les invites au besoin.",
            "Lance le tournoi : les combats 1v1 sont tirés au HASARD et le bracket avance automatiquement.",
            "Suis le déroulement et arbitre si besoin (hors-zone = disqualifié).",
            "Récompense UNIQUEMENT le vainqueur (coffre / yens) et annonce la clôture.",
        },
    },
    {
        id       = "tournoi_famille", -- id CONSERVÉ (données calendrier existantes) ; libellés « Clan » (07/20)
        name     = "Tournoi de Clans",
        color    = { 224, 120, 200 },
        short    = "Affrontement entre clans.",
        description = "Les clans s'affrontent pour la gloire : chaque clan envoie ses champions et le " ..
            "dernier clan debout l'emporte. Présentez-vous avec votre clan, respectez les règles " ..
            "annoncées et prouvez la suprématie de votre lignée. Le clan gagnant remporte la récompense.",
        duration = 45,
        instructions = {
            "Rassemble les participants dans une ZONE D'ENTRAÎNEMENT (ils ne peuvent pas y mourir).",
            "Active le Mode Tournoi Clan (UI Animateur ▸ TOURNOI) et invite tous les joueurs ; relance les invites au besoin.",
            "Lance le tournoi : les combats sont tirés au HASARD entre clans et le bracket avance automatiquement.",
            "Suis le déroulement et arbitre si besoin (hors-zone = disqualifié).",
            "Récompense UNIQUEMENT le clan gagnant (coffres / yens) et annonce la clôture.",
        },
    },
    {
        id       = "invasion_menos",
        name     = "Invasion de Menos",
        color    = { 170, 100, 220 },
        short    = "Un Menos / boss déferle sur la zone.",
        description = "Une menace colossale surgit : un Menos Grande — voire un boss — apparaît et menace la zone. " ..
            "Toutes les forces présentes doivent unir leurs efforts pour l'abattre. Combat de groupe intense ; les " ..
            "combattants les plus acharnés sont récompensés.",
        duration = 30,
        instructions = {
            "Fais une NARRATION pour annoncer la menace et la zone où elle surgit.",
            "Fais apparaître le Menos / boss (UI Animateur ▸ BOSS) — ou INCARNE-le (POSSESSION) pour un combat vivant.",
            "Règle ses PV / dégâts selon le nombre de joueurs présents.",
            "Laisse les joueurs l'affronter ; relance la pression si le combat traîne.",
            "Récompense les meilleurs (coffre), puis nettoie tes entités (UI Animateur ▸ MES ENTITÉS).",
        },
    },
    {
        id       = "scenario_rp",
        name     = "Scénario RP",
        color    = { 207, 68, 78 },
        short    = "Événement narratif / intrigue à jouer.",
        description = "Un événement scénarisé : une intrigue se joue (mystère, menace, négociation, trahison…). " ..
            "Les choix des joueurs influencent le déroulement. Privilégiez le RP : suivez l'animateur et incarnez " ..
            "votre personnage.",
        duration = 60,
        instructions = {
            "Prépare ton intrigue (contexte, PNJ, rebondissements) avant l'heure.",
            "Lance la scène par une NARRATION immersive (plante le décor et l'enjeu).",
            "Incarne les PNJ via la POSSESSION et fais surgir des ennemis (BOSS / Garganta) si l'intrigue l'exige.",
            "Fais avancer l'histoire selon les actions des joueurs.",
            "Conclus par une NARRATION de fin et distribue d'éventuelles récompenses.",
        },
    },
    {
        id       = "defense",
        name     = "Défense de zone",
        color    = { 60, 170, 200 },
        short    = "Tenir une position face à des vagues.",
        description = "Une position clé doit être tenue face à des vagues d'ennemis de plus en plus fortes. " ..
            "Coordonnez-vous, tenez la ligne et ne laissez rien passer. Plus vous survivez de vagues, meilleure " ..
            "est la récompense.",
        duration = 30,
        instructions = {
            "Fais une NARRATION pour annoncer la position à défendre et la menace.",
            "Lance les vagues : Gargantas de Hollows (UI Animateur ▸ CHASSE AUX HOLLOWS) et/ou boss (BOSS).",
            "Monte la difficulté à chaque vague tenue (Hollows DURS, plus de PV / dégâts).",
            "Récompense les défenseurs survivants (coffre).",
            "Nettoie tes entités à la fin (CHASSE AUX HOLLOWS ▸ Supprimer / MES ENTITÉS).",
        },
    },
    {
        id       = "boss_mondial",
        name     = "Boss Mondial (event)",
        color    = { 207, 68, 78 },
        short    = "Boss surpuissant pour tout le serveur.",
        description = "Un adversaire d'une puissance écrasante apparaît : l'événement à ne pas manquer. Toutes les " ..
            "forces du serveur sont nécessaires pour en venir à bout. Combat épique, fortes récompenses pour ceux " ..
            "qui infligent le plus de dégâts.",
        duration = 40,
        instructions = {
            "Fais une NARRATION d'ouverture (l'apparition du boss, le danger pour tout le serveur).",
            "Fais apparaître un boss très résistant (UI Animateur ▸ BOSS), gros PV / dégâts.",
            "INCARNE-le (POSSESSION) pour un combat scénarisé si tu veux.",
            "Encourage la coordination de tout le serveur ; relance la pression.",
            "Récompense les meilleurs, puis nettoie tes entités.",
        },
    },

    -- ── EVENTS MOTEUR (automatisés via game_manager) ─────────────────────────────
    -- Ces thèmes portent un champ `gm_event` : une fois l'event VALIDÉ par un SuperAdmin,
    -- le système game_manager le DÉMARRE TOUT SEUL à l'heure prévue (sur le serveur de la map
    -- où il a été créé), en choisissant une zone configurée au hasard. Pré-requis : des zones
    -- doivent être configurées dans le Game Manager pour le type concerné.
    {
        id       = "gm_defuse",
        name     = "Désamorçage (Defuse)",
        color    = { 230, 160, 60 },
        short    = "Course contre la montre pour désamorcer les bombes (automatisé).",
        gm_event = "Defusal",
        gm_params = {
            { key = "radius",         label = "Rayon de la zone", default = 500, min = 100, max = 5000 },
            { key = "BombCount",      label = "Nombre de bombes", default = 2,   min = 1,   max = 20 },
            { key = "EventDuration",  label = "Durée désamorçage (s)", default = 15, min = 5, max = 600 },
            -- Faction qui DÉFEND les bombes (les protège -> gagne si elles ne sont pas désamorcées).
            -- L'autre faction ATTAQUE (doit désamorcer). Le défenseur est prévenu de la zone
            -- "Avance défenseurs" secondes AVANT que l'attaquant ne soit alerté.
            { key = "DefendFaction",  label = "Faction qui défend les bombes", choices = { "Shinigami", "Hollow" }, default = "Hollow" },
            { key = "DefendPrepTime", label = "Avance défenseurs (s)", default = 300, min = 0, max = 1800 },
        },
        description = "Des bombes sont amorcées sur la zone. Une faction les DÉFEND (et gagne si elles explosent), " ..
            "l'autre doit les DÉSAMORCER avant la fin du compte à rebours. La faction défenseuse est prévenue de la " ..
            "zone ~5 min AVANT l'attaquante, pour se mettre en place. Événement AUTOMATISÉ : le système fait apparaître " ..
            "les bombes, alerte chaque camp au bon moment et gère le minuteur.",
        duration = 20,
        instructions = {
            "À la CRÉATION (formulaire) : définis la ZONE à ta position + les paramètres (rayon, bombes, durée, FACTION DÉFENSEUSE, avance défenseurs).",
            "Un SuperAdmin doit VALIDER l'event.",
            "À l'heure prévue : la faction DÉFENSEUSE est prévenue de la zone et la défend ; ~5 min après, la faction ATTAQUANTE est alertée et le compte à rebours de désamorçage démarre.",
            "Le désamorçage est réservé à la faction ATTAQUANTE (= l'opposée de la défenseuse) ; les défenseurs tiennent la zone.",
            "Fais une NARRATION (sabotage, menace) et supervise / arbitre.",
            "Récompenses : c'est À TOI de les donner (PAS d'automatique) — distribue les coffres aux joueurs méritants via UI Animateur ▸ COFFRES.",
        },
    },
    {
        id       = "gm_faille",
        name     = "Faille Dimensionnelle",
        color    = { 150, 90, 210 },
        short    = "Une faille déverse des vagues de Hollows (automatisé).",
        gm_event = "RiftEvents",
        gm_params = {
            { key = "radius",     label = "Rayon de la zone", default = 500, min = 100, max = 5000 },
            { key = "difficulty", label = "Difficulté", choices = { "facile", "moyenne", "difficile" }, default = "moyenne" },
        },
        description = "Une faille s'ouvre et déverse des vagues de Hollows toujours plus nombreuses. Repoussez " ..
            "l'invasion en équipe : plus vous tenez, plus la menace s'intensifie. Événement AUTOMATISÉ : le système " ..
            "ouvre la faille et gère les vagues. Rendez-vous sur place, réiatsu plein.",
        duration = 25,
        instructions = {
            "À la CRÉATION (formulaire) : définis la ZONE à ta position + les paramètres (rayon, difficulté).",
            "Un SuperAdmin doit VALIDER l'event.",
            "À l'heure prévue, un GARGANTA s'ouvre à chaque vague et déverse les Hollows TOUT SEUL.",
            "Fais une NARRATION pour annoncer la faille ; supervise le combat.",
            "Récompenses AUTOMATIQUES à la fin : top 10 des DÉGÂTS infligés aux Hollows (1er coffre légendaire, 2e/3e épique, 4e-10e rare). Rien à donner toi-même.",
        },
    },
}

-- Accès direct à un type par id.
function EVO_Calendrier.GetType(id)
    for _, t in ipairs(EVO_Calendrier.EventTypes) do
        if t.id == id then return t end
    end
    return nil
end

-- Renvoie le module game_manager associé à un type ("ZoneCapture" / "Defusal" / "RiftEvents"),
-- ou nil si le thème n'est pas un event moteur. Sert au déclenchement automatique côté serveur
-- et à l'affichage "automatisé" côté client.
function EVO_Calendrier.GetGMEvent(typeId)
    local t = EVO_Calendrier.GetType(typeId)
    return t and t.gm_event or nil
end

-- Normalise/valide les paramètres d'un event moteur selon gm_params : clamp des nombres
-- (min/max, entier sauf si float), validation des choix, et défauts pour tout champ manquant.
-- Renvoie TOUJOURS une table complète (tous les keys de gm_params). Utilisé serveur (anti-triche)
-- ET client (pré-remplissage). istable/tonumber/math.floor existent client+serveur.
function EVO_Calendrier.NormalizeGMParams(typeId, raw)
    local out = {}
    local t = EVO_Calendrier.GetType(typeId)
    if not (t and t.gm_params) then return out end
    raw = istable(raw) and raw or {}
    for _, p in ipairs(t.gm_params) do
        local v = raw[p.key]
        if p.choices then
            local ok = false
            for _, c in ipairs(p.choices) do if v == c then ok = true break end end
            out[p.key] = ok and v or p.default
        else
            v = tonumber(v) or p.default
            if p.min and v < p.min then v = p.min end
            if p.max and v > p.max then v = p.max end
            if not p.float then v = math.floor(v) end
            out[p.key] = v
        end
    end
    return out
end

-- Id réservé aux événements PERSONNALISÉS (sans thème prédéfini) : l'animateur spécifie tout
-- lui-même (nom + description). Couleur neutre par défaut.
EVO_Calendrier.CUSTOM_ID    = "custom"
EVO_Calendrier.CUSTOM_COLOR = { 150, 154, 162 }

-- Infos d'AFFICHAGE d'un event (résout thème prédéfini OU custom). Renvoie TOUJOURS une table
-- { name, color, description, instructions, isCustom }. Utilisé client (rendu) ET serveur (annonce).
function EVO_Calendrier.GetEventInfo(e)
    local t = EVO_Calendrier.GetType(e.type)
    if t then return t end
    return {
        name         = (isstring(e.cname) and e.cname ~= "" and e.cname) or "Événement",
        color        = EVO_Calendrier.CUSTOM_COLOR,
        description  = e.note or "",
        instructions = nil,
        isCustom     = true,
    }
end

-- Vrai si l'heure prévue de l'événement est DÉPASSÉE. e.time est un timestamp UNIX absolu
-- (comparable client/serveur via os.time(), contrairement à CurTime qui est local). Sert à
-- afficher l'événement BARRÉ / "terminé" dans le calendrier une fois passé (rendu client).
function EVO_Calendrier.IsEventPast(e)
    return (tonumber(e and e.time) or 0) < os.time()
end
