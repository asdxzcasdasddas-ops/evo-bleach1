-- "addons\\lzy_damage_indicator\\lua\\autorun\\lzy_damage_indicator_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_damage_indicator/cl_damage_indicator.lua")
    include("lzy_damage_indicator/sv_damage_indicator.lua")
    resource.AddFile("materials/damage_icon.png")
else
    include("lzy_damage_indicator/cl_damage_indicator.lua")
end
