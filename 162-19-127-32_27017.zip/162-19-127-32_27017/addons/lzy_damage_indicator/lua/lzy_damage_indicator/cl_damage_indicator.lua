-- "addons\\lzy_damage_indicator\\lua\\lzy_damage_indicator\\cl_damage_indicator.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local indicators = {}
local damage_mat = Material("materials/damage_icon.png", "smooth")
local display_time = 0.5
local base_radius = 150
local base_size = 58

net.Receive("LZY_DamageIndicator", function()
    local pos = net.ReadVector()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local hitVec = (pos - ply:GetPos())
    hitVec.z = 0
    hitVec:Normalize()
    
    local hitAng = hitVec:Angle().y
    local eyeAng = ply:EyeAngles().y
    local diff = math.AngleDifference(eyeAng, hitAng)

    table.insert(indicators, {
        angle = diff,
        time = CurTime()
    })
end)

hook.Add("HUDDamageIndicator", "LZY_DamageIndicator_HideDefault", function()
    return true
end)

hook.Add("HUDShouldDraw", "LZY_DamageIndicator_HideHUD", function(name)
    if name == "CHudDamageIndicator" then return false end
end)

hook.Add("HUDPaint", "LZY_DamageIndicator_Draw", function()
    if #indicators == 0 then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local cx, cy = ScrW() / 2, ScrH() / 2
    local curTime = CurTime()
    
    local r = base_radius
    local size = base_size
    
    if gRespX and gRespY then
        r = gRespY(base_radius)
        size = gRespX(base_size)
    end

    for i = #indicators, 1, -1 do
        local data = indicators[i]
        local timeDiff = curTime - data.time
        
        if timeDiff > display_time then
            table.remove(indicators, i)
        else
            local alpha = 255 * (1 - (timeDiff / display_time))
            local diff = data.angle
            local rad = math.rad(diff)
            local x = cx + math.sin(rad) * r
            local y = cy - math.cos(rad) * r
            
            surface.SetMaterial(damage_mat)
            surface.SetDrawColor(255, 255, 255, alpha)
            surface.DrawTexturedRectRotated(x, y, size, size, -diff)
        end
    end
end)
