-- "addons\\evo_events\\lua\\entities\\evo_event_coffre.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- COFFRE ENFOUI (evo_events) : un coffre des maps (pack #10) qui affleure du
-- sol, repere de loin par un eclat. On le deterre (E maintenu) : il sort de
-- terre, s'ouvre, et donne un coffre de butin tire comme partout ailleurs
-- (EVO_LOOT.GiveRandomChest, memes probabilites).
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Coffre enfoui"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Acteur")
	self:NetworkVar("Float", 0, "HoldDebut")
	self:NetworkVar("Float", 1, "HoldDuree")
	self:NetworkVar("Float", 2, "Profondeur")  -- de combien il est enfonce
	self:NetworkVar("Float", 3, "Deterre")     -- instant ou il a ete sorti, 0 = enfoui
end

function ENT:EvoCentre()
	return self:GetPos() + Vector(0, 0, self:GetProfondeur() + 10)
end

if SERVER then
	local SABLE = { "player/footsteps/sand1.wav", "player/footsteps/sand2.wav", "player/footsteps/sand3.wav", "player/footsteps/sand4.wav" }

	function ENT:Initialize()
		self:SetModel(EVO_EVENTS.Config.modeleCoffre)
		self:SetMoveType(MOVETYPE_NONE)
		self:SetSolid(SOLID_NONE)
		self:DrawShadow(false)
		-- Enfonce aux deux tiers : seul le couvercle depasse, un peu de biais.
		local h = self:OBBMaxs().z - self:OBBMins().z
		local nProf = math.max(8, h * 0.66)
		self:SetProfondeur(nProf)
		self:SetPos(self:GetPos() - Vector(0, 0, nProf))
		self:SetAngles(Angle(math.Rand(-10, 10), math.Rand(0, 360), math.Rand(-12, 12)))
		EVO_EVENTS.Inscrire(self)
		timer.Simple(EVO_EVENTS.Config.coffreVie, function() if IsValid(self) then self:Remove() end end)
	end

	function ENT:OnRemove() EVO_EVENTS.Desinscrire(self) end
	function ENT:UpdateTransmitState() return TRANSMIT_PVS end

	ENT.EvoAction = {
		portee = 150,
		duree = function() return EVO_EVENTS.Config.dureeFouille end,
		peut = function(_, ent)
			if ent:GetDeterre() > 0 then return false end
			return true
		end,
		tic = function(_, ent)
			if (ent._tic or 0) < CurTime() then
				ent._tic = CurTime() + 0.45
				ent:EmitSound(SABLE[math.random(#SABLE)], 70, math.random(80, 95), 0.9)
			end
		end,
		fin = function(ply, ent)
			EVO_EVENTS.Desinscrire(ent)
			ent:SetDeterre(CurTime())
			ent:EmitSound("items/ammocrate_open.wav", 75, 90, 0.9)
			EVO_EVENTS.CoffreOuvert(ply)
			timer.Simple(5, function() if IsValid(ent) then ent:Remove() end end)
		end,
	}
	return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local MAT_GLOW = Material("sprites/light_glow02_add")

function ENT:Initialize()
	self._phase = math.Rand(0, 6.28)
	self._prochainePoussiere = 0
end

function ENT:Think()
	-- Du sable qui vole pendant qu'on creuse.
	local a = self:GetActeur()
	if IsValid(a) and CurTime() > self._prochainePoussiere then
		self._prochainePoussiere = CurTime() + 0.12
		local em = EVO_EVENTS.Emetteur and EVO_EVENTS.Emetteur()
		if em then
			local p = em:Add("particle/smokesprites_0001", self:EvoCentre() + VectorRand() * 16)
			if p then
				p:SetVelocity(VectorRand() * 50 + Vector(0, 0, 70))
				p:SetGravity(Vector(0, 0, -150))
				p:SetDieTime(math.Rand(0.8, 1.4))
				p:SetStartAlpha(150) p:SetEndAlpha(0)
				p:SetStartSize(8) p:SetEndSize(26)
				p:SetRoll(math.Rand(0, 360))
				p:SetColor(196, 168, 120)
				p:SetLighting(false) p:SetCollide(false)
			end
		end
	end
end

function ENT:DrawTranslucent()
	local t = CurTime()
	local nDet = self:GetDeterre()
	local sortie = 0
	if nDet > 0 then
		-- Il sort de terre en 0,8 s, en ralentissant, puis s'efface.
		local u = math.Clamp((t - nDet) / 0.8, 0, 1)
		sortie = (1 - (1 - u) ^ 3) * self:GetProfondeur()
		local fondu = 1 - math.Clamp((t - nDet - 3.5) / 1.5, 0, 1)
		render.SetBlend(fondu)
	end
	self:SetRenderOrigin(self:GetPos() + Vector(0, 0, sortie))
	self:SetupBones()
	self:DrawModel()
	self:SetRenderOrigin()
	render.SetBlend(1)

	-- L'eclat qui le trahit de loin : un scintillement toutes les deux secondes.
	if nDet <= 0 then
		local c = self:EvoCentre()
		local u = ((t + self._phase) % 2.2) / 2.2
		local k = math.max(0, 1 - math.abs(u - 0.5) * 8)
		if k > 0 then
			render.SetMaterial(MAT_GLOW)
			render.DrawSprite(c + Vector(0, 0, 6), 90 * k, 90 * k, Color(255, 240, 190, 255 * k))
			render.DrawSprite(c + Vector(0, 0, 6), 8, 60 * k, Color(255, 255, 230, 220 * k))
		end
		if EVO_EVENTS.DessinerInvite then
			EVO_EVENTS.DessinerInvite(self, c + Vector(0, 0, 34), "Coffre enfoui", "E maintenu : déterrer")
		end
	end
end
