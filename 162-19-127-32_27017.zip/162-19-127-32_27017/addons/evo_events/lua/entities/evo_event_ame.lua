-- "addons\\evo_events\\lua\\entities\\evo_event_ame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- AME ERRANTE (evo_events, Nuit des ames errantes) : une lueur bleue qui erre
-- au ras du sol. Un Shinigami la guide (konso), un Hollow la devore. Le serveur
-- ne garde qu'un point d'ancrage ; l'errance est calculee par chaque client a
-- partir du temps et du numero de l'entite, donc la meme chez tout le monde.
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Âme errante"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Acteur")
	self:NetworkVar("Float", 0, "HoldDebut")
	self:NetworkVar("Float", 1, "HoldDuree")
end

-- L'errance autour de l'ancrage : trois sinus lents par axe, jamais periodique a
-- l'oeil. Partagee : le serveur s'en sert pour viser la bonne position.
function ENT:Errance(t)
	local i = self:EntIndex()
	return Vector(
		math.sin(t * 0.21 + i) * 48 + math.sin(t * 0.53 + i * 2.1) * 20,
		math.cos(t * 0.17 + i * 1.3) * 48 + math.sin(t * 0.47 + i * 0.7) * 20,
		math.sin(t * 0.9 + i * 0.4) * 10)
end

-- Ou est l'ame A CET INSTANT : c'est la que le joueur vise pour agir. Nom a
-- nous : surcharger WorldSpaceCenter du moteur tromperait d'autres addons.
function ENT:EvoCentre()
	return self:GetPos() + self:Errance(CurTime())
end

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/props_junk/PopCan01a.mdl")
		self:SetMoveType(MOVETYPE_NONE)
		self:SetSolid(SOLID_NONE)
		self:DrawShadow(false)
		EVO_EVENTS.Inscrire(self)
	end

	function ENT:OnRemove() EVO_EVENTS.Desinscrire(self) end
	function ENT:UpdateTransmitState() return TRANSMIT_PVS end

	ENT.EvoAction = {
		portee = 170,
		duree = function() return EVO_EVENTS.Config.dureeAme end,
		peut = function(ply)
			local f = EVO_EVENTS.Faction(ply)
			if f == "Shinigami" or f == "Hollow" or f == "HollowLarva" then return true end
			return false, "Seuls un Shinigami (konsō) ou un Hollow (dévorer) peuvent agir sur une âme."
		end,
		fin = function(ply, ent)
			local f = EVO_EVENTS.Faction(ply)
			local pos = ent:EvoCentre()
			ent:Remove()
			if f == "Shinigami" then
				EVO_EVENTS.Fx("ame", { pos = pos, mode = "konso" })
				EVO_EVENTS.DonnerYens(ply, EVO_EVENTS.Config.yensKonso)
				EVO_EVENTS.Notifier(ply, "Konsō : l'âme trouve le chemin de la Soul Society.")
			else
				EVO_EVENTS.Fx("ame", { pos = pos, mode = "devore" })
				EVO_EVENTS.DonnerYens(ply, EVO_EVENTS.Config.yensDevore)
				EVO_EVENTS.Notifier(ply, "Tu dévores l'âme. Ta faim s'apaise un instant.")
			end
		end,
	}
	return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local MAT_GLOW = Material("sprites/light_glow02_add")
local MURMURES = {
	"ambient/levels/citadel/strange_talk1.wav", "ambient/levels/citadel/strange_talk3.wav",
	"ambient/levels/citadel/strange_talk5.wav", "ambient/levels/citadel/strange_talk8.wav",
}

function ENT:Initialize()
	self._phase = math.Rand(0, 6.28)
	self._prochainMurmure = CurTime() + math.Rand(3, 10)
	self._prochaineTraine = 0
end

function ENT:Think()
	local pos = self:EvoCentre()
	local dl = DynamicLight(self:EntIndex())
	if dl then
		dl.pos = pos
		dl.r, dl.g, dl.b = 120, 190, 255
		dl.brightness = 0.9 + math.sin(CurTime() * 2.3 + self._phase) * 0.3
		dl.size = 160
		dl.decay = 800
		dl.dietime = CurTime() + 0.2
	end
	local lp = LocalPlayer()
	local d = IsValid(lp) and lp:GetPos():Distance(pos) or 99999
	-- Un murmure de temps en temps, seulement a portee d'oreille.
	if d < 700 and CurTime() > self._prochainMurmure then
		self._prochainMurmure = CurTime() + math.Rand(8, 16)
		self:EmitSound(MURMURES[math.random(#MURMURES)], 60, math.random(90, 110), 0.18)
	end
	-- La traine : quelques volutes qui restent derriere elle.
	if d < 2500 and CurTime() > self._prochaineTraine then
		self._prochaineTraine = CurTime() + 0.12
		local em = EVO_EVENTS.Emetteur and EVO_EVENTS.Emetteur()
		if em then
			local p = em:Add("sprites/light_glow02_add", pos + VectorRand() * 6)
			if p then
				p:SetVelocity(VectorRand() * 6 + Vector(0, 0, 8))
				p:SetDieTime(math.Rand(1.2, 2))
				p:SetStartAlpha(120) p:SetEndAlpha(0)
				p:SetStartSize(math.Rand(6, 10)) p:SetEndSize(1)
				p:SetColor(150, 210, 255)
				p:SetLighting(false) p:SetCollide(false)
			end
		end
	end
end

function ENT:DrawTranslucent()
	local t = CurTime()
	local pos = self:EvoCentre()
	local k = 0.8 + 0.2 * math.sin(t * 2.3 + self._phase)
	render.SetMaterial(MAT_GLOW)
	render.DrawSprite(pos, 22 * k, 30 * k, Color(235, 248, 255, 255))
	render.DrawSprite(pos, 70 * k, 80 * k, Color(120, 190, 255, 150))
	render.DrawSprite(pos, 160, 160, Color(80, 140, 255, 40))

	if EVO_EVENTS.DessinerInvite then
		local f = LocalPlayer().GetCharFaction and LocalPlayer():GetCharFaction() or ""
		local sAction = (f == "Shinigami") and "E : konsō (guider l'âme)"
			or ((f == "Hollow" or f == "HollowLarva") and "E : dévorer l'âme" or "Une âme errante")
		EVO_EVENTS.DessinerInvite(self, pos + Vector(0, 0, 36), "Âme errante", sAction)
	end
end
