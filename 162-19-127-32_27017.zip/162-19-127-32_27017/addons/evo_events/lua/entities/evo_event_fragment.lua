-- "addons\\evo_events\\lua\\entities\\evo_event_fragment.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- FRAGMENT (evo_events) : le noyau d'un meteore ou un eclat de la Sphere, tombe
-- au sol. Un scientifique l'analyse (E maintenu) : yens, XP de science, et pour
-- un eclat de la Sphere, la jauge commune monte. Modele : un cristal des
-- objets EVO (pack #5), qui flotte et tourne dans son halo.
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Fragment"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Acteur")
	self:NetworkVar("Float", 0, "HoldDebut")
	self:NetworkVar("Float", 1, "HoldDuree")
	self:NetworkVar("String", 0, "Genre")   -- "orbe" ou "meteore"
end

if SERVER then
	function ENT:Initialize()
		self:SetModel(EVO_EVENTS.Config.modeleFragment)
		self:SetModelScale(2.2, 0)
		self:SetMoveType(MOVETYPE_NONE)
		self:SetSolid(SOLID_NONE)
		self:DrawShadow(false)
		self:SetAngles(Angle(0, math.Rand(0, 360), 0))
		EVO_EVENTS.Inscrire(self)
	end

	function ENT:OnRemove() EVO_EVENTS.Desinscrire(self) end
	function ENT:UpdateTransmitState() return TRANSMIT_PVS end

	local ZAPS = { "ambient/energy/spark1.wav", "ambient/energy/spark2.wav", "ambient/energy/spark3.wav", "ambient/energy/spark4.wav" }

	ENT.EvoAction = {
		duree = function() return EVO_EVENTS.Config.dureeAnalyse end,
		peut = function(ply)
			if EVO_SCIENCE and EVO_SCIENCE.IsScientist and EVO_SCIENCE.IsScientist(ply) then return true end
			if ply:IsSuperAdmin() then return true end -- pour tester l'evenement
			return false, "Seul un scientifique peut analyser ce fragment."
		end,
		debut = function(_, ent) ent:EmitSound("ambient/levels/labs/teleport_mechanism_windup2.wav", 65, 140, 0.4) end,
		tic = function(_, ent, dt)
			if (ent._tic or 0) < CurTime() then
				ent._tic = CurTime() + math.Rand(0.6, 1.1)
				ent:EmitSound(ZAPS[math.random(#ZAPS)], 60, math.random(110, 130), 0.35)
			end
		end,
		fin = function(ply, ent)
			local sGenre = ent:GetGenre()
			EVO_EVENTS.Fx("fragment_analyse", { pos = ent:WorldSpaceCenter(), genre = sGenre })
			ent:Remove()
			EVO_EVENTS.DonnerYens(ply, EVO_EVENTS.Config.yensFragment)
			if EVO_SCIENCE and EVO_SCIENCE.SciAddXP then EVO_SCIENCE.SciAddXP(ply) end
			if sGenre == "orbe" then
				EVO_EVENTS.OrbeAnalyse(ply)
			else
				EVO_EVENTS.Notifier(ply, "Noyau de météore analysé : une roche qui ne vient pas d'ici.")
			end
		end,
	}
	return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local MAT_GLOW = Material("sprites/light_glow02_add")
local COULEURS = { orbe = Color(190, 110, 255), meteore = Color(255, 140, 60) }

function ENT:Initialize()
	self._t0 = CurTime()
	self._phase = math.Rand(0, 6.28)
end

function ENT:Couleur() return COULEURS[self:GetGenre()] or COULEURS.meteore end

function ENT:Think()
	local c = self:Couleur()
	local dl = DynamicLight(self:EntIndex())
	if dl then
		dl.pos = self:GetPos() + Vector(0, 0, 20)
		dl.r, dl.g, dl.b = c.r, c.g, c.b
		dl.brightness = 1.6 + math.sin(CurTime() * 3 + self._phase) * 0.4
		dl.size = 220
		dl.decay = 1000
		dl.dietime = CurTime() + 0.2
	end
end

function ENT:DrawTranslucent()
	local t = CurTime()
	local c = self:Couleur()
	-- Il flotte et tourne : un objet pose immobile se lit comme un decor.
	local pos = self:GetPos() + Vector(0, 0, 16 + math.sin(t * 2 + self._phase) * 3)
	self:SetRenderOrigin(pos)
	self:SetRenderAngles(Angle(12, (t * 45) % 360, 0))
	self:SetupBones()
	self:DrawModel()
	self:SetRenderOrigin()
	self:SetRenderAngles()

	local k = 0.75 + 0.25 * math.sin(t * 3 + self._phase)
	render.SetMaterial(MAT_GLOW)
	render.DrawSprite(pos, 70 * k, 70 * k, Color(c.r, c.g, c.b, 210))
	render.DrawSprite(pos, 170, 170, Color(c.r, c.g, c.b, 55))

	if EVO_EVENTS.DessinerInvite then
		EVO_EVENTS.DessinerInvite(self, pos + Vector(0, 0, 30),
			self:GetGenre() == "orbe" and "Éclat de la sphère" or "Noyau de météore",
			"E maintenu : analyser (scientifiques)")
	end
end
