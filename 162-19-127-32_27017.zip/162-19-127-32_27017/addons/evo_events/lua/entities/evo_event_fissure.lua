-- "addons\\evo_events\\lua\\entities\\evo_event_fissure.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- FISSURE DE REIATSU (evo_events) : une dechirure verticale dans l'air, noire au
-- coeur, bordee de lumiere, qui crepite. Des vagues d'ennemis en sortent (le
-- serveur, sv_events) jusqu'a ce qu'un joueur la scelle (E maintenu).
--
-- LE DESSIN : un maillage « billboard cylindrique » (il tourne autour de la
-- verticale pour faire face a chacun), dont les deux bords sont brises par un
-- profil tire du numero de l'entite : la meme dechirure chez tous les joueurs.
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Fissure de reiatsu"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

local HAUT, LARGE, N = 210, 54, 14

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Acteur")
	self:NetworkVar("Float", 0, "HoldDebut")
	self:NetworkVar("Float", 1, "HoldDuree")
end

function ENT:EvoCentre() return self:GetPos() + Vector(0, 0, HAUT * 0.5) end

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/props_junk/PopCan01a.mdl")
		self:SetMoveType(MOVETYPE_NONE)
		self:SetSolid(SOLID_NONE)
		self:DrawShadow(false)
		EVO_EVENTS.Inscrire(self)
		self:EmitSound("ambient/levels/labs/teleport_postblast_thunder1.wav", 90, 90, 0.8)
	end

	function ENT:OnRemove() EVO_EVENTS.Desinscrire(self) end
	function ENT:UpdateTransmitState() return TRANSMIT_PVS end

	local ZAPS = { "ambient/energy/zap1.wav", "ambient/energy/zap2.wav", "ambient/energy/zap3.wav", "ambient/energy/zap5.wav" }

	ENT.EvoAction = {
		portee = 170,
		-- Les Shinigamis connaissent le kido de scellement : plus rapides.
		duree = function(ply)
			local n = EVO_EVENTS.Config.dureeScellement
			return EVO_EVENTS.Faction(ply) == "Shinigami" and n * 0.7 or n
		end,
		peut = function(ply)
			if EVO_EVENTS.Faction(ply) == "HollowLarva" then return false, "Une larve ne peut pas sceller une fissure." end
			return true
		end,
		debut = function(_, ent) ent:EmitSound("ambient/levels/labs/teleport_mechanism_windup1.wav", 75, 100, 0.6) end,
		tic = function(_, ent)
			if (ent._tic or 0) < CurTime() then
				ent._tic = CurTime() + math.Rand(0.4, 0.8)
				ent:EmitSound(ZAPS[math.random(#ZAPS)], 70, math.random(90, 120), 0.5)
			end
		end,
		fin = function(ply, ent) EVO_EVENTS.FissureScellee(ply, ent) end,
	}
	return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local MAT_NOIR = CreateMaterial("evo_ev_fissure_noir", "UnlitGeneric", {
	["$basetexture"] = "vgui/white", ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nocull"] = "1",
})
local MAT_BORD = CreateMaterial("evo_ev_fissure_bord", "UnlitGeneric", {
	["$basetexture"] = "sprites/light_glow02", ["$additive"] = "1", ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nocull"] = "1",
})
local MAT_ECLAIR = Material("sprites/lgtning")
local MAT_GLOW = Material("sprites/light_glow02_add")
local COEUR, BORD, HALO = Color(8, 2, 12, 250), Color(200, 90, 255), Color(150, 40, 220)

-- Le profil : pour chaque hauteur, le bord gauche et le bord droit. Tire une
-- fois (graine = numero de l'entite).
function ENT:Profil()
	if self._profil then return self._profil end
	local r = EVO_EVENTS.Rng(self:EntIndex() * 7919 + 17)
	local t = {}
	for i = 0, N do
		local u = i / N
		local enveloppe = math.sin(u * math.pi) ^ 0.75
		local w = enveloppe * LARGE * (0.5 + 0.5 * r())
		local dx = (r() - 0.5) * 22 * enveloppe
		t[i + 1] = { z = u * HAUT, g = dx - w * 0.5, d = dx + w * 0.5 }
	end
	self._profil = t
	return t
end

function ENT:Initialize()
	self._t0 = CurTime()
	self._son = CreateSound(self, "ambient/energy/electric_loop.wav")
	if self._son then self._son:SetSoundLevel(72) self._son:PlayEx(0.45, 70) end
	self._prochaineEtincelle = 0
end

function ENT:OnRemove()
	if self._son then self._son:Stop() end
end

function ENT:Think()
	local c = self:EvoCentre()
	local dl = DynamicLight(self:EntIndex())
	if dl then
		dl.pos = c
		dl.r, dl.g, dl.b = HALO.r, HALO.g, HALO.b
		dl.brightness = 2.2 + math.sin(CurTime() * 7) * 0.6
		dl.size = 340
		dl.decay = 1500
		dl.dietime = CurTime() + 0.2
	end
	-- Des etincelles arrachees aux bords, de temps en temps.
	if CurTime() > self._prochaineEtincelle then
		self._prochaineEtincelle = CurTime() + math.Rand(0.15, 0.4)
		local em = EVO_EVENTS.Emetteur and EVO_EVENTS.Emetteur()
		local P = self:Profil()
		if em then
			local k = P[math.random(2, #P - 1)]
			local p = em:Add("effects/spark", self:GetPos() + Vector(0, 0, k.z) + VectorRand() * 12)
			if p then
				p:SetVelocity(VectorRand() * 140 + Vector(0, 0, 60))
				p:SetGravity(Vector(0, 0, -300))
				p:SetDieTime(math.Rand(0.4, 0.9))
				p:SetStartAlpha(255) p:SetEndAlpha(0)
				p:SetStartSize(2) p:SetEndSize(0)
				p:SetStartLength(14) p:SetEndLength(2)
				p:SetColor(220, 140, 255)
				p:SetLighting(false) p:SetCollide(false)
			end
		end
	end
end

function ENT:DrawTranslucent()
	local base = self:GetPos()
	local vers = EyePos() - base
	vers.z = 0
	if vers:LengthSqr() < 1 then return end
	vers:Normalize()
	local droite = Vector(-vers.y, vers.x, 0)
	local t = CurTime()
	-- Elle s'ouvre en une seconde et demie, puis respire.
	local ouv = math.Clamp((t - (self._t0 or t)) / 1.5, 0, 1)
	ouv = ouv * ouv * (3 - 2 * ouv) * (0.92 + 0.08 * math.sin(t * 5.3))
	local P = self:Profil()
	local function pt(k, bDroit) return base + droite * ((bDroit and k.d or k.g) * ouv) + Vector(0, 0, k.z) end

	-- Le coeur noir : deux triangles par tranche.
	render.SetMaterial(MAT_NOIR)
	mesh.Begin(MATERIAL_TRIANGLES, N * 2)
	for i = 1, N do
		local a, b = P[i], P[i + 1]
		local ag, ad, bg, bd = pt(a, false), pt(a, true), pt(b, false), pt(b, true)
		mesh.Position(ag) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
		mesh.Position(ad) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
		mesh.Position(bd) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
		mesh.Position(ag) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
		mesh.Position(bd) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
		mesh.Position(bg) mesh.Color(COEUR.r, COEUR.g, COEUR.b, COEUR.a) mesh.AdvanceVertex()
	end
	mesh.End()

	-- Les levres de lumiere : un trait continu sur chaque bord, qui palpite.
	local pulse = 0.75 + 0.25 * math.sin(t * 9)
	render.SetMaterial(MAT_BORD)
	for _, bDroit in ipairs({ false, true }) do
		render.StartBeam(#P)
		for i, k in ipairs(P) do
			local e = math.sin((i - 1) / N * math.pi)
			render.AddBeam(pt(k, bDroit), (6 + 10 * e) * pulse, (i - 1) / N, Color(BORD.r, BORD.g, BORD.b, 255 * (0.3 + 0.7 * e)))
		end
		render.EndBeam()
	end
	-- Un arc electrique au hasard entre les deux levres, une image sur trois.
	if math.random() < 0.33 then
		local k = P[math.random(3, #P - 2)]
		render.SetMaterial(MAT_ECLAIR)
		render.DrawBeam(pt(k, false), pt(k, true) + VectorRand() * 6, 5, 0, 1, Color(230, 180, 255, 200))
	end
	render.SetMaterial(MAT_GLOW)
	render.DrawSprite(self:EvoCentre(), 260 * ouv, 340 * ouv, Color(HALO.r, HALO.g, HALO.b, 70))

	if EVO_EVENTS.DessinerInvite then
		EVO_EVENTS.DessinerInvite(self, base + Vector(0, 0, HAUT + 26), "Fissure de reiatsu", "E maintenu : sceller")
	end
end
