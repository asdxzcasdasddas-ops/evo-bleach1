-- "addons\\evo_events\\lua\\evo_events\\cl_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENTS : le menu du staff (!event, ou le bouton du panneau animateur).
-- A gauche la liste des evenements, a droite ce que fait celui choisi, ses
-- reglages en paliers cliquables et ses boutons. Les choix sont retenus pendant
-- la session : on regle une fois, on relance vite.
-- ============================================================================

local E = EVO_EVENTS

local ACCENT = Color(207, 68, 78)
local VERT = Color(78, 196, 128)
local function C() return EVO_UI and EVO_UI.Col or {
	bg = Color(16, 16, 19, 250), border = Color(255, 255, 255, 20), divider = Color(255, 255, 255, 18),
	title = Color(238, 239, 243), muted = Color(150, 154, 162), dim = Color(106, 109, 118),
	accent = ACCENT, green = VERT } end
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

local fond, carte
local choixRetenus = {}   -- [id evenement][id parametre] = valeur
local _choisi = 1

local function fermer()
	if IsValid(fond) then fond:Remove() end
	if IsValid(carte) then carte:Remove() end
end

local function valeurDe(def, p)
	choixRetenus[def.id] = choixRetenus[def.id] or {}
	local v = choixRetenus[def.id][p.id]
	if v == nil then v = p.defaut end
	return v
end

local function envoyer(sEv, sAct, tParams)
	net.Start("evo_events:action")
	net.WriteString(sEv)
	net.WriteString(sAct)
	net.WriteTable(tParams or {})
	net.SendToServer()
	surface.PlaySound("ui/buttonclickrelease.wav")
end

-- Un bouton a plat, coin coupe, qui s'allume au survol ou quand il est choisi.
local function bouton(parent, x, y, w, h, sTexte, fnActif, fnClic, colPlein)
	local col = C()
	local b = vgui.Create("DButton", parent)
	b:SetPos(x, y) b:SetSize(w, h) b:SetText("")
	b.Paint = function(s, bw, bh)
		local bActif = fnActif and fnActif() or false
		local f
		if colPlein then f = ColorAlpha(colPlein, s:IsHovered() and 255 or 215)
		elseif bActif then f = ColorAlpha(col.accent, 235)
		else f = s:IsHovered() and Color(255, 255, 255, 22) or Color(255, 255, 255, 9) end
		if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, bw, bh, f, R(8), "br")
		else surface.SetDrawColor(f) surface.DrawRect(0, 0, bw, bh) end
		draw.SimpleText(sTexte, "EVO_Ev_Texte", bw / 2, bh / 2, (bActif or colPlein) and color_white or col.title,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fnClic
	return b
end

-- string.upper ne connait pas les accents (« é » reste minuscule) : on les
-- remonte a la main.
local ACCENTS = { ["é"] = "É", ["è"] = "È", ["ê"] = "Ê", ["ë"] = "Ë", ["à"] = "À", ["â"] = "Â",
	["î"] = "Î", ["ï"] = "Ï", ["ô"] = "Ô", ["ù"] = "Ù", ["û"] = "Û", ["ç"] = "Ç" }
local function majuscules(s)
	s = string.upper(s)
	for a, b in pairs(ACCENTS) do s = string.gsub(s, a, b) end
	return s
end

-- La hauteur d'un texte coupe en lignes a `largeur`, calculee ici. Le DLabel qui
-- s'etire tout seul donnait sa taille AVANT de connaitre sa largeur (une lettre
-- par ligne) : les reglages et les boutons partaient sous le bas de la fenetre.
local function hauteurTexte(s, sPolice, nLargeur)
	surface.SetFont(sPolice)
	local _, hLigne = surface.GetTextSize("Ag")
	local nLignes, cur = 1, ""
	for mot in string.gmatch(s, "%S+") do
		local essai = (cur == "") and mot or (cur .. " " .. mot)
		if cur ~= "" and surface.GetTextSize(essai) > nLargeur then
			nLignes = nLignes + 1
			cur = mot
		else
			cur = essai
		end
	end
	return nLignes * hLigne
end

local function remplirDetail(zone, def)
	zone:Clear()
	local col = C()
	local W = zone:GetWide()
	local y = 0

	-- Bebas Neue n'a que des capitales : pas besoin de majuscules (et elles
	-- perdaient les accents).
	local titre = vgui.Create("DLabel", zone)
	titre:SetPos(0, y) titre:SetSize(W, R(40))
	titre:SetFont("EVO_Ev_Grand") titre:SetTextColor(col.title)
	titre:SetText(def.nom)
	y = y + R(46)

	local sResume = def.resume or ""
	local hResume = hauteurTexte(sResume, "EVO_Ev_Texte", W - R(12)) + R(6)
	local resume = vgui.Create("DLabel", zone)
	resume:SetPos(0, y) resume:SetSize(W, hResume)
	resume:SetFont("EVO_Ev_Texte") resume:SetTextColor(col.muted)
	resume:SetWrap(true)
	resume:SetContentAlignment(7)
	resume:SetText(sResume)
	y = y + hResume + R(16)

	choixRetenus[def.id] = choixRetenus[def.id] or {}
	for _, p in ipairs(def.params or {}) do
		local lbl = vgui.Create("DLabel", zone)
		lbl:SetPos(0, y) lbl:SetSize(W, R(22))
		lbl:SetFont("EVO_Ev_Petit") lbl:SetTextColor(col.dim)
		lbl:SetText(majuscules(p.nom))
		y = y + R(24)
		if p.type == "texte" then
			local t = vgui.Create("DTextEntry", zone)
			t:SetPos(0, y) t:SetSize(W, R(38))
			t:SetFont("EVO_Ev_Texte")
			t:SetText(tostring(valeurDe(def, p)))
			t:SetPaintBackground(false)
			t.Paint = function(s, w, h)
				surface.SetDrawColor(255, 255, 255, 8) surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(ColorAlpha(s:HasFocus() and col.accent or col.border, 160)) surface.DrawOutlinedRect(0, 0, w, h)
				s:DrawTextEntryText(col.title, col.accent, col.title)
			end
			t.OnChange = function(s) choixRetenus[def.id][p.id] = s:GetValue() end
			y = y + R(46)
		else
			local n = #p.options
			local ecart = R(6)
			local bw = math.floor((W - (n - 1) * ecart) / n)
			for i, o in ipairs(p.options) do
				bouton(zone, (i - 1) * (bw + ecart), y, bw, R(34), o[1],
					function() return valeurDe(def, p) == o[2] end,
					function() choixRetenus[def.id][p.id] = o[2] surface.PlaySound("ui/buttonclick.wav") end)
			end
			y = y + R(44)
		end
	end

	y = y + R(10)
	local n = #def.actions
	local ecart = R(8)
	local bw = math.floor((W - (n - 1) * ecart) / n)
	for i, a in ipairs(def.actions) do
		local bArreter = (a[1] == "arreter")
		bouton(zone, (i - 1) * (bw + ecart), y, bw, R(44), a[2], nil, function()
			local tP = {}
			for _, p in ipairs(def.params or {}) do tP[p.id] = valeurDe(def, p) end
			envoyer(def.id, a[1], tP)
		end, bArreter and Color(70, 72, 80) or col.accent)
	end
end

function E.MenuOuvrir()
	fermer()
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	local col = C()
	local cardW, cardH = R(1100), R(760)

	fond = EVO_UI and EVO_UI.Backdrop and EVO_UI.Backdrop(fermer) or nil
	carte = vgui.Create("DPanel", fond)
	if not IsValid(fond) then carte:MakePopup() end
	carte:SetSize(cardW, cardH)
	carte:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	carte:SetMouseInputEnabled(true)
	carte.OnMousePressed = function() end
	carte.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then EVO_UI.PaintCard(w, h, 1, R(16)) else surface.SetDrawColor(col.bg) surface.DrawRect(0, 0, w, h) end
		if EVO_UI and EVO_UI.Header then
			EVO_UI.Header(w, "ÉVÉNEMENTS", "VISIBLE PAR TOUT LE SERVEUR", 1, R(26))
			EVO_UI.FooterHints(w, h, game.GetMap(), { { key = "ÉCHAP", label = "FERMER" } }, 1, R(26))
		else
			draw.SimpleText("ÉVÉNEMENTS", "EVO_Ev_Grand", R(26), R(30), col.title)
		end
	end
	local croix = vgui.Create("DButton", carte)
	croix:SetText("") croix:SetSize(R(34), R(34)) croix:SetPos(cardW - R(48), R(16))
	croix.Paint = function(s, w, h)
		draw.SimpleText("✕", "EVO_Ev_Titre", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	croix.DoClick = fermer

	local haut, bas, gauche = R(74), R(46), R(300)
	local liste = vgui.Create("DScrollPanel", carte)
	liste:SetPos(R(16), haut) liste:SetSize(gauche, cardH - haut - bas - R(58))
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(liste) end

	-- Tout arreter : en bas de la colonne, toujours visible, en rouge.
	bouton(carte, R(16), cardH - bas - R(50), gauche - R(8), R(42), "Tout arrêter", nil, function()
		Derma_Query("Arrêter TOUS les événements en cours et nettoyer les cratères ?", "Événements",
			"Oui, tout arrêter", function() envoyer("tout", "tout", {}) end, "Annuler")
	end, Color(150, 30, 40))

	local zone = vgui.Create("DPanel", carte)
	zone:SetPos(R(16) + gauche + R(24), haut + R(4))
	zone:SetSize(cardW - gauche - R(66), cardH - haut - bas - R(10))
	zone:SetPaintBackground(false)

	local boutons = {}
	local function choisir(i)
		_choisi = i
		for j, b in ipairs(boutons) do if b.SetSel then b:SetSel(j == i) end end
		remplirDetail(zone, E.Liste[i])
	end
	local y = 0
	for i, def in ipairs(E.Liste) do
		local b
		if EVO_UI and EVO_UI.RowButton then
			b = EVO_UI.RowButton(liste, 0, y, gauche - R(8), R(46), { num = string.format("%02d", i), label = def.nom }, function() choisir(i) end)
		else
			b = vgui.Create("DButton", liste) b:SetPos(0, y) b:SetSize(gauche - R(8), R(46)) b:SetText(def.nom)
			b.DoClick = function() choisir(i) end
		end
		boutons[i] = b
		y = y + R(46)
	end
	choisir(math.Clamp(_choisi, 1, #E.Liste))
end

net.Receive("evo_events:menu", function() E.MenuOuvrir() end)
