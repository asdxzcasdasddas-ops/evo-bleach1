-- "addons\\evo_events\\lua\\evo_events\\cl_events.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENTS : client. Le HUD (chrono, alerte, jauge de la Sphere, brume) et le
-- spectacle : la Sphere et le message dans le ciel, les meteores, les fusees,
-- les lanternes, les impacts. Tout est tire du temps serveur et des graines
-- recues : deux joueurs cote a cote voient la meme chose.
--
-- BUDGET : un seul emetteur de particules partage ; les effets lointains ne
-- fabriquent pas de particules ; aucune passe d'ecran, aucun shader. Les sons
-- des explosions arrivent avec le retard de la distance (le son va moins vite
-- que la lumiere : a 3000 unites, un quart de seconde).
-- ============================================================================

local E = EVO_EVENTS
local G = E.G

local ACCENT = Color(207, 68, 78)
local BLANC = Color(238, 239, 243)
local VITESSE_SON = 13500   -- 343 m/s en unites Source

-- ── Polices ─────────────────────────────────────────────────────────────────
local function Polices()
	local k = math.Clamp(ScrH() / 1080, 0.6, 2)
	surface.CreateFont("EVO_Ev_Titre", { font = "Bebas Neue", size = math.floor(30 * k), weight = 400, antialias = true })
	surface.CreateFont("EVO_Ev_Grand", { font = "Bebas Neue", size = math.floor(62 * k), weight = 400, antialias = true })
	surface.CreateFont("EVO_Ev_Texte", { font = "Roboto", size = math.floor(18 * k), weight = 500, antialias = true })
	surface.CreateFont("EVO_Ev_Petit", { font = "Roboto", size = math.floor(14 * k), weight = 500, antialias = true })
	-- Polices du monde (3D2D) : taille fixe, c'est l'echelle 3D2D qui les regle.
	surface.CreateFont("EVO_Ev_InviteTitre", { font = "Bebas Neue", size = 56, weight = 400, antialias = true })
	surface.CreateFont("EVO_Ev_Invite", { font = "Roboto", size = 32, weight = 600, antialias = true })
	surface.CreateFont("EVO_Ev_Ciel", { font = "Bebas Neue", size = 200, weight = 400, antialias = true })
end
Polices()
hook.Add("OnScreenSizeChanged", "EVO_Events::Polices", Polices)
local function K() return math.Clamp(ScrH() / 1080, 0.6, 2) end

-- ── Outils ──────────────────────────────────────────────────────────────────
local MAT_GLOW = Material("sprites/light_glow02_add")
local MAT_ECLAIR = Material("sprites/lgtning")
-- Pour les rubans (render.StartBeam) : un UnlitGeneric additif a nous. Le
-- materiau « sprite » du jeu est fait pour DrawSprite, pas pour des rubans.
local MAT_RUBAN = CreateMaterial("evo_ev_ruban", "UnlitGeneric", {
	["$basetexture"] = "sprites/light_glow02", ["$additive"] = "1",
	["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nocull"] = "1",
})
-- Le halo sans brouillard, pour ce qui est tres loin (la Sphere, les eclats).
local MAT_GLOW_LOIN = CreateMaterial("evo_ev_glow_loin", "UnlitGeneric", {
	["$basetexture"] = "sprites/light_glow02", ["$additive"] = "1",
	["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nofog"] = "1", ["$nocull"] = "1",
})

local _em
function E.Emetteur()
	if _em and _em:IsValid() then
		_em:SetPos(EyePos())
		return _em
	end
	_em = ParticleEmitter(EyePos(), false)
	return _em
end

local function lerpCouleur(f, a, b)
	return Color(Lerp(f, a.r, b.r), Lerp(f, a.g, b.g), Lerp(f, a.b, b.b), Lerp(f, a.a or 255, b.a or 255))
end

-- Une direction au hasard, uniforme sur la sphere (VectorRand normalise tire
-- vers les coins du cube : une pivoine en sortirait carree).
local function dirAlea(r)
	r = r or math.Rand
	local z = r(-1, 1)
	local a = r(0, math.pi * 2)
	local s = math.sqrt(1 - z * z)
	return Vector(math.cos(a) * s, math.sin(a) * s, z)
end

local function plaque(x, y, w, h, a)
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, w, h, Color(13, 14, 17, 235 * a), math.floor(12 * K()))
	else
		surface.SetDrawColor(13, 14, 17, 235 * a)
		surface.DrawRect(x, y, w, h)
	end
	surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 255 * a)
	surface.DrawRect(x, y, math.max(3, math.floor(4 * K())), h)
end

-- ── L'invite au-dessus des entites d'evenement ──────────────────────────────
-- « E : x » / « E maintenu : x » -> pastille E + action du style partage (cache par libelle).
local _actInvite = {}
local function ActionInvite(s)
	local t = _actInvite[s]
	if not t then
		local sAct = string.match(s, "^E maintenu : (.+)$")
		if sAct then
			sAct = "Maintenir : " .. sAct
		else
			sAct = string.match(s, "^E : (.+)$")
			if sAct then sAct = string.upper(string.sub(sAct, 1, 1)) .. string.sub(sAct, 2) end
		end
		t = sAct and { sAct, "E" } or { s, "" }
		_actInvite[s] = t
	end
	return t[1], t[2]
end
local COL_NICK, COL_NICK_OMBRE = Color(238, 239, 243, 230), Color(0, 0, 0, 150)

-- Titre, action, et la barre de progression quand quelqu'un est dessus. Droite
-- (lacet seul), face au joueur, et seulement de pres.
function E.DessinerInvite(ent, pos, sTitre, sAction)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local d = EyePos():Distance(pos)
	if d > 340 then return end
	local a = math.Clamp((340 - d) / 90, 0, 1)
	local ang = Angle(0, EyeAngles().y, 0)
	ang:RotateAroundAxis(ang:Up(), -90)
	ang:RotateAroundAxis(ang:Forward(), 90)
	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		local sAct, sKey = ActionInvite(sAction)
		cam.Start3D2D(pos, ang, 0.1)
			surface.SetAlphaMultiplier(a)
			EVO_ZonePrompt.Row(-28, sTitre, sAct, sKey)
			local acteur = ent.GetActeur and ent:GetActeur()
			if IsValid(acteur) then
				local p = math.Clamp((CurTime() - ent:GetHoldDebut()) / math.max(0.1, ent:GetHoldDuree()), 0, 1)
				local w = 380
				surface.SetDrawColor(0, 0, 0, 180)
				surface.DrawRect(-w / 2, 66, w, 18)
				surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 255)
				surface.DrawRect(-w / 2 + 2, 68, (w - 4) * p, 14)
				draw.SimpleText(acteur:Nick(), "EVOZonePrompt_Info", 2, 109, COL_NICK_OMBRE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(acteur:Nick(), "EVOZonePrompt_Info", 0, 106, COL_NICK, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			surface.SetAlphaMultiplier(1)
		cam.End3D2D()
		return
	end
	cam.Start3D2D(pos, ang, 0.1)
		draw.SimpleTextOutlined(sTitre, "EVO_Ev_InviteTitre", 0, 0, Color(BLANC.r, BLANC.g, BLANC.b, 255 * a),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 2, Color(0, 0, 0, 170 * a))
		draw.SimpleTextOutlined(sAction, "EVO_Ev_Invite", 0, 6, Color(255, 180, 160, 255 * a),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, Color(0, 0, 0, 170 * a))
		local acteur = ent.GetActeur and ent:GetActeur()
		if IsValid(acteur) then
			local p = math.Clamp((CurTime() - ent:GetHoldDebut()) / math.max(0.1, ent:GetHoldDuree()), 0, 1)
			local w = 380
			surface.SetDrawColor(0, 0, 0, 180 * a)
			surface.DrawRect(-w / 2, 52, w, 18)
			surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 255 * a)
			surface.DrawRect(-w / 2 + 2, 54, (w - 4) * p, 14)
			draw.SimpleTextOutlined(acteur:Nick(), "EVO_Ev_Invite", 0, 76, Color(BLANC.r, BLANC.g, BLANC.b, 230 * a),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, Color(0, 0, 0, 170 * a))
		end
	cam.End3D2D()
end

-- ── Etat des effets ponctuels ───────────────────────────────────────────────
local meteores, spectacles, lachers, ondes = {}, {}, {}, {}
local flash = nil       -- { t, a, c } : l'ecran blanchit un instant
local eclat = nil       -- instant de la revelation de la Sphere
local eclatSons = {}

local function flashEcran(a, c)
	if flash and flash.a * math.max(0, 1 - (CurTime() - flash.t) / 1.2) > a then return end
	flash = { t = CurTime(), a = a, c = c or color_white }
end

local function lumiere(pos, c, force, taille, duree)
	local dl = DynamicLight(40000 + math.random(1, 4000))
	if not dl then return end
	dl.pos = pos
	dl.r, dl.g, dl.b = c.r, c.g, c.b
	dl.brightness = force
	dl.size = taille
	dl.decay = taille * 3
	dl.dietime = CurTime() + (duree or 0.6)
end

local function sonLoin(snd, pos, niveau, ton, vol)
	local d = EyePos():Distance(pos)
	timer.Simple(d / VITESSE_SON, function() sound.Play(snd, pos, niveau, ton, vol) end)
end

-- ── Impacts ─────────────────────────────────────────────────────────────────
local DEBRIS = { "effects/fleck_cement1", "effects/fleck_cement2" }

local function impactFx(m)
	local P = m.p
	local bFrag = m.genre == "fragment"
	local c = bFrag and Color(200, 120, 255) or Color(255, 150, 60)
	local d = EyePos():Distance(P)
	if bFrag then
		sonLoin("ambient/energy/whiteflash.wav", P, 110, 90, 1)
		sonLoin("weapons/mortar/mortar_explode1.wav", P, 115, 135, 0.55)
	else
		sonLoin("ambient/explosions/explode_" .. math.random(3, 5) .. ".wav", P, 150, math.random(82, 96), 1)
		sonLoin("weapons/mortar/mortar_explode2.wav", P, 140, 90, 1)
	end
	lumiere(P + Vector(0, 0, 80), c, bFrag and 4 or 7, bFrag and 900 or 2800, 0.8)
	if d < 3500 then flashEcran((1 - d / 3500) * (bFrag and 80 or 190), Color(255, 235, 210)) end
	ondes[#ondes + 1] = { p = P + Vector(0, 0, 10), t = CurTime(), r = bFrag and 380 or 950, c = c }
	if d > 7000 then return end
	local em = E.Emetteur()
	if not em then return end
	-- La boule de feu : des halos qui gonflent et s'eteignent vite.
	for _ = 1, bFrag and 10 or 26 do
		local p = em:Add("sprites/light_glow02_add", P + VectorRand() * 30 + Vector(0, 0, 30))
		if p then
			p:SetVelocity(dirAlea() * math.Rand(80, 380) + Vector(0, 0, 160))
			p:SetAirResistance(120)
			p:SetDieTime(math.Rand(0.4, 1))
			p:SetStartAlpha(255) p:SetEndAlpha(0)
			p:SetStartSize(math.Rand(60, 140) * (bFrag and 0.5 or 1)) p:SetEndSize(math.Rand(200, 320) * (bFrag and 0.5 or 1))
			p:SetColor(c.r, c.g, c.b)
			p:SetLighting(false) p:SetCollide(false)
		end
	end
	-- La poussiere : lente, haute, qui retombe en voile.
	for _ = 1, bFrag and 8 or 24 do
		local p = em:Add("particle/smokesprites_0001", P + VectorRand() * 60 + Vector(0, 0, 20))
		if p then
			local v = dirAlea() * math.Rand(60, 260)
			v.z = math.abs(v.z) + 60
			p:SetVelocity(v)
			p:SetAirResistance(60)
			p:SetGravity(Vector(0, 0, -20))
			p:SetDieTime(math.Rand(4, 8))
			p:SetStartAlpha(bFrag and 90 or 170) p:SetEndAlpha(0)
			p:SetStartSize(math.Rand(50, 90)) p:SetEndSize(math.Rand(220, 380))
			p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-0.5, 0.5))
			if bFrag then p:SetColor(150, 110, 190) else p:SetColor(96, 84, 74) end
			p:SetLighting(false) p:SetCollide(false)
		end
	end
	-- Les debris qui retombent et rebondissent (meteore seulement).
	if not bFrag then
		for _ = 1, 22 do
			local p = em:Add(DEBRIS[math.random(#DEBRIS)], P + Vector(0, 0, 20))
			if p then
				local v = dirAlea() * math.Rand(200, 520)
				v.z = math.abs(v.z) * 1.4 + 150
				p:SetVelocity(v)
				p:SetGravity(Vector(0, 0, -600))
				p:SetDieTime(math.Rand(2, 4))
				p:SetStartAlpha(255) p:SetEndAlpha(0)
				p:SetStartSize(math.Rand(3, 7)) p:SetEndSize(2)
				p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-8, 8))
				p:SetColor(60, 52, 46)
				p:SetCollide(true) p:SetBounce(0.3)
			end
		end
	end
	-- Les etincelles.
	for _ = 1, bFrag and 30 or 40 do
		local p = em:Add("effects/spark", P + Vector(0, 0, 20))
		if p then
			local v = dirAlea() * math.Rand(250, 650)
			v.z = math.abs(v.z) + 100
			p:SetVelocity(v)
			p:SetGravity(Vector(0, 0, -500))
			p:SetDieTime(math.Rand(0.5, 1.2))
			p:SetStartAlpha(255) p:SetEndAlpha(0)
			p:SetStartSize(3) p:SetEndSize(0)
			p:SetStartLength(24) p:SetEndLength(4)
			p:SetColor(c.r, math.min(255, c.g + 60), c.b)
			p:SetLighting(false) p:SetCollide(false)
		end
	end
end

-- ── Feux d'artifice ─────────────────────────────────────────────────────────
local TYPES = { "pivoine", "chrysantheme", "saule", "anneau", "crepitant", "palmier", "pivoine", "chrysantheme" }
local PALETTE = {
	Color(255, 70, 70), Color(255, 190, 60), Color(90, 255, 130), Color(90, 170, 255),
	Color(210, 100, 255), Color(255, 255, 255), Color(255, 120, 200), Color(255, 150, 40),
}
local BOUMS = { "ambient/explosions/explode_1.wav", "ambient/explosions/explode_2.wav", "ambient/explosions/explode_7.wav", "ambient/explosions/explode_8.wav" }
local CREPITS = { "ambient/energy/newspark01.wav", "ambient/energy/newspark03.wav", "ambient/energy/newspark05.wav", "ambient/energy/newspark08.wav" }

local function construireSpectacle(t)
	local r = E.Rng(t.graine)
	local nb = math.max(1, t.nb)
	local pas = t.duree / nb
	local fusees = {}
	for i = 1, nb do
		-- Le bouquet final : les cinq dernieres partent ensemble, a la fin.
		local tl = (i > nb - 5 and nb > 8) and (t.t0 + t.duree + r(0, 1.2)) or (t.t0 + (i - 1) * pas + r(0, pas * 0.7))
		local a, rr = r(0, math.pi * 2), r(0, 280)
		local from = t.pos + Vector(math.cos(a) * rr, math.sin(a) * rr, 10)
		fusees[i] = {
			tl = tl, from = from,
			apex = from + Vector(r(-170, 170), r(-170, 170), r(950, 1550)),
			montee = r(1.6, 2.3),
			type = TYPES[math.min(#TYPES, math.floor(r(1, #TYPES + 1)))],
			c1 = PALETTE[math.min(#PALETTE, math.floor(r(1, #PALETTE + 1)))],
			c2 = PALETTE[math.min(#PALETTE, math.floor(r(1, #PALETTE + 1)))],
			graine = math.floor(r(1, 2000000000)),
			etat = 0, traine = 0,
		}
	end
	spectacles[#spectacles + 1] = { fusees = fusees, fin = t.t0 + t.duree + 16 }
end

local function eclater(f)
	local r = E.Rng(f.graine)
	local em = E.Emetteur()
	local P = f.apex
	sonLoin(BOUMS[math.min(#BOUMS, math.floor(r(1, #BOUMS + 1)))], P, 125, math.floor(r(100, 125)), 0.9)
	lumiere(P, f.c1, 3, 1800, 0.5)
	if not em or EyePos():Distance(P) > 9000 then return end
	local typ = f.type
	local n, vit, grav, air, vie, taille, longueur, mat = 90, 430, 170, 55, 1.9, 14, nil, "sprites/light_glow02_add"
	if typ == "chrysantheme" then n, vit, vie, taille, longueur, mat = 80, 420, 2.4, 4, 42, "effects/spark"
	elseif typ == "saule" then n, vit, grav, air, vie, taille, longueur, mat = 70, 280, 120, 25, 4, 3, 30, "effects/spark"
	elseif typ == "anneau" then n, vit = 64, 420
	elseif typ == "crepitant" then n, vit, vie = 60, 320, 2.6
	elseif typ == "palmier" then n, vit, vie, taille, longueur, mat = 10, 300, 2.6, 10, 90, "effects/spark"
	end
	-- L'anneau : un cercle incline au hasard, pas une sphere.
	local u, v
	if typ == "anneau" then
		local axe = dirAlea(r)
		u = axe:Angle():Right()
		v = axe:Angle():Up()
	end
	for i = 1, n do
		local dir
		if u then
			local a = (i / n) * math.pi * 2
			dir = u * math.cos(a) + v * math.sin(a)
		else
			dir = dirAlea(r)
		end
		local p = em:Add(mat, P)
		if p then
			local c = (i % 2 == 0) and f.c1 or f.c2
			if typ == "saule" then c = Color(255, 200, 90) end
			p:SetVelocity(dir * vit * r(0.85, 1.1))
			p:SetGravity(Vector(0, 0, -grav))
			p:SetAirResistance(air)
			p:SetDieTime(r(vie * 0.8, vie * 1.2))
			p:SetStartAlpha(255) p:SetEndAlpha(0)
			p:SetStartSize(taille) p:SetEndSize(0)
			if longueur then p:SetStartLength(longueur) p:SetEndLength(4) end
			p:SetColor(c.r, c.g, c.b)
			p:SetLighting(false) p:SetCollide(false)
			if typ == "crepitant" then
				-- Chaque etincelle se met a clignoter apres une seconde : le crepitement.
				p:SetThinkFunction(function(pp)
					local a = (math.random() < 0.5) and 255 or 40
					pp:SetStartAlpha(a) pp:SetEndAlpha(0)
					pp:SetNextThink(CurTime() + 0.05)
				end)
				p:SetNextThink(CurTime() + r(0.9, 1.3))
			end
		end
	end
	if typ == "crepitant" then
		local d = EyePos():Distance(P) / VITESSE_SON
		for k = 1, 3 do
			timer.Simple(d + 1 + k * 0.25, function() sound.Play(CREPITS[math.random(#CREPITS)], P, 110, math.random(110, 140), 0.6) end)
		end
	end
end

-- ── Lanternes ───────────────────────────────────────────────────────────────
local VIE_LANTERNE = 220

local function construireLanternes(t)
	local r = E.Rng(t.graine)
	local L = {}
	for i = 1, math.max(1, t.nb) do
		local a, rr = r(0, math.pi * 2), r(20, 440)
		L[i] = {
			t = t.t0 + r(0, 25),
			from = t.pos + Vector(math.cos(a) * rr, math.sin(a) * rr, r(40, 90)),
			v = r(26, 46), amp = r(14, 38), f = r(0.15, 0.35), ph = r(0, 6.28),
			dx = r(-7, 7), dy = r(-7, 7),
			c = Color(255, math.floor(r(170, 215)), math.floor(r(90, 140))),
		}
	end
	lachers[#lachers + 1] = { L = L, fin = t.t0 + 25 + VIE_LANTERNE }
end

-- ── Reception ───────────────────────────────────────────────────────────────
net.Receive("evo_events:fx", function()
	local sGenre = net.ReadString()
	local t = net.ReadTable()
	if sGenre == "meteore" then
		meteores[#meteores + 1] = { s = t.s, p = t.p, t0 = t.t0, ta = t.ta, genre = t.genre, taille = t.taille or 1, emis = 0 }
	elseif sGenre == "artifice" then
		construireSpectacle(t)
	elseif sGenre == "lanternes" then
		construireLanternes(t)
	elseif sGenre == "orbe_eclat" then
		eclat = t.t0 or CurTime()
		eclatSons = {}
	elseif sGenre == "ame" then
		local em = E.Emetteur()
		local bKonso = t.mode == "konso"
		sound.Play(bKonso and "ambient/levels/canals/windchime2.wav" or "ambient/levels/labs/teleport_preblast_suckin1.wav",
			t.pos, 75, bKonso and 100 or 130, 0.8)
		lumiere(t.pos, bKonso and Color(200, 230, 255) or Color(255, 60, 60), 3, 400, 0.6)
		if em then
			for _ = 1, 30 do
				local p = em:Add("sprites/light_glow02_add", t.pos + VectorRand() * 10)
				if p then
					if bKonso then
						-- Le konso : elle monte en colonne de lumiere.
						p:SetVelocity(Vector(math.Rand(-15, 15), math.Rand(-15, 15), math.Rand(120, 320)))
						p:SetColor(220, 240, 255)
					else
						-- Devoree : aspiree vers le centre, rouge.
						p:SetVelocity(-dirAlea() * math.Rand(40, 120))
						p:SetColor(255, 70, 60)
					end
					p:SetDieTime(math.Rand(0.8, 1.8))
					p:SetStartAlpha(255) p:SetEndAlpha(0)
					p:SetStartSize(math.Rand(8, 16)) p:SetEndSize(0)
					p:SetLighting(false) p:SetCollide(false)
				end
			end
		end
	elseif sGenre == "fissure_scellee" then
		sound.Play("ambient/levels/labs/teleport_postblast_winddown1.wav", t.pos, 85, 100, 1)
		lumiere(t.pos + Vector(0, 0, 100), Color(210, 140, 255), 5, 900, 0.8)
		ondes[#ondes + 1] = { p = t.pos + Vector(0, 0, 10), t = CurTime(), r = 500, c = Color(200, 120, 255) }
	elseif sGenre == "fissure_vague" then
		sound.Play("ambient/levels/labs/teleport_postblast_thunder1.wav", t.pos, 90, math.random(85, 100), 0.8)
		lumiere(t.pos + Vector(0, 0, 100), Color(170, 60, 230), 4, 700, 0.5)
	elseif sGenre == "fragment_analyse" then
		sound.Play("ambient/energy/whiteflash.wav", t.pos, 75, 110, 0.8)
		local c = t.genre == "orbe" and Color(200, 130, 255) or Color(255, 160, 70)
		lumiere(t.pos, c, 4, 500, 0.6)
		ondes[#ondes + 1] = { p = t.pos - Vector(0, 0, 10), t = CurTime(), r = 260, c = c }
	end
end)

-- ── Chaque image : particules, sons programmes, fusees ──────────────────────
local function posMeteore(m, now)
	local u = math.Clamp((now - m.t0) / math.max(0.1, m.ta - m.t0), 0, 1)
	return LerpVector(u ^ 1.35, m.s, m.p), u
end

local _dernier = 0
local _secondeChrono = nil
local _sirene = nil

hook.Add("Think", "EVO_Events::Fx", function()
	local now = CurTime()
	local dt = math.min(0.1, RealTime() - _dernier)
	_dernier = RealTime()
	local em = E.Emetteur()
	local oeil = EyePos()

	-- Les meteores en vol : fumee et etincelles a la tete, sons, impact.
	for i = #meteores, 1, -1 do
		local m = meteores[i]
		if now >= m.t0 and not m.impacte then
			local tete = posMeteore(m, now)
			if not m.siffle and now >= m.ta - 2.4 then
				m.siffle = true
				sound.Play("weapons/mortar/mortar_shell_incomming1.wav", m.p, 140, m.genre == "fragment" and 140 or 95, 1)
			end
			if em and tete:DistToSqr(oeil) < 12000 * 12000 then
				m.emis = m.emis + dt * (m.genre == "fragment" and 14 or 30)
				while m.emis >= 1 do
					m.emis = m.emis - 1
					local p = em:Add("particle/smokesprites_0001", tete + VectorRand() * 20)
					if p then
						p:SetVelocity(VectorRand() * 30)
						p:SetDieTime(math.Rand(2.5, 4.5))
						p:SetStartAlpha(m.genre == "fragment" and 60 or 130) p:SetEndAlpha(0)
						p:SetStartSize(40 * m.taille) p:SetEndSize(math.Rand(160, 260) * m.taille)
						p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-0.4, 0.4))
						if m.genre == "fragment" then p:SetColor(120, 80, 170) else p:SetColor(70, 62, 58) end
						p:SetLighting(false) p:SetCollide(false)
					end
				end
			end
			if now >= m.ta then
				m.impacte = true
				impactFx(m)
			end
		end
		if now > m.ta + 12 then table.remove(meteores, i) end
	end

	-- Les fusees : depart, trainee, eclatement.
	for i = #spectacles, 1, -1 do
		local S = spectacles[i]
		for _, f in ipairs(S.fusees) do
			if f.etat == 0 and now >= f.tl then
				f.etat = 1
				sound.Play("weapons/mortar/mortar_fire1.wav", f.from, 90, 155, 0.35)
			end
			if f.etat == 1 then
				local u = math.Clamp((now - f.tl) / f.montee, 0, 1)
				f.pos = LerpVector(1 - (1 - u) ^ 2, f.from, f.apex)
				f.traine = f.traine + dt * 40
				if em and f.pos:DistToSqr(oeil) < 8000 * 8000 then
					while f.traine >= 1 do
						f.traine = f.traine - 1
						local p = em:Add("sprites/light_glow02_add", f.pos)
						if p then
							p:SetVelocity(VectorRand() * 20 - Vector(0, 0, 40))
							p:SetDieTime(math.Rand(0.4, 0.8))
							p:SetStartAlpha(220) p:SetEndAlpha(0)
							p:SetStartSize(math.Rand(5, 8)) p:SetEndSize(0)
							p:SetColor(255, 200, 120)
							p:SetLighting(false) p:SetCollide(false)
						end
					end
				else
					f.traine = 0
				end
				if u >= 1 then
					f.etat = 2
					eclater(f)
				end
			end
		end
		if now > S.fin then table.remove(spectacles, i) end
	end
	for i = #lachers, 1, -1 do if now > lachers[i].fin then table.remove(lachers, i) end end
	for i = #ondes, 1, -1 do if now - ondes[i].t > 1.2 then table.remove(ondes, i) end end

	-- La revelation de la Sphere : grondement, puis le flash quand elle eclate.
	if eclat then
		local e = now - eclat
		local dir = Angle(GetGlobalFloat(G.orbePitch, -35), GetGlobalFloat(G.orbeYaw, 0), 0):Forward()
		if e >= 0 and not eclatSons.a then
			eclatSons.a = true
			surface.PlaySound("ambient/levels/labs/teleport_mechanism_windup5.wav")
		end
		if e >= 2.2 and not eclatSons.b then
			eclatSons.b = true
			sound.Play("ambient/explosions/explode_9.wav", oeil + dir * 2500, 140, 70, 1)
			surface.PlaySound("ambient/levels/labs/teleport_postblast_thunder1.wav")
			flashEcran(235, Color(255, 250, 245))
			util.ScreenShake(oeil, 8, 5, 2, 500)
		end
		if e > 12 then eclat = nil end
	end

	-- Le chrono : un bip par seconde dans les dix dernieres, une cloche a zero.
	local fin = GetGlobalFloat(G.chronoFin, 0)
	if fin > 0 then
		local reste = math.ceil(fin - now)
		if reste ~= _secondeChrono then
			if _secondeChrono and reste >= 1 and reste <= 10 then surface.PlaySound("buttons/blip1.wav") end
			if _secondeChrono and _secondeChrono >= 1 and reste <= 0 and reste > -1 then surface.PlaySound("ambient/alarms/warningbell1.wav") end
			_secondeChrono = reste
		end
	else
		_secondeChrono = nil
	end

	-- La sirene de l'alerte, sur le joueur, pas trop fort.
	local bAlerte = GetGlobalFloat(G.alerteFin, 0) > now
	if bAlerte and not _sirene and IsValid(LocalPlayer()) then
		_sirene = CreateSound(LocalPlayer(), "ambient/alarms/city_siren_loop2.wav")
		if _sirene then _sirene:PlayEx(0.3, 100) end
		surface.PlaySound("ambient/alarms/klaxon1.wav")
	elseif not bAlerte and _sirene then
		_sirene:FadeOut(1.5)
		_sirene = nil
	end
end)

-- ── La brume toxique ────────────────────────────────────────────────────────
local function brume()
	local fin = GetGlobalFloat(G.brumeFin, 0)
	if fin <= CurTime() then return nil end
	return GetGlobalVector(G.brumePos, Vector()), GetGlobalFloat(G.brumeRayon, 0)
end

local function dansBrume(v, C, R, marge)
	local d = v - C
	local r = R + (marge or 0)
	return math.abs(d.z) < 400 and d.x * d.x + d.y * d.y <= r * r
end

local _resteBrume = 0
hook.Add("Think", "EVO_Events::Brume", function()
	local C, R = brume()
	if not C then _resteBrume = 0 return end
	local oeil = EyePos()
	if not dansBrume(oeil, C, R, 2500) then return end
	local em = E.Emetteur()
	if not em then return end
	_resteBrume = _resteBrume + FrameTime() * 6
	while _resteBrume >= 1 do
		_resteBrume = _resteBrume - 1
		local a, r = math.Rand(0, math.pi * 2), R * math.sqrt(math.random())
		local p = em:Add("particle/smokesprites_0001", C + Vector(math.cos(a) * r, math.sin(a) * r, math.Rand(10, 140)))
		if p then
			p:SetVelocity(VectorRand() * 12 + Vector(0, 0, 4))
			p:SetDieTime(math.Rand(8, 12))
			p:SetStartAlpha(0) p:SetEndAlpha(0)
			p:SetStartSize(math.Rand(180, 260)) p:SetEndSize(math.Rand(380, 520))
			p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-0.2, 0.2))
			p:SetColor(96, 170, 60)
			p:SetLighting(false) p:SetCollide(false)
			-- Monte en douceur, tient, puis s'efface : une nappe, pas des bouffees.
			p:SetThinkFunction(function(pp)
				local u = pp:GetLifeTime() / math.max(0.1, pp:GetDieTime())
				local al = 85 * math.min(1, u * 4) * math.min(1, (1 - u) * 3)
				pp:SetStartAlpha(al) pp:SetEndAlpha(al)
				pp:SetNextThink(CurTime() + 0.1)
			end)
			p:SetNextThink(CurTime())
		end
	end
end)

--- Le brouillard vert quand on est dans la nappe. Appele aussi par evo_ciel,
-- dont le brouillard d'ambiance prendrait sinon la main (le premier hook qui
-- repond gagne).
function E.BrumeFog(nEchelle)
	local C, R = brume()
	if not C then return false end
	local oeil = EyePos()
	if not dansBrume(oeil, C, R, 300) then return false end
	local bDedans = dansBrume(oeil, C, R, 0)
	render.FogMode(MATERIAL_FOG_LINEAR)
	render.FogColor(70, 104, 44)
	render.FogStart(0)
	render.FogEnd((bDedans and 900 or 2600) / (nEchelle or 1))
	render.FogMaxDensity(bDedans and 0.8 or 0.45)
	return true
end
hook.Add("SetupWorldFog", "EVO_Events::Brume", function() if E.BrumeFog(1) then return true end end)
hook.Add("SetupSkyboxFog", "EVO_Events::Brume", function(n) if E.BrumeFog(n) then return true end end)

-- ── Le monde : meteores, fusees, lanternes, ondes de choc ───────────────────
hook.Add("PostDrawTranslucentRenderables", "EVO_Events::Monde", function(bProfondeur, bCiel)
	if bProfondeur or bCiel then return end
	local now = CurTime()

	for _, m in ipairs(meteores) do
		if now >= m.t0 and now < m.ta then
			local tete, u = posMeteore(m, now)
			local bFrag = m.genre == "fragment"
			local c = bFrag and Color(210, 150, 255) or Color(255, 170, 80)
			-- La trainee : un ruban qui suit la trajectoire, de la tete vers l'arriere.
			render.SetMaterial(MAT_RUBAN)
			render.StartBeam(9)
			for k = 0, 8 do
				local uk = math.max(0, u - k * 0.035)
				local pk = LerpVector(uk ^ 1.35, m.s, m.p)
				local f = k / 8
				render.AddBeam(pk, (1 - f) * 150 * m.taille + 10, f, Color(c.r, Lerp(f, c.g, 60), Lerp(f, c.b, 20), 255 * (1 - f)))
			end
			render.EndBeam()
			-- La tete : un coeur blanc et un halo de sa couleur.
			render.SetMaterial(MAT_GLOW)
			render.DrawSprite(tete, 180 * m.taille, 180 * m.taille, Color(255, 250, 235, 255))
			render.DrawSprite(tete, 520 * m.taille, 520 * m.taille, Color(c.r, c.g, c.b, 140))
		end
	end

	render.SetMaterial(MAT_GLOW)
	for _, S in ipairs(spectacles) do
		for _, f in ipairs(S.fusees) do
			if f.etat == 1 and f.pos then render.DrawSprite(f.pos, 22, 22, Color(255, 230, 190, 255)) end
		end
	end

	for _, lot in ipairs(lachers) do
		for _, l in ipairs(lot.L) do
			local dt = now - l.t
			if dt >= 0 and dt < VIE_LANTERNE then
				local pos = l.from + Vector(math.sin(dt * l.f + l.ph) * l.amp + l.dx * dt,
					math.cos(dt * l.f * 0.8 + l.ph) * l.amp + l.dy * dt, l.v * dt)
				local a = math.min(1, dt / 3) * (1 - math.Clamp((dt - VIE_LANTERNE + 40) / 40, 0, 1))
				local fl = 0.85 + 0.15 * math.sin(now * 9 + l.ph)
				render.DrawSprite(pos, 15, 21, Color(l.c.r, l.c.g, l.c.b, 255 * a * fl))
				render.DrawSprite(pos, 72, 72, Color(255, 150, 60, 105 * a * fl))
				render.DrawSprite(pos - Vector(0, 0, 7), 6, 6, Color(255, 255, 225, 255 * a))
			end
		end
	end

	render.SetMaterial(MAT_RUBAN)
	for _, o in ipairs(ondes) do
		local u = math.Clamp((now - o.t) / 1.2, 0, 1)
		local rr = o.r * (1 - (1 - u) ^ 3)
		render.StartBeam(25)
		for k = 0, 24 do
			local a = k / 24 * math.pi * 2
			render.AddBeam(o.p + Vector(math.cos(a) * rr, math.sin(a) * rr, 0), 40 * (1 - u) + 6, k / 24, Color(o.c.r, o.c.g, o.c.b, 200 * (1 - u)))
		end
		render.EndBeam()
	end
end)

-- ── Le ciel : la Sphere et le message ───────────────────────────────────────
local CYAN, VIOLET, ROUGE = Color(170, 225, 255), Color(190, 100, 255), Color(255, 60, 70)

local function dessinerSphere(oeil, now)
	local deb = GetGlobalFloat(G.orbeDebut, 0)
	local e = eclat and (now - eclat) or nil
	if deb <= 0 and not e then return end
	local dir = Angle(GetGlobalFloat(G.orbePitch, -35), GetGlobalFloat(G.orbeYaw, 0), 0):Forward()
	local prog = GetGlobalFloat(G.orbeProgres, 0)
	local a = (deb > 0) and math.Clamp((now - deb) / 8, 0, 1) or 1
	-- Froide au debut, violette a mi-chemin, rouge quand elle va ceder.
	local c = prog < 0.5 and lerpCouleur(prog * 2, CYAN, VIOLET) or lerpCouleur((prog - 0.5) * 2, VIOLET, ROUGE)
	local R = 520 * (1 + 0.07 * math.sin(now * (1.1 + prog * 3.5)))
	local centre = oeil + dir * 11000
	if e then
		if e < 2.2 then
			centre = centre + VectorRand() * (60 * e)
			c = lerpCouleur(e / 2.2, c, color_white)
			R = R * (1 + e * 0.25)
		else
			a = a * math.max(0, 1 - (e - 2.2) / 0.3)
		end
	end
	if a > 0 then
		render.SetMaterial(MAT_GLOW_LOIN)
		render.DrawSprite(centre, R * 6, R * 6, Color(c.r, c.g, c.b, 45 * a))
		render.DrawSprite(centre, R * 3, R * 3, Color(c.r, c.g, c.b, 130 * a))
		local cc = lerpCouleur(0.55, c, color_white)
		render.DrawSprite(centre, R * 2.1, R * 2.1, Color(cc.r, cc.g, cc.b, 220 * a))
		render.DrawSprite(centre, R * 1.1, R * 1.1, Color(255, 255, 255, 255 * a))
		-- Trois anneaux inclines qui tournent a des vitesses differentes.
		for j = 1, 3 do
			local ang = Angle(j * 47 + now * (7 + j * 3), j * 71 + now * (4 + j * 2), 0)
			local u, v = ang:Right(), ang:Up()
			render.StartBeam(25)
			for k = 0, 24 do
				local t = k / 24 * math.pi * 2
				render.AddBeam(centre + (u * math.cos(t) + v * math.sin(t)) * R * (1.25 + j * 0.12), 55, k / 24, Color(c.r, c.g, c.b, 150 * a))
			end
			render.EndBeam()
		end
		-- Des eclats qui tournent autour.
		for k = 1, 12 do
			local t = now * (0.25 + (k % 3) * 0.1) + k * 0.52
			local ang = Angle(k * 31, k * 57, 0)
			local p = centre + (ang:Right() * math.cos(t) + ang:Up() * math.sin(t)) * R * 1.7
			render.DrawSprite(p, 110, 110, Color(255, 255, 255, 180 * a))
		end
		-- Des arcs qui s'en echappent, d'autant plus souvent qu'elle est analysee.
		if math.random() < 0.06 + prog * 0.3 + (e and 0.6 or 0) then
			local d1 = dirAlea()
			local p0 = centre + d1 * R
			render.SetMaterial(MAT_ECLAIR)
			local prec = p0
			for s = 1, 4 do
				local p = centre + (d1 + dirAlea() * 0.35):GetNormalized() * R * (1 + s * 0.35)
				render.DrawBeam(prec, p, 38, 0, 1, Color(240, 220, 255, 220 * a))
				prec = p
			end
		end
	end
	-- L'eclat : une pluie de morceaux qui part de la Sphere et raye le ciel.
	if e and e >= 2.2 then
		render.SetMaterial(MAT_GLOW_LOIN)
		for i = 1, 24 do
			local u = (e - 2.3 - i * 0.12) / 1.8
			if u > 0 and u < 1 then
				local ai = E.Alea(i * 3.7)
				local fin = Angle(-(4 + ai * 26), GetGlobalFloat(G.orbeYaw, 0) + (E.Alea(i * 1.3) - 0.5) * 140, 0):Forward()
				local tete = (dir * (1 - u) + fin * u):GetNormalized()
				local queue = (dir * (1 - math.max(0, u - 0.15)) + fin * math.max(0, u - 0.15)):GetNormalized()
				render.DrawBeam(oeil + queue * 11000, oeil + tete * 11000, 90, 0, 1, Color(c.r, c.g, c.b, 220 * (1 - u)))
				render.DrawSprite(oeil + tete * 11000, 260, 260, Color(255, 255, 255, 255 * (1 - u)))
			end
		end
	end
end

-- Les caracteres d'un texte UTF-8 (un « é » est un seul caractere), gardes pour
-- ne pas les redecouper a chaque image.
local _cacheTexte, _cacheCars = nil, nil
local function caracteres(s)
	if s == _cacheTexte then return _cacheCars end
	local t = {}
	for _, code in utf8.codes(s) do t[#t + 1] = utf8.char(code) end
	_cacheTexte, _cacheCars = s, t
	return t
end

local function dessinerMessage(oeil, now)
	local s = GetGlobalString(G.cielTexte, "")
	if s == "" then return end
	local deb, fin = GetGlobalFloat(G.cielDebut, 0), GetGlobalFloat(G.cielFin, 0)
	local sortie = (fin > 0) and math.Clamp((now - fin) / 3, 0, 1) or 0
	if sortie >= 1 then return end
	local dir = Angle(GetGlobalFloat(G.cielPitch, -25), GetGlobalFloat(G.cielYaw, 0), 0):Forward()
	local pos = oeil + dir * 9000
	local ang = dir:Angle()
	ang:RotateAroundAxis(ang:Up(), -90)
	ang:RotateAroundAxis(ang:Forward(), 90)
	local cars = caracteres(s)
	surface.SetFont("EVO_Ev_Ciel")
	local tw, th = surface.GetTextSize(s)
	cam.Start3D2D(pos, ang, 5)
		-- Le halo derriere les lettres, qui monte avec elles.
		local ah = math.Clamp((now - deb) / 2, 0, 1) * (1 - sortie)
		surface.SetMaterial(MAT_GLOW_LOIN)
		surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 90 * ah)
		surface.DrawTexturedRect(-tw * 0.75, -th * 1.2, tw * 1.5, th * 2.4)
		local x = -tw / 2
		for i, ch in ipairs(cars) do
			local cw = surface.GetTextSize(ch)
			-- Les lettres arrivent une a une, et partent dans le desordre.
			local ai = math.Clamp((now - deb - (i - 1) * 0.08) / 0.5, 0, 1)
			ai = ai * (1 - math.Clamp(sortie * 1.7 - E.Alea(i * 2.3) * 0.7, 0, 1))
			if ai > 0 then
				draw.SimpleText(ch, "EVO_Ev_Ciel", x + 7, -th / 2 + 7, Color(ACCENT.r, ACCENT.g, ACCENT.b, 200 * ai))
				draw.SimpleText(ch, "EVO_Ev_Ciel", x, -th / 2, Color(255, 246, 236, 255 * ai))
			end
			x = x + cw
		end
	cam.End3D2D()
end

hook.Add("PostDrawSkyBox", "EVO_Events::Ciel", function()
	local oeil = EyePos()
	local now = CurTime()
	render.OverrideDepthEnable(true, false)
	dessinerSphere(oeil, now)
	dessinerMessage(oeil, now)
	render.OverrideDepthEnable(false, false)
end)

-- ── Le HUD ──────────────────────────────────────────────────────────────────
local function chrono()
	local fin = GetGlobalFloat(G.chronoFin, 0)
	if fin <= 0 then return end
	local reste = fin - CurTime()
	if reste < -6 then return end
	local k = K()
	local w, h = math.floor(400 * k), math.floor(100 * k)
	local x, y = math.floor(ScrW() / 2 - w / 2), math.floor(18 * k)
	plaque(x, y, w, h, 1)
	-- Bebas Neue n'a que des capitales : string.upper n'apporterait que la perte
	-- des accents.
	local titre = GetGlobalString(G.chronoTitre, "")
	draw.SimpleText(titre, "EVO_Ev_Titre", x + w / 2, y + 22 * k, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	local s, col
	if reste > 0 then
		local n = math.ceil(reste)
		s = n >= 3600 and string.format("%d:%02d:%02d", math.floor(n / 3600), math.floor((n % 3600) / 60), n % 60)
			or string.format("%02d:%02d", math.floor(n / 60), n % 60)
		col = (n <= 10) and lerpCouleur(0.5 + 0.5 * math.sin(CurTime() * 10), ACCENT, BLANC) or BLANC
	else
		s = "MAINTENANT"
		col = lerpCouleur(0.5 + 0.5 * math.sin(CurTime() * 8), ACCENT, BLANC)
	end
	draw.SimpleText(s, "EVO_Ev_Grand", x + w / 2, y + 64 * k, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

-- Les bords de l'ecran qui battent en rouge : un degrade fait a la main, en
-- bandes, sans dependre du sens des textures de degrade du jeu.
local function bordsRouges(a)
	local w, h = ScrW(), ScrH()
	local n, ep = 14, math.floor(h * 0.012)
	for i = 0, n - 1 do
		local al = a * (1 - i / n) ^ 2
		surface.SetDrawColor(200, 20, 30, al)
		surface.DrawRect(0, i * ep, w, ep)
		surface.DrawRect(0, h - (i + 1) * ep, w, ep)
		surface.DrawRect(i * ep, 0, ep, h)
		surface.DrawRect(w - (i + 1) * ep, 0, ep, h)
	end
end

local function alerte()
	local fin = GetGlobalFloat(G.alerteFin, 0)
	if fin <= CurTime() then return end
	local s = GetGlobalString(G.alerteTexte, "")
	local pulse = 0.5 + 0.5 * math.sin(CurTime() * 5)
	bordsRouges(90 + 90 * pulse)
	if s == "" then return end
	local k = K()
	surface.SetFont("EVO_Ev_Texte")
	local tw = surface.GetTextSize(s)
	local w, h = math.max(math.floor(420 * k), tw + math.floor(60 * k)), math.floor(78 * k)
	local x, y = math.floor(ScrW() / 2 - w / 2), math.floor(134 * k)
	plaque(x, y, w, h, 1)
	draw.SimpleText("ALERTE", "EVO_Ev_Titre", x + w / 2, y + 22 * k, lerpCouleur(pulse, ACCENT, BLANC), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(s, "EVO_Ev_Texte", x + w / 2, y + 54 * k, BLANC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function jaugeSphere()
	if GetGlobalFloat(G.orbeDebut, 0) <= 0 then return end
	local k = K()
	local prog = GetGlobalFloat(G.orbeProgres, 0)
	local w, h = math.floor(260 * k), math.floor(58 * k)
	local x, y = ScrW() - w - math.floor(24 * k), math.floor(24 * k)
	plaque(x, y, w, h, 0.95)
	draw.SimpleText("LA SPHÈRE", "EVO_Ev_Titre", x + 16 * k, y + 18 * k, BLANC, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText(math.floor(prog * 100 + 0.5) .. " %", "EVO_Ev_Titre", x + w - 14 * k, y + 18 * k, ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	local bx, by, bw, bh = x + 16 * k, y + 36 * k, w - 30 * k, math.max(4, math.floor(8 * k))
	surface.SetDrawColor(255, 255, 255, 25)
	surface.DrawRect(bx, by, bw, bh)
	local c = prog < 0.5 and lerpCouleur(prog * 2, CYAN, VIOLET) or lerpCouleur((prog - 0.5) * 2, VIOLET, ROUGE)
	surface.SetDrawColor(c.r, c.g, c.b, 255)
	surface.DrawRect(bx, by, bw * prog, bh)
end

local function avisBrume()
	local C, R = brume()
	if not C or not dansBrume(EyePos(), C, R, 0) then return end
	local pulse = 0.5 + 0.5 * math.sin(CurTime() * 2)
	surface.SetDrawColor(80, 140, 40, 40 + 25 * pulse)
	surface.DrawRect(0, 0, ScrW(), ScrH())
	local k = K()
	draw.SimpleTextOutlined("AIR TOXIQUE : un masque médical protège", "EVO_Ev_Titre", ScrW() / 2, ScrH() - 150 * k,
		Color(190, 255, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 200))
end

-- Ma propre action en cours (analyse, scellement...) : une barre en bas, pour
-- savoir qu'il faut garder E enfonce.
local CLASSES = { "evo_event_fragment", "evo_event_fissure", "evo_event_coffre", "evo_event_ame" }
local _mesCibles, _prochainScan = {}, 0
local function monAction()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if CurTime() > _prochainScan then
		_prochainScan = CurTime() + 0.5
		_mesCibles = {}
		for _, cl in ipairs(CLASSES) do
			for _, e in ipairs(ents.FindByClass(cl)) do _mesCibles[#_mesCibles + 1] = e end
		end
	end
	for _, e in ipairs(_mesCibles) do
		if IsValid(e) and e.GetActeur and e:GetActeur() == lp then
			local p = math.Clamp((CurTime() - e:GetHoldDebut()) / math.max(0.1, e:GetHoldDuree()), 0, 1)
			local k = K()
			local w, h = math.floor(420 * k), math.floor(14 * k)
			local x, y = math.floor(ScrW() / 2 - w / 2), math.floor(ScrH() * 0.72)
			surface.SetDrawColor(0, 0, 0, 190)
			surface.DrawRect(x - 2, y - 2, w + 4, h + 4)
			surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 255)
			surface.DrawRect(x, y, w * p, h)
			draw.SimpleTextOutlined("Garde E enfoncé…", "EVO_Ev_Petit", ScrW() / 2, y - 12 * k, BLANC,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 200))
			return
		end
	end
end

hook.Add("HUDPaint", "EVO_Events::HUD", function()
	chrono()
	alerte()
	jaugeSphere()
	monAction()
end)

hook.Add("HUDPaintBackground", "EVO_Events::Voiles", function()
	avisBrume()
	if flash then
		local a = flash.a * math.max(0, 1 - (CurTime() - flash.t) / 1.2)
		if a <= 0 then flash = nil return end
		surface.SetDrawColor(flash.c.r, flash.c.g, flash.c.b, a)
		surface.DrawRect(0, 0, ScrW(), ScrH())
	end
end)
