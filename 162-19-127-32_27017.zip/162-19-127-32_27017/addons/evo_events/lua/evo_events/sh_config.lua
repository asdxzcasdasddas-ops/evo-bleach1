-- "addons\\evo_events\\lua\\evo_events\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENTS : ce qui est partage entre le serveur et le client.
-- ============================================================================

local E = EVO_EVENTS

-- Qui lance : un superadmin, ou un animateur SUR son perso animation (meme regle
-- que les autres outils d'animation, EVO_ANIM.Tier : 2 = Animateur).
E.TIER_MIN = 2
function E.Peut(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0) >= E.TIER_MIN
end

-- L'etat que tout le monde doit lire, y compris un joueur qui se connecte en
-- plein evenement : des variables globales, ecrites seulement quand l'etat
-- change (jamais a chaque image).
E.G = {
	chronoTitre = "EVO_Ev_ChronoTitre", chronoFin = "EVO_Ev_ChronoFin",
	alerteTexte = "EVO_Ev_AlerteTexte", alerteFin = "EVO_Ev_AlerteFin",
	cielTexte = "EVO_Ev_CielTexte", cielDebut = "EVO_Ev_CielDebut", cielFin = "EVO_Ev_CielFin",
	cielYaw = "EVO_Ev_CielYaw", cielPitch = "EVO_Ev_CielPitch",
	orbeDebut = "EVO_Ev_OrbeDebut", orbeProgres = "EVO_Ev_OrbeProgres",
	orbeYaw = "EVO_Ev_OrbeYaw", orbePitch = "EVO_Ev_OrbePitch",
	brumePos = "EVO_Ev_BrumePos", brumeRayon = "EVO_Ev_BrumeRayon", brumeFin = "EVO_Ev_BrumeFin",
	rituel = "EVO_Ev_RituelBonus",
}

-- Recompenses, durees et plafonds, reglables ici sans toucher au code.
-- Les yens restent petits : la cible d'economie est ~2000 par heure de farm.
E.Config = {
	yensKonso = 150, yensDevore = 120, yensFragment = 250, yensFissure = 300, yensCoffre = 200,
	dureeAnalyse = 6, dureeScellement = 7, dureeFouille = 4, dureeAme = 1.2,
	portee = 130,
	brumeDegatsPct = 0.03, brumeDegatsMin = 4,
	meteoreRayon = 380, meteoreDegatsPct = 0.35,
	fissureVagueIntervalle = 45, fissureVagueTaille = 2, fissureMobsMax = 4,
	-- Qui sort des fissures, par carte : des Hollows qui envahissent le
	-- Seireitei, des Shinigamis qui percent jusqu'au Hueco Mundo.
	fissureGroupe = { rp_seireitei_v1 = "hollow_standard", hueco_mundo_v1 = "pve_shinigami_grunts" },
	fragmentVie = 1200, coffreVie = 1800, decorVie = 600,
	-- Modeles des packs EVO (#5) et des maps, deja chez tous les joueurs.
	modeleFragment = "models/evo/props/items/crystal/crystal_03/evo_x2m6r9wf3k.mdl",
	modeleCoffre = "models/echoes/env/sm_cmn_int_chest_01a.mdl",
}

-- ── Les evenements du menu ──────────────────────────────────────────────────
-- Des paliers a cliquer plutot que des champs libres (sauf les textes) : ca se
-- regle en pleine animation, avec des joueurs qui attendent. Le serveur ne
-- croit rien : chaque valeur recue doit etre l'une des options de la liste.
local function choix(id, nom, defaut, options) return { id = id, nom = nom, type = "choix", defaut = defaut, options = options } end
local function texte(id, nom, defaut, max) return { id = id, nom = nom, type = "texte", defaut = defaut, max = max or 60 } end

local DUREES_COURTES = { { "30 s", 30 }, { "1 min", 60 }, { "2 min", 120 }, { "5 min", 300 } }
local DUREES_LONGUES = { { "5 min", 300 }, { "10 min", 600 }, { "20 min", 1200 }, { "40 min", 2400 } }
local CIBLE = { { "Là où tu vises", "ici" }, { "Au hasard, près des joueurs", "hasard" } }

E.Liste = {
	{ id = "chrono", nom = "Compte à rebours", kanji = "時",
	  resume = "Un titre et un chrono en haut de l'écran de tous les joueurs. Sonne à zéro.",
	  params = { texte("titre", "Titre", "Début de l'événement", 48),
	             choix("duree", "Durée", 300, { { "1 min", 60 }, { "5 min", 300 }, { "10 min", 600 }, { "15 min", 900 }, { "30 min", 1800 }, { "1 h", 3600 } }) },
	  actions = { { "lancer", "Lancer" }, { "arreter", "Arrêter" } } },

	{ id = "alerte", nom = "Alerte", kanji = "警",
	  resume = "Sirène, bords de l'écran qui battent en rouge et un message pour tout le serveur.",
	  params = { texte("message", "Message", "Intrusion au Seireitei, tous à vos postes !", 80),
	             choix("duree", "Durée", 60, DUREES_COURTES) },
	  actions = { { "lancer", "Lancer" }, { "arreter", "Arrêter" } } },

	{ id = "message", nom = "Message dans le ciel", kanji = "天",
	  resume = "Des lettres géantes apparaissent dans le ciel, là où tu regardes, une à une.",
	  params = { texte("texte", "Texte", "LE SEIREITEI TOMBERA", 40),
	             choix("duree", "Durée", 60, DUREES_COURTES) },
	  actions = { { "lancer", "Écrire (regarde le ciel)" }, { "arreter", "Effacer" } } },

	{ id = "artifice", nom = "Feux d'artifice", kanji = "花",
	  resume = "Un hanabi au-dessus de l'endroit visé : fusées, pivoines, saules, anneaux, crépitants.",
	  params = { choix("nb", "Fusées", 20, { { "10", 10 }, { "20", 20 }, { "40", 40 }, { "60", 60 } }),
	             choix("duree", "Durée du spectacle", 60, { { "30 s", 30 }, { "1 min", 60 }, { "2 min", 120 }, { "3 min", 180 } }) },
	  actions = { { "lancer", "Tirer" } } },

	{ id = "lanternes", nom = "Lanternes célestes", kanji = "灯",
	  resume = "Des lanternes chaudes montent lentement dans la nuit depuis là où tu es.",
	  params = { choix("nb", "Lanternes", 40, { { "20", 20 }, { "40", 40 }, { "80", 80 }, { "120", 120 } }) },
	  actions = { { "lancer", "Lâcher" } } },

	{ id = "meteores", nom = "Pluie de météores", kanji = "隕",
	  resume = "Des météores traversent le ciel et s'écrasent : cratère, feu, et un noyau à analyser.",
	  params = { choix("nb", "Météores", 3, { { "1", 1 }, { "3", 3 }, { "6", 6 }, { "12", 12 } }),
	             choix("cible", "Où", "hasard", CIBLE),
	             choix("danger", "Dégâts à l'impact", 0, { { "Non", 0 }, { "Oui", 1 } }) },
	  actions = { { "lancer", "Lancer" }, { "arreter", "Nettoyer les cratères" } } },

	{ id = "orbe", nom = "La Sphère", kanji = "球",
	  resume = "Une sphère apparaît dans le ciel (là où tu regardes). Des fragments tombent : les scientifiques les analysent, la jauge monte, et à 100 % la sphère se brise.",
	  params = { choix("cible", "Fragments à analyser", 8, { { "4", 4 }, { "8", 8 }, { "12", 12 }, { "20", 20 } }),
	             choix("intervalle", "Chute d'un fragment", 240, { { "2 min", 120 }, { "4 min", 240 }, { "8 min", 480 }, { "15 min", 900 } }),
	             choix("issue", "À 100 %", "fissures", { { "Elle se brise", "rien" }, { "Fissures", "fissures" }, { "Garganta (Hueco)", "garganta" }, { "Invasion (Hueco)", "invasion" } }) },
	  actions = { { "lancer", "Faire apparaître" }, { "fragment", "Faire tomber un fragment" }, { "arreter", "Faire disparaître" } } },

	{ id = "ames", nom = "Nuit des âmes errantes", kanji = "魂",
	  resume = "Des âmes perdues errent dehors. Un Shinigami les guide (konsō), un Hollow les dévore.",
	  params = { choix("nb", "Âmes en même temps", 12, { { "8", 8 }, { "12", 12 }, { "20", 20 } }),
	             choix("duree", "Durée", 1200, DUREES_LONGUES) },
	  actions = { { "lancer", "Lancer" }, { "arreter", "Arrêter" } } },

	{ id = "fissures", nom = "Fissures de reiatsu", kanji = "裂",
	  resume = "Des déchirures dans l'air laissent passer des vagues d'ennemis jusqu'à ce qu'on les scelle (E maintenu).",
	  params = { choix("nb", "Fissures", 3, { { "1", 1 }, { "3", 3 }, { "5", 5 } }),
	             choix("cible", "Où", "hasard", CIBLE),
	             choix("duree", "Durée max", 1200, DUREES_LONGUES) },
	  actions = { { "lancer", "Ouvrir" }, { "arreter", "Tout refermer" } } },

	{ id = "coffres", nom = "Coffres enfouis", kanji = "宝",
	  resume = "Des coffres affleurent dans le sable. On les déterre (E maintenu) pour un coffre de butin. Avec la tempête, ils repartent sous le sable quand elle s'arrête.",
	  params = { choix("nb", "Coffres", 6, { { "4", 4 }, { "6", 6 }, { "10", 10 } }),
	             choix("tempete", "Tempête de sable (Hueco)", 1, { { "Oui", 1 }, { "Non", 0 } }),
	             choix("duree", "Durée max", 1200, DUREES_LONGUES) },
	  actions = { { "lancer", "Enfouir" }, { "arreter", "Retirer" } } },

	{ id = "eclipse", nom = "Éclipse rituelle", kanji = "蝕",
	  resume = "La lune mange le soleil sur la durée choisie, chrono jusqu'à la totalité. Pendant la totalité (10 min), les Hollows frappent plus fort.",
	  params = { choix("duree", "Jusqu'à la totalité", 600, { { "5 min", 300 }, { "10 min", 600 }, { "15 min", 900 }, { "30 min", 1800 } }),
	             choix("bonus", "Bonus Hollow", 0.15, { { "Aucun", 0 }, { "+10 %", 0.10 }, { "+15 %", 0.15 }, { "+25 %", 0.25 } }) },
	  actions = { { "lancer", "Lancer" }, { "arreter", "Arrêter" } } },

	{ id = "brume", nom = "Brume toxique", kanji = "毒",
	  resume = "Un gaz vert s'installe là où tu vises. Sans masque médical, on tousse et on perd des PV.",
	  params = { choix("rayon", "Rayon", 900, { { "Petit", 500 }, { "Moyen", 900 }, { "Grand", 1500 } }),
	             choix("duree", "Durée", 300, { { "2 min", 120 }, { "5 min", 300 }, { "10 min", 600 } }) },
	  actions = { { "lancer", "Lâcher le gaz" }, { "arreter", "Dissiper" } } },
}

E.ParId = {}
for _, d in ipairs(E.Liste) do E.ParId[d.id] = d end

--- Revalide les parametres recus (le client est forgeable) : chaque valeur doit
-- etre l'une des options, un texte est coupe a sa longueur. Absent = defaut.
function E.Valider(def, tIn)
	local out = {}
	tIn = istable(tIn) and tIn or {}
	for _, p in ipairs(def.params or {}) do
		local v = tIn[p.id]
		if p.type == "texte" then
			v = isstring(v) and string.Trim(v) or ""
			v = string.gsub(v, "[%c]", "")
			if v == "" then v = p.defaut end
			-- Coupe en CARACTERES, pas en octets : couper un « é » en deux
			-- donnerait un caractere casse a l'ecran.
			local ok, fin = pcall(utf8.offset, v, p.max + 1)
			if ok and fin then v = string.sub(v, 1, fin - 1) elseif not ok then v = string.sub(v, 1, p.max) end
			out[p.id] = v
		else
			local ok = false
			for _, o in ipairs(p.options) do if o[2] == v then ok = true break end end
			out[p.id] = ok and v or p.defaut
		end
	end
	return out
end

-- Le petit hachage des effets tires du temps : un nombre stable par graine, le
-- meme chez tous les clients.
function E.Alea(n)
	local x = math.sin(n * 12.9898) * 43758.5453
	return x - math.floor(x)
end

-- Un generateur a graine (Lehmer) : deux clients qui recoivent la meme graine
-- tirent la meme suite, donc voient les memes fusees et les memes lanternes.
function E.Rng(seed)
	local s = math.floor(tonumber(seed) or 1) % 2147483647
	if s <= 0 then s = s + 2147483646 end
	return function(a, b)
		s = (s * 16807) % 2147483647
		local r = (s - 1) / 2147483646
		if a then return a + (b - a) * r end
		return r
	end
end
