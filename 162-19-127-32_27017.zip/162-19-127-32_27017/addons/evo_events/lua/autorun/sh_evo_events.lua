-- "addons\\evo_events\\lua\\autorun\\sh_evo_events.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO EVENTS : les evenements du staff (30/09/2026, demande d'axxou).
--   Menu !event (superadmin, et animateurs sur leur perso animation) : compte a
--   rebours, alerte, message dans le ciel, feux d'artifice, lanternes, meteores,
--   la Sphere et ses fragments, ames errantes, fissures, coffres enfouis,
--   eclipse rituelle, brume toxique.
--
-- RIEN A TELECHARGER : sons et textures du jeu de base (verifies dans les VPK le
-- 30/09), modeles des packs EVO deja chez les joueurs (cristaux du pack #5,
-- coffre des maps). Le serveur decide tout, le client ne fait que montrer.
-- ============================================================================

EVO_EVENTS = EVO_EVENTS or {}

if SERVER then
	AddCSLuaFile("evo_events/sh_config.lua")
	AddCSLuaFile("evo_events/cl_events.lua")
	AddCSLuaFile("evo_events/cl_menu.lua")
end

include("evo_events/sh_config.lua")

if SERVER then
	include("evo_events/sv_events.lua")
else
	include("evo_events/cl_events.lua")
	include("evo_events/cl_menu.lua")
end
