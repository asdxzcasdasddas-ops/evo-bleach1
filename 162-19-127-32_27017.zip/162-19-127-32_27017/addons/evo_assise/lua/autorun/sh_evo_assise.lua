-- "addons\\evo_assise\\lua\\autorun\\sh_evo_assise.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ASSISE — points « [E] S'asseoir » (demande user 2026-07-24).
-- JUMEAU d'evo_repos, mais l'emote est « assis sur un bord, jambes pendantes »
-- (evo_2xl2ldmdujzb97 = celle du sit-anywhere ALT+E au bord d'un rebord).
-- À un SPOT (position + orientation, par map), un prompt [E] apparaît ; l'appui
-- pose le joueur sur le spot et joue l'emote assise via le pipeline du menu
-- d'animations -> cancel au mouvement + persistance PVS (arrivants).
--
-- Les spots sont ÉDITABLES IN-GAME (panneau SuperAdmin : concommand
-- « evo_assise_menu ») : ajout à ta position exacte, suppression, TP. Ils sont
-- PERSISTÉS (data/evo_assise_spots.json côté serveur) et NETWORKÉS aux clients
-- (aucun redémarrage nécessaire après un ajout/suppression).
--
-- Système SÉPARÉ d'evo_repos (nets/data/menu distincts) : place les spots à des
-- endroits différents des lits « S'allonger » (bords, murets, bancs...).
-- ============================================================================

EVO_ASSISE = EVO_ASSISE or {}

-- Emote jouée = « assis sur un bord » (jambes pendantes). MÊME séquence que le
-- sit-anywhere au bord (SIT_ANYWHERE_EMOTE_EDGE), jouée via ply:Animation.
EVO_ASSISE.Anim = "evo_2xl2ldmdujzb97" -- bleach_evo_FFF_INT_SitEdge

-- SEED initial (utilisé UNIQUEMENT si aucun fichier de données n'existe encore).
-- Vide par défaut : les spots se placent IN-GAME via le panneau SuperAdmin.
-- Ensuite, la vérité vient de EVO_ASSISE.Spots (fichier data / net).
EVO_ASSISE.DefaultSpots = {
	["hueco_mundo_v1"] = {
		-- Spots relevés user 2026-07-24 (evo_assise_print).
		{ pos = Vector(6757.866211, 4937.275391, 6315.681152), yaw = -179.991000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(6746.657715, 5181.968750, 6313.968262), yaw = -82.706000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(6772.882324, 5181.968750, 6313.968262), yaw = -82.706000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(6664.340820, 989.998474, 6311.931152), yaw = -89.073000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(6619.780273, 989.968750, 6311.931152), yaw = -89.073000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(-10784.363281, 397.299255, 6282.574219), yaw = 134.968000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(-11141.411133, 220.012878, 6282.324219), yaw = 94.971000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(-12419.639648, 657.544067, 6287.381348), yaw = -0.566000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(-4758.031250, -7519.070312, 7022.031250), yaw = 89.024000, radius = 90, label = "S'asseoir" },
	},
	["rp_seireitei_v1"] = {
		-- Spots relevés user 2026-07-24 (evo_assise_print).
		{ pos = Vector(-179.922791, 4417.673340, 2112.155273), yaw = -89.413000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(5238.568848, 5078.683594, 14921.756836), yaw = 94.920000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(5037.747070, 9597.301758, 14921.579102), yaw = -89.789000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(5227.755859, 9597.350586, 14921.861328), yaw = -85.826000, radius = 90, label = "S'asseoir" },
		{ pos = Vector(5424.671387, 9597.436523, 14922.356445), yaw = -85.297000, radius = 90, label = "S'asseoir" },
	},
}

-- Liste LIVE des spots par map. Serveur : chargée du fichier data (seed au 1er boot).
-- Client : reçue par le net EVO_Assise:Sync. NearestSpot l'utilise des deux côtés.
EVO_ASSISE.Spots = EVO_ASSISE.Spots or {}

-- Spot de la MAP COURANTE dont `pos` est le plus proche et dans son rayon.
-- Renvoie (spot, index) ou nil. Partagé (client : prompt ; serveur : revalidation).
function EVO_ASSISE.NearestSpot(vPos)
	local list = EVO_ASSISE.Spots[game.GetMap()]
	if not list then return nil end
	local best, bestD, bestI
	for i, s in ipairs(list) do
		local d = vPos:DistToSqr(s.pos)
		if d <= (s.radius * s.radius) and (not bestD or d < bestD) then
			best, bestD, bestI = s, d, i
		end
	end
	return best, bestI
end
