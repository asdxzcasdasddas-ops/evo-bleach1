-- "addons\\evo_assise\\lua\\autorun\\client\\cl_evo_assise.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ASSISE — CLIENT : prompt « [E] S'asseoir » près d'un spot + détection de
-- l'appui E. E envoie EVO_Assise:Sit (le serveur place + joue l'emote assise).
-- Si on est déjà assis sur le spot, E envoie StopAnimation (= se relever). On NE
-- vole PAS le E d'une entité usable (porte/PNJ/joueur/prop sous le réticule) ni
-- pendant un menu / KO -> aucun conflit avec le +use normal ou la roue radiale.
-- ============================================================================

if not CLIENT then return end

local COL_BG     = Color(14, 14, 17, 225)
local COL_ACCENT = Color(207, 68, 78, 255)
local COL_TXT    = Color(238, 239, 243, 255)

local function S(v) return math.Round(v * (ScrH() / 1080)) end

local function makeFonts()
	surface.CreateFont("EVO_Assise_Key",   { font = "Bebas Neue", size = S(20), weight = 600, antialias = true })
	surface.CreateFont("EVO_Assise_Label", { font = "Bebas Neue", size = S(26), weight = 500, antialias = true })
end
makeFonts()
hook.Add("OnScreenSizeChanged", "EVO_Assise::Fonts", makeFonts)

-- Le joueur joue-t-il DÉJÀ notre emote assise ? -> toggle « se relever ».
local function isSitting(lp)
	return lp:GetEvoNWString("EVO::AnimMenuLoopPath", "") == EVO_ASSISE.Anim
end

-- ── Détection de l'appui E (front montant) ──────────────────────────────────
local wasUse = false
local function SendSitAction(sitting)
	net.Start(sitting and "Evo:Server:AnimationMenu:StopAnimation" or "EVO_Assise:Sit")
	net.SendToServer()
end
hook.Add("Think", "EVO_Assise::Detect", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then wasUse = false return end
	local down = lp:KeyDown(IN_USE)
	local edge = down and not wasUse
	wasUse = down
	if not edge then return end
	if vgui.CursorVisible() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	if not EVO_ASSISE.NearestSpot(lp:GetPos()) then return end

	-- Ne pas voler le E d'une entité usable sous le réticule (porte/PNJ/joueur/prop
	-- proche) : le +use / la roue radiale gardent la priorité. Le sol (worldspawn,
	-- EntIndex 0) ne compte pas -> viser le sol du spot déclenche bien.
	local tr = lp:GetEyeTrace()
	if IsValid(tr.Entity) and tr.Entity:EntIndex() > 0
		and tr.HitPos:DistToSqr(lp:EyePos()) < 90 * 90 then
		return
	end

	SendSitAction(isSitting(lp))  -- netgate: edge -- USE key rising edge (wasUse)
end)

-- ── Prompt [E] près d'un spot ────────────────────────────────────────────────
hook.Add("HUDPaint", "EVO_Assise::Prompt", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("EVO_IsKO", false) then return end
	if vgui.CursorVisible() then return end
	local spot = EVO_ASSISE.NearestSpot(lp:GetPos())
	if not spot then return end

	local label = isSitting(lp) and "Se relever" or (spot.label or "S'asseoir")
	local cx, cy = ScrW() * 0.5, ScrH() * 0.5 + S(66)
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(cx, cy, "Siège", label, "E")
		return
	end

	surface.SetFont("EVO_Assise_Label")
	local lw = surface.GetTextSize(label)
	local keyR, gap = S(13), S(9)
	local totalW = keyR * 2 + gap + lw
	local x0 = cx - totalW * 0.5

	-- Fond discret derrière l'ensemble (lisibilité).
	local padX, padY = S(10), S(7)
	draw.RoundedBox(S(6), x0 - padX, cy - keyR - padY, totalW + padX * 2, keyR * 2 + padY * 2, COL_BG)
	-- Keycap accent « E ».
	local kx = x0 + keyR
	draw.RoundedBox(S(4), kx - keyR, cy - keyR, keyR * 2, keyR * 2, COL_ACCENT)
	draw.SimpleText("E", "EVO_Assise_Key", kx, cy + S(1), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	-- Libellé.
	draw.SimpleText(label, "EVO_Assise_Label", x0 + keyR * 2 + gap, cy, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)

-- ── Liste des spots reçue du serveur (persistée + éditable in-game) ──────────
net.Receive("EVO_Assise:Sync", function()
	EVO_ASSISE.Spots[game.GetMap()] = net.ReadTable()
	if EVO_ASSISE.RefreshMenu then EVO_ASSISE.RefreshMenu() end -- rafraîchit le panneau s'il est ouvert
end)

-- Demande la liste au chargement (le serveur re-push aussi au spawn, filet de sécurité).
hook.Add("InitPostEntity", "EVO_Assise::RequestSync", function()
	net.Start("EVO_Assise:RequestSync") net.SendToServer()
end)

-- ── Impression des spots dans la console (valeurs EXACTES du serveur) ────────
net.Receive("EVO_Assise:Print", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do print(net.ReadString()) end
	chat.AddText(Color(120, 220, 120), "[Assise] ", color_white, "spots imprimés dans la console (ouvre-la : « ² » / ~).")
end)

-- Raccourci sans passer par le panneau.
concommand.Add("evo_assise_print", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then
		chat.AddText(Color(255, 80, 80), "[Assise] Réservé aux SuperAdmins.")
		return
	end
	net.Start("EVO_Assise:Print") net.SendToServer()
end)
