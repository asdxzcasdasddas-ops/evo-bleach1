-- "addons\\evo_fosse\\lua\\autorun\\sh_loader_fosse.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- LA FOSSE — loader (pattern ncm_heal_bed). Duel sanctionné de la division de
-- combat : voir evo_fosse/sh_config_fosse.lua pour le design complet.

local base = "evo_fosse/"

if SERVER then
	AddCSLuaFile(base .. "sh_config_fosse.lua")
	AddCSLuaFile(base .. "cl_fosse.lua")

	include(base .. "sh_config_fosse.lua")
	include(base .. "sv_fosse.lua")
end

if CLIENT then
	include(base .. "sh_config_fosse.lua")
	include(base .. "cl_fosse.lua")
end
