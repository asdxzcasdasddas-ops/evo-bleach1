-- "addons\\evo_fosse\\lua\\evo_fosse\\cl_fosse.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LA FOSSE — client. (2026-07-17, v2 : menu dédié + arène + équipes)
-- MENU (bind lzy_bindmenu "fosse_menu", défaut F9, ouvrable UNIQUEMENT près de
-- l'arène) : onglet ORGANISER (équipes 1v1/2v2/3v3 + mise optionnelle) +
-- onglet CLASSEMENT (victoires/défaites, base partagée). Popup de CONSENTEMENT
-- des combattants, HUD par équipes (DA v2 forkée du duel instructeur), contour
-- de l'arène au sol, panneau d'arbitrage. Capitaine/vice-capitaine de la
-- division reçoivent le même HUD à distance (le serveur leur pousse le Sync).
-- ============================================================================

if not CLIENT then return end

EVO_FOSSE = EVO_FOSSE or {}
local CFG = EVO_FOSSE.Config

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

-- Polices : créées par le PIPELINE DU KIT (glibs gCreateRespFont) — même VRAIE
-- Bebas Neue TTF, responsive, et POIDS 400 (« Bebas SANS bold », règle DA) que
-- TOUTES les autres UIs EVO. Un surface.CreateFont brut à poids 700/800 rendait
-- un faux-bold / fallback (« pas la bonne fonte comme les autres »). evo_fosse
-- charge AVANT glibs -> on DIFFÈRE à Initialize (comme evo_ui), avec repli.
local function makeFosseFonts()
	local mk = gCreateRespFont
	if not mk then -- glibs pas encore prêt : Bebas brut, poids 400, scale manuel
		local sc = math.max(1, ScrH() / 1080)
		mk = function(name, font, size) surface.CreateFont(name, { font = font, size = math.Round(size * sc), weight = 400, extended = true }) end
	end
	mk("EVO_Fosse_Small", "Bebas Neue", 26, 400) -- menu / consentement / panneaux
	mk("EVO_Fosse_Text",  "Bebas Neue", 36, 400)
	mk("EVO_Fosse_Head",  "Bebas Neue", 48, 400)
	mk("EVO_Fosse_Score", "Bebas Neue", 78, 400)
	mk("EVO_Fosse_HTiny",  "Bebas Neue", 16, 400) -- HUD de combat (compact)
	mk("EVO_Fosse_HName",  "Bebas Neue", 21, 400)
	mk("EVO_Fosse_HScore", "Bebas Neue", 42, 400)
	mk("EVO_Fosse_HBig",   "Bebas Neue", 58, 400)
end
makeFosseFonts()
hook.Add("Initialize", "EVO_Fosse::Fonts", makeFosseFonts)
hook.Add("OnScreenSizeChanged", "EVO_Fosse::Fonts", makeFosseFonts)

local duel     = nil -- état sync du duel (cf. net Sync)
local pMenu    = nil -- menu principal (F9)
local pRef     = nil -- panneau d'arbitrage
local pConsent = nil -- popup de consentement

local matBeam = Material("cable/redlaser")

-- Petite croix de fermeture locale (le CloseButton du kit se cale en ratio
-- LARGEUR, nos cartes sont en R() ratio min -> il sortirait sur ultrawide).
-- Croix de fermeture IDENTIQUE au reste des UIs (cf. EVO_UI.CloseButton) : glyphe
-- ✕ seul, SANS fond, gris -> accent. Positionnée en R() comme nos cartes.
local function closeX(parent, cardW, fn)
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(34), R(34)) x:SetPos(R(cardW - 48), R(16)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		local col = COL()
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- ── Spectateur ÉLOIGNÉ de l'arène : HUD masqué LOCALEMENT (demande user 08/06 :
-- l'UI restait jusqu'à la fin du duel même très loin). La vérif est côté CLIENT :
-- il connaît sa position à chaque frame et l'arène via la config partagée -> zéro
-- réseau, zéro travail serveur, réaction immédiate (le serveur n'envoie de toute
-- façon plus de mise à jour hors du rayon de suivi ; en revenant, son heartbeat
-- resservira des données fraîches). duel.follow (arbitre, combattant, capitaine/
-- vice de la division de combat) = jamais masqué : suivi à distance (07/17).
-- Hystérésis 500 u pour ne pas clignoter pile à la frontière du rayon.
local SPECT_MARGIN = 3500 -- même marge que le rayon de suivi serveur (launchResolved)

local function hudHidden()
	if duel.follow or duel.amFighter then return false end
	local lp = LocalPlayer()
	if not IsValid(lp) then return true end
	local vMin, vMax, vC = EVO_FOSSE.GetArenaBounds()
	if not vC then return false end
	local nR = math.max(vMax.x - vMin.x, vMax.y - vMin.y) * 0.5 + SPECT_MARGIN
	if not duel._farHidden then nR = nR + 500 end -- visible -> on ne masque qu'un peu plus loin
	duel._farHidden = lp:GetPos():DistToSqr(vC) > nR * nR
	return duel._farHidden
end

-- ── Contour de l'ARÈNE au sol pendant un duel (les boîtes viennent du Sync) ───
hook.Add("PostDrawTranslucentRenderables", "EVO_Fosse::Arena", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (duel and duel.active and duel.boxes) then return end
	if duel._farHidden then return end -- même règle que le HUD (posé par hudHidden)
	local col = COL()
	local pulse = 0.7 + math.sin(CurTime() * 3) * 0.3
	local c = (duel.status == "fighting") and col.accent or col.muted
	local drawCol = Color(c.r, c.g, c.b, 255 * pulse)
	local z = (duel.groundZ or 0) + 10
	render.SetMaterial(matBeam)
	for _, b in ipairs(duel.boxes) do
		local p1 = Vector(b.mins.x, b.mins.y, z)
		local p2 = Vector(b.maxs.x, b.mins.y, z)
		local p3 = Vector(b.maxs.x, b.maxs.y, z)
		local p4 = Vector(b.mins.x, b.maxs.y, z)
		render.DrawBeam(p1, p2, 24, 0, 1, drawCol)
		render.DrawBeam(p2, p3, 24, 0, 1, drawCol)
		render.DrawBeam(p3, p4, 24, 0, 1, drawCol)
		render.DrawBeam(p4, p1, 24, 0, 1, drawCol)
	end
end)

-- ── HUD par équipes ───────────────────────────────────────────────────────────
local function hpBar(x, y, w, h, frac, col)
	surface.SetDrawColor(ColorAlpha(color_white, 22))
	surface.DrawRect(x, y, w, h)
	local fw = math.max(0, math.min(1, frac or 0)) * w
	local c = (frac > 0.5 and col.green) or (frac > 0.25 and Color(220, 180, 70)) or col.accent
	if fw > 1 then
		surface.SetDrawColor(c)
		surface.DrawRect(x, y, fw, h)
	end
end

local function liveFrac(f)
	if IsValid(f.ent) and f.ent:IsPlayer() then
		-- Vrai max via NWInt EVO_MaxHP (GetMaxHealth des AUTRES joueurs = 100 côté
		-- client) ; repli sur la fraction synchronisée par le serveur.
		local nMax = f.ent:GetEvoNWInt("EVO_MaxHP", 0)
		if nMax <= 0 then return f.hp or 0 end
		return math.Clamp(f.ent:Health() / nMax, 0, 1)
	end
	return f.hp or 0
end

local function teamName(n) return n == 1 and "ÉQUIPE A" or "ÉQUIPE B" end

hook.Add("HUDPaint", "EVO_Fosse::HUD", function()
	if not (duel and duel.active) then return end
	if hudHidden() then return end
	local col = COL()
	local nRows = math.max(#(duel.t1 or {}), #(duel.t2 or {}), 1)

	-- Tableau de bord COMPACT en haut, centré (spectateurs comme combattants).
	local W    = R(560)
	local rowH = R(30)
	local yHdr = R(66)            -- bandeau titre + score
	local H    = yHdr + nRows * rowH + R(26)
	-- Sous la boussole ET ses libellés : « TERRAIN D'ENTRAÎNEMENT » (kanji 闘 gravé +
	-- filet accent, bleach_compass) descend jusqu'à ~11 % de la hauteur, et 9 % passait
	-- donc par-dessus (report user 08/09). Même ancrage que les events instructeur
	-- (EVO_INSTRUCTEUR.HudTopY) — garder les deux valeurs alignées.
	local x, y = ScrW() / 2 - W / 2, math.Round(ScrH() * 0.13)

	-- Carte : fond plat, liseré accent en tête + petite barre d'accent à gauche
	-- (rappel de la DA des registres SOIN / Amende).
	surface.SetDrawColor(ColorAlpha(col.bg, 240)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(col.line) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(col.accent) surface.DrawRect(x, y, W, R(3))
	surface.SetDrawColor(col.accent) surface.DrawRect(x, y + R(3), R(3), H - R(3))

	draw.SimpleText("LA FOSSE · arbitré par " .. (duel.arb or ""), "EVO_Fosse_HTiny", x + W / 2, y + R(9), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Score au centre + labels d'équipe de part et d'autre.
	draw.SimpleText((duel.score1 or 0) .. " - " .. (duel.score2 or 0), "EVO_Fosse_HScore", x + W / 2, y + R(42), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(teamName(1), "EVO_Fosse_HName", x + R(16), y + R(42), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText(teamName(2), "EVO_Fosse_HName", x + W - R(16), y + R(42), col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	-- Rangées combattants : nom + barre de vie fine + % ; « À TERRE » si éliminé.
	local bw = R(150)
	for nTeam = 1, 2 do
		local tTeam = (nTeam == 1) and duel.t1 or duel.t2
		local bLeft = (nTeam == 1)
		for i, f in ipairs(tTeam or {}) do
			local ry = y + yHdr + (i - 1) * rowH
			local nx = bLeft and (x + R(16)) or (x + W - R(16))
			local cName = f.elim and col.dim or col.title
			draw.SimpleText(f.name or "?", "EVO_Fosse_HName", nx, ry + rowH * 0.5, cName, bLeft and TEXT_ALIGN_LEFT or TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			local bx = bLeft and (x + W / 2 - R(18) - bw) or (x + W / 2 + R(18))
			local by, bh = ry + rowH * 0.5 - R(7), R(14)
			if f.elim then
				surface.SetDrawColor(ColorAlpha(col.accent, 70)) surface.DrawRect(bx, by, bw, bh)
				surface.SetDrawColor(col.accent) surface.DrawOutlinedRect(bx, by, bw, bh)
				draw.SimpleText("À TERRE", "EVO_Fosse_HTiny", bx + bw / 2, by + bh / 2, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				local fr = liveFrac(f)
				hpBar(bx, by, bw, bh, fr, col)
				draw.SimpleText(math.Round(fr * 100) .. "%", "EVO_Fosse_HTiny", bx + bw / 2, by + bh / 2, col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- Ligne d'état (+ mise si duel à enjeu) en bas de carte.
	local status
	if duel.status == "countdown" then status = "MANCHE " .. (duel.round or 1) .. " · PRÉPARE-TOI"
	elseif duel.status == "fighting" then status = "MANCHE " .. (duel.round or 1) .. " · COMBAT"
	elseif duel.status == "roundover" then status = "MANCHE À L'" .. teamName(duel.roundWinner or 1)
	elseif duel.status == "done" then status = duel.champion and ("VAINQUEUR : " .. teamName(duel.champion)) or "MATCH NUL"
	else status = "" end
	if (duel.stake or 0) > 0 then status = status .. "  ·  MISE " .. string.Comma(duel.stake) .. "¥" end
	MUGEN.DrawMoneyLine(status, "EVO_Fosse_HTiny",
		x + W / 2, y + H - R(15), duel.status == "done" and col.green or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Décompte / vainqueur au centre de l'écran (repère de manche).
	if duel.status == "countdown" then
		local n = math.ceil((duel.phaseEnd or 0) - CurTime())
		if n > 0 then
			draw.SimpleTextOutlined(tostring(n), "EVO_Fosse_HBig", ScrW() / 2, ScrH() * 0.42, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	elseif duel.status == "done" and duel.champion then
		draw.SimpleTextOutlined("VAINQUEUR : " .. teamName(duel.champion), "EVO_Fosse_HScore", ScrW() / 2, ScrH() * 0.42, col.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
	end

	-- Rappel des touches : arbitre -> arbitrer ; combattant -> abandonner.
	local sHint
	if duel.isRef and duel.status ~= "done" then
		sHint = "[F9] arbitrer"
	elseif duel.amFighter and duel.status ~= "done" then
		sHint = "[F9] abandonner"
	end
	if sHint then
		draw.SimpleText(sHint, "EVO_Fosse_HTiny", x + W / 2, y + H + R(6), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau d'arbitrage (arbitre) ─────────────────────────────────────────────
local function openRefPanel()
	if not (duel and duel.active and duel.isRef and duel.status ~= "done") then return end
	if IsValid(pRef) then pRef:Remove() return end
	local col = COL()
	local W, H = 560, 300
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup() f:SetDraggable(false)
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(14))
		draw.SimpleText("ARBITRER LA FOSSE", "EVO_Fosse_Head", R(26), R(30), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("EVO_Fosse_Head")
		local twR = surface.GetTextSize("ARBITRER LA FOSSE")
		local swR = twR * 0.9
		if not (EVO_UI.Ink and EVO_UI.TexSlash and EVO_UI.Ink(EVO_UI.TexSlash, R(26), R(48), swR, math.Clamp(swR * 0.05, R(7), R(12)), ColorAlpha(col.accent, 245))) then
			surface.SetDrawColor(col.accent) surface.DrawRect(R(26), R(52), R(180), R(4))
		end
		draw.SimpleText("MANCHE " .. ((duel and duel.round) or 1) .. "   ·   ÉQUIPE A  " .. ((duel and duel.score1) or 0)
			.. " - " .. ((duel and duel.score2) or 0) .. "  ÉQUIPE B", "EVO_Fosse_Text", R(26), R(88), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	closeX(f, W, function() f:Remove() end)

	local halfW = (W - 64) / 2
	EVO_UI.ActionButton(f, R(28), R(120), R(halfW), R(52), "MANCHE : ÉQUIPE A", col.green, function()
		net.Start("EVO:Fosse:ForceWin") net.WriteUInt(1, 2) net.SendToServer()
	end)
	EVO_UI.ActionButton(f, R(28 + halfW + 8), R(120), R(halfW), R(52), "MANCHE : ÉQUIPE B", col.green, function()
		net.Start("EVO:Fosse:ForceWin") net.WriteUInt(2, 2) net.SendToServer()
	end)
	EVO_UI.ActionButton(f, R(28), R(184), R(W - 56), R(52), "ANNULER LE DUEL (mises annulées)", nil, function()
		net.Start("EVO:Fosse:Cancel") net.SendToServer() f:Remove()
	end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Panneau d'ABANDON (combattant) : quitte le combat, libère tout le monde ──
local pForfeit = nil
local function openForfeitPanel()
	if not (duel and duel.active and duel.amFighter and duel.status ~= "done") then return end
	if IsValid(pForfeit) then pForfeit:Remove() return end
	local col = COL()
	local W, H = 540, 250
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup() f:SetDraggable(false)
	pForfeit = f
	f.OnRemove = function() if pForfeit == f then pForfeit = nil end end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(14))
		draw.SimpleText("ABANDONNER LE COMBAT", "EVO_Fosse_Head", w / 2, R(40), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Tu déclares forfait : ton équipe perd le duel", "EVO_Fosse_Text", w / 2, R(96), col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("et l'arène est libérée pour les autres.", "EVO_Fosse_Small", w / 2, R(128), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeX(f, W, function() f:Remove() end)

	local halfW = (W - 64) / 2
	EVO_UI.ActionButton(f, R(28), R(H - 74), R(halfW), R(52), "ABANDONNER", col.accent, function()
		net.Start("EVO:Fosse:Forfeit") net.SendToServer() f:Remove()
	end)
	EVO_UI.ActionButton(f, R(28 + halfW + 8), R(H - 74), R(halfW), R(52), "CONTINUER", nil, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Joueurs proches de l'arène (requête + callback) ──────────────────────────
local _nearbyCb = nil
local function requestNearby(cb)
	_nearbyCb = cb
	net.Start("EVO:Fosse:Nearby") net.SendToServer()
end
net.Receive("EVO:Fosse:Nearby", function()
	local n = net.ReadUInt(6)
	local list = {}
	for i = 1, n do
		local sid  = net.ReadString()
		local name = net.ReadString()
		list[#list + 1] = { sid = sid, name = name }
	end
	if _nearbyCb then local cb = _nearbyCb _nearbyCb = nil cb(list) end
end)

-- ── Classement (requête + callback) ──────────────────────────────────────────
local _ladderCb = nil
local function requestLadder(cb)
	_ladderCb = cb
	net.Start("EVO:Fosse:Ladder") net.SendToServer()
end
net.Receive("EVO:Fosse:Ladder", function()
	local n = net.ReadUInt(8)
	local rows = {}
	for i = 1, n do
		rows[#rows + 1] = { name = net.ReadString(), wins = net.ReadUInt(16), losses = net.ReadUInt(16) }
	end
	if _ladderCb then local cb = _ladderCb _ladderCb = nil cb(rows) end
end)

-- ── MENU PRINCIPAL (bind F9) : ORGANISER + CLASSEMENT ────────────────────────
local MAXTEAM = (CFG and CFG.MaxTeamSize) or 3

local function openMenu()
	if IsValid(pMenu) then pMenu:Remove() return end
	local col = COL()
	local W, H = 880, 800 -- +60 : ligne DURÉE ajoutée (09/05)
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup() f:SetDraggable(false)
	pMenu = f
	f.OnRemove = function() if pMenu == f then pMenu = nil end end
	f._tab = 1 -- 1 = ORGANISER, 2 = CLASSEMENT

	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(14))
		draw.SimpleText("LA FOSSE", "EVO_Fosse_Score", R(32), R(42), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("EVO_Fosse_Score")
		local tw = surface.GetTextSize("LA FOSSE")
		-- Slash « Atelier » COURT : pinceau EVO_UI à ~0,9× la largeur du titre (le
		-- 1,3× de TitleSlash débordait « trop long »).
		local sw = tw * 0.9
		if not (EVO_UI.Ink and EVO_UI.TexSlash and EVO_UI.Ink(EVO_UI.TexSlash, R(32), R(70), sw, math.Clamp(sw * 0.05, R(8), R(13)), ColorAlpha(col.accent, 245))) then
			surface.SetDrawColor(col.accent) surface.DrawRect(R(32), R(80), math.min(tw, R(240)), R(5))
		end
	end
	closeX(f, W, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end

	-- Onglets (2 boutons plats), sous le titre agrandi.
	local function tabBtn(sLabel, nTab, xPos)
		local b = vgui.Create("DButton", f) b:SetText("") b:SetPos(R(xPos), R(104)) b:SetSize(R(240), R(44))
		b.Paint = function(s, w, h)
			local bOn = f._tab == nTab
			surface.SetDrawColor(bOn and ColorAlpha(col.accent, 40) or ColorAlpha(color_white, s:IsHovered() and 16 or 8))
			surface.DrawRect(0, 0, w, h)
			if bOn then surface.SetDrawColor(col.accent) surface.DrawRect(0, h - R(3), w, R(3)) end
			draw.SimpleText(sLabel, "EVO_Fosse_Text", w / 2, h / 2, bOn and col.title or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function() f._tab = nTab f:RebuildTab() end
		return b
	end
	tabBtn("ORGANISER", 1, 28)
	tabBtn("CLASSEMENT", 2, 284)

	local body = vgui.Create("DPanel", f) body:SetPos(R(28), R(164)) body:SetSize(R(W - 56), R(H - 188))
	body.Paint = nil

	function f:RebuildTab()
		body:Clear()
		if self._tab == 1 then self:BuildOrganize() else self:BuildLadder() end
	end

	-- ═══ ONGLET ORGANISER : composer 2 équipes (clic = A -> B -> retiré) ═══
	function f:BuildOrganize()
		local assign = {} -- [sid] = 1 | 2 | nil
		local nWin   = 2  -- format : premier à N manche(s) (1/2/3), défaut best-of-3
		local nTime  = 2  -- index dans CFG.Duel.TimeChoices (défaut : la 2e, 10 min)
		local rowsPanel
		local bW = W - 56 -- largeur utile du corps

		local counts = vgui.Create("DLabel", body) counts:SetPos(0, 0) counts:SetSize(R(bW), R(30))
		counts:SetFont("EVO_Fosse_Text") counts:SetTextColor(col.muted) counts:SetText("A : 0   ·   B : 0")
		local function refreshCounts()
			local nA, nB = 0, 0
			for _, v in pairs(assign) do if v == 1 then nA = nA + 1 elseif v == 2 then nB = nB + 1 end end
			counts:SetText("A : " .. nA .. "   ·   B : " .. nB)
			counts:SetTextColor((nA == nB and nA >= 1) and col.green or col.muted)
			return nA, nB
		end

		rowsPanel = vgui.Create("DScrollPanel", body) rowsPanel:SetPos(0, R(36)) rowsPanel:SetSize(R(bW), R(288))

		local function countTeam(nTeam)
			local n = 0
			for _, v in pairs(assign) do if v == nTeam then n = n + 1 end end
			return n
		end

		local sMySid = IsValid(LocalPlayer()) and LocalPlayer():SteamID64() or ""
		requestNearby(function(list)
			if not IsValid(rowsPanel) then return end
			if #list < 2 then
				local none = vgui.Create("DLabel", rowsPanel) none:Dock(TOP) none:SetTall(R(32))
				none:SetFont("EVO_Fosse_Text") none:SetTextColor(col.dim)
				none:SetText("Pas assez de joueurs près de l'arène (2 minimum, toi compris).")
				return
			end
			for i, p in ipairs(list) do
				-- Tu peux TE compter toi-même (le serveur te met en tête de liste).
				local sName = p.name .. (p.sid == sMySid and "   (TOI)" or "")
				local b = vgui.Create("DButton", rowsPanel) b:SetText("") b:Dock(TOP) b:DockMargin(0, 0, 0, R(4)) b:SetTall(R(36))
				b.Paint = function(s, w, h)
					local nTeam = assign[p.sid]
					local cBg = nTeam == 1 and ColorAlpha(col.accent, 45) or nTeam == 2 and ColorAlpha(col.green, 40)
						or ColorAlpha(color_white, s:IsHovered() and 14 or 7)
					surface.SetDrawColor(cBg) surface.DrawRect(0, 0, w, h)
					if nTeam then surface.SetDrawColor(nTeam == 1 and col.accent or col.green) surface.DrawRect(0, 0, R(3), h) end
					draw.SimpleText(string.format("%02d", i), "EVO_Fosse_Text", R(14), h / 2, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(sName, "EVO_Fosse_Text", R(54), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					local sTag = nTeam == 1 and "ÉQUIPE A" or nTeam == 2 and "ÉQUIPE B" or ""
					local cTag = nTeam == 1 and col.accent or col.green
					if sTag ~= "" then draw.SimpleText(sTag, "EVO_Fosse_Text", w - R(12), h / 2, cTag, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) end
				end
				b.DoClick = function()
					local cur = assign[p.sid]
					if cur == nil then
						if countTeam(1) < MAXTEAM then assign[p.sid] = 1 end
					elseif cur == 1 then
						assign[p.sid] = (countTeam(2) < MAXTEAM) and 2 or nil
					else
						assign[p.sid] = nil
					end
					refreshCounts()
				end
			end
		end)

		-- FORMAT : premier à N manche(s) — sélecteur segmenté 1 / 2 / 3 (demande user 07/17).
		local yF = R(334)
		local flbl = vgui.Create("DLabel", body) flbl:SetPos(0, yF + R(6)) flbl:SetSize(R(320), R(32))
		flbl:SetFont("EVO_Fosse_Text") flbl:SetTextColor(col.muted) flbl:SetText("PREMIER À")
		for i = 1, 3 do
			local seg = vgui.Create("DButton", body) seg:SetText("")
			seg:SetPos(R(300 + (i - 1) * 92), yF) seg:SetSize(R(84), R(44))
			seg.Paint = function(s, w, h)
				local bOn = nWin == i
				surface.SetDrawColor(bOn and col.accent or ColorAlpha(color_white, s:IsHovered() and 16 or 8))
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(tostring(i), "EVO_Fosse_Text", w / 2, h / 2, bOn and Color(20, 20, 24) or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			seg.DoClick = function() nWin = i surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3") end
		end
		local fhint = vgui.Create("DLabel", body) fhint:SetPos(R(300 + 3 * 92 + 10), yF + R(6)) fhint:SetSize(R(220), R(32))
		fhint:SetFont("EVO_Fosse_Small") fhint:SetTextColor(col.dim) fhint:SetText("manche(s) gagnante(s)")

		-- DURÉE DU DUEL (user 09/05) : même sélecteur segmenté que le format. La liste vient
		-- de la config PARTAGÉE, le serveur re-borne sur la même -> pas de valeur libre.
		local tTimes = (CFG.Duel and CFG.Duel.TimeChoices) or { 300, 600, 900, 1200 }
		local yD = R(392)
		local dlbl = vgui.Create("DLabel", body) dlbl:SetPos(0, yD + R(6)) dlbl:SetSize(R(320), R(32))
		dlbl:SetFont("EVO_Fosse_Text") dlbl:SetTextColor(col.muted) dlbl:SetText("DURÉE MAX")
		for i = 1, math.min(#tTimes, 4) do
			local seg = vgui.Create("DButton", body) seg:SetText("")
			seg:SetPos(R(300 + (i - 1) * 92), yD) seg:SetSize(R(84), R(44))
			seg.Paint = function(s2, w, h)
				local bOn = nTime == i
				surface.SetDrawColor(bOn and col.accent or ColorAlpha(color_white, s2:IsHovered() and 16 or 8))
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(math.floor(tTimes[i] / 60) .. " min", "EVO_Fosse_Text", w / 2, h / 2,
					bOn and Color(20, 20, 24) or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			seg.DoClick = function() nTime = i surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3") end
		end
		local dhint = vgui.Create("DLabel", body) dhint:SetPos(R(300 + 4 * 92 + 10), yD + R(6)) dhint:SetSize(R(240), R(32))
		dhint:SetFont("EVO_Fosse_Small") dhint:SetTextColor(col.dim) dhint:SetText("décomptes et pauses inclus")

		-- MISE OPTIONNELLE (0 = amical). Bornée ici pour le confort, RE-bornée serveur.
		local yM = R(450)
		local lbl = vgui.Create("DLabel", body) lbl:SetPos(0, yM + R(8)) lbl:SetSize(R(300), R(32))
		lbl:SetFont("EVO_Fosse_Text") lbl:SetTextColor(col.muted) lbl:SetText("MISE PAR TÊTE (0 = amical)")
		local entry = vgui.Create("DTextEntry", body) entry:SetPos(R(300), yM) entry:SetSize(R(bW - 300), R(44))
		entry:SetFont("EVO_Fosse_Text") entry:SetNumeric(true) entry:SetText("0")
		entry:SetPaintBackground(false)
		if entry.SetDrawLanguageID then entry:SetDrawLanguageID(false) end -- pas d'indicateur clavier « FR » dans la zone
		entry.Paint = function(s, w, h)
			surface.SetDrawColor(ColorAlpha(color_white, 14)) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(col.line) surface.DrawOutlinedRect(0, 0, w, h)
			s:DrawTextEntryText(col.title, col.accent, col.title)
		end

		local note = vgui.Create("DLabel", body) note:SetPos(0, yM + R(52)) note:SetSize(R(bW), R(24))
		note:SetFont("EVO_Fosse_Small") note:SetTextColor(col.green)
		note:SetText("Aucune blessure profonde comptée · arène fermée aux autres pendant le combat.")

		local launch = EVO_UI.ActionButton(body, 0, yM + R(84), R(bW), R(58), "LANCER LE DÉFI", col.green, function()
			local tA, tB = {}, {}
			for sid, v in pairs(assign) do
				if v == 1 then tA[#tA + 1] = sid elseif v == 2 then tB[#tB + 1] = sid end
			end
			if #tA < 1 or #tA ~= #tB or #tA > MAXTEAM then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Compose deux équipes de même taille (1v1, 2v2 ou 3v3).", NOTIFY_ERROR or 1, 4) end
				return
			end
			local nStake = math.max(0, math.floor(tonumber(entry:GetText()) or 0))
			net.Start("EVO:Fosse:Create")
				net.WriteUInt(#tA, 2)
				for _, sid in ipairs(tA) do net.WriteString(sid) end
				for _, sid in ipairs(tB) do net.WriteString(sid) end
				net.WriteUInt(math.min(nStake, 2 ^ 31 - 1), 32)
				net.WriteUInt(math.Clamp(nWin, 1, 3), 2) -- format : premier à N manches
				net.WriteUInt(math.Clamp(nTime, 1, 4), 3) -- index de durée (CFG.Duel.TimeChoices)
			net.SendToServer()
			f:Remove()
		end)
		-- L'ActionButton câble EVO_UI_Item (~19) : trop petit à côté du menu. On garde
		-- son aplat + hover et on grossit juste le libellé (police du menu).
		launch.Paint = function(s, bw, bh)
			local base = col.green
			local hf = (EVO_UI.HoverFrac and EVO_UI.HoverFrac(s, 8)) or (s:IsHovered() and 1 or 0)
			local c = Color(Lerp(hf, base.r * 0.80, base.r), Lerp(hf, base.g * 0.80, base.g), Lerp(hf, base.b * 0.80, base.b), 255)
			EVO_UI.PaintCut(0, 0, bw, bh, c, R(10), "br")
			draw.SimpleText("LANCER LE DÉFI", "EVO_Fosse_Text", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- ═══ ONGLET CLASSEMENT : top 20 (victoires / défaites) ═══
	function f:BuildLadder()
		local scroll = vgui.Create("DScrollPanel", body) scroll:SetPos(0, 0) scroll:SetSize(R(W - 40), R(H - 200))
		requestLadder(function(rows)
			if not IsValid(scroll) then return end
			if #rows == 0 then
				local none = vgui.Create("DLabel", scroll) none:Dock(TOP) none:SetTall(R(32))
				none:SetFont("EVO_Fosse_Text") none:SetTextColor(col.dim)
				none:SetText("Aucun duel enregistré pour l'instant : ouvre la Fosse !")
				return
			end
			for i, r in ipairs(rows) do
				local row = vgui.Create("DPanel", scroll) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(36))
				row.Paint = function(s, w, h)
					surface.SetDrawColor(ColorAlpha(color_white, i <= 3 and 14 or 7)) surface.DrawRect(0, 0, w, h)
					if i <= 3 then surface.SetDrawColor(i == 1 and col.accent or col.muted) surface.DrawRect(0, 0, R(3), h) end
					local cRank = i == 1 and col.accent or (i <= 3 and col.title) or col.dim
					draw.SimpleText(string.format("%02d", i), "EVO_Fosse_Text", R(14), h / 2, cRank, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(r.name, "EVO_Fosse_Text", R(60), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(r.wins .. " V", "EVO_Fosse_Text", w - R(120), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					draw.SimpleText(r.losses .. " D", "EVO_Fosse_Text", w - R(20), h / 2, col.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
		end)
	end

	f:RebuildTab()
end

-- ── Ouverture par bind (lzy_bindmenu "fosse_menu", défaut F9) + concommand ────
-- Arbitre en plein duel -> panneau d'arbitrage ; sinon menu (SEULEMENT près de
-- l'arène — l'organisation se fait SUR PLACE, règle user).
local function toggleFosse()
	-- En plein duel : arbitre -> panneau d'arbitrage ; combattant -> panneau d'abandon.
	if duel and duel.active and duel.status ~= "done" then
		if duel.isRef then openRefPanel() return end
		if duel.amFighter then openForfeitPanel() return end
	end
	if IsValid(pMenu) then pMenu:Remove() return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if not (EVO_FOSSE.CanArbiter and EVO_FOSSE.CanArbiter(lp)) then return end
	if not EVO_FOSSE.HasArena() then
		if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Aucune arène de la Fosse sur cette map.", NOTIFY_ERROR or 1, 4) end
		return
	end
	if EVO_FOSSE.DistToArena(lp:GetPos()) > ((CFG and CFG.OpenMargin) or 1500) then
		if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Rapproche-toi de l'arène de la division pour ouvrir la Fosse.", NOTIFY_ERROR or 1, 4) end
		return
	end
	openMenu()
end

EVO_FOSSE._closedAt = 0
concommand.Add("evo_fosse_menu", toggleFosse)

-- RÈGLE repo : PlayerButtonDown filtre le 1er arg (prédiction).
hook.Add("PlayerButtonDown", "EVO_Fosse::Bind", function(ply, button)
	if not IsValid(ply) or ply ~= LocalPlayer() then return end
	if SysTime() - (EVO_FOSSE._closedAt or 0) < 0.3 then return end -- anti-réouverture même appui
	if not ply.GetBindKey then return end
	local k = ply:GetBindKey("fosse_menu")
	if k and k ~= KEY_NONE and button == k then
		toggleFosse()
	end
end)

-- evo_fosse_forfeit : ouvre le panneau d'abandon (même si on est AUSSI arbitre :
--                     F9 route en priorité vers l'arbitrage), sinon envoie direct.
-- (evo_fosse_win RETIRÉ 2026-07-20 : raccourci de test qui fuitait dans l'autocomplétion
--  console de tous ; forcer une manche passe par les boutons du panneau d'arbitrage.)
concommand.Add("evo_fosse_forfeit", function()
	if duel and duel.active and duel.amFighter and duel.status ~= "done" then
		openForfeitPanel() return
	end
	net.Start("EVO:Fosse:Forfeit") net.SendToServer()
end)

-- ── Consentement du combattant (popup 30 s ; fermer = refuser) ────────────────
net.Receive("EVO:Fosse:Consent", function()
	if not net.ReadBool() then
		if IsValid(pConsent) then pConsent._silent = true pConsent:Remove() pConsent = nil end
		return
	end
	local sArb    = net.ReadString()
	local sFmt    = net.ReadString()
	local sAllies = net.ReadString()
	local sFoes   = net.ReadString()
	local nMise   = net.ReadUInt(32)
	local nSec    = net.ReadFloat()
	local col     = COL()

	if IsValid(pConsent) then pConsent._silent = true pConsent:Remove() end
	local W, H = 600, 370
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup() f:SetDraggable(false)
	pConsent = f
	local nUntil = CurTime() + (nSec or 30)
	local bAnswered = false
	local function answer(bYes)
		if bAnswered then return end
		bAnswered = true
		net.Start("EVO:Fosse:Answer") net.WriteBool(bYes) net.SendToServer()
		if IsValid(f) then f:Remove() end
	end
	f.OnRemove = function()
		if pConsent == f then pConsent = nil end
		-- Fermer/Échap = refuser (jamais de duel non consenti) ; _silent = fermeture
		-- poussée par le serveur (défi déjà annulé) -> pas de réponse à envoyer.
		if not bAnswered and not f._silent then answer(false) end
	end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(14))
		draw.SimpleText("LA FOSSE T'APPELLE", "EVO_Fosse_Head", R(24), R(34), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("DUEL SANCTIONNÉ " .. sFmt, "EVO_Fosse_Small", R(26), R(64), col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Arbitre : " .. sArb, "EVO_Fosse_Text", R(24), R(108), col.muted)
		draw.SimpleText("Tes alliés : " .. sAllies, "EVO_Fosse_Text", R(24), R(146), col.title)
		draw.SimpleText("En face : " .. sFoes, "EVO_Fosse_Text", R(24), R(184), col.title)
		MUGEN.DrawMoneyLine(nMise > 0 and ("Mise : " .. string.Comma(nMise) .. "¥ par tête — le vainqueur empoche celle de son vis-à-vis.")
			or "Duel amical — aucune mise.", "EVO_Fosse_Small", R(24), R(222), nMise > 0 and col.accent or col.muted)
		draw.SimpleText("Duel encadré : aucune blessure profonde ne sera comptée.", "EVO_Fosse_Small", R(24), R(248), col.green)
		local left = math.max(0, nUntil - CurTime())
		draw.SimpleText(math.ceil(left) .. " s", "EVO_Fosse_Text", w - R(24), R(48), col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(color_white, 14)) surface.DrawRect(R(24), R(276), w - R(48), R(8))
		surface.SetDrawColor(col.accent) surface.DrawRect(R(24), R(276), (w - R(48)) * math.Clamp(left / math.max(1, nSec), 0, 1), R(8))
	end
	f.Think = function()
		if CurTime() > nUntil and not bAnswered then f:Remove() end
	end

	local halfW = (W - 56) / 2
	EVO_UI.ActionButton(f, R(24), R(H - 68), R(halfW), R(44), "ACCEPTER", col.green, function() answer(true) end)
	EVO_UI.ActionButton(f, R(24 + halfW + 8), R(H - 68), R(halfW), R(44), "REFUSER", nil, function() answer(false) end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end)

-- ── NET : sync du duel ────────────────────────────────────────────────────────
net.Receive("EVO:Fosse:Sync", function()
	if not net.ReadBool() then
		duel = nil
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local d = { active = true }
	d.status      = net.ReadString()
	d.arb         = net.ReadString()
	d.score1      = net.ReadUInt(4)
	d.score2      = net.ReadUInt(4)
	d.round       = net.ReadUInt(4)
	d.need        = net.ReadUInt(4)
	d.phase       = net.ReadFloat()
	local nRW     = net.ReadUInt(2)
	local nCh     = net.ReadUInt(2)
	d.roundWinner = nRW ~= 0 and nRW or nil
	d.champion    = nCh ~= 0 and nCh or nil
	d.isRef       = net.ReadBool()
	d.follow      = net.ReadBool() -- autorisé à suivre de loin (arbitre / combattant / capitaine-vice)
	d.stake       = net.ReadUInt(32)
	d.groundZ     = net.ReadFloat()
	d.boxes       = {}
	local nBoxes  = net.ReadUInt(4)
	for i = 1, nBoxes do
		d.boxes[i] = { mins = net.ReadVector(), maxs = net.ReadVector() }
	end
	d.t1, d.t2 = {}, {}
	for _, tTeam in ipairs({ d.t1, d.t2 }) do
		local n = net.ReadUInt(2)
		for i = 1, n do
			tTeam[i] = {
				name = net.ReadString(),
				ent  = net.ReadEntity(),
				elim = net.ReadBool(),
				hp   = net.ReadFloat(),
			}
		end
	end
	d.phaseEnd = CurTime() + (d.phase or 0)
	-- Suis-je un COMBATTANT de ce duel ? (pour le rappel [F9] ABANDONNER + le panneau)
	local lp = LocalPlayer()
	d.amFighter = false
	for _, tTeam in ipairs({ d.t1, d.t2 }) do
		for _, f in ipairs(tTeam) do if IsValid(f.ent) and f.ent == lp then d.amFighter = true end end
	end
	duel = d
	if d.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
