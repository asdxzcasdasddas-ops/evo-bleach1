-- "addons\\evo_fosse\\lua\\evo_fosse\\sh_config_fosse.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LA FOSSE — config partagée (client + serveur). (2026-07-17, v2 même jour :
-- menu dédié + arène = zone d'entraînement de la division, équipes, classement)
--
-- LE système signature de la DIVISION DE COMBAT (« Division 11 » / « Ordre 5 »,
-- index 6 — cf. lzy_faction/config.lua), miroir du rôle de la division de soin :
--   • la Division 4 GUÉRIT les blessures profondes (opération, ncm_heal_bed) ;
--   • la Division 11 les PRÉVIENT — pour le combat consenti et encadré.
--
-- Principe RP : un combat sauvage abîme le corps (chaque KO/mort = une « chute »
-- pour le debuff de soin). Sous l'arbitrage d'un membre de la division de combat,
-- dans SON arène, un duel n'entame PAS le corps : aucune chute comptée.
--
-- Boucle : un membre de la division ouvre le MENU DE LA FOSSE (bind F9,
-- lzy_bindmenu "fosse_menu") — uniquement PRÈS de l'arène. Il compose deux
-- équipes (1v1, 2v2 ou 3v3) parmi les joueurs présents, fixe une MISE
-- optionnelle (0 = amical). Tous les combattants CONSENTENT. Le combat se joue
-- DANS l'arène = la zone d'entraînement de la division (ncm_entrainement),
-- VERROUILLÉE pendant le duel : personne d'autre que les combattants ne peut y
-- entrer. Manche perdue quand toute une équipe est KO/éliminée (best-of-3).
-- À la fin : chaque perdant paie sa mise à son vis-à-vis vainqueur, MOINS la
-- part du trésor de la division (rake fixé serveur). Un CLASSEMENT (victoires/
-- défaites) est tenu en base partagée. Le capitaine et le vice-capitaine de la
-- division suivent le déroulement à distance (HUD).
-- Les porteurs du debuff de soin sont REFUSÉS (« pas en état de combattre ») :
-- la Fosse renvoie des clients à la Division 4 au lieu de la cannibaliser.
-- ============================================================================

EVO_FOSSE = EVO_FOSSE or {}

local C = {}
EVO_FOSSE.Config = C

-- ── Qui peut arbitrer ────────────────────────────────────────────────────────
C.DivisionName          = { Shinigami = "Division 11", Hollow = "Ordre 5" }
C.FallbackDivisionIndex = 6
C.MinGrade              = 1 -- grade minimum (FactionRank) pour arbitrer : tout membre

-- ── L'ARÈNE ──────────────────────────────────────────────────────────────────
-- Deux façons de la définir (ArenaBoxes PRIORITAIRE sur ArenaZoneName) :
--  1) ArenaBoxes[map]   = boîtes { mins, maxs } PROPRES à la Fosse (l'union fait
--     l'arène). N'ajoute RIEN à ncm_entrainement -> aucun effet no-KO permanent.
--  2) ArenaZoneName[map] = nom d'une zone de NCM_ENTRAINEMENT.Zones[map] (un nom
--     peut couvrir plusieurs boîtes, zones en L).
C.ArenaBoxes = {
	-- ORDRE DE COMBAT (Ordre 5) — emplacement donné par le user 07/17
	-- (setpos 5181.7 5049.4 6408.8 = le CENTRE ; sol haut de Las Noches).
	-- ⚠ C'est l'emprise de l'ANCIENNE « Zone Entrainement Divisions Combat »
	-- retirée de ncm_entrainement (elle rendait no-KO un bout de Zone Neutre II) :
	-- ici PAS de no-KO — la boîte ne sert qu'à la Fosse, et le verrou (éjection
	-- des non-combattants) n'est actif QUE pendant un duel.
	["hueco_mundo_v1"] = {
		{ mins = Vector(3682, 3549, 6060), maxs = Vector(6682, 6549, 8900) },
	},
}
C.ArenaZoneName = {
	["rp_seireitei_v1"] = "Zone Entrainement Division 11",
	["gm_construct"]    = "Zone Entrainement Test",
}
C.OpenMargin = 1500 -- distance MAX (u, 2D) au bord de l'arène pour ouvrir le menu
                    -- ET pour être désigné combattant (tout le monde est sur place)

-- ── Format des équipes ───────────────────────────────────────────────────────
C.MaxTeamSize = 3 -- 1v1, 2v2 ou 3v3 — équipes de MÊME taille

-- ── Le duel ──────────────────────────────────────────────────────────────────
C.Duel = {
	WinRounds     = 2,   -- premier à N manches (best-of-3)
	CountdownSec  = 4,   -- décompte avant chaque manche (combattants figés)
	RoundResetSec = 4,   -- pause entre 2 manches (soin + repositionnement)
	OutOfZoneSec  = 5,   -- temps hors-arène toléré avant ÉLIMINATION de la manche
	-- Limite GLOBALE du duel (s) : elle couvre TOUT, manches, décomptes et pauses
	-- comprises. Au bout, vainqueur au score (sinon nul). 300 s était trop court pour
	-- un best-of-3 (user 09/05 : « ça ne va jamais jusqu'au bout ») -> 600 s par défaut,
	-- et l'arbitre choisit dans TimeChoices au moment de lancer le défi.
	TimeLimit     = 600,
	TimeChoices   = { 300, 600, 900, 1200 }, -- 5 / 10 / 15 / 20 min proposées à l'arbitre
}

-- ── L'argent (mise OPTIONNELLE) ──────────────────────────────────────────────
C.Money = {
	MinStake = 0,      -- 0 = duel amical (sanctionné quand même : 0 chute)
	MaxStake = 100000, -- plafond de mise par tête (borné aussi par NCM_MINIGAME.MAX_BET)
	RakePct  = 0.10,   -- part de chaque mise perdante versée au TRÉSOR de la division
	                   -- de combat (EVO_DIVBANK). Fixée SERVEUR : l'arbitre ne peut
	                   -- pas la négocier -> pas de vecteur d'arnaque par l'arbitrage.
}

-- ── Garde-fous anti-abus ─────────────────────────────────────────────────────
C.ConsentSec      = 30   -- délai de réponse des combattants au défi
C.DailyCap        = 3    -- duels sanctionnés MAX par joueur et par jour : la Fosse
                         -- protège le combat ENCADRÉ seulement — guerre, embuscades
                         -- et PVE comptent toujours leurs chutes (la division de
                         -- soin garde son volume d'opérations).
C.PairCooldownSec = 1800 -- 30 min entre 2 duels du MÊME face-à-face (anti win-trading,
                         -- appliqué à toutes les paires adverses des deux équipes)

-- ============================================================================
-- ARÈNE — helpers partagés (client + serveur)
-- ============================================================================

local _boxes, _boxesMap
-- Boîtes { mins, maxs } de l'arène de la map courante (cache ; {} si aucune).
-- Priorité aux boîtes PROPRES à la Fosse, sinon zone d'entraînement par NOM.
function EVO_FOSSE.GetArenaBoxes()
	local sMap = game.GetMap()
	if _boxes and _boxesMap == sMap then return _boxes end
	_boxesMap = sMap
	_boxes = {}
	if istable(C.ArenaBoxes[sMap]) then
		for _, b in ipairs(C.ArenaBoxes[sMap]) do
			if b.mins and b.maxs then _boxes[#_boxes + 1] = { mins = b.mins, maxs = b.maxs } end
		end
		return _boxes
	end
	local sName = C.ArenaZoneName[sMap]
	local tZones = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[sMap]
	if sName and istable(tZones) then
		for _, z in ipairs(tZones) do
			if z.name == sName and z.mins and z.maxs then
				_boxes[#_boxes + 1] = { mins = z.mins, maxs = z.maxs }
			end
		end
	end
	return _boxes
end

function EVO_FOSSE.HasArena()
	return #EVO_FOSSE.GetArenaBoxes() > 0
end

-- Centre (x,y) + bbox englobante de l'union (nil si pas d'arène).
function EVO_FOSSE.GetArenaBounds()
	local tB = EVO_FOSSE.GetArenaBoxes()
	if #tB == 0 then return nil end
	local vMin, vMax = Vector(tB[1].mins), Vector(tB[1].maxs)
	for i = 2, #tB do
		vMin.x = math.min(vMin.x, tB[i].mins.x) vMin.y = math.min(vMin.y, tB[i].mins.y) vMin.z = math.min(vMin.z, tB[i].mins.z)
		vMax.x = math.max(vMax.x, tB[i].maxs.x) vMax.y = math.max(vMax.y, tB[i].maxs.y) vMax.z = math.max(vMax.z, tB[i].maxs.z)
	end
	return vMin, vMax, (vMin + vMax) * 0.5
end

function EVO_FOSSE.IsInArena(vPos)
	for _, b in ipairs(EVO_FOSSE.GetArenaBoxes()) do
		if vPos.x >= b.mins.x and vPos.x <= b.maxs.x
		and vPos.y >= b.mins.y and vPos.y <= b.maxs.y
		and vPos.z >= b.mins.z and vPos.z <= b.maxs.z then
			return true
		end
	end
	return false
end

-- Distance 2D au bord de l'arène (0 si dedans en x/y). Sert au gate « proche ».
function EVO_FOSSE.DistToArena(vPos)
	local nBest = math.huge
	for _, b in ipairs(EVO_FOSSE.GetArenaBoxes()) do
		local dx = math.max(b.mins.x - vPos.x, 0, vPos.x - b.maxs.x)
		local dy = math.max(b.mins.y - vPos.y, 0, vPos.y - b.maxs.y)
		nBest = math.min(nBest, math.sqrt(dx * dx + dy * dy))
	end
	return nBest
end

-- ============================================================================
-- PRÉDICATS PARTAGÉS (client + serveur)
-- ============================================================================

-- `ply` est-il MEMBRE de la division de combat ? (pattern EvoHealBed.IsHealDivision)
function EVO_FOSSE.IsCombatDivision(ply)
	if not IsValid(ply) then return false end

	-- 1) Par nom de division (robuste au ré-ordonnancement), nom PAR FACTION.
	local sReqName = C.DivisionName[ply:GetEvoNWString("FactionName", "")]
	if sReqName and LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions then
		local divs = LZY_FACTION_CONFIG.divisions[ply:GetEvoNWString("FactionName", "")]
		if divs then
			return divs[ply:GetEvoNWInt("FactionDivision", 0)] == sReqName
		end
	end

	-- 2) Fallback par index (config faction indisponible).
	return ply:GetEvoNWInt("FactionDivision", 0) == C.FallbackDivisionIndex
end

-- `ply` peut-il ARBITRER un duel de la Fosse ? Division de combat (grade mini),
-- ou SuperAdmin (animateurs/tests). Revalidé SERVEUR sur chaque action.
function EVO_FOSSE.CanArbiter(ply)
	if not IsValid(ply) then return false end
	if ply:IsSuperAdmin() then return true end
	if not EVO_FOSSE.IsCombatDivision(ply) then return false end
	return (ply:GetEvoNWInt("FactionRank", 0) or 0) >= C.MinGrade
end

-- Capitaine / vice-capitaine de la division de combat (les 2 grades du HAUT —
-- même convention que IsChief du casier : rank >= nombre de grades - 1).
-- Eux suivent le déroulement des duels de leur faction À DISTANCE (HUD).
function EVO_FOSSE.IsCombatStaff(ply)
	if not IsValid(ply) then return false end
	if not EVO_FOSSE.IsCombatDivision(ply) then return false end
	local t = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.factions
		and LZY_FACTION_CONFIG.factions[ply:GetEvoNWString("FactionName", "")]
	if not t then return false end
	return ply:GetEvoNWInt("FactionRank", 0) >= (#t - 1)
end

-- Live HUD sync throttle (fighting tick). Discrete events still sync immediately.
EVO_FOSSE.LIVE_SYNC_HEARTBEAT = 1.0

function EVO_FOSSE.NeedLiveSync(st, fingerprint)
	if not st then return false end
	local now = CurTime()
	local hb = EVO_FOSSE.LIVE_SYNC_HEARTBEAT or 1
	if st._liveFp ~= fingerprint then
		st._liveFp = fingerprint
		st._liveAt = now
		return true
	end
	if (now - (st._liveAt or 0)) >= hb then
		st._liveAt = now
		return true
	end
	return false
end

function EVO_FOSSE.MarkLiveSynced(st, fingerprint)
	if not st then return end
	if fingerprint ~= nil then st._liveFp = fingerprint end
	st._liveAt = CurTime()
end
