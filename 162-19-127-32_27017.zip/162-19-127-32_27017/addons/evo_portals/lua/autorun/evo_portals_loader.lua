-- "addons\\evo_portals\\lua\\autorun\\evo_portals_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS — chargeur unique. CENTRALISE Garganta + Senkaimon (même principe :
-- roue de sélection -> porte animée devant le joueur -> salle invisible -> décompte
-- global de 8s -> TP de tout le monde (local OU cross-serveur) -> fermeture).
--
-- Architecture (zéro duplication, un seul moteur écrit une fois) :
--   evo_portals/sh_evenement.lua : point d'arrivee d'evenement (case « ??? » des roues)
--   evo_portals/sh_anim.lua   — helpers d'anim + EVO_Portal.SlopeAlignedAngle (shared)
--   evo_portals/sv_engine.lua — EVO_Portal.RegisterServer (moteur serveur commun)
--   evo_portals/cl_engine.lua — EVO_Portal.RegisterClient (moteur client commun)
--   evo_portals/sv_def_*.lua  — config serveur de chaque portail (zones, anim, sons)
--   evo_portals/cl_def_*.lua  — config client de chaque portail (roue, salle, couleurs)
--   entities/evo_portal_base|_wall|_fx — entités de BASE ; les 6 classes
--     evo_garganta(_fx/_wall) / evo_senkaimon(_fx/_wall) n'en sont que des configs.
--
-- Contrat externe PRÉSERVÉ À L'IDENTIQUE (4 autres addons en dépendent) :
--   • globals EVO_Garganta / EVO_Senkaimon (+ .MODEL_Z / .MODEL_YAW)  -> evo_noclip_portal
--   • NW vars EvoGargantaInside / EvoSenkaiInside (+ *Until)          -> crossserver / orbit cam / pnj
--   • classes d'entité evo_garganta_fx / evo_senkaimon_fx            -> evo_noclip_portal
--   • binds "garganta" (KEY_O) / "senkaimon" (KEY_N)                 -> lzy_bindmenu
-- ============================================================================
if SERVER then
	AddCSLuaFile("evo_portals/sh_anim.lua")
	AddCSLuaFile("evo_portals/sh_evenement.lua")
	AddCSLuaFile("evo_portals/cl_engine.lua")
	AddCSLuaFile("evo_portals/cl_def_garganta.lua")
	AddCSLuaFile("evo_portals/cl_def_senkaimon.lua")

	include("evo_portals/sh_anim.lua")
	include("evo_portals/sh_evenement.lua")
	include("evo_portals/sv_engine.lua")
	include("evo_portals/sv_def_garganta.lua")
	include("evo_portals/sv_def_senkaimon.lua")
else
	include("evo_portals/sh_anim.lua")
	include("evo_portals/sh_evenement.lua")
	include("evo_portals/cl_engine.lua")
	include("evo_portals/cl_def_garganta.lua")
	include("evo_portals/cl_def_senkaimon.lua")
end
