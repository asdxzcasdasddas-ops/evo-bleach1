-- "addons\\evo_portals\\lua\\evo_portals\\cl_def_senkaimon.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS — config CLIENT du SENKAIMON (roue + salle BLANCHE + ambiance).
--   Toute la mécanique (bind, roue, invisibilité, rendu salle) est dans
--   evo_portals/cl_engine.lua ; ce fichier n'est QUE la config visuelle.
-- ============================================================================
if SERVER then return end

-- Salle BLANCHE : murs rendus en blanc opaque, visibles SEULEMENT de l'intérieur.
local ROOMMAT = CreateMaterial("evo_senkai_room_white", "UnlitGeneric", {
	["$basetexture"] = "color/white",
	["$model"]       = "1",
	["$nocull"]      = "1",  -- visible des deux côtés (donc depuis l'intérieur)
})

EVO_Portal.RegisterClient({
	ID            = "senkaimon",
	NET_OPEN      = "EVO:Senkaimon:Open",
	BIND_NAME     = "senkaimon",
	FACTIONS      = { ["Shinigami"] = true },
	MIN_RANK      = 10,
	NW_INSIDE     = "EvoSenkaiInside",
	-- Doit correspondre a ENT.NWUntil (entities/evo_senkaimon/shared.lua) : instant du TP.
	-- Sans elle le masquage "dans la salle" ne peut plus expirer, cf. insideBy (cl_engine).
	NW_UNTIL      = "EvoSenkaiUntil",
	WALL_CLASS    = "evo_senkaimon_wall",

	ZONES_BY_MAP = {
		["rp_seireitei_v1"]   = { "Seireitei", "Zone Neutre I", "Zone Neutre II", "Hueco Mundo", "Zone neutre Monde des vivants" },
		["hueco_mundo_v1"]    = { "Soul Society" },   -- Shinigami étranger : seulement rentrer
		["rp_shinonome_evo"]   = { "Soul Society", "Hueco Mundo" }, -- zone neutre : sortir seulement
	},

	-- Index des zones CROSS-SERVEUR (par map, MEME ORDRE que ZONES_BY_MAP). Le client
	-- choisit ainsi le bon cooldown : local (in-map) et cross-serveur sont 2 CD SEPARES.
	CROSS_ZONES_BY_MAP = {
		["rp_seireitei_v1"] = { [4] = true, [5] = true },  -- "Hueco Mundo", zone neutre
		["hueco_mundo_v1"]  = { [1] = true },  -- "Soul Society"
		["rp_shinonome_evo"] = { [1] = true, [2] = true },  -- tout est cross depuis la zone neutre
	},

	-- Roue
	TITLE      = "SENKAIMON",
	-- Image affichée au CENTRE de la roue (nom au-dessus, léger mouvement au survol).
	IMAGE      = "etgmnxxbvsadh9/etgmnxxbvsadh9/senkaimon.png",
	ACCENT     = Color(150, 200, 255),
	SEL_BOX    = Color(70, 120, 200, 245),
	UNSEL_BOX  = Color(22, 24, 30, 235),
	TEXT_SEL   = Color(255, 255, 255),
	TEXT_UNSEL = Color(200, 205, 215),
	HINT       = "Relâche sur une zone pour ouvrir le Senkaimon",
	MSG_NOMAP  = "Aucune destination Senkaimon configurée sur cette map.",

	-- Salle + ambiance
	ROOM_MAT      = ROOMMAT,
	ROOM_COLOR    = Color(247, 248, 252, 255),
	ROOM_NWPREFIX = "evosenkai",
	VEIL_COLOR    = Color(255, 255, 255, 120),
	BLUR_AMOUNT   = 4,
	BLUR_PASSES   = 4,
})
