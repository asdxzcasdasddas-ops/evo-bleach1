-- "addons\\evo_portals\\lua\\evo_portals\\cl_engine.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS — moteur CLIENT commun (Garganta + Senkaimon).
--   EVO_Portal.RegisterClient(def) installe, pour un portail :
--     • le bind (maintenir -> roue, relâcher -> valide la zone visée),
--     • la roue de sélection de zone,
--     • l'invisibilité des joueurs DANS la salle pour ceux dehors + 1ère personne,
--     • le rendu de la salle (boîte colorée visible SEULEMENT de l'intérieur),
--     • le voile + blur d'ambiance quand on est dedans.
--   Tout est paramétré par `def` : les deux portails ne sont QUE des configs.
-- ============================================================================
if SERVER then return end

EVO_Portal = EVO_Portal or {}

function EVO_Portal.RequestCancelWait()
	net.Start("EVO:Cross:CancelWait")
	net.SendToServer()
end

-- ── Isolation visuelle de la salle (helper partagé) ─────────────────────────
-- Clés NWBool "dans la salle" de chaque portail enregistré (EvoGargantaInside /
-- EvoSenkaiInside). Renseignées par RegisterClient. Deux joueurs sont "separes"
-- si, pour AU MOINS une de ces clés, l'un est dans la salle et l'autre non : ils
-- ne doivent alors RIEN voir l'un de l'autre.
--   Le CORPS est déjà géré ailleurs (PrePlayerDraw cache l'occupant pour ceux du
--   dehors ; la boîte opaque cache le monde pour l'occupant). MAIS les accessoires
--   bonemergés (passe translucide) et les nametags (cam.IgnoreZ) TRANSPERCENT la
--   salle "invisible" -> ce helper sert à les masquer aussi (cl_models + lzy_meet).
-- { { inside = "EvoSenkaiInside", deadline = "EvoSenkaiUntil" }, ... }
EVO_Portal._insideNWKeys = EVO_Portal._insideNWKeys or {}

-- « Dans la salle » = le booleen EST vrai ET l'heure du TP n'est PAS passee.
--
-- Le booleen seul ne suffit pas, et c'est la cause du bug « joueur invisible pour
-- CERTAINS seulement » : le serveur repasse la cle a false dans le MEME tick que le
-- SetPos du teleport (evo_portal_base/init.lua, TeleportInside). Ce delta NW2 ne part
-- qu'aux clients qui ont encore le joueur dans leur PVS -- or il vient justement d'etre
-- deplace a l'autre bout de la map. Les clients qui le perdent a cet instant gardent
-- « inside = true » pour toujours, et ce joueur leur devient TOTALEMENT absent : corps
-- masque par PrePlayerDraw, plus accessoires / nametag / katana / ciblage via
-- PlayersSeparated. Rien ne les en sort (un refresh d'apparence ne touche pas cet etat).
--
-- La deadline (NWFloat pose par le serveur a chaque SetInside, = l'instant du TP) rend
-- l'etat AUTO-EXPIRANT : une fois cette heure passee, plus personne n'est masque, que le
-- delta soit arrive ou non. Un def sans NW_UNTIL ne masque plus rien du tout : on echoue
-- VISIBLE, jamais invisible.
--
-- INSIDE_GRACE couvre le retard du Think serveur : le TP part au premier Think >= _tpAt,
-- soit jusqu'a 0.15s APRES la deadline. Sans marge, l'occupant redeviendrait visible (et
-- perdrait sa salle) pendant ce court instant, a CHAQUE voyage. La marge supprime ce
-- clignotement sans rien changer a l'auto-expiration, qui reste quasi immediate.
local INSIDE_GRACE = 0.5

local function insideBy(ply, sInside, sUntil)
	if not sUntil or not IsValid(ply) then return false end
	if not ply:GetEvoNWBool(sInside, false) then return false end
	return ply:GetEvoNWFloat(sUntil, 0) + INSIDE_GRACE > CurTime()
end

function EVO_Portal.PlayersSeparated(a, b)
	if not IsValid(a) or not IsValid(b) or a == b then return false end
	-- Staff / spectate : l'observateur doit voir les occupants (follow-TP le
	-- colle sur la cible sans le marquer "inside").
	if EVO_Portal.IgnoresPortals(a) or EVO_Portal.IgnoresPortals(b) then return false end
	local keys = EVO_Portal._insideNWKeys
	for i = 1, #keys do
		local k = keys[i]
		if insideBy(a, k.inside, k.deadline) ~= insideBy(b, k.inside, k.deadline) then
			return true
		end
	end
	return false
end

-- Polices partagées par les deux roues (tailles identiques d'origine).
surface.CreateFont("EVO_PortalWheel",      { font = "Tahoma", size = 19, weight = 600, antialias = true })
surface.CreateFont("EVO_PortalWheelBig",   { font = "Tahoma", size = 25, weight = 700, antialias = true })
surface.CreateFont("EVO_PortalWheelTitle", { font = "Tahoma", size = 34, weight = 800, antialias = true })

-- Couleurs partagées des roues, HOISTÉES (créées une seule fois : zéro allocation
-- de Color par frame pendant que la roue est ouverte — perf).
local COL_W_SUBON  = Color(255, 255, 255)
local COL_W_SUBOFF = Color(160, 165, 180)
local COL_W_CD     = Color(235, 120, 120)
local COL_W_HINT   = Color(180, 182, 198, 220)
local COL_W_DEMO   = Color(150, 150, 160, 200)

local BLUR = Material("pp/blurscreen")
local function drawBlur(amount, passes)
	if not BLUR then return end
	passes = passes or 4
	surface.SetMaterial(BLUR)
	surface.SetDrawColor(255, 255, 255, 255)
	for i = 1, passes do
		BLUR:SetFloat("$blur", (i / passes) * (amount or 4))
		BLUR:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	end
end

-- Compte à rebours lisible pour la recharge affichée dans la roue ("Xm YYs" / "Ys").
local function fmtCooldown(s)
	s = math.max(0, math.ceil(s))
	if s >= 60 then return string.format("%dm%02ds", math.floor(s / 60), s % 60) end
	return s .. "s"
end

-- def : table de config CLIENT du portail. Champs :
--   ID, NET_OPEN, BIND_NAME, FACTIONS, MIN_RANK, ZONES_BY_MAP, NW_INSIDE,
--   TITLE, ACCENT, SEL_BOX, UNSEL_BOX, TEXT_SEL, TEXT_UNSEL, HINT, MSG_NOMAP,
--   ROOM_MAT, ROOM_COLOR, ROOM_NWPREFIX, VEIL_COLOR, BLUR_AMOUNT, BLUR_PASSES.
function EVO_Portal.RegisterClient(def)
	local ZONES = def.ZONES_BY_MAP[game.GetMap()] or {}
	local ID    = def.ID
	-- Map non configurée (ex: gm_construct) : roue de DÉMO (demande user) — on affiche
	-- TOUTES les directions du portail (sa plus grande config : Seireitei pour le
	-- Senkaimon, Hueco Mundo pour la Garganta). La validation n'ouvre RIEN (aucun net) :
	-- elle rappelle juste qu'aucune destination n'existe sur cette map.
	local bDemoZones = false
	if #ZONES == 0 then
		bDemoZones = true
		for _, tList in pairs(def.ZONES_BY_MAP) do
			if #tList > #ZONES then ZONES = tList end
		end
	end
	-- Point d'arrivee d'evenement (sh_evenement.lua) : la roue = les zones de la map, plus
	-- une case « ??? » quand un animateur l'a ouverte a ce portail. Recalculee a chaque
	-- ouverture. Sur une map sans destination, la case seule remplace la roue de demo :
	-- un event sur une map a part reste joignable.
	local BASE, BASE_DEMO, iEvent = ZONES, bDemoZones, 0
	local function zonesDeLaRoue()
		ZONES, bDemoZones, iEvent = BASE, BASE_DEMO, 0
		if not (EVO_Portal.EvenementActif and EVO_Portal.EvenementActif(ID)) then return end
		ZONES = {}
		if not BASE_DEMO then for i, nom in ipairs(BASE) do ZONES[i] = nom end end
		ZONES[#ZONES + 1] = EVO_Portal.EVENT_NOM
		bDemoZones, iEvent = false, #ZONES
	end
	-- Visuel central de la roue : IMAGE du portail (def.IMAGE, .png monté côté client)
	-- affichée au centre avec le NOM au-dessus ; elle "bouge un peu" au survol de la
	-- souris (léger zoom + flottement, lissés). Fallback : titre texte seul (disposition
	-- d'origine) si aucun IMAGE n'est défini ou si le fichier est introuvable (IsError).
	local IMG = def.IMAGE and Material(def.IMAGE, "smooth") or nil
	if IMG and IMG:IsError() then IMG = nil end
	local imgHoverFrac = 0

	-- Rendu de la roue 100% Lua (AUCUN DHTML : un Chromium coûtait cher à créer et à
	-- composer, et le blur par frame copiait le framebuffer en boucle — retours user
	-- "trop bouffeur"). Une poignée de rects arrondis + textes par frame = négligeable.
	-- tSelFrac = fraction de sélection LISSÉE par carte (simple lerp) ; ACCENT_BAR =
	-- couleur du liseré de sélection, MUTÉE par frame (jamais recréée — zéro alloc).
	local tSelFrac   = {}
	local ACCENT_BAR = Color(def.ACCENT.r, def.ACCENT.g, def.ACCENT.b, 255)

	-- Enregistre la clé "dans la salle" pour EVO_Portal.PlayersSeparated (masquage
	-- accessoires + nametags qui transpercent la salle). Dédup au cas où.
	if def.NW_INSIDE then
		local bKnown = false
		for _, k in ipairs(EVO_Portal._insideNWKeys) do
			if k.inside == def.NW_INSIDE then bKnown = true break end
		end
		if not bKnown then
			EVO_Portal._insideNWKeys[#EVO_Portal._insideNWKeys + 1] =
				{ inside = def.NW_INSIDE, deadline = def.NW_UNTIL }
		end
	end
	-- Doit correspondre au NWFloat posé par sv_engine (instant de ré-ouverture possible).
	local NW_CD = "EVO_PortalCD_" .. ID
	-- Zones CROSS-SERVEUR de cette map (par index). Local (in-map) et cross ont des CD SEPARES
	-- cote serveur -> on lit le NWFloat correspondant a la zone visee (demande user).
	local CROSS = (def.CROSS_ZONES_BY_MAP and def.CROSS_ZONES_BY_MAP[game.GetMap()]) or {}
	local function cdNWForZone(idx)
		if iEvent > 0 and idx == iEvent then return NW_CD .. "_event" end
		return CROSS[idx] and (NW_CD .. "_cross") or NW_CD
	end

	-- ── État de la roue ──────────────────────────────────────────────────────
	local wheelOpen, selZone, wheelOpenedAt = false, 0, 0

	local function openWheel()
		if wheelOpen then return end
		wheelOpen, selZone, wheelOpenedAt = true, 0, CurTime()
		zonesDeLaRoue()
		-- Reset des fractions de sélection lissées (cartes de zones).
		for i = 1, #ZONES do tSelFrac[i] = 0 end
		gui.EnableScreenClicker(true)
	end
	local function closeWheel()
		if not wheelOpen then return end
		wheelOpen = false
		gui.EnableScreenClicker(false)
	end
	local function confirmWheel()
		local z = selZone
		closeWheel()
		-- Roue de DÉMO (map non configurée) : quelle que soit la zone visée, on n'ouvre
		-- RIEN — simple rappel que cette map n'a pas de destination.
		if bDemoZones then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify(def.MSG_NOMAP, NOTIFY_ERROR, 4)
			end
			return
		end
		if z < 1 then return end
		-- Recharge encore active : inutile de tenter (le serveur refuserait) — on
		-- prévient le joueur du temps restant au lieu d'ouvrir.
		local rem = LocalPlayer():GetEvoNWFloat(cdNWForZone(z), 0) - CurTime()
		if rem > 0 then
			if MUGEN and MUGEN.Notify then
				MUGEN.Notify(def.TITLE .. " en recharge : encore " .. fmtCooldown(rem) .. ".", NOTIFY_ERROR, 4)
			end
			return
		end
		net.Start(def.NET_OPEN)
		-- La case « ??? » part sous son index fixe, pas sous sa place dans la roue.
		net.WriteUInt((iEvent > 0 and z == iEvent) and EVO_Portal.EVENT_IDX or z, 4)
		net.SendToServer()
	end

	-- ── Bind : maintenir -> roue, relâcher -> valide la zone visée ───────────
	local cachedKey, nextRefresh, wasDown = nil, 0, false

	hook.Add("Think", "EVO_Portal:Bind:" .. ID, function()
		local lp = LocalPlayer()
		if not IsValid(lp) then if wheelOpen then closeWheel() end return end

		-- failsafe : ne jamais laisser la roue (et donc le curseur) bloquée trop longtemps
		if wheelOpen and (CurTime() - wheelOpenedAt) > 15 then closeWheel() wasDown = false return end

		local now = CurTime()
		if now >= nextRefresh then
			cachedKey   = (lp.GetBindKey and lp:GetBindKey(def.BIND_NAME)) or nil
			nextRefresh = now + 2
		end

		local blocked = (not cachedKey) or (not isnumber(cachedKey))
			or gui.IsGameUIVisible()
			or (vgui.GetKeyboardFocus and IsValid(vgui.GetKeyboardFocus()))
			or (not lp:Alive())
			or EVO_Portal.IgnoresPortals(lp)
		if blocked then
			if wheelOpen then closeWheel() end
			wasDown = false
			return
		end

		local down = input.IsKeyDown(cachedKey)
		if down and not wasDown then
			-- En file d'attente cross-serveur (destination pleine) : la touche ANNULE l'attente.
			if lp:GetEvoNWBool("EVO_CrossWaiting", false) then
				EVO_Portal.RequestCancelWait()  -- netgate: edge -- bind key rising edge (wasDown)
				wasDown = down
				return
			end
			-- gate client : roue seulement pour la bonne faction AYANT le portail débloqué
			-- (EVO_PortalUnlocked, auto au grade 3 ; le serveur revalide).
			-- La roue s'ouvre MÊME sans destination configurée sur la map (ex: gm_construct,
			-- demande user) : elle affiche alors "Aucune destination" et ne mène nulle part.
			if def.FACTIONS[lp:GetEvoNWString("FactionName", "")] then
				if lp:GetEvoNWBool("EVO_PortalUnlocked", false) then
					openWheel()
				elseif (lp._portalLockNotif or 0) < CurTime() then
					-- Bonne faction mais pas encore débloqué (grade < 3) : dire POURQUOI au lieu
					-- d'une touche MUETTE (07/22 : l'ancien silence = ressenti « on ne peut plus ouvrir »).
					lp._portalLockNotif = CurTime() + 4
					notification.AddLegacy("Ouverture de portail : débloquée au grade 3.", NOTIFY_ERROR, 4)
					surface.PlaySound("buttons/button10.wav")
				end
			end
		elseif (not down) and wasDown then
			if wheelOpen then confirmWheel() end  -- netgate: edge -- wheel key release edge, closes the wheel
		end
		wasDown = down
	end)

	-- ── Sélection (souris) ───────────────────────────────────────────────────
	local function updateSel()
		local cx, cy = ScrW() * 0.5, ScrH() * 0.5
		local mx, my = gui.MousePos()
		local dx, dy = mx - cx, my - cy
		if (dx * dx + dy * dy) < (70 * 70) then selZone = 0 return end
		local ang, n = math.deg(math.atan2(dy, dx)), #ZONES
		local best, bd = 0, 9999
		for i = 1, n do
			local ia = -90 + (i - 1) * (360 / n)
			local d  = math.abs(math.AngleDifference(ang, ia))
			if d < bd then bd, best = d, i end
		end
		selZone = best
	end

	-- Roue rendue 100% en Lua : une poignée de rects/textes par frame, couleurs
	-- hoistées, lerps locaux — coût négligeable (l'habillage DHTML et le blur par
	-- frame, trop coûteux, ont été retirés — retours user "trop bouffeur").
	hook.Add("HUDPaint", "EVO_Portal:Wheel:" .. ID, function()
		if not wheelOpen then return end
		updateSel()

		local cx, cy = ScrW() * 0.5, ScrH() * 0.5
		local n = #ZONES
		-- Recharge de la zone VISEE (cross-serveur et local ont des CD distincts).
		local nRem = (selZone >= 1) and (LocalPlayer():GetEvoNWFloat(cdNWForZone(selZone), 0) - CurTime()) or 0

		-- Fond : assombrissement seul (gratuit) — jamais de blur par frame.
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, 0, ScrW(), ScrH())

		-- Entrée de roue : fondu + léger déploiement du rayon (pur math, aucune alloc).
		local k = math.Clamp((CurTime() - wheelOpenedAt) * 6, 0, 1)
		k = 1 - (1 - k) * (1 - k) -- ease-out
		local R = math.min(ScrW(), ScrH()) * 0.20 * (0.92 + 0.08 * k)
		surface.SetAlphaMultiplier(k)

		-- ── Centre : NOM au-dessus + IMAGE (zoom + flottement AU SURVOL uniquement) ──
		local subY, cdY -- Y de la ligne "➜ zone" et de la ligne recharge (selon layout)
		if IMG then
			local S = math.floor(math.min(ScrW(), ScrH()) * 0.12)
			local mx, my = gui.MousePos()
			local bHover = math.abs(mx - cx) <= S * 0.5 and math.abs(my - cy) <= S * 0.5
			imgHoverFrac = Lerp(math.Clamp(FrameTime() * 10, 0, 1), imgHoverFrac, bHover and 1 or 0)
			local drawS = S * (1 + 0.08 * imgHoverFrac)
			-- Flottement PERMANENT (l'image "vit" toute seule — demande user) : ±6px de
			-- base, ±8px au survol. Pur math (un sin par frame) : coût nul.
			local bobY  = math.sin(RealTime() * 1.8) * (6 + 2 * imgHoverFrac)
			surface.SetMaterial(IMG)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawTexturedRect(cx - drawS * 0.5, cy - drawS * 0.5 + bobY, drawS, drawS)
			draw.SimpleText(def.TITLE, "EVO_PortalWheelTitle", cx, cy - S * 0.5 - 28,
				def.ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			-- Fine barre accent sous le titre (DA).
			surface.SetDrawColor(def.ACCENT)
			surface.DrawRect(cx - 32, cy - S * 0.5 - 12, 64, 3)
			subY, cdY = cy + S * 0.5 + 16, cy + S * 0.5 + 44
		else
			-- Sans image : titre texte seul.
			draw.SimpleText(def.TITLE, "EVO_PortalWheelTitle", cx, cy - 16, def.ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			subY, cdY = cy + 14, cy + 42
		end

		draw.SimpleText(selZone >= 1 and ("➜ " .. ZONES[selZone]) or "Vise une zone…", "EVO_PortalWheel", cx, subY,
			selZone >= 1 and COL_W_SUBON or COL_W_SUBOFF, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		-- Roue de DÉMO (map sans destination) : petite mention sous le sous-titre.
		if bDemoZones then
			draw.SimpleText("Aucune destination sur cette map", "EVO_PortalWheel", cx, subY + 22,
				COL_W_DEMO, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cdY = cdY + 22
		end

		-- Recharge en cours : affichée au CENTRE de la roue (sous le sous-titre).
		if nRem > 0 then
			draw.SimpleText("Recharge : " .. fmtCooldown(nRem), "EVO_PortalWheelBig", cx, cdY,
				COL_W_CD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		-- ── Cartes de zones : arrondis RNDX si dispo, liseré accent + léger zoom
		-- LISSÉ sur la sélection (tSelFrac : un lerp par carte, zéro alloc par frame).
		local dt = math.Clamp(FrameTime() * 12, 0, 1)
		local bRndx = RNDX and RNDX.Draw and true or false
		for i = 1, n do
			local ia = math.rad(-90 + (i - 1) * (360 / n))
			local ix, iy = cx + math.cos(ia) * R, cy + math.sin(ia) * R
			local sel = (i == selZone)
			tSelFrac[i] = Lerp(dt, tSelFrac[i] or 0, sel and 1 or 0)
			local f = tSelFrac[i]
			local w, h = 186 * (1 + 0.06 * f), 50 * (1 + 0.06 * f)
			local x0, y0 = ix - w * 0.5, iy - h * 0.5
			if bRndx then
				RNDX.Draw(12, x0, y0, w, h, sel and def.SEL_BOX or def.UNSEL_BOX)
			else
				draw.RoundedBox(10, x0, y0, w, h, sel and def.SEL_BOX or def.UNSEL_BOX)
			end
			if f > 0.02 then
				-- Liseré accent gauche (marque DA de la sélection), fondu par f.
				ACCENT_BAR.a = 255 * f
				surface.SetDrawColor(ACCENT_BAR)
				surface.DrawRect(x0, y0, 4, h)
			end
			draw.SimpleText(ZONES[i], "EVO_PortalWheelBig", ix, iy, sel and def.TEXT_SEL or def.TEXT_UNSEL,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		draw.SimpleText(nRem > 0 and "Tu ne peux pas rouvrir tout de suite." or def.HINT, "EVO_PortalWheel",
			cx, cy + R + 58, COL_W_HINT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		surface.SetAlphaMultiplier(1)
	end)

	-- ── Joueurs DANS la salle = invisibles pour ceux DEHORS (perf : simple check) ──
	hook.Add("PrePlayerDraw", "EVO_Portal:HideInside:" .. ID, function(ply)
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		if ply ~= lp and insideBy(ply, def.NW_INSIDE, def.NW_UNTIL)
			and not insideBy(lp, def.NW_INSIDE, def.NW_UNTIL) then
			if EVO_Portal.IgnoresPortals(lp) then return end
			return true
		end
	end)

	-- ── Force la 1ère personne quand on est dans la salle (sinon la 3e pers traverse) ──
	hook.Add("CalcView", "EVO_Portal:FirstPerson:" .. ID, function(ply, pos, angles, fov)
		if EVO_Portal.IgnoresPortals(ply) then return end
		if insideBy(ply, def.NW_INSIDE, def.NW_UNTIL) then
			return { origin = ply:EyePos(), angles = angles, fov = fov, drawviewer = false }
		end
	end)
	hook.Add("ShouldDrawLocalPlayer", "EVO_Portal:FirstPerson:" .. ID, function(ply)
		if EVO_Portal.IgnoresPortals(ply) then return end
		if insideBy(ply, def.NW_INSIDE, def.NW_UNTIL) then return false end
	end)

	-- ── Salle : boîte colorée, visible SEULEMENT de l'intérieur ──────────────
	local function inWall(w, lp)
		local l  = w:WorldToLocal(lp:WorldSpaceCenter())
		local d  = w:GetEvoNWInt(def.ROOM_NWPREFIX .. "_d", 340)
		local hw = w:GetEvoNWInt(def.ROOM_NWPREFIX .. "_hw", 95)
		local h  = w:GetEvoNWInt(def.ROOM_NWPREFIX .. "_h", 115)
		if l.x >= -24 and l.x <= d + 24 and math.abs(l.y) <= hw + 24 and l.z >= -36 and l.z <= h + 24 then
			return d, hw, h
		end
	end

	-- Cache du mur trouvé : la salle est statique pendant ~8s, inutile de refaire un
	-- FindByClass à CHAQUE frame — on garde le mur tant qu'il est valide et nous contient,
	-- sinon rescan au plus 4×/s.
	local roomW, roomNext = nil, 0
	local function findRoom(lp)
		if IsValid(roomW) then
			local d, hw, h = inWall(roomW, lp)
			if d then return roomW, d, hw, h end
		end
		if CurTime() < roomNext then return end
		roomNext = CurTime() + 0.25
		roomW = nil
		for _, w in ipairs(ents.FindByClass(def.WALL_CLASS)) do
			if IsValid(w) then
				local d, hw, h = inWall(w, lp)
				if d then
					roomW = w
					return w, d, hw, h
				end
			end
		end
	end

	-- Pass OPAQUE : écrit la profondeur -> on ne voit PLUS à travers la salle.
	hook.Add("PostDrawOpaqueRenderables", "EVO_Portal:Room:" .. ID, function(_, bSkybox)
		if bSkybox then return end
		local lp = LocalPlayer()
		if EVO_Portal.IgnoresPortals(lp) then return end
		if not insideBy(lp, def.NW_INSIDE, def.NW_UNTIL) then return end
		local w, d, hw, h = findRoom(lp)
		if not IsValid(w) then return end
		render.SetMaterial(def.ROOM_MAT)
		render.DrawBox(w:GetPos(), w:GetAngles(),
			Vector(-12, -hw - 12, -12), Vector(d + 12, hw + 12, h + 12),
			def.ROOM_COLOR)
	end)

	-- ── Voile + léger blur par-dessus (ambiance) ─────────────────────────────
	hook.Add("HUDPaint", "EVO_Portal:Inside:" .. ID, function()
		local lp = LocalPlayer()
		if EVO_Portal.IgnoresPortals(lp) then return end
		if not insideBy(lp, def.NW_INSIDE, def.NW_UNTIL) then return end
		drawBlur(def.BLUR_AMOUNT or 4, def.BLUR_PASSES or 4)
		surface.SetDrawColor(def.VEIL_COLOR)
		surface.DrawRect(0, 0, ScrW(), ScrH())
	end)
end
