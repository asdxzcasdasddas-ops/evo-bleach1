-- "addons\\evo_portals\\lua\\evo_portals\\sh_anim.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS — helpers d'animation PARTAGÉS (Garganta + Senkaimon).
--   Centralise la logique commune des deux portails. Voir evo_portals_loader.lua
--   pour l'ordre de chargement et l'architecture globale.
-- ============================================================================
EVO_Portal      = EVO_Portal or {}
EVO_Portal.Anim = EVO_Portal.Anim or {}

-- Staff / observateur : ne doit NI ouvrir NI emprunter un portail.
-- Le spectate staff (dashboard / SAM / animateur) follow-TP l'observateur SUR
-- la cible toutes les 0.15 s. Sans ce gate, entrer dans un Senkaimon/Garganta
-- emportait le staff avec la cible (salle + voile + TP) alors qu'il n'avait
-- rien demandé.
function EVO_Portal.IgnoresPortals(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return true end
	if ply:GetEvoNWBool("EVO_StaffMode", false) then return true end
	local t = ply.GetEvoNWEntity and ply:GetEvoNWEntity("EVO_SpecTarget")
	return IsValid(t)
end

-- Animation par SCALE (reprise du Garganta de ncm_pnj) : keyframes {t01, scale}
-- interpolées par le moteur (SetModelScale est networké tout seul). baseDelay
-- décale le départ de toute la courbe. totalT = durée de la courbe complète.
function EVO_Portal.Anim.RunScaleCurve(ent, curve, totalT, baseDelay)
	if not curve then return end
	baseDelay = baseDelay or 0
	for i = 2, #curve do
		local segStart = baseDelay + curve[i - 1][1] * totalT
		local segDur   = math.max(0.01, (curve[i][1] - curve[i - 1][1]) * totalT)
		local target   = curve[i][2]
		timer.Simple(segStart, function()
			if IsValid(ent) then ent:SetModelScale(target, segDur) end
		end)
	end
end

-- Joue une séquence nommée du modèle (porte animée). Renvoie sa durée (0 si
-- introuvable).
function EVO_Portal.Anim.PlaySeq(ent, name)
	local seq = ent:LookupSequence(name)
	if seq and seq >= 0 then
		ent:ResetSequence(seq)
		ent:SetCycle(0)
		ent:SetPlaybackRate(1)
		return ent:SequenceDuration(seq) or 1
	end
	return 0
end

-- GARGANTA (09/28, user) : les séquences du modèle NE s'enchaînent PAS seules. open (1,8 s)
-- -> idle (boucle, relancée tant qu'on ne ferme pas) ; close (1,4 s) -> closed (invisible).
-- Durées de repli si le modèle ne connaît pas la séquence.
local GARG_OPEN_FALLBACK, GARG_CLOSE_FALLBACK = 1.8, 1.4

local function GargSeq(ent, name, nFallback)
	local d = EVO_Portal.Anim.PlaySeq(ent, name)
	return (d and d > 0) and d or nFallback
end

local function GargIdle(ent)
	if not IsValid(ent) or ent._gargClosing then return end
	local d = GargSeq(ent, "garganta_idle", 1)
	timer.Simple(math.max(d, 0.2), function() GargIdle(ent) end)
end

-- Ouverture puis maintien ouvert. Renvoie la durée de l'ouverture.
function EVO_Portal.Anim.GargantaOpen(ent)
	ent:SetModelScale(1, 0)
	local d = GargSeq(ent, "garganta_open", GARG_OPEN_FALLBACK)
	timer.Simple(d, function() GargIdle(ent) end)
	return d
end

-- Fermeture puis état fermé (invisible). Renvoie la durée de la fermeture.
function EVO_Portal.Anim.GargantaClose(ent)
	ent._gargClosing = true
	local d = GargSeq(ent, "garganta_close", GARG_CLOSE_FALLBACK)
	timer.Simple(d, function()
		if IsValid(ent) then EVO_Portal.Anim.PlaySeq(ent, "garganta_closed") end
	end)
	return d
end

-- Angle visuel du portail : face au joueur (faceYaw) MAIS incliné pour ÉPOUSER la
-- pente du sol (normale du trace de spawn). Sol plat, pente trop raide (~> 60°) ou
-- pas de sol -> yaw seul (vertical). Le "haut" du modèle suit la normale, le facing
-- reste vers le joueur. Utilisé À LA FOIS pour le visuel ET le repère de SALLE
-- (RoomAng) -> murs / détection / éjection s'inclinent AUSSI avec la pente.
function EVO_Portal.SlopeAlignedAngle(faceYaw, trace)
	local flat = Angle(0, faceYaw, 0)
	if not (trace and trace.Hit) then return flat end
	local n = trace.HitNormal
	if not n or n.z <= 0.5 then return flat end -- pente trop raide / mur -> vertical
	local f = flat:Forward()
	f = f - n * f:Dot(n)                         -- projette le facing dans le plan de la pente
	if f:LengthSqr() < 0.0001 then return flat end
	f:Normalize()
	return f:AngleEx(n)                          -- forward = facing, up = normale du sol
end
