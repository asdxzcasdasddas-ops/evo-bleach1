-- "addons\\evo_portals\\lua\\evo_portals\\sh_evenement.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS : POINT D'ARRIVEE D'EVENEMENT (30/09/2026, demande des animateurs
-- relayee par axxou).
--   Un animateur pose un point la ou il se tient (panneau animateur, onglet
--   GENERAL) et coche les portails qui y menent : Garganta, Senkaimon ou les deux.
--   Les joueurs qui ouvrent ce portail voient alors une case « ??? » de plus dans
--   leur roue et arrivent au point, avec ceux qui passent la porte en meme temps,
--   comme pour une zone de la config.
--   Un seul point par serveur, en memoire : il disparait quand un animateur le
--   retire, quand celui qui l'a pose se deconnecte, ou au redemarrage.
--   Les gardes du portail restent les memes (faction, deblocage au grade 3, pas en
--   instance ni en mode staff). La recharge vers le point est courte et a part :
--   rejoindre un event ne bloque pas les destinations habituelles pendant 30 min.
-- ============================================================================
EVO_Portal = EVO_Portal or {}

-- La roue envoie l'index de la zone sur 4 bits (1 a 15) : le point prend 15, qu'une
-- config n'atteint pas (6 zones au plus). Un index fixe et pas « derniere zone + 1 » :
-- en dev, le serveur retire des zones que le client affiche encore, les deux listes
-- n'ont donc pas toujours la meme longueur.
EVO_Portal.EVENT_IDX      = 15
EVO_Portal.EVENT_NOM      = "???"
EVO_Portal.EVENT_CD       = 30   -- secondes entre deux ouvertures vers le point
EVO_Portal.EVENT_TIER     = 2    -- 2 = Animateur sur le perso animation (EVO_ANIM.Tier), comme le mode build
EVO_Portal.EVENT_PORTAILS = { "garganta", "senkaimon" } -- ordre des bits reseau

-- Etat vu des deux cotes : pose ou non, par qui, et quels portails y menent. Seul le
-- serveur connait la position.
EVO_Portal.Evenement = EVO_Portal.Evenement or { pose = false, par = "", portails = {} }

function EVO_Portal.EvenementActif(id)
	local e = EVO_Portal.Evenement
	return e.pose == true and e.portails[id] == true
end

if SERVER then
	util.AddNetworkString("EVO:Portal:Evenement")      -- client -> serveur : etat, poser, cocher, retirer
	util.AddNetworkString("EVO:Portal:EvenementEtat")  -- serveur -> clients : l'etat, a chaque changement

	function EVO_Portal.PeutPoserEvenement(ply)
		if not IsValid(ply) then return false end
		if ply:IsSuperAdmin() then return true end
		return ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0) >= EVO_Portal.EVENT_TIER
	end

	local function envoyer(cible)
		local e = EVO_Portal.Evenement
		net.Start("EVO:Portal:EvenementEtat")
			net.WriteBool(e.pose == true)
			net.WriteString(e.par or "")
			for _, id in ipairs(EVO_Portal.EVENT_PORTAILS) do net.WriteBool(e.portails[id] == true) end
		if cible then net.Send(cible) else net.Broadcast() end
	end

	local function retirer()
		local e = EVO_Portal.Evenement
		e.pose, e.pos, e.ang, e.par, e.sid, e.portails = false, nil, nil, "", nil, {}
	end

	local function notifier(ply, msg)
		if MUGEN and MUGEN.Notify then MUGEN.Notify(ply, msg, NOTIFY_GENERIC or 0, 5) end
	end

	local ACTIONS = { "pose", "case", "retire" }
	net.Receive("EVO:Portal:Evenement", function(_, ply)
		if not IsValid(ply) or not ply:RateLimit("portal_evenement", 0.3) then return end
		local action = net.ReadUInt(2)
		-- 0 : le client demande l'etat (a son arrivee, a l'ouverture du panneau).
		if action == 0 then envoyer(ply) return end
		if not EVO_Portal.PeutPoserEvenement(ply) then return end
		local e = EVO_Portal.Evenement
		if action == 1 then
			-- Poser (ou deplacer) le point : les pieds de l'animateur, son regard a
			-- l'horizontale (les arrivants regardent dans ce sens). Les cases restent.
			e.pos, e.ang = ply:GetPos(), Angle(0, ply:EyeAngles().yaw, 0)
			e.pose, e.par, e.sid = true, ply:Nick(), ply:SteamID64()
			notifier(ply, "Point d'arrivée posé ici. Coche Garganta et/ou Senkaimon pour l'ouvrir aux joueurs.")
		elseif action == 2 then
			-- Cocher / decocher un portail (bascule).
			local id = EVO_Portal.EVENT_PORTAILS[net.ReadUInt(1) + 1]
			if not id then return end
			e.portails[id] = not e.portails[id]
		else
			retirer()
			notifier(ply, "Point d'arrivée retiré : la case « ??? » disparaît des roues.")
		end
		envoyer()
		if EVO_StaffLog then
			EVO_StaffLog(ply, "anim.portail_evenement", nil, string.format("%s pos=%s garganta=%s senkaimon=%s",
				ACTIONS[action] or "?", tostring(e.pos), tostring(e.portails.garganta == true), tostring(e.portails.senkaimon == true)))
		end
	end)

	-- Point pose par quelqu'un qui part : plus personne ne le tient, on le retire.
	hook.Add("PlayerDisconnected", "EVO_Portal:Evenement:Depart", function(ply)
		local e = EVO_Portal.Evenement
		if e.pose and e.sid == ply:SteamID64() then
			retirer()
			envoyer()
		end
	end)
else
	-- Client : l'etat tenu a jour par le serveur, lu par la roue et le panneau.
	net.Receive("EVO:Portal:EvenementEtat", function()
		local e = EVO_Portal.Evenement
		e.pose = net.ReadBool()
		e.par = net.ReadString()
		e.portails = {}
		for _, id in ipairs(EVO_Portal.EVENT_PORTAILS) do e.portails[id] = net.ReadBool() end
	end)

	-- action : 0 etat, 1 poser ici, 2 cocher (quel = 0 Garganta, 1 Senkaimon), 3 retirer.
	function EVO_Portal.EnvoyerEvenement(action, quel)
		net.Start("EVO:Portal:Evenement")
			net.WriteUInt(action, 2)
			if action == 2 then net.WriteUInt(quel or 0, 1) end
		net.SendToServer()
	end

	-- Un joueur qui arrive apres la pose doit aussi voir la case : il demande l'etat une
	-- fois charge (un message envoye avant que son Lua tourne serait perdu).
	hook.Add("InitPostEntity", "EVO_Portal:Evenement:Etat", function()
		EVO_Portal.EnvoyerEvenement(0)
	end)
end
