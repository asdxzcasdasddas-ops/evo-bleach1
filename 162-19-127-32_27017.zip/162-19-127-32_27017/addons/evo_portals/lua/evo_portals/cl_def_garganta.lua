-- "addons\\evo_portals\\lua\\evo_portals\\cl_def_garganta.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PORTALS — config CLIENT de la GARGANTA (roue + salle NOIRE + ambiance).
--   Toute la mécanique (bind, roue, invisibilité, rendu salle) est dans
--   evo_portals/cl_engine.lua ; ce fichier n'est QUE la config visuelle.
-- ============================================================================
if SERVER then return end

-- Salle NOIRE : murs rendus en noir, visibles SEULEMENT de l'intérieur.
local ROOMMAT = CreateMaterial("evo_garganta_room_black", "UnlitGeneric", {
	["$basetexture"]  = "color/white",
	["$model"]        = "1",
	["$nocull"]       = "1",
	["$vertexcolor"]  = "1",  -- pour que la couleur (noir) du DrawBox s'applique vraiment
	["$vertexalpha"]  = "1",
})

EVO_Portal.RegisterClient({
	ID            = "garganta",
	NET_OPEN      = "EVO:Garganta:Open",
	BIND_NAME     = "garganta",
	FACTIONS      = { ["Hollow"] = true },
	MIN_RANK      = 10,
	NW_INSIDE     = "EvoGargantaInside",
	-- Doit correspondre a ENT.NWUntil (entities/evo_garganta/shared.lua) : instant du TP.
	-- Sans elle le masquage "dans la salle" ne peut plus expirer, cf. insideBy (cl_engine).
	NW_UNTIL      = "EvoGargantaUntil",
	WALL_CLASS    = "evo_garganta_wall",

	ZONES_BY_MAP = {
		["rp_seireitei_v1"]   = { "Hueco Mundo" },   -- Hollow étranger : seulement rentrer
		-- [1] surface = Zone Neutre I, [3] étage du bas = Désert du Hueco (noms recalés 09/21).
		["hueco_mundo_v1"]    = { "Zone Neutre I", "Las Noches", "Désert du Hueco", "Zone Neutre II", "Soul Society", "Zone neutre Monde des vivants" },
		["rp_shinonome_evo"]   = { "Hueco Mundo", "Soul Society" }, -- zone neutre : sortir seulement
	},

	-- Index des zones CROSS-SERVEUR (par map, MEME ORDRE que ZONES_BY_MAP). Local (in-map)
	-- et cross-serveur sont 2 CD SEPARES -> le client lit le bon NWFloat selon la zone.
	-- NB : "Hueco Mundo" est CROSS sur Seireitei mais LOCAL sur Hueco -> marqueur par INDEX.
	CROSS_ZONES_BY_MAP = {
		["rp_seireitei_v1"] = { [1] = true },  -- "Hueco Mundo" (cross)
		["hueco_mundo_v1"]  = { [5] = true, [6] = true },  -- "Soul Society", zone neutre
		["rp_shinonome_evo"] = { [1] = true, [2] = true },  -- tout est cross depuis la zone neutre
	},

	-- Roue
	TITLE      = "GARGANTA",
	-- Image affichée au CENTRE de la roue (nom au-dessus, léger mouvement au survol).
	IMAGE      = "etgmnxxbvsadh9/etgmnxxbvsadh9/garganta.png",
	ACCENT     = Color(190, 110, 220),
	SEL_BOX    = Color(120, 50, 160, 245),
	UNSEL_BOX  = Color(22, 20, 26, 235),
	TEXT_SEL   = Color(255, 255, 255),
	TEXT_UNSEL = Color(200, 200, 205),
	HINT       = "Relâche sur une zone pour ouvrir la Garganta",
	MSG_NOMAP  = "Aucune destination Garganta configurée sur cette map.",

	-- Salle + ambiance
	ROOM_MAT      = ROOMMAT,
	ROOM_COLOR    = Color(6, 6, 10, 255),
	ROOM_NWPREFIX = "evogarg",
	VEIL_COLOR    = Color(0, 0, 4, 130),
	BLUR_AMOUNT   = 4,
	BLUR_PASSES   = 4,
})
