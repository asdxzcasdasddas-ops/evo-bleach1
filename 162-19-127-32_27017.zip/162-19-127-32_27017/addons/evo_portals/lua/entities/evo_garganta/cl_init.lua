-- "addons\\evo_portals\\lua\\entities\\evo_garganta\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")
-- Rendu (modèle seul, sans lueur) hérité de evo_portal_base/cl_init.lua.
