-- "addons\\evo_portals\\lua\\entities\\evo_garganta\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- GARGANTA — porte de téléportation des HOLLOWS. Hérite de evo_portal_base ;
-- ne change QUE l'animation (par SCALE), le modèle, les noms et la lueur.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_base"
ENT.PrintName = "Garganta"
ENT.Model     = "models/evo/props/props_anim/evo_H59dzJFCZ315fzD/evo_H59dzJFCZ315fzD.mdl"

ENT.CfgName   = "EVO_Garganta"
ENT.WallClass = "evo_garganta_wall"
ENT.FxClass   = "evo_garganta_fx"
ENT.NWInside  = "EvoGargantaInside"   -- contrat externe (crossserver / orbit cam / pnj)
ENT.NWUntil   = "EvoGargantaUntil"
-- PAS de lueur (09/28, user : la lumière violette rendait mal) -> GlowColor absent.
