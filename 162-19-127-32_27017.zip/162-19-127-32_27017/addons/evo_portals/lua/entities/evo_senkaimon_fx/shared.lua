-- "addons\\evo_portals\\lua\\entities\\evo_senkaimon_fx\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Porte de SORTIE Senkaimon (visuel pur). Hérite de evo_portal_fx ; séquences bakées.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_fx"
ENT.PrintName = "Senkaimon (sortie)"
ENT.Model     = "models/evo/props/props_anim/evo_rnj8hs7grukf6/evo_c81xtrdihynyze.mdl"

ENT.CfgName   = "EVO_Senkaimon"
ENT.GlowColor = Color(235, 235, 255)
ENT.GlowSize  = 220
ENT.HoldTime  = 0   -- la fermeture enchaîne dès la fin de l'ouverture (séquence)
