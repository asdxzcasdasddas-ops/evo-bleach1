-- "addons\\evo_portals\\lua\\entities\\evo_senkaimon_fx\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")
-- Rendu hérité de evo_portal_fx/cl_init.lua.
