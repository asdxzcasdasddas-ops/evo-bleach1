-- "addons\\evo_portals\\lua\\entities\\evo_portal_wall\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Initialize() self:SetNoDraw(true) end

-- Invisible (murs de collision uniquement ; la salle est dessinée par cl_engine).
function ENT:Draw() end
