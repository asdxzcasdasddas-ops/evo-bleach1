-- "addons\\evo_portals\\lua\\entities\\evo_portal_wall\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Base des MURS invisibles de la salle (Garganta / Senkaimon en héritent).
-- Murs en U : fond + 2 côtés + plafond ; avant (porte) et sol ouverts.
ENT.Type           = "anim"
ENT.Base           = "base_anim"
ENT.PrintName      = "Portal (murs)"
ENT.Author         = "Evo"
ENT.Spawnable      = false
ENT.AdminSpawnable = false

-- Surchargés par les dérivées :
ENT.NWPrefix = "evoportal"  -- préfixe des dimensions networkées (rendu de la salle client)
ENT.CfgName  = nil          -- global de config pour la durée de vie failsafe
