-- "addons\\evo_portals\\lua\\entities\\evo_portal_fx\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Base de la porte de SORTIE (visuel pur : s'ouvre, son, se referme, disparaît ;
-- aucune salle / TP / collision). Garganta / Senkaimon en héritent et ne changent
-- QUE l'animation (scale vs séquence) + le modèle + la lueur.
ENT.Type                  = "anim"
ENT.Base                  = "base_anim"
ENT.PrintName             = "Portal (sortie)"
ENT.Author                = "Evo"
ENT.Spawnable             = false
ENT.AdminSpawnable        = false
ENT.AutomaticFrameAdvance = true

ENT.HoldTime = 0.6   -- temps entre la fin de l'ouverture et le début de la fermeture
ENT.CfgName  = nil   -- global de config (sons / courbes / niveau sonore)
