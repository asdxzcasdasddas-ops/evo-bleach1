-- "addons\\evo_portals\\lua\\entities\\evo_garganta_wall\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Murs invisibles de la salle Garganta. Hérite de evo_portal_wall.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_wall"
ENT.PrintName = "Garganta (murs)"

ENT.NWPrefix  = "evogarg"        -- contrat : cl_engine lit evogarg_d / _hw / _h
ENT.CfgName   = "EVO_Garganta"
