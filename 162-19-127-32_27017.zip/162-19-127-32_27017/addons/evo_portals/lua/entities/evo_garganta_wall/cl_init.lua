-- "addons\\evo_portals\\lua\\entities\\evo_garganta_wall\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")
-- Invisible (rendu de salle géré par cl_engine) ; Draw hérité de evo_portal_wall.
