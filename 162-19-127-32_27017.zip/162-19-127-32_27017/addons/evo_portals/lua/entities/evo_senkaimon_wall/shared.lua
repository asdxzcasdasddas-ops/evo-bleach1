-- "addons\\evo_portals\\lua\\entities\\evo_senkaimon_wall\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Murs invisibles de la salle Senkaimon. Hérite de evo_portal_wall.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_wall"
ENT.PrintName = "Senkaimon (murs)"

ENT.NWPrefix  = "evosenkai"      -- contrat : cl_engine lit evosenkai_d / _hw / _h
ENT.CfgName   = "EVO_Senkaimon"
