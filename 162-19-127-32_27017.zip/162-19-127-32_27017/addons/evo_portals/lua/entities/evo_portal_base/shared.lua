-- "addons\\evo_portals\\lua\\entities\\evo_portal_base\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Entité de BASE des portes de portail (Garganta / Senkaimon en héritent via
-- ENT.Base). Porte TOUTE la logique commune : salle, murs, détection, TP global,
-- redirection cross-serveur. Les dérivées ne changent QUE l'animation + les noms
-- (config, classes murs/fx, variables réseau). Voir evo_portals_loader.lua.
ENT.Type                  = "anim"
ENT.Base                  = "base_anim"
ENT.PrintName             = "Portal (base)"
ENT.Author                = "Evo"
ENT.Spawnable             = false
ENT.AdminSpawnable        = false
ENT.AutomaticFrameAdvance = true  -- CRITIQUE : avance les anims même en MOVETYPE_NONE

-- Champs surchargés par les dérivées (valeurs de repli sûres ici) :
ENT.CfgName   = nil                 -- nom du global de config ("EVO_Garganta"/...)
ENT.WallClass = "evo_portal_wall"   -- classe des murs invisibles à spawn
ENT.FxClass   = "evo_portal_fx"     -- classe de la porte de sortie (visuel pur)
ENT.NWInside  = "EvoPortalInside"   -- NWBool "dans la salle"
ENT.NWUntil   = "EvoPortalUntil"    -- NWFloat timestamp du TP global
