-- "addons\\evo_portals\\lua\\entities\\evo_portal_base\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Initialize() end

-- Dessin commun : le modèle + une lueur d'ambiance dont la COULEUR vient de la
-- dérivée (ENT.GlowColor : violet Garganta / bleu Senkaimon).
function ENT:Draw()
	self:DrawModel()

	local g = self.GlowColor
	if not g then return end
	local dl = DynamicLight(self:EntIndex())
	if dl then
		dl.pos        = self:GetPos() + Vector(0, 0, 70)
		dl.r, dl.g, dl.b = g.r, g.g, g.b
		dl.brightness = 2
		dl.Decay      = 1000
		dl.Size       = self.GlowSize or 240
		dl.DieTime    = CurTime() + 0.1
	end
end
