-- "addons\\evo_portals\\lua\\entities\\evo_garganta_fx\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Garganta de SORTIE (visuel pur). Hérite de evo_portal_fx ; animation par SCALE.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_fx"
ENT.PrintName = "Garganta (sortie)"
ENT.Model     = "models/evo/props/props_anim/evo_H59dzJFCZ315fzD/evo_H59dzJFCZ315fzD.mdl"

ENT.CfgName   = "EVO_Garganta"
-- PAS de lueur (09/28, user) -> GlowColor absent.
ENT.HoldTime  = 0.6   -- court instant entre ouverture et fermeture
