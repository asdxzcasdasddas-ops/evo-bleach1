-- "addons\\evo_portals\\lua\\entities\\evo_senkaimon\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")
-- Rendu (modèle + lueur bleutée) hérité de evo_portal_base/cl_init.lua.
