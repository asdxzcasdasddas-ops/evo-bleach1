-- "addons\\evo_portals\\lua\\entities\\evo_senkaimon\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- SENKAIMON — porte de téléportation des SHINIGAMI. Hérite de evo_portal_base ;
-- ne change QUE l'animation (par SÉQUENCES bakées), le modèle, les noms, la lueur.
ENT.Type      = "anim"
ENT.Base      = "evo_portal_base"
ENT.PrintName = "Senkaimon"
ENT.Model     = "models/evo/props/props_anim/evo_rnj8hs7grukf6/evo_c81xtrdihynyze.mdl"

ENT.CfgName   = "EVO_Senkaimon"
ENT.WallClass = "evo_senkaimon_wall"
ENT.FxClass   = "evo_senkaimon_fx"
ENT.NWInside  = "EvoSenkaiInside"   -- contrat externe (crossserver / orbit cam / pnj)
ENT.NWUntil   = "EvoSenkaiUntil"
ENT.GlowColor = Color(120, 175, 255)  -- lueur bleutée (portail Shinigami)
ENT.GlowSize  = 240
