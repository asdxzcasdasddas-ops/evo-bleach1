-- "addons\\lzy_character\\lua\\autorun\\client\\cl_face_animate.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- PILOTAGE VISAGE EN CODE (client) — clignement des yeux + lipsync de la bouche.
-- Les têtes custom evo/face cassent le blink/lipsync AUTOMATIQUE du moteur (les
-- flexes de sculpt du char creator entrent en conflit). Plutôt que de compter sur
-- le moteur, on pilote NOUS-MÊMES, chaque frame de rendu, les 2 flexes moteur :
--   • "blink"     -> clignement périodique (courbe douce)
--   • "djo_drop"  -> ouverture de mâchoire = lipsync, proportionnel au VOLUME de
--                    la voix du joueur (Player:VoiceVolume) quand il parle.
-- Branché sur PrePlayerDraw : par joueur VISIBLE uniquement (pas de player.GetAll),
-- juste avant le rendu -> notre valeur écrase toute valeur épinglée par le sculpt.
-- ============================================================================
if not CLIENT then return end

-- Noms de flex à piloter (1er trouvé sur le modèle). Fallbacks si une variante de
-- tête nomme autrement son clignement / sa mâchoire.
local BLINK_FLEXES = { "blink" }
local JAW_FLEXES   = { "djo_drop", "jaw_drop", "mouth_open", "JawOpen" }

-- Réglages (tunables) :
local BLINK_MIN, BLINK_MAX = 2.6, 6.5   -- intervalle aléatoire entre 2 clignements (s)
local BLINK_DUR            = 0.12         -- durée d'un clignement (s)
local JAW_GAIN             = 1.7          -- gain volume -> ouverture bouche
local JAW_MAX              = 1.0          -- ouverture max de la bouche
local JAW_SMOOTH           = 18           -- lissage de la bouche (plus grand = plus vif)
-- Portée de pilotage. 4000 u (~70 m) était bien au-delà du lisible : à cette distance
-- un clignement fait deux pixels, mais il coûtait quand même deux écritures de flex par
-- joueur et par image. En foule (100 joueurs autour) c'était 200 recalculs de morph par
-- frame pour des visages que personne ne distingue. 1200 u couvre largement la portée où
-- un visage se lit (conversation, RP rapproché).
local RANGE                = 1200
local RANGE_SQR            = RANGE * RANGE
-- En dessous de ce delta, réécrire le flex ne change rien à l'image : on s'abstient.
-- C'est le gros du gain — hors clignement (rare) et hors parole, la valeur cible est
-- CONSTANTE, donc la quasi-totalité des écritures d'avant étaient des non-événements.
local FLEX_EPS             = 0.004

local CV = CreateClientConVar("lzy_face_animate", "1", true, false,
	"Pilote clignement + lipsync du visage en code (0 = laisser le moteur).")

local function firstFlex(ent, names)
	for _, n in ipairs(names) do
		local id = ent:GetFlexIDByName(n)
		if id and id >= 0 then return id end
	end
	return nil
end

-- (Re)résout les IDs de flex quand le modèle change ; état stocké SUR l'entité
-- (GC avec elle, pas de fuite type table[ent]).
local function ensureFace(ent)
	local mdl = ent:GetModel()
	if ent._lzyFaceMdl == mdl then return end
	ent._lzyFaceMdl  = mdl
	ent._lzyBlinkId  = firstFlex(ent, BLINK_FLEXES)
	ent._lzyJawId    = firstFlex(ent, JAW_FLEXES)
	ent._lzyBlinkNxt = CurTime() + math.Rand(BLINK_MIN, BLINK_MAX)
	ent._lzyBlinkEnd = 0
	ent._lzyJaw      = 0
	-- Dernières valeurs REELLEMENT posées sur le modèle. `nil` (et pas 0) volontairement :
	-- au premier passage il FAUT écrire, même un 0, sinon un flex laissé ouvert par le
	-- sculpt du char creator resterait ouvert.
	ent._lzyBlinkSet = nil
	ent._lzyJawSet   = nil
end

-- Ecrit un flex SEULEMENT s'il bouge. Renvoie la valeur retenue.
local function poseFlex(ent, id, valeur, derniere)
	if derniere and math.abs(valeur - derniere) < FLEX_EPS then return derniere end
	ent:SetFlexWeight(id, valeur)
	return valeur
end

hook.Add("PrePlayerDraw", "LZY:Character:FaceAnimate", function(ply)
	if not CV:GetBool() then return end
	if not IsValid(ply) then return end
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply) then return end
	-- Joueur ECARTE par le plafond max_characters_drawn : son corps n'est pas dessiné,
	-- animer son visage revient à payer des morphs pour une image que personne ne verra.
	-- On ne peut pas compter sur l'ordre des hooks (SkipOverBudget peut passer APRES
	-- celui-ci), donc on relit le tag du LOD nous-mêmes.
	if ply._lzyShouldDraw == false then return end
	-- Perf : ignore les joueurs lointains (le visage n'est de toute façon pas lisible).
	-- GetPos plutôt qu'EyePos : même verdict à cette échelle, sans l'offset de vue.
	local lp = LocalPlayer()
	if IsValid(lp) and ply ~= lp and ply:GetPos():DistToSqr(lp:GetPos()) > RANGE_SQR then return end

	ensureFace(ply)
	local now = CurTime()

	-- ── Clignement des yeux ──
	local bId = ply._lzyBlinkId
	if bId then
		if now >= (ply._lzyBlinkNxt or 0) then
			ply._lzyBlinkEnd = now + BLINK_DUR
			ply._lzyBlinkNxt = now + math.Rand(BLINK_MIN, BLINK_MAX)
		end
		local w = 0
		local endT = ply._lzyBlinkEnd or 0
		if now < endT then
			-- t : 1 au début -> 0 à la fin ; ouverture->fermé->ouvert (sin doux)
			local t = (endT - now) / BLINK_DUR
			w = math.sin((1 - t) * math.pi)
		end
		ply._lzyBlinkSet = poseFlex(ply, bId, w, ply._lzyBlinkSet)
	end

	-- ── Lipsync : ouverture de bouche selon le volume de la voix ──
	local jId = ply._lzyJawId
	if jId then
		local target = 0
		if ply:IsSpeaking() then
			local vv = ply:VoiceVolume() or 0          -- 0..1 (autres joueurs ; local = voice_loopback)
			if vv <= 0 then vv = 0.22 end               -- filet si le volume n'est pas dispo
			target = math.Clamp(vv * JAW_GAIN, 0, JAW_MAX)
		end
		ply._lzyJaw = Lerp(math.Clamp(FrameTime() * JAW_SMOOTH, 0, 1), ply._lzyJaw or 0, target)
		-- La bouche fermée converge vers 0 sans jamais l'atteindre (Lerp) : on colle à 0
		-- sous le seuil, sinon le lissage réécrirait le flex indéfiniment pour un
		-- mouvement invisible, et le silence coûterait autant que la parole.
		if target == 0 and ply._lzyJaw < FLEX_EPS then ply._lzyJaw = 0 end
		ply._lzyJawSet = poseFlex(ply, jId, ply._lzyJaw, ply._lzyJawSet)
	end
end)
