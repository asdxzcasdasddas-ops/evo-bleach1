-- "addons\\lzy_character\\lua\\lzy_character\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_CHARACTER_CONFIG = LZY_CHARACTER_CONFIG or {}

-- Distances de rendu joueur (unités Source ; le client compare en u² via DistanceSqr).
-- Tête = player entity (face SetModel) ; corps / cheveux = ClientsideModels bonemergés.
LZY_CHARACTER_CONFIG.DISTANCE_FACE_BODY_HAIR = 4000
-- Barbe, moustache, accessoires équipés (ClientsideModels lazy, cf. evo_player_lod).
-- Aussi seuil des cheveux HQ (toon+gradient) : au-delà = cheap ou skip selon budget.
LZY_CHARACTER_CONFIG.DISTANCE_ACCESSORIES = 2000
-- Bake / submaterial tatouage RT sur la face.
LZY_CHARACTER_CONFIG.DISTANCE_TATTOO = 1000

function LZY_CHARACTER_CONFIG.DistanceSqr(units)
	units = tonumber(units) or 0
	return units * units
end

function LZY_CHARACTER_CONFIG.GetFaceBodyHairDistanceSqr()
	return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_CHARACTER_CONFIG.DISTANCE_FACE_BODY_HAIR)
end

function LZY_CHARACTER_CONFIG.GetAccessoriesDistanceSqr()
	return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_CHARACTER_CONFIG.DISTANCE_ACCESSORIES)
end

function LZY_CHARACTER_CONFIG.GetTattooDistanceSqr()
	return LZY_CHARACTER_CONFIG.DistanceSqr(LZY_CHARACTER_CONFIG.DISTANCE_TATTOO)
end

-- ============================================================
-- ANCRES DU CRÉATEUR PAR MAP (préview du perso + TP du joueur pendant le
-- hub / la création). Clé = map -> faction -> { pos, ang }.
-- Capture in-game : se placer au bon endroit puis cmd superadmin
-- `lzy_creator_getanchor` (sort un bloc prêt à coller, cf. sv_net.lua).
-- Map ABSENTE => repli automatique : SERVEUR = info_player_start (spawn de la
-- map), CLIENT = position du joueur (le serveur l'y a déjà TP). Le créateur
-- marche donc out-of-the-box sur une map non configurée — mais capture une
-- vraie ancre dès que possible pour un décor propre derrière le perso.
-- ============================================================
LZY_CHARACTER_CONFIG.CREATOR_ANCHORS = {
    ["rp_seireitei_v1"] = {
        Shinigami = { pos = Vector(-9759.91, 10831.12, 379.61), ang = Angle(-2.50, 177.86, 0.00) },
        Hollow    = { pos = Vector(-9759.91, 10831.12, 379.61), ang = Angle(0.00, 48.861828, 0.00) },
    },
    ["hueco_mundo_v1"] = {
        -- Pose user 2026-07 (setpos 2535.41 8446.44 5364.14 ; setang yaw 3.563211).
        -- Yaw pris BRUT (deja le bon sens ~3.56, comme l'ancienne pose 3.61 qui marchait).
        -- +80u DEVANT (forward) + 15u a GAUCHE (Right * -15) du perso — demande user (ajustable).
        -- Shinigami : même ancre (slots ANIMATION 4 sur Hueco = perso Shinigami animateur ;
        -- sans entrée dédiée GetCreatorAnchor retombait sur Hollow, OK en pratique, mais on
        -- l'explicite pour le preview + NEW_CHAR_SPAWN ci-dessous).
        Hollow = { pos = Vector(2535.409912, 8446.438477, 5364.140137) + Angle(0, 3.563211, 0):Forward() * 80 + Angle(0, 3.563211, 0):Right() * -15, ang = Angle(0, 3.563211, 0) },
        Shinigami = { pos = Vector(2535.409912, 8446.438477, 5364.140137) + Angle(0, 3.563211, 0):Forward() * 80 + Angle(0, 3.563211, 0):Right() * -15, ang = Angle(0, 3.563211, 0) },
    },
    ["rp_shinonome_evo"] = {
        -- Capture user (setpos -3009.23 2130.28 283.84 ; setang pitch 89 yaw 0.67).
        -- Pitch 89 = regard vers les pieds au getpos : on ne garde que le YAW.
        -- Pose relevée EN VOL (user 08/27 « trop haute ») : groundSnap -> le Z est
        -- retracé au SOL à l'usage (GetCreatorAnchor), x/y/yaw conservés.
        Shinigami = { pos = Vector(-3009.234131, 2130.277588, 283.836670), ang = Angle(0, 0.671765, 0), groundSnap = true },
        Hollow    = { pos = Vector(-3009.234131, 2130.277588, 283.836670), ang = Angle(0, 0.671765, 0), groundSnap = true },
    },
}

--- Ancre (pos, ang) du créateur pour `faction` sur la map courante.
--- Ne retourne JAMAIS nil : repli spawn map / position joueur (cf. ci-dessus).
function LZY_CHARACTER_CONFIG.GetCreatorAnchor(faction)
    local byMap = LZY_CHARACTER_CONFIG.CREATOR_ANCHORS[game.GetMap()]
    local a = byMap and (byMap[faction] or byMap.Shinigami or byMap.Hollow)
    if a and a.pos then
        -- groundSnap : ancre relevée en l'air -> Z ramené au sol (monde seulement, les
        -- brushs sont toujours chargés côté client). Mémorisé sur l'entrée ; trace ratée
        -- (au-dessus du vide) = pose brute inchangée.
        if a.groundSnap and not a._snapped then
            local tr = util.TraceLine({
                start = a.pos + Vector(0, 0, 32),
                endpos = a.pos - Vector(0, 0, 4096),
                mask = MASK_SOLID_BRUSHONLY,
            })
            if tr.Hit and not tr.HitSky then
                a.pos = tr.HitPos + Vector(0, 0, 2)
                a._snapped = true
            end
        end
        return a.pos, a.ang or Angle(0, 0, 0)
    end
    if SERVER then
        if not LZY_CHARACTER_CONFIG._anchorWarned then
            LZY_CHARACTER_CONFIG._anchorWarned = true
            print("[lzy_character] CREATOR_ANCHORS : map '" .. game.GetMap()
                .. "' non configurée — ancre = spawn de la map (capture avec lzy_creator_getanchor).")
        end
        local s = ents.FindByClass("info_player_start")[1]
        if IsValid(s) then return s:GetPos() + Vector(0, 0, 10), Angle(0, s:GetAngles().y, 0) end
        return Vector(0, 0, 64), Angle(0, 0, 0)
    end
    local lp = LocalPlayer()
    if IsValid(lp) then return lp:GetPos(), Angle(0, lp:EyeAngles().y + 180, 0) end
    return Vector(0, 0, 64), Angle(0, 0, 0)
end

-- Alias HÉRITÉS (= entrée seireitei). NE PLUS UTILISER dans du nouveau code :
-- passer par GetCreatorAnchor() qui est per-map. Conservés car référencés
-- ailleurs (ex. ncm_char_select) et comme valeur de repli historique.
LZY_CHARACTER_CONFIG.INSTANCE_POS_SHINIGAMI = Vector(-9759.91, 10831.12, 379.61)
LZY_CHARACTER_CONFIG.INSTANCE_POS_HOLLOW = Vector(-9759.91, 10831.12, 379.61)

LZY_CHARACTER_CONFIG.INSTANCE_ANG_SHINIGAMI = Angle(-2.50, 177.86, 0.00)
LZY_CHARACTER_CONFIG.INSTANCE_ANG_HOLLOW = Angle(0.00, 48.861828, 0.00)

-- Spawn d'un NOUVEAU perso (création) — SÉPARÉ des ancres (qui restent le point de
-- PREVIEW du créateur). Clé = map -> faction. Map/faction absente => fallback
-- GetCreatorAnchor (per-map).
LZY_CHARACTER_CONFIG.NEW_CHAR_SPAWN = {
    ["rp_seireitei_v1"] = {
        Shinigami = { pos = Vector(-188.704453, -12521.172852, 435.637604), ang = Angle(-2.244003, 89.868317, 0.000000) },
    },
    ["hueco_mundo_v1"] = {
        -- Nouvelle zone de spawn (user 08/20). Le `setang` fourni portait un pitch de 89
        -- (le joueur regardait ses pieds au moment du getpos) : on ne garde que le YAW,
        -- sinon on spawne le nez dans le sable.
        Hollow = { pos = Vector(1850.620239, -7745.360352, 5480.724121), ang = Angle(0, 90.526367, 0) },
        -- Perso ANIMATION Shinigami (slot 4) créé sur Hueco : depuis le 08/22 il
        -- arrive à la PORTE Senkaimon comme n'importe quel Shinigami sur cette map
        -- (1re pose de CROSS_ARRIVAL), au lieu de la zone d'accueil Hollow.
        Shinigami = { pos = Vector(-8026.460938, 10004.818359, 9810.723633), ang = Angle(0, -15.769165, 0) },
    },
}

-- LARVE HOLLOW : elle garde l'ANCIENNE zone de spawn (demande user 08/20) — la nouvelle
-- ci-dessus est pour les persos normaux. Ce n'est pas qu'une préférence : l'anneau de PNJ
-- « désert STARTER » (ncm_pnj/sv_pnj_world_hunt.lua) est calé À LA MAIN autour de ce point,
-- et hors de son ActivationRadius (2800) une larve neuve n'activerait AUCUN Hollow à chasser.
-- Déplacer l'un sans l'autre casse le démarrage de la progression Hollow.
-- Map absente d'ici => la larve suit le spawn normal.
LZY_CHARACTER_CONFIG.NEW_CHAR_SPAWN_LARVA = {
    ["hueco_mundo_v1"] = { pos = Vector(2721.830566, 2269.475586, 118.096680), ang = Angle(0, -178.221359, 0) },
}

-- Points d'ARRIVÉE cross-serveur (la "porte") par map : où l'on spawn quand on
-- arrive de l'AUTRE serveur via Senkaimon/Garganta. Override la dernière position
-- UNIQUEMENT pour ce cas (un join/sélection normal garde sa last_position). Map
-- absente => repli sur last_position. Capturer avec `getpos`.
-- Format : LISTE de { pos, ang }. À l'arrivée on tire UNE pose au hasard ; pendant
-- CROSS_ARRIVAL_STICKY secondes, toutes les arrivées suivantes reprennent LA MÊME
-- (vague Hollow/Shinigami qui débarquent ensemble). Fenêtre glissante : chaque
-- arrivée relance le timer. 1 seule entrée = comportement fixe d'avant.
LZY_CHARACTER_CONFIG.CROSS_ARRIVAL_STICKY = 300 -- 5 min
LZY_CHARACTER_CONFIG.CROSS_ARRIVAL = {
    -- Seireitei : où un HOLLOW débarque via la Garganta (3 poses user 08/22).
    -- Les setang portaient un pitch 89 (regard aux pieds au getpos) : YAW gardé
    -- brut, pitch ramené à 0 — même règle que NEW_CHAR_SPAWN / CROSS_ARRIVAL Hueco.
    ["rp_seireitei_v1"] = {
        { pos = Vector(9705.241211, -10133.509766, -7143.517090), ang = Angle(0, 2.448763, 0) },
        { pos = Vector(10753.051758, -10597.536133, -7143.760742), ang = Angle(0, 70.824768, 0) },
        { pos = Vector(11242.287109, -10245.277344, -7117.797363), ang = Angle(0, 153.324692, 0) },
    },
    -- Hueco : où un SHINIGAMI débarque via le Senkaimon (et respawn de mort d'un
    -- Shinigami sur Hueco, via ResolveCrossArrival). 4 poses user 08/22 ; les
    -- setang portaient un pitch ~89 (regard aux pieds au getpos) : YAW gardé
    -- brut, pitch ramené à 0 — même règle que NEW_CHAR_SPAWN Hueco.
    ["hueco_mundo_v1"] = {
        { pos = Vector(-8026.460938, 10004.818359, 9810.723633), ang = Angle(0, -15.769165, 0) },
        { pos = Vector(-7725.390137, 8099.831055, 9810.723633), ang = Angle(0, 74.818810, 0) },
        { pos = Vector(-9127.882812, 8569.666016, 9810.616211), ang = Angle(0, -3.193237, 0) },
        { pos = Vector(-8544.387695, 11108.728516, 9810.269531), ang = Angle(0, -50.449276, 0) },
    },
    -- ZONE NEUTRE « Zone neutre Monde des vivants » (user 08/27) : map NEUTRE, aucune
    -- faction propriétaire -> GetCrossArrival ne consulte JAMAIS CROSS_ARRIVAL_HOME ici,
    -- et cette table sert à la fois à l'ARRIVÉE par portail et au RESPAWN de mort
    -- (via ResolveCrossArrival, qui couvre les maps neutres). SEULE map en forme PAR
    -- FACTION : { Hollow = {..}, Shinigami = {..}, Default = {..} } — Default = sans
    -- faction (âme errante) et toute faction non listée. Poses user 08/27 (yaw brut,
    -- pitch 89 du getpos remis à 0).
    ["rp_shinonome_evo"] = {
        Hollow    = { { pos = Vector(8994.780273, 13923.158203, 543.796387), ang = Angle(0, -146.746414, 0) } },
        Shinigami = { { pos = Vector(-2414.949707, 5059.105469, 128.025055), ang = Angle(0, -66.982513, 0) } },
        Default   = { { pos = Vector(4987.487305, 3673.014404, 43.851265),   ang = Angle(0, 137.953156, 0) } },
    },
}

-- RETOUR AU PAYS (user 08/27) : où débarque un joueur de la faction DE LA MAP qui
-- revient de l'autre serveur (Shinigami qui rentre du Hueco au Seireitei, Hollow
-- qui rentre du Seireitei au Hueco). Sans entrée ici, il tombait sur la porte
-- ENNEMIE de CROSS_ARRIVAL (Garganta Hollow au Seireitei…). Même format, même
-- sticky. Setpos user (pitch 89 au getpos -> yaw brut, pitch 0).
LZY_CHARACTER_CONFIG.CROSS_ARRIVAL_HOME = {
    ["rp_seireitei_v1"] = {
        { pos = Vector(1568.597412, 10074.791992, -5315.464355), ang = Angle(0, -74.471313, 0) },
    },
    ["hueco_mundo_v1"] = {
        { pos = Vector(2746.303467, -4036.012939, 9750.565430), ang = Angle(0, -48.650188, 0) },
    },
}

-- Sticky serveur : [clé map / map_home] = { spot = {pos,ang}, expires = CurTime }
local crossArrivalSticky = {}

--- Point d'arrivée cross-serveur de la map courante (ou nil si non configuré).
--- Tire au hasard parmi la liste, sticky CROSS_ARRIVAL_STICKY s entre arrivées.
--- sFaction (optionnel) : faction du perso qui arrive ; si c'est la faction DE LA
--- MAP et que CROSS_ARRIVAL_HOME la connaît -> porte de RETOUR, sinon porte
--- ennemie CROSS_ARRIVAL (respawn d'une faction étrangère, appels sans faction).
function LZY_CHARACTER_CONFIG.GetCrossArrival(sFaction)
    local map = game.GetMap()
    local entry, sKey = LZY_CHARACTER_CONFIG.CROSS_ARRIVAL[map], map
    local mf = LZY_CHARACTER_CONFIG.MAP_FACTION
    if isstring(sFaction) and mf and mf[map] == sFaction then
        local home = LZY_CHARACTER_CONFIG.CROSS_ARRIVAL_HOME and LZY_CHARACTER_CONFIG.CROSS_ARRIVAL_HOME[map]
        if home then entry, sKey = home, map .. "_home" end
    end
    if not entry then return nil end

    -- Forme PAR FACTION (maps neutres) : { Hollow = {..}, Shinigami = {..}, Default = {..} }.
    -- Détection : ni pose unique (pas de champ pos), ni liste (pas d'entrée [1]).
    if entry.pos == nil and entry[1] == nil then
        local own = isstring(sFaction) and entry[sFaction] or nil
        local sub = own or entry.Default
        if not istable(sub) then return nil end
        sKey = sKey .. "_" .. (own and sFaction or "default") -- sticky séparé par faction
        entry = sub
    end

    -- Compat : ancienne forme { pos=, ang= } (une seule pose).
    local spots
    if entry.pos ~= nil then
        spots = { entry }
    else
        spots = entry
    end
    local n = istable(spots) and #spots or 0
    if n <= 0 then return nil end
    if n == 1 then return spots[1] end

    -- Sticky uniquement serveur (seul appelant = spawn cross-serveur).
    if not SERVER then return spots[1] end

    local now = CurTime()
    local ttl = tonumber(LZY_CHARACTER_CONFIG.CROSS_ARRIVAL_STICKY) or 300
    local st = crossArrivalSticky[sKey]
    if st and st.spot and now < (st.expires or 0) then
        st.expires = now + ttl -- fenêtre glissante : vague continue = même porte
        return st.spot
    end

    local pick = spots[math.random(1, n)]
    crossArrivalSticky[sKey] = { spot = pick, expires = now + ttl }
    return pick
end

-- Restriction faction <-> map en création de personnage.
-- Sur ces maps, seule la faction associée peut être créée. Une map absente de
-- la table n'impose AUCUNE restriction (ex. gm_construct de test).
-- ⚠ La ZONE NEUTRE (rp_shinonome_evo) est VOLONTAIREMENT ABSENTE : c'est ce qui
-- permet aux DEUX factions d'y charger leur perso et d'y réapparaître (le garde
-- anti-exploit de sv_net et FactionAllowedOnMap ne se déclenchent que si la map
-- appartient à une faction). NE PAS l'ajouter ici.
LZY_CHARACTER_CONFIG.MAP_FACTION = {
	["rp_seireitei_v1"]   = "Shinigami",
	["hueco_mundo_v1"] = "Hollow",
}

-- Serveur GMod qui héberge chaque faction. En création de personnage, choisir une
-- faction hébergée sur l'AUTRE serveur (cf. MAP_FACTION) propose un transfert
-- (popup) puis un `connect` vers l'adresse correspondante. Mêmes adresses que les
-- portails Senkaimon / Garganta (evo_senkaimon / evo_garganta) : GARDER EN PHASE.
LZY_CHARACTER_CONFIG.FACTION_SERVER = {
	Shinigami = { name = "le Seireitei", addr = "game.evo-roleplay.com:27016" },
	Hollow    = { name = "Hueco Mundo",  addr = "game.evo-roleplay.com:27017" },
}

-- ── ANIMATIONS D'IDLE DISPONIBLES (poses « Debout », pour les aperçus) ────────────
-- Liste de réf (toutes les anims = lzy_animation_menu/config.lua). Mets l'ID voulu dans
-- IDLE_ANIM_* (inventaire/menu) et/ou CREATOR_IDLE_ANIM_* (créateur) ci-dessous :
--   "bleach_evo_act_bras_croise_idle"  -- Bras croisés (idle qui BOUCLE — recommandé pour un aperçu)
--   "idle_all_01"                      -- Idle neutre debout (valeur actuelle inventaire)
--   "evo_jhcb4o7px1yz3"                -- Bras croisés (emote menu)
--   "evo_5ilt23e0w6z7hh"               -- Bras croisés (autre)
--   "evo_usfpc0dmqdhmwoh9"             -- Attendre
--   "evo_gdw2emeap1ck6ff"              -- Poser tranquille
--   "evo_qd9likmrj3hnpsu8"             -- Pose cool
--   "evo_fl8lzok29qqb0"                -- Main sur le cœur
--   "evo_t9ed5d453empc541"             -- Mains jointes
-- ──────────────────────────────────────────────────────────────────────────────────

-- Idle des aperçus INVENTAIRE / MENU (LZY_Character_PlayerModel_PlayPanelIdle).
LZY_CHARACTER_CONFIG.IDLE_ANIM_MALE = "idle_all_01" --evo_o4vxrgfyntooa
LZY_CHARACTER_CONFIG.IDLE_ANIM_FEMALE = "idle_all_01"

-- Idle de l'aperçu du CHARACTER CREATOR — SÉPARÉ des IDLE_ANIM_* ci-dessus (demande user :
-- 2 anims différentes). Le créateur reste en BRAS CROISÉS sans toucher l'inventaire/menu.
LZY_CHARACTER_CONFIG.CREATOR_IDLE_ANIM_MALE   = "evo_5ilt23e0w6z7hh" -- Bras croisés (autre) (demande user)
LZY_CHARACTER_CONFIG.CREATOR_IDLE_ANIM_FEMALE = "evo_5ilt23e0w6z7hh"

LZY_CHARACTER_CONFIG.AVAILABLE_SKIN_COLORS = {
    {id = 0, color = Color(238, 194, 175)},
    {id = 1, color = Color(226, 173, 148)},
    {id = 2, color = Color(218, 160, 132)},
    {id = 3, color = Color(229, 161, 126)},
    {id = 4, color = Color(206, 134, 102)},
    {id = 5, color = Color(200, 124, 91)},
    {id = 6, color = Color(202, 122, 80)},
    {id = 7, color = Color(162, 98, 65)},
}

-- Peaux Hollow UNIQUEMENT (skins 8 et 9 bakés sur les modèles Arrancar). Affichées EN TÊTE
-- (positions 1 et 2) du sélecteur de couleur de peau, pour la faction Hollow seulement.
-- NOTE: couleurs de SWATCH provisoires — l'apparence réelle vient du skin baké du modèle ;
-- ajuster les Color() ci-dessous pour qu'elles matchent le rendu en jeu.
LZY_CHARACTER_CONFIG.HOLLOW_EXTRA_SKIN_COLORS = {
    {id = 8, color = Color(232, 224, 214)},
    {id = 9, color = Color(203, 197, 196)},
}

-- Liste ordonnée des couleurs de peau selon la faction. Hollow : skins 8/9 d'abord, puis la
-- palette commune (8/9 en positions 1-2). Toute autre faction : palette commune seule.
-- Source unique partagée par le créateur (UI + randomizer) ET la sanitisation serveur (clamp).
function LZY_CHARACTER_CONFIG.GetSkinColorsForFaction(faction)
    local base = LZY_CHARACTER_CONFIG.AVAILABLE_SKIN_COLORS
    if tostring(faction) ~= "Hollow" or not istable(LZY_CHARACTER_CONFIG.HOLLOW_EXTRA_SKIN_COLORS) then
        return base
    end
    local out = {}
    for _, e in ipairs(LZY_CHARACTER_CONFIG.HOLLOW_EXTRA_SKIN_COLORS) do out[#out + 1] = e end
    for _, e in ipairs(base) do out[#out + 1] = e end
    return out
end

LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE = "models/evo/face/male/evo_ef3af0qw8ptsm869r/evo_0m2bur0ao19q.mdl"
LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE = "models/evo/face/female/evo_8k2jhw1ql75i4yu/evo_ztpmdcvgli1j.mdl"

-- ── Flexes RÉSERVÉS AU MOTEUR (ne JAMAIS les épingler via shape_keys) ─────────
-- Le moteur pilote lui-même le CLIGNEMENT des yeux (flex "blink") et le LIPSYNC de
-- la bouche quand on parle (flex "djo_drop" = ouverture de mâchoire sur ces têtes).
-- Le sculpt du visage (characterData.shape_keys) était appliqué EN BLOC via
-- SetFlexWeight (sv_main au spawn + cl_models au rendu), ce qui figeait ces 2 flexes
-- -> yeux qui ne se ferment plus, bouche qui ne s'ouvre plus. On les EXCLUT de
-- l'application pour rendre la main au moteur. Le créateur n'expose AUCUN de ces
-- flexes en slider (sliders = Eye_shape*/Mouth_shape*/...), donc les exclure ne
-- retire aucun trait sculpté. Les IDs de flex étant propres à CHAQUE modèle, on
-- résout ces noms sur le modèle RÉEL de la cible (corrige aussi un éventuel mapping
-- d'ID décalé où un slider retomberait sur blink/djo_drop).
LZY_CHARACTER_CONFIG.RESERVED_FACE_FLEXES = {
	"blink",
	"djo_drop",
	-- variantes usuelles de lipsync/paupières Source (ignorées si absentes du modèle) :
	"jaw_drop",
	"right_lid_raiser", "left_lid_raiser",
	"right_lid_tightener", "left_lid_tightener",
	"right_lid_closer", "left_lid_closer",
}

-- Cache modèle -> set d'IDs de flex réservés (résolus sur le modèle réel de l'ent).
local reservedFlexIdCache = {}
function LZY_Character_ReservedFlexIds(ent)
	if not IsValid(ent) then return nil end
	local mdl = ent:GetModel()
	if not isstring(mdl) or mdl == "" then return nil end
	local cached = reservedFlexIdCache[mdl]
	if cached ~= nil then return cached end
	local ids = {}
	for _, name in ipairs(LZY_CHARACTER_CONFIG.RESERVED_FACE_FLEXES) do
		local id = ent:GetFlexIDByName(name)
		if id and id >= 0 then ids[id] = true end
	end
	reservedFlexIdCache[mdl] = ids
	return ids
end

-- Un flex-key de shape_keys (ID numérique, éventuellement string après JSON) est-il
-- réservé au moteur -> à NE PAS épingler ?
function LZY_Character_IsReservedFlexKey(ent, key)
	local ids = LZY_Character_ReservedFlexIds(ent)
	if not ids then return false end
	local id = tonumber(key)
	if not id then return false end
	return ids[id] == true
end

LZY_CHARACTER_CONFIG.PUPILS_COLORS = {
	["red"] = Color(230, 0, 0),
	["blue"] = Color(0, 0, 255),
	["purple"] = Color(128, 0, 128),
	["green"] = Color(0, 255, 0),
	["orange"] = Color(255, 165, 0),
	["white"] = Color(255, 255, 255),
	["black"] = Color(0, 0, 0),
	["cyan"] = Color(0, 250, 250),
	["pink"] = Color(255, 105, 180),
	["yellow"] = Color(255, 255, 0),
}

LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES = {
    {
        { color = "blue", path = "evo/face/eyes/semireal/pupil_semireal_000" },
        { color = "cyan", path = "evo/face/eyes/semireal/pupil_semireal_007" },
        { color = "green", path = "evo/face/eyes/semireal/pupil_semireal_001" },
        { color = "yellow", path = "evo/face/eyes/semireal/pupil_semireal_008" },
        { color = "orange", path = "evo/face/eyes/semireal/pupil_semireal_002" },
        { color = "red", path = "evo/face/eyes/semireal/pupil_semireal_004" },
        { color = "pink", path = "evo/face/eyes/semireal/pupil_semireal_005" },
        { color = "purple", path = "evo/face/eyes/semireal/pupil_semireal_006" },
        { color = "white", path = "evo/face/eyes/semireal/pupil_semireal_003" },
    },
    {
        { color = "blue", path = "evo/face/eyes/manga/pupil_manga_000" },
        { color = "cyan", path = "evo/face/eyes/manga/pupil_manga_002" },
        { color = "green", path = "evo/face/eyes/manga/pupil_manga_003" },
        { color = "orange", path = "evo/face/eyes/manga/pupil_manga_004" },
        { color = "red", path = "evo/face/eyes/manga/pupil_manga_005" },
        { color = "pink", path = "evo/face/eyes/manga/pupil_manga_006" },
        { color = "purple", path = "evo/face/eyes/manga/pupil_manga_001" },
        { color = "white", path = "evo/face/eyes/manga/pupil_manga_007" },
    },
    {
        { color = "blue", path = "evo/face/eyes/gojo/pupil_gojo_000" },
        { color = "green", path = "evo/face/eyes/gojo/pupil_gojo_001" },
        { color = "yellow", path = "evo/face/eyes/gojo/pupil_gojo_002" },
        { color = "red", path = "evo/face/eyes/gojo/pupil_gojo_003" },
        { color = "purple", path = "evo/face/eyes/gojo/pupil_gojo_004" },
        { color = "white", path = "evo/face/eyes/gojo/pupil_gojo_005" },
    },
    {
        { color = "blue", path = "evo/face/eyes/blind/pupil_blind_000" },
        { color = "cyan", path = "evo/face/eyes/blind/pupil_blind_001" },
        { color = "green", path = "evo/face/eyes/blind/pupil_blind_002" },
        { color = "yellow", path = "evo/face/eyes/blind/pupil_blind_003" },
        { color = "orange", path = "evo/face/eyes/blind/pupil_blind_004" },
        { color = "red", path = "evo/face/eyes/blind/pupil_blind_005" },
        { color = "pink", path = "evo/face/eyes/blind/pupil_blind_006" },
        { color = "purple", path = "evo/face/eyes/blind/pupil_blind_007" },
        { color = "white", path = "evo/face/eyes/blind/pupil_blind_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/bluelock/pupil_bluelock_000" },
        { color = "cyan", path = "evo/face/eyes/bluelock/pupil_bluelock_002" },
        { color = "green", path = "evo/face/eyes/bluelock/pupil_bluelock_003" },
        { color = "yellow", path = "evo/face/eyes/bluelock/pupil_bluelock_004" },
        { color = "red", path = "evo/face/eyes/bluelock/pupil_bluelock_005" },
        { color = "purple", path = "evo/face/eyes/bluelock/pupil_bluelock_006" },
        { color = "white", path = "evo/face/eyes/bluelock/pupil_bluelock_001" },
    },
    {
        { color = "blue", path = "evo/face/eyes/butterfly/pupil_butterfly_000" },
        { color = "cyan", path = "evo/face/eyes/butterfly/pupil_butterfly_003" },
        { color = "green", path = "evo/face/eyes/butterfly/pupil_butterfly_002" },
        { color = "yellow", path = "evo/face/eyes/butterfly/pupil_butterfly_001" },
        { color = "orange", path = "evo/face/eyes/butterfly/pupil_butterfly_007" },
        { color = "red", path = "evo/face/eyes/butterfly/pupil_butterfly_006" },
        { color = "pink", path = "evo/face/eyes/butterfly/pupil_butterfly_005" },
        { color = "purple", path = "evo/face/eyes/butterfly/pupil_butterfly_004" },
        { color = "white", path = "evo/face/eyes/butterfly/pupil_butterfly_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/gorou/pupil_gorou_000" },
        { color = "cyan", path = "evo/face/eyes/gorou/pupil_gorou_001" },
        { color = "green", path = "evo/face/eyes/gorou/pupil_gorou_002" },
        { color = "yellow", path = "evo/face/eyes/gorou/pupil_gorou_003" },
        { color = "orange", path = "evo/face/eyes/gorou/pupil_gorou_004" },
        { color = "red", path = "evo/face/eyes/gorou/pupil_gorou_005" },
        { color = "pink", path = "evo/face/eyes/gorou/pupil_gorou_006" },
        { color = "purple", path = "evo/face/eyes/gorou/pupil_gorou_008" },
        { color = "white", path = "evo/face/eyes/gorou/pupil_gorou_007" },
    },
    {
        { color = "blue", path = "evo/face/eyes/maka/pupil_maka_000" },
        { color = "cyan", path = "evo/face/eyes/maka/pupil_maka_006" },
        { color = "green", path = "evo/face/eyes/maka/pupil_maka_007" },
        { color = "yellow", path = "evo/face/eyes/maka/pupil_maka_001" },
        { color = "orange", path = "evo/face/eyes/maka/pupil_maka_002" },
        { color = "red", path = "evo/face/eyes/maka/pupil_maka_003" },
        { color = "pink", path = "evo/face/eyes/maka/pupil_maka_004" },
        { color = "purple", path = "evo/face/eyes/maka/pupil_maka_005" },
        { color = "white", path = "evo/face/eyes/maka/pupil_maka_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/vampire/pupil_vampire_000" },
        { color = "cyan", path = "evo/face/eyes/vampire/pupil_vampire_004" },
        { color = "green", path = "evo/face/eyes/vampire/pupil_vampire_005" },
        { color = "yellow", path = "evo/face/eyes/vampire/pupil_vampire_006" },
        { color = "orange", path = "evo/face/eyes/vampire/pupil_vampire_007" },
        { color = "red", path = "evo/face/eyes/vampire/pupil_vampire_001" },
        { color = "pink", path = "evo/face/eyes/vampire/pupil_vampire_002" },
        { color = "purple", path = "evo/face/eyes/vampire/pupil_vampire_003" },
        { color = "white", path = "evo/face/eyes/vampire/pupil_vampire_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/berryfish/pupil_berryfish_000" },
        { color = "cyan", path = "evo/face/eyes/berryfish/pupil_berryfish_002" },
        { color = "green", path = "evo/face/eyes/berryfish/pupil_berryfish_003" },
        { color = "yellow", path = "evo/face/eyes/berryfish/pupil_berryfish_004" },
        { color = "orange", path = "evo/face/eyes/berryfish/pupil_berryfish_005" },
        { color = "red", path = "evo/face/eyes/berryfish/pupil_berryfish_006" },
        { color = "purple", path = "evo/face/eyes/berryfish/pupil_berryfish_001" },
        { color = "white", path = "evo/face/eyes/berryfish/pupil_berryfish_007" },
    },
    {
           { color = "blue", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_000" },
           { color = "cyan", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_004" },
           { color = "green", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_005" },
           { color = "yellow", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_006" },
           { color = "orange", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_007" },
           { color = "red", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_003" },
           { color = "pink", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_001" },
           { color = "purple", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_002" },
           { color = "white", path = "evo/face/eyes/ladyreboot/pupil_ladyreboot_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/chainsawman/pupil_chainsawman_000" },
        { color = "cyan", path = "evo/face/eyes/chainsawman/pupil_chainsawman_001" },
        { color = "green", path = "evo/face/eyes/chainsawman/pupil_chainsawman_002" },
        { color = "yellow", path = "evo/face/eyes/chainsawman/pupil_chainsawman_003" },
        { color = "orange", path = "evo/face/eyes/chainsawman/pupil_chainsawman_007" },
        { color = "pink", path = "evo/face/eyes/chainsawman/pupil_chainsawman_004" },
        { color = "purple", path = "evo/face/eyes/chainsawman/pupil_chainsawman_006" },
        { color = "white", path = "evo/face/eyes/chainsawman/pupil_chainsawman_005" },
    },
    {
        { color = "blue", path = "evo/face/eyes/fireforce/pupil_fireforce_000" },
        { color = "cyan", path = "evo/face/eyes/fireforce/pupil_fireforce_004" },
        { color = "green", path = "evo/face/eyes/fireforce/pupil_fireforce_005" },
        { color = "yellow", path = "evo/face/eyes/fireforce/pupil_fireforce_006" },
        { color = "orange", path = "evo/face/eyes/fireforce/pupil_fireforce_007" },
        { color = "red", path = "evo/face/eyes/fireforce/pupil_fireforce_001" },
        { color = "pink", path = "evo/face/eyes/fireforce/pupil_fireforce_002" },
        { color = "purple", path = "evo/face/eyes/fireforce/pupil_fireforce_003" },
        { color = "white", path = "evo/face/eyes/fireforce/pupil_fireforce_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/yugioh/pupil_yugioh_000" },
        { color = "cyan", path = "evo/face/eyes/yugioh/pupil_yugioh_004" },
        { color = "green", path = "evo/face/eyes/yugioh/pupil_yugioh_005" },
        { color = "yellow", path = "evo/face/eyes/yugioh/pupil_yugioh_006" },
        { color = "orange", path = "evo/face/eyes/yugioh/pupil_yugioh_007" },
        { color = "red", path = "evo/face/eyes/yugioh/pupil_yugioh_008" },
        { color = "pink", path = "evo/face/eyes/yugioh/pupil_yugioh_001" },
        { color = "purple", path = "evo/face/eyes/yugioh/pupil_yugioh_002" },
        { color = "white", path = "evo/face/eyes/yugioh/pupil_yugioh_003" },
    },
    {
        { color = "blue", path = "evo/face/eyes/danganronpa/pupil_danganronpa_000" },
        { color = "cyan", path = "evo/face/eyes/danganronpa/pupil_danganronpa_001" },
        { color = "green", path = "evo/face/eyes/danganronpa/pupil_danganronpa_002" },
        { color = "yellow", path = "evo/face/eyes/danganronpa/pupil_danganronpa_003" },
        { color = "orange", path = "evo/face/eyes/danganronpa/pupil_danganronpa_004" },
        { color = "red", path = "evo/face/eyes/danganronpa/pupil_danganronpa_005" },
        { color = "pink", path = "evo/face/eyes/danganronpa/pupil_danganronpa_006" },
        { color = "purple", path = "evo/face/eyes/danganronpa/pupil_danganronpa_007" },
        { color = "white", path = "evo/face/eyes/danganronpa/pupil_danganronpa_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/galaxy/pupil_galaxy_000" },
        { color = "cyan", path = "evo/face/eyes/galaxy/pupil_galaxy_001" },
        { color = "green", path = "evo/face/eyes/galaxy/pupil_galaxy_002" },
        { color = "yellow", path = "evo/face/eyes/galaxy/pupil_galaxy_003" },
        { color = "orange", path = "evo/face/eyes/galaxy/pupil_galaxy_004" },
        { color = "red", path = "evo/face/eyes/galaxy/pupil_galaxy_005" },
        { color = "pink", path = "evo/face/eyes/galaxy/pupil_galaxy_006" },
        { color = "purple", path = "evo/face/eyes/galaxy/pupil_galaxy_007" },
        { color = "white", path = "evo/face/eyes/galaxy/pupil_galaxy_008" },
    },
    {
        { color = "blue", path = "evo/face/eyes/joker/pupil_joker_000" },
        { color = "cyan", path = "evo/face/eyes/joker/pupil_joker_005" },
        { color = "green", path = "evo/face/eyes/joker/pupil_joker_006" },
        { color = "orange", path = "evo/face/eyes/joker/pupil_joker_001" },
        { color = "red", path = "evo/face/eyes/joker/pupil_joker_002" },
        { color = "pink", path = "evo/face/eyes/joker/pupil_joker_003" },
        { color = "purple", path = "evo/face/eyes/joker/pupil_joker_004" },
        { color = "white", path = "evo/face/eyes/joker/pupil_joker_007" },
    },
    {
        { color = "blue", path = "evo/face/eyes/alastor/pupil_alastor_000" },
        { color = "cyan", path = "evo/face/eyes/alastor/pupil_alastor_003" },
        { color = "green", path = "evo/face/eyes/alastor/pupil_alastor_004" },
        { color = "yellow", path = "evo/face/eyes/alastor/pupil_alastor_005" },
        { color = "orange", path = "evo/face/eyes/alastor/pupil_alastor_006" },
        { color = "red", path = "evo/face/eyes/alastor/pupil_alastor_007" },
        { color = "purple", path = "evo/face/eyes/alastor/pupil_alastor_001" },
        { color = "white", path = "evo/face/eyes/alastor/pupil_alastor_002" },
    },
    {
        { color = "blue", path = "evo/face/eyes/villainsister/pupil_villainsister_000" },
        { color = "green", path = "evo/face/eyes/villainsister/pupil_villainsister_002" },
        { color = "yellow", path = "evo/face/eyes/villainsister/pupil_villainsister_003" },
        { color = "orange", path = "evo/face/eyes/villainsister/pupil_villainsister_004" },
        { color = "pink", path = "evo/face/eyes/villainsister/pupil_villainsister_005" },
        { color = "purple", path = "evo/face/eyes/villainsister/pupil_villainsister_006" },
        { color = "white", path = "evo/face/eyes/villainsister/pupil_villainsister_007" },
        { color = "black", path = "evo/face/eyes/villainsister/pupil_villainsister_001" },
    },
    {
        { color = "blue", path = "evo/face/eyes/cherribomb/pupil_cherribomb_000" },
        { color = "cyan", path = "evo/face/eyes/cherribomb/pupil_cherribomb_003" },
        { color = "green", path = "evo/face/eyes/cherribomb/pupil_cherribomb_007" },
        { color = "yellow", path = "evo/face/eyes/cherribomb/pupil_cherribomb_004" },
        { color = "red", path = "evo/face/eyes/cherribomb/pupil_cherribomb_001" },
        { color = "pink", path = "evo/face/eyes/cherribomb/pupil_cherribomb_002" },
        { color = "purple", path = "evo/face/eyes/cherribomb/pupil_cherribomb_006" },
        { color = "white", path = "evo/face/eyes/cherribomb/pupil_cherribomb_005" },
    },
}

-- Same list for all genders; keep legacy keys as aliases (same table reference).
LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES_MALE = LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES
LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES_FEMALE = LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES

LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE = {
    ["Shinigami"] = "models/evo/characters/shinigami/male/evo_yyjejrymar3ma/evo_7ef88q5bfk3wr1vg1.mdl",
    ["Hollow"] = "models/evo/characters/arrancar/male/evo_b3xr7ovm2oob1ef6e/evo_4916psnf6mgwm.mdl",
}

-- Variantes de la tenue de base (academy) Shinigami HOMME : tiree AU HASARD a la creation
-- (sv_main:CreateCharacter) pour varier les nouveaux persos. La 1re = DEFAULT_BODY_MODEL_MALE
-- .Shinigami (= apercu du createur). Toutes ajoutees au set valide en sanitisation.
LZY_CHARACTER_CONFIG.SHINIGAMI_ACADEMY_BASE_MODELS = {
    "models/evo/characters/shinigami/male/evo_yyjejrymar3ma/evo_7ef88q5bfk3wr1vg1.mdl",
    "models/evo/characters/shinigami/male/evo_ngj0h7f6jfvvd2i/evo_y9slfotok57b.mdl",
    "models/evo/characters/shinigami/male/evo_a0866efapg51vveqb/evo_2lti9ypsiy653yy.mdl",
}
-- Variantes academy FEMME (transfert user 2026-07-10) : même principe que les hommes.
-- La 1re = DEFAULT_BODY_MODEL_FEMALE.Shinigami (= aperçu du créateur), la 2e = nouvelle tenue.
LZY_CHARACTER_CONFIG.SHINIGAMI_ACADEMY_BASE_MODELS_FEMALE = {
    "models/evo/characters/shinigami/female/evo_f4kq399g1dcdnc/evo_3p3uuy49h3ho.mdl",
    "models/evo/characters/shinigami/female/evo_951uhvbfgyhbucfgyvfed/evo_951UHVBFGYhbucfgyvFEd.mdl",
}
LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_FEMALE = {
    ["Shinigami"] = "models/evo/characters/shinigami/female/evo_f4kq399g1dcdnc/evo_3p3uuy49h3ho.mdl",
    ["Hollow"] = "models/evo/characters/arrancar/female/evo_pvg59ubjcjt5i5v7j/evo_eiosl74snv8xpz.mdl",
}

-- ════════════════════════════════════════════════════════════════════════════════════
-- UNIFORMES PAR GRADE / DIVISION (tenue de base auto selon le rang)
-- Le modèle de CORPS du composite devient cet uniforme = la "tenue de base" du joueur QUAND
-- aucune tenue d'inventaire n'est équipée (body_model == base_body_model). Purement VISUEL
-- (clientside) : promotion / rétrogradation / changement de division / sortie de faction
-- l'appliquent ou le retirent automatiquement (rebuild du composite sur changement de NWVar).
--
-- Structure : RANK_OUTFITS[faction] = {
--   grades    = { [grade] = { m = <model|liste>, f = <model|liste> } },     -- toute division
--   divisions = { [libellé] = { [grade] = { m = ..., f = ... } } },         -- PRIORITAIRE sur grades
-- }
-- <model> = string fixe OU liste de strings (tirage déterministe STABLE par perso via unique_id).
-- ⚠️ Le libellé de division vient de LZY_FACTION_CONFIG.divisions :
--    "Division 2" (assassin / 2e division) = FactionDivision INDEX 3 (l'index 2 = "Division 1").
LZY_CHARACTER_CONFIG.RANK_OUTFITS = {
    ["Shinigami"] = {
        grades = {
            -- Grade 2 = "Shinigami" : tenue de base standard (toute division).
            [2] = {
                m = "models/evo/characters/shinigami/male/evo_ahs3t42aet16yyuy4/evo_et09u5e24jmxvdo98.mdl",
                -- Femmes : tirage stable entre 2 tenues (réparti ~50/50, fixe par perso).
                f = {
                    "models/evo/characters/shinigami/female/evo_hv192cuz9jauqlj/evo_5en23p0p6ms18xb.mdl",
                    "models/evo/characters/shinigami/female/evo_jsypfd09tj73b/evo_c5yvg6qqlcldvywdd.mdl",
                },
            },
        },
        -- Les CAPITAINES (grade 15+) n'ont plus d'uniforme de CORPS ici (26/07, demande user,
        -- exactement le même traitement que les Espadas) : ils gardent la tenue de base
        -- Shinigami, et leur haori est un ACCESSOIRE bonemergé PAR-DESSUS — cf.
        -- LZY_CHARACTER_CONFIG.CAPTAIN_HAORI.
        -- Pourquoi : un uniforme de corps REMPLACE le modèle, donc un capitaine qui achetait
        -- une tenue en boutique perdait son haori, ou gardait son uniforme et voyait son achat
        -- ignoré. En accessoire, les deux coexistent.
    },
    -- ARRANCAR (faction Hollow) : les ESPADAS (capitaines, grades 15 & 16) reprennent la TENUE DE
    -- BASE Arrancar (demande user 07/26) — plus d'uniforme de corps ici. À la place, un accessoire
    -- body bonemergé PAR-DESSUS la tenue de base, skin selon l'Ordre : cf. LZY_CHARACTER_CONFIG.ESPADA_BODY.
    -- Les espadas retombent donc sur le [2] ci-dessous (= la tenue de base), inchangé.
    ["Hollow"] = {
        grades = {
            -- Grade 1 = tenue academy : celle du spawn, AVANT la 1re WL. Sert à distinguer
            -- un arrivant d'un arrancar déjà formé (demande user).
            [1] = {
                m = "models/evo/characters/arrancar/male/evo_repstrnf6re5yht5wm/evo_repstrnf6RE5yht5wm.mdl",
                f = "models/evo/characters/arrancar/female/evo_zef5yjl74sntrxpz/evo_zef5YJl74snTRxpz.mdl",
            },
            -- Grade 2+ = tenue de base Arrancar, celle portée aujourd'hui. Ce sont les mêmes
            -- modèles que DEFAULT_BODY_MODEL_*.Hollow : à partir du grade 2 le rendu est
            -- donc STRICTEMENT identique à avant, seul le grade 1 change.
            [2] = {
                m = "models/evo/characters/arrancar/male/evo_b3xr7ovm2oob1ef6e/evo_4916psnf6mgwm.mdl",
                f = "models/evo/characters/arrancar/female/evo_pvg59ubjcjt5i5v7j/evo_eiosl74snv8xpz.mdl",
            },
        },
    },
}

-- Tirage déterministe STABLE par perso (même seed -> même choix ; réparti entre les entrées).
-- Garde les nombres bornés (pas d'opérateur bitwise : LuaJIT 5.1).
local function LZY_RankOutfit_PickStable(modelOrList, seed)
    if not istable(modelOrList) then return modelOrList end
    local n = #modelOrList
    if n == 0 then return nil end
    if n == 1 then return modelOrList[1] end
    seed = tostring(seed or "")
    local h = 0
    for i = 1, #seed do
        h = (h * 31 + string.byte(seed, i)) % 1000003
    end
    return modelOrList[(h % n) + 1]
end

-- Cherche le modèle applicable dans une table { [grade] = {m=,f=} } : le PLUS HAUT grade défini
-- <= rank du joueur qui possède un modèle pour son genre. Sémantique "À PARTIR DE" : ex. grade 2 =
-- tenue de base dès le grade 2 ; définir un grade plus haut l'écrase à partir de ce grade-là.
local function LZY_RankOutfit_FloorModel(gradeTbl, rank, gender)
    if not istable(gradeTbl) then return nil end
    local best, bestG = nil, -1
    for g, entry in pairs(gradeTbl) do
        g = tonumber(g)
        if g and rank and g <= rank and g > bestG and istable(entry) then
            local m = entry[gender] or entry.all
            if m ~= nil then bestG, best = g, m end
        end
    end
    return best
end

-- Renvoie le modèle d'uniforme (corps) pour ce joueur, ou nil si aucun. divisionIndex =
-- FactionDivision (NWInt). seed = unique_id du perso (tirage stable des listes). La table de
-- DIVISION est PRIORITAIRE sur la générique ; dans chaque table, plus haut grade défini <= rank.
function LZY_CHARACTER_CONFIG.GetRankOutfitModel(faction, divisionIndex, rank, gender, seed)
    local fac = istable(LZY_CHARACTER_CONFIG.RANK_OUTFITS) and LZY_CHARACTER_CONFIG.RANK_OUTFITS[faction]
    if not istable(fac) then return nil end
    rank = tonumber(rank)
    gender = (gender == "f" or gender == "female") and "f" or "m"

    -- 1) Spécifique division (prioritaire). Résout l'index -> libellé via la config faction.
    if istable(fac.divisions) and LZY_FACTION_CONFIG and istable(LZY_FACTION_CONFIG.divisions) then
        local dlist = LZY_FACTION_CONFIG.divisions[faction]
        local label = istable(dlist) and dlist[tonumber(divisionIndex)] or nil
        local m = label and LZY_RankOutfit_FloorModel(fac.divisions[label], rank, gender)
        if m ~= nil then return LZY_RankOutfit_PickStable(m, seed) end
    end

    -- 2) Générique par grade (toute division).
    local m = LZY_RankOutfit_FloorModel(fac.grades, rank, gender)
    if m ~= nil then return LZY_RankOutfit_PickStable(m, seed) end
    return nil
end

-- ══════════════════════════════════════════════════════════════════════════════
-- ÉPAULETTES DE GRADE : accessoire "body" BONEMERGÉ, UNE PAR GRADE ET PAR FACTION depuis le
-- 09/28 (user : nouveau pack « distinctions_grades », grades 5 à 16). Division ignorée.
-- Rendu par les 3 chemins (monde cl_models, aperçus VGUI, scène char-select) via
-- GetRankEpauletteModel ; suit la promotion (hook LZY:Character:RankOutfitRefresh).
-- Grades 1-4 et 16 : aucune épaulette. Grade 15 : elle s'ajoute au haori / corps d'Espada.
-- ⚠️ Table indexée par NUMÉRO de grade : si lzy_faction/config.lua est réordonnée, revenir ici.
-- 10/02 (user) : décalées d'UN grade vers le bas. L'épaulette 05 n'est plus portée, le grade N
-- porte le modèle N+1 (5 -> 06 ... 15 -> 16) et le grade 16 n'en a plus.
LZY_CHARACTER_CONFIG.RANK_EPAULETTES = {
    ["Shinigami"] = {
        [5] = "models/evo/accessories/body/distinctions_grades/shini_grade_06/shini_grade_06.mdl",
        [6] = "models/evo/accessories/body/distinctions_grades/shini_grade_07/shini_grade_07.mdl",
        [7] = "models/evo/accessories/body/distinctions_grades/shini_grade_08/shini_grade_08.mdl",
        [8] = "models/evo/accessories/body/distinctions_grades/shini_grade_09/shini_grade_09.mdl",
        [9] = "models/evo/accessories/body/distinctions_grades/shini_grade_10/shini_grade_10.mdl",
        [10] = "models/evo/accessories/body/distinctions_grades/shini_grade_11/shini_grade_11.mdl",
        [11] = "models/evo/accessories/body/distinctions_grades/shini_grade_12/shini_grade_12.mdl",
        [12] = "models/evo/accessories/body/distinctions_grades/shini_grade_13/shini_grade_13.mdl",
        [13] = "models/evo/accessories/body/distinctions_grades/shini_grade_14/shini_grade_14.mdl",
        [14] = "models/evo/accessories/body/distinctions_grades/shini_grade_15/shini_grade_15.mdl",
        [15] = "models/evo/accessories/body/distinctions_grades/shini_grade_16/shini_grade_16.mdl",
    },
    ["Hollow"] = {
        [5] = "models/evo/accessories/body/distinctions_grades/arr_grade_06/arr_grade_06.mdl",
        [6] = "models/evo/accessories/body/distinctions_grades/arr_grade_07/arr_grade_07.mdl",
        [7] = "models/evo/accessories/body/distinctions_grades/arr_grade_08/arr_grade_08.mdl",
        [8] = "models/evo/accessories/body/distinctions_grades/arr_grade_09/arr_grade_09.mdl",
        [9] = "models/evo/accessories/body/distinctions_grades/arr_grade_10/arr_grade_10.mdl",
        [10] = "models/evo/accessories/body/distinctions_grades/arr_grade_11/arr_grade_11.mdl",
        [11] = "models/evo/accessories/body/distinctions_grades/arr_grade_12/arr_grade_12.mdl",
        [12] = "models/evo/accessories/body/distinctions_grades/arr_grade_13/arr_grade_13.mdl",
        [13] = "models/evo/accessories/body/distinctions_grades/arr_grade_14/arr_grade_14.mdl",
        [14] = "models/evo/accessories/body/distinctions_grades/arr_grade_15/arr_grade_15.mdl",
        [15] = "models/evo/accessories/body/distinctions_grades/arr_grade_16/arr_grade_16.mdl",
    },
}

-- Modèle d'épaulette pour ce grade (par FACTION ; division ignorée).
-- nil = aucune épaulette (grade 1-4 ou 16, faction inconnue, ou pas de modèle configuré).
function LZY_CHARACTER_CONFIG.GetRankEpauletteModel(faction, rank)
    local fac = istable(LZY_CHARACTER_CONFIG.RANK_EPAULETTES) and LZY_CHARACTER_CONFIG.RANK_EPAULETTES[faction]
    if not istable(fac) then return nil end
    local mdl = fac[tonumber(rank) or 0]
    return (isstring(mdl) and mdl ~= "") and mdl or nil
end

-- Épaulette masquée ? Préférence PAR PERSO (coche inventaire). characterData GAGNE (synced serveur,
-- juste = pour le perso affiché dans le char-select) ; NWBool EVO_HideEpaulette en secours (perso chargé).
-- Miroir exact de CharacterHasHideHair.
function LZY_CHARACTER_CONFIG.CharacterHasHideEpaulette(characterData, nwPlayer)
    if characterData and characterData.hide_epaulette ~= nil then
        local h = characterData.hide_epaulette
        return (h == 1 or h == true or tostring(h) == "1")
    end
    if nwPlayer and IsValid(nwPlayer) and nwPlayer:IsPlayer() then
        return nwPlayer:GetEvoNWBool("EVO_HideEpaulette", false)
    end
    return false
end

-- Épaulette résolue pour les APERÇUS (HUD/inventaire/char-select) : nil si masquée OU grade sans épaulette.
-- faction + rank lus depuis characterData ; le MONDE, lui, lit les NWVars live dans EnsureDetailParts.
function LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter(characterData, nwPlayer)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasHideEpaulette(characterData, nwPlayer) then return nil end
    return LZY_CHARACTER_CONFIG.GetRankEpauletteModel(characterData.faction, characterData.rank)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- BRASSARD DE VICE-CAPITAINE (2026-07-22, demande user) — accessoire body bonemergé porté par les
-- VICE-CAPITAINES Shinigami (grade 14) ; le SKIN dépend de la DIVISION. Le .mdl a un
-- $texturegroup "skinfamilies" : skin 0=div1, 1=div2, 2=div4, 3=div11, 4=div12. Slot "brassard"
-- (≠ épaulette slot "grade" -> les deux coexistent). Suit promotion/division via RankOutfitRefresh.
-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte) — cf. RANK_EPAULETTES.
LZY_CHARACTER_CONFIG.VICE_CAPTAIN_BRASSARD = {
    model = "models/evo/accessories/body/evo_bts414f1fsfbeffa52/evo_BTs414f1fsFBeffa52.mdl",
    skinByDivNum = { [1] = 0, [2] = 1, [4] = 2, [11] = 3, [12] = 4 }, -- numéro de division -> skin
}

-- Brassard (modèle, skin) pour ce vice-capitaine, ou nil. divisionIndex = NWInt/colonne FactionDivision
-- (index 1..N) ; on résout le NUMÉRO via le nom « Division X » (robuste : l'ordre des index ne suit
-- PAS les numéros — index 4=« Division 12 », 5=« Division 4 »...). Renvoie (model, skin) ou nil.
function LZY_CHARACTER_CONFIG.GetRankBrassard(faction, rank, divisionIndex)
    if faction ~= "Shinigami" or tonumber(rank) ~= 14 then return nil end -- grade 14 = Vice capitaine
    local cfg = LZY_CHARACTER_CONFIG.VICE_CAPTAIN_BRASSARD
    if not istable(cfg) then return nil end
    local num
    if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName then
        local nm = LZY_FACTION_CONFIG.DivisionName(faction, tonumber(divisionIndex))
        num = nm and tonumber(string.match(tostring(nm), "(%d+)"))
    end
    local skin = num and cfg.skinByDivNum[num]
    if skin == nil then return nil end
    return cfg.model, skin
end

-- Brassard résolu pour les APERÇUS (faction/rank/division depuis characterData). Renvoie (model, skin) ou nil.
function LZY_CHARACTER_CONFIG.GetBrassardForCharacter(characterData)
    if not characterData then return nil end
    return LZY_CHARACTER_CONFIG.GetRankBrassard(characterData.faction, characterData.rank, characterData.division)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- ACCESSOIRE BODY DE DIVISION (2026-08\15, demande user) — même principe que le
-- haori de capitaine, mais porté par TOUS les membres d'une division/ordre dès
-- leur arrivée dedans. Accessoire bonemergé PAR-DESSUS la tenue : il coexiste
-- avec une tenue achetée en boutique, contrairement à un uniforme de corps.
--
-- ⚠️ Indexé par la SPÉCIALITÉ et non par le numéro de division. « Scientifique »
-- est la Division 12 chez les Shinigami mais l'Ordre 3 chez les Hollow : passer
-- par le numéro (recette du haori) imposerait deux tables croisées à maintenir en
-- parallèle. LZY_FACTION_CONFIG.DivisionSpecialty est la SOURCE UNIQUE index ->
-- rôle, partagée par les deux factions.
-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte).
LZY_CHARACTER_CONFIG.DIVISION_BODY = {
    ["Commandement"] = {
        Shinigami = "models/evo/accessories/body/evo_zdey9ref523z8zedfefdez/evo_zdey9ref523z8zedfEFdez.mdl",
        Hollow    = "models/evo/accessories/body/evo_svef523z8xb527zedfeffh/evo_svef523z8xb527zedfEFfh.mdl",
    },
    ["Assassin"] = {
        Shinigami = "models/evo/accessories/body/evo_xpamgr6gr3zygrcao/evo_XPamgr6GR3zygrcao.mdl",
        Hollow    = "models/evo/accessories/body/evo_zdfdgrfr345rcef/evo_zdfdgrfR345rcef.mdl",
    },
    ["Scientifique"] = {
        Shinigami = "models/evo/accessories/body/evo_zeferfegr3z85dfefdfer/evo_zeferFEGR3z85dfEFdfer.mdl",
        Hollow    = "models/evo/accessories/body/evo_oplikujyhttg368juy/evo_oplikujyhtTG368juy.mdl",
    },
    -- Combat : un SEUL modèle pour les deux factions (demande user).
    ["Combat"] = {
        Shinigami = "models/evo/accessories/body/evo_zdegr6g52hnbvgrgvf/evo_zdegr6G52hnbvGRGVF.mdl",
        Hollow    = "models/evo/accessories/body/evo_zdegr6g52hnbvgrgvf/evo_zdegr6G52hnbvGRGVF.mdl",
    },
    -- Médecin : sac de médecin. ⚠️ Le modèle Shinigami est CELUI de l'item
    -- sac_division_4 (inventory), distribué à la main jusqu'ici : un membre qui
    -- garde l'item équipé portera DEUX sacs superposés.
    ["Médecin"] = {
        Shinigami = "models/evo/accessories/body/evo_sjp4twaalatsdzlev/evo_9fll4f1uyp2trha.mdl",
        Hollow    = "models/evo/accessories/body/evo_zdefedzyp524tdez/evo_zdefedzyp524tdez.mdl",
    },
}

--- Accessoire body de division pour ce joueur, ou nil. La seule condition est
--- d'ÊTRE dans une division : l'index 1 (« Aucune ») n'a pas de spécialité, donc
--- il retombe naturellement sur nil, sans seuil de grade à maintenir.
function LZY_CHARACTER_CONFIG.GetRankDivisionBody(faction, rank, divisionIndex)
    if faction ~= "Shinigami" and faction ~= "Hollow" then return nil end
    local spec = (LZY_FACTION_CONFIG and istable(LZY_FACTION_CONFIG.DivisionSpecialty))
        and LZY_FACTION_CONFIG.DivisionSpecialty[tonumber(divisionIndex)] or nil
    if not spec then return nil end
    local entry = istable(LZY_CHARACTER_CONFIG.DIVISION_BODY) and LZY_CHARACTER_CONFIG.DIVISION_BODY[spec]
    local mdl = istable(entry) and entry[faction] or nil
    return (isstring(mdl) and mdl ~= "") and mdl or nil
end

--- Accessoire de division masqué ? Drapeau DÉDIÉ, séparé de « Cacher la tenue de
--- grade » : partager EVO_HideRankOutfit faisait qu'une seule coche cachait à la
--- fois l'accessoire de division ET le haori/uniforme (report user 08\16).
--- ⚠️ PAS de NWBool : le drapeau vit dans characterData (colonne
--- characters.hide_division_body, répliquée par le payload modèle), comme
--- masque_base_offset. Ça évite de toucher au SCHÉMA NW (bump VERSION risqué
--- entre branches divergentes) et chaque toggle re-pousse la data de toute façon.
function LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(characterData)
    if not istable(characterData) then return false end
    local h = characterData.hide_division_body
    return (h == 1 or h == true or tostring(h) == "1")
end

--- Résolu pour les APERÇUS (créateur / sélection de perso) ET le monde.
function LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter(characterData)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(characterData) then return nil end
    return LZY_CHARACTER_CONFIG.GetRankDivisionBody(characterData.faction, characterData.rank, characterData.division)
end

--- Ce perso porte-t-il un accessoire de division masquable ? Visibilité de la
--- coche dédiée (miroir de HasRankOutfit pour la coche de grade).
function LZY_CHARACTER_CONFIG.HasDivisionBody(faction, rank, divisionIndex)
    local db = LZY_CHARACTER_CONFIG.GetRankDivisionBody
        and LZY_CHARACTER_CONFIG.GetRankDivisionBody(faction, rank, divisionIndex)
    return isstring(db) and db ~= ""
end


-- ══════════════════════════════════════════════════════════════════════════════
-- ACCESSOIRE ESPADA (2026-07-26, demande user) — accessoire body bonemergé porté par les ESPADAS =
-- capitaines Arrancar (faction Hollow) du GRADE 15. Ils reprennent la TENUE DE BASE Arrancar
-- (l'ancien uniforme capitaine Hollow a été retiré de RANK_OUTFITS) + ce corps bonemergé PAR-DESSUS.
-- ⚠️ PLUS LE GRADE 16 depuis le 2026-09-18 : le Roi du Hueco Mundo porte SA cape À LA PLACE
-- (HOLLOW_KING_CAPE), pas par-dessus. Une surcharge !espadatenue ne le concerne donc plus.
-- Le SKIN dépend de l'ORDRE (= division Hollow) ; la correspondance n'est PAS
-- séquentielle, elle est donnée par skinByOrdreNum juste en dessous. Slot "espada" (≠ "grade"/
-- "brassard" -> les trois coexistent). Suit promotion/changement d'ordre via RankOutfitRefresh.
-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte) — cf. RANK_EPAULETTES.
LZY_CHARACTER_CONFIG.ESPADA_BODY = {
    model = "models/evo/accessories/body/evo_52tgrdv5542frfyudfezer/evo_52tgrDV5542frFYUdfezer.mdl",
    -- numero d'Ordre -> skin de la tenue. Correspondance REVUE le 22/09/2026 (demande
    -- user : « c'est ca les bons Ordres maintenant »). La tenue « Espada N » est le skin
    -- N-1 du .mdl (5 tenues = skins 0..4, cf. !espadatenue qui les appelle « tenue 0-4 ») :
    --     Ordre 1 (Commandement)  -> Espada 1 (skin 0)
    --     Ordre 2 (Medicale)      -> Espada 4 (skin 3)
    --     Ordre 3 (Combat)        -> Espada 2 (skin 1)
    --     Ordre 4 (Scientifique)  -> Espada 5 (skin 4)
    --     Ordre 5 (Assassinat)    -> Espada 3 (skin 2)
    -- Ne pas « remettre dans l'ordre » en croyant corriger une faute de frappe : les
    -- tenues du .mdl ne sont pas rangees dans l'ordre des Ordres, c'est voulu.
    -- Chaque tenue porte un NOM (16/09/2026, demande user) : c'est le métier qu'elle
    -- habille, pas le numéro d'Ordre qui la porte. Les noms servent au staff
    -- (!espadatenue les affiche et les accepte en argument) ; le jeu, lui, ne
    -- travaille QUE sur les numéros de skin, donc renommer ici n'habille personne
    -- autrement. Avec la table ci-dessous : Ordre 1 -> Commandement, Ordre 2 ->
    -- Medicale, Ordre 3 -> Combat, Ordre 4 -> Scientifique, Ordre 5 -> Assassinat.
    tenueNoms = { [0] = "Commandement", [1] = "Combat", [2] = "Assassinat", [3] = "Médicale", [4] = "Scientifique" },
    -- ⚠ Une surcharge posée en jeu (!espadatenue, table MySQL evo_espada_tenues,
    -- partagee par tous les serveurs) est PRIORITAIRE sur cette table :
    -- « !espadatenue reset » pour revenir ici.
    skinByOrdreNum = { [1] = 0, [2] = 3, [3] = 1, [4] = 4, [5] = 2 },
}

-- Corps Espada (modèle, skin) pour ce joueur, ou nil. Gate : faction Hollow + grade >= 15 (15 & 16).
-- divisionIndex = NWInt/colonne FactionDivision ; on résout le NUMÉRO d'Ordre via le nom « Ordre X »
-- (robuste comme le brassard : l'index ne suit pas forcément le numéro). Renvoie (model, skin) ou nil.
function LZY_CHARACTER_CONFIG.GetRankEspadaBody(faction, rank, divisionIndex)
    -- Seuil partagé avec le masque Espada (ESPADA_MIN_RANK, défini plus bas dans ce fichier).
    if faction ~= "Hollow" then return nil end
    local nRank = tonumber(rank) or 0
    if nRank < (tonumber(LZY_CHARACTER_CONFIG.ESPADA_MIN_RANK) or 15) then return nil end
    -- Le grade 16 (« Roi du Hueco Mundo ») REMPLACE ce corps par sa cape, il ne l'empile
    -- pas dessus (demande user 2026-09-18 : « il faut la mettre juste elle, tu as laissé la
    -- tenue d'avant alors qu'il fallait la remplacer »). Le corps d'Espada reste donc la
    -- tenue des SEULS grades 15. Voir HOLLOW_KING_CAPE plus bas.
    if nRank >= (tonumber(LZY_CHARACTER_CONFIG.HOLLOW_KING_MIN_RANK) or 16) then return nil end
    local cfg = LZY_CHARACTER_CONFIG.ESPADA_BODY
    if not istable(cfg) then return nil end
    local num
    if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName then
        local nm = LZY_FACTION_CONFIG.DivisionName(faction, tonumber(divisionIndex))
        num = nm and tonumber(string.match(tostring(nm), "(%d+)"))
    end
    if not num then return nil end
    -- SURCHARGE EN JEU (commande SAM !espadatenue) : une globale repliquee par
    -- Ordre, -1 = pas de surcharge. Lue AVANT la table du code, cote serveur
    -- comme cote client -- c'est le client qui construit le composite, il doit
    -- voir la meme correspondance que le serveur.
    local sur = GetGlobalInt("EVO_EspadaSkin" .. num, -1)
    local skin = (sur >= 0) and sur or cfg.skinByOrdreNum[num]
    if skin == nil then return nil end
    return cfg.model, skin
end

-- Corps Espada résolu pour les APERÇUS (faction/rank/division depuis characterData). (model, skin) ou nil.
-- Masquable par la coche « Cacher la tenue de grade » (EVO_HideRankOutfit).
function LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter(characterData, nwPlayer)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasHideRankOutfit(characterData, nwPlayer) then return nil end
    return LZY_CHARACTER_CONFIG.GetRankEspadaBody(characterData.faction, characterData.rank, characterData.division)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- HAORI DE CAPITAINE (2026-07-26, demande user) — PENDANT SHINIGAMI du corps d'Espada.
-- Accessoire body bonemergé porté par les capitaines (grade >= ESPADA_MIN_RANK, donc
-- Taicho et Sotaicho), avec un MODÈLE DIFFÉRENT PAR DIVISION.
--
-- Pourquoi un accessoire et plus un uniforme de corps : un uniforme REMPLACE le modèle
-- du personnage. Un capitaine qui achetait une tenue en boutique perdait donc son haori,
-- ou gardait son uniforme et voyait son achat ignoré. En accessoire, les deux coexistent
-- — c'est exactement le raisonnement qui avait fait passer les Espadas en ESPADA_BODY.
--
-- Contrairement au brassard et au corps d'Espada, la variation par division se fait par
-- MODÈLE et non par skin : ce sont cinq .mdl distincts, pas cinq skins d'un même fichier.
--
-- Clé = NUMÉRO de division (celui du libellé « Division X »), PAS l'index FactionDivision :
-- l'index ne suit pas le numéro (index 4 = « Division 12 », index 5 = « Division 4 »...).
-- Slot "haori" (≠ "grade"/"brassard"/"espada"/"masque_base" -> tous coexistent).
-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte) — le
-- serveur est Linux : un nom lowercasé ne matche AUCUN fichier -> haori INVISIBLE.
LZY_CHARACTER_CONFIG.CAPTAIN_HAORI = {
    byDivNum = {
        [1]  = "models/evo/accessories/body/evo_5co9frfyuyge52hr/evo_5cO9frFYUyge52hr.mdl",
        [2]  = "models/evo/accessories/body/evo_uef96dafg59frfyuygeder/evo_UEF96DAfg59frFYUygeder.mdl",
        [4]  = "models/evo/accessories/body/evo_er5yh59frfyuygtgrder/evo_er5YH59frFYUygTGRder.mdl",
        [11] = "models/evo/accessories/body/evo_hbdv59frfyuygeder/evo_HBDV59frFYUygeder.mdl",
        [12] = "models/evo/accessories/body/evo_54hgtrv59frfyuyrefer/evo_54HgtrV59frFYUyrefer.mdl",
    },
}

-- Haori du capitaine pour ce joueur, ou nil. Gate : Shinigami + grade >= seuil capitaine.
-- divisionIndex = NWInt/colonne FactionDivision ; on résout le NUMÉRO via le libellé
-- « Division X » (même méthode que le brassard, robuste au désordre des index).
function LZY_CHARACTER_CONFIG.GetRankHaori(faction, rank, divisionIndex)
    if faction ~= "Shinigami" then return nil end
    if (tonumber(rank) or 0) < (tonumber(LZY_CHARACTER_CONFIG.ESPADA_MIN_RANK) or 15) then return nil end
    local cfg = LZY_CHARACTER_CONFIG.CAPTAIN_HAORI
    if not (istable(cfg) and istable(cfg.byDivNum)) then return nil end
    local num
    if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionName then
        local nm = LZY_FACTION_CONFIG.DivisionName(faction, tonumber(divisionIndex))
        num = nm and tonumber(string.match(tostring(nm), "(%d+)"))
    end
    local mdl = num and cfg.byDivNum[num]
    return (isstring(mdl) and mdl ~= "") and mdl or nil
end

-- Haori résolu pour les APERÇUS (faction/rank/division depuis characterData), ou nil.
-- Masquable par la coche « Cacher la tenue de grade » (EVO_HideRankOutfit).
function LZY_CHARACTER_CONFIG.GetHaoriForCharacter(characterData, nwPlayer)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasHideRankOutfit(characterData, nwPlayer) then return nil end
    return LZY_CHARACTER_CONFIG.GetRankHaori(characterData.faction, characterData.rank, characterData.division)
end

-- Tenue de grade (haori / Espada) masquée ? Préférence PAR PERSO (coche inventaire).
-- Miroir exact de CharacterHasHideEpaulette.
function LZY_CHARACTER_CONFIG.CharacterHasHideRankOutfit(characterData, nwPlayer)
    if characterData and characterData.hide_rank_outfit ~= nil then
        local h = characterData.hide_rank_outfit
        return (h == 1 or h == true or tostring(h) == "1")
    end
    if nwPlayer and IsValid(nwPlayer) and nwPlayer:IsPlayer() then
        return nwPlayer:GetEvoNWBool("EVO_HideRankOutfit", false)
    end
    return false
end

-- Ce grade porte-t-il une ÉPAULETTE masquable ? Sert à n'afficher la coche
-- « Cacher l'épaulette de grade » que si elle a un effet (pas haori / Espada).
-- Ignore volontairement l'état masqué (on veut savoir s'il Y A quelque chose à masquer).
function LZY_CHARACTER_CONFIG.HasRankMarker(faction, rank, divisionIndex)
    local ep = LZY_CHARACTER_CONFIG.GetRankEpauletteModel
        and LZY_CHARACTER_CONFIG.GetRankEpauletteModel(faction, rank)
    return isstring(ep) and ep ~= ""
end

-- Ce grade porte-t-il une TENUE DE GRADE masquable (haori capitaine / corps Espada) ?
-- Sert à n'afficher la coche « Cacher la tenue de grade » que si elle a un effet.
function LZY_CHARACTER_CONFIG.HasRankOutfit(faction, rank, divisionIndex)
    local ha = LZY_CHARACTER_CONFIG.GetRankHaori
        and LZY_CHARACTER_CONFIG.GetRankHaori(faction, rank, divisionIndex)
    if isstring(ha) and ha ~= "" then return true end
    local es = LZY_CHARACTER_CONFIG.GetRankEspadaBody
        and LZY_CHARACTER_CONFIG.GetRankEspadaBody(faction, rank, divisionIndex)
    if isstring(es) and es ~= "" then return true end
    local ck = LZY_CHARACTER_CONFIG.GetRankHollowKingCape
        and LZY_CHARACTER_CONFIG.GetRankHollowKingCape(faction, rank)
    return isstring(ck) and ck ~= ""
    -- (L'accessoire de DIVISION a désormais SA coche et SON drapeau : cf.
    -- HasDivisionBody / CharacterHasHideDivisionBody, report user 08\16.)
end

-- TENUE DE GRADE VERROUILLÉE (user 08/24) : dès RankOutfitLockMinRank la coche
-- « Cacher la tenue de grade » est refusée serveur, ignorée au rendu et masquée
-- dans l'inventaire. Exemptés : superadmin et perso animateur (EVO_AnimChar).
-- PARTAGÉ : lu des deux côtés, sur soi ET sur les joueurs distants
-- (FactionRank / EVO_AnimChar sont des clés « appearance », diffusées à tous).
-- ⚠ SEUIL À 99 = VERROU DÉSACTIVÉ (09/01, demande user : les grades 15 et 16
-- doivent pouvoir mettre ET enlever leur tenue de grade — haori / corps Espada).
-- Toute la tuyauterie (refus serveur, rendu, coche, ré-affichage à la promotion)
-- reste en place : remettre 15 ici re-verrouille tout d'un coup.
LZY_CHARACTER_CONFIG.RankOutfitLockMinRank = 99
function LZY_CHARACTER_CONFIG.IsRankOutfitLocked(ply)
    if not (IsValid(ply) and ply.IsPlayer and ply:IsPlayer()) then return false end
    if ply:IsSuperAdmin() then return false end
    if ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_AnimChar", false) then return false end
    local rank = ply.GetEvoNWInt and (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) or 0
    return rank >= (LZY_CHARACTER_CONFIG.RankOutfitLockMinRank or 15)
end

-- ══════════════════════════════════════════════════════════════════════════════
-- MASQUE DE BASE ARRANCAR (2026-07-26, demande user) — masque bonemergé porté PAR DÉFAUT par TOUS
-- les Arrancars (faction Hollow), avec un modèle DIFFÉRENT pour les ESPADAS (grades 15-16). Même
-- principe que la tenue de capitaine : c'est déjà sur eux dès la connexion, sans rien acheter.
--
-- ⚠️ DIFFÉRENCE avec l'épaulette / le brassard / le corps Espada : ces trois-là s'affichent TOUJOURS,
-- alors que le masque de base DISPARAÎT dès que le joueur équipe un masque acheté en boutique (slot
-- dédié INVENTORY_CONFIG.MASK_EQUIP_SLOT = 7). Sinon on aurait deux masques superposés sur le visage.
-- Le test se fait sur les accessoires déjà résolus (cf. CharacterHasBoughtMask), pas sur l'inventaire :
-- les aperçus (char-select, HUD) n'ont pas accès à l'inventaire du joueur, seulement à characterData.
--
-- Slot "masque_base" (≠ "grade"/"brassard"/"espada" -> les quatre coexistent). Suit la promotion
-- Arrancar -> Espada via le rebuild du hook LZY:Character:RankOutfitRefresh, comme les autres.
-- ⚠️ Casse du nom de fichier RESPECTÉE (dossier minuscule, fichier casse mixte) — cf. RANK_EPAULETTES.
--    Le serveur est Linux : un nom lowercasé ne matche AUCUN fichier -> masque INVISIBLE.
LZY_CHARACTER_CONFIG.ARRANCAR_MASK = {
    -- Grades 15-16 = « Espadas numérotés » + « Roi des Hollows » (même seuil que ESPADA_BODY).
    espada   = "models/evo/accessories/head/arr_mask/evo_57efrgfs3p0952g7r0/evo_57efrGFs3p0952g7r0.mdl",
    -- Tous les autres Arrancars (grades 1-14).
    arrancar = "models/evo/accessories/head/arr_mask/evo_85jyo9hfzl9d5hfgbrzp/evo_85JYo9hfzl9d5Hfgbrzp.mdl",
}

-- Grade à partir duquel un Hollow est un ESPADA (corps bonemergé + masque dédié). Constante
-- partagée : le seuil était écrit en dur dans GetRankEspadaBody, deux copies auraient dérivé.
LZY_CHARACTER_CONFIG.ESPADA_MIN_RANK = 15

-- Masque de base pour ce joueur, ou nil (autre faction, ou modèle non configuré).
function LZY_CHARACTER_CONFIG.GetArrancarMaskModel(faction, rank)
    if faction ~= "Hollow" then return nil end
    local cfg = LZY_CHARACTER_CONFIG.ARRANCAR_MASK
    if not istable(cfg) then return nil end
    local seuil = tonumber(LZY_CHARACTER_CONFIG.ESPADA_MIN_RANK) or 15
    local mdl = ((tonumber(rank) or 0) >= seuil) and cfg.espada or cfg.arrancar
    return (isstring(mdl) and mdl ~= "") and mdl or nil
end

-- Le perso porte-t-il un masque ACHETÉ (slot dédié 7) ? Si oui, le masque de base s'efface.
-- equipped_accessories est rempli aussi bien pour le rendu monde que pour les aperçus.
function LZY_CHARACTER_CONFIG.CharacterHasBoughtMask(characterData)
    if not istable(characterData) then return false end
    local acc = characterData.equipped_accessories
    if not istable(acc) then return false end
    local slot = (INVENTORY_CONFIG and INVENTORY_CONFIG.MASK_EQUIP_SLOT) or 7
    local path = acc[tostring(slot)]
    return isstring(path) and path ~= ""
end

-- Masque de base résolu pour les APERÇUS (char-select, création, HUD) : nil si un masque acheté
-- le remplace, ou si le perso n'est pas Hollow. Le MONDE, lui, lit les NWVars live (EnsureDetailParts).
function LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter(characterData)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasBoughtMask(characterData) then return nil end
    return LZY_CHARACTER_CONFIG.GetArrancarMaskModel(characterData.faction, characterData.rank)
end

-- ═════════════════════════════════════════════════════════════════════════════
-- CAPE DU ROI DU HUECO MUNDO (16/09/2026, demande user) — accessoire body bonemergé porté par le
-- SEUL grade 16 Hollow (« Roi du Hueco Mundo »). Les Espadas 15 gardent leur corps d'Espada sans cape.
--
-- ⚠️ ELLE REMPLACE le corps d'Espada, elle ne s'y ajoute pas (correctif user 2026-09-18) : le gate
-- de GetRankEspadaBody s'arrête donc au grade 15. Le roi porte sa cape seule, sur sa tenue de base.
-- Son MASQUE d'Espada, lui, est conservé (ARRANCAR_MASK.espada, couvre toujours les grades 15-16) :
-- c'est un masque, pas une tenue, et rien n'a demandé de le retirer.
--
-- Pourquoi un accessoire et pas un uniforme : exactement le raisonnement du haori et du corps
-- d'Espada — un uniforme REMPLACE le modèle du perso, donc une tenue achetée en boutique ferait
-- disparaître la marque de grade. En accessoire, la cape se pose PAR-DESSUS et les deux coexistent.
--
-- Slot "cape_roi" (≠ "grade"/"brassard"/"espada"/"haori"/"division_body"/"masque_base" -> tous
-- coexistent : le roi porte cape + corps d'Espada + masque Espada en même temps). Suit la
-- promotion via le rebuild du hook LZY:Character:RankOutfitRefresh, comme les autres.
--
-- Un seul modèle : contrairement au corps d'Espada, la cape NE VARIE PAS par Ordre (il n'y a
-- qu'un roi) -> ni skin ni table par division à résoudre.
-- ⚠️ CASSE RECOPIÉE TELLE QUELLE depuis le chemin fourni : ICI LE DOSSIER EST EN CASSE MIXTE
--    (evo_1526HGTIJ...), contrairement aux épaulettes/haoris où seul le fichier l'est. Le serveur
--    est Linux (FS sensible à la casse) : ne normaliser NI le dossier NI le fichier, un segment
--    lowercasé ne matche AUCUN fichier -> cape INVISIBLE.
LZY_CHARACTER_CONFIG.HOLLOW_KING_CAPE = {
    model = "models/evo/accessories/body/evo_1526HGTIJvgrfe5123gr/evo_1526HGTIJvgrfe5123gr.mdl",
}

-- Grade du « Roi du Hueco Mundo » (cf. lzy_faction/config.lua, Hollow [16]). Constante nommée :
-- le seuil ne doit pas être confondu avec ESPADA_MIN_RANK (15), qui couvre AUSSI les Espadas.
LZY_CHARACTER_CONFIG.HOLLOW_KING_MIN_RANK = 16

-- Cape du roi pour ce joueur, ou nil. Gate : faction Hollow + grade >= 16.
function LZY_CHARACTER_CONFIG.GetRankHollowKingCape(faction, rank)
    if faction ~= "Hollow" then return nil end
    if (tonumber(rank) or 0) < (tonumber(LZY_CHARACTER_CONFIG.HOLLOW_KING_MIN_RANK) or 16) then return nil end
    local cfg = LZY_CHARACTER_CONFIG.HOLLOW_KING_CAPE
    if not istable(cfg) then return nil end
    local mdl = cfg.model
    return (isstring(mdl) and mdl ~= "") and mdl or nil
end

-- Cape résolue pour les APERÇUS (char-select, création, HUD), ou nil. Masquable par la coche
-- « Cacher la tenue de grade » (EVO_HideRankOutfit), comme le haori et le corps d'Espada.
function LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter(characterData, nwPlayer)
    if not characterData then return nil end
    if LZY_CHARACTER_CONFIG.CharacterHasHideRankOutfit(characterData, nwPlayer) then return nil end
    return LZY_CHARACTER_CONFIG.GetRankHollowKingCape(characterData.faction, characterData.rank)
end

LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_MALE = {
    { model = "models/evo/hair/male/hair/evo_28lcyyincfaxifq/evo_yjkrqo7sfpsqi.mdl" },
    { model = "models/evo/hair/male/hair/evo_923mcqu70whvomai/evo_63ot7cxn4uhfdh6.mdl" },
    { model = "models/evo/hair/male/hair/evo_e0ohi78jzz0y2oc9u/evo_qn32x3tw443w.mdl" },
    { model = "models/evo/hair/male/hair/evo_2dk2vvzxqng8p/evo_peqsrexu4ktn58.mdl" },
    { model = "models/evo/hair/male/hair/evo_no6jjok4l4lljlloq/evo_8vup6lzq1l4cwwu.mdl" },
    { model = "models/evo/hair/male/hair/evo_yrrq9113axtq6bli/evo_p4ptf6ngx0pu5u12.mdl" },
    { model = "models/evo/hair/male/hair/evo_70bm8zvsotjuqi/evo_jb51v8ixn9kbm7f.mdl" },
    { model = "models/evo/hair/male/hair/evo_5h6q641knvd3m4n/evo_bhvgqurfgt1kmz.mdl" },
    { model = "models/evo/hair/male/hair/evo_4sn8r8m7kgdyr/evo_0rv774h5f2u5l.mdl" },
    { model = "models/evo/hair/male/hair/evo_itip0dyl202sc/evo_c7cj0o06ini8.mdl" },
    { model = "models/evo/hair/male/hair/evo_icjhi07bs6x72ef/evo_q8e0u53v63i820.mdl" },
    { model = "models/evo/hair/male/hair/evo_1kxobb9b9t7s63px/evo_ezkvzmwpe6p69.mdl" },
    { model = "models/evo/hair/male/hair/evo_jvjmcnf1wnxm4d/evo_6odeitxqeqr9x4q.mdl" },
    { model = "models/evo/hair/male/hair/evo_ht6md7uk9cq62xwdl/evo_9l5vsq06lz3h.mdl" },
    { model = "models/evo/hair/male/hair/evo_yk866r3cctzmj3vq/evo_muwkjr86s6ah46tpc.mdl" },
    { model = "models/evo/hair/male/hair/evo_owwncneywo4gd6/evo_ldxzv5601kvsdai.mdl" },
    { model = "models/evo/hair/male/hair/evo_brd4lt2rh12cvadj/evo_81d9mju2bf3tfa7rl.mdl" },
    { model = "models/evo/hair/male/hair/evo_040lr6o19hfw4ffk/evo_uij35g9kp57lq.mdl" },
    { model = "models/evo/hair/male/hair/evo_as007mrvhkm26/evo_gt0syabh9u2zp.mdl" },
    { model = "models/evo/hair/male/hair/evo_eha897j9ix3y/evo_gxp16n2nir3wvzz.mdl" },
    { model = "models/evo/hair/male/hair/evo_h6em9iub9caaklkt9/evo_di0ze3iy3y1n.mdl" },
    { model = "models/evo/hair/male/hair/evo_93qyaz10cdlb4j68/evo_hz2b0dzvdctfprt4.mdl" },
    { model = "models/evo/hair/male/hair/evo_tqolpdff0437cj/evo_2lpxqrf8y07oapc.mdl" },
    { model = "models/evo/hair/male/hair/evo_4tn4a8jj8degztwx8/evo_a1xlpfz0gsbzm.mdl" },
    { model = "models/evo/hair/male/hair/evo_x1awmv95z6hosdf/evo_d9egapqh3p8n.mdl" },
    { model = "models/evo/hair/male/hair/evo_fz55x32a8u2m/evo_puvtjpxld2gom9ub.mdl" },
    { model = "models/evo/hair/male/hair/evo_rtrd3k84kp7dfjy/evo_1tvku7f9hebzrrfat.mdl" },
    { model = "models/evo/hair/male/hair/evo_exfb8wbe80z4g7nve/evo_vbsqnci8zqj1.mdl" },
    { model = "models/evo/hair/male/hair/evo_9mvhto45wkmar/evo_ranxeligf2ad.mdl" },
    { model = "models/evo/hair/male/hair/evo_0pr0nedchl0b/evo_l5zbhz2c2t8a.mdl" },
    { model = "models/evo/hair/male/hair/evo_fcxiocdufc0fjv5js/evo_y1muthlrpoinq.mdl" },
    { model = "models/evo/hair/male/hair/evo_z7v6rt4eyfz3ejvus/evo_px00i58csobo94.mdl" },
    { model = "models/evo/hair/male/hair/evo_maceov6viwx49bd/evo_itq2lw3yqzaevpf83.mdl" },
    { model = "models/evo/hair/male/hair/evo_5bxojys4r3fhft/evo_myed0w4l9t09.mdl" },
    { model = "models/evo/hair/male/hair/evo_ukyu27ucaac46odg9/evo_uxzouwl66ele.mdl" },
    { model = "models/evo/hair/male/hair/evo_bflvqbiuj3aif6/evo_jme6n9wv9wbqwgv4q.mdl" },
	{ model = "models/evo/hair/male/hair/evo_1ymjc4hzi9k2q/evo_pmygtrdhy5uwzc9.mdl" },
	{ model = "models/evo/hair/male/hair/evo_4ldbpkdx0k6a1/evo_11a3euewrped32.mdl" },
	{ model = "models/evo/hair/male/hair/evo_fza9tiiyfio8q87/evo_45nds22lovhwsdcdm.mdl" },
	{ model = "models/evo/hair/male/hair/evo_02n9rw23su58tx/evo_iyi79h9qkfzf1c.mdl" },
	{ model = "models/evo/hair/male/hair/evo_xxp4llom6o7dsme0x/evo_0uxhy5ibw2m3.mdl" },
	{ model = "models/evo/hair/male/hair/evo_p5pxu3sl1tg7/evo_ckdrkuyi607avhibi.mdl" },
	{ model = "models/evo/hair/male/hair/evo_3186j4wo8gjffe/evo_uadzieh7wy5g.mdl" },
	{ model = "models/evo/hair/male/hair/evo_1637cwa9q1qwzg/evo_t1x2yefsyiq8yh.mdl" },
	{ model = "models/evo/hair/male/hair/evo_s7ot9k0zssimg4k/evo_ms3m43dj1jd17ha.mdl" },
	{ model = "models/evo/hair/male/hair/evo_tceddshsh5kzkc2w/evo_3gfiz093ojke4r.mdl" },
	{ model = "models/evo/hair/male/hair/evo_bsipiky8q4k4n/evo_pnqsrb51fyxfpv78w.mdl" },
	{ model = "models/evo/hair/male/hair/evo_dtaljraeqx4n0/evo_s5hrtaxcu5yzbjr3.mdl" },
	{ model = "models/evo/hair/male/hair/evo_a0k0166cosc5qmto/evo_dxqjp5sud0zp7.mdl" },
	{ model = "models/evo/hair/male/hair/evo_tib99kp4yc37x4qiy/evo_fylrwche1w5nw4i.mdl" },
	{ model = "models/evo/hair/male/hair/evo_mrso5kgkr22if/evo_y0wdf216npvcah86v.mdl" },
	{ model = "models/evo/hair/male/hair/evo_o3m7790i8a12q9/evo_c9k9s6hg3345o.mdl" },
	{ model = "models/evo/hair/male/hair/evo_qrlu66d4vsa0/evo_b23xoxde5kcsydhg.mdl" },
	{ model = "models/evo/hair/male/hair/evo_e55t4i4q5ve1kagja/evo_38x550c7or9jq.mdl" },
	{ model = "models/evo/hair/male/hair/evo_p0uy3pocdy5blls/evo_yn9ql925q5wcl.mdl" },
	{ model = "models/evo/hair/male/hair/evo_rwf4785o5qc7c7/evo_rwqbci389oma62jd.mdl" },
	{ model = "models/evo/hair/male/hair/evo_jribu0kn0w2ft/evo_ks4bgap5i87zimr.mdl" },
	{ model = "models/evo/hair/male/hair/evo_39w1sxtyivjn/evo_3u1v20ux5b1k.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vy7tr5j5bis8/evo_uphy4edt3wmgw6b9.mdl" },
	{ model = "models/evo/hair/male/hair/evo_g6lj3su5sk42qhhko/evo_dxdvtgsbpdagn0n.mdl" },
	{ model = "models/evo/hair/male/hair/evo_bvgjdezb19rhbekefadgf/evo_bvgJDEZB19rhBEKEFadgf.mdl" },
	{ model = "models/evo/hair/male/hair/evo_cbfhhdve923ghjhcjee/evo_cbfhHDVE923GHJhcjee.mdl" },
	{ model = "models/evo/hair/male/hair/evo_fgerhfe92ghfe5fee/evo_fgerHFE92Ghfe5fee.mdl" },
	{ model = "models/evo/hair/male/hair/evo_padpz6fejkfeceuafv/evo_padpz6fejKFEceuafv.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vae95fjfe6fekpjzdzfe/evo_vae95fJFE6fekPJZdzfe.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vbdghfefzz6z6zhczez/evo_vbdgHFEFZZ6Z6Zhczez.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vbdglfehzf92gejfzfzefgdz/evo_vbdgLFEHZF92gejFZFZEFGdz.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vbfhfe6dzhkjfe55eeezd/evo_vbfhFE6DZHkjfe55eeezd.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vbzfkvfe932gjfe54f8zzz/evo_vbzfkVFE932Gjfe54f8zzz.mdl" },
	{ model = "models/evo/hair/male/hair/evo_vbfdfdzhkj52tgrqqeeezd/evo_vbfdfDZHkj52tgrqqeeezd.mdl" },
	-- ── COUPES PLATINUM (09/02, demande user) : visibles par tous, sélectionnables
	-- par le tier 3 (et le staff) seulement — cf. flag `platinum` (grille + serveur).
	-- ⚠ CASSE EXACTE fournie par le user (serveur Linux).
	{ model = "models/evo/hair/male/hair/evo_14526GBHrefopijuefr/evo_14526GBHrefopijuefr.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_481526EDZgbhrgt62OKrgt/evo_481526EDZgbhrgt62OKrgt.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_14562AKOIgrpoijuhR52gr/evo_14562AKOIgrpoijuhR52gr.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_41562APnjffvghjGR52grt/evo_41562APnjffvghjGR52grt.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_19526APhbgrtvgbh4155RGTfer/evo_19526APhbgrtvgbh4155RGTfer.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_145263ANHJfeopghbDdez/evo_145263ANHJfeopghbDdez.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_14562AhnfrpokijG41gtr/evo_14562AhnfrpokijG41gtr.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_14562AOKIgrpoliuh562rgt/evo_14562AOKIgrpoliuh562rgt.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_653gtPMOIKUJhbgfv/evo_653gtPMOIKUJhbgfv.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_rtgrt896MOPLIKhtgr/evo_rtgrt896MOPLIKhtgr.mdl", platinum = true },
	{ model = "models/evo/hair/male/hair/evo_41562vgybhRGTop52egr/evo_41562vgybhRGTop52egr.mdl", platinum = true },
}
LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_FEMALE = {
    { model = "models/evo/hair/female/hair/evo_oofl5g4kc8wi/evo_ceuz0onlmyz3.mdl" },
    { model = "models/evo/hair/female/hair/evo_umvqe8f6t8mpf/evo_6lx2w7u4ll9kqq4.mdl" },
    { model = "models/evo/hair/female/hair/evo_5tl2fe13bpyi/evo_74pju1v8ne9i.mdl" },
    { model = "models/evo/hair/female/hair/evo_2kf677qt2qxx/evo_gwjqrms1aadr7p7.mdl" },
    { model = "models/evo/hair/female/hair/evo_1mh6kwgwku1yv/evo_azbic0loqgu3r.mdl" },
    { model = "models/evo/hair/female/hair/evo_qmzz0v7mm655/evo_g9sfibe17kug.mdl" },
    { model = "models/evo/hair/female/hair/evo_zzq0zdulisp9gipf/evo_5ihfwv44ouew.mdl" },
    { model = "models/evo/hair/female/hair/evo_yw948bba78pdtv/evo_m7ylsvdv8uih9.mdl" },
    { model = "models/evo/hair/female/hair/evo_3uyrwnouzgwhlsgbn/evo_ni1kw2ebkxqf.mdl" },
    { model = "models/evo/hair/female/hair/evo_nsze4xt7u23g3xfbl/evo_855gai7s91rg03c73.mdl" },
    { model = "models/evo/hair/female/hair/evo_b9qf03loma80/evo_feqbtalx9c7y2cjbn.mdl" },
    { model = "models/evo/hair/female/hair/evo_lcdfyv7mjiuo/evo_47av7y8u1pmf.mdl" },
    { model = "models/evo/hair/female/hair/evo_rb1rtgasp5ngef5w/evo_i5f67pbpt454q.mdl" },
	{ model = "models/evo/hair/female/hair/evo_vm6sh06i3800bxy9j/evo_no00vusp67xzl2w0t.mdl" },
	{ model = "models/evo/hair/female/hair/evo_k84tmfkh43en2dx/evo_vkicojwis2kdlo6.mdl" },
	{ model = "models/evo/hair/female/hair/evo_wbklfas8thq2/evo_8104rbst7mmp43b.mdl" },
	{ model = "models/evo/hair/female/hair/evo_nn23kit408y40/evo_c3v05pw0phug.mdl" },
	{ model = "models/evo/hair/female/hair/evo_rhyrsd5ydifj/evo_f0fstaxksm4kuwfe.mdl" },
	{ model = "models/evo/hair/female/hair/evo_8f5bjqlnn6rpiky/evo_hmil44aeoludzxh.mdl" },
	{ model = "models/evo/hair/female/hair/evo_ay7bit4se1dv/evo_ipa2ilavr4bg1mc4.mdl" },
	{ model = "models/evo/hair/female/hair/evo_feavr4bg97rc4zedzed/evo_feavr4bg97rc4zedzed.mdl" },
	-- ── COUPES PLATINUM (09/02) : cf. bloc homme ci-dessus, memes regles. ──
	{ model = "models/evo/hair/female/hair/evo_836yhtgbHBGVpmloki/evo_836yhtgbHBGVpmloki.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_86352hygvfmplokijYHTG/evo_86352hygvfmplokijYHTG.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_54yhtgfGRTpmoi563hyt/evo_54yhtgfGRTpmoi563hyt.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_56gtrAHBWpmloki/evo_56gtrAHBWpmloki.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_69ikujANBgbpm52f/evo_69ikujANBgbpm52f.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_356gtPOIKUJrg5dcF/evo_356gtPOIKUJrg5dcF.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_52frhGRPLO52grt/evo_52frhGRPLO52grt.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_51APbhvgtplJNGT5grt/evo_51APbhvgtplJNGT5grt.mdl", platinum = true },
	{ model = "models/evo/hair/female/hair/evo_1526PFgbGFRIJfr3EFRref/evo_1526PFgbGFRIJfr3EFRref.mdl", platinum = true },
}

-- ══════════════════════════════════════════════════════════════════════════════
-- COUPES PLATINUM (09/02, ouvertes à tous le 09/03) — SOURCE UNIQUE de la règle.
-- Une coupe marquée `platinum = true` dans les listes ci-dessus s'AFFICHE pour tout
-- le monde mais ne se PORTE que par un Platinum (premium tier 3) ou le staff. La
-- règle était recopiée à quatre endroits (grille de création, tirage aléatoire,
-- validation création/CK, coiffeur) : elle vit désormais ICI, partagée client/serveur.
-- ⚠️ Y toucher change l'accès PARTOUT, y compris les gardes serveur anti-triche.
function LZY_CHARACTER_CONFIG.PeutCoupePlatinum(ply)
    if not IsValid(ply) then return false end
    return ply:GetEvoNWInt("premium", 0) >= 3 or ply:IsSuperAdmin()
end

--- Ce modèle de cheveux est-il une coupe PLATINUM ? (cherche dans les deux genres :
--- une validation serveur ne connaît pas toujours le genre au moment du test).
function LZY_CHARACTER_CONFIG.EstCoupePlatinum(sModel)
    if not isstring(sModel) or sModel == "" then return false end
    local tListes = { LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_MALE,
                      LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_FEMALE }
    for _, tListe in ipairs(tListes) do
        for _, h in ipairs(tListe or {}) do
            if h.model == sModel then return h.platinum == true end
        end
    end
    return false
end

--- Une liste de coupes PRIVÉE de ses entrées platinum. Pour les tirages qui n'ont
--- pas de joueur derrière (figurants, joueurs simulés) ou dont le joueur n'y a pas droit.
function LZY_CHARACTER_CONFIG.GetHairStylesSansPlatinum(tListe)
    local out = {}
    for _, h in ipairs(tListe or {}) do
        if not h.platinum then out[#out + 1] = h end
    end
    return out
end

-- Legacy characters may still have stub *_00 paths stored; those are treated as "no merge" like empty string.
LZY_CHARACTER_CONFIG.LEGACY_EMPTY_BEARD_MODEL = "models/evo/hair/male/beard/evo_c0c4eaxfjik3s/evo_39vpbcetld42.mdl"
LZY_CHARACTER_CONFIG.LEGACY_EMPTY_MUSTACHE_MODEL = "models/evo/hair/male/beard/evo_2gzg9up9omz85ui/evo_d061bubo3hwgk.mdl"

--- @return string model path to bone-merge, or "" for no facial hair part
function LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(path)
	if not isstring(path) or path == "" then return "" end
	if path == LZY_CHARACTER_CONFIG.LEGACY_EMPTY_BEARD_MODEL then return "" end
	if path == LZY_CHARACTER_CONFIG.LEGACY_EMPTY_MUSTACHE_MODEL then return "" end
	return path
end

LZY_CHARACTER_CONFIG.AVAILABLE_BEARD_STYLES = {
	{ none = true, gridCaption = "Sans barbe" },
	{ model = "models/evo/hair/male/beard/evo_tq8nzd8joxo88/evo_qvnic0yitbjo97c1.mdl" },
	{ model = "models/evo/hair/male/beard/evo_0g4t8dok1zd0eh/evo_zz7vdphzynannd.mdl" },
	{ model = "models/evo/hair/male/beard/evo_gxy44qonvcoi/evo_ryn703flxtklmj.mdl" },
	{ model = "models/evo/hair/male/beard/evo_ddx3lp3wn7r4h1o5l/evo_lv6c6yjs0nrhj3am.mdl" },
	{ model = "models/evo/hair/male/beard/evo_9epatmiaodkcv/evo_8ll6s52227vfe5uor.mdl" },
	{ model = "models/evo/hair/male/beard/evo_rdlg8w6egp7rk/evo_a77xvo8yx4dyg.mdl" },
	{ model = "models/evo/hair/male/beard/evo_152ibkv1vbnd1/evo_fxgkwjlhnscak.mdl" },
	{ model = "models/evo/hair/male/beard/evo_9qbyp9zutdrgaj1y/evo_5grz3tudcuc360l6j.mdl" },
	{ model = "models/evo/hair/male/beard/evo_ttqlnl28skz9e/evo_jy6ir0ms0295.mdl" },
}

LZY_CHARACTER_CONFIG.AVAILABLE_MUSTACHE_STYLES = {
	{ none = true, gridCaption = "Sans moustache" },
	{ model = "models/evo/hair/male/beard/evo_vs0bp17ny8ipw/evo_l0vfhntlfbmwb.mdl" },
	{ model = "models/evo/hair/male/beard/evo_ld2l71vdk2h0/evo_jieiu71uryemmj8l.mdl" },
	{ model = "models/evo/hair/male/beard/evo_6advpbzpixwt/evo_0bbljsbqgj25.mdl" },
	{ model = "models/evo/hair/male/beard/evo_idl9klp2ha3s8fe/evo_87wcbjqqvp7s4cex.mdl" },
	{ model = "models/evo/hair/male/beard/evo_pr9j1shm9q817/evo_tp3x7i0i268oux.mdl" },
	{ model = "models/evo/hair/male/beard/evo_geix24zqpq5s/evo_ian873imyezszae9w.mdl" },
}

LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_MALE = "models/evo/hair/male/hair/evo_tt1gilc3ru96ey6b5/evo_8vwfbzf8h6m2xp.mdl"
LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_FEMALE = "models/evo/hair/female/hair/evo_4scvb5ez1lbn/evo_us0m2r9g7rvmpw1.mdl"

--- @param nwPlayer Player|nil Fallback NWBool hide_hair when characterData has no hide_hair field.
function LZY_CHARACTER_CONFIG.CharacterHasHideHair(characterData, nwPlayer)
	if not characterData then return false end
	if characterData.hide_hair ~= nil then
		local h = characterData.hide_hair
		return (h == 1 or h == true or tostring(h) == "1")
	end
	if nwPlayer and IsValid(nwPlayer) and nwPlayer:IsPlayer() then
		return nwPlayer:GetEvoNWBool("hide_hair", false)
	end
	return false
end

--- Resolved hair model for rendering (stub hair when hide_hair is set in data or on nwPlayer).
--- Synced characterData from the server wins over NWBool so the model updates immediately when
--- CreateClientSideModel arrives (NW can replicate a tick later).
--- @param nwPlayer Player|nil Fallback: that entity's NWBool hide_hair if characterData has no hide_hair field (omit in character creator preview).
function LZY_CHARACTER_CONFIG.GetHairModelForCharacter(characterData, nwPlayer)
	if not characterData then return nil end
	if LZY_CHARACTER_CONFIG.CharacterHasHideHair(characterData, nwPlayer) then
		local g = characterData.gender
		if g == "m" or g == "male" then
			return LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_MALE
		end
		return LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_FEMALE
	end
	return characterData.hair_model
end

-- Tattoo application (see cl_models.lua): bake tattoo into a render target on the face diffuse, then
-- assign a cloned VertexLitGeneric submaterial whose $basetexture is that RT.

-- Substring matched against lowercase GetMaterials(); first match picks the face diffuse slot to bake.
-- Example: LZY_CHARACTER_CONFIG.TATTOO_FACE_DIFFUSE_HINT = "/male/faces/skin"
LZY_CHARACTER_CONFIG.TATTOO_FACE_DIFFUSE_HINT = ""

-- RT resolution cap (axe le plus grand) pour le bake face + tattoo.
-- 2026-05 : passe de 1024 a 2048 pour preserver la resolution native des
-- face VMTs (souvent 2048x2048 ou 1024x2048). A 1024 on perdait 50%+ de
-- detail -> aliasing visible aux angles glissants (oreille, sous-bouche)
-- car les RT en DX9 ne generent pas automatiquement leurs mipmaps.
LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE = 2048

-- Cap RT tattoo pour les joueurs LOINTAINS / hors budget detail (cf. LZY_Character_TattooMaxAxisForEntity).
-- Local + K plus proches gardent TATTOO_RT_SIZE ; au-dela du LOD accessoires = pas de tatouage RT.
LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE_LOD = 1024

-- Tattoo decal width/height as a fraction of the RT (and face UV space).
LZY_CHARACTER_CONFIG.TATTOO_RT_DECAL_SIZE = 0.30

-- Picker-centered UV slide: multiplied by (pos - 0.5); increase if the motif moves too little on screen.
LZY_CHARACTER_CONFIG.TATTOO_UV_TRANSLATE_STRENGTH = 2

-- Constant UV offset added on top of the picker-driven translate. Lets us re-anchor the
-- picker so its visual center maps to a non-center point on the face. Negative X = leftward.
LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_X = 0
LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_Y = 0.25

-- Plage du pad « Placement » du visage (UV normalisée 0-1) : réglage fin autour du centre.
-- Ce n'est PAS une borne des données : le clic dans l'aperçu place partout (0..1).
LZY_CHARACTER_CONFIG.TATTOO_POS_MIN = 0.4
LZY_CHARACTER_CONFIG.TATTOO_POS_MAX = 0.6

-- Face tattoo texture allow-list; tint applied when compositing into the RT.
LZY_CHARACTER_CONFIG.AVAILABLE_TATOO_TEXTURES = {
    "evo/face/tattoo/tattoo_001",
    "evo/face/tattoo/tattoo_002",
    "evo/face/tattoo/tattoo_003",
    "evo/face/tattoo/tattoo_004",
    "evo/face/tattoo/tattoo_005",
    "evo/face/tattoo/tattoo_006",
    "evo/face/tattoo/tattoo_007",
    "evo/face/tattoo/tattoo_008",
    "evo/face/tattoo/tattoo_009",
    "evo/face/tattoo/tattoo_010",
    "evo/face/tattoo/tattoo_011",
    "evo/face/tattoo/tattoo_012",
    "evo/face/tattoo/tattoo_013",
    "evo/face/tattoo/tattoo_014",
    "evo/face/tattoo/tattoo_015",
    "evo/face/tattoo/tattoo_016",
    "evo/face/tattoo/tattoo_017",
    "evo/face/tattoo/tattoo_018",
    "evo/face/tattoo/tattoo_019",
    "evo/face/tattoo/tattoo_020",
    "evo/face/tattoo/tattoo_021",
    "evo/face/tattoo/tattoo_022",
    "evo/face/tattoo/tattoo_023",
    "evo/face/tattoo/tattoo_024",
    "evo/face/tattoo/tattoo_025",
    "evo/face/tattoo/tattoo_026",
    "evo/face/tattoo/tattoo_027",
    "evo/face/tattoo/tattoo_028",
    "evo/face/tattoo/tattoo_029",
    "evo/face/tattoo/tattoo_030",
    "evo/face/tattoo/tattoo_031",
    "evo/face/tattoo/tattoo_032",
    "evo/face/tattoo/tattoo_033",
    "evo/face/tattoo/tattoo_034",
    "evo/face/tattoo/tattoo_035",
    "evo/face/tattoo/tattoo_036",
    "evo/face/tattoo/tattoo_037",
    "evo/face/tattoo/tattoo_038",
    "evo/face/tattoo/tattoo_039",
    "evo/face/tattoo/tattoo_040",
    "evo/face/tattoo/tattoo_041",
    "evo/face/tattoo/tattoo_042",
    "evo/face/tattoo/tattoo_043",
    "evo/face/tattoo/tattoo_044",
    "evo/face/tattoo/tattoo_045",
    "evo/face/tattoo/tattoo_046",
    "evo/face/tattoo/tattoo_047",
    "evo/face/tattoo/tattoo_048",
    "evo/face/tattoo/tattoo_049",
    "evo/face/tattoo/tattoo_050",
    "evo/face/tattoo/tattoo_051",
    "evo/face/tattoo/tattoo_052",
    "evo/face/tattoo/tattoo_053",
    "evo/face/tattoo/tattoo_054",
    "evo/face/tattoo/tattoo_055",
    "evo/face/tattoo/tattoo_056",
    "evo/face/tattoo/tattoo_057",
    "evo/face/tattoo/tattoo_058",
    "evo/face/tattoo/tattoo_059",
    "evo/face/tattoo/tattoo_060",
    "evo/face/tattoo/tattoo_061",
    "evo/face/tattoo/tattoo_062",
    "evo/face/tattoo/tattoo_063",
    "evo/face/tattoo/tattoo_064",
    "evo/face/tattoo/tattoo_065",
    "evo/face/tattoo/tattoo_066",
    "evo/face/tattoo/tattoo_067",
    "evo/face/tattoo/tattoo_068",
    "evo/face/tattoo/tattoo_069",
    "evo/face/tattoo/tattoo_070",
    "evo/face/tattoo/tattoo_071",
    "evo/face/tattoo/tattoo_072",
    "evo/face/tattoo/tattoo_073",
    "evo/face/tattoo/tattoo_074",
    "evo/face/tattoo/tattoo_075",
    "evo/face/tattoo/tattoo_076",
    "evo/face/tattoo/tattoo_077",
    "evo/face/tattoo/tattoo_078",
    "evo/face/tattoo/tattoo_079",
    "evo/face/tattoo/tattoo_080",
    "evo/face/tattoo/tattoo_081",
    "evo/face/tattoo/tattoo_082",
    "evo/face/tattoo/tattoo_083",
    "evo/face/tattoo/tattoo_084",
    "evo/face/tattoo/tattoo_085",
    "evo/face/tattoo/tattoo_086",
    "evo/face/tattoo/tattoo_087",
    "evo/face/tattoo/tattoo_088",
    "evo/face/tattoo/tattoo_089",
    "evo/face/tattoo/tattoo_090",
    "evo/face/tattoo/tattoo_091",
    "evo/face/tattoo/tattoo_092",
    "evo/face/tattoo/tattoo_093",
    "evo/face/tattoo/tattoo_094",
    "evo/face/tattoo/tattoo_095",
    "evo/face/tattoo/tattoo_096",
    "evo/face/tattoo/tattoo_097",
    "evo/face/tattoo/tattoo_098",
    "evo/face/tattoo/tattoo_099",
    "evo/face/tattoo/tattoo_100",
    "evo/face/tattoo/tattoo_101",
    "evo/face/tattoo/tattoo_102",
    "evo/face/tattoo/tattoo_103",
    "evo/face/tattoo/tattoo_104",
    "evo/face/tattoo/tattoo_105",
    "evo/face/tattoo/tattoo_106",
    "evo/face/tattoo/tattoo_107",
    "evo/face/tattoo/tattoo_108",
    "evo/face/tattoo/tattoo_109",
    "evo/face/tattoo/tattoo_110",
    "evo/face/tattoo/tattoo_111",
    "evo/face/tattoo/tattoo_112",
    "evo/face/tattoo/tattoo_113",
    "evo/face/tattoo/tattoo_114",
    "evo/face/tattoo/tattoo_115",
    "evo/face/tattoo/tattoo_116",
    "evo/face/tattoo/tattoo_117",
    "evo/face/tattoo/tattoo_118",
    "evo/face/tattoo/tattoo_119",
    -- Motifs pour TOUS (09/29, user), légende = nom du motif.
    "evo/face/tattoo/tattoo_130", -- Rectangle vertical
    "evo/face/tattoo/tattoo_131", -- Rectangle horizontal
    "evo/face/tattoo/tattoo_132", -- Double bande verticale
    "evo/face/tattoo/tattoo_133", -- Triple bande
    "evo/face/tattoo/tattoo_134", -- Barres de joue
    "evo/face/tattoo/tattoo_135", -- Marques sous les yeux
    "evo/face/tattoo/tattoo_136", -- Bandeau scientifique
    "evo/face/tattoo/tattoo_137", -- Larmes angulaires
    "evo/face/tattoo/tattoo_138", -- Couronne frontale
    "evo/face/tattoo/tattoo_139", -- Masque scindé
    "evo/face/tattoo/tattoo_140", -- Menton rituel
    "evo/face/tattoo/tattoo_141", -- Masque du chercheur
    -- Tatouages Arrancar : Numéros Espada (09/29, user) : tattoo_120 = chiffre 0 ... tattoo_129 = 9.
    -- RÉSERVÉS aux Hollows (TATTOO_FACTION).
    "evo/face/tattoo/tattoo_120",
    "evo/face/tattoo/tattoo_121",
    "evo/face/tattoo/tattoo_122",
    "evo/face/tattoo/tattoo_123",
    "evo/face/tattoo/tattoo_124",
    "evo/face/tattoo/tattoo_125",
    "evo/face/tattoo/tattoo_126",
    "evo/face/tattoo/tattoo_127",
    "evo/face/tattoo/tattoo_128",
    "evo/face/tattoo/tattoo_129",
}

-- Légende sous la vignette du créateur, et tatouages EXCLUS du tirage aléatoire (bouton
-- hasard, foule de PNJ) : un numéro d'Espada a un sens, il ne doit pas tomber au hasard.
LZY_CHARACTER_CONFIG.TATTOO_CAPTIONS = LZY_CHARACTER_CONFIG.TATTOO_CAPTIONS or {}
LZY_CHARACTER_CONFIG.TATTOO_NO_RANDOM = LZY_CHARACTER_CONFIG.TATTOO_NO_RANDOM or {}
-- Tatouage réservé à UNE faction (nom LZY_FACTION_CONFIG) : masqué ailleurs dans la grille,
-- et refusé par le serveur à la création, au CK et chez le tatoueur (NormalizeTattooTexturePath).
LZY_CHARACTER_CONFIG.TATTOO_FACTION = LZY_CHARACTER_CONFIG.TATTOO_FACTION or {}
for i = 0, 9 do
    local sPath = "evo/face/tattoo/tattoo_12" .. i
    LZY_CHARACTER_CONFIG.TATTOO_CAPTIONS[sPath] = "Espada " .. i
    LZY_CHARACTER_CONFIG.TATTOO_NO_RANDOM[sPath] = true
    LZY_CHARACTER_CONFIG.TATTOO_FACTION[sPath] = "Hollow"
end
for sPath, sNom in pairs({
    ["evo/face/tattoo/tattoo_130"] = "Rectangle vertical",
    ["evo/face/tattoo/tattoo_131"] = "Rectangle horizontal",
    ["evo/face/tattoo/tattoo_132"] = "Double bande verticale",
    ["evo/face/tattoo/tattoo_133"] = "Triple bande",
    ["evo/face/tattoo/tattoo_134"] = "Barres de joue",
    ["evo/face/tattoo/tattoo_135"] = "Marques sous les yeux",
    ["evo/face/tattoo/tattoo_136"] = "Bandeau scientifique",
    ["evo/face/tattoo/tattoo_137"] = "Larmes angulaires",
    ["evo/face/tattoo/tattoo_138"] = "Couronne frontale",
    ["evo/face/tattoo/tattoo_139"] = "Masque scindé",
    ["evo/face/tattoo/tattoo_140"] = "Menton rituel",
    ["evo/face/tattoo/tattoo_141"] = "Masque du chercheur",
}) do
    LZY_CHARACTER_CONFIG.TATTOO_CAPTIONS[sPath] = sNom
end

-- La faction peut-elle porter ce tatouage ? (sans restriction = oui pour tous)
function LZY_CHARACTER_CONFIG.TattooAllowedForFaction(sPath, sFaction)
    local sReq = LZY_CHARACTER_CONFIG.TATTOO_FACTION[sPath]
    return not sReq or sReq == tostring(sFaction or "")
end

-- Tatouages pouvant sortir au hasard (tous, sauf TATTOO_NO_RANDOM).
function LZY_CHARACTER_CONFIG.GetRandomTattooPool()
    local t = {}
    for _, sPath in ipairs(LZY_CHARACTER_CONFIG.AVAILABLE_TATOO_TEXTURES or {}) do
        if not LZY_CHARACTER_CONFIG.TATTOO_NO_RANDOM[sPath] then t[#t + 1] = sPath end
    end
    return t
end

-- sFaction (optionnel, ÉCRITURES serveur) : un tatouage réservé à une autre faction est refusé.
-- Sans sFaction (lecture / rendu), seul l'allow-list compte.
function LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(path, sFaction)
    if not isstring(path) then return "" end
    path = (string.gsub(path, "^%s*(.-)%s*$", "%1")) or ""
    if path == "" then return "" end
    for _, allowed in ipairs(LZY_CHARACTER_CONFIG.AVAILABLE_TATOO_TEXTURES or {}) do
        if allowed == path then
            if sFaction ~= nil and LZY_CHARACTER_CONFIG.TattooAllowedForFaction
                and not LZY_CHARACTER_CONFIG.TattooAllowedForFaction(path, sFaction) then
                return ""
            end
            return path
        end
    end
    return ""
end

-- ── TATOUAGES DU CORPS (10/01 ; collection V2 « TATOUAGES_CORPS_V2_1 ») ─────────────
-- Peau du corps séparée du visage : matériau `skin_body_m` / `skin_body_f` /
-- `skin_body_m_citoyen` (`_1`.. = teintes), sous evo/characters/skin/ OU
-- skin/details/<famille>/. Atlas UV commun 2048, MÊMES zones homme et femme. Un tatouage =
-- un EMPLACEMENT k (1..MAX, partagé avec le visage : un emplacement est visage OU corps,
-- 2 tatouages au total) + ZONE + u (autour du membre) + v (le long) + taille / rotation /
-- opacité / couleur. Motifs = allow-list du visage. JSON characters.body_tattoos, cuit par
-- LZY_ApplyBodyTattoo (cl_models) sur le $basetexture RÉEL de la peau (détails du torse).
LZY_CHARACTER_CONFIG.BODY_TATTOO = {
    MAX        = 2,             -- = nombre d'emplacements de tatouage (visage + corps)
    ATLAS      = 2048,
    -- Trouvés par NOM (jamais par indice). "_citoyen" AVANT "skin_body_m" (même début).
    SKIN_LEAVES = { "skin_body_m_citoyen", "skin_body_m", "skin_body_f" },
    MAIN_FRAC = 2 / 3,          -- dépliage cylindrique : 2/3 = tour, dernier tiers = raccord
    BASE_SIZE = 0.35,           -- taille 1 = 35 % du plus petit côté de la zone (sx largeur, sy hauteur)
    -- Encre MULTIPLIÉE par la peau (les détails peints du torse restent visibles dessous) +
    -- cette part posée par-dessus, pour que les encres claires se voient. 0 = multiply pur.
    INK_COVER = 0.35,
    TEST_OUTFITS = {
        amazone  = { label = "Amazone Grenat", model = "models/evo/tests/tattoo_corps_v1/amazone_grenat.mdl" },
        danseuse = { label = "Danseuse Iris",  model = "models/evo/tests/tattoo_corps_v1/danseuse_iris.mdl" },
    },
    -- rect = pixels atlas [x0, y0, x1, y1], origine haut-gauche. L/R = côtés du PERSONNAGE.
    -- La case réservée au vêtement [2022,238]-[2047,263] n'est dans AUCUNE zone : jamais peinte.
    -- Zones PROPOSÉES (menu + clic dans l'aperçu), user 10/02. Pieds / doigts restent décrits
    -- dans ZONES (atlas) mais ne sont plus proposés.
    ZONE_ORDER = { "torse", "dos", "cou", "bras_L", "bras_R", "paume_L", "paume_R", "jambe_L", "jambe_R" },
    ZONES = {
        -- geo = hauteur réelle (unités) du HAUT et du BAS du rect, par genre (ATLAS_UV_COMMUN :
        -- start.z + length * vmax / vmin). link = zones où le motif CONTINUE (même angle, même
        -- hauteur réelle) : cou et torse liés (user 10/02), plus de coupure à la base du cou.
        torse    = { label = "Torse",               rect = { 16, 16, 1008, 1008 },
            geo = { m = { 64.11, 29.5 }, f = { 64.0, 29.5 } }, link = { "cou" } },
        -- Dos = MÊME cylindre que le torse, décalé d'un demi-tour (u = 0,5 -> milieu du dos).
        -- Si Torse et Dos s'affichent inversés en jeu : mettre uoff sur torse au lieu de dos.
        dos      = { label = "Dos",                 rect = { 16, 16, 1008, 1008 }, uoff = 0.5,
            geo = { m = { 64.11, 29.5 }, f = { 64.0, 29.5 } }, link = { "cou" } },
        cou      = { label = "Cou",                 rect = { 1040, 16, 1518, 240 },
            geo = { m = { 67.81, 58 }, f = { 65, 58 } }, link = { "torse" } },
        bras_L   = { label = "Bras gauche",         rect = { 1040, 272, 1518, 1008 } },
        bras_R   = { label = "Bras droit",          rect = { 1552, 272, 2030, 1008 } },
        paume_L  = { label = "Main gauche",         rect = { 1040, 1040, 1518, 1518 } },
        paume_R  = { label = "Main droite",         rect = { 1552, 1040, 2030, 1518 } },
        jambe_L  = { label = "Jambe gauche",        rect = { 16, 1040, 494, 2032 } },
        jambe_R  = { label = "Jambe droite",        rect = { 528, 1040, 1006, 2032 } },
        pied_L   = { label = "Pied gauche",         rect = { 1552, 16, 1776, 240 } },
        pied_R   = { label = "Pied droit",          rect = { 1792, 16, 2016, 240 } },
        doigt_L0 = { label = "Pouce gauche",        rect = { 1040, 1552, 1218, 1784 } },
        doigt_L1 = { label = "Index gauche",        rect = { 1238, 1552, 1416, 1784 } },
        doigt_L2 = { label = "Majeur gauche",       rect = { 1436, 1552, 1614, 1784 } },
        doigt_L3 = { label = "Annulaire gauche",    rect = { 1634, 1552, 1812, 1784 } },
        doigt_L4 = { label = "Auriculaire gauche",  rect = { 1832, 1552, 2010, 1784 } },
        doigt_R0 = { label = "Pouce droit",         rect = { 1040, 1800, 1218, 2032 } },
        doigt_R1 = { label = "Index droit",         rect = { 1238, 1800, 1416, 2032 } },
        doigt_R2 = { label = "Majeur droit",        rect = { 1436, 1800, 1614, 2032 } },
        doigt_R3 = { label = "Annulaire droit",     rect = { 1634, 1800, 1812, 2032 } },
        doigt_R4 = { label = "Auriculaire droit",   rect = { 1832, 1800, 2010, 2032 } },
    },
}

local function bodyTatByte(n) return math.Clamp(math.floor(tonumber(n) or 255), 0, 255) end

-- Liste propre : emplacement k unique dans 1..MAX, zone connue, motif de l'allow-list (+ faction
-- côté écriture serveur), valeurs bornées et arrondies (JSON court : payload modèle).
-- dFace (optionnel, écritures serveur) : un emplacement qui porte un tatouage VISAGE
-- (tattoo_texture[_k]) ne peut pas porter aussi un tatouage corps -> 2 au total.
function LZY_CHARACTER_CONFIG.SanitizeBodyTattoos(t, sFaction, dFace)
    local BT, out, used = LZY_CHARACTER_CONFIG.BODY_TATTOO, {}, {}
    if not istable(t) then return out end
    for i = 1, BT.MAX * 2 do
        local e = t[i]
        local k = istable(e) and math.floor(tonumber(e.k) or i) or 0 -- anciennes entrées sans k : rang
        local sFace = istable(dFace) and dFace["tattoo_texture" .. (k == 1 and "" or ("_" .. k))] or ""
        if k >= 1 and k <= BT.MAX and not used[k] and (not isstring(sFace) or sFace == "")
            and isstring(e.z) and BT.ZONES[e.z] then
            local path = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(tostring(e.t or ""), sFaction)
            if path ~= "" then
                used[k] = true
                local c = istable(e.c) and e.c or {}
                out[#out + 1] = {
                    k = k, t = path, z = e.z,
                    u = math.Round(math.Clamp(tonumber(e.u) or 0.5, 0, 1), 3),
                    v = math.Round(math.Clamp(tonumber(e.v) or 0.5, 0, 1), 3),
                    -- sx/sy comme le visage ; anciennes entrées : taille unique s.
                    sx = math.Round(math.Clamp(tonumber(e.sx or e.s) or 1, 0.1, 3), 2),
                    sy = math.Round(math.Clamp(tonumber(e.sy or e.s) or 1, 0.1, 3), 2),
                    r = math.floor(tonumber(e.r) or 0) % 360,
                    o = math.Round(math.Clamp(tonumber(e.o) or 1, 0, 1), 2),
                    c = { r = bodyTatByte(c.r), g = bodyTatByte(c.g), b = bodyTatByte(c.b) },
                }
            end
        end
    end
    return out
end

-- ── PETS D'ÉPAULE (user 08/26) ──────────────────────────────────────────────
-- Accessoires « body » ANIMÉS (pets), bonemergés comme les autres accessoires. Rendu =
-- ClientsideModel posé chaque frame sur un os du porteur + séquences jouées par le
-- module pet de cl_models (LZY_Character_SetupPetPart / PetPlace / Think PetAnim).
-- Clé = model_path (minuscules, chemin canonique models/evo/accessories/body/pet_epaule/
-- <dir>/<dir>.mdl). anims.idle = boucle de base ; anims.specials = séquences jouées
-- de temps en temps (une table = chaîne jouée dans l'ordre).
LZY_CHARACTER_CONFIG.PET_ATTACH = {
    -- mode (user 08/27, « ça doit être comme les accessoires d'épaule ») :
    --   "auto"      = si le .mdl du pet porte des os ValveBiped (rigé sur le squelette
    --                 joueur par le modeleur), il est BONEMERGÉ comme n'importe quel
    --                 accessoire d'épaule (position exacte du modeleur, ses propres os
    --                 gardent leurs animations) ; sinon, pose manuelle sur l'os ci-dessous.
    --   "bonemerge" = toujours bonemergé (un modèle à squelette propre ne s'afficherait pas).
    --   "manual"    = toujours posé sur l'os (ancien comportement, offsets ci-dessous).
    -- 08/27 : TOUS les pets sont ré-exportés SANS pet_root, rigés sur le squelette
    -- joueur comme les autres accessoires body -> bonemerge pour tous, EXACTEMENT
    -- comme un accessoire d'épaule. La pose manuelle (bone/pos/ang ci-dessous) ne
    -- sert plus qu'en repli (mode "manual").
    -- ⚠ NE PAS repasser en "auto" : le 08/29 ça avait été tenté pour couvrir un
    -- modèle qui aurait gardé pet_root, et ça remettait des pets en pose manuelle
    -- au lieu du bonemerge attendu (user : « les pets doivent être reliés comme
    -- les accessoires de base »).
    mode     = "bonemerge",
    bone     = "ValveBiped.Bip01_R_Clavicle", -- épaule droite : POSITION d'ancrage
    fallback = "ValveBiped.Bip01_Spine2",
    -- Décalage depuis l'os d'ancrage, dans les AXES DU CORPS du porteur (x = vers
    -- l'avant, y = vers sa droite, z = vers le haut), unités source. La clavicule
    -- est au creux de l'épaule : 7 vers l'extérieur et 3 vers le haut = posé dessus.
    pos      = Vector(0, 7, 3),
    -- Orientation en axes du corps (pitch, yaw, roll) : 0 = le pet regarde devant.
    ang      = Angle(0, 0, 0),
    scale    = 1,
    special_delay = { 6, 16 }, -- secondes entre deux séquences spéciales
}

local PET_ROOT = "models/evo/accessories/body/pet_epaule/"
LZY_CHARACTER_CONFIG.SHOULDER_PETS = {}
-- sAttach (optionnel) : "bonemerge" / "manual" force l'attache de CE pet, sinon
-- PET_ATTACH.mode (= bonemerge pour tous depuis le 08/27, plus de pet_root).
local function pet(sDir, tSpecials, sAttach)
    -- sDir peut avoir un sous-dossier (« tickets/loutre_lotus ») : le .mdl porte le DERNIER segment.
    LZY_CHARACTER_CONFIG.SHOULDER_PETS[PET_ROOT .. sDir .. "/" .. string.GetFileFromFilename(sDir) .. ".mdl"] = {
        id     = sDir,
        anims  = { idle = "idle", specials = tSpecials },
        attach = sAttach,
    }
end
pet("anole_vert")
pet("axolotl")
pet("baleine_cartoon", { "nage" })
pet("champignon")
pet("chat_cartoon")
pet("chien_cartoon")
pet("corbeau")
pet("demon_garcon")
pet("fantome")
pet("grenouille_lowpoly")
pet("koi_anime", { "nage" })
pet("lama_peluche")
pet("doll_ikkaku")
pet("doll_nnoitra")
pet("doll_yamamoto")
pet("lezard_cartoon")
pet("oeil_tentacules")
pet("papillon", { "vol" })
pet("papillon_arc_en_ciel", { "vol" })
pet("pingouin_peluche")
pet("poisson_anime", { "nage" })
pet("poulet_anime", { "picore", "marche", "repos", { "s_assoit", "assis", "se_leve" } })
pet("serpent", { "attaque", "recherche" })
-- Compagnons 09/08 (bis) : idle seul, bouclé par le Think (demande user).
pet("tanuki_bois")
pet("tortue_jardin")
pet("hibou_veilleuse")
pet("dragon_perle")
-- Compagnons 09/08 (ter) : idle seul (cycle 4 s / 30 ips dans la sequence).
pet("souris_des_greniers")
pet("grue_des_roseaux")
pet("lapin_de_neige")
pet("axolotl_de_jade")
pet("furet_voyageur")
pet("baku_des_songes")
pet("panda_roux_erable")
pet("kirin_clochettes")
pet("kitsune_trois_queues")
pet("phoenix_de_braise")
pet("kon") -- 10/01, idle seul
-- Tickets à gratter thématiques (10/01) : pets « V2 animés », idle bouclé tant que les
-- noms de leurs séquences spéciales ne sont pas connus.
pet("tickets/loutre_lotus")
pet("tickets/scarabee_jade")
pet("tickets/griffon_solaire")
pet("tickets/salamandre_braise")
pet("tickets/lapin_lunaire")
pet("tickets/raie_celeste")
pet("tickets/chauve_souris_oni")
pet("tickets/crabe_oni")

function LZY_CHARACTER_CONFIG.GetShoulderPet(sModelPath)
    if not isstring(sModelPath) then return nil end
    return LZY_CHARACTER_CONFIG.SHOULDER_PETS[string.lower(sModelPath)]
end
