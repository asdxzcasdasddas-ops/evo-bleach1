-- "addons\\lzy_character\\lua\\lzy_character\\shared\\sh_ply_state.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Owner state + small remote appearance state over versioned reliable nets.
-- Engine SetNW* is not used for schema keys.

LZY_PlyState = LZY_PlyState or {}
-- 10 : nacim et staging avaient TOUS DEUX pris le n°9, pour des schémas DIFFÉRENTS
-- (nacim + EVO::IsHoldingMap, staging + EVO_HealBed_Operated). Le merge contient les deux,
-- donc ses index de fil diffèrent des deux côtés : garder 9 aurait rendu un désaccord
-- serveur/client SILENCIEUX (même n°, indices décalés). 10 le rend détectable.
-- 11 : + EVO_AnonMask (masque d'anonymat, slot 7). Vérifié avant de prendre le n° :
-- aucune autre branche du dépôt ne porte ce fichier au-delà de 8 (pre-staging).
-- 12 : + EVO_FactionFormateur, EVO_ShikaiEligible (hors NW2).
-- 13 : + EVO::IsReadingLivre (anim lecture evo_livre, visible aux autres clients).
-- 15 : + EVO_LivreHabilite (invite au Secret defense des archives, evo_livre).
-- On saute le 14 EXPRES : nacim l'a deja pris pour un schema DIFFERENT (7 cles
-- routees d'un coup). Reutiliser 14 ici pour une 3e disposition, c'est
-- exactement l'incident du n 9 : meme numero, indices de fil decales, desync
-- serveur/client SILENCIEUSE. Au merge de nacim, ne pas ecraser ce numero.
-- 17 : + EVO::IsHoldingAffiche (evo_affiche, APPEARANCE : pose de lecture d'une
-- affiche tenue en main, vue par autrui). Report du SEUL systeme d'affiches
-- depuis nacim, sans le reste de la branche. On saute le 16 : nacim et
-- pre-staging l'ont DEJA pris pour un schema PLUS LARGE (164 clefs) alors
-- qu'ici la table en compte 161. Meme numero pour deux dispositions = desync
-- serveur/client SILENCIEUSE, c'est l'incident du n 9. Au merge complet de
-- nacim, ne PAS ecraser ce numero.
-- 20 : + NCM_AssassinInvisEnd (float owner-only, deadline HUD Camouflage de l'Ombre).
-- Ecrit dans ncm_assassin_passif ; lu uniquement sur LocalPlayer. Sans routage le
-- gate tombe en NW2 (CI pull_request staging -> main). On SAUTE 18 et 19 :
-- origin/nacim porte 18 (retrait de rerolls_coffre_cosmetique) et origin/pre-staging
-- porte 19 (ce meme +InvisEnd, schema plus large). Reprendre l'un ou l'autre
-- rendrait le desaccord serveur/client SILENCIEUX (incident du n 9).
-- 21 : + EVO_StaffScale (float appearance, FIN de liste : aucun index de fil ne bouge).
-- Report du systeme de taille staff depuis pre-staging, schema ADAPTE a cette lignee.
-- ATTENTION : pre-staging a REPRIS le n 20 apres nous pour SON +EVO_StaffScale (165
-- cles vs nos 162) -> 20 est desormais AMBIGU entre les deux lignees ; 21 est vierge
-- sur toutes les branches au 08/15. Prochain bump nacim/pre-staging : sauter 21.
-- 22 : + EVO_HideDivisionBody (bool appearance, FIN de liste). Coche inventaire
-- « Cacher la tenue de division » : sans NW, le Think relisait la data CSM
-- (debounce 0.35s) et recachait la coche. Miroir de EVO_HideRankOutfit.
-- 23 : RESTAURATION de EVO_Maladie / EVO_MaladieAggrave / EVO_SciLevel, perdues
-- par le portage du n 21 (cf. fin de SCHEMA). Ajoutees en FIN de liste, donc
-- aucun index de fil existant ne bouge : un client en 22 lit toujours
-- correctement les 164 premieres clefs, il ignore juste les 3 nouvelles.
-- 24 : + EVO_ShieldHP (float owner-only, FIN de liste). Bouclier spirituel du
-- lot Voie du katana (Rasen Zan) : ecrit dans sv_spell_utils, lu sur SOI par la
-- pilule HUD. Sans routage le gate le voyait retomber en NW2. 24 vierge sur
-- toutes les lignees au 08/18 (pre-staging est en 20, nacim en 23).
-- 25 : + start_packs_bought (int owner-only, FIN de liste), repris de STAGING.
-- ⚠ staging avait pris 23 pour SON schema (165 cles, avec cette cle) pendant
-- que nacim portait 23 pour 167 cles : collision classique. 25 = l'UNION des
-- trois lignees (169 cles) faite au merge du 08/18 pour reunifier nacim,
-- pre-staging ET staging sur une seule disposition. Cle vivante sur staging
-- (starter packs PAR COMPTE, lzy_shop/lzy_reroll, vitrine grisee sur SOI).
-- 26 : retrait de EVO_Maladie / EVO_MaladieAggrave / EVO_SciLevel / EVO_ShieldHP
-- (voies + extras science retires de staging). start_packs_bought reste en FIN
-- de liste. Les index des 164 premieres clefs (jusqu'a EVO_HideDivisionBody)
-- ne bougent pas.
-- 27 : + EVO::IsReadingMissive (bool appearance, FIN de liste). Pose de lecture
-- du bureau des missions (evo_missive) : meme mecanique que EVO::IsHoldingMap,
-- le client force la sequence sur TOUT joueur qui lit une missive.
-- 28 : + NCM_OSU_Enabled / NCM_OSU_InDuel (mini-jeu Duel de Rythme, osu 1v1).
-- Les jumeaux NCM_CS_* / NCM_PFC_* retombent sur le NW2 moteur via
-- tools/nw2_fallback_baseline.txt, mais ce fichier est une RATCHET : y
-- ajouter une cle fait echouer la CI. Les nouvelles cles sont donc ROUTEES.
-- InDuel = appearance : elle est lue SUR AUTRUI (busy-gate du menu C et du
-- grab) ; en NW2 brut elle serait limitee au PVS et un joueur hors PVS
-- paraitrait libre alors qu'il a de l'argent en jeu.
-- 29 : RE-ROUTAGE de EVO_Maladie / EVO_MaladieAggrave / EVO_SciLevel sur
-- PRE-STAGING. Le n 26 les avait retirees parce que les extras science sont
-- absents de STAGING — vrai la-bas, faux ici : evo_science les ECRIT toujours
-- (sv_science_maladies, sv_science_hub), donc depuis le merge elles
-- retombaient sur le NW2 moteur (repliquees a TOUS les clients) et les 3
-- remontaient au gate de routage. Reprises en FIN de liste : aucun index
-- existant ne bouge. EVO_ShieldHP n'est PAS repris, plus personne ne l'ecrit.
-- 30 : retour de EVO_ShieldHP avec la voie du KATANA. Le merge de staging
-- avait emporté EvoStyle.GiveShield, sa pilule de HUD et sa clé d'un bloc ;
-- Katana 4 (Rasen Zan) la réécrit, donc elle doit être routée. Fin de liste.
-- 31 : EVO_ClanDomaineSlot (emplacement du domaine achete par le clan).
-- Ajoutee en FIN de liste : aucun index existant ne bouge.
-- 32 : Level revient en int. Un commit l'avait passe en float sans bump ; GetEvoNWInt
-- ne lit que les cles ty=int, donc HUD / quetes retombaient sur le fallback 1.
-- 38 : + EVO_ParrainageFirstDone (bool owner-only, FIN de liste : aucun index de fil ne
-- bouge). On SAUTE 37 : main / staging / fix-nacim le portent DEJA pour un schema
-- DIFFERENT -> reprendre 37 ici rendrait le desaccord serveur/client SILENCIEUX, c'est
-- exactement l'incident du n 9.
-- 39 : premium passe en APPEARANCE. Le panneau cadeau de la boutique (gift.lua) le lit
-- sur AUTRUI (« Already Premium ») ; en owner-only la lecture rendait silencieusement 0 et
-- le gate de routage le signalait (CI rouge depuis le 07/30). Aucune position de fil ne
-- bouge, seule la diffusion change. 39 vierge sur toutes les lignees au 09/08 (main 32,
-- staging 38, pre-staging 31, louzzy 32, nacim 25).
-- 40 : + EVO_BusinessId / EVO_BusinessLeader (commerce bar) + EVO_BeerUntil /
-- EVO_BeerLevel (ivresse progressive). Ajoutés en FIN de liste.
-- 41 : + EVO_Amputation (int ÉTAT : 0 / 1 main / 2 bras / 3, 4 = idem + prothèse, evo_science). APPEARANCE : lue sur AUTRUI
-- par le rendu du corps (bodygroups) et par le menu C du praticien. FIN de liste. 41 vierge
-- sur toutes les lignées au 09/20 (main / staging / louzzy / fix-nacim à 40).
-- 42 : + EVO_DivSpellTest (string owner-only : rôle de division TESTÉ depuis le menu
-- d'équilibrage). FIN de liste. 42 vierge au 09/27 (staging / fix-nacim 41, main 40).
-- 43 : + EVO_ProsthesisColor (int : 0 = texture d'origine, sinon RGB+1 ; evo_science). APPEARANCE :
-- le proxy de matériau la lit sur AUTRUI. FIN de liste. 43 vierge au 09/28 (staging / fix-nacim / main à 42).
-- 44 : Level repasse de float a int (le passage en float du 09/29 mettait tout le monde niveau 1).
-- Aucune cle ajoutee. 44 vierge au 09/29 (staging / main a 43).
-- 45 : + EVO_FourreauCosmetic (int, APPEARANCE : bodygroup du fourreau, ajoute par Yugiro
-- le 09/30 sous « v44 » sans bump). FIN de liste. 45 vierge au 09/30 (staging / main a 44).
-- 46 : - EVO_FourreauCosmetic (fourreaux V6 supprimés). 46 vierge au 09/30.
-- 47 : + EVO_FourreauCosmetic (int : 0 = sans fourreau, n + 1 = bodygroup « cosmetic » n du
-- fourreau V7 ; dérivé du slot 8 d'inventaire, APPEARANCE). FIN de liste. 47 vierge au 09/30 (staging / fix-nacim à 46).
-- 48 : + EvoCatalyseur (string, APPEARANCE : effet d'arme dessiné chez tous) + rerolls_catalyseur
-- (int, owner-only : stock de rerolls) + EVO_Compagnon (string, APPEARANCE : id d'item du
-- compagnon qui suit, slot 9). FIN de liste. 48 vierge au 10/06 (main / staging / fix-nacim à 47).
-- 49 : + EVO_CompagnonNom (string, APPEARANCE : nom donné au compagnon, affiché au-dessus de
-- lui chez tous). FIN de liste. 49 vierge au 10/08 (fix-nacim à 48).
-- 50 : + EVO_CatalyseurOff (bool, APPEARANCE : coche inventaire, masque l'effet d'arme
-- chez tous sans perdre le catalyseur). FIN de liste. 50 vierge au 10/10.
-- 51 : effet temporaire de bière spéciale et échéance, owner-only, FIN de liste.
-- 52 : + EquipmentSpellCostReduction (float owner-only, FIN de liste).
-- Réduction du coût des sorts par l'équipement, lue par la barre du porteur.
-- 53 : + ShikaiLameReglage (string, APPEARANCE : décalage et rotation de la lame de shikai
-- dans la main, « <lame>|x|y|z|p|y|r », dessiné chez tous). FIN de liste. 53 vierge au 10/17
-- (staging / main / louzzy à 52, fix-nacim à 50).
-- 54 : + EquipmentComboSpeedPct (float, APPEARANCE : vitesse des combos utilisee
-- par le calcul partage des animations et des delais). Ajout en FIN de liste.
LZY_PlyState.VERSION = 54

-- ty: "string" | "int" | "bool" | "float"
-- appearance: remote clients need this value for models / combat presentation
-- Ordered list = wire indices for Full/Delta (uint8 id).
LZY_PlyState.SCHEMA = {
	-- Remote-visible appearance / identity
	{ key = "Nickname",              ty = "string", appearance = true },
	{ key = "FactionName",           ty = "string", appearance = true },
	{ key = "FactionRank",           ty = "int",    appearance = true },
	{ key = "FactionDivision",       ty = "int",    appearance = true },
	-- Local-primary (no server SetNW)
	{ key = "Character::Unique::ID", ty = "string", appearance = true },
	{ key = "Gender",                ty = "string", remote = false },
	{ key = "ArtSpirituel",          ty = "string", appearance = true },
	{ key = "StyleCombat",           ty = "string", appearance = true },
	{ key = "EvoFinisher",           ty = "string", appearance = true },
	{ key = "ReiatsuColor",          ty = "string", appearance = true },
	{ key = "NCM_FreeStyleSwap",     ty = "int",    remote = false },
	{ key = "Money",                 ty = "int",    remote = false },
	-- int, jamais float : les lecteurs passent tous par GetEvoNWInt("Level"), qui ne lit le
	-- sac que pour un int (en float : tout le monde niveau 1, reset d'arbre a 1 point, 29/09).
	{ key = "Level",                 ty = "int",    appearance = true },
	{ key = "Exp",                   ty = "int",    remote = false },
	{ key = "MaxEXP",                ty = "int",    remote = false },
	{ key = "EVO_AgeStart",          ty = "int",    remote = false },
	{ key = "EVO_AgeCreatedUnix",    ty = "int",    remote = false },
	{ key = "EVO_ShikaiUnlocked",    ty = "bool",   remote = false },
	{ key = "ShikaiPassive",         ty = "string", remote = false },
	-- Mode de la prise du grab superieur ("deplacer"/"etrangler"). Lu par le GRABBER
	-- (camera epaule) ET par sa VICTIME (tressaillement subi, cl_grab CalcVehicleView
	-- lit la cle sur l'attrapeur) : appearance obligatoire, owner-only la rendait
	-- muette chez la victime.
	{ key = "NCM_GrabMode",          ty = "string", appearance = true },
	-- Noclip cinematique whiteliste (commande SAM cine_noclip) : seul le joueur
	-- concerne le lit (rendu force cote client). Owner-only.
	{ key = "EVO_CineNoclip",        ty = "bool",   remote = false },
	-- Modele de lame attribue au rituel de la Salle Blanche : l'arme le prend
	-- PENDANT le shikai. appearance = true, les AUTRES joueurs doivent le voir.
	{ key = "ShikaiSkin",            ty = "string", appearance = true },
	{ key = "EVO_BankaiUnlocked",    ty = "bool",   remote = false },
	{ key = "BankaiPassive",         ty = "string", remote = false },
	{ key = "EVO_HollowMaskUnlocked", ty = "bool",  remote = false },
	{ key = "HollowMaskBoost",       ty = "string", remote = false },
	{ key = "EVO_LiberationSpiUnlocked", ty = "bool", remote = false },
	{ key = "LiberationSpiBoost",    ty = "string", remote = false },
	{ key = "EVO_PortalUnlocked",    ty = "bool",   remote = false },
	{ key = "hide_hair",             ty = "bool",   remote = false },
	{ key = "EVO_HideEpaulette",     ty = "bool",   appearance = true },
	{ key = "EVO_HideRankOutfit",    ty = "bool",   appearance = true },
	{ key = "EVO_HollowRaw",         ty = "bool",   appearance = true },
	{ key = "EVO_IsLarva",           ty = "bool",   appearance = true },
	{ key = "NCM_TF_Active",         ty = "bool",   appearance = true },
	{ key = "EVO_SheathedKatana",    ty = "string", appearance = true },
	{ key = "EVO_SheathedModel",     ty = "string", appearance = true },
	{ key = "BankaiWeaponOverride",  ty = "string", appearance = true },
	{ key = "KatanaSkin",            ty = "string", appearance = true },
	{ key = "KatanaName",            ty = "string", appearance = true },
	{ key = "ShikaiWord",            ty = "string", remote = false }, -- mot de libération (bande shikai), lu par son porteur seul
	{ key = "NCM_HakudaGauntlet",    ty = "string", appearance = true },
	{ key = "NCM_KatanaPos",         ty = "string", appearance = true },
	{ key = "start_pack_bought",     ty = "int",    remote = false },
	{ key = "NeedOnboarding",        ty = "int",    remote = false },
	{ key = "EvoPocketMap",          ty = "bool",   remote = false },
	{ key = "ncm_questState",        ty = "string", remote = false },
	{ key = "ncm_questPNJType",      ty = "string", remote = false },
	{ key = "NCM_QuestNoAbandon",    ty = "bool",   remote = false },
	{ key = "EVO_Confused",          ty = "bool",   remote = false },
	{ key = "EVO_SpellActionLock",   ty = "bool",   appearance = true },
	{ key = "EVO_AbilitiesLocked",   ty = "bool",   remote = false },
	{ key = "EVO_BlockDirectionalInput", ty = "bool", remote = false },
	{ key = "NCM_HideBindHUD",       ty = "bool",   remote = false },
	{ key = "NCM_ShowFlashstepBind", ty = "bool",   remote = false },
	{ key = "NCM_ShowFlyBind",       ty = "bool",   remote = false },
	{ key = "NCM_AerialCombatUnlocked", ty = "bool", remote = false },
	{ key = "NCM_FlashstepTrainingDone", ty = "bool", remote = false },
	{ key = "NCM_FlyTrainingDone",   ty = "bool",   remote = false },
	{ key = "NCM_WeaponTrainingDone", ty = "bool",  remote = false },
	{ key = "NCM_TutorialDone",      ty = "bool",   remote = false },
	{ key = "EVO_TutorialDone",      ty = "bool",   remote = false },
	{ key = "EVO_FFAHasChar",        ty = "bool",   remote = false },
	{ key = "NCM_TrainHits",         ty = "int",    remote = false },
	{ key = "NCM_TrainHitsMax",      ty = "int",    remote = false },
	{ key = "NCM_TrainParries",      ty = "int",    remote = false },
	{ key = "NCM_TrainParriesReq",   ty = "int",    remote = false },
	{ key = "NCM_TutoFamily",        ty = "string", remote = false },
	{ key = "EVO_DivBankBadge",      ty = "string", remote = false },
	{ key = "faction_sanction",      ty = "string", remote = false },
	{ key = "EVO_CombatLockUntil",   ty = "float",  remote = false },
	{ key = "EVO_CombatSwapUntil",   ty = "float",  remote = false },
	{ key = "EVO_FFACdUntil",        ty = "float",  remote = false },
	{ key = "EVO_KOStartTime",       ty = "float",  remote = false },
	{ key = "NCM_AssassinInvisEnd",  ty = "float",  remote = false }, -- HUD countdown owner-only
	{ key = "EVO_SitExitNoJump",     ty = "float",  remote = false },
	{ key = "EVO_SoinDebuffEnd",     ty = "float",  remote = false },
	-- appearance OBLIGATOIRE : le canHeal du menu C la lit sur TARGET (le medecin lit
	-- le patient). C'est un MIROIR re-derive par PushDebuffNW -- l'autorite est
	-- EvoHealBed.GetReopBlockRemaining ; l'ecrire de l'exterieur ne decide rien.
	{ key = "EVO_SoinReopBlockEnd",  ty = "float",  appearance = true },
	{ key = "LZY_InvKatanaDurability", ty = "float", remote = false },
	{ key = "NCM_TrainEnd",          ty = "float",  remote = false },
	{ key = "RunBaseSpeed",          ty = "float",  remote = false },
	{ key = "karma",                 ty = "float",  remote = false },
	{ key = "specpunches",           ty = "float",  remote = false },
	{ key = "Reiatsu",               ty = "int",    remote = false },
	{ key = "MaxReiatsu",            ty = "int",    remote = false },
	-- Large owner-only payloads: reliable deltas, never engine NW strings.
	{ key = "LZY_SpellSelector_Equipped", ty = "string", remote = false },
	{ key = "LZY_Reroll_Pities",      ty = "string", remote = false },
	{ key = "EVO_HiddenAccessories",  ty = "string", remote = false },
	{ key = "lzy_shop_cosm_state",    ty = "string", remote = false },
	{ key = "coins",                  ty = "int",    remote = false },
	{ key = "premium",                ty = "int",    appearance = true }, -- lu sur autrui (panneau cadeau)
	{ key = "LZY_Shop_PremiumEndDate", ty = "string", remote = false },
	{ key = "queue_bypass",           ty = "int",    remote = false },
	{ key = "queue_bypass_end_date",  ty = "string", remote = false },
	{ key = "rerolls_art_spirituel",  ty = "int",    remote = false },
	{ key = "rerolls_aura_spirituel", ty = "int",    remote = false },
	{ key = "rerolls_style_execution", ty = "int",   remote = false },
	{ key = "rerolls_combat_style",   ty = "int",    remote = false },
	{ key = "BattlePass_IsPremium",   ty = "bool",   remote = false },
	{ key = "BattlePass_XP",          ty = "int",    remote = false },
	{ key = "BattlePass_LastBpLevel", ty = "int",    remote = false },
	{ key = "BattlePass_CanClaimLevel", ty = "int",  remote = false },
	-- ── Migrated off NW2 (append only: id is the wire index) ─────────────
	-- Remote clients read these for OTHER players, so they must stay broadcast:
	-- appearance keeps the same visibility as NW2 without burning an NW2 slot.
	{ key = "EVO_MaxHP",              ty = "int",    appearance = true }, -- GetMaxHealth des autres = 100 côté client
	{ key = "EVO_StaffMode",          ty = "bool",   appearance = true },
	{ key = "EVO_AnimChar",           ty = "bool",   appearance = true },
	{ key = "InCharacterMenu",        ty = "bool",   appearance = true }, -- lu sur ent/candidate distants (models, meet, run)
	{ key = "MUGEN_CtxMenuOpen",      ty = "bool",   appearance = true },
	{ key = "EVO_SoinDebuff",         ty = "bool",   appearance = true },
	{ key = "NCM_TF_Class",           ty = "string", appearance = true }, -- CalcMainActivity anime aussi les distants
	{ key = "NCM_TF_AtkSeq",          ty = "string", appearance = true },
	{ key = "NCM_TF_AtkUntil",        ty = "float",  appearance = true },
	{ key = "aqa_god",                ty = "bool",   appearance = true },
	{ key = "aqa_frozen",             ty = "bool",   appearance = true },
	{ key = "aqa_mute_voice",         ty = "bool",   appearance = true },
	{ key = "aqa_mute_text",          ty = "bool",   appearance = true },
	{ key = "EVO_IsVasto",            ty = "bool",   appearance = true }, -- Vasto = modèle plus grand
	{ key = "EVO_AnimatorHollow",     ty = "bool",   appearance = true }, -- cl_models lit la clé sur ent
	{ key = "EVO_HealBed_Downed",     ty = "bool",   appearance = true }, -- IsDowned(target) / cl_operation lisent la cible
	{ key = "EVO::IsHoldingMap",      ty = "bool",   appearance = true }, -- carte en main : cl_map_hold force la pose sur TOUT joueur
	{ key = "EVO::IsHoldingAffiche",  ty = "bool",   appearance = true }, -- affiche en main (evo_affiche) : meme pose forcee que la carte
	-- Owner/serveur uniquement : lectures client confirmées sur LocalPlayer ou SetupMove.
	{ key = "LZY_SkillTree_SkillPoints", ty = "int", remote = false },
	{ key = "LZY_SkillTree_Reset",    ty = "int",    remote = false },
	{ key = "LZY_GeneralPointMax",    ty = "int",    remote = false },
	{ key = "RunDamageLocked",        ty = "bool",   remote = false },
	{ key = "CreatorCode",            ty = "string", remote = false },
	{ key = "EVO_Palier",             ty = "int",    remote = false },
	{ key = "EVO_PalierPaye",         ty = "int",    remote = false },
	{ key = "EVO_PalierResp",         ty = "bool",   remote = false },
	{ key = "EVO_FamilyPerms",        ty = "int",    remote = false },
	{ key = "EVO_ClanSpells",         ty = "int",    remote = false },
	{ key = "EVO_ClanBuildingAccess", ty = "bool",   remote = false },
	{ key = "EVO_WantedBounty",       ty = "int",    remote = false },
	{ key = "EVO_CharacterLoading",   ty = "bool",   remote = false },
	{ key = "EVO_SciBypass",          ty = "bool",   remote = false },
	{ key = "evo_whitelisted",        ty = "bool",   remote = false },
	{ key = "EVO_HollowMaskUnlimited", ty = "bool",  remote = false },
	{ key = "EVO_LiberationSpiUnlimited", ty = "bool", remote = false },
	{ key = "EVO_AdminFrozen",        ty = "bool",   remote = false },
	{ key = "EVO_AdminJailed",        ty = "bool",   remote = false },
	{ key = "EVO_AdminDisarmed",      ty = "bool",   remote = false },
	{ key = "NCM_TF_MaxHP",           ty = "int",    remote = false },
	{ key = "InputLagDuration",       ty = "float",  remote = false },
	{ key = "InputLagIntensity",      ty = "float",  remote = false },
	{ key = "EVO_AerialDashUntil",    ty = "float",  remote = false },
	{ key = "EVO_AerialKnockUntil",   ty = "float",  remote = false },
	{ key = "EVO_FlyHitBlockUntil",   ty = "float",  remote = false },
	{ key = "EVO_ThrowImmuneUntil",  ty = "float",  appearance = true }, -- fin d'immunite au throw aerien (logo de garde BLEU chez tous)
	{ key = "EVO_ActiveToggleSpell",  ty = "string", remote = false },
	{ key = "Evo_RunningSpellID",     ty = "string", remote = false },
	{ key = "EVO_ChargingProjectile_SpellID", ty = "string", remote = false },
	{ key = "EVO_HealBed_Healing",    ty = "bool",   remote = false }, -- lu sur l'acteur (canHeal/CreateMove), jamais sur la cible
	{ key = "EVO_HealBed_Operated",   ty = "bool",   remote = false }, -- patient sous opération (CreateMove lock client)
	{ key = "EVO::IsReadingFaction",  ty = "bool",   appearance = true }, -- lu sur autrui dans UpdateAnimation (pose de lecture)
	-- Portails (senkaimon / garganta). Ecrits via ENT.NWInside/NWUntil, donc en VARIABLE :
	-- invisibles au generateur de baseline, ils tombaient sur NW2 sans que rien ne le voie.
	-- Or NW2 n'envoie ses deltas qu'aux clients qui ont l'entite en PVS : le serveur remet
	-- "inside" a false dans le meme tick que le SetPos du TP, donc les clients qui perdent
	-- le joueur a cet instant ne recevaient JAMAIS le false et le voyaient invisible pour
	-- toujours. L'appearance part a TOUS les humains (PushAppearanceFull), pas au PVS.
	{ key = "EvoSenkaiInside",        ty = "bool",   appearance = true },
	{ key = "EvoSenkaiUntil",         ty = "float",  appearance = true },
	{ key = "EvoGargantaInside",      ty = "bool",   appearance = true },
	{ key = "EvoGargantaUntil",       ty = "float",  appearance = true },
	-- Instances (tuto / training). Meme classe de bug que les portails : Leave remet
	-- NCM_Instanced a false APRES ShowWorldToPlayer, alors que SetPreventTransmit ne
	-- prend effet qu'au snapshot suivant. Sur NW2 le clear n'atteint jamais les
	-- observateurs encore bloques, et le Think client leur pose SetNoDraw(true) pour
	-- toujours. Appearance = broadcast a tous les humains + resync PVS.
	{ key = "NCM_Instanced",          ty = "bool",   appearance = true },
	{ key = "NCM_InstanceZone",       ty = "string", appearance = true },
	{ key = "NCM_InstanceOwnerIdx",   ty = "int",    appearance = true },
	-- Whitelist STREAMER (evo_staff) : tag noclip + protection kick/mute/ban SA-only.
	{ key = "EVO_IsStreamer",         ty = "bool",   appearance = true },
	-- MASQUE D'ANONYMAT (slot 7, 09/08) : le porteur s'affiche « ??? » partout où son nom
	-- RP apparaît. Dérivé SERVEUR de l'équipement (lzy_character/server/sv_main.lua,
	-- LZY_Character_SyncEquippedAccessories) — jamais posé par le client.
	-- appearance = true OBLIGATOIRE : le drapeau est lu par les AUTRES clients, et il doit
	-- avoir exactement la même portée que « Nickname » (broadcast à tous les humains, hors
	-- PVS). Sur NW2 brut il serait limité au PVS -> le vrai nom réapparaîtrait de loin.
	{ key = "EVO_AnonMask",           ty = "bool",   appearance = true },
	-- Formateur whitelisté (coche gestion faction) + éligibilité Shikai (quête prog).
	-- Owner-only : lectures client confirmées sur LocalPlayer ; serveur lit autrui en local.
	{ key = "EVO_FactionFormateur",   ty = "bool",   remote = false },
	{ key = "EVO_ShikaiEligible",     ty = "bool",   remote = false },
	-- Lecture d'un livre (evo_livre) : forcé en UpdateAnimation sur TOUS les clients qui
	-- voient le lecteur — appearance obligatoire (sinon remote = default silencieux).
	{ key = "EVO::IsReadingLivre",    ty = "bool",   appearance = true },
	-- Jetons de coffre cosmétique (lzy_shop, recyclage 3 cosmétiques -> 1 jeton).
	{ key = "rerolls_coffre_cosmetique", ty = "int", remote = false },
	-- Invite au rayon « Secret defense » des archives (evo_livre). Lue sur SOI
	-- uniquement (EVO_LIVRE.HasSecretAccess) : owner-only.
	{ key = "EVO_LivreHabilite",      ty = "bool",   remote = false },
	-- Taille posée par le staff (commande SAM `scale`) ou par l'outil animateur.
	-- 0 = pas d'override, on retombe sur la taille du personnage. Surcouche lue par
	-- LZY_Character_ResolveModelScale (sh_scale.lua) des DEUX côtés : sans elle, chaque
	-- client remettait le joueur à la taille de son perso au premier rebuild (changement
	-- de tenue, respawn, entrée dans le PVS) et deux joueurs voyaient deux tailles.
	-- appearance OBLIGATOIRE (les autres clients posent le model scale avec).
	{ key = "EVO_StaffScale",         ty = "float",  appearance = true },
	-- Coche inventaire « Cacher la tenue de division » (accessoire body de
	-- specialite). appearance : AppendRankCosmetics lit la cle SUR le porteur.
	{ key = "EVO_HideDivisionBody",   ty = "bool",   appearance = true },
	-- Starter packs achetés PAR COMPTE (lzy_shop/lzy_reroll, lignée STAGING) :
	-- lu sur LocalPlayer pour griser la vitrine. Distinct de start_pack_bought
	-- (0/1 par personnage, table characters).
	{ key = "start_packs_bought",     ty = "int",    remote = false },
	-- Coche inventaire « Porter les gantelets » (Hakuda) : le modèle bonemergé
	-- reste visible hors arme de combat. appearance : les autres clients
	-- dessinent le gantelet sur le porteur (cl_hakuda_gauntlet.lua).
	{ key = "NCM_HakudaAlwaysWear",   ty = "bool",   appearance = true },
	-- Missive en main (evo_missive) : cl force la pose de lecture sur TOUT joueur.
	{ key = "EVO::IsReadingMissive",  ty = "bool",   appearance = true },
	-- Mini-jeu Duel de Rythme : coche du menu C (lue sur SOI) + drapeau
	-- « en duel » (lu sur AUTRUI par les busy-gates).
	{ key = "NCM_OSU_Enabled",        ty = "bool",   remote = false },
	{ key = "NCM_OSU_InDuel",         ty = "bool",   appearance = true },
	-- v29 : lues SUR SOI seulement (carte de maladie et onglet niveau du labo).
	{ key = "EVO_Maladie",            ty = "string", remote = false },
	{ key = "EVO_MaladieAggrave",     ty = "bool",   remote = false },
	{ key = "EVO_SciLevel",           ty = "int",    remote = false },
	-- PV du bouclier spirituel (EvoStyle.GiveShield, Katana 4 Rasen Zan) : lu
	-- uniquement sur SOI (pilule HUD lzy_hud), fin de liste.
	{ key = "EVO_ShieldHP",           ty = "float",  remote = false },
	-- v31 : emplacement du domaine achete par le clan (lu sur soi seulement,
	-- le client apprend les AUTRES emplacements par evo_clan:dom_slots).
	{ key = "EVO_ClanDomaineSlot",    ty = "string", remote = false },
	-- v38 : le compte a deja eu son 1er perso REEL (miroir de players.parrainage_first_done,
	-- evo_parrainage) -> le createur n'affiche plus jamais le champ « code de parrainage ».
	-- Lue sur SOI uniquement (CreatePage2). FIN de liste : aucun index de fil ne bouge.
	{ key = "EVO_ParrainageFirstDone", ty = "bool", remote = false },
	-- v40 : commerce (evo_business). BusinessId lu sur AUTRUI (menu propriété /
	-- busy-gates) -> appearance. Beer* owner-only (FX + Move sur soi).
	{ key = "EVO_BusinessId",         ty = "string", appearance = true },
	{ key = "EVO_BusinessLeader",     ty = "bool",   appearance = true },
	{ key = "EVO_BeerUntil",          ty = "float",  remote = false },
	{ key = "EVO_BeerLevel",          ty = "int",    remote = false },
	{ key = "EVO_Amputation",         ty = "int",    appearance = true },
	-- v42 : test d'un sort de division depuis l'équilibrage (lu sur SOI : sélecteur).
	{ key = "EVO_DivSpellTest",       ty = "string", remote = false },
	-- v43 : couleur de la prothèse (proxy EVOProsthesisColor, lu sur tous les joueurs).
	{ key = "EVO_ProsthesisColor",    ty = "int",    appearance = true },
	-- v47 : fourreau V7 (0 = sans, n + 1 = cosmétique n), lu sur tous les joueurs.
	{ key = "EVO_FourreauCosmetic",   ty = "int",    appearance = true },
	-- v48 : catalyseur d'arme (id du catalogue, lu sur tous les joueurs) + son stock de rerolls.
	{ key = "EvoCatalyseur",          ty = "string", appearance = true },
	{ key = "rerolls_catalyseur",     ty = "int",    remote = false },
	-- v48 : compagnon équipé (slot 9), simulé chez tous les clients proches.
	{ key = "EVO_Compagnon",          ty = "string", appearance = true },
	-- v49 : nom du compagnon (evo_compagnons, Dresseur), affiché au-dessus de lui.
	{ key = "EVO_CompagnonNom",       ty = "string", appearance = true },
	-- v50 : catalyseur masqué (coche inventaire). L'id reste en base ; le rendu ne le dessine plus.
	{ key = "EVO_CatalyseurOff",      ty = "bool",   appearance = true },
	{ key = "EVO_BeerEffect",         ty = "string", remote = false },
	{ key = "EVO_BeerEffectUntil",    ty = "float",  remote = false },
	{ key = "EquipmentSpellCostReduction", ty = "float", remote = false },
	-- v53 : réglage de la lame de shikai en main (evo_blanc), lu sur tous les porteurs.
	{ key = "ShikaiLameReglage",      ty = "string", appearance = true },
	-- v54 : bonus de vitesse des combos d'equipement, partage client/serveur.
	{ key = "EquipmentComboSpeedPct", ty = "float", appearance = true },
}

LZY_PlyState.BY_KEY = {}
LZY_PlyState.BY_ID = {}
for id, def in ipairs(LZY_PlyState.SCHEMA) do
	def.id = id
	LZY_PlyState.BY_KEY[def.key] = def
	LZY_PlyState.BY_ID[id] = def
end

LZY_PlyState.APPEARANCE = {}
for _, def in ipairs(LZY_PlyState.SCHEMA) do
	if def.appearance then
		LZY_PlyState.APPEARANCE[#LZY_PlyState.APPEARANCE + 1] = def
	end
end

local function DefaultFor(ty)
	if ty == "string" then return "" end
	if ty == "bool" then return false end
	return 0
end

function LZY_PlyState.Default(key)
	local def = LZY_PlyState.BY_KEY[key]
	if not def then return nil end
	if key == "Character::Unique::ID" then return "none" end
	if key == "Level" then return 1 end
	if key == "MaxReiatsu" then return 100 end
	if key == "LZY_SpellSelector_Equipped" then return "[]" end
	if key == "LZY_Reroll_Pities" or key == "EVO_HiddenAccessories" then return "{}" end
	return DefaultFor(def.ty)
end

function LZY_PlyState.Normalize(key, val)
	local def = LZY_PlyState.BY_KEY[key]
	if not def then return val end
	if def.ty == "string" then
		return tostring(val or "")
	elseif def.ty == "bool" then
		return val == true or val == 1 or val == "1"
	elseif def.ty == "float" then
		return tonumber(val) or 0
	else
		return math.floor(tonumber(val) or 0)
	end
end

--- Read: server bag → client local bag (LP) → NW fallback (client remotes / unmigrated).
function LZY_PlyState.Get(ply, key, fallback)
	if not IsValid(ply) then
		if fallback ~= nil then return fallback end
		return LZY_PlyState.Default(key)
	end
	local def = LZY_PlyState.BY_KEY[key]
	local fb = fallback
	if fb == nil then fb = LZY_PlyState.Default(key) end

	if SERVER then
		local bag = ply._lzyState
		if istable(bag) and bag[key] ~= nil then
			return bag[key]
		end
		return fb
	end

	-- Client
	local lp = LocalPlayer()
	if IsValid(lp) and ply == lp and istable(LZY_LocalState) and LZY_LocalState[key] ~= nil then
		return LZY_LocalState[key]
	end
	if def and def.appearance and istable(LZY_RemoteState) then
		local remote = LZY_RemoteState[ply:EntIndex()]
		if remote and remote.ent == ply and remote.values and remote.values[key] ~= nil then
			return remote.values[key]
		end
	end

	if not def then
		return fb
	end
	if def.ty == "string" then
		return ply:GetEvoNWString(key, isstring(fb) and fb or "")
	elseif def.ty == "bool" then
		return ply:GetEvoNWBool(key, fb == true)
	elseif def.ty == "float" then
		return ply:GetEvoNWFloat(key, tonumber(fb) or 0)
	else
		return ply:GetEvoNWInt(key, tonumber(fb) or 0)
	end
end

function LZY_PlyState.HasBag(ply)
	return IsValid(ply) and istable(ply._lzyState)
end

-- Player meta convenience (shared readers).
local meta = FindMetaTable("Player")

function meta:LzyGet(key, fallback)
	return LZY_PlyState.Get(self, key, fallback)
end

function meta:GetCharFaction()
	return LZY_PlyState.Get(self, "FactionName", "")
end

function meta:GetCharMoney()
	return LZY_PlyState.Get(self, "Money", 0)
end

function meta:GetCharLevel()
	return LZY_PlyState.Get(self, "Level", 1)
end

function meta:GetCharReiatsu()
	return LZY_PlyState.Get(self, "Reiatsu", 0)
end

function meta:GetCharMaxReiatsu()
	return LZY_PlyState.Get(self, "MaxReiatsu", 100)
end
