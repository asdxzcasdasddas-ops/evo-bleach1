-- "addons\\lzy_character\\lua\\lzy_character\\shared\\sh_scale.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ─────────────────────────────────────────────────────────────────────────
-- SCALE PERSONNAGE — point UNIQUE (select / larva / âme errante / respawn)
-- Resolve = valeur ; Apply = un seul SetModelScale (no-op si déjà bon).
-- Schedule = apply différé (Spawn / SetModel remettent le scale à 1).
-- Ne JAMAIS brancher sur LZY_IsLarvaCharacter / EVO_HollowRaw (Lost Soul = raw aussi).
-- ─────────────────────────────────────────────────────────────────────────

-- ── SURCOUCHE STAFF / ANIMATEUR ──────────────────────────────────────────
-- Pourquoi elle existe : la commande SAM `scale` et l'outil animateur posaient un
-- SetModelScale SEC sur le joueur. Or ce résolveur est rejoué par TOUS les chemins de
-- ré-application, côté serveur ET côté CHAQUE client (réception du composite,
-- changement de tenue, respawn, entrée dans le PVS). Chacun de ces chemins renvoyait
-- l'échelle du PERSONNAGE et remettait donc le joueur à ~1 localement. D'où les deux
-- symptômes rapportés : « je change de tenue et je redeviens petit », et surtout
-- « les autres me voient grand, moi je me vois petit » (seuls les clients qui
-- rebuildaient écrasaient la valeur, les autres gardaient l'ancienne).
--
-- La correction tient en un point : l'échelle staff est un NW2Float RÉPLIQUÉ, lu ICI
-- en priorité. Tous les chemins existants convergent alors sur la même valeur, sans
-- un seul hook Think ni timer de surveillance.
LZY_CHARACTER_STAFF_SCALE_KEY = "EVO_StaffScale"
LZY_CHARACTER_STAFF_SCALE_MIN = 0.1
LZY_CHARACTER_STAFF_SCALE_MAX = 5

--- Échelle staff active du joueur, ou nil si aucune (0 = pas d'override).
function LZY_Character_StaffScale(ply)
	if not IsValid(ply) then return nil end
	if not (ply.IsPlayer and ply:IsPlayer() and ply.GetEvoNWFloat) then return nil end
	-- Clé écrite EN DUR (et pas via LZY_CHARACTER_STAFF_SCALE_KEY) : le gate de routage
	-- réseau inspecte le source, une clé passée par variable lui est invisible.
	local n = tonumber(ply:GetEvoNWFloat("EVO_StaffScale", 0)) or 0
	if n <= 0 then return nil end
	return math.Clamp(n, LZY_CHARACTER_STAFF_SCALE_MIN, LZY_CHARACTER_STAFF_SCALE_MAX)
end

-- Offsets de vue par DÉFAUT du joueur (mêmes constantes que ncm_transform).
local VIEW_STAND, VIEW_DUCK = 64, 28

--- La caméra ne suit PAS le model scale : le moteur garde l'offset de vue d'origine.
--- Un staff à l'échelle 3 avait donc les yeux à hauteur de genoux et « se voyait tout
--- petit » pendant que les autres le voyaient grand. On ne touche la vue QUE si un
--- override staff est actif : les échelles de personnage (0.9..1.1) et de larve
--- gardent l'offset moteur exact, pour ne rien changer au jeu existant.
function LZY_Character_ApplyScaleViewOffset(ply)
	if not SERVER then return end
	if not (IsValid(ply) and ply.IsPlayer and ply:IsPlayer()) then return end
	local sc = LZY_Character_StaffScale(ply)
	if not sc then
		if ply._lzyScaleViewApplied then
			ply._lzyScaleViewApplied = nil
			ply:SetViewOffset(Vector(0, 0, VIEW_STAND))
			ply:SetViewOffsetDucked(Vector(0, 0, VIEW_DUCK))
		end
		return
	end
	if ply._lzyScaleViewApplied == sc then return end
	ply._lzyScaleViewApplied = sc
	ply:SetViewOffset(Vector(0, 0, VIEW_STAND * sc))
	ply:SetViewOffsetDucked(Vector(0, 0, VIEW_DUCK * sc))
end

--- Pose (ou retire avec nil / 0 / 1) l'échelle staff. SERVEUR uniquement.
--- dureeLerp optionnelle : interpolation moteur à la pose (l'outil animateur y tient),
--- les ré-applications ultérieures restent instantanées.
--- Retourne la valeur retenue, ou nil si l'override est levé.
function LZY_Character_SetStaffScale(ply, scale, dureeLerp)
	if not SERVER then return nil end
	if not (IsValid(ply) and ply.IsPlayer and ply:IsPlayer() and ply.SetEvoNWFloat) then return nil end
	local n = tonumber(scale) or 0
	-- Tolérance : 1 exactement = retour à l'échelle du personnage, PAS un override à 1
	-- (sinon `scale 1` figeait le joueur à 1 et cassait larve / âme errante / sculpteur).
	if n <= 0 or math.abs(n - 1) < 0.001 then
		ply:SetEvoNWFloat("EVO_StaffScale", 0)
		n = nil
	else
		n = math.Clamp(n, LZY_CHARACTER_STAFF_SCALE_MIN, LZY_CHARACTER_STAFF_SCALE_MAX)
		ply:SetEvoNWFloat("EVO_StaffScale", n)
	end
	local dt = tonumber(dureeLerp) or 0
	if n and dt > 0 then
		ply:SetModelScale(n, dt)
		LZY_Character_ApplyScaleViewOffset(ply)
		return n
	end
	local d = ply.GetPlayerModelData and ply:GetPlayerModelData() or nil
	LZY_Character_ApplyModelScale(ply, d)
	return n
end

--- Lève l'override SANS reposer d'échelle : pour les appelants qui posent eux-mêmes la
--- bonne taille juste après (changement de perso, incarnation hollow). Repasser par
--- SetStaffScale y serait risqué : il ré-applique depuis les data perso, qui peuvent
--- être encore celles d'AVANT le changement.
function LZY_Character_ClearStaffScale(ply)
	if not SERVER then return end
	if not (IsValid(ply) and ply.IsPlayer and ply:IsPlayer() and ply.SetEvoNWFloat) then return end
	ply:SetEvoNWFloat("EVO_StaffScale", 0)
	LZY_Character_ApplyScaleViewOffset(ply)
end

--- Résout l'échelle d'apparence à partir des data perso (body_model prioritaire).
function LZY_Character_ResolveModelScale(data, ply)
	-- Override staff AVANT tout : il doit gagner sur perso / larve / âme errante, et
	-- rester valable même quand data est nil (chemins qui appellent sans data).
	local staff = LZY_Character_StaffScale(ply)
	if staff then return staff end
	if not istable(data) then return 1 end
	local body = data.body_model
	if EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(body)
		and EVO_HollowProg.GetScale then
		local seed = data.unique_id
		if (not seed or seed == "" or seed == "none") and IsValid(ply) then
			seed = ply:GetUniqueID()
			if not seed or seed == "" or seed == "none" then seed = ply:SteamID64() end
		end
		return EVO_HollowProg.GetScale(seed)
	end
	if EVO_LostSoul and EVO_LostSoul.IsLostSoulBodyModel and EVO_LostSoul.IsLostSoulBodyModel(body) then
		return (EVO_LostSoul.Config and tonumber(EVO_LostSoul.Config.ModelScale)) or 1
	end
	return math.Clamp(tonumber(data.scale) or 1, 0.9, 1.1)
end

--- Pose l'échelle UNE fois (no-op si déjà à ±0.001).
function LZY_Character_ApplyModelScale(ent, data)
	if not IsValid(ent) then return nil end
	local sc = LZY_Character_ResolveModelScale(data, ent)
	-- Vue AVANT le court-circuit : l'échelle peut déjà être bonne alors que la vue a été
	-- remise à plat par un respawn (PlayerSpawn réinitialise l'offset de vue).
	LZY_Character_ApplyScaleViewOffset(ent)
	if math.abs((ent.GetModelScale and ent:GetModelScale() or 1) - sc) < 0.001 then
		return sc
	end
	if ent.SetModelScale then ent:SetModelScale(sc, 0) end
	return sc
end

--- Apply différé : PlayerSpawn / SetModel remettent le scale à 1 dans le même tick.
--- Sans ce délai, CreateSelectedCharacter → Spawn() laisse tout le monde à 1.0.
function LZY_Character_ScheduleModelScale(ply, data)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if istable(data) then ply._lzyPendingScaleData = data end
	local tid = "LZY_CharScale_" .. (ply:SteamID64() or tostring(ply:EntIndex()))
	timer.Create(tid, 0.05, 1, function()
		if not IsValid(ply) then return end
		local d = ply._lzyPendingScaleData
		ply._lzyPendingScaleData = nil
		if not istable(d) and ply.GetPlayerModelData then
			d = ply:GetPlayerModelData()
		end
		if istable(d) then LZY_Character_ApplyModelScale(ply, d) end
	end)
end

if CLIENT then
	-- COURSE DE RÉPLICATION : la valeur peut arriver APRÈS le rebuild du composite (même
	-- classe de bug que EVO_HollowRaw dans cl_models). Le client aurait alors posé
	-- l'échelle du perso et ne serait jamais repassé dessus, ce qui laissait un
	-- observateur sur l'ancienne taille. Les deux hooks tirent PILE à la réception de la
	-- valeur : coût nul, ni Think ni timer de surveillance.
	--   EVO:Appearance:Changed = les AUTRES joueurs (canal appearance)
	--   LZY:PlyState:Changed   = LocalPlayer (canal owner)
	local function resync(ent, key)
		if key ~= LZY_CHARACTER_STAFF_SCALE_KEY then return end
		if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return end
		local d = GetPlayerCharacterData and GetPlayerCharacterData(ent) or nil
		LZY_Character_ApplyModelScale(ent, d)
	end
	hook.Add("EVO:Appearance:Changed", "LZY:Character:StaffScaleSync", resync)
	hook.Add("LZY:PlyState:Changed", "LZY:Character:StaffScaleSync", resync)
end
