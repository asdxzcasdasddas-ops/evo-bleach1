-- "addons\\lzy_character\\lua\\lzy_character\\shared\\sh_character.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local meta = FindMetaTable("Player")

function meta:GetUniqueID()
    if LZY_PlyState and LZY_PlyState.Get then
        local v = LZY_PlyState.Get(self, "Character::Unique::ID", "none")
        if v ~= nil and v ~= "" then return v end
    end
    return self:GetEvoNWString("Character::Unique::ID", "none")
end


-- Cle net CSM / GetPMBatch. Les bots Source partagent SteamID64 "0" : sans cle unique,
-- GetPMBatch n'envoie qu'UN seul modele pour tous les bots (impossible de reproduire pop 45+).
function LZY_Character_NetPlayerKey(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return "" end
	if ply.IsBot and ply:IsBot() then
		return "BOT" .. tostring(ply:EntIndex())
	end
	return ply:SteamID64() or ""
end


-- ─────────────────────────────────────────────────────────────────────────
-- GENRE -> MODÈLE DE FACE (source PARTAGÉE serveur + client)
-- Le SERVEUR pose la face du joueur (CreateSelectedCharacter) et le CLIENT vérifie
-- qu'elle correspond aux données perso avant de bone-merger corps/cheveux
-- (LZY_Character_FaceModelMatches). Les deux côtés avaient leur propre règle :
--   serveur : `gender == "m"` -> tout ce qui n'est pas EXACTEMENT "m" prenait la face FÉMININE
--   client  : NormalizeGender -> tout ce qui n'est pas "f"/"female" attend la face MASCULINE
-- Pour toute row dont le genre n'est ni "m" ni "f"/"female" (nil, "", "M", "male",
-- "homme" — rows legacy), les deux ne parlaient donc PAS du même modèle : le test du
-- client était faux À VIE, TryCreatePlayerClientModels refusait le bone-merge, et le
-- joueur restait « tête + katana » (sans corps ni cheveux) chez TOUS les observateurs,
-- définitivement — le bouton « Rafraîchir apparences » n'y pouvait rien (la data était bonne).
-- Une seule source ici, comme l'âge plus bas et pour la même raison.
-- Les copies client (cl_character_selection / cl_character_creation, gardées HORS de
-- config.lua par une exigence antérieure) sont IDENTIQUES à celle-ci : toute divergence
-- (ex. accepter "femme" d'un seul côté) recrée le bug.
-- ─────────────────────────────────────────────────────────────────────────
LZY_CHARACTER_CONFIG = LZY_CHARACTER_CONFIG or {}

--- "male" / "female" à partir d'un genre DB ("m", "f", "male", "female", nil…).
function LZY_CHARACTER_CONFIG.NormalizeGender(gender)
    if not gender then return "male" end
    local g = string.lower(tostring(gender))
    if g == "f" or g == "female" then return "female" end
    return "male"
end

--- Modèle de FACE (tête) attendu pour ce genre. Le corps vient de characterData.body_model.
function LZY_CHARACTER_CONFIG.GetDefaultFaceModel(gender)
    return LZY_CHARACTER_CONFIG.NormalizeGender(gender) == "female"
        and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE
        or LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE
end

-- ─────────────────────────────────────────────────────────────────────────
-- ÂGE DU PERSONNAGE (demande user)
-- L'âge = age_start (choisi à la création, 15-25) + 1 AN par JOUR RÉEL écoulé
-- (demande user 2026-07-27 ; c'était 2 ans/jour depuis le 23/07). Même rythme que
-- l'ANNÉE RP du serveur (lzy_hud cl_server_year lit CETTE constante) -> l'année du
-- monde et l'âge des persos restent synchrones. Le bonus = +1% reiatsu max ET +1% dégâts de sort
-- PAR TRANCHE DE 10 ANS d'âge, SANS plafond (appliqué côté serveur dans
-- lzy_stats — règle projet : tout scaling passe par lui).
-- Calcul partagé ici pour que serveur (stats) ET client (HUD, char-select) donnent
-- le MÊME âge. os.time() renvoie l'heure système (UTC) des deux côtés : la
-- granularité (12 h) absorbe le léger écart client/serveur.
-- ─────────────────────────────────────────────────────────────────────────
EVO_CHARACTER_AGE_SECONDS_PER_YEAR = 86400 -- 24 h réelles = 1 an in-game (1 an / jour)

-- Âge courant à partir des 2 champs DB (age_start, age_created_unix).
function EVO_ComputeCharacterAge(ageStart, ageCreatedUnix)
    ageStart = tonumber(ageStart) or 0
    ageCreatedUnix = tonumber(ageCreatedUnix) or 0
    if ageStart <= 0 then return 0 end
    local elapsedYears = 0
    if ageCreatedUnix > 0 then
        elapsedYears = math.floor((os.time() - ageCreatedUnix) / EVO_CHARACTER_AGE_SECONDS_PER_YEAR)
        if elapsedYears < 0 then elapsedYears = 0 end -- horloge client en retard : pas d'âge négatif
    end
    return ageStart + elapsedYears
end

-- Années nécessaires pour +1 % de bonus. Global (pas une constante figée) pour
-- que l'éditeur d'équilibrage puisse le régler en jeu ; il repose la valeur au
-- boot depuis la base. Plus le chiffre est petit, plus l'âge compte.
EVO_AGE_BONUS_YEARS_PER_PCT = EVO_AGE_BONUS_YEARS_PER_PCT or 10

-- Bonus en % (reiatsu max & dégâts de sort) : +1% par tranche d'années, sans plafond.
function EVO_CharacterAgeBonusPct(age)
    age = tonumber(age) or 0
    if age <= 0 then return 0 end
    local div = tonumber(EVO_AGE_BONUS_YEARS_PER_PCT) or 10
    if div <= 0 then div = 10 end
    return math.floor(age / div)
end

-- Âge courant du perso ACTIF d'un joueur (age_start / age_created_unix networkés
-- par lzy_character au chargement du perso). Renvoie 0 si pas de perso chargé.
function meta:GetCharacterAge()
    local ageStart, ageCreated
    if LZY_PlyState and LZY_PlyState.Get then
        ageStart = LZY_PlyState.Get(self, "EVO_AgeStart", 0)
        ageCreated = LZY_PlyState.Get(self, "EVO_AgeCreatedUnix", 0)
    else
        ageStart = self:GetEvoNWInt("EVO_AgeStart", 0)
        ageCreated = self:GetEvoNWInt("EVO_AgeCreatedUnix", 0)
    end
    return EVO_ComputeCharacterAge(ageStart, ageCreated)
end


-- Bonus % d'âge du perso actif (raccourci pour lzy_stats / affichages).
function meta:GetCharacterAgeBonusPct()
    return EVO_CharacterAgeBonusPct(self:GetCharacterAge())
end

-- ─────────────────────────────────────────────────────────────────────────
-- CAPACITÉ EN EMPLACEMENTS DE PERSONNAGE RP
-- Base 1 perso gratuit ; le 2e exige VIP (premium tier 2), le 3e Platinum (tier 3).
-- Les SUPERADMINS ont les 3 d'office, sans aucune restriction de grade (demande user
-- 2026-07-27) : c'est un accès staff, pas un achat — il ne doit dépendre d'aucun
-- paiement ni d'aucune resynchro boutique.
--
-- Calcul PARTAGÉ, comme l'âge plus haut et pour la même raison : le SERVEUR s'en sert
-- pour AUTORISER la création (lzy_character/server/sv_main.lua, CreateCharacter) et le
-- CLIENT pour AFFICHER les cadenas et le compteur « x / 3 » (ncm_char_select/cl_main).
-- Les deux côtés portaient chacun leur propre copie de la formule — le serveur avec le
-- commentaire « Mirror client » pour tout garde-fou, et l'affichage une TROISIÈME copie.
-- Une seule source ici : sinon l'UI finit par annoncer autre chose que ce que le serveur
-- accepte réellement.
--
-- NOTE : ne concerne QUE les 3 emplacements RP. Les emplacements 4/5 sont les persos
-- ANIMATION, réservés au groupe « animateur » (test à part dans ncm_char_select) : c'est
-- un rôle d'événement, pas une restriction de grade boutique, et il n'est pas touché ici.
-- ─────────────────────────────────────────────────────────────────────────
EVO_CHARACTER_MAX_RP_SLOTS = 3

--- Nombre d'emplacements RP utilisables par ce joueur (1 à EVO_CHARACTER_MAX_RP_SLOTS).
--- @param ply Player
--- @return number
function EVO_GetCharacterSlotCap(ply)
    if not IsValid(ply) then return 1 end
    if ply:IsSuperAdmin() then return EVO_CHARACTER_MAX_RP_SLOTS end

    local nPremium = ply:GetEvoNWInt("premium", 0)
    local nCap = (nPremium >= 3 and 3) or (nPremium >= 2 and 2) or 1

    -- RESPONSABLE MODÉRATEUR (demande user 09/08) : le 2e emplacement lui est OFFERT,
    -- exactement comme à un VIP. Même logique que les superadmins juste au-dessus :
    -- c'est un accès lié à la FONCTION, pas un achat — il ne doit dépendre d'aucun
    -- paiement ni d’aucune resynchro boutique.
    -- math.max et pas « = 2 » : un respo qui est AUSSI Platinum garderait sinon 2
    -- emplacements au lieu de 3, et perdrait un perso déjà créé en prenant le grade.
    -- Le rang SAM est reconnu par EVO_IsRespoModo (evo_staff/lua/autorun/sh_staff_grades),
    -- testé en `and` : sans evo_staff monté, on retombe simplement sur la règle boutique.
    if EVO_IsRespoModo and EVO_IsRespoModo(ply) then nCap = math.max(nCap, 2) end

    return nCap
end