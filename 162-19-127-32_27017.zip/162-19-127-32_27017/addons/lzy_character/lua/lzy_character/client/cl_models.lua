-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_models.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local playersModels = {}
local _lzyPendingModelsBySteamID64 = {}
local _lzyCrowdDummies = {}
local _lzyCrowdSpawnToken = 0

-- evo_persos_fps (autre addon) doit voir les mannequins pour mesurer en solo.
-- La table est remplacee a chaque lzy_crowd_clear : on expose une fonction, pas la table.
function LZY_Crowd_Dummies() return _lzyCrowdDummies end

local _lzyBuildsBlockedByLoading = false
local _lzyPostLoadSyncGen = 0

local function LZY_Character_NoteBuildBlockedByLoading()
	_lzyBuildsBlockedByLoading = true
end

local function LZY_IsRawBodyModel(model)
	if EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(model) then return true end
	if EVO_LostSoul and EVO_LostSoul.IsLostSoulBodyModel and EVO_LostSoul.IsLostSoulBodyModel(model) then return true end
	return false
end

local _lzyLocalInCharMenu = false
local _lzyLocalInCharMenuSetAt = 0
local LZY_LOCAL_MENU_STALE_SECONDS = 10

function LZY_Character_SetLocalInCharMenu(on)
	_lzyLocalInCharMenu = on == true
	_lzyLocalInCharMenuSetAt = _lzyLocalInCharMenu and RealTime() or 0
end

function LZY_Character_IsLocalInCharMenu()
	if LZY_IsCharacterCreatorOpen and LZY_IsCharacterCreatorOpen() then return true end
	if NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive() then return true end
	if LZY_Character_HubSceneActive and LZY_Character_HubSceneActive() then return true end
	if _lzyLocalInCharMenu
		and (not LZY_IsLoadingScreenOpen or not LZY_IsLoadingScreenOpen()) then
		local lp = LocalPlayer()
		local uid = (IsValid(lp) and lp.GetEvoNWString and lp:GetEvoNWString("Character::Unique::ID", "none")) or "none"
		if uid ~= "" and uid ~= "none"
			and RealTime() - (_lzyLocalInCharMenuSetAt or 0) >= LZY_LOCAL_MENU_STALE_SECONDS then
			_lzyLocalInCharMenu = false
			_lzyLocalInCharMenuSetAt = 0
		end
	end
	return _lzyLocalInCharMenu
end

local function LZY_Character_InHubOrFinalizeFlow(ent)
	if LZY_IsCharacterCreatorOpen and LZY_IsCharacterCreatorOpen() then return true end
	if NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive() then return true end
	if ent == LocalPlayer() and EVO_HollowProg and EVO_HollowProg._Finalizing then
		local deadline = tonumber(EVO_HollowProg._FinalizeClientDeadline) or 0
		if deadline <= 0 then
			deadline = RealTime() + 15
			EVO_HollowProg._FinalizeClientDeadline = deadline
		end
		if RealTime() <= deadline then return true end
		if EVO_HollowProg.ClearFinalizeClient then
			EVO_HollowProg.ClearFinalizeClient()
		else
			EVO_HollowProg._Finalizing = false
		end
	end
	if LZY_Character_IsLocalInCharMenu() then return true end
	return false
end

function LZY_IsLarvaCharacter(ent, characterData)
	local data = characterData
	if not data and ent and IsValid(ent) then
		data = playersModels[ent]
	end
	local bAnimHollow = ent and IsValid(ent) and ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_AnimatorHollow", false)
	if not bAnimHollow and data and data.body_model and data.hair_model then
		if not LZY_IsRawBodyModel(data.body_model) then
			return false
		end
	end
	local nwRaw = false
	if ent and IsValid(ent) and ent.GetEvoNWBool then
		nwRaw = ent:GetEvoNWBool("EVO_HollowRaw", false) or ent:GetEvoNWBool("EVO_IsLarva", false)
		if nwRaw then
			if not bAnimHollow and ent.GetModel then
				local mdl = ent:GetModel() or ""
				if mdl ~= "" and not LZY_IsRawBodyModel(mdl) then
					return false
				end
			end
			return true
		end
	end
	if data and LZY_IsRawBodyModel(data.body_model) then
		if not bAnimHollow and ent and IsValid(ent) and ent.GetModel and not nwRaw then
			local mdl = ent:GetModel() or ""
			if mdl ~= "" and not LZY_IsRawBodyModel(mdl) then
				return false
			end
			local liveUid = (ent.GetEvoNWString and ent:GetEvoNWString("Character::Unique::ID", "none")) or "none"
			if liveUid ~= "" and liveUid ~= "none" then
				local dataUid = data.unique_id ~= nil and tostring(data.unique_id) or ""
				if dataUid ~= "" and dataUid ~= liveUid then
					return false
				end
			end
		end
		return true
	end
	return false
end

local LZY_PlayerLODCVar = CreateClientConVar("evo_player_lod", "1", true, false,
	"LOD joueurs lointains (1=on : details/tatouages budgetes, 0=tout HQ)")

local LZY_PlayerLODBudget = CreateClientConVar("evo_player_lod_budget", "8", true, false,
	"Nb max de joueurs en detail complet (accessoires/barbe/tatouages). 0 = illimite")

local function LZY_Character_GetDetailBudget()
	if LZY_OPTIMISATIONS and LZY_OPTIMISATIONS.GetDetailBudget then
		return math.floor(tonumber(LZY_OPTIMISATIONS.GetDetailBudget()) or 8)
	end
	return LZY_PlayerLODBudget:GetInt()
end

local function LZY_Character_GetMaxCharactersDrawn()
	if LZY_OPTIMISATIONS and LZY_OPTIMISATIONS.GetMaxCharactersDrawn then
		return math.floor(tonumber(LZY_OPTIMISATIONS.GetMaxCharactersDrawn()) or 0)
	end
	return 0
end

local FACE_RANGE_EXIT_MUL_SQR = 1.05 * 1.05

local LZY_Character_PlayerExpectsModelData
local LZY_Character_HasPriorityRankCosmetics

local function LZY_Character_ComputeInFaceRange(ent, distSqr)
	local limit = LZY_CHARACTER_CONFIG.GetFaceBodyHairDistanceSqr()
	if ent._lzyInFaceRange == true then
		return distSqr <= limit * FACE_RANGE_EXIT_MUL_SQR
	end
	return distSqr <= limit
end

local function LZY_Character_LodViewScore(ent, origin, eyePos, forward)
	local distSqr = ent:GetPos():DistToSqr(origin)
	local toEnt = (ent.EyePos and ent:EyePos() or ent:GetPos()) - eyePos
	local lenSqr = toEnt:LengthSqr()
	local facing = 0
	if lenSqr > 1 then
		facing = forward:Dot(toEnt * (1 / math.sqrt(lenSqr)))
	end
	facing = math.Clamp(facing, -1, 1)

	local viewMul = 1
	if facing >= 0 then
		viewMul = 1 - 0.12 * facing
	else
		viewMul = 1 - 0.55 * facing
	end

	local score = distSqr * viewMul

	if ent._lzyShouldDraw == true then
		score = score * 0.82
	end

	if LZY_Character_HasPriorityRankCosmetics(ent, playersModels and playersModels[ent]) then
		score = score * 0.50
	end

	return score, distSqr
end

function LZY_Character_UpdateDetailBudgetTags(localPly)
	localPly = localPly or LocalPlayer()
	if not IsValid(localPly) then return end

	local detailBudget = LZY_Character_GetDetailBudget()
	local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
	local lodOn = LZY_PlayerLODCVar:GetBool()
	local origin = localPly:GetPos()
	local eyePos = localPly:EyePos()
	local forward = localPly:EyeAngles():Forward()
	local accDistSqr = LZY_CHARACTER_CONFIG.GetAccessoriesDistanceSqr()
	local specTarget = localPly.GetEvoNWEntity and localPly:GetEvoNWEntity("EVO_SpecTarget")

	local drawCand, detailCand = {}, {}

	local function scheduleBudgetPromote(ent)
		if not IsValid(ent) or ent._lzyBudgetPromotePending then return end
		ent._lzyBudgetPromotePending = true
		timer.Simple(0, function()
			if not IsValid(ent) then return end
			ent._lzyBudgetPromotePending = nil
			if ent._lzyShouldDraw ~= true then return end
			LZY_Character_InvalidateDrawState(ent)
			local d = playersModels and playersModels[ent]
			if d and d.body_model then
				LZY_Character_TryCreatePlayerClientModels(ent, d)
			elseif LZY_Character_PlayerExpectsModelData(ent, LocalPlayer()) then
				LZY_Character_WantPM(ent)
			end
		end)
	end

	local function cullCompositeParts(ent)
		if ent.PlayerModelParts then
			LZY_Character_DestroyPlayerClientModels(ent, { keepRenderOverride = true })
		else
			LZY_Character_InvalidateDrawState(ent)
		end
	end

	local function consider(ent)
		if not IsValid(ent) or ent == localPly then return end
		if IsValid(specTarget) and ent == specTarget then return end
		if ent.IsDormant and ent:IsDormant() then
			ent._lzyShouldDraw = false
			ent._lzyNearDetail = false
			return
		end

		local score, distSqr = LZY_Character_LodViewScore(ent, origin, eyePos, forward)
		ent._lzyLodScore = score
		ent._lzyLodDistSqr = distSqr

		local inFace = LZY_Character_ComputeInFaceRange(ent, distSqr)
		ent._lzyInFaceRange = inFace
		if inFace then
			drawCand[#drawCand + 1] = ent
		else
			if ent._lzyShouldDraw ~= false or ent.PlayerModelParts then
				cullCompositeParts(ent)
			end
			ent._lzyShouldDraw = false
			ent._lzyNearDetail = false
		end
	end

	for _, ply in player.Iterator() do
		consider(ply)
	end
	if _lzyCrowdDummies then
		for i = 1, #_lzyCrowdDummies do
			consider(_lzyCrowdDummies[i])
		end
	end

	table.sort(drawCand, function(a, b)
		local sa, sb = a._lzyLodScore or 0, b._lzyLodScore or 0
		if sa ~= sb then return sa < sb end
		return (a._lzyLodDistSqr or 0) < (b._lzyLodDistSqr or 0)
	end)

	local drawUnlimited = maxDrawn <= 0
	for i = 1, #drawCand do
		local ent = drawCand[i]
		local allowDraw = drawUnlimited or (i <= maxDrawn)
		local wasDraw = ent._lzyShouldDraw
		ent._lzyShouldDraw = allowDraw
		if allowDraw and wasDraw ~= true then
			scheduleBudgetPromote(ent)
		elseif not allowDraw and wasDraw == true then
			cullCompositeParts(ent)
		end
		if allowDraw then
			local distSqr = ent:GetPos():DistToSqr(origin)
			if distSqr <= accDistSqr then
				detailCand[#detailCand + 1] = ent
			else
				ent._lzyNearDetail = false
			end
		else
			ent._lzyNearDetail = false
		end
	end

	table.sort(detailCand, function(a, b)
		local sa, sb = a._lzyLodScore or 0, b._lzyLodScore or 0
		if sa ~= sb then return sa < sb end
		return (a._lzyLodDistSqr or 0) < (b._lzyLodDistSqr or 0)
	end)

	local detailUnlimited = (not lodOn) or detailBudget <= 0
	for i = 1, #detailCand do
		local ent = detailCand[i]
		local allowDetail = detailUnlimited or (i <= detailBudget)
		if not allowDetail and not detailUnlimited and ent._lzyNearDetail == true and i <= detailBudget + 2 then
			allowDetail = true
		end
		ent._lzyNearDetail = allowDetail
	end

	if IsValid(specTarget) and specTarget:IsPlayer() and specTarget ~= localPly then
		local needPromote = specTarget._lzyShouldDraw ~= true
			or not specTarget.PlayerModelParts
			or LZY_Character_PlayerNeedsModelRepair(specTarget)
		specTarget._lzyShouldDraw = true
		specTarget._lzyNearDetail = true
		specTarget._lzyInFaceRange = true
		if needPromote then
			scheduleBudgetPromote(specTarget)
		end
	end
end

local _lodBudgetNext = 0
hook.Add("Think", "LZY:Character:PlayerLODBudget", function()
	local now = CurTime()
	if now < _lodBudgetNext then return end
	_lodBudgetNext = now + 0.15
	LZY_Character_UpdateDetailBudgetTags()
end)

local _lzyDrawStateThinkNext = 0
local LZY_DRAW_STATE_INTERVAL = 0.1

local LZY_DRAW_STATE_NWVARS = {
	NCM_TF_Active = true,
	NCM_Instanced = true,
	NCM_InstanceZone = true,
	InCharacterMenu = true,
	EVO_FullHide = true,
	EVO_FlashStepping = true,
	EVO_HollowRaw = true,
	EVO_IsLarva = true,
}

function LZY_Character_InvalidateDrawState(ply)
	if IsValid(ply) then
		ply._lzyDrawState = nil
		-- Les Ensure* du rendu sont espaces de 0,25 s : une invalidation (apparence,
		-- budget, reconnexion) les relance des la prochaine image.
		ply._lzyEnsureNext = 0
	end
end

local function LZY_Character_PlayerIsDrawHidden(ply)
	if not IsValid(ply) then return true end
	if ply.EVO_FlashStepHidden then return true end
	if ply.GetEvoNWBool and (ply:GetEvoNWBool("EVO_FullHide", false) or ply:GetEvoNWBool("EVO_FlashStepping", false)) then
		return true
	end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("NCM_IsAssassinInvisible", false) then return true end
	if ply.sam_get_nwvar and ply:sam_get_nwvar("cloaked") then return true end
	if ply._NCM_CrossInstanceHidden then return true end
	if NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive()
		and ply ~= LocalPlayer() then
		return true
	end
	if ply:GetNoDraw() then return true end
	return false
end

local function LZY_Character_HubSceneActive()
	return NCM_CHAR_SELECT ~= nil and NCM_CHAR_SELECT.IsSceneActive ~= nil and NCM_CHAR_SELECT.IsSceneActive()
end

function LZY_Character_RefreshDrawState(ply, localPly)
	if not IsValid(ply) then return end
	localPly = localPly or LocalPlayer()
	if not IsValid(localPly) then return end

	local isLocal = (ply == localPly)
	local state = {
		isLocal = isLocal,
		dormant = ply.IsDormant and ply:IsDormant() or false,
		tfActive = ply.GetEvoNWBool and ply:GetEvoNWBool("NCM_TF_Active", false) or false,
		instanceOk = true,
		charMenuHideOthers = false,
		hidden = LZY_Character_PlayerIsDrawHidden(ply),
		distSqr = ply:GetPos():DistToSqr(localPly:GetPos()),
	}

	if not isLocal then
		local entInst = ply:GetEvoNWBool("NCM_Instanced", false)
		local localInst = localPly:GetEvoNWBool("NCM_Instanced", false)
		state.instanceOk = (entInst == localInst)
			and (not entInst or ply:GetEvoNWString("NCM_InstanceZone", "") == localPly:GetEvoNWString("NCM_InstanceZone", ""))
		state.charMenuHideOthers = LZY_Character_IsLocalInCharMenu()
	end

	local specTarget = localPly.GetEvoNWEntity and localPly:GetEvoNWEntity("EVO_SpecTarget")
	local isSpectateTarget = IsValid(specTarget) and specTarget == ply
	if isLocal or isSpectateTarget then
		state.inFaceRange = true
	else
		state.inFaceRange = LZY_Character_ComputeInFaceRange(ply, state.distSqr)
		ply._lzyInFaceRange = state.inFaceRange
	end
	local lodOn = LZY_PlayerLODCVar:GetBool()
	local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
	state.shouldDraw = isLocal or maxDrawn <= 0 or ply._lzyShouldDraw ~= false
	state.shouldBuild = LZY_Character_PlayerShouldBuildClientModels(ply) and state.shouldDraw
	local withinAccDist = state.distSqr <= LZY_CHARACTER_CONFIG.GetAccessoriesDistanceSqr()
	local budget = LZY_Character_GetDetailBudget()
	local inLodBudget = budget <= 0 or ply._lzyNearDetail ~= false
	state.drawHairHQ = isLocal or (not lodOn) or withinAccDist
	state.drawHairCheap = (not state.drawHairHQ) and state.inFaceRange and lodOn
	local hideOtherAcc = LZY_OPTIMISATIONS and LZY_OPTIMISATIONS.GetHideOtherAccessories and LZY_OPTIMISATIONS.GetHideOtherAccessories()
	state.drawDetails = isLocal or (not hideOtherAcc
		and state.shouldDraw
		and ((not lodOn) or (withinAccDist and inLodBudget)))
	state.drawTattoos = isLocal or (state.shouldDraw and ((not lodOn) or inLodBudget))

	local botData = playersModels and playersModels[ply]
	if botData and botData._lzyLightBot then
		state.drawHairHQ = false
		state.drawHairCheap = state.inFaceRange
		state.drawDetails = false
		state.drawTattoos = false
	end

	if ply._lzyCrowdForceHQ then
		state.shouldDraw = true
		state.shouldBuild = true
		state.drawHairHQ = true
		state.drawHairCheap = false
		state.drawTattoos = true
		if not hideOtherAcc then state.drawDetails = true end
	end

	ply._lzyDrawState = state
end

local function LZY_Character_ScanPartsNeedReparent(ply)
	if not IsValid(ply) or ply._lzyPartsNeedReparent or not ply.PlayerModelParts then return end
	local p = ply.PlayerModelParts
	local function check(m)
		if IsValid(m) and not m._lzyPet and m:GetParent() ~= ply then
			ply._lzyPartsNeedReparent = true
		end
	end
	check(p.body)
	check(p.hair)
	check(p.beard)
	check(p.mustache)
	if istable(p.accessories) then
		for i = 1, #p.accessories do check(p.accessories[i]) end
	end
end

local function LZY_Character_ClearPartsNeedReparentIfAttached(ent, parts)
	if not ent._lzyPartsNeedReparent or not parts then return end
	local function ok(m) return not IsValid(m) or m._lzyPet or m:GetParent() == ent end
	if not ok(parts.body) or not ok(parts.hair) or not ok(parts.beard) or not ok(parts.mustache) then return end
	if istable(parts.accessories) then
		for i = 1, #parts.accessories do
			if not ok(parts.accessories[i]) then return end
		end
	end
	ent._lzyPartsNeedReparent = nil
end

hook.Add("Think", "LZY:Character:DrawStateRefresh", function()
	local now = CurTime()
	if now < _lzyDrawStateThinkNext then return end
	_lzyDrawStateThinkNext = now + LZY_DRAW_STATE_INTERVAL

	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	LZY_Character_UpdateDetailBudgetTags(lp)

	for _, ply in player.Iterator() do
		if not IsValid(ply) or not ply:Alive() then continue end
		LZY_Character_RefreshDrawState(ply, lp)
		if ply.RenderOverride then LZY_Character_ScanPartsNeedReparent(ply) end
	end
	for i = 1, #_lzyCrowdDummies do
		local dum = _lzyCrowdDummies[i]
		if IsValid(dum) and dum.RenderOverride then
			LZY_Character_RefreshDrawState(dum, lp)
			LZY_Character_ScanPartsNeedReparent(dum)
		end
	end
end)

function LZY_IsHairDetailMaterialPath(mpath)
	if not isstring(mpath) then return false end
	return string.find(string.lower(mpath), "detail", 1, true) ~= nil
end

function LZY_IsHairMainGradientMaterialPath(mpath)
	if not isstring(mpath) then return false end
	local low = string.lower(mpath)
	if not string.find(low, "evo/hair/uni", 1, true) then return false end
	if LZY_IsHairDetailMaterialPath(mpath) then return false end
	return true
end

local LZY_hairModelHasDetailsCache = {}

function LZY_HairModelPathHasDetailMaterials(modelPath)
	if not isstring(modelPath) or modelPath == "" then return false end
	local c = LZY_hairModelHasDetailsCache[modelPath]
	if c ~= nil then return c end
	if util and util.PrecacheModel then util.PrecacheModel(modelPath) end
	local mdl = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
	local has = false
	if IsValid(mdl) then
		local mats = mdl:GetMaterials()
		if mats then
			for _, mname in ipairs(mats) do
				if LZY_IsHairDetailMaterialPath(mname) then
					has = true
					break
				end
			end
		end
		mdl:Remove()
	end
	LZY_hairModelHasDetailsCache[modelPath] = has
	return has
end

matproxy.Add({
	name = "DetailsColor",
	init = function(self, mat, values)
		self.ResultTo = values.resultvar or "$color2"
	end,
	bind = function(self, mat, ent)
		if not IsValid(ent) then return end
		local c = ent.HairDetailsColor or Color(255, 255, 255)
		mat:SetVector(self.ResultTo, Vector(
			math.Clamp(c.r or 255, 0, 255) / 255,
			math.Clamp(c.g or 255, 0, 255) / 255,
			math.Clamp(c.b or 255, 0, 255) / 255
		))
	end,
})

local HAIR_GRADIENT_RT_W, HAIR_GRADIENT_RT_H = 256, 1

local _lzy_face_rt_epoch = 0
local hair_grad_rt_cache = {}
local hair_grad_mat_cache = {}
local hair_cheap_mat_cache = {}

local function getGradientRTName(colA, colB)
    colA = colA or Color(0, 0, 0)
    colB = colB or Color(0, 0, 0)
    return string.format("lzy_hairgrad_rt_%02x%02x%02x_%02x%02x%02x",
        math.floor(tonumber(colA.r) or 0), math.floor(tonumber(colA.g) or 0), math.floor(tonumber(colA.b) or 0),
        math.floor(tonumber(colB.r) or 0), math.floor(tonumber(colB.g) or 0), math.floor(tonumber(colB.b) or 0))
end

function GetOrCreateGradientRT_World(colA, colB)
    colA = colA or Color(0, 0, 0)
    colB = colB or Color(0, 0, 0)
    local ar = math.floor(tonumber(colA.r) or 0)
    local ag = math.floor(tonumber(colA.g) or 0)
    local ab = math.floor(tonumber(colA.b) or 0)
    local br = math.floor(tonumber(colB.r) or 0)
    local bg = math.floor(tonumber(colB.g) or 0)
    local bb = math.floor(tonumber(colB.b) or 0)
    colA = Color(ar, ag, ab)
    colB = Color(br, bg, bb)
	local rtName = getGradientRTName(colA, colB)
	local cachedRt = hair_grad_rt_cache[rtName]
	if cachedRt then return cachedRt end
	local rt = nil
	if GetRenderTargetEx and IMAGE_FORMAT_BGRA8888 ~= nil then
		local sizeMode = RT_SIZE_LITERAL or 1
		local depthMode = MATERIAL_RT_DEPTH_NONE
		if depthMode == nil then depthMode = 3 end
		local texFlags = 2 + 256 + 32768
		if bit and bit.bor then texFlags = bit.bor(2, 256, 32768) end
		rt = GetRenderTargetEx(rtName, HAIR_GRADIENT_RT_W, HAIR_GRADIENT_RT_H, sizeMode, depthMode, texFlags, 0, IMAGE_FORMAT_BGRA8888)
	end
	if not rt then rt = GetRenderTarget(rtName, HAIR_GRADIENT_RT_W, HAIR_GRADIENT_RT_H) end
	if not rt then return nil end
    render.PushRenderTarget(rt)
    render.Clear(0, 0, 0, 255)
    cam.Start2D()
        for x = 0, HAIR_GRADIENT_RT_W - 1 do
            local t = x / (HAIR_GRADIENT_RT_W - 1)
            surface.SetDrawColor(
                math.ceil(Lerp(t, colA.r, colB.r)),
                math.ceil(Lerp(t, colA.g, colB.g)),
                math.ceil(Lerp(t, colA.b, colB.b)),
                255
            )
            surface.DrawRect(x, 0, 1, HAIR_GRADIENT_RT_H)
        end
    cam.End2D()
    render.PopRenderTarget()
	hair_grad_rt_cache[rtName] = rt
    return rt
end

function GetOrCreateHairGradientMaterial_World(colA, colB, angleDeg)
    colA = colA or Color(0, 0, 0)
    colB = colB or Color(0, 0, 0)
    angleDeg = tonumber(angleDeg) or 0
    local ar = math.floor(tonumber(colA.r) or 0)
    local ag = math.floor(tonumber(colA.g) or 0)
    local ab = math.floor(tonumber(colA.b) or 0)
    local br = math.floor(tonumber(colB.r) or 0)
    local bg = math.floor(tonumber(colB.g) or 0)
    local bb = math.floor(tonumber(colB.b) or 0)
    colA = Color(ar, ag, ab)
    colB = Color(br, bg, bb)

	local cacheKey = string.format("%02x%02x%02x_%02x%02x%02x_%03d",
		colA.r, colA.g, colA.b, colB.r, colB.g, colB.b, math.floor(angleDeg % 360))
	local cachedMat = hair_grad_mat_cache[cacheKey]
	if cachedMat then return cachedMat end

    local gradientRT = GetOrCreateGradientRT_World(colA, colB)
    if not gradientRT then return nil end

    local uniqueName = string.format("lzy_hairgrad_world_%02x%02x%02x_%02x%02x%02x_%03d",
        colA.r, colA.g, colA.b, colB.r, colB.g, colB.b, math.floor(angleDeg % 360))

    local mat = CreateMaterial(uniqueName, "VertexLitGeneric", {
        ["$basetexture"] = "evo/hair/uni/hair",
        ["$lightwarptexture"] = "evo/shaders/toon",
        ["$nocull"] = "1",
        ["$color2"] = "1 1 1",
        ["$detailscale"] = "1",
        ["$detailblendfactor"] = "1",
        ["$detailblendmode"] = "0",
        ["$detailtint"] = "1 1 1",
        ["$model"] = "1",
    })

    mat:SetTexture("$detail", gradientRT)
    mat:SetVector("$color2", Vector(1, 1, 1))
    mat:SetVector("$detailtint", Vector(1, 1, 1))

    local m = Matrix()
    m:Translate(Vector(0.5, 0.5, 0))
    m:Rotate(Angle(0, angleDeg, 0))
    m:Translate(Vector(-0.5, -0.5, 0))
    mat:SetMatrix("$detailtexturetransform", m)

	local sub = "!" .. uniqueName
	hair_grad_mat_cache[cacheKey] = sub
    return sub
end

LZY_SKIN_TONE_HAIR_MODELS = LZY_SKIN_TONE_HAIR_MODELS or {
    ["models/evo/hair/male/hair/evo_vbfdfdzhkj52tgrqqeeezd/evo_vbfdfdzhkj52tgrqqeeezd.mdl"] = true,
    ["models/evo/hair/female/hair/evo_feavr4bg97rc4zedzed/evo_feavr4bg97rc4zedzed.mdl"]     = true,
}

function ApplyHairGradientToWorldPlayer(ent, hairEnt, colA, colB, angleDeg, detailsColor)
    if not IsValid(ent) then return end
    if LZY_IsLarvaCharacter(ent) then return end
    if LZY_IsRawBodyModel(ent:GetModel()) then return end
    local cached = playersModels and playersModels[ent]
    if cached and LZY_IsRawBodyModel(cached.body_model) then return end
    detailsColor = detailsColor or Color(255, 255, 255)
    if not detailsColor.a then detailsColor.a = 255 end

    ent.HairDetailsColor = detailsColor
    if IsValid(hairEnt) then
        hairEnt.HairDetailsColor = detailsColor
    end

    local matName = GetOrCreateHairGradientMaterial_World(colA, colB, angleDeg)
    if not matName then return end

    if IsValid(hairEnt) then
        if LZY_SKIN_TONE_HAIR_MODELS[string.lower(hairEnt:GetModel() or "")] then
            hairEnt:SetSubMaterial()
            if hairEnt.SetSkin and ent.GetSkin then hairEnt:SetSkin(ent:GetSkin() or 0) end
        else
            local mats = hairEnt:GetMaterials()
            if mats then
                for idx, mname in ipairs(mats) do
                    local i = idx - 1
                    if LZY_IsHairMainGradientMaterialPath(mname) then
                        hairEnt:SetSubMaterial(i, matName)
                    elseif LZY_IsHairDetailMaterialPath(mname) or string.find(string.lower(mname), "evo/hair/uni", 1, true) then
                        hairEnt:SetSubMaterial(i, nil)
                    end
                end
            end
        end
    end

    local faceAlreadyOk = ent._lzyHairGradMatApplied == matName
        and ent._hairMaterialIndex ~= nil
        and ent._hairMaterialIndex ~= false
    if faceAlreadyOk then return end

    local genAtSchedule = ent._lzyVisualOverrideGen or 0

    local function applyFaceSlots()
        if not IsValid(ent) then return false end
        if LZY_IsLarvaCharacter(ent) then return false end
        if LZY_IsRawBodyModel(ent:GetModel()) then return false end
        local cached = playersModels and playersModels[ent]
        if cached and LZY_IsRawBodyModel(cached.body_model) then return false end
        if (ent._lzyVisualOverrideGen or 0) ~= genAtSchedule then return false end
        ent._hairMaterialIndex = nil
        local mats = ent:GetMaterials()
        if not mats then return false end
        local found = false
        for idx, mname in ipairs(mats) do
            local i = idx - 1
            if LZY_IsHairMainGradientMaterialPath(mname) then
                ent:SetSubMaterial(i, matName)
                if ent._hairMaterialIndex == nil then
                    ent._hairMaterialIndex = i
                end
                found = true
            elseif string.find(string.lower(mname), "evo/hair/uni", 1, true) then
                ent:SetSubMaterial(i, nil)
            end
        end
        if not found then
            ent._hairMaterialIndex = false
            return false
        end
        ent._lzyHairGradMatApplied = matName
        return true
    end

    if applyFaceSlots() then return end

    if ent._lzyHairGradFaceRetryPending then return end
    ent._lzyHairGradFaceRetryPending = true
    timer.Simple(0.1, function()
        if not IsValid(ent) then return end
        ent._lzyHairGradFaceRetryPending = nil
        if (ent._lzyVisualOverrideGen or 0) ~= genAtSchedule then return end
        if LZY_IsLarvaCharacter(ent) then return end
        if LZY_IsRawBodyModel(ent:GetModel()) then return end
        local cached = playersModels and playersModels[ent]
        if cached and LZY_IsRawBodyModel(cached.body_model) then return end
        if ent._lzyHairGradMatApplied == matName
            and ent._hairMaterialIndex ~= nil
            and ent._hairMaterialIndex ~= false then
            return
        end
        applyFaceSlots()
    end)
end

local function GetOrCreateCheapHairMaterial_World(col)
	col = col or Color(180, 140, 100)
	local r = math.floor(math.Clamp(tonumber(col.r) or 180, 0, 255) / 16 + 0.5) * 16
	local g = math.floor(math.Clamp(tonumber(col.g) or 140, 0, 255) / 16 + 0.5) * 16
	local b = math.floor(math.Clamp(tonumber(col.b) or 100, 0, 255) / 16 + 0.5) * 16
	r, g, b = math.Clamp(r, 0, 255), math.Clamp(g, 0, 255), math.Clamp(b, 0, 255)
	local cacheKey = string.format("%02x%02x%02x", r, g, b)
	local cached = hair_cheap_mat_cache[cacheKey]
	if cached then return cached end
	local uniqueName = "lzy_haircheap_world_" .. cacheKey
	local mat = CreateMaterial(uniqueName, "VertexLitGeneric", {
		["$basetexture"] = "evo/hair/uni/hair",
		["$nocull"] = "1",
		["$model"] = "1",
		["$color2"] = "1 1 1",
	})
	if not mat then return nil end
	mat:SetVector("$color2", Vector(r / 255, g / 255, b / 255))
	local sub = "!" .. uniqueName
	hair_cheap_mat_cache[cacheKey] = sub
	return sub
end

local function LZY_AverageHairColor(colA, colB)
	colA = colA or Color(180, 140, 100)
	colB = colB or colA
	local ar, ag, ab = tonumber(colA.r) or 180, tonumber(colA.g) or 140, tonumber(colA.b) or 100
	local br, bg, bb = tonumber(colB.r) or ar, tonumber(colB.g) or ag, tonumber(colB.b) or ab
	return Color(math.floor((ar + br) * 0.5), math.floor((ag + bg) * 0.5), math.floor((ab + bb) * 0.5))
end

function ApplyCheapHairToWorldPlayer(ent, hairEnt, colA, colB)
	if not IsValid(ent) or not IsValid(hairEnt) then return end
	if LZY_IsLarvaCharacter(ent) then return end
	if LZY_IsRawBodyModel(ent:GetModel()) then return end
	local cached = playersModels and playersModels[ent]
	if cached and LZY_IsRawBodyModel(cached.body_model) then return end
	if LZY_SKIN_TONE_HAIR_MODELS[string.lower(hairEnt:GetModel() or "")] then
		hairEnt:SetSubMaterial()
		if hairEnt.SetSkin and ent.GetSkin then hairEnt:SetSkin(ent:GetSkin() or 0) end
		return
	end
	local matName = GetOrCreateCheapHairMaterial_World(LZY_AverageHairColor(colA, colB))
	if not matName then return end
	local mats = hairEnt:GetMaterials()
	if not mats then return end
	for idx, mname in ipairs(mats) do
		local i = idx - 1
		if LZY_IsHairMainGradientMaterialPath(mname) then
			hairEnt:SetSubMaterial(i, matName)
		elseif LZY_IsHairDetailMaterialPath(mname) or string.find(string.lower(mname), "evo/hair/uni", 1, true) then
			hairEnt:SetSubMaterial(i, nil)
		end
	end
end

local function normalizeHairDetailsColor(c)
	if not c then return Color(255, 255, 255) end
	if type(c) == "table" and (c.r or c.g or c.b) then
		return Color(c.r or 255, c.g or 255, c.b or 255, c.a or 255)
	end
	if type(c) == "table" and c[1] then
		return Color(c[1], c[2] or 255, c[3] or 255, c[4] or 255)
	end
	if IsColor(c) then return c end
	return Color(255, 255, 255)
end

function LZY_NormalizeHairDetailsColor(c)
	return normalizeHairDetailsColor(c)
end

local function normalizeEyesColor(eyes_color)
    if not eyes_color then return nil end
    if type(eyes_color) == "table" and (eyes_color.r or eyes_color.g or eyes_color.b) then
        return Color(eyes_color.r or 0, eyes_color.g or 0, eyes_color.b or 0)
    end
    if type(eyes_color) == "table" and eyes_color[1] then
        return Color(eyes_color[1], eyes_color[2] or 0, eyes_color[3] or 0)
    end
    return eyes_color
end

function GetPupilsTextureList(_gender)
    return LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES
        or LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES_MALE
        or {}
end

function LZY_PupilsIsLegacyFlatList(list)
    if not istable(list) or #list < 1 then return true end
    return isstring(list[1])
end

function LZY_PupilsGetStyleGroups()
    local list = GetPupilsTextureList()
    if not istable(list) then return {} end
    if LZY_PupilsIsLegacyFlatList(list) then return {} end
    return list
end

function LZY_PupilsGetFirstPathForStyleIndex(styleIndex)
    local groups = LZY_PupilsGetStyleGroups()
    local group = groups[styleIndex]
    if not istable(group) then return nil end
    for _, row in ipairs(group) do
        if istable(row) and isstring(row.path) and row.path ~= "" then
            return row.path
        end
    end
    return nil
end

function LZY_PupilsGetWhitePathForStyleIndex(styleIndex)
    return LZY_PupilsGetFirstPathForStyleIndex(styleIndex)
end

function LZY_PupilsGetPathForStyleColor(styleIndex, colorKey)
    local groups = LZY_PupilsGetStyleGroups()
    local group = groups[styleIndex]
    if not istable(group) or not isstring(colorKey) then return nil end
    for _, row in ipairs(group) do
        if istable(row) and row.color == colorKey and isstring(row.path) then
            return row.path
        end
    end
    return nil
end

function LZY_PupilsPathForNewStyleKeepingColor(currentPath, newStyleIndex)
    local first = LZY_PupilsGetFirstPathForStyleIndex(newStyleIndex)
    if not newStyleIndex or newStyleIndex < 1 then return first end
    local _, colorKey = LZY_PupilsFindStyleAndColorByPath(currentPath)
    if not colorKey then return first end
    return LZY_PupilsGetPathForStyleColor(newStyleIndex, colorKey) or first
end

function LZY_PupilsFindStyleAndColorByPath(path)
    if not isstring(path) or path == "" then return nil, nil end
    local groups = LZY_PupilsGetStyleGroups()
    for si, group in ipairs(groups) do
        if istable(group) then
            for _, row in ipairs(group) do
                if istable(row) and row.path == path then
                    return si, row.color
                end
            end
        end
    end
    return nil, nil
end

function LZY_PupilsStyleIndexForPath(path)
    local si, _ = LZY_PupilsFindStyleAndColorByPath(path)
    return si
end

function LZY_PupilsDefaultPath()
    if LZY_PupilsIsLegacyFlatList(GetPupilsTextureList()) then
        local list = GetPupilsTextureList()
        return (list[1] and isstring(list[1])) and list[1] or nil
    end
    return LZY_PupilsGetFirstPathForStyleIndex(1)
end

function GetEyesBodygroupId(ent)
    if not IsValid(ent) then return nil end
    local groups = ent:GetBodyGroups()
    if not groups then return nil end
    for _, bg in ipairs(groups) do
        if bg.name and string.lower(bg.name) == "eyes" then
            return bg.id
        end
    end
    return nil
end

function SetEyesBodygroupToFirst(ent)
    local id = GetEyesBodygroupId(ent)
    if id ~= nil then
        ent:SetBodygroup(id, 0)
    end
end

local function FindPupilSubMaterialIndexBySide(ent, token)
    if not IsValid(ent) or not isstring(token) or token == "" then return nil end
    local mats = ent:GetMaterials()
    if not mats then return nil end
    for i, mname in ipairs(mats) do
        local lower = string.lower(mname)
        if string.find(lower, "evo/face/eyes/", 1, true) and string.find(lower, token, 1, true) then
            return i - 1
        end
    end
    return nil
end

function ApplyPupilTextureToEntity(ent, gender, leftSpec, rightSpec)
    if not IsValid(ent) then return end
    local matIdxL = FindPupilSubMaterialIndexBySide(ent, "pupil_left")
    local matIdxR = FindPupilSubMaterialIndexBySide(ent, "pupil_right")

    local function resolvePath(spec)
        local list = GetPupilsTextureList(gender)
        if not list or #list < 1 then return nil end

        if spec == nil or spec == "" then
            return LZY_PupilsDefaultPath()
        end

        if isstring(spec) and string.find(spec, "/", 1, true) then
            return spec
        end

        local idx = math.Clamp(tonumber(spec) or 0, 0, math.max(0, #list - 1))
        if LZY_PupilsIsLegacyFlatList(list) then
            local entry = list[idx + 1]
            return isstring(entry) and entry or nil
        end
        return LZY_PupilsGetFirstPathForStyleIndex(idx + 1)
    end

    local pathL = resolvePath(leftSpec)
    if not pathL then return end
    local pathR = resolvePath(rightSpec ~= nil and rightSpec or leftSpec)
    if not pathR then pathR = pathL end

    if matIdxL ~= nil then ent:SetSubMaterial(matIdxL, pathL) end
    if matIdxR ~= nil then ent:SetSubMaterial(matIdxR, pathR) end
end

function ApplyPupilsFromCharacterData(ent, gender, data)
    if not IsValid(ent) or not data then return end
    if LZY_IsLarvaCharacter(ent, data) then return end
    SetEyesBodygroupToFirst(ent)
    local sep = data.pupils_separate == true or data.pupils_separate == 1
    if sep then
        ApplyPupilTextureToEntity(ent, gender, data.pupil_left or "", data.pupil_right or "")
    else
        ApplyPupilTextureToEntity(ent, gender, data.pupils_texture or "", nil)
    end
end

local function LZY_Character_GetBodygroupsString(characterData)
	if not characterData then return nil end
	if isstring(characterData.bodygroupsString) and characterData.bodygroupsString ~= "" then
		return characterData.bodygroupsString
	end
	if isstring(characterData.bodygroups) and characterData.bodygroups ~= "" then
		return characterData.bodygroups
	end
	return nil
end

local function LZY_Character_GetExpectedFaceModelPath(characterData)
	if not characterData then return nil end
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
		return LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
	end
	if characterData.gender == "f" or characterData.gender == "female" then
		return LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE
	end
	return LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE
end

function LZY_Character_FaceModelMatches(ent, characterData)
	if not IsValid(ent) or not characterData then return false end
	if LZY_IsLarvaCharacter(ent, characterData) then return true end
	local expected = LZY_Character_GetExpectedFaceModelPath(characterData)
	if not isstring(expected) or expected == "" then return true end
	local cur = ent:GetModel()
	if not isstring(cur) or cur == "" then return false end
	return string.lower(cur) == string.lower(expected)
end

local function LZY_Character_IsKnownFaceModel(ent)
	if not IsValid(ent) then return false end
	local cur = string.lower(ent:GetModel() or "")
	if cur == "" then return false end
	local male = LZY_Character_GetExpectedFaceModelPath({ gender = "m" })
	local female = LZY_Character_GetExpectedFaceModelPath({ gender = "f" })
	return (isstring(male) and cur == string.lower(male))
		or (isstring(female) and cur == string.lower(female))
end

local function LZY_Character_FaceReadyForComposite(ent, characterData)
	if LZY_Character_FaceModelMatches(ent, characterData) then
		ent._lzyFaceMismatchSince = nil
		return true
	end
	if not LZY_Character_IsKnownFaceModel(ent) then
		ent._lzyFaceMismatchSince = nil
		return false
	end
	ent._lzyFaceMismatchSince = ent._lzyFaceMismatchSince or CurTime()
	return CurTime() - ent._lzyFaceMismatchSince >= 1
end

function LZY_Character_ApplyShapeKeysFromData(ent, characterData)
	if not IsValid(ent) or not istable(characterData) or not istable(characterData.shape_keys) then return end
	for key, value in pairs(characterData.shape_keys) do
		local id = tonumber(key)
		if id and not LZY_Character_IsReservedFlexKey(ent, id) then
			ent:SetFlexWeight(id, tonumber(value) or 0)
		end
	end
end

function LZY_Character_ApplyFaceAppearanceFromData(ent, characterData)
	if not IsValid(ent) or not characterData then return end
	if LZY_IsLarvaCharacter(ent, characterData) then return end
	if LZY_IsRawBodyModel(characterData.body_model) then return end
	if not LZY_Character_FaceModelMatches(ent, characterData) then return end

	if characterData.skin_color and ent.SetSkin then
		ent:SetSkin(tonumber(characterData.skin_color) or 0)
	end

	local bg = LZY_Character_GetBodygroupsString(characterData)
	if bg and ent.SetBodyGroups then
		ent:SetBodyGroups(bg)
	end

	LZY_Character_ApplyShapeKeysFromData(ent, characterData)

	local eyesColor = normalizeEyesColor(characterData.eyes_color) or Color(255, 255, 255)
	ent.EyesColor = eyesColor
	ApplyPupilsFromCharacterData(ent, characterData.gender, characterData)
end

local function LZY_Character_FaceDiffuseMaterialReady(ent)
	if not IsValid(ent) then return false end
	local diffIdx = LZY_Character_FindLikelyFaceDiffuseSubMaterialIndex(ent)
	if diffIdx == nil then return false end
	local mats = ent:GetMaterials()
	if not mats then return false end
	local slotName = mats[diffIdx + 1]
	if not isstring(slotName) or slotName == "" then return false end
	local base = Material(slotName)
	if base:IsError() then return false end
	local baseTex = base:GetTexture("$basetexture")
	if not baseTex or (baseTex.IsError and baseTex:IsError()) then return false end
	local w = baseTex.GetMappingWidth and baseTex:GetMappingWidth() or baseTex:Width()
	return isnumber(w) and w >= 64
end

local function LZY_Character_ScheduleFaceAppearanceRefresh(ent, characterData)
	if not IsValid(ent) or not characterData then return end
	if LZY_IsLarvaCharacter(ent, characterData) then return end
	if LZY_IsRawBodyModel(characterData.body_model) then return end
	local function refresh()
		if not IsValid(ent) then return end
		if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
			LZY_Character_NoteBuildBlockedByLoading()
			return
		end
		local d = (playersModels and playersModels[ent]) or characterData
		if not d then return end
		if LZY_IsLarvaCharacter(ent, d) then return end
		if LZY_IsRawBodyModel(d.body_model) then return end
		if not LZY_Character_FaceReadyForComposite(ent, d) then return end
		if not LZY_Character_FaceModelMatches(ent, d) then return end
		LZY_RefreshEntityFaceMaterials(ent, d)
	end
	timer.Simple(0, refresh)
	timer.Simple(0.15, refresh)
	timer.Simple(0.5, refresh)
end

local function normalizeTattooColor(c)
	if not c then return Color(255, 255, 255) end
	if type(c) == "table" and (c.r or c.g or c.b) then
		return Color(c.r or 255, c.g or 255, c.b or 255)
	end
	if type(c) == "table" and c[1] then
		return Color(c[1], c[2] or 255, c[3] or 255)
	end
	if IsColor(c) then return c end
	return Color(255, 255, 255)
end

local tattoo_rt_mat_cache = {}
local tattoo_rt_tex_keepalive = {}
local TATTOO_BLIT_OPAQUE
local TATTOO_BLIT_TRANS
local TATTOO_BLIT_ALPHA_MASK

function LZY_InvalidateFaceRenderCaches()
	_lzy_face_rt_epoch = _lzy_face_rt_epoch + 1
	table.Empty(tattoo_rt_mat_cache)
	table.Empty(tattoo_rt_tex_keepalive)
	if LZY_BodyTattoo_ResetBakes then LZY_BodyTattoo_ResetBakes() end
	table.Empty(hair_grad_rt_cache)
	table.Empty(hair_grad_mat_cache)
	table.Empty(hair_cheap_mat_cache)
	TATTOO_BLIT_OPAQUE = nil
	TATTOO_BLIT_TRANS = nil
	TATTOO_BLIT_ALPHA_MASK = nil
	for _, ply in player.Iterator() do
		if IsValid(ply) then
			ply._lzyHairGradMatApplied = nil
			ply._hairMaterialIndex = nil
			ply._lzyHairGradFaceRetryPending = nil
		end
	end
end

function LZY_Character_TattooMaxAxisForEntity(ent)
	if not IsValid(ent) then return 0 end
	local full = math.Clamp(math.floor(tonumber(LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE) or 2048), 256, 2048)
	local isWorldChar = ent:IsPlayer() or ent._lzyCrowdDummy == true
	if not isWorldChar then return full end
	if ent == LocalPlayer() then return full end
	if LZY_OPTIMISATIONS and LZY_OPTIMISATIONS.GetHideOtherTattoos and LZY_OPTIMISATIONS.GetHideOtherTattoos() then
		return 0
	end
	if ent._lzyShouldDraw == false then return 0 end
	local lp = LocalPlayer()
	if not IsValid(lp) then return 0 end
	local distSqr = ent:GetPos():DistToSqr(lp:GetPos())
	if distSqr > LZY_CHARACTER_CONFIG.GetTattooDistanceSqr() then
		return 0
	end
	if not LZY_PlayerLODCVar:GetBool() then return full end
	local budget = LZY_Character_GetDetailBudget()
	if budget > 0 and ent._lzyNearDetail == false then
		return 0
	end
	return full
end

local function LZY_Character_DataHasTattoo(data)
	if not data then return false end
	for _, tslot in ipairs({ 1, 2, 3 }) do
		local suf = (tslot == 1) and "" or ("_" .. tslot)
		local path = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(tostring(data["tattoo_texture" .. suf] or ""))
		local opacity = math.Clamp(tonumber(data["tattoo_opacity" .. suf]) or 1.0, 0, 1)
		if path ~= "" and opacity > 0 then return true end
	end
	return false
end

local function quantizeTattooByte(n)
	n = math.Clamp(tonumber(n) or 255, 0, 255)
	return math.Clamp(math.floor(n / 16 + 0.5) * 16, 0, 255)
end

local function quantizeNorm01(val, buckets)
	val = tonumber(val) or 0.5
	buckets = tonumber(buckets) or 48
	local i = math.floor(val * buckets + 0.5)
	i = math.Clamp(i, 0, buckets)
	return i / buckets
end

local function tattooPickerTranslateDXDY(px, py)
	px = math.Clamp(tonumber(px) or 0.5, 0, 1)
	py = math.Clamp(tonumber(py) or 0.5, 0, 1)
	local k = tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_TRANSLATE_STRENGTH) or 2
	local biasX = tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_X) or 0
	local biasY = tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_Y) or 0
	local dx = math.Clamp((px - 0.5) * k + biasX, -1.5, 1.5)
	local dy = math.Clamp((py - 0.5) * k + biasY, -1.5, 1.5)
	return dx, dy
end

local TATTOO_CLONE_SKIP_SCALAR_LOWER = {
	["$basemapalphaphongmask"] = true,
	["$basemapalphaenvmapmask"] = true,
	["$blendtintbybasealpha"] = true,
	["$selfillum"] = true,
	["$selfillummask"] = true,
	["$selfillumtint"] = true,
	["$translucent"] = true,
	["$alphatest"] = true, ["$alphatestreference"] = true,
	["$alpha"] = true,
	["$basetexture"] = true,
	["$halflambert"] = true,
	["include"] = true,
	["fallbackmaterial"] = true,
	["proxies"] = true,
	["$flags"]          = true,
	["$flags2"]         = true,
	["$flags_defined"]  = true,
	["$flags_defined2"] = true,
}

local TATTOO_CLONE_TEXTURE_KEYS = {
	"$bumpmap", "$bumpmap2", "$normalmap",
	"$detail",
	"$lightwarptexture",
	"$selfillummask",
	"$phongexponenttexture", "$phongwarptexture",
}

local TATTOO_CLONE_MATRIX_KEYS = {
	"$basetexturetransform", "$bumptransform", "$normalmaptransform",
	"$detailtexturetransform",
}

local function tattoo_CloneFaceScalarParams(baseMat, params)
	if not baseMat or baseMat:IsError() or not params then return end
	local kv = baseMat.GetKeyValues and baseMat:GetKeyValues() or nil
	if not istable(kv) then return end
	for k, v in pairs(kv) do
		if isstring(k) and v ~= nil then
			local lk = string.lower(k)
			if not TATTOO_CLONE_SKIP_SCALAR_LOWER[lk] and not istable(v) then
				params[k] = v
			end
		end
	end
end

local function tattoo_CloneFaceTexturesAndMatrices(baseMat, newMat)
	if not baseMat or baseMat:IsError() or not newMat or newMat:IsError() then return end
	for _, tk in ipairs(TATTOO_CLONE_TEXTURE_KEYS) do
		local ok, t = pcall(baseMat.GetTexture, baseMat, tk)
		if ok and t and not (t.IsError and t:IsError()) then
			local n = t:GetName()
			if isstring(n) and n ~= "" then
				pcall(newMat.SetTexture, newMat, tk, t)
			end
		end
	end
	if baseMat.GetMatrix and newMat.SetMatrix then
		for _, mk in ipairs(TATTOO_CLONE_MATRIX_KEYS) do
			local mx = baseMat:GetMatrix(mk)
			if mx then pcall(newMat.SetMatrix, newMat, mk, mx) end
		end
	end
end

local function tattoo_GetOrCreateRenderTarget(rtName, w, h)
	local rt
	if GetRenderTargetEx and IMAGE_FORMAT_BGRA8888 ~= nil then
		local sizeMode = RT_SIZE_LITERAL or 1
		local depthMode = MATERIAL_RT_DEPTH_NONE
		if depthMode == nil then depthMode = 2 end
		local texFlags = 4 + 8 + 16 + 1024 + 32768
		if bit and bit.bor then texFlags = bit.bor(4, 8, 16, 1024, 32768) end
		rt = GetRenderTargetEx(rtName, w, h, sizeMode, depthMode, texFlags, 0, IMAGE_FORMAT_BGRA8888)
	end
	if not rt then rt = GetRenderTarget(rtName, w, h) end
	return rt
end

local function tattoo_GetBlitOpaqueMaterial()
	if TATTOO_BLIT_OPAQUE and not TATTOO_BLIT_OPAQUE:IsError() then return TATTOO_BLIT_OPAQUE end
	TATTOO_BLIT_OPAQUE = CreateMaterial("lzy_tattoo_blit_opaque", "UnlitGeneric", {
		["$basetexture"] = "models/debug/debugwhite",
		["$vertexcolor"] = "1",
		["$nolod"] = "1",
	})
	return TATTOO_BLIT_OPAQUE
end

local function tattoo_GetBlitTranslucentMaterial()
	if TATTOO_BLIT_TRANS and not TATTOO_BLIT_TRANS:IsError() then return TATTOO_BLIT_TRANS end
	TATTOO_BLIT_TRANS = CreateMaterial("lzy_tattoo_blit_trans", "UnlitGeneric", {
		["$basetexture"] = "models/debug/debugwhite",
		["$alphatest"] = "1",
		["$alphatestreference"] = "0.5",
		["$vertexalpha"] = "1",
		["$vertexcolor"] = "1",
		["$nolod"] = "1",
	})
	return TATTOO_BLIT_TRANS
end

local function tattoo_GetBlitAlphaMaskMaterial()
	if TATTOO_BLIT_ALPHA_MASK and not TATTOO_BLIT_ALPHA_MASK:IsError() then return TATTOO_BLIT_ALPHA_MASK end
	TATTOO_BLIT_ALPHA_MASK = CreateMaterial("lzy_tattoo_blit_alpha_mask", "UnlitGeneric", {
		["$basetexture"] = "models/debug/debugwhite",
		["$translucent"] = "1",
		["$vertexalpha"] = "1",
		["$vertexcolor"] = "1",
		["$nolod"] = "1",
	})
	return TATTOO_BLIT_ALPHA_MASK
end

local function tattoo_DrawOverlayMaterial(mat, x, y, w, h, col, rot, cx, cy)
	if rot and rot ~= 0 then
		local m = Matrix()
		m:Translate(Vector(cx, cy, 0))
		m:Rotate(Angle(0, rot, 0))
		m:Translate(Vector(-w * 0.5, -h * 0.5, 0))
		cam.PushModelMatrix(m)
		RNDX.DrawMaterial(0, 0, 0, w, h, col, mat)
		cam.PopModelMatrix()
	else
		RNDX.DrawMaterial(0, x, y, w, h, col, mat)
	end
end

local function tattoo_BakeFaceTattooRT(rt, rtW, rtH, baseMat, overlays)
	local baseTex = baseMat:GetTexture("$basetexture")
	if not baseTex or (baseTex.IsError and baseTex:IsError()) then return false end

	local opaque = tattoo_GetBlitOpaqueMaterial()
	if not opaque or opaque:IsError() then return false end
	local trans = tattoo_GetBlitTranslucentMaterial()
	if not trans or trans:IsError() then return false end
	local alphaMaskMat = tattoo_GetBlitAlphaMaskMaterial()
	if not alphaMaskMat or alphaMaskMat:IsError() then return false end

	local frac = math.Clamp(tonumber(LZY_CHARACTER_CONFIG.TATTOO_RT_DECAL_SIZE) or 0.30, 0.05, 1)

	local rects = {}
	for i, ov in ipairs(overlays) do
		local tex = ov.mat and ov.mat:GetTexture("$basetexture") or nil
		if tex and not (tex.IsError and tex:IsError()) then
			local dx, dy = tattooPickerTranslateDXDY(ov.px, ov.py)
			local sX = math.Clamp(tonumber(ov.scaleX) or 1.0, 0.05, 10.0)
			local sY = math.Clamp(tonumber(ov.scaleY) or 1.0, 0.05, 10.0)
			local w = rtW * math.Clamp(frac * sX, 0.02, 1)
			local h = rtH * math.Clamp(frac * sY, 0.02, 1)
			local cx = rtW * (0.5 + dx)
			local cy = rtH * (0.5 + dy)
			rects[i] = { tex = tex, c = normalizeTattooColor(ov.color), x = cx - w * 0.5, y = cy - h * 0.5, w = w, h = h, cx = cx, cy = cy, rot = (tonumber(ov.rotation) or 0) % 360, op = math.Clamp(tonumber(ov.opacity) or 1.0, 0, 1) }
		end
	end

	local ok, err = pcall(function()
		render.PushRenderTarget(rt)
		render.Clear(0, 0, 0, 0)
		cam.Start2D()
			render.OverrideAlphaWriteEnable(true, false)
			opaque:SetTexture("$basetexture", baseTex)
			RNDX.DrawMaterial(0, 0, 0, rtW, rtH, color_white, opaque)

			for i = 1, #rects do
				local r = rects[i]
				if r then
					render.OverrideAlphaWriteEnable(true, false)
					trans:SetTexture("$basetexture", r.tex)
					tattoo_DrawOverlayMaterial(trans, r.x, r.y, r.w, r.h, Color(r.c.r, r.c.g, r.c.b, 255), r.rot, r.cx, r.cy)
					render.OverrideAlphaWriteEnable(false)

					if r.op < 1 then
						render.OverrideAlphaWriteEnable(true, false)
						alphaMaskMat:SetTexture("$basetexture", baseTex)
						surface.SetDrawColor(255, 255, 255, math.floor((1 - r.op) * 255))
						surface.SetMaterial(alphaMaskMat)
						local bx, by, bw, bh = r.x, r.y, r.w, r.h
						if r.rot ~= 0 then
							local rad = math.rad(r.rot)
							local cosr, sinr = math.abs(math.cos(rad)), math.abs(math.sin(rad))
							bw = r.w * cosr + r.h * sinr
							bh = r.w * sinr + r.h * cosr
							bx = r.cx - bw * 0.5
							by = r.cy - bh * 0.5
						end
						local u0, v0 = bx / rtW, by / rtH
						local u1, v1 = (bx + bw) / rtW, (by + bh) / rtH
						surface.DrawTexturedRectUV(bx, by, bw, bh, u0, v0, u1, v1)
						render.OverrideAlphaWriteEnable(false)
					end
				end
			end

			render.OverrideAlphaWriteEnable(true, true)
			render.OverrideColorWriteEnable(true, false)
			render.OverrideBlend(true, BLEND_ONE, BLEND_ZERO, BLENDFUNC_ADD)
			for i = 1, #rects do
				local r = rects[i]
				if r then
					alphaMaskMat:SetTexture("$basetexture", r.tex)
					surface.SetDrawColor(255, 255, 255, math.floor((r.op or 1) * 255))
					surface.SetMaterial(alphaMaskMat)
					if r.rot ~= 0 then
						surface.DrawTexturedRectRotated(r.cx, r.cy, r.w, r.h, r.rot)
					else
						surface.DrawTexturedRect(r.x, r.y, r.w, r.h)
					end
				end
			end
			render.OverrideBlend(false)
			render.OverrideColorWriteEnable(false)
			render.OverrideAlphaWriteEnable(false)
		cam.End2D()
		render.PopRenderTarget()
	end)

	if not ok then
		if render.PopRenderTarget then pcall(render.PopRenderTarget) end
		if err then ErrorNoHaltWithStack(tostring(err)) end
		return false
	end
	return true
end

-- sStableKey (optionnel, aperçus du créateur / tatoueur / sélection, 10/01) : UNE RT par aperçu,
-- re-cuite sur place quand le contenu change, hors du cache par contenu. Sans elle, glisser le
-- tatouage créait une RT de 16 Mo jamais libérée par cran (OOM en quelques secondes).
function LZY_GetOrCreateTattooFaceRTSubMaterial(faceMatName, overlays, maxAxisCap, sStableKey)
	if not isstring(faceMatName) or faceMatName == "" then return nil end
	if not istable(overlays) or #overlays == 0 then return nil end

	local defaultCap = math.Clamp(math.floor(tonumber(LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE) or 1024), 256, 2048)
	local maxAxis = maxAxisCap or defaultCap
	maxAxis = math.Clamp(math.floor(tonumber(maxAxis) or defaultCap), 256, 2048)
	local decalFrac = math.Clamp(tonumber(LZY_CHARACTER_CONFIG.TATTOO_RT_DECAL_SIZE) or 0.30, 0.05, 1)

	local prepared = {}
	local keyParts = { faceMatName, "rt12opblend", "d" .. string.format("%.2f", decalFrac), "cap" .. maxAxis }
	for i, ov in ipairs(overlays) do
		if isstring(ov.path) and ov.path ~= "" then
			local c = normalizeTattooColor(ov.color)
			local rq = quantizeTattooByte(c.r)
			local gq = quantizeTattooByte(c.g)
			local bq = quantizeTattooByte(c.b)
			local qx = math.Round((tonumber(ov.px) or 0.5) * 1000) / 1000
			local qy = math.Round((tonumber(ov.py) or 0.5) * 1000) / 1000
			local qsx = math.Round((tonumber(ov.scaleX) or 1.0) * 100) / 100
			local qsy = math.Round((tonumber(ov.scaleY) or 1.0) * 100) / 100
			local qop = math.Round(math.Clamp(tonumber(ov.opacity) or 1.0, 0, 1) * 100) / 100
			local qrot = math.Round((tonumber(ov.rotation) or 0)) % 360
			prepared[#prepared + 1] = { path = ov.path, color = c, px = qx, py = qy, scaleX = qsx, scaleY = qsy, opacity = qop, rotation = qrot }
			keyParts[#keyParts + 1] = "ov" .. i .. "=" .. ov.path
				.. "|" .. rq .. "|" .. gq .. "|" .. bq
				.. "|tu" .. string.format("%.3f", qx) .. "v" .. string.format("%.3f", qy)
				.. "|sx" .. string.format("%.2f", qsx) .. "sy" .. string.format("%.2f", qsy)
				.. "|op" .. string.format("%.2f", qop)
				.. "|rot" .. qrot
		end
	end
	if #prepared == 0 then return nil end

	local base = Material(faceMatName)
	if base:IsError() then return nil end

	local baseTex0 = base:GetTexture("$basetexture")
	local nativeW, nativeH = maxAxis, maxAxis
	if baseTex0 and not (baseTex0.IsError and baseTex0:IsError()) then
		local tw = baseTex0.GetMappingWidth and baseTex0:GetMappingWidth() or nil
		local th = baseTex0.GetMappingHeight and baseTex0:GetMappingHeight() or nil
		if not isnumber(tw) or tw <= 0 then
			tw = baseTex0.Width and baseTex0:Width() or nil
		end
		if not isnumber(th) or th <= 0 then
			th = baseTex0.Height and baseTex0:Height() or nil
		end
		if isnumber(tw) and isnumber(th) and tw > 0 and th > 0 then
			nativeW, nativeH = tw, th
		end
	end
	local scl = maxAxis / math.max(nativeW, nativeH)
	local rtW = math.Clamp(math.floor(nativeW * scl), 64, 2048)
	local rtH = math.Clamp(math.floor(nativeH * scl), 64, 2048)
	keyParts[#keyParts + 1] = "rt" .. rtW .. "x" .. rtH

	local cacheKey = table.concat(keyParts, "|")
	-- Signatures des RT stables rangées DANS le cache (vidé avec lui par LZY_InvalidateFaceRenderCaches).
	local tStable = (isstring(sStableKey) and sStableKey ~= "") and (tattoo_rt_mat_cache.__stable or {}) or nil
	if tStable then tattoo_rt_mat_cache.__stable = tStable end
	local cached = (not tStable) and tattoo_rt_mat_cache[cacheKey] or nil
	if cached then return cached end

	local bakeOverlays = {}
	for i, ov in ipairs(prepared) do
		local mat = Material(ov.path)
		if mat:IsError() then return nil end
		bakeOverlays[i] = { mat = mat, color = ov.color, px = ov.px, py = ov.py, scaleX = ov.scaleX, scaleY = ov.scaleY, opacity = ov.opacity, rotation = ov.rotation }
	end

	local matName = "lzy_tat_rt_" .. util.CRC(cacheKey)
	local rtName = "rt_" .. matName
	if tStable then
		rtName = "rt_lzy_tat_st_" .. sStableKey .. "_" .. rtW .. "x" .. rtH
		matName = "lzy_tat_st_" .. sStableKey .. "_" .. util.CRC(faceMatName .. "|" .. rtName)
		if tStable[rtName] == cacheKey and not Material("!" .. matName):IsError() then return "!" .. matName end
	end

	local rt = tattoo_GetOrCreateRenderTarget(rtName, rtW, rtH)
	if not rt then return nil end

	if not tattoo_BakeFaceTattooRT(rt, rtW, rtH, base, bakeOverlays) then
		return nil
	end
	if tStable then
		tStable[rtName] = cacheKey
		tattoo_rt_tex_keepalive[rtName] = rt
		local mExist = Material("!" .. matName)
		if not mExist:IsError() then
			mExist:SetTexture("$basetexture", rt)
			return "!" .. matName
		end
	end

	local params = {
		["$basetexture"] = "models/debug/debugwhite",
	}
	tattoo_CloneFaceScalarParams(base, params)
	params["$selfillum"] = "1"
	params["$selfillumtint"] = "[2 2 2]"
	params["$halflambert"] = "1"

	local baseShader = "VertexLitGeneric"
	if base.GetShader then
		local s = base:GetShader()
		if isstring(s) and s ~= "" then baseShader = s end
	end

	local m = CreateMaterial(matName, baseShader, params)
	if m:IsError() then
		return nil
	end

	m:SetTexture("$basetexture", rt)
	tattoo_CloneFaceTexturesAndMatrices(base, m)
	tattoo_rt_tex_keepalive[rtName] = rt

	local sub = "!" .. matName
	if not tStable then tattoo_rt_mat_cache[cacheKey] = sub end
	return sub
end

-- ════════════════════════════════════════════════════════════════════════════
-- TATOUAGES DU CORPS (10/01, test tattoo_corps_v1, cf. LZY_CHARACTER_CONFIG.BODY_TATTOO).
-- RT et matériau STABLES PAR PORTEUR (pas par contenu, contrairement au visage) : l'éditeur
-- re-cuit dans la même texture à chaque réglage, aucune RT nouvelle par cran de slider.
-- Le matériau garde le shader et TOUS les paramètres du VMT de peau ; la RT garde l'alpha
-- de la peau (masques du VMT) : seuls les pixels de couleur des motifs changent.
-- ⚠ Bloc do...end : ce fichier est à la limite Lua de 200 locales actives au niveau fichier.
-- ════════════════════════════════════════════════════════════════════════════
do
-- Les $flags SONT copiés : $halflambert (VMT des peaux) n'existe que comme bit de $flags ;
-- sans lui l'ombrage toon (lightwarp) changeait dès qu'un tatouage était posé (user 10/02).
local BODYTAT_CLONE_SKIP = {
	["$basetexture"] = true, ["include"] = true, ["fallbackmaterial"] = true, ["proxies"] = true,
}
local bodyTat_keep = {}
local bodyTat_sig = {} -- [rtName] = signature du dernier bake (vidé = re-cuisson forcée)
-- Appelé par LZY_InvalidateFaceRenderCaches (alt-tab / VRAM : le contenu des RT est perdu).
function LZY_BodyTattoo_ResetBakes() table.Empty(bodyTat_sig) end

-- Indice du matériau de peau de la teinte COURANTE (`.../skin_body_m|f|m_citoyen` ou `_<skin>`,
-- tous dossiers, details/<famille>/ compris), par NOM. Repli : la peau de base (teinte 0).
local function bodyTat_FindSkinIndex(bodyEnt)
	local skin = bodyEnt:GetSkin() or 0
	local tMats = bodyEnt:GetMaterials() or {}
	local fbIdx, fbName
	for _, sLeaf in ipairs(LZY_CHARACTER_CONFIG.BODY_TATTOO.SKIN_LEAVES) do
		local leaf = "/" .. sLeaf
		local want = (skin > 0) and (leaf .. "_" .. skin) or leaf
		for i, m in ipairs(tMats) do
			local low = string.lower(m)
			if string.EndsWith(low, want) then return i - 1, m end
			if not fbIdx and string.EndsWith(low, leaf) then fbIdx, fbName = i - 1, m end
		end
	end
	return fbIdx, fbName
end
LZY_BodyTattoo_FindSkinIndex = bodyTat_FindSkinIndex -- picking UV du créateur (cl_tattoo_pick)

-- Matériau de copie PROPRE à une texture. surface.DrawTexturedRect recale ses UV d'un
-- demi-texel de la texture d'ORIGINE du matériau : un matériau générique (debugwhite, 16 px)
-- dont on change la texture décalait et étirait la peau d'environ 3 % dans la RT (muscles du
-- torse qui bougent dès qu'on pose un tatouage, user 10/02).
local function bodyTat_BlitMat(tex, bTrans)
	local sName = (bTrans and "lzy_btat_blitt_" or "lzy_btat_blit_") .. util.CRC(tex:GetName())
	local m = Material("!" .. sName)
	if m:IsError() then
		m = CreateMaterial(sName, "UnlitGeneric", {
			["$basetexture"] = tex:GetName(), ["$vertexcolor"] = "1", ["$nolod"] = "1",
			["$translucent"] = bTrans and "1" or "0", ["$vertexalpha"] = bTrans and "1" or "0",
		})
	end
	return m
end

local function bodyTat_Bake(rt, rtW, rtH, baseMat, items, sG)
	local baseTex = baseMat:GetTexture("$basetexture")
	if not baseTex or (baseTex.IsError and baseTex:IsError()) then return false end
	local BT = LZY_CHARACTER_CONFIG.BODY_TATTOO
	local k = rtW / BT.ATLAS
	local rtMul = tattoo_GetOrCreateRenderTarget("rt_lzy_btat_mul_" .. rtW .. "x" .. rtH, rtW, rtH)
	if not rtMul then return false end
	local nCover = math.Clamp(tonumber(BT.INK_COVER) or 0.35, 0, 1)
	local function box(zid)
		local r = BT.ZONES[zid].rect
		local x0, y0 = math.floor(r[1] * k), math.floor(r[2] * k)
		local x1, y1 = math.ceil(r[3] * k), math.ceil(r[4] * k)
		return x0, y0, x1, y1, (x1 - x0) * BT.MAIN_FRAC
	end
	-- Un motif rogné à sa zone, recopié de part et d'autre de la couture ; fx/fy = échelle
	-- de la zone liée. MIROIR horizontal : le tour (u) des cylindres de l'atlas va vers la
	-- DROITE du perso, donc vers la gauche de qui le regarde -> sans ce retournement le motif
	-- se lisait comme dans un miroir (user 10/02). Winding inversé -> CullMode CW.
	local function stamp(x0, y0, x1, y1, tour, cx, cy, w, h, rot, fx, fy)
		render.SetScissorRect(x0, y0, x1, y1, true)
		render.CullMode(MATERIAL_CULLMODE_CW)
		for d = -1, 1 do
			local m = Matrix()
			m:Translate(Vector(cx + d * tour, cy, 0))
			m:Scale(Vector(-fx, fy, 1))
			cam.PushModelMatrix(m)
			surface.DrawTexturedRectRotated(0, 0, w, h, rot)
			cam.PopModelMatrix()
		end
		render.CullMode(MATERIAL_CULLMODE_CCW)
		render.SetScissorRect(0, 0, 0, 0, false)
	end
	local function drawItems(nAlpha)
		for _, it in ipairs(items) do
			local zt = BT.ZONES[it.z]
			local x0, y0, x1, y1, tour = box(it.z)
			local ang = (it.u + (zt.uoff or 0)) % 1
			local w = math.min(tour, y1 - y0) * BT.BASE_SIZE
			surface.SetMaterial(bodyTat_BlitMat(it.tex, true))
			surface.SetDrawColor(it.c.r, it.c.g, it.c.b, it.o * nAlpha * 255)
			stamp(x0, y0, x1, y1, tour, x0 + ang * tour, y0 + it.v * (y1 - y0), w * it.sx, w * it.sy, it.r, 1, 1)
			-- Zones liées (cou <-> torse) : même angle et même hauteur réelle -> le motif continue.
			local g = zt.geo and zt.geo[sG]
			for _, lid in ipairs((g and zt.link) or {}) do
				local lg = BT.ZONES[lid] and BT.ZONES[lid].geo and BT.ZONES[lid].geo[sG]
				if lg then
					local lx0, ly0, lx1, ly1, ltour = box(lid)
					local zc = g[1] - it.v * (g[1] - g[2])
					local fy = ((ly1 - ly0) / (lg[1] - lg[2])) / ((y1 - y0) / (g[1] - g[2]))
					stamp(lx0, ly0, lx1, ly1, ltour, lx0 + ang * ltour, ly0 + (lg[1] - zc) / (lg[1] - lg[2]) * (ly1 - ly0),
						w * it.sx, w * it.sy, it.r, ltour / tour, fy)
				end
			end
		end
	end
	local ok, err = pcall(function()
		-- 0) carte d'encre : blanc + motifs = facteur de multiplication (blanc = peau intacte)
		render.PushRenderTarget(rtMul)
		render.Clear(255, 255, 255, 255)
		cam.Start2D()
			drawItems(1)
		cam.End2D()
		render.PopRenderTarget()

		render.PushRenderTarget(rt)
		render.Clear(0, 0, 0, 0)
		cam.Start2D()
			-- 1) peau (couleur seule)
			render.OverrideAlphaWriteEnable(true, false)
			surface.SetMaterial(bodyTat_BlitMat(baseTex))
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawTexturedRect(0, 0, rtW, rtH)
			-- 2) encre = peau x carte : pectoraux, abdos et ombres peints restent sous le motif
			render.OverrideBlend(true, BLEND_DST_COLOR, BLEND_ZERO, BLENDFUNC_ADD)
			surface.SetMaterial(bodyTat_BlitMat(rtMul))
			surface.DrawTexturedRect(0, 0, rtW, rtH)
			render.OverrideBlend(false)
			-- 2b) une part posée par-dessus : sans elle une encre claire (blanc) serait invisible
			if nCover > 0 then drawItems(nCover) end
			-- 3) alpha = alpha de la peau (blend ONE/ZERO, couleur verrouillée)
			render.OverrideAlphaWriteEnable(true, true)
			render.OverrideColorWriteEnable(true, false)
			render.OverrideBlend(true, BLEND_ONE, BLEND_ZERO, BLENDFUNC_ADD)
			surface.SetMaterial(bodyTat_BlitMat(baseTex, true))
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawTexturedRect(0, 0, rtW, rtH)
			render.OverrideBlend(false)
			render.OverrideColorWriteEnable(false)
			render.OverrideAlphaWriteEnable(false)
		cam.End2D()
		render.PopRenderTarget()
	end)
	if not ok then
		pcall(render.SetScissorRect, 0, 0, 0, 0, false)
		pcall(cam.PopModelMatrix)
		pcall(render.CullMode, MATERIAL_CULLMODE_CCW)
		pcall(render.OverrideBlend, false)
		pcall(render.PopRenderTarget)
		if err then ErrorNoHaltWithStack(tostring(err)) end
		return false
	end
	return true
end

--- Applique (ou retire) les tatouages corps de `data.body_tattoos` sur la PEAU de bodyEnt.
--- ownerKey : clé de porteur stable ([%w_]), maxAxis : plafond LOD (0 = retirer).
function LZY_ApplyBodyTattoo(bodyEnt, data, ownerKey, maxAxis)
	if not IsValid(bodyEnt) then return end
	local idx, baseName = bodyTat_FindSkinIndex(bodyEnt)
	local prevIdx = bodyEnt._lzyBodyTatIdx
	if prevIdx and prevIdx ~= idx then bodyEnt:SetSubMaterial(prevIdx, "") bodyEnt._lzyBodyTatIdx = nil end
	local list = istable(data) and LZY_CHARACTER_CONFIG.SanitizeBodyTattoos(data.body_tattoos) or {}
	maxAxis = math.Clamp(math.floor(tonumber(maxAxis) or 0), 0, 2048)
	local items, sig = {}, { tostring(baseName), maxAxis }
	if idx and maxAxis >= 256 then
		for _, e in ipairs(list) do
			local m = Material(e.t)
			local tex = (not m:IsError()) and m:GetTexture("$basetexture") or nil
			if tex and not (tex.IsError and tex:IsError()) then
				items[#items + 1] = { tex = tex, z = e.z, u = e.u, v = e.v, sx = e.sx, sy = e.sy, r = e.r, o = e.o, c = e.c }
				sig[#sig + 1] = table.concat({ e.t, e.z, e.u, e.v, e.sx, e.sy, e.r, e.o, e.c.r, e.c.g, e.c.b }, ",")
			end
		end
	end
	if #items == 0 then
		if bodyEnt._lzyBodyTatIdx then bodyEnt:SetSubMaterial(bodyEnt._lzyBodyTatIdx, "") end
		bodyEnt._lzyBodyTatIdx = nil
		return
	end

	local base = Material(baseName)
	local baseTex = (not base:IsError()) and base:GetTexture("$basetexture") or nil
	if not baseTex or (baseTex.IsError and baseTex:IsError()) then return end
	local tw = baseTex.GetMappingWidth and baseTex:GetMappingWidth() or 0
	local th = baseTex.GetMappingHeight and baseTex:GetMappingHeight() or 0
	if tw <= 0 or th <= 0 then tw, th = maxAxis, maxAxis end
	local scl = maxAxis / math.max(tw, th)
	local rtW, rtH = math.Clamp(math.floor(tw * scl), 64, 2048), math.Clamp(math.floor(th * scl), 64, 2048)

	local rtName = "rt_lzy_btat_" .. ownerKey .. "_" .. rtW .. "x" .. rtH
	local rt = tattoo_GetOrCreateRenderTarget(rtName, rtW, rtH)
	if not rt then return end
	local sSig = table.concat(sig, "|")
	if bodyTat_sig[rtName] ~= sSig then
		local sG = string.find(string.lower(baseName), "skin_body_f", 1, true) and "f" or "m"
		if not bodyTat_Bake(rt, rtW, rtH, base, items, sG) then return end
		bodyTat_sig[rtName] = sSig
		bodyTat_keep[rtName] = rt
	end

	local matName = "lzy_btat_" .. ownerKey .. "_" .. util.CRC(baseName .. "|" .. rtName)
	local m = Material("!" .. matName)
	if m:IsError() then
		local params = { ["$basetexture"] = "models/debug/debugwhite" }
		local kv = base.GetKeyValues and base:GetKeyValues() or nil
		if istable(kv) then
			for key, v in pairs(kv) do
				if isstring(key) and v ~= nil and not istable(v) and not BODYTAT_CLONE_SKIP[string.lower(key)] then params[key] = v end
			end
		end
		m = CreateMaterial(matName, (base.GetShader and base:GetShader()) or "VertexLitGeneric", params)
		if m:IsError() then return end
		tattoo_CloneFaceTexturesAndMatrices(base, m)
	end
	m:SetTexture("$basetexture", rt)
	-- Matériau déjà créé sans les drapeaux (session en cours) : on les recopie une fois.
	local nF, nF2 = base:GetInt("$flags") or 0, base:GetInt("$flags2") or 0
	if m:GetInt("$flags") ~= nF or m:GetInt("$flags2") ~= nF2 then
		m:SetInt("$flags", nF)
		m:SetInt("$flags2", nF2)
		m:Recompute()
	end
	bodyEnt:SetSubMaterial(idx, "!" .. matName)
	bodyEnt._lzyBodyTatIdx = idx
end
end -- do (tatouages du corps)

local function tattoo_FaceMatNameExcluded(low)
	if string.find(low, "pupil", 1, true)
		or string.find(low, "sclera", 1, true)
		or string.find(low, "lash", 1, true)
		or string.find(low, "brow", 1, true)
		or string.find(low, "iris", 1, true)
		or string.find(low, "lid", 1, true)
		or string.find(low, "eye", 1, true)
		or string.find(low, "moist", 1, true)
		or string.find(low, "teeth", 1, true)
		or string.find(low, "tooth", 1, true)
		or string.find(low, "tongue", 1, true)
		or string.find(low, "warp", 1, true)
		or string.find(low, "_details", 1, true)
		or string.find(low, "/details", 1, true)
		or string.find(low, "/detail/", 1, true)
		or string.find(low, "detailmap", 1, true)
		or string.find(low, "/uni/", 1, true)
		or string.find(low, "hair", 1, true)
		or string.find(low, "/tattoo/", 1, true)
		or string.find(low, "/tatoo/", 1, true)
		or string.find(low, "evo/hair", 1, true) then
		return true
	end
	return false
end

local function tattoo_FaceDiffuseCandidateScore(low)
	if tattoo_FaceMatNameExcluded(low) then return nil end
	local s = 0
	if string.find(low, "evo/face/", 1, true) then s = s + 8 end
	if string.find(low, "skin", 1, true) or string.find(low, "faces", 1, true) or string.find(low, "tone", 1, true)
		or string.find(low, "complexion", 1, true) then
		s = s + 32
	end
	if string.find(low, "lip", 1, true) or string.find(low, "mouth_inside", 1, true)
		or string.find(low, "teeth_line", 1, true) then
		s = s - 20
	end
	return s
end

local function tattoo_NormalizeMatPath(mname)
	return string.gsub(string.lower(tostring(mname or "")), "\\", "/")
end

local function tattoo_MaterialBaseTextureWidth(mname)
	local mm = Material(mname)
	if not mm or mm:IsError() then return 0 end
	local bt = mm:GetTexture("$basetexture")
	if not bt or (bt.IsError and bt:IsError()) then return 0 end
	return bt:Width() or 0
end

function LZY_Character_FindLikelyFaceDiffuseSubMaterialIndex(ent)
	if not IsValid(ent) then return nil end
	local mats = ent:GetMaterials()
	if not mats then return nil end

	local hint = LZY_CHARACTER_CONFIG.TATTOO_FACE_DIFFUSE_HINT
	local hintLc = hint and hint ~= "" and string.lower(hint) or nil

	if hintLc then
		for i, mname in ipairs(mats) do
			local low = tattoo_NormalizeMatPath(mname)
			if string.find(low, hintLc, 1, true) and not tattoo_FaceMatNameExcluded(low) then
				return i - 1
			end
		end
		return nil
	end

	local skin = (ent.GetSkin and ent:GetSkin()) or 0
	local skinSuffix = skin == 0 and "/face" or ("/face_" .. skin)
	for i, mname in ipairs(mats) do
		local low = tattoo_NormalizeMatPath(mname)
		if not tattoo_FaceMatNameExcluded(low) and string.sub(low, -#skinSuffix) == skinSuffix then
			return i - 1
		end
	end

	local bestIdx, bestScore = nil, -math.huge
	for i, mname in ipairs(mats) do
		local low = tattoo_NormalizeMatPath(mname)
		if not tattoo_FaceMatNameExcluded(low) then
			local s = tattoo_FaceDiffuseCandidateScore(low) or 0
			if string.find(low, "black", 1, true) or string.match(low, "/white$")
				or string.find(low, "default", 1, true) or string.find(low, "placeholder", 1, true) then
				s = s - 100
			end
			local w = tattoo_MaterialBaseTextureWidth(mname)
			if w >= 256 then s = s + 20 end
			if w <= 64 then s = s - 30 end
			if s > bestScore then
				bestScore = s
				bestIdx = i - 1
			end
		end
	end
	return bestIdx
end

local function LZY_LarvaRawDrawModel(ent)
	if not IsValid(ent) then return end
	if ent.IsDormant and ent:IsDormant() then return end
	render.SuppressEngineLighting(true)
	render.SetLightingOrigin(ent:GetPos())
	render.ResetModelLighting(50 / 255, 50 / 255, 50 / 255)
	render.SetModelLighting(BOX_TOP, 1, 1, 1)
	render.SetColorModulation(1, 1, 1)
	render.SetBlend(1)
	ent:DrawShadow(false)
	if ent.AddEffects then ent:AddEffects(EF_NOSHADOW) end
	ent:DrawModel()
	render.SuppressEngineLighting(false)
end

local LZY_Character_InvalidateStaleRawModel

local function LZY_SetLarvaRawRenderOverride(ent)
	local renderOverride = function()
		if not LZY_IsLarvaCharacter(ent) and not ent._lzyLarvaExitPending then
			if LZY_Character_InHubOrFinalizeFlow(ent) then
				local d = playersModels and playersModels[ent]
				if d and LZY_IsRawBodyModel(d.body_model) then
					playersModels[ent] = nil
				end
				if ent.RenderOverride == ent._lzyCompositeRenderOverride then
					ent.RenderOverride = nil
				end
				ent._lzyCompositeRenderOverride = nil
				return
			end
			if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ent) then
				return
			end
			local d = playersModels and playersModels[ent]
			if d and isstring(d.body_model) and d.body_model ~= "" then
				ent._lzyLarvaExitPending = true
				timer.Simple(0, function()
					if not IsValid(ent) then return end
					ent._lzyLarvaExitPending = nil
					if LZY_Character_InHubOrFinalizeFlow(ent) then return end
					if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ent) then
						return
					end
					local dd = playersModels and playersModels[ent]
					if dd and not LZY_IsLarvaCharacter(ent, dd) and LZY_Character_TryCreatePlayerClientModels then
						LZY_Character_TryCreatePlayerClientModels(ent, dd)
					end
				end)
			end
		end
		LZY_LarvaRawDrawModel(ent)
	end
	ent._lzyCompositeRenderOverride = renderOverride
	ent.RenderOverride = renderOverride
	if ent.DrawShadow then ent:DrawShadow(false) end
	if ent.AddEffects then ent:AddEffects(EF_NOSHADOW) end
end

local trackedParts = {}

local cvLzyPartsSingleDraw = CreateClientConVar("lzy_parts_singledraw", "1", true, false,
    "1 = parts bonemergees dessinees 1x (via le joueur). 0 = ancien rendu (2x).")

local cvLzyDbgHideParts = CreateClientConVar("lzy_dbg_hideparts", "0", false, false,
    "DIAG: 1 = cache les parts cosmetiques des joueurs (mesure du cout GPU des parts).")

local function createModelPart(ent, model, color, skinColor)
	if not model then return "" end
	if istable(model) then
		local picked
		for _, v in pairs(model) do
			if isstring(v) and v ~= "" then picked = v break end
		end
		model = picked
	end
	if not isstring(model) or model == "" then return "" end
	local mdl = ClientsideModel(model, RENDERGROUP_OPAQUE)

	if not IsValid(mdl) then return end
	if not color then color = Color(255, 255, 255, 255) end
	if not color.a then color.a = 255 end

	mdl:SetParent(ent)
	mdl:SetLocalPos(Vector(0, 0, 0))
	mdl:SetLocalAngles(Angle(0, 0, 0))
	mdl:SetNoDraw(cvLzyPartsSingleDraw:GetBool())
	mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
	if mdl.DrawShadow then mdl:DrawShadow(false) end
	if mdl.AddEffects then mdl:AddEffects(EF_NOSHADOW) end

	mdl:SetRenderMode(RENDERMODE_TRANSCOLOR)
    if skinColor then
        mdl:SetSkin(skinColor)
    end
	mdl:SetColor(color)

	if not cvLzyPartsSingleDraw:GetBool() then
    mdl.RenderOverride = function()
        if cvLzyPartsSingleDraw:GetBool() then return end
        if not IsValid(ent) then return end
        if mdl:GetParent() ~= ent then return end
        if ent.IsDormant and ent:IsDormant() then return end

        local localPly = LocalPlayer()
        if not IsValid(localPly) then return end

        if ent:IsPlayer() and ent ~= localPly then
            local entInstanced   = ent:GetEvoNWBool("NCM_Instanced", false)
            local localInstanced = localPly:GetEvoNWBool("NCM_Instanced", false)
            if entInstanced ~= localInstanced then return end
            if entInstanced and localInstanced
               and ent:GetEvoNWString("NCM_InstanceZone", "") ~= localPly:GetEvoNWString("NCM_InstanceZone", "") then
                return
            end
        end

        if LZY_Character_IsLocalInCharMenu()
			and ent:IsPlayer() and ent ~= localPly then
            return
        end
        if ent:IsPlayer() and not ent._FlashStepGhostDrawParts
            and (ent:GetNoDraw() or ent.EVO_FlashStepHidden or ent:GetEvoNWBool("EVO_FullHide", false)) then
            return
        end

        if ent:IsPlayer() and ent ~= localPly and EVO_Portal and EVO_Portal.PlayersSeparated
            and EVO_Portal.PlayersSeparated(localPly, ent) then
            return
        end

        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1)
        if mdl._lzyAccessorySlot and LZY_Character_DrawAccessoryModel then
            local charData = playersModels and playersModels[ent]
            LZY_Character_DrawAccessoryModel(ent, mdl, charData)
        else
            mdl:DrawModel()
        end
    end
	end

	if IsValid(ent) and ent:IsPlayer() then
		mdl.owner_steamid64 = ent:SteamID64()
	end

	trackedParts[mdl] = true
	return mdl
end

local function LZY_ClearTattooDecoration(ent)
	if not IsValid(ent) then return end

	if ent._lzy_tattooSlotIdx ~= nil then
		ent:SetSubMaterial(ent._lzy_tattooSlotIdx, nil)
	end

	if IsValid(ent.tattooOverlayEnt) then
		SafeRemoveEntity(ent.tattooOverlayEnt)
		ent.tattooOverlayEnt = nil
	end

	if ent:IsPlayer() and istable(ent.PlayerModelParts) and IsValid(ent.PlayerModelParts.tattoo) then
		trackedParts[ent.PlayerModelParts.tattoo] = nil
		SafeRemoveEntity(ent.PlayerModelParts.tattoo)
		ent.PlayerModelParts.tattoo = nil
	end

	ent._lzy_tattooMode = nil
	ent._lzy_tattooSlotIdx = nil
	ent._lzyTattooMaxAxisApplied = nil
	ent._lzyTattooOverlaySig = nil
	ent._lzyTattooRtEpoch = nil
end

local function LZY_Character_ComputeTattooOverlaySig(overlays)
	if not istable(overlays) or #overlays == 0 then return "" end
	local parts = {}
	for i, ov in ipairs(overlays) do
		local c = normalizeTattooColor(ov.color)
		parts[#parts + 1] = string.format(
			"%d:%s|r%d,g%d,b%d|p%.3f,%.3f|s%.2f,%.2f|o%.2f|rot%d",
			i, tostring(ov.path or ""),
			quantizeTattooByte(c.r), quantizeTattooByte(c.g), quantizeTattooByte(c.b),
			math.Round((tonumber(ov.px) or 0.5) * 1000) / 1000,
			math.Round((tonumber(ov.py) or 0.5) * 1000) / 1000,
			math.Round((tonumber(ov.scaleX) or 1.0) * 100) / 100,
			math.Round((tonumber(ov.scaleY) or 1.0) * 100) / 100,
			math.Round(math.Clamp(tonumber(ov.opacity) or 1.0, 0, 1) * 100) / 100,
			math.Round((tonumber(ov.rotation) or 0)) % 360
		)
	end
	return table.concat(parts, ";")
end

local function LZY_ClearCharacterVisualOverrides(ent, opts)
	if not IsValid(ent) then return end
	opts = opts or {}
	if not opts.silent then
		ent._lzyVisualOverrideGen = (ent._lzyVisualOverrideGen or 0) + 1
	end
	local gen = ent._lzyVisualOverrideGen or 0
	LZY_ClearTattooDecoration(ent)
	ent.HairDetailsColor = nil
	ent.EyesColor = nil
	ent._hairMaterialIndex = nil
	ent._lzyHairGradMatApplied = nil
	ent._lzyHairGradFaceRetryPending = nil
	if ent.SetSubMaterial then ent:SetSubMaterial() end
	local mats = ent.GetMaterials and ent:GetMaterials()
	if mats then
		for i = 1, #mats do
			ent:SetSubMaterial(i - 1, nil)
		end
	end
	if not opts.reschedule then return end
	local function reClear()
		if not IsValid(ent) then return end
		if (ent._lzyVisualOverrideGen or 0) ~= gen then return end
		if not LZY_IsLarvaCharacter(ent) and not LZY_IsRawBodyModel(ent:GetModel() or "") then return end
		LZY_ClearCharacterVisualOverrides(ent, { silent = true })
	end
	timer.Simple(0, reClear)
	timer.Simple(0.15, reClear)
	timer.Simple(0.5, reClear)
end

function LZY_ApplyTattooFromCharacterData(ent, data)
	if not IsValid(ent) or not data then return end
	if LZY_IsLarvaCharacter(ent, data) then return end
	if LZY_IsRawBodyModel(data.body_model) then return end

	local overlays = {}
	for _, tslot in ipairs({ 1, 2, 3 }) do
		local suf = (tslot == 1) and "" or ("_" .. tslot)
		local path = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(tostring(data["tattoo_texture" .. suf] or ""))
		data["tattoo_texture" .. suf] = path
		local opacity = math.Clamp(tonumber(data["tattoo_opacity" .. suf]) or 1.0, 0, 1)
		if path ~= "" and opacity > 0 then
			overlays[#overlays + 1] = {
				path = path,
				color = normalizeTattooColor(data["tattoo_color" .. suf]),
				px = math.Clamp(tonumber(data["tattoo_pos_x" .. suf]) or 0.5, 0, 1),
				py = math.Clamp(tonumber(data["tattoo_pos_y" .. suf]) or 0.5, 0, 1),
				scaleX = math.Clamp(tonumber(data["tattoo_scale_x" .. suf]) or 1.0, 0.05, 10.0),
				scaleY = math.Clamp(tonumber(data["tattoo_scale_y" .. suf]) or 1.0, 0.05, 10.0),
				opacity = opacity,
				rotation = tonumber(data["tattoo_rotation" .. suf]) or 0,
			}
		end
	end

	if #overlays == 0 then
		LZY_ClearTattooDecoration(ent)
		ent._lzyTattooMaxAxisApplied = nil
		return
	end

	if not LZY_Character_FaceDiffuseMaterialReady(ent) then
		ent._lzyTattooTexRetryCount = (ent._lzyTattooTexRetryCount or 0) + 1
		if ent._lzyTattooTexRetryCount > 12 then return end
		local now = CurTime()
		ent._lzyTattooRetryNext = ent._lzyTattooRetryNext or 0
		if now >= ent._lzyTattooRetryNext and not ent._lzyTattooRetryPending then
			ent._lzyTattooRetryPending = true
			ent._lzyTattooRetryNext = now + 0.15
			timer.Simple(0.15, function()
				if not IsValid(ent) then return end
				ent._lzyTattooRetryPending = nil
				LZY_ApplyTattooFromCharacterData(ent, data)
			end)
		end
		return
	end
	ent._lzyTattooTexRetryCount = 0

	local maxAxis = LZY_Character_TattooMaxAxisForEntity(ent)
	if maxAxis <= 0 then
		if ent._lzy_tattooMode then LZY_ClearTattooDecoration(ent) end
		ent._lzyTattooMaxAxisApplied = nil
		return
	end

	local overlaySig = LZY_Character_ComputeTattooOverlaySig(overlays)
	local curTattooSkin = (ent.GetSkin and ent:GetSkin()) or 0
	if ent._lzy_tattooMode == "rt_baked"
		and ent._lzyTattooMaxAxisApplied == maxAxis
		and ent._lzyTattooOverlaySig == overlaySig
		and ent._lzyTattooSkin == curTattooSkin
		and ent._lzyTattooRtEpoch == _lzy_face_rt_epoch then
		return
	end

	LZY_ClearTattooDecoration(ent)

	local diffIdx = LZY_Character_FindLikelyFaceDiffuseSubMaterialIndex(ent)
	if diffIdx == nil then return end

	local mats = ent:GetMaterials()
	if not mats then return end

	local slotName = mats[diffIdx + 1]
	if not isstring(slotName) or slotName == "" then return end

	local subMat = LZY_GetOrCreateTattooFaceRTSubMaterial(slotName, overlays, maxAxis, ent._lzyStableTatKey)
	if not subMat then return end

	ent:SetSubMaterial(diffIdx, subMat)
	ent._lzy_tattooMode = "rt_baked"
	ent._lzy_tattooSlotIdx = diffIdx
	ent._lzyTattooMaxAxisApplied = maxAxis
	ent._lzyTattooOverlaySig = overlaySig
	ent._lzyTattooRtEpoch = _lzy_face_rt_epoch
	ent._lzyTattooSkin = curTattooSkin
end

local function removePlayerModelPartEntities(parts)
	if not parts then return end
	for _, e in pairs(parts) do
		if IsValid(e) then
			trackedParts[e] = nil
			SafeRemoveEntity(e)
		elseif istable(e) then
			for _, sub in ipairs(e) do
				if IsValid(sub) then
					trackedParts[sub] = nil
					SafeRemoveEntity(sub)
				end
			end
		end
	end
end

function LZY_Character_DestroyPlayerClientModels(ply, opts)
	if not IsValid(ply) then return end
	opts = opts or {}
	removePlayerModelPartEntities(ply.PlayerModelParts)
	ply.PlayerModelParts = nil
	ply._lzyPartsNeedReparent = nil
	ply._lzyLarvaEnterPending = nil
	if not opts.keepRenderOverride then
		LZY_ClearCharacterVisualOverrides(ply)
	end
	LZY_Character_InvalidateDrawState(ply)
	if not opts.keepRenderOverride then
		if ply.RenderOverride == ply._lzyCompositeRenderOverride then
			ply.RenderOverride = nil
		end
		ply._lzyCompositeRenderOverride = nil
	end
end

function LZY_Character_ClearCachedPlayerModel(ply)
	if not IsValid(ply) then return end
	playersModels[ply] = nil
	local sid = ply.SteamID64 and ply:SteamID64()
	if sid and sid ~= "" then
		_lzyPendingModelsBySteamID64[sid] = nil
	end
	LZY_Character_DestroyPlayerClientModels(ply)
end

function LZY_Character_PlayerShouldBuildClientModels(ply)
	if not IsValid(ply) then return false end
	if ply._lzyCrowdDummy then
		if ply.IsDormant and ply:IsDormant() then return false end
		local lp = LocalPlayer()
		if IsValid(lp) and not LZY_Character_ComputeInFaceRange(ply, ply:GetPos():DistToSqr(lp:GetPos())) then
			return false
		end
		local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
		if maxDrawn > 0 and ply._lzyShouldDraw ~= true then
			return false
		end
		return true
	end
	if not ply:IsPlayer() then return false end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("NCM_TF_Active", false) then return false end
	if ply == LocalPlayer() then return true end
	if ply:IsDormant() then return false end
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetEvoNWEntity and lp:GetEvoNWEntity("EVO_SpecTarget") == ply then
		return true
	end
	if IsValid(lp) and not LZY_Character_ComputeInFaceRange(ply, ply:GetPos():DistToSqr(lp:GetPos())) then
		return false
	end
	local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
	if maxDrawn > 0 and ply._lzyShouldDraw ~= true then
		return false
	end
	return true
end

function LZY_Character_CompositeNotReady(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply == LocalPlayer() then return false end
	if ply.PlayerModelParts and IsValid(ply.PlayerModelParts.body)
		and ply.RenderOverride == ply._lzyCompositeRenderOverride then
		return false
	end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_NoCSM", false) then return false end
	if not LZY_Character_PlayerShouldBuildClientModels(ply) then return false end
	local data = playersModels and playersModels[ply]
	if data and LZY_IsRawBodyModel(data.body_model) and not LZY_IsLarvaCharacter(ply, data) then
		local nwRaw = ply.GetEvoNWBool and (ply:GetEvoNWBool("EVO_HollowRaw", false) or ply:GetEvoNWBool("EVO_IsLarva", false))
		if not nwRaw then
			return true
		end
	end
	if LZY_IsLarvaCharacter(ply, data) then return false end
	if data and data.body_model and not LZY_Character_PlayerNeedsModelRepair(ply) then return false end
	if (not data or not data.body_model) and ply.IsBot and ply:IsBot() then return false end
	return true
end

function LZY_Character_CompositeHiddenWhileBuilding(ply)
	if not IsValid(ply) then return false end
	if not LZY_Character_CompositeNotReady(ply) then
		ply._lzyCompositeMissingSince = nil
		return false
	end
	if not ply._lzyCompositeMissingSince then
		ply._lzyCompositeMissingSince = CurTime()
	end
	return true
end

function LZY_Character_ShouldDrawOtherPlayer(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply == LocalPlayer() then return true end
	-- Illusion d'Aizen (passif slot 8) : hors du cache _lzyDrawState, sinon jusqu'a 1 refresh de retard.
	if EVO_IllusionCachePlayer and EVO_IllusionCachePlayer(ply) then return false end
	local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
	if maxDrawn > 0 and ply._lzyShouldDraw == false then
		return false
	end
	if LZY_Character_CompositeHiddenWhileBuilding(ply) then return false end
	if not ply._lzyDrawState then
		LZY_Character_RefreshDrawState(ply)
	end
	local state = ply._lzyDrawState
	if not state then return false end
	if state.shouldDraw == false or state.dormant or not state.instanceOk then return false end
	if state.inFaceRange == false then return false end
	if state.charMenuHideOthers or state.hidden then return false end
	return true
end

function LZY_Character_ShouldDrawPlayerHeldWeapon(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply == LocalPlayer() then return true end
	if EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(LocalPlayer(), ply) then
		return false
	end
	if not LZY_Character_ShouldDrawOtherPlayer(ply) then return false end
	if not ply._lzyDrawState then
		LZY_Character_RefreshDrawState(ply)
	end
	local state = ply._lzyDrawState
	if not state then return LZY_Character_PlayerShouldBuildClientModels(ply) end
	return state.inFaceRange == true
end

local ACCESSORY_DRAW_ORDER = { 1, 3, 4, 5, 6, 7 }

local function LZY_Character_BuildExpectedAccessories(characterData)
	local expected = {}
	local accTbl = characterData and characterData.equipped_accessories
	local accSkins = characterData and characterData.equipped_accessory_skins
	if not istable(accTbl) then return expected end
	for i = 1, #ACCESSORY_DRAW_ORDER do
		local slot = ACCESSORY_DRAW_ORDER[i]
		local path = accTbl[tostring(slot)]
		if isstring(path) and path ~= "" then
			expected[#expected + 1] = {
				path = path,
				skin = istable(accSkins) and tonumber(accSkins[tostring(slot)]) or nil,
				slot = slot,
			}
		end
	end
	return expected
end

local function LZY_Character_MergeInventoryEquippedAccessories(ply, characterData, onlySlot)
	if not istable(characterData) or not IsValid(ply) or not ply.GetInventoryEquippedItems then
		return characterData
	end
	local outfitSlot = INVENTORY_CONFIG and INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
	local eq = ply:GetInventoryEquippedItems()
	if not istable(eq) then return characterData end
	characterData.equipped_accessories = characterData.equipped_accessories or {}
	characterData.equipped_accessory_skins = characterData.equipped_accessory_skins or {}
	characterData._lzyAlwaysVisibleAcc = nil -- mutation sur place : mémo always_visible à recalculer
	for k, itemId in pairs(eq) do
		if k ~= "katana" then
			local n = tonumber(k)
			if n and n >= 1 and n <= (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) and n ~= outfitSlot and (not onlySlot or n == onlySlot) then
				local it = ITEMS and ITEMS[itemId]
				if it and it.category == "accessory" and not it.fourreau_cosmetic and not it.compagnon_id and isstring(it.model_path) and it.model_path ~= "" then
					characterData.equipped_accessories[tostring(n)] = it.model_path
					characterData.equipped_accessory_skins[tostring(n)] = tonumber(it.skin) or 0
				end
			end
		end
	end
	return characterData
end

local function LZY_Character_DetailDataForEnsure(ent, characterData)
	if not istable(characterData) then return characterData end
	if ent ~= LocalPlayer() or not LZY_AccessoryEditor_IsActive or not LZY_AccessoryEditor_IsActive() then
		return characterData
	end
	local copy = table.Copy(characterData)
	copy.equipped_accessories = table.Copy(characterData.equipped_accessories or {})
	copy.equipped_accessory_skins = table.Copy(characterData.equipped_accessory_skins or {})
	return LZY_Character_MergeInventoryEquippedAccessories(ent, copy)
end

function LZY_Character_GetPlayerBodyYaw(ent, yawOverride)
	if yawOverride ~= nil then return yawOverride end
	if not IsValid(ent) then return 0 end
	if ent:IsPlayer() then return ent:EyeAngles().y end
	return ent:GetAngles().y
end

function LZY_Character_GetBodyLocalMoveAxes(parent, yawOverride)
	if not IsValid(parent) then
		return Vector(1, 0, 0), Vector(0, 1, 0), Vector(0, 0, 1)
	end
	local yawAng = Angle(0, LZY_Character_GetPlayerBodyYaw(parent, yawOverride), 0)
	local right = yawAng:Right()
	right.z = 0
	if right:LengthSqr() < 0.0001 then right = Vector(1, 0, 0) else right:Normalize() end
	local forward = yawAng:Forward()
	forward.z = 0
	if forward:LengthSqr() < 0.0001 then forward = Vector(0, 1, 0) else forward:Normalize() end
	return right, forward, Vector(0, 0, 1)
end

function LZY_Character_BodyLocalOffsetToWorld(parent, vLocal, yawOverride)
	if not IsValid(parent) then return vector_origin end
	vLocal = vLocal or vector_origin
	local right, forward, up = LZY_Character_GetBodyLocalMoveAxes(parent, yawOverride)
	return right * vLocal.x + forward * vLocal.y + up * vLocal.z
end

local function LZY_Character_GetAccessoryBodyOffset(offTbl)
	if not offTbl or not INVENTORY_CONFIG then return vector_origin end
	return INVENTORY_CONFIG.ClampAccessoryOffsetPos(INVENTORY_CONFIG.AccessoryOffsetToBodyLocal(offTbl), "any",
		INVENTORY_CONFIG.AccessoryOffsetToScale(offTbl)) -- filet : chaque save est borné par kind
end

local function LZY_Character_GetAccessoryBodyAngle(offTbl)
	if not offTbl or not INVENTORY_CONFIG then return angle_zero end
	return INVENTORY_CONFIG.ClampAccessoryOffsetAng(INVENTORY_CONFIG.AccessoryOffsetToBodyLocalAngle(offTbl))
end

local function LZY_Character_GetAccessoryBodyScale(offTbl)
	if not offTbl or not INVENTORY_CONFIG then return 1 end
	local s = INVENTORY_CONFIG.AccessoryOffsetToScale(offTbl)
	if INVENTORY_CONFIG.ClampAccessoryOffsetScale then
		return INVENTORY_CONFIG.ClampAccessoryOffsetScale(s, "any")
	end
	return s
end

local function LZY_Character_BodyLocalAngleIsZero(ang)
	if not ang then return true end
	return ang.p * ang.p + ang.y * ang.y + ang.r * ang.r < 0.0001
end

local function LZY_Character_AccessoryScaleIsDefault(scale)
	return math.abs((tonumber(scale) or 1) - 1) < 0.001
end

local function LZY_Character_RotateVectorAroundAxis(v, axis, deg)
	if math.abs(deg) < 0.0001 then return v end
	local k = axis
	local lenSq = k:LengthSqr()
	if lenSq < 0.0001 then return v end
	k = k / math.sqrt(lenSq)
	local rad = math.rad(deg)
	local cosA, sinA = math.cos(rad), math.sin(rad)
	return v * cosA + k:Cross(v) * sinA + k * k:Dot(v) * (1 - cosA)
end

local function LZY_Character_ApplyBodyLocalAnglesToVector(v, ang, right, forward, up)
	if LZY_Character_BodyLocalAngleIsZero(ang) then return v end
	if ang.p ~= 0 then v = LZY_Character_RotateVectorAroundAxis(v, right, ang.p) end
	if ang.y ~= 0 then v = LZY_Character_RotateVectorAroundAxis(v, forward, ang.y) end
	if ang.r ~= 0 then v = LZY_Character_RotateVectorAroundAxis(v, up, ang.r) end
	return v
end

local function LZY_Character_ApplyBodyLocalAnglesToAngle(a, ang, right, forward, up)
	if LZY_Character_BodyLocalAngleIsZero(ang) then return a end
	local out = Angle(a)
	if ang.p ~= 0 then out:RotateAroundAxis(right, ang.p) end
	if ang.y ~= 0 then out:RotateAroundAxis(forward, ang.y) end
	if ang.r ~= 0 then out:RotateAroundAxis(up, ang.r) end
	return out
end

local function LZY_Character_AccessoryHasBodyOffset(offTbl, forcePose)
	if forcePose then return true end
	return offTbl and INVENTORY_CONFIG and INVENTORY_CONFIG.AccessoryOffsetNeedsManualAttach(offTbl)
end

function LZY_Character_GetAccessoryGizmoFrame(mdl, offTbl, forcePose)
	if not IsValid(mdl) then return nil, nil end
	local vR, vF, vU, pos = LZY_Character_GetAccessoryAxes(mdl)
	if LZY_Character_AccessoryHasBodyOffset(offTbl, forcePose) then
		local vOff = LZY_Character_GetAccessoryBodyOffset(offTbl)
		pos = pos + vR * vOff.x + vF * vOff.y + vU * vOff.z
	end
	return pos, mdl:GetAngles()
end

-- Le squelette du parent (le modele joueur) ne change pas entre deux pieces d'une
-- meme image, mais SetupBones appele depuis le Lua le recalcule en entier (~26 us).
-- Chaque insigne, accessoire et familier le relancait : 9 fois par perso et par
-- image, 14,4 ms sur 46 pour 61 persos (evo_persos_analyse du 28/09/2026). Une
-- fois par image suffit : la tete est dessinee avant ses pieces, sa pose est deja
-- celle de l'image quand la premiere piece arrive ici.
-- Interrupteurs de test des deux gains du 28/09/2026 (non archives : un redemarrage
-- du jeu les remet a 1). 0 = ancien comportement, pour isoler un bug d'affichage.
-- Le fichier est a la limite des 200 locales de LuaJIT : la convar du squelette vit
-- dans un bloc, celle de la passe unique dans une globale.
LZY_Character_CvPasseUnique = CreateClientConVar("wzl_passe_unique", "1", false, false,
	"Composite dessine une seule fois par image (1) ou dans les deux passes du moteur comme avant (0)")

local LZY_Character_SetupBonesParent
do
	local cvSquelettes = CreateClientConVar("wzl_squelette_unique", "1", false, false,
		"Squelette du joueur calcule une fois par image (1) ou a chaque piece comme avant (0)")
	LZY_Character_SetupBonesParent = function(parent)
		if not cvSquelettes:GetBool() then
			parent:SetupBones()
			return
		end
		local image = FrameNumber()
		if parent._lzyBonesImage == image then return end
		parent._lzyBonesImage = image
		parent:SetupBones()
	end
end

-- REPÈRE D'OS des réglages d'accessoire (10/04, user : « décalé pendant une émote / assis »).
-- Un réglage se fait debout ; il était appliqué dans le repère du REGARD (yaw seul) : il ne
-- suivait ni l'os qui porte la pièce (penché, assis) ni le corps (il tournait avec la caméra).
-- Repère = rotation actuelle de l'os porteur x inverse de sa rotation en idle debout, lue sur un
-- modèle témoin caché (1 par modèle parent). Debout = l'ancien repère : réglages inchangés.
do
	local REF_IDLE = { "evo_laybn5x3god89", "idle_all_01" } -- idle mains nues du jeu, repli GMod
	local ANCHORS = {
		"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2",
		"ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis",
		"ValveBiped.Bip01_L_Clavicle", "ValveBiped.Bip01_R_Clavicle", "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_R_UpperArm",
		"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_L_Hand", "ValveBiped.Bip01_R_Hand",
		"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_R_Calf",
		"ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_R_Foot",
	}
	local L_RIGHT, L_FWD, L_UP = Vector(0, -1, 0), Vector(1, 0, 0), Vector(0, 0, 1) -- axes du regard à yaw 0
	local tRef, tRetry, tAnchor = {}, {}, {}

	local function seqOf(e, tNames)
		for _, sName in ipairs(tNames) do
			local nSeq = e:LookupSequence(sName)
			if nSeq and nSeq >= 0 then return nSeq end
		end
	end

	local function sampleBones(e, nSeq)
		e:ResetSequence(nSeq)
		e:SetCycle(0)
		e:InvalidateBoneCache()
		e:SetupBones()
		local out = {}
		for _, sBone in ipairs(ANCHORS) do
			local i = e:LookupBone(sBone)
			local m = i and e:GetBoneMatrix(i)
			if m then out[sBone] = { pos = m:GetTranslation(), ang = m:GetAngles() } end
		end
		return out
	end

	-- UN modèle par pose : changer de séquence sur le même modèle mélange l'ancienne (fondu de
	-- transition du moteur), la 2e lecture serait polluée par la 1re.
	local function sampleModel(sModel, tNames)
		local e = ClientsideModel(sModel, RENDERGROUP_OTHER)
		if not IsValid(e) then return nil end
		e:SetNoDraw(true)
		e:SetPos(vector_origin)
		e:SetAngles(angle_zero)
		local nSeq = seqOf(e, tNames)
		local out = nSeq and sampleBones(e, nSeq) or nil
		e:Remove()
		return out
	end

	-- Modèle témoin : os en idle debout (repère + pivot) et en pose de liaison (choix de l'os
	-- porteur). Séquences pas encore chargées juste après création : nouvel essai 2 s plus tard,
	-- abandon après 5 essais (modèle sans idle -> ancien repère du regard pour de bon).
	local function getRef(sModel)
		local r = tRef[sModel]
		if r ~= nil then return r or nil end
		local t = tRetry[sModel] or { at = 0, n = 0 }
		tRetry[sModel] = t
		if t.at > RealTime() then return nil end
		t.at, t.n = RealTime() + 2, t.n + 1
		if t.n > 5 then tRef[sModel] = false return nil end
		local tIdle = sampleModel(sModel, REF_IDLE)
		if not tIdle then return nil end
		local tBind = sampleModel(sModel, { "reference", "ragdoll" }) or tIdle
		r = { idle = {}, bind = tBind }
		for sBone, t in pairs(tIdle) do
			r.idle[sBone] = {
				pos = t.pos, ang = t.ang,
				right = (WorldToLocal(L_RIGHT, angle_zero, vector_origin, t.ang)),
				fwd   = (WorldToLocal(L_FWD, angle_zero, vector_origin, t.ang)),
				up    = (WorldToLocal(L_UP, angle_zero, vector_origin, t.ang)),
			}
		end
		tRef[sModel] = r
		return r
	end

	-- Os porteur d'une pièce = os majeur le plus proche du centre de son modèle, les deux en pose
	-- de liaison (indépendant de la pose jouée). Pivot = ce centre rattaché à l'os porteur TEL QU'EN
	-- IDLE : debout il retombe pile sur l'ancien pivot (réglages tournés / redimensionnés intacts).
	local function anchorFor(r, sParent, mdl)
		local sKey = sParent .. "|" .. (mdl:GetModel() or "")
		local a = tAnchor[sKey]
		if a ~= nil then return a end
		local vCenter = mdl:OBBCenter()
		local sBest, nBest = nil, math.huge
		for sBone, t in pairs(r.bind) do
			if r.idle[sBone] and mdl:LookupBone(sBone) then
				local d = t.pos:DistToSqr(vCenter)
				if d < nBest then sBest, nBest = sBone, d end
			end
		end
		a = sBest and { bone = sBest, pivot = (WorldToLocal(vCenter, angle_zero, r.idle[sBest].pos, r.idle[sBest].ang)) } or false
		tAnchor[sKey] = a
		return a
	end

	--- Axes droite / avant / haut (monde) + pivot (monde, sans réglage) d'un accessoire.
	--- Repli sur l'ancien repère du regard (modèle témoin pas prêt, pièce sans os ValveBiped).
	function LZY_Character_GetAccessoryAxes(mdl, parent, yawOverride)
		parent = IsValid(parent) and parent or (IsValid(mdl) and mdl:GetParent())
		if IsValid(parent) then LZY_Character_SetupBonesParent(parent) end
		if IsValid(mdl) then mdl:SetupBones() end
		local sParent = IsValid(parent) and parent:GetModel()
		local r = IsValid(mdl) and isstring(sParent) and sParent ~= "" and getRef(sParent)
		local a = r and mdl:GetParent() == parent and mdl:IsEffectActive(EF_BONEMERGE) and anchorFor(r, sParent, mdl)
		local i = a and parent:LookupBone(a.bone)
		local m = i and parent:GetBoneMatrix(i)
		if m then
			local ang, t = m:GetAngles(), r.idle[a.bone]
			local vR, vF, vU = Vector(t.right), Vector(t.fwd), Vector(t.up)
			vR:Rotate(ang) vF:Rotate(ang) vU:Rotate(ang)
			return vR, vF, vU, m * a.pivot
		end
		local vR, vF, vU = LZY_Character_GetBodyLocalMoveAxes(parent, yawOverride)
		return vR, vF, vU, IsValid(mdl) and mdl:LocalToWorld(mdl:OBBCenter()) or vector_origin
	end
end

function LZY_Character_GetAccessoryEditorGizmoOrigin(mdl, vOff, yawOverride)
	if not IsValid(mdl) then return nil end
	local parent = mdl:GetParent()
	if not IsValid(parent) then parent = mdl._petParent end -- pet en pose manuelle : pas de parent
	local vR, vF, vU, pos = LZY_Character_GetAccessoryAxes(mdl, parent, yawOverride)
	if vOff and vOff:LengthSqr() > 0.0001 and IsValid(parent) then
		pos = pos + vR * vOff.x + vF * vOff.y + vU * vOff.z
	end
	return pos
end

function LZY_Character_GetAccessoryAxisDirs(mdl, offTbl, forcePose)
	if not IsValid(mdl) then return nil, nil, nil end
	if LZY_Character_AccessoryHasBodyOffset(offTbl, forcePose) then
		local vR, vF, vU = LZY_Character_GetAccessoryAxes(mdl)
		return vR, vF, vU
	end
	mdl:SetupBones()
	return mdl:GetRight(), mdl:GetForward(), mdl:GetUp()
end

local function LZY_Character_AccessoryGhostLookSig(source)
	if not IsValid(source) then return nil end
	local parts = { source:GetModel() or "", tostring(source:GetSkin() or 0) }
	local col = source:GetColor()
	if col then
		parts[#parts + 1] = string.format("%d,%d,%d,%d", col.r, col.g, col.b, col.a)
	else
		parts[#parts + 1] = "255,255,255,255"
	end
	parts[#parts + 1] = tostring(source:GetRenderMode() or 0)
	for i = 0, (source:GetNumBodyGroups() or 0) - 1 do
		parts[#parts + 1] = i .. ":" .. source:GetBodygroup(i)
	end
	return table.concat(parts, "|")
end

local function LZY_Character_SyncAccessoryGhostLook(source, ghost)
	if not IsValid(source) or not IsValid(ghost) then return end
	local sig = LZY_Character_AccessoryGhostLookSig(source)
	if sig and ghost._lzyGhostLookSig == sig then return end

	if ghost:GetModel() ~= source:GetModel() then
		ghost:SetModel(source:GetModel())
		ghost._lzyGhostBoneFromSource = nil
	end
	ghost:SetSkin(source:GetSkin())
	ghost:SetColor(source:GetColor())
	ghost:SetRenderMode(source:GetRenderMode())
	for i = 0, source:GetNumBodyGroups() - 1 do
		ghost:SetBodygroup(i, source:GetBodygroup(i))
	end
	ghost._lzyGhostLookSig = sig
end

local function LZY_Character_SafeSetBoneMatrix(ent, boneId, mat)
	if not IsValid(ent) or not mat then return false end
	local name = ent:GetBoneName(boneId)
	if not isstring(name) or name == "" or name == "__INVALIDBONE__" then return false end
	return pcall(ent.SetBoneMatrix, ent, boneId, mat)
end

local function LZY_Character_EnsureAccessoryGhostBoneMap(mdl, ghost)
	if ghost._lzyGhostBoneFromSource then return ghost._lzyGhostBoneFromSource end
	local map = {}
	local ghostCount = ghost:GetBoneCount() or 0
	for gi = 0, ghostCount - 1 do
		local name = ghost:GetBoneName(gi)
		if isstring(name) and name ~= "" and name ~= "__INVALIDBONE__" then
			local si = mdl:LookupBone(name)
			if si then map[gi] = si end
		end
	end
	ghost._lzyGhostBoneFromSource = map
	return map
end

local function LZY_Character_GetOrCreateAccessoryGhost(mdl)
	local ghost = mdl._lzyAccessoryGhost
	if IsValid(ghost) then return ghost end
	local modelPath = mdl:GetModel()
	if not isstring(modelPath) or modelPath == "" then return nil end
	ghost = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
	if not IsValid(ghost) then return nil end
	ghost:SetNoDraw(true)
	ghost:SetSolid(SOLID_NONE)
	ghost:SetMoveType(MOVETYPE_NONE)
	if ghost.DrawShadow then ghost:DrawShadow(false) end
	ghost._lzyGhostBoneFromSource = nil
	ghost._lzyGhostLookSig = nil
	mdl._lzyAccessoryGhost = ghost
	-- FUITE corrigée (10/08) : la pièce était retirée (mort, sortie de PVS, déco, corps refait)
	-- sans son fantôme, qui restait à vie -> limite d'entités client atteinte en longue session.
	mdl:CallOnRemove("lzy_acc_ghost", function(m) SafeRemoveEntity(m._lzyAccessoryGhost) end)
	LZY_Character_SyncAccessoryGhostLook(mdl, ghost)
	return ghost
end

function LZY_Character_DestroyAccessoryOffsetGhost(mdl)
	if not mdl then return end
	if IsValid(mdl._lzyAccessoryGhost) then
		mdl._lzyAccessoryGhost:Remove()
	end
	mdl._lzyAccessoryGhost = nil
end

-- Pose SANS dessin (10/25, clone du voile d'Illusion) : vrai pendant LZY_Character_PoseAccessoryModel,
-- les chemins de rendu ci-dessous calculent position, réglage et os, mais sautent le DrawModel.
local bPoseSeule = false

-- right / forward / up / pivot = repère de l'os porteur (LZY_Character_GetAccessoryAxes).
local function LZY_Character_DrawAccessoryGhostFromSource(mdl, worldOff, bodyAng, right, forward, up, pivot, scale)
	local ghost = LZY_Character_GetOrCreateAccessoryGhost(mdl)
	if not IsValid(ghost) then return false end
	LZY_Character_SyncAccessoryGhostLook(mdl, ghost)
	ghost:SetupBones()

	worldOff = worldOff or vector_origin
	local origin = pivot + worldOff
	bodyAng = bodyAng or angle_zero
	scale = tonumber(scale) or 1
	local hasScale = not LZY_Character_AccessoryScaleIsDefault(scale)

	local boneMap = LZY_Character_EnsureAccessoryGhostBoneMap(mdl, ghost)
	for gi, si in pairs(boneMap) do
		local srcMat = mdl:GetBoneMatrix(si)
		if not srcMat then continue end
		if not LZY_Character_SafeSetBoneMatrix(ghost, gi, srcMat) then continue end
		local gMat = ghost:GetBoneMatrix(gi)
		if not gMat then continue end

		local pos = gMat:GetTranslation()
		if worldOff:LengthSqr() > 0.0001 then
			pos = pos + worldOff
		end

		local rel = pos - origin
		rel = LZY_Character_ApplyBodyLocalAnglesToVector(rel, bodyAng, right, forward, up)
		if hasScale then
			rel = rel * scale
		end
		pos = origin + rel

		local boneAng = LZY_Character_ApplyBodyLocalAnglesToAngle(gMat:GetAngles(), bodyAng, right, forward, up)
		if hasScale then
			local mat = Matrix()
			mat:Translate(pos)
			mat:Rotate(boneAng)
			mat:Scale(Vector(scale, scale, scale))
			LZY_Character_SafeSetBoneMatrix(ghost, gi, mat)
		else
			gMat:SetTranslation(pos)
			gMat:SetAngles(boneAng)
			LZY_Character_SafeSetBoneMatrix(ghost, gi, gMat)
		end
	end

	ghost:SetPos(mdl:GetPos())
	ghost:SetAngles(mdl:GetAngles())
	if not bPoseSeule then ghost:DrawModel() end
	return true
end

local function LZY_Character_DrawAccessoryWithBodyOffset(parent, mdl, vOff, vAng, yawOverride, scale)
	if not IsValid(mdl) then return end

	local hasPos = vOff and vOff:LengthSqr() > 0.0001
	local hasAng = not LZY_Character_BodyLocalAngleIsZero(vAng)
	local hasScale = not LZY_Character_AccessoryScaleIsDefault(scale)

	if not hasPos and not hasAng and not hasScale then
		LZY_Character_DestroyAccessoryOffsetGhost(mdl)
		if IsValid(parent) then LZY_Character_SetupBonesParent(parent) end
		mdl:SetupBones()
		if not bPoseSeule then mdl:DrawModel() end
		return
	end

	if not IsValid(parent) then
		LZY_Character_DestroyAccessoryOffsetGhost(mdl)
		mdl:SetupBones()
		if not bPoseSeule then mdl:DrawModel() end
		return
	end

	local vR, vF, vU, pivot = LZY_Character_GetAccessoryAxes(mdl, parent, yawOverride)
	local worldOff = hasPos and (vR * vOff.x + vF * vOff.y + vU * vOff.z) or vector_origin
	if not LZY_Character_DrawAccessoryGhostFromSource(mdl, worldOff, vAng or angle_zero, vR, vF, vU, pivot, scale) then
		mdl:SetupBones()
		if not bPoseSeule then mdl:DrawModel() end
	end
end

local petModels = setmetatable({}, { __mode = "k" })
local petRigCache = {}
local PET_ATTACH_DEFAULT = {
	bone = "ValveBiped.Bip01_R_Clavicle", fallback = "ValveBiped.Bip01_Spine2",
	pos = Vector(6, -2, 4), ang = Angle(0, 0, 0), scale = 1, special_delay = { 6, 16 },
}
local function PetAttachCfg()
	return (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.PET_ATTACH) or PET_ATTACH_DEFAULT
end

local function PetHasPlayerSkeleton(mdl)
	local sPath = IsValid(mdl) and mdl:GetModel() or ""
	if sPath == "" then return nil end
	local c = petRigCache[sPath]
	if c ~= nil then return c end
	local n = mdl:GetBoneCount() or 0
	if n <= 0 then return nil end
	local bRig = false
	for i = 0, n - 1 do
		local sBone = mdl:GetBoneName(i)
		if isstring(sBone) and string.sub(sBone, 1, 10) == "ValveBiped" then bRig = true break end
	end
	petRigCache[sPath] = bRig
	return bRig
end

local function PetShouldBonemerge(mdl)
	local sMode = tostring((mdl._lzyPet and mdl._lzyPet.attach) or PetAttachCfg().mode or "auto")
	if sMode == "bonemerge" then return true end
	if sMode == "manual" then return false end
	return PetHasPlayerSkeleton(mdl)
end

local function PetBonemergeTo(mdl, parent)
	if not (IsValid(mdl) and IsValid(parent)) then return false end
	if mdl:GetParent() ~= parent then
		mdl:SetParent(parent)
		mdl:SetLocalPos(vector_origin)
		mdl:SetLocalAngles(angle_zero)
	end
	mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
	return true
end

local function PetApplyMode(mdl, bMerged)
	mdl._petMerged = bMerged and true or false
	if mdl._petMerged then
		PetBonemergeTo(mdl, mdl._petParent)
	else
		mdl:RemoveEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
		mdl:SetParent(NULL)
		LZY_Character_DestroyAccessoryOffsetGhost(mdl)
	end
end

-- Séquences RÉELLES du modèle (cache par chemin) : { list = {noms}, byName = {min -> nom} }.
local petSeqCache = {}
local function PetSeqInfo(mdl)
	local sPath = IsValid(mdl) and mdl:GetModel() or ""
	if sPath == "" then return nil end
	local c = petSeqCache[sPath]
	if c then return c end
	local list = mdl.GetSequenceList and mdl:GetSequenceList() or nil
	if not istable(list) or #list == 0 then return nil end
	c = { list = list, byName = {} }
	for _, sSeq in ipairs(list) do c.byName[string.lower(sSeq)] = sSeq end
	petSeqCache[sPath] = c
	return c
end

-- RÉSOLUTION TOLÉRANTE (09/07) : le nom déclaré dans SHOULDER_PETS n'est pas forcément
-- celui de l'export du modeleur. Nom absent -> repli sur les séquences réelles du modèle
-- (hors idle), annoncé UNE fois en console pour corriger la config ou l'export.
local petSeqWarned = {}
local function PetResolveSeq(mdl, sName)
	local seq = mdl:LookupSequence(sName or "")
	if seq and seq >= 0 then return sName end
	local info = PetSeqInfo(mdl)
	if not info then return nil end
	local sHit = info.byName[string.lower(tostring(sName or ""))]
	if sHit then return sHit end
	local anims = mdl._lzyPet and mdl._lzyPet.anims or nil
	local sIdle = string.lower(tostring((anims and anims.idle) or "idle"))
	local tOthers = {}
	for _, sSeq in ipairs(info.list) do
		if string.lower(sSeq) ~= sIdle and string.lower(sSeq) ~= "ref" then tOthers[#tOthers + 1] = sSeq end
	end
	local sKey = mdl:GetModel() .. "|" .. tostring(sName)
	if not petSeqWarned[sKey] then
		petSeqWarned[sKey] = true
		print(string.format("[Pets] %s : séquence déclarée « %s » absente du modèle. Séquences réelles : %s",
			tostring(mdl._lzyPet and mdl._lzyPet.id or mdl:GetModel()), tostring(sName), table.concat(info.list, ", ")))
	end
	if #tOthers > 0 then return tOthers[math.random(#tOthers)] end
	return nil
end

local function PetPlaySeq(mdl, sName)
	local sReal = PetResolveSeq(mdl, sName)
	local seq = sReal and mdl:LookupSequence(sReal) or -1
	if not seq or seq < 0 then return false end
	mdl:ResetSequence(seq)
	mdl:SetCycle(0)
	mdl:SetPlaybackRate(1)
	mdl._petSeqEnd = CurTime() + math.max(0.1, tonumber(mdl:SequenceDuration(seq)) or 1)
	return true
end

local function PetIdle(mdl)
	local anims = mdl._lzyPet and mdl._lzyPet.anims or nil
	local sIdle = (anims and anims.idle) or "idle"
	local seq = mdl:LookupSequence(sIdle)
	if not seq or seq < 0 then
		-- Idle absent : première séquence du modèle (pose de référence sinon rien ne tourne).
		local info = PetSeqInfo(mdl)
		sIdle = info and info.list[1] or sIdle
	end
	PetPlaySeq(mdl, sIdle)
	mdl._petSeqEnd, mdl._petChain, mdl._petChainIdx = nil, nil, nil
	local d = PetAttachCfg().special_delay or { 6, 16 }
	mdl._petNext = CurTime() + math.Rand(tonumber(d[1]) or 6, tonumber(d[2]) or 16)
end

function LZY_Character_PetPlace(mdl, vOff, vAng, scale, yawOverride)
	if not IsValid(mdl) then return false end
	local parent = mdl._petParent
	if not IsValid(parent) then return false end
	if mdl._petMerged then return PetBonemergeTo(mdl, parent) end
	local cfg = PetAttachCfg()
	if mdl._petBoneParent ~= parent or mdl._petBone == nil then
		mdl._petBoneParent = parent
		mdl._petBone = parent:LookupBone(cfg.bone or "") or parent:LookupBone(cfg.fallback or "") or false
	end
	LZY_Character_SetupBonesParent(parent)
	local matrix = mdl._petBone and parent:GetBoneMatrix(mdl._petBone) or nil
	local right, forward, up = LZY_Character_GetBodyLocalMoveAxes(parent, yawOverride)
	local pos
	if matrix then
		pos = matrix:GetTranslation()
	else
		pos = parent:GetPos() + up * 60
	end
	local ang = forward:Angle()
	local vDef = cfg.pos or vector_origin
	pos = pos + forward * vDef.x + right * vDef.y + up * vDef.z
	local aDef = cfg.ang
	if aDef and (aDef.p ~= 0 or aDef.y ~= 0 or aDef.r ~= 0) then
		ang = LZY_Character_ApplyBodyLocalAnglesToAngle(ang, aDef, right, forward, up)
	end
	if vOff then pos = pos + right * vOff.x + forward * vOff.y + up * vOff.z end
	if vAng and not LZY_Character_BodyLocalAngleIsZero(vAng) then
		ang = LZY_Character_ApplyBodyLocalAnglesToAngle(ang, vAng, right, forward, up)
	end
	local s = (tonumber(cfg.scale) or 1) * (tonumber(scale) or 1)
	if mdl._petScale ~= s then
		mdl._petScale = s
		mdl:SetModelScale(s, 0)
	end
	mdl:SetPos(pos)
	mdl:SetAngles(ang)
	return true
end

function LZY_Character_SetupPetPart(parent, mdl, petCfg, offTbl)
	if not IsValid(mdl) then return end
	mdl._lzyPet = petCfg or mdl._lzyPet or {}
	mdl._petParent = parent
	mdl._petBone = nil
	mdl._petOffTbl = istable(offTbl) and offTbl or nil
	local bMerge = PetShouldBonemerge(mdl)
	mdl._petModeSet = (bMerge ~= nil)
	PetApplyMode(mdl, bMerge == true)
	petModels[mdl] = true
	PetIdle(mdl)
	LZY_Character_PetPlace(mdl)
end

local function LZY_Character_DrawPetModel(ent, mdl, vOff, vAng, scale, yawOverride)
	if IsValid(ent) then mdl._petParent = ent end
	if mdl._petMerged then
		PetBonemergeTo(mdl, mdl._petParent)
		-- Offset joueur : MEME chemin que les autres accessoires bonemerges (accessoire de
		-- division, epaulette). Le ghost recopie les matrices d'os a chaque frame, donc
		-- l'animation du pet continue de tourner. Sans offset -> dessin direct comme avant.
		LZY_Character_DrawAccessoryWithBodyOffset(mdl._petParent, mdl, vOff, vAng, yawOverride, scale)
		return
	end
	LZY_Character_PetPlace(mdl, vOff, vAng, scale, yawOverride)
	mdl:SetupBones()
	if not bPoseSeule then mdl:DrawModel() end
end

-- DIAG SA (09/07) : evo_pet_dump <dossier|item_id> -> os (racines, ValveBiped ou non),
-- séquences + durées, résolution de la config. Sert à trancher un pet qui n'anime pas
-- (nom de séquence) ou qui part dans tous les sens (os racine propre animé sous bonemerge).
concommand.Add("evo_pet_dump", function(ply, _, args)
	if not (IsValid(ply) and ply:IsSuperAdmin()) then return end
	local sArg = string.lower(tostring(args[1] or ""))
	if sArg == "" then print("[Pets] usage : evo_pet_dump <dossier|item_id>") return end
	local sPath, petCfg
	for sP, cfg in pairs(LZY_CHARACTER_CONFIG.SHOULDER_PETS or {}) do
		if cfg.id == sArg or ("pet_" .. cfg.id) == sArg then sPath, petCfg = sP, cfg break end
	end
	if not sPath and ITEMS and ITEMS[sArg] and ITEMS[sArg].model_path then
		sPath = string.lower(ITEMS[sArg].model_path)
		petCfg = LZY_CHARACTER_CONFIG.GetShoulderPet(sPath)
	end
	if not sPath then print("[Pets] pet inconnu : " .. sArg) return end
	if not util.IsValidModel(sPath) then print("[Pets] modèle absent ou invalide : " .. sPath) return end
	local mdl = ClientsideModel(sPath, RENDERGROUP_OPAQUE)
	if not IsValid(mdl) then print("[Pets] ClientsideModel impossible : " .. sPath) return end
	mdl:SetNoDraw(true)
	print("[Pets] ===== " .. sPath)
	local n = mdl:GetBoneCount() or 0
	local nVB, tRoots = 0, {}
	for i = 0, n - 1 do
		local sBone = tostring(mdl:GetBoneName(i) or "?")
		local nPar = mdl:GetBoneParent(i) or -1
		if string.sub(sBone, 1, 10) == "ValveBiped" then nVB = nVB + 1 end
		if nPar < 0 then tRoots[#tRoots + 1] = sBone end
		print(string.format("  os [%2d] %-40s parent = %s", i, sBone, nPar >= 0 and tostring(mdl:GetBoneName(nPar)) or "RACINE"))
	end
	print(string.format("[Pets] %d os, %d ValveBiped, racine(s) : %s", n, nVB, table.concat(tRoots, ", ")))
	if nVB > 0 then
		for _, sRoot in ipairs(tRoots) do
			if string.sub(sRoot, 1, 10) ~= "ValveBiped" then
				print("[Pets] ⚠ racine PROPRE « " .. sRoot .. "» avec des os ValveBiped : sous bonemerge cette racine est posée à l'ORIGINE du joueur et son animation la promène -> pet qui part dans tous les sens. Ré-export sur la racine ValveBiped, ou attach = \"manual\" pour ce pet.")
			end
		end
	else
		print("[Pets] aucun os ValveBiped : bonemerge impossible, ce pet doit être en pose manuelle.")
	end
	local list = mdl:GetSequenceList() or {}
	for i, sSeq in ipairs(list) do
		local seq = mdl:LookupSequence(sSeq)
		print(string.format("  séquence [%2d] %-28s durée %.2fs", i - 1, sSeq, tonumber(mdl:SequenceDuration(seq)) or 0))
	end
	local anims = petCfg and petCfg.anims or nil
	if anims then
		local function check(sName)
			local seq = mdl:LookupSequence(sName)
			print(string.format("  config « %s » -> %s", sName, (seq and seq >= 0) and "OK" or "ABSENTE (repli sur les séquences réelles)"))
		end
		check(anims.idle or "idle")
		for _, v in ipairs(anims.specials or {}) do
			if istable(v) then for _, w in ipairs(v) do check(w) end else check(v) end
		end
	end
	mdl:Remove()
end)

hook.Add("Think", "LZY_Character::PetAnim", function()
	local now = CurTime()
	for mdl in pairs(petModels) do
		if not IsValid(mdl) then
			petModels[mdl] = nil
			continue
		end
		mdl:FrameAdvance()
		local anims = mdl._lzyPet and mdl._lzyPet.anims or nil
		if mdl._petSeqEnd then
			if now >= mdl._petSeqEnd then
				local chain = mdl._petChain
				local nIdx = (mdl._petChainIdx or 0) + 1
				if chain and chain[nIdx] then
					mdl._petChainIdx = nIdx
					if not PetPlaySeq(mdl, chain[nIdx]) then PetIdle(mdl) end
				else
					PetIdle(mdl)
				end
			end
		elseif anims and istable(anims.specials) and #anims.specials > 0 and now >= (mdl._petNext or 0) then
			local pick = anims.specials[math.random(#anims.specials)]
			if istable(pick) then
				mdl._petChain, mdl._petChainIdx = pick, 1
				if not PetPlaySeq(mdl, pick[1]) then PetIdle(mdl) end
			elseif not PetPlaySeq(mdl, pick) then
				PetIdle(mdl)
			end
		elseif mdl:GetCycle() >= 0.999 then
			mdl:SetCycle(0)
		end
		if not mdl._petModeSet then
			local b = PetShouldBonemerge(mdl)
			if b ~= nil then
				mdl._petModeSet = true
				if b ~= mdl._petMerged then PetApplyMode(mdl, b) end
			end
		end
		if mdl._petMerged then
			PetBonemergeTo(mdl, mdl._petParent)
		elseif not mdl:GetNoDraw() then
			local off = mdl._petOffTbl
			LZY_Character_PetPlace(mdl,
				off and LZY_Character_GetAccessoryBodyOffset(off) or nil,
				off and LZY_Character_GetAccessoryBodyAngle(off) or nil,
				off and LZY_Character_GetAccessoryBodyScale(off) or nil)
		end
	end
end)

function LZY_Character_DrawAccessoryModel(ent, mdl, charData)
	if not IsValid(mdl) then return end

	if EVO_Portal and EVO_Portal.PlayersSeparated then
		local lp = LocalPlayer()
		if IsValid(ent) and ent ~= lp and EVO_Portal.PlayersSeparated(lp, ent) then return end
	end

	local vOff = vector_origin
	local vAng = angle_zero
	local scale = 1
	local yawOverride = nil

	if IsValid(ent) and ent == LocalPlayer()
		and LZY_AccessoryEditor_IsActive and LZY_AccessoryEditor_IsActive()
		and LZY_AccessoryEditor_GetGearSlot then
		local editSlot = LZY_AccessoryEditor_GetGearSlot()
		if editSlot and tostring(mdl._lzyAccessorySlot or editSlot) == tostring(editSlot)
			and LZY_AccessoryEditor_GetPreviewOffset then
			local offTbl = LZY_AccessoryEditor_GetPreviewOffset(editSlot)
			vOff = LZY_Character_GetAccessoryBodyOffset(offTbl)
			vAng = LZY_Character_GetAccessoryBodyAngle(offTbl)
			scale = LZY_Character_GetAccessoryBodyScale(offTbl)
			yawOverride = LZY_AccessoryEditor_GetBodyYaw and LZY_AccessoryEditor_GetBodyYaw()
		end
	else
		local offTbl
		if charData and mdl._lzyAccessorySlot and charData.equipped_accessory_offsets then
			offTbl = charData.equipped_accessory_offsets[mdl._lzyAccessorySlot]
		end
		vOff = LZY_Character_GetAccessoryBodyOffset(offTbl)
		vAng = LZY_Character_GetAccessoryBodyAngle(offTbl)
		scale = LZY_Character_GetAccessoryBodyScale(offTbl)
	end

	local parent = IsValid(ent) and ent or mdl:GetParent()
	if mdl._lzyPet then
		LZY_Character_DrawPetModel(parent, mdl, vOff, vAng, scale, yawOverride)
		return
	end
	LZY_Character_DrawAccessoryWithBodyOffset(parent, mdl, vOff, vAng, yawOverride, scale)
end

-- Clone du voile d'Illusion (cl_combats_functions, 10/25) : pose l'accessoire ou le pet EXACTEMENT
-- comme au rendu (réglage de position, angle, taille, animation du pet) sans le dessiner, et
-- renvoie l'entité qui porte sa forme finale : le fantôme décalé s'il existe, sinon le modèle.
function LZY_Character_PoseAccessoryModel(ply, mdl)
	if not IsValid(mdl) then return nil end
	bPoseSeule = true
	local ok = pcall(LZY_Character_DrawAccessoryModel, ply, mdl, playersModels[ply])
	bPoseSeule = false
	if not ok then return nil end
	local ghost = mdl._lzyAccessoryGhost
	return IsValid(ghost) and ghost or mdl
end

function LZY_Character_ResetAccessoryEditorPreviewDraw()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local slot = LZY_AccessoryEditor_GetGearSlot and LZY_AccessoryEditor_GetGearSlot()
	if not slot then return end
	local mdl = LZY_Character_FindAccessoryModelOnPlayer(lp, slot)
	if IsValid(mdl) then
		LZY_Character_DestroyAccessoryOffsetGhost(mdl)
	end
end

function LZY_Character_FindAccessoryModelOnPlayer(ply, gearSlot)
	if not IsValid(ply) or not ply.PlayerModelParts then return nil end
	local parts = ply.PlayerModelParts
	if not istable(parts.accessories) then return nil end
	local want = tostring(gearSlot)
	for i = 1, #parts.accessories do
		local m = parts.accessories[i]
		if IsValid(m) and m._lzyAccessorySlot == want then return m end
	end
	local data = playersModels and playersModels[ply]
	if data then
		local expected = LZY_Character_BuildExpectedAccessories(data)
		for i = 1, #expected do
			if tostring(expected[i].slot) == want and IsValid(parts.accessories[i]) then
				parts.accessories[i]._lzyAccessorySlot = want
				return parts.accessories[i]
			end
		end
	end
	if ply.GetInventoryEquippedItems then
		local eq = ply:GetInventoryEquippedItems()
		local itemId = istable(eq) and eq[want]
		local it = itemId and ITEMS and ITEMS[itemId]
		local wantPath = it and it.model_path
		if isstring(wantPath) and wantPath ~= "" then
			for i = 1, #parts.accessories do
				local m = parts.accessories[i]
				if IsValid(m) and m:GetModel() == wantPath then
					m._lzyAccessorySlot = want
					return m
				end
			end
		end
	end
	return nil
end

local function LZY_Character_BumpAccessoryPartsGen(ent)
	if not IsValid(ent) then return end
	ent._lzyAccessoryPartsGen = (ent._lzyAccessoryPartsGen or 0) + 1
end

local function LZY_Character_DestroyHairPart(parts)
	if not parts then return end
	if IsValid(parts.hair) then
		trackedParts[parts.hair] = nil
		SafeRemoveEntity(parts.hair)
	end
	parts.hair = nil
end

local LZY_RANK_COSMETIC_SLOTS = {
	grade = true,
	brassard = true,
	espada = true,
	haori = true,
	masque_base = true,
	division_body = true,
	cape_roi = true,
}

local function LZY_Character_IsRankCosmeticSlot(slot)
	return LZY_RANK_COSMETIC_SLOTS[tostring(slot or "")] == true
end

-- Pièce d'accessoire qui SURVIT au masquage des détails (menu Optimisations « masquer
-- les accessoires », distance d'affichage, budget LOD) : insigne de grade OU accessoire
-- marqué `always_visible` dans ITEMS (user 09/16, Cape Yamamoto modifiée). Le verdict
-- always_visible est mémorisé sur la pièce (nil = pas encore calculé) : une pièce est
-- recréée quand son modèle change (SyncAccessoriesToExpected), donc jamais périmé, et
-- ça évite un string.lower par pièce et par image dans le rendu.
local function LZY_Character_IsPersistentAccessoryPart(m)
	if not IsValid(m) then return false end
	if LZY_Character_IsRankCosmeticSlot(m._lzyAccessorySlot) then return true end
	if m._lzyAlwaysVisible == nil then
		m._lzyAlwaysVisible = (INVENTORY_CONFIG and INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel
			and INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel(m:GetModel())) == true
	end
	return m._lzyAlwaysVisible == true
end

local function LZY_Character_ForceRankCosmeticsInZone(ent)
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return false end
	if ZC and ZC.ActiveZone and not ZC.EventFinished then
		if ZC.PlayersInside and ZC.PlayersInside[ent] then return true end
		if ZoneCapture and ZoneCapture.IsInsideArena then
			local zone = ZC.ActiveZone
			local arena = ZoneCapture.GetArena and ZoneCapture.GetArena() or nil
			if ZoneCapture.IsInsideArena(ent:GetPos(), {
				center = zone.pos,
				radius = zone.radius,
				height = (arena and arena.height) or zone.height,
				name   = zone.name,
			}) then return true end
		end
	end
	if EVO_BATAILLE_FAC and EVO_BATAILLE_FAC.IsPlayerInside and EVO_BATAILLE_FAC.IsPlayerInside(ent) then
		return true
	end
	return false
end

local function LZY_Character_AppendRankCosmetics(ent, characterData, expected)
	if not istable(expected) then return expected end
	-- Les mannequins de lzy_crowd_spawn portent aussi insignes et tenues de grade
	-- (faction, division et grade tires dans leur characterData) : sans eux, une
	-- foule de test en solo coute moins cher qu'une vraie foule de joueurs.
	if not (IsValid(ent) and ((ent.IsPlayer and ent:IsPlayer()) or ent._lzyCrowdDummy == true)) then return expected end
	if LZY_IsLarvaCharacter(ent, characterData) then return expected end
	if ent.GetEvoNWBool and ent:GetEvoNWBool("NCM_TF_Active", false) then return expected end

	local faction, division, rank = LZY_Character_GetRankIdentity(ent, characterData)

	local bForceInZone = LZY_Character_ForceRankCosmeticsInZone(ent)
	local bHideEpaulette = (not bForceInZone) and ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideEpaulette", false)
	local bHideRankOutfit = (not bForceInZone) and ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideRankOutfit", false)
		and not (LZY_CHARACTER_CONFIG.IsRankOutfitLocked and LZY_CHARACTER_CONFIG.IsRankOutfitLocked(ent))
	local bHideDivisionBody = ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideDivisionBody", false)

	if not bHideEpaulette and LZY_CHARACTER_CONFIG.GetRankEpauletteModel then
		local epaulette = LZY_CHARACTER_CONFIG.GetRankEpauletteModel(faction, rank)
		if isstring(epaulette) and epaulette ~= "" then
			expected[#expected + 1] = { path = epaulette, skin = nil, slot = "grade" }
		end
	end

	if LZY_CHARACTER_CONFIG.GetRankBrassard then
		local brassard, bskin = LZY_CHARACTER_CONFIG.GetRankBrassard(faction, rank, division)
		if isstring(brassard) and brassard ~= "" then
			expected[#expected + 1] = { path = brassard, skin = bskin, slot = "brassard" }
		end
	end

	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankEspadaBody then
		local espada, eskin = LZY_CHARACTER_CONFIG.GetRankEspadaBody(faction, rank, division)
		if isstring(espada) and espada ~= "" then
			expected[#expected + 1] = { path = espada, skin = eskin, slot = "espada" }
		end
	end

	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankHaori then
		local haori = LZY_CHARACTER_CONFIG.GetRankHaori(faction, rank, division)
		if isstring(haori) and haori ~= "" then
			expected[#expected + 1] = { path = haori, skin = nil, slot = "haori" }
		end
	end

	-- Cape du Roi du Hueco Mundo (Hollow grade 16) : slot "cape_roi", coexiste avec le corps
	-- d'Espada et le masque Espada que ce même grade porte déjà.
	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankHollowKingCape then
		local cape = LZY_CHARACTER_CONFIG.GetRankHollowKingCape(faction, rank)
		if isstring(cape) and cape ~= "" then
			expected[#expected + 1] = { path = cape, skin = nil, slot = "cape_roi" }
		end
	end

	if LZY_CHARACTER_CONFIG.GetRankDivisionBody
		and not (LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody
			and LZY_CHARACTER_CONFIG.CharacterHasHideDivisionBody(characterData)) then
		local divBody = LZY_CHARACTER_CONFIG.GetRankDivisionBody(faction, rank, division)
		if isstring(divBody) and divBody ~= "" then
			expected[#expected + 1] = { path = divBody, skin = nil, slot = "division_body" }
		end
	end

	if LZY_CHARACTER_CONFIG.GetArrancarMaskModel then
		local maskSlot = (INVENTORY_CONFIG and INVENTORY_CONFIG.MASK_EQUIP_SLOT) or 7
		local aMasqueAchete = false
		for i = 1, #expected do
			if expected[i].slot == maskSlot then aMasqueAchete = true break end
		end
		if not aMasqueAchete and istable(characterData) and istable(characterData.equipped_accessories) then
			local path = characterData.equipped_accessories[tostring(maskSlot)]
			if isstring(path) and path ~= "" then aMasqueAchete = true end
		end
		if not aMasqueAchete then
			local masque = LZY_CHARACTER_CONFIG.GetArrancarMaskModel(faction, rank)
			if isstring(masque) and masque ~= "" then
				expected[#expected + 1] = { path = masque, skin = nil, slot = "masque_base" }
			end
		end
	end

	return expected
end

LZY_Character_HasPriorityRankCosmetics = function(ent, characterData)
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return false end
	if LZY_IsLarvaCharacter(ent, characterData) then return false end
	if ent.GetEvoNWBool and ent:GetEvoNWBool("NCM_TF_Active", false) then return false end
	local faction, division, rank = LZY_Character_GetRankIdentity(ent, characterData)
	if faction == "" then return false end
	local bForceInZone = LZY_Character_ForceRankCosmeticsInZone(ent)
	local bHideEpaulette = (not bForceInZone) and ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideEpaulette", false)
	local bHideRankOutfit = (not bForceInZone) and ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideRankOutfit", false)
		and not (LZY_CHARACTER_CONFIG.IsRankOutfitLocked and LZY_CHARACTER_CONFIG.IsRankOutfitLocked(ent))
	local bHideDivisionBody = ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_HideDivisionBody", false)
	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankHaori then
		local h = LZY_CHARACTER_CONFIG.GetRankHaori(faction, rank, division)
		if isstring(h) and h ~= "" then return true end
	end
	if LZY_CHARACTER_CONFIG.GetRankBrassard then
		local b = LZY_CHARACTER_CONFIG.GetRankBrassard(faction, rank, division)
		if isstring(b) and b ~= "" then return true end
	end
	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankEspadaBody then
		local e = LZY_CHARACTER_CONFIG.GetRankEspadaBody(faction, rank, division)
		if isstring(e) and e ~= "" then return true end
	end
	if not bHideRankOutfit and LZY_CHARACTER_CONFIG.GetRankHollowKingCape then
		local ck = LZY_CHARACTER_CONFIG.GetRankHollowKingCape(faction, rank)
		if isstring(ck) and ck ~= "" then return true end
	end
	if not bHideDivisionBody and LZY_CHARACTER_CONFIG.GetRankDivisionBody then
		local db = LZY_CHARACTER_CONFIG.GetRankDivisionBody(faction, rank, division)
		if isstring(db) and db ~= "" then return true end
	end
	if not bHideEpaulette and LZY_CHARACTER_CONFIG.GetRankEpauletteModel then
		local ep = LZY_CHARACTER_CONFIG.GetRankEpauletteModel(faction, rank)
		if isstring(ep) and ep ~= "" then return true end
	end
	return false
end

local function LZY_Character_SyncAccessoriesToExpected(ent, p, expected)
	if not istable(p.accessories) then p.accessories = {} end
	if #expected == 0 then
		local hadAccessories = #p.accessories > 0
		for i = 1, #p.accessories do
			if IsValid(p.accessories[i]) then
				LZY_Character_DestroyAccessoryOffsetGhost(p.accessories[i])
				trackedParts[p.accessories[i]] = nil
				SafeRemoveEntity(p.accessories[i])
			end
		end
		p.accessories = {}
		if hadAccessories then
			LZY_Character_BumpAccessoryPartsGen(ent)
		end
		return
	end

	local allValid = (#p.accessories == #expected)
	if allValid then
		for i = 1, #expected do
			local m = p.accessories[i]
			if not IsValid(m)
				or tostring(m._lzyAccessorySlot or "") ~= tostring(expected[i].slot)
				or (tonumber(m._lzyAccessorySkin) or 0) ~= (tonumber(expected[i].skin) or 0)
				or string.lower(m:GetModel() or "") ~= string.lower(expected[i].path or "") then
				allValid = false
				break
			end
		end
	end
	if allValid then
		for i = 1, #expected do
			if IsValid(p.accessories[i]) then
				p.accessories[i]._lzyAccessorySlot = tostring(expected[i].slot)
			end
		end
		return
	end

	for i = 1, #p.accessories do
		if IsValid(p.accessories[i]) then
			LZY_Character_DestroyAccessoryOffsetGhost(p.accessories[i])
			trackedParts[p.accessories[i]] = nil
			SafeRemoveEntity(p.accessories[i])
		end
	end
	p.accessories = {}
	for i = 1, #expected do
		local mdl = createModelPart(ent, expected[i].path, nil, expected[i].skin)
		if IsValid(mdl) then
			mdl._lzyAccessorySlot = tostring(expected[i].slot)
			mdl._lzyAccessorySkin = tonumber(expected[i].skin) or 0
			local petCfg = LZY_CHARACTER_CONFIG.GetShoulderPet and LZY_CHARACTER_CONFIG.GetShoulderPet(expected[i].path)
			if petCfg then LZY_Character_SetupPetPart(ent, mdl, petCfg) end
			p.accessories[#p.accessories + 1] = mdl
		end
	end
	LZY_Character_BumpAccessoryPartsGen(ent)
end

-- Accessoires `always_visible` équipés (ITEMS, ex. Cape Yamamoto modifiée), dans l'ordre
-- de dessin. MÉMORISÉ sur characterData (`_lzyAlwaysVisibleAcc`) : cette fonction est
-- appelée à CHAQUE image pour chaque joueur aux détails masqués, et la table
-- equipped_accessories ne change pas entre deux paquets d'apparence (playersModels[ply]
-- est remplacé en bloc ; la seule mutation sur place, MergeInventoryEquippedAccessories,
-- vide le mémo). Jamais pour un bot léger / figurant (_lzyLightBot) : leurs accessoires
-- sont tirés au hasard, un cosmétique staff n'a rien à faire dessus.
local function LZY_Character_GetAlwaysVisibleAccessories(characterData)
	local av = characterData._lzyAlwaysVisibleAcc
	if av ~= nil then return av end
	av = {}
	if not characterData._lzyLightBot and INVENTORY_CONFIG and INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel then
		local equipped = LZY_Character_BuildExpectedAccessories(characterData)
		for i = 1, #equipped do
			if INVENTORY_CONFIG.IsAlwaysVisibleAccessoryModel(equipped[i].path) then
				av[#av + 1] = equipped[i]
			end
		end
	end
	characterData._lzyAlwaysVisibleAcc = av
	return av
end

-- Détails MASQUÉS (accessoires cachés / hors distance / hors budget) : on ne garde que
-- les accessoires `always_visible` et les insignes de grade (même ordre de dessin que
-- EnsureDetailParts : accessoires équipés d'abord, insignes ensuite -> le chemin rapide
-- « allValid » de SyncAccessoriesToExpected tient, rien n'est recréé d'une image à l'autre).
local function LZY_Character_EnsureRankCosmeticParts(ent, characterData)
	local p = ent.PlayerModelParts
	if not p or not characterData then return end
	characterData = LZY_Character_DetailDataForEnsure(ent, characterData)
	local expected = {}
	local av = LZY_Character_GetAlwaysVisibleAccessories(characterData)
	for i = 1, #av do expected[#expected + 1] = av[i] end
	LZY_Character_AppendRankCosmetics(ent, characterData, expected)
	LZY_Character_SyncAccessoriesToExpected(ent, p, expected)
end

local function LZY_Character_DestroyOptionalDetailParts(ent, parts)
	if not parts then return end
	if IsValid(parts.beard) then
		trackedParts[parts.beard] = nil
		SafeRemoveEntity(parts.beard)
		parts.beard = nil
	end
	if IsValid(parts.mustache) then
		trackedParts[parts.mustache] = nil
		SafeRemoveEntity(parts.mustache)
		parts.mustache = nil
	end
	if not istable(parts.accessories) then return end
	local kept, removed = {}, false
	for i = 1, #parts.accessories do
		local m = parts.accessories[i]
		if LZY_Character_IsPersistentAccessoryPart(m) then
			kept[#kept + 1] = m
		elseif IsValid(m) then
			LZY_Character_DestroyAccessoryOffsetGhost(m)
			trackedParts[m] = nil
			SafeRemoveEntity(m)
			removed = true
		end
	end
	parts.accessories = kept
	if removed then
		LZY_Character_BumpAccessoryPartsGen(ent)
	end
end

local function LZY_Character_DestroyDetailParts(ent, parts)
	if not parts then return end
	if IsValid(parts.beard) then
		trackedParts[parts.beard] = nil
		SafeRemoveEntity(parts.beard)
		parts.beard = nil
	end
	if IsValid(parts.mustache) then
		trackedParts[parts.mustache] = nil
		SafeRemoveEntity(parts.mustache)
		parts.mustache = nil
	end
	if istable(parts.accessories) then
		local hadAccessories = #parts.accessories > 0
		for i = 1, #parts.accessories do
			local m = parts.accessories[i]
			if IsValid(m) then
				LZY_Character_DestroyAccessoryOffsetGhost(m)
				trackedParts[m] = nil
				SafeRemoveEntity(m)
			end
		end
		parts.accessories = {}
		if hadAccessories then
			LZY_Character_BumpAccessoryPartsGen(ent)
		end
	end
end

local function LZY_Character_EnsureDetailParts(ent, characterData)
	local p = ent.PlayerModelParts
	if not p or not characterData then return end
	characterData = LZY_Character_DetailDataForEnsure(ent, characterData)

	if LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) ~= "female" then
		local bm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.beard_model or ""))
		local mm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.mustache_model or ""))
		if bm ~= "" and not IsValid(p.beard) then
			p.beard = createModelPart(ent, bm, Color(255, 255, 255), nil)
			if IsValid(p.beard) and characterData.hair_color1 and characterData.hair_color2 then
				ApplyHairGradientToWorldPlayer(ent, p.beard, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, normalizeHairDetailsColor(characterData.hair_details_color))
			end
		end
		if mm ~= "" and not IsValid(p.mustache) then
			p.mustache = createModelPart(ent, mm, Color(255, 255, 255), nil)
			if IsValid(p.mustache) and characterData.hair_color1 and characterData.hair_color2 then
				ApplyHairGradientToWorldPlayer(ent, p.mustache, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, normalizeHairDetailsColor(characterData.hair_details_color))
			end
		end
	end

	local expected = LZY_Character_BuildExpectedAccessories(characterData)
	LZY_Character_AppendRankCosmetics(ent, characterData, expected)
	LZY_Character_SyncAccessoriesToExpected(ent, p, expected)
end

local function LZY_Character_EnsureHairPart(ent, characterData, hq)
	local p = ent.PlayerModelParts
	if not p or not characterData then return end
	local hairModel = LZY_CHARACTER_CONFIG.GetHairModelForCharacter(characterData, ent) or characterData.hair_model
	if istable(hairModel) then
		local picked
		for _, v in pairs(hairModel) do
			if isstring(v) and v ~= "" then picked = v break end
		end
		hairModel = picked
	end
	if not isstring(hairModel) or hairModel == "" then
		LZY_Character_DestroyHairPart(p)
		return
	end

	local wantLod = hq and "hq" or "cheap"
	local curModel = IsValid(p.hair) and string.lower(p.hair:GetModel() or "") or ""
	if IsValid(p.hair) and curModel == string.lower(hairModel) and p.hair._lzyHairLod == wantLod then
		return
	end

	if IsValid(p.hair) and curModel ~= string.lower(hairModel) then
		trackedParts[p.hair] = nil
		SafeRemoveEntity(p.hair)
		p.hair = nil
	end
	if not IsValid(p.hair) then
		p.hair = createModelPart(ent, hairModel, Color(255, 255, 255), nil)
	end
	if not IsValid(p.hair) then return end

	if hq then
		if characterData.hair_color1 and characterData.hair_color2 then
			ApplyHairGradientToWorldPlayer(ent, p.hair, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, normalizeHairDetailsColor(characterData.hair_details_color))
		end
	else
		p.hair:SetSubMaterial()
		ApplyCheapHairToWorldPlayer(ent, p.hair, characterData.hair_color1, characterData.hair_color2)
	end
	p.hair._lzyHairLod = wantLod
end

function LZY_Character_EnsureAccessoryModelForSlot(ply, gearSlot)
	if not IsValid(ply) or not ply:IsPlayer() then return nil end

	local data = (GetPlayerCharacterData and GetPlayerCharacterData(ply)) or (playersModels and playersModels[ply])
	if not data then data = {} end

	local bRankCosmetic = INVENTORY_CONFIG and (
		(INVENTORY_CONFIG.IsMasqueBaseSlot and INVENTORY_CONFIG.IsMasqueBaseSlot(gearSlot))
		or (INVENTORY_CONFIG.IsDivisionBodySlot and INVENTORY_CONFIG.IsDivisionBodySlot(gearSlot))
		or (INVENTORY_CONFIG.IsGradeSlot and INVENTORY_CONFIG.IsGradeSlot(gearSlot))
		or (INVENTORY_CONFIG.IsRankOffsetSlot and INVENTORY_CONFIG.IsRankOffsetSlot(gearSlot)))
	if bRankCosmetic then
		local slotKey = tostring(gearSlot)
		playersModels[ply] = data
		if LZY_IsLarvaCharacter(ply, data) then return nil end
		if not ply.PlayerModelParts
			or ply.RenderOverride ~= ply._lzyCompositeRenderOverride then
			if LZY_Character_TryCreatePlayerClientModels then
				LZY_Character_TryCreatePlayerClientModels(ply, data)
			end
		end
		LZY_Character_EnsureDetailParts(ply, data)
		return LZY_Character_FindAccessoryModelOnPlayer(ply, slotKey)
	end

	gearSlot = tonumber(gearSlot) or 0
	local outfitSlot = INVENTORY_CONFIG and INVENTORY_CONFIG.OUTFIT_EQUIP_SLOT or 2
	if gearSlot < 1 or gearSlot > (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_GEAR_SLOT or 7) or gearSlot == outfitSlot then return nil end

	LZY_Character_MergeInventoryEquippedAccessories(ply, data, gearSlot)
	playersModels[ply] = data

	if LZY_IsLarvaCharacter(ply, data) then return nil end
	local hasParts = ply.PlayerModelParts and IsValid(ply.PlayerModelParts.body)
	if not hasParts and (not data.body_model or not data.hair_model) then return nil end

	if not ply.PlayerModelParts
		or ply.RenderOverride ~= ply._lzyCompositeRenderOverride then
		if LZY_Character_TryCreatePlayerClientModels then
			LZY_Character_TryCreatePlayerClientModels(ply, data)
		end
	end

	LZY_Character_EnsureDetailParts(ply, data)
	return LZY_Character_FindAccessoryModelOnPlayer(ply, gearSlot)
end

local function LZY_Character_DrawModelPart(ent, mdl)
	if not IsValid(mdl) then return end
	if ent._lzyPartsNeedReparent and mdl:GetParent() ~= ent then
		mdl:SetParent(ent)
		mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
	end
	mdl:DrawModel()
end

function LZY_Character_ForceDrawPlayerComposite(ply)
	if not IsValid(ply) then return end
	local prevR, prevG, prevB = render.GetColorModulation()
	local prevA = render.GetBlend()
	render.SetColorModulation(1, 1, 1)
	ply:DrawModel()
	local parts = ply.PlayerModelParts
	if parts then
		LZY_Character_DrawModelPart(ply, parts.body)
		LZY_Character_DrawModelPart(ply, parts.hair)
		LZY_Character_DrawModelPart(ply, parts.beard)
		LZY_Character_DrawModelPart(ply, parts.mustache)
		if istable(parts.accessories) then
			local charData = playersModels and playersModels[ply]
			for i = 1, #parts.accessories do
				LZY_Character_DrawAccessoryModel(ply, parts.accessories[i], charData)
			end
		end
	end
	render.SetColorModulation(prevR, prevG, prevB)
	render.SetBlend(prevA)
end

local function LZY_Character_EnsurePartsSingleDrawNoDraw(parts)
	if not cvLzyPartsSingleDraw:GetBool() or not parts then return end
	local function fix(m)
		if IsValid(m) and not m:GetNoDraw() then m:SetNoDraw(true) end
	end
	fix(parts.body)
	fix(parts.hair)
	fix(parts.beard)
	fix(parts.mustache)
	if istable(parts.accessories) then
		for i = 1, #parts.accessories do fix(parts.accessories[i]) end
	end
end

function LZY_Character_GetRankIdentity(ply, characterData)
	local faction, division, rank = "", 0, 0
	local fromBag = false
	if IsValid(ply) and ply.GetEvoNWString then
		if ply == LocalPlayer() then
			faction = ply:GetEvoNWString("FactionName", "") or ""
			division = tonumber(ply:GetEvoNWInt("FactionDivision", 0)) or 0
			rank = tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0
			fromBag = true
		else
			local bag = LZY_RemoteState and LZY_RemoteState[ply:EntIndex()]
			if bag and bag.ent == ply and bag.values
				and (bag.values["FactionName"] ~= nil or bag.values["FactionRank"] ~= nil) then
				faction = ply:GetEvoNWString("FactionName", "") or ""
				division = tonumber(ply:GetEvoNWInt("FactionDivision", 0)) or 0
				rank = tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0
				fromBag = true
			end
		end
	end
	if not fromBag and istable(characterData) then
		faction = characterData.faction or ""
		division = tonumber(characterData.division) or 0
		rank = tonumber(characterData.rank) or 0
	end
	return faction, division, rank
end

function LZY_Character_GetDisplayBodyModel(characterData, ply)
	local bodyModel = characterData and characterData.body_model
	if LZY_IsRawBodyModel(bodyModel) then return bodyModel end
	if not characterData or not (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankOutfitModel) then return bodyModel end
	if not (IsValid(ply) and ply.GetEvoNWString) then return bodyModel end
	local base = characterData.base_body_model
	if isstring(base) and base ~= "" and characterData.body_model ~= base then return bodyModel end
	local faction, division, rank = LZY_Character_GetRankIdentity(ply, characterData)
	local uniform = LZY_CHARACTER_CONFIG.GetRankOutfitModel(
		faction,
		division,
		rank,
		characterData.gender,
		characterData.unique_id
	)
	if isstring(uniform) and uniform ~= "" then return uniform end
	return bodyModel
end

function LZY_Character_GetDisplayBodyModelFromData(characterData)
	local bodyModel = characterData and characterData.body_model
	if LZY_IsRawBodyModel(bodyModel) then return bodyModel end
	if not characterData or not (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetRankOutfitModel) then return bodyModel end
	local base = characterData.base_body_model
	if isstring(base) and base ~= "" and characterData.body_model ~= base then return bodyModel end
	local uniform = LZY_CHARACTER_CONFIG.GetRankOutfitModel(
		characterData.faction,
		characterData.division,
		characterData.rank,
		characterData.gender,
		characterData.unique_id
	)
	if isstring(uniform) and uniform ~= "" then return uniform end
	return bodyModel
end

local function createPlayerClientSideModel(ent, characterData)
    if not ent or not IsValid(ent) then return end
	if LZY_Character_ApplyModelScale and istable(characterData) then
		LZY_Character_ApplyModelScale(ent, characterData)
	end
	local isRaw = LZY_IsLarvaCharacter(ent, characterData)
	if (not ent._lzyCrowdDummy) and (not isRaw) and LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		LZY_Character_NoteBuildBlockedByLoading()
		return
	end
	if ent.GetEvoNWBool and ent:GetEvoNWBool("NCM_TF_Active", false) then return end
	if isRaw then
		removePlayerModelPartEntities(ent.PlayerModelParts)
		ent.PlayerModelParts = nil
		LZY_ClearCharacterVisualOverrides(ent, { reschedule = true })
		LZY_SetLarvaRawRenderOverride(ent)
		if EVO_HollowProg and EVO_HollowProg.ApplyAppearance and characterData.unique_id then
			local vasto = EVO_HollowProg.Config and characterData.body_model == EVO_HollowProg.Config.VastoModel
			EVO_HollowProg.ApplyAppearance(ent, vasto, characterData.unique_id)
		end
		return
	end

	local lightBot = characterData._lzyLightBot == true
		or (ent.IsBot ~= nil and ent:IsBot())

	local accList = {}

	local bodyModel = LZY_Character_GetDisplayBodyModel(characterData, ent)
	local bodyPart = createModelPart(ent, bodyModel, nil, characterData.skin_color)
	if not IsValid(bodyPart) then
		for _, other in player.Iterator() do
			if other ~= ent and IsValid(other) and other.PlayerModelParts then
				LZY_Character_DestroyDetailParts(other, other.PlayerModelParts)
			end
		end
		local failures = math.min((ent._lzyBodyAllocFailures or 0) + 1, 6)
		local delay = math.min(0.5 * (2 ^ (failures - 1)), 8)
		ent._lzyBodyAllocFailures = failures
		ent._lzyBodyAllocBlockedUntil = CurTime() + delay
		if not ent._lzyBodyAllocRetryScheduled then
			ent._lzyBodyAllocRetryScheduled = true
			timer.Simple(delay, function()
				if not IsValid(ent) then return end
				ent._lzyBodyAllocRetryScheduled = nil
				if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
					LZY_Character_NoteBuildBlockedByLoading()
					return
				end
				local d = playersModels and playersModels[ent]
				if d then LZY_Character_TryCreatePlayerClientModels(ent, d) end
			end)
		end
		return
	end

	removePlayerModelPartEntities(ent.PlayerModelParts)

	LZY_Character_ApplyFaceAppearanceFromData(ent, characterData)

	if not lightBot and LZY_ApplyTattooFromCharacterData then
		LZY_ApplyTattooFromCharacterData(ent, characterData)
	end

	ent.PlayerModelParts = {
        body = bodyPart,
		hair = nil,
		beard = nil,
		mustache = nil,
		tattoo = nil,
		accessories = accList,
	}
	-- Amputation (evo_science) : le corps est RECREE a chaque rebuild (tenue, LOD, PVS),
	-- les bodygroups du membre coupe se reposent donc ici. Sans effet si le modele ne les a pas.
	if EVO_AMPUT and EVO_AMPUT.ApplyBodygroups then EVO_AMPUT.ApplyBodygroups(ent, bodyPart) end
	-- Tatouages du corps (test tattoo_corps_v1) : même raison, re-posés à chaque rebuild.
	LZY_ApplyBodyTattoo(bodyPart, characterData, "w" .. ent:EntIndex(), LZY_Character_TattooMaxAxisForEntity(ent))
	ent._lzyBodyAllocFailures = 0
	ent._lzyBodyAllocBlockedUntil = nil
	ent._lzyFaceMismatchSince = nil

    if not lightBot and characterData.hair_color1 and characterData.hair_color2 then
        ApplyHairGradientToWorldPlayer(ent, nil, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, normalizeHairDetailsColor(characterData.hair_details_color))
    end

	if not lightBot then
		LZY_Character_ScheduleFaceAppearanceRefresh(ent, characterData)
	end

	ent:CallOnRemove("EVO:Client:PlayerClientSideModel:OnRemove", function()
		removePlayerModelPartEntities(ent.PlayerModelParts)
	end)

	local renderOverride = function(_, flags)
		if not IsValid(ent) then return end

		-- Un perso dont un modele a des materiaux transparents est rendu en DEUX passes
		-- par le moteur (opaque puis translucide), et chaque passe redessinait tout le
		-- composite : 62 appels opaques + 61 translucides par image pour 61 persos
		-- (evo_persos_analyse du 28/09/2026). Un DrawModel lance d'ici dessine deja
		-- tous les materiaux, transparents compris, des la passe opaque. La passe
		-- translucide ne dessine donc que si la passe opaque n'a pas eu lieu dans
		-- l'image (perso en fondu, que le moteur ne rend qu'en translucide). Seule une
		-- passe opaque de la MEME vue compte : les passes de profondeur (ombres, SSAO)
		-- et les autres vues (reflets, photo d'imposteur) ne dessinent pas l'ecran, un
		-- perso en fondu disparaissait si l'une d'elles passait avant.
		-- Et seul un perso entierement opaque est saute : en fondu ou en clignotement
		-- (alpha, render mode, blend du moteur), il reste dessine dans les deux passes
		-- comme avant, meme si un autre addon l'a dessine en opaque dans l'image.
		-- wzl_passe_unique 0 remet l'ancien rendu (test).
		local image = FrameNumber()
		local f = tonumber(flags) or 0
		local profondeur = (STUDIO_SHADOWDEPTHTEXTURE and bit.band(f, STUDIO_SHADOWDEPTHTEXTURE) ~= 0)
			or (STUDIO_SSAODEPTHTEXTURE and bit.band(f, STUDIO_SSAODEPTHTEXTURE) ~= 0)
		if not profondeur and LZY_Character_CvPasseUnique:GetBool() then
			local rt = render.GetRenderTarget()
			local cible = rt and rt:GetName() or ""
			if STUDIO_TRANSPARENCY and bit.band(f, STUDIO_TRANSPARENCY) ~= 0 then
				if ent._lzyOpaqueImage == image and ent._lzyOpaqueCible == cible
					and render.GetBlend() >= 0.999 and ent:GetRenderMode() == RENDERMODE_NORMAL
					and ent:GetColor().a >= 255 then
					return
				end
			else
				ent._lzyOpaqueImage, ent._lzyOpaqueCible = image, cible
			end
		end

		local localPly = LocalPlayer()
		if not IsValid(localPly) then return end

		local state = ent._lzyDrawState
		if not state then
			LZY_Character_RefreshDrawState(ent, localPly)
			state = ent._lzyDrawState
		end
		if not state then return end

		-- Photo d'imposteur en cours (evo_persos_fps) : c'est ce rendu complet qui la fait.
		if EVO_PERSOS and EVO_PERSOS.enPhoto then EVO_PERSOS.photoComplete = true end
		-- Mannequin de test au palier imposteur (evo_persos_fps) : sa photo le remplace,
		-- comme PrePlayerDraw le fait pour un joueur (ce hook ne voit pas les mannequins).
		if ent._lzyCrowdDummy and EVO_PERSOS and EVO_PERSOS.ImposteurPrend and EVO_PERSOS.ImposteurPrend(ent) then return end

		local charData = playersModels and playersModels[ent]
		local needsParts = state.shouldDraw and charData and charData.body_model
			and (not ent.PlayerModelParts or LZY_Character_PlayerNeedsModelRepair(ent))
		if needsParts and state.shouldBuild then
			local now = CurTime()
			local forceRebuild = (ent._lzyWasShouldDraw == false and state.shouldDraw == true)
				or (ent._lzyWasInFaceRange == false and state.inFaceRange == true)
			ent._lzyModelSyncNext = ent._lzyModelSyncNext or 0
			if not ent._lzyModelSyncPending and (forceRebuild or now >= ent._lzyModelSyncNext) then
				ent._lzyModelSyncPending = true
				ent._lzyModelSyncNext = now + (forceRebuild and 0.05 or 0.5)
				timer.Simple(0, function()
					if not IsValid(ent) then return end
					ent._lzyModelSyncPending = nil
					local d = playersModels and playersModels[ent]
					if d then LZY_Character_TryCreatePlayerClientModels(ent, d) end
				end)
			end
		end
		ent._lzyWasShouldDraw = state.shouldDraw ~= false
		ent._lzyWasInFaceRange = state.inFaceRange == true

		if ent:IsPlayer() and not state.isLocal then
			if state.tfActive or state.dormant or not state.shouldBuild then
				if ent.PlayerModelParts then
					LZY_Character_DestroyPlayerClientModels(ent, { keepRenderOverride = true })
				end
				return
			end
		end

		if state.dormant then
			if ent.PlayerModelParts then
				LZY_Character_DestroyPlayerClientModels(ent, { keepRenderOverride = true })
			end
			return
		end

		if not state.isLocal and state.shouldDraw == false then
			if ent.PlayerModelParts then
				LZY_Character_DestroyPlayerClientModels(ent, { keepRenderOverride = true })
			end
			return
		end

		if LZY_IsLarvaCharacter(ent) then
			if not ent._lzyLarvaEnterPending then
				ent._lzyLarvaEnterPending = true
				LZY_ClearCharacterVisualOverrides(ent, { reschedule = true })
				timer.Simple(0, function()
					if not IsValid(ent) then return end
					ent._lzyLarvaEnterPending = nil
					if not LZY_IsLarvaCharacter(ent) then return end
					local d = playersModels and playersModels[ent]
					if d and LZY_Character_TryCreatePlayerClientModels then
						LZY_Character_TryCreatePlayerClientModels(ent, d)
					else
						LZY_SetLarvaRawRenderOverride(ent)
					end
				end)
			end
			LZY_LarvaRawDrawModel(ent)
			return
		end

		if not state.instanceOk or state.charMenuHideOthers then return end

		if ent:IsPlayer() then
			if LZY_Character_PlayerIsDrawHidden(ent) then
				if ent.DrawShadow then ent:DrawShadow(false) end
				return
			end
			if not state.inFaceRange then
				if ent.PlayerModelParts then
					LZY_Character_DestroyPlayerClientModels(ent, { keepRenderOverride = true })
				end
				return
			end
			if not state.isLocal then
				local tData = playersModels and playersModels[ent]
				if tData and LZY_Character_DataHasTattoo(tData) then
					local tAxis = LZY_Character_TattooMaxAxisForEntity(ent)
					if tAxis > 0 then
						local needsTattoo = ent._lzy_tattooMode ~= "rt_baked"
							or ent._lzyTattooMaxAxisApplied ~= tAxis
						if needsTattoo then
							local now = CurTime()
							ent._lzyTattooEnsureNext = ent._lzyTattooEnsureNext or 0
							if now >= ent._lzyTattooEnsureNext and not ent._lzyTattooEnsurePending then
								ent._lzyTattooEnsurePending = true
								ent._lzyTattooEnsureNext = now + 0.5
								timer.Simple(0, function()
									if not IsValid(ent) then return end
									ent._lzyTattooEnsurePending = nil
									local d = playersModels and playersModels[ent]
									if d then LZY_ApplyTattooFromCharacterData(ent, d) end
								end)
							end
						end
					elseif ent._lzy_tattooMode then
						LZY_ClearTattooDecoration(ent)
					end
				end
			end
		end

		local prevR, prevG, prevB = render.GetColorModulation()
		local prevA = render.GetBlend()

		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
		ent:DrawShadow(false)
		-- Palier de detail (evo_persos_fps) : 0 proche, 1 lointain, 2 imposteur.
		-- De loin, la tete saute ses flexes (le visage revient au neutre, invisible
		-- a 30 m) ; le LOD et l'IK sont poses par le module au changement de palier.
		local palier = (EVO_PERSOS and EVO_PERSOS.Palier) and EVO_PERSOS.Palier(ent) or 0
		if palier >= 1 then ent:DrawModel(EVO_PERSOS.FLAGS_TETE_LOIN) else ent:DrawModel() end

        if ent.PlayerModelParts and not cvLzyDbgHideParts:GetBool() then
			local drawDetails = state.drawDetails
			local parts = ent.PlayerModelParts
			local detailData = playersModels and playersModels[ent]
			-- Les Ensure* (cheveux, barbe, accessoires, insignes) verifient que les
			-- pieces correspondent aux donnees : table neuve, lookups config et
			-- string.lower par piece, pour un resultat identique 99 fois sur 100.
			-- Mesure a ~40 us par joueur visible et par image en foule. On ne les
			-- refait que toutes les 0,25 s, ou des que l'etat de dessin change
			-- (budget, distance), ou quand une mise a jour d'apparence remet
			-- _lzyEnsureNext a zero (InvalidateDrawState). Le dessin, lui, est
			-- fait a chaque image.
			local now = CurTime()
			local sig = (drawDetails and 1 or 0) + (state.drawHairHQ and 2 or 0) + (state.drawHairCheap and 4 or 0)
			local ensure = ent._lzyEnsureSig ~= sig or (ent._lzyEnsureNext or 0) <= now
			if ensure then
				ent._lzyEnsureSig = sig
				ent._lzyEnsureNext = now + 0.25
			end
			LZY_Character_EnsurePartsSingleDrawNoDraw(parts)
			if EVO_PERSOS and EVO_PERSOS.PiecesDebut then EVO_PERSOS.PiecesDebut(ent, parts, palier) end
			LZY_Character_DrawModelPart(ent, parts.body)

			if state.drawHairHQ or state.drawHairCheap then
				if ensure and detailData then
					LZY_Character_EnsureHairPart(ent, detailData, state.drawHairHQ == true)
				end
				LZY_Character_DrawModelPart(ent, parts.hair)
			elseif ensure then
				LZY_Character_DestroyHairPart(parts)
			end

			if drawDetails then
				if ensure and detailData then LZY_Character_EnsureDetailParts(ent, detailData) end
				LZY_Character_DrawModelPart(ent, parts.beard)
				LZY_Character_DrawModelPart(ent, parts.mustache)
				if istable(parts.accessories) then
					local charData = playersModels and playersModels[ent]
					for i = 1, #parts.accessories do
						LZY_Character_DrawAccessoryModel(ent, parts.accessories[i], charData)
					end
				end
			else
				if ensure then
					LZY_Character_DestroyOptionalDetailParts(ent, parts)
					if detailData then LZY_Character_EnsureRankCosmeticParts(ent, detailData) end
				end
				if istable(parts.accessories) then
					local charData = playersModels and playersModels[ent]
					for i = 1, #parts.accessories do
						local mdl = parts.accessories[i]
						if LZY_Character_IsPersistentAccessoryPart(mdl) then
							LZY_Character_DrawAccessoryModel(ent, mdl, charData)
						end
					end
				end
			end
			if EVO_PERSOS and EVO_PERSOS.PiecesFin then EVO_PERSOS.PiecesFin() end
			LZY_Character_ClearPartsNeedReparentIfAttached(ent, parts)
		end

		render.SetColorModulation(prevR, prevG, prevB)
		render.SetBlend(prevA)
	end
	ent._lzyCompositeRenderOverride = renderOverride
	if not (ent.GetEvoNWBool and ent:GetEvoNWBool("NCM_IsAssassinInvisible", false)) then
		ent.RenderOverride = renderOverride
	end
	if ent.DrawShadow then ent:DrawShadow(false) end
	if ent.AddEffects then ent:AddEffects(EF_NOSHADOW) end

	ent._lzyPartsNeedReparent = nil
	LZY_Character_InvalidateDrawState(ent)
	LZY_Character_RefreshDrawState(ent)
	local st = ent._lzyDrawState
	if st and (st.drawHairHQ or st.drawHairCheap) then
		LZY_Character_EnsureHairPart(ent, characterData, st.drawHairHQ == true)
	end
end

function LZY_Character_TryCreatePlayerClientModels(ply, characterData)
	if not IsValid(ply) or not characterData or not characterData.body_model then return end
	if LZY_Character_ApplyModelScale then
		LZY_Character_ApplyModelScale(ply, characterData)
	end
	if LZY_Character_InHubOrFinalizeFlow(ply) then return end
	local isRaw = LZY_IsLarvaCharacter(ply, characterData)
	if LZY_IsRawBodyModel(characterData.body_model) and not LZY_IsRawBodyModel(ply:GetModel() or "") then
		LZY_ClearCharacterVisualOverrides(ply)
		LZY_Character_DeferPlayerModelBuild(ply)
		return
	end
	if (not isRaw) and LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		LZY_Character_NoteBuildBlockedByLoading()
		return
	end
	if (ply._lzyBodyAllocBlockedUntil or 0) > CurTime() then return end
	ply._lzyBodyAllocBlockedUntil = nil
	if not LZY_Character_PlayerShouldBuildClientModels(ply) then
		if ply.IsDormant and ply:IsDormant() then
			LZY_Character_DeferPlayerModelBuild(ply)
			return
		end
		if ply.PlayerModelParts then
			LZY_Character_DestroyPlayerClientModels(ply, { keepRenderOverride = true })
		end
		return
	end
	if ply._lzyCrowdDummy then
		createPlayerClientSideModel(ply, characterData)
		return
	end
	if not LZY_IsLarvaCharacter(ply, characterData)
		and not LZY_Character_FaceReadyForComposite(ply, characterData) then
		LZY_Character_DeferPlayerModelBuild(ply)
		return
	end
	if LZY_IsLarvaCharacter(ply, characterData) or characterData.body_model then
		createPlayerClientSideModel(ply, characterData)
	end
	if (ply._lzyBodyAllocBlockedUntil or 0) > CurTime() then return end
	if LZY_Character_PlayerNeedsModelRepair(ply) then
		local n = (ply._lzyCreateRetryCount or 0) + 1
		if n <= 3 and not ply._lzyCreateRetryScheduled then
			ply._lzyCreateRetryScheduled = true
			ply._lzyCreateRetryCount = n
			timer.Simple(0.5 * n, function()
				if not IsValid(ply) then return end
				ply._lzyCreateRetryScheduled = nil
				local d = playersModels and playersModels[ply]
				if d then LZY_Character_TryCreatePlayerClientModels(ply, d) end
			end)
		end
	else
		ply._lzyCreateRetryCount = 0
	end
end

function LZY_Character_DeferPlayerModelBuild(ply, maxAttempts)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	maxAttempts = maxAttempts or 20
	if ply._lzyDeferBuildActive then return end
	ply._lzyDeferBuildActive = true
	local token = (ply._lzyDeferBuildToken or 0) + 1
	ply._lzyDeferBuildToken = token

	local function finish()
		if IsValid(ply) and ply._lzyDeferBuildToken == token then
			ply._lzyDeferBuildActive = nil
		end
	end

	local function attempt(left)
		if not IsValid(ply) or ply._lzyDeferBuildToken ~= token then return end
		if not ply:Alive() then finish() return end

		local data = playersModels and playersModels[ply]
		if not data or not data.body_model then
			if left > 0 then timer.Simple(0, function() attempt(left - 1) end) else finish() end
			return
		end

		if ply:IsDormant() then
			if left > 0 then timer.Simple(0, function() attempt(left - 1) end) else finish() end
			return
		end

		if not LZY_Character_PlayerShouldBuildClientModels(ply) then
			if left > 0 then
				timer.Simple(0.1, function() attempt(left - 1) end)
			else
				finish()
			end
			return
		end

		if LZY_IsRawBodyModel(data.body_model) and not LZY_IsRawBodyModel(ply:GetModel() or "") then
			LZY_ClearCharacterVisualOverrides(ply)
			if left > 0 then
				local gap = (ply == LocalPlayer()) and 0.05 or 0.1
				timer.Simple(gap, function() attempt(left - 1) end)
			else
				finish()
				LZY_Character_TryCreatePlayerClientModels(ply, data)
			end
			return
		end

		if not LZY_IsLarvaCharacter(ply, data)
			and not LZY_Character_FaceReadyForComposite(ply, data) then
			if left > 0 then
				local gap = (ply == LocalPlayer()) and 0.05 or 0.1
				timer.Simple(gap, function() attempt(left - 1) end)
			else
				finish()
			end
			return
		end

		finish()
		LZY_Character_TryCreatePlayerClientModels(ply, data)
	end

	if ply == LocalPlayer() and maxAttempts < 40 then
		maxAttempts = 40
	end
	timer.Simple(0, function() attempt(maxAttempts) end)
end

local _lzyWantSet = {}
local _lzyWantOrder = {}
local _lzyWantInFlightUntil = {}
local _lzyWantMiss = {}
local _lzyWantRevProbed = {}
local _lzyWantFlushScheduled = false
local WANTSET_COALESCE = 0.15
local WANTSET_MAX_KEYS = 32
local WANTSET_MAX_SIZE = 96
local WANTSET_INFLIGHT_GAP = 0.4
local WANTSET_INFLIGHT_GAP_MAX = 4

local function LZY_Character_NetKeyFor(ply)
	if not IsValid(ply) then return nil end
	local key = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ply)) or ply:SteamID64()
	if not isstring(key) or key == "" then return nil end
	return key
end

local function LZY_Character_WantSetForget(key, opts)
	if not key then return end
	_lzyWantSet[key] = nil
	_lzyWantInFlightUntil[key] = nil
	_lzyWantMiss[key] = nil
	if not (opts and opts.keepRevProbed) then
		_lzyWantRevProbed[key] = nil
	end
	for i = #_lzyWantOrder, 1, -1 do
		if _lzyWantOrder[i] == key then
			table.remove(_lzyWantOrder, i)
		end
	end
end

local function LZY_Character_WantSetEnqueue(key)
	if _lzyWantSet[key] then return end
	for i = #_lzyWantOrder, 1, -1 do
		if _lzyWantOrder[i] == key then
			table.remove(_lzyWantOrder, i)
		end
	end
	_lzyWantSet[key] = true
	_lzyWantOrder[#_lzyWantOrder + 1] = key
end

local function LZY_Character_WantSetTrimFIFO()
	while #_lzyWantOrder > WANTSET_MAX_SIZE do
		local drop = table.remove(_lzyWantOrder, 1)
		if drop then
			LZY_Character_WantSetForget(drop)
		end
	end
	if #_lzyWantOrder == 0 and next(_lzyWantSet) ~= nil then
		for k in pairs(_lzyWantSet) do
			_lzyWantOrder[#_lzyWantOrder + 1] = k
		end
		while #_lzyWantOrder > WANTSET_MAX_SIZE do
			local drop = table.remove(_lzyWantOrder, 1)
			if drop then LZY_Character_WantSetForget(drop) end
		end
	end
end

local LZY_Character_FlushWantSet

function LZY_Character_ScheduleWantFlush(delay)
	if _lzyWantFlushScheduled then return end
	if next(_lzyWantSet) == nil then return end
	_lzyWantFlushScheduled = true
	timer.Create("LZY:Character:WantSetFlush", math.max(0, tonumber(delay) or WANTSET_COALESCE), 1, function()
		_lzyWantFlushScheduled = false
		LZY_Character_FlushWantSet()
	end)
end

function LZY_Character_WantPM(ply, opts)
	local key = LZY_Character_NetKeyFor(ply)
	if not key then return end
	opts = opts or {}
	if opts.rateLimit and _lzyWantSet[key] then return end
	if opts.force then
		_lzyWantInFlightUntil[key] = nil
		_lzyWantMiss[key] = nil
	end
	local wasEmpty = next(_lzyWantSet) == nil
	if not _lzyWantSet[key] then
		LZY_Character_WantSetEnqueue(key)
	end
	if opts.revProbe then
		_lzyWantSet[key] = { revProbe = true, forceFresh = opts.force == true }
		if opts.force then
			_lzyWantRevProbed[key] = true
		end
	end
	LZY_Character_WantSetTrimFIFO()
	LZY_Character_ScheduleWantFlush(wasEmpty and 0 or WANTSET_COALESCE)
end

LZY_Character_InvalidateStaleRawModel = function(ent)
	if not IsValid(ent) then return false end
	local d = playersModels and playersModels[ent]
	if not (d and LZY_IsRawBodyModel(d.body_model)) then return false end
	if LZY_IsLarvaCharacter(ent, d) then return false end
	local bAnim = ent.GetEvoNWBool and ent:GetEvoNWBool("EVO_AnimatorHollow", false)
	if not bAnim and ent.GetEvoNWBool
		and (ent:GetEvoNWBool("EVO_HollowRaw", false) or ent:GetEvoNWBool("EVO_IsLarva", false)) then
		return false
	end
	playersModels[ent] = nil
	local key = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ent)) or ent:SteamID64()
	if isstring(key) and key ~= "" then
		_lzyPendingModelsBySteamID64[key] = nil
		LZY_Character_WantSetForget(key)
		_lzyWantRevProbed[key] = nil
	end
	if LZY_Character_DestroyPlayerClientModels then
		LZY_Character_DestroyPlayerClientModels(ent)
	else
		ent.RenderOverride = nil
		ent._lzyCompositeRenderOverride = nil
	end
	if ent == LocalPlayer() or LZY_Character_PlayerExpectsModelData(ent, LocalPlayer()) then
		LZY_Character_WantPM(ent, { revProbe = true, force = true })
	end
	return true
end

local function LZY_Character_FindPlayerBySteamID64(sid64)
	if not isstring(sid64) or sid64 == "" then return nil end
	if string.sub(sid64, 1, 3) == "BOT" then
		local idx = tonumber(string.sub(sid64, 4))
		local ent = idx and Entity(idx) or NULL
		if IsValid(ent) and ent:IsPlayer() then return ent end
		return nil
	end
	for _, ply in player.Iterator() do
		if not IsValid(ply) then continue end
		local key = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ply)) or ply:SteamID64()
		if key == sid64 or ply:SteamID64() == sid64 then return ply end
	end
	return nil
end

local function LZY_Character_IncomingIsFresher(existing, incoming)
	if not istable(existing) or not existing.body_model then return true end
	if not istable(incoming) then return false end
	local er = tonumber(existing._lzyModelRev) or 0
	local ir = tonumber(incoming._lzyModelRev) or 0
	if er > 0 and ir > 0 then
		return ir > er
	end
	return not existing._lzyFromCsm
end

local function LZY_Character_TryApplyPendingModelForPlayer(ply)
	if not IsValid(ply) then return false end
	local sid = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ply)) or ply:SteamID64()
	local pending = _lzyPendingModelsBySteamID64[sid]
	if not pending then return false end
	_lzyPendingModelsBySteamID64[sid] = nil
	if not LZY_Character_IncomingIsFresher(playersModels[ply], pending) then
		return false
	end
	playersModels[ply] = pending
	LZY_Character_WantSetForget(sid)
	return true
end

local function LZY_Character_ApplyIncomingPlayerModels(incoming)
	if not istable(incoming) then return end
	for key, data in pairs(incoming) do
		if not istable(data) then continue end
		local ply = nil
		if IsValid(key) and key.IsPlayer and key:IsPlayer() then
			ply = key
		else
			ply = LZY_Character_FindPlayerBySteamID64(tostring(key))
		end
		if IsValid(ply) then
			local netKey = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ply)) or ply:SteamID64()
			_lzyPendingModelsBySteamID64[netKey] = nil
			if isstring(data.body_model) and data.body_model ~= "" then
				LZY_Character_WantSetForget(netKey)
				_lzyWantRevProbed[netKey] = nil
			end
			if LZY_Character_IncomingIsFresher(playersModels[ply], data) then
				playersModels[ply] = data
			end
		else
			local pendingKey = tostring(key)
			local existingPending = _lzyPendingModelsBySteamID64[pendingKey]
			if LZY_Character_IncomingIsFresher(existingPending, data) then
				_lzyPendingModelsBySteamID64[pendingKey] = data
			end
			if isstring(data.body_model) and data.body_model ~= "" then
				LZY_Character_WantSetForget(pendingKey)
			end
		end
	end
end

LZY_Character_PlayerExpectsModelData = function(p, lp)
	if not IsValid(p) or not p:Alive() then return false end
	if lp and p == lp then return false end
	if p.GetEvoNWBool and p:GetEvoNWBool("EVO_NoCSM", false) then return false end
	if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(p) then
		return false
	end
	return true
end

local function LZY_Character_LocalPlayerMissingModelData()
	local lp = LocalPlayer()
	if not IsValid(lp) then return true end
	local d = playersModels and playersModels[lp]
	return not d or not d.body_model
end

local function LZY_Character_InterestRadiusSqr()
	if LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetFaceBodyHairDistanceSqr then
		return LZY_CHARACTER_CONFIG.GetFaceBodyHairDistanceSqr()
	end
	return 4000 * 4000
end

local function LZY_Character_AnyAlivePlayerMissingModelData(lp)
	lp = lp or LocalPlayer()
	if not IsValid(lp) then return false end
	if LZY_Character_LocalPlayerMissingModelData() then return true end
	local radiusSqr = LZY_Character_InterestRadiusSqr()
	local origin = lp:GetPos()
	for _, p in player.Iterator() do
		if not LZY_Character_PlayerExpectsModelData(p, lp) then continue end
		if p:GetPos():DistToSqr(origin) > radiusSqr then continue end
		local d = playersModels and playersModels[p]
		if not d or not d.body_model then
			return true
		end
	end
	return false
end

function LZY_Character_WantScanMissingPM(opts)
	opts = opts or {}
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if opts.force then
		_lzyWantRevProbed = {}
		for k in pairs(_lzyWantSet) do
			_lzyWantInFlightUntil[k] = nil
			_lzyWantMiss[k] = nil
		end
	end
	local own = playersModels[lp]
	if not own or not own.body_model then
		LZY_Character_WantPM(lp)
	end
	local radiusSqr = LZY_Character_InterestRadiusSqr()
	local origin = lp:GetPos()
	for _, p in player.Iterator() do
		if not LZY_Character_PlayerExpectsModelData(p, lp) then continue end
		if p:GetPos():DistToSqr(origin) > radiusSqr then continue end
		local d = playersModels[p]
		if not d or not d.body_model then
			LZY_Character_WantPM(p)
		else
			local key = LZY_Character_NetKeyFor(p)
			if key and not _lzyWantRevProbed[key] then
				_lzyWantRevProbed[key] = true
				LZY_Character_WantPM(p, { revProbe = true })
			end
		end
	end
end

LZY_Character_FlushWantSet = function()
	if next(_lzyWantSet) == nil then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if (EVO_HollowProg and (EVO_HollowProg._Finalizing or EVO_HollowProg._FinalizePending))
		or (LZY_IsCharacterCreatorOpen and LZY_IsCharacterCreatorOpen())
		or (NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive())
		or LZY_Character_IsLocalInCharMenu() then
		_lzyWantSet = {}
		_lzyWantOrder = {}
		_lzyWantInFlightUntil = {}
		_lzyWantRevProbed = {}
		return
	end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		LZY_Character_ScheduleWantFlush(0.5)
		return
	end
	local now = CurTime()
	local batch = {}
	local n = 0
	local nextReadyIn = nil
	local PROBE_MISS_CAP = 3
	for oi = 1, #_lzyWantOrder do
		local key = _lzyWantOrder[oi]
		if not _lzyWantSet[key] then continue end
		local ply = LZY_Character_FindPlayerBySteamID64(key)
		local d = IsValid(ply) and playersModels[ply] or nil
		local wantMeta = _lzyWantSet[key]
		local revProbe = istable(wantMeta) and wantMeta.revProbe == true
		local forceFresh = istable(wantMeta) and wantMeta.forceFresh == true
		if d and d.body_model and not revProbe then
			LZY_Character_WantSetForget(key)
		elseif not IsValid(ply) then
			LZY_Character_WantSetForget(key)
		elseif now < (_lzyWantInFlightUntil[key] or 0) then
			local wait = (_lzyWantInFlightUntil[key] or 0) - now
			if nextReadyIn == nil or wait < nextReadyIn then nextReadyIn = wait end
		else
			n = n + 1
			local rev = 0
			if d and d.body_model and not forceFresh then
				rev = tonumber(d._lzyModelRev) or 0
			end
			batch[n] = { key = key, rev = rev }
			local miss = (_lzyWantMiss[key] or 0) + 1
			_lzyWantMiss[key] = miss
			_lzyWantInFlightUntil[key] = now + math.min(WANTSET_INFLIGHT_GAP * miss, WANTSET_INFLIGHT_GAP_MAX)
			if revProbe and d and d.body_model and miss >= PROBE_MISS_CAP and not forceFresh then
				LZY_Character_WantSetForget(key, { keepRevProbed = true })
			end
			if n >= WANTSET_MAX_KEYS then break end
		end
	end
	for i = #_lzyWantOrder, 1, -1 do
		if not _lzyWantSet[_lzyWantOrder[i]] then
			table.remove(_lzyWantOrder, i)
		end
	end
	if n > 0 then
		net.Start("EVO:Server:CharacterCreator:RequestPM")
			net.WriteUInt(n, 8)
			for i = 1, n do
				net.WriteString(batch[i].key)
				net.WriteUInt(batch[i].rev, 32)
			end
		net.SendToServer()
		nextReadyIn = WANTSET_INFLIGHT_GAP
	end
	if next(_lzyWantSet) ~= nil and nextReadyIn ~= nil then
		LZY_Character_ScheduleWantFlush(math.max(0.05, nextReadyIn))
	end
end

timer.Remove("LZY:Character:WantSetFlush")

local function LZY_Character_RecoverLocalPlayerModelAfterLoading()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if LZY_Character_InHubOrFinalizeFlow(lp) then return end
	LZY_Character_TryApplyPendingModelForPlayer(lp)
	local data = playersModels and playersModels[lp]
	if data and data.body_model then
		LZY_Character_TryCreatePlayerClientModels(lp, data)
		if lp.HUD_UpdatePlayerModel then lp:HUD_UpdatePlayerModel() end
		return
	end
	LZY_Character_WantScanMissingPM({ force = true })
end

function LZY_Character_OnPlayerEnteredPVS(ply)
	ply._lzyPartsNeedReparent = true
	LZY_Character_InvalidateDrawState(ply)
	LZY_Character_UpdateDetailBudgetTags()
	LZY_Character_TryApplyPendingModelForPlayer(ply)
	local data = playersModels and playersModels[ply]
	if not data or not data.body_model then
		if LZY_Character_PlayerExpectsModelData(ply, LocalPlayer()) then
			LZY_Character_WantPM(ply)
		end
		return
	end
	local key = LZY_Character_NetKeyFor(ply)
	if key and not _lzyWantRevProbed[key] and LZY_Character_PlayerExpectsModelData(ply, LocalPlayer()) then
		_lzyWantRevProbed[key] = true
		LZY_Character_WantPM(ply, { revProbe = true })
	end
	LZY_Character_DeferPlayerModelBuild(ply)
end

function LZY_Character_OnPlayerExitedPVS(ply)
	LZY_Character_InvalidateDrawState(ply)
	LZY_Character_DestroyPlayerClientModels(ply)
end

function LZY_Character_SyncPlayerClientModels(ply, opts)
	opts = opts or {}
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if LZY_Character_InHubOrFinalizeFlow(ply) then
		if ply.PlayerModelParts or ply.RenderOverride then
			LZY_Character_DestroyPlayerClientModels(ply)
		end
		return
	end
	if not ply:Alive() then
		if ply.PlayerModelParts or ply.RenderOverride then
			LZY_Character_DestroyPlayerClientModels(ply)
		end
		return
	end
	if not LZY_Character_PlayerShouldBuildClientModels(ply) then
		if ply:IsDormant() then
			if LZY_Character_PlayerNeedsModelRepair(ply) then
				LZY_Character_DeferPlayerModelBuild(ply)
			end
			return
		end
		local maxDrawn = LZY_Character_GetMaxCharactersDrawn()
		if maxDrawn > 0 and ply._lzyShouldDraw == nil then
			LZY_Character_DeferPlayerModelBuild(ply)
			return
		end
		if ply.PlayerModelParts or ply.RenderOverride then
			LZY_Character_DestroyPlayerClientModels(ply, { keepRenderOverride = true })
		end
		return
	end
	local data = playersModels[ply]
	if not data or not data.body_model then
		LZY_Character_TryApplyPendingModelForPlayer(ply)
		data = playersModels[ply]
	end
	if not data or not data.body_model then
		if LZY_Character_PlayerExpectsModelData(ply, LocalPlayer()) then
			LZY_Character_WantPM(ply)
		end
		return
	end
	local sid = ply:SteamID64()
	if sid then
		for part in pairs(trackedParts) do
			if IsValid(part) and not part._lzyPet
				and part.owner_steamid64 == sid and not IsValid(part:GetParent()) then
				ply._lzyPartsNeedReparent = true
				trackedParts[part] = nil
				SafeRemoveEntity(part)
			end
		end
	end
	if opts.refreshMaterialsOnly and not opts.forceRebuild and not LZY_Character_PlayerNeedsModelRepair(ply) then
		if not LZY_IsLarvaCharacter(ply, data) and data.hair_model then
			LZY_RefreshEntityFaceMaterials(ply, data)
		end
		return
	end
	if opts.forceRebuild or LZY_Character_PlayerNeedsModelRepair(ply) then
		LZY_Character_TryCreatePlayerClientModels(ply, data)
	end
end

function LZY_Character_RefreshAllPlayerFaceMaterials(opts)
	opts = opts or {}
	if opts.invalidateCaches ~= false then
		LZY_InvalidateFaceRenderCaches()
	end
	local lp = LocalPlayer()
	if IsValid(lp) then
		local data = playersModels and playersModels[lp]
		if data and data.body_model then
			if LZY_IsLarvaCharacter(lp, data) or LZY_Character_PlayerNeedsModelRepair(lp) then
				LZY_Character_SyncPlayerClientModels(lp, { forceRebuild = true })
			elseif data.hair_model then
				LZY_RefreshEntityFaceMaterials(lp, data)
			end
		end
	end
	for _, ply in player.Iterator() do
		if not IsValid(ply) or not ply:Alive() or ply == lp then continue end
		if not LZY_Character_PlayerShouldBuildClientModels(ply) then continue end
		local data = playersModels and playersModels[ply]
		if not data or not data.body_model then continue end
		if LZY_IsLarvaCharacter(ply, data) then continue end
		if data.hair_model or LZY_Character_DataHasTattoo(data) then
			LZY_RefreshEntityFaceMaterials(ply, data)
		end
	end
	hook.Run("LZY_Character:RefreshPanelFaceMaterials")
	hook.Run("LZY_Character:RepairPanelModels")
end

function LZY_Character_RefreshLocalPlayerFaceAndPanels()
	LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = true })
end

local _lzy_spawnFaceSettleGen = 0
local function LZY_Character_ScheduleSpawnFaceSettle(ply)
	if not IsValid(ply) or ply ~= LocalPlayer() then return end
	_lzy_spawnFaceSettleGen = _lzy_spawnFaceSettleGen + 1
	local gen = _lzy_spawnFaceSettleGen
	local function settle(invalidate)
		if gen ~= _lzy_spawnFaceSettleGen then return end
		if not IsValid(ply) or ply ~= LocalPlayer() then return end
		if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
		local data = playersModels and playersModels[ply]
		if not data or not data.body_model then return end
		if LZY_IsLarvaCharacter(ply, data) then return end
		LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = invalidate ~= false })
	end
	timer.Simple(1.0, function() settle(true) end)
	timer.Simple(2.5, function() settle(true) end)
end

local _lzy_lastFocusRestore = 0
local function LZY_Character_OnVideoMemoryOrFocusRestore()
	local now = SysTime()
	if now - _lzy_lastFocusRestore < 0.2 then return end
	_lzy_lastFocusRestore = now
	LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = true })
	timer.Simple(0.15, function()
		LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = false })
	end)
	timer.Simple(0.5, function()
		LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = true })
	end)
end

local function PartsNeedRebuild(ent)
	if LZY_IsLarvaCharacter(ent) then
		return ent.PlayerModelParts ~= nil
	end
	local p = ent.PlayerModelParts
	if not p then return true end
	if not IsValid(p.body) then return true end
	if isentity(p.hair) and not IsValid(p.hair) then return true end
	if isentity(p.beard) and not IsValid(p.beard) then return true end
	if isentity(p.mustache) and not IsValid(p.mustache) then return true end
	if istable(p.accessories) then
		for i = 1, #p.accessories do
			if not IsValid(p.accessories[i]) then return true end
		end
	end
	return false
end

function LZY_Character_PlayerNeedsModelRepair(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("NCM_TF_Active", false) then return false end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("NCM_IsAssassinInvisible", false) then return false end
	local data = playersModels and playersModels[ply]
	if not data or not data.body_model then return false end
	if LZY_IsRawBodyModel(data.body_model) and not LZY_IsLarvaCharacter(ply, data) then
		local bAnim = ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_AnimatorHollow", false)
		local nwRaw = ply.GetEvoNWBool and (ply:GetEvoNWBool("EVO_HollowRaw", false) or ply:GetEvoNWBool("EVO_IsLarva", false))
		if not bAnim and not nwRaw then
			return true
		end
	end
	if LZY_IsLarvaCharacter(ply, data) then
		if ply.RenderOverride ~= ply._lzyCompositeRenderOverride then return true end
		return PartsNeedRebuild(ply)
	end
	if not LZY_Character_FaceModelMatches(ply, data)
		and not LZY_Character_IsKnownFaceModel(ply) then
		return false
	end
	if not ply.PlayerModelParts or ply.RenderOverride ~= ply._lzyCompositeRenderOverride then return true end
	return PartsNeedRebuild(ply)
end

local _lzyRepairQueue = {}
local _lzyRepairBusyUntil = 0
local LZY_REPAIR_GAP = 0.05
local LZY_REPAIR_GAP_BURST = 0.03
local _lzyPendingRepairWhileLoading = nil
local _lzyRepairBurstLeft = 0

local function LZY_Character_EnqueueRepairAllClientModels(opts)
	opts = opts or {}
	local localPly = LocalPlayer()
	if not IsValid(localPly) or not LZY_CHARACTER_CONFIG then return end
	LZY_Character_UpdateDetailBudgetTags(localPly)
	local q = {}
	if localPly:Alive() then
		q[#q + 1] = { ply = localPly, opts = opts }
	end
	local origin = localPly:GetPos()
	local radiusSqr = LZY_Character_InterestRadiusSqr and LZY_Character_InterestRadiusSqr() or (4000 * 4000)
	local near, far = {}, {}
	for _, ply in player.Iterator() do
		if IsValid(ply) and ply:Alive() and ply ~= localPly then
			if ply:GetPos():DistToSqr(origin) <= radiusSqr then
				near[#near + 1] = ply
			else
				far[#far + 1] = ply
			end
		end
	end
	for i = 1, #near do q[#q + 1] = { ply = near[i], opts = opts } end
	for i = 1, #far do q[#q + 1] = { ply = far[i], opts = opts } end
	_lzyRepairQueue = q
	_lzyRepairBurstLeft = math.min(#q, 16)
end

hook.Add("Think", "LZY:Character:RepairModelQueue", function()
	if #_lzyRepairQueue == 0 then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
	if CurTime() < _lzyRepairBusyUntil then return end
	local item = table.remove(_lzyRepairQueue, 1)
	if not item or not IsValid(item.ply) then return end
	local gap = LZY_REPAIR_GAP
	if _lzyRepairBurstLeft > 0 then
		gap = LZY_REPAIR_GAP_BURST
		_lzyRepairBurstLeft = _lzyRepairBurstLeft - 1
	end
	_lzyRepairBusyUntil = CurTime() + gap
	LZY_Character_SyncPlayerClientModels(item.ply, item.opts)
	if #_lzyRepairQueue == 0 then
		hook.Run("LZY_Character:RefreshPanelFaceMaterials")
		hook.Run("LZY_Character:RepairPanelModels")
	end
end)

function LZY_Character_RepairAllClientModels(opts)
	opts = opts or {}
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		_lzyPendingRepairWhileLoading = opts
		return
	end
	LZY_Character_EnqueueRepairAllClientModels(opts)
end

local function LZY_Character_UnstickLocalCamera(lp)
	if not IsValid(lp) then return end
	if rawget(_G, "IsFreeCamActive") and IsFreeCamActive() then return end
	if EvoHealBed and EvoHealBed.IsOperationOpen and EvoHealBed.IsOperationOpen() then return end
	lp.ActiveCamera = true
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = false end
end

local _lzyManualPMRefreshAt = 0
local LZY_MANUAL_PM_REFRESH_CD = 8
function LZY_Character_ManualRefreshPlayerModels()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		chat.AddText(Color(255, 180, 80), "[Apparence] ", color_white, "Attends la fin du chargement.")
		return false
	end
	if LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu() then
		chat.AddText(Color(255, 180, 80), "[Apparence] ", color_white, "Indisponible dans le menu personnage.")
		return false
	end
	local now = CurTime()
	if now < _lzyManualPMRefreshAt then
		chat.AddText(Color(255, 180, 80), "[Apparence] ", color_white,
			"Patiente " .. tostring(math.ceil(_lzyManualPMRefreshAt - now)) .. "s.")
		return false
	end
	_lzyManualPMRefreshAt = now + LZY_MANUAL_PM_REFRESH_CD

	net.Start("EVO:Server:CharacterCreator:RefreshPM")
	net.SendToServer()

	if LZY_Character_VisibilityUnstick then LZY_Character_VisibilityUnstick() end

	_lzyWantFlushScheduled = false
	timer.Remove("LZY:Character:WantSetFlush")
	LZY_Character_WantScanMissingPM({ force = true })
	if LZY_Character_FlushWantSet then
		LZY_Character_FlushWantSet()
	end
	LZY_Character_RecoverLocalPlayerModelAfterLoading()
	LZY_Character_RepairAllClientModels({ forceRebuild = true })
	LZY_Character_UnstickLocalCamera(lp)
	chat.AddText(Color(120, 200, 120), "[Apparence] ", color_white, "Rafraîchissement des modèles…")
	return true
end

hook.Add("EVO:Client:LoadingScreenClosed", "LZY:Character:RepairAfterLoading", function()
	local pending = _lzyPendingRepairWhileLoading
	local blocked = _lzyBuildsBlockedByLoading
	_lzyPendingRepairWhileLoading = nil
	_lzyBuildsBlockedByLoading = false
	timer.Simple(0, function()
		local lp = LocalPlayer()
		if (EVO_HollowProg and (EVO_HollowProg._Finalizing or EVO_HollowProg._FinalizePending))
			or (LZY_IsCharacterCreatorOpen and LZY_IsCharacterCreatorOpen())
			or (NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive())
			or LZY_Character_IsLocalInCharMenu() then
			return
		end
		_lzyWantFlushScheduled = false
		timer.Remove("LZY:Character:WantSetFlush")
		LZY_Character_WantScanMissingPM({ force = true })
		LZY_Character_FlushWantSet()
		LZY_Character_RecoverLocalPlayerModelAfterLoading()
		if pending or blocked then
			LZY_Character_EnqueueRepairAllClientModels(pending or { forceRebuild = true })
		else
			LZY_Character_EnqueueRepairAllClientModels({ forceRebuild = true })
		end
	end)
	local retryDelays = { 0.75, 2, 5, 10, 20, 40 }

	local retryGen = (_lzyPostLoadSyncGen or 0) + 1
	_lzyPostLoadSyncGen = retryGen
	for i = 1, #retryDelays do
		local delay = retryDelays[i]
		timer.Simple(delay, function()
			if retryGen ~= _lzyPostLoadSyncGen then return end
			local lp = LocalPlayer()
			if not IsValid(lp) then return end
			if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
			if (EVO_HollowProg and (EVO_HollowProg._Finalizing or EVO_HollowProg._FinalizePending))
				or (LZY_IsCharacterCreatorOpen and LZY_IsCharacterCreatorOpen())
				or (NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive())
				or LZY_Character_IsLocalInCharMenu() then
				return
			end
			if not LZY_Character_AnyAlivePlayerMissingModelData(lp) then
				LZY_Character_RecoverLocalPlayerModelAfterLoading()
				return
			end
			LZY_Character_WantScanMissingPM({ force = true })
			timer.Simple(0.75, function()
				if retryGen ~= _lzyPostLoadSyncGen then return end
				if not IsValid(LocalPlayer()) then return end
				LZY_Character_RecoverLocalPlayerModelAfterLoading()
				LZY_Character_RepairAllClientModels({ forceRebuild = true })
			end)
		end)
	end
end)

local _lzy_clientModelRepairGen = 0
function LZY_Character_ScheduleClientModelRepairs(opts)
	opts = opts or {}
	_lzy_clientModelRepairGen = _lzy_clientModelRepairGen + 1
	local gen = _lzy_clientModelRepairGen
	local function runRefreshOnly()
		if gen ~= _lzy_clientModelRepairGen then return end
		LZY_Character_RefreshAllPlayerFaceMaterials({ invalidateCaches = true })
		for _, ply in player.Iterator() do
			if not IsValid(ply) or not ply:Alive() then continue end
			if not LZY_Character_PlayerShouldBuildClientModels(ply) then continue end
			if LZY_Character_PlayerNeedsModelRepair(ply) then
				LZY_Character_SyncPlayerClientModels(ply)
			end
		end
	end
	local function runFull()
		if gen ~= _lzy_clientModelRepairGen then return end
		LZY_InvalidateFaceRenderCaches()
		LZY_Character_RepairAllClientModels({ forceRebuild = opts.forceRebuild == true })
	end
	if opts.forceRebuild then
		runFull()
		for _, delay in ipairs({ 0.5, 2, 5 }) do
			timer.Simple(delay, runRefreshOnly)
		end
	else
		runRefreshOnly()
		timer.Simple(0.5, runRefreshOnly)
	end
end

local function LZY_Character_SweepOrphanParts(removedEnt)
	local ownerSid = (IsValid(removedEnt) and removedEnt:IsPlayer()) and removedEnt:SteamID64() or nil
	for part in pairs(trackedParts) do
		if not IsValid(part) then
			trackedParts[part] = nil
		elseif (ownerSid and part.owner_steamid64 == ownerSid)
			or (IsValid(removedEnt) and part:GetParent() == removedEnt) then
			trackedParts[part] = nil
			SafeRemoveEntity(part)
			local owner = part.owner_steamid64 and LZY_Character_FindPlayerBySteamID64(part.owner_steamid64)
			if IsValid(owner) and playersModels[owner] then
				timer.Simple(0, function()
					LZY_Character_SyncPlayerClientModels(owner)
				end)
			end
		end
	end
end

function GetPlayerCharacterData(ply)
    return playersModels and playersModels[ply] or nil
end

function GetPlayerDisplayCharacterData(ply)
    local data = GetPlayerCharacterData(ply)
    if not data then return data end

    local disp
    if LZY_Character_GetDisplayBodyModel then
        disp = LZY_Character_GetDisplayBodyModel(data, ply)
        if not isstring(disp) or disp == "" or disp == data.body_model then
            disp = nil
        end
    end

    local liveFac, liveRank, liveDiv, rankChg
    if IsValid(ply) then
        liveFac = ply:GetEvoNWString("FactionName", "") or ""
        liveRank = tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0
        liveDiv = tonumber(ply:GetEvoNWInt("FactionDivision", 0)) or 0
        rankChg = liveFac ~= tostring(data.faction or "")
            or liveRank ~= (tonumber(data.rank) or 0)
            or liveDiv ~= (tonumber(data.division) or 0)
    end

    if not disp and not rankChg then return data end
    local cd = {}
    for k, v in pairs(data) do cd[k] = v end
    if disp then cd.body_model = disp end
    if rankChg then
        cd.faction = liveFac
        cd.rank = liveRank
        cd.division = liveDiv
    end
    return cd
end

function LZY_RefreshEntityFaceMaterials(ent, characterData)
	if not IsValid(ent) or not characterData then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		LZY_Character_NoteBuildBlockedByLoading()
		return
	end
	if LZY_IsLarvaCharacter(ent, characterData) then return end
	if LZY_IsRawBodyModel(characterData.body_model) then return end
	if LZY_IsRawBodyModel(ent:GetModel()) then return end
	if not LZY_Character_FaceModelMatches(ent, characterData) then return end

	LZY_Character_ApplyFaceAppearanceFromData(ent, characterData)
	LZY_ApplyTattooFromCharacterData(ent, characterData)
	local tParts = ent.PlayerModelParts
	if tParts and IsValid(tParts.body) then
		LZY_ApplyBodyTattoo(tParts.body, characterData, "w" .. ent:EntIndex(), LZY_Character_TattooMaxAxisForEntity(ent))
	end

	if characterData.hair_color1 and characterData.hair_color2 then
		local details = normalizeHairDetailsColor(characterData.hair_details_color)
		local angle = characterData.hair_gradient_angle or 0
		local parts = ent.PlayerModelParts
		ApplyHairGradientToWorldPlayer(ent, nil, characterData.hair_color1, characterData.hair_color2, angle, details)
		if parts and IsValid(parts.hair) then
			if parts.hair._lzyHairLod == "cheap" then
				ApplyCheapHairToWorldPlayer(ent, parts.hair, characterData.hair_color1, characterData.hair_color2)
			else
				ApplyHairGradientToWorldPlayer(ent, parts.hair, characterData.hair_color1, characterData.hair_color2, angle, details)
			end
		end
		if parts and IsValid(parts.beard) then
			ApplyHairGradientToWorldPlayer(ent, parts.beard, characterData.hair_color1, characterData.hair_color2, angle, details)
		end
		if parts and IsValid(parts.mustache) then
			ApplyHairGradientToWorldPlayer(ent, parts.mustache, characterData.hair_color1, characterData.hair_color2, angle, details)
		end
	end
end

local _lzyBotModelQueue = {}
local _lzyBotModelBusyUntil = 0
local LZY_BOT_MODEL_GAP = 0.45

function LZY_Character_EnqueueBotClientModel(ply)
	if not IsValid(ply) then return end
	for i = 1, #_lzyBotModelQueue do
		if _lzyBotModelQueue[i] == ply then return end
	end
	_lzyBotModelQueue[#_lzyBotModelQueue + 1] = ply
end

hook.Add("Think", "LZY:Character:BotModelQueue", function()
	if #_lzyBotModelQueue == 0 then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
	if CurTime() < _lzyBotModelBusyUntil then return end
	local ply = table.remove(_lzyBotModelQueue, 1)
	if not IsValid(ply) then return end
	local data = playersModels and playersModels[ply]
	if not data or not data.body_model then return end
	_lzyBotModelBusyUntil = CurTime() + LZY_BOT_MODEL_GAP
	if isstring(data.body_model) then util.PrecacheModel(data.body_model) end
	if isstring(data.hair_model) then util.PrecacheModel(data.hair_model) end
	LZY_Character_TryCreatePlayerClientModels(ply, data)
end)

net.Receive("EVO:Client:CharacterCreator:CreateClientSideModel", function()
	local ply = net.ReadPlayer()
	local sid = net.ReadString()
	local characterData = net.ReadTable()
	if not istable(characterData) then return end
	characterData._lzyFromCsm = true
	if not IsValid(ply) and sid ~= "" then
		ply = LZY_Character_FindPlayerBySteamID64(sid)
	end
	if not IsValid(ply) then
		if sid ~= "" then
			local existingPending = _lzyPendingModelsBySteamID64[sid]
			if LZY_Character_IncomingIsFresher(existingPending, characterData) then
				_lzyPendingModelsBySteamID64[sid] = characterData
			end
		end
		return
	end
	if LZY_Character_IncomingIsFresher(playersModels[ply], characterData) then
		playersModels[ply] = characterData
	end
	_lzyPendingModelsBySteamID64[ply:SteamID64() or sid] = nil
	if LZY_Character_ApplyModelScale then
		LZY_Character_ApplyModelScale(ply, characterData)
	end
	local netKey = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ply)) or ply:SteamID64() or sid
	if netKey and netKey ~= "" then
		_lzyWantRevProbed[netKey] = nil
		_lzyWantInFlightUntil[netKey] = nil
	end
	if ply == LocalPlayer() and characterData.body_model and LZY_Character_MarkLoadingReadyFlag then
		LZY_Character_MarkLoadingReadyFlag("own")
	end
	if ply ~= LocalPlayer() and LZY_PlyState_RequestAppearanceResync then
		local bag = LZY_RemoteState and LZY_RemoteState[ply:EntIndex()]
		local hasUid = bag and bag.ent == ply and bag.values and bag.values["Character::Unique::ID"] ~= nil
		if not hasUid then
			LZY_PlyState_RequestAppearanceResync(ply)
		end
	end
	if characterData._lzyLightBot or (ply.IsBot and ply:IsBot()) then
		LZY_Character_EnqueueBotClientModel(ply)
		return
	end
	local token = (ply._lzyPendingCsmBuild or 0) + 1
	ply._lzyPendingCsmBuild = token
	local function runBuild()
		if not IsValid(ply) or ply._lzyPendingCsmBuild ~= token then return end
		ply._lzyPendingCsmBuild = nil
		local data = playersModels and playersModels[ply]
		if not data then return end
		LZY_Character_TryCreatePlayerClientModels(ply, data)
		if ply == LocalPlayer() then
			if ply.HUD_UpdatePlayerModel then ply:HUD_UpdatePlayerModel() end
			local isLarva = LZY_IsLarvaCharacter(ply, data)
			if isLarva and LZY_Character_ScheduleClientModelRepairs then
				LZY_Character_ScheduleClientModelRepairs({ forceRebuild = true })
			elseif not isLarva then
				LZY_Character_ScheduleSpawnFaceSettle(ply)
			end
		end
	end
	if LZY_IsLarvaCharacter(ply, characterData) then
		timer.Simple(0, runBuild)
		return
	end
	local localBuildDelay = 0
	local loadingOpen = LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen()
	if ply == LocalPlayer() and loadingOpen then
		local hid = "LZY:CsmAfterLoading:" .. tostring(ply:EntIndex())
		hook.Add("EVO:Client:LoadingScreenClosed", hid, function()
			hook.Remove("EVO:Client:LoadingScreenClosed", hid)
			timer.Simple(0, runBuild)
		end)
	else
		timer.Simple(localBuildDelay, runBuild)
	end
end)

local function LZY_Character_OnHollowExit(ent, name, _, newVal)
	if name ~= "EVO_HollowRaw" or newVal ~= false then return end
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return end
	local function reapply()
		if not IsValid(ent) then return end
		if ent:GetEvoNWBool("EVO_HollowRaw", false) or ent:GetEvoNWBool("EVO_IsLarva", false) then return end

		if LZY_Character_InHubOrFinalizeFlow(ent) then
			local data = playersModels and playersModels[ent]
			if data and LZY_IsRawBodyModel(data.body_model) then
				playersModels[ent] = nil
			end
			if LZY_Character_DestroyPlayerClientModels then
				LZY_Character_DestroyPlayerClientModels(ent)
			else
				ent.RenderOverride = nil
			end
			return
		end

		if ent == LocalPlayer() and LZY_IsRawBodyModel(ent:GetModel() or "") then
			local data = playersModels and playersModels[ent]
			if data and LZY_IsRawBodyModel(data.body_model) then
				playersModels[ent] = nil
			end
			if LZY_Character_DestroyPlayerClientModels then
				LZY_Character_DestroyPlayerClientModels(ent)
			else
				ent.RenderOverride = nil
			end
			return
		end

		local data = playersModels and playersModels[ent]
		if data and LZY_IsRawBodyModel(data.body_model)
			and not LZY_IsRawBodyModel(ent:GetModel() or "") then
			playersModels[ent] = nil
			data = nil
		end
		if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ent) then
			return
		end
		if LZY_IsLarvaCharacter(ent) then return end
		if not data then
			data = playersModels and playersModels[ent]
		end
		if not data then return end
		if LZY_Character_TryCreatePlayerClientModels then LZY_Character_TryCreatePlayerClientModels(ent, data) end
		if LZY_RefreshEntityFaceMaterials then LZY_RefreshEntityFaceMaterials(ent, data) end
	end
	timer.Simple(0, reapply)
	timer.Simple(0.2, reapply)
	timer.Simple(0.5, reapply)
end
hook.Add("EVO:Appearance:Changed", "LZY:Character:HollowExitFaceFix", LZY_Character_OnHollowExit)
hook.Add("LZY:PlyState:Changed", "LZY:Character:HollowExitFaceFixLocal", LZY_Character_OnHollowExit)

local function LZY_Character_OnRankOutfitStateChanged(ent, name, oldVal, newVal)
	if name ~= "FactionRank" and name ~= "FactionDivision" and name ~= "FactionName" then return end
	if oldVal == newVal then return end
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return end
	if LZY_Character_InHubOrFinalizeFlow(ent) then return end
	local data = playersModels and playersModels[ent]
	if not data then return end
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ent, data) then return end
	if ent._lzyRankOutfitPending then return end
	ent._lzyRankOutfitPending = true
	timer.Simple(0, function()
		if not IsValid(ent) then return end
		ent._lzyRankOutfitPending = nil
		if LZY_Character_InHubOrFinalizeFlow(ent) then return end
		local d = playersModels and playersModels[ent]
		if not d then return end
		d.faction = ent:GetEvoNWString("FactionName", "") or ""
		d.rank = tonumber(ent:GetEvoNWInt("FactionRank", 0)) or 0
		d.division = tonumber(ent:GetEvoNWInt("FactionDivision", 0)) or 0
		if LZY_Character_TryCreatePlayerClientModels then
			LZY_Character_TryCreatePlayerClientModels(ent, d)
		end
	end)
end
hook.Add("EVO:Appearance:Changed", "LZY:Character:RankOutfitRefresh", LZY_Character_OnRankOutfitStateChanged)
hook.Add("LZY:PlyState:Changed", "LZY:Character:RankOutfitRefreshLocal", LZY_Character_OnRankOutfitStateChanged)

hook.Add("EVO:Appearance:Changed", "LZY:Character:AppearanceRefresh", function(ent, name, oldVal, newVal)
	if (name ~= "EVO_HideEpaulette" and name ~= "EVO_HideRankOutfit") or oldVal == newVal then return end
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return end
	if LZY_Character_InHubOrFinalizeFlow(ent) then return end
	local data = playersModels and playersModels[ent]
	if data and LZY_Character_TryCreatePlayerClientModels then
		LZY_Character_TryCreatePlayerClientModels(ent, data)
	end
end)
hook.Add("LZY:PlyState:Changed", "LZY:Character:AppearanceRefreshLocal", function(ent, name, oldVal, newVal)
	if (name ~= "EVO_HideEpaulette" and name ~= "EVO_HideRankOutfit") or oldVal == newVal then return end
	if not (IsValid(ent) and ent.IsPlayer and ent:IsPlayer()) then return end
	if LZY_Character_InHubOrFinalizeFlow(ent) then return end
	local data = playersModels and playersModels[ent]
	if data and LZY_Character_TryCreatePlayerClientModels then
		LZY_Character_TryCreatePlayerClientModels(ent, data)
	end
end)

net.Receive("EVO:Client:CharacterCreator:GetPMBatch", function()
	local n = net.ReadUInt(8)
	local batch = net.ReadTable() or {}
	LZY_Character_ApplyIncomingPlayerModels(batch)

	local lp = LocalPlayer()
	local ownKey = IsValid(lp) and LZY_Character_NetKeyFor(lp) or nil
	if ownKey and batch[ownKey] and LZY_Character_TryAckSpawnLoadingReady then
		LZY_Character_TryAckSpawnLoadingReady()
	end

	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then
		LZY_Character_NoteBuildBlockedByLoading()
		return
	end
	timer.Simple(0, function()
		for key in pairs(batch) do
			local ply = LZY_Character_FindPlayerBySteamID64(tostring(key))
			if IsValid(ply) then
				LZY_Character_DeferPlayerModelBuild(ply)
				if ply == LocalPlayer() and ply.HUD_UpdatePlayerModel then
					ply:HUD_UpdatePlayerModel()
				end
			end
		end
	end)
end)

concommand.Add("evo_uniform_dbg", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then return end
	local function P(s) MsgC(Color(120, 200, 255), "[uniform] ", color_white, s, "\n") end
	P(string.format("NWVar  : Faction='%s'  Rank=%d  Div=%d",
		lp:GetEvoNWString("FactionName", ""), lp:GetEvoNWInt("FactionRank", 0), lp:GetEvoNWInt("FactionDivision", 0)))
	local data = (GetPlayerCharacterData and GetPlayerCharacterData(lp)) or nil
	if not data then P("playersModels[lp] = NIL"); return end
	P(string.format("DATA   : gender=%s  body=%s", tostring(data.gender), tostring(data.body_model)))
	P(string.format("DATA   : base=%s", tostring(data.base_body_model)))
	P(string.format("SKIN   : data.skin_color=%s   <->   monde lp:GetSkin()=%s   %s",
		tostring(data.skin_color), tostring(lp:GetSkin()),
		(tostring(tonumber(data.skin_color) or -1) == tostring(lp:GetSkin())) and "(OK)" or "(DIVERGENT -> HUD/inv perimes)"))
	P(string.format("DATA   : rank=%s  division=%s  faction=%s",
		tostring(data.rank), tostring(data.division), tostring(data.faction)))
	local viaNW = LZY_Character_GetDisplayBodyModel and LZY_Character_GetDisplayBodyModel(data, lp)
	local viaData = LZY_Character_GetDisplayBodyModelFromData and LZY_Character_GetDisplayBodyModelFromData(data)
	P("via NWVar  (monde + HUD/inv display) = " .. tostring(viaNW))
	P("via DATA   (cle de cache ComputeBuildSig) = " .. tostring(viaData))
	local disp = GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(lp)
	P("GetPlayerDisplayCharacterData().body = " .. tostring(disp and disp.body_model))
	P((tostring(viaNW) == tostring(viaData)) and "=> NW == DATA (cache coherent)"
		or "=> NW != DATA : la cle de cache (DATA) diverge de l'affichage (NWVar) -> HUD/inv figes")
end)

local function LZY_Crowd_Msg(msg)
	MsgC(Color(255, 180, 80), "[lzy_crowd] ", color_white, msg, "\n")
end

local function LZY_Crowd_Pick(tbl)
	if not istable(tbl) or #tbl == 0 then return nil end
	return tbl[math.random(1, #tbl)]
end

local function LZY_Crowd_RandColor()
	return Color(math.random(0, 255), math.random(0, 255), math.random(0, 255))
end

local _lzyCrowdPools = nil
local function LZY_Crowd_GetPools()
	if _lzyCrowdPools then return _lzyCrowdPools end

	local outfitsM, outfitsF, accessories = {}, {}, {}
	local function addOutfit(path, genderHint)
		if not isstring(path) or path == "" then return end
		if LZY_IsRawBodyModel and LZY_IsRawBodyModel(path) then return end
		local low = string.lower(path)
		if genderHint == "f" or string.find(low, "/female/", 1, true) then
			outfitsF[#outfitsF + 1] = path
		elseif genderHint == "m" or string.find(low, "/male/", 1, true) then
			outfitsM[#outfitsM + 1] = path
		else
			outfitsM[#outfitsM + 1] = path
			outfitsF[#outfitsF + 1] = path
		end
	end

	local dm = LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE
	if istable(dm) then for _, p in pairs(dm) do addOutfit(p, "m") end end
	local df = LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_FEMALE
	if istable(df) then for _, p in pairs(df) do addOutfit(p, "f") end end
	for _, p in ipairs(LZY_CHARACTER_CONFIG.SHINIGAMI_ACADEMY_BASE_MODELS or {}) do addOutfit(p, "m") end
	for _, p in ipairs(LZY_CHARACTER_CONFIG.SHINIGAMI_ACADEMY_BASE_MODELS_FEMALE or {}) do addOutfit(p, "f") end

	if istable(ITEMS) then
		for _, it in pairs(ITEMS) do
			if not istable(it) or not isstring(it.model_path) or it.model_path == "" then continue end
			if it.category == "outfit" then
				addOutfit(it.model_path, nil)
			elseif it.category == "accessory" and not it.always_visible then -- always_visible = cosmétique staff, jamais sur un figurant
				accessories[#accessories + 1] = {
					path = it.model_path,
					skin = tonumber(it.skin) or 0,
				}
			end
		end
	end

	_lzyCrowdPools = {
		outfitsM = outfitsM,
		outfitsF = outfitsF,
		accessories = accessories,
		tattoos = LZY_CHARACTER_CONFIG.GetRandomTattooPool and LZY_CHARACTER_CONFIG.GetRandomTattooPool() or (LZY_CHARACTER_CONFIG.AVAILABLE_TATOO_TEXTURES or {}),
	}
	return _lzyCrowdPools
end

local function LZY_Crowd_HairStyles(gender)
	if LZY_CHARACTER_CONFIG.GetAvailableHairStyles then
		local styles = LZY_CHARACTER_CONFIG.GetAvailableHairStyles(gender)
		if istable(styles) and #styles > 0 then return styles end
	end
	local norm = LZY_CHARACTER_CONFIG.NormalizeGender and LZY_CHARACTER_CONFIG.NormalizeGender(gender) or gender
	if norm == "female" or gender == "f" then
		return LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_FEMALE or {}
	end
	return LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_MALE or {}
end

local function LZY_Crowd_RandomCharacter()
	local pools = LZY_Crowd_GetPools()
	local female = math.random() < 0.5
	local gender = female and "f" or "m"
	local outfits = female and pools.outfitsF or pools.outfitsM
	if #outfits == 0 then outfits = pools.outfitsM end

	local body = LZY_Crowd_Pick(outfits)
		or (LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE and LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE["Shinigami"])
	local hairEntry = LZY_Crowd_Pick(LZY_Crowd_HairStyles(gender))
	local hairModel = (hairEntry and hairEntry.model)
		or (female and LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_FEMALE or LZY_CHARACTER_CONFIG.DISABLED_HAIR_MODEL_MALE)

	local skin = 0
	if LZY_CHARACTER_CONFIG.GetSkinColorsForFaction then
		local skins = LZY_CHARACTER_CONFIG.GetSkinColorsForFaction(nil)
		local sk = LZY_Crowd_Pick(skins)
		if sk then skin = tonumber(sk.id) or 0 end
	else
		skin = math.random(0, 9)
	end

	local data = {
		gender = gender,
		skin_color = skin,
		scale = math.Round(0.9 + math.random() * 0.2, 2),
		body_model = body,
		base_body_model = body,
		hair_model = hairModel,
		hair_color1 = LZY_Crowd_RandColor(),
		hair_color2 = LZY_Crowd_RandColor(),
		hair_details_color = LZY_Crowd_RandColor(),
		hair_gradient_angle = math.random(0, 360),
		hide_hair = 0,
		beard_model = "",
		mustache_model = "",
		equipped_accessories = {},
		equipped_accessory_skins = {},
	}

	-- Faction, division et grade au hasard, lus par LZY_Character_GetRankIdentity :
	-- ils donnent epaulette, brassard, tenue de division, haori, corps d'Espada ou
	-- masque, comme sur un vrai joueur. Grades 1 a 16 : quelques capitaines par foule.
	data.faction = (math.random() < 0.6) and "Shinigami" or "Hollow"
	local divs = LZY_FACTION_CONFIG and istable(LZY_FACTION_CONFIG.divisions) and LZY_FACTION_CONFIG.divisions[data.faction]
	data.division = math.random(1, (istable(divs) and #divs > 0) and #divs or 6)
	data.rank = math.random(1, 16)

	if not female then
		local beard = LZY_Crowd_Pick(LZY_CHARACTER_CONFIG.AVAILABLE_BEARD_STYLES)
		if beard and not beard.none and isstring(beard.model) then
			data.beard_model = beard.model
		end
		local mustache = LZY_Crowd_Pick(LZY_CHARACTER_CONFIG.AVAILABLE_MUSTACHE_STYLES)
		if mustache and not mustache.none and isstring(mustache.model) then
			data.mustache_model = mustache.model
		end
	end

	local accPool = pools.accessories
	if #accPool > 0 then
		local slots = { 1, 3, 4, 5, 6 }
		for i = #slots, 2, -1 do
			local j = math.random(i)
			slots[i], slots[j] = slots[j], slots[i]
		end
		local nAcc = math.random(0, math.min(3, #accPool, #slots))
		for i = 1, nAcc do
			local pick = LZY_Crowd_Pick(accPool)
			if pick then
				local slotKey = tostring(slots[i])
				data.equipped_accessories[slotKey] = pick.path
				data.equipped_accessory_skins[slotKey] = pick.skin
			end
		end
	end

	if #pools.tattoos > 0 and math.random() < 0.4 then
		local tex = LZY_Crowd_Pick(pools.tattoos)
		if isstring(tex) and tex ~= "" then
			data.tattoo_texture = tex
			data.tattoo_color = LZY_Crowd_RandColor()
			data.tattoo_opacity = 0.65 + math.random() * 0.35
			data.tattoo_pos_x = 0.4 + math.random() * 0.2
			data.tattoo_pos_y = 0.4 + math.random() * 0.2
			data.tattoo_scale_x = 0.7 + math.random() * 0.8
			data.tattoo_scale_y = 0.7 + math.random() * 0.8
			data.tattoo_rotation = math.random(0, 359)
		end
	end

	return data
end

local function LZY_Crowd_GroundPos(pos)
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 72),
		endpos = pos - Vector(0, 0, 512),
		mask = MASK_SOLID_BRUSHONLY,
	})
	if tr.Hit then return tr.HitPos end
	return pos
end

function LZY_Crowd_Clear()
	_lzyCrowdSpawnToken = _lzyCrowdSpawnToken + 1
	for i = 1, #_lzyCrowdDummies do
		local dum = _lzyCrowdDummies[i]
		if IsValid(dum) then
			playersModels[dum] = nil
			LZY_Character_DestroyPlayerClientModels(dum)
			SafeRemoveEntity(dum)
		end
	end
	_lzyCrowdDummies = {}
	LZY_Crowd_Msg("cleared")
end

local function LZY_Crowd_SpawnOne(origin, yawDeg, radius, forceHQ)
	local data = LZY_Crowd_RandomCharacter()
	if not data or not data.body_model or not data.hair_model then return nil end

	local yaw = Angle(0, yawDeg, 0)
	local pos = LZY_Crowd_GroundPos(origin + yaw:Forward() * radius)
	local facePath = (data.gender == "f" or data.gender == "female")
		and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE
		or LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE
	if LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
		facePath = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(data.gender) or facePath
	end
	if not isstring(facePath) or facePath == "" then return nil end

	local face = ClientsideModel(facePath, RENDERGROUP_OPAQUE)
	if not IsValid(face) then return nil end

	local look = (origin - pos):Angle()
	look.p = 0
	look.r = 0
	face:SetPos(pos)
	face:SetAngles(look)
	face:DrawShadow(false)
	if face.SetSkin then face:SetSkin(tonumber(data.skin_color) or 0) end
	local sc = tonumber(data.scale) or 1
	if sc ~= 1 and face.SetModelScale then face:SetModelScale(sc, 0) end

	local idle = (data.gender == "f" or data.gender == "female")
		and (LZY_CHARACTER_CONFIG.IDLE_ANIM_FEMALE or "idle_all_01")
		or (LZY_CHARACTER_CONFIG.IDLE_ANIM_MALE or "idle_all_01")
	local seq = face:LookupSequence(idle)
	if seq and seq >= 0 then
		face:ResetSequence(seq)
		face:SetCycle(math.Rand(0, 1))
	end

	face._lzyCrowdDummy = true
	face._lzyCrowdForceHQ = forceHQ == true
	playersModels[face] = data
	createPlayerClientSideModel(face, data)
	return face
end

concommand.Add("lzy_crowd_clear", function()
	LZY_Crowd_Clear()
end)

concommand.Add("lzy_crowd_spawn", function(_, _, args)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	local count = math.Clamp(math.floor(tonumber(args[1]) or 100), 1, 200)
	local radius = math.Clamp(tonumber(args[2]) or 350, 50, 4000)
	local forceHQ = false
	for i = 1, #args do
		local a = string.lower(tostring(args[i] or ""))
		if a == "full" or a == "hq" then
			forceHQ = true
			break
		end
	end

	LZY_Crowd_Clear()
	_lzyCrowdPools = nil

	local pools = LZY_Crowd_GetPools()
	if #(pools.outfitsM) + #(pools.outfitsF) == 0 then
		LZY_Crowd_Msg("no outfit models found — abort")
		return
	end

	local token = _lzyCrowdSpawnToken
	local origin = lp:GetPos()
	local batchSize = 5
	local spawned = 0

	LZY_Crowd_Msg(string.format(
		"spawning %d randomized @ radius %d%s (outfits M/F=%d/%d, acc=%d, tattoos=%d) …",
		count, radius, forceHQ and " (FORCE HQ)" or " (LOD on)",
		#pools.outfitsM, #pools.outfitsF, #pools.accessories, #pools.tattoos
	))

	local function spawnBatch(startIdx)
		if token ~= _lzyCrowdSpawnToken then return end
		local last = math.min(startIdx + batchSize - 1, count)
		for i = startIdx, last do
			local yaw = (i - 1) * (360 / count)
			local dum = LZY_Crowd_SpawnOne(origin, yaw, radius, forceHQ)
			if IsValid(dum) then
				_lzyCrowdDummies[#_lzyCrowdDummies + 1] = dum
				spawned = spawned + 1
			end
		end
		if last < count then
			timer.Simple(0, function() spawnBatch(last + 1) end)
		else
			LZY_Crowd_Msg(string.format("done — %d dummies (lzy_crowd_clear to remove)", spawned))
		end
	end

	spawnBatch(1)
end)

net.Receive("EVO:Client:CharacterCreator:RemoveClientSideModel", function()
    local ply = net.ReadPlayer()
    if not IsValid(ply) then return end
    playersModels[ply] = nil
	if ply:SteamID64() then
		_lzyPendingModelsBySteamID64[ply:SteamID64()] = nil
	end
    LZY_Character_DestroyPlayerClientModels(ply)
end)

hook.Add("OnScreenSizeChanged", "EVO:Client:PlayerClientSideModel:OnScreenSizeChanged", function()
	LZY_Character_ScheduleClientModelRepairs({ forceRebuild = true })
end)

timer.Remove("EVO:Client:PlayerClientSideModel:Repair")

hook.Add("OnGameFocusChanged", "EVO:Client:PlayerClientSideModel:OnGameFocus", function()
	LZY_Character_OnVideoMemoryOrFocusRestore()
end)

local _lzy_lastSystemFocus = system.HasFocus()
hook.Add("Think", "EVO:Client:PlayerClientSideModel:FocusWatch", function()
	local has = system.HasFocus()
	if has == _lzy_lastSystemFocus then return end
	_lzy_lastSystemFocus = has
	LZY_Character_OnVideoMemoryOrFocusRestore()
end)

hook.Add("GRubTextureRestore", "EVO:Client:PlayerClientSideModel:TextureRestore", function()
	LZY_Character_OnVideoMemoryOrFocusRestore()
end)

hook.Add("InitPostEntity", "EVO:Client:PlayerClientSideModel:InitPostEntity", function()
	local function resync(delay)
		timer.Simple(delay, function()
			local lp = LocalPlayer()
			if not IsValid(lp) then return end
			if (LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen())
				or LZY_Character_IsLocalInCharMenu() then
				return
			end
			LZY_Character_WantScanMissingPM()
			timer.Simple(0.15, function()
				if not IsValid(LocalPlayer()) then return end
				if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
				LZY_Character_UpdateDetailBudgetTags()
				LZY_Character_RepairAllClientModels({ forceRebuild = true })
			end)
		end)
	end
	resync(0)
	resync(2)
	resync(6)
end)

hook.Add("LZY:Optimisations:SettingsApplied", "EVO:Client:PlayerClientSideModel:DistancesChanged", function()
	timer.Simple(0, function()
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
		LZY_Character_WantScanMissingPM()
	end)
end)

hook.Add("OnReloaded", "EVO:Client:PlayerClientSideModel:OnReloaded", function()
	LZY_Character_ScheduleClientModelRepairs({ forceRebuild = true })
end)

hook.Add("PlayerSpawn", "EVO:Client:PlayerClientSideModel:PlayerSpawn", function(ply)
	timer.Simple(0, function()
		if not IsValid(ply) then return end
		LZY_Character_SyncPlayerClientModels(ply)
		if ply == LocalPlayer() then
			if ply.HUD_UpdatePlayerModel then ply:HUD_UpdatePlayerModel() end
			local data = playersModels and playersModels[ply]
			if data and not LZY_IsLarvaCharacter(ply, data) then
				LZY_Character_ScheduleFaceAppearanceRefresh(ply, data)
			end
			timer.Simple(0.25, function()
				if not IsValid(LocalPlayer()) or LocalPlayer() ~= ply then return end
				LZY_Character_UpdateDetailBudgetTags()
				if LZY_Character_AnyAlivePlayerMissingModelData(ply) then
					LZY_Character_WantScanMissingPM()
				end
				LZY_Character_RepairAllClientModels({ forceRebuild = true })
			end)
		end
	end)
end)

hook.Add("NetworkEntityCreated", "EVO:Client:PlayerClientSideModel:NetworkEntityCreated", function(ent)
	if not IsValid(ent) or not ent:IsPlayer() then return end
	timer.Simple(0, function()
		if not IsValid(ent) then return end
		LZY_Character_TryApplyPendingModelForPlayer(ent)
		LZY_Character_DeferPlayerModelBuild(ent)
	end)
end)

hook.Add("EntityRemoved", "EVO:Client:PlayerClientSideModel:EntityRemoved", function(ent)
	LZY_Character_SweepOrphanParts(ent)
	if not IsValid(ent) or not ent:IsPlayer() then return end
	local key = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ent)) or ent:SteamID64()
	playersModels[ent] = nil
	if isstring(key) and key ~= "" then
		_lzyPendingModelsBySteamID64[key] = nil
		LZY_Character_WantSetForget(key)
		_lzyWantRevProbed[key] = nil
	end
	LZY_Character_DestroyPlayerClientModels(ent)
end)

local function LZY_Character_OnNetworkPresentationChanged(ent, name, _, new)
	if not IsValid(ent) or not ent:IsPlayer() then return end
	if LZY_DRAW_STATE_NWVARS[name] then
		if name == "InCharacterMenu" and ent == LocalPlayer() then
			for _, p in player.Iterator() do
				LZY_Character_RefreshDrawState(p)
			end
		else
			LZY_Character_RefreshDrawState(ent)
		end
	end
	if name == "NCM_TF_Active" and new == false then
		timer.Simple(0, function()
			if IsValid(ent) then LZY_Character_SyncPlayerClientModels(ent) end
		end)
	elseif name == "EVO_HollowRaw" or name == "EVO_IsLarva" then
		timer.Simple(0, function()
			if not IsValid(ent) then return end
			if LZY_Character_InHubOrFinalizeFlow(ent) then
				if LZY_Character_DestroyPlayerClientModels then
					LZY_Character_DestroyPlayerClientModels(ent)
				else
					ent.RenderOverride = nil
				end
				return
			end
			if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ent) then
				return
			end
			LZY_Character_SyncPlayerClientModels(ent)
		end)
	elseif name == "Character::Unique::ID" then
		timer.Simple(0, function()
			if not IsValid(ent) then return end
			if LZY_Character_InHubOrFinalizeFlow(ent) then return end
			if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ent) then
				return
			end
			local data = playersModels and playersModels[ent]
			local liveUid = ent:GetEvoNWString("Character::Unique::ID", "none")
			local dataUid = data and data.unique_id ~= nil and tostring(data.unique_id) or ""
			if data and dataUid ~= "" and liveUid ~= "" and liveUid ~= "none" and dataUid ~= liveUid then
				playersModels[ent] = nil
				local key = (LZY_Character_NetPlayerKey and LZY_Character_NetPlayerKey(ent)) or ent:SteamID64()
				if isstring(key) and key ~= "" then
					_lzyPendingModelsBySteamID64[key] = nil
					LZY_Character_WantSetForget(key)
					_lzyWantRevProbed[key] = nil
				end
				LZY_Character_DestroyPlayerClientModels(ent)
				if ent == LocalPlayer() or LZY_Character_PlayerExpectsModelData(ent, LocalPlayer()) then
					LZY_Character_WantPM(ent, { revProbe = true, force = true })
				end
			end
		end)
	end
end
hook.Add("EVO:Appearance:Changed", "EVO:Client:PlayerClientSideModel:Appearance", LZY_Character_OnNetworkPresentationChanged)
hook.Add("LZY:PlyState:Changed", "EVO:Client:PlayerClientSideModel:LocalState", LZY_Character_OnNetworkPresentationChanged)

local function LZY_Character_EnsureDrawable(ply, overrideSuppressed)
	local data = playersModels and playersModels[ply]
	if not data or not data.body_model then
		LZY_Character_TryApplyPendingModelForPlayer(ply)
		data = playersModels and playersModels[ply]
	end
	if not data or not data.body_model then
		if LZY_Character_PlayerExpectsModelData(ply, LocalPlayer()) then
			LZY_Character_WantPM(ply, { rateLimit = true })
		end
		return
	end
	if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ply) then
		return
	end
	if ply.RenderOverride == ply._lzyCompositeRenderOverride
		and not overrideSuppressed
		and not LZY_Character_PlayerNeedsModelRepair(ply) then
		return
	end
	if not LZY_Character_PlayerShouldBuildClientModels(ply) then return end
	if not LZY_Character_PlayerNeedsModelRepair(ply) then return end
	LZY_Character_DeferPlayerModelBuild(ply, 10)
end

hook.Add("PrePlayerDraw", "EVO:Client:PlayerClientSideModel:SkipOverBudget", function(ply)
	if not IsValid(ply) or ply == LocalPlayer() then return end
	if LZY_Character_ShouldDrawOtherPlayer(ply) then return end
	if ply:Alive() and LZY_Character_CompositeNotReady(ply) then
		LZY_Character_EnsureDrawable(ply, true)
	end
	return true
end)

hook.Add("PrePlayerDraw", "EVO:Client:PlayerClientSideModel:PreDrawEnsure", function(ply)
	if not IsValid(ply) or ply == LocalPlayer() or not ply:Alive() then return end
	LZY_Character_EnsureDrawable(ply, false)
end)

local COMPOSITE_STUCK = 1.5
local COMPOSITE_FIX_GAP = 2
local _lzyCompositeWatchdogAt = 0

hook.Add("Think", "EVO:Client:PlayerClientSideModel:CompositeWatchdog", function()
	local now = CurTime()
	if now < _lzyCompositeWatchdogAt then return end
	_lzyCompositeWatchdogAt = now + 0.5
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if LZY_Character_IsLocalInCharMenu() then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end

	local stuckMissing = 0
	for _, ply in player.Iterator() do
		if not IsValid(ply) or not ply:Alive() then continue end
		local missingComposite
		if ply == lp then
			local ownData = playersModels and playersModels[ply]
			missingComposite = LZY_Character_PlayerShouldBuildClientModels(ply)
				and ((not ownData or not ownData.body_model)
					or LZY_Character_PlayerNeedsModelRepair(ply)
					or (ownData and LZY_IsRawBodyModel(ownData.body_model)
						and not LZY_IsLarvaCharacter(ply, ownData)))
		else
			missingComposite = LZY_Character_CompositeNotReady(ply)
		end
		if not missingComposite then
			ply._lzyCompositeMissingSince = nil
			continue
		end
		local since = ply._lzyCompositeMissingSince
		if not since then
			ply._lzyCompositeMissingSince = now
			continue
		end
		if (now - since) < COMPOSITE_STUCK then continue end
		stuckMissing = stuckMissing + 1
		if (ply._lzyCompositeFixAt or 0) > now then continue end
		ply._lzyCompositeFixAt = now + COMPOSITE_FIX_GAP

		local data = playersModels and playersModels[ply]
		if not data or not data.body_model then
			if ply == lp or LZY_Character_PlayerExpectsModelData(ply, lp) then
				LZY_Character_WantPM(ply, { force = true })
			end
			continue
		end
		if LZY_Character_InvalidateStaleRawModel and LZY_Character_InvalidateStaleRawModel(ply) then
			continue
		end
		if (ply._lzyBodyAllocBlockedUntil or 0) > now then continue end
		if ply ~= lp and LZY_Character_PlayerExpectsModelData(ply, lp) then
			local key = LZY_Character_NetKeyFor(ply)
			if key then _lzyWantRevProbed[key] = nil end
			LZY_Character_WantPM(ply, { revProbe = true, force = true })
		end
		LZY_Character_DestroyPlayerClientModels(ply)
		ply._lzyDeferBuildToken = (ply._lzyDeferBuildToken or 0) + 1
		ply._lzyDeferBuildActive = nil
		LZY_Character_DeferPlayerModelBuild(ply, 20)
	end
	if stuckMissing >= 8 and (lp._lzyMassVisUnstickAt or 0) <= now then
		lp._lzyMassVisUnstickAt = now + 5
		LZY_Character_WantScanMissingPM({ force = true })
	end
end)

hook.Add("NotifyShouldTransmit", "EVO:Client:PlayerClientSideModel:PVS", function(ent, shouldTransmit)
	if not IsValid(ent) or not ent:IsPlayer() then return end
	if ent == LocalPlayer() then return end
	if shouldTransmit then
		timer.Simple(0, function()
			if not IsValid(ent) then return end
			LZY_Character_OnPlayerEnteredPVS(ent)
		end)
	else
		LZY_Character_OnPlayerExitedPVS(ent)
	end
end)
