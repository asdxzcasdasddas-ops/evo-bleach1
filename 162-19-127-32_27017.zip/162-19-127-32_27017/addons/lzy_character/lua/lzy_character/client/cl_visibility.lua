-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_visibility.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Filet VISIBILITE cote CLIENT : diagnostic + « unstick » du bouton Rafraichir.
--
-- Le bouton « Rafraichir apparences » ne reconstruisait que les ClientsideModels.
-- Or la majorite des cas « joueur invisible pour CERTAINS observateurs seulement »
-- ne viennent pas d'un composite casse : un flag « cache-moi » perime coupe le rendu
-- EN AMONT du composite (PrePlayerDraw, SetNoDraw clientside, budget LOD). Le modele
-- est parfait, il n'est juste jamais dessine -- d'ou le fameux « le refresh n'y change
-- rien ». L'unstick attaque les trois causes qu'un simple rebuild ignore :
--
--   1. Etat reseau perime  -> resync AUTORITAIRE des trois transports. C'est le seul
--      remede : le client ne peut pas deviner qu'une valeur est fausse, il faut la
--      redemander. Le serveur limite deja ces requetes (3s global, 0.5s par sujet) et
--      verifie le PVS, donc rien a throttler ici.
--   2. Latches clientside  -> hook EVO:Client:VisibilityUnstick. Chaque systeme relache
--      CE QU'IL a pose lui-meme. On ne touche JAMAIS au SetNoDraw d'un autre : un
--      SetNoDraw pose par le serveur est une propriete repliquee, l'effacer en local
--      revelerait un joueur legitimement cache (cloak admin, limbo, sort) jusqu'au
--      prochain envoi serveur -- on transformerait un bug d'invisibilite en triche.
--   3. Tags LOD / backoff  -> remis a nil, c'est-a-dire « pas encore evalue » donc
--      visible (fail open), et re-evalues au prochain passage du Think budget.

if SERVER then return end

--- Relache tout ce qui peut masquer un joueur cote client, et redemande au serveur
--- l'etat autoritaire. Retourne le nombre de joueurs re-evalues.
function LZY_Character_VisibilityUnstick()
	local lp = LocalPlayer()
	if not IsValid(lp) then return 0 end

	if LZY_PlyState_RequestAppearanceResync then LZY_PlyState_RequestAppearanceResync() end
	if LZY_PlyState_RequestResync then LZY_PlyState_RequestResync() end

	local count = 0
	for _, ply in player.Iterator() do
		if IsValid(ply) and ply ~= lp then
			-- Masque combat (EVO_FullHide, NCM_IsAssassinInvisible, ...) : par sujet.
			if EVO_HudNet and EVO_HudNet.RequestState then EVO_HudNet.RequestState(ply) end
			ply._lzyShouldDraw = nil
			ply._lzyNearDetail = nil
			ply._lzyDrawState = nil
			-- Un pic passager d'entites clientside bloquait la reconstruction du corps
			-- jusqu'a 8s par essai, et le watchdog saute le joueur pendant ce temps.
			ply._lzyBodyAllocFailures = 0
			ply._lzyBodyAllocBlockedUntil = nil
			count = count + 1
		end
	end

	hook.Run("EVO:Client:VisibilityUnstick", lp)
	return count
end

-- ── Diagnostic ──────────────────────────────────────────────────────────────
-- Le bug est PAR OBSERVATEUR : seul le client qui ne voit pas la personne detient
-- la preuve. Cette commande imprime, pour chaque joueur que CE client ne dessine
-- pas, la premiere raison trouvee -- ce qui distingue immediatement un flag reseau
-- perime d'un composite absent ou d'un plafond LOD.

--- Masquages sans valeur d'exploit : tout le monde peut les lire.
local PUBLIC_FLAGS = {
	{ key = "NCM_Instanced",     ty = "bool",  label = "instance (tuto/training)" },
	{ key = "EvoSenkaiInside",   ty = "bool",  label = "salle senkaimon",  until_ = "EvoSenkaiUntil" },
	{ key = "EvoGargantaInside", ty = "bool",  label = "salle garganta",   until_ = "EvoGargantaUntil" },
}

--- Capacites de dissimulation : nommer la capacite en clair donnerait un radar a
--- assassin / admin cloak. Le staff voit le detail, les autres juste la categorie.
local CONCEALMENT_FLAGS = {
	{ key = "NCM_IsAssassinInvisible", label = "passif assassin" },
	{ key = "EVO_FullHide",            label = "EVO_FullHide (sort)" },
	{ key = "EVO_FlashStepping",       label = "flashstep en cours" },
	{ key = "EVO_StaffMode",           label = "staff mode" },
}

local function flagValue(ply, entry)
	if entry.ty == "bool" or entry.ty == nil then
		return ply:GetEvoNWBool(entry.key, false)
	end
	return false
end

--- Premiere raison pour laquelle le client local ne dessine pas `ply`, ou nil.
local function suppressionReason(ply, staff)
	for _, entry in ipairs(PUBLIC_FLAGS) do
		if flagValue(ply, entry) then
			local suffix = ""
			if entry.until_ then
				local deadline = ply:GetEvoNWFloat(entry.until_, 0)
				-- Une deadline depassee = flag perime qui ne masque DEJA plus rien :
				-- on le signale quand meme, c'est la signature du bug portail.
				suffix = string.format(" (deadline %s, CurTime %.1f)",
					deadline > CurTime() and string.format("%.1f", deadline) or "DEPASSEE", CurTime())
			end
			return entry.key .. " = true -- " .. entry.label .. suffix
		end
	end
	for _, entry in ipairs(CONCEALMENT_FLAGS) do
		if ply:GetEvoNWBool(entry.key, false) then
			if staff then return entry.key .. " = true -- " .. entry.label end
			return "masque par une capacite (detail reserve au staff)"
		end
	end
	if ply._NCM_CrossInstanceHidden then
		return "_NCM_CrossInstanceHidden -- SetNoDraw pose par ncm_instance sur CE client"
	end
	if ply:GetNoDraw() then
		return "GetNoDraw() = true -- masquage entite (serveur ou clientside)"
	end
	if ply._lzyShouldDraw == false then
		return "_lzyShouldDraw = false -- hors plafond max_characters_drawn (LOD)"
	end
	if (ply._lzyBodyAllocBlockedUntil or 0) > CurTime() then
		return string.format("_lzyBodyAllocBlockedUntil -- budget ClientsideModel sature (%.1fs)",
			ply._lzyBodyAllocBlockedUntil - CurTime())
	end
	local data = GetPlayerCharacterData and GetPlayerCharacterData(ply)
	if not data then
		return "aucune donnee d'apparence sur ce client -- composite impossible " ..
			"(le corps ne se dessine QUE via le composite : pas de modele par defaut)"
	end
	if LZY_Character_CompositeNotReady and LZY_Character_CompositeNotReady(ply) then
		return "composite pas pret -- data presente mais parts non construites"
	end
	if EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(LocalPlayer(), ply) then
		return "EVO_Portal.PlayersSeparated -- isolation salle de portail"
	end
	return nil
end

concommand.Add("lzy_vis_debug", function(_, _, args)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local staff = lp:IsAdmin()
	local filter = string.lower(table.concat(args, " "):Trim())

	MsgN("========== [VisDebug] joueurs non dessines par CE client ==========")
	local shown, hidden = 0, 0
	for _, ply in player.Iterator() do
		if IsValid(ply) and ply ~= lp then
			local named = filter == "" or string.find(string.lower(ply:Nick()), filter, 1, true)
			local drawn = not LZY_Character_ShouldDrawOtherPlayer
				or LZY_Character_ShouldDrawOtherPlayer(ply)
			local reason = suppressionReason(ply, staff)
			if named and (reason or not drawn) then
				hidden = hidden + 1
				MsgN(string.format("  %-24s %s", ply:Nick(), ply:SteamID()))
				MsgN("      raison  : " .. (reason or "aucun masquage identifie (verifier PrePlayerDraw tiers)"))
				MsgN(string.format("      dessine : %s   NoDraw=%s   _lzyShouldDraw=%s",
					drawn and "oui" or "NON",
					tostring(ply:GetNoDraw()), tostring(ply._lzyShouldDraw)))
			elseif named then
				shown = shown + 1
			end
		end
	end
	MsgN(string.format("  -> %d joueur(s) masque(s), %d visible(s).", hidden, shown))
	if hidden > 0 then
		MsgN("  Si la raison est un flag reseau : l'etat de CE client est perime,")
		MsgN("  utilise le bouton « Rafraichir apparences » (ou lzy_vis_fix).")
	end
	if not staff then
		MsgN("  (certains details sont reserves au staff)")
	end
	MsgN("===================================================================")
end)

--- Meme action que le bouton, sans passer par l'UI : utile a dicter en jeu.
concommand.Add("lzy_vis_fix", function()
	if LZY_Character_ManualRefreshPlayerModels then
		LZY_Character_ManualRefreshPlayerModels()
	else
		LZY_Character_VisibilityUnstick()
	end
end)
