-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_character_creation.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Share the one-model-per-frame queue while preserving this menu's camera setup.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

local PANEL = {}
local frame = nil
local UpdateCharacterData -- assigned later; pupil swatch rebuild helpers close over this local
local can_open = true

-- EyesColor material proxy: reads ent.EyesColor and sets $color2 (matches VMT Proxies.EyesColor.resultVar).
matproxy.Add({
    name = "EyesColor",
    init = function(self, mat, values)
        self.ResultTo = values.resultvar or "$color2"
    end,
    bind = function(self, mat, ent)
        if not IsValid(ent) then return end
        local c = ent.EyesColor
        if c then
            mat:SetVector(self.ResultTo, Vector(
                math.Clamp(c.r or 0, 0, 255) / 255,
                math.Clamp(c.g or 0, 0, 255) / 255,
                math.Clamp(c.b or 0, 0, 255) / 255
            ))
        end
    end
})

-- Track all ClientsideModel entities created by this UI so we can clean them up safely.
local createdClientsideModels = {}
-- Any face models created for this UI's previews live under this path prefix.
local GRID_FACE_MODEL_PREFIX = "models/evo/face/"

local function TrackClientsideModel(ent)
    if not IsValid(ent) then return end
    table.insert(createdClientsideModels, ent)
end

local function CleanupClientsideModels()
    -- Remove all explicitly tracked clientside models
    for _, ent in ipairs(createdClientsideModels) do
        if IsValid(ent) then
            SafeRemoveEntity(ent)
        end
    end
    createdClientsideModels = {}

    -- Barber mode (lzy_coiffeur) : on saute la "extra safety" loop qui itere
    -- ents.GetAll() et supprime tout entity dont le model commence par
    -- "models/evo/face/". Le HUD (lzy_hud / cl_hud.lua) utilise un
    -- DModelPanel avec un model qui matche ce prefix => la safety loop le
    -- supprimait egalement, ce qui vidait le HUD apres chaque fermeture du
    -- coiffeur. En barber mode on n'a pas cree d'entities "grid face" (on
    -- saute la Page 1 et ses thumbnails), donc rien a nettoyer en extra.
    if LZY_CHARACTER_BARBER_MODE then return end

    -- HUB de sélection (ncm_char_select) : StartScene appelle ForceClose PUIS
    -- buildScene (faces models/evo/face/). Si OnRemove du creator est différé
    -- d'1 frame, cette safety-loop tuait les modèles du HUB → slot vide après
    -- "Terminer" la création.
    if NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive() then
        return
    end

    -- Extra safety: remove any stray client-only face models from this UI
    for _, ent in ents.Iterator() do
        if IsValid(ent)
            and not ent:IsPlayer()
            and ent:GetModel()
            and string.StartWith(string.lower(ent:GetModel()), string.lower(GRID_FACE_MODEL_PREFIX)) then
            SafeRemoveEntity(ent)
        end
    end
end

-- Retire proprement un modele de preview : la face racine ET tous ses sous-ents
-- bonemerges (body/hair/barbe/moustache). Retirer la seule face laisse les
-- enfants orphelins (parent invalide) => ils se rendent a (0,0,0) au centre de
-- la map. A utiliser a chaque fois qu'on detruit/recree un preview.
local function DestroyPreviewModel(ent)
    if not IsValid(ent) then return end
    for _, key in ipairs({ "bodyEnt", "hairEnt", "beardEnt", "mustacheEnt" }) do
        if IsValid(ent[key]) then SafeRemoveEntity(ent[key]) end
        ent[key] = nil
    end
    -- Accessoires équipés (HUB) = champs-entité dynamiques ent._lzyAccEnt<slot>.
    local accKeys = {}
    for k in pairs(ent:GetTable()) do
        if isstring(k) and string.sub(k, 1, 10) == "_lzyAccEnt" then accKeys[#accKeys + 1] = k end
    end
    for _, k in ipairs(accKeys) do
        if IsValid(ent[k]) then SafeRemoveEntity(ent[k]) end
        ent[k] = nil
    end
    SafeRemoveEntity(ent)
end

local materials = {
    left_panel_bg = Material("l1acam515ehakdj3/vs1c1xgu02o00.png", "smooth"), -- 658x1080
    continuer_btn = Material("l1acam515ehakdj3/iareaq44zcujr0h1m.png", "smooth"), -- 578x81
    continuer_btn_hover = Material("l1acam515ehakdj3/7k453ppu7j3famu.png", "smooth"), -- 578x81
    go_back_btn = Material("l1acam515ehakdj3/oex4smod4c79pxbeo.png", "smooth"), -- 60x60
    go_back_btn_hover = Material("l1acam515ehakdj3/1s22wqyhoe8s9.png", "smooth"), -- 60x60
    input_bg = Material("l1acam515ehakdj3/cuy88nes5gh8mhsl.png", "smooth"), -- 578x80
    input_bg_active = Material("l1acam515ehakdj3/i91boodhf9n1hnmsb.png", "smooth"), -- 578x80
    input_clear_btn = Material("l1acam515ehakdj3/oilevovbrtkz4u.png", "smooth"), -- 40x40
    slider_bg = Material("l1acam515ehakdj3/hk0h0ahyolmx5.png", "smooth"), -- 526x7
    slider_cursor = Material("l1acam515ehakdj3/a1pkd2wbhvoa3.png", "smooth"), -- 13x13
    creation_du_personnage_txt = Material("l1acam515ehakdj3/mwz0u712c4al.png", "smooth"), -- 341x88
    female_btn = Material("l1acam515ehakdj3/c1q06ssdmhbyptubu.png", "smooth"), -- 80x80
    female_btn_active = Material("l1acam515ehakdj3/izqoucw89sb3.png", "smooth"), -- 80x80
    male_btn = Material("l1acam515ehakdj3/25pl4ecvennpm6t.png", "smooth"), -- 80x80
    male_btn_active = Material("l1acam515ehakdj3/pf3sv5upkyhxulhx5.png", "smooth"), -- 80x80
    character_icon = Material("l1acam515ehakdj3/q8j4e4gls20q61rf.png", "smooth"), -- 19x34
    select_faction_bg = Material("l1acam515ehakdj3/m3s09ug80mdfzkcs6.png", "smooth"), -- 1920x1080
	shinigami_btn = Material("l1acam515ehakdj3/pdjb293j4h97wn.png", "smooth"), -- 980x1080
    shinigami_btn_hover = Material("l1acam515ehakdj3/jzm5uv6a1ia3qc.png", "smooth"), -- 980x1080
	hollow_btn = Material("l1acam515ehakdj3/tiwu2ycyf8nx.png", "smooth"), -- 938x1080
    hollow_btn_hover = Material("l1acam515ehakdj3/oeov4vlklgvrhgk.png", "smooth"), -- 938x1080
    choisir_sa_faction_txt = Material("l1acam515ehakdj3/wx27vvo38idpq3.png"), -- 405x28
    shinigami_icon = Material("l1acam515ehakdj3/6i05nkvlbs70099.png", "smooth"), -- 350x350
    hollow_icon = Material("l1acam515ehakdj3/kflc5qgaqm0fcm4o9.png", "smooth"), -- 350x350
    apparence_txt = Material("l1acam515ehakdj3/nrk8rp2dgetr7261.png", "smooth"), -- 300x38
    sub_panel_bg = Material("l1acam515ehakdj3/0gau6bacmxms3lnm.png", "smooth"), -- 440x1080
    terminer_btn = Material("l1acam515ehakdj3/h0mk2cyz6g3j2bok.png", "smooth"), -- 449x81
    terminer_btn_hover = Material("l1acam515ehakdj3/nac57wsrddp1ohrx.png", "smooth"), -- 449x81
    vertical_line = Material("l1acam515ehakdj3/3iallzu2sbrcqvi.png", "smooth"), -- 4x431
    cheveux_btn = Material("l1acam515ehakdj3/hd68tnxql58hcm7sx.png", "smooth"), -- 449x80
    cheveux_btn_hover = Material("l1acam515ehakdj3/ab81ibjq2n9uxg4u.png", "smooth"), -- 449x80
    visage_btn = Material("l1acam515ehakdj3/93uc4kd33z9i8s.png", "smooth"), -- 449x80
    visage_btn_hover = Material("l1acam515ehakdj3/lwjhfjpckrcoubows.png", "smooth"), -- 449x80
    yeux_btn = Material("l1acam515ehakdj3/mpn7uytehsv0l.png", "smooth"), -- 449x80
    yeux_btn_hover = Material("l1acam515ehakdj3/acfqhncft0jv25s1o.png", "smooth"), -- 449x80
    sourcils_btn = Material("l1acam515ehakdj3/drjmvtsyjv9zq.png", "smooth"), -- 449x80
    sourcils_btn_hover = Material("l1acam515ehakdj3/hojy8nczoqdtufde.png", "smooth"),                 -- 449x80
    barbes_moustaches_btn = Material("l1acam515ehakdj3/whv8wboh9k35c.png", "smooth"), -- 449x80
    barbes_moustaches_btn_hover = Material("l1acam515ehakdj3/u8uepqpyatwzt.png", "smooth"), -- 449x80
    tatoo_btn = Material("l1acam515ehakdj3/33l0bqeoc2ib8mve2.png", "smooth"), -- 449x80
    tatoo_btn_hover = Material("l1acam515ehakdj3/sphkmiwwz0hvf.png", "smooth"), -- 449x80
    mouse_scroll_icon = Material("l1acam515ehakdj3/2ni6ib6k9af6.png", "smooth"), -- 40x40
    mouse_left_click_icon = Material("l1acam515ehakdj3/zy4n9pgaonyllk.png", "smooth"), -- 40x40
    position_picker = Material("l1acam515ehakdj3/b3gzu8g5dcgolv.png", "smooth"), -- 178x178
    scale_picker = Material("l1acam515ehakdj3/h09n7w1880wm2n.png", "smooth"), -- 178x178
}

-- Tattoo thumbnails: drawing the source material directly is unreliable (its VMT may be
-- VertexLitGeneric, which sometimes reads uninitialized lighting state and flickers
-- black->white). We sample only $basetexture and blit it through a dedicated UnlitGeneric
-- material so the alpha-on-dark composition is stable.
local TATTOO_THUMB_BLIT
local function GetTattooThumbBlitMaterial()
    if TATTOO_THUMB_BLIT and not TATTOO_THUMB_BLIT:IsError() then return TATTOO_THUMB_BLIT end
    TATTOO_THUMB_BLIT = CreateMaterial("lzy_tattoo_thumb_blit", "UnlitGeneric", {
        ["$basetexture"] = "models/debug/debugwhite",
        ["$translucent"] = "1",
        ["$vertexalpha"] = "1",
        ["$vertexcolor"] = "1",
        ["$nolod"] = "1",
    })
    return TATTOO_THUMB_BLIT
end

local currentPage = 1 -- 1: Select Faction, 2: Main Character Creation, 3: Sub Character Creation

-- Character helper defaults (kept out of config.lua per requirements).
do
    function LZY_CHARACTER_CONFIG.NormalizeGender(gender)
        if not gender then return "male" end
        local g = string.lower(tostring(gender))
        if g == "f" or g == "female" then return "female" end
        return "male"
    end

    function LZY_CHARACTER_CONFIG.GetDefaultFaceModel(gender)
        local norm = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
        return norm == "female" and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE or LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE
    end

    function LZY_CHARACTER_CONFIG.GetDefaultBodyModel(gender, faction)
        local normGender = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
        local fac = tostring(faction or "Shinigami")

        local tbl = (normGender == "female") and LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_FEMALE
            or LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE

        if istable(tbl) and tbl[fac] then
            return tbl[fac]
        end

        -- Ultimate fallback so we never break
        if normGender == "female" then
            return "models/evo/characters/shinigami/female/evo_f4kq399g1dcdnc/evo_3p3uuy49h3ho.mdl"
        end
        return "models/evo/characters/shinigami/male/evo_yyjejrymar3ma/evo_7ef88q5bfk3wr1vg1.mdl"
    end

    -- COUPES PLATINUM : OUVERTES A TOUS depuis le 09/03 (demande user). La liste
    -- d'AFFICHAGE les contient donc pour tout le monde ; l'accès reste gaté par le
    -- voile « PLATINUM / Réservé » + la popup boutique (grille) et par la
    -- validation serveur (création, CK, coiffeur). Le filtre superadmin du 09/02
    -- est retiré.
    -- ⚠️ Cette fonction est définie une 2e fois dans cl_character_selection.lua ;
    -- l'autorun inclut ce fichier-ci APRÈS, donc c'est CETTE version qui gagne.
    -- Pour re-restreindre l'AFFICHAGE, filtrer ici ET là-bas.
    function LZY_CHARACTER_CONFIG.GetAvailableHairStyles(gender)
        local norm = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
        return norm == "female" and LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_FEMALE or LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_MALE
    end

    -- Coupes que CE joueur peut réellement PORTER (platinum retirées s'il n'y a
    -- pas droit). Sert aux tirages ALÉATOIRES : sans ça le dé pouvait poser une
    -- coupe platinum que le serveur remplaçait ensuite en silence.
    function LZY_CHARACTER_CONFIG.GetSelectableHairStyles(gender)
        local t = LZY_CHARACTER_CONFIG.GetAvailableHairStyles(gender)
        if LZY_CHARACTER_CONFIG.PeutCoupePlatinum(LocalPlayer()) then return t end
        return LZY_CHARACTER_CONFIG.GetHairStylesSansPlatinum(t)
    end
end

local shinigamiText = "Gardiens de l'équilibre. Faucheurs d'âmes."
local hollowText = "Nés du désespoir. Affamés d'éternité."

local characterData = {
    gender = "m",
    firstname = "",
    lastname = "",
    scale = 1, -- 0.7 to 1.5
    skin_color = 0,
    hair_color1 = Color(0, 0, 0),
    hair_color2 = Color(0, 0, 0),
    hair_details_color = Color(255, 255, 255),
    hair_model = LZY_CHARACTER_CONFIG.GetAvailableHairStyles("m")[1].model,
    beard_model = "",
    mustache_model = "",
    hair_gradient_angle = 0, -- 0 to 360
    eyes_color = Color(255, 255, 255),
    face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel("m"),
    faction = "Shinigami",
    body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel("m", "Shinigami"),
    -- shape_keys uses flex IDs as keys (for preview/server); shapeKeysByName uses flex names (for UI persistence)
    shape_keys = {},
    shapeKeysByName = {},
    bodygroups = {
        pupils = 0,
    },
    bodygroupsString = "",
    pupils_texture = "",
    pupils_separate = false,
    pupil_left = "",
    pupil_right = "",
    tattoo_texture = "",
    tattoo_color = Color(255, 255, 255),
    tattoo_pos_x = 0.5,
    tattoo_pos_y = 0.5,
    tattoo_scale_x = 1.0,
    tattoo_scale_y = 1.0,
    tattoo_opacity = 1.0,
    tattoo_rotation = 0,
    tattoo_texture_2 = "",
    tattoo_color_2 = Color(255, 255, 255),
    tattoo_pos_x_2 = 0.5,
    tattoo_pos_y_2 = 0.5,
    tattoo_scale_x_2 = 1.0,
    tattoo_scale_y_2 = 1.0,
    tattoo_opacity_2 = 1.0,
    tattoo_rotation_2 = 0,
    -- Tatouages du CORPS : { k = emplacement 1|2, t, z, u, v, s, r, o, c } (BODY_TATTOO, config).
    -- Un emplacement est visage OU corps : 2 tatouages au total.
    body_tattoos = {},
    -- Âge choisi à la création (slider 15-25, Page 2). Le perso vieillit ensuite de +2 ans
    -- par jour réel (1 an / 12 h, cf. sh_character 07/23 — même rythme que l'année RP du
    -- serveur). Donne +1% reiatsu/dégâts sort /10 ans.
    age_start = 18,
    referral_code = "",
}

-- Make an immutable copy of the initial defaults so we can reliably reset
-- characterData fields later without them drifting as the user edits values.
local defaultCharacterData = table.Copy(characterData)
defaultCharacterData.shapeKeysByName = {}

-- Default flex weights for the character creator UI (first-open / missing values).
-- We also sync them into `characterData.shape_keys` (flex IDs) after the preview model is created
-- so they are preserved when saving the character.
local DEFAULT_START_SHAPEKEYS = {
    Chin_shape1 = 0.5,
    Chin_shape2 = 0.5,
    Chin_shape3 = 0.5,
    ear_shape = 0.5,
    Down = 0.5,
    Length = 0.5,
    Thickness = 0.5
}

for flexName, defaultValue in pairs(DEFAULT_START_SHAPEKEYS) do
    defaultCharacterData.shapeKeysByName[flexName] = defaultValue
    characterData.shapeKeysByName[flexName] = defaultValue
end

local function trimStr(str)
    if not isstring(str) then return "" end
    return (string.gsub(str, "^%s*(.-)%s*$", "%1")) or ""
end

-- nil = not yet verified / stale; true = server says free; false = taken
local characterNameServerAvailable = nil
local characterNameCheckPending = false

local function getTrimmedCharacterNames()
    return trimStr(characterData.firstname or ""), trimStr(characterData.lastname or "")
end

local function characterNamesAreFilled()
    -- Nom de famille OPTIONNEL (demande user 07/22) : seul le prénom est requis.
    local a = getTrimmedCharacterNames()
    return a ~= ""
end

local function characterNameGateAllowsProceed()
    return characterNamesAreFilled() and not characterNameCheckPending and characterNameServerAvailable == true
end

local function GetCharacterNameGateHint()
    if not characterNamesAreFilled() then
        return "Renseignez au moins le prénom."
    end
    if characterNameCheckPending then
        return "Vérification du nom..."
    end
    if characterNameServerAvailable == false then
        return "Ce prénom et ce nom sont déjà utilisés."
    end
    if characterNameServerAvailable == nil then
        return "Cliquez sur Continuer pour vérifier le nom."
    end
    return ""
end

local function ResetCharacterNameAvailabilityState()
    characterNameServerAvailable = nil
    characterNameCheckPending = false
end

local function RefreshCharacterNameGate()
    if IsValid(frame) and IsValid(frame.currentPagePanel) then
        frame.currentPagePanel:InvalidateLayout(true)
    end
end

local function RequestCharacterNameCheckFromServer()
    local f, l = getTrimmedCharacterNames()
    -- Nom de famille optionnel : on vérifie la dispo dès que le PRÉNOM est rempli
    -- (la paire "Prénom"+"" reste soumise au check d'unicité serveur).
    if f == "" then
        ResetCharacterNameAvailabilityState()
        RefreshCharacterNameGate()
        return
    end
    characterNameCheckPending = true
    RefreshCharacterNameGate()
    net.Start("EVO:Server:CharacterCreator:CheckCharacterName")
    net.WriteString(f)
    net.WriteString(l)
    if LZY_CHARACTER_CK_MODE and istable(LZY_CHARACTER_CK_DATA) then
        net.WriteInt(tonumber(LZY_CHARACTER_CK_DATA.unique_id) or 0, 32)
    end
    net.SendToServer()
end

local function SyncPage2NameInputsFromWidgets(pnl)
    if not IsValid(pnl) or not IsValid(pnl.firstNameInput) or not IsValid(pnl.lastNameInput) then return end
    local f = trimStr(pnl.firstNameInput:GetText())
    local l = trimStr(pnl.lastNameInput:GetText())
    pnl.firstNameInput:SetText(f)
    pnl.lastNameInput:SetText(l)
    if f ~= trimStr(characterData.firstname or "") or l ~= trimStr(characterData.lastname or "") then
        ResetCharacterNameAvailabilityState()
    end
    characterData.firstname = f
    characterData.lastname = l
    if IsValid(pnl.referralInput) then
        local c = string.upper(string.gsub(trimStr(pnl.referralInput:GetText()), "%s+", ""))
        pnl.referralInput:SetText(c)
        characterData.referral_code = c
    end
end

local function NotifyCharacterCreator(msg, ntype)
    ntype = ntype or NOTIFY_ERROR
    if MUGEN and MUGEN.Notify then
        MUGEN.Notify(msg, ntype, 5)
    else
        notification.AddLegacy(msg, ntype, 5)
    end
end

-- ── Code de parrainage : validation LIVE (a la perte de focus du champ) ──────
-- Le serveur reste seul juge (EVO_Parrainage.ValidateCode au Terminer), mais on interroge
-- la meme fonction des que le joueur quitte le champ pour dire tout de suite si le code
-- existe, au lieu d'attendre l'echec de la creation. Un seul local (table) : ce fichier
-- frole la limite de 200 locals par chunk.
local ReferralCheck = {
    code    = nil,  -- code (normalise) auquel `state` se rapporte
    state   = nil,  -- nil = pas verifie | "ok" | "empty" | "format" | "unknown" | "self" | "not_first" | "already" | "db"
    pending = false,
}

-- Messages joueur par statut serveur. nil = pas de notification (statut neutre).
ReferralCheck.MESSAGES = {
    format    = "Code de parrainage invalide (4 à 16 lettres ou chiffres), ou laisse vide.",
    unknown   = "Ce code de parrainage n'existe pas.",
    self      = "Tu ne peux pas utiliser ton propre code.",
    not_first = "Le code de parrainage n'est utilisable que sur ton premier personnage.",
    already   = "Tu as déjà été parrainé : ce code sera ignoré.",
    db        = "Impossible de vérifier le code pour l'instant, réessaie.",
}

-- Statuts qui BLOQUENT le passage a la page suivante / la creation.
ReferralCheck.BLOCKING = {
    format = true, unknown = true, self = true, db = true,
}

function ReferralCheck.Reset()
    ReferralCheck.code, ReferralCheck.state, ReferralCheck.pending = nil, nil, false
end

function ReferralCheck.NotifyState(status)
    local msg = ReferralCheck.MESSAGES[status]
    if msg then
        NotifyCharacterCreator(msg, ReferralCheck.BLOCKING[status] and NOTIFY_ERROR or NOTIFY_HINT)
    elseif status == "ok" then
        NotifyCharacterCreator("Code de parrainage valide.", NOTIFY_GENERIC)
    end
end

function ReferralCheck.Normalize(raw)
    if EVO_Parrainage and EVO_Parrainage.NormalizeCode then
        return EVO_Parrainage.NormalizeCode(raw)
    end
    return string.upper(string.gsub(tostring(raw or ""), "%s+", ""))
end

-- Statut du code courant, ou nil s'il n'a pas encore ete verifie.
function ReferralCheck.StateFor(code)
    if ReferralCheck.code ~= code then return nil end
    return ReferralCheck.state
end

-- Demande la verification au serveur (no-op si deja verifie / deja en vol).
function ReferralCheck.Request(code, notify)
    code = ReferralCheck.Normalize(code)
    if code == "" then
        ReferralCheck.code, ReferralCheck.state, ReferralCheck.pending = "", "empty", false
        return
    end
    -- Format : verifiable sans aller-retour serveur.
    if EVO_Parrainage and EVO_Parrainage.IsValidCodeFormat and not EVO_Parrainage.IsValidCodeFormat(code) then
        ReferralCheck.code, ReferralCheck.state, ReferralCheck.pending = code, "format", false
        if notify then NotifyCharacterCreator(ReferralCheck.MESSAGES.format) end
        return
    end
    if ReferralCheck.pending and ReferralCheck.code == code then return end
    -- Deja verifie : on re-notifie depuis le cache (pas de 2e aller-retour).
    if ReferralCheck.code == code and ReferralCheck.state then
        if notify then ReferralCheck.NotifyState(ReferralCheck.state) end
        return
    end
    if util.NetworkStringToID("evo_parrainage.check_ref") == 0 then return end
    ReferralCheck.code, ReferralCheck.state, ReferralCheck.pending = code, nil, true
    ReferralCheck.notifyOnAnswer = notify and true or false
    net.Start("evo_parrainage.check_ref")
        net.WriteString(code)
    net.SendToServer()
end

net.Receive("evo_parrainage.check_ref_result", function()
    local code   = net.ReadString() or ""
    local status = net.ReadString() or ""
    if ReferralCheck.code ~= code then return end -- reponse perimee (le joueur a retape)
    ReferralCheck.state, ReferralCheck.pending = status, false
    if ReferralCheck.notifyOnAnswer then ReferralCheck.NotifyState(status) end
end)

-- Flex controller names; re-applied every frame so animation doesn't overwrite them.
local PREVIEW_FLEX_NAMES = {
    "Eye_shape1", "Eye_shape2", "Eye_shape3", "Eye_shape4",
    "Nose_shape1", "Nose_shape2", "Nose_shape3", "Nose_shape4",
    "Mouth_shape1", "Mouth_shape2", "Mouth_shape3", "Mouth_shape4",
    "Chin_shape1", "Chin_shape2", "Chin_shape3", "ear_shape",
    "Serious_R", "Serious_L", "Sad_R", "Sad_L", "Happy_R",
    "Happy_L", "Angry_R", "Angry_L", "Thickness", "Length", "Down"
}

-- Pupil helpers: LZY_Pupils*, GetPupilsTextureList, SetEyesBodygroupToFirst, ApplyPupilTextureToEntity, ApplyPupilsFromCharacterData (cl_models.lua)

-- Cache from flex name -> flex ID for the current preview model
local ShapeKeyNameToId = {}

local function GetShapeKeyIdForName(ent, name)
    if not IsValid(ent) then return nil end
    local cached = ShapeKeyNameToId[name]
    if cached ~= nil then return cached end

    local id = ent:GetFlexIDByName(name)
    if not id or id < 0 then
        id = nil
    end
    ShapeKeyNameToId[name] = id
    return id
end

local function SyncDefaultShapeKeysToFlexIds(previewEnt)
    if not IsValid(previewEnt) then return end
    characterData.shape_keys = characterData.shape_keys or {}

    -- Map only the keys we explicitly default (keep it predictable + cheap).
    for flexName, defaultValue in pairs(DEFAULT_START_SHAPEKEYS) do
        local val = characterData.shapeKeysByName and characterData.shapeKeysByName[flexName]
        if val == nil then
            val = defaultValue
            characterData.shapeKeysByName[flexName] = val
        end

        local id = GetShapeKeyIdForName(previewEnt, flexName)
        if id then
            characterData.shape_keys[id] = val
        end
    end
end

local function ApplyPreviewModelFlexWeights(ent)
    if not IsValid(ent) or not characterData.shape_keys then return end
    for _, flexName in ipairs(PREVIEW_FLEX_NAMES) do
        local id = GetShapeKeyIdForName(ent, flexName)
        if id then
            local val = (characterData.shapeKeysByName and characterData.shapeKeysByName[flexName]) or characterData.shape_keys[id]
            if val ~= nil then
                ent:SetFlexWeight(id, val)
            end
        end
    end
end

-- BARBER/SCULPTEUR : les données du PNJ ne fournissent que `shape_keys` (par ID de flex), pas
-- `shapeKeysByName` (par NOM). Or les sliders ET ApplyPreviewModelFlexWeights lisent shapeKeysByName
-- EN PRIORITÉ (resté aux DÉFAUTS) -> le visage du créateur en mode édition s'affiche à l'état initial,
-- et SyncDefaultShapeKeysToFlexIds fige ensuite ces défauts. On reconstruit donc shapeKeysByName
-- depuis les shape_keys chargés (mapping nom->ID via le modèle preview courant), pour que l'éditeur
-- reflète les TRAITS ACTUELS du personnage. Gère les clés number ET string (les shape_keys passent
-- par un JSON DB -> clés string à la relecture).
local function LZY_LoadShapeKeysByNameFromIds(previewEnt)
    if not IsValid(previewEnt) or not istable(characterData.shape_keys) then return end
    -- Le cache nom->ID est PARTAGÉ : on le vide pour qu'il se résolve sur CE modèle preview
    -- (sinon des IDs d'un perso/genre précédent fausseraient la lecture des shape_keys chargés).
    for k in pairs(ShapeKeyNameToId) do ShapeKeyNameToId[k] = nil end
    characterData.shapeKeysByName = characterData.shapeKeysByName or {}
    for _, flexName in ipairs(PREVIEW_FLEX_NAMES) do
        local id = GetShapeKeyIdForName(previewEnt, flexName)
        if id then
            local v = characterData.shape_keys[id]
            if v == nil then v = characterData.shape_keys[tostring(id)] end
            if v ~= nil then characterData.shapeKeysByName[flexName] = tonumber(v) or 0 end
        end
    end
end

-- Hair gradient: Color 1 ($color2) + Color 2 ($detailtint) with ramp; angle rotates gradient direction.
-- Use shared world gradient helpers from cl_models.lua (made global) so creator and live players stay in sync.
local function ApplyHairGradientToPreview(faceEnt, hairEnt, colA, colB, angleDeg, detailsColor)
    if not IsValid(faceEnt) and not IsValid(hairEnt) then return end
    ApplyHairGradientToWorldPlayer(faceEnt, hairEnt, colA, colB, angleDeg, detailsColor or Color(255, 255, 255))
end

local function ApplyHairGradientToPreviewHairAndFacial(faceEnt)
    if not IsValid(faceEnt) then return end
    local c1, c2 = characterData.hair_color1, characterData.hair_color2
    local ang, det = characterData.hair_gradient_angle, characterData.hair_details_color
    if IsValid(faceEnt.hairEnt) then
        ApplyHairGradientToPreview(faceEnt, faceEnt.hairEnt, c1, c2, ang, det)
    end
    if IsValid(faceEnt.beardEnt) then
        ApplyHairGradientToPreview(faceEnt, faceEnt.beardEnt, c1, c2, ang, det)
    end
    if IsValid(faceEnt.mustacheEnt) then
        ApplyHairGradientToPreview(faceEnt, faceEnt.mustacheEnt, c1, c2, ang, det)
    end
end

local function SetEntityAnim(ent, animation, speed, cycle)
    if not IsValid(ent) then return end

    speed = speed or 1
    cycle = cycle or 0

    ent:SetPlaybackRate(speed)
    ent:SetCycle(cycle)

    local seqCount = ent:GetSequenceCount()
    if seqCount <= 0 then return end

    local blockedNames = {
        proportions = true,
        a_proportions = true
    }

    local function GetValidSequence(name)
        if not name or name == "" then return -1 end

        local seq = ent:LookupSequence(name)
        if not seq or seq < 0 then return -1 end

        local seqName = ""
        pcall(function()
            seqName = ent:GetSequenceName(seq) or ""
        end)

        if blockedNames[seqName] then
            return -1
        end

        return seq
    end

    local seq = -1

    if animation then
        seq = GetValidSequence(animation)
    end

    if seq < 0 then
        seq = GetValidSequence("idle_all_01")
    end

    if seq < 0 then
        seq = GetValidSequence("idle")
    end

    if seq < 0 then
        seq = GetValidSequence("reference")
    end

    if seq < 0 then
        seq = 0
    end

    local seqName = ""
    pcall(function()
        seqName = ent:GetSequenceName(seq) or ""
    end)

    if seqName == "proportions" or seqName == "a_proportions" then
        local ref = ent:LookupSequence("reference")
        if ref and ref >= 0 then
            seq = ref
        else
            seq = 0
        end
    end

    ent:ResetSequence(seq)
end

-- Idle de l'aperçu du créateur. Chez le tatoueur, « Pose neutre » (frame._lzyNeutralPose) =
-- debout bras le long du corps, pour voir torse, dos et bras (user 10/02).
function LZY_CC_PreviewIdleAnim()
    if LZY_CHARACTER_TATTOO_MODE and frame and frame._lzyNeutralPose then return "idle_all_01" end
    return characterData.gender == "m" and LZY_CHARACTER_CONFIG.CREATOR_IDLE_ANIM_MALE or LZY_CHARACTER_CONFIG.CREATOR_IDLE_ANIM_FEMALE
end

function LZY_CC_SetPreviewPose(bNeutral)
    if not frame then return end
    frame._lzyNeutralPose = bNeutral and true or nil
    if IsValid(frame.previewModel) then SetEntityAnim(frame.previewModel, LZY_CC_PreviewIdleAnim(), 1, 0) end
end

-- Aligne le preview sur le sol (creator). TraceHull peut retourner nil si le monde
-- n'est pas encore prêt (reconnexion mid-creator, joueur en limbo).
local function SnapPreviewModelToGround(ent, posVector)
    if not IsValid(ent) then return end
    local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
    if not mins or not maxs then return end
    local tr = util.TraceHull({
        start = posVector + Vector(0, 0, 64),
        endpos = posVector - Vector(0, 0, 512),
        mins = Vector(mins.x, mins.y, 0),
        maxs = Vector(maxs.x, maxs.y, 0),
        mask = MASK_SOLID_BRUSHONLY,
    })
    if tr and tr.Hit then
        ent:SetPos(tr.HitPos - Vector(0, 0, mins.z))
    end
end

local function createClientsidePlayerModel(posVector, angleVector, playerData)
    -- evo_hollow_progression : perso larva -> le preview affiche le modèle hollow ENTIER
    -- (raw), pas le composite face+corps arrancar (= "mon arrancar par défaut").
    -- IDEM pour l'âme errante (evo_lost_soul) : dans le HUB on veut UNIQUEMENT le modèle
    -- lost_soul brut, PAS le composite visage+corps (sinon on voit le visage par-dessus).
    local bLarvaPrev = EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(playerData.body_model)
    local bSoulPrev  = EVO_LostSoul and EVO_LostSoul.IsLostSoulBodyModel and EVO_LostSoul.IsLostSoulBodyModel(playerData.body_model)
    if bLarvaPrev or bSoulPrev then
        local lent = ClientsideModel(playerData.body_model)
        if IsValid(lent) then
            TrackClientsideModel(lent)
            lent:SetPos(posVector)
            lent:SetAngles(angleVector)
            SnapPreviewModelToGround(lent, posVector)
            lent.baseAngles = angleVector
            if bLarvaPrev then
                -- Échelle RÉELLE de la larva (proportions) : recalculée à l'identique côté client
                -- (déterministe par char_id) -> mêmes proportions que le perso en jeu, plus le
                -- scale=1 de la BDD. Fallback playerData.scale si le helper n'est pas chargé.
                lent:SetModelScale((EVO_HollowProg.GetScale and EVO_HollowProg.GetScale(playerData.unique_id))
                    or tonumber(playerData.scale) or 1)
                -- Apparence RÉELLE de la larva (skin + masque/bodygroups) : recalculée à
                -- l'identique côté client (déterministe par char_id) -> la preview montre le VRAI
                -- hollow qu'on joue, pas une version "propre" sans masque.
                if EVO_HollowProg.ApplyAppearance then
                    local cfg = EVO_HollowProg.Config
                    local isVasto = cfg and playerData.body_model == cfg.VastoModel
                    EVO_HollowProg.ApplyAppearance(lent, isVasto, playerData.unique_id)
                end
            else
                -- Âme errante : modèle brut, échelle de config (pas de visage, pas de composite).
                lent:SetModelScale((EVO_LostSoul.Config and tonumber(EVO_LostSoul.Config.ModelScale)) or 1)
            end
        end
        return lent
    end

    local model = playerData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(playerData.gender)
    local ent = ClientsideModel(model)
    if IsValid(ent) then
        -- La face racine est trackee elle aussi : sans ca, seule la "safety loop"
        -- sur le prefixe models/evo/face/ la rattrapait (sautee en barber mode).
        TrackClientsideModel(ent)
        -- RT de tatouage STABLE par aperçu (visage + corps) : re-cuite sur place, aucune RT
        -- neuve par réglage. Une clé par perso : la sélection en affiche plusieurs à la fois.
        ent._lzyStableTatKey = "c" .. string.gsub(tostring(playerData.unique_id or "creator"), "[^%w_]", "")

        -- Start roughly at the desired instance position/angle
        ent:SetPos(posVector)
        ent:SetAngles(angleVector)

        SnapPreviewModelToGround(ent, posVector)

        -- Store base angles so we can rotate the preview model relative to this
        ent.baseAngles = angleVector

        -- skin_color est le nom canonique du champ dans characterData ; on
        -- garde "skin" en fallback pour les anciens code paths qui pourraient
        -- encore l'utiliser. Avant : seul "skin" etait lu => barber mode
        -- recevait skin_color depuis le serveur mais createClientsidePlayerModel
        -- ne le lisait pas et SetSkin(0) etait toujours applique => preview
        -- montrait la skin 0 au lieu de la skin actuelle du joueur.
        ent:SetSkin(tonumber(playerData.skin_color) or tonumber(playerData.skin) or 0)
        -- IMPORTANT : on applique aussi le scale directement a la creation.
        -- Sans ca, le modele reste a scale 1.0 jusqu'a ce que CreateSlider("scale")
        -- soit appele via UpdateCharacterData -> SetModelScale. En sculpteur le slider
        -- est visible donc ca arrive. En coiffeur/tatoueur le slider n'existait pas
        -- => modele a scale 1.0 alors que characterData.scale = 0.95 par ex.
        -- Resultat : le bone "head" est plus haut, la cam (qui look-at le bone)
        -- pop a un endroit different entre les 3 PNJ.
        local previewScale = tonumber(playerData.scale) or 1
        if previewScale ~= 1 then
            ent:SetModelScale(math.Round(previewScale, 2), 0)
        end
        if isstring(playerData.bodygroupsString) and playerData.bodygroupsString ~= "" then
            ent:SetBodyGroups(playerData.bodygroupsString)
        elseif type(playerData.bodygroups) == "string" and playerData.bodygroups ~= "" then
            ent:SetBodyGroups(playerData.bodygroups)
        end
        ApplyPupilsFromCharacterData(ent, playerData.gender, playerData)

        local function syncPreviewTattoo()
            if IsValid(ent) then
                LZY_ApplyTattooFromCharacterData(ent, playerData)
            end
        end
        syncPreviewTattoo()
        timer.Simple(0.1, syncPreviewTattoo)

        -- Find which face submaterial uses the hair material (so we can apply gradient there too)
        local materials = ent:GetMaterials()
        if materials then
            for i, material in ipairs(materials) do
                if string.find(material, "evo/hair/uni") then
                    ent.hairMaterial = material
                    ent.hairMaterialIndex = i - 1
                    break
                end
            end
        end

        -- Play idle on face if it has sequences; otherwise idle will be played on body.
        -- Anim PROPRE au créateur (CREATOR_IDLE_ANIM_*, = bras croisés) — découplée de l'idle
        -- inventaire/menu (IDLE_ANIM_*) à la demande user (2 anims différentes).
        ent:SetupBones()
        local sCreatorIdle = LZY_CC_PreviewIdleAnim()
        SetEntityAnim(ent, sCreatorIdle, 1, 0)
        -- RE-application différée (même filet que ncm_char_select) : à t=0 le modèle vient d'être
        -- créé et LookupSequence peut échouer -> SetEntityAnim retombait sur idle_all_01 = le user
        -- voyait "l'idle normal" au lieu des bras croisés. On repose l'anim quand le modèle est prêt.
        timer.Simple(0.15, function()
            if IsValid(ent) then SetEntityAnim(ent, sCreatorIdle, 1, 0) end
        end)
    end

    local bodyModel = playerData.body_model or (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultBodyModel(playerData.gender, playerData.faction))
    -- Uniforme de grade : si la data du perso porte rank/division (cas SCÈNE DE SÉLECTION = le HUB :
    -- la liste de persos est chargée avec ces champs), on remplace le corps par l'uniforme. En
    -- CRÉATION/édition la data n'a pas de rank/division -> no-op (garde body_model). Ce builder
    -- (LZY_CreateClientsideCharacter) sert à la fois le créateur ET la scène 3D de sélection (ncm_char_select).
    if LZY_Character_GetDisplayBodyModelFromData then
        local disp = LZY_Character_GetDisplayBodyModelFromData(playerData)
        if isstring(disp) and disp ~= "" then bodyModel = disp end
    end
    if bodyModel then
        ent.bodyEnt = ClientsideModel(bodyModel, RENDERGROUP_OPAQUE)
        if IsValid(ent.bodyEnt) then
            TrackClientsideModel(ent.bodyEnt)
            ent.bodyEnt:SetParent(ent)
            ent.bodyEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
            -- Applique le skin sur le body aussi pour matcher la face. Sans
            -- ca, la face avait la bonne couleur de peau mais le corps gardait
            -- le skin 0 par defaut => mismatch visuel face/corps.
            ent.bodyEnt:SetSkin(tonumber(playerData.skin_color) or tonumber(playerData.skin) or 0)
            ent.bodyEnt:SetupBones()
            LZY_CC_ApplyPreviewBodyTattoo(ent, playerData)
        end
    end

    local hairStyles = LZY_CHARACTER_CONFIG.GetAvailableHairStyles(playerData.gender)
    local hairModel = playerData.hair_model or (hairStyles and hairStyles[1] and hairStyles[1].model)
    if hairModel then
        ent.hairEnt = ClientsideModel(hairModel, RENDERGROUP_OPAQUE)
        if IsValid(ent.hairEnt) then
            TrackClientsideModel(ent.hairEnt)
            ent.hairEnt:SetParent(ent)
            ent.hairEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
            ApplyHairGradientToPreview(ent, ent.hairEnt, playerData.hair_color1, playerData.hair_color2, playerData.hair_gradient_angle, playerData.hair_details_color)
            -- Respecte l'état hide_hair stocké (défini via l'inventaire) : masque les cheveux du preview.
            if tonumber(playerData.hide_hair) == 1 then ent.hairEnt:SetNoDraw(true) end
        end
    end

    if LZY_CHARACTER_CONFIG.NormalizeGender(playerData.gender) ~= "female" then
        local bm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(playerData.beard_model or ""))
        local mm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(playerData.mustache_model or ""))
        if bm ~= "" then
            ent.beardEnt = ClientsideModel(bm, RENDERGROUP_OPAQUE)
            if IsValid(ent.beardEnt) then
                TrackClientsideModel(ent.beardEnt)
                ent.beardEnt:SetParent(ent)
                ent.beardEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                ApplyHairGradientToPreview(ent, ent.beardEnt, playerData.hair_color1, playerData.hair_color2, playerData.hair_gradient_angle, playerData.hair_details_color)
            end
        end
        if mm ~= "" then
            ent.mustacheEnt = ClientsideModel(mm, RENDERGROUP_OPAQUE)
            if IsValid(ent.mustacheEnt) then
                TrackClientsideModel(ent.mustacheEnt)
                ent.mustacheEnt:SetParent(ent)
                ent.mustacheEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                ApplyHairGradientToPreview(ent, ent.mustacheEnt, playerData.hair_color1, playerData.hair_color2, playerData.hair_gradient_angle, playerData.hair_details_color)
            end
        end
    end

    -- Accessoires équipés : montrer ce que le perso PORTE dans le HUB de sélection (la liste de
    -- persos charge déjà equipped_accessories côté serveur, cf. GetCharactersList). Bonemergés comme
    -- le corps/cheveux. Stockés en CHAMPS-ENTITÉ ent._lzyAccEnt<slot> -> nettoyés par
    -- DestroyPreviewModel ET par removeChar/buildScene de ncm_char_select (itèrent les champs-entité).
    if istable(playerData.equipped_accessories) then
        local accSkins = playerData.equipped_accessory_skins
        for slotKey, modelPath in pairs(playerData.equipped_accessories) do
            if isstring(modelPath) and modelPath ~= "" then
                local accEnt = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
                if IsValid(accEnt) then
                    TrackClientsideModel(accEnt)
                    local sk = istable(accSkins) and tonumber(accSkins[slotKey])
                    if sk then accEnt:SetSkin(sk) end
                    local petCfg = LZY_CHARACTER_CONFIG.GetShoulderPet and LZY_CHARACTER_CONFIG.GetShoulderPet(modelPath)
                    if petCfg and LZY_Character_SetupPetPart then
                        -- Pet d'épaule : attache décidée par le module pets de cl_models
                        -- (bonemerge, cf. PET_ATTACH.mode) + animé par son Think (dessiné par le moteur ici).
                        local offs = playerData.equipped_accessory_offsets
                        LZY_Character_SetupPetPart(ent, accEnt, petCfg, istable(offs) and offs[tostring(slotKey)] or nil)
                    else
                        accEnt:SetParent(ent)
                        accEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                        accEnt:SetupBones()
                    end
                    ent["_lzyAccEnt" .. tostring(slotKey)] = accEnt
                end
            end
        end
    end

    -- ÉPAULETTE DE GRADE (scène de sélection / HUB) : accessoire bonemergé par FACTION + tier de
    -- grade, comme en jeu (cl_models EnsureDetailParts). La liste de persos porte faction/rank
    -- (GetCharactersList) -> résolue via GetEpauletteModelForCharacter (gère aussi la coche « cacher »,
    -- champ hide_epaulette). En CRÉATION/édition (pas de rank) -> renvoie nil (no-op). Bonemergée
    -- SANS FASTCULL (comme le corps après buildScene) pour ne pas se détacher sur un slot surélevé.
    -- Stockée en champ-entité -> nettoyée par removeChar/DestroyPreviewModel (itèrent GetTable()).
    if LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter then
        local epaulette = LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter(playerData, nil)
        if isstring(epaulette) and epaulette ~= "" then
            ent.epauletteEnt = ClientsideModel(epaulette, RENDERGROUP_OPAQUE)
            if IsValid(ent.epauletteEnt) then
                TrackClientsideModel(ent.epauletteEnt)
                ent.epauletteEnt:SetParent(ent)
                ent.epauletteEnt:AddEffects(EF_BONEMERGE)
                ent.epauletteEnt:SetupBones()
            end
        end
    end

    -- Brassard de VICE-CAPITAINE (grade 14 Shinigami, skin PAR DIVISION) : même rendu qu'en jeu.
    -- playerData porte faction/rank/division (liste char-select). En création (pas de rank) -> nil.
    if LZY_CHARACTER_CONFIG.GetBrassardForCharacter then
        local brassard, bskin = LZY_CHARACTER_CONFIG.GetBrassardForCharacter(playerData)
        if isstring(brassard) and brassard ~= "" then
            ent.brassardEnt = ClientsideModel(brassard, RENDERGROUP_OPAQUE)
            if IsValid(ent.brassardEnt) then
                TrackClientsideModel(ent.brassardEnt)
                ent.brassardEnt:SetParent(ent)
                if bskin then ent.brassardEnt:SetSkin(bskin) end
                ent.brassardEnt:AddEffects(EF_BONEMERGE)
                ent.brassardEnt:SetupBones()
            end
        end
    end

    -- Corps ESPADA (capitaine Arrancar/Hollow grades 15-16, skin PAR ORDRE) : même rendu qu'en jeu.
    -- playerData porte faction/rank/division (liste char-select du HUB). En création (grade 1) -> nil.
    if LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter then
        local espada, eskin = LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter(playerData)
        if isstring(espada) and espada ~= "" then
            ent.espadaEnt = ClientsideModel(espada, RENDERGROUP_OPAQUE)
            if IsValid(ent.espadaEnt) then
                TrackClientsideModel(ent.espadaEnt)
                ent.espadaEnt:SetParent(ent)
                if eskin then ent.espadaEnt:SetSkin(eskin) end
                ent.espadaEnt:AddEffects(EF_BONEMERGE)
                ent.espadaEnt:SetupBones()
            end
        end
    end

    -- HAORI de capitaine (Shinigami grade 15+, un modèle par division) : même rendu qu'en jeu.
    -- En création le grade vaut 1 -> nil, aucun haori sur l'aperçu.
    if LZY_CHARACTER_CONFIG.GetHaoriForCharacter then
        local haori = LZY_CHARACTER_CONFIG.GetHaoriForCharacter(playerData)
        if isstring(haori) and haori ~= "" then
            ent.haoriEnt = ClientsideModel(haori, RENDERGROUP_OPAQUE)
            if IsValid(ent.haoriEnt) then
                TrackClientsideModel(ent.haoriEnt)
                ent.haoriEnt:SetParent(ent)
                ent.haoriEnt:AddEffects(EF_BONEMERGE)
                ent.haoriEnt:SetupBones()
            end
        end
    end

    -- CAPE DU ROI DU HUECO MUNDO (Hollow grade 16) : même rendu qu'en jeu. En création le grade
    -- vaut 1 -> nil, aucune cape sur l'aperçu. Champ-entité obligatoire (comme haoriEnt) :
    -- la purge de ncm_char_select itère GetTable().
    if LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter then
        local cape = LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter(playerData)
        if isstring(cape) and cape ~= "" then
            ent.hollowKingCapeEnt = ClientsideModel(cape, RENDERGROUP_OPAQUE)
            if IsValid(ent.hollowKingCapeEnt) then
                TrackClientsideModel(ent.hollowKingCapeEnt)
                ent.hollowKingCapeEnt:SetParent(ent)
                ent.hollowKingCapeEnt:AddEffects(EF_BONEMERGE)
                ent.hollowKingCapeEnt:SetupBones()
            end
        end
    end

    -- ACCESSOIRE BODY DE DIVISION (tout membre d'une division/ordre) : même rendu qu'en jeu.
    -- ⚠️ Ce builder sert AUSSI la scène 3D de sélection (LZY_CreateClientsideCharacter), c'est
    -- même le SEUL chemin du HUB : l'oublier ici le rendait invisible au choix de perso.
    -- En création la division vaut « Aucune » -> nil, rien ne s'affiche.
    -- Champ-entité obligatoire (comme haoriEnt) : la purge de ncm_char_select itère GetTable().
    if LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter then
        local divBody = LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter(playerData)
        if isstring(divBody) and divBody ~= "" then
            ent.divisionBodyEnt = ClientsideModel(divBody, RENDERGROUP_OPAQUE)
            if IsValid(ent.divisionBodyEnt) then
                TrackClientsideModel(ent.divisionBodyEnt)
                ent.divisionBodyEnt:SetParent(ent)
                ent.divisionBodyEnt:AddEffects(EF_BONEMERGE)
                ent.divisionBodyEnt:SetupBones()
            end
        end
    end

    -- Masque de base ARRANCAR (tout Hollow ; modèle dédié pour les Espadas 15-16) : même rendu qu'en
    -- jeu sur la SCÈNE DE SÉLECTION (HUB / ncm_char_select). PAS dans le créateur/éditeur : la face
    -- doit rester libre à la création (et en barber) — `frame` n'est valide que tant que
    -- LZY_CharacterCreator est ouvert ; char-select appelle ce builder avec frame = nil.
    if not IsValid(frame) and LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter then
        local masque = LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter(playerData)
        if isstring(masque) and masque ~= "" then
            ent.arrancarMaskEnt = ClientsideModel(masque, RENDERGROUP_OPAQUE)
            if IsValid(ent.arrancarMaskEnt) then
                TrackClientsideModel(ent.arrancarMaskEnt)
                ent.arrancarMaskEnt:SetParent(ent)
                ent.arrancarMaskEnt:AddEffects(EF_BONEMERGE)
                ent.arrancarMaskEnt:SetupBones()
            end
        end
    end

    ent.EyesColor = playerData.eyes_color or Color(255, 255, 255)

    return ent
end

-- Exposé pour ncm_char_select : réutilise le builder composite éprouvé (rend bien
-- en monde). Renvoie l'ent visage avec .bodyEnt/.hairEnt/.beardEnt/.mustacheEnt ;
-- l'appelant gère le nettoyage (Remove sur l'ent + ses enfants).
LZY_CreateClientsideCharacter = createClientsidePlayerModel

-- Camera configuration for the character creator preview
local CHARACTER_VIEW_DISTANCE = 110
local CHARACTER_VIEW_ZOOM_MIN = 10
local CHARACTER_VIEW_ZOOM_MAX = 110 -- same as default distance; cannot zoom out past this
local CHARACTER_VIEW_ZOOM_SPEED = 12
local CHARACTER_VIEW_HEIGHT = 45
local CHARACTER_VIEW_SIDE_OFFSET = -40 -- negative = a bit to the left of the model (at default distance)
local CHARACTER_VIEW_YAW_ANGLE = 10 -- how much to yaw toward the player when offset to the side
local CHARACTER_VIEW_ZOOM_LIFT = 20 -- when zoomed in, raise camera this much (world units) so zoom feels toward the head
-- Distance "auto" appliquee selon l'etape : corps entier sur Page 2 (nom/taille),
-- cadre visage sur Page 3 (categories d'apparence). Anime via previewZoomTarget
-- dans PANEL:Think ; le scroll molette reprend la main des qu'on l'utilise.
local CHARACTER_VIEW_ZOOM_BODY = CHARACTER_VIEW_DISTANCE -- dezoom corps entier (Page 2)
local CHARACTER_VIEW_ZOOM_FACE = 46 -- zoom visage (Page 3)
local CHARACTER_VIEW_ZOOM_LERP = 8 -- vitesse d'interpolation de l'auto-zoom

local function GetPreviewModelHeadPosition(ent)
    local headBoneNames = { "ValveBiped.Bip01_Head", "bip_head", "Bip01 Head", "head" }
    for _, name in ipairs(headBoneNames) do
        local boneId = ent:LookupBone(name)
        if boneId and boneId >= 0 then
            local pos = ent:GetBonePosition(boneId)
            if pos then return pos end
        end
    end
    -- Fallback: approximate head height using base height scaled by character scale
    local scale = characterData and characterData.scale or 1
    return ent:GetPos() + Vector(0, 0, CHARACTER_VIEW_HEIGHT * scale)
end

local function GetCharacterCreatorView()
    if not IsValid(frame) or not IsValid(frame.previewModel) then return nil end

    if frame.previewZoom == nil then
        frame.previewZoom = CHARACTER_VIEW_DISTANCE
    end
    local distance = math.Clamp(frame.previewZoom, CHARACTER_VIEW_ZOOM_MIN, CHARACTER_VIEW_ZOOM_MAX)

    -- Scale side offset with distance so the model keeps the same position on screen when zooming
    local sideOffset = CHARACTER_VIEW_SIDE_OFFSET * (distance / CHARACTER_VIEW_DISTANCE)

    local targetPos = GetPreviewModelHeadPosition(frame.previewModel)
    -- Use the model's base angles for the camera so rotating the model
    -- with the mouse does not rotate the camera around it.
    local plyAng = frame.previewModel.baseAngles or frame.previewModel:GetAngles()

    local baseForward = -plyAng:Forward()
    local camAngles = baseForward:Angle()
    if CHARACTER_VIEW_SIDE_OFFSET ~= 0 and CHARACTER_VIEW_YAW_ANGLE ~= 0 then
        if CHARACTER_VIEW_SIDE_OFFSET < 0 then
            camAngles.y = camAngles.y + CHARACTER_VIEW_YAW_ANGLE
        else
            camAngles.y = camAngles.y - CHARACTER_VIEW_YAW_ANGLE
        end
    end

    local camForward = camAngles:Forward()
    local camRight = camAngles:Right()

    local camPos = targetPos - camForward * distance + camRight * sideOffset

    -- When zoomed in, raise the camera a bit so the zoom motion goes toward the head.
    -- Scale this lift by the character's current scale so it stays centered on the head.
    local liftFrac = 1 - math.Clamp((distance - CHARACTER_VIEW_ZOOM_MIN) / (CHARACTER_VIEW_DISTANCE - CHARACTER_VIEW_ZOOM_MIN), 0, 1)
    local scale = characterData and characterData.scale or 1
    local scaledLift = CHARACTER_VIEW_ZOOM_LIFT * scale
    camPos = camPos + Vector(0, 0, scaledLift * liftFrac)

    -- Use fixed view direction (with yaw) so the side offset keeps the model off-center; scaling sideOffset with distance keeps that screen position when zooming
    local view = {}
    view.origin = camPos
    view.angles = camAngles
    view.fov = 60

    return view
end

hook.Add("CalcView", "LZY_CharacterCreator_CalcView", function(ply, pos, ang, fov)
    -- Only override the view while the character creator is open and a preview model exists
    if not IsValid(frame) or not frame:IsVisible() or not IsValid(frame.previewModel) then return end

    local view = GetCharacterCreatorView()
    if view then
        view.drawviewer = true
        return view
    end
end)

-- Masque les AUTRES joueurs tant que le créateur/éditeur est ouvert. La création initiale est
-- isolée dans son instance (aucun joueur autour), mais les PNJ métier (coiffeur, tatoueur,
-- chirurgien esthétique/sculpteur) ouvrent le MÊME éditeur EN PLEIN MONDE -> sans ça on voit les
-- joueurs passer autour pendant qu'on s'édite la tête. PrePlayerDraw -> true saute tout le
-- composite (les parts bonemergées sont SetNoDraw + dessinées dans le RenderOverride du joueur,
-- donc cachées avec lui). Le previewModel est un ClientsideModel, pas un joueur -> non affecté.
hook.Add("PrePlayerDraw", "LZY_CharacterCreator_HideOtherPlayers", function(drawnPly)
    if not IsValid(frame) or not frame:IsVisible() then return end
    if drawnPly == LocalPlayer() then return end
    return true
end)

-- Converts a bodygroup submodel index to a single character used by Entity:SetBodyGroups.
-- 0-9 -> "0"-"9", 10-35 -> "a"-"z" (values are clamped into this range).
local function EncodeBodygroupIndexToChar(val)
    local num = tonumber(val) or 0
    if num < 0 then num = 0 end
    if num > 35 then num = 35 end

    if num <= 9 then
        return string.char(string.byte("0") + num)
    else
        return string.char(string.byte("a") + (num - 10))
    end
end

-- Builds a SetBodyGroups string for the face model. Pupils use the first "eyes" submodel; texture is stored separately (submaterial index in save blob).
local function BuildFaceBodygroupsStringFromEntity(ent, namedBodygroups)
    if not IsValid(ent) or not namedBodygroups then return nil end

    local count = ent:GetNumBodyGroups() or 0
    if count <= 0 then return nil end

    local chars = {}
    for i = 1, count do
        chars[i] = EncodeBodygroupIndexToChar(0)
    end

    local eyesId = GetEyesBodygroupId(ent)
    if eyesId ~= nil then
        chars[eyesId + 1] = EncodeBodygroupIndexToChar(0)
    end

    return table.concat(chars)
end

-- Keeps characterData.bodygroupsString in sync with characterData.bodygroups so we can later do
-- ent:SetBodyGroups(characterData.bodygroupsString) directly.
local function RefreshEncodedBodygroups()
    local named = characterData.bodygroups
    if not named then return end

    if frame and IsValid(frame.previewModel) then
        characterData.bodygroupsString = BuildFaceBodygroupsStringFromEntity(frame.previewModel, named)
        return
    end

    local model = characterData.face_model or (LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender))
    if not model then return end

    local temp = ClientsideModel(model, RENDERGROUP_OTHER)
    if not IsValid(temp) then return end
    TrackClientsideModel(temp)
    temp:SetNoDraw(true)
    characterData.bodygroupsString = BuildFaceBodygroupsStringFromEntity(temp, named)
    temp:Remove()
end

local function ResetCharacterDataToDefaults()
    characterData.firstname = defaultCharacterData.firstname
    characterData.lastname = defaultCharacterData.lastname
    characterData.scale = defaultCharacterData.scale
    characterData.age_start = defaultCharacterData.age_start
    characterData.skin_color = defaultCharacterData.skin_color
    characterData.hair_color1 = defaultCharacterData.hair_color1
    characterData.hair_color2 = defaultCharacterData.hair_color2
    characterData.hair_details_color = defaultCharacterData.hair_details_color
    characterData.hair_gradient_angle = defaultCharacterData.hair_gradient_angle
    characterData.eyes_color = defaultCharacterData.eyes_color
    characterData.gender = defaultCharacterData.gender
    characterData.face_model = defaultCharacterData.face_model
    characterData.body_model = defaultCharacterData.body_model
    characterData.hair_model = defaultCharacterData.hair_model
    characterData.beard_model = defaultCharacterData.beard_model
    characterData.mustache_model = defaultCharacterData.mustache_model
    characterData.faction = defaultCharacterData.faction
    characterData.bodygroups = table.Copy(defaultCharacterData.bodygroups or {})
    characterData.bodygroupsString = defaultCharacterData.bodygroupsString
    characterData.shape_keys = defaultCharacterData.shape_keys
    characterData.shapeKeysByName = table.Copy(defaultCharacterData.shapeKeysByName or {})
    characterData.pupils_texture = defaultCharacterData.pupils_texture
    characterData.pupils_separate = defaultCharacterData.pupils_separate
    characterData.pupil_left = defaultCharacterData.pupil_left
    characterData.pupil_right = defaultCharacterData.pupil_right
    characterData.unique_id = nil
    characterData._animSlot = nil
    -- Champs d'IDENTITÉ / PROGRESSION / VISUEL absents des défauts (donc jamais réinitialisés
    -- autrement) : ils sont écrits dans characterData par les modes ÉDITION (barber/sculpteur via
    -- `for k,v in pairs(LZY_CHARACTER_BARBER_DATA)`, ou le resume d'animation) à partir d'un perso
    -- EXISTANT. Sans ce nettoyage, créer un NOUVEAU perso juste après avoir un perso grade 2+ fait
    -- FUITER son uniforme de grade (RANK_OUTFITS) sur l'aperçu du créateur — GetDisplayBodyModelFromData
    -- lit rank/division/base_body_model. (Idem accessoires équipés.) On remet à l'état d'un perso
    -- neuf : grade 1, aucune tenue/accessoire d'inventaire -> corps de base.
    -- rank = 1 (et non nil) : un perso neuf EST grade 1, et depuis la tenue academy Arrancar
    -- le grade 1 a un uniforme -> l'aperçu doit montrer ce qu'il portera au spawn. Sans grade,
    -- le resolveur ne rendait aucun uniforme et l'aperçu affichait la tenue de grade 2.
    -- Shinigami inchangé : leur 1er uniforme est au grade 2, donc rien ne s'applique au 1.
    characterData.rank = 1
    characterData.division = nil
    characterData.base_body_model = nil
    characterData.equipped_accessories = nil
    characterData.equipped_accessory_skins = nil
    for _, s in ipairs({ "", "_2", "_3" }) do
        characterData["tattoo_texture" .. s] = defaultCharacterData["tattoo_texture" .. s]
        characterData["tattoo_color"   .. s] = defaultCharacterData["tattoo_color"   .. s]
        characterData["tattoo_pos_x"   .. s] = defaultCharacterData["tattoo_pos_x"   .. s]
        characterData["tattoo_pos_y"   .. s] = defaultCharacterData["tattoo_pos_y"   .. s]
        characterData["tattoo_scale_x" .. s] = defaultCharacterData["tattoo_scale_x" .. s]
        characterData["tattoo_scale_y" .. s] = defaultCharacterData["tattoo_scale_y" .. s]
        characterData["tattoo_opacity" .. s] = defaultCharacterData["tattoo_opacity" .. s]
        characterData["tattoo_rotation" .. s] = defaultCharacterData["tattoo_rotation" .. s]
    end
    characterData.body_tattoos = {}
    RefreshEncodedBodygroups()
end

-- Tatouages du corps sur l'aperçu (créateur / tatoueur / sélection de perso). Clé de RT par
-- perso (unique_id) : plusieurs persos affichés en même temps ne se partagent pas la texture.
-- Global (pas de local fichier : fichier proche de la limite Lua des 200 locales).
function LZY_CC_ApplyPreviewBodyTattoo(ent, data)
    if not (LZY_ApplyBodyTattoo and IsValid(ent) and IsValid(ent.bodyEnt)) then return end
    local sKey = ent._lzyStableTatKey or ("c" .. string.gsub(tostring(istable(data) and data.unique_id or "creator"), "[^%w_]", ""))
    LZY_ApplyBodyTattoo(ent.bodyEnt, data, sKey, LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE or 2048)
end

-- Creates a custom slider (slider_bg track + slider_cursor thumb). Returns the panel.
-- storageTable[storageKey] is read for initial value and written when the value changes.
local function CreateSlider(parent, x, y, w, h, min, max, step, storageTable, storageKey, updateFunction, labelText, leftIconMaterial, leftIconW, leftIconH, rightIconMaterial, rightIconW, rightIconH)
    local label = vgui.Create("DLabel", parent)
    -- Hauteur mini 40 : la police Inter:30 était COUPÉE quand l'appelant passe un h
    -- petit (les 2 sliders tatouage passent h=14 -> "Opacité"/"Rotation" tronqués).
    -- Le slider commence à y+40, donc un label de 40 ne chevauche jamais.
    label:gSetSize(w, math.max(h, 40))
    label:gSetPos(x, y)
    label:SetText(labelText)
    label:SetFont("Inter:30")
    label:SetTextColor(Color(255, 255, 255, 255))
    label:SetTextInset(0, 0)
    label:SetContentAlignment(TEXT_ALIGN_LEFT)

    y = y + 40

    if leftIconMaterial and leftIconW and leftIconH then
        local leftIcon = vgui.Create("DButton", parent)
        leftIcon:gSetSize(leftIconW, leftIconH)
        leftIcon:gSetPos(x, y + (h - leftIconH) / 2)
        leftIcon:SetText("")
        leftIcon.Paint = function(selff, w, h)
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), leftIconMaterial)
        end
    end
    if rightIconMaterial and rightIconW and rightIconH then
        local rightIcon = vgui.Create("DButton", parent)
        rightIcon:gSetSize(rightIconW, rightIconH)
        rightIcon:gSetPos(x + w - rightIconW, y + (h - rightIconH) / 2)
        rightIcon:SetText("")
        rightIcon.Paint = function(selff, w, h)
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), rightIconMaterial)
        end
    end

    -- Quelques morphs du modèle sont montés à l'envers : leur valeur 0 donne
    -- l'effet MAXIMUM. Le curseur partait donc à droite pour raccourcir le menton
    -- et rétrécir la bouche, alors que tous les autres font l'inverse.
    -- On retourne la valeur entre le curseur et le modèle, ici et une seule fois :
    -- les appelants n'ont rien à savoir, et la correction ne peut pas être oubliée
    -- si un de ces curseurs est recréé ailleurs.
    local MORPHS_INVERSES = { Mouth_shape3 = true, Chin_shape1 = true }
    local bInverse = MORPHS_INVERSES[storageKey] == true
    -- Symétrique : marche dans les deux sens, quelle que soit l'échelle du curseur.
    local function versAutreSens(v)
        if not bInverse or not isnumber(v) then return v end
        return min + max - v
    end
    if bInverse then
        local fVraie = updateFunction
        updateFunction = function(cle, v) return fVraie(cle, versAutreSens(v)) end
    end
    -- La valeur enregistrée est dans le repère du MODÈLE : on la ramène dans
    -- celui du curseur pour poser le bouton au bon endroit à l'ouverture.
    local function valeurEnregistree()
        local v = storageTable[storageKey]
        if v == nil then return nil end
        return versAutreSens(v)
    end

    updateFunction(storageKey, valeurEnregistree() or min)

    local slider = vgui.Create("DPanel", parent)
    slider:gSetSize(w, h)
    slider:gSetPos(x, y)
    slider.SliderMin = min
    slider.SliderMax = max
    slider.SliderStep = step
    slider.TrackMarginLeft = leftIconW and leftIconW + 5 or 0
    slider.TrackMarginRight = rightIconW and rightIconW + 5 or 0
    do
        local v = valeurEnregistree()
        if v == nil then
            v = min
        end
        v = min + math.Round((v - min) / step) * step
        slider.SliderValue = math.Clamp(v, min, max)
        updateFunction(storageKey, slider.SliderValue)
    end
    slider.Dragging = false
    slider.Paint = function(selff, pw, ph)
        local marginL, marginR = gRespX(selff.TrackMarginLeft), gRespX(selff.TrackMarginRight)
        local trackX, trackW = marginL, pw - marginL - marginR
        local trackH = gRespY(7)
        local cursorW, cursorH = gRespX(13), gRespY(13)
        local trackY = (ph - trackH) / 2
        RNDX.DrawMaterial(0, trackX, trackY, trackW, trackH, Color(255, 255, 255, 255), materials.slider_bg)
        local frac = (selff.SliderValue - selff.SliderMin) / (selff.SliderMax - selff.SliderMin)
        frac = math.Clamp(frac, 0, 1)
        if selff.Invert then frac = 1 - frac end -- barre inversée (sens visuel seul ; la valeur stockée/appliquée ne change pas)
        local cursorX = trackX + frac * (trackW - cursorW)
        local cursorY = (ph - cursorH) / 2
        RNDX.DrawMaterial(0, cursorX, cursorY, cursorW, cursorH, Color(255, 255, 255, 255), materials.slider_cursor)
    end
    slider.Think = function(selff)
        if not selff.Dragging then return end
        if not input.IsMouseDown(MOUSE_LEFT) then
            selff.Dragging = false
            return
        end
        local mx = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
        local pw = selff:GetWide()
        local marginL, marginR = gRespX(selff.TrackMarginLeft), gRespX(selff.TrackMarginRight)
        local trackX, trackW = marginL, pw - marginL - marginR
        local cursorW = gRespX(13)
        local frac = (mx - trackX - cursorW / 2) / (trackW - cursorW)
        frac = math.Clamp(frac, 0, 1)
        if selff.Invert then frac = 1 - frac end -- barre inversée : glisser à droite = valeur basse
        local rawVal = selff.SliderMin + frac * (selff.SliderMax - selff.SliderMin)
        local val = selff.SliderMin + math.Round((rawVal - selff.SliderMin) / selff.SliderStep) * selff.SliderStep
        val = math.Clamp(val, selff.SliderMin, selff.SliderMax)
        if val ~= selff.SliderValue then
            selff.SliderValue = val
            updateFunction(storageKey, val)
        end
    end
    slider.OnMousePressed = function(selff, mc)
        if mc ~= MOUSE_LEFT then return end
        selff.Dragging = true
        local mx = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
        local pw = selff:GetWide()
        local marginL, marginR = gRespX(selff.TrackMarginLeft), gRespX(selff.TrackMarginRight)
        local trackX, trackW = marginL, pw - marginL - marginR
        local cursorW = gRespX(13)
        local frac = (mx - trackX - cursorW / 2) / (trackW - cursorW)
        frac = math.Clamp(frac, 0, 1)
        if selff.Invert then frac = 1 - frac end -- barre inversée : glisser à droite = valeur basse
        local rawVal = selff.SliderMin + frac * (selff.SliderMax - selff.SliderMin)
        local val = selff.SliderMin + math.Round((rawVal - selff.SliderMin) / selff.SliderStep) * selff.SliderStep
        val = math.Clamp(val, selff.SliderMin, selff.SliderMax)
        selff.SliderValue = val
        updateFunction(storageKey, val)
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
    end
    slider.OnMouseReleased = function(selff, mc)
        if mc == MOUSE_LEFT then
            selff.Dragging = false
        end
    end
    slider.GetValue = function(selff)
        return selff.SliderValue
    end
    slider.SetValue = function(selff, val)
        local snapped = selff.SliderMin + math.Round((val - selff.SliderMin) / selff.SliderStep) * selff.SliderStep
        selff.SliderValue = math.Clamp(snapped, selff.SliderMin, selff.SliderMax)
        updateFunction(storageKey, selff.SliderValue)
    end
    slider._layoutLabel = label
    return slider
end

-- Creates a styled text input (input_bg, placeholder, cursor, clear button). Returns the DTextEntry panel.
-- storageTable[storageKey] is read for initial text and written on Enter/LoseFocus/Clear.
-- Optional onAfterCommit(selff, storageKey) runs after each commit (including clear).
local function CreateStyledInput(parent, x, y, w, h, placeholderText, storageTable, storageKey, updateFunction, onAfterCommit)
    updateFunction(storageKey, storageTable[storageKey] or "")
    local input = vgui.Create("DTextEntry", parent)
    input:gSetSize(w, h)
    input:gSetPos(x, y)
    input:SetText(storageTable[storageKey])
    input.PlaceholderText = placeholderText
    input:SetUpdateOnType(true)
    if input.SetDrawLanguageID then input:SetDrawLanguageID(false) end
    input.Paint = function(selff, pw, ph)
        if selff:IsEditing() or selff:IsHovered() then
            RNDX.DrawMaterial(0, 0, 0, pw, ph, Color(255, 255, 255, 255), materials.input_bg_active)
        else
            RNDX.DrawMaterial(0, 0, 0, pw, ph, Color(255, 255, 255, 255), materials.input_bg)
        end
        local text = selff:GetText()
        local displayText = (text ~= "" or selff:IsEditing()) and text or selff.PlaceholderText
        local color = (text ~= "" or selff:IsEditing()) and Color(255, 255, 255, 255) or Color(255, 255, 255, 30)
        draw.SimpleText(displayText, "Inter:25", gRespX(15), ph / 2, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        if selff:IsEditing() then
            local font = "Inter:25"
            local fullText = text ~= "" and text or ""
            local caretPos = selff:GetCaretPos()
            local textBeforeCaret = string.sub(fullText, 1, caretPos)
            surface.SetFont(font)
            local beforeW = surface.GetTextSize(textBeforeCaret)
            local cursorX = gRespX(15) + beforeW
            if math.floor(CurTime() * 2.5) % 2 == 0 then
                local padY = (ph - select(2, surface.GetTextSize("W"))) / 2
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect(cursorX, padY, 2, ph - padY * 2)
            end
        end
    end
    local function commitStyledInput(selff)
        updateFunction(storageKey, selff:GetText())
        if onAfterCommit then onAfterCommit(selff, storageKey) end
    end
    input.OnEnter = commitStyledInput
    input.OnLoseFocus = commitStyledInput
    input.OnChange = function(selff)
        if IsValid(selff.clearBtn) then
            selff.clearBtn:SetVisible(selff:GetText() ~= "")
        end
    end
    input.OnValueChange = function(selff)
        if IsValid(selff.clearBtn) then
            selff.clearBtn:SetVisible(selff:GetText() ~= "")
        end
    end
    local clearBtn = vgui.Create("DButton", input)
    clearBtn:gSetSize(40, 40)
    clearBtn:gSetPos(518, 20)
    clearBtn:SetText("")
    clearBtn:SetVisible(input:GetText() ~= "")
    input.clearBtn = clearBtn
    clearBtn.Paint = function(btn, bw, bh)
        if not btn:IsVisible() then return end
        local mat = materials.input_clear_btn
        if btn:IsHovered() then
            surface.SetDrawColor(255, 255, 255, 200)
        else
            surface.SetDrawColor(255, 255, 255, 255)
        end
        surface.SetMaterial(mat)
        surface.DrawTexturedRect(0, 0, bw, bh)
    end
    clearBtn.DoClick = function()
        input:SetText("")
        input:SetCaretPos(0)
        updateFunction(storageKey, "")
        if onAfterCommit then onAfterCommit(input, storageKey) end
        clearBtn:SetVisible(false)
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
    end
    return input
end

-- Creates a color selector: label text on top, then a list of color squares with white stroke.
-- storageTable[storageKey] holds the selected color *id*.
-- availableColors is a table of entries like { id = <number>, color = Color(...) }.
-- Returns the container panel.
local function CreateColorSelector(parent, x, y, areaWidth, storageTable, storageKey, updateFunction, availableColors, labelText)
    -- Initialize with current id or first entry's id
    local currentId = storageTable[storageKey]
    if currentId == nil and availableColors[1] then
        currentId = availableColors[1].id or 0
        updateFunction(storageKey, currentId)
    end
    local slotSize = 36
    local spacing = 8
    local strokeWidth = 1
    local labelHeight = 28
    local slotsPerRow = math.floor((areaWidth + spacing) / (slotSize + spacing))

    local numColors = #availableColors
    local numRows = math.ceil(numColors / slotsPerRow)
    local totalHeight = labelHeight + spacing + numRows * (slotSize + spacing) - spacing

    local container = vgui.Create("DPanel", parent)
    container:gSetPos(x, y)
    container:gSetSize(areaWidth, totalHeight)
    container.Paint = function() end

    local label = vgui.Create("DLabel", container)
    label:gSetPos(0, 0)
    label:gSetSize(areaWidth, labelHeight)
    label:SetText(labelText)
    label:SetFont("Inter:30")
    label:SetTextColor(Color(255, 255, 255, 255))

    for i, entry in ipairs(availableColors) do
        local color = entry.color or entry
        local colorId = entry.id
        local row = math.floor((i - 1) / slotsPerRow)
        local col = (i - 1) % slotsPerRow
        local px = col * (slotSize + spacing)
        local py = labelHeight + spacing + row * (slotSize + spacing)

        local btn = vgui.Create("DButton", container)
        btn:gSetPos(px, py)
        btn:gSetSize(slotSize, slotSize)
        btn:SetText("")
        btn.ColorId = colorId
        btn.ColorValue = color
        btn.Paint = function(selff, w, h)
            local curId = storageTable[storageKey]
            local isSelected = (curId ~= nil) and (curId == selff.ColorId)
            local drawColor = selff.ColorValue
            surface.SetDrawColor(drawColor.r, drawColor.g, drawColor.b, drawColor.a)
            surface.DrawRect(strokeWidth, strokeWidth, w - strokeWidth * 2, h - strokeWidth * 2)
            surface.SetDrawColor(255, 255, 255, 255)
            local sw = isSelected and (strokeWidth + 3) or strokeWidth
            for s = 0, sw - 1 do
                surface.DrawOutlinedRect(s, s, w - s * 2, h - s * 2)
            end
        end
        btn.DoClick = function(selff)
            if selff.ColorId ~= nil then
                updateFunction(storageKey, selff.ColorId)
            end
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        end
    end

    return container
end

-- HSV (H,S,V in 0-1) <-> RGB helpers for color picker
local function HSVToRGB(h, s, v)
    if s <= 0 then return Color(v * 255, v * 255, v * 255, 255) end
    local i = math.floor(h * 6)
    local f = h * 6 - i
    i = i % 6
    local p = v * (1 - s)
    local q = v * (1 - s * f)
    local t = v * (1 - s * (1 - f))
    local r, g, b
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    else r, g, b = v, p, q
    end
    return Color(math.Round(r * 255), math.Round(g * 255), math.Round(b * 255), 255)
end

local function RGBToHSV(c)
    local r, g, b = c.r / 255, c.g / 255, c.b / 255
    local max, min = math.max(r, g, b), math.min(r, g, b)
    local v = max
    if max <= 0 then return 0, 0, 0 end
    local s = (max - min) / max
    local h
    if max == min then h = 0
    elseif max == r then h = (g - b) / (max - min) + (g < b and 6 or 0)
    elseif max == g then h = (b - r) / (max - min) + 2
    else h = (r - g) / (max - min) + 4
    end
    return (h / 6) % 1, s, v
end

local function ColorToHex(c)
    return string.format("%02X%02X%02X", math.Clamp(c.r, 0, 255), math.Clamp(c.g, 0, 255), math.Clamp(c.b, 0, 255))
end

local function HexToColor(hex)
    hex = hex:gsub("#", ""):upper()
    if #hex ~= 6 then return nil end
    local r = tonumber(hex:sub(1, 2), 16)
    local g = tonumber(hex:sub(3, 4), 16)
    local b = tonumber(hex:sub(5, 6), 16)
    if not r or not g or not b then return nil end
    return Color(r, g, b, 255)
end

-- Dark theme color picker: vertical hue strip, SV square, swatch + HEX input. storageTable[storageKey] = Color, updateFunction(storageKey, color).
local function createColorPicker(parent, x, y, w, h, storageTable, storageKey, updateFunction, labelText)
    local c = storageTable[storageKey]
    if not c or type(c) ~= "table" or not c.r then c = Color(255, 150, 255, 255) end
    storageTable[storageKey] = c
    local H, S, V = RGBToHSV(c)
    local padding = 8
    local bottomPadding = 8
    local hueStripW = 24
    local bottomH = 36
    local labelH = (labelText and labelText ~= "") and 22 or 0
    local labelGap = 4
    local containerY = y + (labelH > 0 and (labelH + labelGap) or 0)
    local containerH = h - (labelH > 0 and (labelH + labelGap) or 0)
    local contentH = containerH - bottomH - padding * 2 - bottomPadding
    local svSize = math.min(contentH, w - hueStripW - padding * 3)
    local hueStripH = contentH

    -- Label outside (above) the color picker panel
    if labelH > 0 then
        local lbl = vgui.Create("DLabel", parent)
        lbl:gSetPos(x, y)
        lbl:gSetSize(w, labelH)
        lbl:SetText(labelText)
        lbl:SetFont("Inter:30")
        lbl:SetTextColor(Color(240, 240, 240, 255))
    end

    local container = vgui.Create("DPanel", parent)
    container:gSetPos(x, containerY)
    container:gSetSize(w, containerH)
    container.Paint = function(selff, pw, ph)
        surface.SetDrawColor(18, 18, 18, 255)
        surface.DrawRect(0, 0, pw, ph)
        surface.SetDrawColor(60, 60, 60, 255)
    end

    local curY = padding

    local hueStrip = vgui.Create("DPanel", container)
    hueStrip:gSetPos(padding, curY)
    hueStrip:gSetSize(hueStripW, hueStripH)
    hueStrip.Paint = function(selff, pw, ph)
        for i = 0, ph - 1 do
            local hue = 1 - (i / ph)
            local col = HSVToRGB(hue, 1, 1)
            surface.SetDrawColor(col.r, col.g, col.b, 255)
            surface.DrawRect(0, i, pw, 1)
        end
        surface.SetDrawColor(255, 255, 255, 200)
        local barY = (1 - H) * ph - 6
        barY = math.Clamp(barY, 0, ph - 12)
        surface.DrawRect(0, barY, pw, 12)
        surface.SetDrawColor(40, 40, 40, 255)
        surface.DrawOutlinedRect(0, 0, pw, ph)
    end
    hueStrip.OnMousePressed = function(selff, mc)
        if mc ~= MOUSE_LEFT then return end
        local _, my = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
        local ph = selff:GetTall()
        H = 1 - math.Clamp(my / ph, 0, 1)
        local col = HSVToRGB(H, S, V)
        storageTable[storageKey] = col
        if updateFunction then updateFunction(storageKey, col) end
    end
    hueStrip.Think = function(selff)
        if input.IsMouseDown(MOUSE_LEFT) and selff:IsHovered() then
            local _, my = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
            local ph = selff:GetTall()
            H = 1 - math.Clamp(my / ph, 0, 1)
            local col = HSVToRGB(H, S, V)
            storageTable[storageKey] = col
            if updateFunction then updateFunction(storageKey, col) end
        end
    end

    local svPanelW = w - padding * 2 - hueStripW - padding
    local svPanel = vgui.Create("DPanel", container)
    svPanel:gSetPos(padding + hueStripW + padding, curY)
    svPanel:gSetSize(svPanelW, svSize)
    svPanel.Paint = function(selff, pw, ph)
        local hueCol = HSVToRGB(H, 1, 1)
        local block = 4
        for py = 0, ph - 1, block do
            for px = 0, pw - 1, block do
                local sat = (px + block / 2) / pw
                local val = 1 - (py + block / 2) / ph
                sat = math.Clamp(sat, 0, 1)
                val = math.Clamp(val, 0, 1)
                local r = hueCol.r / 255 * sat + (1 - sat)
                local g = hueCol.g / 255 * sat + (1 - sat)
                local b = hueCol.b / 255 * sat + (1 - sat)
                r, g, b = r * val, g * val, b * val
                surface.SetDrawColor(r * 255, g * 255, b * 255, 255)
                surface.DrawRect(px, py, math.min(block, pw - px), math.min(block, ph - py))
            end
        end
        surface.SetDrawColor(40, 40, 40, 255)
        surface.DrawOutlinedRect(0, 0, pw, ph)
        local cx, cy = S * pw, (1 - V) * ph
        local curCol = HSVToRGB(H, S, V)
        surface.SetDrawColor(curCol.r, curCol.g, curCol.b, 255)
        for dy = -6, 6 do
            for dx = -6, 6 do
                if dx * dx + dy * dy <= 36 then
                    surface.DrawRect(math.Round(cx + dx), math.Round(cy + dy), 1, 1)
                end
            end
        end
        surface.SetDrawColor(255, 255, 255, 230)
        surface.DrawOutlinedRect(math.Round(cx - 7), math.Round(cy - 7), 14, 14)
    end
    svPanel.OnMousePressed = function(selff, mc)
        if mc ~= MOUSE_LEFT then return end
        local mx, my = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
        local pw, ph = selff:GetWide(), selff:GetTall()
        S = math.Clamp(mx / pw, 0, 1)
        V = 1 - math.Clamp(my / ph, 0, 1)
        local col = HSVToRGB(H, S, V)
        storageTable[storageKey] = col
        if updateFunction then updateFunction(storageKey, col) end
    end
    svPanel.Think = function(selff)
        if input.IsMouseDown(MOUSE_LEFT) and selff:IsHovered() then
            local mx, my = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
            local pw, ph = selff:GetWide(), selff:GetTall()
            S = math.Clamp(mx / pw, 0, 1)
            V = 1 - math.Clamp(my / ph, 0, 1)
            local col = HSVToRGB(H, S, V)
            storageTable[storageKey] = col
            if updateFunction then updateFunction(storageKey, col) end
        end
    end

    curY = curY + svSize + padding
    local swatchSize = bottomH - 4
    local swatch = vgui.Create("DPanel", container)
    swatch:gSetPos(padding, curY)
    swatch:gSetSize(swatchSize, swatchSize)
    swatch.Paint = function(selff, pw, ph)
        local col = storageTable[storageKey] or Color(255, 255, 255)
        surface.SetDrawColor(col.r, col.g, col.b, 255)
        surface.DrawRect(2, 2, pw - 4, ph - 4)
        surface.SetDrawColor(255, 255, 255, 180)
        surface.DrawOutlinedRect(0, 0, pw, ph)
    end

    local hexLabel = vgui.Create("DLabel", container)
    hexLabel:gSetPos(padding + swatchSize + 10, curY + (bottomH - 16) / 2)
    hexLabel:gSetSize(28, 16)
    hexLabel:SetText("HEX:")
    hexLabel:SetTextColor(Color(240, 240, 240, 255))

    local hexInput = vgui.Create("DTextEntry", container)
    hexInput:gSetPos(padding + swatchSize + 10 + 28, curY + 2)
    hexInput:gSetSize(w - (padding + swatchSize + 10 + 28 + padding), bottomH - 4)
    hexInput:SetText(ColorToHex(storageTable[storageKey] or c))
    hexInput:SetFont("DermaDefault")
    hexInput:SetTextColor(Color(255, 255, 255, 255))
    if hexInput.SetDrawLanguageID then hexInput:SetDrawLanguageID(false) end
    hexInput.Paint = function(selff, pw, ph)
        surface.SetDrawColor(30, 30, 30, 255)
        surface.DrawRect(0, 0, pw, ph)
        surface.SetDrawColor(80, 80, 80, 255)
        surface.DrawOutlinedRect(0, 0, pw, ph)
        selff:DrawTextEntryText(Color(255, 255, 255, 255), selff:GetHighlightColor(), Color(255, 255, 255, 255))
    end
    hexInput.OnEnter = function(selff)
        local hex = selff:GetText():gsub("%s", "")
        local col = HexToColor(hex)
        if col then
            H, S, V = RGBToHSV(col)
            storageTable[storageKey] = col
            if updateFunction then updateFunction(storageKey, col) end
        end
    end
    hexInput.OnLoseFocus = function(selff)
        hexInput.OnEnter(selff)
    end

    -- Keep HEX and swatch in sync when dragging (refresh from storage when not typing)
    container.Think = function(selff)
        if IsValid(hexInput) and not hexInput:IsEditing() then
            hexInput:SetText(ColorToHex(storageTable[storageKey] or c))
        end
    end

    return container
end

-- Shared 178x178 crosshair-picker scaffold for the tattoo Placement / Taille controls.
-- The image fills the DPanel at native resolution; the optional label sits above it.
local TATTOO_PICKER_IMAGE_SIZE = 178
local TATTOO_PICKER_LABEL_H   = 22
local TATTOO_PICKER_LABEL_GAP = 4

local function createTattooCrosshairPicker(parent, x, y, storageTable, updateFunction, labelText, opts)
	local mat = opts.material
	local getNorm = opts.getNorm        -- function(storageTable) -> nx, ny in [0..1]
	local applyNorm = opts.applyNorm    -- function(storageTable, nx, ny) -> commits to storage and returns update payload
	local fieldName = opts.fieldName    -- string passed to updateFunction

	local sz = TATTOO_PICKER_IMAGE_SIZE
	local labelH = (labelText and labelText ~= "") and TATTOO_PICKER_LABEL_H or 0
	local containerY = y + (labelH > 0 and (labelH + TATTOO_PICKER_LABEL_GAP) or 0)

	if labelH > 0 then
		local lbl = vgui.Create("DLabel", parent)
		lbl:gSetPos(x, y)
		lbl:gSetSize(sz, labelH)
		lbl:SetText(labelText)
		lbl:SetFont("Inter:30")
		lbl:SetTextColor(Color(240, 240, 240, 255))
	end

	-- (10/01) Plus de « seed » à l'ouverture : il réécrivait les valeurs bornées au pad
	-- (taille 0,3..2, position 0,4..0,6) sans action du joueur. getNorm sert à l'affichage seul.

	local panel = vgui.Create("DPanel", parent)
	panel:gSetPos(x, containerY)
	panel:gSetSize(sz, sz)
	panel:SetMouseInputEnabled(true)
	panel:SetCursor("hand")
	panel.Paint = function(selff, pw, ph)
		surface.SetMaterial(mat)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(0, 0, pw, ph)

		local nx, ny = getNorm(storageTable)
		local cx = nx * pw
		local cy = ny * ph

		surface.SetDrawColor(255, 255, 255, 220)
		-- Clamp the 16px box so it stays fully visible at extreme picker positions.
		local boxX = math.Clamp(math.Round(cx - 8), 0, pw - 16)
		local boxY = math.Clamp(math.Round(cy - 8), 0, ph - 16)
		surface.DrawOutlinedRect(boxX, boxY, 16, 16)

		local arm = math.min(14, math.floor(math.min(pw, ph) * 0.12))
		surface.DrawLine(cx - arm, cy, cx + arm, cy)
		surface.DrawLine(cx, cy - arm, cx, cy + arm)

		surface.SetDrawColor(40, 40, 40, 255)
		surface.DrawOutlinedRect(0, 0, pw, ph)
	end

	local function pickFromMouse(selff)
		local lx, ly = selff:ScreenToLocal(gui.MouseX(), gui.MouseY())
		local pw, ph = selff:GetWide(), selff:GetTall()
		if pw < 1 or ph < 1 then return end
		local nx = math.Clamp(lx / pw, 0, 1)
		local ny = math.Clamp(ly / ph, 0, 1)
		-- Pad tenu sans bouger : rien à réécrire (évite une re-cuisson de RT par image).
		if nx == selff._lzyLastNX and ny == selff._lzyLastNY then return end
		selff._lzyLastNX, selff._lzyLastNY = nx, ny
		local payload = applyNorm(storageTable, nx, ny)
		if updateFunction and fieldName then
			updateFunction(fieldName, payload)
		end
	end

	panel.OnMousePressed = function(selff, mc)
		if mc ~= MOUSE_LEFT then return end
		selff:MouseCapture(true)
		selff._lzyLastNX = nil -- la valeur a pu bouger ailleurs (clic dans l'aperçu)
		pickFromMouse(selff)
	end
	panel.OnMouseReleased = function(selff, mc)
		if mc ~= MOUSE_LEFT then return end
		selff:MouseCapture(false)
	end
	panel.Think = function(selff)
		if input.IsMouseDown(MOUSE_LEFT) and selff:IsHovered() then
			pickFromMouse(selff)
		end
	end

	return panel
end

-- Placement on the face UVs (normalized 0-1). Server persists px/py alongside RGB in `tattoo_color`.
-- `slot` selects which tattoo slot's fields are edited (1 or 2). Le pad couvre TATTOO_POS_MIN..MAX
-- (réglage fin autour du centre) ; un clic dans l'aperçu peut poser plus loin (affiché au bord).
local function createTattooPositionPicker(parent, x, y, storageTable, updateFunction, labelText, slot)
	slot = slot == 2 and 2 or 1
	local suf = slot == 1 and "" or "_2"
	local xKey, yKey = "tattoo_pos_x" .. suf, "tattoo_pos_y" .. suf
	return createTattooCrosshairPicker(parent, x, y, storageTable, updateFunction, labelText, {
		material = materials.position_picker,
		fieldName = "tattoo_pos",
		getNorm = function(st)
			local mn, mx = LZY_CHARACTER_CONFIG.TATTOO_POS_MIN, LZY_CHARACTER_CONFIG.TATTOO_POS_MAX
			local rng = mx - mn
			local vx = math.Clamp(tonumber(st[xKey]) or 0.5, mn, mx)
			local vy = math.Clamp(tonumber(st[yKey]) or 0.5, mn, mx)
			return (vx - mn) / rng, (vy - mn) / rng
		end,
		applyNorm = function(st, nx, ny)
			local mn, mx = LZY_CHARACTER_CONFIG.TATTOO_POS_MIN, LZY_CHARACTER_CONFIG.TATTOO_POS_MAX
			local rng = mx - mn
			local vx = math.Clamp(mn + nx * rng, mn, mx)
			local vy = math.Clamp(mn + ny * rng, mn, mx)
			st[xKey] = vx
			st[yKey] = vy
			return { x = vx, y = vy, slot = slot }
		end,
	})
end

-- Tattoo size on the face: X axis controls width scale, Y axis controls height scale.
-- Persisted alongside RGB+px/py via `tattoo_color`. The mapping is piecewise linear so the
-- default scale (1.0x) lands exactly at the picker's center.
local TATTOO_SCALE_MIN = 0.3
local TATTOO_SCALE_MAX = 2.0
local TATTOO_SCALE_DEFAULT = 1.0
local function tattooScaleToNorm(s)
	s = math.Clamp(s, TATTOO_SCALE_MIN, TATTOO_SCALE_MAX)
	if s <= TATTOO_SCALE_DEFAULT then
		return 0.5 * (s - TATTOO_SCALE_MIN) / (TATTOO_SCALE_DEFAULT - TATTOO_SCALE_MIN)
	end
	return 0.5 + 0.5 * (s - TATTOO_SCALE_DEFAULT) / (TATTOO_SCALE_MAX - TATTOO_SCALE_DEFAULT)
end
local function tattooNormToScale(n)
	n = math.Clamp(n, 0, 1)
	if n <= 0.5 then
		return TATTOO_SCALE_MIN + (n / 0.5) * (TATTOO_SCALE_DEFAULT - TATTOO_SCALE_MIN)
	end
	return TATTOO_SCALE_DEFAULT + ((n - 0.5) / 0.5) * (TATTOO_SCALE_MAX - TATTOO_SCALE_DEFAULT)
end

-- sxKey/syKey (optionnels) : même pad pour un tatouage du CORPS (entrée body_tattoos, clés sx/sy).
local function createTattooScalePicker(parent, x, y, storageTable, updateFunction, labelText, slot, sxKey, syKey)
	slot = slot == 2 and 2 or 1
	local suf = slot == 1 and "" or "_2"
	local bBody = sxKey ~= nil
	sxKey, syKey = sxKey or ("tattoo_scale_x" .. suf), syKey or ("tattoo_scale_y" .. suf)
	return createTattooCrosshairPicker(parent, x, y, storageTable, updateFunction, labelText, {
		material = materials.scale_picker,
		fieldName = bBody and "body_tattoos" or "tattoo_scale",
		getNorm = function(st)
			local sx = math.Clamp(tonumber(st[sxKey]) or 1.0, TATTOO_SCALE_MIN, TATTOO_SCALE_MAX)
			local sy = math.Clamp(tonumber(st[syKey]) or 1.0, TATTOO_SCALE_MIN, TATTOO_SCALE_MAX)
			return tattooScaleToNorm(sx), 1 - tattooScaleToNorm(sy)
		end,
		applyNorm = function(st, nx, ny)
			local sx = tattooNormToScale(nx)
			local sy = tattooNormToScale(1 - ny)
			st[sxKey] = sx
			st[syKey] = sy
			return { x = sx, y = sy, slot = slot }
		end,
	})
end

-- Creates a labeled grid of icon buttons.
local function createIconSelectionGrid(opts)
    local parent = opts.parent
    local labelText = opts.labelText
    local labelX = opts.labelX or 57
    local labelY = opts.labelY or 0
    local startX = opts.startX or 34.5
    local startY = opts.startY or 0
    local itemW = opts.itemW or 180
    local itemH = opts.itemH or 180
    local spacing = opts.spacing or 10
    local perRow = opts.perRow or 2
    local bottomPadding = opts.bottomPadding or 0
    local items = opts.items or {}
    local getIcon = opts.getIcon or function(item) return item.icon end
    local onSelect = opts.onSelect or function() end
    local isSelected = opts.isSelected or function() return false end

    if labelText and labelText ~= "" then
        local label = vgui.Create("DLabel", parent)
        label:gSetPos(labelX, labelY)
        label:gSetSize(200, 20)
        label:SetText(labelText)
        label:SetFont("Inter:30")
        label:SetTextColor(Color(255, 255, 255, 255))
    end

    for i = 1, #items do
        local row = math.floor((i - 1) / perRow)
        local col = (i - 1) % perRow
        local x = startX + col * (itemW + spacing)
        local y = startY + row * (itemH + spacing)
        local item = items[i]
        local icon = getIcon(item)
        local btn = vgui.Create("DButton", parent)
        btn:gSetSize(itemW, itemH)
        btn:gSetPos(x, y)
        btn:SetText("")
        btn.Paint = function(selff, pw, ph)
            RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
            RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 255/2))
            -- Only draw flat icon when no model preview is used
            if icon then
                RNDX.DrawMaterial(0, pw*0.1, ph*0.1, pw*0.8, ph*0.8, Color(255, 255, 255, 255), icon)
            end
            -- Stroke on selected item (4 filled rects so thickness is even on all sides)
            if isSelected(item) then
                local strokeW = 3
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect(0, 0, pw, strokeW)                           -- top
                surface.DrawRect(0, ph - strokeW, pw, strokeW)              -- bottom
                surface.DrawRect(0, 0, strokeW, ph)                         -- left
                surface.DrawRect(pw - strokeW, 0, strokeW, ph)             -- right
            end
        end

        btn.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            onSelect(item)
        end
    end

    if bottomPadding > 0 then
        parent:DockPadding(0, 0, 0, gRespY(bottomPadding))
    end
end

-- Eyes subpage layout @ 1920×1080 design units (pass only to gSetPos / gSetSize / gSetSize on children).
local PUPIL_UI_CB_Y, PUPIL_UI_CB_H, PUPIL_UI_CB_W = 40, 44, 372
local PUPIL_UI_CB_LABEL_INDENT = 12
local PUPIL_UI_SECTION_Y0 = PUPIL_UI_CB_Y + PUPIL_UI_CB_H + 12
-- Onglets "Pupille gauche / Pupille droite" (mode pupilles separees, demande user 2026-07-16) :
-- au lieu d'empiler les 2 blocs (page tres longue), UN SEUL bloc est affiche et on bascule par onglet.
local PUPIL_UI_TAB_H, PUPIL_UI_TAB_W, PUPIL_UI_TAB_GAP = 44, 180, 8
local pupilTabSide = "left" -- onglet actif ("left"/"right") ; persiste tant que le fichier est charge
local PUPIL_UI_SWATCH_X = 56
local PUPIL_UI_COLOR_ROW_Y_OFFSET = 34 -- below section label (e.g. "Pupille gauche")
local PUPIL_UI_COLOR_ROW_H = 40
local PUPIL_UI_GRID_GAP_BELOW_COLOR = 12

--- Color squares for one pupil style (nested config). Order matches each style group's array in AVAILABLE_PUPILS_TEXTURES (ipairs). getCurrentPath() returns active VMT path for highlight. `x`/`y` are design coords (first swatch top-left).
local function createPupilColorSwatchRow(parent, x, y, styleIndex, getCurrentPath, onPickPath)
    if not styleIndex or styleIndex < 1 then return 0 end
    local groups = LZY_PupilsGetStyleGroups()
    local group = groups[styleIndex]
    if not istable(group) then return 0 end

    local defaultPath = LZY_PupilsGetFirstPathForStyleIndex(styleIndex)

    local rows = {}
    for _, row in ipairs(group) do
        if istable(row) and isstring(row.path) then
            rows[#rows + 1] = row
        end
    end
    if #rows < 1 then return 0 end

    local wrap = vgui.Create("DPanel", parent)
    wrap._lzyPupilSwatchWrap = true
    wrap:gSetPos(x, y)
    wrap:SetPaintBackground(false)
    local sq, gap = 28, 8
    local n = #rows
    local wrapW = n * sq + math.max(0, n - 1) * gap + 4
    wrap:gSetSize(wrapW, 36)

    for colIdx, row in ipairs(rows) do
        local colKey = row.color or "white"
        local mapCol = LZY_CHARACTER_CONFIG.PUPILS_COLORS and LZY_CHARACTER_CONFIG.PUPILS_COLORS[colKey]
        local fill = mapCol or Color(200, 200, 200)

        local btn = vgui.Create("DButton", wrap)
        btn:gSetSize(sq, sq)
        btn:gSetPos((colIdx - 1) * (sq + gap), 0)
        btn:SetText("")
        local pathForBtn = row.path
        btn.Paint = function(s, w, h)
            local cur = getCurrentPath and getCurrentPath() or ""
            local isOn = (pathForBtn == cur) or ((not isstring(cur) or cur == "") and defaultPath and pathForBtn == defaultPath)
            surface.SetDrawColor(fill.r, fill.g, fill.b, fill.a or 255)
            surface.DrawRect(2, 2, w - 4, h - 4)
            surface.SetDrawColor(isOn and 255 or 55, isOn and 255 or 55, isOn and 255 or 55, 255)
            local t = isOn and 3 or 1
            for k = 0, t - 1 do
                surface.DrawOutlinedRect(k, k, w - 2 * k, h - 2 * k)
            end
        end
        btn.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            onPickPath(pathForBtn)
        end
    end
    return PUPIL_UI_COLOR_ROW_H
end

--[[---------------------------------------------------------------------------
  Pupil thumbnail camera tuning (same file as this block)

  Per-eye "eyes" attachment offsets (Evo: left socket = +IPD along attachment Right, right = −IPD):
    EYES_L_IPD_HALF, EYES_R_IPD_HALF   — lateral half-distance (Source units); tune left/right independently.
    EYES_L_FORWARD, EYES_R_FORWARD      — along attachment Forward (toward/away from cornea).
    EYES_L_ALONG_UP, EYES_R_ALONG_UP    — along attachment Up (+ toward top of head, − lower on face).

  Fallback when no "eyes" attachment (model-local X from bounds center):
    FALLBACK_X_LEFT, FALLBACK_X_RIGHT

  Pupil-only view ray (× render-bounds radius): CAM_DIR_Y_L/Z_L and CAM_DIR_Y_R/Z_R.
  Default zoom distance when grid omits camEyeDistanceMul: CAM_EYE_DIST_MUL_L / CAM_EYE_DIST_MUL_R.

  Per createModelSelectionGrid({ ... }) on pupil rows:
    camFOV, camLookAtOffsetZ, camEyeDistanceMul, camDistance, camDistanceScale, camOffsetZ
    (camLookAtOffsetZ adds model-local Z after all of the above; use for small per-grid nudges.)
---------------------------------------------------------------------------]]--

-- Pupil thumbnail DModelPanel: focus camera on one eye (model-local space).
-- Evo face models often have ValveBiped eye bones placed off the actual eye; prefer the "eyes"
-- attachment (between sockets) plus a small lateral offset, then other bones, Valve eye bones last.
local LZY_PUPIL_THUMB_EYES_L_IPD_HALF = 1.13
local LZY_PUPIL_THUMB_EYES_R_IPD_HALF = 1.25
local LZY_PUPIL_THUMB_EYES_L_FORWARD = 0.22
local LZY_PUPIL_THUMB_EYES_R_FORWARD = 0.22
-- Negative = move look-at down on the face (from brow toward the eye) for typical QC "eyes" attachment.
local LZY_PUPIL_THUMB_EYES_L_ALONG_UP = -0.7
local LZY_PUPIL_THUMB_EYES_R_ALONG_UP = -0.7

local LZY_PUPIL_THUMB_FALLBACK_X_LEFT = -0.8
local LZY_PUPIL_THUMB_FALLBACK_X_RIGHT = 0.8

local LZY_PUPIL_THUMB_CAM_DIR_Y_L = 0.08
local LZY_PUPIL_THUMB_CAM_DIR_Z_L = 0.05
local LZY_PUPIL_THUMB_CAM_DIR_Y_R = 0.08
local LZY_PUPIL_THUMB_CAM_DIR_Z_R = 0.05
local LZY_PUPIL_THUMB_CAM_EYE_DIST_MUL_L = 0.45
local LZY_PUPIL_THUMB_CAM_EYE_DIST_MUL_R = 0.4

local LZY_PUPIL_THUMB_BONES_LEFT = { "eye_L", "LeftEye", "l_eye", "DEF_L_eye", "ValveBiped.Bip01_L_Eye" }
local LZY_PUPIL_THUMB_BONES_RIGHT = { "eye_R", "RightEye", "r_eye", "DEF_R_eye", "ValveBiped.Bip01_R_Eye" }

local function LZY_GetPupilThumbnailLookAtFromEyesAttachment(ent, side, zExtra)
    local aid = ent:LookupAttachment("eyes")
    if not aid or aid <= 0 then return nil end
    local t = ent:GetAttachment(aid)
    if not t or not t.Pos or not t.Ang then return nil end
    -- Evo face.mdl: character left socket = +IPD on attachment Right, right socket = −IPD.
    local ipd, fwd, aup
    if side == "right" then
        ipd, fwd, aup = LZY_PUPIL_THUMB_EYES_R_IPD_HALF, LZY_PUPIL_THUMB_EYES_R_FORWARD, LZY_PUPIL_THUMB_EYES_R_ALONG_UP
    else
        ipd, fwd, aup = LZY_PUPIL_THUMB_EYES_L_IPD_HALF, LZY_PUPIL_THUMB_EYES_L_FORWARD, LZY_PUPIL_THUMB_EYES_L_ALONG_UP
    end
    local lat = (side == "right") and -ipd or ipd
    local worldFocus = t.Pos
        + t.Ang:Right() * lat
        + t.Ang:Forward() * fwd
        + t.Ang:Up() * aup
    return ent:WorldToLocal(worldFocus) + Vector(0, 0, zExtra)
end

local function LZY_GetPupilThumbnailLookAtLocal(ent, side, centerLocal, zExtra)
    zExtra = zExtra or 0
    if not IsValid(ent) then return centerLocal + Vector(0, 0, zExtra) end
    local fromEyes = LZY_GetPupilThumbnailLookAtFromEyesAttachment(ent, side, zExtra)
    if fromEyes then return fromEyes end
    local list = (side == "right") and LZY_PUPIL_THUMB_BONES_RIGHT or LZY_PUPIL_THUMB_BONES_LEFT
    for _, bname in ipairs(list) do
        local bid = ent:LookupBone(bname)
        if bid and bid >= 0 then
            local pos = select(1, ent:GetBonePosition(bid))
            if pos then
                return ent:WorldToLocal(pos) + Vector(0, 0, zExtra)
            end
        end
    end
    local fx = (side == "right") and LZY_PUPIL_THUMB_FALLBACK_X_RIGHT or LZY_PUPIL_THUMB_FALLBACK_X_LEFT
    return centerLocal + Vector(fx, 0, 2.2 + zExtra)
end

-- Bottom Y of a 2-column model grid (exclusive of section label above startY).
local function LZY_ModelSelectionGridBottomY(itemCount, startY, itemH, spacing, perRow, bottomPadding)
    itemH = itemH or 180
    spacing = spacing or 10
    perRow = perRow or 2
    bottomPadding = bottomPadding or 0
    if not itemCount or itemCount < 1 then return startY + bottomPadding end
    local rows = math.ceil(itemCount / perRow)
    return startY + (rows - 1) * (itemH + spacing) + itemH + bottomPadding
end

-- Grid of rectangles (2 per row): DModelPanel thumbnails for mainModel, or flat texture quads when opts.useTextureThumbnails.
-- ── COUPES PLATINUM (09/02, demande user) ──────────────────────────────────
-- Les entrees `platinum = true` (config) sont AFFICHEES pour tous mais
-- selectionnables par le tier 3 (NWInt premium) et le staff seulement. Un clic
-- non autorise ouvre un popup avec le bouton vers la boutique des grades.
local function LZY_PeutCoupePlatinum()
    -- Source unique : LZY_CHARACTER_CONFIG.PeutCoupePlatinum (config.lua, partagée
    -- avec le tirage aléatoire, la validation serveur et le coiffeur).
    return LZY_CHARACTER_CONFIG.PeutCoupePlatinum(LocalPlayer())
end

local function LZY_PopupCoupePlatinum()
    local W, H = 430, 190
    local f = vgui.Create("DFrame")
    f:SetSize(W, H) f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
    f:SetDrawOnTop(true)
    if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
    f.Paint = function(_, w, h)
        surface.SetDrawColor(18, 18, 22, 248) surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(232, 179, 75, 220) surface.DrawRect(0, 0, w, 3)
        draw.SimpleText("Coupe Platinum", "Inter:30", w / 2, 34, Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Cette coupe est réservée aux Platinums.", "Inter:20", w / 2, 72, Color(230, 230, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Le grade s'obtient sur la boutique du serveur.", "Inter:18", w / 2, 96, Color(160, 163, 170), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    local function mkB(x, label, col, colH, fn)
        local b = vgui.Create("DButton", f)
        b:SetText("") b:SetSize(190, 42) b:SetPos(x, H - 56)
        b.Paint = function(_, w, h)
            draw.RoundedBox(6, 0, 0, w, h, b:IsHovered() and colH or col)
            draw.SimpleText(label, "Inter:20", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = fn
    end
    mkB(W / 2 - 200, "Voir le grade", Color(160, 120, 40), Color(190, 145, 55), function()
        f:Remove()
        local sURL = (SHOP_CONFIG and SHOP_CONFIG.GRADES_SITE_URL) or "https://evo-roleplay.com/BleachRP/boutique.html"
        if EVO_OpenWeb then EVO_OpenWeb(sURL, "Boutique") else gui.OpenURL(sURL) end
    end)
    mkB(W / 2 + 10, "Fermer", Color(60, 60, 65), Color(85, 85, 92), function() f:Remove() end)
end

local function createModelSelectionGrid(opts)
    local parent = opts.parent
    local labelText = opts.labelText
    local labelX = opts.labelX or 57
    local labelY = opts.labelY or 0
    local startX = opts.startX or 34.5
    local startY = opts.startY or 0
    local itemW = opts.itemW or 180
    local itemH = opts.itemH or 180
    local spacing = opts.spacing or 10
    local perRow = opts.perRow or 2
    local bottomPadding = opts.bottomPadding or 0
    local mainModel = opts.mainModel or ""
    local bodygroupId = opts.bodygroupId
    local bodygroupSubmodels = opts.bodygroupSubmodels or {}
    local setEntitySetup = opts.setEntitySetup
    local onSelect = opts.onSelect or function() end
    local getSubModel = opts.getSubModel
    local setSubEntitySetup = opts.setSubEntitySetup
    local isSelected = opts.isSelected or function() return false end
    local camDistanceScale = opts.camDistanceScale or 1
    local camOffsetZ = opts.camOffsetZ or 0
    local camDistance = opts.camDistance  -- if set, exact distance from model center (overrides scale for distance)
    local camFOV = opts.camFOV or 28     -- lower = more zoom on model
    local camLookAtOffsetZ = opts.camLookAtOffsetZ or 0  -- shift look-at point up/down (e.g. to frame the face)
    local camFocusEye = opts.camFocusEye -- "left" | "right" | nil — pupil grids: frame that eye
    local camEyeDistanceMul = opts.camEyeDistanceMul -- optional when camFocusEye set (defaults L/R: CAM_EYE_DIST_MUL_*)
    local pupilThumbBumpTag = opts.pupilThumbBumpTag
    local thumbnailBumpTag = opts.thumbnailBumpTag
    local collectHairLayoutCells = opts.collectHairLayoutCells
    local collectHairStyleLabel = opts.collectHairStyleLabel
    -- When true, paint item.texture directly in each cell instead of rendering mainModel (e.g. tattoo motif list).
    local useTextureThumbnails = opts.useTextureThumbnails

    -- Build list of items: from opts.items or bodygroup indices
    local items
    if opts.items and #opts.items > 0 then
        items = opts.items
    else
        items = {}
        local n = type(bodygroupSubmodels) == "number" and bodygroupSubmodels or #bodygroupSubmodels
        for i = 0, n - 1 do
            items[#items + 1] = { index = i }
        end
    end

    if labelText and labelText ~= "" then
        local styleLabel = vgui.Create("DLabel", parent)
        styleLabel:gSetPos(labelX, labelY)
        styleLabel:gSetSize(200, 20)
        styleLabel:SetText(labelText)
        styleLabel:SetFont("Inter:30")
        styleLabel:SetTextColor(Color(255, 255, 255, 255))
        if collectHairStyleLabel then
            collectHairStyleLabel.label = styleLabel
        end
    end

    local thumbnailMdls = {}

    for i = 1, #items do
        local row = math.floor((i - 1) / perRow)
        local col = (i - 1) % perRow
        local x = startX + col * (itemW + spacing)
        local y = startY + row * (itemH + spacing)
        local item = items[i]

        local cell = vgui.Create("DPanel", parent)
        cell:gSetSize(itemW, itemH)
        cell:gSetPos(x, y)
        if collectHairLayoutCells then
            cell._hairLayoutBaseX = x
            cell._hairLayoutBaseY = y
            collectHairLayoutCells[#collectHairLayoutCells + 1] = cell
        end
        cell.Paint = function(_, cw, ch)
            surface.SetDrawColor(60, 60, 60, 255)
            surface.DrawOutlinedRect(0, 0, cw, ch)
            if isstring(item.gridCaption) and item.gridCaption ~= "" then
                surface.SetDrawColor(0, 0, 0, 200)
                surface.DrawRect(0, ch - 24, cw, 24)
                draw.SimpleText(item.gridCaption, "Inter:18", cw * 0.5, ch - 6, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
            end
            -- Stroke on selected item (4 filled rects so thickness is even on all sides)
            if isSelected(item) then
                local strokeW = 3
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect(0, 0, cw, strokeW)                          -- top
                surface.DrawRect(0, ch - strokeW, cw, strokeW)              -- bottom
                surface.DrawRect(0, 0, strokeW, ch)                          -- left
                surface.DrawRect(cw - strokeW, 0, strokeW, ch)               -- right
            end
        end

        local bg = vgui.Create("DPanel", cell)
        bg:Dock(FILL)
        bg.Paint = function(_, bw, bh)
            surface.SetDrawColor(0, 0, 0, 56)
            surface.DrawRect(0, 0, bw, bh)
        end

        local mdl
        if useTextureThumbnails then
            local texPanel = vgui.Create("DPanel", cell)
            texPanel:Dock(FILL)
            texPanel:DockMargin(3, 3, 3, 3)
            texPanel:SetMouseInputEnabled(false)
            texPanel.Paint = function(_, bw, bh)
                -- Solid dark backdrop so the underlying framebuffer can never bleed through.
                surface.SetDrawColor(28, 28, 28, 255)
                surface.DrawRect(0, 0, bw, bh)

                if item.none then
                    draw.SimpleText("Aucun", "Inter:25", bw * 0.5, bh * 0.5, Color(220, 220, 220, 255),
                        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    return
                end
                local path = item.texture
                if not isstring(path) or path == "" then return end

                local srcMat = Material(path)
                if srcMat:IsError() then
                    surface.SetDrawColor(50, 30, 30, 255)
                    surface.DrawRect(0, 0, bw, bh)
                    return
                end
                local tex = srcMat:GetTexture("$basetexture")
                if not tex or (tex.IsError and tex:IsError()) then
                    return
                end

                local blit = GetTattooThumbBlitMaterial()
                if not blit or blit:IsError() then return end
                blit:SetTexture("$basetexture", tex)

                local tw, th = tex:Width(), tex:Height()
                if not tw or tw <= 0 or not th or th <= 0 then tw, th = bw, bh end
                local scale = math.min(bw / tw, bh / th)
                local dw = tw * scale
                local dh = th * scale
                local ox = (bw - dw) * 0.5
                local oy = (bh - dh) * 0.5

                surface.SetMaterial(blit)
                surface.SetDrawColor(230, 230, 230, 255)
                surface.DrawTexturedRect(ox, oy, dw, dh)
            end
        else
            mdl = vgui.Create("DModelPanel", cell)
            mdl:Dock(FILL)
            mdl:DockMargin(3, 3, 3, 3)
            QueuePreviewModel(mdl, function(panel) panel:SetModel(mainModel) end)
            mdl:SetMouseInputEnabled(false)
            mdl:SetAmbientLight(Color(200, 200, 200))
            mdl:SetDirectionalLight(BOX_TOP, Color(255, 255, 255))
            mdl:SetDirectionalLight(BOX_FRONT, Color(200, 200, 200))
            mdl:SetFOV(camFOV)
            -- Completely disable DModelPanel's built-in animation for these thumbnails
            mdl.RunAnimation = function() end
            local thumbBumpTag = (isstring(pupilThumbBumpTag) and pupilThumbBumpTag ~= "") and pupilThumbBumpTag
                or (isstring(thumbnailBumpTag) and thumbnailBumpTag ~= "" and thumbnailBumpTag)
                or nil
            if thumbBumpTag then
                mdl._lzyThumbBumpTag = thumbBumpTag
            end

            mdl.LayoutEntity = function(self, ent)
                if not IsValid(ent) then return end
                -- Track and hide the internal DModelPanel entity so it doesn't appear in the world
                if not self._trackedMainEnt then
                    self._trackedMainEnt = true
                    TrackClientsideModel(ent)
                    ent:SetNoDraw(true)
                end
                if bodygroupId ~= nil then
                    ent:SetBodygroup(bodygroupId, item.index or 0)
                end
                -- Bone-merge submodel (e.g. hair) onto main (face), same pattern as preview
                if getSubModel and item then
                    local subModel = getSubModel(item)
                    if subModel and subModel ~= "" then
                        if not IsValid(self._subEnt) then
                            self._subEnt = ClientsideModel(subModel, RENDERGROUP_OPAQUE)
                            if IsValid(self._subEnt) then
                                TrackClientsideModel(self._subEnt)
                                self._subEnt:SetNoDraw(true)
                                self._subEnt:SetParent(ent)
                                self._subEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                            end
                        end
                        if IsValid(self._subEnt) then
                            if self._subEnt:GetModel() ~= subModel then
                                self._subEnt:SetModel(subModel)
                            end
                            if setSubEntitySetup then
                                setSubEntitySetup(ent, self._subEnt, item)
                            end
                        end
                    else
                        if IsValid(self._subEnt) then
                            self._subEnt:Remove()
                            self._subEnt = nil
                        end
                    end
                end
                if setEntitySetup then
                    setEntitySetup(ent, item)
                end
                -- Rotate model so front faces camera (camera is in -X; model faces camera at 180° Y)
                ent:SetAngles(Angle(0, 163, 0))
                -- Force thumbnails into reference/T pose and freeze
                local refSeq = ent:LookupSequence("reference")
                if not refSeq or refSeq < 0 then
                    refSeq = 0
                end
                ent:ResetSequence(refSeq)
                ent:SetPlaybackRate(0)
                ent:SetCycle(0)
                if IsValid(self._subEnt) then
                    self._subEnt:SetPlaybackRate(0)
                    self._subEnt:SetCycle(0)
                end
                if camFocusEye == "left" or camFocusEye == "right" then
                    ent:SetupBones()
                elseif not self._camDone then
                    self._camDone = true
                    ent:SetupBones()
                end
                local mn, mx = ent:GetRenderBounds()
                local center = (mn + mx) * 0.5
                local radius = (mx - mn):Length() * 0.5
                if radius < 1 then radius = 50 end
                local lookAtLocal
                if camFocusEye == "left" or camFocusEye == "right" then
                    lookAtLocal = LZY_GetPupilThumbnailLookAtLocal(ent, camFocusEye, center, camLookAtOffsetZ)
                else
                    lookAtLocal = center + Vector(0, 0, camLookAtOffsetZ)
                end
                -- Face models typically face -X in model space; put camera in front (negative X).
                -- Pupil thumbnails: keep direction closer to -X so a small look-at error does not swing toward the ear.
                local dir
                local pupilEyeDistMul
                if camFocusEye == "left" or camFocusEye == "right" then
                    local dy = (camFocusEye == "right") and LZY_PUPIL_THUMB_CAM_DIR_Y_R or LZY_PUPIL_THUMB_CAM_DIR_Y_L
                    local dz = (camFocusEye == "right") and LZY_PUPIL_THUMB_CAM_DIR_Z_R or LZY_PUPIL_THUMB_CAM_DIR_Z_L
                    dir = Vector(-radius, radius * dy, radius * dz)
                    pupilEyeDistMul = (camFocusEye == "right") and LZY_PUPIL_THUMB_CAM_EYE_DIST_MUL_R or LZY_PUPIL_THUMB_CAM_EYE_DIST_MUL_L
                else
                    dir = Vector(-radius, radius * 0.3, radius * 0.1)
                end
                local dist
                if camDistance and camDistance > 0 then
                    dist = camDistance
                    if camFocusEye == "left" or camFocusEye == "right" then
                        dist = dist * (camEyeDistanceMul or pupilEyeDistMul)
                    end
                else
                    local mul = camDistanceScale
                    if camFocusEye == "left" or camFocusEye == "right" then
                        mul = mul * (camEyeDistanceMul or pupilEyeDistMul)
                    end
                    dist = dir:Length() * mul
                    local minDist = radius * 0.15
                    if camFocusEye == "left" or camFocusEye == "right" then
                        minDist = math.max(minDist * 0.35, radius * 0.06)
                    end
                    if dist < minDist then dist = minDist end
                end
                dir = dir:GetNormalized() * dist
                local camPosLocal = lookAtLocal + dir
                -- DModelPanel expects model-relative coordinates, not world
                self:SetLookAt(lookAtLocal)
                self:SetCamPos(camPosLocal + Vector(0, 0, camOffsetZ))
            end

            -- DModelPanel only draws its main entity; draw bone-merged subentity (e.g. hair) in PostDrawModel
            if getSubModel then
                mdl.PostDrawModel = function(self, ent)
                    if IsValid(self._subEnt) then
                        self._subEnt:DrawModel()
                    end
                end
            end

            mdl.OnRemove = function(self)
                if IsValid(self._subEnt) then
                    self._subEnt:Remove()
                    self._subEnt = nil
                end
            end
        end

        local btn = vgui.Create("DButton", cell)
        btn:Dock(FILL)
        btn:SetText("")
        btn.Paint = function(_, bw, bh)
            -- Voile Platinum : la coupe reste VISIBLE (apercu dessous), le voile
            -- dit juste qu'elle est verrouillee pour ce joueur.
            if item.platinum and not LZY_PeutCoupePlatinum() then
                surface.SetDrawColor(0, 0, 0, 120)
                surface.DrawRect(0, 0, bw, bh)
                surface.SetDrawColor(232, 179, 75, 220)
                surface.DrawRect(0, 0, bw, 2)
                draw.SimpleText("PLATINUM", "Inter:25", bw * 0.5, bh * 0.5 - 10, Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("Réservé", "Inter:18", bw * 0.5, bh * 0.5 + 14, Color(225, 225, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
        btn.DoClick = function()
            if item.platinum and not LZY_PeutCoupePlatinum() then
                surface.PlaySound("a4xy732ex6yeop2/g1kpyv29gwai.mp3")
                LZY_PopupCoupePlatinum()
                return
            end
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            onSelect(item)
        end

        if IsValid(mdl) then
            thumbnailMdls[#thumbnailMdls + 1] = mdl
        end
    end

    if #thumbnailMdls > 0 then
        local function bumpThumbnailLayouts()
            for _, p in ipairs(thumbnailMdls) do
                if IsValid(p) then
                    p._camDone = false
                    p:InvalidateLayout(true)
                end
            end
        end
        timer.Simple(0, bumpThumbnailLayouts)
        timer.Simple(0.05, bumpThumbnailLayouts)
    end

    if bottomPadding > 0 then
        parent:DockPadding(0, 0, 0, gRespY(bottomPadding))
    end
end

-- Styles a DScrollPanel's vertical scrollbar: dark background, white grip. Call after creating the panel.
local function styleScrollPanelVBar(scrollPanel)
    local vbar = scrollPanel:GetVBar()
    if not IsValid(vbar) then return end
    vbar:SetWide(gRespX(9))   -- barre un peu plus large (demande user) : plus facile a attraper pour descendre
    vbar:SetHideButtons(true)
    vbar.Paint = function(selff, w, h)
        surface.SetDrawColor(30, 30, 30, 255)
        surface.DrawRect(0, 0, w, h)
    end
    if IsValid(vbar.btnGrip) then
        vbar.btnGrip.Paint = function(grip, w, h)
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawRect(0, 0, w, h)
        end
    end
end

--- Read vertical scroll offset from a DScrollPanel (pixel offset into canvas).
local function LZY_GetScrollPanelScrollY(scrollPanel)
    if not IsValid(scrollPanel) then return 0 end
    local vbar = scrollPanel:GetVBar()
    if not IsValid(vbar) then return 0 end
    if vbar.GetScroll then return tonumber(vbar:GetScroll()) or 0 end
    if vbar.GetValue then return tonumber(vbar:GetValue()) or 0 end
    return 0
end

local function LZY_SetScrollPanelScrollYClamped(scrollPanel, targetY)
    if not IsValid(scrollPanel) then return end
    local target = tonumber(targetY) or 0
    local canvas = scrollPanel:GetCanvas()
    local vbar = scrollPanel:GetVBar()
    if not IsValid(canvas) or not IsValid(vbar) or not vbar.SetScroll then return end
    local maxScroll = math.max(0, canvas:GetTall() - scrollPanel:GetTall())
    if maxScroll < 1 then return end
    vbar:SetScroll(math.Clamp(target, 0, maxScroll))
end

--- Re-apply scroll after layout: early SetScroll clamps to 0 until canvas height is known.
local function LZY_RestoreScrollPanelScrollDeferred(scrollPanel, targetY)
    if not IsValid(scrollPanel) then return end
    local target = tonumber(targetY) or 0
    local delays = { 0, 0.01, 0.05, 0.1, 0.15, 0.2, 0.35 }
    for _, delay in ipairs(delays) do
        timer.Simple(delay, function()
            if not IsValid(scrollPanel) then return end
            LZY_SetScrollPanelScrollYClamped(scrollPanel, target)
        end)
    end
end

-- Vertical offset when hair has no detail materials (must match CreateSubPage1: 790 - 540).
local HAIR_DETAILS_LAYOUT_COLLAPSE_Y = 250

local function LZY_BumpThumbnailsTagged(root, tag)
    if not isstring(tag) or tag == "" or not IsValid(root) then return end
    local function walk(p)
        if not IsValid(p) then return end
        if p._lzyThumbBumpTag == tag then
            p._camDone = false
            p:InvalidateLayout(true)
        end
        for _, c in ipairs(p:GetChildren()) do
            walk(c)
        end
    end
    walk(root)
end

local function LZY_RemovePupilSwatchWraps(canvas)
    if not IsValid(canvas) then return end
    local rem = {}
    for _, ch in ipairs(canvas:GetChildren()) do
        if ch._lzyPupilSwatchWrap then rem[#rem + 1] = ch end
    end
    for _, ch in ipairs(rem) do ch:Remove() end
end

local function LZY_RebuildNestedPupilColorSwatches()
    local f = frame
    if not IsValid(f) then return end
    local ctx = f._lzyEyesNestedSwatchCtx
    if not ctx or not IsValid(ctx.canvas) then return end
    if LZY_PupilsIsLegacyFlatList(GetPupilsTextureList()) then return end
    if ctx.separate ~= characterData.pupils_separate then return end

    LZY_RemovePupilSwatchWraps(ctx.canvas)

    if ctx.separate then
        -- Onglets gauche/droite : UN SEUL bloc visible -> on ne reconstruit que la rangee du cote actif.
        if (ctx.side or pupilTabSide) == "right" then
            createPupilColorSwatchRow(ctx.canvas, PUPIL_UI_SWATCH_X, ctx.sideY or ctx.rightY, LZY_PupilsStyleIndexForPath(characterData.pupil_right) or 1,
                function() return characterData.pupil_right end,
                function(p) UpdateCharacterData("pupil_right", p) end)
        else
            createPupilColorSwatchRow(ctx.canvas, PUPIL_UI_SWATCH_X, ctx.sideY or ctx.leftY, LZY_PupilsStyleIndexForPath(characterData.pupil_left) or 1,
                function() return characterData.pupil_left end,
                function(p) UpdateCharacterData("pupil_left", p) end)
        end
    else
        createPupilColorSwatchRow(ctx.canvas, PUPIL_UI_SWATCH_X, ctx.combinedY, LZY_PupilsStyleIndexForPath(characterData.pupils_texture) or 1,
            function() return characterData.pupils_texture end,
            function(p) UpdateCharacterData("pupils_texture", p) end)
    end
end

local function LZY_ApplyHairCheveuxPageLayout()
    local f = frame
    if not IsValid(f) or f.currentPage3SubPage ~= 1 then return end
    local sp = f.currentSubPagePanel

    local prevExpanded = f._lzyHairDetailsExpandedVisual
    local scrollBefore = 0
    if IsValid(sp) then
        scrollBefore = LZY_GetScrollPanelScrollY(sp)
    end

    local expanded = LZY_HairModelPathHasDetailMaterials(characterData.hair_model)
    if IsValid(f.hairDetailsWrapper) then
        f.hairDetailsWrapper:SetVisible(expanded)
    end
    local dy = expanded and 0 or -HAIR_DETAILS_LAYOUT_COLLAPSE_Y
    local sl = f.gradientAngleSlider
    if IsValid(sl) then
        if IsValid(sl._layoutLabel) then
            sl._layoutLabel:gSetPos(56, 790 + dy)
        end
        sl:gSetPos(56, 830 + dy)
    end
    if IsValid(f._hairStyleSectionLabel) then
        f._hairStyleSectionLabel:gSetPos(57, 900 + dy)
    end
    for _, cell in ipairs(f._hairStyleThumbCells or {}) do
        if IsValid(cell) and cell._hairLayoutBaseY then
            cell:gSetPos(cell._hairLayoutBaseX or 0, cell._hairLayoutBaseY + dy)
        end
    end

    f._lzyHairDetailsExpandedVisual = expanded

    local delta = 0
    if prevExpanded ~= nil then
        if not prevExpanded and expanded then
            delta = HAIR_DETAILS_LAYOUT_COLLAPSE_Y
        elseif prevExpanded and not expanded then
            delta = -HAIR_DETAILS_LAYOUT_COLLAPSE_Y
        end
    end
    if delta ~= 0 and IsValid(sp) then
        local targetY = scrollBefore + delta
        sp._lzyHairSnapScrollY = targetY
        sp._lzyHairSnapScrollPaints = 8
        local c = sp:GetCanvas()
        if IsValid(c) then c:InvalidateLayout(true) end
        sp:InvalidateLayout(true)
        LZY_SetScrollPanelScrollYClamped(sp, targetY)
        timer.Simple(0, function()
            if not IsValid(sp) then return end
            if sp._lzyHairSnapScrollY then
                LZY_SetScrollPanelScrollYClamped(sp, sp._lzyHairSnapScrollY)
            end
        end)
        timer.Simple(0.12, function()
            if not IsValid(sp) then return end
            if sp._lzyHairSnapScrollY then
                LZY_SetScrollPanelScrollYClamped(sp, sp._lzyHairSnapScrollY)
            end
        end)
        timer.Simple(0.25, function()
            if not IsValid(sp) then return end
            LZY_SetScrollPanelScrollYClamped(sp, targetY)
        end)
    end
end

-- Neutralise : avant, la sous-page Cheveux cachait barbe/moustache sur le
-- preview pour "lier" facial hair a son propre onglet - mais cote user ca
-- ressemblait a un bug (la barbe semblait disparaitre en revenant aux cheveux,
-- alors que la donnee characterData.beard_model etait conservee).
-- On laisse la barbe/moustache visibles sur toutes les sous-pages.
-- Si jamais un appelant force SetNoDraw(true) ailleurs, on remet a false ici
-- pour garantir la visibilite.
local function LZY_SyncPreviewFacialHairVisibilityForAppearancePage()
    local f = frame
    if not IsValid(f) or not IsValid(f.previewModel) then return end
    local pm = f.previewModel
    if IsValid(pm.beardEnt) then pm.beardEnt:SetNoDraw(false) end
    if IsValid(pm.mustacheEnt) then pm.mustacheEnt:SetNoDraw(false) end
end

--- Rebuild Yeux (pupils) subpage so every DModelPanel thumbnail picks up latest characterData (both eyes when separate).
--- Only while that subpage is actually on screen: currentPage3SubPage stays at 3 after going back
--- to Page 2, and the random dé writes pupils_separate — without the currentPage check that would
--- recreate the eyes panel on top of the name/gender page.
local function ScheduleRefreshEyesSubPage()
    local f = frame
    if not IsValid(f) or currentPage ~= 3 or f.currentPage3SubPage ~= 3 then return end
    local sp = f.currentSubPagePanel
    local scrollToRestore = LZY_GetScrollPanelScrollY(sp)
    timer.Simple(0, function()
        if not IsValid(f) or currentPage ~= 3 or f.currentPage3SubPage ~= 3 then return end
        f._lzyEyesSubPageScrollDoRestore = true
        f._lzyEyesSubPageScrollRestore = scrollToRestore
        if f.CreateSubPage3 then f:CreateSubPage3() end
    end)
end

--- Barre d'onglets "Pupille gauche / Pupille droite" (mode pupilles separees). Bascule
--- pupilTabSide puis reconstruit la sous-page (un seul bloc affiche a la fois). Retourne la
--- hauteur DESIGN occupee (pour positionner le bloc en dessous). Theme sombre = celui de la checkbox.
local function createPupilSideTabs(canvas, y)
    local tabs = { { key = "left", label = "Pupille gauche" }, { key = "right", label = "Pupille droite" } }
    for i, t in ipairs(tabs) do
        local b = vgui.Create("DButton", canvas)
        b:gSetPos(PUPIL_UI_SWATCH_X + (i - 1) * (PUPIL_UI_TAB_W + PUPIL_UI_TAB_GAP), y)
        b:gSetSize(PUPIL_UI_TAB_W, PUPIL_UI_TAB_H)
        b:SetText("")
        -- Style IDENTIQUE aux onglets tatouages (createTattooSlotTabs) : fond transparent,
        -- Inter:22, soulignement blanc pour l'onglet actif (demande user 2026-07-17).
        b.Paint = function(selfb, w, h)
            local on = (pupilTabSide == t.key)
            local txtColor
            if on then                    txtColor = Color(255, 255, 255, 255)
            elseif selfb:IsHovered() then txtColor = Color(220, 220, 220, 255)
            else                          txtColor = Color(150, 150, 150, 255) end
            draw.SimpleText(t.label, "Inter:22", w * 0.5, h * 0.5 - 2, txtColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if on then
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect(12, h - 2, w - 24, 2)
            end
        end
        b.DoClick = function()
            if pupilTabSide == t.key then return end
            pupilTabSide = t.key
            ScheduleRefreshEyesSubPage()
        end
    end
    return PUPIL_UI_TAB_H + 12
end

UpdateCharacterData = function(field, value)
    if field == "body_tattoos" then
        characterData.body_tattoos = istable(value) and value or {}
        if frame then LZY_CC_ApplyPreviewBodyTattoo(frame.previewModel, characterData) end
        return
    end
    -- Shape keys: store by flex ID in shape_keys (for preview/server) and by name in shapeKeysByName (for UI persistence)
    if frame and IsValid(frame.previewModel) then
        local id = GetShapeKeyIdForName(frame.previewModel, field)
        if id then
            characterData.shape_keys[id] = value
            characterData.shapeKeysByName[field] = value
            frame.previewModel:SetFlexWeight(id, value)
            return
        end
    end
    -- Bodygroups are stored in characterData.bodygroups (bodygroup name = key)
    if characterData.bodygroups and characterData.bodygroups[field] ~= nil then
        characterData.bodygroups[field] = value
        RefreshEncodedBodygroups()
        return
    end
    if field == "pupils_texture" then
        characterData.pupils_texture = isstring(value) and value or ""
        if not characterData.pupils_separate then
            characterData.pupil_left = characterData.pupils_texture
            characterData.pupil_right = characterData.pupils_texture
        end
        if frame and IsValid(frame.previewModel) then
            ApplyPupilsFromCharacterData(frame.previewModel, characterData.gender, characterData)
            -- Re-poser les pupilles efface le submaterial du tatouage -> on le ré-applique par-dessus
            -- (sinon un slider yeux le fait "disparaître" dans la preview alors qu'on ne l'édite pas).
            if LZY_ApplyTattooFromCharacterData then LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData) end
        end
        LZY_RebuildNestedPupilColorSwatches()
        LZY_BumpThumbnailsTagged(frame._lzyEyesPupilCanvas, "eyes_pupil")
        return
    end
    if field == "pupil_left" or field == "pupil_right" then
        characterData[field] = isstring(value) and value or ""
        if frame and IsValid(frame.previewModel) then
            ApplyPupilsFromCharacterData(frame.previewModel, characterData.gender, characterData)
            -- Re-poser les pupilles efface le submaterial du tatouage -> on le ré-applique par-dessus
            -- (sinon un slider yeux le fait "disparaître" dans la preview alors qu'on ne l'édite pas).
            if LZY_ApplyTattooFromCharacterData then LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData) end
        end
        LZY_RebuildNestedPupilColorSwatches()
        LZY_BumpThumbnailsTagged(frame._lzyEyesPupilCanvas, "eyes_pupil")
        return
    end
    if field == "pupils_separate" then
        local want = value and true or false
        local changed = (characterData.pupils_separate and true or false) ~= want
        characterData.pupils_separate = want
        if not characterData.pupils_separate then
            characterData.pupils_texture = characterData.pupil_left or characterData.pupil_right or characterData.pupils_texture or ""
            characterData.pupil_left = characterData.pupils_texture
            characterData.pupil_right = characterData.pupils_texture
        else
            characterData.pupil_left = characterData.pupil_left or characterData.pupils_texture or ""
            characterData.pupil_right = characterData.pupil_right or characterData.pupil_left or ""
        end
        if frame and IsValid(frame.previewModel) then
            ApplyPupilsFromCharacterData(frame.previewModel, characterData.gender, characterData)
            -- Re-poser les pupilles efface le submaterial du tatouage -> on le ré-applique par-dessus
            -- (sinon un slider yeux le fait "disparaître" dans la preview alors qu'on ne l'édite pas).
            if LZY_ApplyTattooFromCharacterData then LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData) end
        end
        -- Layout (tabs vs combined grid) only changes when the toggle flips. Random always
        -- writes false; rebuilding here while not on Yeux is what reopened the eyes panel.
        if changed then
            ScheduleRefreshEyesSubPage()
        end
        return
    end
    if field == "firstname" or field == "lastname" then
        characterData[field] = trimStr(isstring(value) and value or tostring(value or ""))
        ResetCharacterNameAvailabilityState()
        if IsValid(frame) then
            if field == "firstname" and IsValid(frame.firstNameInput) then
                frame.firstNameInput:SetText(characterData.firstname)
                if IsValid(frame.firstNameInput.clearBtn) then
                    frame.firstNameInput.clearBtn:SetVisible(characterData.firstname ~= "")
                end
            elseif field == "lastname" and IsValid(frame.lastNameInput) then
                frame.lastNameInput:SetText(characterData.lastname)
                if IsValid(frame.lastNameInput.clearBtn) then
                    frame.lastNameInput.clearBtn:SetVisible(characterData.lastname ~= "")
                end
            end
        end
        RefreshCharacterNameGate()
        return
    end
    if field == "tattoo_pos" then
        if istable(value) then
            local slot = tonumber(value.slot) == 2 and 2 or 1
            local suf = slot == 1 and "" or "_2"
            local xKey, yKey = "tattoo_pos_x" .. suf, "tattoo_pos_y" .. suf
            -- 0..1 comme l'écriture serveur et le rendu (la fenêtre 0,4..0,6 bridait le placement direct).
            characterData[xKey] = math.Clamp(tonumber(value.x or value.px or value[1]) or characterData[xKey] or 0.5, 0, 1)
            characterData[yKey] = math.Clamp(tonumber(value.y or value.py or value[2]) or characterData[yKey] or 0.5, 0, 1)
        end
        if frame and IsValid(frame.previewModel) then
            LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        end
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
        return
    end
    if field == "tattoo_scale" then
        if istable(value) then
            local slot = tonumber(value.slot) == 2 and 2 or 1
            local suf = slot == 1 and "" or "_2"
            local sxKey, syKey = "tattoo_scale_x" .. suf, "tattoo_scale_y" .. suf
            characterData[sxKey] = math.Clamp(tonumber(value.x or value.sx or value[1]) or characterData[sxKey], 0.05, 10.0)
            characterData[syKey] = math.Clamp(tonumber(value.y or value.sy or value[2]) or characterData[syKey], 0.05, 10.0)
        end
        if frame and IsValid(frame.previewModel) then
            LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        end
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
        return
    end
    characterData[field] = value
    if field == "gender" then
        characterData.face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(value)
        characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(value, characterData.faction)
        local hairStyles = LZY_CHARACTER_CONFIG.GetAvailableHairStyles(value)
        characterData.hair_model = (hairStyles[1] and hairStyles[1].model) or characterData.hair_model
        if LZY_CHARACTER_CONFIG.NormalizeGender(value) == "male" then
            characterData.beard_model = ""
            characterData.mustache_model = ""
        else
            characterData.beard_model = ""
            characterData.mustache_model = ""
        end
        if frame and IsValid(frame.previewModel) then
            DestroyPreviewModel(frame.previewModel)
            frame.previewModel = nil
            -- Le modele de tete change (homme<->femme) => le cache nom->flexID devient
            -- perime (IDs valables pour l'ANCIENNE tete). Sans ce reset, les shape keys
            -- s'ecrivent sur de mauvais flex => visage deforme ET SAUVEGARDE ainsi.
            ShapeKeyNameToId = {}
            local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(characterData.faction)
            frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)

            characterData.firstname = defaultCharacterData.firstname
            characterData.lastname = defaultCharacterData.lastname
            ResetCharacterNameAvailabilityState()
            characterData.scale = defaultCharacterData.scale
            characterData.skin_color = defaultCharacterData.skin_color
            characterData.hair_color1 = defaultCharacterData.hair_color1
            characterData.hair_color2 = defaultCharacterData.hair_color2
            characterData.hair_details_color = defaultCharacterData.hair_details_color
            characterData.hair_gradient_angle = defaultCharacterData.hair_gradient_angle
            characterData.eyes_color = defaultCharacterData.eyes_color
            characterData.bodygroups = defaultCharacterData.bodygroups
            characterData.bodygroupsString = defaultCharacterData.bodygroupsString
            characterData.pupils_texture = defaultCharacterData.pupils_texture
            characterData.pupils_separate = defaultCharacterData.pupils_separate
            characterData.pupil_left = defaultCharacterData.pupil_left
            characterData.pupil_right = defaultCharacterData.pupil_right
            for _, s in ipairs({ "", "_2" }) do
                characterData["tattoo_texture" .. s] = defaultCharacterData["tattoo_texture" .. s]
                characterData["tattoo_color"   .. s] = defaultCharacterData["tattoo_color"   .. s]
                characterData["tattoo_pos_x"   .. s] = defaultCharacterData["tattoo_pos_x"   .. s]
                characterData["tattoo_pos_y"   .. s] = defaultCharacterData["tattoo_pos_y"   .. s]
                characterData["tattoo_scale_x" .. s] = defaultCharacterData["tattoo_scale_x" .. s]
                characterData["tattoo_scale_y" .. s] = defaultCharacterData["tattoo_scale_y" .. s]
                characterData["tattoo_opacity" .. s] = defaultCharacterData["tattoo_opacity" .. s]
                characterData["tattoo_rotation" .. s] = defaultCharacterData["tattoo_rotation" .. s]
            end
            characterData.body_tattoos = {}
            LZY_CC_ApplyPreviewBodyTattoo(frame.previewModel, characterData) -- modèle recréé AVANT ce reset
            characterData.shape_keys = defaultCharacterData.shape_keys
            characterData.shapeKeysByName = table.Copy(defaultCharacterData.shapeKeysByName or {})
            RefreshEncodedBodygroups()
            SyncDefaultShapeKeysToFlexIds(frame.previewModel)
            -- Refresh visible inputs/sliders so they display the reset values
            if IsValid(frame) then
                if frame.firstNameInput and IsValid(frame.firstNameInput) then
                    frame.firstNameInput:SetText(characterData.firstname or "")
                    if IsValid(frame.firstNameInput.clearBtn) then
                        frame.firstNameInput.clearBtn:SetVisible(frame.firstNameInput:GetText() ~= "")
                    end
                end
                if frame.lastNameInput and IsValid(frame.lastNameInput) then
                    frame.lastNameInput:SetText(characterData.lastname or "")
                    if IsValid(frame.lastNameInput.clearBtn) then
                        frame.lastNameInput.clearBtn:SetVisible(frame.lastNameInput:GetText() ~= "")
                    end
                end
                if frame.scaleSlider and IsValid(frame.scaleSlider) and frame.scaleSlider.SetValue then
                    frame.scaleSlider:SetValue(characterData.scale)
                end
                if frame.gradientAngleSlider and IsValid(frame.gradientAngleSlider) and frame.gradientAngleSlider.SetValue then
                    frame.gradientAngleSlider:SetValue(characterData.hair_gradient_angle)
                end
                -- Refresh face/eyebrows shape sliders if they exist (page 3 subpages)
                local shapeSliders = {
                    frame.noseShape1Slider, frame.noseShape2Slider, frame.noseShape3Slider, frame.noseShape4Slider,
                    frame.eyeShape1Slider, frame.eyeShape2Slider, frame.eyeShape3Slider, frame.eyeShape4Slider,
                    frame.mouthShape1Slider, frame.mouthShape2Slider, frame.mouthShape3Slider, frame.mouthShape4Slider,
                    frame.chinShape1Slider, frame.chinShape2Slider, frame.chinShape3Slider, frame.chinShape4Slider,
                    frame.eyebrowsShape1Slider, frame.eyebrowsShape2Slider, frame.eyebrowsShape3Slider, frame.eyebrowsShape4Slider, frame.eyebrowsShape5Slider,
                    frame.eyebrowsShape6Slider, frame.eyebrowsShape7Slider, frame.eyebrowsShape8Slider, frame.eyebrowsShape9Slider,
                }
                for i, slider in ipairs(shapeSliders) do
                    local flexName = PREVIEW_FLEX_NAMES and PREVIEW_FLEX_NAMES[i]
                    if slider and IsValid(slider) and slider.SetValue and flexName then
                        local val = characterData.shapeKeysByName and characterData.shapeKeysByName[flexName]
                        if val == nil then val = 0 end
                        slider:SetValue(val)
                    end
                end
                RefreshCharacterNameGate()
                if currentPage == 3 and frame.CreateSubPage1 and frame.currentPage3SubPage == 1 then
                    frame:CreateSubPage1()
                end
                local isMaleGender = LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) == "male"
                if IsValid(frame.barbesMoustachesButton) then
                    frame.barbesMoustachesButton:SetVisible(isMaleGender)
                end
                -- Femme sur la page Barbes (5, homme-only) -> on rebascule sur Visage (1re categorie).
                if currentPage == 3 and not isMaleGender and frame.currentPage3SubPage == 5 and frame.CreateSubPage2 then
                    frame:CreateSubPage2()
                end
                -- Repositionnement gender-dependant (creation normale) : Barbes n'existe que pour
                -- les hommes, donc Tatouage ET Cheveux — les 2 dernieres categories — remontent d'un
                -- cran chez la femme. Cheveux = dernier slot (687 h / 593 f) ; Tatouage juste au-dessus
                -- (593 h / 499 f). Gate BARBER : chez le coiffeur Cheveux reste fixe en haut (217).
                if not LZY_CHARACTER_BARBER_MODE then
                    if IsValid(frame.tattooButton) then
                        frame.tattooButton:gSetPos(40, isMaleGender and 593 or 499)
                    end
                    if IsValid(frame.cheveuxButton) then
                        frame.cheveuxButton:gSetPos(40, isMaleGender and 687 or 593)
                    end
                end
                if currentPage == 3 and frame.CreateSubPage6 and frame.currentPage3SubPage == 6 then
                    frame:CreateSubPage6()
                end
            end
        end
        return
    end
    if not IsValid(frame.previewModel) then return end
    if field == "scale" then
        frame.previewModel:SetModelScale(value)
    elseif field == "skin_color" then
        frame.previewModel:SetSkin(value)
        if IsValid(frame.previewModel.bodyEnt) then frame.previewModel.bodyEnt:SetSkin(value) end
        -- Re-applique le tattoo car le changement de skin change la face VMT
        -- du model (slot index ET face texture differents par skin). L'ancien
        -- submaterial RT-baked pointe sur la mauvaise face texture / slot
        -- => tattoo disparait visuellement. LZY_ApplyTattooFromCharacterData
        -- clear + re-bake + re-applique au bon slot pour le nouveau skin.
        if LZY_ApplyTattooFromCharacterData then
            LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        end
        -- Tatouages du corps : la teinte change le matériau de peau (et son indice).
        LZY_CC_ApplyPreviewBodyTattoo(frame.previewModel, characterData)
        -- COUPE CHAUVE : sa teinte = SKIN du modèle de coupe (matériaux de peau) ->
        -- re-sync quand la peau change (no-op pour les coupes normales : même gradient).
        ApplyHairGradientToPreviewHairAndFacial(frame.previewModel)
    elseif field == "hair_model" then
        if IsValid(frame.previewModel.hairEnt) then
            frame.previewModel.hairEnt:SetModel(value)
        end
        ApplyHairGradientToPreviewHairAndFacial(frame.previewModel)
        LZY_ApplyHairCheveuxPageLayout()
    elseif field == "beard_model" then
        local v = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(isstring(value) and value or "")
        characterData.beard_model = v
        if IsValid(frame.previewModel.beardEnt) then
            SafeRemoveEntity(frame.previewModel.beardEnt)
            frame.previewModel.beardEnt = nil
        end
        if v ~= "" then
            local ent = frame.previewModel
            ent.beardEnt = ClientsideModel(v, RENDERGROUP_OPAQUE)
            if IsValid(ent.beardEnt) then
                TrackClientsideModel(ent.beardEnt)
                ent.beardEnt:SetParent(ent)
                ent.beardEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                ApplyHairGradientToPreview(ent, ent.beardEnt, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle, characterData.hair_details_color)
            end
        end
        ApplyHairGradientToPreviewHairAndFacial(frame.previewModel)
    elseif field == "mustache_model" then
        local v = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(isstring(value) and value or "")
        characterData.mustache_model = v
        if IsValid(frame.previewModel.mustacheEnt) then
            SafeRemoveEntity(frame.previewModel.mustacheEnt)
            frame.previewModel.mustacheEnt = nil
        end
        if v ~= "" then
            local ent = frame.previewModel
            ent.mustacheEnt = ClientsideModel(v, RENDERGROUP_OPAQUE)
            if IsValid(ent.mustacheEnt) then
                TrackClientsideModel(ent.mustacheEnt)
                ent.mustacheEnt:SetParent(ent)
                ent.mustacheEnt:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
                ApplyHairGradientToPreview(ent, ent.mustacheEnt, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle, characterData.hair_details_color)
            end
        end
        ApplyHairGradientToPreviewHairAndFacial(frame.previewModel)
    elseif field == "hair_color1" or field == "hair_color2" or field == "hair_gradient_angle" or field == "hair_details_color" then
        ApplyHairGradientToPreviewHairAndFacial(frame.previewModel)
    elseif field == "tattoo_texture" then
        local v = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(isstring(value) and value or "")
        characterData.tattoo_texture = v
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    elseif field == "tattoo_color" then
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    elseif field == "tattoo_texture_2" then
        local v = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(isstring(value) and value or "")
        characterData.tattoo_texture_2 = v
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    elseif field == "tattoo_color_2" then
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    elseif field == "tattoo_opacity" or field == "tattoo_opacity_2" then
        characterData[field] = math.Clamp(tonumber(value) or 1, 0, 1)
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    elseif field == "tattoo_rotation" or field == "tattoo_rotation_2" then
        characterData[field] = (tonumber(value) or 0) % 360
        LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        if IsValid(frame) and IsValid(frame.currentSubPagePanel) and frame.currentPage3SubPage == 6 then
            local c = frame.currentSubPagePanel:GetCanvas()
            if IsValid(c) then LZY_BumpThumbnailsTagged(c, "evo_tattoo_thumb") end
        end
    end
end

-- ============================================================
-- DÉ ALEATOIRE : randomise TOUTE l'apparence d'un coup.
-- Conserve faction / genre / prenom / nom. On passe par UpdateCharacterData
-- (= exactement le meme chemin que les widgets) donc le preview 3D se met a
-- jour en live ; le rafraichissement des widgets visibles (slider Taille) est
-- fait par l'appelant (le bouton dé en Page 2, a cote des icones de sexe).
-- ============================================================
local function LZY_RandFloat(min, max)
    return min + math.random() * (max - min)
end

local function LZY_RandStep(min, max, step)
    local steps = math.floor((max - min) / step + 0.5)
    return math.Clamp(min + math.random(0, steps) * step, min, max)
end

local function LZY_RandColor()
    return Color(math.random(0, 255), math.random(0, 255), math.random(0, 255))
end

local function LZY_PickRandom(tbl)
    if not istable(tbl) or #tbl == 0 then return nil end
    return tbl[math.random(1, #tbl)]
end

-- Morphs structurels du visage : plage moderee (0.2-0.8) pour eviter les tetes
-- grotesques que produirait un random pur aux extremes 0/1.
local LZY_RANDOM_FACE_SHAPES = {
    "Nose_shape1", "Nose_shape2", "Nose_shape3", "Nose_shape4",
    "Eye_shape1", "Eye_shape2", "Eye_shape3", "Eye_shape4",
    "Mouth_shape1", "Mouth_shape2", "Mouth_shape3", "Mouth_shape4",
    "Chin_shape1", "Chin_shape2", "Chin_shape3", "ear_shape",
}
-- Morphs d'expression des sourcils : on reste tres discret (un visage neutre est
-- plus joli qu'un visage fige en colere + triste + heureux a la fois).
local LZY_RANDOM_EYEBROW_EXPR = {
    "Serious_R", "Serious_L", "Sad_R", "Sad_L",
    "Happy_R", "Happy_L", "Angry_R", "Angry_L",
}

-- Helpers de randomisation PAR catégorie (réutilisés par le random global ET par
-- les dés des PNJ métier qui ne randomisent que leur catégorie -> "que les bons trucs").
local function LZY_RandomizeHair()
    local hair = LZY_PickRandom(LZY_CHARACTER_CONFIG.GetSelectableHairStyles(characterData.gender))
    if hair and hair.model then UpdateCharacterData("hair_model", hair.model) end
    UpdateCharacterData("hair_color1", LZY_RandColor())
    UpdateCharacterData("hair_color2", LZY_RandColor())
    UpdateCharacterData("hair_details_color", LZY_RandColor())
    UpdateCharacterData("hair_gradient_angle", math.random(0, 360))
end

local function LZY_RandomizeEyebrows()
    UpdateCharacterData("Thickness", LZY_RandFloat(0.25, 0.9))
    UpdateCharacterData("Length", LZY_RandFloat(0.25, 0.9))
    UpdateCharacterData("Down", LZY_RandFloat(0.2, 0.8))
    for _, flexName in ipairs(LZY_RANDOM_EYEBROW_EXPR) do
        UpdateCharacterData(flexName, LZY_RandFloat(0, 0.25))
    end
end

local function LZY_RandomizeBeard()
    if LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) == "male" then
        local beard = LZY_PickRandom(LZY_CHARACTER_CONFIG.AVAILABLE_BEARD_STYLES)
        UpdateCharacterData("beard_model", (beard and not beard.none and beard.model) or "")
        local mustache = LZY_PickRandom(LZY_CHARACTER_CONFIG.AVAILABLE_MUSTACHE_STYLES)
        UpdateCharacterData("mustache_model", (mustache and not mustache.none and mustache.model) or "")
    else
        UpdateCharacterData("beard_model", "")
        UpdateCharacterData("mustache_model", "")
    end
end

local function LZY_RandomizeFaceShape()
    for _, flexName in ipairs(LZY_RANDOM_FACE_SHAPES) do
        UpdateCharacterData(flexName, LZY_RandFloat(0.2, 0.8))
    end
end

local function LZY_RandomizeEyes()
    UpdateCharacterData("pupils_separate", false)
    local pupilStyle = LZY_PickRandom(LZY_CHARACTER_CONFIG.AVAILABLE_PUPILS_TEXTURES)
    local pupilEntry = pupilStyle and LZY_PickRandom(pupilStyle)
    if pupilEntry and pupilEntry.path then
        UpdateCharacterData("pupils_texture", pupilEntry.path)
    end
end

local function LZY_RandomizeSkinScale()
    UpdateCharacterData("scale", LZY_RandStep(0.9, 1.1, 0.01))
    local skin = LZY_PickRandom(LZY_CHARACTER_CONFIG.GetSkinColorsForFaction(characterData.faction))
    if skin then UpdateCharacterData("skin_color", skin.id or 0) end
end

local function LZY_RandomizeTattoo()
    local tex = LZY_PickRandom(LZY_CHARACTER_CONFIG.GetRandomTattooPool())
    if tex then
        -- Emplacement 1 = visage OU corps : un tatouage du corps en 1 serait jeté à la sauvegarde.
        local bt = characterData.body_tattoos
        if istable(bt) then
            for i = #bt, 1, -1 do
                if istable(bt[i]) and tonumber(bt[i].k) == 1 then table.remove(bt, i) end
            end
            UpdateCharacterData("body_tattoos", bt)
        end
        UpdateCharacterData("tattoo_color", LZY_RandColor())
        UpdateCharacterData("tattoo_opacity", LZY_RandFloat(0.6, 1.0))
        UpdateCharacterData("tattoo_texture", tex)
    end
end

local function LZY_RandomizeCharacterAppearance()
    if not (frame and IsValid(frame.previewModel)) then return end

    -- Modes "métier" (PNJ coiffeur/tatoueur/sculpteur) : on ne randomise QUE les
    -- catégories que ce métier peut réellement éditer (= les onglets visibles dans
    -- ce mode). C'est le "aléatoire que sur les bons trucs".
    if LZY_CHARACTER_SCULPTOR_MODE then
        -- Chirurgien esthétique : forme du visage + yeux + taille + couleur de peau.
        LZY_RandomizeFaceShape()
        LZY_RandomizeEyes()
        LZY_RandomizeSkinScale()
        -- Le sculpteur n'édite JAMAIS le tatouage -> il doit rester. Mais re-poser visage/pupilles
        -- efface le submaterial du tatouage (il "disparaît" alors qu'on ne l'a pas touché). On le
        -- RE-applique donc par-dessus, à la fin (la data du tatouage est intacte dans characterData).
        if IsValid(frame.previewModel) and LZY_ApplyTattooFromCharacterData then
            LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        end
        return
    elseif LZY_CHARACTER_TATTOO_MODE then
        -- Tatoueur : un tatouage aléatoire.
        LZY_RandomizeTattoo()
        return
    elseif LZY_CHARACTER_BARBER_MODE then
        -- Coiffeur : cheveux + sourcils + barbe/moustache.
        LZY_RandomizeHair()
        LZY_RandomizeEyebrows()
        LZY_RandomizeBeard()
        -- Idem sculpteur : on préserve le tatouage (les sourcils/visage peuvent effacer son submaterial).
        if IsValid(frame.previewModel) and LZY_ApplyTattooFromCharacterData then
            LZY_ApplyTattooFromCharacterData(frame.previewModel, characterData)
        end
        return
    end

    -- Création normale : tout d'un coup (comportement d'origine).
    LZY_RandomizeSkinScale()
    LZY_RandomizeHair()
    LZY_RandomizeFaceShape()
    LZY_RandomizeEyebrows()
    LZY_RandomizeEyes()
    LZY_RandomizeBeard()
    -- Tatouage du visage : ~1 chance sur 3 d'en avoir un (sinon visage net).
    if math.random(1, 3) == 1 then
        LZY_RandomizeTattoo()
    else
        UpdateCharacterData("tattoo_texture", "")
    end
end

-- Musique d'ambiance du créateur : joue en boucle pendant toute la session (choix faction
-- + création). Streamée via sound.PlayFile (comme le menu OST lzy_ost) et NON via
-- CreateSound/EmitSound : ce dernier, sur un MP3 non précaché, part "dans le vide" au 1er
-- essai (le moteur charge le fichier en asynchrone) et SoundDuration renvoie 0 -> l'ancien
-- code retombait sur un fallback de 180s => la musique n'arrivait que ~3 min plus tard.
-- sound.PlayFile charge le fichier puis appelle le callback quand PRÊT -> démarrage immédiat.
local LZY_CHARACTER_AMBIENT_TRACKS = {
    -- "Number One" (demande user), même piste que le menu OST (lzy_ost). Chemin SANS le
    -- préfixe "sound/" ici ; on le préfixe pour sound.PlayFile (qui l'exige, cf. lzy_ost).
    "n9up65zys7zbducp/ost_anime/01_number_one.mp3",
}
local LZY_CHARACTER_AMBIENT_VOLUME = 0.05  -- tres soft (ambiance discrete uniquement)
local LZY_CHARACTER_AMBIENT_TIMER  = "LZY_CharacterCreator:AmbientLoop"

-- Coupe proprement la track courante + le timer d'enchainement, et INVALIDE tout
-- chargement async encore en vol (bump du token) -> pas de musique orpheline si on ferme
-- le créateur pendant le chargement.
local function StopAmbient(panel)
    if not panel then return end
    timer.Remove(LZY_CHARACTER_AMBIENT_TIMER)
    panel._ambientToken = (panel._ambientToken or 0) + 1
    if panel._ambientSound then
        if IsValid(panel._ambientSound) then panel._ambientSound:Stop() end
        panel._ambientSound = nil
    end
end

local function PlayNextAmbient(panel)
    if not IsValid(panel) then return end

    StopAmbient(panel) -- coupe la precedente (et bump le token) avant d'enchainer

    -- Pick random en evitant de retomber sur la meme track 2x de suite
    local idx
    repeat
        idx = math.random(1, #LZY_CHARACTER_AMBIENT_TRACKS)
    until idx ~= panel._ambientLastIdx or #LZY_CHARACTER_AMBIENT_TRACKS == 1
    panel._ambientLastIdx = idx
    local track = LZY_CHARACTER_AMBIENT_TRACKS[idx]

    -- "noplay" : on règle volume + boucle AVANT de jouer (pas de blip). Chemin AVEC "sound/".
    local marker = panel._ambientToken
    sound.PlayFile("sound/" .. track, "noplay", function(chan, errId, errName)
        -- Créateur fermé / relance entre-temps -> on jette ce canal (evite une musique orpheline).
        if not IsValid(panel) or panel._ambientToken ~= marker then
            if IsValid(chan) then chan:Stop() end
            return
        end
        if not IsValid(chan) then return end -- echec de chargement (errId / errName)

        panel._ambientSound = chan
        chan:SetVolume(LZY_CHARACTER_AMBIENT_VOLUME)

        if #LZY_CHARACTER_AMBIENT_TRACKS == 1 then
            chan:EnableLooping(true) -- une seule piste : boucle native SEAMLESS (pas de timer)
            chan:Play()
            return
        end

        -- Plusieurs pistes : enchaine a la fin sur une AUTRE (duree reelle, canal charge).
        chan:Play()
        local duration = chan:GetLength()
        if not duration or duration <= 0 then duration = 180 end
        timer.Create(LZY_CHARACTER_AMBIENT_TIMER, duration + 1, 1, function()
            if IsValid(panel) then PlayNextAmbient(panel) end
        end)
    end)
end

function PANEL:Init()
    self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	-- Pas d'Échap-close sur le créateur de personnage : on ne doit pas pouvoir
	-- abandonner la création en plein milieu via Échap.
	self:SetVisible(true)
	self:gSetSize(1920, 1080)
	self:gSetPos(0, 0)

	-- Session d'édition PNJ métier (coiffeur/tatoueur/sculpteur) : capturée ICI car les globals
	-- BARBER_MODE sont remis à nil à la fermeture -> on s'en souvient pour signaler EditorClose au
	-- serveur dans OnRemove (sortie de "l'instance" : InCharacterMenu + god). Le créateur INITIAL
	-- (non barber) ne signale rien (il gère son InCharacterMenu lui-même).
	self._lzyBarberSession = (LZY_CHARACTER_BARBER_MODE == true)

	-- Lance la boucle de musique d'ambiance random.
	PlayNextAmbient(self)

    -- Barber mode (addon lzy_coiffeur) : on pre-remplit characterData avec la
    -- data character actuelle du joueur pour que l'editeur s'ouvre directement
    -- sur ses parametres existants. Le firstname/lastname est preserve mais
    -- les inputs sont caches (voir CreatePage1).
    if LZY_CHARACTER_BARBER_MODE and istable(LZY_CHARACTER_BARBER_DATA) then
        for k, v in pairs(LZY_CHARACTER_BARBER_DATA) do
            characterData[k] = v
        end
        -- face_model n'a PAS de colonne DB -> jamais présent dans BARBER_DATA -> la fusion ci-dessus
        -- laisse characterData.face_model au défaut MÂLE (déclaré ~l.208), et l'aperçu (l.551
        -- `face_model or GetDefaultFaceModel(gender)`) prend ce défaut non-nil -> TÊTE HOMME sur un
        -- perso FEMME. On le recalcule depuis le genre fusionné (la tête = toujours dérivée du genre,
        -- jamais éditée). Idem body_model par sécurité s'il manquait.
        characterData.face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        if not (isstring(characterData.body_model) and characterData.body_model ~= "") then
            characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, characterData.faction)
        end
    elseif LZY_CHARACTER_CK_MODE and istable(LZY_CHARACTER_CK_DATA) then
        -- CK recreate : même unique_id / faction ; nom + genre + looks éditables.
        for k, v in pairs(LZY_CHARACTER_CK_DATA) do
            characterData[k] = v
        end
        characterData.face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        if characterData._ckAfterHollow then
            characterData.faction = "Hollow"
            characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, "Hollow")
            characterData.face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        elseif not (isstring(characterData.body_model) and characterData.body_model ~= "") then
            characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, characterData.faction)
        end
        -- Noms vidés : l'objectif CK est de recrée l'identité (préremplir l'ancien
        -- laisserait trop facilement "valider sans changer").
        characterData.firstname = ""
        characterData.lastname = ""
    end

    ResetCharacterNameAvailabilityState()

    -- Slot du créateur : par défaut AUCUN slot animation (création RP normale). Posé à un
    -- slot animation (4/5) dans la branche LZY_ANIM_CREATE plus bas (création depuis un slot anim).
    characterData._animSlot = nil

    -- For left-click drag rotation of the preview model
    self.previewRotation = 0
    self.isRotatingPreview = false
    self.lastMouseX = nil

    -- Barber mode : on saute la Page 1 (faction selection) puisque la faction
    -- est verrouillee. On va directement sur Page 2 ou les inputs nom + boutons
    -- gender seront caches (voir CreatePage2).
    -- IMPORTANT : on defere d'un frame via timer.Simple(0, ...) parce que
    -- CreatePage2 declenche des CreateSlider dont l'updateFunction utilise la
    -- local `frame` du fichier - or `frame` n'est assignee qu'APRES que
    -- vgui.Create() retourne (par OpenCharacterCreator). Sans defer => nil ref.
    -- On en profite pour aussi creer le preview model (qui en mode normal est
    -- cree au moment du choix de faction Page 1, qu'on saute ici).
    if LZY_CHARACTER_BARBER_MODE then
        local panel = self
        timer.Simple(0, function()
            if not IsValid(panel) then return end

            -- Cree le preview model avec la pos/ang qui correspond a la faction
            -- du joueur (Shinigami / Hollow). La faction n'est PAS editable en
            -- barber mode donc on la prend telle quelle dans characterData.
            local faction = tostring(characterData.faction or "Shinigami")
            local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(faction)
            -- frame est maintenant assignee (set par OpenCharacterCreator avant
            -- que le timer fire), on peut creer le previewModel directement
            -- sur frame.previewModel comme les autres code paths.
            if not IsValid(panel.previewModel) then
                panel.previewModel = createClientsidePlayerModel(pos, ang, characterData)
                if IsValid(panel.previewModel) then
                    -- Barber/sculptor : charge les TRAITS ACTUELS (nez/yeux/bouche...) depuis les
                    -- shape_keys du perso AVANT le sync (sinon SyncDefault fige les défauts) et avant
                    -- CreatePage3 (pour que les sliders affichent les vraies valeurs). Le rendu suit
                    -- via ApplyPreviewModelFlexWeights (par frame), qui lit shapeKeysByName.
                    LZY_LoadShapeKeysByNameFromIds(panel.previewModel)
                    SyncDefaultShapeKeysToFlexIds(panel.previewModel)
                end
            end
            -- Barber mode : on saute aussi Page 2 (scale/skin color/body model)
            -- et on va direct sur Page 3. Le coiffeur s'occupe que des cheveux
            -- + pilosite faciale, donc Page 3 expose uniquement cheveux /
            -- sourcils / barbes-moustaches (visage / yeux / tatouage caches).
            panel:CreatePage3()
        end)
    elseif LZY_CHARACTER_CK_MODE then
        -- CK : choix de faction (Shinigami / Hollow) puis Page 2. Un slot animation
        -- reste verrouillé sur sa faction.
        self._fromCK = true
        self._ckOriginFaction = LZY_CK_NormFaction(characterData.faction)
        self._ckOriginBody = characterData.body_model
        self._ckOriginSkin = characterData.skin_color
        local panel = self
        timer.Simple(0, function()
            if not IsValid(panel) then return end
            local slot = tonumber(characterData.slot)
            local animLocked = EVO_ANIM and EVO_ANIM.SLOT_FACTION and slot and EVO_ANIM.SLOT_FACTION[slot] ~= nil
            local fac = LZY_CK_NormFaction(characterData.faction)
            if fac ~= "" then characterData.faction = fac end
            panel._ckOriginFaction = fac
            if characterData._ckAfterHollow then
                panel._fromFinalize = true
                local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor("Hollow")
                if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
                if frame then
                    frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
                    if IsValid(frame.previewModel) then SyncDefaultShapeKeysToFlexIds(frame.previewModel) end
                end
                panel:CreatePage2()
            elseif animLocked or (fac ~= "" and fac ~= "Shinigami" and fac ~= "Hollow") then
                local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(fac ~= "" and fac or "Shinigami")
                if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
                if frame then
                    frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
                    if IsValid(frame.previewModel) then SyncDefaultShapeKeysToFlexIds(frame.previewModel) end
                end
                panel:CreatePage2()
            else
                panel._ckCanSwitchFaction = true
                panel:CreateCKFactionStep()
            end
        end)
    elseif LZY_ANIM_CREATE and (LZY_ANIM_CREATE.faction == "Shinigami" or LZY_ANIM_CREATE.faction == "Hollow") then
        -- Slot ANIMATION (animateur) : faction PRÉDÉFINIE -> on SAUTE la Page 1 (choix de
        -- faction + son check de map), comme le barber mode, et on va DIRECT à la Page 2.
        -- La faction + le slot forcé (4/5) partent avec characterData à la création.
        local animF, animSlot = LZY_ANIM_CREATE.faction, LZY_ANIM_CREATE.slot
        LZY_ANIM_CREATE = nil -- consommé (one-shot)
        characterData.faction    = animF
        characterData._animSlot  = animSlot
        self._fromAnimSlot = true -- Page 1 (faction) SAUTÉE -> "retour" de Page 2 ramène au HUB (pas au choix de faction)
        characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, animF)
        local panel = self
        timer.Simple(0, function() -- `frame` n'est assignée qu'après vgui.Create -> defer
            if not IsValid(panel) then return end
            -- Ancre PER-MAP (GetCreatorAnchor) : sur Hueco le perso se place a l'ancre Hueco,
            -- pas aux coords Seireitei des anciens globals INSTANCE_POS_* (legacy).
            local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(animF)
            if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
            if frame then
                frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
                if IsValid(frame.previewModel) then SyncDefaultShapeKeysToFlexIds(frame.previewModel) end
            end
            panel:CreatePage2()
        end)
    elseif EVO_HollowProg and EVO_HollowProg._Finalizing then
        -- FINALISATION Hollow (evo_hollow_progression) : on devient Arrancar -> on est FORCÉMENT
        -- Hollow, donc on SAUTE la page de choix de faction (comme le slot animateur) et on va
        -- DIRECT au character creator (Page 2).
        -- IMPORTANT : on NE consomme PAS _Finalizing ici — il reste true jusqu'à création /
        -- retour HUB pour que RequestAllPM / Sync / HollowExit ne rebuild pas (freeze).
        self._fromFinalize = true -- Page 1 (faction) sautee -> "retour" de Page 2 ramene au HUB.
        local resume = EVO_HollowProg._FinalizeResumeData
        EVO_HollowProg._FinalizeResumeData = nil
        if resume then
            for k, v in pairs(resume) do characterData[k] = v end
        else
            ResetCharacterDataToDefaults()
        end
        characterData.faction    = "Hollow"
        characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, "Hollow")
        characterData.face_model = characterData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        local panel = self
        timer.Simple(0.15, function() -- léger délai : monde pas toujours prêt au reconnect
            if not IsValid(panel) then return end
            -- Ancre PER-MAP : finalisation Arrancar sur Hueco -> ancre Hueco (pas Seireitei).
            local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor("Hollow")
            if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
            if frame then
                frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
                if IsValid(frame.previewModel) then SyncDefaultShapeKeysToFlexIds(frame.previewModel) end
            end
            panel:CreatePage2()
        end)
    else
        self:CreatePage1()
    end
end

function PANEL:Paint(w, h) end

function PANEL:Think()
    local dt = FrameTime()

    -- Re-apply flex weights every frame so model animation / pose doesn't overwrite them
    if IsValid(self.previewModel) then
        -- Handle left-click drag rotation of the preview model, only on the right side of the screen
        local mx = gui.MouseX()
        local leftDown = input.IsMouseDown(MOUSE_LEFT)
        local onRightSide = mx >= ScrW() * 0.55
        -- Page Tatouage : un clic sur le visage / la peau place ou déplace le tatouage
        -- (PANEL:LZY_TattooPlacementThink, appearance) ; un clic dans le vide tourne le perso.
        if self.LZY_TattooPlacementThink and self:LZY_TattooPlacementThink(leftDown, onRightSide) then
            leftDown = false
        end
        if leftDown and onRightSide and not self.isRotatingPreview then
            self.isRotatingPreview = true
            self.lastMouseX = mx
        elseif (not leftDown or not onRightSide) and self.isRotatingPreview then
            self.isRotatingPreview = false
            self.lastMouseX = nil
        end
        if self.isRotatingPreview and self.lastMouseX then
            local dx = mx - self.lastMouseX
            self.lastMouseX = mx
            local rotateSpeed = 0.4
            self.previewRotation = (self.previewRotation or 0) + dx * rotateSpeed
        end

        local rft = RealFrameTime()
        self.previewModel:FrameAdvance(rft)
        self.previewModel:SetupBones()
        if IsValid(self.previewModel.bodyEnt) then
            self.previewModel.bodyEnt:FrameAdvance(rft)
            self.previewModel.bodyEnt:SetupBones()
        end

        -- Apply accumulated rotation relative to the base angles
        if self.previewModel.baseAngles and self.previewRotation then
            local base = self.previewModel.baseAngles
            local ang = Angle(base.p, base.y + self.previewRotation, base.r)
            self.previewModel:SetAngles(ang)
        end

        ApplyPreviewModelFlexWeights(self.previewModel)
        -- (PERF) Degrade cheveux PLUS recalcule chaque frame : il est deja applique a
        -- la creation du modele ET re-applique a chaque changement reel (hair_model /
        -- couleur / angle / barbe / moustache, cf. UpdateCharacterData lignes ~2435+).
        -- Le faire en Think = ~180 rebuilds de render-target/s pour rien -> gros gain FPS.
        LZY_SyncPreviewFacialHairVisibilityForAppearancePage()
    end

    -- Auto-zoom camera : interpolation douce de previewZoom vers previewZoomTarget
    -- (zoom visage en Page 3 / dezoom corps en Page 2). On s'arrete une fois la
    -- cible atteinte ; le scroll molette efface la cible pour reprendre la main.
    if self.previewZoomTarget and self.previewZoom then
        self.previewZoom = Lerp(CHARACTER_VIEW_ZOOM_LERP * dt, self.previewZoom, self.previewZoomTarget)
        if math.abs(self.previewZoom - self.previewZoomTarget) < 0.5 then
            self.previewZoom = self.previewZoomTarget
            self.previewZoomTarget = nil
        end
    end

    -- Page 3: smooth transition of left panel width 658 -> 529
    if currentPage == 3 and self.leftPanelWidthTarget then
        local speed = 6
        self.leftPanelWidth = Lerp(speed * dt, self.leftPanelWidth, self.leftPanelWidthTarget)
        if math.abs(self.leftPanelWidth - self.leftPanelWidthTarget) < 1 then
            self.leftPanelWidth = self.leftPanelWidthTarget
            self.leftPanelWidthTarget = nil
        end
    end

    -- Subpage fade-in
    if currentPage == 3 and IsValid(self.currentSubPagePanel) and self.subPageFadeAlpha and self.subPageFadeAlpha < 255 then
        local speed = 1
        self.subPageFadeAlpha = math.min(255, Lerp(speed * dt, self.subPageFadeAlpha, 255))
        self.currentSubPagePanel:SetAlpha(math.Round(self.subPageFadeAlpha))
        -- L'en-tête fixe (onglets pupilles/tatouage) est un panneau SEPARE (frere du
        -- scroll, pas dedans -> sinon DScrollPanel le re-parente au canvas et il defile).
        -- On sync donc son alpha a la main pour qu'il fonde avec la sous-page.
        if IsValid(self._lzyStickyHeader) then self._lzyStickyHeader:SetAlpha(math.Round(self.subPageFadeAlpha)) end
        if self.subPageFadeAlpha >= 255 then
            self.subPageFadeAlpha = nil
        end
    end

    -- Page 1 transition obsolete : la page de selection de faction est maintenant
    -- en DHTML (CreatePage1), le fade-out est gere en CSS (classe `fading`) et
    -- StartPage1Transition declenche CreatePage2 via timer.Simple(0.4, ...).
end

function LZY_CK_NormFaction(raw)
    local s = string.Trim(tostring(raw or ""))
    local low = string.lower(s)
    if low == "shinigami" then return "Shinigami" end
    if low == "hollow" or low == "arrancar" then return "Hollow" end
    return s
end

function LZY_CK_HollowUid()
    local uid = 0
    if istable(LZY_CK_RECREATE) then uid = tonumber(LZY_CK_RECREATE.uid) or 0 end
    if uid <= 0 and istable(LZY_CHARACTER_CK_DATA) then
        uid = tonumber(LZY_CHARACTER_CK_DATA.unique_id) or 0
    end
    if uid <= 0 then uid = tonumber(characterData.unique_id) or 0 end
    return uid
end

function LZY_CK_OriginFaction(panel)
    local origin = ""
    if panel and isstring(panel._ckOriginFaction) and panel._ckOriginFaction ~= "" then
        origin = panel._ckOriginFaction
    elseif istable(LZY_CK_RECREATE) and LZY_CK_RECREATE.faction and LZY_CK_RECREATE.faction ~= "" then
        origin = LZY_CK_RECREATE.faction
    elseif istable(LZY_CHARACTER_CK_DATA) and LZY_CHARACTER_CK_DATA.faction and LZY_CHARACTER_CK_DATA.faction ~= "" then
        origin = LZY_CHARACTER_CK_DATA.faction
    end
    return LZY_CK_NormFaction(origin)
end

-- CK Shinigami qui choisit Hollow : larve, jamais la page d'apparence.
function LZY_CK_ShouldStartHollow(panel)
    if characterData._ckAfterHollow then return false end
    local isCK = LZY_CHARACTER_CK_MODE == true
        or (istable(LZY_CK_RECREATE) and (tonumber(LZY_CK_RECREATE.uid) or 0) > 0)
    if not isCK then return false end
    local origin = LZY_CK_OriginFaction(panel)
    if origin == "Hollow" then return false end
    if origin ~= "Shinigami" and origin ~= "" then return false end
    return LZY_CK_HollowUid() > 0
end

function LZY_CK_BeginHollowFromUI()
    local uid = LZY_CK_HollowUid()
    if uid <= 0 then
        NotifyCharacterCreator("CK invalide : personnage introuvable.")
        return false
    end
    if LZY_SetLoadingScreen then LZY_SetLoadingScreen(true) end
    if NCM_CHAR_SELECT and isfunction(NCM_CHAR_SELECT.StopScene) then
        NCM_CHAR_SELECT.StopScene()
    end
    local sent = pcall(function()
        net.Start("EVO:CK:BeginHollowProg")
        net.WriteInt(uid, 32)
        net.SendToServer()
    end)
    if not sent then
        if LZY_SetLoadingScreen then LZY_SetLoadingScreen(false) end
        NotifyCharacterCreator("Progression Hollow indisponible. Reconnecte-toi au serveur.")
        return false
    end
    LZY_CK_RECREATE = nil
    if LZY_CharacterCreator_ForceClose then
        LZY_CharacterCreator_ForceClose()
    end
    return true
end

function PANEL:ApplyCKFaction(faction)
    faction = LZY_CK_NormFaction(faction)
    if faction ~= "Shinigami" and faction ~= "Hollow" then return end
    if faction == "Hollow" and LZY_CK_ShouldStartHollow(self) then
        LZY_CK_BeginHollowFromUI()
        return
    end
    if faction == self._ckOriginFaction then
        characterData.faction = self._ckOriginFaction
        characterData.body_model = self._ckOriginBody
        characterData.skin_color = self._ckOriginSkin
    else
        characterData.faction = faction
        characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, faction)
        characterData.face_model = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        -- Peaux 8/9 = Hollow seulement. Un Shinigami retombe sur la peau claire.
        if faction ~= "Hollow" and (tonumber(characterData.skin_color) or 0) > 7 then
            characterData.skin_color = 0
        end
    end
    local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(characterData.faction)
    if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
    if frame then
        frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
        if IsValid(frame.previewModel) then SyncDefaultShapeKeysToFlexIds(frame.previewModel) end
    end
    self:CreatePage2()
end

function PANEL:CreateCKFactionStep()
    currentPage = 1
    if self.currentPagePanel then self.currentPagePanel:Remove() end
    self.currentPagePanel = vgui.Create("DPanel", self)
    self.currentPagePanel:gSetSize(1920, 1080)
    self.currentPagePanel:gSetPos(0, 0)
    local origin = tostring(self._ckOriginFaction or "")
    self.currentPagePanel.Paint = function(_, w, h)
        surface.SetDrawColor(8, 8, 14, 255)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("CHARACTER KILL", "Inter Bold:" .. gRespFont(22), w * 0.5, gRespY(220), Color(180, 186, 198), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Choisis ta faction", "Inter Bold:" .. gRespFont(48), w * 0.5, gRespY(270), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if origin == "Shinigami" then
            draw.SimpleText("Garder Shinigami ne change rien à ton art spirituel.", "Inter:22", w * 0.5, gRespY(340), Color(200, 204, 214), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("Devenir Hollow retire l'art, pose le jeton, puis lance la progression Hollow.", "Inter:22", w * 0.5, gRespY(372), Color(200, 204, 214), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText("Garder ta faction ne change rien à ton art spirituel.", "Inter:22", w * 0.5, gRespY(340), Color(200, 204, 214), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("En changer le retire et pose un jeton de la même rareté dans ton inventaire.", "Inter:22", w * 0.5, gRespY(372), Color(200, 204, 214), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    local back = vgui.Create("DButton", self.currentPagePanel)
    back:gSetSize(60, 60)
    back:gSetPos(40, 40)
    back:SetText("")
    back.Paint = function(selff, w, h)
        if selff:IsHovered() then
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.go_back_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.go_back_btn)
        end
    end
    back.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        self:Close()
        timer.Simple(0, function()
            if LZY_CharacterSelection and LZY_CharacterSelection.Open then
                LZY_CharacterSelection.Open()
            end
        end)
    end

    local function addCard(x, faction, title, col)
        local btn = vgui.Create("DButton", self.currentPagePanel)
        btn:gSetSize(420, 220)
        btn:gSetPos(x, 460)
        btn:SetText("")
        local current = faction == origin
        btn.Paint = function(selff, w, h)
            local hov = selff:IsHovered()
            local bg = hov and Color(col.r, col.g, col.b, 46) or Color(16, 16, 24, 230)
            draw.RoundedBox(8, 0, 0, w, h, bg)
            surface.SetDrawColor(col.r, col.g, col.b, hov and 255 or 160)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
            draw.SimpleText(title, "Inter Bold:" .. gRespFont(36), w * 0.5, h * 0.38, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            local label = current and "FACTION ACTUELLE" or "CHANGER"
            if (not current) and faction == "Hollow" and origin == "Shinigami" then label = "PROGRESSION" end
            draw.SimpleText(label, "Inter:20", w * 0.5, h * 0.68, current and Color(180, 220, 180) or col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        btn.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            -- Shinigami → Hollow : larve tout de suite. L'apparence Arrancar est à la fin.
            if faction == "Hollow" and LZY_CK_ShouldStartHollow(self) then
                LZY_CK_BeginHollowFromUI()
                return
            end
            self:ApplyCKFaction(faction)
        end
    end

    addCard(500, "Shinigami", "SHINIGAMI", Color(90, 150, 255))
    addCard(1000, "Hollow", "HOLLOW", Color(255, 90, 90))
end

function PANEL:CreatePage1()
    currentPage = 1

    -- Page 1 is the faction selection step: when we come back here,
    -- clear any existing preview entities and reset all values to defaults (same as gender change).
    CleanupClientsideModels()
    if IsValid(self.previewModel) then
        SafeRemoveEntity(self.previewModel)
        self.previewModel = nil
    end
    if IsValid(frame) and IsValid(frame.previewModel) then
        SafeRemoveEntity(frame.previewModel)
        frame.previewModel = nil
    end
    ShapeKeyNameToId = {}

    ResetCharacterDataToDefaults()

    if self.currentPagePanel then
        self.currentPagePanel:Remove()
    end
    self.transitionBgAlpha = 255
    self.currentPagePanel = vgui.Create("DPanel", self)
    self.currentPagePanel:gSetSize(1920, 1080)
    self.currentPagePanel:gSetPos(0, 0)
    -- Le DHTML ci-dessous dessine tout (fond + titre + cards). Le Paint Lua ne
    -- fait plus que servir de filet de securite noir au cas ou le DHTML met du
    -- temps a charger les images au premier frame.
    self.currentPagePanel.Paint = function(selff, w, h)
        surface.SetDrawColor(8, 8, 14, 255)
        surface.DrawRect(0, 0, w, h)
    end

    -- ════════════════════════════════════════════════════════════════════════
    -- DHTML : page de choix de faction style "prime" inspire de la shop.
    -- Fond gradient sombre, deux cards glassmorphism centrees, icones sans
    -- background (transparent PNG), hover lift + glow accent par faction
    -- (cyan pour Shinigami, rouge pour Hollow), description fade-in.
    -- Click -> JS appelle gmod.selectFaction(faction) via le bridge AddFunction.
    -- ════════════════════════════════════════════════════════════════════════
    self.factionHtml = vgui.Create("DHTML", self.currentPagePanel)
    self.factionHtml:gSetSize(1920, 1080)
    self.factionHtml:gSetPos(0, 0)
    self.factionHtml:SetScrollbars(false)
    self.factionHtml:SetAllowLua(false)

    -- Insertion directe dans le HTML (pas un contexte JS), donc pas d'escape
    -- d'apostrophes. On convertit juste les \n en <br> pour les retours ligne.
    local htmlShinigamiDesc = shinigamiText:gsub("\n", "<br>")
    local htmlHollowDesc = hollowText:gsub("\n", "<br>")

    -- Map à faction dédiée (MAP_FACTION) : la carte de l'AUTRE faction est
    -- verrouillée visuellement (grisée, pas de onclick, CTA = sur quelle map
    -- aller) au lieu de laisser cliquer puis rejeter. Le clic reste revalidé
    -- en Lua (gmod.selectFaction) et côté serveur (sv_net.lua) de toute façon.
    local mapFaction = LZY_CHARACTER_CONFIG.MAP_FACTION and LZY_CHARACTER_CONFIG.MAP_FACTION[game.GetMap()]
    -- Faction hébergée sur l'AUTRE serveur : sur une map dédiée (MAP_FACTION), c'est
    -- celle qui n'est PAS celle du lieu. Sa carte reste CLIQUABLE — la choisir propose
    -- un transfert (modale ci-dessous) vers le serveur correspondant, au lieu d'être
    -- verrouillée. Map non dédiée => nil (les deux factions se créent sur place).
    local crossFaction = nil
    if mapFaction then crossFaction = (mapFaction == "Shinigami") and "Hollow" or "Shinigami" end
    local fsrv = LZY_CHARACTER_CONFIG.FACTION_SERVER or {}
    local crossServerName = (crossFaction and fsrv[crossFaction] and fsrv[crossFaction].name) or "l'autre serveur"
    local CTA_PICK   = "&gt;&nbsp;&nbsp;CHOISIR&nbsp;&nbsp;&lt;"
    local shinClass, hollClass = "", ""
    local shinClick  = " onclick=\"onPick('Shinigami')\""
    local hollClick  = " onclick=\"onPick('Hollow')\""
    local shinCta    = (crossFaction == "Shinigami") and ("REJOINDRE " .. string.upper(crossServerName)) or CTA_PICK
    local hollCta    = (crossFaction == "Hollow") and ("REJOINDRE " .. string.upper(crossServerName)) or CTA_PICK
    local html = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; }
html, body { width: 100%; height: 100%; overflow: hidden; background: transparent; font-family: 'Bebas Neue', 'Arial Black', sans-serif; cursor: default; }
body {
  background:
    radial-gradient(ellipse at center, rgba(40,40,70,0.35) 0%, rgba(8,8,14,1) 70%),
    linear-gradient(180deg, #0a0a12 0%, #02020a 100%);
  color: #fff;
  transition: opacity 0.4s ease;
}
body.fading { opacity: 0; }

/* Couche 1 : halo central STATIQUE (plus d'animation continue => CEF au repos).
   Bleu/rouge melanges discrets pour rappeler les deux factions. */
.bg-glow {
  position: absolute; inset: 0; pointer-events: none; opacity: 0.85;
  background:
    radial-gradient(circle at 30% 42%, rgba(70,130,235,0.10) 0%, transparent 45%),
    radial-gradient(circle at 70% 42%, rgba(225,55,55,0.10) 0%, transparent 45%);
}

/* Couche 2 : aura cyan a gauche + aura rouge a droite (statiques) */
.bg-aura-left, .bg-aura-right {
  position: absolute; top: 0; bottom: 0; width: 50%; pointer-events: none;
}
.bg-aura-left {
  left: 0;
  background: radial-gradient(ellipse at 25% 50%, rgba(80,160,220,0.12) 0%, transparent 60%);
}
.bg-aura-right {
  right: 0;
  background: radial-gradient(ellipse at 75% 50%, rgba(220,60,60,0.12) 0%, transparent 60%);
}

/* Couche 3 : vignette sombre sur les bords */
.bg-vignette {
  position: absolute; inset: 0; pointer-events: none;
  background: radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.7) 100%);
}

/* Couche 4 : barre horizontale lumineuse au milieu */
.bg-divider {
  position: absolute; top: 50%; left: 0; right: 0; height: 1px;
  background: linear-gradient(90deg, transparent 0%, rgba(180,180,255,0.15) 30%, rgba(180,180,255,0.25) 50%, rgba(180,180,255,0.15) 70%, transparent 100%);
  pointer-events: none;
}

/* Couche 5 : 4 coins L-markers Valorant-style */
.frame-corner {
  position: absolute; width: 80px; height: 80px;
  border: 2px solid rgba(180, 180, 255, 0.25);
  pointer-events: none;
}
.frame-corner.tl { top: 24px; left: 24px; border-right: none; border-bottom: none; }
.frame-corner.tr { top: 24px; right: 24px; border-left: none; border-bottom: none; }
.frame-corner.bl { bottom: 24px; left: 24px; border-right: none; border-top: none; }
.frame-corner.br { bottom: 24px; right: 24px; border-left: none; border-top: none; }

/* Couche 6 : texte EVO en bas */
.bg-tech {
  position: absolute; bottom: 40px; left: 0; right: 0;
  text-align: center;
  font-family: 'Roboto Mono', 'Consolas', monospace;
  font-size: 13px; letter-spacing: 0.5em;
  color: rgba(180, 200, 255, 0.35);
  pointer-events: none;
}

/* Couche 7 : watermark BLEACH gigantesque derriere (1 element statique, outline
   text - GPU friendly car le texte ne bouge pas, juste rasterise 1 fois). */
.bg-watermark {
  position: absolute; top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  font-size: 220px; font-weight: 900;
  letter-spacing: 0.25em;
  color: transparent;
  -webkit-text-stroke: 1.5px rgba(255, 255, 255, 0.05);
  white-space: nowrap;
  pointer-events: none;
  user-select: none;
  z-index: 0;
}

/* Couche 8 : accent dots/diamants - 6 losanges STATIQUES (plus de pulse =>
   aucune repaint en continu, la page peut rester au repos). */
.accent-dot {
  position: absolute; width: 8px; height: 8px; opacity: 0.8;
  background: rgba(150, 185, 255, 0.9);
  box-shadow: 0 0 12px rgba(150, 185, 255, 0.7);
  transform: rotate(45deg); /* losange */
  pointer-events: none;
}
.accent-dot.red {
  background: rgba(255, 120, 120, 0.9);
  box-shadow: 0 0 12px rgba(255, 120, 120, 0.7);
}
.accent-dot.d1 { top: 18%;  left: 8%; }
.accent-dot.d2 { top: 78%;  left: 12%; opacity: 0.55; }
.accent-dot.d3 { top: 48%;  left: 4%;  opacity: 0.55; }
.accent-dot.d4 { top: 18%;  right: 8%; }
.accent-dot.d5 { top: 78%;  right: 12%; opacity: 0.55; }
.accent-dot.d6 { top: 48%;  right: 4%;  opacity: 0.55; }

/* Couche 9 : fine ligne lumineuse STATIQUE au centre (l'ancien scan anime en
   continu a ete retire pour laisser le CEF au repos). */
.scan-line {
  position: absolute; top: 50%; left: 0; right: 0; height: 1px;
  background: linear-gradient(90deg, transparent 0%, rgba(170,190,255,0.35) 50%, transparent 100%);
  box-shadow: 0 0 8px rgba(170, 190, 255, 0.2);
  pointer-events: none;
}

/* Couche 10 : tirets verticaux decoratifs sur les cotes (8 elements statiques) */
.side-tick {
  position: absolute; width: 12px; height: 2px;
  background: rgba(180, 200, 255, 0.25);
  pointer-events: none;
}
.side-tick.r { background: rgba(255, 180, 180, 0.25); }
.side-tick.t1 { top: 30%; left: 60px; }
.side-tick.t2 { top: 40%; left: 50px; opacity: 0.6; }
.side-tick.t3 { top: 60%; left: 50px; opacity: 0.6; }
.side-tick.t4 { top: 70%; left: 60px; }
.side-tick.t5 { top: 30%; right: 60px; }
.side-tick.t6 { top: 40%; right: 50px; opacity: 0.6; }
.side-tick.t7 { top: 60%; right: 50px; opacity: 0.6; }
.side-tick.t8 { top: 70%; right: 60px; }

.title {
  position: absolute; top: 90px; left: 0; right: 0;
  text-align: center;
  font-size: 56px; font-weight: 700; letter-spacing: 0.25em;
  color: #ffffff;
  text-shadow: 0 0 30px rgba(180,180,255,0.4), 0 2px 0 #000;
}
.subtitle {
  position: absolute; top: 200px; left: 0; right: 0;
  text-align: center;
  font-family: 'Roboto', 'Arial', sans-serif;
  font-size: 16px; font-weight: 400; letter-spacing: 0.3em;
  color: #888d9a;
  text-transform: uppercase;
}

.cards {
  position: absolute; top: 270px; left: 0; right: 0; bottom: 60px;
  display: flex; justify-content: center; align-items: center; gap: 80px;
}

.card {
  position: relative;
  /* Cards plus verticales : reduites en largeur, plus hautes */
  width: 560px; height: 740px;
  background: linear-gradient(180deg, rgba(20,20,28,0.92) 0%, rgba(12,12,18,0.98) 100%);
  border: 1px solid rgba(255,255,255,0.06);
  /* DA v2 « Seireitei » : angles carres, coins coupes 45deg */
  -webkit-clip-path: polygon(0 0, calc(100% - 26px) 0, 100% 26px, 100% 100%, 26px 100%, 0 calc(100% - 26px));
  padding: 60px 40px 50px;
  display: flex; flex-direction: column; align-items: center;
  cursor: pointer;
  overflow: hidden;
  /* On limite la transition aux proprietes GPU-only (transform + opacity via
     border opacity n'existe pas, donc on garde border-color qui est cheap aussi).
     PAS de transition sur background/box-shadow/filter cote card -> repaint full
     a chaque frame de hover = lag massif sur Chromium GMod. */
  transition: transform 0.25s ease, border-color 0.25s ease;
  /* Promote en couche GPU pour eviter les reflow lors du hover */
  will-change: transform;
}

/* Top accent bar - subtle gradient line per faction (opacity only) */
.card::before {
  content: ''; position: absolute; top: 0; left: 10%; right: 10%; height: 2px;
  background: linear-gradient(90deg, transparent 0%, var(--accent) 50%, transparent 100%);
  opacity: 0.4;
  transition: opacity 0.25s ease;
}

/* Glow pseudo-element : fade in/out via opacity (cheap) au lieu d'animer
   box-shadow (couteux) directement sur la card. Le glow est statique en
   permanence dans le DOM, on change juste son alpha au hover. */
.card::after {
  content: ''; position: absolute; inset: -2px;
  box-shadow: 0 12px 30px rgba(0,0,0,0.5), 0 0 30px var(--accent-soft);
  opacity: 0;
  transition: opacity 0.25s ease;
  pointer-events: none;
}

/* Corner L-markers Valorant-style (transitions opacity uniquement) */
.corner {
  position: absolute; width: 34px; height: 34px;
  border: 2px solid var(--accent); opacity: 0.6;
  transition: opacity 0.25s ease;
}
.corner.tl { top: 18px; left: 18px; border-right: none; border-bottom: none; }
.corner.tr { top: 18px; right: 18px; border-left: none; border-bottom: none; }
.corner.bl { bottom: 18px; left: 18px; border-right: none; border-top: none; }
.corner.br { bottom: 18px; right: 18px; border-left: none; border-top: none; }

.card .icon {
  width: 380px; height: 380px;
  object-fit: contain;
  opacity: 0.92;
  /* halo couleur de faction STATIQUE derriere l'icone (calcule une fois) */
  filter: drop-shadow(0 0 26px var(--accent-soft));
  transition: transform 0.25s ease, filter 0.25s ease;
  will-change: transform;
}

.card .name {
  margin-top: 30px;
  font-size: 68px; font-weight: 700; letter-spacing: 0.15em;
  color: #fff;
  text-shadow: 0 0 20px var(--accent-soft);
}

.card .desc {
  margin-top: 24px;
  font-family: 'Georgia', 'Times New Roman', serif;
  font-size: 19px; font-weight: 400; font-style: italic; line-height: 1.6;
  color: #d4d8e0;
  text-align: center;
  max-width: 460px;
  opacity: 0;
  transition: opacity 0.25s ease;
}
/* Attribution (— Auteur) plus discrete : 2eme ligne via <br> */
.card .desc br + * { display: block; }

.card .cta {
  margin-top: auto;
  font-size: 20px; font-weight: 600; letter-spacing: 0.35em;
  color: var(--accent);
  opacity: 0;
  transition: opacity 0.25s ease;
  text-transform: uppercase;
}

/* HOVER state - uniquement transform + opacity (zero repaint full) */
.card:hover { transform: translateY(-8px); border-color: var(--accent); }
.card:hover::before { opacity: 1; }
.card:hover::after  { opacity: 1; }
.card:hover .corner { opacity: 1; }
.card:hover .icon   { transform: translateY(-4px); filter: drop-shadow(0 0 44px var(--accent-soft)); }
.card:hover .desc   { opacity: 1; }
.card:hover .cta    { opacity: 1; }

/* Theme variables per faction : Shinigami = bleu fonce, Hollow = rouge fonce */
.card.shinigami {
  --accent: #5aa0ff;
  --accent-soft: rgba(70, 140, 255, 0.30);
}
.card.hollow {
  --accent: #ff5a5a;
  --accent-soft: rgba(220, 40, 40, 0.30);
}

/* Carte VERROUILLÉE (faction indisponible sur cette map) : grisée, aucun
   effet hover, et le CTA (toujours visible) indique sur quelle map aller. */
.card.locked { cursor: default; opacity: 0.42; filter: grayscale(0.85); }
.card.locked:hover { transform: none; border-color: rgba(255,255,255,0.06); }
.card.locked:hover::before { opacity: 0.4; }
.card.locked:hover::after  { opacity: 0; }
.card.locked:hover .corner { opacity: 0.6; }
.card.locked:hover .icon   { transform: none; }
.card.locked:hover .desc   { opacity: 0; }
.card.locked .cta { opacity: 0.9; color: #9aa1ad; font-size: 17px; letter-spacing: 0.22em; }

/* CANVAS DE DESIGN 1920x1080 : centré dans le viewport et mis à l'échelle (transform:
   scale) pour tenir dans N'IMPORTE quel ratio — 16:9, CARRÉ 1080x1080, 5:4, 21:9... —
   sans déborder ni se coller en haut à gauche. Remplace l'ancien body.style.zoom qui,
   sur le vieux Chromium/CEF de GMod, s'ancre en HAUT À GAUCHE : en carré (scale 0.56)
   le contenu se tassait dans le coin, laissant tout le reste vide (bug 1080x1080).
   margin:auto + top/left/right/bottom:0 = centrage absolu classique ; transform-origin
   center => le scale garde le canvas centré. Les fonds (body) restent plein écran. */
#stage {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  margin: auto;
  width: 1920px; height: 1080px;
  transform: scale(1);
  transform-origin: center center;
}

/* Modale de transfert inter-serveur : s'affiche quand on choisit une faction
   hébergée sur l'autre serveur (création cross-serveur). Confirme le voyage. */
.xfer-overlay { position: absolute; top: 0; right: 0; bottom: 0; left: 0; display: none; align-items: center; justify-content: center; background: rgba(2,2,8,0.82); z-index: 60; }
.xfer-overlay.show { display: flex; }
.xfer { width: 640px; padding: 44px 48px; text-align: center; background: linear-gradient(180deg, rgba(20,20,32,0.98) 0%, rgba(10,10,18,0.98) 100%); border: 1px solid rgba(180,190,255,0.18); box-shadow: 0 0 70px rgba(0,0,0,0.65); }
.xfer h2 { font-size: 40px; letter-spacing: 0.12em; color: #eef0ff; margin-bottom: 20px; }
.xfer p { font-family: 'Roboto','Arial',sans-serif; font-size: 18px; line-height: 1.55; color: #b9bdd0; margin-bottom: 30px; }
.xfer p .srv { color: #ff7a7a; font-weight: 700; }
.xfer-btns { display: flex; gap: 16px; justify-content: center; }
.xfer-btn { font-family: 'Bebas Neue','Arial Black',sans-serif; font-size: 24px; letter-spacing: 0.1em; padding: 13px 34px; cursor: pointer; border: 1px solid transparent; transition: background 0.15s ease; }
.xfer-confirm { background: #cf444e; color: #fff; }
.xfer-confirm:hover { background: #e35560; }
.xfer-cancel { background: rgba(255,255,255,0.06); color: #cfd2dd; border-color: rgba(255,255,255,0.14); }
.xfer-cancel:hover { background: rgba(255,255,255,0.13); }

</style></head><body>
<!-- Couches de fond decoratives (toutes CSS statiques, zero JS, ultra-light) -->
<div class="bg-glow"></div>
<div class="bg-aura-left"></div>
<div class="bg-aura-right"></div>
<div class="bg-divider"></div>
<div class="scan-line"></div>
<div class="bg-vignette"></div>

<!-- Les décorations GÉOMÉTRIQUES (coins, tirets, losanges, texte EVO) sont DANS #stage
     ci-dessous : à tailles/positions fixes en px, sur body elles ne suivaient pas
     l'échelle du design -> trop petites en 1440p/4K, décalées en ultrawide/carré. Dans
     #stage elles scalent avec les cartes (responsive parfait). Seuls les DÉGRADÉS doux
     (auras/vignette/glow, en %) restent plein écran : ils remplissent n'importe quel ratio. -->

<!-- Canvas 1920x1080 centré + scale (voir #stage) : titre + cartes + décorations tiennent
     à toute résolution, y compris carré 1080x1080 (seuls les fonds dégradés restent sur body). -->
<div id="stage">
<!-- 6 accent dots/losanges statiques (bleu a gauche, rouge a droite) -->
<div class="accent-dot d1"></div>
<div class="accent-dot d2"></div>
<div class="accent-dot d3"></div>
<div class="accent-dot red d4"></div>
<div class="accent-dot red d5"></div>
<div class="accent-dot red d6"></div>
<!-- 8 tirets decoratifs sur les cotes (cyan gauche / rouge droite) -->
<div class="side-tick t1"></div><div class="side-tick t2"></div>
<div class="side-tick t3"></div><div class="side-tick t4"></div>
<div class="side-tick r t5"></div><div class="side-tick r t6"></div>
<div class="side-tick r t7"></div><div class="side-tick r t8"></div>
<!-- 4 coins L-markers Valorant-style -->
<div class="frame-corner tl"></div><div class="frame-corner tr"></div>
<div class="frame-corner bl"></div><div class="frame-corner br"></div>
<!-- Texte tout en bas -->
<div class="bg-tech">EVO</div>
<h1 class="title">CHOISIR SA FACTION</h1>
<div class="subtitle">Bleach RP — Faites votre choix</div>

<div class="cards">
  <div class="card shinigami]] .. shinClass .. [["]] .. shinClick .. [[>
    <div class="corner tl"></div><div class="corner tr"></div>
    <div class="corner bl"></div><div class="corner br"></div>
    <img class="icon" src="asset://garrysmod/materials/l1acam515ehakdj3/6i05nkvlbs70099.png">
    <div class="name">SHINIGAMI</div>
    <div class="desc">]] .. htmlShinigamiDesc .. [[</div>
    <div class="cta">]] .. shinCta .. [[</div>
  </div>

  <div class="card hollow]] .. hollClass .. [["]] .. hollClick .. [[>
    <div class="corner tl"></div><div class="corner tr"></div>
    <div class="corner bl"></div><div class="corner br"></div>
    <img class="icon" src="asset://garrysmod/materials/l1acam515ehakdj3/kflc5qgaqm0fcm4o9.png">
    <div class="name">HOLLOW</div>
    <div class="desc">]] .. htmlHollowDesc .. [[</div>
    <div class="cta">]] .. hollCta .. [[</div>
  </div>
</div>
</div><!-- fin #stage (la modale ci-dessous reste plein écran, hors canvas) -->

<div class="xfer-overlay" id="xfer">
  <div class="xfer">
    <h2>VOYAGE INTER-SERVEUR</h2>
    <p>Pour incarner un <span class="srv">]] .. (crossFaction or "") .. [[</span>, tu dois jouer sur <span class="srv">]] .. crossServerName .. [[</span>.<br>Tu vas y être transféré pour créer ton personnage.</p>
    <div class="xfer-btns">
      <div class="xfer-btn xfer-confirm" onclick="xferConfirm()">CONFIRMER</div>
      <div class="xfer-btn xfer-cancel" onclick="xferCancel()">ANNULER</div>
    </div>
  </div>
</div>

<script>
  var locked = false;
  var CROSS_FACTION = ]] .. (crossFaction and ("'" .. crossFaction .. "'") or "null") .. [[;
  function onPick(faction) {
    if (locked) return;
    // Faction hébergée sur l'autre serveur : on propose le transfert (modale) au
    // lieu de lancer la création locale (que le serveur refuserait de toute façon).
    if (CROSS_FACTION && faction === CROSS_FACTION) {
      try { gmod.playSound(); } catch(e) {}
      document.getElementById('xfer').classList.add('show');
      return;
    }
    locked = true;
    try { gmod.playSound(); } catch(e) {}
    document.body.classList.add('fading');
    setTimeout(function() {
      try { gmod.selectFaction(faction); } catch(e) {}
    }, 380);
  }
  function xferConfirm() {
    document.getElementById('xfer').classList.remove('show');
    try { gmod.confirmTransfer(); } catch(e) {}
  }
  function xferCancel() {
    document.getElementById('xfer').classList.remove('show');
    try { gmod.cancelTransfer(); } catch(e) {}
  }
</script>
</body></html>
]]
    self.factionHtml:SetHTML(html)

    -- Responsive : on met à l'échelle le CANVAS #stage (1920x1080) via transform:scale
    -- pour matcher la taille du panel. min(scaleX, scaleY) => tient dans 16:9, CARRÉ
    -- 1080x1080, 5:4, 21:9... sans overflow ET centré (l'ancien body.style.zoom s'ancrait
    -- en haut à gauche sur le CEF de GMod -> contenu tassé dans le coin en carré = le bug).
    -- On réapplique aussi OnFinishLoadingDocument car le 1er call peut fire avant que
    -- #stage soit parsé (race avec SetHTML async chromium) ; le if(s) rend l'appel no-op.
    local function _applyFactionZoom(htmlPanel)
        if not IsValid(htmlPanel) then return end
        local scale = math.min(ScrW() / 1920, ScrH() / 1080)
        htmlPanel:RunJavascript(string.format(
            "var s=document.getElementById('stage'); if(s){ s.style.transform='scale(%f)'; window.__zoom=%f; }",
            scale, scale))
    end
    _applyFactionZoom(self.factionHtml)
    self.factionHtml.OnFinishLoadingDocument = function(selff) _applyFactionZoom(selff) end

    self.factionHtml:AddFunction("gmod", "playSound", function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
    end)

    self.factionHtml:AddFunction("gmod", "selectFaction", function(faction)
        -- IMPORTANT : on est dans un callback JS-vers-Lua, ne pas faire de calculs
        -- lourds ici. Defer d'un frame pour relacher le bridge proprement.
        timer.Simple(0, function()
            if not IsValid(self) then return end
            if faction ~= "Shinigami" and faction ~= "Hollow" then return end

            -- CK Shinigami → Hollow : la page d'apparence n'est pas le début du parcours.
            if faction == "Hollow" and LZY_CK_ShouldStartHollow(self) then
                LZY_CK_BeginHollowFromUI()
                return
            end

            -- Restriction map <-> faction : sur les maps dédiées, on ne crée sur place
            -- que la faction du lieu. La faction de l'autre serveur est routée vers la
            -- modale de transfert par le JS (confirmTransfer), JAMAIS ici. Garde
            -- défensive si jamais appelé : on ne crée rien, on ré-affiche la page.
            local mapFaction = LZY_CHARACTER_CONFIG.MAP_FACTION and LZY_CHARACTER_CONFIG.MAP_FACTION[game.GetMap()]
            if mapFaction and faction ~= mapFaction then
                if IsValid(self.factionHtml) then
                    self.factionHtml:RunJavascript("locked=false;document.body.classList.remove('fading');")
                end
                return
            end

            -- evo_hollow_progression : créer un HOLLOW envoie en jeu en tant que "larva"
            -- (parcours larva -> vasto -> creator) AU LIEU des pages du creator. Exception :
            -- en mode finalisation, on crée le vrai Arrancar normalement (flag consommé).
            if faction == "Hollow" and EVO_HollowProg and EVO_HollowProg.ShouldInterceptHollow then
                if EVO_HollowProg.ShouldInterceptHollow() then
                    EVO_HollowProg.BeginFromCreator(self)
                    return
                else
                    EVO_HollowProg._Finalizing = false
                end
            end

            self:StartPage1Transition()
            net.Start("EVO:Server:SelectFaction")
            net.WriteString(faction)
            net.SendToServer()

            characterData.faction = faction
            characterData.body_model = LZY_CHARACTER_CONFIG.GetDefaultBodyModel(characterData.gender, characterData.faction)
            local pos, ang = LZY_CHARACTER_CONFIG.GetCreatorAnchor(faction)
            -- Detruit l'ancien preview (face + enfants) avant d'en recreer un :
            -- sinon l'ancien restait orphelin au centre de la map.
            if frame and IsValid(frame.previewModel) then DestroyPreviewModel(frame.previewModel) end
            frame.previewModel = createClientsidePlayerModel(pos, ang, characterData)
            SyncDefaultShapeKeysToFlexIds(frame.previewModel)
        end)
    end)

    -- Transfert inter-serveur confirmé dans la modale : on demande au serveur le
    -- `connect` (seule voie autorisée pour la redirection) vers le serveur de la
    -- faction choisie, et on arme EVO_CrossSkipConfirm pour que la confirmation
    -- native re-skinnée (evo_crossserver) s'auto-valide — notre modale a déjà
    -- servi de confirmation, on évite ainsi un second popup.
    self.factionHtml:AddFunction("gmod", "confirmTransfer", function()
        timer.Simple(0, function()
            if not IsValid(self) or not crossFaction then return end
            if crossFaction == "Hollow" and LZY_CK_ShouldStartHollow(self) then
                LZY_CK_BeginHollowFromUI()
                return
            end
            EVO_CrossSkipConfirm = CurTime() + 10
            net.Start("EVO:Server:CharacterCreator:RequestFactionServer")
            net.WriteString(crossFaction)
            net.SendToServer()
            NotifyCharacterCreator("Transfert vers " .. crossServerName .. "...", NOTIFY_HINT)
        end)
    end)
    -- Annulation : le JS a déjà masqué la modale ; rien à faire côté Lua.
    self.factionHtml:AddFunction("gmod", "cancelTransfer", function() end)

    -- Go back to character selection (VGUI sur-impression DHTML)
    self.goBackButton = vgui.Create("DButton", self.currentPagePanel)
    self.goBackButton:gSetSize(60, 60)
    self.goBackButton:gSetPos(40, 40)
    self.goBackButton:SetText("")
    self.goBackButton:SetZPos(100)
    self.goBackButton.Paint = function(selff, w, h)
        if selff:IsHovered() then
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.go_back_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.go_back_btn)
        end
    end
    self.goBackButton.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        if EVO_HollowProg and EVO_HollowProg._Finalizing then
            EVO_HollowProg._FinalizeResumeData = table.Copy(characterData)
            EVO_HollowProg._Finalizing = false
            EVO_HollowProg._FinalizePending = true
            self:Close()
            net.Start("EVO:HollowProg:ReturnToSelection") net.SendToServer()
            return
        end
        self:Close()
        timer.Simple(0, function()
            if LZY_CharacterSelection and LZY_CharacterSelection.Open then
                LZY_CharacterSelection.Open()
            end
        end)
    end
end

function PANEL:StartPage1Transition()
    if self.page1Transitioning then return end
    self.page1Transitioning = true
    -- Anciennement on slidait les boutons VGUI shinigami/hollow + fade bg. Maintenant
    -- la page est DHTML : le fade-out visuel (0.4s) est deja fait cote CSS dans le
    -- handler JS onPick AVANT que selectFaction soit appelee. Donc on enchaine quasi
    -- instantanement sur CreatePage2.
    if IsValid(self.factionHtml) then
        self.factionHtml:SetMouseInputEnabled(false)
    end
    timer.Simple(0.05, function()
        if not IsValid(self) then return end
        self.page1Transitioning = false
        self:CreatePage2()
    end)
end

function PANEL:CreatePage2()
    if LZY_CK_ShouldStartHollow(self) and LZY_CK_NormFaction(characterData.faction) == "Hollow" then
        if LZY_CK_BeginHollowFromUI() then return end
    end
    currentPage = 2
    -- Page 2 = nom / taille : on dezoom sur le corps entier.
    self.previewZoom = self.previewZoom or CHARACTER_VIEW_DISTANCE
    self.previewZoomTarget = CHARACTER_VIEW_ZOOM_BODY
    if self.currentPagePanel then
        self.currentPagePanel:Remove()
    end
    -- Code de parrainage : 1er Shinigami / 1er Arrancar uniquement (serveur re-valide).
    -- La finalisation Hollow EST ce 1er Arrancar : on n'exclut plus _fromFinalize / _Finalizing
    -- (un nouveau Hollow ne voyait jamais le champ — Page 2 n'existe qu'à la finalisation).
    local showReferral = not LZY_CHARACTER_BARBER_MODE
        and not LZY_CHARACTER_TATTOO_MODE
        and not LZY_CHARACTER_SCULPTOR_MODE
        and not LZY_CHARACTER_CK_MODE
        and not (LZY_ANIM_CREATE and LZY_ANIM_CREATE.slot)
        and not (self._fromAnimSlot or self._fromCK)
    if showReferral then
        -- Compte des persos qui CONSOMMENT le droit (pas âme errante, pas larve). On lit
        -- charactersData (liste serveur) : NCM_CHAR_SELECT.RealFilledCount lit la SCENE, or
        -- CreateFocused appelle StopScene avant le créateur -> il renvoyait toujours 0.
        local nReal
        if LZY_CharacterSelection and LZY_CharacterSelection.ParrainageEligibleCount then
            nReal = LZY_CharacterSelection.ParrainageEligibleCount()
        elseif LZY_CharacterSelection and LZY_CharacterSelection.RealCharCount then
            nReal = LZY_CharacterSelection.RealCharCount()
        elseif NCM_CHAR_SELECT and NCM_CHAR_SELECT.RealFilledCount then
            nReal = NCM_CHAR_SELECT.RealFilledCount()
        end
        showReferral = (tonumber(nReal) or 0) == 0
        -- Flag de COMPTE (players.parrainage_first_done, miroir NWBool) : le droit au code est
        -- consomme a la 1re creation et ne revient JAMAIS -> supprimer tous ses persos (nReal
        -- repasse a 0) ne reaffiche pas le champ. Le serveur re-valide (statut "not_first").
        local lp = LocalPlayer()
        if showReferral and IsValid(lp) and lp.GetEvoNWBool and lp:GetEvoNWBool("EVO_ParrainageFirstDone", false) then
            showReferral = false
        end
    end
    if not showReferral then ReferralCheck.Reset() end
    self.currentPagePanel = vgui.Create("DPanel", self)
    self.currentPagePanel:gSetSize(1920, 1080)
    self.currentPagePanel:gSetPos(0, 0)
    self.currentPagePanel.Paint = function(selff, w, h)
        RNDX.DrawMaterial(0, 0, 0, gRespX(658), gRespY(1080), Color(255, 255, 255, 255), materials.left_panel_bg)
        -- Barber mode : on remplace l'image "creation du personnage" par un
        -- texte "Modification du personnage" pour refleter le contexte (le
        -- joueur edite, ne cree pas).
        if LZY_CHARACTER_BARBER_MODE then
            draw.SimpleText("Modification du personnage", "Inter Bold:" .. gRespFont(34),
                gRespX(40), gRespY(144 + 44), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        elseif LZY_CHARACTER_CK_MODE then
            draw.SimpleText("Recréation CK", "Inter Bold:" .. gRespFont(34),
                gRespX(40), gRespY(144 + 44), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        else
            RNDX.DrawMaterial(0, gRespX(40), gRespY(144), gRespX(341), gRespY(88), Color(255, 255, 255, 255), materials.creation_du_personnage_txt)
        end
        RNDX.DrawMaterial(0, gRespX(1854), gRespY(1002), gRespX(40), gRespY(40), Color(255, 255, 255, 255), materials.mouse_scroll_icon)
        draw.SimpleText("ZOOM", "Inter Bold:20", gRespX(1874), gRespY(1054), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        RNDX.DrawMaterial(0, gRespX(1854), gRespY(932), gRespX(40), gRespY(40), Color(255, 255, 255, 255), materials.mouse_left_click_icon)
        draw.SimpleText("ROTATION", "Inter Bold:20", gRespX(1874), gRespY(984), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local hint = GetCharacterNameGateHint()
        -- Barber mode : pas de hint relatif au nom (il n'est pas editable).
        -- Avec le champ parrainage, le hint à y=572 chevaucherait l'input → on le saute
        -- (les erreurs nom passent déjà par NotifyCharacterCreator + bouton grisé).
        if hint ~= "" and not LZY_CHARACTER_BARBER_MODE and not showReferral then
            draw.SimpleText(hint, "Inter:20", gRespX(40), gRespY(572), Color(255, 180, 180, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
    end

    -- Go back button
    self.goBackButton = vgui.Create("DButton", self.currentPagePanel)
    self.goBackButton:gSetSize(60, 60)
    self.goBackButton:gSetPos(40, 40)
    self.goBackButton:SetText("")
    self.goBackButton.Paint = function(selff, w, h)
        if selff:IsHovered() then
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.go_back_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.go_back_btn)
        end
    end
    self.goBackButton.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        -- Finalisation Arrancar : Page 1 (faction) a ete SAUTEE -> "retour" doit ramener au
        -- HUB (meme handling que le retour de Page 1), pas au choix de faction.
        if self._fromFinalize then
            if EVO_HollowProg then
                EVO_HollowProg._FinalizeResumeData = table.Copy(characterData)
                EVO_HollowProg._Finalizing = false
                EVO_HollowProg._FinalizePending = true
            end
            self:Close()
            net.Start("EVO:HollowProg:ReturnToSelection") net.SendToServer()
            return
        end
        -- Barber mode : on a saute Page 1, donc "go back" doit fermer le panel
        -- (annule l'edition) au lieu de retourner sur la faction selection.
        if LZY_CHARACTER_BARBER_MODE then
            self:Close()
            return
        end
        -- CK avec choix de faction : retour à ce choix. Sinon (slot animation) retour HUB.
        if self._fromCK and self._ckCanSwitchFaction then
            self:CreateCKFactionStep()
            return
        end
        if self._fromCK or self._fromAnimSlot then
            self:Close()
            timer.Simple(0, function()
                if LZY_CharacterSelection and LZY_CharacterSelection.Open then
                    LZY_CharacterSelection.Open()
                end
            end)
            return
        end
        self:CreatePage1()
    end

    -- Continuer button
    self.continuerButton = vgui.Create("DButton", self.currentPagePanel)
    self.continuerButton:gSetSize(578, 81)
    self.continuerButton:gSetPos(40, 958)
    self.continuerButton:SetText("")
    self.continuerButton.Paint = function(selff, w, h)
        -- Barber mode : le gate du nom n'existe pas, le bouton est toujours
        -- actif.
        local allow = LZY_CHARACTER_BARBER_MODE or characterNameGateAllowsProceed()
        local alpha = allow and 255 or 100
        local col = Color(255, 255, 255, alpha)
        if selff:IsHovered() and allow then
            RNDX.DrawMaterial(0, 0, 0, w, h, col, materials.continuer_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, col, materials.continuer_btn)
        end
    end
    self.continuerButton.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        -- Barber mode : pas de check nom (firstname/lastname conservs depuis
        -- la data character du joueur, inputs caches).
        if LZY_CHARACTER_BARBER_MODE then
            self:CreatePage3()
            return
        end
        SyncPage2NameInputsFromWidgets(self)
        -- Le champ n'existe pas hors 1er perso : on ne laisse pas trainer une valeur.
        if not showReferral then characterData.referral_code = "" end
        local ref = ReferralCheck.Normalize(characterData.referral_code)
        characterData.referral_code = ref
        if showReferral and ref ~= "" then
            -- Verification en vol : on attend la reponse (le joueur reclique).
            if ReferralCheck.pending and ReferralCheck.code == ref then return end
            local st = ReferralCheck.StateFor(ref)
            if st == nil then
                -- Pas encore verifie (Entree directe sans perte de focus) : on lance et on attend.
                ReferralCheck.Request(ref, true)
                return
            end
            if ReferralCheck.BLOCKING[st] then
                ReferralCheck.NotifyState(st)
                return
            end
        end
        if not characterNamesAreFilled() then
            NotifyCharacterCreator("Renseignez au moins le prénom.")
            return
        end
        if characterNameCheckPending then return end
        if characterNameServerAvailable == nil then
            RequestCharacterNameCheckFromServer()
            return
        end
        if characterNameServerAvailable == false then
            NotifyCharacterCreator("Ce prénom et ce nom sont déjà utilisés.")
            return
        end
        self:CreatePage3()
    end

    -- Barber mode : pas de changement de genre autorise. On ne cree pas les
    -- boutons male/female pour eviter qu'ils s'affichent + qu'on puisse cliquer.
    if not LZY_CHARACTER_BARBER_MODE then
        -- Male button
        self.maleButton = vgui.Create("DButton", self.currentPagePanel)
        self.maleButton:gSetSize(80, 80)
        self.maleButton:gSetPos(40, 282)
        self.maleButton:SetText("")
        self.maleButton.Paint = function(selff, w, h)
            if selff:IsHovered() or characterData.gender == "m" then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.male_btn_active)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.male_btn)
            end
        end
        self.maleButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            UpdateCharacterData("gender", "m")
        end

        -- Female button
        self.femaleButton = vgui.Create("DButton", self.currentPagePanel)
        self.femaleButton:gSetSize(80, 80)
        self.femaleButton:gSetPos(135, 282)
        self.femaleButton:SetText("")
        self.femaleButton.Paint = function(selff, w, h)
            if selff:IsHovered() or characterData.gender == "f" then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.female_btn_active)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.female_btn)
            end
        end
        self.femaleButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            UpdateCharacterData("gender", "f")
        end

        -- Dé aléatoire : randomise toute l'apparence d'un coup. Petit (40x40),
        -- colle a droite (bord droit aligne sur les champs : 40+578=618 => x=578)
        -- au-dessus du prenom. Uniquement ici, en creation normale. Dessine une
        -- face de de (5 points) teintee selon la faction (bleu / rouge).
        self.randomDiceButton = vgui.Create("DButton", self.currentPagePanel)
        -- CARRÉ responsive UNIFORME (min des 2 axes) : gSetSize(40,40) étirait le
        -- dé en rectangle sur les ratios non 16:9 (gRespX≠gRespY) et les points
        -- débordaient du bouton. Bord droit toujours aligné sur les champs (x=618).
        local diceSize = math.Round(40 * math.min(ScrW() / 1920, ScrH() / 1080))
        self.randomDiceButton:SetSize(diceSize, diceSize)
        self.randomDiceButton:SetPos(gRespX(618) - diceSize, gRespY(302))
        self.randomDiceButton:SetText("")
        self.randomDiceButton.Paint = function(selff, w, h)
            local hollow = tostring(characterData.faction) == "Hollow"
            local hov    = selff:IsHovered()
            local bg     = hollow and Color(40, 14, 16) or Color(12, 20, 42)
            local accent = hollow and Color(255, 90, 90) or Color(90, 150, 255)
            if hov then accent = hollow and Color(255, 145, 145) or Color(150, 190, 255) end
            local dot    = hollow and Color(255, 225, 225) or Color(228, 238, 255)
            -- cadre accent + fond sombre arrondis
            draw.RoundedBox(math.Round(w * 0.18), 0, 0, w, h, accent)
            draw.RoundedBox(math.Round(w * 0.15), w * 0.04, h * 0.04, w * 0.92, h * 0.92, bg)
            -- 5 points (face de de)
            -- points : x calculé sur w, y sur h (robuste même si le bouton n'est pas carré)
            local d    = math.min(w, h) * 0.15
            local loX, hiX   = w * 0.22, w * 0.63
            local loY, hiY   = h * 0.22, h * 0.63
            local ctrX, ctrY = (w - d) / 2, (h - d) / 2
            local pts = { { loX, loY }, { hiX, loY }, { ctrX, ctrY }, { loX, hiY }, { hiX, hiY } }
            local r = math.Round(d / 2)
            for _, p in ipairs(pts) do
                draw.RoundedBox(r, p[1], p[2], d, d, dot)
            end
        end
        self.randomDiceButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            LZY_RandomizeCharacterAppearance()
            -- Rafraichit le slider Taille ; le selecteur de peau lit en live (Paint).
            if IsValid(self.scaleSlider) and self.scaleSlider.SetValue then
                self.scaleSlider:SetValue(characterData.scale)
            end
        end
    end

    local function afterNameFieldCommit()
        RefreshCharacterNameGate()
        RequestCharacterNameCheckFromServer()
    end

    -- Barber mode (addon lzy_coiffeur) : on n'autorise pas la modification
    -- du nom/prenom => on ne cree meme pas les inputs. Ils restent nil sur
    -- self, le terminerButton verra LZY_CHARACTER_BARBER_MODE et bypassera le
    -- characterNameGate.
    if not LZY_CHARACTER_BARBER_MODE then
        -- First name input
        self.firstNameInput = CreateStyledInput(self.currentPagePanel, 40, 390, 578, 80, "Prénom", characterData, "firstname", UpdateCharacterData, afterNameFieldCommit)

        -- Last name input
        local lastNameY = showReferral and 475 or 485
        self.lastNameInput = CreateStyledInput(self.currentPagePanel, 40, lastNameY, 578, 80, "Nom", characterData, "lastname", UpdateCharacterData, afterNameFieldCommit)

        if showReferral then
            -- Validation a la PERTE DE FOCUS (onAfterCommit = OnEnter / OnLoseFocus / croix) :
            -- on normalise l'affichage puis on demande au serveur si le code existe, au lieu
            -- de laisser le joueur decouvrir l'erreur au moment de creer le perso.
            local function afterReferralCommit(inputPanel)
                local code = ReferralCheck.Normalize(inputPanel:GetText())
                if inputPanel:GetText() ~= code then
                    inputPanel:SetText(code)
                    inputPanel:SetCaretPos(#code)
                end
                UpdateCharacterData("referral_code", code)
                ReferralCheck.Request(code, true)
            end
            self.referralInput = CreateStyledInput(self.currentPagePanel, 40, 555, 578, 64, "Code de parrainage (optionnel)", characterData, "referral_code", UpdateCharacterData, afterReferralCommit)
            -- Liseré de statut par-dessus le fond standard : rouge = refuse, vert = valide.
            local basePaint = self.referralInput.Paint
            self.referralInput.Paint = function(selff, pw, ph)
                basePaint(selff, pw, ph)
                local st = ReferralCheck.StateFor(ReferralCheck.Normalize(selff:GetText()))
                if not st or st == "empty" then return end
                local col = (st == "ok") and Color(120, 220, 140, 255)
                    or (ReferralCheck.BLOCKING[st] and Color(235, 90, 90, 255))
                    or Color(235, 200, 100, 255)
                surface.SetDrawColor(col)
                surface.DrawOutlinedRect(0, 0, pw, ph, 2)
            end
            ReferralCheck.Request(characterData.referral_code, false)
        else
            characterData.referral_code = ""
        end
    end

    -- Scale slider
    local scaleY = showReferral and 630 or 590
    self.scaleSlider = CreateSlider(self.currentPagePanel, 40, scaleY, 578, 80, 0.9, 1.1, 0.01, characterData, "scale", UpdateCharacterData, "Taille", materials.character_icon, 19/1.5, 34/1.5, materials.character_icon, 19, 34)

    -- Âge de départ : slider 15-25 ans, UNIQUEMENT en création. En mode barber/édition l'âge
    -- est figé (c'est une donnée de naissance, pas une apparence) -> on ne crée pas le slider et
    -- le sélecteur de peau reste à sa position d'origine (y=750). En création, on le décale plus
    -- bas (y=850) pour laisser la place au slider Âge + son label numérique.
    local skinY = 750
    if not LZY_CHARACTER_BARBER_MODE then
        local ageY = showReferral and 745 or 720
        self.ageSlider = CreateSlider(self.currentPagePanel, 40, ageY, 578, 80, 15, 25, 1, characterData, "age_start", UpdateCharacterData, "Âge")
        -- Lecture numérique LIVE de l'âge choisi (le slider seul n'affiche pas sa valeur),
        -- alignée à droite sur la ligne du label "Âge".
        self.ageValueLabel = vgui.Create("DLabel", self.currentPagePanel)
        self.ageValueLabel:gSetPos(40, ageY)
        self.ageValueLabel:gSetSize(578, 40)
        self.ageValueLabel:SetFont("Inter:30")
        self.ageValueLabel:SetTextColor(Color(255, 255, 255, 255))
        self.ageValueLabel:SetContentAlignment(6) -- centré-droite
        self.ageValueLabel.Think = function(selff)
            selff:SetText(math.Round(tonumber(characterData.age_start) or 18) .. " ans")
        end
        skinY = showReferral and 860 or 850
    end

    -- Skin color selector
    self.skinColorSelector = CreateColorSelector(self.currentPagePanel, 40, skinY, 578, characterData, "skin_color", UpdateCharacterData, LZY_CHARACTER_CONFIG.GetSkinColorsForFaction(characterData.faction), "Couleur de peau")
end

-- Appearance pages (CreatePage3+) live in a sibling file so each CSLua
-- payload stays under GMod's 64KB send limit.
do
    local env = {
        ApplyHairGradientToPreview = ApplyHairGradientToPreview,
        BuildFaceBodygroupsStringFromEntity = BuildFaceBodygroupsStringFromEntity,
        CHARACTER_VIEW_DISTANCE = CHARACTER_VIEW_DISTANCE,
        CHARACTER_VIEW_ZOOM_FACE = CHARACTER_VIEW_ZOOM_FACE,
        CreateColorSelector = CreateColorSelector,
        CreateSlider = CreateSlider,
        LZY_ApplyHairCheveuxPageLayout = LZY_ApplyHairCheveuxPageLayout,
        LZY_GetScrollPanelScrollY = LZY_GetScrollPanelScrollY,
        LZY_ModelSelectionGridBottomY = LZY_ModelSelectionGridBottomY,
        LZY_RandomizeCharacterAppearance = LZY_RandomizeCharacterAppearance,
        LZY_RestoreScrollPanelScrollDeferred = LZY_RestoreScrollPanelScrollDeferred,
        LZY_SetScrollPanelScrollYClamped = LZY_SetScrollPanelScrollYClamped,
        NotifyCharacterCreator = NotifyCharacterCreator,
        PANEL = PANEL,
        PUPIL_UI_CB_H = PUPIL_UI_CB_H,
        PUPIL_UI_CB_LABEL_INDENT = PUPIL_UI_CB_LABEL_INDENT,
        PUPIL_UI_CB_W = PUPIL_UI_CB_W,
        PUPIL_UI_CB_Y = PUPIL_UI_CB_Y,
        PUPIL_UI_COLOR_ROW_Y_OFFSET = PUPIL_UI_COLOR_ROW_Y_OFFSET,
        PUPIL_UI_GRID_GAP_BELOW_COLOR = PUPIL_UI_GRID_GAP_BELOW_COLOR,
        PUPIL_UI_SECTION_Y0 = PUPIL_UI_SECTION_Y0,
        PUPIL_UI_SWATCH_X = PUPIL_UI_SWATCH_X,
        PUPIL_UI_TAB_H = PUPIL_UI_TAB_H,
        RefreshEncodedBodygroups = RefreshEncodedBodygroups,
        RequestCharacterNameCheckFromServer = RequestCharacterNameCheckFromServer,
        UpdateCharacterData = UpdateCharacterData,
        characterData = characterData,
        characterNameGateAllowsProceed = characterNameGateAllowsProceed,
        characterNamesAreFilled = characterNamesAreFilled,
        createClientsidePlayerModel = createClientsidePlayerModel,
        createColorPicker = createColorPicker,
        createModelSelectionGrid = createModelSelectionGrid,
        createPupilColorSwatchRow = createPupilColorSwatchRow,
        createPupilSideTabs = createPupilSideTabs,
        createTattooCrosshairPicker = createTattooCrosshairPicker,
        createTattooPositionPicker = createTattooPositionPicker,
        createTattooScalePicker = createTattooScalePicker,
        materials = materials,
        styleScrollPanelVBar = styleScrollPanelVBar,
    }
    setmetatable(env, {
        __index = function(_, k)
            if k == "characterNameCheckPending" then return characterNameCheckPending end
            if k == "characterNameServerAvailable" then return characterNameServerAvailable end
            if k == "currentPage" then return currentPage end
            if k == "frame" then return frame end
            if k == "pupilTabSide" then return pupilTabSide end
            return _G[k]
        end,
        __newindex = function(_, k, v)
            if k == "characterNameCheckPending" then characterNameCheckPending = v return end
            if k == "characterNameServerAvailable" then characterNameServerAvailable = v return end
            if k == "currentPage" then currentPage = v return end
            if k == "frame" then frame = v return end
            if k == "pupilTabSide" then pupilTabSide = v return end
            rawset(env, k, v)
        end,
    })
    local chunk = CompileFile("lzy_character/client/cl_character_creation_appearance.lua")
    if not isfunction(chunk) then
        ErrorNoHalt("[lzy_character] Failed to CompileFile cl_character_creation_appearance.lua\n")
    else
        setfenv(chunk, env)
        chunk()
    end
end

-- Édition PNJ métier : le joueur est DÉJÀ en monde. OpenCharacterCreator ne doit
-- PAS poser le hub-flag local (sinon MUGEN::CalcView cède jusqu'au filet stale
-- 10s -> vue moteur 1re personne = "on ne voit plus son perso" au Cancel/Close).
local function RestoreWorldCamAfterMetierEditor(panel)
    if not panel or not panel._lzyBarberSession then return end
    if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(false) end
end

function PANEL:OnClose()
    CleanupClientsideModels()

    if IsValid(self.previewModel) then
        SafeRemoveEntity(self.previewModel)
        self.previewModel = nil
    end

    -- Stoppe la boucle de musique d'ambiance + la track en cours.
    StopAmbient(self)
    self._ambientLastIdx = nil

    frame = nil
    RestoreWorldCamAfterMetierEditor(self)
    -- IMPORTANT : self:Remove() declenche OnRemove() qui rappelle
    -- CleanupClientsideModels(). Le flag barber doit ENCORE etre actif a cet instant,
    -- sinon la "safety-loop" (qui supprime tout model "models/evo/face/") efface aussi
    -- l'entity face du portrait HUD -> "on voit plus la tete" apres le coiffeur.
    -- On reset donc les globals barber/tattoo/sculptor APRES le Remove.
    self:Remove()

    -- Reset barber mode globals (set par lzy_coiffeur quand on ouvre via PNJ).
    -- Si on n'est pas en barber mode, ca ne fait rien.
    LZY_CHARACTER_BARBER_MODE = nil
    LZY_CHARACTER_TATTOO_MODE = nil
    LZY_CHARACTER_SCULPTOR_MODE = nil
    LZY_CHARACTER_BARBER_DATA = nil
    LZY_CHARACTER_CK_MODE = nil
    LZY_CHARACTER_CK_DATA = nil
    LZY_CK_RECREATE = nil

    timer.Simple(0.1, function() can_open = true end)
end

-- Filet de securite : OnClose ne fire PAS sur une suppression directe du panel
-- (reload gamemode, :Remove() direct, deconnexion, kill du parent). OnRemove
-- fire TOUJOURS. On garantit donc ici le nettoyage des modeles de preview
-- (face racine + sous-ents bonemerges), sinon ils restent orphelins et se
-- rendent au centre de la map a (0,0,0).
function PANEL:OnRemove()
    StopAmbient(self) -- filet : coupe la musique si OnClose n'a pas fire (reload / :Remove() direct)
    -- ForceClose (ouverture HUB) : previews déjà purgés ; NE PAS CleanupClientsideModels
    -- (safety-loop faces) — sinon OnRemove différé tue les modèles de ncm_char_select.
    if self._lzyForceClosed then
        self.previewModel = nil
    else
        DestroyPreviewModel(self.previewModel)
        self.previewModel = nil
        CleanupClientsideModels()
    end
    -- Édition PNJ métier terminée -> on demande au serveur de nous SORTIR de "l'instance"
    -- (InCharacterMenu + god). OnRemove fire TOUJOURS (close, :Remove() direct, reload, déco).
    -- No-op serveur si on n'était pas en édition métier (ExitCharacterEditor gardé par _InCharEditor).
    if self._lzyBarberSession then
        RestoreWorldCamAfterMetierEditor(self)
        net.Start("LZY_Character:EditorClose")
        net.SendToServer()
    end
end

-- function PANEL:OnKeyCodePressed(keycode)
-- 	if keycode == KEY_F4 and can_open == false then
-- 		self:Close()
-- 	end
-- end

function PANEL:OnMouseWheeled(delta)
	-- Don't zoom when cursor is on the left half of the screen (where scroll panels are)
	local mx, my = gui.MousePos()
	if mx < ScrW() * 0.55 then return end
	if not IsValid(self.previewModel) then return end
	if self.previewZoom == nil then
		self.previewZoom = CHARACTER_VIEW_DISTANCE
	end
	-- L'utilisateur prend la main : on annule l'auto-zoom en cours.
	self.previewZoomTarget = nil
	-- Scale zoom step by current distance: more steps when zoomed in (finer control)
	local dist = self.previewZoom
	local stepScale = math.Clamp(dist / CHARACTER_VIEW_DISTANCE, 0.15, 1)
	local step = CHARACTER_VIEW_ZOOM_SPEED * stepScale
	self.previewZoom = math.Clamp(self.previewZoom - delta * step, CHARACTER_VIEW_ZOOM_MIN, CHARACTER_VIEW_ZOOM_MAX)
end

vgui.Register("LZY_CharacterCreator", PANEL, "DFrame")

-- Exposé pour ncm_char_select : permet de gater la scène HUB (hooks de rendu +
-- ré-ouverture auto) tant que le creator est ouvert -> les deux ne coexistent jamais.
function LZY_IsCharacterCreatorOpen()
	return IsValid(frame)
end

function OpenCharacterCreator()
	-- Le HUB de sélection (ncm_char_select) et le creator ne doivent JAMAIS coexister :
	-- on ferme la scène HUB AVANT d'ouvrir le creator. Couvre les chemins 0-perso /
	-- suppression du dernier perso qui appellent OpenCharacterCreator sans StopScene.
	if NCM_CHAR_SELECT and isfunction(NCM_CHAR_SELECT.StopScene) then
		NCM_CHAR_SELECT.StopScene()
	end
	-- ForceClose efface le mode CK. On le repose après, sinon un creator encore
	-- valide (Terminer caché) ouvrait la page faction normale et Hollow tombait
	-- sur la page d'apparence.
	local keepCK = LZY_CHARACTER_CK_MODE
	local keepData = LZY_CHARACTER_CK_DATA
	local keepRecreate = LZY_CK_RECREATE
	-- TOUJOURS (re)créer. L'ancien toggle `if IsValid(frame) then Close()` mangeait
	-- LZY_ANIM_CREATE : après un Terminer (frame caché mais encore valide), recliquer un
	-- slot Animation fermait le panel SANS Init -> `_animSlot` jamais posé -> sur Hueco,
	-- création Shinigami = wrong_map. ForceClose purge proprement avant le nouvel Init.
	if IsValid(frame) then
		LZY_CharacterCreator_ForceClose()
	end
	if keepCK then
		LZY_CHARACTER_CK_MODE = true
		LZY_CHARACTER_CK_DATA = keepData
		LZY_CK_RECREATE = keepRecreate
	end
	-- Hub flag LOCAL : StopScene coupe IsSceneActive, mais WantPM/Flush doivent rester
	-- bloqués jusqu'au vrai spawn-load (LoadingBegin). APRÈS ForceClose : OnRemove d'une
	-- session métier remet le flag à false, on le re-pose ici pour une vraie création.
	-- Sauf édition PNJ métier (coiffeur/tatoueur/chirurgien) : déjà en monde, le flag
	-- ferait céder la cam 3e personne après Close (vue 1re personne pendant ~10s).
	if not LZY_CHARACTER_BARBER_MODE then
		if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(true) end
	end
	RunConsoleCommand("stopsound") -- coupe tout son en cours a l'ouverture du creator (hub)
	frame = vgui.Create("LZY_CharacterCreator")
	can_open = false
	-- Écran OBLIGATOIRE : on purge tout panneau esc-closable résiduel pour qu'Échap ne
	-- puisse rien fermer pendant le créateur (sinon Échap enlèverait l'UI).
	openedFrame = nil
end

-- Ferme de force le character creator + nettoie SES modeles de preview (la face
-- racine + ses sous-modeles bonemerges body/hair/barbe/moustache) en se basant
-- UNIQUEMENT sur la liste trackee `createdClientsideModels` -> on EVITE la
-- safety-loop large de CleanupClientsideModels qui supprimerait aussi le
-- DModelPanel du portrait HUD (meme prefixe "models/evo/face/").
-- Appele par la scene de selection (ncm_char_select) a son ouverture : tue toute
-- preview de face restee orpheline ("face qui vole a cote des poses").
function LZY_CharacterCreator_ForceClose()
	local old = frame
	frame = nil
	can_open = true
	LZY_CHARACTER_CK_MODE = nil
	LZY_CHARACTER_CK_DATA = nil
	LZY_CK_RECREATE = nil
	-- Purge synchrone des previews creator AVANT que StartScene ne pose les faces HUB.
	for _, ent in ipairs(createdClientsideModels) do
		if IsValid(ent) then
			for _, key in ipairs({ "bodyEnt", "hairEnt", "beardEnt", "mustacheEnt" }) do
				if IsValid(ent[key]) then SafeRemoveEntity(ent[key]) end
			end
			SafeRemoveEntity(ent)
		end
	end
	createdClientsideModels = {}
	-- Remove différé possible : flag pour que OnRemove ne re-Cleanup pas (sinon
	-- safety-loop 1 frame plus tard = pas de modèle dans le menu de sélection).
	if IsValid(old) then
		old._lzyForceClosed = true
		old:Remove()
	end
end

-- hook.Add("PlayerButtonDown", "LZY_Test_KeyBind", function(ply, button)
-- 	if button == KEY_F4 and can_open == true then
-- 		OpenCharacterCreator()
-- 	end
-- end)

net.Receive("EVO:CK:HollowArmed", function()
	if LZY_CharacterCreator_ForceClose then LZY_CharacterCreator_ForceClose() end
end)

net.Receive("EVO:Client:CharacterCreator:CheckCharacterNameResult", function()
	characterNameCheckPending = false
	local rf = net.ReadString()
	local rl = net.ReadString()
	local available = net.ReadBool()
	local cf, cl = getTrimmedCharacterNames()
	if cf == rf and cl == rl then
		characterNameServerAvailable = available
	else
		characterNameServerAvailable = nil
	end
	RefreshCharacterNameGate()
end)

net.Receive("EVO:Client:CharacterCreator:FinishCharacterCreationFailed", function()
	local reason = net.ReadString()
	local msg = "Impossible de créer le personnage."
	if reason == "name_taken" then
		msg = "Ce prénom et ce nom sont déjà utilisés."
	elseif reason == "empty_names" then
		msg = "Prénom requis."
	elseif reason == "no_slot" then
		msg = "Aucun emplacement de personnage libre."
	elseif reason == "name_forbidden" then
		msg = "Ce prénom ou nom contient un terme interdit. Choisis-en un autre."
	elseif reason == "faction_switch" then
		msg = "Le changement de faction a échoué. Réessaie."
	elseif reason == "wrong_map" then
		msg = "Tu n'es pas sur la bonne map pour cette faction. Pour un perso Animation, utilise les emplacements Animation (4/5)."
	elseif reason == "invalid_referral" then
		msg = "Code de parrainage invalide. Corrige-le ou laisse le champ vide."
	end
	NotifyCharacterCreator(msg)
	timer.Simple(0.2, function()
		-- Le creator est normalement encore la, juste CACHE (cf. l envoi) : on le
		-- remontre tel quel, avec le personnage intact. OpenCharacterCreator() n est
		-- qu un filet pour les cas ou il aurait vraiment disparu (deconnexion de la
		-- scene, ForceClose venu d ailleurs) — et lui, il repart de zero.
		-- Si on doit recréer et que c'était un slot Animation, on ré-arme LZY_ANIM_CREATE
		-- pour que Init repose `_animSlot` (sinon Hueco = wrong_map au prochain Terminer).
		if IsValid(frame) then
			frame:SetVisible(true)
			frame:SetMouseInputEnabled(true)
			frame:SetKeyboardInputEnabled(true)
			frame:MakePopup()
		else
			local as = tonumber(characterData._animSlot)
			if as and EVO_ANIM and EVO_ANIM.SLOT_FACTION and EVO_ANIM.SLOT_FACTION[as] and characterData.faction then
				LZY_ANIM_CREATE = { faction = characterData.faction, slot = as }
			end
			OpenCharacterCreator()
		end
		timer.Simple(0, function()
			if reason == "name_taken" then
				characterNameServerAvailable = false
			else
				characterNameServerAvailable = nil
			end
			RefreshCharacterNameGate()
		end)
	end)
end)

hook.Add("InitPostEntity", "EVO:Client:InitPostEntity", function()
	net.Start("EVO:Server:InitPostEntity")
	net.SendToServer()
end)
