-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_character_selection.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- cl_character_selection.lua
-- Rôle réel après nettoyage (2026-06-03) :
--   (1) helpers de modèle de perso PARTAGÉS (LZY_Character_PlayerModel_* + LZY_CHARACTER_CONFIG.*)
--       réutilisés par inventory / lzy_animation_menu / lzy_hud ;
--   (2) le routage de l'écran de choix vers l'addon ncm_char_select (la vraie scène 3D).
-- Retirés : perso de démo "Vee Vendetta", grille 2D (createSlotBtn/createPlayerModelPanel),
-- scène 3D locale MORTE (sceneOpen jamais mis à true) et le PANEL "LZY_CharacterSelection"
-- qui n'était jamais instancié. Voir reference_charselect_3d_scene (mémoire) pour le détail.

local frame = nil
local can_open = true

-- Normalize gender to "male" or "female" (accepts "m", "f", "male", "female")
function LZY_CHARACTER_CONFIG.NormalizeGender(gender)
    if not gender then return "male" end
    local g = string.lower(tostring(gender))
    if g == "f" or g == "female" then return "female" end
    return "male"
end

function LZY_CHARACTER_CONFIG.GetDefaultFaceModel(gender)
    local norm = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
    return norm == "female" and LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_FEMALE or LZY_CHARACTER_CONFIG.DEFAULT_FACE_MODEL_MALE
end

function LZY_CHARACTER_CONFIG.GetDefaultBodyModel(gender, faction)
    local normGender = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
    local fac = tostring(faction or "Shinigami")

    if normGender == "female" then
        local tbl = LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_FEMALE
        if istable(tbl) and tbl[fac] then
            return tbl[fac]
        end
        -- Fallback to a single string config if table entry is missing
        if isstring(tbl) then return tbl end
    else
        local tbl = LZY_CHARACTER_CONFIG.DEFAULT_BODY_MODEL_MALE
        if istable(tbl) and tbl[fac] then
            return tbl[fac]
        end
        if isstring(tbl) then return tbl end
    end

    -- Ultimate fallback: keep old shinigami academy model so we never break
    if normGender == "female" then
        return "models/evo/characters/shinigami/female/evo_f4kq399g1dcdnc/evo_3p3uuy49h3ho.mdl"
    end
    return "models/evo/characters/shinigami/male/evo_yyjejrymar3ma/evo_7ef88q5bfk3wr1vg1.mdl"
end

function LZY_CHARACTER_CONFIG.GetAvailableHairStyles(gender)
    local norm = LZY_CHARACTER_CONFIG.NormalizeGender(gender)
    return norm == "female" and LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_FEMALE or LZY_CHARACTER_CONFIG.AVAILABLE_HAIR_STYLES_MALE
end

function LZY_CHARACTER_CONFIG.GetAvailableBeardStyles(gender)
    if LZY_CHARACTER_CONFIG.NormalizeGender(gender) == "female" then return {} end
    return LZY_CHARACTER_CONFIG.AVAILABLE_BEARD_STYLES or {}
end

function LZY_CHARACTER_CONFIG.GetAvailableMustacheStyles(gender)
    if LZY_CHARACTER_CONFIG.NormalizeGender(gender) == "female" then return {} end
    return LZY_CHARACTER_CONFIG.AVAILABLE_MUSTACHE_STYLES or {}
end

-- Centralized player model panel helpers (used by inventory, animation menu)
function LZY_Character_PlayerModel_CreateModelPart(ent, model, color, skinColor)
    if not isstring(model) or model == "" then return nil end
    local mdl = ClientsideModel(model)
    if not IsValid(mdl) then return nil end
    mdl.skipDim = true
    color = color or Color(255, 255, 255, 255)
    if not color.a then color.a = 255 end
    mdl:SetParent(ent)
    mdl:SetLocalPos(Vector(0, 0, 0))
    mdl:SetLocalAngles(Angle(0, 0, 0))
    mdl:SetNoDraw(true)
    mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
    mdl:SetRenderMode(RENDERMODE_TRANSCOLOR)
    if skinColor then mdl:SetSkin(skinColor) end
    mdl:SetColor(color)
    return mdl
end

function LZY_Character_PlayerModel_NormalizeEyesColor(eyes_color)
    if not eyes_color then return nil end
    if type(eyes_color) == "table" and (eyes_color.r or eyes_color.g or eyes_color.b) then
        return Color(eyes_color.r or 0, eyes_color.g or 0, eyes_color.b or 0)
    end
    if type(eyes_color) == "table" and eyes_color[1] then
        return Color(eyes_color[1], eyes_color[2] or 0, eyes_color[3] or 0)
    end
    return eyes_color
end

function LZY_Character_PlayerModel_NormalizeHairDetailsColor(h)
    return (LZY_NormalizeHairDetailsColor and LZY_NormalizeHairDetailsColor(h)) or Color(255, 255, 255)
end

-- 7 = slot MASQUE dédié (Arrancar). DOIT rester aligné sur ACCESSORY_DRAW_ORDER (cl_models.lua,
-- rendu MONDE) : sans le 7 ici, le masque s'affichait en jeu mais JAMAIS dans les aperçus
-- preview/char-select (ni dans la signature de rebuild -> aucune reconstruction à l'équip masque,
-- ni dans EnsureSharedParts -> part masque jamais créée sur le mannequin). Bug user 07/24.
local PANEL_ACCESSORY_DRAW_ORDER = { 1, 3, 4, 5, 6, 7 }

-- Composite UI partagé (HUD + inventaire + menu anim) : un seul jeu de CSEnts,
-- reparenté sur le panel ent à chaque passe de rendu (plusieurs panels visibles OK).
local _lzySharedPanelRig = {
	buildSig = nil,
	parts = nil,
	models = nil,
}
local _lzySharedPanelHolder = nil
local _lzySharedPanelOverlay = nil

function LZY_Character_PlayerModel_ComputeBuildSig(characterData)
	if not characterData or not characterData.body_model then return nil end
	-- Uniforme de grade (char-select : résolu depuis les données du perso ; previews : déjà résolu).
	local bodyModel = (LZY_Character_GetDisplayBodyModelFromData and LZY_Character_GetDisplayBodyModelFromData(characterData)) or characterData.body_model
	local hairPath = LZY_CHARACTER_CONFIG.GetHairModelForCharacter(characterData, LocalPlayer()) or characterData.hair_model or ""
	local beardPath, mustachePath = "", ""
	if LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) ~= "female" then
		local bm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.beard_model or ""))
		local mm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.mustache_model or ""))
		beardPath = bm
		mustachePath = mm
	end
	local accParts = {}
	local accTbl = characterData.equipped_accessories
	local accSkins = characterData.equipped_accessory_skins
	if istable(accTbl) then
		for i = 1, #PANEL_ACCESSORY_DRAW_ORDER do
			local slot = PANEL_ACCESSORY_DRAW_ORDER[i]
			local path = accTbl[tostring(slot)]
			if isstring(path) and path ~= "" then
				local skin = istable(accSkins) and tonumber(accSkins[tostring(slot)]) or 0
				accParts[#accParts + 1] = tostring(slot) .. ":" .. path .. ":" .. skin
			end
		end
	end
	table.sort(accParts)
	return table.concat({
		tostring(bodyModel),
		tostring(hairPath),
		beardPath,
		mustachePath,
		table.concat(accParts, "|"),
		-- skin_color + bodygroups : SANS eux, un changement de PEAU (ou de bodygroup) ne change pas la
		-- signature -> le composite (donc le CORPS) ne se reconstruit pas dans les aperçus HUD/inventaire
		-- et garde l'ancienne peau. Le portrait HUD, lui, re-bake la TÊTE via son propre bakeSig (qui
		-- inclut skin) -> asymétrie "seule la tête change, pas le corps". On les ajoute ici.
		"sk:" .. tostring(characterData.skin_color),
		"bg:" .. tostring(characterData.bodygroupsString),
		-- Épaulette de grade (par faction+rang, masquable) : sans ce jeton, la coche « Cacher »
		-- ou une promotion ne reconstruit pas le composite d'aperçu -> épaulette figée.
		"ep:" .. tostring((LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter
			and LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter(characterData, LocalPlayer())) or ""),
		-- Brassard vice-capitaine (modèle + SKIN division) : le SKIN doit être dans le jeton (le modèle
		-- est identique pour toutes les divisions -> sans le skin, un changement de division ne
		-- reconstruirait pas l'aperçu et garderait l'ancien numéro de division).
		"br:" .. (function()
			if not LZY_CHARACTER_CONFIG.GetBrassardForCharacter then return "" end
			local m, s = LZY_CHARACTER_CONFIG.GetBrassardForCharacter(characterData)
			return tostring(m or "") .. ":" .. tostring(s or "")
		end)(),
		-- Corps Espada (capitaine Hollow 15-16, modèle + SKIN par Ordre) : skin dans le jeton comme le brassard.
		"es:" .. (function()
			if not LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter then return "" end
			local m, s = LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter(characterData)
			return tostring(m or "") .. ":" .. tostring(s or "")
		end)(),
		-- Haori de capitaine : un MODÈLE par division, donc le chemin suffit comme jeton
		-- (pas de skin à y mettre, contrairement au brassard).
		"ha:" .. tostring((LZY_CHARACTER_CONFIG.GetHaoriForCharacter
			and LZY_CHARACTER_CONFIG.GetHaoriForCharacter(characterData)) or ""),
		-- Cape du Roi du Hueco Mundo (Hollow grade 16) : sans ce jeton, la coche « Cacher la
		-- tenue de grade » ou la promotion au grade 16 ne reconstruirait pas l'aperçu.
		"ck:" .. tostring((LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter
			and LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter(characterData)) or ""),
		-- Accessoire body de division : sans ce jeton, un changement de division ne
		-- reconstruirait pas l'aperçu (l'ancien accessoire resterait affiché).
		"db:" .. tostring((LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter
			and LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter(characterData, LocalPlayer())) or ""),
		-- Masque de base Arrancar : sans ce jeton, ÉQUIPER ou RETIRER un masque acheté ne
		-- reconstruirait pas l'aperçu (le masque de base resterait, ou manquerait, jusqu'au
		-- prochain changement d'autre chose). Une promotion Arrancar -> Espada change le modèle.
		"am:" .. tostring((LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter
			and LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter(characterData)) or ""),
	}, "\n")
end

function LZY_Character_PlayerModel_InvalidateSharedRig()
	if _lzySharedPanelRig.parts then
		for _, e in pairs(_lzySharedPanelRig.parts) do
			if istable(e) then
				for _, sub in ipairs(e) do
					if IsValid(sub) then SafeRemoveEntity(sub) end
				end
			elseif IsValid(e) then SafeRemoveEntity(e) end
		end
	end
	_lzySharedPanelRig.buildSig = nil
	_lzySharedPanelRig.parts = nil
	_lzySharedPanelRig.models = nil
	_lzySharedPanelRig.activeEnt = nil
	hook.Run("LZY_Character:SharedPanelRigInvalidated")
end

function LZY_Character_PlayerModel_IsSharedRigReady()
	local parts = _lzySharedPanelRig.parts
	local models = _lzySharedPanelRig.models
	if not parts or not models then return false end
	if not IsValid(parts.body) or not IsValid(parts.hair) then return false end
	return true
end

function LZY_Character_PlayerModel_GetSharedOverlay()
	return _lzySharedPanelOverlay
end

function LZY_Character_PlayerModel_ReleaseEntityParts(ent)
	if not IsValid(ent) or not ent.PlayerModelParts then return end
	if _lzySharedPanelRig.parts and ent.PlayerModelParts == _lzySharedPanelRig.parts then
		ent.PlayerModelParts = nil
		ent.RenderOverride = nil
		ent._inventoryModelOverlay = nil
		ent._lzySharedPanelRO = nil
		if IsValid(_lzySharedPanelHolder) and _lzySharedPanelRig.models then
			for _, mdl in ipairs(_lzySharedPanelRig.models) do
				if IsValid(mdl) then mdl:SetParent(_lzySharedPanelHolder) end
			end
		end
		_lzySharedPanelRig.activeEnt = nil
		return
	end
	for _, e in pairs(ent.PlayerModelParts) do
		if istable(e) then
			for _, sub in ipairs(e) do
				if IsValid(sub) then SafeRemoveEntity(sub) end
			end
		elseif IsValid(e) then SafeRemoveEntity(e) end
	end
	ent.PlayerModelParts = nil
	ent.RenderOverride = nil
	ent._inventoryModelOverlay = nil
end

local function LZY_Character_PlayerModel_GetSharedHolder(faceModelPath)
	faceModelPath = tostring(faceModelPath or "")
	if faceModelPath == "" then
		faceModelPath = LZY_CHARACTER_CONFIG.GetDefaultFaceModel("male")
	end
	if not IsValid(_lzySharedPanelHolder) then
		_lzySharedPanelHolder = ClientsideModel(faceModelPath)
		if IsValid(_lzySharedPanelHolder) then
			_lzySharedPanelHolder:SetNoDraw(true)
			_lzySharedPanelHolder.skipDim = true
		end
	elseif _lzySharedPanelHolder:GetModel() ~= faceModelPath then
		_lzySharedPanelHolder:SetModel(faceModelPath)
	end
	return _lzySharedPanelHolder
end

function LZY_Character_PlayerModel_PlayPanelIdle(ent, characterData)
	if not IsValid(ent) then return end
	local gender = characterData and LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender)
	local anim = (gender == "female") and LZY_CHARACTER_CONFIG.IDLE_ANIM_FEMALE or LZY_CHARACTER_CONFIG.IDLE_ANIM_MALE
	local seq = ent:LookupSequence(anim or "")
	if not seq or seq < 0 then seq = ent:LookupSequence("idle_all_01") end
	if not seq or seq < 0 then seq = ent:LookupSequence("idle") end
	if seq and seq >= 0 then
		ent:ResetSequence(seq)
		ent:SetCycle(0)
		ent:SetPlaybackRate(1)
	end
	ent:SetupBones()
end

local function LZY_Character_PlayerModel_AttachSharedPartsTo(ent)
	if not IsValid(ent) then return end
	local models = _lzySharedPanelRig.models
	if not models then return end
	for _, mdl in ipairs(models) do
		if not IsValid(mdl) then continue end
		if mdl._lzyPet then
			mdl._petParent = ent -- pet d'épaule : re-bonemergé sur le panel courant par le module pets (PetPlace)
			continue
		end
		if mdl:GetParent() ~= ent then
			mdl:SetParent(ent)
			mdl:SetLocalPos(Vector(0, 0, 0))
			mdl:SetLocalAngles(Angle(0, 0, 0))
			mdl:AddEffects(EF_BONEMERGE + EF_BONEMERGE_FASTCULL)
		end
	end
	_lzySharedPanelRig.activeEnt = ent
	ent:SetupBones()
end

--- Pose + bonemerge attach immediately before a panel/RT draw pass (HUD portrait bake).
--- Matches legacy HUD DModelPanel.LayoutEntity: seq 0 / cycle 0 (not gender idle).
function LZY_Character_PlayerModel_PreparePanelForDraw(ent, characterData)
	if not IsValid(ent) then return end
	ent:SetAngles(Angle(0, 0, 0))
	ent:SetSequence(0)
	ent:SetCycle(0)
	if ent.RenderOverride and _lzySharedPanelRig.models then
		LZY_Character_PlayerModel_AttachSharedPartsTo(ent)
	end
	ent:SetupBones()
end

local function LZY_Character_PlayerModel_EnsureSharedOverlay(ply)
	if not MUGEN or not MUGEN.Character or not MUGEN.Character.Config then return end
	if not IsValid(_lzySharedPanelOverlay) then
		_lzySharedPanelOverlay = ClientsideModel(MUGEN.Character.Config.StandartModel or "models/ali/bleach/vetement_homme.mdl", RENDERGROUP_OPAQUE)
		if IsValid(_lzySharedPanelOverlay) then
			_lzySharedPanelOverlay:SetNoDraw(true)
			_lzySharedPanelOverlay.skipDim = true
		end
	end
	if not IsValid(_lzySharedPanelOverlay) or not IsValid(ply) then return end
	_lzySharedPanelOverlay:SetSkin(ply:GetSkin() or 0)
	local bodygroupsTable = util.JSONToTable(ply:GetEvoNWString("OverlayBodygroups", "{}"))
	if istable(bodygroupsTable) then
		for indexStr, value in pairs(bodygroupsTable) do
			local index = tonumber(indexStr)
			if index and isnumber(value) and _lzySharedPanelOverlay:GetBodygroupCount(index) > 1 then
				_lzySharedPanelOverlay:SetBodygroup(index, value)
			end
		end
	end
end

local function LZY_Character_PlayerModel_EnsureSharedParts(characterData, faceEnt)
	local sig = LZY_Character_PlayerModel_ComputeBuildSig(characterData)
	if not sig then return nil end
	local parts = _lzySharedPanelRig.parts
	if _lzySharedPanelRig.buildSig == sig and parts and IsValid(parts.body) and IsValid(parts.hair) then
		if IsValid(faceEnt) then
			LZY_Character_PlayerModel_AttachSharedPartsTo(faceEnt)
		end
		return parts
	end

	LZY_Character_PlayerModel_InvalidateSharedRig()

	local facePath = (IsValid(faceEnt) and faceEnt:GetModel()) or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
	local holder = LZY_Character_PlayerModel_GetSharedHolder(facePath)
	if not IsValid(holder) then return nil end

	local accList = {}
	local accTbl = characterData.equipped_accessories
	local accSkins = characterData.equipped_accessory_skins
	if istable(accTbl) then
		for i = 1, #PANEL_ACCESSORY_DRAW_ORDER do
			local slot = PANEL_ACCESSORY_DRAW_ORDER[i]
			local path = accTbl[tostring(slot)]
			if isstring(path) and path ~= "" then
				local skin = istable(accSkins) and tonumber(accSkins[tostring(slot)]) or nil
				local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, path, nil, skin)
				if IsValid(mdl) then
					mdl._lzyAccessorySlot = tostring(slot)
					-- Pet d'épaule : attaché au panel courant par le module pets (cl_models).
					local petCfg = LZY_CHARACTER_CONFIG.GetShoulderPet and LZY_CHARACTER_CONFIG.GetShoulderPet(path)
					if petCfg and LZY_Character_SetupPetPart then LZY_Character_SetupPetPart(holder, mdl, petCfg) end
					accList[#accList + 1] = mdl
				end
			end
		end
	end

	-- Épaulette de grade (bonemergée comme un accessoire, slot "grade") : même rendu que le monde/HUB.
	-- Résolue via characterData (faction+rang) et masquable par la coche inventaire (EVO_HideEpaulette).
	if LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter then
		local epaulette = LZY_CHARACTER_CONFIG.GetEpauletteModelForCharacter(characterData, LocalPlayer())
		if isstring(epaulette) and epaulette ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, epaulette, nil, nil)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "grade"
				accList[#accList + 1] = mdl
			end
		end
	end

	-- Brassard vice-capitaine (grade 14 Shinigami, skin PAR DIVISION) : slot "brassard", coexiste
	-- avec l'épaulette. Résolu via characterData (faction+rang+division).
	if LZY_CHARACTER_CONFIG.GetBrassardForCharacter then
		local brassard, bskin = LZY_CHARACTER_CONFIG.GetBrassardForCharacter(characterData)
		if isstring(brassard) and brassard ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, brassard, nil, bskin)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "brassard"
				accList[#accList + 1] = mdl
			end
		end
	end
	-- Corps Espada (capitaine Hollow 15-16, skin PAR ORDRE) : slot "espada", coexiste épaulette/brassard.
	if LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter then
		local espada, eskin = LZY_CHARACTER_CONFIG.GetEspadaBodyForCharacter(characterData)
		if isstring(espada) and espada ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, espada, nil, eskin)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "espada"
				accList[#accList + 1] = mdl
			end
		end
	end

	-- Haori de capitaine (Shinigami 15+, un modèle par division) : slot "haori".
	if LZY_CHARACTER_CONFIG.GetHaoriForCharacter then
		local haori = LZY_CHARACTER_CONFIG.GetHaoriForCharacter(characterData)
		if isstring(haori) and haori ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, haori, nil, nil)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "haori"
				accList[#accList + 1] = mdl
			end
		end
	end

	-- Cape du Roi du Hueco Mundo (Hollow grade 16) : slot "cape_roi".
	if LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter then
		local cape = LZY_CHARACTER_CONFIG.GetHollowKingCapeForCharacter(characterData)
		if isstring(cape) and cape ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, cape, nil, nil)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "cape_roi"
				accList[#accList + 1] = mdl
			end
		end
	end

	-- Accessoire body de division : slot "division_body", même rendu qu'en jeu.
	if LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter then
		local divBody = LZY_CHARACTER_CONFIG.GetDivisionBodyForCharacter(characterData)
		if isstring(divBody) and divBody ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, divBody, nil, nil)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "division_body"
				accList[#accList + 1] = mdl
			end
		end
	end

	-- Masque de base Arrancar (tout Hollow ; modèle dédié Espada) : slot "masque_base". Renvoie nil
	-- si un masque acheté est équipé -> il est déjà rendu par la boucle accessoires (slot 7).
	if LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter then
		local masque = LZY_CHARACTER_CONFIG.GetArrancarMaskForCharacter(characterData)
		if isstring(masque) and masque ~= "" then
			local mdl = LZY_Character_PlayerModel_CreateModelPart(holder, masque, nil, nil)
			if IsValid(mdl) then
				mdl._lzyAccessorySlot = "masque_base"
				accList[#accList + 1] = mdl
			end
		end
	end

	local hairPath = LZY_CHARACTER_CONFIG.GetHairModelForCharacter(characterData, LocalPlayer()) or characterData.hair_model
	if not isstring(hairPath) or hairPath == "" then return nil end

	local beardPath, mustachePath = nil, nil
	if LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) ~= "female" then
		local bm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.beard_model or ""))
		local mm = LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(tostring(characterData.mustache_model or ""))
		beardPath = (bm ~= "") and bm or nil
		mustachePath = (mm ~= "") and mm or nil
	end

	local bodyModel = (LZY_Character_GetDisplayBodyModelFromData and LZY_Character_GetDisplayBodyModelFromData(characterData)) or characterData.body_model
	parts = {
		body = LZY_Character_PlayerModel_CreateModelPart(holder, bodyModel, nil, characterData.skin_color),
		hair = LZY_Character_PlayerModel_CreateModelPart(holder, hairPath, Color(255, 255, 255), nil),
		beard = beardPath and LZY_Character_PlayerModel_CreateModelPart(holder, beardPath, Color(255, 255, 255), nil) or nil,
		mustache = mustachePath and LZY_Character_PlayerModel_CreateModelPart(holder, mustachePath, Color(255, 255, 255), nil) or nil,
		tattoo = nil,
		accessories = accList,
	}

	local models = { parts.body, parts.hair }
	if IsValid(parts.beard) then models[#models + 1] = parts.beard end
	if IsValid(parts.mustache) then models[#models + 1] = parts.mustache end
	if istable(parts.accessories) then
		for i = 1, #parts.accessories do
			models[#models + 1] = parts.accessories[i]
		end
	end

	_lzySharedPanelRig.buildSig = sig
	_lzySharedPanelRig.parts = parts
	_lzySharedPanelRig.models = models
	if IsValid(faceEnt) then
		LZY_Character_PlayerModel_AttachSharedPartsTo(faceEnt)
	end
	return parts
end

-- Morphologie (flex / shape_keys) sur la FACE du mannequin HUD/inventaire/anim.
-- Les shape_keys ne sont pas bakés dans le .mdl : sans ça le DModelPanel reste au
-- visage par défaut. FrameAdvance de l'idle (LayoutEntity) peut aussi tout remettre
-- à 0 — d'où le rappel chaque draw dans le RenderOverride, APRÈS l'anim.
-- Copie depuis le joueur live quand le modèle de face est le même (source de vérité
-- après sculpteur, comme lzy_shop cosmetic_preview). Sinon les shape_keys des data.
local function LZY_Character_PlayerModel_ApplyPanelFlexes(faceEnt, characterData)
	if not IsValid(faceEnt) or not faceEnt.SetFlexWeight then return end
	local lp = LocalPlayer()
	local sameFace = IsValid(lp) and lp.GetFlexNum and faceEnt.GetFlexNum
		and isstring(lp:GetModel()) and isstring(faceEnt:GetModel())
		and string.lower(lp:GetModel()) == string.lower(faceEnt:GetModel())
	if sameFace then
		local n = math.min(faceEnt:GetFlexNum() or 0, lp:GetFlexNum() or 0)
		for i = 0, n - 1 do
			if not (LZY_Character_IsReservedFlexKey and LZY_Character_IsReservedFlexKey(faceEnt, i)) then
				faceEnt:SetFlexWeight(i, lp:GetFlexWeight(i) or 0)
			end
		end
		if faceEnt.SetFlexScale and lp.GetFlexScale then
			faceEnt:SetFlexScale(lp:GetFlexScale() or 1)
		end
		return
	end
	if characterData and LZY_Character_ApplyShapeKeysFromData then
		LZY_Character_ApplyShapeKeysFromData(faceEnt, characterData)
	end
end

local function LZY_Character_PlayerModel_ApplySharedMaterials(faceEnt, characterData)
	if not IsValid(faceEnt) or not characterData then return end
	if characterData.skin_color and faceEnt.SetSkin then
		faceEnt:SetSkin(tonumber(characterData.skin_color) or 0)
	end
	local bg = (isstring(characterData.bodygroupsString) and characterData.bodygroupsString ~= "")
		and characterData.bodygroupsString
		or ((isstring(characterData.bodygroups) and characterData.bodygroups ~= "") and characterData.bodygroups or nil)
	if bg and faceEnt.SetBodyGroups then
		faceEnt:SetBodyGroups(bg)
	end

	local parts = _lzySharedPanelRig.parts
	if parts and parts.hair and characterData.hair_color1 and characterData.hair_color2 and ApplyHairGradientToWorldPlayer then
		ApplyHairGradientToWorldPlayer(faceEnt, parts.hair, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, LZY_Character_PlayerModel_NormalizeHairDetailsColor(characterData.hair_details_color))
	end
	if parts and IsValid(parts.beard) and characterData.hair_color1 and characterData.hair_color2 and ApplyHairGradientToWorldPlayer then
		ApplyHairGradientToWorldPlayer(faceEnt, parts.beard, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, LZY_Character_PlayerModel_NormalizeHairDetailsColor(characterData.hair_details_color))
	end
	if parts and IsValid(parts.mustache) and characterData.hair_color1 and characterData.hair_color2 and ApplyHairGradientToWorldPlayer then
		ApplyHairGradientToWorldPlayer(faceEnt, parts.mustache, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle or 0, LZY_Character_PlayerModel_NormalizeHairDetailsColor(characterData.hair_details_color))
	end

	local eyesColor = LZY_Character_PlayerModel_NormalizeEyesColor(characterData.eyes_color) or Color(255, 255, 255)
	faceEnt.EyesColor = eyesColor
	if ApplyPupilsFromCharacterData then
		ApplyPupilsFromCharacterData(faceEnt, characterData.gender, characterData)
	end
	LZY_Character_PlayerModel_ApplyPanelFlexes(faceEnt, characterData)

	timer.Simple(0, function()
		if not IsValid(faceEnt) then return end
		if LZY_ApplyTattooFromCharacterData then
			LZY_ApplyTattooFromCharacterData(faceEnt, characterData)
		end
		-- Tatouages du corps : rig PARTAGÉ entre persos -> ré-appliqué (ou retiré) à chaque
		-- mise en place, une seule RT « panel ».
		local tParts = faceEnt.PlayerModelParts
		if LZY_ApplyBodyTattoo and tParts and IsValid(tParts.body) then
			LZY_ApplyBodyTattoo(tParts.body, characterData, "panel", LZY_CHARACTER_CONFIG.TATTOO_RT_SIZE or 2048)
		end
	end)
	timer.Simple(0.15, function()
		if not IsValid(faceEnt) then return end
		if LZY_ApplyTattooFromCharacterData then
			LZY_ApplyTattooFromCharacterData(faceEnt, characterData)
		end
	end)
end

local function LZY_Character_PlayerModel_GetPanelRenderOverride(ent)
	if ent._lzySharedPanelRO then return ent._lzySharedPanelRO end
	ent._lzySharedPanelRO = function()
		if not IsValid(ent) then return end
		local parts = _lzySharedPanelRig.parts
		local models = _lzySharedPanelRig.models

		local prevR, prevG, prevB = render.GetColorModulation()
		local prevA = render.GetBlend()
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
		-- Après FrameAdvance (LayoutEntity) : ré-applique le sculpt, sinon le
		-- ClientsideModel du panel reste au visage par défaut.
		LZY_Character_PlayerModel_ApplyPanelFlexes(ent, ent._lzyPanelCharacterData)
		ent:DrawModel()

		if parts and models then
			LZY_Character_PlayerModel_AttachSharedPartsTo(ent)
			ent:SetupBones()
			local panelCharData = ent._lzyPanelCharacterData
			for _, mdl in ipairs(models) do
				if not IsValid(mdl) then continue end
				if mdl._lzyAccessorySlot and LZY_Character_DrawAccessoryModel then
					LZY_Character_DrawAccessoryModel(ent, mdl, panelCharData)
				else
					mdl:SetupBones()
					mdl:DrawModel()
				end
			end
		end

		local overlay = ent._inventoryModelOverlay
		if overlay and IsValid(overlay) then
			ent:SetupBones()
			overlay:SetupBones()
			if not ent._lzySharedOverlayBoneMap then
				ent._lzySharedOverlayBoneMap = {}
				for i = 0, overlay:GetBoneCount() - 1 do
					local entBone = ent:LookupBone(overlay:GetBoneName(i))
					if entBone then ent._lzySharedOverlayBoneMap[i] = entBone end
				end
			end
			for i, entBone in pairs(ent._lzySharedOverlayBoneMap) do
				local matrix = ent:GetBoneMatrix(entBone)
				if matrix then overlay:SetBoneMatrix(i, matrix) end
			end
			if overlay.gSetPos then
				overlay:gSetPos(ent:GetPos())
			else
				overlay:SetPos(ent:GetPos())
			end
			overlay:SetAngles(ent:GetAngles())
			overlay:DrawModel()
		end

		render.SetColorModulation(prevR, prevG, prevB)
		render.SetBlend(prevA)
	end
	return ent._lzySharedPanelRO
end

function LZY_Character_PlayerModel_SetupPanelEntity(ent, characterData, modelOverlayRef)
	if not IsValid(ent) or not characterData or not characterData.body_model then return end
	-- evo_hollow_progression : larva/vasto = modèle créature brut, pas de composite panel.
	-- ⚠ body_model (pas LZY_IsLarvaCharacter) — Lost Soul partage EVO_HollowRaw.
	local isLarvaBody = EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel
		and EVO_HollowProg.IsLarvaBodyModel(characterData.body_model)
	local isLostSoulBody = EVO_LostSoul and EVO_LostSoul.IsLostSoulBodyModel
		and EVO_LostSoul.IsLostSoulBodyModel(characterData.body_model)
	if isLarvaBody or isLostSoulBody then
		LZY_Character_PlayerModel_ReleaseEntityParts(ent)
		if ent.SetModel and ent:GetModel() ~= characterData.body_model then
			ent:SetModel(characterData.body_model)
		end
		if isLarvaBody and EVO_HollowProg and EVO_HollowProg.ApplyAppearance then
			local cfg = EVO_HollowProg.Config
			local isVasto = cfg and characterData.body_model == cfg.VastoModel
			EVO_HollowProg.ApplyAppearance(ent, isVasto, characterData.unique_id)
		end
		if ent.SetModelScale then
			if isLarvaBody then
				ent:SetModelScale((EVO_HollowProg and EVO_HollowProg.GetScale and EVO_HollowProg.GetScale(characterData.unique_id))
					or tonumber(characterData.scale) or 1)
			else
				ent:SetModelScale((EVO_LostSoul and EVO_LostSoul.Config and tonumber(EVO_LostSoul.Config.ModelScale)) or 1)
			end
		end
		return
	end
	if LZY_Character_ApplyModelScale then
		LZY_Character_ApplyModelScale(ent, characterData)
	elseif ent.SetModelScale then
		ent:SetModelScale(math.Clamp(tonumber(characterData.scale) or 1, 0.9, 1.1), 0)
	end
	if not characterData.hair_model or characterData.hair_model == "" then return end

	LZY_Character_PlayerModel_ReleaseEntityParts(ent)

	local parts = LZY_Character_PlayerModel_EnsureSharedParts(characterData, ent)
	if not parts then return end

	local lp = LocalPlayer()
	if IsValid(lp) then
		LZY_Character_PlayerModel_EnsureSharedOverlay(lp)
	end

	ent.PlayerModelParts = parts
	ent._inventoryModelOverlay = IsValid(modelOverlayRef) and modelOverlayRef or _lzySharedPanelOverlay
	ent._lzyPanelCharacterData = characterData
	ent._lzyPanelBuildSig = LZY_Character_PlayerModel_ComputeBuildSig(characterData)
	ent.RenderOverride = LZY_Character_PlayerModel_GetPanelRenderOverride(ent)
	LZY_Character_PlayerModel_PlayPanelIdle(ent, characterData)
	LZY_Character_PlayerModel_ApplySharedMaterials(ent, characterData)
end

function LZY_Character_PlayerModel_RefreshFaceMaterials(ent, characterData)
	if LZY_RefreshEntityFaceMaterials then
		LZY_RefreshEntityFaceMaterials(ent, characterData)
	end
end

-- Liste des persos : remplie par le serveur via le net "EVO:Client:CharacterSelection:Open".
local charactersData = {}

local function OpenCharacterSelection()
	-- UNIQUEMENT la scene in-world : on ne cree PLUS JAMAIS l'ancienne grille.
	-- Si la scene n'est pas encore prete au tout debut du spawn, on retente
	-- (le temps que l'addon/les modeles soient charges).
	if IsValid(frame) then frame:Close() end

	local function tryOpen(attempt)
		if NCM_CHAR_SELECT and isfunction(NCM_CHAR_SELECT.StartScene) then
			local ok, started = pcall(NCM_CHAR_SELECT.StartScene, charactersData)
			if ok and started then return end
		end
		attempt = (attempt or 0) + 1
		if attempt <= 15 then -- ~4.5s de tentatives
			timer.Simple(0.3, function() tryOpen(attempt) end)
		end
	end
	tryOpen(0)
end

-- Expose so character creation can return to this screen (e.g. Page 1 go back)
LZY_CharacterSelection = LZY_CharacterSelection or {}
LZY_CharacterSelection.Open = OpenCharacterSelection

-- Nombre de persos REELS du compte, cote client (memes regles que le serveur :
-- EVO_LostSoul.IsRealCharRow -> exclut l'ame errante et les slots ANIMATION 4/5).
-- charactersData est la liste envoyee par le serveur (net Open) et tenue a jour a la
-- suppression : contrairement a NCM_CHAR_SELECT.RealFilledCount (qui lit les slots de la
-- SCENE, vides des StopScene), elle reste valide une fois le createur ouvert. Sert au gate
-- du champ « code de parrainage » (1er perso uniquement).
function LZY_CharacterSelection.RealCharCount()
	local n = 0
	for key, row in pairs(charactersData) do
		-- charactersData est indexee par slot : la CLE fait foi si la ligne n'a pas .slot
		-- (sinon un perso ANIMATION 4/5 passerait le filtre de IsRealCharRow).
		local slot = tonumber(row and row.slot) or tonumber(key) or 0
		if istable(row) and slot >= 1 and slot <= 3 then
			local isReal = true
			if EVO_LostSoul and EVO_LostSoul.IsRealCharRow then
				isReal = EVO_LostSoul.IsRealCharRow(row)
			end
			if isReal then n = n + 1 end
		end
	end
	return n
end

-- Même liste, mais exclut AUSSI la larve Hollow : le champ parrainage doit rester
-- visible à la finalisation Arrancar (1er perso « réel » du compte Hollow).
function LZY_CharacterSelection.ParrainageEligibleCount()
	local n = 0
	for key, row in pairs(charactersData) do
		local slot = tonumber(row and row.slot) or tonumber(key) or 0
		if istable(row) and slot >= 1 and slot <= 3 then
			local ok = true
			if EVO_Parrainage and EVO_Parrainage.IsEligibleCharRow then
				ok = EVO_Parrainage.IsEligibleCharRow(row)
			elseif EVO_LostSoul and EVO_LostSoul.IsRealCharRow then
				ok = EVO_LostSoul.IsRealCharRow(row)
			end
			if ok then n = n + 1 end
		end
	end
	return n
end

-- Ouverture fiable pour tester (indépendant du serveur / de F6).
concommand.Add("lzy_charselect", function()
    -- Passe par le routage normal -> la nouvelle scene in-world (plus la grille).
    OpenCharacterSelection()
end)

-- Plus de keybind direct ici : changer de personnage passe UNIQUEMENT par le bouton
-- PERSONNAGE du menu Échap (net EVO:Server:ReOpenCharacterMenu -> playerMeta:ReOpenCharacterMenu,
-- sv_main.lua ; ex-touche F8) qui applique le verrou anti-combat (3 min) + le snapshot
-- anti-heal. Ce hook client ouvrait la scene en CONTOURNANT ces securites.
-- OpenCharacterSelection reste appele par le retour du creator + la concommand lzy_charselect
-- (via LZY_CharacterSelection.Open).

local function isHollowFinalizeFlow()
    if not EVO_HollowProg then return false end
    if EVO_HollowProg._FinalizePending then return true end
    -- Slot posé à l'ouverture du creator (F) : retour menu avant le 2e net.
    if EVO_HollowProg._FinalizeSlot and not EVO_HollowProg._Finalizing then return true end
    return false
end

net.Receive("EVO:Client:CharacterSelection:Open", function()
    -- Relâche un éventuel écran noir d'onboarding (HoldBlack) : ce net ROUVRE l'UI personnages
    -- (y compris en fallback serveur après un Begin âme errante refusé) — il ne doit jamais
    -- rester masqué par le hold (sinon noir 8s jusqu'au failsafe). No-op si pas de hold.
    if EVO_IntroCine and EVO_IntroCine.HoldStop then EVO_IntroCine.HoldStop() end
    -- Hub flag LOCAL (fiable) : CSM ne doit pas bake le monde pendant la sélection.
    if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(true) end
    charactersData = net.ReadTable() or {}
    -- ReadTable -> cles souvent string ; StartScene / POSITION_TO_SLOT indexent en number.
    do
        local norm = {}
        for k, v in pairs(charactersData) do
            local slot = tonumber(k)
            if slot and istable(v) then norm[slot] = v end
        end
        charactersData = norm
    end
    if net.BytesLeft() > 0 and net.ReadBool() then
        if EVO_HollowProg and EVO_HollowProg.ApplyFinalizeSelectionClient then
            EVO_HollowProg.ApplyFinalizeSelectionClient(net.ReadUInt(4), net.ReadUInt(32))
        else
            net.ReadUInt(4)
            net.ReadUInt(32)
        end
    elseif EVO_HollowProg and EVO_HollowProg.ClearFinalizeClient then
        EVO_HollowProg.ClearFinalizeClient()
    end
    local hollowFinalize = isHollowFinalizeFlow()
    -- Flux : aucun perso -> création directe (sauf reprise finalisation Hollow -> sélection).
    -- EXCEPTION animateur : on OUVRE la scène de sélection (emplacements 4/5 ANIMATION).
    -- Avant, 0 perso = créateur classique direct -> sur Hueco, Hollow = larve et Shinigami =
    -- transfert Seireitei, donc impossible de créer un perso ANIMATION (slots 4/5 jamais vus).
    local isAnimateur = IsValid(LocalPlayer()) and LocalPlayer().GetUserGroup
        and EVO_ANIM ~= nil and EVO_ANIM.IsAnimGroupName(LocalPlayer():GetUserGroup())
    if table.Count(charactersData) == 0 and not hollowFinalize and not isAnimateur then
        if IsValid(frame) then frame:Remove() end
        -- ONBOARDING (règle user 2026-07-14) : un NOUVEAU joueur (compte sans tuto) fait
        -- TOUJOURS l'âme errante d'abord — ce chemin (0 perso = créateur direct) contournait
        -- l'interception du bouton CRÉER de ncm_char_select. Le choix Hollow (larve) ou
        -- Shinigami (créateur) se fait À LA FIN du tuto, dans le vrai créateur.
        if EVO_LostSoul and EVO_LostSoul.ShouldIntercept and EVO_LostSoul.ShouldIntercept()
            and EVO_LostSoul.BeginFromSelect then
            -- true = auto (connexion / fail Create). false = déjà en vol -> hub vide, pas de re-noir.
            if not EVO_LostSoul.BeginFromSelect(true) then
                OpenCharacterSelection()
            end
        else
            -- DIAGNOSTIC (07/20, « 0 perso mais créateur classique au lieu de l'âme errante ») :
            -- dit QUEL gate a échoué — visible en console client, à copier tel quel.
            local why = "raison inconnue"
            if not EVO_LostSoul then why = "addon evo_lost_soul ABSENT côté client (transfert CS-Lua ?)"
            elseif not EVO_LostSoul.ShouldIntercept then why = "vieux fichier client (ShouldIntercept absent) — restart serveur + reconnexion"
            elseif EVO_LostSoul.IsActiveMap and not EVO_LostSoul.IsActiveMap() then why = "map tutoriel non configurée pour « " .. game.GetMap() .. " » (NCM_TUTORIEL.MAP_POSITIONS / CFG.Enabled)"
            elseif not IsValid(LocalPlayer()) then why = "LocalPlayer pas encore valide (net trop tôt)"
            elseif EVO_HollowProg and EVO_HollowProg._Finalizing then why = "finalisation Hollow en cours"
            end
            print("[LostSoul] 0 perso mais createur classique -> " .. why)
            OpenCharacterCreator()
        end
    else
        OpenCharacterSelection()
    end
end)

net.Receive("EVO:Client:CharacterCreator:CharacterDeleted", function()
    local success = net.ReadBool()
    local slot = net.ReadInt(32)
    if success and slot and charactersData[slot] then
        charactersData[slot] = nil
        if table.Count(charactersData) == 0 then
            -- plus aucun perso -> même interception onboarding qu'à la connexion. CRITÈRE
            -- « 0 perso RÉEL » (2026-07-17) : supprimer son DERNIER perso te renvoie désormais
            -- à l'âme errante (le serveur re-valide via CountRealChars). L'ancien wrap
            -- delete->tuto-fait (qui renvoyait au créateur) a été retiré.
            -- Animateur : rouvre la sélection (slots ANIMATION 4/5), pas le créateur classique
            -- (sinon Hueco = larve / transfert, perso animation inaccessible).
            local isAnimateur = IsValid(LocalPlayer()) and LocalPlayer().GetUserGroup
                and EVO_ANIM ~= nil and EVO_ANIM.IsAnimGroupName(LocalPlayer():GetUserGroup())
            if isAnimateur then
                OpenCharacterSelection()
            elseif EVO_LostSoul and EVO_LostSoul.ShouldIntercept and EVO_LostSoul.ShouldIntercept()
                and EVO_LostSoul.BeginFromSelect then
                if not EVO_LostSoul.BeginFromSelect(true) then
                    OpenCharacterSelection()
                end
            else
                OpenCharacterCreator()
            end
        else
            OpenCharacterSelection()
        end
    end
end)