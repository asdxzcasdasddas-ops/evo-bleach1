-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_ply_state.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client: owner + remote appearance bags from versioned reliable Full/Delta.

LZY_LocalState = LZY_LocalState or {}
LZY_RemoteState = LZY_RemoteState or {}

local function ReadValue(def)
	if def.ty == "string" then
		return net.ReadString()
	elseif def.ty == "bool" then
		return net.ReadBool()
	elseif def.ty == "float" then
		return net.ReadFloat()
	else
		return net.ReadInt(32)
	end
end

local function ApplyKey(def, val)
	local old = LZY_LocalState[def.key]
	if old == val then return end
	LZY_LocalState[def.key] = val
	hook.Run("LZY:PlyState:Changed", LocalPlayer(), def.key, old, val)
end

function LZY_PlyState.SetLocalPreview(key, val)
	local def = LZY_PlyState.BY_KEY[key]
	if not def then return end
	local normalized = LZY_PlyState.Normalize(key, val)
	local old = LZY_LocalState[key]
	if old == normalized then return end
	LZY_LocalState[key] = normalized
	hook.Run("LZY:PlyState:Changed", LocalPlayer(), key, old, normalized)
end

net.Receive("EVO:Client:PlyStateFull", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then
		ErrorNoHalt(string.format("[LZY:PlyState] Full version mismatch server=%d client=%d\n", version, LZY_PlyState.VERSION))
		return
	end
	local n = net.ReadUInt(8)
	local schema = LZY_PlyState and LZY_PlyState.SCHEMA
	if not schema then return end
	n = math.min(n, #schema)
	for i = 1, n do
		local def = schema[i]
		if not def then break end
		ApplyKey(def, ReadValue(def))
	end
	local uid = LZY_LocalState["Character::Unique::ID"]
	local fac = LZY_LocalState["FactionName"]
	local nick = LZY_LocalState["Nickname"]
	MsgN(string.format("[LZY:PlyState][CL] Full uid=%s faction=%s nick=%s",
		tostring(uid or "?"), tostring(fac ~= "" and fac or "?"), tostring(nick ~= "" and nick or "?")))
	if LZY_Character_MarkLoadingReadyFlag and uid and uid ~= "" and uid ~= "none" then
		LZY_Character_MarkLoadingReadyFlag("identity")
	end
	hook.Run("LZY:PlyState:FullApplied")
end)

net.Receive("EVO:Client:PlyStateDelta", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then
		ErrorNoHalt(string.format("[LZY:PlyState] Delta version mismatch server=%d client=%d\n", version, LZY_PlyState.VERSION))
		return
	end
	local n = net.ReadUInt(8)
	for _ = 1, n do
		local id = net.ReadUInt(8)
		local def = LZY_PlyState and LZY_PlyState.BY_ID and LZY_PlyState.BY_ID[id]
		if def then
			ApplyKey(def, ReadValue(def))
		else
			ErrorNoHalt("[LZY:PlyState] unknown delta field id " .. tostring(id) .. "\n")
			return
		end
	end
end)

net.Receive("EVO:Client:PlyStateClear", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then return end
	LZY_LocalState = {}
end)

local function RemoteBag(ent)
	if not IsValid(ent) then return nil end
	local idx = ent:EntIndex()
	local bag = LZY_RemoteState[idx]
	if not bag or bag.ent ~= ent then
		bag = { ent = ent, values = {} }
		LZY_RemoteState[idx] = bag
	end
	return bag
end

local function ApplyAppearanceKey(ent, def, val)
	local bag = RemoteBag(ent)
	if not bag then return end
	local old = bag.values[def.key]
	if old == val then return end
	bag.values[def.key] = val
	hook.Run("EVO:Appearance:Changed", ent, def.key, old, val)
end

-- UniqueID (nametag / DoIKnowHim) et EVO_SheathedKatana vivent dans CE bag, pas
-- dans le NW2 moteur. Bag absent → "???" + katana rangé invisible jusqu'à un
-- resync (souvent un aller-retour PVS).
local function RemoteHasIdentity(ply)
	if not IsValid(ply) then return false end
	local bag = LZY_RemoteState[ply:EntIndex()]
	return bag and bag.ent == ply and bag.values and bag.values["Character::Unique::ID"] ~= nil
end

-- Full/Delta peuvent arriver AVANT que net.ReadEntity résolve le joueur
-- (course spawn / PVS). Consommer le payload puis redemander, sinon le bag
-- est perdu et rien ne le redemande tant que le joueur ne quitte pas le PVS.
local function ScheduleDroppedAppearanceRetry()
	if timer.Exists("LZY:Appearance:DroppedRetry") then return end
	timer.Create("LZY:Appearance:DroppedRetry", 0.75, 1, function()
		if LZY_PlyState_RequestAppearanceResync then
			LZY_PlyState_RequestAppearanceResync() -- netgate: edge -- Full/Delta arrived before ReadEntity resolved
		end
	end)
end

local function ReadAppearanceFields(n)
	local values
	for _ = 1, n do
		local id = net.ReadUInt(8)
		local def = LZY_PlyState.BY_ID[id]
		if not def or not def.appearance then
			return nil
		end
		values = values or {}
		values[#values + 1] = { def, ReadValue(def) }
	end
	return values or {}
end

net.Receive("EVO:Client:AppearanceFull", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then
		ErrorNoHalt(string.format("[LZY:Appearance] Full version mismatch server=%d client=%d\n", version, LZY_PlyState.VERSION))
		return
	end
	local ent = net.ReadEntity()
	local n = net.ReadUInt(8)
	local fields = ReadAppearanceFields(n)
	if not fields then
		ErrorNoHalt("[LZY:Appearance] unknown full field id\n")
		return
	end
	if not IsValid(ent) then
		ScheduleDroppedAppearanceRetry()
		return
	end
	for i = 1, #fields do
		ApplyAppearanceKey(ent, fields[i][1], fields[i][2])
	end
	if ent == LocalPlayer() and LZY_Character_MarkLoadingReadyFlag then
		LZY_Character_MarkLoadingReadyFlag("appearance")
	end
	hook.Run("EVO:Appearance:FullApplied", ent)
end)

net.Receive("EVO:Client:AppearanceDelta", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then return end
	local ent = net.ReadEntity()
	local n = net.ReadUInt(8)
	local fields = ReadAppearanceFields(n)
	if not fields then return end
	if not IsValid(ent) then
		ScheduleDroppedAppearanceRetry()
		return
	end
	for i = 1, #fields do
		ApplyAppearanceKey(ent, fields[i][1], fields[i][2])
	end
end)

net.Receive("EVO:Client:AppearanceClear", function()
	local version = net.ReadUInt(8)
	if version ~= LZY_PlyState.VERSION then return end
	local ent = net.ReadEntity()
	if not IsValid(ent) then return end
	local idx = ent:EntIndex()
	local bag = LZY_RemoteState[idx]
	if bag and bag.ent == ent then LZY_RemoteState[idx] = nil end
	hook.Run("EVO:Appearance:Cleared", ent)
end)

hook.Add("EntityRemoved", "LZY:Appearance:ClearRemoved", function(ent)
	if not ent or not ent.EntIndex then return end
	local idx = ent:EntIndex()
	local bag = LZY_RemoteState[idx]
	if bag and bag.ent == ent then LZY_RemoteState[idx] = nil end
end)

function LZY_PlyState_RequestAppearanceResync(subject)
	net.Start("EVO:Server:AppearanceResync")
		net.WriteEntity(IsValid(subject) and subject or NULL)
	net.SendToServer()
end

function LZY_PlyState_RequestResync()
	net.Start("EVO:Server:PlyStateResync")
	net.SendToServer()
end

local function RequestResyncIfMissing()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu() then return end
	local uid = LZY_PlyState.Get(lp, "Character::Unique::ID", "")
	local nick = LZY_PlyState.Get(lp, "Nickname", "")
	local faction = LZY_PlyState.Get(lp, "FactionName", "")
	if (uid ~= "" and uid ~= "none") and nick ~= "" and faction ~= "" then return end
	if uid == "" and nick == "" and (not LZY_LocalState or not next(LZY_LocalState)) then
		-- Might still be hub with no bag; only request if we had a loading session
		if not (LZY_Character_HadSpawnLoadBits and LZY_Character_HadSpawnLoadBits()) then return end
	end
	MsgN(string.format("[LZY:PlyState][CL] Resync request uid=%s nick=%s faction=%s",
		uid ~= "" and uid or "?", nick ~= "" and nick or "?", faction ~= "" and faction or "?"))
	LZY_PlyState_RequestResync()
end

hook.Add("EVO:Client:LoadingScreenClosed", "LZY:PlyState:Resync", function()
	timer.Simple(0.2, RequestResyncIfMissing)
	timer.Simple(1.0, RequestResyncIfMissing)
	timer.Simple(3.0, RequestResyncIfMissing)
end)

-- netgate: edge -- only subjects whose appearance bag still lacks UniqueID
local function RequestMissingRemoteAppearance(limit)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	limit = tonumber(limit) or 4
	local n = 0
	for _, ply in player.Iterator() do
		if ply ~= lp and IsValid(ply) and not ply:IsDormant() and not RemoteHasIdentity(ply) then
			LZY_PlyState_RequestAppearanceResync(ply)
			n = n + 1
			if n >= limit then return end
		end
	end
end

hook.Add("InitPostEntity", "LZY:Appearance:InitialResync", function()
	timer.Simple(0, LZY_PlyState_RequestAppearanceResync)
end)

hook.Add("NotifyShouldTransmit", "LZY:Appearance:PVSResync", function(ent, shouldTransmit)
	if not shouldTransmit or not IsValid(ent) or not ent:IsPlayer() then return end
	LZY_PlyState_RequestAppearanceResync(ent)
end)

-- NE PAS vider LZY_RemoteState ici. Les bags des AUTRES joueurs restent
-- valides (leurs entity index ne changent pas au switch / spawn). Un wipe
-- + resync unique se faisait manger par le throttle serveur 3 s : tout le
-- monde déjà en PVS restait « ??? » sans katana rangé jusqu'à un cycle PVS.
hook.Add("EVO:Client:CharacterLoadingBegin", "LZY:Appearance:LoadingResync", function()
	LZY_PlyState_RequestAppearanceResync()
	timer.Simple(1.5, function() RequestMissingRemoteAppearance(8) end)
	timer.Simple(3.5, function() RequestMissingRemoteAppearance(16) end)
end)

hook.Add("EVO:Client:LoadingScreenClosed", "LZY:Appearance:MissingAfterLoad", function()
	timer.Simple(0.25, function() RequestMissingRemoteAppearance(8) end)
	timer.Simple(2.0, function() RequestMissingRemoteAppearance(16) end)
end)

hook.Add("NetworkEntityCreated", "LZY:Appearance:NewPlayer", function(ent)
	if not IsValid(ent) or not ent:IsPlayer() or ent == LocalPlayer() then return end
	timer.Simple(0, function()
		if IsValid(ent) and not RemoteHasIdentity(ent) then
			LZY_PlyState_RequestAppearanceResync(ent)
		end
	end)
end)

-- Filet : joueur visible dont le bag n'est jamais arrivé (Full droppé, wipe
-- historique, PVS déjà ouvert). 4 sujets / s, throttle serveur 0.5 s / sujet.
timer.Create("LZY:Appearance:MissingBagFilet", 1, 0, function()
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
	RequestMissingRemoteAppearance(4)
end)

local metaPly = FindMetaTable("Player")
local metaEnt = FindMetaTable("Entity")
local rawGetNW2String = (metaPly and metaPly.GetNW2String) or (metaEnt and metaEnt.GetNW2String)
local rawGetNW2Int = (metaPly and metaPly.GetNW2Int) or (metaEnt and metaEnt.GetNW2Int)
local rawGetNW2Bool = (metaPly and metaPly.GetNW2Bool) or (metaEnt and metaEnt.GetNW2Bool)
local rawGetNW2Float = (metaPly and metaPly.GetNW2Float) or (metaEnt and metaEnt.GetNW2Float)

local function InstallEntityNW2Getter(suffix)
	local getNW2 = metaEnt["GetNW2" .. suffix]
	if not getNW2 then return end
	metaEnt["SetEvoNW" .. suffix] = function(self, key, value)
		self._EvoClientState = self._EvoClientState or {}
		self._EvoClientState[key] = value
	end
	metaEnt["GetEvoNW" .. suffix] = function(self, key, fallback)
		local bag = self._EvoClientState
		if bag and bag[key] ~= nil then return bag[key] end
		return getNW2(self, key, fallback)
	end
	if suffix == "Entity" or suffix == "Vector" or suffix == "Angle" then
		metaPly["SetEvoNW" .. suffix] = metaEnt["SetEvoNW" .. suffix]
		metaPly["GetEvoNW" .. suffix] = function(self, key, fallback)
			local bag = self._EvoClientState
			if bag and bag[key] ~= nil then return bag[key] end
			return getNW2(self, key, fallback)
		end
	end
end
for _, suffix in ipairs({ "String", "Int", "Bool", "Float", "Entity", "Vector", "Angle" }) do
	InstallEntityNW2Getter(suffix)
end

local function BagValue(ply, key)
	local def = LZY_PlyState.BY_KEY[key]
	if not def then return nil, false end
	if ply == LocalPlayer() and LZY_LocalState[key] ~= nil then
		return LZY_LocalState[key], true
	end
	if def.appearance then
		local bag = LZY_RemoteState[ply:EntIndex()]
		if bag and bag.ent == ply and bag.values[key] ~= nil then
			return bag.values[key], true
		end
	end
	return nil, false
end

local function ClientValue(ent, key)
	local bag = ent._EvoClientState
	if bag and bag[key] ~= nil then return bag[key], true end
	return nil, false
end

if metaPly and rawGetNW2String and rawGetNW2Int and rawGetNW2Bool then
	LZY_PlyState._dispatcherInstalled = true

	function metaPly:SetEvoNWString(key, value)
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "string" then
			LZY_PlyState.SetLocalPreview(key, value)
			return
		end
		self._EvoClientState = self._EvoClientState or {}
		self._EvoClientState[key] = tostring(value or "")
	end

	function metaPly:GetEvoNWString(key, fallback)
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "string" then
			local value, found = BagValue(self, key)
			if found then return tostring(value or "") end
			if self == LocalPlayer() or def.appearance then
				return isstring(fallback) and fallback or LZY_PlyState.Default(key)
			end
		end
		local localValue, localFound = ClientValue(self, key)
		if localFound then return tostring(localValue or "") end
		return rawGetNW2String(self, key, fallback)
	end

	function metaPly:SetEvoNWInt(key, value)
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "int" then
			LZY_PlyState.SetLocalPreview(key, value)
			return
		end
		self._EvoClientState = self._EvoClientState or {}
		self._EvoClientState[key] = math.floor(tonumber(value) or 0)
	end

	function metaPly:GetEvoNWInt(key, fallback)
		if EVO_HudNet and EVO_HudNet.RouteGetNW then
			local handled, value = EVO_HudNet.RouteGetNW(self, "int", key, fallback)
			if handled then return value end
		end
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "int" then
			local value, found = BagValue(self, key)
			if found then return math.floor(tonumber(value) or 0) end
			if self == LocalPlayer() or def.appearance then
				return math.floor(tonumber(fallback) or LZY_PlyState.Default(key) or 0)
			end
		end
		local localValue, localFound = ClientValue(self, key)
		if localFound then return math.floor(tonumber(localValue) or 0) end
		return rawGetNW2Int(self, key, fallback)
	end

	function metaPly:SetEvoNWBool(key, value)
		if EVO_HudNet and EVO_HudNet.COMBAT_FLAG_BIT and EVO_HudNet.COMBAT_FLAG_BIT[key] ~= nil then
			EVO_HudNet.SetLocalCombatBool(key, value)
			return
		end
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "bool" then
			LZY_PlyState.SetLocalPreview(key, value)
			return
		end
		self._EvoClientState = self._EvoClientState or {}
		self._EvoClientState[key] = value == true
	end

	function metaPly:GetEvoNWBool(key, fallback)
		if EVO_HudNet and EVO_HudNet.RouteGetNW then
			local handled, value = EVO_HudNet.RouteGetNW(self, "bool", key, fallback)
			if handled then return value end
		end
		local def = LZY_PlyState.BY_KEY[key]
		if def and def.ty == "bool" then
			local value, found = BagValue(self, key)
			if found then return value == true end
			if self == LocalPlayer() or def.appearance then return fallback == true end
		end
		local localValue, localFound = ClientValue(self, key)
		if localFound then return localValue == true end
		return rawGetNW2Bool(self, key, fallback)
	end

	if rawGetNW2Float then
		function metaPly:SetEvoNWFloat(key, value)
			local def = LZY_PlyState.BY_KEY[key]
			if def and def.ty == "float" then
				LZY_PlyState.SetLocalPreview(key, value)
				return
			end
			self._EvoClientState = self._EvoClientState or {}
			self._EvoClientState[key] = tonumber(value) or 0
		end

		function metaPly:GetEvoNWFloat(key, fallback)
			if EVO_HudNet and EVO_HudNet.RouteGetNW then
				local handled, value = EVO_HudNet.RouteGetNW(self, "float", key, fallback)
				if handled then return value end
			end
			local def = LZY_PlyState.BY_KEY[key]
			if def and def.ty == "float" then
				local value, found = BagValue(self, key)
				if found then return tonumber(value) or 0 end
				if self == LocalPlayer() or def.appearance then
					return tonumber(fallback) or LZY_PlyState.Default(key) or 0
				end
			end
			local localValue, localFound = ClientValue(self, key)
			if localFound then return tonumber(localValue) or 0 end
			return rawGetNW2Float(self, key, fallback)
		end
	end
end
