-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_loadingscreen.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local frame = nil

function PANEL:Init()
    self:SetDraggable(false)
    self:SetSizable(false)
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:gSetSize(1920, 1080)
    self:gSetPos(0, 0)
end

function PANEL:Paint(w, h)
    -- Même fond que spell selector / opts : blur monde + voile sombre (texte lisible).
    if RNDX and RNDX.Draw and RNDX.BLUR then
        RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
    elseif EVO_UI and EVO_UI.DrawBlur then
        EVO_UI.DrawBlur(self, 5)
    end
    surface.SetDrawColor(5, 5, 7, 216)
    surface.DrawRect(0, 0, w, h)

    -- Loading text with animated dots (0 -> 1 -> 2 -> 3 dots then repeat)
    local dotPhase = math.floor(CurTime() / 0.35) % 4
    local dots = string.rep(".", dotPhase)
    local loadingText = "Chargement" .. dots

    draw.SimpleText(loadingText, "DermaLarge", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PANEL:OnClose()
    frame = nil
    self:Remove()
end

vgui.Register("lzy_loadingscreen", PANEL, "DFrame")

-- Idempotent : le serveur envoie un bool explicite (show). show=true ouvre (si pas
-- déjà ouvert), show=false ferme (si ouvert). Évite le bug de l'ancien *toggle* sans
-- état où un OPEN/CLOSE manqué ou doublé inversait la parité et collait l'écran.
local function SetLoadingScreen(show)
    if show then
        if not IsValid(frame) then frame = vgui.Create("lzy_loadingscreen") end
    else
        if IsValid(frame) then frame:Close() end
        hook.Run("EVO:Client:LoadingScreenClosed")
    end
end

-- Exposé pour evo_hollow_progression (loading optimiste dès le clic Hollow).
function LZY_SetLoadingScreen(show)
    SetLoadingScreen(show == true)
end

-- true tant que "Chargement…" est affiché (cl_models gate les bakes CSM dessus).
function LZY_IsLoadingScreenOpen()
    return IsValid(frame)
end

net.Receive("EVO:Client:ToggleLoadingScreen", function()
    SetLoadingScreen(net.ReadBool())
end)

-- ── Spawn loading readiness ─────────────────────────────────────────────────
-- Ready = own CSM + inventory + skilltree + versioned appearance state. Les modeles des AUTRES joueurs ne
-- gatent plus le ready (push nearest-N serveur + RequestPM à la demande).
-- Must-fix 5 : status reporte dès que Begin est actif (panel Toggle optionnel).
-- Si Toggle droppé : Begin rouvre le panel ; serveur renvoie Toggle+Begin sans status.
local LOAD_FLAG_OWN = 1
local LOAD_FLAG_SKILLS = 2
local LOAD_FLAG_INV = 4
local LOAD_FLAG_APPEARANCE = 8
-- Aligne serveur soft : critique ~180s + marge.
local SOFT_STATUS_SECONDS = 190

local _loadReady = {
	token = 0,
	active = false,
	acked = false,
	own = false,
	inv = false,
	skills = false,
	appearance = false,
	lastSentFlags = nil,
}

local function LZY_SpawnLoad_Log(msg)
	MsgN("[LZY:SpawnLoad][CL] " .. tostring(msg))
end

local function LZY_SpawnLoad_BitsStr()
	return string.format("token=%d own=%s skills=%s inv=%s appearance=%s acked=%s panel=%s",
		_loadReady.token or 0,
		tostring(_loadReady.own), tostring(_loadReady.skills), tostring(_loadReady.inv),
		tostring(_loadReady.appearance),
		tostring(_loadReady.acked),
		tostring(LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen()))
end

local function LZY_Character_BuildLoadFlags()
	local flags = 0
	if _loadReady.own then flags = bit.bor(flags, LOAD_FLAG_OWN) end
	if _loadReady.skills then flags = bit.bor(flags, LOAD_FLAG_SKILLS) end
	if _loadReady.inv then flags = bit.bor(flags, LOAD_FLAG_INV) end
	if _loadReady.appearance then flags = bit.bor(flags, LOAD_FLAG_APPEARANCE) end
	return flags
end

local function LZY_Character_EnsureLoadingPanelOpen()
	-- Panel manquant pendant spawn loading serveur → rouvrir (Toggle droppé).
	-- NE PAS rouvrir après Ready / fin de session : Toggle(false) arrive souvent AVANT
	-- que le NWBool EVO_CharacterLoading se réplique à false → sinon Chargement… collé
	-- à vie et cl_models ne bake plus les autres joueurs.
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if not _loadReady.active or _loadReady.acked then return end
	if not lp:GetEvoNWBool("EVO_CharacterLoading", false) then return end
	if LZY_IsLoadingScreenOpen() then return end
	LZY_SpawnLoad_Log("panel reopen (Toggle dropped?) " .. LZY_SpawnLoad_BitsStr())
	if LZY_SetLoadingScreen then LZY_SetLoadingScreen(true) end
end

-- netgate: edge -- lastSentFlags dirty-check
local function LZY_Character_SendLoadStatus(force)
	if not _loadReady.active then return end
	local flags = LZY_Character_BuildLoadFlags()
	-- On bit-change only (sauf force) : évite flood CharacterLoadingStatus 2/s pendant 790s.
	if not force and _loadReady.lastSentFlags == flags then return end
	_loadReady.lastSentFlags = flags
	-- Pas de gate sur le panel : Begin suffit pour le handshake serveur.
	net.Start("EVO:Server:CharacterLoadingStatus")
		net.WriteUInt(_loadReady.token or 0, 16)
		net.WriteUInt(flags, 8)
	net.SendToServer()
end

function LZY_Character_MarkLoadingReadyFlag(flag)
	if not _loadReady.active or not flag then return end
	if _loadReady[flag] then return end
	_loadReady[flag] = true
	if flag == "own" then
		_loadReady.ownNeedsFreshCsm = false
	end
	LZY_SpawnLoad_Log("bit +" .. tostring(flag) .. " " .. LZY_SpawnLoad_BitsStr())
	LZY_Character_TryAckSpawnLoadingReady()
end

--- Serveur invalide own apres outfit/accessoires (CSM final a re-ACK).
net.Receive("EVO:Client:CharacterLoadingClearOwn", function()
	if not _loadReady.active then return end
	_loadReady.own = false
	_loadReady.acked = false
	-- Ne pas re-ACK via cache GetPlayerCharacterData (body de base encore present).
	_loadReady.ownNeedsFreshCsm = true
	LZY_SpawnLoad_Log("ClearOwn " .. LZY_SpawnLoad_BitsStr())
	LZY_Character_SendLoadStatus(true)
end)

local function LZY_Character_LoadBitsComplete()
	return _loadReady.own and _loadReady.inv and _loadReady.skills and _loadReady.appearance
end

-- Exposé pour cl_ply_state resync (évite resync hub sans session spawn).
function LZY_Character_HadSpawnLoadBits()
	return LZY_Character_LoadBitsComplete()
end

-- netgate: edge -- _loadReady.acked one-shot
function LZY_Character_TryAckSpawnLoadingReady()
	if not _loadReady.active or _loadReady.acked then return end

	LZY_Character_EnsureLoadingPanelOpen()

	local lp = LocalPlayer()
	-- Own bootstrap via cache : seulement avant ClearOwn (1er CSM / GetPMBatch).
	if not _loadReady.own and not _loadReady.ownNeedsFreshCsm then
		local d = (GetPlayerCharacterData and GetPlayerCharacterData(lp)) or nil
		if IsValid(lp) and istable(d) and d.body_model then
			_loadReady.own = true
			LZY_SpawnLoad_Log("own via cache body_model " .. LZY_SpawnLoad_BitsStr())
		end
	end

	LZY_Character_SendLoadStatus()

	if not LZY_Character_LoadBitsComplete() then
		return
	end

	_loadReady.acked = true
	LZY_SpawnLoad_Log("SEND Ready " .. LZY_SpawnLoad_BitsStr())
	net.Start("EVO:Server:CharacterLoadingReady")
		net.WriteUInt(_loadReady.token or 0, 16)
	net.SendToServer()
end

net.Receive("EVO:Client:CharacterLoadingBegin", function()
	local token = net.ReadUInt(16)
	-- Resend serveur (Must-fix 5) : meme token → ne pas wipe les bits deja acquis.
	if _loadReady.active and _loadReady.token == token then
		LZY_SpawnLoad_Log("BEGIN resend same token=" .. tostring(token) .. " " .. LZY_SpawnLoad_BitsStr())
		if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(false) end
		if LZY_SetLoadingScreen then LZY_SetLoadingScreen(true) end
		LZY_Character_SendLoadStatus(true)
		return
	end
	_loadReady = {
		token = token,
		active = true,
		acked = false,
		own = false,
		inv = false,
		skills = false,
		appearance = false,
		ownNeedsFreshCsm = false,
		lastSentFlags = nil,
	}
	LZY_SpawnLoad_Log("BEGIN token=" .. tostring(token))
	-- Spawn world : quitter le hub côté LOCAL (ne pas attendre InCharacterMenu NW).
	if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(false) end
	if LZY_SpellSelector_OnCharacterLoadingBegin then
		LZY_SpellSelector_OnCharacterLoadingBegin()
	end
	if EVO_HudNet and EVO_HudNet.OnCharacterLoadingBegin then
		EVO_HudNet.OnCharacterLoadingBegin()
	end
	hook.Run("EVO:Client:CharacterLoadingBegin", token)
	timer.Remove("LZY:SpawnLoadingSoftStop")
	-- Begin reçu = source de vérité ; rouvre Chargement même si Toggle(true) a droppé.
	if LZY_SetLoadingScreen then LZY_SetLoadingScreen(true) end

	local hid = "LZY:SpawnLoadingReadyPoll"
	timer.Create(hid, 0.5, 0, function()
		if not _loadReady.active then
			timer.Remove(hid)
			return
		end
		LZY_Character_EnsureLoadingPanelOpen()
		-- Complet : Ready + status puis stop (Ready manquant = Finish serveur rate).
		if LZY_Character_LoadBitsComplete() then
			LZY_Character_TryAckSpawnLoadingReady()
			LZY_Character_SendLoadStatus(true)
			-- Garder active=true jusqu'à LoadingScreenClosed : ClearOwn (outfit/accessoires
			-- pendant le fade) doit encore pouvoir invalider le bit own.
			timer.Remove(hid)
			timer.Remove("LZY:SpawnLoadingSoftStop")
			return
		end
		-- Soft : status seulement si bits ont change (pas flood 2/s).
		LZY_Character_SendLoadStatus(false)
		if not _loadReady.acked then
			LZY_Character_TryAckSpawnLoadingReady()
		end
	end)
end)

-- Begin droppé mais NW loading encore true : rouvre le panel (tant que !acked).
-- NW false + panel encore ouvert : orphelin (Toggle false droppé OU faux reopen NW-lag)
-- → force-close, même si _loadReady.active est déjà false après LoadingScreenClosed.
local _sawNwCharacterLoading = false
timer.Create("LZY:SpawnLoading:NwPanelRecover", 0.5, 0, function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local nwLoading = lp:GetEvoNWBool("EVO_CharacterLoading", false)
	if nwLoading then
		_sawNwCharacterLoading = true
		LZY_Character_EnsureLoadingPanelOpen()
		return
	end
	if not _sawNwCharacterLoading then return end
	_sawNwCharacterLoading = false
	if not (LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen()) then return end
	LZY_SpawnLoad_Log("panel force-close (NW loading false) " .. LZY_SpawnLoad_BitsStr())
	if LZY_SetLoadingScreen then LZY_SetLoadingScreen(false) end
end)

local function LZY_Character_RequestIdentityResyncIfMissing()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu() then return end
	local uid = lp:GetEvoNWString("Character::Unique::ID", "")
	local nick = lp:GetEvoNWString("Nickname", "")
	local faction = lp:GetEvoNWString("FactionName", "")
	if (uid ~= "" and uid ~= "none") and nick ~= "" and faction ~= "" then return end
	-- Serveur no-op si pas de perso chargé (uid none).
	LZY_SpawnLoad_Log(string.format("IdentityResync request uid=%s nick=%s faction=%s",
		uid ~= "" and uid or "?", nick ~= "" and nick or "?", faction ~= "" and faction or "?"))
	if LZY_PlyState_RequestResync then LZY_PlyState_RequestResync() end
end

hook.Add("EVO:Client:LoadingScreenClosed", "LZY:SpawnLoadingReadyClear", function()
	-- Complet : stop. Incomplet (timeout) : status soft aligne serveur (~190s).
	LZY_SpawnLoad_Log("LoadingScreenClosed " .. LZY_SpawnLoad_BitsStr())
	-- Filet : hub flag local false (NW InCharacterMenu false a pu dropper).
	if LZY_Character_SetLocalInCharMenu then LZY_Character_SetLocalInCharMenu(false) end
	-- NW identité souvent absents à la fermeture : demander immédiatement + retries.
	timer.Simple(0.2, LZY_Character_RequestIdentityResyncIfMissing)
	timer.Simple(1.0, LZY_Character_RequestIdentityResyncIfMissing)
	timer.Simple(3.0, LZY_Character_RequestIdentityResyncIfMissing)
	if LZY_Character_LoadBitsComplete() then
		_loadReady.active = false
		_loadReady.acked = true
		timer.Remove("LZY:SpawnLoadingReadyPoll")
		timer.Remove("LZY:SpawnLoadingSoftStop")
		return
	end
	timer.Create("LZY:SpawnLoadingSoftStop", SOFT_STATUS_SECONDS, 1, function()
		if LZY_Character_LoadBitsComplete() then return end
		LZY_SpawnLoad_Log("soft status window expired " .. LZY_SpawnLoad_BitsStr())
		_loadReady.active = false
		timer.Remove("LZY:SpawnLoadingReadyPoll")
	end)
end)
