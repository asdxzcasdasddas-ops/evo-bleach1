-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_tattoo_pick.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- PICKING DES TATOUAGES (créateur / tatoueur, 10/01) : point du VISAGE ou de la PEAU DU CORPS
-- sous la souris, en coordonnées de texture. Le perso est redessiné dans une petite RT avec un
-- matériau qui CODE ses UV en couleur (R = u, G = v sur 256 niveaux ; B = 255 corps, ~moitié
-- visage) ; tout le reste (vêtements, yeux, cheveux, barbe) en noir = occultant. Le pixel sous
-- le curseur est lu PENDANT le rendu 3D : la caméra du créateur est la vue moteur plein écran,
-- donc la RT (même ratio) voit exactement l'écran. Exact quelle que soit la pose ou le sculpt.
-- ============================================================================
LZY_TattooPick = LZY_TattooPick or {}
local P = LZY_TattooPick
local UV_RES = 256 -- 8 px de l'atlas 2048 par niveau : largement assez pour viser
local _req

local function uvTexture()
	local rt = GetRenderTargetEx("lzy_tatpick_uv", UV_RES, UV_RES, RT_SIZE_LITERAL, MATERIAL_RT_DEPTH_NONE,
		bit.bor(1, 4, 8, 256, 512, 32768), 0, IMAGE_FORMAT_RGBA8888) -- point sample, clamp, sans mips
	-- Re-rempli à chaque pick : le contenu d'une RT est perdu à un reset de device (alt-tab).
	render.PushRenderTarget(rt)
	render.Clear(0, 0, 0, 255)
	cam.Start2D()
		draw.NoTexture()
		for x = 0, UV_RES - 1 do
			surface.SetDrawColor(x, 0, 255, 255)
			surface.DrawRect(x, 0, 1, UV_RES)
		end
		-- Alpha 255 obligatoire : le moteur ne soumet pas un DrawRect d'alpha 0 (G resterait à 0).
		render.OverrideBlend(true, BLEND_ONE, BLEND_ONE, BLENDFUNC_ADD)
		for y = 0, UV_RES - 1 do
			surface.SetDrawColor(0, y, 0, 255)
			surface.DrawRect(0, y, UV_RES, 1)
		end
		render.OverrideBlend(false)
	cam.End2D()
	render.PopRenderTarget()
	return rt
end

-- Le rendu de modèle écrase $color par la modulation courante : le noir vient donc d'une
-- TEXTURE noire, et le visage (B ~ moitié) de render.SetColorModulation dans doPick.
local function blackTexture()
	local rt = GetRenderTargetEx("lzy_tatpick_black", 4, 4, RT_SIZE_LITERAL, MATERIAL_RT_DEPTH_NONE,
		bit.bor(1, 256, 512, 32768), 0, IMAGE_FORMAT_RGBA8888)
	render.PushRenderTarget(rt)
	render.Clear(0, 0, 0, 255)
	render.PopRenderTarget()
	return rt
end

local _mats
local function mats(rtUV)
	if not _mats then
		_mats = {
			uv = CreateMaterial("lzy_tatpick_uv", "UnlitGeneric", { ["$basetexture"] = rtUV:GetName(), ["$model"] = 1, ["$nofog"] = 1 }),
			miss = CreateMaterial("lzy_tatpick_black", "UnlitGeneric", { ["$basetexture"] = "color/white", ["$model"] = 1, ["$nofog"] = 1 }),
		}
	end
	_mats.uv:SetTexture("$basetexture", rtUV)
	_mats.miss:SetTexture("$basetexture", blackTexture())
	return _mats
end

-- Dessine ent avec le matériau UV sur l'indice iTarget, noir partout ailleurs.
local function drawTarget(ent, iTarget, mTarget, mMiss)
	if not IsValid(ent) or ent:GetNoDraw() then return end
	local n = #(ent:GetMaterials() or {})
	for i = 0, n - 1 do render.MaterialOverrideByIndex(i, i == iTarget and mTarget or mMiss) end
	ent:DrawModel()
	render.MaterialOverrideByIndex()
end

local function doPick(r)
	local rtUV = uvTexture()
	local M = mats(rtUV)
	local w = 512
	local h = math.max(64, math.floor(w * ScrH() / math.max(1, ScrW())))
	local rt = GetRenderTargetEx("lzy_tatpick_view_" .. w .. "x" .. h, w, h, RT_SIZE_LITERAL, MATERIAL_RT_DEPTH_SEPARATE,
		bit.bor(1, 256, 512, 32768), 0, IMAGE_FORMAT_RGBA8888)
	local px = math.Clamp(math.floor(r.x * w / math.max(1, ScrW())), 0, w - 1)
	local py = math.Clamp(math.floor(r.y * h / math.max(1, ScrH())), 0, h - 1)
	local cr, cg, cb = 0, 0, 0
	local oldTM = render.GetToneMappingScaleLinear and render.GetToneMappingScaleLinear()
	local oR, oG, oB = render.GetColorModulation()
	local oBlend = render.GetBlend()
	local ok, err = pcall(function()
		render.PushRenderTarget(rt)
		render.Clear(0, 0, 0, 0, true, true)
		render.SuppressEngineLighting(true)
		if oldTM then render.SetToneMappingScaleLinear(Vector(1, 1, 1)) end
		render.SetBlend(1)
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(M.miss)
		for _, e in ipairs(r.e.occluders or {}) do
			if IsValid(e) and not e:GetNoDraw() then e:DrawModel() end
		end
		render.MaterialOverride()
		local face, body = r.e.face, r.e.body
		if IsValid(body) and LZY_BodyTattoo_FindSkinIndex then
			drawTarget(body, (LZY_BodyTattoo_FindSkinIndex(body)), M.uv, M.miss)
		end
		if IsValid(face) and LZY_Character_FindLikelyFaceDiffuseSubMaterialIndex then
			render.SetColorModulation(1, 1, 0.5)
			drawTarget(face, LZY_Character_FindLikelyFaceDiffuseSubMaterialIndex(face), M.uv, M.miss)
			render.SetColorModulation(1, 1, 1)
		end
		render.CapturePixels()
		cr, cg, cb = render.ReadPixel(px, py)
	end)
	render.MaterialOverride()
	render.MaterialOverrideByIndex()
	render.SuppressEngineLighting(false)
	render.SetColorModulation(oR, oG, oB)
	render.SetBlend(oBlend)
	if oldTM then render.SetToneMappingScaleLinear(oldTM) end
	render.PopRenderTarget()
	if not ok then ErrorNoHalt("[lzy_character] pick tatouage : " .. tostring(err) .. "\n") return nil end
	cb = tonumber(cb) or 0
	if cb > 230 then
		return { kind = "body", ax = ((tonumber(cr) or 0) + 0.5) * 2048 / UV_RES, ay = ((tonumber(cg) or 0) + 0.5) * 2048 / UV_RES }
	elseif cb > 24 then -- miss = 0 exact (texture noire) ; visage 55..190 selon le gamma
		return { kind = "face", u = ((tonumber(cr) or 0) + 0.5) / UV_RES, v = ((tonumber(cg) or 0) + 0.5) / UV_RES }
	end
	return nil
end

--- Demande un pick au prochain rendu 3D. tEnts = { face, body, occluders = { ... } } ;
--- fDone(hit) avec hit = { kind = "body", ax, ay } (pixels atlas 2048) / { kind = "face", u, v } / nil.
function P.Request(tEnts, mx, my, fDone)
	if _req and _req.cb then _req.cb(nil) end -- une seule demande en vol
	_req = { e = tEnts or {}, x = mx, y = my, cb = fDone }
end

--- Pixel de l'atlas du corps -> u (autour, cyclique), v (le long) dans la zone `id` (la zone
--- de l'emplacement ne change JAMAIS au clic). Un clic sur une zone LIÉE (cou <-> torse) est
--- ramené dans `id` par la hauteur réelle. nil ailleurs. sG = "m" / "f" (géométrie).
function P.ZoneUV(id, ax, ay, sG)
	local BT = LZY_CHARACTER_CONFIG.BODY_TATTOO
	local z = BT.ZONES[id]
	if not z then return nil end
	local function inRect(r) return ax >= r[1] and ax <= r[3] and ay >= r[2] and ay <= r[4] end
	local function angle(r) return ((ax - r[1]) / ((r[3] - r[1]) * BT.MAIN_FRAC)) % 1 end
	local r = z.rect
	if inRect(r) then
		return (angle(r) - (z.uoff or 0)) % 1, math.Clamp((ay - r[2]) / (r[4] - r[2]), 0, 1)
	end
	local g = z.geo and z.geo[sG]
	for _, lid in ipairs((g and z.link) or {}) do
		local lz = BT.ZONES[lid]
		local lg = lz and lz.geo and lz.geo[sG]
		if lg and inRect(lz.rect) then
			local lr = lz.rect
			local zc = lg[1] - (ay - lr[2]) / (lr[4] - lr[2]) * (lg[1] - lg[2])
			return (angle(lr) - (z.uoff or 0)) % 1, math.Clamp((g[1] - zc) / (g[1] - g[2]), 0, 1)
		end
	end
	return nil
end

-- 3e arg = seule garde skybox fiable (2D sky : bSky reste vrai, cf. lzy_voice). Les vues eau /
-- caméras RT passent aussi ici : on attend la vue principale (cible nil), 2 passes max.
hook.Add("PostDrawTranslucentRenderables", "LZY_TattooPick", function(bDepth, _, b3DSky)
	if not _req or bDepth or b3DSky then return end
	if render.GetRenderTarget() and (_req.skips or 0) < 2 then
		_req.skips = (_req.skips or 0) + 1
		return
	end
	local r = _req
	_req = nil
	local hit = doPick(r)
	if r.cb then r.cb(hit) end
end)
