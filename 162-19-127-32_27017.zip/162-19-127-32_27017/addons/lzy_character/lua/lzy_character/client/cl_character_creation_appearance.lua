-- "addons\\lzy_character\\lua\\lzy_character\\client\\cl_character_creation_appearance.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
function PANEL:CreatePage3()
    currentPage = 3
    -- Page 3 = categories d'apparence : on zoome vers le visage.
    self.previewZoom = self.previewZoom or CHARACTER_VIEW_DISTANCE
    self.previewZoomTarget = CHARACTER_VIEW_ZOOM_FACE
    if self.currentPagePanel then
        self.currentPagePanel:Remove()
    end

    self.currentPage3SubPage = 1 -- 1: Cheveux, 2: Visage, 3: Yeux, 4: Sourcils, 5: Barbes & moustaches, 6: Tatouage

    local tattooNavY = LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) == "male" and 687 or 593
    -- Start smooth transition: left panel width 658 -> 529
    self.leftPanelWidth = 658
    self.leftPanelWidthTarget = 529

    self.currentPagePanel = vgui.Create("DPanel", self)
    self.currentPagePanel:gSetSize(1920, 1080)
    self.currentPagePanel:gSetPos(0, 0)
    self.currentPagePanel.Paint = function(selff, w, h)
        local frame = selff:GetParent()
        local panelW = frame.leftPanelWidth and frame.leftPanelWidth or 529
        RNDX.DrawMaterial(0, 0, 0, gRespX(panelW), gRespY(1080), Color(255, 255, 255, 255), materials.left_panel_bg)
        RNDX.DrawMaterial(0, gRespX(40), gRespY(144), gRespX(300), gRespY(38), Color(255, 255, 255, 255), materials.apparence_txt)
        RNDX.DrawMaterial(0, gRespX(1854), gRespY(1002), gRespX(40), gRespY(40), Color(255, 255, 255, 255), materials.mouse_scroll_icon)
        draw.SimpleText("ZOOM", "Inter Bold:20", gRespX(1874), gRespY(1054), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        RNDX.DrawMaterial(0, gRespX(1854), gRespY(932), gRespX(40), gRespY(40), Color(255, 255, 255, 255), materials.mouse_left_click_icon)
        draw.SimpleText("ROTATION", "Inter Bold:20", gRespX(1874), gRespY(984), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    -- Go back button
    self.goBackButton = vgui.Create("DButton", self.currentPagePanel)
    self.goBackButton:gSetSize(60, 60)
    self.goBackButton:gSetPos(40, 40)
    self.goBackButton:SetZPos(100)
    self.goBackButton:SetText("")
    self.goBackButton.Paint = function(selff, w, h)
        if selff:IsHovered() then
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 150), materials.go_back_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.go_back_btn)
        end
    end
    self.goBackButton.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        -- Barber mode : la fleche retour ferme l'editeur (= annule l'edition)
        -- au lieu de retourner sur Page 2 qui contient des trucs non-editables
        -- ici (taille, couleur de peau, body model). En barber on n'a JAMAIS
        -- mis le pied sur Page 2 (skip dans Init), donc retour direct au monde.
        if LZY_CHARACTER_BARBER_MODE then
            self:Close()
            return
        end
        self:CreatePage2()
    end

    -- Terminer button
    self.terminerButton = vgui.Create("DButton", self.currentPagePanel)
    self.terminerButton:gSetSize(449, 81)
    self.terminerButton:gSetPos(40, 958)
    self.terminerButton:SetZPos(90)
    self.terminerButton:SetText("")
    self.terminerButton.Paint = function(selff, w, h)
        -- Barber / tatoueur / sculpteur : pas de gate nom (meme logique que Continuer page 2).
        local allow = LZY_CHARACTER_BARBER_MODE or characterNameGateAllowsProceed()
        local alpha = allow and 255 or 100
        local col = Color(255, 255, 255, alpha)
        if selff:IsHovered() and allow then
            RNDX.DrawMaterial(0, 0, 0, w, h, col, materials.terminer_btn_hover)
        else
            RNDX.DrawMaterial(0, 0, 0, w, h, col, materials.terminer_btn)
        end
    end
    self.terminerButton.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)

        -- Barber mode (addon lzy_coiffeur) ou Tattoo mode (addon lzy_tatoueur) :
        -- on saute toute la validation du nom et on route le save vers l'addon
        -- approprie. TATTOO_MODE prend la priorite (il implique BARBER_MODE).
        if LZY_CHARACTER_BARBER_MODE then
            -- Refresh bodygroups seulement si le mode edite le visage (sculpteur /
            -- tatoueur). Chez le coiffeur, BuildFaceBodygroupsStringFromEntity
            -- zeroait la string et l'ancien save full-merge la persistait.
            if (LZY_CHARACTER_TATTOO_MODE or LZY_CHARACTER_SCULPTOR_MODE) and characterData.bodygroups then
                RefreshEncodedBodygroups()
            end
            if LZY_CHARACTER_TATTOO_MODE then
                if LZY_TATOUEUR and LZY_TATOUEUR.SendSaveToServer then
                    LZY_TATOUEUR.SendSaveToServer(characterData)
                else
                    MsgC(Color(255, 80, 80), "[Tatoueur] Save fail : addon lzy_tatoueur non charge cote client.", "\n")
                end
            elseif LZY_CHARACTER_SCULPTOR_MODE then
                if LZY_SCULPTEUR and LZY_SCULPTEUR.SendSaveToServer then
                    LZY_SCULPTEUR.SendSaveToServer(characterData)
                else
                    MsgC(Color(255, 80, 80), "[Sculpteur] Save fail : addon lzy_sculpteur non charge cote client.", "\n")
                end
            elseif LZY_COIFFEUR and LZY_COIFFEUR.SendSaveToServer then
                LZY_COIFFEUR.SendSaveToServer(characterData)
            else
                MsgC(Color(255, 80, 80), "[Coiffeur] Save fail : addon lzy_coiffeur non charge cote client.", "\n")
            end
            self:Close()
            return
        end

        if not characterNamesAreFilled() then
            NotifyCharacterCreator("Renseignez au moins le prénom.")
            return
        end
        if characterNameCheckPending then return end
        if characterNameServerAvailable == nil then
            RequestCharacterNameCheckFromServer()
            NotifyCharacterCreator("Vérification du nom en cours. Réessayez dans un instant.", NOTIFY_HINT)
            return
        end
        if characterNameServerAvailable == false then
            NotifyCharacterCreator("Ce prénom et ce nom sont déjà utilisés.")
            return
        end
        -- Ensure we have an up-to-date SetBodyGroups string before sending data to the server
        if characterData.bodygroups then
            RefreshEncodedBodygroups()
        end

        -- CK recreate : UPDATE même unique_id (pas CreateCharacter).
        if LZY_CHARACTER_CK_MODE then
            local uid = tonumber(characterData.unique_id) or 0
            if uid <= 0 and istable(LZY_CHARACTER_CK_DATA) then
                uid = tonumber(LZY_CHARACTER_CK_DATA.unique_id) or 0
            end
            if uid <= 0 then
                NotifyCharacterCreator("CK invalide : personnage introuvable.")
                return
            end
            net.Start("EVO:Server:CharacterCreator:FinishCKRecreate")
            net.WriteTable(characterData)
            net.WriteInt(uid, 32)
            net.SendToServer()
            -- Même filet que la création : un nom refusé rouvre CE creator (mode CK
            -- inclus). Close() ici effaçait LZY_CHARACTER_CK_MODE avant la réponse.
            self:SetVisible(false)
            self:SetMouseInputEnabled(false)
            self:SetKeyboardInputEnabled(false)
            local pan = self
            timer.Simple(15, function()
                if not IsValid(pan) or pan:IsVisible() then return end
                pan:SetVisible(true)
                pan:SetMouseInputEnabled(true)
                pan:SetKeyboardInputEnabled(true)
                pan:MakePopup()
                NotifyCharacterCreator("Le serveur n'a pas répondu. Réessaie de valider.")
            end)
            return
        end

        -- Slot ANIMATION : uint APRÈS la table (compat clients/serveurs mixtes) — filet si
        -- `_animSlot` manque dans la table (Hueco refusait alors la création Shinigami).
        local animSlotSend = tonumber(characterData._animSlot) or 0
        -- Slots d'animation valides = ceux de la grille partagee (4/5, +6 pour le
        -- Gerant). Le serveur revalide de toute facon contre le palier du compte.
        local bSlotAnim = EVO_ANIM and EVO_ANIM.SLOT_FACTION and EVO_ANIM.SLOT_FACTION[animSlotSend] ~= nil
        if not bSlotAnim and animSlotSend ~= 4 and animSlotSend ~= 5 then animSlotSend = 0 end
        net.Start("EVO:Server:CharacterCreator:FinishCharacterCreation")
        net.WriteTable(characterData)
        net.WriteUInt(animSlotSend, 3)
        net.SendToServer()

        -- ON CACHE, ON NE FERME PAS (26/07). Avant, un :Close() ici DETRUISAIT le
        -- creator avant meme la reponse du serveur. Si celui-ci refusait le nom, le
        -- client n avait plus rien a reafficher et rouvrait un creator VIERGE : tout
        -- le personnage etait perdu, et cote Hollow c est toute la progression qui
        -- etait a refaire. Un nom interdit doit couter la correction du nom, rien de plus.
        -- Le succes ferme le creator de toute facon : les deux chemins (selection
        -- normale et finalisation Hollow) appellent LZY_CharacterCreator_ForceClose.
        self:SetVisible(false)
        self:SetMouseInputEnabled(false)
        self:SetKeyboardInputEnabled(false)

        -- FILET : si le serveur ne repond NI succes NI echec (paquet perdu, erreur Lua
        -- serveur, requete SQL qui ne revient pas), le joueur resterait devant un ecran
        -- vide avec ses mouvements bloques, sans aucun moyen de revenir. Au bout de 15 s
        -- on remontre le creator tel quel : il pourra recliquer sur Terminer.
        local pan = self
        timer.Simple(15, function()
            if not IsValid(pan) or pan:IsVisible() then return end
            pan:SetVisible(true)
            pan:SetMouseInputEnabled(true)
            pan:SetKeyboardInputEnabled(true)
            pan:MakePopup()
            NotifyCharacterCreator("Le serveur n'a pas repondu. Reessaie de valider.")
        end)
    end

    -- Cheveux button (cache en TATTOO_MODE et SCULPTOR_MODE)
    if not LZY_CHARACTER_TATTOO_MODE and not LZY_CHARACTER_SCULPTOR_MODE then
        -- Cheveux en DERNIERE position en creation normale (demande user 2026-07-17) : on le pose
        -- sur le dernier slot (tattooNavY = 687 homme / 593 femme). En mode coiffeur (BARBER) il
        -- reste EN HAUT (217) car la nav coiffeur est compactee (Cheveux / Sourcils / Barbes).
        local cheveuxY = LZY_CHARACTER_BARBER_MODE and 217 or tattooNavY
        self.cheveuxButton = vgui.Create("DButton", self.currentPagePanel)
        self.cheveuxButton:gSetSize(449, 80)
        self.cheveuxButton:gSetPos(40, cheveuxY)
        self.cheveuxButton:SetZPos(50)
        self.cheveuxButton:SetText("")
        self.cheveuxButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 1 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.cheveux_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.cheveux_btn)
            end
        end
        self.cheveuxButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage1()
        end
    end

    -- Barber mode : on cache visage / yeux / tatouage car le coiffeur ne touche
    -- qu'a la coupe (cheveux, sourcils, barbes & moustaches). On compacte la
    -- nav verticale en repositionnant sourcils + barbes a la place de visage/
    -- yeux pour eviter les trous visuels.
    -- Visage button : visible en mode normal OU en SCULPTOR_MODE.
    -- En SCULPTOR_MODE on le positionne en y=217 (place du cheveux qui est cache).
    if not LZY_CHARACTER_BARBER_MODE or LZY_CHARACTER_SCULPTOR_MODE then
        -- 1re position en creation normale (Cheveux a ete deplace tout en bas). Vaut aussi 217
        -- en SCULPTOR (Cheveux y est deja cache), donc valeur unique.
        local visageY = 217
        self.visageButton = vgui.Create("DButton", self.currentPagePanel)
        self.visageButton:gSetSize(449, 80)
        self.visageButton:gSetPos(40, visageY)
        self.visageButton:SetZPos(50)
        self.visageButton:SetText("")
        self.visageButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 2 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.visage_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.visage_btn)
            end
        end
        self.visageButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage2()
        end
    end

    -- Yeux button : visible en mode normal OU en SCULPTOR_MODE.
    -- En SCULPTOR_MODE on le positionne en y=311 (juste sous le bouton Visage).
    if not LZY_CHARACTER_BARBER_MODE or LZY_CHARACTER_SCULPTOR_MODE then
        -- 2e position en creation normale (decale d'un cran vers le haut). Identique au SCULPTOR.
        local yeuxY = 311
        self.yeuxButton = vgui.Create("DButton", self.currentPagePanel)
        self.yeuxButton:gSetSize(449, 80)
        self.yeuxButton:gSetPos(40, yeuxY)
        self.yeuxButton:SetZPos(50)
        self.yeuxButton:SetText("")
        self.yeuxButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 3 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.yeux_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.yeux_btn)
            end
        end
        self.yeuxButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage3()
        end
    end

    -- Sourcils button (cache en TATTOO_MODE et SCULPTOR_MODE — sourcils = coiffeur)
    if not LZY_CHARACTER_TATTOO_MODE and not LZY_CHARACTER_SCULPTOR_MODE then
        local sourcilsY = LZY_CHARACTER_BARBER_MODE and 311 or 405
        self.sourcilsButton = vgui.Create("DButton", self.currentPagePanel)
        self.sourcilsButton:gSetSize(449, 80)
        self.sourcilsButton:gSetPos(40, sourcilsY)
        self.sourcilsButton:SetZPos(50)
        self.sourcilsButton:SetText("")
        self.sourcilsButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 4 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.sourcils_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.sourcils_btn)
            end
        end
        self.sourcilsButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage4()
        end
    end

    -- Barbes & moustaches (cache en TATTOO_MODE et SCULPTOR_MODE)
    if not LZY_CHARACTER_TATTOO_MODE and not LZY_CHARACTER_SCULPTOR_MODE then
        local barbesY = LZY_CHARACTER_BARBER_MODE and 405 or 499
        self.barbesMoustachesButton = vgui.Create("DButton", self.currentPagePanel)
        self.barbesMoustachesButton:gSetSize(449, 80)
        self.barbesMoustachesButton:gSetPos(40, barbesY)
        self.barbesMoustachesButton:SetZPos(50)
        self.barbesMoustachesButton:SetText("")
        self.barbesMoustachesButton:SetVisible(LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) == "male")
        self.barbesMoustachesButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 5 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.barbes_moustaches_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.barbes_moustaches_btn)
            end
        end
        self.barbesMoustachesButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage5()
        end
    end

    -- Tatouage button : visible en mode normal OU en TATTOO_MODE (cache en SCULPTOR_MODE).
    if (not LZY_CHARACTER_BARBER_MODE or LZY_CHARACTER_TATTOO_MODE) and not LZY_CHARACTER_SCULPTOR_MODE then
        -- En creation normale, Tatouage remonte d'un cran (tattooNavY - 94) car Cheveux occupe
        -- desormais le dernier slot (tattooNavY). En mode TATTOO dedie il reste en haut (217).
        local tattooY = LZY_CHARACTER_TATTOO_MODE and 217 or (tattooNavY - 94)
        self.tattooButton = vgui.Create("DButton", self.currentPagePanel)
        self.tattooButton:gSetSize(449, 80)
        self.tattooButton:gSetPos(40, tattooY)
        self.tattooButton:SetZPos(50)
        self.tattooButton:SetText("")
        self.tattooButton.Paint = function(selff, w, h)
            if selff:IsHovered() or self.currentPage3SubPage == 6 then
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.tatoo_btn_hover)
            else
                RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.tatoo_btn)
            end
        end
        self.tattooButton.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            self:CreateSubPage6()
        end
    end

    -- Sculpteur seulement : slider Taille + selecteur Couleur de peau. Les autres
    -- modes barber (coiffeur/tatoueur) n'ont pas besoin de ces widgets : le scale
    -- est applique directement dans createClientsidePlayerModel maintenant.
    if LZY_CHARACTER_SCULPTOR_MODE then
        self.scaleSlider = CreateSlider(self.currentPagePanel, 40, 410, 449, 80,
            0.9, 1.1, 0.01, characterData, "scale", UpdateCharacterData, "Taille",
            materials.character_icon, 19/1.5, 34/1.5,
            materials.character_icon, 19, 34)
        self.skinColorSelector = CreateColorSelector(self.currentPagePanel, 40, 560, 449,
            characterData, "skin_color", UpdateCharacterData,
            LZY_CHARACTER_CONFIG.GetSkinColorsForFaction(characterData.faction), "Couleur de peau")
    end

    -- Dé aléatoire pour les PNJ métier (coiffeur / tatoueur) : randomise UNIQUEMENT les catégories
    -- éditables par ce métier (cf. LZY_RandomizeCharacterAppearance, qui dispatche selon
    -- BARBER/TATTOO). Placé en haut à droite du panneau gauche (60x60, comme la flèche retour).
    -- Absent en création normale (le dé y est déjà sur la page nom/genre) ET chez le CHIRURGIEN
    -- ESTHÉTIQUE (sculpteur) : aléatoire retiré à la demande user.
    if LZY_CHARACTER_BARBER_MODE and not LZY_CHARACTER_SCULPTOR_MODE then
        self.barberRandomDice = vgui.Create("DButton", self.currentPagePanel)
        -- carré responsive uniforme (même raison que le dé de la création normale)
        local bDiceSize = math.Round(60 * math.min(ScrW() / 1920, ScrH() / 1080))
        self.barberRandomDice:SetSize(bDiceSize, bDiceSize)
        self.barberRandomDice:SetPos(gRespX(425), gRespY(40))
        self.barberRandomDice:SetZPos(100)
        self.barberRandomDice:SetText("")
        self.barberRandomDice.Paint = function(selff, w, h)
            local hollow = tostring(characterData.faction) == "Hollow"
            local hov    = selff:IsHovered()
            local bg     = hollow and Color(40, 14, 16) or Color(12, 20, 42)
            local accent = hollow and Color(255, 90, 90) or Color(90, 150, 255)
            if hov then accent = hollow and Color(255, 145, 145) or Color(150, 190, 255) end
            local dot    = hollow and Color(255, 225, 225) or Color(228, 238, 255)
            draw.RoundedBox(math.Round(w * 0.18), 0, 0, w, h, accent)
            draw.RoundedBox(math.Round(w * 0.15), w * 0.04, h * 0.04, w * 0.92, h * 0.92, bg)
            -- points : x calculé sur w, y sur h (robuste même si le bouton n'est pas carré)
            local d    = math.min(w, h) * 0.15
            local loX, hiX   = w * 0.22, w * 0.63
            local loY, hiY   = h * 0.22, h * 0.63
            local ctrX, ctrY = (w - d) / 2, (h - d) / 2
            local pts = { { loX, loY }, { hiX, loY }, { ctrX, ctrY }, { loX, hiY }, { hiX, hiY } }
            local r = math.Round(d / 2)
            for _, p in ipairs(pts) do
                draw.RoundedBox(r, p[1], p[2], d, d, dot)
            end
        end
        self.barberRandomDice.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            LZY_RandomizeCharacterAppearance() -- mode-aware (ne touche que les bonnes catégories)
            -- Le slider Taille (sculpteur) ne lit pas en live -> SetValue manuel.
            if IsValid(self.scaleSlider) and self.scaleSlider.SetValue then
                self.scaleSlider:SetValue(characterData.scale)
            end
            -- Reconstruit la sous-page active pour que ses widgets reflètent les
            -- nouveaux choix (les selecteurs lisent en live, mais les sliders non).
            local sub = self.currentPage3SubPage
            if     sub == 1 and self.CreateSubPage1 then self:CreateSubPage1()
            elseif sub == 2 and self.CreateSubPage2 then self:CreateSubPage2()
            elseif sub == 3 and self.CreateSubPage3 then self:CreateSubPage3()
            elseif sub == 4 and self.CreateSubPage4 then self:CreateSubPage4()
            elseif sub == 5 and self.CreateSubPage5 then self:CreateSubPage5()
            elseif sub == 6 and self.CreateSubPage6 then self:CreateSubPage6()
            end
        end
    end

    -- Auto-open subpage selon le mode (= 1re categorie visible de la nav) :
    --   TATTOO_MODE   -> subpage 6 (Tatouage, seule categorie)
    --   SCULPTOR_MODE -> subpage 2 (Visage, en haut)
    --   BARBER_MODE   -> subpage 1 (Cheveux, reste en haut chez le coiffeur)
    --   creation normale -> subpage 2 (Visage) : Cheveux a ete deplace tout en bas.
    if LZY_CHARACTER_TATTOO_MODE then
        self:CreateSubPage6()
    elseif LZY_CHARACTER_SCULPTOR_MODE then
        self:CreateSubPage2()
    elseif LZY_CHARACTER_BARBER_MODE then
        self:CreateSubPage1()
    else
        self:CreateSubPage2()
    end
end

function PANEL:CreateSubPage1()
    self.currentPage3SubPage = 1
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self._lzyHairDetailsExpandedVisual = nil
    self._beardStyleThumbCells = nil
    self._mustacheStyleThumbCells = nil
    self._beardStyleSectionLabel = nil
    self._mustacheStyleSectionLabel = nil
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        if selff._lzyHairSnapScrollY then
            LZY_SetScrollPanelScrollYClamped(selff, selff._lzyHairSnapScrollY)
            local tgt = selff._lzyHairSnapScrollY
            local got = LZY_GetScrollPanelScrollY(selff)
            local canvas = selff:GetCanvas()
            local maxScroll = IsValid(canvas) and math.max(0, canvas:GetTall() - selff:GetTall()) or 0
            local reached = math.abs(got - tgt) <= 1 or (tgt >= maxScroll - 1 and got >= maxScroll - 1)
            selff._lzyHairSnapScrollPaints = (selff._lzyHairSnapScrollPaints or 0) - 1
            if reached or selff._lzyHairSnapScrollPaints <= 0 then
                selff._lzyHairSnapScrollY = nil
                selff._lzyHairSnapScrollPaints = nil
            end
        end
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()

    -- Barbe / moustache *styles* live on CreateSubPage5 (left nav "Barbes & moustaches"), not on this scroll.
    createColorPicker(canvas, 56, 40, 300, 230, characterData, "hair_color1", UpdateCharacterData, "Couleur 1")
    createColorPicker(canvas, 56, 290, 300, 230, characterData, "hair_color2", UpdateCharacterData, "Couleur 2")

    self.hairDetailsWrapper = vgui.Create("DPanel", canvas)
    self.hairDetailsWrapper:gSetPos(56, 540)
    self.hairDetailsWrapper:gSetSize(308, 260)
    self.hairDetailsWrapper:SetPaintBackground(false)
    createColorPicker(self.hairDetailsWrapper, 0, 0, 300, 230, characterData, "hair_details_color", UpdateCharacterData, "Détails cheveux")

    -- Gradient angle slider (label 790, track 830 — matches CreateSlider internal +40)
    self.gradientAngleSlider = CreateSlider(canvas, 56, 790, 300, 60, 0, 360, 1, characterData, "hair_gradient_angle", UpdateCharacterData, "Angle du dégradé")

    self._hairStyleThumbCells = {}
    local hairStyleLabelBox = {}
    createModelSelectionGrid({
        parent = canvas,
        labelText = "Style de cheveux",
        labelX = 57,
        labelY = 900,
        startX = 34.5,
        startY = 940,
        itemW = 180,
        itemH = 180,
        spacing = 10,
        perRow = 2,
        bottomPadding = 30,
        camLookAtOffsetZ = 30,
        camFOV = 18,
        collectHairLayoutCells = self._hairStyleThumbCells,
        collectHairStyleLabel = hairStyleLabelBox,
        mainModel = characterData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender),
        items = LZY_CHARACTER_CONFIG.GetAvailableHairStyles(characterData.gender),
        getSubModel = function(item) return item.model end,
        setSubEntitySetup = function(faceEnt, hairEnt, _item)
            ApplyHairGradientToPreview(faceEnt, hairEnt, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle, characterData.hair_details_color)
        end,
        setEntitySetup = function(ent, _item)
            if characterData.skin_color and ent.SetSkin then
                ent:SetSkin(characterData.skin_color)
            end
        end,
        isSelected = function(item) return characterData.hair_model == item.model end,
        onSelect = function(item) UpdateCharacterData("hair_model", item.model) end,
    })
    self._hairStyleSectionLabel = hairStyleLabelBox.label

    LZY_ApplyHairCheveuxPageLayout()
end

function PANEL:CreateSubPage2()
    self.currentPage3SubPage = 2
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()
    -- Nose shape 1 slider
    self.noseShape1Slider = CreateSlider(canvas, 56, 0, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Nose_shape1", UpdateCharacterData, "Inclinaison du nez")
    -- Nose shape 2 slider
    self.noseShape2Slider = CreateSlider(canvas, 56, 100, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Nose_shape2", UpdateCharacterData, "Taille du nez")
    -- Nose shape 3 slider
    self.noseShape3Slider = CreateSlider(canvas, 56, 200, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Nose_shape3", UpdateCharacterData, "Largeur du nez")
    -- Nose shape 4 slider
    self.noseShape4Slider = CreateSlider(canvas, 56, 300, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Nose_shape4", UpdateCharacterData, "Longueur du nez")

    -- Eye shape 1 slider
    self.eyeShape1Slider = CreateSlider(canvas, 56, 400, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Eye_shape1", UpdateCharacterData, "Ouverture des yeux")
    -- Eye shape 2 slider
    self.eyeShape2Slider = CreateSlider(canvas, 56, 500, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Eye_shape2", UpdateCharacterData, "Inclinaison des yeux")
    -- Eye shape 3 slider
    self.eyeShape3Slider = CreateSlider(canvas, 56, 600, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Eye_shape3", UpdateCharacterData, "Écartement des yeux")
    -- Eye shape 4 slider
    self.eyeShape4Slider = CreateSlider(canvas, 56, 700, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Eye_shape4", UpdateCharacterData, "Paupières inférieures")

    -- Mouth shape 1 slider
    self.mouthShape1Slider = CreateSlider(canvas, 56, 800, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Mouth_shape1", UpdateCharacterData, "Courbure des lèvres")
    -- Mouth shape 2 slider
    self.mouthShape2Slider = CreateSlider(canvas, 56, 900, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Mouth_shape2", UpdateCharacterData, "Inclinaison des lèvres")
    -- Mouth shape 3 slider
    self.mouthShape3Slider = CreateSlider(canvas, 56, 1000, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Mouth_shape3", UpdateCharacterData, "Largeur de la bouche")
    if IsValid(self.mouthShape3Slider) then self.mouthShape3Slider.Invert = true end -- barre inversée (demande user)
    -- Mouth shape 4 slider
    self.mouthShape4Slider = CreateSlider(canvas, 56, 1100, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Mouth_shape4", UpdateCharacterData, "Épaisseur des lèvres")

    -- Chin shape 1 slider
    self.chinShape1Slider = CreateSlider(canvas, 56, 1200, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Chin_shape1", UpdateCharacterData, "Longueur du menton")
    if IsValid(self.chinShape1Slider) then self.chinShape1Slider.Invert = true end -- barre inversée (demande user)
    -- Chin shape 2 slider
    self.chinShape2Slider = CreateSlider(canvas, 56, 1300, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Chin_shape2", UpdateCharacterData, "Largeur de la mâchoire")
    -- Chin shape 3 slider
    self.chinShape3Slider = CreateSlider(canvas, 56, 1400, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Chin_shape3", UpdateCharacterData, "Hauteur des pommettes")
    -- Chin shape 4 slider
    self.chinShape4Slider = CreateSlider(canvas, 56, 1500, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "ear_shape", UpdateCharacterData, "Taille des oreilles")
end

function PANEL:CreateSubPage3()
    local scrollDoRestore = self._lzyEyesSubPageScrollDoRestore
    local scrollRestore = self._lzyEyesSubPageScrollRestore
    self._lzyEyesSubPageScrollDoRestore = nil
    self._lzyEyesSubPageScrollRestore = nil

    self.currentPage3SubPage = 3
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()
    frame._lzyEyesPupilCanvas = canvas
    frame._lzyEyesNestedSwatchCtx = nil

    -- EN-TÊTE FIXE (ne défile pas) : la coche "Pupilles différentes" + les onglets
    -- gauche/droite restent visibles même quand on descend la grille (demande user).
    -- IMPORTANT : un DScrollPanel re-parente TOUT enfant vers son canvas (OnChildAdded ->
    -- AddItem -> SetParent(canvas)), donc un enfant du scroll DEFILE. On parente donc
    -- l'en-tête au conteneur de PAGE (frère du scroll) et on le positionne par-dessus le
    -- haut du scroll (même x=528). ZPos élevé -> dessiné au-dessus. La grille défile dessous.
    -- Largeur 430 pour laisser la scrollbar (x≈431 du scroll) cliquable.
    local pupilsSeparate = characterData.pupils_separate and true or false
    local headerH = pupilsSeparate and (PUPIL_UI_SECTION_Y0 + PUPIL_UI_TAB_H + 8) or (PUPIL_UI_CB_Y + PUPIL_UI_CB_H + 8)
    local header = vgui.Create("DPanel", self.currentPagePanel)
    header:gSetPos(528, 0)
    header:gSetSize(430, headerH)
    header:SetZPos(200)
    header:SetAlpha(0) -- fondu synchronisé avec la sous-page via self._lzyStickyHeader (Think)
    -- Nettoyage : l'en-tête n'est PAS enfant du scroll, donc scroll:Remove() ne l'enlève pas.
    -- On le lie au cycle de vie du scroll courant : quand ce scroll est retiré (changement de
    -- sous-page), on retire l'en-tête. Évite les en-têtes fantômes empilés sur les autres pages.
    self._lzyStickyHeader = header
    self.currentSubPagePanel.OnRemove = function() if IsValid(header) then header:Remove() end end
    header.Paint = function(_, pw, ph)
        -- Voile léger (60) : l'en-tête re-floute PAR-DESSUS le fond déjà assombri (150) de la
        -- sous-page -> un voile fort le rendait quasi noir. 60 le garde proche du reste.
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 60))
    end

    local cb = vgui.Create("DCheckBoxLabel", header)
    cb:gSetPos(56, 40)
    cb:SetText("Pupilles différentes (gauche / droite)")
    cb:SetValue(characterData.pupils_separate and true or false)
    cb:SetTextColor(Color(235, 237, 240))
    if cb.Label and IsValid(cb.Label) then
        cb.Label:SetFont("Inter:34") -- 30 -> 34 : « Pupilles différentes » un cran au-dessus de l'origine (38 jugé trop gros, user 2026-07-17)
        cb.Label:SetTextColor(Color(235, 237, 240))
        cb.Label:SizeToContents() -- re-mesure la boîte du label pour la nouvelle taille (sinon texte rogné)
    end

    local checkBtn = cb.Button
    if IsValid(checkBtn) then
        local bw, bh = gRespX(22), gRespY(22)
        checkBtn:SetSize(bw, bh)
        checkBtn:SetText("")

        -- Dark-theme checkbox (matches scroll / inputs ~30–40 gray)
        checkBtn.Paint = function(self, w, h)
            local on = self:GetChecked()
            local r, g, b = 32, 34, 38
            if on then
                r, g, b = 58, 62, 70
            elseif self:IsHovered() then
                r, g, b = 42, 46, 52
            end
            draw.RoundedBox(0, 0, 0, w, h, Color(r, g, b, 255))
            surface.SetDrawColor(55, 60, 68, 255)
            surface.DrawOutlinedRect(0, 0, w, h)

            if on then
                surface.SetDrawColor(240, 242, 248, 255)
                local x1, y1 = math.floor(w * 0.20), math.floor(h * 0.52)
                local x2, y2 = math.floor(w * 0.42), math.floor(h * 0.72)
                local x3, y3 = math.floor(w * 0.82), math.floor(h * 0.28)
                for k = 0, 1 do
                    surface.DrawLine(x1 + k, y1, x2 + k, y2)
                    surface.DrawLine(x2 + k, y2, x3 + k, y3)
                end
            end
        end

        checkBtn.OnChange = function(_, val)
            local want = val == true
            if characterData.pupils_separate == want then return end
            UpdateCharacterData("pupils_separate", want)
        end
    end

    cb.Paint = function() end
    -- Default DCheckBoxLabel width is tiny; label gets clipped. Sub panel is 440 wide @ 1080 ref.
    cb:gSetSize(PUPIL_UI_CB_W, PUPIL_UI_CB_H)
    cb.PerformLayout = function(self, lw, lh)
        local btn = self.Button
        local lbl = self.Label
        if not IsValid(btn) or not IsValid(lbl) then return end
        local indentPx = gRespX(PUPIL_UI_CB_LABEL_INDENT)
        btn:SetPos(0, math.max(0, math.floor((lh - btn:GetTall()) * 0.5)))
        lbl:SetPos(btn:GetWide() + indentPx, 0)
        lbl:SetSize(math.max(40, lw - btn:GetWide() - indentPx), lh)
    end
    cb:InvalidateLayout(true)

    -- Pupil styles: nested AVAILABLE_PUPILS_TEXTURES = { { {color=,path=}, ... }, ... } (style grid uses first path in each group + color swatches in table order), or legacy flat { "path", ... }.
    do
        local faceModel = characterData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
        local textures = GetPupilsTextureList(characterData.gender)
        if not textures or #textures < 1 then
            -- nothing
        elseif LZY_PupilsIsLegacyFlatList(textures) then
            local items = {}
            for i = 1, #textures do
                items[i] = { index = i - 1 }
            end
            local y0 = PUPIL_UI_SECTION_Y0
            if characterData.pupils_separate then
                -- ONGLETS gauche/droite (demande user) : un seul bloc affiche, on bascule par onglet.
                local nTabH = createPupilSideTabs(header, y0)
                local yBlock = y0 + nTabH
                local bRight = (pupilTabSide == "right")
                local sField = bRight and "pupil_right" or "pupil_left"
                createModelSelectionGrid({
                    parent = canvas,
                    labelText = bRight and "Pupille droite" or "Pupille gauche",
                    labelX = 57,
                    labelY = yBlock,
                    startX = 34.5,
                    startY = yBlock + 30,
                    itemW = 180,
                    itemH = 180,
                    spacing = 10,
                    perRow = 2,
                    bottomPadding = 20,
                    mainModel = faceModel,
                    bodygroupId = nil,
                    items = items,
                    camFocusEye = bRight and "right" or "left",
                    camLookAtOffsetZ = 0,
                    camFOV = 5,
                    pupilThumbBumpTag = "eyes_pupil",
                    setEntitySetup = function(ent, item)
                        SetEyesBodygroupToFirst(ent)
                        local path = textures[item.index + 1]
                        -- l'AUTRE oeil garde sa pupille actuelle dans la vignette (fallback : celle testee)
                        local other = bRight and characterData.pupil_left or characterData.pupil_right
                        if not isstring(other) or other == "" then other = path end
                        if bRight then
                            ApplyPupilTextureToEntity(ent, characterData.gender, other, path)
                        else
                            ApplyPupilTextureToEntity(ent, characterData.gender, path, other)
                        end
                        if characterData.skin_color and ent.GetSkin then ent:SetSkin(characterData.skin_color) end
                    end,
                    isSelected = function(item)
                        local path = textures[item.index + 1]
                        return isstring(path) and path ~= "" and characterData[sField] == path
                    end,
                    onSelect = function(item)
                        UpdateCharacterData(sField, textures[item.index + 1] or "")
                    end,
                })
            else
                createModelSelectionGrid({
                    parent = canvas,
                    labelText = "Pupilles",
                    labelX = 57,
                    labelY = y0,
                    startX = 34.5,
                    startY = y0 + 30,
                    itemW = 180,
                    itemH = 180,
                    spacing = 10,
                    perRow = 2,
                    bottomPadding = 20,
                    mainModel = faceModel,
                    bodygroupId = nil,
                    items = items,
                    camFocusEye = "left",
                    camLookAtOffsetZ = 0,
                    camFOV = 5,
                    pupilThumbBumpTag = "eyes_pupil",
                    setEntitySetup = function(ent, item)
                        SetEyesBodygroupToFirst(ent)
                        local path = textures[item.index + 1]
                        ApplyPupilTextureToEntity(ent, characterData.gender, path, path)
                        if characterData.skin_color and ent.GetSkin then ent:SetSkin(characterData.skin_color) end
                    end,
                    isSelected = function(item)
                        local path = textures[item.index + 1]
                        return isstring(path) and path ~= "" and characterData.pupils_texture == path
                    end,
                    onSelect = function(item)
                        UpdateCharacterData("pupils_texture", textures[item.index + 1] or "")
                    end,
                })
            end
        else
            local styleGroups = LZY_PupilsGetStyleGroups()
            local nStyles = #styleGroups
            if nStyles < 1 then
                -- invalid nested
            else
                local y0 = PUPIL_UI_SECTION_Y0
                local itemW, itemH, spacing, perRow = 180, 180, 10, 2
                local function gridBottomFrom(startY, nItems)
                    local rows = math.max(1, math.ceil(nItems / perRow))
                    return startY + rows * (itemH + spacing) - spacing
                end

                local styleItems = {}
                for i = 1, nStyles do
                    styleItems[#styleItems + 1] = { styleIndex = i }
                end

                if characterData.pupils_separate then
                    -- ONGLETS gauche/droite (demande user) : un seul bloc affiche, on bascule par onglet.
                    local nTabH = createPupilSideTabs(header, y0)
                    local yBlock = y0 + nTabH
                    local bRight = (pupilTabSide == "right")
                    local sField = bRight and "pupil_right" or "pupil_left"
                    local colorRowY = yBlock + PUPIL_UI_COLOR_ROW_Y_OFFSET
                    local si = LZY_PupilsStyleIndexForPath(characterData[sField]) or 1
                    local colorH = createPupilColorSwatchRow(canvas, PUPIL_UI_SWATCH_X, colorRowY, si,
                        function() return characterData[sField] end,
                        function(p) UpdateCharacterData(sField, p) end)
                    local startY = colorRowY + colorH + PUPIL_UI_GRID_GAP_BELOW_COLOR
                    createModelSelectionGrid({
                        parent = canvas,
                        labelText = bRight and "Pupille droite" or "Pupille gauche",
                        labelX = 57,
                        labelY = yBlock,
                        startX = 34.5,
                        startY = startY,
                        itemW = itemW,
                        itemH = itemH,
                        spacing = spacing,
                        perRow = perRow,
                        bottomPadding = 48,
                        mainModel = faceModel,
                        bodygroupId = nil,
                        items = styleItems,
                        camFocusEye = bRight and "right" or "left",
                        camLookAtOffsetZ = 0,
                        camFOV = 5,
                        pupilThumbBumpTag = "eyes_pupil",
                        setEntitySetup = function(ent, item)
                            SetEyesBodygroupToFirst(ent)
                            local wp = LZY_PupilsGetFirstPathForStyleIndex(item.styleIndex)
                            if not wp then return end
                            local sidePath = wp
                            if (LZY_PupilsStyleIndexForPath(characterData[sField]) or 1) == item.styleIndex then
                                sidePath = characterData[sField]
                            end
                            if not isstring(sidePath) or sidePath == "" then sidePath = wp end
                            -- l'AUTRE oeil garde sa pupille actuelle dans la vignette (fallback : style teste)
                            local other = bRight and characterData.pupil_left or characterData.pupil_right
                            if not isstring(other) or other == "" then other = wp end
                            if bRight then
                                ApplyPupilTextureToEntity(ent, characterData.gender, other, sidePath)
                            else
                                ApplyPupilTextureToEntity(ent, characterData.gender, sidePath, other)
                            end
                            if characterData.skin_color and ent.GetSkin then ent:SetSkin(characterData.skin_color) end
                        end,
                        isSelected = function(item)
                            return ((LZY_PupilsStyleIndexForPath(characterData[sField]) or 1) == item.styleIndex)
                        end,
                        onSelect = function(item)
                            local wp = LZY_PupilsPathForNewStyleKeepingColor(characterData[sField], item.styleIndex)
                            if wp then
                                UpdateCharacterData(sField, wp)
                            end
                        end,
                    })
                    frame._lzyEyesNestedSwatchCtx = {
                        canvas = canvas,
                        separate = true,
                        side = pupilTabSide,
                        sideY = colorRowY,
                        combinedY = nil,
                    }
                else
                    local colorRowY = y0 + PUPIL_UI_COLOR_ROW_Y_OFFSET
                    local si = LZY_PupilsStyleIndexForPath(characterData.pupils_texture) or 1
                    local colorH = createPupilColorSwatchRow(canvas, PUPIL_UI_SWATCH_X, colorRowY, si,
                        function() return characterData.pupils_texture end,
                        function(p) UpdateCharacterData("pupils_texture", p) end)
                    local startY = colorRowY + colorH + PUPIL_UI_GRID_GAP_BELOW_COLOR
                    createModelSelectionGrid({
                        parent = canvas,
                        labelText = "Pupilles",
                        labelX = 57,
                        labelY = y0,
                        startX = 34.5,
                        startY = startY,
                        itemW = itemW,
                        itemH = itemH,
                        spacing = spacing,
                        perRow = perRow,
                        bottomPadding = 40,
                        mainModel = faceModel,
                        bodygroupId = nil,
                        items = styleItems,
                        camFocusEye = "left",
                        camLookAtOffsetZ = 0,
                        camFOV = 5,
                        pupilThumbBumpTag = "eyes_pupil",
                        setEntitySetup = function(ent, item)
                            SetEyesBodygroupToFirst(ent)
                            local wp = LZY_PupilsGetFirstPathForStyleIndex(item.styleIndex)
                            if not wp then return end
                            local tex = wp
                            if (LZY_PupilsStyleIndexForPath(characterData.pupils_texture) or 1) == item.styleIndex then
                                tex = characterData.pupils_texture
                            end
                            if not isstring(tex) or tex == "" then tex = wp end
                            ApplyPupilTextureToEntity(ent, characterData.gender, tex, tex)
                            if characterData.skin_color and ent.GetSkin then ent:SetSkin(characterData.skin_color) end
                        end,
                        isSelected = function(item)
                            return ((LZY_PupilsStyleIndexForPath(characterData.pupils_texture) or 1) == item.styleIndex)
                        end,
                        onSelect = function(item)
                            local wp = LZY_PupilsPathForNewStyleKeepingColor(characterData.pupils_texture, item.styleIndex)
                            if wp then
                                UpdateCharacterData("pupils_texture", wp)
                            end
                        end,
                    })
                    frame._lzyEyesNestedSwatchCtx = {
                        canvas = canvas,
                        separate = false,
                        leftY = nil,
                        rightY = nil,
                        combinedY = colorRowY,
                    }
                end
            end
        end
    end

    -- After pupil refresh rebuild, put scroll back (new panel lays out later; single-tick SetScroll clamps to 0).
    if scrollDoRestore and IsValid(self.currentSubPagePanel) then
        LZY_RestoreScrollPanelScrollDeferred(self.currentSubPagePanel, scrollRestore or 0)
    end
end

function PANEL:CreateSubPage4()
    self.currentPage3SubPage = 4
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()

    self.eyebrowsThicknessSlider = CreateSlider(canvas, 56, 0, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Thickness", UpdateCharacterData, "Épaisseur")
    self.eyebrowsLengthSlider = CreateSlider(canvas, 56, 100, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Length", UpdateCharacterData, "Longueur")
    self.eyebrowsShape1Slider = CreateSlider(canvas, 56, 200, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Serious_R", UpdateCharacterData, "Sérieux droit")
    self.eyebrowsShape2Slider = CreateSlider(canvas, 56, 300, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Serious_L", UpdateCharacterData, "Sérieux gauche")
    self.eyebrowsShape3Slider = CreateSlider(canvas, 56, 400, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Sad_R", UpdateCharacterData, "Triste droit")
    self.eyebrowsShape4Slider = CreateSlider(canvas, 56, 500, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Sad_L", UpdateCharacterData, "Triste gauche")
    self.eyebrowsShape5Slider = CreateSlider(canvas, 56, 600, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Happy_R", UpdateCharacterData, "Heureux droit")
    self.eyebrowsShape6Slider = CreateSlider(canvas, 56, 700, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Happy_L", UpdateCharacterData, "Heureux gauche")
    self.eyebrowsShape7Slider = CreateSlider(canvas, 56, 800, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Angry_R", UpdateCharacterData, "Colère droit")
    self.eyebrowsShape8Slider = CreateSlider(canvas, 56, 900, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Angry_L", UpdateCharacterData, "Colère gauche")
    self.eyebrowsShape9Slider = CreateSlider(canvas, 56, 1000, 300, 60, 0, 1, 0.01, characterData.shapeKeysByName, "Down", UpdateCharacterData, "Position")
end

function PANEL:CreateSubPage5()
    self.currentPage3SubPage = 5
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()

    if LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) ~= "male" then
        local lbl = vgui.Create("DLabel", canvas)
        lbl:gSetPos(56, 40)
        lbl:SetSize(360, 40)
        lbl:SetText("Non disponible pour ce personnage.")
        lbl:SetTextColor(Color(235, 237, 240))
        lbl:SetFont("Inter:30")
        return
    end

    local beardLabelY = 40
    local beardStartY = 80
    self._beardStyleThumbCells = {}
    local beardLabelBox = {}
    createModelSelectionGrid({
        parent = canvas,
        labelText = "Barbe",
        labelX = 57,
        labelY = beardLabelY,
        startX = 34.5,
        startY = beardStartY,
        itemW = 180,
        itemH = 180,
        spacing = 10,
        perRow = 2,
        bottomPadding = 30,
        camLookAtOffsetZ = 28,
        camFOV = 16,
        collectHairLayoutCells = self._beardStyleThumbCells,
        collectHairStyleLabel = beardLabelBox,
        mainModel = characterData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender),
        items = LZY_CHARACTER_CONFIG.GetAvailableBeardStyles(characterData.gender),
        getSubModel = function(item)
            if item.none then return "" end
            return item.model
        end,
        setSubEntitySetup = function(faceEnt, subEnt, _item)
            if IsValid(subEnt) then
                ApplyHairGradientToPreview(faceEnt, subEnt, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle, characterData.hair_details_color)
            end
        end,
        setEntitySetup = function(ent, _item)
            if characterData.skin_color and ent.SetSkin then
                ent:SetSkin(characterData.skin_color)
            end
        end,
        isSelected = function(item)
            if item.none then
                return LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(characterData.beard_model or "") == ""
            end
            return characterData.beard_model == item.model
        end,
        onSelect = function(item)
            UpdateCharacterData("beard_model", item.none and "" or item.model)
        end,
    })
    self._beardStyleSectionLabel = beardLabelBox.label

    local beardCount = #LZY_CHARACTER_CONFIG.GetAvailableBeardStyles(characterData.gender)
    local beardBottom = LZY_ModelSelectionGridBottomY(beardCount, beardStartY, 180, 10, 2, 30)
    local mustacheLabelY = beardBottom + 24
    local mustacheStartY = mustacheLabelY + 40
    self._mustacheStyleThumbCells = {}
    local mustacheLabelBox = {}
    createModelSelectionGrid({
        parent = canvas,
        labelText = "Moustache",
        labelX = 57,
        labelY = mustacheLabelY,
        startX = 34.5,
        startY = mustacheStartY,
        itemW = 180,
        itemH = 180,
        spacing = 10,
        perRow = 2,
        bottomPadding = 30,
        camLookAtOffsetZ = 29,
        camFOV = 15,
        collectHairLayoutCells = self._mustacheStyleThumbCells,
        collectHairStyleLabel = mustacheLabelBox,
        mainModel = characterData.face_model or LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender),
        items = LZY_CHARACTER_CONFIG.GetAvailableMustacheStyles(characterData.gender),
        getSubModel = function(item)
            if item.none then return "" end
            return item.model
        end,
        setSubEntitySetup = function(faceEnt, subEnt, _item)
            if IsValid(subEnt) then
                ApplyHairGradientToPreview(faceEnt, subEnt, characterData.hair_color1, characterData.hair_color2, characterData.hair_gradient_angle, characterData.hair_details_color)
            end
        end,
        setEntitySetup = function(ent, _item)
            if characterData.skin_color and ent.SetSkin then
                ent:SetSkin(characterData.skin_color)
            end
        end,
        isSelected = function(item)
            if item.none then
                return LZY_CHARACTER_CONFIG.NormalizeFacialHairPathForMerge(characterData.mustache_model or "") == ""
            end
            return characterData.mustache_model == item.model
        end,
        onSelect = function(item)
            UpdateCharacterData("mustache_model", item.none and "" or item.model)
        end,
    })
    self._mustacheStyleSectionLabel = mustacheLabelBox.label
end

-- Underlined-tab selector for the tattoo slots (1..visibleSlots, max 2). Active tab has a white
-- bottom border. If visibleSlots < 2, a "+ Ajouter" button is appended at the end.
local function createTattooSlotTabs(parent, activeSlot, visibleSlots, onClick, onAdd)
    local container = vgui.Create("DPanel", parent)
    container:gSetPos(56, 0)
    container:gSetSize(440, 36)
    container.Paint = function() end
    local tabW = 130
    for slot = 1, visibleSlots do
        local btn = vgui.Create("DButton", container)
        btn:gSetPos((slot - 1) * tabW, 0)
        btn:gSetSize(tabW, 36)
        btn:SetText("")
        btn.Paint = function(selff, pw, ph)
            local active = (slot == activeSlot)
            local hovered = selff:IsHovered()
            local txtColor
            if active then
                txtColor = Color(255, 255, 255, 255)
            elseif hovered then
                txtColor = Color(220, 220, 220, 255)
            else
                txtColor = Color(150, 150, 150, 255)
            end
            draw.SimpleText("Tatouage " .. slot, "Inter:22", pw * 0.5, ph * 0.5 - 2, txtColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if active then
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect(12, ph - 2, pw - 24, 2)
            end
        end
        btn.DoClick = function()
            if slot ~= activeSlot and onClick then
                onClick(slot)
            end
        end
    end
    if visibleSlots < 2 then
        local addBtn = vgui.Create("DButton", container)
        addBtn:gSetPos(visibleSlots * tabW, 0)
        addBtn:gSetSize(tabW, 36)
        addBtn:SetText("")
        addBtn.Paint = function(selff, pw, ph)
            local hovered = selff:IsHovered()
            local txt = hovered and Color(120, 220, 120, 255) or Color(120, 180, 120, 220)
            draw.SimpleText("+ Ajouter", "Inter:20", pw * 0.5, ph * 0.5 - 2, txt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        addBtn.DoClick = function()
            if onAdd then onAdd() end
        end
    end
    return container
end

-- Liste déroulante dans la DA du créateur (coins droits, fond 18, contour 60, ordre conservé).
-- La liste est posée sur le panneau de PAGE (un DScrollPanel la rognerait et la ferait
-- défiler) au-dessus d'un fond invisible qui la ferme au clic. getSelected() est relu à
-- chaque image : la zone change aussi quand on place le tatouage dans l'aperçu.
local function createTattooZoneDropdown(page, parent, x, y, w, options, getSelected, onSelect)
    local function click() LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO) end
    local labels = {}
    for _, o in ipairs(options) do labels[o.id] = o.label end

    local field = vgui.Create("DButton", parent)
    field:gSetPos(x, y)
    field:gSetSize(w, 38)
    field:SetText("")
    field.Paint = function(selff, pw, ph)
        local open = IsValid(selff._catcher)
        local hov = selff:IsHovered()
        surface.SetDrawColor(18, 18, 18, 255)
        surface.DrawRect(0, 0, pw, ph)
        local o = open and 255 or (hov and 110 or 60)
        surface.SetDrawColor(o, o, o, 255)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
        draw.SimpleText(labels[getSelected()] or "", "Inter:20", gRespX(14), ph * 0.5 - 1,
            Color(255, 255, 255, (open or hov) and 255 or 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        local cx, cy, s = pw - gRespX(20), ph * 0.5, gRespX(5)
        local d = open and -1 or 1
        surface.SetDrawColor(255, 255, 255, (open or hov) and 255 or 150)
        surface.DrawLine(cx - s, cy - d * s * 0.5, cx, cy + d * s * 0.5)
        surface.DrawLine(cx, cy + d * s * 0.5, cx + s, cy - d * s * 0.5)
    end
    field.OnRemove = function(selff)
        if IsValid(selff._catcher) then selff._catcher:Remove() end
    end
    field.DoClick = function(selff)
        click()
        if IsValid(selff._catcher) then selff._catcher:Remove() return end
        local catcher = vgui.Create("DButton", page)
        catcher:SetPos(0, 0)
        catcher:SetSize(page:GetWide(), page:GetTall())
        catcher:SetZPos(300)
        catcher:SetText("")
        catcher.Paint = function() end
        catcher.DoClick = function(c) c:Remove() end
        selff._catcher = catcher

        local sx, sy = selff:LocalToScreen(0, selff:GetTall())
        local lx, ly = page:ScreenToLocal(sx, sy)
        local rowH = gRespY(30)
        local listH = math.min(#options * rowH + 2, gRespY(390), page:GetTall() - ly - gRespY(10))
        local list = vgui.Create("DScrollPanel", catcher)
        list:SetPos(lx, ly + gRespY(4))
        list:SetSize(selff:GetWide(), listH)
        list:DockPadding(1, 1, 1, 1)
        list.Paint = function(_, pw, ph)
            surface.SetDrawColor(18, 18, 18, 250)
            surface.DrawRect(0, 0, pw, ph)
            surface.SetDrawColor(60, 60, 60, 255)
            surface.DrawOutlinedRect(0, 0, pw, ph, 1)
        end
        styleScrollPanelVBar(list)
        local sCur = getSelected()
        for _, o in ipairs(options) do
            local row = list:Add("DButton")
            row:Dock(TOP)
            row:SetTall(rowH)
            row:SetText("")
            row.Paint = function(r, pw, ph)
                local sel = o.id == sCur
                local hov = r:IsHovered()
                if hov then
                    surface.SetDrawColor(255, 255, 255, 12)
                    surface.DrawRect(0, 0, pw, ph)
                end
                if sel then
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.DrawRect(0, gRespY(6), 2, ph - gRespY(12))
                end
                draw.SimpleText(o.label, "Inter:20", gRespX(14), ph * 0.5 - 1,
                    Color(255, 255, 255, sel and 255 or (hov and 220 or 150)), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            row.DoClick = function()
                click()
                if IsValid(catcher) then catcher:Remove() end
                if o.id ~= sCur then onSelect(o.id) end
            end
        end
    end
    return field
end

-- Chez le tatoueur : pose de l'aperçu, celle du créateur ou neutre (bras le long du corps).
local function createTattooPoseToggle(parent, x, y, panel)
    for i, o in ipairs({ { false, "Pose actuelle" }, { true, "Pose neutre" } }) do
        local b = vgui.Create("DButton", parent)
        b:gSetPos(x + (i - 1) * 154, y)
        b:gSetSize(146, 34)
        b:SetText("")
        b.Paint = function(selff, pw, ph)
            local sel = (panel._lzyNeutralPose == true) == o[1]
            local hov = selff:IsHovered()
            surface.SetDrawColor(18, 18, 18, 255)
            surface.DrawRect(0, 0, pw, ph)
            local c = sel and 255 or (hov and 110 or 60)
            surface.SetDrawColor(c, c, c, 255)
            surface.DrawOutlinedRect(0, 0, pw, ph, 1)
            draw.SimpleText(o[2], "Inter:20", pw * 0.5, ph * 0.5 - 1,
                Color(255, 255, 255, sel and 255 or (hov and 220 or 150)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function()
            if (panel._lzyNeutralPose == true) == o[1] then return end
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            LZY_CC_SetPreviewPose(o[1])
        end
    end
end

function PANEL:CreateSubPage6()
    self.currentPage3SubPage = 6
    if self.currentSubPagePanel then
        self.currentSubPagePanel:Remove()
    end
    self.subPageFadeAlpha = 0
    self.currentSubPagePanel = vgui.Create("DScrollPanel", self.currentPagePanel)
    self.currentSubPagePanel:gSetSize(440, 1080)
    self.currentSubPagePanel:gSetPos(528, 0)
    self.currentSubPagePanel:SetZPos(0)
    self.currentSubPagePanel:SetText("")
    self.currentSubPagePanel:SetAlpha(0)
    self.currentSubPagePanel.Paint = function(selff, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 150))
    end
    styleScrollPanelVBar(self.currentSubPagePanel)

    local canvas = self.currentSubPagePanel:GetCanvas()

    -- EN-TÊTE FIXE (ne défile pas) : les onglets Tatouage restent visibles même en
    -- descendant la grille (demande user). IMPORTANT : un DScrollPanel re-parente TOUT
    -- enfant vers son canvas (il défilerait) -> on parente au conteneur de PAGE (frère du
    -- scroll), positionné par-dessus le haut du scroll (x=528), ZPos élevé = dessus.
    local tattooHeader = vgui.Create("DPanel", self.currentPagePanel)
    tattooHeader:gSetPos(528, 0)
    tattooHeader:gSetSize(430, 50)
    tattooHeader:SetZPos(200)
    tattooHeader:SetAlpha(0) -- fondu sync avec la sous-page (self._lzyStickyHeader, Think)
    self._lzyStickyHeader = tattooHeader
    self.currentSubPagePanel.OnRemove = function()
        if IsValid(tattooHeader) then tattooHeader:Remove() end
        -- Sortie de la page Tatouage (pas une simple reconstruction) : on coupe le placement
        -- à la souris et on rend la vue visage si on était en corps entier.
        timer.Simple(0, function()
            if not IsValid(self) or (self.currentPage3SubPage == 6 and IsValid(self.currentSubPagePanel)) then return end
            if self._lzyTatCamBody and currentPage == 3 then self.previewZoomTarget = CHARACTER_VIEW_ZOOM_FACE end
            self._lzyTatCamMode, self._lzyTatCamBody, self._lzyTatOnPick, self._lzyTat = nil, nil, nil, nil
        end)
    end
    tattooHeader.Paint = function(_, pw, ph)
        RNDX.Draw(0, 0, 0, pw, ph, Color(255, 255, 255), RNDX.BLUR)
        RNDX.Draw(0, 0, 0, pw, ph, Color(0, 0, 0, 60))
    end

    -- TATOUAGES DU CORPS (10/01) : chaque emplacement est VISAGE ou une ZONE du corps
    -- (characterData.body_tattoos, entrée { k = emplacement, ... }) -> 2 tatouages au total.
    local BT = LZY_CHARACTER_CONFIG.BODY_TATTOO
    characterData.body_tattoos = istable(characterData.body_tattoos) and characterData.body_tattoos or {}
    local function bodyEntryOf(k)
        for i, e in ipairs(characterData.body_tattoos) do
            if istable(e) and tonumber(e.k) == k then return e, i end
        end
    end
    local function pushBody() UpdateCharacterData("body_tattoos", characterData.body_tattoos) end

    -- Inference du nombre de slots visibles : au moins 1, plus le slot 2 s'il est utilisé (visage
    -- OU corps) OU s'il a deja ete revele via le bouton + Ajouter (self.tattooVisibleSlots). Cap a 2.
    local function inferVisibleSlots()
        local maxUsed = 1
        if (isstring(characterData.tattoo_texture_2) and characterData.tattoo_texture_2 ~= "") or bodyEntryOf(2) then maxUsed = 2 end
        return math.min(2, math.max(maxUsed, self.tattooVisibleSlots or 1))
    end

    self.activeTattooSlot = self.activeTattooSlot or 1
    if self.activeTattooSlot > inferVisibleSlots() then self.activeTattooSlot = 1 end
    local activeSlot = self.activeTattooSlot
    local suf = (activeSlot == 1) and "" or ("_" .. activeSlot)
    local bodyEntry = bodyEntryOf(activeSlot)
    -- Caméra (visage zoomé / corps entier) : à l'ouverture et sur un choix explicite (menu,
    -- onglet) SEULEMENT. Un clic dans l'aperçu qui fait passer le tatouage du visage au corps
    -- reconstruit la page sans bouger la caméra.
    if not self._lzyTatCamMode then
        self.previewZoomTarget = bodyEntry and CHARACTER_VIEW_DISTANCE or CHARACTER_VIEW_ZOOM_FACE
        self._lzyTatCamBody = bodyEntry ~= nil -- où est la caméra (le mode, lui, suit l'emplacement)
    end
    self._lzyTatCamMode = bodyEntry and "body" or "face"

    createTattooSlotTabs(tattooHeader, activeSlot, inferVisibleSlots(), function(newSlot)
        self.activeTattooSlot = newSlot
        self._lzyTatCamMode = nil
        self:CreateSubPage6()
    end, function()
        self.tattooVisibleSlots = math.min(2, inferVisibleSlots() + 1)
        self.activeTattooSlot = self.tattooVisibleSlots
        self._lzyTatCamMode = nil
        self:CreateSubPage6()
    end)

    -- Déplace le tatouage de l'emplacement entre visage et corps (motif, couleur, opacité,
    -- rotation suivent). z/u/v = point du corps visé, px/py = point du visage visé.
    local function moveToBody(z, u, v)
        local col = characterData["tattoo_color" .. suf]
        col = istable(col) and col or {}
        characterData.body_tattoos[#characterData.body_tattoos + 1] = {
            k = activeSlot, z = z, u = u or 0.5, v = v or 0.5,
            sx = tonumber(characterData["tattoo_scale_x" .. suf]) or 1,
            sy = tonumber(characterData["tattoo_scale_y" .. suf]) or 1,
            t = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(characterData["tattoo_texture" .. suf] or ""),
            r = tonumber(characterData["tattoo_rotation" .. suf]) or 0,
            o = tonumber(characterData["tattoo_opacity" .. suf]) or 1,
            c = { r = tonumber(col.r) or 255, g = tonumber(col.g) or 255, b = tonumber(col.b) or 255 },
        }
        UpdateCharacterData("tattoo_texture" .. suf, "")
        pushBody()
    end
    local function moveToFace(px, py)
        local e, idx = bodyEntryOf(activeSlot)
        if not e then return end
        local c = istable(e.c) and e.c or {}
        table.remove(characterData.body_tattoos, idx)
        pushBody()
        UpdateCharacterData("tattoo_color" .. suf, Color(tonumber(c.r) or 255, tonumber(c.g) or 255, tonumber(c.b) or 255))
        UpdateCharacterData("tattoo_opacity" .. suf, tonumber(e.o) or 1)
        UpdateCharacterData("tattoo_rotation" .. suf, tonumber(e.r) or 0)
        if px then UpdateCharacterData("tattoo_pos", { x = px, y = py, slot = activeSlot }) end
        UpdateCharacterData("tattoo_scale", { x = tonumber(e.sx or e.s) or 1, y = tonumber(e.sy or e.s) or 1, slot = activeSlot })
        UpdateCharacterData("tattoo_texture" .. suf, e.t or "")
    end

    -- Placement direct (PANEL:LZY_TattooPlacementThink) : hit = point du visage { u, v } ou de
    -- l'atlas du corps { ax, ay } sous la souris. Le motif bouge DANS son emplacement : un clic
    -- ailleurs ne change jamais l'emplacement (user 10/02), il fait tourner le perso.
    self._lzyTatOnPick = function(hit)
        local e = bodyEntryOf(activeSlot)
        local sFace = LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(characterData["tattoo_texture" .. suf] or "")
        if not ((e and isstring(e.t) and e.t ~= "") or sFace ~= "") then return false end -- aucun motif
        if hit.kind == "body" then
            if not e then return false end
            local sG = LZY_CHARACTER_CONFIG.NormalizeGender(characterData.gender) == "female" and "f" or "m"
            local u, v = LZY_TattooPick.ZoneUV(e.z, hit.ax, hit.ay, sG)
            if not u then return false end
            e.u, e.v = u, v
            pushBody()
            return true
        end
        if e then return false end
        -- Visage : inverse de tattooPickerTranslateDXDY (cl_models), centre = 0,5 + (p - 0,5) * k + biais.
        local k = tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_TRANSLATE_STRENGTH) or 2
        local px = (hit.u - 0.5 - (tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_X) or 0)) / k + 0.5
        local py = (hit.v - 0.5 - (tonumber(LZY_CHARACTER_CONFIG.TATTOO_UV_BIAS_Y) or 0)) / k + 0.5
        UpdateCharacterData("tattoo_pos", { x = px, y = py, slot = activeSlot })
        return true
    end

    -- EMPLACEMENT : Visage ou zone du corps (ordre de la config, non trié). Choisir une zone la
    -- pose au centre ; on l'affine ensuite à la souris dans l'aperçu.
    local zoneLabel = vgui.Create("DLabel", canvas)
    zoneLabel:gSetPos(56, 60)
    zoneLabel:gSetSize(300, 40)
    zoneLabel:SetText("Emplacement")
    zoneLabel:SetFont("Inter:30")
    zoneLabel:SetTextColor(Color(255, 255, 255, 255))
    local zoneOptions = { { id = "visage", label = "Visage" } }
    for _, id in ipairs(BT.ZONE_ORDER) do
        zoneOptions[#zoneOptions + 1] = { id = id, label = BT.ZONES[id].label }
    end
    createTattooZoneDropdown(self.currentPagePanel, canvas, 56, 102, 300, zoneOptions, function()
        local e = bodyEntryOf(activeSlot)
        return e and e.z or "visage"
    end, function(id)
        local e = bodyEntryOf(activeSlot)
        if id == "visage" then
            moveToFace()
        elseif e then
            e.z, e.u, e.v = id, 0.5, 0.5
            pushBody()
        else
            moveToBody(id)
        end
        self._lzyTatCamMode = nil
        self:CreateSubPage6()
    end)

    local hint = vgui.Create("DLabel", canvas)
    hint:gSetPos(56, 150)
    hint:gSetSize(300, 66)
    hint:SetWrap(true)
    hint:SetContentAlignment(7)
    hint:SetFont("Inter:18")
    hint:SetTextColor(Color(255, 255, 255, 130))
    hint:SetText("Clique sur l'emplacement choisi dans l'aperçu pour y poser le tatouage, garde le clic enfoncé pour le déplacer, ou utilise le pad Placement.")

    local DY = 160
    if LZY_CHARACTER_TATTOO_MODE and LZY_CC_SetPreviewPose then
        createTattooPoseToggle(canvas, 56, 222, self)
        DY = DY + 48
    end
    local yGrid
    if bodyEntry then
        local function setBody(key, val)
            bodyEntry[key] = val
            pushBody()
        end
        createColorPicker(canvas, 56, 66 + DY, 300, 230, bodyEntry, "c", function(_, col)
            setBody("c", { r = col.r, g = col.g, b = col.b })
        end, "Couleur du tatouage")
        CreateSlider(canvas, 56, 304 + DY, 300, 14, 0, 1, 0.05, bodyEntry, "o", setBody, "Opacité")
        -- Pad Placement : horizontal = autour du membre (cyclique), vertical = le long. u va vers
        -- la droite du PERSO (gauche de qui le regarde) : pad inversé pour suivre ce qu'on voit.
        createTattooCrosshairPicker(canvas, 37, 384 + DY, bodyEntry, pushBody, "Placement", {
            material = materials.position_picker,
            fieldName = "body_tattoos",
            getNorm = function(e) return 1 - math.Clamp(tonumber(e.u) or 0.5, 0, 1), math.Clamp(tonumber(e.v) or 0.5, 0, 1) end,
            applyNorm = function(e, nx, ny) e.u, e.v = 1 - nx, ny end,
        })
        -- Même UI que le visage : pad Taille largeur / hauteur.
        bodyEntry.sx = bodyEntry.sx or bodyEntry.s or 1
        bodyEntry.sy = bodyEntry.sy or bodyEntry.s or 1
        createTattooScalePicker(canvas, 225, 384 + DY, bodyEntry, pushBody, "Taille", activeSlot, "sx", "sy")
        CreateSlider(canvas, 56, 596 + DY, 300, 14, 0, 360, 1, bodyEntry, "r", setBody, "Rotation")
        yGrid = 680 + DY
    else
        createColorPicker(canvas, 56, 66 + DY, 300, 230, characterData, "tattoo_color" .. suf, UpdateCharacterData, "Couleur du tatouage")
        CreateSlider(canvas, 56, 304 + DY, 300, 14, 0, 1, 0.05,
            characterData, "tattoo_opacity" .. suf, UpdateCharacterData, "Opacité")
        createTattooPositionPicker(canvas, 37, 384 + DY, characterData, UpdateCharacterData, "Placement", activeSlot)
        createTattooScalePicker(canvas, 225, 384 + DY, characterData, UpdateCharacterData, "Taille", activeSlot)
        CreateSlider(canvas, 56, 596 + DY, 300, 14, 0, 360, 1,
            characterData, "tattoo_rotation" .. suf, UpdateCharacterData, "Rotation")
        yGrid = 680 + DY
    end

    local tattooItems = { { none = true } }
    -- Faction du perso (création) ou du joueur (tatoueur) : les tatouages réservés à une autre
    -- faction (numéros Espada = Hollow) ne sont pas proposés.
    local sTattooFac = characterData.faction
    if not isstring(sTattooFac) or sTattooFac == "" then
        sTattooFac = IsValid(LocalPlayer()) and LocalPlayer():GetEvoNWString("FactionName", "") or ""
    end
    for _, path in ipairs(LZY_CHARACTER_CONFIG.AVAILABLE_TATOO_TEXTURES or {}) do
        if isstring(path) and path ~= ""
            and (not LZY_CHARACTER_CONFIG.TattooAllowedForFaction or LZY_CHARACTER_CONFIG.TattooAllowedForFaction(path, sTattooFac)) then
            tattooItems[#tattooItems + 1] = { texture = path, gridCaption = (LZY_CHARACTER_CONFIG.TATTOO_CAPTIONS or {})[path] }
        end
    end

    self._tattooStyleThumbCells = {}
    local tattooStyleLabelBox = {}
    -- Subtitle "Choisir un tatouage" sous le label "Tatouage" : opacite reduite
    -- pour qu'il soit secondaire visuellement, juste guidance utilisateur.
    -- On le pose en plus du label principal "Tatouage" cree par la grille.
    local tattooSubLabel = vgui.Create("DLabel", canvas)
    tattooSubLabel:gSetPos(57, yGrid + 38)
    tattooSubLabel:gSetSize(300, 22)
    tattooSubLabel:SetText("Choisir un tatouage")
    tattooSubLabel:SetFont("Inter:18")
    tattooSubLabel:SetTextColor(Color(255, 255, 255, 130))

    createModelSelectionGrid({
        parent = canvas,
        labelText = "Tatouage",
        labelX = 57,
        labelY = yGrid,
        startX = 34.5,
        startY = yGrid + 72,
        itemW = 180,
        itemH = 180,
        spacing = 10,
        perRow = 2,
        bottomPadding = 36,
        useTextureThumbnails = true,
        collectHairLayoutCells = self._tattooStyleThumbCells,
        collectHairStyleLabel = tattooStyleLabelBox,
        items = tattooItems,
        isSelected = function(it)
            local e = bodyEntryOf(activeSlot)
            local cur = e and (e.t or "") or LZY_CHARACTER_CONFIG.NormalizeTattooTexturePath(characterData["tattoo_texture" .. suf] or "")
            if it.none then return cur == "" end
            return cur == it.texture
        end,
        onSelect = function(it)
            local e, idx = bodyEntryOf(activeSlot)
            if e then
                if it.none then
                    -- « Aucun » vide l'emplacement : il redevient un emplacement visage libre.
                    table.remove(characterData.body_tattoos, idx)
                    pushBody()
                    self:CreateSubPage6()
                else
                    e.t = it.texture
                    pushBody()
                end
                return
            end
            UpdateCharacterData("tattoo_texture" .. suf, it.none and "" or it.texture)
        end,
    })
    self._tattooStyleSectionLabel = tattooStyleLabelBox.label
end

-- Placement direct sur l'aperçu (page Tatouage), appelé par PANEL:Think AVANT la rotation :
-- appui sur le visage / la peau = le motif s'y pose, maintenir = il suit la souris ; appui
-- dans le vide (ou sur un bouton) = rotation habituelle. Le pick répond au rendu suivant
-- (LZY_TattooPick) : la rotation attend sa réponse, traitée ici (jamais dans le hook de rendu,
-- qui reconstruirait la page et re-cuirait les RT en plein rendu). Retourne true = clic consommé.
local TAT_OCCLUDERS = { "hairEnt", "beardEnt", "mustacheEnt", "haoriEnt", "arrancarMaskEnt", "espadaEnt",
    "brassardEnt", "epauletteEnt", "divisionBodyEnt", "hollowKingCapeEnt" }

function PANEL:LZY_TattooPlacementThink(leftDown, onRightSide)
    if self.currentPage3SubPage ~= 6 or not self._lzyTatOnPick then
        self._lzyTat = nil
        return false
    end
    local st = self._lzyTat
    if st and st.hit ~= nil then
        local hit, bFirst = st.hit, st.mode == "pending"
        st.hit = nil
        local bOk = hit and self._lzyTatOnPick(hit) or false
        if bFirst then st.mode = bOk and "drag" or "rotate" end
    end
    if not leftDown then
        self._lzyTat = nil
        return false
    end
    if st then
        if st.mode == "drag" and not st.busy then
            local mx, my = gui.MousePos()
            local now = RealTime()
            if (mx ~= st.mx or my ~= st.my) and now >= st.next then
                st.mx, st.my, st.next = mx, my, now + 1 / 30
                st.busy = true
                LZY_TattooPick.Request(st.ents, mx, my, st.cb)
            end
        end
        return st.mode ~= "rotate"
    end
    local ent = self.previewModel
    if self.isRotatingPreview or not onRightSide or currentPage ~= 3 or not LZY_TattooPick or not IsValid(ent)
        or vgui.GetHoveredPanel() ~= self.currentPagePanel then
        self._lzyTat = { mode = "rotate" }
        return false
    end
    local occ = {}
    for _, sKey in ipairs(TAT_OCCLUDERS) do
        if IsValid(ent[sKey]) then occ[#occ + 1] = ent[sKey] end
    end
    for k, v in pairs(ent:GetTable()) do -- accessoires équipés (masque, lunettes : tatoueur)
        if isstring(k) and string.sub(k, 1, 10) == "_lzyAccEnt" and IsValid(v) then occ[#occ + 1] = v end
    end
    local mx, my = gui.MousePos()
    st = { mode = "pending", busy = true, mx = mx, my = my, next = RealTime() + 1 / 30,
        ents = { face = ent, body = ent.bodyEnt, occluders = occ } }
    st.cb = function(hit)
        st.busy = false
        st.hit = hit or false
    end
    self._lzyTat = st
    LZY_TattooPick.Request(st.ents, mx, my, st.cb)
    return true
end
