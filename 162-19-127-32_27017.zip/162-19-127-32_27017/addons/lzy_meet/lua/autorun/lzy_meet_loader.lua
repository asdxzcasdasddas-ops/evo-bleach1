-- "addons\\lzy_meet\\lua\\autorun\\lzy_meet_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_meet/cl_main.lua")
	include("lzy_meet/net.lua")
else
	include("lzy_meet/cl_main.lua")
end