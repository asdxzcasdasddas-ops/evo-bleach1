-- "addons\\lzy_meet\\lua\\lzy_meet\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local TRACK_DISTANCE    = 600
local TRACK_DISTANCE_SQ = TRACK_DISTANCE * TRACK_DISTANCE

local lzy_meet_hovered = nil

-- Teste si le rayon passe dans le cylindre corps entier (H=72u, R=32u) sans trace physique.
local function IsAimingAtPlayer( eyePos, eyeVec, ply )
	local feet = ply:GetPos()
	for i = 0, 7 do
		local center = feet + Vector( 0, 0, i * 10 + 4 )
		local diff   = center - eyePos
		local t      = diff:Dot( eyeVec )
		if t < 0 or t > TRACK_DISTANCE then continue end
		local closest = eyePos + eyeVec * t
		if ( center - closest ):LengthSqr() < 32 * 32 then
			return true, t
		end
	end
	return false
end

local LZY_MEET_UPDATE_INTERVAL = 0.1
local lzy_meet_nextUpdate = 0

-- Couleurs du nametag HOISTÉES (0 alloc/frame — règle projet ; elles étaient recréées à
-- chaque frame de rendu du billboard tant qu'un joueur était visé).
local COL_NAME    = Color(255, 255, 255, 255)
local COL_OUTLINE = Color(0, 0, 0, 255)
local COL_ZZZ     = Color(150, 200, 255, 255)
local COL_CLAN    = Color(224, 178, 58, 255) -- nom de clan sous le nom RP (doré, couleur « rôle » evo_clan)

hook.Add( "HUDPaint", "LzyMeet::UpdateHovered", function()
	local lp = LocalPlayer()
	if not IsValid( lp ) then lzy_meet_hovered = nil; return end
	-- Noclip cinematique force (evo_cine_noclip) : AUCUNE info joueur, nametags
	-- compris. Rendu en PostDrawEffects (3D) -> le scissor HUD ne le coupe pas.
	if EVO_CineNoclipHidden and EVO_CineNoclipHidden() then lzy_meet_hovered = nil return end

	-- CRÉATEUR / SÉLECTION DE PERSO (bug user 07/22) : la scène char-select cache les
	-- MODÈLES (PrePlayerDraw) mais pas ce nametag (rendu PostDrawEffects) -> nom flottant
	-- sur des joueurs invisibles pendant le créateur. Aucun nametag tant qu'on est au menu.
	-- Ne PAS se fier au seul NWBool : il peut arriver en retard / dropper (cf. cl_models
	-- LZY_Character_IsLocalInCharMenu) alors que le panel creator / scène HUB est déjà ouvert.
	if lp:GetEvoNWBool("InCharacterMenu", false)
		or (LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu()) then
		lzy_meet_hovered = nil
		return
	end

	-- OPÉRATION en cours (ncm_heal_bed, caméra au-dessus du patient) : le patient
	-- serait « visé » en permanence -> son nom flottait en plein milieu du mini-jeu.
	if EvoHealBed and EvoHealBed.IsOperationOpen and EvoHealBed.IsOperationOpen() then
		lzy_meet_hovered = nil
		return
	end

	-- Recalcul du joueur visé THROTTLÉ (~10Hz) : refaire le test de visée
	-- (boucle 8 points x N joueurs proches) chaque frame est inutile, ~0.1s de
	-- latence est imperceptible. lzy_meet_hovered persiste entre 2 updates et
	-- PostPlayerDraw le lit + dessine le nametag chaque frame (rendu inchangé).
	local now = CurTime()
	if now < lzy_meet_nextUpdate then return end
	lzy_meet_nextUpdate = now + LZY_MEET_UPDATE_INTERVAL

	-- eyePos = position de la CAMERA rendue (EyePos global) -> valable en cam normale
	-- ET orbitale. Pour la DIRECTION : en cam orbitale (statique, on ne bouge pas),
	-- l'aim du perso reste verrouille, donc on suit la direction de la CAMERA pour
	-- detecter qui on regarde a l'ecran. ActiveCamera == false = cam orbitale active
	-- (la cam MUGEN cede la main) ; sinon on garde l'aim du perso (cam normale).
	local eyePos = EyePos()
	local eyeVec = (lp.ActiveCamera == false) and EyeAngles():Forward() or lp:GetAimVector()
	local lp_pos = lp:GetPos()
	lzy_meet_hovered = nil
	local best_t = math.huge

	for _, candidate in player.Iterator() do
		if candidate == lp or not candidate:Alive() then continue end
		-- Pas de nametag pour les joueurs en noclip (admin/staff ou autre) : on ne
		-- les cible jamais. MoveType est networke -> fiable cote client. + EVO_StaffMode
		-- (mode staff invisible/cloak) en garde explicite (ncm_combat_system/sv_staffmode).
		if candidate:GetMoveType() == MOVETYPE_NOCLIP or candidate:GetEvoNWBool("EVO_StaffMode", false) then continue end
		-- Joueur entierement cache (blink de flashstep / invisibilite Aizen Kyoka
		-- Suigetsu / orbite Illusion Parfaite) : pas de nametag qui flotte et revele.
		if candidate:GetEvoNWBool("EVO_FullHide", false) then continue end
		-- Invisibilite assassin (Camouflage de l'Ombre) : l'entite reste solide (le trace
		-- de visee la touche) -> sans cette garde, le nom RP flottait sur du vide et
		-- REVELAIT l'assassin invisible (meme famille que les poings hakuda, fix 07/26).
		if candidate:GetEvoNWBool("NCM_IsAssassinInvisible", false) then continue end
		-- Joueur AU MENU perso (NoDraw serveur, assis au hub) : corps invisible -> jamais
		-- de nametag qui flotte sur du vide (bug user 07/22, vu depuis le créateur).
		-- InCharacterMenu appearance peut dropper false chez les OBSERVATEURS (bag remote
		-- manquant → fallback false) alors que SetNoDraw reste vrai : on lit aussi NoDraw.
		if candidate:GetEvoNWBool("InCharacterMenu", false) or candidate:GetNoDraw() then continue end
		-- Salle de portail (garganta/senkaimon) : si lui et moi sommes de part et
		-- d'autre du mur de la salle, son nametag (cam.IgnoreZ) transpercerait la
		-- salle "invisible". On ne le cible pas. Cf. EVO_Portal.PlayersSeparated.
		if EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(lp, candidate) then continue end
		-- Instance (tuto / training / etc.) : chaque joueur est isolé dans sa zone.
		-- Sans ce filtre, le nametag "???" apparaît au-dessus des autres joueurs au
		-- même endroit physique (ex. plusieurs tutos simultanés). Cf. NCM_INSTANCE.
		if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(candidate) then continue end
		if lp_pos:DistToSqr( candidate:GetPos() ) > TRACK_DISTANCE_SQ then continue end
		local hit, t = IsAimingAtPlayer( eyePos, eyeVec, candidate )
		if hit and t < best_t then
			best_t = t
			lzy_meet_hovered = candidate
		end
	end
end )

-- Nametag joueur dessine dans la passe TRANSLUCIDE (apres TOUTE la geometrie
-- opaque : monde + props + models joueurs), avec cam.IgnoreZ. Avant on dessinait
-- dans PostPlayerDraw (passe opaque) : un prop rendu apres le joueur repeignait
-- par-dessus le nom (effet "nom derriere le prop"). Ici le nom est garanti
-- au premier plan, jamais occluded par un prop.
hook.Add("PostDrawEffects", "DrawPlayerName", function()
	-- Rendu en PostDrawEffects = APRÈS le rendu des halos (la halo lib rend ici aussi, et nos
	-- hooks d'addon chargés ensuite passent après). Évite que le contour shikai / aura-vision
	-- (halo additif) ne déteigne sur le nom. cam.IgnoreZ garde le nom au premier plan.
	local ply = lzy_meet_hovered
	if not IsValid(ply) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if ply == lp then return end
	-- Double garde noclip cinematique (couvre le hovered pose juste avant le toggle).
	if EVO_CineNoclipHidden and EVO_CineNoclipHidden() then return end
	-- Double garde menu perso (couvre le délai du throttle de UpdateHovered + hovered
	-- rémanent) : rien pendant le créateur/sélection, ni sur un joueur assis au menu.
	-- Filet local (creator/HUB) : même raison que UpdateHovered — NWBool pas fiable seul.
	-- GetNoDraw : filet observateur quand InCharacterMenu remote a droppé (corps déjà caché).
	if lp:GetEvoNWBool("InCharacterMenu", false)
		or ply:GetEvoNWBool("InCharacterMenu", false)
		or ply:GetNoDraw()
		or (LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu()) then return end
	-- Masque le nom des joueurs en noclip (admin/staff ou autre) + mode staff invisible
	-- (EVO_StaffMode). Double garde avec UpdateHovered : couvre le delai du throttle (0.1s)
	-- si on passe en noclip/staff entre 2 updates.
	if ply:GetMoveType() == MOVETYPE_NOCLIP or ply:GetEvoNWBool("EVO_StaffMode", false) then return end
	-- Salle de portail : double garde (couvre le delai du throttle de UpdateHovered) —
	-- pas de nom qui transperce la salle "invisible". Cf. EVO_Portal.PlayersSeparated.
	if EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(lp, ply) then return end
	-- Instance : double garde (throttle UpdateHovered) — pas de "???" cross-instance.
	if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(ply) then return end
	if lp:GetPos():DistToSqr(ply:GetPos()) > TRACK_DISTANCE_SQ then return end

	-- Hauteur ADAPTÉE à la taille du joueur. La face.mdl a des bounds minuscules
	-- (d'où l'ancien offset fixe de 80), mais le corps réellement visible est
	-- bonemergé et suit l'échelle du squelette du joueur (GetModelScale). Pour les
	-- joueurs TRÈS GRANDS (model scale > 1), un offset fixe collait le nom à leur
	-- tête : on met donc l'offset à l'échelle du modèle -> marge constante pour tous.
	local headPos = ply:GetPos() + Vector(0, 0, 80 * (ply:GetModelScale() or 1))

	-- Direction towards the local player
	local dir = (EyePos() - headPos):Angle()
	local ang = Angle(0, dir.y, 0)

	local pos = headPos
	ang:RotateAroundAxis(ang:Right(), 90)
	ang:RotateAroundAxis(ang:Up(), -90)
	ang:RotateAroundAxis(ang:Right(), 180)

	-- Name displayed : nom RP du personnage (NWString natif "Nickname" rempli par
	-- lzy_character = "prenom nom"), PAS ply:Nick() qui lit le Public MUGEN vide et
	-- retombe sur le nom Steam. Meme source que lzy_hud / battlepass / faction / shop.
	-- Source unique : EVO_GetRPDisplayName (défini plus bas dans ce fichier) — il couvre
	-- la présentation ET le masque d'anonymat, et grise le nom quand il est anonyme.
	local name, bAnon = EVO_GetRPDisplayName(ply)

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.2)
		draw.SimpleTextOutlined(
			name,
			"Inter:40",
			0, 0,
			bAnon and EVO_GetRPAnonColor() or COL_NAME,
			TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER,
			1,
			COL_OUTLINE
		)
		-- Nom de CLAN sous le nom RP (demande user 07/14 : « comme les familles »).
		-- PRÉSENTATION OBLIGATOIRE (08/15, demande user) : fini le tag public — le clan
		-- n'est visible que si le porteur me l'a PRÉSENTÉ (menu C « Présenter son Clan »,
		-- même mécanique que le nom : BDD lzy_meet_clans + cache DoIKnowHisClan).
		-- Exception naturelle : les membres du MÊME clan voient toujours le tag entre eux.
		-- Source = NW EVO_ClanName (posée par evo_clan SyncPlayerClan). Doré discret, dans
		-- le MÊME billboard que le nom -> suit l'échelle (GetModelScale) automatiquement.
		-- EXCEPTION MASQUE (09/08) : sous masque d'anonymat le clan est CACHÉ, même pour
		-- ceux à qui il a été présenté — « Masqué / Clan X » désignerait le porteur.
		local clanName = ply:GetEvoNWString("EVO_ClanName", "")
		if ply:GetEvoNWBool("EVO_AnonMask", false) then clanName = "" end
		if clanName ~= "" then
			local bSameClan = lp:GetEvoNWString("EVO_ClanName", "") == clanName
			if not bSameClan and not (lp.DoIKnowHisClan and ply.GetUniqueID and lp:DoIKnowHisClan(ply:GetUniqueID())) then
				clanName = ""
			end
		end
		if clanName ~= "" then
			draw.SimpleTextOutlined(
				"Clan " .. clanName,
				"Inter:26",
				0, 34,
				COL_CLAN,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER,
				1,
				COL_OUTLINE
			)
		end
		-- "Zzz" AU-DESSUS DU NOM si le joueur est ALT-TAB (focus fenêtre perdu). État networké
		-- via le NWBool EVO_AltTab (cf. AltTabWatch + net "lzy_meet.SetAFK"). Rendu dans le MÊME
		-- billboard que le nom (donc "comme le nom"), avec des z de sommeil qui s'allongent + un bob.
		if ply:GetEvoNWBool("EVO_AltTab", false) then
			local t = CurTime()
			local zText = "Z" .. string.rep("z", 1 + math.floor((t * 1.2) % 3)) -- Zz / Zzz / Zzzz
			draw.SimpleTextOutlined(
				zText,
				"Inter:26",
				0, -36 + math.sin(t * 2) * 2,
				COL_ZZZ,
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER,
				1,
				COL_OUTLINE
			)
		end
	cam.End3D2D()
	cam.IgnoreZ(false)
end)

-- ============================================================
-- ALT-TAB : signale au serveur la perte / le regain de focus de la fenêtre du jeu, pour que les
-- AUTRES joueurs voient un "Zzz" au-dessus du nom (rendu ci-dessus via le NWBool EVO_AltTab).
-- Détection par poll throttlé de system.HasFocus() (fiable, couvre OnGameFocusChanged) ; envoi
-- réseau UNIQUEMENT sur changement d'état (pas de spam).
-- ============================================================
local lzy_afk_lastFocus = system.HasFocus()
local lzy_afk_nextCheck = 0
local function SendFocusState(hasFocus)
	net.Start("lzy_meet.SetAFK")
		net.WriteBool(not hasFocus)
	net.SendToServer()
end

hook.Add("Think", "LzyMeet::AltTabWatch", function()
	local now = CurTime()
	if now < lzy_afk_nextCheck then return end
	lzy_afk_nextCheck = now + 0.3

	local has = system.HasFocus()
	if has == lzy_afk_lastFocus then return end
	lzy_afk_lastFocus = has

	SendFocusState(has)  -- netgate: edge -- 0.3s throttle, focus change only
end)

-- DICT (idStr -> true) au lieu d'un array : DoIKnowHim est appelé CHAQUE FRAME dans le
-- nametag ; l'array faisait un parcours O(n) + un tostring par entrée par frame (des
-- centaines d'allocs/frame pour un perso très social). Lookup O(1), tostring fait à
-- l'insertion seulement.
local knownPlayers = {}

-- CLANS connus (08/15) : jumeau de knownPlayers — « le perso targetID m'a présenté
-- son clan ». Même structure dict (lookup O(1) chaque frame dans le nametag).
local knownClans = {}

-- Perso auquel appartient `knownPlayers` (étiquette envoyée par le serveur avec la liste).
-- nil = liste vide / d'origine inconnue. Sert au reset de fin de fichier : on ne purge que
-- si la liste vient VRAIMENT d'un autre perso, jamais sur un simple changement d'ID observé.
-- `knownClans` partage la même étiquette : les deux listes arrivent ensemble (même sync).
local _lzyMeetOwnerUID = nil

local playerMeta = FindMetaTable("Player")

function playerMeta:GetKnownPlayers()
	return knownPlayers
end

function playerMeta:AddKnownPlayer(target_character_id)
	if not target_character_id then return end
	knownPlayers[tostring(target_character_id)] = true
	-- Une rencontre ajoutée en direct AVANT d'avoir reçu la liste : on étiquette quand même,
	-- sinon `knownPlayers` serait non vide sans propriétaire connu et échapperait au reset.
	if _lzyMeetOwnerUID == nil then
		local lp = LocalPlayer()
		if IsValid(lp) then
			local uid = lp:GetEvoNWString("Character::Unique::ID", "none")
			if uid ~= "none" then _lzyMeetOwnerUID = uid end
		end
	end
end

-- ══════════════════════════════════════════════════════════════════════════════
-- NOM RP AFFICHABLE — SOURCE UNIQUE (09/08)
--
-- POURQUOI ICI : le repo avait déjà un système d'anonymat (« ??? » tant qu'on ne s'est
-- pas présenté), mais recopié à l'identique dans une douzaine de fichiers — chat, voix,
-- kill-feed, amendes, casier, soins, menu C... Le masque d'anonymat ajoute une 2e raison
-- d'être anonyme ; sans point unique, il aurait fallu la répéter partout, et un oubli
-- aurait suffi à trahir le porteur.
--
-- ⚠️ On ne touche PAS à DoIKnowHim : il reçoit un identifiant de personnage, pas une
-- entité, donc il ne peut PAS savoir ce que porte le joueur. Il reste ce qu'il est —
-- « me suis-je présenté à lui ? » — et ce helper l'utilise.
--
-- RÈGLES, dans l'ordre :
--   1. MOI : je vois toujours mon propre nom, masque ou pas.
--   2. Masque d'anonymat porté : « Masqué » pour tout le monde, MÊME pour ceux qui se
--      sont déjà présentés (sinon le masque ne protège pas de ses connaissances — donc
--      de personne d'utile). Le staff, lui, voit « Masqué (Vrai Nom) » : la modération doit
--      pouvoir sanctionner, et il peut de toute façon déjà identifier n'importe qui via
--      le panneau d'inspection et le dashboard.
--   3. Sinon : règle historique de présentation.
--
-- Renvoie (nom, bAnonyme). `bAnonyme` sert aux appelants qui veulent aussi griser.
local COL_NAME_ANON = Color(150, 152, 158, 255) -- gris éteint : « je ne sais pas qui c'est »

function EVO_GetRPDisplayName(ply)
	if not IsValid(ply) or not ply.GetEvoNWString then return "???", true end
	local rpName = ply:GetEvoNWString("Nickname", "")
	if rpName == "" then rpName = ply:Nick() end

	local lp = LocalPlayer()
	if ply == lp then return rpName, false end

	if ply:GetEvoNWBool("EVO_AnonMask", false) then
		-- IsSuperAdmin est fiable côté client ; IsStaff() ne l'est pas (table serveur).
		if IsValid(lp) and (lp:IsSuperAdmin() or lp:GetEvoNWBool("EVO_StaffMode", false)) then
			return "Masqué (" .. rpName .. ")", true
		end
		return "Masqué", true
	end

	if IsValid(lp) and lp.DoIKnowHim and ply.GetUniqueID and not lp:DoIKnowHim(ply:GetUniqueID()) then
		return "???", true
	end
	return rpName, false
end

--- Couleur à utiliser quand EVO_GetRPDisplayName a renvoyé bAnonyme.
function EVO_GetRPAnonColor() return COL_NAME_ANON end

function playerMeta:DoIKnowHim(target_character_id)
	if not target_character_id then return false end
	local targetIDStr = tostring(target_character_id)
	-- Uid "none" = AUCUN perso chargé (menu perso / créateur / transition de switch).
	-- Sans cette garde, le test « mon propre perso ? » faisait "none" == "none" -> TRUE
	-- dès que les DEUX joueurs étaient sans perso -> vrai nom (Nickname RÉMANENT de
	-- l'ancien perso) révélé au char-select/créateur, sans présentation (bug user 07/22).
	if targetIDStr == "none" then return false end
	-- C'est mon propre perso ?
	if targetIDStr == tostring(LocalPlayer():GetUniqueID()) then return true end
	return knownPlayers[targetIDStr] == true
end

-- « Ce perso m'a-t-il présenté son CLAN ? » — mêmes gardes que DoIKnowHim.
function playerMeta:DoIKnowHisClan(target_character_id)
	if not target_character_id then return false end
	local targetIDStr = tostring(target_character_id)
	if targetIDStr == "none" then return false end
	if targetIDStr == tostring(LocalPlayer():GetUniqueID()) then return true end
	return knownClans[targetIDStr] == true
end

function playerMeta:AddKnownClan(target_character_id)
	if not target_character_id then return end
	knownClans[tostring(target_character_id)] = true
	-- Même filet que AddKnownPlayer : étiqueter si la liste n'a pas encore de propriétaire.
	if _lzyMeetOwnerUID == nil then
		local lp = LocalPlayer()
		if IsValid(lp) then
			local uid = lp:GetEvoNWString("Character::Unique::ID", "none")
			if uid ~= "none" then _lzyMeetOwnerUID = uid end
		end
	end
end

net.Receive("client:lzy_meet.GetMeetPlayers", function()
	local ownerUID    = net.ReadString()
	local meetPlayers = net.ReadTable()

	-- Remplacer seulement si c'est UN AUTRE perso. Même propriétaire : fusionner,
	-- sinon un snapshot BDD pris avant un INSERT récent écrase les AddKnownPlayer
	-- de la session (« plusieurs se présentent à la suite → certains restent ??? »).
	if ownerUID ~= "" then
		if _lzyMeetOwnerUID ~= nil and _lzyMeetOwnerUID ~= ownerUID then
			knownPlayers = {}
			knownClans = {}
		end
		_lzyMeetOwnerUID = ownerUID
	end
	for _, data in ipairs(meetPlayers) do
		if data and data.target_character_id then
			knownPlayers[tostring(data.target_character_id)] = true
		end
	end
end)

net.Receive("client:lzy_meet.GetMeetClans", function()
	local ownerUID  = net.ReadString()
	local meetClans = net.ReadTable()

	if ownerUID ~= "" then
		if _lzyMeetOwnerUID ~= nil and _lzyMeetOwnerUID ~= ownerUID then
			knownPlayers = {}
			knownClans = {}
		end
		_lzyMeetOwnerUID = ownerUID
	end
	for _, data in ipairs(meetClans) do
		if data and data.target_character_id then
			knownClans[tostring(data.target_character_id)] = true
		end
	end
end)

-- RESET au CHANGEMENT DE PERSO : un perso NEUF ne doit pas hériter des rencontres de
-- l'ancien (DoIKnowHim répondrait true à tort -> vrais noms au lieu de "???").
--
-- On se base sur l'ÉTIQUETTE de la liste (_lzyMeetOwnerUID, posée par le net) et non plus
-- sur « l'ID a changé depuis la dernière frame ». L'ancienne version vidait la liste dès
-- que l'ID local bougeait ; comme la NWString de l'ID et le message de liste ne sont pas
-- ordonnés entre eux, ce reset pouvait tomber APRÈS l'arrivée de la liste et l'effacer
-- -> présentations perdues à la reconnexion.
--
-- IMPORTANT : ne PAS purger quand l'ID local est encore "none" (menu / lag NW / F8).
-- Sinon la liste syncée arrive, puis ce Think la vide avant que Character::Unique::ID
-- soit posé, et plus rien ne la redemande -> noms "???" jusqu'à une nouvelle présentation.
hook.Add("Think", "LzyMeet::ResetOnCharChange", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if _lzyMeetOwnerUID == nil then return end -- liste vide ou pas encore reçue : rien à purger
	local localUID = lp:GetEvoNWString("Character::Unique::ID", "none")
	if localUID == "none" then return end -- perso pas encore chargé côté client : garder la liste
	if _lzyMeetOwnerUID ~= localUID then
		knownPlayers = {}
		knownClans = {}
		_lzyMeetOwnerUID = nil
	end
end)

net.Receive("client:lzy_meet.AddKnownPlayer", function()
	local target_character_id = net.ReadString()
	LocalPlayer():AddKnownPlayer(target_character_id)
end)

net.Receive("client:lzy_meet.AddKnownClan", function()
	local target_character_id = net.ReadString()
	LocalPlayer():AddKnownClan(target_character_id)
end)

-- Notif "Présenter son Clan" : même règle que PresentNotif — nom RP résolu CÔTÉ
-- CLIENT (présentation + masque), et le nom de clan lu sur la NW du présentateur.
net.Receive("client:lzy_meet.PresentClanNotif", function()
	local other       = net.ReadEntity()
	local toPresenter = net.ReadBool()
	if not IsValid(other) or not other:IsPlayer() then return end
	if not MUGEN or not MUGEN.Notify then return end

	-- On me présente le clan : inscrire le clan tout de suite (pas le nom RP —
	-- « Présenter son Clan » ne révèle pas l'identité).
	if not toPresenter and other.GetUniqueID then
		local uid = other:GetUniqueID()
		if uid and uid ~= "" and uid ~= "none" then
			LocalPlayer():AddKnownClan(uid)
		end
	end

	local rpName = EVO_GetRPDisplayName(other)

	if toPresenter then
		MUGEN.Notify("Tu as présenté ton clan à " .. rpName .. ".", NOTIFY_HINT, 4)
	else
		local clanName = other:GetEvoNWString("EVO_ClanName", "")
		local sClan = (clanName ~= "") and (" (Clan " .. clanName .. ")") or ""
		MUGEN.Notify(rpName .. " t'a présenté son clan" .. sClan .. ".", NOTIFY_HINT, 4)
	end
end)

-- Notif "Se Présenter" : on résout le nom CÔTÉ CLIENT pour respecter la même règle
-- que les nametags -> vrai nom RP (NWString "Nickname"), JAMAIS le nom Steam, et
-- "???" si on ne connaît pas le joueur.
net.Receive("client:lzy_meet.PresentNotif", function()
	local other       = net.ReadEntity()
	local toPresenter = net.ReadBool()
	if not IsValid(other) or not other:IsPlayer() then return end
	if not MUGEN or not MUGEN.Notify then return end

	-- On me présente : inscrire tout de suite. AddKnownPlayer serveur et UniqueID
	-- peuvent arriver dans n'importe quel ordre ; sans ça la notif affiche « ??? ».
	if not toPresenter and other.GetUniqueID then
		local uid = other:GetUniqueID()
		if uid and uid ~= "" and uid ~= "none" then
			LocalPlayer():AddKnownPlayer(uid)
		end
	end

	-- Nom RP affichable : source UNIQUE (présentation + masque d'anonymat).
	-- Ce site recopiait la logique DoIKnowHim à la main, donc il ignorait le masque :
	-- se présenter à un masqué affichait son vrai nom dans la notification.
	local rpName = EVO_GetRPDisplayName(other)

	if toPresenter then
		-- Je suis le présentateur : je ne connais la cible QUE si on me l'a déjà
		-- présentée auparavant (se présenter à quelqu'un ne me le fait pas connaître) —
		-- le helper applique déjà cette règle.
		MUGEN.Notify("Tu t'es présenté à " .. rpName .. ".", NOTIFY_HINT, 4)
	else
		-- On vient de me présenter : je connais donc forcément ce joueur maintenant
		-- (l'AddKnownPlayer peut arriver juste après, on affiche son Nickname direct).
		MUGEN.Notify(rpName .. " s'est présenté à toi.", NOTIFY_HINT, 4)
	end
end)

-- Reconnect : cache client vidé ; si le sync post-load a raté (timing / abort),
-- re-demander la liste DB une fois l'UniqueID local posé.
local function LzyMeet_RequestSyncIfNeeded()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if LZY_IsLoadingScreenOpen and LZY_IsLoadingScreenOpen() then return end
	local uid = lp:GetEvoNWString("Character::Unique::ID", "none")
	if uid == "none" or uid == "" then return end
	if _lzyMeetOwnerUID == tostring(uid) then return end
	net.Start("lzy_meet.RequestSync")
	net.SendToServer()
end

hook.Add("EVO:Client:LoadingScreenClosed", "LzyMeet::EnsureSyncAfterLoad", function()
	timer.Simple(1.5, LzyMeet_RequestSyncIfNeeded)
	timer.Simple(3.5, LzyMeet_RequestSyncIfNeeded)
end)

hook.Add("LZY:PlyState:FullApplied", "LzyMeet::EnsureSyncOnIdentity", function()
	timer.Simple(0.25, LzyMeet_RequestSyncIfNeeded)
end)


