-- "addons\\evo_hdv\\lua\\entities\\evo_npc_hdv\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- Nametag 3D2D au-dessus du PNJ (copie du coiffeur : billboard yaw-only + IgnoreZ).
surface.CreateFont("EVO_HDV_NameTag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
	outline   = false,
})

ENT.RenderGroup = RENDERGROUP_BOTH

local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Hauteur du libellé DÉRIVÉE du modèle (+18 u au-dessus de son sommet) au lieu d'un 100 u
	-- fixe calibré sur un humanoïde : le HDV est désormais un COFFRE, bien plus bas — le texte
	-- flottait très haut au-dessus. S'adapte tout seul si le modèle rechange.
	local top = self:OBBMaxs().z
	if not isnumber(top) or top <= 0 then top = 72 end
	self.EVO_PromptZ = top + 18 -- invite (E) d'evo_npc_core au même endroit
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

	local cfg = EVO_HDV and EVO_HDV.Config or {}
	local name = cfg.NPCName or "Hôtel des ventes"
	-- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, top + 18, nil, 750, "parler") return end

	local pos = ePos + Vector(0, 0, top + 18)
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		if _tagName ~= name then
			_tagName = name
			surface.SetFont("EVO_HDV_NameTag")
			_tagTW, _tagTH = surface.GetTextSize(name)
		end
		draw.RoundedBox(0, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "EVO_HDV_NameTag", 0, 0,
			COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
