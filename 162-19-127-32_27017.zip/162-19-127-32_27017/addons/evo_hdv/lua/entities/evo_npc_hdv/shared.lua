-- "addons\\evo_hdv\\lua\\entities\\evo_npc_hdv\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- PNJ Hotel des ventes (anim simple, pas de NextBot/AI). Spawn via sv_hdv,
-- interaction E via evo_npc_core (prompt + net a distance).

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Hôtel des ventes"
ENT.Author    = "evo_hdv"
ENT.Spawnable = false -- pas dans le Q menu, spawn auto via config
ENT.AdminOnly = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsHdvNPC")
end
