-- "addons\\evo_hdv\\lua\\evo_hdv\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Hotel des ventes : config + helpers PARTAGES (le client et le serveur calculent
-- les memes predicats/taxes ; le serveur reste seul autoritaire).

EVO_HDV = EVO_HDV or {}
EVO_HDV.Config = EVO_HDV.Config or {}
local CFG = EVO_HDV.Config

-- ── Economie ─────────────────────────────────────────────────────────────────
CFG.MinPrice          = 50           -- prix de vente minimum (yens)
CFG.MaxPrice          = 50000000     -- prix de vente maximum
CFG.ListingFeePct     = 0.02         -- taxe de mise en vente (non remboursable, anti-spam)
CFG.ListingFeeMin     = 50           -- taxe plancher
CFG.CommissionPct     = 0.05         -- commission prelevee sur le prix a la vente
CFG.MaxActiveListings = 10           -- annonces actives max PAR COMPTE (steamid64)
CFG.DurationHours     = 168          -- duree d'une annonce : 7 jours, puis expiree (a recuperer)

-- Recherches : demande d'achat. Meme fourchette de prix, meme taxe de depot
-- (non remboursee), meme commission a la vente. Le prix est reserve des la
-- publication (rendu si la recherche est retiree). Une proposition escrow
-- l'exemplaire du vendeur jusqu'a acceptation, refus ou retrait.
CFG.MaxActiveWants    = 10           -- recherches actives max par compte
CFG.MaxOffersPerWant  = 8            -- propositions en attente max sur une recherche
CFG.MaxPendingOffers  = 5            -- propositions en attente max par compte (items escrow)
CFG.WantSnapshotRows  = 200          -- recherches actives max envoyees au client

-- ── Technique ────────────────────────────────────────────────────────────────
-- Sentinel drop_map des lignes inventory escrowees : la purge au boot
-- (DeleteDroppedInventoryRows) ne supprime que drop_map = <map> OU NULL,
-- donc les annonces survivent aux reboots des 2 serveurs.
CFG.EscrowMap       = "__hdv__"
CFG.MaxSnapshotRows = 400            -- annonces max envoyees au client (les plus recentes)
CFG.AvgDays         = 30             -- fenetre du prix moyen (ventes des N derniers jours)
CFG.AvgCacheSec     = 300            -- cache serveur du prix moyen (1 GROUP BY / 5 min max)
CFG.HistoryRows     = 30             -- lignes d'historique perso envoyees

-- ── "PNJ" HDV = un COFFRE (demande user 2026-07-26 : plus de marchand humanoïde) ─────
-- Même entité qu'avant (evo_npc_hdv : prompt [E], placement evo_placer) : seul le MODÈLE
-- change. Un coffre est neutre -> le MÊME sur les 2 maps (plus de branche par faction).
-- L'entité cherche une séquence d'idle et retombe sur la séquence 0 si le modèle n'en a
-- aucune (cf. entities/evo_npc_hdv/init.lua) : un prop statique ne pose donc pas de souci.
CFG.NPCModel = "models/evo/props/items/evo_efttede452hk/evo_efttede452hk.mdl"
if SERVER and not util.IsValidModel(CFG.NPCModel) then
	print("[HDV] modele dedie absent (" .. CFG.NPCModel .. ") -> fallback modele commun")
	CFG.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end
CFG.NPCSkin        = 0
CFG.NPCBodygroups  = {}
CFG.NPCScale       = 1.0
CFG.NPCName        = "Hôtel des ventes"
CFG.NPCSubtitle    = "Marché entre joueurs"
CFG.InteractDistance = 200
CFG.PromptDistance   = 160
CFG.MaxZDelta        = 200

-- Positions = coiffeur decale de 70u sur SA GAUCHE (meme regard). Z re-snappe au
-- sol par l'entity ; repositionnable in-game via evo_placer.
--
-- POURQUOI LA GAUCHE, ET POURQUOI CETTE ECRITURE. La position etait ecrite en
-- chiffres bruts, copies de evo_clan qui se pose deja a +70 sur la DROITE du
-- coiffeur : sur Hueco Mundo les deux PNJ tombaient donc au MEME point au metre
-- pres et se rentraient dedans (constat user 08/08). Un vecteur recopie a la main
-- ne dit pas d'ou il vient, donc rien ne signalait la collision.
--
-- On ecrit desormais le DECALAGE, pas le point d'arrivee : yaw+90 = la gauche du
-- coiffeur (yaw-90 = sa droite, cf. evo_clan). L'intention est lisible, la place
-- prise par le voisin aussi, et si le coiffeur bouge un jour l'HDV le suit.
--
-- La rangee, vue depuis le coiffeur, lateralement :
--     -70 = HDV   |   0 = coiffeur   |   +70 = clan (Hueco)   |   +180 = renommeur
local COIF_SEIREITEI = { Vector(-1573.928023, -11399.395728, 427.765717), 177.754608 }
local COIF_HUECO     = { Vector(2710.770752, 7953.031250, 5359.369629), 85.40 }

--- Le point situe a `dist` unites sur la GAUCHE d'un PNJ regardant `yaw`.
local function aGauche(base, yaw, dist)
	return base + Angle(0, yaw + 90, 0):Forward() * dist
end

CFG.SpawnPositions = {
	rp_seireitei_v1 = {
		{ pos = aGauche(COIF_SEIREITEI[1], COIF_SEIREITEI[2], 70), ang = Angle(0, COIF_SEIREITEI[2], 0) },
	},
	hueco_mundo_v1 = {
		{ pos = aGauche(COIF_HUECO[1], COIF_HUECO[2], 70), ang = Angle(0, COIF_HUECO[2], 0) },
	},
	gm_construct = {
		{ pos = Vector(150, -80, -135), ang = Angle(0, 90, 0) },
	},
}

-- ── Predicat vendable (regle UNIQUE, partagee UI + serveur) ──────────────────
-- Vendable = echangeable en jeu : IsItemDroppable SANS le bypass superadmin,
-- jamais un item boutique (coins), jamais un item dynamique ephemere (note/carte).
-- Le serveur ajoute en plus le refus des cosmetiques lies au compte
-- (lzy_shop_unlocks : ils seraient re-donnes au vendeur au prochain chargement).
function EVO_HDV.IsSellable(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it then return false end
	if it.evo_note or it.evo_carte or it.evo_affiche or it.evo_missive then return false end
	if item_id == "evo_livre" then return false end
	if isfunction(LZY_Shop_IsShopItem) and LZY_Shop_IsShopItem(item_id) then return false end
	if not (INVENTORY_CONFIG and INVENTORY_CONFIG.IsItemDroppable) then return false end
	return INVENTORY_CONFIG.IsItemDroppable(item_id, nil)
end

-- ── Taxes ────────────────────────────────────────────────────────────────────
function EVO_HDV.ListingFee(price)
	price = math.floor(tonumber(price) or 0)
	return math.max(CFG.ListingFeeMin, math.floor(price * CFG.ListingFeePct))
end

-- Ce que le vendeur touchera a la vente (prix - commission).
function EVO_HDV.Proceeds(price)
	price = math.floor(tonumber(price) or 0)
	return math.max(0, price - math.floor(price * CFG.CommissionPct))
end

-- ── Affichage ────────────────────────────────────────────────────────────────
EVO_HDV.RarityColors = {
	common    = Color(180, 180, 185),
	rare      = Color(80, 140, 220),
	epic      = Color(160, 90, 220),
	legendary = Color(230, 190, 80),
	mythic    = Color(207, 68, 78),
}

function EVO_HDV.RarityColor(rarity)
	return EVO_HDV.RarityColors[rarity] or Color(180, 180, 185)
end

EVO_HDV.RarityNames = {
	common = "Commun", rare = "Rare", epic = "Épique",
	legendary = "Légendaire", mythic = "Mythique",
}

-- "3j 4h" / "5h 12m" / "8m" ; nil ou <= 0 = "Expirée".
function EVO_HDV.FormatRemaining(sec)
	sec = math.floor(tonumber(sec) or 0)
	if sec <= 0 then return "Expirée" end
	local d = math.floor(sec / 86400)
	local h = math.floor((sec % 86400) / 3600)
	local m = math.floor((sec % 3600) / 60)
	if d > 0 then return string.format("%dj %dh", d, h) end
	if h > 0 then return string.format("%dh %02dm", h, m) end
	return string.format("%dm", math.max(1, m))
end

-- Lignes de stats d'un item, multipliees par le niveau de forge (comme le
-- tooltip inventaire/forge). Gere les 2 formats de `stats` (dict et array de
-- paires). Retourne { "+0.7% Degats d'arme", ... }.
function EVO_HDV.StatLines(item_id, forge_level)
	local it = ITEMS and ITEMS[item_id]
	if not it or not istable(it.stats) then return {} end
	local mult = 1
	if NCM_FORGE and NCM_FORGE.GetStatMultiplier then
		mult = NCM_FORGE.GetStatMultiplier(tonumber(forge_level) or 1)
	end
	local names = (INVENTORY_CONFIG and INVENTORY_CONFIG.STAT_DISPLAY_NAMES) or {}
	local out = {}
	local function push(key, val)
		val = tonumber(val) or 0
		val = NCM_FORGE and NCM_FORGE.ScaleItemStat and NCM_FORGE.ScaleItemStat(it, key, val, mult) or val * mult
		local baseKey = tostring(key):gsub("^e_", "")
		local reduction = baseKey == "flashstep_cd" or baseKey == "spell_cd_reduction" or baseKey == "parade_regen"
		local s = string.format("%.3f", math.abs(val)):gsub("0+$", ""):gsub("%.$", "")
		local label = names[baseKey] or tostring(key)
		out[#out + 1] = string.format("%s%s%% %s", reduction and "-" or "+", s, label)
	end
	if it.stats[1] ~= nil then
		for _, pair in ipairs(it.stats) do
			if istable(pair) and pair[1] then push(pair[1], pair[2]) end
		end
	else
		for k, v in pairs(it.stats) do push(k, v) end
	end
	return out
end

-- Sanitize : strip caracteres de controle + tronque (payloads/affichage).
function EVO_HDV.Clean(s, n)
	s = tostring(s or ""):gsub("[%z\1-\31]", "")
	if #s > (n or 64) then s = string.sub(s, 1, n or 64) end
	return s
end
