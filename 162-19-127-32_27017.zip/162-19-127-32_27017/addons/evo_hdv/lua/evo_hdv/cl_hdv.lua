-- "addons\\evo_hdv\\lua\\evo_hdv\\cl_hdv.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Hotel des ventes : UI client (VUE PURE — zero autorite, zero DB ; le serveur
-- pousse un snapshot compresse, chaque action = un net en DoClick). DA Atelier :
-- plaque coins coupes + accent rouge unique + Bebas 400 + slash d'encre.

EVO_HDV = EVO_HDV or {}
local CFG = EVO_HDV.Config

-- ── Scaler uniforme (dialogue centre) + palette DA canonique ─────────────────
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

local COL_FOND   = Color(5, 5, 7, 216)
local COL_CARD   = Color(13, 14, 17, 250)
local COL_ROW    = Color(26, 26, 32, 255)
local COL_ROW_H  = Color(36, 36, 44, 255)
local COL_FIELD  = Color(30, 31, 37)
local COL_ACC    = Color(207, 68, 78)
local COL_ACC_H  = Color(224, 92, 102, 255)
local COL_ACC_S  = Color(207, 68, 78, 45)
local COL_TXT    = Color(236, 236, 240)
local COL_DIM    = Color(150, 154, 162)
local COL_MUT    = Color(106, 109, 118)
local COL_GOLD   = Color(230, 196, 120, 255)
local COL_GREEN  = Color(90, 200, 120)
local COL_WARN   = Color(230, 180, 70)
local COL_SCROLL = Color(58, 58, 68, 220)

local F_TITLE = "Bebas Neue:36"
local F_TAB   = "Bebas Neue:23"
local F_ROW   = "Bebas Neue:22"
local F_BIG   = "Bebas Neue:30"
local F_SUB   = "EVO_UI_Sub"
local F_MONO  = "EVO_UI_Mono"
local F_X     = "Avenir Next World Bold:26"

local function rndx(r, x, y, w, h, c, fl)
	if RNDX then RNDX.Draw(r, x, y, w, h, c, fl) else draw.RoundedBox(r, x, y, w, h, c) end
end

local function hovered(pnl)
	return EVO_UI and EVO_UI.PanelContainsCursor and EVO_UI.PanelContainsCursor(pnl) or pnl:IsHovered()
end

local function trunc(s, font, maxW)
	if EVO_UI and EVO_UI.TruncText then return EVO_UI.TruncText(s, font, maxW) end
	return s
end

local function fold(s)
	if EVO_UI and EVO_UI.FoldStr then return EVO_UI.FoldStr(s) end
	return string.lower(tostring(s or ""))
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dx = x
	while dx < x + w do
		surface.DrawRect(dx, y, math.min(R(6), x + w - dx), 1)
		dx = dx + R(11)
	end
end

local function itemDef(id) return ITEMS and ITEMS[id] or nil end
local function itemName(id)
	local it = itemDef(id)
	-- Repli : jamais d'id brut a underscores a l'ecran (demande user 08/18).
	return (it and it.name) or (tostring(id):gsub("_", " "))
end

local function itemNameQty(id, q)
	local n = itemName(id)
	q = math.floor(tonumber(q) or 1)
	if q > 1 then return n .. " ×" .. q end
	return n
end

-- ── Etat ─────────────────────────────────────────────────────────────────────
EVO_HDV._snap = EVO_HDV._snap or nil
EVO_HDV._snapAt = EVO_HDV._snapAt or 0

local TAB = "buy"
local BUY_FILTER, BUY_CAT, BUY_SORT, BUY_SEL = "", "all", "recent", nil
-- Groupe acheteur : item_id deplie (UI only ; chaque annonce reste une ligne DB).
local BUY_EXPAND = nil
local SELL_SLOT = nil
local SELL_PRICE = 0
local SELL_QTY = 1
local WANT_SEL, WANT_SLOT, WANT_ITEM = nil, nil, nil
local WANT_POST = false
local WANT_PRICE, WANT_QTY, WANT_OFFER_PRICE = 0, 1, 0
local WANT_FILTER, WANT_FIND = "", ""

-- Temps restant vivant (le snapshot fige `r` a la reception).
-- Lignes d'enchantement d'une annonce ("stat:pct;...", user 08/20) : libellé +
-- couleur du boost (config partagée evo_craft). Affichage seulement, la vérité
-- reste inventory.enchant (relue à la livraison).
local function enchantLines(sEnch, item_id)
	local out = {}
	if not (isstring(sEnch) and sEnch ~= "" and INVENTORY_CONFIG and INVENTORY_CONFIG.ParseEnchantList) then
		return out
	end
	if EVO_CRAFT and EVO_CRAFT.EnchantMigrateString then
		sEnch = EVO_CRAFT.EnchantMigrateString(sEnch, item_id)
	end
	for _, e in ipairs(INVENTORY_CONFIG.ParseEnchantList(sEnch)) do
		local d = EVO_CRAFT and EVO_CRAFT.EnchantByKey and EVO_CRAFT.EnchantByKey(e.stat)
		out[#out + 1] = {
			txt = string.format("Enchantement : +%.2f%% %s", e.pct, d and d.label or e.stat),
			col = d and d.color or COL_GREEN,
		}
	end
	return out
end

local function remainingOf(l)
	return math.floor((tonumber(l.r) or 0) - (CurTime() - (EVO_HDV._snapAt or 0)))
end

local function avgOf(item_id)
	local snap = EVO_HDV._snap
	local a = snap and snap.avg and snap.avg[tostring(item_id)]
	if a and (tonumber(a.a) or 0) > 0 then return tonumber(a.a), tonumber(a.c) or 0 end
	return nil
end

-- Marche ACTUEL (agrege serveur sur toutes les annonces actives) : min, max, nb.
local function mktOf(item_id)
	local snap = EVO_HDV._snap
	local m = snap and snap.mkt and snap.mkt[tostring(item_id)]
	if m and (tonumber(m.c) or 0) > 0 then
		return tonumber(m.mn) or 0, tonumber(m.mx) or 0, tonumber(m.c) or 0
	end
	return nil
end

-- Bloc Dofus « MIN / MOY / MAX » : min et max = annonces en vente en ce moment,
-- moy = prix moyen des ventes reelles (30j). Retourne le y suivant.
local function drawMarketBlock(w, y, item_id)
	local mn, mx, cnt = mktOf(item_id)
	local avg, sales = avgOf(item_id)
	local labels = { "MIN", "MOY", "MAX" }
	local vals = {
		mn and (string.Comma(mn) .. " ¥") or "-",
		avg and (string.Comma(avg) .. " ¥") or "-",
		mx and (string.Comma(mx) .. " ¥") or "-",
	}
	local colW = w / 3
	for i = 1, 3 do
		local cx = (i - 1) * colW + colW * 0.5
		draw.SimpleText(labels[i], F_MONO, cx, y, COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		if MUGEN and MUGEN.DrawMoneyLine then
			MUGEN.DrawMoneyLine(vals[i], F_ROW, cx, y + R(14), i == 2 and COL_GOLD or COL_TXT,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		else
			draw.SimpleText(vals[i], F_ROW, cx, y + R(14), i == 2 and COL_GOLD or COL_TXT,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		end
	end
	y = y + R(38)
	local sub
	if cnt then
		sub = string.format("%d en vente actuellement", cnt)
		if sales and sales > 0 then sub = sub .. string.format("  ·  %d ventes / %dj", sales, CFG.AvgDays or 30) end
	elseif sales and sales > 0 then
		sub = string.format("Aucune en vente  ·  %d ventes / %dj", sales, CFG.AvgDays or 30)
	else
		sub = "Aucune donnée de marché pour cet objet"
	end
	draw.SimpleText(sub, F_SUB, w * 0.5, y, COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	return y + R(20)
end

-- Matieres premieres d'artisanat (bois / roche / metal / os / corde) : la liste
-- SOURCE vit dans evo_craft, on ne la recopie pas.
local _matSet
local function isCraftMat(item_id)
	if not _matSet then
		_matSet = {}
		for _, id in ipairs((EVO_CRAFT and EVO_CRAFT.ResourceOrder) or {}) do _matSet[id] = true end
	end
	return _matSet[item_id] == true
end

-- Categorie logique pour les filtres. ORDRE VOLONTAIRE : coffre et equipement
-- d'abord (ils priment), puis les familles ajoutees le 08/22. Chaque test passe
-- par le helper de son addon plutot que par une liste recopiee ici, sinon un
-- nouvel item n'atterrirait jamais dans sa categorie.
local function catOf(item_id)
	local it = itemDef(item_id)
	if not it then return "other" end
	if it.is_lootbox then return "chest" end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.ItemAffectsStats and INVENTORY_CONFIG.ItemAffectsStats(item_id) then
		return "equip"
	end
	-- Potions du labo (toutes etoiles) + potion ratee.
	if EVO_SCIENCE and EVO_SCIENCE.PotionParse and EVO_SCIENCE.PotionParse(item_id) then
		return "potion"
	end
	-- Pieges et grenades de l'atelier assassin (kind de la fiche de craft).
	if EVO_CRAFT and EVO_CRAFT.AssassinGearByKey then
		local g = EVO_CRAFT.AssassinGearByKey(item_id)
		if g and (g.kind == "piege" or g.kind == "grenade") then return "piege" end
	end
	-- Consommable au sens user : ce qui se ramasse sur la map (plantes,
	-- champignons, cristaux) + les matieres d'artisanat.
	if EVO_SCIENCE and EVO_SCIENCE.IngredientKind and EVO_SCIENCE.IngredientKind(item_id) then
		return "conso"
	end
	if isCraftMat(item_id) then return "conso" end
	return "other"
end

local RARITY_ORDER = { common = 1, rare = 2, epic = 3, legendary = 4, mythic = 5 }

-- ── Envois reseau (uniquement depuis des actions utilisateur) ────────────────
local function netOpen()
	net.Start("EVO:HDV:Open") net.SendToServer()
end
local function netSell(slot, price, amount)
	net.Start("EVO:HDV:Sell")
	net.WriteUInt(slot, 16)
	net.WriteUInt(price, 32)
	net.WriteUInt(math.max(1, math.floor(tonumber(amount) or 1)), 16)
	net.SendToServer()
end
local function netBuy(id)
	net.Start("EVO:HDV:Buy") net.WriteUInt(id, 32) net.SendToServer()
end
local function netTakeBack(id)
	net.Start("EVO:HDV:TakeBack") net.WriteUInt(id, 32) net.SendToServer()
end
local function netCollect(id)
	net.Start("EVO:HDV:Collect") net.WriteUInt(id, 32) net.SendToServer()
end
local function netWantPost(item_id, price, qty)
	net.Start("EVO:HDV:WantPost")
	net.WriteString(tostring(item_id or ""))
	net.WriteUInt(math.max(0, math.floor(tonumber(price) or 0)), 32)
	net.WriteUInt(math.Clamp(math.floor(tonumber(qty) or 1), 1, 65535), 16)
	net.SendToServer()
end
local function netWantCancel(id)
	net.Start("EVO:HDV:WantCancel") net.WriteUInt(id, 32) net.SendToServer()
end
local function netWantFill(id, slot)
	net.Start("EVO:HDV:WantFill")
	net.WriteUInt(id, 32)
	net.WriteUInt(slot, 16)
	net.SendToServer()
end
local function netWantOffer(id, slot, price)
	net.Start("EVO:HDV:WantOffer")
	net.WriteUInt(id, 32)
	net.WriteUInt(slot, 16)
	net.WriteUInt(math.max(0, math.floor(tonumber(price) or 0)), 32)
	net.SendToServer()
end
local function netWantAccept(id)
	net.Start("EVO:HDV:WantAccept") net.WriteUInt(id, 32) net.SendToServer()
end
local function netWantRefuse(id)
	net.Start("EVO:HDV:WantRefuse") net.WriteUInt(id, 32) net.SendToServer()
end
local function netWantPull(id)
	net.Start("EVO:HDV:WantPull") net.WriteUInt(id, 32) net.SendToServer()
end
local function netWantTake(id)
	net.Start("EVO:HDV:WantTake") net.WriteUInt(id, 32) net.SendToServer()
end

-- ── Widgets ──────────────────────────────────────────────────────────────────
local function styleScroll(scroll)
	if EVO_UI and EVO_UI.StyleScrollBar then
		EVO_UI.StyleScrollBar(scroll, { accent = COL_ACC, scroll = COL_SCROLL })
		return
	end
	local sbar = scroll:GetVBar()
	if IsValid(sbar) then sbar:SetWide(math.max(4, R(6))) end
end

local function Btn(parent, label, x, y, w, h, filled, fClick, fEnabled)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(x, y)
	b:SetSize(w, h)
	b:SetCursor("hand")
	b.Paint = function(s, bw, bh)
		local on = (not fEnabled) or fEnabled()
		local hov = on and hovered(s)
		if filled then
			rndx(0, 0, 0, bw, bh, on and (hov and COL_ACC_H or COL_ACC) or COL_ROW)
		else
			rndx(0, 0, 0, bw, bh, ColorAlpha(color_white, hov and 16 or 8))
		end
		local lbl = s._lbl or label
		local col = filled and (on and color_white or COL_MUT) or (on and COL_TXT or COL_MUT)
		if MUGEN and MUGEN.DrawMoneyLine then
			MUGEN.DrawMoneyLine(lbl, F_TAB, bw * 0.5, bh * 0.5, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText(lbl, F_TAB, bw * 0.5, bh * 0.5, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	b.DoClick = function(s)
		if fEnabled and not fEnabled() then return end
		fClick(s)
	end
	return b
end

local function Entry(parent, x, y, w, h, placeholder, numeric)
	local bg = vgui.Create("DPanel", parent)
	bg:SetPos(x, y)
	bg:SetSize(w, h)
	bg.Paint = function(_, bw, bh) rndx(R(5), 0, 0, bw, bh, COL_FIELD) end
	local e = vgui.Create("DTextEntry", bg)
	e:Dock(FILL)
	e:DockMargin(R(8), R(4), R(8), R(4))
	e:SetFont(F_SUB)
	e:SetTextColor(COL_TXT)
	e:SetCursorColor(COL_TXT)
	e:SetPaintBackground(false)
	e:SetDrawLanguageID(false) -- pas de badge "FR" (layout clavier) dans le champ
	e:SetUpdateOnType(true)
	if numeric then e:SetNumeric(true) end
	e.Paint = function(s, bw, bh)
		s:DrawTextEntryText(COL_TXT, COL_ACC, COL_TXT)
		if s:GetText() == "" and not s:HasFocus() and placeholder then
			draw.SimpleText(placeholder, F_SUB, 0, bh * 0.5, COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	bg.OnMousePressed = function() e:RequestFocus() end
	return e
end

-- Apercu d'item : 3D si model, sinon PNG icon (meme logique que l'inventaire).
local function ItemPreview(parent, item_id, fov)
	local it = itemDef(item_id)
	if not it then return end
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(parent, it, fov or 30, nil, 1)
		return
	end
	local mat = it.icon and Material(it.icon) or nil
	if not mat or mat:IsError() then return end
	local old = parent.Paint
	parent.Paint = function(s, w, h)
		if old then old(s, w, h) end
		local sc = math.min(1, tonumber(it.icon_scale) or 1)
		local iw = math.floor(math.min(w, h) * 0.82 * sc)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(mat)
		surface.DrawTexturedRect(math.floor((w - iw) * 0.5), math.floor((h - iw) * 0.5), iw, iw)
	end
end

-- ── Panneau principal ────────────────────────────────────────────────────────
local CARD_W, CARD_H = 1180, 680

local buildTab -- forward (selectTab <-> buildTab)

local function selectTab(id)
	TAB = id
	local f = EVO_HDV._frame
	if not IsValid(f) or not IsValid(f._content) then return end
	if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
	f._content:Clear()
	buildTab(f._content, id)
end

function EVO_HDV.RebuildTab()
	local f = EVO_HDV._frame
	if not IsValid(f) or not IsValid(f._content) then return end
	f._content:Clear()
	buildTab(f._content, TAB)
end

function EVO_HDV.Open()
	if IsValid(EVO_HDV._frame) then EVO_HDV._frame:Remove() end
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("hdv")
	end
	BUY_SEL, BUY_EXPAND, SELL_SLOT, SELL_PRICE, SELL_QTY = nil, nil, nil, 0, 1
	WANT_SEL, WANT_SLOT, WANT_ITEM = nil, nil, nil
	WANT_POST = false
	WANT_PRICE, WANT_QTY, WANT_OFFER_PRICE = 0, 1, 0
	WANT_FILTER, WANT_FIND = "", ""

	local frame = vgui.Create("DFrame")
	EVO_HDV._frame = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame._a = 0
	frame.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	frame.Paint = function(s, w, h)
		if RNDX and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(COL_FOND.r, COL_FOND.g, COL_FOND.b, COL_FOND.a * (s._a / 255))
		surface.DrawRect(0, 0, w, h)
	end
	frame.OnMousePressed = function() frame:Remove() end

	local card = vgui.Create("DPanel", frame)
	card:SetSize(R(CARD_W), R(CARD_H))
	card:Center()
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end -- absorbe le clic (ne ferme pas)
	card.Paint = function(s, w, h)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, R(16))
		else
			rndx(R(12), 0, 0, w, h, COL_CARD)
		end
		draw.SimpleText("市", "EVO_UI_KanjiXL", w - R(8), h - R(2),
			Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
		if EVO_UI and EVO_UI.Screw then
			local sr = R(5)
			EVO_UI.Screw(R(18), R(18), sr)
			EVO_UI.Screw(w - R(18), R(18), sr)
			EVO_UI.Screw(w - R(18), h - R(18), sr)
			EVO_UI.Screw(R(18), h - R(18), sr)
		end

		local title = "HÔTEL DES VENTES"
		draw.SimpleText(title, F_TITLE, R(22), R(12), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		surface.SetFont(F_TITLE)
		local tw, th = surface.GetTextSize(title)
		local inkOk = EVO_UI and EVO_UI.Ink
			and EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(12) + th * 0.78, tw * 1.1, R(8), ColorAlpha(COL_ACC, 245))
		if not inkOk then
			surface.SetDrawColor(COL_ACC)
			surface.DrawRect(R(22), R(12) + th * 0.84, tw, math.max(2, R(3)))
		end
		draw.SimpleText("Marché global entre joueurs", F_SUB, R(24) + tw + R(14), R(24),
			COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		local money = LocalPlayer():GetEvoNWInt("Money", 0)
		if MUGEN and MUGEN.DrawMoneyLine then
			MUGEN.DrawMoneyLine(string.Comma(money) .. " ¥", F_BIG, w - R(56), R(16),
				COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
		drawDashes(R(20), R(60), w - R(40), Color(255, 255, 255, 26))
	end

	-- Fermeture : glyphe seul, muted -> accent.
	local x = vgui.Create("DButton", card)
	x:SetText("")
	x:SetSize(R(32), R(32))
	x:SetPos(R(CARD_W - 46), R(12))
	x:SetCursor("hand")
	x.NoUIClickSound = true
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", F_X, w * 0.5, h * 0.5,
			s:IsHovered() and COL_ACC or COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() frame:Remove() end

	-- Onglets horizontaux (soulignes accent, style forge).
	local tabs = {
		{ id = "buy",  label = "ACHETER" },
		{ id = "sell", label = "VENDRE" },
		{ id = "want", label = "RECHERCHES" },
		{ id = "mine", label = "MES VENTES" },
		{ id = "hist", label = "HISTORIQUE" },
	}
	local tabY = R(70)
	for i, t in ipairs(tabs) do
		local b = vgui.Create("DButton", card)
		b:SetText("")
		b:SetCursor("hand")
		b:SetPos(R(16) + (i - 1) * R(150), tabY)
		b:SetSize(R(146), R(36))
		b.Paint = function(s, w, h)
			local active = (TAB == t.id)
			local hov = hovered(s)
			if hov and not active then rndx(0, 0, 0, w, h, COL_ACC_S) end
			if active then rndx(0, 0, h - R(2), w, R(2), COL_ACC) end
			draw.SimpleText(t.label, F_TAB, w * 0.5, h * 0.5,
				(active or hov) and COL_TXT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function() selectTab(t.id) end
	end

	-- Actualiser (throttle serveur 1 s).
	Btn(card, "ACTUALISER", R(CARD_W - 156), tabY + R(2), R(108), R(32), false, function()
		netOpen()
	end)

	local content = vgui.Create("DPanel", card)
	frame._content = content
	content:SetPos(R(16), tabY + R(44))
	content:SetSize(R(CARD_W - 32), R(CARD_H) - (tabY + R(60)))
	content:SetPaintBackground(false)

	buildTab(content, TAB)
end

-- ── Onglet ACHETER ───────────────────────────────────────────────────────────
local function buildBuyTab(content)
	local cw, ch = content:GetSize()
	local detailW = R(330)
	local listW = cw - detailW - R(12)
	local snap = EVO_HDV._snap or {}
	local listings = snap.listings or {}

	-- Deux rangees : recherche + tri, puis les categories sur toute la largeur.
	-- Sur une seule rangee les libelles (surtout « PIÈGES & GRENADES ») passaient
	-- sous le bouton de tri : le texte seul est plus large que la place restante.
	local barH = R(72)
	local bar = vgui.Create("DPanel", content)
	bar:SetPos(0, 0)
	bar:SetSize(listW, barH)
	bar:SetPaintBackground(false)

	local refreshList -- forward

	local sorts = {
		{ id = "recent",     label = "RÉCENT" },
		{ id = "price_asc",  label = "PRIX CROISSANT" },
		{ id = "price_desc", label = "PRIX DÉCROISSANT" },
		{ id = "rarity",     label = "RARETÉ" },
	}
	surface.SetFont(F_MONO)
	local sortW = 0
	for _, srt in ipairs(sorts) do
		local tw = surface.GetTextSize("TRI : " .. srt.label)
		if tw > sortW then sortW = tw end
	end
	sortW = math.min(listW - R(160), sortW + R(20))
	local searchW = math.max(R(120), listW - sortW - R(8))

	local search = Entry(bar, 0, 0, searchW, R(36), "Rechercher un objet, un vendeur...")
	search.OnValueChange = function(_, v)
		BUY_FILTER = fold(v)
		if refreshList then refreshList() end
	end

	local sortBtn = vgui.Create("DButton", bar)
	sortBtn:SetText("")
	sortBtn:SetCursor("hand")
	sortBtn:SetPos(listW - sortW, R(4))
	sortBtn:SetSize(sortW, R(28))
	sortBtn.Paint = function(s, w, h)
		rndx(R(4), 0, 0, w, h, ColorAlpha(color_white, hovered(s) and 16 or 8))
		local lbl = "TRI : " .. (sorts[1].label)
		for _, srt in ipairs(sorts) do
			if srt.id == BUY_SORT then lbl = "TRI : " .. srt.label break end
		end
		draw.SimpleText(lbl, F_MONO, w * 0.5, h * 0.5, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	sortBtn.DoClick = function()
		for i, srt in ipairs(sorts) do
			if srt.id == BUY_SORT then
				BUY_SORT = sorts[(i % #sorts) + 1].id
				if refreshList then refreshList() end
				return
			end
		end
		BUY_SORT = "recent"
		if refreshList then refreshList() end
	end

	local cats = {
		{ id = "all",    label = "TOUS" },
		{ id = "equip",  label = "ÉQUIPEMENT" },
		{ id = "chest",  label = "COFFRES" },
		{ id = "conso",  label = "CONSOMMABLES" },
		{ id = "piege",  label = "PIÈGES & GRENADES" },
		{ id = "potion", label = "POTIONS" },
		{ id = "other",  label = "AUTRES" },
	}
	local cx = 0
	local nAvail = listW
	surface.SetFont(F_MONO)
	local nText = 0
	for _, c in ipairs(cats) do nText = nText + surface.GetTextSize(c.label) end
	local nPad, nGap = R(20), R(6)
	local function rowW(pad, gap)
		return nText + #cats * pad + math.max(0, #cats - 1) * gap
	end
	if rowW(nPad, nGap) > nAvail then
		local slack = nAvail - nText
		if slack <= 0 then
			nPad, nGap = 0, 0
		else
			local denom = #cats + 0.3 * math.max(0, #cats - 1)
			nPad = math.floor(slack / denom)
			nGap = math.floor(nPad * 0.3)
			while rowW(nPad, nGap) > nAvail and (nPad > 0 or nGap > 0) do
				if nGap > 0 then nGap = nGap - 1 else nPad = nPad - 1 end
			end
		end
	end
	for _, c in ipairs(cats) do
		surface.SetFont(F_MONO)
		local tw = surface.GetTextSize(c.label)
		local bw = tw + nPad
		local b = vgui.Create("DButton", bar)
		b:SetText("")
		b:SetCursor("hand")
		b:SetPos(cx, R(42))
		b:SetSize(bw, R(28))
		b.Paint = function(s, w, h)
			local on = (BUY_CAT == c.id)
			rndx(R(4), 0, 0, w, h, on and ColorAlpha(COL_ACC, 220) or ColorAlpha(color_white, hovered(s) and 16 or 8))
			draw.SimpleText(c.label, F_MONO, w * 0.5, h * 0.5,
				on and color_white or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			BUY_CAT = c.id
			if refreshList then refreshList() end
		end
		cx = cx + bw + nGap
	end

	local listY = R(78)
	local list = vgui.Create("DScrollPanel", content)
	list:SetPos(0, listY)
	list:SetSize(listW, ch - listY)
	list.Paint = function() end
	styleScroll(list)

	-- Panneau detail (droite).
	local detail = vgui.Create("DPanel", content)
	detail:SetPos(listW + R(12), 0)
	detail:SetSize(detailW, ch)
	local buildDetail -- forward

	local function matches(l)
		if BUY_CAT ~= "all" and catOf(l.i) ~= BUY_CAT then return false end
		if BUY_FILTER ~= "" then
			local hay = fold(itemName(l.i)) .. " " .. fold(l.s or "")
			if not string.find(hay, BUY_FILTER, 1, true) then return false end
		end
		return true
	end

	local function priceRangeTxt(mn, mx)
		mn, mx = math.floor(tonumber(mn) or 0), math.floor(tonumber(mx) or 0)
		if mn == mx then return string.Comma(mn) .. " ¥" end
		return string.Comma(mn) .. " – " .. string.Comma(mx) .. " ¥"
	end

	-- Detail marche d'un groupe (pas d'achat tant qu'une offre n'est pas choisie).
	local function buildGroupDetail(item_id, g)
		detail:Clear()
		detail.Paint = function(_, w, h)
			rndx(R(8), 0, 0, w, h, Color(19, 20, 24))
		end
		detail.PaintOver = nil
		local it = itemDef(item_id)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)

		local prev = vgui.Create("DPanel", detail)
		prev:SetPos(R(12), R(12))
		prev:SetSize(detailW - R(24), R(150))
		prev.Paint = function(_, w, h) rndx(R(6), 0, 0, w, h, Color(8, 8, 10, 255)) end
		ItemPreview(prev, item_id, 30)

		local infoY = R(170)
		local info = vgui.Create("DPanel", detail)
		info:SetPos(R(12), infoY)
		info:SetSize(detailW - R(24), ch - infoY - R(20))
		info:SetPaintBackground(false)
		info.Paint = function(_, w, h)
			local y = 0
			draw.SimpleText(trunc(itemName(item_id), F_BIG, w), F_BIG, 0, y, COL_TXT)
			y = y + R(30)
			draw.SimpleText(EVO_HDV.RarityNames[(it or {}).rarity] or "", F_SUB, 0, y, rarCol)
			y = y + R(20)
			local n = g and g.n or 0
			draw.SimpleText(string.format("%d offre%s", n, n > 1 and "s" or ""), F_SUB, 0, y, COL_DIM)
			y = y + R(18)
			if g then
				draw.SimpleText("Prix : " .. priceRangeTxt(g.mn, g.mx), F_SUB, 0, y, COL_GOLD)
				y = y + R(18)
			end
			y = y + R(4)
			drawDashes(0, y, w, Color(255, 255, 255, 22))
			y = drawMarketBlock(w, y + R(8), item_id)
			y = y + R(10)
			draw.SimpleText("Déplie et choisis une offre", F_SUB, w * 0.5, y,
				COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		end
	end

	refreshList = function()
		list:Clear()
		local rows = {}
		for _, l in ipairs(listings) do
			if matches(l) and remainingOf(l) > 0 then rows[#rows + 1] = l end
		end

		-- Groupement UI par item_id (ordre = 1ere apparition = plus recent serveur).
		local groups, byId = {}, {}
		for _, l in ipairs(rows) do
			local key = tostring(l.i)
			local g = byId[key]
			if not g then
				g = { i = l.i, offers = {}, mn = math.huge, mx = 0, n = 0 }
				byId[key] = g
				groups[#groups + 1] = g
			end
			g.offers[#g.offers + 1] = l
			local p = tonumber(l.p) or 0
			if p < g.mn then g.mn = p end
			if p > g.mx then g.mx = p end
			g.n = g.n + 1
		end

		if BUY_SORT == "price_asc" then
			table.sort(groups, function(a, b) return a.mn < b.mn end)
		elseif BUY_SORT == "price_desc" then
			table.sort(groups, function(a, b) return a.mx > b.mx end)
		elseif BUY_SORT == "rarity" then
			table.sort(groups, function(a, b)
				local ra = RARITY_ORDER[(itemDef(a.i) or {}).rarity] or 0
				local rb = RARITY_ORDER[(itemDef(b.i) or {}).rarity] or 0
				if ra ~= rb then return ra > rb end
				return a.mn < b.mn
			end)
		end -- "recent" = ordre d'insertion (created_at DESC serveur)

		if BUY_EXPAND and not byId[tostring(BUY_EXPAND)] then
			BUY_EXPAND = nil
		end
		if BUY_SEL then
			local still = false
			for _, l in ipairs(rows) do
				if l.id == BUY_SEL then still = true break end
			end
			if not still then BUY_SEL = nil end
		end

		local function restoreDetail()
			if BUY_SEL then
				for _, l in ipairs(rows) do
					if l.id == BUY_SEL then buildDetail(l) return end
				end
			end
			if BUY_EXPAND and byId[tostring(BUY_EXPAND)] then
				buildGroupDetail(BUY_EXPAND, byId[tostring(BUY_EXPAND)])
				return
			end
			buildDetail(nil)
		end

		if #groups == 0 then
			local empty = list:Add("DPanel")
			empty:Dock(TOP)
			empty:SetTall(R(60))
			empty:SetPaintBackground(false)
			empty.Paint = function(_, w, h)
				draw.SimpleText("Aucune annonce ne correspond.", F_SUB, w * 0.5, h * 0.5,
					COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			restoreDetail()
			return
		end

		for _, g in ipairs(groups) do
			local item_id = g.i
			local key = tostring(item_id)
			local it = itemDef(item_id)
			local rarCol = EVO_HDV.RarityColor(it and it.rarity)
			local expanded = (BUY_EXPAND == key)
			local nameC = trunc(itemName(item_id), F_ROW, listW - R(320))

			local groupRow = list:Add("DButton")
			groupRow:SetText("")
			groupRow:SetCursor("hand")
			groupRow:Dock(TOP)
			groupRow:DockMargin(0, 0, R(6), R(4))
			groupRow:SetTall(R(52))
			groupRow.Paint = function(s, w, h)
				local active = (BUY_EXPAND == key)
				local hov = hovered(s)
				rndx(0, 0, 0, w, h, (hov or active) and COL_ROW_H or COL_ROW)
				if hov or active then
					rndx(0, 0, 0, R(4), h, COL_ACC, RNDX and (RNDX.NO_TR + RNDX.NO_BR) or nil)
				end
				surface.SetDrawColor(rarCol)
				surface.DrawRect(R(10), R(10), R(3), h - R(20))
				draw.SimpleText(expanded and "▾" or "▸", F_SUB, R(22), h * 0.5, COL_DIM,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(nameC, F_ROW, R(40), h * 0.30, rarCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(string.format("%d offre%s", g.n, g.n > 1 and "s" or ""),
					F_SUB, R(40), h * 0.72, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if MUGEN and MUGEN.DrawMoneyLine then
					MUGEN.DrawMoneyLine(priceRangeTxt(g.mn, g.mx), F_ROW, w - R(14), h * 0.5,
						COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(priceRangeTxt(g.mn, g.mx), F_ROW, w - R(14), h * 0.5,
						COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			groupRow.DoClick = function()
				if BUY_EXPAND == key then
					BUY_EXPAND = nil
					BUY_SEL = nil
				else
					BUY_EXPAND = key
					BUY_SEL = nil
				end
				refreshList()
			end

			if not expanded then continue end

			table.sort(g.offers, function(a, b) return (a.p or 0) < (b.p or 0) end)
			for _, l in ipairs(g.offers) do
				local offer = list:Add("DButton")
				offer:SetText("")
				offer:SetCursor("hand")
				offer:Dock(TOP)
				offer:DockMargin(R(14), 0, R(6), R(3))
				offer:SetTall(R(44))
				offer.Paint = function(s, w, h)
					local sel = (BUY_SEL == l.id)
					local hov = hovered(s)
					rndx(0, 0, 0, w, h, (hov or sel) and COL_ROW_H or Color(22, 22, 28, 255))
					if hov or sel then
						rndx(0, 0, 0, R(3), h, COL_ACC, RNDX and (RNDX.NO_TR + RNDX.NO_BR) or nil)
					end
					local sub = "Par " .. tostring(l.s or "?") .. "  ·  " .. EVO_HDV.FormatRemaining(remainingOf(l))
					if isstring(l.e) and l.e ~= "" then sub = "Enchanté  ·  " .. sub end
					if (tonumber(l.q) or 1) > 1 then sub = "×" .. l.q .. "  ·  " .. sub end
					if (tonumber(l.f) or 1) > 1 then sub = "Forge niv. " .. l.f .. "  ·  " .. sub end
					draw.SimpleText(sub, F_SUB, R(14), h * 0.32, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					local avg = avgOf(l.i)
					if avg and avg > 0 then
						local delta = math.Round(((l.p or 0) - avg) / avg * 100)
						local dCol = delta > 10 and COL_ACC or (delta < -10 and COL_GREEN or COL_MUT)
						draw.SimpleText((delta >= 0 and "+" or "") .. delta .. "% vs moy.", F_SUB,
							R(14), h * 0.72, dCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					elseif (tonumber(l.d) or 100) < 100 then
						draw.SimpleText(string.format("Durabilité %d%%", math.floor(tonumber(l.d) or 100)),
							F_SUB, R(14), h * 0.72, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
					if MUGEN and MUGEN.DrawMoneyLine then
						MUGEN.DrawMoneyLine(string.Comma(l.p or 0) .. " ¥", F_ROW, w - R(12), h * 0.5,
							COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(string.Comma(l.p or 0) .. " ¥", F_ROW, w - R(12), h * 0.5,
							COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				end
				offer.DoClick = function()
					BUY_SEL = l.id
					BUY_EXPAND = key
					buildDetail(l)
				end
			end
		end

		restoreDetail()
	end

	buildDetail = function(l)
		detail:Clear()
		detail.Paint = function(_, w, h)
			rndx(R(8), 0, 0, w, h, Color(19, 20, 24))
		end
		if not l then
			detail.PaintOver = function(_, w, h)
				draw.SimpleText("Sélectionne une annonce", F_SUB, w * 0.5, h * 0.5,
					COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		detail.PaintOver = nil
		local it = itemDef(l.i)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)

		local prev = vgui.Create("DPanel", detail)
		prev:SetPos(R(12), R(12))
		prev:SetSize(detailW - R(24), R(150))
		prev.Paint = function(_, w, h) rndx(R(6), 0, 0, w, h, Color(8, 8, 10, 255)) end
		ItemPreview(prev, l.i, 30)

		local infoY = R(170)
		local info = vgui.Create("DPanel", detail)
		info:SetPos(R(12), infoY)
		info:SetSize(detailW - R(24), ch - infoY - R(64))
		info:SetPaintBackground(false)
		-- Mémoïsé à la construction (jamais de parse par frame dans le Paint).
		local tEnchLines = enchantLines(l.e, l.i)
		info.Paint = function(_, w, h)
			local y = 0
			draw.SimpleText(trunc(itemNameQty(l.i, l.q), F_BIG, w), F_BIG, 0, y, COL_TXT)
			y = y + R(30)
			local rar = EVO_HDV.RarityNames[(it or {}).rarity] or ""
			draw.SimpleText(rar, F_SUB, 0, y, rarCol)
			y = y + R(20)
			if (tonumber(l.f) or 1) > 1 then
				draw.SimpleText("Niveau de forge : " .. l.f .. " / " .. ((NCM_FORGE and NCM_FORGE.MAX_LEVEL) or 30),
					F_SUB, 0, y, COL_WARN)
				y = y + R(18)
			end
			-- Enchantement(s) de la pièce (user 08/20) : couleur du boost.
			for _, le in ipairs(tEnchLines) do
				draw.SimpleText(le.txt, F_SUB, 0, y, le.col)
				y = y + R(18)
			end
			if (tonumber(l.d) or 100) < 100 then
				draw.SimpleText(string.format("Durabilité : %d%%", math.floor(tonumber(l.d) or 100)), F_SUB, 0, y, COL_DIM)
				y = y + R(18)
			end
			for _, line in ipairs(EVO_HDV.StatLines(l.i, l.f)) do
				draw.SimpleText(line, F_SUB, 0, y, COL_GREEN)
				y = y + R(16)
			end
			y = y + R(6)
			draw.SimpleText("Vendeur : " .. tostring(l.s or "?"), F_SUB, 0, y, COL_DIM)
			y = y + R(18)
			draw.SimpleText("Expire dans : " .. EVO_HDV.FormatRemaining(remainingOf(l)), F_SUB, 0, y, COL_DIM)
			y = y + R(8)
			drawDashes(0, y, w, Color(255, 255, 255, 22))
			y = drawMarketBlock(w, y + R(8), l.i)
			y = y + R(6)
			if MUGEN and MUGEN.DrawMoneyLine then
				MUGEN.DrawMoneyLine(string.Comma(l.p or 0) .. " ¥", "Bebas Neue:34", 0, y, COL_GOLD)
			end
		end

		-- Achat en deux temps : 1er clic arme, 2e clic (dans les 3 s) confirme.
		local buyBtn
		buyBtn = Btn(detail, "ACHETER", R(12), ch - R(48), detailW - R(24), R(38), true, function(s)
			if tostring(l.sid) == LocalPlayer():SteamID64() then return end
			if (s._armedUntil or 0) > CurTime() then
				s._armedUntil = nil
				s._lbl = nil
				netBuy(l.id)
			else
				s._armedUntil = CurTime() + 3
				s._lbl = "CONFIRMER L'ACHAT ?"
				timer.Simple(3.1, function()
					if IsValid(s) and (s._armedUntil or 0) <= CurTime() then s._lbl = nil end
				end)
			end
		end, function()
			return tostring(l.sid) ~= LocalPlayer():SteamID64()
				and LocalPlayer():GetEvoNWInt("Money", 0) >= (l.p or 0)
		end)
		if tostring(l.sid) == LocalPlayer():SteamID64() then
			buyBtn._lbl = "TON ANNONCE"
		end
	end

	-- Si une offre etait selectionnee, re-ouvrir son groupe au rebuild.
	if BUY_SEL then
		for _, l in ipairs(listings) do
			if l.id == BUY_SEL and remainingOf(l) > 0 then
				BUY_EXPAND = tostring(l.i)
				break
			end
		end
	end
	refreshList()
end

-- ── Onglet VENDRE ────────────────────────────────────────────────────────────
local function buildSellTab(content)
	local cw, ch = content:GetSize()
	local detailW = R(330)
	local gridW = cw - detailW - R(12)
	local snap = EVO_HDV._snap or {}

	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or { items = {}, durability = {} }
	local maxSlots = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80

	local header = vgui.Create("DPanel", content)
	header:SetPos(0, 0)
	header:SetSize(gridW, R(24))
	header:SetPaintBackground(false)
	header.Paint = function(_, w, h)
		draw.SimpleText("TON SAC (objets vendables en clair)", "Bebas Neue:21", 0, h * 0.5,
			COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.format("%d/%d annonces actives", tonumber(snap.myCount) or 0, CFG.MaxActiveListings),
			F_MONO, w - R(4), h * 0.5, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local grid = vgui.Create("DScrollPanel", content)
	grid:SetPos(0, R(30))
	grid:SetSize(gridW, ch - R(30))
	grid.Paint = function() end
	styleScroll(grid)

	local detail = vgui.Create("DPanel", content)
	detail:SetPos(gridW + R(12), 0)
	detail:SetSize(detailW, ch)
	local buildSellDetail -- forward

	-- Grille des objets du sac (slots occupes uniquement).
	local cell = R(86)
	local gap = R(8)
	local cols = math.max(1, math.floor((gridW - R(10)) / (cell + gap)))
	local rowPnl, inRow = nil, 0
	for slot = 1, maxSlots do
		local item_id = inv.items[slot]
		if isstring(item_id) and item_id ~= "" then
			if not rowPnl or inRow >= cols then
				rowPnl = grid:Add("DPanel")
				rowPnl:Dock(TOP)
				rowPnl:DockMargin(0, 0, 0, gap)
				rowPnl:SetTall(cell)
				rowPnl:SetPaintBackground(false)
				inRow = 0
			end
			local it = itemDef(item_id)
			local sellable = EVO_HDV.IsSellable(item_id)
			local rarCol = EVO_HDV.RarityColor(it and it.rarity)
			local c = vgui.Create("DButton", rowPnl)
			c:SetText("")
			c:SetPos(inRow * (cell + gap), 0)
			c:SetSize(cell, cell)
			c:SetCursor(sellable and "hand" or "no")
			c._slot = slot
			c.Paint = function(s, w, h)
				local sel = (SELL_SLOT == slot)
				rndx(R(6), 0, 0, w, h, (sel or (sellable and hovered(s))) and COL_ROW_H or COL_ROW)
				surface.SetDrawColor(rarCol.r, rarCol.g, rarCol.b, sellable and 255 or 90)
				surface.DrawRect(0, h - R(3), w, R(3))
				if sel then
					if EVO_UI and EVO_UI.HoverOutline then
						EVO_UI.HoverOutline(w, h, COL_ACC, R(6))
					else
						surface.SetDrawColor(COL_ACC)
						surface.DrawOutlinedRect(0, 0, w - 1, h - 1)
					end
				end
			end
			c.PaintOver = function(s, w, h)
				if not sellable then
					rndx(R(6), 0, 0, w, h, Color(10, 10, 12, 170))
				end
				local lvl = NCM_FORGE and NCM_FORGE.GetClientLevel and NCM_FORGE.GetClientLevel(slot) or 1
				if (lvl or 1) > 1 then
					draw.SimpleText("N" .. lvl, F_MONO, R(4), R(2), COL_WARN)
				end
				local qn = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inv, slot) or 1
				if qn > 1 then
					draw.SimpleText("x" .. qn, F_MONO, w - R(4), R(2), COL_TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				end
			end
			ItemPreview(c, item_id, 30)
			c.DoClick = function()
				if not sellable then return end
				SELL_SLOT = slot
				SELL_PRICE = 0
				SELL_QTY = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inv, slot) or 1
				buildSellDetail(slot, item_id)
			end
			inRow = inRow + 1
		end
	end

	buildSellDetail = function(slot, item_id)
		detail:Clear()
		detail.Paint = function(_, w, h) rndx(R(8), 0, 0, w, h, Color(19, 20, 24)) end
		if not slot then
			detail.PaintOver = function(_, w, h)
				draw.SimpleText("Sélectionne un objet à vendre", F_SUB, w * 0.5, h * 0.5,
					COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		detail.PaintOver = nil
		local it = itemDef(item_id)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)
		local lvl = NCM_FORGE and NCM_FORGE.GetClientLevel and NCM_FORGE.GetClientLevel(slot) or 1
		local dur = inv.durability and tonumber(inv.durability[slot]) or 100
		local haveQty = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inv, slot) or 1
		SELL_QTY = math.max(1, math.min(haveQty, tonumber(SELL_QTY) or haveQty))

		local prev = vgui.Create("DPanel", detail)
		prev:SetPos(R(12), R(12))
		prev:SetSize(detailW - R(24), R(130))
		prev.Paint = function(_, w, h) rndx(R(6), 0, 0, w, h, Color(8, 8, 10, 255)) end
		ItemPreview(prev, item_id, 30)

		local entryY = ch - R(130)
		local infoY = R(150)
		local info = vgui.Create("DPanel", detail)
		info:SetPos(R(12), infoY)
		info:SetSize(detailW - R(24), entryY - infoY - R(6))
		info:SetPaintBackground(false)
		-- Enchantement du slot (miroir cl_net, copie via GetInventory) mémoïsé à
		-- la construction : jamais de table.Copy ni de parse par frame.
		local invT = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
		local tEnchLines2 = enchantLines(istable(invT) and istable(invT.enchants) and invT.enchants[slot] or nil, item_id)
		info.Paint = function(_, w, h)
			local y = 0
			draw.SimpleText(trunc(itemNameQty(item_id, haveQty), F_BIG, w), F_BIG, 0, y, COL_TXT)
			y = y + R(30)
			draw.SimpleText(EVO_HDV.RarityNames[(it or {}).rarity] or "", F_SUB, 0, y, rarCol)
			y = y + R(20)
			if (lvl or 1) > 1 then
				draw.SimpleText("Niveau de forge : " .. lvl .. " / " .. ((NCM_FORGE and NCM_FORGE.MAX_LEVEL) or 30),
					F_SUB, 0, y, COL_WARN)
				y = y + R(18)
			end
			-- Enchantement(s) de la pièce à vendre (miroir client du sac).
			for _, le in ipairs(tEnchLines2) do
				draw.SimpleText(le.txt, F_SUB, 0, y, le.col)
				y = y + R(18)
			end
			if dur < 100 then
				draw.SimpleText(string.format("Durabilité : %d%%", math.floor(dur)), F_SUB, 0, y, COL_DIM)
				y = y + R(18)
			end
			y = y + R(6)
			drawDashes(0, y, w, Color(255, 255, 255, 22))
			drawMarketBlock(w, y + R(8), item_id)
		end

		-- Prix suggere pre-rempli (comme Dofus) : moyenne des ventes, sinon le min
		-- des annonces en cours. Modifiable librement.
		local avgS = avgOf(item_id)
		local mnS = mktOf(item_id)
		local suggested = avgS or mnS
		local priceW = detailW - R(24)
		if haveQty > 1 then
			local qtyW = R(110)
			local qtyEntry = Entry(detail, R(12), entryY, qtyW, R(34), "Qté", true)
			qtyEntry:SetValue(tostring(SELL_QTY))
			qtyEntry.OnValueChange = function(_, v)
				local n = math.floor(tonumber(v) or 1)
				if n < 1 then n = 1 end
				if n > haveQty then n = haveQty end
				SELL_QTY = n
			end
			priceW = detailW - R(24) - qtyW - R(8)
			local priceEntry = Entry(detail, R(12) + qtyW + R(8), entryY, priceW, R(34), "Prix de vente en yens", true)
			priceEntry.OnValueChange = function(_, v)
				SELL_PRICE = math.floor(tonumber(v) or 0)
			end
			if suggested and suggested >= (CFG.MinPrice or 1) then
				SELL_PRICE = math.floor(suggested)
				priceEntry:SetValue(tostring(SELL_PRICE))
			end
		else
			SELL_QTY = 1
			local priceEntry = Entry(detail, R(12), entryY, priceW, R(34), "Prix de vente en yens", true)
			priceEntry.OnValueChange = function(_, v)
				SELL_PRICE = math.floor(tonumber(v) or 0)
			end
			if suggested and suggested >= (CFG.MinPrice or 1) then
				SELL_PRICE = math.floor(suggested)
				priceEntry:SetValue(tostring(SELL_PRICE))
			end
		end

		local fees = vgui.Create("DPanel", detail)
		fees:SetPos(R(12), entryY + R(40))
		fees:SetSize(detailW - R(24), R(36))
		fees:SetPaintBackground(false)
		fees.Paint = function(_, w, h)
			local p = SELL_PRICE
			if p < (CFG.MinPrice or 1) then
				draw.SimpleText(string.format("Prix entre %s et %s ¥", string.Comma(CFG.MinPrice), string.Comma(CFG.MaxPrice)),
					F_SUB, 0, 0, COL_MUT)
				return
			end
			draw.SimpleText(string.format("Taxe de mise en vente : %s ¥ (non remboursable)",
				string.Comma(EVO_HDV.ListingFee(p))), F_SUB, 0, 0, COL_DIM)
			draw.SimpleText(string.format("Tu recevras à la vente : %s ¥ (commission %d%%)",
				string.Comma(EVO_HDV.Proceeds(p)), math.floor((CFG.CommissionPct or 0) * 100)), F_SUB, 0, R(17), COL_GREEN)
		end

		Btn(detail, "METTRE EN VENTE", R(12), ch - R(48), detailW - R(24), R(38), true, function()
			netSell(slot, SELL_PRICE, SELL_QTY)
			SELL_SLOT = nil
		end, function()
			return SELL_PRICE >= (CFG.MinPrice or 1) and SELL_PRICE <= (CFG.MaxPrice or math.huge)
				and (tonumber(snap.myCount) or 0) < CFG.MaxActiveListings
		end)
	end

	buildSellDetail(SELL_SLOT, SELL_SLOT and inv.items[SELL_SLOT] or nil)
end

-- ── Onglet MES VENTES ────────────────────────────────────────────────────────
local function buildMineTab(content)
	local cw, ch = content:GetSize()
	local snap = EVO_HDV._snap or {}
	local mine = snap.mine or {}

	local toCollect, nSold = 0, 0
	for _, l in ipairs(mine) do
		if l.st == "sold" then
			toCollect = toCollect + (tonumber(l.g) or 0)
			nSold = nSold + 1
		end
	end

	local header = vgui.Create("DPanel", content)
	header:SetPos(0, 0)
	header:SetSize(cw, R(40))
	header:SetPaintBackground(false)
	header.Paint = function(_, w, h)
		draw.SimpleText(string.format("%d annonce(s)", #mine), "Bebas Neue:21", 0, h * 0.5,
			COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if toCollect > 0 and MUGEN and MUGEN.DrawMoneyLine then
			MUGEN.DrawMoneyLine(string.Comma(toCollect) .. " ¥ à récupérer", F_TAB, w - R(190), h * 0.5,
				COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
	if nSold > 0 then
		Btn(header, "TOUT RÉCUPÉRER", cw - R(170), R(2), R(170), R(34), true, function()
			netCollect(0)
		end)
	end

	local list = vgui.Create("DScrollPanel", content)
	list:SetPos(0, R(48))
	list:SetSize(cw, ch - R(48))
	list.Paint = function() end
	styleScroll(list)

	if #mine == 0 then
		local empty = list:Add("DPanel")
		empty:Dock(TOP)
		empty:SetTall(R(60))
		empty:SetPaintBackground(false)
		empty.Paint = function(_, w, h)
			draw.SimpleText("Aucune annonce en cours. Passe par l'onglet VENDRE.", F_SUB, w * 0.5, h * 0.5,
				COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	for _, l in ipairs(mine) do
		local it = itemDef(l.i)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)
		local nameC = trunc(itemNameQty(l.i, l.q), F_ROW, cw - R(430))
		local row = list:Add("DPanel")
		row:Dock(TOP)
		row:DockMargin(0, 0, R(6), R(4))
		row:SetTall(R(52))
		row:SetPaintBackground(false)
		row.Paint = function(s, w, h)
			rndx(0, 0, 0, w, h, hovered(s) and COL_ROW_H or COL_ROW)
			surface.SetDrawColor(rarCol)
			surface.DrawRect(R(10), R(10), R(3), h - R(20))
			draw.SimpleText(nameC, F_ROW, R(22), h * 0.30, rarCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local sub, subCol
			if l.st == "sold" then
				sub, subCol = "Vendue  ·  " .. string.Comma(l.g or 0) .. " ¥ à récupérer", COL_GREEN
			else
				local rem = remainingOf(l)
				if rem <= 0 then
					sub, subCol = "Expirée, récupère ton objet", COL_WARN
				else
					sub, subCol = "Active  ·  expire dans " .. EVO_HDV.FormatRemaining(rem), COL_DIM
				end
			end
			draw.SimpleText(sub, F_SUB, R(22), h * 0.72, subCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if MUGEN and MUGEN.DrawMoneyLine then
				MUGEN.DrawMoneyLine(string.Comma(l.p or 0) .. " ¥", F_ROW, w - R(190), h * 0.5,
					COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		local actBtn
		if l.st == "sold" then
			actBtn = Btn(row, "RÉCUPÉRER", 0, R(9), R(160), R(34), true, function()
				netCollect(l.id)
			end)
		else
			actBtn = Btn(row, "RETIRER", 0, R(9), R(160), R(34), false, function()
				netTakeBack(l.id)
			end)
		end
		row.PerformLayout = function(_, w)
			if IsValid(actBtn) then actBtn:SetPos(w - R(172), R(9)) end
		end
	end
end

-- ── Onglet HISTORIQUE ────────────────────────────────────────────────────────
local function buildHistTab(content)
	local cw, ch = content:GetSize()
	local snap = EVO_HDV._snap or {}
	local hist = snap.hist or {}

	local list = vgui.Create("DScrollPanel", content)
	list:SetPos(0, 0)
	list:SetSize(cw, ch)
	list.Paint = function() end
	styleScroll(list)

	if #hist == 0 then
		local empty = list:Add("DPanel")
		empty:Dock(TOP)
		empty:SetTall(R(60))
		empty:SetPaintBackground(false)
		empty.Paint = function(_, w, h)
			draw.SimpleText("Aucune transaction pour le moment.", F_SUB, w * 0.5, h * 0.5,
				COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	for _, e in ipairs(hist) do
		local label, amount, aCol
		if e.a == "buy" and e.b then
			label, amount, aCol = "Achat", -(e.p or 0), COL_ACC
		elseif e.a == "buy" then
			label, amount, aCol = "Vente", (e.p or 0) - (e.fee or 0), COL_GREEN
		elseif e.a == "list" then
			label, amount, aCol = "Mise en vente (taxe)", -(e.fee or 0), COL_DIM
		elseif e.a == "cancel" then
			label, amount, aCol = "Annonce retirée", 0, COL_DIM
		elseif e.a == "collect" then
			label, amount, aCol = "Gains récupérés", (e.p or 0), COL_GREEN
		elseif e.a == "want" then
			label, amount, aCol = "Recherche postée", -((e.p or 0) + (e.fee or 0)), COL_ACC
		elseif e.a == "wfill" and e.b then
			label, amount, aCol = "Recherche pourvue", 0, COL_GREEN
		elseif e.a == "wfill" then
			label, amount, aCol = "Vente (recherche)", (e.p or 0) - (e.fee or 0), COL_GREEN
		elseif e.a == "wcancel" then
			label, amount, aCol = "Recherche retirée", (e.p or 0), COL_GREEN
		else
			label, amount, aCol = tostring(e.a), 0, COL_DIM
		end
		local nameC = trunc(itemName(e.i), F_ROW, cw - R(420))
		local row = list:Add("DPanel")
		row:Dock(TOP)
		row:DockMargin(0, 0, R(6), R(4))
		row:SetTall(R(40))
		row:SetPaintBackground(false)
		row.Paint = function(s, w, h)
			rndx(0, 0, 0, w, h, hovered(s) and COL_ROW_H or COL_ROW)
			draw.SimpleText(tostring(e.d or ""), F_MONO, R(12), h * 0.5, COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(label, F_SUB, R(110), h * 0.5, aCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(nameC, F_ROW, R(280), h * 0.5, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if amount ~= 0 and MUGEN and MUGEN.DrawMoneyLine then
				local sign = amount > 0 and "+" or "-"
				MUGEN.DrawMoneyLine(sign .. string.Comma(math.abs(amount)) .. " ¥", F_ROW, w - R(14), h * 0.5,
					amount > 0 and COL_GREEN or COL_ACC, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end
end

-- ── Onglet RECHERCHES ────────────────────────────────────────────────────────
local function buildWantTab(content)
	local cw, ch = content:GetSize()
	local snap = EVO_HDV._snap or {}
	local detailW = R(400)
	local listW = cw - detailW - R(12)
	local commPct = math.floor((CFG.CommissionPct or 0) * 100)

	local function priceOk(p)
		p = math.floor(tonumber(p) or 0)
		return p >= (CFG.MinPrice or 1) and p <= (CFG.MaxPrice or 50000000)
	end
	local function arm(s, lbl, fDo)
		if (s._armedUntil or 0) > CurTime() then
			s._armedUntil = nil
			s._lbl = nil
			fDo()
		else
			s._armedUntil = CurTime() + 3
			s._lbl = lbl
			timer.Simple(3.1, function()
				if IsValid(s) and (s._armedUntil or 0) <= CurTime() then s._lbl = nil end
			end)
		end
	end
	local function isMine(w)
		return w.me == 1 or tostring(w.sid) == LocalPlayer():SteamID64()
	end
	local function myPending(wantId)
		for _, o in ipairs(snap.myOffers or {}) do
			if o.w == wantId and o.st == "pending" then return o end
		end
	end
	local function slotsFor(item_id, qty)
		local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
		local exact, total = {}, 0
		if not inv or not inv.items then return exact, total end
		local maxSlots = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
		qty = math.max(1, math.floor(tonumber(qty) or 1))
		for slot = 1, maxSlots do
			if inv.items[slot] == item_id then
				local q = INVENTORY_CONFIG.GetSlotQuantity and INVENTORY_CONFIG.GetSlotQuantity(inv, slot) or 1
				total = total + q
				if q >= qty then exact[#exact + 1] = slot end
			end
		end
		return exact, total
	end
	local function slotMeta(slot)
		local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or nil
		if not inv then return "" end
		local bits = {}
		local lvl = NCM_FORGE and NCM_FORGE.GetClientLevel and NCM_FORGE.GetClientLevel(slot) or 1
		if (lvl or 1) > 1 then bits[#bits + 1] = "Forge N" .. tostring(lvl) end
		local dur = inv.durability and tonumber(inv.durability[slot])
		if dur and dur < 100 then bits[#bits + 1] = math.floor(dur) .. "% durabilité" end
		local ench = inv.enchants and inv.enchants[slot]
		local el = enchantLines(ench, inv.items and inv.items[slot])
		if el[1] then bits[#bits + 1] = el[1].txt end
		if #bits == 0 then return "Exemplaire standard" end
		return table.concat(bits, " · ")
	end
	local function offerMeta(o, item_id)
		local bits = {}
		if (tonumber(o.f) or 1) > 1 then bits[#bits + 1] = "Forge N" .. tostring(o.f) end
		if (tonumber(o.d) or 100) < 100 then
			bits[#bits + 1] = math.floor(tonumber(o.d) or 0) .. "% durabilité"
		end
		local el = enchantLines(o.e, item_id)
		if el[1] then bits[#bits + 1] = el[1].txt end
		if #bits == 0 then return "Exemplaire standard" end
		return table.concat(bits, " · ")
	end

	-- Publication : catalogue des objets vendables, filtre par nom.
	if WANT_POST then
		local bar = vgui.Create("DPanel", content)
		bar:SetPos(0, 0)
		bar:SetSize(listW, R(36))
		bar:SetPaintBackground(false)
		Btn(bar, "RETOUR", 0, 0, R(110), R(36), false, function()
			WANT_POST = false
			EVO_HDV.RebuildTab()
		end)

		local list = vgui.Create("DScrollPanel", content)
		list:SetPos(0, R(44))
		list:SetSize(listW, ch - R(44))
		list.Paint = function() end
		styleScroll(list)

		local detail = vgui.Create("DPanel", content)
		detail:SetPos(listW + R(12), 0)
		detail:SetSize(detailW, ch)
		local buildPostDetail

		local function refreshResults()
			list:Clear()
			if #WANT_FIND < 2 then
				local hint = list:Add("DPanel")
				hint:Dock(TOP)
				hint:SetTall(R(48))
				hint:SetPaintBackground(false)
				hint.Paint = function(_, w, h)
					draw.SimpleText("Tape au moins 2 lettres.", F_SUB, R(8), h * 0.5,
						COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				return
			end
			local matches = {}
			for id in pairs(ITEMS or {}) do
				if EVO_HDV.IsSellable(id) and string.find(fold(itemName(id)), WANT_FIND, 1, true) then
					matches[#matches + 1] = id
				end
			end
			table.sort(matches, function(a, b) return fold(itemName(a)) < fold(itemName(b)) end)
			local more = #matches > 40
			if more then
				for i = #matches, 41, -1 do matches[i] = nil end
			end
			if #matches == 0 then
				local empty = list:Add("DPanel")
				empty:Dock(TOP)
				empty:SetTall(R(48))
				empty:SetPaintBackground(false)
				empty.Paint = function(_, w, h)
					draw.SimpleText("Aucun objet vendable ne correspond.", F_SUB, R(8), h * 0.5,
						COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				return
			end
			for _, id in ipairs(matches) do
				local it = itemDef(id)
				local rarCol = EVO_HDV.RarityColor(it and it.rarity)
				local nameC = trunc(itemName(id), F_ROW, listW - R(160))
				local row = list:Add("DButton")
				row:Dock(TOP)
				row:DockMargin(0, 0, R(6), R(4))
				row:SetTall(R(40))
				row:SetText("")
				row:SetCursor("hand")
				row.Paint = function(s, w, h)
					local sel = (WANT_ITEM == id)
					rndx(0, 0, 0, w, h, (sel or hovered(s)) and COL_ROW_H or COL_ROW)
					surface.SetDrawColor(rarCol)
					surface.DrawRect(R(8), R(8), R(3), h - R(16))
					draw.SimpleText(nameC, F_ROW, R(18), h * 0.5, rarCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(EVO_HDV.RarityNames[(it or {}).rarity] or "", F_SUB, w - R(10), h * 0.5,
						COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				row.DoClick = function()
					WANT_ITEM = id
					WANT_QTY = 1
					local avgS = avgOf(id)
					local mnS = mktOf(id)
					local suggested = avgS or mnS
					WANT_PRICE = (suggested and suggested >= (CFG.MinPrice or 1)) and math.floor(suggested) or 0
					buildPostDetail()
				end
			end
			if more then
				local foot = list:Add("DPanel")
				foot:Dock(TOP)
				foot:SetTall(R(28))
				foot:SetPaintBackground(false)
				foot.Paint = function(_, w, h)
					draw.SimpleText("Affine ta recherche pour voir la suite.", F_SUB, R(8), h * 0.5, COL_MUT)
				end
			end
		end

		local search = Entry(bar, R(118), 0, listW - R(118), R(36), "Nom de l'objet...")
		search.OnValueChange = function(_, v)
			WANT_FIND = fold(v)
			refreshResults()
		end
		if WANT_FIND ~= "" then search:SetValue(WANT_FIND) end
		refreshResults()

		buildPostDetail = function()
			detail:Clear()
			detail.Paint = function(_, w, h) rndx(R(8), 0, 0, w, h, Color(19, 20, 24)) end
			local item_id = WANT_ITEM
			if not item_id then
				detail.PaintOver = function(_, w, h)
					draw.SimpleText("Choisis l'objet que tu cherches", F_SUB, w * 0.5, h * 0.5,
						COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				return
			end
			detail.PaintOver = nil
			local it = itemDef(item_id)
			local rarCol = EVO_HDV.RarityColor(it and it.rarity)
			local stackMax = INVENTORY_CONFIG.GetItemStackMax and INVENTORY_CONFIG.GetItemStackMax(item_id) or 1
			WANT_QTY = math.max(1, math.min(stackMax, tonumber(WANT_QTY) or 1))

			local prev = vgui.Create("DPanel", detail)
			prev:SetPos(R(12), R(12))
			prev:SetSize(detailW - R(24), R(120))
			prev.Paint = function(_, w, h) rndx(R(6), 0, 0, w, h, Color(8, 8, 10, 255)) end
			ItemPreview(prev, item_id, 30)

			local entryY = ch - R(168)
			local info = vgui.Create("DPanel", detail)
			info:SetPos(R(12), R(140))
			info:SetSize(detailW - R(24), entryY - R(146))
			info:SetPaintBackground(false)
			info.Paint = function(_, w, h)
				draw.SimpleText(trunc(itemName(item_id), F_BIG, w), F_BIG, 0, 0, COL_TXT)
				draw.SimpleText(EVO_HDV.RarityNames[(it or {}).rarity] or "", F_SUB, 0, R(30), rarCol)
				draw.SimpleText(string.format("Active %d jours. Retire-la pour récupérer les yens.",
					math.floor((CFG.DurationHours or 168) / 24)), F_SUB, 0, R(50), COL_DIM)
				drawMarketBlock(w, R(76), item_id)
			end

			local priceW = detailW - R(24)
			if stackMax > 1 then
				local qtyW = R(90)
				local qtyEntry = Entry(detail, R(12), entryY, qtyW, R(34), "Qté", true)
				qtyEntry:SetValue(tostring(WANT_QTY))
				qtyEntry.OnValueChange = function(_, v)
					local n = math.floor(tonumber(v) or 1)
					if n < 1 then n = 1 end
					if n > stackMax then n = stackMax end
					WANT_QTY = n
				end
				priceW = detailW - R(24) - qtyW - R(8)
				local priceEntry = Entry(detail, R(12) + qtyW + R(8), entryY, priceW, R(34), "Prix total en yens", true)
				priceEntry.OnValueChange = function(_, v) WANT_PRICE = math.floor(tonumber(v) or 0) end
				if WANT_PRICE > 0 then priceEntry:SetValue(tostring(WANT_PRICE)) end
			else
				WANT_QTY = 1
				local priceEntry = Entry(detail, R(12), entryY, priceW, R(34), "Prix en yens", true)
				priceEntry.OnValueChange = function(_, v) WANT_PRICE = math.floor(tonumber(v) or 0) end
				if WANT_PRICE > 0 then priceEntry:SetValue(tostring(WANT_PRICE)) end
			end

			local fees = vgui.Create("DPanel", detail)
			fees:SetPos(R(12), entryY + R(40))
			fees:SetSize(detailW - R(24), R(70))
			fees:SetPaintBackground(false)
			fees.Paint = function(_, w, h)
				local p = WANT_PRICE
				if (tonumber(snap.myWantCount) or 0) >= (CFG.MaxActiveWants or 10) then
					draw.SimpleText("Maximum de recherches atteint.", F_SUB, 0, 0, COL_WARN)
					return
				end
				if not priceOk(p) then
					draw.SimpleText(string.format("Prix entre %s et %s ¥",
						string.Comma(CFG.MinPrice), string.Comma(CFG.MaxPrice)), F_SUB, 0, 0, COL_MUT)
					return
				end
				local fee = EVO_HDV.ListingFee(p)
				draw.SimpleText("Réservé : " .. string.Comma(p) .. " ¥ (rendu si tu retires)", F_SUB, 0, 0, COL_GOLD)
				draw.SimpleText("Taxe : " .. string.Comma(fee) .. " ¥ (non remboursable)", F_SUB, 0, R(18), COL_DIM)
				local cost = p + fee
				local short = LocalPlayer():GetEvoNWInt("Money", 0) < cost
				draw.SimpleText(short and "Fonds insuffisants" or ("Total débité : " .. string.Comma(cost) .. " ¥"),
					F_SUB, 0, R(36), short and COL_ACC or COL_DIM)
			end

			Btn(detail, "POSTER LA RECHERCHE", R(12), ch - R(48), detailW - R(24), R(38), true, function(s)
				arm(s, "CONFIRMER ?", function()
					netWantPost(item_id, WANT_PRICE, WANT_QTY)
					WANT_POST = false
					WANT_ITEM = nil
					EVO_HDV.RebuildTab()
				end)
			end, function()
				local p = WANT_PRICE
				if not priceOk(p) then return false end
				if (tonumber(snap.myWantCount) or 0) >= (CFG.MaxActiveWants or 10) then return false end
				return LocalPlayer():GetEvoNWInt("Money", 0) >= p + EVO_HDV.ListingFee(p)
			end)
		end
		buildPostDetail()
		return
	end

	-- Liste des recherches + détail (vendre, proposer, ou gérer les siennes).
	local bar = vgui.Create("DPanel", content)
	bar:SetPos(0, 0)
	bar:SetSize(listW, R(36))
	bar:SetPaintBackground(false)
	local postW = R(150)
	local search = Entry(bar, 0, 0, listW - postW - R(8), R(36), "Rechercher un objet, un joueur...")
	Btn(bar, "POSTER", listW - postW, 0, postW, R(36), true, function()
		WANT_POST = true
		WANT_ITEM = nil
		WANT_FIND = ""
		EVO_HDV.RebuildTab()
	end)

	local list = vgui.Create("DScrollPanel", content)
	list:SetPos(0, R(44))
	list:SetSize(listW, ch - R(44))
	list.Paint = function() end
	styleScroll(list)

	local detail = vgui.Create("DPanel", content)
	detail:SetPos(listW + R(12), 0)
	detail:SetSize(detailW, ch)
	local buildDetail

	local function findWant(id)
		if not id then return nil end
		for _, w in ipairs(snap.myWants or {}) do
			if w.id == id then return w end
		end
		for _, w in ipairs(snap.wants or {}) do
			if w.id == id then return w end
		end
	end

	local function addWantRow(w)
		local it = itemDef(w.i)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)
		local mine = isMine(w)
		local nameC = trunc(itemNameQty(w.i, w.q), F_ROW, listW - R(200))
		local row = list:Add("DButton")
		row:Dock(TOP)
		row:DockMargin(0, 0, R(6), R(4))
		row:SetTall(R(52))
		row:SetText("")
		row:SetCursor("hand")
		row.Paint = function(s, bw, bh)
			local sel = (WANT_SEL == w.id)
			rndx(0, 0, 0, bw, bh, (sel or hovered(s)) and COL_ROW_H or COL_ROW)
			surface.SetDrawColor(rarCol)
			surface.DrawRect(R(8), R(10), R(3), bh - R(20))
			draw.SimpleText(nameC, F_ROW, R(18), bh * 0.32, rarCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local sub
			if w.st == "filled" then
				local who = (w.sn and w.sn ~= "") and w.sn or "un joueur"
				sub = "Pourvue par " .. who .. " · à récupérer"
			elseif mine then
				local rem = remainingOf(w)
				if rem <= 0 then
					sub = "Expirée · retire-la pour récupérer tes yens"
				else
					sub = "Ta recherche · " .. EVO_HDV.FormatRemaining(rem)
					local nOff = #(w.off or {})
					if nOff > 0 then sub = sub .. " · " .. nOff .. " proposition(s)" end
				end
			else
				sub = "Par " .. tostring(w.s or "?") .. " · " .. EVO_HDV.FormatRemaining(remainingOf(w))
				local pend = myPending(w.id)
				if pend then sub = sub .. " · offre envoyée" end
			end
			local subCol = (w.st == "filled" or (mine and remainingOf(w) <= 0 and w.st ~= "filled")) and COL_WARN or COL_DIM
			draw.SimpleText(trunc(sub, F_SUB, listW - R(200)), F_SUB, R(18), bh * 0.72, subCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if MUGEN and MUGEN.DrawMoneyLine then
				MUGEN.DrawMoneyLine(string.Comma(w.p or 0) .. " ¥", F_ROW, bw - R(12), bh * 0.5,
					COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		row.DoClick = function()
			WANT_SEL = w.id
			WANT_SLOT = nil
			WANT_OFFER_PRICE = 0
			buildDetail(w)
		end
	end

	local function refreshBrowse()
		list:Clear()
		local nReclaim = 0
		for _, o in ipairs(snap.myOffers or {}) do
			if o.st == "reclaim" then
				nReclaim = nReclaim + 1
				local nameC = trunc(itemNameQty(o.i, o.q), F_ROW, listW - R(220))
				local row = list:Add("DPanel")
				row:Dock(TOP)
				row:DockMargin(0, 0, R(6), R(4))
				row:SetTall(R(48))
				row:SetPaintBackground(false)
				row.Paint = function(s, bw, bh)
					rndx(0, 0, 0, bw, bh, hovered(s) and COL_ROW_H or COL_ROW)
					draw.SimpleText(nameC, F_ROW, R(12), bh * 0.32, COL_WARN, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText("Objet à récupérer", F_SUB, R(12), bh * 0.72, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				local b = Btn(row, "RÉCUPÉRER", 0, R(7), R(140), R(34), true, function()
					netWantPull(o.id)
				end)
				row.PerformLayout = function(_, bw)
					if IsValid(b) then b:SetPos(bw - R(152), R(7)) end
				end
			end
		end
		local shown = 0
		local seen = {}
		local function consider(w)
			if seen[w.id] then return end
			seen[w.id] = true
			if WANT_FILTER ~= "" then
				local blob = fold(itemName(w.i) .. " " .. tostring(w.s or "") .. " " .. tostring(w.sn or ""))
				if not string.find(blob, WANT_FILTER, 1, true) then return end
			end
			shown = shown + 1
			addWantRow(w)
		end
		for _, w in ipairs(snap.myWants or {}) do consider(w) end
		for _, w in ipairs(snap.wants or {}) do consider(w) end
		if shown == 0 and nReclaim == 0 then
			local empty = list:Add("DPanel")
			empty:Dock(TOP)
			empty:SetTall(R(60))
			empty:SetPaintBackground(false)
			empty.Paint = function(_, w, h)
				local msg = WANT_FILTER ~= "" and "Aucun résultat." or "Aucune recherche. Poste celle d'un objet que tu cherches."
				draw.SimpleText(msg, F_SUB, w * 0.5, h * 0.5, COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
	local fillingFilter = false
	search.OnValueChange = function(_, v)
		if fillingFilter then return end
		WANT_FILTER = fold(v)
		refreshBrowse()
	end
	if WANT_FILTER ~= "" then
		fillingFilter = true
		search:SetValue(WANT_FILTER)
		fillingFilter = false
	end
	refreshBrowse()

	buildDetail = function(w)
		detail:Clear()
		detail.Paint = function(_, dw, dh) rndx(R(8), 0, 0, dw, dh, Color(19, 20, 24)) end
		if not w then
			detail.PaintOver = function(_, dw, dh)
				draw.SimpleText("Sélectionne une recherche", F_SUB, dw * 0.5, dh * 0.42,
					COL_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(string.format("%d/%d recherches actives",
					tonumber(snap.myWantCount) or 0, CFG.MaxActiveWants or 10),
					F_SUB, dw * 0.5, dh * 0.42 + R(22), COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		detail.PaintOver = nil
		local it = itemDef(w.i)
		local rarCol = EVO_HDV.RarityColor(it and it.rarity)
		local mine = isMine(w)
		local expired = remainingOf(w) <= 0

		local prev = vgui.Create("DPanel", detail)
		prev:SetPos(R(12), R(12))
		prev:SetSize(detailW - R(24), R(110))
		prev.Paint = function(_, dw, dh) rndx(R(6), 0, 0, dw, dh, Color(8, 8, 10, 255)) end
		ItemPreview(prev, w.i, 30)

		local info = vgui.Create("DPanel", detail)
		info:SetPos(R(12), R(128))
		info:SetSize(detailW - R(24), R(108))
		info:SetPaintBackground(false)
		info.Paint = function(_, dw, dh)
			local y = 0
			draw.SimpleText(trunc(itemNameQty(w.i, w.q), F_BIG, dw), F_BIG, 0, y, COL_TXT)
			y = y + R(28)
			draw.SimpleText(EVO_HDV.RarityNames[(it or {}).rarity] or "", F_SUB, 0, y, rarCol)
			y = y + R(18)
			local who
			if w.st == "filled" then
				who = "Pourvue par " .. (((w.sn and w.sn ~= "") and w.sn) or "un joueur")
			elseif mine then
				who = expired and "Expirée" or ("Expire dans " .. EVO_HDV.FormatRemaining(remainingOf(w)))
			else
				who = "Demandé par " .. tostring(w.s or "?")
			end
			draw.SimpleText(who, F_SUB, 0, y, COL_DIM)
			y = y + R(22)
			if MUGEN and MUGEN.DrawMoneyLine then
				MUGEN.DrawMoneyLine(string.Comma(w.p or 0) .. " ¥", F_BIG, 0, y, COL_GOLD)
			end
		end

		if w.st == "filled" and mine then
			local note = vgui.Create("DPanel", detail)
			note:SetPos(R(12), R(250))
			note:SetSize(detailW - R(24), R(40))
			note:SetPaintBackground(false)
			note.Paint = function(_, dw, dh)
				draw.SimpleText("L'objet t'attend. Libère une place si ton sac est plein.", F_SUB, 0, 0, COL_DIM)
			end
			Btn(detail, "RÉCUPÉRER", R(12), ch - R(48), detailW - R(24), R(38), true, function()
				netWantTake(w.id)
			end)
			return
		end

		if mine then
			local scroll = vgui.Create("DScrollPanel", detail)
			scroll:SetPos(R(12), R(244))
			scroll:SetSize(detailW - R(24), ch - R(244) - R(60))
			scroll.Paint = function() end
			styleScroll(scroll)
			local offers = w.off or {}
			if expired then
				local note = scroll:Add("DPanel")
				note:Dock(TOP)
				note:SetTall(R(36))
				note:SetPaintBackground(false)
				note.Paint = function(_, dw, dh)
					draw.SimpleText("Expirée. Retire-la pour rendre les yens et les objets.", F_SUB, 0, 0, COL_WARN)
				end
			elseif #offers == 0 then
				local note = scroll:Add("DPanel")
				note:Dock(TOP)
				note:SetTall(R(36))
				note:SetPaintBackground(false)
				note.Paint = function(_, dw, dh)
					draw.SimpleText("Aucune proposition pour l'instant.", F_SUB, 0, dh * 0.5,
						COL_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			for _, o in ipairs(offers) do
				local meta = offerMeta(o, w.i)
				local diff = (o.p or 0) - (w.p or 0)
				local diffTxt
				if diff > 0 then
					diffTxt = "Tu paies " .. string.Comma(diff) .. " ¥ de plus"
				elseif diff < 0 then
					diffTxt = "On te rend " .. string.Comma(-diff) .. " ¥"
				else
					diffTxt = "Au prix demandé"
				end
				local row = scroll:Add("DPanel")
				row:Dock(TOP)
				row:DockMargin(0, 0, 0, R(6))
				row:SetTall(R(96))
				row:SetPaintBackground(false)
				row.Paint = function(s, dw, dh)
					rndx(R(4), 0, 0, dw, dh, COL_ROW)
					draw.SimpleText(trunc(tostring(o.s or "?"), F_ROW, dw - R(150)), F_ROW, R(8), R(8), COL_TXT)
					if MUGEN and MUGEN.DrawMoneyLine then
						MUGEN.DrawMoneyLine(string.Comma(o.p or 0) .. " ¥", F_ROW, dw - R(8), R(8),
							COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
					end
					draw.SimpleText(trunc(meta, F_SUB, dw - R(16)), F_SUB, R(8), R(32), COL_DIM)
					draw.SimpleText(diffTxt, F_SUB, R(8), R(50), diff > 0 and COL_WARN or COL_GREEN)
				end
				if not expired then
					Btn(row, "ACCEPTER", R(8), R(64), R(110), R(26), true, function(s)
						arm(s, "ACCEPTER ?", function() netWantAccept(o.id) end)
					end, function()
						if diff <= 0 then return true end
						return LocalPlayer():GetEvoNWInt("Money", 0) >= diff
					end)
					Btn(row, "REFUSER", R(126), R(64), R(100), R(26), false, function()
						netWantRefuse(o.id)
					end)
				end
			end
			Btn(detail, "RETIRER LA RECHERCHE", R(12), ch - R(48), detailW - R(24), R(38), false, function(s)
				arm(s, "CONFIRMER ?", function() netWantCancel(w.id) end)
			end)
			return
		end

		local pend = myPending(w.id)
		if pend then
			local note = vgui.Create("DPanel", detail)
			note:SetPos(R(12), R(250))
			note:SetSize(detailW - R(24), R(80))
			note:SetPaintBackground(false)
			note.Paint = function(_, dw, dh)
				draw.SimpleText("Proposition envoyée", F_ROW, 0, 0, COL_TXT)
				draw.SimpleText(string.Comma(pend.p or 0) .. " ¥ · en attente", F_SUB, 0, R(26), COL_GOLD)
				draw.SimpleText("L'objet est réservé jusqu'à sa réponse.", F_SUB, 0, R(46), COL_DIM)
			end
			Btn(detail, "ANNULER L'OFFRE", R(12), ch - R(48), detailW - R(24), R(38), false, function()
				netWantPull(pend.id)
			end)
			return
		end

		local exact, total = slotsFor(w.i, w.q)
		local haveSlot = false
		for _, slot in ipairs(exact) do
			if slot == WANT_SLOT then haveSlot = true break end
		end
		if not haveSlot then WANT_SLOT = exact[1] end

		local body = vgui.Create("DPanel", detail)
		body:SetPos(R(12), R(244))
		body:SetSize(detailW - R(24), ch - R(244) - R(8))
		body:SetPaintBackground(false)
		if #exact == 0 then
			body.Paint = function(_, dw, dh)
				local msg = total > 0 and "Regroupe la quantité dans un même emplacement."
					or "Tu n'as pas cet objet."
				draw.SimpleText(msg, F_SUB, 0, 0, COL_MUT)
			end
			return
		end

		local metaCache = {}
		local function cachedMeta(slot)
			local m = metaCache[slot]
			if not m then
				m = slotMeta(slot)
				metaCache[slot] = m
			end
			return m
		end
		local sc = vgui.Create("DHorizontalScroller", body)
		sc:SetPos(0, 0)
		sc:SetSize(detailW - R(24), R(58))
		sc:SetOverlap(-R(6))
		for _, slot in ipairs(exact) do
			local b = vgui.Create("DButton", sc)
			b:SetText("")
			b:SetSize(R(72), R(54))
			b:SetCursor("hand")
			b.Paint = function(s, dw, dh)
				local sel = (WANT_SLOT == slot)
				rndx(R(4), 0, 0, dw, dh, sel and COL_ROW_H or COL_ROW)
				if sel then
					surface.SetDrawColor(COL_ACC)
					surface.DrawOutlinedRect(0, 0, dw - 1, dh - 1)
				end
			end
			ItemPreview(b, w.i, 28)
			b.PaintOver = function(_, dw, dh)
				draw.SimpleText(trunc(cachedMeta(slot), F_MONO, dw - R(4)), F_MONO, dw * 0.5, dh - R(2),
					COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			end
			b.DoClick = function() WANT_SLOT = slot end
			sc:AddPanel(b)
		end

		local hint = vgui.Create("DPanel", body)
		hint:SetPos(0, R(64))
		hint:SetSize(detailW - R(24), R(78))
		hint:SetPaintBackground(false)
		hint.Paint = function(_, dw, dh)
			local meta = WANT_SLOT and cachedMeta(WANT_SLOT) or ""
			draw.SimpleText(trunc(meta, F_SUB, dw), F_SUB, 0, 0, COL_DIM)
			if WANT_SLOT then
				draw.SimpleText("À ce prix tu reçois " .. string.Comma(EVO_HDV.Proceeds(w.p or 0)) .. " ¥",
					F_SUB, 0, R(16), COL_GREEN)
			end
			draw.SimpleText("Vendre livre cet exemplaire tout de suite.", F_SUB, 0, R(36), COL_MUT)
			local offerP = WANT_OFFER_PRICE
			if priceOk(offerP) then
				draw.SimpleText("Proposition : tu recevrais " .. string.Comma(EVO_HDV.Proceeds(offerP))
					.. " ¥ (commission " .. commPct .. "%)", F_SUB, 0, R(54), COL_DIM)
			else
				draw.SimpleText("Proposer : l'acheteur accepte ou refuse.", F_SUB, 0, R(54), COL_MUT)
			end
		end

		Btn(body, "VENDRE À CE PRIX", 0, R(148), detailW - R(24), R(36), true, function(s)
			arm(s, "CONFIRMER LA VENTE ?", function()
				if WANT_SLOT then netWantFill(w.id, WANT_SLOT) end
			end)
		end, function() return WANT_SLOT ~= nil end)

		local priceEntry = Entry(body, 0, R(192), detailW - R(24), R(34), "Autre prix en yens", true)
		priceEntry.OnValueChange = function(_, v) WANT_OFFER_PRICE = math.floor(tonumber(v) or 0) end
		Btn(body, "PROPOSER CE PRIX", 0, R(232), detailW - R(24), R(36), false, function(s)
			arm(s, "CONFIRMER L'OFFRE ?", function()
				if WANT_SLOT then netWantOffer(w.id, WANT_SLOT, WANT_OFFER_PRICE) end
			end)
		end, function() return WANT_SLOT ~= nil and priceOk(WANT_OFFER_PRICE) end)
	end

	buildDetail(findWant(WANT_SEL))
end

buildTab = function(content, id)
	if id == "sell" then buildSellTab(content)
	elseif id == "want" then buildWantTab(content)
	elseif id == "mine" then buildMineTab(content)
	elseif id == "hist" then buildHistTab(content)
	else buildBuyTab(content) end
end

-- ── Reseau : nouvelle mise en vente -> canal chat HDV ────────────────────────
net.Receive("EVO:HDV:Announce", function()
	local item_id = net.ReadString()
	local price = net.ReadUInt(32)
	local isWant = net.ReadBool()
	local qty = net.ReadUInt(16)
	local it = itemDef(item_id)
	local name = isWant and itemNameQty(item_id, qty) or ((it and it.name) or tostring(item_id))
	local rarName = EVO_HDV.RarityNames[(it and it.rarity) or ""] or ""
	local priceStr = string.Comma(price) .. " ¥"
	local msg
	if isWant then
		if rarName ~= "" then
			msg = string.format("Recherche : %s (%s) pour %s", name, rarName, priceStr)
		else
			msg = string.format("Recherche : %s pour %s", name, priceStr)
		end
	elseif rarName ~= "" then
		msg = string.format("%s (%s) mis en vente pour %s", name, rarName, priceStr)
	else
		msg = string.format("%s mis en vente pour %s", name, priceStr)
	end
	if LZY_Chat_AddSystemLine then
		LZY_Chat_AddSystemLine("hdv", msg)
	else
		chat.AddText(EVO_HDV.RarityColor(it and it.rarity), "[HDV] ", COL_TXT, msg)
	end
end)

-- ── Reseau : snapshot serveur ────────────────────────────────────────────────
net.Receive("EVO:HDV:Snap", function()
	local bOpen = net.ReadBool()
	local len = net.ReadUInt(32)
	local data = len > 0 and net.ReadData(len) or nil
	if not data then return end
	local json = util.Decompress(data)
	if not json or json == "" then return end
	local ok, tbl = pcall(util.JSONToTable, json)
	if not ok or not istable(tbl) then return end
	EVO_HDV._snap = tbl
	EVO_HDV._snapAt = CurTime()
	if bOpen then
		EVO_HDV.Open()
	elseif IsValid(EVO_HDV._frame) then
		EVO_HDV.RebuildTab()
	end
end)

-- Sac resynchronise pendant que l'onglet VENDRE est ouvert (vente acceptee,
-- objet rendu...) : reconstruire la grille pour rester fidele au serveur.
hook.Add("LZY_Inventory_Synced", "EVO_HDV::RefreshSellTab", function()
	if IsValid(EVO_HDV._frame) and (TAB == "sell" or TAB == "want") then
		EVO_HDV.RebuildTab()
	end
end)

-- ── Prompt central « [E] ... » (evo_npc_core) ────────────────────────────────
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["hdv"] = {
	fGetTarget = function()
		if IsValid(EVO_HDV._frame) then return nil end
		local lp = LocalPlayer()
		if not IsValid(lp) then return nil end
		local maxD = (CFG.PromptDistance or 160)
		local maxZ = (CFG.MaxZDelta or 200)
		local lpPos = lp:GetPos()
		local best, bestD = nil, maxD * maxD
		for _, e in ipairs(ents.FindByClass("evo_npc_hdv")) do
			if IsValid(e) and math.abs(e:GetPos().z - lpPos.z) <= maxZ then
				local d = e:GetPos():DistToSqr(lpPos)
				if d <= bestD then best, bestD = e, d end
			end
		end
		return best
	end,
	fLabel = function() return "[E] " .. (CFG.NPCName or "Hôtel des ventes") end,
	fSub = function() return CFG.NPCSubtitle or "" end,
}
