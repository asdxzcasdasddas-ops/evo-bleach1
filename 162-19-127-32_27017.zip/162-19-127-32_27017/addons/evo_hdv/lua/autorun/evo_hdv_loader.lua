-- "addons\\evo_hdv\\lua\\autorun\\evo_hdv_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- EVO HDV (Hotel des ventes) : marche global entre joueurs, cross-serveur (MySQL partagee).
-- sh_config = regles + helpers partages ; sv_hdv = autorite (escrow, achats, DB) ;
-- cl_hdv = vue pure (UI DA Atelier). PNJ d'acces : lua/entities/evo_npc_hdv.

if SERVER then
	AddCSLuaFile("evo_hdv/sh_config.lua")
	AddCSLuaFile("evo_hdv/cl_hdv.lua")
	include("evo_hdv/sh_config.lua")
	include("evo_hdv/sv_hdv.lua")
else
	include("evo_hdv/sh_config.lua")
	include("evo_hdv/cl_hdv.lua")
end
