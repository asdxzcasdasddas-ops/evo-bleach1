-- "addons\\evo_science\\lua\\autorun\\sh_science_medic.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE — TABLE MÉDICALE (partagé, 08/18). Craft des MÉDECINS (division
-- de soin, PAS la division scientifique) : infusions, médicaments, vaccins,
-- seringues — à partir des MÊMES ingrédients de récolte que le laboratoire.
--
-- FLUX (2 étapes, demande user « sans trop d'étapes ») :
--   1) MORTIER : mélange libre déposé, puis MINI-JEU du pilon À LA SOURIS
--      (mouvements circulaires réguliers). Raté = ingrédients GÂCHÉS.
--   2) PRÉPARATION : 30 s sur la table, puis récupération.
-- Découverte par l'EXPÉRIMENTATION comme les potions : un mélange inconnu se
-- pile puis se révèle inutilisable ; une réussite consigne la recette POUR LA
-- FACTION (même table BDD evo_science_recipes, ids préfixés "med_").
--
-- TOUT VIT DANS L'ATELIER MÉDECIN d'evo_craft (demande user 08/18 : « des
-- onglets de l'UI atelier, pas un panneau externe ») : la zone = la STATION
-- rôle "soin" (EVO_CRAFT.CurrentStation, partagé), les onglets Mortier/Carnet
-- sont construits par cl_science_medic dans le détail de l'atelier — même
-- pattern que l'onglet Forge de l'atelier combat.
--
-- CENTRALISÉ SUR L'EXISTANT (règle projet) :
--   ingrédients = HUB.Mushrooms / HUB.Plants + les infusions de la table
--   (potions du labo EXCLUES, demande user 08/18) ; carnet = MÊME livre DHTML que les scientifiques
--   (EVO_SCIENCE.BuildRecipeBookHTML, cl_science_hub) ; gate médecin =
--   EvoHealBed.CanHeal ; immunité vaccin = EVO_SCIENCE.GrantImmunity (pipeline
--   maladies) ; geste de conso = EVO_SCIENCE.EatGesture ; notifs/comptages =
--   EVO_SCIENCE.Notify/CountItem.
-- ============================================================================

EVO_SCIENCE = EVO_SCIENCE or {}
EVO_SCIENCE.CFG = EVO_SCIENCE.CFG or {}
local CFG = EVO_SCIENCE.CFG
CFG.Hub = CFG.Hub or {}
local HUB = CFG.Hub

-- ── Modèles (assets user 08/18) ──────────────────────────────────────────────
HUB.MedicModels = {
	seringue      = "models/evo/props/items/medic/medic_01/evo_73d907fc7beb005c2b.mdl",
	mix_herbes    = "models/evo/props/items/medic/medic_02/evo_92b20a3cf53ade90aa.mdl", -- 6 skins
	pilules_long  = "models/evo/props/items/medic/medic_03/evo_4439f077e42a074258.mdl", -- 3 skins
	pilules_rond  = "models/evo/props/items/medic/medic_04/evo_779a7fdb22c804c0eb.mdl", -- 3 skins
	tube_pilules  = "models/evo/props/items/medic/medic_05/evo_92086caf577aaa798f.mdl", -- 3 skins
	vaccin        = "models/evo/props/items/medic/medic_06/evo_11254adf144ae83866.mdl", -- 3 skins
	mortier       = "models/evo/props/items/medic/mortier/evo_mortier_bea9fe937c.mdl",
	pilon         = "models/evo/props/items/medic/mortier/evo_pilon_tgr5a9fe937c.mdl",
}

-- Verrerie de DÉCOR : placée avec l'outil des établis (evo_etablie), pour
-- habiller la table médicale. Aucune logique dessus, c'est de la scène.
HUB.MedicDecor = {
	{ id = "med_becher",     name = "Bécher",             model = "models/evo/props/items/medic/becher/evo_becher_2f6de8f4b5.mdl" },
	{ id = "med_entonnoir",  name = "Entonnoir",          model = "models/evo/props/items/medic/entonnoir/evo_entonnoir_9bfe560f63.mdl" },
	{ id = "med_eprouvette", name = "Éprouvette graduée", model = "models/evo/props/items/medic/eprouvette_graduee/evo_eprouvette_graduee_d2bb99fa3c.mdl" },
	{ id = "med_erlenmeyer", name = "Erlenmeyer",         model = "models/evo/props/items/medic/erlenmeyer/evo_erlenmeyer_fcdd7b63af.mdl" },
	{ id = "med_fiole",      name = "Fiole jaugée",       model = "models/evo/props/items/medic/fiole_jaugee/evo_fiole_jaugee_1d00b0497e.mdl" },
	{ id = "med_mortier",    name = "Mortier",            model = "models/evo/props/items/medic/mortier/evo_mortier_bea9fe937c.mdl" },
	{ id = "med_pilon",      name = "Pilon",              model = "models/evo/props/items/medic/mortier/evo_pilon_tgr5a9fe937c.mdl" },
	{ id = "med_pipette",    name = "Pipette",            model = "models/evo/props/items/medic/pipette/evo_pipette_cc16709b79.mdl" },
	{ id = "med_tube_essai", name = "Tube à essai",       model = "models/evo/props/items/medic/tube_essai/evo_tube_essai_2834fdd0a7.mdl" },
	{ id = "med_verre",      name = "Verre mesureur",     model = "models/evo/props/items/medic/verre_mesureur/evo_verre_mesureur_4d45466fb8.mdl" },
}

-- ── Zone = la STATION D'ATELIER SOIN d'evo_craft ─────────────────────────────
-- Plus de zone médicale dédiée : l'id de table est dérivé de la station rôle
-- "soin" où se trouve le joueur (cylindre PARTAGÉ EVO_CRAFT.CurrentStation :
-- le client construit l'onglet et le serveur revalide chaque net pareil).
function EVO_SCIENCE.MedicZoneIdFor(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return nil end
	if not (EVO_CRAFT and EVO_CRAFT.CurrentStation) then return nil end
	local st = EVO_CRAFT.CurrentStation(ply)
	if not (st and st.role == "soin") then return nil end
	return string.format("medatelier:%s:%d:%d", game.GetMap(),
		math.floor(st.pos.x), math.floor(st.pos.y))
end

-- Médecin ? = le MÊME droit que « Soigner la vie » (division de soin ou SA).
-- On ne réinvente pas un gate : si le heal bed change sa règle, la table suit.
function EVO_SCIENCE.IsMedic(ply)
	return EvoHealBed ~= nil and EvoHealBed.CanHeal ~= nil and EvoHealBed.CanHeal(ply)
end

-- ── Réglages du craft ────────────────────────────────────────────────────────
HUB.MedPrepSec        = 30  -- étape 2 : préparation sur la table (niveau 1)

-- ── NIVEAU D'ATELIER SOIN (evo_craft, rôle "soin") : à quoi il SERT (user
-- 08/19). Sans gate par recette : verrouiller un dosage révèlerait qu'il
-- correspond à une recette (la découverte reste aveugle). À la place :
--   1) XP par préparation RÉUSSIE (par catégorie),
--   2) le repos RACCOURCIT avec le niveau (30 s -> 40% au niveau max),
--   3) chance d'une DOSE BONUS sur une réussite (jusqu'à MedBonusBatchMax).
HUB.MedXP = { infusion = 10, pilule = 14, vaccin = 22, outil = 18 }
HUB.MedPrepMinFrac   = 0.4  -- fraction de MedPrepSec au niveau d'atelier max
HUB.MedBonusBatchMax = 0.25 -- chance max (niveau max) d'une dose supplémentaire

-- ── ÉTOILES (user 08/19, MIROIR des PotionStars du labo) : le CŒUR du rôle du
-- niveau d'atelier soin. Concerne les produits à effets CHIFFRÉS directs (les
-- 6 infusions + la seringue) ; vaccins, médicament, tubes et calmant restent
-- 1★ (effets booléens ou indirects). nFxMult multiplie les effets, nCostMult
-- les ingrédients CONSOMMÉS (le mélange déposé garde les doses de la recette,
-- même règle que le labo). L'XP gagnée est aussi multipliée par l'étoile.
HUB.MedStars = {
	[1] = { nFxMult = 1,   nCostMult = 1, nCraftLevel = 0 },
	[2] = { nFxMult = 1.5, nCostMult = 2, nCraftLevel = 10 },
	[3] = { nFxMult = 2,   nCostMult = 3, nCraftLevel = 20 },
}

-- Produit éligible aux étoiles ? = effets chiffrés scalables, jamais un vaccin.
function EVO_SCIENCE.MedStarrable(sId)
	local fx = HUB.MedEffects and HUB.MedEffects[sId]
	if not fx or fx.sVaccin then return false end
	return (fx.nHealPct or fx.nRegenPct or fx.nReiatsuPct or fx.nReopCutPct or fx.nInjectPct) ~= nil
end

-- Id de la variante étoilée ("infusion_verte_2s"…) ; 1★ = id de base.
function EVO_SCIENCE.MedStarId(sId, nStar)
	return (nStar or 1) >= 2 and (sId .. "_" .. nStar .. "s") or sId
end
HUB.MedMixMaxTypes    = 4   -- variétés max dans le mortier
HUB.MedMixMaxPerType  = 5   -- exemplaires max d'une même variété
-- CRAFT EN SÉRIE (user 09/15) : préparations par pilage. Ingrédients ×N au
-- dépôt, doses ×N à la récupération, un seul pilage et un seul repos.
HUB.MedMaxBatch       = 10
-- Mini-jeu du pilon : N tours complets, à vitesse RÉGULIÈRE. Trop brusque =
-- la jauge de casse monte ; pleine = ingrédients gâchés (demande user).
HUB.MedGrindTurns     = 8    -- tours de pilon à accomplir
HUB.MedGrindMinSpeed  = 2.0  -- rad/s : en-dessous, rien ne se broie
HUB.MedGrindMaxSpeed  = 9.0  -- rad/s : au-dessus, plus de progrès
HUB.MedGrindBreakAt   = 14.0 -- rad/s : geste brutal, la casse monte
HUB.MedSeringueCD     = 120  -- s entre deux injections de soin (par médecin)
HUB.MedSeringueRange  = 120  -- portée de l'injection sur une cible
-- Injection sur AUTRUI (user 08/18) : temps de préparation pendant lequel la
-- cible ne doit PAS bouger (tolérance en unités : petits ajustements ok, un
-- déplacement casse). S'injecter soi-même reste immédiat.
HUB.MedSeringueChannel = 3   -- s de préparation avant l'effet
HUB.MedSeringueMoveTol = 70  -- déplacement max de la cible pendant la préparation

-- ── Catégories (couleurs du carnet + de l'UI) ────────────────────────────────
HUB.MedCategories = {
	infusion = { sName = "Infusion",   sHex = "#3d7a4f" },
	pilule   = { sName = "Médicament", sHex = "#7a5a9e" },
	vaccin   = { sName = "Vaccin",     sHex = "#2f6f8f" },
	outil    = { sName = "Matériel",   sHex = "#8a6415" },
	masque   = { sName = "Protection", sHex = "#4f7a8a" },
}

-- ── Masque médical : réglages (partagés serveur + client) ────────────────────
-- États : STÉRILE (durabilité > MaskUsedPct, non contaminé) = bloque toute
-- exposition à la contagion. USÉ (≤ MaskUsedPct) = protection partielle (plus
-- de sur-exposition au contact rapproché). CONTAMINÉ = un malade l'a porté :
-- le masque garde sa maladie et la refile à qui le porte. L'état se lit au
-- survol d'inventaire (demande user 08/24) ; la stérilisation d'un médecin
-- reste le seul moyen de NETTOYER un masque contaminé.
HUB.MaskUsedPct         = 30    -- sous ce % de durabilité : usé
HUB.MaskContagionChance = 0.12  -- jet par sweep (15 s) en portant un masque contaminé
HUB.MaskSterilizeCost   = "pilule_antiseptique" -- consommé par la stérilisation

-- ── Recettes (ids BDD préfixés "med_" à l'enregistrement) ────────────────────
-- PLANTES ET CHAMPIGNONS UNIQUEMENT, à GROS DOSAGES (rééquilibrage user 08/18 :
-- rien du labo, et la médecine se mérite). Les variétés restent UNIVERSELLES
-- (aucune exclusive de map) : un médecin soigne sans voyager, mais il cueille
-- LONGTEMPS — les recettes sérieuses reposent sur les rares (amanite, coprin,
-- fougère ~10% des pousses) et les épiques (girolle, menthe ~4%).
-- CHAÎNE DE CRAFT (user 08/18) : les INJECTABLES consomment des INFUSIONS de
-- la table comme base (l'infusion assortie à la maladie pour les vaccins) —
-- MedIngredientAllowed les readmet au mortier pour ça.
HUB.MedRecipes = {
	-- ── Infusions (sachets, bus directement) ─────────────────────────────
	{ id = "infusion_verte", sName = "Infusion verte", sCat = "infusion", nSkin = 0,
	  sDesc = "Le classique des infirmeries : réconforte et referme les petites plaies.",
	  sQuote = "Une tasse chaude a sauvé plus d'âmes qu'on ne le croit.",
	  tIngredients = { herbe_reishi = 4, sauge_ames = 3 } },
	{ id = "infusion_bleue", sName = "Infusion bleue", sCat = "infusion", nSkin = 1,
	  sDesc = "Apaise les circuits spirituels et fait remonter le reiatsu.",
	  sQuote = "Le calme est un réservoir que chacun porte en soi.",
	  tIngredients = { feuille_lune = 4, herbe_reishi = 3 } },
	{ id = "infusion_rouge", sName = "Infusion rouge", sCat = "infusion", nSkin = 2,
	  sDesc = "Réchauffe le corps meurtri : les chairs se remettent plus vite d'une opération.",
	  sQuote = "La chaleur recoud ce que le froid a figé.",
	  tIngredients = { sauge_ames = 4, bolet_hueco = 3 } },
	{ id = "infusion_emeraude", sName = "Infusion émeraude", sCat = "infusion", nSkin = 3,
	  sDesc = "Verte et bleue mêlées : soigne le corps et remplit l'esprit.",
	  sQuote = "Soigner l'un sans l'autre, c'est ne soigner personne.",
	  tIngredients = { herbe_reishi = 4, feuille_lune = 4, girolle_ectoplasme = 2 } },
	{ id = "infusion_ambree", sName = "Infusion ambrée", sCat = "infusion", nSkin = 4,
	  sDesc = "Verte et rouge mêlées : le grand remontant des lendemains d'opération.",
	  sQuote = "On ne guérit pas plus vite en serrant les dents. Si : un peu.",
	  tIngredients = { herbe_reishi = 4, sauge_ames = 4, girolle_ectoplasme = 2 } },
	{ id = "infusion_violette", sName = "Infusion violette", sCat = "infusion", nSkin = 5,
	  sDesc = "Rouge et bleue mêlées : remet d'aplomb l'esprit et efface les séquelles.",
	  sQuote = "L'esprit clair, le corps suit.",
	  tIngredients = { feuille_lune = 4, sauge_ames = 4, girolle_ectoplasme = 2 } },
	-- ── Médicaments (pilules) ────────────────────────────────────────────
	{ id = "medicament", sName = "Médicament", sCat = "pilule", nBatch = 2,
	  sDesc = "Cachets blancs contre l'intoxication alimentaire. Deux par préparation.",
	  sQuote = "Le champignon inconnu se mange deux fois : la seconde chez le médecin.",
	  tIngredients = { champignon_reiatsu = 4, menthe_limbes = 2 } },
	{ id = "tube_antiseptique", sName = "Tube d'antiseptique", sCat = "pilule",
	  sDesc = "Tube de trois cachets verts : le corps repousse toute contagion un temps.",
	  sQuote = "La meilleure infection est celle qu'on n'attrape pas.",
	  tIngredients = { coprin_spectral = 4, herbe_reishi = 4 } },
	{ id = "tube_antidouleur", sName = "Tube d'antidouleur", sCat = "pilule",
	  sDesc = "Tube de trois cachets rouges : le corps oublie la moitié d'une opération ratée.",
	  sQuote = "La douleur enseigne, puis elle encombre.",
	  tIngredients = { amanite_ames = 4, sauge_ames = 4 } },
	{ id = "tube_calmant", sName = "Tube de calmant", sCat = "pilule",
	  sDesc = "Tube de trois cachets bleus : dissipe la Peur qui paralyse les combattants.",
	  sQuote = "Le courage se prescrit rarement. Rarement n'est pas jamais.",
	  tIngredients = { feuille_lune = 4, menthe_limbes = 2 } },
	-- ── Vaccins (immunité préventive 24 h) : la BASE est l'INFUSION assortie
	-- (chaîne de craft : la table produit, la table réutilise), complétée de
	-- récolte rare + fougère spectrale commune. Les crafts les plus longs.
	{ id = "vaccin_ecarlate", sName = "Vaccin écarlate", sCat = "vaccin", nSkin = 0,
	  sDesc = "Immunise 24 h contre la Fièvre écarlate. Se pique avant, et guérit sur-le-champ si le mal est déjà là.",
	  sQuote = "Prévenir est le seul remède qui ne laisse pas de cicatrice.",
	  tIngredients = { infusion_verte = 2, amanite_ames = 3, champignon_reiatsu = 4, fougere_spectrale = 2 } },
	{ id = "vaccin_verdatre", sName = "Vaccin verdâtre", sCat = "vaccin", nSkin = 1,
	  sDesc = "Immunise 24 h contre la Peste verdâtre. Se pique avant, et guérit sur-le-champ si le mal est déjà là.",
	  sQuote = "Le souffle qu'on protège n'a jamais à être rendu.",
	  tIngredients = { infusion_verte = 2, coprin_spectral = 4, feuille_lune = 3, fougere_spectrale = 2 } },
	{ id = "vaccin_rose", sName = "Vaccin rosé", sCat = "vaccin", nSkin = 2,
	  sDesc = "Immunise 24 h contre le Mal rosé. Se pique avant, et guérit sur-le-champ si le mal est déjà là.",
	  sQuote = "La main qui tremble déjà n'a plus besoin d'être affaiblie.",
	  tIngredients = { infusion_violette = 2, amanite_ames = 3, menthe_limbes = 2, fougere_spectrale = 2 } },
	-- ── Matériel ─────────────────────────────────────────────────────────
	{ id = "seringue_soin", sName = "Seringue de soin", sCat = "outil",
	  sDesc = "Dose de soin concentré à injecter à un blessé — ou à soi-même, faute de mieux.",
	  sQuote = "Une seringue pleine vaut tous les discours du triage.",
	  tIngredients = { infusion_verte = 1, amanite_ames = 3, girolle_ectoplasme = 2 } },
	-- ── Protection ───────────────────────────────────────────────────────
	-- Deux masques par préparation. La remise choisit la VARIANTE de la faction
	-- du crafteur (sv_science_medic) : même modèle, skinfamille arrancar.
	{ id = "masque_medical", sName = "Masque médical", sCat = "masque", nBatch = 2, bAlwaysKnown = true,
	  sDesc = "Se porte (accessoire de tête) : tant qu'il est stérile, aucune contagion ne passe. S'use en 6 heures de port.",
	  sQuote = "Le premier geste du soin, c'est de ne pas devenir le prochain patient.",
	  tIngredients = { fougere_spectrale = 2, coprin_spectral = 3, sauge_ames = 3 } },
}

function EVO_SCIENCE.MedRecipeById(sId)
	for _, r in ipairs(HUB.MedRecipes) do
		if r.id == sId then return r end
	end
	return nil
end

-- Préparations LIQUIDES (injectables : vaccins + seringue) : après le pilage,
-- le BANC DE VERRERIE s'ouvre (2e mini-jeu, dosage à l'erlenmeyer). Règle par
-- CATÉGORIE, un seul endroit : pas de flag à recopier sur chaque recette.
function EVO_SCIENCE.MedRecipeLiquid(r)
	return r ~= nil and (r.sCat == "vaccin" or r.sCat == "outil")
end

-- Le mélange déposé correspond-il EXACTEMENT à une recette médicale ?
-- (Même sémantique que EVO_SCIENCE.MatchRecipe, sur l'autre registre.)
function EVO_SCIENCE.MatchMedRecipe(tCombo)
	local nTypes = 0
	for _ in pairs(tCombo) do nTypes = nTypes + 1 end
	for _, r in ipairs(HUB.MedRecipes) do
		local n, ok = 0, true
		for id, qty in pairs(r.tIngredients) do
			n = n + 1
			if tCombo[id] ~= qty then ok = false break end
		end
		if ok and n == nTypes then return r end
	end
	return nil
end

-- Id de BASE d'une variante étoilée ("infusion_verte_2s" -> "infusion_verte").
-- Renvoie l'id inchangé si ce n'est pas une variante (ou si la base n'existe pas).
function EVO_SCIENCE.MedBaseId(sId)
	local sBase = string.match(tostring(sId or ""), "^(.+)_[23]s$")
	return (sBase and EVO_SCIENCE.MedRecipeById(sBase)) and sBase or sId
end

-- Un item a-t-il sa place dans le mortier ? Champignons + plantes (récolte),
-- plus les INFUSIONS de la table elle-même : elles retournent au mortier comme
-- BASE des injectables (chaîne de craft, user 08/18). Rien du labo (même les
-- remèdes) ni les cristaux : c'est de la médecine, pas de la synthèse.
function EVO_SCIENCE.MedIngredientAllowed(sItemId)
	local sKind = EVO_SCIENCE.IngredientKind(sItemId)
	if sKind == "mush" or sKind == "plant" then return true end
	-- Les variantes ÉTOILÉES valent leur base : sans ça un médecin qui ne brasse
	-- qu'en 2★/3★ ne pouvait plus préparer ni vaccins ni seringue (leurs recettes
	-- exigent de l'infusion verte ou violette), son stock devenait inutilisable.
	local r = EVO_SCIENCE.MedRecipeById(EVO_SCIENCE.MedBaseId(sItemId))
	return r ~= nil and r.sCat == "infusion"
end

-- ── Effets des produits (lus par sv_science_medic + descriptions) ────────────
-- Tous ancrés dans des systèmes EXISTANTS : PV (PlayerMaxHP), reiatsu
-- (SetCharReiatsu), blocage de réop (EvoHealBed.CutReopBlock — l'API, PAS le NWFloat
-- EVO_SoinReopBlockEnd : celui-ci n'est qu'un miroir, lu par le menu C pour griser
-- l'action mais jamais par le contrôle qui autorise l'opération),
-- contagion (jauge du sweep maladies), Peur (EVO::Peur d'Ulquiorra), immunité
-- (pipeline _EvoMaladieImmun). Rien d'inventé sans consommateur.
-- Valeurs NERFÉES ÷3 le 08/18 (user : « t'as abusé sur les bonus ») : rien de
-- chiffré au-dessus de ~10%, la table soigne le quotidien, pas les combats.
HUB.MedEffects = {
	infusion_verte    = { nHealPct = 4, nRegenPct = 0.2, nRegenSec = 20 },
	infusion_bleue    = { nReiatsuPct = 7 },
	infusion_rouge    = { nHealPct = 3,  nReopCutPct = 8 },
	infusion_emeraude = { nHealPct = 4, nRegenPct = 0.2, nRegenSec = 20, nReiatsuPct = 7 },
	infusion_ambree   = { nHealPct = 5, nRegenPct = 0.2, nRegenSec = 20, nReopCutPct = 10 },
	infusion_violette = { nReiatsuPct = 8, nReopCutPct = 10 },
	pilule_antiseptique = { nAntisepMin = 15 },
	pilule_antidouleur  = { nReopCutPct = 17 },
	pilule_calmante     = { bCalmeFear = true },
	vaccin_ecarlate   = { sVaccin = "fievre_ecarlate" },
	vaccin_verdatre   = { sVaccin = "peste_verdatre" },
	vaccin_rose       = { sVaccin = "mal_rose" },
	-- 10 -> 12.5 le 10/26 (user) : 3★ = 25 %, au niveau de la décoction scientifique ★.
	seringue_soin     = { nInjectPct = 12.5 },
}

-- Produits de la table assignables au CONSOMMABLE RAPIDE (petit slot de la
-- spell bar, demande user 08/18). Source UNIQUE lue par
-- INVENTORY_CONFIG.IsQuickConsumable (inventory/config.lua) : tout ce que la
-- table produit — effets directs (MedEffects), tubes et médicament compris.
function EVO_SCIENCE.MedQuickConsumable(sItemId)
	if HUB.MedEffects[sItemId] then return true end
	return sItemId == "medicament" or sItemId == "tube_calmant"
		or sItemId == "tube_antiseptique" or sItemId == "tube_antidouleur"
end

-- Phrase d'effet (description d'item + page du carnet + notification).
function EVO_SCIENCE.MedFxDesc(sItemId)
	local fx = HUB.MedEffects[sItemId]
	if not fx then
		-- Les tubes décrivent leur contenu.
		if sItemId == "tube_antiseptique" then return "Contient 3 cachets d'antiseptique." end
		if sItemId == "tube_antidouleur" then return "Contient 3 cachets d'antidouleur." end
		if sItemId == "tube_calmant" then return "Contient 3 cachets de calmant." end
		if sItemId == "medicament" then return "Coupe les vertiges et maux de tête d'une intoxication." end
		return ""
	end
	local t = {}
	if fx.nHealPct then t[#t + 1] = "rend " .. fx.nHealPct .. "% des PV" end
	if fx.nRegenPct then
		t[#t + 1] = "régénère " .. fx.nRegenPct .. "% des PV par seconde"
			.. ((fx.nStar or 1) > 1 and (" +" .. ((fx.nStar or 1) - 1) .. " PV") or "")
			.. " pendant " .. fx.nRegenSec .. " s"
	end
	if fx.nReiatsuPct then t[#t + 1] = "rend " .. fx.nReiatsuPct .. "% du reiatsu" end
	if fx.nReopCutPct then t[#t + 1] = "raccourcit de " .. fx.nReopCutPct .. "% le temps de réopération QUI RESTE" end
	if fx.nAntisepMin then t[#t + 1] = "immunise " .. fx.nAntisepMin .. " min contre la contagion passive" end
	if fx.bCalmeFear then t[#t + 1] = "dissipe la Peur" end
	if fx.sVaccin then
		local d = HUB.Maladies and HUB.Maladies[fx.sVaccin]
		t[#t + 1] = "immunise 24 h contre « " .. (d and d.sName or fx.sVaccin) .. " » (et la guérit sur-le-champ si elle est déjà déclarée)"
	end
	if fx.nInjectPct then t[#t + 1] = "injecte " .. fx.nInjectPct .. "% de PV à la cible visée (ou soi-même)" end
	if #t == 0 then return "" end
	local s = table.concat(t, ", ") .. "."
	return s:sub(1, 1):upper() .. s:sub(2)
end

-- ── Items ────────────────────────────────────────────────────────────────────
-- Enregistrés dans HUB.Items : la boucle de retry de sh_science_hub (chargé
-- AVANT ce fichier) les recopie dans ITEMS avec les autres.
local function medOnUse(sItemId)
	return function(ply)
		if not SERVER then return end
		if EVO_SCIENCE.MedUse then EVO_SCIENCE.MedUse(ply, sItemId) end
	end
end

local function addMedItem(sId, sName, sModel, nSkin, sDesc, sRarity)
	HUB.Items[sId] = {
		name = sName,
		description = sDesc .. "\nClic droit > Utiliser, ou « Consommable rapide » pour l'assigner au consommable rapide.",
		category = "object",
		rarity = sRarity or "rare",
		model_path = sModel,
		skin = nSkin or 0,
		is_droppable = true,
		on_use = medOnUse(sId),
	}
end

-- Infusions (sachets d'herbes, skins 0..5 du mix).
for _, r in ipairs(HUB.MedRecipes) do
	if r.sCat == "infusion" then
		addMedItem(r.id, r.sName, HUB.MedicModels.mix_herbes, r.nSkin,
			r.sDesc .. " " .. EVO_SCIENCE.MedFxDesc(r.id))
	end
end

-- Pilules à l'unité (sorties des tubes) : longues bleu/vert/rouge.
addMedItem("pilule_calmante", "Cachet de calmant", HUB.MedicModels.pilules_long, 0,
	"Cachet bleu. " .. EVO_SCIENCE.MedFxDesc("pilule_calmante"))
addMedItem("pilule_antiseptique", "Cachet d'antiseptique", HUB.MedicModels.pilules_long, 1,
	"Cachet vert. " .. EVO_SCIENCE.MedFxDesc("pilule_antiseptique"))
addMedItem("pilule_antidouleur", "Cachet d'antidouleur", HUB.MedicModels.pilules_long, 2,
	"Cachet rouge. " .. EVO_SCIENCE.MedFxDesc("pilule_antidouleur"))

-- Tubes (3 doses : s'OUVRENT en 3 cachets, skins alignés bleu/vert/rouge).
addMedItem("tube_calmant", "Tube de calmant", HUB.MedicModels.tube_pilules, 0,
	"Tube scellé de trois cachets bleus. S'ouvre d'un geste.")
addMedItem("tube_antiseptique", "Tube d'antiseptique", HUB.MedicModels.tube_pilules, 1,
	"Tube scellé de trois cachets verts. S'ouvre d'un geste.")
addMedItem("tube_antidouleur", "Tube d'antidouleur", HUB.MedicModels.tube_pilules, 2,
	"Tube scellé de trois cachets rouges. S'ouvre d'un geste.")

-- Vaccins (skins 0 bleu / 1 vert / 2 violet).
for _, r in ipairs(HUB.MedRecipes) do
	if r.sCat == "vaccin" then
		addMedItem(r.id, r.sName, HUB.MedicModels.vaccin, r.nSkin,
			r.sDesc .. " " .. EVO_SCIENCE.MedFxDesc(r.id), "epic")
	end
end

-- Seringue de soin.
addMedItem("seringue_soin", "Seringue de soin", HUB.MedicModels.seringue, 0,
	"Dose de soin concentré. " .. EVO_SCIENCE.MedFxDesc("seringue_soin"), "epic")

-- ── Masque médical : ACCESSOIRE de tête, pas un consommable ──────────────────
-- Contamination stockée dans la CLÉ D'INSTANCE de l'exemplaire ("cont:<maladie>:
-- <gen>") : elle voyage avec l'objet (échange, drop, coffre) — c'est tout le
-- gameplay. La logique de contagion vit dans sv_science_maladies (sweep).
function EVO_SCIENCE.MaskContagion(sKey)
	if not isstring(sKey) then return nil end
	local sId, sGen = string.match(sKey, "^cont:([%w_]+):(%d+)$")
	if not sId then return nil end
	return sId, tonumber(sGen) or 1
end

-- Clic droit > Utiliser DANS LE SAC = STÉRILISATION (médecin uniquement) :
-- consomme un cachet d'antiseptique et efface la contamination (l'état, lui,
-- se lit au survol d'inventaire).
local function maskOnUse(ply, nSlot)
	if not SERVER then return end
	if not (IsValid(ply) and ply.inventory) then return end
	local bMedic = (EvoHealBed and EvoHealBed.IsHealDivision and EvoHealBed.IsHealDivision(ply))
		or ply:GetEvoNWInt("FactionDivision", 0) == 5
	local function say(s, bErr)
		if ply.rpNotify then ply:rpNotify(s, bErr and 1 or 0, 6) end
	end
	if not bMedic then
		say("Seul un médecin sait stériliser un masque correctement.", true)
		return
	end
	local sCost = HUB.MaskSterilizeCost
	if ply:CountInventoryItem(sCost) < 1 then
		say("Il te faut un cachet d'antiseptique à dissoudre pour stériliser.", true)
		return
	end
	local sKey = ply.inventory.instance_keys and ply.inventory.instance_keys[nSlot]
	local bWasCont = EVO_SCIENCE.MaskContagion(sKey) ~= nil
	ply:RemoveItem(sCost, function(ok)
		if ok == false or not IsValid(ply) then return end
		if ply.inventory and ply.inventory.instance_keys then
			ply.inventory.instance_keys[nSlot] = nil
		end
		-- Le drain de durabilité ne persiste QUE la durabilité (UPDATE ciblé) :
		-- l'effacement de la clé a besoin du sien, même patron que l'enchant.
		local rid = ply.inventory and ply.inventory.row_by_slot and ply.inventory.row_by_slot[nSlot]
		if rid and MUGEN and MUGEN.Query then
			MUGEN.Query(string.format("UPDATE inventory SET instance_key = NULL WHERE id = %d", rid))
		end
		ply:SyncInventory(nil, nil)
		if bWasCont then
			say("L'eau de stérilisation vire au trouble… ce masque ÉTAIT contaminé. Le voilà propre.")
		else
			say("Masque passé à l'antiseptique : il est propre.")
		end
	end)
end

for _, t in ipairs({
	{ id = "masque_medical",     sFaction = "Shinigami", nSkin = 0 },
	{ id = "masque_medical_arr", sFaction = "Hollow",    nSkin = 1 },
}) do
	HUB.Items[t.id] = {
		name = "Masque médical",
		description = "Masque de protection contre les maladies. Stérile, il bloque toute contagion ; "
			.. "il s'use en 6 heures de port et protège alors moins bien. Un masque porté par un malade "
			.. "devient contaminé et transmet la maladie : seul un médecin peut le stériliser "
			.. "(clic droit > Utiliser, coûte un cachet d'antiseptique).",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		faction = t.sFaction,
		skin = t.nSkin, -- skinfamille du .mdl : 0 = medic, 1 = medic_arr
		rarity = "rare",
		model_path = "models/evo/accessories/head/evo_zf53ref3rgfterefr572gr2/evo_zf53REF3rgftEREFR572gr2.mdl",
		has_durability = true,
		durability_drain_per_min = 100 / 360, -- 6 h portées (drain PAR ITEM, cf. inventory)
		bMedicalMask = true, -- marqueur lu par le sweep de contagion
		is_droppable = true, -- il DOIT circuler : c'est le vecteur du gameplay
		on_use = maskOnUse,
		-- État de CET exemplaire dans le tooltip d'inventaire (contrat générique
		-- tooltip_state du hover : texte + couleur).
		tooltip_state = function(nSlot, inv)
			local sKey = INVENTORY_CONFIG and INVENTORY_CONFIG.GetSlotInstanceKey
				and INVENTORY_CONFIG.GetSlotInstanceKey(inv, nSlot) or nil
			if EVO_SCIENCE.MaskContagion(sKey) then
				return "État : Contaminé", Color(207, 68, 78)
			end
			local m = istable(inv) and inv.durability or nil
			local nDur = istable(m) and tonumber(m[nSlot] or m[tonumber(nSlot)]) or 100
			if nDur <= (HUB.MaskUsedPct or 30) then
				return "État : Usé", Color(255, 200, 110)
			end
			return "État : Stérile", Color(140, 200, 160)
		end,
	}
end

-- Le MÉDICAMENT existait déjà (soigne l'intoxication au champignon) sur un
-- modèle provisoire de fiole : il prend son VRAI modèle (pilules rondes,
-- blanc) maintenant que les assets sont là. Son on_use (UseMedicament,
-- sv_science_maladies) ne bouge pas.
if HUB.Items.medicament then
	HUB.Items.medicament.model_path = HUB.MedicModels.pilules_rond
	HUB.Items.medicament.skin = 2
end
-- (Pilules rondes bleu/rose : RÉSERVÉES à de futurs médicaments.)

-- ── Variantes ÉTOILÉES (2★/3★) des produits scalables ────────────────────────
-- Items + effets DÉRIVÉS des bases (aucune valeur dupliquée) : le nom prend
-- ses étoiles, les effets sont multipliés par nFxMult. Le craft les délivre
-- via EVO_SCIENCE.MedStarId selon l'étoile choisie au mortier.
local function medStarFx(fxBase, nMult, nStar)
	local t = {}
	for k, v in pairs(fxBase) do
		-- nRegenSec = une DURÉE de tick : l'étoile augmente le soin par
		-- seconde, pas la durée (sinon double multiplication).
		if isnumber(v) and k ~= "nRegenSec" then
			t[k] = math.Round(v * nMult * 10) / 10
		else
			t[k] = v
		end
	end
	-- Étoile PORTÉE par l'effet : le tick serveur en tire un bonus additif de
	-- régénération (+0 / +1 / +2 PV). Sans ça l'arrondi au PV supérieur écrasait
	-- tout le barème et les trois étoiles soignaient exactement pareil.
	t.nStar = nStar
	return t
end

for _, r in ipairs(HUB.MedRecipes) do
	if EVO_SCIENCE.MedStarrable(r.id) then
		for nStar = 2, 3 do
			local sc = HUB.MedStars[nStar]
			local sId = EVO_SCIENCE.MedStarId(r.id, nStar)
			HUB.MedEffects[sId] = medStarFx(HUB.MedEffects[r.id], sc.nFxMult, nStar)
			local base = HUB.Items[r.id]
			if base then
				addMedItem(sId, (base.name or r.sName) .. " " .. string.rep("★", nStar),
					base.model_path, base.skin,
					r.sDesc .. " " .. EVO_SCIENCE.MedFxDesc(sId),
					nStar == 3 and "legendary" or "epic")
			end
		end
	end
end

-- La verrerie rejoint l'outil de placement des établis (evo_etablie) : le
-- user habille sa table médicale avec, positions copiées comme d'habitude.
for _, d in ipairs(HUB.MedicDecor) do
	HUB.Etablies[#HUB.Etablies + 1] = { id = d.id, name = d.name .. " (médic)", model = d.model }
end
