-- "addons\\evo_science\\lua\\autorun\\sh_science_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO SCIENCE — config partagée (Division scientifique : Division 12 / Ordre 3).
--
-- GAMEPLAY (v2) :
--  • Les Hollows PNJ tués par des joueurs LÂCHENT parfois une CARCASSE (même
--    recette que les âmes du mode larve : prop_dynamic + flag NW, ramassage E).
--  • Besace max 3 ; chaque carcasse se DÉCOMPOSE en 30 min.
--  • L'ÉCHANTILLONNAGE (mini-jeu façon "docteur Maboule") se fait AU LABORATOIRE
--    (zones par map ci-dessous). Il consomme la carcasse et lance une ANALYSE
--    LONGUE sur l'analyseur de la faction : 30 min -> 4 h selon le spécimen,
--    accélérée par la qualité des prélèvements.
--  • Une fois l'analyse terminée, N'IMPORTE QUEL scientifique de la faction la
--    RÉCUPÈRE au labo -> la connaissance est PARTAGÉE par toute la faction
--    (bestiaire commun, persistant, cross-serveur si MySQL).
-- ============================================================================
EVO_SCIENCE = EVO_SCIENCE or {}

-- ⚠ AUTOREFRESH : RÉUTILISER la table CFG existante, jamais la remplacer —
-- CFG.Hub (sh_science_hub) et les upvalues des fichiers clients vivent dessus.
-- Une table neuve à chaud = « attempt to index HUB (nil) » dans tout fichier
-- rechargé APRÈS celui-ci mais sans que sh_science_hub re-tourne (bug 08/18).
local CFG = EVO_SCIENCE.CFG or {}
EVO_SCIENCE.CFG = CFG

-- ── Accès : division scientifique uniquement (même INDEX dans les 2 factions) ──
CFG.DivisionName = { Shinigami = "Division 12", Hollow = "Ordre 3" }
CFG.DivisionIndexFallback = 4 -- index si LZY_FACTION_CONFIG indisponible

-- ── ZONES DE LABORATOIRE (par map) ──────────────────────────────────────────
-- L'échantillonnage ET la récupération des résultats ne sont possibles QUE dans
-- une de ces zones. Une zone = CYLINDRE : rayon sur x/y autour du poste + bande
-- de hauteur autour du SOL (cf. ZoneIdFor). Le z de config n'a donc pas besoin
-- d'être exact : le sol est retrouvé par trace (ZoneAnchor), ce qui garde la
-- détection ALIGNÉE sur le cercle blanc dessiné au sol.
-- En jeu : `evo_science_getpos` imprime la ligne prête à coller ici ;
-- `evo_science_zone_here [rayon]` pose une zone de TEST temporaire (session).
CFG.LabZones = {
	-- Seireitei : 3 postes d'analyse (positions relevées en jeu par le user, 2026-07-17).
	-- Rayon PETIT (55) : il faut être SUR le poste, pas juste dans la pièce.
	-- z ABAISSÉ de 64 (le getpos console de GMod imprime la position des YEUX,
	-- pas des pieds -> cercles flottants + sphère de détection trop haute).
	-- AVANCÉS de 90 en -y (2e demande user : direction montrée par le point
	-- 5247/9601 — les cercles étaient trop enfoncés côté postes).
	["rp_seireitei_v1"] = {
		{ pos = Vector(5015.9, 9617.6, 14985), radius = 55 },
		{ pos = Vector(5199.5, 9624.9, 14974), radius = 55 },
		{ pos = Vector(5398.1, 9629.7, 14967), radius = 55 },
		-- 2e salle (y≈5100), 3 postes ajoutés par le user le 07/17.
		{ pos = Vector(5457.6, 5175.1, 14997), radius = 55 },
		{ pos = Vector(5228.4, 5031.3, 14989.6), radius = 55 },
		{ pos = Vector(5010.7, 5162.3, 14987), radius = 55 },
	},
	-- Hueco Mundo : 6 postes. Positions relevées en jeu ; z corrigé yeux -> pieds
	-- (-64), le sol est de toute façon retrouvé par trace (ZoneAnchor). Swap de 2
	-- postes le 07/17 (retirés ~(-11494,1072) et ~(-11638,53)).
	["hueco_mundo_v1"] = {
		{ pos = Vector(-10654.4, -19, 6328), radius = 55 },
		{ pos = Vector(-11032, -221.1, 6359.6), radius = 55 },
		{ pos = Vector(-11600.1, 459.9, 6334.1), radius = 55 },
		{ pos = Vector(-11712.2, 1149.2, 6374.4), radius = 55 },
		{ pos = Vector(-11262.8, 1502.5, 6368.6), radius = 55 },
		{ pos = Vector(-11615.5, 1307, 6356.9), radius = 55 },
	},
	-- gm_construct : un poste d'analyse (en plaine, loin du spawn encombré).
	["gm_construct"] = {
		{ pos = Vector(1500, 1500, -60), radius = 90 },
	},
}

-- ── Drop des carcasses ──
-- Chance par Tier du PNJ (NCM_PNJ.Config[class].Tier, 1 = trash -> 4 = boss).
-- Taux DURS (user 07/17 "plus rude") : une carcasse doit rester un événement.
CFG.DropChance   = { [1] = 0.08, [2] = 0.12, [3] = 0.18, [4] = 0.25 }
CFG.DropChanceBoss = 0.35 -- IsBoss = carcasse plus probable (et plus précieuse)
CFG.GroundLinger = 45     -- s au sol avant auto-destruction ("petit laps de temps")
CFG.MaxGround    = 8      -- carcasses simultanées au sol max (anti-spam)
CFG.AllowQuestMobs = false -- pas de drop sur les vagues de quêtes (comme les âmes larve)

-- Modèle de la carcasse (même prop d'âme que le mode larve ; PAS de SetColor :
-- la teinte rendait ce modèle workshop invisible -> le look = halo vert client).
CFG.CarcassModel = "models/evo/props/items/evo_fryhbhbfefr65bhvfhudf/evo_FRYHBhbfefr65BHVFhudf.mdl"

-- ── Besace ──
CFG.PouchMax    = 3
CFG.RotSeconds  = 30 * 60 -- 30 min puis auto-destruction
-- ⚠️ CES TROIS PORTÉES DOIVENT RESTER ORDONNÉES : détection ≤ E ≤ validation serveur.
-- Bug corrigé le 26/07 : la détection affichait « [E] Prélever » dès 250 unités alors
-- que la touche ne répondait qu'à 170. Entre les deux, le joueur voyait le message,
-- appuyait, et il ne se passait RIEN — ni son, ni refus, ni explication. Les
-- scientifiques ont conclu que les carcasses n'étaient pas ramassables du tout.
-- Le message ne doit jamais promettre une action impossible : on aligne donc le E sur
-- la détection, et on garde une marge SERVEUR au-dessus pour absorber le déplacement
-- entre l'appui et la réception du paquet.
CFG.DetectRange = 250     -- rayon d'affichage du prompt (client, cf. scanCarcasses)
CFG.EatRange    = 250     -- portée du E client — ALIGNÉE sur la détection
CFG.PickupRange = 300     -- validation serveur, marge volontaire au-dessus du client

-- ── Échantillonnage ──
-- (Mini-jeu "docteur Maboule" RETIRÉ 07/17 à la demande : ÉCHANTILLONNER lance
--  directement l'analyse. La QUALITÉ = FRAÎCHEUR de la carcasse (0..Samples) et
--  accélère l'analyse via JobQualitySpeedup -> une carcasse fraîche reste meilleure.)
CFG.Samples  = 4 -- échelle de qualité affichée ("Qualité x/4")
-- LONGUE PROGRESSION (user 08/26) : une espèce demandait 5 carcasses — le système
-- était bouclé en quelques jours et n'existait plus pour les nouveaux. Une analyse
-- = 1 point de connaissance, et il en faut désormais CFG.MaxLevel pour épuiser une
-- espèce. Les points DÉJÀ acquis ne bougent pas (rien n'est réinitialisé) : c'est le
-- gain PAR analyse qui devient petit, cf. CFG.CombatBonusPerLevel.
CFG.MaxLevel = 100
-- MUTATIONS (user 08/25) : fiche de connaissance À PART par forme mutée (clé "classe@n"),
-- gagnée UNIQUEMENT par l'analyse de carcasses MUTÉES (rares). Une faction au max sur
-- l'espèce repart de zéro ici.
CFG.MutationMaxLevel = 75

-- PALIERS DE RÉVÉLATION : nombre d'analyses qui débloque chaque section de la fiche
-- (5 sections pour une espèce : profil -> physiologie -> comportement -> tactique ->
-- secrets ; 3 pour une mutation : identifiée -> physiologie -> primes et bonus).
-- ⚠ VOLONTAIREMENT IDENTIQUES À L'ANCIEN RYTHME (1 section par analyse) : étaler les
-- révélations sur les 100 analyses RE-VERROUILLERAIT des fiches déjà lues (une faction
-- à 5/5 ne verrait plus que le PROFIL) — exactement ce que « ne rien réinitialiser »
-- interdit. Le savoir reste donc acquis en 5 analyses (3 pour une mutation, dont les
-- carcasses sont ~25x plus rares) ; les analyses suivantes n'apportent QUE du bonus de
-- dégâts. Pour étaler les révélations plus tard, il suffit de monter ces seuils.
-- #IntelThresholds DOIT rester égal au nombre de sections.
CFG.IntelThresholds         = { 1, 2, 3, 4, 5 }
CFG.MutationIntelThresholds = { 1, 2, 3 }

-- ── Encadrement (DOSSIERS) ──
-- Onglet de suivi (meilleurs analyseurs, complétion, analyses en cours) réservé au
-- CAPITAINE et au VICE-CAPITAINE de la division scientifique (+ superadmins).
CFG.OversightMinRank = 14 -- index de grade minimum (14 = Vice-Capitaine, 15 = Capitaine)

-- ── Analyse LONGUE (l'analyseur de la faction travaille en tâche de fond) ──
-- Durée de base par Tier du spécimen ; chaque prélèvement réussi accélère de 8%
-- (4/4 = -32%). Persistant en BDD : survit aux restarts, partagé par la faction.
CFG.JobDuration = { [1] = 30 * 60, [2] = 60 * 60, [3] = 120 * 60, [4] = 240 * 60 } -- 30min / 1h / 2h / 4h
CFG.JobQualitySpeedup = 0.08  -- -8% de durée par échantillon réussi
CFG.MaxJobsPerFaction = 2     -- REPLI seulement : analyses simultanées max par faction sur une
                              -- carte SANS poste configuré. Avec des postes, le plafond = leur
                              -- nombre (EVO_SCIENCE.MaxJobs) — 6 postes, 2 analyses à la fois
                              -- bloquait le labo depuis le passage à 100 analyses (user 08/27).

-- ── LONGÉVITÉ ────────────────────────────────────────────────────────────────
-- 1) BONUS DE COMBAT DE FACTION : chaque analyse donne +0,1% de dégâts à TOUTE la
--    faction contre ce type de Hollow PNJ. Le PLAFOND ne bouge pas (100 analyses =
--    +10%, comme les 5 x 2% d'avant ; une forme mutée plafonne à +7,5%) : c'est la
--    ROUTE qui s'allonge, pas la puissance finale (user 08/26). Un bestiaire déjà
--    rempli garde ses points mais voit son bonus fondre — c'est voulu.
--    (Hook dédié EntityTakeDamage + ScaleDamage : compose proprement avec
--    lzy_stats et le bonus suprématie du drapeau — jamais de re-multiplication.)
CFG.CombatBonusPerLevel = 0.001

-- 2) SPÉCIMEN PRIORITAIRE DE LA SEMAINE : rotation déterministe (os.time), analyse
--    2x plus rapide.
CFG.PrioritySpeedMult = 0.5

-- (3 — DONNÉES DE RECHERCHE : système de points RETIRÉ 07/17 à la demande du user, STANDBY.)
-- CFG.PointsByTier = { [1] = 10, [2] = 15, [3] = 25, [4] = 40 }
-- CFG.MaxLevelPointsMult = 2
-- CFG.PriorityPointsMult = 2

--    (STIMULANT DE COMBAT : RETIRÉ à la demande du user 07/17 — STANDBY. Pour le
--     réactiver : décommenter + restaurer la logique BuyStim sv/cl.)
-- CFG.StimCost     = 100
-- CFG.StimBonus    = 0.05
-- CFG.StimDuration = 30 * 60

-- 4) JALONS : bestiaire d'un TIER complet au niveau max -> prime versée à la
--    TRÉSORERIE de la division scientifique (evo_division_bank), une seule fois.
CFG.MilestoneYen = { [1] = 25000, [2] = 50000, [3] = 75000, [4] = 150000 }
-- Coût de FONCTIONNEMENT d'une analyse (¥, par TIER du spécimen), débité à la trésorerie de la
-- division scientifique (evo_division_bank) AU LANCEMENT. Fail-closed : caisse insuffisante ->
-- l'analyse ne démarre PAS (demande user 2026-07-20) — la division doit financer son labo
-- (dons des membres, jalons de bestiaire) et les capitaines arbitrent entre payer des analyses
-- et offrir des coffres. Volontairement modéré (« pas abuser mais un peu »).
-- 08/26 : divisé par 10 en même temps que le passage à 100 analyses par espèce —
-- au tarif d'avant, épuiser une seule espèce de tier 4 aurait coûté 400 000 ¥ à la
-- division et bloqué le labo (donc l'inverse du but : rouvrir le système aux nouveaux).
CFG.AnalysisCost = { [1] = 50, [2] = 100, [3] = 200, [4] = 400 }

-- ── SONS (assets custom du serveur — pas de sons GMod de base) ──────────────
CFG.Sounds = {
	click      = "a4xy732ex6yeop2/adgwz38nw3s9.mp3",      -- clic UI (ncm_ui_sounds)
	pickup     = "a4xy732ex6yeop2/adgwz38nw3s9.mp3",      -- ramassage carcasse
	sampleGrab = "a4xy732ex6yeop2/g1kpyv29gwai.mp3",      -- prise d'un point de prélèvement (hover UI)
	sampleOk   = "a4xy732ex6yeop2/tv6cllaafv0qtz08d.wav", -- prélèvement réussi (ting parade parfaite)
	sampleFail = "a4xy732ex6yeop2/kke07ldjfgeghkki.wav",  -- BZZT raté (son kidō/absorption)
	jobStart   = "a4xy732ex6yeop2/1q9kcah77kmxhhyw.wav",  -- analyseur lancé (activation d'énergie)
	jobReady   = "a4xy732ex6yeop2/tv6cllaafv0qtz08d.wav", -- analyse terminée (notification)
	toux       = "r1n1mtedmal9vcf/toux.mp3",              -- quinte de toux d'un malade (3D, entendue autour)
	medMixing  = "srvtjl3ecp3ies4/cffpgm47hql72m1d5/mixing.mp3",       -- broyage au mortier (boucle du geste)
	medFill    = "srvtjl3ecp3ies4/cffpgm47hql72m1d5/remplir_eau.mp3",  -- versement au banc de verrerie
}

-- ── Helpers partagés ─────────────────────────────────────────────────────────
-- Le joueur est-il de la division scientifique ? (pattern heal_bed : par NOM de
-- division, fallback index ; NWString/NWInt répliqués -> marche client+serveur.)
function EVO_SCIENCE.IsScientist(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:GetEvoNWBool("EVO_SciBypass", false) then return true end -- bypass de TEST (cmd superadmin evo_science_bypass)
	local fac = ply:GetEvoNWString("FactionName", "")
	if fac == "" then return false end
	local want = CFG.DivisionName[fac]
	local idx  = ply:GetEvoNWInt("FactionDivision", 0)
	if want and istable(LZY_FACTION_CONFIG) and istable(LZY_FACTION_CONFIG.divisions) then
		local divs = LZY_FACTION_CONFIG.divisions[fac]
		if divs then return divs[idx] == want end
	end
	return idx == CFG.DivisionIndexFallback
end

-- Postes de la map courante : { pos, radius, id } — SOURCE UNIQUE partagée par la
-- détection (serveur+client) ET les marqueurs 3D, pour qu'ils ne divergent jamais.
-- id "map:index" (config) / "runtime:map" (evo_science_zone_here).
-- Analyses simultanées autorisées pour la faction : UNE par poste d'analyse de la
-- carte (la règle « 1 analyse par poste » fait le reste), repli CFG.MaxJobsPerFaction
-- s'il n'y a aucun poste. Partagé : le serveur refuse, le client affiche x / n.
function EVO_SCIENCE.MaxJobs()
	local n = #EVO_SCIENCE.Zones()
	return (n > 0) and n or (CFG.MaxJobsPerFaction or 2)
end

function EVO_SCIENCE.Zones()
	local map = game.GetMap()
	local out = {}
	local zones = CFG.LabZones[map]
	if istable(zones) then
		for i, z in ipairs(zones) do
			out[#out + 1] = { pos = z.pos, radius = z.radius or 300, id = map .. ":" .. i }
		end
	end
	if GetGlobalString("EVO_SciZoneMap", "") == map then
		local r = GetGlobalFloat("EVO_SciZoneRadius", 0)
		if r > 0 then
			out[#out + 1] = { pos = GetGlobalVector("EVO_SciZonePos", vector_origin), radius = r, id = "runtime:" .. map }
		end
	end
	return out
end

-- Ancre d'un poste = le SOL sous le point de config (trace 1x puis cache).
-- Rend la zone INSENSIBLE à un z de config approximatif : le getpos CONSOLE de
-- GMod imprime la position des YEUX (+64), ce qui plaçait la sphère de détection
-- hors d'atteinte depuis le sol (bug "le poste ne répond pas", 07/17).
local anchorCache = {}
function EVO_SCIENCE.InvalidateLabAnchors()
	anchorCache = {}
end
function EVO_SCIENCE.ZoneAnchor(z)
	local key = z.id .. "|" .. math.Round(z.pos.x) .. "|" .. math.Round(z.pos.y) .. "|" .. math.Round(z.pos.z)
	local a = anchorCache[key]
	if a then return a end
	local tr = util.TraceLine({
		start  = z.pos + Vector(0, 0, 128),
		endpos = z.pos - Vector(0, 0, 512),
		mask   = MASK_SOLID_BRUSHONLY, -- le sol du monde, pas les props posés dessus
	})
	local zGround = (tr.Hit and not tr.StartSolid) and tr.HitPos.z or z.pos.z
	a = Vector(z.pos.x, z.pos.y, zGround)
	anchorCache[key] = a
	return a
end

-- Bande de hauteur du cylindre, autour du SOL du poste (pieds du joueur).
CFG.ZoneBandBelow = 96  -- marge basse (pente, z de config resté à hauteur d'yeux)
CFG.ZoneBandAbove = 110 -- marge haute (saut, petite estrade) sans attraper l'étage du dessus

-- Identifiant STABLE du poste d'analyse où se trouve le joueur (nil hors zone).
-- Sert à lier chaque analyse à SON poste : 1 analyse à la fois par poste
-- (lancement ET récupération sur le même poste).
function EVO_SCIENCE.ZoneIdFor(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return nil end
	local pos = ply:GetPos() -- PIEDS
	for _, z in ipairs(EVO_SCIENCE.Zones()) do
		local a = EVO_SCIENCE.ZoneAnchor(z)
		local dz = pos.z - a.z
		if dz >= -CFG.ZoneBandBelow and dz <= CFG.ZoneBandAbove then
			local dx, dy = pos.x - a.x, pos.y - a.y
			if dx * dx + dy * dy <= z.radius * z.radius then return z.id end
		end
	end
	return nil
end

-- Le joueur est-il dans une zone de laboratoire ? (config par map + zone de TEST
-- runtime posée par evo_science_zone_here, répliquée par globals NW.)
function EVO_SCIENCE.IsInLabZone(ply)
	return EVO_SCIENCE.ZoneIdFor(ply) ~= nil
end

-- Nom d'affichage d'un id de poste ("Poste 2", "Poste de test"), "" si inconnu
-- (analyses d'avant la colonne zone : récupérables sur n'importe quel poste).
function EVO_SCIENCE.ZoneLabel(zoneId)
	if not isstring(zoneId) or zoneId == "" then return "" end
	if zoneId:sub(1, 5) == "etab:" then return "bureau de préparation" end
	if zoneId:sub(1, 8) == "runtime:" then return "Poste de test" end
	local idx = zoneId:match(":(%d+)$")
	return idx and ("Poste " .. idx) or ""
end

-- Le PNJ (classe) est-il un Hollow analysable ? (faction DrGBase "ncm_hollow",
-- fallback préfixe de classe).
function EVO_SCIENCE.IsHollowClass(sClass)
	local cfg = istable(NCM_PNJ) and istable(NCM_PNJ.Config) and NCM_PNJ.Config[sClass]
	if istable(cfg) then
		for _, f in ipairs(cfg.Factions or {}) do
			if f == "ncm_hollow" then return true end
		end
		return false
	end
	return string.sub(tostring(sClass or ""), 1, 15) == "ncm_pnj_hollow_"
end

-- Clés de bestiaire : une classe PNJ, ou "classe@n" pour sa n-ième mutation (ncm_pnj).
function EVO_SCIENCE.SplitKey(sKey)
	local sClass, sMut = string.match(tostring(sKey or ""), "^(.-)@(%d+)$")
	if sClass then return sClass, tonumber(sMut) end
	return sKey, nil
end

function EVO_SCIENCE.MutKey(sClass, nMut)
	return nMut and (sClass .. "@" .. nMut) or sClass
end

function EVO_SCIENCE.MaxLevelFor(sKey)
	local _, nMut = EVO_SCIENCE.SplitKey(sKey)
	return nMut and (CFG.MutationMaxLevel or 3) or CFG.MaxLevel
end

-- Paliers de révélation de la fiche (espèce ou mutation) : { analyses pour section 1, 2, ... }.
function EVO_SCIENCE.IntelThresholdsFor(sKey)
	local _, nMut = EVO_SCIENCE.SplitKey(sKey)
	return (nMut and CFG.MutationIntelThresholds or CFG.IntelThresholds) or { 1 }
end

-- Bonus de dégâts de faction (FRACTION, ex. 0.037) pour un nombre d'analyses.
-- Source unique : le hook de combat et les 3 affichages passent tous par ici.
function EVO_SCIENCE.CombatBonus(sKey, nLvl)
	local n = math.Clamp(math.floor(tonumber(nLvl) or 0), 0, EVO_SCIENCE.MaxLevelFor(sKey))
	return (CFG.CombatBonusPerLevel or 0) * n
end

-- Pourcentage lisible d'une fraction : « 10 », « 7,5 », « 0,5 ». math.floor(x * 100)
-- afficherait « +0% » pendant les 10 premières analyses depuis le passage à +0,1%/analyse.
function EVO_SCIENCE.FormatPct(nFrac)
	local p = (tonumber(nFrac) or 0) * 100
	local txt = (p >= 10 or math.abs(p - math.floor(p + 0.5)) < 0.001)
		and tostring(math.floor(p + 0.5)) or string.format("%.1f", p)
	return (string.gsub(txt, "%.", ","))
end

-- Infos affichables d'une classe PNJ (nom / stats / tier) depuis NCM_PNJ.Config.
-- Accepte une clé "classe@n" : nom suffixé de la mutation, PV / dégâts mutés.
function EVO_SCIENCE.NpcInfo(sClass)
	local nMut
	sClass, nMut = EVO_SCIENCE.SplitKey(sClass)
	local cfg = istable(NCM_PNJ) and istable(NCM_PNJ.Config) and NCM_PNJ.Config[sClass] or {}
	local M = nMut and istable(NCM_PNJ) and NCM_PNJ.Mutations or nil
	local nHpMult  = M and (M.HPMult or 3) or 1
	local nDmgMult = M and (M.DmgMult or 3) or 1
	-- PRIME D'XP : on lit la fonction de calcul RÉELLE (NCM_PNJ.GetKillXP), pas les plages
	-- cfg.XPReward{min,max}. Celles-ci ne pilotent plus l'XP de kill depuis le passage au
	-- socle plat : les afficher revenait à promettre 300-800 XP pour un Menos qui en verse
	-- 26. Un seul champ `xp` désormais, puisque le montant est déterministe.
	-- On ne passe PAS d'entité (aucune ici) : le bestiaire décrit la CLASSE, donc un mob
	-- promu boss au runtime par l'événement world boss n'est pas reflété — normal.
	return {
		name   = (cfg.PrintName or sClass) .. (nMut and (" · " .. ((NCM_PNJ.MutationLabel and NCM_PNJ.MutationLabel(nMut)) or "Muté")) or ""),
		model  = cfg.Model,
		hp     = math.floor((cfg.Health or 0) * nHpMult),
		regen  = cfg.HealthRegen or 0,
		dmg    = math.floor((cfg.AttackDamage or 0) * nDmgMult),
		base   = sClass, -- classe PNJ sans la mutation
		mut    = nMut,   -- 1 / 2 pour une clé "classe@n", sinon nil
		speed  = cfg.RunSpeed or 0,
		walk   = cfg.WalkSpeed or 0,
		tier   = cfg.Tier or 1,
		-- Prédicat PARTAGÉ, comme l'XP juste en dessous : `cfg.IsBoss` seul ne voyait que les
		-- classes portant littéralement le champ, donc le Garde et l'Abominación passaient pour
		-- des PNJ ordinaires ici alors que GetKillXP leur versait déjà l'XP de boss.
		boss   = (istable(NCM_PNJ) and NCM_PNJ.IsBossClass and NCM_PNJ.IsBossClass(cfg)) or cfg.IsBoss == true,
		xp     = (istable(NCM_PNJ) and NCM_PNJ.GetKillXP) and NCM_PNJ.GetKillXP(cfg, nil) or 0,
	}
end

-- Le joueur peut-il consulter les DOSSIERS (encadrement) ? Capitaine/Vice-Capitaine
-- de la division scientifique uniquement (+ superadmins pour l'administration).
function EVO_SCIENCE.CanOversight(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	if not EVO_SCIENCE.IsScientist(ply) then return false end
	return ply:GetEvoNWInt("FactionRank", 0) >= CFG.OversightMinRank
end

-- SPÉCIMEN PRIORITAIRE DE LA SEMAINE : rotation déterministe sur la liste triée
-- des classes hollow (pairs() n'est PAS déterministe -> tri obligatoire).
-- `atTime` optionnel : décider le bonus d'une analyse sur SA date de lancement
-- (job.started), pas sur la semaine de récupération.
function EVO_SCIENCE.PrioritySpecimen(atTime)
	local classes = {}
	for class in pairs((istable(NCM_PNJ) and NCM_PNJ.Config) or {}) do
		if EVO_SCIENCE.IsHollowClass(class) then classes[#classes + 1] = class end
	end
	if #classes == 0 then return nil end
	table.sort(classes)
	local week = math.floor((atTime or os.time()) / 604800)
	return classes[(week % #classes) + 1]
end

-- Durée d'analyse (s) pour une classe + une qualité d'échantillonnage (0..Samples).
-- Le spécimen prioritaire de la semaine s'analyse 2x plus vite.
function EVO_SCIENCE.JobDurationFor(sClass, nSuccess, nMut)
	local info = EVO_SCIENCE.NpcInfo(sClass)
	nMut = nMut or info.mut -- clé "classe@n" : mutation portée par la clé
	local base = CFG.JobDuration[math.Clamp(info.tier or 1, 1, 4)] or CFG.JobDuration[1]
	local mult = 1 - CFG.JobQualitySpeedup * math.Clamp(nSuccess or 0, 0, CFG.Samples)
	-- info.base = classe SANS la mutation : comparer sClass brut ne matchait jamais pour
	-- une clé "classe@n", donc une carcasse mutée ne profitait jamais du x0,5 prioritaire.
	if (info.base or sClass) == EVO_SCIENCE.PrioritySpecimen() then mult = mult * CFG.PrioritySpeedMult end
	-- Carcasse d'un Hollow MUTÉ (ncm_pnj) : matière plus riche, analyse plus rapide.
	if nMut and istable(NCM_PNJ) and istable(NCM_PNJ.Mutations) then mult = mult * (NCM_PNJ.Mutations.AnalysisSpeed or 1) end
	return math.floor(base * mult)
end

-- ============================================================================
-- BESTIAIRE — INTEL par classe. 3 paliers de connaissance :
--   1 = PROFIL (description + difficulté), 2 = PHYSIOLOGIE (PV/dégâts/vitesse),
--   3 = COMBAT (patterns d'attaque + fenêtre de PARADE PARFAITE + faiblesse).
-- Les classes absentes d'INTEL reçoivent un contenu auto-généré depuis les stats.
-- ============================================================================
-- Champs par classe : desc / lore (archives Bleach) / patterns / parade / esquive
-- / faiblesse / secret.
EVO_SCIENCE.INTEL = {
	["ncm_pnj_hollow_chien"] = {
		desc     = "Hollow quadrupède de type traqueur. Chasse en lignes droites, très mobile mais fragile.",
		lore     = "Né d'âmes restées en meute après la mort — chasseurs, bêtes errantes — dont les Chaînes du Destin se sont corrodées ensemble. Dans les sables blancs de Hueco Mundo, ces traqueurs pistent un reiatsu comme une odeur, parfois sur des kilomètres.",
		patterns = "Bonds répétés sur la cible avec morsure à l'atterrissage. Recule après chaque bond raté.",
		parade   = "Parade parfaite AU MOMENT où ses pattes avant touchent le sol (fin du bond).",
		esquive  = "Esquive LATÉRALE au départ du bond : il ne corrige pas sa trajectoire en l'air.",
		faiblesse = "Très peu de PV : une esquive latérale suivie d'un contre suffit souvent à l'abattre.",
		secret   = "Chasse rarement seul : quand un chien bondit, un second arrive souvent par le flanc opposé.",
	},
	["ncm_pnj_hollow_alas"] = {
		desc     = "Hollow ailé. Harcèle depuis les airs et pique sur les cibles isolées.",
		lore     = "Ces ailés nichent dans les crevasses qui surplombent la Forêt des Menos. Les Adjuchas dominants s'en servent comme d'éclaireurs : certaines carcasses portent encore des entailles rituelles, marques d'un « maître » plus profond dans le désert.",
		patterns = "Piqués en cloche : il prend de l'altitude, replie ses ailes puis fond sur la cible.",
		parade   = "Parade parfaite QUAND IL REPLIE SES AILES (début du piqué) — le timing est généreux.",
		esquive  = "Un pas de côté au dernier moment suffit : le piqué est rectiligne et sans correction.",
		faiblesse = "Une fois au sol, il est lent à redécoller : c'est la fenêtre de punition.",
		secret   = "Refuse de piquer sous un plafond bas : combattre sous un toit l'oblige à se poser.",
	},
	["ncm_pnj_hollow_base"] = {
		desc     = "Hollow commun. Lent, prévisible, mais ses griffes font mal aux jeunes recrues.",
		lore     = "La forme la plus répandue du Hollow : une âme errante dont la Chaîne du Destin s'est entièrement rongée. Le trou dans sa poitrine marque le cœur qu'elle a perdu — et la faim d'âmes, éternelle, qui l'a remplacé. Son masque blanc est né de cette douleur.",
		patterns = "Enchaînement de 2 coups de griffes télégraphiés, toujours précédés d'un rugissement.",
		parade   = "Parade parfaite JUSTE APRÈS LE RUGISSEMENT (1er coup). Punir après le 2e coup.",
		esquive  = "Reculer d'un pas pendant le rugissement : les deux griffes fauchent court.",
		faiblesse = "Aucune défense pendant sa récupération : rester collé à son flanc droit.",
		secret   = "Son masque encaisse mal les coups montants : un contre en uppercut écourte nettement le combat.",
	},
	["ncm_pnj_hollow_bero"] = {
		desc     = "Hollow charognard endurant. Encaisse énormément et cherche le corps-à-corps.",
		lore     = "Charognard des dunes : il suit de loin les duels entre Hollows pour dévorer les vaincus. Cette diète d'âmes déjà « creuses » densifie sa carapace au fil des décennies, mais éteint peu à peu ce qui lui restait d'esprit. Il ne chasse pas — il attend.",
		patterns = "Charge lourde en ligne droite, puis coups circulaires s'il parvient au contact.",
		parade   = "Parade parfaite SUR LE PREMIER IMPACT de la charge ; sinon ESQUIVER latéralement.",
		esquive  = "Ne JAMAIS reculer en ligne : sa charge gagne de la vitesse. Sortir de l'axe, toujours.",
		faiblesse = "Ses virages sont mauvais : tourner autour de lui en frappant les jambes.",
		secret   = "Après trois charges ratées, il s'essouffle quelques secondes : c'est là qu'on le brise.",
	},
	["ncm_pnj_hollow_coloso"] = {
		desc     = "Colosse territorial. Frappe le sol pour créer des ondes de choc en zone.",
		lore     = "Les anciens récits en font d'ex-gardiens de la Forêt des Menos, chassés vers la surface après avoir perdu leur territoire. Leur masse de reiryoku compacté fait vibrer le sable à des centaines de mètres — les Quincy les surnommaient « les marteaux de Hueco Mundo ».",
		patterns = "Alterne coup de bras direct et FRAPPE AU SOL en AoE (onde circulaire).",
		parade   = "NE PAS parer l'onde de choc (imparable) : sauter/esquiver. Parade parfaite uniquement sur le coup de bras direct.",
		esquive  = "SAUTER l'onde au moment où le poing touche le sol ; rester à mi-distance rend ses bras inutiles.",
		faiblesse = "Long temps de récupération après la frappe au sol : fenêtre de dégâts maximale.",
		secret   = "Il lève TOUJOURS le bras gauche avant l'onde de zone, le droit avant le coup direct : lire les épaules.",
	},
	["ncm_pnj_hollow_abominacion"] = {
		desc     = "Abomination instable. Ses attaques semblent erratiques mais suivent un cycle.",
		lore     = "Fusion ratée de plusieurs âmes en un seul corps — un pré-Gillian avorté, resté à mi-chemin de l'évolution. Les voix qui l'habitent se disputent encore le contrôle du corps : c'est ce conflit intérieur qui rythme son cycle de coups, deux gestes fous puis un seul, terriblement décidé.",
		patterns = "Cycle de 3 coups : deux rapides et désordonnés, puis un 3e LENT et surpuissant.",
		parade   = "Parade parfaite SUR LE 3e COUP (le plus lent). Encaisser ou esquiver les deux premiers.",
		esquive  = "Rompre la distance sur les deux premiers coups, revenir dans l'axe pour le 3e.",
		faiblesse = "Vulnérable pendant tout le 3e coup : une parade parfaite le met au sol.",
		secret   = "Le cycle REPART À ZÉRO s'il change de cible : se relayer à deux le rend inoffensif.",
	},
	["ncm_pnj_hollow_grandfisher"] = {
		desc     = "Grand Fisher — boss. Utilise un LEURRE pour attirer ses proies avant de frapper.",
		lore     = "Recherché depuis plus d'un demi-siècle : il a échappé à toutes les patrouilles en fuyant systématiquement les combats perdus. Son leurre imite une âme innocente — il choisit ses proies parmi les humains capables de voir les esprits, et les dévore pour affiner encore son appât.",
		patterns = "Déploie son leurre puis frappe en traître dès qu'on s'en approche. Sous 30% PV : enrage, enchaînements plus rapides.",
		parade   = "Parade parfaite QUAND LE LEURRE SE RÉTRACTE (annonce l'attaque réelle).",
		esquive  = "Rester HORS du rayon du leurre : ses vraies attaques portent moins loin que l'appât.",
		faiblesse = "Ignorer le leurre le force à attaquer frontalement, où il est bien plus lisible.",
		secret   = "En rage (<30% PV), il abandonne le leurre : c'est le signe qu'il faut passer à l'offensive totale.",
	},
	["ncm_pnj_hollow_serpent"] = {
		desc     = "Serpent Hollow — boss. Balayages de queue dévastateurs et morsures éclair.",
		lore     = "Les serpents de Hueco Mundo grandissent en dévorant leurs propres congénères : chaque mue les rapproche du stade d'Adjuchas. Celui-ci a déjà mué plusieurs fois — les écailles de son ancien corps jonchent encore, dit-on, la galerie où il a dévoré sa fratrie.",
		patterns = "Alterne BALAYAGE de queue à ras du sol (360°) et MORSURE précédée d'un sifflement.",
		parade   = "Parade parfaite sur la MORSURE (au sifflement). SAUTER le balayage — ne jamais le parer.",
		esquive  = "Le balayage part TOUJOURS de la droite du serpent : sauter en se décalant à sa gauche.",
		faiblesse = "Tête vulnérable pendant 2 s après une morsure dans le vide.",
		secret   = "Il ne mord jamais deux fois de suite : après une morsure esquivée, le balayage est GARANTI — sauter d'avance.",
	},
	["ncm_pnj_hollow_menos"] = {
		desc     = "Menos Grande — boss. Gigantesque, lent, mais son Cero rase des zones entières.",
		lore     = "Quand des centaines de Hollows s'entre-dévorent, leurs âmes fusionnent en une seule masse : le Menos Grande, premier stade — Gillian — de l'évolution des Menos. La plupart n'ont plus aucune conscience propre ; les rares qui gardent une volonté finissent par devenir Adjuchas… puis, pour une poignée, Vasto Lorde.",
		patterns = "Charge un CERO (lueur rouge à la bouche) puis balaie la zone. Piétine les cibles proches.",
		parade   = "Le CERO est IMPARABLE : rompre la ligne de vue ou s'écarter. Parade parfaite possible sur le PIÉTINEMENT, au lever de la jambe.",
		esquive  = "Dès la lueur rouge : se mettre DERRIÈRE lui ou derrière un mur épais. Ne jamais courir en arrière face au Cero.",
		faiblesse = "Frapper les chevilles : la tête est hors de portée et le haut du corps encaisse moins.",
		secret   = "Après un Cero, il reste immobile plusieurs secondes pour « recharger » : c'est LA fenêtre de burst de tout le groupe.",
	},
	["ncm_pnj_boss"] = {
		desc     = "Gardien colossal. Coups de masse d'une lenteur trompeuse : chaque impact est létal.",
		lore     = "Certains Hollows séculaires cessent d'errer : ils se « fixent » à un lieu saturé de reiatsu et le défendent comme un territoire, des siècles durant. Les archives n'en recensent qu'une poignée — chacun a coûté des vies entières de scientifiques avant que sa carcasse n'arrive sur une paillasse.",
		patterns = "Coups de masse verticaux très télégraphiés, parfois enchaînés par une seconde frappe horizontale.",
		parade   = "Parade parfaite GÉNÉREUSE (l'attaque est lente) — mais une parade simple inflige d'énormes dégâts de garde.",
		esquive  = "Un pas dans son dos à CHAQUE frappe verticale : il pivote trop lentement pour suivre.",
		faiblesse = "Se placer DERRIÈRE lui pendant la récupération : il pivote très lentement.",
		secret   = "La frappe horizontale ne vient QUE si on reste devant lui après la verticale : rester dans le dos l'annule totalement.",
	},
}

-- Intel auto-généré (fallback) pour les classes sans entrée manuelle.
function EVO_SCIENCE.GetIntel(sClass)
	local manual = EVO_SCIENCE.INTEL[sClass]
	if manual then return manual end
	local info = EVO_SCIENCE.NpcInfo(sClass)
	local agile = (info.speed or 0) >= 400
	local fort  = (info.dmg or 0) >= 180
	return {
		desc = "Spécimen Hollow " .. (info.boss and "de classe supérieure" or "standard")
			.. (agile and ", très mobile" or ", peu mobile") .. ".",
		lore = info.boss
			and "Lignée mal documentée : un Hollow n'atteint cette envergure qu'après des décennies à dévorer ses semblables dans les profondeurs de Hueco Mundo. Ces carcasses sont les premières archives de la faction à son sujet."
			or "Âme errante dont la Chaîne du Destin s'est rongée jusqu'au cœur, comme tous les Hollows. Aucune archive détaillée sur cette lignée : chaque carcasse analysée enrichit un dossier encore vierge.",
		patterns = agile and "Attaques rapides et répétées : garder la parade prête en continu."
			or "Attaques lentes et télégraphiées : observer la posture avant chaque coup.",
		parade = fort and "Frappes létales : PRIORITÉ à la parade parfaite plutôt qu'à l'échange de coups."
			or "Dégâts modérés : la parade simple suffit pour temporiser.",
		esquive = agile and "Trop rapide pour être distancé : esquiver au CONTACT, pas à l'approche."
			or "Lent : garder la distance et tourner autour suffit à annuler la plupart de ses coups.",
		faiblesse = info.boss and "Endurance exceptionnelle : combattre en groupe et par fenêtres courtes."
			or "Constitution ordinaire : un burst coordonné l'abat rapidement.",
		secret = info.boss and "Les spécimens de cette classe suivent des cycles fixes : observer deux attaques suffit pour prédire la troisième."
			or "Rien d'exceptionnel à signaler : appliquer la doctrine standard anti-Hollow.",
	}
end
