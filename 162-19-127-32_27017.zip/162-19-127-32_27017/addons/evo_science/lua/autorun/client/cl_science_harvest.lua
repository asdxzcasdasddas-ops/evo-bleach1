-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_harvest.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE RECOLTE (client) : prompt « [E] Ramasser » au-dessus des
-- champignons spawnes et des cristaux droppes, envoi du ramassage au serveur.
-- Identification par CHEMIN DE MODELE (listes partagees dans sh_science_hub) :
-- aucune cle reseau consommee. Meme plaque DA que le prompt PNJ central.
-- ============================================================================

EVO_SCIENCE = EVO_SCIENCE or {}
local CFG = EVO_SCIENCE.CFG
local HUB = CFG.Hub

-- Set des modeles ramassables + resolution du nom affiche.
local MODELS = nil -- [modelLower] = { variety = t } | { tier = n } | { plant = true, nGive = n }
local function modelSet()
	if MODELS then return MODELS end
	MODELS = {}
	for _, m in ipairs(HUB.MushroomModels) do
		local v = EVO_SCIENCE.MushroomByModel(m)
		if v then MODELS[string.lower(m)] = { variety = v } end
	end
	for nTier, m in pairs(HUB.CrystalModels) do
		MODELS[string.lower(m)] = { tier = nTier }
	end
	-- Plantes (user 08/10) : variete = SKIN du prop, taille = quantite donnee.
	for _, p in ipairs(HUB.PlantModels) do
		MODELS[string.lower(p.model)] = { plant = true, nGive = p.nGive or 1 }
	end
	return MODELS
end

local function harvestLabel(ent, info)
	if info.variety then
		return info.variety.name or "Champignon"
	end
	if info.plant then
		local v = HUB.Plants[(ent:GetSkin() or 0) + 1]
		local sName = (v and v.name) or "Plante"
		return (info.nGive or 1) > 1 and (sName .. " ×" .. info.nGive) or sName
	end
	local c = HUB.CrystalColors[(ent:GetSkin() or 0) + 1]
	return (HUB.CrystalTierNames[info.tier] or "Cristal") .. (c and (" (" .. c.name .. ")") or "")
end

-- Scan throttle ~4 Hz : l'entite ramassable la plus proche a portee.
local _best, _bestLabel, _nextScan = nil, "", 0
local function findHarvest()
	if CurTime() < _nextScan then return _best end
	_nextScan = CurTime() + 0.25
	_best, _bestLabel = nil, ""
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return nil end
	local set = modelSet()
	local range = HUB.HarvestRange or 120
	local vPos = lp:GetPos()
	local bestD = range * range
	for _, e in ipairs(ents.FindInSphere(vPos, range)) do
		-- prop_dynamic spawnés par le hub seulement. Les cultures en pot
		-- (evo_agri_pot + ClientsideModel) réutilisent les mêmes meshes :
		-- sans ce filtre le prompt « Ramasser » recouvre le pot planté.
		if IsValid(e) and e:EntIndex() > 0 and e:GetClass() == "prop_dynamic" then
			local info = set[string.lower(e:GetModel() or "")]
			if info then
				local d = e:GetPos():DistToSqr(vPos)
				if d <= bestD then
					bestD = d
					_best = e
					_bestLabel = harvestLabel(e, info)
				end
			end
		end
	end
	return _best
end

-- Prompt bas-ecran (meme plaque que le prompt PNJ d'evo_npc_core).
surface.CreateFont("EVOSci_Harvest", { font = "Roboto", size = 22, weight = 600, antialias = true })
surface.CreateFont("EVOSci_HarvestSub", { font = "Roboto", size = 16, weight = 400, antialias = true })

hook.Add("HUDPaint", "EVO_Science::HarvestPrompt", function()
	if vgui.CursorVisible() then return end
	-- Pas de prompt pendant qu'on mange/boit (prédicat central, user 08/19).
	if EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end
	local ent = findHarvest()
	if not IsValid(ent) then return end

	local txt = "[E] Ramasser"
	local sub = _bestLabel
	local cx, cy = ScrW() * 0.5, ScrH() * 0.78
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(cx, cy, sub, "Ramasser", "E")
		return
	end
	surface.SetFont("EVOSci_Harvest")
	local tw, th = surface.GetTextSize(txt)
	surface.SetFont("EVOSci_HarvestSub")
	local sw, sh = surface.GetTextSize(sub)
	local boxW = math.max(tw, sw) + 40
	local boxH = th + sh + 26

	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(13, 14, 17, 220), 8, "br")
	else
		draw.RoundedBox(0, cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(0, 0, 0, 180))
	end
	surface.SetDrawColor(150, 225, 165) -- accent SCI (vert labo)
	surface.DrawRect(cx - boxW * 0.5, cy - boxH * 0.5, 2, boxH)
	draw.SimpleText(txt, "EVOSci_Harvest", cx, cy - 8, Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sub, "EVOSci_HarvestSub", cx, cy + th * 0.5 + 2, Color(150, 225, 165), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("PlayerButtonDown", "EVO_Science::HarvestKey", function(ply, btn)
	if ply ~= LocalPlayer() or btn ~= KEY_E then return end
	if vgui.CursorVisible() then return end
	if gui.IsGameUIVisible() then return end
	if IsValid(vgui.GetKeyboardFocus()) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end

	local ent = findHarvest()
	if not IsValid(ent) then return end
	net.Start("EVO_Science::HarvestPick")
	net.WriteEntity(ent)
	net.SendToServer()
end)
