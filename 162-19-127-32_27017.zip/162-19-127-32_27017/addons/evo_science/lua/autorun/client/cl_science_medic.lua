-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_medic.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE — TABLE MÉDICALE (client, 08/18). PLUS DE FENÊTRE DÉDIÉE : tout
-- vit dans les ONGLETS de l'atelier soin d'evo_craft (demande user), même
-- pattern que l'onglet Forge de l'atelier combat. Ce fichier fournit les deux
-- builders appelés par BuildDetail (cl_main d'evo_craft) :
--   EVO_SCIENCE.BuildMedicMortier(pnl, padX)  — mélange + mini-jeu + récup
--   EVO_SCIENCE.BuildMedicCarnet(pnl, padX)   — livre DHTML des découvertes
-- DA de l'atelier (clean base) : cartes sombres arrondies SANS bordure, accent
-- #cf444e, fontes Bebas/Avenir glibs, RNDX. Le sac se lit par le miroir client
-- d'inventory/cl_net (GetInventoryItems), jamais ply.inventory (serveur only).
-- ============================================================================
if not CLIENT then return end

local CFG = EVO_SCIENCE.CFG
CFG.Hub = CFG.Hub or {} -- refresh à chaud : ne jamais capturer un Hub nil
local HUB = CFG.Hub

-- Tokens DA (mêmes valeurs que cl_main d'evo_craft).
local COL_DIMBG   = Color(4, 4, 8, 246)
local COL_SUB     = Color(20, 20, 24, 255)
local COL_SUB_HI  = Color(27, 27, 33, 255)
local COL_ROW     = Color(14, 14, 17, 255)
local COL_ACCENT  = Color(207, 68, 78)
local COL_TITLE   = Color(237, 238, 242)
local COL_MUTED   = Color(150, 154, 162)
local COL_DIMTXT  = Color(110, 113, 120)
local COL_GOLD    = Color(216, 185, 106)
local COL_OK      = Color(96, 220, 130)
local COL_BAD     = Color(226, 80, 80)

-- État reçu du serveur (MedSync) + mélange local en cours de dépôt + étoile
-- choisie (1★ par défaut, gate par niveau d'atelier soin côté serveur).
local MED = { found = {}, tbl = nil, mix = {}, star = 1, qty = 1 } -- qty = lot (craft en série, user 09/15)

local function mixCount()
	local n = 0
	for _ in pairs(MED.mix) do n = n + 1 end
	return n
end

-- Demande d'état au serveur (ouverture d'onglet). Throttle client : changer
-- d'onglet vite ne spamme pas, le cache MED sert entre deux réponses.
local nNextReq = 0
local function requestMedState()
	if CurTime() < nNextReq then return end
	nNextReq = CurTime() + 0.6
	net.Start("EVO_Science::MedOpen")
	net.SendToServer()
end

-- ── Sac : ingrédients admis au mortier (unités, piles comprises) ─────────────
local function bagIngredients()
	local lp = LocalPlayer()
	if not IsValid(lp) then return {} end
	local counts, order = {}, {}
	if lp.ForEachBagSlot then
		lp:ForEachBagSlot(function(_, sId, q)
			if EVO_SCIENCE.MedIngredientAllowed(sId) then
				if not counts[sId] then
					counts[sId] = 0
					order[#order + 1] = sId
				end
				counts[sId] = counts[sId] + q
			end
		end)
	elseif lp.GetInventoryItems then
		for _, sId in ipairs(lp:GetInventoryItems()) do
			if counts[sId] then
				counts[sId] = counts[sId] + 1
			elseif EVO_SCIENCE.MedIngredientAllowed(sId) then
				counts[sId] = 1
				order[#order + 1] = sId
			end
		end
	end
	table.sort(order, function(a, b)
		return EVO_SCIENCE.ItemName(a) < EVO_SCIENCE.ItemName(b)
	end)
	local out = {}
	for _, sId in ipairs(order) do out[#out + 1] = { id = sId, n = counts[sId] } end
	return out
end

-- Le sac a pu changer depuis le dernier dépôt : borne le mélange local.
local function clampMixToBag(tBag)
	local counts = {}
	for _, e in ipairs(tBag) do counts[e.id] = e.n end
	for sId, n in pairs(MED.mix) do
		local nHave = counts[sId] or 0
		if nHave <= 0 then
			MED.mix[sId] = nil
		elseif n > nHave then
			MED.mix[sId] = nHave
		end
	end
end

-- Boutons/croix : les helpers DA de l'ATELIER (EVO_CRAFT.MakeActionBtn /
-- MakeCloseCross, cl_main d'evo_craft) — ces onglets vivent dedans, on ne
-- recopie pas son langage UI. Appelés à l'exécution : evo_craft est chargé.

-- Scrollbar DA : fine, fond invisible, poignée arrondie acier -> accent.
local function styleScroll(sp)
	local vbar = sp:GetVBar()
	if not IsValid(vbar) then return end
	vbar:SetWide(gRespX(6))
	vbar:SetHideButtons(true)
	vbar.Paint = nil
	vbar.btnGrip.Paint = function(s, gw, gh)
		RNDX.Draw(gw / 2, 0, 0, gw, gh,
			(s.Depressed or s:IsHovered()) and COL_ACCENT or Color(60, 60, 68, 220))
	end
end

-- Aperçu 3D d'un item dans une rangée (même composant que l'inventaire). Le
-- DModelPanel est LAZY et volerait les clics de la rangée : son input est
-- coupé au Think (pattern des cartes d'enchantement de l'atelier).
local function rowItemPreview(row, sItemId, x, size)
	local it = ITEMS and ITEMS[sItemId]
	local holder = vgui.Create("DPanel", row)
	holder:SetPos(x, (row:GetTall() - size) / 2)
	holder:SetSize(size, size)
	holder.Paint = nil
	if it and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it)
	end
	row.Think = function()
		local mp = holder._modelPanel
		if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
	end
end

-- Boucle de son d'ACTION (broyage, versement) : CSoundPatch relancé
-- périodiquement tant que le geste est actif (les mp3 ne bouclent pas
-- nativement dans Source), coupé NET dès que le geste s'arrête.
-- (Exportée plus bas : les mini-jeux d'étapes de POTION, cl_science_hub,
-- utilisent la même boucle — pas de copie là-bas.)
local function ActionLoop(sPath)
	local t = { snd = nil, nextAt = -1 }
	function t:Tick(bActive)
		if bActive then
			if RealTime() >= self.nextAt then -- -1 (à l'arrêt) relance direct
				self.snd = self.snd or (sPath ~= "" and CreateSound(LocalPlayer(), sPath) or nil)
				if self.snd then
					self.snd:Stop()
					self.snd:PlayEx(0.7, 100)
				end
				self.nextAt = RealTime() + 2.4
			end
		elseif self.nextAt >= 0 then
			if self.snd then self.snd:Stop() end
			self.nextAt = -1
		end
	end
	function t:Kill()
		if self.snd then self.snd:Stop() self.snd = nil end
	end
	return t
end
EVO_SCIENCE.ActionLoop = ActionLoop

-- ── Mini-jeu du pilon (overlay plein écran, recette du mini-jeu de forge) ────
-- Mouvements CIRCULAIRES à vitesse régulière, clic gauche enfoncé. Trop brusque
-- = jauge de casse ; pleine = raté (les ingrédients sont déjà consommés).
-- Dans le bol : les MODÈLES des ingrédients déposés rétrécissent à mesure du
-- broyage et le PRODUIT se forme au centre (si la recette est connue) — retour
-- user 08/18 « plus on bouge, plus ça devient le model que ça doit devenir ».
local function openGrindGame(sToken, tIng, sResModel, nResSkin)
	local ov = vgui.Create("DPanel")
	ov:SetSize(ScrW(), ScrH())
	ov:SetPos(0, 0)
	ov:MakePopup()
	ov:SetKeyboardInputEnabled(true)
	-- Le PILON remplace le curseur (retour user : « le pilon doit être dans la
	-- souris directement ») : flèche système masquée sur l'overlay.
	ov:SetCursor("blank")

	local mortier = ClientsideModel(HUB.MedicModels.mortier, RENDERGROUP_OPAQUE)
	local pilon = ClientsideModel(HUB.MedicModels.pilon, RENDERGROUP_OPAQUE)
	if IsValid(mortier) then mortier:SetNoDraw(true) end
	if IsValid(pilon) then pilon:SetNoDraw(true) end

	local tIngMdl = {}
	for _, e in ipairs(tIng or {}) do
		local m = ClientsideModel(e.mdl, RENDERGROUP_OPAQUE)
		if IsValid(m) then
			m:SetNoDraw(true)
			m:SetSkin(e.skin or 0)
			tIngMdl[#tIngMdl + 1] = m
		end
	end
	local resMdl
	if isstring(sResModel) and sResModel ~= "" then
		resMdl = ClientsideModel(sResModel, RENDERGROUP_OPAQUE)
		if IsValid(resMdl) then
			resMdl:SetNoDraw(true)
			resMdl:SetSkin(nResSkin or 0)
		end
	end

	local nGoal = (HUB.MedGrindTurns or 8) * math.pi * 2
	local nProgress, nCasse = 0, 0
	local nLastAng, nLastT = nil, RealTime()
	local nAngSmooth = 0
	local bDone = false
	local sndMix = ActionLoop(CFG.Sounds.medMixing or "")

	local function finish(bOk)
		if bDone then return end
		bDone = true
		net.Start("EVO_Science::MedGameResult")
		net.WriteString(sToken)
		net.WriteBool(bOk)
		net.SendToServer()
		surface.PlaySound(bOk and (CFG.Sounds.sampleOk or "") or (CFG.Sounds.sampleFail or ""))
		if IsValid(ov) then ov:Remove() end
	end

	ov.OnRemove = function()
		sndMix:Kill()
		if IsValid(mortier) then mortier:Remove() end
		if IsValid(pilon) then pilon:Remove() end
		for _, m in ipairs(tIngMdl) do
			if IsValid(m) then m:Remove() end
		end
		if IsValid(resMdl) then resMdl:Remove() end
		-- Fenêtre fermée sans finir = raté (les ingrédients sont déjà consommés).
		if not bDone then finish(false) end
	end
	ov.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE then finish(false) end
	end

	ov.Paint = function(pnl, w, h)
		-- Couche PLATE : voile sombre (pas de coins arrondis = pas de liseré).
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)

		local cx = w * 0.5
		local mx, my = pnl:CursorPos()
		local cy = h * 0.5

		-- Géométrie du geste : angle de la souris autour du centre de la scène.
		local dx, dy = mx - cx, my - cy
		local nAng = math.atan2(dy, dx)
		local now = RealTime()
		local dt = math.max(0.001, now - nLastT)
		nLastT = now

		local bHeld = input.IsMouseDown(MOUSE_LEFT)
		if nLastAng and bHeld then
			local d = math.abs(math.NormalizeAngle(math.deg(nAng - nLastAng)))
			local nSpeed = math.rad(d) / dt -- rad/s
			nAngSmooth = nAngSmooth + (nSpeed - nAngSmooth) * math.min(1, dt * 8)
			if nAngSmooth >= (HUB.MedGrindMinSpeed or 2) and nAngSmooth <= (HUB.MedGrindMaxSpeed or 9) then
				nProgress = nProgress + math.rad(d)
			elseif nAngSmooth > (HUB.MedGrindBreakAt or 14) then
				nCasse = nCasse + (nAngSmooth - HUB.MedGrindBreakAt) * dt * 0.12
			end
		end
		nLastAng = nAng
		-- Son de broyage tant que le geste tourne assez vite (coupé net sinon).
		sndMix:Tick(bHeld and nAngSmooth >= (HUB.MedGrindMinSpeed or 2) * 0.6)
		-- Envois ONE-SHOT verrouillés par bDone (fin de partie), pas par frame.
		-- netgate: edge
		if nCasse >= 1 then finish(false) return end
		-- netgate: edge
		if nProgress >= nGoal then finish(true) return end

		-- Titre + consigne (recette du mini-jeu de forge de l'atelier).
		draw.SimpleText("PILER LE MÉLANGE", "Bebas Neue:64", cx, gRespY(92),
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		RNDX.Draw(gRespY(2), cx - gRespX(120), gRespY(126), gRespX(240), gRespY(4), COL_ACCENT)
		draw.SimpleText("Maintiens le CLIC GAUCHE et tourne autour du mortier, d'un geste régulier.",
			"Avenir Next World:20", cx, gRespY(160), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		-- Scène 3D : mortier FIXE au centre. ⚠ Le pilon n'est PAS placé dans
		-- cette scène : replaquer l'angle souris dans une perspective 3D donnait
		-- une orbite en ellipse décalée (retour user : « il ne bouge pas à 360 »).
		if IsValid(mortier) then
			mortier:SetPos(vector_origin)
			mortier:SetAngles(angle_zero)
		end
		local nSize = gRespX(460)
		local prog = math.min(1, nProgress / nGoal)
		cam.Start3D(Vector(26, 0, 30), Angle(38, 180, 0), 34, cx - nSize / 2, cy - nSize / 2, nSize, nSize)
			render.SuppressEngineLighting(true)
			if IsValid(mortier) then mortier:DrawModel() end
			-- Ingrédients dans le bol : ils tournent (brassés) et RÉTRÉCISSENT à
			-- mesure du broyage ; le PRODUIT se forme au centre en échange.
			-- Placement en ANNEAUX (user 08/20) : une dose = un modèle, répartis
			-- sur trois rayons et deux hauteurs pour que TOUT le dépôt se voie.
			local nBase = #tIngMdl > 8 and 0.28 or 0.38
			for i = 1, #tIngMdl do
				local m = tIngMdl[i]
				local sc = nBase * (1 - prog)
				if IsValid(m) and sc > 0.03 then
					local a = now * 0.9 + i * 2.4
					local r = 1.2 + (i % 3) * 0.9
					m:SetPos(Vector(math.cos(a) * r, math.sin(a) * r, 4.2 + (i % 2) * 0.9 - prog * 1.6))
					m:SetAngles(Angle(0, math.deg(a) + now * 40, 0))
					m:SetModelScale(sc, 0)
					m:DrawModel()
				end
			end
			if IsValid(resMdl) then
				local sc = 0.55 * math.max(0, (prog - 0.2) / 0.8)
				if sc > 0.02 then
					resMdl:SetPos(Vector(0, 0, 4.4))
					resMdl:SetAngles(Angle(0, now * 60, 0))
					resMdl:SetModelScale(sc, 0)
					resMdl:DrawModel()
				end
			end
			render.SuppressEngineLighting(false)
		cam.End3D()

		-- Le PILON suit la souris 1:1 : viewport 3D recentré sur le curseur à
		-- chaque frame (l'écran est le plan de jeu, aucune projection à subir).
		-- Levé quand le clic est lâché, tangage de broyage quand il est tenu.
		if IsValid(pilon) then
			pilon:SetPos(vector_origin)
			pilon:SetAngles(Angle(bHeld and math.sin(RealTime() * 9) * 7 or 0, math.deg(-nAng), 0))
			local pw = gRespX(240)
			cam.Start3D(Vector(30, 0, 8), Angle(6, 180, 0), 30,
				mx - pw / 2, my - pw / 2 - (bHeld and 0 or gRespY(16)), pw, pw)
				render.SuppressEngineLighting(true)
				pilon:DrawModel()
				render.SuppressEngineLighting(false)
			cam.End3D()
		end

		-- Tempo du geste.
		local sTempo = nAngSmooth < (HUB.MedGrindMinSpeed or 2) and "PLUS VITE…"
			or (nAngSmooth > (HUB.MedGrindMaxSpeed or 9) and "TROP VITE !" or "BON RYTHME")
		draw.SimpleText(sTempo, "Bebas Neue:34", cx, h - gRespY(252),
			sTempo == "BON RYTHME" and COL_OK or (sTempo == "TROP VITE !" and COL_BAD or COL_MUTED),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		-- Jauges arrondies : broyage (accent) puis casse (rouge).
		local bw, bh = gRespX(560), gRespY(22)
		local bx, by = cx - bw / 2, h - gRespY(196)
		draw.SimpleText("BROYAGE", "Bebas Neue:22", bx, by - gRespY(22), COL_MUTED)
		RNDX.Draw(bh / 2, bx, by, bw, bh, COL_SUB)
		local fw = math.floor(bw * math.min(1, nProgress / nGoal))
		if fw > bh then RNDX.Draw(bh / 2, bx, by, fw, bh, COL_ACCENT) end
		local by2 = by + gRespY(56)
		draw.SimpleText("CASSE (geste trop brusque)", "Bebas Neue:22", bx, by2 - gRespY(22), COL_MUTED)
		RNDX.Draw(bh / 2, bx, by2, bw, bh, COL_SUB)
		local fw2 = math.floor(bw * math.min(1, nCasse))
		if fw2 > bh then RNDX.Draw(bh / 2, bx, by2, fw2, bh, COL_BAD) end
	end

	-- Croix standard de l'atelier : abandonner = raté (mêmes conséquences
	-- qu'Échap). Curseur main explicite : celui de l'overlay est masqué.
	if EVO_CRAFT and EVO_CRAFT.MakeCloseCross then
		local x = EVO_CRAFT.MakeCloseCross(ov, ov:GetWide() - gRespX(104), gRespY(44), function() finish(false) end)
		x:SetCursor("hand")
	end
end

-- ── Banc de verrerie (2e mini-jeu, INJECTABLES seulement) ────────────────────
-- La VRAIE verrerie en 3D (demande user 08/18 : « les vrais items, pas des
-- dessins ») : erlenmeyer au centre, bécher/fiole jaugée qui s'inclinent pour
-- verser, pipette au-dessus du col — les assets de HUB.MedicDecor rendus en
-- ClientsideModel comme le mortier. Le LIQUIDE reste un calque 2D par-dessus
-- le verre (niveau qui clapote, filet, gouttes, bulles) : un niveau qui monte
-- DANS un mesh ne se truque pas proprement. 4 étapes : BÉCHER (décoction avec
-- l'inertie du filet, lâcher tôt !), FIOLE JAUGÉE (solvant, bande plus
-- étroite), PIPETTE (une goutte par CLIC, bande fine), CHAUFFE (bande qui
-- dérive, ébullition prolongée = raté). Trop plein = PURGE (2 max).
local function hexToColor(s)
	local r, g, b = string.match(s or "", "^#(%x%x)(%x%x)(%x%x)$")
	if not r then return Color(207, 68, 78) end
	return Color(tonumber(r, 16), tonumber(g, 16), tonumber(b, 16))
end

local function openLiquidGame(sToken, sCat)
	local ov = vgui.Create("DPanel")
	ov:SetSize(ScrW(), ScrH())
	ov:SetPos(0, 0)
	ov:MakePopup()
	ov:SetKeyboardInputEnabled(true)

	local catDef = HUB.MedCategories[sCat]
	local colDecoct = hexToColor(catDef and catDef.sHex)
	local colSolvant = Color(172, 205, 218)
	local colPour = colDecoct
	local colMix = Color(colDecoct.r, colDecoct.g, colDecoct.b, 205)

	-- Les VRAIS modèles de la verrerie (assets HUB.MedicDecor). Cadrages des
	-- viewports 3D à AJUSTER en jeu si un modèle sort du cadre.
	local function csDecorModel(sId)
		for _, d in ipairs(HUB.MedicDecor or {}) do
			if d.id == sId then
				local m = ClientsideModel(d.model, RENDERGROUP_OPAQUE)
				if IsValid(m) then m:SetNoDraw(true) return m end
				return nil
			end
		end
		return nil
	end
	local mErlen   = csDecorModel("med_erlenmeyer")
	local mBecher  = csDecorModel("med_becher")
	local mFiole   = csDecorModel("med_fiole")
	local mPipette = csDecorModel("med_pipette")
	local ERLEN_CAM, ERLEN_FOV = Vector(34, 0, 9), 30
	local POUR_CAM,  POUR_FOV  = Vector(26, 0, 6), 30
	local PIP_CAM,   PIP_FOV   = Vector(22, 0, 6), 26

	-- Cibles en fraction de la contenance : décoction (bécher), NIVEAU TOTAL au
	-- solvant (fiole jaugée), puis titrage FIN à la pipette (bande étroite).
	local BAND_A = { 0.44, 0.54 }
	local BAND_B = { 0.72, 0.80 }
	local BAND_C = { 0.86, 0.90 }
	local DROP = 0.012     -- apport d'une goutte de pipette
	local OVER = 0.045     -- marge au-dessus de la bande avant purge
	local HEAT_NEED = 6    -- s d'aiguille dans la bande pour stabiliser

	local nPhase = 1       -- 1 bécher, 2 fiole jaugée, 3 pipette, 4 chauffe
	local nLevel, nBase, nRate = 0, 0, 0
	local nA = 0           -- part de décoction (teinte du mélange)
	local nPurges, bPurging = 2, false
	local nSettle, nTilt = 0, 0
	local nTemp, nHeatProg, nBoil = 0, 0, 0
	local tBubbles, tDrops = {}, {}
	local sFeedback, colFeedback, feedbackUntil = nil, COL_MUTED, 0
	local nLastT = RealTime()
	local bDone = false
	local sEnd = nil
	local sndFill = ActionLoop(CFG.Sounds.medFill or "")

	local function finish(bOk)
		if bDone then return end
		bDone = true
		net.Start("EVO_Science::MedLiquidResult")
		net.WriteString(sToken)
		net.WriteBool(bOk)
		net.SendToServer()
		surface.PlaySound(bOk and (CFG.Sounds.sampleOk or "") or (CFG.Sounds.sampleFail or ""))
		if IsValid(ov) then ov:Remove() end
	end

	ov.OnRemove = function()
		sndFill:Kill()
		if IsValid(mErlen) then mErlen:Remove() end
		if IsValid(mBecher) then mBecher:Remove() end
		if IsValid(mFiole) then mFiole:Remove() end
		if IsValid(mPipette) then mPipette:Remove() end
		if not bDone then finish(false) end
	end
	ov.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE then finish(false) end
	end
	-- Pipette (étape 3) : une goutte par CLIC. Le y de chute est posé au Paint
	-- (la géométrie du col y vit) ; 3 gouttes en vol maximum.
	ov.OnMousePressed = function(_, mc)
		if mc ~= MOUSE_LEFT or bDone or bPurging or nPhase ~= 3 then return end
		if #tDrops >= 3 then return end
		tDrops[#tDrops + 1] = {}
		surface.PlaySound(CFG.Sounds.click or "")
	end

	local tLiq = { {}, {}, {}, {} } -- polygone du liquide, réutilisé

	ov.Paint = function(pnl, w, h)
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)

		local now = RealTime()
		local dt = math.min(0.1, math.max(0.001, now - nLastT))
		nLastT = now
		local bHeld = input.IsMouseDown(MOUSE_LEFT)

		-- Géométrie de l'erlenmeyer (cône + col).
		local cx = w * 0.5
		local baseY = h * 0.68
		local BH = gRespY(320)
		local W0, W1 = gRespX(160), gRespX(52)
		local NH = gRespY(74) -- hauteur du col (position du filet et de la pipette)
		local mouthY = baseY - BH - NH
		local function halfAt(f) return W0 + (W1 - W0) * f end

		-- ── Simulation ───────────────────────────────────────────────────────
		local band = nPhase == 1 and BAND_A or (nPhase == 2 and BAND_B or BAND_C)
		if nPhase <= 2 then
			if bPurging then
				nLevel = math.max(nBase, nLevel - dt * 0.9)
				if nLevel <= nBase then bPurging = false end
			else
				if bHeld then
					nRate = math.min(0.15, nRate + dt * 0.20)
				else
					nRate = math.max(0, nRate - dt * 0.26) -- l'inertie du filet
				end
				nLevel = math.min(1, nLevel + nRate * dt)
				if nLevel > band[2] + OVER then
					if nPurges <= 0 then
						sEnd = false
					else
						nPurges = nPurges - 1
						bPurging = true
						nRate, nSettle = 0, 0
						surface.PlaySound(CFG.Sounds.sampleFail or "")
						sFeedback, colFeedback, feedbackUntil = "TROP PLEIN : PURGE…", COL_BAD, now + 1.4
					end
				elseif nRate <= 0 and nLevel >= band[1] and nLevel <= band[2] then
					nSettle = nSettle + dt
					if nSettle > 0.7 then
						surface.PlaySound(CFG.Sounds.click or "")
						sFeedback, colFeedback, feedbackUntil = "DOSAGE JUSTE", COL_OK, now + 1
						if nPhase == 1 then nA = nLevel end
						nPhase = nPhase + 1
						nBase, nRate, nSettle = nLevel, 0, 0
					end
				else
					nSettle = 0
				end
			end
		elseif nPhase == 3 then
			-- Pipette : les gouttes lâchées tombent puis font monter le niveau.
			if bPurging then
				nLevel = math.max(nBase, nLevel - dt * 0.9)
				if nLevel <= nBase then bPurging = false end
			else
				local ySurf = baseY - nLevel * BH
				for i = #tDrops, 1, -1 do
					local d = tDrops[i]
					d.y = (d.y or (mouthY - gRespY(8))) + dt * gRespY(520)
					if d.y >= ySurf then
						table.remove(tDrops, i)
						nLevel = math.min(1, nLevel + DROP)
					end
				end
				if nLevel > band[2] + 0.018 then
					if nPurges <= 0 then
						sEnd = false
					else
						nPurges = nPurges - 1
						bPurging = true
						nSettle = 0
						for i = #tDrops, 1, -1 do tDrops[i] = nil end
						surface.PlaySound(CFG.Sounds.sampleFail or "")
						sFeedback, colFeedback, feedbackUntil = "UNE GOUTTE DE TROP : PURGE…", COL_BAD, now + 1.4
					end
				elseif #tDrops == 0 and nLevel >= band[1] and nLevel <= band[2] then
					nSettle = nSettle + dt
					if nSettle > 0.8 then
						surface.PlaySound(CFG.Sounds.click or "")
						sFeedback, colFeedback, feedbackUntil = "TITRAGE PARFAIT", COL_OK, now + 1
						nPhase, nSettle = 4, 0
					end
				else
					nSettle = 0
				end
			end
		else
			-- Chauffe : la bande dérive, maintenir chauffe, relâcher refroidit.
			local c = 0.52 + 0.20 * math.sin(now * 0.55) + 0.07 * math.sin(now * 1.35)
			local hw = 0.09
			nTemp = math.Clamp(nTemp + (bHeld and 0.45 or -0.32) * dt, 0, 1)
			if math.abs(nTemp - c) <= hw then
				nHeatProg = nHeatProg + dt
				if nHeatProg >= HEAT_NEED then sEnd = true end
			end
			if nTemp > c + hw + 0.15 then
				nBoil = nBoil + dt
				if nBoil > 1.1 then sEnd = false end
			else
				nBoil = math.max(0, nBoil - dt * 0.8)
			end
			-- Bulles : naissent au fond, montent, éclatent à la surface.
			if nTemp > 0.25 and math.random() < dt * (2 + nTemp * 9) then
				tBubbles[#tBubbles + 1] = {
					x = cx + (math.random() * 1.6 - 0.8) * halfAt(0.12),
					y = baseY - gRespY(8),
					r = gRespX(2) + math.random() * gRespX(3),
					v = gRespY(30) + math.random() * gRespY(45),
				}
			end
		end
		-- Son de remplissage tant que le liquide coule (versements, coupé net).
		sndFill:Tick(nPhase <= 2 and not bPurging and nRate > 0.008)

		-- Fin de partie : envoi ONE-SHOT verrouillé par bDone.
		-- netgate: edge
		if sEnd ~= nil then finish(sEnd) return end

		-- ── Habillage ────────────────────────────────────────────────────────
		draw.SimpleText("BANC DE VERRERIE", "Bebas Neue:64", cx, gRespY(92),
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		RNDX.Draw(gRespY(2), cx - gRespX(120), gRespY(126), gRespX(240), gRespY(4), COL_ACCENT)
		local sHint = nPhase == 1
			and "Maintiens le CLIC GAUCHE : le bécher verse la décoction jusqu'à la bande. Lâche tôt, les dernières gouttes tombent seules."
			or (nPhase == 2 and "La fiole jaugée complète au solvant clair jusqu'à la deuxième bande."
			or (nPhase == 3 and "Titrage à la PIPETTE : un CLIC = une goutte, jusque dans la bande étroite."
			or "Maintiens le CLIC pour chauffer : garde l'aiguille dans la bande, sans faire bouillir."))
		draw.SimpleText(sHint, "Avenir Next World:20", cx, gRespY(160), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		-- Étapes (chaque outil de la verrerie a la sienne).
		local tSteps = { "1. BÉCHER", "2. FIOLE JAUGÉE", "3. PIPETTE", "4. CHAUFFE" }
		for i = 1, 4 do
			local sx = cx + (i - 2.5) * gRespX(170)
			local col = i < nPhase and COL_OK or (i == nPhase and COL_TITLE or COL_DIMTXT)
			draw.SimpleText(tSteps[i], "Bebas Neue:26", sx, gRespY(212), col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if i == nPhase then
				RNDX.Draw(gRespY(2), sx - gRespX(46), gRespY(230), gRespX(92), gRespY(3), COL_ACCENT)
			end
		end

		-- Le VRAI erlenmeyer en 3D (le calque liquide 2D se dessine par-dessus).
		if IsValid(mErlen) then
			mErlen:SetPos(vector_origin)
			mErlen:SetAngles(angle_zero)
			local vw = gRespX(430)
			cam.Start3D(ERLEN_CAM, Angle(4, 180, 0), ERLEN_FOV,
				cx - vw / 2, mouthY - gRespY(14), vw, baseY - mouthY + gRespY(44))
				render.SuppressEngineLighting(true)
				mErlen:DrawModel()
				render.SuppressEngineLighting(false)
			cam.End3D()
		end

		-- Graduations + bande cible (phases de versement).
		for f = 0.2, 0.81, 0.2 do
			local gy = baseY - f * BH
			surface.SetDrawColor(146, 152, 161, 90)
			surface.DrawRect(cx + halfAt(f) - gRespX(16), gy, gRespX(16), 1)
		end
		if nPhase <= 3 then
			local y1, y2 = baseY - band[1] * BH, baseY - band[2] * BH
			local Wb = halfAt((band[1] + band[2]) / 2)
			surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 32)
			surface.DrawRect(cx - Wb, y2, Wb * 2, y1 - y2)
			surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 150)
			surface.DrawRect(cx - Wb, y1, Wb * 2, 1)
			surface.DrawRect(cx - Wb, y2, Wb * 2, 1)
			draw.SimpleText("PURGES : " .. nPurges, "Bebas Neue:22", cx + W0 + gRespX(24), baseY - BH,
				nPurges > 0 and COL_MUTED or COL_BAD)
		end

		-- Liquide : teinte décoction -> mélange au solvant, réchauffée en chauffe.
		local fS = (nLevel > nA and nLevel > 0) and (nLevel - nA) / nLevel or 0
		colMix.r = Lerp(fS * 0.55, colDecoct.r, colSolvant.r) + nTemp * 26
		colMix.g = Lerp(fS * 0.55, colDecoct.g, colSolvant.g) + nTemp * 8
		colMix.b = Lerp(fS * 0.55, colDecoct.b, colSolvant.b)
		if nLevel > 0.01 then
			local yL = baseY - nLevel * BH
			local Wt = halfAt(nLevel)
			local amp = gRespY(2) + nRate * gRespY(70) + nTemp * gRespY(4)
			local sw = math.sin(now * 4.2) * amp * 0.5
			tLiq[1].x, tLiq[1].y = cx - Wt, yL + sw
			tLiq[2].x, tLiq[2].y = cx + Wt, yL - sw
			tLiq[3].x, tLiq[3].y = cx + W0 - 1, baseY - 1
			tLiq[4].x, tLiq[4].y = cx - W0 + 1, baseY - 1
			draw.NoTexture()
			surface.SetDrawColor(colMix.r, colMix.g, colMix.b, 205)
			surface.DrawPoly(tLiq)
			-- Ménisque.
			surface.SetDrawColor(255, 255, 255, 60)
			surface.DrawRect(cx - Wt, yL - 1, Wt * 2, gRespY(2))
			-- Bulles (chauffe).
			for i = #tBubbles, 1, -1 do
				local b = tBubbles[i]
				b.y = b.y - b.v * dt
				if b.y <= yL + gRespY(6) then
					table.remove(tBubbles, i)
				else
					RNDX.DrawCircle(b.x, b.y, b.r, Color(255, 255, 255, 70))
				end
			end
		end

		-- Récipient qui verse : le VRAI BÉCHER (étape 1) ou la VRAIE FIOLE JAUGÉE
		-- (étape 2), qui glissent vers le col et S'INCLINENT quand on verse.
		if nPhase <= 2 and not bPurging then
			colPour = nPhase == 1 and colDecoct or colSolvant
			nTilt = Lerp(math.min(1, dt * 8), nTilt, bHeld and 1 or 0)
			-- Au repos le récipient attend à droite ; en VERSANT il vient se
			-- CENTRER au-dessus du col (retour user 08/19 : « trop à droite »,
			-- le filet coule à cx, le récipient doit être dessus).
			local fx = cx + gRespX(150) - nTilt * gRespX(150)
			local fy = mouthY - gRespY(140) + nTilt * gRespY(22)
			local m = nPhase == 1 and mBecher or mFiole
			if IsValid(m) then
				m:SetPos(vector_origin)
				m:SetAngles(Angle(0, 0, -(16 + nTilt * 52)))
				local pw = gRespX(200)
				cam.Start3D(POUR_CAM, Angle(6, 180, 0), POUR_FOV, fx - pw / 2, fy - pw / 2, pw, pw)
					render.SuppressEngineLighting(true)
					m:DrawModel()
					render.SuppressEngineLighting(false)
				cam.End3D()
			end
			if nRate > 0.004 then
				local yL = baseY - nLevel * BH
				local swx = math.sin(now * 7) * gRespX(2)
				surface.SetDrawColor(colPour.r, colPour.g, colPour.b, math.min(200, 70 + nRate * 900))
				surface.DrawRect(cx - gRespX(2) + swx, mouthY + gRespY(4), gRespX(4), yL - mouthY - gRespY(6))
			end
		end

		-- Pipette (étape 3) : le VRAI modèle au-dessus du col, gouttes en chute.
		if nPhase == 3 and not bPurging then
			if IsValid(mPipette) then
				mPipette:SetPos(vector_origin)
				mPipette:SetAngles(angle_zero)
				local pw = gRespX(150)
				cam.Start3D(PIP_CAM, Angle(0, 180, 0), PIP_FOV,
					cx - pw / 2, mouthY - gRespY(158), pw, gRespY(148))
					render.SuppressEngineLighting(true)
					mPipette:DrawModel()
					render.SuppressEngineLighting(false)
				cam.End3D()
			end
			for i = 1, #tDrops do
				local d = tDrops[i]
				if d.y then RNDX.DrawCircle(cx, d.y, gRespX(4), colDecoct) end
			end
		end

		-- Chauffe : flamme + thermomètre + jauge de stabilisation.
		if nPhase == 4 then
			local pulse = math.sin(now * 6) * gRespX(4)
			RNDX.DrawCircle(cx, baseY + gRespY(30), gRespX(20) + pulse + nTemp * gRespX(10),
				Color(255, 150, 60, 70 + nTemp * 110))
			RNDX.DrawCircle(cx, baseY + gRespY(32), gRespX(10) + pulse * 0.5, Color(255, 220, 140, 120))

			local tx = cx + W0 + gRespX(90)
			local c = 0.52 + 0.20 * math.sin(now * 0.55) + 0.07 * math.sin(now * 1.35)
			local hw = 0.09
			RNDX.Draw(gRespX(9), tx, baseY - BH, gRespX(18), BH, COL_SUB)
			surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 70)
			surface.DrawRect(tx, baseY - (c + hw) * BH, gRespX(18), hw * 2 * BH)
			surface.SetDrawColor(255, 255, 255, 235)
			surface.DrawRect(tx - gRespX(4), baseY - nTemp * BH - 1, gRespX(26), gRespY(3))
			draw.SimpleText("CHAUFFE", "Bebas Neue:22", tx + gRespX(9), baseY - BH - gRespY(22),
				COL_MUTED, TEXT_ALIGN_CENTER)

			local bw2, bh2 = gRespX(420), gRespY(18)
			local bx2, by2 = cx - bw2 / 2, h - gRespY(140)
			draw.SimpleText("STABILISATION", "Bebas Neue:22", bx2, by2 - gRespY(22), COL_MUTED)
			RNDX.Draw(bh2 / 2, bx2, by2, bw2, bh2, COL_SUB)
			local fw3 = math.floor(bw2 * math.min(1, nHeatProg / HEAT_NEED))
			if fw3 > bh2 then RNDX.Draw(bh2 / 2, bx2, by2, fw3, bh2, COL_ACCENT) end
			if nBoil > 0.15 then
				draw.SimpleText("ÉBULLITION !", "Bebas Neue:34", cx, by2 - gRespY(58),
					COL_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		if sFeedback and feedbackUntil > now then
			draw.SimpleText(sFeedback, "Bebas Neue:34", cx, baseY + gRespY(70),
				colFeedback, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	if EVO_CRAFT and EVO_CRAFT.MakeCloseCross then
		EVO_CRAFT.MakeCloseCross(ov, ov:GetWide() - gRespX(104), gRespY(44), function() finish(false) end)
	end
end

-- ── ONGLET MORTIER (construit dans le détail de l'atelier soin) ──────────────
function EVO_SCIENCE.BuildMedicMortier(pnl, padX, nXP)
	local w, h = pnl:GetWide(), pnl:GetTall()
	-- Niveau d'atelier soin (xp poussée par EVO:Craft:Open via cl_main) : gate
	-- CLIENT des étoiles, le serveur revalide de toute façon.
	local nLvlSoin = (EVO_CRAFT and EVO_CRAFT.LevelFromXP) and EVO_CRAFT.LevelFromXP(nXP or 0) or 1

	-- Miroir du refus serveur (l'atelier gate déjà la division ; SA compris).
	if not (EVO_SCIENCE.IsMedic and EVO_SCIENCE.IsMedic(LocalPlayer())) then
		local lock = vgui.Create("DLabel", pnl)
		lock:SetFont("Bebas Neue:40")
		lock:SetTextColor(COL_DIMTXT)
		lock:SetText("Réservé à la division de soin.")
		lock:SizeToContents()
		lock:SetPos(padX, gRespY(190))
		return
	end

	requestMedState()

	-- Le contenu vit dans un sous-panneau : rebuild() ne vide QUE lui, jamais le
	-- détail (qui porte le titre d'onglet posé par l'atelier).
	local box = vgui.Create("DPanel", pnl)
	box:SetPos(0, 0)
	box:SetSize(w, h)
	box:SetPaintBackground(false)

	local function rebuild()
		box:Clear()
		local c = MED.tbl

		-- Une préparation occupe la table : état + récupération.
		if c then
			local card = vgui.Create("DPanel", box)
			card:SetPos(padX, gRespY(140))
			card:SetSize(w - padX * 2, gRespY(160))
			card.Paint = function(_, cw, ch)
				RNDX.Draw(gRespY(14), 0, 0, cw, ch, COL_SUB)
				draw.SimpleText(c.bMine and "Ta préparation repose sur la table."
					or ("Préparation de " .. (c.sName or "?") .. " en cours."),
					"Avenir Next World:20", gRespX(26), gRespY(30), COL_TITLE)
				local nLeft = math.max(0, (c.readyAt or 0) - CurTime())
				draw.SimpleText(nLeft > 0 and string.format("PRÊTE DANS %d S", math.ceil(nLeft))
					or "PRÊTE À ÊTRE RÉCUPÉRÉE", "Bebas Neue:34", gRespX(26), gRespY(88),
					nLeft > 0 and COL_MUTED or COL_OK)
			end
			if c.bMine then
				EVO_CRAFT.MakeActionBtn(box, padX, gRespY(330), gRespX(300), gRespY(56),
					"RÉCUPÉRER", "Bebas Neue:30", function()
						net.Start("EVO_Science::MedCollect")
						net.SendToServer()
					end, function() return (c.readyAt or 0) - CurTime() <= 0 end)
			end
			return
		end

		local tBag = bagIngredients()
		clampMixToBag(tBag)
		local colW = gRespX(565)

		-- Section 1 : le sac (clic = déposer au mortier).
		local lblBag = vgui.Create("DLabel", box)
		lblBag:SetFont("Bebas Neue:30")
		lblBag:SetTextColor(COL_GOLD)
		lblBag:SetText("1. INGRÉDIENTS DU SAC")
		lblBag:SizeToContents()
		lblBag:SetPos(padX, gRespY(112))

		local list = vgui.Create("DScrollPanel", box)
		list:SetPos(padX, gRespY(154))
		list:SetSize(colW, gRespY(540))
		list.Paint = nil
		styleScroll(list)

		if #tBag == 0 then
			local lbl = vgui.Create("DLabel", list)
			lbl:SetFont("Avenir Next World:20")
			lbl:SetTextColor(COL_DIMTXT)
			lbl:SetWrap(true)
			lbl:SetAutoStretchVertical(true)
			lbl:SetWide(colW - gRespX(20))
			lbl:SetText("Aucun ingrédient de récolte dans ton sac. Herbes, champignons et infusions de la table se déposent ici.")
			lbl:SetPos(gRespX(4), gRespY(10))
		end

		for _, e in ipairs(tBag) do
			local sName = EVO_SCIENCE.ItemName(e.id)
			local nLeft = e.n - (MED.mix[e.id] or 0)
			local row = vgui.Create("DButton", list)
			row:Dock(TOP)
			row:DockMargin(0, 0, gRespX(12), gRespY(8))
			row:SetTall(gRespY(58))
			row:SetText("")
			row.Paint = function(s, rw, rh)
				RNDX.Draw(gRespY(10), 0, 0, rw, rh, s:IsHovered() and COL_SUB_HI or COL_SUB)
				draw.SimpleText(sName, "Avenir Next World:20", gRespX(70), rh / 2,
					nLeft > 0 and COL_TITLE or COL_DIMTXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText("×" .. nLeft, "Bebas Neue:28", rw - gRespX(16), rh / 2,
					nLeft > 0 and COL_MUTED or COL_DIMTXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			rowItemPreview(row, e.id, gRespX(10), gRespY(50))
			row.DoClick = function()
				if (e.n - (MED.mix[e.id] or 0)) <= 0 then return end
				if not MED.mix[e.id] and mixCount() >= (HUB.MedMixMaxTypes or 4) then
					surface.PlaySound(CFG.Sounds.sampleFail or "")
					return
				end
				if (MED.mix[e.id] or 0) >= (HUB.MedMixMaxPerType or 5) then
					surface.PlaySound(CFG.Sounds.sampleFail or "")
					return
				end
				MED.mix[e.id] = (MED.mix[e.id] or 0) + 1
				surface.PlaySound(CFG.Sounds.click or "")
				rebuild()
			end
		end

		-- Section 2 : le mortier (clic = retirer une dose).
		local xR = padX + colW + gRespX(80)
		local lblMix = vgui.Create("DLabel", box)
		lblMix:SetFont("Bebas Neue:30")
		lblMix:SetTextColor(COL_GOLD)
		lblMix:SetText("2. MORTIER")
		lblMix:SizeToContents()
		lblMix:SetPos(xR, gRespY(112))

		local mixPnl = vgui.Create("DPanel", box)
		mixPnl:SetPos(xR, gRespY(154))
		mixPnl:SetSize(colW, gRespY(540))
		mixPnl.Paint = function(_, mw, mh)
			RNDX.Draw(gRespY(14), 0, 0, mw, mh, COL_SUB)
			if mixCount() == 0 then
				draw.SimpleText("Clique tes ingrédients à gauche pour les déposer.",
					"Avenir Next World:20", mw / 2, mh / 2, COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		local y = gRespY(16)
		for sId, n in SortedPairs(MED.mix) do
			local sName = EVO_SCIENCE.ItemName(sId)
			local row = vgui.Create("DButton", mixPnl)
			row:SetPos(gRespX(14), y)
			row:SetSize(colW - gRespX(28), gRespY(54))
			row:SetText("")
			row.Paint = function(s, rw, rh)
				RNDX.Draw(gRespY(8), 0, 0, rw, rh, s:IsHovered() and COL_ROW or Color(16, 16, 20, 255))
				draw.SimpleText("×" .. n, "Bebas Neue:28", gRespX(62), rh / 2,
					COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(sName, "Avenir Next World:20", gRespX(106), rh / 2,
					COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText("RETIRER", "Bebas Neue:20", rw - gRespX(14), rh / 2,
					s:IsHovered() and COL_BAD or COL_DIMTXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			rowItemPreview(row, sId, gRespX(8), gRespY(46))
			row.DoClick = function()
				MED.mix[sId] = MED.mix[sId] - 1
				if MED.mix[sId] <= 0 then MED.mix[sId] = nil end
				surface.PlaySound(CFG.Sounds.click or "")
				rebuild()
			end
			y = y + gRespY(62)
		end

		-- Pied de page : règles du geste + ÉTOILES + PILER.
		local sc = HUB.MedStars and HUB.MedStars[MED.star]
		local hint = vgui.Create("DLabel", box)
		hint:SetFont("Avenir Next World:19")
		hint:SetTextColor(COL_DIMTXT)
		hint:SetWrap(true)
		hint:SetAutoStretchVertical(true)
		hint:SetWide(w - padX * 2 - gRespX(340))
		hint:SetText(string.format(
			"%d variétés maximum, %d doses par variété. Un dosage inconnu se tente : pilage raté ou dosage sans effet, les ingrédients sont perdus.%s",
			HUB.MedMixMaxTypes or 4, HUB.MedMixMaxPerType or 5,
			(sc and (sc.nCostMult or 1) > 1)
				and string.format(" En %s : chaque dose déposée consomme ×%d ingrédients. Les préparations qui se déclinent en étoiles gagnent ×%s d'effet ; les autres rendent ×%d doses.",
					string.rep("★", MED.star), sc.nCostMult, tostring(sc.nFxMult), sc.nCostMult)
				or ""))
		hint:SetPos(padX, h - gRespY(96))

		-- LOT (craft en série, user 09/15) : [−] ×N [+] [MAX] à GAUCHE des étoiles,
		-- même ligne. Ingrédients ×N au dépôt, doses ×N à la récupération, un seul
		-- pilage et un seul repos. Borné par HUB.MedMaxBatch, revalidé serveur.
		local nMaxBatch = math.min(HUB.MedMaxBatch or 10, 15) -- 4 bits sur le net
		MED.qty = math.Clamp(math.floor(tonumber(MED.qty) or 1), 1, nMaxBatch)
		local function medMaxBatch()
			local counts = {}
			for _, e in ipairs(bagIngredients()) do counts[e.id] = e.n end
			local nMult = (HUB.MedStars and HUB.MedStars[MED.star] and HUB.MedStars[MED.star].nCostMult) or 1
			local nMax = nMaxBatch
			for sId, n in pairs(MED.mix) do
				nMax = math.min(nMax, math.floor((counts[sId] or 0) / math.max(1, n * nMult)))
			end
			return math.max(1, nMax)
		end
		local qy, qh = h - gRespY(150), gRespY(48)
		local qx = w - padX - gRespX(300) - gRespX(250)
		local function qtyBtn(x, bw, sTxt, sFont, fn)
			local b = vgui.Create("DButton", box)
			b:SetText("")
			b:SetSize(bw, qh)
			b:SetPos(x, qy)
			b.Paint = function(s, bw2, bh)
				RNDX.Draw(gRespY(10), 0, 0, bw2, bh, s:IsHovered() and COL_SUB_HI or COL_SUB)
				draw.SimpleText(sTxt, sFont, bw2 / 2, bh / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				fn()
				surface.PlaySound(CFG.Sounds.click or "")
				rebuild()
			end
			return b
		end
		qtyBtn(qx, gRespX(44), "−", "Bebas Neue:30", function() MED.qty = math.max(1, MED.qty - 1) end)
		local qLbl = vgui.Create("DPanel", box)
		qLbl:SetPos(qx + gRespX(48), qy)
		qLbl:SetSize(gRespX(96), qh)
		qLbl:SetPaintBackground(false)
		qLbl.Paint = function(_, bw, bh)
			RNDX.Draw(gRespY(10), 0, 0, bw, bh, COL_SUB)
			draw.SimpleText("×" .. MED.qty, "Bebas Neue:30", bw / 2, bh / 2 - gRespY(7),
				MED.qty > 1 and COL_ACCENT or COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(MED.qty > 1 and "préparations" or "préparation", "Avenir Next World:13", bw / 2, bh - gRespY(11),
				COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		qtyBtn(qx + gRespX(148), gRespX(44), "+", "Bebas Neue:30", function() MED.qty = math.min(nMaxBatch, MED.qty + 1) end)
		qtyBtn(qx + gRespX(196), gRespX(50), "MAX", "Bebas Neue:20", function() MED.qty = medMaxBatch() end)

		-- ÉTOILES (user 08/19, miroir du labo) : le niveau d'atelier soin ouvre
		-- les préparations 2★/3★ (infusions + seringue ; le reste part en 1★).
		for i = 1, 3 do
			local cfg = HUB.MedStars and HUB.MedStars[i]
			local bOk = cfg and nLvlSoin >= (cfg.nCraftLevel or 0)
			local sb = vgui.Create("DButton", box)
			sb:SetText("")
			sb:SetSize(gRespX(92), gRespY(48))
			sb:SetPos(w - padX - gRespX(300) + (i - 1) * gRespX(104), h - gRespY(150))
			sb.Paint = function(s, bw, bh)
				local bSel = MED.star == i
				RNDX.Draw(gRespY(10), 0, 0, bw, bh, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
				if bSel then
					RNDX.DrawOutlined(gRespY(10), 0, 0, bw, bh, COL_ACCENT, gRespY(2))
				end
				draw.SimpleText(string.rep("★", i), "Bebas Neue:26", bw / 2, bOk and bh / 2 or gRespY(14),
					bSel and COL_ACCENT or (bOk and COL_TITLE or COL_DIMTXT), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				if not bOk then
					draw.SimpleText("niv " .. (cfg and cfg.nCraftLevel or "?"), "Avenir Next World:14",
						bw / 2, bh - gRespY(12), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			sb.DoClick = function()
				if not bOk then
					notification.AddLegacy(string.format("Niveau d'atelier soin %d requis pour les préparations %s.",
						cfg and cfg.nCraftLevel or 0, string.rep("★", i)), NOTIFY_ERROR, 3)
					return
				end
				MED.star = i
				surface.PlaySound(CFG.Sounds.click or "")
				rebuild()
			end
		end

		EVO_CRAFT.MakeActionBtn(box, w - padX - gRespX(300), h - gRespY(92), gRespX(300), gRespY(56),
			"PILER AU MORTIER", "Bebas Neue:30",
			function()
				net.Start("EVO_Science::MedCraft")
				net.WriteUInt(mixCount(), 4)
				for sId, n in pairs(MED.mix) do
					net.WriteString(sId)
					net.WriteUInt(n, 4)
				end
				net.WriteUInt(math.Clamp(MED.star or 1, 1, 3), 2)
				net.WriteUInt(math.Clamp(math.floor(tonumber(MED.qty) or 1), 1, math.min(HUB.MedMaxBatch or 10, 15)), 4) -- lot (craft en série), 4 bits : 15 max
				net.SendToServer()
			end,
			function() return mixCount() > 0 end)
	end

	EVO_SCIENCE._MedPanelRefresh = function()
		if IsValid(box) then rebuild() end
	end
	box.OnRemove = function()
		EVO_SCIENCE._MedPanelRefresh = nil
	end
	rebuild()
end

-- ── ONGLET CARNET : MÊME livre DHTML que les scientifiques, autre registre ───
function EVO_SCIENCE.BuildMedicCarnet(pnl, padX)
	local w, h = pnl:GetWide(), pnl:GetTall()

	if not (EVO_SCIENCE.IsMedic and EVO_SCIENCE.IsMedic(LocalPlayer())) then
		local lock = vgui.Create("DLabel", pnl)
		lock:SetFont("Bebas Neue:40")
		lock:SetTextColor(COL_DIMTXT)
		lock:SetText("Réservé à la division de soin.")
		lock:SizeToContents()
		lock:SetPos(padX, gRespY(190))
		return
	end
	if not EVO_SCIENCE.BuildRecipeBookHTML then return end

	requestMedState()
	EVO_SCIENCE.QueueRecipeIcons(HUB.MedRecipes)

	local function spec()
		return {
			tRecipes = HUB.MedRecipes,
			fDiscovered = function(sId) return MED.found[sId] == true end,
			fTocHex = function(r)
				local c = HUB.MedCategories[r.sCat]
				return (c and c.sHex) or "#8a2a31"
			end,
			fChipsHTML = function(r)
				local c = HUB.MedCategories[r.sCat]
				local hex = (c and c.sHex) or "#8a2a31"
				return string.format('<span class="chip" style="color:%s;border-color:%s">%s</span>',
					hex, hex, string.upper(c and c.sName or "?"))
			end,
			fFx = function(r) return EVO_SCIENCE.MedFxDesc(r.id) end,
			-- Recette CONSIGNÉE = bouton PRÉPARER : renvoie au mortier pré-rempli
			-- (user 08/19). stopPropagation sinon le clic tourne la page.
			fActionHTML = function(r)
				return string.format('<div class="prep" onclick="event.stopPropagation();'
					.. ' if (window.evoMed) evoMed.prepare(\'%s\');">PRÉPARER AU MORTIER</div>', r.id)
			end,
			sGuardHTML = [[<div class="center"><div class="t">CARNET MÉDICAL</div>
				<div class="s">Préparations validées par la division de soin.<br>
				À feuilleter d'une main propre.</div></div>]],
			sSommaireFmt = "Préparations validées par l'infirmerie : %d / %d.",
			sProtocoleHTML = '<div class="eyebrow">METHODE</div><h2>Protocole de la table</h2>'
				.. '<div class="step"><span class="sn">1</span><span class="tm">au geste</span><div class="nm">Mortier</div><div class="tx">Déposer les ingrédients et piler d\'un mouvement circulaire RÉGULIER. La précipitation gâche le mélange, et les ingrédients avec.</div></div>'
				.. '<div class="step"><span class="sn">2</span><span class="tm">au dosage</span><div class="nm">Verrerie</div><div class="tx">Les INJECTABLES (vaccins, seringues) passent au banc : décoction puis solvant versés à la graduation, chauffe tenue dans la bande. Un trop-plein se purge, deux fois pas plus.</div></div>'
				.. '<div class="step"><span class="sn">3</span><span class="tm">' .. (HUB.MedPrepSec or 30) .. 's</span><div class="nm">Préparation</div><div class="tx">Laisser reposer sur la table, puis récupérer. Une seule préparation à la fois par table.</div></div>'
				.. '<div class="sec">RÈGLE DE LA MAISON</div>'
				.. '<div class="desc">Rien d\'autre que la RÉCOLTE n\'entre au mortier : plantes et champignons, à gros dosages. Les grands soins réclament les cueillettes rares, et les INJECTABLES se bâtissent sur une INFUSION de la maison : brasse tes sachets avant de piquer.</div>',
			sObservationsHTML = [[<div class="eyebrow">TERRAIN</div><h2>Observations</h2>
				<div class="desc">Les herbes et champignons de la récolte servent aussi bien la médecine que la science : cueillez large, dosez juste.</div>
				<div class="desc">Un dosage inconnu se pile, repose… et s'effrite. Les ingrédients d'un essai raté ne se récupèrent jamais.</div>
				<div class="desc">Ce carnet ne livre ses dosages qu'aux infirmeries qui ont RÉUSSI la préparation : une réussite les consigne pour toute la faction.</div>]],
			sColophonHTML = [[<div class="center"><div class="t">DIVISION DE SOIN</div>
				<div class="s">Carnet tenu par l'infirmerie.<br>
				Les doses s'écrivent, les gestes s'apprennent.</div></div>]],
		}
	end

	local html = vgui.Create("DHTML", pnl)
	html:SetPos(padX, gRespY(104))
	html:SetSize(w - padX * 2, h - gRespY(134))
	html:SetAllowLua(false)
	html:SetKeyboardInputEnabled(false)
	-- PRÉPARER depuis le carnet (user 08/19) : le clic sur une recette consignée
	-- bascule sur l'onglet mortier avec le mélange PRÉ REMPLI (clampé au sac au
	-- rebuild ; le serveur revalide le stock au moment de piler).
	html:AddFunction("evoMed", "prepare", function(sId)
		local r = EVO_SCIENCE.MedRecipeById and EVO_SCIENCE.MedRecipeById(sId)
		if not r or MED.found[sId] ~= true then return end
		if MED.tbl then
			notification.AddLegacy("Une préparation occupe déjà la table.", NOTIFY_HINT, 3)
			return
		end
		MED.mix = table.Copy(r.tIngredients or {})
		-- Ce qui manque au sac est annoncé AVANT le clamp du rebuild.
		local tHave = {}
		for _, e in ipairs(bagIngredients()) do tHave[e.id] = e.n end
		local tMiss = {}
		for id, n in SortedPairs(MED.mix) do
			if (tHave[id] or 0) < n then
				tMiss[#tMiss + 1] = string.format("%d× %s", n - (tHave[id] or 0), EVO_SCIENCE.ItemName(id))
			end
		end
		if EVO_CRAFT and EVO_CRAFT.SelectRecipeById then
			EVO_CRAFT.SelectRecipeById("soin_mortier")
		end
		if #tMiss > 0 then
			notification.AddLegacy("Il manque au sac : " .. table.concat(tMiss, ", ") .. ".", NOTIFY_HINT, 5)
		else
			notification.AddLegacy("Mortier pré rempli : « " .. (r.sName or sId) .. " ».", NOTIFY_GENERIC, 3)
		end
		if NCM_UISounds and NCM_UISounds.Click then NCM_UISounds.Click() end
	end)
	html:SetHTML(EVO_SCIENCE.BuildRecipeBookHTML(spec()))
	-- Les vignettes 3D arrivent en différé (cl_science_hub rappelle ce hook) et
	-- les découvertes fraîches aussi : on re-rend le livre quand c'est prêt.
	EVO_SCIENCE._MedBookRebuild = function()
		if IsValid(html) then html:SetHTML(EVO_SCIENCE.BuildRecipeBookHTML(spec())) end
	end
	html.OnRemove = function()
		EVO_SCIENCE._MedBookRebuild = nil
	end
end

-- ── Réseau ───────────────────────────────────────────────────────────────────
net.Receive("EVO_Science::MedGame", function()
	local sToken = net.ReadString()
	local sResModel = net.ReadString() -- "" si recette inconnue/non consignée
	local nResSkin = net.ReadUInt(4)
	-- Les modèles des ingrédients déposés : MED.mix est encore intact ici.
	-- UNE copie PAR DOSE (user 08/20 « on ne voit pas tout ce qu'il y a
	-- dedans ») : tout le dépôt tourne dans le bol, plafonné pour le cadre.
	local tIng = {}
	for sId, n in SortedPairs(MED.mix) do
		local it = ITEMS and ITEMS[sId]
		if it and it.model_path then
			for _ = 1, n do
				if #tIng >= 20 then break end
				tIng[#tIng + 1] = { mdl = it.model_path, skin = it.skin or 0 }
			end
		end
	end
	MED.mix = {} -- consommés par le serveur
	openGrindGame(sToken, tIng, sResModel, nResSkin)
end)

net.Receive("EVO_Science::MedLiquid", function()
	openLiquidGame(net.ReadString(), net.ReadString())
end)

net.Receive("EVO_Science::MedSync", function()
	net.ReadBool() -- bOpen : plus de fenêtre dédiée, réponse et push font pareil
	local sDisc = net.ReadString()
	MED.found = {}
	for sId in string.gmatch(sDisc, "[^,]+") do MED.found[sId] = true end
	if net.ReadBool() then
		MED.tbl = {
			bMine = net.ReadBool(),
			stage = net.ReadString(),
			readyAt = net.ReadFloat(),
			sName = net.ReadString(),
		}
	else
		MED.tbl = nil
	end
	if EVO_SCIENCE._MedPanelRefresh then EVO_SCIENCE._MedPanelRefresh() end
	if EVO_SCIENCE._MedBookRebuild then EVO_SCIENCE._MedBookRebuild() end
end)

-- Le sac change pendant que l'onglet mortier est ouvert (dépôt consommé,
-- préparation livrée) : rebuild pour rester fidèle (recette du hub potions).
hook.Add("LZY_Inventory_Synced", "EVO_Science::MedBagRefresh", function()
	if EVO_SCIENCE._MedPanelRefresh then EVO_SCIENCE._MedPanelRefresh() end
end)

-- ── Compte à rebours AU-DESSUS de l'atelier (user 08/19) ─────────────────────
-- Chaque station de soin affiche SA préparation en cours à tout le monde :
-- nom du médecin + temps restant (vert « PRÊTE » une fois le repos fini).
surface.CreateFont("EVOMedPrep_T", { font = "Bebas Neue", size = 46, weight = 600 })
surface.CreateFont("EVOMedPrep_S", { font = "Bebas Neue", size = 30, weight = 600 })

local WPREP = {} -- [zid] = { st = {pos}, readyAt, name } (st = table stable pour le cache StationAnchor)

net.Receive("EVO_Science::MedPrepWorld", function()
	local zid = net.ReadString()
	if not net.ReadBool() then
		WPREP[zid] = nil
		return
	end
	WPREP[zid] = { st = { pos = net.ReadVector() }, readyAt = net.ReadFloat(), name = net.ReadString() }
end)

-- Plusieurs préparations PAR TABLE (une par médecin, user 08/20) : les
-- compteurs d'un même atelier s'EMPILENT verticalement. Table de comptage
-- réutilisée (zéro alloc par frame en régime établi).
local _wprepStack = {}
hook.Add("PostDrawTranslucentRenderables", "EVO_Science::MedPrepWorld", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if next(WPREP) == nil then return end
	local eye = EyePos()
	for k in pairs(_wprepStack) do _wprepStack[k] = nil end
	for _, p in SortedPairs(WPREP) do
		local vBase = (EVO_CRAFT and EVO_CRAFT.StationAnchor) and EVO_CRAFT.StationAnchor(p.st) or p.st.pos
		if eye:DistToSqr(vBase) < 1600 * 1600 then
			local sAnchor = math.Round(vBase.x) .. "|" .. math.Round(vBase.y)
			local nIdx = _wprepStack[sAnchor] or 0
			_wprepStack[sAnchor] = nIdx + 1
			local ang = (eye - vBase):Angle()
			local nLeft = math.max(0, (p.readyAt or 0) - CurTime())
			cam.Start3D2D(vBase + Vector(0, 0, 112 + nIdx * 26), Angle(0, ang.y + 90, 90), 0.18)
				draw.SimpleText("PRÉPARATION · " .. (p.name or "?"), "EVOMedPrep_S", 0, -26,
					Color(236, 236, 240, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(nLeft > 0 and string.format("%d s", math.ceil(nLeft)) or "PRÊTE",
					"EVOMedPrep_T", 0, 20,
					nLeft > 0 and Color(207, 68, 78, 235) or Color(96, 220, 130, 235),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cam.End3D2D()
		end
	end
end)


-- ── SERINGUE : choix de cible a la souris (user 08/22) ──────────────────────
-- Utiliser la seringue l'ARME ; le joueur decide ensuite : clic gauche sur soi,
-- clic droit sur la personne en face. On lit l'etat BRUT de la souris
-- (input.IsMouseDown) et pas les touches du usercmd, parce que le serveur en
-- retire justement IN_ATTACK/IN_ATTACK2 pendant la fenetre pour que le clic ne
-- parte pas en coup d'arme.
local SERIN = nil -- { untilT }
local serinL, serinR = false, false

net.Receive("EVO_Science::SeringueAim", function()
	local bOn = net.ReadBool()
	local nWin = net.ReadFloat()
	SERIN = bOn and { untilT = CurTime() + nWin } or nil
	-- On repart de l'etat courant : un bouton deja enfonce a l'armement ne doit
	-- pas compter comme un choix.
	serinL = input.IsMouseDown(MOUSE_LEFT)
	serinR = input.IsMouseDown(MOUSE_RIGHT)
end)

-- Ecriture a FRONT et one-shot, bien qu'appelee depuis un Think : la garde est
-- SERIN, consommee des la premiere ligne ci-dessous, et le Think sort
-- immediatement tant qu'elle est nil. S'y ajoute la detection de front du
-- bouton (bL and not serinL) : un bouton MAINTENU n'envoie qu'une fois.
-- Marqueur sur la DEFINITION : il couvre les deux appelants.
-- netgate: edge
local function serinSend(bSelf)
	SERIN = nil
	net.Start("EVO_Science::SeringueUse")
		net.WriteBool(bSelf)
	net.SendToServer()
end

hook.Add("Think", "EVO_Science::SeringueChoice", function()
	if not SERIN then return end
	if CurTime() > SERIN.untilT then SERIN = nil return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	local bL, bR = input.IsMouseDown(MOUSE_LEFT), input.IsMouseDown(MOUSE_RIGHT)
	if bL and not serinL then serinSend(true) return end   -- gauche = soi
	if bR and not serinR then serinSend(false) return end  -- droit  = en face
	serinL, serinR = bL, bR
end)

hook.Add("HUDPaint", "EVO_Science::SeringueHint", function()
	if not SERIN then return end
	local nLeft = SERIN.untilT - CurTime()
	if nLeft <= 0 then SERIN = nil return end
	local x, y = ScrW() * 0.5, ScrH() * 0.72
	draw.SimpleTextOutlined("SERINGUE PRÊTE", "Bebas Neue:34", x, y,
		Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 220))
	draw.SimpleTextOutlined("Clic gauche : t'injecter  ·  Clic droit : la personne en face",
		"Bebas Neue:26", x, y + 30, Color(190, 190, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
		1, Color(0, 0, 0, 220))
end)
