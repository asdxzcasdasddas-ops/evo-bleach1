-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_amputation.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO SCIENCE : AMPUTATION + PROTHÈSE, côté client. Applique les bodygroups du membre
-- coupé et de la prothèse sur le CORPS composite (part bonemergée de lzy_character) et
-- répond à la demande d'accord. Les bodygroups sont résolus par NOM : un modèle qui ne
-- les porte pas reste intact, sans erreur.
-- ============================================================================
EVO_AMPUT = EVO_AMPUT or {}
local CFG = EVO_AMPUT.CFG

local function setBodygroup(body, sName, nVal)
	local nId = body:FindBodygroupByName(sName)
	if nId and nId >= 0 then body:SetBodygroup(nId, nVal) end
end

-- Appelé par lzy_character à CHAQUE création du corps (cl_models : changement de tenue,
-- respawn, LOD, retour en PVS) et à chaque changement de l'état. `body` optionnel.
function EVO_AMPUT.ApplyBodygroups(ply, body)
	if not IsValid(ply) then return end
	body = body or (ply.PlayerModelParts and ply.PlayerModelParts.body)
	if not IsValid(body) then return end
	local tLevel = CFG.Levels[EVO_AMPUT.Level(ply)]
	local tWant = tLevel and tLevel.tBody or nil
	-- Tous les noms connus sont reposés (0 par défaut) : une restauration rend le membre,
	-- un retrait de prothèse ne touche QUE left_prosthesis.
	for _, t in ipairs(CFG.Levels) do
		for sName in pairs(t.tBody) do
			setBodygroup(body, sName, tWant and tWant[sName] or 0)
		end
	end
	setBodygroup(body, CFG.ProthBodygroup, (tLevel and EVO_AMPUT.HasProsthesis(ply)) and tLevel.nProth or 0)
end

-- L'état arrive par deux canaux : état local (soi) et apparence (soi + les autres).
hook.Add("EVO:Appearance:Changed", "EVO_Amput::Body", function(ent, sKey)
	if sKey == "EVO_Amputation" then EVO_AMPUT.ApplyBodygroups(ent) end
end)
hook.Add("LZY:PlyState:Changed", "EVO_Amput::BodyLocal", function(ply, sKey)
	if sKey == "EVO_Amputation" then EVO_AMPUT.ApplyBodygroups(ply) end
end)

-- Réponse « Oui » du patient à la popup de demande de coupe (lzy_popup).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.EVO_AmputAccept = function()
	net.Start("EVO_Amput::Accept")
	net.SendToServer()
end

-- ── COULEUR DE LA PROTHÈSE (09/28, user) ────────────────────────────────────
-- Proxy du matériau evo/characters/protheses_reikon/reikon_integre (main ET bras) :
-- $frame 0 + $color2 blanc = texture d'origine ; $frame 1 + $color2 = couleur choisie.
-- Les DEUX sont reposés à CHAQUE bind (le matériau est partagé par tous les joueurs).
-- La couleur vient du PORTEUR : le corps est parenté au joueur (lzy_character cl_models).
EVO_AMPUT.PreviewColor = EVO_AMPUT.PreviewColor or {} -- [joueur] = couleur packée (aperçu local)
local vWhite, vCol = Vector(1, 1, 1), Vector(1, 1, 1)
matproxy.Add({
	name = "EVOProsthesisColor",
	init = function() end,
	bind = function(_, mat, ent)
		local nCol = 0
		if IsValid(ent) then
			local owner = ent:IsPlayer() and ent or ent:GetParent()
			if IsValid(owner) and owner:IsPlayer() then
				nCol = EVO_AMPUT.PreviewColor[owner] or owner:GetEvoNWInt("EVO_ProsthesisColor", 0)
			end
		end
		local r, g, b = EVO_AMPUT.UnpackColor(nCol)
		if r then
			vCol.x, vCol.y, vCol.z = r / 255, g / 255, b / 255
			mat:SetInt("$frame", 1)
			mat:SetVector("$color2", vCol)
		else
			mat:SetInt("$frame", 0)
			mat:SetVector("$color2", vWhite)
		end
	end,
})

-- Aperçu relayé AU PATIENT (09/29, user) : il voit aussi la couleur changer en direct.
-- 0 = fin d'aperçu, effacée avec un léger délai le temps que la couleur appliquée arrive.
local nApercuJeton = 0
net.Receive("EVO_Amput::Preview", function()
	local n = net.ReadUInt(25)
	local lp = LocalPlayer()
	nApercuJeton = nApercuJeton + 1
	local j = nApercuJeton
	if n > 0 then EVO_AMPUT.PreviewColor[lp] = n end
	timer.Simple(n > 0 and 30 or 0.3, function() -- 30 s = filet si le scientifique disparaît
		if j == nApercuJeton then EVO_AMPUT.PreviewColor[lp] = nil end
	end)
end)

local function envoyerApercu(target, n)
	net.Start("EVO_Amput::Preview")
		net.WriteEntity(target)
		net.WriteUInt(n, 25)
	net.SendToServer()
end

-- Sélecteur (DA : plaque sombre, accent #cf444e). La couleur s'affiche EN DIRECT sur le
-- patient, chez le scientifique ET chez le patient ; rien n'est enregistré avant « APPLIQUER ».
local _pickerFrame
function EVO_AMPUT.OpenColorPicker(target)
	if not IsValid(target) then return end
	if IsValid(_pickerFrame) then _pickerFrame:Remove() end
	local ACC, BG, TXT, MUT = Color(207, 68, 78), Color(14, 14, 17, 245), Color(238, 239, 243), Color(150, 154, 162)
	local sc = math.min(ScrW() / 1920, ScrH() / 1080)
	local W, H = math.floor(420 * sc), math.floor(560 * sc)

	local f = vgui.Create("DFrame")
	_pickerFrame = f
	f:SetSize(W, H)
	f:SetPos(ScrW() - W - math.floor(60 * sc), (ScrH() - H) / 2) -- à droite : le patient reste visible
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:SetDraggable(true)
	f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		draw.RoundedBox(math.floor(10 * sc), 0, 0, w, h, BG)
		surface.SetDrawColor(ACC) surface.DrawRect(0, 0, w, math.max(2, math.floor(4 * sc)))
		draw.SimpleText("COULEUR DE LA PROTHÈSE", "Bebas Neue:28", math.floor(22 * sc), math.floor(34 * sc), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(IsValid(target) and target:Nick() or "", "Avenir Next World:15", math.floor(22 * sc), math.floor(62 * sc), MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local bApplique = false
	local nApercu, nEnvoye, nProchain = 0, 0, 0
	f.OnRemove = function()
		EVO_AMPUT.PreviewColor[target] = nil
		if not bApplique and IsValid(target) then envoyerApercu(target, 0) end
	end
	-- Le patient part / se relève / n'a plus de prothèse : on ferme.
	f.Think = function(s)
		if not IsValid(target) or not EVO_AMPUT.HasProsthesis(target) then s:Remove() return end
		-- Aperçu vers le patient : au plus 10 envois par seconde, la dernière valeur part toujours.
		if nApercu ~= nEnvoye and CurTime() >= nProchain then
			nEnvoye, nProchain = nApercu, CurTime() + 0.1
			-- netgate: stream -- aperçu en direct, seulement quand la couleur change, 10/s max
			envoyerApercu(target, nApercu)
		end
	end

	local r0, g0, b0 = EVO_AMPUT.UnpackColor(target:GetEvoNWInt("EVO_ProsthesisColor", 0))
	local mixer = vgui.Create("DColorMixer", f)
	mixer:SetPos(math.floor(22 * sc), math.floor(86 * sc))
	mixer:SetSize(W - math.floor(44 * sc), math.floor(300 * sc))
	mixer:SetPalette(true)
	mixer:SetAlphaBar(false)
	mixer:SetWangs(true)
	mixer:SetColor(r0 and Color(r0, g0, b0) or Color(207, 68, 78))
	local function apercu()
		local c = mixer:GetColor()
		nApercu = EVO_AMPUT.PackColor(c.r, c.g, c.b)
		EVO_AMPUT.PreviewColor[target] = nApercu
	end
	mixer.ValueChanged = function() apercu() end
	apercu()

	local function bouton(y, sLabel, bAccent, fn)
		local b = vgui.Create("DButton", f)
		b:SetPos(math.floor(22 * sc), y)
		b:SetSize(W - math.floor(44 * sc), math.floor(42 * sc))
		b:SetText("")
		b.Paint = function(s, w, h)
			local bH = s:IsHovered()
			local c = bAccent and (bH and Color(224, 92, 102) or ACC) or (bH and Color(38, 38, 46) or Color(24, 25, 30))
			draw.RoundedBox(math.floor(8 * sc), 0, 0, w, h, c)
			draw.SimpleText(sLabel, "Bebas Neue:22", w / 2, h / 2, TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
		return b
	end
	local function envoyer(bReset)
		bApplique = true -- le serveur met fin à l'aperçu du patient lui-même
		local c = mixer:GetColor()
		net.Start("EVO_Amput::SetColor")
			net.WriteEntity(target)
			net.WriteBool(bReset)
			net.WriteUInt(c.r, 8) net.WriteUInt(c.g, 8) net.WriteUInt(c.b, 8)
		net.SendToServer()
		f:Remove()
	end
	bouton(math.floor(400 * sc), "APPLIQUER", true, function() envoyer(false) end)
	bouton(math.floor(450 * sc), "COULEUR D'ORIGINE", false, function() envoyer(true) end)
	bouton(math.floor(500 * sc), "ANNULER", false, function() f:Remove() end)
end
