-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_hub.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE HUB (client) : onglets GESTION / DOCUMENTS / RECETTES / POTIONS
-- du laboratoire. S'enregistre dans EVO_SCIENCE.LabTabs (barre d'onglets de
-- cl_science) et recoit un ctx (helpers + couleurs DA) a la construction.
-- Aucune autorite ici : chaque action = un net, le serveur revalide tout.
-- ============================================================================

EVO_SCIENCE = EVO_SCIENCE or {}
EVO_SCIENCE.LabTabs = EVO_SCIENCE.LabTabs or {}
local CFG = EVO_SCIENCE.CFG
local HUB = CFG.Hub

local CACHE_DIR = "evo_science/cache"
file.CreateDir(CACHE_DIR)

-- ── Etat synchronise ─────────────────────────────────────────────────────────
local SYNC = { grade = 0, canAssign = false, canRename = false, grades = {}, members = {}, docs = {}, found = {} }
local POTION = { st = 0, recv = 0 } -- {st, r|exp, left, total, here, post, busy, recv}
local COMBO = {} -- melange prepare dans le synthetiseur : { { itemId=, n= } }
local COMBO_TAKEN = {} -- [bagSlot] = { itemId=, n= } unites deja prises dans CETTE pile

local function comboClear()
	COMBO = {}
	COMBO_TAKEN = {}
end
EVO_SCIENCE.PotionComboClear = comboClear

local function comboTakenOf(slot)
	local t = slot and COMBO_TAKEN[slot]
	return (t and t.n) or 0
end

local function comboTakenAdd(slot, itemId, n)
	n = math.floor(tonumber(n) or 0)
	if not slot or n < 1 or not isstring(itemId) then return end
	local t = COMBO_TAKEN[slot]
	if t and t.itemId == itemId then
		t.n = t.n + n
	else
		COMBO_TAKEN[slot] = { itemId = itemId, n = n }
	end
end

local function comboTakenFree(itemId, n)
	n = math.floor(tonumber(n) or 0)
	if n < 1 or not isstring(itemId) then return end
	for slot, t in pairs(COMBO_TAKEN) do
		if t.itemId == itemId and t.n > 0 then
			local k = math.min(t.n, n)
			t.n = t.n - k
			n = n - k
			if t.n <= 0 then COMBO_TAKEN[slot] = nil end
			if n < 1 then return end
		end
	end
end

function EVO_SCIENCE.HubReqSync()
	net.Start("EVO_Science::HubReq")
	net.SendToServer()
end

net.Receive("EVO_Science::HubSync", function()
	local len = net.ReadUInt(32)
	local data = len > 0 and net.ReadData(len) or nil
	if not data then return end
	local json = util.Decompress(data)
	if not json or json == "" then return end
	local ok, tbl = pcall(util.JSONToTable, json)
	if not ok or not istable(tbl) then return end
	SYNC = tbl
	SYNC.grades = SYNC.grades or {}
	SYNC.members = SYNC.members or {}
	SYNC.docs = SYNC.docs or {}
	SYNC.found = istable(SYNC.found) and SYNC.found or {}
	SYNC.zones = istable(SYNC.zones) and SYNC.zones or {}
	-- Rebuild SEULEMENT si le contenu a change : chaque ouverture demande un
	-- sync, et le rebuild systematique a sa reception faisait FLASHER la
	-- fenetre fraichement construite (user 08/21 « un truc bizarre avant »).
	local sSig = util.CRC(json)
	if sSig ~= EVO_SCIENCE._HubSyncSig then
		EVO_SCIENCE._HubSyncSig = sSig
		if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild() end
	end
end)

-- L'etat potion arrive aussi en POLL (2 s, onglet ouvert) : on ne rebuild l'UI
-- que si quelque chose de STRUCTUREL a change (etape, occupation, poste), sinon
-- les listes deroulantes / drags seraient fermes toutes les 2 secondes.
local _potionSig
net.Receive("EVO_Science::PotionState", function()
	local ok, tbl = pcall(util.JSONToTable, net.ReadString())
	if not ok or not istable(tbl) then return end
	POTION = tbl
	POTION.recv = CurTime()
	if (tbl.st or 0) > 0 then comboClear() end -- synthese lancee : melange consomme
	local sig = string.format("%s|%s|%s|%s|%s", tbl.st or 0, tbl.r or "", tbl.exp or 0,
		istable(tbl.busy) and ("b" .. (tbl.busy.st or 0)) or "-", tostring(tbl.here))
	if sig == _potionSig then return end
	_potionSig = sig
	if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
end)

local function potionLeft()
	if (POTION.st or 0) < 1 then return 0 end
	return math.max(0, (POTION.left or 0) - (CurTime() - (POTION.recv or 0)))
end

local function gradeName(idx)
	return SYNC.grades[idx] or HUB.GradeDefaults[idx] or ("Rang " .. idx)
end

local function myGrade()
	local lp = LocalPlayer()
	local explicit = tonumber(SYNC.grade) or 0
	if explicit > 0 then return explicit end
	-- Fallback avant le premier sync : regle implicite partagee.
	return EVO_SCIENCE.ComputeLabGrade(0, EVO_SCIENCE.IsScientist(lp), lp:GetEvoNWInt("FactionRank", 0))
end

-- Recette visible en clair ? (decouverte par la faction, ou superadmin.)
local function recipeDiscovered(sRecipeId)
	-- bAlwaysKnown (masque médical) : connue d'office — miroir du recipeFound
	-- serveur, sinon le carnet cacherait une page que le mortier accepte.
	local r = EVO_SCIENCE.PotionRecipeById and EVO_SCIENCE.PotionRecipeById(sRecipeId)
	if r and r.bAlwaysKnown then return true end
	if istable(SYNC.found) and SYNC.found[sRecipeId] then return true end
	local lp = LocalPlayer()
	return IsValid(lp) and lp:IsSuperAdmin() or false
end

-- ── Zones de documents (labels par faction, renommables + customs z1..z8) ────
local function zonesList()
	if istable(SYNC.zones) and #SYNC.zones > 0 then return SYNC.zones end
	-- Avant le premier sync : les deux zones de base.
	return { { id = "lab", name = "Laboratoire" }, { id = "secret", name = "Zone secrète" } }
end

local function zoneLabel(zid)
	for _, z in ipairs(zonesList()) do
		if z.id == zid then return z.name end
	end
	return zid == "secret" and "Zone secrète" or "Laboratoire"
end

local function isCustomZone(s) return tostring(s or ""):match("^z%d$") ~= nil end

local function canSeeSecret()
	if SYNC.canSecret then return true end
	local lp = LocalPlayer()
	return IsValid(lp) and lp:IsSuperAdmin() or false
end

-- Ai-je acces a cette zone ? (rang minimum PAR ZONE regle par les rangs 5 ;
-- la zone secrete garde son acces nominatif.)
local function zoneAccessible(z)
	if z.id == "secret" then return canSeeSecret() end
	return myGrade() >= (tonumber(z.mg) or 1)
end

-- Scope BDD -> valeur cable 4 bits (0 prive, 1 lab, 2 secret, 3.. = z1..z8).
local function scopeWire(sc)
	if sc == "lab" then return 1 end
	if sc == "secret" then return 2 end
	local n = tostring(sc or ""):match("^z(%d)$")
	return n and (2 + tonumber(n)) or 0
end

-- ── Helpers UI locaux : troncature UTF-8 + listes deroulantes DA ─────────────
-- (demande user 08/09 : plus AUCUN DComboBox/DermaMenu gris de base dans le hub,
-- noms limites a 20 caracteres, libelles longs reduits au lieu de deborder.)
local function trunc(sTxt, nMax)
	sTxt = tostring(sTxt or "")
	local n = utf8.len(sTxt)
	if not n then n = #sTxt end -- octets invalides : on retombe sur du byte-count
	if n <= nMax then return sTxt end
	local nByte = utf8.offset(sTxt, nMax + 1)
	if nByte then return string.sub(sTxt, 1, nByte - 1) .. "…" end
	return string.sub(sTxt, 1, nMax) .. "…"
end

-- Texte + police qui TIENNENT dans nMaxW px : S, sinon XS, sinon tronque.
local function fitText(sTxt, nMaxW)
	sTxt = tostring(sTxt or "")
	surface.SetFont("EVOSci_S")
	if surface.GetTextSize(sTxt) <= nMaxW then return sTxt, "EVOSci_S" end
	surface.SetFont("EVOSci_XS")
	local t = sTxt
	local n = utf8.len(sTxt) or #sTxt
	while n > 2 do
		if surface.GetTextSize(t) <= nMaxW then return t, "EVOSci_XS" end
		n = n - 1
		t = trunc(sTxt, n)
	end
	return t, "EVOSci_XS"
end

-- Liste flottante DA sous un panel ancre (au-dessus de tout : parent = backdrop).
-- items = { { label=, sub=, value=, col= } } ; fOnSelect(item) au clic.
local function openDropList(ctx, anchor, items, fOnSelect)
	local col, s = ctx.col, ctx.s
	if not (IsValid(anchor) and IsValid(ctx.back)) then return end

	-- Voile cliquable : premier clic hors de la liste = fermeture.
	local catch = vgui.Create("DButton", ctx.back)
	catch:SetText("")
	catch:SetCursor("arrow")
	catch:SetSize(ctx.back:GetWide(), ctx.back:GetTall())
	catch:SetPos(0, 0)
	catch.Paint = function() end

	local ax, ay = anchor:LocalToScreen(0, 0)
	local ox, oy = ctx.back:LocalToScreen(0, 0)
	ax, ay = ax - ox, ay - oy
	local rowH = s(34)
	local lw = math.max(anchor:GetWide(), s(240))
	local lh = math.max(rowH + s(8), math.min(s(300), #items * rowH + s(8)))

	local list = vgui.Create("DPanel", ctx.back)
	list:SetSize(lw, lh)
	local ly = ay + anchor:GetTall() + s(2)
	if ly + lh > ctx.back:GetTall() then ly = ay - lh - s(2) end -- ouvre vers le haut
	list:SetPos(math.Clamp(ax, 0, ctx.back:GetWide() - lw), math.max(0, ly))
	list.Paint = function(_, w, h)
		surface.SetDrawColor(16, 16, 20, 252) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(col.ACCENT.r, col.ACCENT.g, col.ACCENT.b, 150)
		surface.DrawOutlinedRect(0, 0, w, h)
	end

	local function closeAll()
		if IsValid(list) then list:Remove() end
		if IsValid(catch) then catch:Remove() end
	end
	catch.DoClick = closeAll
	-- L'ancre disparait (rebuild d'onglet) -> la liste orpheline se ferme seule.
	list.Think = function() if not IsValid(anchor) then closeAll() end end

	local sc = vgui.Create("DScrollPanel", list)
	sc:Dock(FILL)
	sc:DockMargin(s(4), s(4), s(4), s(4))
	ctx.styleScroll(sc)

	if #items == 0 then
		local e = sc:Add("DPanel")
		e:Dock(TOP)
		e:SetTall(rowH)
		e:SetPaintBackground(false)
		e.Paint = function(_, w, h)
			draw.SimpleText("(vide)", "EVOSci_XS", s(8), h / 2, col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	for _, it in ipairs(items) do
		local r = sc:Add("DButton")
		r:SetText("")
		r:SetCursor("hand")
		r:Dock(TOP)
		r:DockMargin(0, 0, 0, s(2))
		r:SetTall(rowH - s(2))
		r.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and col.FIELD or col.CARD2)
			surface.DrawRect(0, 0, w, h)
			local maxW = w - (it.sub and s(92) or s(16))
			if self._fitFor ~= it.label then
				self._fitFor = it.label
				self._fitTxt, self._fitFont = fitText(it.label or "?", maxW)
			end
			draw.SimpleText(self._fitTxt, self._fitFont, s(8), h / 2, it.col or col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if it.sub then
				draw.SimpleText(it.sub, "EVOSci_XS", w - s(8), h / 2, col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		r.DoClick = function()
			if ctx.snd then ctx.snd("click") end
			closeAll()
			fOnSelect(it)
		end
	end
end

-- Bouton-champ DA qui ouvre une liste deroulante. fItems() est appele A CHAQUE
-- ouverture -> contenu toujours frais (joueurs en ligne, fichiers du dossier...).
local function mkDrop(ctx, parent, sPlaceholder, fItems, fOnSelect)
	local col, s = ctx.col, ctx.s
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b._label = sPlaceholder
	b.SetLabel = function(self, txt) self._label = txt end
	b.Paint = function(self, w, h)
		surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, self:IsHovered() and 30 or 14)
		surface.DrawOutlinedRect(0, 0, w, h)
		if self._fitFor ~= self._label then
			self._fitFor = self._label
			self._fitTxt, self._fitFont = fitText(self._label or "", w - s(34))
		end
		draw.SimpleText(self._fitTxt or "", self._fitFont or "EVOSci_S", s(10), h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- petite fleche dessinee (pas de glyphe : Roboto n'a pas tous les triangles)
		local cx, cy = w - s(18), h / 2 - s(2)
		surface.SetDrawColor(self:IsHovered() and col.ACCENT or col.TXT_DIM)
		draw.NoTexture()
		surface.DrawPoly({
			{ x = cx, y = cy }, { x = cx + s(10), y = cy }, { x = cx + s(5), y = cy + s(6) },
		})
	end
	b.DoClick = function(self)
		if ctx.snd then ctx.snd("click") end
		openDropList(ctx, self, fItems() or {}, fOnSelect)
	end
	return b
end

-- Joueurs en ligne -> items de liste (noms RP tronques a 20 caracteres).
local function onlinePlayerItems(bSkipSelf)
	local out = {}
	for _, p in player.Iterator() do
		if IsValid(p) and (not bSkipSelf or p ~= LocalPlayer()) then
			local n = p:GetEvoNWString("Nickname", "")
			if n == "" then n = p:Nick() end
			out[#out + 1] = { label = trunc(n, 20), value = p:SteamID64() }
		end
	end
	table.sort(out, function(a, b) return a.label < b.label end)
	return out
end

-- ── Images de documents : upload (chunks) + cache de telechargement ──────────
local _upBusy = false
local _upDone = nil

local function uploadDocImage(sData, fDone)
	if _upBusy then fDone(false, "Envoi déjà en cours.") return end
	if not isstring(sData) or #sData < 8 or #sData > HUB.DocImgMaxSize then
		fDone(false, "Image invalide ou trop lourde (512 Ko max).")
		return
	end
	_upBusy = true
	local nChunks = math.ceil(#sData / HUB.DocImgChunk)
	net.Start("EVO_Science::DocImgUpBegin")
	net.WriteUInt(#sData, 32)
	net.WriteUInt(nChunks, 8)
	net.SendToServer()
	for i = 1, nChunks do
		timer.Simple(i * 0.1, function()
			local part = sData:sub((i - 1) * HUB.DocImgChunk + 1, i * HUB.DocImgChunk)
			net.Start("EVO_Science::DocImgUpChunk")
			net.WriteUInt(i, 8)
			net.WriteUInt(#part, 16)
			net.WriteData(part, #part)
			net.SendToServer()
		end)
	end
	timer.Simple(nChunks * 0.1 + 0.2, function()
		net.Start("EVO_Science::DocImgUpEnd")
		net.SendToServer()
	end)
	_upDone = fDone
	timer.Create("EVOSci::ImgUpTimeout", nChunks * 0.1 + 10, 1, function()
		if _upBusy then
			_upBusy = false
			if _upDone then _upDone(false, "Délai dépassé, réessaie.") _upDone = nil end
		end
	end)
end

net.Receive("EVO_Science::DocImgUpDone", function()
	local ok = net.ReadBool()
	local msg = net.ReadString()
	timer.Remove("EVOSci::ImgUpTimeout")
	_upBusy = false
	if _upDone then _upDone(ok, msg) _upDone = nil end
end)

-- Telechargement : demande par ID de document, le serveur re-resout le fichier.
local DOWNLOADS = {} -- [file] = { size, n, parts, got, cbs }

local function docImageMaterial(sFile)
	if not isstring(sFile) or sFile == "" then return nil end
	local path = CACHE_DIR .. "/" .. sFile
	if file.Exists(path, "DATA") then
		local m = Material("data/" .. path, "smooth")
		if m and not m:IsError() then return m end
	end
	return nil
end

local function requestDocImage(nDocId, sFile, fReady)
	local m = docImageMaterial(sFile)
	if m then fReady(m) return end
	local dl = DOWNLOADS[sFile]
	if dl then dl.cbs[#dl.cbs + 1] = fReady return end
	DOWNLOADS[sFile] = { parts = {}, got = 0, cbs = { fReady } }
	net.Start("EVO_Science::DocImgReq")
	net.WriteUInt(nDocId, 32)
	net.SendToServer()
	timer.Simple(15, function()
		local d = DOWNLOADS[sFile]
		if d then
			DOWNLOADS[sFile] = nil
			for _, cb in ipairs(d.cbs) do cb(nil) end
		end
	end)
end

net.Receive("EVO_Science::DocImgBegin", function()
	local sFile = net.ReadString()
	local size = net.ReadUInt(32)
	local n = net.ReadUInt(8)
	local dl = DOWNLOADS[sFile]
	if not dl then return end
	dl.size, dl.n = size, n
end)

net.Receive("EVO_Science::DocImgChunk", function()
	local sFile = net.ReadString()
	local idx = net.ReadUInt(8)
	local len = net.ReadUInt(16)
	local part = len > 0 and net.ReadData(len) or ""
	local dl = DOWNLOADS[sFile]
	if not dl or not dl.n then return end
	dl.parts[idx] = part
	dl.got = dl.got + 1
	if dl.got < dl.n then return end
	DOWNLOADS[sFile] = nil
	local sData = table.concat(dl.parts)
	if #sData ~= dl.size or not sFile:match("^img_%d+_%d+%.%a+$") then
		for _, cb in ipairs(dl.cbs) do cb(nil) end
		return
	end
	file.Write(CACHE_DIR .. "/" .. sFile, sData)
	local m = docImageMaterial(sFile)
	for _, cb in ipairs(dl.cbs) do cb(m) end
end)

-- Zoom plein ecran d'une image (copie du viewer des rapports faction).
local function openImageZoom(mat)
	if not mat then return end
	local zoom = vgui.Create("DFrame")
	zoom:SetSize(ScrW(), ScrH())
	zoom:SetTitle("")
	zoom:ShowCloseButton(false)
	zoom:SetDraggable(false)
	zoom:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(zoom) end
	zoom.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 235)
		surface.DrawRect(0, 0, w, h)
		local iw = math.floor(w * 0.9)
		local ih = math.floor(iw * 9 / 16)
		if ih > h * 0.9 then
			ih = math.floor(h * 0.9)
			iw = math.floor(ih * 16 / 9)
		end
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(mat)
		surface.DrawTexturedRect((w - iw) / 2, (h - ih) / 2, iw, ih)
	end
	zoom.OnMousePressed = function() zoom:Remove() end
end

-- ══════════════════════════════════════════════════════════════════════════
-- ONGLET GESTION (grades whitelist)
-- ══════════════════════════════════════════════════════════════════════════
local function buildGestion(content, ctx)
	local s, col, mkBtn, styleScroll = ctx.s, ctx.col, ctx.mkBtn, ctx.styleScroll
	local cw = content:GetWide()
	local colW = math.floor((cw - s(24)) / 2)

	local function mkEntry(parent, x, y, w, h, placeholder)
		local bg = vgui.Create("DPanel", parent)
		bg:SetPos(x, y)
		bg:SetSize(w, h)
		bg.Paint = function(_, bw, bh)
			surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, bw, bh)
			surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, bw, bh)
		end
		local e = vgui.Create("DTextEntry", bg)
		e:Dock(FILL)
		e:DockMargin(s(8), s(3), s(8), s(3))
		e:SetFont("EVOSci_S")
		e:SetTextColor(col.TXT)
		e:SetCursorColor(col.TXT)
		e:SetPaintBackground(false)
		e:SetDrawLanguageID(false) -- pas de badge "FR" (comme partout)
		e.Paint = function(self, bw, bh)
			self:DrawTextEntryText(col.TXT, col.ACCENT, col.TXT)
			if self:GetText() == "" and not self:HasFocus() and placeholder then
				draw.SimpleText(placeholder, "EVOSci_S", 0, bh / 2, col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		return e
	end

	-- ── Colonne gauche : les 5 grades ────────────────────────────────────────
	local left = vgui.Create("DPanel", content)
	left:SetPos(0, 0)
	left:SetSize(colW, content:GetTall())
	left.Paint = function(_, w, h) ctx.paintCutCard(w, h, Color(19, 19, 23, 250)) end

	local title1 = vgui.Create("DPanel", left)
	title1:SetPos(s(16), s(10))
	title1:SetSize(colW - s(32), s(30))
	title1:SetPaintBackground(false)
	title1.Paint = function(_, w, h)
		draw.SimpleText("RANGS DU LABORATOIRE", "EVOSci_H", 0, h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if not SYNC.canRename then
			draw.SimpleText("Renommage : Responsable de division", "EVOSci_XS", w, h / 2, col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	local y = s(50)
	for i = HUB.GradeCount, 1, -1 do
		local row = vgui.Create("DPanel", left)
		row:SetPos(s(16), y)
		row:SetSize(colW - s(32), s(46))
		row.Paint = function(_, w, h)
			surface.SetDrawColor(col.CARD2) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(col.SCI.r, col.SCI.g, col.SCI.b, 40 + i * 25)
			surface.DrawRect(0, 0, s(4), h)
			draw.SimpleText(i, "EVOSci_B", s(18), h / 2, col.SCI, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if not SYNC.canRename then
				draw.SimpleText(gradeName(i), "EVOSci_S", s(38), h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		if SYNC.canRename then
			local e = mkEntry(row, s(34), s(7), colW - s(32) - s(156), s(32))
			e:SetValue(gradeName(i))
			local b = mkBtn(row, "RENOMMER", true, function()
				local v = string.Trim(e:GetValue() or "")
				if v == "" then return end
				net.Start("EVO_Science::GradeRename")
				net.WriteUInt(i, 3)
				net.WriteString(v)
				net.SendToServer()
			end)
			b:SetPos(colW - s(32) - s(112), s(7))
			b:SetSize(s(104), s(32))
		end
		y = y + s(54)
	end

	local hint = vgui.Create("DPanel", left)
	hint:SetPos(s(16), y + s(6))
	hint:SetSize(colW - s(32), s(48))
	hint:SetPaintBackground(false)
	hint.Paint = function(_, w, h)
		draw.SimpleText("Ton rang : " .. (myGrade() > 0 and gradeName(myGrade()) or "aucun"),
			"EVOSci_S", 0, 0, col.SCI, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("La confidentialité des documents du labo se règle par rang.",
			"EVOSci_XS", 0, s(22), col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	-- ── Zones de documents (rang 5) : renommer lab/secret + customs (max 8),
	-- creation et suppression — visibles par TOUTE la faction (demande 08/09) ──
	if SYNC.canRename then
		local zy = y + s(60)
		local nCustom = 0
		for _, z in ipairs(zonesList()) do
			if isCustomZone(z.id) then nCustom = nCustom + 1 end
		end
		local ztitle = vgui.Create("DPanel", left)
		ztitle:SetPos(s(16), zy)
		ztitle:SetSize(colW - s(32), s(24))
		ztitle:SetPaintBackground(false)
		ztitle.Paint = function(_, w, h)
			draw.SimpleText("ZONES DE DOCUMENTS", "EVOSci_H", 0, h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(nCustom .. "/" .. HUB.MaxCustomZones .. " personnalisées", "EVOSci_XS",
				w, h / 2, col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		zy = zy + s(30)
		for _, z in ipairs(zonesList()) do
			local zid = z.id
			local bCustom = isCustomZone(zid)
			local row = vgui.Create("DPanel", left)
			row:SetPos(s(16), zy)
			row:SetSize(colW - s(32), s(34))
			row.Paint = function(_, w, h)
				surface.SetDrawColor(col.CARD2) surface.DrawRect(0, 0, w, h)
				local c = zid == "secret" and col.WARN or (bCustom and col.TXT_DIM or col.SCI)
				surface.SetDrawColor(c.r, c.g, c.b, 160)
				surface.DrawRect(0, 0, s(4), h)
			end
			local e = mkEntry(row, s(10), s(4),
				colW - s(32) - (bCustom and s(226) or (zid == "secret" and s(120) or s(190))), s(26))
			e:SetValue(z.name)
			-- Rang MINIMUM pour VOIR la zone (« qui a accès à quoi », demande user
			-- 08/09) — pas pour la zone secrete (acces nominatif via SECRET).
			if zid ~= "secret" then
				local mgDrop
				mgDrop = mkDrop(ctx, row, "R" .. (tonumber(z.mg) or 1) .. "+", function()
					local out = {}
					for i = 1, HUB.GradeCount do
						out[#out + 1] = { label = gradeName(i) .. " et +", sub = "rang " .. i, value = i }
					end
					return out
				end, function(it)
					net.Start("EVO_Science::ZoneMinRank")
					net.WriteString(zid)
					net.WriteUInt(it.value, 3)
					net.SendToServer()
				end)
				mgDrop:SetPos(colW - s(32) - (bCustom and s(212) or s(176)), s(4))
				mgDrop:SetSize(s(64), s(26))
			end
			local rn = mkBtn(row, "RENOMMER", true, function()
				local v = string.Trim(e:GetValue() or "")
				if v == "" then return end
				net.Start("EVO_Science::ZoneRename")
				net.WriteString(zid)
				net.WriteString(string.sub(v, 1, 40))
				net.SendToServer()
			end)
			rn:SetPos(colW - s(32) - (bCustom and s(142) or s(106)), s(4))
			rn:SetSize(s(100), s(26))
			if bCustom then
				local del = mkBtn(row, "✕", false, function()
					net.Start("EVO_Science::ZoneDel")
					net.WriteString(zid)
					net.SendToServer()
				end)
				del:SetPos(colW - s(32) - s(36), s(4))
				del:SetSize(s(28), s(26))
			end
			zy = zy + s(38)
		end
		local addRow = vgui.Create("DPanel", left)
		addRow:SetPos(s(16), zy)
		addRow:SetSize(colW - s(32), s(34))
		addRow:SetPaintBackground(false)
		local ne = mkEntry(addRow, 0, s(2), colW - s(32) - s(116), s(30), "Nom de la nouvelle zone…")
		local addZ = mkBtn(addRow, "AJOUTER", true, function()
			local v = string.Trim(ne:GetValue() or "")
			if v == "" then return end
			net.Start("EVO_Science::ZoneAdd")
			net.WriteString(string.sub(v, 1, 40))
			net.SendToServer()
		end)
		addZ:SetPos(colW - s(32) - s(108), s(2))
		addZ:SetSize(s(108), s(30))
		addZ.Think = function(self) self:SetEnabled(nCustom < HUB.MaxCustomZones) end
	end

	-- ── Colonne droite : whitelist ───────────────────────────────────────────
	local right = vgui.Create("DPanel", content)
	right:SetPos(colW + s(24), 0)
	right:SetSize(colW, content:GetTall())
	right.Paint = function(_, w, h) ctx.paintCutCard(w, h, Color(19, 19, 23, 250)) end

	local title2 = vgui.Create("DPanel", right)
	title2:SetPos(s(16), s(10))
	title2:SetSize(colW - s(32), s(30))
	title2:SetPaintBackground(false)
	title2.Paint = function(_, w, h)
		draw.SimpleText("WHITELIST (" .. #SYNC.members .. ")", "EVOSci_H", 0, h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	if not SYNC.canAssign then
		local no = vgui.Create("DPanel", right)
		no:SetPos(s(16), s(60))
		no:SetSize(colW - s(32), s(40))
		no:SetPaintBackground(false)
		no.Paint = function(_, w, h)
			draw.SimpleText("Réservé au rang « " .. gradeName(HUB.GradeCount) .. " » du laboratoire (grade 15 de la division, ou attribué).",
				"EVOSci_XS", 0, 0, col.TXT_DIM)
		end
		return
	end

	-- Items de la liste des grades (reutilises par l'ajout ET les lignes membres).
	local function gradeItems()
		local out = {}
		for i = 1, HUB.GradeCount do
			out[#out + 1] = { label = gradeName(i), sub = "rang " .. i, value = i }
		end
		return out
	end

	local function setGrade(sid, g)
		net.Start("EVO_Science::GradeSet")
		net.WriteString(sid)
		net.WriteUInt(g, 3)
		net.SendToServer()
	end

	-- Ajout d'un joueur EN LIGNE : listes DA (joueur puis grade) + AJOUTER.
	-- Deux rangees pleines largeur : plus rien ne se chevauche ni ne deborde.
	local addGrade = 1
	local selSid = nil
	local playerDrop, gradeDrop
	playerDrop = mkDrop(ctx, right, "Choisir un joueur en ligne…", function()
		return onlinePlayerItems(false)
	end, function(it)
		selSid = it.value
		playerDrop:SetLabel(it.label)
	end)
	playerDrop:SetPos(s(16), s(46))
	playerDrop:SetSize(colW - s(32), s(32))

	gradeDrop = mkDrop(ctx, right, gradeName(1), gradeItems, function(it)
		addGrade = it.value
		gradeDrop:SetLabel(it.label)
	end)
	gradeDrop:SetPos(s(16), s(84))
	gradeDrop:SetSize(colW - s(32) - s(130), s(32))

	local add = ctx.mkBtn(right, "AJOUTER", true, function()
		if not isstring(selSid) then return end
		setGrade(selSid, addGrade)
	end)
	add:SetPos(colW - s(16) - s(122), s(84))
	add:SetSize(s(122), s(32))
	add.Think = function(self) self:SetEnabled(isstring(selSid)) end

	local list = vgui.Create("DScrollPanel", right)
	list:SetPos(s(16), s(126))
	list:SetSize(colW - s(32), right:GetTall() - s(142))
	list.Paint = function() end
	styleScroll(list)

	for _, m in ipairs(SYNC.members) do
		local row = list:Add("DPanel")
		row:Dock(TOP)
		row:DockMargin(0, 0, s(6), s(6))
		row:SetTall(s(46))
		row.Paint = function(_, w, h)
			surface.SetDrawColor(col.CARD2) surface.DrawRect(0, 0, w, h)
			-- Nom limite a 20 caracteres (demande user 08/09).
			draw.SimpleText(trunc(m.name or "?", 20), "EVOSci_S", s(10), h * 0.32, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(trunc(gradeName(m.grade or 1), 26) .. (m.secret and "  ·  accès secret" or ""),
				"EVOSci_XS", s(10), h * 0.72, m.secret and col.WARN or col.SCI, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		-- Rang en LISTE deroulante (fini les boutons +/-), libelle auto-reduit.
		local gd = mkDrop(ctx, row, gradeName(m.grade or 1), gradeItems, function(it)
			setGrade(m.sid, it.value)
		end)
		-- Acces zone secrete : toggle (accent = accorde), demande user 08/09.
		local sec = ctx.mkBtn(row, "SECRET", m.secret == true, function()
			net.Start("EVO_Science::GradeSecret")
			net.WriteString(m.sid)
			net.WriteBool(not m.secret)
			net.SendToServer()
		end)
		local rem = ctx.mkBtn(row, "RETIRER", true, function()
			setGrade(m.sid, 0)
		end)
		row.PerformLayout = function(_, w, h)
			gd:SetPos(w - s(352), s(8)) gd:SetSize(s(178), s(30))
			sec:SetPos(w - s(166), s(8)) sec:SetSize(s(70), s(30))
			rem:SetPos(w - s(88), s(8)) rem:SetSize(s(82), s(30))
		end
	end
end

-- ══════════════════════════════════════════════════════════════════════════
-- ONGLET DOCUMENTS
-- ══════════════════════════════════════════════════════════════════════════
-- Selection persistante ENTRE les rebuilds (les syncs reconstruisent l'onglet) :
-- avant, creer un document revenait a l'ecran "Selectionne un document" et le
-- joueur ne voyait jamais son document enregistre (bug user 08/09).
local DOC_SEL = nil
local DOC_PICK_NEWEST = false -- apres ENREGISTRER : sauter sur mon doc le plus recent
local DOC_SEARCH = ""         -- recherche (titre/auteur/contenu/classeur), persiste
local DOC_SORT = "recent"     -- recent | old | title | author
local DOC_FOLDED = {}         -- classeurs replies : ["zone/classeur"] = true (persiste)

local function buildDocuments(content, ctx)
	local s, col, mkBtn, styleScroll = ctx.s, ctx.col, ctx.mkBtn, ctx.styleScroll
	local cw, chh = content:GetSize()
	local listW = s(400)

	local right = vgui.Create("DPanel", content)
	right:SetPos(listW + s(16), 0)
	right:SetSize(cw - listW - s(16), chh)
	right.Paint = function(_, w, h) ctx.paintCutCard(w, h, Color(19, 19, 23, 250)) end

	local showViewer, showEditor -- forward

	-- ── Liste (gauche) ───────────────────────────────────────────────────────
	local left = vgui.Create("DPanel", content)
	left:SetPos(0, 0)
	left:SetSize(listW, chh)
	left:SetPaintBackground(false)

	local newBtn = mkBtn(left, "+  NOUVEAU DOCUMENT", true, function() showEditor() end)
	newBtn:SetPos(0, 0)
	newBtn:SetSize(listW, s(38))

	-- ── Recherche + tri (pattern gestionnaires de fichiers, demande user 08/09) ─
	local refreshList -- fwd
	local searchBg = vgui.Create("DPanel", left)
	searchBg:SetPos(0, s(46))
	searchBg:SetSize(listW - s(122), s(30))
	searchBg.Paint = function(_, w, h)
		surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
	end
	local searchE = vgui.Create("DTextEntry", searchBg)
	searchE:Dock(FILL)
	searchE:DockMargin(s(8), s(3), s(8), s(3))
	searchE:SetFont("EVOSci_XS")
	searchE:SetTextColor(col.TXT)
	searchE:SetCursorColor(col.TXT)
	searchE:SetPaintBackground(false)
	searchE:SetDrawLanguageID(false)
	searchE:SetPlaceholderText("Rechercher (titre, auteur, contenu…)")
	searchE:SetValue(DOC_SEARCH)
	searchE:SetUpdateOnType(true)
	searchE.OnValueChange = function(_, v)
		DOC_SEARCH = tostring(v or "")
		if refreshList then refreshList() end
	end

	local SORT_LABELS = { recent = "Récents", old = "Anciens", title = "Titre A-Z", author = "Auteur A-Z" }
	local sortDrop
	sortDrop = mkDrop(ctx, left, "Tri : " .. (SORT_LABELS[DOC_SORT] or "Récents"), function()
		return {
			{ label = "Plus récents d'abord", sub = "date", value = "recent" },
			{ label = "Plus anciens d'abord", sub = "date", value = "old" },
			{ label = "Titre A-Z", sub = "titre", value = "title" },
			{ label = "Auteur A-Z", sub = "auteur", value = "author" },
		}
	end, function(it)
		DOC_SORT = it.value
		sortDrop:SetLabel("Tri : " .. (SORT_LABELS[it.value] or "?"))
		if refreshList then refreshList() end
	end)
	sortDrop:SetPos(listW - s(114), s(46))
	sortDrop:SetSize(s(114), s(30))

	local list = vgui.Create("DScrollPanel", left)
	list:SetPos(0, s(84))
	list:SetSize(listW, chh - s(84))
	list.Paint = function() end
	styleScroll(list)

	local function section(label)
		local p = list:Add("DPanel")
		p:Dock(TOP)
		p:DockMargin(0, s(8), s(6), s(4))
		p:SetTall(s(22))
		p:SetPaintBackground(false)
		p.Paint = function(_, w, h)
			draw.SimpleText(label, "EVOSci_XS", 0, h / 2, col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(255, 255, 255, 16)
			surface.DrawRect(0, h - 1, w, 1)
		end
	end

	-- Sous-en-tete de CLASSEUR dans une zone : CLIQUABLE pour plier / deplier
	-- (demande user 08/09), etat garde dans DOC_FOLDED entre les rebuilds.
	local function folderHeader(sName, n, sKey)
		local p = list:Add("DButton")
		p:SetText("")
		p:SetCursor("hand")
		p:Dock(TOP)
		p:DockMargin(0, s(2), s(6), s(2))
		p:SetTall(s(20))
		p.Paint = function(self, w, h)
			local bFolded = DOC_FOLDED[sKey]
			local c = self:IsHovered() and col.TXT or col.SCI
			surface.SetDrawColor(0, 0, 0, 0)
			-- petite fleche : vers la droite = plie, vers le bas = deplie
			surface.SetDrawColor(c)
			draw.NoTexture()
			local cx, cy = s(11), h / 2
			if bFolded then
				surface.DrawPoly({
					{ x = cx - s(2), y = cy - s(4) }, { x = cx + s(3), y = cy }, { x = cx - s(2), y = cy + s(4) },
				})
			else
				surface.DrawPoly({
					{ x = cx - s(4), y = cy - s(2) }, { x = cx + s(4), y = cy - s(2) }, { x = cx, y = cy + s(3) },
				})
			end
			draw.SimpleText(trunc(sName, 24) .. "  (" .. n .. ")", "EVOSci_XS", s(20), h / 2,
				c, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		p.DoClick = function()
			DOC_FOLDED[sKey] = (not DOC_FOLDED[sKey]) or nil
			if ctx.snd then ctx.snd("click") end
			if refreshList then refreshList() end
		end
	end

	local function emptyRow(sTxt)
		local p = list:Add("DPanel")
		p:Dock(TOP)
		p:DockMargin(0, 0, s(6), s(4))
		p:SetTall(s(28))
		p:SetPaintBackground(false)
		p.Paint = function(_, w, h)
			draw.SimpleText(sTxt, "EVOSci_XS", s(10), h / 2, col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local function docRow(doc)
		local row = list:Add("DButton")
		row:SetText("")
		row:SetCursor("hand")
		row:Dock(TOP)
		row:DockMargin(0, 0, s(6), s(4))
		row:SetTall(s(46))
		row.Paint = function(self, w, h)
			local active = DOC_SEL == doc.id
			surface.SetDrawColor(active and col.FIELD or col.CARD2)
			surface.DrawRect(0, 0, w, h)
			if active then
				surface.SetDrawColor(col.ACCENT)
				surface.DrawRect(0, 0, s(3), h)
			end
			draw.SimpleText(doc.t or "?", "EVOSci_S", s(10), h * 0.32, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local sub = (doc.o or "?") .. "  ·  " .. (doc.d or "")
			local cSub = col.TXT_DIM
			if doc.sc == "lab" then
				sub = sub .. "  ·  " .. gradeName(doc.mg or 1) .. "+"
				cSub = col.SCI
			elseif doc.sc == "secret" then
				sub = sub .. "  ·  " .. trunc(zoneLabel("secret"), 18)
				cSub = col.WARN
			elseif isCustomZone(doc.sc) then
				sub = sub .. "  ·  " .. trunc(zoneLabel(doc.sc), 18)
				cSub = col.SCI
			end
			draw.SimpleText(sub, "EVOSci_XS", s(10), h * 0.72, cSub, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if (doc.img or "") ~= "" then
				draw.SimpleText("IMG", "EVOSci_XS", w - s(8), h / 2, col.WARN, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		row.DoClick = function()
			DOC_SEL = doc.id
			showViewer(doc)
		end
	end

	local function matchSearch(d)
		if DOC_SEARCH == "" then return true end
		local hay = string.lower((d.t or "") .. " " .. (d.o or "") .. " " .. (d.f or "") .. " " .. (d.b or ""))
		return string.find(hay, string.lower(DOC_SEARCH), 1, true) ~= nil
	end

	local function sortDocs(t)
		local out = {}
		for i, d in ipairs(t) do out[i] = d end
		if DOC_SORT == "old" then
			table.sort(out, function(a, b) return (a.id or 0) < (b.id or 0) end)
		elseif DOC_SORT == "title" then
			table.sort(out, function(a, b) return string.lower(a.t or "") < string.lower(b.t or "") end)
		elseif DOC_SORT == "author" then
			table.sort(out, function(a, b) return string.lower(a.o or "") < string.lower(b.o or "") end)
		end -- "recent" = ordre serveur (plus recents d'abord)
		return out
	end

	-- Rangee par classeurs : docs sans classeur d'abord, puis chaque classeur
	-- (A-Z) avec son sous-en-tete PLIABLE (sZone prefixe la cle de pliage).
	local function addGroup(docs, sZone)
		local loose, folders, names = {}, {}, {}
		for _, d in ipairs(docs) do
			local f = d.f or ""
			if f == "" then
				loose[#loose + 1] = d
			else
				if not folders[f] then
					folders[f] = {}
					names[#names + 1] = f
				end
				folders[f][#folders[f] + 1] = d
			end
		end
		for _, d in ipairs(loose) do docRow(d) end
		table.sort(names, function(a, b) return string.lower(a) < string.lower(b) end)
		for _, f in ipairs(names) do
			local sKey = sZone .. "/" .. f
			folderHeader(f, #folders[f], sKey)
			if not DOC_FOLDED[sKey] then
				for _, d in ipairs(folders[f]) do docRow(d) end
			end
		end
	end

	-- ZONES DYNAMIQUES (renommables + customs, ordre serveur : laboratoire,
	-- customs z1..z8, zone secrete en dernier). Le "partage" deplace le document
	-- ENTRE CES ZONES. La zone secrete n'apparait que si on y a acces.
	refreshList = function()
		list:GetCanvas():Clear()
		local mine, secret, byZone = {}, {}, {}
		for _, doc in ipairs(SYNC.docs) do
			if matchSearch(doc) then
				if doc.mine then
					mine[#mine + 1] = doc
				elseif doc.sc == "secret" then
					secret[#secret + 1] = doc
				else
					local zid = isCustomZone(doc.sc) and doc.sc or "lab"
					byZone[zid] = byZone[zid] or {}
					byZone[zid][#byZone[zid] + 1] = doc
				end
			end
		end
		-- Zone custom disparue cote serveur (edge de sync) : repli laboratoire.
		local known = {}
		for _, z in ipairs(zonesList()) do known[z.id] = true end
		for zid, t in pairs(byZone) do
			if zid ~= "lab" and not known[zid] then
				byZone.lab = byZone.lab or {}
				for _, d in ipairs(t) do byZone.lab[#byZone.lab + 1] = d end
				byZone[zid] = nil
			end
		end
		local sNoRes = "Aucun résultat pour cette recherche."
		section("MES DOCUMENTS (" .. #mine .. ")")
		if #mine == 0 then emptyRow(DOC_SEARCH ~= "" and sNoRes or "Aucun document : « + Nouveau document » ci-dessus.") end
		addGroup(sortDocs(mine), "mine")
		for _, z in ipairs(zonesList()) do
			if z.id == "secret" then
				if canSeeSecret() or #secret > 0 then
					section(string.upper(z.name) .. " (" .. #secret .. ")")
					if #secret == 0 then emptyRow(DOC_SEARCH ~= "" and sNoRes or "Aucun document secret déposé.") end
					addGroup(sortDocs(secret), "secret")
				end
			else
				local t = byZone[z.id] or {}
				local nMin = tonumber(z.mg) or 1
				-- Zone reservee a un rang superieur : section CACHEE en dessous
				-- (les gestionnaires rang 5 voient tout).
				if zoneAccessible(z) or SYNC.canRename or #t > 0 then
					local sSuffix = nMin > 1 and ("  ·  rang " .. nMin .. "+") or ""
					section(string.upper(z.name) .. " (" .. #t .. ")" .. sSuffix)
					if #t == 0 then emptyRow(DOC_SEARCH ~= "" and sNoRes or "Rien dans cette zone pour l'instant.") end
					addGroup(sortDocs(t), z.id)
				end
			end
		end
	end
	refreshList()

	-- ── Viewer (droite) ──────────────────────────────────────────────────────
	showViewer = function(doc)
		right:Clear()
		if not doc then
			right.PaintOver = function(_, w, h)
				draw.SimpleText("Sélectionne un document", "EVOSci_S", w / 2, h / 2, col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			return
		end
		right.PaintOver = nil
		local rw = right:GetWide()

		local head = vgui.Create("DPanel", right)
		head:SetPos(s(20), s(14))
		head:SetSize(rw - s(40), s(58))
		head:SetPaintBackground(false)
		head.Paint = function(_, w, h)
			draw.SimpleText(doc.t or "?", "EVOSci_Title", 0, 0, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local meta = "Par " .. (doc.o or "?") .. "  ·  " .. (doc.d or "")
			local cMeta = col.TXT_DIM
			if doc.sc == "lab" then
				meta = meta .. "  ·  " .. zoneLabel("lab") .. ", confidentialité : " .. gradeName(doc.mg or 1) .. " et +"
				cMeta = col.SCI
			elseif doc.sc == "secret" then
				meta = meta .. "  ·  " .. zoneLabel("secret") .. " — accès restreint"
				cMeta = col.WARN
			elseif isCustomZone(doc.sc) then
				meta = meta .. "  ·  Zone : " .. zoneLabel(doc.sc)
				cMeta = col.SCI
			else
				meta = meta .. "  ·  Document privé"
			end
			if (doc.f or "") ~= "" then
				meta = meta .. "  ·  Classeur : " .. doc.f
			end
			draw.SimpleText(meta, "EVOSci_XS", 0, s(40), cMeta, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end

		-- Actions (droite -> gauche) : SUPPRIMER / PARTAGER (= deplacer de ZONE :
		-- prive / laboratoire / zone secrete — demande user 08/09) / MODIFIER
		-- (proprietaire), RANGER (proprietaire ou Responsable sur labo/secret),
		-- IMPRIMER (tout lecteur : note evo_note dans le sac).
		local bx = rw - s(20)
		local function actionBtn(sLabel, bFill, fn, nW)
			local b = mkBtn(right, sLabel, bFill, fn)
			nW = nW or s(100)
			b:SetSize(nW, s(30))
			bx = bx - nW
			b:SetPos(bx, s(16))
			bx = bx - s(8)
			return b
		end
		if doc.mine then
			actionBtn("SUPPRIMER", false, function()
				net.Start("EVO_Science::DocDelete")
				net.WriteUInt(doc.id, 32)
				net.SendToServer()
				DOC_SEL = nil
			end)
			local shBtn
			shBtn = actionBtn("PARTAGER", true, function()
				local cur = doc.sc or "private"
				local items = { { label = "Privé (toi seul)", value = 0, sub = cur == "private" and "actuel" or nil } }
				for _, z in ipairs(zonesList()) do
					-- Zones d'un rang superieur : pas proposees (le depot en zone
					-- secrete reste libre — rapport confidentiel qui remonte).
					if z.id == "secret" or zoneAccessible(z) then
						items[#items + 1] = {
							label = z.name, value = scopeWire(z.id),
							col = z.id == "secret" and col.WARN or col.SCI,
							sub = cur == z.id and "actuel" or nil,
						}
					end
				end
				openDropList(ctx, shBtn, items, function(it)
					net.Start("EVO_Science::DocScope")
					net.WriteUInt(doc.id, 32)
					net.WriteUInt(it.value, 4)
					net.SendToServer()
				end)
			end)
			actionBtn("MODIFIER", false, function() showEditor(doc) end)
		end
		if doc.mine or (SYNC.canRename and (doc.sc == "lab" or doc.sc == "secret")) then
			local rgBtn
			rgBtn = actionBtn("RANGER", false, function()
				-- Classeurs existants (tous documents visibles) + retrait. Un
				-- NOUVEAU nom de classeur se tape dans MODIFIER (champ Classeur).
				local names, seen = {}, {}
				for _, d2 in ipairs(SYNC.docs) do
					local f = d2.f or ""
					if f ~= "" and not seen[f] then
						seen[f] = true
						names[#names + 1] = f
					end
				end
				table.sort(names, function(a, b) return string.lower(a) < string.lower(b) end)
				local items = { { label = "(Aucun classeur)", value = "" } }
				for _, f in ipairs(names) do
					items[#items + 1] = { label = f, value = f }
				end
				items[#items + 1] = { label = "Nouveau classeur : tape son nom via MODIFIER", value = nil, col = col.TXT_DIM }
				openDropList(ctx, rgBtn, items, function(it)
					if it.value == nil then return end
					net.Start("EVO_Science::DocFolder")
					net.WriteUInt(doc.id, 32)
					net.WriteString(it.value)
					net.SendToServer()
				end)
			end, s(88))
		end
		actionBtn("IMPRIMER", not doc.mine, function()
			net.Start("EVO_Science::DocPrint")
			net.WriteUInt(doc.id, 32)
			net.SendToServer()
		end)

		local bodyTop = s(84)
		local imgH = 0
		if (doc.img or "") ~= "" then
			imgH = s(210)
			local imgPnl = vgui.Create("DButton", right)
			imgPnl:SetText("")
			imgPnl:SetCursor("hand")
			imgPnl:SetPos(s(20), bodyTop)
			imgPnl:SetSize(rw - s(40), imgH - s(10))
			imgPnl._mat = nil
			imgPnl.Paint = function(self, w, h)
				surface.SetDrawColor(10, 10, 13, 255)
				surface.DrawRect(0, 0, w, h)
				if self._mat then
					local iw = h * 16 / 9
					if iw > w then iw = w end
					surface.SetDrawColor(255, 255, 255, 255)
					surface.SetMaterial(self._mat)
					surface.DrawTexturedRect((w - iw) / 2, 0, iw, h)
				else
					draw.SimpleText("Chargement de l'image...", "EVOSci_XS", w / 2, h / 2, col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			imgPnl.DoClick = function(self) openImageZoom(self._mat) end
			requestDocImage(doc.id, doc.img, function(m)
				if IsValid(imgPnl) then imgPnl._mat = m end
			end)
		end

		local scroll = vgui.Create("DScrollPanel", right)
		scroll:SetPos(s(20), bodyTop + imgH)
		scroll:SetSize(rw - s(40), right:GetTall() - bodyTop - imgH - s(16))
		scroll.Paint = function() end
		styleScroll(scroll)
		local lbl = scroll:Add("DLabel")
		lbl:SetFont("EVOSci_S")
		lbl:SetTextColor(col.TXT)
		lbl:SetWrap(true)
		lbl:SetAutoStretchVertical(true)
		lbl:Dock(TOP)
		lbl:DockMargin(0, 0, s(10), 0)
		lbl:SetText(doc.b or "")
	end

	-- ── Editeur (droite) ─────────────────────────────────────────────────────
	-- docEdit (optionnel) = MODE EDITION : champs pre-remplis, ENREGISTRER envoie
	-- DocEdit (l'image existante est conservee) au lieu de DocCreate.
	showEditor = function(docEdit)
		right:Clear()
		right.PaintOver = nil
		DOC_SEL = nil
		local rw = right:GetWide()
		local bEdit = istable(docEdit)
		local sFolderDir = (LZYF_ReportImage and LZYF_ReportImage.FolderDir and LZYF_ReportImage.FolderDir()) or "evo_preuves"
		local st = {
			img = nil, imgMat = nil,
			scope = bEdit and scopeWire(docEdit.sc) or 0,
			minGrade = bEdit and (docEdit.mg or 1) or 1,
			status = bEdit and "Modification du document — l'image existante est conservée telle quelle."
				or ("Astuce : glisse tes images (jpg/png) dans garrysmod/data/" .. sFolderDir
					.. "/ puis « Image du dossier » — la liste se relit à chaque ouverture."),
		}

		local head = vgui.Create("DPanel", right)
		head:SetPos(s(20), s(14))
		head:SetSize(rw - s(40), s(30))
		head:SetPaintBackground(false)
		head.Paint = function(_, w, h)
			draw.SimpleText(bEdit and "MODIFIER LE DOCUMENT" or "NOUVEAU DOCUMENT DE RECHERCHE",
				"EVOSci_H", 0, h / 2, col.TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local titleBg = vgui.Create("DPanel", right)
		titleBg:SetPos(s(20), s(52))
		titleBg:SetSize(rw - s(40), s(34))
		titleBg.Paint = function(_, w, h)
			surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
		end
		local titleE = vgui.Create("DTextEntry", titleBg)
		titleE:Dock(FILL)
		titleE:DockMargin(s(8), s(4), s(8), s(4))
		titleE:SetFont("EVOSci_S")
		titleE:SetTextColor(col.TXT)
		titleE:SetCursorColor(col.TXT)
		titleE:SetPaintBackground(false)
		titleE:SetDrawLanguageID(false)
		titleE:SetPlaceholderText("Titre du document")
		if bEdit then titleE:SetValue(docEdit.t or "") end

		local bodyBg = vgui.Create("DPanel", right)
		bodyBg:SetPos(s(20), s(94))
		bodyBg:SetSize(rw - s(40), right:GetTall() - s(94) - s(166))
		bodyBg.Paint = function(_, w, h)
			surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
		end
		local bodyE = vgui.Create("DTextEntry", bodyBg)
		bodyE:Dock(FILL)
		bodyE:DockMargin(s(8), s(6), s(8), s(6))
		bodyE:SetFont("EVOSci_S")
		bodyE:SetTextColor(col.TXT)
		bodyE:SetCursorColor(col.TXT)
		bodyE:SetPaintBackground(false)
		bodyE:SetDrawLanguageID(false)
		bodyE:SetMultiline(true)
		if bEdit then bodyE:SetValue(docEdit.b or "") end

		-- ── Image : capture d'ecran OU image du dossier data/ (LISTE DA relue a
		-- chaque ouverture : on peut y glisser un fichier Windows puis rouvrir la
		-- liste sans fermer le jeu). GMod n'accepte PAS le drag & drop de fichiers
		-- de l'OS dans la fenetre : le dossier data/ est la porte d'entree.
		-- (Import par URL RETIRE — demande user 08/09. En MODE EDITION : pas de
		-- rangee image, l'image existante du document est conservee.)
		local imgY = right:GetTall() - s(148)
		if not bEdit then
			local cap = mkBtn(right, "[+] CAPTURE D'ÉCRAN", false, function()
				if not (LZYF_ReportImage and LZYF_ReportImage.Capture) then
					st.status = "Module image indisponible."
					return
				end
				local root = ctx.back
				LZYF_ReportImage.Capture({ root }, function(sData, sErr, mat)
					if not sData then st.status = sErr or "Capture impossible." return end
					st.img, st.imgMat = sData, mat
					st.status = "Capture prête (" .. math.ceil(#sData / 1024) .. " Ko)."
				end)
			end)
			cap:SetPos(s(20), imgY)
			cap:SetSize(s(180), s(30))

			local folder = mkDrop(ctx, right, "[+] IMAGE DU DOSSIER", function()
				if not (LZYF_ReportImage and LZYF_ReportImage.ListFolder) then return {} end
				local out = {}
				for _, f in ipairs(LZYF_ReportImage.ListFolder()) do
					out[#out + 1] = {
						label = f.name,
						sub = math.ceil((f.size or 0) / 1024) .. " Ko",
						value = f.name,
					}
				end
				return out
			end, function(it)
				if not it.value then return end
				LZYF_ReportImage.ReadFolderImage(it.value, function(sData, sErr, mat)
					if not sData then st.status = sErr or "Lecture impossible." return end
					st.img, st.imgMat = sData, mat
					st.status = "Image prête (" .. math.ceil(#sData / 1024) .. " Ko)."
				end)
			end)
			folder:SetPos(s(208), imgY)
			folder:SetSize(s(200), s(30))

			local thumb = vgui.Create("DButton", right)
			thumb:SetText("")
			thumb:SetPos(s(420), imgY - s(14))
			thumb:SetSize(s(88), s(50))
			thumb.Paint = function(_, w, h)
				if st.imgMat then
					surface.SetDrawColor(255, 255, 255, 255)
					surface.SetMaterial(st.imgMat)
					surface.DrawTexturedRect(0, 0, w, h)
				end
			end
			thumb.DoClick = function()
				st.img, st.imgMat = nil, nil
				st.status = "Image retirée."
			end
		end

		local status = vgui.Create("DPanel", right)
		status:SetPos(s(20), imgY + s(36))
		status:SetSize(rw - s(40), s(18))
		status:SetPaintBackground(false)
		status.Paint = function(_, w, h)
			draw.SimpleText(st.status, "EVOSci_XS", 0, h / 2, col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		-- Visibilite (prive / labo / ZONE SECRETE) + confidentialite + CLASSEUR.
		local optY = right:GetTall() - s(86)
		local function pubLabel()
			if st.scope == 0 then return "Visibilité : Privé" end
			if st.scope == 1 then return "Visibilité : " .. zoneLabel("lab") end
			if st.scope == 2 then return "Visibilité : " .. zoneLabel("secret") end
			return "Visibilité : " .. zoneLabel("z" .. (st.scope - 2))
		end
		local pubDrop, confDrop
		pubDrop = mkDrop(ctx, right, pubLabel(), function()
			local items = { { label = "Privé (toi seul)", value = 0 } }
			for _, z in ipairs(zonesList()) do
				if z.id == "secret" or zoneAccessible(z) then
					items[#items + 1] = {
						label = z.name, value = scopeWire(z.id),
						col = z.id == "secret" and col.WARN or col.SCI,
					}
				end
			end
			return items
		end, function(it)
			st.scope = it.value
			pubDrop:SetLabel(pubLabel())
		end)
		pubDrop:SetPos(s(20), optY)
		pubDrop:SetSize(s(230), s(30))

		confDrop = mkDrop(ctx, right, "Visible : " .. gradeName(st.minGrade) .. " et +", function()
			local out = {}
			for i = 1, HUB.GradeCount do
				out[#out + 1] = { label = gradeName(i) .. " et +", sub = "rang " .. i, value = i }
			end
			return out
		end, function(it)
			st.minGrade = it.value
			confDrop:SetLabel("Visible : " .. gradeName(it.value) .. " et +")
		end)
		confDrop:SetPos(s(258), optY)
		confDrop:SetSize(s(250), s(30))

		-- Classeur (libre) : tape un nom pour creer/reutiliser un classeur.
		local folderBg = vgui.Create("DPanel", right)
		folderBg:SetPos(s(516), optY)
		folderBg:SetSize(s(220), s(30))
		folderBg.Paint = function(_, w, h)
			surface.SetDrawColor(col.FIELD) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
		end
		local folderE = vgui.Create("DTextEntry", folderBg)
		folderE:Dock(FILL)
		folderE:DockMargin(s(8), s(3), s(8), s(3))
		folderE:SetFont("EVOSci_XS")
		folderE:SetTextColor(col.TXT)
		folderE:SetCursorColor(col.TXT)
		folderE:SetPaintBackground(false)
		folderE:SetDrawLanguageID(false)
		folderE:SetPlaceholderText("Classeur (optionnel)")
		if bEdit then folderE:SetValue(docEdit.f or "") end

		local save = mkBtn(right, "ENREGISTRER", true, function()
			local t = string.Trim(titleE:GetValue() or "")
			local b = string.Trim(bodyE:GetValue() or "")
			local f = string.sub(string.Trim(folderE:GetValue() or ""), 1, HUB.DocFolderMax)
			if t == "" or (b == "" and not st.img and not bEdit) then
				st.status = "Titre et contenu requis."
				return
			end
			if bEdit then
				net.Start("EVO_Science::DocEdit")
				net.WriteUInt(docEdit.id, 32)
				net.WriteString(string.sub(t, 1, HUB.DocMaxTitle))
				net.WriteString(string.sub(b, 1, HUB.DocMaxBody))
				net.WriteUInt(st.scope, 4)
				net.WriteUInt(st.minGrade, 3)
				net.WriteString(f)
				net.SendToServer()
				DOC_SEL = docEdit.id -- le sync qui suit reaffiche CE document
				return
			end
			local function sendDoc(bImage)
				net.Start("EVO_Science::DocCreate")
				net.WriteString(string.sub(t, 1, HUB.DocMaxTitle))
				net.WriteString(string.sub(b, 1, HUB.DocMaxBody))
				net.WriteUInt(st.scope, 4)
				net.WriteUInt(st.minGrade, 3)
				net.WriteString(f)
				net.WriteBool(bImage)
				net.SendToServer()
				-- Le sync qui suit selectionnera MON document le plus recent :
				-- le joueur VOIT son document enregistre (bug user 08/09).
				DOC_PICK_NEWEST = true
			end
			if st.img then
				st.status = "Envoi de l'image..."
				uploadDocImage(st.img, function(ok, msg)
					if not ok then st.status = msg or "Envoi impossible." return end
					sendDoc(true)
				end)
			else
				sendDoc(false)
			end
		end)
		save:SetPos(rw - s(170), optY + s(38))
		save:SetSize(s(150), s(34))

		local cancel = mkBtn(right, "ANNULER", false, function()
			DOC_SEL = bEdit and docEdit.id or nil
			showViewer(bEdit and docEdit or nil)
		end)
		cancel:SetPos(rw - s(260), optY + s(38))
		cancel:SetSize(s(80), s(34))
	end

	-- Restaure la selection apres un rebuild ; apres ENREGISTRER, saute sur mon
	-- document le plus recent (docs tries created_at DESC par le serveur).
	if DOC_PICK_NEWEST then
		DOC_PICK_NEWEST = false
		for _, d in ipairs(SYNC.docs) do
			if d.mine then DOC_SEL = d.id break end
		end
	end
	local dSel = nil
	if DOC_SEL then
		for _, d in ipairs(SYNC.docs) do
			if d.id == DOC_SEL then dSel = d break end
		end
		if not dSel then DOC_SEL = nil end
	end
	showViewer(dSel)
end

-- ══════════════════════════════════════════════════════════════════════════
-- ONGLET RECETTES (cahier DHTML)
-- ══════════════════════════════════════════════════════════════════════════
-- Cahier de recettes : VRAI LIVRE (demande user 08/09). Couverture laquee qu'on
-- ouvre, double-page washi, pages tournees avec animation (rotateY sur le pli),
-- sommaire cliquable, numeros de page. Les pages sont generees en Lua depuis
-- HUB.PotionRecipes et injectees en JSON dans le JS du livre.
local BOOK_SHELL = [==[
<html><head><meta charset="utf-8"><style>
@@BEBAS@@
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; }
body { background:#0b0b0e; font-family:Georgia,'Times New Roman',serif;
  background-image:radial-gradient(ellipse at 50% -10%, #1a1a22 0%, #0b0b0e 60%); }
/* PAS de raccourci CSS `inset:` ni de `gap:` flex ici : le Chromium embarque
   de GMod ne les connait pas — c'est ce qui collait le carnet en haut a gauche. */
.stage { position:absolute; left:0; top:0; right:0; bottom:0;
  display:flex; align-items:center; justify-content:center; }
.scaler { width:1160px; height:800px; flex:none; }

.bookwrap { position:relative; width:1160px; height:760px; margin-top:20px; perspective:2600px; }

/* ── Couverture fermee ── */
.cover { position:absolute; left:290px; top:10px; width:580px; height:740px; cursor:pointer;
  transform-origin:left center; transition:transform .8s cubic-bezier(.6,.05,.3,1), opacity .3s ease .55s;
  background:linear-gradient(135deg, #1d1315 0%, #17100f 55%, #211517 100%);
  border-radius:6px 14px 14px 6px;
  box-shadow:0 30px 80px rgba(0,0,0,.75), inset 0 0 0 1px rgba(207,68,78,.25),
    inset 10px 0 24px rgba(0,0,0,.5);
  display:flex; flex-direction:column; align-items:center; justify-content:center; }
.cover:before { content:""; position:absolute; left:26px; top:26px; right:26px; bottom:26px;
  border:2px solid rgba(207,68,78,.55); border-radius:4px;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.05), 0 1px 0 rgba(255,255,255,.04); }
.cover h1 { font-family:'BebasEVO',Impact,sans-serif; font-weight:400; font-size:56px;
  letter-spacing:7px; color:#e8dcc8; text-align:center; line-height:1.05; margin:10px 0;
  text-shadow:0 1px 0 rgba(0,0,0,.8), 0 -1px 0 rgba(255,255,255,.06); }
.cover .sub { color:#8a7460; font-size:13px; font-style:italic; letter-spacing:1px; }
.cover .hint { position:absolute; bottom:34px; color:#6a5a4c; font-size:12px; font-style:italic; }
/* Details de couverture (08/09) : filets a losange autour du titre, equerres
   interieures du cadre, fiole stylisee, ligne de tome. Pas de kanji. */
.cover .rule { position:relative; width:230px; height:1px; margin:12px 0;
  background:linear-gradient(90deg, transparent, rgba(207,68,78,.55), transparent); }
.cover .rule:after { content:""; position:absolute; left:50%; top:-4px; margin-left:-4px;
  width:8px; height:8px; background:rgba(207,68,78,.75); transform:rotate(45deg); }
.cover .corner { position:absolute; width:26px; height:26px; opacity:.5; }
.cover .ctl { left:38px; top:38px; border-left:2px solid #cf444e; border-top:2px solid #cf444e; }
.cover .ctr { right:38px; top:38px; border-right:2px solid #cf444e; border-top:2px solid #cf444e; }
.cover .cbl { left:38px; bottom:38px; border-left:2px solid #cf444e; border-bottom:2px solid #cf444e; }
.cover .cbr { right:38px; bottom:38px; border-right:2px solid #cf444e; border-bottom:2px solid #cf444e; }
.cover .fiole { position:relative; width:30px; height:44px; margin-top:20px;
  border:2px solid rgba(207,68,78,.65); border-radius:5px 5px 14px 14px; }
.cover .fiole:before { content:""; position:absolute; left:50%; top:-13px; margin-left:-9px;
  width:14px; height:11px; border:2px solid rgba(207,68,78,.65); border-bottom:none;
  border-radius:3px 3px 0 0; }
.cover .fiole:after { content:""; position:absolute; left:3px; right:3px; bottom:3px; height:16px;
  background:rgba(207,68,78,.32); border-radius:0 0 10px 10px; }
.cover .tome { font-family:'BebasEVO',Impact,sans-serif; font-size:14px; letter-spacing:4px;
  color:#8a7460; margin-top:14px; }
.open .cover { transform:rotateY(-165deg); opacity:0; pointer-events:none; }

/* ── Livre ouvert ── */
/* pointer-events:none TANT QUE FERME : le livre (opacite 0) recouvre la
   couverture et avalerait sinon le clic d'ouverture. bottom 46px = juste milieu
   valide user (0 = trop bas, 52 = trop haut). */
.book { position:absolute; left:0; top:0; right:0; bottom:46px;
  display:flex; opacity:0; pointer-events:none; transition:opacity .5s ease .35s;
  filter:drop-shadow(0 30px 60px rgba(0,0,0,.7)); }
.open .book { opacity:1; pointer-events:auto; }
/* Toute la page est cliquable : gauche = precedent, droite = suivant. */
.page { width:50%; height:100%; background:#f3ead8; color:#241f19; position:relative;
  padding:40px 44px 52px; overflow:hidden; cursor:pointer;
  transition:transform .26s ease-in; backface-visibility:hidden; }
.page.pl { border-radius:8px 2px 2px 8px; transform-origin:right center;
  background:linear-gradient(90deg, #ece1cb 0%, #f3ead8 12%, #f3ead8 96%, #e2d5ba 100%);
  box-shadow:inset -14px 0 26px -14px rgba(90,60,20,.45); }
.page.pr { border-radius:2px 8px 8px 2px; transform-origin:left center;
  background:linear-gradient(90deg, #e2d5ba 0%, #f3ead8 4%, #f3ead8 88%, #ece1cb 100%);
  box-shadow:inset 14px 0 26px -14px rgba(90,60,20,.45); }
.page.turn { transition:transform .24s ease-in; }
.pr.turn { transform:rotateY(-86deg); }
.pl.turn { transform:rotateY(86deg); }
.spine { position:absolute; left:50%; top:0; bottom:0; width:34px; margin-left:-17px;
  background:linear-gradient(90deg, transparent, rgba(40,25,10,.28) 45%, rgba(40,25,10,.38) 50%, rgba(40,25,10,.28) 55%, transparent);
  pointer-events:none; z-index:5; }
.pageno { position:absolute; bottom:20px; font-size:12px; color:#8a7c66; font-style:italic; }
.pl .pageno { left:40px; } .pr .pageno { right:40px; }

/* ── Navigation : bottom 6px = JUSTE MILIEU valide user (0 trop bas, 12 trop haut) ── */
.nav { position:absolute; left:0; right:0; bottom:6px; height:34px; display:flex;
  align-items:center; justify-content:center; color:#8b8f9a; font-size:13px; }
.nav > * { margin:0 13px; }

/* ── Decorations LEGERES autour du livre (fond de scene, jamais dans les
   pages) : halo, cercles lateraux, equerres de coins. pointer-events:none. ── */
.deco { position:absolute; pointer-events:none; }
.deco.glow { left:50%; top:50%; width:1400px; height:900px; margin-left:-700px; margin-top:-450px;
  background:radial-gradient(ellipse at center, rgba(207,68,78,.06) 0%, rgba(207,68,78,0) 62%); }
.deco.c1  { left:-150px; top:50%; margin-top:-270px; width:540px; height:540px;
  border:1px solid rgba(207,68,78,.10); border-radius:50%; }
.deco.c1b { left:-105px; top:50%; margin-top:-225px; width:450px; height:450px;
  border:1px dashed rgba(232,220,200,.06); border-radius:50%; }
.deco.c2  { right:-170px; top:50%; margin-top:-310px; width:620px; height:620px;
  border:1px solid rgba(207,68,78,.08); border-radius:50%; }
.deco.c2b { right:-120px; top:50%; margin-top:-260px; width:520px; height:520px;
  border:1px dashed rgba(232,220,200,.05); border-radius:50%; }
.deco.tl { left:24px; top:22px; width:46px; height:46px;
  border-left:2px solid rgba(207,68,78,.35); border-top:2px solid rgba(207,68,78,.35); }
.deco.tr { right:24px; top:22px; width:46px; height:46px;
  border-right:2px solid rgba(207,68,78,.35); border-top:2px solid rgba(207,68,78,.35); }
.deco.bl { left:24px; bottom:22px; width:46px; height:46px;
  border-left:2px solid rgba(207,68,78,.35); border-bottom:2px solid rgba(207,68,78,.35); }
.deco.br { right:24px; bottom:22px; width:46px; height:46px;
  border-right:2px solid rgba(207,68,78,.35); border-bottom:2px solid rgba(207,68,78,.35); }
.deco.hl { left:90px; right:90px; top:44px; height:1px;
  background:linear-gradient(90deg, transparent, rgba(207,68,78,.18), transparent); }
.deco.hb { left:90px; right:90px; bottom:44px; height:1px;
  background:linear-gradient(90deg, transparent, rgba(207,68,78,.18), transparent); }
.nav .btn { cursor:pointer; color:#cf444e; font-family:'BebasEVO',Impact,sans-serif;
  letter-spacing:2px; font-size:17px; user-select:none; padding:4px 10px; }
.nav .btn:hover { color:#e05c66; }
.nav .btn.off { color:#4a4d55; cursor:default; }

/* ── Contenu des pages ── */
.eyebrow { font-size:12px; letter-spacing:3px; color:#8a2a31; font-weight:bold; margin-bottom:6px; }
.page h2 { font-family:'BebasEVO',Impact,sans-serif; font-weight:400; font-size:34px;
  letter-spacing:2px; color:#2a231a; margin-bottom:6px; }
.num { position:absolute; top:34px; right:38px; width:54px; height:54px;
  border:2px solid #b8353f; border-radius:50%; color:#b8353f; display:flex;
  align-items:center; justify-content:center; transform:rotate(10deg); opacity:.8;
  font-family:'BebasEVO',Impact,sans-serif; font-size:22px; }
.chip { display:inline-block; font-size:11px; letter-spacing:2px; font-weight:bold;
  padding:3px 10px; border:1px solid; border-radius:3px; margin-bottom:12px; }
.desc { margin:4px 0 18px; font-size:14px; line-height:1.55; color:#4a4034;
  font-style:italic; border-left:3px solid #cf444e; padding-left:12px; }
.sec { font-family:'BebasEVO',Impact,sans-serif; font-size:20px; letter-spacing:3px;
  color:#8a2a31; border-bottom:1px dashed rgba(90,60,20,.4); padding-bottom:5px; margin:14px 0 8px; }
.ing { display:flex; align-items:center; padding:8px 4px;
  border-bottom:1px solid rgba(90,60,20,.14); font-size:14px; }
.ing > * { margin-right:10px; }
.ing .icn { width:32px; height:32px; flex:none;
  border:1px solid rgba(90,60,20,.28); border-radius:3px; }
.ing:last-child { border-bottom:none; }
.ing .qty { min-width:40px; height:27px; border:2px solid #8a2a31; color:#8a2a31;
  display:flex; align-items:center; justify-content:center; font-weight:bold;
  border-radius:3px; font-size:13px; flex:none; }
.ing .nm { font-weight:bold; color:#2a231a; }
.ing .made { margin-left:auto; margin-right:0; font-size:11px; letter-spacing:.4px;
	color:#8a2a31; border:1px dashed #8a2a31; border-radius:3px; padding:2px 7px; white-space:nowrap; }
.ing .dot { width:12px; height:12px; border-radius:50%; display:inline-block;
  border:1px solid rgba(40,25,10,.4); flex:none; }
/* Sommaire : 20 lignes ne tiennent pas sur la page -> zone SCROLLABLE. */
.toc { margin-top:8px; max-height:470px; overflow-y:auto; padding-right:6px; }
.toc::-webkit-scrollbar { width:6px; }
.toc::-webkit-scrollbar-track { background:rgba(90,60,20,.12); }
.toc::-webkit-scrollbar-thumb { background:rgba(138,42,49,.45); border-radius:3px; }
.tocr { display:flex; align-items:baseline; padding:5px 2px; font-size:14px;
  cursor:pointer; border-bottom:1px dotted rgba(90,60,20,.25); }
.tocr > * { margin-right:8px; }
.tocr > *:last-child { margin-right:0; }
.tocr:hover .tnm { color:#8a2a31; }
.tocr .tn { font-family:'BebasEVO',Impact,sans-serif; font-size:15px; min-width:34px; }
.tocr .tnm { font-weight:bold; color:#2a231a; }
.tocr .lead { flex:1; border-bottom:1px dotted rgba(90,60,20,.5); margin:0 2px; }
.tocr .tp { color:#8a7c66; font-size:12px; }
.step { position:relative; padding:12px 10px 12px 58px; margin-bottom:10px;
  background:rgba(120,90,40,.07); border-radius:3px; }
.step .sn { position:absolute; left:12px; top:50%; transform:translateY(-50%);
  width:32px; height:32px; background:#2a231a; color:#f3ead8; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  font-family:'BebasEVO',Impact,sans-serif; font-size:18px; }
.step .nm { font-weight:bold; font-size:16px; color:#2a231a; }
.step .tm { float:right; color:#8a2a31; font-weight:bold; font-size:13px; }
.step .tx { color:#5a4f41; font-size:13px; margin-top:3px; line-height:1.45; }
/* Citation philosophique de la recette (bas de page, sans auteur). */
.quote { margin-top:16px; padding:8px 14px; border-left:3px solid rgba(207,68,78,.8);
  font-style:italic; color:#5a4f41; font-size:13px; line-height:1.55;
  background:rgba(120,90,40,.06); }
/* Bouton d'action de page (carnet médical : renvoi au mortier pré-rempli). */
.prep { display:inline-block; margin-top:12px; padding:7px 16px; cursor:pointer;
  font-family:'BebasEVO',Impact,sans-serif; font-size:17px; letter-spacing:2px;
  color:#f2e8d8; background:#8a2a31; border-radius:3px; }
.prep:hover { background:#a13741; }
.lrow { display:flex; align-items:center; padding:6px 2px; font-size:13px;
  border-bottom:1px solid rgba(90,60,20,.14); }
.lrow > * { margin-right:10px; }
.lrow:last-child { border-bottom:none; }
.lrow .nm { font-weight:bold; color:#2a231a; flex:1; }
.lrow .in { color:#7a6d5b; font-style:italic; white-space:nowrap; font-size:12px; }
.center { display:flex; flex-direction:column; align-items:center; justify-content:center;
  height:100%; text-align:center; }
.center > * { margin:6px 0; }
.center .t { font-family:'BebasEVO',Impact,sans-serif; font-size:34px; letter-spacing:5px; color:#2a231a; }
.center .s { color:#7a6d5b; font-size:13px; font-style:italic; max-width:340px; line-height:1.6; }
</style></head><body>
<div class="stage">
<div class="deco glow"></div>
<div class="deco c1"></div><div class="deco c1b"></div>
<div class="deco c2"></div><div class="deco c2b"></div>
<div class="deco tl"></div><div class="deco tr"></div>
<div class="deco bl"></div><div class="deco br"></div>
<div class="deco hl"></div><div class="deco hb"></div>
<div class="scaler">
<div class="bookwrap" id="wrap">
  <div class="cover" id="cover">
    <div class="corner ctl"></div><div class="corner ctr"></div>
    <div class="corner cbl"></div><div class="corner cbr"></div>
    <div class="rule"></div>
    <h1>CAHIER<br>DE RECETTES</h1>
    <div class="rule"></div>
    <div class="sub">Division scientifique</div>
    <div class="fiole"></div>
    <div class="tome">TOME UNIQUE &middot; SYNTH&Egrave;SES &amp; PR&Eacute;PARATIONS</div>
    <div class="hint">Cliquer pour ouvrir le registre</div>
  </div>
  <div class="book">
    <div class="page pl" id="pl" title="Page précédente"></div>
    <div class="page pr" id="pr" title="Page suivante"></div>
    <div class="spine"></div>
  </div>
  <div class="nav">
    <span class="btn" id="prev">&#8249; PRÉCÉDENT</span>
    <span id="pcount"></span>
    <span class="btn" id="next">SUIVANT &#8250;</span>
  </div>
</div></div></div>
<script>
var PAGES = @@PAGES@@;
var spread = 0, anim = false;
var maxSpread = Math.ceil(PAGES.length / 2) - 1;
var pl = document.getElementById('pl'), pr = document.getElementById('pr');
function render() {
  pl.innerHTML = (PAGES[spread * 2] || '') + '<div class="pageno">' + (spread * 2 + 1) + '</div>';
  pr.innerHTML = (PAGES[spread * 2 + 1] || '') + '<div class="pageno">' + (spread * 2 + 2) + '</div>';
  document.getElementById('pcount').textContent = 'Pages ' + (spread * 2 + 1) + '-' + (spread * 2 + 2) + ' / ' + PAGES.length;
  document.getElementById('prev').className = 'btn' + (spread <= 0 ? ' off' : '');
  document.getElementById('next').className = 'btn' + (spread >= maxSpread ? ' off' : '');
}
function go(n) {
  n = Math.max(0, Math.min(maxSpread, n));
  if (anim || n === spread) return;
  anim = true;
  var fwd = n > spread;
  var turning = fwd ? pr : pl;
  turning.classList.add('turn');
  setTimeout(function() {
    spread = n; render();
    turning.classList.remove('turn');
    /* La page entrante doit PARTIR pliee puis se deplier : on coupe la
       transition le temps de la poser pliee, sinon rien ne bouge. */
    var incoming = fwd ? pl : pr;
    incoming.style.transition = 'none';
    incoming.classList.add('turn');
    incoming.offsetWidth;
    incoming.style.transition = '';
    incoming.classList.remove('turn');
    setTimeout(function() { anim = false; }, 280);
  }, 240);
}
var wrap = document.getElementById('wrap');
function isOpen() { return wrap.className.indexOf('open') >= 0; }
function openBook() { wrap.className = 'bookwrap open'; }
document.getElementById('cover').onclick = openBook;
/* Sur la couverture, PRECEDENT/SUIVANT ouvrent d'abord le livre. */
document.getElementById('prev').onclick = function() { if (!isOpen()) { openBook(); return; } go(spread - 1); };
document.getElementById('next').onclick = function() { if (!isOpen()) { openBook(); return; } go(spread + 1); };
/* Toute la page tournee : gauche = precedent, droite = suivant. Exceptions :
   les lignes du sommaire (data-goto, le listener body navigue) et TOUT le bloc
   .toc (zone scrollable : cliquer/scroller ne doit pas tourner la page). */
function pageClick(dir) {
  return function(e) {
    if (e.target.closest && (e.target.closest('[data-goto]') || e.target.closest('.toc'))) return;
    go(spread + dir);
  };
}
pl.onclick = pageClick(-1);
pr.onclick = pageClick(1);
document.body.addEventListener('click', function(e) {
  var t = e.target.closest ? e.target.closest('[data-goto]') : null;
  if (t) go(Math.floor((parseInt(t.getAttribute('data-goto'), 10) - 1) / 2));
});
function fit() {
  var s = Math.min(window.innerWidth * 0.97 / 1160, window.innerHeight * 0.96 / 800);
  document.querySelector('.scaler').style.transform = 'scale(' + s + ')';
}
window.onresize = fit;
setInterval(fit, 400); /* le viewport DHTML de GMod peut arriver en retard */
fit();
render();
</script>
</body></html>
]==]

-- @font-face Bebas embarquee en base64 (pattern evo_map) ; fallback Impact.
local _bebasCSS
local function bebasCSS()
	if _bebasCSS ~= nil then return _bebasCSS end
	_bebasCSS = ""
	local raw = file.Read("resource/fonts/BebasNeue-Regular.ttf", "GAME")
	if raw and #raw < 400 * 1024 then
		_bebasCSS = "@font-face{font-family:'BebasEVO';src:url('data:font/ttf;base64,"
			.. util.Base64Encode(raw, true):gsub("%s", "") .. "');}"
	end
	return _bebasCSS
end

-- Teintes CSS des 12 couleurs de cristaux (pastille dans la liste d'ingredients).
local CRYSTAL_HEX = {
	carmin = "#b8353f", bleu = "#3b6fd4", vert = "#3d9e5f", violet = "#7c4fc9",
	cyan = "#2fb5c7", dore = "#c9a437", orange = "#d97c2b", rose = "#d46a9e",
	blanc = "#e8e4da", noir = "#2a2a2e", lime = "#9ccc3f", magenta = "#c73bb0",
}
-- (PALIER_HEX retire 08/09 : la couleur = le TYPE de potion, jamais le niveau.)

-- ── Vignettes 3D des ingredients (demande user 08/09 : "comme l'inventaire") ─
-- Le carnet est du DHTML : impossible d'y monter un DModelPanel. Chaque couple
-- (modele, skin) est donc rendu UNE fois dans un RT (fond couleur papier,
-- fullbright), capture JPEG -> base64 embarque dans le HTML (pattern
-- MoneyIconDataURI). Cache RAM de session ; quand tout est pret, l'onglet
-- recettes ouvert se rebuild pour afficher les vignettes.
local ICON_SIZE = 64
local ICONS = {}     -- ["model|skin"] = base64 jpeg
local iconQueue = {}
local iconHookAlive = false
local iconScanned = {} -- [tRecipes] = true : chaque registre n'est scanne qu'une fois

local function iconKey(sModel, nSkin) return sModel .. "|" .. (nSkin or 0) end

-- (PARAMETRE 08/18) La file d'icones sert desormais N'IMPORTE QUEL registre de
-- recettes : le carnet des scientifiques ET le carnet medical (cl_science_medic)
-- partagent le meme pipeline de vignettes. L'ancien garde single-shot devient un
-- garde PAR REGISTRE, et le hook se relance si une 2e file arrive apres coup.
local startIconHook -- declare avant : QueueRecipeIcons l'appelle

function EVO_SCIENCE.QueueRecipeIcons(tRecipes)
	if not istable(tRecipes) or iconScanned[tRecipes] then return end
	iconScanned[tRecipes] = true
	local seen = {}
	for _, r in ipairs(tRecipes) do
		for itemId in pairs(r.tIngredients) do
			local it = HUB.Items[itemId]
			if it and it.model_path then
				local k = iconKey(it.model_path, it.skin)
				if not seen[k] and not ICONS[k] then
					seen[k] = true
					iconQueue[#iconQueue + 1] = { mdl = it.model_path, skin = it.skin or 0, key = k }
				end
			end
		end
	end
	if #iconQueue > 0 and startIconHook then startIconHook() end
end

local function queueIngredientIcons()
	EVO_SCIENCE.QueueRecipeIcons(HUB.PotionRecipes)
end

startIconHook = function()
	if iconHookAlive then return end
	iconHookAlive = true
	hook.Add("PostRender", "EVOSci::IngIcons", function()
		-- Nom de RT STABLE (regle projet : un RT par usage, jamais de suffixe).
		local rt = GetRenderTarget("EVOSci_IngIcon", ICON_SIZE, ICON_SIZE)
		for _ = 1, 3 do
			local job = table.remove(iconQueue)
			if not job then break end
			local ent = ClientsideModel(job.mdl, RENDERGROUP_OPAQUE)
			if IsValid(ent) then
				ent:SetSkin(job.skin)
				ent:SetupBones()
				local mn, mx = ent:GetRenderBounds()
				local vCenter = (mn + mx) * 0.5
				local nRadius = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z, 2)
				local vDir = Vector(1, 0.8, 0.55):GetNormalized()
				local vCam = vCenter + vDir * nRadius * 2.1
				render.PushRenderTarget(rt)
				render.Clear(240, 231, 212, 255, true, true)
				cam.Start3D(vCam, (vCenter - vCam):Angle(), 32, 0, 0, ICON_SIZE, ICON_SIZE)
				render.SuppressEngineLighting(true)
				ent:DrawModel()
				render.SuppressEngineLighting(false)
				cam.End3D()
				local sData = render.Capture({ format = "jpeg", quality = 92, x = 0, y = 0, w = ICON_SIZE, h = ICON_SIZE })
				render.PopRenderTarget()
				ent:Remove()
				if sData and #sData > 0 then
					ICONS[job.key] = util.Base64Encode(sData, true):gsub("%s", "")
				end
			end
		end
		if #iconQueue == 0 then
			hook.Remove("PostRender", "EVOSci::IngIcons")
			iconHookAlive = false
			if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("recettes") end
			-- Le carnet MEDICAL partage ces vignettes (cl_science_medic).
			if EVO_SCIENCE._MedBookRebuild then EVO_SCIENCE._MedBookRebuild() end
		end
	end)
end

-- <img> base64 d'un ingredient ("" tant que la vignette n'est pas prete).
local function ingIcon(sItemId)
	local it = HUB.Items[sItemId]
	if not (it and it.model_path) then return "" end
	local b64 = ICONS[iconKey(it.model_path, it.skin)]
	if not b64 then return "" end
	return '<img class="icn" src="data:image/jpeg;base64,' .. b64 .. '">'
end

-- INDICE CRISTAUX des recettes NON débloquées (user 08/27 : « un labyrinthe sans
-- sortie ») : les COULEURS de cristaux de la recette, distinctes et triées — le
-- tier, les quantités, champignons et plantes restent à trouver.
local function recipeCrystalColors(r)
	local seen, out = {}, {}
	for itemId in pairs(r.tIngredients or {}) do
		local _, nColor = EVO_SCIENCE.CrystalParse(itemId)
		if nColor and not seen[nColor] then
			seen[nColor] = true
			out[#out + 1] = nColor
		end
	end
	table.sort(out)
	return out
end

-- Pastilles HTML (carnet) : une par couleur, stylées en ligne (indépendant du CSS du livre).
local function crystalHintHTML(r)
	local t = {}
	for _, nColor in ipairs(recipeCrystalColors(r)) do
		local c = HUB.CrystalColors[nColor]
		if c then
			t[#t + 1] = string.format(
				'<span title="%s" style="display:inline-block;width:8px;height:8px;border-radius:50%%;margin-left:4px;vertical-align:middle;background:%s"></span>',
				c.name, CRYSTAL_HEX[c.key] or "#888")
		end
	end
	return table.concat(t, "")
end

-- "#rrggbb" -> Color (cache : appelé à la construction des lignes, jamais en Paint).
local _hexColorCache = {}
local function hexColor(sHex)
	local c = _hexColorCache[sHex]
	if c then return c end
	local r, g, b = tostring(sHex or ""):match("^#(%x%x)(%x%x)(%x%x)$")
	c = r and Color(tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)) or Color(136, 136, 136)
	_hexColorCache[sHex] = c
	return c
end

local function ingredientLines(r)
	-- Champignons d'abord, cristaux ensuite (tries par tier puis couleur).
	-- (Appelee UNIQUEMENT pour une recette debloquee : la page entiere d'une
	-- recette non validee est verrouillee en amont, cf. buildRecipeHTML.)
	local shrooms, crystals = {}, {}
	for itemId, n in pairs(r.tIngredients) do
		local nTier, nColor = EVO_SCIENCE.CrystalParse(itemId)
		if nTier then
			crystals[#crystals + 1] = { id = itemId, n = n, tier = nTier, color = nColor }
		else
			shrooms[#shrooms + 1] = { id = itemId, n = n }
		end
	end
	table.sort(shrooms, function(a, b) return a.id < b.id end)
	table.sort(crystals, function(a, b)
		if a.tier ~= b.tier then return a.tier < b.tier end
		return a.color < b.color
	end)
	local out = {}
	for _, e in ipairs(shrooms) do
		-- Nom via le resolver HUB-first (ITEMS peut etre vide : l'icone sortait
		-- mais le nom affichait l'id brut "herbe_reishi", constat user 08/18).
		-- Ingredient qui SE CRAFTE lui-meme a la table (infusion d'un vaccin…) :
		-- petit marqueur « se prepare a la table » (user 08/19).
		local sMade = (EVO_SCIENCE.MedRecipeById and EVO_SCIENCE.MedRecipeById(e.id))
			and '<span class="made">se prépare à la table</span>' or ""
		out[#out + 1] = string.format(
			'<div class="ing"><div class="qty">x%d</div>%s<div class="nm">%s</div>%s</div>',
			e.n, ingIcon(e.id), EVO_SCIENCE.ItemName(e.id), sMade)
	end
	for _, e in ipairs(crystals) do
		local c = HUB.CrystalColors[e.color]
		local hex = (c and CRYSTAL_HEX[c.key]) or "#888"
		-- Vignette 3D du cristal (bon tier + bonne teinte) ; pastille couleur en
		-- attendant que le rendu soit pret.
		local sIcn = ingIcon(e.id)
		if sIcn == "" then
			sIcn = string.format('<span class="dot" style="background:%s"></span>', hex)
		end
		out[#out + 1] = string.format(
			'<div class="ing"><div class="qty">x%d</div>%s<div class="nm">%s (%s)</div></div>',
			e.n, sIcn, HUB.CrystalTierNames[e.tier] or "Cristal", c and c.name or "?")
	end
	return table.concat(out, "")
end

-- (PARAMETRE 08/18) Le carnet sert DEUX registres : les potions du laboratoire
-- (defaut, sortie inchangee) et les preparations de la TABLE MEDICALE
-- (cl_science_medic, via EVO_SCIENCE.BuildRecipeBookHTML). La spec porte tout
-- ce qui differe : registre, decouverte, chips, textes des pages fixes.
local function scienceBookSpec()
	local function dur(step)
		return string.format("%gs", HUB.PotionStepDuration[step] or 2)
	end
	local fuse = {}
	for nTier = 6, 2, -1 do
		fuse[#fuse + 1] = string.format(
			'<div class="lrow"><div class="nm">%s &#8594; %s</div><div class="in">%d identiques · %s ¥</div></div>',
			HUB.CrystalTierNames[nTier] or "?", HUB.CrystalTierNames[nTier - 1] or "?",
			HUB.CrystalMergeCount, string.Comma(EVO_SCIENCE.CrystalMergeCostFor(nTier)))
	end
	return {
		tRecipes = HUB.PotionRecipes,
		fDiscovered = recipeDiscovered,
		fLockedHint = crystalHintHTML, -- couleurs de cristaux des recettes à découvrir (user 08/27)
		fTocHex = function(r)
			local cat = HUB.PotionCategories[r.sCat]
			return (cat and cat.sHex) or "#8a2a31"
		end,
		-- SEULE la CATEGORIE est coloree (couleur = TYPE de potion, jamais le
		-- niveau — demande user 08/09) ; le chip PALIER reste en encre neutre.
		fChipsHTML = function(r)
			local cat = HUB.PotionCategories[r.sCat]
			local catHex = (cat and cat.sHex) or "#8a2a31"
			return string.format(
				'<span class="chip" style="color:%s;border-color:%s">%s</span> '
				.. '<span class="chip" style="color:#8a7c66;border-color:#8a7c66">%s</span>',
				catHex, catHex, string.upper(cat and cat.sName or "?"),
				string.upper(HUB.PotionPaliers[r.nPalier] or ""))
		end,
		-- sFx : ligne d'effet d'une recette qui n'est pas une fiole (prothèses).
		fFx = function(r) return r.sFx or EVO_SCIENCE.PotionFxDesc(HUB.PotionEffects[r.id]) end,
		sGuardHTML = [[<div class="center"><div class="t">CAHIER DE RECETTES</div>
			<div class="s">Registre des synthèses validées par le laboratoire.<br>
			Toute reproduction hors du laboratoire est passible de sanction.</div></div>]],
		sSommaireFmt = "Synthèses validées par le laboratoire : %d / %d.",
		sProtocoleHTML = '<div class="eyebrow">METHODE</div><h2>Protocole commun</h2>'
			.. '<div class="step"><span class="sn">1</span><span class="tm">' .. dur("broyeur") .. '</span><div class="nm">Broyage</div><div class="tx">Réduire les ingrédients en poudre fine au broyeur. La poudre doit prendre une teinte uniforme.</div></div>'
			.. '<div class="step"><span class="sn">2</span><span class="tm">' .. dur("melange") .. '</span><div class="nm">Mélange</div><div class="tx">Incorporer la poudre au solvant spirituel sous agitation constante. Ne jamais interrompre.</div></div>'
			.. '<div class="step"><span class="sn">3</span><span class="tm">' .. dur("synthese") .. '</span><div class="nm">Synthèse</div><div class="tx">Porter la solution au synthétiseur. La potion est stable quand la mousse retombe.</div></div>'
			.. '<div class="sec">FUSION DES CRISTAUX (FORGE)</div>' .. table.concat(fuse, ""),
		sObservationsHTML = [[<div class="eyebrow">TERRAIN</div><h2>Observations</h2>
			<div class="desc">Les champignons poussent par poignées dans les zones de chasse, puis plus rien pendant une demi-heure : cueillez tout, notez l'endroit, revenez.</div>
			<div class="desc">Un cristal se récolte sur les dépouilles des Hollows. Sa teinte est un caprice du reiryoku : la bonne couleur peut se faire attendre, la forge sait fusionner les surplus.</div>
			<div class="desc">Les ingrédients sont consommés dès le broyage. Un mélange erroné donne une potion RATÉE, blanche et inerte : expérimentez avec méthode.</div>
			<div class="desc">Ce registre ne livre ses proportions qu'aux laboratoires qui ont VALIDÉ la synthèse : réussissez-la une fois pour compléter sa page, pour toute la division.</div>]],
		sColophonHTML = [[<div class="center"><div class="t">DIVISION SCIENTIFIQUE</div>
			<div class="s">Registre tenu par le Responsable de division.<br>
			Les effets des préparations sont consignés dans un volume séparé.</div></div>]],
	}
end

local function buildRecipeHTML(spec)
	spec = spec or scienceBookSpec()
	local pages = {}

	-- PAGINATION DYNAMIQUE (demande user 08/09) : le carnet ne contient QUE les
	-- pages d'intro (garde / sommaire / methode / observations) + UNE page par
	-- recette DEBLOQUEE — il grandit page par page au fil des decouvertes. Les
	-- pages des recettes non validees N'EXISTENT PAS (plus de placeholders).
	local pageOf = {} -- [index recette] = numero de page (recettes debloquees)
	local nPage = 4
	for i, r in ipairs(spec.tRecipes) do
		if spec.fDiscovered(r.id) then
			nPage = nPage + 1
			pageOf[i] = nPage
		end
	end

	-- p1 : page de garde
	pages[1] = spec.sGuardHTML

	-- p2 : sommaire (scrollable + cliquable). Le NOM d'une recette non debloquee
	-- est masque et sa ligne ne pointe vers aucune page.
	do
		local rows = {}
		local nDisc = 0
		for i, r in ipairs(spec.tRecipes) do
			if pageOf[i] then
				nDisc = nDisc + 1
				rows[#rows + 1] = string.format(
					'<div class="tocr" data-goto="%d"><span class="tn" style="color:%s">%02d</span><span class="tnm">%s</span><span class="lead"></span><span class="tp">p. %d</span></div>',
					pageOf[i], spec.fTocHex(r), i, r.sName, pageOf[i])
			else
				-- Ligne verrouillee = numero + pointilles + « à découvrir », SANS texte
				-- (les 20 libelles italiques identiques rendaient mal dans le vieux CEF :
				-- texte fantome sur une partie des lignes — screenshot user 08/09).
				-- Indice optionnel de la spec (labo : pastilles des couleurs de cristaux).
				local sHint = spec.fLockedHint and spec.fLockedHint(r) or ""
				rows[#rows + 1] = string.format(
					'<div class="tocr" style="cursor:default"><span class="tn" style="color:#8a7c66">%02d</span><span class="lead"></span><span class="tp">à découvrir%s</span></div>',
					i, sHint)
			end
		end
		-- Les pages d'INTRO (toujours debloquees) sont listees EN TETE du sommaire :
		-- sans elles, un joueur sans decouverte croyait le carnet entierement
		-- verrouille (demande user 08/09).
		local intro =
			'<div class="tocr" data-goto="3"><span class="tn" style="color:#8a2a31">—</span><span class="tnm">Protocole commun</span><span class="lead"></span><span class="tp">p. 3</span></div>'
			.. '<div class="tocr" data-goto="4"><span class="tn" style="color:#8a2a31">—</span><span class="tnm">Observations</span><span class="lead"></span><span class="tp">p. 4</span></div>'
			.. '<div class="sec" style="margin:10px 0 4px">RECETTES</div>'
		pages[2] = '<div class="eyebrow">REGISTRE</div><h2>Sommaire</h2>'
			.. string.format('<div class="desc">' .. spec.sSommaireFmt .. '</div>', nDisc, #spec.tRecipes)
			.. '<div class="toc">' .. intro .. table.concat(rows, "") .. '</div>'
	end

	-- p3 : protocole / p4 : observations (textes fournis par la spec)
	pages[3] = spec.sProtocoleHTML
	pages[4] = spec.sObservationsHTML

	-- p5.. : UNIQUEMENT les recettes DEBLOQUEES, une par page (numero N° = index
	-- du registre, numero de PAGE = position dynamique). Citation en bas de page.
	for i, r in ipairs(spec.tRecipes) do
		if pageOf[i] then
			local catHex = spec.fTocHex(r)
			pages[pageOf[i]] = string.format(
				'<div class="num">N°%02d</div><div class="eyebrow">RECETTE</div><h2>%s</h2>'
				.. '%s'
				.. '<div class="desc" style="border-left-color:%s">%s</div>'
				.. '<div class="desc">%s</div><div class="sec">INGRÉDIENTS</div>%s'
				.. '%s' -- action de page optionnelle (carnet médical : PRÉPARER)
				.. '<div class="quote">« %s »</div>',
				i, r.sName,
				spec.fChipsHTML(r),
				catHex, "EFFET — " .. spec.fFx(r),
				r.sDesc or "", ingredientLines(r),
				spec.fActionHTML and spec.fActionHTML(r) or "",
				r.sQuote or "")
		end
	end

	-- Colophon en derniere page (le carnet grandit avec les decouvertes).
	pages[nPage + 1] = spec.sColophonHTML

	local html = BOOK_SHELL
	html = string.Replace(html, "@@BEBAS@@", bebasCSS())
	html = string.Replace(html, "@@PAGES@@", util.TableToJSON(pages) or "[]")
	return html
end

-- Export : le carnet MEDICAL (cl_science_medic) construit le sien avec sa spec.
function EVO_SCIENCE.BuildRecipeBookHTML(spec)
	return buildRecipeHTML(spec)
end

local function buildRecettes(content, ctx)
	-- Lance (une seule fois) le rendu des vignettes 3D d'ingredients ; l'onglet
	-- se rebuild tout seul quand elles sont pretes.
	queueIngredientIcons()
	local html = vgui.Create("DHTML", content)
	html:Dock(FILL)
	html:SetAllowLua(false)
	html:SetKeyboardInputEnabled(false)
	html:SetHTML(buildRecipeHTML())
end

-- ══════════════════════════════════════════════════════════════════════════
-- ONGLET POTIONS : EXPERIMENTATION (refonte 08/09). On depose un MELANGE LIBRE
-- (drag & drop depuis le sac, filtre champignons + cristaux) ; le resultat
-- n'est revele qu'a la fin de la synthese. AUCUN requis affiche ici (demande
-- user) : les proportions ne se lisent QUE dans le carnet, page debloquee.
-- Clic sur une recette debloquee = remplissage auto du melange.
-- 1 seule synthese a la fois PAR POSTE (etat busy renvoye par le serveur).
-- ══════════════════════════════════════════════════════════════════════════
local DROP_NAME = "EVO_SCI_INGREDIENT"

local function comboFind(itemId)
	for i, e in ipairs(COMBO) do
		if e.itemId == itemId then return i, e end
	end
	return nil
end

local function comboFill(r)
	comboClear()
	local t = {}
	for itemId, n in pairs(r.tIngredients) do
		t[#t + 1] = { itemId = itemId, n = n, crystal = EVO_SCIENCE.CrystalParse(itemId) ~= nil }
	end
	table.sort(t, function(a, b)
		if a.crystal ~= b.crystal then return not a.crystal end
		return a.itemId < b.itemId
	end)
	for _, e in ipairs(t) do COMBO[#COMBO + 1] = { itemId = e.itemId, n = e.n } end
end

-- Niveau d'etoiles selectionne (1..3, persiste entre rebuilds de l'onglet).
local POTION_STAR = 1
-- LOT (craft en serie, user 09/15) : potions par synthese, 1..HUB.PotionMaxBatch.
local POTION_QTY = 1

-- ══════════════════════════════════════════════════════════════════════════
-- MINI-JEUX DES ÉTAPES DE POTION (user 08/19 « ajouter des animations pendant
-- la fabrication, comme le mortier ») : chaque clic d'étape joue un GESTE avant
-- d'envoyer le net — broyage au mortier, agitation à l'erlenmeyer, gouttes de
-- pipette pour la synthèse. Purement client : fermer/rater ne coûte RIEN
-- (l'étape n'est simplement pas lancée), le serveur garde ses minuteries.
-- Verrerie = les VRAIS modèles médicaux (HUB.MedicModels / HUB.MedicDecor).
-- ══════════════════════════════════════════════════════════════════════════
local GSC = math.Clamp(ScrH() / 1080, 0.9, 2.0)
local function gs(n) return math.floor(n * GSC + 0.5) end

local COL_G_BG    = Color(4, 4, 8, 218)
local COL_G_TITLE = Color(235, 235, 240)
local COL_G_MUT   = Color(150, 150, 160)
local COL_G_ACC   = Color(207, 68, 78)
local COL_G_OK    = Color(96, 220, 130)
local COL_G_BAD   = Color(230, 90, 80)
local COL_G_SUB   = Color(45, 45, 52)
local COL_G_LIQ   = Color(157, 184, 216, 150)

local function medDecorModel(sId)
	for _, d in ipairs(HUB.MedicDecor or {}) do
		if d.id == sId then return d.model end
	end
end

-- Boucle sonore partagée avec la table médicale (export de cl_science_medic) ;
-- export absent = objet muet aux mêmes méthodes.
local function actionLoop(sPath)
	if EVO_SCIENCE.ActionLoop then return EVO_SCIENCE.ActionLoop(sPath) end
	return { Tick = function() end, Kill = function() end }
end

local function drawGBar(x, y, w2, sLabel, frac, colFill)
	draw.SimpleText(sLabel, "EVOSci_S", x, y - gs(22), COL_G_MUT)
	draw.RoundedBox(gs(9), x, y, w2, gs(18), COL_G_SUB)
	local fw = math.floor(w2 * math.Clamp(frac, 0, 1))
	if fw > gs(16) then draw.RoundedBox(gs(9), x, y, fw, gs(18), colFill) end
end

-- Overlay commun des trois gestes : voile, titre, Échap/croix, nettoyage.
local function potionOverlay(sTitle, sHint, tMdls, fDone)
	local ov = vgui.Create("DPanel")
	ov:SetSize(ScrW(), ScrH())
	ov:SetPos(0, 0)
	ov:MakePopup()
	ov:SetKeyboardInputEnabled(true)
	ov:SetCursor("blank")
	ov._done = false
	ov.Finish = function(pnl, bOk)
		if pnl._done then return end
		pnl._done = true
		if bOk then
			surface.PlaySound(CFG.Sounds.sampleOk or "")
			if fDone then fDone() end
		end
		pnl:Remove()
	end
	ov.OnRemove = function(pnl)
		for _, m in pairs(tMdls) do
			if IsValid(m) then m:Remove() end
		end
		if pnl._snd then pnl._snd:Kill() end
	end
	ov.OnKeyCodePressed = function(pnl, key)
		if key == KEY_ESCAPE then pnl:Finish(false) end
	end
	ov.PaintHead = function(_, w)
		local cx = w * 0.5
		surface.SetDrawColor(COL_G_BG)
		surface.DrawRect(0, 0, w, ov:GetTall())
		draw.SimpleText(sTitle, "EVOSci_Title", cx, gs(92), COL_G_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(COL_G_ACC)
		surface.DrawRect(cx - gs(120), gs(126), gs(240), gs(4))
		draw.SimpleText(sHint, "EVOSci_B", cx, gs(160), COL_G_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	if EVO_CRAFT and EVO_CRAFT.MakeCloseCross then
		local x = EVO_CRAFT.MakeCloseCross(ov, ov:GetWide() - gs(104), gs(44), function() ov:Finish(false) end)
		x:SetCursor("hand")
	end
	return ov
end

-- ── 1. BROYAGE : mortier + pilon-curseur, geste circulaire régulier ──────────
-- Même geste que la table médicale ; ici rater ne PERD rien (relance libre).
local function openPotionGrind(tIng, fDone)
	local tMdls = {}
	tMdls.mortier = ClientsideModel(HUB.MedicModels and HUB.MedicModels.mortier or "", RENDERGROUP_OPAQUE)
	tMdls.pilon = ClientsideModel(HUB.MedicModels and HUB.MedicModels.pilon or "", RENDERGROUP_OPAQUE)
	for i, e in ipairs(tIng or {}) do
		local m = ClientsideModel(e.mdl, RENDERGROUP_OPAQUE)
		if IsValid(m) then
			m:SetSkin(e.skin or 0)
			tMdls[i] = m
		end
	end
	for _, m in pairs(tMdls) do
		if IsValid(m) then m:SetNoDraw(true) end
	end

	local ov = potionOverlay("BROYER LES INGRÉDIENTS",
		"Maintiens le CLIC GAUCHE et tourne autour du mortier, d'un geste régulier.", tMdls, fDone)
	ov._snd = actionLoop(CFG.Sounds.medMixing or "")

	local nGoal = (HUB.PotionGrindTurns or 4) * math.pi * 2
	local nProgress, nCasse = 0, 0
	local nLastAng, nLastT, nAngSmooth = nil, RealTime(), 0

	ov.Paint = function(pnl, w, h)
		pnl:PaintHead(w)
		local cx, cy = w * 0.5, h * 0.5
		local mx, my = pnl:CursorPos()
		local dx, dy = mx - cx, my - cy
		local nAng = math.atan2(dy, dx)
		local now = RealTime()
		local dt = math.max(0.001, now - nLastT)
		nLastT = now

		local bHeld = input.IsMouseDown(MOUSE_LEFT)
		if nLastAng and bHeld then
			local d = math.abs(math.NormalizeAngle(math.deg(nAng - nLastAng)))
			local nSpeed = math.rad(d) / dt
			nAngSmooth = nAngSmooth + (nSpeed - nAngSmooth) * math.min(1, dt * 8)
			if nAngSmooth >= (HUB.MedGrindMinSpeed or 2) and nAngSmooth <= (HUB.MedGrindMaxSpeed or 9) then
				nProgress = nProgress + math.rad(d)
			elseif nAngSmooth > (HUB.MedGrindBreakAt or 14) then
				nCasse = nCasse + (nAngSmooth - (HUB.MedGrindBreakAt or 14)) * dt * 0.12
			end
		end
		nLastAng = nAng
		pnl._snd:Tick(bHeld and nAngSmooth >= (HUB.MedGrindMinSpeed or 2) * 0.6)
		if nCasse >= 1 then
			notification.AddLegacy("Trop brusque : la poudre est bonne à refaire. Rien de perdu, recommence.", NOTIFY_HINT, 3)
			surface.PlaySound(CFG.Sounds.sampleFail or "")
			pnl:Finish(false)
			return
		end
		if nProgress >= nGoal then pnl:Finish(true) return end

		local prog = math.min(1, nProgress / nGoal)
		if IsValid(tMdls.mortier) then
			tMdls.mortier:SetPos(vector_origin)
			tMdls.mortier:SetAngles(angle_zero)
		end
		local nSize = gs(460)
		cam.Start3D(Vector(26, 0, 30), Angle(38, 180, 0), 34, cx - nSize / 2, cy - nSize / 2, nSize, nSize)
			render.SuppressEngineLighting(true)
			if IsValid(tMdls.mortier) then tMdls.mortier:DrawModel() end
			-- Une dose = un modèle, en ANNEAUX (mêmes règles que le mortier médical).
			local nBase = #tIng > 8 and 0.28 or 0.38
			for i = 1, #tIng do
				local m = tMdls[i]
				local sc = nBase * (1 - prog)
				if IsValid(m) and sc > 0.03 then
					local a = now * 0.9 + i * 2.4
					local r = 1.2 + (i % 3) * 0.9
					m:SetPos(Vector(math.cos(a) * r, math.sin(a) * r, 4.2 + (i % 2) * 0.9 - prog * 1.6))
					m:SetAngles(Angle(0, math.deg(a) + now * 40, 0))
					m:SetModelScale(sc, 0)
					m:DrawModel()
				end
			end
			render.SuppressEngineLighting(false)
		cam.End3D()

		if IsValid(tMdls.pilon) then
			tMdls.pilon:SetPos(vector_origin)
			tMdls.pilon:SetAngles(Angle(bHeld and math.sin(RealTime() * 9) * 7 or 0, math.deg(-nAng), 0))
			local pw = gs(240)
			cam.Start3D(Vector(30, 0, 8), Angle(6, 180, 0), 30,
				mx - pw / 2, my - pw / 2 - (bHeld and 0 or gs(16)), pw, pw)
				render.SuppressEngineLighting(true)
				tMdls.pilon:DrawModel()
				render.SuppressEngineLighting(false)
			cam.End3D()
		end

		local sTempo = nAngSmooth < (HUB.MedGrindMinSpeed or 2) and "PLUS VITE…"
			or (nAngSmooth > (HUB.MedGrindMaxSpeed or 9) and "TROP VITE !" or "BON RYTHME")
		draw.SimpleText(sTempo, "EVOSci_H", cx, h - gs(250),
			sTempo == "BON RYTHME" and COL_G_OK or (sTempo == "TROP VITE !" and COL_G_BAD or COL_G_MUT),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		drawGBar(cx - gs(280), h - gs(196), gs(560), "BROYAGE", prog, COL_G_ACC)
		drawGBar(cx - gs(280), h - gs(140), gs(560), "CASSE (geste trop brusque)", nCasse, COL_G_BAD)
	end
end

-- ── 2. MÉLANGE : agitation constante à l'erlenmeyer (tube = agitateur) ───────
local function openPotionStir(fDone)
	local tMdls = {}
	tMdls.erlen = ClientsideModel(medDecorModel("med_erlenmeyer") or "", RENDERGROUP_OPAQUE)
	tMdls.tube = ClientsideModel(medDecorModel("med_tube_essai") or "", RENDERGROUP_OPAQUE)
	for _, m in pairs(tMdls) do
		if IsValid(m) then m:SetNoDraw(true) end
	end

	local ov = potionOverlay("INCORPORER LA POUDRE",
		"Maintiens le CLIC GAUCHE et agite en CERCLES, sans jamais t'interrompre.", tMdls, fDone)
	ov._snd = actionLoop(CFG.Sounds.medMixing or "")

	local nGoal = (HUB.PotionStirTurns or 4) * math.pi * 2
	local nProgress = 0
	local nLastAng, nLastT, nAngSmooth = nil, RealTime(), 0

	ov.Paint = function(pnl, w, h)
		pnl:PaintHead(w)
		local cx, cy = w * 0.5, h * 0.5
		local mx, my = pnl:CursorPos()
		local nAng = math.atan2(my - cy, mx - cx)
		local now = RealTime()
		local dt = math.max(0.001, now - nLastT)
		nLastT = now

		local bHeld = input.IsMouseDown(MOUSE_LEFT)
		local bStirring = false
		if nLastAng and bHeld then
			local d = math.abs(math.NormalizeAngle(math.deg(nAng - nLastAng)))
			local nSpeed = math.rad(d) / dt
			nAngSmooth = nAngSmooth + (nSpeed - nAngSmooth) * math.min(1, dt * 8)
			if nAngSmooth >= 1.5 then
				nProgress = nProgress + math.rad(d)
				bStirring = true
			end
		end
		nLastAng = nAng
		-- « Ne jamais interrompre » : la solution retombe dès que le geste cesse.
		if not bStirring then nProgress = math.max(0, nProgress - math.rad(50) * dt) end
		pnl._snd:Tick(bStirring)
		if nProgress >= nGoal then pnl:Finish(true) return end

		local prog = math.min(1, nProgress / nGoal)
		-- L'erlenmeyer TOURNE doucement avec l'agitation, le liquide (calque 2D,
		-- un niveau ne se truque pas dans un mesh) monte avec le progrès.
		local nSize = gs(440)
		if IsValid(tMdls.erlen) then
			tMdls.erlen:SetPos(vector_origin)
			tMdls.erlen:SetAngles(Angle(0, now * (bStirring and 90 or 12), 0))
		end
		cam.Start3D(Vector(30, 0, 10), Angle(12, 180, 0), 30, cx - nSize / 2, cy - nSize / 2, nSize, nSize)
			render.SuppressEngineLighting(true)
			if IsValid(tMdls.erlen) then tMdls.erlen:DrawModel() end
			render.SuppressEngineLighting(false)
		cam.End3D()
		-- Calque liquide : bande qui monte dans le tiers bas du viewport.
		local liqMaxH = nSize * 0.34
		local liqH = math.floor(liqMaxH * (0.25 + 0.75 * prog))
		draw.RoundedBox(gs(10), cx - nSize * 0.18, cy + nSize * 0.36 - liqH,
			math.floor(nSize * 0.36), liqH, COL_G_LIQ)

		-- Le TUBE À ESSAI suit la souris : c'est lui l'agitateur.
		if IsValid(tMdls.tube) then
			tMdls.tube:SetPos(vector_origin)
			tMdls.tube:SetAngles(Angle(bHeld and 24 or 8, math.deg(-nAng), 0))
			local pw = gs(200)
			cam.Start3D(Vector(24, 0, 5), Angle(4, 180, 0), 26, mx - pw / 2, my - pw / 2, pw, pw)
				render.SuppressEngineLighting(true)
				tMdls.tube:DrawModel()
				render.SuppressEngineLighting(false)
			cam.End3D()
		end

		draw.SimpleText(bStirring and "AGITATION CONSTANTE" or "LA SOLUTION RETOMBE…", "EVOSci_H",
			cx, h - gs(250), bStirring and COL_G_OK or COL_G_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		drawGBar(cx - gs(280), h - gs(196), gs(560), "INCORPORATION", prog, COL_G_ACC)
	end
end

-- ── 3. SYNTHÈSE : gouttes de pipette dans la bande, la mousse retombe ────────
local function openPotionSynth(fDone)
	local tMdls = {}
	tMdls.tube = ClientsideModel(medDecorModel("med_tube_essai") or "", RENDERGROUP_OPAQUE)
	tMdls.pipette = ClientsideModel(medDecorModel("med_pipette") or "", RENDERGROUP_OPAQUE)
	for _, m in pairs(tMdls) do
		if IsValid(m) then m:SetNoDraw(true) end
	end

	local nDropsGoal = HUB.PotionSynthDrops or 3
	local ov = potionOverlay("STABILISER LA SYNTHÈSE",
		"CLIC GAUCHE quand le repère traverse la bande : " .. nDropsGoal .. " gouttes de réactif, ni plus ni moins.",
		tMdls, fDone)

	local nDrops, nFoam = 0, 0
	local nBandC = 0.5
	local nDoneAt -- posée quand toutes les gouttes sont tombées (la mousse retombe)

	ov.OnMousePressed = function(pnl, code)
		if code ~= MOUSE_LEFT or nDoneAt then return end
		local now = RealTime()
		local nMark = 0.5 + 0.5 * math.sin(now * 1.7)
		if math.abs(nMark - nBandC) <= 0.09 then
			nDrops = nDrops + 1
			nFoam = math.max(0, nFoam - 0.2)
			surface.PlaySound(CFG.Sounds.click or "")
			nBandC = 0.18 + math.random() * 0.64
			if nDrops >= nDropsGoal then nDoneAt = now + 0.9 end
		else
			nFoam = math.min(1, nFoam + 0.34)
			surface.PlaySound(CFG.Sounds.sampleFail or "")
		end
	end

	ov.Paint = function(pnl, w, h)
		pnl:PaintHead(w)
		local cx, cy = w * 0.5, h * 0.5
		local mx, my = pnl:CursorPos()
		local now = RealTime()
		if nDoneAt and now >= nDoneAt then pnl:Finish(true) return end

		-- Tube à essai au centre : la mousse (calque 2D) gonfle avec les ratés
		-- et RETOMBE une fois les gouttes posées — « la potion est stable ».
		local nSize = gs(420)
		if IsValid(tMdls.tube) then
			tMdls.tube:SetPos(vector_origin)
			tMdls.tube:SetAngles(Angle(0, now * 14, 0))
		end
		cam.Start3D(Vector(22, 0, 6), Angle(6, 180, 0), 26, cx - nSize / 2, cy - nSize / 2, nSize, nSize)
			render.SuppressEngineLighting(true)
			if IsValid(tMdls.tube) then tMdls.tube:DrawModel() end
			render.SuppressEngineLighting(false)
		cam.End3D()
		local nFoamShow = nDoneAt and math.max(0, (nDoneAt - now) / 0.9) or (0.2 + nFoam * 0.8)
		local foamH = math.floor(nSize * 0.22 * nFoamShow)
		if foamH > 2 then
			draw.RoundedBox(gs(8), cx - nSize * 0.12, cy - nSize * 0.1 - foamH,
				math.floor(nSize * 0.24), foamH, Color(235, 235, 240, 140))
		end

		-- Jauge verticale : repère oscillant + bande cible.
		local gx, gy, gw, gh = cx + nSize / 2 + gs(70), cy - gs(180), gs(26), gs(360)
		draw.RoundedBox(gs(10), gx, gy, gw, gh, COL_G_SUB)
		local bandH = math.floor(gh * 0.18)
		local bandY = gy + math.floor(gh * math.Clamp(nBandC - 0.09, 0, 1))
		draw.RoundedBox(gs(6), gx, bandY, gw, bandH, Color(96, 220, 130, 130))
		local nMark = 0.5 + 0.5 * math.sin(now * 1.7)
		surface.SetDrawColor(COL_G_TITLE)
		surface.DrawRect(gx - gs(6), gy + math.floor(gh * nMark) - gs(2), gw + gs(12), gs(4))

		-- La PIPETTE suit la souris.
		if IsValid(tMdls.pipette) then
			tMdls.pipette:SetPos(vector_origin)
			tMdls.pipette:SetAngles(Angle(18, math.deg(-math.atan2(my - cy, mx - cx)), 0))
			local pw = gs(190)
			cam.Start3D(Vector(20, 0, 4), Angle(4, 180, 0), 24, mx - pw / 2, my - pw / 2, pw, pw)
				render.SuppressEngineLighting(true)
				tMdls.pipette:DrawModel()
				render.SuppressEngineLighting(false)
			cam.End3D()
		end

		draw.SimpleText(nDoneAt and "LA MOUSSE RETOMBE…" or ("GOUTTES : " .. nDrops .. " / " .. nDropsGoal),
			"EVOSci_H", cx, h - gs(250), nDoneAt and COL_G_OK or COL_G_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		drawGBar(cx - gs(280), h - gs(196), gs(560), "MOUSSE (goutte hors bande)", nFoam, COL_G_BAD)
	end
end

local function sendPotionStep(tCombo, nStar, nQty)
	net.Start("EVO_Science::PotionStep")
	net.WriteUInt(#tCombo, 4)
	for _, e in ipairs(tCombo) do
		net.WriteString(e.itemId)
		net.WriteUInt(math.Clamp(e.n, 1, HUB.ComboMaxPerType), 2)
	end
	-- Le niveau d'etoiles (puis le LOT, craft en serie) n'accompagnent que les
	-- VRAIS depots (melange non vide) — meme ordre que la lecture serveur.
	if #tCombo > 0 then
		net.WriteUInt(math.Clamp(nStar or 1, 1, 3), 2)
		net.WriteUInt(math.Clamp(math.floor(tonumber(nQty) or 1), 1, math.min(HUB.PotionMaxBatch or 10, 15)), 4) -- 4 bits : 15 max
	end
	net.SendToServer()
end

local function buildPotions(content, ctx)
	local s, col, mkBtn, styleScroll = ctx.s, ctx.col, ctx.mkBtn, ctx.styleScroll
	local cw, chh = content:GetSize()
	if #HUB.PotionRecipes == 0 then return end

	-- Snapshot des comptes du sac (UNITES, piles comprises) : UNE passe par
	-- rebuild. ForEachBagSlot lit le cache LIVE — GetInventory() est une copie.
	local bagCounts = {}
	local bagSlots = {}
	do
		local lp = LocalPlayer()
		if IsValid(lp) and lp.ForEachBagSlot then
			lp:ForEachBagSlot(function(slot, id, q)
				bagCounts[id] = (bagCounts[id] or 0) + q
				if EVO_SCIENCE.IngredientKind(id) then
					bagSlots[#bagSlots + 1] = { slot = slot, id = id, q = q }
				end
			end)
		elseif IsValid(lp) then
			local items = lp:GetInventory().items
			for slotIdx = 1, (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80 do
				local id = items[slotIdx]
				if isstring(id) and id ~= "" then
					bagCounts[id] = (bagCounts[id] or 0) + 1
					if EVO_SCIENCE.IngredientKind(id) then
						bagSlots[#bagSlots + 1] = { slot = slotIdx, id = id, q = 1 }
					end
				end
			end
		end
	end
	local function haveAllFor(r)
		for itemId, n in pairs(r.tIngredients) do
			if (bagCounts[itemId] or 0) < n then return false end
		end
		return true
	end

	local bCrafting = (POTION.st or 0) > 0
	local bHere = POTION.here ~= false -- ma synthese tourne-t-elle sur CE poste ?
	local bBusy = not bCrafting and istable(POTION.busy) -- poste pris par un autre

	local function canAcceptNewType(itemId)
		if comboFind(itemId) then return true end
		local kind = EVO_SCIENCE.IngredientKind(itemId)
		if not kind then return false end
		-- 4 genres comptés CHACUN de son côté (avant : tout le reste tombait dans les cristaux).
		local nMush, nPlant, nCry, nRes = 0, 0, 0, 0
		for _, e2 in ipairs(COMBO) do
			local k2 = EVO_SCIENCE.IngredientKind(e2.itemId)
			if k2 == "mush" then nMush = nMush + 1
			elseif k2 == "plant" then nPlant = nPlant + 1
			elseif k2 == "res" then nRes = nRes + 1
			else nCry = nCry + 1 end
		end
		if kind == "mush" and nMush >= HUB.ComboMaxMushTypes then return false end
		if kind == "plant" and nPlant >= (HUB.ComboMaxPlantTypes or 3) then return false end
		if kind == "crystal" and nCry >= HUB.ComboMaxCrystalTypes then return false end
		if kind == "res" and nRes >= (HUB.ComboMaxResTypes or 4) then return false end
		if #COMBO >= (HUB.ComboMaxMushTypes + HUB.ComboMaxCrystalTypes) then return false end
		return true
	end

	local function comboQty(itemId)
		local _, ex = comboFind(itemId)
		return (ex and ex.n) or 0
	end

	-- Combien de cette PILE peut encore entrer (reste dans la pile + cap recette).
	local function maxAddFrom(itemId, slotIdx, slotQty)
		local nHave = bagCounts[itemId] or 0
		local nIn = comboQty(itemId)
		local nRoom = math.min(HUB.ComboMaxPerType - nIn, nHave - nIn)
		local nLeft = math.max(0, math.floor(tonumber(slotQty) or 0) - comboTakenOf(slotIdx))
		return math.max(0, math.min(nLeft, nRoom))
	end

	-- Dépose nAdd unites d'un type dans le synthétiseur (fusion par item_id).
	-- slotIdx : pile du sac d'où viennent les unites (pour pouvoir en reprendre).
	local function addToCombo(itemId, nAdd, slotIdx)
		if bCrafting or bBusy then return end
		nAdd = math.floor(tonumber(nAdd) or 0)
		if nAdd < 1 then return end
		if not EVO_SCIENCE.IngredientKind(itemId) then return end
		local nBefore = comboQty(itemId)
		local _, ex = comboFind(itemId)
		if ex then
			local nNew = math.min(HUB.ComboMaxPerType, bagCounts[itemId] or 0, ex.n + nAdd)
			if nNew == ex.n then return end
			ex.n = nNew
		else
			if not canAcceptNewType(itemId) then return end
			local n = math.min(HUB.ComboMaxPerType, bagCounts[itemId] or 0, nAdd)
			if n < 1 then return end
			COMBO[#COMBO + 1] = { itemId = itemId, n = n }
		end
		comboTakenAdd(slotIdx, itemId, comboQty(itemId) - nBefore)
		if ctx.snd then ctx.snd("pickup") end
		if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
	end

	-- Clic / drop d'une pile : popup de quantite (PromptQuantity auto-valide si max = 1).
	local function promptFromStack(itemId, slotIdx, slotQty)
		if bCrafting or bBusy then return end
		if not EVO_SCIENCE.IngredientKind(itemId) then return end
		if not canAcceptNewType(itemId) then
			if ctx.snd then ctx.snd("sampleFail") end
			return
		end
		local nMax = maxAddFrom(itemId, slotIdx, slotQty)
		if nMax < 1 then
			if ctx.snd then ctx.snd("sampleFail") end
			return
		end
		-- MakePopup pendant un DragWatch/MouseCapture = drag gelé + reclic à la fermeture.
		if dragndrop then
			local main = dragndrop.m_DraggingMain
			if dragndrop.StopDragging then dragndrop.StopDragging() end
			if IsValid(main) then main:MouseCapture(false) end
		end
		local sName = EVO_SCIENCE.ItemName(itemId)
		if INVENTORY_CONFIG and INVENTORY_CONFIG.PromptQuantity then
			INVENTORY_CONFIG.PromptQuantity("Quantité", sName, nMax, function(n)
				addToCombo(itemId, n, slotIdx)
			end, { default = nMax, confirm = "Déposer" })
		else
			addToCombo(itemId, nMax, slotIdx)
		end
	end

	-- Pose réelle sur un emplacement (pas un simple clic / drag raté).
	local bDropHandled = false

	local function busyLeft()
		if not istable(POTION.busy) then return 0 end
		return math.max(0, (POTION.busy.left or 0) - (CurTime() - (POTION.recv or 0)))
	end

	local recW = s(300)
	local machineW = s(620)
	local bagW = cw - recW - machineW - s(40)

	-- ── Registre (gauche) : SEULES les recettes debloquees sont lisibles ─────
	-- (noms masques sinon, comme le carnet). Clic sur une debloquee = le melange
	-- se remplit tout seul ; les proportions se lisent dans le carnet.
	local nDisc = 0
	for _, r in ipairs(HUB.PotionRecipes) do
		if recipeDiscovered(r.id) then nDisc = nDisc + 1 end
	end
	local recPanel = vgui.Create("DPanel", content)
	recPanel:SetPos(0, 0)
	recPanel:SetSize(recW, chh)
	recPanel.Paint = function(_, w, h)
		ctx.paintCutCard(w, h, Color(19, 19, 23, 250))
		draw.SimpleText("RECETTES (" .. nDisc .. "/" .. #HUB.PotionRecipes .. " validées)", "EVOSci_H", s(16), s(12), col.TXT)
	end
	local recList = vgui.Create("DScrollPanel", recPanel)
	recList:SetPos(s(10), s(44))
	recList:SetSize(recW - s(20), chh - s(54))
	recList.Paint = function() end
	styleScroll(recList)

	-- GROUPES PAR CATEGORIE (couleur = TYPE de potion, demande user 08/09) ; le
	-- palier n'est plus qu'un chiffre romain discret a droite de chaque ligne.
	-- Les recettes non debloquees vont dans « À DÉCOUVRIR » tout en bas (aucune
	-- fuite du type tant que la faction n'a pas reussi la synthese).
	local ROMAN = { "I", "II", "III", "IV" }
	local CAT_ORDER = { "tonique", "celerite", "fortifiant", "stimulant", "essence", "toxine", "remede", "protection", "prothese", "equipement" }

	local function catHeader(sLabel, cHead, n)
		local head = recList:Add("DPanel")
		head:Dock(TOP)
		head:DockMargin(0, s(8), s(6), s(2))
		head:SetTall(s(20))
		head:SetPaintBackground(false)
		head.Paint = function(_, w, h)
			draw.SimpleText(sLabel .. " (" .. n .. ")", "EVOSci_XS", 0, h / 2, cHead, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(cHead.r, cHead.g, cHead.b, 60)
			surface.DrawRect(0, h - 1, w, 1)
		end
	end

	for _, sCat in ipairs(CAT_ORDER) do
		local cat = HUB.PotionCategories[sCat]
		local t = {}
		for _, r in ipairs(HUB.PotionRecipes) do
			if r.sCat == sCat and recipeDiscovered(r.id) then t[#t + 1] = r end
		end
		if cat and #t > 0 then
			catHeader(string.upper(cat.sName), cat.cCol, #t)
			for _, r in ipairs(t) do
				local bOk = haveAllFor(r)
				local row = recList:Add("DButton")
				row:SetText("")
				row:SetCursor("hand")
				row:Dock(TOP)
				row:DockMargin(0, 0, s(6), s(3))
				row:SetTall(s(30))
				row.Paint = function(self, w, h)
					surface.SetDrawColor(self:IsHovered() and col.FIELD or col.CARD2)
					surface.DrawRect(0, 0, w, h)
					-- Pastille aux couleurs de la CATEGORIE (= teinte de la fiole).
					surface.SetDrawColor(cat.cCol)
					surface.DrawRect(s(8), h / 2 - s(4), s(8), s(8))
					draw.SimpleText(r.sName, "EVOSci_S", s(22), h / 2,
						self:IsHovered() and col.TXT or col.TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(ROMAN[r.nPalier] or "?", "EVOSci_XS", w - s(46), h / 2,
						col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					if bOk then
						draw.SimpleText("PRÊT", "EVOSci_XS", w - s(8), h / 2, col.OK, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
				end
				row.DoClick = function()
					if bCrafting or bBusy then return end
					comboFill(r)
					if ctx.snd then ctx.snd("click") end
					if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
				end
			end
		end
	end

	local locked = {}
	for nIdx, r in ipairs(HUB.PotionRecipes) do
		if not recipeDiscovered(r.id) then locked[#locked + 1] = nIdx end
	end
	if #locked > 0 then
		catHeader("À DÉCOUVRIR", col.TXT_DIM, #locked)
		for _, nIdx in ipairs(locked) do
			local row = recList:Add("DPanel")
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(3))
			row:SetTall(s(30))
			-- Indice : couleurs de cristaux de la recette (pastille + nom), figées ici.
			local sLabel = string.format("N°%02d — non débloquée", nIdx)
			local tHint = {}
			surface.SetFont("EVOSci_XS")
			for _, nColor in ipairs(recipeCrystalColors(HUB.PotionRecipes[nIdx])) do
				local c = HUB.CrystalColors[nColor]
				if c then
					tHint[#tHint + 1] = { name = c.name, col = hexColor(CRYSTAL_HEX[c.key]), tw = surface.GetTextSize(c.name) }
				end
			end
			row.Paint = function(_, w, h)
				surface.SetDrawColor(col.CARD2)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(sLabel, "EVOSci_XS", s(10), h / 2, Color(108, 108, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if #tHint == 0 then
					draw.SimpleText("?", "EVOSci_S", w - s(10), h / 2, col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					return
				end
				local x = w - s(10)
				for k = #tHint, 1, -1 do
					local hnt = tHint[k]
					draw.SimpleText(hnt.name, "EVOSci_XS", x, h / 2, col.TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					x = x - hnt.tw - s(4)
					surface.SetDrawColor(hnt.col)
					surface.DrawRect(x - s(8), h / 2 - s(4), s(8), s(8))
					x = x - s(8) - s(10)
				end
				draw.SimpleText("cristaux :", "EVOSci_XS", x, h / 2, Color(108, 108, 120), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- ── Machine (centre) : 6 emplacements de melange + 3 stations ────────────
	local machine = vgui.Create("DPanel", content)
	machine:SetPos(recW + s(20), 0)
	machine:SetSize(machineW, chh)
	local nSteps = #HUB.PotionSteps
	machine.Paint = function(_, w, h)
		ctx.paintCutCard(w, h, Color(19, 19, 23, 250))
		draw.SimpleText("SYNTHÉTISEUR", "EVOSci_H", s(16), s(12), col.TXT)
		if bCrafting then
			if POTION.r then
				local r = EVO_SCIENCE.PotionRecipeById(POTION.r)
				local cat = r and HUB.PotionCategories[r.sCat] or nil
				draw.SimpleText(r and r.sName or POTION.r, "EVOSci_B", s(16), s(38),
					(cat and cat.cCol) or col.SCI)
			else
				draw.SimpleText("EXPÉRIENCE EN COURS — résultat inconnu", "EVOSci_B", s(16), s(38), col.WARN)
			end
			if not bHere then
				local sPost = (POTION.post or "") ~= "" and POTION.post or "poste de lancement"
				draw.SimpleText("Ta synthèse tourne au " .. sPost
					.. " : retourne à ce poste pour la suivre.", "EVOSci_XS", s(16), s(64), col.ACCENT)
			end
		elseif bBusy then
			draw.SimpleText("POSTE OCCUPÉ", "EVOSci_B", s(16), s(38), col.ACCENT)
			draw.SimpleText(string.format("%s effectue une synthèse (étape %d/%d, %.0fs).",
				trunc(POTION.busy.n or "?", 20), POTION.busy.st or 1, nSteps, busyLeft()),
				"EVOSci_XS", s(16), s(64), col.TXT_DIM)
		end
		-- (Etat libre : AUCUN texte d'explication — les emplacements et le bouton
		-- d'action guident deja, demande user 08/09 "trop de details".)
	end

	-- Poll leger : progression / occupation du poste, sans rebuild si rien ne change.
	-- La progression du craft et la prise du poste par un autre membre ne
	-- produisent aucun evenement client -> il faut demander. Le panneau (et donc
	-- le poll) meurt avec l'onglet.
	machine.Think = function(self)
		if (self._nextPoll or 0) > CurTime() then return end
		self._nextPoll = CurTime() + 2
		-- netgate: stream -- poll VOLONTAIRE 2 s tant que l'onglet potions est ouvert
		net.Start("EVO_Science::PotionSync")
		net.SendToServer()
	end

	local maxSlots = HUB.ComboMaxMushTypes + HUB.ComboMaxCrystalTypes
	local slotSz = s(88)
	local slotY = s(84)
	if not bCrafting and not bBusy then
		-- Bouton VIDER en haut a droite de la machine.
		local clr = mkBtn(machine, "VIDER LE MÉLANGE", false, function()
			comboClear()
			if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
		end)
		clr:SetPos(machineW - s(16) - s(150), s(12))
		clr:SetSize(s(150), s(26))

		for i = 1, maxSlots do
			local e = COMBO[i]
			local it = e and ITEMS and ITEMS[e.itemId] or nil
			local sp = vgui.Create("DButton", machine)
			sp:SetText("")
			sp:SetCursor(e and "hand" or "arrow")
			sp:SetPos(s(16) + (i - 1) * (slotSz + s(10)), slotY)
			sp:SetSize(slotSz, slotSz)
			sp.Paint = function(self, w, h)
				surface.SetDrawColor(col.FIELD)
				surface.DrawRect(0, 0, w, h)
				local have = e and (bagCounts[e.itemId] or 0) or 0
				local cOut = Color(255, 255, 255, 20)
				if e then cOut = (have >= e.n) and col.OK or col.ACCENT
				elseif self._dragHover then cOut = col.ACCENT end
				surface.SetDrawColor(cOut)
				surface.DrawOutlinedRect(0, 0, w, h)
				surface.DrawOutlinedRect(1, 1, w - 2, h - 2)
				self._dragHover = false
				if not e then
					draw.SimpleText("Glisse ici", "EVOSci_XS", w / 2, h / 2, col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			sp.PaintOver = function(_, w, h)
				if not e then return end
				local have = bagCounts[e.itemId] or 0
				draw.SimpleText("x" .. e.n, "EVOSci_S", w - s(6), s(2), have >= e.n and col.OK or col.ACCENT,
					TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				draw.SimpleText(trunc(EVO_SCIENCE.ItemName(e.itemId), 13), "EVOSci_XS", w / 2, h - s(9),
					col.TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			-- Clic sur un emplacement rempli = retirer UN exemplaire.
			sp.DoClick = function()
				local idx, ex = comboFind(e and e.itemId or "")
				if not ex then return end
				comboTakenFree(ex.itemId, 1)
				ex.n = ex.n - 1
				if ex.n <= 0 then table.remove(COMBO, idx) end
				if ctx.snd then ctx.snd("click") end
				if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
			end
			if e then
				local host = vgui.Create("DPanel", sp)
				host:SetPos(s(12), s(14))
				host:SetSize(slotSz - s(24), slotSz - s(30))
				host:SetMouseInputEnabled(false)
				if LZY_INVENTORY_ITEM_PREVIEW and it and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
					LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(host, it, 30, nil, 1)
				end
			end
			-- Depose : popup de quantite puis fusion par item_id (contraintes
			-- locales via addToCombo, le serveur revalide tout au lancement).
			sp:Receiver(DROP_NAME, function(rcv, panels, bDoDrop)
				rcv._dragHover = not bDoDrop
				if not bDoDrop then return end
				local d = panels and panels[1]
				if not IsValid(d) or not isstring(d.itemId) then return end
				bDropHandled = true
				promptFromStack(d.itemId, d.slotIndex, d.slotQty or 1)
			end)
		end
	end

	-- Les 3 stations (Broyage / Melange / Synthese) + progression (la mienne, ou
	-- celle du joueur qui occupe le poste).
	local function stStage()
		if bCrafting then return POTION.st or 0 end
		if bBusy then return POTION.busy.st or 0 end
		return 0
	end
	local function stLeft()
		if bCrafting then return potionLeft() end
		if bBusy then return busyLeft() end
		return 0
	end
	local function stTotal()
		if bCrafting then return POTION.total or 1 end
		if bBusy then return POTION.busy.total or 1 end
		return 1
	end

	local stY = (bCrafting or bBusy) and s(96) or slotY + slotSz + s(20)
	local stW = math.floor((machineW - s(32) - s(20)) / 3)
	local stations = vgui.Create("DPanel", machine)
	stations:SetPos(s(16), stY)
	stations:SetSize(machineW - s(32), s(96))
	stations:SetPaintBackground(false)
	stations.Paint = function(_, w, h)
		for i, step in ipairs(HUB.PotionSteps) do
			local x = (i - 1) * (stW + s(10))
			local st = stStage()
			local bDone = st > i or (st == i and stLeft() <= 0)
			local bActive = st == i and stLeft() > 0
			surface.SetDrawColor(col.CARD2)
			surface.DrawRect(x, 0, stW, h)
			surface.SetDrawColor(bDone and col.OK or (bActive and col.ACCENT or Color(255, 255, 255, 18)))
			surface.DrawOutlinedRect(x, 0, stW, h)
			draw.SimpleText(i .. ". " .. (HUB.PotionStepLabel[step] or step), "EVOSci_S",
				x + stW / 2, s(20), bDone and col.OK or col.TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(string.format("%gs", HUB.PotionStepDuration[step] or 2), "EVOSci_XS",
				x + stW / 2, s(40), col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if bActive then
				local prog = 1 - math.Clamp(stLeft() / math.max(stTotal(), 0.01), 0, 1)
				surface.SetDrawColor(45, 45, 52)
				surface.DrawRect(x + s(10), h - s(24), stW - s(20), s(10))
				surface.SetDrawColor(col.ACCENT)
				surface.DrawRect(x + s(10), h - s(24), math.floor((stW - s(20)) * prog), s(10))
			elseif bDone and st == i then
				draw.SimpleText("TERMINÉ", "EVOSci_XS", x + stW / 2, h - s(19), col.OK, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			if i < #HUB.PotionSteps then
				draw.SimpleText(">", "EVOSci_B", x + stW + s(5), h / 2, col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- Selecteur de NIVEAU d'etoiles (user 08/10) : 1★ libre, 2★ = niveau
	-- scientifique 15, 3★ = 30 (SYNC.sci, le serveur revalide). Ingredients
	-- consommes x2/x3 — la bouteille vide reste 1.
	local sciLvl = (istable(SYNC.sci) and tonumber(SYNC.sci.lvl)) or 1
	if (HUB.PotionStars[POTION_STAR] and HUB.PotionStars[POTION_STAR].nSciLevel or 0) > sciLvl then
		POTION_STAR = 1 -- selection perimee (changement de perso...)
	end
	local starW = s(52)
	for i = 1, 3 do
		local nReq = HUB.PotionStars[i] and HUB.PotionStars[i].nSciLevel or 0
		local bOk = sciLvl >= nReq
		local sb = vgui.Create("DButton", machine)
		sb:SetText("")
		sb:SetCursor("hand")
		sb:SetPos(s(16) + (i - 1) * (starW + s(6)), stY + s(112))
		sb:SetSize(starW, s(44))
		sb:SetTooltip(bOk
			and string.format("Potion %s : effets ×%.2g, ingrédients ×%d", string.rep("★", i),
				HUB.PotionStars[i].nFxMult, HUB.PotionStars[i].nCostMult)
			or string.format("Niveau scientifique %d requis", nReq))
		sb.Paint = function(_, w, h)
			local bSel = POTION_STAR == i
			surface.SetDrawColor(bSel and col.ACCENT or col.CARD2)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(bSel and col.ACCENT or Color(255, 255, 255, 18))
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(string.rep("★", i), "EVOSci_S", w / 2, bOk and h / 2 or s(14),
				bSel and Color(255, 255, 255) or (bOk and col.TXT or col.TXT_DIM),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if not bOk then
				draw.SimpleText("niv " .. nReq, "EVOSci_XS", w / 2, h - s(12),
					col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		sb.DoClick = function()
			if not bOk then return end
			POTION_STAR = i
		end
	end

	-- LOT (craft en serie, user 09/15) : [−] ×N [+] [MAX] a droite des etoiles.
	-- Ingredients et bouteilles x N, un seul cycle broyage/melange/synthese.
	local nMaxBatch = math.min(HUB.PotionMaxBatch or 10, 15) -- 4 bits sur le net
	POTION_QTY = math.Clamp(math.floor(tonumber(POTION_QTY) or 1), 1, nMaxBatch)
	local function starMult()
		return (HUB.PotionStars[POTION_STAR] and HUB.PotionStars[POTION_STAR].nCostMult) or 1
	end
	local function maxBatchFor()
		if #COMBO == 0 then return 1 end
		local nMult = starMult()
		local nMax = nMaxBatch
		for _, e in ipairs(COMBO) do
			nMax = math.min(nMax, math.floor((bagCounts[e.itemId] or 0) / math.max(1, (e.n or 1) * nMult)))
		end
		nMax = math.min(nMax, bagCounts["bouteille_vide"] or 0)
		return math.max(1, nMax)
	end
	local qtyW, qtyGap = s(150), s(4)
	local qx0 = s(16) + 3 * (starW + s(6))
	local function qtyBtn(x, bw, sTxt, sFont, fn)
		local b = vgui.Create("DButton", machine)
		b:SetText("")
		b:SetCursor("hand")
		b:SetPos(x, stY + s(112))
		b:SetSize(bw, s(44))
		b.Paint = function(self, bw2, bh)
			surface.SetDrawColor(self:IsHovered() and col.ACCENT or col.CARD2)
			surface.DrawRect(0, 0, bw2, bh)
			surface.SetDrawColor(Color(255, 255, 255, 18))
			surface.DrawOutlinedRect(0, 0, bw2, bh)
			draw.SimpleText(sTxt, sFont, bw2 / 2, bh / 2, col.TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
		return b
	end
	qtyBtn(qx0, s(30), "−", "EVOSci_B", function() POTION_QTY = math.max(1, POTION_QTY - 1) end)
	local qLbl = vgui.Create("DPanel", machine)
	qLbl:SetPos(qx0 + s(30) + qtyGap, stY + s(112))
	qLbl:SetSize(s(46), s(44))
	qLbl:SetTooltip("Potions fabriquées par synthèse (ingrédients et bouteilles multipliés)")
	qLbl.Paint = function(_, bw, bh)
		surface.SetDrawColor(col.CARD2)
		surface.DrawRect(0, 0, bw, bh)
		surface.SetDrawColor(POTION_QTY > 1 and col.ACCENT or Color(255, 255, 255, 18))
		surface.DrawOutlinedRect(0, 0, bw, bh)
		draw.SimpleText("×" .. POTION_QTY, "EVOSci_B", bw / 2, bh / 2, col.TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	qtyBtn(qx0 + s(30) + qtyGap + s(46) + qtyGap, s(30), "+", "EVOSci_B", function()
		POTION_QTY = math.min(nMaxBatch, POTION_QTY + 1)
	end)
	qtyBtn(qx0 + s(30) + qtyGap + s(46) + qtyGap + s(30) + qtyGap, s(32), "MAX", "EVOSci_XS", function()
		POTION_QTY = maxBatchFor()
	end)

	-- Bouton d'action unique (l'etat serveur decide du libelle). Chaque étape
	-- passe d'abord par son GESTE (mini-jeu, user 08/19) : le net ne part qu'à
	-- la réussite — fermer/rater ne lance rien et ne coûte rien.
	local nStarsW = 3 * (starW + s(6)) + qtyW + s(6)
	local act = mkBtn(machine, "", true, function()
		local st = POTION.st or 0
		if st == 0 then
			if #COMBO == 0 then return end
			-- Une copie PAR DOSE (user 08/20) : tout le dépôt se voit dans le bol.
			local tIng = {}
			for _, e in ipairs(COMBO) do
				local it = ITEMS and ITEMS[e.itemId]
				if it and it.model_path then
					for _ = 1, e.n or 1 do
						if #tIng >= 20 then break end
						tIng[#tIng + 1] = { mdl = it.model_path, skin = tonumber(it.skin) or 0 }
					end
				end
			end
			local tSend, nStar, nQty = COMBO, POTION_STAR, POTION_QTY
			openPotionGrind(tIng, function() sendPotionStep(tSend, nStar, nQty) end)
		elseif st < #HUB.PotionSteps and potionLeft() <= 0 then
			if HUB.PotionSteps[st + 1] == "melange" then
				openPotionStir(function() sendPotionStep({}) end)
			else
				openPotionSynth(function() sendPotionStep({}) end)
			end
		else
			sendPotionStep({}) -- recuperation / resync
		end
	end)
	act:SetPos(s(16) + nStarsW, stY + s(112))
	act:SetSize(machineW - s(32) - nStarsW, s(44))
	act.Think = function(self)
		if (self._next or 0) > CurTime() then return end
		self._next = CurTime() + 0.2
		local st = POTION.st or 0
		if bBusy then
			self:SetLabel("POSTE OCCUPÉ — SYNTHÈSE D'UN AUTRE MEMBRE")
			self:SetEnabled(false)
		elseif st == 0 then
			if #COMBO == 0 then
				self:SetLabel("DÉPOSE DES INGRÉDIENTS DANS LE SYNTHÉTISEUR")
				self:SetEnabled(false)
			else
				-- Couverture du LOT : ingredients x etoile x N, et N bouteilles vides.
				local okAll, sMiss = true, "INGRÉDIENTS MANQUANTS"
				local nMult = starMult()
				for _, e in ipairs(COMBO) do
					if (bagCounts[e.itemId] or 0) < (e.n or 1) * nMult * POTION_QTY then okAll = false break end
				end
				if okAll and (bagCounts["bouteille_vide"] or 0) < POTION_QTY then
					okAll, sMiss = false, (POTION_QTY > 1 and "BOUTEILLES VIDES MANQUANTES" or "BOUTEILLE VIDE MANQUANTE")
				end
				self:SetLabel(okAll and ("LANCER LA SYNTHÈSE" .. (POTION_QTY > 1 and (" ×" .. POTION_QTY) or "")) or sMiss)
				self:SetEnabled(okAll)
			end
		elseif not bHere then
			local sPost = (POTION.post or "") ~= "" and POTION.post or "poste de lancement"
			self:SetLabel("SYNTHÈSE EN COURS AU " .. string.upper(sPost))
			self:SetEnabled(false)
		elseif potionLeft() > 0 then
			self:SetLabel(string.format("%s EN COURS... (%.1fs)",
				string.upper(HUB.PotionStepLabel[HUB.PotionSteps[st]] or ""), potionLeft()))
			self:SetEnabled(false)
		elseif st < #HUB.PotionSteps then
			self:SetLabel("LANCER : " .. string.upper(HUB.PotionStepLabel[HUB.PotionSteps[st + 1]] or ""))
			self:SetEnabled(true)
		else
			local nLot = tonumber(POTION.qty) or 1
			self:SetLabel(POTION.exp and ("RÉCUPÉRER LE RÉSULTAT…" .. (nLot > 1 and (" ×" .. nLot) or ""))
				or (nLot > 1 and ("RÉCUPÉRER LES POTIONS ×" .. nLot) or "RÉCUPÉRER LA POTION"))
			self:SetEnabled(true)
		end
	end

	-- (Panneau REQUIS + textes d'aide RETIRES — demande user 08/09 : les
	-- proportions se lisent dans le carnet, l'UI se suffit a elle-meme.)

	-- ── Sac (droite) : UNIQUEMENT champignons + cristaux (demande user 08/09) ─
	local bag = vgui.Create("DPanel", content)
	bag:SetPos(recW + machineW + s(40), 0)
	bag:SetSize(bagW, chh)
	bag.Paint = function(_, w, h)
		ctx.paintCutCard(w, h, Color(19, 19, 23, 250))
		draw.SimpleText("TON SAC (ingrédients)", "EVOSci_H", s(16), s(14), col.TXT)
	end

	local grid = vgui.Create("DScrollPanel", bag)
	grid:SetPos(s(16), s(48))
	grid:SetSize(bagW - s(32), chh - s(64))
	grid.Paint = function() end
	styleScroll(grid)

	local cell = s(84)
	local gap = s(10)
	local cols = math.max(1, math.floor((bagW - s(42)) / (cell + gap)))
	local rowPnl, inRow = nil, 0
	local shown = 0
	for _, slotInfo in ipairs(bagSlots) do
		local itemId, slotIdx, slotQty = slotInfo.id, slotInfo.slot, slotInfo.q
		local it = ITEMS and ITEMS[itemId]
		shown = shown + 1
		if not rowPnl or inRow >= cols then
			rowPnl = grid:Add("DPanel")
			rowPnl:Dock(TOP)
			rowPnl:DockMargin(0, 0, 0, gap)
			rowPnl:SetTall(cell)
			rowPnl:SetPaintBackground(false)
			inRow = 0
		end
		local slotBg = vgui.Create("DPanel", rowPnl)
		slotBg:SetPos(inRow * (cell + gap), 0)
		slotBg:SetSize(cell, cell)
		-- Surlignage : l'ingredient est deja dans le melange. Grise seulement
		-- si CETTE pile ne peut plus rien ajouter (cap ou type refuse).
		local nLeft = math.max(0, slotQty - comboTakenOf(slotIdx))
		local bIngredient = comboFind(itemId) ~= nil
		local bBlocked = maxAddFrom(itemId, slotIdx, slotQty) < 1 or not canAcceptNewType(itemId)
		slotBg.Paint = function(_, w, h)
			surface.SetDrawColor(col.CARD2)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(bIngredient and col.SCI.r or 255, bIngredient and col.SCI.g or 255,
				bIngredient and col.SCI.b or 255, bIngredient and 140 or 16)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		-- Cellule draggable (pattern forge : Droppable + champs itemId/slotIndex).
		local c = vgui.Create("DPanel", slotBg)
		c:SetPos(s(4), s(4))
		c:SetSize(cell - s(8), cell - s(8))
		c:SetPaintBackground(false)
		c.itemId = itemId
		c.slotIndex = slotIdx
		c.slotQty = slotQty
		c:Droppable(DROP_NAME)
		-- CLIC = dépose. Un drag qui RATE l'emplacement doit aussi ouvrir le
		-- popup (sinon le 2e clic sur la même pile est avalé comme un drag).
		c:SetCursor(bBlocked and "arrow" or "hand")
		c.OnMousePressed = function(self, mc)
			if mc == MOUSE_LEFT then self:DragMousePress(mc) end
		end
		c.OnMouseReleased = function(self, mc)
			if mc ~= MOUSE_LEFT then return end
			bDropHandled = false
			self:DragMouseRelease(mc)
			if bDropHandled then return end
			promptFromStack(itemId, slotIdx, slotQty)
		end
		if LZY_INVENTORY_ITEM_PREVIEW and it and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(c, it, 30, nil, 1)
		elseif it and it.icon then
			c.Paint = function(_, w, h)
				local mat = Material(it.icon, "smooth")
				if mat and not mat:IsError() then
					surface.SetDrawColor(255, 255, 255, 255)
					surface.SetMaterial(mat)
					surface.DrawTexturedRect(0, 0, w, h)
				end
			end
		end
		-- xN = reste dans CETTE pile (pas encore déposé dans le mélange).
		local qtyOv = vgui.Create("DPanel", slotBg)
		qtyOv:SetPos(0, 0)
		qtyOv:SetSize(cell, cell)
		qtyOv:SetMouseInputEnabled(false)
		qtyOv:SetPaintBackground(false)
		qtyOv:SetZPos(100)
		qtyOv.Paint = function(_, w, h)
			if bBlocked then
				surface.SetDrawColor(0, 0, 0, 110)
				surface.DrawRect(0, 0, w, h)
			end
			draw.SimpleText("x" .. nLeft, "EVOSci_S", w - s(6), s(2),
				bBlocked and col.TXT_DIM or col.TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
		inRow = inRow + 1
	end
	if shown == 0 then
		local empty = grid:Add("DPanel")
		empty:Dock(TOP)
		empty:SetTall(s(70))
		empty:SetPaintBackground(false)
		empty.Paint = function(_, w, h)
			draw.SimpleText("Aucun ingrédient dans ton sac.", "EVOSci_S", w / 2, h / 2 - s(10), col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Récolte des champignons, chasse des cristaux.", "EVOSci_XS", w / 2, h / 2 + s(12), col.TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

-- ═══ NIVEAU : plus d'onglet dedie (user 08/19 « comme les autres divisions ») ═
-- Le niveau s'affiche dans l'EN-TÊTE de la fenêtre LABORATOIRE (cl_science),
-- comme le niveau d'atelier des autres divisions. Courbe centrale evo_craft.
function EVO_SCIENCE.SciLevelInfo()
	local sci = istable(SYNC.sci) and SYNC.sci or {}
	local nXP = tonumber(sci.xp) or 0
	local nMax = tonumber(sci.max) or 30
	if EVO_CRAFT and EVO_CRAFT.LevelFromXP then
		local nLvl, nIn, nNeed = EVO_CRAFT.LevelFromXP(nXP, "science")
		return nLvl, nIn, nNeed, nMax, tonumber(sci.today) or 0, tonumber(sci.cap) or 10
	end
	return tonumber(sci.lvl) or 1, 0, 0, nMax, tonumber(sci.today) or 0, tonumber(sci.cap) or 10
end

-- ══════════════════════════════════════════════════════════════════════════
-- Enregistrement des onglets (lus par EVO_OpenScienceLab)
-- ══════════════════════════════════════════════════════════════════════════
local function visLab()
	return myGrade() >= 1
end

local function visGestion()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:IsSuperAdmin() then return true end
	-- Rang labo MAX (5) : whitelist explicite ou grade faction 15 implicite.
	return myGrade() >= HUB.GradeCount
end

-- GESTION en DERNIER : tout a droite de la barre d'onglets (demande user 08/09).
EVO_SCIENCE.LabTabs = {
	{ id = "documents", label = "DOCUMENTS", fVisible = visLab,     fBuild = buildDocuments },
	{ id = "recettes",  label = "RECETTES",  fVisible = visLab,     fBuild = buildRecettes },
	{ id = "potions",   label = "POTIONS",   fVisible = visLab,     fBuild = buildPotions },
	{ id = "gestion",   label = "GESTION",   fVisible = visGestion, fBuild = buildGestion },
}

-- Le sac change pendant que l'onglet potions est ouvert (ingredients consommes,
-- potion livree) : rebuild pour rester fidele.
hook.Add("LZY_Inventory_Synced", "EVO_Science::HubBagRefresh", function()
	if EVO_SCIENCE._LabRebuild then EVO_SCIENCE._LabRebuild("potions") end
end)
