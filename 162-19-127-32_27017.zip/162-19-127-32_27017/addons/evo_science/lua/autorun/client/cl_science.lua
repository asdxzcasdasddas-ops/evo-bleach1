-- "addons\\evo_science\\lua\\autorun\\client\\cl_science.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Share the one-model-per-frame queue while preserving this menu's camera setup.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

-- ============================================================================
-- EVO SCIENCE — client (v2) : prompt [E] + ramassage FAÇON LARVE, UI LABORATOIRE
-- (besace + PAILLASSE d'analyses longues + bestiaire de FACTION) et MINI-JEU
-- d'échantillonnage "docteur Maboule" (au labo uniquement).
-- Sons = assets custom du serveur (CFG.Sounds), pas de sons GMod de base.
-- DA EVO : carte #0E0E11, accent #cf444e, Bebas Neue.
-- ============================================================================
if not CLIENT then return end

local CFG = EVO_SCIENCE.CFG

local ACCENT  = Color(207, 68, 78)
local CARD2   = Color(24, 24, 29)
local FIELD   = Color(32, 32, 38)
local TXT     = Color(236, 236, 240)
local TXT_DIM = Color(150, 150, 162)
local OK_COL  = Color(90, 200, 120)
local WARN    = Color(230, 180, 70)
local SCI     = Color(150, 225, 165) -- vert "échantillon"

local SC = math.Clamp(ScrH() / 1080, 0.9, 2.0)
local function s(n) return math.floor(n * SC + 0.5) end
local function fsz(n) return math.max(11, math.floor(n * SC + 0.5)) end

surface.CreateFont("EVOSci_Title", { font = "Bebas Neue", size = fsz(42), weight = 600 })
surface.CreateFont("EVOSci_Big",   { font = "Bebas Neue", size = fsz(54), weight = 600 })
surface.CreateFont("EVOSci_H",     { font = "Roboto", size = fsz(26), weight = 700 })
surface.CreateFont("EVOSci_B",     { font = "Roboto", size = fsz(21), weight = 600 })
surface.CreateFont("EVOSci_S",     { font = "Roboto", size = fsz(18), weight = 500 })
surface.CreateFont("EVOSci_XS",    { font = "Roboto", size = fsz(15), weight = 500 })

local function snd(name)
	local path = CFG.Sounds and CFG.Sounds[name]
	if path and path ~= "" then surface.PlaySound(path) end
end

-- ── État reçu du serveur ─────────────────────────────────────────────────────
local POUCH = {} -- { {class=, at=, left=, recv=CurTime()} }  (`at` = identité, cf. EVO_Science::Start)
local BEST  = {} -- bestiaire de MA faction : class -> niveau 0..3

-- Niveau AFFICHÉ dans le bestiaire (clé = classe ou "classe@n" pour une mutation) :
-- un SUPERADMIN voit tout au niveau max (vue d'administration, user 08/25). Les
-- stats de complétion (dossiers) et le bonus réel restent calculés sur BEST.
local function viewLevel(sKey)
	local lp = LocalPlayer()
	if IsValid(lp) and lp:IsSuperAdmin() then
		return (EVO_SCIENCE.MaxLevelFor and EVO_SCIENCE.MaxLevelFor(sKey)) or CFG.MaxLevel
	end
	return tonumber(BEST[sKey]) or 0
end
local JOBS  = {} -- analyses de MA faction : { {id,class,quality,starter,left,total,recv} }
local UI, content
local currentView = "lab"

local function slotLeft(c) return math.max(0, (c.left or 0) - (CurTime() - (c.recv or 0))) end
local function slotFresh(c) return math.Clamp(slotLeft(c) / CFG.RotSeconds, 0, 1) end
local function jobLeft(j) return math.max(0, (j.left or 0) - (CurTime() - (j.recv or 0))) end

-- L'analyse qui occupe le poste où je me trouve (nil = poste libre ou hors zone).
-- 1 analyse à la fois par poste : sert à griser ANALYSER + état du bandeau de zone.
local function myPostJob()
	local here = EVO_SCIENCE.ZoneIdFor(LocalPlayer())
	if not here then return nil end
	for _, j in ipairs(JOBS) do
		if (j.zone or "") ~= "" and j.zone == here then return j end
	end
	return nil
end

local function freshColor(f)
	if f > 0.5 then return OK_COL elseif f > 0.2 then return WARN end
	return ACCENT
end

local function fmtLeft(sec)
	sec = math.floor(sec)
	return string.format("%d:%02d", math.floor(sec / 60), sec % 60)
end

local function fmtDur(sec)
	sec = math.max(0, math.floor(sec))
	local h = math.floor(sec / 3600)
	local m = math.ceil((sec % 3600) / 60)
	if h > 0 then return h .. " h " .. (m > 0 and (m .. " min") or "") end
	return m .. " min"
end

-- Ligne "S'évapore dans ..." pour le tooltip de l'item carcasse dans l'inventaire
-- (les items miroir sont indistinguables -> on liste toutes les carcasses, la plus
-- pressée d'abord). nil si la besace est vide côté client.
function EVO_SCIENCE.PouchTooltipLine()
	if #POUCH == 0 then return nil end
	local times = {}
	for _, c in ipairs(POUCH) do times[#times + 1] = slotLeft(c) end
	table.sort(times)
	local parts = {}
	for _, t in ipairs(times) do
		parts[#parts + 1] = (t < 60) and "moins d'1 min" or (math.ceil(t / 60) .. " min")
	end
	if #parts == 1 then return "S'évapore dans " .. parts[1] end
	return "S'évapore dans : " .. table.concat(parts, " / ")
end

local function reqSync() net.Start("EVO_Science::ReqSync") net.SendToServer() end

local DOSS = {} -- stats des analyseurs (encadrement), reçues à la demande
local ShowBench, ShowBestiary, ShowDossiers -- fwd (poste d'analyse / bestiaire / dossiers)
net.Receive("EVO_Science::Sync", function()
	local t = util.JSONToTable(net.ReadString() or "") or {}
	POUCH, JOBS = {}, {}
	for i, c in ipairs(t.pouch or {}) do
		-- `at` DOIT être recopié : cette boucle reconstruit chaque entrée champ par
		-- champ au lieu de garder la table reçue. L'oublier laissait `at` à nil, donc
		-- le client renvoyait 0 comme pièce d'identité et le serveur refusait TOUTE
		-- analyse en annonçant « ta besace a changé », alors qu'elle n'avait pas bougé.
		POUCH[i] = { class = c.class, at = tonumber(c.at) or 0, left = tonumber(c.left) or 0, recv = CurTime(), mut = tonumber(c.mut) }
	end
	for i, j in ipairs(t.jobs or {}) do
		JOBS[i] = {
			id = j.id, class = j.class, quality = tonumber(j.quality) or 0, starter = j.starter or "",
			left = tonumber(j.left) or 0, total = tonumber(j.total) or 1, recv = CurTime(),
			zone = j.zone or "", -- poste où tourne l'analyse ("" = jobs d'avant, partout)
		}
	end
	BEST = t.best or {}
	if IsValid(UI) then
		if currentView == "lab" and ShowBench then ShowBench()
		elseif currentView == "bestiary" and ShowBestiary then ShowBestiary() end
	end
end)

net.Receive("EVO_Science::Notify", function()
	-- resync TOUJOURS (pas seulement UI ouverte) : l'affichage 3D au-dessus des
	-- postes d'analyse lit JOBS et doit rester à jour.
	reqSync()
end)

-- ── Petits helpers UI (DA) ───────────────────────────────────────────────────
-- Libellé MUTABLE via b._label + b:SetLabel(txt) : le Paint le relit à chaque
-- frame. NE JAMAIS utiliser b:SetText() ici — SetText("") museler le rendu texte
-- du moteur (DButton::Paint retourne false exprès pour le laisser dessiner) ;
-- lui repasser une chaîne non vide RALLUME ce rendu PAR-DESSUS notre libellé
-- (texte dédoublé) sans changer ce qui est peint.
local function mkBtn(parent, label, fill, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b._label = label
	b.SetLabel = function(self, txt) self._label = txt end
	b.Paint = function(self, w, h)
		local c = fill and ACCENT or CARD2
		if not self:IsEnabled() then c = Color(40, 40, 46)
		elseif self:IsHovered() then c = fill and Color(225, 86, 96) or FIELD end
		if fill and EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, c, s(7), "br")
		else
			surface.SetDrawColor(c) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, self:IsHovered() and 26 or 14) surface.DrawOutlinedRect(0, 0, w, h)
		end
		draw.SimpleText(self._label or "", "EVOSci_S", w / 2, h / 2, self:IsEnabled() and TXT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	if fn then b.DoClick = function() snd("click") fn() end end
	return b
end

-- Scrollbar DA : passe par le kit EVO_UI si dispo, sinon barre fine sombre + grip accent.
local function styleScroll(sp)
	if not IsValid(sp) then return end
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(sp) return end
	local vbar = sp:GetVBar()
	if not IsValid(vbar) then return end
	vbar:SetWide(s(8))
	vbar.Paint = function(_, w, h) surface.SetDrawColor(20, 20, 24, 200) surface.DrawRect(0, 0, w, h) end
	vbar.btnUp.Paint = function() end
	vbar.btnDown.Paint = function() end
	vbar.btnGrip.Paint = function(self, w, h)
		surface.SetDrawColor(self.Depressed and ACCENT or (self:IsHovered() and Color(225, 86, 96) or Color(95, 95, 105)))
		surface.DrawRect(s(2), 0, w - s(4), h)
	end
end

-- Carte DA à coins coupés + liseré (kit EVO_UI, fallback rect simple).
local function paintCutCard(w, h, col, cut)
	if EVO_UI and EVO_UI.PaintCut then
		local pts = EVO_UI.PaintCut(0, 0, w, h, col, cut or s(10))
		if pts and EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(255, 255, 255, 18)) end
	else
		surface.SetDrawColor(col) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
	end
end

-- Barre de connaissance : les étoiles ne tiennent plus depuis le passage à 100
-- analyses par espèce (08/26). Marque les paliers de révélation encore à venir.
local function drawKnowBar(x, y, w, h, n, max, col, tThresholds)
	local frac = math.Clamp((tonumber(n) or 0) / math.max(1, max), 0, 1)
	surface.SetDrawColor(45, 45, 52)
	surface.DrawRect(x, y, w, h)
	surface.SetDrawColor(col.r, col.g, col.b, 235)
	surface.DrawRect(x, y, w * frac, h)
	if tThresholds then
		local last = -99
		for _, need in ipairs(tThresholds) do
			local tx = x + w * (need / max)
			-- Seuils serrés (les 5 premières analyses sur 100) : un seul trait, sinon
			-- ils forment un pâté illisible au bord gauche de la barre.
			if need > 1 and need <= max and (tx - last) >= 4 then
				last = tx
				surface.SetDrawColor(255, 255, 255, need <= (n or 0) and 40 or 120)
				surface.DrawRect(tx - 1, y - 2, 2, h + 4)
			end
		end
	end
end

-- Prochain palier de révélation : nombre d'analyses restantes, ou nil si tout est révélé.
local function nextThreshold(sKey, n)
	for _, need in ipairs((EVO_SCIENCE.IntelThresholdsFor and EVO_SCIENCE.IntelThresholdsFor(sKey)) or {}) do
		if (n or 0) < need then return need end
	end
	return nil
end

local function pctTxt(frac)
	return (EVO_SCIENCE.FormatPct and EVO_SCIENCE.FormatPct(frac)) or tostring(math.floor((frac or 0) * 100))
end

local function drawStars(x, y, n, max, col, sz)
	for i = 1, max do
		draw.SimpleText(i <= n and "★" or "☆", "EVOSci_B", x + (i - 1) * s(sz or 20), y, i <= n and (col or WARN) or Color(90, 90, 100), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
end

-- DModelPanel plein-corps du PNJ (dissection / bestiaire).
local function mkNpcModel(parent, class, dark, nSkin)
	local info = EVO_SCIENCE.NpcInfo(class)
	local mp = vgui.Create("DModelPanel", parent)
	mp:SetFOV(34)
	mp.LayoutEntity = function(_, e) if IsValid(e) then e:FrameAdvance(RealFrameTime()) end end
	QueuePreviewModel(mp, function(mp)
		if isstring(info.model) and info.model ~= "" and util.IsValidModel(info.model) then
			mp:SetModel(info.model)
			local ent = mp:GetEntity()
			if IsValid(ent) then
				if dark then ent:SetColor(Color(120, 200, 140)) end
				if nSkin then ent:SetSkin(nSkin) end -- aperçu d'une mutation (skin du modèle)
				local mn, mx = ent:GetRenderBounds()
				if mn and mx then
					local c = (mn + mx) * 0.5
					local hgt = math.max(mx.z - mn.z, 16)
					mp:SetLookAt(c)
					mp:SetCamPos(c + Vector(hgt * 3.4, hgt * 0.35, hgt * 0.12)) -- caméra bien reculée (dézoom)
				end
			end
		end
	end)
	return mp
end

-- (mkCarcassModel retiré le 06/08 : il affichait CFG.CarcassModel, le MÊME prop pour
--  toutes les espèces. Depuis que les emplacements de besace sont choisis un par un,
--  les vignettes passent par mkNpcModel(class, dark) pour qu'on distingue les
--  spécimens. Fonction `local` sans autre appelant dans le fichier.)

-- Rendu des sections d'intel (bestiaire / rapport) selon le niveau connu.
-- ============================================================================
-- MUTATIONS (ncm_pnj, user 08/25) : fiches de connaissance À PART. Chaque forme mutée
-- a sa clé "classe@n" (EVO_SCIENCE.MutKey) et ses propres paliers (CFG.MutationMaxLevel),
-- gagnés UNIQUEMENT par l'analyse de carcasses MUTÉES, rares : une faction qui a tout
-- appris sur l'espèce repart de zéro sur ses mutations.
-- nOnly = une seule mutation (rapport d'analyse) ; nLevel = niveau imposé (rapport).
-- ============================================================================
local function buildMutationBlock(parent, class, nOnly, nLevel)
	local M = istable(NCM_PNJ) and NCM_PNJ.Mutations or nil
	if not (M and NCM_PNJ.CanMutate and NCM_PNJ.CanMutate(class)) then return end
	local info = EVO_SCIENCE.NpcInfo(class)
	local nMax = CFG.MutationMaxLevel or 3
	local TH   = CFG.MutationIntelThresholds or { 1, 2, 3 }

	local head = vgui.Create("DLabel", parent)
	head:Dock(TOP) head:DockMargin(0, s(14), 0, s(2))
	head:SetFont("EVOSci_B") head:SetTextColor(ACCENT)
	head:SetText(nOnly and "MUTATION ANALYSÉE" or "MUTATIONS") head:SizeToContents()

	if not nOnly then
		local l = vgui.Create("DLabel", parent)
		l:Dock(TOP) l:DockMargin(s(4), s(2), s(6), 0)
		l:SetFont("EVOSci_S") l:SetTextColor(TXT_DIM) l:SetWrap(true) l:SetAutoStretchVertical(true)
		l:SetText("Formes mutées de l'espèce (une naissance sur " .. math.max(1, math.Round(1 / math.max(M.Chance or 0.08, 0.001)))
			.. " environ). Connaissance SÉPARÉE de l'espèce : seules leurs carcasses, rares, la font progresser.")
	end

	for i, t in ipairs(M.Types) do
		if not nOnly or nOnly == i then
			local sKey = EVO_SCIENCE.MutKey and EVO_SCIENCE.MutKey(class, i) or (class .. "@" .. i)
			local lvl  = nLevel or viewLevel(sKey)
			local col  = t.col or TXT

			local sKnow = "Connaissance : " .. lvl .. " / " .. nMax -- figé (Paint à 60 fps)
			local card = vgui.Create("DPanel", parent)
			card:Dock(TOP) card:DockMargin(s(4), s(8), s(6), 0)
			card:SetTall(lvl > 0 and s(232) or s(54))
			card.Paint = function(_, w, h)
				paintCutCard(w, h, Color(18, 18, 22))
				surface.SetDrawColor(col.r, col.g, col.b, 150) surface.DrawRect(0, 0, s(3), h)
				draw.SimpleText(lvl > 0 and t.label or "MUTATION INCONNUE", "EVOSci_B", s(14), s(10), lvl > 0 and col or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(sKnow, "EVOSci_XS", w - s(14), s(10), TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				drawKnowBar(w - s(154), s(26), s(140), s(8), lvl, nMax, col, TH)
				if lvl <= 0 then
					draw.SimpleText("Analysez une carcasse de cette mutation pour l'identifier.", "EVOSci_XS", s(14), s(32), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
			end
			if lvl > 0 then
				local mp = mkNpcModel(card, class, false, NCM_PNJ.MutationSkin(class, i))
				mp:SetPos(s(10), s(36)) mp:SetSize(s(150), s(186))
				local lines = { t.desc }
				if lvl >= (TH[2] or 2) then
					lines[#lines + 1] = "Constitution ×" .. (M.HPMult or 3) .. " (" .. math.floor((info.hp or 0) * (M.HPMult or 3)) .. " PV)  ·  puissance ×"
						.. (M.DmgMult or 3) .. " (" .. math.floor((info.dmg or 0) * (M.DmgMult or 3)) .. ")."
				else
					lines[#lines + 1] = "Physiologie : encore " .. math.max(0, (TH[2] or 2) - lvl) .. " analyse(s) de cette mutation."
				end
				if lvl >= (TH[3] or 3) then
					lines[#lines + 1] = "Primes : expérience ×" .. (M.XPMult or 1.5) .. ", os ×" .. (M.DropMult or 1.5) .. ", +" .. (M.CrystalBonus or 1)
						.. " cristal ; carcasse rare (×" .. (M.CarcassMult or 0.5) .. "), analyse " .. math.floor((1 - (M.AnalysisSpeed or 1)) * 100) .. "% plus rapide."
					lines[#lines + 1] = "Bonus de faction contre cette forme : +"
						.. pctTxt(EVO_SCIENCE.CombatBonus(sKey, tonumber(BEST[sKey]) or 0)) .. "% de dégâts (maximum +"
						.. pctTxt((CFG.CombatBonusPerLevel or 0) * nMax) .. "%)."
				else
					lines[#lines + 1] = "Primes et bonus : encore " .. math.max(0, (TH[3] or 3) - lvl) .. " analyse(s) de cette mutation."
				end
				local tLabels = {}
				for _, line in ipairs(lines) do
					local l = vgui.Create("DLabel", card)
					l:SetFont("EVOSci_S") l:SetTextColor(TXT) l:SetWrap(true) l:SetAutoStretchVertical(true)
					l:SetText(line)
					tLabels[#tLabels + 1] = l
				end
				card.PerformLayout = function(_, w, h)
					local y = s(40)
					for _, l in ipairs(tLabels) do
						l:SetPos(s(170), y) l:SetWide(w - s(184))
						y = y + l:GetTall() + s(4)
					end
				end
			end
		end
	end
end

local function buildIntelSections(parent, class, level)
	local info  = EVO_SCIENCE.NpcInfo(class)
	local intel = EVO_SCIENCE.GetIntel(class)

	-- 5 paliers de connaissance, de plus en plus utiles en combat.
	local secrets = {
		"Faiblesse : " .. (intel.faiblesse or "?"),
		"Note de terrain : " .. (intel.secret or "?"),
	}
	-- Montant EXACT (socle plat + bonus boss/élite), plus une fourchette : l'XP de kill
	-- est déterministe depuis NCM_PNJ.GetKillXP, donc « estimée » n'a plus lieu d'être.
	if (info.xp or 0) > 0 then
		secrets[#secrets + 1] = "Prime d'expérience : " .. info.xp .. " XP"
	end
	secrets[#secrets + 1] = "Bonus de faction au maximum : +" .. pctTxt(CFG.CombatBonusPerLevel * CFG.MaxLevel)
		.. "% de dégâts contre ce spécimen (+" .. pctTxt(CFG.CombatBonusPerLevel) .. "% par analyse)"

	-- Paliers de révélation (CFG.IntelThresholds) : le nombre d'analyses qui ouvre
	-- chaque section. Une section de plus ici DOIT s'accompagner d'un seuil de plus.
	local TH = EVO_SCIENCE.IntelThresholdsFor(class)
	local SECTIONS = {
		{ lvl = TH[1] or 1, title = "PROFIL", lines = {
			intel.desc,
			"Classification : " .. (info.boss and "SPÉCIMEN MAJEUR (boss)" or ("Hollow de classe " .. info.tier .. " / 4")),
			intel.lore and ("Archives : " .. intel.lore) or nil,
		} },
		{ lvl = TH[2] or 2, title = "PHYSIOLOGIE", lines = {
			"Constitution : " .. info.hp .. " PV" .. ((info.regen or 0) > 0 and ("  ·  régénération " .. info.regen .. "/s") or ""),
			"Puissance d'attaque : " .. info.dmg,
			"Vitesse : " .. info.speed .. " en course" .. ((info.walk or 0) > 0 and ("  ·  " .. info.walk .. " en marche") or ""),
		} },
		{ lvl = TH[3] or 3, title = "COMPORTEMENT", lines = {
			"Patterns : " .. (intel.patterns or "?"),
		} },
		{ lvl = TH[4] or 4, title = "ANALYSE TACTIQUE", lines = {
			"Parade parfaite : " .. (intel.parade or "?"),
			"Esquive : " .. (intel.esquive or "?"),
		} },
		{ lvl = TH[5] or 5, title = "SECRETS DU SPÉCIMEN", lines = secrets },
	}
	for _, sec in ipairs(SECTIONS) do
		local unlocked = level >= sec.lvl
		local head = vgui.Create("DLabel", parent)
		head:Dock(TOP) head:DockMargin(0, s(12), 0, s(2))
		head:SetFont("EVOSci_B")
		head:SetTextColor(unlocked and ACCENT or Color(90, 90, 100))
		head:SetText(sec.title .. (unlocked and "" or ("   ·   " .. sec.lvl .. " analyse" .. (sec.lvl > 1 and "s" or "")))) -- pas d'icône cadenas (carré avec cette fonte)
		head:SizeToContents()
		if unlocked then
			for _, line in ipairs(sec.lines) do
				local l = vgui.Create("DLabel", parent)
				l:Dock(TOP) l:DockMargin(s(4), s(2), s(6), 0)
				l:SetFont("EVOSci_S")
				l:SetTextColor(TXT)
				l:SetWrap(true) l:SetAutoStretchVertical(true)
				l:SetText(line)
			end
		else
			local l = vgui.Create("DLabel", parent)
			l:Dock(TOP) l:DockMargin(s(4), s(2), s(6), 0)
			l:SetFont("EVOSci_S") l:SetTextColor(TXT_DIM)
			l:SetWrap(true) l:SetAutoStretchVertical(true) -- phrase plus longue qu'avant : sans wrap elle serait coupée
			l:SetText("Encore " .. math.max(0, sec.lvl - level) .. " analyse" .. ((sec.lvl - level) > 1 and "s" or "") .. " pour révéler cette section.")
		end
	end

	-- MUTATIONS : fiches de connaissance à part (clé "classe@n"), sous les sections.
	buildMutationBlock(parent, class)
end

-- ============================================================================
-- VUE LABO : besace + paillasse (gauche) | bestiaire (droite : liste + détail)
-- ============================================================================
local selectedClass

function ShowBench()
	if not IsValid(content) then return end
	currentView = "lab"
	content.PerformLayout = nil
	content:Clear()

	local inZone = EVO_SCIENCE.IsInLabZone(LocalPlayer())

	-- ── POSTE D'ANALYSE (fenêtre dédiée, légère) : recherche + besace + analyseur ──
	local left = vgui.Create("DPanel", content)
	left:Dock(FILL)
	left.Paint = function(_, w, h)
		surface.SetDrawColor(CARD2) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 12) surface.DrawOutlinedRect(0, 0, w, h)
	end

	local zoneBar = vgui.Create("DPanel", left)
	zoneBar:Dock(TOP) zoneBar:SetTall(s(36))
	zoneBar.Paint = function(_, w, h)
		local ok = EVO_SCIENCE.IsInLabZone(LocalPlayer())
		local busy = ok and myPostJob() or nil
		local col = (not ok and ACCENT) or (busy and WARN) or SCI
		surface.SetDrawColor(col.r, col.g, col.b, 24)
		surface.DrawRect(0, 0, w, h)
		local txt = (not ok and "● HORS ZONE — rejoins le laboratoire pour analyser")
			or (busy and (jobLeft(busy) <= 0 and "● POSTE OCCUPÉ — résultats prêts à récupérer"
				or "● POSTE OCCUPÉ — analyse en cours sur ce poste"))
			or "● AU LABORATOIRE — poste libre, analyses possibles"
		draw.SimpleText(txt, "EVOSci_XS", s(10), h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- Nav bestiaire dockée BOTTOM AVANT le scroll FILL (règle Derma : FILL en dernier).
	local bNav = mkBtn(left, "VOIR LE BESTIAIRE (F6)", false, function() EVO_OpenScienceLab("bestiary") end)
	bNav:Dock(BOTTOM) bNav:DockMargin(s(10), s(6), s(6), s(8)) bNav:SetTall(s(34))

	local scroll = vgui.Create("DScrollPanel", left)
	scroll:Dock(FILL) scroll:DockMargin(s(10), s(8), s(6), s(8))
	styleScroll(scroll)

	-- Spécimen prioritaire de la semaine (analyse 2x plus rapide)
	local prio = EVO_SCIENCE.PrioritySpecimen()
	if prio then
		local rp = scroll:Add("DPanel")
		rp:Dock(TOP) rp:DockMargin(0, 0, s(4), s(10)) rp:SetTall(s(36))
		rp.Paint = function(_, w, h)
			paintCutCard(w, h, Color(18, 18, 22))
			surface.SetDrawColor(WARN.r, WARN.g, WARN.b, 150) surface.DrawRect(0, 0, s(3), h)
			draw.SimpleText("★ Spécimen prioritaire : " .. EVO_SCIENCE.NpcInfo(prio).name, "EVOSci_S", s(12), h / 2, WARN, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	-- BESACE
	local bh = scroll:Add("DLabel")
	bh:Dock(TOP) bh:SetFont("EVOSci_H") bh:SetTextColor(TXT)
	bh:SetText("BESACE  " .. #POUCH .. " / " .. CFG.PouchMax) bh:SizeToContents()

	-- TOUS les emplacements sont affichés et analysables (demande user 06/08).
	-- Avant : seule la carcasse de TÊTE était montrée et le bouton envoyait l'index 1
	-- en dur, donc on subissait l'ordre de ramassage. Or les carcasses n'ont ni la
	-- même espèce ni la même fraîcheur, et la fraîcheur DEVIENT la qualité de
	-- l'analyse (sv_science : quality = round(fresh * Samples)) : imposer la tête
	-- revenait à gâcher un spécimen rare parce qu'un banal traînait devant lui.
	-- Chaque carte porte SON bouton : le choix, c'est le bouton sur lequel on clique,
	-- sans état de sélection à garder synchronisé avec la besace qui bouge.
	if #POUCH == 0 then
		local sp = scroll:Add("DPanel")
		sp:Dock(TOP) sp:DockMargin(0, s(6), s(4), 0) sp:SetTall(s(120))
		sp.Paint = function(_, w, h)
			surface.SetDrawColor(16, 16, 20, 160) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 8) surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText("aucune carcasse en besace", "EVOSci_S", w / 2, h / 2, Color(90, 90, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	for iSlot = 1, #POUCH do
		local c = POUCH[iSlot]
		local info = EVO_SCIENCE.NpcInfo(c.class)
		-- Capturé POUR CETTE CARTE : `at` est l'horodatage de ramassage, il sert de
		-- pièce d'identité. La besace peut se réindexer entre l'ouverture du menu et
		-- le clic (décomposition d'une entrée, analyse lancée ailleurs) ; l'index seul
		-- désignerait alors une AUTRE carcasse, et le labo débiterait la trésorerie
		-- pour un spécimen que le joueur n'a pas choisi. Le serveur recoupe les deux.
		local nAt = tonumber(c.at) or 0
		-- Carcasse d'un Hollow MUTÉ : nom suffixé et teinté de la mutation.
		local sName, cName = info.name, TXT
		local tMut = c.mut and istable(NCM_PNJ) and istable(NCM_PNJ.Mutations) and NCM_PNJ.Mutations.Types[c.mut] or nil
		if tMut then sName, cName = info.name .. " · " .. tMut.label, tMut.col end

		local sp = scroll:Add("DPanel")
		sp:Dock(TOP) sp:DockMargin(0, s(6), s(4), 0) sp:SetTall(s(120))
		sp.Paint = function(_, w, h)
			paintCutCard(w, h, Color(18, 18, 22))
			draw.SimpleText(sName, "EVOSci_B", s(98), s(6), cName, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			drawStars(s(98), s(30), info.tier, 4, WARN, 17)
			local f = slotFresh(c)
			surface.SetDrawColor(45, 45, 52) surface.DrawRect(s(98), s(56), w - s(114), s(8))
			local fc = freshColor(f)
			surface.SetDrawColor(fc.r, fc.g, fc.b) surface.DrawRect(s(98), s(56), (w - s(114)) * f, s(8))
			draw.SimpleText("Se décompose dans " .. fmtLeft(slotLeft(c)), "EVOSci_XS", s(98), s(66), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end

		-- Vignette de l'ESPÈCE et non du prop générique : mkCarcassModel affiche le
		-- même modèle de carcasse pour tout le monde, ce qui rendait trois emplacements
		-- rigoureusement identiques à l'œil. On choisit mal ce qu'on ne distingue pas.
		-- Teinte sombre (2e argument) = lecture « spécimen », pas PNJ vivant.
		local mp = mkNpcModel(sp, c.class, true, c.mut and NCM_PNJ.MutationSkin and NCM_PNJ.MutationSkin(c.class, c.mut) or nil)
		mp:SetPos(s(6), s(6)) mp:SetSize(s(84), s(108))

		local bAna = mkBtn(sp, inZone and "ANALYSER" or "ANALYSER (au labo)", true, function()
			net.Start("EVO_Science::Start")
				net.WriteUInt(iSlot, 4)
				net.WriteUInt(nAt, 32) -- contrôle d'identité, cf. commentaire ci-dessus
			net.SendToServer()
		end)
		bAna:SetPos(s(98), s(84)) bAna:SetSize(s(230), s(30))
		bAna.Think = function(self)
			if (self._next or 0) > CurTime() then return end
			self._next = CurTime() + 0.5
			local inz = EVO_SCIENCE.IsInLabZone(LocalPlayer())
			local busy = inz and myPostJob() ~= nil
			self:SetEnabled(inz and not busy)
			self:SetLabel(busy and "POSTE OCCUPÉ" or (inz and "ANALYSER" or "ANALYSER (au labo)"))
		end
	end

	-- PAILLASSE (analyses longues de la faction)
	local ph = scroll:Add("DLabel")
	ph:Dock(TOP) ph:DockMargin(0, s(16), 0, 0)
	ph:SetFont("EVOSci_H") ph:SetTextColor(TXT)
	ph:SetText("ANALYSEUR  " .. #JOBS .. " / " .. EVO_SCIENCE.MaxJobs()) ph:SizeToContents()

	if #JOBS == 0 then
		local none = scroll:Add("DLabel")
		none:Dock(TOP) none:DockMargin(0, s(6), 0, 0)
		none:SetFont("EVOSci_S") none:SetTextColor(Color(90, 90, 100))
		none:SetText("aucune analyse en cours") none:SizeToContents()
	end

	for _, j in ipairs(JOBS) do
		local info = EVO_SCIENCE.NpcInfo(j.class)
		local zlbl = EVO_SCIENCE.ZoneLabel(j.zone)
		local jp = scroll:Add("DPanel")
		jp:Dock(TOP) jp:DockMargin(0, s(6), s(4), 0) jp:SetTall(s(108))
		jp.Paint = function(_, w, h)
			paintCutCard(w, h, Color(18, 18, 22))
			local leftS = jobLeft(j)
			local ready = leftS <= 0
			if ready then surface.SetDrawColor(OK_COL.r, OK_COL.g, OK_COL.b, 150) surface.DrawRect(0, 0, s(3), h) end
			draw.SimpleText(info.name .. (zlbl ~= "" and ("  ·  " .. zlbl) or ""), "EVOSci_B", s(12), s(8), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Échantillons " .. j.quality .. "/" .. CFG.Samples .. "  ·  par " .. (j.starter ~= "" and j.starter or "?"),
				"EVOSci_XS", s(12), s(36), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local prog = 1 - math.Clamp(leftS / math.max(j.total, 1), 0, 1)
			surface.SetDrawColor(45, 45, 52) surface.DrawRect(s(12), s(58), w - s(152), s(10))
			surface.SetDrawColor(ready and OK_COL.r or SCI.r, ready and OK_COL.g or SCI.g, ready and OK_COL.b or SCI.b)
			surface.DrawRect(s(12), s(58), (w - s(152)) * prog, s(10))
			draw.SimpleText(ready and "ANALYSE TERMINÉE" or ("Résultats dans " .. fmtDur(leftS)),
				"EVOSci_XS", s(12), s(76), ready and OK_COL or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		local jobId = j.id
		local bCol = mkBtn(jp, "RÉCUPÉRER", true, function()
			net.Start("EVO_Science::Collect")
				net.WriteString(jobId)
			net.SendToServer()
		end)
		bCol:SetSize(s(120), s(34))
		jp.PerformLayout = function(_, w, h) bCol:SetPos(w - s(130), h / 2 - s(17)) end
		local jref = j
		bCol.Think = function(self)
			if (self._next or 0) > CurTime() then return end
			self._next = CurTime() + 0.5
			-- récupérable seulement SUR le poste où tourne l'analyse ("" = partout)
			local here = EVO_SCIENCE.ZoneIdFor(LocalPlayer())
			local zoneOk = here ~= nil and ((jref.zone or "") == "" or jref.zone == here)
			self:SetEnabled(jobLeft(jref) <= 0 and zoneOk)
			self:SetLabel(zoneOk and "RÉCUPÉRER" or (zlbl ~= "" and zlbl:upper() or "AUTRE POSTE"))
		end
	end

end

-- ============================================================================
-- VUE BESTIAIRE (fenêtre dédiée, consultable PARTOUT via F6) : consultation pure
-- ============================================================================
function ShowBestiary()
	if not IsValid(content) then return end
	currentView = "bestiary"
	local bSA = IsValid(LocalPlayer()) and LocalPlayer():IsSuperAdmin()
	content.PerformLayout = nil
	content:Clear()

	-- Bandeau infos : analyseur + spécimen prioritaire
	local prio = EVO_SCIENCE.PrioritySpecimen()
	local strip = vgui.Create("DPanel", content)
	strip:Dock(TOP) strip:SetTall(s(40)) strip:DockMargin(0, 0, 0, s(8))
	strip.Paint = function(_, w, h)
		paintCutCard(w, h, Color(18, 18, 22))
		surface.SetDrawColor(SCI.r, SCI.g, SCI.b, 150) surface.DrawRect(0, 0, s(3), h)
		local nReady = 0
		for _, j in ipairs(JOBS) do if jobLeft(j) <= 0 then nReady = nReady + 1 end end
		local jtxt = #JOBS == 0 and "Analyseur : libre" or ("Analyseur : " .. #JOBS .. " analyse(s)" .. (nReady > 0 and (" dont " .. nReady .. " PRÊTE(S)") or ""))
		draw.SimpleText(jtxt, "EVOSci_S", s(14), h / 2, nReady > 0 and OK_COL or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if prio then
			draw.SimpleText("★ Prioritaire : " .. EVO_SCIENCE.NpcInfo(prio).name, "EVOSci_S", w - s(14), h / 2, WARN, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	-- DOSSIERS (encadrement : Capitaine / Vice-Capitaine de la division + SA)
	if EVO_SCIENCE.CanOversight(LocalPlayer()) then
		local bDoss = mkBtn(content, "DOSSIERS — SUIVI DE LA RECHERCHE", false, function() ShowDossiers() end)
		bDoss:Dock(BOTTOM) bDoss:SetTall(s(34)) bDoss:DockMargin(0, s(6), 0, s(4))
	end

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL)
	right.Paint = function(_, w, h)
		surface.SetDrawColor(CARD2) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 12) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText(bSA and "BESTIAIRE HOLLOW  ·  VUE SUPERADMIN (tout débloqué)" or "BESTIAIRE HOLLOW", "EVOSci_H", s(14), s(12), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local classes = {}
	if istable(NCM_PNJ) and istable(NCM_PNJ.Config) then
		for class in pairs(NCM_PNJ.Config) do
			if EVO_SCIENCE.IsHollowClass(class) then classes[#classes + 1] = class end
		end
	end
	table.sort(classes, function(a, b)
		local ia, ib = EVO_SCIENCE.NpcInfo(a), EVO_SCIENCE.NpcInfo(b)
		if ia.tier ~= ib.tier then return ia.tier < ib.tier end
		return ia.name < ib.name
	end)
	if not selectedClass then selectedClass = classes[1] end

	local list = vgui.Create("DScrollPanel", right)
	local detail
	local function rebuildDetail()
		if not IsValid(detail) then return end
		detail:GetCanvas():Clear()
		if not selectedClass then return end
		local class = selectedClass
		local info  = EVO_SCIENCE.NpcInfo(class)
		local lvl   = viewLevel(class)
		-- Libellés figés ici : le Paint tourne 60 fois par seconde, `lvl` ne bouge qu'au Sync.
		local sCount = lvl .. " / " .. CFG.MaxLevel .. " analyses"
		local sBonus = "Bonus de faction : +" .. pctTxt(EVO_SCIENCE.CombatBonus(class, tonumber(BEST[class]) or 0))
			.. "% de dégâts contre ce spécimen"
		local nNeed  = nextThreshold(class, lvl)
		local sNext  = nNeed and ("Prochaine révélation dans " .. (nNeed - lvl) .. " analyse" .. ((nNeed - lvl) > 1 and "s" or ""))
			or "Fiche entièrement révélée"
		local tThres = EVO_SCIENCE.IntelThresholdsFor(class)
		surface.SetFont("EVOSci_XS")
		local nCountW = surface.GetTextSize(sCount) -- mesure unique : « 100 / 100 analyses » mordait sur la barre

		local head = vgui.Create("DPanel", detail)
		head:Dock(TOP) head:SetTall(s(122)) head.Paint = function(_, w, h)
			draw.SimpleText(lvl > 0 and info.name or "SPÉCIMEN INCONNU", "EVOSci_Big", 0, 0, lvl > 0 and TXT or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			if class == prio then
				draw.SimpleText("★ PRIORITAIRE CETTE SEMAINE", "EVOSci_XS", 0, s(54), WARN, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			draw.SimpleText("Difficulté :", "EVOSci_S", 0, s(78), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			drawStars(s(96), s(74), info.tier, 4, WARN, 22)
			draw.SimpleText("Connaissance :", "EVOSci_S", s(210), s(78), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local bx = s(340)
			local bw = math.max(s(90), w - bx - nCountW - s(22))
			drawKnowBar(bx, s(80), bw, s(11), lvl, CFG.MaxLevel, SCI, tThres)
			draw.SimpleText(sCount, "EVOSci_XS", w - s(8), s(77), TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			if lvl > 0 then
				draw.SimpleText(sBonus, "EVOSci_XS", 0, s(102), SCI, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			draw.SimpleText(sNext, "EVOSci_XS", w - s(8), s(102), nNeed and TXT_DIM or SCI, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
		if lvl <= 0 then
			local l = vgui.Create("DLabel", detail)
			l:Dock(TOP) l:DockMargin(0, s(14), s(8), 0)
			l:SetFont("EVOSci_S") l:SetTextColor(TXT_DIM)
			l:SetWrap(true) l:SetAutoStretchVertical(true)
			l:SetText("Aucune donnée : analysez une carcasse de ce spécimen.")
		else
			-- Spécimen analysé : son model 3D dans la fiche + l'intel par paliers.
			local mp = mkNpcModel(detail, class)
			mp:Dock(TOP) mp:SetTall(s(210)) mp:DockMargin(0, s(4), s(8), 0)
			buildIntelSections(detail, class, lvl)
		end
	end

	-- Largeur du pire cas (« 100/100 ») mesurée UNE fois : le compteur mordait sur la barre.
	surface.SetFont("EVOSci_XS")
	local nLvlW = surface.GetTextSize(CFG.MaxLevel .. "/" .. CFG.MaxLevel)
	for _, class in ipairs(classes) do
		local info = EVO_SCIENCE.NpcInfo(class)
		local lvl  = viewLevel(class)
		local sLvl = lvl .. "/" .. CFG.MaxLevel -- figé : ~15 lignes redessinées à chaque frame
		local row = list:Add("DButton")
		row:Dock(TOP) row:DockMargin(0, 0, s(6), s(4)) row:SetTall(s(48)) row:SetText("")
		row.Paint = function(self, w, h)
			local sel = (selectedClass == class)
			surface.SetDrawColor(sel and Color(ACCENT.r, ACCENT.g, ACCENT.b, 40) or (self:IsHovered() and Color(255, 255, 255, 12) or Color(18, 18, 22)))
			surface.DrawRect(0, 0, w, h)
			if sel then surface.SetDrawColor(ACCENT) surface.DrawRect(0, 0, s(3), h) end
			local label = (class == prio and "★ " or "") .. (lvl > 0 and info.name or "???")
			draw.SimpleText(label, "EVOSci_B", s(12), h / 2, class == prio and WARN or (lvl > 0 and TXT or TXT_DIM), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			-- Barre + compteur (une pastille par analyse ne tient plus à 100, 08/26).
			local bw = s(96)
			local bx = w - s(12) - nLvlW - s(10) - bw
			drawKnowBar(bx, h / 2 - s(4), bw, s(8), lvl, CFG.MaxLevel, SCI)
			draw.SimpleText(sLvl, "EVOSci_XS", w - s(12), h / 2, lvl > 0 and TXT or TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function() snd("click") selectedClass = class rebuildDetail() end
	end

	detail = vgui.Create("DScrollPanel", right)
	styleScroll(list)
	styleScroll(detail)
	right.PerformLayout = function(_, w, h)
		list:SetPos(s(12), s(64))
		list:SetSize(math.floor(w * 0.42), h - s(76))
		detail:SetPos(math.floor(w * 0.42) + s(26), s(64))
		detail:SetSize(w - math.floor(w * 0.42) - s(40), h - s(76))
	end
	rebuildDetail()
end

-- ============================================================================
-- VUE DOSSIERS (encadrement : Capitaine / Vice-Capitaine de la division + SA)
-- Complétion du bestiaire, analyses en cours, classement des meilleurs analyseurs.
-- ============================================================================
function ShowDossiers(skipReq)
	if not IsValid(content) then return end
	currentView = "dossiers"
	content.PerformLayout = nil
	content:Clear()

	-- demande les stats (la réponse rebuild la vue avec skipReq -> pas de boucle)
	if not skipReq then net.Start("EVO_Science::Dossiers") net.SendToServer() end

	local top = vgui.Create("DPanel", content)
	top:Dock(TOP) top:SetTall(s(56))
	top.Paint = function(_, w, h)
		draw.SimpleText("DOSSIERS : SUIVI DE LA RECHERCHE", "EVOSci_H", 0, 0, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Réservé à l'encadrement de la division scientifique.", "EVOSci_XS", 0, s(32), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local back = mkBtn(content, "RETOUR AU BESTIAIRE", false, function() ShowBestiary() end)
	back:Dock(BOTTOM) back:SetTall(s(36)) back:DockMargin(0, s(6), 0, 0)

	local body = vgui.Create("DScrollPanel", content)
	body:Dock(FILL)
	styleScroll(body)

	local function sectionTitle(txt)
		local l = body:Add("DLabel")
		l:Dock(TOP) l:DockMargin(0, s(14), 0, s(4))
		l:SetFont("EVOSci_B") l:SetTextColor(ACCENT)
		l:SetText(txt) l:SizeToContents()
	end

	-- ── 1) Complétion du bestiaire (par tier, depuis la connaissance de faction) ──
	sectionTitle("COMPLÉTION DU BESTIAIRE")
	local tiers = {}
	if istable(NCM_PNJ) and istable(NCM_PNJ.Config) then
		for class in pairs(NCM_PNJ.Config) do
			if EVO_SCIENCE.IsHollowClass(class) then
				local t = EVO_SCIENCE.NpcInfo(class).tier
				tiers[t] = tiers[t] or { total = 0, done = 0, lvls = 0 }
				tiers[t].total = tiers[t].total + 1
				local lvl = tonumber(BEST[class]) or 0
				tiers[t].lvls = tiers[t].lvls + lvl
				if lvl >= CFG.MaxLevel then tiers[t].done = tiers[t].done + 1 end
			end
		end
	end
	for t = 1, 4 do
		local d = tiers[t]
		if d then
			local row = body:Add("DPanel")
			row:Dock(TOP) row:DockMargin(0, 0, s(6), s(4)) row:SetTall(s(40))
			row.Paint = function(_, w, h)
				paintCutCard(w, h, Color(18, 18, 22), s(7))
				draw.SimpleText("Tier " .. t, "EVOSci_S", s(12), h / 2, WARN, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local frac = d.lvls / math.max(d.total * CFG.MaxLevel, 1)
				surface.SetDrawColor(45, 45, 52) surface.DrawRect(s(90), h / 2 - s(6), w - s(300), s(12))
				surface.SetDrawColor(SCI.r, SCI.g, SCI.b) surface.DrawRect(s(90), h / 2 - s(6), (w - s(300)) * frac, s(12))
				draw.SimpleText(d.done .. "/" .. d.total .. " espèces épuisées  ·  " .. math.floor(frac * 100) .. "%",
					"EVOSci_S", w - s(12), h / 2, TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- ── 2) Analyses en cours ──
	sectionTitle("ANALYSES EN COURS  (" .. #JOBS .. "/" .. EVO_SCIENCE.MaxJobs() .. ")")
	if #JOBS == 0 then
		local l = body:Add("DLabel")
		l:Dock(TOP) l:SetFont("EVOSci_S") l:SetTextColor(Color(90, 90, 100))
		l:SetText("analyseur libre") l:SizeToContents()
	end
	for _, j in ipairs(JOBS) do
		local row = body:Add("DPanel")
		row:Dock(TOP) row:DockMargin(0, 0, s(6), s(4)) row:SetTall(s(40))
		row.Paint = function(_, w, h)
			paintCutCard(w, h, Color(18, 18, 22), s(7))
			local leftS = jobLeft(j)
			local ready = leftS <= 0
			draw.SimpleText(EVO_SCIENCE.NpcInfo(j.class).name .. "  ·  par " .. (j.starter ~= "" and j.starter or "?"),
				"EVOSci_S", s(12), h / 2, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(ready and "PRÊTE" or (fmtDur(leftS) .. " restants"),
				"EVOSci_S", w - s(12), h / 2, ready and OK_COL or TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	-- ── 3) Meilleurs analyseurs ──
	sectionTitle("MEILLEURS ANALYSEURS")
	if #DOSS == 0 then
		local l = body:Add("DLabel")
		l:Dock(TOP) l:SetFont("EVOSci_S") l:SetTextColor(Color(90, 90, 100))
		l:SetText("aucune analyse enregistrée pour le moment") l:SizeToContents()
	end
	for i, st in ipairs(DOSS) do
		local row = body:Add("DPanel")
		row:Dock(TOP) row:DockMargin(0, 0, s(6), s(4)) row:SetTall(s(44))
		row.Paint = function(_, w, h)
			paintCutCard(w, h, Color(18, 18, 22), s(7))
			if i <= 3 then surface.SetDrawColor(WARN.r, WARN.g, WARN.b, 150) surface.DrawRect(0, 0, s(3), h) end
			draw.SimpleText("#" .. i, "EVOSci_B", s(12), h / 2, i <= 3 and WARN or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(st.name or "?", "EVOSci_B", s(56), h / 2, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local qavg = (st.analyses or 0) > 0 and (st.qsum or 0) / st.analyses or 0
			draw.SimpleText((st.analyses or 0) .. " analyse(s)  ·  qualité moy. " .. string.format("%.1f", qavg) .. "/" .. CFG.Samples,
				"EVOSci_S", w - s(12), h / 2, TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
end

net.Receive("EVO_Science::Dossiers", function()
	local t = util.JSONToTable(net.ReadString() or "") or {}
	DOSS = t.stats or {}
	if IsValid(UI) and currentView == "dossiers" then ShowDossiers(true) end
end)

-- ============================================================================
-- ÉCRANS DE RÉSULTAT
-- ============================================================================
local function mkBackBtn()
	local back = mkBtn(content, "RETOUR AU POSTE D'ANALYSE", true, function() reqSync() ShowBench() end)
	back:SetSize(s(280), s(40))
	content.PerformLayout = function(_, w, h) if IsValid(back) then back:SetPos(0, h - s(44)) end end
end

-- Analyse lancée (net Result) : qualité (= fraîcheur de la carcasse) + durée estimée.
local function ShowLaunched(class, quality, duration)
	if not IsValid(content) then return end
	currentView = "outcome"
	content.PerformLayout = nil
	content:Clear()

	local info = EVO_SCIENCE.NpcInfo(class)
	local top = vgui.Create("DPanel", content)
	top:Dock(TOP) top:SetTall(s(150))
	top.Paint = function(_, w, h)
		draw.SimpleText("ANALYSE LANCÉE", "EVOSci_Title", 0, 0, SCI, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(info.name .. " : qualité de l'échantillon " .. quality .. " / " .. CFG.Samples .. " (fraîcheur)", "EVOSci_H", 0, s(46), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("L'analyseur travaille : résultats dans ~" .. fmtDur(duration) .. ".", "EVOSci_B", 0, s(80), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Tout scientifique de la faction pourra les récupérer au laboratoire.", "EVOSci_S", 0, s(112), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	mkBackBtn()
end

-- Récupération des résultats : rapport + intel débloquée (net CollectAck).
local function ShowReport(class, old, new)
	if not IsValid(content) then return end
	currentView = "report"
	content.PerformLayout = nil
	content:Clear()

	local info = EVO_SCIENCE.NpcInfo(class)
	local sGain = "CONNAISSANCE AMÉLIORÉE : " .. new .. " analyses / "
		.. ((EVO_SCIENCE.MaxLevelFor and EVO_SCIENCE.MaxLevelFor(class)) or CFG.MaxLevel)
	local top = vgui.Create("DPanel", content)
	top:Dock(TOP) top:SetTall(s(120))
	top.Paint = function(_, w, h)
		draw.SimpleText("RAPPORT D'ANALYSE", "EVOSci_Title", 0, 0, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(info.name, "EVOSci_H", 0, s(46), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if new > old then
			draw.SimpleText(sGain, "EVOSci_B", 0, s(80), SCI, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		else
			draw.SimpleText("Connaissance déjà au maximum pour ce spécimen.", "EVOSci_B", 0, s(80), WARN, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local body = vgui.Create("DScrollPanel", content)
	body:Dock(FILL) body:DockMargin(0, s(6), 0, s(52))
	styleScroll(body)
	local sBase, nMut = class, nil
	if EVO_SCIENCE.SplitKey then sBase, nMut = EVO_SCIENCE.SplitKey(class) end
	if nMut then
		buildMutationBlock(body, sBase, nMut, new) -- carcasse mutée : la fiche de CETTE mutation
	else
		buildIntelSections(body, class, new)
	end

	mkBackBtn()
	if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
end

-- ============================================================================
-- FRAME PRINCIPALE (labo)
-- ============================================================================
-- mode = "bestiary" (défaut, consultable partout) ou "lab" (poste d'analyse, via [E]
-- dans un cercle blanc). Deux fenêtres légères plutôt qu'une seule surchargée.
function EVO_OpenScienceLab(mode)
	mode = mode or "bestiary"
	if IsValid(UI) then UI:Remove() end
	-- Le sync du BANC (spécimens/analyses) ne concerne que le poste d'analyse
	-- et le bestiaire : les bureaux n'en ont pas besoin.
	if mode == "lab" or mode == "bestiary" or mode == nil then reqSync() end
	-- Sync du hub (grades labo / documents / potions) : fourni par cl_science_hub.
	if EVO_SCIENCE.HubReqSync then EVO_SCIENCE.HubReqSync() end

	local back
	if EVO_UI and EVO_UI.Backdrop then
		back = EVO_UI.Backdrop(function() if IsValid(back) then back:Remove() end end)
	else
		back = vgui.Create("DPanel")
		back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0) back:MakePopup()
		back._t = SysTime()
		back.Paint = function(self, w, h)
			Derma_DrawBackgroundBlur(self, self._t)
			surface.SetDrawColor(0, 0, 0, 175) surface.DrawRect(0, 0, w, h)
		end
		if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end
	end
	UI = back

	-- Fermer la fenêtre = vider le mélange du synthétiseur (pas persisté hors UI).
	local prevRemove = back.OnRemove
	back.OnRemove = function(pnl)
		if EVO_SCIENCE.PotionComboClear then EVO_SCIENCE.PotionComboClear() end
		if prevRemove then prevRemove(pnl) end
	end

	-- RE-APPUI sur la touche du bind (déf. F6) = FERMER (toggle, demande user 07/18).
	-- PlayerButtonDown ne tire plus une fois le popup ouvert (focus clavier au panel) ->
	-- on POLL input.IsKeyDown dans le Think. On exige d'abord un RELÂCHEMENT après
	-- l'ouverture (_sciKeyArmed) : sinon l'appui d'ouverture, encore enfoncé à la 1re
	-- frame, refermerait aussitôt. On wrappe le Think existant (fondu du Backdrop).
	local prevThink = back.Think
	back.Think = function(pnl)
		if prevThink then prevThink(pnl) end
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		local k = (lp.GetBindKey and lp:GetBindKey("science_ui")) or KEY_F6
		if not k or k == 0 then return end
		local down = input.IsKeyDown(k)
		if not pnl._sciKeyArmed then
			if not down then pnl._sciKeyArmed = true end
			return
		end
		if down then pnl:Remove() end
	end

	-- Voile supplémentaire : assombrit franchement l'arrière-plan derrière la carte
	-- (demande user "mets le derrière en opacité").
	local shade = vgui.Create("DPanel", back)
	shade:SetSize(ScrW(), ScrH()) shade:SetPos(0, 0)
	shade:SetMouseInputEnabled(false)
	shade.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 130) surface.DrawRect(0, 0, w, h)
	end

	-- FENÊTRES SÉPARÉES PAR POSTE PHYSIQUE (user 08/19) : le poste d'analyse ne
	-- montre QUE les carcasses, le bureau de préparation (etablie_02) porte
	-- recettes+potions, le bureau ordinateur (etablie_03) les documents, la
	-- GESTION est une interface à part (rang 5). Le bestiaire reste le F6.
	local LAB_MODES = {
		lab      = { title = "POSTE D'ANALYSE" }, -- carcasses uniquement
		prep     = { title = "LABORATOIRE", order = { "potions", "recettes" }, lvl = true },
		bureau   = { title = "BUREAU DU LABORATOIRE", order = { "documents" }, gestionBtn = true },
		gestion  = { title = "GESTION DU LABORATOIRE", order = { "gestion" } },
		bestiary = { title = "BESTIAIRE" },
	}
	local md = LAB_MODES[mode] or LAB_MODES.bestiary
	-- TYPE de fenêtre : le receiver EVO_Science::Sync ne redessine le banc
	-- (spécimens/analyses) que si currentView vaut "lab"/"bestiary" — sans ça
	-- il ÉCRASAIT le contenu des bureaux (prep/bureau/gestion) à chaque sync
	-- (user 08/21 « arrête de me montrer les spécimens »).
	currentView = (mode == "lab") and "lab" or ((mode == "bestiary" or mode == nil) and "bestiary" or "hub")

	local W = ScrW() - s(60)
	local H = ScrH() - s(60)
	local sTitle = md.title
	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then EVO_UI.PaintCard(w, h, 1, s(14))
		else draw.RoundedBox(0, 0, 0, w, h, Color(14, 14, 17)) end
		local title = sTitle
		draw.SimpleText(title, "EVOSci_Title", s(38), s(30), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVOSci_Title")
			local tw, th = surface.GetTextSize(title)
			EVO_UI.Ink(EVO_UI.TexSlash, s(36), s(30) + th * 0.28, tw * 1.12, s(8), ColorAlpha(ACCENT, 245))
		end
		-- Niveau d'atelier scientifique dans l'EN-TÊTE (mode préparation) : même
		-- présentation que le niveau d'atelier des autres divisions (user 08/19).
		if md.lvl and EVO_SCIENCE.SciLevelInfo then
			local nLvl, nIn, nNeed, nMax, nToday, nCap = EVO_SCIENCE.SciLevelInfo()
			local bx = w - s(360)
			draw.SimpleText("NIVEAU D'ATELIER " .. nLvl .. (nLvl >= nMax and " (MAX)" or ""),
				"EVOSci_B", bx, s(22), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local bw2, bh2 = s(280), s(8)
			surface.SetDrawColor(45, 45, 52)
			surface.DrawRect(bx, s(38), bw2, bh2)
			surface.SetDrawColor(ACCENT)
			surface.DrawRect(bx, s(38), math.floor(bw2 * (nNeed > 0 and math.Clamp(nIn / nNeed, 0, 1) or 1)), bh2)
			draw.SimpleText(nNeed > 0 and (nIn .. " / " .. nNeed .. " XP") or "niveau maximum",
				"EVOSci_XS", bx, s(56), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("gains du jour " .. nToday .. " / " .. nCap, "EVOSci_XS",
				bx + bw2, s(56), TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	local close = vgui.Create("DButton", card)
	close:SetText("") close:SetSize(s(40), s(40)) close:SetPos(W - s(50), s(12))
	close.Paint = function(self, w, h)
		draw.SimpleText("✕", "EVOSci_H", w / 2, h / 2, self:IsHovered() and ACCENT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() snd("click") back:Remove() end

	-- Onglets du MODE (filtre sur ceux de cl_science_hub) : barre seulement s'il
	-- y a plusieurs onglets, sinon le contenu prend toute la hauteur.
	local tTabs = {}
	if mode == "lab" then
		-- Poste d'analyse = CARCASSES UNIQUEMENT (user 08/19) : plus aucun onglet
		-- du hub ici, les autres activités vivent sur leurs établis.
		tTabs[1] = { id = "analyse", label = "ANALYSE", fBuild = function() ShowBench() end }
	elseif md.order then
		-- Ordre EXPLICITE du mode (user 08/21 : POTIONS d'abord au bureau de
		-- préparation — le carnet qui s'ouvrait en premier passait pour un
		-- bestiaire), filtré par la visibilité de chaque onglet.
		local byId = {}
		for _, t in ipairs(EVO_SCIENCE.LabTabs or {}) do byId[t.id] = t end
		for _, sId in ipairs(md.order) do
			local t = byId[sId]
			if t and (not t.fVisible or t.fVisible()) then tTabs[#tTabs + 1] = t end
		end
	end
	local bBar = #tTabs > 1
	local contentY = bBar and s(116) or s(72)
	content = vgui.Create("DPanel", card)
	content:SetPos(s(20), contentY)
	content:SetSize(W - s(40), H - contentY - s(20))
	content.Paint = function() end

	if mode == "bestiary" then
		ShowBestiary()
		return
	end
	if #tTabs == 0 then
		-- HubSync pas encore arrive (grades a 0) ou acces reellement refuse :
		-- on se reconstruit des que le sync tombe au lieu de rester fige.
		EVO_SCIENCE._LabRebuild = function()
			if IsValid(back) then EVO_OpenScienceLab(mode) end
		end
		local lbl = vgui.Create("DLabel", content)
		lbl:SetFont("EVOSci_H")
		lbl:SetTextColor(TXT_DIM)
		lbl:SetText("Chargement du laboratoire…")
		lbl:SizeToContents()
		lbl:SetPos(s(20), s(20))
		return
	end

	-- ── Barre d'onglets du labo ──────────────────────────────────────────────
	-- ANALYSE (le poste historique) + les onglets enregistres par cl_science_hub
	-- dans EVO_SCIENCE.LabTabs ({id, label, fVisible, fBuild(content, ctx)}).
	-- ctx expose les helpers locaux du fichier pour que les onglets externes
	-- gardent EXACTEMENT la meme DA sans dupliquer le code.
	local ctx = {
		s = s, fsz = fsz, mkBtn = mkBtn, styleScroll = styleScroll,
		paintCutCard = paintCutCard, snd = snd, drawStars = drawStars,
		back = back, card = card, content = content, W = W, H = H,
		col = {
			ACCENT = ACCENT, CARD2 = CARD2, FIELD = FIELD, TXT = TXT,
			TXT_DIM = TXT_DIM, OK = OK_COL, WARN = WARN, SCI = SCI,
		},
	}
	local curTab = tTabs[1].id
	local function buildTab(t)
		curTab = t.id
		content:Clear()
		content.PerformLayout = nil
		if t.fBuild then t.fBuild(content, ctx) end
	end

	-- Rebuild de l'onglet courant (consomme par les receivers de cl_science_hub
	-- quand un sync arrive). sOnlyTab : ne rebuild que si cet onglet est actif.
	EVO_SCIENCE._LabRebuild = function(sOnlyTab)
		if not IsValid(back) or not IsValid(content) then return end
		if sOnlyTab and sOnlyTab ~= curTab then return end
		for _, t in ipairs(tTabs) do
			if t.id == curTab then buildTab(t) return end
		end
	end

	if bBar then
		local tabsY = s(64)
		local x = s(38)
		for _, t in ipairs(tTabs) do
			surface.SetFont("EVOSci_B")
			local tw = surface.GetTextSize(t.label)
			local b = vgui.Create("DButton", card)
			b:SetText("")
			b:SetCursor("hand")
			b:SetPos(x, tabsY)
			b:SetSize(tw + s(28), s(40))
			b.Paint = function(self, w, h)
				local active = (curTab == t.id)
				if self:IsHovered() and not active then
					surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, 45)
					surface.DrawRect(0, 0, w, h)
				end
				if active then
					surface.SetDrawColor(ACCENT)
					surface.DrawRect(0, h - s(3), w, s(3))
				end
				draw.SimpleText(t.label, "EVOSci_B", w / 2, h / 2,
					(active or self:IsHovered()) and TXT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				snd("click")
				buildTab(t)
			end
			x = x + tw + s(34)
		end
	end

	-- GESTION = interface SÉPARÉE (user 08/19) : bouton en haut à droite du
	-- bureau, visible seulement au rang labo maximum (même gate que l'onglet).
	if md.gestionBtn then
		local gt
		for _, t in ipairs(EVO_SCIENCE.LabTabs or {}) do
			if t.id == "gestion" then gt = t break end
		end
		if gt and (not gt.fVisible or gt.fVisible()) then
			surface.SetFont("EVOSci_B")
			local tw = surface.GetTextSize("GESTION")
			local bg = vgui.Create("DButton", card)
			bg:SetText("")
			bg:SetCursor("hand")
			bg:SetSize(tw + s(36), s(38))
			bg:SetPos(W - s(70) - tw - s(36), s(14))
			bg.Paint = function(self, w, h)
				surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, self:IsHovered() and 235 or 190)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText("GESTION", "EVOSci_B", w / 2, h / 2, TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			bg.DoClick = function()
				snd("click")
				EVO_OpenScienceLab("gestion")
			end
		end
	end

	buildTab(tTabs[1])
end

net.Receive("EVO_Science::Open", function() EVO_OpenScienceLab() end)

net.Receive("EVO_Science::Result", function()
	local class    = net.ReadString()
	local quality  = net.ReadUInt(4)
	local duration = net.ReadUInt(18)
	if IsValid(UI) then ShowLaunched(class, quality, duration) end
end)

net.Receive("EVO_Science::CollectAck", function()
	local class = net.ReadString()
	local old   = net.ReadUInt(8)
	local new   = net.ReadUInt(8)
	if not IsValid(UI) then EVO_OpenScienceLab("lab") end
	ShowReport(class, old, new)
end)

concommand.Add("evo_science", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if not EVO_SCIENCE.IsScientist(lp) then
		if lp:IsSuperAdmin() then EVO_OpenScienceLab("bestiary") return end -- SA : consultation complète
		chat.AddText(ACCENT, "[Labo] ", TXT, "Réservé à la division scientifique (Division 12 / Ordre 3).")
		return
	end
	EVO_OpenScienceLab()
end)

-- Bind "science_ui" (menu de binds, défaut F6) — scientifiques uniquement.
hook.Add("PlayerButtonDown", "EVO_Science::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if vgui.GetKeyboardFocus() then return end
	if IsValid(UI) then return end
	local bSA = ply:IsSuperAdmin()
	if not bSA and ply:GetEvoNWBool("EVO_StaffMode", false) then return end
	if not (EVO_SCIENCE.IsScientist(ply) or bSA) then return end
	-- Pres d'un bureau du labo, la touche appartient au BUREAU (sinon le
	-- bestiaire s'ouvrait une frame avant la fenetre du bureau, user 08/21).
	if EVO_SCIENCE.EtablieNearby and EVO_SCIENCE.EtablieNearby() then return end
	local k = (ply.GetBindKey and ply:GetBindKey("science_ui")) or KEY_F6
	if k and k ~= 0 and btn == k then
		-- SA hors division scientifique : bestiaire seul (pas de besace / poste à lui).
		EVO_OpenScienceLab((bSA and not EVO_SCIENCE.IsScientist(ply)) and "bestiary" or nil)
	end
end)

-- ============================================================================
-- « EN TRAIN DE MANGER / BOIRE » : fenêtre poussée par le serveur (net EatBusy,
-- source unique sv_science_potions : PotionDrinkFX + eatGesture). Prédicat
-- CENTRAL lu par tous les prompts [E] du HUD (ramasser récolte / ressources /
-- carcasses, récupérer pièges, hint de drop) pour se cacher pendant le geste.
-- ============================================================================
local eatBusyUntil = 0
net.Receive("EVO_Science::EatBusy", function()
	eatBusyUntil = CurTime() + net.ReadFloat()
end)
function EVO_SCIENCE.EatBusy()
	return CurTime() < eatBusyUntil
end

-- ============================================================================
-- CARCASSES AU SOL : scan (3 Hz), prompt [E], ramassage E FAÇON LARVE, halo
-- ============================================================================
local nearCarc, carcList, nextScan = nil, {}, 0

local function scanCarcasses(lp)
	nextScan = SysTime() + 0.33
	nearCarc, carcList = nil, {}
	local best
	for _, e in ents.Iterator() do
		if IsValid(e) and e:GetEvoNWBool("EVO_SciCarcass", false) then
			-- Isolation instance : carcasse monde cachée aux joueurs en Bataille / instance
			-- (et inversement via ShouldHideFromLocal sur l'owner si jamais owned).
			if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal
				and NCM_INSTANCE.ShouldHideFromLocal(e) then continue end
			local d = lp:EyePos():DistToSqr(e:GetPos())
			if d < 900 * 900 then carcList[#carcList + 1] = e end
			-- Rayon LU DANS LA CONFIG et plus ecrit en dur : c'est son ecart avec
			-- CFG.EatRange qui rendait les carcasses  intachables  (cf. commentaire
			-- des portees dans sh_science_config). Les deux doivent bouger ensemble.
			local rDet = CFG.DetectRange or 250
			if d < rDet * rDet and (not best or d < best) then best = d nearCarc = e end
		end
	end
end

hook.Add("HUDPaint", "EVO_Science::Hud", function()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	if lp:GetEvoNWBool("EVO_IsLarva", false) then return end
	if lp:GetEvoNWBool("EVO_StaffMode", false) then return end

	-- (Le bandeau HUD haut-centre des analyses a été RETIRÉ — demande user 07/17 :
	-- l'état des analyses ne s'affiche plus QUE au-dessus des postes, en 3D.)
	if SysTime() > nextScan then scanCarcasses(lp) end
	if not IsValid(nearCarc) then return end
	if EVO_SCIENCE.EatBusy() then return end

	local isSci = EVO_SCIENCE.IsScientist(lp)
	local scr = (nearCarc:GetPos() + Vector(0, 0, 26)):ToScreen()
	if not scr.visible then return end
	local class = nearCarc:GetEvoNWString("SciClass", "")
	local name  = EVO_SCIENCE.NpcInfo(class).name
	local left  = math.max(0, nearCarc:GetEvoNWFloat("SciDieAt", 0) - CurTime())
	-- Style d'invite unifié, ancré en haut de l'ancienne plaque (scr.y - s(46)) ; repli dessous.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		local sInfo = "s'évapore dans " .. math.floor(left) .. " s"
		if isSci then
			EVO_ZonePrompt.Draw2D(scr.x, scr.y - s(46), name, "Prélever", "E", nil, sInfo)
		else
			EVO_ZonePrompt.Draw2D(scr.x, scr.y - s(46), "Carcasse de Hollow", "Réservé à la division scientifique", "", nil, sInfo)
		end
		return
	end
	local txt   = isSci and ("[E] Prélever — " .. name) or "Carcasse de Hollow (division scientifique)"
	surface.SetFont("EVOSci_B")
	local tw = surface.GetTextSize(txt)
	local bw, bh = tw + s(28), s(46)
	local x, y = scr.x - bw / 2, scr.y - bh
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, bw, bh, Color(15, 15, 18, 235), s(8), "br")
	else
		surface.SetDrawColor(15, 15, 18, 235) surface.DrawRect(x, y, bw, bh)
	end
	surface.SetDrawColor(isSci and SCI or TXT_DIM) surface.DrawRect(x, y, s(3), bh)
	draw.SimpleText(txt, "EVOSci_B", x + s(14), y + s(7), isSci and TXT or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("s'évapore dans " .. math.floor(left) .. " s", "EVOSci_XS", x + s(14), y + s(28), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end)

-- Touche E : (1) ramasser la carcasse visée (même recette que le mode larve :
-- net -> serveur revalide) ; sinon (2) DANS un cercle blanc = ouvrir le POSTE D'ANALYSE.
hook.Add("PlayerButtonDown", "EVO_Science::EatKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if not EVO_SCIENCE.IsScientist(ply) then return end
	if IsValid(nearCarc) and not EVO_SCIENCE.EatBusy()
		and ply:EyePos():Distance(nearCarc:GetPos()) <= CFG.EatRange then
		net.Start("EVO_Science::Pickup")
			net.WriteEntity(nearCarc)
		net.SendToServer()
		return
	end
	if not IsValid(UI) and EVO_SCIENCE.IsInLabZone(ply) then
		EVO_OpenScienceLab("lab")
	end
end)

-- Halo vert "spécimen" (la teinte SetColor rendait ce prop invisible -> contour halo).
hook.Add("PreDrawHalos", "EVO_Science::CarcassHalo", function()
	-- Mode cinematique (F7, ncm_cinematic) : aucun halo, plan propre.
	if IsCinematicActive and IsCinematicActive() then return end
	if #carcList == 0 then return end
	local t = {}
	for _, e in ipairs(carcList) do
		if IsValid(e) then t[#t + 1] = e end
	end
	if #t > 0 then halo.Add(t, SCI, 2, 2, 1, true, true) end
end)

-- ============================================================================
-- MARQUEURS DE ZONE (monde) : plaque « ANALYSE [E] Utiliser le poste » face au
-- joueur (EVO_ZonePrompt, recette cachot — plus de cercle au sol, user 08/24).
-- Visibles UNIQUEMENT par la division scientifique.
-- ============================================================================

hook.Add("PostDrawTranslucentRenderables", "EVO_Science::ZoneMarkers", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local lp = LocalPlayer()
	if not (IsValid(lp) and EVO_SCIENCE.IsScientist(lp)) then return end
	-- MÊME source que la détection (EVO_SCIENCE.Zones + ZoneAnchor) : le cercle
	-- dessiné et le cylindre testé sont le MÊME endroit, par construction.
	local zones = EVO_SCIENCE.Zones()
	if #zones == 0 then return end

	local eye = EyePos()
	for _, z in ipairs(zones) do
		if eye:DistToSqr(z.pos) < (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then
			local gpos = EVO_SCIENCE.ZoneAnchor(z) -- sol du poste = centre du cylindre testé
			-- Billboard du poste (pivote pour faire face au joueur). Chaque poste
			-- n'affiche QUE l'analyse qui tourne SUR LUI (jobs d'avant la colonne
			-- zone : partout).
			-- MÊME prédicat que le verrou (myPostJob / refus serveur) : un job sans
			-- poste (zone="", analyses d'avant la colonne) ne bloque RIEN, il ne doit
			-- donc pas faire croire que tous les postes sont occupés.
			local zjobs = {}
			for _, j in ipairs(JOBS) do
				if (j.zone or "") ~= "" and j.zone == z.id then zjobs[#zjobs + 1] = j end
			end
			local ang = (eye - gpos):Angle()
			cam.Start3D2D(gpos + Vector(0, 0, 125), Angle(0, ang.y + 90, 90), 0.22)
				-- Poste LIBRE = nom "ANALYSE" sur la plaque ; poste OCCUPÉ = le statut
				-- le REMPLACE (sinon "ANALYSE" apparaissait en double avec "ANALYSE EN
				-- COURS" — remarque user 07/17), la plaque garde keycap + action.
				EVO_ZonePrompt.Row(0, #zjobs == 0 and "ANALYSE" or "", "Utiliser le poste")
				-- État de l'ANALYSEUR (SEUL affichage des analyses en cours — le
				-- bandeau HUD a été retiré) : "ANALYSE EN COURS" + temps restant +
				-- barre de progression 3D. Pas de nom de hollow (demande user), pas
				-- de gris (illisible en monde) -> vert science. Départ -135 : la
				-- plaque 2 lignes monte jusqu'à -40 (poste libre), la barre du job
				-- finit à yOff+78.
				local yOff = -135
				for _, j in ipairs(zjobs) do
					local leftS = jobLeft(j)
					local ready = leftS <= 0
					local prog = 1 - math.Clamp(leftS / math.max(j.total or 1, 1), 0, 1)
					draw.SimpleText(ready and "ANALYSE TERMINÉE" or "ANALYSE EN COURS", "EVOSci_H", 0, yOff,
						ready and OK_COL or Color(255, 255, 255, 250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.SimpleText(ready and "Résultats à récupérer au poste"
							or ("Temps restant : " .. fmtDur(leftS)),
						"EVOSci_B", 0, yOff + 36, ready and OK_COL or SCI, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetDrawColor(35, 35, 42, 235) surface.DrawRect(-220, yOff + 62, 440, 16)
					local pc = ready and OK_COL or SCI
					surface.SetDrawColor(pc.r, pc.g, pc.b, 245) surface.DrawRect(-220, yOff + 62, 440 * prog, 16)
					yOff = yOff - 125
				end
			cam.End3D2D()
		end
	end
end)
