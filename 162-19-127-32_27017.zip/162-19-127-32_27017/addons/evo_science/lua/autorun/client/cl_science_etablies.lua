-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_etablies.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Share the one-model-per-frame queue while preserving this menu's camera setup.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

-- ============================================================================
-- EVO_SCIENCE ETABLIES (client) : UI de placement precis des etablis du labo
-- (cmd `evo_etablie`, SUPERADMIN — demande user 08/10). 3 cartes avec apercu
-- 3D + PLACER (au point vise, yaw camera) ; liste des poses avec ajustements
-- (±15°/±2°, ±Z, re-placer au vise) et COPIER : ligne Lua prete a coller au
-- presse-papier (`{ pos = Vector(...), ang = Angle(0, yaw, 0) }`).
-- DA EVO (#0E0E11, accent #cf444e), fontes EVOSci_* (creees par cl_science).
-- ============================================================================
if not CLIENT then return end

EVO_SCIENCE = EVO_SCIENCE or {}
local CFG = EVO_SCIENCE.CFG
local HUB = CFG.Hub

local SC = math.Clamp(ScrH() / 1080, 0.9, 2.0)
local function s(n) return math.floor(n * SC + 0.5) end

local COL_BG     = Color(14, 14, 17, 248)
local COL_CARD   = Color(19, 19, 23, 255)
local COL_ACCENT = Color(207, 68, 78)
local COL_TXT    = Color(236, 236, 240)
local COL_DIM    = Color(150, 150, 162)
local COL_LINE   = Color(255, 255, 255, 18)

local PLACED = {} -- miroir de la liste serveur (EtablieSync)
local FRAME

net.Receive("EVO_Science::EtablieSync", function()
	local ok, t = pcall(util.JSONToTable, net.ReadString())
	PLACED = (ok and istable(t)) and t or {}
	if IsValid(FRAME) and FRAME.RebuildList then FRAME:RebuildList() end
end)

-- Ligne Lua prete a coller pour UNE pose.
local function fmtEntry(e)
	local t = HUB.Etablies[tonumber(e.mdl) or 1]
	return string.format("{ pos = Vector(%.1f, %.1f, %.1f), ang = Angle(0, %.1f, 0) }, -- %s",
		e.x or 0, e.y or 0, e.z or 0, e.yaw or 0, (t and t.id) or "?")
end

local function copyText(sTxt, sMsg)
	SetClipboardText(sTxt)
	notification.AddLegacy(sMsg or "Copié dans le presse-papier.", NOTIFY_GENERIC, 3)
	surface.PlaySound("buttons/button14.wav")
end

-- Petit bouton DA (texte seul, hover accent).
local function mkBtn(parent, sLabel, fClick, sTip)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	if sTip then b:SetTooltip(sTip) end
	b.DoClick = fClick
	b.Paint = function(self, w, h)
		surface.SetDrawColor(self:IsHovered() and COL_ACCENT or Color(30, 30, 36, 255))
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText(sLabel, "EVOSci_XS", w / 2, h / 2,
			self:IsHovered() and Color(255, 255, 255) or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return b
end

local function openUI()
	if IsValid(FRAME) then FRAME:Remove() end

	local W, H = s(940), s(590)
	local fr = vgui.Create("DPanel")
	fr:SetSize(W, H)
	fr:Center()
	fr:MakePopup()
	FRAME = fr
	if EVO_MakeEscClosable then EVO_MakeEscClosable(fr) end

	fr.Paint = function(_, w, h)
		surface.SetDrawColor(COL_BG)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(0, 0, w, s(3))
		draw.SimpleText("PLACEMENT DES ÉTABLIS", "EVOSci_Title", s(20), s(34), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("PLACER pose l'établi au POINT VISÉ, orienté comme ta caméra. Ajuste, puis COPIER — la ligne Lua part au presse-papier.",
			"EVOSci_XS", s(20), s(62), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local close = mkBtn(fr, "✕", function() fr:Remove() end)
	close:SetPos(W - s(42), s(12))
	close:SetSize(s(30), s(30))

	-- ── Colonne gauche : les modeles (apercu 3D + PLACER) ────────────────────
	-- SCROLLABLE depuis l'ajout de la verrerie medicale (08/18) : la liste est
	-- passee de 3 a 13 entrees, les cartes a positions fixes debordaient.
	-- ⚠ L'index part sur 6 bits (net) : 63 entrees MAX dans HUB.Etablies
	-- (elargi de 4 bits avec le decor assassin/ressources, meme jour).
	local scrollL = vgui.Create("DScrollPanel", fr)
	scrollL:SetPos(s(16), s(84))
	scrollL:SetSize(s(312), H - s(100))
	for i, t in ipairs(HUB.Etablies) do
		local card = vgui.Create("DPanel", scrollL)
		card:Dock(TOP)
		card:DockMargin(0, 0, s(10), s(10))
		card:SetTall(s(154))
		card.Paint = function(_, w, h)
			surface.SetDrawColor(COL_CARD)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(COL_LINE)
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(t.name, "EVOSci_B", s(130), s(22), COL_TXT)
			draw.SimpleText(t.id, "EVOSci_XS", s(130), s(46), COL_DIM)
		end

		local mdl = vgui.Create("DModelPanel", card)
		mdl:SetPos(s(8), s(8))
		mdl:SetSize(s(112), s(138))
		QueuePreviewModel(mdl, function(mdl)
			mdl:SetModel(t.model)
			mdl.LayoutEntity = function() end -- pas de rotation auto (lisible)
			local ent = mdl.Entity
			if IsValid(ent) and t.skin then ent:SetSkin(t.skin) end
			if IsValid(ent) then
				local mn, mx = ent:GetRenderBounds()
				local vC = (mn + mx) / 2
				local nSize = math.max((mx - mn):Length(), 16)
				mdl:SetFOV(32)
				mdl:SetCamPos(vC + Vector(nSize * 0.9, nSize * 0.7, nSize * 0.45))
				mdl:SetLookAt(vC)
			end
		end)

		local place = mkBtn(card, "PLACER AU POINT VISÉ", function()
			net.Start("EVO_Science::EtabliePlace")
			net.WriteUInt(i, 6)
			net.SendToServer()
		end)
		place:SetPos(s(130), card:GetTall() - s(44))
		place:SetSize(s(160), s(34))
	end

	-- ── Colonne droite : poses de la session + ajustements + copie ───────────
	local listX = s(330)
	local listW = W - listX - s(16)

	local head = vgui.Create("DPanel", fr)
	head:SetPos(listX, s(84))
	head:SetSize(listW, s(24))
	head:SetPaintBackground(false)
	head.Paint = function(_, w, h)
		draw.SimpleText("POSES DE LA SESSION (" .. #PLACED .. ")", "EVOSci_H", 0, h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local scroll = vgui.Create("DScrollPanel", fr)
	scroll:SetPos(listX, s(116))
	scroll:SetSize(listW, H - s(116) - s(64))

	local all = mkBtn(fr, "COPIER TOUTES LES POSITIONS (table Lua)", function()
		if #PLACED == 0 then
			notification.AddLegacy("Aucune pose à copier.", NOTIFY_HINT, 3)
			return
		end
		local out = { "{" }
		for _, e in ipairs(PLACED) do
			out[#out + 1] = "\t" .. fmtEntry(e)
		end
		out[#out + 1] = "}"
		copyText(table.concat(out, "\n"), #PLACED .. " pose(s) copiée(s) au presse-papier.")
	end)
	all:SetPos(listX, H - s(52))
	all:SetSize(listW, s(38))

	fr.RebuildList = function(self)
		if not IsValid(scroll) then return end
		scroll:Clear()
		head:InvalidateLayout()
		for _, e in ipairs(PLACED) do
			local t = HUB.Etablies[tonumber(e.mdl) or 1]
			local row = scroll:Add("DPanel")
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(6))
			row:SetTall(s(56))
			row.Paint = function(_, w, h)
				surface.SetDrawColor(COL_CARD)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawRect(0, 0, s(3), h)
				draw.SimpleText("#" .. e.id .. "  " .. ((t and t.name) or "?"), "EVOSci_S", s(12), s(14), COL_TXT)
				draw.SimpleText(string.format("%.1f  %.1f  %.1f   ·   yaw %.1f", e.x or 0, e.y or 0, e.z or 0, e.yaw or 0),
					"EVOSci_XS", s(12), s(36), COL_DIM)
			end

			local function adj(sAct)
				return function()
					net.Start("EVO_Science::EtablieAdjust")
					net.WriteUInt(e.id, 16)
					net.WriteString(sAct)
					net.SendToServer()
				end
			end
			-- Boutons d'ajustement, ancres a droite de la ligne.
			local defs = {
				{ "✕", "remove", "Supprimer" },
				{ "COPIER", "copy", "Copier la ligne Lua" },
				{ "VISÉ", "aim", "Re-placer au point visé" },
				{ "▼", "down", "Descendre (2u)" },
				{ "▲", "up", "Monter (2u)" },
				{ "+2°", "yawf+", "Rotation fine +2°" },
				{ "-2°", "yawf-", "Rotation fine -2°" },
				{ "+15°", "yaw+", "Rotation +15°" },
				{ "-15°", "yaw-", "Rotation -15°" },
			}
			row.PerformLayout = function(_, w)
				local x = w - s(8)
				for _, d in ipairs(defs) do
					if IsValid(d.btn) then
						x = x - d.btn:GetWide() - s(4)
						d.btn:SetPos(x, s(12))
					end
				end
			end
			for _, d in ipairs(defs) do
				local sLabel, sAct, sTip = d[1], d[2], d[3]
				local b
				if sAct == "copy" then
					b = mkBtn(row, sLabel, function()
						copyText(fmtEntry(e), "Pose #" .. e.id .. " copiée.")
					end, sTip)
				else
					b = mkBtn(row, sLabel, adj(sAct), sTip)
				end
				b:SetSize(sLabel == "COPIER" and s(64) or s(38), s(32))
				d.btn = b
			end
		end
	end
	fr:RebuildList()
end

concommand.Add("evo_etablie", function()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:IsSuperAdmin()) then
		notification.AddLegacy("Commande réservée aux superadmins.", NOTIFY_ERROR, 3)
		return
	end
	openUI()
	net.Start("EVO_Science::EtablieReq")
	net.SendToServer()
end)


-- ============================================================================
-- INTERACTION JOUEUR SUR LES BUREAUX (user 08/21, v2 « comme les crafts ») :
-- un ROND au sol + enseigne 3D2D par bureau (zonePos des placements, même
-- recette visuelle que les stations d'atelier), E DANS le rond = la fenêtre du
-- bureau. Le frigo (coffre de division) garde sa propre interaction.
-- Visible par la division scientifique uniquement (comme les postes d'analyse).
-- ============================================================================
local ET_ZONES = {
	etablie_01 = { mode = "frigo",  label = "FRIGO DU LABORATOIRE",  sub = "Stockage de la division" },
	etablie_02 = { mode = "prep",   label = "BUREAU DE PRÉPARATION", sub = "Recettes et potions" },
	etablie_03 = { mode = "bureau", label = "BUREAU DU LABORATOIRE", sub = "Documents et gestion" },
}
local ET_RADIUS = 45

-- Liste résolue une fois : { { t = ET_ZONES entry, e = placement } }.
local _etList
local function etList()
	if _etList then return _etList end
	_etList = {}
	for _, e in ipairs((HUB.EtabliePlacements or {})[game.GetMap()] or {}) do
		local t = ET_ZONES[e.id]
		if t then _etList[#_etList + 1] = { t = t, e = e } end
	end
	return _etList
end

-- Le joueur est-il DANS le rond d'un bureau ? Retourne l'entrée ET_ZONES.
local function currentEtZone()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return nil end
	if not (EVO_SCIENCE.IsScientist and EVO_SCIENCE.IsScientist(lp)) then return nil end
	local p = lp:GetPos()
	for _, z in ipairs(etList()) do
		local a = EVO_SCIENCE.EtablieZoneSpot(z.e)
		local dx, dy = p.x - a.x, p.y - a.y
		if dx * dx + dy * dy <= ET_RADIUS * ET_RADIUS and math.abs(p.z - a.z) <= 120 then
			return z.t
		end
	end
	return nil
end

-- Export : le bind bestiaire (cl_science OpenBind) s'efface DANS un rond de
-- bureau, sinon une touche partagée ouvrait le bestiaire une frame avant.
function EVO_SCIENCE.EtablieNearby()
	return currentEtZone() ~= nil
end

-- Plaque « NOM [E] sous-titre » face au joueur (EVO_ZonePrompt, recette cachot,
-- plus de cercle au sol — user 08/24). Le E reste géré par currentEtZone.
hook.Add("PostDrawTranslucentRenderables", "EVO_Science::EtablieZones", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return end
	if not (EVO_SCIENCE.IsScientist and EVO_SCIENCE.IsScientist(lp)) then return end
	local tZ = etList()
	if #tZ == 0 then return end

	local eye = EyePos()
	for _, z in ipairs(tZ) do
		local gpos = EVO_SCIENCE.EtablieZoneSpot(z.e)
		if eye:DistToSqr(gpos) < (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then
			EVO_ZonePrompt.Draw(gpos, z.t.label, z.t.sub)
		end
	end
end)

hook.Add("PlayerButtonDown", "EVO_Science::EtablieKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if IsValid(vgui.GetKeyboardFocus()) then return end
	if EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end
	local t = currentEtZone()
	if not t then return end
	if t.mode == "frigo" then
		-- Le frigo est un coffre de division : ouverture à distance côté
		-- serveur (mêmes gates que le +use sur le coffre).
		net.Start("EVO:Craft:CoffreOpenReq")
		net.SendToServer()
		return
	end
	if EVO_OpenScienceLab then EVO_OpenScienceLab(t.mode) end
end)
