-- "addons\\evo_science\\lua\\autorun\\client\\cl_science_maladies.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE MALADIES (client, 08/09) : HUD d'etat malade (demande user :
-- "pour savoir que tu es malade c'est dans le HUD") + mini-jeu d'auscultation
-- du medecin (curseur oscillant, 3 zones, >= 2 reussites = examen reussi).
-- Fontes EVOSci_* creees par cl_science (meme addon, chargees avant l'usage).
-- ============================================================================
if not CLIENT then return end

local CFG = EVO_SCIENCE.CFG
local HUB = CFG.Hub

local SC = math.Clamp(ScrH() / 1080, 0.9, 2.0)
local function s(n) return math.floor(n * SC + 0.5) end

-- ── Effets actifs (carte EFFETS de l'inventaire, 08/09) ──────────────────────
-- Buffs potions recus par EVO_Science::BuffSync (a chaque potion bue + a
-- l'ouverture de l'inventaire) ; nUntil en CurTime (synced), decompte local.
-- Maladie lue directement des NW (EVO_Maladie / EVO_MaladieAggrave).
-- Prefixe p* = MINI BONUS DE PLANTES (canaux distincts des potions, cf.
-- sv_science_potions) : ils s'affichent en plus, jamais a la place.
local BUFFS = {
	fU = 0, fPct = 0, dU = 0, dPct = 0, rU = 0, rMult = 1, rCost = 1, xU = 0, xMult = 1, cdU = 0,
	pdU = 0, pdPct = 0, prU = 0, prPct = 0, pfU = 0, pfPct = 0,
	prrU = 0, prrMult = 1, prrCost = 1, pxU = 0, pxMult = 1, pcdU = 0,
	kU = 0, kPct = 0, -- prospection (philtre du prospecteur)
}

-- ⚠️ L'ordre DOIT suivre EXACTEMENT celui des net.WriteFloat de
-- EVO_SCIENCE.SendBuffSync (sv_science_potions) : bloc potions, puis plantes.
net.Receive("EVO_Science::BuffSync", function()
	BUFFS.fU, BUFFS.fPct = net.ReadFloat(), net.ReadFloat()
	BUFFS.dU, BUFFS.dPct = net.ReadFloat(), net.ReadFloat()
	BUFFS.rU, BUFFS.rMult, BUFFS.rCost = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
	BUFFS.xU, BUFFS.xMult = net.ReadFloat(), net.ReadFloat()
	BUFFS.cdU = net.ReadFloat() -- CD global de consommation (CurTime synced)
	BUFFS.pdU, BUFFS.pdPct = net.ReadFloat(), net.ReadFloat()
	BUFFS.prU, BUFFS.prPct = net.ReadFloat(), net.ReadFloat()
	BUFFS.pfU, BUFFS.pfPct = net.ReadFloat(), net.ReadFloat()
	BUFFS.prrU, BUFFS.prrMult, BUFFS.prrCost = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
	BUFFS.pxU, BUFFS.pxMult = net.ReadFloat(), net.ReadFloat()
	BUFFS.pcdU = net.ReadFloat() -- CD des plantes (CurTime synced)
	-- Prospection : APPENDU EN FIN de protocole cote serveur, donc lu en dernier ici.
	BUFFS.kU, BUFFS.kPct = net.ReadFloat(), net.ReadFloat()
	EVO_SCIENCE._fxNext = 0 -- rebuild immediat du cache
end)

-- Secondes restantes des CD de consommation (case rapide de la spell bar).
-- Les deux sont INDEPENDANTS : potions 10 min, plantes 30 s.
function EVO_SCIENCE.PotionCDLeft()
	return math.max(0, (BUFFS.cdU or 0) - CurTime())
end

function EVO_SCIENCE.PlantCDLeft()
	return math.max(0, (BUFFS.pcdU or 0) - CurTime())
end

-- Couleurs simples (user 08/09) : BONUS = VERT, nefaste/maladie = ROUGE.
local FX_COL_BUFF = Color(110, 205, 130)
local FX_COL_BAD  = Color(226, 80, 80)

local function fmtLeftShort(nSec)
	if nSec >= 60 then return math.ceil(nSec / 60) .. " min" end
	return math.max(1, math.floor(nSec)) .. " s"
end

-- Pourcentage de malus d'une maladie (double si aggravee — meme formule que le
-- serveur : 1 - (1 - base) * MaladieAggraveMalusMult).
local function malusPct(nMult, bAggrave)
	local nBase = 1 - (nMult or 1)
	if bAggrave then nBase = nBase * (HUB.MaladieAggraveMalusMult or 2) end
	return math.Round(nBase * 100)
end

-- Liste {txt, sub, line, col, mal} des effets en cours, cache 0.5 s (0 alloc
-- par frame : le HUD ne fait que dessiner les lignes pre-formatees ; `line` =
-- "TXT · SUB" pret a l'emploi ; mal=true pour les malus maladie — le HUD les
-- SAUTE, la carte MALADE dediee les affiche deja).
local FX_CACHE = {}
EVO_SCIENCE._fxNext = 0

-- Affliction en cours sur le joueur local (nil si sain), + son id. SOURCE
-- UNIQUE des trois lecteurs : pilules du HUD, yeux lourds, hallucinations.
-- SANS garde d'affichage : les pilules doivent rester visibles dans les menus,
-- ce sont les effets d'ecran qui s'effacent (cf. screenMaladie plus bas).
local function maladieDef()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local sId = lp:GetEvoNWString("EVO_Maladie", "")
	if sId == "" then return nil end
	return HUB.Maladies[sId], sId
end

-- Pas de separateur « · » dans les lignes (retire sur demande user 08/09) :
-- juste un espace entre l'effet et le temps/etat.
local function addFx(t, sTxt, sSub, col, bMal)
	t[#t + 1] = {
		txt = sTxt, sub = sSub, col = col, mal = bMal or nil,
		line = (sSub and sSub ~= "") and (sTxt .. "  " .. sSub) or sTxt,
	}
end

function EVO_SCIENCE.GetActiveEffects()
	local now = CurTime()
	if now < EVO_SCIENCE._fxNext then return FX_CACHE end
	EVO_SCIENCE._fxNext = now + 0.5

	local t = {}
	if BUFFS.dU > now then
		addFx(t, string.format("DÉGÂTS +%d%%", BUFFS.dPct), fmtLeftShort(BUFFS.dU - now), FX_COL_BUFF)
	end
	if BUFFS.fU > now then
		addFx(t, string.format("CD FLASHSTEP -%d%%", BUFFS.fPct), fmtLeftShort(BUFFS.fU - now), FX_COL_BUFF)
	end
	if BUFFS.rU > now then
		addFx(t, string.format("RÉGÉN REIATSU ×%.2g", BUFFS.rMult), fmtLeftShort(BUFFS.rU - now), FX_COL_BUFF)
		if (BUFFS.rCost or 1) < 1 then
			addFx(t, string.format("COÛT SORTS -%d%%", math.Round((1 - BUFFS.rCost) * 100)),
				fmtLeftShort(BUFFS.rU - now), FX_COL_BUFF)
		end
	end
	if BUFFS.xU > now then
		addFx(t, string.format("XP +%d%%", math.Round((BUFFS.xMult - 1) * 100)), fmtLeftShort(BUFFS.xU - now), FX_COL_BUFF)
	end
	if BUFFS.kU > now then
		addFx(t, string.format("CRISTAUX +%d%%", BUFFS.kPct), fmtLeftShort(BUFFS.kU - now), FX_COL_BUFF)
	end

	-- MINI BONUS DE PLANTES : memes natures, pilules prefixees « ✿ » pour qu'on
	-- distingue d'un coup d'oeil le petit bonus vegetal du vrai buff de potion.
	if BUFFS.pdU > now then
		addFx(t, string.format("✿ DÉGÂTS +%d%%", BUFFS.pdPct), fmtLeftShort(BUFFS.pdU - now), FX_COL_BUFF)
	end
	if BUFFS.prU > now then
		addFx(t, string.format("✿ DÉGÂTS SUBIS -%d%%", BUFFS.prPct), fmtLeftShort(BUFFS.prU - now), FX_COL_BUFF)
	end
	if BUFFS.pfU > now then
		addFx(t, string.format("✿ CD FLASHSTEP -%d%%", BUFFS.pfPct), fmtLeftShort(BUFFS.pfU - now), FX_COL_BUFF)
	end
	if BUFFS.prrU > now then
		if (BUFFS.prrMult or 1) > 1 then
			addFx(t, string.format("✿ RÉGÉN REIATSU ×%.2g", BUFFS.prrMult), fmtLeftShort(BUFFS.prrU - now), FX_COL_BUFF)
		end
		if (BUFFS.prrCost or 1) < 1 then
			addFx(t, string.format("✿ COÛT SORTS -%d%%", math.Round((1 - BUFFS.prrCost) * 100)),
				fmtLeftShort(BUFFS.prrU - now), FX_COL_BUFF)
		end
	end
	if BUFFS.pxU > now then
		addFx(t, string.format("✿ XP +%d%%", math.Round((BUFFS.pxMult - 1) * 100)), fmtLeftShort(BUFFS.pxU - now), FX_COL_BUFF)
	end

	-- Maladie : pilule(s) ROUGES dans la MEME rangee HUD que les buffs (user
	-- 08/09). Nom de la maladie inclus ; sub = "×2 !" seulement si aggravee.
	local lp = LocalPlayer()
	local d = maladieDef()
	if d then
		local bAg = lp:GetEvoNWBool("EVO_MaladieAggrave", false)
		local sSub = bAg and "×2 !" or ""
		local sName = string.upper(d.sName or "?")
		if d.nMaxHpMult then
			addFx(t, string.format("%s  VIE MAX -%d%%", sName, malusPct(d.nMaxHpMult, bAg)), sSub, FX_COL_BAD, true)
		end
		if d.nMaxReiatsuMult then
			addFx(t, string.format("%s  REIATSU MAX -%d%%", sName, malusPct(d.nMaxReiatsuMult, bAg)), sSub, FX_COL_BAD, true)
		end
		if d.nMeleeMult then
			addFx(t, string.format("%s  DÉGÂTS ARME -%d%%", sName, malusPct(d.nMeleeMult, bAg)), sSub, FX_COL_BAD, true)
		end
	end

	FX_CACHE = t
	return t
end

-- ── HUD : etat malade ────────────────────────────────────────────────────────
-- (Carte flottante a mi-ecran RETIREE 08/09 : la maladie s'affiche desormais en
-- pilule dans la rangee HUD sous la barre de reiatsu, via GetActiveEffects
-- ci-dessus — rendu dans lzy_hud, comme les buffs de potions.)

-- ── Episodes "yeux lourds" (demande user 08/09) : de temps a autre, les
-- paupieres se ferment UN PEU pendant ~4 s (bandes douces haut/bas + leger
-- assombrissement), a intervalles aleatoires tant qu'on est malade. ──────────
local matGradD = Material("vgui/gradient-d")
local matGradU = Material("vgui/gradient-u")

-- ── SOCLE PARTAGE DES SYMPTOMES D'ECRAN ──────────────────────────────────────
-- Les yeux lourds et les hallucinations sont deux effets differents mais
-- exactement le meme MECANISME : lire l'affliction locale, verifier les memes
-- gardes d'affichage, puis derouler un episode periodique. Les trois etaient
-- ecrits en double ; tout nouvel effet d'ecran doit passer par ici.

-- (maladieDef est declaree PLUS HAUT : GetActiveEffects s'en sert aussi, et un
--  local pose ici ne serait pas visible dans une fonction definie avant.)

-- maladieDef + les gardes propres aux effets d'ECRAN : mort, staff, menu personnage,
-- cinematique. Un seul endroit ou ajouter une exception a l'avenir.
local function screenMaladie()
	local d, sId = maladieDef()
	if not d then return nil end
	local lp = LocalPlayer()
	if not lp:Alive() then return nil end
	if lp:GetEvoNWBool("EVO_StaffMode", false) then return nil end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return nil end
	if IsCinematicActive and IsCinematicActive() then return nil end
	return d, sId
end

-- Minuteur d'EPISODE. `st` porte l'etat {nNext, nStart}. Renvoie l'intensite
-- 0..1 en cloche (monte puis redescend) pendant l'episode, nil en dehors :
-- une coupure franche ressemble a un bug d'affichage, pas a un symptome.
local function episodePulse(st, nDelay, nDur)
	local now = CurTime()
	if (st.nNext or 0) <= 0 then st.nNext = now + nDelay end
	if now >= st.nNext then
		st.nStart = now
		st.nNext  = now + nDur + nDelay
	end
	local t = now - (st.nStart or -1e9)
	if t < 0 or t > nDur then return nil end
	return math.sin(math.pi * t / nDur)
end

local ST_YEUX = { nNext = 0, nStart = -1e9 }

hook.Add("HUDPaint", "EVO_Science::MaladieYeux", function()
	local d, sId = screenMaladie()
	if not d then
		ST_YEUX.nNext = 0
		return
	end

	-- Cadence PARTAGEE avec la quinte de toux du serveur
	-- (EVO_SCIENCE.MaladieSymptomDelay) : afflictions d'evenement toutes les
	-- 15 min, maladies ordinaires sur la fourchette longue. Sans cette source
	-- unique, un empoisonne toussait au quart d'heure mais ne cillait qu'a
	-- l'heure — deux symptomes censes decrire le meme etat.
	local f = episodePulse(ST_YEUX, EVO_SCIENCE.MaladieSymptomDelay(sId), HUB.MaladieBlinkDur)
	if not f then return end

	local nClose = math.floor(ScrH() * HUB.MaladieBlinkAmt * f)
	if nClose <= 0 then return end
	local w, hh = ScrW(), ScrH()

	-- Leger voile global pendant l'episode.
	surface.SetDrawColor(8, 6, 8, math.floor(45 * f))
	surface.DrawRect(0, 0, w, hh)

	-- Paupieres : bande pleine + bord degrade vers le centre.
	local nSoft = math.floor(nClose * 0.9) + 2
	surface.SetDrawColor(8, 6, 8, 235)
	surface.DrawRect(0, 0, w, nClose)
	surface.DrawRect(0, hh - nClose, w, nClose)
	surface.SetDrawColor(8, 6, 8, 210)
	surface.SetMaterial(matGradD)
	surface.DrawTexturedRect(0, nClose, w, nSoft)
	surface.SetMaterial(matGradU)
	surface.DrawTexturedRect(0, hh - nClose - nSoft, w, nSoft)
end)

-- ── Mini-jeu d'auscultation (chez le medecin) ────────────────────────────────
-- Fermer / timeout / rater = examen RATE envoye au serveur (sinon on pourrait
-- relancer a l'infini sans consommer le cooldown du patient).
net.Receive("EVO_Science::AusculteGame", function()
	if IsValid(EVO_SCIENCE._AusculteFrame) then EVO_SCIENCE._AusculteFrame:Remove() end

	local W, H = s(460), s(170)
	local fr = vgui.Create("DPanel")
	fr:SetSize(W, H)
	fr:SetPos(math.floor((ScrW() - W) / 2), math.floor(ScrH() * 0.62))
	fr:MakePopup()
	fr:SetKeyboardInputEnabled(true)
	EVO_SCIENCE._AusculteFrame = fr
	if EVO_MakeEscClosable then EVO_MakeEscClosable(fr) end

	local nRound, nHits, bDone = 1, 0, false
	local nT0 = SysTime()
	local nSpeed = 2.2
	local nZoneW = 0.16
	local nZoneX = math.Rand(0.1, 0.9 - nZoneW)

	-- Le resultat d'un examen part UNE seule fois (clic, ESPACE, timeout ou
	-- fermeture du panneau), et le panneau est retire dans la foulee.
	-- netgate: edge -- garde one-shot bDone, couvre tous les appelants (dont le Think ESPACE)
	local function sendResult(bOk)
		if bDone then return end
		bDone = true
		net.Start("EVO_Science::AusculteResult")
		net.WriteBool(bOk)
		net.SendToServer()
		if IsValid(fr) then fr:Remove() end
	end
	fr.OnRemove = function()
		if not bDone then
			bDone = true
			net.Start("EVO_Science::AusculteResult")
			net.WriteBool(false)
			net.SendToServer()
		end
	end
	timer.Simple(20, function()
		if IsValid(fr) then sendResult(false) end
	end)

	local function cursorPos()
		return (math.sin((SysTime() - nT0) * nSpeed) + 1) / 2
	end

	local function strike()
		if bDone then return end
		local p = cursorPos()
		if p >= nZoneX and p <= nZoneX + nZoneW then
			nHits = nHits + 1
			surface.PlaySound(CFG.Sounds.sampleOk or "")
		else
			surface.PlaySound(CFG.Sounds.sampleFail or "")
		end
		if nRound >= 3 then
			sendResult(nHits >= 2)
			return
		end
		nRound = nRound + 1
		nZoneX = math.Rand(0.1, 0.9 - nZoneW)
		nT0 = SysTime()
		nSpeed = nSpeed + 0.5 -- chaque manche accelere
	end

	fr.OnMousePressed = function() strike() end
	fr.Think = function(self)
		-- ESPACE (debounce) : meme geste que le clic.
		local bDown = input.IsKeyDown(KEY_SPACE)
		if bDown and not self._spaceHeld then strike() end
		self._spaceHeld = bDown
	end

	fr.Paint = function(_, w, h)
		surface.SetDrawColor(14, 14, 17, 245)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(207, 68, 78, 200)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("AUSCULTATION", "EVOSci_H", w / 2, s(12), Color(236, 236, 240), TEXT_ALIGN_CENTER)
		draw.SimpleText("Clique (ou ESPACE) quand le curseur traverse la zone  ·  manche "
			.. nRound .. "/3  ·  réussites : " .. nHits, "EVOSci_XS", w / 2, s(44),
			Color(150, 150, 162), TEXT_ALIGN_CENTER)
		local bx, by, bw, bh = s(30), s(76), w - s(60), s(26)
		surface.SetDrawColor(32, 32, 38, 255)
		surface.DrawRect(bx, by, bw, bh)
		surface.SetDrawColor(90, 200, 120, 130)
		surface.DrawRect(bx + math.floor(bw * nZoneX), by, math.floor(bw * nZoneW), bh)
		local cx = bx + math.floor(bw * cursorPos())
		surface.SetDrawColor(236, 236, 240, 255)
		surface.DrawRect(cx - s(2), by - s(4), s(4), bh + s(8))
		draw.SimpleText("ÉCHAP pour abandonner (compte comme un examen raté)", "EVOSci_XS",
			w / 2, h - s(22), Color(108, 108, 120), TEXT_ALIGN_CENTER)
	end
end)

-- ── ZONE CONTAMINEE : reperes au sol, STAFF UNIQUEMENT (user 08/16) ──────────
-- L'organisateur doit voir la limite de sa zone pour la placer et l'animer.
-- Les JOUEURS, eux, ne la voient pas : une contamination qu'on repere a un
-- cercle lumineux n'est plus une contamination, c'est un panneau.
local COL_ZONE = Color(190, 70, 90, 200)
hook.Add("PostDrawTranslucentRenderables", "EVO_Science::InfectZoneMark", function(_, bSky)
	if bSky then return end
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:IsSuperAdmin()) then return end
	if GetGlobalString("EVO_SciInfectId", "") == "" then return end
	if GetGlobalString("EVO_SciInfectMap", "") ~= game.GetMap() then return end
	local nR = GetGlobalFloat("EVO_SciInfectRadius", 0)
	if nR <= 0 then return end

	local vPos = GetGlobalVector("EVO_SciInfectPos", vector_origin)
	if lp:GetPos():DistToSqr(vPos) > (nR + 4000) ^ 2 then return end

	-- MEME technique que les cercles des postes d'analyse (cl_science, marqueurs
	-- de zone) : cam.Start3D2D + surface.DrawCircle, un seul push de matrice pour
	-- les deux anneaux. Deux facons de tracer un cercle au sol dans le meme addon,
	-- c'etait deja une de trop.
	local pulse = 150 + math.sin(RealTime() * 2.2) * 60 -- meme respiration
	cam.Start3D2D(vPos + Vector(0, 0, 3), angle_zero, 1)
		surface.DrawCircle(0, 0, nR, COL_ZONE.r, COL_ZONE.g, COL_ZONE.b, pulse)
		surface.DrawCircle(0, 0, nR - 3, COL_ZONE.r, COL_ZONE.g, COL_ZONE.b, pulse * 0.55)
	cam.End3D2D()
end)

-- ── HALLUCINATIONS : l'ecran vacille par episodes (user 08/16) ───────────────
-- L'affliction porte sa propre cadence (nHalluSec / nHalluDur) : 5 s toutes les
-- 2 min, pendant les 30 min que dure l'intoxication.
-- ⚠ POST-TRAITEMENT D'ECRAN, PAS DE CAMERA. Faire tanguer la vue passerait par
-- CalcView, or la camera du projet est deja disputee par l'orbite, le vol, le
-- mode cinematique et la mort : s'y greffer casserait l'un ou l'autre. Ici on
-- ne touche qu'a l'image finale, aucun systeme ne s'en apercoit.
local ST_HALLU = { nNext = 0, nStart = -1e9 }

hook.Add("RenderScreenspaceEffects", "EVO_Science::Hallucination", function()
	local d = screenMaladie()
	if not (d and d.nHalluSec) then
		ST_HALLU.nNext = 0
		return
	end

	local nDur = d.nHalluDur or 5
	local f = episodePulse(ST_HALLU, d.nHalluSec, nDur)
	if not f then return end

	local w = math.sin(CurTime() * 2.3) * f -- oscillation lente du vertige

	DrawMotionBlur(0.45, 0.55 * f, 0.008)
	DrawColorModify({
		["$pp_colour_addr"]       = 0,
		["$pp_colour_addg"]       = 0.012 * f,
		["$pp_colour_addb"]       = 0.02 * f,
		["$pp_colour_brightness"] = -0.03 * f + w * 0.015,
		["$pp_colour_contrast"]   = 1 + 0.12 * f,
		["$pp_colour_colour"]     = 1 - 0.45 * f, -- desature : la couleur fuit
		["$pp_colour_mulr"]       = 0,
		["$pp_colour_mulg"]       = 0,
		["$pp_colour_mulb"]       = 0.05 * f,
	})
end)
