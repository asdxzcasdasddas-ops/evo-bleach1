-- "addons\\evo_science\\lua\\autorun\\sh_science_hub.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO_SCIENCE HUB — config + helpers PARTAGES des nouveaux onglets du poste
-- d'analyse : GESTION (grades labo), DOCUMENTS (recherche, confidentialite),
-- RECETTES (cahier DHTML), POTIONS (craft 3 etapes).
-- Le serveur (sv_science_hub) reste seul autoritaire ; le client recoit son
-- grade labo via le HubSync.
-- ============================================================================

EVO_SCIENCE = EVO_SCIENCE or {}
EVO_SCIENCE.CFG = EVO_SCIENCE.CFG or {}
local CFG = EVO_SCIENCE.CFG

CFG.Hub = CFG.Hub or {}
local HUB = CFG.Hub

-- ── Rangs labo (whitelist) ───────────────────────────────────────────────────
-- 5 rangs par faction. TOUTE l'administration (gestion whitelist, renommages,
-- zones de documents, acces zone secrete) est au RANG LABO MAX (5) — explicite
-- via la whitelist OU implicite via le grade faction 15 (ResponsableRank) — et
-- aux superadmins (demande user 08/09).
HUB.GradeCount        = 5
HUB.ResponsableRank   = 15  -- rang faction science donnant le rang labo 5 implicite
HUB.GradeMaxLabel     = 40
HUB.MaxCustomZones    = 8   -- zones de documents personnalisees max (z1..z8)

HUB.GradeDefaults = {
	[1] = "Assistant de laboratoire",
	[2] = "Chercheur",
	[3] = "Chercheur confirmé",
	[4] = "Chef de projet",
	[5] = "Responsable de division",
}

-- Grade labo EFFECTIF a partir des donnees d'un realm (explicite d'abord,
-- sinon implicite : Responsable science = 5, membre de la division = 1).
function EVO_SCIENCE.ComputeLabGrade(nExplicit, bScientist, nFactionRank)
	nExplicit = tonumber(nExplicit) or 0
	if nExplicit > 0 then return math.Clamp(math.floor(nExplicit), 1, HUB.GradeCount) end
	if bScientist and (tonumber(nFactionRank) or 0) >= HUB.ResponsableRank then return HUB.GradeCount end
	if bScientist then return 1 end
	return 0
end

-- ── Documents de recherche ───────────────────────────────────────────────────
HUB.DocMaxTitle    = 60
HUB.DocMaxBody     = 2000
HUB.DocFolderMax   = 24     -- longueur max d'un nom de classeur (colonne 40)
HUB.DocMaxPerOwner = 20     -- documents max par proprietaire
HUB.DocListMax     = 60     -- documents max envoyes dans un sync
HUB.DocPublishGrade = 1     -- grade labo mini pour publier un document au labo
-- Images : memes limites que le pipeline rapports faction (jpg/png, 512 Ko,
-- chunks 45 Ko espaces de 0.1 s) ; stockage data/evo_science/docs/ serveur.
HUB.DocImgMaxSize  = 512 * 1024
HUB.DocImgChunk    = 45000
HUB.DocImgDir      = "evo_science/docs"
HUB.DocImgRetentionDays = 60

-- ── Potions (craft en 3 etapes au poste d'analyse) ───────────────────────────
-- Durees en secondes, PENSEES POUR AUGMENTER plus tard : tout le flux lit ces
-- valeurs (serveur autoritaire, client n'affiche que la progression).
HUB.PotionSteps = { "broyeur", "melange", "synthese" }
HUB.PotionStepLabel = {
	broyeur  = "Broyage",
	melange  = "Mélange",
	synthese = "Synthèse",
}
-- Durees FIXEES par le user (08\18) : broyage 15 s, melange 30 s. La synthese
-- garde sa valeur courte d'origine — il n'a tranche que les deux premieres.
HUB.PotionStepDuration = {
	broyeur  = 15,
	melange  = 30,
	synthese = 2,
}
HUB.PotionMinLabGrade = 1   -- grade labo mini (scientifiques = 1 implicite)
-- CRAFT EN SÉRIE (user 09/15) : potions max par synthèse. Ingrédients ET
-- bouteilles ×N, les 3 étapes gardent leurs durées (un seul cycle pour le lot).
HUB.PotionMaxBatch = 10

-- ── Modele des potions (prop evo, 10 skins — user 08/09) ─────────────────────
-- $texturegroup : 0 base, 1 rouge, 2 vert, 3 bleu, 4 cyan, 5 dore, 6 orange,
-- 7 rose, 8 blanc, 9 bouteille vide. ROUGE / VERT / ROSE = RESERVES aux futures
-- potions a effets NEGATIFS (ne pas les utiliser pour les recettes actuelles).
-- NIVEAUX (ETOILES) 1..3 (user 08/10) : un prop de fiole PAR niveau, memes 10
-- skins ($texturegroup identiques sur les 3 modeles).
HUB.PotionStarModels = {
	[1] = "models/evo/props/items/evo_reg5632re54grtefr/evo_REG5632re54grtefr.mdl",
	[2] = "models/evo/props/items/evo_efrrt2ref457reefr/evo_efrRT2ref457reefr.mdl",
	[3] = "models/evo/props/items/evo_erff52fthy45632ref42eref/evo_erfF52fthy45632ref42Eref.mdl",
}
-- Versions TENUES EN MAIN (une par niveau) : attachees a la MAIN GAUCHE pendant
-- la chaine d'anims du boire (start evo_fezqano -> loop evo_wurkeji -> end
-- evo_tomvixa, cf. PotionDrinkFX) — memes $texturegroup, donc memes skins.
HUB.PotionStarHandModels = {
	[1] = "models/evo/props/items/evo_efrref452f25/evo_EFRref452F25.mdl",
	[2] = "models/evo/props/items/evo_efr52ref42e25erf/evo_efr52ref42E25erf.mdl",
	[3] = "models/evo/props/items/evo_eerf52f52ref42erf25/evo_eERF52f52ref42ERF25.mdl",
}
-- Modele "par defaut" (bouteille vide, potion ratee, preparations) = niveau 1.
HUB.PotionModel = HUB.PotionStarModels[1]
HUB.PotionHandModel = HUB.PotionStarHandModels[1]

-- ⚠ RESTAURÉ le 22/08 : le merge de staging (e7f79196 « retire les extras
-- science ») a emporté ce bloc alors que ses appelants VIVENT sur pre-staging.
-- ── CHAMPIGNON / PLANTE EN MAIN GAUCHE (user 08\12) ─────────────────────────
-- ⚠ TECHNIQUE DIFFERENTE DES POTIONS, et ce n'est pas un choix de style : les
-- fioles ci-dessus ont un modele "main" RIGGE sur le squelette du joueur, d'ou
-- le EF_BONEMERGE sans rien a positionner. Les champignons et les plantes n'ont
-- que leur modele de DECOR ; bonemerger un modele qui ne partage pas le
-- squelette ne le colle pas a la main, il le laisse planter a l'origine du
-- joueur. On les accroche donc a l'os de la main gauche (FollowBone), exactement
-- comme la carte, le livre et l'affiche.
-- Le modele affiche est celui de l'ITEM (model_path + skin), donc toujours
-- identique a l'apercu du sac.
-- Ces 3 valeurs se reglent EN JEU avec `evo_science_hand_offset` (superadmin),
-- qui imprime la ligne prete a coller ici.
HUB.EatPropPos   = Vector(1.5, 1.2, 0)   -- offset local sur l'os de la main
HUB.EatPropAng   = Angle(0, 0, 0)        -- orientation locale
HUB.EatPropScale = 0.85                  -- un champignon de decor est un peu gros en main
-- Fraction de l'anim au bout de laquelle l'objet DISPARAIT de la main (user
-- 08\13) : a 60% la main est deja a la bouche, la bouchee est prise. Le garder
-- jusqu'au bout donnait un champignon encore intact pendant qu'on le mastique.
HUB.EatPropHideAt = 0.6

-- Regles des niveaux : effets x nFxMult, ingredients x nCostMult (la bouteille
-- vide reste 1 quel que soit le niveau), acces gate par NIVEAU SCIENTIFIQUE.
-- Toxines/remedes N'ONT PAS de niveaux (effets non scalaires).
HUB.PotionStars = {
	[1] = { nSciLevel = 0,  nCostMult = 1, nFxMult = 1 },
	[2] = { nSciLevel = 15, nCostMult = 2, nFxMult = 1.5 },
	[3] = { nSciLevel = 30, nCostMult = 3, nFxMult = 2 },
}
HUB.PotionStarSuffix = { [1] = "", [2] = "_2e", [3] = "_3e" }
HUB.PotionStarTag    = { [1] = "", [2] = " ★★", [3] = " ★★★" }

-- XP SCIENTIFIQUE (user 08/10) : +1 XP par analyse RECUPEREE ou synthese
-- RECUPEREE (ratee incluse), max 20 gains/jour depuis le 09/28 (10 avant) : un
-- assidu atteint le niv 15 en ~1 semaine et le 30 en ~2 semaines.
-- CENTRALISE le 08/18 : la COURBE (10 XP/niveau, cap 30) et le STOCKAGE vivent
-- dans le systeme de niveaux d'evo_craft (role "science", table
-- evo_craft_levels, courbe par role dans EVO_CRAFT.XPPerLevel). Ici ne restent
-- que le cap JOURNALIER (pacing labo) et des delegues de compat (12 sites).
HUB.SciMaxGainsPerDay = 20 -- 09/28 (user) : 10 -> 20, deux fois plus d'XP possible par jour
HUB.SciXPPerLevel     = (EVO_CRAFT and EVO_CRAFT.XPPerLevel) and EVO_CRAFT.XPPerLevel(1, "science") or 10
HUB.SciMaxLevel       = (EVO_CRAFT and EVO_CRAFT.MaxLevel) or 30

function EVO_SCIENCE.SciLevelFromXP(nXP)
	if EVO_CRAFT and EVO_CRAFT.LevelFromXP then
		return (EVO_CRAFT.LevelFromXP(nXP, "science"))
	end
	return math.min(HUB.SciMaxLevel, 1 + math.floor((tonumber(nXP) or 0) / HUB.SciXPPerLevel))
end
HUB.PotionSkinPrep     = 0 -- preparation en cours (liquide de base)
HUB.PotionSkinFailed   = 8 -- BLANC = potion ratee (n'importe quel melange invalide)
HUB.PotionSkinEmpty    = 9 -- bouteille vide (Urahara Shop, 100 yens)

-- ── CATEGORIES de potions (08/09) : chaque recette a une categorie qui fixe la
-- COULEUR de la fiole (skin) et le THEME d'effet. Les effets chiffres seront
-- branches plus tard (proposes au user, en attente de validation) ; sDesc sert
-- deja d'annonce dans le carnet et la description d'item. Le PALIER reste la
-- PUISSANCE de l'effet au sein de la categorie (I -> IV).
HUB.PotionCategories = {
	tonique = {
		sName = "Tonique", nSkin = 3, sHex = "#3b6fd4", cCol = Color(90, 140, 225),
		sDesc = "Récupération : rend et régénère des points de vie.",
	},
	celerite = {
		sName = "Célérité", nSkin = 4, sHex = "#2fb5c7", cCol = Color(70, 190, 205),
		sDesc = "Mobilité : vitesse de course et vivacité au combat.",
	},
	fortifiant = {
		sName = "Fortifiant", nSkin = 5, sHex = "#c9a437", cCol = Color(210, 175, 80),
		sDesc = "Puissance : renforce les dégâts du katana et des sorts.",
	},
	stimulant = {
		sName = "Stimulant", nSkin = 6, sHex = "#d97c2b", cCol = Color(220, 135, 60),
		sDesc = "Reiatsu : accélère la récupération d'énergie spirituelle.",
	},
	essence = {
		sName = "Essence", nSkin = 0, sHex = "#7c4fc9", cCol = Color(150, 105, 220),
		sDesc = "Esprit : expérience et effets spirituels rares.",
	},
	-- Potions NEFASTES (08/09) : les recettes de ces 2 categories portent un
	-- nSkin OVERRIDE par paire (rouge/vert/rose) — le remede a la MEME teinte
	-- que la toxine qu'il guerit.
	toxine = {
		sName = "Toxine", nSkin = 1, sHex = "#b8353f", cCol = Color(200, 80, 90),
		sDesc = "Pathogène : inocule une maladie (injectable par un scientifique).",
	},
	remede = {
		sName = "Remède", nSkin = 8, sHex = "#6a9a6a", cCol = Color(120, 175, 130),
		sDesc = "Antidote : guérit SA maladie — le mauvais remède aggrave.",
	},
	protection = {
		sName = "Protection", nSkin = 0, sHex = "#4f7a8a", cCol = Color(95, 145, 160),
		sDesc = "Équipement sanitaire : se porte au lieu de se boire.",
	},
	-- Prothèses (09/20) : posées au bloc par un scientifique (amputation, EVO_AMPUT).
	prothese = {
		sName = "Prothèse", nSkin = 0, sHex = "#7d8794", cCol = Color(150, 160, 175),
		sDesc = "Appareillage : se pose au bloc, sur un patient allongé.",
	},
	-- Équipement (10/12) : accessoires techniques à porter (lunettes d'analyse).
	equipement = {
		sName = "Équipement", nSkin = 0, sHex = "#3f9a6a", cCol = Color(90, 200, 130),
		sDesc = "Appareil d'analyse : se porte au lieu de se boire.",
	},
}

-- ── MALADIES (potions nefastes, 08/09) ───────────────────────────────────────
-- Malus (nerfs) VOLONTAIREMENT faibles (~1/4 des effets positifs, demande
-- user). Une maladie dure TANT QU'ELLE N'EST PAS SOIGNEE (persistee par
-- personnage) ; passe 3 jours, un jet de guerison naturelle est tente chaque
-- heure. Le MAUVAIS remede DOUBLE les malus (x2, une seule fois).
HUB.Maladies = {
	fievre_ecarlate = {
		sName = "Fièvre écarlate", nSkin = 1, sHex = "#b8353f", cCol = Color(200, 80, 90),
		sEffet = "vie maximale réduite de 10%",
		nMaxHpMult = 0.90,
		sToxine = "toxine_ecarlate", sRemede = "remede_ecarlate",
	},
	peste_verdatre = {
		sName = "Peste verdâtre", nSkin = 2, sHex = "#3d9e5f", cCol = Color(90, 170, 110),
		sEffet = "reiatsu maximal réduit de 10%",
		nMaxReiatsuMult = 0.90,
		sToxine = "toxine_verdatre", sRemede = "remede_verdatre",
	},
	mal_rose = {
		sName = "Mal rosé", nSkin = 7, sHex = "#d46a9e", cCol = Color(215, 120, 165),
		sEffet = "dégâts katana/hakuda réduits de 8%",
		nMeleeMult = 0.92,
		sToxine = "toxine_rose", sRemede = "remede_rose",
	},
	-- ── AFFLICTIONS D'EVENEMENT (user 08\16) ─────────────────────────────────
	-- Reservees aux commandes staff : `bEvent` les EXCLUT du tirage aleatoire
	-- (champignon cru, potion ratee) et de la CONTAGION. Sans ce drapeau, manger
	-- un champignon pouvait tirer le poison mortel — un scenario d'event devenu
	-- accident de cuisine. Aucune recette ne les fabrique : pas de sToxine, pas
	-- de sRemede, seul le SERUM les leve (EVO_SCIENCE.CureAll).
	-- Valeurs FIXEES par le user (08\16). Le nom reste « mortel » pour le RP,
	-- mais l'effet est un malus de PV max, pas des degats continus.
	poison_mortel = {
		sName = "Poison mortel", nSkin = 1, sHex = "#7a1020", cCol = Color(150, 30, 45),
		sEffet = "vie maximale réduite de 10%",
		bEvent = true,
		nMaxHpMult = 0.90,
		nSymptomSec = 900,
	},
	parasite = {
		sName = "Parasite spirituel", nSkin = 2, sHex = "#5b4a8a", cCol = Color(125, 105, 180),
		sEffet = "reiatsu maximal réduit de 25%",
		bEvent = true,
		nMaxReiatsuMult = 0.75,
		nSymptomSec = 900,
	},
	-- ── INTOXICATION AU CHAMPIGNON CRU (user 08\16) ──────────────────────────
	-- Ni une maladie du labo, ni un outil de staff : la sanction ordinaire du
	-- joueur qui croque un champignon ramasse par terre. AUCUN malus de stats,
	-- c'est une gene VISUELLE — d'ou l'absence de nMaxHpMult & co.
	hallucination = {
		sName = "Hallucinations", nSkin = 2, sHex = "#6f8f4a", cCol = Color(140, 175, 95),
		sEffet = "vertiges et maux de tête à répétition",
		-- Jamais par tirage general ni par contagion : elle a son propre point
		-- d'entree (manger un champignon cru). On ne l'attrape pas d'un voisin.
		bDirect  = true,
		-- On ne tousse pas d'une migraine : coupe la quinte, garde les yeux lourds.
		bNoCough = true,
		-- TEMPORAIRE, contrairement aux maladies : se dissipe seule au bout de
		-- 30 min meme sans soin (auto-guerison dans le sweep).
		nDurationSec = 30 * 60,
		-- Episode d'ecran qui vacille : 5 s, toutes les 2 min (client).
		nHalluSec = 120,
		nHalluDur = 5,
		sCureItem = "medicament",
	},
}

-- Nom d'affichage d'un item : HUB.Items D'ABORD (toujours peuplee localement),
-- ITEMS ensuite (retry vers l'inventaire, peut rater en silence). Dernier repli :
-- l'id SANS underscores — jamais d'id brut a l'ecran (demande user 08/18).
-- Resolver UNIQUE de l'addon : toute UI/notif passe par lui, pas par ITEMS seul.
function EVO_SCIENCE.ItemName(sItemId)
	local it = (HUB.Items and HUB.Items[sItemId]) or (ITEMS and ITEMS[sItemId])
	if it and it.name then return it.name end
	return (tostring(sItemId or "?"):gsub("_", " "))
end

-- Item qui soigne cette affliction, resolu pour l'affichage (auscultation,
-- description). Les maladies classiques passent par leur remede appaire.
function EVO_SCIENCE.MaladieCureName(d)
	if not d then return "?" end
	local sId = d.sCureItem or (d.sRemede and ("potion_" .. d.sRemede))
	if not sId then return "?" end
	return EVO_SCIENCE.ItemName(sId)
end

-- ── SOCLE PARTAGE DU COTE SERVEUR ────────────────────────────────────────────
-- Ces trois helpers etaient recopies dans chaque fichier serveur de l'addon
-- (notify x6, countItem x2, echappement SQL x2). Un seul exemplaire desormais.

-- 🔴 ECHAPPEMENT SQL D'UNE VALEUR JOUEUR — NE JAMAIS appeler sql.SQLStr seul.
-- sql.SQLStr est la fonction SQLite de GMod : elle double l'apostrophe mais ne
-- touche PAS a l'ANTISLASH. MUGEN.Query, lui, parle a MySQL, qui lit « \' »
-- comme une apostrophe LITTERALE : la chaine se referme et la suite passe en
-- SQL. Meme faille que celle trouvee dans evo_livre le 08/11 (un titre de livre
-- suffisait a reecrire toute la table). Ici la surface est identique : titres et
-- corps de documents, noms de classeurs et de zones, libelles de rang.
-- On retire donc l'antislash AVANT d'echapper — et seulement lui, l'apostrophe
-- est legitime en francais et correctement geree une fois l'antislash parti.
function EVO_SCIENCE.SqlStr(s)
	return sql.SQLStr((string.gsub(tostring(s or ""), "\\", "")))
end

-- Requete BDD (SERVEUR uniquement) : MUGEN.Query si dispo, sinon SQLite en
-- EMULANT la convention MUGEN — erreur = STRING en 1er argument du callback,
-- resultat = table. sv_science_hub et sv_science_maladies portaient chacun leur
-- copie identique de ce wrapper.
-- (sv_science.lua garde le SIEN : il normalise les erreurs en nil, ses
--  callbacks ne testent que istable — fusionner changerait leur comportement.)
function EVO_SCIENCE.DbQuery(query, cb)
	if istable(MUGEN) and isfunction(MUGEN.Query) then
		MUGEN.Query(query, cb)
	else
		local res = sql.Query(query)
		if cb then cb(res == false and sql.LastError() or (res or {}), nil) end
	end
end

-- Notification joueur (repli ChatPrint si MUGEN n'est pas la).
function EVO_SCIENCE.Notify(ply, sMsg, bErr, nDur)
	if not IsValid(ply) then return end
	if MUGEN and MUGEN.Notify then
		if SERVER then
			MUGEN.Notify(ply, sMsg, bErr and NOTIFY_ERROR or NOTIFY_GENERIC, nDur or 5)
		else
			MUGEN.Notify(sMsg, bErr and NOTIFY_ERROR or NOTIFY_GENERIC, nDur or 5)
		end
	else
		ply:ChatPrint(sMsg)
	end
end

-- Exemplaires d'un item dans le sac du joueur, piles comprises.
-- Client : cache LIVE (CountInventoryItem). Serveur : ply.inventory.quantities.
function EVO_SCIENCE.CountItem(ply, sItemId)
	if not (IsValid(ply) and isstring(sItemId)) then return 0 end
	if ply.CountInventoryItem then
		return ply:CountInventoryItem(sItemId)
	end
	if CLIENT then
		if not ply.GetInventoryItems then return 0 end
		local n = 0
		for _, id in ipairs(ply:GetInventoryItems()) do
			if id == sItemId then n = n + 1 end
		end
		return n
	end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.CountBagItem and ply.inventory then
		return INVENTORY_CONFIG.CountBagItem(ply.inventory, sItemId)
	end
	local inv = ply.inventory and ply.inventory.items
	if not istable(inv) then return 0 end
	local n = 0
	for _, v in pairs(inv) do
		if v == sItemId then n = n + 1 end
	end
	return n
end

-- PV MAX REELS d'un joueur. ⚠ GOTCHA du systeme de stats : GetMaxHealth()
-- renvoie 100 pour les AUTRES joueurs, seul le NW porte la vraie valeur.
-- SOURCE UNIQUE : sv_science_potions (soins de potions/plantes) et
-- sv_science_maladies (remise a plein du contre-poison) lisaient chacun leur
-- copie de ces 3 lignes.
function EVO_SCIENCE.PlayerMaxHP(ply)
	if not IsValid(ply) then return 0 end
	local n = ply:GetEvoNWInt("EVO_MaxHP", 0)
	if n <= 0 then n = ply:GetMaxHealth() end
	return n
end

-- Affliction qui n'arrive QUE par son point d'entree dedie : exclue du tirage
-- aleatoire (champignon cru, potion ratee) ET de la contagion.
-- Deux familles la portent, pour deux raisons differentes :
--   bEvent  = outil de staff (poison mortel, parasite) — il serait absurde
--             qu'un champignon tire le poison d'un scenario ;
--   bDirect = a deja son propre declencheur (hallucination = champignon cru),
--             la remettre dans le pool general la ferait sortir deux fois.
function EVO_SCIENCE.MaladieIsDirect(sId)
	local d = HUB.Maladies[sId]
	return d ~= nil and (d.bEvent == true or d.bDirect == true)
end
-- CONTAGION PAR EXPOSITION (08/09, "tranquille sans etre abuse") : rester PRES
-- d'un malade fait monter une JAUGE (x2 au contact rapproche) ; au seuil, un
-- jet decide de l'infection — et le joueur est PREVENU aux 3/4 de la jauge (il
-- peut s'eloigner, la jauge redescend loin des malades). Garde-fous : 2
-- transmissions max par malade et par heure, et extinction par GENERATION
-- (injectee/bue = gen 0 ; une gen >= 2 ne transmet plus -> pas d'epidemie infinie).
HUB.ContagionTick        = 15    -- periode du sweep (s)
-- ⚠ Valeurs re-NERFEES le 22/08 : le merge de staging avait ramene le reglage
-- d'avant les deux nerfs demandes par le user (propagation ~4x plus rapide).
HUB.ContagionRange       = 130   -- rayon d'exposition (unites)
HUB.ContagionCloseRange  = 90    -- contact rapproche : jauge x2
HUB.ContagionThreshold   = 16    -- points avant le jet (4 min a portee, 2 min au contact)
HUB.ContagionChance      = 0.15  -- chance d'infection quand la jauge est pleine
HUB.ContagionFailFloor   = 3     -- points conserves apres un jet rate
HUB.ContagionMaxPerHour  = 1     -- transmissions max par malade et par heure
HUB.ContagionMaxGen      = 2     -- generation >= N : ne transmet plus
-- Guerison / immunite (08/09, valide user) : le BON remede guerit ET immunise
-- TOTALEMENT contre CETTE maladie 24 h (injection + contagion). Sans remede, la
-- maladie persiste ; passe AutoCureAfter, un jet AutoCureChance est tente
-- chaque heure. Le MAUVAIS remede DOUBLE les malus (AggraveMalusMult, 1 fois).
HUB.MaladieImmuniteSec     = 24 * 3600 -- immunite totale a LA maladie soignee
HUB.MaladieAutoCureAfter   = 72 * 3600 -- anciennete avant les jets de guerison naturelle
HUB.MaladieAutoCureChance  = 0.15      -- chance de guerison naturelle PAR HEURE au-dela
HUB.MaladieAggraveMalusMult = 2        -- mauvais remede : malus x2
-- Infections "hasardeuses" (user 08/09 : tout passe par le MEME pipeline
-- central — EVO_SCIENCE.MaladieRoll -> Infect — avec des entrees differentes) :
HUB.MaladieChampiChance = 0.10  -- manger un champignon CRU : 1 chance sur 10
-- Intoxication (vertiges 30 min) : 1 chance sur 2, tiree APRES la maladie et
-- seulement si elle n'est pas sortie — un joueur ne porte qu'une affliction.
HUB.MaladieChampiHalluChance = 0.5

HUB.MaladieRateeChance  = 1 / 3 -- boire une potion RATEE : 1 chance sur 3

-- CD global de CONSOMMATION (user 08/09) : temps mini entre deux potions bues.
-- Toxines/remedes EXCLUS (se soigner/soigner ne doit pas etre bloque).
HUB.PotionUseCD = 10 * 60
-- Effet "yeux lourds" (client) : episodes aleatoires de paupieres mi-closes.
-- ~UNE FOIS PAR HEURE (45-75 min, valide user 08/09 : 25-60 s = beaucoup trop).
HUB.MaladieBlinkMin = 45 * 60 -- s min entre deux episodes
HUB.MaladieBlinkMax = 75 * 60 -- s max entre deux episodes
HUB.MaladieBlinkDur = 4       -- duree d'un episode (s)
HUB.MaladieBlinkAmt = 0.22    -- fermeture max de CHAQUE paupiere (fraction d'ecran)

-- QUINTE DE TOUX (user 08\12) : le malade tousse ~une fois par heure, son 3D
-- EMIS PAR LE SERVEUR donc ENTENDU AUTOUR de lui. C'est le seul symptome
-- perceptible par les autres sans auscultation : de quoi soupconner un malade
-- dans une piece, et de quoi se trahir quand on veut cacher son etat.
-- Fourchette (comme les yeux lourds) plutot qu'un metronome : deux malades
-- infectes en meme temps ne toussent pas en choeur.
HUB.MaladieToussMin = 45 * 60 -- s min entre deux quintes
HUB.MaladieToussMax = 75 * 60 -- s max entre deux quintes

-- Delai avant le PROCHAIN symptome visible. SOURCE UNIQUE lue par la quinte de
-- toux (serveur, sv_science_maladies) ET par les yeux lourds (client,
-- cl_science_maladies) : les deux symptomes doivent suivre la meme cadence,
-- sinon un joueur tousse sans ciller ou l'inverse.
-- Les afflictions d'EVENEMENT portent `nSymptomSec` (15 min, user 08\16) : sur
-- un scenario d'une heure, une fourchette de 45-75 min laissait la moitie des
-- joueurs touches sans aucun signe visible. Les maladies ordinaires gardent la
-- fourchette longue (~1 h) : c'est un fond RP, pas une alarme.
function EVO_SCIENCE.MaladieSymptomDelay(sId)
	local d = HUB.Maladies[sId]
	if d and d.nSymptomSec then return d.nSymptomSec end
	return math.random(HUB.MaladieToussMin or 2700, HUB.MaladieToussMax or 4500)
end
-- Auscultation (medecins, division de soin) : CD par PATIENT, 3 examens reussis
-- = diagnostic (maladie + remede). Chaque examen reussi (mini-jeu gagne) donne
-- UNE enigme tiree AU HASARD dans la banque de sa maladie (user 08/10 :
-- « beaucoup beaucoup » d'enigmes philosophiques, dur d'identifier le mal).
HUB.AusculteCD      = 30 * 60 -- 2 h -> 30 min (user 08/23) : deux heures immobilisaient le patient trop longtemps
HUB.AusculteFailCD  = 30 * 60
HUB.AusculteNeeded  = 3
HUB.AusculteClues = {
	-- Fievre ecarlate : le SANG, la chaleur, la VITALITE qui fond.
	fievre_ecarlate = {
		"Le foyer brûle en dedans ; la cendre se dépose sur les joues.",
		"J'ai demandé au sang où il courait si vite. Il n'a pas répondu : il fuyait.",
		"Le patient rêve de neige. Son corps, lui, rêve d'éteindre quelque chose.",
		"Ce qui déborde n'est pas la force : c'est la chaleur qui cherche une sortie.",
		"Les rivières intérieures charrient des braises. La digue tiendra moins longtemps.",
		"Le cœur frappe à la porte plus souvent qu'il ne devrait — et plus faiblement.",
		"La vie est une chandelle : ici, la cire fond des deux bouts.",
		"Rouge est la couleur de ce qui vit ; trop de rouge est la couleur de ce qui brûle.",
		"Le corps paie un impôt que personne ne lui a annoncé. Il paie en vitalité.",
		"Sous la peau, une fournaise ; dans les yeux, une fatigue d'incendie.",
		"Ce mal ne prend pas la force du bras : il prend la réserve qui la nourrit.",
		"On ne meurt pas d'une étincelle. On meurt d'oublier qu'elle couve.",
	},
	-- Peste verdatre : l'ESPRIT, le souffle, le REIATSU qui se vide.
	peste_verdatre = {
		"Le corps est intact ; c'est la maison de l'esprit qui a les fenêtres murées.",
		"Le souffle spirituel entre, mais ressort à moitié. Où va l'autre moitié ?",
		"Les canaux sont des routes : ici, quelqu'un a posé des barricades.",
		"La lame est propre, le bras est fort — et pourtant le puits est à sec.",
		"Demande au patient d'appeler son énergie : elle répond de plus loin qu'avant.",
		"Une brume s'est installée entre l'âme et la main. Elle ne pleut jamais.",
		"Ce mal n'éteint pas le feu : il rétrécit l'âtre.",
		"L'esprit inspire, expire — et garde moins d'air à chaque cycle.",
		"La marée spirituelle monte moins haut. La plage, elle, s'en souvient.",
		"Rien ne saigne, rien ne casse. Et pourtant quelque chose se vide.",
		"Les veines du corps sont libres ; celles de l'âme sont engorgées.",
		"Vert est la couleur de ce qui pousse — et de ce qui pourrit.",
	},
	-- Mal rose : la MAIN, le geste, les coups qui ne portent plus.
	mal_rose = {
		"La volonté ordonne, la main négocie. Ce dialogue-là est nouveau.",
		"Le sabre pèse le même poids qu'hier. C'est le bras qui a changé d'avis.",
		"Entre l'intention et le geste, quelqu'un a glissé un coussin.",
		"Les doigts se souviennent des gestes, mais les exécutent en traduction.",
		"Ce mal n'attaque ni la vie ni l'âme : il taxe chaque coup porté.",
		"La poigne est une promesse ; ici, elle n'est plus tenue qu'à moitié.",
		"Serre-lui la main : tu sentiras une hésitation qui n'est pas de la politesse.",
		"Le corps va bien, dit-il. Puis il rate la tasse qu'il voulait saisir.",
		"Rose est la couleur des choses douces. La douceur, au combat, est une condamnation.",
		"Les réflexes arrivent au rendez-vous — avec un temps de retard poli.",
		"L'arme ne mord plus : elle effleure.",
		"Ce n'est pas la force qui manque, c'est la justesse qui la porte.",
	},
}

-- ── EFFETS DES POTIONS (08/09, valides user : boosts FORTS) ──────────────────
-- Indexes par ID DE RECETTE. Le palier monte la valeur, pas la nature.
-- heal    : nPct % PV max instantane (+ nRegenPct %/s pendant nRegenSec)
-- flashcd : -nPct % de cooldown de flashstep pendant nMin minutes
-- damage  : +nPct % degats (katana + sorts) pendant nMin minutes
-- reiatsu : regen reiatsu x nMult (+ couts de sorts -nCostPct %) pendant nMin
-- xp      : +nPct % d'experience pendant nMin minutes
-- Boire une potion de la meme famille REMPLACE le buff en cours (pas de stack).
HUB.PotionEffects = {
	-- Durees DOUBLEES 08/09 (user : "+100% les temps de toutes les potions").
	-- TONIQUE (bleu) : soin
	decoction_trouble  = { sType = "heal", nPct = 25 },
	nectar_seireitei   = { sType = "heal", nPct = 45 },
	rosee_ame          = { sType = "heal", nPct = 30, nRegenPct = 2, nRegenSec = 20 },
	larme_celeste      = { sType = "heal", nPct = 100, nRegenPct = 2, nRegenSec = 30 },
	-- CELERITE (cyan) : reduction du CD de flashstep (demande user : "pas mal")
	brume_limbes       = { sType = "flashcd", nPct = 30, nMin = 12 },
	fiole_orage        = { sType = "flashcd", nPct = 45, nMin = 10 },
	serum_garganta     = { sType = "flashcd", nPct = 60, nMin = 12 },
	-- FORTIFIANT (dore) : degats katana + sorts. sirop_spectral (palier I) est
	-- ICI pour que la fiole DOREE soit craftable des le debut (user 08/09 : "pas
	-- de gold" — aucune recette doree n'existait au palier I ; comptes inegaux OK).
	sirop_spectral     = { sType = "damage", nPct = 10, nMin = 8 },
	philtre_carmin     = { sType = "damage", nPct = 15, nMin = 10 },
	concentre_solaire  = { sType = "damage", nPct = 20, nMin = 8 },
	ambroisie_carmine  = { sType = "damage", nPct = 25, nMin = 10 },
	sang_hollow        = { sType = "damage", nPct = 35, nMin = 8 },
	-- STIMULANT (orange) : regen reiatsu (+ couts de sorts pour le prismatique)
	tonique_sables     = { sType = "reiatsu", nMult = 2, nMin = 10 },
	venin_lumineux     = { sType = "reiatsu", nMult = 2.5, nMin = 10 },
	suc_abime          = { sType = "reiatsu", nMult = 3, nMin = 12 },
	extrait_prismatique = { sType = "reiatsu", nMult = 3, nCostPct = 20, nMin = 12 },
	-- ESSENCE (violet) : experience
	-- ... et PROSPECTION (user 2026-09-18) : le philtre du prospecteur augmente la
	-- chance qu'un Hollow tue laisse un cristal. nPct est un bonus RELATIF sur la
	-- chance de base (cf. HUB.CrystalDropChance, ~7,4% cumules), pas des points de
	-- pourcentage : +50% porte le tirage a ~5,5%, et le rapport entre les tiers ne
	-- bouge pas d'un iota (tous multiplies par le meme facteur).
	-- +75% / 30 min, et la recette ne coûte que 2 cristaux du tier le plus commun :
	-- une potion de prospection doit RAPPORTER des cristaux. Seuil de rentabilité
	-- ~72 Hollows tués sur les 30 min (2,4 kills/min), atteignable en farm normal.
	-- ⚠️ Un premier jet à +50% pour 6 cristaux demandait 16 kills/MINUTE pour être
	-- rentable : si on retouche le coût ou le bonus, refaire ce calcul —
	-- kills = coût / (0,0368 × bonus).
	philtre_prospecteur = { sType = "crystal", nPct = 75, nMin = 30 },
	essence_verdoyante = { sType = "xp", nPct = 30, nMin = 40 },
	elixir_encre       = { sType = "xp", nPct = 50, nMin = 40 },
	huile_profondeurs  = { sType = "xp", nPct = 75, nMin = 60 },
	quintessence_primordiale = { sType = "xp", nPct = 100, nMin = 60 },
	-- TOXINES / REMEDES (maladies — logique dans sv_science_maladies)
	toxine_ecarlate  = { sType = "toxine", sMaladie = "fievre_ecarlate" },
	toxine_verdatre  = { sType = "toxine", sMaladie = "peste_verdatre" },
	toxine_rose      = { sType = "toxine", sMaladie = "mal_rose" },
	remede_ecarlate  = { sType = "remede", sMaladie = "fievre_ecarlate" },
	remede_verdatre  = { sType = "remede", sMaladie = "peste_verdatre" },
	remede_rose      = { sType = "remede", sMaladie = "mal_rose" },
	-- Contre-poison UNIVERSEL : leve n'importe quelle affliction, y compris les
	-- afflictions d'evenement (poison mortel, parasite) que les remedes apparies
	-- ci-dessus ne touchent pas. Aucune immunite derriere. (Restaure 22/08, le
	-- merge de staging l'avait emporte alors que sv_science_potions le consomme.)
	miraculeuse      = { sType = "cureall" },
}

-- Valeurs d'un effet au niveau d'etoiles demande (multiplicateur nFxMult, avec
-- plafonds de bon sens : CD flashstep <= 90%, soin <= 100%). Partage sh :
-- utilise par la description d'item ET par l'application serveur (sv_potions).
function EVO_SCIENCE.PotionStarValues(fx, nStar)
	local m = (HUB.PotionStars[nStar or 1] or HUB.PotionStars[1]).nFxMult or 1
	local t = {}
	if fx.nPct then
		t.nPct = math.Round(fx.nPct * m)
		if fx.sType == "flashcd" then t.nPct = math.min(t.nPct, 90) end
		if fx.sType == "heal" then t.nPct = math.min(t.nPct, 100) end
		-- Prospection : +150% max (x2,5 sur ~7,4% = ~18,5%). A 3 etoiles la recette
		-- actuelle plafonne a +100%, la borne ne sert que de garde-fou si on monte
		-- la valeur de base. Le vrai garde-fou reste le clamp de rollCrystalTier.
		if fx.sType == "crystal" then t.nPct = math.min(t.nPct, 150) end
	end
	if fx.nRegenPct then t.nRegenPct = fx.nRegenPct * m end
	if fx.nMult then t.nMult = math.Round((1 + (fx.nMult - 1) * m) * 100) / 100 end
	if fx.nCostPct then t.nCostPct = math.min(math.Round(fx.nCostPct * m), 60) end
	return t
end

-- Phrase d'effet d'une potion (description d'item + page du carnet).
-- nStar (optionnel, defaut 1) : affiche les valeurs BOOSTEES du niveau.
function EVO_SCIENCE.PotionFxDesc(fx, nStar)
	if not istable(fx) then return "Effets en cours d'étude." end
	local v = EVO_SCIENCE.PotionStarValues(fx, nStar)
	if fx.sType == "heal" then
		local s = "Rend " .. v.nPct .. "% des PV"
		if v.nRegenPct then
			s = s .. " et régénère " .. v.nRegenPct .. "%/s pendant " .. fx.nRegenSec .. " s"
		end
		return s .. "."
	elseif fx.sType == "flashcd" then
		return "Cooldown du flashstep réduit de " .. v.nPct .. "% pendant " .. fx.nMin .. " min."
	elseif fx.sType == "damage" then
		return "+" .. v.nPct .. "% de dégâts (katana et sorts) pendant " .. fx.nMin .. " min."
	elseif fx.sType == "reiatsu" then
		local s = "Régénération de reiatsu ×" .. v.nMult
		if v.nCostPct then s = s .. " et coûts des sorts réduits de " .. v.nCostPct .. "%" end
		return s .. " pendant " .. fx.nMin .. " min."
	elseif fx.sType == "xp" then
		return "+" .. v.nPct .. "% d'expérience pendant " .. fx.nMin .. " min."
	elseif fx.sType == "crystal" then
		return "+" .. v.nPct .. "% de chances qu'un Hollow tué laisse un cristal, pendant "
			.. fx.nMin .. " min."
	elseif fx.sType == "toxine" then
		local m = HUB.Maladies[fx.sMaladie]
		if not m then return "" end
		return "Inocule « " .. m.sName .. " » (" .. m.sEffet
			.. " tant qu'elle n'est pas soignée). Un scientifique peut l'injecter à autrui ; contagieuse."
	elseif fx.sType == "remede" then
		local m = HUB.Maladies[fx.sMaladie]
		if not m then return "" end
		return "Guérit « " .. m.sName .. " » et immunise 24 h contre elle — le MAUVAIS remède DOUBLE les effets de la maladie."
	elseif fx.sType == "cureall" then
		return "Neutralise N'IMPORTE QUELLE affliction — maladie, poison, parasite — et referme les plaies."
			.. " Ne laisse aucune immunité derrière elle."
	end
	return ""
end

-- Items des etapes intermediaires du craft (donnes/echanges par le serveur au
-- fil des stations : broyage fait -> "pas terminee", melange fait -> "terminee").
HUB.PotionPrepItem     = "potion_preparation"
HUB.PotionPrepDoneItem = "potion_preparation_terminee"
HUB.PotionFailedItem   = "potion_ratee"

-- Recettes de potion (validees user 08/09) : tIngredients = { [item_id] = qte }.
-- Les ingredients sont CONSOMMES au lancement du broyage. Contraintes : max 3
-- varietes de champignons + max 3 plantes + max 3 cristaux differents, max 3
-- exemplaires each. Toutes les couleurs / tiers / varietes servent quelque part.
HUB.PotionPaliers = { "Décoctions", "Philtres", "Sérums", "Grands crus" }

local function K(t, color) return string.format("cristal_t%d_%s", t, color) end

-- PLANTES integrees a TOUTES les recettes (user 08/10, rien en prod) : chaque
-- recette demande 1 variete de plante (communes aux paliers I-II, rares aux
-- II-III, epiques aux III-IV), en restant a MAX 6 TYPES par melange (slots UI) —
-- les recettes qui etaient deja a 6 ont un ingredient REMPLACE par la plante.
HUB.PotionRecipes = {
	-- ── Palier I : Décoctions ────────────────────────────────────────────
	{ id = "decoction_trouble", sName = "Décoction trouble", nPalier = 1, sCat = "tonique",
	  sDesc = "Premier pas de tout apprenti : trouble, âcre, mais chargée.",
	  sQuote = "Ce qui est trouble n'est pas impur : c'est la clarté qui n'a pas encore choisi.",
	  tIngredients = { champignon_reiatsu = 3, bolet_hueco = 2, herbe_reishi = 2, [K(6, "carmin")] = 3, [K(5, "vert")] = 2 } },
	{ id = "tonique_sables", sName = "Tonique des sables", nPalier = 1, sCat = "stimulant",
	  sDesc = "Distillée sous le soleil blanc du Hueco Mundo.",
	  sQuote = "Le désert ne brise que ceux qui refusent de plier.",
	  tIngredients = { bolet_hueco = 3, chanterelle_garganta = 2, feuille_lune = 2, [K(6, "dore")] = 2, [K(5, "orange")] = 2, [K(4, "dore")] = 1 } },
	{ id = "sirop_spectral", sName = "Sirop spectral", nPalier = 1, sCat = "fortifiant",
	  sDesc = "Si limpide qu'on jurerait la fiole vide.",
	  sQuote = "La force la plus sûre est celle qu'on ne voit pas venir.",
	  tIngredients = { coprin_spectral = 3, amanite_ames = 2, herbe_reishi = 2, [K(6, "blanc")] = 2, [K(6, "cyan")] = 2, [K(5, "blanc")] = 2 } },
	{ id = "essence_verdoyante", sName = "Essence verdoyante", nPalier = 1, sCat = "essence",
	  sDesc = "Verte et vivante, elle frémit quand on la regarde trop longtemps.",
	  sQuote = "Tout ce qui vit apprend ; tout ce qui apprend grandit.",
	  tIngredients = { girolle_ectoplasme = 3, champignon_reiatsu = 2, trompette_limbes = 2, sauge_ames = 2, [K(6, "vert")] = 3, [K(5, "lime")] = 2 } },
	{ id = "brume_limbes", sName = "Brume des Limbes", nPalier = 1, sCat = "celerite",
	  sDesc = "S'évapore à moitié pendant la synthèse. L'autre moitié vaut le prix.",
	  sQuote = "Qui voyage léger arrive avant son ombre.",
	  tIngredients = { trompette_limbes = 3, coprin_spectral = 2, cepe_menos = 2, feuille_lune = 2, [K(6, "noir")] = 3, [K(5, "violet")] = 2 } },
	-- ── Palier II : Philtres ─────────────────────────────────────────────
	{ id = "elixir_encre", sName = "Élixir d'encre", nPalier = 2, sCat = "essence",
	  sDesc = "Noir total. Absorbe la lumière et un peu du courage de celui qui la boit.",
	  sQuote = "L'encre la plus noire écrit les vérités les plus claires.",
	  tIngredients = { cepe_menos = 3, trompette_limbes = 3, sauge_ames = 2, [K(5, "noir")] = 2, [K(5, "violet")] = 2, [K(4, "noir")] = 1 } },
	{ id = "philtre_carmin", sName = "Philtre carmin", nPalier = 2, sCat = "fortifiant",
	  sDesc = "La Lépiote y bat encore, dit-on.",
	  sQuote = "Un cœur qui bat encore n'a pas dit son dernier mot.",
	  tIngredients = { lepiote_carmine = 3, champignon_reiatsu = 2, herbe_reishi = 3, [K(5, "carmin")] = 2, [K(6, "rose")] = 2, [K(4, "carmin")] = 1 } },
	{ id = "nectar_seireitei", sName = "Nectar du Seireitei", nPalier = 2, sCat = "tonique",
	  sDesc = "Doux comme une aube sur les toits blancs de la Cour.",
	  sQuote = "La douceur répare ce que la force a défait.",
	  tIngredients = { morille_seireitei = 3, amanite_ames = 2, champignon_reiatsu = 2, lys_seireitei = 2, [K(5, "blanc")] = 3, [K(4, "dore")] = 1 } },
	{ id = "fiole_orage", sName = "Fiole d'orage", nPalier = 2, sCat = "celerite",
	  sDesc = "Secouer avant usage. Ou pas, si on aime les étincelles.",
	  sQuote = "L'éclair ne demande pas la permission au ciel.",
	  tIngredients = { chanterelle_garganta = 3, girolle_ectoplasme = 2, feuille_lune = 3, [K(5, "cyan")] = 3, [K(5, "bleu")] = 2, [K(4, "bleu")] = 1 } },
	{ id = "concentre_solaire", sName = "Concentré solaire", nPalier = 2, sCat = "fortifiant",
	  sDesc = "Un fragment de midi en bouteille.",
	  sQuote = "Midi n'a jamais douté de sa propre lumière.",
	  tIngredients = { bolet_hueco = 3, lepiote_carmine = 2, chardon_hueco = 2, [K(4, "dore")] = 2, [K(6, "orange")] = 3, [K(3, "orange")] = 1 } },
	{ id = "suc_abime", sName = "Suc d'abîme", nPalier = 2, sCat = "stimulant",
	  sDesc = "Remonté des profondeurs de la Forêt des Menos, goutte à goutte.",
	  sQuote = "C'est au fond du gouffre qu'on apprend la hauteur du ciel.",
	  tIngredients = { trompette_limbes = 3, cepe_menos = 3, morille_seireitei = 2, fougere_spectrale = 2, [K(4, "violet")] = 2, [K(5, "magenta")] = 2 } },
	{ id = "rosee_ame", sName = "Rosée d'âme", nPalier = 2, sCat = "tonique",
	  sDesc = "Chaque goutte pèse le souvenir d'une âme apaisée.",
	  sQuote = "Une âme apaisée pèse moins lourd qu'une larme.",
	  tIngredients = { amanite_ames = 2, morille_seireitei = 2, girolle_ectoplasme = 2, sauge_ames = 3, [K(5, "rose")] = 3, [K(4, "rose")] = 2 } },
	{ id = "philtre_prospecteur", sName = "Philtre du prospecteur", nPalier = 2, sCat = "essence",
	  sDesc = "Aiguise l'oeil pour la lueur du reiryoku figé dans la poussière d'un Hollow.",
	  sQuote = "Le cristal ne se cache pas : c'est le regard qui n'apprend que tard à le voir.",
	  tIngredients = { cepe_menos = 3, girolle_ectoplasme = 2, trompette_limbes = 2, fougere_spectrale = 2, [K(6, "dore")] = 2 } },
	{ id = "venin_lumineux", sName = "Venin lumineux", nPalier = 2, sCat = "stimulant",
	  sDesc = "Brille dans le noir. C'est précisément le problème.",
	  sQuote = "Ce qui brille dans le noir n'a plus rien à cacher.",
	  tIngredients = { girolle_ectoplasme = 3, coprin_spectral = 3, fougere_spectrale = 2, [K(4, "lime")] = 3, [K(6, "vert")] = 2, [K(3, "lime")] = 1 } },
	-- ── Palier III : Sérums ──────────────────────────────────────────────
	{ id = "serum_garganta", sName = "Sérum de Garganta", nPalier = 3, sCat = "celerite",
	  sDesc = "Stabilise ce qui ne devrait pas l'être. Un temps.",
	  sQuote = "Entre deux mondes, le plus court chemin est de ne pas s'arrêter.",
	  tIngredients = { chanterelle_garganta = 3, trompette_limbes = 2, liane_garganta = 2, [K(3, "magenta")] = 2, [K(5, "noir")] = 3, [K(4, "magenta")] = 2 } },
	{ id = "extrait_prismatique", sName = "Extrait prismatique", nPalier = 3, sCat = "stimulant",
	  sDesc = "Trois couleurs, trois humeurs, une seule fiole.",
	  sQuote = "Trois vérités valent mieux qu'une certitude.",
	  tIngredients = { fougere_spectrale = 2, lepiote_carmine = 2, girolle_ectoplasme = 2, [K(4, "bleu")] = 2, [K(4, "rose")] = 2, [K(4, "lime")] = 2 } },
	{ id = "huile_profondeurs", sName = "Huile des profondeurs", nPalier = 3, sCat = "essence",
	  sDesc = "Épaisse, froide, et étrangement attirante.",
	  sQuote = "La profondeur ne se mesure qu'en y descendant.",
	  tIngredients = { cepe_menos = 3, morille_seireitei = 3, liane_garganta = 2, [K(3, "bleu")] = 2, [K(4, "cyan")] = 2, [K(5, "bleu")] = 2 } },
	{ id = "ambroisie_carmine", sName = "Ambroisie carmine", nPalier = 3, sCat = "fortifiant",
	  sDesc = "Réservée aux tables des capitaines, quand elle arrive jusqu'à elles.",
	  sQuote = "Ce qui est rare n'est pas précieux ; ce qui est mérité l'est.",
	  tIngredients = { lepiote_carmine = 3, amanite_ames = 3, orchidee_carmine = 2, [K(3, "carmin")] = 2, [K(4, "carmin")] = 2, [K(6, "magenta")] = 2 } },
	-- ── Palier IV : Grands crus ──────────────────────────────────────────
	{ id = "larme_celeste", sName = "Larme céleste", nPalier = 4, sCat = "tonique",
	  sDesc = "Il paraît qu'elle tombe du Palais Royal. Personne n'a vérifié.",
	  sQuote = "Le ciel ne pleure pas : il rend ce qu'on lui a confié.",
	  tIngredients = { morille_seireitei = 3, amanite_ames = 3, lys_seireitei = 2, [K(2, "blanc")] = 1, [K(3, "dore")] = 3, [K(4, "blanc")] = 2 } },
	{ id = "sang_hollow", sName = "Sang de Hollow", nPalier = 4, sCat = "fortifiant",
	  sDesc = "Ce n'est pas du sang. C'est pire.",
	  sQuote = "Connais le monstre, pour ne jamais le devenir.",
	  tIngredients = { bolet_hueco = 3, trompette_limbes = 3, rose_vide = 2, [K(2, "carmin")] = 2, [K(3, "noir")] = 3, [K(5, "carmin")] = 3 } },
	{ id = "quintessence_primordiale", sName = "Quintessence primordiale", nPalier = 4, sCat = "essence",
	  sDesc = "L'aboutissement de tout le savoir du laboratoire. Une seule suffit à une carrière.",
	  sQuote = "Au bout de tout savoir commence l'humilité.",
	  tIngredients = { amanite_ames = 3, morille_seireitei = 3, orchidee_carmine = 2, [K(1, "blanc")] = 1, [K(2, "dore")] = 3, [K(3, "blanc")] = 3 } },
	-- ── TOXINES (potions nefastes : inoculent une maladie) ───────────────
	{ id = "toxine_ecarlate", sName = "Toxine écarlate", nPalier = 2, sCat = "toxine", nSkin = 1,
	  sDesc = "Un rouge trop vif pour être honnête. Fait bouillir le sang, au sens propre.",
	  sQuote = "Le poison le plus sûr ressemble à un remède.",
	  tIngredients = { lepiote_carmine = 2, coprin_spectral = 2, liane_garganta = 2, [K(5, "carmin")] = 3, [K(6, "vert")] = 1 } },
	{ id = "toxine_verdatre", sName = "Toxine verdâtre", nPalier = 3, sCat = "toxine", nSkin = 2,
	  sDesc = "Trouble et mouvante, elle semble respirer. Obstrue les canaux spirituels.",
	  sQuote = "Ce qui étouffe l'esprit n'a pas besoin de toucher le corps.",
	  tIngredients = { girolle_ectoplasme = 2, cepe_menos = 2, rose_vide = 1, [K(4, "vert")] = 2, [K(5, "lime")] = 3 } },
	{ id = "toxine_rose", sName = "Toxine rosée", nPalier = 4, sCat = "toxine", nSkin = 7,
	  sDesc = "Douce au regard, cruelle à la main. Engourdit les gestes du combattant.",
	  sQuote = "La plus jolie fleur est celle qu'on ne devrait pas cueillir.",
	  tIngredients = { lepiote_carmine = 3, girolle_ectoplasme = 2, rose_vide = 2, [K(3, "rose")] = 2, [K(4, "magenta")] = 1, [K(6, "rose")] = 3 } },
	-- ── REMEDES (antidotes apparies : le MAUVAIS remede aggrave) ─────────
	{ id = "remede_ecarlate", sName = "Remède écarlate", nPalier = 2, sCat = "remede", nSkin = 1,
	  sDesc = "Apaise le sang en feu de la Fièvre écarlate. Uniquement elle.",
	  sQuote = "On ne soigne bien que ce qu'on a compris.",
	  tIngredients = { amanite_ames = 2, champignon_reiatsu = 3, sauge_ames = 2, [K(5, "blanc")] = 2, [K(6, "carmin")] = 1 } },
	{ id = "remede_verdatre", sName = "Remède verdâtre", nPalier = 3, sCat = "remede", nSkin = 2,
	  sDesc = "Rouvre les canaux de reiatsu qu'étouffe la Peste verdâtre. Uniquement elle.",
	  sQuote = "Rendre le souffle est plus difficile que le couper.",
	  tIngredients = { morille_seireitei = 2, amanite_ames = 2, lys_seireitei = 2, [K(4, "blanc")] = 1, [K(5, "vert")] = 3 } },
	{ id = "remede_rose", sName = "Remède rosé", nPalier = 4, sCat = "remede", nSkin = 7,
	  sDesc = "Rend au bras sa fermeté volée par le Mal rosé. Uniquement lui.",
	  sQuote = "La main qui guérit doit être plus sûre que celle qui frappe.",
	  tIngredients = { amanite_ames = 3, morille_seireitei = 2, menthe_limbes = 2, [K(3, "blanc")] = 1, [K(5, "rose")] = 2 } },
	-- Recette VOLONTAIREMENT courte (« pas trop compliquee ») mais qui EXIGE
	-- un ingredient de CHAQUE monde : le Lys ne pousse qu'au Seireitei, le
	-- Chardon qu'au Hueco. On ne peut donc pas la produire sans passer le
	-- senkaimon ou la garganta, ce qui en fait un objet qui se negocie.
	{ id = "miraculeuse", sName = "Potion miraculeuse", nPalier = 3, sCat = "remede", nSkin = 0,
	  sDesc = "Limpide, presque tiede. Elle ne soigne pas une maladie : elle les chasse toutes.",
	  sQuote = "Ce qui guerit tout ne se trouve jamais au meme endroit.",
	  tIngredients = { champignon_reiatsu = 2, lys_seireitei = 2, chardon_hueco = 2, [K(5, "blanc")] = 2, [K(5, "vert")] = 1 } },
	-- ── Protection ───────────────────────────────────────────────────────
	-- Masque médical AU LABO aussi (user 08/24) : recette CONNUE D'OFFICE
	-- (bAlwaysKnown, honoré par recipeFound sv + recipeDiscovered cl) et
	-- résultat EXTERNE (bExternalResult : l'item est l'ACCESSOIRE défini par
	-- sh_science_medic, le générateur de fioles ne doit ni l'écraser ni créer
	-- de variantes étoilées). La variante arrancar est choisie à la remise.
	{ id = "masque_medical", sName = "Masque médical", nPalier = 1, sCat = "protection",
	  bAlwaysKnown = true, bExternalResult = true, sResult = "masque_medical",
	  sDesc = "Masque de protection contre les maladies : stérile, rien ne passe. S'use en 6 heures de port.",
	  sQuote = "Le premier geste du soin, c'est de ne pas devenir le prochain patient.",
	  tIngredients = { fougere_spectrale = 2, coprin_spectral = 2, herbe_reishi = 2, [K(6, "blanc")] = 2 } },
	-- ── Prothèses (user 09/20) ───────────────────────────────────────────
	-- CONNUES D'OFFICE des deux factions (bAlwaysKnown). Matériaux LOGIQUES (2e demande du
	-- jour : « du métal et autre, mais ça doit rester dur ») : ressources d'artisanat
	-- d'evo_craft + un cristal de reiryoku pour animer l'ensemble. Le DUR vient de la chaîne :
	-- métal brut = nœud RARE (10 à 24 min de repousse) ; os moyen = 4 petits os fondus à la
	-- forge, gros os = 16 ; CORDE = fabriquée à l'atelier ASSASSIN (6 petits os + 2 bois
	-- pièce), donc à négocier avec eux. Aucun ingrédient exclusif à une map.
	-- sFx = ligne d'effet du cahier (pas une fiole : rien dans PotionEffects).
	{ id = "prothese_main", sName = "Prothèse de main", nPalier = 2, sCat = "prothese",
	  bAlwaysKnown = true, bExternalResult = true, sResult = "prothese_main",
	  sDesc = "Main articulée : armature de métal brut, phalanges d'os, tendons de corde, et un cristal pour l'animer.",
	  sQuote = "Ce que la lame a pris, la patience peut le rendre.",
	  sFx = "Se pose au bloc par un scientifique, sur un patient allongé dont la main est coupée : le malus de PV max disparaît tant qu'elle est portée.",
	  tIngredients = { res_metal_brut = 3, res_os_moyen = 2, res_corde = 2, [K(5, "blanc")] = 2 } },
	{ id = "prothese_bras", sName = "Prothèse de bras", nPalier = 3, sCat = "prothese",
	  bAlwaysKnown = true, bExternalResult = true, sResult = "prothese_bras",
	  sDesc = "Bras complet, de l'épaule aux doigts : fût de métal calé à la roche, un gros os pour l'axe, trois cordes pour le tendre.",
	  sQuote = "Un bras ne remplace pas un bras. Il apprend seulement à faire le même travail.",
	  sFx = "Se pose au bloc par un scientifique, sur un patient allongé dont le bras est coupé : le malus de PV max disparaît tant qu'elle est portée.",
	  tIngredients = { res_metal_brut = 3, res_roche = 3, res_gros_os = 1, res_corde = 3, [K(5, "noir")] = 3, [K(4, "blanc")] = 1 } },
	-- ── Équipement (10/12, user) ─────────────────────────────────────────
	-- Lunettes d'analyse (« scouter ») : item défini par evo_craft/sh_lunettes. Craft de
	-- MI-NIVEAU = niveau scientifique 15/30 (nSciLevel, revalidé serveur à la synthèse).
	{ id = "lunettes_analyse", sName = "Lunettes d'analyse", nPalier = 2, sCat = "equipement",
	  bAlwaysKnown = true, bExternalResult = true, sResult = "lunettes_analyse", nSciLevel = 15,
	  sDesc = "Verres taillés dans le cristal de reiryoku, montés sur une armature de métal tendue à la corde.",
	  sQuote = "Mesurer quelqu'un, c'est déjà commencer à le comprendre.",
	  sFx = "Niveau scientifique 15 requis. Se portent (accessoire de tête) : affichent les PV, le reiatsu et l'art spirituel de la personne regardée. S'usent et se brisent : à refabriquer, la forge ne les répare pas.",
	  tIngredients = { res_metal_brut = 3, res_os_moyen = 1, res_corde = 1, [K(5, "cyan")] = 2, [K(4, "blanc")] = 1 } },
}

-- sResult implicite : potion_<id> (les items potions sont generes plus bas).
for _, r in ipairs(HUB.PotionRecipes) do
	r.sResult = r.sResult or ("potion_" .. r.id)
end

function EVO_SCIENCE.PotionRecipeById(sId)
	for _, r in ipairs(HUB.PotionRecipes) do
		if r.id == sId then return r end
	end
	return nil
end

-- Une recette a-t-elle des niveaux d'etoiles ? (toxines/remedes/protection :
-- NON — le masque est un accessoire externe, pas une fiole a etoiler.)
function EVO_SCIENCE.RecipeHasStars(r)
	return r ~= nil and r.sCat ~= "toxine" and r.sCat ~= "remede" and r.sCat ~= "protection"
		and not r.bExternalResult
end

-- Item resultat d'une recette au niveau demande (retombe sur le 1★ si la
-- recette n'a pas de niveaux).
function EVO_SCIENCE.PotionStarResult(r, nStar)
	if not r then return nil end
	if not EVO_SCIENCE.RecipeHasStars(r) then return r.sResult end
	return r.sResult .. (HUB.PotionStarSuffix[nStar or 1] or "")
end

-- Item eligible au MENU RAPIDE (case + radial de la spell bar). SOURCE UNIQUE lue par
-- lzy_spell_bar (radial + case) ET par l'option « Action rapide » de
-- l'inventaire — un nouveau consommable n'a qu'a passer ce test.
-- EXCLUS : champignons crus (risque de maladie, aucun bienfait — user 08/09),
-- preparations et bouteille vide (aucun on_use).
-- 3 familles, qui portent AUSSI le cooldown a afficher sur la case rapide :
--   "potion" -> CD de consommation 10 min (6 min pour un scientifique grade 16,
--               passif LZY_DIVISION_PASSIVES.GetPotionCdMult)   |   "plant" -> CD 30 s
--   "cure"   -> AUCUN CD : le serveur aiguille toxines/remedes vers la logique
--               maladies AVANT le test de CD (se soigner n'est jamais bloque),
--               donc afficher un compte a rebours dessus serait un MENSONGE.
function EVO_SCIENCE.QuickItemKind(sItemId)
	local s = tostring(sItemId or "")
	local it = ITEMS and ITEMS[s]
	if not (it and it.on_use) then return nil end
	-- Garde defensif : PlantEffects est defini PLUS BAS dans ce fichier ; une
	-- erreur de chargement entre les deux laisserait la fonction sans sa table.
	if HUB.PlantEffects and HUB.PlantEffects[s] then return "plant" end
	local sRid = EVO_SCIENCE.PotionParse(s)
	if not sRid then return nil end
	local fx = HUB.PotionEffects[sRid]
	if fx and (fx.sType == "toxine" or fx.sType == "remede" or fx.sType == "cureall") then return "cure" end
	return "potion" -- potions a effet (toutes etoiles) + potion ratee
end

-- Phrase d'effet d'un item du MENU RAPIDE, quelle que soit sa famille (potion
-- au bon niveau d'etoiles / toxine / remede / plante). SOURCE UNIQUE pour l'UI :
-- le radial l'affiche, et toute autre UI doit passer par ici plutot que de
-- re-deriver les effets. Renvoie (texte, bNefaste) — bNefaste sert a colorer en
-- ROUGE (convention projet : bonus vert, nefaste rouge). "" si inconnu.
function EVO_SCIENCE.QuickItemFxDesc(sItemId)
	local s = tostring(sItemId or "")
	local fxPlant = HUB.PlantEffects and HUB.PlantEffects[s]
	if fxPlant then return EVO_SCIENCE.PlantFxDesc(fxPlant), false end
	local sRid, nStar = EVO_SCIENCE.PotionParse(s)
	if not sRid then return "", false end
	local fx = HUB.PotionEffects[sRid]
	if not fx then
		-- Potion ratee : aucune vertu, mais le risque doit etre annonce.
		if s == HUB.PotionFailedItem then
			return "Aucun effet — et une chance sur trois de tomber malade.", true
		end
		return "", false
	end
	return EVO_SCIENCE.PotionFxDesc(fx, nStar), fx.sType == "toxine"
end


-- potion_<rid>[_2e|_3e] -> rid, nStar (nil si pas un item de potion).
function EVO_SCIENCE.PotionParse(sItemId)
	local s = tostring(sItemId or "")
	local sBase, sStar = s:match("^potion_(.+)_([23])e$")
	if sBase then return sBase, tonumber(sStar) end
	local sRid = s:match("^potion_(.+)$")
	if sRid then return sRid, 1 end
	return nil
end

-- ── Recolte : ZONES DE RESSOURCES dediees (champignons + plantes) ────────────
-- Spots releves en jeu par le user (Seireitei 08/12, Hueco 08/18). Ils
-- REMPLACENT les zones de chasse des PNJ, qui servaient de source jusque-la :
-- les ressources ne poussent plus forcement la ou les mobs spawnent.
-- NCM_PNJ.GetHuntSpawnPositions reste le REPLI pour les maps absentes de cette
-- table (gm_construct).
-- Le z vient du getpos console = hauteur des YEUX : aucune importance ici, le
-- sol est retrace sous chaque point tire (groundSpot, sv_science_harvest).
HUB.HarvestZones = {
	["hueco_mundo_v1"] = {
		-- FORET DES MENOS : spots AU PIED D'UN ARBRE (setpos user 08/21), les memes
			-- que les noeuds de BOIS. Les spots de roche de cet etage ne portent que
			-- du mineral (cf. EVO_CRAFT.ResNodes.Spots.roche).
			Vector(1732.019531, -5563.835449, -12696.071289), Vector(2492.534912, -5354.350098, -12742.371094),
			Vector(4288.293457, -4980.434570, -12821.916992), Vector(5500.098145, -6008.006348, -12783.112305),
			Vector(4670.494629, -3415.528564, -12774.576172), Vector(7960.848633, -732.622986, -12151.957031),
			Vector(2585.530273, 1086.248901, -12232.030273), Vector(584.266602, -2277.711670, -12817.770508),
			Vector(-1279.890869, -1336.552124, -12837.324219), Vector(-3317.526611, -1077.285156, -12902.457031),
			Vector(-2529.935059, -6177.611816, -12846.502930), Vector(-4370.027344, -7173.111328, -12910.006836),
			Vector(-9653.166992, -6617.644531, -12908.390625), Vector(-6174.015137, -1314.729492, -12867.388672),
			Vector(3659.276367, -493.487946, -12531.340820),
			-- ZONE NEUTRE 1 : spots AU PIED D'UN ARBRE (setpos user 08/21), les memes
			-- que les noeuds de BOIS d'artisanat. Les spots de roche de cet etage ne
			-- portent que du mineral (cf. EVO_CRAFT.ResNodes.Spots).
			Vector(-11147.777344, 2205.876709, 186.608002), Vector(-11029.721680, 4307.650391, 372.094238),
			Vector(-11595.985352, 9386.205078, 352.148010), Vector(-7722.964844, 9669.376953, 579.823914),
			Vector(-6728.293457, 9537.050781, 235.603088), Vector(-5624.445312, 12389.028320, 116.432770),
			Vector(-4671.513184, 11193.656250, 131.874619), Vector(-3283.162842, 11604.862305, 116.406097),
			Vector(-4768.748535, 9680.713867, 124.635391), Vector(-2600.476562, 9367.439453, 114.849663),
			Vector(-960.999084, 9843.613281, 322.014740), Vector(-290.353577, 10820.899414, 407.135040),
			Vector(-3437.257812, 7204.451172, 487.950897), Vector(-3171.622314, 1225.757935, 127.940369),
			Vector(-3508.088379, -446.994751, 550.573242), Vector(-5984.545410, 65.829468, 170.617401),
			Vector(-6476.841797, 2201.324951, 116.165245), Vector(-7808.556152, 824.149414, 142.292694),
			Vector(-8643.015625, 1080.038574, 300.101166), Vector(-8410.327148, -2356.822021, 172.023788),
			Vector(-9295.221680, -4808.507324, 112.653564), Vector(-7741.430176, -9389.465820, 66.564926),
			Vector(-4068.131836, -6663.016113, 190.841599), Vector(-3047.846191, -3517.831055, 416.014679),
			Vector(1268.223755, -6308.476074, 372.628998), Vector(651.652527, -3647.924316, 359.153961),
			Vector(-740.893433, -2574.877930, 107.445999), Vector(640.724854, 132.331207, 359.637482),
			Vector(-209.360031, 2334.907715, 271.901031), Vector(1489.558960, 6399.472168, 419.855133),
			Vector(6460.336426, 10135.841797, 47.889576), Vector(7984.649902, 11682.328125, 112.653595),
			Vector(10525.171875, 12473.143555, 239.224380), Vector(10023.343750, 10181.047852, 115.975296),
			Vector(11580.211914, 9189.974609, 123.178268), Vector(7652.586914, 7530.593262, 130.505096),
			Vector(8818.588867, 4670.314941, 168.557678), Vector(10331.311523, 3772.634521, 348.248383),
			Vector(11515.429688, 1458.718628, 399.399841), Vector(6791.215820, -3140.123291, 532.562134),
			Vector(9043.714844, -7444.108398, 115.510010), Vector(11502.132812, -7557.608398, 119.633286),
			Vector(6169.749023, -9690.360352, 420.188812), Vector(4289.363770, -9550.813477, 174.917969),
			Vector(4822.060547, 2352.157227, 117.432770), Vector(4889.741699, 2081.410400, 130.373459),
			-- ZONE NEUTRE 2 (étage haut, z ~ 9070/11120 ; relevé user 08/18)
		Vector( -7666.69,  -8500.71,  10417.91),
		Vector( -8638.46,  -7311.87,   9841.91),
		Vector(-11049.04, -12786.45,  10609.91),
		Vector(-11425.77, -11830.59,   9887.43),
		Vector( -9551.94,  -3103.08,   9772.83),
		Vector(-11417.83,    521.42,  10609.91),
		Vector( -9049.97,   2670.15,   9143.51),
		Vector( -6108.68,  -2465.87,   9145.45),
		Vector(  -466.20,  -3722.26,  10097.91),
		Vector( -3948.73, -10968.45,   9528.61),
		Vector( -3173.53, -11871.77,   9481.50),
		Vector(   933.84,  -9961.28,   9268.29),
		Vector(  6321.56, -10344.72,   9199.64),
		Vector(  5956.69, -12157.05,   9383.76),
		Vector( 12419.83, -10289.35,   9601.80),
		Vector(  8195.51,  -4277.60,  10353.91),
		Vector(  8596.14,   1960.78,   9495.88),
		Vector(  3226.57,   1644.14,   9073.91),
		Vector(  2746.75,   9885.80,   9598.41),
		Vector(  4836.58,  10675.74,   9585.91),
		Vector(  6117.10,  12234.39,   9835.25),
		Vector( 10074.84,   8513.33,   9073.91),
		Vector(  9737.73,   3980.99,   9585.80),
		Vector(  5530.73,  -4129.76,  10353.91),
		Vector(  3003.09,  -5820.83,   9073.91),
		Vector( -5802.49,   6298.47,  11121.91),
		Vector( -3808.79,   6671.34,  10481.91),
	},
	["rp_seireitei_v1"] = {
		-- Spots AU PIED D'UN ARBRE (setpos user 08/21) : c'est là que poussent
		-- champignons et plantes, comme le bois d'artisanat (même liste, cf.
		-- EVO_CRAFT.ResNodes.Spots). Les spots de ROCHE ne portent que du
		-- minéral. Le z est une hauteur d'YEUX : le sol est retracé sous chaque
		-- point (groundSpot), et la bande d'altitude trie déjà les exclusives.
		-- ZONE NEUTRE I (étage profond)
		Vector(-3315.241455, -579.313538, -14855.953125), Vector(-2080.011963, -242.717636, -14806.134766),
		Vector(-2133.418945, 624.178467, -14984.857422), Vector(-3535.882568, 2257.216064, -14940.827148),
		Vector(-4025.004883, 3575.074463, -14970.413086), Vector(-6356.397461, 6973.779785, -14929.737305),
		Vector(-4364.365723, 6405.996582, -14967.178711), Vector(-2148.016602, 5013.530762, -14415.805664),
		Vector(-964.124207, 4779.343262, -14414.011719), Vector(-615.614685, 3851.720947, -14715.357422),
		Vector(1036.558838, -164.389206, -14965.582031), Vector(1817.400635, -1774.567871, -14564.201172),
		Vector(4484.657715, -587.876587, -14760.712891), Vector(4587.947266, 1018.120972, -14774.686523),
		Vector(6362.038574, 141.505722, -14290.026367), Vector(7502.056152, -1038.651367, -14385.041016),
		Vector(9446.354492, 183.490662, -14410.398438), Vector(9849.241211, -8831.277344, -14448.049805),
		Vector(8020.000488, -9924.035156, -14447.188477), Vector(4504.413086, -11003.820312, -13868.833984),
		Vector(2876.103760, -5500.395996, -14276.909180), Vector(-4358.968750, -9636.852539, -13794.949219),
		Vector(-7088.350098, -6125.350098, -14957.811523), Vector(13122.911133, 6887.489746, -14292.000977),
		Vector(-4098.683105, 7989.226562, -14720.955078),
		-- ZONE NEUTRE II (étage médian)
		Vector(-5053.442871, -6042.883301, -6626.001953), Vector(-5716.255859, -4672.599121, -6566.414062),
		Vector(-3577.322021, 76.262321, -6435.792969), Vector(-2051.273682, 382.320282, -6194.570801),
		Vector(-4564.437500, 3305.484375, -7089.937988), Vector(-2369.838135, 7223.993164, -6919.721680),
		Vector(-237.784180, 9234.956055, -6636.257324), Vector(1459.268555, 6700.955078, -6408.250488),
		Vector(1248.960205, 1207.822266, -6301.340332), Vector(4659.819824, 3020.423096, -5856.489746),
		Vector(4095.077393, 9719.189453, -5518.920898), Vector(9747.894531, 10617.436523, -5510.249512),
		Vector(12841.492188, 11706.697266, -5526.444336), Vector(13737.712891, 6041.203613, -6432.926270),
		Vector(11503.961914, 4192.210938, -5530.559570), Vector(7645.256836, 2325.671387, -6040.391113),
		Vector(8128.967285, 1692.625122, -6566.269531), Vector(9897.722656, -1274.364502, -7304.933594),
		Vector(12355.465820, -1386.096069, -7343.170898), Vector(14045.417969, -3997.582764, -6388.431152),
		Vector(12287.080078, -9284.845703, -6438.158691), Vector(9035.249023, -11366.018555, -6365.876465),
		Vector(6300.447754, -8042.061035, -5843.308105), Vector(3675.347900, -9819.724609, -7268.990723),
		Vector(-4251.027344, -6901.470703, -5817.579102), Vector(-7138.874023, -6513.131836, -5778.671875),
		Vector(1419.922974, -11476.750977, -5147.075684), Vector(-2733.118896, 2073.268066, -5932.602539),
		Vector(-6889.410156, 9638.158203, -6399.505371), Vector(13391.309570, -10924.933594, -5620.207520),
		Vector(-428.450165, -2974.754639, -7234.766602),
	},
	["rp_shinonome_evo"] = {
		-- ZONE NEUTRE « Monde des vivants » : 88 poses user 08/27, les MÊMES que les
		-- nœuds d'artisanat (EVO_CRAFT.ResNodes.Spots, liste plate) : GARDER EN PHASE.
		-- Le z est une hauteur d'yeux : le sol est retracé sous chaque point (groundSpot).
		Vector(4521.968262, 10067.981445, 102.238953), Vector(4937.665039, 9588.258789, 147.378052),
		Vector(4834.128906, 9118.127930, 139.094727), Vector(4847.436035, 8796.525391, 55.454903),
		Vector(4863.093262, 8283.018555, 23.859695), Vector(4973.373047, 8241.860352, 26.552544),
		Vector(4750.619141, 8134.123047, 54.727650), Vector(4528.117676, 8179.876465, 47.069275),
		Vector(4281.970215, 8263.215820, 37.312546), Vector(4523.014648, 7859.812500, 119.685493),
		Vector(4723.356445, 7574.263184, 103.786118), Vector(6617.733398, 7691.641113, 25.629955),
		Vector(6755.808105, 7398.660645, 27.214821), Vector(7096.358887, 7423.828125, 154.257187),
		Vector(7465.734375, 7251.651855, 338.286011), Vector(7531.201172, 7925.617188, 276.668793),
		Vector(7405.217285, 8038.060059, 266.828217), Vector(7330.594238, 7931.926758, 271.497467),
		Vector(7778.344238, 8886.363281, 48.132793), Vector(7922.279785, 9029.986328, 63.974308),
		Vector(7971.419434, 8877.537109, 63.812477), Vector(7907.470703, 8685.328125, 96.999466),
		Vector(8115.218262, 9149.496094, 114.773178), Vector(8302.227539, 9376.656250, 121.795395),
		Vector(8556.700195, 9747.966797, 68.780533), Vector(8996.122070, 9902.449219, 129.191437),
		Vector(9128.985352, 9795.475586, 141.601456), Vector(8679.465820, 11085.359375, 28.855499),
		Vector(8483.678711, 11269.507812, 32.749237), Vector(8272.376953, 11294.768555, 33.129730),
		Vector(7239.193848, 11260.934570, 68.985229), Vector(6722.607422, 12044.938477, 69.353424),
		Vector(6708.830078, 12170.879883, 66.809235), Vector(6585.615234, 12070.348633, 76.440155),
		Vector(6347.488281, 12580.759766, 67.969109), Vector(6348.006348, 12755.593750, 69.724274),
		Vector(6329.131836, 12828.946289, 69.454025), Vector(6309.015625, 12909.653320, 56.513218),
		Vector(6590.034180, 13361.239258, 57.688797), Vector(6535.819824, 13419.093750, 51.904282),
		Vector(6511.006348, 13548.356445, 40.689178), Vector(6285.667969, 14071.965820, 37.852627),
		Vector(6361.932129, 14062.930664, 26.960701), Vector(5714.693848, 14344.956055, 39.595577),
		Vector(5542.680176, 14363.251953, 55.832878), Vector(5279.924316, 14295.725586, 42.947113),
		Vector(5170.030762, 14290.000977, 57.133728), Vector(4250.345215, 14254.798828, 14.068039),
		Vector(4090.547119, 14225.445312, -11.767578), Vector(4176.938477, 14026.004883, 37.632423),
		Vector(3498.540039, 13952.382812, 39.193123), Vector(2772.719482, 13944.787109, 69.618660),
		Vector(2749.540039, 14045.412109, 63.526169), Vector(2825.700928, 14358.306641, 83.537025),
		Vector(3182.188232, 14482.003906, 94.404839), Vector(3347.059570, 13495.329102, 29.116405),
		Vector(3649.429932, 13320.060547, 25.701942), Vector(3607.275146, 13222.621094, 20.353607),
		Vector(3607.807861, 13146.097656, 19.515846), Vector(3516.084961, 13004.990234, 12.758564),
		Vector(3438.641602, 12984.484375, 12.750202), Vector(2813.142822, 12724.081055, 37.431480),
		Vector(2715.479736, 12577.101562, 51.018272), Vector(2595.681885, 12406.000000, 46.307285),
		Vector(2599.965332, 12333.958984, 27.541065), Vector(2471.175537, 12153.077148, 41.808517),
		Vector(2424.507080, 11962.286133, 31.227539), Vector(2790.803711, 11875.782227, 34.248859),
		Vector(2749.212891, 11956.457031, 10.773010), Vector(2614.306152, 11050.438477, 38.366524),
		Vector(2499.951172, 11142.869141, 58.372768), Vector(2400.094971, 11096.461914, 66.074287),
		Vector(1875.063354, 10415.830078, 40.221756), Vector(1709.616577, 10336.013672, 29.285347),
		Vector(1432.482788, 10199.725586, 84.574997), Vector(1508.187256, 10021.957031, 128.217255),
		Vector(1867.329834, 9621.833008, 350.392273), Vector(1969.717773, 9760.625000, 363.273407),
		Vector(1524.298706, 9054.033203, 34.062271), Vector(1271.777222, 8879.165039, -18.230621),
		Vector(1007.727661, 8843.318359, 1.117287), Vector(851.026306, 8693.041016, 13.036060),
		Vector(737.590088, 8484.173828, 0.651119), Vector(728.112610, 8296.714844, -4.711136),
		Vector(698.663940, 8021.452637, 27.805630), Vector(732.999390, 7795.365234, 36.747574),
		Vector(1229.290039, 7872.961426, 14.791298), Vector(1484.896851, 7868.409180, 5.839417),
	},
}

-- Zones de recolte de la map : liste dediee si elle existe, sinon REPLI sur les
-- zones de chasse des PNJ (maps pas encore relevees). Source UNIQUE du spawner.
function EVO_SCIENCE.HarvestZonesFor(sMap)
	local t = HUB.HarvestZones[sMap]
	if istable(t) and #t > 0 then return t end
	if NCM_PNJ and NCM_PNJ.GetHuntSpawnPositions then
		return NCM_PNJ.GetHuntSpawnPositions(sMap)
	end
	return nil
end

-- ── RARETE AU SPAWN + EXCLUSIVITE DE MONDE (user 08\12) ──────────────────────
-- 1) Toutes les varietes ne se tirent PLUS a poids egal : le poids vient de la
--    rarete, donc les ingredients des meilleures recettes sont les plus durs a
--    trouver. Avec les listes actuelles : une commune ~21-24% du tirage, une
--    rare ~10%, une epique ~4% (avant : 10% chacune, quelle que soit la
--    rarete — un epique sortait aussi souvent qu'une commune).
HUB.HarvestRarityWeights = { common = 100, rare = 45, epic = 18 }

-- 2) Certaines varietes ne poussent QUE dans un monde (champ `map` des listes
--    ci-dessous ; absent = pousse partout). Consequence voulue : les Grands crus
--    demandent des ingredients des DEUX mondes, il faut donc passer le
--    senkaimon / la garganta pour les fabriquer. Les COMMUNES restent partout,
--    et les REMEDES n'utilisent que des ingredients universels — se soigner ne
--    doit jamais dependre d'un voyage.
-- La zone neutre est DÉCLARÉE pour que les EXCLUSIVES d'un monde n'y poussent PAS
-- (map hors table = mode dev, TOUT pousse — le Monde des vivants ne doit pas
-- court-circuiter le voyage Senkaimon/Garganta qu'exigent les Grands crus).
HUB.HarvestMaps = { ["rp_seireitei_v1"] = true, ["hueco_mundo_v1"] = true, ["rp_shinonome_evo"] = true }

-- 3) Les EXCLUSIVES d'un monde ne poussent QUE dans sa ZONE NEUTRE II (user
--    08/21) : bandes d'ALTITUDE des spots concernés (robuste à l'ajout de
--    spots, le z de config est une hauteur d'yeux). Les autres étages (zones
--    neutres I, forêt des Menos) ne sortent que des variétés universelles.
HUB.HarvestExcluBands = {
	["rp_seireitei_v1"] = { zMin = -8000, zMax = -4500 }, -- Zone Neutre II (étage médian)
	["hueco_mundo_v1"]  = { zMin = 8500,  zMax = 11500 }, -- Zone Neutre 2 (étage haut)
}

-- Ce SPOT peut-il faire pousser les variétés EXCLUSIVES du monde ? Map sans
-- bande déclarée (dev, repli zones de chasse) : oui partout.
function EVO_SCIENCE.HarvestSpotAllowsExclu(sMap, vSpot)
	local b = HUB.HarvestExcluBands[sMap]
	if not b or not vSpot then return true end
	return vSpot.z >= b.zMin and vSpot.z <= b.zMax
end

-- Une variete pousse-t-elle sur cette map ? Sur une map de DEV (gm_construct,
-- absente de HarvestMaps) tout pousse : sinon plus rien a tester en local.
function EVO_SCIENCE.HarvestAllowsVariety(v, sMap)
	if not (v and v.map) then return true end
	if not HUB.HarvestMaps[sMap] then return true end
	return v.map == sMap
end

-- Phrase d'origine affichee sur l'item (le joueur doit pouvoir savoir OU
-- chercher sans lire le Lua). Source unique des deux boucles d'items.
function EVO_SCIENCE.HarvestOriginDesc(v)
	if not (v and v.map) then return "Pousse dans les deux mondes." end
	if v.map == "hueco_mundo_v1" then return "Ne pousse QUE dans le Hueco Mundo." end
	return "Ne pousse QUE dans la Soul Society."
end

-- Tirage d'une variete : filtre la map courante puis pondere par RARETE.
-- SOURCE UNIQUE des deux spawners (champignons ET plantes).
-- bAllowExclu = false (spot HORS Zone Neutre II) : les varietes a champ `map`
-- (exclusives d'un monde) sont exclues du tirage — universelles seulement.
function EVO_SCIENCE.RollHarvestVariety(tList, sMap, bAllowExclu)
	local pool, nTotal = {}, 0
	for _, v in ipairs(tList or {}) do
		if EVO_SCIENCE.HarvestAllowsVariety(v, sMap)
			and (bAllowExclu ~= false or not v.map) then
			local w = HUB.HarvestRarityWeights[v.rarity] or 1
			nTotal = nTotal + w
			pool[#pool + 1] = { v = v, w = w }
		end
	end
	if nTotal <= 0 then return nil end
	local r, acc = math.random() * nTotal, 0
	for _, e in ipairs(pool) do
		acc = acc + e.w
		if r <= acc then return e.v end
	end
	return pool[#pool].v -- garde-fou arrondi flottant
end

-- Ramassage a la touche E au-dessus du prop -> item champignon dans le sac.
HUB.MushroomModels = {
	"models/evo/props/items/mushroom/mushroom_01/evo_k7m2v9qx4p.mdl",
	"models/evo/props/items/mushroom/mushroom_02/evo_r5t8n3wc6j.mdl",
	"models/evo/props/items/mushroom/mushroom_03/evo_z4h7b2kf9s.mdl",
	"models/evo/props/items/mushroom/mushroom_04/evo_p8x3m6dr2v.mdl",
	"models/evo/props/items/mushroom/mushroom_05/evo_f6q9c4ty7n.mdl",
	"models/evo/props/items/mushroom/mushroom_06/evo_w3j8s5kp2m.mdl",
	"models/evo/props/items/mushroom/mushroom_07/evo_n9v4d7rx6b.mdl",
	"models/evo/props/items/mushroom/mushroom_08/evo_c2m7q5zh8k.mdl",
	"models/evo/props/items/mushroom/mushroom_09/evo_t6b3w9fn4x.mdl",
	"models/evo/props/items/mushroom/mushroom_10/evo_h8r5k2vc7q.mdl",
	"models/evo/props/items/mushroom/mushroom_11/evo_m4x9p6jd3s.mdl",
	"models/evo/props/items/mushroom/mushroom_12/evo_q7n2f8wb5r.mdl",
	"models/evo/props/items/mushroom/mushroom_13/evo_v5c3z9kt6m.mdl",
	"models/evo/props/items/mushroom/mushroom_14/evo_j2s7r4px8n.mdl",
	"models/evo/props/items/mushroom/mushroom_15/evo_b9k6m3qh5v.mdl",
	"models/evo/props/items/mushroom/mushroom_16/evo_x4w8n2df7c.mdl",
	"models/evo/props/items/mushroom/mushroom_17/evo_d7p5v9sj3k.mdl",
	"models/evo/props/items/mushroom/mushroom_18/evo_s3q6x8mr4b.mdl",
	"models/evo/props/items/mushroom/mushroom_19/evo_g8v2k7tn5p.mdl",
	"models/evo/props/items/mushroom/mushroom_20/evo_y5m9c3wf6r.mdl",
}
-- 10 varietes d'ingredients, 2 apparences chacune (indices dans MushroomModels).
-- Les 20 modeles spawnent TOUS sur les 2 maps, sans reserve ; chaque map
-- applique la meme logique independamment (serveurs separes).
HUB.Mushrooms = {
	{ id = "champignon_reiatsu",   name = "Champignon de reiatsu",   rarity = "common", models = { 1, 2 },
	  desc = "Le champignon spirituel le plus répandu. Base de la plupart des décoctions." },
	{ id = "amanite_ames",         name = "Amanite des Âmes",        rarity = "rare",   models = { 3, 4 },
	  desc = "Chair blanc laiteux gorgée d'énergie pure. Prisée pour les synthèses de haut vol." },
	{ id = "morille_seireitei",    name = "Morille du Seireitei",    rarity = "rare",   models = { 5, 6 }, map = "rp_seireitei_v1",
	  desc = "Pousse à l'ombre des murs de pierre. Alvéoles chargées de reiatsu stable." },
	{ id = "bolet_hueco",          name = "Bolet du Hueco",          rarity = "common", models = { 7, 8 },
	  desc = "Endurci par le désert. Son pied fibreux résiste au broyeur le plus affûté." },
	{ id = "cepe_menos",           name = "Cèpe des Menos",          rarity = "rare",   models = { 9, 10 }, map = "hueco_mundo_v1",
	  desc = "Noir comme la Forêt des Menos qui le voit naître. Amertume spirituelle intense." },
	{ id = "trompette_limbes",     name = "Trompette des Limbes",    rarity = "rare",   models = { 11, 12 },
	  desc = "Croît entre deux mondes. Son parfum évoque le vide d'une Garganta ouverte." },
	{ id = "coprin_spectral",      name = "Coprin spectral",         rarity = "rare",   models = { 13, 14 },
	  desc = "Translucide, presque invisible. Se dissout en brume au moindre faux geste." },
	{ id = "girolle_ectoplasme",   name = "Girolle d'ectoplasme",    rarity = "epic",   models = { 15, 16 },
	  desc = "Luminescence verte instable. Manipuler avec des gants doublés de reishi." },
	{ id = "lepiote_carmine",      name = "Lépiote carmine",         rarity = "epic",   models = { 17, 18 }, map = "rp_seireitei_v1",
	  desc = "Rouge sang, nervures pulsantes. Certains jurent l'avoir entendue battre." },
	{ id = "chanterelle_garganta", name = "Chanterelle de Garganta", rarity = "epic",   models = { 19, 20 }, map = "hueco_mundo_v1",
	  desc = "Chapeau déchiré strié de noir, comme entaillé par le passage d'un Hollow." },
}

-- Regles de spawn. L'ABONDANCE du 08/19 (« il peut y en avoir beaucoup sur la
-- map ») est REVENUE DE MOITIE le 08/22 (user « reduire le taux de spawn ») :
-- vague et plafond divises par deux, cadence de vague INCHANGEE (10 min) pour
-- ne pas changer le rythme d'apparition, juste la quantite. Un champignon
-- RESTE tant qu'il n'est pas ramasse.
-- Redivisés le 08/28 (user « réduit énormément ») : même cadence, encore
-- moins de props par vague et au plafond.
HUB.MushroomWaveSize    = 3
HUB.MushroomWaveSec     = 600
HUB.MushroomMaxAlive    = 10
HUB.MushroomScatter     = 380 -- dispersion autour du point de zone (HarvestZones)
-- REPARTITION : plafond de props VIVANTS par spot, toutes familles confondues
-- (champignons + plantes) — une vague sert plusieurs zones au lieu de tout
-- deverser au meme endroit. Porte sur les props VIVANTS et pas sur la vague :
-- un prop RESTE jusqu'au ramassage, sinon les vagues rempileraient au meme
-- endroit. 2 ou 3 par pied d'arbre (user 08/21) : peu a chaque endroit, mais
-- BEAUCOUP d'endroits servis — c'est HarvestMaxZones qui porte l'abondance.
HUB.HarvestPerZoneMin   = 2
HUB.HarvestPerZoneMax   = 3

-- Nombre de spots portant de la recolte EN MEME TEMPS. Avec 2-3 props par spot
-- et ~110 props vivants au plafond, il en faut beaucoup : sinon tout s'entasse
-- sur une poignee de pieds d'arbre et le reste de la foret est vide.
HUB.HarvestMaxZones     = 50

-- Modele (minuscules) -> variete. Construit une fois, partage cl + sv.
local _byModel
function EVO_SCIENCE.MushroomByModel(sModel)
	if not _byModel then
		_byModel = {}
		for _, v in ipairs(HUB.Mushrooms) do
			for _, nIdx in ipairs(v.models) do
				local m = HUB.MushroomModels[nIdx]
				if m then _byModel[string.lower(m)] = v end
			end
		end
	end
	return _byModel[string.lower(tostring(sModel or ""))]
end
HUB.HarvestRange       = 120  -- portee du prompt E cote client
HUB.HarvestRangeServer = 200  -- revalidation serveur (marge : jamais < client)

-- ── Plantes (user 08/10) : MEME vegetal en 3 TAILLES de prop ; la VARIETE est
-- portee par le SKIN ($texturegroup skinfamilies, 10 familles). La taille ne
-- change PAS l'item donne — elle change la QUANTITE : petite = 1 exemplaire,
-- moyenne = 2, grande = 3 de LA MEME plante.
HUB.PlantModels = {
	{ model = "models/evo/props/items/plants/plants_01/evo_u8dwaEdKMAgaAhy1rYct.mdl", nGive = 1 }, -- petite
	{ model = "models/evo/props/items/plants/plants_02/evo_QHM1LFmsa7upEsEI7HaX.mdl", nGive = 2 }, -- moyenne
	{ model = "models/evo/props/items/plants/plants_03/evo_V9Yoxr6Xa4VvBUKscyiK.mdl", nGive = 3 }, -- grande
}
-- Poids de tirage des tailles au spawn (petite courante, grande rare).
HUB.PlantSizeWeights = { 60, 30, 10 }
-- 10 varietes = skins 0..9 des modeles, DANS L'ORDRE du $texturegroup.
HUB.Plants = {
	{ id = "herbe_reishi",      name = "Herbe à reishi",      rarity = "common",
	  desc = "Brins gorgés de particules spirituelles. La base de toute décoction végétale." },
	{ id = "feuille_lune",      name = "Feuille de lune",     rarity = "common",
	  desc = "Ne pousse qu'à la lumière pâle. Sa sève apaise les circuits de reiatsu." },
	{ id = "sauge_ames",        name = "Sauge des Âmes",      rarity = "common",
	  desc = "Brûlée en offrande depuis des siècles. Fraîche, elle garde tout son pouvoir." },
	{ id = "fougere_spectrale", name = "Fougère spectrale",   rarity = "rare",
	  desc = "Ses frondes traversent la main qui les cueille mal. Manipulation délicate." },
	{ id = "liane_garganta",    name = "Liane de Garganta",   rarity = "rare", map = "hueco_mundo_v1",
	  desc = "Fibres noires nées entre deux mondes. Résiste à toutes les lames ordinaires." },
	{ id = "lys_seireitei",     name = "Lys du Seireitei",    rarity = "rare", map = "rp_seireitei_v1",
	  desc = "Fleur blanche des jardins nobles. Son pollen stabilise les synthèses." },
	{ id = "chardon_hueco",     name = "Chardon du Hueco",    rarity = "rare", map = "hueco_mundo_v1",
	  desc = "Épines durcies par le sable blanc. Piquant, mais d'une pureté rare." },
	{ id = "menthe_limbes",     name = "Menthe des Limbes",   rarity = "epic",
	  desc = "Parfum glacé qui évoque le passage d'une âme. Recherchée des maîtres brasseurs." },
	{ id = "orchidee_carmine",  name = "Orchidée carmine",    rarity = "epic", map = "rp_seireitei_v1",
	  desc = "Pétales rouge sang aux nervures pulsantes. Certains jurent qu'elle respire." },
	{ id = "rose_vide",         name = "Rose du Vide",        rarity = "epic", map = "hueco_mundo_v1",
	  desc = "Éclot au bord des Gargantas. Son cœur noir absorbe la lumière alentour." },
}
-- Skin par variete (position dans la liste) : partage item + spawn + tirage.
for i, v in ipairs(HUB.Plants) do v.nSkin = i - 1 end

-- Spawn : meme mecanique de vagues que les champignons, compteurs separes.
-- Divises par deux le 08/22, meme decision que les champignons.
-- Redivisées le 08/28, même décision que les champignons.
HUB.PlantWaveSize = 2
HUB.PlantMaxAlive = 8


HUB.PlantUseCD = 30 -- s entre deux plantes machees, INDEPENDANT du CD potions
HUB.PlantEffects = {
	-- COMMUNES : le plus petit palier.
	herbe_reishi      = { sType = "reiatsu", nMult = 1.2, nSec = 45 },
	feuille_lune      = { sType = "reiatsu", nMult = 1, nCostPct = 5, nSec = 45 },
	sauge_ames        = { sType = "heal",    nPct = 4 },
	-- RARES.
	chardon_hueco     = { sType = "damage",  nPct = 4, nSec = 60 },
	liane_garganta    = { sType = "resist",  nPct = 5, nSec = 60 },
	fougere_spectrale = { sType = "flashcd", nPct = 8, nSec = 60 },
	lys_seireitei     = { sType = "regen",   nRegenPct = 0.4, nSec = 20 },
	-- EPIQUES.
	menthe_limbes     = { sType = "xp",      nPct = 10, nSec = 120 },
	orchidee_carmine  = { sType = "damage",  nPct = 7, nSec = 90 },
	rose_vide         = { sType = "reiatsu", nMult = 1.5, nCostPct = 8, nSec = 90 },
}

-- Plantes assignables au CONSOMMABLE RAPIDE (petit slot de la spell bar / radial,
-- demande user 2026-09-18). Source UNIQUE lue par INVENTORY_CONFIG.IsQuickConsumable,
-- miroir exact d'EVO_SCIENCE.MedQuickConsumable.
-- Le critere est PlantEffects, et c'est volontairement le meme que celui qui decide
-- du `on_use` de l'item plus bas : une plante SANS effet ne se mache pas, elle n'a
-- donc rien a faire dans la roue. Les CHAMPIGNONS restent exclus (demande user 08/09).
function EVO_SCIENCE.PlantQuickConsumable(sItemId)
	return (HUB.PlantEffects and HUB.PlantEffects[sItemId]) ~= nil
end

-- Duree lisible ("45 s" / "2 min") — les plantes se comptent en secondes.
local function plantDur(nSec)
	if nSec >= 120 and nSec % 60 == 0 then return (nSec / 60) .. " min" end
	return nSec .. " s"
end

-- Phrase d'effet d'une plante (description d'item + notification a la mastication).
function EVO_SCIENCE.PlantFxDesc(fx)
	if not istable(fx) then return "" end
	if fx.sType == "heal" then
		return "Rend " .. fx.nPct .. "% des PV."
	elseif fx.sType == "regen" then
		return "Régénère " .. fx.nRegenPct .. "%/s de PV pendant " .. plantDur(fx.nSec) .. "."
	elseif fx.sType == "damage" then
		return "+" .. fx.nPct .. "% de dégâts (katana et sorts) pendant " .. plantDur(fx.nSec) .. "."
	elseif fx.sType == "resist" then
		return "-" .. fx.nPct .. "% de dégâts subis pendant " .. plantDur(fx.nSec) .. "."
	elseif fx.sType == "flashcd" then
		return "Cooldown du flashstep réduit de " .. fx.nPct .. "% pendant " .. plantDur(fx.nSec) .. "."
	elseif fx.sType == "reiatsu" then
		local t = {}
		if (fx.nMult or 1) > 1 then t[#t + 1] = "Régénération de reiatsu ×" .. fx.nMult end
		if fx.nCostPct then t[#t + 1] = (#t > 0 and "coûts des sorts réduits de " or "Coûts des sorts réduits de ") .. fx.nCostPct .. "%" end
		return table.concat(t, " et ") .. " pendant " .. plantDur(fx.nSec) .. "."
	elseif fx.sType == "xp" then
		return "+" .. fx.nPct .. "% d'expérience pendant " .. plantDur(fx.nSec) .. "."
	end
	return ""
end

-- Modele (minuscules) -> taille { model, nGive }. Construit une fois, cl + sv.
local _plantByModel
function EVO_SCIENCE.PlantByModel(sModel)
	if not _plantByModel then
		_plantByModel = {}
		for _, p in ipairs(HUB.PlantModels) do
			_plantByModel[string.lower(p.model)] = p
		end
	end
	return _plantByModel[string.lower(tostring(sModel or ""))]
end

-- ── Etablis du laboratoire (outil de placement SA `evo_etablie`, user 08/10) ─
-- Props de decor a positionner PRECISEMENT en jeu puis a copier en config
-- (cl_science_etablies = UI, sv_science_etablies = spawn/ajustements).
HUB.Etablies = {
	{ id = "etablie_01", name = "Gros frigo",            model = "models/evo/props/items/etablie_sci/etablie_01/evo_zfefdefefe4d15.mdl" },
	{ id = "etablie_02", name = "Bureau de préparation", model = "models/evo/props/items/etablie_sci/etablie_02/evo_fregt65hy4j8k2.mdl" },
	{ id = "etablie_03", name = "Bureau avec ordinateur", model = "models/evo/props/items/etablie_sci/etablie_03/evo_gyh7uj5nfr9d31.mdl" },
}

-- ── Placements PERSISTANTS des établis (user 08/19 « séparer physiquement ») ─
-- Le labo se scinde en POSTES PHYSIQUES : frigo = COFFRE de stockage division
-- (evo_coffre_division, gratuit), bureau de préparation = recettes+potions,
-- bureau ordinateur = documents+gestion. Les postes d'analyse (cercles blancs)
-- ne servent plus QU'AUX CARCASSES.
-- pos = setpos BRUT (YEUX, pris SUR PLACE — coords user 08/20) + yaw = setang
-- BRUT (règle projet : jamais de +180 magique). Le spawn SNAP AU SOL sous le
-- point (même recette que les stations d'atelier et les coffres).
-- Map ABSENTE d'ici (Hueco en attente de coords, maps de dev) : le flux potions
-- retombe sur les postes d'analyse (PotionZoneIdFor), rien ne casse.
HUB.EtabliePlacements = {
	["rp_seireitei_v1"] = {
		{ id = "etablie_01", pos = Vector(7470.916016, 7725.955078, 14449.031250),
		  ang = Angle(6.467651, -164.641434, 0), coffre = "Division 12", label = "Frigo du laboratoire",
		  zonePos = Vector(7393.968750, 7700.180664, 14595.518555) },
		-- zonePos = le ROND d'interaction (façon ateliers de craft, user 08/21) ;
		-- le modèle reste sur pos.
		{ id = "etablie_02", pos = Vector(7513.968750, 7404.339844, 14494.503906),
		  ang = Angle(72.599983, -178.141556, 0),
		  zonePos = Vector(7450.932617, 7400.052246, 14595.321289) },
		{ id = "etablie_03", pos = Vector(7468.860352, 7068.471680, 14449.031250),
		  ang = Angle(1.187675, 160.905884, 0),
		  zonePos = Vector(7404.890137, 7080.625977, 14595.723633) },
	},
	-- Hueco (setpos user 08/22) : les 3 établis alignés dans le labo de l'Ordre 3,
	-- chacun avec son rond d'interaction devant lui comme au Seireitei.
	-- ⚠ Les postes ne suivent PAS l'ordre des positions : le user a nommé chaque
	-- rond, et c'est le FRIGO qui va au milieu (le bureau de préparation est à
	-- l'est). Le frigo est le coffre de la division scientifique Hollow, d'où
	-- « Ordre 3 » (même nom que son coffre dans evo_craft).
	["hueco_mundo_v1"] = {
		{ id = "etablie_01", pos = Vector(-10426.530273, -710.928284, 6472.717773),
		  ang = Angle(0, 89.996872, 0), coffre = "Ordre 3", label = "Frigo du laboratoire",
		  zonePos = Vector(-10428.333984, -620.203369, 6472.724121) },
		{ id = "etablie_02", pos = Vector(-10230.735352, -710.928284, 6472.717773),
		  ang = Angle(0, 89.996872, 0),
		  zonePos = Vector(-10236.952148, -651.680603, 6472.710938) },
		{ id = "etablie_03", pos = Vector(-10622.971680, -710.917969, 6472.717773),
		  ang = Angle(0, 89.996872, 0),
		  zonePos = Vector(-10632.336914, -640.565613, 6471.367676) },
	},
}

function EVO_SCIENCE.EtablieById(sId)
	for _, t in ipairs(HUB.Etablies) do
		if t.id == sId then return t end
	end
end

-- Point d'ancrage d'un placement (cache) : SOL sous le setpos (pris debout sur
-- place, donc à hauteur d'yeux). Géométrie de map uniquement = même résultat
-- client et serveur.
local _etSpot = {}
local _etZone = {}
function EVO_SCIENCE.InvalidateEtablieAnchors()
	_etSpot = {}
	_etZone = {}
end

function EVO_SCIENCE.EtablieSpot(e)
	local key = e.id .. "|" .. math.Round(e.pos.x) .. "|" .. math.Round(e.pos.y)
	local v = _etSpot[key]
	if v then return v end
	local tr = util.TraceLine({
		start  = e.pos + Vector(0, 0, 16),
		endpos = e.pos - Vector(0, 0, 512),
		mask   = MASK_SOLID_BRUSHONLY,
	})
	v = (tr.Hit and not tr.StartSolid) and tr.HitPos or e.pos
	_etSpot[key] = v
	return v
end

-- Ancre AU SOL du ROND d'interaction d'un placement (zonePos, cache) — même
-- recette que les stations de craft.
function EVO_SCIENCE.EtablieZoneSpot(e)
	if not e.zonePos then return EVO_SCIENCE.EtablieSpot(e) end
	local key = e.id .. "|zone|" .. math.Round(e.zonePos.x) .. "|" .. math.Round(e.zonePos.y)
	local v = _etZone[key]
	if v then return v end
	local tr = util.TraceLine({
		start  = e.zonePos + Vector(0, 0, 16),
		endpos = e.zonePos - Vector(0, 0, 512),
		mask   = MASK_SOLID_BRUSHONLY,
	})
	v = (tr.Hit and not tr.StartSolid) and tr.HitPos or e.zonePos
	_etZone[key] = v
	return v
end

-- Zone du CRAFT DE POTIONS = autour du bureau de préparation (etablie_02).
-- Même cylindre ancré au sol que les postes (bande CFG.ZoneBand*). Map sans
-- placements = repli sur les postes d'analyse (ancien flux, maps de dev/Hueco).
HUB.PotionZoneRadius = 170
function EVO_SCIENCE.PotionZoneIdFor(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return nil end
	local tList = HUB.EtabliePlacements[game.GetMap()]
	if not istable(tList) then return EVO_SCIENCE.ZoneIdFor(ply) end
	local p = ply:GetPos()
	for i, e in ipairs(tList) do
		if e.id == "etablie_02" then
			local a = EVO_SCIENCE.EtablieSpot(e)
			local dz = p.z - a.z
			if dz >= -CFG.ZoneBandBelow and dz <= CFG.ZoneBandAbove then
				local dx, dy = p.x - a.x, p.y - a.y
				local r = HUB.PotionZoneRadius
				if dx * dx + dy * dy <= r * r then
					return "etab:" .. game.GetMap() .. ":" .. i
				end
			end
		end
	end
	return nil
end

-- ── Cristaux : drop sur la mort de N'IMPORTE QUEL mob ────────────────────────
-- 6 tiers (t1 = le plus rare) x 12 couleurs (skins du model). Un seul tirage
-- cumulatif par mort : chaque tier garde exactement sa probabilite.
HUB.CrystalModels = {
	[1] = "models/evo/props/items/crystal/crystal_01/evo_q7v3k9mx2r.mdl",
	[2] = "models/evo/props/items/crystal/crystal_02/evo_b5n8t4cz7p.mdl",
	[3] = "models/evo/props/items/crystal/crystal_03/evo_x2m6r9wf3k.mdl",
	[4] = "models/evo/props/items/crystal/crystal_04/evo_h8p4v7qd5n.mdl",
	[5] = "models/evo/props/items/crystal/crystal_05/evo_t3z9k6mc2s.mdl",
	[6] = "models/evo/props/items/crystal/crystal_06/evo_r6w2x8fj4v.mdl",
}
-- Taux divisés par ~3 le 08/28 (user « réduit de beaucoup »), x4 le 10/02 (deux buffs),
-- puis /2 le 10/03 : ~7,4% de chance totale d'un drop par kill. Rapport entre tiers inchangé.
HUB.CrystalDropChance = {
	[1] = 0.0006, [2] = 0.003, [3] = 0.006, [4] = 0.014, [5] = 0.02, [6] = 0.03,
}
HUB.CrystalTierNames = {
	[1] = "Cristal primordial",
	[2] = "Cristal céleste",
	[3] = "Cristal raffiné",
	[4] = "Cristal poli",
	[5] = "Cristal brut",
	[6] = "Éclat de reiryoku",
}
HUB.CrystalTierRarity = {
	[1] = "mythic", [2] = "legendary", [3] = "epic",
	[4] = "rare", [5] = "common", [6] = "common",
}
-- Couleurs = skins du model, DANS L'ORDRE du $texturegroup skinfamilies.
HUB.CrystalColors = {
	{ key = "carmin",  name = "Carmin" },
	{ key = "bleu",    name = "Bleu" },
	{ key = "vert",    name = "Vert" },
	{ key = "violet",  name = "Violet" },
	{ key = "cyan",    name = "Cyan" },
	{ key = "dore",    name = "Doré" },
	{ key = "orange",  name = "Orange" },
	{ key = "rose",    name = "Rose" },
	{ key = "blanc",   name = "Blanc" },
	{ key = "noir",    name = "Noir" },
	{ key = "lime",    name = "Lime" },
	{ key = "magenta", name = "Magenta" },
}
HUB.CrystalGroundLinger = 120 -- s au sol avant disparition du drop
-- Fusion a la forge : 4 cristaux d'un tier ET d'une couleur -> 1 cristal du
-- tier SUPERIEUR (t-1), meme couleur. t1 n'est pas fusionnable.
HUB.CrystalMergeCount = 4

-- Cout en yens de la fusion, par TIER SOURCE. Courbe reguliere DIVISEE PAR
-- DEUX le 08/24 (user : « descendre les prix de fusion ») — l'ancienne allait
-- de 2500 a 10000 (08/09).
HUB.CrystalMergeCost = {
	[6] = 1250, -- Eclat    -> Brut
	[5] = 2000, -- Brut     -> Poli
	[4] = 3000, -- Poli     -> Raffine
	[3] = 4000, -- Raffine  -> Celeste
	[2] = 5000, -- Celeste  -> Primordial
}

function EVO_SCIENCE.CrystalMergeCostFor(nTier)
	return HUB.CrystalMergeCost[nTier] or 0
end

-- SCISSION (08/24) : l'inverse de la fusion — 1 cristal du tier t rend les
-- 4 cristaux du tier INFERIEUR (t+1), meme couleur, contre des yens. Prix =
-- la MOITIE de la fusion qu'elle defait : l'aller-retour fusion+scission
-- coute donc 1,5x la fusion, assez pour ne pas servir de stockage gratuit.
function EVO_SCIENCE.CrystalUnmergeCostFor(nTier)
	return math.floor((HUB.CrystalMergeCost[(nTier or 0) + 1] or 0) / 2)
end

function EVO_SCIENCE.CrystalItemId(nTier, nColorIdx)
	local c = HUB.CrystalColors[nColorIdx]
	if not c then return nil end
	return string.format("cristal_t%d_%s", nTier, c.key)
end

-- Decompose un item id de cristal -> tier, colorIdx (ou nil).
function EVO_SCIENCE.CrystalParse(sItemId)
	local t, key = tostring(sItemId or ""):match("^cristal_t(%d)_(%w+)$")
	t = tonumber(t)
	if not t or not HUB.CrystalModels[t] then return nil end
	for i, c in ipairs(HUB.CrystalColors) do
		if c.key == key then return t, i end
	end
	return nil
end

-- ── Experimentation (demande user 08/09) ─────────────────────────────────────
-- Les requis d'une recette sont CACHES tant que la faction ne l'a pas reussie
-- une fois : le joueur depose un MELANGE LIBRE au synthetiseur ; s'il colle
-- exactement a une recette -> potion + recette consignee, sinon les ingredients
-- sont perdus. Bornes du melange = les memes que celles des recettes.
HUB.ComboMaxMushTypes    = 3 -- varietes de champignons max
HUB.ComboMaxCrystalTypes = 3 -- cristaux differents max
HUB.ComboMaxPlantTypes   = 3 -- varietes de plantes max (user 08/10)
HUB.ComboMaxResTypes     = 4 -- ressources d'artisanat differentes max (protheses, user 09/20)
HUB.ComboMaxPerType      = 3 -- exemplaires max d'un meme ingredient
HUB.ComboMaxTypes        = 8 -- borne dure du net (4 bits) ; l'UI n'a que 6 slots de toute facon

-- "mush" / "plant" / "crystal" si l'item peut entrer au synthetiseur, nil sinon.
local _mushSet, _plantSet
function EVO_SCIENCE.IngredientKind(sItemId)
	if not _mushSet then
		_mushSet = {}
		for _, v in ipairs(HUB.Mushrooms) do _mushSet[v.id] = true end
		_plantSet = {}
		for _, v in ipairs(HUB.Plants) do _plantSet[v.id] = true end
	end
	if _mushSet[sItemId] then return "mush" end
	if _plantSet[sItemId] then return "plant" end
	if EVO_SCIENCE.CrystalParse(sItemId) then return "crystal" end
	-- Ressources d'artisanat d'evo_craft (metal brut, roche, bois, os, corde) : acceptees
	-- au melangeur depuis les protheses (user 09/20). Lu a l'APPEL : evo_craft est un autre addon.
	if EVO_CRAFT and EVO_CRAFT.Resources and EVO_CRAFT.Resources[sItemId] then return "res" end
	return nil
end

-- Le melange (map itemId -> qte) correspond-il EXACTEMENT a une recette ?
function EVO_SCIENCE.MatchRecipe(tCombo)
	local nTypes = 0
	for _ in pairs(tCombo) do nTypes = nTypes + 1 end
	for _, r in ipairs(HUB.PotionRecipes) do
		local n, ok = 0, true
		for id, qty in pairs(r.tIngredients) do
			n = n + 1
			if tCombo[id] ~= qty then ok = false break end
		end
		if ok and n == nTypes then return r end
	end
	return nil
end

-- ── Items ingredients / potions ──────────────────────────────────────────────
HUB.Items = {}
-- Plantes, champignons, cristaux, potions, bouteille : piles de 64 (demande user).
local STACK_MAT = 64

-- 10 varietes de champignons (1 item par variete, 1er modele en apercu sac).
-- Se mange CRU : aucun bienfait, risque de maladie (pipeline central MaladieRoll).
for _, v in ipairs(HUB.Mushrooms) do
	local sMid = v.id
	HUB.Items[v.id] = {
		name = v.name,
		description = v.desc .. " " .. EVO_SCIENCE.HarvestOriginDesc(v)
			.. "\nClic droit > Utiliser pour le manger CRU (à tes risques).",
		category = "object",
		rarity = v.rarity,
		model_path = HUB.MushroomModels[v.models[1]],
		is_droppable = true,
		stack_max = STACK_MAT,
		on_use = function(ply)
			if not SERVER then return end
			if EVO_SCIENCE.EatMushroom then EVO_SCIENCE.EatMushroom(ply, sMid) end
		end,
	}
end

-- 10 varietes de plantes (1 item par variete ; apercu sac = PETIT modele au
-- skin de la variete). La taille du prop recolte ne change que la QUANTITE.
-- ⚠ RESTAURE le 22/08 (merge de staging) : le on_use (macher la plante) et la
-- phrase d'effet avaient saute — les 10 plantes etaient devenues inertes.
for _, v in ipairs(HUB.Plants) do
	local sPid = v.id
	local fx = HUB.PlantEffects[sPid]
	HUB.Items[v.id] = {
		name = v.name,
		description = v.desc .. " " .. EVO_SCIENCE.HarvestOriginDesc(v)
			.. (fx and ("\nClic droit > Utiliser pour la mâcher : " .. EVO_SCIENCE.PlantFxDesc(fx)) or ""),
		category = "object",
		rarity = v.rarity,
		model_path = HUB.PlantModels[1].model,
		skin = v.nSkin,
		is_droppable = true,
		stack_max = STACK_MAT,
		on_use = fx and function(ply)
			if not SERVER then return end
			if EVO_SCIENCE.ChewPlant then EVO_SCIENCE.ChewPlant(ply, sPid) end
		end or nil,
	}
end

-- ── MEDICAMENT (user 08\16) : contre l'intoxication au champignon cru ────────
-- Pas de recette pour l'instant, l'item existe et c'est tout — a brancher sur
-- une vente ou une synthese quand ce sera decide.
-- Ne touche QUE les afflictions qui le declarent en `sCureItem` : ce n'est pas
-- un contre-poison universel, la Potion miraculeuse garde ce role.
HUB.Items.medicament = {
	name = "Médicament",
	description = "Cachets amers dans un sachet de papier. Coupe les vertiges et les maux de tête"
		.. " d'une intoxication alimentaire.\nClic droit > Utiliser pour l'avaler.",
	category = "object",
	rarity = "common",
	model_path = HUB.PotionModel,
	skin = HUB.PotionSkinEmpty,
	is_droppable = true,
	on_use = function(ply)
		if not SERVER then return end
		if EVO_SCIENCE.UseMedicament then EVO_SCIENCE.UseMedicament(ply) end
	end,
}

-- Potions (resultats des recettes) : UNE entree PAR NIVEAU D'ETOILES (1..3,
-- user 08/10) — meme skin, mais prop de fiole du niveau et effets boostes dans
-- la description. Toxines/remedes = 1 seul niveau (RecipeHasStars).
local POTION_RARITY = { [1] = "rare", [2] = "epic", [3] = "legendary", [4] = "mythic" }
for _, r in ipairs(HUB.PotionRecipes) do
	-- bExternalResult (masque médical) : l'item RÉSULTAT vit ailleurs
	-- (accessoire sh_science_medic) — ne surtout pas fabriquer une fiole
	-- buvable par-dessus, ni de variantes étoilées fantômes.
	if r.bExternalResult then continue end
	local cat = HUB.PotionCategories[r.sCat]
	local nMaxStar = EVO_SCIENCE.RecipeHasStars(r) and 3 or 1
	for nStar = 1, nMaxStar do
		local sResult = EVO_SCIENCE.PotionStarResult(r, nStar)
		HUB.Items[sResult] = {
			name = r.sName .. (HUB.PotionStarTag[nStar] or ""),
			description = r.sDesc
				.. " Potion de catégorie " .. (cat and cat.sName or "?") .. ". "
				.. EVO_SCIENCE.PotionFxDesc(HUB.PotionEffects[r.id], nStar)
				.. "\nClic droit > Utiliser pour la boire.",
			category = "object",
			rarity = POTION_RARITY[r.nPalier] or "epic",
			stack_max = STACK_MAT,
			model_path = HUB.PotionStarModels[nStar] or HUB.PotionModel,
			-- nSkin de RECETTE (toxines/remedes : teinte par paire) prioritaire sur
			-- le skin de categorie.
			skin = r.nSkin or (cat and cat.nSkin) or 0,
			is_droppable = true,
			-- Boire : logique 100% SERVEUR (sv_science_potions : guards, consommation,
			-- application du buff) — meme pattern que les parchemins de l'inventaire.
			on_use = function(ply)
				if not SERVER then return end
				if EVO_SCIENCE.DrinkPotion then EVO_SCIENCE.DrinkPotion(ply, sResult) end
			end,
		}
	end
end

-- Bouteille vide : achetable par TOUT LE MONDE a l'Urahara Shop (100 yens).
HUB.Items.bouteille_vide = {
	name = "Bouteille vide",
	description = "Une bouteille de verre vide, calibrée pour le synthétiseur du laboratoire scientifique."
		.. " OBLIGATOIRE pour embouteiller toute potion (consommée à la synthèse).",
	category = "object",
	rarity = "common",
	model_path = HUB.PotionModel,
	skin = HUB.PotionSkinEmpty,
	is_droppable = true,
	stack_max = STACK_MAT,
}

-- ── OUTILS DE MÉDECINE / LABO (user 08/17) : props RP PURS, sans on_use.
-- Vendus à l'Urahara Shop 100 yens (lzy_npcshop). Un item PAR MODÈLE (demande
-- user : les variantes à texture groups ne sont pas vendues).
local tMedicTools = {
	{ id = "medic_seringue",           name = "Seringue",           model = "models/evo/props/items/medic/medic_01/evo_73d907fc7beb005c2b.mdl" },
	{ id = "medic_becher",             name = "Bécher",             model = "models/evo/props/items/medic/becher/evo_becher_2f6de8f4b5.mdl" },
	{ id = "medic_entonnoir",          name = "Entonnoir",          model = "models/evo/props/items/medic/entonnoir/evo_entonnoir_9bfe560f63.mdl" },
	{ id = "medic_eprouvette_graduee", name = "Éprouvette graduée", model = "models/evo/props/items/medic/eprouvette_graduee/evo_eprouvette_graduee_d2bb99fa3c.mdl" },
	{ id = "medic_erlenmeyer",         name = "Erlenmeyer",         model = "models/evo/props/items/medic/erlenmeyer/evo_erlenmeyer_fcdd7b63af.mdl" },
	{ id = "medic_fiole_jaugee",       name = "Fiole jaugée",       model = "models/evo/props/items/medic/fiole_jaugee/evo_fiole_jaugee_1d00b0497e.mdl" },
	{ id = "medic_mortier",            name = "Mortier",            model = "models/evo/props/items/medic/mortier/evo_mortier_bea9fe937c.mdl" },
	{ id = "medic_pilon",              name = "Pilon",              model = "models/evo/props/items/medic/mortier/evo_pilon_tgr5a9fe937c.mdl" },
	{ id = "medic_pipette",            name = "Pipette",            model = "models/evo/props/items/medic/pipette/evo_pipette_cc16709b79.mdl" },
	{ id = "medic_tube_essai",         name = "Tube à essai",       model = "models/evo/props/items/medic/tube_essai/evo_tube_essai_2834fdd0a7.mdl" },
	{ id = "medic_verre_mesureur",     name = "Verre mesureur",     model = "models/evo/props/items/medic/verre_mesureur/evo_verre_mesureur_4d45466fb8.mdl" },
}
for _, t in ipairs(tMedicTools) do
	HUB.Items[t.id] = {
		name = t.name,
		description = t.name .. " : matériel de médecine et de laboratoire."
			.. "\nSe pose au sol (clic droit > Jeter) pour habiller un poste de soin ou d'analyse.",
		category = "object",
		rarity = "common",
		model_path = t.model,
		is_droppable = true,
	}
end

-- PROTHÈSES (user 09/20) : résultat des 2 recettes « prothese », consommées par la pose au
-- bloc (EVO_AMPUT, sv_science_amputation) et rendues au retrait.
-- ⚠ MODÈLE PROVISOIRE : les prothèses n'existent que comme bodygroups du corps (rk_main /
-- rk_bras), il n'y a PAS de prop. En attendant, l'aperçu du sac reprend la seringue.
local PROTH_ITEM_MODEL = "models/evo/props/items/medic/medic_01/evo_73d907fc7beb005c2b.mdl"
HUB.Items.prothese_main = {
	name = "Prothèse de main",
	description = "Main articulée fabriquée au laboratoire scientifique."
		.. "\nUn scientifique la pose au bloc sur un patient allongé dont la main est coupée : son malus de PV max disparaît tant qu'il la porte.",
	category = "object",
	rarity = "rare",
	model_path = PROTH_ITEM_MODEL,
	is_droppable = true,
}
HUB.Items.prothese_bras = {
	name = "Prothèse de bras",
	description = "Bras complet fabriqué au laboratoire scientifique."
		.. "\nUn scientifique la pose au bloc sur un patient allongé dont le bras est coupé : son malus de PV max disparaît tant qu'il la porte.",
	category = "object",
	rarity = "epic",
	model_path = PROTH_ITEM_MODEL,
	is_droppable = true,
}

-- Potion RATEE (blanche) : resultat de N'IMPORTE QUEL melange invalide.
-- Buvable… avec un risque de maladie (pipeline central MaladieRoll).
HUB.Items[HUB.PotionFailedItem] = {
	name = "Potion ratée",
	description = "Un liquide blanc laiteux, inerte. Ce mélange ne correspondait à aucune synthèse connue."
		.. "\nClic droit > Utiliser pour la boire (déconseillé).",
	category = "object",
	rarity = "common",
	model_path = HUB.PotionModel,
	skin = HUB.PotionSkinFailed,
	is_droppable = true,
	stack_max = STACK_MAT,
	on_use = function(ply)
		if not SERVER then return end
		if EVO_SCIENCE.DrinkPotion then EVO_SCIENCE.DrinkPotion(ply, HUB.PotionFailedItem) end
	end,
}

-- Etapes intermediaires (flavor, NON echangeables : le craft reste pilote par
-- l'etat serveur du poste, jamais par la detention de ces items).
-- Interruption (crash / timeout) : Utiliser rend le mélange. is_deletable=false
-- pour ne pas jeter le jeton de remboursement.
HUB.Items[HUB.PotionPrepItem] = {
	name = "Préparation de potion (pas terminée)",
	description = "Broyage effectué : la poudre attend le mélange, puis la synthèse, au poste d'analyse."
		.. "\nSi la synthèse a été interrompue, clic droit > Utiliser pour récupérer les ingrédients.",
	category = "object",
	rarity = "common",
	model_path = HUB.PotionModel,
	skin = HUB.PotionSkinPrep,
	is_droppable = false,
	is_deletable = false,
	on_use = function(ply)
		if not SERVER then return end
		if EVO_SCIENCE.UsePotionPrep then EVO_SCIENCE.UsePotionPrep(ply, HUB.PotionPrepItem) end
	end,
}
HUB.Items[HUB.PotionPrepDoneItem] = {
	name = "Préparation de potion (terminée)",
	description = "Mélange terminé : il ne reste que la synthèse pour révéler la potion."
		.. "\nSi la synthèse a été interrompue, clic droit > Utiliser pour récupérer les ingrédients.",
	category = "object",
	rarity = "common",
	model_path = HUB.PotionModel,
	skin = HUB.PotionSkinPrep,
	is_droppable = false,
	is_deletable = false,
	on_use = function(ply)
		if not SERVER then return end
		if EVO_SCIENCE.UsePotionPrep then EVO_SCIENCE.UsePotionPrep(ply, HUB.PotionPrepDoneItem) end
	end,
}

-- 6 tiers x 12 couleurs de cristaux, generes en items (comme les katanas).
for nTier, sModel in pairs(HUB.CrystalModels) do
	for nColor, c in ipairs(HUB.CrystalColors) do
		local sId = EVO_SCIENCE.CrystalItemId(nTier, nColor)
		HUB.Items[sId] = {
			name = string.format("%s (%s)", HUB.CrystalTierNames[nTier], c.name),
			description = nTier > 1
				and string.format("Cristal de reiryoku, teinte %s. %d exemplaires identiques peuvent être fusionnés à la forge en un %s.",
					string.lower(c.name), HUB.CrystalMergeCount, HUB.CrystalTierNames[nTier - 1])
				or string.format("Cristal de reiryoku ultime, teinte %s. La forme la plus pure connue.", string.lower(c.name)),
			category = "object",
			rarity = HUB.CrystalTierRarity[nTier],
			model_path = sModel,
			skin = nColor - 1,
			is_droppable = true,
			stack_max = STACK_MAT,
		}
	end
end

-- Enregistrement dans ITEMS en boucle de retry (pattern evo_note) : l'addon
-- inventory REASSIGNE la table ITEMS a son include, s'enregistrer trop tot =
-- entrees ecrasees. Idempotent (guard not ITEMS[id]).
local function registerHubItems()
	if not istable(ITEMS) then return false end
	for id, def in pairs(HUB.Items) do
		if not ITEMS[id] then
			local t = table.Copy(def)
			ITEMS[id] = t
		end
	end
	return true
end

-- Echec LOGGE apres 30 essais (etait 100% muet : ITEMS jamais peuplee = tous
-- les `or id` devenaient le chemin normal, d'ou les noms a underscores en jeu).
local nHubItemsTry = 0
timer.Create("EVO_Science::HubItems", 1, 30, function()
	nHubItemsTry = nHubItemsTry + 1
	if registerHubItems() then
		timer.Remove("EVO_Science::HubItems")
	elseif nHubItemsTry >= 30 then
		print("[evo_science] ITEMS indisponible apres 30 essais : items du hub non enregistres dans l'inventaire (verifier l'addon inventory).")
	end
end)

-- Les actions du menu C de cet addon vivent désormais dans LA CONFIG DU
-- GAMEMODE : gamemodes/mangarp/gamemode/config/modules/sh_property_menu.lua
-- (centralisation 08/17, demande user — plus aucun enregistrement à l'init ici).
