-- "addons\\evo_science\\lua\\autorun\\sh_science_amputation.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO SCIENCE : AMPUTATION + PROTHÈSE (09/20, demande user). N'IMPORTE QUI peut couper la
-- main ou le bras GAUCHE d'un joueur de grade INFÉRIEUR au sien, depuis le menu C, s'il est
-- en MODE PAIN (coupe directe) ou ALLONGÉ (mini-jeu de la scie) : malus PERMANENT de PV max,
-- porté par le PERSONNAGE.
-- Un SCIENTIFIQUE ou un MÉDECIN pose ensuite la prothèse adaptée (opération à mini-jeu du
-- heal bed, patient allongé sur un lit) : le malus disparaît tant que la prothèse est portée.
-- La prothèse, elle, ne se FABRIQUE qu'au labo scientifique (10/26 : « la scientifique
-- fabrique, la médicale pose »).
-- Fichier autonome : il charge AVANT sh_science_config (ordre alphabétique).
-- ============================================================================
EVO_AMPUT = EVO_AMPUT or {}

-- AUTOREFRESH : on réutilise la table, jamais une neuve (upvalues des autres fichiers).
local CFG = EVO_AMPUT.CFG or {}
EVO_AMPUT.CFG = CFG

CFG.MinRank        = 2   -- grade de faction minimum du praticien qui pose une prothèse
CFG.ConsentTimeout = 30  -- s pour répondre à la demande de coupe
CFG.CutDist        = 120 -- portée de la demande de coupe

-- Spécialités de la PROTHÈSE (LZY_FACTION_CONFIG.DivisionSpecialty : même index dans les 2
-- factions, Division 12 / Ordre 3 = 4, Division 4 / Ordre 4 = 5). Repli par index si la
-- config manque. La COUPE, elle, n'a plus de gate de division (user 09/20 : tout le monde
-- peut couper).
CFG.FitSpecialties = { ["Scientifique"] = true, ["Médecin"] = true } -- user 10/26 : + médecins
CFG.FitIndexes     = { [4] = true, [5] = true }

-- Niveaux de coupe. Le bras ENGLOBE la main : 10 % au total, jamais 15.
-- tBody = bodygroups du CORPS résolus par NOM (tableau fourni par le user) :
--   left_arm 0 normal / 1 moignon du poignet / 2 bras retiré ; left_hand 1 = main masquée.
-- nProth = valeur de left_prosthesis quand la prothèse de CE niveau est portée.
-- sItem = l'objet fabriqué au labo (recettes « prothese » de sh_science_hub), consommé du
-- sac du scientifique à la réussite de la pose et rendu au retrait.
CFG.ProthBodygroup = "left_prosthesis"
CFG.Levels = {
	[1] = { sPart = "la main gauche", sProth = "prothèse de main", nHpPct = 5,
		tBody = { left_arm = 1, left_hand = 1 }, nProth = 1, sItem = "prothese_main" },
	[2] = { sPart = "le bras gauche", sProth = "prothèse de bras", nHpPct = 10,
		tBody = { left_arm = 2, left_hand = 1 }, nProth = 2, sItem = "prothese_bras" },
}

-- ÉTAT réseau EVO_Amputation (UNE clé, 5 valeurs = le tableau du user) :
-- 0 normal, 1 main coupée, 2 bras coupé, 3 prothèse de main, 4 prothèse de bras.
function EVO_AMPUT.State(ply)
	if not (IsValid(ply) and ply.GetEvoNWInt) then return 0 end
	return ply:GetEvoNWInt("EVO_Amputation", 0)
end
function EVO_AMPUT.Level(ply)
	local n = EVO_AMPUT.State(ply)
	return n > 2 and n - 2 or n
end
function EVO_AMPUT.HasProsthesis(ply)
	return EVO_AMPUT.State(ply) > 2
end

-- Membre manquant SANS prothèse : plus de prise à la main (« Attraper », « Étrangler » de
-- ncm_grab_superieur). nil = aucune gêne. Lu par le menu C (client) ET par CanGrab (serveur).
-- Superadmin exempté : sa prise est un outil de modération, pas un geste RP.
-- Main ou bras gauche manquant, SANS prothèse (aucune exemption : c'est un état du corps).
-- Lu aussi par le rendu des gantelets Hakuda (bodygroup hakuda_left).
function EVO_AMPUT.IsHandless(ply)
	local n = EVO_AMPUT.State(ply)
	return n == 1 or n == 2
end

function EVO_AMPUT.GrabBlockReason(ply)
	if not IsValid(ply) or ply:IsSuperAdmin() then return nil end
	local n = EVO_AMPUT.State(ply)
	if n == 1 then return "Impossible : il te manque une main. Une prothèse te rendrait la prise." end
	if n == 2 then return "Impossible : il te manque un bras. Une prothèse te rendrait la prise." end
	return nil
end

local function hasSpecialty(ply, tNames, tIndexes)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	local sFac = ply:GetEvoNWString("FactionName", "")
	if sFac == "" or sFac == "LostSoul" then return false end
	if ply:GetEvoNWInt("FactionRank", 0) < CFG.MinRank then return false end
	local nDiv = ply:GetEvoNWInt("FactionDivision", 0)
	local tSpec = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionSpecialty
	if istable(tSpec) then return tNames[tSpec[nDiv] or ""] == true end
	return tIndexes[nDiv] == true
end

-- Poser / retirer une prothèse : division scientifique ou médicale, grade 2+ (ou superadmin).
function EVO_AMPUT.CanFitter(ply)
	return hasSpecialty(ply, CFG.FitSpecialties, CFG.FitIndexes)
end

-- Cible NEUTRALISÉE = pas besoin de son accord : MENOTTÉE (captif) ou bot. Le mode pain ne
-- dispense PAS de l'accord : il est la condition de TOUTE coupe, c'est lui qui ouvre la demande.
function EVO_AMPUT.IsNeutralised(target)
	if not IsValid(target) then return false end
	return target:IsBot() or target:GetEvoNWBool("EVO_Handcuffed", false)
end

-- ALLONGÉE = emote « à terre » du heal bed (lit ou non) : c'est elle qui déclenche le mini-jeu.
function EVO_AMPUT.IsLyingDown(ply)
	return EvoHealBed ~= nil and EvoHealBed.IsDowned ~= nil and EvoHealBed.IsDowned(ply) == true
end

-- MODE PAIN = état blessé de ncm_injured_system (5 % de PV ou moins), NW répliquée sur autrui.
function EVO_AMPUT.IsInPain(ply)
	return IsValid(ply) and ply:GetEvoNWBool("EVO::IsInjured", false)
end

-- Conditions communes à la pose et au retrait de PROTHÈSE : patient ALLONGÉ, praticien libre et à
-- portée (celle de l'opération du heal bed). bBed = exiger en plus un lit (evo_repos),
-- comme l'opération des médecins ; StartHeal le revalide de toute façon.
local function patientReady(ply, target, bBed)
	if ply:GetEvoNWBool("EVO_IsKO", false) then
		return false, "Impossible pendant que tu es à terre."
	end
	if ply:GetEvoNWBool("EVO_HealBed_Healing", false) then
		return false, "Tu es déjà en opération."
	end
	if not (EvoHealBed and EvoHealBed.IsDowned and EvoHealBed.IsDowned(target)) then
		return false, "Le patient doit être allongé sur un lit."
	end
	if bBed and EVO_REPOS and EVO_REPOS.NearestSpot and EVO_REPOS.NearestSpot(target:GetPos()) == nil then
		return false, "Le patient doit être allongé sur un lit."
	end
	local nMax = (EvoHealBed.Config and EvoHealBed.Config.tHeal and EvoHealBed.Config.tHeal.nMaxDist) or 180
	if ply:GetPos():DistToSqr(target:GetPos()) > nMax * nMax then
		return false, "Tu es trop loin du patient."
	end
	return true
end

-- Gates PARTAGÉS (CanRun du menu C côté client, revalidation serveur).
-- `false` nu = entrée masquée ; `false, raison` = entrée visible, le clic explique.
function EVO_AMPUT.CanCut(ply, target, nLevel)
	if not (IsValid(ply) and IsValid(target) and target:IsPlayer()) then return false end
	if ply == target then return false end
	if not CFG.Levels[nLevel] then return false end
	if EVO_AMPUT.Level(target) >= nLevel then return false end
	-- Formes sans bras (larve, Hollow brut, transformation) : rien à couper.
	if target:GetEvoNWBool("EVO_IsLarva", false) or target:GetEvoNWBool("EVO_HollowRaw", false)
		or target:GetEvoNWBool("NCM_TF_Active", false) then
		return false
	end
	-- Cible en MODE PAIN ou ALLONGÉE, sinon l'entrée n'existe pas (tout le monde la verrait
	-- sur tout le monde). Les deux voies (09/21) : pain = coupe directe, allongée = mini-jeu.
	if not (EVO_AMPUT.IsInPain(target) or EVO_AMPUT.IsLyingDown(target)) then return false end
	-- GRADE SUPÉRIEUR à celui de la cible (toutes factions, grades comparés en nombre).
	if not ply:IsSuperAdmin()
		and ply:GetEvoNWInt("FactionRank", 0) <= target:GetEvoNWInt("FactionRank", 0) then
		return false, "Il te faut un grade supérieur au sien pour le couper."
	end
	if ply:GetEvoNWBool("EVO_IsKO", false) or EVO_AMPUT.IsInPain(ply) then
		return false, "Impossible dans ton état."
	end
	if ply:GetEvoNWBool("EVO_HealBed_Healing", false) then
		return false, "Tu es déjà en opération."
	end
	if ply:GetPos():DistToSqr(target:GetPos()) > CFG.CutDist * CFG.CutDist then
		return false, "Tu es trop loin de lui."
	end
	return true
end

-- Poser LA prothèse du niveau nLevel : le membre correspondant doit être coupé, sans prothèse.
function EVO_AMPUT.CanFit(ply, target, nLevel)
	if not (IsValid(ply) and IsValid(target) and target:IsPlayer()) then return false end
	if ply == target then return false end
	if not CFG.Levels[nLevel] then return false end
	if not EVO_AMPUT.CanFitter(ply) then return false end
	if EVO_AMPUT.Level(target) ~= nLevel or EVO_AMPUT.HasProsthesis(target) then return false end
	local t = CFG.Levels[nLevel]
	if t.sItem and EVO_SCIENCE and EVO_SCIENCE.CountItem and EVO_SCIENCE.CountItem(ply, t.sItem) < 1 then
		return false, "Il te faut une " .. t.sProth .. " dans ton sac : elle se fabrique au laboratoire."
	end
	return patientReady(ply, target, true)
end

-- Couleur de la prothèse (09/28) : mêmes conditions que le retrait (praticien, patient
-- allongé, prothèse portée), SANS exiger de lit ni lancer d'opération.
function EVO_AMPUT.CanRecolor(ply, target)
	if not (IsValid(ply) and IsValid(target) and target:IsPlayer()) then return false end
	if ply == target then return false end
	if not EVO_AMPUT.CanFitter(ply) then return false end
	if not EVO_AMPUT.HasProsthesis(target) then return false end
	return patientReady(ply, target, false)
end

-- Couleur réseau : 0 = texture d'origine, sinon (r * 65536 + g * 256 + b) + 1.
function EVO_AMPUT.PackColor(r, g, b)
	return math.Clamp(math.floor(r), 0, 255) * 65536 + math.Clamp(math.floor(g), 0, 255) * 256 + math.Clamp(math.floor(b), 0, 255) + 1
end
function EVO_AMPUT.UnpackColor(n)
	n = math.floor(tonumber(n) or 0)
	if n <= 0 then return nil end
	n = n - 1
	return math.floor(n / 65536) % 256, math.floor(n / 256) % 256, n % 256
end

function EVO_AMPUT.CanRemove(ply, target)
	if not (IsValid(ply) and IsValid(target) and target:IsPlayer()) then return false end
	if ply == target then return false end
	if not EVO_AMPUT.CanFitter(ply) then return false end
	if not EVO_AMPUT.HasProsthesis(target) then return false end
	return patientReady(ply, target, false)
end
