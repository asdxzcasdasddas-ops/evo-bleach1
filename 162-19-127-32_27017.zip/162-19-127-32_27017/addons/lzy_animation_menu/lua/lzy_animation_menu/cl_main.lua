-- "addons\\lzy_animation_menu\\lua\\lzy_animation_menu\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local frame = nil
local can_open = true

-- =====================================================================
-- REFONTE VISUELLE — DA EVO : carte #0E0E11, accent rouge #cf444e, fond
-- plein écran blur + assombrissement, aucune bordure grise, ✕ standard.
-- Rendu 100% VGUI + RNDX (pas de DHTML). Tout le FONCTIONNEL est inchangé :
-- net messages, bind d'ouverture/fermeture, drag & drop vers la roue,
-- persistance des 6 emplacements, aperçu 3D, recherche/catégories, sons.
-- =====================================================================

-- ── Palette DA (couleurs module-locales : rien de réalloué par frame) ──
local COL_WHITE       = Color(255, 255, 255, 255)
local COL_CARD        = Color(13, 14, 17, 250)     -- plaque métal noir (Atelier)
local COL_EDGE        = Color(146, 152, 161, 33)   -- liseré acier 1px
local COL_CARD_OPAQUE = Color(14, 14, 17, 250)     -- carte quasi opaque (menu catégories, aperçu)
local COL_CARD_HOV    = Color(24, 24, 29, 250)     -- carte survolée
local COL_HEADER      = Color(22, 22, 27, 255)     -- bandeau d'entête (légèrement plus clair)
local COL_ROW         = Color(26, 26, 32, 255)     -- case de la liste
local COL_ROW_HOV     = Color(36, 36, 44, 255)     -- case survolée
local COL_ACCENT      = Color(207, 68, 78, 255)    -- #cf444e
local COL_ACCENT_SOFT = Color(207, 68, 78, 45)     -- accent translucide (survol menu catégories)
local COL_PULSE       = Color(207, 68, 78, 110)    -- anneau pendant un drag (alpha muté par frame)
local COL_TXT         = Color(235, 235, 240, 255)
local COL_TXT_SOFT    = Color(215, 215, 222, 255)  -- nom d'anim dans un emplacement (repos)
local COL_TXT_DIM     = Color(150, 150, 160, 255)
local COL_PLACEHOLDER = Color(255, 255, 255, 64)   -- placeholder de la recherche
local COL_SWITCH_OFF  = Color(46, 46, 54, 255)     -- fond de l'interrupteur BOUCLE éteint
local COL_SCROLL      = Color(58, 58, 68, 220)     -- grip de l'ascenseur

-- ── Fontes DA Atelier : Bebas Neue SANS bold pour l'affichage, Avenir pour
-- la saisie/les aides (⚠ les strings Avenir rendent à N+7 : tailles Bebas
-- compensées pour un rendu équivalent).
-- Tailles augmentées de partout (demande user 08/07 : "trop petit").
local F_TITLE      = "Bebas Neue:56"
local F_HINT       = "Avenir Next World:21"
local F_X          = "Avenir Next World Bold:28"  -- ✕ (croix standard DA)
local F_HEADER     = "Bebas Neue:32"
local F_ROW        = "Bebas Neue:30"              -- nom d'anim dans une case
local F_ROW_CAT    = "Bebas Neue:21"              -- catégorie sous le nom
local F_INPUT      = "Avenir Next World:22"       -- recherche + placeholder
local F_DROPDOWN   = "Bebas Neue:29"              -- sélecteur de catégorie : bouton + entrées
local F_SLOT       = "Bebas Neue:28"              -- nom d'anim dans un cercle de la roue
local F_SLOT_SMALL = "Bebas Neue:23"              -- repli si un MOT seul ne tient pas dans le cercle
local F_SLOT_PLUS  = "Bebas Neue:52"
local F_SLOT_HINT  = "Bebas Neue:21"
local F_BTN        = "Bebas Neue:30"
local F_BTN_SMALL  = "Bebas Neue:21"
local F_PREVIEW    = "Avenir Next World:18"

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/support) ──
local function drawCircleA(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
    drawCircleA(cx, cy, r + 1, Color(0, 0, 0, 155))
    drawCircleA(cx, cy, r, Color(23, 25, 29, 255))
    drawCircleA(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = gRespX(6), gRespX(5)
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
        cx = cx + dw + gap
    end
end

local loop = false
local animationListMenuIsOpen = false
-- DEUX PAGES de 6 emplacements (demande user 08/13) : la roue n'en affiche
-- qu'une, le sélecteur du centre bascule. Tout ce qui lit un emplacement passe
-- par radialSlots() À L'APPEL — jamais une table capturée à la création du
-- bouton, sinon le slot resterait collé à la page active à ce moment-là.
local RADIAL_PAGES = 2
local RADIAL_SLOTS = 6
local radialPages = {}
for p = 1, RADIAL_PAGES do radialPages[p] = {} end
local radialPage = 1
local function radialSlots() return radialPages[radialPage] end
local ANIMATION_DROPPABLE = "LZY_ANIMATION_ITEM"
local PREVIEW_HOVER_DELAY = 0.5
local PREVIEW_TIMER = "LZY_AnimationPreview"

-- Persistance des emplacements radiaux : on stocke juste l'id d'anim ; le nom
-- et l'icône sont re-résolus depuis la config au chargement (robuste si la config
-- change + valide que l'anim existe toujours). Avant : table module-locale perdue
-- au reload/reconnexion.
local RADIAL_SAVE_FILE = "lzy_animation_radial.txt"

local function FindAnimByPath(sPath)
    for _, a in ipairs(LZY_ANIMATION_MENU_CONFIG.ANIMATIONS or {}) do
        if a.animation == sPath then return a end
    end
end

local function SaveRadial()
    local out = { page = radialPage, pages = {} }
    for p = 1, RADIAL_PAGES do
        local page = {}
        for i = 1, RADIAL_SLOTS do
            local a = radialPages[p][i]
            page[i] = (a and a.animation) or false
        end
        out.pages[p] = page
    end
    file.Write(RADIAL_SAVE_FILE, util.TableToJSON(out))
end

-- L'ANCIEN format était une liste plate de 6 chemins. On le reconnaît à l'absence
-- de `pages` et on le verse dans la page 1 : sans ça, tous les favoris déjà
-- épinglés disparaissaient au premier lancement de la version à deux pages.
local function LoadRadial()
    if not file.Exists(RADIAL_SAVE_FILE, "DATA") then return end
    local data = util.JSONToTable(file.Read(RADIAL_SAVE_FILE, "DATA") or "")
    if not istable(data) then return end
    local pages = istable(data.pages) and data.pages or { data }
    for p = 1, RADIAL_PAGES do
        local src = pages[p]
        if istable(src) then
            for i = 1, RADIAL_SLOTS do
                local sPath = src[i]
                if isstring(sPath) and sPath ~= "" then
                    local a = FindAnimByPath(sPath)
                    if a then
                        radialPages[p][i] = { name = a.name, icon = a.icon, animation = a.animation }
                    end
                end
            end
        end
    end
    radialPage = math.Clamp(math.floor(tonumber(data.page) or 1), 1, RADIAL_PAGES)
end
LoadRadial()

-- IsHovered() can miss edges on some resolutions; use cursor vs panel bounds (same space as gSetSize).
local function panel_contains_cursor(pnl)
	return EVO_UI.PanelContainsCursor(pnl) -- helper partagé (extraction kit EVO_UI 2026-07-14)
end

-- Survol "rond" pour les emplacements de la roue : curseur dans le CERCLE
-- visible (et non le rectangle du bouton) -> l'état survolé colle au dessin.
local function circle_contains_cursor(pnl)
	if not IsValid(pnl) or not pnl:IsVisible() then return false end
	local mx, my = gui.MousePos()
	local lx, ly = pnl:ScreenToLocal(mx, my)
	local w, h = pnl:GetWide(), pnl:GetTall()
	local dx, dy = lx - w * 0.5, ly - h * 0.5
	local r = math.min(w, h) * 0.5
	return (dx * dx + dy * dy) <= r * r
end

-- Tronque un texte avec "..." pour tenir dans nMaxW pixels (découpe UTF-8
-- via utf8.sub pour ne pas casser les accents). À appeler à la CRÉATION
-- (résultat mis en cache), pas dans un Paint.
local function truncText(sText, sFont, nMaxW)
    return EVO_UI.TruncText(sText, sFont, nMaxW) -- helper partagé (kit EVO_UI)
end

-- Découpe un texte en lignes <= nMaxW px (nom d'anim centré dans un cercle).
local function wrapText(sText, sFont, nMaxW, nMaxLines)
    surface.SetFont(sFont)
    local lines, cur = {}, ""
    for word in string.gmatch(sText or "", "%S+") do
        local try = (cur == "") and word or (cur .. " " .. word)
        if surface.GetTextSize(try) > nMaxW and cur ~= "" then
            lines[#lines + 1] = cur
            cur = word
        else
            cur = try
        end
    end
    if cur ~= "" then lines[#lines + 1] = cur end
    if nMaxLines and #lines > nMaxLines then
        for i = #lines, nMaxLines + 1, -1 do lines[i] = nil end
        lines[nMaxLines] = truncText(lines[nMaxLines] .. "...", sFont, nMaxW)
    end
    -- Garde-fou : un MOT unique plus large que nMaxW resterait sur sa ligne et
    -- DÉBORDERAIT du cercle (SimpleText ne clippe pas) -> on tronque la ligne.
    for i = 1, #lines do
        lines[i] = truncText(lines[i], sFont, nMaxW)
    end
    return lines
end

-- Vrai si chaque mot de sText tient seul dans nMaxW px avec sFont (sert à
-- choisir la fonte des cercles : grande par défaut, compacte si mot trop long).
local function longestWordFits(sText, sFont, nMaxW)
    surface.SetFont(sFont)
    for word in string.gmatch(sText or "", "%S+") do
        if surface.GetTextSize(word) > nMaxW then return false end
    end
    return true
end

function PANEL:Init()
    self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetVisible(true)
	self:gSetSize(1920, 1080)
	self:gSetPos(0, 0)

    self:CreateRadialMenu()

    -- Liste OUVERTE PAR DÉFAUT (demande user) : le panneau latéral est visible
    -- dès l'ouverture du menu, quel que soit l'état à la fermeture précédente
    -- (le flag module-local est forcé ici à chaque création). Le bouton LISTE
    -- garde son rôle de toggle et démarre donc en état "ouvert" (accent + barre).
    self:CreateAnimationListMenu()
    animationListMenuIsOpen = true

    -- Bouton fermer ✕ standard DA (gris -> accent au survol), en haut à droite.
    local close_btn = vgui.Create("DButton", self)
    close_btn:gSetSize(56, 56)
    close_btn:gSetPos(1842, 18)
    close_btn:SetText("")
    close_btn.Paint = function(selff, w, h)
        draw.SimpleText("✕", F_X, w * 0.5, h * 0.5,
            panel_contains_cursor(selff) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    close_btn.DoClick = function()
        self:Close()
    end

    -- ── OUTILS ANIMATEUR (demande user 07/20) : visible UNIQUEMENT sur le PERSO ANIMATION
    -- (NWBool EVO_AnimChar, slots 4/5 groupe animateur) — superadmin = exception de test,
    -- même règle que le reste d'evo_animateur. Ouvre le panneau scale + self-give
    -- (tenues/accessoires/katanas <= épique), moteur serveur : evo_animateur/sv_anim_tools.lua.
    local lp = LocalPlayer()
    if IsValid(lp) and (lp:GetEvoNWBool("EVO_AnimChar", false) or lp:IsSuperAdmin()) then
        local tools_btn = vgui.Create("DButton", self)
        tools_btn:gSetSize(340, 56)
        tools_btn:gSetPos(24, 18)
        tools_btn:SetText("")
        tools_btn:SetCursor("hand")
        tools_btn.Paint = function(selff, w, h)
            local bHover = panel_contains_cursor(selff)
            RNDX.Draw(gRespY(8), 0, 0, w, h, bHover and COL_ROW_HOV or COL_ROW)
            if bHover then RNDX.Draw(gRespY(8), 0, 0, gRespX(4), h, COL_ACCENT, RNDX.NO_TR + RNDX.NO_BR) end
            draw.SimpleText("OUTILS ANIMATEUR", F_DROPDOWN, gRespX(18), h * 0.5,
                bHover and COL_ACCENT or COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        tools_btn.DoClick = function() self:OpenAnimatorTools() end
    end
end

function PANEL:Paint(w, h)
    -- Fond DA : blur plein écran + assombrissement TRÈS léger (retour user : voir
    -- la scène derrière). Voile beaucoup moins opaque que le reste des UIs.
    RNDX.Draw(0, 0, 0, w, h, COL_WHITE, RNDX.BLUR)
    RNDX.Draw(0, 0, 0, w, h, Color(5, 5, 7, 40))

    -- Titre Bebas SANS bold + entaille slash1 centrée (remplace la fine barre
    -- accent) + rappel drag & drop / clic droit.
    draw.SimpleText("ANIMATIONS", F_TITLE, w * 0.5, gRespY(134), COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    surface.SetFont(F_TITLE)
    local twT, thT = surface.GetTextSize("ANIMATIONS")
    if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, w * 0.5 - twT * 0.575, gRespY(134) + thT * 0.78,
        twT * 1.15, gRespY(10), ColorAlpha(COL_ACCENT, 245))) then
        RNDX.Draw(0, w * 0.5 - gRespX(32), gRespY(134) + thT * 0.84, gRespX(64), gRespY(3), COL_ACCENT)
    end
    draw.SimpleText("Glissez une animation de la liste sur un emplacement pour l'épingler · Clic droit : retirer · Molette : changer de page",
        F_HINT, w * 0.5, gRespY(200), COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

-- Ferme la liste déroulante des catégories (popup top-level, pas un enfant du menu) si
-- elle est ouverte. Réf directe (self.categoryMenu) + CloseDermaMenus en filet.
function PANEL:CloseCategoryDropdown()
    if IsValid(self.categoryMenu) then
        self.categoryMenu:Remove()
        self.categoryMenu = nil
    end
    CloseDermaMenus()
end

function PANEL:OnClose()
    timer.Remove(PREVIEW_TIMER)
    if IsValid(self.animationPreviewPanel) then
        self.animationPreviewPanel:Remove()
        self.animationPreviewPanel = nil
    end
    self:CloseCategoryDropdown()
    self:Remove()
    frame = nil
    animationListMenuIsOpen = false
    timer.Simple(0.1, function() can_open = true end)
end

-- Filet : la fermeture peut ne PAS passer par OnClose (retrait direct, Échap via
-- EVO_MakeEscClosable qui enveloppe OnRemove, retrait par le jeu). OnRemove tourne TOUJOURS
-- sur Remove -> on y referme aussi la liste déroulante restée orpheline.
function PANEL:OnRemove()
    self:CloseCategoryDropdown()
end

-- Fermeture par re-appui — bind CLAVIER. (Le bind SOURIS est géré dans Think ci-dessous,
-- car OnKeyCodePressed ne reçoit que le clavier.) Avantage du clavier ici : ça ne se
-- déclenche pas quand on tape dans la barre de recherche (le champ texte a le focus).
function PANEL:OnKeyCodePressed(keycode)
	if keycode == LocalPlayer():GetBindKey("animation_menu") and can_open == false then
		self:Close()
	end
end

-- Fermeture par re-appui — bind SOURIS. Quand le menu (popup) a le focus, les clics
-- partent au VGUI : ils ne passent ni par OnKeyCodePressed (clavier-only) ni par le
-- hook PlayerButtonDown. On poll donc l'état physique du bouton (input.IsButtonDown
-- gère clavier ET souris) avec détection de front montant. On ne traite ICI que la
-- souris : le clavier reste sur OnKeyCodePressed (qui ne ferme pas pendant qu'on tape
-- dans la recherche).
function PANEL:Think()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local bindKey = lp:GetBindKey("animation_menu")
	if not bindKey or bindKey < MOUSE_FIRST or bindKey > MOUSE_LAST then return end
	local down = input.IsButtonDown(bindKey)
	if self._bindWasDown == nil then
		-- 1er tick : on mémorise l'état sans agir (le bouton qui vient d'ouvrir le
		-- menu est peut-être encore enfoncé) pour éviter une fermeture instantanée.
		self._bindWasDown = down
		return
	end
	if down and not self._bindWasDown and can_open == false then
		self:Close()
		return
	end
	self._bindWasDown = down
end

-- Molette = page suivante/précédente, en boucle. L'ascenseur de la liste latérale
-- consomme la sienne, donc l'événement ne remonte ici que hors de cette liste.
function PANEL:OnMouseWheeled(delta)
	if delta == 0 then return end
	local nNew = radialPage + (delta > 0 and -1 or 1)
	if nNew < 1 then nNew = RADIAL_PAGES elseif nNew > RADIAL_PAGES then nNew = 1 end
	if nNew == radialPage then return end
	radialPage = nNew
	SaveRadial()
	LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
end

local icon_cache = {}

-- Forward-déclaré (défini plus bas) pour être visible dans le Think de la liste,
-- qui est défini AVANT la fonction elle-même.
local createAnimationPreviewPanel

-- Disposition hexagonale des 6 emplacements autour du centre (960, 528) :
-- mêmes index 1..6 que radialSlots() (sauvegarde/drag & drop inchangés).
-- Cercles agrandis (150 -> 168) pour accompagner les fontes plus grosses.
local RADIAL_SLOT_SIZE = 168
local RADIAL_SLOT_POS = {
    [1] = { 876, 239 },   -- haut
    [2] = { 699, 342 },   -- haut-gauche
    [3] = { 1054, 342 },  -- haut-droite
    [4] = { 876, 649 },   -- bas
    [5] = { 699, 547 },   -- bas-gauche
    [6] = { 1054, 547 },  -- bas-droite
}

-- Peinture d'un emplacement radial : cercle carte sombre, anneau accent au
-- survol / pendant un drag (cible de dépôt), icône ou nom de l'anim au centre,
-- "+" quand l'emplacement est vide. Aucune bordure au repos (DA).
local function paintRadialSlot(btn, slot_idx)
    btn.Paint = function(selff, w, h)
        local bHover = circle_contains_cursor(selff)
        local bDragging = dragndrop and dragndrop.IsDragging and dragndrop.IsDragging()
        -- Marqueur posé par le Receiver pendant le survol d'un drag (cf.
        -- makeRadialDropTarget) : anneau plus marqué = "lâchez ici".
        local bDropHover = (RealTime() - (selff._dropHoverT or 0)) < 0.05

        -- Cercle carte, léger grossissement au survol + enfoncement au clic.
        local d = (bHover or bDropHover) and (w - gRespX(4)) or (w - gRespX(14))
        if selff:IsDown() then d = d - gRespX(4) end
        RNDX.DrawCircle(w * 0.5, h * 0.5, d, (bHover or bDropHover) and COL_CARD_HOV or COL_CARD)

        -- Anneau accent : dépôt imminent > survol > drag en cours (pulsation).
        if bDropHover then
            RNDX.DrawCircleOutlined(w * 0.5, h * 0.5, d, COL_ACCENT, math.max(2, gRespY(3)))
        elseif bHover then
            RNDX.DrawCircleOutlined(w * 0.5, h * 0.5, d, COL_ACCENT, math.max(1, gRespY(2)))
        elseif bDragging then
            COL_PULSE.a = 110 + 70 * math.sin(RealTime() * 5)
            RNDX.DrawCircleOutlined(w * 0.5, h * 0.5, d, COL_PULSE, math.max(1, gRespY(2)))
        end

        local anim = radialSlots()[slot_idx]
        if anim then
            if anim.icon then
                local mat = icon_cache[anim.icon]
                if not mat then
                    mat = Material(anim.icon, "smooth")
                    icon_cache[anim.icon] = mat
                end
                local icon_sz = gRespY(66)
                RNDX.DrawMaterial(0, (w - icon_sz) * 0.5, (h - icon_sz) * 0.5, icon_sz, icon_sz, COL_WHITE, mat)
            else
                -- Nom sur 1 à 3 lignes centrées dans le cercle (memo par anim +
                -- largeur : pas de re-calcul par frame). Fonte agrandie par
                -- défaut ; si un MOT seul ne tient pas (ex: "Incompréhension"),
                -- repli sur la fonte compacte plutôt que de tronquer.
                if selff._wrapFor ~= anim.animation or selff._wrapW ~= w then
                    selff._wrapFor = anim.animation
                    selff._wrapW = w
                    local nMaxW = w * 0.75
                    selff._wrapFont = longestWordFits(anim.name, F_SLOT, nMaxW) and F_SLOT or F_SLOT_SMALL
                    selff._wrapLines = wrapText(anim.name, selff._wrapFont, nMaxW, 3)
                end
                local lines = selff._wrapLines or {}
                local sFont = selff._wrapFont or F_SLOT
                local lh = (sFont == F_SLOT) and gRespY(26) or gRespY(21)
                local y = h * 0.5 - (#lines - 1) * lh * 0.5
                for _, line in ipairs(lines) do
                    draw.SimpleText(line, sFont, w * 0.5, y, bHover and COL_TXT or COL_TXT_SOFT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    y = y + lh
                end
            end
        else
            -- Emplacement vide : "+" et invite de dépôt.
            draw.SimpleText("+", F_SLOT_PLUS, w * 0.5, h * 0.5 - gRespY(12),
                (bHover or bDragging) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("Glisser ici", F_SLOT_HINT, w * 0.5, h * 0.5 + gRespY(22), COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

function PANEL:CreateRadialMenu()
    -- Bouton LISTE (ouvre/ferme le panneau latéral — logique inchangée)
    local menu_btn = vgui.Create("DButton", self)
    menu_btn:gSetSize(186, 60)
    menu_btn:gSetPos(867, 462)
    menu_btn:SetText("")
    menu_btn.Paint = function(selff, w, h)
        local bHover = panel_contains_cursor(selff)
        RNDX.Draw(gRespY(12), 0, 0, w, h, bHover and COL_CARD_HOV or COL_CARD)
        draw.SimpleText("LISTE", F_BTN, w * 0.5, h * 0.5,
            (animationListMenuIsOpen or bHover) and COL_ACCENT or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        -- Petite barre accent sous le libellé quand la liste est ouverte.
        if animationListMenuIsOpen then
            RNDX.Draw(0, w * 0.5 - gRespX(20), h - gRespY(8), gRespX(40), gRespY(3), COL_ACCENT)
        end
    end
    menu_btn.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        if animationListMenuIsOpen then
            timer.Remove(PREVIEW_TIMER)
            if IsValid(self.animationPreviewPanel) then
                self.animationPreviewPanel:Remove()
                self.animationPreviewPanel = nil
            end
            if IsValid(self.animationListMenu) then
                self.animationListMenu:Remove()
            end
            animationListMenuIsOpen = false
        else
            if IsValid(self.animationListMenu) then
                self.animationListMenu:Remove()
            end
            self:CreateAnimationListMenu()
            animationListMenuIsOpen = true
        end
    end

    -- Bouton BOUCLE (interrupteur local, logique inchangée)
    local loop_btn = vgui.Create("DButton", self)
    loop_btn:gSetSize(90, 60)
    loop_btn:gSetPos(867, 528)
    loop_btn:SetText("")
    loop_btn.Paint = function(selff, w, h)
        local bHover = panel_contains_cursor(selff)
        RNDX.Draw(gRespY(12), 0, 0, w, h, bHover and COL_CARD_HOV or COL_CARD)
        draw.SimpleText("BOUCLE", F_BTN_SMALL, w * 0.5, gRespY(15),
            loop and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        -- Petit interrupteur : gris = off, accent = on.
        local swW, swH = gRespX(38), gRespY(18)
        local swX, swY = (w - swW) * 0.5, h - gRespY(28)
        RNDX.Draw(swH * 0.5, swX, swY, swW, swH, loop and COL_ACCENT or COL_SWITCH_OFF)
        local knob = swH - gRespY(6)
        local knobX = loop and (swX + swW - knob - gRespY(3)) or (swX + gRespY(3))
        RNDX.DrawCircle(knobX + knob * 0.5, swY + swH * 0.5, knob, COL_TXT)
    end
    loop_btn.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        loop = not loop
    end

    -- Bouton STOP (annule l'emote en cours — net inchangé)
    local stop_btn = vgui.Create("DButton", self)
    stop_btn:gSetSize(90, 60)
    stop_btn:gSetPos(963, 528)
    stop_btn:SetText("")
    stop_btn.Paint = function(selff, w, h)
        local bHover = panel_contains_cursor(selff)
        RNDX.Draw(gRespY(12), 0, 0, w, h, bHover and COL_CARD_HOV or COL_CARD)
        -- Glyphe "stop" vectoriel (carré arrondi) + libellé.
        local sq = gRespY(14)
        RNDX.Draw(gRespY(3), (w - sq) * 0.5, gRespY(11), sq, sq, bHover and COL_ACCENT or COL_TXT)
        draw.SimpleText("STOP", F_BTN_SMALL, w * 0.5, h - gRespY(18),
            bHover and COL_TXT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    stop_btn.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        net.Start("Evo:Server:AnimationMenu:StopAnimation")
        net.SendToServer()
    end

    -- ── Sélecteur de PAGE, sous BOUCLE/STOP. Aucun rebuild au changement : les
    -- Paint des emplacements relisent radialSlots() à chaque frame. On persiste
    -- au clic pour rouvrir le menu sur la page où on l'a laissé.
    local PAGE_GAP   = 6
    local PAGE_BTN_W = math.floor((186 - PAGE_GAP * (RADIAL_PAGES - 1)) / RADIAL_PAGES)
    for page_idx = 1, RADIAL_PAGES do
        local page_btn = vgui.Create("DButton", self)
        page_btn:gSetSize(PAGE_BTN_W, 40)
        page_btn:gSetPos(867 + (page_idx - 1) * (PAGE_BTN_W + PAGE_GAP), 596)
        page_btn:SetText("")
        page_btn:SetCursor("hand")
        page_btn.Paint = function(selff, w, h)
            local bHover  = panel_contains_cursor(selff)
            local bActive = (radialPage == page_idx)
            RNDX.Draw(gRespY(10), 0, 0, w, h, (bActive or bHover) and COL_CARD_HOV or COL_CARD)
            draw.SimpleText("PAGE " .. page_idx, F_BTN_SMALL, w * 0.5, h * 0.5 - gRespY(2),
                (bActive or bHover) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if bActive then
                RNDX.Draw(0, w * 0.5 - gRespX(16), h - gRespY(8), gRespX(32), gRespY(3), COL_ACCENT)
            end
        end
        page_btn.DoClick = function()
            if radialPage == page_idx then return end
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            radialPage = page_idx
            SaveRadial()
        end
    end

    local function makeRadialClickPlay(btn, slot_idx)
        btn.DoClick = function()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
            local anim = radialSlots()[slot_idx]
            if anim and anim.animation then
                net.Start("Evo:Server:AnimationMenu:PlayAnimation")
                net.WriteString(anim.animation)
                net.WriteBool(loop)
                net.SendToServer()
                -- Lancer une anim ferme le menu (demande user).
                self:Close()
            end
        end
    end

    local function makeRadialDropTarget(btn, slot_idx)
        btn:Droppable(ANIMATION_DROPPABLE)
        btn:Receiver(ANIMATION_DROPPABLE, function(rcv, panels, bDoDrop)
            if not bDoDrop then
                -- Survol pendant un drag : marqueur lu par paintRadialSlot
                -- (anneau accent appuyé = cible de dépôt). Aucune logique.
                rcv._dropHoverT = RealTime()
                return
            end
            local dragged = panels and panels[1]
            if not IsValid(dragged) or not dragged.animationData then return end
            radialSlots()[slot_idx] = { name = dragged.animationData.name, icon = dragged.animationData.icon, animation = dragged.animationData.animation }
            SaveRadial()
            LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        end)
    end

    -- Clic DROIT sur un emplacement : RETIRE l'anim épinglée (le slot réaffiche
    -- "+ Glisser ici") et persiste via la MÊME sauvegarde que le drag & drop
    -- (SaveRadial écrit `false` pour un slot vide, format inchangé). On wrappe
    -- OnMousePressed en interceptant MOUSE_RIGHT SANS le transmettre à la base :
    -- pas de Depressed/drag/DoClick -> rien n'est joué, le menu reste ouvert.
    -- Slot déjà vide = no-op silencieux. Le clic GAUCHE est chaîné tel quel.
    local function makeRadialRightClickClear(btn, slot_idx)
        local fOldPressed = btn.OnMousePressed
        btn.OnMousePressed = function(p, m)
            if m == MOUSE_RIGHT then
                if radialSlots()[slot_idx] then
                    radialSlots()[slot_idx] = nil
                    SaveRadial()
                    LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
                end
                return
            end
            if fOldPressed then return fOldPressed(p, m) end
        end
    end

    -- Les 6 emplacements radiaux (mêmes index, drag & drop et clic-pour-jouer qu'avant).
    for slot_idx = 1, RADIAL_SLOTS do
        local pos = RADIAL_SLOT_POS[slot_idx]
        local slot_btn = vgui.Create("DButton", self)
        slot_btn:gSetSize(RADIAL_SLOT_SIZE, RADIAL_SLOT_SIZE)
        slot_btn:gSetPos(pos[1], pos[2])
        slot_btn:SetText("")
        paintRadialSlot(slot_btn, slot_idx)
        makeRadialDropTarget(slot_btn, slot_idx)
        makeRadialClickPlay(slot_btn, slot_idx)
        makeRadialRightClickClear(slot_btn, slot_idx)
    end
end

function PANEL:CreateAnimationListMenu()
    -- Carte élargie (300x560 -> 340x640) pour accueillir les cases et le
    -- sélecteur agrandis (demande user) tout en gardant l'écart au bord droit.
    self.animationListMenu = vgui.Create("DPanel", self)
    self.animationListMenu:gSetSize(340, 640)
    self.animationListMenu:gSetPos(1540, 130)
    self.animationListMenu.Paint = function(selff, w, h)
        -- Plaque de métal noir PLATE Atelier + vis, filet DENTÉ sous l'entête.
        -- DA dashboard 08/07 : plus de liseré acier ; vis alignées 18px sur les 2 axes.
        EVO_UI.PaintCut(0, 0, w, h, COL_CARD, gRespY(14))
        local sr = gRespY(4)
        drawScrew(gRespX(18), gRespY(18), sr)
        drawScrew(w - gRespX(18), gRespY(18), sr)
        drawScrew(w - gRespX(18), h - gRespY(18), sr)
        drawScrew(gRespX(18), h - gRespY(18), sr)
        draw.SimpleText("LISTE DES ANIMATIONS", F_HEADER, gRespX(20), gRespY(28), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        drawDashes(gRespX(16), gRespY(56), w - gRespX(32), Color(255, 255, 255, 26))
    end

    -- Barre de recherche (comportement inchangé, rendu manuel du texte comme avant)
    self.searchBar = vgui.Create("DTextEntry", self.animationListMenu)
    self.searchBar:gSetSize(300, 48)
    self.searchBar:gSetPos(20, 72)
    self.searchBar:SetText("")
	self.searchBar:SetFont(F_INPUT)
	self.searchBar:SetPlaceholderText("Rechercher...")
	self.searchBar:SetDrawBackground(false)
	self.searchBar:SetDrawBorder(false)
	self.searchBar:SetTextColor(COL_TXT)
	self.searchBar:SetPlaceholderColor(Color(100, 100, 100, 255))
    self.searchBar:SetDrawLanguageID(false)
    self.searchBar.Paint = function(selff, w, h)
        RNDX.Draw(gRespY(8), 0, 0, w, h, COL_ROW)
        -- Soulignement accent quand le champ est actif (pas de bordure grise).
        if selff:IsEditing() then
            RNDX.Draw(0, gRespX(10), h - gRespY(2), w - gRespX(20), gRespY(2), COL_ACCENT)
        end

        -- Draw text
		if selff:GetText() == "" and not selff:IsEditing() then
			-- Draw placeholder text
			draw.SimpleText(selff:GetPlaceholderText(), F_INPUT, gRespX(16), h / 2, COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			-- Draw actual text
			draw.SimpleText(selff:GetText(), F_INPUT, gRespX(16), h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
    end
    self.searchBar.OnTextChanged = function()
        self:RefreshAnimationList()
    end

    -- Sélecteur de catégorie (DermaMenu custom — comportement inchangé)
    local categories = LZY_ANIMATION_MENU_CONFIG.ANIMATIONS_CATEGORIES or {}
    self.selected_category = categories[1] or ""

    -- Bouton agrandi (260x36 -> 300x46) + fonte dédiée plus grosse (demande user).
    local dropdown_btn = vgui.Create("DButton", self.animationListMenu)
    dropdown_btn:gSetSize(300, 46)
    dropdown_btn:gSetPos(20, 132)
    dropdown_btn:SetText("")
    dropdown_btn.Paint = function(selff, w, h)
        local bHover = panel_contains_cursor(selff)
        RNDX.Draw(gRespY(8), 0, 0, w, h, bHover and COL_ROW_HOV or COL_ROW)
        draw.SimpleText(self.selected_category, F_DROPDOWN, gRespX(16), h * 0.5, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        -- Chevron ▼ vectoriel (pas de glyphe hasardeux dans la fonte),
        -- agrandi pour suivre la nouvelle taille de police.
        local cx, cy = w - gRespX(24), h * 0.5
        surface.SetDrawColor(bHover and COL_ACCENT or COL_TXT_DIM)
        draw.NoTexture()
        surface.DrawPoly({
            { x = cx - gRespX(7), y = cy - gRespY(4) },
            { x = cx + gRespX(7), y = cy - gRespY(4) },
            { x = cx, y = cy + gRespY(5) },
        })
    end
    dropdown_btn.DoClick = function()
        LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
        local menu = DermaMenu()
        -- Réf stockée sur le menu principal : la liste déroulante est un popup de PREMIER
        -- NIVEAU (pas un enfant), donc pas retirée avec l'UI. On la ferme via cette réf dans
        -- OnClose/OnRemove (plus fiable que CloseDermaMenus seul).
        self.categoryMenu = menu
        -- Largeur alignée sur le bouton + look carte DA.
        menu:SetMinimumWidth(gRespX(300))
        menu.Paint = function(p, w, h)
            RNDX.Draw(gRespY(8), 0, 0, w, h, COL_CARD_OPAQUE)
        end
        for _, cat in ipairs(categories) do
            local opt = menu:AddOption(cat, function()
                LocalPlayer():EmitSound("6515xw26amw1br/5q3pv2f791tp.ogg", 75, 100, 1, CHAN_AUTO)
                self.selected_category = cat
                self:RefreshAnimationList()
            end)
            -- Hauteur des entrées. PIÈGE : DMenuOption:PerformLayout FORCE self:SetSize(w, 22)
            -- (hauteur codée en dur) à CHAQUE layout via InvalidateLayout(true) -> tout SetTall
            -- était écrasé, d'où les catégories collées. On réécrit son PerformLayout en gardant
            -- SA logique de largeur mais avec NOTRE hauteur (aération demandée). Texte centré
            -- verticalement (SetContentAlignment 4 posé par DMenuOption:Init) -> air haut/bas.
            opt.PerformLayout = function(s)
                s:SizeToContents()
                s:SetWide(s:GetWide() + 30)
                local ww = math.max(s:GetParent():GetWide(), s:GetWide())
                s:SetSize(ww, gRespY(42))
            end
            opt:SetFont(F_DROPDOWN)
            opt:SetTextColor(COL_TXT)
            -- Padding gauche pour decoller le texte du bord
            if opt.SetTextInset then opt:SetTextInset(gRespX(16), 0) end
            opt.Paint = function(p, w, h)
                -- panel_contains_cursor evite le bug d'IsHovered() qui rate les
                -- bords sur ecrans non-1080p (rounding gRespX/gRespY).
                if panel_contains_cursor(p) then
                    RNDX.Draw(gRespY(6), gRespX(4), gRespY(2), w - gRespX(8), h - gRespY(4), COL_ACCENT_SOFT)
                    RNDX.Draw(gRespY(6), gRespX(4), gRespY(2), gRespX(3), h - gRespY(4), COL_ACCENT, RNDX.NO_TR + RNDX.NO_BR)
                end
                -- Pastille accent sur la catégorie active.
                if cat == self.selected_category then
                    RNDX.DrawCircle(w - gRespX(16), h * 0.5, gRespY(7), COL_ACCENT)
                end
            end
        end
        local sx, sy = dropdown_btn:LocalToScreen(0, dropdown_btn:GetTall())
        menu:Open(sx, sy)
    end

    -- Animation List
    self.animationList = vgui.Create("DScrollPanel", self.animationListMenu)
    self.animationList:gSetSize(300, 432)
    self.animationList:gSetPos(20, 192)

    -- Ascenseur discret DA : pas de flèches, piste invisible, grip pilule
    -- sombre (accent au survol).
    local vbar = self.animationList:GetVBar()
    if IsValid(vbar) then
        vbar:SetWide(math.max(4, gRespX(6)))
        vbar:SetHideButtons(true)
        vbar.Paint = function() end
        vbar.btnGrip.Paint = function(selff, w, h)
            RNDX.Draw(w * 0.5, 0, 0, w, h, panel_contains_cursor(selff) and COL_ACCENT or COL_SCROLL)
        end
    end

    -- Gestionnaire de survol UNIQUE : poll géométrique (panel_contains_cursor)
    -- chaque frame pour déclencher l'aperçu 3D, au lieu de l'événement natif
    -- OnCursorEntered (qui rate des bords sur écrans non-1080p, comme le souligne
    -- déjà le code). Couvre toute la case, sur toute résolution, et évite les
    -- races entre boutons (un seul "hovered" à la fois, ordre-indépendant).
    self.animationList.Think = function(sp)
        local canvas = sp:GetCanvas()
        local hovered = nil
        if IsValid(canvas) and panel_contains_cursor(sp) then
            for _, child in ipairs(canvas:GetChildren()) do
                if child.animationData and panel_contains_cursor(child) then
                    hovered = child
                    break
                end
            end
        end
        if hovered == self._previewHoverBtn then return end
        self._previewHoverBtn = hovered

        timer.Remove(PREVIEW_TIMER)
        if IsValid(self.animationPreviewPanel) then
            self.animationPreviewPanel:Remove()
            self.animationPreviewPanel = nil
        end
        if IsValid(hovered) then
            local frameref, data, btnref = self, hovered.animationData, hovered
            timer.Create(PREVIEW_TIMER, PREVIEW_HOVER_DELAY, 1, function()
                timer.Remove(PREVIEW_TIMER)
                if not IsValid(btnref) or not panel_contains_cursor(btnref) then return end
                if not IsValid(frameref) then return end
                if IsValid(frameref.animationPreviewPanel) then return end
                frameref.animationPreviewPanel = createAnimationPreviewPanel(frameref, data, btnref)
            end)
        end
    end

    self:RefreshAnimationList()
end

function createAnimationPreviewPanel(parent, anim_data, btn)
    if not parent or not anim_data or not anim_data.animation then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local characterData = (GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply)) or nil
    local faceModel = ply:GetModel()
    if characterData and LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
        faceModel = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender) or faceModel
    end

    local panel = vgui.Create("DPanel", parent)
    panel:gSetSize(220, 280)
    panel:SetZPos(10000)
    -- Nom tronqué une fois (affiché en pied de carte).
    local previewName = truncText(anim_data.name or "", F_PREVIEW, gRespX(196))
    panel.Paint = function(p, w, h)
        -- Carte DA : fond #0E0E11 + liseré accent à gauche, nom de l'anim en pied.
        RNDX.Draw(gRespY(10), 0, 0, w, h, COL_CARD_OPAQUE)
        RNDX.Draw(gRespY(10), 0, 0, gRespX(4), h, COL_ACCENT, RNDX.NO_TR + RNDX.NO_BR)
        draw.SimpleText(previewName, F_PREVIEW, w * 0.5, h - gRespY(16), COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local modelOverlay = nil
    if characterData and characterData.body_model and characterData.hair_model and MUGEN and MUGEN.Character and MUGEN.Character.Config then
        modelOverlay = ClientsideModel(MUGEN.Character.Config.StandartModel or "models/ali/bleach/vetement_homme.mdl", RENDER_GROUP_OPAQUE_ENTITY)
        if IsValid(modelOverlay) then
            modelOverlay:SetNoDraw(true)
            modelOverlay:SetSkin(ply:GetSkin() or 0)
            local bodygroupsTable = util.JSONToTable(ply:GetEvoNWString("OverlayBodygroups", "{}"))
            if istable(bodygroupsTable) then
                for indexStr, value in pairs(bodygroupsTable) do
                    local index = tonumber(indexStr)
                    if index and isnumber(value) and modelOverlay:GetBodygroupCount(index) > 1 then
                        modelOverlay:SetBodygroup(index, value)
                    end
                end
            end
        end
    end

    panel.OnRemove = function()
        if IsValid(panel.modelPanel) and panel.modelPanel.Entity and panel.modelPanel.Entity.PlayerModelParts then
            for _, e in pairs(panel.modelPanel.Entity.PlayerModelParts) do
                if istable(e) then
                    for _, sub in ipairs(e) do
                        if IsValid(sub) then SafeRemoveEntity(sub) end
                    end
                elseif IsValid(e) then SafeRemoveEntity(e) end
            end
            panel.modelPanel.Entity.PlayerModelParts = nil
            panel.modelPanel.Entity.RenderOverride = nil
        end
        if IsValid(modelOverlay) then SafeRemoveEntity(modelOverlay) end
    end

    local modelPanel = vgui.Create("DModelPanel", panel)
    panel.modelPanel = modelPanel
    modelPanel:Dock(FILL)
    -- Marge basse responsive : laisse la place au nom de l'anim en pied de carte.
    modelPanel:DockMargin(4, 4, 4, gRespY(30))
    modelPanel:SetModel(faceModel)
    modelPanel:SetAnimated(true)
    modelPanel:SetCamPos(Vector(75, 0, 48))
    modelPanel:SetLookAt(Vector(0, 0, 42))
    modelPanel:SetFOV(50)
    modelPanel.PreDrawModel = function() end

    local seqName = anim_data.animation
    local entitySetup = false
    local camAdjusted = false
    modelPanel.LayoutEntity = function(pnl, ent)
        if not IsValid(ent) then return end
        if not camAdjusted then
            camAdjusted = true
            local mn, mx = ent:GetRenderBounds()
            local size = (mx - mn):Length()
            local dist = math.max(85, size * 0.95)
            local center = (mn + mx) * 0.5
            pnl:SetCamPos(center + Vector(dist, 0, dist * 0.25))
            pnl:SetLookAt(center)
        end
        if not entitySetup then
            entitySetup = true
            if characterData and characterData.body_model and characterData.hair_model then
                ent:SetSkin(characterData.skin_color or 0)
                if characterData.bodygroupsString and ent.SetBodyGroups then ent:SetBodyGroups(characterData.bodygroupsString) end
                LZY_Character_PlayerModel_SetupPanelEntity(ent, characterData, modelOverlay)
            else
                ent:SetSkin(ply:GetSkin() or 0)
                for i = 0, (ply:GetNumBodyGroups() or 0) - 1 do
                    ent:SetBodygroup(i, ply:GetBodygroup(i) or 0)
                end
            end
        end
        local seq = ent:LookupSequence(seqName)
        if seq and seq >= 0 then
            if ent._previewSeq ~= seq then
                ent._previewSeq = seq
                ent:ResetSequence(seq)
            end
            ent:FrameAdvance(RealFrameTime())
        end
    end

    local sx, sy = btn:LocalToScreen(0, 0)
    local px, py = parent:ScreenToLocal(sx, sy)
    -- Décalage RESPONSIVE (largeur de carte 220 + marge) : l'ancien "- 230" brut
    -- faisait chevaucher l'aperçu et la carte liste sur écrans non-1080p.
    px = px - gRespX(250)
    if px < 10 then
        px, py = parent:ScreenToLocal(sx + btn:GetWide() + 10, sy)
    end
    panel:SetPos(math.max(10, px), py)
    return panel
end

function PANEL:RefreshAnimationList()
    if not IsValid(self.animationList) then return end
    local canvas = self.animationList:GetCanvas()
    if canvas then canvas:Clear() end
    local animations = LZY_ANIMATION_MENU_CONFIG.ANIMATIONS or {}
    local search = string.Trim((IsValid(self.searchBar) and self.searchBar:GetText() or ""):lower())
    local category = self.selected_category or ""

    -- Cases agrandies (46 -> 62) pour une lecture confortable (demande user) ;
    -- moins de cases visibles = OK, l'ascenseur prend le relais.
    local btn_h = 62
    local btn_spacing = 8
    local idx = 0
    for _, anim_data in ipairs(animations) do
        local matches_search = search == "" or (anim_data.name and anim_data.name:lower():find(search, 1, true))
        local matches_category = search ~= "" or anim_data.category == category
        if matches_search and matches_category then
            local btn = vgui.Create("DButton", canvas)
            btn:SetText("")
            if btn.SetPaintBackground then btn:SetPaintBackground(false) end
            btn:SetMouseInputEnabled(true)
            btn:gSetSize(286, btn_h)
            btn:gSetPos(0, idx * (btn_h + btn_spacing))
            btn.animationData = anim_data
            btn:SetCursor("hand")
            btn:Droppable(ANIMATION_DROPPABLE)
            -- Nom tronqué UNE FOIS à la création (pas de mesure par frame).
            local displayName = truncText(anim_data.name or "", F_ROW, gRespX(250))
            btn.Paint = function(p, w, h)
                local bHover = panel_contains_cursor(p)
                RNDX.Draw(gRespY(8), 0, 0, w, h, bHover and COL_ROW_HOV or COL_ROW)
                if bHover then
                    -- Liseré accent à gauche = marque DA du survol.
                    RNDX.Draw(gRespY(8), 0, 0, gRespX(4), h, COL_ACCENT, RNDX.NO_TR + RNDX.NO_BR)
                end
                draw.SimpleText(displayName, F_ROW, gRespX(16), h * 0.32, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText(anim_data.category or "", F_ROW_CAT, gRespX(16), h * 0.73,
                    bHover and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            -- (Aperçu géré par le Think unique de self.animationList : poll fiable
            -- panel_contains_cursor, couvre toute la case sur toute résolution.)
            btn.OnMousePressed = function(p, m)
                surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
                if m == MOUSE_LEFT then
                    p:DragMousePress(m)
                    local world = vgui.GetWorldPanel()
                    if IsValid(world) then world:SetCursor("hand") end
                end
            end
            btn.OnMouseReleased = function(p, m)
                p:DragMouseRelease(m)
                local world = vgui.GetWorldPanel()
                if IsValid(world) then world:SetCursor("arrow") end
                -- Clic simple (relâché SUR le bouton, pas glissé vers un emplacement
                -- radial) -> jouer l'anim directement, sans passer par le drag.
                if m == MOUSE_LEFT and panel_contains_cursor(p) and p.animationData and p.animationData.animation then
                    net.Start("Evo:Server:AnimationMenu:PlayAnimation")
                    net.WriteString(p.animationData.animation)
                    net.WriteBool(loop)
                    net.SendToServer()
                    -- Clic simple sur une anim de la liste -> on la joue ET on ferme le
                    -- menu (demande user). Le drag-vers-emplacement-radial ne passe pas
                    -- ici (panel_contains_cursor faux quand relâché ailleurs).
                    self:Close()
                end
            end
            idx = idx + 1
        end
    end
    self.animationList:Rebuild()
end

-- ══════════════════════════════════════════════════════════════════════════════
-- OUTILS ANIMATEUR (demande user 07/20) — panneau ouvert depuis le bouton du menu.
--   • SCALE 0.8 - 1.4 (net EVO:AnimTools:Scale, appliqué serveur).
--   • SELF-GIVE : browser façon menu SAM (recherche + onglets Tenues / Accessoires /
--     Katanas), rareté selon le PALIER (Gérant : jusqu'au LÉGENDAIRE depuis le 08/20).
--     Net EVO:AnimTools:Give, REVALIDÉ serveur
--     (evo_animateur/sv_anim_tools.lua — le filtre ci-dessous en est le MIROIR client).
--   Ces items ne peuvent pas sortir du perso animation : jet + trade bloqués serveur.
-- ══════════════════════════════════════════════════════════════════════════════
-- Raretés autorisées = PALIER animateur (EVO_ANIM.Caps[tier].itemRarity, miroir du
-- serveur sv_anim_tools qui revalide). Fallback ancien périmètre si EVO_ANIM absent.
-- Par OBJET (EVO_ANIM.RarityFor, sh_anim_tiers) : les tenues ont leur propre plafond,
-- epique pour l'Animateur depuis le 09/10. Le serveur revalide avec la meme fonction.
local function atRarityOk(it)
    local cap = EVO_ANIM and EVO_ANIM.Cap and EVO_ANIM.Cap(LocalPlayer())
    if cap and EVO_ANIM.RarityFor then return EVO_ANIM.RarityFor(cap, it) end
    return (cap and cap.itemRarity) or { common = true, rare = true, epic = true }
end
local AT_RARITY_COL = {
    common    = Color(160, 164, 172),
    rare      = Color(90, 140, 220),
    epic      = Color(165, 95, 225),
    legendary = Color(224, 176, 60), -- or : ouvert au Gérant depuis le 08/20
}
local AT_TABS = {
    { key = "outfit",    label = "TENUES" },
    { key = "accessory", label = "ACCESSOIRES" },
    { key = "katana",    label = "KATANAS" },
    { key = "hakuda",    label = "HAKUDA" },
}

-- Liste filtrée du catalogue (catégorie + recherche). Les ARMES sont discriminées par leur id
-- de skin, jamais par category (elles sont toutes en "object") : skin_id pour les katanas
-- (KATANA_SKINS), gauntlet_id pour les gantelets Hakuda (NCM_HAKUDA_GAUNTLETS).
local function atBuildList(sCat, sQuery)
    local out = {}
    if not ITEMS then return out end
    sQuery = string.lower(sQuery or "")
    for id, it in pairs(ITEMS) do
        -- Exclusions (nominatives + armes de Shikai) : verdict partagé EVO_ANIM.EstItemExclu,
        -- le même que la revalidation serveur.
        local bExclu = EVO_ANIM and EVO_ANIM.EstItemExclu and EVO_ANIM.EstItemExclu(id, it)
        if istable(it) and not it.evo_carte and not bExclu then
            local bKatana   = isstring(it.skin_id) and it.skin_id ~= ""
            local bGauntlet = isstring(it.gauntlet_id) and it.gauntlet_id ~= ""
            local bMatch = (sCat == "katana" and bKatana)
                or (sCat == "hakuda" and bGauntlet)
                or (not bKatana and not bGauntlet and it.category == sCat)
            if bMatch and atRarityOk(it)[it.rarity or "common"] then
                local sName = string.lower(it.name or id)
                if sQuery == "" or string.find(sName, sQuery, 1, true) or string.find(string.lower(id), sQuery, 1, true) then
                    out[#out + 1] = { id = id, name = it.name or id, icon = it.icon, rarity = it.rarity or "common" }
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

-- Cache de materials d'icônes (jamais re-créés par frame ; IsError -> placeholder).
local _atMatCache = {}
local function atIconMat(sPath)
    if not isstring(sPath) or sPath == "" then return nil end
    local m = _atMatCache[sPath]
    if m == nil then
        m = Material(sPath, "smooth")
        _atMatCache[sPath] = m
    end
    if m:IsError() then return nil end
    return m
end

-- Panneau EXPOSÉ en global (demande user 08/02) : le menu animateur (evo_animateur)
-- l'ouvre directement, sans passer par le menu des animations — même panneau, zéro doublon.
-- parent optionnel : nil = fenêtre autonome (au-dessus du menu animateur).
local atFrame
function LZY_AnimMenu_OpenAnimatorTools(parent)
    if IsValid(atFrame) then atFrame:Remove() end

    -- Plafond de taille du PALIER (le Gérant monte à ×2) : même source que le clamp serveur.
    local atScaleMin = (EVO_ANIM and EVO_ANIM.SCALE_MIN) or 0.8
    local atScaleMax = (EVO_ANIM and EVO_ANIM.ScaleMax and EVO_ANIM.ScaleMax(LocalPlayer())) or 1.4

    local f = vgui.Create("DFrame", IsValid(parent) and parent or nil)
    atFrame = f
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:SetDraggable(false)
    f:gSetSize(1000, 820)
    f:Center()
    f:MakePopup()
    if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
    f.Paint = function(_, w, h)
        RNDX.Draw(gRespY(10), 0, 0, w, h, Color(14, 14, 17, 250))
        draw.SimpleText("OUTILS ANIMATEUR", F_DROPDOWN, gRespX(24), gRespY(34), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
            surface.SetFont(F_DROPDOWN)
            local tw = surface.GetTextSize("OUTILS ANIMATEUR")
            EVO_UI.Ink(EVO_UI.TexSlash, gRespX(24), gRespY(52), tw, gRespY(7), ColorAlpha(COL_ACCENT, 235))
        end
        draw.SimpleText(string.format("TAILLE DU PERSONNAGE  (%.1f - %.1f)", atScaleMin, atScaleMax),
            F_HINT, gRespX(24), gRespY(86), COL_TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("Clic = se donner   ·   Clic droit = apercu 3D", F_HINT, gRespX(920), gRespY(38),
            COL_TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end

    local x = vgui.Create("DButton", f)
    x:gSetSize(48, 48) x:gSetPos(944, 10) x:SetText("") x:SetCursor("hand")
    x.Paint = function(s, w, h)
        draw.SimpleText("✕", F_X, w * 0.5, h * 0.5,
            panel_contains_cursor(s) and COL_ACCENT or COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = function() f:Remove() end

    -- ── SCALE : slider 0.8-1.4, envoi DÉBOUNCÉ (0.25 s) — le serveur throttle aussi.
    local slider = vgui.Create("DNumSlider", f)
    slider:gSetPos(16, 104)
    slider:gSetSize(960, 44)
    slider:SetText("")
    slider:SetMin(atScaleMin) slider:SetMax(atScaleMax) slider:SetDecimals(2)
    slider:SetValue(math.Clamp(LocalPlayer():GetModelScale() or 1, atScaleMin, atScaleMax))
    slider.OnValueChanged = function(_, nVal)
        timer.Create("EVO_AnimTools_ScaleSend", 0.25, 1, function()
            net.Start("EVO:AnimTools:Scale")
            net.WriteFloat(math.Clamp(tonumber(nVal) or 1, atScaleMin, atScaleMax))
            net.SendToServer()
        end)
    end

    -- ── SELF-GIVE : onglets + recherche + grille.
    f._atCat = "outfit"

    local tabBtns = {}
    for i, t in ipairs(AT_TABS) do
        local b = vgui.Create("DButton", f)
        -- 4 onglets sur la largeur laissée par la recherche (qui commence à 672).
        b:gSetSize(150, 46)
        b:gSetPos(24 + (i - 1) * 158, 162)
        b:SetText("") b:SetCursor("hand")
        b.Paint = function(s, w, h)
            local bOn = f._atCat == t.key
            RNDX.Draw(gRespY(8), 0, 0, w, h, (bOn or panel_contains_cursor(s)) and COL_ROW_HOV or COL_ROW)
            if bOn then RNDX.Draw(0, 0, h - gRespY(3), w, gRespY(3), COL_ACCENT) end
            draw.SimpleText(t.label, F_DROPDOWN, w * 0.5, h * 0.5,
                bOn and COL_ACCENT or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function()
            f._atCat = t.key
            f:RebuildAnimToolsGrid()
        end
        tabBtns[#tabBtns + 1] = b
    end

    local search = vgui.Create("DTextEntry", f)
    search:gSetSize(304, 46)
    search:gSetPos(672, 162)
    search:SetFont(F_INPUT)
    search:SetPlaceholderText("Rechercher un objet...")
    if search.SetDrawLanguageID then search:SetDrawLanguageID(false) end
    search:SetUpdateOnType(true)
    search.OnValueChange = function()
        -- Débounce : pas de rebuild par frappe (catalogue ~100+ items par onglet).
        timer.Create("EVO_AnimTools_Search", 0.15, 1, function()
            if IsValid(f) then f:RebuildAnimToolsGrid() end
        end)
    end
    f._atSearch = search

    local scroll = vgui.Create("DScrollPanel", f)
    scroll:gSetPos(24, 224)
    scroll:gSetSize(952, 572)
    local grid = vgui.Create("DIconLayout", scroll)
    grid:Dock(FILL)
    grid:SetSpaceX(gRespX(10))
    grid:SetSpaceY(gRespY(10))
    f._atGrid = grid

    function f:RebuildAnimToolsGrid()
        if not IsValid(self._atGrid) then return end
        self._atGrid:Clear()
        local rows = atBuildList(self._atCat, IsValid(self._atSearch) and self._atSearch:GetValue() or "")
        local P = LZY_INVENTORY_ITEM_PREVIEW
        for _, r in ipairs(rows) do
            local card = self._atGrid:Add("DButton")
            card:gSetSize(180, 200)
            card:SetText("") card:SetCursor("hand")
            local mat = atIconMat(r.icon)
            local cRar = AT_RARITY_COL[r.rarity] or AT_RARITY_COL.common
            local displayName = truncText(r.name, F_ROW_CAT, gRespX(164))

            -- APERÇU 3D dans la vignette (demande user 08/04). L'icône 2D du catalogue est
            -- PARTAGÉE par toute une catégorie — toutes les tenues portent la même image, donc
            -- la grille était illisible. On monte le vrai modèle via le composant d'aperçu de
            -- l'inventaire (cadrage + variante de rareté + file de chargement 1 modèle/frame,
            -- d'où l'absence de freeze à l'ouverture). L'icône reste le repli.
            local it = ITEMS and ITEMS[r.id]
            local bModel = P and P.ItemHasModelPreview and P.SetupModelPanel and P.ItemHasModelPreview(it)
            if bModel then
                local host = vgui.Create("DPanel", card)
                host:gSetPos(10, 14)
                host:gSetSize(160, 132)
                host:SetMouseInputEnabled(false) -- le clic doit atteindre la carte
                P.SetupModelPanel(host, it, 30)
            end

            card.Paint = function(s, w, h)
                local bHover = panel_contains_cursor(s)
                RNDX.Draw(gRespY(8), 0, 0, w, h, bHover and COL_ROW_HOV or COL_ROW)
                RNDX.Draw(0, 0, 0, w, gRespY(3), cRar) -- liseré rareté en haut
                if bModel then
                    -- rien : le DModelPanel enfant dessine par-dessus
                elseif mat then
                    local isz = math.min(w, h) - gRespX(64)
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.SetMaterial(mat)
                    surface.DrawTexturedRect((w - isz) * 0.5, gRespY(18), isz, isz)
                else
                    draw.SimpleText("-", F_DROPDOWN, w * 0.5, h * 0.42, COL_TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                draw.SimpleText(displayName, F_ROW_CAT, w * 0.5, h - gRespY(38), bHover and COL_ACCENT or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(string.upper(r.rarity), F_ROW_CAT, w * 0.5, h - gRespY(16), cRar, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            card.DoClick = function()
                surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
                net.Start("EVO:AnimTools:Give")
                net.WriteString(r.id)
                net.SendToServer()
            end
            -- Clic droit = APERÇU 3D porté par ton perso (demande user 08/04). On réutilise la
            -- preview cosmétique de la boutique : elle bonemerge l'objet sur le modèle de FACE
            -- du joueur, donc les tenues (qui sont des corps sans tête) s'affichent complètes.
            card.DoRightClick = function()
                local bOk = it and isstring(it.model_path) and it.model_path ~= ""
                    and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open
                if not bOk then
                    if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Pas d'aperçu 3D pour cet objet.", NOTIFY_ERROR, 3) end
                    return
                end
                surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
                LZY_SHOP_COSMETIC_PREVIEW.Open(it)
            end
        end
        self._atGrid:Layout()
    end

    -- Chargement des modèles étalé (1 par frame) à la 1re ouverture de la session : sans ça,
    -- monter ~100 modèles d'un coup fait décrocher l'image.
    if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
        LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("animator_tools")
    end
    f:RebuildAnimToolsGrid()

    f.OnRemove = function()
        timer.Remove("EVO_AnimTools_ScaleSend")
        timer.Remove("EVO_AnimTools_Search")
    end
    return f
end

function PANEL:OpenAnimatorTools()
    self.animatorTools = LZY_AnimMenu_OpenAnimatorTools(self)
end

vgui.Register("lzy_animation_menu", PANEL, "DFrame")

local function OpenAnimationMenu()
    if IsValid(frame) then
        frame:Close()
    else
        frame = vgui.Create("lzy_animation_menu")
        can_open = false
    end
end

hook.Add("PlayerButtonDown", "AnimationMenu_OpenMenu", function(ply, button)
    if button == LocalPlayer():GetBindKey("animation_menu") and can_open == true then
        OpenAnimationMenu()
    end
end)
