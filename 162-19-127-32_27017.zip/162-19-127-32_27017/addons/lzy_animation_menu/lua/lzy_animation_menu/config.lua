-- "addons\\lzy_animation_menu\\lua\\lzy_animation_menu\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_ANIMATION_MENU_CONFIG = LZY_ANIMATION_MENU_CONFIG or {}

LZY_ANIMATION_MENU_CONFIG.ANIMATIONS_CATEGORIES = {
    "Salutations",
    "Émotions",
    "Gestes",
    "Debout",
    "Assis",
    "Au Sol",
}

LZY_ANIMATION_MENU_CONFIG.ANIMATIONS = {
    -- Salutations
    {
        name = "Faire coucou",
        animation = "evo_v8zamttvabe3rcgr",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "Faire coucou (autre)",
        animation = "evo_svpcj4sf7uo6",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "Saluer de la tête",
        animation = "evo_pu8b6de0wak1951",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "Révérence",
        animation = "evo_8jz064pazaxvs0j",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "Salut de loin",
        animation = "evo_bg0f7e2fysk1hp1",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "S'incliner",
        animation = "evo_xvj5filk92q0uy07d",
        icon = nil,
        category = "Salutations",
    },
    {
        name = "Prostration",
        animation = "evo_cddb6oky75170vv",
        icon = nil,
        category = "Salutations",
    },

    -- Émotions
    {
        name = "Joie",
        animation = "evo_x7nv9x9bnaoh",
        icon = nil,
        category = "Émotions",
    },
    {
        name = "Rire",
        animation = "evo_wdu6fgaz4r3x",
        icon = nil,
        category = "Émotions",
    },
    {
        name = "Colère",
        animation = "evo_s4zdyjjuikkev6uav",
        icon = nil,
        category = "Émotions",
    },
    {
        name = "Pleurer",
        animation = "evo_2rjm3i88q4p16",
        icon = nil,
        category = "Émotions",
    },
    {
        name = "Panique",
        animation = "evo_lnfml4bsbiz3y",
        icon = nil,
        category = "Émotions",
    },
    {
        name = "Incompréhension",
        animation = "evo_d1cqftpekvos",
        icon = nil,
        category = "Émotions",
    },

    -- Gestes
    {
        name = "Montrer du doigt",
        animation = "evo_te86mqrwqlt6ak3",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Acquiescer",
        animation = "evo_5jjn2a2g37m53p",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Se gratter la tête",
        animation = "evo_2msvp98e3oh3a",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Réfléchir",
        animation = "evo_6ns1g5zgwz6oa9xp",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Proposer",
        animation = "evo_418jm9e8lbscuqt6n",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Hein ?",
        animation = "evo_4ogp9vrrcjw4dtfd",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Applaudir",
        animation = "evo_zy360mi1vakeej",
        icon = nil,
        category = "Gestes",
    },
    {
        name = "Calmer",
        animation = "evo_tsvvp6l4hn01",
        icon = nil,
        category = "Gestes",
    },

    -- Debout
    {
        name = "Bras croisés",
        animation = "evo_jhcb4o7px1yz3",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Bras croisés (autre)",
        animation = "evo_5ilt23e0w6z7hh",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Attendre",
        animation = "evo_usfpc0dmqdhmwoh9",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Poser tranquille",
        animation = "evo_gdw2emeap1ck6ff",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Pose cool",
        animation = "evo_qd9likmrj3hnpsu8",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Main sur le coeur",
        animation = "evo_fl8lzok29qqb0",
        icon = nil,
        category = "Debout",
    },
    {
        name = "Mains jointes",
        animation = "evo_t9ed5d453empc541",
        icon = nil,
        category = "Debout",
    },
    -- Assis
    {
        name = "À genoux",
        animation = "evo_jx5gialady6z6o",
        icon = nil,
        category = "Assis",
    },
    {
        name = "Assis au sol",
        animation = "evo_dka1l1lotc93",
        icon = nil,
        category = "Assis",
    },
    {
        name = "En tailleur",
        animation = "evo_mmcti5028z5h",
        icon = nil,
        category = "Assis",
    },
    {
        name = "Assis décontracté",
        animation = "evo_73xi2thsdf53onfvz",
        icon = nil,
        category = "Assis",
    },
    {
        name = "Accroupi",
        animation = "evo_o1pgm0qp8i307cmnr",
        icon = nil,
        category = "Assis",
    },
    {
        name = "Agenouillé",
        animation = "evo_9s25xpgepeqebgplp",
        icon = nil,
        category = "Assis",
    },
    {
        name = "Assis mignon",
        animation = "evo_xpz88n97m7rwukc3b",
        icon = nil,
        category = "Assis",
    },

    -- Au Sol
    {
        name = "Allongé sur le ventre",
        animation = "evo_zaoqmalvvo906xmw",
        icon = nil,
        category = "Au Sol",
    },
    {
        name = "Allongé sur le ventre (autre)",
        animation = "evo_q8y7h9q2n1pc4",
        icon = nil,
        category = "Au Sol",
    },
    {
        name = "Allongé sur le dos",
        animation = "evo_ca1g2is0q0w26o1dt",
        icon = nil,
        category = "Au Sol",
    },
    {
        name = "Faire le mort",
        animation = "evo_af3l1iuop8z5x8",
        icon = nil,
        category = "Au Sol",
    },

    -- ── Ajouts (demande user) : idles/emotes STAND_IDLE non encore présents (déduplication faite
    --    contre les 39 déjà listés ci-dessus). Noms FR + catégorie déduits de la table SMD fournie. ──
    -- Salutations
    { name = "Agiter les mains",         animation = "evo_ezbvwo6r7814",       icon = nil, category = "Salutations" },
    { name = "Grande révérence",         animation = "evo_lrmmxxtiojca2",      icon = nil, category = "Salutations" },

    -- Émotions
    { name = "Abattu",                   animation = "evo_1w1a1ivmh4up4662u",  icon = nil, category = "Émotions" },
    { name = "Méfiance",                 animation = "evo_45gzeuyeu9wslo",     icon = nil, category = "Émotions" },
    { name = "Bisou soufflé",            animation = "evo_6i7rzdev927yn62p9",  icon = nil, category = "Émotions" },
    { name = "Bisou soufflé (cool)",     animation = "evo_8bzums76skai81",     icon = nil, category = "Émotions" },
    { name = "Se pavaner",               animation = "evo_9yx3lb6ta6yad76",    icon = nil, category = "Émotions" },
    { name = "Refus",                    animation = "evo_b75w69ns0qm391htr",  icon = nil, category = "Émotions" },
    { name = "Embarrassé",               animation = "evo_byny2b867whonev",    icon = nil, category = "Émotions" },
    { name = "Ravi (cool 2)",            animation = "evo_dtivya97hy41qb",     icon = nil, category = "Émotions" },
    { name = "Regret",                   animation = "evo_fkdzpjoytcx4prv",    icon = nil, category = "Émotions" },
    { name = "Joie (M)",                 animation = "evo_hdkil3dybvs1rd9o",   icon = nil, category = "Émotions" },
    { name = "Pensif",                   animation = "evo_k2hj56uwg6xalv",     icon = nil, category = "Émotions" },
    { name = "Bisou soufflé (cool 2)",   animation = "evo_mkfjhzuf6fn0",       icon = nil, category = "Émotions" },
    { name = "Ravi (mignon)",            animation = "evo_ml7hplae200hc0ju",   icon = nil, category = "Émotions" },
    { name = "Supplier",                 animation = "evo_n3e4shx6hp4pmc",     icon = nil, category = "Émotions" },
    { name = "Air malin",                animation = "evo_p1f8adr3s0zd2t",     icon = nil, category = "Émotions" },
    { name = "Bisou soufflé (mignon 2)", animation = "evo_t1lab34bpugxq5ly",   icon = nil, category = "Émotions" },
    { name = "Fièrement",                animation = "evo_vd203ezpvts0m29",    icon = nil, category = "Émotions" },
    { name = "Ravi (cool)",              animation = "evo_yjpz721owrb8bmuse",  icon = nil, category = "Émotions" },
    { name = "Frimer",                   animation = "evo_yoatqzbl5i2q79y0",   icon = nil, category = "Émotions" },

    -- Gestes
    { name = "Création 03",              animation = "evo_18qmcwdf9kjpnc",     icon = nil, category = "Gestes" },
    { name = "Bonhomme de neige",        animation = "evo_23dkgpp1njj5igvtw",  icon = nil, category = "Gestes" },
    { name = "Création 03 (M)",          animation = "evo_2lmo5d84zs734r",     icon = nil, category = "Gestes" },
    { name = "Danse club",               animation = "evo_4jihd2q4doplu",      icon = nil, category = "Gestes" },
    { name = "Danse aux bâtons",         animation = "evo_7j9lhq5wdfyxuxr4",   icon = nil, category = "Gestes" },
    { name = "Invocation",               animation = "evo_8nfu1nk27ilme",      icon = nil, category = "Gestes" },
    { name = "Encourager",               animation = "evo_9a8meh5cifo24l",     icon = nil, category = "Gestes" },
    { name = "Danse du ventre",          animation = "evo_9xhd08l0xwiye4",     icon = nil, category = "Gestes" },
    { name = "Création 04 (M)",          animation = "evo_bs8432pbipia0ttu",   icon = nil, category = "Gestes" },
    { name = "Création 02",              animation = "evo_fwxg0zs6yzlmv1",     icon = nil, category = "Gestes" },
    { name = "Création 02 (M)",          animation = "evo_hkfeqbdntt76yda8",   icon = nil, category = "Gestes" },
    { name = "Oreilles de lapin",        animation = "evo_i05zovvqpbf0y5",     icon = nil, category = "Gestes" },
    { name = "Prière",                   animation = "evo_ig197a41uy7n98ubu",  icon = nil, category = "Gestes" },
    { name = "S'étirer",                 animation = "evo_jqhz5p9dxbv7d2drm",  icon = nil, category = "Gestes" },
    { name = "Danse d'idole",            animation = "evo_m2etkgpdjc4xyl",     icon = nil, category = "Gestes" },
    { name = "Serpentins",               animation = "evo_prhhuljqgcax5",      icon = nil, category = "Gestes" },
    { name = "Bâton lumineux",           animation = "evo_r5ohm6r1g5vpbrd",    icon = nil, category = "Gestes" },
    { name = "Manger",                   animation = "evo_rhgykp2904100zmb",   icon = nil, category = "Gestes" },
    { name = "Viens ici",                animation = "evo_s3xw9mx0q4hk13hmw",  icon = nil, category = "Gestes" },
    { name = "Création 01 (M)",          animation = "evo_sqawcx4oa8qyghw5x",  icon = nil, category = "Gestes" },
    { name = "Gimmick",                  animation = "evo_tedseoqmgzx1uipe",   icon = nil, category = "Gestes" },
    { name = "Hurler (loup)",            animation = "evo_tis0jz6tjb121gd",    icon = nil, category = "Gestes" },
    { name = "Machine de fabrication",   animation = "evo_to0lqhhw2gfa2r",     icon = nil, category = "Gestes" },
    { name = "Poser au sol",             animation = "evo_u33fr4nx02qdnrw2",   icon = nil, category = "Gestes" },
    { name = "Création 04",              animation = "evo_u7vfsln1d6l56e",     icon = nil, category = "Gestes" },
    { name = "Danse endiablée",          animation = "evo_urvs4132ccd5i0",     icon = nil, category = "Gestes" },
    { name = "Danse Bon Odori",          animation = "evo_ygqy0ue1rqfqwa9",    icon = nil, category = "Gestes" },
    { name = "Invocation (arts)",        animation = "evo_yibu7ssxkqc3m",      icon = nil, category = "Gestes" },
    { name = "Pouce en l'air",           animation = "evo_ysa3vv6gexyxupllb",  icon = nil, category = "Gestes" },
    { name = "Petite danse",             animation = "evo_zmsj350ahqrf9h9l9",  icon = nil, category = "Gestes" },
    { name = "Danser",                   animation = "evo_zog400rika6m89j",    icon = nil, category = "Gestes" },
    { name = "Kabedon (mignon)",         animation = "evo_zs643zxx7fd6",       icon = nil, category = "Gestes" },

    -- Debout
    { name = "Attente (serviteur)",      animation = "evo_9s1gjvp305q9lsdpm",  icon = nil, category = "Debout" },
    { name = "Pose du roi",              animation = "evo_awemoxabxo4ldc6",    icon = nil, category = "Debout" },
    { name = "Pose mannequin",           animation = "evo_my0dopjdzh3ayhec7",  icon = nil, category = "Debout" },
    { name = "Nonchalant",               animation = "evo_tphsrs068lo7fl",     icon = nil, category = "Debout" },

    -- Assis
    { name = "Seiza (M)",                animation = "evo_t8uydxtetv43t",      icon = nil, category = "Assis" },
}
