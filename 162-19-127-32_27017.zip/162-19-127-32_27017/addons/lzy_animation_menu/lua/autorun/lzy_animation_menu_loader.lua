-- "addons\\lzy_animation_menu\\lua\\autorun\\lzy_animation_menu_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_animation_menu/config.lua")
    AddCSLuaFile("lzy_animation_menu/cl_main.lua")
    include("lzy_animation_menu/config.lua")
    include("lzy_animation_menu/sv_main.lua")
else
    include("lzy_animation_menu/config.lua")
    include("lzy_animation_menu/cl_main.lua")
end