-- "addons\\evo_animateur\\lua\\entities\\evo_build_particule.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- PARTICULE DE BUILD (30/09/2026) : un effet d'ambiance pose par un animateur en
-- mode build (catalogue, onglet Particules, liste EVO_BUILD.PARTICULES). L'entite
-- porte une petite physique pour que le physgun la deplace et que le remover
-- l'enleve ; elle est comptee comme un prop de build (plafond, proprietaire,
-- « Retirer mes props »). L'effet est joue par le client, attache a l'entite,
-- donc il la suit quand on la deplace.
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Particule de build"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "Effet")
end

if SERVER then
	function ENT:Initialize()
		-- Un modele minuscule jamais dessine, mais avec une physique : c'est lui que
		-- le physgun attrape et que le remover vise.
		self:SetModel("models/props_junk/PopCan01a.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		-- Les joueurs passent au travers ; la physique reste la pour le physgun.
		self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
		self:DrawShadow(false)
		local ph = self:GetPhysicsObject()
		if IsValid(ph) then ph:EnableMotion(false) ph:Wake() end
	end

	function ENT:UpdateTransmitState()
		return TRANSMIT_PVS
	end

	return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local REPERE = Material("sprites/light_glow02_add")
local COULEUR_REPERE = Color(207, 68, 78, 220)

function ENT:Think()
	local effet = self:GetEffet()
	if effet == "" then return end
	if effet ~= self._effet or not (self._ps and self._ps:IsValid()) then
		if self._ps and self._ps:IsValid() then self._ps:StopEmissionAndDestroyImmediately() end
		self._ps = CreateParticleSystem(self, effet, PATTACH_ABSORIGIN_FOLLOW)
		self._effet = effet
	elseif self._ps:IsFinished() then
		-- Un effet qui n'est pas en boucle repart quand il se termine.
		self._ps:Restart()
	end
	self:SetNextClientThink(CurTime() + 0.5)
	return true
end

-- Le repere n'apparait qu'aux animateurs en mode build, les joueurs ne voient que
-- l'effet. Sans repere, impossible de viser la particule au physgun ou au remover.
function ENT:Draw()
	if not (EVO_BUILD and EVO_BUILD.MoiActif) then return end
	render.SetMaterial(REPERE)
	render.DrawSprite(self:GetPos(), 18, 18, COULEUR_REPERE)
end

function ENT:OnRemove()
	if self._ps and self._ps:IsValid() then self._ps:StopEmissionAndDestroyImmediately() end
end
