-- "addons\\evo_animateur\\lua\\autorun\\sh_anim_tiers.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- PALIERS ANIMATEUR — source unique PARTAGÉE (client + serveur).
-- 3 groupes SAM (créés par evo_staff/sv_staff_ranks.lua) ; superadmin = palier
-- max (test/secours). mj / mj_plus = palier 2 (même que animateur).
-- EVO_ANIM.Caps = plafonds par palier (grille user 08/02) :
-- self-set (grade/niveau/art/style), tenues boutique, Garganta, arts hollow.
-- ============================================================================

EVO_ANIM = EVO_ANIM or {}

-- Groupe SAM -> palier. 1 = Animateur Testé, 2 = Animateur, 3 = Gérant Animateur,
-- 4 = Gérant RP (09/07, au-dessus du gérant animateur).
EVO_ANIM.GROUP_TIERS = {
	animateur_test   = 1,
	animateur        = 2,
	mj               = 2,
	mj_plus          = 2,
	animateur_gerant = 3, ["Gérant Animateur"] = 3, ["gérant animateur"] = 3,
	gerant_rp = 4, ["Gérant RP"] = 4, ["gérant rp"] = 4,
	-- Responsable modérateur (09/27, user) : persos d'animation + panel au palier Animateur,
	-- pour épauler les animateurs sans perso RP. Mêmes 2 orthographes que RESPO_MODO.
	responsable_moderateur = 2, ["Responsable Modérateur"] = 2, ["responsable modérateur"] = 2,
	-- variantes historiques tolérées ailleurs dans le code (bindmenu)
	["Animateur"] = 2, animator = 2, MJ = 2,
}

-- Palier d'un NOM de rang (09/28, fix « le respo modo n'a toujours pas de perso animateur ») :
-- la table était lue AU CARACTÈRE PRÈS, alors que les droits du respo (EVO_IsRespoModo)
-- comparent en MINUSCULES -> un rang « Responsable modérateur » avait ses droits de modo
-- mais aucun palier d'animation. Exact, puis minuscules, puis la liste du respo (palier 2).
function EVO_ANIM.TierOfGroup(sGroup)
	local s = tostring(sGroup or "")
	local t = EVO_ANIM.GROUP_TIERS
	local n = t[s] or t[string.lower(s)]
	if n then return n end
	if EVO_IsRespoModoGroup and EVO_IsRespoModoGroup(s) then return 2 end
	return nil
end

function EVO_ANIM.IsAnimGroupName(sGroup)
	return EVO_ANIM.TierOfGroup(sGroup) ~= nil
end

-- Palier EFFECTIF pour les OUTILS : exige d'être SUR le perso animateur
-- (EVO_AnimChar, posé serveur par lzy_character, non spoofable) — un compte
-- animateur sur un perso RP normal n'a aucun pouvoir. Superadmin : toujours 3.
function EVO_ANIM.Tier(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return 0 end
	if ply:IsSuperAdmin() then return 3 end
	if not ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return EVO_ANIM.TierOfGroup(ply:GetUserGroup()) or 0
end

-- Plafonds par palier. Raretés : arts/styles en FR (table lzy_reroll),
-- items boutique en EN (table inventory).
-- Échelle du perso : plancher commun, plafond PAR PALIER (le Gérant monte à ×2, demande user
-- 08/04). Une seule source pour l'UI (menu animateur + outils) et pour le clamp serveur.
EVO_ANIM.SCALE_MIN = 0.8
EVO_ANIM.SCALE_MAX_DEFAULT = 1.4

-- PV que l'animateur peut se donner (outil « Points de vie » ET incarnation larve/Vasto/
-- personnage : MÊME plafond des deux côtés, sinon le plafond du palier se contournerait en
-- passant par une transformation). 10000 = borne historique de la possession NPC.
EVO_ANIM.HP_MIN = 1
EVO_ANIM.HP_MAX_DEFAULT = 10000

-- Objets du catalogue INTERDITS au self-give animateur, quel que soit le palier. Clé = id
-- d'item (ITEMS). Vérifié SERVEUR (sv_anim_tools isGivableItem) ET CLIENT (miroir
-- lzy_animation_menu atBuildList) : une seule liste pour les deux côtés.
--   • katana_aizen : exclusivité du PACK BETA T3 (cf. ncm_ranger_katana/sh_katana_skins).
--     Son skin force la rareté "epic" (le générateur d'items ne retombe donc jamais sur
--     le "mythic" prévu dans katanaRarities), ce qui l'ouvrait au palier Gérant.
--     Retiré du panel (demande user 09/12).
EVO_ANIM.ITEMS_EXCLUS = {
	katana_aizen = true,
}

-- Un item est-il INTERDIT au self-give animateur ? Verdict unique pour le filtre
-- serveur (sv_anim_tools isGivableItem) et son miroir client (lzy_animation_menu
-- atBuildList). Deux cas :
--   • exclusion nominative (ITEMS_EXCLUS ci-dessus) ;
--   • ARME DE SHIKAI (user 09/12) : lame / poings `is_shikai` de KATANA_SKINS /
--     NCM_HAKUDA_GAUNTLETS. Une apparence de shikai est ATTRIBUÉE au personnage
--     (rituel de la Salle Blanche, reroll au PNJ — evo_blanc/sh_rituel, même marqueur),
--     jamais donnée : l'item n'existe que comme outil superadmin (getitem, cf.
--     inventory/config.lua GenerateKatanaItems). Le flag n'est PAS recopié sur ITEMS,
--     on remonte donc à la définition du skin. Les jumeaux « <id>_shikai » (variante
--     de texture d'un skin de boutique) n'ont pas le marqueur : ils restent donnables.
function EVO_ANIM.EstItemExclu(id, it)
	if EVO_ANIM.ITEMS_EXCLUS[id] then return true end
	if not istable(it) then return false end
	if isstring(it.skin_id) and it.skin_id ~= "" then
		local def = KATANA_SKINS and KATANA_SKINS.List and KATANA_SKINS.List[it.skin_id]
		if def and def.is_shikai then return true end
	end
	if isstring(it.gauntlet_id) and it.gauntlet_id ~= "" then
		local def = NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List and NCM_HAKUDA_GAUNTLETS.List[it.gauntlet_id]
		if def and def.is_shikai then return true end
	end
	return false
end

EVO_ANIM.Caps = {
	[1] = { -- Animateur Testé
		grade = 7,  level = 30,
		art   = { commun = true, rare = true },
		style = { commun = true, rare = true },
		items = 0,  itemRarity = {},
		garganta = 0,
		hollowArts = false,
		mobility = false,
		scaleMax = 1.4,
		hpMax = 3000,
		parchemins = false,
		division = false,
		persos = 6, -- +4 (09/11, user) : deux Hollow et deux Shinigami de plus
	},
	[2] = { -- Animateur
		-- 12 (04/08) : de quoi incarner un gradé crédible sans toucher au commandement.
		grade = 12, level = 100,
		art   = { commun = true, rare = true, epique = true },
		style = { commun = true, rare = true },
		items = 15, itemRarity = { common = true, rare = true },
		-- TENUES : jusqu'a l'EPIQUE (demande user 09/10) pour habiller un personnage
		-- d'animation, SANS ouvrir les katanas ni les accessoires epiques (la regle
		-- itemRarity ci-dessus reste celle de tout le reste). Voir EVO_ANIM.RarityFor.
		outfitRarity = { common = true, rare = true, epic = true },
		garganta = 5,
		hollowArts = true, -- Ars Hollow 1-3 + vol
		mobility = true,   -- bouton Vol + Vol de Combat
		scaleMax = 1.4,
		hpMax = 6000,
		parchemins = true,
		division = true,
		persos = 6, -- +4 (09/11, user) : deux Hollow et deux Shinigami de plus
	},
	[3] = { -- Gérant Animateur
		-- 16 = Sotaicho / Roi du Hueco Mundo : le sommet de la faction, pour incarner le
		-- personnage d'une trame serveur (demande user 08/04).
		grade = 16, level = 250,
		art   = { commun = true, rare = true, epique = true },
		style = { commun = true, rare = true, epique = true },
		-- Aura (couleur de reiatsu) : réservée au Gérant. Même forme que art/style, la table
		-- absente ailleurs suffit à refuser le choix côté serveur ET à masquer la liste.
		aura  = { commun = true, rare = true, epique = true },
		-- LÉGENDAIRE ouvert au sommet (demande user 08/20) : le responsable de l'animation
		-- doit pouvoir s'équiper comme le personnage d'une trame serveur. Mythique et secret
		-- restent fermés à TOUT LE MONDE (ils ne s'obtiennent qu'au tirage).
		items = 30, itemRarity = { common = true, rare = true, epic = true, legendary = true },
		garganta = 15,
		hollowArts = true,
		mobility = true,
		scaleMax = 2,
		hpMax = 10000,
		parchemins = true,
		division = true,
		persos = 7, -- +4 (09/11, user) : deux Hollow et deux Shinigami de plus
	},
	[4] = { -- Gérant RP (user 09/07) : tout le palier Gérant Animateur, avec un quota
		-- d'objets boutique plus large (« un peu plus d'accessoires » : le quota est
		-- commun aux tenues, accessoires et katanas). Raretés inchangées : mythique et
		-- secret restent fermés à tout le monde.
		grade = 16, level = 250,
		art   = { commun = true, rare = true, epique = true },
		style = { commun = true, rare = true, epique = true },
		aura  = { commun = true, rare = true, epique = true },
		items = 45, itemRarity = { common = true, rare = true, epic = true, legendary = true },
		garganta = 15,
		hollowArts = true,
		mobility = true,
		scaleMax = 2,
		hpMax = 10000,
		parchemins = true,
		division = true,
		persos = 7, -- +4 (09/11, user) : deux Hollow et deux Shinigami de plus
	},
}

-- Raretes d'objets boutique ouvertes au palier POUR UN OBJET donne. Les TENUES peuvent
-- avoir leur propre plafond (cap.outfitRarity) : l'Animateur porte des tenues epiques
-- sans se donner des katanas ou des accessoires epiques. Sans outfitRarity, c'est
-- itemRarity pour tout. SOURCE UNIQUE : le serveur (sv_anim_tools, revalidation du don)
-- et le catalogue client (lzy_animation_menu) l'appellent tous les deux, un seul endroit
-- a changer quand la grille bouge.
function EVO_ANIM.RarityFor(cap, it)
	if not istable(cap) then return {} end
	if istable(it) and it.category == "outfit" and istable(cap.outfitRarity) then
		return cap.outfitRarity
	end
	return cap.itemRarity or {}
end

-- ── PERSOS D'ANIMATION ──────────────────────────────────────────────────────
-- Les slots 1 à 3 sont les persos RP de tout le monde ; au-delà, ce sont les persos
-- d'ANIMATION, à faction imposée. On en ouvre autant que le palier l'autorise, dans
-- CET ordre — un slot ne bouge donc jamais de place quand la grille change.
-- +4 le 09/11 (user, en deux temps) : 7 H, 8 S, puis 9 H, 10 S ; avec `persos` +4 par
-- palier, chaque animateur gagne deux Hollow et deux Shinigami de plus.
EVO_ANIM.SLOTS_ANIM   = { 4, 5, 6, 7, 8, 9, 10 }
EVO_ANIM.SLOT_FACTION = { [4] = "Shinigami", [5] = "Hollow", [6] = "Shinigami", [7] = "Hollow", [8] = "Shinigami", [9] = "Hollow", [10] = "Shinigami" }

-- Palier du COMPTE : le groupe SAM seul, SANS exiger d'être sur un perso animation.
-- C'est la différence avec EVO_ANIM.Tier, et elle est indispensable ici : le menu de
-- sélection de personnage s'affiche AVANT qu'un perso soit chargé, donc EVO_AnimChar
-- n'est pas encore posé et Tier() renverrait 0 — aucun slot d'animation ne s'afficherait.
--
-- ⚠ Volontairement LOCAL et collé à son unique appelant. Une fonction publique
-- équivalente a déjà été supprimée une fois comme « code mort » alors que NbPersos
-- l'appelait : le menu de sélection plantait à chaque joueur qui se connectait, et
-- git ne voit pas ce genre de conflit puisque les deux côtés touchent des lignes
-- différentes. Sous cette forme, la supprimer casse la compilation tout de suite.
local function tierDuCompte(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return 0 end
	if ply:IsSuperAdmin() then return 3 end
	return EVO_ANIM.TierOfGroup(ply:GetUserGroup()) or 0
end

-- Combien de persos d'animation ce COMPTE peut avoir.
function EVO_ANIM.NbPersos(ply)
	local cap = EVO_ANIM.Caps[tierDuCompte(ply)]
	return (cap and tonumber(cap.persos)) or 0
end

-- Les slots réellement ouverts à ce compte, dans l'ordre.
function EVO_ANIM.SlotsPersos(ply)
	local out = {}
	local n = math.min(EVO_ANIM.NbPersos(ply), #EVO_ANIM.SLOTS_ANIM)
	for i = 1, n do out[#out + 1] = EVO_ANIM.SLOTS_ANIM[i] end
	return out
end

-- Ce compte a-t-il droit à CE slot d'animation ? Revalidé SERVEUR à la création :
-- le client ne doit pas pouvoir s'offrir le slot du Gérant en forgeant un net.
function EVO_ANIM.PeutSlot(ply, slot)
	slot = tonumber(slot)
	for _, s in ipairs(EVO_ANIM.SlotsPersos(ply)) do
		if s == slot then return true end
	end
	return false
end

-- Plafonds du joueur (nil si pas animateur effectif).
function EVO_ANIM.Cap(ply)
	return EVO_ANIM.Caps[EVO_ANIM.Tier(ply)]
end

-- Palier INDÉTERMINÉ -> on retombe sur le palier LE PLUS BAS, jamais sur le plafond
-- maximal. Le cas existe pour de vrai : un compte dont le groupe SAM n'est pas un groupe
-- animateur mais qui joue un perso de slot animation passe les gates `isAnimChar`
-- (EVO_AnimChar) alors que Tier() renvoie 0. Rendre le plafond MAXIMAL dans ce trou
-- revenait à ouvrir en grand ce que la grille est censée fermer.
local function capOuPlancher(ply)
	return EVO_ANIM.Cap(ply) or EVO_ANIM.Caps[1]
end

-- Échelle max autorisée pour ce joueur.
function EVO_ANIM.ScaleMax(ply)
	local cap = capOuPlancher(ply)
	return (cap and tonumber(cap.scaleMax)) or EVO_ANIM.SCALE_MAX_DEFAULT
end

-- PV max que ce joueur peut se donner (outil PV, incarnation ET possession de PNJ).
function EVO_ANIM.HpMax(ply)
	local cap = capOuPlancher(ply)
	return (cap and tonumber(cap.hpMax)) or EVO_ANIM.HP_MAX_DEFAULT
end
