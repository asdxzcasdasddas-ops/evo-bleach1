-- "addons\\evo_animateur\\lua\\autorun\\sh_anim_build_taille.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- MODE BUILD : REDIMENSIONNER SES PROPS (30/09/2026, demande des animateurs relayee
-- par axxou, fait maison plutot qu'un addon « scaler » du workshop).
--   Outil « Taille » (weapons/gmod_tool/stools/evo_taille.lua), dans la liste blanche
--   du mode build : clic gauche applique la taille reglee (x0.1 a x5), clic droit
--   remet la taille d'origine, R reprend la taille du prop vise.
--   Visuel : SetModelScale, networke par le moteur. Physique : le maillage convexe du
--   modele, chaque point multiplie, puis PhysicsInitMultiConvex + collisions sur mesure.
--   Mesure du 30/09 (listen server local) : le SetModelScale + Activate du moteur
--   agrandit bien la physique du SERVEUR, mais le client garde la forme d'origine : un
--   joueur debout sur le prop agrandi n'a pas de sol cote client, erreur de prediction
--   a chaque tick, il tremble. Le client refait donc la MEME physique, d'apres la liste
--   des props redimensionnes que le serveur lui envoie (message et pas variable reseau,
--   comme le reste du mode build). Avec elle : aucune erreur de prediction mesuree.
--   Refuse : prop soude, encorde ou en no-collide (refaire sa physique casserait ses
--   contraintes), plus de TAILLE_MAX unites de cote, moins de TAILLE_MIN d'epaisseur.
-- ============================================================================
EVO_BUILD = EVO_BUILD or {}
EVO_BUILD.ECHELLE_MIN = 0.1
EVO_BUILD.ECHELLE_MAX = 5
EVO_BUILD.TAILLE_MAX  = 4000  -- plus grand cote une fois redimensionne, en unites
EVO_BUILD.TAILLE_MIN  = 0.5   -- plus petit cote : en dessous, l'enveloppe convexe degenere

-- Maillage physique d'origine d'un modele : les points de chaque convexe (GetMeshConvexes
-- rend des triangles, PhysicsInitMultiConvex refait les enveloppes) et leur boite.
-- A lire sur une physique creee par PhysicsInit, qui ignore l'echelle du modele (mesure
-- des deux cotes) : c'est toujours la forme d'origine. Garde par modele.
local maillages = {}
local function maillageDe(ent, phys)
	local modele = ent:GetModel() or ""
	if maillages[modele] then return maillages[modele] end
	local brut = IsValid(phys) and phys:GetMeshConvexes()
	if not istable(brut) or #brut == 0 then return end
	local convexes = {}
	local mn, mx = Vector(math.huge, math.huge, math.huge), Vector(-math.huge, -math.huge, -math.huge)
	for i, triangles in ipairs(brut) do
		local points = {}
		for j, sommet in ipairs(triangles) do
			local p = sommet.pos
			points[j] = p
			mn.x, mn.y, mn.z = math.min(mn.x, p.x), math.min(mn.y, p.y), math.min(mn.z, p.z)
			mx.x, mx.y, mx.z = math.max(mx.x, p.x), math.max(mx.y, p.y), math.max(mx.z, p.z)
		end
		convexes[i] = points
	end
	maillages[modele] = { convexes = convexes, mins = mn, maxs = mx }
	return maillages[modele]
end

-- Boite de collision d'origine (echelle 1) : modele et physique reunis. SetCollisionBounds
-- prend la boite AVANT echelle, le moteur la multiplie par celle du modele. A reposer des
-- deux cotes apres PhysicsInitMultiConvex, qui la remplace par celle du maillage passe
-- (deja agrandi : elle l'etait deux fois) : mesure le 30/09, cote client la boite n'est
-- plus celle du serveur et les traces ratent les bords d'un prop reduit.
-- Deux appels : le moteur ne refait sa boite de tri des traces que si la valeur CHANGE.
-- Sans ca, cote client, elle restait celle de la physique detruite (mesure du 30/09 :
-- bord d'un prop remis a sa taille rate par une coque de joueur, alors que tout le reste
-- etait identique a un prop neuf).
local function reposerBornes(ent, m)
	local mn, mx = ent:GetModelBounds()
	if m then
		mn = Vector(math.min(mn.x, m.mins.x), math.min(mn.y, m.mins.y), math.min(mn.z, m.mins.z))
		mx = Vector(math.max(mx.x, m.maxs.x), math.max(mx.y, m.maxs.y), math.max(mx.z, m.maxs.z))
	end
	ent:SetCollisionBounds(mn * 0.5, mx * 0.5)
	ent:SetCollisionBounds(mn, mx)
end

-- Retour aux collisions du moteur : un prop remis a sa taille retrouve les drapeaux d'un
-- prop neuf (aucun, mesure du 30/09). On retire les deux drapeaux de test sur mesure au
-- lieu de compter sur EnableCustomCollisions(false) seul.
local SUR_MESURE = bit.bor(FSOLID_CUSTOMRAYTEST, FSOLID_CUSTOMBOXTEST)
local function collisionsMoteur(ent)
	ent:EnableCustomCollisions(false)
	ent:RemoveSolidFlags(SUR_MESURE)
end

local function aLEchelle(m, s)
	local out = {}
	for i, points in ipairs(m.convexes) do
		local c = {}
		for j, p in ipairs(points) do c[j] = p * s end
		out[i] = c
	end
	return out
end

if SERVER then
	util.AddNetworkString("EVO:Anim:BuildTaille") -- serveur -> clients : [index d'entite, echelle] ; client -> serveur : la liste complete

	EVO_BUILD.Tailles = EVO_BUILD.Tailles or {}   -- [ent] = echelle, les props redimensionnes

	local function envoyer(liste, cible)
		net.Start("EVO:Anim:BuildTaille")
			net.WriteUInt(#liste, 12)
			for _, t in ipairs(liste) do
				net.WriteUInt(t[1], 13)  -- index d'entite (8192 au plus)
				net.WriteFloat(t[2])
			end
		if cible then net.Send(cible) else net.Broadcast() end
	end

	-- Redimensionne un prop_physics. Renvoie true, ou false et la raison a afficher.
	function EVO_BUILD.Redimensionner(ent, s)
		if not IsValid(ent) or ent:GetClass() ~= "prop_physics" then return false, "Seuls les props se redimensionnent." end
		s = math.Round(math.Clamp(tonumber(s) or 1, EVO_BUILD.ECHELLE_MIN, EVO_BUILD.ECHELLE_MAX), 2)
		if s == (ent.EVO_Taille or 1) then return true end
		if constraint.HasConstraints(ent) then
			return false, "Ce prop est soudé, encordé ou en no-collide : redimensionne-le avant de l'attacher."
		end
		local phys = ent:GetPhysicsObject()
		if not IsValid(phys) then return false, "Ce prop n'a pas de physique." end
		-- Bornes de taille sur la boite du modele (sans echelle).
		local bmn, bmx = ent:GetModelBounds()
		local d = bmx - bmn
		if math.max(d.x, d.y, d.z) * s > EVO_BUILD.TAILLE_MAX then
			return false, "Trop grand : plus de " .. EVO_BUILD.TAILLE_MAX .. " unités de côté à cette taille."
		end
		if s < 1 and math.min(d.x, d.y, d.z) * s < EVO_BUILD.TAILLE_MIN then
			return false, "Trop petit : ce prop serait trop fin pour garder des collisions."
		end

		ent:ForcePlayerDrop() -- refaire la physique d'un prop tenu au physgun ferait planter le moteur
		local bouge, gravite, matiere = phys:IsMotionEnabled(), phys:IsGravityEnabled(), phys:GetMaterial()
		local basAvant = ent:WorldSpaceAABB().z

		-- Physique du modele, a l'echelle 1 : reference (masse, maillage), gardee telle
		-- quelle pour la taille d'origine ou si l'agrandie est refusee.
		ent:PhysicsInit(SOLID_VPHYSICS)
		phys = ent:GetPhysicsObject()
		if not IsValid(phys) then return false, "Ce prop n'a pas de physique." end
		local masse = phys:GetMass()
		local m = maillageDe(ent, phys)
		local refus
		if s ~= 1 then
			if m and ent:PhysicsInitMultiConvex(aLEchelle(m, s)) and IsValid(ent:GetPhysicsObject()) then
				ent:EnableCustomCollisions(true)
			else
				ent:PhysicsInit(SOLID_VPHYSICS)
				s, refus = 1, "Le moteur physique a refusé cette taille."
			end
		end
		if s == 1 then collisionsMoteur(ent) end
		reposerBornes(ent, m)
		ent:SetModelScale(s, 0)

		phys = ent:GetPhysicsObject()
		phys:SetMaterial(matiere)
		phys:SetMass(math.Clamp(masse * s ^ 3, 1, 50000))
		phys:EnableGravity(gravite)
		phys:EnableMotion(bouge)
		if bouge then
			-- Prop libre : son dessous reste a la meme hauteur. Sinon la moitie agrandie
			-- s'enfonce dans le sol et le moteur le projette en l'air.
			ent:SetPos(ent:GetPos() + Vector(0, 0, basAvant - ent:WorldSpaceAABB().z))
			phys:Wake()
		end

		ent.EVO_Taille = (s ~= 1) and s or nil
		EVO_BUILD.Tailles[ent] = ent.EVO_Taille
		envoyer({ { ent:EntIndex(), s } })
		if refus then return false, refus end
		return true
	end

	-- Un joueur qui arrive demande la liste une fois charge (cf. client).
	net.Receive("EVO:Anim:BuildTaille", function(_, ply)
		if not IsValid(ply) or not ply:RateLimit("build_taille", 2) then return end
		local liste = {}
		for ent, s in pairs(EVO_BUILD.Tailles) do
			if IsValid(ent) then liste[#liste + 1] = { ent:EntIndex(), s } else EVO_BUILD.Tailles[ent] = nil end
		end
		if #liste > 0 then envoyer(liste, ply) end
	end)

	-- Prop retire : les clients oublient son index (il servira a une autre entite).
	hook.Add("EntityRemoved", "EVO:Build:Taille", function(ent)
		if EVO_BUILD.Tailles[ent] then
			EVO_BUILD.Tailles[ent] = nil
			envoyer({ { ent:EntIndex(), 1 } })
		end
	end)
end

if CLIENT then
	local voulues = {} -- [index d'entite] = echelle recue ; 1 = remettre d'origine puis oublier

	local function appliquer(ent, s)
		local avant = ent.EVO_TaillePhys
		ent.EVO_TaillePhys = s
		if s == 1 then
			-- Rien a defaire sur un prop que ce client n'a jamais agrandi : sa boite est
			-- celle du serveur, on n'y touche pas.
			if avant == nil or avant == 1 then return end
			ent:PhysicsDestroy()
			collisionsMoteur(ent)
			reposerBornes(ent, maillages[ent:GetModel() or ""])
			return
		end
		-- PhysicsInit ignore l'echelle du modele : elle rend la forme d'origine a relire.
		ent:PhysicsInit(SOLID_VPHYSICS)
		local m = maillageDe(ent, ent:GetPhysicsObject())
		if not m or not ent:PhysicsInitMultiConvex(aLEchelle(m, s)) then
			-- Echec : collisions du moteur (forme d'origine), sans reessayer en boucle.
			ent:PhysicsDestroy()
			collisionsMoteur(ent)
			reposerBornes(ent, m)
			ent.EVO_TailleEchec = s
			return
		end
		ent:EnableCustomCollisions(true)
		reposerBornes(ent, m)
		-- Physique client figee : elle ne sert qu'aux traces (prediction de mouvement,
		-- visee), qui la lisent a la position de l'entite.
		local phys = ent:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) phys:Sleep() end
	end

	net.Receive("EVO:Anim:BuildTaille", function()
		for _ = 1, net.ReadUInt(12) do
			local idx = net.ReadUInt(13)
			voulues[idx] = net.ReadFloat()
		end
	end)

	-- Applique des que le prop existe chez ce client ET que l'echelle du serveur est
	-- arrivee (le message et l'entite ne voyagent pas ensemble). Refait aussi une
	-- physique perdue (entite recreee par une mise a jour complete).
	timer.Create("EVO:Build:TailleClient", 0.2, 0, function()
		for idx, s in pairs(voulues) do
			local ent = Entity(idx)
			if IsValid(ent) and ent:GetClass() == "prop_physics" then
				local aFaire = ent.EVO_TaillePhys ~= s or (s ~= 1 and not IsValid(ent:GetPhysicsObject()))
				if aFaire and ent.EVO_TailleEchec ~= s and math.abs(ent:GetModelScale() - s) < 0.001 then
					appliquer(ent, s)
				end
				if s == 1 and ent.EVO_TaillePhys == 1 then voulues[idx] = nil end
			elseif s == 1 then
				voulues[idx] = nil
			end
		end
	end)

	-- Joueur qui arrive : la liste des props deja redimensionnes, une fois son Lua pret.
	hook.Add("InitPostEntity", "EVO:Build:Taille", function()
		net.Start("EVO:Anim:BuildTaille")
		net.SendToServer()
	end)
end
