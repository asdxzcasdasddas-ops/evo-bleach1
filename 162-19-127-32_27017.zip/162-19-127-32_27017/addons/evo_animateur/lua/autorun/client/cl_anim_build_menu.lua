-- "addons\\evo_animateur\\lua\\autorun\\client\\cl_anim_build_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- CATALOGUE DU MODE BUILD (30/09/2026, demande d'axxou).
--   En mode build, la touche Q d'un animateur ouvre CE menu a la place du menu
--   sandbox : il n'y voit qu'une SELECTION de modeles (EVO_BUILD.CATALOGUE : les
--   modeles des maps, pieces de decor comprises depuis le 30/09, verifie aussi cote
--   serveur) et le plastique de GMod (EVO_BUILD.CATALOGUE_AJOUTS), jamais le reste
--   des modeles de base de GMod (vehicules, HL2...).
--   Onglet Particules : quelques effets d'ambiance (EVO_BUILD.PARTICULES).
--   Onglet Outils : les outils de la liste blanche avec leurs reglages, le meme
--   panneau de controle que dans le menu Q (BuildCPanel de chaque outil).
--   Poser un modele passe par gm_spawn, donc par les memes hooks que le menu Q :
--   plafond, catalogue et proprietaire sont juges par le serveur.
-- ============================================================================
if SERVER then return end

EVO_BUILD = EVO_BUILD or {}

local UI_SCALE = 1
local function R(v) return math.Round(v * UI_SCALE * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function C() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18),
	title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118),
	accent = Color(207,68,78), green = Color(78,196,128) } end

local frame, fond
local ICONE = 96
local etat = { cat = 1, outil = nil, recherche = "" }

local function fermer()
	if IsValid(frame) then frame:Remove() end
	if IsValid(fond) then fond:Remove() end
end
EVO_BUILD.FermerMenu = fermer

-- Nom lisible d'un modele : le fichier sans dossier ni extension.
local function nomCourt(m) return (string.GetFileFromFilename(m):gsub("%.mdl$", "")) end

-- Les outils de la liste blanche reellement installes sur le serveur.
local function outilsDispo()
	local sw = weapons.GetStored("gmod_tool")
	local out = {}
	if sw and istable(sw.Tool) then
		for mode, t in pairs(sw.Tool) do
			if EVO_BUILD.OUTILS and EVO_BUILD.OUTILS[mode] then
				out[#out + 1] = { mode = mode, nom = language.GetPhrase(t.Name or mode), tool = t }
			end
		end
	end
	table.sort(out, function(a, b) return a.nom < b.nom end)
	return out
end

local function txtEntree(parent)
	local t = vgui.Create("DTextEntry", parent)
	t:SetFont("EVO_UI_Sub")
	t:SetPlaceholderText("Chercher un modèle…")
	t:SetPaintBackground(false)
	t:SetTextColor(C().title)
	t:SetCursorColor(C().accent)
	t:SetPlaceholderColor(C().dim)
	t.Paint = function(s, w, h)
		surface.SetDrawColor(255, 255, 255, 8) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ColorAlpha(s:HasFocus() and C().accent or C().border, 120)) surface.DrawOutlinedRect(0, 0, w, h)
		s:DrawTextEntryText(C().title, C().accent, C().title)
	end
	return t
end

-- Zone de droite : la grille des modeles d'une categorie, filtree par la recherche.
local function remplirModeles(zone, cat)
	zone:Clear()
	local col = C()
	local rech = txtEntree(zone)
	rech:Dock(TOP) rech:SetTall(R(32)) rech:DockMargin(0, 0, 0, R(8))
	rech:SetValue(etat.recherche)
	local scroll = vgui.Create("DScrollPanel", zone)
	scroll:Dock(FILL)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	local grille = vgui.Create("DIconLayout", scroll)
	grille:Dock(TOP)
	grille:SetSpaceX(R(6)) grille:SetSpaceY(R(6))
	local compteur = vgui.Create("DLabel", zone)
	compteur:Dock(BOTTOM) compteur:SetTall(R(18)) compteur:SetFont("EVO_UI_Mono") compteur:SetTextColor(col.dim)

	local function construire()
		grille:Clear()
		local q = string.lower(etat.recherche or "")
		local n = 0
		for _, m in ipairs(cat.modeles) do
			local nom = nomCourt(m)
			if q == "" or string.find(string.lower(nom), q, 1, true) then
				n = n + 1
				local ic = grille:Add("SpawnIcon")
				ic:SetSize(R(ICONE), R(ICONE))
				ic:SetModel(m)
				ic:SetTooltip(nom)
				-- Meme chemin que le menu Q : le serveur applique plafond et catalogue.
				ic.DoClick = function()
					surface.PlaySound(EVO_UI and EVO_UI.SndClick or "ui/buttonclick.wav")
					RunConsoleCommand("gm_spawn", m)
				end
				-- Pas de menu contextuel sandbox sur l'icone (copier, retirer du spawnlist...).
				ic.OpenMenu = function() end
			end
		end
		compteur:SetText(n .. " modèle" .. (n > 1 and "s" or "") .. (q ~= "" and " (filtre : " .. etat.recherche .. ")" or ""))
	end
	-- Filtre au clavier, avec un petit delai : reconstruire 480 icones a chaque lettre
	-- ferait saccader la frappe.
	rech.OnValueChange = function(_, v)
		etat.recherche = v or ""
		timer.Create("EVO:Build:Recherche", 0.25, 1, function() if IsValid(grille) then construire() end end)
	end
	construire()
end

-- Zone de droite : les particules d'ambiance. Un clic en pose une la ou on vise
-- (le serveur juge : mode build, liste, plafond).
local function remplirParticules(zone)
	zone:Clear()
	local col = C()
	local grille = vgui.Create("DIconLayout", zone)
	grille:Dock(TOP) grille:SetSpaceX(R(6)) grille:SetSpaceY(R(6))
	for _, p in ipairs(EVO_BUILD.PARTICULES or {}) do
		local b = grille:Add("DButton")
		b:SetText("")
		surface.SetFont("EVO_UI_Item")
		b:SetSize(select(1, surface.GetTextSize(p.nom)) + R(26), R(32))
		b.Paint = function(s, w, h)
			local f = s:IsHovered() and col.accent or ColorAlpha(color_white, 10)
			if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, w, h, f, R(8), "br") else surface.SetDrawColor(f) surface.DrawRect(0, 0, w, h) end
			draw.SimpleText(p.nom, "EVO_UI_Item", w / 2, h / 2, s:IsHovered() and color_white or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound(EVO_UI and EVO_UI.SndClick or "ui/buttonclick.wav")
			net.Start("EVO:Anim:Build") net.WriteUInt(4, 3) net.WriteString(p.effet) net.SendToServer()
		end
	end
end

-- Zone de droite : les outils autorises, puis les reglages de celui qu'on prend.
local function remplirOutils(zone)
	zone:Clear()
	local col = C()
	local barre = vgui.Create("DIconLayout", zone)
	barre:Dock(TOP) barre:SetSpaceX(R(6)) barre:SetSpaceY(R(6)) barre:DockMargin(0, 0, 0, R(10))
	local reglages = vgui.Create("DScrollPanel", zone)
	reglages:Dock(FILL)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(reglages) end
	local outils = outilsDispo()
	local courant = GetConVar("gmod_toolmode") and GetConVar("gmod_toolmode"):GetString() or ""

	local function prendre(o)
		etat.outil = o.mode
		-- Ce que fait le menu Q quand on clique un outil : le mode, puis l'arme.
		RunConsoleCommand("gmod_toolmode", o.mode)
		RunConsoleCommand("use", "gmod_tool")
		reglages:Clear()
		local cp = vgui.Create("ControlPanel", reglages)
		cp:Dock(TOP)
		cp:SetName(o.nom)
		if isfunction(o.tool.BuildCPanel) then
			local ok, err = pcall(o.tool.BuildCPanel, cp)
			if not ok then ErrorNoHalt("[EVO build] reglages de l'outil " .. o.mode .. " : " .. tostring(err) .. "\n") end
		end
		for _, b in ipairs(barre:GetChildren()) do b._on = (b._mode == o.mode) end
	end

	for _, o in ipairs(outils) do
		local b = barre:Add("DButton")
		b:SetText("")
		surface.SetFont("EVO_UI_Item")
		b:SetSize(select(1, surface.GetTextSize(o.nom)) + R(26), R(32))
		b._mode = o.mode
		b._on = (o.mode == courant)
		b.Paint = function(s, w, h)
			local f = s._on and col.accent or (s:IsHovered() and ColorAlpha(col.accent, 120) or ColorAlpha(color_white, 10))
			if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, w, h, f, R(8), "br") else surface.SetDrawColor(f) surface.DrawRect(0, 0, w, h) end
			draw.SimpleText(o.nom, "EVO_UI_Item", w / 2, h / 2, s._on and color_white or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound(EVO_UI and EVO_UI.SndClick or "ui/buttonclick.wav")
			prendre(o)
		end
		if o.mode == (etat.outil or courant) then timer.Simple(0, function() if IsValid(b) then prendre(o) end end) end
	end
	if #outils == 0 then
		local l = vgui.Create("DLabel", zone) l:Dock(TOP) l:SetFont("EVO_UI_Sub") l:SetTextColor(col.muted)
		l:SetText("Aucun outil de la liste blanche n'est installé sur ce serveur.")
	end
end

local function ouvrir()
	fermer()
	if not EVO_BUILD.CATALOGUE then return end
	-- Catalogue genere + ajouts, filtres pour cette map (sh_anim_build.lua).
	local cats = EVO_BUILD.Categories()
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	local col = C()
	local cardW, cardH = R(1120), R(740)

	-- Fond flou + fermeture standard (Echap, clic a cote).
	fond = EVO_UI and EVO_UI.Backdrop and EVO_UI.Backdrop(fermer) or nil
	frame = vgui.Create("DPanel", fond)
	if not IsValid(fond) then frame:MakePopup() end
	frame:SetSize(cardW, cardH)
	frame:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	frame:SetMouseInputEnabled(true)
	frame.OnMousePressed = function() end
	frame.Paint = function(s, w, h)
		if EVO_UI and EVO_UI.PaintCard then EVO_UI.PaintCard(w, h, 1, R(16)) else surface.SetDrawColor(col.bg) surface.DrawRect(0, 0, w, h) end
		if EVO_UI and EVO_UI.Header then
			EVO_UI.Header(w, "CATALOGUE BUILD", (EVO_BUILD.Nombre or 0) .. " / " .. (EVO_BUILD.MAX_PROPS or 0) .. " PROPS", 1, R(26))
			EVO_UI.FooterHints(w, h, "Sélection EVO : posé là où tu vises", { { key = "CLIC", label = "POSER" }, { key = "Q", label = "FERMER" } }, 1, R(26))
		else
			draw.SimpleText("CATALOGUE BUILD", "DermaLarge", R(26), R(30), col.title)
		end
	end
	-- Croix DA (glyphe seul, gris -> accent), placee avec la meme echelle que la carte.
	local croix = vgui.Create("DButton", frame)
	croix:SetText("") croix:SetSize(R(34), R(34)) croix:SetPos(cardW - R(48), R(16))
	croix.Paint = function(s, w, h)
		draw.SimpleText("✕", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	croix.DoClick = fermer

	-- Re-appui sur la touche du menu Q : ferme. Le bind lui-meme ne passe plus quand
	-- un panneau a le clavier, d'ou le sondage (meme technique que le panneau animateur).
	local touche = input.GetKeyCode(input.LookupBinding("+menu") or "q") or KEY_Q
	local ouvertA = SysTime()
	frame._down = true
	frame.Think = function(s)
		local down = input.IsButtonDown(touche)
		if down and not s._down and SysTime() - ouvertA > 0.3 then fermer() return end
		s._down = down
	end

	-- Colonne de gauche : les categories, puis Outils.
	local haut, bas, gauche = R(70), R(46), R(250)
	local liste = vgui.Create("DScrollPanel", frame)
	liste:SetPos(R(16), haut) liste:SetSize(gauche, cardH - haut - bas)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(liste) end
	local zone = vgui.Create("DPanel", frame)
	zone:SetPos(R(16) + gauche + R(14), haut) zone:SetSize(cardW - gauche - R(46), cardH - haut - bas)
	zone:SetPaintBackground(false)

	-- Colonne : les categories du catalogue, puis Particules, puis Outils.
	local boutons = {}
	local nCat = #cats
	local function choisir(i)
		etat.cat = i
		for j, b in ipairs(boutons) do b:SetSel(j == i) end
		if i == nCat + 2 then remplirOutils(zone)
		elseif i == nCat + 1 then remplirParticules(zone)
		else remplirModeles(zone, cats[i]) end
	end
	local entrees = {}
	for i, cat in ipairs(cats) do
		entrees[i] = { num = string.format("%02d", i), label = cat.nom, kanji = tostring(#cat.modeles) }
	end
	entrees[nCat + 1] = { num = string.format("%02d", nCat + 1), label = "Particules", kanji = tostring(#(EVO_BUILD.PARTICULES or {})) }
	entrees[nCat + 2] = { num = string.format("%02d", nCat + 2), label = "Outils", kanji = "工" }
	local y = 0
	for i, data in ipairs(entrees) do
		local b
		if EVO_UI and EVO_UI.RowButton then
			b = EVO_UI.RowButton(liste, 0, y, gauche - R(8), R(44), data, function() choisir(i) end)
		else
			b = vgui.Create("DButton", liste) b:SetPos(0, y) b:SetSize(gauche - R(8), R(44)) b:SetText(data.label)
			b.SetSel = function() end b.DoClick = function() choisir(i) end
		end
		boutons[i] = b
		y = y + R(44)
	end
	choisir(math.Clamp(etat.cat, 1, #boutons))
end

function EVO_BUILD.OuvrirMenu() ouvrir() end
function EVO_BUILD.BasculerMenu()
	if IsValid(frame) then fermer() else ouvrir() end
end
