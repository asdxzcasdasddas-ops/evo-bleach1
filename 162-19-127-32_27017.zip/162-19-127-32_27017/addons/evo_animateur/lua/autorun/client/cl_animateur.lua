-- "addons\\evo_animateur\\lua\\autorun\\client\\cl_animateur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ANIMATEUR — panneau (client). Ouvre via !animateur / !anim.
-- Mode animateur (toggle) · Coffres · Boss · Taille perso · Modération (Aller à / TP / Renvoyer / spectate ; Message = mj_plus).
-- Coffres & boss apparaissent là où l'animateur regarde (eye-trace serveur).
-- ============================================================================

if not CLIENT then return end

local UI_SCALE = 1.35 -- agrandissement global de l'UI animateur (bumpé 1.2->1.35, demande user « UI plus grande partout » ; reste responsive via le ratio écran)
local function R(v) return math.Round(v * UI_SCALE * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function C() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18),
	title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118),
	accent = Color(207,68,78), green = Color(78,196,128) } end

local RAR = { common = Color(150,154,162), rare = Color(80,150,230), epic = Color(170,100,220), legendary = Color(224,176,60), mythic = Color(207,68,78) }

local function MakeFonts()
	if not gCreateRespFont then return end
	-- DA Atelier : Bebas Neue SANS bold pour titres de section/boutons/chips,
	-- Roboto pour les petits textes (réglages, valeurs).
	-- Tailles bumpées (demande user « fonte plus grosse partout ») : 21->24 / 22->25 / 15->17 / 30->33.
	-- Fontes AGRANDIES (demande user 07/23 « police très lisible + grosse »).
	gCreateRespFont("EVO_Anim_H",     "Bebas Neue", 28, 400)
	gCreateRespFont("EVO_Anim_Btn",   "Bebas Neue", 28, 400)
	gCreateRespFont("EVO_Anim_Small", "Roboto", 20, 500)
	gCreateRespFont("EVO_Anim_Title", "Bebas Neue", 40, 400)
end

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/support) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end
hook.Add("Initialize", "EVO_Anim::Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Anim::Fonts2", MakeFonts)
MakeFonts()

-- bouton coloré (fill custom) avec wrap auto de largeur via le texte
local function chip(parent, label, x, y, fill, fn)
	local col = C()
	surface.SetFont("EVO_Anim_Btn")
	local bw = select(1, surface.GetTextSize(label))
	if bw <= 0 then bw = #label * R(8) end
	bw = bw + R(24)
	local b = vgui.Create("DButton", parent) b:SetText("")
	b:SetPos(R(x), R(y)) b:SetSize(bw, R(30))
	b.Paint = function(s, w, h)
		local hov = s:IsHovered()
		-- `fill` peut être une FONCTION renvoyant une Color (relue chaque frame) : sert à la
		-- surbrillance LIVE (ex. la taille sélectionnée passe en vert dès le clic, sans rebuild).
		local f = fill ; if isfunction(f) then f = f(s) end ; f = f or col.accent
		-- Bouton plein Atelier : coin bas-droit coupé (plus d'arrondi).
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(f, hov and 255 or 215), R(8), "br")
		else
			RNDX.Draw(0, 0, 0, w, h, ColorAlpha(f, hov and 255 or 215))
		end
		draw.SimpleText(label, "EVO_Anim_Btn", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fn
	-- largeur en unités BASE pour le flow (÷ UI_SCALE pour rester cohérent avec R/UI_SCALE)
	return b, math.Round(bw / (UI_SCALE * math.min(ScrW() / 1920, ScrH() / 1080)))
end

local pAnim, state = nil, { chests = {}, bosses = {}, used = 0, max = 5, quotaLbl = nil }
local animClosedAt = 0 -- SysTime de la dernière fermeture (debounce anti-réouverture du bind)

-- ── Ouverture de l'UI via le BIND MENU (lzy_bindmenu, bind "animateur_ui") ───
-- Le mode animateur (noclip/god) n'a PAS de touche dédiée : il se toggle via le
-- bouton dans l'UI. Seule l'OUVERTURE de l'UI est un bind, configurable dans le
-- menu de binds (visible animateur / admin / superadmin).
hook.Add("PlayerButtonDown", "EVO_Anim::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	-- UNIQUEMENT sur un perso animateur (ou superadmin) : le serveur le revérifie de toute façon.
	if not (ply:GetEvoNWBool("EVO_AnimChar", false) or ply:IsSuperAdmin()) then return end
	if vgui.GetKeyboardFocus() then return end          -- on tape dans un champ
	if IsValid(pAnim) then return end                    -- déjà ouverte (fermeture = poll Think / Échap)
	if SysTime() - (animClosedAt or 0) < 0.3 then return end -- anti-réouverture juste après fermeture
	if not ply.GetBindKey then return end
	local k = ply:GetBindKey("animateur_ui")
	if k and k ~= 0 and btn == k then
		RunConsoleCommand("evo_animateur")
	end
end)

-- Liste des NPC possédables, lue depuis NCM_PNJ.Config (partagé client/serveur)
local function npcList()
	local t = {}
	if NCM_PNJ and NCM_PNJ.Config then
		for class, c in pairs(NCM_PNJ.Config) do
			-- Exclus de la liste de possession : tous les BOSS (IsBoss) + rudbornn + hollow_bestial
			-- + toutes les unités SHINIGAMI (soulreapers, PrintName "Shinigami"). Jidanbo reste.
			-- EXCEPTIONS (demande user) : Menos Grande et Hollow Serpent restent possédables
			-- malgré leur flag IsBoss.
			local allow = class == "ncm_pnj_hollow_menos" or class == "ncm_pnj_hollow_serpent"
			local skip = not allow and (c.IsBoss
				or class == "ncm_pnj_rudbornn"
				or class == "ncm_pnj_hollow_bestial"
				or c.PrintName == "Shinigami"
				or string.find(class, "soulreaper", 1, true) ~= nil)
			if not skip then
				-- pré-remplissage borné aux limites : PV ≤ 10000, dégâts ≤ 200
				t[#t + 1] = { class = class, name = c.PrintName or class, hp = math.min(c.Health or 1000, 10000), dmg = math.min(c.AttackDamage or 100, 200) }
			end
		end
		table.sort(t, function(a, b) return a.name < b.name end)
	end
	return t
end

-- Liste de TOUS les NPC spawnables (section BOSS), depuis NCM_PNJ.Config (partagé). AUCUNE
-- exclusion (contrairement à npcList qui filtre pour la possession) -> l'animateur peut faire spawn
-- n'importe quel Hollow/boss. PV/dégâts par défaut bornés aux mêmes limites que la possession.
local function bossList()
	local t = {}
	if NCM_PNJ and NCM_PNJ.Config then
		for class, c in pairs(NCM_PNJ.Config) do
			t[#t + 1] = { class = class, name = c.PrintName or class, hp = math.Clamp(c.Health or 3000, 1, 10000), dmg = math.Clamp(c.AttackDamage or 100, 0, 200) }
		end
		table.sort(t, function(a, b) return a.name < b.name end)
	end
	return t
end

-- Groupe une liste {class,name,hp,dmg} par faction (déduit du nom de classe) pour le dropdown.
local function groupNpcs(list)
	local g = { { key = "Shinigami", items = {} }, { key = "Hollow", items = {} }, { key = "Arrancar", items = {} } }
	for _, n in ipairs(list) do
		local c = n.class or ""
		if string.find(c, "hollow", 1, true) then g[2].items[#g[2].items + 1] = n
		elseif c == "ncm_pnj_rudbornn" then g[3].items[#g[3].items + 1] = n
		else g[1].items[#g[1].items + 1] = n end
	end
	return g
end

-- NPC groupés pour le dropdown : possession (liste filtrée) ET boss (toutes les classes).
local function npcGroups()  return groupNpcs(npcList())  end
local function bossGroups() return groupNpcs(bossList()) end

-- Dropdown custom (remplace le DComboBox moche) : popup scrollable, stylé, groupé par
-- faction, avec PV/dégâts par défaut affichés. Ouvre sous le bouton `dd`.
local function OpenNpcDropdown(dd, groups, onPick, selGetter)
	if not IsValid(pAnim) or not IsValid(dd) then return end
	local col = C()
	local sx, sy = dd:LocalToScreen(0, dd:GetTall() + R(4))
	local pw = dd:GetWide()
	local ph = math.min(R(320), ScrH() - sy - R(20))

	local back = vgui.Create("DButton", pAnim) back:SetText("")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0) back:SetZPos(900)
	back.Paint = function() end

	local pop = vgui.Create("DPanel", pAnim)
	pop:SetSize(pw, ph) pop:SetPos(sx, sy) pop:SetZPos(901)
	pop:SetMouseInputEnabled(true)
	pop.Paint = function(_, w, h)
		RNDX.Draw(R(8), 0, 0, w, h, col.bg)
		RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.accent, 130), 1.5)
	end
	dd._pop = pop

	local function closeAll()
		dd._pop = nil
		if IsValid(pop) then pop:Remove() end
		if IsValid(back) then back:Remove() end
	end
	back.DoClick = closeAll
	pop.OnRemove = function() if IsValid(back) then back:Remove() end end

	local scroll = vgui.Create("DScrollPanel", pop)
	scroll:Dock(FILL) scroll:DockMargin(R(6), R(6), R(6), R(6))
	local sb = scroll:GetVBar()
	if IsValid(sb) then
		sb:SetWide(R(6))
		sb.Paint = function() end
		if IsValid(sb.btnUp) then sb.btnUp.Paint = function() end end
		if IsValid(sb.btnDown) then sb.btnDown.Paint = function() end end
		sb.btnGrip.Paint = function(_, w, h) RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(col.accent, 130)) end
	end

	for _, grp in ipairs(groups) do
		if #grp.items > 0 then
			local hdr = scroll:Add(vgui.Create("DLabel"))
			hdr:SetFont("EVO_Anim_Small") hdr:SetTextColor(col.muted)
			hdr:SetText("  " .. string.upper(grp.key))
			hdr:Dock(TOP) hdr:DockMargin(0, R(6), 0, R(2)) hdr:SetTall(R(18))
			for _, n in ipairs(grp.items) do
				local row = scroll:Add(vgui.Create("DButton"))
				row:SetText("") row:Dock(TOP) row:DockMargin(0, R(2), 0, 0) row:SetTall(R(32))
				row.Paint = function(rs, rw, rh)
					local sel = (selGetter and selGetter() == n.class)
					if rs:IsHovered() or sel then RNDX.Draw(R(5), 0, 0, rw, rh, ColorAlpha(col.accent, sel and 90 or 55)) end
					draw.SimpleText(n.name, "EVO_Anim_Small", R(10), rh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText("PV " .. n.hp .. " · " .. n.dmg .. " dmg", "EVO_Anim_Small", rw - R(10), rh / 2, col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				row.DoClick = function()
					onPick(n)
					closeAll()
				end
			end
		end
	end
end

-- ── Choix art spirituel / style de combat (mode HOLLOW animation) ─────────────
-- Lus depuis REROLL_DROPS (partagé). Restriction commun->épique, SAUF superadmin (tout).
local CHOICE_RAR_ORDER = { commun = 1, rare = 2, epique = 3, legendary = 4, mythique = 5, secret = 6 }
local CHOICE_RAR_COL   = { commun = Color(150,154,162), rare = Color(80,150,230), epique = Color(170,100,220), legendary = Color(224,176,60), mythique = Color(207,68,78), secret = Color(235,235,240) }
-- Raretés proposées pour l'INCARNATION : celles du palier (miroir du serveur, qui
-- revalide dans EVO_AnimHollow.Transform). Avant, la liste était fixe commun/rare/épique
-- et proposait donc à un Animateur Testé des choix que le serveur devait refuser.
local CHOICE_CAP_KEY = { art_spirituel = "art", style_de_combat = "style" }
local function rerollChoices(kind)
	local out, seen = {}, {}
	local isSA = LocalPlayer():IsSuperAdmin()
	local cap = (EVO_ANIM and EVO_ANIM.Cap and EVO_ANIM.Cap(LocalPlayer()))
		or (EVO_ANIM and EVO_ANIM.Caps and EVO_ANIM.Caps[1])
	local CHOICE_ALLOWED = (cap and cap[CHOICE_CAP_KEY[kind] or ""]) or {}
	if REROLL_DROPS then
		for _, fac in pairs(REROLL_DROPS) do
			local list = fac[kind]
			if istable(list) then
				for _, d in ipairs(list) do
					-- Arts EN TEST (superadmin_only du reroll) : jamais proposés hors superadmin.
					if d.win_id and not seen[d.win_id] and (isSA or (CHOICE_ALLOWED[d.rarity] and not d.superadmin_only)) then
						seen[d.win_id] = true
						out[#out + 1] = { id = d.win_id, name = d.name or d.win_id, rarity = d.rarity or "commun" }
					end
				end
			end
		end
	end
	table.sort(out, function(a, b)
		local ra, rb = CHOICE_RAR_ORDER[a.rarity] or 9, CHOICE_RAR_ORDER[b.rarity] or 9
		if ra ~= rb then return ra < rb end
		return a.name < b.name
	end)
	return out
end

-- Choix bornés au PALIER animateur (EVO_ANIM.Caps, sh_anim_tiers — grille 08/02). Même source
-- que le serveur, qui revalide de toute façon dans EVO:Anim:SelfSet.
local function selfCap()
	return (EVO_ANIM and EVO_ANIM.Cap and EVO_ANIM.Cap(LocalPlayer())) or nil
end
-- MIROIR de SELFSET_CAP_KEY (sv_animateur) : catégorie de pool -> clé de plafond du palier.
local SELF_CAP_KEY = { art_spirituel = "art", style_de_combat = "style", reiatsu_color = "aura" }
local function selfChoices(kind)
	local out, seen = {}, {}
	local cap = selfCap()
	local allowed = (cap and cap[SELF_CAP_KEY[kind] or ""]) or {}
	if REROLL_DROPS then
		for _, fac in pairs(REROLL_DROPS) do
			local list = fac[kind]
			if istable(list) then
				for _, d in ipairs(list) do
					if d.win_id and not seen[d.win_id] and allowed[d.rarity]
						and (not d.superadmin_only or LocalPlayer():IsSuperAdmin()) then
						seen[d.win_id] = true
						out[#out + 1] = { id = d.win_id, name = d.name or d.win_id, rarity = d.rarity or "commun" }
					end
				end
			end
		end
	end
	table.sort(out, function(a, b)
		local ra, rb = CHOICE_RAR_ORDER[a.rarity] or 9, CHOICE_RAR_ORDER[b.rarity] or 9
		if ra ~= rb then return ra < rb end
		return a.name < b.name
	end)
	return out
end

-- Champ de RECHERCHE en tête d'un menu déroulant de joueurs (demande user 09/10) : filtre à
-- chaque frappe sur le nom RP OU le SteamID64. Avec 60 joueurs en ligne la liste seule
-- obligeait à défiler pour trouver quelqu'un. Créé AVANT le DScrollPanel : le dock TOP doit
-- passer avant le FILL, sinon la liste passe par-dessus le champ.
local RECHERCHE_H = 34
local function champRecherche(pop, onChange)
	local col = C()
	local e = vgui.Create("DTextEntry", pop)
	e:Dock(TOP) e:DockMargin(R(6), R(6), R(6), 0) e:SetTall(R(RECHERCHE_H - 6))
	e:SetFont("EVO_Anim_Small") e:SetPaintBackground(false)
	e:SetPlaceholderText("Rechercher un joueur (nom ou SteamID)…")
	if e.SetDrawLanguageID then e:SetDrawLanguageID(false) end
	e.Paint = function(s, w, h)
		RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, 12))
		RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(s:HasFocus() and col.accent or col.border, s:HasFocus() and 150 or 50), 1)
		if s:GetValue() == "" and not s:HasFocus() then
			draw.SimpleText(s:GetPlaceholderText(), "EVO_Anim_Small", R(8), h / 2, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		s:DrawTextEntryText(col.title, col.accent, col.title)
	end
	e.OnChange = function(s) onChange(s:GetValue()) end
	timer.Simple(0, function() if IsValid(e) then e:RequestFocus() end end)
	return e
end

-- Vrai si l'item passe le filtre (nom RP ou SteamID64, insensible à la casse).
local function correspond(it, q)
	if q == "" then return true end
	return string.find(string.lower(it.name or ""), q, 1, true) ~= nil
		or string.find(tostring(it.id or ""), q, 1, true) ~= nil
end

-- Dropdown générique (même style que OpenNpcDropdown) : liste d'items {id,name,rarity}.
local function OpenChoiceDropdown(dd, items, getCur, onPick)
	if not IsValid(pAnim) or not IsValid(dd) then return end
	local col = C()
	local sx, sy = dd:LocalToScreen(0, dd:GetTall() + R(4))
	local pw = dd:GetWide()
	-- Liste de JOUEURS (id = SteamID64) : elle reçoit le champ de recherche.
	local i1 = items[1]
	local bJoueurs = i1 and isstring(i1.id) and #i1.id == 17 and string.sub(i1.id, 1, 4) == "7656"
	local ph = math.min(R(300) + (bJoueurs and R(RECHERCHE_H) or 0), ScrH() - sy - R(20))

	local back = vgui.Create("DButton", pAnim) back:SetText("")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0) back:SetZPos(900) back.Paint = function() end

	local pop = vgui.Create("DPanel", pAnim)
	pop:SetSize(pw, ph) pop:SetPos(sx, sy) pop:SetZPos(901) pop:SetMouseInputEnabled(true)
	pop.Paint = function(_, w, h)
		RNDX.Draw(R(8), 0, 0, w, h, col.bg)
		RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.accent, 130), 1.5)
	end
	dd._pop = pop

	local function closeAll()
		dd._pop = nil
		if IsValid(pop) then pop:Remove() end
		if IsValid(back) then back:Remove() end
	end
	back.DoClick = closeAll
	pop.OnRemove = function() if IsValid(back) then back:Remove() end end

	local remplir -- défini plus bas, le champ l'appelle à chaque frappe
	if bJoueurs then champRecherche(pop, function(q) remplir(q) end) end

	local scroll = vgui.Create("DScrollPanel", pop)
	scroll:Dock(FILL) scroll:DockMargin(R(6), R(6), R(6), R(6))
	local sb = scroll:GetVBar()
	if IsValid(sb) then
		sb:SetWide(R(6)) sb.Paint = function() end
		if IsValid(sb.btnUp) then sb.btnUp.Paint = function() end end
		if IsValid(sb.btnDown) then sb.btnDown.Paint = function() end end
		sb.btnGrip.Paint = function(_, w, h) RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(col.accent, 130)) end
	end

	remplir = function(q)
	scroll:Clear()
	q = string.lower(q or "")
	local n = 0
	for _, it in ipairs(items) do if correspond(it, q) then
	n = n + 1
		-- Items JOUEURS (modération) : it.id = SteamID64 (17 chiffres, 7656...). On l'affiche à droite
		-- et le CLIC DROIT le copie (demande user 2026-07-22). Les items art/style (id = clé rareté)
		-- gardent l'affichage de rareté et ne sont pas copiables.
		local isSid = isstring(it.id) and #it.id == 17 and string.sub(it.id, 1, 4) == "7656"
		local row = scroll:Add(vgui.Create("DButton"))
		row:SetText("") row:Dock(TOP) row:DockMargin(0, R(2), 0, 0) row:SetTall(R(30))
		row.Paint = function(rs, rw, rh)
			local sel = (getCur() == it.id)
			if rs:IsHovered() or sel then RNDX.Draw(R(5), 0, 0, rw, rh, ColorAlpha(col.accent, sel and 90 or 55)) end
			draw.SimpleText(it.name, "EVO_Anim_Small", R(10), rh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if isSid then
				draw.SimpleText(it.id, "EVO_Anim_Small", rw - R(10), rh / 2, rs:IsHovered() and col.accent or col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText(string.upper(it.rarity), "EVO_Anim_Small", rw - R(10), rh / 2, CHOICE_RAR_COL[it.rarity] or col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		row.DoClick = function() onPick(it) closeAll() end
		if isSid then
			row.DoRightClick = function()
				SetClipboardText(it.id)
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("SteamID copié : " .. it.id, NOTIFY_GENERIC, 3) end
			end
		end
	end end
	if n == 0 then
		local vide = scroll:Add(vgui.Create("DLabel"))
		vide:Dock(TOP) vide:DockMargin(R(10), R(8), 0, 0) vide:SetTall(R(24))
		vide:SetFont("EVO_Anim_Small") vide:SetTextColor(col.dim) vide:SetText("Aucun joueur ne correspond.")
	end
	end
	remplir("")
end

-- Multi-selection de joueurs (invites du tournoi) : rows togglables (case cochee), ne ferme PAS au clic.
-- selSet = table sid->name (mutee en place) ; items = { {id, name, dist}, ... }.
local function OpenPlayerMultiSelect(dd, items, selSet)
	if not IsValid(pAnim) or not IsValid(dd) then return end
	local col = C()
	local sx, sy = dd:LocalToScreen(0, dd:GetTall() + R(4))
	local pw = dd:GetWide()
	local ph = math.min(R(320) + R(RECHERCHE_H), ScrH() - sy - R(20))
	local back = vgui.Create("DButton", pAnim) back:SetText("")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0) back:SetZPos(900) back.Paint = function() end
	local pop = vgui.Create("DPanel", pAnim)
	pop:SetSize(pw, ph) pop:SetPos(sx, sy) pop:SetZPos(901) pop:SetMouseInputEnabled(true)
	pop.Paint = function(_, w, h)
		RNDX.Draw(R(8), 0, 0, w, h, col.bg)
		RNDX.DrawOutlined(R(8), 0, 0, w, h, ColorAlpha(col.accent, 130), 1.5)
	end
	dd._pop = pop
	local function closeAll()
		dd._pop = nil
		if IsValid(pop) then pop:Remove() end
		if IsValid(back) then back:Remove() end
	end
	back.DoClick = closeAll
	pop.OnRemove = function() if IsValid(back) then back:Remove() end end
	local remplir
	champRecherche(pop, function(q) remplir(q) end)
	local scroll = vgui.Create("DScrollPanel", pop)
	scroll:Dock(FILL) scroll:DockMargin(R(6), R(6), R(6), R(6))
	local sb = scroll:GetVBar()
	if IsValid(sb) then
		sb:SetWide(R(6)) sb.Paint = function() end
		if IsValid(sb.btnUp) then sb.btnUp.Paint = function() end end
		if IsValid(sb.btnDown) then sb.btnDown.Paint = function() end end
		sb.btnGrip.Paint = function(_, w, h) RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(col.accent, 130)) end
	end
	-- La sélection vit dans selSet : refiltrer ne perd aucune case cochée.
	remplir = function(q)
	scroll:Clear()
	q = string.lower(q or "")
	for _, it in ipairs(items) do if correspond(it, q) then
		local row = scroll:Add(vgui.Create("DButton"))
		row:SetText("") row:Dock(TOP) row:DockMargin(0, R(2), 0, 0) row:SetTall(R(30))
		row.Paint = function(rs, rw, rh)
			local on = selSet[it.id] ~= nil
			if rs:IsHovered() or on then RNDX.Draw(R(5), 0, 0, rw, rh, ColorAlpha(col.accent, on and 90 or 55)) end
			RNDX.DrawOutlined(R(3), R(10), rh / 2 - R(7), R(14), R(14), ColorAlpha(on and col.accent or col.border, on and 220 or 90), 1.5)
			if on then RNDX.Draw(R(2), R(13), rh / 2 - R(4), R(8), R(8), col.accent) end
			draw.SimpleText(it.name, "EVO_Anim_Small", R(32), rh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if it.dist then draw.SimpleText(it.dist, "EVO_Anim_Small", rw - R(10), rh / 2, col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER) end
		end
		row.DoClick = function()
			if selSet[it.id] then selSet[it.id] = nil else selSet[it.id] = it.name end
		end
	end end
	end
	remplir("")
end

local function buildBody(card, CARD_W)
	local col = C()
	for _, ch in ipairs(card:GetChildren()) do
		if ch.EVO_AnimBody then ch:Remove() end
	end
	-- Corps SCROLLABLE : le contenu dépasse la hauteur fixe de la carte (section HOLLOW +
	-- entités spawnées dynamiques). DScrollPanel sous le titre ; `host` = canvas docké dont on
	-- fixe la hauteur au contenu réel en fin de buildBody. `scroll` porte le tag EVO_AnimBody
	-- (le rebuild "MyEntities" supprime les enfants taggés de la carte).
	-- ── ONGLETS (refonte 2026-07-23, demande user « plus joli + plus intuitif ») ──
	-- Le corps, autrefois un SEUL long défilement de ~13 sections, est réparti en 4 ONGLETS.
	-- Chaque onglet a son propre DScrollPanel (host docké) ; seul l'actif est visible. On mémorise
	-- l'onglet courant dans state.animTab (conservé au rebuild « MyEntities »). Le code des sections
	-- est INCHANGÉ : on bascule juste `host`/`y` d'un onglet à l'autre aux frontières (les helpers
	-- secLabel/chip/styleEntry et les vgui.Create(..., host) écrivent dans le `host` courant).
	local TAB_NAMES = { "GÉNÉRAL", "COMBAT", "BOSS", "INCARNER", "OUTILS" }
	state.animTab = math.Clamp(tonumber(state.animTab) or 1, 1, #TAB_NAMES)

	local tabScrolls, tabHosts = {}, {}
	local function showTab(i)
		state.animTab = i
		for j = 1, #TAB_NAMES do if IsValid(tabScrolls[j]) then tabScrolls[j]:SetVisible(j == i) end end
	end

	-- Barre d'onglets (sous le titre + le filet denté).
	local tabBar = vgui.Create("DPanel", card) tabBar.EVO_AnimBody = true
	tabBar:SetPos(R(0), R(66)) tabBar:SetSize(R(CARD_W), R(34)) tabBar:SetPaintBackground(false)

	-- 4 scrolls (un par onglet), même emplacement ; seul l'actif est visible.
	for i = 1, #TAB_NAMES do
		local sc = vgui.Create("DScrollPanel", card) sc.EVO_AnimBody = true
		sc:SetPos(R(0), R(104)) sc:SetSize(R(CARD_W), card:GetTall() - R(110))
		sc:SetVisible(i == state.animTab)
		local sbar = sc:GetVBar()
		if IsValid(sbar) then
			sbar:SetWide(R(6)) sbar.Paint = function() end
			if IsValid(sbar.btnUp) then sbar.btnUp.Paint = function() end end
			if IsValid(sbar.btnDown) then sbar.btnDown.Paint = function() end end
			sbar.btnGrip.Paint = function(_, w, h) RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(col.accent, 130)) end
		end
		local hst = vgui.Create("DPanel", sc) hst:Dock(TOP)
		hst:SetPaintBackground(false) hst:SetMouseInputEnabled(true) hst.OnMousePressed = function() end
		tabScrolls[i], tabHosts[i] = sc, hst
	end

	-- Boutons d'onglets répartis sur la largeur (actif = accent plein).
	do
		local n  = #TAB_NAMES
		local bwB = math.floor((CARD_W - 48) / n)
		for i, nm in ipairs(TAB_NAMES) do
			local tb = vgui.Create("DButton", tabBar) tb:SetText("") tb:SetCursor("hand")
			tb:SetPos(R(24 + (i - 1) * bwB), R(0)) tb:SetSize(R(bwB - 6), R(30))
			tb.Paint = function(s, w, h)
				local active = (state.animTab == i)
				local hov = s:IsHovered()
				RNDX.Draw(R(7), 0, 0, w, h, active and col.accent or ColorAlpha(color_white, hov and 22 or 10))
				draw.SimpleText(nm, "EVO_Anim_Btn", w / 2, h / 2, active and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			tb.DoClick = function() surface.PlaySound("garrysmod/ui_click.wav") showTab(i) end
		end
	end

	local PADX, INNER = 24, CARD_W - 48
	-- host/y COURANTS : on démarre sur l'onglet 1 ; les frontières plus bas basculent vers 2/3/4.
	local host = tabHosts[1]
	local y = 8

	local function secLabel(txt)
		-- Puce accent + libellé (boîte agrandie pour la grosse fonte, plus repérable).
		local tick = vgui.Create("DPanel", host) tick:SetPaintBackground(false)
		tick:SetPos(R(PADX), R(y + 3)) tick:SetSize(R(4), R(18))
		tick.Paint = function(_, w, h) RNDX.Draw(R(2), 0, 0, w, h, col.accent) end
		local l = vgui.Create("DLabel", host) l:SetFont("EVO_Anim_H") l:SetTextColor(col.title)
		l:SetPos(R(PADX + 12), R(y)) l:SetSize(R(INNER - 12), R(24)) l:SetText(txt)
		y = y + 30
	end
	local function styleEntry(p) -- DTextEntry stylé
		p:SetPaintBackground(false)
		if p.SetDrawLanguageID then p:SetDrawLanguageID(false) end -- retire le "FR" (indicateur de langue) dans le champ
		p.Paint = function(s, w, h)
			RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(color_white, 12))
			RNDX.DrawOutlined(R(6), 0, 0, w, h, ColorAlpha(col.border, 50), 1)
			s:DrawTextEntryText(col.title, col.accent, col.title)
		end
	end
	-- Persistance des champs (demande user 07/31) : la valeur TAPÉE est mémorisée dans
	-- `state` (local de fichier = cache client, zéro réseau) à chaque frappe, et les
	-- champs se re-seedent depuis `state` à la réouverture du menu.
	local function persistEntry(p, sKey)
		p.OnChange = function(s)
			local n = tonumber(s:GetValue())
			if n then state[sKey] = n end
		end
	end

	-- ── Mode animateur (toggle) ──
	local mode = vgui.Create("DButton", host) mode:SetText("")
	mode:SetPos(R(PADX), R(y)) mode:SetSize(R(INNER), R(40))
	mode.Paint = function(s, w, h)
		local on = LocalPlayer():GetEvoNWBool("EVO_AnimMode", false)
		RNDX.Draw(R(9), 0, 0, w, h, ColorAlpha(on and col.green or color_white, on and 230 or 10))
		if not on then RNDX.DrawOutlined(R(9), 0, 0, w, h, ColorAlpha(col.border, 40), 1) end
		draw.SimpleText("Mode animateur : " .. (on and "ACTIVÉ (invisible · noclip · god)" or "désactivé : clique pour activer"), "EVO_Anim_Btn", w / 2, h / 2, on and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	mode.DoClick = function() net.Start("EVO:Anim:Mode") net.SendToServer() end
	y = y + 48

	-- ── Mode build (29/09/2026) : physgun + toolgun + menu Q, props plafonnes sur le
	-- serveur (sh_anim_build.lua). Animateur et Gerant Animateur seulement.
	if EVO_BUILD and EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(LocalPlayer()) >= EVO_BUILD.TIER_MIN then
		-- Etat et compteur demandes au serveur a l'ouverture (message, pas de NW).
		net.Start("EVO:Anim:Build") net.WriteUInt(0, 3) net.SendToServer()
		local build = vgui.Create("DButton", host) build:SetText("")
		build:SetPos(R(PADX), R(y)) build:SetSize(R(INNER), R(40))
		build.Paint = function(s, w, h)
			local on = EVO_BUILD.MoiActif == true
			RNDX.Draw(R(9), 0, 0, w, h, ColorAlpha(on and col.accent or color_white, on and 230 or 10))
			if not on then RNDX.DrawOutlined(R(9), 0, 0, w, h, ColorAlpha(col.border, 40), 1) end
			local txt = on and "Mode build : ACTIVÉ (physgun · toolgun · catalogue sur Q)" or "Mode build : désactivé : clique pour activer"
			txt = txt .. "  ·  " .. (EVO_BUILD.Nombre or 0) .. "/" .. EVO_BUILD.MAX_PROPS .. " props"
			draw.SimpleText(txt, "EVO_Anim_Btn", w / 2, h / 2, on and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		build.DoClick = function() net.Start("EVO:Anim:Build") net.WriteUInt(1, 3) net.SendToServer() end
		y = y + 48
		local _, wMes = chip(host, "Retirer mes props", PADX, y, col.accent, function()
			net.Start("EVO:Anim:Build") net.WriteUInt(2, 3) net.SendToServer()
		end)
		if EVO_ANIM.Tier(LocalPlayer()) >= EVO_BUILD.TIER_TOUT then
			chip(host, "Retirer tous les props build", PADX + (wMes or 0) + 8, y, col.accent, function()
				if not Derma_Query then net.Start("EVO:Anim:Build") net.WriteUInt(3, 3) net.SendToServer() return end
				Derma_Query("Retirer TOUS les props de build du serveur, ceux des autres animateurs compris ?", "Mode build",
					"Oui, tout retirer", function() net.Start("EVO:Anim:Build") net.WriteUInt(3, 3) net.SendToServer() end, "Annuler")
			end)
		end
		y = y + 42
	end

	-- ── Point d'arrivée d'event (30/09/2026, evo_portals/sh_evenement.lua) : une case
	-- « ??? » dans la roue Garganta et/ou Senkaimon, qui mène là où il a été posé.
	if EVO_Portal and EVO_Portal.EnvoyerEvenement and EVO_ANIM and EVO_ANIM.Tier
		and EVO_ANIM.Tier(LocalPlayer()) >= (EVO_Portal.EVENT_TIER or 2) then
		EVO_Portal.EnvoyerEvenement(0) -- etat a jour a l'ouverture
		local ev = EVO_Portal.Evenement
		local etat = vgui.Create("DLabel", host) etat:SetFont("EVO_Anim_Small") etat:SetTextColor(col.muted)
		etat:SetPos(R(PADX), R(y)) etat:SetSize(R(INNER), R(16))
		etat.Think = function(s)
			local txt = "Point d'arrivée event : aucun. Pose-le là où tu te tiens, puis coche les portails."
			if ev.pose then
				local l = {}
				if ev.portails.garganta then l[#l + 1] = "Garganta" end
				if ev.portails.senkaimon then l[#l + 1] = "Senkaimon" end
				txt = "Point d'arrivée event posé par " .. (ev.par ~= "" and ev.par or "?") .. " : "
					.. (#l > 0 and ("case « ??? » dans " .. table.concat(l, " et ")) or "aucun portail coché")
			end
			if s:GetText() ~= txt then s:SetText(txt) end
		end
		y = y + 22
		local x = PADX
		local _, w1 = chip(host, "Poser le point ici", x, y, col.accent, function() EVO_Portal.EnvoyerEvenement(1) end)
		x = x + (w1 or 0) + 8
		-- Cases : vertes quand cochees (relu a chaque image, sans reconstruire le panneau).
		local _, w2 = chip(host, "Garganta", x, y, function() return ev.portails.garganta and col.green or col.dim end,
			function() EVO_Portal.EnvoyerEvenement(2, 0) end)
		x = x + (w2 or 0) + 8
		local _, w3 = chip(host, "Senkaimon", x, y, function() return ev.portails.senkaimon and col.green or col.dim end,
			function() EVO_Portal.EnvoyerEvenement(2, 1) end)
		x = x + (w3 or 0) + 8
		chip(host, "Retirer le point", x, y, col.accent, function() EVO_Portal.EnvoyerEvenement(3) end)
		y = y + 42
	end

	-- Astuce : la touche pour OUVRIR cette UI se règle dans le menu de binds (Échap →
	-- Bind → « Ouvrir l'UI Animateur », défaut ' apostrophe). Le mode se toggle au-dessus.
	local bhint = vgui.Create("DLabel", host) bhint:SetFont("EVO_Anim_Small") bhint:SetTextColor(col.dim)
	bhint:SetPos(R(PADX), R(y)) bhint:SetSize(R(INNER), R(16)) bhint:SetWrap(true)
	bhint:SetText("Touche pour ouvrir cette UI : à régler dans le menu de binds (« Ouvrir l'UI Animateur », défaut ' apostrophe).")
	y = y + 22

	-- ── CALENDRIER (events d'animation, cross-serveur) ──
	local _, wCal = chip(host, "Calendrier des événements", PADX, y, col.green, function()
		if IsValid(pAnim) then pAnim:Remove() end
		if EVO_OpenCalendrier then EVO_OpenCalendrier() end
	end)
	-- Les evenements du staff (evo_events, 30/09/2026) : meteores, Sphere, ames,
	-- fissures, feux d'artifice... Le serveur revalide le droit a l'ouverture.
	local xOutils = PADX + (wCal or 0) + 8
	if EVO_EVENTS and EVO_EVENTS.Peut and EVO_EVENTS.Peut(LocalPlayer()) then
		local _, wEv = chip(host, "Événements", xOutils, y, col.accent, function()
			if IsValid(pAnim) then pAnim:Remove() end
			RunConsoleCommand("evo_event")
		end)
		xOutils = xOutils + (wEv or 0) + 8
	end
	-- Ciel et meteo (evo_ciel, 10/09) : Gerant RP et superadmin, pour la trame principale.
	-- Meme principe que le bouton au-dessus : le serveur revalide le droit a l'ouverture.
	if EVO_CIEL and EVO_CIEL.Peut and EVO_CIEL.Peut(LocalPlayer()) then
		chip(host, "Ciel et météo", xOutils, y, col.accent, function()
			if IsValid(pAnim) then pAnim:Remove() end
			RunConsoleCommand("evo_ciel")
		end)
	end
	y = y + 42

	-- ── COFFRES ──
	state.quotaLbl = vgui.Create("DLabel", host) state.quotaLbl:SetFont("EVO_Anim_H") state.quotaLbl:SetTextColor(col.title)
	state.quotaLbl:SetPos(R(PADX), R(y)) state.quotaLbl:SetSize(R(INNER), R(18))
	state.quotaLbl:SetText("COFFRES : " .. state.used .. "/" .. state.max .. " (par 2h)")
	y = y + 24
	do
		local x = PADX
		for _, c in ipairs(state.chests) do
			local _, w = chip(host, c.name, x, y, RAR[c.rarity] or col.accent, function()
				net.Start("EVO:Anim:Chest") net.WriteString(c.id) net.SendToServer()
			end)
			x = x + w + 8
			if x > CARD_W - 120 then x = PADX y = y + 38 end
		end
		y = y + 42
	end

	-- ── MON PERSO ANIMATEUR (self-set) : style / art / grade / niveau PLAFONNÉS PAR PALIER
	-- (EVO_ANIM.Caps, grille 08/02). Les listes ne font que SÉLECTIONNER ; « Donner » applique la
	-- sélection. Le SERVEUR (EVO:Anim:SelfSet) revalide raretés et plafonds. ──
	secLabel("MON PERSO ANIMATEUR")
	-- Style de combat (raretés du palier)
	local ddSelfStyle = vgui.Create("DButton", host) ddSelfStyle:SetText("")
	ddSelfStyle:SetPos(R(PADX), R(y)) ddSelfStyle:SetSize(R(INNER), R(34))
	ddSelfStyle.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.selfStyleName or "Style de combat…", "EVO_Anim_Btn", R(12), h / 2, state.selfStyleName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddSelfStyle.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		OpenChoiceDropdown(s, selfChoices("style_de_combat"), function() return state.selfStyle end, function(it)
			state.selfStyle, state.selfStyleName = it.id, it.name
		end)
	end
	y = y + 40
	-- Art spirituel (raretés du palier)
	local ddSelfArt = vgui.Create("DButton", host) ddSelfArt:SetText("")
	ddSelfArt:SetPos(R(PADX), R(y)) ddSelfArt:SetSize(R(INNER), R(34))
	ddSelfArt.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.selfArtName or "Art spirituel…", "EVO_Anim_Btn", R(12), h / 2, state.selfArtName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddSelfArt.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		OpenChoiceDropdown(s, selfChoices("art_spirituel"), function() return state.selfArt end, function(it)
			state.selfArt, state.selfArtName = it.id, it.name
		end)
	end
	y = y + 40
	-- Grade (plafond du palier)
	local ddSelfGrade = vgui.Create("DButton", host) ddSelfGrade:SetText("")
	ddSelfGrade:SetPos(R(PADX), R(y)) ddSelfGrade:SetSize(R(INNER), R(34))
	ddSelfGrade.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.selfGradeName or "Grade…", "EVO_Anim_Btn", R(12), h / 2, state.selfGradeName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddSelfGrade.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		local gr = {}
		for g = 1, (selfCap() or {}).grade or 7 do gr[#gr + 1] = { id = tostring(g), name = "Grade " .. g, rarity = "commun" } end
		OpenChoiceDropdown(s, gr, function() return state.selfGrade end, function(it)
			state.selfGrade, state.selfGradeName = it.id, it.name
		end)
	end
	y = y + 42
	-- Aura (couleur de reiatsu) — palier GÉRANT uniquement : la liste n'existe pas pour les
	-- autres, dont le plafond n'a pas de table `aura` (le serveur refuse de toute façon).
	local bAura = (selfCap() or {}).aura ~= nil
	if bAura then
		local ddSelfAura = vgui.Create("DButton", host) ddSelfAura:SetText("")
		ddSelfAura:SetPos(R(PADX), R(y)) ddSelfAura:SetSize(R(INNER), R(34))
		ddSelfAura.Paint = function(s, w, h)
			local open = IsValid(s._pop)
			RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
			RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
			draw.SimpleText(state.selfAuraName or "Aura de reiatsu…", "EVO_Anim_Btn", R(12), h / 2, state.selfAuraName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		ddSelfAura.DoClick = function(s)
			if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
			OpenChoiceDropdown(s, selfChoices("reiatsu_color"), function() return state.selfAura end, function(it)
				state.selfAura, state.selfAuraName = it.id, it.name
			end)
		end
		y = y + 42
	end
	-- Bouton DONNER : applique les sélections des listes ci-dessus (les dropdowns ne
	-- s'appliquent plus au clic ; on valide ici). Seuls les champs choisis sont envoyés.
	chip(host, bAura and "Donner (style / art / grade / aura)" or "Donner (style / art / grade)", PADX, y, col.green, function()
		local sent = 0
		if state.selfStyle then net.Start("EVO:Anim:SelfSet") net.WriteString("style") net.WriteString(state.selfStyle) net.SendToServer() sent = sent + 1 end
		if state.selfArt   then net.Start("EVO:Anim:SelfSet") net.WriteString("art")   net.WriteString(state.selfArt)   net.SendToServer() sent = sent + 1 end
		if state.selfGrade then net.Start("EVO:Anim:SelfSet") net.WriteString("grade") net.WriteString(state.selfGrade) net.SendToServer() sent = sent + 1 end
		if bAura and state.selfAura then net.Start("EVO:Anim:SelfSet") net.WriteString("aura") net.WriteString(state.selfAura) net.SendToServer() sent = sent + 1 end
		if MUGEN and MUGEN.AddNotification then
			if sent > 0 then MUGEN.AddNotification("Appliqué à ton perso animateur.", NOTIFY_GENERIC, 3)
			else MUGEN.AddNotification("Choisis d'abord un style / art / grade dans les listes.", NOTIFY_ERROR, 4) end
		end
	end)
	y = y + 42
	-- Niveau (plafond du palier)
	local capLvl = (selfCap() or {}).level or 50
	local lvlL = vgui.Create("DLabel", host) lvlL:SetFont("EVO_Anim_Small") lvlL:SetTextColor(col.muted)
	lvlL:SetPos(R(PADX), R(y)) lvlL:SetSize(R(INNER), R(16))
	lvlL:SetText("Niveau (1 - " .. capLvl .. ")")
	local lvlE = vgui.Create("DTextEntry", host) lvlE:SetNumeric(true) lvlE:SetFont("EVO_Anim_Small")
	lvlE:SetPos(R(PADX), R(y + 18)) lvlE:SetSize(R(math.floor(INNER / 2) - 8), R(26))
	lvlE:SetText(tostring(state.selfLevel or capLvl))
	styleEntry(lvlE) persistEntry(lvlE, "selfLevel")
	y = y + 52
	chip(host, "Se mettre ce NIVEAU", PADX, y, col.green, function()
		local n = tonumber(IsValid(lvlE) and lvlE:GetValue())
		if not n or n < 1 or n > capLvl then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Niveau invalide - entre 1 et " .. capLvl .. ".", NOTIFY_ERROR, 4) end
			return
		end
		net.Start("EVO:Anim:SelfSet") net.WriteString("level") net.WriteString(tostring(math.floor(n))) net.SendToServer()
	end)
	y = y + 42
	-- Ars Hollow 1-3 + vol (palier Animateur et plus)
	if (selfCap() or {}).hollowArts then
		chip(host, "Ars Hollow 1-3 + Vol (perso Hollow)", PADX, y, Color(190, 110, 220), function()
			net.Start("EVO:Anim:SelfSet") net.WriteString("hollowarts") net.WriteString("") net.SendToServer()
		end)
		y = y + 38
	end
	-- Les 5 premiers parchemins des 3 voies (palier Animateur et plus)
	if (selfCap() or {}).parchemins then
		chip(host, "Parchemins : Ars Hollow / Bakudo / Hado 1-5", PADX, y, Color(210, 150, 90), function()
			net.Start("EVO:Anim:SelfSet") net.WriteString("parchemins") net.WriteString("") net.SendToServer()
		end)
		y = y + 38
	end
	-- Sorts de division (palier Animateur et plus) : celui de la division jouée s'active seul
	if (selfCap() or {}).division then
		chip(host, "Débloquer les sorts de division", PADX, y, Color(120, 180, 160), function()
			net.Start("EVO:Anim:SelfSet") net.WriteString("division") net.WriteString("") net.SendToServer()
		end)
		y = y + 38
	end
	-- Vol + Vol de Combat (air walk), palier Animateur et plus
	if (selfCap() or {}).mobility then
		chip(host, "Débloquer Vol + Vol de Combat", PADX, y, Color(90, 160, 220), function()
			net.Start("EVO:Anim:SelfSet") net.WriteString("mobility") net.WriteString("") net.SendToServer()
		end)
		y = y + 38
	end
	-- Objets boutique (paliers avec items) : ouvre le SÉLECTEUR VISUEL existant
	-- (lzy_animation_menu, onglets tenues/accessoires/katanas — raretés du palier).
	if ((selfCap() or {}).items or 0) > 0 and LZY_AnimMenu_OpenAnimatorTools then
		chip(host, "Objets boutique (tenues / accessoires / katanas)", PADX, y, Color(220, 170, 90), function()
			LZY_AnimMenu_OpenAnimatorTools()
		end)
		y = y + 46
	else
		y = y + 4
	end

	-- ════════ Fin onglet GÉNÉRAL → bascule vers COMBAT ════════
	tabHosts[1]:SetTall(R(y)) ; host = tabHosts[2] ; y = 8

	-- ── BOSS (spawn PNJ) ──
	secLabel("CHASSE AUX HOLLOWS (Garganta)")
		do
			chip(host, "Garganta + Hollows", PADX, y, col.accent, function()
				net.Start("EVO:Anim:GargantaWave") net.WriteBool(false) net.SendToServer()
			end)
			y = y + 38
			chip(host, "Garganta + Hollows DURS (boostés)", PADX, y, Color(190, 110, 220), function()
				net.Start("EVO:Anim:GargantaWave") net.WriteBool(true) net.SendToServer()
			end)
			y = y + 44
		end

		chip(host, "Supprimer les Hollows (chasse)", PADX, y, Color(120, 120, 130), function()
			net.Start("EVO:Anim:GargantaClear") net.WriteBool(false) net.SendToServer()
		end)
		y = y + 44

		secLabel("TOURNOI")
		do
			state.tourneyInvites = state.tourneyInvites or {}
			-- Sélecteur d'invités (multi-sélection). VIDE => les joueurs PROCHES de l'organisateur (demande user 07/25).
			local ddInv = vgui.Create("DButton", host) ddInv:SetText("")
			ddInv:SetPos(R(PADX), R(y)) ddInv:SetSize(R(INNER), R(34))
			ddInv.Paint = function(s, w, h)
				local open = IsValid(s._pop)
				local n = table.Count(state.tourneyInvites)
				RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
				RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
				local txt = n > 0 and ("Invités : " .. n .. " sélectionné(s)") or "Invités : joueurs proches (défaut)"
				draw.SimpleText(txt, "EVO_Anim_Btn", R(12), h / 2, n > 0 and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			ddInv.DoClick = function(s)
				if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
				local lp = LocalPlayer()
				local origin = IsValid(lp) and lp:GetPos() or Vector(0, 0, 0)
				local items = {}
				for _, p in player.Iterator() do
					if IsValid(p) and p ~= lp and not p:IsSuperAdmin() then
						local nm = p:GetEvoNWString("Nickname", "") ; if nm == "" then nm = p:Nick() end
						local d = p:GetPos():Distance(origin)
						items[#items + 1] = { id = p:SteamID64(), name = nm, _d = d, dist = math.Round(d / 52.49) .. " m" }
					end
				end
				if #items == 0 then
					if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Aucun joueur à inviter.", NOTIFY_ERROR, 3) end
					return
				end
				table.sort(items, function(a, b) return a._d < b._d end)
				OpenPlayerMultiSelect(s, items, state.tourneyInvites)
			end
			y = y + 40
			chip(host, "Vider la sélection", PADX, y, Color(70, 70, 80), function()
				state.tourneyInvites = {}
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Sélection vidée : invitera les joueurs proches.", NOTIFY_GENERIC, 2) end
			end)
			y = y + 42
			local function sendOpen(typ)
				net.Start("EVO:Tourney:Open")
				net.WriteString(typ)
				local sids = {}
				for sid in pairs(state.tourneyInvites or {}) do sids[#sids + 1] = sid end
				net.WriteUInt(#sids, 8)
				for _, sid in ipairs(sids) do net.WriteString(sid) end
				net.SendToServer()
			end
			chip(host, "Mode Tournoi (PvP)", PADX, y, col.accent, function() sendOpen("pvp") end)
			y = y + 38
			-- « Tournoi Clan » (renommé 07/20) : la clé réseau interne reste "famille" (compat EVO_FamilyName).
			chip(host, "Mode Tournoi Clan", PADX, y, Color(224, 120, 200), function() sendOpen("famille") end)
			y = y + 38
			chip(host, "Ouvrir le panneau Tournoi", PADX, y, Color(70, 70, 80), function()
				if EVO_AnimTourney and EVO_AnimTourney.OpenPanel then EVO_AnimTourney.OpenPanel() end
			end)
			y = y + 44
		end

	-- ════════ Fin onglet COMBAT → bascule vers BOSS ════════
	tabHosts[2]:SetTall(R(y)) ; host = tabHosts[3] ; y = 8

		secLabel("BOSS / HOLLOW (spawn PNJ) : PV & dégâts au choix")
		-- Dropdown : TOUS les Hollows/boss spawnables (NCM_PNJ.Config). Sélectionner pré-remplit PV/dégâts.
		local ddB = vgui.Create("DButton", host) ddB:SetText("")
		ddB:SetPos(R(PADX), R(y)) ddB:SetSize(R(INNER), R(36))
		ddB.Paint = function(s, w, h)
			local open = IsValid(s._pop)
			RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
			RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
			draw.SimpleText(state.bossName or "Choisir un Hollow / boss à spawn…", "EVO_Anim_Btn", R(12), h / 2, state.bossName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		ddB.DoClick = function(s)
			if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
			OpenNpcDropdown(s, bossGroups(), function(n)
				state.bossClass, state.bossName = n.class, n.name
				state.bossHP, state.bossDMG = n.hp, n.dmg
				if IsValid(state.bossHpEntry)  then state.bossHpEntry:SetText(tostring(n.hp))   end
				if IsValid(state.bossDmgEntry) then state.bossDmgEntry:SetText(tostring(n.dmg)) end
			end, function() return state.bossClass end)
		end
		y = y + 44

		-- PV + Dégâts (MÊMES bornes que la possession : PV 1-10000, dégâts/coup 0-200)
		do
			local half = math.floor(INNER / 2) - 8
			local hpl = vgui.Create("DLabel", host) hpl:SetFont("EVO_Anim_Small") hpl:SetTextColor(col.muted)
			hpl:SetPos(R(PADX), R(y)) hpl:SetSize(R(half), R(16)) hpl:SetText("Points de vie (1 – 10000)")
			local dml = vgui.Create("DLabel", host) dml:SetFont("EVO_Anim_Small") dml:SetTextColor(col.muted)
			dml:SetPos(R(PADX + half + 16), R(y)) dml:SetSize(R(half), R(16)) dml:SetText("Dégâts/coup (0 – 200)")

			local hpB = vgui.Create("DTextEntry", host) hpB:SetNumeric(true) hpB:SetFont("EVO_Anim_Small")
			hpB:SetPos(R(PADX), R(y + 18)) hpB:SetSize(R(half), R(26)) hpB:SetText(tostring(math.Clamp(state.bossHP or 3000, 1, 10000)))
			styleEntry(hpB) persistEntry(hpB, "bossHP") hpB._lo, hpB._hi = 1, 10000 state.bossHpEntry = hpB
			local dmB = vgui.Create("DTextEntry", host) dmB:SetNumeric(true) dmB:SetFont("EVO_Anim_Small")
			dmB:SetPos(R(PADX + half + 16), R(y + 18)) dmB:SetSize(R(half), R(26)) dmB:SetText(tostring(math.Clamp(state.bossDMG or 100, 0, 200)))
			styleEntry(dmB) persistEntry(dmB, "bossDMG") dmB._lo, dmB._hi = 0, 200 state.bossDmgEntry = dmB
		end
		y = y + 52

		chip(host, "Spawn le Hollow / boss", PADX, y, col.accent, function()
			local function refuse(msg)
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(msg, NOTIFY_ERROR, 4) end
			end
			if not state.bossClass then return refuse("Choisis d'abord un Hollow / boss.") end
			local hp  = tonumber(state.bossHpEntry:GetValue())
			local dmg = tonumber(state.bossDmgEntry:GetValue())
			if not hp  or hp  < 1 or hp  > 10000 then return refuse("Points de vie invalides — entre 1 et 10000.") end
			if not dmg or dmg < 0 or dmg > 200   then return refuse("Dégâts invalides — entre 0 et 200.") end
			net.Start("EVO:Anim:Boss")
				net.WriteString(state.bossClass)
				net.WriteUInt(math.floor(hp),  24)
				net.WriteUInt(math.floor(dmg), 20)
			net.SendToServer()
		end)
		y = y + 44

	-- ── MES ENTITÉS SPAWNÉES (suppression — seulement les miennes) ──
	local myEnts = state.myEnts or {}
	secLabel("MES ENTITÉS SPAWNÉES (" .. #myEnts .. "/5 en tout) : clic = supprimer")
	if #myEnts == 0 then
		local none = vgui.Create("DLabel", host) none:SetFont("EVO_Anim_Small") none:SetTextColor(col.dim)
		none:SetPos(R(PADX), R(y)) none:SetSize(R(INNER), R(16)) none:SetText("Aucune entité spawnée par toi.")
		y = y + 24
	else
		do
			local x = PADX
			for _, ent in ipairs(myEnts) do
				local _, w = chip(host, "✕ " .. (ent.name or "?"), x, y, col.accent, function()
					net.Start("EVO:Anim:DeleteEntity") net.WriteUInt(ent.idx or 0, 16) net.SendToServer()
				end)
				x = x + w + 8
				if x > CARD_W - 120 then x = PADX y = y + 38 end
			end
			y = y + 38
		end
		chip(host, "Tout supprimer (les miennes)", PADX, y, col.muted, function()
			net.Start("EVO:Anim:DeleteAllMine") net.SendToServer()
		end)
		y = y + 44
	end

	-- ════════ Fin onglet BOSS → bascule vers INCARNER ════════
	tabHosts[3]:SetTall(R(y)) ; host = tabHosts[4] ; y = 8

	-- ── POSSESSION (boss jouable) ──
	secLabel("POSSESSION : incarner un NPC (boss jouable)")
	local dd = vgui.Create("DButton", host) dd:SetText("")
	dd:SetPos(R(PADX), R(y)) dd:SetSize(R(INNER), R(36))
	dd.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.possessName or "Choisir un NPC à incarner…", "EVO_Anim_Btn", R(12), h / 2, state.possessName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	dd.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		OpenNpcDropdown(s, npcGroups(), function(n)
			state.possessClass, state.possessName = n.class, n.name
			state.possessHP, state.possessDMG = n.hp, n.dmg
			if IsValid(state.hpEntry)  then state.hpEntry:SetText(tostring(n.hp))   end
			if IsValid(state.dmgEntry) then state.dmgEntry:SetText(tostring(n.dmg)) end
		end, function() return state.possessClass end)
	end
	y = y + 44

	-- PV + Dégâts (côte à côte)
	local half = math.floor(INNER / 2) - 8
	-- PV bornés au PALIER : le serveur reclampe, l'UI ne doit pas proposer plus.
	local nPossHpMax = (EVO_ANIM and EVO_ANIM.HpMax and EVO_ANIM.HpMax(LocalPlayer())) or 10000
	local hpl = vgui.Create("DLabel", host) hpl:SetFont("EVO_Anim_Small") hpl:SetTextColor(col.muted)
	hpl:SetPos(R(PADX), R(y)) hpl:SetSize(R(half), R(16)) hpl:SetText("Points de vie (1 – " .. nPossHpMax .. ")")
	local dml = vgui.Create("DLabel", host) dml:SetFont("EVO_Anim_Small") dml:SetTextColor(col.muted)
	dml:SetPos(R(PADX + half + 16), R(y)) dml:SetSize(R(half), R(16)) dml:SetText("Dégâts/coup (0 – 200)")

	-- Pas de correction silencieuse : on mémorise les bornes (lo/hi) sur le champ ; le bouton
	-- « Posséder » REFUSE (notif) si la valeur est vide ou hors bornes (validation dure).
	local hpE = vgui.Create("DTextEntry", host) hpE:SetNumeric(true) hpE:SetFont("EVO_Anim_Small")
	hpE:SetPos(R(PADX), R(y + 18)) hpE:SetSize(R(half), R(26)) hpE:SetText(tostring(math.Clamp(state.possessHP or 1000, 1, nPossHpMax)))
	styleEntry(hpE) persistEntry(hpE, "possessHP") hpE._lo, hpE._hi = 1, nPossHpMax state.hpEntry = hpE
	local dmE = vgui.Create("DTextEntry", host) dmE:SetNumeric(true) dmE:SetFont("EVO_Anim_Small")
	dmE:SetPos(R(PADX + half + 16), R(y + 18)) dmE:SetSize(R(half), R(26)) dmE:SetText(tostring(math.Clamp(state.possessDMG or 100, 0, 200)))
	styleEntry(dmE) persistEntry(dmE, "possessDMG") dmE._lo, dmE._hi = 0, 200 state.dmgEntry = dmE
	y = y + 52

	-- Boutons Posséder / Revenir
	do
		local _, w = chip(host, "Posséder le NPC", PADX, y, col.accent, function()
			-- Refus = notif MUGEN (PAS le son button10). MUGEN.AddNotification est la SEULE API
			-- qui affiche réellement une notif (notification.AddLegacy est bridé hors de là).
			local function refuse(msg)
				if MUGEN and MUGEN.AddNotification then
					MUGEN.AddNotification(msg, NOTIFY_ERROR, 4)
				end
			end
			if not state.possessClass then return refuse("Choisis d'abord un NPC à posséder.") end
			local hp  = tonumber(state.hpEntry:GetValue())
			local dmg = tonumber(state.dmgEntry:GetValue())
			-- Validation DURE : valeurs vides ou hors bornes -> on REFUSE (pas de possession).
			if not hp  or hp  < 1 or hp  > nPossHpMax then return refuse("Points de vie invalides — entre 1 et " .. nPossHpMax .. ".") end
			if not dmg or dmg < 0 or dmg > 200   then return refuse("Dégâts invalides — entre 0 et 200.") end
			net.Start("EVO:Anim:Possess")
				net.WriteString(state.possessClass)
				net.WriteUInt(math.floor(hp),  24)
				net.WriteUInt(math.floor(dmg), 20)
			net.SendToServer()
		end)
		chip(host, "Revenir (humain)", PADX + w + 8, y, col.muted, function()
			net.Start("EVO:Anim:Unpossess") net.SendToServer()
		end)
		y = y + 44
	end

	-- ── HOLLOW (animation) — incarner une larve / Vasto Lorde / un personnage ──
	secLabel("HOLLOW (animation) : larve / Vasto Lorde / personnage")
	-- Dropdown art spirituel
	local ddArt = vgui.Create("DButton", host) ddArt:SetText("")
	ddArt:SetPos(R(PADX), R(y)) ddArt:SetSize(R(INNER), R(34))
	ddArt.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.animArtName or "Art spirituel…", "EVO_Anim_Btn", R(12), h / 2, state.animArtName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddArt.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		OpenChoiceDropdown(s, rerollChoices("art_spirituel"), function() return state.animArt end, function(it)
			state.animArt, state.animArtName = it.id, it.name
		end)
	end
	y = y + 40
	-- Dropdown style de combat
	local ddStyle = vgui.Create("DButton", host) ddStyle:SetText("")
	ddStyle:SetPos(R(PADX), R(y)) ddStyle:SetSize(R(INNER), R(34))
	ddStyle.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.animStyleName or "Style de combat…", "EVO_Anim_Btn", R(12), h / 2, state.animStyleName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddStyle.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		OpenChoiceDropdown(s, rerollChoices("style_de_combat"), function() return state.animStyle end, function(it)
			state.animStyle, state.animStyleName = it.id, it.name
		end)
	end
	y = y + 42

	-- PV + dégâts (côte à côte) — MÊME LOGIQUE que la possession NPC : bornes 1..10000 PV /
	-- 0..200 dégâts PAR COUP (dégât fixe, pas un multiplicateur), SAUF superadmin = champ libre.
	local isSAh = LocalPlayer():IsSuperAdmin()
	-- MÊME plafond que l'outil « Points de vie » : le palier borne les deux chemins.
	local nIncHpMax = (EVO_ANIM and EVO_ANIM.HpMax and EVO_ANIM.HpMax(LocalPlayer())) or 10000
	local hHpl = vgui.Create("DLabel", host) hHpl:SetFont("EVO_Anim_Small") hHpl:SetTextColor(col.muted)
	hHpl:SetPos(R(PADX), R(y)) hHpl:SetSize(R(half), R(16))
	hHpl:SetText(isSAh and "Points de vie (libre)" or ("Points de vie (1 – " .. nIncHpMax .. ")"))
	local hDml = vgui.Create("DLabel", host) hDml:SetFont("EVO_Anim_Small") hDml:SetTextColor(col.muted)
	hDml:SetPos(R(PADX + half + 16), R(y)) hDml:SetSize(R(half), R(16))
	hDml:SetText(isSAh and "Dégâts/coup (libre)" or "Dégâts/coup (0 – 200)")

	local hHpE = vgui.Create("DTextEntry", host) hHpE:SetNumeric(true) hHpE:SetFont("EVO_Anim_Small")
	hHpE:SetPos(R(PADX), R(y + 18)) hHpE:SetSize(R(half), R(26)) hHpE:SetText(tostring(state.animHP or 900))
	styleEntry(hHpE) persistEntry(hHpE, "animHP") state.animHpEntry = hHpE
	local hDmE = vgui.Create("DTextEntry", host) hDmE:SetNumeric(true) hDmE:SetFont("EVO_Anim_Small")
	hDmE:SetPos(R(PADX + half + 16), R(y + 18)) hDmE:SetSize(R(half), R(26)) hDmE:SetText(tostring(state.animDMG or 50))
	styleEntry(hDmE) persistEntry(hDmE, "animDMG") state.animDmgEntry = hDmE
	y = y + 52

	-- Boutons Devenir Hollow / Vasto / personnage / Revenir
	do
		-- sForm : "hollow", "vasto" ou une clé de ANIM_MODELS (sv_anim_hollow.lua). Ajouter un
		-- personnage = une entrée là-bas + un chip ici.
		local function becomeHollow(sForm)
			local function refuse(msg) if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(msg, NOTIFY_ERROR, 4) end end
			if not state.animArt   then return refuse("Choisis un art spirituel.") end
			if not state.animStyle then return refuse("Choisis un style de combat.") end
			-- Validation DURE des PV/dégâts (comme « Posséder »). Superadmin = pas de borne haute.
			local isSA = LocalPlayer():IsSuperAdmin()
			local hp  = tonumber(IsValid(state.animHpEntry)  and state.animHpEntry:GetValue())
			local dmg = tonumber(IsValid(state.animDmgEntry) and state.animDmgEntry:GetValue())
			if not hp  or hp  < 1 or (not isSA and hp  > nIncHpMax) then return refuse(isSA and "Points de vie invalides (≥ 1)." or ("Points de vie invalides — entre 1 et " .. nIncHpMax .. ".")) end
			if not dmg or dmg < 0 or (not isSA and dmg > 200)   then return refuse(isSA and "Dégâts invalides (≥ 0)."     or "Dégâts invalides — entre 0 et 200.") end
			net.Start("EVO:AnimHollow:Become")
				net.WriteString(sForm)
				net.WriteString(state.animArt)
				net.WriteString(state.animStyle)
				net.WriteUInt(math.Clamp(math.floor(hp),  1, 16777215), 24) -- borne = largeur réseau (anti-overflow, pas une limite de jeu)
				net.WriteUInt(math.Clamp(math.floor(dmg), 0, 1048575),  20)
			net.SendToServer()
		end
		local _, w1 = chip(host, "Devenir Hollow (aléatoire)", PADX, y, col.accent, function() becomeHollow("hollow") end)
		chip(host, "Devenir Vasto Lorde", PADX + w1 + 8, y, col.accent, function() becomeHollow("vasto") end)
		y = y + 38
		local _, w2 = chip(host, "Devenir Urahara", PADX, y, col.accent, function() becomeHollow("urahara") end)
		chip(host, "Tenue civile", PADX + w2 + 8, y, col.accent, function() becomeHollow("civil") end)
		y = y + 38
		local _, w3 = chip(host, "Devenir Âme errante", PADX, y, col.accent, function() becomeHollow("ame") end)
		chip(host, "Revenir (humain)", PADX + w3 + 8, y, col.muted, function() net.Start("EVO:AnimHollow:Revert") net.SendToServer() end)
		y = y + 42
	end
	local hhint = vgui.Create("DLabel", host) hhint:SetFont("EVO_Anim_Small") hhint:SetTextColor(col.dim)
	hhint:SetPos(R(PADX), R(y)) hhint:SetSize(R(INNER), R(44)) hhint:SetWrap(true)
	hhint:SetText("Choisis art + style + PV/dégâts (commun→épique & bornes du palier ; tout libre pour les superadmins), puis transforme-toi. L'équipement n'a plus de limite de faction/genre. NB : chaque forme garde sa PROPRE apparence (son visage compris), elle ne montre ni ta tête ni tes tenues.")
	y = y + 50

	-- ════════ Fin onglet INCARNER → bascule vers OUTILS ════════
	tabHosts[4]:SetTall(R(y)) ; host = tabHosts[5] ; y = 8

	-- ── RÉIATSU (self-give) — utile en hollow/vasto pour lancer des sorts ──
	secLabel("RÉIATSU (self-give)")
	local isSAr = LocalPlayer():IsSuperAdmin()
	local rReiL = vgui.Create("DLabel", host) rReiL:SetFont("EVO_Anim_Small") rReiL:SetTextColor(col.muted)
	rReiL:SetPos(R(PADX), R(y)) rReiL:SetSize(R(INNER), R(16))
	rReiL:SetText(isSAr and "Réiatsu (libre)" or "Réiatsu (0 - 1000000)")
	local rReiE = vgui.Create("DTextEntry", host) rReiE:SetNumeric(true) rReiE:SetFont("EVO_Anim_Small")
	rReiE:SetPos(R(PADX), R(y + 18)) rReiE:SetSize(R(half), R(26))
	rReiE:SetText(tostring(state.reiatsuVal or LocalPlayer():GetEvoNWInt("MaxReiatsu", 100)))
	styleEntry(rReiE) persistEntry(rReiE, "reiatsuVal")
	y = y + 52
	chip(host, "Se donner ce reiatsu", PADX, y, col.green, function()
		local n = tonumber(IsValid(rReiE) and rReiE:GetValue())
		if not n or n < 0 or (not isSAr and n > 1000000) then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(isSAr and "Reiatsu invalide (>= 0)." or "Reiatsu invalide - entre 0 et 1000000.", NOTIFY_ERROR, 4) end
			return
		end
		net.Start("EVO:AnimTools:Reiatsu")
			net.WriteUInt(math.Clamp(math.floor(n), 0, 4294967295), 32) -- borne = largeur reseau (le clamp serveur est la vraie garde)
		net.SendToServer()
	end)
	y = y + 38
	local rReiH = vgui.Create("DLabel", host) rReiH:SetFont("EVO_Anim_Small") rReiH:SetTextColor(col.dim)
	rReiH:SetPos(R(PADX), R(y)) rReiH:SetSize(R(INNER), R(34)) rReiH:SetWrap(true)
	rReiH:SetText("Fixe ton reiatsu courant + max (indispensable en hollow/vasto pour caster). Non persistant : re-donne apres un respawn / changement de stats.")
	y = y + 40

	-- ── POINTS DE VIE (self-give) — l'équivalent animateur du `sethp` SAM (superadmin) ──
	secLabel("POINTS DE VIE (self-give)")
	local isSAh2 = LocalPlayer():IsSuperAdmin()
	-- Plafond PV du PALIER (miroir du clamp serveur, partagé avec l'incarnation).
	local nHpMax = (EVO_ANIM and EVO_ANIM.HpMax and EVO_ANIM.HpMax(LocalPlayer())) or 10000
	local rHpL = vgui.Create("DLabel", host) rHpL:SetFont("EVO_Anim_Small") rHpL:SetTextColor(col.muted)
	rHpL:SetPos(R(PADX), R(y)) rHpL:SetSize(R(INNER), R(16))
	rHpL:SetText(isSAh2 and "Points de vie (libre)" or ("Points de vie (1 – " .. nHpMax .. ")"))
	local rHpE = vgui.Create("DTextEntry", host) rHpE:SetNumeric(true) rHpE:SetFont("EVO_Anim_Small")
	rHpE:SetPos(R(PADX), R(y + 18)) rHpE:SetSize(R(half), R(26))
	rHpE:SetText(tostring(state.hpVal or LocalPlayer():GetMaxHealth()))
	styleEntry(rHpE) persistEntry(rHpE, "hpVal")
	y = y + 52
	local _, wHp = chip(host, "Se donner ces PV", PADX, y, col.green, function()
		local n = tonumber(IsValid(rHpE) and rHpE:GetValue())
		if not n or n < 1 or (not isSAh2 and n > nHpMax) then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(isSAh2 and "PV invalides (>= 1)." or ("PV invalides - entre 1 et " .. nHpMax .. "."), NOTIFY_ERROR, 4) end
			return
		end
		net.Start("EVO:AnimTools:HP")
			net.WriteUInt(math.Clamp(math.floor(n), 1, 16777215), 24) -- borne = largeur reseau (le clamp serveur est la vraie garde)
		net.SendToServer()
	end)
	-- 0 = code de RETOUR aux PV normaux côté serveur (pas une valeur de PV).
	chip(host, "PV normaux", PADX + wHp + 8, y, col.muted, function()
		net.Start("EVO:AnimTools:HP") net.WriteUInt(0, 24) net.SendToServer()
	end)
	y = y + 38
	local rHpH = vgui.Create("DLabel", host) rHpH:SetFont("EVO_Anim_Small") rHpH:SetTextColor(col.dim)
	rHpH:SetPos(R(PADX), R(y)) rHpH:SetSize(R(INNER), R(34)) rHpH:SetWrap(true)
	rHpH:SetText("Fixe tes PV max ET courants (tu repars vie pleine). Survit a l'equipement et au respawn ; « PV normaux » te rend exactement la vie que tu avais.")
	y = y + 40

	-- ── TAILLE DU PERSONNAGE (self-scale 0.8 - 1.4) ──
	-- Réutilise le net EVO:AnimTools:Scale (sv_anim_tools) ; la surbrillance verte = taille à
	-- l'OUVERTURE du menu (le perso se redimensionne visiblement au clic).
	-- Plafond PAR PALIER (le Gérant monte à ×2) : mêmes valeurs que le clamp serveur.
	local nScaleMin = (EVO_ANIM and EVO_ANIM.SCALE_MIN) or 0.8
	local nScaleMax = (EVO_ANIM and EVO_ANIM.ScaleMax and EVO_ANIM.ScaleMax(LocalPlayer())) or 1.4
	secLabel(string.format("TAILLE DU PERSONNAGE (×%.1f – ×%.1f)", nScaleMin, nScaleMax))
	do
		-- Sélection OPTIMISTE client (state.scaleSel) : le fill du chip est une FONCTION relue
		-- chaque frame -> la surbrillance verte suit le clic INSTANTANÉMENT (le scale réel
		-- s'applique en // via le net, avec son lissage 0.2 s serveur). Init = scale courant.
		state.scaleSel = LocalPlayer():GetModelScale() or 1
		-- Palier de 0,1 jusqu'au plafond : la liste s'allonge toute seule pour le Gérant.
		local steps = {}
		for sc = nScaleMin, nScaleMax + 0.001, 0.1 do steps[#steps + 1] = math.Round(sc, 1) end
		local x = PADX
		for _, sc in ipairs(steps) do
			local _, w = chip(host, string.format("×%.1f", sc), x, y, function()
				return (math.abs((state.scaleSel or 1) - sc) < 0.05) and col.green or col.accent
			end, function()
				state.scaleSel = sc
				net.Start("EVO:AnimTools:Scale") net.WriteFloat(sc) net.SendToServer()
			end)
			x = x + w + 8
			if x > CARD_W - 120 then x = PADX y = y + 38 end
		end
		y = y + 42
	end

	-- ── MODÉRATION (téléportation, message mj_plus & spectate) ──
	-- Sélecteur de joueur par NOM RP (NWString Nickname). Le serveur (EVO:AnimTools:Nav)
	-- re-gate animateur, ignore soi-même / les superadmins, et gère Aller à / TP / Renvoyer /
	-- spectate. Message = mj_plus seulement (EVO:AnimTools:Msg, même rendu que le dashboard).
	secLabel("MODÉRATION : téléportation & spectate")
	local ddM = vgui.Create("DButton", host) ddM:SetText("")
	ddM:SetPos(R(PADX), R(y)) ddM:SetSize(R(INNER), R(36))
	ddM.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.modTargetName or "Choisir un joueur…", "EVO_Anim_Btn", R(12), h / 2, state.modTargetName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddM.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		local items = {}
		for _, p in player.Iterator() do
			if IsValid(p) and p ~= LocalPlayer() and not p:IsSuperAdmin() then
				local nm = p:GetEvoNWString("Nickname", "")
				if nm == "" then nm = p:Nick() end
				items[#items + 1] = { id = p:SteamID64(), name = nm, rarity = "" }
			end
		end
		if #items == 0 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Aucun joueur ciblable.", NOTIFY_ERROR, 3) end
			return
		end
		table.sort(items, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
		OpenChoiceDropdown(s, items, function() return state.modTargetSid end, function(it)
			state.modTargetSid, state.modTargetName = it.id, it.name
		end)
	end
	y = y + 44

	do
		local function sendNav(action)
			if not state.modTargetSid then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Choisis d'abord un joueur dans la liste.", NOTIFY_ERROR, 4) end
				return
			end
			net.Start("EVO:AnimTools:Nav") net.WriteString(action) net.WriteString(state.modTargetSid) net.SendToServer()
		end
		local x = PADX
		local actions = {
			{ "goto",     "Aller à",    col.accent },
			{ "bring",    "TP sur moi", col.accent },
			{ "return",   "Renvoyer",   col.muted },
			{ "spectate", "Spectate",   col.green },
		}
		for _, a in ipairs(actions) do
			local _, w = chip(host, a[2], x, y, a[3], function() sendNav(a[1]) end)
			x = x + w + 8
			if x > CARD_W - 120 then x = PADX y = y + 38 end
		end
		-- Message plein écran : mj_plus (et SA de test). Même prompt / rendu que le dashboard F8.
		local lp = LocalPlayer()
		local bMsg = IsValid(lp) and (lp:IsSuperAdmin() or (EVO_IsMJPlus and EVO_IsMJPlus(lp)))
		if bMsg then
			local _, w = chip(host, "Message", x, y, col.accent, function()
				if not state.modTargetSid then
					if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Choisis d'abord un joueur dans la liste.", NOTIFY_ERROR, 4) end
					return
				end
				local function sendMsg(txt, dura)
					txt = string.Trim(tostring(txt or ""))
					if txt == "" then return end
					net.Start("EVO:AnimTools:Msg")
						net.WriteString(state.modTargetSid)
						net.WriteString(string.sub(txt, 1, 200))
						net.WriteUInt(math.Clamp(math.floor(tonumber(dura) or 6), 3, 30), 8)
					net.SendToServer()
				end
				if EVO_StaffPrompt then
					EVO_StaffPrompt("Message à l'écran", {
						{ label = "Message (affiché plein écran chez le joueur)", default = "" },
						{ label = "Durée en secondes (3-30)", default = "6", numeric = true },
					}, sendMsg)
				else
					Derma_StringRequest("Message à l'écran", "Texte affiché chez le joueur :", "", function(txt) sendMsg(txt, 6) end)
				end
			end)
			x = x + w + 8
			if x > CARD_W - 120 then x = PADX y = y + 38 end
		end
		y = y + 38
		chip(host, "Arrêter le spectate", PADX, y, col.muted, function()
			net.Start("EVO:AnimTools:Nav") net.WriteString("unspectate") net.WriteString("") net.SendToServer()
		end)
		y = y + 44
	end

	local hint = vgui.Create("DLabel", host) hint:SetFont("EVO_Anim_Small") hint:SetTextColor(col.dim)
	hint:SetPos(R(PADX), R(y)) hint:SetSize(R(INNER), R(34)) hint:SetWrap(true) hint:SetContentAlignment(7)
	hint:SetText("Possession : règle PV/dégâts puis « Posséder ». Clic G = attaque · Clic D = lourde · R = skill. PV à 0 = retour humain.")
	y = y + 40

	-- Hauteur réelle du contenu -> le DScrollPanel affiche une barre si ça dépasse le viewport.
	-- ── TÉLÉCOMMUNICATION (user 08/24) : radio forcée vers UN joueur ──
	secLabel("TÉLÉCOMMUNICATION : parler à un seul joueur (radio forcée)")
	local tlHint = vgui.Create("DLabel", host) tlHint:SetFont("EVO_Anim_Small") tlHint:SetTextColor(col.dim)
	tlHint:SetPos(R(PADX), R(y)) tlHint:SetSize(R(INNER), R(32)) tlHint:SetWrap(true)
	tlHint:SetText("Liaison ouverte = ta voix n'est entendue QUE par ce joueur, où qu'il soit, et tu l'entends de partout. Il continue de parler normalement autour de lui.")
	y = y + 36
	local ddTl = vgui.Create("DButton", host) ddTl:SetText("")
	ddTl:SetPos(R(PADX), R(y)) ddTl:SetSize(R(INNER), R(34))
	ddTl.Paint = function(s, w, h)
		local open = IsValid(s._pop)
		RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, 14))
		RNDX.DrawOutlined(R(7), 0, 0, w, h, ColorAlpha(open and col.accent or col.border, open and 150 or 60), 1.5)
		draw.SimpleText(state.telecomPickName or "Choisir un joueur…", "EVO_Anim_Btn", R(12), h / 2, state.telecomPickName and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(open and "▴" or "▾", "EVO_Anim_Btn", w - R(18), h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ddTl.DoClick = function(s)
		if IsValid(s._pop) then s._pop:Remove() s._pop = nil return end
		local lp = LocalPlayer()
		local items = {}
		for _, p in player.Iterator() do
			if IsValid(p) and p ~= lp then
				local nm = p:GetEvoNWString("Nickname", "") ; if nm == "" then nm = p:Nick() end
				items[#items + 1] = { id = p:SteamID64(), name = nm }
			end
		end
		if #items == 0 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Aucun autre joueur en ligne.", NOTIFY_ERROR, 3) end
			return
		end
		table.sort(items, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
		OpenChoiceDropdown(s, items, function() return state.telecomPickSid end, function(it)
			state.telecomPickSid, state.telecomPickName = it.id, it.name
		end)
	end
	y = y + 40
	local tlBtn = vgui.Create("DButton", host) tlBtn:SetText("")
	tlBtn:SetPos(R(PADX), R(y)) tlBtn:SetSize(R(INNER), R(36))
	tlBtn.Paint = function(s, w, h)
		local on = state.telecomSid ~= nil
		RNDX.Draw(R(9), 0, 0, w, h, ColorAlpha(on and col.green or color_white, on and 230 or 10))
		if not on then RNDX.DrawOutlined(R(9), 0, 0, w, h, ColorAlpha(col.border, 40), 1) end
		draw.SimpleText(on and ("LIAISON OUVERTE avec " .. (state.telecomName or "?") .. " : clique pour COUPER")
			or "OUVRIR LA LIAISON avec le joueur choisi", "EVO_Anim_Btn", w / 2, h / 2, on and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	tlBtn.DoClick = function()
		local on = state.telecomSid ~= nil
		if not on and not state.telecomPickSid then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Choisis d'abord un joueur dans la liste.", NOTIFY_ERROR, 3) end
			return
		end
		net.Start("EVO:Anim:Telecom")
			net.WriteString(on and "" or state.telecomPickSid)
		net.SendToServer()
	end
	y = y + 44

	-- ── SALLE BLANCHE (evo_blanc) : blocs blancs, endormissement, rituel des lames ──
	-- Palier 2+ uniquement (jamais le Testé, le bloc est visible par TOUT le
	-- serveur). Le serveur revalide de toute façon (PeutGerer, sv_blanc).
	if ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(LocalPlayer())) or 0) >= 2 then
		secLabel("SALLE BLANCHE")
		chip(host, "Ouvrir la gestion des blocs blancs", PADX, y, col.accent, function()
			RunConsoleCommand("evo_blanc")
		end)
		y = y + 38
		local sbH = vgui.Create("DLabel", host) sbH:SetFont("EVO_Anim_Small") sbH:SetTextColor(col.dim)
		sbH:SetPos(R(PADX), R(y)) sbH:SetSize(R(INNER), R(34)) sbH:SetWrap(true)
		sbH:SetText("Poser et régler les blocs blancs, endormir et ramener les joueurs, planter les lames du rituel. Le même panneau que celui des superadmins.")
		y = y + 40
	end

	host:SetTall(R(y))
end

function EVO_OpenAnim()
	MakeFonts()
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	if IsValid(pAnim) then pAnim:Remove() end
	local col = C()
	local CARD_W, CARD_H = 660, 740
	local cardW, cardH = R(CARD_W), R(CARD_H)

	pAnim = vgui.Create("DFrame")
	pAnim:SetSize(ScrW(), ScrH()) pAnim:SetPos(0, 0)
	pAnim:SetTitle("") pAnim:ShowCloseButton(false) pAnim:SetDraggable(false)
	pAnim:SetPaintBackgroundEnabled(false) pAnim:MakePopup()
	-- Fermeture standard du projet :
	--  • Échap : globale openedFrame -> fermée par le hook OnPauseMenuShow de lzy_escape_menu.
	--  • Re-appui sur la touche du bind "animateur_ui" : poll dans Think (focus-indépendant,
	--    car PlayerButtonDown est SUPPRIMÉ quand un menu a le focus).
	openedFrame = pAnim
	pAnim._a = 0
	pAnim._opened = false
	timer.Simple(0.3, function() if IsValid(pAnim) then pAnim._opened = true end end) -- évite que l'appui d'OUVERTURE referme
	pAnim._keyDown = false
	pAnim.Think = function(s)
		s._a = Lerp(FrameTime() * 12, s._a, 255)
		local lp = LocalPlayer()
		local k = (IsValid(lp) and lp.GetBindKey) and lp:GetBindKey("animateur_ui") or 0
		if k ~= 0 then
			local down = input.IsButtonDown(k)
			if down and not s._keyDown and s._opened then s:Remove() return end -- front montant = ferme
			s._keyDown = down
		end
	end
	pAnim.OnRemove = function(self)
		if openedFrame == self then openedFrame = nil end
		animClosedAt = SysTime() -- debounce anti-réouverture (PlayerButtonDown)
	end
	pAnim.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		-- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * a) surface.DrawRect(0, 0, w, h)
	end
	pAnim.OnMousePressed = function() if IsValid(pAnim) then pAnim:Remove() end end

	local card = vgui.Create("DPanel", pAnim)
	card:SetSize(cardW, cardH) card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (pAnim and pAnim._a or 255) / 255
		-- Plaque de métal noir Atelier : coins coupés + liseré acier + vis,
		-- titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
		EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250 * a), R(16))
		-- DA dashboard 08/07 : plaque plate, plus de lisere acier.
		local sr = R(5)
		drawScrew(R(18), R(18), sr)
		drawScrew(w - R(18), R(18), sr)
		drawScrew(w - R(18), h - R(18), sr)
		drawScrew(R(18), h - R(18), sr)
		draw.SimpleText("ANIMATEUR", "EVO_Anim_Title", R(22), R(26), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("EVO_Anim_Title")
		local twT, thT = surface.GetTextSize("ANIMATEUR")
		-- Titre CENTER-aligné vertical à Y=R(26) -> haut = R(26) - thT/2 ; slash à 78% de la
		-- hauteur MESURÉE = R(26) + thT*0.28 (même relation que le titre BOUTIQUE de la boutique).
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(26) + thT * 0.28, twT * 1.15, R(9), ColorAlpha(col.accent, 245 * a)) then
			surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
			surface.DrawRect(R(22), R(26) + thT * 0.34, twT, math.max(2, R(3)))
		end
		drawDashes(R(24), R(60), w - R(48), Color(255, 255, 255, 26 * a))
	end
	state.card = card -- mémorisé pour reconstruire le corps quand la liste "mes entités" change

	buildBody(card, CARD_W)

	-- CROIX créée APRÈS buildBody : le panel `host` de buildBody recouvre toute la carte
	-- avec l'input souris activé ; créé après la croix, il la masquait et captait son clic
	-- (= la croix ne fermait pas). En la créant en dernier, elle est au-dessus -> cliquable.
	local x = vgui.Create("DButton", card) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(CARD_W - 42), R(19))
	x:SetZPos(1000) -- TOUJOURS au-dessus de `host` (même après un rebuild de buildBody) -> cliquable
	x:SetCursor("hand")
	x.Paint = function(s, w, h)
		-- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() if IsValid(pAnim) then pAnim:Remove() end end
end

net.Receive("EVO:Anim:Open", function()
	state.chests = net.ReadTable() or {}
	state.bosses = net.ReadTable() or {}
	state.used   = net.ReadUInt(8)
	state.max    = net.ReadUInt(8)
	local _ = net.ReadBool() -- mode (lu live via NWBool)
	state.myEnts = net.ReadTable() or {}
	local sTlSid, sTlName = net.ReadString(), net.ReadString()
	state.telecomSid  = sTlSid ~= "" and sTlSid or nil
	state.telecomName = sTlSid ~= "" and sTlName or nil
	EVO_OpenAnim()
end)

-- Liste "mes entités" mise à jour (après spawn / suppression) -> on reconstruit le corps.
net.Receive("EVO:Anim:MyEntities", function()
	state.myEnts = net.ReadTable() or {}
	if IsValid(state.card) then buildBody(state.card, 660) end
end)

net.Receive("EVO:Anim:Quota", function()
	state.used = net.ReadUInt(8)
	state.max  = net.ReadUInt(8)
	if IsValid(state.quotaLbl) then state.quotaLbl:SetText("COFFRES : " .. state.used .. "/" .. state.max .. " (par 2h)") end
end)

-- ── UI flottante des coffres déposés (même style que les items au sol cl_drop.lua) ──
-- Marqueurs posés serveur : NWBool "NCM_AnimChestDropped" + NWString "NCM_AnimChestLabel".
local CHEST_HINT_RANGE = 150 -- portée d'affichage du "Appuyez sur …" (≈ portée de ramassage serveur)
-- Même touche affichée que les items au sol : la fonction OFFICIELLE de l'inventaire
-- (input.LookupBinding("+use"), fallback "E"). Le ramassage est aussi sur IN_USE -> cohérent.
local function chestUseKey()
	return (LZY_INVENTORY_GetUseKeyDisplay and LZY_INVENTORY_GetUseKeyDisplay()) or "E"
end

local function drawChestLabel(ent, label)
	if not isstring(label) or label == "" then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	local t = CurTime()
	local phase = ent:EntIndex() * 0.37
	local bob = math.sin(t * 2.6 + phase) * 7 + math.sin(t * 1.22 + phase * 1.3) * 1.6

	local rad = ent:BoundingRadius()
	if not rad or rad < 1 then local sz = ent:OBBMaxs() - ent:OBBMins() rad = sz:Length() * 0.5 end
	local p = ent:GetPos()
	local top = Vector(p.x, p.y, p.z + rad + 8 + bob)

	local sway = math.sin(t * 1.9 + phase * 0.8) * 4
	-- Billboard FACE À LA CAMÉRA via EyePos() (PAS les yeux du joueur) : reste lisible même
	-- avec la cam orbitale quand on tourne juste la caméra sans bouger. Cf flag billboard.
	local ang = Angle(0, (top - EyePos()):Angle().y - 90, 90 + sway)
	local scale = 0.12 * (1 + math.sin(t * 2.2 + phase) * 0.06)

	local inRange = lp:Alive() and ent:GetPos():DistToSqr(lp:GetPos()) <= CHEST_HINT_RANGE * CHEST_HINT_RANGE
	if EVO_ZonePrompt and EVO_ZonePrompt.Row then
		-- Style invite partage : nom, touche + « Ramasser » a portee.
		cam.Start3D2D(top, ang, scale)
			EVO_ZonePrompt.Row(-60, label, inRange and "Ramasser", inRange and chestUseKey() or "E", "coffre")
		cam.End3D2D()
		return
	end
	local hint = inRange and ("Appuyez sur " .. chestUseKey() .. " pour ramasser") or nil

	cam.Start3D2D(top, ang, scale)
		surface.SetFont("Inter:56")
		local _, nameH = surface.GetTextSize(label)
		if hint then
			local hy = -nameH - 10
			for _, d in ipairs({ {-1,-1},{1,-1},{-1,1},{1,1},{0,-1},{0,1},{-1,0},{1,0} }) do
				draw.SimpleText(hint, "Inter:36", d[1], hy + d[2], Color(0,0,0,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			end
			draw.SimpleText(hint, "Inter:36", 0, hy, Color(200,220,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end
		for _, d in ipairs({ {-2,-2},{0,-2},{2,-2},{-2,0},{2,0},{-2,2},{0,2},{2,2} }) do
			draw.SimpleText(label, "Inter:56", d[1], d[2], Color(0,0,0,220), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end
		draw.SimpleText(label, "Inter:56", 0, 0, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	cam.End3D2D()
end

-- Scan throttlé (~4x/s) comme cl_drop.lua : on ne FindInSphere pas chaque frame.
local CHEST_SCAN_INTERVAL = 0.25
local nNextChestScan = 0
local tCachedChests = {}
hook.Add("PostDrawTranslucentRenderables", "EVO_Anim::ChestLabels", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local maxDist, lpPos = 900, lp:GetPos()
	local now = CurTime()
	if now >= nNextChestScan then
		nNextChestScan = now + CHEST_SCAN_INTERVAL
		tCachedChests = {}
		for _, e in ipairs(ents.FindInSphere(lpPos, maxDist + 200)) do
			if IsValid(e) and e:GetEvoNWBool("NCM_AnimChestDropped", false) then
				tCachedChests[#tCachedChests + 1] = e
			end
		end
	end
	if #tCachedChests == 0 then return end
	local maxDistSq = maxDist * maxDist
	for i = 1, #tCachedChests do
		local e = tCachedChests[i]
		if IsValid(e) and e:GetEvoNWBool("NCM_AnimChestDropped", false) and e:GetPos():DistToSqr(lpPos) <= maxDistSq then
			drawChestLabel(e, e:GetEvoNWString("NCM_AnimChestLabel", "Coffre"))
		end
	end
end)

-- ── TÉLÉCOMMUNICATION : état live (bouton du menu) + indicateur HUD des deux côtés ──
-- Texte du HUD calculé UNE fois à la réception (zéro concat par frame).
local TELECOM = { on = false, txt = "" }
local COL_TL_BG = Color(14, 14, 17, 225)
net.Receive("EVO:Anim:TelecomState", function()
	local bOn, bCaller = net.ReadBool(), net.ReadBool()
	local sSid, sName = net.ReadString(), net.ReadString()
	if bCaller then
		state.telecomSid  = bOn and sSid or nil
		state.telecomName = bOn and sName or nil
	end
	TELECOM.on = bOn
	-- Côté cible : aucune mention de télécom ni d'animateur (user 08/24), juste du RP.
	TELECOM.txt = bCaller and ("TÉLÉCOM → " .. sName .. " (ta voix ne va qu'à lui)")
		or "Tu entends une voix dans ta tête…"
end)

hook.Add("HUDPaint", "EVO_Anim::TelecomHUD", function()
	if not TELECOM.on then return end
	local col = C()
	surface.SetFont("EVO_Anim_H")
	local tw, th = surface.GetTextSize(TELECOM.txt)
	local w, h = tw + R(34), th + R(14)
	local x, y = math.floor((ScrW() - w) / 2), math.floor(ScrH() * 0.10)
	RNDX.Draw(R(8), x, y, w, h, COL_TL_BG)
	RNDX.Draw(R(3), x + R(10), y + h / 2 - R(5), R(10), R(10), col.accent)
	draw.SimpleText(TELECOM.txt, "EVO_Anim_H", x + R(26), y + h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)
