-- "addons\\evo_animateur\\lua\\autorun\\client\\cl_anim_tournoi.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ANIMATEUR — TOURNOI (client).
--   • Popup d'invitation (callback lzy_popup "EVO_TourneyJoin").
--   • Panneau de contrôle de l'organisateur : inscriptions -> combats -> vainqueur.
-- L'organisateur clique le GAGNANT de chaque combat ; le bracket avance tout seul.
-- ============================================================================
if not CLIENT then return end

EVO_AnimTourney = EVO_AnimTourney or {}
local CL = EVO_AnimTourney

surface.CreateFont("EVO_Tr_H",   { font = "Bebas Neue", size = 28, weight = 700, antialias = true, extended = true })
surface.CreateFont("EVO_Tr_Big", { font = "Roboto", size = 30, weight = 800, antialias = true, extended = true })
surface.CreateFont("EVO_Tr_Lbl", { font = "Roboto", size = 18, weight = 500, antialias = true, extended = true })
surface.CreateFont("EVO_Tr_Btn", { font = "Roboto", size = 17, weight = 600, antialias = true, extended = true })

local COL_BG    = Color(14, 14, 17)
local COL_ACC   = Color(207, 68, 78)
local COL_TITLE = Color(235, 235, 240)
local COL_MUTED = Color(150, 150, 160)
local COL_GREEN = Color(90, 200, 120)
local COL_FAM   = Color(224, 120, 200)
local COL_GREY  = Color(70, 70, 80)

-- Invitation : le serveur envoie un popup Oui/Non (lzy_popup) avec ce callback.
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.EVO_TourneyJoin = function()
    net.Start("EVO:Tourney:Join") net.SendToServer()
end

local function trunc(s, n) s = tostring(s or "") return #s > n and (string.sub(s, 1, n - 1) .. "…") or s end

local pPanel
local function mkbtn(parent, label, x, y, w, h, fill, fn)
    local b = vgui.Create("DButton", parent) b:SetText("") b:SetPos(x, y) b:SetSize(w, h)
    b.Paint = function(s, ww, hh)
        -- DA : aplat coin bas-droit coupé (plus d'arrondi)
        local c = fill or COL_ACC
        local cc = s:IsHovered() and Color(c.r, c.g, c.b, 255) or Color(c.r, c.g, c.b, 215)
        if EVO_UI and EVO_UI.PaintCut then
            EVO_UI.PaintCut(0, 0, ww, hh, cc, 8, "br")
        else
            draw.RoundedBox(0, 0, 0, ww, hh, cc)
        end
        draw.SimpleText(label, "EVO_Tr_Btn", ww / 2, hh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = fn
    return b
end

local function rebuild()
    if not IsValid(pPanel) then return end
    -- NE PAS faire pPanel:Clear() : sur un DFrame, ça détruit AUSSI ses panels internes (titre,
    -- croix, min/max) et DFrame:PerformLayout plante ensuite ("Tried to use a NULL Panel" sur
    -- SetPos, en boucle). On retire donc UNIQUEMENT nos propres boutons.
    pPanel._btns = pPanel._btns or {}
    for _, b in ipairs(pPanel._btns) do if IsValid(b) then b:Remove() end end
    pPanel._btns = {}
    local function add(b) if b then pPanel._btns[#pPanel._btns + 1] = b end return b end

    local d = CL.data or {}
    local w, h = pPanel:GetWide(), pPanel:GetTall()
    local by = h - 54

    -- Croix de fermeture (ne touche pas au tournoi côté serveur).
    add(mkbtn(pPanel, "X", w - 40, 12, 28, 28, COL_GREY, function() if IsValid(pPanel) then pPanel:Remove() end end))

    if d.phase == "reg" then
        add(mkbtn(pPanel, "Relancer les invites", 18, by, 198, 40, COL_ACC, function() net.Start("EVO:Tourney:Invite") net.SendToServer() end))
        add(mkbtn(pPanel, "Démarrer", 224, by, 118, 40, COL_GREEN, function() net.Start("EVO:Tourney:Start") net.SendToServer() end))
        add(mkbtn(pPanel, "Annuler", 350, by, 92, 40, COL_GREY, function() net.Start("EVO:Tourney:Cancel") net.SendToServer() end))
    elseif d.phase == "running" then
        add(mkbtn(pPanel, "Gagnant : " .. trunc(d.a, 14), 18, by, 205, 40, COL_GREEN, function() net.Start("EVO:Tourney:Winner") net.WriteBool(true) net.SendToServer() end))
        add(mkbtn(pPanel, "Gagnant : " .. trunc(d.b, 14), 237, by, 205, 40, COL_GREEN, function() net.Start("EVO:Tourney:Winner") net.WriteBool(false) net.SendToServer() end))
    elseif d.phase == "done" then
        add(mkbtn(pPanel, "Fermer", (w - 130) / 2, by, 130, 40, COL_ACC, function() if IsValid(pPanel) then pPanel:Remove() end end))
    end
end

local function makePanel()
    if IsValid(pPanel) then pPanel:Remove() end
    pPanel = vgui.Create("DFrame")
    pPanel:SetSize(460, 370) pPanel:Center()
    pPanel:SetTitle("") pPanel:ShowCloseButton(false) pPanel:SetDraggable(true)
    pPanel:MakePopup() pPanel:SetKeyboardInputEnabled(false)
    if EVO_MakeEscClosable then EVO_MakeEscClosable(pPanel) end
    pPanel.Paint = function(s, w, h)
        -- DA « Seireitei » : carte du kit (coins coupés + liseré + seigaiha),
        -- titre Bebas signé par l'entaille (plus d'arrondi ni de barre accent).
        if EVO_UI and EVO_UI.PaintCard then
            EVO_UI.PaintCard(w, h, 1, 12)
        else
            draw.RoundedBox(0, 0, 0, w, h, COL_BG)
        end
        local d = CL.data or {}
        local famTour = d.type == "famille"
        local titre = "TOURNOI " .. (famTour and "DE CLANS" or "PvP")
        draw.SimpleText(titre, "EVO_Tr_H", 18, 14, famTour and COL_FAM or COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        if EVO_UI and EVO_UI.Ink then
            surface.SetFont("EVO_Tr_H")
            local tw, th = surface.GetTextSize(titre)
            EVO_UI.Ink(EVO_UI.TexSlash, 16, 14 + th * 0.78, tw * 1.25, 9, ColorAlpha(famTour and COL_FAM or COL_ACC, 245))
        end
        if d.phase == "reg" then
            draw.SimpleText("Inscriptions ouvertes : invite les joueurs, puis Démarrer.", "EVO_Tr_Lbl", 18, 52, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            local txt = (d.players or 0) .. " inscrit(s)" .. (famTour and ("  ·  " .. (d.fams or 0) .. " clan(s)") or "")
            draw.SimpleText(txt, "EVO_Tr_Lbl", 18, 76, COL_GREEN, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            -- Liste des joueurs inscrits.
            local names = d.names or {}
            if #names == 0 then
                draw.SimpleText("Personne pour l'instant…", "EVO_Tr_Lbl", 22, 104, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            else
                local maxShow = 9
                for i = 1, math.min(#names, maxShow) do
                    draw.SimpleText("• " .. names[i], "EVO_Tr_Btn", 22, 102 + (i - 1) * 20, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
                if #names > maxShow then
                    draw.SimpleText("+ " .. (#names - maxShow) .. " autre(s)…", "EVO_Tr_Btn", 22, 102 + maxShow * 20, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
            end
        elseif d.phase == "running" then
            draw.SimpleText("Manche " .. (d.round or 1) .. " : clique le vainqueur du combat :", "EVO_Tr_Lbl", 18, 56, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText(d.a ~= "" and d.a or "?", "EVO_Tr_Big", w / 2, 118, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("VS", "EVO_Tr_Lbl", w / 2, 150, COL_ACC, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(d.b ~= "" and d.b or "?", "EVO_Tr_Big", w / 2, 182, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        elseif d.phase == "done" then
            draw.SimpleText("Vainqueur du tournoi", "EVO_Tr_Lbl", w / 2, 100, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(d.champion ~= "" and d.champion or "?", "EVO_Tr_Big", w / 2, 145, COL_GREEN, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("Récompense-le via UI Animateur ▸ COFFRES.", "EVO_Tr_Lbl", w / 2, 185, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    rebuild()
end

-- Ré-ouverture manuelle (bouton du menu animateur) si le panneau a été fermé.
function EVO_AnimTourney.OpenPanel()
    if not CL.active then return end
    makePanel()
end

net.Receive("EVO:Tourney:Sync", function()
    local active = net.ReadBool()
    if not active then
        CL.active = false ; CL.data = nil
        if IsValid(pPanel) then pPanel:Remove() end
        return
    end
    CL.active = true
    CL.data = {
        type     = net.ReadString(),
        phase    = net.ReadString(),
        players  = net.ReadUInt(16),
        fams     = net.ReadUInt(16),
        round    = net.ReadUInt(8),
        a        = net.ReadString(),
        b        = net.ReadString(),
        champion = net.ReadString(),
    }
    local n = net.ReadUInt(8)
    local names = {}
    for i = 1, n do names[i] = net.ReadString() end
    CL.data.names = names
    if not IsValid(pPanel) then makePanel() else rebuild() end
end)
