-- "addons\\evo_animateur\\lua\\autorun\\sh_anim_build.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- MODE BUILD DES ANIMATEURS (29/09/2026, demande d'axxou).
--   Depuis le panneau animateur (evo_animateur), un Animateur ou un Gerant
--   Animateur passe en mode build : il recoit le physgun et le toolgun, la touche Q
--   ouvre le CATALOGUE EVO (cl_anim_build_menu.lua : les modeles des maps, pieces de
--   decor comprises depuis le 30/09, et quelques particules, jamais le reste des modeles
--   de base de GMod) et le menu contextuel sandbox s'ouvre pour lui. Seule exception aux
--   modeles de base : le plastique de GMod (sh_anim_build_ajouts.lua, 30/09, les
--   animateurs construisent avec).
--   Tout le reste du verrouillage (evo_lockdown) reste en place.
--
-- GARDE-FOUS, tous cote SERVEUR :
--   * plafond de props GLOBAL au serveur (tous animateurs confondus), en plus de
--     la limite par joueur de GMod (sbox_maxprops, 150 par defaut) ;
--   * physgun, outils et proprietes (clic droit) sur SES props seulement, jamais
--     sur un joueur, un PNJ, un prop d'un autre ou une entite de la map ;
--   * outils sur une LISTE BLANCHE : ceux qui creent des entites (lampes,
--     propulseurs, duplicateur...) contourneraient le plafond de props ;
--   * palier Animateur minimum (pas l'Animateur teste) et PERSO ANIMATION
--     obligatoire, comme les autres outils (EVO_ANIM.Tier) ;
--   * le mode s'eteint a la mort et au changement de personnage.
-- ============================================================================

EVO_BUILD = EVO_BUILD or {}
EVO_BUILD.MAX_PROPS = 250   -- props de build EN TOUT sur le serveur
EVO_BUILD.TIER_MIN  = 2     -- 2 = Animateur, 3 = Gerant Animateur (EVO_ANIM.GROUP_TIERS)
EVO_BUILD.TIER_TOUT = 3     -- « Retirer tous les props build » : Gerant et plus

-- Outils autorises. Tout outil absent de la liste est refuse.
EVO_BUILD.OUTILS = {
	weld = true, nocollide = true, remover = true, colour = true, material = true,
	axis = true, ballsocket = true, rope = true, elastic = true, slider = true,
	keepupright = true, physprop = true, precision = true, stacker = true,
	evo_taille = true, -- redimensionner (sh_anim_build_taille.lua), fait maison
}

-- Proprietes du clic droit (menu contextuel) refusees meme sur ses props :
-- persist garderait le prop au redemarrage, drive et edit ouvrent autre chose.
EVO_BUILD.PROPRIETES_INTERDITES = { persist = true, drive = true, editentity = true }

-- Particules posables (catalogue, onglet Particules) : quelques effets d'ambiance,
-- noms verifies dans les .pcf des packs le 30/09/2026 (pcf_noms.py). L'effet vit
-- dans l'entite evo_build_particule, comptee comme un prop de build : plafond,
-- proprietaire, physgun, remover et « Retirer mes props » s'appliquent pareil.
EVO_BUILD.PCF = { "particles/fire_01.pcf", "particles/watcher_map.pcf", "particles/watcher_stuff.pcf", "particles/ali_aura.pcf" }
EVO_BUILD.PARTICULES = {
	{ nom = "Feu (petit)",                 effet = "env_fire_small" },
	{ nom = "Feu (moyen)",                 effet = "env_fire_medium" },
	{ nom = "Feu (grand)",                 effet = "env_fire_large" },
	{ nom = "Feu de camp",                 effet = "[1]campfire1" },
	{ nom = "Flammes au sol",              effet = "[1]groundflame1" },
	{ nom = "Pétales de cerisier (arbre)", effet = "three_leaf_cherry" },
	{ nom = "Pétales de cerisier (zone)",  effet = "map_sakura" },
	{ nom = "Feuilles (arbre)",            effet = "three_leaf" },
	{ nom = "Neige (arbre)",               effet = "three_snow" },
	{ nom = "Brume",                       effet = "watcher_waterfall_smoke_1" },
	{ nom = "Étincelles",                  effet = "[2]sparkle1" },
	{ nom = "Étincelles (2)",              effet = "[2]sparkle2" },
	{ nom = "Aura rouge",                  effet = "aura_rouge" },
	{ nom = "Aura bleue",                  effet = "aura_bleu" },
	{ nom = "Aura blanche",                effet = "aura_blanche" },
}
for _, p in ipairs(EVO_BUILD.PCF) do game.AddParticles(p) end
for _, p in ipairs(EVO_BUILD.PARTICULES) do PrecacheParticleSystem(p.effet) end
function EVO_BUILD.ParticuleAutorisee(effet)
	for _, p in ipairs(EVO_BUILD.PARTICULES) do
		if p.effet == effet then return true end
	end
	return false
end

-- Categories du catalogue : celles tirees des maps (sh_anim_build_catalogue.lua,
-- genere) puis les ajouts faits a la main (sh_anim_build_ajouts.lua). Une categorie
-- qui porte `carte` n'existe que sur cette map (ses modeles sont ranges dans le .bsp).
-- Assemblees a la demande : l'ordre de chargement des fichiers autorun n'est pas garanti.
function EVO_BUILD.Categories()
	local out, carte = {}, game.GetMap()
	for _, liste in ipairs({ EVO_BUILD.CATALOGUE or {}, EVO_BUILD.CATALOGUE_AJOUTS or {} }) do
		for _, cat in ipairs(liste) do
			if not cat.carte or cat.carte == carte then out[#out + 1] = cat end
		end
	end
	return out
end

-- Modeles autorises : le catalogue ci-dessus, indexe a la premiere demande. Chemin
-- normalise : GMod passe parfois des antislashes ou des majuscules.
local modelesOk
function EVO_BUILD.ModeleAutorise(model)
	if not modelesOk then
		if not istable(EVO_BUILD.CATALOGUE) then return false end
		modelesOk = {}
		for _, cat in ipairs(EVO_BUILD.Categories()) do
			for _, m in ipairs(cat.modeles or {}) do modelesOk[m] = true end
		end
	end
	return modelesOk[string.lower((string.gsub(tostring(model or ""), "\\", "/")))] == true
end

if SERVER then
	util.AddNetworkString("EVO:Anim:Build")      -- client -> serveur : les actions du panneau
	util.AddNetworkString("EVO:Anim:BuildEtat")  -- serveur -> client : son etat et le compteur

	EVO_BUILD.Props = EVO_BUILD.Props or {}   -- [ent] = true, props poses en mode build

	local function actif(ply)
		return IsValid(ply) and ply:IsPlayer() and ply.EVO_ModeBuild == true
	end
	EVO_BUILD.Actif = actif

	local function palier(ply)
		return (EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0
	end

	local function notifier(ply, msg, err)
		if MUGEN and MUGEN.Notify then MUGEN.Notify(ply, msg, err and (NOTIFY_ERROR or 1) or (NOTIFY_GENERIC or 0), 4) end
	end

	-- Etat envoye au client par MESSAGE, pas par variable reseau : le schema NW du
	-- projet (LZY_PlyState) est numerote entre branches, et l'API NW1 de GMod est
	-- refusee par les controles. Envoye seulement quand quelque chose change.
	local function envoyerEtat(ply)
		if not IsValid(ply) then return end
		net.Start("EVO:Anim:BuildEtat")
			net.WriteBool(actif(ply))
			net.WriteUInt(math.min(EVO_BUILD.Nombre or 0, 4095), 12)
			net.WriteUInt(EVO_BUILD.MAX_PROPS, 12)
		net.Send(ply)
	end

	local function compter()
		local n = 0
		for ent in pairs(EVO_BUILD.Props) do
			if IsValid(ent) then n = n + 1 else EVO_BUILD.Props[ent] = nil end
		end
		if n ~= EVO_BUILD.Nombre then
			EVO_BUILD.Nombre = n
			for _, p in player.Iterator() do if p.EVO_ModeBuild then envoyerEtat(p) end end
		end
		return n
	end
	EVO_BUILD.Compter = compter

	local function aLui(ply, ent)
		return IsValid(ent) and ent.EVO_BuildSid ~= nil and ent.EVO_BuildSid == ply:SteamID64()
	end

	-- Verdicts lus AUSSI par le gamemode (mangarp sv_item_spawning), dont les
	-- regles staff repondent directement : sans ca, son « oui » au physgun
	-- court-circuitait la verification « ses props seulement » des hooks ci-dessous.
	function EVO_BUILD.PeutPhysgun(ply, ent) return actif(ply) and aLui(ply, ent) end
	function EVO_BUILD.PeutPropriete(ply, prop, ent)
		return actif(ply) and not EVO_BUILD.PROPRIETES_INTERDITES[tostring(prop or "")] and aLui(ply, ent)
	end

	-- Appele par evo_lockdown : les seuls pouvoirs de base qu'on rend, et seulement
	-- en mode build. Les garde-fous plus bas decident ensuite au cas par cas.
	local ROUVERTS = { PlayerSpawnObject = true, PlayerSpawnProp = true, CanTool = true, CanProperty = true, PhysgunPickup = true }
	function EVO_BUILD.Autorise(ply, sHook)
		return actif(ply) and ROUVERTS[sHook] == true
	end

	local function eteindre(ply, raison)
		if not IsValid(ply) or not ply.EVO_ModeBuild then return end
		ply.EVO_ModeBuild = nil
		envoyerEtat(ply)
		if ply:Alive() then
			ply:StripWeapon("weapon_physgun")
			ply:StripWeapon("gmod_tool")
		end
		if raison then notifier(ply, "Mode build désactivé : " .. raison) end
		if EVO_StaffLog then EVO_StaffLog(ply, "anim.build.off", nil, raison or "") end
	end
	EVO_BUILD.Eteindre = eteindre

	local function allumer(ply)
		if palier(ply) < EVO_BUILD.TIER_MIN then
			notifier(ply, "Le mode build est réservé aux animateurs et gérants animateur, sur le perso animation.", true)
			return
		end
		ply.EVO_ModeBuild = true
		compter()
		envoyerEtat(ply)
		ply:Give("weapon_physgun")
		ply:Give("gmod_tool")
		notifier(ply, "Mode build activé : physgun, toolgun et menu Q. " .. compter() .. "/" .. EVO_BUILD.MAX_PROPS .. " props sur le serveur.")
		if EVO_StaffLog then EVO_StaffLog(ply, "anim.build.on") end
	end

	local function retirer(filtre)
		local n = 0
		for ent in pairs(EVO_BUILD.Props) do
			if IsValid(ent) and filtre(ent) then ent:Remove() n = n + 1 end
		end
		compter()
		return n
	end

	net.Receive("EVO:Anim:Build", function(_, ply)
		if not IsValid(ply) then return end
		local action = net.ReadUInt(3)
		if action == 0 then
			compter()
			envoyerEtat(ply)   -- le panneau demande l'etat a son ouverture
		elseif action == 1 then
			if actif(ply) then eteindre(ply, "à ta demande") else allumer(ply) end
		elseif action == 2 then
			if palier(ply) < EVO_BUILD.TIER_MIN then return end
			local sid = ply:SteamID64()
			local n = retirer(function(ent) return ent.EVO_BuildSid == sid end)
			notifier(ply, n .. " prop(s) retiré(s).")
			if EVO_StaffLog then EVO_StaffLog(ply, "anim.build.retirer", nil, tostring(n)) end
		elseif action == 3 then
			if palier(ply) < EVO_BUILD.TIER_TOUT then return end
			local n = retirer(function() return true end)
			notifier(ply, n .. " prop(s) de build retiré(s) sur le serveur.")
			if EVO_StaffLog then EVO_StaffLog(ply, "anim.build.retirer_tout", nil, tostring(n)) end
		elseif action == 4 then
			-- Une particule d'ambiance, posee la ou il vise, portee par une entite
			-- comptee comme un prop de build (memes garde-fous que les props).
			local effet = net.ReadString()
			if not actif(ply) or not EVO_BUILD.ParticuleAutorisee(effet) then return end
			if compter() >= EVO_BUILD.MAX_PROPS then
				notifier(ply, "Limite atteinte : " .. EVO_BUILD.MAX_PROPS .. " props de build sur le serveur.", true)
				return
			end
			local oeil = ply:EyePos()
			local tr = util.TraceLine({ start = oeil, endpos = oeil + ply:GetAimVector() * 1500, filter = ply, mask = MASK_SOLID })
			local ent = ents.Create("evo_build_particule")
			if not IsValid(ent) then return end
			ent:SetEffet(effet)
			ent:SetPos(tr.HitPos + tr.HitNormal * 2)
			ent:Spawn()
			ent:Activate()
			if ent.CPPISetOwner then ent:CPPISetOwner(ply) end
			ent.EVO_BuildSid = ply:SteamID64()
			EVO_BUILD.Props[ent] = true
			compter()
			if undo then undo.Create("Particule de build") undo.AddEntity(ent) undo.SetPlayer(ply) undo.Finish() end
			if ply.AddCleanup then ply:AddCleanup("props", ent) end
		end
	end)

	-- Plafond global : refuse le prop de trop, AVANT sa creation.
	hook.Add("PlayerSpawnProp", "EVO:Build:Plafond", function(ply)
		if not actif(ply) or ply:IsSuperAdmin() then return end
		if compter() >= EVO_BUILD.MAX_PROPS then
			notifier(ply, "Limite atteinte : " .. EVO_BUILD.MAX_PROPS .. " props de build sur le serveur. Retire des props avant d'en poser d'autres.", true)
			return false
		end
	end)

	-- Catalogue : seuls les modeles de la map. Le menu du client ne montre que ceux-la,
	-- mais gm_spawn se tape aussi dans la console : la verification est ICI.
	hook.Add("PlayerSpawnProp", "EVO:Build:Catalogue", function(ply, model)
		if not actif(ply) or ply:IsSuperAdmin() then return end
		if not EVO_BUILD.ModeleAutorise(model) then
			notifier(ply, "Ce modèle n'est pas dans le catalogue du mode build.", true)
			return false
		end
	end)

	-- La limite sandbox par joueur (sbox_maxprops, 150 par defaut) couperait un
	-- animateur seul avant le plafond global : en mode build, seul ce dernier compte.
	hook.Add("PlayerCheckLimit", "EVO:Build:Limite", function(ply, quoi)
		if quoi == "props" and actif(ply) then return true end
	end)

	hook.Add("PlayerSpawnedProp", "EVO:Build:Marquer", function(ply, _, ent)
		if not actif(ply) or not IsValid(ent) then return end
		-- SteamID et pas l'objet joueur : apres une deconnexion, il retrouve ses props.
		ent.EVO_BuildSid = ply:SteamID64()
		EVO_BUILD.Props[ent] = true
		compter()
	end)

	hook.Add("EntityRemoved", "EVO:Build:Compter", function(ent)
		if EVO_BUILD.Props[ent] then EVO_BUILD.Props[ent] = nil compter() end
	end)

	-- Physgun : ses props, rien d'autre (ni joueur, ni PNJ, ni la map).
	hook.Add("PhysgunPickup", "EVO:Build:Physgun", function(ply, ent)
		if not actif(ply) or ply:IsSuperAdmin() then return end
		if not aLui(ply, ent) then return false end
	end)

	-- Toolgun : liste blanche, et seulement sur ses props ou sur le monde (souder au sol).
	hook.Add("CanTool", "EVO:Build:Outils", function(ply, tr, outil)
		if not actif(ply) or ply:IsSuperAdmin() then return end
		if not EVO_BUILD.OUTILS[tostring(outil or "")] then
			notifier(ply, "Cet outil n'est pas autorisé en mode build.", true)
			return false
		end
		local ent = tr and tr.Entity
		if IsValid(ent) and not ent:IsWorld() and not aLui(ply, ent) then return false end
	end)

	-- Clic droit (menu contextuel) : ses props, sans les proprietes interdites.
	hook.Add("CanProperty", "EVO:Build:Proprietes", function(ply, prop, ent)
		if not actif(ply) or ply:IsSuperAdmin() then return end
		if EVO_BUILD.PROPRIETES_INTERDITES[tostring(prop or "")] or not aLui(ply, ent) then return false end
	end)

	-- Extinction automatique : mort, deconnexion, changement de perso ou de rang.
	hook.Add("PlayerDeath", "EVO:Build:Mort", function(ply) eteindre(ply, "mort") end)
	hook.Add("PlayerDisconnected", "EVO:Build:Depart", function(ply) ply.EVO_ModeBuild = nil end)
	timer.Create("EVO:Build:Surveille", 5, 0, function()
		for _, ply in player.Iterator() do
			if ply.EVO_ModeBuild and palier(ply) < EVO_BUILD.TIER_MIN then eteindre(ply, "plus sur le perso animation") end
		end
	end)
end

if CLIENT then
	-- Etat local du joueur, lu par le menu Q (gamemode cl_init) et le panneau.
	EVO_BUILD.MoiActif = EVO_BUILD.MoiActif or false
	EVO_BUILD.Nombre = EVO_BUILD.Nombre or 0
	net.Receive("EVO:Anim:BuildEtat", function()
		local on = net.ReadBool()
		EVO_BUILD.Nombre = net.ReadUInt(12)
		EVO_BUILD.MAX_PROPS = net.ReadUInt(12)
		if on == EVO_BUILD.MoiActif then return end
		EVO_BUILD.MoiActif = on
		if not on and EVO_BUILD.FermerMenu then EVO_BUILD.FermerMenu() end
		-- Menu contextuel : en mode build, celui de sandbox (outils, clic droit sur ses
		-- props) remplace le menu RP. MUGEN.ContextMenuOpen = true = menu RP (gamemode).
		if MUGEN then MUGEN.ContextMenuOpen = not on end
	end)
end
