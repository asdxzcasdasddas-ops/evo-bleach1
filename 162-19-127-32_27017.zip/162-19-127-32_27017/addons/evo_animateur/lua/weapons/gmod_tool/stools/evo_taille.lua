-- "addons\\evo_animateur\\lua\\weapons\\gmod_tool\\stools\\evo_taille.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- OUTIL « TAILLE » DU MODE BUILD (30/09/2026). Le travail est fait par
-- EVO_BUILD.Redimensionner (evo_animateur/lua/autorun/sh_anim_build_taille.lua).
-- Le droit de s'en servir (mode build, liste blanche, ses props seulement) est juge
-- par le hook CanTool de sh_anim_build.lua avant que l'outil ne soit appele.
-- ============================================================================
TOOL.Category = "EVO"
TOOL.Name = "#tool.evo_taille.name"
TOOL.ClientConVar["echelle"] = "1"
TOOL.Information = { { name = "left" }, { name = "right" }, { name = "reload" } }

if CLIENT then
	language.Add("tool.evo_taille.name", "Taille")
	language.Add("tool.evo_taille.desc", "Agrandit ou rétrécit un de tes props, collisions comprises.")
	language.Add("tool.evo_taille.left", "Appliquer la taille réglée")
	language.Add("tool.evo_taille.right", "Remettre la taille d'origine")
	language.Add("tool.evo_taille.reload", "Reprendre la taille du prop visé")
end

local function propVise(tr)
	local ent = tr and tr.Entity
	if IsValid(ent) and ent:GetClass() == "prop_physics" then return ent end
end

local function dire(ply, msg)
	if MUGEN and MUGEN.Notify then MUGEN.Notify(ply, msg, NOTIFY_ERROR or 1, 4) else ply:ChatPrint(msg) end
end

local function redimensionner(tool, tr, s)
	local ent = propVise(tr)
	if not ent then return false end
	if CLIENT then return true end
	if not (EVO_BUILD and EVO_BUILD.Redimensionner) then return false end
	local ply = tool:GetOwner()
	local ok, raison = EVO_BUILD.Redimensionner(ent, s)
	if not ok then
		dire(ply, raison or "Redimensionnement refusé.")
		return false
	end
	if EVO_StaffLog then EVO_StaffLog(ply, "anim.build.taille", nil, string.format("%s x%.2f", ent:GetModel() or "?", ent:GetModelScale())) end
	return true
end

function TOOL:LeftClick(tr) return redimensionner(self, tr, self:GetClientNumber("echelle", 1)) end
function TOOL:RightClick(tr) return redimensionner(self, tr, 1) end

function TOOL:Reload(tr)
	local ent = propVise(tr)
	if not ent then return false end
	if CLIENT then return true end
	self:GetOwner():ConCommand("evo_taille_echelle " .. string.format("%.2f", ent:GetModelScale()))
	return true
end

function TOOL.BuildCPanel(cp)
	cp:Help("#tool.evo_taille.desc")
	cp:NumSlider("Taille", "evo_taille_echelle", EVO_BUILD and EVO_BUILD.ECHELLE_MIN or 0.1, EVO_BUILD and EVO_BUILD.ECHELLE_MAX or 5, 2)
	for _, v in ipairs({ 0.25, 0.5, 1, 1.5, 2, 3, 5 }) do
		cp:Button("x" .. v, "evo_taille_echelle", tostring(v))
	end
	cp:Help("Clic droit : taille d'origine. R : reprendre la taille du prop visé. Un prop soudé ou encordé se redimensionne avant d'être attaché.")
end
