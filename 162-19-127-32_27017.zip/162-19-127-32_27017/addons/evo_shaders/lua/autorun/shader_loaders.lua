-- "addons\\evo_shaders\\lua\\autorun\\shader_loaders.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("shaders/impact_frame.lua")
	AddCSLuaFile("shaders/chromatic_impact_frame.lua")
	AddCSLuaFile("shaders/cl_main.lua")
	include("shaders/sv_main.lua")
end

if CLIENT then
	include("shaders/impact_frame.lua")
	include("shaders/chromatic_impact_frame.lua")
	include("shaders/cl_main.lua")
end
