-- "addons\\evo_shaders\\lua\\shaders\\impact_frame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local active = false

local currentMat = nil

local shakeEndTime = 0

hook.Add("CalcView", "ImpactShakeView:1", function(ply, pos, angles, fov)
	if CurTime() > shakeEndTime then return end

	local intensity = 0.05
	local freq = 20

	local offset = VectorRand() * intensity
	local angOffset = AngleRand() * (intensity * 0.5)

	local view = {}
	view.origin = pos + offset
	view.angles = angles + angOffset
	view.fov = fov
	return view
end)

hook.Add("RenderScreenspaceEffects", "ImpactFrame:1", function()
	if not active or not currentMat then return end

	render.UpdateScreenEffectTexture()

	currentMat:SetFloat("$c0_x", ScrW())
	currentMat:SetFloat("$c0_y", ScrH())

	render.SetMaterial(currentMat)
	render.DrawScreenQuad()
end)

local Player = FindMetaTable("Player")

function Player:ImpactFrame(len)
	frame = 0
	active = true
	shakeEndTime = CurTime() + len

	currentMat = Material("evo_shaders/impact_frame")

	timer.Simple(len/3, function() currentMat = Material("evo_shaders/invert_impact_frame") end)
	timer.Simple((len/3) * 2, function() currentMat = Material("evo_shaders/impact_frame") end)
	timer.Simple(len, function() currentMat = nil active = false end)
end
