-- "addons\\evo_shaders\\lua\\shaders\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
net.Receive("EVO::ImpactFrame", function ()
    local nTime = net.ReadFloat()
    local nType = net.ReadUInt(2)
    if nType == 1 then 
        LocalPlayer():ImpactFrame(nTime)
    else
        LocalPlayer():ChromaticImpactFrame(nTime)
    end
end)
