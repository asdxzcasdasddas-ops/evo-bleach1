-- "addons\\evo_shaders\\lua\\shaders\\chromatic_impact_frame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local active = false

local currentMat = nil

local shakeEndTime = 0

hook.Add("CalcView", "ImpactShakeView:2", function(ply, pos, angles, fov)
	if CurTime() > shakeEndTime then return end

	local intensity = 0.05
	local freq = 20

	local offset = VectorRand() * intensity
	local angOffset = AngleRand() * (intensity * 0.5)

	local view = {}
	view.origin = pos + offset
	view.angles = angles + angOffset
	view.fov = fov
	return view
end)

hook.Add("RenderScreenspaceEffects", "ImpactFrame:2", function()
	if not active or not currentMat then return end

	render.UpdateScreenEffectTexture()

	currentMat:SetFloat("$c0_x", ScrW())
	currentMat:SetFloat("$c0_y", ScrH())

	render.SetMaterial(currentMat)
	render.DrawScreenQuad()
end)

local Player = FindMetaTable("Player")

function Player:ChromaticImpactFrame(len)
	frame = 0
	active = true
	shakeEndTime = CurTime() + len

	currentMat = Material("evo_shaders/chromatic_impact_frame")

	timer.Simple(len, function() currentMat = nil active = false end)
end
