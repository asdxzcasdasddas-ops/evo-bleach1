-- "addons\\evo_staff\\lua\\autorun\\sh_staff_grades.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF — reconnaissance du grade « responsable modérateur », PARTAGÉE.
--
-- POURQUOI CE FICHIER : le test « ce joueur est-il responsable modérateur ? »
-- existait déjà recopié à l'identique dans sh_staff_context_actions, sv_dashboard
-- et cl_dashboard. Les droits ajoutés le 09/08 (tickets helpeur + modérateur,
-- 2e emplacement de perso, ESP sans limite de portée, retrait de warn) en
-- auraient fait 5 copies de plus, dans 4 ADDONS DIFFÉRENTS — dont lzy_character
-- et evo_support, qui n'ont aucune raison de connaître les orthographes SAM.
-- Une seule source ici : le jour où le rang est renommé côté SAM, il y a UN
-- endroit à corriger, pas neuf.
--
-- ORTHOGRAPHES : le rang canonique est « responsable_moderateur », et SAM accepte
-- les alias déclarés dans sv_staff_ranks.lua (« Responsable Modérateur »,
-- « responsable modérateur »). On normalise en lower — qui ne touche PAS aux
-- accents, d'où les deux clés.
-- ⚠ EXACTEMENT ces orthographes-là, pas une de plus. Une variante « maison »
-- reconnue ICI mais absente de STAFFMODE_GROUPS / MOD_PLUS / MODO_VIEWERS
-- donnerait un DEMI-DROIT silencieux : le porteur aurait les tickets et le 2e
-- perso, mais ni `!staff`, ni `!warn`, ni le dashboard, ni l'ESP — et personne
-- ne comprendrait pourquoi. Pour ajouter une orthographe, il faut la déclarer
-- dans sv_staff_ranks.lua ET dans toutes ces tables, ou pas du tout.
--
-- REALM : fichier lua/autorun/ nu (pas /server ni /client) = chargé des DEUX
-- côtés. Indispensable : le serveur en a besoin pour AUTORISER, le client pour
-- AFFICHER (bouton « Retirer » d'un warn, cadenas d'emplacement de perso).
--
-- APPEL DEPUIS UN AUTRE ADDON : toujours `EVO_IsRespoModo and EVO_IsRespoModo(p)`.
-- Rien ne garantit l'ordre de chargement des addons, et un serveur sans evo_staff
-- doit continuer à tourner (le droit est simplement refusé) plutôt que planter.
-- ============================================================================

local RESPO_MODO = {
	responsable_moderateur     = true,
	["responsable modérateur"] = true,
	-- Gérant RP (user 09/07 : « il doit avoir aussi les perms du resp modérateur »).
	-- Le déclarer ICI lui donne d'un coup TOUS les droits du respo dans les 8 addons qui
	-- lisent EVO_IsRespoModo (dashboard, warns, tickets, inspection, slot perso, ESP,
	-- masquage aux rangs inférieurs). Rang SAM `gerant_rp` (sv_staff_ranks.lua) ; en plus
	-- de ces droits il a le palier d'animation 4 (evo_animateur sh_anim_tiers).
	gerant_rp                  = true,
	["gérant rp"]              = true,
}

--- Ce joueur porte-t-il les DROITS du responsable modérateur ? (rang respo modo OU
--- gérant RP, cf. RESPO_MODO)
--- N'inclut PAS les superadmins : un SA a ses propres droits, et les additionner
--- ici masquerait les endroits où le SA a été oublié.
--- @param ply Player
--- @return boolean
function EVO_IsRespoModo(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return RESPO_MODO[string.lower(ply:GetUserGroup() or "")] == true
end

--- Même test sur un NOM de rang (sélection de perso : avant qu'un perso soit chargé).
function EVO_IsRespoModoGroup(sGroup)
	return RESPO_MODO[string.lower(tostring(sGroup or ""))] == true
end

-- Plafond de ban du responsable modérateur (dashboard F8). 0 / au-delà → clampé
-- à cette valeur côté serveur. Superadmin : pas de plafond (0 = permanent).
EVO_RESPO_BAN_MAX_MINUTES = 30 * 24 * 60 -- 30 jours

-- Plafond de ban du modérateur plus (dashboard F8). 7 jours, pas de permanent.
EVO_MODO_PLUS_BAN_MAX_MINUTES = 7 * 24 * 60 -- 7 jours

-- ============================================================================
-- MODÉRATEUR PLUS / MJ PLUS — droits EXTRA, PARTAGÉS (client + serveur).
-- Même règle que EVO_IsRespoModo : UNE liste d'orthographes, lue partout.
-- ============================================================================
local MODO_PLUS = {
	moderateur_plus = true,
	["moderateur plus"] = true,
}

--- Rang `moderateur_plus` : mêmes droits modo + ban 7 j + rename (dashboard).
function EVO_IsModoPlus(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return MODO_PLUS[string.lower(ply:GetUserGroup() or "")] == true
end

--- Lecture des PAPILLONS (messages privés) d'un joueur depuis le dashboard F8 (10/25) :
--- modérateur plus, responsable modérateur (gérant RP compris, cf. RESPO_MODO) et
--- superadmin. Pas le modérateur simple. Lu par le serveur (sv_pmlogs, AUTORISE) et
--- le client (cl_dashboard, AFFICHE le bouton).
function EVO_CanReadPapillons(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return ply:IsSuperAdmin() or EVO_IsRespoModo(ply) or EVO_IsModoPlus(ply)
end

local MJ_PLUS = {
	mj_plus = true,
}

--- Rang `mj_plus` : mêmes droits animateur + Aller à / TP / Renvoyer / Message
--- dans les outils animateur (pas le dashboard F8).
function EVO_IsMJPlus(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return MJ_PLUS[string.lower(ply:GetUserGroup() or "")] == true
end

local GERANT_ANIM = {
	animateur_gerant = true,
	["gérant animateur"] = true,
}

--- Rang `animateur_gerant` (alias SAM « Gérant Animateur »).
function EVO_IsGerantAnim(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return GERANT_ANIM[string.lower(ply:GetUserGroup() or "")] == true
end

-- Les orthographes du gérant RP sont AUSSI déclarées dans sv_staff_ranks.lua (alias
-- SAM), STAFFMODE_GROUPS, MOD_PLUS, MODO_VIEWERS, NOCLIP_TAGS, GROUP_TIERS et les deux
-- STAFF_GROUPS du chat : une variante ajoutée ici seule = demi-droit silencieux.

-- ============================================================================
-- LES RANGS DU STAFF, PARTAGÉS (17/08)
--
-- POURQUOI ICI : cette table vivait en `local` dans cl_voir_staff.lua, donc le
-- SERVEUR n'avait aucun moyen de répondre à « ce joueur est-il du staff ? ».
-- CanStaffMode ne répond PAS à cette question : un HELPEUR n'y est pas (il n'a
-- pas droit au mode staff), et c'est pourtant un membre du staff. Une annonce
-- staff qui s'appuierait sur CanStaffMode raterait donc exactement les gens
-- qu'elle doit prévenir.
--
-- Elle est DÉPLACÉE, pas recopiée : cl_voir_staff.lua lit celle-ci. C'est la
-- même règle que EVO_IsRespoModo ci-dessus — une liste d'orthographes SAM
-- recopiée finit toujours par en oublier une dans l'une des copies.
--
-- Les champs :
--   niveau    4 = admin/superadmin · 3 = responsable · 2 = titulaire · 1 = débutant
--   pole      "moderation" · "animation" · "*" (les deux)
--   supervise voit tout son pôle, hors service et sans limite de portée
--   lib       libellé court affiché dans les HUD
--
-- ⚠ Un groupe ABSENT de cette table n'est PAS du staff : il ne voit personne,
-- n'est vu de personne (hors superadmin) et ne reçoit pas les annonces. C'est
-- volontairement fermé — un rang inconnu ne doit hériter d'aucun droit par
-- défaut. Les orthographes sont celles de SAM, exactement (sv_staff_ranks.lua).
-- Le rang « équilibrage » n'y figure pas : il peut passer en mode staff pour
-- tester les sorts, mais il n'encadre personne et ne relève pas de la modération.
-- ============================================================================
-- `ordre` : la place dans la liste du staff a l'ecran (demande user 18/08 :
-- superadmin, puis gerants, puis moderateurs, puis animateurs, puis helpeurs).
-- Distinct de `niveau`, qui porte les DROITS de visibilite : trier sur le
-- niveau melangeait moderateurs et animateurs, a egalite de rang.
local RESPO = { niveau = 3, pole = "moderation", supervise = true, lib = "RESP MODO", ordre = 3 }
-- Gérant RP (09/07) : les droits du respo modo, à la tête du pôle animation, AU-DESSUS
-- du gérant animateur ; `supervise` = ses repères portent sur toute la map.
local GERANT = { niveau = 3, pole = "animation", supervise = true, lib = "GERANT RP", ordre = 4 }
local MODO  = { niveau = 2, pole = "moderation", lib = "MODO", ordre = 7 }
local MODOP = { niveau = 2, pole = "moderation", lib = "MODO+", ordre = 6 }
local GANIM = { niveau = 3, pole = "animation", lib = "GERANT ANIM", ordre = 5 }
local MJ    = { niveau = 2, pole = "animation", lib = "MJ", ordre = 9 }
local MJP   = { niveau = 2, pole = "animation", lib = "MJ+", ordre = 8 }

EVO_STAFF_RANGS = {
	superadmin             = { niveau = 4, pole = "*", lib = "SUPERADMIN", ordre = 1 },
	admin                  = { niveau = 4, pole = "*", lib = "ADMIN", ordre = 2 },
	responsable_moderateur = RESPO,
	-- Orthographe alias SAM (rang créé à la main « Responsable Modérateur »).
	["responsable modérateur"] = RESPO,
	gerant_rp              = GERANT,
	["gérant rp"]          = GERANT,
	animateur_gerant       = GANIM, ["gérant animateur"] = GANIM,
	moderateur_plus        = MODOP, ["moderateur plus"] = MODOP,
	-- 3 orthographes du rang modérateur, comme partout ailleurs.
	moderateur             = MODO, ["modérateur"] = MODO, moderator = MODO,
	mj_plus                = MJP,
	mj                     = MJ,
	animateur              = { niveau = 2, pole = "animation", lib = "ANIMATEUR", ordre = 10 },
	animateur_test         = { niveau = 1, pole = "animation", lib = "ANIM TEST", ordre = 11 },
	helper                 = { niveau = 1, pole = "moderation", lib = "HELPEUR", ordre = 12 },
	helpeur                = { niveau = 1, pole = "moderation", lib = "HELPEUR", ordre = 12 },
}

--- Le descriptif de rang staff d'un joueur, ou nil s'il n'est pas du staff.
--- @param ply Player
--- @return table|nil
function EVO_StaffRang(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return nil end
	return EVO_STAFF_RANGS[string.lower(ply:GetUserGroup() or "")]
end

--- Ce joueur est-il membre du staff, EN SERVICE OU NON ? Helpeurs et animateurs
--- compris — c'est justement ce que CanStaffMode ne sait pas dire.
--- @param ply Player
--- @return boolean
function EVO_EstStaff(ply)
	return EVO_StaffRang(ply) ~= nil
end
