-- "addons\\evo_staff\\lua\\autorun\\sh_streamer_wl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STREAMER WHITELIST — shared
-- Joueurs listés (SteamID64) : tag « STREAMER » en noclip staff + TOUTE action
-- staff (ban, kick, bring, ck, kill, hp, freeze, warn…) réservée aux SUPERADMINS.
-- Ce qui ne TOUCHE PAS la cible reste ouvert à tout le staff : observation
-- (spectate / inspection) et goto. Le rang SAM « streamer » reste aussi reconnu
-- (tag historique) pour les mêmes protections.
-- ============================================================================

EVO_StreamerWL = EVO_StreamerWL or {}

--- Joueur streamer ? (NWBool whitelist sync, ou rang SAM « streamer ».)
function EVO_StreamerWL.IsPlayer(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_IsStreamer", false) then return true end
	local g = string.lower(ply:GetUserGroup() or "")
	return g == "streamer"
end

--- L'acteur peut-il exécuter une action STAFF sur cette cible ?
--- Non-streamer = oui (les autres gates — immunité SAM, rang requis — s'appliquent
--- toujours par-dessus). Streamer = SUPERADMIN uniquement, quelle que soit l'action :
--- ban, kick, bring, return, ck, kill, heal, hp, freeze, mute, rename, warn…
--- Le staff garde le droit de se cibler lui-même (un modérateur peut être whitelist
--- streamer sans perdre ses propres actions).
--- ⚠ NE PAS appeler pour ce qui NE TOUCHE PAS la cible — observation (spectate,
--- inspection) et goto restent ouverts à tout le staff (demande user) : les appelants
--- exemptent ces actions eux-mêmes.
--- Point d'entrée UNIQUE : dashboard staff, menu contextuel, warns et outils
--- animateur passent tous par ici. Les commandes SAM sont déjà superadmin-only
--- (hook EVO::SAM::SuperadminOnly, sv_staff_ranks.lua).
function EVO_StreamerWL.CanAct(actor, target)
	if not EVO_StreamerWL.IsPlayer(target) then return true end
	if not (IsValid(actor) and actor:IsPlayer()) then return false end
	if actor == target then return true end
	return actor:IsSuperAdmin()
end

--- Alias historique (kick / mute / ban). Même règle, désormais élargie à TOUTES
--- les actions staff : gardé pour les appelants externes non migrés.
EVO_StreamerWL.CanSanction = EVO_StreamerWL.CanAct
