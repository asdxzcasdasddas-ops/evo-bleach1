-- "addons\\evo_staff\\lua\\autorun\\client\\cl_voir_staff.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ════════════════════════════════════════════════════════════════════════════
--  REPÈRES DU STAFF EN SERVICE (client) — demande L8Anton1, 04/08.
--
--  POURQUOI : le mode staff comme le mode animateur rendent INVISIBLE
--  (sam_cloak = SetNoDraw côté serveur). Deux staff qui travaillent sur la même
--  scène ne se voyaient donc pas du tout : impossible de savoir qu'un collègue
--  est déjà sur place, ni de se répartir une zone.
--
--  CE QU'ON NE FAIT PAS : toucher au cloak. Les joueurs ne doivent toujours rien
--  voir, et un cloak levé par erreur casserait la modération discrète. On ne
--  rend donc PAS les corps visibles — on dessine un simple repère à l'écran.
--
--  QUI LE VOIT : uniquement un client qui est LUI-MÊME en service (mode staff,
--  mode animateur, ou sur un PERSO ANIMATEUR). Un joueur normal, ou un staff hors
--  service, ne voit rien — le repère n'existe que dans son HUD, aucune donnée
--  nouvelle ne transite. Les drapeaux lus sont déjà répliqués à tout le monde
--  (sh_ply_state : EVO_StaffMode / EVO_AnimChar ; EVO_AnimMode sur le socle NW2).
-- ════════════════════════════════════════════════════════════════════════════

local CVAR = CreateClientConVar("evo_voir_staff", "1", true, false,
    "Afficher les reperes des autres staff en service (1 = oui)")

-- LISTE « staff en jeu » (haut-droite) : pilotée par UNE SEULE coche, celle des
-- ACTIONS RAPIDES, et **CACHÉE PAR DÉFAUT** (demande user 2026-08-22).
-- La coche décide TOUJOURS — en service comme en train de jouer son personnage :
-- un staff qui joue peut l'afficher, un staff en poste peut la masquer. Le service
-- n'entre PLUS dans l'équation pour la liste.
-- ⚠ Les REPÈRES 3D au-dessus des têtes, eux, restent réservés au service (ils
-- traversent les murs) et gardent leur propre réglage `evo_voir_staff` ci-dessus.
-- Nom de convar consommé par evo_admin_quickactions -> ne pas le renommer seul.
EVO_STAFF_LISTE_CVAR = "evo_liste_staff"
local CVAR_LISTE = CreateClientConVar(EVO_STAFF_LISTE_CVAR, "0", true, false,
    "Afficher la liste du staff en jeu en haut a droite (0 = cachee, coche des actions rapides)")

surface.CreateFont("EVO_VoirStaff", { font = "Roboto", size = 17, weight = 700, antialias = true })

local COL_TXT    = Color(236, 238, 242)
local COL_OMBRE  = Color(0, 0, 0, 190)
local COL_STAFF  = Color(207, 68, 78)     -- accent EVO : mode staff
local COL_ANIM   = Color(120, 180, 235)   -- bleu : mode animateur
-- Gris éteint : membre du staff HORS service (visible du seul responsable modérateur).
-- Couleur distincte volontaire — sans elle, il compterait un helpeur qui joue son perso
-- comme un collègue en poste, et croirait sa modération couverte alors que non.
local COL_REPOS  = Color(150, 155, 165)
local HAUTEUR    = Vector(0, 0, 82)       -- au-dessus de la tête
local DIST_MAX   = 8000                   -- au-delà, le repère n'aide plus

-- EN ANIMATION = mode animateur (cloak/noclip) OU simplement SUR UN PERSO ANIMATEUR
-- (EVO_AnimChar, posé serveur par lzy_character au chargement d'un perso slot
-- animation, non spoofable). Demande user 09/15 : avant, seul le mode animateur
-- comptait, donc un animateur qui anime « en chair » sur son perso passait pour
-- hors service — aucun intérêt, puisqu'il est bel et bien à son poste.
local function enAnimation(ply)
    return ply:GetEvoNWBool("EVO_AnimMode", false) or ply:GetEvoNWBool("EVO_AnimChar", false)
end

local function enService(ply)
    if not (IsValid(ply) and ply.GetEvoNWBool) then return false end
    return ply:GetEvoNWBool("EVO_StaffMode", false) or enAnimation(ply)
end

-- Couleur d'un staff EN SERVICE : rouge en mode staff (prioritaire : un superadmin en
-- noclip sur un perso animateur est en modération, pas en animation), bleu sinon.
local function couleurService(ply)
    if ply:GetEvoNWBool("EVO_StaffMode", false) then return COL_STAFF end
    return COL_ANIM
end

-- ── HIÉRARCHIE DE VISIBILITÉ (demande user 05/08) ───────────────────────────
--  Un repère n'a pas à être public au sein du staff : voir où se trouve un
--  responsable, ou un superadmin en observation, donne un avantage que le grade
--  ne prévoit pas. La règle :
--    • superadmin / admin : voient TOUT LE MONDE, et ne sont vus de PERSONNE ;
--    • responsables (niveau 3) : se voient entre eux, MÊME d'un pôle à l'autre ;
--    • en dessous : uniquement SON PROPRE PÔLE, jusqu'à son propre niveau.
--  Un modérateur voit donc les helpeurs et les modérateurs, et rien d'autre —
--  ni les animateurs (autre pôle), ni les responsables (au-dessus).
--
--  Groupes SAM réels du serveur. Un groupe ABSENT de cette table ne voit
--  personne et n'est vu de personne (hors superadmin) : c'est volontairement
--  fermé, un rang inconnu ne doit pas hériter d'une visibilité par défaut.
--
--  SUPERVISION (`supervise`, demande user 09/08) : drapeau porté par le RANG DU
--  SPECTATEUR — c'est LUI qui voit mieux, les cibles ne deviennent pas plus visibles
--  pour les autres. Deux effets, indissociables parce qu'ils répondent à la même
--  phrase (« voir les modérateurs et les helpeurs dans TOUTE la map ») :
--    1. plus de coupure à DIST_MAX — le repère porte d'un bout à l'autre de la map ;
--    2. les modérateurs et helpeurs sont affichés MÊME HORS SERVICE (en gris). Sans
--       ça, aucun helpeur ne serait jamais visible : le rang « helper » n'a pas accès
--       au mode staff, donc son « en service » est faux à vie.
--  Réservé au responsable modérateur : c'est son rôle d'encadrer ce pôle.
-- `lib` : libellé court du rang, affiché dans la liste du staff en service (plus
-- bas). Il est porté par le rang et pas par une seconde table, pour qu'ajouter un
-- rang ici suffise : une liste recopiée ailleurs finirait par en oublier un.
--
-- LA TABLE A DÉMÉNAGÉ (17/08) : elle est désormais dans sh_staff_grades.lua, du
-- même addon, chargé des DEUX côtés. Le serveur en avait besoin pour savoir qui
-- est du staff (destinataires d'une annonce staff) ; la laisser en `local` ici
-- l'aurait fait recopier côté serveur, c'est-à-dire exactement le défaut que ce
-- fichier-là existe pour empêcher. Le contenu et la hiérarchie n'ont pas bougé
-- d'un cran.
local function rangDe(ply)
    return EVO_StaffRang ~= nil and EVO_StaffRang(ply) or nil
end

-- `moi` peut-il voir `cible` ?
local function peutVoir(moi, cible)
    local a, b = rangDe(moi), rangDe(cible)
    if not (a and b) then return false end
    if b.niveau >= 4 then return false end          -- personne ne voit un superadmin
    if a.niveau >= 4 then return true end           -- le superadmin voit tout le reste
    if b.niveau > a.niveau then return false end    -- jamais au-dessus de soi
    if a.niveau >= 3 then return true end           -- les responsables franchissent les pôles
    return a.pole == b.pole                         -- sinon : son propre pôle seulement
end

-- ── Polices et géométrie du panneau « staff en service » (voir plus bas) ────
-- Déclarées ICI, avant `rafraichir`, parce que c'est lui qui mesure et tronque les
-- noms : une locale déclarée après ne serait pas capturée et vaudrait nil.
surface.CreateFont("EVO_ListeStaff_Titre", { font = "Bebas Neue", size = 24, weight = 400, antialias = true })
surface.CreateFont("EVO_ListeStaff_Nom",   { font = "Roboto",     size = 17, weight = 600, antialias = true })
surface.CreateFont("EVO_ListeStaff_Rang",  { font = "Roboto",     size = 14, weight = 700, antialias = true })

-- La géométrie ne dépend que de la résolution. On la calcule au rafraîchissement
-- (pour tronquer) ET au dessin, jamais deux fois dans la même frame.
local function mesures()
    local s = math.max(ScrH() / 1080, 0.5)
    return s, math.floor(280 * s), math.floor(12 * s), math.floor(26 * s), math.floor(34 * s)
end

-- Tronque un texte à `maxW` pixels avec une ellipse, en préservant les codepoints
-- UTF-8 (accents FR). Sans ça le nom, aligné à gauche, passe SOUS le libellé de rang
-- aligné à droite et les deux se superposent : un nom RP un peu long suffit, et la
-- mention « (hors service) » collée au nom plus bas en ajoute quinze caractères.
-- Même correctif que le grade long de cl_staff_inspect (ellipsize), recopié plutôt
-- qu'importé : là-bas la fonction est locale au fichier.
local function tronquer(texte, police, maxW)
    texte = tostring(texte or "")
    if maxW <= 0 or texte == "" then return texte end
    surface.SetFont(police)
    if select(1, surface.GetTextSize(texte)) <= maxW then return texte end
    local ell = "…"
    local ew  = select(1, surface.GetTextSize(ell))
    if ew >= maxW then return ell end
    local budget = maxW - ew
    local out = texte
    if utf8 and utf8.len and utf8.sub then
        local l = utf8.len(out) or 0
        while l > 0 and select(1, surface.GetTextSize(out)) > budget do
            l = l - 1
            out = utf8.sub(texte, 1, l)
        end
    else
        while #out > 0 and select(1, surface.GetTextSize(out)) > budget do
            out = out:sub(1, -2)
        end
    end
    return out .. ell
end

-- ── COÛT PAR FRAME ──────────────────────────────────────────────────────────
-- Ce hook tourne à chaque image, pour TOUS les joueurs du serveur. Il doit donc
-- coûter quasiment rien à ceux que ça ne concerne pas — c'est-à-dire presque
-- tout le monde.
--
-- Tout ce qui ne change pas d'une frame à l'autre est calculé DEUX FOIS PAR
-- SECONDE et mis en cache : qui est visible, son nom RP, sa couleur, et même le
-- fait que MOI je sois en service. Un joueur normal ne paie donc qu'un seul test
-- booléen par frame, et un staff en service ne fait plus que de la projection
-- écran, sans lecture réseau ni concaténation de chaîne.
-- `supervise` est recalculé avec le reste (2×/s) et jamais par frame : il dépend
-- de MON rang, qui ne change pas entre deux images.
--
-- `liste` : les MÊMES entrées que `visibles`, plus la mienne, triées par rang.
-- C'est ce que dessine le panneau en haut à droite. On la construit ici, avec le
-- reste du cache : le panneau ne fait donc que du dessin, jamais de lecture réseau.
local visibles, liste, prochain, jAffiche, supervise, deService = {}, {}, 0, false, false, false

local function rafraichir()
    if CurTime() < prochain then return end
    prochain = CurTime() + 0.5
    visibles = {}
    liste = {}
    jAffiche = false

    local lp = LocalPlayer()
    -- LA COCHE DECIDE SEULE (demande user 2026-08-22). Cachee par defaut, elle vaut
    -- EN SERVICE comme en train de jouer son personnage : un staff qui joue peut
    -- afficher la liste, un staff en poste peut la masquer. Le service n'entre plus
    -- dans l'equation pour la LISTE.
    -- Les REPERES 3D restent service-only (ils traversent les murs) : c'est `deService`
    -- qui, seul, remplit `visibles`. On ne sort donc AVANT la boucle joueurs que si
    -- NI la liste NI les reperes n'ont quelque chose a montrer.
    local monRang = IsValid(lp) and rangDe(lp)
    if not monRang then return end
    deService = enService(lp) == true
    jAffiche  = CVAR_LISTE:GetBool()
    if not jAffiche and not deService then return end
    supervise = monRang.supervise == true

    -- Moi d'abord : je ne suis pas dans `visibles` (on ne se dessine pas de repère
    -- au-dessus de sa propre tête), mais la liste doit m'y faire figurer, sinon le
    -- compteur annonce un staff de moins qu'il n'y en a.
    local monNom = lp:Nick()
    liste[1] = {
        nom  = monNom,
        -- Meme convention que pour les collegues : gris hors service, sinon on se
        -- croit en service en lisant sa propre ligne en couleur.
        col  = (not deService) and COL_REPOS or couleurService(lp),
        niv  = monRang.niveau,
        ordre = monRang.ordre or 99,
        lib  = monRang.lib or "",
        moi  = true,
    }

    for _, p in player.Iterator() do
        -- CIBLE HORS SERVICE (09/08) : normalement on n'affiche que le staff EN service.
        -- Le responsable modérateur fait exception, et pas par confort : un HELPEUR n'a
        -- PAS accès au mode staff (absent de STAFFMODE_GROUPS, cf. sv_staffmode), donc
        -- enService(helpeur) est TOUJOURS faux. Sans cette exception, « voir les
        -- modérateurs et les helpeurs » n'aurait jamais montré un seul helpeur, quelle
        -- que soit la portée.
        -- L'exception est BORNÉE à ce que la demande dit — pôle modération, niveau <= 2,
        -- c'est-à-dire les modérateurs et les helpeurs. Un animateur hors service, ou un
        -- collègue responsable qui joue son perso, restent invisibles : ils ne sont pas
        -- sous sa responsabilité. peutVoir s'applique ensuite comme avant, la hiérarchie
        -- ne bouge pas d'un cran.
        if p == lp then continue end
        local bDeService = enService(p)
        -- Ordre volontaire : le test « en service » d'abord, qui ne coûte que deux
        -- lectures réseau. rangDe alloue (string.lower) — on ne l'appelle donc QUE
        -- pour un responsable, et seulement sur les joueurs hors service. Pour tous
        -- les autres spectateurs, cette boucle coûte exactement ce qu'elle coûtait.
        -- TOUT LE STAFF PRESENT, EN SERVICE OU NON (demande Louxi 17/08). Avant, la
        -- liste ne montrait que ceux en service : on savait qui tenait le serveur,
        -- jamais qui etait connecte sans avoir pris son poste. Or c'est exactement
        -- ce qu'un responsable veut voir avant de demander a quelqu'un d'intervenir.
        -- La hierarchie de visibilite (peutVoir) ne bouge pas d'un cran : un
        -- superadmin en observation reste invisible, et personne ne voit au-dessus
        -- de son propre rang. On elargit CE QUI est liste, pas QUI a le droit de lire.
        local bCandidat = bDeService or rangDe(p) ~= nil
        if bCandidat and peutVoir(lp, p) then
            -- Nom RP et couleur figés ici : deux lectures réseau par personne
            -- toutes les 0,5 s au lieu de deux par personne PAR FRAME.
            -- PSEUDO STEAM et plus le nom RP (demande Louxi 17/08) : un staff se
            -- reconnait a son pseudo, pas au personnage qu'il joue ce soir-la, et
            -- c'est sous ce pseudo qu'on le retrouve sur Discord et au panel.
            local nom = p:Nick()
            local col
            if not bDeService then
                col = COL_REPOS                                                 -- hors service : gris
                -- Mention collée au nom ICI, pas au moment du dessin : le HUDPaint
                -- garde exactement le même nombre de concaténations par frame.
                nom = nom .. " (hors service)"
            else col = couleurService(p) end
            -- Le rang est relu ici plutôt que récupéré de peutVoir : un string.lower
            -- de plus, deux fois par seconde, et SEULEMENT pour les collègues déjà
            -- retenus. Le coût de la boucle pour tous les autres ne bouge pas.
            local rangCible = rangDe(p)
            local e = {
                ply = p, nom = nom, col = col,
                niv = rangCible and rangCible.niveau or 0,
                ordre = rangCible and rangCible.ordre or 99,
                lib = rangCible and rangCible.lib or "",
            }
            -- `visibles` porte les REPERES a l'ecran, `liste` le panneau. Hors
            -- service on alimente le panneau seul : voir la liste ne doit pas
            -- revenir a voir tout le monde a travers les murs.
            if deService then visibles[#visibles + 1] = e end
            liste[#liste + 1] = e
        end
    end

    -- Tri : l'ORDRE d'affichage des rangs (superadmin, gerants, moderateurs,
    -- animateurs, helpeurs -- demande user 18/08), puis par nom. Le niveau de
    -- droits ne convenait pas : moderateurs et animateurs y sont a egalite et
    -- se melangeaient. Stable d'un rafraichissement a l'autre, sinon les lignes
    -- danseraient toutes les 0,5 s.
    table.sort(liste, function(a, b)
        if (a.ordre or 99) ~= (b.ordre or 99) then return (a.ordre or 99) < (b.ordre or 99) end
        return a.nom < b.nom
    end)

    -- Noms tronqués ICI et pas au dessin : mesurer coûte un surface.GetTextSize par
    -- ligne, payé 2×/s au lieu de 60×/s. Une résolution qui change est prise en
    -- compte au rafraîchissement suivant, soit au pire 0,5 s plus tard.
    local s, boxW, pad = mesures()
    local ecart = math.floor(10 * s) -- respiration entre le nom et le libellé de rang
    for i = 1, #liste do
        local e = liste[i]
        surface.SetFont("EVO_ListeStaff_Rang")
        local largeurRang = e.lib ~= "" and select(1, surface.GetTextSize(e.lib)) or 0
        e.nomAff = tronquer(e.nom, "EVO_ListeStaff_Nom", boxW - 2 * pad - largeurRang - ecart)
    end
end

-- ════════════════════════════════════════════════════════════════════════════
--  LISTE DU STAFF EN SERVICE (haut-droite) — demande user 14/08.
--
--  POURQUOI : les repères ci-dessus ne montrent que les collègues À L'ÉCRAN. On
--  ne savait toujours pas qui d'autre tient le serveur, ni combien on est. La
--  liste répond à ça SANS une seule donnée réseau de plus : elle se sert du même
--  cache que les repères, donc de la MÊME hiérarchie de visibilité — un
--  modérateur n'y lit pas plus de monde qu'il n'en voit sur la carte, et un
--  superadmin en observation n'y apparaît pour personne.
--
--  Affichage piloté par la seule coche des ACTIONS RAPIDES (CVAR_LISTE, déclarée
--  en tête de fichier car `rafraichir` en dépend) : cachée par défaut, visible
--  en service comme hors service dès qu'on la coche.
-- ════════════════════════════════════════════════════════════════════════════

local COL_FOND    = Color(13, 14, 17, 230)
local COL_LISERE  = Color(146, 152, 161, 45)
local COL_LIB     = Color(165, 170, 182)
local COL_MOI_BG  = Color(207, 68, 78, 26)
local MAX_LIGNES  = 24  -- au-dela, on compte le reste. Passe de 12 a 24 (18/08) : a 12, les soirs charges finissaient en « +3 » et on ne savait plus qui manquait

-- Le panneau d'inspection du mode staff (ncm_combat_system/cl_staffmode_hud) se
-- dessine LUI AUSSI à droite. On publie le bas de la liste pour qu'il descende
-- dessous au lieu de se superposer ; 0 quand la liste n'est pas affichée.
EVO_STAFF_LISTE_BAS = 0

local function dessinerListe()
    local s, boxW, pad, ligneH, titreH = mesures()
    local total   = #liste
    -- Compte des gens REELLEMENT a leur poste. Calcule ici sur un tableau de 12
    -- lignes au maximum : c'est moins cher qu'une lecture reseau, et ca evite de
    -- trainer un compteur de plus dans le cache.
    local enPoste = 0
    for i = 1, total do if liste[i].col ~= COL_REPOS then enPoste = enPoste + 1 end end
    local n       = math.min(total, MAX_LIGNES)
    local reste   = total - n
    local boxH    = titreH + (n + (reste > 0 and 1 or 0)) * ligneH + math.floor(8 * s)
    local x       = ScrW() - boxW - math.floor(24 * s)
    local y       = math.floor(24 * s)

    -- Plaque Atelier : coin bas-droit coupé + liseré acier 1px ; repli carré si le
    -- kit DA n'est pas chargé (le HUD ne doit jamais dépendre d'un autre addon).
    if EVO_UI and EVO_UI.PaintCut then
        local pts = EVO_UI.PaintCut(x, y, boxW, boxH, COL_FOND, math.floor(12 * s), "br")
        if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, COL_LISERE) end
    else
        draw.RoundedBox(0, x, y, boxW, boxH, COL_FOND)
        surface.SetDrawColor(COL_LISERE)
        surface.DrawOutlinedRect(x, y, boxW, boxH, 1)
    end
    surface.SetDrawColor(COL_STAFF)
    surface.DrawRect(x, y, 2, boxH) -- barre accent gauche 2px (signature DA)

    draw.SimpleText("STAFF EN JEU", "EVO_ListeStaff_Titre", x + pad, y + math.floor(5 * s),
        COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    -- « en service / total » : le titre annoncait un total alors que la liste
    -- contient desormais aussi ceux qui ne sont pas a leur poste. Compter les
    -- deux evite de croire l'equipe deux fois plus disponible qu'elle ne l'est.
    draw.SimpleText(enPoste .. " / " .. total, "EVO_ListeStaff_Titre", x + boxW - pad, y + math.floor(5 * s),
        COL_STAFF, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

    local ly = y + titreH
    for i = 1, n do
        local e = liste[i]
        -- Ma propre ligne : fond accent très léger. Un simple repère de lecture, la
        -- couleur du nom reste celle de l'état (staff / animation / hors service).
        if e.moi then
            surface.SetDrawColor(COL_MOI_BG)
            surface.DrawRect(x + 2, ly, boxW - 2, ligneH)
        end
        draw.SimpleText(e.nomAff or e.nom, "EVO_ListeStaff_Nom", x + pad, ly + ligneH * 0.5,
            e.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(e.lib, "EVO_ListeStaff_Rang", x + boxW - pad, ly + ligneH * 0.5,
            COL_LIB, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        ly = ly + ligneH
    end
    if reste > 0 then
        draw.SimpleText("+ " .. reste .. " autre" .. (reste > 1 and "s" or ""), "EVO_ListeStaff_Rang",
            x + pad, ly + ligneH * 0.5, COL_LIB, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    EVO_STAFF_LISTE_BAS = y + boxH
end

hook.Add("HUDPaint", "EVO::VoirStaffEnService", function()
    rafraichir()

    -- LISTE : la seule coche des actions rapides tranche (jAffiche), en service ou non.
    if jAffiche then dessinerListe() else EVO_STAFF_LISTE_BAS = 0 end

    -- REPÈRES 3D : réservés au SERVICE et à leur PROPRE réglage. ⚠ Surtout pas de
    -- sortie anticipée sur `jAffiche` ici : décocher la liste ne doit pas aveugler
    -- un staff en poste. `visibles` est déjà vide hors service, le test évite juste
    -- de parcourir la boucle.
    if not CVAR:GetBool() or not deService then return end

    local oeil = EyePos()
    for i = 1, #visibles do
        local e = visibles[i]
        local p = e.ply
        if IsValid(p) then
            local pos = p:GetPos()
            local dist = oeil:Distance(pos)
            -- `supervise` (responsable modérateur) : le repère porte sur TOUTE la map.
            -- La distance reste calculée — elle s'affiche dans le libellé, c'est même
            -- la seule info utile quand la cible est trop loin pour être vue.
            if supervise or dist <= DIST_MAX then
                local ecran = (pos + HAUTEUR):ToScreen()
                if ecran.visible then
                    local txt = e.nom .. "  ·  " .. math.floor(dist / 52) .. " m"
                    -- Ombre portée : lisible sur un fond clair comme sur un fond sombre.
                    draw.SimpleText(txt, "EVO_VoirStaff", ecran.x + 1, ecran.y + 1, COL_OMBRE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    draw.SimpleText(txt, "EVO_VoirStaff", ecran.x, ecran.y, e.col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    -- Point au sol : dit où il est POSÉ, pas seulement où flotte son nom.
                    local sol = pos:ToScreen()
                    if sol.visible then
                        surface.SetDrawColor(e.col.r, e.col.g, e.col.b, 170)
                        surface.DrawRect(sol.x - 2, sol.y - 2, 4, 4)
                    end
                end
            end
        end
    end
end)
