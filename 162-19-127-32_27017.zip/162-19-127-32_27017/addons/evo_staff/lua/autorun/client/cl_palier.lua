-- "addons\\evo_staff\\lua\\autorun\\client\\cl_palier.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF — pastille du PALIER DE PAYE, en bas a gauche sous le profil.
--
-- Une ligne, discrete, visible seulement par celui qu'elle concerne : « PALIER 2
-- · 15 EUR ». Elle repond a la seule question qu'un staff se pose en service :
-- est-ce que ce que je fais compte, et ou j'en suis.
--
-- FICHIER SEPARE, HOOK SEPARE. lzy_hud/cl_hud.lua est un gros HUD optimise au
-- doigt (fonts et chaines mises en cache par resolution pour ne rien
-- reconstruire par frame). Y ajouter un bloc, c'est prendre le risque de casser
-- ce travail pour trois mots. On dessine donc a cote, et si ce fichier disparait
-- le HUD ne s'en apercoit meme pas.
--
-- Rien n'est calcule ici : le serveur pose EVO_Palier / EVO_PalierPaye /
-- EVO_PalierResp (eux-memes lus depuis le site). Palier 0 et non-responsable =
-- rien a afficher, on ne dessine pas.
-- ============================================================================
if not CLIENT then return end

-- Meme echelle que le HUD principal, pour rester aligne avec le bloc profil
-- quelle que soit la resolution.
local function hScale() return math.min(ScrW() / 1920, ScrH() / 1080) end
local function hSz(v) return math.Round(v * hScale()) end
local function hYB(v) return ScrH() - hSz(1080 - v) end

local COUL = {
    [0] = Color(150, 154, 162),
    [1] = Color(143, 180, 240),
    [2] = Color(183, 155, 240),
    [3] = Color(95, 211, 152),
}
local RESP = Color(232, 180, 92)
local OMBRE = Color(0, 0, 0, 190)

local police = false
local function fontes()
    if not gCreateRespFont then return end
    gCreateRespFont("EVO_Palier_L", "Roboto", 13, 700)
    gCreateRespFont("EVO_Palier_S", "Roboto", 12, 500)
    police = true
end
hook.Add("Initialize", "EVO_Palier::Fonts", fontes)
hook.Add("OnScreenSizeChanged", "EVO_Palier::Fonts2", fontes)
fontes()

-- Le texte ne change qu'a la promotion : on le reconstruit alors, pas a chaque
-- frame. Meme discipline que le HUD d'a cote.
local cachePal, cacheMnt, cacheResp, cacheTxt, cacheSous

hook.Add("HUDPaint", "EVO_Palier::HUD", function()
    if not police then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local pal  = ply:GetEvoNWInt("EVO_Palier", 0)
    local mnt  = ply:GetEvoNWInt("EVO_PalierPaye", 0)
    local resp = ply:GetEvoNWBool("EVO_PalierResp", false)
    -- Rien a dire : pas de staff, ou palier zero et pas responsable. On ne
    -- dessine pas une pastille « PALIER 0 » a quelqu'un, ca ne l'aide pas.
    if not resp and (pal <= 0 or mnt <= 0) then return end

    -- Pendant une scene cinematique ou un menu plein ecran, on s'efface.
    if hook.Run("HUDShouldDraw", "CHudHealth") == false then return end

    if cachePal ~= pal or cacheMnt ~= mnt or cacheResp ~= resp then
        cachePal, cacheMnt, cacheResp = pal, mnt, resp
        cacheTxt = resp and "RESPONSABLE" or ("PALIER " .. pal)
        cacheSous = mnt .. " EUR boutique"
    end

    local coul = resp and RESP or (COUL[pal] or COUL[0])
    -- Sous le bloc profil (portrait + barres + anneau d'XP), colle a gauche.
    local x, y = hSz(41), hYB(1041)

    surface.SetFont("EVO_Palier_L")
    local lw = surface.GetTextSize(cacheTxt)
    surface.SetFont("EVO_Palier_S")
    local sw = surface.GetTextSize(cacheSous)
    local w = math.max(lw, sw) + hSz(26)
    local h = hSz(34)

    draw.RoundedBox(hSz(6), x, y, w, h, Color(12, 12, 15, 205))
    surface.SetDrawColor(coul.r, coul.g, coul.b, 190)
    surface.DrawRect(x, y, hSz(3), h)

    draw.SimpleTextOutlined(cacheTxt, "EVO_Palier_L", x + hSz(13), y + hSz(11),
        coul, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, OMBRE)
    draw.SimpleTextOutlined(cacheSous, "EVO_Palier_S", x + hSz(13), y + hSz(24),
        Color(190, 194, 202), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, OMBRE)
end)
