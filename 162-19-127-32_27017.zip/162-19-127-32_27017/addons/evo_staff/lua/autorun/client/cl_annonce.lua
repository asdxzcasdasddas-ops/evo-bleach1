-- "addons\\evo_staff\\lua\\autorun\\client\\cl_annonce.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF : ANNONCE AU STAFF (côté destinataire) — demande user 17/08.
--
-- Reçue via EVO_Dash::AnnonceRx, envoyée depuis le dashboard F8 par le
-- responsable modérateur (bouton « ANNONCE STAFF »).
--
-- POURQUOI PAS LE RENDU DE cl_mp.lua : le message privé floute tout l'écran et
-- pose le logo EVO au milieu. C'est fait pour un JOUEUR à qui on s'adresse, et
-- c'est très bien pour ça. Ici le destinataire est un modérateur qui est
-- peut-être en pleine intervention : lui voiler l'écran pendant 15 s serait
-- l'empêcher de travailler au moment précis où on lui demande de travailler.
-- D'où une plaque en HAUT, lisible sans rien masquer du jeu.
--
-- PLACEMENT : haut-CENTRE. La liste du staff (cl_voir_staff) occupe le
-- haut-droite ; centrer laisse les deux côte à côte sans se recouvrir, même en
-- 1280 de large.
--
-- La ligne part AUSSI dans le chat : une annonce qu'on a ratée pendant un
-- combat doit pouvoir se relire. La plaque, elle, s'efface.
-- ============================================================================
if not CLIENT then return end

local ACCENT   = Color(207, 68, 78)
local FOND     = Color(13, 14, 17, 238)
local LISERE   = Color(146, 152, 161, 55)
local TXT      = Color(236, 238, 242)
local TXT_DIM  = Color(165, 170, 182)

local FADE_IN, FADE_OUT = 0.25, 0.8

-- { texte, de, lib, lignes, debut, fin } ou nil quand rien à afficher.
local actif = nil

local function polices()
	local s = math.max(ScrH() / 1080, 0.5)
	surface.CreateFont("EVOAnnonce_Titre", { font = "Bebas Neue", size = math.floor(26 * s), weight = 400, antialias = true })
	surface.CreateFont("EVOAnnonce_Msg",   { font = "Roboto",     size = math.floor(21 * s), weight = 600, antialias = true })
	surface.CreateFont("EVOAnnonce_De",    { font = "Roboto",     size = math.floor(15 * s), weight = 700, antialias = true })
end
polices()
hook.Add("OnScreenSizeChanged", "EVO_Annonce::Polices", function()
	polices()
	-- Les lignes ont été découpées à l'ancienne largeur : elles ne veulent plus
	-- rien dire ici. On coupe l'annonce en cours plutôt que d'afficher un pavé
	-- qui déborde de sa plaque.
	actif = nil
end)

-- Coupe le texte en lignes qui tiennent dans maxW. Fait UNE FOIS à la réception,
-- jamais au dessin : le HUDPaint ne doit pas mesurer 5 lignes 60 fois par seconde.
local function lignes(texte, police, maxW)
	surface.SetFont(police)
	local out, courante = {}, ""
	for mot in string.gmatch(texte, "%S+") do
		local essai = courante == "" and mot or (courante .. " " .. mot)
		if surface.GetTextSize(essai) > maxW and courante ~= "" then
			out[#out + 1] = courante
			courante = mot
		else
			courante = essai
		end
	end
	if courante ~= "" then out[#out + 1] = courante end
	return out
end

net.Receive("EVO_Dash::AnnonceRx", function()
	local texte = net.ReadString()
	local de    = net.ReadString()
	local lib   = net.ReadString()
	local dura  = math.Clamp(net.ReadUInt(8), 5, 60)
	if texte == "" then return end

	local s    = math.max(ScrH() / 1080, 0.5)
	local boxW = math.min(math.floor(ScrW() * 0.42), math.floor(820 * s))
	actif = {
		texte  = texte,
		de     = de,
		lib    = lib,
		boxW   = boxW,
		lignes = lignes(texte, "EVOAnnonce_Msg", boxW - math.floor(36 * s)),
		debut  = CurTime(),
		fin    = CurTime() + dura,
	}

	-- Trace relisible : le HUD s'efface, le chat non.
	chat.AddText(ACCENT, "[Annonce staff] ", Color(200, 204, 214), de .. " · " .. lib .. " : ", TXT, texte)
	surface.PlaySound((EVO_UI and EVO_UI.SndClick) or "buttons/button15.wav")
end)

hook.Add("HUDPaint", "EVO_Annonce::Dessin", function()
	if not actif then return end
	local now = CurTime()
	if now >= actif.fin then actif = nil return end

	-- Fondu d'entrée et de sortie, en fraction 0..1.
	local k = math.min(1, (now - actif.debut) / FADE_IN)
	local reste = actif.fin - now
	if reste < FADE_OUT then k = math.min(k, reste / FADE_OUT) end
	if k <= 0 then return end
	local a = math.Round(255 * k)

	local s      = math.max(ScrH() / 1080, 0.5)
	local pad    = math.floor(18 * s)
	local titreH = math.floor(32 * s)
	local ligneH = math.floor(27 * s)
	local piedH  = math.floor(24 * s)
	local boxW   = actif.boxW
	local boxH   = titreH + #actif.lignes * ligneH + piedH + pad
	local x      = math.floor((ScrW() - boxW) / 2)
	local y      = math.floor(28 * s)

	-- Plaque Atelier : coin bas-droit coupé + liseré acier ; repli carré si le kit
	-- DA n'est pas chargé (le HUD ne doit jamais dépendre d'un autre addon).
	local fond = Color(FOND.r, FOND.g, FOND.b, math.Round(FOND.a * k))
	if EVO_UI and EVO_UI.PaintCut then
		local pts = EVO_UI.PaintCut(x, y, boxW, boxH, fond, math.floor(12 * s), "br")
		if EVO_UI.OutlineCut then
			EVO_UI.OutlineCut(pts, Color(LISERE.r, LISERE.g, LISERE.b, math.Round(LISERE.a * k)))
		end
	else
		draw.RoundedBox(0, x, y, boxW, boxH, fond)
	end
	surface.SetDrawColor(ACCENT.r, ACCENT.g, ACCENT.b, a)
	surface.DrawRect(x, y, math.max(2, math.floor(3 * s)), boxH) -- barre accent gauche (signature DA)

	draw.SimpleText("ANNONCE STAFF", "EVOAnnonce_Titre", x + pad, y + math.floor(6 * s),
		Color(ACCENT.r, ACCENT.g, ACCENT.b, a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	local ly = y + titreH
	for i = 1, #actif.lignes do
		draw.SimpleText(actif.lignes[i], "EVOAnnonce_Msg", x + pad, ly,
			Color(TXT.r, TXT.g, TXT.b, a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		ly = ly + ligneH
	end

	draw.SimpleText(string.upper(actif.de or "") .. "  ·  " .. (actif.lib or ""), "EVOAnnonce_De",
		x + boxW - pad, ly + math.floor(4 * s),
		Color(TXT_DIM.r, TXT_DIM.g, TXT_DIM.b, math.Round(a * 0.8)), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
end)
