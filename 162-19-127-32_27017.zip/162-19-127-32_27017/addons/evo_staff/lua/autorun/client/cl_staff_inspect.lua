-- "addons\\evo_staff\\lua\\autorun\\client\\cl_staff_inspect.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF — INSPECTION (client)
-- En mode staff (!staff), vise un joueur + E -> panneau d'inspection complet
-- dans la DA EVO_UI : identité, grade SAM, niveau/xp, yens/coins/premium,
-- faction, RP, vie, temps de jeu, stats et inventaire (équipé + sac) résolu.
-- Le menu contextuel "Inspecter (staff)" appelle aussi EVO_RequestInspect.
-- EN NOCLIP, vise un joueur + F -> la MÊME carte ÉPINGLÉE à l'écran (pas de
-- capture souris, on continue de voler) ; Échap la retire (demande user 07/23).
--
-- RESPONSIVE : posé en unités de base (1920x1080), mis à l'échelle UNE fois via
-- R() avec un facteur UNIFORME -> proportions conservées sur tous les écrans.
-- ============================================================================

if not CLIENT then return end

local pInspect

-- Échelle uniforme (même X/Y) -> pas de déformation sur écrans non-16:9.
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

-- ── Palette (fallback si EVO_UI pas encore chargé) ──────────────────────────
local function C() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18),
	title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118),
	accent = Color(207,68,78), green = Color(78,196,128), red = Color(199,70,80) } end

local RARITY = {
	common    = Color(150, 154, 162),
	rare      = Color(80, 150, 230),
	epic      = Color(170, 100, 220),
	legendary = Color(224, 176, 60),
	mythic    = Color(207, 68, 78),
}
local PREMIUM = { [0] = "Aucun", [1] = "Premium", [2] = "VIP", [3] = "Platinum" }

-- ── Fonts (evo_staff charge avant glibs -> on diffère) ──────────────────────
local function MakeFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("EVO_Insp_Title", "Bebas Neue", 24, 700)
	gCreateRespFont("EVO_Insp_Name",  "Roboto", 19, 700)
	gCreateRespFont("EVO_Insp_Sec",   "Roboto", 13, 700)
	gCreateRespFont("EVO_Insp_Label", "Roboto", 13, 500)
	gCreateRespFont("EVO_Insp_Val",   "Roboto", 14, 600)
	gCreateRespFont("EVO_Insp_Small", "Roboto", 12, 500)
end
hook.Add("Initialize", "EVO_Insp::FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Insp::Fonts", MakeFonts)
MakeFonts()

-- ── Helpers ─────────────────────────────────────────────────────────────────
local function fmtNum(n)
	n = tostring(math.floor(tonumber(n) or 0))
	local out = n:reverse():gsub("(%d%d%d)", "%1 "):reverse()
	return (out:gsub("^%s+", ""))
end
local function fmtTime(sec)
	sec = tonumber(sec) or 0
	local h = math.floor(sec / 3600)
	local m = math.floor((sec % 3600) / 60)
	if h > 0 then return h .. "h " .. m .. "m" end
	return m .. "m"
end

-- Libellé court d'une action de sanction (historique inspection / dashboard).
local SANCTION_LABEL = {
	ban = "Ban", kick = "Kick", mute = "Mute", gag = "Gag",
	warn = "Warn", ["warn.ban"] = "Warn→Ban", unwarn = "Unwarn",
	["sam.jail"] = "Jail", ["sam.slay"] = "Slay", ["sam.unban"] = "Unban",
	["sam.unmute"] = "Unmute", ["sam.ungag"] = "Ungag",
	["sam.freeze"] = "Freeze", ["sam.unfreeze"] = "Unfreeze",
	["dash.rename"] = "Rename", ["dash.ck"] = "CK",
	["dash.mute"] = "Mute", ["dash.unmute"] = "Unmute",
	["dash.freeze"] = "Freeze", ["dash.unfreeze"] = "Unfreeze",
	["ctx.kick"] = "Kick", ["ctx.ban"] = "Ban", ["ctx.gag"] = "Gag",
}
local function prettySanction(action)
	action = tostring(action or "")
	if SANCTION_LABEL[action] then return SANCTION_LABEL[action] end
	if string.sub(action, 1, 5) == "dash." then return string.upper(string.sub(action, 6, 6)) .. string.sub(action, 7) end
	if string.sub(action, 1, 4) == "sam." then return string.sub(action, 5) end
	return action
end
local function fmtSanctionWhen(ts)
	ts = tonumber(ts) or 0
	if ts <= 0 then return "—" end
	return os.date("%d/%m/%y %H:%M", ts)
end

-- L'art spirituel networké (NWString "ArtSpirituel") est une CLÉ de catégorie skilltree
-- (ex "CoyoteStarrk", "Aizen", "yammyLlargo"). Toutes ces catégories ont name="Art Spirituel"
-- (générique) -> la clé (= le personnage) est l'info utile. On la met en forme : on insère un
-- espace aux transitions minuscule->MAJUSCULE puis on capitalise la 1re lettre. Vide -> "Aucun".
local function fmtArtSpirituel(key)
	if not key or key == "" then return "Aucun" end
	local pretty = tostring(key):gsub("(%l)(%u)", "%1 %2")
	return pretty:sub(1, 1):upper() .. pretty:sub(2)
end

-- Tronque un texte à `maxW` pixels (police donnée), avec ellipse. Préserve les
-- codepoints UTF-8 (accents FR). Utilisé pour les grades faction longs qui
-- recouvraient sinon le libellé de la ligne (« Rang », « Nom RP »…).
-- PERF (10/02, bug staff « grosse perte de FPS avec la fiche F ») : l'ancienne version
-- retirait UN caractère à la fois avec utf8.sub (écrit en Lua, très lent) et tournait à
-- CHAQUE image pour chaque ligne. Mesuré en local : 115 ms par image (8 FPS) dès que le
-- joueur inspecté a 30 sanctions à l'historique, 0,5 ms sans historique. Ici : recherche
-- par dichotomie (une dizaine de mesures au lieu de centaines), et les appelants gardent
-- le résultat au lieu de le recalculer à chaque image.
local function ellipsize(text, font, maxW)
	text = tostring(text or "")
	maxW = tonumber(maxW) or 0
	if maxW <= 0 or text == "" then return text end
	surface.SetFont(font)
	if select(1, surface.GetTextSize(text)) <= maxW then return text end
	local ell = "…"
	local ew = select(1, surface.GetTextSize(ell))
	if ew >= maxW then return ell end
	local budget = maxW - ew
	-- Positions où l'on peut couper sans casser un caractère UTF-8 : l'octet suivant
	-- n'est pas un octet de suite (128 à 191).
	local fins = {}
	for i = 1, #text do
		local b = string.byte(text, i + 1)
		if not b or b < 128 or b >= 192 then fins[#fins + 1] = i end
	end
	-- Plus grand nombre de caractères qui tient dans `budget`.
	local lo, hi = 0, #fins
	while lo < hi do
		local mid = math.ceil((lo + hi) / 2)
		if select(1, surface.GetTextSize(string.sub(text, 1, fins[mid]))) <= budget then
			lo = mid
		else
			hi = mid - 1
		end
	end
	return (lo > 0 and string.sub(text, 1, fins[lo]) or "") .. ell
end

-- Armés avant OpenInspect / Think (closures) — forward-decl pour rester locaux.
local _pinNext = false
local _pendingTrack = nil

-- Ciblage robuste (surtout en noclip) : un TraceLine seul rate souvent le corps
-- (hitboxes fines / EyePos dans un brush = startsolid → hit monde immédiat).
-- Même stratégie que le property menu / radial : line → hull → proximité rayon.
--
-- EyePos()/GetAimVector() hors rendu sont FAUX / périmés (surtout à l'arrêt :
-- orbite, 3e perso). On cache la vue en PreDrawEffects — comme le property menu.
local AIM_DIST     = 5000
local AIM_PERP_SQ  = 40 * 40 -- pick initial (E/F)
local AIM_BODY_OZ  = { 12, 28, 44, 60, 72 }

local lastAimEye = vector_origin
local lastAimDir = Vector(1, 0, 0)

hook.Add("PreDrawEffects", "EVO_Staff::CacheAimView", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Orbite (immobile) : aim corps figé ≠ caméra — GetView = ce que le joueur VOIT.
	if CitronOrbitCam and CitronOrbitCam.GetView then
		local v, a = CitronOrbitCam.GetView()
		if v and a then
			lastAimEye, lastAimDir = v, a:Forward()
			return
		end
	end
	lastAimEye = EyePos()
	lastAimDir = EyeAngles():Forward()
end)

local function GetAimEyeDir()
	if lastAimDir:LengthSqr() < 0.25 then
		return EyePos(), EyeAngles():Forward()
	end
	return lastAimEye, lastAimDir
end

local function RayToPlayerDistSq(eyePos, eyeVec, ply)
	local pos = ply:GetPos()
	local best = math.huge
	for i = 1, #AIM_BODY_OZ do
		local center = pos + Vector(0, 0, AIM_BODY_OZ[i])
		local diff = center - eyePos
		local t = diff:Dot(eyeVec)
		if t < 0 or t > AIM_DIST then continue end
		local d2 = (center - (eyePos + eyeVec * t)):LengthSqr()
		if d2 < best then best = d2 end
	end
	return best
end

local function AimedPlayer()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end

	local eye, dir = GetAimEyeDir()
	local endpos = eye + dir * AIM_DIST

	local tr = util.TraceLine({
		start = eye, endpos = endpos, filter = lp, mask = MASK_SHOT,
	})
	local e = tr.Entity
	if IsValid(e) and e:IsPlayer() and e:Alive() then return e end

	local tr2 = util.TraceHull({
		start = eye, endpos = endpos,
		mins = Vector(-12, -12, -12), maxs = Vector(12, 12, 12),
		filter = lp, mask = MASK_SHOT_HULL,
	})
	e = tr2.Entity
	if IsValid(e) and e:IsPlayer() and e:Alive() then return e end

	-- Fallback géométrique : ignore occlusion / startsolid (noclip à travers les murs).
	local best, bestD2 = nil, AIM_PERP_SQ
	local maxDistSq = AIM_DIST * AIM_DIST
	for _, ply in player.Iterator() do
		if ply == lp or not ply:Alive() then continue end
		if eye:DistToSqr(ply:GetPos()) > maxDistSq then continue end
		local d2 = RayToPlayerDistSq(eye, dir, ply)
		if d2 < bestD2 then
			bestD2 = d2
			best = ply
		end
	end
	return best
end

-- Demande d'inspection (utilisée par la touche E ET le menu contextuel "Inspecter").
function EVO_RequestInspect(target)
	if not IsValid(target) or not target:IsPlayer() then return end
	-- Toujours mémoriser la cible : le bouton Dashboard de la carte seed la fiche
	-- depuis cette entité live (sans ça E ouvrait le dash sans profil).
	_pendingTrack = target
	net.Start("EVO:Staff:Inspect")
	net.WriteEntity(target)
	net.SendToServer()
end

-- Petite croix de fermeture (échelle uniforme).
local function CloseBtn(parent, cardWbase, fClose)
	local col = C()
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(R(28), R(28))
	b:SetPos(R(cardWbase - 42), R(19))
	b.Paint = function(s, w, h)
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.title or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClose
	return b
end

-- ── Colonne gauche : infos (rendu en lignes empilées) ───────────────────────
local function buildRows(d)
	local rows = {}
	local function sec(t)   rows[#rows + 1] = { k = "sec", t = t } end
	local function f(l, v, c) rows[#rows + 1] = { k = "f", l = l, v = tostring(v), c = c } end
	local function bar(frac, txt) rows[#rows + 1] = { k = "bar", frac = frac, t = txt } end
	local function gap()    rows[#rows + 1] = { k = "gap" } end

	sec("Identité")
	f("Nom RP", d.name ~= "" and d.name or "—")
	f("Steam", d.steamName or "—")
	f("SteamID", d.steamid or "—")
	f("Grade", d.rank or "user", (EVO_UI and EVO_UI.Col.accent))
	gap()

	sec("Progression")
	f("Niveau", d.level or 1)
	if (d.maxexp or 0) > 0 then bar(math.Clamp((d.exp or 0) / d.maxexp, 0, 1), fmtNum(d.exp) .. " / " .. fmtNum(d.maxexp) .. " XP") end
	f("Yens", fmtNum(d.money) .. " ¥")
	-- Coins / Premium : réservés au SUPERADMIN (demande user 09/24).
	local lp = LocalPlayer()
	if IsValid(lp) and lp:IsSuperAdmin() then
		f("Coins", fmtNum(d.coins))
		f("Premium", PREMIUM[d.premium or 0] or tostring(d.premium))
	end
	-- Art spirituel TOUJOURS affiché (même « Aucun ») — mis en évidence quand défini.
	do
		local hasArt = d.art and d.art ~= ""
		f("Art spirituel", fmtArtSpirituel(d.art),
			hasArt and (EVO_UI and EVO_UI.Col.accent) or (EVO_UI and EVO_UI.Col.dim))
	end
	f("Style de combat", (d.style and d.style ~= "") and d.style or "—")
	gap()

	if d.faction and d.faction ~= "" then
		sec("Faction")
		f("Faction", d.faction)
		if (d.facRank or 0) > 0 then f("Rang", LZY_FACTION_CONFIG.RankName(d.faction, d.facRank)) end
		if (d.facDiv or 0) > 0 then f(LZY_FACTION_CONFIG.DivisionWord(d.faction), LZY_FACTION_CONFIG.DivisionName(d.faction, d.facDiv)) end
		gap()
	end

	if d.finisher and d.finisher ~= "" then
		sec("RP")
		f("Finisher", d.finisher)
		gap()
	end

	sec("État")
	f("Vie", math.floor(d.health or 0) .. " / " .. math.floor(d.maxhealth or 0))
	f("Temps de jeu", fmtTime(d.playtime))
	f("Warns", tostring(d.warns or 0), (tonumber(d.warns) or 0) > 0 and (EVO_UI and EVO_UI.Col.accent) or nil)

	-- Historique sanctions (warn/ban/kick/rename…) — scrollable via la colonne gauche.
	do
		gap()
		sec("Historique")
		local hist = istable(d.history) and d.history or {}
		if #hist == 0 then
			f("—", "Aucune sanction enregistrée", EVO_UI and EVO_UI.Col.dim)
		else
			for _, h in ipairs(hist) do
				local when = fmtSanctionWhen(h.ts)
				local act = prettySanction(h.action)
				local who = tostring(h.staff or "?")
				local det = tostring(h.details or "")
				local right = who
				if det ~= "" then right = who .. " — " .. det end
				f(when .. " · " .. act, right,
					(act == "Ban" or act == "CK" or act == "Warn→Ban") and (EVO_UI and EVO_UI.Col.accent) or nil)
			end
		end
	end

	if istable(d.stats) and #d.stats > 0 then
		gap()
		sec("Stats")
		for _, s in ipairs(d.stats) do f(s.label, s.value) end
	end

	return rows
end

-- ── Ouverture du panneau ────────────────────────────────────────────────────
-- pinned = mode ÉPINGLÉ (F en noclip) : pas de MakePopup -> la souris reste au
-- jeu et on continue de voler ; pas de voile/flou (le monde reste visible) ;
-- carte collée à droite. Reste jusqu'à F (toggle) / Échap / sortie noclip.

local function OpenInspect(d, pinned, trackEnt)
	MakeFonts()
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	if IsValid(pInspect) then pInspect:Remove() end
	local col = C()

	local CARD_W, CARD_H = 860, 560
	local PAD = 24
	local L_X, L_W = PAD, 384
	local R_X = L_X + L_W + 24
	local R_W = CARD_W - R_X - PAD
	local HEAD_H = 64
	local cardW, cardH = R(CARD_W), R(CARD_H)

	-- Backdrop plein écran flouté (flou non clippé), carte enfant (coins propres).
	pInspect = vgui.Create("DFrame")
	pInspect:SetSize(ScrW(), ScrH())
	pInspect:SetPos(0, 0)
	pInspect:SetTitle("") pInspect:ShowCloseButton(false) pInspect:SetDraggable(false)
	if pinned then
		pInspect:SetMouseInputEnabled(false)
		pInspect:SetKeyboardInputEnabled(false)
	else
		pInspect:MakePopup()
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pInspect) end
	pInspect._pinned = pinned
	pInspect._trackEnt = trackEnt
	pInspect._a = 0
	pInspect.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	pInspect.Paint = function(s, w, h)
		if pinned then return end
		local a = s._a / 255
		if a < 0.01 then return end
		if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 5) end
		surface.SetDrawColor(0, 0, 0, 150 * a)
		surface.DrawRect(0, 0, w, h)
	end
	pInspect.OnMousePressed = function() if not pinned and IsValid(pInspect) then pInspect:Remove() end end

	local card = vgui.Create("DPanel", pInspect)
	card:SetSize(cardW, cardH)
	if pinned then
		card:SetPos(ScrW() - cardW - R(24), math.floor((ScrH() - cardH) / 2))
	else
		card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	end
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (pInspect and pInspect._a or 255) / 255
		if a < 0.01 then return end
		if EVO_UI then EVO_UI.PaintCard(w, h, a, R(16)) else RNDX.Draw(R(16), 0, 0, w, h, col.bg) end
		-- header : accent + titre + nom RP (+ steam si différent) + grade SAM à droite.
		-- Le grade (ex. RESPONSABLE_MODERATEUR) est tronqué pour ne jamais manger le nom.
		surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
		surface.DrawRect(R(24), R(24), R(3), R(18))
		draw.SimpleText("INSPECTION", "EVO_Insp_Title", R(38), R(33), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		local rightPad = R(58)
		local nameX = R(160)
		-- Grade et nom tronqués calculés UNE fois (refaits si la largeur change), pas à
		-- chaque image : les données de la fiche ne bougent pas après l'ouverture.
		if s._enteteW ~= w then
			s._enteteW = w
			s._rankTxt = ellipsize(string.upper(tostring(d.rank or "user")), "EVO_Insp_Small", R(150))
			surface.SetFont("EVO_Insp_Small")
			local rankW = select(1, surface.GetTextSize(s._rankTxt))
			local rpName = (d.name and d.name ~= "") and d.name or ""
			local steam = d.steamName or ""
			local nameMax = (w - rightPad - rankW - R(16)) - nameX
			if nameMax < R(48) then nameMax = R(48) end
			-- Nom RP prioritaire ; si steam diffère on l'ajoute (« RP · steam »), le tout
			-- tronqué dans l'espace restant (sinon le grade long le masquait).
			local nameLine = rpName ~= "" and rpName or steam
			if rpName ~= "" and steam ~= "" and steam ~= rpName then
				nameLine = rpName .. "  ·  " .. steam
			end
			s._nameLine = ellipsize(nameLine, "EVO_Insp_Name", nameMax)
		end
		draw.SimpleText(s._rankTxt, "EVO_Insp_Small", w - rightPad, R(34), ColorAlpha(col.accent, 255 * a), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(s._nameLine, "EVO_Insp_Name", nameX, R(34), ColorAlpha(col.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- filets
		surface.SetDrawColor(ColorAlpha(col.divider, 150 * a))
		surface.DrawRect(R(24), R(HEAD_H - 6), w - R(48), 1)
		surface.DrawRect(R(R_X - 12), R(HEAD_H + 6), 1, h - R(HEAD_H + 18))
	end

	CloseBtn(card, CARD_W, function() pInspect:Remove() end)

	-- Bouton → dashboard staff sur CE joueur (carte E centrée uniquement :
	-- la carte F épinglée n'a pas de souris). Ferme l'inspection et ouvre
	-- le dashboard avec la fiche pré-sélectionnée.
	if not pinned then
		local sid64 = tostring(d.steamid64 or "")
		if string.sub(sid64, 1, 1) == "#" then sid64 = string.sub(sid64, 2) end
		-- Visible dès qu'on a une entité trackée OU un sid (même imparfait).
		if IsValid(trackEnt) or sid64 ~= "" then
			local dashBtn = vgui.Create("DButton", card)
			dashBtn:SetText("")
			dashBtn:SetCursor("hand")
			dashBtn:SetSize(R(148), R(28))
			dashBtn:SetPos(R(CARD_W - 42 - 156), R(19))
			dashBtn.Paint = function(s, w, h)
				local hov = s:IsHovered()
				if RNDX and RNDX.Draw then
					RNDX.Draw(R(6), 0, 0, w, h, ColorAlpha(col.accent, hov and 255 or 200))
				else
					surface.SetDrawColor(ColorAlpha(col.accent, hov and 255 or 200))
					surface.DrawRect(0, 0, w, h)
				end
				draw.SimpleText("DASHBOARD", "EVO_Insp_Small", w / 2, h / 2, col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			dashBtn.DoClick = function()
				local ply = IsValid(trackEnt) and trackEnt or nil
				local uid = ply and ply:UserID() or nil
				local sid = sid64
				if ply then
					local ok, live = pcall(function() return ply:SteamID64() end)
					if ok and live ~= nil then
						live = tostring(live)
						if string.sub(live, 1, 1) == "#" then live = string.sub(live, 2) end
						if live:match("^%d+$") then sid = live end
					end
				end
				-- Fermer l'inspection PUIS ouvrir le dashboard au tick suivant :
				-- Remove() + MakePopup dans le même DoClick rate souvent le 1er clic.
				if IsValid(pInspect) then pInspect:Remove() end
				timer.Simple(0, function()
					-- 3e arg = entité live → seed immédiat de la fiche (pas d'attente snap).
					if EVO_OpenStaffDashboard then EVO_OpenStaffDashboard(sid, uid, ply) end
				end)
			end
		end
	end

	-- Scrollbar DA commune aux deux colonnes.
	local function styleInspScroll(scroll)
		local sb = scroll:GetVBar()
		if not IsValid(sb) then return end
		sb:SetWide(R(5))
		sb:SetHideButtons(true)
		sb.Paint = function() end
		sb.btnUp.Paint, sb.btnDown.Paint = function() end, function() end
		sb.btnGrip.Paint = function(s, w, h)
			local hov = s:IsHovered()
			RNDX.Draw(R(3), 0, 0, w, h, ColorAlpha(hov and col.accent or col.dim, hov and 200 or 120))
		end
	end

	-- Hauteur du contenu gauche (même pas que le Paint) pour dimensionner le canvas scrollable.
	local function rowsHeight(list)
		local y = R(2)
		for _, r in ipairs(list) do
			if r.k == "sec" then y = y + R(27)
			elseif r.k == "f" then y = y + R(21)
			elseif r.k == "bar" then y = y + R(20)
			elseif r.k == "gap" then y = y + R(12)
			end
		end
		return y + R(8)
	end

	-- ── Colonne gauche : infos (scrollable — demande user 09/24) ──
	local rows = buildRows(d)
	local leftH = R(CARD_H - HEAD_H - 26)
	local leftScroll = vgui.Create("DScrollPanel", card)
	leftScroll:SetPos(R(L_X), R(HEAD_H + 10))
	leftScroll:SetSize(R(L_W), leftH)
	leftScroll:SetPaintBackground(false)
	styleInspScroll(leftScroll)

	local left = vgui.Create("DPanel", leftScroll)
	left:Dock(TOP)
	left:DockMargin(0, 0, R(4), 0)
	left:SetTall(math.max(leftH, rowsHeight(rows)))
	left:SetPaintBackground(false)
	left.Paint = function(s, w, h)
		local a = (pInspect and pInspect._a or 255) / 255
		local y = R(2)
		-- Bande visible de la colonne (elle défile) : une ligne hors de la vue avance `y`
		-- sans rien dessiner. L'historique fait vite 30 lignes sous le pli.
		local vbar = leftScroll:GetVBar()
		local vueHaut = IsValid(vbar) and vbar:GetScroll() or 0
		local vueBas = vueHaut + leftScroll:GetTall()
		for _, r in ipairs(rows) do
			local hLigne = (r.k == "sec" and R(27)) or (r.k == "f" and R(21)) or (r.k == "bar" and R(20)) or R(12)
			if y + hLigne < vueHaut or y > vueBas then
				if r.k == "f" and r.l == "SteamID" then s._sidY = y end
				y = y + hLigne
			elseif r.k == "sec" then
				surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
				surface.DrawRect(0, y + R(3), R(3), R(11))
				draw.SimpleText(string.upper(r.t), "EVO_Insp_Sec", R(9), y, ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				surface.SetDrawColor(ColorAlpha(col.divider, 120 * a))
				surface.DrawRect(0, y + R(19), w, 1)
				y = y + R(27)
			elseif r.k == "f" then
				-- Libellé à gauche (jamais masqué) : la valeur à droite est tronquée
				-- dans l'espace restant (grades faction type « Shinigami de troisième
				-- classe » débordaient sinon sur « Rang »).
				-- Valeur tronquée gardée sur la ligne (refaite si la largeur change) : la
				-- recalculer à chaque image coûtait 115 ms par image avec un historique.
				if r._w ~= w then
					r._w = w
					surface.SetFont("EVO_Insp_Label")
					local labelW = select(1, surface.GetTextSize(r.l or ""))
					r._val = ellipsize(r.v, "EVO_Insp_Val", math.max(R(40), w - labelW - R(12)))
				end
				local val = r._val
				draw.SimpleText(r.l, "EVO_Insp_Label", 0, y, ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				-- Ligne SteamID copiable (demande user) : on mémorise sa bande Y pour le hit-test clic,
				-- et un survol l'accentue (indice visuel qu'on peut cliquer pour copier).
				local hovSid = (r.l == "SteamID" and s._sidHover)
				MUGEN.DrawMoneyLine(val, "EVO_Insp_Val", w, y, ColorAlpha(hovSid and col.accent or (r.c or col.title), 255 * a), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				if r.l == "SteamID" then s._sidY = y end
				y = y + R(21)
			elseif r.k == "bar" then
				local bh = R(8)
				RNDX.Draw(R(4), 0, y + R(2), w, bh, ColorAlpha(color_white, 12 * a))
				if r.frac > 0 then RNDX.Draw(R(4), 0, y + R(2), w * r.frac, bh, ColorAlpha(col.accent, 230 * a)) end
				draw.SimpleText(r.t, "EVO_Insp_Small", w / 2, y + R(1), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				y = y + R(20)
			elseif r.k == "gap" then
				y = y + R(12)
			end
		end
	end

	-- Clic sur la ligne SteamID = copie dans le presse-papier (demande user 2026-07-22).
	local SID_H = R(21)
	left:SetMouseInputEnabled(true)
	left:SetCursor("hand")
	left.Think = function(s)
		local mx, my = s:CursorPos()
		s._sidHover = s:IsHovered() and s._sidY ~= nil
			and mx >= 0 and mx <= s:GetWide() and my >= s._sidY and my <= s._sidY + SID_H
	end
	left.OnMousePressed = function(s, key)
		if key ~= MOUSE_LEFT or not s._sidHover then return end
		local sid = tostring(d.steamid or "")
		if sid == "" or sid == "—" then return end
		SetClipboardText(sid)
		surface.PlaySound("ui/buttonclickrelease.wav")
		if chat and chat.AddText then
			chat.AddText(Color(120, 200, 255), "[Staff] ", color_white, "SteamID copié : " .. sid)
		end
	end

	-- ── Colonne droite : inventaire (scrollable) ──
	local titleR = vgui.Create("DLabel", card)
	titleR:SetFont("EVO_Insp_Sec") titleR:SetTextColor(col.title)
	titleR:SetText("INVENTAIRE")
	titleR:SetPos(R(R_X), R(HEAD_H + 12)) titleR:SetSize(R(R_W), R(18))

	local inv = d.inv or { equipped = {}, bag = {} }
	local nEq, nBag = #(inv.equipped or {}), #(inv.bag or {})
	local sub = vgui.Create("DLabel", card)
	sub:SetFont("EVO_Insp_Small") sub:SetTextColor(col.dim)
	sub:SetText(nEq .. " équipé(s) · " .. nBag .. " en sac")
	sub:SetPos(R(R_X), R(HEAD_H + 30)) sub:SetSize(R(R_W), R(16))

	local scroll = vgui.Create("DScrollPanel", card)
	scroll:SetPos(R(R_X), R(HEAD_H + 52))
	scroll:SetSize(R(R_W), R(CARD_H - HEAD_H - 70))
	styleInspScroll(scroll)

	local function addHeader(t)
		local l = vgui.Create("DLabel", scroll)
		l:Dock(TOP) l:DockMargin(0, R(6), 0, R(4)) l:SetTall(R(18))
		l:SetFont("EVO_Insp_Small") l:SetTextColor(col.muted) l:SetText(string.upper(t))
	end
	local function addItem(it, isEquip)
		local r = vgui.Create("DPanel", scroll)
		r:Dock(TOP) r:DockMargin(0, 0, R(8), R(6)) r:SetTall(R(40)) r:SetPaintBackground(false)
		local rc = RARITY[it.rarity or "common"] or col.muted
		r.Paint = function(s, w, h)
			RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(color_white, 7))
			-- pastille rareté à gauche
			RNDX.Draw(R(3), R(10), h / 2 - R(8), R(4), R(16), rc)
			draw.SimpleText(it.name or "?", "EVO_Insp_Val", R(24), R(8), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local sub2 = isEquip and (it.slot or "") or ("Slot " .. (it.slot or "?"))
			draw.SimpleText(sub2, "EVO_Insp_Small", R(24), R(23), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			-- durabilité (si applicable)
			if it.dura ~= nil then
				local dv = math.floor(it.dura)
				local dc = dv <= 20 and col.red or (dv <= 50 and Color(224,162,60) or col.green)
				draw.SimpleText(dv .. "%", "EVO_Insp_Small", w - R(12), h / 2, dc, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	if nEq == 0 and nBag == 0 then
		local l = vgui.Create("DLabel", scroll)
		l:Dock(TOP) l:SetTall(R(30)) l:SetFont("EVO_Insp_Label") l:SetTextColor(col.dim)
		l:SetText("Inventaire vide.")
	else
		if nEq > 0 then
			addHeader("Équipé")
			for _, it in ipairs(inv.equipped) do addItem(it, true) end
		end
		if nBag > 0 then
			addHeader("Sac")
			for _, it in ipairs(inv.bag) do addItem(it, false) end
		end
	end
end

-- F épinglé : reste collée jusqu'à F (toggle) / Échap / sortie noclip.
-- Pas de close auto sur perte de visée (demande user).
hook.Add("Think", "EVO_Staff::PinnedInspectTrack", function()
	if not IsValid(pInspect) or not pInspect._pinned then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or lp:GetMoveType() ~= MOVETYPE_NOCLIP then
		pInspect:Remove()
	end
end)

-- Le prochain InspectData ouvre-t-il en mode épinglé ? (armé par F uniquement.)
-- (_pinNext / _pendingTrack déclarés plus haut pour les closures OpenInspect.)

net.Receive("EVO:Staff:InspectData", function()
	local json = net.ReadString()
	local d = util.JSONToTable(json or "")
	local pin = _pinNext
	local track = _pendingTrack
	_pinNext = false
	_pendingTrack = nil
	if not istable(d) then return end

	-- Déjà la carte épinglée de CE joueur : ne pas rebuild (évite un flash / close).
	if pin and IsValid(pInspect) and pInspect._pinned
		and IsValid(track) and pInspect._trackEnt == track then
		return
	end

	OpenInspect(d, pin, track)
end)

-- ── Déclencheur touche E (en mode staff, en visant un joueur) ───────────────
-- Carte CENTRÉE (MakePopup) — même en noclip. F = carte épinglée à droite.
hook.Add("PlayerButtonDown", "EVO_Staff::InspectKey", function(p, btn)
	if p ~= LocalPlayer() then return end
	if btn ~= KEY_E then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:GetEvoNWBool("EVO_StaffMode", false) then return end
	-- Une carte CENTRÉE déjà ouverte : ignore (Échap / clic dehors pour fermer).
	-- Une carte ÉPINGLÉE (F) ne bloque pas E : l'inspection centrale la remplace.
	if IsValid(pInspect) and not pInspect._pinned then return end
	if vgui.GetKeyboardFocus() then return end -- on tape dans un champ
	local tgt = AimedPlayer()
	if not IsValid(tgt) then return end
	_pinNext = false
	_pendingTrack = tgt -- requis pour le bouton Dashboard (seed fiche live)
	EVO_RequestInspect(tgt)
end)

-- ── Déclencheur touche F (en NOCLIP) : TOGGLE carte ÉPINGLÉE à droite ───────
-- F vise + ouvre → reste collée même sans viser ; F à nouveau → décroche.
-- Miroir client des groupes de canInspect serveur (lookup lowercase) : le gate
-- d'autorité reste le serveur, ceci évite juste des requêtes réseau pour rien.
local PIN_GROUPS = {
	moderator = true, ["modérateur"] = true, moderateur = true,
	moderateur_plus = true, ["moderateur plus"] = true,
	admin = true, administrateur = true, superadmin = true, ["super-admin"] = true,
	owner = true, fondateur = true, developer = true,
}
hook.Add("PlayerButtonDown", "EVO_Staff::PinInspectKey", function(p, btn)
	if p ~= LocalPlayer() then return end
	if btn ~= KEY_F then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	if lp:GetMoveType() ~= MOVETYPE_NOCLIP then return end
	if vgui.GetKeyboardFocus() then return end -- on tape dans un champ
	if not (lp:IsSuperAdmin() or lp:GetEvoNWBool("EVO_StaffMode", false)
		or PIN_GROUPS[string.lower(lp:GetUserGroup() or "")]) then return end

	-- Déjà épinglée → F décroche (toggle).
	if IsValid(pInspect) and pInspect._pinned then
		pInspect:Remove()
		return
	end

	local tgt = AimedPlayer()
	if not IsValid(tgt) then return end
	_pinNext = true
	_pendingTrack = tgt
	EVO_RequestInspect(tgt)
end)

-- Diagnostic : `evo_inspect` vise un joueur et ouvre l'inspection.
concommand.Add("evo_inspect", function()
	local tgt = AimedPlayer()
	if IsValid(tgt) then EVO_RequestInspect(tgt) else print("[evo_staff] vise un joueur d'abord") end
end)

-- ══════════════════════════════════════════════════════════════════════════════
-- TAGS STAFF AU-DESSUS DE LA TÊTE — en NOCLIP (demande user 07/20 : « repérer
-- rapidement » le staff). Affiche un tag au-dessus des joueurs des groupes SAM
-- listés dans NOCLIP_TAGS ci-dessous (alias inclus, cf.
-- sv_staff_ranks). Sans test de LOS : en noclip on survole la map, le tag se voit
-- à travers les murs (HUDPaint + ToScreen). Portée bornée à 6000u.
-- VIEWERS (07/22) : SUPERADMIN = tous les tags ; MODÉRATEUR en noclip = SEULEMENT
-- le tag STREAMER (repérer un stream en cours sans exposer le reste du staff).
-- Le tag SUPERADMIN n'est visible QUE par les autres SA (coordination : un SA
-- cloaké — corps SetNoDraw — reste transmis, donc son tag s'affiche quand même).
-- ══════════════════════════════════════════════════════════════════════════════
surface.CreateFont("EVO_StaffNoclipTag", { font = "Roboto", size = 22, weight = 800, antialias = true })

local TAG_MODO = { label = "MODÉRATEUR", col = Color(90, 140, 220), forRespo = true }
local TAG_MODO_PLUS = { label = "MODO+", col = Color(70, 160, 240), forRespo = true }
local TAG_MJ = { label = "MJ", col = Color(224, 120, 200) }
local TAG_MJ_PLUS = { label = "MJ+", col = Color(240, 100, 190) }
-- Lookup en LOWERCASE (07/21, même correctif que CanStaffMode) : le groupe SAM réel peut
-- porter n'importe quelle casse (« Moderateur », « MODÉRATEUR »...) — on normalise à la
-- lecture ; on garde les deux formes accentuée/non accentuée en clé.
-- forModo = tag AUSSI visible par un modérateur en noclip (les autres = SA only).
-- forRespo = tag visible par un RESPONSABLE modérateur (demande user 09/08 : il doit
--            pouvoir situer ses modérateurs et ses helpeurs). Volontairement PAS posé
--            sur les tags animateur : encadrer l'animation n'est pas son pôle.
-- saOnly  = tag visible UNIQUEMENT par un superadmin (jamais par un modérateur).
local TAG_STREAMER = { label = "STREAMER", col = Color(145, 70, 255), forModo = true } -- violet Twitch
local TAG_HELPEUR  = { label = "HELPEUR",  col = Color(120, 200, 140), forRespo = true }
-- Gérant RP (09/07) : droits du respo modo, donc comme lui vu des SEULS superadmins.
local TAG_GERANT_RP = { label = "GÉRANT RP", col = Color(255, 205, 90), saOnly = true }
local NOCLIP_TAGS = {
	helper       = TAG_HELPEUR, helpeur = TAG_HELPEUR, -- 2 orthographes possibles côté SAM
	animateur    = { label = "ANIMATEUR", col = Color(224, 120, 200) },
	mj           = TAG_MJ,
	mj_plus      = TAG_MJ_PLUS,
	animateur_test   = { label = "ANIM. TESTÉ",  col = Color(224, 150, 210) },
	animateur_gerant = { label = "GÉRANT ANIM.", col = Color(210, 80, 180) },
	gerant_rp = TAG_GERANT_RP, ["gérant rp"] = TAG_GERANT_RP,
	moderateur   = TAG_MODO, ["modérateur"] = TAG_MODO, moderator = TAG_MODO,
	moderateur_plus = TAG_MODO_PLUS, ["moderateur plus"] = TAG_MODO_PLUS,
	-- Respo modo : vu des SEULS superadmins en noclip (invisible aux modos/animateurs).
	responsable_moderateur = { label = "RESPO MODO", col = Color(255, 150, 60), saOnly = true },
	["responsable modérateur"] = { label = "RESPO MODO", col = Color(255, 150, 60), saOnly = true },
	streamer     = TAG_STREAMER, -- (lookup en lowercase : couvre « Streamer » etc.)
	superadmin   = { label = "SUPERADMIN", col = Color(207, 68, 78), saOnly = true },
}
-- Groupes « viewer modérateur » (mêmes alias que TAG_MODO).
local MODO_VIEWERS = { moderateur = true, ["modérateur"] = true, moderator = true,
	moderateur_plus = true, ["moderateur plus"] = true,
	responsable_moderateur = true, ["responsable modérateur"] = true,
	gerant_rp = true, ["gérant rp"] = true }
local TAG_MAXDIST_SQR = 6000 * 6000

hook.Add("HUDPaint", "EVO_Staff::NoclipTags", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local bSA = lp:IsSuperAdmin()
	local bModo = MODO_VIEWERS[string.lower(lp:GetUserGroup() or "")] == true
	if not (bSA or bModo) then return end
	if lp:GetMoveType() ~= MOVETYPE_NOCLIP then return end
	-- Responsable modérateur : voit les tags forRespo (HELPEUR / MODÉRATEUR) et sur
	-- TOUTE la map — même règle que son repère de service (cl_voir_staff, portée
	-- illimitée). Les 6000 u par défaut restent pour les autres.
	local bRespo = EVO_IsRespoModo ~= nil and EVO_IsRespoModo(lp)
	local nMaxDistSqr = bRespo and math.huge or TAG_MAXDIST_SQR
	local vMy = lp:GetPos()
	for _, p in player.Iterator() do
		if IsValid(p) and p ~= lp and p:Alive() then
			local tag = NOCLIP_TAGS[string.lower(p:GetUserGroup() or "")]
			-- Whitelist STREAMER (SteamID64) : même tag même si le joueur garde son rang RP.
			if (not tag) and p:GetEvoNWBool("EVO_IsStreamer", false) then
				tag = TAG_STREAMER
			end
			-- Modérateur : ne voit QUE les tags forModo (STREAMER). SA : tout.
			-- Cible TENUE (grab ncm_grab_superieur / carry) : PAS de tag (bug user 07/23 :
			-- « SUPERADMIN » flottant au-dessus d'un SA attrapé = chelou). Le tag garde son
			-- rôle « repérage » sur un staff libre (noclip/cloak) ou un streamer qui joue.
			if tag and (bSA or tag.forModo or (bRespo and tag.forRespo)) and not (tag.saOnly and not bSA)
				and not p:GetEvoNWBool("NCM_IsGrabbed", false)
				and not p:GetEvoNWBool("EVO::BeingCarryied", false)
				and p:GetPos():DistToSqr(vMy) <= nMaxDistSqr then
				-- Au-dessus de la tête, scalé par le model scale (cf. nametag lzy_meet).
				local scr = (p:GetPos() + Vector(0, 0, 88 * (p.GetModelScale and p:GetModelScale() or 1))):ToScreen()
				if scr.visible then
					draw.SimpleTextOutlined(tag.label, "EVO_StaffNoclipTag", scr.x, scr.y, tag.col,
						TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(0, 0, 0, 230))
					-- SA cloaké (corps invisible) : on précise QUI c'est sous le tag.
					if tag.saOnly and p:GetNoDraw() then
						draw.SimpleTextOutlined(p:Nick(), "EVO_StaffNoclipTag", scr.x, scr.y + 22, color_white,
							TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 230))
					end
				end
			end
		end
	end
end)

-- ══════════════════════════════════════════════════════════════════════════════
-- LES SUPERADMINS SE VOIENT ENTRE EUX (demande user 07/22) : le cloak SAM du
-- staff mode (sam_cloak = SetNoDraw + alpha 0, networké) cache un SA en noclip
-- de TOUT LE MONDE, autres SA compris. Ici, un SA re-dessine LOCALEMENT le
-- modèle des autres SA cloakés en fantôme semi-transparent (l'entité reste
-- transmise, seul son rendu est coupé). L'alpha entité étant forcé à 0 par le
-- cloak, on le restaure le temps du DrawModel puis on le remet — état 100%
-- client, aucune fuite réseau. Coût : 1 boucle/frame pour les SA uniquement.
-- ══════════════════════════════════════════════════════════════════════════════
hook.Add("PostDrawTranslucentRenderables", "EVO_Staff::SeeCloakedSA", function(_, bSkybox)
	if bSkybox then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then return end
	for _, p in player.Iterator() do
		-- Orthographes du rang : source unique EVO_IsRespoModo (sh_staff_grades.lua).
		local bGhostable = IsValid(p) and (p:IsSuperAdmin()
			or (EVO_IsRespoModo ~= nil and EVO_IsRespoModo(p)))
		if bGhostable and p ~= lp and p:Alive() and p:GetNoDraw() then
			-- Cloak SAM preview only — do not pierce instance / portal / hub / spell hides.
			if p.EVO_FlashStepHidden then continue end
			if p.GetEvoNWBool and (p:GetEvoNWBool("EVO_FullHide", false)
				or p:GetEvoNWBool("EVO_FlashStepping", false)
				or p:GetEvoNWBool("NCM_IsAssassinInvisible", false)) then
				continue
			end
			if p._NCM_CrossInstanceHidden then continue end
			if NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(p) then
				continue
			end
			if EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(lp, p) then
				continue
			end
			if NCM_CHAR_SELECT and NCM_CHAR_SELECT.IsSceneActive and NCM_CHAR_SELECT.IsSceneActive() then
				continue
			end
			local col = p:GetColor()
			p:SetColor(Color(col.r, col.g, col.b, 255)) -- annule l'alpha 0 du cloak (local)
			render.SetBlend(0.45)
			-- DrawModel seul ignore RenderOverride → parts singledraw restent NoDraw
			-- = face flottante. Dessiner le composite (face + parts) à la place.
			if LZY_Character_ForceDrawPlayerComposite then
				LZY_Character_ForceDrawPlayerComposite(p)
			else
				p:DrawModel()
			end
			render.SetBlend(1)
			p:SetColor(col)
		end
	end
end)
