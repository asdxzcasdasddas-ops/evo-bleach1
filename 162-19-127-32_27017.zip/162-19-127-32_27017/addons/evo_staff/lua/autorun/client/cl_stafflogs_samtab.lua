-- "addons\\evo_staff\\lua\\autorun\\client\\cl_stafflogs_samtab.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF LOGS — ONGLET dans le SAM MENU (super admin).
-- Ajoute un onglet "Logs" au menu SAM (!menu) pour CONSULTER les logs staff sans
-- passer par le popup evo_logs. Construit en composants SUI natifs (look SAM) et
-- réutilise l'infra net déjà en place : EVO_StaffLogsUI (cl_stafflogs.lua) ->
-- EVO_StaffLogs::Query / Results / Meta (sv_stafflogs.lua, gate super admin).
-- Le popup evo_logs / !logs reste dispo (recherche avancée + périodes custom).
-- ============================================================================
if not CLIENT then return end

local ICON = "icon16/text_list_bullets.png" -- silkicon intégré (non-http => Material), identifiant unique
local ACCENT = Color(207, 68, 78)

-- Périodes rapides (label -> secondes ; 0 = tout, borné à 250 lignes récentes côté serveur).
local PERIODS = {
	{ "Tout", 0 }, { "Dernière heure", 3600 }, { "6 heures", 21600 },
	{ "24 heures", 86400 }, { "7 jours", 604800 }, { "30 jours", 2592000 },
}

local ROW_FONT, HEAD_FONT

-- Construit le contenu de l'onglet dans `sheet`. Renvoie le panel racine (requis par AddSheet).
local function BuildTab(sheet)
	local SUI      = sam.SUI
	local GetColor = SUI.GetColor
	local S        = SUI.Scale

	local col_title = GetColor("menu_tabs_title")
	local col_head  = GetColor("player_list_titles")
	local col_txt   = GetColor("player_list_data")
	local col_dim   = GetColor("player_list_steamid")
	local rowbg     = GetColor("page_switch_bg")

	local W_DATE, W_STAFF, W_ACT, W_TGT = S(140), S(150), S(120), S(150)

	local root = sheet:Add("Panel")
	root:Dock(FILL)
	root:DockMargin(0, 1, 0, 0)
	root:DockPadding(10, 10, 10, 10)

	-- Titre
	local title = root:Add("SAM.Label")
	title:Dock(TOP)
	title:SetFont(SAM_TAB_TITLE_FONT)
	title:SetText("Logs staff")
	title:SetTextColor(col_title)
	title:SizeToContents()

	local sub = root:Add("SAM.Label")
	sub:Dock(TOP)
	sub:DockMargin(0, 4, 0, 0)
	sub:SetFont(SAM_TAB_DESC_FONT)
	sub:SetText("Toutes les actions staff de CE serveur. Recherche avancée : !logs")
	sub:SetTextColor(col_dim)
	sub:SizeToContents()

	-- État courant des filtres
	local curAction, curPeriod = "", 0
	local actionMap = {}
	local body, countLbl, playerEntry, textEntry

	-- ── Une requête -> setData(rows, capped) via le sink partagé ──────────────
	local function mkCell(parent, text, wide, col)
		local l = parent:Add("SAM.Label")
		if wide then l:Dock(LEFT) l:SetWide(wide) else l:Dock(FILL) end
		l:DockMargin(4, 0, 0, 0)
		l:SetFont(ROW_FONT)
		l:SetText(text or "")
		l:SetTextColor(col)
		l:SetContentAlignment(4)
		return l
	end

	local function setData(rows, capped)
		if not IsValid(body) then return end
		body:GetCanvas():Clear()
		body.VBar.Scroll = 0
		for i, r in ipairs(rows) do
			local line = body:Add("Panel")
			line:Dock(TOP)
			line:DockMargin(0, 0, 0, 2)
			line:SetTall(S(20))
			local shade = (i % 2 == 0)
			line.Paint = function(_, w, h)
				if shade then surface.SetDrawColor(rowbg) surface.DrawRect(0, 0, w, h) end
			end

			mkCell(line, EVO_StaffLogsUI.FmtTs(r.ts), W_DATE, col_dim)
			mkCell(line, EVO_StaffLogsUI.Who(r.staff_name, r.staff_sid), W_STAFF, col_txt)
			mkCell(line, EVO_StaffLogsUI.PrettyAction(r.action or ""), W_ACT, ACCENT)
			mkCell(line, EVO_StaffLogsUI.Who(r.target_name, r.target_sid), W_TGT, col_txt)

			local det = tostring(r.details or "")
			local short = #det > 80 and (string.sub(det, 1, 80) .. "…") or det
			local d = mkCell(line, short, nil, col_dim)
			if det ~= "" then d:SetTooltip(det) end
		end
		body:InvalidateLayout(true)
		if IsValid(countLbl) then
			countLbl:SetText(#rows .. " résultat(s)" .. (capped and " : limité (affine les filtres)" or ""))
		end
	end

	local function refresh()
		if not LocalPlayer():IsSuperAdmin() then return end
		local from
		if curPeriod and curPeriod > 0 then from = os.time() - curPeriod end
		EVO_StaffLogsUI.SendQuery({
			player = IsValid(playerEntry) and playerEntry:GetValue() or "",
			scope  = "both",
			action = curAction or "",
			text   = IsValid(textEntry) and textEntry:GetValue() or "",
			from   = from,
		}, setData)
	end

	-- ── Barre de filtres ──────────────────────────────────────────────────────
	local ctrl = root:Add("SAM.Panel")
	ctrl:Dock(TOP)
	ctrl:DockMargin(0, 10, 0, 0)
	ctrl:SetTall(S(30))

	playerEntry = ctrl:Add("SAM.TextEntry")
	playerEntry:Dock(LEFT)
	playerEntry:SetWide(S(190))
	playerEntry:SetNoBar(true)
	playerEntry:SetRadius(4)
	playerEntry:SetPlaceholder("Joueur (nom / SteamID)")
	function playerEntry:OnEnter() refresh() end

	textEntry = ctrl:Add("SAM.TextEntry")
	textEntry:Dock(LEFT)
	textEntry:DockMargin(8, 0, 0, 0)
	textEntry:SetWide(S(190))
	textEntry:SetNoBar(true)
	textEntry:SetRadius(4)
	textEntry:SetPlaceholder("Détails (raison, motif…)")
	function textEntry:OnEnter() refresh() end

	local cbA = ctrl:Add("SAM.ComboBox")
	cbA:Dock(LEFT)
	cbA:DockMargin(8, 0, 0, 0)
	cbA:SetWide(S(190))
	cbA:SetValue("Toutes les actions")
	function cbA:OnSelect(_, value)
		curAction = actionMap[value] or ""
		refresh()
	end

	local cbP = ctrl:Add("SAM.ComboBox")
	cbP:Dock(LEFT)
	cbP:DockMargin(8, 0, 0, 0)
	cbP:SetWide(S(130))
	local periodMap = {}
	for _, p in ipairs(PERIODS) do cbP:AddChoice(p[1]) periodMap[p[1]] = p[2] end
	cbP:SetValue("Tout")
	function cbP:OnSelect(_, value)
		curPeriod = periodMap[value] or 0
		refresh()
	end

	local btnSearch = ctrl:Add("SAM.Button")
	btnSearch:Dock(LEFT)
	btnSearch:DockMargin(8, 0, 0, 0)
	btnSearch:SetWide(S(110))
	btnSearch:SetText("Rechercher")
	btnSearch:SetFont(ROW_FONT)
	btnSearch:On("DoClick", refresh)

	-- ── En-têtes de colonnes ──────────────────────────────────────────────────
	local head = root:Add("Panel")
	head:Dock(TOP)
	head:DockMargin(0, 12, 0, 0)
	head:SetTall(S(20))
	local function hcol(text, wide)
		local l = head:Add("SAM.Label")
		if wide then l:Dock(LEFT) l:SetWide(wide) else l:Dock(FILL) end
		l:DockMargin(4, 0, 0, 0)
		l:SetFont(HEAD_FONT)
		l:SetText(text)
		l:SetTextColor(col_head)
		l:SetContentAlignment(4)
	end
	hcol("Date", W_DATE) hcol("Staff", W_STAFF) hcol("Action", W_ACT)
	hcol("Cible", W_TGT) hcol("Détails", nil)

	-- ── Liste ─────────────────────────────────────────────────────────────────
	body = root:Add("SAM.ScrollPanel")
	body:Dock(FILL)
	body:DockMargin(0, 6, 0, 0)
	body:SetVBarPadding(6)

	-- ── Pied : compteur + actions ─────────────────────────────────────────────
	local bottom = root:Add("SAM.Panel")
	bottom:Dock(BOTTOM)
	bottom:DockMargin(0, 8, 0, 0)
	bottom:SetTall(S(30))
	bottom:Background(GetColor("page_switch_bg"))

	countLbl = bottom:Add("SAM.Label")
	countLbl:Dock(LEFT)
	countLbl:DockMargin(8, 0, 0, 0)
	countLbl:SetFont(ROW_FONT)
	countLbl:SetText("Chargement…")
	countLbl:SetTextColor(col_dim)
	countLbl:SetWide(S(300))
	countLbl:SetContentAlignment(4)

	local btnExport = bottom:Add("SAM.Button")
	btnExport:Dock(RIGHT)
	btnExport:DockMargin(6, 4, 8, 4)
	btnExport:SetWide(S(130))
	btnExport:SetText("Exporter CSV")
	btnExport:SetFont(ROW_FONT)
	btnExport:On("DoClick", function() EVO_StaffLogsUI.ExportCSV() end)

	local btnCopy = bottom:Add("SAM.Button")
	btnCopy:Dock(RIGHT)
	btnCopy:DockMargin(6, 4, 0, 4)
	btnCopy:SetWide(S(100))
	btnCopy:SetText("Copier")
	btnCopy:SetFont(ROW_FONT)
	btnCopy:On("DoClick", function() EVO_StaffLogsUI.Copy() end)

	local btnAdv = bottom:Add("SAM.Button")
	btnAdv:Dock(RIGHT)
	btnAdv:DockMargin(6, 4, 0, 4)
	btnAdv:SetWide(S(150))
	btnAdv:SetText("Recherche avancée")
	btnAdv:SetFont(ROW_FONT)
	btnAdv:On("DoClick", function() EVO_StaffLogsUI.OpenPopup() end)

	-- ── Peuplement du filtre Action (actions réellement loggées) ──────────────
	local filled = false
	local function fillActions()
		if filled or not IsValid(cbA) then return end
		filled = true
		actionMap = {}
		local function add(label, val) cbA:AddChoice(label) actionMap[label] = val end
		add("Toutes les actions", "")
		add("— Sanctions —", "@sanctions")
		add("— Mutes / Gags —", "@mutes")
		add("— Warns —", "@warns")
		add("— Staff mode —", "@staff")
		add("— Animateur —", "@anim")
		add("— Reports —", "@reports")
		local seen = {
			[""] = true, ["@sanctions"] = true, ["@mutes"] = true, ["@warns"] = true,
			["@staff"] = true, ["@anim"] = true, ["@reports"] = true,
		}
		local dyn = {}
		for _, a in ipairs(EVO_StaffLogsUI.GetActions() or {}) do
			if not seen[a] then dyn[#dyn + 1] = a seen[a] = true end
		end
		table.sort(dyn, function(x, y)
			return EVO_StaffLogsUI.PrettyAction(x) < EVO_StaffLogsUI.PrettyAction(y)
		end)
		for _, a in ipairs(dyn) do add(EVO_StaffLogsUI.PrettyAction(a), a) end
	end
	EVO_StaffLogsUI.RequestMeta(fillActions)  -- fill dès l'arrivée des métadonnées (serveur local = quasi instantané)
	timer.Simple(1.5, fillActions)            -- filet : si la réponse Meta est perdue, on remplit depuis le cache

	refresh() -- recherche initiale (250 dernières actions)
	return root
end

-- ── Enregistrement de l'onglet (robuste vis-à-vis de l'ordre de chargement) ──
local registered = false
local function register()
	if registered then return end
	if not (istable(sam) and sam.menu and sam.menu.add_tab and sam.SUI and EVO_StaffLogsUI) then return end
	registered = true
	ROW_FONT  = sam.SUI.CreateFont("EVOLogsRow", "Roboto", 15)
	HEAD_FONT = sam.SUI.CreateFont("EVOLogsHead", "Roboto", 16)
	sam.menu.add_tab(ICON, BuildTab, function()
		return IsValid(LocalPlayer()) and LocalPlayer():IsSuperAdmin()
	end, 20) -- pos 20 : après les onglets natifs (Players/Ranks/Bans/Config…)
end

hook.Add("InitPostEntity", "EVO_StaffLogs::SamTab", register)
register() -- si SAM est déjà chargé au moment de ce fichier
