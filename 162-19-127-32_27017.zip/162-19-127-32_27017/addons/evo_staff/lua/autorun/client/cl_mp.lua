-- "addons\\evo_staff\\lua\\autorun\\client\\cl_mp.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF : MESSAGE PRIVE plein ecran (cote destinataire).
--
-- Recu via EVO_Dash::MP (action « msg » du dashboard staff). Rendu demande
-- (2026-08-01) : l'ecran se floute, le logo EVO au milieu un peu en haut, le
-- message dessous, et dessous encore, plus petit et plus discret, le nom du
-- staff qui l'a envoye.
--
-- Le logo est le meme PNG que le menu Echap / HUD : ATTENTION, sa moitie HAUTE
-- est transparente (le cercle EVO occupe la moitie basse du carre). On place
-- donc l'image par le centre VISIBLE (~75% de la hauteur du carre), pas par
-- son centre geometrique, sinon le logo semble flotter trop bas.
-- ============================================================================
if not CLIENT then return end

local matLogo = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png", "smooth")
local matBlur = Material("pp/blurscreen")

local FADE_IN, FADE_OUT = 0.35, 0.6

-- { texte, de, fin } ou nil quand rien a afficher.
local actif = nil

local function MakeFonts()
	surface.CreateFont("EVOMP_Msg", {
		font = "Gilroy", size = math.max(20, math.Round(ScrH() * 0.032)),
		weight = 800, antialias = true, extended = true,
	})
	surface.CreateFont("EVOMP_De", {
		font = "Gilroy", size = math.max(13, math.Round(ScrH() * 0.017)),
		weight = 600, antialias = true, extended = true,
	})
end
hook.Add("Initialize", "EVOMP_Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVOMP_Fonts", MakeFonts)
MakeFonts()

net.Receive("EVO_Dash::MP", function()
	local texte = net.ReadString()
	local de    = net.ReadString()
	local dura  = math.Clamp(net.ReadFloat() or 6, 3, 30)
	if texte == "" then return end
	actif = { texte = texte, de = de, debut = CurTime(), fin = CurTime() + dura }
end)

-- Coupe le message en lignes qui tiennent dans maxW avec la fonte donnee.
local function Lignes(texte, fonte, maxW)
	surface.SetFont(fonte)
	local lignes, courante = {}, ""
	for mot in string.gmatch(texte, "%S+") do
		local essai = courante == "" and mot or (courante .. " " .. mot)
		if surface.GetTextSize(essai) > maxW and courante ~= "" then
			lignes[#lignes + 1] = courante
			courante = mot
		else
			courante = essai
		end
	end
	if courante ~= "" then lignes[#lignes + 1] = courante end
	return lignes
end

local function PaintBlur(force, alpha)
	surface.SetMaterial(matBlur)
	surface.SetDrawColor(255, 255, 255, alpha)
	for i = 1, 3 do
		matBlur:SetFloat("$blur", (i / 3) * force)
		matBlur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	end
end

hook.Add("HUDPaint", "EVOMP_Draw", function()
	if not actif then return end
	local now = CurTime()
	if now >= actif.fin then actif = nil return end

	-- Fondu d'entree et de sortie, en fraction 0..1.
	local k = math.min(1, (now - actif.debut) / FADE_IN)
	local resteAvantFin = actif.fin - now
	if resteAvantFin < FADE_OUT then k = math.min(k, resteAvantFin / FADE_OUT) end
	if k <= 0 then return end

	local sw, sh = ScrW(), ScrH()
	local a = math.Round(255 * k)

	PaintBlur(5 * k, a)
	surface.SetDrawColor(8, 9, 12, math.Round(170 * k))
	surface.DrawRect(0, 0, sw, sh)

	-- Logo : centre VISIBLE du cercle a ~32% de l'ecran (« au milieu un peu en
	-- haut »). Le cercle vit dans la moitie basse du carre -> son centre visible
	-- est a ~75% de la hauteur de l'image.
	local L = math.Round(sh * 0.30)
	local yCercle = math.Round(sh * 0.32)
	surface.SetDrawColor(255, 255, 255, a)
	surface.SetMaterial(matLogo)
	surface.DrawTexturedRect(math.Round(sw / 2 - L / 2), math.Round(yCercle - L * 0.75), L, L)

	-- Message, sous le logo.
	local lignes = Lignes(actif.texte, "EVOMP_Msg", math.Round(sw * 0.56))
	surface.SetFont("EVOMP_Msg")
	local _, lh = surface.GetTextSize("Ag")
	local y = math.Round(sh * 0.455)
	for _, l in ipairs(lignes) do
		draw.SimpleTextOutlined(l, "EVOMP_Msg", sw / 2, y, Color(238, 240, 246, a),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, math.Round(160 * k)))
		y = y + math.Round(lh * 1.22)
	end

	-- L'expediteur : plus petit, plus discret.
	draw.SimpleText(string.upper(actif.de or ""), "EVOMP_De", sw / 2, y + math.Round(sh * 0.018),
		Color(210, 214, 224, math.Round(a * 0.55)), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)
