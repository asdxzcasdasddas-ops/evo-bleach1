-- "addons\\evo_staff\\lua\\autorun\\client\\cl_dashboard.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF DASHBOARD — client : grande UI (mode staff).
-- Ouverte via le menu de binds quand on est en mode staff (bind "staff_dashboard").
-- Recherche + liste triable de TOUS les joueurs (gauche) + FICHE JOUEUR (droite) :
--   model 3D + infos + sanctions + ACTIONS REGROUPÉES PAR CATÉGORIE. Données =
--   snapshot serveur (sv_dashboard.lua, 2s) + fiche détaillée à la sélection.
-- Actions gated serveur (CanStaffMode + immunité + permissions par rang).
-- DA Atelier EVO : plaque #0E0E11 à coins coupés + vis + titre Bebas/slash accent
--   (#cf444e), RNDX, fond flouté. Refonte visuelle 2026-07-23 (demande user :
--   « plus joli + plus intuitif »). FONCTIONNEL inchangé (réseau/3D/binds/toast).
-- ============================================================================
if not CLIENT then return end

local ACCENT   = Color(207, 68, 78)
local ACCENT_D = Color(232, 136, 145)   -- accent clair (texte danger au repos)
local CARD     = Color(14, 14, 17)
local CARD2    = Color(19, 20, 24)
local FIELD    = Color(30, 31, 37)
local FIELD_H  = Color(42, 43, 51)
local CHIP     = Color(24, 25, 30)
local ROWALT   = Color(20, 20, 25)
local TXT      = Color(236, 236, 240)
local TXT_DIM  = Color(150, 150, 162)
local TXT_MUT  = Color(106, 109, 118)
local OK_COL   = Color(90, 200, 120)
local WARN_COL = Color(230, 180, 70)
local SEP      = Color(255, 255, 255, 16)

local FAC_COL = {
	Shinigami = Color(90, 150, 235),
	Hollow    = Color(210, 80, 90),
	Arrancar  = Color(210, 80, 90),
}

-- Échelle globale (l'UI grandit avec la résolution).
local SC = math.Clamp(ScrH() / 1080, 0.9, 2.2)
local function s(n) return math.floor(n * SC + 0.5) end
local function fsz(n) return math.max(11, math.floor(n * SC + 0.5)) end

surface.CreateFont("EVODash_Title", { font = "Bebas Neue", size = fsz(46), weight = 600 })
surface.CreateFont("EVODash_Big",   { font = "Bebas Neue", size = fsz(50), weight = 600 })
surface.CreateFont("EVODash_Grp",   { font = "Bebas Neue", size = fsz(19), weight = 600 })
surface.CreateFont("EVODash_H",     { font = "Roboto",     size = fsz(23), weight = 700 })
surface.CreateFont("EVODash_B",     { font = "Roboto",     size = fsz(19), weight = 600 })
surface.CreateFont("EVODash_S",     { font = "Roboto",     size = fsz(16), weight = 500 })
surface.CreateFont("EVODash_XS",    { font = "Roboto",     size = fsz(14), weight = 500 })

-- État partagé
local DASH = {
	players = {}, byId = {}, map = "", t = 0,
	selSid = nil, detail = {}, search = "",
	-- Pré-sélection depuis l'inspect E. On préfère UserID (petit int, jamais
	-- corrompu par JSON) puis SteamID64. Ne se clear PAS sur un miss de snap.
	preselectSid = nil,
	preselectUid = nil,
	sortKey = "name", sortAsc = true,
	tab = "players",
	clans = {}, clanByKey = {}, selClan = nil, clanMembers = {}, clanWarnHist = {},
	clanSearch = "", clanSortKey = "spell", clanSortAsc = true,
	onSnap = nil, onDetail = nil, onClans = nil, onClanDetail = nil, showToast = nil,
}
local UI -- backdrop (DFrame plein écran)
local dashClosedAt = 0 -- SysTime de la dernière fermeture (debounce anti-réouverture du bind)

-- ── Helpers de dessin DA ─────────────────────────────────────────────────────
-- Plaque à coins coupés (DA Atelier). Fallback rect plein si le kit EVO_UI manque.
local function paintPlate(x, y, w, h, col, rad)
	if EVO_UI and EVO_UI.PaintCut then return EVO_UI.PaintCut(x, y, w, h, col, rad or s(12)) end
	surface.SetDrawColor(col) surface.DrawRect(x, y, w, h)
	return nil
end
-- Rectangle arrondi doux (boutons / chips / lignes).
local function roundRect(rad, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(rad, x, y, w, h, col)
	else draw.RoundedBox(rad, x, y, w, h, col) end
end

local function facColor(fac) return FAC_COL[fac] or TXT_DIM end

-- SteamID64 fiable depuis une entité joueur (string digits only).
local function steamId64Of(ply)
	if not IsValid(ply) then return "" end
	local ok, v = pcall(function() return ply:SteamID64() end)
	if not ok or v == nil then return "" end
	v = tostring(v)
	if string.sub(v, 1, 1) == "#" then v = string.sub(v, 2) end
	if not v:match("^%d+$") then return "" end
	return v
end

-- Injecte / met à jour une entrée liste depuis le joueur LIVE (sans attendre le snap).
-- Obligatoire pour E→Dashboard : le profil doit s'afficher au 1er frame.
local function seedFromPlayer(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return nil end
	local sid = steamId64Of(ply)
	if sid == "" then return nil end
	local fac = (ply.GetEvoNWString and ply:GetEvoNWString("FactionName", "")) or ""
	local divN, rnkN = "", ""
	if fac ~= "" and istable(LZY_FACTION_CONFIG) then
		local divI = ply.GetEvoNWInt and ply:GetEvoNWInt("FactionDivision", 0) or 0
		local rnkI = ply.GetEvoNWInt and ply:GetEvoNWInt("FactionRank", 0) or 0
		if LZY_FACTION_CONFIG.DivisionName then divN = tostring(LZY_FACTION_CONFIG.DivisionName(ply, divI) or "") end
		if LZY_FACTION_CONFIG.RankName then rnkN = tostring(LZY_FACTION_CONFIG.RankName(ply, rnkI) or "") end
	end
	local pos = ply:GetPos()
	local name = (ply.GetEvoNWString and ply:GetEvoNWString("Nickname", "")) or ""
	local entry = {
		sid = sid,
		uid = ply:UserID(),
		name = name ~= "" and name or ply:Nick(),
		steam = ply:Nick(),
		grp = ply:GetUserGroup(),
		sa = ply:IsSuperAdmin(),
		respo = EVO_IsRespoModo ~= nil and EVO_IsRespoModo(ply) or false,
		staff = ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_StaffMode", false) or false,
		fac = fac,
		div = divN,
		rank = rnkN,
		hp = math.floor(ply:Health()),
		maxhp = math.floor(ply:GetMaxHealth()),
		rei = ply.GetEvoNWInt and ply:GetEvoNWInt("Reiatsu", 0) or 0,
		maxrei = ply.GetEvoNWInt and ply:GetEvoNWInt("MaxReiatsu", 0) or 0,
		money = ply.GetEvoNWInt and ply:GetEvoNWInt("Money", 0) or 0,
		age = (ply.GetCharacterAge and ply:GetCharacterAge()) or 0,
		ping = ply:Ping(),
		pt = 0,
		x = math.Round(pos.x), y = math.Round(pos.y), z = math.Round(pos.z),
		alive = ply:Alive(),
		frozen = ply.GetEvoNWBool and ply:GetEvoNWBool("EVO_AdminFrozen", false) or false,
		hasChar = true,
	}
	DASH.byId[sid] = entry
	local replaced = false
	for i, p in ipairs(DASH.players) do
		if p.sid == sid or tonumber(p.uid) == entry.uid then
			DASH.players[i] = entry
			replaced = true
			break
		end
	end
	if not replaced then DASH.players[#DASH.players + 1] = entry end
	return sid
end

-- Retrouve un joueur live pour (re)seeder après un snap qui l'a écrasé.
local function findLiveForPreselect()
	local wantUid = tonumber(DASH.preselectUid)
	if wantUid then
		for _, p in player.Iterator() do
			if IsValid(p) and p:UserID() == wantUid then return p end
		end
	end
	local wantSid = DASH.preselectSid and tostring(DASH.preselectSid) or ""
	if wantSid ~= "" and player.GetBySteamID64 then
		local p = player.GetBySteamID64(wantSid)
		if IsValid(p) then return p end
	end
	if DASH.selSid and player.GetBySteamID64 then
		local p = player.GetBySteamID64(tostring(DASH.selSid))
		if IsValid(p) then return p end
	end
	return nil
end

local function fmtMoney(n)
	n = tonumber(n) or 0
	local str = tostring(math.floor(n))
	local out, c = "", 0
	for i = #str, 1, -1 do
		out = str:sub(i, i) .. out
		c = c + 1
		if c % 3 == 0 and i > 1 then out = " " .. out end
	end
	return out .. " ¥"
end

local function fmtPlaytime(sec)
	sec = tonumber(sec) or 0
	local h = math.floor(sec / 3600)
	local m = math.floor((sec % 3600) / 60)
	if h > 0 then return h .. "h" .. string.format("%02d", m) end
	return m .. "m"
end

-- Libellés courts des actions de sanction (historique fiche joueur).
local SANCTION_LABEL = {
	ban = "Ban", kick = "Kick", mute = "Mute", gag = "Gag",
	warn = "Warn", ["warn.ban"] = "Warn→Ban", unwarn = "Unwarn",
	["sam.jail"] = "Jail", ["sam.slay"] = "Slay", ["sam.unban"] = "Unban",
	["sam.unmute"] = "Unmute", ["sam.ungag"] = "Ungag",
	["sam.freeze"] = "Freeze", ["sam.unfreeze"] = "Unfreeze",
	["dash.rename"] = "Rename", ["dash.ck"] = "CK",
	["dash.mute"] = "Mute", ["dash.unmute"] = "Unmute",
	["dash.freeze"] = "Freeze", ["dash.unfreeze"] = "Unfreeze",
	["ctx.kick"] = "Kick", ["ctx.ban"] = "Ban", ["ctx.gag"] = "Gag",
}
local function prettySanction(action)
	action = tostring(action or "")
	if SANCTION_LABEL[action] then return SANCTION_LABEL[action] end
	if string.sub(action, 1, 5) == "dash." then
		return string.upper(string.sub(action, 6, 6)) .. string.sub(action, 7)
	end
	if string.sub(action, 1, 4) == "sam." then return string.sub(action, 5) end
	return action
end
local function fmtSanctionWhen(ts)
	ts = tonumber(ts) or 0
	if ts <= 0 then return "—" end
	return os.date("%d/%m/%y %H:%M", ts)
end

local function short(str, n)
	str = tostring(str or "")
	if utf8 and utf8.len and utf8.sub then -- coupe sur les codepoints (accents FR intacts)
		local l = utf8.len(str)
		if l and l > n then return utf8.sub(str, 1, n - 1) .. "…" end
		return str
	end
	if #str > n then return str:sub(1, n - 1) .. "…" end
	return str
end

-- Bouton DA. tone : "danger" (sanction, accent) · "primary" (accent plein) · nil (neutre).
local function mkBtn(parent, label, tone, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetCursor("hand")
	b._hf = 0
	b.Paint = function(self, w, h)
		self._hf = Lerp(FrameTime() * 12, self._hf or 0, self:IsHovered() and 1 or 0)
		local hf = self._hf
		local bg, txt
		if not self:IsEnabled() then
			bg, txt = Color(28, 28, 33), TXT_MUT
		elseif tone == "danger" then
			bg  = Color(ACCENT.r, ACCENT.g, ACCENT.b, 34 + 150 * hf)
			txt = hf > 0.35 and TXT or ACCENT_D
		elseif tone == "primary" then
			bg  = Color(ACCENT.r, ACCENT.g, ACCENT.b, 205 + 50 * hf)
			txt = TXT
		else
			bg  = Color(FIELD.r + 12 * hf, FIELD.g + 12 * hf, FIELD.b + 14 * hf, 255)
			txt = TXT
		end
		roundRect(s(5), 0, 0, w, h, bg)
		draw.SimpleText(label, "EVODash_S", w / 2, h / 2 + s(1), txt, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	if fn then b.DoClick = fn end
	return b
end

-- Dialogue de saisie DA EVO (remplace Derma_StringRequest). `fields` = liste de
-- { label=, default=, numeric= }. onConfirm reçoit les valeurs saisies dans l'ordre.
local function evoPrompt(title, fields, onConfirm)
	local n = #fields
	local W = s(480)
	local H = s(88) + n * s(66) + s(60)

	-- DFrame plein écran = le patron des dialogues à saisie du projet (evo_clan,
	-- lzy_reroll…) : le routage clavier vers les champs est NATIF chez DFrame,
	-- là où un DPanel popup exigeait des rustines de focus (saisie impossible,
	-- seul Ctrl+V passait).
	local back = vgui.Create("DFrame")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0)
	back:SetTitle("") back:SetDraggable(false) back:ShowCloseButton(false)
	back:MakePopup()
	back.Paint = function(_, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end

	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(12))
		if pts and EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60)) end
		draw.SimpleText(string.upper(title or ""), "EVODash_Title", s(26), s(34), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVODash_Title")
			local tw = surface.GetTextSize(string.upper(title or ""))
			EVO_UI.Ink(EVO_UI.TexSlash, s(23), s(34) + s(13), tw * 1.05, s(9), Color(ACCENT.r, ACCENT.g, ACCENT.b, 235))
		end
	end

	local entries = {}
	local y = s(78)
	for i, f in ipairs(fields) do
		local lbl = vgui.Create("DLabel", card)
		lbl:SetFont("EVODash_S") lbl:SetTextColor(TXT_DIM) lbl:SetText(f.label or "")
		lbl:SetPos(s(28), y) lbl:SizeToContents()
		local e
		-- f.choices = { {label=, value=}, ... } -> liste déroulante ; le callback
		-- reçoit la `value`, pas le libellé.
		if istable(f.choices) and #f.choices > 0 then
			e = vgui.Create("DComboBox", card)
			e:SetPos(s(26), y + s(22)) e:SetSize(W - s(52), s(38))
			e:SetFont("EVODash_B") e:SetTextColor(TXT)
			e:SetTextInset(s(10), 0)
			e:SetSortItems(false) -- l'ordre de la liste fournie fait foi
			-- ⚠ ne PAS `return true` : le texte reste dessiné par le moteur (DLabel).
			e.Paint = function(_, w, h)
				roundRect(s(4), 0, 0, w, h, FIELD)
				draw.SimpleText("▾", "EVODash_S", w - s(12), h / 2, TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			for _, c in ipairs(f.choices) do
				e:AddChoice(c.label, c.value, c.value == f.default)
			end
			if not e:GetSelected() then e:ChooseOptionID(1) end
			e.OnMenuOpened = function(_, menu)
				if not IsValid(menu) then return end
				menu.Paint = function(_, w, h) roundRect(s(4), 0, 0, w, h, CARD) end
				-- DMenuOption se redimensionne sur SON texte dans PerformLayout (liste
				-- tassée) : on impose hauteur + retrait, et une largeur mini = celle du
				-- champ pour ne pas tronquer « Division 12 — Scientifique ».
				local nOptH = s(34)
				for _, opt in ipairs(menu:GetCanvas():GetChildren()) do
					if opt.SetFont then opt:SetFont("EVODash_B") end
					if opt.SetTextColor then opt:SetTextColor(TXT) end
					opt.PerformLayout = function(o)
						o:SetTextInset(s(14), 0)
						o:SetTall(nOptH)
					end
					opt:SetTall(nOptH)
				end
				menu:SetMinimumWidth(e:GetWide())
				menu:InvalidateLayout(true)
			end
			e._evoGet = function()
				local _, data = e:GetSelected()
				return data
			end
		else
			e = vgui.Create("DTextEntry", card)
			e:SetPos(s(26), y + s(22)) e:SetSize(W - s(52), s(38))
			e:SetText(tostring(f.default or "")) e:SetFont("EVODash_B")
			e:SetTextColor(TXT) e:SetCursorColor(TXT) e:SetPaintBackground(false)
			e:SetDrawLanguageID(false) -- pas de badge "FR" (layout clavier) dans le champ
			if f.numeric then e:SetNumeric(true) end
			e.Paint = function(self, w, h)
				roundRect(s(4), 0, 0, w, h, FIELD)
				self:DrawTextEntryText(TXT, ACCENT, TXT)
			end
			e._evoIsText = true
			e._evoGet = function() return e:GetValue() end
		end
		entries[i] = e
		y = y + s(66)
	end

	local function finish(ok)
		local vals = {}
		for i = 1, n do vals[i] = (IsValid(entries[i]) and entries[i]._evoGet and entries[i]._evoGet()) or "" end
		back:Remove()
		if ok and onConfirm then onConfirm(unpack(vals, 1, n)) end
	end
	-- OnEnter / focus : champs TEXTE seulement (rien à taper dans une liste).
	for _, e in ipairs(entries) do if e._evoIsText then e.OnEnter = function() finish(true) end end end
	timer.Simple(0, function() if IsValid(entries[1]) and entries[1]._evoIsText then entries[1]:RequestFocus() end end)

	local btnOK = mkBtn(card, "Valider", "primary", function() finish(true) end)
	btnOK:SetSize(s(150), s(40)) btnOK:SetPos(W - s(176), H - s(54))
	local btnCancel = mkBtn(card, "Annuler", nil, function() finish(false) end)
	btnCancel:SetSize(s(132), s(40)) btnCancel:SetPos(W - s(176) - s(144), H - s(54))
end
-- Exposé pour les autres UIs staff (menu contextuel : saisie du « Message à
-- l'écran ») : même dialogue DA partout plutôt qu'un Derma_StringRequest gris.
EVO_StaffPrompt = evoPrompt

-- ── Réseau (inchangé) ────────────────────────────────────────────────────────
local function subscribe(on)
	net.Start("EVO_Dash::Sub") net.WriteBool(on == true) net.SendToServer()
end
local function requestDetail(sid)
	if not sid then return end
	sid = tostring(sid)
	if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
	if sid == "" then return end
	net.Start("EVO_Dash::DetailReq") net.WriteString(sid) net.SendToServer()
end
local function act(action, arg1, arg2)
	if not DASH.selSid and action ~= "unspectate" then return end
	local sid = tostring(DASH.selSid or "")
	if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
	net.Start("EVO_Dash::Act")
		net.WriteString(action)
		net.WriteString(sid)
		net.WriteString(tostring(arg1 or ""))
		net.WriteString(tostring(arg2 or ""))
	net.SendToServer()
end

net.Receive("EVO_Dash::Snap", function()
	local len = net.ReadUInt(32)
	if not len or len <= 0 then return end
	local json = util.Decompress(net.ReadData(len))
	if not json or json == "" then return end
	local t = util.JSONToTable(json)
	if not istable(t) then return end
	DASH.map, DASH.t, DASH.players = t.map or "", t.t or 0, t.players or {}
	DASH.byId = {}
	for _, p in ipairs(DASH.players) do
		-- Strip le préfixe "#" anti-cast JSON (sv_dashboard makePlayers).
		local raw = tostring(p.sid or "")
		if string.sub(raw, 1, 1) == "#" then raw = string.sub(raw, 2) end
		p.sid = raw
		if p.sid ~= "" then DASH.byId[p.sid] = p end
	end
	if isfunction(DASH.onSnap) then DASH.onSnap() end
end)

net.Receive("EVO_Dash::Detail", function()
	-- Sid en WriteString (fiable) + payload compressé (warns / ban / history).
	local sid = net.ReadString()
	if not sid or sid == "" then return end
	sid = tostring(sid)
	if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
	local len = net.ReadUInt(32)
	if not len or len <= 0 then return end
	local data = net.ReadData(len)
	local json = util.Decompress(data)
	-- Fallback : serveur a pu envoyer le JSON brut si Compress a échoué.
	if not json or json == "" then json = data end
	if not json or json == "" then return end
	local t = util.JSONToTable(json)
	if not istable(t) then return end
	DASH.detail[sid] = {
		warns = t.warns or {},
		ban = t.ban or false,
		history = istable(t.history) and t.history or {},
	}
	if isfunction(DASH.onDetail) then DASH.onDetail() end
end)

net.Receive("EVO_Dash::Toast", function()
	local msg = net.ReadString()
	local err = net.ReadBool()
	if isfunction(DASH.showToast) then DASH.showToast(msg, err) end
end)

-- ── Résultats de la recherche BDD : nom RP -> SteamID (demande user 08/02) ──
-- Liste des personnages trouvés (hors ligne inclus) ; CLIC sur une ligne =
-- copie le SteamID64 dans le presse-papiers (feedback « COPIÉ » sur la ligne).
local function showFindResults(q, rows)
	local W = s(620)
	local n = istable(rows) and #rows or 0
	local listH = math.Clamp(math.max(n, 1), 1, 8) * s(52)
	local H = s(78) + listH + s(64)

	local back = vgui.Create("DFrame")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0)
	back:SetTitle("") back:SetDraggable(false) back:ShowCloseButton(false)
	back:MakePopup()
	back.Paint = function(_, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end

	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(12))
		if pts and EVO_UI and EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60)) end
		local title = "RECHERCHE : " .. string.upper(short(q, 22))
		draw.SimpleText(title, "EVODash_Title", s(26), s(34), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVODash_Title")
			local tw = surface.GetTextSize(title)
			EVO_UI.Ink(EVO_UI.TexSlash, s(23), s(34) + s(13), tw * 1.05, s(9), Color(ACCENT.r, ACCENT.g, ACCENT.b, 235))
		end
	end

	local sp = vgui.Create("DScrollPanel", card)
	sp:SetPos(s(24), s(70)) sp:SetSize(W - s(48), listH)
	local vbar = sp:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(s(5))
		vbar.Paint = function() end
		vbar.btnUp.Paint = function() end
		vbar.btnDown.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h) end
	end

	if n == 0 then
		local lbl = vgui.Create("DLabel", sp)
		lbl:Dock(TOP) lbl:SetTall(s(48))
		lbl:SetFont("EVODash_B") lbl:SetTextColor(TXT_DIM)
		lbl:SetContentAlignment(5)
		lbl:SetText("Aucun personnage trouvé pour ce nom.")
	end
	for _, r in ipairs(rows or {}) do
		local sid32 = (util.SteamIDFrom64 and util.SteamIDFrom64(r.sid)) or ""
		local row = sp:Add("DButton")
		row:Dock(TOP)
		row:DockMargin(0, 0, s(8), s(4))
		row:SetTall(s(48))
		row:SetText("")
		row:SetCursor("hand")
		row.Paint = function(self, w, h)
			roundRect(s(4), 0, 0, w, h, self:IsHovered() and FIELD_H or FIELD)
			draw.SimpleText(short(r.name ~= "" and r.name or "(sans nom)", 30), "EVODash_B", s(12), s(6), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(r.sid .. (sid32 ~= "" and ("   ·   " .. sid32) or ""), "EVODash_XS", s(12), h - s(7), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			if (self._copiedUntil or 0) > SysTime() then
				draw.SimpleText("COPIÉ", "EVODash_S", w - s(12), h / 2, OK_COL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			elseif r.on then
				draw.SimpleText("EN LIGNE", "EVODash_XS", w - s(12), h / 2, OK_COL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		row.DoClick = function(self)
			SetClipboardText(r.sid)
			self._copiedUntil = SysTime() + 1.6
			surface.PlaySound("garrysmod/ui_click.wav")
		end
	end

	local hint = vgui.Create("DLabel", card)
	hint:SetFont("EVODash_XS") hint:SetTextColor(TXT_MUT)
	hint:SetText("Clique sur une ligne pour copier le SteamID64.")
	hint:SetPos(s(26), H - s(46)) hint:SizeToContents()

	local btnClose = mkBtn(card, "Fermer", nil, function() back:Remove() end)
	btnClose:SetSize(s(132), s(40)) btnClose:SetPos(W - s(156), H - s(54))
end

net.Receive("EVO_Dash::ClansSnap", function()
	local len = net.ReadUInt(32)
	if not len or len <= 0 then return end
	local json = util.Decompress(net.ReadData(len))
	if not json or json == "" then return end
	local t = util.JSONToTable(json)
	if not istable(t) then return end
	DASH.clans = istable(t.clans) and t.clans or {}
	DASH.clanByKey = {}
	for _, c in ipairs(DASH.clans) do
		if c.key then DASH.clanByKey[c.key] = c end
	end
	if isfunction(DASH.onClans) then DASH.onClans() end
end)

net.Receive("EVO_Dash::ClanDetail", function()
	local len = net.ReadUInt(32)
	if not len or len <= 0 then return end
	local json = util.Decompress(net.ReadData(len))
	if not json or json == "" then return end
	local t = util.JSONToTable(json)
	if not istable(t) or not t.key then return end
	DASH.clanMembers[t.key] = istable(t.members) and t.members or {}
	DASH.clanWarnHist[t.key] = istable(t.warns) and t.warns or {}
	if isfunction(DASH.onClanDetail) then DASH.onClanDetail(t.key) end
	if isfunction(DASH.warnListRefresh) then DASH.warnListRefresh(t.key) end
end)

local function requestClans()
	net.Start("EVO_Dash::ClansReq") net.SendToServer()
end
local function requestClanDetail(key)
	if not key or key == "" then return end
	net.Start("EVO_Dash::ClanDetailReq") net.WriteString(key) net.SendToServer()
end

local function sendClanAction(action, key, nArg)
	if not key or key == "" then return end
	if util.NetworkStringToID("evo_clan:action") == 0 then return end
	net.Start("evo_clan:action")
		net.WriteString(action)
		net.WriteString(key)
		net.WriteInt(nArg or 0, 32)
	net.SendToServer()
	timer.Simple(0.7, function()
		requestClans()
		if DASH.selClan and DASH.selClan ~= "" then requestClanDetail(DASH.selClan) end
	end)
end

local function sendClanSpellDecision(key, bAccept)
	sendClanAction("sa_spell_decision", key, bAccept and 1 or 0)
end

local function sendClanWarn(key, nDelta)
	sendClanAction("sa_warn", key, nDelta)
end

local function sendClanWarnAdd(key, title, reason)
	title = string.gsub(string.Trim(tostring(title or "")), "[\t\n\r]", " ")
	reason = string.gsub(string.Trim(tostring(reason or "")), "[\t\n\r]", " ")
	if title == "" then return end
	sendClanAction("sa_warn_add", key .. "\t" .. string.sub(title, 1, 80) .. "\t" .. string.sub(reason, 1, 200), 1)
end

local function clanSpellStatus(c)
	if not c then return "" end
	local st = tostring(c.spellStatus or "")
	if st ~= "" then return st end
	if istable(c.spell) then return tostring(c.spell.status or "") end
	return ""
end

local function clanSpellAt(c)
	if not c then return 0 end
	local n = tonumber(c.spellAt)
	if n and n > 0 then return n end
	if istable(c.spell) then return tonumber(c.spell.spell_req_at) or 0 end
	return 0
end

local function fmtWhen(ts)
	ts = tonumber(ts) or 0
	if ts <= 0 then return "—" end
	return os.date("%d/%m/%Y %H:%M", ts)
end

local function clanWarnStatus(w)
	local bRem = tonumber(w.removed) == 1 or w.removed == true
	local bActive = tonumber(w.active) == 1 or w.active == true
	if bRem then return "RETIRÉ", TXT_MUT end
	if bActive then return "ACTIF jusqu'au " .. fmtWhen(w.exp), ACCENT end
	return "EXPIRÉ", TXT_DIM
end

local function showClanWarnList(key)
	key = tostring(key or "")
	if key == "" then return end
	local c = DASH.clanByKey[key]
	local sLabel = c and (c.label or key) or key
	if not istable(DASH.clanWarnHist[key]) then requestClanDetail(key) end

	local W = s(640)
	local H = s(560)
	local back = vgui.Create("DFrame")
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0)
	back:SetTitle("") back:SetDraggable(false) back:ShowCloseButton(false)
	back:MakePopup()
	back.Paint = function(_, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end

	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(12))
		if pts and EVO_UI and EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60)) end
		local title = "WARNS — " .. string.upper(short(sLabel, 28))
		draw.SimpleText(title, "EVODash_Title", s(26), s(34), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVODash_Title")
			local tw = surface.GetTextSize(title)
			EVO_UI.Ink(EVO_UI.TexSlash, s(23), s(34) + s(13), tw * 1.05, s(9), Color(ACCENT.r, ACCENT.g, ACCENT.b, 235))
		end
	end

	local sp = vgui.Create("DScrollPanel", card)
	sp:SetPos(s(22), s(72))
	sp:SetSize(W - s(44), H - s(140))

	local function fill()
		if not IsValid(sp) then return end
		sp:Clear()
		local hist = DASH.clanWarnHist[key]
		if not istable(hist) then
			local wait = sp:Add("DLabel")
			wait:Dock(TOP) wait:SetTall(s(28))
			wait:SetFont("EVODash_S") wait:SetTextColor(TXT_DIM)
			wait:SetText("Chargement…")
			return
		end
		if #hist == 0 then
			local none = sp:Add("DPanel")
			none:Dock(TOP) none:SetTall(s(36))
			none.Paint = function(_, w, h)
				draw.SimpleText("Aucun warn de clan.", "EVODash_S", 0, h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			return
		end
		for _, w in ipairs(hist) do
			local st, col = clanWarnStatus(w)
			local sMember = string.Trim(tostring(w.member or ""))
			local sReason = string.Trim(tostring(w.reason or ""))
			local sTitle = w.title ~= "" and w.title or "Warn de clan"
			local bActive = tonumber(w.active) == 1 or w.active == true
			local row = sp:Add("DPanel")
			row:Dock(TOP)
			row:DockMargin(0, 0, 0, s(6))
			row:SetTall(s(72))
			row.Paint = function(_, ww, hh)
				roundRect(s(4), 0, 0, ww, hh, CHIP)
				if bActive then surface.SetDrawColor(ACCENT) surface.DrawRect(0, s(8), s(3), hh - s(16)) end
				draw.SimpleText(short(sTitle, 42), "EVODash_S", s(14), s(8), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(st, "EVODash_XS", ww - s(12), s(10), col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				local y = s(30)
				if sMember ~= "" then
					draw.SimpleText("Membre : " .. short(sMember, 36), "EVODash_XS", s(14), y, WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					y = y + s(16)
				end
				local sLine = sReason ~= "" and sReason or "Pas de motif."
				draw.SimpleText(short(sLine, 58), "EVODash_XS", s(14), y, sReason ~= "" and TXT_DIM or TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText((w.staff ~= "" and w.staff or "?") .. "  ·  " .. fmtWhen(w.at), "EVODash_XS", ww - s(12), hh - s(10), TXT_MUT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
			end
		end
	end
	fill()
	DASH.warnListRefresh = function(k)
		if k and k ~= key then return end
		fill()
	end
	back.OnRemove = function()
		if DASH.warnListRefresh then DASH.warnListRefresh = nil end
	end

	local hint = vgui.Create("DLabel", card)
	hint:SetFont("EVODash_XS") hint:SetTextColor(TXT_MUT)
	hint:SetText("Warns hérités d'un warn / ban de membre, ou posés à la main.")
	hint:SetPos(s(26), H - s(46)) hint:SizeToContents()

	local btnClose = mkBtn(card, "Fermer", nil, function() back:Remove() end)
	btnClose:SetSize(s(132), s(40)) btnClose:SetPos(W - s(156), H - s(54))
end

local function clanSpellEligible(c)
	if not c then return false end
	if tonumber(c.spellElig) == 1 or c.spellElig == true then return true end
	return istable(c.spell) and c.spell.eligible == true
end

local function spellStatusRank(c)
	local st = clanSpellStatus(c)
	if st == "pending" then return 0 end
	local elig = c and (tonumber(c.spellElig) == 1 or c.spellElig == true or (istable(c.spell) and c.spell.eligible))
	if elig and st ~= "accepted" then return 1 end
	if st == "refused" then return 2 end
	if st == "accepted" then return 3 end
	return 4
end

local function spellStatusLabel(c)
	local sp = c and c.spell
	local st = clanSpellStatus(c)
	if st == "pending" then return "DEMANDE", WARN_COL end
	if st == "accepted" then return "ACCORDÉ", OK_COL end
	if st == "refused" then return "REFUSÉ", ACCENT end
	local elig = c and (tonumber(c.spellElig) == 1 or c.spellElig == true or (istable(sp) and sp.eligible))
	if elig then return "ÉLIGIBLE", OK_COL end
	local nOk, nAll = 0, 5
	if istable(sp) and istable(sp.checks) then
		nAll = 0
		for _, ok in pairs(sp.checks) do
			nAll = nAll + 1
			if ok then nOk = nOk + 1 end
		end
	end
	return nOk .. "/" .. nAll, TXT_DIM
end

net.Receive("EVO_Dash::FindRes", function()
	local len = net.ReadUInt(32)
	if not len or len <= 0 then return end
	local json = util.Decompress(net.ReadData(len))
	if not json or json == "" then return end
	local t = util.JSONToTable(json)
	if not istable(t) then return end
	showFindResults(tostring(t.q or ""), istable(t.rows) and t.rows or {})
end)

-- ── Tri + recherche de la liste ──────────────────────────────────────────────
local COLS = {
	{ key = "name",  label = "Nom RP",    w = s(220) },
	{ key = "steam", label = "Nom Steam", w = s(200) },
	{ key = "fac",   label = "Faction",   w = s(140) },
	{ key = "rank",  label = "Grade",     w = s(190) },
	{ key = "money", label = "Argent",    w = s(160) },
}

local function sortedPlayers()
	local arr = {}
	local q = string.lower(string.Trim(DASH.search or ""))
	for _, p in ipairs(DASH.players) do
		if q == "" then
			arr[#arr + 1] = p
		else
			-- RP name, steam name, SteamID64, SteamID (STEAM_0:x:y), + fac/grade/groupe.
			local sid64 = tostring(p.sid or "")
			local sid32 = (sid64 ~= "" and util.SteamIDFrom64 and util.SteamIDFrom64(sid64)) or ""
			local hay = string.lower(table.concat({
				p.name or "", p.steam or "", sid64, sid32,
				p.fac or "", p.rank or "", p.grp or "",
			}, " "))
			if string.find(hay, q, 1, true) then arr[#arr + 1] = p end
		end
	end
	local k, asc = DASH.sortKey, DASH.sortAsc
	table.sort(arr, function(a, b)
		local va, vb = a[k], b[k]
		if isnumber(va) or isnumber(vb) then va, vb = tonumber(va) or 0, tonumber(vb) or 0
		else va, vb = tostring(va or ""):lower(), tostring(vb or ""):lower() end
		if va == vb then return (a.name or "") < (b.name or "") end
		if asc then return va < vb else return va > vb end
	end)
	return arr
end

-- ============================================================================
-- FICHE JOUEUR (droite) : model 3D + infos + sanctions + actions groupées
-- ============================================================================
local function buildFiche(fiche)
	-- ── Model 3D (haut de la fiche) : cadre à coins coupés + liseré accent bas ──
	local modelArea = vgui.Create("DPanel", fiche)
	modelArea:Dock(TOP)
	modelArea:SetTall(s(200))
	modelArea:DockMargin(0, 0, 0, s(8))
	modelArea.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, Color(10, 10, 13), s(10))
		if not DASH.selSid then
			draw.SimpleText("AUCUN JOUEUR", "EVODash_Grp", w / 2, h / 2, TXT_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			local p = DASH.byId[DASH.selSid]
			if p then surface.SetDrawColor(ColorAlpha(facColor(p.fac), 200)) surface.DrawRect(0, h - s(2), w, s(2)) end
		end
	end

	local mdl = vgui.Create("DModelPanel", modelArea)
	mdl:Dock(FILL)
	mdl:DockMargin(s(4), s(4), s(4), s(6))
	mdl:SetFOV(48)
	mdl:SetVisible(false)
	-- Anime l'idle sans auto-spin (le rig lzy_character rend le visage via RenderOverride).
	mdl.LayoutEntity = function(_, e) if IsValid(e) then e:FrameAdvance(RealFrameTime()) end end

	-- Cadrage plein corps : dézoom fort pour tête + pieds dans le cadre.
	function mdl:FitCamera()
		local ent = self:GetEntity()
		if not IsValid(ent) then return end
		local mn, mx = ent:GetRenderBounds()
		if not mn or not mx then return end
		local center = (mn + mx) * 0.5
		local height = math.max(mx.z - mn.z, 16)
		local size = (mx - mn):Length()
		-- Distance large + FOV ouvert = personnage entier visible (plus croppé).
		local dist = math.max(height * 4.2, size * 1.45, 160)
		self:SetFOV(48)
		self:SetLookAt(center)
		self:SetCamPos(center + Vector(dist, dist * 0.06, height * 0.04))
	end

	-- Reconstruit l'apparence RÉELLE (visage custom compris) via le système lzy_character.
	function mdl:ApplyCharacter(data)
		if not istable(data) then self:SetVisible(false) return end
		local faceModel = data.face_model
		if (not isstring(faceModel) or faceModel == "") and LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
			faceModel = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(data.gender)
		end
		if not (isstring(faceModel) and faceModel ~= "" and util.IsValidModel(faceModel)) then
			self:SetVisible(false) return
		end
		self:SetVisible(true)
		self:SetModel(faceModel)
		local ent = self:GetEntity()
		if not IsValid(ent) then return end
		ent:SetSkin(tonumber(data.skin_color) or 0)
		if isstring(data.bodygroupsString) and data.bodygroupsString ~= "" then
			ent:SetBodyGroups(data.bodygroupsString)
		end
		if LZY_Character_PlayerModel_SetupPanelEntity then
			LZY_Character_PlayerModel_SetupPanelEntity(ent, data)
		end
		self:FitCamera()
		-- Re-cadrage après merge visage/cheveux (bounds changent au tick suivant).
		timer.Simple(0.15, function()
			if not IsValid(self) or not IsValid(ent) then return end
			if LZY_RefreshEntityFaceMaterials then LZY_RefreshEntityFaceMaterials(ent, data) end
			self:FitCamera()
		end)
	end

	-- ── Actions (bas) : hauteur plafonnée + scroll interne (sinon SA mange toute la fiche) ──
	local isSA = LocalPlayer():IsSuperAdmin()
	-- Source unique des orthographes SAM du rang : sh_staff_grades.lua (même addon).
	local isRespo = EVO_IsRespoModo ~= nil and EVO_IsRespoModo(LocalPlayer()) -- respo modo OU gérant RP
	local isModoPlus = EVO_IsModoPlus ~= nil and EVO_IsModoPlus(LocalPlayer())

	local ACTIONS_MAX = s(340)
	local actionsHost = vgui.Create("DPanel", fiche)
	actionsHost:Dock(BOTTOM)
	actionsHost:DockPadding(0, s(8), 0, 0)
	actionsHost.Paint = function(_, w, h)
		surface.SetDrawColor(SEP) surface.DrawRect(0, 0, w, 1)
	end
	local actions = vgui.Create("DScrollPanel", actionsHost)
	actions:Dock(FILL)
	do
		local vbar = actions:GetVBar()
		if IsValid(vbar) then
			vbar:SetWide(s(5))
			vbar:SetHideButtons(true)
			vbar.Paint = function() end
			vbar.btnUp.Paint, vbar.btnDown.Paint = function() end, function() end
			vbar.btnGrip.Paint = function(_, w, h)
				surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h)
			end
		end
	end

	-- ── Listes DIVISION / GRADE de la faction DE LA CIBLE (p.fac) ────────────────
	-- ⚠ l'index ne suit PAS le nom : « Division 4 » = index 5, « Division 2 » = index 3.
	-- On n'affiche donc que des noms ; le réseau envoie l'index, le serveur revalide.
	local function divisionChoices(sFaction, sCurrentName)
		local out, nDefault = {}, nil
		local cfg  = LZY_FACTION_CONFIG
		local divs = cfg and cfg.divisions and cfg.divisions[sFaction]
		if not istable(divs) then return out, nil end
		local spec = cfg.DivisionSpecialty -- source unique (pas les libellés du menu SAM)
		local tmp = {}
		for idx, name in pairs(divs) do
			idx = tonumber(idx)
			if idx then
				local sSpec = istable(spec) and spec[idx] or nil
				tmp[#tmp + 1] = {
					idx  = idx,
					-- tri par le NUMÉRO du nom (1, 2, 4, 11, 12), « Aucune » en tête
					num  = (idx <= 1) and -1 or (tonumber(string.match(tostring(name), "%d+")) or idx),
					raw  = tostring(name),
					label = tostring(name) .. (sSpec and (" — " .. sSpec) or ""),
				}
			end
		end
		table.sort(tmp, function(a, b) return a.num < b.num end)
		for _, t in ipairs(tmp) do
			out[#out + 1] = { label = t.label, value = t.idx }
			if sCurrentName ~= "" and t.raw == sCurrentName then nDefault = t.idx end
		end
		return out, nDefault
	end

	local function gradeChoices(sFaction, sCurrentName)
		local out, nDefault = {}, nil
		local cfg   = LZY_FACTION_CONFIG
		local ranks = cfg and cfg.factions and cfg.factions[sFaction]
		if not istable(ranks) then return out, nil end
		local nMax = 0
		for k in pairs(ranks) do k = tonumber(k) if k and k > nMax then nMax = k end end
		for i = 1, nMax do
			if ranks[i] then
				out[#out + 1] = { label = i .. " · " .. tostring(ranks[i]), value = i }
				if sCurrentName ~= "" and tostring(ranks[i]) == sCurrentName then nDefault = i end
			end
		end
		return out, nDefault
	end

	-- Dispatcher d'action par id (toggles + prompts DA EVO). Inchangé fonctionnellement.
	local function doAction(id)
		if not DASH.selSid then return end
		local p = DASH.byId[DASH.selSid]
		if id == "spectate" then
			if IsValid(LocalPlayer():GetEvoNWEntity("EVO_SpecTarget")) then
				act("unspectate")
			else
				act("spectate")
				if IsValid(UI) then UI:Remove() end -- ferme pour voir la vue observée
			end
		elseif id == "freeze" then
			act(p and p.frozen and "unfreeze" or "freeze")
		elseif id == "goto" or id == "bring" or id == "return" or id == "heal" then
			act(id)
		elseif id == "copysid" then
			-- Client pur : copie le SteamID64 du joueur sélectionné (aucun aller-retour serveur).
			if p and p.sid then
				SetClipboardText(p.sid)
				if isfunction(DASH.showToast) then DASH.showToast("SteamID64 copié : " .. p.sid, false) end
			end
		elseif id == "chathist" then
			if p and p.sid and EVO_OpenPlayerChatLogs then
				EVO_OpenPlayerChatLogs(p.sid, p.name)
			end
		elseif id == "pmhist" then
			if p and p.sid and EVO_OpenPlayerPMLogs then
				EVO_OpenPlayerPMLogs(p.sid, p.name)
			end
		elseif id == "rename" then
			evoPrompt("Renommer le personnage", {
				{ label = "Prénom", default = "" },
				{ label = "Nom", default = "" },
			}, function(first, last)
				first, last = string.Trim(first or ""), string.Trim(last or "")
				if first == "" or last == "" then return end
				local sid = DASH.selSid
				act("rename", first, last)
				if DASH.byId[sid] then DASH.byId[sid].name = first .. " " .. last end
			end)
		elseif id == "mute" then
			evoPrompt("Mute (chat)", { { label = "Durée en minutes (0 = permanent)", default = "0", numeric = true } }, function(m) act("mute", m) end)
		elseif id == "msg" then
			evoPrompt("Message à l'écran", {
				{ label = "Message (affiché plein écran chez le joueur)", default = "" },
				{ label = "Durée en secondes (3-30)", default = "6", numeric = true },
			}, function(txt, dura)
				if string.Trim(txt or "") == "" then return end
				act("msg", dura, txt)
			end)
		elseif id == "warn" then
			evoPrompt("Avertir le joueur", {
				{ label = "Titre (ex : RDM, Insultes, Cheat…)", default = "" },
				{ label = "Description", default = "" },
			}, function(title, desc)
				title = string.Trim(title or "")
				if title == "" then return end
				act("warn", title, desc)
			end)
		elseif id == "kick" then
			evoPrompt((isSA or isRespo) and "Kick" or "Kick (ban 30 min)", { { label = "Raison", default = "Staff" } }, function(r) act("kick", "", r) end)
		elseif id == "ban" then
			local maxBan = (isModoPlus and not isRespo)
				and (EVO_MODO_PLUS_BAN_MAX_MINUTES or (7 * 24 * 60))
				or (EVO_RESPO_BAN_MAX_MINUTES or (30 * 24 * 60))
			local maxLabel = isSA and "Durée en minutes (0 = permanent)"
				or (isModoPlus and not isRespo)
					and ("Durée en minutes (max " .. maxBan .. " = 7 jours)")
					or ("Durée en minutes (max " .. maxBan .. " = 30 jours)")
			evoPrompt("Ban", {
				{ label = maxLabel, default = isSA and "0" or tostring(maxBan), numeric = true },
				{ label = "Raison", default = "Staff" },
			}, function(m, r) act("ban", m, r) end)
		elseif id == "setgrade" then
			local sFac = (p and p.fac ~= "" and p.fac) or ""
			local tCh, nDef = gradeChoices(sFac, (p and p.rank) or "")
			if #tCh > 0 then
				evoPrompt("Grade — " .. ((p and p.name) or "joueur"), {
					{ label = "Grade dans " .. sFac, choices = tCh, default = nDef or 1 },
				}, function(g) if tonumber(g) then act("setgrade", g) end end)
			else
				-- Faction inconnue / config absente : saisie libre d'avant.
				evoPrompt("Grade", { { label = "Grade (1 - 16)", default = "", numeric = true } }, function(g)
					if tonumber(g) then act("setgrade", g) end
				end)
			end
		elseif id == "setdivision" then
			local sFac = (p and p.fac ~= "" and p.fac) or ""
			local tCh, nDef = divisionChoices(sFac, (p and p.div) or "")
			if #tCh > 0 then
				local sMot = (LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionWord
					and LZY_FACTION_CONFIG.DivisionWord(sFac)) or "Division"
				evoPrompt(sMot .. " — " .. ((p and p.name) or "joueur"), {
					{ label = sMot .. " dans " .. sFac, choices = tCh, default = nDef or 1 },
				}, function(d) if tonumber(d) then act("setdivision", d) end end)
			else
				evoPrompt("Division / Ordre", { { label = "Division (1 = Aucune, 2-6 = divisions / ordres)", default = "", numeric = true } }, function(d)
					if tonumber(d) then act("setdivision", d) end
				end)
			end
		elseif id == "ck" then
			-- Double-confirm côté serveur (20 s) : 1er clic arme, 2e confirme.
			act("ck")
		elseif id == "uncloak" then
			act("uncloak")
		elseif id == "noclipoff" then
			act("noclipoff")
		end
	end

	-- Catégories intuitives. mod=true -> visible pour les modérateurs ;
	-- respo / modoplus = rangs spécifiques. Un groupe n'apparaît que s'il
	-- a au moins une action visible.
	local GROUPS = {
		{ title = "Observation", items = {
			{ id = "spectate", label = "Observer", mod = true },
			{ id = "goto",     label = "Aller à", mod = true },
			{ id = "msg",      label = "Message", mod = true },
			{ id = "copysid",  label = "Copier SteamID", mod = true },
		}},
		{ title = "Parole", items = {
			{ id = "chathist", label = "Historique du chat", mod = true },
			-- Papillons (MP, anonymes démasqués) : modo+ / respo / SA (EVO_CanReadPapillons).
			{ id = "pmhist",   label = "Papillons", respo = true, modoplus = true },
		}},
		{ title = "Déplacement", items = {
			{ id = "bring",  label = "TP sur moi", mod = true },
			{ id = "return", label = "Renvoyer",   mod = true },
		}},
		{ title = "État", items = {
			{ id = "freeze", label = "Geler / Dégeler" },
			{ id = "heal",   label = "Soigner" },
			{ id = "rename",      label = "Renommer", respo = true, modoplus = true },
			{ id = "setgrade",    label = "Grade",    respo = true },
			{ id = "setdivision", label = "Division", respo = true },
		}},
		{ title = "Silence", items = {
			{ id = "mute", label = "Mute (chat)" },
		}},
		{ title = "Inter-admin", items = {
			{ id = "uncloak",   label = "Rendre visible" },
			{ id = "noclipoff", label = "Couper noclip" },
		}},
		{ title = "Sanctions", items = {
			{ id = "warn", label = "Avertir", mod = true, danger = true },
			{ id = "kick", label = (isSA or isRespo) and "Kick" or "Kick (30 min)", mod = true, danger = true },
			{ id = "ban",  label = isSA and "Ban" or ((isModoPlus and not isRespo) and "Ban (7 j max)" or "Ban (30 j max)"), respo = true, modoplus = true, danger = true },
			{ id = "ck",   label = "CK", respo = true, danger = true },
		}},
	}

	local HDR_H, BTN_H, GRP_GAP = s(19), s(30), s(9)
	local totalH = s(8)
	for _, g in ipairs(GROUPS) do
		local vis = {}
		for _, it in ipairs(g.items) do
			local show = isSA or it.mod or (isRespo and it.respo) or (isModoPlus and it.modoplus)
			if show then vis[#vis + 1] = it end
		end
		if #vis == 0 then continue end

		local gp = vgui.Create("DPanel", actions)
		gp:Dock(TOP)
		gp:DockMargin(0, 0, 0, GRP_GAP)
		gp:SetTall(HDR_H + BTN_H)
		local gTitle = string.upper(g.title)
		gp.Paint = function(_, w, h)
			draw.SimpleText(gTitle, "EVODash_Grp", 0, s(1), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end

		local rowBtns = {}
		for _, it in ipairs(vis) do
			rowBtns[#rowBtns + 1] = mkBtn(gp, it.label, it.danger and "danger" or nil, function() doAction(it.id) end)
		end
		gp.PerformLayout = function(_, w, h)
			local nb  = #rowBtns
			local gap = s(6)
			local bw  = (w - (nb - 1) * gap) / nb
			for i, b in ipairs(rowBtns) do
				b:SetPos((i - 1) * (bw + gap), HDR_H)
				b:SetSize(bw, BTN_H)
			end
		end
		totalH = totalH + HDR_H + BTN_H + GRP_GAP
	end
	actionsHost:SetTall(math.min(totalH, ACTIONS_MAX) + s(8))

	-- ── Infos + historique : UN seul scroll (évite stats/historique écrasés par les actions) ──
	local infoScroll = vgui.Create("DScrollPanel", fiche)
	infoScroll:Dock(FILL)
	infoScroll:DockMargin(0, 0, 0, s(6))
	do
		local vbar = infoScroll:GetVBar()
		if IsValid(vbar) then
			vbar:SetWide(s(5))
			vbar:SetHideButtons(true)
			vbar.Paint = function() end
			vbar.btnUp.Paint, vbar.btnDown.Paint = function() end, function() end
			vbar.btnGrip.Paint = function(_, w, h)
				surface.SetDrawColor(146, 152, 161, 110) surface.DrawRect(0, 0, w, h)
			end
		end
	end

	local INFO_TOP_H = s(198)
	local infoTop = vgui.Create("DPanel", infoScroll)
	infoTop:Dock(TOP)
	infoTop:SetTall(INFO_TOP_H)
	infoTop:SetPaintBackground(false)
	infoTop.Paint = function(_, w, h)
		local p = DASH.selSid and DASH.byId[tostring(DASH.selSid)]
		if not p then
			draw.SimpleText("Sélectionne un joueur dans la liste", "EVODash_B", w / 2, h / 2, TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		local pad = s(2)
		local y = 0
		surface.SetDrawColor(facColor(p.fac)) surface.DrawRect(pad, s(10), s(4), s(30))
		local nameX = pad + s(14)
		draw.SimpleText(short(p.name, 22), "EVODash_Big", nameX, y, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + s(46)
		draw.SimpleText(p.steam .. "  ·  " .. (p.grp or "user"), "EVODash_S", nameX, y, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + s(22)
		if p.staff then draw.SimpleText("● EN MODE STAFF", "EVODash_XS", nameX, y, WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + s(18) end
		y = y + s(8)

		local stats = {
			{ "Faction", p.fac ~= "" and p.fac or "—", facColor(p.fac) },
			{ "Argent", fmtMoney(p.money), WARN_COL },
			{ "Division", p.div ~= "" and p.div or "—" },
			{ "Temps", fmtPlaytime(p.pt) },
			{ "Grade", p.rank ~= "" and p.rank or "—" },
			{ "Position", math.floor(p.x) .. ", " .. math.floor(p.y) },
		}
		local gap  = s(10)
		local colw = (w - pad * 2 - gap) / 2
		local rowH = s(30)
		local function chipAt(x, label, val, col)
			roundRect(s(4), x, y, colw, rowH - s(4), CHIP)
			draw.SimpleText(label, "EVODash_XS", x + s(9), y + (rowH - s(4)) / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine(tostring(val), "EVODash_S", x + colw - s(9), y + (rowH - s(4)) / 2 - s(1), col or TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		for i = 1, #stats, 2 do
			chipAt(pad, stats[i][1], stats[i][2], stats[i][3])
			if stats[i + 1] then chipAt(pad + colw + gap, stats[i + 1][1], stats[i + 1][2], stats[i + 1][3]) end
			y = y + rowH
		end
		if p.frozen then draw.SimpleText("● GELÉ", "EVODash_S", pad, y, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + s(22) end

		y = y + s(2)
		surface.SetDrawColor(SEP) surface.DrawRect(pad, y, w - pad * 2, 1) y = y + s(6)
		local d = DASH.detail[tostring(p.sid)]
		if not d then
			draw.SimpleText("Sanctions : chargement…", "EVODash_S", pad, y, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		else
			local nw = #(d.warns or {})
			draw.SimpleText("Warns actifs : " .. nw, "EVODash_B", pad, y, nw > 0 and WARN_COL or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(d.ban and "BANNI" or "Non banni", "EVODash_B", w - pad, y, d.ban and ACCENT or TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
	end

	local histOpen = false -- replié par défaut (place pour stats + model)
	local histHead = vgui.Create("DButton", infoScroll)
	histHead:SetText("")
	histHead:SetCursor("hand")
	histHead:Dock(TOP)
	histHead:SetTall(s(26))
	histHead:DockMargin(0, 0, 0, s(2))
	histHead.Paint = function(_, w, h)
		local sid = tostring(DASH.selSid or "")
		if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
		local d = (sid ~= "" and DASH.detail[sid]) or nil
		local n = d and istable(d.history) and #d.history or nil
		local arrow = histOpen and "▾" or "▸"
		local label = "HISTORIQUE SANCTIONS  " .. arrow
		if n ~= nil then label = label .. "  (" .. n .. ")" end
		draw.SimpleText(label, "EVODash_Grp", s(2), h / 2, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local histRows = {}
	local histSig = ""
	local function rebuildHistory()
		for _, r in ipairs(histRows) do if IsValid(r) then r:Remove() end end
		histRows = {}
		local sid = tostring(DASH.selSid or "")
		if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
		local function addEmpty(txt)
			local empty = vgui.Create("DLabel", infoScroll)
			empty:Dock(TOP)
			empty:SetTall(s(28))
			empty:SetFont("EVODash_S")
			empty:SetTextColor(TXT_DIM)
			empty:SetText(txt)
			histRows[#histRows + 1] = empty
		end
		if sid == "" then
			histSig = "none"
			if histOpen then addEmpty("Sélectionne un joueur.") end
			return
		end
		local d = DASH.detail[sid]
		if not d then
			histSig = sid .. ":pending:" .. tostring(histOpen)
			if histOpen then addEmpty("Chargement de l'historique…") end
			return
		end
		local hist = istable(d.history) and d.history or {}
		histSig = sid .. ":" .. tostring(#hist) .. ":" .. tostring(histOpen)
		if not histOpen then
			infoScroll:InvalidateLayout(true)
			return
		end
		if #hist == 0 then
			addEmpty("Aucune sanction enregistrée.")
			return
		end
		for _, h in ipairs(hist) do
			local row = vgui.Create("DPanel", infoScroll)
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(4))
			row:SetTall(s(40))
			row:SetPaintBackground(false)
			histRows[#histRows + 1] = row
			local act = prettySanction(h.action)
			local when = fmtSanctionWhen(h.ts)
			local who = tostring(h.staff or "?")
			local det = tostring(h.details or "")
			local danger = (act == "Ban" or act == "CK" or act == "Warn→Ban" or act == "Kick")
			row.Paint = function(_, w, hh)
				roundRect(s(4), 0, 0, w, hh, CHIP)
				draw.SimpleText(act, "EVODash_S", s(8), s(5), danger and ACCENT or WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(when, "EVODash_XS", w - s(8), s(6), TXT_MUT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				local line = who
				if det ~= "" then line = who .. " — " .. short(det, 48) end
				MUGEN.DrawMoneyLine(line, "EVODash_XS", s(8), s(22), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
		end
		infoScroll:InvalidateLayout(true)
	end
	histHead.DoClick = function()
		histOpen = not histOpen
		rebuildHistory()
		surface.PlaySound("garrysmod/ui_click.wav")
	end
	-- Autoguérison : si Detail arrive alors que onDetail a été raté (rebuild mid-frame /
	-- onglet clans / Remove), on resync dès que la signature change.
	histHead.Think = function()
		local sid = tostring(DASH.selSid or "")
		if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
		local d = (sid ~= "" and DASH.detail[sid]) or nil
		local want
		if sid == "" then
			want = "none"
		elseif not d then
			want = sid .. ":pending:" .. tostring(histOpen)
		else
			want = sid .. ":" .. tostring(#(d.history or {})) .. ":" .. tostring(histOpen)
		end
		if want ~= histSig then rebuildHistory() end
	end

	-- Applique l'apparence 3D du joueur sélectionné.
	local function refreshModel()
		if not DASH.selSid then mdl:SetVisible(false) return end
		local ent = player.GetBySteamID64 and player.GetBySteamID64(DASH.selSid)
		if not IsValid(ent) then mdl:SetVisible(false) return end
		local data = GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ent)
		if istable(data) then mdl:ApplyCharacter(data) else mdl:SetVisible(false) end
	end
	fiche._refreshModel = refreshModel
	fiche._rebuildHistory = rebuildHistory
	rebuildHistory()
	return refreshModel, rebuildHistory
end

-- ============================================================================
-- VUE PRINCIPALE : recherche + liste (gauche) + fiche (droite)
-- ============================================================================
local function buildContent(content)
	content:Clear()

	-- Fiche (droite)
	local fiche = vgui.Create("DPanel", content)
	fiche:Dock(RIGHT)
	fiche:SetWide(s(568))
	fiche:DockMargin(s(14), 0, 0, 0)
	fiche:DockPadding(s(16), s(14), s(16), s(14))
	fiche.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, CARD2, s(12))
	end
	local refreshModel, rebuildHistory = buildFiche(fiche)

	-- Barre de RECHERCHE (gauche, en haut) — gain d'intuitivité : trouver un joueur vite.
	local searchBar = vgui.Create("DPanel", content)
	searchBar:Dock(TOP)
	searchBar:SetTall(s(38))
	searchBar:DockMargin(0, 0, 0, s(8))
	searchBar.Paint = function(_, w, h)
		roundRect(s(5), 0, 0, w, h, FIELD)
		-- Petite loupe dessinée (pas d'emoji : rendrait en tofu avec ces polices).
		local cx, cy, rr = s(15), h / 2, s(6)
		surface.SetDrawColor(TXT_MUT)
		local seg = 14
		for i = 0, seg - 1 do
			local a1, a2 = math.rad(i / seg * 360), math.rad((i + 1) / seg * 360)
			surface.DrawLine(cx + math.cos(a1) * rr, cy - s(1) + math.sin(a1) * rr, cx + math.cos(a2) * rr, cy - s(1) + math.sin(a2) * rr)
		end
		surface.DrawLine(cx + rr * 0.7, cy - s(1) + rr * 0.7, cx + rr * 1.6, cy - s(1) + rr * 1.6)
	end
	local search = vgui.Create("DTextEntry", searchBar)
	search:Dock(FILL)
	search:DockMargin(s(30), s(6), s(10), s(6))
	search:SetFont("EVODash_B")
	search:SetTextColor(TXT) search:SetCursorColor(TXT) search:SetPaintBackground(false)
	search:SetDrawLanguageID(false)
	search:SetUpdateOnType(true)
	search:SetPlaceholderText("Rechercher (nom RP, Steam, SteamID, SteamID64…)")
	search.Paint = function(self, w, h)
		self:DrawTextEntryText(TXT, ACCENT, TXT)
		if self:GetText() == "" and not self:HasFocus() then
			draw.SimpleText(self:GetPlaceholderText(), "EVODash_S", 0, h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	search.OnValueChange = function(_, val)
		DASH.search = val or ""
		if isfunction(DASH.onSnap) then DASH.onSnap() end
	end
	-- Clic sur la barre (loupe / marges) = focus le champ (la racine est un DFrame :
	-- le routage clavier est natif, pas besoin de RequestFocus à l'ouverture).
	searchBar:SetMouseInputEnabled(true)
	searchBar.OnMousePressed = function() if IsValid(search) then search:RequestFocus() end end

	-- En-têtes de colonnes (gauche)
	local header = vgui.Create("DPanel", content)
	header:Dock(TOP)
	header:SetTall(s(30))
	header:SetMouseInputEnabled(true)
	header.Paint = function(_, w, h)
		local x = s(10)
		for _, c in ipairs(COLS) do
			local lbl = c.label
			if DASH.sortKey == c.key then lbl = lbl .. (DASH.sortAsc and " ▲" or " ▼") end
			draw.SimpleText(string.upper(lbl), "EVODash_XS", x, h / 2, DASH.sortKey == c.key and ACCENT or TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			x = x + c.w
		end
	end
	header.OnMousePressed = function(self, code)
		if code ~= MOUSE_LEFT then return end
		local mx = self:ScreenToLocal(gui.MouseX(), 0)
		local x = s(10)
		for _, c in ipairs(COLS) do
			if mx >= x and mx < x + c.w then
				if DASH.sortKey == c.key then DASH.sortAsc = not DASH.sortAsc
				else DASH.sortKey = c.key DASH.sortAsc = (c.key == "name") end
				if isfunction(DASH.onSnap) then DASH.onSnap() end
				return
			end
			x = x + c.w
		end
	end

	local list = vgui.Create("DScrollPanel", content)
	list:Dock(FILL)
	list.Paint = function(_, w, h) end
	local vbar = list:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(s(5))
		vbar.Paint = function() end
		vbar.btnUp.Paint = function() end
		vbar.btnDown.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h) end
	end

	local rows = {}
	local function makeRow(sid)
		sid = tostring(sid or "")
		local r = list:Add("DButton")
		r:Dock(TOP)
		r:DockMargin(0, 0, s(6), s(3))
		r:SetTall(s(36))
		r:SetText("")
		r:SetCursor("hand")
		r._hf = 0
		r.DoClick = function()
			DASH.selSid = sid
			requestDetail(sid)
			refreshModel()
			if rebuildHistory then rebuildHistory() end
			surface.PlaySound("garrysmod/ui_click.wav")
		end
		r.Paint = function(self, w, h)
			local p = DASH.byId[sid]
			if not p then return end
			local sel = (tostring(DASH.selSid or "") == sid)
			self._hf = Lerp(FrameTime() * 12, self._hf or 0, self:IsHovered() and 1 or 0)
			local bg
			if sel then bg = Color(ACCENT.r, ACCENT.g, ACCENT.b, 46)
			else bg = Color(ROWALT.r + 8 * self._hf, ROWALT.g + 8 * self._hf, ROWALT.b + 10 * self._hf, (self._z or 0) % 2 == 0 and 150 or 90) end
			roundRect(s(4), 0, 0, w, h, bg)
			-- Pastille faction (gauche) + liseré sélection.
			surface.SetDrawColor(facColor(p.fac)) surface.DrawRect(0, s(6), s(3), h - s(12))
			if sel then surface.SetDrawColor(ACCENT) surface.DrawRect(0, 0, s(3), h) end
			if p.staff then surface.SetDrawColor(WARN_COL) surface.DrawRect(w - s(3), s(6), s(3), h - s(12)) end

			local x = s(10)
			local function cell(txt, col)
				MUGEN.DrawMoneyLine(txt, "EVODash_S", x, h / 2, col or TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			cell(short(p.name, 22));                                        x = x + COLS[1].w
			cell(short(p.steam ~= "" and p.steam or "—", 20), TXT_DIM);    x = x + COLS[2].w
			cell(p.fac ~= "" and p.fac or "—", facColor(p.fac));            x = x + COLS[3].w
			cell(short(p.rank ~= "" and p.rank or "—", 18), TXT_DIM);       x = x + COLS[4].w
			cell(fmtMoney(p.money), WARN_COL)
		end
		return r
	end

	local function refreshList()
		local visible = sortedPlayers()
		local seen = {}
		for _, p in ipairs(visible) do seen[p.sid] = true end
		-- retire les lignes hors filtre / déconnectées
		for sid, r in pairs(rows) do
			if not seen[sid] then if IsValid(r) then r:Remove() end rows[sid] = nil end
		end
		for i, p in ipairs(visible) do
			local r = rows[p.sid]
			if not r or not IsValid(r) then r = makeRow(p.sid) rows[p.sid] = r end
			r._z = i
			r:SetZPos(i)
		end

		-- Résout la pré-sélection inspect→dashboard (UserID puis SteamID64).
		-- Si le snap n'a pas le joueur (filtre) ou a écrasé le seed, on re-seed
		-- depuis l'entité live pour que la fiche reste ouverte.
		local function resolvePreselect()
			if not (DASH.preselectUid or DASH.preselectSid) then return nil end
			local wantUid = tonumber(DASH.preselectUid)
			if wantUid and next(DASH.byId) ~= nil then
				for _, p in pairs(DASH.byId) do
					if tonumber(p.uid) == wantUid then return p.sid end
				end
			end
			local wantSid = DASH.preselectSid and tostring(DASH.preselectSid) or ""
			if wantSid ~= "" and DASH.byId[wantSid] then return wantSid end
			-- Snap vide ou joueur absent → seed live.
			local live = findLiveForPreselect()
			if IsValid(live) then return seedFromPlayer(live) end
			if next(DASH.byId) ~= nil then return false end -- snap là, joueur offline
			return nil -- encore en attente du 1er snap
		end

		local resolved = resolvePreselect()
		if resolved then
			DASH.selSid = resolved
			DASH.preselectSid = nil
			DASH.preselectUid = nil
			requestDetail(resolved)
			refreshModel()
			if rebuildHistory then rebuildHistory() end
		elseif resolved == false then
			DASH.preselectSid = nil
			DASH.preselectUid = nil
		end

		-- Le snap remplace byId entier : si le joueur sélectionné a disparu du
		-- payload (filtre SA/respo) on re-seed depuis l'entité live pour garder la fiche.
		if DASH.selSid and not DASH.byId[tostring(DASH.selSid)] then
			local live = findLiveForPreselect()
			if not IsValid(live) and player.GetBySteamID64 then
				live = player.GetBySteamID64(tostring(DASH.selSid))
			end
			if IsValid(live) then
				local sid = seedFromPlayer(live)
				if sid then DASH.selSid = sid end
				refreshModel()
				if rebuildHistory then rebuildHistory() end
			end
		end
	end

	DASH.onSnap = refreshList
	DASH.onDetail = function()
		if rebuildHistory then rebuildHistory() end
	end
	refreshList()
	if DASH.selSid and DASH.byId[DASH.selSid] then
		requestDetail(DASH.selSid)
		refreshModel()
		if rebuildHistory then rebuildHistory() end
	elseif DASH.preselectSid or DASH.selSid then
		requestDetail(DASH.preselectSid or DASH.selSid)
		if rebuildHistory then rebuildHistory() end
	end
end

-- ============================================================================
-- ONGLET CLANS : liste (gauche) + fiche (droite : banque, niveau, spell, membres)
-- ============================================================================
local function styleDashBar(list)
	local vbar = list:GetVBar()
	if not IsValid(vbar) then return end
	vbar:SetWide(s(5))
	vbar.Paint = function() end
	vbar.btnUp.Paint = function() end
	vbar.btnDown.Paint = function() end
	vbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h) end
end

local function buildClansContent(content)
	content:Clear()

	local CLAN_COLS = {
		{ key = "label",   label = "Clan",     w = s(200) },
		{ key = "faction", label = "Faction",  w = s(120) },
		{ key = "members", label = "Membres",  w = s(100) },
		{ key = "level",   label = "Niveau",   w = s(80) },
		{ key = "pot",     label = "Banque",   w = s(140) },
		{ key = "spell",   label = "Spell",    w = s(130) },
	}

	local function sortedClans()
		local arr = {}
		local q = string.lower(string.Trim(DASH.clanSearch or ""))
		for _, c in ipairs(DASH.clans) do
			if q == "" then
				arr[#arr + 1] = c
			else
				local hay = string.lower(table.concat({
					c.label or "", c.faction or "", c.leader or "", c.key or "",
				}, " "))
				if string.find(hay, q, 1, true) then arr[#arr + 1] = c end
			end
		end
		local k, asc = DASH.clanSortKey, DASH.clanSortAsc
		table.sort(arr, function(a, b)
			local va, vb
			if k == "spell" then
				va, vb = spellStatusRank(a), spellStatusRank(b)
			else
				va, vb = a[k], b[k]
			end
			if isnumber(va) or isnumber(vb) then va, vb = tonumber(va) or 0, tonumber(vb) or 0
			else va, vb = tostring(va or ""):lower(), tostring(vb or ""):lower() end
			if va == vb then return (a.label or "") < (b.label or "") end
			if asc then return va < vb else return va > vb end
		end)
		return arr
	end

	local fiche = vgui.Create("DPanel", content)
	fiche:Dock(RIGHT)
	fiche:SetWide(s(568))
	fiche:DockMargin(s(14), 0, 0, 0)
	fiche:DockPadding(s(16), s(14), s(16), s(14))
	fiche.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, CARD2, s(12))
	end

	local membersScroll = vgui.Create("DScrollPanel", fiche)
	membersScroll:Dock(FILL)
	membersScroll:DockMargin(0, s(8), 0, 0)
	styleDashBar(membersScroll)

	local head = vgui.Create("DPanel", fiche)
	head:Dock(TOP)
	head:SetTall(s(268))
	head.Paint = function(_, w, h)
		local c = DASH.selClan and DASH.clanByKey[DASH.selClan]
		if not c then
			draw.SimpleText("Sélectionne un clan dans la liste", "EVODash_B", w / 2, h / 2, TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		local pad = s(2)
		surface.SetDrawColor(facColor(c.faction)) surface.DrawRect(pad, s(10), s(4), s(30))
		draw.SimpleText(short(c.label, 28), "EVODash_Big", pad + s(14), 0, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local y = s(46)
		draw.SimpleText((c.leader ~= "" and c.leader or "sans leader") .. "  ·  " .. (c.faction or "—"),
			"EVODash_S", pad + s(14), y, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		y = y + s(28)

		local stats = {
			{ "Banque", fmtMoney(c.pot), WARN_COL },
			{ "Niveau", tostring(c.level or 1) },
			{ "Membres", (c.members or 0) .. " / " .. (c.cap or 0) .. "  (" .. (c.online or 0) .. " en ligne)" },
			{ "Warns (7j) ▸", tostring(c.warns or 0), (c.warns or 0) > 0 and ACCENT or TXT },
			{ "Taxe", c.taxOk and "à jour" or "en retard", c.taxOk and OK_COL or ACCENT },
			{ "Bâtiment", c.building and "acheté" or "non", c.building and OK_COL or TXT_DIM },
		}
		local gap = s(10)
		local colw = (w - pad * 2 - gap) / 2
		local rowH = s(30)
		head._warnChip = nil
		local function chipAt(x, label, val, col)
			roundRect(s(4), x, y, colw, rowH - s(4), CHIP)
			draw.SimpleText(label, "EVODash_XS", x + s(9), y + (rowH - s(4)) / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			MUGEN.DrawMoneyLine(tostring(val), "EVODash_S", x + colw - s(9), y + (rowH - s(4)) / 2 - s(1), col or TXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		for i = 1, #stats, 2 do
			chipAt(pad, stats[i][1], stats[i][2], stats[i][3])
			if stats[i + 1] then
				local x2 = pad + colw + gap
				chipAt(x2, stats[i + 1][1], stats[i + 1][2], stats[i + 1][3])
				if i + 1 == 4 then
					head._warnChip = { x = x2, y = y, w = colw, h = rowH - s(4) }
				end
			end
			y = y + rowH
		end

		y = y + s(4)
		surface.SetDrawColor(SEP) surface.DrawRect(pad, y, w - pad * 2, 1) y = y + s(8)
		local sp = c.spell
		local sLbl, sCol = spellStatusLabel(c)
		draw.SimpleText("SPELL UNIQUE", "EVODash_Grp", pad, y, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(sLbl, "EVODash_S", w - pad, y + s(2), sCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		y = y + s(22)
		if istable(sp) then
			local checks = {
				{ ok = sp.checks and sp.checks.level,   lab = "Clan niveau " .. (sp.minLevel or 3), val = "Niv. " .. (sp.level or 1) },
				{ ok = sp.checks and sp.checks.members, lab = (sp.minMembers or 10) .. " membres", val = (sp.members or 0) .. " / " .. (sp.minMembers or 10) },
				{ ok = sp.checks and sp.checks.high,    lab = (sp.minHigh or 10) .. " membres niv. " .. (sp.threshold or 60) .. "+", val = (sp.high or 0) .. " / " .. (sp.minHigh or 10) },
				{ ok = sp.checks and sp.checks.warns,   lab = "Aucun warn de clan actif", val = (sp.warns or 0) .. " actif(s)" },
				{ ok = sp.checks and sp.checks.age,     lab = (sp.minAgeDays or 7) .. " jours d'existence", val = (sp.ageDays or 0) .. " / " .. (sp.minAgeDays or 7) .. " j" },
			}
			local cw = (w - pad * 2 - s(8)) / 2
			local ch = s(22)
			for i, ck in ipairs(checks) do
				local col = (i % 2 == 1) and pad or (pad + cw + s(8))
				local row = math.floor((i - 1) / 2)
				local yy = y + row * ch
				draw.SimpleText((ck.ok and "● " or "○ ") .. ck.lab, "EVODash_XS", col, yy, ck.ok and OK_COL or TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(ck.val, "EVODash_XS", col + cw - s(4), yy, ck.ok and OK_COL or ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			end
		end
	end
	head.Think = function(self)
		local r = self._warnChip
		if not r then self:SetCursor("arrow") return end
		local mx, my = self:CursorPos()
		self:SetCursor((mx >= r.x and mx <= r.x + r.w and my >= r.y and my <= r.y + r.h) and "hand" or "arrow")
	end
	head.OnMousePressed = function(self, mc)
		if mc ~= MOUSE_LEFT then return end
		local r = self._warnChip
		if not r then return end
		local mx, my = self:CursorPos()
		if mx >= r.x and mx <= r.x + r.w and my >= r.y and my <= r.y + r.h and DASH.selClan then
			showClanWarnList(DASH.selClan)
			surface.PlaySound("garrysmod/ui_click.wav")
		end
	end

	local warnBar = vgui.Create("DPanel", fiche)
	warnBar:Dock(TOP)
	warnBar:DockMargin(0, 0, 0, s(6))
	warnBar:SetTall(0)

	local demandeBar = vgui.Create("DPanel", fiche)
	demandeBar:Dock(TOP)
	demandeBar:DockMargin(0, 0, 0, s(6))
	demandeBar:SetTall(s(52))
	local isSA = LocalPlayer():IsSuperAdmin()

	-- Clear() détruit les boutons ; SetTall / le dock parent relance ensuite
	-- l'ancien PerformLayout, qui SetSize des panels déjà NULL.
	local function resetBarLayout(bar)
		if not IsValid(bar) then return end
		bar.PerformLayout = function() end
		bar:Clear()
	end

	local function refreshWarnBar()
		if not IsValid(warnBar) then return end
		resetBarLayout(warnBar)
		local c = DASH.selClan and DASH.clanByKey[DASH.selClan]
		if not c then
			warnBar:SetTall(0)
			warnBar.Paint = function() end
			return
		end
		warnBar:SetTall(s(46))
		local nWarns = tonumber(c.warns) or 0
		local key = c.key
		warnBar.Paint = function(_, w, h)
			roundRect(s(5), 0, 0, w, h, nWarns > 0 and Color(ACCENT.r, ACCENT.g, ACCENT.b, 28) or CHIP)
			if nWarns > 0 then surface.SetDrawColor(ACCENT) surface.DrawRect(0, s(6), s(4), h - s(12)) end
			draw.SimpleText("WARNS ACTIFS (7 J)", "EVODash_Grp", s(14), h / 2, nWarns > 0 and ACCENT or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(tostring(nWarns), "EVODash_B", s(248), h / 2, nWarns > 0 and ACCENT or TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local btnList = mkBtn(warnBar, "LISTE", nil, function()
			showClanWarnList(key)
		end)
		local btnP, btnM
		if isSA then
			btnP = mkBtn(warnBar, "WARNER", "danger", function()
				evoPrompt("Warn de clan — 7 jours", {
					{ label = "Titre", default = "" },
					{ label = "Description", default = "" },
				}, function(title, desc)
					title = string.Trim(title or "")
					if title == "" then return end
					sendClanWarnAdd(key, title, desc)
				end)
			end)
			btnM = mkBtn(warnBar, "LEVER", nil, function()
				sendClanWarn(key, -1)
			end)
			btnM:SetEnabled(nWarns > 0)
		end
		warnBar.PerformLayout = function(_, w, h)
			if not IsValid(btnList) then return end
			local x = w - s(14)
			if IsValid(btnM) and IsValid(btnP) then
				btnM:SetSize(s(80), s(30))
				btnP:SetSize(s(110), s(30))
				x = x - s(80)
				btnM:SetPos(x, (h - s(30)) / 2)
				x = x - s(8) - s(110)
				btnP:SetPos(x, (h - s(30)) / 2)
				x = x - s(8)
			end
			btnList:SetSize(s(90), s(30))
			btnList:SetPos(x - s(90), (h - s(30)) / 2)
		end
	end

	local function refreshDemande()
		if not IsValid(demandeBar) then return end
		resetBarLayout(demandeBar)
		local c = DASH.selClan and DASH.clanByKey[DASH.selClan]
		if not c then
			demandeBar:SetTall(s(4))
			demandeBar.Paint = function() end
			return
		end
		local st = clanSpellStatus(c)
		local pending = st == "pending"
		demandeBar:SetTall(pending and isSA and s(86) or s(54))
		local sLbl, sCol = spellStatusLabel(c)
		local when = fmtWhen(clanSpellAt(c))
		local sub
		if st == "pending" then sub = "Déposée le " .. when
		elseif st == "accepted" then sub = "Acceptée le " .. when
		elseif st == "refused" then sub = "Refusée le " .. when .. " — re-soumission possible"
		elseif clanSpellEligible(c) then sub = "Prérequis OK — aucune demande envoyée"
		else sub = "Pas de demande en cours"
		end
		demandeBar.Paint = function(_, w, h)
			roundRect(s(5), 0, 0, w, h, pending and Color(WARN_COL.r, WARN_COL.g, WARN_COL.b, 32) or CHIP)
			if pending then surface.SetDrawColor(WARN_COL) surface.DrawRect(0, s(6), s(4), h - s(12)) end
			draw.SimpleText("DEMANDE SPELL UNIQUE", "EVODash_Grp", s(14), s(8), pending and WARN_COL or TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(sLbl, "EVODash_S", w - s(14), s(10), sCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			draw.SimpleText(sub, "EVODash_XS", s(14), s(30), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		if pending and isSA then
			local key = c.key
			local btnA = mkBtn(demandeBar, "ACCEPTER", "primary", function() sendClanSpellDecision(key, true) end)
			local btnR = mkBtn(demandeBar, "REFUSER", "danger", function() sendClanSpellDecision(key, false) end)
			demandeBar.PerformLayout = function(_, w, h)
				if not IsValid(btnR) or not IsValid(btnA) then return end
				btnR:SetSize(s(110), s(28))
				btnA:SetSize(s(130), s(28))
				btnR:SetPos(w - s(14) - s(110), h - s(36))
				btnA:SetPos(w - s(14) - s(110) - s(8) - s(130), h - s(36))
			end
		end
	end

	local function refreshMembers()
		membersScroll:Clear()
		local key = DASH.selClan
		if not key then return end
		local rows = DASH.clanMembers[key]
		if not istable(rows) then
			local wait = membersScroll:Add("DLabel")
			wait:Dock(TOP) wait:SetTall(s(28))
			wait:SetFont("EVODash_S") wait:SetTextColor(TXT_DIM)
			wait:SetText("Membres : chargement…")
			return
		end

		local hist = DASH.clanWarnHist[key]
		local hTitle = membersScroll:Add("DButton")
		hTitle:SetText("")
		hTitle:Dock(TOP) hTitle:SetTall(s(22))
		hTitle:SetCursor("hand")
		hTitle.Paint = function(_, w, h)
			draw.SimpleText("HISTORIQUE WARNS CLAN  ▸", "EVODash_Grp", 0, h / 2, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		hTitle.DoClick = function() showClanWarnList(key) end
		if not istable(hist) or #hist == 0 then
			local none = membersScroll:Add("DPanel")
			none:Dock(TOP) none:SetTall(s(24))
			none.Paint = function(_, w, h)
				draw.SimpleText("Aucun warn de clan.", "EVODash_XS", 0, h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		else
			for _, w in ipairs(hist) do
				local row = membersScroll:Add("DButton")
				row:SetText("")
				row:SetCursor("hand")
				row:Dock(TOP)
				row:DockMargin(0, 0, s(4), s(3))
				local sMember = string.Trim(tostring(w.member or ""))
				local sReason = string.Trim(tostring(w.reason or ""))
				row:SetTall((sMember ~= "" or sReason ~= "") and s(56) or s(40))
				local bActive = tonumber(w.active) == 1 or w.active == true
				local st, col = clanWarnStatus(w)
				row.Paint = function(_, ww, hh)
					roundRect(s(4), 0, 0, ww, hh, CHIP)
					if bActive then surface.SetDrawColor(ACCENT) surface.DrawRect(0, s(6), s(3), hh - s(12)) end
					draw.SimpleText(short(w.title ~= "" and w.title or "Warn de clan", 34), "EVODash_S", s(12), s(6), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					local y = s(24)
					if sMember ~= "" then
						draw.SimpleText("Membre : " .. short(sMember, 34), "EVODash_XS", s(12), y, WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
						y = y + s(14)
					end
					if sReason ~= "" then
						draw.SimpleText(short(sReason, 48), "EVODash_XS", s(12), y, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end
					draw.SimpleText(st .. "  ·  " .. (w.staff ~= "" and w.staff or "?") .. "  ·  " .. fmtWhen(w.at), "EVODash_XS", ww - s(10), s(8), col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				end
				row.DoClick = function() showClanWarnList(key) end
			end
		end

		local title = membersScroll:Add("DPanel")
		title:Dock(TOP) title:SetTall(s(26)) title:DockMargin(0, s(8), 0, 0)
		title.Paint = function(_, w, h)
			draw.SimpleText("MEMBRES  (" .. #rows .. ")  —  SANCTIONS JOUEUR", "EVODash_Grp", 0, h / 2, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		if #rows == 0 then
			local none = membersScroll:Add("DPanel")
			none:Dock(TOP) none:SetTall(s(28))
			none.Paint = function(_, w, h)
				draw.SimpleText("Aucun membre.", "EVODash_S", 0, h / 2, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			return
		end
		for i, m in ipairs(rows) do
			local sans = istable(m.sanctions) and m.sanctions or {}
			local nShow = math.min(#sans, 4)
			local row = membersScroll:Add("DPanel")
			row:Dock(TOP)
			row:DockMargin(0, 0, s(4), s(3))
			row:SetTall(s(36) + (nShow > 0 and (s(4) + nShow * s(16)) or 0))
			row.Paint = function(_, w, h)
				roundRect(s(4), 0, 0, w, h, Color(ROWALT.r, ROWALT.g, ROWALT.b, i % 2 == 0 and 150 or 90))
				surface.SetDrawColor(m.online and OK_COL or TXT_MUT)
				surface.DrawRect(s(8), s(12), s(8), s(8))
				local role = m.isLeader and "  ·  LEADER" or (m.isOfficer and "  ·  BRAS DROIT" or "")
				local rank = (m.rankName and m.rankName ~= "") and ("  ·  " .. m.rankName) or ""
				draw.SimpleText(short((m.name or "?") .. role .. rank, 34), "EVODash_S", s(24), s(8), m.isLeader and ACCENT or TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				local nAct = tonumber(m.warnCount) or 0
				draw.SimpleText("niv. " .. (m.level or 0) .. (nAct > 0 and ("  ·  " .. nAct .. " warn") or ""), "EVODash_XS", w - s(10), s(10), nAct > 0 and ACCENT or TXT_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				for j = 1, nShow do
					local wn = sans[j]
					local bRem = tonumber(wn.removed) == 1 or wn.removed == true
					local bExp = (not bRem) and (tonumber(wn.expired) == 1 or wn.expired == true) -- plus actif (7 j)
					local line = (bRem and "[retiré] " or (bExp and "[expiré] " or "")) .. (wn.title ~= "" and wn.title or "Warn") .. "  ·  " .. fmtWhen(wn.at)
					draw.SimpleText(short(line, 46), "EVODash_XS", s(24), s(26) + (j - 1) * s(16), (bRem or bExp) and TXT_MUT or WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
			end
		end
	end

	local function selectClan(key)
		DASH.selClan = key
		DASH.clanMembers[key] = nil
		DASH.clanWarnHist[key] = nil
		requestClanDetail(key)
		refreshMembers()
		refreshWarnBar()
		refreshDemande()
		surface.PlaySound("garrysmod/ui_click.wav")
	end

	local searchBar = vgui.Create("DPanel", content)
	searchBar:Dock(TOP)
	searchBar:SetTall(s(38))
	searchBar:DockMargin(0, 0, 0, s(8))
	searchBar.Paint = function(_, w, h)
		roundRect(s(5), 0, 0, w, h, FIELD)
	end
	local search = vgui.Create("DTextEntry", searchBar)
	search:Dock(FILL)
	search:DockMargin(s(12), s(6), s(110), s(6))
	search:SetFont("EVODash_B")
	search:SetTextColor(TXT) search:SetCursorColor(TXT) search:SetPaintBackground(false)
	search:SetDrawLanguageID(false)
	search:SetUpdateOnType(true)
	search:SetPlaceholderText("Rechercher un clan (nom, faction, leader…)")
	search:SetText(DASH.clanSearch or "")
	search.Paint = function(self, w, h)
		self:DrawTextEntryText(TXT, ACCENT, TXT)
		if self:GetText() == "" and not self:HasFocus() then
			draw.SimpleText(self:GetPlaceholderText(), "EVODash_S", 0, h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	search.OnValueChange = function(_, val)
		DASH.clanSearch = val or ""
		if isfunction(DASH.onClans) then DASH.onClans() end
	end
	local refreshBtn = mkBtn(searchBar, "RAFRAÎCHIR", nil, function() requestClans() end)
	refreshBtn:Dock(RIGHT)
	refreshBtn:DockMargin(0, s(4), s(4), s(4))
	refreshBtn:SetWide(s(100))

	local pendingWrap = vgui.Create("DPanel", content)
	pendingWrap:Dock(TOP)
	pendingWrap:DockMargin(0, 0, 0, s(8))
	pendingWrap:SetTall(0)
	pendingWrap.Paint = function() end

	local function pendingDemandes()
		local t = {}
		for _, c in ipairs(DASH.clans) do
			if clanSpellStatus(c) == "pending" then t[#t + 1] = c end
		end
		table.sort(t, function(a, b)
			local ta, tb = clanSpellAt(a), clanSpellAt(b)
			if ta ~= tb then return ta > tb end
			return (a.label or "") < (b.label or "")
		end)
		return t
	end

	local function rebuildPending()
		pendingWrap:Clear()
		local pending = pendingDemandes()
		if #pending == 0 then
			pendingWrap:SetTall(0)
			pendingWrap:SetVisible(false)
			return
		end
		pendingWrap:SetVisible(true)
		local nShow = math.min(#pending, 5)
		pendingWrap:SetTall(s(26) + nShow * s(36) + s(4))
		local title = vgui.Create("DPanel", pendingWrap)
		title:Dock(TOP)
		title:SetTall(s(24))
		title.Paint = function(_, w, h)
			draw.SimpleText("DEMANDES DE SPELL UNIQUE  (" .. #pending .. ")", "EVODash_Grp", 0, h / 2, WARN_COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		for i = 1, nShow do
			local c = pending[i]
			local row = vgui.Create("DButton", pendingWrap)
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(3))
			row:SetTall(s(32))
			row:SetText("")
			row:SetCursor("hand")
			row.Paint = function(self, w, h)
				roundRect(s(4), 0, 0, w, h, self:IsHovered() and Color(WARN_COL.r, WARN_COL.g, WARN_COL.b, 50) or Color(WARN_COL.r, WARN_COL.g, WARN_COL.b, 28))
				surface.SetDrawColor(WARN_COL) surface.DrawRect(0, s(5), s(3), h - s(10))
				draw.SimpleText(short(c.label, 28), "EVODash_S", s(12), h / 2 - s(1), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(fmtWhen(clanSpellAt(c)), "EVODash_XS", w - s(10), h / 2, WARN_COL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function() selectClan(c.key) end
		end
	end

	local header = vgui.Create("DPanel", content)
	header:Dock(TOP)
	header:SetTall(s(28))
	header:DockMargin(0, 0, 0, s(4))
	header:SetCursor("hand")
	header.Paint = function(_, w, h)
		local x = s(10)
		for _, col in ipairs(CLAN_COLS) do
			local lbl = col.label
			if DASH.clanSortKey == col.key then lbl = lbl .. (DASH.clanSortAsc and " ▲" or " ▼") end
			draw.SimpleText(string.upper(lbl), "EVODash_XS", x, h / 2, DASH.clanSortKey == col.key and ACCENT or TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			x = x + col.w
		end
	end
	header.OnMousePressed = function(self, code)
		if code ~= MOUSE_LEFT then return end
		local mx = self:ScreenToLocal(gui.MouseX(), 0)
		local x = s(10)
		for _, col in ipairs(CLAN_COLS) do
			if mx >= x and mx < x + col.w then
				if DASH.clanSortKey == col.key then DASH.clanSortAsc = not DASH.clanSortAsc
				else DASH.clanSortKey = col.key DASH.clanSortAsc = (col.key == "label") end
				if isfunction(DASH.onClans) then DASH.onClans() end
				return
			end
			x = x + col.w
		end
	end

	local list = vgui.Create("DScrollPanel", content)
	list:Dock(FILL)
	list.Paint = function() end
	styleDashBar(list)

	local rows = {}
	local function makeRow(key)
		local r = list:Add("DButton")
		r:Dock(TOP)
		r:DockMargin(0, 0, s(6), s(3))
		r:SetTall(s(36))
		r:SetText("")
		r:SetCursor("hand")
		r._hf = 0
		r.DoClick = function()
			selectClan(key)
		end
		r.Paint = function(self, w, h)
			local c = DASH.clanByKey[key]
			if not c then return end
			local sel = (DASH.selClan == key)
			self._hf = Lerp(FrameTime() * 12, self._hf or 0, self:IsHovered() and 1 or 0)
			local bg
			if sel then bg = Color(ACCENT.r, ACCENT.g, ACCENT.b, 46)
			else bg = Color(ROWALT.r + 8 * self._hf, ROWALT.g + 8 * self._hf, ROWALT.b + 10 * self._hf, (self._z or 0) % 2 == 0 and 150 or 90) end
			roundRect(s(4), 0, 0, w, h, bg)
			surface.SetDrawColor(facColor(c.faction)) surface.DrawRect(0, s(6), s(3), h - s(12))
			if sel then surface.SetDrawColor(ACCENT) surface.DrawRect(0, 0, s(3), h) end
		local spSt = clanSpellStatus(c)
		if spSt == "pending" then surface.SetDrawColor(WARN_COL) surface.DrawRect(w - s(3), s(6), s(3), h - s(12)) end

			local x = s(10)
			local function cell(txt, col)
				MUGEN.DrawMoneyLine(txt, "EVODash_S", x, h / 2, col or TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			cell(short(c.label, 20)); x = x + CLAN_COLS[1].w
			cell(c.faction ~= "" and c.faction or "—", facColor(c.faction)); x = x + CLAN_COLS[2].w
			cell((c.members or 0) .. "/" .. (c.cap or 0)); x = x + CLAN_COLS[3].w
			cell(tostring(c.level or 1)); x = x + CLAN_COLS[4].w
			cell(fmtMoney(c.pot), WARN_COL); x = x + CLAN_COLS[5].w
			local sLbl, sCol = spellStatusLabel(c)
			cell(sLbl, sCol)
		end
		return r
	end

	local function refreshList()
		local visible = sortedClans()
		local seen = {}
		for _, c in ipairs(visible) do seen[c.key] = true end
		for key, r in pairs(rows) do
			if not seen[key] then if IsValid(r) then r:Remove() end rows[key] = nil end
		end
		for i, c in ipairs(visible) do
			local r = rows[c.key]
			if not r or not IsValid(r) then r = makeRow(c.key) rows[c.key] = r end
			r._z = i
			r:SetZPos(i)
		end
		if DASH.selClan and not DASH.clanByKey[DASH.selClan] then
			DASH.selClan = nil
			membersScroll:Clear()
		end
		rebuildPending()
		refreshWarnBar()
		refreshDemande()
	end

	DASH.onClans = refreshList
	DASH.onClanDetail = function(key)
		if key == DASH.selClan then refreshMembers() end
	end
	refreshList()
	if DASH.selClan then
		if not DASH.clanMembers[DASH.selClan] then requestClanDetail(DASH.selClan) end
		refreshMembers()
		refreshWarnBar()
		refreshDemande()
	end
	if #DASH.clans == 0 then requestClans() end
end

-- ============================================================================
-- FRAME PRINCIPALE
-- ============================================================================
-- selSid / selUid / seedPly : pré-sélection depuis l'inspection E.
-- seedPly = joueur live → fiche remplie immédiatement (sans attendre le snap).
function EVO_OpenStaffDashboard(selSid, selUid, seedPly)
	-- Capturer AVANT Remove : OnRemove d'un ancien frame peut tourner en différé
	-- et écraserait sinon preselectUid/Sid qu'on vient de poser.
	local wantUid = tonumber(selUid)
	local wantSid = nil
	if selSid ~= nil and tostring(selSid) ~= "" then
		local sid = tostring(selSid)
		if string.sub(sid, 1, 1) == "#" then sid = string.sub(sid, 2) end
		if sid:match("^%d+$") and #sid >= 15 and #sid <= 20 then wantSid = sid end
	end
	local wantPly = (IsValid(seedPly) and seedPly:IsPlayer()) and seedPly or nil

	if IsValid(UI) then UI:Remove() end

	DASH.preselectSid = nil
	DASH.preselectUid = nil

	if wantPly then
		local seeded = seedFromPlayer(wantPly)
		if seeded then wantSid = seeded end
		wantUid = wantPly:UserID()
	end

	if wantUid and wantUid > 0 then DASH.preselectUid = wantUid end
	if wantSid then
		DASH.selSid = wantSid
		DASH.preselectSid = wantSid
	end

	-- Toujours l'onglet JOUEURS quand on ouvre une fiche (sinon onglet CLANS
	-- conservé de la session précédente → profil invisible).
	if DASH.preselectUid or DASH.preselectSid then
		DASH.tab = "players"
	end

	-- DFrame plein écran = patron du projet pour toute UI avec saisie (evo_clan,
	-- evoPrompt, calendrier, famille…) : routage clavier NATIF vers DTextEntry.
	-- Un DPanel popup (même avec SetFocusTopLevel) laissait la recherche inécrivable
	-- au clavier — seul Ctrl+V passait.
	local back = vgui.Create("DFrame")
	UI = back
	back:SetSize(ScrW(), ScrH())
	back:SetPos(0, 0)
	back:SetTitle("")
	back:SetDraggable(false)
	back:ShowCloseButton(false)
	back:SetPaintBackgroundEnabled(false)
	back:MakePopup()
	back._t = SysTime()
	back.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur(self, self._t)
		surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h)
	end
	openedFrame = back

	-- Re-appui sur le bind = FERMER (toggle). MakePopup vole le clavier ->
	-- PlayerButtonDown ne fire plus : on poll input.IsButtonDown dans Think
	-- (même schéma que calendrier / animateur / famille). Attendre le RELÂCHEMENT
	-- de la touche d'ouverture, sinon l'appui encore enfoncé referme aussitôt.
	back._bindKey = (LocalPlayer().GetBindKey and LocalPlayer():GetBindKey("staff_dashboard")) or KEY_F8
	back._bindWasDown = true
	back.Think = function(s)
		local k = s._bindKey
		if not k or k == 0 then return end
		local down = input.IsButtonDown(k)
		if down and not s._bindWasDown then
			-- Ne pas fermer pendant une saisie dans un champ texte.
			local kf = vgui.GetKeyboardFocus()
			local typing = IsValid(kf) and kf ~= s and kf.GetText ~= nil
			if not typing then
				s:Remove()
				return
			end
		end
		s._bindWasDown = down
	end

	back.OnRemove = function()
		if openedFrame == back then openedFrame = nil end
		dashClosedAt = SysTime()
		subscribe(false)
		-- Ne PAS clear preselect ici : Remove() peut être différé et écraserait
		-- une pré-sélection posée juste après dans EVO_OpenStaffDashboard.
		DASH.onSnap, DASH.onDetail, DASH.onClans, DASH.onClanDetail, DASH.showToast = nil, nil, nil, nil, nil
		timer.Simple(0, function()
			if LZY_Character_RefreshAllPlayerFaceMaterials then LZY_Character_RefreshAllPlayerFaceMaterials() end
		end)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end

	local W = math.floor(ScrW() * 0.84)
	local H = math.floor(ScrH() * 0.88)
	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H)
	card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(16))
		-- Vis alignées aux 4 coins (DA Atelier).
		if EVO_UI and EVO_UI.Screw then
			local sr, mx, my = s(5), s(20), s(20)
			EVO_UI.Screw(mx, my, sr) EVO_UI.Screw(w - mx, my, sr)
			EVO_UI.Screw(w - mx, h - my, sr) EVO_UI.Screw(mx, h - my, sr)
		end
		-- Titre Bebas + entaille slash accent.
		draw.SimpleText("DASHBOARD STAFF", "EVODash_Title", s(52), s(38), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("EVODash_Title")
		local tw = surface.GetTextSize("DASHBOARD STAFF")
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			EVO_UI.Ink(EVO_UI.TexSlash, s(49), s(38) + s(14), tw * 1.06, s(10), Color(ACCENT.r, ACCENT.g, ACCENT.b, 240))
		else
			surface.SetDrawColor(ACCENT) surface.DrawRect(s(52), s(38) + s(16), tw, math.max(2, s(2)))
		end
		local sub
		if DASH.tab == "clans" then
			sub = #DASH.clans .. " clan(s)"
			local nPend = 0
			for _, c in ipairs(DASH.clans) do
				if clanSpellStatus(c) == "pending" then nPend = nPend + 1 end
			end
			if nPend > 0 then sub = sub .. "  ·  " .. nPend .. " demande(s) spell unique" end
		else
			sub = #DASH.players .. " joueur(s)  ·  " .. (DASH.map or "")
		end
		draw.SimpleText(sub, "EVODash_S", s(54), s(70), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- Filet denté sous l'entête.
		surface.SetDrawColor(255, 255, 255, 14)
		local dx, dw2, dgap = s(52), s(6), s(5)
		while dx < w - s(52) do
			surface.DrawRect(dx, s(92), math.min(dw2, w - s(52) - dx), 1)
			dx = dx + dw2 + dgap
		end
	end

	local close = vgui.Create("DButton", card)
	close:SetText("") close:SetSize(s(40), s(40)) close:SetPos(W - s(54), s(16))
	close:SetCursor("hand")
	close.Paint = function(self, w, h)
		draw.SimpleText("✕", "EVODash_H", w / 2, h / 2, self:IsHovered() and ACCENT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() back:Remove() end

	-- Message de zone (demande user 07/31) : annonce plein écran (rendu des annonces de
	-- faction) pour tous les joueurs dans un rayon autour du staff. Gate serveur.
	local zoneBtn = mkBtn(card, "MESSAGE DE ZONE", "primary", function()
		evoPrompt("Message de zone", {
			{ label = "Message (affiché en plein écran chez les joueurs)", default = "" },
			{ label = "Rayon autour de toi (unités, 100 à 20000)", default = "3000", numeric = true },
			{ label = "Durée d'affichage (secondes, 3 à 30)", default = "8", numeric = true },
		}, function(text, radius, dura)
			text = string.Trim(tostring(text or ""))
			if text == "" then return end
			net.Start("EVO_Dash::ZoneMsg")
				net.WriteString(string.sub(text, 1, 200))
				net.WriteUInt(math.Clamp(math.floor(tonumber(radius) or 3000), 100, 20000), 16)
				net.WriteUInt(math.Clamp(math.floor(tonumber(dura) or 8), 3, 30), 8)
			net.SendToServer()
		end)
	end)
	zoneBtn:SetSize(s(190), s(40)) zoneBtn:SetPos(W - s(54) - s(190) - s(12), s(16))

	-- Recherche BDD (demande user 08/02) : retrouver le SteamID d'un joueur MÊME HORS
	-- LIGNE depuis son nom RP. Requête serveur (EVO_Dash::FindReq), résultats copiables.
	local findBtn = mkBtn(card, "TROUVER UN STEAMID", nil, function()
		evoPrompt("Retrouver un SteamID", {
			{ label = "Nom RP (même partiel, cherche aussi les joueurs hors ligne)", default = "" },
		}, function(q)
			q = string.Trim(tostring(q or ""))
			if #q < 2 then return end
			net.Start("EVO_Dash::FindReq")
				net.WriteString(string.sub(q, 1, 48))
			net.SendToServer()
		end)
	end)
	findBtn:SetSize(s(190), s(40)) findBtn:SetPos(W - s(54) - (s(190) + s(12)) * 2, s(16))

	-- Annonce staff (demande user 17/08) : prévenir TOUTE l'équipe en jeu d'un
	-- coup, helpeurs compris, sans passer par Discord. Le message de zone à côté
	-- vise les JOUEURS autour de soi, et l'action « Message » de la fiche vise UNE
	-- personne : ni l'un ni l'autre ne parlait au staff.
	-- Bouton affiché au seul responsable modérateur (et superadmin) — le serveur
	-- refuse de toute façon les autres, mais montrer un bouton qui répond « non »
	-- au clic est le bug qu'on a déjà eu ailleurs.
	if LocalPlayer():IsSuperAdmin() or (EVO_IsRespoModo ~= nil and EVO_IsRespoModo(LocalPlayer())) then
		local annonceBtn = mkBtn(card, "ANNONCE STAFF", nil, function()
			evoPrompt("Annonce au staff", {
				{ label = "Message (affiché au staff en jeu, en service ou non)", default = "" },
				{ label = "Durée d'affichage (secondes, 5 à 60)", default = "15", numeric = true },
				-- Destinataires en TEXTE : evoPrompt ne connait que des champs de
				-- saisie, et une liste deroulante maison serait un chantier pour
				-- six valeurs. Le serveur refuse une valeur inconnue avec la liste.
				{ label = "Destinataires : tous · moderation · animation · moderateurs · helpeurs · animateurs", default = "tous" },
			}, function(text, dura, cible)
				text = string.Trim(tostring(text or ""))
				if text == "" then return end
				net.Start("EVO_Dash::Annonce")
					net.WriteString(string.sub(text, 1, 300))
					net.WriteUInt(math.Clamp(math.floor(tonumber(dura) or 15), 5, 60), 8)
					net.WriteString(string.sub(string.Trim(tostring(cible or "tous")), 1, 24))
				net.SendToServer()
			end)
		end)
		annonceBtn:SetSize(s(190), s(40)) annonceBtn:SetPos(W - s(54) - (s(190) + s(12)) * 3, s(16))
	end

	local content = vgui.Create("DPanel", card)
	content:SetPos(s(20), s(138))
	content:SetSize(W - s(40), H - s(160))
	content.Paint = function() end

	local function showTab(id)
		DASH.tab = id
		DASH.onSnap, DASH.onDetail, DASH.onClans, DASH.onClanDetail = nil, nil, nil, nil
		if id == "clans" then
			buildClansContent(content)
			requestClans()
		else
			buildContent(content)
		end
	end

	local tabBar = vgui.Create("DPanel", card)
	tabBar:SetPos(s(20), s(96))
	tabBar:SetSize(W - s(40), s(36))
	tabBar.Paint = function() end
	local tabs = {
		{ id = "players", label = "JOUEURS" },
		{ id = "clans",   label = "CLANS" },
	}
	for i, tabDef in ipairs(tabs) do
		local t = tabDef
		local b = vgui.Create("DButton", tabBar)
		b:SetText("")
		b:SetCursor("hand")
		b:SetSize(s(140), s(32))
		b:SetPos((i - 1) * (s(140) + s(8)), s(2))
		b.Paint = function(self, w, h)
			local on = DASH.tab == t.id
			self._hf = Lerp(FrameTime() * 12, self._hf or 0, self:IsHovered() and 1 or 0)
			roundRect(s(4), 0, 0, w, h, on and Color(ACCENT.r, ACCENT.g, ACCENT.b, 46) or Color(FIELD.r, FIELD.g, FIELD.b, 180 + 40 * (self._hf or 0)))
			draw.SimpleText(t.label, "EVODash_S", w / 2, h / 2, on and TXT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if on then surface.SetDrawColor(ACCENT) surface.DrawRect(s(12), h - s(3), w - s(24), s(2)) end
		end
		b.DoClick = function()
			if DASH.tab == t.id then return end
			surface.PlaySound("garrysmod/ui_click.wav")
			showTab(t.id)
		end
	end

	showTab(DASH.tab == "clans" and "clans" or "players")

	-- Toast
	local toastState = { txt = "", err = false, until_ = 0 }
	DASH.showToast = function(msg, err) toastState.txt, toastState.err, toastState.until_ = msg, err, SysTime() + 4 end
	local toastP = vgui.Create("DPanel", card)
	toastP:SetSize(W - s(40), s(28)) toastP:SetPos(s(20), H - s(30))
	toastP.Paint = function(_, w, h)
		if SysTime() > toastState.until_ or toastState.txt == "" then return end
		draw.SimpleText(toastState.txt, "EVODash_B", w / 2, h / 2, toastState.err and ACCENT or OK_COL, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	subscribe(true)
end

concommand.Add("evo_staff_dashboard", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Mode staff actif, ou superadmin (accès direct sans !staff — demande user 2026-08-01).
	if not (lp:GetEvoNWBool("EVO_StaffMode", false) or lp:IsSuperAdmin()) then
		chat.AddText(ACCENT, "[Staff] ", TXT, "Active d'abord le mode staff (!staff) pour ouvrir le dashboard.")
		return
	end
	EVO_OpenStaffDashboard()
end)

-- Ouverture par le BIND "staff_dashboard" : mode staff actif, ou superadmin (toujours).
-- Fallback KEY_F8 si le cache de binds n'est pas encore chargé. OUVERTURE seulement :
-- la FERMETURE par ré-appui est gérée par le Think du frame (input.IsButtonDown),
-- car PlayerButtonDown ne fire plus une fois le MakePopup ouvert (vol de clavier).
-- Si on OBSERVE déjà, la touche ARRÊTE l'observation (toggle intuitif).
hook.Add("PlayerButtonDown", "EVO_Dash::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if IsValid(UI) then return end -- déjà ouvert -> fermeture via le Think
	if vgui.GetKeyboardFocus() then return end
	if SysTime() - (dashClosedAt or 0) < 0.3 then return end -- anti-réouverture juste après fermeture
	local k = (ply.GetBindKey and ply:GetBindKey("staff_dashboard")) or KEY_F8
	if not (k and k ~= 0 and btn == k) then return end
	if not (ply:GetEvoNWBool("EVO_StaffMode", false) or ply:IsSuperAdmin()) then return end
	if IsValid(ply:GetEvoNWEntity("EVO_SpecTarget")) then
		act("unspectate")
	else
		EVO_OpenStaffDashboard()
	end
end)

-- CLIC GAUCHE en mode staff (hors UI) = spectate le joueur VISÉ (2026-07-22, demande user).
hook.Add("PlayerButtonDown", "EVO_Dash::ClickSpectate", function(ply, btn)
	if ply ~= LocalPlayer() or btn ~= MOUSE_LEFT then return end
	if not ply:GetEvoNWBool("EVO_StaffMode", false) then return end
	if vgui.GetKeyboardFocus() or IsValid(UI) then return end
	if IsValid(ply:GetEvoNWEntity("EVO_SpecTarget")) then return end
	local tr = util.TraceLine({
		start  = ply:EyePos(),
		endpos = ply:EyePos() + ply:GetAimVector() * 8000,
		filter = ply,
	})
	local hit = tr.Entity
	if not (IsValid(hit) and hit:IsPlayer() and hit ~= ply) then return end
	if hit:IsSuperAdmin() then return end
	DASH.selSid = hit:SteamID64()
	act("spectate")
end)

-- TAB (scoreboard) EN MODE STAFF ouvre le dashboard et masque le scoreboard par défaut.
hook.Add("ScoreboardShow", "EVO_Dash::TabOpen", function()
	local lp = LocalPlayer()
	if IsValid(lp) and lp:GetEvoNWBool("EVO_StaffMode", false) then
		if not IsValid(UI) then EVO_OpenStaffDashboard() end
		return true
	end
end)
