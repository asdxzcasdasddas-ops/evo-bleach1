-- "addons\\evo_staff\\lua\\autorun\\client\\cl_warns.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO WARNS — UI de gestion (client). Ouvre via !warn (staff).
-- Gauche : liste des joueurs en ligne (+ nb de warns). Clic -> ses warns à
-- droite. Bouton "+ Ajouter un warn" (Titre + Description). Retrait par warn.
-- ============================================================================

if not CLIENT then return end

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function C() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18),
	title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118),
	accent = Color(207,68,78), green = Color(78,196,128), red = Color(199,70,80) } end

local function MakeFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("EVO_Warn_H",     "Roboto", 17, 600)
	gCreateRespFont("EVO_Warn_Body",  "Roboto", 14, 400)
	gCreateRespFont("EVO_Warn_Small", "Roboto", 13, 500)
	gCreateRespFont("EVO_Warn_Btn",   "Roboto", 14, 700)
end
hook.Add("Initialize", "EVO_Warn::FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Warn::Fonts", MakeFonts)
MakeFonts()

local function StyledButton(parent, label, x, y, w, h, filled, font)
	local col = C()
	local b = vgui.Create("DButton", parent) b:SetText("")
	b:SetPos(R(x), R(y)) b:SetSize(R(w), R(h))
	b.Paint = function(s, bw, bh)
		local hov = s:IsHovered()
		if filled then RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(col.accent, hov and 255 or 220))
		else RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 14 or 7)) RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(col.border, hov and 60 or 32), 1) end
		draw.SimpleText(label, font or "EVO_Warn_Btn", bw / 2, bh / 2, filled and color_white or (hov and col.title or col.muted), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return b
end

local function StyledEntry(parent, x, y, w, h, placeholder, multiline)
	local col = C()
	local e = vgui.Create("DTextEntry", parent)
	e:SetPos(R(x), R(y)) e:SetSize(R(w), R(h))
	e:SetFont("EVO_Warn_Body") e:SetDrawLanguageID(false) e:SetMultiline(multiline or false)
	e:SetPlaceholderText(placeholder or "") e:SetTextColor(col.title) e:SetPaintBackground(false)
	e.Paint = function(s, bw, bh)
		RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(Color(8, 8, 10), 230))
		RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(col.border, s:HasFocus() and 70 or 34), 1)
		s:DrawTextEntryText(col.title, col.accent, col.title)
		if not s:HasFocus() and s:GetValue() == "" then draw.SimpleText(placeholder or "", "EVO_Warn_Body", R(10), multiline and R(12) or bh / 2, ColorAlpha(col.dim, 200), TEXT_ALIGN_LEFT, multiline and TEXT_ALIGN_TOP or TEXT_ALIGN_CENTER) end
	end
	return e
end

local pWarns
local state = { sid = nil, name = "", list = {}, warns = {}, clans = {}, clanKey = nil, playersScroll = nil, warnsScroll = nil, warnsHead = nil }

local function fmtDate(ts) ts = tonumber(ts) or 0 return ts > 0 and os.date("%d/%m/%y %H:%M", ts) or "—" end

-- ── WARNS DE CLAN (superadmin, 07/22) : la liste des clans + leurs warns vient
-- d'evo_clan (net "evo_clan:warnlist", SA only ; le warn = compteur SA sa_warn,
-- prérequis « 0 warn » de la demande de spell unique). Garde : si evo_clan n'est
-- pas monté, la net string n'existe pas -> on ne demande rien (section absente).
local function requestClanList()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:IsSuperAdmin() then return end
	if util.NetworkStringToID("evo_clan:warnlist") == 0 then return end
	net.Start("evo_clan:warnlist") net.SendToServer()
end

local renderWarns -- forward : le clic d'un clan dans renderPlayers re-rend le panneau droit

local function renderPlayers()
	local sc = state.playersScroll
	if not IsValid(sc) then return end
	sc:Clear()
	local col = C()
	for _, p in ipairs(state.list) do
		local r = vgui.Create("DButton", sc) r:SetText("") r:Dock(TOP) r:SetTall(R(40)) r:DockMargin(0, 0, R(6), R(6))
		r.Paint = function(s, w, h)
			local on = state.sid == p.sid
			RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(color_white, on and 16 or (s:IsHovered() and 10 or 5)))
			if on then surface.SetDrawColor(col.accent) surface.DrawRect(0, R(8), R(3), h - R(16)) end
			draw.SimpleText(p.name, "EVO_Warn_Small", R(14), h / 2, on and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if (p.count or 0) > 0 then
				local bw = R(26)
				RNDX.Draw(R(9), w - bw - R(10), h / 2 - R(9), bw, R(18), col.accent)
				draw.SimpleText(p.count, "EVO_Warn_Small", w - R(10) - bw / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		r.DoClick = function()
			state.sid, state.name, state.clanKey = p.sid, p.name, nil
			net.Start("EVO:Warns:GetPlayer") net.WriteString(p.sid) net.SendToServer()
			renderPlayers()
			if IsValid(state.warnsHead) then state.warnsHead:SetText(p.name) end
		end
	end

	-- ── Section CLANS (superadmin) : warn de clan = compteur evo_clan. ──
	if LocalPlayer():IsSuperAdmin() and #state.clans > 0 then
		local sep = vgui.Create("DPanel", sc) sep:Dock(TOP) sep:SetTall(R(28)) sep:DockMargin(0, R(10), R(6), R(4)) sep:SetPaintBackground(false)
		sep.Paint = function(s, w, h)
			draw.SimpleText("CLANS (WARNS)", "EVO_Warn_Small", 0, h / 2, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		for _, c in ipairs(state.clans) do
			local r = vgui.Create("DButton", sc) r:SetText("") r:Dock(TOP) r:SetTall(R(40)) r:DockMargin(0, 0, R(6), R(6))
			r.Paint = function(s, w, h)
				local on = state.clanKey == c.key
				RNDX.Draw(R(8), 0, 0, w, h, ColorAlpha(color_white, on and 16 or (s:IsHovered() and 10 or 5)))
				if on then surface.SetDrawColor(col.accent) surface.DrawRect(0, R(8), R(3), h - R(16)) end
				draw.SimpleText(c.label .. "  ·  " .. (c.faction or ""), "EVO_Warn_Small", R(14), h / 2, on and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if (c.warns or 0) > 0 then
					local bw = R(26)
					RNDX.Draw(R(9), w - bw - R(10), h / 2 - R(9), bw, R(18), col.accent)
					draw.SimpleText(c.warns, "EVO_Warn_Small", w - R(10) - bw / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				-- Dissolution À VALIDER par un SA (seuil de warns atteint, user 09/15).
				if c.disbandReq == "pending" then
					local pw = R(96)
					local px = w - R(10) - ((c.warns or 0) > 0 and (R(26) + R(6)) or 0) - pw
					RNDX.Draw(R(9), px, h / 2 - R(9), pw, R(18), ColorAlpha(col.accent, 70))
					draw.SimpleText("DISSOLUTION", "EVO_Warn_Small", px + pw / 2, h / 2, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
			r.DoClick = function()
				state.clanKey, state.sid, state.name = c.key, nil, ""
				renderPlayers() renderWarns()
				if IsValid(state.warnsHead) then state.warnsHead:SetText("Clan " .. c.label) end
			end
		end
	end
end

renderWarns = function()
	local sc = state.warnsScroll
	if not IsValid(sc) then return end
	sc:Clear()
	local col = C()

	-- ── PANNEAU WARN DE CLAN (superadmin) : compteur + boutons +1/-1. L'action
	-- « sa_warn » d'evo_clan est revalidée serveur (SA only) ; le compteur
	-- conditionne le prérequis « 0 warn » de la demande de spell unique. ──
	if state.clanKey then
		local cSel
		for _, c in ipairs(state.clans) do if c.key == state.clanKey then cSel = c break end end
		if cSel then
			local head = vgui.Create("DPanel", sc) head:Dock(TOP) head:SetTall(R(66)) head:DockMargin(0, 0, R(8), R(8)) head:SetPaintBackground(false)
			head.Paint = function(s, w, h)
				RNDX.Draw(R(10), 0, 0, w, h, ColorAlpha(color_white, 6))
				RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(col.border, 26), 1)
				draw.SimpleText("Warns du clan : " .. (cSel.warns or 0) .. ((cSel.warnsMax or 0) > 0 and (" / " .. cSel.warnsMax) or ""), "EVO_Warn_H", R(14), R(12),
					(cSel.warns or 0) > 0 and col.accent or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(cSel.faction or "", "EVO_Warn_Small", R(14), R(38), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			local function clanWarn(nDelta)
				net.Start("evo_clan:action")
				net.WriteString("sa_warn") net.WriteString(state.clanKey) net.WriteInt(nDelta, 32)
				net.SendToServer()
				timer.Simple(0.5, requestClanList) -- rafraîchit compteur + badges
			end
			local btns = vgui.Create("DPanel", sc) btns:Dock(TOP) btns:SetTall(R(42)) btns:DockMargin(0, 0, R(8), R(6)) btns:SetPaintBackground(false)
			StyledButton(btns, "+1 WARN", 0, 4, 130, 32, true).DoClick = function() clanWarn(1) end
			StyledButton(btns, "-1 WARN", 142, 4, 130, 32, false).DoClick = function() clanWarn(-1) end
			local note = vgui.Create("DLabel", sc) note:Dock(TOP) note:SetTall(R(44)) note:SetFont("EVO_Warn_Small") note:SetTextColor(col.dim) note:SetWrap(true)
			note:SetText("Compteur superadmin (evo_clan). 0 warn requis pour la demande de spell unique du clan."
				.. ((cSel.warnsMax or 0) > 0 and (" À " .. cSel.warnsMax .. " warns actifs, la dissolution est soumise à un superadmin.") or ""))
			-- DISSOLUTION À VALIDER (seuil de warns atteint, user 09/15) : la décision SA se
			-- prend ici aussi (« sa_disband_decision », revalidée serveur, SA only).
			if cSel.disbandReq == "pending" then
				local dp = vgui.Create("DPanel", sc) dp:Dock(TOP) dp:SetTall(R(66)) dp:DockMargin(0, R(6), R(8), R(6)) dp:SetPaintBackground(false)
				dp.Paint = function(s, w, h)
					RNDX.Draw(R(10), 0, 0, w, h, ColorAlpha(col.accent, 18))
					RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(col.accent, 90), 1)
					draw.SimpleText("DISSOLUTION À VALIDER", "EVO_Warn_H", R(14), R(10), col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					draw.SimpleText(cSel.disbandReason or "", "EVO_Warn_Small", R(14), R(38), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
				local function decide(n)
					net.Start("evo_clan:action")
					net.WriteString("sa_disband_decision") net.WriteString(state.clanKey) net.WriteInt(n, 32)
					net.SendToServer()
					timer.Simple(0.5, requestClanList)
				end
				local dbtns = vgui.Create("DPanel", sc) dbtns:Dock(TOP) dbtns:SetTall(R(42)) dbtns:DockMargin(0, 0, R(8), R(6)) dbtns:SetPaintBackground(false)
				-- VALIDER = 2 clics en 3 s (irréversible : membres, banque, coffre, domaine).
				StyledButton(dbtns, "DISSOUDRE LE CLAN", 0, 4, 200, 32, true).DoClick = function()
					if dbtns._arm and CurTime() < dbtns._arm then
						dbtns._arm = nil
						decide(1)
					else
						dbtns._arm = CurTime() + 3
						chat.AddText(col.accent, "[Warns] ", color_white, "Re-clique DISSOUDRE LE CLAN dans les 3 s pour confirmer la dissolution de « " .. cSel.label .. " ».")
					end
				end
				StyledButton(dbtns, "GARDER LE CLAN", 212, 4, 180, 32, false).DoClick = function() decide(0) end
			end
		else
			state.clanKey = nil
		end
		return
	end

	if not state.sid then
		local l = vgui.Create("DLabel", sc) l:Dock(TOP) l:SetTall(R(30)) l:SetFont("EVO_Warn_Body") l:SetTextColor(col.dim) l:SetText("Sélectionne un joueur à gauche.") return
	end
	if #state.warns == 0 then
		local l = vgui.Create("DLabel", sc) l:Dock(TOP) l:SetTall(R(30)) l:SetFont("EVO_Warn_Body") l:SetTextColor(col.dim) l:SetText("Aucun warn actif pour ce joueur.") return
	end
	for _, w in ipairs(state.warns) do
		local row = vgui.Create("DPanel", sc) row:Dock(TOP) row:DockMargin(0, 0, R(8), R(8)) row:SetPaintBackground(false)
		surface.SetFont("EVO_Warn_Body")
		local lines = {}
		do -- wrap description
			local maxw = R(440)
			local cur = ""
			for _, word in ipairs(string.Explode(" ", w.reason or "")) do
				local test = cur == "" and word or cur .. " " .. word
				if surface.GetTextSize(test) > maxw and cur ~= "" then lines[#lines + 1] = cur cur = word else cur = test end
			end
			if cur ~= "" then lines[#lines + 1] = cur end
		end
		row:SetTall(R(46) + #lines * R(17))
		row.Paint = function(s, ww, hh)
			RNDX.Draw(R(10), 0, 0, ww, hh, ColorAlpha(color_white, 6))
			RNDX.DrawOutlined(R(10), 0, 0, ww, hh, ColorAlpha(col.border, 26), 1)
			local bExp = w.expired == true -- plus « actif » (7 j) mais retirable et compté par l'escalade 14 j
			draw.SimpleText(w.title ~= "" and w.title or "Avertissement", "EVO_Warn_H", R(14), R(12), bExp and col.muted or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			if bExp then
				draw.SimpleText("Expiré", "EVO_Warn_Small", ww - R(100), R(14), col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			end
			local y = R(34)
			for _, ln in ipairs(lines) do draw.SimpleText(ln, "EVO_Warn_Body", R(14), y, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + R(17) end
			draw.SimpleText("par " .. (w.staff or "?") .. "  ·  " .. fmtDate(w.at), "EVO_Warn_Small", R(14), hh - R(20), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		-- Le bouton n'existe QUE pour ceux qui peuvent VRAIMENT retirer : superadmin, et
		-- responsable moderateur depuis le 09/08. Le serveur refuse de toute facon (cf.
		-- sv_warns.lua), mais afficher un bouton qui ne marche pas a tout le staff ferait
		-- croire a un bug et generait des tickets.
		-- MIROIR EXACT du gate serveur, garde anti auto-blanchiment comprise : un respo
		-- ne retire pas un warn qui le vise, donc le bouton ne s'affiche pas non plus sur
		-- sa propre fiche — sinon il cliquerait dans le vide.
		local lpW = LocalPlayer()
		local bPeutRetirer = lpW:IsSuperAdmin()
			or (EVO_IsRespoModo ~= nil and EVO_IsRespoModo(lpW) and state.sid ~= lpW:SteamID64())
		if bPeutRetirer then
			local del = StyledButton(row, "Retirer", 0, 0, 80, 26, false, "EVO_Warn_Small")
			del.PerformLayout = function(s) s:SetPos(s:GetParent():GetWide() - R(90), R(10)) s:SetSize(R(80), R(26)) end
			del.DoClick = function() net.Start("EVO:Warns:Remove") net.WriteString(w.id) net.SendToServer() end
		end
	end
end

local function openAddForm(card, CARD_W, CARD_H)
	if not state.sid then
		if MUGEN and MUGEN.Notify then MUGEN.Notify("Sélectionne d'abord un joueur.", NOTIFY_ERROR or 1, 4) end
		return
	end
	local col = C()
	local FW, FH = 440, 320
	local ov = vgui.Create("DPanel", card)
	ov:SetSize(R(CARD_W), R(CARD_H)) ov:SetPos(0, 0) ov:SetMouseInputEnabled(true)
	ov.Paint = function(s, w, h) surface.SetDrawColor(0, 0, 0, 170) surface.DrawRect(0, 0, w, h) end
	ov.OnMousePressed = function() ov:Remove() end
	local box = vgui.Create("DPanel", ov)
	box:SetSize(R(FW), R(FH)) box:SetPos(R((CARD_W - FW) / 2), R((CARD_H - FH) / 2))
	box:SetMouseInputEnabled(true) box.OnMousePressed = function() end
	box.Paint = function(s, w, h)
		RNDX.Draw(R(14), 0, 0, w, h, col.bg)
		RNDX.DrawOutlined(R(14), 0, 0, w, h, ColorAlpha(col.accent, 60), 1)
		surface.SetDrawColor(col.accent) surface.DrawRect(R(22), R(22), R(3), R(16))
		draw.SimpleText("AJOUTER UN WARN", "EVO_Warn_H", R(34), R(22), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Joueur : " .. state.name, "EVO_Warn_Small", R(24), R(50), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Titre", "EVO_Warn_Small", R(24), R(76), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Description", "EVO_Warn_Small", R(24), R(132), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	local titleE = StyledEntry(box, 24, 94, FW - 48, 30, "Ex : RDM, Insultes, Cheat…")
	local descE  = StyledEntry(box, 24, 150, FW - 48, 110, "Détaille ce qu'il s'est passé…", true)
	StyledButton(box, "Annuler", 24, FH - 44, 120, 32, false).DoClick = function() ov:Remove() end
	StyledButton(box, "Confirmer le warn", FW - 24 - 200, FH - 44, 200, 32, true).DoClick = function()
		local ti = string.Trim(titleE:GetValue() or "")
		if ti == "" then if MUGEN and MUGEN.Notify then MUGEN.Notify("Ajoute un titre.", NOTIFY_ERROR or 1, 4) end return end
		net.Start("EVO:Warns:Add") net.WriteString(state.sid) net.WriteString(ti) net.WriteString(descE:GetValue() or "") net.SendToServer()
		ov:Remove()
	end
end

function EVO_OpenWarns()
	MakeFonts()
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	if IsValid(pWarns) then pWarns:Remove() end
	local col = C()
	local CARD_W, CARD_H = 880, 540
	local cardW, cardH = R(CARD_W), R(CARD_H)

	pWarns = vgui.Create("DFrame")
	pWarns:SetSize(ScrW(), ScrH()) pWarns:SetPos(0, 0)
	pWarns:SetTitle("") pWarns:ShowCloseButton(false) pWarns:SetDraggable(false)
	pWarns:SetPaintBackgroundEnabled(false) pWarns:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pWarns) end
	pWarns._a = 0
	pWarns.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	pWarns.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 5) end
		surface.SetDrawColor(0, 0, 0, 150 * a) surface.DrawRect(0, 0, w, h)
	end
	pWarns.OnMousePressed = function() if IsValid(pWarns) then pWarns:Remove() end end

	local card = vgui.Create("DPanel", pWarns)
	card:SetSize(cardW, cardH) card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	local SIDEBAR = 320
	card.Paint = function(s, w, h)
		local a = (pWarns and pWarns._a or 255) / 255
		if EVO_UI then EVO_UI.PaintCard(w, h, a, R(16)) else RNDX.Draw(R(16), 0, 0, w, h, col.bg) end
		surface.SetDrawColor(ColorAlpha(col.accent, 255 * a)) surface.DrawRect(R(24), R(24), R(3), R(18))
		draw.SimpleText("AVERTISSEMENTS", "EVO_UI_Header", R(38), R(33), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(ColorAlpha(col.divider, 150 * a))
		surface.DrawRect(R(24), R(64), w - R(48), 1)
		surface.DrawRect(R(SIDEBAR), R(72), 1, h - R(84))
		draw.SimpleText("JOUEURS EN LIGNE", "EVO_Warn_Small", R(24), R(78), ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	-- close
	local x = vgui.Create("DButton", card) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(CARD_W - 42), R(19))
	x.Paint = function(s, w, h) draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.title or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
	x.DoClick = function() pWarns:Remove() end

	-- bouton + Ajouter un warn (haut-droite)
	StyledButton(card, "+ Ajouter un warn", CARD_W - 230, 22, 175, 30, true).DoClick = function() openAddForm(card, CARD_W, CARD_H) end

	-- liste joueurs (gauche)
	state.playersScroll = vgui.Create("DScrollPanel", card)
	state.playersScroll:SetPos(R(20), R(102)) state.playersScroll:SetSize(R(SIDEBAR - 36), R(CARD_H - 102 - 20))

	-- en-tête + warns (droite)
	state.warnsHead = vgui.Create("DLabel", card)
	state.warnsHead:SetFont("EVO_Warn_H") state.warnsHead:SetTextColor(col.title)
	state.warnsHead:SetText(state.name ~= "" and state.name or "Warns")
	state.warnsHead:SetPos(R(SIDEBAR + 20), R(78)) state.warnsHead:SetSize(R(CARD_W - SIDEBAR - 40), R(24))
	state.warnsScroll = vgui.Create("DScrollPanel", card)
	state.warnsScroll:SetPos(R(SIDEBAR + 20), R(110)) state.warnsScroll:SetSize(R(CARD_W - SIDEBAR - 40), R(CARD_H - 110 - 20))

	renderPlayers() renderWarns()
	net.Start("EVO:Warns:GetList") net.SendToServer()
	requestClanList() -- section CLANS (superadmin) — no-op pour les autres
end

net.Receive("EVO:Warns:Open", function() EVO_OpenWarns() end)
net.Receive("EVO:Warns:List", function()
	state.list = net.ReadTable() or {}
	renderPlayers()
end)
net.Receive("EVO:Warns:PlayerWarns", function()
	local sid = net.ReadString()
	local warns = net.ReadTable() or {}
	if sid == state.sid then state.warns = warns renderWarns() end
end)

-- Liste des clans + warns (réponse d'evo_clan, SA only). Rafraîchit la sidebar
-- et, si un clan est sélectionné, le panneau droit (compteur à jour).
net.Receive("evo_clan:warnlist", function()
	state.clans = net.ReadTable() or {}
	if IsValid(pWarns) then
		renderPlayers()
		if state.clanKey then renderWarns() end
	end
end)

concommand.Add("evo_warns", function() EVO_OpenWarns() end)
