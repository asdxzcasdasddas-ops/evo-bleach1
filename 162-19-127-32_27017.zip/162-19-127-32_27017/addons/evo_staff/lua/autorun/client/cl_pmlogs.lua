-- "addons\\evo_staff\\lua\\autorun\\client\\cl_pmlogs.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO PAPILLONS — popup « papillons du joueur » (dashboard staff, 10/25).
-- Ouverte par EVO_OpenPlayerPMLogs(sid, name) depuis la fiche joueur ; réservée
-- à EVO_CanReadPapillons (modo+, respo modo, superadmin), revalidé côté serveur.
-- DA identique à l'historique du chat (cl_chatlogs) : plaque sombre, accent.
-- Un papillon anonyme y affiche son expéditeur RÉEL, marqué ANONYME.
-- ============================================================================
if not CLIENT then return end

local ACCENT   = Color(207, 68, 78)
local CARD     = Color(14, 14, 17)
local FIELD    = Color(30, 31, 37)
local FIELD_H  = Color(42, 43, 51)
local TXT      = Color(236, 236, 240)
local TXT_DIM  = Color(150, 150, 162)
local TXT_MUT  = Color(106, 109, 118)
local OK_COL   = Color(90, 200, 120)
local COL_SENT = Color(207, 68, 78)
local COL_RECV = Color(126, 196, 240)
local COL_ANON = Color(230, 196, 120)

local SC = math.Clamp(ScrH() / 1080, 0.9, 2.2)
local function s(n) return math.floor(n * SC + 0.5) end
local function fsz(n) return math.max(11, math.floor(n * SC + 0.5)) end

surface.CreateFont("EVOPMHist_T", { font = "Bebas Neue", size = fsz(46), weight = 600 })
surface.CreateFont("EVOPMHist_B", { font = "Roboto",     size = fsz(16), weight = 500, extended = true })
surface.CreateFont("EVOPMHist_S", { font = "Roboto",     size = fsz(14), weight = 500, extended = true })

local UI -- popup courant

local function paintPlate(x, y, w, h, col, rad)
	if EVO_UI and EVO_UI.PaintCut then return EVO_UI.PaintCut(x, y, w, h, col, rad or s(12)) end
	surface.SetDrawColor(col) surface.DrawRect(x, y, w, h)
	return nil
end

local function roundRect(rad, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(rad, x, y, w, h, col)
	else draw.RoundedBox(rad, x, y, w, h, col) end
end

local function mkBtn(parent, label, primary, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetCursor("hand")
	b.Paint = function(self, w, h)
		local hf = self:IsHovered() and 1 or 0
		local bg = primary
			and Color(ACCENT.r, ACCENT.g, ACCENT.b, 205 + 50 * hf)
			or Color(FIELD.r + 12 * hf, FIELD.g + 12 * hf, FIELD.b + 14 * hf)
		roundRect(s(5), 0, 0, w, h, bg)
		draw.SimpleText(label, "EVOPMHist_B", w / 2, h / 2 + s(1), TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	if fn then b.DoClick = fn end
	return b
end

-- « 2026-10-25 14:03  Kira Yamato → Rin Tohsaka  [ANONYME] »
local function headOf(r)
	return os.date("%Y-%m-%d %H:%M", tonumber(r.ts) or 0) .. "  "
		.. tostring(r.from or "?") .. " → " .. tostring(r.to or "?")
		.. (r.anon and "  [ANONYME]" or "")
end

local function fmtLine(r)
	return headOf(r) .. " : " .. tostring(r.tx or "")
end

local function matches(r, q)
	if q == "" then return true end
	local hay = string.lower(tostring(r.from) .. " " .. tostring(r.to) .. " " .. tostring(r.tx)
		.. (r.anon and " anonyme" or ""))
	return string.find(hay, q, 1, true) ~= nil
end

local function fillList(sp, rows, query)
	sp:Clear()
	query = string.lower(string.Trim(query or ""))
	local n = 0
	for _, r in ipairs(rows) do
		if matches(r, query) then
			n = n + 1
			local row = sp:Add("DButton")
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(4))
			row:DockPadding(s(12), s(6), s(12), s(8))
			row:SetText("")
			row:SetCursor("hand")
			row:SetTooltip("Cliquer pour copier ce papillon")

			local head = vgui.Create("DLabel", row)
			head:Dock(TOP)
			head:SetTall(s(20))
			head:DockMargin(0, 0, s(170), 0) -- place des badges ENVOYÉ / ANONYME à droite
			head:SetFont("EVOPMHist_S")
			head:SetTextColor(TXT_DIM)
			head:SetText(headOf(r))
			head:SetMouseInputEnabled(false)

			local body = vgui.Create("DLabel", row)
			body:Dock(TOP)
			body:SetFont("EVOPMHist_B")
			body:SetTextColor(TXT)
			body:SetWrap(true)
			body:SetAutoStretchVertical(true)
			body:SetText(tostring(r.tx or ""))
			body:SetMouseInputEnabled(false)

			row.PerformLayout = function(self)
				self:SizeToChildren(false, true)
				self:SetTall(self:GetTall() + s(8))
			end

			local colSide = r.sent and COL_SENT or COL_RECV
			row.Paint = function(self, w, h)
				roundRect(s(4), 0, 0, w, h, self:IsHovered() and FIELD_H or FIELD)
				surface.SetDrawColor(colSide)
				surface.DrawRect(0, 0, s(3), h)
				local xR = w - s(12)
				if (self._copiedUntil or 0) > SysTime() then
					draw.SimpleText("COPIÉ", "EVOPMHist_S", xR, s(16), OK_COL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(r.sent and "ENVOYÉ" or "REÇU", "EVOPMHist_S", xR, s(16), colSide, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				if r.anon then
					surface.SetFont("EVOPMHist_S")
					local tw = surface.GetTextSize(r.sent and "ENVOYÉ" or "REÇU")
					draw.SimpleText("ANONYME", "EVOPMHist_S", xR - tw - s(12), s(16), COL_ANON, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			row.DoClick = function(self)
				SetClipboardText(fmtLine(r))
				self._copiedUntil = SysTime() + 1.4
				surface.PlaySound("garrysmod/ui_click.wav")
			end
		end
	end
	if n == 0 then
		local empty = sp:Add("DLabel")
		empty:Dock(TOP) empty:SetTall(s(48))
		empty:SetFont("EVOPMHist_B") empty:SetTextColor(TXT_DIM)
		empty:SetContentAlignment(5)
		empty:SetText(#rows == 0
			and "Aucun papillon envoyé ou reçu par ce joueur."
			or "Aucun papillon ne correspond au filtre.")
	end
	return n
end

function EVO_OpenPlayerPMLogs(sid, name)
	sid = tostring(sid or "")
	if sid == "" then return end
	if IsValid(UI) then UI:Remove() end

	local back = vgui.Create("DFrame")
	UI = back
	back._sid = sid
	back._name = tostring(name or "")
	back._rows = {}
	back._capped = false
	back._loading = true
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0)
	back:SetTitle("") back:SetDraggable(false) back:ShowCloseButton(false)
	back:MakePopup()
	back.Paint = function(_, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end
	back.OnRemove = function() if UI == back then UI = nil end end

	local W = math.min(ScrW() - s(80), s(920))
	local H = math.min(ScrH() - s(80), s(640))
	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(12))
		if pts and EVO_UI and EVO_UI.OutlineCut then
			EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60))
		end
		local title = "PAPILLONS"
		draw.SimpleText(title, "EVOPMHist_T", s(26), s(34), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVOPMHist_T")
			local tw = surface.GetTextSize(title)
			EVO_UI.Ink(EVO_UI.TexSlash, s(23), s(34) + s(13), tw * 1.05, s(9), Color(ACCENT.r, ACCENT.g, ACCENT.b, 235))
		end
		local who = back._name ~= "" and back._name or sid
		draw.SimpleText(who .. "  ·  tous ses personnages", "EVOPMHist_B", s(26), s(62), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local close = vgui.Create("DButton", card)
	close:SetText("") close:SetSize(s(40), s(40)) close:SetPos(W - s(50), s(12))
	close:SetCursor("hand")
	close.Paint = function(self, w, h)
		draw.SimpleText("✕", "EVOPMHist_T", w / 2, h / 2, self:IsHovered() and ACCENT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() back:Remove() end

	local search = vgui.Create("DTextEntry", card)
	search:SetPos(s(24), s(88)) search:SetSize(W - s(48), s(34))
	search:SetFont("EVOPMHist_B")
	search:SetTextColor(TXT) search:SetCursorColor(TXT) search:SetPaintBackground(false)
	search:SetDrawLanguageID(false) search:SetUpdateOnType(true)
	search.Paint = function(self, w, h)
		roundRect(s(4), 0, 0, w, h, FIELD)
		self:DrawTextEntryText(TXT, ACCENT, TXT)
		if self:GetText() == "" and not self:HasFocus() then
			draw.SimpleText("Filtrer (nom, texte, « anonyme »)…", "EVOPMHist_B", s(10), h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local sp = vgui.Create("DScrollPanel", card)
	sp:SetPos(s(24), s(130))
	sp:SetSize(W - s(48), H - s(200))
	local vbar = sp:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(s(5))
		vbar.Paint = function() end
		vbar.btnUp.Paint = function() end
		vbar.btnDown.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h)
			surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h)
		end
	end
	back._sp = sp

	local hint = vgui.Create("DLabel", card)
	hint:SetFont("EVOPMHist_S") hint:SetTextColor(TXT_MUT)
	hint:SetPos(s(26), H - s(50))
	hint:SetSize(W - s(320), s(36))
	hint:SetWrap(true)
	hint:SetText("Chargement…")

	local function refresh()
		if not IsValid(sp) then return end
		local shown = fillList(sp, back._rows, search:GetValue())
		if not IsValid(hint) then return end
		if back._loading then
			hint:SetText("Chargement…")
		else
			local extra = back._capped and "  ·  lot tronqué (plus ancien ignoré)" or ""
			hint:SetText(shown .. " papillon(s)  ·  300 derniers max  ·  clic = copier" .. extra)
		end
	end
	search.OnValueChange = function() refresh() end
	back._refresh = refresh
	refresh()

	local btnCopy = mkBtn(card, "Copier tout", true, function()
		local q = string.lower(string.Trim(search:GetValue() or ""))
		local lines = {}
		for _, r in ipairs(back._rows) do
			if matches(r, q) then lines[#lines + 1] = fmtLine(r) end
		end
		if #lines == 0 then return end
		SetClipboardText(table.concat(lines, "\n"))
		surface.PlaySound("garrysmod/content_downloaded.wav")
		if IsValid(hint) then hint:SetText(#lines .. " papillon(s) copié(s) dans le presse-papiers.") end
	end)
	btnCopy:SetSize(s(150), s(40)) btnCopy:SetPos(W - s(176) - s(144), H - s(54))

	local btnClose = mkBtn(card, "Fermer", nil, function() back:Remove() end)
	btnClose:SetSize(s(132), s(40)) btnClose:SetPos(W - s(156), H - s(54))

	net.Start("EVO_Dash::PMHistReq")
		net.WriteString(sid)
	net.SendToServer()
end

net.Receive("EVO_Dash::PMHist", function()
	local sid = net.ReadString()
	local capped = net.ReadBool()
	local len = net.ReadUInt(32)
	local rows = {}
	if len and len > 0 then
		local json = util.Decompress(net.ReadData(len))
		if json and json ~= "" then rows = util.JSONToTable(json) or {} end
	end
	if not (IsValid(UI) and UI._sid == sid) then return end
	UI._loading = false
	UI._capped = capped == true
	UI._rows = istable(rows) and rows or {}
	if isfunction(UI._refresh) then UI._refresh() end
	-- Fil en bas : plus récent visible. Les lignes wrappées se stabilisent sur 1-2 frames.
	local function stick()
		if not IsValid(UI) or not IsValid(UI._sp) then return end
		UI._sp:InvalidateLayout(true)
		local vbar = UI._sp:GetVBar()
		if IsValid(vbar) then vbar:SetScroll(vbar.CanvasSize or 0) end
	end
	timer.Simple(0, stick)
	timer.Simple(0.1, stick)
end)
