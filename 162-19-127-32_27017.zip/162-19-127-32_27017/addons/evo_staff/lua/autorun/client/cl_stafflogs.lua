-- "addons\\evo_staff\\lua\\autorun\\client\\cl_stafflogs.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO STAFF LOGS — UI de RECHERCHE / EXPORT en jeu (super admin).
-- Ouverte par la concommand serveur `evo_logs` ou les commandes SAM `logs*`
-- (net EVO_StaffLogs::Open, qui peut transporter des FILTRES INITIAUX en JSON).
-- Filtres : joueur + portée (staff/cible/les deux) / action (ou groupe) / période /
-- texte libre. Résultats du SQLite LOCAL du serveur (cf. sv_stafflogs.lua). Export
-- CSV dans garrysmod/data/evo_stafflogs/ + copie presse-papiers.
-- DA EVO : carte sombre #0E0E11, accent rouge #cf444e, fond flouté + assombri.
-- ============================================================================
if not CLIENT then return end

local ACCENT  = Color(207, 68, 78)
local CARD    = Color(14, 14, 17)
local CARD2   = Color(24, 24, 29)
local FIELD   = Color(32, 32, 38)
local TXT     = Color(236, 236, 240)
local TXT_DIM = Color(150, 150, 162)

surface.CreateFont("EVOLogs_H", { font = "Roboto", size = 23, weight = 700 })
surface.CreateFont("EVOLogs_T", { font = "Bebas Neue", size = 27, weight = 700 })
surface.CreateFont("EVOLogs_B", { font = "Roboto", size = 16, weight = 500 })
surface.CreateFont("EVOLogs_S", { font = "Roboto", size = 14, weight = 500 })

-- Filtre déroulant d'actions. label -> valeur ("" = toutes ; "@xxx" = groupe géré serveur).
local ACTIONS = {
	{ "Toutes les actions", "" },
	{ "— Sanctions (toutes) —", "@sanctions" },
	{ "— Mutes / Gags —", "@mutes" },
	{ "— Warns —", "@warns" },
	{ "— Staff mode —", "@staff" },
	{ "— Animateur —", "@anim" },
	{ "— Reports —", "@reports" },
	{ "Ban", "ban" }, { "Kick", "kick" }, { "Mute", "mute" }, { "Gag", "gag" },
	{ "Unmute", "sam.unmute" }, { "Ungag", "sam.ungag" }, { "Unban", "sam.unban" },
	{ "Freeze", "sam.freeze" }, { "Unfreeze", "sam.unfreeze" }, { "Slay", "sam.slay" },
	{ "Jail", "sam.jail" }, { "Unjail", "sam.unjail" }, { "Bring", "sam.bring" },
	{ "Goto", "sam.goto" }, { "Return", "sam.return" }, { "Setrank", "sam.setrank" },
	{ "Slap", "sam.slap" }, { "Strip", "sam.strip" },
	{ "Staff mode ON", "staff_on" }, { "Staff mode OFF", "staff_off" },
	{ "Warn", "warn" }, { "Unwarn", "unwarn" }, { "Warn -> ban", "warn.ban" },
	{ "Report réclamé", "report.claim" }, { "Report fermé", "report.close" },
	{ "Question traitée", "question.close" },
	{ "Ticket refusé", "support.reject" },
	{ "Ticket transmis modos", "support.escalate" },
	{ "Récompense grade", "grade_reward" },
	{ "Animateur ON", "anim_on" }, { "Animateur OFF", "anim_off" },
	{ "Possession", "anim.possess" }, { "Spawn boss", "anim.boss" },
	{ "Suppr. boss", "anim.boss.del" }, { "Suppr. tous boss", "anim.boss.delall" },
	{ "Coffre animateur", "anim.chest" },
}

local SCOPES = {
	{ "Staff ou cible", "both" },
	{ "Staff (acteur)", "staff" },
	{ "Cible (victime)", "target" },
}

local PERIODS = {
	{ "Tout", 0 }, { "Dernière heure", 3600 }, { "6 heures", 21600 },
	{ "24 heures", 86400 }, { "7 jours", 604800 }, { "Personnalisé", -1 },
}

-- Parse "AAAA-MM-JJ HH:MM" (ou "AAAA-MM-JJ") -> timestamp unix, ou nil.
local function parseDateTime(s)
	s = string.Trim(s or "")
	if s == "" then return nil end
	local y, mo, d, h, mi = string.match(s, "^(%d%d%d%d)%-(%d%d?)%-(%d%d?)%s+(%d%d?):(%d%d?)")
	if not y then y, mo, d = string.match(s, "^(%d%d%d%d)%-(%d%d?)%-(%d%d?)") end
	if not y then return nil end
	return os.time({ year = tonumber(y), month = tonumber(mo), day = tonumber(d),
		hour = tonumber(h) or 0, min = tonumber(mi) or 0, sec = 0 })
end

local function fmtTs(ts) return os.date("%Y-%m-%d %H:%M:%S", tonumber(ts) or 0) end
local function who(name, sid) return (name and name ~= "") and name or (sid ~= "" and sid or "-") end

local UI          -- backdrop
local lastRows = {}  -- derniers résultats (pour export / copie)
local LOG_NAMES = {} -- noms connus (autocomplétion du champ Joueur), reçus à l'ouverture
local LOG_ACTIONS = {} -- actions distinctes présentes dans les logs (peuplent le filtre "Action")

-- Label lisible pour une action dynamique : "sam.evo_heal" -> "evo_heal", sinon tel quel.
local function prettyAction(a)
	a = tostring(a or "")
	if string.sub(a, 1, 4) == "sam." then return string.sub(a, 5) end
	return a
end

-- Fusionne le filtre curé (groupes @ + sanctions nommées) avec TOUTES les actions réellement
-- présentes dans les logs -> le superadmin retrouve n'importe quelle action loggée sans rien coder
-- en dur. Les actions déjà curées ne sont pas dupliquées ; les nouvelles sont triées à la fin.
local function buildActionList()
	local list, seen = {}, {}
	for _, a in ipairs(ACTIONS) do
		list[#list + 1] = a
		seen[a[2]] = true
	end
	local extra = {}
	for _, a in ipairs(LOG_ACTIONS) do
		if not seen[a] then
			extra[#extra + 1] = { prettyAction(a), a }
			seen[a] = true
		end
	end
	if #extra > 0 then
		table.sort(extra, function(x, y) return x[1] < y[1] end)
		list[#list + 1] = { "———  Autres actions loggées  ———", "" } -- séparateur (sélection = aucun filtre)
		for _, e in ipairs(extra) do list[#list + 1] = e end
	end
	return list
end

-- ── Export CSV dans garrysmod/data/evo_stafflogs/ ───────────────────────────
local function csvEsc(s)
	s = tostring(s or "")
	if string.find(s, '[,"\n\r]') then s = '"' .. string.gsub(s, '"', '""') .. '"' end
	return s
end

local function exportCSV()
	if #lastRows == 0 then
		chat.AddText(ACCENT, "[Logs] ", TXT, "Rien à exporter (lance d'abord une recherche).")
		return
	end
	local lines = { "date,staff,staff_steamid,action,cible,cible_steamid,details" }
	for _, r in ipairs(lastRows) do
		lines[#lines + 1] = table.concat({
			csvEsc(fmtTs(r.ts)), csvEsc(r.staff_name), csvEsc(r.staff_sid), csvEsc(r.action),
			csvEsc(r.target_name), csvEsc(r.target_sid), csvEsc(r.details),
		}, ",")
	end
	file.CreateDir("evo_stafflogs")
	local fn = "evo_stafflogs/logs_" .. os.date("%Y%m%d_%H%M%S") .. ".csv"
	file.Write(fn, table.concat(lines, "\n"))
	chat.AddText(ACCENT, "[Logs] ", TXT, "Exporté : garrysmod/data/" .. fn .. " (" .. #lastRows .. " lignes).")
end

local function copyAll()
	if #lastRows == 0 then return end
	local lines = {}
	for _, r in ipairs(lastRows) do
		lines[#lines + 1] = fmtTs(r.ts) .. "  |  " .. who(r.staff_name, r.staff_sid)
			.. "  |  " .. r.action .. "  |  " .. who(r.target_name, r.target_sid)
			.. "  |  " .. r.details
	end
	SetClipboardText(table.concat(lines, "\n"))
	chat.AddText(ACCENT, "[Logs] ", TXT, #lastRows .. " ligne(s) copiée(s) dans le presse-papiers.")
end

-- ── Réception des résultats ─────────────────────────────────────────────────
-- Les résultats sont routés vers le "sink" de la vue qui a lancé la requête (popup
-- evo_logs OU onglet SAM). lastRows est toujours mis à jour -> l'export/copie porte sur
-- la vue courante. Dernier appel = propriétaire du sink (un seul admin pilote à la fois).
local activeSink

net.Receive("EVO_StaffLogs::Results", function()
	local count  = net.ReadUInt(16)
	local capped = net.ReadBool()
	local len    = net.ReadUInt(32)
	local rows, failed = {}, false
	if len > 0 then
		local raw = net.ReadData(len)
		local json = util.Decompress(raw)
		if json and json ~= "" then
			rows = util.JSONToTable(json) or {}
		else
			failed = true -- payload corrompu / trop gros
		end
	end
	lastRows = rows

	if failed or (count > 0 and #rows == 0) then
		chat.AddText(ACCENT, "[Logs] ", TXT, "Échec de réception du lot : affine les filtres (période / joueur).")
	end

	if isfunction(activeSink) then activeSink(rows, capped) end
end)

-- Sink du POPUP (evo_logs / !logs) : remplit la DListView + le compteur.
local function updatePopupList(rows, capped)
	if not (IsValid(UI) and IsValid(UI.list)) then return end
	UI.list:Clear()
	for _, r in ipairs(rows) do
		UI.list:AddLine(fmtTs(r.ts), who(r.staff_name, r.staff_sid), r.action,
			who(r.target_name, r.target_sid), r.details)
	end
	if IsValid(UI.count) then
		UI.count:SetText(#rows .. " résultat(s)" .. (capped and "  (limité : affine les filtres)" or ""))
	end
end

-- ── Envoi de la requête ─────────────────────────────────────────────────────
-- Émetteur générique : `filters` = {player,scope,action,text,from,to}, `sink(rows,capped)`
-- reçoit le résultat. Partagé par le popup et l'onglet SAM (cf. EVO_StaffLogsUI).
local function sendQuery(filters, sink)
	activeSink = sink
	net.Start("EVO_StaffLogs::Query")
		net.WriteString(string.sub(filters.player or "", 1, 64))
		net.WriteString(filters.scope or "both")
		net.WriteString(filters.action or "")
		net.WriteString(string.sub(filters.text or "", 1, 64))
		net.WriteString(filters.from and tostring(math.floor(filters.from)) or "")
		net.WriteString(filters.to and tostring(math.floor(filters.to)) or "")
	net.SendToServer()
end

local function doQuery()
	if not IsValid(UI) then return end
	if IsValid(UI._suggest) then UI._suggest:SetVisible(false) end -- referme l'autocomplétion
	local from, to
	local per = UI.periodVal or 0
	if per == -1 then -- Personnalisé
		from, to = parseDateTime(UI.from:GetValue()), parseDateTime(UI.to:GetValue())
	elseif per > 0 then
		from = os.time() - per
	end
	sendQuery({
		player = UI.player:GetValue() or "",
		scope  = UI.scopeVal or "both",
		action = UI.actionVal or "",
		text   = UI.text:GetValue() or "",
		from   = from, to = to,
	}, updatePopupList)
end

-- ── Helpers UI ──────────────────────────────────────────────────────────────
local function styleEntry(e, placeholder)
	e:SetTextColor(TXT)
	e:SetCursorColor(TXT)
	e:SetFont("EVOLogs_S")
	e.Paint = function(s, w, h)
		-- champ flat carré + liseré 1px (DA : plus d'arrondi)
		surface.SetDrawColor(FIELD) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 16) surface.DrawOutlinedRect(0, 0, w, h)
		s:DrawTextEntryText(TXT, ACCENT, TXT)
		if s:GetText() == "" and placeholder then
			draw.SimpleText(placeholder, "EVOLogs_S", 8, h / 2 + 1, TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	return e
end

local function mkCombo(parent)
	local c = vgui.Create("DComboBox", parent)
	c:SetTextColor(TXT) c:SetFont("EVOLogs_S")
	c.Paint = function(s, w, h)
		surface.SetDrawColor(FIELD) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 16) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("▾", "EVOLogs_S", w - 14, h / 2, TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return c
end

local function comboSetByData(combo, list, data)
	for _, e in ipairs(list) do
		if e[2] == data then combo:SetValue(e[1]) return end
	end
	if list[1] then combo:SetValue(list[1][1]) end
end

local function mkButton(parent, label, fill)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(s, w, h)
		local c = fill and ACCENT or CARD2
		if s:IsHovered() then c = fill and Color(225, 86, 96) or Color(40, 40, 47) end
		if fill and EVO_UI and EVO_UI.PaintCut then
			-- bouton d'action DA : coin bas-droit coupé
			EVO_UI.PaintCut(0, 0, w, h, c, 8, "br")
		else
			surface.SetDrawColor(c) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, s:IsHovered() and 30 or 16)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		draw.SimpleText(label, "EVOLogs_B", w / 2, h / 2, TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return b
end

-- Champ Joueur AVEC autocomplétion : un panneau de suggestions (enfant de la carte, donc il NE
-- VOLE PAS le focus clavier du champ) filtre LOG_NAMES en direct pendant la frappe. Clic = remplit
-- + relance la recherche. Se ferme via card.OnMousePressed (clic ailleurs) ou après un choix.
local function attachNameSearch(card, entry, onPick)
	entry:SetUpdateOnType(true)
	local sp = vgui.Create("DScrollPanel", card)
	sp:SetZPos(900)
	sp:SetVisible(false)
	sp.Paint = function(_, w, h)
		surface.SetDrawColor(18, 18, 22) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 16) surface.DrawOutlinedRect(0, 0, w, h)
	end
	sp.OnMousePressed = function() sp:SetVisible(false) end -- clic sur le panneau (hors bouton) = referme
	UI._suggest = sp

	local function rebuild()
		sp:GetCanvas():Clear()
		local q = string.lower(string.Trim(entry:GetValue() or ""))
		local n = 0
		for _, name in ipairs(LOG_NAMES) do
			if q == "" or string.find(string.lower(name), q, 1, true) then
				local nm = name
				local b = sp:Add("DButton")
				b:Dock(TOP) b:DockMargin(3, 3, 3, 0) b:SetTall(23) b:SetText("")
				b.Paint = function(s, bw, bh)
					surface.SetDrawColor(s:IsHovered() and FIELD or Color(28, 28, 34))
					surface.DrawRect(0, 0, bw, bh)
					draw.SimpleText(nm, "EVOLogs_S", 7, bh / 2, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				b.DoClick = function()
					entry:SetText(nm)
					sp:SetVisible(false)
					if onPick then onPick() end
				end
				n = n + 1
				if n >= 60 then break end
			end
		end
		if n == 0 then sp:SetVisible(false) return end
		local x, y = entry:GetPos()
		sp:SetSize(entry:GetWide(), math.min(n, 7) * 26 + 6)
		sp:SetPos(x, y + entry:GetTall() + 2)
		sp:SetVisible(true)
		sp:MoveToFront()
	end

	entry.OnValueChange = rebuild
	-- N'ouvre PAS toute la liste au simple focus du champ vide (sinon elle recouvre les résultats) :
	-- au focus, on ne (ré)ouvre les suggestions que s'il y a déjà du texte. Sinon = à la frappe.
	entry.OnGetFocus = function()
		if string.Trim(entry:GetValue() or "") ~= "" then rebuild() end
	end
end

-- ── Construction de l'UI (init = filtres initiaux optionnels) ───────────────
function EVO_OpenStaffLogs(init)
	if IsValid(UI) then UI:Remove() end

	local back = vgui.Create("DPanel")
	UI = back
	back:SetSize(ScrW(), ScrH())
	back:SetPos(0, 0)
	back:MakePopup()
	back._t = SysTime()
	back.Paint = function(s, w, h)
		Derma_DrawBackgroundBlur(s, s._t)
		surface.SetDrawColor(0, 0, 0, 170)
		surface.DrawRect(0, 0, w, h)
	end
	back.OnMousePressed = function() back:Remove() end -- clic en dehors = fermer
	openedFrame = back
	back.OnRemove = function() if openedFrame == back then openedFrame = nil end end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end

	local W = math.min(ScrW() - 100, 1200)
	local H = math.min(ScrH() - 110, 770)

	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H)
	card:Center()
	card:SetMouseInputEnabled(true)
	card.Paint = function(s, w, h)
		-- DA « Seireitei » : carte du kit (coins coupés + liseré + seigaiha),
		-- titre Bebas + entaille (plus de bandeau arrondi ni de barre accent).
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, 14)
		else
			draw.RoundedBox(0, 0, 0, w, h, CARD)
		end
		local titre = "LOGS STAFF — RECHERCHE & EXPORT"
		draw.SimpleText(titre, "EVOLogs_T", 18, 24, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink then
			surface.SetFont("EVOLogs_T")
			local tw, th = surface.GetTextSize(titre)
			EVO_UI.Ink(EVO_UI.TexSlash, 16, 24 + th * 0.28, tw * 1.15, 8, ColorAlpha(ACCENT, 245))
		end
	end
	card.OnMousePressed = function() if IsValid(UI._suggest) then UI._suggest:SetVisible(false) end end

	local close = vgui.Create("DButton", card)
	close:SetText("")
	close:SetSize(34, 34) close:SetPos(W - 42, 7)
	close.Paint = function(s, w, h)
		draw.SimpleText("✕", "EVOLogs_H", w / 2, h / 2, s:IsHovered() and ACCENT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() back:Remove() end

	local pad, fy = 18, 64
	local function lbl(text, x, y)
		local l = vgui.Create("DLabel", card)
		l:SetText(text) l:SetFont("EVOLogs_S") l:SetTextColor(TXT_DIM)
		l:SetPos(x, y) l:SizeToContents()
		return l
	end

	-- Joueur (autocomplétion : liste déroulante des noms connus + filtrage en frappant)
	lbl("Joueur (nom/SteamID — tape pour filtrer)", pad, fy)
	UI.player = styleEntry(vgui.Create("DTextEntry", card), "ex: Yugiro / 7656119…")
	UI.player:SetPos(pad, fy + 18) UI.player:SetSize(210, 30)
	UI.player.OnEnter = doQuery
	attachNameSearch(card, UI.player, doQuery)

	-- Portée (scope)
	lbl("Portée", pad + 222, fy)
	UI.scopeVal = "both"
	local cbS = mkCombo(card)
	cbS:SetPos(pad + 222, fy + 18) cbS:SetSize(170, 30)
	for _, e in ipairs(SCOPES) do cbS:AddChoice(e[1], e[2], e[2] == "both") end
	cbS.OnSelect = function(_, _, _, data) UI.scopeVal = data or "both" end

	-- Action (filtre curé + actions dynamiques réellement loggées)
	lbl("Action", pad + 404, fy)
	UI.actionVal = ""
	local actionList = buildActionList()
	local cbA = mkCombo(card)
	cbA:SetPos(pad + 404, fy + 18) cbA:SetSize(210, 30)
	for i, a in ipairs(actionList) do cbA:AddChoice(a[1], a[2], i == 1) end
	cbA.OnSelect = function(_, _, _, data) UI.actionVal = data or "" end

	-- Période
	lbl("Période", pad + 626, fy)
	UI.periodVal = 0
	local cbP = mkCombo(card)
	cbP:SetPos(pad + 626, fy + 18) cbP:SetSize(160, 30)
	for _, p in ipairs(PERIODS) do cbP:AddChoice(p[1], p[2], p[2] == 0) end

	-- Du / Au (révélés en "Personnalisé")
	local lblDu = lbl("Du", pad + 798, fy)
	UI.from = styleEntry(vgui.Create("DTextEntry", card), "AAAA-MM-JJ HH:MM")
	UI.from:SetPos(pad + 798, fy + 18) UI.from:SetSize(160, 30)
	local lblAu = lbl("Au", pad + 798, fy + 52)
	UI.to = styleEntry(vgui.Create("DTextEntry", card), "AAAA-MM-JJ HH:MM")
	UI.to:SetPos(pad + 798, fy + 70) UI.to:SetSize(160, 30)
	local function setCustom(on)
		lblDu:SetVisible(on) UI.from:SetVisible(on)
		lblAu:SetVisible(on) UI.to:SetVisible(on)
	end
	setCustom(false)
	cbP.OnSelect = function(_, _, _, data)
		UI.periodVal = data or 0
		setCustom(data == -1)
	end

	-- Ligne 2 : texte libre + Rechercher
	lbl("Recherche dans les détails", pad, fy + 52)
	UI.text = styleEntry(vgui.Create("DTextEntry", card), "ex: raison, motif…")
	UI.text:SetPos(pad, fy + 70) UI.text:SetSize(440, 30)
	UI.text.OnEnter = doQuery

	local btnSearch = mkButton(card, "Rechercher", true)
	btnSearch:SetPos(pad + 466, fy + 70) btnSearch:SetSize(160, 30)
	btnSearch.DoClick = doQuery

	-- Liste des résultats
	local listY = fy + 116
	local list = vgui.Create("DListView", card)
	UI.list = list
	list:SetPos(pad, listY)
	list:SetSize(W - pad * 2, H - listY - 56)
	list:SetMultiSelect(true)
	list.Paint = function(s, w, h)
		surface.SetDrawColor(CARD2) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 14) surface.DrawOutlinedRect(0, 0, w, h)
	end
	list:AddColumn("Date"):SetFixedWidth(150)
	list:AddColumn("Staff"):SetFixedWidth(180)
	list:AddColumn("Action"):SetFixedWidth(140)
	list:AddColumn("Cible"):SetFixedWidth(180)
	list:AddColumn("Détails")

	-- Pied : compteur + boutons
	UI.count = vgui.Create("DLabel", card)
	UI.count:SetFont("EVOLogs_S") UI.count:SetTextColor(TXT_DIM)
	UI.count:SetPos(pad, H - 40) UI.count:SetText("Recherche…") UI.count:SetSize(420, 24)

	local btnClose = mkButton(card, "Fermer", false)
	btnClose:SetPos(W - pad - 120, H - 44) btnClose:SetSize(120, 30)
	btnClose.DoClick = function() back:Remove() end

	local btnCopy = mkButton(card, "Copier", false)
	btnCopy:SetPos(W - pad - 250, H - 44) btnCopy:SetSize(120, 30)
	btnCopy.DoClick = copyAll

	local btnExport = mkButton(card, "Exporter CSV", true)
	btnExport:SetPos(W - pad - 400, H - 44) btnExport:SetSize(140, 30)
	btnExport.DoClick = exportCSV

	-- Application des filtres INITIAUX (commandes SAM raccourcies)
	if istable(init) then
		UI.player:SetText(tostring(init.player or ""))
		UI.text:SetText(tostring(init.text or ""))
		UI.scopeVal = init.scope or "both"
		comboSetByData(cbS, SCOPES, UI.scopeVal)
		UI.actionVal = init.action or ""
		comboSetByData(cbA, actionList, UI.actionVal)
		local per = tonumber(init.period) or 0
		UI.periodVal = per
		comboSetByData(cbP, PERIODS, per)
		setCustom(per == -1)
		if init.from then UI.from:SetText(tostring(init.from)) end
		if init.to then UI.to:SetText(tostring(init.to)) end
	end

	doQuery() -- recherche initiale
end

net.Receive("EVO_StaffLogs::Open", function()
	local js = net.ReadString()
	local nlen = net.ReadUInt(32)
	if nlen > 0 and nlen <= 2000000 then -- garde-fou taille (le lot de noms est borné côté serveur)
		local raw = net.ReadData(nlen)
		local j = util.Decompress(raw)
		if j and j ~= "" then LOG_NAMES = util.JSONToTable(j) or {} end
	end
	local alen = net.ReadUInt(32)
	if alen > 0 and alen <= 2000000 then -- lot d'actions distinctes (borné côté serveur)
		local raw = net.ReadData(alen)
		local j = util.Decompress(raw)
		if j and j ~= "" then LOG_ACTIONS = util.JSONToTable(j) or {} end
	end
	local init = (js ~= "") and util.JSONToTable(js) or nil
	EVO_OpenStaffLogs(init)
end)

-- ════════════════════════════════════════════════════════════════════════════
-- API CLIENTE PARTAGÉE — consommée par l'ONGLET SAM (cl_stafflogs_samtab.lua).
-- On expose l'émetteur de requête, l'export/copie (portent sur lastRows = vue courante)
-- et une demande de métadonnées (noms + actions distincts) SANS ouvrir le popup, pour
-- que l'onglet peuple son filtre Action. Un seul net.Receive::Results existe (ci-dessus) :
-- l'onglet passe SON sink à SendQuery, il n'enregistre PAS un second receive.
-- ════════════════════════════════════════════════════════════════════════════
EVO_StaffLogsUI = EVO_StaffLogsUI or {}
EVO_StaffLogsUI.SendQuery  = sendQuery
EVO_StaffLogsUI.ExportCSV  = exportCSV
EVO_StaffLogsUI.Copy       = copyAll
EVO_StaffLogsUI.FmtTs      = fmtTs
EVO_StaffLogsUI.Who        = who
EVO_StaffLogsUI.PrettyAction = prettyAction
EVO_StaffLogsUI.OpenPopup  = function(init) EVO_OpenStaffLogs(init) end
function EVO_StaffLogsUI.GetActions() return LOG_ACTIONS end
function EVO_StaffLogsUI.GetNames() return LOG_NAMES end

local metaCb
function EVO_StaffLogsUI.RequestMeta(cb)
	metaCb = cb
	net.Start("EVO_StaffLogs::Meta")
	net.SendToServer()
end

net.Receive("EVO_StaffLogs::Meta", function()
	local nlen = net.ReadUInt(32)
	if nlen > 0 and nlen <= 2000000 then
		local j = util.Decompress(net.ReadData(nlen))
		if j and j ~= "" then LOG_NAMES = util.JSONToTable(j) or {} end
	end
	local alen = net.ReadUInt(32)
	if alen > 0 and alen <= 2000000 then
		local j = util.Decompress(net.ReadData(alen))
		if j and j ~= "" then LOG_ACTIONS = util.JSONToTable(j) or {} end
	end
	if isfunction(metaCb) then local cb = metaCb metaCb = nil cb() end
end)
