-- "addons\\evo_staff\\lua\\autorun\\client\\cl_chatlogs.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CHAT LOGS — popup « historique du chat » (dashboard staff).
-- Ouverte par EVO_OpenPlayerChatLogs(sid, name) depuis la fiche joueur.
-- DA identique au dashboard : plaque sombre, accent, fond assombri.
-- ============================================================================
if not CLIENT then return end

local ACCENT   = Color(207, 68, 78)
local CARD     = Color(14, 14, 17)
local FIELD    = Color(30, 31, 37)
local FIELD_H  = Color(42, 43, 51)
local TXT      = Color(236, 236, 240)
local TXT_DIM  = Color(150, 150, 162)
local TXT_MUT  = Color(106, 109, 118)
local OK_COL   = Color(90, 200, 120)

local SC = math.Clamp(ScrH() / 1080, 0.9, 2.2)
local function s(n) return math.floor(n * SC + 0.5) end
local function fsz(n) return math.max(11, math.floor(n * SC + 0.5)) end

surface.CreateFont("EVOChatHist_T", { font = "Bebas Neue", size = fsz(46), weight = 600 })
surface.CreateFont("EVOChatHist_B", { font = "Roboto",     size = fsz(16), weight = 500 })
surface.CreateFont("EVOChatHist_S", { font = "Roboto",     size = fsz(14), weight = 500 })

local CHAN_COL = {
	hrp    = Color(190, 196, 208),
	looc   = Color(190, 196, 208),
	fac    = Color(90, 200, 170),
	nar    = Color(77, 154, 255),
	it     = Color(126, 196, 240),
	clan   = Color(186, 130, 255),
	div    = Color(80, 200, 170),
	me     = Color(255, 220, 80),
	roll   = Color(51, 255, 0),
	staff  = Color(207, 68, 78),
	ooc    = Color(180, 180, 190),
	advert = Color(230, 196, 120),
}

local CHAN_TAG = {
	hrp = "HRP", looc = "HRP", fac = "FAC", nar = "NAR", it = "IT",
	clan = "CLAN", div = "DIV", me = "ME", roll = "ROLL",
	staff = "STAFF", ooc = "OOC", advert = "ADS",
}

local UI -- popup courant

local function paintPlate(x, y, w, h, col, rad)
	if EVO_UI and EVO_UI.PaintCut then return EVO_UI.PaintCut(x, y, w, h, col, rad or s(12)) end
	surface.SetDrawColor(col) surface.DrawRect(x, y, w, h)
	return nil
end

local function roundRect(rad, x, y, w, h, col)
	if RNDX and RNDX.Draw then RNDX.Draw(rad, x, y, w, h, col)
	else draw.RoundedBox(rad, x, y, w, h, col) end
end

local function mkBtn(parent, label, primary, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetCursor("hand")
	b.Paint = function(self, w, h)
		local hf = self:IsHovered() and 1 or 0
		local bg = primary
			and Color(ACCENT.r, ACCENT.g, ACCENT.b, 205 + 50 * hf)
			or Color(FIELD.r + 12 * hf, FIELD.g + 12 * hf, FIELD.b + 14 * hf)
		roundRect(s(5), 0, 0, w, h, bg)
		draw.SimpleText(label, "EVOChatHist_B", w / 2, h / 2 + s(1), TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	if fn then b.DoClick = fn end
	return b
end

local function fmtTs(ts)
	return os.date("%H:%M:%S", tonumber(ts) or 0)
end

local function fmtLine(r)
	local tag = CHAN_TAG[r.ch] or string.upper(tostring(r.ch or "?"))
	return os.date("%Y-%m-%d %H:%M:%S", tonumber(r.ts) or 0) .. "  [" .. tag .. "]  " .. tostring(r.tx or "")
end

local function ellipsize(str, font, maxW)
	str = tostring(str or "")
	if maxW <= 40 then return str end
	surface.SetFont(font)
	if surface.GetTextSize(str) <= maxW then return str end
	local cut = str
	if utf8 and utf8.len and utf8.sub then
		local l = utf8.len(cut) or #cut
		while l > 1 and surface.GetTextSize(utf8.sub(cut, 1, l) .. "…") > maxW do
			l = l - 1
		end
		return utf8.sub(cut, 1, l) .. "…"
	end
	while #cut > 4 and surface.GetTextSize(cut .. "…") > maxW do
		cut = string.sub(cut, 1, #cut - 1)
	end
	return cut .. "…"
end

local function fillList(sp, rows, query)
	sp:Clear()
	query = string.lower(string.Trim(query or ""))
	local n = 0
	for _, r in ipairs(rows) do
		local tag = CHAN_TAG[r.ch] or string.upper(tostring(r.ch or "?"))
		if query == "" or string.find(string.lower(tag .. " " .. tostring(r.tx or "")), query, 1, true) then
			n = n + 1
			local row = sp:Add("DButton")
			row:Dock(TOP)
			row:DockMargin(0, 0, s(6), s(3))
			row:SetTall(s(36))
			row:SetText("")
			row:SetCursor("hand")
			row:SetTooltip("Cliquer pour copier ce message")
			local col = CHAN_COL[r.ch] or TXT_DIM
			local shown
			row.Paint = function(self, w, h)
				roundRect(s(4), 0, 0, w, h, self:IsHovered() and FIELD_H or FIELD)
				draw.SimpleText(fmtTs(r.ts), "EVOChatHist_S", s(10), h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(tag, "EVOChatHist_S", s(84), h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local maxW = w - s(150)
				if not shown or self._ellipW ~= maxW then
					shown = ellipsize(r.tx, "EVOChatHist_B", maxW)
					self._ellipW = maxW
				end
				draw.SimpleText(shown, "EVOChatHist_B", s(140), h / 2, TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if (self._copiedUntil or 0) > SysTime() then
					draw.SimpleText("COPIÉ", "EVOChatHist_S", w - s(10), h / 2, OK_COL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			row.DoClick = function(self)
				SetClipboardText(fmtLine(r))
				self._copiedUntil = SysTime() + 1.4
				surface.PlaySound("garrysmod/ui_click.wav")
			end
		end
	end
	if n == 0 then
		local empty = sp:Add("DLabel")
		empty:Dock(TOP) empty:SetTall(s(48))
		empty:SetFont("EVOChatHist_B") empty:SetTextColor(TXT_DIM)
		empty:SetContentAlignment(5)
		empty:SetText(#rows == 0
			and "Aucun message enregistré (7 derniers jours)."
			or "Aucun message ne correspond au filtre.")
	end
	return n
end

function EVO_OpenPlayerChatLogs(sid, name)
	sid = tostring(sid or "")
	if sid == "" then return end
	if IsValid(UI) then UI:Remove() end

	local back = vgui.Create("DFrame")
	UI = back
	back._sid = sid
	back._name = tostring(name or "")
	back._rows = {}
	back._capped = false
	back._loading = true
	back:SetSize(ScrW(), ScrH()) back:SetPos(0, 0)
	back:SetTitle("") back:SetDraggable(false) back:ShowCloseButton(false)
	back:MakePopup()
	back.Paint = function(_, w, h) surface.SetDrawColor(0, 0, 0, 190) surface.DrawRect(0, 0, w, h) end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(back) end
	back.OnRemove = function() if UI == back then UI = nil end end

	local W = math.min(ScrW() - s(80), s(920))
	local H = math.min(ScrH() - s(80), s(640))
	local card = vgui.Create("DPanel", back)
	card:SetSize(W, H) card:Center()
	card.Paint = function(_, w, h)
		local pts = paintPlate(0, 0, w, h, CARD, s(12))
		if pts and EVO_UI and EVO_UI.OutlineCut then
			EVO_UI.OutlineCut(pts, Color(ACCENT.r, ACCENT.g, ACCENT.b, 60))
		end
		local title = "HISTORIQUE CHAT"
		draw.SimpleText(title, "EVOChatHist_T", s(26), s(34), TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
			surface.SetFont("EVOChatHist_T")
			local tw = surface.GetTextSize(title)
			EVO_UI.Ink(EVO_UI.TexSlash, s(23), s(34) + s(13), tw * 1.05, s(9), Color(ACCENT.r, ACCENT.g, ACCENT.b, 235))
		end
		local who = back._name ~= "" and back._name or sid
		draw.SimpleText(who, "EVOChatHist_B", s(26), s(62), TXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local close = vgui.Create("DButton", card)
	close:SetText("") close:SetSize(s(40), s(40)) close:SetPos(W - s(50), s(12))
	close:SetCursor("hand")
	close.Paint = function(self, w, h)
		draw.SimpleText("✕", "EVOChatHist_T", w / 2, h / 2, self:IsHovered() and ACCENT or TXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() back:Remove() end

	local search = vgui.Create("DTextEntry", card)
	search:SetPos(s(24), s(88)) search:SetSize(W - s(48), s(34))
	search:SetFont("EVOChatHist_B")
	search:SetTextColor(TXT) search:SetCursorColor(TXT) search:SetPaintBackground(false)
	search:SetDrawLanguageID(false) search:SetUpdateOnType(true)
	search.Paint = function(self, w, h)
		roundRect(s(4), 0, 0, w, h, FIELD)
		self:DrawTextEntryText(TXT, ACCENT, TXT)
		if self:GetText() == "" and not self:HasFocus() then
			draw.SimpleText("Filtrer (canal ou texte)…", "EVOChatHist_B", s(10), h / 2, TXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local sp = vgui.Create("DScrollPanel", card)
	sp:SetPos(s(24), s(130))
	sp:SetSize(W - s(48), H - s(200))
	local vbar = sp:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(s(5))
		vbar.Paint = function() end
		vbar.btnUp.Paint = function() end
		vbar.btnDown.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h)
			surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h)
		end
	end
	back._sp = sp
	back._count = 0

	local hint = vgui.Create("DLabel", card)
	hint:SetFont("EVOChatHist_S") hint:SetTextColor(TXT_MUT)
	hint:SetPos(s(26), H - s(50))
	hint:SetSize(W - s(320), s(36))
	hint:SetWrap(true)
	hint:SetText("Chargement…")
	back._hint = hint

	local function refresh()
		if not IsValid(sp) then return end
		local shown = fillList(sp, back._rows, search:GetValue())
		back._count = shown
		if not IsValid(hint) then return end
		if back._loading then
			hint:SetText("Chargement…")
		else
			local extra = back._capped and "  ·  lot tronqué (plus ancien ignoré)" or ""
			hint:SetText(shown .. " message(s)  ·  7 jours, 300 max / joueur  ·  clic = copier" .. extra)
		end
	end
	search.OnValueChange = function() refresh() end
	back._refresh = refresh
	refresh()

	local btnCopy = mkBtn(card, "Copier tout", true, function()
		if #back._rows == 0 then return end
		local lines = {}
		local q = string.lower(string.Trim(search:GetValue() or ""))
		for _, r in ipairs(back._rows) do
			if q == "" then
				lines[#lines + 1] = fmtLine(r)
			else
				local tag = CHAN_TAG[r.ch] or ""
				if string.find(string.lower(tag .. " " .. tostring(r.tx or "")), q, 1, true) then
					lines[#lines + 1] = fmtLine(r)
				end
			end
		end
		if #lines == 0 then return end
		SetClipboardText(table.concat(lines, "\n"))
		surface.PlaySound("garrysmod/content_downloaded.wav")
		if IsValid(hint) then hint:SetText(#lines .. " ligne(s) copiée(s) dans le presse-papiers.") end
	end)
	btnCopy:SetSize(s(150), s(40)) btnCopy:SetPos(W - s(176) - s(144), H - s(54))

	local btnClose = mkBtn(card, "Fermer", nil, function() back:Remove() end)
	btnClose:SetSize(s(132), s(40)) btnClose:SetPos(W - s(156), H - s(54))

	net.Start("EVO_Dash::ChatHistReq")
		net.WriteString(sid)
	net.SendToServer()
end

net.Receive("EVO_Dash::ChatHist", function()
	local sid = net.ReadString()
	local capped = net.ReadBool()
	local len = net.ReadUInt(32)
	local rows = {}
	if len and len > 0 then
		local json = util.Decompress(net.ReadData(len))
		if json and json ~= "" then rows = util.JSONToTable(json) or {} end
	end
	if not (IsValid(UI) and UI._sid == sid) then return end
	UI._loading = false
	UI._capped = capped == true
	UI._rows = istable(rows) and rows or {}
	if isfunction(UI._refresh) then UI._refresh() end
	-- Fil en bas : on lit comme un chat (plus récent visible).
	timer.Simple(0, function()
		if not IsValid(UI) or not IsValid(UI._sp) then return end
		local vbar = UI._sp:GetVBar()
		if IsValid(vbar) then vbar:SetScroll(vbar.CanvasSize or 0) end
	end)
end)
