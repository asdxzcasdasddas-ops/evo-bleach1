-- "addons\\evo_famille\\lua\\autorun\\sh_loader_famille.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO FAMILLE — système de clans RP persistant (BDD, par PERSONNAGE).
-- Chef de clan (grade 3) > Bras droit (2) > Membre (1).
-- Création payante en yens, invitations (UI + property menu), promotion/
-- rétrogradation (property menu + UI), nom de clan sous le nom RP (lzy_meet),
-- leaderboard 3D des clans (argent / niveaux / heures cumulés) à côté du
-- leaderboard existant.
-- ============================================================================
-- ⚠️ ADDON DÉSACTIVÉ (2026-07-13, demande user) : REMPLACÉ par les CLANS FIXES
-- d'evo_clan (8 clans, leader nommé par les superadmins, invitations leader,
-- pas d'XP, pas de PNJ doyen). Les tables BDD evo_families/evo_family_members/
-- evo_family_ranks/evo_famille_meta sont CONSERVÉES (dormantes) — ne PAS les
-- supprimer. Pour réactiver : retirer le `return` ci-dessous (et gérer la
-- cohabitation avec evo_clan : NW EVO_FamilyName partagé, bind "famille",
-- filtre du menu de binds, sorts de clan branchés sur EVO_Clan::PlayerSynced).
-- ============================================================================
if true then return end

EVO_FAMILLE = EVO_FAMILLE or {}

if SERVER then
    AddCSLuaFile("evo_famille/sh_config.lua")
    AddCSLuaFile("evo_famille/cl_main.lua")
    AddCSLuaFile("evo_famille/cl_leaderboard.lua")

    util.AddNetworkString("evo_famille:openui")  -- sv -> cl : ouvre le menu (commande chat)
    util.AddNetworkString("evo_famille:get")     -- cl -> sv : demande l'état
    util.AddNetworkString("evo_famille:state")   -- sv -> cl : état complet (famille + membres)
    util.AddNetworkString("evo_famille:create")  -- cl -> sv : créer (nom)
    util.AddNetworkString("evo_famille:invite")  -- cl -> sv : inviter (entité joueur)
    util.AddNetworkString("evo_famille:invited") -- sv -> cl : popup d'invitation chez la cible
    util.AddNetworkString("evo_famille:answer")  -- cl -> sv : réponse à l'invitation (bool)
    util.AddNetworkString("evo_famille:action")  -- cl -> sv : action (kick/promote/demote/leave/disband/rename)
    util.AddNetworkString("evo_famille:lb")      -- sv -> cl : données du leaderboard familles
end

include("evo_famille/sh_config.lua")

if SERVER then
    include("evo_famille/sv_main.lua")
else
    include("evo_famille/cl_main.lua")
    include("evo_famille/cl_leaderboard.lua")
end
