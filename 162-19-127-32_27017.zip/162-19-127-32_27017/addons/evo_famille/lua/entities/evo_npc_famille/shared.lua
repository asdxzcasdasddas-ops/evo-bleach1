-- "addons\\evo_famille\\lua\\entities\\evo_npc_famille\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- PNJ "Doyen des Clans" (fonder un clan — gate whitelist).

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Doyen des Clans"
ENT.Author    = "evo_famille"
ENT.Spawnable = false
ENT.AdminOnly = true

function ENT:SetupDataTables()
    self:NetworkVar("Bool", 0, "IsFamilleNPC")
end
