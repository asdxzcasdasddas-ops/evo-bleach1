-- "addons\\evo_famille\\lua\\entities\\evo_npc_famille\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("EVO_FamNPC_NameTag", {
    font      = "Roboto",
    size      = 64,
    weight    = 800,
    antialias = true,
})

ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette de nom.
ENT.EVO_PromptZ = 100

local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Initialize()
end

function ENT:Draw()
    self:DrawModel()
end

function ENT:DrawTranslucent()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local ePos = self:GetPos()
    if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

    local cfg  = EVO_FAMILLE and EVO_FAMILLE.Config or {}
    local name = cfg.NPCName or "Doyen des Clans"
    -- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
    if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 100, nil, 750, "parler") return end

    local pos = ePos + Vector(0, 0, 100)
    -- face caméra de rendu (EyePos) -> suit la cam orbitale, pas l'angle du joueur.
    local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

    cam.IgnoreZ(true)
    cam.Start3D2D(pos, ang, 0.15)
        if _tagName ~= name then
            _tagName = name
            surface.SetFont("EVO_FamNPC_NameTag")
            _tagTW, _tagTH = surface.GetTextSize(name)
        end
        draw.RoundedBox(0, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
        draw.SimpleText(name, "EVO_FamNPC_NameTag", 0, 0,
            COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
    cam.IgnoreZ(false)
end
