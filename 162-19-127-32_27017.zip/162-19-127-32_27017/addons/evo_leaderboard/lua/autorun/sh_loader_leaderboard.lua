-- "addons\\evo_leaderboard\\lua\\autorun\\sh_loader_leaderboard.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- sh_loader_leaderboard.lua — Loader evo_leaderboard
-- ============================================================

EVO_LEADERBOARD = EVO_LEADERBOARD or {}

local root = "evo_leaderboard/"

if SERVER then
    util.AddNetworkString("evo_leaderboard:sync")
    util.AddNetworkString("evo_leaderboard:set_pos")
end

AddCSLuaFile(root .. "sh_config.lua")
include(root .. "sh_config.lua")

if SERVER then
    AddCSLuaFile(root .. "cl_main.lua")

    include(root .. "sv_database.lua")
    include(root .. "sv_tracking.lua")
    include(root .. "sv_main.lua")
    include(root .. "sv_commande_time.lua")
end

if CLIENT then
    include(root .. "cl_main.lua")
end
