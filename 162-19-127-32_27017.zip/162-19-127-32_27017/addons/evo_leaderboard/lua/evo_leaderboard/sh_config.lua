-- "addons\\evo_leaderboard\\lua\\evo_leaderboard\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- sh_config.lua — Config du panneau leaderboard
-- ============================================================

EVO_LEADERBOARD = EVO_LEADERBOARD or {}

EVO_LEADERBOARD.Config = {
    -- Nombre d'entrees affichees par classement
    topN      = 25,

    -- Frequence de rafraichissement (serveur recalcule + broadcast)
    refreshInterval = 300, -- 5 minutes

    -- Frequence du flush playtime en DB
    playtimeFlushInterval = 60, -- 1 minute

    -- Categories affichees (ordre = ordre des colonnes)
    categories = {
        { id = "playtime", label = "Temps de jeu",  unit = "h"  },
        { id = "rank",     label = "Grade",         unit = ""   },
        { id = "money",    label = "Yens",          unit = " ¥" },
        { id = "deaths",   label = "Morts",         unit = ""   },
    },
}

-- ════════════════════════════════════════════════════════════
-- POSITIONS AUTO-SPAWN PAR MAP
-- Une entree par position {pos, angle, scale}. Plusieurs positions
-- peuvent etre definies par map. Les admins peuvent en ajouter via
-- la concommand "evo_leaderboard_addpos" (persiste dans data/).
-- ════════════════════════════════════════════════════════════

EVO_LEADERBOARD.AUTO_SPAWN_POSITIONS = {
    ["gm_construct"] = {
        -- A cote du panneau de la forge (forge a Vector(-300, 924, -148))
        -- angle.r = 90 -> panneau debout (vertical) ; angle.y -> direction qu'il regarde
        -- Chaque panneau est bind a une faction (visible par tout le monde)
        { pos = Vector(-100, 924, 100), angle = Angle(0, 90, 90), scale = 0.15, faction = "Shinigami" },
        { pos = Vector( 100, 924, 100), angle = Angle(0, 90, 90), scale = 0.15, faction = "Hollow"    },
    },
    ["rp_seireitei_v1"] = {
        -- yaw +180deg (-1.32 -> 178.68) + decale -100 sur X (vers la gauche)
        -- puis +20, +100, +120 sur X = VERS LA DROITE (demande user).
        -- NB : le leaderboard FAMILLE est COLLÉ à ce panneau (evo_famille LbAttach)
        -- -> il se décale automatiquement avec.
        { pos = Vector(-1950, -12445.719727, 519.031250), angle = Angle(0, 178.680695, 90), scale = 0.15, faction = "Shinigami" },
    },
    ["hueco_mundo_v1"] = {
        -- Panneau HOLLOW uniquement : le classement SHINIGAMI reste au Seireitei
        -- (demande user 07/24, panneau Shinigami retiré du Hueco). Le classement CLAN
        -- est désormais AUTONOME (evo_clan.Config.LbPanels) : il a sa PROPRE pose et
        -- ne suit PLUS ce panneau -> le déplacer/tourner ici n'affecte que le Hollow.
        -- Pose relevée user 07/23 (mur du couloir de Las Noches) + ajustements 07/24.
        { pos = Vector(3184.968750, 8357.426270, 5552.358398), angle = Angle(0, -90, 90), scale = 0.15, faction = "Hollow" }, -- 07/25 : DEBOUT face -X (roll 90) ; décalé +200 en Y (vers la droite du panneau) ; côté Maître des Arts
    },
}
