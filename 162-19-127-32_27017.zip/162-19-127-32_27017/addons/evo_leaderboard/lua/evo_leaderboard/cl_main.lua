-- "addons\\evo_leaderboard\\lua\\evo_leaderboard\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- cl_main.lua — Affichage 3D2D des panneaux classement (multi-positions)
-- ============================================================

local CFG = EVO_LEADERBOARD.Config

-- Cache reçu du serveur : { [faction] = { [categoryId] = { {name=, value=} ... } } }
EVO_LEADERBOARD.ClientCache  = EVO_LEADERBOARD.ClientCache  or {}
-- Cache d'AFFICHAGE pré-formaté (chaînes prêtes à dessiner), reconstruit
-- uniquement à la réception d'un sync. Évite de relancer les formateurs et
-- les opérations sur chaînes à chaque frame.
-- { [faction] = { [categoryId] = { [rowIndex] = { name=, val= } } } }
EVO_LEADERBOARD.DisplayCache = EVO_LEADERBOARD.DisplayCache or {}

-- Liste des positions reçues du serveur : { {pos=, angle=, scale=}, ... }
local activePositions = {}

-- ─── OPTIM RenderTarget (état) ──────────────────────────────────────────────
-- Le panneau est STATIQUE entre 2 syncs (5 min) : on le rend UNE FOIS dans une
-- texture (au sync) puis on dessine 1 quad texturé/frame au lieu de ~300
-- draw.SimpleText. Fonctions/détail plus bas. État déclaré ICI pour que
-- net.Receive (sync) marque le rebuild via la MÊME variable locale.
--   evo_leaderboard_rt 1 = RT (défaut)  |  0 = ancien dessin direct (revert live).
-- Si un build RT échoue (pcall) -> bascule définitive en direct : le panneau
-- n'est JAMAIS cassé/blanc, au pire on retombe sur le coût d'avant.
local USE_RT = CreateClientConVar("evo_leaderboard_rt", "1", true, false,
    "Leaderboard 3D2D via RenderTarget (1) ou dessin direct (0) - revert instantane")
local rtCache  = {}     -- [faction] = { rt = ITexture, mat = IMaterial }
local rtPanelW, rtPanelH
local rtDirty  = true    -- rebuild requis (après chaque sync)
local rtBroken = false   -- une erreur de build -> fallback direct permanent

-- Fonts alignées sur le leaderboard FAMILLES (DA Atelier) : Bebas SANS bold.
surface.CreateFont("EvoLeaderboardTitle",  { font = "Bebas Neue", size = 72, weight = 400, antialias = true })
surface.CreateFont("EvoLeaderboardHeader", { font = "Bebas Neue", size = 44, weight = 400, antialias = true })
surface.CreateFont("EvoLeaderboardRow",    { font = "Bebas Neue", size = 30, weight = 400, antialias = true })
surface.CreateFont("EvoLeaderboardKanji",  { font = "EVO Kanji",  size = 260, weight = 700, antialias = true })

-- ── Helpers de dessin DA Atelier (pixels 3D2D ABSOLUS, pas de gResp). ──
local function lbCircle(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

local function lbScrew(cx, cy, r)
    lbCircle(cx, cy, r + 2, Color(0, 0, 0, 155))
    lbCircle(cx, cy, r, Color(23, 25, 29, 255))
    lbCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(2, math.floor(r * 0.24)), 38)
end

local function lbDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = 12, 10
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 2)
        cx = cx + dw + gap
    end
end

-- ────────────────────────────────────────────────────────────
-- Formateurs par categorie
-- ────────────────────────────────────────────────────────────

local function formatPlaytime(seconds)
    local h = math.floor((seconds or 0) / 3600)
    local m = math.floor(((seconds or 0) % 3600) / 60)
    if h >= 1 then return string.format("%dh %02dm", h, m) end
    return string.format("%dm", m)
end

local function formatRank(rankIndex, faction)
    local list = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.factions and LZY_FACTION_CONFIG.factions[faction]
    if list and list[rankIndex] then return list[rankIndex] end
    return tostring(rankIndex)
end

local function formatMoney(amount)
    local s = tostring(math.floor(amount or 0))
    return s:reverse():gsub("(%d%d%d)", "%1 "):reverse():Trim() .. " ¥"
end

local function formatDeaths(n) return tostring(math.floor(n or 0)) end

local FORMATTERS = {
    playtime = function(v, faction) return formatPlaytime(v) end,
    rank     = function(v, faction) return formatRank(v, faction) end,
    money    = function(v, faction) return formatMoney(v) end,
    deaths   = function(v, faction) return formatDeaths(v) end,
}

-- ────────────────────────────────────────────────────────────
-- Construction du cache d'affichage (appelée à chaque sync, PAS par frame)
-- ────────────────────────────────────────────────────────────
function EVO_LEADERBOARD.BuildDisplayCache()
    local categories = CFG.categories or {}
    local topN = CFG.topN or 25
    local out = {}

    for faction, byCat in pairs(EVO_LEADERBOARD.ClientCache) do
        local fcache = {}
        for _, cat in ipairs(categories) do
            local formatter = FORMATTERS[cat.id] or tostring
            local entries   = byCat[cat.id] or {}
            local rows      = {}
            for iRow = 1, topN do
                local row = entries[iRow]
                if row then
                    local name = row.name or "?"
                    if #name > 18 then name = name:sub(1, 17) .. "…" end
                    rows[iRow] = { name = name, val = formatter(row.value, faction) }
                end
            end
            fcache[cat.id] = rows
        end
        out[faction] = fcache
    end

    EVO_LEADERBOARD.DisplayCache = out
end

net.Receive("evo_leaderboard:sync", function()
    EVO_LEADERBOARD.ClientCache = net.ReadTable() or {}
    local count = net.ReadUInt(8)
    activePositions = {}
    for i = 1, count do
        activePositions[i] = {
            pos     = net.ReadVector(),
            angle   = net.ReadAngle(),
            scale   = net.ReadFloat(),
            faction = net.ReadString(),
        }
    end

    -- Pré-formate une seule fois (les données ne changent qu'au sync).
    EVO_LEADERBOARD.BuildDisplayCache()

    -- Données changées -> les textures RT doivent être reconstruites (1x au prochain frame).
    rtDirty = true
end)

-- ────────────────────────────────────────────────────────────
-- 3D2D RENDERING
-- ────────────────────────────────────────────────────────────

local COL_WIDTH   = 540
local COL_PADDING = 24
local ROW_HEIGHT  = 32
local HEADER_H    = 80
local TITLE_H     = 100

-- Distance d'affichage, alignée sur le PNJ coiffeur (lzy_coiffeur = 750u).
-- "pas trop loin" : au-delà, le panneau n'est plus dessiné.
local DRAW_DIST    = 750
local DRAW_DIST_SQR = DRAW_DIST * DRAW_DIST

-- Couleurs hoistées au scope fichier : créées UNE fois (sinon ~300 tables
-- Color allouées par frame et par panneau -> churn GC inutile).
-- Palette DA EVO, identique au leaderboard FAMILLES (carte sombre #0E0E11,
-- accent rouge #cf444e, podium or/argent/bronze, pas de bordure grise).
local COL_PANEL_BG    = Color(13, 14, 17, 250)     -- plaque métal noir PLATE (Atelier v2)
local COL_ACCENT      = Color(207, 68, 78)
local COL_DIVIDER     = Color(255, 255, 255, 18)
local COL_TITLE       = Color(237, 238, 242)
local COL_HEADER      = COL_ACCENT
local COL_ROW_STRIPE  = Color(255, 255, 255, 8)
local COL_RANK_1      = Color(230, 196, 120)
local COL_RANK_2      = Color(190, 190, 198)
local COL_RANK_3      = Color(196, 132, 84)
local COL_RANK_DEF    = Color(108, 111, 120)
local COL_NAME        = Color(237, 238, 242)
local COL_VALUE       = Color(150, 154, 162)
local COL_EMPTY       = Color(108, 111, 120)

local function drawPanel(faction)
    local categories = CFG.categories or {}
    local nCols    = #categories
    local panelW   = nCols * (COL_WIDTH + COL_PADDING) + COL_PADDING
    local rowsH    = (CFG.topN or 25) * ROW_HEIGHT
    local panelH   = TITLE_H + HEADER_H + rowsH + COL_PADDING

    -- Plaque de métal noir Atelier PLATE : coins coupés 45° + vis, SANS liseré
    -- acier ; kanji de faction gravé clair (cut EXPLICITE : pixels 3D2D/RT, pas écran).
    if EVO_UI and EVO_UI.PaintCut then
        EVO_UI.PaintCut(0, 0, panelW, panelH, COL_PANEL_BG, 28)
    else
        draw.RoundedBox(0, 0, 0, panelW, panelH, COL_PANEL_BG)
    end
    draw.SimpleText(faction == "Hollow" and "虚" or "神", "EvoLeaderboardKanji",
        panelW - 16, panelH - 4, Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
    lbScrew(22, 22, 11)
    lbScrew(panelW - 52, 22, 11)
    lbScrew(panelW - 22, panelH - 22, 11)
    lbScrew(52, panelH - 22, 11)

    -- Header : titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
    local sTitle = string.format("CLASSEMENT : %s", faction or "?")
    draw.SimpleText(sTitle, "EvoLeaderboardTitle", COL_PADDING + 4, TITLE_H / 2 - 6,
        COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    surface.SetFont("EvoLeaderboardTitle")
    local twT, thT = surface.GetTextSize(sTitle)
    if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, COL_PADDING, TITLE_H / 2 - 6 + thT * 0.28,
        twT * 1.1, 20, ColorAlpha(COL_ACCENT, 245))) then
        surface.SetDrawColor(COL_ACCENT)
        surface.DrawRect(COL_PADDING + 4, TITLE_H / 2 - 6 + thT * 0.34, twT, 5)
    end
    lbDashes(COL_PADDING, TITLE_H - 6, panelW - COL_PADDING * 2, Color(255, 255, 255, 26))

    local data = EVO_LEADERBOARD.DisplayCache[faction] or {}

    for iCol, cat in ipairs(categories) do
        local x = COL_PADDING + (iCol - 1) * (COL_WIDTH + COL_PADDING)
        local y = TITLE_H

        draw.SimpleText(cat.label, "EvoLeaderboardHeader",
            x + 8, y + HEADER_H / 2,
            COL_HEADER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        local entries = data[cat.id] or {}

        for iRow = 1, CFG.topN do
            local row = entries[iRow]
            local ry = y + HEADER_H + (iRow - 1) * ROW_HEIGHT

            if iRow % 2 == 0 then
                draw.RoundedBox(0, x, ry, COL_WIDTH, ROW_HEIGHT - 2, COL_ROW_STRIPE)
            end

            local rankColor = COL_RANK_DEF
            if iRow == 1 then rankColor = COL_RANK_1
            elseif iRow == 2 then rankColor = COL_RANK_2
            elseif iRow == 3 then rankColor = COL_RANK_3
            end

            draw.SimpleText(iRow .. ".", "EvoLeaderboardRow",
                x + 8, ry + ROW_HEIGHT / 2,
                rankColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            if row then
                draw.SimpleText(row.name, "EvoLeaderboardRow",
                    x + 48, ry + ROW_HEIGHT / 2,
                    COL_NAME, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                MUGEN.DrawMoneyLine(row.val, "EvoLeaderboardRow",
                    x + COL_WIDTH - 8, ry + ROW_HEIGHT / 2,
                    COL_VALUE, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            else
                draw.SimpleText("-", "EvoLeaderboardRow",
                    x + COL_WIDTH / 2, ry + ROW_HEIGHT / 2,
                    COL_EMPTY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end
end

-- ────────────────────────────────────────────────────────────
-- RenderTarget : rendu du panneau une fois -> 1 quad/frame (cf. bloc état + convar)
-- Pattern 2D->RT calqué sur lzy_character/cl_models (prouvé sur ce projet) :
-- PushRenderTarget + OverrideAlphaWriteEnable(true,true) + cam.Start2D, dessin à
-- (0,0)..(w,h) puis Pop. Le panneau remplit exactement la RT (taille = panelW/H).
-- ────────────────────────────────────────────────────────────
local function rtComputeSize()
    local nCols = #(CFG.categories or {})
    rtPanelW = nCols * (COL_WIDTH + COL_PADDING) + COL_PADDING
    rtPanelH = TITLE_H + HEADER_H + (CFG.topN or 25) * ROW_HEIGHT + COL_PADDING
end

local function rtGet(faction)
    local c = rtCache[faction]
    if c then return c end
    if not rtPanelW then rtComputeSize() end

    local name = "evo_lb_rt_" .. faction
    local rt
    if GetRenderTargetEx and IMAGE_FORMAT_BGRA8888 ~= nil then
        local fl = 2 + 256 + 32768
        if bit and bit.bor then fl = bit.bor(2, 256, 32768) end
        rt = GetRenderTargetEx(name, rtPanelW, rtPanelH, RT_SIZE_LITERAL or 1,
            MATERIAL_RT_DEPTH_NONE, fl, 0, IMAGE_FORMAT_BGRA8888)
    end
    if not rt then rt = GetRenderTarget(name, rtPanelW, rtPanelH) end
    if not rt then return nil end

    local mat = CreateMaterial("evo_lb_mat_" .. faction, "UnlitGeneric", {
        ["$basetexture"] = rt:GetName(),
        ["$translucent"] = "1",
        ["$vertexalpha"] = "1",
        ["$vertexcolor"] = "1",
    })
    c = { rt = rt, mat = mat }
    rtCache[faction] = c
    return c
end

-- Rend chaque panneau-faction dans sa RT. Appelé en contexte 2D (HUDPaint).
local function rtRebuild()
    local ok = pcall(function()
        for faction in pairs(EVO_LEADERBOARD.DisplayCache) do
            local c = rtGet(faction)
            if c then
                render.PushRenderTarget(c.rt)
                    render.OverrideAlphaWriteEnable(true, true)
                    render.Clear(0, 0, 0, 0, true, true)
                    cam.Start2D()
                        drawPanel(faction) -- dessine à (0,0)..(rtPanelW,rtPanelH)
                    cam.End2D()
                    render.OverrideAlphaWriteEnable(false)
                render.PopRenderTarget()
            end
        end
    end)
    -- La moindre erreur -> fallback direct PERMANENT (jamais de panneau cassé).
    if not ok then rtBroken = true end
end

-- Build des RT quand "dirty" (après sync), en contexte 2D propre (HUDPaint, 1x/frame).
hook.Add("HUDPaint", "evo_leaderboard:RT_Build", function()
    if rtBroken or not USE_RT:GetBool() then return end
    if not rtDirty then return end
    if not next(EVO_LEADERBOARD.DisplayCache) then return end
    rtDirty = false
    rtRebuild()
end)

hook.Add("PostDrawTranslucentRenderables", "evo_leaderboard:Draw3D2D", function(bDepth, bSkybox)
    -- bDepth = passe de profondeur (eau/réfraction/DoF) : on NE redessine PAS le
    -- panneau 3D2D dans cette passe -> évite le double-rendu par frame. bSkybox : idem.
    if bDepth or bSkybox then return end
    if #activePositions == 0 then return end

    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local lpPos  = lp:GetPos()
    local eyePos = EyePos()
    local eyeFwd = EyeVector()
    local useRT  = USE_RT:GetBool() and not rtBroken
    if useRT and not rtPanelW then rtComputeSize() end

    for _, p in ipairs(activePositions) do
        -- 1) Cull distance (aligné coiffeur : on ne le voit pas de trop loin).
        if lpPos:DistToSqr(p.pos) <= DRAW_DIST_SQR then
            -- 2) Cull "derrière la caméra" : inutile de dessiner un panneau
            --    nettement hors champ (~>101°). Évite le rendu 3D2D gâché.
            local dir = (p.pos - eyePos):GetNormalized()
            if dir:Dot(eyeFwd) >= -0.2 then
                local faction = p.faction or "Shinigami"
                cam.Start3D2D(p.pos, p.angle, p.scale)
                    local c = useRT and rtCache[faction]
                    if c and c.mat then
                        -- 1 quad texturé au lieu de ~300 draw.SimpleText.
                        surface.SetDrawColor(255, 255, 255, 255)
                        surface.SetMaterial(c.mat)
                        surface.DrawTexturedRect(0, 0, rtPanelW, rtPanelH)
                    else
                        -- Fallback direct : RT off / pas encore prête / cassée.
                        drawPanel(faction)
                    end
                cam.End3D2D()
            end
        end
    end
end)

-- Diagnostic : imprime l'état RT dans la console pour comprendre si/pourquoi le
-- RT n'est pas actif (code chargé ? RT cassée ? caches peuplés ?).
concommand.Add("evo_leaderboard_rt_status", function()
    print("=== EVO Leaderboard RT status ===")
    print("convar evo_leaderboard_rt = " .. tostring(USE_RT:GetBool()))
    print("rtBroken = " .. tostring(rtBroken) .. "   rtDirty = " .. tostring(rtDirty))
    print("rtPanelW/H = " .. tostring(rtPanelW) .. " x " .. tostring(rtPanelH))
    local n = 0
    for faction, c in pairs(rtCache) do
        n = n + 1
        local err = (c.rt and c.rt.IsError) and tostring(c.rt:IsError()) or "?"
        print(string.format("  RT[%s] : name=%s  mat=%s  isError=%s", faction,
            (c.rt and c.rt.GetName) and c.rt:GetName() or "nil", tostring(c.mat ~= nil), err))
    end
    print("RT cache entries = " .. n)
    print("activePositions = " .. #activePositions)
    for _, p in ipairs(activePositions) do print("   position faction = " .. tostring(p.faction)) end
    local dc = 0
    for _ in pairs(EVO_LEADERBOARD.DisplayCache) do dc = dc + 1 end
    print("DisplayCache factions = " .. dc)
    print("=================================")
end)
