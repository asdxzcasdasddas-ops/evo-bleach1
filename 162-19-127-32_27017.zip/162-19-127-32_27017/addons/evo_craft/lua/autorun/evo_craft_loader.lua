-- "addons\\evo_craft\\lua\\autorun\\evo_craft_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Ateliers de craft de division : zones au sol (même mécanique que les Archives
-- evo_livre, en plus petit), une zone = un rôle de division (assassin / soin /
-- combat, résolution par NOM via EvoStyle.DivisionSpells). Les recettes de
-- chaque rayon vivent dans leur propre fichier sv_craft_<role>.lua.

if SERVER then
	AddCSLuaFile("evo_craft/sh_config.lua")
	AddCSLuaFile("evo_craft/sh_craft_resources.lua")
	AddCSLuaFile("evo_craft/sh_craft_assassin_gear.lua")
	AddCSLuaFile("evo_craft/sh_hollow_drops.lua")
	AddCSLuaFile("evo_craft/cl_main.lua")
	AddCSLuaFile("evo_craft/cl_coffre.lua")
	AddCSLuaFile("evo_craft/cl_resources.lua")
	AddCSLuaFile("evo_craft/cl_assassin_gear.lua")
	AddCSLuaFile("evo_craft/sh_lunettes.lua")
	AddCSLuaFile("evo_craft/cl_lunettes.lua")

	include("evo_craft/sh_config.lua")
	include("evo_craft/sh_craft_resources.lua")
	include("evo_craft/sh_craft_assassin_gear.lua")
	include("evo_craft/sh_hollow_drops.lua")
	include("evo_craft/sh_lunettes.lua")
	include("evo_craft/sv_main.lua")
	include("evo_craft/sv_coffre.lua")
	include("evo_craft/sv_enchant_rescale.lua")
	include("evo_craft/sv_enchant_repair.lua")
	include("evo_craft/sv_resources.lua")
	include("evo_craft/sv_craft_assassin.lua")
	include("evo_craft/sv_craft_soin.lua")
	include("evo_craft/sv_craft_combat.lua")
	include("evo_craft/sv_lunettes.lua")
end

if CLIENT then
	include("evo_craft/sh_config.lua")
	include("evo_craft/sh_craft_resources.lua")
	include("evo_craft/sh_craft_assassin_gear.lua")
	include("evo_craft/sh_hollow_drops.lua")
	include("evo_craft/cl_main.lua")
	include("evo_craft/cl_coffre.lua")
	include("evo_craft/cl_resources.lua")
	include("evo_craft/cl_assassin_gear.lua")
	include("evo_craft/sh_lunettes.lua")
	include("evo_craft/cl_lunettes.lua")
end
