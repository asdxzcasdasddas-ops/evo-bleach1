-- "addons\\evo_craft\\lua\\evo_craft\\cl_lunettes.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Lunettes d'analyse, côté client : vise la personne la plus proche du centre de l'écran,
-- demande ses valeurs au serveur (seul juge) et dessine l'interface façon scouter.
local L = EVO_LUNETTES
local VERT, VERT_FONCE, FOND = Color(90, 255, 130), Color(40, 140, 70), Color(5, 25, 12, 190)
local tScan, nProchain = nil, 0
local nPolice = 0

local function Polices()
	if nPolice == ScrH() then return end
	nPolice = ScrH()
	local k = ScrH() / 1080
	surface.CreateFont("EVO_Lun_Titre", { font = "Bebas Neue", size = math.Round(24 * k), weight = 400, antialias = true, extended = true })
	surface.CreateFont("EVO_Lun_Ligne", { font = "Bebas Neue", size = math.Round(20 * k), weight = 400, antialias = true, extended = true })
end

local function PorteLunettes(lp)
	local eq = lp.GetInventoryEquippedItems and lp:GetInventoryEquippedItems()
	if not istable(eq) then return false end
	for _, id in pairs(eq) do
		if id == L.ID then return true end
	end
	return false
end

local function Visible(p)
	if LZY_Character_ShouldDrawOtherPlayer and not LZY_Character_ShouldDrawOtherPlayer(p) then return false end
	return not (NCM_INSTANCE and NCM_INSTANCE.ShouldHideFromLocal and NCM_INSTANCE.ShouldHideFromLocal(p))
end

local function Tete(p) return p:EyePos() + Vector(0, 0, 6) end

-- Personne visée = la plus proche du centre de l'écran, dans un rayon de 22 % de la hauteur.
local function ChercherCible(lp)
	local cx, cy, nMax = ScrW() / 2, ScrH() / 2, (ScrH() * 0.22) ^ 2
	local vOeil, best, nBest = EyePos(), nil, nMax
	for _, p in player.Iterator() do
		if p ~= lp and p:Alive() and not p:IsDormant() and p:GetPos():DistToSqr(vOeil) <= L.Portee * L.Portee and Visible(p) then
			local s = Tete(p):ToScreen()
			if s.visible then
				local d = (s.x - cx) ^ 2 + (s.y - cy) ^ 2
				if d < nBest then best, nBest = p, d end
			end
		end
	end
	return best
end

net.Receive("EVO:Lunettes:Scan", function()
	if not net.ReadBool() then tScan = nil return end
	local p = net.ReadEntity()
	local t = { ent = p, hp = net.ReadUInt(32), hpMax = net.ReadUInt(32), rei = net.ReadUInt(32),
		reiMax = net.ReadUInt(32), art = net.ReadString(), dur = net.ReadFloat(), recu = RealTime() }
	-- Chiffres qui défilent à l'acquisition d'une nouvelle cible (effet scouter).
	t.depuis = (tScan and tScan.ent == p) and tScan.depuis or RealTime()
	tScan = t
end)

local function Valeur(n, t)
	local f = math.Clamp((RealTime() - t.depuis) / 0.5, 0, 1)
	return math.floor(n * f)
end

local function Coin(x, y, dx, dy, n)
	surface.DrawRect(x, y, dx * n, 2)
	surface.DrawRect(x, y, 2, dy * n)
end

hook.Add("HUDPaint", "EVO::Lunettes::Scouter", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local t = RealTime()
	if t >= nProchain then
		nProchain = t + L.Intervalle
		if PorteLunettes(lp) then
			local p = ChercherCible(lp)
			if p then
				-- netgate: stream -- 2 Hz (L.Intervalle), dans HUDPaint pour que ToScreen lise la vue courante
				net.Start("EVO:Lunettes:Scan") net.WriteEntity(p) net.SendToServer()
			else
				tScan = nil
			end
		else
			tScan = nil
		end
	end

	local s = tScan
	if not s or t - s.recu > 1.5 or not IsValid(s.ent) or not s.ent:Alive() or not Visible(s.ent) then return end
	Polices()
	local vTete, vPied = Tete(s.ent):ToScreen(), s.ent:GetPos():ToScreen()
	if not vTete.visible then return end

	-- Cadre de verrouillage autour de la cible.
	local h = math.max(40, vPied.y - vTete.y)
	local w = h * 0.55
	local x0, y0 = vTete.x - w / 2, vTete.y - h * 0.1
	local n = math.max(10, w * 0.25)
	surface.SetDrawColor(VERT)
	Coin(x0, y0, 1, 1, n) Coin(x0 + w, y0, -1, 1, n)
	Coin(x0, y0 + h, 1, -1, n) Coin(x0 + w, y0 + h, -1, -1, n)

	-- Fiche à droite du cadre.
	local k = ScrH() / 1080
	local fx, fy, fw, fh = x0 + w + 14 * k, y0, 250 * k, 118 * k
	draw.RoundedBox(0, fx, fy, fw, fh, FOND)
	surface.SetDrawColor(VERT_FONCE)
	surface.DrawOutlinedRect(fx, fy, fw, fh, 1)
	surface.DrawRect(fx, fy, 3, fh)
	local sArt = s.art ~= "" and (EVO_ArtPowerName and EVO_ArtPowerName(s.art, s.art) or s.art) or "Aucun"
	local lx, ly, pas = fx + 12 * k, fy + 8 * k, 26 * k
	draw.SimpleText("ANALYSE", "EVO_Lun_Titre", lx, ly, VERT)
	draw.SimpleText(string.format("PV  %d / %d", Valeur(s.hp, s), s.hpMax), "EVO_Lun_Ligne", lx, ly + pas, VERT)
	draw.SimpleText(string.format("REIATSU  %d / %d", Valeur(s.rei, s), s.reiMax), "EVO_Lun_Ligne", lx, ly + pas * 2, VERT)
	draw.SimpleText("ART  " .. string.upper(sArt), "EVO_Lun_Ligne", lx, ly + pas * 3, VERT)
	draw.SimpleText(string.format("Lunettes %d %%", math.ceil(s.dur)), "EVO_Lun_Ligne", fx + fw - 10 * k, fy + fh + 4 * k,
		s.dur <= 15 and Color(255, 110, 90) or VERT_FONCE, TEXT_ALIGN_RIGHT)
end)
