-- "addons\\evo_craft\\lua\\evo_craft\\sh_craft_resources.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Ressources d'artisanat (evo_craft) : bois / roche / métal brut récoltés sur
-- des NŒUDS fixes dans le monde, os récupérés sur les KILLS de PNJ hostiles,
-- corde fabriquée à l'atelier assassin (au bois, 09/23). Fusion des os 4 vers 1 à la forge
-- (même mécanique que les cristaux de reiryoku). Config PARTAGÉE.

EVO_CRAFT = EVO_CRAFT or {}

-- ── Items ressources (ids res_*) ─────────────────────────────────────────────
EVO_CRAFT.Resources = {
	res_bois = {
		name = "Bois", rarity = "common",
		model = "models/evo/props/items/resources/bois/evo_647f708c252b644c96.mdl",
		desc = "Rondins secs ramassés dans la nature. Matériau d'artisanat de base.",
		stack_max = 64,
	},
	res_roche = {
		name = "Roche", rarity = "common",
		model = "models/evo/props/items/resources/roche/evo_821a0f4df6d41c4f6e.mdl",
		desc = "Bloc de pierre brute. Se taille, se broie, cale les mécanismes.",
		stack_max = 64,
	},
	res_metal_brut = {
		name = "Métal brut", rarity = "rare",
		model = "models/evo/props/items/resources/metal_brut/evo_30fb2534dabbac346d.mdl",
		desc = "Minerai lourd arraché aux affleurements. Le cœur des mâchoires et des coques.",
		stack_max = 64,
	},
	res_petit_os = {
		name = "Petit os", rarity = "common",
		model = "models/evo/props/items/resources/petits_os/evo_4fbfb3068e754c91af.mdl",
		desc = "Ossements laissés par une créature abattue. Quatre se fondent en un os moyen à la forge.",
		stack_max = 64,
	},
	res_os_moyen = {
		name = "Os moyen", rarity = "rare",
		model = "models/evo/props/items/resources/os_moyens/evo_29af3ef2788155eb8b.mdl",
		desc = "Os dense et régulier. Quatre se fondent en un gros os à la forge.",
		stack_max = 64,
	},
	res_gros_os = {
		name = "Gros os", rarity = "epic",
		model = "models/evo/props/items/resources/os/evo_53b44343b9e1685820.mdl",
		desc = "Fémur massif saturé de reiryoku. Les artificiers en tirent leurs sceaux les plus dangereux.",
		stack_max = 64,
	},
	res_corde = {
		name = "Corde", rarity = "common",
		model = "models/evo/props/items/resources/corde/evo_eca7617433d50ba6c0.mdl",
		desc = "Fibres d'écorce torsadées puis goudronnées. Tend les ressorts et ficelle les pièges.",
		stack_max = 64,
	},
}

-- Ordre d'affichage stable (l'atelier et la forge listent dans cet ordre).
EVO_CRAFT.ResourceOrder = {
	"res_bois", "res_roche", "res_metal_brut",
	"res_petit_os", "res_os_moyen", "res_gros_os", "res_corde",
}

-- ── Nœuds de récolte (par map) ───────────────────────────────────────────────
-- Chaque nœud tire son TYPE à chaque (re)spawn selon les poids de la map : les
-- spots tournent, pas de farm d'un point fixe. setpos BRUTS (snap sol serveur).
EVO_CRAFT.ResNodes = {
	-- Respawn RALENTI le 08/22 (x2,5) puis ENCORE ×4 le 08/28 (user « réduit
	-- énormément ») : 10 à 24 min par nœud. Le nombre de spots ne bouge pas —
	-- c'est la DISPONIBILITE qui baisse, pas la couverture de la map.
	RespawnMin = 600,   -- s avant réapparition d'un nœud récolté (mini)
	RespawnMax = 1440,  -- s (maxi)
	HarvestXP  = 3,    -- XP d'atelier assassin par ramassage (progression DURE voulue)
	UseDist    = 110,  -- portée du [E]

	-- Poids par FAMILLE DE SPOT (user 08/21) : un spot au pied d'un arbre ne
	-- donne QUE du bois, un spot au pied d'une roche donne pierre ou métal.
	-- Utilisé quand la map déclare ses spots par famille (cf. Spots ci-dessous) ;
	-- une map en liste plate garde les poids globaux `Weights`.
	KindWeights = {
		arbre = { res_bois = 100 },
		roche = { res_roche = 60, res_metal_brut = 40 },
	},

	-- Poids de tirage du type par map (Hueco plus minéral, Seireitei plus boisé).
	-- REPLI : ne sert plus qu'aux maps dont les spots sont une liste PLATE.
	Weights = {
		["rp_seireitei_v1"] = { res_bois = 40, res_roche = 35, res_metal_brut = 25 },
		["hueco_mundo_v1"]  = { res_bois = 25, res_roche = 40, res_metal_brut = 35 },
		["gm_construct"]    = { res_bois = 34, res_roche = 33, res_metal_brut = 33 },
		-- Ville du Monde des vivants : boisée (parcs, berges), comme le Seireitei.
		["rp_shinonome_evo"] = { res_bois = 40, res_roche = 35, res_metal_brut = 25 },
	},

	Spots = {
		-- setpos user 08/18 (72 points).
		-- Seireitei (setpos user 08/21) : le TYPE dépend du SPOT — au pied d'un
		-- ARBRE on ramasse du BOIS, au pied d'une ROCHE de la pierre ou du métal.
		-- Les spots ARBRE sont les MÊMES que ceux des champignons et plantes
		-- (evo_science HarvestZones) : la forêt nourrit les deux récoltes.
		["rp_seireitei_v1"] = {
			arbre = {
				Vector(-3315.241455, -579.313538, -14855.953125), Vector(-2080.011963, -242.717636, -14806.134766),
				Vector(-2133.418945, 624.178467, -14984.857422), Vector(-3535.882568, 2257.216064, -14940.827148),
				Vector(-4025.004883, 3575.074463, -14970.413086), Vector(-6356.397461, 6973.779785, -14929.737305),
				Vector(-4364.365723, 6405.996582, -14967.178711), Vector(-2148.016602, 5013.530762, -14415.805664),
				Vector(-964.124207, 4779.343262, -14414.011719), Vector(-615.614685, 3851.720947, -14715.357422),
				Vector(1036.558838, -164.389206, -14965.582031), Vector(1817.400635, -1774.567871, -14564.201172),
				Vector(4484.657715, -587.876587, -14760.712891), Vector(4587.947266, 1018.120972, -14774.686523),
				Vector(6362.038574, 141.505722, -14290.026367), Vector(7502.056152, -1038.651367, -14385.041016),
				Vector(9446.354492, 183.490662, -14410.398438), Vector(9849.241211, -8831.277344, -14448.049805),
				Vector(8020.000488, -9924.035156, -14447.188477), Vector(4504.413086, -11003.820312, -13868.833984),
				Vector(2876.103760, -5500.395996, -14276.909180), Vector(-4358.968750, -9636.852539, -13794.949219),
				Vector(-7088.350098, -6125.350098, -14957.811523), Vector(13122.911133, 6887.489746, -14292.000977),
				Vector(-4098.683105, 7989.226562, -14720.955078), Vector(-5053.442871, -6042.883301, -6626.001953),
				Vector(-5716.255859, -4672.599121, -6566.414062), Vector(-3577.322021, 76.262321, -6435.792969),
				Vector(-2051.273682, 382.320282, -6194.570801), Vector(-4564.437500, 3305.484375, -7089.937988),
				Vector(-2369.838135, 7223.993164, -6919.721680), Vector(-237.784180, 9234.956055, -6636.257324),
				Vector(1459.268555, 6700.955078, -6408.250488), Vector(1248.960205, 1207.822266, -6301.340332),
				Vector(4659.819824, 3020.423096, -5856.489746), Vector(4095.077393, 9719.189453, -5518.920898),
				Vector(9747.894531, 10617.436523, -5510.249512), Vector(12841.492188, 11706.697266, -5526.444336),
				Vector(13737.712891, 6041.203613, -6432.926270), Vector(11503.961914, 4192.210938, -5530.559570),
				Vector(7645.256836, 2325.671387, -6040.391113), Vector(8128.967285, 1692.625122, -6566.269531),
				Vector(9897.722656, -1274.364502, -7304.933594), Vector(12355.465820, -1386.096069, -7343.170898),
				Vector(14045.417969, -3997.582764, -6388.431152), Vector(12287.080078, -9284.845703, -6438.158691),
				Vector(9035.249023, -11366.018555, -6365.876465), Vector(6300.447754, -8042.061035, -5843.308105),
				Vector(3675.347900, -9819.724609, -7268.990723), Vector(-4251.027344, -6901.470703, -5817.579102),
				Vector(-7138.874023, -6513.131836, -5778.671875), Vector(1419.922974, -11476.750977, -5147.075684),
				Vector(-2733.118896, 2073.268066, -5932.602539), Vector(-6889.410156, 9638.158203, -6399.505371),
				Vector(13391.309570, -10924.933594, -5620.207520), Vector(-428.450165, -2974.754639, -7234.766602),
			},
			roche = {
				Vector(9268.600586, -445.372589, -14335.669922), Vector(8915.616211, -475.532349, -14325.383789),
				Vector(1714.710938, -2733.054443, -13976.252930), Vector(-5052.413086, -6223.258789, -14967.540039),
				Vector(-4773.952148, -6656.174316, -14974.400391), Vector(-5030.299316, -6696.705566, -14963.881836),
				Vector(130.430283, -5484.461426, -14899.545898), Vector(11636.000977, 4459.115234, -14378.409180),
				Vector(11263.110352, 4217.008301, -14366.462891), Vector(8066.931641, 4436.736816, -14367.619141),
				Vector(7722.873047, 4403.846680, -14384.983398), Vector(12110.365234, 10104.221680, -14031.799805),
				Vector(12439.578125, 10134.527344, -14048.015625), Vector(7764.043945, 8902.508789, -13643.390625),
				Vector(7401.561035, 8644.182617, -13578.510742), Vector(7683.620605, 8984.500977, -13654.332031),
				Vector(-5401.067383, 3853.905029, -7054.882324), Vector(-5437.284180, 3983.444824, -7051.763184),
				Vector(-6155.278320, 2757.755615, -7146.521484), Vector(-5894.260254, -1010.282593, -6629.242188),
				Vector(-4078.162598, -5028.253906, -6594.222168), Vector(-4203.251953, -5060.252441, -6568.593262),
				Vector(-3006.055176, 4198.026855, -6846.305176), Vector(1120.049316, 7866.904785, -5540.386719),
				Vector(1254.879395, 8279.849609, -5541.114258), Vector(1575.927368, 7983.385742, -5466.009766),
				Vector(11906.683594, 3842.090576, -6043.451172), Vector(7291.648926, 2958.241211, -5248.767578),
				Vector(13111.215820, -6298.120605, -6403.609863), Vector(12980.042969, -6774.430664, -6406.434570),
				Vector(7504.323730, 2920.663818, -5231.328125), Vector(6035.719238, -6527.725098, -7310.486328),
				Vector(6437.004395, -6756.595215, -7343.584473), Vector(11769.997070, 748.675903, -7250.674805),
				Vector(12046.504883, 908.166138, -7268.792969), Vector(-3036.257324, -2286.052490, -7094.288574),
				Vector(-3591.276855, -2153.488525, -7095.334961), Vector(-3125.662109, -2539.084229, -7070.312500),
				Vector(-2023.402588, -1799.368408, -7128.480957), Vector(-2541.190918, -1475.496948, -7104.167969),
				Vector(-2620.120850, -1083.923096, -7095.347656), Vector(-5726.130859, -368.171173, -6661.150391),
				Vector(-6975.254395, 4436.512695, -7145.805176), Vector(-6915.581543, 3874.848633, -7079.458496),
				Vector(-1066.386841, 8508.896484, -6761.028809), Vector(-1146.034546, 8426.722656, -6761.047852),
			},
		},
		-- setpos user 08/18 (64 points).
		["hueco_mundo_v1"] = {
			-- Zone neutre 1 (setpos user 08/21) : le TYPE suit le LIEU, comme sur
			-- Seireitei. Les spots `arbre` sont les memes que ceux des champignons
			-- et plantes (evo_science HarvestZones).
			arbre = {
				Vector(-11147.777344, 2205.876709, 186.608002), Vector(-11029.721680, 4307.650391, 372.094238),
				Vector(-11595.985352, 9386.205078, 352.148010), Vector(-7722.964844, 9669.376953, 579.823914),
				Vector(-6728.293457, 9537.050781, 235.603088), Vector(-5624.445312, 12389.028320, 116.432770),
				Vector(-4671.513184, 11193.656250, 131.874619), Vector(-3283.162842, 11604.862305, 116.406097),
				Vector(-4768.748535, 9680.713867, 124.635391), Vector(-2600.476562, 9367.439453, 114.849663),
				Vector(-960.999084, 9843.613281, 322.014740), Vector(-290.353577, 10820.899414, 407.135040),
				Vector(-3437.257812, 7204.451172, 487.950897), Vector(-3171.622314, 1225.757935, 127.940369),
				Vector(-3508.088379, -446.994751, 550.573242), Vector(-5984.545410, 65.829468, 170.617401),
				Vector(-6476.841797, 2201.324951, 116.165245), Vector(-7808.556152, 824.149414, 142.292694),
				Vector(-8643.015625, 1080.038574, 300.101166), Vector(-8410.327148, -2356.822021, 172.023788),
				Vector(-9295.221680, -4808.507324, 112.653564), Vector(-7741.430176, -9389.465820, 66.564926),
				Vector(-4068.131836, -6663.016113, 190.841599), Vector(-3047.846191, -3517.831055, 416.014679),
				Vector(1268.223755, -6308.476074, 372.628998), Vector(651.652527, -3647.924316, 359.153961),
				Vector(-740.893433, -2574.877930, 107.445999), Vector(640.724854, 132.331207, 359.637482),
				Vector(-209.360031, 2334.907715, 271.901031), Vector(1489.558960, 6399.472168, 419.855133),
				Vector(6460.336426, 10135.841797, 47.889576), Vector(7984.649902, 11682.328125, 112.653595),
				Vector(10525.171875, 12473.143555, 239.224380), Vector(10023.343750, 10181.047852, 115.975296),
				Vector(11580.211914, 9189.974609, 123.178268), Vector(7652.586914, 7530.593262, 130.505096),
				Vector(8818.588867, 4670.314941, 168.557678), Vector(10331.311523, 3772.634521, 348.248383),
				Vector(11515.429688, 1458.718628, 399.399841), Vector(6791.215820, -3140.123291, 532.562134),
				Vector(9043.714844, -7444.108398, 115.510010), Vector(11502.132812, -7557.608398, 119.633286),
				Vector(6169.749023, -9690.360352, 420.188812), Vector(4289.363770, -9550.813477, 174.917969),
				Vector(4822.060547, 2352.157227, 117.432770), Vector(4889.741699, 2081.410400, 130.373459),
				-- Foret des Menos (setpos user 08/21)
				Vector(1732.019531, -5563.835449, -12696.071289), Vector(2492.534912, -5354.350098, -12742.371094),
				Vector(4288.293457, -4980.434570, -12821.916992), Vector(5500.098145, -6008.006348, -12783.112305),
				Vector(4670.494629, -3415.528564, -12774.576172), Vector(7960.848633, -732.622986, -12151.957031),
				Vector(2585.530273, 1086.248901, -12232.030273), Vector(584.266602, -2277.711670, -12817.770508),
				Vector(-1279.890869, -1336.552124, -12837.324219), Vector(-3317.526611, -1077.285156, -12902.457031),
				Vector(-2529.935059, -6177.611816, -12846.502930), Vector(-4370.027344, -7173.111328, -12910.006836),
				Vector(-9653.166992, -6617.644531, -12908.390625), Vector(-6174.015137, -1314.729492, -12867.388672),
				Vector(3659.276367, -493.487946, -12531.340820),
			},
			roche = {
				Vector(-7365.833008, 3358.675781, 131.167923), Vector(-6797.437012, 2722.460449, 152.608002),
				Vector(-6178.804199, 3371.645508, 123.033371), Vector(-6723.914551, 7868.749512, 531.976318),
				Vector(-6281.505859, 8895.681641, 210.628479), Vector(-6222.012207, 8721.815430, 214.644684),
				Vector(-1262.271729, 10290.427734, 258.405396), Vector(-1229.920410, 10368.987305, 286.963989),
				Vector(4305.237305, 13082.750000, 361.736450), Vector(4177.721191, 13219.100586, 655.060791),
				Vector(3486.815430, 8507.390625, 290.464142), Vector(3204.633789, 8622.813477, 312.247101),
				Vector(2176.931152, 5742.920410, 385.605499), Vector(-3642.910400, 572.973267, 517.138794),
				Vector(-5464.982422, -1890.715942, 348.278625), Vector(-7552.572266, -9610.339844, 321.264771),
				Vector(-2361.757080, -11043.052734, 856.165405), Vector(-3285.868652, -10787.760742, 207.807373),
				Vector(-718.101257, -9397.141602, 817.255554), Vector(2979.578369, -8800.986328, 501.456024),
				Vector(5316.628418, -7723.088379, 699.900146), Vector(5347.761719, -11581.819336, 579.301941),
				Vector(11028.182617, -10146.013672, 253.257462), Vector(8418.252930, -7823.782227, 371.362854),
				Vector(9695.805664, -1149.853271, 283.757141), Vector(9634.921875, -270.416718, 304.250244),
				Vector(9439.354492, 3423.289795, 155.101135), Vector(11964.082031, 8784.897461, 535.725220),
				Vector(12152.800781, 8424.892578, 311.620697), Vector(9541.708008, 12807.927734, 462.201141),
				Vector(6954.515625, 12598.650391, 257.036530), Vector(-4069.767578, 5220.137207, 1148.509033),
				Vector(-4052.903564, 4287.387695, 1420.439941),
				-- Foret des Menos (setpos user 08/21)
				Vector(1853.021362, -4921.501465, -12489.189453), Vector(1943.347778, -4569.089844, -12670.972656),
				Vector(2259.265625, -4176.871094, -12582.004883), Vector(539.668701, -6338.475586, -12288.451172),
				Vector(-8143.215820, -5649.727051, -12385.222656), Vector(-3965.642334, -657.636292, -12529.634766),
				Vector(-744.902161, -2632.599365, -15104.810547), Vector(502.728058, -3617.326416, -14935.437500),
				Vector(5825.760742, 2168.284668, -12320.366211), Vector(-342.157227, 3248.167480, -11604.684570),
				Vector(3969.089355, -5333.574219, -12710.074219), Vector(3667.205322, -5189.532227, -12882.253906),
				Vector(6993.516113, -4127.340820, -12669.153320), Vector(-4410.171387, 5241.866699, -11706.931641),
				Vector(-5766.408691, 242.227371, -11715.560547), Vector(-6636.189941, 4281.847656, -11644.271484),
			},
			-- Etage HAUT, pas encore releve par famille : garde le tirage aux poids
			-- de la map (KindWeights n'a pas d'entree `mixte`). A deplacer dans
			-- arbre/roche quand les spots seront releves.
			mixte = {
				Vector(-127.602402, -72.712387, 9663.976562), Vector(2003.908813, -1697.743042, 9677.770508),
				Vector(-119.291061, -3540.024414, 10066.723633), Vector(-200.163589, -3776.428223, 10066.570312),
				Vector(5.544993, -3726.724609, 10066.723633), Vector(985.320984, -9317.806641, 9245.146484),
				Vector(1020.791565, -9068.105469, 9240.110352), Vector(1234.020142, -9212.250977, 9232.062500),
				Vector(171.074890, -9830.516602, 9223.230469), Vector(36.026150, -9720.172852, 9216.181641),
				Vector(-36.506699, -9778.220703, 9207.656250), Vector(-15.020200, -9930.747070, 9209.636719),
				Vector(-783.722351, -6070.479980, 9554.723633), Vector(-613.678406, -6080.991699, 9554.723633),
				Vector(-680.061462, -5898.769043, 9554.723633), Vector(-11973.618164, -852.522522, 10578.723633),
				Vector(-11688.636719, -611.670471, 10578.701172), Vector(-11511.356445, -860.407471, 10578.708008),
				Vector(-7618.032227, -8355.841797, 10386.723633), Vector(-7469.871582, -8428.204102, 10386.723633),
				Vector(-7444.512207, -8250.116211, 10386.723633), Vector(5185.148438, 10565.182617, 9554.723633),
				Vector(4799.911133, 10692.211914, 9552.188477), Vector(12232.200195, -4269.814453, 9042.723633),
				Vector(12073.427734, -4519.668457, 9042.723633), Vector(12302.207031, -4491.244141, 9042.723633),
				Vector(12377.556641, -10388.092773, 9568.013672), Vector(12515.172852, -10592.444336, 9580.804688),
				Vector(12706.208984, -10426.416016, 9611.402344), Vector(-7582.047852, -8454.015625, 10386.723633),
				Vector(-7402.388672, -8317.273438, 10386.723633), Vector(-7606.338379, -8279.296875, 10386.723633),
			},
		},
		-- ZONE NEUTRE « Monde des vivants » : 88 poses user 08/27, en LISTE PLATE (pas
		-- relevées par famille) -> tirage aux poids de la map (Weights ci-dessus). Les
		-- MÊMES spots nourrissent champignons et plantes (evo_science HUB.HarvestZones) :
		-- GARDER LES DEUX EN PHASE.
		["rp_shinonome_evo"] = {
			Vector(4521.968262, 10067.981445, 102.238953), Vector(4937.665039, 9588.258789, 147.378052),
			Vector(4834.128906, 9118.127930, 139.094727), Vector(4847.436035, 8796.525391, 55.454903),
			Vector(4863.093262, 8283.018555, 23.859695), Vector(4973.373047, 8241.860352, 26.552544),
			Vector(4750.619141, 8134.123047, 54.727650), Vector(4528.117676, 8179.876465, 47.069275),
			Vector(4281.970215, 8263.215820, 37.312546), Vector(4523.014648, 7859.812500, 119.685493),
			Vector(4723.356445, 7574.263184, 103.786118), Vector(6617.733398, 7691.641113, 25.629955),
			Vector(6755.808105, 7398.660645, 27.214821), Vector(7096.358887, 7423.828125, 154.257187),
			Vector(7465.734375, 7251.651855, 338.286011), Vector(7531.201172, 7925.617188, 276.668793),
			Vector(7405.217285, 8038.060059, 266.828217), Vector(7330.594238, 7931.926758, 271.497467),
			Vector(7778.344238, 8886.363281, 48.132793), Vector(7922.279785, 9029.986328, 63.974308),
			Vector(7971.419434, 8877.537109, 63.812477), Vector(7907.470703, 8685.328125, 96.999466),
			Vector(8115.218262, 9149.496094, 114.773178), Vector(8302.227539, 9376.656250, 121.795395),
			Vector(8556.700195, 9747.966797, 68.780533), Vector(8996.122070, 9902.449219, 129.191437),
			Vector(9128.985352, 9795.475586, 141.601456), Vector(8679.465820, 11085.359375, 28.855499),
			Vector(8483.678711, 11269.507812, 32.749237), Vector(8272.376953, 11294.768555, 33.129730),
			Vector(7239.193848, 11260.934570, 68.985229), Vector(6722.607422, 12044.938477, 69.353424),
			Vector(6708.830078, 12170.879883, 66.809235), Vector(6585.615234, 12070.348633, 76.440155),
			Vector(6347.488281, 12580.759766, 67.969109), Vector(6348.006348, 12755.593750, 69.724274),
			Vector(6329.131836, 12828.946289, 69.454025), Vector(6309.015625, 12909.653320, 56.513218),
			Vector(6590.034180, 13361.239258, 57.688797), Vector(6535.819824, 13419.093750, 51.904282),
			Vector(6511.006348, 13548.356445, 40.689178), Vector(6285.667969, 14071.965820, 37.852627),
			Vector(6361.932129, 14062.930664, 26.960701), Vector(5714.693848, 14344.956055, 39.595577),
			Vector(5542.680176, 14363.251953, 55.832878), Vector(5279.924316, 14295.725586, 42.947113),
			Vector(5170.030762, 14290.000977, 57.133728), Vector(4250.345215, 14254.798828, 14.068039),
			Vector(4090.547119, 14225.445312, -11.767578), Vector(4176.938477, 14026.004883, 37.632423),
			Vector(3498.540039, 13952.382812, 39.193123), Vector(2772.719482, 13944.787109, 69.618660),
			Vector(2749.540039, 14045.412109, 63.526169), Vector(2825.700928, 14358.306641, 83.537025),
			Vector(3182.188232, 14482.003906, 94.404839), Vector(3347.059570, 13495.329102, 29.116405),
			Vector(3649.429932, 13320.060547, 25.701942), Vector(3607.275146, 13222.621094, 20.353607),
			Vector(3607.807861, 13146.097656, 19.515846), Vector(3516.084961, 13004.990234, 12.758564),
			Vector(3438.641602, 12984.484375, 12.750202), Vector(2813.142822, 12724.081055, 37.431480),
			Vector(2715.479736, 12577.101562, 51.018272), Vector(2595.681885, 12406.000000, 46.307285),
			Vector(2599.965332, 12333.958984, 27.541065), Vector(2471.175537, 12153.077148, 41.808517),
			Vector(2424.507080, 11962.286133, 31.227539), Vector(2790.803711, 11875.782227, 34.248859),
			Vector(2749.212891, 11956.457031, 10.773010), Vector(2614.306152, 11050.438477, 38.366524),
			Vector(2499.951172, 11142.869141, 58.372768), Vector(2400.094971, 11096.461914, 66.074287),
			Vector(1875.063354, 10415.830078, 40.221756), Vector(1709.616577, 10336.013672, 29.285347),
			Vector(1432.482788, 10199.725586, 84.574997), Vector(1508.187256, 10021.957031, 128.217255),
			Vector(1867.329834, 9621.833008, 350.392273), Vector(1969.717773, 9760.625000, 363.273407),
			Vector(1524.298706, 9054.033203, 34.062271), Vector(1271.777222, 8879.165039, -18.230621),
			Vector(1007.727661, 8843.318359, 1.117287), Vector(851.026306, 8693.041016, 13.036060),
			Vector(737.590088, 8484.173828, 0.651119), Vector(728.112610, 8296.714844, -4.711136),
			Vector(698.663940, 8021.452637, 27.805630), Vector(732.999390, 7795.365234, 36.747574),
			Vector(1229.290039, 7872.961426, 14.791298), Vector(1484.896851, 7868.409180, 5.839417),
		},
		-- Nœuds de TEST à côté des zones d'atelier.
		["gm_construct"] = {
			Vector(-620, 480, -148), Vector(-460, 480, -148), Vector(-300, 480, -148),
		},
	},
}

-- Spots de la map, NORMALISÉS en { pos, kind } : une map peut déclarer soit une
-- liste plate (kind nil = tirage aux poids de la map), soit des familles
-- `arbre` / `roche` (kind posé = tirage aux poids de la famille). Source UNIQUE
-- du spawner : lui n'a plus à connaître les deux formes.
function EVO_CRAFT.ResSpotList(sMap)
	local t = (EVO_CRAFT.ResNodes.Spots or {})[sMap]
	if not istable(t) then return {} end
	local out = {}
	if t[1] then -- liste plate
		for _, v in ipairs(t) do out[#out + 1] = { pos = v } end
		return out
	end
	for sKind, tList in SortedPairs(t) do -- familles : ordre STABLE (index de nœud)
		if istable(tList) then
			for _, v in ipairs(tList) do out[#out + 1] = { pos = v, kind = sKind } end
		end
	end
	return out
end

-- ── Os sur les kills de PNJ hostiles ────────────────────────────────────────
-- Tirage en CASCADE du plus rare au plus courant (un seul os max par kill).
EVO_CRAFT.BoneDrop = {
	{ id = "res_gros_os",  pct = 1.5 },
	{ id = "res_os_moyen", pct = 6 },
	{ id = "res_petit_os", pct = 35 },
}

-- ── Fusion des os à la forge (4 vers 1, même mécanique que les cristaux) ────
-- Coûts divisés par deux le 08/24 (user : « descendre les prix de fusion »).
EVO_CRAFT.BoneFusion = {
	{ from = "res_petit_os", to = "res_os_moyen", count = 4, cost = 125 },
	{ from = "res_os_moyen", to = "res_gros_os",  count = 4, cost = 250 },
}

function EVO_CRAFT.BoneFusionFor(sFrom)
	for _, f in ipairs(EVO_CRAFT.BoneFusion) do
		if f.from == sFrom then return f end
	end
	return nil
end

-- SCISSION (08/24) : l'inverse — 1 os rend les 4 os du palier inférieur, pour
-- la MOITIÉ du prix de la fusion qu'elle défait (même règle que les cristaux).
-- Retourne { from = os à scinder, to = os rendu, count, cost } ou nil.
function EVO_CRAFT.BoneUnfusionFor(sFrom)
	for _, f in ipairs(EVO_CRAFT.BoneFusion) do
		if f.to == sFrom then
			return { from = f.to, to = f.from, count = f.count, cost = math.floor(f.cost / 2) }
		end
	end
	return nil
end

-- Compte les exemplaires d'un item dans le sac, piles comprises.
-- Client : cache LIVE (CountInventoryItem) — GetInventory() est une copie,
-- ne pas s'en servir pour compter. Serveur : ply.inventory.
function EVO_CRAFT.CountBagItem(inv, sId)
	if not isstring(sId) or sId == "" then return 0 end
	if CLIENT then
		local lp = LocalPlayer()
		if IsValid(lp) and lp.CountInventoryItem then
			return lp:CountInventoryItem(sId)
		end
	end
	if istable(inv) and INVENTORY_CONFIG and INVENTORY_CONFIG.CountBagItem and istable(inv.items) then
		return INVENTORY_CONFIG.CountBagItem(inv, sId)
	end
	if not istable(inv) then return 0 end
	local tItems = istable(inv.items) and inv.items or inv
	local n = 0
	for _, v in pairs(tItems) do
		if v == sId then n = n + 1 end
	end
	return n
end

-- Nom d'affichage d'une ressource : registre local d'abord, ITEMS ensuite,
-- repli = id SANS underscores (règle projet : jamais d'id brut à l'écran).
-- Resolver UNIQUE : notifs serveur, panneau atelier et onglet OS de la forge.
function EVO_CRAFT.ResourceName(sId)
	local r = EVO_CRAFT.Resources[sId]
	if r then return r.name end
	local it = ITEMS and ITEMS[sId]
	if it and it.name then return it.name end
	return (tostring(sId or "?"):gsub("_", " "))
end

-- Boucle de retry PARTAGÉE (1 s × 30 essais, échec LOGGÉ) : l'addon inventory
-- réassigne ITEMS à son include et evo_science se charge après evo_craft, tout
-- enregistrement inter-addon d'evo_craft passe par ici.
function EVO_CRAFT.Retry(sTimerName, fnTry, sFailLog)
	local nTry = 0
	timer.Create(sTimerName, 1, 30, function()
		nTry = nTry + 1
		if fnTry() then
			timer.Remove(sTimerName)
		elseif nTry >= 30 then
			print(sFailLog)
		end
	end)
end

-- ── Enregistrement dans ITEMS (retry, échec loggé : recette assassin gear) ──
local function registerResourceItems()
	if not istable(ITEMS) then return false end
	for id, r in pairs(EVO_CRAFT.Resources) do
		if not ITEMS[id] then
			ITEMS[id] = {
				name = r.name,
				description = r.desc,
				category = "object",
				rarity = r.rarity,
				model_path = r.model,
				is_droppable = true,
				is_deletable = true,
				stack_max = r.stack_max,
			}
		end
	end
	return true
end

EVO_CRAFT.Retry("EVO_Craft::ResourceItems", registerResourceItems,
	"[evo_craft] ITEMS indisponible apres 30 essais : ressources non enregistrees dans l'inventaire (verifier l'addon inventory).")
