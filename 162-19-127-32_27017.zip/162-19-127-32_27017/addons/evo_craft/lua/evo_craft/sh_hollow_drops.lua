-- "addons\\evo_craft\\lua\\evo_craft\\sh_hollow_drops.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- DROPS HOLLOW (user 08/24) : deux objets qui ne tombent QUE sur les Hollows
-- (classes ncm_pnj_hollow_*), utilisables depuis l'inventaire (clic droit >
-- Utiliser) pour ouvrir un Garganta devant soi.
--   • Pièce blanche (5 %)  -> Garganta, 3 Hollows (tirage de chasse normal).
--   • Cube blanc  (0,5 %)  -> Garganta, 1 à 3 Menos Grande (classe forcée).
--   • Pièce dorée (1 %)    -> Garganta, 1 BOSS du pool de chasse (Serpent, Grand
--                             Fisher ou Menos Grande, tiré au hasard).
-- Modèles = appâts dédiés du modélisateur (08/28) : « appât pièce » pour les deux
-- pièces, « appât cube » pour le cube. Même retry ITEMS que les ressources
-- (l'addon inventory réassigne ITEMS à son include).
-- ============================================================================
EVO_CRAFT = EVO_CRAFT or {}

-- Taux ACTIVÉS le 08/27 (user) : cube 0,5 / pièce dorée 1 / pièce blanche 5 (% par
-- kill de Hollow). Tirage en cascade du plus rare au plus courant, un seul drop max
-- par kill. Remettre pct = 0 pour couper un drop sans retirer l'objet.
EVO_CRAFT.HollowDrops = {
	{ id = "hollow_cube_blanc",    pct = 0.5 },
	{ id = "hollow_piece_doree",   pct = 1 },
	{ id = "hollow_piece_blanche", pct = 5 },
}

EVO_CRAFT.HollowDropItems = {
	hollow_piece_blanche = {
		name = "Pièce blanche", rarity = "rare",
		model = "models/evo/props/items/evo_ezd9pomlikj/evo_ezd9pomlikj.mdl",
		desc = "Petite pièce d'un blanc laiteux, encore tiède du reiatsu d'un Hollow. Clic droit > Utiliser : ouvre un Garganta devant toi, d'où sortent trois Hollows.",
		stack_max = 16,
		count = 3,
		me = "utilise une pièce blanche",
	},
	hollow_cube_blanc = {
		name = "Cube blanc", rarity = "legendary",
		model = "models/evo/props/items/evo_967grzgrtpolkiuhow/evo_967grZGRTpolkiuhow.mdl",
		desc = "Cube parfaitement lisse, d'un blanc qui absorbe la lumière. Clic droit > Utiliser : ouvre un Garganta devant toi, d'où sortent un à trois Menos Grande.",
		stack_max = 8,
		me = "utilise un cube blanc",
		count = { 1, 3 }, forceClass = "ncm_pnj_hollow_menos",
	},
	hollow_piece_doree = {
		name = "Pièce dorée", rarity = "epic",
		model = "models/evo/props/items/evo_ezd9pomlikj/evo_ezd9pomlikj.mdl", -- meme appat piece que la blanche (pas de modele dore fourni)
		desc = "Pièce d'or gravée d'un masque de Hollow, lourde d'un reiatsu ancien. Clic droit > Utiliser : ouvre un Garganta devant toi, d'où sort un boss.",
		stack_max = 8,
		me = "utilise une pièce dorée",
		-- forceClass en LISTE = tirage au hasard à l'utilisation (pool de boss de la chasse).
		count = 1, forceClass = { "ncm_pnj_hollow_serpent", "ncm_pnj_hollow_grandfisher", "ncm_pnj_hollow_menos" },
	},
}

-- Appâts assignables au CONSOMMABLE RAPIDE (petit slot de la spell bar / radial,
-- demande user 2026-09-18 : pièce blanche, pièce dorée, cube blanc). Source UNIQUE
-- lue par INVENTORY_CONFIG.IsQuickConsumable, même forme que les prédicats d'evo_science.
-- Indexé sur HollowDropItems (les OBJETS) et pas sur HollowDrops (les TAUX de drop) :
-- mettre un pct à 0 coupe le drop sans retirer l'appât de la roue, ce que le commentaire
-- des taux ci-dessus annonce explicitement.
function EVO_CRAFT.IsHollowBait(sItemId)
	return istable(EVO_CRAFT.HollowDropItems) and EVO_CRAFT.HollowDropItems[sItemId] ~= nil
end

-- Cubes posés via !config_positions (provider no_npc_item_zones). AABB brute :
-- la boîte dessinée est la boîte qui bloque, sans bande de sol.
EVO_CRAFT.NoNpcZones = EVO_CRAFT.NoNpcZones or {}

local function rangesOverlap(a0, a1, b0, b1)
	return math.min(a0, a1) <= math.max(b0, b1) and math.max(a0, a1) >= math.min(b0, b1)
end

function EVO_CRAFT.PosInNoNpcZone(pos)
	if not isvector(pos) then return false end
	local list = EVO_CRAFT.NoNpcZones[game.GetMap()]
	if not istable(list) then return false end
	for _, z in ipairs(list) do
		local mins, maxs = z.mins, z.maxs
		if isvector(mins) and isvector(maxs)
			and pos.x >= math.min(mins.x, maxs.x) and pos.x <= math.max(mins.x, maxs.x)
			and pos.y >= math.min(mins.y, maxs.y) and pos.y <= math.max(mins.y, maxs.y)
			and pos.z >= math.min(mins.z, maxs.z) and pos.z <= math.max(mins.z, maxs.z) then
			return true
		end
	end
	return false
end

-- Le gizmo peut croiser les coins : la boîte dessinée reste bonne, un test
-- « pos >= mins et pos <= maxs » non. On compare le volume du joueur à ce volume.
function EVO_CRAFT.PlayerInNoNpcZone(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	local list = EVO_CRAFT.NoNpcZones[game.GetMap()]
	if not istable(list) then return false end
	local pos = ply:GetPos()
	local hMin, hMax = ply:GetHull()
	if not (isvector(hMin) and isvector(hMax)) then
		hMin, hMax = Vector(-16, -16, 0), Vector(16, 16, 72)
	end
	local pMin, pMax = pos + hMin, pos + hMax
	for _, z in ipairs(list) do
		local mins, maxs = z.mins, z.maxs
		if isvector(mins) and isvector(maxs)
			and rangesOverlap(pMin.x, pMax.x, mins.x, maxs.x)
			and rangesOverlap(pMin.y, pMax.y, mins.y, maxs.y)
			and rangesOverlap(pMin.z, pMax.z, mins.z, maxs.z) then
			return true
		end
	end
	return false
end

-- XP des Hollows d'appât (user 08/30 : « augmente pas mal l'exp ») : cagnotte de kill
-- multipliée par ce facteur (base 20 x palier x ça). Ils ne subissent PLUS le plafond
-- animateur de 5 XP (z.baitEvent, cf. sv_pnj_world_hunt) : un grunt normal passe de
-- 5 à ~50 XP, un Menos/boss à ~65+.
EVO_CRAFT.HollowDropXPMult = 2.5

local GARGANTA_DIST = 350 -- unités devant le joueur
local USE_COOLDOWN  = 15  -- s entre deux ouvertures par joueur (anti-spam de pièces)

local function useDrop(ply, slot, sId)
	if not (SERVER and IsValid(ply) and ply:IsPlayer()) then return end
	local d = EVO_CRAFT.HollowDropItems[sId]
	if not d then return end
	if not (NCM_PNJ and NCM_PNJ.SpawnHuntGargantaEvent) then return end
	-- Avant le cooldown et RemoveItem : l'appât reste dans le sac.
	if EVO_CRAFT.PlayerInNoNpcZone(ply) then
		if ply.rpNotify then ply:rpNotify("Impossible d'ouvrir un Garganta ici.", 1, 4) end
		return
	end
	if (ply._EvoHollowDropNext or 0) > CurTime() then
		if ply.rpNotify then ply:rpNotify("Un Garganta vient de s'ouvrir, attends un peu.", 1, 4) end
		return
	end
	ply._EvoHollowDropNext = CurTime() + USE_COOLDOWN

	-- Consommer D'ABORD (anti-dupe), ouvrir ENSUITE ; si l'ouverture est refusée
	-- (arène de Bataille, hors map) l'objet est rendu.
	ply:RemoveItem(sId, function(ok)
		if not IsValid(ply) then return end
		if ok == false then return end
		local nCount = istable(d.count) and math.random(d.count[1], d.count[2]) or d.count
		local sClass = istable(d.forceClass) and d.forceClass[math.random(#d.forceClass)] or d.forceClass
		local vPos = ply:GetPos() + Angle(0, ply:EyeAngles().y, 0):Forward() * GARGANTA_DIST
		local z = NCM_PNJ.SpawnHuntGargantaEvent(vPos, nil, nCount, false, ply, sClass)
		if z then
			-- Posé sur le z renvoyé AVANT que les spawns différés partent : XP pleine
			-- (pas le plafond animateur) et boostée, drops toujours coupés.
			z.baitEvent = true
			z.xpMult = EVO_CRAFT.HollowDropXPMult
		end
		if not z then
			ply._EvoHollowDropNext = 0
			ply:GiveItem(sId)
			if ply.rpNotify then ply:rpNotify("Impossible d'ouvrir un Garganta ici.", 1, 4) end
			return
		end
		if ply.rpNotify then ply:rpNotify("Le Garganta s'ouvre devant toi…", 0, 4) end
		-- /me de PROXIMITÉ (demande user 09/01) : convention projet = 500 u, jamais
		-- net.Broadcast (sinon les 128 joueurs du serveur le lisent). Émis seulement
		-- APRÈS l'ouverture réussie : un Garganta refusé rendait l'objet, le /me
		-- aurait menti.
		if d.me and util.NetworkStringToID("LZY:ReceiveMeChat") ~= 0 then
			local vPos = ply:GetPos()
			for _, rcp in player.Iterator() do
				if IsValid(rcp) and rcp:GetPos():DistToSqr(vPos) <= (500 * 500) then
					net.Start("LZY:ReceiveMeChat") -- netgate: edge -- un seul envoi par usage d'appât
						net.WriteEntity(ply)
						net.WriteString(d.me)
						net.WriteBool(not ply:Alive())
					net.Send(rcp)
				end
			end
		end
		if EVO_StaffLog then EVO_StaffLog(ply, "hollow_drop.use", nil, sId .. " x" .. nCount) end
	end, nil, slot, 1)
end

local function registerHollowDropItems()
	if not istable(ITEMS) then return false end
	for id, r in pairs(EVO_CRAFT.HollowDropItems) do
		if not ITEMS[id] then
			ITEMS[id] = {
				name = r.name,
				description = r.desc,
				category = "object",
				rarity = r.rarity,
				model_path = r.model,
				is_droppable = true,
				is_deletable = true,
				stack_max = r.stack_max,
				-- on_use doit exister côté CLIENT pour proposer « Utiliser » ; l'action
				-- réelle est SERVEUR (net server:inventory.UseItem -> on_use(ply, slot)).
				on_use = SERVER and function(ply, slot) useDrop(ply, slot, id) end or function() end,
			}
		end
	end
	return true
end

EVO_CRAFT.Retry("EVO_Craft::HollowDropItems", registerHollowDropItems,
	"[evo_craft] ITEMS indisponible apres 30 essais : drops Hollow non enregistres (verifier l'addon inventory).")

if not SERVER then return end

-- Tirages INDÉPENDANTS (un cube ET une pièce peuvent tomber sur le même kill),
-- pas de multiplicateur boss/mutation : les taux sont ceux demandés, point.
-- Mêmes filtres anti-farm que les os (quête, bots, events animateur, clones, pets).
hook.Add("NCM_PNJ::Killed", "EVO_Craft::HollowDrop", function(attacker, npc)
	if not (IsValid(npc) and IsValid(attacker) and attacker:IsPlayer()) then return end
	if attacker.CanHarvestResources and not attacker:CanHarvestResources() then return end
	local sClass = npc:GetClass()
	if not string.find(sClass, "^ncm_pnj_hollow") then return end
	if not (NCM_PNJ and NCM_PNJ.Config and NCM_PNJ.Config[sClass]) then return end
	if npc._ncmQuestNPC or npc._isTrainingBot or npc._ncmAnimEvent or npc._ncmBaitEvent or npc._ncmCloneOwner then return end
	if IsValid(npc._aizenPetOwner) then return end

	for _, d in ipairs(EVO_CRAFT.HollowDrops) do
		if math.Rand(0, 100) < d.pct then
			local sName = EVO_CRAFT.ResourceName(d.id)
			attacker:GiveItem(d.id, function(ok)
				if not IsValid(attacker) then return end
				if ok == false then
					if attacker.rpNotify then attacker:rpNotify("Inventaire plein : " .. sName .. " perdu(e).", 1, 4) end
					return
				end
				if attacker.rpNotify then attacker:rpNotify("Trouvé sur le Hollow : " .. sName .. " !", 0, 5) end
			end)
		end
	end
end)
