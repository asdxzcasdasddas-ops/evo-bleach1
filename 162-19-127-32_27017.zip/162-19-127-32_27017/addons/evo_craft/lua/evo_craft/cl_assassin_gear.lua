-- "addons\\evo_craft\\lua\\evo_craft\\cl_assassin_gear.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Visée en DEUX TEMPS de l'équipement assassin (client) : au 1er usage le
-- serveur active la preview (net AssassinAim), au 2e il exécute et la coupe.
-- Pièges : zone de pose au sol (VERTE = valide, rouge = refusée), mêmes règles
-- que le serveur (trace caméra 500 u, portée 160 u du joueur, sol franc).
-- Grenades : trajectoire simulée AVEC LA CHUTE (mêmes constantes que le jet
-- serveur, drag coupé sur l'entité) + cercle d'effet au point d'impact.
--
-- PERF (retour user 08/18 « la preview lag ») : tout est recalculé PAR FRAME
-- pour coller à la vue en mouvement, en ZÉRO alloc : la balistique s'intègre en
-- SCALAIRES dans des Vector préalloués mutés (SetUnpacked), les traces passent
-- par des tables d'entrée/sortie RÉUTILISÉES. Seul le balayage de COLLISION de
-- l'arc (les traces segment par segment) reste throttlé à 30 Hz : entre deux
-- balayages, l'index d'impact caché borne l'arc de la frame courante.

local AIM = nil -- { g = entrée du catalogue, untilT = expiration, vA = 1er piquet (fil) }
local COL_OK  = Color(110, 230, 140)
local COL_BAD = Color(230, 90, 80)

-- Piquet A d'un piège à FIL : montré en VRAI modèle dès qu'il est planté
-- (user 08/19 : « le premier que tu mets, tu dois le voir »).
local mFilA
local function setFilAModel(vA)
	if not vA then
		if IsValid(mFilA) then mFilA:Remove() end
		mFilA = nil
		return
	end
	if not IsValid(mFilA) then
		local sMdl = EVO_CRAFT.AssassinModels and EVO_CRAFT.AssassinModels.fil
		if not sMdl then return end
		mFilA = ClientsideModel(sMdl, RENDERGROUP_OPAQUE)
	end
	if IsValid(mFilA) then
		mFilA:SetPos(vA)
		mFilA:SetAngles(angle_zero)
	end
end

net.Receive("EVO_Craft:AssassinAim", function()
	if not net.ReadBool() then
		AIM = nil
		setFilAModel(nil)
		return
	end
	local g = EVO_CRAFT.AssassinGearByKey(net.ReadString())
	local vA = net.ReadBool() and net.ReadVector() or nil
	if not g then return end
	AIM = { g = g, untilT = CurTime() + (EVO_CRAFT.AssassinCfg.AimWindow or 8), vA = vA }
	setFilAModel(vA)
end)

-- Vue RÉELLE (cam orbitale incluse) : la même source que la sonde serveur.
local function viewPos(lp)
	if CitronOrbitCam and CitronOrbitCam.GetView then
		local p, a = CitronOrbitCam.GetView()
		if p then return p, a:Forward() end
	end
	return lp:EyePos(), lp:GetAimVector()
end

local TUNE = { bombe = "Bombe", toxique = "Toxique", fumigene = "Fumigene",
	glace = "Glace", feu = "Feu", magique = "Magique" }

-- Traces sans alloc par frame : entrées et sorties réutilisées.
local TR_OUT  = {}
local TR_AIM  = { mask = MASK_SOLID, output = TR_OUT }
local TR_OUT2 = {}
local TR_SOL  = { mask = MASK_SOLID_BRUSHONLY, output = TR_OUT2 }

-- ── Piège : ancre + validité, PAR FRAME (2 traces, vecteurs scratch) ─────────
local vTrapAnchor = Vector(0, 0, 0)
local vScratchA, vScratchB = Vector(0, 0, 0), Vector(0, 0, 0)
local function computeTrap(lp)
	local vFrom, vDir = viewPos(lp)
	vScratchA:Set(vDir) vScratchA:Mul(500) vScratchA:Add(vFrom)
	TR_AIM.start, TR_AIM.endpos, TR_AIM.filter = vFrom, vScratchA, lp
	util.TraceLine(TR_AIM)
	local vBase = TR_OUT.Hit and TR_OUT.HitPos or vScratchA
	local bOk = vBase:Distance(lp:GetPos()) <= 160
	vScratchA:Set(vBase) vScratchA.z = vScratchA.z + 24
	vScratchB:Set(vBase) vScratchB.z = vScratchB.z - 160
	TR_SOL.start, TR_SOL.endpos, TR_SOL.filter = vScratchA, vScratchB, lp
	util.TraceLine(TR_SOL)
	if TR_OUT2.Hit and TR_OUT2.HitNormal.z >= 0.72 then
		vTrapAnchor:Set(TR_OUT2.HitPos)
	else
		vTrapAnchor:Set(vBase)
		bOk = false
	end
	return bOk
end

-- ── Grenade : arc PAR FRAME en scalaires (préalloué), collision à 30 Hz ──────
local SIM_N, SIM_DT = 60, 0.05
local PTS = {}
for i = 1, SIM_N + 1 do PTS[i] = Vector(0, 0, 0) end
local nPts = 0          -- points calculés cette frame (borné par l'impact caché)
local nHitIdx = SIM_N   -- index d'impact du dernier balayage tracé
local nHitFrac = 1      -- fraction le long du segment d'impact
local bHit = false
local vEnd = Vector(0, 0, 0)
local nSweepNext = 0

local function computeArc(lp)
	local vEye = lp:EyePos()
	local _, vDir = viewPos(lp)
	local vVel = lp:GetVelocity()
	-- Mêmes constantes que throwGrenade (sv_craft_assassin).
	local px, py, pz = vEye.x + vDir.x * 20, vEye.y + vDir.y * 20, vEye.z + vDir.z * 20
	local vx = vDir.x * 880 + vVel.x * 0.5
	local vy = vDir.y * 880 + vVel.y * 0.5
	local vz = vDir.z * 880 + vVel.z * 0.5 + 110
	local grav = GetConVar("sv_gravity"):GetFloat()

	PTS[1]:SetUnpacked(px, py, pz)
	local nMax = math.min(SIM_N, nHitIdx + 2) -- pas la peine de calculer après l'impact
	for i = 2, nMax + 1 do
		vz = vz - grav * SIM_DT
		px = px + vx * SIM_DT
		py = py + vy * SIM_DT
		pz = pz + vz * SIM_DT
		PTS[i]:SetUnpacked(px, py, pz)
	end
	nPts = nMax + 1

	-- Balayage de collision (30 Hz) : cherche le segment d'impact sur les
	-- points de CETTE frame, mémorise index + fraction pour les suivantes.
	if RealTime() >= nSweepNext then
		nSweepNext = RealTime() + 0.033
		bHit, nHitIdx, nHitFrac = false, SIM_N, 1
		for i = 1, nPts - 1 do
			TR_AIM.start, TR_AIM.endpos, TR_AIM.filter = PTS[i], PTS[i + 1], lp
			util.TraceLine(TR_AIM)
			if TR_OUT.Hit then
				bHit, nHitIdx, nHitFrac = true, i, TR_OUT.Fraction
				break
			end
		end
	end

	-- Point d'impact de la frame COURANTE : interpolation sur l'index caché.
	if bHit and nHitIdx < nPts then
		local a, b = PTS[nHitIdx], PTS[math.min(nHitIdx + 1, nPts)]
		vEnd:SetUnpacked(
			a.x + (b.x - a.x) * nHitFrac,
			a.y + (b.y - a.y) * nHitFrac,
			a.z + (b.z - a.z) * nHitFrac)
		nPts = nHitIdx + 1
	end
end

-- ── Rendu monde ──────────────────────────────────────────────────────────────
hook.Add("PostDrawTranslucentRenderables", "EVO_Craft::AssassinAim", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not AIM then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() or CurTime() > AIM.untilT then
		AIM = nil
		setFilAModel(nil)
		return
	end
	local g = AIM.g
	local pulse = 170 + math.sin(RealTime() * 4) * 60

	-- Overlay de VISÉE dessiné PAR-DESSUS le monde (retour user 08/19 : les
	-- zones passaient DERRIÈRE les props/murs et devenaient invisibles). Guide
	-- local et éphémère : le voir au travers d'un obstacle est voulu.
	cam.IgnoreZ(true)
	if g.kind == "piege" then
		local C = EVO_CRAFT.AssassinCfg
		local bOk = computeTrap(lp)
		-- FIL avec 1er piquet posé : la validité inclut la longueur du fil.
		local nLen = (g.gtype == "fil" and AIM.vA) and AIM.vA:Distance(vTrapAnchor) or 0
		if g.gtype == "fil" and AIM.vA and (nLen > C.Fil.maxLen or nLen < 48) then bOk = false end
		local col = bOk and COL_OK or COL_BAD
		local nR = g.gtype == "ours" and C.Ours.radius
			or (g.gtype == "fil" and C.Fil.trigDist or C.Pics.radius)
		vScratchA:Set(vTrapAnchor) vScratchA.z = vScratchA.z + 2
		cam.Start3D2D(vScratchA, angle_zero, 1)
			surface.DrawCircle(0, 0, nR, col.r, col.g, col.b, pulse)
			surface.DrawCircle(0, 0, nR - 3, col.r, col.g, col.b, pulse * 0.55)
			surface.DrawCircle(0, 0, nR * 0.3, col.r, col.g, col.b, pulse * 0.7)
		cam.End3D2D()
		-- Aperçu du FIL : piquet A marqué + fil tendu jusqu'au point visé.
		if g.gtype == "fil" and AIM.vA then
			-- Le fil S'ÉTIRE littéralement du piquet A au curseur, VERT dans les
			-- limites / ROUGE au-delà, distance affichée au milieu (user 08/19).
			vScratchB:Set(AIM.vA) vScratchB.z = vScratchB.z + 2
			cam.Start3D2D(vScratchB, angle_zero, 1)
				surface.DrawCircle(0, 0, 12, col.r, col.g, col.b, pulse)
			cam.End3D2D()
			render.SetColorMaterial()
			vScratchB:Set(AIM.vA) vScratchB.z = vScratchB.z + (C.Fil.wireH or 12)
			vScratchA:Set(vTrapAnchor) vScratchA.z = vScratchA.z + (C.Fil.wireH or 12)
			render.DrawBeam(vScratchB, vScratchA, 3, 0, 1, col)
			vScratchB:Add(vScratchA) vScratchB:Mul(0.5) vScratchB.z = vScratchB.z + 14
			local aFace = (EyePos() - vScratchB):Angle()
			cam.Start3D2D(vScratchB, Angle(0, aFace.y + 90, 90), 0.24)
				draw.SimpleText(string.format("%d / %d", math.ceil(nLen), C.Fil.maxLen),
					"EVOCraft_ZoneS", 0, 0, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cam.End3D2D()
		end
	else
		computeArc(lp)
		render.SetColorMaterial()
		for i = 2, nPts, 2 do
			render.DrawSphere(PTS[i], 2.4, 8, 8, COL_OK)
		end
		if bHit then
			local T = EVO_CRAFT.AssassinCfg[TUNE[g.gtype] or ""]
			local nR = (T and T.radius) or 120
			vScratchA:Set(vEnd) vScratchA.z = vScratchA.z + 2
			cam.Start3D2D(vScratchA, angle_zero, 1)
				surface.DrawCircle(0, 0, nR, COL_OK.r, COL_OK.g, COL_OK.b, pulse)
				surface.DrawCircle(0, 0, nR * 0.35, COL_OK.r, COL_OK.g, COL_OK.b, pulse * 0.6)
			cam.End3D2D()
		end
	end
	cam.IgnoreZ(false)
end)

-- ── Rappel à l'écran (au-dessus du prompt de récolte, même famille visuelle) ─
hook.Add("HUDPaint", "EVO_Craft::AssassinAimHint", function()
	if not AIM then return end
	if vgui.CursorVisible() then return end
	local sName = AIM.g.name or "?"
	draw.SimpleTextOutlined(sName .. " : réutilise l'objet pour " .. (AIM.g.kind == "piege" and "poser" or "lancer"),
		"EVOCraftRes_Sub", ScrW() * 0.5, ScrH() * 0.7,
		Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 190))
end)

-- ── « [E] Récupérer » au-dessus d'un de SES pièges posés (user 08/19) : même
-- famille visuelle que le prompt des nœuds de ressources (cl_resources, dont
-- les fontes EVOCraftRes_* sont déjà créées). Proximité + visée par CÔNE : les
-- pièges sont en COLLISION_GROUP_PASSABLE_DOOR, un eye trace les traverse.
local TRAP_NAME = {
	evo_piege_ours = "Piège à ours",
	evo_piege_pics = "Piège à pics",
	evo_piege_fil  = "Piège à fil",
}
local COL_TRAP_ACCENT = Color(216, 185, 106)

-- Scan throttlé ~7 Hz (même patron que ResPrompt/HarvestPrompt) : c'était le
-- DERNIER prompt à scanner chaque frame — FindInSphere + un GetNormalized (qui
-- alloue un Vector) par piège, 60 fois par seconde pour une réponse qui ne
-- change pas à la frame près.
local _trapBest, _trapNextScan = nil, 0
local function findTrap(lp)
	if CurTime() < _trapNextScan then return _trapBest end
	_trapNextScan = CurTime() + 0.15
	_trapBest = nil
	local vEye, vAim = lp:EyePos(), lp:GetAimVector()
	local bestDot
	for _, e in ipairs(ents.FindInSphere(lp:GetPos(), 130)) do
		if TRAP_NAME[e:GetClass()]
			and (not e.GetSprung or not e:GetSprung())
			and e.GetThrower and e:GetThrower() == lp then
			local nDot = (e:WorldSpaceCenter() - vEye):GetNormalized():Dot(vAim)
			if nDot > 0.92 and (not bestDot or nDot > bestDot) then
				_trapBest, bestDot = e, nDot
			end
		end
	end
	return _trapBest
end

hook.Add("HUDPaint", "EVO_Craft::TrapPickupPrompt", function()
	if vgui.CursorVisible() then return end
	-- Pas de prompt pendant qu'on mange/boit (prédicat central evo_science).
	if EVO_SCIENCE and EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end

	local best = findTrap(lp)
	if not IsValid(best) then return end

	-- Sur le fil, [E] n'est plus un ramassage sec : il ouvre le menu (monter une
	-- grenade / la retirer / récupérer). Le libellé doit le dire, sinon on croit
	-- perdre son piège en appuyant.
	local bFil = best:GetClass() == "evo_piege_fil"
	local sName = TRAP_NAME[best:GetClass()] or "Piège"
	local bGren = bFil and best.GetGrenadeType and best:GetGrenadeType() ~= ""
	local cx, cy = ScrW() * 0.5, ScrH() * 0.74
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(cx, cy, sName, bFil and "Menu du piège" or "Récupérer", "E", nil,
			bGren and "grenade montée" or nil)
		return
	end
	local txt = bFil and "[E] Menu du piège" or "[E] Récupérer"
	local sub = bGren and (sName .. " · grenade montée") or sName
	surface.SetFont("EVOCraftRes_Prompt")
	local tw, th = surface.GetTextSize(txt)
	surface.SetFont("EVOCraftRes_Sub")
	local sw = surface.GetTextSize(sub)
	local boxW = math.max(tw, sw) + 40
	local boxH = th + 16 + 26

	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(13, 14, 17, 220), 8, "br")
	else
		draw.RoundedBox(0, cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(0, 0, 0, 180))
	end
	surface.SetDrawColor(COL_TRAP_ACCENT)
	surface.DrawRect(cx - boxW * 0.5, cy - boxH * 0.5, 2, boxH)
	draw.SimpleText(txt, "EVOCraftRes_Prompt", cx, cy - 8, Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sub, "EVOCraftRes_Sub", cx, cy + th * 0.5 + 2, COL_TRAP_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- ═══ MENU RADIAL DU PIÈGE À FIL (user 08/23) ════════════════════════════════
-- [E] sur SON fil ouvre ce menu : monter une grenade du sac, la retirer, ou
-- récupérer le piège. Le serveur envoie la liste (il connaît le sac), le client
-- ne renvoie qu'une INTENTION — tout est revalidé côté serveur.
surface.CreateFont("EVOFilRadial",     { font = "Roboto", size = 19, weight = 600, antialias = true })
surface.CreateFont("EVOFilRadialTtl",  { font = "Roboto", size = 26, weight = 700, antialias = true })

local COL_FIL_ACC  = Color(255, 165, 60)
local COL_FIL_BG   = Color(13, 14, 17, 235)
local COL_FIL_TXT  = Color(232, 232, 238)
local COL_FIL_DIM  = Color(150, 152, 158)

local function filSend(fil, sAct, sGren)
	if not IsValid(fil) then return end
	net.Start("EVO_Craft:FilAction")
		net.WriteEntity(fil)
		net.WriteString(sAct)
		net.WriteString(sGren or "")
	net.SendToServer()
end

local pFilRadial
local function OpenFilRadial(fil, sMounted, tGren)
	if IsValid(pFilRadial) then pFilRadial:Remove() end

	-- Une entrée = { label, act, gren, col }. Ordre : les grenades, puis les
	-- actions sur le piège lui-même (toujours en dernier, place stable).
	local tOpts = {}
	if sMounted == "" then
		for _, g in ipairs(tGren) do
			tOpts[#tOpts + 1] = { label = g.name, act = "mount", gren = g.key, col = COL_FIL_ACC }
		end
		if #tGren == 0 then
			tOpts[#tOpts + 1] = { label = "Aucune grenade dans ton sac", act = "", col = COL_FIL_DIM }
		end
	else
		tOpts[#tOpts + 1] = { label = "Retirer la grenade", act = "unmount", col = COL_FIL_ACC }
	end
	tOpts[#tOpts + 1] = { label = "Récupérer le piège", act = "pickup", col = Color(200, 205, 215) }

	local frame = vgui.Create("DFrame")
	pFilRadial = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end -- APRÈS MakePopup

	local S = function(v) return math.Round(v * (ScrH() / 1080)) end
	local RADIUS, BTN_W, BTN_H = S(190), S(230), S(46)
	local tHover = {}
	for i = 1, #tOpts do tHover[i] = 0 end

	frame.Paint = function(_, w, h)
		-- Le fil disparaît (déclenché, ramassé, expiré) : on referme, sinon on
		-- garderait un menu qui agit sur une entité morte.
		if not IsValid(fil) or fil:GetSprung() then frame:Remove() return end

		local cx, cy = w * 0.5, h * 0.5
		surface.SetDrawColor(0, 0, 0, 110)
		surface.DrawRect(0, 0, w, h)

		draw.SimpleText("PIÈGE À FIL", "EVOFilRadialTtl", cx, cy - S(24),
			COL_FIL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sMounted ~= "" and "Une grenade est montée" or "Choisis une grenade à monter",
			"EVOFilRadial", cx, cy + S(8), COL_FIL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		local mx, my = gui.MouseX(), gui.MouseY()
		local ft = FrameTime()
		for i, o in ipairs(tOpts) do
			-- Réparties sur le cercle, départ en haut, sens horaire.
			local a  = math.rad((i - 1) / #tOpts * 360 - 90)
			local bx = cx + math.cos(a) * RADIUS
			local by = cy + math.sin(a) * RADIUS
			local x0, y0 = bx - BTN_W * 0.5, by - BTN_H * 0.5
			local bOn = mx >= x0 and mx <= x0 + BTN_W and my >= y0 and my <= y0 + BTN_H
			tHover[i] = math.Clamp(tHover[i] + (bOn and ft * 6 or -ft * 6), 0, 1)
			o._hit = bOn

			local col = o.col or COL_FIL_TXT
			draw.RoundedBox(S(8), x0, y0, BTN_W, BTN_H,
				Color(COL_FIL_BG.r, COL_FIL_BG.g, COL_FIL_BG.b, 200 + 55 * tHover[i]))
			surface.SetDrawColor(col.r, col.g, col.b, 90 + 165 * tHover[i])
			surface.DrawOutlinedRect(x0, y0, BTN_W, BTN_H, math.max(1, S(2)))
			draw.SimpleText(o.label, "EVOFilRadial", bx, by,
				o.act == "" and COL_FIL_DIM or col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	frame.OnMousePressed = function(_, code)
		if code ~= MOUSE_LEFT then frame:Remove() return end
		for _, o in ipairs(tOpts) do
			if o._hit and o.act ~= "" then
				filSend(fil, o.act, o.gren)
				if NCM_UISounds and NCM_UISounds.Click then NCM_UISounds.Click() end
				break
			end
		end
		frame:Remove()
	end
end

net.Receive("EVO_Craft:FilRadial", function()
	local fil      = net.ReadEntity()
	local sMounted = net.ReadString()
	local n        = net.ReadUInt(4)
	local tGren    = {}
	for i = 1, n do
		tGren[i] = { key = net.ReadString(), name = net.ReadString() }
	end
	if IsValid(fil) then OpenFilRadial(fil, sMounted, tGren) end
end)
