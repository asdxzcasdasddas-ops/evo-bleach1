-- "addons\\evo_craft\\lua\\evo_craft\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Ateliers de craft, côté client : plaque EVO_ZonePrompt face au joueur +
-- touche E (recette cachot, plus de cercle au sol — user 08/24).
-- Menu PLEIN ÉCRAN refait 08/18 au look « DHTML » DA (VGUI + RNDX PUR, jamais de
-- Chromium — cf. règle projet) : cartes sombres arrondies SANS bordure, accent
-- #cf444e, grosses fontes, micro-animations Lua (lerp/sin, zéro alloc par frame).

local CFG = EVO_CRAFT.CFG

-- EVOCraft_ZoneS sert encore au décor du gear assassin (cl_assassin_gear).
surface.CreateFont("EVOCraft_ZoneS", { font = "Bebas Neue", size = 36, weight = 600 })

local COL_GOLD = Color(216, 185, 106)

-- ============================================================================
-- MARQUEURS DE ZONE : visibles par tout le monde ; la plaque précise si
-- l'atelier nous est accessible (résolution de division partagée). Atelier
-- verrouillé = pas de keycap, juste le motif du refus (sKey = "").
-- ============================================================================
hook.Add("PostDrawTranslucentRenderables", "EVO_Craft::ZoneMarkers", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local zones = EVO_CRAFT.StationList()
	if #zones == 0 then return end

	local eye = EyePos()
	for _, st in ipairs(zones) do
		if eye:DistToSqr(EVO_CRAFT.StationZonePos(st)) < (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then
			-- La plaque vit sur la ZONE (zonePos), le modèle reste sur pos.
			local gpos = EVO_CRAFT.StationZoneAnchor(st)
			local sDeny = EVO_CRAFT.StationDenyReason(lp, st)
			local sLine, sKey = "Crafter", "E"
			if sDeny == "division" then
				sLine, sKey = "Réservé : " .. EVO_CRAFT.DivisionName(st.role, lp), ""
			elseif sDeny == "rank" then
				sLine, sKey = "Accessible au grade " .. (CFG.MinRank or 2), ""
			end
			EVO_ZonePrompt.Draw(gpos, "ATELIER " .. EVO_CRAFT.RoleLabel(st.role), sLine, nil, sKey)
		end
	end
end)

-- ============================================================================
-- TOKENS DA (clean base : carte sombre arrondie SANS bordure, accent rouge).
-- ============================================================================
local COL_DIMBG   = Color(4, 4, 8, 208)      -- voile plein écran (couche PLATE)
local COL_CARD    = Color(14, 14, 17, 250)   -- carte principale
local COL_SUB     = Color(20, 20, 24, 255)   -- sous-panneau / rangée
local COL_SUB_HI  = Color(27, 27, 33, 255)   -- rangée survolée
local COL_ACCENT  = Color(207, 68, 78)       -- #cf444e
local COL_ACC_WASH = Color(207, 68, 78, 26)  -- voile accent (rangée active)
local COL_LOCK_WASH = Color(8, 8, 11, 165)   -- voile des plans verrouillés (preview)
local COL_TITLE   = Color(237, 238, 242)
local COL_MUTED   = Color(150, 154, 162)
local COL_DIMTXT  = Color(110, 113, 120)
local COL_RING_BG = Color(255, 255, 255, 13)
local COL_SHADOW  = Color(0, 0, 0, 160)

-- ============================================================================
-- MENU PLEIN ÉCRAN — état poussé par le serveur (qui a déjà validé l'accès).
-- ============================================================================
local frame
local tState -- { role, recipes = {id,name,desc,ready}, xp, targets = {slot,item,ench} }

local RARITY_COLORS = {
	common    = Color(176, 178, 184),
	rare      = Color(77, 157, 255),
	epic      = Color(178, 103, 255),
	legendary = Color(255, 174, 66),
	mythic    = Color(255, 84, 84),
}

local function RarityColor(item_id)
	local it = ITEMS and ITEMS[item_id]
	return RARITY_COLORS[it and it.rarity or "common"] or RARITY_COLORS.common
end

-- "a:x;b:y" -> lignes d'affichage { {txt=, col=, pct=, stat=}, ... } (2 max).
local function EnchLines(sEnch, item_id)
	local out = {}
	if not (INVENTORY_CONFIG and INVENTORY_CONFIG.ParseEnchantList) then return out end
	if EVO_CRAFT.EnchantMigrateString then
		sEnch = EVO_CRAFT.EnchantMigrateString(sEnch, item_id)
	end
	for _, e in ipairs(INVENTORY_CONFIG.ParseEnchantList(sEnch)) do
		local def = EVO_CRAFT.EnchantByKey(e.stat)
		out[#out + 1] = {
			txt = string.format("+%.2f%% %s", e.pct, def and def.label or e.stat),
			col = (def and def.color) or COL_GOLD,
			pct = e.pct,
			stat = e.stat,
		}
	end
	return out
end

local COL_ENCH_SHADOW = Color(0, 0, 0, 190)

-- Texte en DÉGRADÉ horizontal par caractère : teinte du boost -> version
-- éclaircie. Construit UNE fois (itération utf8 + Lerp), les Paint ne font que
-- dessiner (l'alpha des Color par caractère est pulsé sur place).
local function BuildGradLine(txt, font, colA)
	local colB = Color(colA.r + (255 - colA.r) * 0.72, colA.g + (255 - colA.g) * 0.72,
		colA.b + (255 - colA.b) * 0.72)
	surface.SetFont(font)
	local totalW = surface.GetTextSize(txt)
	local chars, x = {}, 0
	for _, cp in utf8.codes(txt) do
		local ch = utf8.char(cp)
		local w = surface.GetTextSize(ch)
		local f = totalW > 0 and ((x + w / 2) / totalW) or 0
		chars[#chars + 1] = { ch = ch, x = x,
			col = Color(Lerp(f, colA.r, colB.r), Lerp(f, colA.g, colB.g), Lerp(f, colA.b, colB.b)) }
		x = x + w
	end
	return { txt = txt, font = font, chars = chars, w = totalW }
end

-- Dessin centré sur cx : ombre portée pleine chaîne puis caractères dégradés.
local function DrawGradLine(tLine, cx, y, alpha)
	draw.SimpleText(tLine.txt, tLine.font, cx + 1, y + 1, COL_ENCH_SHADOW, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	local x0 = cx - tLine.w / 2
	for i = 1, #tLine.chars do
		local g = tLine.chars[i]
		g.col.a = alpha
		draw.SimpleText(g.ch, tLine.font, x0 + g.x, y, g.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

-- Anneau de progression en QUADS convexes (surface.DrawPoly ne rend bien que du
-- convexe). Mémoisé par fraction : ne se reconstruit qu'au changement d'XP.
local function DrawRingArc(cx, cy, rIn, rOut, frac, col, cache)
	frac = math.Clamp(frac or 0, 0, 1)
	if frac <= 0 then return end
	if not cache.quads or cache.frac ~= frac then
		local seg = math.max(4, math.ceil(96 * frac))
		local a0 = -math.pi / 2
		local step = math.pi * 2 * frac / seg
		local quads = {}
		for i = 0, seg - 1 do
			local a1, a2 = a0 + i * step, a0 + (i + 1) * step
			local c1, s1, c2, s2 = math.cos(a1), math.sin(a1), math.cos(a2), math.sin(a2)
			quads[#quads + 1] = {
				{ x = cx + c1 * rIn,  y = cy + s1 * rIn },
				{ x = cx + c1 * rOut, y = cy + s1 * rOut },
				{ x = cx + c2 * rOut, y = cy + s2 * rOut },
				{ x = cx + c2 * rIn,  y = cy + s2 * rIn },
			}
		end
		cache.quads, cache.frac = quads, frac
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	for i = 1, #cache.quads do
		surface.DrawPoly(cache.quads[i])
	end
end

-- Croix de fermeture STANDARD DA : × gris -> rouge au survol, fond arrondi léger.
local function MakeCloseCross(parent, x, y, fClick)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(gRespX(52), gRespY(52))
	b:SetPos(x, y)
	b.Paint = function(s, w, h)
		if s:IsHovered() then
			RNDX.Draw(gRespY(10), 0, 0, w, h, COL_SUB_HI)
		end
		draw.SimpleText("×", "Bebas Neue:44", w / 2, h / 2 - gRespY(2),
			s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClick
	return b
end

-- Bouton d'action DA : plein accent arrondi, éclairci au survol (lerp doux).
-- fEnabled (optionnel) : grisé + clic inerte tant qu'elle renvoie false.
local function MakeActionBtn(parent, x, y, w, h, label, font, fClick, fEnabled)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(w, h)
	b:SetPos(x, y)
	b._hf = 0
	b.Paint = function(s, bw, bh)
		local bOn = not fEnabled or fEnabled()
		s._hf = Lerp(FrameTime() * 10, s._hf, (bOn and s:IsHovered()) and 1 or 0)
		local k = 1 + s._hf * 0.18
		RNDX.Draw(gRespY(10), 0, 0, bw, bh, bOn
			and Color(math.min(255, COL_ACCENT.r * k), math.min(255, COL_ACCENT.g * k), math.min(255, COL_ACCENT.b * k))
			or COL_SUB)
		draw.SimpleText(label, font or "Bebas Neue:30", bw / 2, bh / 2,
			bOn and COL_TITLE or COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function()
		if fEnabled and not fEnabled() then return end
		fClick()
	end
	return b
end

-- Exposés pour les onglets construits par d'autres addons DANS l'atelier
-- (table médicale d'evo_science) : même langage UI, défini à UN seul endroit.
EVO_CRAFT.MakeCloseCross = MakeCloseCross
EVO_CRAFT.MakeActionBtn = MakeActionBtn

-- nQty (craft en série, user 09/15) : exemplaires demandés, 1 par défaut —
-- TOUJOURS écrit (le serveur le lit inconditionnellement), enchant/forge l'ignorent.
local function SendDo(sID, nSlot, sArg, nScore, nQty)
	net.Start("EVO:Craft:Do")
		net.WriteString(sID)
		net.WriteUInt(math.Clamp(tonumber(nSlot) or 0, 0, 65535), 16)
		net.WriteString(sArg or "")
		net.WriteFloat(math.Clamp(tonumber(nScore) or 0, 0, 1))
		net.WriteUInt(math.Clamp(math.floor(tonumber(nQty) or 1), 1, math.min((EVO_CRAFT.CFG and EVO_CRAFT.CFG.MaxBatch) or 10, 31)), 5) -- 5 bits : 31 max
	net.SendToServer()
end

-- ============================================================================
-- MINI-JEU DE FORGE : le modèle 3D de l'accessoire au centre, 3 frappes au bon
-- moment sur la jauge (zone qui bouge et rétrécit, curseur qui accélère). Le
-- score part avec le net Do et pèse pour EnchantCfg.SkillWeight dans le tirage.
-- ============================================================================
local COL_STRIKE_GOOD = Color(120, 230, 140)
local COL_STRIKE_MID  = Color(235, 200, 90)
local COL_STRIKE_BAD  = Color(235, 90, 80)
local COL_CURSOR      = Color(255, 255, 255, 245)

-- Sons CUSTOM du projet (règle : jamais de sons GMod de base). Sons dédiés de
-- l'atelier (user 08/18), pack tbfpvq7ot1yh livré par le contenu workshop
-- (comme les senkaimon) : un son par mini-jeu + un son de raté commun.
-- Le résultat gravé garde le ting de réussite (asset evo_science / ncm_forge).
local SND_STRIKE_ENCH  = "tbfpvq7ot1yh/enchantement_sound.mp3" -- frappe du mini-jeu d'enchantement
local SND_STRIKE_FORGE = "tbfpvq7ot1yh/forge_sound.mp3"        -- frappe du mini-jeu de forge 21-30
local SND_MISS         = "tbfpvq7ot1yh/fail.mp3"               -- raté (frappe manquée, éteint, à côté, forge ratée)
local SND_DONE         = "a4xy732ex6yeop2/tv6cllaafv0qtz08d.wav"

local function OpenForgeGame(sRecipeID, t, eBoost)
	if not IsValid(frame) or IsValid(frame._forgeOverlay) then return end
	local it = ITEMS and ITEMS[t.item]
	local ec = eBoost.color or COL_ACCENT
	local ecZone = Color(ec.r, ec.g, ec.b, 185)
	local ecGlow = Color(ec.r, ec.g, ec.b, 46)
	local ecHalo = Color(ec.r, ec.g, ec.b, 130) -- halo de frappe au repos (plein = survol)
	local sItemName = (it and it.name) or t.item

	local ov = vgui.Create("DPanel", frame)
	ov:SetSize(frame:GetWide(), frame:GetTall())
	ov:SetPos(0, 0)
	ov:SetZPos(30000)
	frame._forgeOverlay = ov

	-- État du jeu. Le curseur est une fonction CONTINUE du temps : au changement
	-- de vitesse on recale t0 pour préserver la phase (pas de saut visuel).
	-- Rythme ADOUCI (user 08/20 « trop difficile ») : départ plus lent, montée en
	-- vitesse plus douce, zone plus large qui rétrécit moins.
	local nMax = 3
	local scores, strikeCols = {}, {}
	local speed, t0 = 0.7, RealTime()
	local zoneC, zoneW = 0.3 + math.random() * 0.4, 0.18
	local shakeUntil, lastHit = 0, 0
	local sFeedback, feedbackUntil = nil, 0
	local bWaiting, tResult = false, nil

	local function cursorPos()
		return math.abs(((RealTime() - t0) * speed) % 2 - 1)
	end
	local function setSpeed(nNew)
		local phase = (RealTime() - t0) * speed
		t0 = RealTime() - phase / nNew
		speed = nNew
	end

	-- Modèle 3D de l'accessoire, gros plan au centre (demande user).
	local hw = gRespX(460)
	local hx, hy = (ov:GetWide() - hw) / 2, gRespY(196)
	local holder = vgui.Create("DPanel", ov)
	holder:SetSize(hw, hw)
	holder:SetPos(hx, hy)
	holder.Paint = nil
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it)
	end
	holder.Think = function(s)
		local mp = s._modelPanel
		if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		-- Secousse du modèle à chaque coup de marteau.
		if shakeUntil > RealTime() then
			s:SetPos(hx + math.random(-7, 7), hy + math.random(-7, 7))
		else
			s:SetPos(hx, hy)
		end
	end

	local gaugeW, gaugeH = gRespX(760), gRespY(34)
	ov.Paint = function(s, w, h)
		-- Couche PLATE : voile sombre (pas de coins arrondis = pas de liseré).
		surface.SetDrawColor(COL_DIMBG.r, COL_DIMBG.g, COL_DIMBG.b, 246)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("FORGE DE L'ENCHANTEMENT", "Bebas Neue:64", w / 2, gRespY(92),
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		RNDX.Draw(gRespY(2), w / 2 - gRespX(120), gRespY(126), gRespX(240), gRespY(4), COL_ACCENT)
		draw.SimpleText(sItemName, "Bebas Neue:34", w / 2, gRespY(158),
			COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(eBoost.label, "Black Han Sans:26", w / 2, gRespY(676),
			ec, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		-- Écran de RÉSULTAT (posé par ShowResult via le net Sync) : ligne en dégradé.
		if tResult then
			DrawGradLine(tResult.grad, w / 2, gRespY(766), 255)
			draw.SimpleText("Qualité : " .. tResult.quality, "Bebas Neue:36", w / 2, gRespY(822),
				tResult.qcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		if bWaiting then
			draw.SimpleText("Gravure en cours...", "Bebas Neue:36", w / 2, gRespY(776),
				COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		-- Halo pulsé AUTOUR DU MODÈLE : purement décoratif depuis que la frappe
		-- se fait à la BARRE ESPACE (user 08/20), il bat au rythme du geste.
		local mcx, mcy = hx + hw / 2, hy + hw / 2
		local pr = hw * 0.30 + math.sin(RealTime() * 3) * gRespX(5)
		RNDX.DrawCircleOutlined(mcx, mcy, pr, ecHalo, gRespY(3))

		-- Jauge arrondie : fond, halo + zone (teinte du boost), curseur.
		local gx, gy = (w - gaugeW) / 2, gRespY(716)
		RNDX.Draw(gaugeH / 2, gx, gy, gaugeW, gaugeH, COL_SUB)
		local zx = gx + (zoneC - zoneW) * gaugeW
		local zw = zoneW * 2 * gaugeW
		RNDX.Draw(gaugeH / 2, zx - gRespX(6), gy - gRespY(4), zw + gRespX(12), gaugeH + gRespY(8), ecGlow)
		RNDX.Draw(gaugeH / 2, zx, gy, zw, gaugeH, ecZone)
		local cxu = gx + cursorPos() * gaugeW
		RNDX.Draw(gRespX(2), cxu - gRespX(2), gy - gRespY(8), gRespX(4), gaugeH + gRespY(16), COL_CURSOR)

		-- Marqueurs des frappes (couleur selon la précision de chacune).
		for i = 1, nMax do
			local c = strikeCols[i] or COL_RING_BG
			RNDX.Draw(gRespY(4), gx + (i - 1) * gRespX(34), gy + gaugeH + gRespY(16), gRespX(24), gRespY(8), c)
		end

		if sFeedback and feedbackUntil > RealTime() then
			draw.SimpleText(sFeedback, "Black Han Sans:34", w / 2, gRespY(786),
				strikeCols[#strikeCols] or COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("FRAPPE " .. math.min(#scores + 1, nMax) .. " / " .. nMax,
			"Bebas Neue:28", w / 2, gRespY(842), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("BARRE ESPACE quand le curseur traverse la zone colorée",
			"Avenir Next World:19", w / 2, gRespY(876), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- FRAPPE À LA BARRE ESPACE (user 08/20, remplace le clic sur le modèle) :
	-- front montant lu en input BRUT dans le Think (marche quelle que soit la
	-- souris), armé au premier relâchement — l'appui d'ouverture ne compte pas.
	local function Strike() -- netgate: edge -- space-key rising edge (down and not bSpaceWas)
		if bWaiting or tResult then return end
		if RealTime() - lastHit < 0.25 then return end
		lastHit = RealTime()
		local prec = math.max(0, 1 - math.abs(cursorPos() - zoneC) / zoneW)
		scores[#scores + 1] = prec
		strikeCols[#scores] = prec >= 0.75 and COL_STRIKE_GOOD or (prec >= 0.35 and COL_STRIKE_MID or COL_STRIKE_BAD)
		shakeUntil = RealTime() + 0.22
		surface.PlaySound(prec > 0 and SND_STRIKE_ENCH or SND_MISS)
		sFeedback = prec >= 0.85 and "PARFAIT !" or (prec >= 0.5 and "BIEN" or (prec > 0 and "JUSTE" or "RATÉ"))
		feedbackUntil = RealTime() + 0.7
		if #scores >= nMax then
			bWaiting = true
			local sum = 0
			for _, v in ipairs(scores) do sum = sum + v end
			frame._forgePending = { slot = t.slot }
			SendDo(sRecipeID, t.slot, eBoost.key, sum / nMax)
			-- Failsafe : refus serveur = notif sans Sync, on ne reste pas bloqué.
			timer.Simple(5, function()
				if IsValid(ov) and not tResult then
					if IsValid(frame) then frame._forgePending = nil end
					ov:Remove()
				end
			end)
		else
			-- Frappe suivante : un peu plus rapide, zone un peu plus étroite,
			-- replacée (progression adoucie, user 08/20).
			setSpeed(speed + 0.25)
			zoneW = zoneW * 0.85
			zoneC = 0.2 + math.random() * 0.6
		end
	end
	local bSpaceWas = true
	ov.Think = function()
		local down = input.IsKeyDown(KEY_SPACE)
		if down and not bSpaceWas then Strike() end
		bSpaceWas = down
	end

	local cancel = MakeCloseCross(ov, ov:GetWide() - gRespX(104), gRespY(40), function()
		if bWaiting and not tResult then return end -- gravure partie : on attend le résultat
		if IsValid(frame) then frame._forgePending = nil end
		ov:Remove()
	end)
	cancel:SetZPos(32000)

	-- Appelé par le receiver Sync quand l'enchant de CE slot arrive : on montre
	-- l'entrée du boost FORGÉ (l'item peut en porter deux), en dégradé.
	ov.ShowResult = function(sEnch)
		local eNew
		for _, l in ipairs(EnchLines(sEnch)) do
			if l.stat == eBoost.key then eNew = l break end
		end
		if not eNew then
			ov:Remove()
			return
		end
		local q = EVO_CRAFT.EnchantQuality(eNew.pct, eNew.stat)
		tResult = {
			grad = BuildGradLine(eNew.txt, "Black Han Sans:40", eNew.col),
			quality = q.label, qcol = q.color,
		}
		surface.PlaySound(SND_DONE)
		timer.Simple(2.8, function()
			if IsValid(ov) then ov:Remove() end
		end)
	end
end

-- ============================================================================
-- MINI-JEU FORGE 21-30 : POINTS CHAUDS — des étincelles dorées apparaissent sur
-- la pièce et rétrécissent, il faut les marteler avant qu'elles s'éteignent.
-- 5 points, 4 réussites minimum ; un clic à côté = coup perdu (anti spam-clic) ;
-- RATÉ = rien n'est dépensé, on réessaie. Mécanique volontairement DISTINCTE du
-- timing-bar de l'enchantement (demande user : « un autre truc »).
-- ============================================================================
local COL_SPARK_GLOW = Color(216, 185, 106, 30)

local function OpenForgeUpGame(sRecipeID, t)
	if not IsValid(frame) or IsValid(frame._forgeOverlay) then return end
	local it = ITEMS and ITEMS[t.item]
	local sItemName = (it and it.name) or t.item
	local sLvlLine = string.format("Niveau %d  →  %d", t.lvl, t.lvl + 1)

	local ov = vgui.Create("DPanel", frame)
	ov:SetSize(frame:GetWide(), frame:GetTall())
	ov:SetPos(0, 0)
	ov:SetZPos(30000)
	frame._forgeOverlay = ov

	local nTotal, nNeed = 5, 4
	local nHits, nDone = 0, 0
	local tMarks = {}
	local spark = nil -- { x, y, born, life }
	local nextAt = RealTime() + 0.9
	local shakeUntil, lastClick = 0, 0
	local sFeedback, feedbackUntil, colFeedback = nil, 0, COL_TITLE
	local sEnd = nil -- "ok" / "fail"

	-- Modèle 3D de la pièce, gros plan au centre.
	local hw = gRespX(460)
	local hx, hy = (ov:GetWide() - hw) / 2, gRespY(196)
	local holder = vgui.Create("DPanel", ov)
	holder:SetSize(hw, hw)
	holder:SetPos(hx, hy)
	holder.Paint = nil
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it)
	end
	holder.Think = function(s)
		local mp = s._modelPanel
		if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		if shakeUntil > RealTime() then
			s:SetPos(hx + math.random(-7, 7), hy + math.random(-7, 7))
		else
			s:SetPos(hx, hy)
		end
	end

	local SPARK_R0, SPARK_R1 = gRespX(46), gRespX(12)
	local function sparkRadius(sp)
		local f = math.Clamp((RealTime() - sp.born) / sp.life, 0, 1)
		return Lerp(f, SPARK_R0, SPARK_R1), f
	end

	-- netgate: edge — sEnd posé ici coupe Think et clics : le net Do part UNE fois.
	local function finish()
		if nHits >= nNeed then
			sEnd = "ok"
			surface.PlaySound(SND_DONE)
			SendDo(sRecipeID, t.slot, "", nHits / nTotal)
			timer.Simple(2.2, function()
				if IsValid(ov) then ov:Remove() end
			end)
		else
			sEnd = "fail"
			surface.PlaySound(SND_MISS)
			timer.Simple(1.8, function()
				if IsValid(ov) then ov:Remove() end
			end)
		end
	end

	ov.Think = function()
		if sEnd then return end
		local now = RealTime()
		if spark then
			local _, f = sparkRadius(spark)
			if f >= 1 then
				-- Étincelle éteinte sans frappe = coup perdu.
				spark = nil
				nDone = nDone + 1
				tMarks[nDone] = COL_STRIKE_BAD
				surface.PlaySound(SND_MISS)
				sFeedback, colFeedback, feedbackUntil = "ÉTEINT", COL_STRIKE_BAD, now + 0.6
				if nDone >= nTotal then finish() else nextAt = now + 0.55 end
			end
		elseif nDone < nTotal and now >= nextAt then
			local ang = math.random() * math.pi * 2
			local d = hw * (0.10 + math.random() * 0.24)
			spark = {
				x = hx + hw / 2 + math.cos(ang) * d,
				y = hy + hw / 2 + math.sin(ang) * d,
				born = now, life = 1.15,
			}
		end
	end

	ov.Paint = function(s, w, h)
		surface.SetDrawColor(COL_DIMBG.r, COL_DIMBG.g, COL_DIMBG.b, 246)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("FORGE", "Bebas Neue:64", w / 2, gRespY(92),
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		RNDX.Draw(gRespY(2), w / 2 - gRespX(120), gRespY(126), gRespX(240), gRespY(4), COL_ACCENT)
		draw.SimpleText(sItemName, "Bebas Neue:34", w / 2, gRespY(158),
			COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sLvlLine, "Black Han Sans:24", w / 2, gRespY(676),
			COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if sEnd == "ok" then
			draw.SimpleText("FORGE EN COURS...", "Bebas Neue:40", w / 2, gRespY(766),
				COL_STRIKE_GOOD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		elseif sEnd == "fail" then
			draw.SimpleText("FORGE RATÉE", "Bebas Neue:40", w / 2, gRespY(766),
				COL_STRIKE_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Rien n'a été dépensé.", "Avenir Next World:20", w / 2, gRespY(812),
				COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		-- Étincelle : halo + disque doré qui rétrécit (dessinés SOUS le modèle,
		-- les enfants du panel peignent après — le point reste lisible autour).
		if spark then
			local r = sparkRadius(spark)
			RNDX.DrawCircle(spark.x, spark.y, r + gRespX(8), COL_SPARK_GLOW)
			RNDX.DrawCircle(spark.x, spark.y, r, COL_GOLD)
			RNDX.DrawCircleOutlined(spark.x, spark.y, r + gRespX(3), COL_CURSOR, gRespY(2))
		end

		-- Marqueurs des 5 coups (couleur par précision).
		local mx0 = w / 2 - gRespX((nTotal * 34 - 10) / 2)
		for i = 1, nTotal do
			local c = tMarks[i] or COL_RING_BG
			RNDX.Draw(gRespY(4), mx0 + (i - 1) * gRespX(34), gRespY(716), gRespX(24), gRespY(8), c)
		end

		if sFeedback and feedbackUntil > RealTime() then
			draw.SimpleText(sFeedback, "Black Han Sans:34", w / 2, gRespY(766),
				colFeedback, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("FRAPPE " .. math.min(nDone + 1, nTotal) .. " / " .. nTotal,
			"Bebas Neue:28", w / 2, gRespY(842), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Zone de frappe = le cadre du modèle (les étincelles vivent autour de lui).
	local catch = vgui.Create("DButton", ov)
	catch:SetSize(hw, hw)
	catch:SetPos(hx, hy)
	catch:SetText("")
	catch:SetZPos(31000)
	catch.Paint = nil
	catch.DoClick = function()
		if sEnd then return end
		if RealTime() - lastClick < 0.12 then return end
		lastClick = RealTime()
		if spark then
			local r, f = sparkRadius(spark)
			local dx, dy = gui.MouseX() - spark.x, gui.MouseY() - spark.y
			local hitR = r + gRespX(6)
			if dx * dx + dy * dy <= hitR * hitR then
				nHits = nHits + 1
				nDone = nDone + 1
				tMarks[nDone] = f < 0.45 and COL_STRIKE_GOOD or COL_STRIKE_MID
				sFeedback, colFeedback, feedbackUntil = (f < 0.45 and "PARFAIT !" or "BIEN"),
					tMarks[nDone], RealTime() + 0.6
				spark = nil
				shakeUntil = RealTime() + 0.22
				surface.PlaySound(SND_STRIKE_FORGE)
				if nDone >= nTotal then finish() else nextAt = RealTime() + 0.5 end
				return
			end
		end
		-- Clic à côté (ou sans étincelle) = coup perdu : pas de spam-clic gagnant.
		nDone = nDone + 1
		tMarks[nDone] = COL_STRIKE_BAD
		spark = nil
		surface.PlaySound(SND_MISS)
		sFeedback, colFeedback, feedbackUntil = "À CÔTÉ", COL_STRIKE_BAD, RealTime() + 0.6
		if nDone >= nTotal then finish() else nextAt = RealTime() + 0.55 end
	end

	local cancel = MakeCloseCross(ov, ov:GetWide() - gRespX(104), gRespY(40), function()
		ov:Remove()
	end)
	cancel:SetZPos(32000)
end

-- ── Panneau de droite : détail de la recette sélectionnée ────────────────────
local BuildEnchantPanel
local BuildForgePanel
local BuildAssassinPanel

local function BuildDetail(pnl, r)
	pnl:Clear()
	if not r then
		local lbl = vgui.Create("DLabel", pnl)
		lbl:SetFont("Bebas Neue:30")
		lbl:SetTextColor(COL_DIMTXT)
		lbl:SetText("Aucune recette pour le moment.")
		lbl:SizeToContents()
		lbl:SetPos(gRespX(40), gRespY(40))
		return
	end

	local padX = gRespX(40)
	local title = vgui.Create("DLabel", pnl)
	title:SetFont("Bebas Neue:48")
	title:SetTextColor(COL_TITLE)
	title:SetText(r.name)
	title:SizeToContents()
	title:SetPos(padX, gRespY(26))

	-- Fine barre d'accent sous le titre (signature DA).
	local bar = vgui.Create("DPanel", pnl)
	bar:SetPos(padX, gRespY(82))
	bar:SetSize(gRespX(120), gRespY(4))
	bar.Paint = function(_, w, h) RNDX.Draw(gRespY(2), 0, 0, w, h, COL_ACCENT) end

	-- Pas de paragraphe d'explication pour l'enchantement (demande user 08/18) :
	-- le panneau parle de lui-même, la desc reste pour les recettes génériques.
	if r.id == "combat_enchant" and r.ready then
		BuildEnchantPanel(pnl, r, padX)
		return
	end
	-- Forge 21-30 : panneau + mini-jeu ENTIÈREMENT dans l'atelier (user 08/18,
	-- « rien à voir avec l'enclume » qui garde le socle 1-20).
	if r.id == "combat_forge" and r.ready then
		BuildForgePanel(pnl, r, padX)
		return
	end
	-- Rayon assassin : catalogue de pièges et grenades (sh_craft_assassin_gear).
	if r.id == "assassin_equipement" and r.ready then
		BuildAssassinPanel(pnl, r, padX)
		return
	end
	-- Onglets MÉDECIN : la table médicale d'evo_science, construite DANS
	-- l'atelier (user 08/18, « des onglets, pas un panneau externe »).
	if r.id == "soin_mortier" and r.ready and EVO_SCIENCE and EVO_SCIENCE.BuildMedicMortier then
		-- L'XP soin est poussée par EVO:Craft:Open : le tab gate les ÉTOILES avec.
		EVO_SCIENCE.BuildMedicMortier(pnl, padX, tState.xp or 0)
		return
	end
	if r.id == "soin_carnet" and r.ready and EVO_SCIENCE and EVO_SCIENCE.BuildMedicCarnet then
		EVO_SCIENCE.BuildMedicCarnet(pnl, padX)
		return
	end

	local desc = vgui.Create("DLabel", pnl)
	desc:SetFont("Avenir Next World:20")
	desc:SetTextColor(COL_MUTED)
	desc:SetWrap(true)
	desc:SetAutoStretchVertical(true)
	desc:SetText(r.desc or "")
	desc:SetPos(padX, gRespY(98))
	desc:SetWide(pnl:GetWide() - padX * 2)

	if r.ready then
		MakeActionBtn(pnl, padX, pnl:GetTall() - gRespY(92), gRespX(240), gRespY(56),
			"CRAFTER", "Bebas Neue:30", function()
			SendDo(r.id, 0, "", 0)
		end)
	else
		local soon = vgui.Create("DLabel", pnl)
		soon:SetFont("Bebas Neue:40")
		soon:SetTextColor(COL_DIMTXT)
		soon:SetText("À VENIR")
		soon:SizeToContents()
		soon:SetPos(padX, pnl:GetTall() - gRespY(92))
	end
end

-- ── Enchantement : choix de l'équipement + du boost + forge ──────────────────
BuildEnchantPanel = function(pnl, r, padX)
	local w = pnl:GetWide()

	-- Verrou de grade (miroir du refus serveur) : le panneau ne s'affiche pas.
	if not EVO_CRAFT.CanEnchantRank(LocalPlayer()) then
		local lock = vgui.Create("DLabel", pnl)
		lock:SetFont("Bebas Neue:40")
		lock:SetTextColor(COL_DIMTXT)
		lock:SetText(string.format("Réservé au grade %d et plus de la division.", EVO_CRAFT.EnchantCfg.MinRank or 3))
		lock:SizeToContents()
		lock:SetPos(padX, gRespY(190))
		return
	end

	local function SectionLabel(text, y)
		local l = vgui.Create("DLabel", pnl)
		l:SetFont("Bebas Neue:30")
		l:SetTextColor(COL_GOLD)
		l:SetText(text)
		l:SizeToContents()
		l:SetPos(padX, y)
		return l
	end

	-- Cibles : équipés d'abord (c'est ce qu'on vient enchanter le plus souvent).
	local targets = {}
	for _, t in ipairs(tState.targets or {}) do targets[#targets + 1] = t end
	table.sort(targets, function(a, b)
		local ea, eb = a.slot > 1000, b.slot > 1000
		if ea ~= eb then return ea end
		return a.slot < b.slot
	end)

	SectionLabel("1. ÉQUIPEMENT À ENCHANTER", gRespY(112))

	local gridY, gridH = gRespY(154), gRespY(436)
	local grid = vgui.Create("DScrollPanel", pnl)
	grid:SetPos(padX, gridY)
	grid:SetSize(w - padX * 2, gridH)
	grid.Paint = nil

	local footer -- déclaré avant : les clics des cartes rafraîchissent le pied de page

	if #targets == 0 then
		local lbl = vgui.Create("DLabel", grid)
		lbl:SetFont("Avenir Next World:20")
		lbl:SetTextColor(COL_DIMTXT)
		lbl:SetText("Aucun équipement enchantable (accessoire à stats) dans ton inventaire.")
		lbl:SizeToContents()
		lbl:SetPos(gRespX(4), gRespY(10))
	end

	local cardW, cardH, gap = gRespX(212), gRespY(276), gRespX(14)
	local perRow = math.max(1, math.floor((w - padX * 2) / (cardW + gap)))
	for i, t in ipairs(targets) do
		local it = ITEMS and ITEMS[t.item]
		local card = vgui.Create("DButton", grid)
		card:SetText("")
		card:SetSize(cardW, cardH)
		card:SetPos(((i - 1) % perRow) * (cardW + gap), math.floor((i - 1) / perRow) * (cardH + gap))

		local holder = vgui.Create("DPanel", card)
		holder:SetPos(gRespX(10), gRespY(14))
		holder:SetSize(cardW - gRespX(20), gRespY(136))
		holder.Paint = nil
		-- ⚠ Sans ça le porte-aperçu AVALE les clics : la moitié haute de la
		-- carte ne sélectionnait pas (user 08/19 « toute la case »).
		holder:SetMouseInputEnabled(false)
		if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it)
		end
		-- Le DModelPanel (lazy) volerait les clics de la carte : on coupe son input.
		card.Think = function()
			local mp = holder._modelPanel
			if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		end

		-- Textes figés à la CONSTRUCTION (le Sync reconstruit le panneau) : lignes
		-- d'enchantement pré-dégradées, pas de ParseEnchant par frame dans le Paint.
		local sName = (it and it.name) or t.item
		local tGrads = {}
		for _, l in ipairs(EnchLines(t.ench, t.item)) do
			tGrads[#tGrads + 1] = BuildGradLine(l.txt, "Black Han Sans:17", l.col)
		end
		local rc = RarityColor(t.item)
		local rcBar = Color(rc.r, rc.g, rc.b, 235)
		local nCost = EVO_CRAFT.EnchantCostFor(t.item)
		card.Paint = function(s, cw, ch)
			local bSel = frame and frame._selTarget == t.slot
			RNDX.Draw(gRespY(12), 0, 0, cw, ch, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
			if bSel then
				RNDX.Draw(gRespY(12), 0, 0, cw, ch, COL_ACC_WASH)
				RNDX.DrawOutlined(gRespY(12), 0, 0, cw, ch, COL_ACCENT, gRespY(2))
			end
			-- Ruban de rareté arrondi en tête de carte.
			RNDX.Draw(gRespY(3), gRespX(10), gRespY(6), cw - gRespX(20), gRespY(5), rcBar)
			draw.SimpleText(sName, "Bebas Neue:24", cw / 2, gRespY(172),
				COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if t.slot > 1000 then
				draw.SimpleText("PORTÉ", "Bebas Neue:18", cw - gRespX(12), gRespY(22),
					COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			if #tGrads > 0 then
				-- Enchantements en DÉGRADÉ (2 max) + respiration douce partagée.
				local pulse = 200 + math.sin(RealTime() * 2.5) * 55
				if #tGrads == 1 then
					DrawGradLine(tGrads[1], cw / 2, gRespY(204), pulse)
				else
					DrawGradLine(tGrads[1], cw / 2, gRespY(196), pulse)
					DrawGradLine(tGrads[2], cw / 2, gRespY(218), pulse)
				end
			else
				draw.SimpleText("Aucun enchantement", "Avenir Next World:16", cw / 2, gRespY(204),
					COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			if MUGEN and MUGEN.DrawMoney then
				MUGEN.DrawMoney(nCost, "Bebas Neue:22", cw / 2, gRespY(246),
					COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		card.DoClick = function()
			frame._selTarget = t.slot
			if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
			if IsValid(footer) then footer:InvalidateLayout() end
		end
	end

	SectionLabel("2. STAT À GRAVER", gridY + gridH + gRespY(18))

	local pillY = gridY + gridH + gRespY(60)
	local pillW, pillH, pillGap = gRespX(234), gRespY(54), gRespX(10)
	-- Les pastilles PASSENT À LA LIGNE (08/22, l'ajout du boost de critique en a
	-- fait 6 : une seule rangée débordait du panneau). On calcule combien tiennent,
	-- le pied de page suit le nombre de rangées réellement occupées.
	local pillRowGap = gRespY(8)
	local nPerRow = math.max(1, math.floor((w - padX * 2 + pillGap) / (pillW + pillGap)))
	local nPillRows = math.ceil(#EVO_CRAFT.Enchants / nPerRow)

	for i, e in ipairs(EVO_CRAFT.Enchants) do
		local nCol, nRow = (i - 1) % nPerRow, math.floor((i - 1) / nPerRow)
		local b = vgui.Create("DButton", pnl)
		b:SetText("")
		b:SetSize(pillW, pillH)
		b:SetPos(padX + nCol * (pillW + pillGap), pillY + nRow * (pillH + pillRowGap))
		-- Teintes de la pastille figées à la construction (couleur du boost).
		local ec = e.color or COL_ACCENT
		local ecIdle = ColorAlpha(ec, 175)
		local ecWash = Color(ec.r, ec.g, ec.b, 30)
		b.Paint = function(s, bw, bh)
			local bSel = frame and frame._selBoost == e.key
			RNDX.Draw(gRespY(10), 0, 0, bw, bh, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
			if bSel then
				RNDX.Draw(gRespY(10), 0, 0, bw, bh, ecWash)
				RNDX.DrawOutlined(gRespY(10), 0, 0, bw, bh, ec, gRespY(2))
			end
			RNDX.Draw(gRespY(2), gRespX(8), gRespY(10), gRespX(4), bh - gRespY(20), bSel and ec or ecIdle)
			draw.SimpleText(e.label, "Black Han Sans:19", bw / 2 + gRespX(4), bh / 2,
				bSel and ec or (s:IsHovered() and COL_TITLE or ecIdle),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			frame._selBoost = e.key
			if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
		end
	end

	-- Pied de page : coût (yens ET cristaux) + prédiction ajout/remplacement.
	-- Pas de texte d'explication (demande user 08/18). Mémoïsé par sélection.
	footer = vgui.Create("DPanel", pnl)
	footer:SetPos(padX, pillY + nPillRows * (pillH + pillRowGap) - pillRowGap + gRespY(26))
	footer:SetSize(w - padX * 2 - gRespX(280), gRespY(92))
	local cEnch = EVO_CRAFT.EnchantCfg
	local nLvlNow = EVO_CRAFT.LevelFromXP(tState.xp or 0)
	local selCache = { key = false }
	local function RefreshSelCache()
		local selT = frame and frame._selTarget
		local selB = frame and frame._selBoost
		local key = tostring(selT) .. "|" .. tostring(selB)
		if selCache.key == key then return end
		selCache.key = key
		selCache.t = nil
		for _, t in ipairs(tState.targets or {}) do
			if t.slot == selT then selCache.t = t break end
		end
		if not selCache.t then return end
		local nTier, nCnt = EVO_CRAFT.EnchantCrystalsFor(selCache.t.item)
		local lp = LocalPlayer()
		local inv = lp.GetInventory and lp:GetInventory()
		local nHave = EVO_CRAFT.CountCrystalsIn(inv, nTier)
		selCache.cost = EVO_CRAFT.EnchantCostFor(selCache.t.item)
		selCache.cry = string.format("%d× %s (%d en réserve)", nCnt, EVO_CRAFT.CrystalTierName(nTier), nHave)
		selCache.cryOk = nHave >= nCnt
		selCache.pred = nil
		if selB then
			local sEnch = selCache.t.ench
			if EVO_CRAFT.EnchantMigrateString then
				sEnch = EVO_CRAFT.EnchantMigrateString(sEnch, selCache.t.item)
			end
			local tList = INVENTORY_CONFIG.ParseEnchantList(sEnch)
			local nSlots = (nLvlNow >= (cEnch.SecondSlotLevel or 20)) and (cEnch.MaxSlots or 2) or 1
			for _, e in ipairs(tList) do
				if e.stat == selB then
					local d = EVO_CRAFT.EnchantByKey(selB)
					selCache.pred = string.format("Remplacera le +%.2f%% %s déjà gravé.", e.pct, d and d.label or e.stat)
				end
			end
			if not selCache.pred and #tList > 0 then
				if #tList < nSlots then
					selCache.pred = "Sera AJOUTÉ en 2e enchantement (niveau " .. (cEnch.SecondSlotLevel or 20) .. ")."
				else
					local old = tList[1]
					local d = EVO_CRAFT.EnchantByKey(old.stat)
					selCache.pred = string.format("Remplacera +%.2f%% %s (le plus ancien).", old.pct, d and d.label or old.stat)
				end
			end
		end
	end
	footer.Paint = function(s, fw, fh)
		RefreshSelCache()
		if selCache.t then
			local sTxt = "Coût de la tentative : "
			surface.SetFont("Avenir Next World:19")
			local tw = surface.GetTextSize(sTxt)
			draw.SimpleText(sTxt, "Avenir Next World:19", 0, gRespY(4), COL_TITLE)
			if MUGEN and MUGEN.DrawMoney then
				MUGEN.DrawMoney(selCache.cost, "Avenir Next World:19", tw, gRespY(4), COL_GOLD)
			end
			draw.SimpleText("+ " .. selCache.cry, "Avenir Next World:19", 0, gRespY(32),
				selCache.cryOk and COL_STRIKE_GOOD or COL_STRIKE_BAD)
			if selCache.pred then
				draw.SimpleText(selCache.pred, "Avenir Next World:19", 0, gRespY(60), COL_MUTED)
			end
		else
			draw.SimpleText("Sélectionne un équipement.", "Avenir Next World:19", 0, gRespY(4), COL_DIMTXT)
		end
	end

	-- FORGER = ouvre le mini-jeu ; le net Do ne part qu'après les 3 frappes.
	MakeActionBtn(pnl, w - padX - gRespX(260), pillY + pillH + gRespY(44), gRespX(260), gRespY(58), "FORGER", "Bebas Neue:32", function()
		if not (frame and frame._selTarget and frame._selBoost) then
			notification.AddLegacy("Choisis un équipement ET un boost.", NOTIFY_ERROR, 3)
			return
		end
		RefreshSelCache()
		if selCache.t and not selCache.cryOk then
			notification.AddLegacy("Il te manque des cristaux : " .. selCache.cry .. ".", NOTIFY_ERROR, 4)
			return
		end
		local tSel
		for _, tt in ipairs(tState.targets or {}) do
			if tt.slot == frame._selTarget then tSel = tt break end
		end
		local eBoost = EVO_CRAFT.EnchantByKey(frame._selBoost)
		if not (tSel and eBoost) then return end
		OpenForgeGame(r.id, tSel, eBoost)
	end)
end

-- ── Forge 21-30 : choix de la pièce (niveau 20+) + mini-jeu des points chauds ─
BuildForgePanel = function(pnl, r, padX)
	local w = pnl:GetWide()

	-- Verrou (miroir du refus serveur CanForgeLevel : division de combat + grade 8+).
	if NCM_FORGE and NCM_FORGE.CanForgeLevel
		and not NCM_FORGE.CanForgeLevel(LocalPlayer(), NCM_FORGE.COMBAT_LEVEL_START or 21) then
		local lock = vgui.Create("DLabel", pnl)
		lock:SetFont("Bebas Neue:40")
		lock:SetTextColor(COL_DIMTXT)
		lock:SetText(string.format("Réservé au grade %d et plus de la division.", (NCM_FORGE and NCM_FORGE.FORGE_MIN_GRADE) or 8))
		lock:SizeToContents()
		lock:SetPos(padX, gRespY(190))
		return
	end

	local function SectionLabel(text, y)
		local l = vgui.Create("DLabel", pnl)
		l:SetFont("Bebas Neue:30")
		l:SetTextColor(COL_GOLD)
		l:SetText(text)
		l:SizeToContents()
		l:SetPos(padX, y)
		return l
	end

	-- Cibles : les mêmes accessoires que l'enchantement, déjà montés au moins
	-- niveau 20 à l'enclume et pas encore au max. Équipés d'abord.
	local nMaxLvl = (NCM_FORGE and NCM_FORGE.MAX_LEVEL) or 30
	local targets = {}
	for _, t in ipairs(tState.targets or {}) do
		local lvl = (NCM_FORGE and NCM_FORGE.GetClientLevel and NCM_FORGE.GetClientLevel(t.slot)) or 1
		if lvl >= 20 and lvl < nMaxLvl then
			targets[#targets + 1] = { slot = t.slot, item = t.item, lvl = lvl }
		end
	end
	table.sort(targets, function(a, b)
		local ea, eb = a.slot > 1000, b.slot > 1000
		if ea ~= eb then return ea end
		return a.slot < b.slot
	end)

	SectionLabel("ÉQUIPEMENT À FORGER (NIVEAU 20 MINIMUM)", gRespY(112))

	local gridY, gridH = gRespY(154), gRespY(436)
	local grid = vgui.Create("DScrollPanel", pnl)
	grid:SetPos(padX, gridY)
	grid:SetSize(w - padX * 2, gridH)
	grid.Paint = nil

	local footer

	if #targets == 0 then
		local lbl = vgui.Create("DLabel", grid)
		lbl:SetFont("Avenir Next World:20")
		lbl:SetTextColor(COL_DIMTXT)
		lbl:SetText("Aucun accessoire niveau 20 ou plus. Monte-les d'abord à l'enclume.")
		lbl:SizeToContents()
		lbl:SetPos(gRespX(4), gRespY(10))
	end

	local cardW, cardH, gap = gRespX(212), gRespY(276), gRespX(14)
	local perRow = math.max(1, math.floor((w - padX * 2) / (cardW + gap)))
	for i, t in ipairs(targets) do
		local it = ITEMS and ITEMS[t.item]
		local card = vgui.Create("DButton", grid)
		card:SetText("")
		card:SetSize(cardW, cardH)
		card:SetPos(((i - 1) % perRow) * (cardW + gap), math.floor((i - 1) / perRow) * (cardH + gap))

		local holder = vgui.Create("DPanel", card)
		holder:SetPos(gRespX(10), gRespY(14))
		holder:SetSize(cardW - gRespX(20), gRespY(136))
		holder.Paint = nil
		-- ⚠ Sans ça le porte-aperçu AVALE les clics : la moitié haute de la
		-- carte ne sélectionnait pas (user 08/19 « toute la case »).
		holder:SetMouseInputEnabled(false)
		if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, it)
		end
		card.Think = function()
			local mp = holder._modelPanel
			if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		end

		local sName = (it and it.name) or t.item
		local sLvl = string.format("Niveau %d  →  %d", t.lvl, t.lvl + 1)
		local rc = RarityColor(t.item)
		local rcBar = Color(rc.r, rc.g, rc.b, 235)
		local nCost = (NCM_FORGE and NCM_FORGE.GetUpgradeCost and NCM_FORGE.GetUpgradeCost((it and it.rarity) or "common", t.lvl)) or 0
		card.Paint = function(s, cw, ch)
			local bSel = frame and frame._selForge == t.slot
			RNDX.Draw(gRespY(12), 0, 0, cw, ch, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
			if bSel then
				RNDX.Draw(gRespY(12), 0, 0, cw, ch, COL_ACC_WASH)
				RNDX.DrawOutlined(gRespY(12), 0, 0, cw, ch, COL_ACCENT, gRespY(2))
			end
			RNDX.Draw(gRespY(3), gRespX(10), gRespY(6), cw - gRespX(20), gRespY(5), rcBar)
			draw.SimpleText(sName, "Bebas Neue:24", cw / 2, gRespY(172),
				COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if t.slot > 1000 then
				draw.SimpleText("PORTÉ", "Bebas Neue:18", cw - gRespX(12), gRespY(22),
					COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			draw.SimpleText(sLvl, "Black Han Sans:18", cw / 2, gRespY(204),
				COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if MUGEN and MUGEN.DrawMoney then
				MUGEN.DrawMoney(nCost, "Bebas Neue:22", cw / 2, gRespY(246),
					COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		card.DoClick = function()
			frame._selForge = t.slot
			if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
			if IsValid(footer) then footer:InvalidateLayout() end
		end
	end

	-- Pied de page : coût yens + cristaux + niveau perso requis. Mémoïsé par cible.
	footer = vgui.Create("DPanel", pnl)
	footer:SetPos(padX, gridY + gridH + gRespY(26))
	footer:SetSize(w - padX * 2 - gRespX(300), gRespY(96))
	local selCache = { key = false }
	local function RefreshSelCache()
		local selT = frame and frame._selForge
		if selCache.key == selT then return end
		selCache.key = selT
		selCache.t = nil
		for _, t in ipairs(targets) do
			if t.slot == selT then selCache.t = t break end
		end
		if not selCache.t then return end
		local t = selCache.t
		local it = ITEMS and ITEMS[t.item]
		selCache.cost = (NCM_FORGE.GetUpgradeCost and NCM_FORGE.GetUpgradeCost((it and it.rarity) or "common", t.lvl)) or 0
		local tReq = NCM_FORGE.GetForgeCrystalCost and NCM_FORGE.GetForgeCrystalCost(t.lvl + 1)
		if tReq then
			local lp = LocalPlayer()
			local inv = lp.GetInventory and lp:GetInventory()
			local nHave = EVO_CRAFT.CountCrystalsIn(inv, tReq.tier)
			selCache.cry = string.format("%s (%d en réserve)",
				(NCM_FORGE.ForgeCrystalLabel and NCM_FORGE.ForgeCrystalLabel(t.lvl + 1)) or "des cristaux", nHave)
			selCache.cryOk = nHave >= tReq.count
		else
			selCache.cry, selCache.cryOk = nil, true
		end
		local nReqLvl = (NCM_FORGE.GetRequiredCharLevel and NCM_FORGE.GetRequiredCharLevel(t.lvl + 1)) or 0
		local nMyLvl = LocalPlayer():GetEvoNWInt("Level", 1)
		-- Ligne TOUJOURS visible : verte si le prérequis est rempli, rouge sinon (user 08/18).
		selCache.lvlOk = nMyLvl >= nReqLvl
		selCache.lvlLine = string.format("Niveau de personnage requis : %d (toi : %d)", nReqLvl, nMyLvl)
	end
	footer.Paint = function(s, fw, fh)
		RefreshSelCache()
		if selCache.t then
			local sTxt = "Coût de la forge : "
			surface.SetFont("Avenir Next World:19")
			local tw = surface.GetTextSize(sTxt)
			draw.SimpleText(sTxt, "Avenir Next World:19", 0, gRespY(4), COL_TITLE)
			if MUGEN and MUGEN.DrawMoney then
				MUGEN.DrawMoney(selCache.cost, "Avenir Next World:19", tw, gRespY(4), COL_GOLD)
			end
			if selCache.cry then
				draw.SimpleText("+ " .. selCache.cry, "Avenir Next World:19", 0, gRespY(32),
					selCache.cryOk and COL_STRIKE_GOOD or COL_STRIKE_BAD)
			end
			if selCache.lvlLine then
				draw.SimpleText(selCache.lvlLine, "Avenir Next World:19", 0, gRespY(60),
					selCache.lvlOk and COL_STRIKE_GOOD or COL_STRIKE_BAD)
			end
		else
			draw.SimpleText("Sélectionne un équipement.", "Avenir Next World:19", 0, gRespY(4), COL_DIMTXT)
		end
	end

	-- FORGER = lance le mini-jeu des points chauds ; le net ne part qu'en cas de
	-- réussite (4 frappes sur 5), un raté ne dépense RIEN.
	MakeActionBtn(pnl, w - padX - gRespX(280), gridY + gridH + gRespY(40), gRespX(280), gRespY(58), "FORGER", "Bebas Neue:32", function()
		if not (frame and frame._selForge) then
			notification.AddLegacy("Choisis un équipement.", NOTIFY_ERROR, 3)
			return
		end
		RefreshSelCache()
		if not selCache.t then return end
		if not selCache.cryOk then
			notification.AddLegacy("Il te manque des cristaux : " .. tostring(selCache.cry) .. ".", NOTIFY_ERROR, 4)
			return
		end
		if not selCache.lvlOk then
			notification.AddLegacy(selCache.lvlLine, NOTIFY_ERROR, 4)
			return
		end
		OpenForgeUpGame(r.id, selCache.t)
	end)
end

-- Aperçus FIGÉS dans l'atelier assassin (demande user 08/18) : délègue au
-- helper CENTRAL du module d'aperçu (partagé avec le slot rapide et son radial).
local function AssassinPreviewItem(it)
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.StaticItem then
		return LZY_INVENTORY_ITEM_PREVIEW.StaticItem(it)
	end
	return it
end

-- ── MINI-JEU D'ASSEMBLAGE (assassin) : un anneau se resserre vers le cercle
-- cible autour de la pièce, il faut cliquer au passage. 3 coups, 2 réussites
-- minimum ; RATÉ = rien n'est dépensé. Le score (précision moyenne) module
-- l'XP côté serveur. Mécanique distincte du timing-bar et des points chauds.
-- nQty : exemplaires du lot (craft en série, user 09/15) — UN seul mini-jeu
-- pour tout le lot, envoyé au serveur avec le score.
local function OpenAssassinGame(sRecipeID, g, nQty)
	if not IsValid(frame) or IsValid(frame._forgeOverlay) then return end
	local it = ITEMS and ITEMS[g.key]
	local sItemName = g.name or g.key

	local ov = vgui.Create("DPanel", frame)
	ov:SetSize(frame:GetWide(), frame:GetTall())
	ov:SetPos(0, 0)
	ov:SetZPos(30000)
	frame._forgeOverlay = ov

	local nTotal, nNeed = 3, 2
	local nRound, nHits, sumPrec = 1, 0, 0
	local tMarks = {}
	local sFeedback, feedbackUntil, colFeedback = nil, 0, COL_TITLE
	local sEnd = nil -- "ok" / "fail"
	local shakeUntil, lastClick = 0, 0

	-- Modèle 3D de la pièce au centre (même cadrage que les mini-jeux de forge).
	local hw = gRespX(460)
	local hx, hy = (ov:GetWide() - hw) / 2, gRespY(196)
	local holder = vgui.Create("DPanel", ov)
	holder:SetSize(hw, hw)
	holder:SetPos(hx, hy)
	holder.Paint = nil
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, AssassinPreviewItem(it))
	end
	holder.Think = function(s)
		local mp = s._modelPanel
		if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		if shakeUntil > RealTime() then
			s:SetPos(hx + math.random(-6, 6), hy + math.random(-6, 6))
		else
			s:SetPos(hx, hy)
		end
	end

	-- Géométrie de l'anneau : il part large et se RESSERRE vers le cercle cible.
	local mcx, mcy = hx + hw / 2, hy + hw / 2
	local R0  = hw * 0.62
	local RT  = hw * 0.20
	local TOL = hw * 0.075
	local ringBorn = RealTime() + 0.6
	local ringLife = 1.7 -- s pour aller de R0 à 0 ; se raccourcit à chaque coup

	local function ringRadius()
		local f = (RealTime() - ringBorn) / ringLife
		if f < 0 then return nil end -- pause entre deux coups
		return Lerp(math.Clamp(f, 0, 1), R0, 0)
	end

	local function finish()
		if nHits >= nNeed then
			sEnd = "ok"
			surface.PlaySound(SND_DONE)
			SendDo(sRecipeID, 0, g.key, sumPrec / nTotal, nQty)
		else
			sEnd = "fail"
			surface.PlaySound(SND_MISS)
		end
		timer.Simple(1.8, function()
			if IsValid(ov) then ov:Remove() end
		end)
	end

	local function nextRound(bHit, nPrec)
		tMarks[nRound] = bHit and (nPrec >= 0.7 and COL_STRIKE_GOOD or COL_STRIKE_MID) or COL_STRIKE_BAD
		sFeedback = bHit and (nPrec >= 0.7 and "PARFAIT !" or "BIEN") or "RATÉ"
		colFeedback = tMarks[nRound]
		feedbackUntil = RealTime() + 0.6
		if bHit then
			nHits = nHits + 1
			sumPrec = sumPrec + nPrec
			shakeUntil = RealTime() + 0.2
			surface.PlaySound(SND_STRIKE_FORGE)
		else
			surface.PlaySound(SND_MISS)
		end
		nRound = nRound + 1
		if nRound > nTotal then finish() return end
		ringLife = math.max(0.9, ringLife - 0.25)
		ringBorn = RealTime() + 0.45
	end

	ov.Think = function()
		if sEnd then return end
		local r = ringRadius()
		-- Anneau passé SOUS la zone cible sans clic : coup perdu.
		if r and r < RT - TOL then nextRound(false, 0) end
	end

	ov.Paint = function(s, w, h)
		surface.SetDrawColor(COL_DIMBG.r, COL_DIMBG.g, COL_DIMBG.b, 246)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("ASSEMBLAGE", "Bebas Neue:64", w / 2, gRespY(92),
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		RNDX.Draw(gRespY(2), w / 2 - gRespX(120), gRespY(126), gRespX(240), gRespY(4), COL_ACCENT)
		draw.SimpleText(sItemName, "Bebas Neue:34", w / 2, gRespY(158),
			COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if sEnd == "ok" then
			draw.SimpleText("ASSEMBLAGE RÉUSSI", "Bebas Neue:40", w / 2, gRespY(766),
				COL_STRIKE_GOOD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		elseif sEnd == "fail" then
			draw.SimpleText("ASSEMBLAGE RATÉ", "Bebas Neue:40", w / 2, gRespY(766),
				COL_STRIKE_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Rien n'a été dépensé.", "Avenir Next World:20", w / 2, gRespY(812),
				COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		-- (Les cercles cible + anneau sont dessinés par le bouton de frappe,
		-- AU-DESSUS du modèle 3D : dessinés ici ils passaient DERRIÈRE lui,
		-- retour user 08/19.)

		local mx0 = w / 2 - gRespX((nTotal * 34 - 10) / 2)
		for i = 1, nTotal do
			local c = tMarks[i] or COL_RING_BG
			RNDX.Draw(gRespY(4), mx0 + (i - 1) * gRespX(34), gRespY(716), gRespX(24), gRespY(8), c)
		end
		if sFeedback and feedbackUntil > RealTime() then
			draw.SimpleText(sFeedback, "Black Han Sans:34", w / 2, gRespY(766),
				colFeedback, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("Clique quand l'anneau touche le cercle rouge", "Avenir Next World:20",
			w / 2, gRespY(812), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("COUP " .. math.min(nRound, nTotal) .. " / " .. nTotal,
			"Bebas Neue:28", w / 2, gRespY(842), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Zone de clic = tout le cadre du modèle (l'anneau vit autour de lui).
	local catch = vgui.Create("DButton", ov)
	catch:SetSize(hw + gRespX(160), hw + gRespY(160))
	catch:SetPos(hx - gRespX(80), hy - gRespY(80))
	catch:SetText("")
	catch:SetZPos(31000)
	-- Cercle CIBLE + anneau : dessinés ICI (ZPos 31000) pour passer DEVANT le
	-- DModelPanel de la pièce — dans ov.Paint ils finissaient derrière (08/19).
	local ccx, ccy = hw / 2 + gRespX(80), hw / 2 + gRespY(80)
	catch.Paint = function()
		if sEnd then return end
		RNDX.DrawCircleOutlined(ccx, ccy, RT + TOL, COL_ACC_WASH, TOL * 2)
		RNDX.DrawCircleOutlined(ccx, ccy, RT, COL_ACCENT, gRespY(3))
		local r = ringRadius()
		if r and r > 2 then
			RNDX.DrawCircleOutlined(ccx, ccy, r, COL_CURSOR, gRespY(4))
		end
	end
	catch.DoClick = function()
		if sEnd then return end
		if RealTime() - lastClick < 0.15 then return end
		lastClick = RealTime()
		local r = ringRadius()
		if not r then return end -- pause : le clic ne compte pas
		local nDist = math.abs(r - RT)
		if nDist <= TOL then
			nextRound(true, 1 - nDist / TOL)
		else
			nextRound(false, 0)
		end
	end

	local cancel = MakeCloseCross(ov, ov:GetWide() - gRespX(104), gRespY(40), function()
		ov:Remove()
	end)
	cancel:SetZPos(32000)
end

-- ── Assassin : catalogue de pièges et grenades, verrouillé par niveau ─────────
BuildAssassinPanel = function(pnl, r, padX)
	local w = pnl:GetWide()
	local tGear = EVO_CRAFT.AssassinGear or {}
	local nLvl = EVO_CRAFT.LevelFromXP(tState.xp or 0)

	local function CountInBag(sKey)
		local lp = LocalPlayer()
		if IsValid(lp) and lp.CountInventoryItem then
			return lp:CountInventoryItem(sKey)
		end
		return EVO_CRAFT.CountBagItem(nil, sKey)
	end

	-- QUANTITÉ du lot (craft en série, user 09/15) : persiste sur le cadre comme
	-- la sélection ; bornée par CFG.MaxBatch, revalidée serveur.
	local nMaxBatch = math.min((EVO_CRAFT.CFG and EVO_CRAFT.CFG.MaxBatch) or 10, 31) -- 5 bits sur le net
	local function Qty()
		return math.Clamp(math.floor(tonumber(frame and frame._craftQty) or 1), 1, nMaxBatch)
	end
	local function SetQty(n)
		if not IsValid(frame) then return end
		frame._craftQty = math.Clamp(math.floor(tonumber(n) or 1), 1, nMaxBatch)
	end
	-- Lot maximal couvert par le sac ET les yens pour la pièce g (>= 1 pour que
	-- le bouton continue d'expliquer ce qui manque).
	local function MaxCraftable(g)
		local nMax = nMaxBatch
		for id, n in pairs(g.mats or {}) do
			nMax = math.min(nMax, math.floor(CountInBag(id) / math.max(1, n)))
		end
		if (g.cost or 0) > 0 then
			nMax = math.min(nMax, math.floor(LocalPlayer():GetEvoNWInt("Money", 0) / g.cost))
		end
		return math.max(1, nMax)
	end

	-- TOUT le catalogue est visible (user 08/20, annule le masquage 08/19) :
	-- les plans pas encore débloqués s'affichent en GRISÉ avec leur niveau.
	local tVisible, nNextLvl = tGear, nil
	for _, g in ipairs(tGear) do
		local nReq = g.level or 1
		if nLvl < nReq and (not nNextLvl or nReq < nNextLvl) then nNextLvl = nReq end
	end

	local lblSec = vgui.Create("DLabel", pnl)
	lblSec:SetFont("Bebas Neue:30")
	lblSec:SetTextColor(COL_GOLD)
	lblSec:SetText("MATÉRIEL DE LA DIVISION  (NIVEAU D'ATELIER " .. nLvl .. ")"
		.. (nNextLvl and ("   ·   PROCHAIN PLAN AU NIVEAU " .. nNextLvl) or ""))
	lblSec:SizeToContents()
	lblSec:SetPos(padX, gRespY(112))

	-- 2 rangées de cartes (276 + 14 de gouttière) : la grille tient SANS scroll.
	local gridY, gridH = gRespY(154), gRespY(570)
	local grid = vgui.Create("DScrollPanel", pnl)
	grid:SetPos(padX, gridY)
	grid:SetSize(w - padX * 2, gridH)
	grid.Paint = nil

	local RefreshSel -- déclaré avant : les clics des cartes rafraîchissent le pied de page

	local cardW, cardH, gap = gRespX(212), gRespY(276), gRespX(14)
	local perRow = math.max(1, math.floor((w - padX * 2) / (cardW + gap)))
	for i, g in ipairs(tVisible) do
		local it = ITEMS and ITEMS[g.key]
		local card = vgui.Create("DButton", grid)
		card:SetText("")
		card:SetSize(cardW, cardH)
		card:SetPos(((i - 1) % perRow) * (cardW + gap), math.floor((i - 1) / perRow) * (cardH + gap))

		local holder = vgui.Create("DPanel", card)
		holder:SetPos(gRespX(10), gRespY(14))
		holder:SetSize(cardW - gRespX(20), gRespY(136))
		holder.Paint = nil
		-- ⚠ Sans ça le porte-aperçu AVALE les clics : la moitié haute de la
		-- carte ne sélectionnait pas (user 08/19 « toute la case »).
		holder:SetMouseInputEnabled(false)
		if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel and it then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(holder, AssassinPreviewItem(it))
		end
		card.Think = function()
			local mp = holder._modelPanel
			if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
		end

		local rc = RARITY_COLORS[g.rarity or "common"] or RARITY_COLORS.common
		local rcBar = Color(rc.r, rc.g, rc.b, 235)
		-- « La corde n'est pas une grenade » (user 08/19) : étiquette par kind.
		local sKind = g.kind == "piege" and "PIÈGE"
			or (g.kind == "grenade" and "GRENADE" or "MATÉRIAU")
		local bLock = nLvl < (g.level or 1)
		card.Paint = function(s, cw, ch)
			local bSel = not bLock and frame and frame._selGear == g.key
			local nOwn = CountInBag(g.key)
			RNDX.Draw(gRespY(12), 0, 0, cw, ch, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
			if bSel then
				RNDX.Draw(gRespY(12), 0, 0, cw, ch, COL_ACC_WASH)
				RNDX.DrawOutlined(gRespY(12), 0, 0, cw, ch, COL_ACCENT, gRespY(2))
			end
			RNDX.Draw(gRespY(3), gRespX(10), gRespY(6), cw - gRespX(20), gRespY(5), rcBar)
			draw.SimpleText(sKind, "Bebas Neue:18", cw - gRespX(12), gRespY(22),
				COL_GOLD, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			draw.SimpleText(g.name, "Bebas Neue:24", cw / 2, gRespY(172),
				COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if bLock then
				draw.SimpleText("Plan verrouillé", "Avenir Next World:16", cw / 2, gRespY(240),
					COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				return
			end
			if MUGEN and MUGEN.DrawMoney then
				MUGEN.DrawMoney(g.cost, "Bebas Neue:22", cw / 2, gRespY(206),
					COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			draw.SimpleText(nOwn > 0 and ("x" .. nOwn .. " en sac") or "aucun en sac", "Avenir Next World:16",
				cw / 2, gRespY(240), nOwn > 0 and COL_STRIKE_GOOD or COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		if bLock then
			-- PaintOver passe PAR-DESSUS l'aperçu 3D : voile + niveau requis.
			card.PaintOver = function(_, cw, ch)
				RNDX.Draw(gRespY(12), 0, 0, cw, ch, COL_LOCK_WASH)
				draw.SimpleText("NIVEAU " .. (g.level or 1), "Bebas Neue:34", cw / 2, gRespY(78),
					COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		card.DoClick = function()
			if bLock then
				notification.AddLegacy("Plan verrouillé : atelier niveau " .. (g.level or 1) .. " requis.",
					NOTIFY_HINT, 3)
				surface.PlaySound(SND_MISS)
				return
			end
			frame._selGear = g.key
			if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
			if RefreshSel then RefreshSel() end
		end
	end

	-- Pied de page : effet + matériaux + description de la sélection.
	local footY = gridY + gridH + gRespY(16)
	local lblEffect = vgui.Create("DLabel", pnl)
	lblEffect:SetFont("Black Han Sans:20")
	lblEffect:SetTextColor(COL_GOLD)
	lblEffect:SetPos(padX, footY)
	lblEffect:SetSize(w - padX * 2 - gRespX(300), gRespY(26))

	-- CHIPS de matériaux (user 08/19 « plus visuel ») : une pastille par
	-- ressource, aperçu 3D + quantité, VERTE quand le sac couvre, rouge sinon.
	local matsRow = vgui.Create("DPanel", pnl)
	matsRow:SetPos(padX, footY + gRespY(28))
	matsRow:SetSize(w - padX * 2 - gRespX(300), gRespY(58))
	matsRow:SetPaintBackground(false)

	local COL_OK_WASH  = Color(96, 220, 130, 26)
	local COL_BAD_WASH = Color(230, 90, 80, 22)
	local function BuildMatChips(g)
		matsRow:Clear()
		if not istable(g.mats) or next(g.mats) == nil then return end
		local x = 0
		for _, id in ipairs(EVO_CRAFT.ResourceOrder or {}) do
			local n = g.mats[id]
			if n then
				local chip = vgui.Create("DPanel", matsRow)
				chip:SetPos(x, 0)
				chip:SetSize(gRespX(196), gRespY(58))
				chip:SetPaintBackground(false)
				chip.Paint = function(_, cw2, chh)
					local nHave = CountInBag(id)
					local nNeed = n * Qty() -- lot courant (craft en série)
					local bOk = nHave >= nNeed
					RNDX.Draw(gRespY(10), 0, 0, cw2, chh, COL_SUB)
					RNDX.Draw(gRespY(10), 0, 0, cw2, chh, bOk and COL_OK_WASH or COL_BAD_WASH)
					RNDX.DrawOutlined(gRespY(10), 0, 0, cw2, chh,
						bOk and COL_STRIKE_GOOD or COL_STRIKE_BAD, gRespY(2))
					draw.SimpleText(string.format("%d× %s", nNeed, EVO_CRAFT.ResourceName(id)),
						"Avenir Next World:17", gRespX(62), chh / 2 - gRespY(11),
						COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText("x" .. nHave .. " en sac", "Avenir Next World:15", gRespX(62), chh / 2 + gRespY(12),
						bOk and COL_STRIKE_GOOD or COL_STRIKE_BAD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				local hv = vgui.Create("DPanel", chip)
				hv:SetPos(gRespX(8), gRespY(5))
				hv:SetSize(gRespY(48), gRespY(48))
				hv:SetMouseInputEnabled(false)
				hv.Paint = nil
				local itRes = ITEMS and ITEMS[id]
				if itRes and LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel then
					LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(hv, AssassinPreviewItem(itRes))
				end
				chip.Think = function()
					local mp = hv._modelPanel
					if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
				end
				x = x + gRespX(206)
			end
		end
	end

	local lblDesc = vgui.Create("DLabel", pnl)
	lblDesc:SetFont("Avenir Next World:19")
	lblDesc:SetTextColor(COL_MUTED)
	lblDesc:SetWrap(true)
	lblDesc:SetPos(padX, footY + gRespY(94))
	lblDesc:SetSize(w - padX * 2 - gRespX(300), gRespY(52))

	RefreshSel = function()
		local g = frame and frame._selGear and EVO_CRAFT.AssassinGearByKey(frame._selGear)
		if g then
			lblEffect:SetText(g.effect or "")
			BuildMatChips(g)
			lblDesc:SetText(g.desc or "")
		else
			lblEffect:SetText("Sélectionne un équipement : le craft rapporte de l'XP d'atelier.")
			matsRow:Clear()
			lblDesc:SetText("")
		end
	end
	RefreshSel()

	-- Ce qui bloque le craft de la sélection courante : nil = tout est bon.
	-- Source UNIQUE du bouton (libellé d'état) ET du clic (message de refus) —
	-- user 08/19 : « quand tu peux pas crafter, ça doit te dire ».
	local function CraftBlock()
		local g = frame and frame._selGear and EVO_CRAFT.AssassinGearByKey(frame._selGear)
		if not g then return nil, "Choisis un équipement à fabriquer.", "CRAFTER" end
		local nQ = Qty()
		for id, n in pairs(g.mats or {}) do
			local nHave = CountInBag(id)
			if nHave < n * nQ then
				return g, string.format("Il te manque des matériaux : %d× %s (tu en as %d).",
					n * nQ, EVO_CRAFT.ResourceName(id), nHave), "MATÉRIAUX MANQUANTS"
			end
		end
		if (g.cost or 0) > 0 and LocalPlayer():GetEvoNWInt("Money", 0) < g.cost * nQ then
			return g, string.format("Pas assez de yens (%d requis).", g.cost * nQ), "YENS INSUFFISANTS"
		end
		return g, nil, nQ > 1 and ("CRAFTER ×" .. nQ) or "CRAFTER"
	end

	-- QUANTITÉ (craft en série, user 09/15) : [−] ×N [+] [MAX] juste au-dessus de
	-- CRAFTER. Les pastilles de matériaux et le bouton suivent le lot en direct.
	do
		local qx = w - padX - gRespX(300)
		local qy = pnl:GetTall() - gRespY(92) - gRespY(58)
		local qh = gRespY(48)
		local function QtyBtn(x, bw, sTxt, sFont, fn)
			local b = vgui.Create("DButton", pnl)
			b:SetText("")
			b:SetSize(bw, qh)
			b:SetPos(x, qy)
			b.Paint = function(s, bw2, bh)
				RNDX.Draw(gRespY(10), 0, 0, bw2, bh, s:IsHovered() and COL_SUB_HI or COL_SUB)
				draw.SimpleText(sTxt, sFont, bw2 / 2, bh / 2, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				fn()
				if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
			end
			return b
		end
		QtyBtn(qx, gRespX(52), "−", "Bebas Neue:30", function() SetQty(Qty() - 1) end)
		local lblQty = vgui.Create("DPanel", pnl)
		lblQty:SetPos(qx + gRespX(58), qy)
		lblQty:SetSize(gRespX(120), qh)
		lblQty:SetPaintBackground(false)
		lblQty.Paint = function(_, bw, bh)
			RNDX.Draw(gRespY(10), 0, 0, bw, bh, COL_SUB)
			local nQ = Qty()
			draw.SimpleText("×" .. nQ, "Bebas Neue:30", bw / 2, bh / 2 - gRespY(7),
				nQ > 1 and COL_ACCENT or COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(nQ > 1 and "exemplaires" or "exemplaire", "Avenir Next World:13", bw / 2, bh - gRespY(11),
				COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		QtyBtn(qx + gRespX(184), gRespX(52), "+", "Bebas Neue:30", function() SetQty(Qty() + 1) end)
		QtyBtn(qx + gRespX(242), gRespX(58), "MAX", "Bebas Neue:22", function()
			local g = frame and frame._selGear and EVO_CRAFT.AssassinGearByKey(frame._selGear)
			if g then SetQty(MaxCraftable(g)) end
		end)
	end

	-- CRAFTER = pré-checks puis MINI-JEU d'assemblage ; le net Do ne part qu'en
	-- cas de réussite (2 coups sur 3), un raté ne dépense RIEN. Le bouton DIT
	-- l'état en continu et le clic explique toujours le refus.
	local btnCraft = vgui.Create("DButton", pnl)
	btnCraft:SetText("")
	btnCraft:SetSize(gRespX(300), gRespY(58))
	btnCraft:SetPos(w - padX - gRespX(300), pnl:GetTall() - gRespY(92))
	btnCraft._hf = 0
	btnCraft.Think = function(s)
		if (s._next or 0) > CurTime() then return end
		s._next = CurTime() + 0.25
		local _, sErr, sLabel = CraftBlock()
		s._on, s._label = sErr == nil, sLabel or "CRAFTER"
	end
	btnCraft.Paint = function(s, bw, bh)
		local bOn = s._on
		s._hf = Lerp(FrameTime() * 10, s._hf, (bOn and s:IsHovered()) and 1 or 0)
		local k = 1 + s._hf * 0.18
		RNDX.Draw(gRespY(10), 0, 0, bw, bh, bOn
			and Color(math.min(255, COL_ACCENT.r * k), math.min(255, COL_ACCENT.g * k), math.min(255, COL_ACCENT.b * k))
			or COL_SUB)
		draw.SimpleText(s._label or "CRAFTER", "Bebas Neue:30", bw / 2, bh / 2,
			bOn and COL_TITLE or COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	btnCraft.DoClick = function()
		local g, sErr = CraftBlock()
		if sErr then
			notification.AddLegacy(sErr, NOTIFY_ERROR, 4)
			surface.PlaySound(SND_MISS)
			return
		end
		if not g then return end
		OpenAssassinGame(r.id, g, Qty())
	end
end

-- ── Cadre plein écran ────────────────────────────────────────────────────────
local function MakeFrame()
	if IsValid(frame) then frame:Remove() end
	if not tState then return end
	local sRole = tState.role

	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end -- APRÈS MakePopup

	local sTitle = "ATELIER " .. EVO_CRAFT.RoleLabel(sRole)
	frame.Paint = function(s, w, h)
		-- Couche PLATE plein écran : flou RNDX léger + voile sombre (jamais de
		-- pp/blurscreen par frame). Les 4 rayons de coins sont OBLIGATOIRES
		-- (nil = crash math_clamp dans rndx) : 0 partout = rectangle plat.
		RNDX.DrawBlur(0, 0, w, h, nil, 0, 0, 0, 0)
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)
		-- Header : gros titre + barre d'accent + sous-titre.
		local padX = gRespX(70)
		draw.SimpleText(sTitle, "Bebas Neue:68", padX, gRespY(70), COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:68")
		local tw = surface.GetTextSize(sTitle)
		RNDX.Draw(gRespY(2), padX, gRespY(108), tw, gRespY(5), COL_ACCENT)
		draw.SimpleText("Poste de travail de la division. Progression personnelle du personnage.",
			"Avenir Next World:20", padX + tw + gRespX(30), gRespY(78), COL_DIMTXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	MakeCloseCross(frame, ScrW() - gRespX(104), gRespY(44), function() frame:Remove() end)

	-- ── Colonne gauche : le ROND DE CRAFT (niveau personnel) + recettes ──────
	local ring = vgui.Create("DPanel", frame)
	ring:SetPos(gRespX(70), gRespY(150))
	ring:SetSize(gRespX(440), gRespY(430))
	local cacheBg, cacheFg = {}, {}
	ring.Paint = function(s, w, h)
		RNDX.DrawShadows(gRespY(18), 0, 0, w, h, COL_SHADOW, gRespY(14), 16)
		RNDX.Draw(gRespY(18), 0, 0, w, h, COL_CARD)
		local nLvl, nInto, nNeed = EVO_CRAFT.LevelFromXP(tState.xp or 0)
		local cx, cy = w / 2, gRespY(210)
		local rOut, rIn = gRespX(142), gRespX(122)
		draw.SimpleText("NIVEAU DE CRAFT", "Bebas Neue:32", cx, gRespY(38), COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		DrawRingArc(cx, cy, rIn, rOut, 1, COL_RING_BG, cacheBg)
		local frac = nNeed > 0 and (nInto / nNeed) or 1
		DrawRingArc(cx, cy, rIn, rOut, frac, COL_ACCENT, cacheFg)
		draw.SimpleText(tostring(nLvl), "Bebas Neue:100", cx, cy - gRespY(8), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("/ " .. EVO_CRAFT.MaxLevel, "Bebas Neue:30", cx, cy + gRespY(56), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local sXP = nNeed > 0 and string.format("%d / %d XP", nInto, nNeed) or "NIVEAU MAXIMUM"
		draw.SimpleText(sXP, "Bebas Neue:30", cx, gRespY(392), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Pastille « ? » (user 08/18) : ce que fait le niveau de craft, en bref, au
	-- survol. Lignes par rayon, chiffres tirés de la config partagée (jamais en dur).
	local tTipLines = { "Progression du personnage, propre à cet atelier." }
	if sRole == "combat" then
		tTipLines[#tTipLines + 1] = string.format("Monte en enchantant (+%d XP par réussite).",
			EVO_CRAFT.EnchantCfg.XP or 25)
		tTipLines[#tTipLines + 1] = "Le niveau plafonne la puissance des tirages."
		tTipLines[#tTipLines + 1] = string.format("Niveau %d : un 2e enchantement s'ajoute au lieu de remplacer.",
			EVO_CRAFT.EnchantCfg.SecondSlotLevel or 20)
	elseif sRole == "assassin" then
		tTipLines[#tTipLines + 1] = "Monte en fabriquant à l'atelier."
		tTipLines[#tTipLines + 1] = "Le niveau débloque les équipements du catalogue."
	else
		tTipLines[#tTipLines + 1] = "Monte avec les crafts de l'atelier."
	end

	local tip = vgui.Create("DPanel", frame)
	tip:SetVisible(false)
	tip:SetZPos(32000)
	surface.SetFont("Avenir Next World:19")
	local nTipW = 0
	for _, l in ipairs(tTipLines) do
		nTipW = math.max(nTipW, (surface.GetTextSize(l)))
	end
	local nLineH = gRespY(27)
	tip:SetSize(nTipW + gRespX(36), #tTipLines * nLineH + gRespY(24))
	tip.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintTooltip then
			EVO_UI.PaintTooltip(0, 0, w, h)
		else
			RNDX.Draw(gRespY(12), 0, 0, w, h, COL_SUB_HI)
		end
		for i, l in ipairs(tTipLines) do
			draw.SimpleText(l, "Avenir Next World:19", gRespX(18),
				gRespY(12) + (i - 1) * nLineH + nLineH / 2,
				i == 1 and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local info = vgui.Create("DButton", ring)
	info:SetText("")
	local nInfoSz = gRespX(34)
	info:SetSize(nInfoSz, nInfoSz)
	info:SetPos(ring:GetWide() - nInfoSz - gRespX(18), gRespY(18))
	info.Paint = function(s, w, h)
		local bHov = s:IsHovered()
		RNDX.DrawCircleOutlined(w / 2, h / 2, w / 2 - gRespX(2),
			bHov and COL_ACCENT or COL_DIMTXT, gRespY(2))
		draw.SimpleText("?", "Bebas Neue:24", w / 2, h / 2,
			bHov and COL_TITLE or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	-- Le frame est plein écran en (0,0) : coords écran = coords frame.
	info.OnCursorEntered = function(s)
		local x, y = s:LocalToScreen(0, s:GetTall() + gRespY(8))
		tip:SetPos(x + s:GetWide() - tip:GetWide(), y)
		tip:SetVisible(true)
	end
	info.OnCursorExited = function() tip:SetVisible(false) end

	local recipesCard = vgui.Create("DPanel", frame)
	recipesCard:SetPos(gRespX(70), gRespY(600))
	recipesCard:SetSize(gRespX(440), gRespY(440))
	recipesCard.Paint = function(_, w, h)
		RNDX.DrawShadows(gRespY(18), 0, 0, w, h, COL_SHADOW, gRespY(14), 16)
		RNDX.Draw(gRespY(18), 0, 0, w, h, COL_CARD)
		draw.SimpleText("RECETTES", "Bebas Neue:32", gRespX(26), gRespY(34), COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local list = vgui.Create("DScrollPanel", recipesCard)
	list:SetPos(gRespX(18), gRespY(64))
	list:SetSize(gRespX(404), gRespY(358))
	list.Paint = nil

	-- ── Zone de droite : détail de la recette sélectionnée ───────────────────
	local detail = vgui.Create("DPanel", frame)
	detail:SetPos(gRespX(560), gRespY(150))
	detail:SetSize(gRespX(1290), gRespY(890))
	detail.Paint = function(_, w, h)
		RNDX.DrawShadows(gRespY(18), 0, 0, w, h, COL_SHADOW, gRespY(14), 16)
		RNDX.Draw(gRespY(18), 0, 0, w, h, COL_CARD)
	end
	frame._detail = detail

	local nSel = 1
	local function Select(i)
		nSel = i
		frame._selRecipe = tState.recipes[i]
		BuildDetail(detail, frame._selRecipe)
	end

	for i, r in ipairs(tState.recipes) do
		local row = list:Add("DButton")
		row:SetText("")
		row:Dock(TOP)
		row:DockMargin(0, 0, gRespX(6), gRespY(10))
		row:SetTall(gRespY(70))
		row.Paint = function(s, pw, ph)
			local bSel = nSel == i
			RNDX.Draw(gRespY(10), 0, 0, pw, ph, (bSel or s:IsHovered()) and COL_SUB_HI or COL_SUB)
			if bSel then
				RNDX.Draw(gRespY(10), 0, 0, pw, ph, COL_ACC_WASH)
				RNDX.Draw(gRespY(2), gRespX(8), gRespY(12), gRespX(4), ph - gRespY(24), COL_ACCENT)
			end
			draw.SimpleText(r.name, "Bebas Neue:26", gRespX(24), ph / 2,
				bSel and COL_TITLE or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if not r.ready then
				draw.SimpleText("À VENIR", "Bebas Neue:20", pw - gRespX(16), ph / 2,
					COL_DIMTXT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		row.DoClick = function()
			if EVO_UI and EVO_UI.PlayDraw then EVO_UI.PlayDraw() end
			Select(i)
		end
	end

	-- Refresh live (après un enchantement) : le rond lit tState en Paint, seule
	-- la zone de droite doit se reconstruire (elle fige l'état à la création).
	frame.RefreshState = function()
		if frame._selRecipe then BuildDetail(detail, frame._selRecipe) end
	end

	-- Saut d'onglet PROGRAMMATIQUE (le carnet médical renvoie au mortier).
	frame.SelectRecipeById = function(sId)
		for i2, r2 in ipairs(tState.recipes) do
			if r2.id == sId then Select(i2) return true end
		end
		return false
	end

	Select(1)
end

function EVO_CRAFT.SelectRecipeById(sId)
	if IsValid(frame) and frame.SelectRecipeById then return frame.SelectRecipeById(sId) end
	return false
end

net.Receive("EVO:Craft:Open", function()
	local sRole = net.ReadString()
	local n = net.ReadUInt(6)
	local tRecipes = {}
	for i = 1, n do
		tRecipes[i] = {
			id    = net.ReadString(),
			name  = net.ReadString(),
			desc  = net.ReadString(),
			ready = net.ReadBool(),
		}
	end
	local nXP = net.ReadUInt(32)
	local nT = net.ReadUInt(16)
	local tTargets = {}
	for i = 1, nT do
		tTargets[i] = {
			slot = net.ReadUInt(16),
			item = net.ReadString(),
			ench = net.ReadString(),
		}
	end
	tState = { role = sRole, recipes = tRecipes, xp = nXP, targets = tTargets }
	MakeFrame()
end)

-- Refresh live : XP du rôle + enchant d'un slot (après un craft réussi).
net.Receive("EVO:Craft:Sync", function()
	local sRole = net.ReadString()
	local nXP = net.ReadUInt(32)
	local nSlot = net.ReadUInt(16)
	local sEnch = net.ReadString()
	if not tState or tState.role ~= sRole then return end
	tState.xp = nXP
	if nSlot > 0 then
		for _, t in ipairs(tState.targets or {}) do
			if t.slot == nSlot then
				t.ench = sEnch
				break
			end
		end
	end
	if IsValid(frame) and frame.RefreshState then frame.RefreshState() end
	-- Mini-jeu de forge en attente sur CE slot : afficher le résultat gravé.
	if IsValid(frame) and frame._forgePending and frame._forgePending.slot == nSlot then
		frame._forgePending = nil
		local ov = frame._forgeOverlay
		if IsValid(ov) and ov.ShowResult then ov.ShowResult(sEnch) end
	end
end)

-- Touche E dans le cylindre : le serveur revalide zone + division de toute façon.
hook.Add("PlayerButtonDown", "EVO_Craft::UseKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if IsValid(frame) then return end
	if EVO_CRAFT.CurrentStation(ply) then
		net.Start("EVO:Craft:Use")
		net.SendToServer()
	end
end)
