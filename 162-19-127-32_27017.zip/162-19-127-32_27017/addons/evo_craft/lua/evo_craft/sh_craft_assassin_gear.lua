-- "addons\\evo_craft\\lua\\evo_craft\\sh_craft_assassin_gear.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Rayon ASSASSIN (Division 2 / Ordre 2) : catalogue de l'équipement de l'ombre.
-- Config PARTAGÉE : l'atelier client affiche exactement ce que le serveur craft.
-- Le CRAFT est réservé à la division (gates sv_main), l'UTILISATION est libre :
-- un assassin peut vendre ses grenades, c'est voulu (économie de division).

EVO_CRAFT = EVO_CRAFT or {}

local MDL_OURS  = "models/evo/props/items/evo_zefrqfer3grefrzedr/evo_zefrqfer3grefrzedr.mdl"
local MDL_PICS  = "models/evo/props/items/evo_zder3gzed54edezfer/evo_zder3gzed54edezfer.mdl"
local MDL_BOMBE = "models/evo/props/items/evo_zeff55354qerfedzgrt/evo_zeff55354qerfedzgrt.mdl"
local MDL_GREN  = "models/evo/props/items/evo_sg3rgqerfhddzk526t/evo_sg3rgqerfhddzk526t.mdl"
local MDL_FIL   = "models/evo/props/items/evo_zed36gzedrefpmolikujyhg/evo_zed36gzedREFPMolikujyhg.mdl"

EVO_CRAFT.AssassinModels = {
	ours = MDL_OURS, pics = MDL_PICS, bombe = MDL_BOMBE, grenade = MDL_GREN, fil = MDL_FIL,
}

-- ============================================================================
-- ÉQUILIBRAGE CENTRALISÉ : les entités et sv_craft_assassin lisent ICI, et les
-- textes d'effet du catalogue sont FORMATÉS depuis ces valeurs : rééquilibrer ne
-- peut pas désynchroniser les descriptions (recette « MAJ desc » des sorts).
-- ============================================================================
EVO_CRAFT.AssassinCfg = {
	GrenadeCD    = 5,    -- s entre deux jets (tous types)
	PiegeCD      = 2.5,  -- s entre deux poses
	MaxTraps     = 4,    -- pièges actifs par joueur, tous types confondus
	GrenadeFuse  = 1.9,  -- s de mèche après le jet
	TrapArmDelay = 3,    -- s avant qu'un piège posé ne devienne actif (1,2 -> 3, user 08/18)
	TrapLifetime = 300,  -- s au sol avant expiration d'un piège non déclenché
	AimWindow    = 8,    -- s de fenêtre de VISÉE (1er usage = preview, 2e = exécution)

	Fumigene = { dur = 14, clouds = 12, spread = 45 },
	Bombe    = { dmgMax = 55, dmgMin = 15, radius = 260 },
	Toxique  = { dur = 8, tick = 1, dmg = 4, radius = 170 },
	-- Glace = mini VOILE DE NEIGE (recette Hitsugaya Spell 4) : zone au point
	-- d'impact, brouillard givré + slow + petits ticks + props de glace.
	Glace    = { dur = 6, tick = 1, dmg = 2, radius = 220, slowScale = 0.5, props = 3 },
	-- Feu = CALCINATION Yamamoto sur quiconque traverse (dmg/igniteSec = repli
	-- si le spell system n'est pas chargé).
	Feu      = { dur = 6, tick = 0.8, dmg = 4, radius = 160, igniteSec = 1.2 },
	Magique  = { radius = 380, fullSec = 3, grazeSec = 1 },
	Ours     = { radius = 34, dmg = 32, rootSec = 2.6 },
	Pics     = { radius = 40, dmg = 20, bleedDmg = 4, bleedTicks = 4, bleedEvery = 1.5,
	             slowDur = 3, slowScale = 0.6, charges = 3, rearm = 2.6 },
	-- Fil = DÉTECTION pure (user 08/19) : deux piquets, un fil tendu entre les
	-- deux (maxLen max), quiconque le touche est RÉVÉLÉ revealSec s à travers
	-- tout pour le poseur (surbrillance Target Mark de Soifon, EVO::WallHackEffect).
	-- armDist (08/22) : distance à un piquet pour ACCROCHER une grenade au fil.
	Fil      = { maxLen = 1000, revealSec = 5, trigDist = 24, wireH = 12, armDist = 120 }, -- 300 -> 1000 (user 08/19)
}
local C = EVO_CRAFT.AssassinCfg

-- ── Plan d'ÉQUILIBRAGE IN-GAME (éditeur spell_balance, fiches hors sort) ─────
-- Chemin dans AssassinCfg -> clé plate de l'éditeur. Lu par la fiche
-- « Assassin_* » de sv_spell_config_editor : régler en jeu MUTE AssassinCfg
-- serveur (tout la lit en direct), persistance MySQL de l'éditeur. ⚠ Comme les
-- fiches Dot/Grade/Style, les valeurs BDD ne redescendent PAS dans ce fichier :
-- reporter ici les réglages validés (les textes d'effet sont formés d'ici).
EVO_CRAFT.AssassinFiches = {
	{ id = "Assassin_Communs", nom = "Assassin · Communs", champs = {
		{ chemin = { "GrenadeCD" },    var = "nCdGrenade" },
		{ chemin = { "PiegeCD" },      var = "nCdPiege" },
		{ chemin = { "MaxTraps" },     var = "nMaxPieges" },
		{ chemin = { "GrenadeFuse" },  var = "nFuseSec" },
		{ chemin = { "TrapArmDelay" }, var = "nArmDelay" },
		{ chemin = { "TrapLifetime" }, var = "nLifetime" },
		{ chemin = { "AimWindow" },    var = "nAimWindow" },
	} },
	{ id = "Assassin_Fumigene", nom = "Assassin · Grenade fumigène", champs = {
		{ chemin = { "Fumigene", "dur" },    var = "nDuration" },
		{ chemin = { "Fumigene", "clouds" }, var = "nClouds" },
		{ chemin = { "Fumigene", "spread" }, var = "nSpread" },
	} },
	{ id = "Assassin_Bombe", nom = "Assassin · Bombe artisanale", champs = {
		{ chemin = { "Bombe", "dmgMax" }, var = "nDamage" },
		{ chemin = { "Bombe", "dmgMin" }, var = "nMinDamage" },
		{ chemin = { "Bombe", "radius" }, var = "nRadius" },
	} },
	{ id = "Assassin_Toxique", nom = "Assassin · Grenade toxique", champs = {
		{ chemin = { "Toxique", "dur" },    var = "nDuration" },
		{ chemin = { "Toxique", "tick" },   var = "nTickRate" },
		{ chemin = { "Toxique", "dmg" },    var = "nDamage" },
		{ chemin = { "Toxique", "radius" }, var = "nRadius" },
	} },
	{ id = "Assassin_Glace", nom = "Assassin · Grenade de glace", champs = {
		{ chemin = { "Glace", "dur" },       var = "nDuration" },
		{ chemin = { "Glace", "tick" },      var = "nTickRate" },
		{ chemin = { "Glace", "dmg" },       var = "nDamage" },
		{ chemin = { "Glace", "radius" },    var = "nRadius" },
		{ chemin = { "Glace", "slowScale" }, var = "nSlowMult" },
		{ chemin = { "Glace", "props" },     var = "nProps" },
	} },
	{ id = "Assassin_Feu", nom = "Assassin · Grenade incendiaire", champs = {
		{ chemin = { "Feu", "dur" },       var = "nDuration" },
		{ chemin = { "Feu", "tick" },      var = "nTickRate" },
		{ chemin = { "Feu", "dmg" },       var = "nDamage" },
		{ chemin = { "Feu", "radius" },    var = "nRadius" },
		{ chemin = { "Feu", "igniteSec" }, var = "nIgniteSec" },
	} },
	{ id = "Assassin_Spirituelle", nom = "Assassin · Grenade spirituelle", champs = {
		{ chemin = { "Magique", "radius" },   var = "nRadius" },
		{ chemin = { "Magique", "fullSec" },  var = "nFlashPlein" },
		{ chemin = { "Magique", "grazeSec" }, var = "nFlashCourt" },
	} },
	{ id = "Assassin_PiegeOurs", nom = "Assassin · Piège à ours", champs = {
		{ chemin = { "Ours", "radius" },  var = "nRadius" },
		{ chemin = { "Ours", "dmg" },     var = "nDamage" },
		{ chemin = { "Ours", "rootSec" }, var = "nRootSec" },
	} },
	{ id = "Assassin_PiegeFil", nom = "Assassin · Piège à fil", champs = {
		{ chemin = { "Fil", "maxLen" },    var = "nRange" },
		{ chemin = { "Fil", "revealSec" }, var = "nDuration" },
		{ chemin = { "Fil", "trigDist" },  var = "nRadius" },
		{ chemin = { "Fil", "armDist" },   var = "nArmDist" },
	} },
	{ id = "Assassin_PiegePics", nom = "Assassin · Piège à pics", champs = {
		{ chemin = { "Pics", "radius" },     var = "nRadius" },
		{ chemin = { "Pics", "dmg" },        var = "nDamage" },
		{ chemin = { "Pics", "bleedDmg" },   var = "nBleedDamage" },
		{ chemin = { "Pics", "bleedTicks" }, var = "nBleedTicks" },
		{ chemin = { "Pics", "bleedEvery" }, var = "nBleedRate" },
		{ chemin = { "Pics", "slowDur" },    var = "nSlowDur" },
		{ chemin = { "Pics", "slowScale" },  var = "nSlowMult" },
		{ chemin = { "Pics", "charges" },    var = "nCharges" },
		{ chemin = { "Pics", "rearm" },      var = "nRearm" },
	} },
}

-- 4.5 -> "4,5" (textes joueurs en français).
local function frnum(n)
	return (tostring(n):gsub("%.", ","))
end

-- kind "piege" = pose au sol devant soi, "grenade" = jet, "materiau" = simple
-- ressource craftée (pas d'on_use, item défini par sh_craft_resources). gtype =
-- comportement de l'entité (et skin du modèle général : 0 toxic, 1 fumée,
-- ÉQUILIBRAGE 08/21 ×2 (user « drastiquement » puis « beaucoup plus encore ») : chaque
-- craft exige 3-4 ressources différentes à gros volumes, les os moyens/gros et
-- la corde (elle-même craftée) sont devenus centraux — farm + chaîne d'intermédiaires.
-- RÉÉQUILIBRAGE 09/23 (retour joueur) : la corde passe au BOIS SEUL et les recettes de
-- base lâchent leurs petits os pour la roche et le métal. Les os gardent leur rôle via
-- la fusion (os moyens, gros os) qui signe les objets rares, inchangés.
-- 2 magie, 3 glace, 4 feu). level = niveau de craft assassin requis, cost =
-- yens, mats = ressources consommées (res_*), xp = XP d'atelier gagnée.
EVO_CRAFT.AssassinGear = {
	{ key = "res_corde", kind = "materiau",
	  name = "Corde", model = "models/evo/props/items/resources/corde/evo_eca7617433d50ba6c0.mdl",
	  skin = 0, rarity = "common",
	  level = 1, cost = 0, xp = 8,
	  mats = { res_petit_os = 4 }, -- 10/03 (user) : 4 petits os SEULS ; 6 bois = introuvable (09/23 : bois seul)
	  effect = "Matériau d'artisanat : tend les pièges à pics, à ours et l'incendiaire.",
	  desc = "Fibres d'écorce torsadées puis goudronnées. La base de tout le reste." },

	{ key = "assassin_grenade_fumigene", kind = "grenade", gtype = "fumigene",
	  name = "Grenade fumigène", model = MDL_GREN, skin = 1, rarity = "rare",
	  level = 1, cost = 250, xp = 12,
	  mats = { res_bois = 10, res_roche = 12 },
	  effect = string.format("Épais écran de fumée pendant %d secondes. Aucun dégât.", C.Fumigene.dur),
	  desc = "Verre soufflé rempli de poudre occultante. La signature des assassins : on ne combat pas ce qu'on ne voit pas." },

	{ key = "assassin_piege_pics", kind = "piege", gtype = "pics",
	  name = "Piège à pics", model = MDL_PICS, skin = 0, rarity = "rare",
	  level = 3, cost = 400, xp = 15,
	  mats = { res_bois = 12, res_roche = 12, res_corde = 4, res_metal_brut = 4 },
	  effect = string.format("Pics dissimulés : %d dégâts, saignement et ralentissement. %d déclenchements.",
		C.Pics.dmg, C.Pics.charges),
	  desc = "Une plaque discrète aux pics rétractés. Se pose au sol et se récupère tant qu'elle n'a pas mordu." },

	{ key = "assassin_piege_ours", kind = "piege", gtype = "ours",
	  name = "Piège à ours", model = MDL_OURS, skin = 0, rarity = "epic",
	  level = 6, cost = 600, xp = 18,
	  mats = { res_metal_brut = 12, res_roche = 10, res_corde = 6, res_os_moyen = 5 },
	  effect = string.format("Mâchoire d'acier : %d dégâts et immobilise la victime %s secondes.",
		C.Ours.dmg, frnum(C.Ours.rootSec)),
	  desc = "Deux mâchoires crantées tendues par un ressort spirituel. Le claquement s'entend, mais toujours trop tard." },

	{ key = "assassin_piege_fil", kind = "piege", gtype = "fil",
	  name = "Piège à fil", model = MDL_FIL, skin = 0, rarity = "epic",
	  level = 8, cost = 500, xp = 16,
	  mats = { res_bois = 12, res_corde = 8, res_metal_brut = 8, res_petit_os = 3 },
	  effect = string.format("Fil tendu entre deux piquets (%d unités max) : quiconque le touche est révélé %d secondes à travers tout aux yeux du poseur."
		.. " Approche-toi d'un piquet et utilise une grenade pour la MONTER sur le fil : elle explosera sur la première personne qui passe.",
		C.Fil.maxLen, C.Fil.revealSec),
	  desc = "Deux piquets, un fil de tendon presque invisible. Il ne blesse personne : il désigne. Se pose en deux temps, un piquet puis l'autre." },

	{ key = "assassin_grenade_toxique", kind = "grenade", gtype = "toxique",
	  name = "Grenade toxique", model = MDL_GREN, skin = 0, rarity = "epic",
	  level = 9, cost = 600, xp = 20,
	  mats = { res_petit_os = 6, res_roche = 16, res_bois = 10, res_corde = 4 },
	  effect = string.format("Nuage empoisonné %d secondes : %d dégâts par seconde dans la zone.",
		C.Toxique.dur, math.Round(C.Toxique.dmg / C.Toxique.tick)),
	  desc = "Moelle d'os de Hollow broyée à la roche. Le nuage ronge le reiryoku de quiconque s'y attarde." },

	{ key = "assassin_grenade_glace", kind = "grenade", gtype = "glace",
	  name = "Grenade de glace", model = MDL_GREN, skin = 3, rarity = "epic",
	  level = 12, cost = 650, xp = 22,
	  mats = { res_metal_brut = 10, res_roche = 15, res_os_moyen = 6, res_corde = 5 },
	  effect = string.format("Voile de neige à l'impact : brouille la vue et ralentit de %d%% dans la zone pendant %d secondes.",
		math.Round((1 - C.Glace.slowScale) * 100), C.Glace.dur),
	  desc = "Cristal instable serti dans le métal. Le givre monte, la vue se voile, les jambes oublient de fuir." },

	{ key = "assassin_grenade_bombe", kind = "grenade", gtype = "bombe",
	  name = "Bombe artisanale", model = MDL_BOMBE, skin = 0, rarity = "legendary",
	  level = 15, cost = 800, xp = 25,
	  mats = { res_metal_brut = 15, res_roche = 15, res_corde = 6, res_os_moyen = 8 },
	  effect = string.format("Explosion : %d dégâts au centre, %d en bordure de zone.",
		C.Bombe.dmgMax, C.Bombe.dmgMin),
	  desc = "Sphère de fonte bourrée de poudre de roche condensée. Rien de subtil, mais personne ne se plaint du résultat." },

	{ key = "assassin_grenade_feu", kind = "grenade", gtype = "feu",
	  name = "Grenade incendiaire", model = MDL_GREN, skin = 4, rarity = "legendary",
	  level = 18, cost = 800, xp = 28,
	  mats = { res_bois = 15, res_metal_brut = 10, res_corde = 8, res_gros_os = 2 },
	  effect = string.format("Nappe de flammes %d secondes : embrase quiconque la traverse (calcination).", C.Feu.dur),
	  desc = "Huiles de résine scellées sous verre, mèche de corde. Quiconque traverse repart en flammes." },

	{ key = "assassin_grenade_magique", kind = "grenade", gtype = "magique",
	  name = "Grenade spirituelle", model = MDL_GREN, skin = 2, rarity = "legendary",
	  level = 22, cost = 1000, xp = 30,
	  mats = { res_gros_os = 5, res_os_moyen = 10, res_corde = 10, res_metal_brut = 12 },
	  effect = string.format("Éclair spirituel : aveugle jusqu'à %d secondes ceux qui le regardent.", C.Magique.fullSec),
	  desc = "Un gros os saturé de reiryoku, scellé et comprimé par les artificiers. Parfaite pour entrer, encore meilleure pour disparaître." },
}

function EVO_CRAFT.AssassinGearByKey(sKey)
	for _, g in ipairs(EVO_CRAFT.AssassinGear) do
		if g.key == sKey then return g end
	end
	return nil
end

-- Enregistrement dans ITEMS en boucle de retry (pattern evo_science) : l'addon
-- inventory RÉASSIGNE la table ITEMS à son include, trop tôt = entrées écrasées.
local function registerAssassinItems()
	if not istable(ITEMS) then return false end
	for _, g in ipairs(EVO_CRAFT.AssassinGear) do
		-- Les matériaux (res_*) sont définis par sh_craft_resources, sans on_use.
		if g.kind ~= "materiau" and not ITEMS[g.key] then
			local sKey = g.key
			ITEMS[sKey] = {
				name = g.name,
				description = g.desc .. "\n" .. g.effect .. "\nClic droit > Utiliser, ou « Consommable rapide » pour l'assigner au consommable rapide.",
				category = "object",
				rarity = g.rarity,
				model_path = g.model,
				skin = g.skin or 0,
				is_droppable = true,
				is_deletable = true,
				-- on_use tourne sur les DEUX realms (recette inventory) : serveur only.
				on_use = function(ply)
					if not SERVER then return end
					if EVO_CRAFT.AssassinUse then EVO_CRAFT.AssassinUse(ply, sKey) end
				end,
			}
		end
	end
	return true
end

EVO_CRAFT.Retry("EVO_Craft::AssassinItems", registerAssassinItems,
	"[evo_craft] ITEMS indisponible apres 30 essais : equipement assassin non enregistre dans l'inventaire (verifier l'addon inventory).")

-- ============================================================================
-- DÉCOR D'ATELIER : les modèles assassin + ressources rejoignent l'outil de
-- placement des établis (`evo_etablie`, HUB.Etablies d'evo_science), même
-- technique que la verrerie médicale : props de scène, aucune logique dessus.
-- Retry : evo_craft se charge AVANT evo_science, la table n'existe pas encore
-- à l'include. Idempotent par id (l'index net de l'outil est passé à 6 bits).
-- ============================================================================
local function registerAtelierDecor()
	local hub = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub
	if not (hub and istable(hub.Etablies)) then return false end
	local function add(sId, sName, sModel, nSkin)
		for _, e in ipairs(hub.Etablies) do
			if e.id == sId then return end
		end
		hub.Etablies[#hub.Etablies + 1] = { id = sId, name = sName, model = sModel, skin = nSkin }
	end
	add("assassin_piege_ours", "Piège à ours (assassin)", MDL_OURS)
	add("assassin_piege_pics", "Piège à pics (assassin)", MDL_PICS)
	add("assassin_grenade_bombe", "Bombe artisanale (assassin)", MDL_BOMBE)
	add("assassin_grenade_fumigene", "Grenade fumigène (assassin)", MDL_GREN, 1)
	for _, sId in ipairs(EVO_CRAFT.ResourceOrder or {}) do
		local r = EVO_CRAFT.Resources[sId]
		if r then add(sId, r.name .. " (ressource)", r.model) end
	end
	return true
end

EVO_CRAFT.Retry("EVO_Craft::AssassinDecor", registerAtelierDecor,
	"[evo_craft] HUB.Etablies indisponible apres 30 essais : decor assassin non enregistre dans l'outil evo_etablie.")

-- ============================================================================
-- HELPERS PARTAGÉS DES ENTITÉS (grenade + 2 pièges) : un seul exemplaire des
-- filtres de cible, de l'attribution des dégâts et des utilitaires.
-- ============================================================================
if SERVER then

	-- Particule au monde : StartParticule (EntMeta, posé par ncm_pnj) filtre les
	-- destinataires par instance ; repli moteur si absent.
	-- ── DOUBLURE DE PARTICULE (user 08/21 : « on ne voit pas la particule ») ──
	-- « [0]_anger_explousion_add_7_instant » (éclair de la grenade spirituelle) est
	-- le SEUL système de particules du projet qu'aucun sort en service n'utilise :
	-- s'il n'est dans aucun PCF monté, sa création échoue EN SILENCE côté client
	-- (cl_particles_citron) et rien ne s'affiche. On déclare donc une doublure
	-- PROUVÉE en jeu (celle du Bakudō 3, déjà utilisée par le fumigène).
	-- Le nom demandé reste en place : le jour où l'asset arrive, la vraie
	-- particule se crée et la doublure n'est plus jamais consultée.
	EVO_ParticleFallback = EVO_ParticleFallback or {}
	EVO_ParticleFallback["[0]_anger_explousion_add_7_instant"] =
		EVO_ParticleFallback["[0]_anger_explousion_add_7_instant"] or "[0]_anger_explousion_add_11_instant"

	-- ⚠ LA PARTICULE NE PART PAS DE LA GRENADE, MAIS DU LANCEUR (fix 2026-08-22,
	-- « parfois on ne voit pas les particules »). StartParticule réseaute l'entité
	-- SOURCE, et le receveur client (`cl_particles_citron`) commence par
	-- `if not IsValid(pPlayer) then return end`. Or bombe / fumigène / spirituelle
	-- appellent `self:Remove()` DANS LA MÊME FRAME : la suppression et le message
	-- partent au même snapshot, et selon l'ordre d'arrivée chez chaque client
	-- l'entité est déjà NULL -> le handler sort AVANT même d'essayer la doublure de
	-- particule. D'où l'intermittence, pire en ping élevé. Les grenades de ZONE
	-- (toxique / glace / feu) gardent leur entité vivante : elles, on les voit
	-- toujours — c'est la signature du bug.
	-- Le lanceur, lui, survit à la détonation. La position reste MONDE (bAttach =
	-- false -> le client crée à vPos, sans rien ajouter), donc l'effet ne bouge pas
	-- d'un pouce ; et filtrer les destinataires sur l'instance du lanceur est
	-- exactement ce qu'on veut. Repli sur l'entité si le lanceur s'est déconnecté.
	function EVO_CRAFT.AssassinFx(ent, sName, vPos, nDur)
		local src = ent
		if ent.GetThrower then
			local pThrower = ent:GetThrower()
			if IsValid(pThrower) then src = pThrower end
		end
		if src.StartParticule then
			src:StartParticule(sName, vPos, angle_zero, false, nDur, {}, false)
		else
			ParticleEffect(sName, vPos, angle_zero)
		end
	end

	-- Cibles valides d'une ZONE : mêmes filtres que le Sekienton (sv_bakudo).
	function EVO_CRAFT.AssassinVictims(owner, pos, r)
		local out = {}
		for _, v in ipairs(ents.FindInSphere(pos, r)) do
			if v ~= owner and (v:IsPlayer() or v:IsNextBot()) then
				local ok = true
				if v:IsPlayer() and (not v:Alive() or v:GetEvoNWBool("EVO_IsKO", false)) then ok = false end
				if ok and EvoStyle and EvoStyle.IsIntangibleTarget and EvoStyle.IsIntangibleTarget(v) then ok = false end
				if ok and IsValid(owner) and NCM_INSTANCE and NCM_INSTANCE.CanAffect
					and not NCM_INSTANCE.CanAffect(owner, v) then ok = false end
				if ok then out[#out + 1] = v end
			end
		end
		return out
	end

	-- 910 = impact direct (parable comme un sort), 911 = tick de DoT (son de hit
	-- adouci, n'ouvre pas l'enchaînement de sorts). ApplySpellDamage porte les
	-- damage numbers + protections ; repli DamageInfo si le lanceur a disparu.
	function EVO_CRAFT.AssassinHurt(owner, inflictor, victim, dmg, nCustom)
		if IsValid(owner) and owner.ApplySpellDamage then
			owner:ApplySpellDamage(victim, dmg, nCustom)
			if victim.DoSpellHitSound then victim:DoSpellHitSound() end
			return
		end
		local d = DamageInfo()
		d:SetDamage(dmg)
		d:SetAttacker(IsValid(owner) and owner or (IsValid(inflictor) and inflictor or game.GetWorld()))
		d:SetInflictor(IsValid(inflictor) and inflictor or game.GetWorld())
		d:SetDamageCustom(nCustom)
		victim:TakeDamageInfo(d)
	end

	-- Filtres de DÉCLENCHEMENT d'un piège : pas de KO, pas de noclip, pas de
	-- survol (dz), immunité récente optionnelle (tRecent). Le POSEUR n'est PAS
	-- exempté (demande user 08/18) : son propre piège le mord aussi, l'armement
	-- de TrapArmDelay est sa seule fenêtre pour reculer.
	function EVO_CRAFT.AssassinCanTrigger(trap, v)
		if not (v:IsPlayer() or v:IsNextBot()) then return false end
		if trap.tRecent and (trap.tRecent[v] or 0) > CurTime() then return false end
		if v:IsPlayer() then
			if not v:Alive() or v:GetEvoNWBool("EVO_IsKO", false) then return false end
			if v:GetMoveType() == MOVETYPE_NOCLIP then return false end
		end
		if EvoStyle and EvoStyle.IsIntangibleTarget and EvoStyle.IsIntangibleTarget(v) then return false end
		local owner = trap:GetThrower()
		if IsValid(owner) and NCM_INSTANCE and NCM_INSTANCE.CanAffect and not NCM_INSTANCE.CanAffect(owner, v) then
			return false
		end
		if math.abs(v:GetPos().z - trap:GetPos().z) > 40 then return false end
		return true
	end

	-- Joue une séquence si le modèle la porte (asset pas monté = pas d'anim,
	-- jamais d'erreur). Retourne la durée (0 si absente).
	function EVO_CRAFT.AssassinPlaySeq(ent, sName)
		local i = ent:LookupSequence(sName)
		if i and i >= 0 then
			ent:ResetSequence(i)
			return ent:SequenceDuration(i)
		end
		return 0
	end

	-- Récupération d'un piège au [E] par son poseur : l'item retourne au sac.
	-- Grenades assassin PRÉSENTES dans le sac, dédoublonnées et comptées.
	-- Sert au menu radial du piège à fil : on n'affiche que ce qu'on a vraiment.
	function EVO_CRAFT.AssassinGrenadesInBag(ply)
		local out, seen = {}, {}
		local inv = ply.inventory and ply.inventory.items
		if not istable(inv) then return out end
		for _, sId in pairs(inv) do
			if isstring(sId) and not seen[sId] then
				local g = EVO_CRAFT.AssassinGearByKey(sId)
				if g and g.kind == "grenade" then
					seen[sId] = true
					out[#out + 1] = { key = sId, name = g.name or sId }
				end
			end
		end
		table.sort(out, function(a, b) return a.name < b.name end)
		return out
	end

	function EVO_CRAFT.AssassinTrapPickup(trap, activator, sDefaultKey)
		if not (IsValid(activator) and activator:IsPlayer()) then return end
		if activator ~= trap:GetThrower() then return end
		if (activator._evoPiegeUseNext or 0) > CurTime() then return end
		activator._evoPiegeUseNext = CurTime() + 1
		local sKey = trap.sItemKey or sDefaultKey
		activator:GiveItem(sKey, function(ok)
			if ok == false then
				if activator.rpNotify then
					activator:rpNotify("Sac plein : fais de la place avant de récupérer le piège.", 1, 4)
				end
				return
			end
			-- Grenade montée sur le fil : elle repart au sac AVANT le retrait, sinon
			-- démonter son propre piège la ferait disparaître.
			if IsValid(trap) and isstring(trap.sGrenadeKey) and trap.sGrenadeKey ~= "" then
				local sGren = trap.sGrenadeKey
				trap.sGrenadeKey = nil
				activator:GiveItem(sGren, function(okG)
					if okG == false and activator.rpNotify then
						activator:rpNotify("Sac plein : la grenade montée sur le fil est perdue.", 1, 4)
					end
				end)
			end
			if IsValid(trap) then
				trap:EmitSound("physics/metal/metal_grate_impact_soft3.wav", 60, 100)
				trap:Remove()
			end
		end)
	end

end
-- (Le cercle du poseur AssassinTrapRing a été RETIRÉ, demande user 08/18 : les
-- pièges posés ne montrent que leur modèle, la preview vit dans cl_assassin_gear.)
