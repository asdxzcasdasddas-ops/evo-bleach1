-- "addons\\evo_craft\\lua\\evo_craft\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Ateliers de craft : config + helpers PARTAGÉS (le rendu client et les gates
-- serveur doivent lire exactement la même géométrie, recette evo_livre).

EVO_CRAFT = EVO_CRAFT or {}

EVO_CRAFT.CFG = {
	-- Rayon DEFAUT des zones : volontairement beaucoup plus petit que les
	-- Archives (90) : un atelier est un poste de travail, pas une salle.
	StationRadius = 45,

	-- Grade de faction minimum pour UTILISER un atelier (demande user 08/16).
	MinRank = 2,

	-- CRAFT EN SÉRIE (user 09/15) : exemplaires max fabriqués en UN craft
	-- (matériaux et yens ×N, XP ×N, un seul mini-jeu). Borne dure serveur.
	MaxBatch = 10,

	-- Coffre de division : ouverture au grade 3+, onglet CACHÉ au grade 10+.
	CoffreMinRank    = 3,
	CoffreSecretRank = 10,

	-- rôle -> enseigne. Les clés reprennent EvoStyle.DivisionSpells (résolution
	-- par NOM de division via LZY_FACTION_CONFIG, jamais par index de division).
	Roles = {
		assassin = { label = "ASSASSIN" },
		soin     = { label = "MEDECIN" },
		combat   = { label = "COMBAT" },
	},

	-- ZONES PAR MAP, même mécanique que les Archives : cylindre horizontal + z
	-- ANCRÉ AU SOL (les setpos sont souvent pris en vol). pos = setpos BRUT,
	-- yaw BRUT (règle projet : jamais de +180 magique). role OBLIGATOIRE.
	Stations = {
		-- gm_construct : 3 zones de TEST, une par rôle, alignées près du coin de
		-- test des Archives/postes d'analyse (positions éprouvées, z recalé).
		["gm_construct"] = {
			{ pos = Vector(-620, 700, -148), yaw = 0, role = "assassin" },
			{ pos = Vector(-460, 700, -148), yaw = 0, role = "soin" },
			{ pos = Vector(-300, 700, -148), yaw = 0, role = "combat" },
		},
		-- Hueco : setpos/setang BRUTS re-relevés par le user 08/22 (remplacent
		-- les 3 stations du 08/20) : 4 postes médecin, 2 assassin, 3 combat.
		-- zonePos médecin/combat = ronds au sol (user 08/22) ; assassin = 2
		-- stations qui remplacent les 3 précédentes (modèle + zone sur pos).
		["hueco_mundo_v1"] = {
			{ pos = Vector(-13689.343750, 4711.031250, 6388.189453), yaw = 87.933632,   role = "soin",
			  zonePos = Vector(-13689.664062, 4751.912109, 6472.724121) },
			{ pos = Vector(-13696.698242, 5160.968750, 6329.039062), yaw = -91.718369,  role = "soin",
			  zonePos = Vector(-13696.180664, 5120.352539, 6472.724121) },
			{ pos = Vector(-13534.315430, 5160.968750, 6329.189453), yaw = -88.022369,  role = "soin",
			  zonePos = Vector(-13531.257812, 5120.316895, 6472.724121) },
			{ pos = Vector(-13529.293945, 4711.031250, 6333.479492), yaw = 88.365623,   role = "soin",
			  zonePos = Vector(-13528.138672, 4751.801270, 6472.724121) },
			{ pos = Vector(4517.712402, 2163.989502, 7047.724121),   yaw = -85.939720,  role = "assassin" },
			{ pos = Vector(4131.624023, 2163.880371, 7047.724121),   yaw = -88.975677,  role = "assassin" },
			{ pos = Vector(2965.968750, 4592.812500, 6595.487305),   yaw = -182.904205, role = "combat",
			  zonePos = Vector(2915.722900, 4589.463379, 6704.724121) },
			{ pos = Vector(2607.595703, 4191.031250, 6569.278809),   yaw = 88.823860,   role = "combat",
			  zonePos = Vector(2612.163330, 4252.691406, 6704.695312) },
			{ pos = Vector(2239.031250, 4591.392090, 6572.387695),   yaw = -2.256104,   role = "combat",
			  zonePos = Vector(2299.719727, 4593.993164, 6704.676270) },
		},
		-- Seireitei : setpos/setang BRUTS re-relevés par le user 08/21 (z = yeux,
		-- sans importance : StationAnchor retrace le sol ; yaw brut, jamais +180).
		-- DEUX ateliers de soin (demande user) — la liste le supporte nativement.
		-- zonePos (optionnel, user 08/21) : le ROND/enseigne et la détection E
		-- vivent là, le MODÈLE d'établi reste sur pos.
		["rp_seireitei_v1"] = {
			{ pos = Vector(-13763.332031, 10846.292969, 596.973938), yaw = 181.776108, role = "combat",
			  zonePos = Vector(-13817.134766, 10843.966797, 596.973877) },
			-- DEUX ateliers assassin (user 08/21 « 2 modèles en tout »).
			{ pos = Vector(6754.377930, -9035.805664, 577.723938),   yaw = 0.539768,   role = "assassin",
			  zonePos = Vector(6811.562012, -9037.245117, 577.723938) },
			{ pos = Vector(6754.451172, -9233.654297, 577.723938),   yaw = -1.378597,  role = "assassin",
			  zonePos = Vector(6814.201660, -9232.457031, 577.411255) },
			{ pos = Vector(-9569.737305, -9975.736328, 574.710999),  yaw = -1.236594,  role = "soin",
			  zonePos = Vector(-9530.993164, -9978.113281, 574.737671) },
			{ pos = Vector(-9569.155273, -9829.179688, 574.723877),  yaw = 0.611406,   role = "soin",
			  zonePos = Vector(-9530.777344, -9828.109375, 574.723877) },
		},
	},

	-- Modèles des ÉTABLIS d'atelier par RÔLE (assets user 08/20) : spawnés sur
	-- CHAQUE station de la map (ancre StationAnchor au sol, yaw brut de la
	-- station, vraie collision statique). Cf. SpawnDecor (sv_main).
	StationModels = {
		-- Établi assassin remplacé (user 08/24) — le double « models/models/ » est
		-- VOULU, c'est le chemin réel du pack watcherprops. Ancien :
		-- models/evo/props/items/evo_ax7qm2lp9vr/evo_Ax7Qm2Lp9Vr.mdl
		assassin = "models/models/watcherprops/watcher_konoha_stuff_68.mdl",
		combat   = "models/evo/props/items/evo_fg6nz3rc7yp/evo_Fg6Nz3Rc7Yp.mdl",
		soin     = "models/evo/props/items/evo_md4ks8wq1ht/evo_Md4Ks8Wq1Ht.mdl",
	},

	-- DÉCOR posé par le serveur au boot (prop_dynamic PAR MAP, recette forge :
	-- snap au sol + fallback si le modèle n'est pas monté + filet timer).
	Decor = {
		["gm_construct"] = {
			{ model = "models/props_c17/FurnitureTable002a.mdl", pos = Vector(-620, 760, -148), yaw = 0 },
			{ model = "models/props_c17/FurnitureTable002a.mdl", pos = Vector(-460, 760, -148), yaw = 0 },
			{ model = "models/props_c17/FurnitureTable002a.mdl", pos = Vector(-300, 760, -148), yaw = 0 },
		},
	},

	-- COFFRES DE DIVISION (entité evo_coffre_division, MÊME modèle de coffre que
	-- l'HDV). division = NOM EXACT dans LZY_FACTION_CONFIG (jamais un index).
	-- pos = setpos BRUT (snap sol par l'entité), yaw = setang BRUT (jamais +180).
	Coffres = {
		["rp_seireitei_v1"] = {
			{ pos = Vector(-13879.535156, 11642.600586, 596.973938),  yaw = -87.012711,  division = "Division 11" },
			{ pos = Vector(-7521.522949, -7908.062012, 641.695129),   yaw = 92.111801,   division = "Division 4" },
			{ pos = Vector(7578.491699, -9514.081055, 577.723938),    yaw = 85.750862,   division = "Division 2" },
			{ pos = Vector(5719.927246, 14322.632812, 598.723938),    yaw = -176.401871, division = "Division 12" },
			{ pos = Vector(-4258.488281, 349.493317, 14500.642578),   yaw = -178.224106, division = "Division 1" },
		},
		-- Hueco (setpos user 08/16 ; Ordre 1/4 INVERSÉS puis corrigés, demande user).
		-- Assassin / combat / médecin RELOGÉS le 08/22 : leurs quartiers ont
		-- déménagé le matin même (ateliers, spawns, terrains), les anciennes poses
		-- restaient sur les quartiers d'avant. Les trois nouvelles tombent à côté
		-- de leurs archives. Ordre 1 et Ordre 3 n'ont pas bougé (pas de relevé).
		["hueco_mundo_v1"] = {
			{ pos = Vector(-12534.412109, 66.803123, 6472.710938),   yaw = 91.174667,  division = "Ordre 3" }, -- scientifique
			{ pos = Vector(9133.594727, 918.777832, 6823.550781),    yaw = -91.419357, division = "Ordre 2" }, -- assassin   (08/22)
			{ pos = Vector(3900.764893, 6967.707031, 6975.968750),   yaw = 270.296722, division = "Ordre 5" }, -- combat     (08/22)
			{ pos = Vector(-14527.835938, 5359.946289, 6345.837891), yaw = -93.267273, division = "Ordre 4" }, -- médecin    (08/22)
			{ pos = Vector(-11382.181641, -1444.647461, 6472.724121), yaw = -89.258636, division = "Ordre 1" }, -- commandement
		},
		-- Coffre de TEST à côté des zones d'atelier.
		["gm_construct"] = {
			{ pos = Vector(-160, 700, -148), yaw = -90, division = "Division 11" },
		},
	},

	-- Modèle du coffre : LE MÊME que l'HDV (demande user). Lu paresseusement par
	-- l'entité, avec le même fallback que l'HDV si l'asset n'est pas monté.
	CoffreModel = "models/evo/props/items/evo_efttede452hk/evo_efttede452hk.mdl",

	-- Sentinelle d'escrow des dons : NI un nom de map NI NULL, sinon la purge au
	-- boot (DeleteDroppedInventoryRows) efface les objets stockés (recette HDV).
	CoffreEscrowMap = "__divchest__",
	CoffreSnapMax   = 400, -- objets max envoyés au client (les plus récents)
	CoffreLogMax    = 80,  -- lignes d'historique (dépôts / retraits)
}

-- ============================================================================
-- DÉPÔT : tout se stocke SAUF la boutique (demande user 08/16) et les objets
-- personnels dynamiques (notes, cartes, affiches, livres : liés à leur auteur).
-- Contrairement à l'HDV, PAS de gate is_droppable : katanas, gantelets et
-- équipement de loot se donnent à la division.
-- ============================================================================
-- Le FRIGO du laboratoire (coffre à LabelOverride, spawné par evo_science) ne
-- conserve que le CONSOMMABLE utile (user 08/21) : récolte (champis/plantes/
-- cristaux via IngredientKind), ressources d'artisanat res_*, potions/fioles,
-- ingrédients et produits de la table médicale (variantes étoilées incluses).
function EVO_CRAFT.FrigoDeposable(item_id)
	if not isstring(item_id) or item_id == "" then return false end
	if item_id == "bouteille_vide" then return true end
	if string.sub(item_id, 1, 4) == "res_" then return true end
	if string.sub(item_id, 1, 7) == "potion_" then return true end
	if EVO_SCIENCE then
		if EVO_SCIENCE.IngredientKind and EVO_SCIENCE.IngredientKind(item_id) then return true end
		if EVO_SCIENCE.MedIngredientAllowed and EVO_SCIENCE.MedIngredientAllowed(item_id) then return true end
		if EVO_SCIENCE.MedRecipeById then
			local sBase = string.gsub(item_id, "_[23]s$", "")
			if EVO_SCIENCE.MedRecipeById(sBase) then return true end
		end
	end
	return false
end

function EVO_CRAFT.CoffreDeposable(item_id)
	if not isstring(item_id) or item_id == "" then return false end
	-- Récolte / potions / préparations : jamais boutique. Ne pas exiger ITEMS
	-- (le hub science les enregistre en retry ; sans ça le coffre ment « boutique »).
	if EVO_CRAFT.FrigoDeposable(item_id) then return true end
	if string.sub(item_id, 1, 4) == "bar_" then return true end
	local it = ITEMS and ITEMS[item_id]
	if not it then
		local hub = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub
		it = hub and hub.Items and hub.Items[item_id]
	end
	if not it then return false end
	if it.evo_note or it.evo_carte or it.evo_affiche or it.evo_missive then return false end
	if item_id == "evo_livre" or item_id:sub(1, 6) == "livre_" then return false end
	if isfunction(LZY_Shop_IsShopItem) and LZY_Shop_IsShopItem(item_id) then return false end
	if isfunction(LZY_Shop_IsCoffreOnlyItem) and LZY_Shop_IsCoffreOnlyItem(item_id) then return false end
	-- Armes de BASE jamais donnables (demande user 08/16) : shinai, Foudre Noire
	-- par défaut, gantelets de base/bois. Lu par FLAG dans les registres d'armes
	-- (is_default / is_starter / is_shinai + skin "default"), pas d'ids en dur.
	if it.skin_id then
		local sk = KATANA_SKINS and KATANA_SKINS.List and KATANA_SKINS.List[it.skin_id]
		if it.skin_id == "default" or (sk and (sk.is_shinai or sk.is_default or sk.is_starter)) then return false end
	end
	if it.gauntlet_id then
		local g = NCM_HAKUDA_GAUNTLETS and NCM_HAKUDA_GAUNTLETS.List and NCM_HAKUDA_GAUNTLETS.List[it.gauntlet_id]
		if g and (g.is_default or g.is_starter) then return false end
	end
	return true
end

function EVO_CRAFT.CoffreRefuseReason(item_id)
	if EVO_CRAFT.CoffreDeposable(item_id) then return nil end
	local it = ITEMS and ITEMS[item_id]
	if not it then
		return "Objet inconnu : il n'est pas enregistré dans l'inventaire."
	end
	if isfunction(LZY_Shop_IsShopItem) and LZY_Shop_IsShopItem(item_id) then
		return "Les objets boutique ne peuvent pas être déposés."
	end
	if isfunction(LZY_Shop_IsCoffreOnlyItem) and LZY_Shop_IsCoffreOnlyItem(item_id) then
		return "Les objets de coffre boutique ne peuvent pas être déposés."
	end
	if it.evo_note or it.evo_carte or it.evo_affiche or it.evo_missive
		or item_id == "evo_livre" or (isstring(item_id) and item_id:sub(1, 6) == "livre_") then
		return "Les objets personnels (notes, cartes, livres) ne peuvent pas être déposés."
	end
	return "Cet objet ne peut pas être déposé."
end

-- Catégories du coffre (onglets). L'ordre du classement compte : un accessoire
-- de loot À STATS part en "ÉQUIPEMENT", un cosmétique pur reste "ACCESSOIRES".
EVO_CRAFT.CoffreCats = {
	{ id = "all",    label = "TOUS" },
	{ id = "armes",  label = "ARMES" },
	{ id = "equip",  label = "ÉQUIPEMENT" },
	{ id = "tenues", label = "TENUES" },
	{ id = "access", label = "ACCESSOIRES" },
	{ id = "chest",  label = "COFFRES" },
	{ id = "conso",  label = "PARCHEMINS" },
	{ id = "other",  label = "AUTRES" },
}

function EVO_CRAFT.CoffreCatOf(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it then return "other" end
	if it.is_lootbox then return "chest" end
	if it.skin_id or it.gauntlet_id then return "armes" end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.ItemAffectsStats and INVENTORY_CONFIG.ItemAffectsStats(item_id) then
		return "equip"
	end
	if it.category == "outfit" then return "tenues" end
	if it.category == "accessory" then return "access" end
	if it.on_use or it.is_quest_scroll then return "conso" end
	return "other"
end

function EVO_CRAFT.StationList()
	return (EVO_CRAFT.CFG.Stations or {})[game.GetMap()] or {}
end

-- Presets "Etabli *" du menu Modeles : même chemin que les établis spawnés.
-- Sans ça, un swap de modèle (assassin 08/24) laisse l'éditeur sur l'ancien mdl.
if EVO_ConfigPos and istable(EVO_ConfigPos.WorldModelPresets) then
	local models = EVO_CRAFT.CFG.StationModels
	if istable(models) then
		for _, pre in ipairs(EVO_ConfigPos.WorldModelPresets) do
			if pre.id and models[pre.id] then
				pre.model = models[pre.id]
			end
		end
	end
end

function EVO_CRAFT.RoleLabel(sRole)
	local t = EVO_CRAFT.CFG.Roles[sRole]
	return (t and t.label) or tostring(sRole or "?")
end

-- Ancrage AU SOL partagé client/serveur : le rendu ET les gates E/net doivent
-- utiliser le MÊME z ancré, sinon une zone s'affiche au sol mais refuse le E
-- (bug « 2 zones sur 4 » des Archives sur Hueco).
local tAnchors = {}
local tZoneAnchors = {}
function EVO_CRAFT.InvalidateAnchors()
	tAnchors = {}
	tZoneAnchors = {}
end
function EVO_CRAFT.StationAnchor(st)
	local a = tAnchors[st]
	if a then return a end
	local tr = util.TraceLine({
		start = st.pos + Vector(0, 0, 30),
		endpos = st.pos - Vector(0, 0, 1000),
		mask = MASK_SOLID_BRUSHONLY,
	})
	a = tr.Hit and tr.HitPos or st.pos
	tAnchors[st] = a
	return a
end

-- Pose du MODÈLE : sol + modelOffZ (le gizmo Z de config_positions). Le rond
-- E reste sur StationZoneAnchor : un établi soulevé ne doit pas emporter la
-- zone. modelOffZ = 0 (défaut) = collé au sol, comme avant l'éditeur.
function EVO_CRAFT.StationModelPos(st)
	local g = EVO_CRAFT.StationAnchor(st)
	return Vector(g.x, g.y, g.z + (tonumber(st.modelOffZ) or 0))
end

-- Position de la ZONE (rond/enseigne/détection E) : zonePos si la station
-- sépare le rond du modèle (user 08/21), sinon pos. Même ancrage au sol.
function EVO_CRAFT.StationZonePos(st)
	return st.zonePos or st.pos
end
function EVO_CRAFT.StationZoneAnchor(st)
	if not st.zonePos then return EVO_CRAFT.StationAnchor(st) end
	local a = tZoneAnchors[st]
	if a then return a end
	local tr = util.TraceLine({
		start = st.zonePos + Vector(0, 0, 30),
		endpos = st.zonePos - Vector(0, 0, 1000),
		mask = MASK_SOLID_BRUSHONLY,
	})
	a = tr.Hit and tr.HitPos or st.zonePos
	tZoneAnchors[st] = a
	return a
end

-- Cylindre : distance horizontale < rayon, dz contre le z ANCRÉ. Retourne la
-- STATION (pour son rôle), nil hors zone.
function EVO_CRAFT.CurrentStation(ply)
	if not IsValid(ply) then return nil end
	local p = ply:GetPos()
	for _, st in ipairs(EVO_CRAFT.StationList()) do
		local r = st.radius or EVO_CRAFT.CFG.StationRadius or 45
		local vZone = EVO_CRAFT.StationZonePos(st)
		local dx, dy = p.x - vZone.x, p.y - vZone.y
		if dx * dx + dy * dy <= r * r and math.abs(p.z - EVO_CRAFT.StationZoneAnchor(st).z) <= 120 then
			return st
		end
	end
	return nil
end

-- Raison de refus d'un atelier : nil = accès OK, "division" = pas la bonne
-- division, "rank" = bonne division mais grade < MinRank. Résolution par NOM
-- (EvoStyle.IsInSpellDivision), nil-safe si le système de sorts n'est pas chargé.
function EVO_CRAFT.StationDenyReason(ply, st)
	if not (IsValid(ply) and ply:IsPlayer() and st and st.role) then return "division" end
	if ply:IsSuperAdmin() then return nil end
	local bMember = EvoStyle and EvoStyle.IsInSpellDivision
		and EvoStyle.IsInSpellDivision(ply, st.role) or false
	if not bMember then return "division" end
	if (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) < (EVO_CRAFT.CFG.MinRank or 2) then
		return "rank"
	end
	return nil
end

function EVO_CRAFT.CanUseStation(ply, st)
	return EVO_CRAFT.StationDenyReason(ply, st) == nil
end

-- Membre d'une division par NOM EXACT (règle projet : toujours passer par
-- LZY_FACTION_CONFIG, jamais par index en dur).
function EVO_CRAFT.IsInDivisionByName(ply, sDivName)
	if not (IsValid(ply) and ply:IsPlayer() and isstring(sDivName)) then return false end
	local sFaction = ply:GetEvoNWString("FactionName", "")
	local divs = LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.divisions and LZY_FACTION_CONFIG.divisions[sFaction]
	if not divs then return false end
	return divs[ply:GetEvoNWInt("FactionDivision", 0)] == sDivName
end

-- Interaction "[E]" à distance : le registre evo_npc_core RÉASSIGNE sa table au
-- chargement, donc on s'inscrit à InitPostEntity (les deux realms), pas à l'include.
hook.Add("InitPostEntity", "EVO_Craft:RegisterInteract", function()
	if EVO_NPCInteract and EVO_NPCInteract.NPCs then
		EVO_NPCInteract.NPCs["evo_coffre_division"] = 160
	end
end)

-- Nom de la division du rôle pour la faction du joueur (messages/UI), fallback
-- sur l'enseigne du rôle.
function EVO_CRAFT.DivisionName(sRole, ply)
	local tRole = EvoStyle and EvoStyle.DivisionSpells and EvoStyle.DivisionSpells[sRole]
	local sFaction = IsValid(ply) and ply:GetEvoNWString("FactionName", "") or ""
	return (tRole and tRole.tNames and tRole.tNames[sFaction]) or EVO_CRAFT.RoleLabel(sRole)
end

-- ============================================================================
-- NIVEAUX DE CRAFT : XP par PERSONNAGE et par rôle d'atelier (table
-- evo_craft_levels). Courbe partagée client/serveur : le rond de niveau du menu
-- doit afficher exactement ce que le serveur calcule.
-- ============================================================================
-- 30 depuis le 08/18 (le plafond de tirage s'atteint donc au niveau 30 ;
-- le 2e emplacement d'enchantement reste débloqué au niveau EnchantCfg.SecondSlotLevel).
EVO_CRAFT.MaxLevel = 30

-- ── RÔLES À NIVEAU : source UNIQUE de tout ce qui a un niveau de craft ───────
-- Les 3 ateliers + le labo scientifique (evo_science, branché ici le 08/18).
-- Consommé par la commande SAM craftlevel (dropdown + validation) et les
-- helpers admin. Un nouveau système à niveaux = une entrée ICI, jamais ailleurs.
EVO_CRAFT.LevelRoles = { "assassin", "soin", "combat", "science" }

function EVO_CRAFT.IsLevelRole(sRole)
	for _, r in ipairs(EVO_CRAFT.LevelRoles) do
		if r == sRole then return true end
	end
	return false
end

-- Saisie SAM / chat -> clé interne (soin = atelier médecin).
EVO_CRAFT.LevelRoleAliases = {
	medecin = "soin",
	medic = "soin",
	docteur = "soin",
	labo = "science",
	scientifique = "science",
}

function EVO_CRAFT.ResolveLevelRole(sRole)
	sRole = string.lower(string.Trim(tostring(sRole or "")))
	sRole = string.gsub(string.gsub(sRole, "é", "e"), "è", "e")
	if EVO_CRAFT.IsLevelRole(sRole) then return sRole end
	local mapped = EVO_CRAFT.LevelRoleAliases and EVO_CRAFT.LevelRoleAliases[sRole]
	if mapped and EVO_CRAFT.IsLevelRole(mapped) then return mapped end
	return nil
end

-- XP nécessaire pour passer du niveau l au niveau l+1. Courbe PAR RÔLE :
-- les ateliers (assassin / soin / combat) = progressive ; la science garde sa
-- courbe HISTORIQUE plate (10 XP/niveau, +1 XP par analyse/synthèse avec cap
-- journalier côté evo_science) — la science n'est PAS concernée par le palier.
--
-- PALIER DE DURCISSEMENT (demande user 2026-08-22) : jusqu'au niveau 11 la
-- montée ne change pas (+25 par niveau) ; À PARTIR DU NIVEAU 12 le pas passe à
-- +60. Les hauts niveaux d'atelier deviennent un vrai objectif long, sans
-- toucher au début de progression que tout le monde a déjà fait.
-- ⚠ Le niveau est TOUJOURS recalculé depuis l'XP totale (LevelFromXP) : durcir
-- la courbe REDESCEND mécaniquement les joueurs déjà au-dessus du palier. C'est
-- inhérent au changement, pas un bug.
-- Les 3 constantes sont le seul point de réglage.
EVO_CRAFT.LevelHardStep  = 12  -- 1er niveau à tarif durci
EVO_CRAFT.LevelStepEasy  = 25  -- +XP par niveau avant le palier
EVO_CRAFT.LevelStepHard  = 60  -- +XP par niveau à partir du palier

function EVO_CRAFT.XPPerLevel(l, sRole)
	if sRole == "science" then return 10 end
	l = math.max(1, l)
	local nPalier = EVO_CRAFT.LevelHardStep
	if l < nPalier then return 50 + (l - 1) * EVO_CRAFT.LevelStepEasy end
	-- Reprend la valeur du dernier niveau « doux » (palier - 1) puis accélère,
	-- sinon le tarif ferait un creux au moment du changement de pas.
	return 50 + (nPalier - 2) * EVO_CRAFT.LevelStepEasy
		+ (l - nPalier + 1) * EVO_CRAFT.LevelStepHard
end

-- Courbe HISTORIQUE (avant le palier du 22/08). Gardée UNIQUEMENT pour la
-- migration de compensation (sv_main) : elle permet de retrouver le niveau
-- qu'un joueur AVAIT, pour lui recréditer l'XP qui le lui conserve.
-- Ne pas s'en servir ailleurs — la courbe en vigueur est XPPerLevel.
function EVO_CRAFT.XPPerLevelLegacy(l, sRole)
	if sRole == "science" then return 10 end
	return 50 + (math.max(1, l) - 1) * 25
end

-- XP TOTALE cumulée pour atteindre nLevel avec la courbe fCurve (défaut : en
-- vigueur). Sert à la migration et à la conversion niveau -> XP.
function EVO_CRAFT.TotalXPForLevel(nLevel, sRole, fCurve)
	fCurve = fCurve or EVO_CRAFT.XPPerLevel
	local nTotal = 0
	for l = 1, math.max(1, tonumber(nLevel) or 1) - 1 do
		nTotal = nTotal + fCurve(l, sRole)
	end
	return nTotal
end

-- (niveau, xp DANS le niveau) pour une courbe donnée. Miroir de LevelFromXP.
function EVO_CRAFT.LevelFromXPWith(xp, sRole, fCurve)
	fCurve = fCurve or EVO_CRAFT.XPPerLevel
	xp = math.max(0, math.floor(tonumber(xp) or 0))
	local lvl = 1
	while lvl < EVO_CRAFT.MaxLevel do
		local need = fCurve(lvl, sRole)
		if xp < need then return lvl, xp end
		xp = xp - need
		lvl = lvl + 1
	end
	return EVO_CRAFT.MaxLevel, 0
end

-- xp totale -> (niveau 1..MaxLevel, xp accumulée DANS ce niveau, xp requise pour
-- le suivant — 0 au niveau max). sRole optionnel (courbe par rôle).
function EVO_CRAFT.LevelFromXP(xp, sRole)
	xp = math.max(0, math.floor(tonumber(xp) or 0))
	local lvl = 1
	while lvl < EVO_CRAFT.MaxLevel do
		local need = EVO_CRAFT.XPPerLevel(lvl, sRole)
		if xp < need then return lvl, xp, need end
		xp = xp - need
		lvl = lvl + 1
	end
	return EVO_CRAFT.MaxLevel, 0, 0
end

-- ============================================================================
-- ENCHANTEMENT (rayon COMBAT) : un bonus par INSTANCE d'équipement (accessoire à
-- stats), stocké "stat:pct" dans inventory.enchant. Ré-enchanter REMPLACE.
-- `pct` = ajout PLAT d'e_* (même unité que les stats d'accessoire = % joueur),
-- multiplié par la forge. Une pièce SANS cette stat peut quand même la recevoir.
-- Application dans ncm_forge/sv_stats_hook. Clés = e_* de lzy_stats (allowlist).
-- ============================================================================
-- `color` = teinte d'affichage du boost (UI atelier : ligne des cartes, pastilles).
-- `maxPct` = plafond ABSOLU du tirage (e_* plat). EnchantCapFor lit ça.
-- Plafonds relevés pour se rapprocher de l'ancien player-flat (MaxPct 15, crit 5)
-- une fois la forge appliquée (×2.53 au niv 30) sans y revenir à cru.
-- ⚠ Toucher un maxPct ici (ou RarityMult plus bas) = archiver l'échelle sortante
-- dans EnchantScales puis bumper ENCHANT_REV, sinon les pièces DÉJÀ gravées
-- restent à l'ancienne valeur. Voir le bloc ÉCHELLE DES GRAVURES plus bas.
EVO_CRAFT.Enchants = {
	{ key = "max_hp",           label = "PV maximum",             color = Color(96, 220, 130), maxPct = 5.0 },
	{ key = "max_reiatsu",      label = "Reiatsu maximum",        color = Color(90, 170, 255), maxPct = 6.0 },
	-- « Dégâts d'arme », jamais « dégâts katana » : la stat scale katana ET Hakuda.
	{ key = "katana_damage",    label = "Dégâts d'arme",          color = Color(255, 120, 90), maxPct = 4.5 },
	{ key = "spell_damage",     label = "Dégâts de sort",         color = Color(190, 120, 255), maxPct = 4.5 },
	-- 4.0 -> 12.0 (user 2026-09-18). À 4 %, une gravure MAXIMALE valait 0,11 s sur un
	-- CD de 3 s au grade 16 — et une pièce mythique Tempête en donne 4,5 % toute seule.
	-- Graver « CD Flashstep » coûtait 10 000 yens et 5 cristaux pour moins qu'une pièce.
	-- Un % de cooldown pèse bien moins qu'un % de dégâts (qui se sent à chaque coup),
	-- d'où un plafond volontairement au-dessus des autres. Échelle rev 3 archivée en
	-- EnchantScales[3], rev bumpée à 4 : les gravures déjà posées sont reconverties.
	{ key = "flashstep_cd",     label = "Réduction CD Flashstep", color = Color(110, 230, 230), maxPct = 12.0 },
	{ key = "katana_cc_chance", label = "Chance de critique",     color = Color(255, 170, 60), maxPct = 2.0 },
}

function EVO_CRAFT.EnchantByKey(sKey)
	for _, e in ipairs(EVO_CRAFT.Enchants) do
		if e.key == sKey then return e end
	end
	return nil
end

EVO_CRAFT.EnchantCfg = {
	MaxPct      = 5,   -- fallback si un boost n'a pas de maxPct (échelle e_* plate)
	LegacyScale = 50,  -- ancien plafond 08/28 (% de la pièce) : archivé dans EnchantScales[2]
	FloorFrac   = 0.5, -- part du plafond atteignable au niveau 1 (0.95% signalé trop bas -> relevé encore)
	RollMinFrac = 0.6, -- le tirage va de 60% à 100% du plafond du niveau (plancher relevé 08/18)
	XP          = 25,  -- XP de craft gagnée par enchantement réussi
	MinRank     = 3,   -- grade de division requis pour enchanter (demande user 08/17)
	-- Part du MINI-JEU de forge dans le tirage, le reste reste du hasard pur
	-- (le score client est borné 0..1 : tricher = au mieux le plafond de SON niveau).
	SkillWeight = 0.5,
	-- 2e EMPLACEMENT d'enchantement : un crafteur niveau 20 AJOUTE au lieu de
	-- remplacer (2 boosts max par pièce, jamais 2× la même stat).
	MaxSlots        = 2,
	SecondSlotLevel = 20,
	-- Coût en yens d'une tentative, selon la RARETÉ de l'équipement ciblé
	-- (divisé par 2 le 08/18, demande user).
	Cost = { common = 500, rare = 1250, epic = 2500, legendary = 5000, mythic = 10000 },
	-- Multiplicateur du plafond de tirage selon la rareté : courbe volontairement
	-- ÉCARTÉE (common trop proche de mythic à 0.6). Graver une rareté supérieure
	-- doit rester clairement plus fort, même pièce forgée 30.
	RarityMult = { common = 0.35, rare = 0.50, epic = 0.70, legendary = 0.88, mythic = 1 },
	-- CRISTAUX de reiryoku (evo_science, toutes couleurs confondues) consommés en
	-- plus des yens : de plus en plus RARES et NOMBREUX avec la rareté de la pièce
	-- (tier 6 = Éclat de reiryoku ... tier 1 = Cristal primordial, réservé).
	Crystals = {
		common    = { tier = 6, count = 1 },
		rare      = { tier = 5, count = 2 },
		epic      = { tier = 4, count = 3 },
		legendary = { tier = 3, count = 4 },
		mythic    = { tier = 2, count = 5 },
	},
}

-- Multiplicateur de plafond selon la rareté de la pièce ciblée.
function EVO_CRAFT.EnchantRarityMult(item_id)
	local it = ITEMS and ITEMS[item_id]
	return EVO_CRAFT.EnchantCfg.RarityMult[(it and it.rarity) or "common"] or 1
end

-- Besoin en cristaux pour un item ciblé -> (tier, count).
function EVO_CRAFT.EnchantCrystalsFor(item_id)
	local it = ITEMS and ITEMS[item_id]
	local t = EVO_CRAFT.EnchantCfg.Crystals[(it and it.rarity) or "common"]
		or EVO_CRAFT.EnchantCfg.Crystals.common
	return t.tier, t.count
end

-- Nom d'affichage d'un tier de cristal (fallback si evo_science absent).
function EVO_CRAFT.CrystalTierName(nTier)
	local hub = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub
	return (hub and hub.CrystalTierNames and hub.CrystalTierNames[nTier])
		or ("Cristal T" .. tostring(nTier))
end

-- Compte les cristaux d'un TIER (toutes couleurs) dans le sac, piles comprises.
-- Client : cache LIVE. Serveur : ply.inventory (items + quantities).
function EVO_CRAFT.CountCrystalsIn(inv, nTier)
	if not (EVO_SCIENCE and EVO_SCIENCE.CrystalParse) then return 0 end
	local n = 0
	if CLIENT then
		local lp = LocalPlayer()
		if IsValid(lp) and lp.ForEachBagSlot then
			lp:ForEachBagSlot(function(_, id, q)
				if EVO_SCIENCE.CrystalParse(id) == nTier then n = n + q end
			end)
			return n
		end
	end
	if not istable(inv) then return 0 end
	local tItems = istable(inv.items) and inv.items or inv
	for slot, id in pairs(tItems) do
		if isstring(id) and EVO_SCIENCE.CrystalParse(id) == nTier then
			if istable(inv.items) and INVENTORY_CONFIG and INVENTORY_CONFIG.GetSlotQuantity then
				n = n + INVENTORY_CONFIG.GetSlotQuantity(inv, slot)
			else
				n = n + 1
			end
		end
	end
	return n
end

-- Qualités NOMMÉES d'un enchantement, en fraction du plafond ABSOLU (MaxPct) :
-- un bas niveau ne peut pas dépasser « Correcte », c'est voulu (progression).
-- Ordre du plus haut au plus bas, EnchantQuality prend la première atteinte.
EVO_CRAFT.EnchantQualities = {
	{ min = 0.90, label = "Parfaite",   color = Color(255, 205, 90) },
	{ min = 0.75, label = "Supérieure", color = Color(90, 170, 255) },
	{ min = 0.58, label = "Soignée",    color = Color(96, 220, 130) },
	{ min = 0.40, label = "Correcte",   color = Color(225, 225, 230) },
	{ min = 0,    label = "Grossière",  color = Color(150, 152, 158) },
}

function EVO_CRAFT.EnchantQuality(nPct, sStat)
	local f = EVO_CRAFT.EnchantEffective(nPct, sStat) / EVO_CRAFT.EnchantCapFor(sStat)
	for _, q in ipairs(EVO_CRAFT.EnchantQualities) do
		if f >= q.min then return q end
	end
	return EVO_CRAFT.EnchantQualities[#EVO_CRAFT.EnchantQualities]
end

-- Gate de grade de l'enchantement (partagé : affichage client + refus serveur).
function EVO_CRAFT.CanEnchantRank(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= (EVO_CRAFT.EnchantCfg.MinRank or 3)
end

-- Plafond de tirage d'un niveau de craft (linéaire : FloorFrac du max au niv 1 -> 100% au niv 20).
-- Plafond ABSOLU d'un boost : celui de la stat si elle en déclare un (maxPct),
-- sinon le plafond commun. Un seul point de lecture pour le tirage ET pour la
-- qualité affichée, sinon un boost à plafond réduit sortirait toujours
-- « Grossière ».
function EVO_CRAFT.EnchantCapFor(sStat)
	local def = sStat and EVO_CRAFT.EnchantByKey(sStat)
	return (def and def.maxPct) or EVO_CRAFT.EnchantCfg.MaxPct or 5
end

-- ============================================================================
-- ÉCHELLE DES GRAVURES : le pct stocké est un SNAPSHOT du tirage, jamais
-- recalculé. Pour qu'un changement de balance (maxPct / RarityMult) atteigne
-- les pièces DÉJÀ gravées, chaque chaîne porte la RÉVISION d'échelle sous
-- laquelle elle a été tirée (suffixe ";v<rev>") et on reconvertit à la lecture.
--
-- ⚠ CONTRAT DE MAINTENANCE — changer un `maxPct` ou `EnchantCfg.RarityMult` :
--   1. recopier les valeurs SORTANTES dans EnchantScales[ENCHANT_REV] ;
--   2. incrémenter ENCHANT_REV.
-- C'est TOUT : le balayage de boot (sv_enchant_rescale) reconvertit l'existant
-- et le verrou cross-serveur est keyé sur la rev. Oublier l'étape 1 fige les
-- gravures existantes à l'ancienne échelle — c'est exactement le bug du 08/28.
--
-- La conversion conserve la QUALITÉ du tirage, pas le nombre : le tirage vaut
-- `cap(stat) × levelFrac × rarityMult × rollFrac` (cf. sv_craft_combat), donc
-- `pct / (cap × rarityMult)` isole le mérite du crafteur (niveau + mini-jeu).
-- On réapplique ensuite le cap ET la rareté COURANTS -> un nerf de rareté passe.
-- ParseEnchantList ignore les segments sans "stat:nombre" : le tampon est inerte.
-- ============================================================================
-- ⚠ RESTE À 3 tant que les caps / RarityMult du 08/28 sont en place : la rev
-- COURANTE est lue en direct dans EVO_CRAFT.Enchants / EnchantCfg, et le tampon
-- ";v3" est EXACTEMENT celui qu'écrivait f959722c7. Une ligne déjà gravée depuis
-- le 08/28 est donc reconnue « à jour » et n'est pas réécrite, et un serveur
-- encore en ancien code lit le même tampon -> aucun aller-retour d'échelle sur la
-- BDD `inventory`, qui est PARTAGÉE entre Seireitei et Garganta Hueco.
EVO_CRAFT.ENCHANT_REV = 4
EVO_CRAFT.ENCHANT_STAMP = "v" .. EVO_CRAFT.ENCHANT_REV -- compat lecture externe

-- Échelles PASSÉES, gelées : des valeurs en BDD les référencent, on n'y touche
-- plus jamais. Rééquilibrer = y ARCHIVER l'échelle sortante, puis bumper la rev.
EVO_CRAFT.EnchantScales = {
	-- rev 1 : système plat du 08/18 au 08/28 (d8311f9d5 -> 826bd5782).
	-- MaxPct = 15 pour TOUS les boosts ; katana_cc_chance est arrivé le 08/22
	-- (2a18e8a09) avec son propre plafond de 5. Valeurs relues dans git, PAS
	-- devinées : la table ENCHANT_OLD_FLAT_CAP de f959722c7 (2.3 / 3.0 / 1.7 …)
	-- ne correspondait à AUCUNE config ayant existé, d'où une conversion qui
	-- écrasait les bons tirages de ~70 % et gonflait les mauvais de ~500 %.
	[1] = {
		fallback = 15,
		caps = { katana_cc_chance = 5 },
		rarity = { common = 0.6, rare = 0.72, epic = 0.85, legendary = 0.95, mythic = 1 },
	},
	-- rev 2 : 08/28 « % de la stat de la PIÈCE », plafond COMMUN 50 (EnchantCfg.LegacyScale).
	[2] = {
		fallback = 50,
		caps = {},
		rarity = { common = 0.6, rare = 0.72, epic = 0.85, legendary = 0.95, mythic = 1 },
	},
	-- rev 3 : 08/28 -> 2026-09-18, plafonds PAR BOOST + courbe de rareté écartée
	-- (RarityMult 0.35 -> 1). Archivée le 2026-09-18 pour relever flashstep_cd
	-- (4 -> 12) : valeurs recopiées depuis la config VIVE de l'époque, pas devinées.
	[3] = {
		fallback = 5,
		caps = { max_hp = 5.0, max_reiatsu = 6.0, katana_damage = 4.5, spell_damage = 4.5,
		         flashstep_cd = 4.0, katana_cc_chance = 2.0 },
		rarity = { common = 0.35, rare = 0.50, epic = 0.70, legendary = 0.88, mythic = 1 },
	},
	-- rev 4 = COURANTE : lue en direct depuis EVO_CRAFT.Enchants / EnchantCfg
	-- (pas de copie ici, sinon deux sources de vérité qui divergent en silence).
	-- Au prochain rééquilibrage : recopier ici les valeurs SORTANTES, puis rev 5.
}

-- Échelle d'une révision. La révision COURANTE est construite à la volée depuis
-- la config vive ; les précédentes viennent de l'archive.
function EVO_CRAFT.EnchantScaleFor(nRev)
	nRev = math.floor(tonumber(nRev) or 0)
	if nRev == EVO_CRAFT.ENCHANT_REV then
		local caps = {}
		for _, e in ipairs(EVO_CRAFT.Enchants) do
			if e.maxPct then caps[e.key] = e.maxPct end
		end
		return {
			caps = caps,
			fallback = EVO_CRAFT.EnchantCfg.MaxPct or 5,
			rarity = EVO_CRAFT.EnchantCfg.RarityMult or {},
		}
	end
	return EVO_CRAFT.EnchantScales[nRev]
end

local function enchantRarityOf(item_id)
	local it = ITEMS and ITEMS[item_id]
	return (it and it.rarity) or "common"
end

-- Rev lue sur une chaîne stockée. Le tampon est TOUJOURS un suffixe
-- (EnchantStampString concatène en fin), donc l'ancrage $ est sûr.
-- nil = chaîne d'avant le tamponnage (rev 1 ou 2, tranché par valeur).
function EVO_CRAFT.EnchantReadRev(raw)
	if not isstring(raw) then return nil end
	return tonumber(string.match(raw, ";v(%d+)%s*$"))
end

function EVO_CRAFT.EnchantHasStamp(raw)
	return EVO_CRAFT.EnchantReadRev(raw) ~= nil
end

function EVO_CRAFT.EnchantStampString(sStr)
	if not isstring(sStr) or sStr == "" then return sStr end
	if EVO_CRAFT.EnchantHasStamp(sStr) then return sStr end
	return sStr .. ";v" .. EVO_CRAFT.ENCHANT_REV
end

-- Rev d'une valeur NON tamponnée : une gravure rev 1 ne peut pas dépasser
-- son cap rev 1 (× rareté ≤ 1), donc au-dessus c'est forcément l'échelle 50.
local function enchantGuessRev(nPct, sStat)
	local sc1 = EVO_CRAFT.EnchantScales[1]
	local nCap1 = (sc1.caps[sStat] or sc1.fallback)
	return (nPct > nCap1 + 0.051) and 2 or 1
end

-- Fraction du tirage MAXIMAL possible sous nRev (le mérite du crafteur, 0..1).
function EVO_CRAFT.EnchantQualityFrac(nPct, sStat, sRarity, nRev)
	local sc = EVO_CRAFT.EnchantScaleFor(nRev)
	if not sc then return 0 end
	local nMax = (sc.caps[sStat] or sc.fallback or 0) * (sc.rarity[sRarity] or 1)
	if nMax <= 0 then return 0 end
	return (tonumber(nPct) or 0) / nMax
end

-- Valeur stockée sous nFromRev -> valeur à l'échelle COURANTE, qualité conservée.
function EVO_CRAFT.EnchantRescale(nPct, sStat, item_id, nFromRev)
	nPct = tonumber(nPct) or 0
	local nCap = EVO_CRAFT.EnchantCapFor(sStat)
	if nPct <= 0 then return 0 end
	local sRar = enchantRarityOf(item_id)
	local f = EVO_CRAFT.EnchantQualityFrac(nPct, sStat, sRar, nFromRev)
	if f <= 0 then return math.Clamp(math.Round(nPct, 2), 0.1, nCap) end
	local nOut = f * nCap * ((EVO_CRAFT.EnchantCfg.RarityMult or {})[sRar] or 1)
	return math.Clamp(math.Round(nOut, 2), 0.1, nCap)
end

-- Compat : conversion d'une valeur NON tamponnée (rev deviné) vers la courante.
function EVO_CRAFT.EnchantMigrateValue(nPct, sStat, item_id)
	nPct = tonumber(nPct) or 0
	if nPct <= 0 then return 0 end
	return EVO_CRAFT.EnchantRescale(nPct, sStat, item_id, enchantGuessRev(nPct, sStat))
end

-- raw inventaire -> chaîne à l'échelle courante + tampon ;v<rev>. 2e retour = a changé.
function EVO_CRAFT.EnchantMigrateString(raw, item_id)
	if not (isstring(raw) and raw ~= "" and INVENTORY_CONFIG and INVENTORY_CONFIG.ParseEnchantList) then
		return raw, false
	end
	-- 🔴 item_id INCONNU = rareté inconnue = conversion fausse, et FIGÉE par le
	-- tampon qu'on poserait derrière. On préfère ne rien réécrire : la ligne
	-- repassera au prochain chargement, ou par le balayage global (qui lit
	-- toujours item_id sur la ligne BDD). C'est ce que produisait le slot 1007.
	if not (isstring(item_id) and item_id ~= "") then return raw, false end
	local tList = INVENTORY_CONFIG.ParseEnchantList(raw)
	if #tList == 0 then return raw, false end
	local nRev = EVO_CRAFT.EnchantReadRev(raw)
	local tNew = {}
	for i, e in ipairs(tList) do
		local n
		if nRev == EVO_CRAFT.ENCHANT_REV then
			-- Déjà à l'échelle : on borne seulement (valeur corrompue en BDD).
			n = math.Clamp(e.pct, 0.1, EVO_CRAFT.EnchantCapFor(e.stat))
		else
			n = EVO_CRAFT.EnchantRescale(e.pct, e.stat, item_id, nRev or enchantGuessRev(e.pct, e.stat))
		end
		tNew[i] = { stat = e.stat, pct = n }
	end
	local s = EVO_CRAFT.EnchantStampString(INVENTORY_CONFIG.EnchantListString(tNew))
	return s, s ~= raw
end

-- Affichage / apply d'un pct DÉJÀ parsé, sans sa chaîne : on ne peut trancher
-- que le cas non ambigu (au-dessus du cap = échelle 50). Le vrai chemin est
-- EnchantMigrateString sur le brut, que l'inventaire et l'atelier appellent.
function EVO_CRAFT.EnchantEffective(nPct, sStat, item_id)
	nPct = tonumber(nPct) or 0
	if nPct <= 0 then return 0 end
	local nCap = EVO_CRAFT.EnchantCapFor(sStat)
	if nPct > nCap then
		return EVO_CRAFT.EnchantRescale(nPct, sStat, item_id, 2)
	end
	return nPct
end

function EVO_CRAFT.EnchantMaxRoll(nLevel, sStat)
	local c = EVO_CRAFT.EnchantCfg
	nLevel = math.Clamp(tonumber(nLevel) or 1, 1, EVO_CRAFT.MaxLevel)
	local f = c.FloorFrac + (1 - c.FloorFrac) * (nLevel - 1) / (EVO_CRAFT.MaxLevel - 1)
	return EVO_CRAFT.EnchantCapFor(sStat) * f
end

function EVO_CRAFT.EnchantCostFor(item_id)
	local it = ITEMS and ITEMS[item_id]
	local r = (it and it.rarity) or "common"
	return EVO_CRAFT.EnchantCfg.Cost[r] or EVO_CRAFT.EnchantCfg.Cost.common
end

-- Enchantable = un accessoire À STATS (même règle que la forge).
function EVO_CRAFT.IsItemEnchantable(item_id)
	local it = ITEMS and ITEMS[item_id]
	if not it then return false end
	return it.category == "accessory" and istable(it.stats)
end
