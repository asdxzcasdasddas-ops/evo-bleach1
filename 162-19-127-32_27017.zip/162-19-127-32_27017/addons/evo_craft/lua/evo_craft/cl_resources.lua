-- "addons\\evo_craft\\lua\\evo_craft\\cl_resources.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Ressources d'artisanat, côté client : prompt « [E] Ramasser » au-dessus des
-- nœuds (bois / roche / métal brut), envoi du ramassage au serveur. Même
-- recette que la récolte science : identification par CHEMIN DE MODÈLE, aucune
-- clé réseau. Plaque légèrement plus HAUTE que le prompt science (0.74 contre
-- 0.78) : les deux peuvent coexister à l'écran sans se chevaucher.

-- Seuls les types qui poussent sur des nœuds (les os viennent des kills).
local NODE_TYPES = { "res_bois", "res_roche", "res_metal_brut" }

local MODELS = nil -- [modelLower] = item id
local function modelSet()
	if MODELS then return MODELS end
	MODELS = {}
	for _, sId in ipairs(NODE_TYPES) do
		local r = EVO_CRAFT.Resources and EVO_CRAFT.Resources[sId]
		if r then MODELS[string.lower(r.model)] = sId end
	end
	return MODELS
end

-- Scan throttlé ~4 Hz : le nœud le plus proche à portée.
local _best, _bestId, _nextScan = nil, nil, 0
local function findNode()
	if CurTime() < _nextScan then return _best end
	_nextScan = CurTime() + 0.25
	_best, _bestId = nil, nil
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return nil end
	local set = modelSet()
	local range = (EVO_CRAFT.ResNodes and EVO_CRAFT.ResNodes.UseDist) or 110
	local vPos = lp:GetPos()
	local bestD = range * range
	for _, e in ipairs(ents.FindInSphere(vPos, range)) do
		if IsValid(e) then
			local sId = set[string.lower(e:GetModel() or "")]
			if sId then
				local d = e:GetPos():DistToSqr(vPos)
				if d <= bestD then
					bestD = d
					_best = e
					_bestId = sId
				end
			end
		end
	end
	return _best
end

surface.CreateFont("EVOCraftRes_Prompt", { font = "Roboto", size = 22, weight = 600, antialias = true })
surface.CreateFont("EVOCraftRes_Sub", { font = "Roboto", size = 16, weight = 400, antialias = true })

local COL_ACCENT = Color(216, 185, 106) -- doré artisanat (pas le vert labo)

hook.Add("HUDPaint", "EVO_Craft::ResPrompt", function()
	if vgui.CursorVisible() then return end
	-- Pas de prompt pendant qu'on mange/boit (prédicat central evo_science).
	if EVO_SCIENCE and EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end
	local ent = findNode()
	if not IsValid(ent) then return end

	local txt = "[E] Ramasser"
	local sub = EVO_CRAFT.ResourceName(_bestId)
	local cx, cy = ScrW() * 0.5, ScrH() * 0.74
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(cx, cy, sub, "Ramasser", "E")
		return
	end
	surface.SetFont("EVOCraftRes_Prompt")
	local tw, th = surface.GetTextSize(txt)
	surface.SetFont("EVOCraftRes_Sub")
	local sw, sh = surface.GetTextSize(sub)
	local boxW = math.max(tw, sw) + 40
	local boxH = th + sh + 26

	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(13, 14, 17, 220), 8, "br")
	else
		draw.RoundedBox(0, cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(0, 0, 0, 180))
	end
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(cx - boxW * 0.5, cy - boxH * 0.5, 2, boxH)
	draw.SimpleText(txt, "EVOCraftRes_Prompt", cx, cy - 8, Color(235, 235, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sub, "EVOCraftRes_Sub", cx, cy + th * 0.5 + 2, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("PlayerButtonDown", "EVO_Craft::ResPickKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() then return end
	if gui.IsGameUIVisible() then return end
	if IsValid(vgui.GetKeyboardFocus()) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if EVO_SCIENCE and EVO_SCIENCE.EatBusy and EVO_SCIENCE.EatBusy() then return end

	local ent = findNode()
	if not IsValid(ent) then return end
	net.Start("EVO_Craft:ResPick")
	net.WriteEntity(ent)
	net.SendToServer()
end)
