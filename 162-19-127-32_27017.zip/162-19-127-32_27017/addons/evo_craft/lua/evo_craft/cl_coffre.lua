-- "addons\\evo_craft\\lua\\evo_craft\\cl_coffre.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Coffre de division, côté client — PLEIN ÉCRAN, DA Atelier v2 (kit EVO_UI).
-- Retours user 08/16 : pas de kanji (filigrane ni sidebar), header épuré sans
-- rappel de rayons, titres plus gros, rayons nommés RAYON / RAYON SECRET,
-- vue don = SEULS les objets donnables, catégories SEULEMENT dans la vue COFFRE.

local CATS = EVO_CRAFT.CoffreCats

local frame
local STATE = {
	div = "", secret = false, rows = {}, folders = {}, log = {},
	vault = 3, cat = "all", view = "coffre", sel = nil, sorted = false,
	folderId = 0, canManage = true,
}

local function Col()
	return (EVO_UI and EVO_UI.Col) or {
		title = Color(238, 239, 243), muted = Color(150, 154, 162),
		dim = Color(106, 109, 118), accent = Color(207, 68, 78),
		green = Color(78, 196, 128), divider = Color(255, 255, 255, 18),
	}
end

local function itemDef(id) return ITEMS and ITEMS[id] or nil end
local function itemName(id)
	local it = itemDef(id)
	-- Repli : jamais d'id brut a underscores a l'ecran (demande user 08/18).
	return (it and it.name) or (tostring(id):gsub("_", " "))
end
local function rarityCol(id)
	local it = itemDef(id)
	if EVO_HDV and EVO_HDV.RarityColor then return EVO_HDV.RarityColor(it and it.rarity) end
	return Col().muted
end
local function rarityName(id)
	local it = itemDef(id)
	if EVO_HDV and EVO_HDV.RarityNames and it and it.rarity then
		return EVO_HDV.RarityNames[it.rarity] or ""
	end
	return ""
end

local function slotQty(slot)
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
	if INVENTORY_CONFIG and INVENTORY_CONFIG.GetSlotQuantity then
		return math.max(1, math.floor(tonumber(INVENTORY_CONFIG.GetSlotQuantity(inv, slot)) or 1))
	end
	return 1
end

local function rowQty(r)
	return math.max(1, math.floor(tonumber(r and r.q) or 1))
end

local function logWhen(e)
	local ts = tonumber(e and e.t) or 0
	if ts <= 0 then return "—" end
	return os.date("%d/%m %H:%M", ts)
end
local function logWho(e)
	local n = e and e.n
	if isstring(n) and n ~= "" then return n end
	return "Anonyme"
end

-- Aperçu d'objet : modèle 3D si dispo (helper inventaire), sinon PNG.
local matCache = {}
local function AttachIcon(tile, it, nInset)
	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview
		and LZY_INVENTORY_ITEM_PREVIEW.ItemHasModelPreview(it) then
		LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(tile, it, nil, nil, nInset)
		return
	end
	local sIcon = it and it.icon
	if not isstring(sIcon) or sIcon == "" then return end
	matCache[sIcon] = matCache[sIcon] or Material(sIcon, "smooth")
	local m = matCache[sIcon]
	local nScale = (it and tonumber(it.icon_scale)) or 1
	tile.PaintOver = function(_, w, h)
		if not m or m:IsError() then return end
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(m)
		local s = math.min(w, h) * 0.8 * nScale
		surface.DrawTexturedRect((w - s) / 2, (h - s) / 2 - gRespY(7), s, s)
	end
end

local function netDon(slot, vault, amount, folderId)
	net.Start("EVO:Craft:CoffreDon")
	net.WriteUInt(slot, 16)
	net.WriteUInt(vault, 8)
	net.WriteUInt(math.max(1, math.floor(tonumber(amount) or 1)), 16)
	net.WriteUInt(math.max(0, math.floor(tonumber(folderId) or 0)), 32)
	net.SendToServer()
end
local function netTake(id, amount)
	net.Start("EVO:Craft:CoffreTake")
	net.WriteUInt(id, 32)
	net.WriteUInt(math.max(1, math.floor(tonumber(amount) or 1)), 16)
	net.SendToServer()
end
local function netSort()
	net.Start("EVO:Craft:CoffreSort")
	net.WriteUInt(STATE.vault == 10 and 10 or 3, 8)
	net.SendToServer()
end
local function netClose()
	net.Start("EVO:Craft:CoffreClose")
	net.SendToServer()
end
local function netFolderCreate(name, vault)
	net.Start("EVO:Craft:CoffreFolderCreate")
	net.WriteString(tostring(name or ""))
	net.WriteUInt(vault == 10 and 10 or 3, 8)
	net.SendToServer()
end
local function netFolderRename(id, name)
	net.Start("EVO:Craft:CoffreFolderRename")
	net.WriteUInt(math.max(1, math.floor(tonumber(id) or 0)), 32)
	net.WriteString(tostring(name or ""))
	net.SendToServer()
end
local function netFolderDelete(id)
	net.Start("EVO:Craft:CoffreFolderDelete")
	net.WriteUInt(math.max(1, math.floor(tonumber(id) or 0)), 32)
	net.SendToServer()
end
local function netFolderMove(itemId, folderId)
	net.Start("EVO:Craft:CoffreFolderMove")
	net.WriteUInt(math.max(1, math.floor(tonumber(itemId) or 0)), 32)
	net.WriteUInt(math.max(0, math.floor(tonumber(folderId) or 0)), 32)
	net.SendToServer()
end

-- Saisie de nom de dossier : DA EVO (EVO_StaffPrompt), repli Derma.
local function PromptFolderName(title, default, onOk)
	default = tostring(default or "")
	local function accept(txt)
		if not isstring(txt) then return end
		txt = string.gsub(txt, "^%s+", "")
		txt = string.gsub(txt, "%s+$", "")
		if txt == "" then return end
		onOk(txt)
	end
	if EVO_StaffPrompt then
		EVO_StaffPrompt(title, {
			{ label = "Nom du dossier", default = default },
		}, accept)
		return
	end
	Derma_StringRequest(title, "Nom du dossier :", default, accept)
end

local DROP_NAME = "evo_coffre_div_item"

-- Picker DÉPLACER : carte DA EVO (pas de DermaMenu gris).
local function OpenMovePicker(itemId, nCurrent, tFolders)
	if not IsValid(frame) then return end
	if IsValid(frame._movePicker) then frame._movePicker:Remove() end
	local col = Col()
	nCurrent = tonumber(nCurrent) or 0
	itemId = tonumber(itemId) or 0
	if itemId < 1 then return end

	local options = {}
	if nCurrent > 0 then
		options[#options + 1] = { id = 0, label = "Racine" }
	end
	for _, f in ipairs(tFolders or {}) do
		if f.id ~= nCurrent then
			options[#options + 1] = { id = f.id, label = f.name or "Dossier" }
		end
	end

	local modal = vgui.Create("DButton", frame)
	modal:SetText("")
	modal:SetSize(frame:GetWide(), frame:GetTall())
	modal:SetPos(0, 0)
	modal:MoveToFront()
	modal.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 170)
		surface.DrawRect(0, 0, w, h)
	end
	modal.DoClick = function()
		if IsValid(modal) then modal:Remove() end
	end
	frame._movePicker = modal

	local rowH = gRespY(50)
	local W = gRespX(380)
	local nRows = math.max(1, #options)
	local H = gRespY(72) + nRows * (rowH + gRespY(8)) + gRespY(20)
	local card = vgui.Create("DPanel", modal)
	card:SetSize(W, H)
	card:Center()
	card:SetMouseInputEnabled(true)
	card.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, Color(16, 17, 21, 250), gRespY(12))
		draw.SimpleText("DÉPLACER VERS", "Bebas Neue:32", gRespX(22), gRespY(30),
			col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:32")
		local tw = surface.GetTextSize("DÉPLACER VERS")
		if not (EVO_UI.TitleSlash and EVO_UI.TitleSlash(gRespX(18), gRespY(48), tw, 1)) then
			surface.SetDrawColor(col.accent)
			surface.DrawRect(gRespX(22), gRespY(48), tw, gRespY(3))
		end
	end
	-- Clic dans la carte ne ferme pas.
	card.OnMousePressed = function() end

	local y = gRespY(66)
	if #options == 0 then
		local lbl = vgui.Create("DLabel", card)
		lbl:SetPos(gRespX(22), y)
		lbl:SetSize(W - gRespX(44), rowH)
		lbl:SetFont("Bebas Neue:22")
		lbl:SetTextColor(col.dim)
		lbl:SetContentAlignment(4)
		lbl:SetText("Aucun dossier disponible.")
		return
	end
	for _, opt in ipairs(options) do
		local b = vgui.Create("DButton", card)
		b:SetPos(gRespX(18), y)
		b:SetSize(W - gRespX(36), rowH)
		b:SetText("")
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local gx, gy, gw, gh = EVO_UI.HoverPlate(s, w, h, { cut = gRespY(8), growPx = 2, offPx = 2, screws = false })
			draw.SimpleText(EVO_UI.TruncText(opt.label, "Bebas Neue:24", gw - gRespX(28)), "Bebas Neue:24",
				gx + gRespX(16), gy + gh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound(EVO_UI.SndClick)
			netFolderMove(itemId, opt.id)
			STATE.sel = nil
			if IsValid(modal) then modal:Remove() end
		end
		y = y + rowH + gRespY(8)
	end
end

local function FolderNameOf(nId)
	nId = tonumber(nId) or 0
	if nId < 1 then return "Racine" end
	for _, f in ipairs(STATE.folders or {}) do
		if f.id == nId then return f.name or ("Dossier " .. nId) end
	end
	return "Dossier"
end

local function VaultFolders()
	local t = {}
	for _, f in ipairs(STATE.folders or {}) do
		if (tonumber(f.v) or 3) == STATE.vault then
			t[#t + 1] = f
		end
	end
	return t
end

local function FolderItemCount(nId)
	local n = 0
	for _, r in ipairs(STATE.rows or {}) do
		if r.v == STATE.vault and (tonumber(r.c) or 0) == nId then
			n = n + 1
		end
	end
	return n
end

-- Header maison (retours user) : titre PLUS GROS, pas de texte à droite,
-- entaille calibrée sur le titre + filet denté.
local function DrawHeader(w, sTitle)
	local col = Col()
	local padX = gRespX(26)
	-- 3e passe d'agrandissement (user 08/19 : « c'est écrit tout petit ») :
	-- titre 42 -> 56, entaille et filet descendus d'autant (le contenu commence
	-- à TOP_Y, remonté en conséquence).
	draw.SimpleText(sTitle, "Bebas Neue:56", padX, gRespY(42), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:56")
	local tw = surface.GetTextSize(sTitle)
	if not (EVO_UI.TitleSlash and EVO_UI.TitleSlash(padX - gRespX(4), gRespY(72), tw, 1)) then
		surface.SetDrawColor(col.accent)
		surface.DrawRect(padX, gRespY(76), tw, gRespY(3))
	end
	surface.SetDrawColor(ColorAlpha(col.divider, 55))
	local dashW, dashGap = gRespX(6), gRespX(5)
	local dx = padX
	while dx < w - padX do
		surface.DrawRect(dx, gRespY(90), math.min(dashW, w - padX - dx), 1)
		dx = dx + dashW + dashGap
	end
end

-- ============================================================================
-- FILTRES
-- ============================================================================
local function CoffreRows()
	local nFolder = tonumber(STATE.folderId) or 0
	local t = {}
	for _, r in ipairs(STATE.rows) do
		if r.v == STATE.vault
			and (tonumber(r.c) or 0) == nFolder
			and (STATE.cat == "all" or EVO_CRAFT.CoffreCatOf(r.i) == STATE.cat) then
			t[#t + 1] = r
		end
	end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.CompareItemsForSort then
		table.sort(t, function(a, b)
			return INVENTORY_CONFIG.CompareItemsForSort(a.i, b.i)
		end)
	end
	return t
end

-- Le coffre le plus proche est-il le FRIGO du labo (identité propre) ?
-- Miroir client de NearbyCoffre (même rayon 220).
local function NearFrigo()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	local best, bestD = nil, 220 * 220
	for _, e in ipairs(ents.FindByClass("evo_coffre_division")) do
		local d = lp:GetPos():DistToSqr(e:GetPos())
		if d < bestD then best, bestD = e, d end
	end
	return IsValid(best) and best.GetLabelOverride ~= nil and best:GetLabelOverride() ~= ""
end

-- Vue don : SEULS les objets donnables (demande user), pas de tuiles grisées.
-- Au FRIGO, la liste se limite au consommable utile (même filtre que le serveur).
local function BagRows()
	local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory() or { items = {} }
	local nMax = (INVENTORY_CONFIG and INVENTORY_CONFIG.MAX_BAG_SLOTS) or 80
	local bFrigo = NearFrigo()
	local t = {}
	for slot = 1, nMax do
		local id = inv.items[slot]
		if isstring(id) and id ~= "" and EVO_CRAFT.CoffreDeposable(id)
			and (not bFrigo or EVO_CRAFT.FrigoDeposable(id)) then
			t[#t + 1] = { slot = slot, i = id, q = slotQty(slot) }
		end
	end
	return t
end

-- ============================================================================
-- PANNEAU DÉTAIL (droite) : actions DA.
-- ============================================================================
-- Forward : BuildDetail ouvre un dossier via BuildGrid (défini plus bas).
local BuildGrid

local function BuildDetail()
	if not (IsValid(frame) and IsValid(frame._detail)) then return end
	local d = frame._detail
	d:Clear()
	local col = Col()
	local dw = d:GetWide()
	local sel = STATE.sel

	if not sel then
		local lbl = vgui.Create("DLabel", d)
		lbl:SetPos(0, gRespY(120))
		lbl:SetSize(dw, gRespY(52))
		lbl:SetFont("Bebas Neue:26")
		lbl:SetTextColor(col.dim)
		lbl:SetContentAlignment(5)
		lbl:SetText(STATE.view == "don" and "Choisis un objet de ton sac."
			or STATE.view == "hist" and "Choisis une ligne."
			or "Choisis un objet ou un dossier.")
		return
	end

	-- Dossier sélectionné (racine uniquement) : ouvrir / renommer / supprimer.
	if sel._folder then
		local y = gRespY(40)
		local name = vgui.Create("DLabel", d)
		name:SetPos(gRespX(14), y)
		name:SetSize(dw - gRespX(28), gRespY(46))
		name:SetFont("Bebas Neue:40")
		name:SetTextColor(col.title)
		name:SetText(EVO_UI.TruncText(sel.name or "Dossier", "Bebas Neue:40", dw - gRespX(28)))
		y = y + gRespY(54)

		local cnt = vgui.Create("DLabel", d)
		cnt:SetPos(gRespX(14), y)
		cnt:SetSize(dw - gRespX(28), gRespY(28))
		cnt:SetFont("Bebas Neue:24")
		cnt:SetTextColor(col.muted)
		local nCnt = FolderItemCount(sel.id)
		cnt:SetText(nCnt .. (nCnt > 1 and " objets" or " objet"))
		y = y + gRespY(40)

		local bw = dw - gRespX(28)
		local bh = gRespY(50)
		local function bigBtn(b)
			if IsValid(b) then b._font = "Bebas Neue:28" end
			return b
		end
		bigBtn(EVO_UI.ActionButton(d, gRespX(14), d:GetTall() - gRespY(14) - bh, bw, bh, "OUVRIR", nil, function()
			STATE.folderId = sel.id
			STATE.sel = nil
			BuildGrid()
		end))
		if STATE.canManage then
			bigBtn(EVO_UI.ActionButton(d, gRespX(14), d:GetTall() - gRespY(14) - bh * 2 - gRespY(8), bw, bh, "RENOMMER", Color(52, 56, 64), function()
				PromptFolderName("Renommer le dossier", sel.name or "", function(txt)
					netFolderRename(sel.id, txt)
				end)
			end))
			bigBtn(EVO_UI.ActionButton(d, gRespX(14), d:GetTall() - gRespY(14) - bh * 3 - gRespY(16), bw, bh, "SUPPRIMER", Color(72, 36, 40), function()
				Derma_Query("Supprimer ce dossier ? Son contenu revient à la racine.", "Dossier",
					"Supprimer", function()
						netFolderDelete(sel.id)
						STATE.sel = nil
						BuildDetail()
					end,
					"Annuler", function() end)
			end))
		end
		return
	end

	if STATE.view == "hist" then
		local sID = sel.i
		local it = itemDef(sID)
		local bDon = sel.k == "don"
		local kc = bDon and (col.green or col.title) or col.accent

		local prev = vgui.Create("DPanel", d)
		prev:SetPos(gRespX(14), gRespY(10))
		prev:SetSize(dw - gRespX(28), gRespY(190))
		prev.Paint = function(_, w, h)
			EVO_UI.PaintCut(0, 0, w, h, Color(19, 21, 26, 235), gRespY(10))
			local rc = rarityCol(sID)
			surface.SetDrawColor(rc.r, rc.g, rc.b, 235)
			surface.DrawRect(0, h - gRespY(3), w, gRespY(3))
		end
		AttachIcon(prev, it, gRespY(10))

		local y = gRespY(212)
		local name = vgui.Create("DLabel", d)
		name:SetPos(gRespX(14), y)
		name:SetSize(dw - gRespX(28), gRespY(46))
		name:SetFont("Bebas Neue:44")
		name:SetTextColor(col.title)
		name:SetText(EVO_UI.TruncText(itemName(sID), "Bebas Neue:44", dw - gRespX(28)))
		y = y + gRespY(50)

		local act = vgui.Create("DLabel", d)
		act:SetPos(gRespX(14), y)
		act:SetSize(dw - gRespX(28), gRespY(30))
		act:SetFont("Bebas Neue:28")
		act:SetTextColor(kc)
		act:SetText(bDon and "DÉPÔT" or "RETRAIT")
		y = y + gRespY(32)

		local qSel = rowQty(sel)
		if qSel > 1 then
			local qty = vgui.Create("DLabel", d)
			qty:SetPos(gRespX(14), y)
			qty:SetSize(dw - gRespX(28), gRespY(28))
			qty:SetFont("Bebas Neue:26")
			qty:SetTextColor(col.title)
			qty:SetText("×" .. qSel)
			y = y + gRespY(30)
		end

		local who = vgui.Create("DLabel", d)
		who:SetPos(gRespX(14), y)
		who:SetSize(dw - gRespX(28), gRespY(26))
		who:SetFont("Bebas Neue:24")
		who:SetTextColor(col.muted)
		who:SetText(logWho(sel))
		y = y + gRespY(26)

		local when = vgui.Create("DLabel", d)
		when:SetPos(gRespX(14), y)
		when:SetSize(dw - gRespX(28), gRespY(26))
		when:SetFont("Bebas Neue:24")
		when:SetTextColor(col.muted)
		when:SetText(logWhen(sel))
		y = y + gRespY(26)

		if sel.v == 10 then
			local sec = vgui.Create("DLabel", d)
			sec:SetPos(gRespX(14), y)
			sec:SetSize(dw - gRespX(28), gRespY(26))
			sec:SetFont("Bebas Neue:22")
			sec:SetTextColor(col.accent)
			sec:SetText("Rayon secret")
		end
		return
	end

	local sID = sel.i
	local it = itemDef(sID)

	-- Grand aperçu.
	local prev = vgui.Create("DPanel", d)
	prev:SetPos(gRespX(14), gRespY(10))
	prev:SetSize(dw - gRespX(28), gRespY(190))
	prev.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, Color(19, 21, 26, 235), gRespY(10))
		local rc = rarityCol(sID)
		surface.SetDrawColor(rc.r, rc.g, rc.b, 235)
		surface.DrawRect(0, h - gRespY(3), w, gRespY(3))
	end
	AttachIcon(prev, it, gRespY(10))

	local y = gRespY(212)
	local name = vgui.Create("DLabel", d)
	name:SetPos(gRespX(14), y)
	name:SetSize(dw - gRespX(28), gRespY(46))
	name:SetFont("Bebas Neue:44")
	name:SetTextColor(col.title)
	name:SetText(EVO_UI.TruncText(itemName(sID), "Bebas Neue:44", dw - gRespX(28)))
	y = y + gRespY(50)

	local qSel = rowQty(sel)
	if qSel > 1 then
		local qty = vgui.Create("DLabel", d)
		qty:SetPos(gRespX(14), y)
		qty:SetSize(dw - gRespX(28), gRespY(28))
		qty:SetFont("Bebas Neue:26")
		qty:SetTextColor(col.title)
		qty:SetText("×" .. qSel)
		y = y + gRespY(30)
	end

	local sRar = rarityName(sID)
	if sRar ~= "" then
		local rar = vgui.Create("DLabel", d)
		rar:SetPos(gRespX(14), y)
		rar:SetSize(dw - gRespX(28), gRespY(30))
		rar:SetFont("Bebas Neue:28")
		rar:SetTextColor(rarityCol(sID))
		rar:SetText(sRar)
		y = y + gRespY(34)
	end

	-- Donateur (coffre) : nom RP ; vide = ligne ancienne sans nom.
	if sel.don ~= nil then
		local don = vgui.Create("DLabel", d)
		don:SetPos(gRespX(14), y)
		don:SetSize(dw - gRespX(28), gRespY(26))
		don:SetFont("Bebas Neue:24")
		don:SetTextColor(col.muted)
		don:SetText((sel.don ~= "") and ("Don de " .. sel.don) or "Don anonyme")
		y = y + gRespY(26)
	end

	-- Stats (mêmes lignes que l'HDV, avec le niveau de forge de l'instance).
	if EVO_HDV and EVO_HDV.StatLines then
		for _, sLine in ipairs(EVO_HDV.StatLines(sID, sel.f) or {}) do
			local st = vgui.Create("DLabel", d)
			st:SetPos(gRespX(14), y)
			st:SetSize(dw - gRespX(28), gRespY(24))
			st:SetFont("Bebas Neue:24")
			st:SetTextColor(col.muted)
			st:SetText(sLine)
			y = y + gRespY(26)
		end
	end

	-- Actions (fonte agrandie via _font, cf. EVO_UI.ActionButton).
	local bw = dw - gRespX(28)
	local bh = gRespY(50)
	local qMax = rowQty(sel)
	local qtyH = (qMax > 1 and EVO_UI.QtyPicker) and gRespY(58) or 0
	local nExtra = 0
	if STATE.view == "coffre" and STATE.canManage and sel.id then
		nExtra = nExtra + 1
	end
	local by = d:GetTall() - gRespY(14) - bh
	if STATE.view == "don" and STATE.secret then
		by = by - bh - gRespY(8)
	elseif STATE.view == "coffre" and nExtra > 0 then
		by = by - bh - gRespY(8)
	end
	local getQty = function() return qMax end
	if qtyH > 0 then
		getQty = EVO_UI.QtyPicker(d, gRespX(14), by - qtyH - gRespY(8), bw, qtyH, qMax, qMax)
	end
	local function bigBtn(b)
		if IsValid(b) then b._font = "Bebas Neue:28" end
		return b
	end
	local function depositFolderFor(nVault)
		local nF = tonumber(STATE.folderId) or 0
		if nF < 1 then return 0 end
		for _, f in ipairs(STATE.folders or {}) do
			if f.id == nF and (tonumber(f.v) or 3) == nVault then return nF end
		end
		return 0
	end
	if STATE.view == "don" then
		local nFold3 = depositFolderFor(3)
		local nFold10 = depositFolderFor(10)
		local sDest3 = (nFold3 > 0) and (" · " .. string.upper(FolderNameOf(nFold3))) or ""
		local sDest10 = (nFold10 > 0) and (" · " .. string.upper(FolderNameOf(nFold10))) or ""
		if STATE.secret then
			bigBtn(EVO_UI.ActionButton(d, gRespX(14), d:GetTall() - gRespY(14) - bh, bw, bh, "DÉPOSER · RAYON SECRET" .. sDest10, Color(52, 56, 64), function()
				netDon(sel.slot, 10, getQty(), nFold10)
				STATE.sel = nil
			end))
		end
		bigBtn(EVO_UI.ActionButton(d, gRespX(14), by, bw, bh, "DÉPOSER · RAYON" .. sDest3, nil, function()
			netDon(sel.slot, 3, getQty(), nFold3)
			STATE.sel = nil
		end))
	else
		if STATE.canManage and sel.id then
			local nTargetFolder = tonumber(STATE.folderId) or 0
			bigBtn(EVO_UI.ActionButton(d, gRespX(14), by, bw, bh, "DÉPLACER", Color(52, 56, 64), function()
				OpenMovePicker(sel.id, nTargetFolder, VaultFolders())
			end))
		end
		bigBtn(EVO_UI.ActionButton(d, gRespX(14), d:GetTall() - gRespY(14) - bh, bw, bh, "RÉCUPÉRER", nil, function()
			netTake(sel.id, getQty())
			STATE.sel = nil
			BuildDetail()
		end))
	end
end

-- ============================================================================
-- GRILLE (tuiles HoverPlate, rareté = barre fonctionnelle conservée)
-- ============================================================================
BuildGrid = function()
	if not (IsValid(frame) and IsValid(frame._grid)) then return end
	local grid = frame._grid
	grid:Clear()
	local col = Col()

	-- Sous-onglets RAYON / RAYON SECRET + catégories : SEULEMENT dans la vue
	-- COFFRE (retour user : les rayons sont des sous-onglets du coffre, pas des
	-- entrées de sidebar). La vue don liste tout ce qui est donnable, sans filtre.
	local nFolder = tonumber(STATE.folderId) or 0
	local bInFolder = nFolder > 0
	if IsValid(frame._cats) then
		local bCoffre = STATE.view == "coffre"
		if IsValid(frame._vaults) then frame._vaults:SetVisible(bCoffre and not bInFolder) end
		frame._cats:SetVisible(bCoffre)
		-- Rayons cachés en dossier : remonter les catégories, grille juste en dessous
		-- avec le même écart catégorie→grille qu'à la racine (pas le trou du rayon).
		local nGridY = frame._gridY
		if bCoffre and bInFolder then
			frame._cats:SetPos(frame._gridX, frame._topY)
			nGridY = frame._topY + (frame._gridY - (frame._catsY or frame._topY))
		else
			frame._cats:SetPos(frame._gridX, frame._catsY or frame._topY)
		end
		if IsValid(frame._sort) then frame._sort:SetVisible(bCoffre and not bInFolder) end
		if IsValid(frame._newFolder) then frame._newFolder:SetVisible(bCoffre and not bInFolder and STATE.canManage) end
		grid:SetPos(frame._gridX, bCoffre and nGridY or frame._topY)
		grid:SetTall(bCoffre and (frame._gridH + (frame._gridY - nGridY)) or (frame._gridH + (frame._gridY - frame._topY)))
	end

	if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession then
		LZY_INVENTORY_ITEM_PREVIEW.BeginLazyLoadSession("evo_coffre_div")
	end

	if STATE.view == "hist" then
		local tLog = STATE.log or {}
		if #tLog == 0 then
			local empty = grid:Add("DLabel")
			empty:Dock(TOP)
			empty:SetTall(gRespY(110))
			empty:SetFont("Bebas Neue:26")
			empty:SetTextColor(col.dim)
			empty:SetContentAlignment(5)
			empty:SetText("Aucun dépôt ni retrait pour l'instant.")
			BuildDetail()
			return
		end
		for _, e in ipairs(tLog) do
			local bDon = e.k == "don"
			local kc = bDon and (col.green or col.title) or col.accent
			local sItem = itemName(e.i)
			local q = rowQty(e)
			local sTitle = bDon and "DÉPÔT" or "RETRAIT"
			if q > 1 then sTitle = sTitle .. "  ×" .. q end
			local sSub = logWho(e) .. "  ·  " .. logWhen(e)
			if e.v == 10 then sSub = sSub .. "  ·  secret" end
			local row = grid:Add("DButton")
			row:Dock(TOP)
			row:DockMargin(gRespX(6), 0, gRespX(8), gRespY(8))
			row:SetTall(gRespY(72))
			row:SetText("")
			row:NoClipping(true)
			row.Paint = function(s, w, h)
				local gx, gy, gw, gh = EVO_UI.HoverPlate(s, w, h, { cut = gRespY(8), growPx = 2, offPx = 2, screws = false })
				surface.SetDrawColor(kc.r, kc.g, kc.b, 235)
				surface.DrawRect(gx, gy, gRespX(4), gh)
				if STATE.sel == e then
					surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 235)
					surface.DrawOutlinedRect(gx, gy, gw, gh, 2)
				end
				draw.SimpleText(sTitle, "Bebas Neue:26", gx + gRespX(18), gy + gRespY(20), kc, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(EVO_UI.TruncText(sItem, "Bebas Neue:22", gw - gRespX(28)), "Bebas Neue:22",
					gx + gRespX(18), gy + gh - gRespY(20), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(sSub, "Bebas Neue:20", gx + gw - gRespX(14), gy + gh / 2, col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function()
				surface.PlaySound(EVO_UI.SndClick)
				STATE.sel = e
				BuildDetail()
			end
		end
		BuildDetail()
		return
	end

	local tShown = (STATE.view == "don") and BagRows() or CoffreRows()
	local tFolders = {}
	if STATE.view == "coffre" and nFolder == 0 then
		tFolders = VaultFolders()
	end

	if STATE.view == "coffre" and bInFolder then
		local back = grid:Add("DButton")
		back:Dock(TOP)
		back:DockMargin(gRespX(6), gRespY(4), gRespX(8), gRespY(14))
		back:SetTall(gRespY(44))
		back:SetText("")
		back.Paint = function(s, w, h)
			local gx, gy, gw, gh = EVO_UI.HoverPlate(s, w, h, { cut = gRespY(8), growPx = 2, offPx = 2, screws = false })
			if STATE.canManage and dragndrop.IsDragging() and s:IsHovered() then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 90)
				surface.DrawRect(gx, gy, gw, gh)
			end
			draw.SimpleText("←  " .. string.upper(FolderNameOf(nFolder)), "Bebas Neue:26",
				gx + gRespX(16), gy + gh / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		back.DoClick = function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.folderId = 0
			STATE.sel = nil
			BuildGrid()
		end
		if STATE.canManage then
			back:Receiver(DROP_NAME, function(_, panels, bDoDrop)
				if not bDoDrop then return end
				local dragged = panels and panels[1]
				local nId = IsValid(dragged) and tonumber(dragged._coffreRowId) or 0
				if nId < 1 then return end
				surface.PlaySound(EVO_UI.SndClick)
				netFolderMove(nId, 0)
				STATE.sel = nil
			end)
		end
	end

	if #tShown == 0 and #tFolders == 0 then
		local lbl = grid:Add("DLabel")
		lbl:Dock(TOP)
		lbl:SetTall(gRespY(110))
		lbl:SetFont("Bebas Neue:26")
		lbl:SetTextColor(col.dim)
		lbl:SetContentAlignment(5)
		lbl:SetText(STATE.view == "don"
			and "Aucun objet déposable dans ton sac (les objets boutique et personnels sont exclus)."
			or bInFolder and "Ce dossier est vide. Dépose un objet !"
			or "Rien dans ce rayon pour le moment. Dépose un objet !")
		BuildDetail()
		return
	end

	local cell, gap = gRespY(118), gRespY(10)
	local cols = math.max(1, math.floor((grid:GetWide() - gRespX(20)) / (cell + gap)))
	local rowPnl, inRow = nil, 0

	local function placeTile(paintFn, clickFn)
		if not rowPnl or inRow >= cols then
			rowPnl = grid:Add("DPanel")
			rowPnl:Dock(TOP)
			rowPnl:DockMargin(gRespX(6), 0, 0, gap)
			rowPnl:SetTall(cell)
			rowPnl:SetPaintBackground(false)
			inRow = 0
		end
		local tile = vgui.Create("DButton", rowPnl)
		tile:Dock(LEFT)
		tile:DockMargin(0, 0, gap, 0)
		tile:SetWide(cell)
		tile:SetText("")
		tile:NoClipping(true)
		tile.Paint = paintFn
		tile.DoClick = clickFn
		inRow = inRow + 1
		return tile
	end

	for _, f in ipairs(tFolders) do
		local nCnt = FolderItemCount(f.id)
		local tile = placeTile(function(s, w, h)
			local gx, gy, gw, gh = EVO_UI.HoverPlate(s, w, h, { cut = gRespY(10), growPx = 4, offPx = 3, screws = false })
			if STATE.canManage and dragndrop.IsDragging() and s:IsHovered() then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 70)
				surface.DrawRect(gx, gy, gw, gh)
			end
			surface.SetDrawColor(col.muted.r, col.muted.g, col.muted.b, 180)
			surface.DrawRect(gx, gy + gh - gRespY(3), gw, gRespY(3))
			if STATE.sel and STATE.sel._folder and STATE.sel.id == f.id then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 235)
				surface.DrawOutlinedRect(gx, gy, gw, gh, 2)
			end
			draw.SimpleText("DOSSIER", "Bebas Neue:18", gx + gw / 2, gy + gRespY(22),
				col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(EVO_UI.TruncText(f.name or "Dossier", "Bebas Neue:22", gw - gRespX(8)), "Bebas Neue:22",
				gx + gw / 2, gy + gh / 2, col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(nCnt .. (nCnt > 1 and " objets" or " objet"), "Bebas Neue:18",
				gx + gw / 2, gy + gh - gRespY(18), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end, function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.sel = { _folder = true, id = f.id, name = f.name, v = f.v }
			BuildDetail()
		end)
		tile.DoDoubleClick = function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.folderId = f.id
			STATE.sel = nil
			BuildGrid()
		end
		if STATE.canManage then
			tile._coffreFolderId = f.id
			tile:Receiver(DROP_NAME, function(_, panels, bDoDrop)
				if not bDoDrop then return end
				local dragged = panels and panels[1]
				local nId = IsValid(dragged) and tonumber(dragged._coffreRowId) or 0
				if nId < 1 then return end
				surface.PlaySound(EVO_UI.SndClick)
				netFolderMove(nId, f.id)
				STATE.sel = nil
			end)
		end
	end

	for _, r in ipairs(tShown) do
		local sID = r.i
		local rc = rarityCol(sID)
		local tile = placeTile(function(s, w, h)
			local gx, gy, gw, gh = EVO_UI.HoverPlate(s, w, h, { cut = gRespY(10), growPx = 4, offPx = 3, screws = false })
			surface.SetDrawColor(rc.r, rc.g, rc.b, 235)
			surface.DrawRect(gx, gy + gh - gRespY(3), gw, gRespY(3))
			if STATE.sel and ((STATE.sel.id and not STATE.sel._folder and STATE.sel.id == r.id) or (STATE.sel.slot and STATE.sel.slot == r.slot)) then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 235)
				surface.DrawOutlinedRect(gx, gy, gw, gh, 2)
			end
			draw.SimpleText(EVO_UI.TruncText(itemName(sID), "Bebas Neue:22", gw - gRespX(8)), "Bebas Neue:22",
				gx + gw / 2, gy + gh - gRespY(17), col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end, function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.sel = r
			BuildDetail()
		end)
		AttachIcon(tile, itemDef(sID), gRespY(14))
		local prevOver = tile.PaintOver
		tile.PaintOver = function(s, w, h)
			if prevOver then prevOver(s, w, h) end
			local q = rowQty(r)
			if q > 1 then
				draw.SimpleText("x" .. q, "Bebas Neue:22", w - gRespX(10), gRespY(8),
					col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			end
		end
		if STATE.view == "coffre" and STATE.canManage and r.id then
			tile._coffreRowId = r.id
			tile:Droppable(DROP_NAME)
		end
	end
	BuildDetail()
end

-- ============================================================================
-- CHIPS CATÉGORIES (vue COFFRE uniquement)
-- ============================================================================
local function BuildCats(parent)
	parent:Clear()
	local col = Col()
	for _, c in ipairs(CATS) do
		local b = vgui.Create("DButton", parent)
		b:Dock(LEFT)
		b:DockMargin(0, 0, gRespX(8), 0)
		b:SetWide(gRespX(108))
		b:SetText("")
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local bOn = STATE.cat == c.id
			local hf = EVO_UI.HoverFrac(s, 10)
			EVO_UI.PaintCut(0, 0, w, h, bOn and col.accent or Color(24, 26, 31, 235), gRespY(8), "br")
			if not bOn and hf > 0.02 then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 120 * hf)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			draw.SimpleText(c.label, "Bebas Neue:24", w / 2, h / 2,
				bOn and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.cat = c.id
			STATE.sel = nil
			STATE.folderId = 0
			BuildGrid()
		end
	end
end

-- ============================================================================
-- SOUS-ONGLETS RAYON / RAYON SECRET (vue COFFRE uniquement)
-- ============================================================================
local function BuildVaults(parent)
	parent:Clear()
	local col = Col()
	local tV = { { v = 3, label = "RAYON" } }
	-- Onglet CACHÉ : n'existe que si le serveur l'a dit (grade 10+).
	if STATE.secret then tV[#tV + 1] = { v = 10, label = "RAYON SECRET" } end
	for _, t in ipairs(tV) do
		local b = vgui.Create("DButton", parent)
		b:Dock(LEFT)
		b:DockMargin(0, 0, gRespX(8), 0)
		b:SetWide(gRespX(160))
		b:SetText("")
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local bOn = STATE.vault == t.v
			local hf = EVO_UI.HoverFrac(s, 10)
			EVO_UI.PaintCut(0, 0, w, h, bOn and col.accent or Color(24, 26, 31, 235), gRespY(8), "br")
			if not bOn and hf > 0.02 then
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 120 * hf)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
			draw.SimpleText(t.label, "Bebas Neue:28", w / 2, h / 2,
				bOn and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound(EVO_UI.SndClick)
			STATE.vault = t.v
			STATE.sel = nil
			STATE.folderId = 0
			BuildGrid()
		end
	end
end

-- ============================================================================
-- FENÊTRE PLEIN ÉCRAN
-- ============================================================================
local function MakeFrame()
	if IsValid(frame) then
		frame._evoSilentClose = true
		frame:Remove()
	end
	local col = Col()

	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end -- APRÈS MakePopup
	local oldOnRemove = frame.OnRemove
	frame.OnRemove = function(s, ...)
		if not s._evoSilentClose then netClose() end
		if oldOnRemove then oldOnRemove(s, ...) end
	end
	-- Fond plein écran : même recette que le menu Échap (blur + voile sombre).
	frame.Paint = function(s, w, h)
		EVO_UI.DrawBlur(s, 5)
		surface.SetDrawColor(5, 5, 7, 216)
		surface.DrawRect(0, 0, w, h)
	end

	-- Plaque centrale quasi plein écran (pas de filigrane kanji, retour user).
	local card = vgui.Create("DPanel", frame)
	local cw, chh = ScrW() - gRespX(90), ScrH() - gRespY(70)
	card:SetSize(cw, chh)
	card:SetPos((ScrW() - cw) / 2, (ScrH() - chh) / 2)
	card.Paint = function(_, w, h)
		EVO_UI.PaintCard(w, h, 1, nil, "none")
		DrawHeader(w, "COFFRE : " .. string.upper(STATE.div))
	end

	-- ✕ standard DA.
	local close = vgui.Create("DButton", card)
	close:SetText("")
	close:SetSize(gRespX(34), gRespY(34))
	close:SetPos(cw - gRespX(48), gRespY(14))
	close.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:30", w / 2, h / 2,
			s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Remove() end

	local sortW, sortH = gRespX(118), gRespY(34)
	local foldW = gRespX(150)
	local sortBtn = EVO_UI.ActionButton(card, cw - gRespX(48) - gRespX(12) - sortW, gRespY(14), sortW, sortH, "TRIER", nil, function()
		STATE.sorted = true
		netSort()
		BuildGrid()
	end)
	sortBtn._quietClick = true
	sortBtn._font = "Bebas Neue:22"
	frame._sort = sortBtn

	local newFold = EVO_UI.ActionButton(card,
		cw - gRespX(48) - gRespX(12) - sortW - gRespX(10) - foldW, gRespY(14),
		foldW, sortH, "NOUVEAU DOSSIER", Color(52, 56, 64), function()
			PromptFolderName("Nouveau dossier", "", function(txt)
				netFolderCreate(txt, STATE.vault)
			end)
		end)
	newFold._quietClick = true
	newFold._font = "Bebas Neue:20"
	frame._newFolder = newFold

	-- Sidebar : coffre / déposer / historique. Les rayons restent des
	-- sous-onglets du coffre. La banque ouvre une autre UI.
	local sideW = gRespX(280)
	local sideX, sideY = gRespX(20), gRespY(108)
	local rowH = gRespY(52)
	local tRows = {}
	local function Reselect()
		for id, b in pairs(tRows) do
			if IsValid(b) then b:SetSel(id == STATE.view) end
		end
	end

	tRows["coffre"] = EVO_UI.RowButton(card, sideX, sideY, sideW, rowH,
		{ num = "01", label = "COFFRE", font = "Bebas Neue:30", numFont = "Bebas Neue:24", numPad = 34 }, function()
			STATE.view = "coffre" STATE.sel = nil Reselect() BuildGrid()
		end)
	tRows["don"] = EVO_UI.RowButton(card, sideX, sideY + rowH, sideW, rowH,
		{ num = "02", label = "DÉPOSER", font = "Bebas Neue:30", numFont = "Bebas Neue:24", numPad = 34 }, function()
			STATE.view = "don" STATE.sel = nil Reselect() BuildGrid()
		end)
	tRows["hist"] = EVO_UI.RowButton(card, sideX, sideY + rowH * 2, sideW, rowH,
		{ num = "03", label = "HISTORIQUE", font = "Bebas Neue:30", numFont = "Bebas Neue:24", numPad = 34 }, function()
			STATE.view = "hist" STATE.sel = nil STATE.folderId = 0 Reselect() BuildGrid()
		end)
	-- L'autre porte d'entrée de la banque (trésorerie partagée, evo_division_bank).
	-- Libellé "BANQUE DE FACTION" (demande user 08/16 : c'est une banque de faction).
	tRows["banque"] = EVO_UI.RowButton(card, sideX, sideY + rowH * 3, sideW, rowH,
		{ num = "04", label = "BANQUE DE FACTION", font = "Bebas Neue:30", numFont = "Bebas Neue:24", numPad = 34 }, function()
			if EVO_DIVBANK and EVO_DIVBANK.Open then EVO_DIVBANK.Open() end
		end)

	-- Zone principale : sous-onglets rayons + chips catégories (vue coffre),
	-- grille, détail.
	local mainX = sideX + sideW + gRespX(18)
	local detailW = gRespX(300)
	local mainW = cw - mainX - detailW - gRespX(34)

	frame._gridX = mainX
	frame._topY  = gRespY(108)
	frame._catsY = gRespY(156)
	frame._gridY = gRespY(198)
	frame._gridH = chh - gRespY(216)

	local vaults = vgui.Create("DPanel", card)
	vaults:SetPos(mainX, frame._topY)
	vaults:SetSize(mainW, gRespY(40))
	vaults:SetPaintBackground(false)
	BuildVaults(vaults)
	frame._vaults = vaults

	local cats = vgui.Create("DPanel", card)
	cats:SetPos(mainX, frame._catsY)
	cats:SetSize(mainW, gRespY(36))
	cats:SetPaintBackground(false)
	BuildCats(cats)
	frame._cats = cats

	local grid = vgui.Create("DScrollPanel", card)
	grid:SetPos(mainX, frame._gridY)
	grid:SetSize(mainW, frame._gridH)
	grid.Paint = nil
	frame._grid = grid

	local detail = vgui.Create("DPanel", card)
	detail:SetPos(mainX + mainW + gRespX(14), frame._topY)
	detail:SetSize(detailW, chh - gRespY(126))
	detail.Paint = function(_, w, h)
		EVO_UI.PaintCut(0, 0, w, h, Color(16, 17, 21, 240), gRespY(12))
	end
	frame._detail = detail

	Reselect()
	timer.Simple(0, BuildGrid)
end

-- ============================================================================
-- NET
-- ============================================================================
local function ReadSnap()
	local n = net.ReadUInt(24)
	local raw = util.Decompress(net.ReadData(n))
	local t = raw and util.JSONToTable(raw)
	if not istable(t) then return false end
	STATE.div = tostring(t.div or "")
	STATE.secret = t.secret == true
	STATE.rows = istable(t.rows) and t.rows or {}
	STATE.folders = istable(t.folders) and t.folders or {}
	STATE.log = istable(t.log) and t.log or {}
	STATE.canManage = true
	if STATE.vault == 10 and not STATE.secret then STATE.vault = 3 end
	-- Dossier courant disparu (supprimé) → retour racine.
	if (tonumber(STATE.folderId) or 0) > 0 then
		local bOk = false
		for _, f in ipairs(STATE.folders) do
			if f.id == STATE.folderId and (tonumber(f.v) or 3) == STATE.vault then
				bOk = true
				break
			end
		end
		if not bOk then STATE.folderId = 0 end
	end
	if STATE.sel and STATE.sel._folder then
		local found
		for _, f in ipairs(STATE.folders) do
			if f.id == STATE.sel.id then
				found = { _folder = true, id = f.id, name = f.name, v = f.v }
				break
			end
		end
		STATE.sel = found
	elseif STATE.sel and STATE.sel.id and not STATE.sel.slot then
		local found
		for _, r in ipairs(STATE.rows) do
			if r.id == STATE.sel.id then found = r break end
		end
		STATE.sel = found
	end
	return true
end

net.Receive("EVO:Craft:CoffreOpen", function()
	if not ReadSnap() then return end
	STATE.vault = 3
	STATE.cat = "all"
	STATE.view = "coffre"
	STATE.sel = nil
	STATE.sorted = false
	STATE.folderId = 0
	MakeFrame()
end)

net.Receive("EVO:Craft:CoffreSnap", function()
	if not ReadSnap() then return end
	if IsValid(frame) then BuildGrid() end
end)

-- Le sac vient de changer (don accepté, retrait livré) : rafraîchir la vue don.
hook.Add("LZY_Inventory_Synced", "EVO_CoffreDiv::RefreshDon", function()
	if IsValid(frame) and STATE.view == "don" then BuildGrid() end
end)
