-- "addons\\evo_craft\\lua\\evo_craft\\sh_lunettes.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- LUNETTES D'ANALYSE (10/12, user : « comme le scouter de DBZ ») : accessoire de tête qui
-- affiche PV, reiatsu et art spirituel de la personne regardée. S'use (port, analyses, coups
-- reçus), se brise à 0 % et ne se répare PAS : on en fabrique de nouvelles au LABO scientifique
-- (recette « lunettes_analyse » de HUB.PotionRecipes, evo_science). Serveur : sv_lunettes, client : cl_lunettes.
EVO_LUNETTES = EVO_LUNETTES or {}
local L = EVO_LUNETTES

L.ID     = "lunettes_analyse"
L.Modele = "models/evo/accessories/head/lar_gotei13/lar_gotei13.mdl"
L.Portee = 2500          -- u : au-delà, aucune analyse
L.Intervalle = 0.5       -- s entre deux demandes du client (revalidé serveur)
-- Usure en % de durabilité, divisée par 10 pour toutes les sources.
L.UsurePortParMin  = 100 / 6000 -- 100 h portées
L.UsureNouvelleCible = 0.03    -- verrouiller une NOUVELLE personne
L.UsureSuivi       = 0.001     -- chaque rafraîchissement sur la même (≈ 0,12 % par minute)
L.UsureCoupFacteur = 1.2       -- coup reçu : dégâts / PV max × facteur...
L.UsureCoupMin, L.UsureCoupMax = 0.02, 0.4 -- ...borné à cet intervalle

local function enregistrer()
	if not istable(ITEMS) then return false end
	if ITEMS[L.ID] then return true end
	ITEMS[L.ID] = {
		name = "Lunettes d'analyse",
		description = "Lunettes d'analyse spirituelle du Gotei 13. Portées, elles affichent les PV, le reiatsu "
			.. "et l'art spirituel de la personne que tu regardes. Elles s'usent avec le temps, à chaque analyse "
			.. "et surtout sous les coups : à 0 % elles se brisent et disparaissent. La forge ne les répare pas, il faut en "
			.. "fabriquer de nouvelles au laboratoire scientifique.",
		icon = "zw7x2d061ill/6assh2s06ssp2u7n/tqybajmit5ywxc4lz.png",
		category = "accessory",
		slot = "head",
		rarity = "epic",
		model_path = L.Modele,
		has_durability = true,
		durability_drain_per_min = L.UsurePortParMin,
		no_repair = true, -- lu par ncm_forge : jamais réparable
		destroy_on_break = true, -- suppression de l'exemplaire équipé à 0 %
		bAnalysisGlasses = true, -- équipement technique autorisé à circuler
		is_droppable = true,
		is_deletable = true,
	}
	return true
end

EVO_CRAFT.Retry("EVO_Craft::Lunettes", enregistrer,
	"[evo_craft] ITEMS indisponible apres 30 essais : lunettes d'analyse non enregistrees.")
