-- "addons\\evo_craft\\lua\\entities\\evo_piege_pics.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Piège à pics des assassins (evo_craft). Posé pics RENTRÉS (discret) : au
-- passage, les pics sortent (dégâts + saignement + ralentissement), rentrent,
-- et le piège se réarme. 3 déclenchements puis il casse. Récupérable au [E]
-- par le poseur entre deux morsures. Séquences : idle_closed / open / idle_open
-- / close.
-- Équilibrage (AssassinCfg.Pics) + helpers partagés : sh_craft_assassin_gear.

AddCSLuaFile()

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Piège à pics"
ENT.Author    = "EVO"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Thrower")
	self:NetworkVar("Bool", 0, "Out") -- pics sortis (verrouille le [E])
end

-- Client : rien de spécial, le MODÈLE seul (cercle du poseur retiré, demande
-- user 08/18 ; la preview de pose vit dans cl_assassin_gear).
if CLIENT then return end

local MDL = "models/evo/props/items/evo_zder3gzed54edezfer/evo_zder3gzed54edezfer.mdl"
local RETRACT_AFTER = 1.6 -- s pics sortis avant la rétraction

function ENT:Initialize()
	local CFG = EVO_CRAFT.AssassinCfg
	self:SetModel(MDL)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_BBOX)
	self:SetCollisionBounds(Vector(-16, -16, 0), Vector(16, 16, 6))
	self:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR)
	self:SetUseType(SIMPLE_USE)

	EVO_CRAFT.AssassinPlaySeq(self, "idle_closed")
	self.nArmedAt  = CurTime() + CFG.TrapArmDelay
	self.nExpireAt = CurTime() + CFG.TrapLifetime
	self.nCharges  = CFG.Pics.charges
	self.tRecent   = {} -- victime -> immunité (pas de re-morsure instantanée)
	self:NextThink(CurTime() + 0.2)
end

function ENT:Think()
	if self:GetOut() then return end
	if CurTime() > self.nExpireAt then
		self:EmitSound("ambient/machines/steam_release_1.wav", 55, 140)
		self:Remove()
		return
	end
	if CurTime() >= self.nArmedAt then
		for _, v in ipairs(ents.FindInSphere(self:GetPos(), EVO_CRAFT.AssassinCfg.Pics.radius)) do
			if EVO_CRAFT.AssassinCanTrigger(self, v) then
				self:Spring(v)
				break
			end
		end
	end
	self:NextThink(CurTime() + 0.2)
	return true
end

function ENT:Spring(victim)
	local T = EVO_CRAFT.AssassinCfg.Pics
	self:SetOut(true)
	self.tRecent[victim] = CurTime() + 3
	EVO_CRAFT.AssassinPlaySeq(self, "open")
	self:EmitSound("physics/metal/sawblade_stick1.wav", 74, math.random(96, 108))

	local owner = self:GetThrower()
	EVO_CRAFT.AssassinHurt(owner, self, victim, T.dmg, 910)
	if victim.TempScaleSpeed then victim:TempScaleSpeed(T.slowDur, T.slowScale) end

	-- Saignement : ticks différés, ApplySpellDamage re-filtre à chaque tick.
	local sBleed = "EvoPics_" .. self:EntIndex() .. "_" .. victim:EntIndex()
	timer.Create(sBleed, T.bleedEvery, T.bleedTicks, function()
		if not IsValid(victim) then timer.Remove(sBleed) return end
		if victim:IsPlayer() and not victim:Alive() then timer.Remove(sBleed) return end
		EVO_CRAFT.AssassinHurt(owner, IsValid(self) and self or nil, victim, T.bleedDmg, 911)
	end)

	-- Rétraction puis réarmement, ou casse à la dernière charge.
	self.nCharges = self.nCharges - 1
	timer.Simple(RETRACT_AFTER, function()
		if not IsValid(self) then return end
		if self.nCharges <= 0 then
			self:EmitSound("physics/metal/metal_box_break2.wav", 65, 110)
			self:Remove()
			return
		end
		local d = EVO_CRAFT.AssassinPlaySeq(self, "close")
		timer.Simple(math.max(d, 0.05), function()
			if IsValid(self) then EVO_CRAFT.AssassinPlaySeq(self, "idle_closed") end
		end)
		timer.Simple(math.max(T.rearm - RETRACT_AFTER, 0.1), function()
			if IsValid(self) then self:SetOut(false) self:NextThink(CurTime() + 0.2) end
		end)
	end)
end

function ENT:Use(activator)
	if self:GetOut() then return end
	EVO_CRAFT.AssassinTrapPickup(self, activator, "assassin_piege_pics")
end
