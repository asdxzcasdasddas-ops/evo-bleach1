-- "addons\\evo_craft\\lua\\entities\\evo_piege_ours.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Piège à ours des assassins (evo_craft). Posé au sol, s'ouvre après un court
-- armement, se referme sur le premier passant valide : dégâts + immobilisation
-- (EvoFreeze, comme le stagger de parade). Un seul déclenchement. Le poseur le
-- récupère au [E] tant qu'il n'a pas mordu. Séquences du modèle : open / close /
-- idle_open / idle_closed.
-- Équilibrage (AssassinCfg.Ours) + helpers partagés : sh_craft_assassin_gear.

AddCSLuaFile()

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Piège à ours"
ENT.Author    = "EVO"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Thrower")
	self:NetworkVar("Bool", 0, "Sprung")
end

-- Client : rien de spécial, le MODÈLE seul (cercle du poseur retiré, demande
-- user 08/18 ; la preview de pose vit dans cl_assassin_gear).
if CLIENT then return end

local MDL = "models/evo/props/items/evo_zefrqfer3grefrzedr/evo_zefrqfer3grefrzedr.mdl"
local REMOVE_LATE = 8 -- s entre la morsure et la disparition du piège fermé

function ENT:Initialize()
	local CFG = EVO_CRAFT.AssassinCfg
	self:SetModel(MDL)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_BBOX)
	self:SetCollisionBounds(Vector(-14, -14, 0), Vector(14, 14, 8))
	self:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR) -- traversable mais visable au [E] (recette coffre)
	self:SetUseType(SIMPLE_USE)

	EVO_CRAFT.AssassinPlaySeq(self, "idle_closed")
	self.nArmedAt  = CurTime() + CFG.TrapArmDelay
	self.nExpireAt = CurTime() + CFG.TrapLifetime
	timer.Simple(CFG.TrapArmDelay, function()
		if not (IsValid(self) and not self:GetSprung()) then return end
		local d = EVO_CRAFT.AssassinPlaySeq(self, "open")
		self:EmitSound("physics/metal/metal_grate_impact_soft3.wav", 60, 130)
		timer.Simple(math.max(d, 0.05), function()
			if IsValid(self) and not self:GetSprung() then EVO_CRAFT.AssassinPlaySeq(self, "idle_open") end
		end)
	end)
	self:NextThink(CurTime() + 0.2)
end

function ENT:Think()
	if self:GetSprung() then return end
	if CurTime() > self.nExpireAt then
		self:EmitSound("ambient/machines/steam_release_1.wav", 55, 140)
		self:Remove()
		return
	end
	if CurTime() >= self.nArmedAt then
		for _, v in ipairs(ents.FindInSphere(self:GetPos(), EVO_CRAFT.AssassinCfg.Ours.radius)) do
			if EVO_CRAFT.AssassinCanTrigger(self, v) then
				self:Spring(v)
				break
			end
		end
	end
	self:NextThink(CurTime() + 0.2)
	return true
end

function ENT:Spring(victim)
	local T = EVO_CRAFT.AssassinCfg.Ours
	self:SetSprung(true)
	EVO_CRAFT.AssassinPlaySeq(self, "close")
	self:EmitSound("physics/metal/metal_barrel_impact_hard2.wav", 78, 120)
	self:EmitSound("npc/barnacle/neck_snap1.wav", 72, 105)

	local owner = self:GetThrower()
	EVO_CRAFT.AssassinHurt(owner, self, victim, T.dmg, 910)
	-- Root type stagger de parade ; attacker transmis pour le gate d'instance.
	if victim.EvoFreeze then
		victim:EvoFreeze({ duration = T.rootSec, killVelocity = true, attacker = IsValid(owner) and owner or nil })
	end

	timer.Simple(REMOVE_LATE, function()
		if IsValid(self) then self:Remove() end
	end)
end

function ENT:Use(activator)
	if self:GetSprung() then return end
	EVO_CRAFT.AssassinTrapPickup(self, activator, "assassin_piege_ours")
end
