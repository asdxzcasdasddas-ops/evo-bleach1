-- "addons\\evo_craft\\lua\\entities\\evo_coffre_division\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Coffre de division"
ENT.Author    = "EVO"
ENT.Spawnable = false

function ENT:SetupDataTables()
	-- Nom EXACT de la division propriétaire ("Division 11", "Ordre 4", ...),
	-- posé au spawn serveur, lu par le nametag client.
	self:NetworkVar("String", 0, "DivisionName")
	-- Libellé du nametag quand le coffre a une identité propre (ex. « Frigo du
	-- laboratoire », evo_science) ; vide = « Coffre : <division> » par défaut.
	self:NetworkVar("String", 1, "LabelOverride")
end
