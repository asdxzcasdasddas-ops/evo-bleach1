-- "addons\\evo_craft\\lua\\entities\\evo_grenade_assassin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Grenade artisanale des assassins (evo_craft, rayon assassin). Une seule
-- classe : le comportement suit GType (bombe / toxique / fumigene / glace /
-- feu / magique). Physique SPHÈRE (indépendante du modèle), DÉTONATION AU
-- PREMIER IMPACT (demande user 08/18, la mèche ne sert que de filet), zones
-- gérées par la même entité rendue invisible (l'inflictor des ticks reste
-- valide). Équilibrage + helpers : sh_craft_assassin_gear.

AddCSLuaFile()

ENT.Type      = "anim"
ENT.Base      = "base_gmodentity"
ENT.PrintName = "Grenade artisanale"
ENT.Author    = "EVO"
ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "GType")
	self:NetworkVar("Entity", 0, "Thrower")
end

if CLIENT then return end

local MDL_BOMBE = "models/evo/props/items/evo_zeff55354qerfedzgrt/evo_zeff55354qerfedzgrt.mdl"
local MDL_GREN  = "models/evo/props/items/evo_sg3rgqerfhddzk526t/evo_sg3rgqerfhddzk526t.mdl"
local SKINS = { toxique = 0, fumigene = 1, magique = 2, glace = 3, feu = 4 }

local SMOKE_PART    = "[0]_anger_explousion_add_11_instant" -- fumée du Bakudō 3 Sekienton
local SND_SEKIENTON = "a4xy732ex6yeop2/1q9kcah77kmxhhyw.wav"
-- Prop de glace du Voile de neige (Hitsugaya Spell 4) : séquences idle / glace_pop.
local MDL_GLACE = "models/evo/props/props_anim/evo_8xtcqjdupm1zo63u8/evo_71i152ggs1nt.mdl"

function ENT:Initialize()
	local sType = self:GetGType()
	self:SetModel(sType == "bombe" and MDL_BOMBE or MDL_GREN)
	self:SetSkin(SKINS[sType] or 0)
	self:PhysicsInitSphere(5)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE_DEBRIS) -- jamais de push de joueur
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
		phys:SetMass(3)
		-- Pas de traînée d'air : la trajectoire colle à l'arc PRÉDIT par la
		-- preview de visée client (gravité pure, mêmes constantes).
		phys:EnableDrag(false)
	end
	-- La mèche n'est qu'un FILET (jet vers le vide, coincée) : le vrai
	-- déclencheur est le premier impact (PhysicsCollide).
	timer.Simple(math.max(EVO_CRAFT.AssassinCfg.GrenadeFuse, 3), function()
		if IsValid(self) then self:Detonate() end
	end)
	timer.Simple(30, function()
		if IsValid(self) then self:Remove() end
	end)
end

-- Détonation à l'IMPACT (sol, mur, prop). Jamais de Remove dans le callback
-- physique : on diffère d'un tick.
function ENT:PhysicsCollide(data)
	if self.bDone or self.bImpact then return end
	self.bImpact = true
	timer.Simple(0, function()
		if IsValid(self) then self:Detonate() end
	end)
end

-- La zone réutilise l'entité : invisible, figée, elle porte les timers de tick
-- puis se retire. tickFn(pos) est appelé toutes les nInterval secondes.
function ENT:BecomeZone(nDuration, nInterval, tickFn)
	self:SetNoDraw(true)
	self:SetSolid(SOLID_NONE)
	self:SetMoveType(MOVETYPE_NONE)
	local vPos = self:GetPos()
	local sTimer = "EvoGrenZone_" .. self:EntIndex()
	timer.Create(sTimer, nInterval, math.floor(nDuration / nInterval), function()
		if not IsValid(self) then timer.Remove(sTimer) return end
		tickFn(vPos)
	end)
	timer.Simple(nDuration + 0.2, function()
		if IsValid(self) then self:Remove() end
	end)
end

function ENT:OnRemove()
	timer.Remove("EvoGrenZone_" .. self:EntIndex())
end

-- Props de glace du Voile de neige : posés dans la zone, séquence glace_pop
-- puis suppression à la fin (copie du Spell 4 Hitsugaya, snap sol systématique).
local function spawnIceProps(vCenter, nRadius, nCount, nDuration)
	for _ = 1, nCount do
		local nAng = math.random() * 360
		local nDist = math.random() * nRadius * 0.85
		local vPos = vCenter + Vector(math.cos(math.rad(nAng)) * nDist, math.sin(math.rad(nAng)) * nDist, 0)
		local tr = util.TraceLine({
			start = vPos + Vector(0, 0, 50),
			endpos = vPos - Vector(0, 0, 500),
			mask = MASK_SOLID_BRUSHONLY,
		})
		if tr.Hit then vPos = tr.HitPos end

		local eProp = ents.Create("base_anim")
		if IsValid(eProp) then
			eProp:SetModel(MDL_GLACE)
			eProp:SetPos(vPos)
			eProp:SetAngles(Angle(0, math.random(0, 360), 0))
			eProp:SetSolid(SOLID_NONE)
			eProp:SetMoveType(MOVETYPE_NONE)
			eProp:Spawn()
			eProp:Activate()
			local nIdle = eProp:LookupSequence("idle")
			if nIdle and nIdle >= 0 then eProp:ResetSequence(nIdle) end
			timer.Simple(nDuration - 1, function()
				if not IsValid(eProp) then return end
				local nPop = eProp:LookupSequence("glace_pop")
				if nPop and nPop >= 0 then eProp:ResetSequence(nPop) end
				SafeRemoveEntityDelayed(eProp, 1)
			end)
		end
	end
end

local BEHAVIOR = {}

-- Fumigène : la fumée du Sekienton, SANS ses ticks de dégâts (demande user).
BEHAVIOR.fumigene = function(self, owner, pos, T)
	self:EmitSound(SND_SEKIENTON, 78, 100)
	for _ = 1, T.clouds do
		local v = pos + Vector(math.Rand(-T.spread, T.spread), math.Rand(-T.spread, T.spread), math.Rand(-6, 14))
		EVO_CRAFT.AssassinFx(self, SMOKE_PART, v, T.dur)
	end
	self:Remove()
end

BEHAVIOR.bombe = function(self, owner, pos, T)
	self:EmitSound("ambient/explosions/explode_4.wav", 92, math.random(96, 104))
	EVO_CRAFT.AssassinFx(self, "[8]_little_exp_red", pos, 3)
	util.ScreenShake(pos, 9, 45, 0.8, T.radius + 160)
	for _, v in ipairs(EVO_CRAFT.AssassinVictims(owner, pos, T.radius)) do
		local f = math.Clamp(v:WorldSpaceCenter():Distance(pos) / T.radius, 0, 1)
		EVO_CRAFT.AssassinHurt(owner, self, v, math.Round(Lerp(f, T.dmgMax, T.dmgMin)), 910)
	end
	self:Remove()
end

BEHAVIOR.toxique = function(self, owner, pos, T)
	self:EmitSound("ambient/levels/canals/toxic_slime_gurgle3.wav", 72, 90)
	EVO_CRAFT.AssassinFx(self, "[4]_dash_brolly_slash_add_2", pos, T.dur + 1)
	self:BecomeZone(T.dur, T.tick, function(vPos)
		for _, v in ipairs(EVO_CRAFT.AssassinVictims(owner, vPos, T.radius)) do
			EVO_CRAFT.AssassinHurt(owner, self, v, T.dmg, 911)
			-- Aura verte ATTACHÉE au corps de la victime (demande user 08/18),
			-- rafraîchie par tick : elle s'éteint en sortant du nuage.
			if v.StartParticule then
				v:StartParticule("[0]aura_vert", v:GetPos(), v:GetAngles(), true, T.tick + 0.2, {}, false) -- netgate: stream
			end
		end
	end)
end

-- Glace : mini VOILE DE NEIGE au point d'impact (recette Hitsugaya Spell 4) :
-- même particule de zone, mêmes props de glace, brouillard givré + slow + ticks.
BEHAVIOR.glace = function(self, owner, pos, T)
	self:EmitSound("physics/glass/glass_sheet_break1.wav", 80, math.random(88, 96))
	EVO_CRAFT.AssassinFx(self, "[8]_snow_veil", pos, T.dur)
	spawnIceProps(pos, T.radius, T.props or 3, T.dur)
	self:BecomeZone(T.dur, T.tick, function(vPos)
		for _, v in ipairs(EVO_CRAFT.AssassinVictims(owner, vPos, T.radius)) do
			EVO_CRAFT.AssassinHurt(owner, self, v, T.dmg, 911)
			if v.TempScaleSpeed then v:TempScaleSpeed(T.tick + 0.2, T.slowScale) end
			if v:IsPlayer() and v.SnowVeilBlur then v:SnowVeilBlur(T.tick + 0.4) end -- netgate: stream
			if v.StartParticule then
				v:StartParticule("[8]_ice_effect", v:GetPos(), v:GetAngles(), true, T.tick + 0.2, {}, false) -- netgate: stream
			end
		end
	end)
end

-- Feu : la nappe EMBRASE quiconque la traverse avec la CALCINATION de l'art
-- spirituel Yamamoto (même DoT, même aura de flammes, même icône de statut).
BEHAVIOR.feu = function(self, owner, pos, T)
	self:EmitSound("ambient/fire/gascan_ignite1.wav", 82, math.random(94, 102))
	EVO_CRAFT.AssassinFx(self, "[20]_guren_kekkai_add_1", pos, T.dur)
	self:BecomeZone(T.dur, T.tick, function(vPos)
		for _, v in ipairs(EVO_CRAFT.AssassinVictims(owner, vPos, T.radius)) do
			if EvoStyle and EvoStyle.ApplyCalcination and IsValid(owner) then
				-- Valeurs PROPRES (celles d'avant le buff Yamamoto du 10/02), sans anti soin.
				EvoStyle.ApplyCalcination(owner, v, { nPerTick = 5, nDuration = 4, nTickRate = 0.5, bAntiHeal = false }) -- netgate: stream
			else
				-- Repli sans spell system : petits ticks + la MÊME aura de
				-- flammes que la calcination (jamais le feu moteur, autre rendu).
				EVO_CRAFT.AssassinHurt(owner, self, v, T.dmg, 911)
				if v.StartParticule then
					v:StartParticule("[14]_shiba_aura_flamme_add_2", v:GetPos(), v:GetAngles(), true, T.igniteSec, {}, false) -- netgate: stream
				elseif v.Ignite then
					v:Ignite(T.igniteSec, 0)
				end
			end
		end
	end)
end

-- Spirituelle : éclair de reiryoku aveuglant. Flash plein si la victime REGARDE
-- l'éclair avec ligne de vue, flash court sinon. Aucun dégât.
BEHAVIOR.magique = function(self, owner, pos, T)
	self:EmitSound("ambient/energy/weld2.wav", 85, 135)
	EVO_CRAFT.AssassinFx(self, "[0]_anger_explousion_add_7_instant", pos, 2.5)
	for _, v in ipairs(EVO_CRAFT.AssassinVictims(owner, pos, T.radius)) do
		if v:IsPlayer() then
			local tr = util.TraceLine({ start = pos, endpos = v:EyePos(), mask = MASK_OPAQUE })
			if tr.Fraction >= 0.98 or tr.Entity == v then
				local nDot = v:GetAimVector():Dot((pos - v:EyePos()):GetNormalized())
				v:ScreenFade(SCREENFADE.IN, Color(245, 235, 255), 0.35, nDot > 0.2 and T.fullSec or T.grazeSec)
			end
		end
	end
	self:Remove()
end

-- Clé de tuning EVO_CRAFT.AssassinCfg par gtype.
local TUNE = { bombe = "Bombe", toxique = "Toxique", fumigene = "Fumigene",
	glace = "Glace", feu = "Feu", magique = "Magique" }

function ENT:Detonate()
	if self.bDone then return end
	self.bDone = true
	local sType = self:GetGType()
	local fn = BEHAVIOR[sType]
	local T = EVO_CRAFT.AssassinCfg[TUNE[sType] or ""]
	if not (fn and T) then self:Remove() return end
	fn(self, self:GetThrower(), self:GetPos() + Vector(0, 0, 6), T)
end
