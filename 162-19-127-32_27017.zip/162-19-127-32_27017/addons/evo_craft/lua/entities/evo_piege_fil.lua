-- "addons\\evo_craft\\lua\\entities\\evo_piege_fil.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Piège à FIL des assassins (evo_craft, user 08/19). Posé en DEUX piquets
-- (sv_craft_assassin valide la longueur Fil.maxLen), un fil presque invisible
-- tendu entre les deux. AUCUN dégât : quiconque touche le fil est RÉVÉLÉ
-- Fil.revealSec s au POSEUR à travers tout (surbrillance EVO::WallHackEffect,
-- le même canal que la Target Mark de Soifon). Un seul déclenchement, le fil
-- se rompt. Le poseur récupère le piège au [E] sur le PREMIER piquet tant
-- qu'il n'a pas été déclenché. Équilibrage : AssassinCfg.Fil.
-- ⚠ ENTITÉ NOUVELLE = restart serveur, pas un simple refresh.

AddCSLuaFile()

ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Piège à fil"
ENT.Author    = "EVO"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_BOTH -- modèle opaque + fil translucide

local MDL = "models/evo/props/items/evo_zed36gzedrefpmolikujyhg/evo_zed36gzedREFPMolikujyhg.mdl"

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Thrower")
	self:NetworkVar("Vector", 0, "PointB")
	self:NetworkVar("Bool", 0, "Sprung")
	-- gtype de la grenade montée ("" = aucune). Réseaué pour que le POSEUR voie
	-- son fil armé ; la clé d'ITEM, elle, reste serveur (sGrenadeKey).
	self:NetworkVar("String", 0, "GrenadeType")
end

if CLIENT then
	-- Le piquet B et le fil sont dessinés PAR l'entité (un seul objet réseau).
	function ENT:OnRemove()
		if IsValid(self._mB) then self._mB:Remove() end
	end

	function ENT:Draw()
		self:DrawModel()
		local vB = self:GetPointB()
		if vB:IsZero() then return end
		if not IsValid(self._mB) then
			self._mB = ClientsideModel(MDL, RENDERGROUP_OPAQUE)
			if IsValid(self._mB) then
				self._mB:SetPos(vB)
				self._mB:SetAngles(Angle(0, (self:GetPos() - vB):Angle().yaw, 0))
			end
		end
		if IsValid(self._mB) then self._mB:DrawModel() end
	end

	function ENT:DrawTranslucent()
		if self:GetSprung() then return end
		local vB = self:GetPointB()
		if vB:IsZero() then return end
		local nH = (EVO_CRAFT.AssassinCfg.Fil and EVO_CRAFT.AssassinCfg.Fil.wireH) or 12
		-- Fil discret pour les victimes, net pour le poseur (c'est SON piège).
		local bMine = self:GetThrower() == LocalPlayer()
		local nA = bMine and 150 or 45
		-- Armé d'une grenade : teinte chaude pour LE POSEUR seulement. Une victime
		-- ne doit pas pouvoir lire au premier coup d'œil qu'un fil est piégé.
		local col = (bMine and self:GetGrenadeType() ~= "")
			and Color(255, 165, 60, nA) or Color(205, 210, 220, nA)
		render.SetColorMaterial()
		render.DrawBeam(self:GetPos() + Vector(0, 0, nH), vB + Vector(0, 0, nH),
			1.2, 0, 1, col)
	end
	return
end

-- ── Serveur ──────────────────────────────────────────────────────────────────
-- Le net de révélation appartient au combat system (Soifon/Zommari) ; on le
-- (re)déclare, l'appel est idempotent et evo_craft ne dépend pas de leur ordre.
util.AddNetworkString("EVO::WallHackEffect")

function ENT:Initialize()
	local CFG = EVO_CRAFT.AssassinCfg
	self:SetModel(MDL)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_BBOX)
	self:SetCollisionBounds(Vector(-8, -8, 0), Vector(8, 8, 18))
	self:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR) -- traversable mais visable au [E]
	self:SetUseType(SIMPLE_USE)

	self.nArmedAt  = CurTime() + CFG.TrapArmDelay
	self.nExpireAt = CurTime() + CFG.TrapLifetime
	self:NextThink(CurTime() + 0.2)
end

-- Franchissement du SEGMENT A-B : distance 2D au fil + bande verticale autour
-- de sa hauteur (interpolée entre les deux ancrages : un fil sur une pente
-- suit le sol). Sauter par-dessus l'évite, c'est voulu.
function ENT:CrossesWire(v)
	local T = EVO_CRAFT.AssassinCfg.Fil
	local vA, vB = self:GetPos(), self:GetPointB()
	local dx, dy = vB.x - vA.x, vB.y - vA.y
	local nLen2 = dx * dx + dy * dy
	if nLen2 <= 0 then return false end
	local p = v:GetPos()
	local t = math.Clamp(((p.x - vA.x) * dx + (p.y - vA.y) * dy) / nLen2, 0, 1)
	local cx, cy = vA.x + dx * t, vA.y + dy * t
	local ex, ey = p.x - cx, p.y - cy
	if ex * ex + ey * ey > (T.trigDist or 24) * (T.trigDist or 24) then return false end
	local wz = vA.z + (vB.z - vA.z) * t + (T.wireH or 12)
	return p.z > wz - 30 and p.z < wz + 44
end

function ENT:Think()
	if self:GetSprung() then return end
	if CurTime() > self.nExpireAt then
		self:EmitSound("ambient/machines/steam_release_1.wav", 55, 140)
		self:Remove()
		return
	end
	if CurTime() >= self.nArmedAt then
		local vA, vB = self:GetPos(), self:GetPointB()
		local vMid = (vA + vB) * 0.5
		local nR = vA:Distance(vB) * 0.5 + (EVO_CRAFT.AssassinCfg.Fil.trigDist or 24) + 40
		for _, v in ipairs(ents.FindInSphere(vMid, nR)) do
			if EVO_CRAFT.AssassinCanTrigger(self, v) and self:CrossesWire(v) then
				self:Spring(v)
				break
			end
		end
	end
	-- 0.1 s : un sprinteur ne doit pas enjamber le fil entre deux ticks.
	self:NextThink(CurTime() + 0.1)
	return true
end

function ENT:Spring(victim)
	local T = EVO_CRAFT.AssassinCfg.Fil
	self:SetSprung(true)
	self:EmitSound("physics/metal/metal_grate_impact_soft3.wav", 62, 150)

	local owner = self:GetThrower()
	-- Révélation : la MÊME surbrillance à travers tout que la Target Mark de
	-- Soifon, visible par le POSEUR seulement.
	if IsValid(owner) and owner:IsPlayer() and victim:IsPlayer() then
		-- Envoi ONE-SHOT : verrouillé par SetSprung, le Think ne repasse plus ici.
		-- netgate: edge
		net.Start("EVO::WallHackEffect")
			net.WriteEntity(victim)
			net.WriteFloat(T.revealSec or 5)
			net.WriteColor(Color(255, 200, 0))
		net.Send(owner)
		if owner.rpNotify then
			owner:rpNotify("Ton piège à fil s'est déclenché : la cible est révélée "
				.. (T.revealSec or 5) .. " secondes.", 0, 5)
		end
	end
	if victim:IsPlayer() and victim.rpNotify then
		victim:rpNotify("Un fil se rompt sur ton passage… tu te sens observé.", 1, 5)
	end

	-- GRENADE MONTÉE (user 08/22) : elle détone SUR la victime, pas sur le piquet
	-- — c'est elle qui a tiré le fil. Le poseur reste le Thrower : dégâts, camp et
	-- journalisation lui sont attribués comme s'il l'avait lancée.
	local sGren = self:GetGrenadeType()
	if sGren ~= "" then
		self.sGrenadeKey = nil -- consommée : plus rien à rendre au ramassage
		local gren = ents.Create("evo_grenade_assassin")
		if IsValid(gren) then
			gren:SetGType(sGren)
			gren:SetThrower(IsValid(owner) and owner or self)
			gren:SetPos(victim:WorldSpaceCenter())
			gren:Spawn()
			-- Différé d'un tick : Detonate part sur des particules et des timers,
			-- on ne le fait pas dans la même frame que le Spawn de l'entité.
			timer.Simple(0, function()
				if IsValid(gren) then gren:Detonate() end
			end)
		end
	end

	timer.Simple(1, function()
		if IsValid(self) then self:Remove() end
	end)
end

-- [E] n'est plus un ramassage sec (user 08/23) : il ouvre un MENU RADIAL où le
-- poseur choisit la grenade à monter, la retire, ou récupère le piège. Le
-- ramassage reste donc accessible, il est juste devenu une entrée du menu.
function ENT:Use(activator)
	if self:GetSprung() then return end
	if not (IsValid(activator) and activator:IsPlayer()) then return end
	if activator ~= self:GetThrower() then return end
	if (activator._evoFilRadialNext or 0) > CurTime() then return end
	activator._evoFilRadialNext = CurTime() + 0.4

	local tGren = EVO_CRAFT.AssassinGrenadesInBag(activator)
	net.Start("EVO_Craft:FilRadial")
		net.WriteEntity(self)
		net.WriteString(self:GetGrenadeType())
		net.WriteUInt(math.min(#tGren, 8), 4)
		for i = 1, math.min(#tGren, 8) do
			net.WriteString(tGren[i].key)
			net.WriteString(tGren[i].name)
		end
	net.Send(activator)
end
