-- "addons\\lzy_reroll\\lua\\lzy_reroll\\vgui\\main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local frame = nil
local can_open = true

-- Helper : joue un son UI a volume reduit (0.5 = -6dB).
-- surface.PlaySound ne supporte pas de parametre volume, donc on passe par
-- Entity:EmitSound. Tous les sons du reroll passent par ici pour rester coherent.
local REROLL_SOUND_VOLUME = 0.25 -- 0.5 -> 0.25 (÷2, demande user 2026-07-16)
-- "1" = sons du reroll coupés (bouton SON : ON/OFF de l'UI, persisté par client via cookie).
local REROLL_MUTE_COOKIE = "LZY_Reroll_SoundMuted"
local function PlayRerollSound(path)
	if cookie.GetString(REROLL_MUTE_COOKIE, "0") == "1" then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then
		surface.PlaySound(path)
		return
	end
	lp:EmitSound(path, 75, 100, REROLL_SOUND_VOLUME)
end

local materials = {
	bg = Material("4wsd81r0bjysb8vy/q05l5o87nzvua.png", "smooth"), -- 1920x1080
	bg_blue = Material("4wsd81r0bjysb8vy/fri5koxugb3g1i3.png", "smooth"), -- 1920x1080
	bg_red = Material("4wsd81r0bjysb8vy/o2w659pxhsjh.png", "smooth"), -- 1920x1080
	close = Material("4wsd81r0bjysb8vy/uy0x8f27b0sg.png", "smooth"), -- 60x60
	left_top_bar_bg = Material("4wsd81r0bjysb8vy/bjexqtttr63wqucp.png", "smooth"), -- 833x73
	coins_bg = Material("4wsd81r0bjysb8vy/itk1zoy41wcirx.png", "smooth"), -- 159x60
	btn_art_spirituel = Material("4wsd81r0bjysb8vy/trafvfqt1oxx6t4r.png", "smooth"), -- 223x43
	btn_hover_art_spirituel = Material("4wsd81r0bjysb8vy/sa6ujq6o5l6uifgc.png", "smooth"), -- 223x43
	btn_style_de_combat = Material("4wsd81r0bjysb8vy/5g3zumhghg3iu3rh.png", "smooth"), -- 267x43
	btn_hover_style_de_combat = Material("4wsd81r0bjysb8vy/s7pt0mgg0w2hd.png", "smooth"), -- 267x43
	btn_style_execution = Material("lzy_reroll/btn_style_execution.png", "smooth"), -- 283x43
	btn_hover_style_execution = Material("lzy_reroll/btn_hover_style_execution.png", "smooth"), -- 283x43
	btn_exec = Material("4wsd81r0bjysb8vy/tdsiydb4ao9ewric6.png", "smooth"), -- 283x43
	btn_exec_hover = Material("4wsd81r0bjysb8vy/zwqx1vxp741zq.png", "smooth"), -- 283x43
	btn_reiatsu_color = Material("lzy_reroll/btn_reiatsu_color.png", "smooth"), -- 267x43
	btn_hover_reiatsu_color = Material("lzy_reroll/btn_hover_reiatsu_color.png", "smooth"), -- 267x43
	btn_aura = Material("4wsd81r0bjysb8vy/x0ehk37d1fbux2fp.png", "smooth"), -- 267x43
	btn_aura_hover = Material("4wsd81r0bjysb8vy/xt2bgcmvwn9i9quft.png", "smooth"), -- 267x43
	reroll_bg = Material("4wsd81r0bjysb8vy/9ulg76ex65ae30ln.png", "noclamp smooth"), -- 1585x285
	reroll_bg_blue = Material("4wsd81r0bjysb8vy/tj4zg26wpmzt61.png", "noclamp smooth"), -- 1585x285
	reroll_bg_red = Material("4wsd81r0bjysb8vy/q9clonv37mtg86.png", "noclamp smooth"), -- 1585x285
	reroll_btn_bg = Material("4wsd81r0bjysb8vy/wwt1pne932ots.png", "noclamp smooth"), -- 236x118
	btn_reroll = Material("4wsd81r0bjysb8vy/51hp4vmqs182qu.png", "smooth"), -- 172x48
	btn_reroll_blue = Material("4wsd81r0bjysb8vy/34vq6k7556ahl.png", "smooth"), -- 172x48
	btn_reroll_red = Material("4wsd81r0bjysb8vy/dzjgt7f1hxsayk.png", "smooth"), -- 172x48
	btn_skip = Material("4wsd81r0bjysb8vy/s3nbdpczv7xacw.png", "smooth"), -- 172x48
	btn_skip_blue = Material("4wsd81r0bjysb8vy/76vwyglxu2tvurum8.png", "smooth"), -- 172x48
	btn_skip_red = Material("4wsd81r0bjysb8vy/oy3f8u5fa9pas.png", "smooth"), -- 172x48
	btn_loot = Material("4wsd81r0bjysb8vy/lw2q34326ww1zzbnr.png", "smooth"), -- 197x45
	btn_question = Material("4wsd81r0bjysb8vy/aapqrza379wren.png", "smooth"), -- 45x45
	reroll_cursor = Material("4wsd81r0bjysb8vy/oeadty3y98e8q6m.png", "smooth"), -- 16x253
	slot = Material("4wsd81r0bjysb8vy/v8ze0daemdmajt9.png", "noclamp smooth"), -- 200x200
	slot_blue = Material("4wsd81r0bjysb8vy/disisdoir7wuxr7h.png", "noclamp smooth"), -- 200x200
	slot_cyan = Material("4wsd81r0bjysb8vy/fgq3n4ld61ql3pq.png", "noclamp smooth"), -- 200x200
	slot_green = Material("4wsd81r0bjysb8vy/l4hndfstrw2qqq4fe.png", "noclamp smooth"), -- 200x200
	slot_red = Material("4wsd81r0bjysb8vy/dmt9znhfvl86ys.png", "noclamp smooth"), -- 200x200
	icon_empty = Material("4wsd81r0bjysb8vy/yciboiwzb1h8uj.png", "smooth"), -- 94x94
	loot_list_bg = Material("4wsd81r0bjysb8vy/1jdxm8oal3es0euwf.png", "smooth"), -- 585x665
	loot_slot = Material("4wsd81r0bjysb8vy/9lcw5pvpi4rv.png", "smooth"), -- 120x120
	raretes_bg = Material("4wsd81r0bjysb8vy/pc9bem76j9x8.png", "noclamp smooth"), -- 328x361
	equiped_slot = Material("4wsd81r0bjysb8vy/z9by274l1d7ba.png", "noclamp smooth"), -- 150x150
	coin = Material("fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "noclamp smooth"), -- 42x42
	premium_on = Material("4wsd81r0bjysb8vy/ytywpf1eoyb60tt0c.png", "smooth"), -- 220x35
	premium_off = Material("4wsd81r0bjysb8vy/dcxfts2hdbd960w5.png", "smooth"), -- 220x35
}

-- matBlurScreen retire (blur a cause de crash GPU sur certaines configs ;
-- voir les overlays loot_overlay et rarities_overlay - on utilise un simple
-- DrawRect sombre a la place).

-- ============================================================================
-- RESPONSIVE DHTML : helper qui met le contenu CSS du DHTML a la meme echelle
-- que le panel (gSetSize utilise gRespX/Y -> actual = design * scale). Sans ca,
-- les pixels CSS sont 1:1 avec les pixels actuels, donc sur 4K les elements
-- paraissent 2x plus petits relativement au panel. zoom CSS scale tout.
-- ============================================================================
local function ApplyDHTMLScale(htmlPanel)
	if not IsValid(htmlPanel) then return end
	-- min(scaleX, scaleY) pour eviter qu'un ecran 21:9 ne fasse deborder le
	-- contenu verticalement (le panel se redimensionne via gRespX/Y dans les 2
	-- axes mais le zoom CSS est un seul scalaire). Garde le contenu visible.
	local scaleX = ScrW() / 1920
	local scaleY = ScrH() / 1080
	local scale = math.min(scaleX, scaleY)
	htmlPanel:RunJavascript(string.format(
		"if (document.body) { document.body.style.zoom = %f; window.__zoom = %f; }",
		scale, scale))
end

-- Couleurs rareté pre-allouees (Color() alloue une table -> on evite dans la
-- hot loop du slot strip qui s'execute a 60 fps avec 10-15 slots visibles).
local LZY_REROLL_RARITY_BORDER = {
	secret    = Color(255,  60, 200, 255),
	mythique  = Color(255,  60,  60, 255),
	legendary = Color(255, 215,   0, 255),
	epique    = Color(190,  90, 255, 255),
	rare      = Color( 80, 160, 255, 255),
	commun    = Color(210, 210, 220, 220),
}
local LZY_REROLL_RARITY_HALO = {
	secret    = Color(255,  60, 200, 32),
	mythique  = Color(255,  60,  60, 32),
	legendary = Color(255, 215,   0, 32),
	epique    = Color(190,  90, 255, 32),
	rare      = Color( 80, 160, 255, 28),
	commun    = Color(210, 210, 220, 22),
}
-- Ordre des raretés (du plus commun au plus rare), aligné sur REROLL_DROPS_RARITIES.
-- Sert à trier l'affichage de la liste de loot par rareté.
local LZY_REROLL_RARITY_RANK = {
	commun    = 1,
	rare      = 2,
	epique    = 3,
	legendary = 4,
	mythique  = 5,
	secret    = 6,
}
local LZY_REROLL_SLOT_BG_DARK = Color(20, 22, 32, 240)
local LZY_REROLL_SLOT_BG_TOP  = Color(255, 255, 255, 8)
local function LZY_RerollGetBorder(rarity)
	return LZY_REROLL_RARITY_BORDER[rarity] or LZY_REROLL_RARITY_BORDER.commun
end
local function LZY_RerollGetHalo(rarity)
	return LZY_REROLL_RARITY_HALO[rarity] or LZY_REROLL_RARITY_HALO.commun
end

local function GetRerollPityStepRolls()
	return math.max(1, math.floor(tonumber(REROLL_PITY_STEP_ROLLS) or 10))
end

-- Helpers: derive weight and color from rarity config
local function GetDropWeight(drop)
    if not drop then return 0 end
    if drop.rarity and REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[drop.rarity] then
        local w = tonumber(REROLL_DROPS_RARITIES[drop.rarity].weight) or 0
        return math.max(0, w)
    end
    local dropRate = tonumber(drop.drop_rate) or 0
    return math.max(0, dropRate)
end

-- ════════════════════════════════════════════════════════════════════════════
-- Eye icon vectoriel partage (mirror du shop cosmetique). Pas de DHTML, pas de
-- Material -> juste DrawPoly. Pre-calcul des sin/cos en module-level (zero
-- alloc par frame). 100% Lua.
-- ════════════════════════════════════════════════════════════════════════════
local _EYE_SEGS = 32
local _EYE_COS, _EYE_SIN = {}, {}
local _EYE_POLY_OUTER, _EYE_POLY_INNER, _EYE_POLY_PUPIL = {}, {}, {}
for i = 1, _EYE_SEGS do
	local a = (i - 1) / _EYE_SEGS * math.pi * 2
	_EYE_COS[i] = math.cos(a)
	_EYE_SIN[i] = math.sin(a)
	_EYE_POLY_OUTER[i] = { x = 0, y = 0 }
	_EYE_POLY_INNER[i] = { x = 0, y = 0 }
	_EYE_POLY_PUPIL[i] = { x = 0, y = 0 }
end
local function DrawEyeIcon(cx, cy, w, h, col, bgCol)
	local hw, hh = w * 0.5, h * 0.5
	local ihw, ihh = hw - 2, hh - 1.5
	local pr = math.min(hw, hh) * 0.42
	for i = 1, _EYE_SEGS do
		local cosA, sinA = _EYE_COS[i], _EYE_SIN[i]
		local po = _EYE_POLY_OUTER[i]; po.x = cx + cosA * hw;  po.y = cy + sinA * hh
		local pi = _EYE_POLY_INNER[i]; pi.x = cx + cosA * ihw; pi.y = cy + sinA * ihh
		local pp = _EYE_POLY_PUPIL[i]; pp.x = cx + cosA * pr;  pp.y = cy + sinA * pr
	end
	draw.NoTexture()
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_OUTER)
	surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a or 255)
	surface.DrawPoly(_EYE_POLY_INNER)
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_PUPIL)
end

-- ════════════════════════════════════════════════════════════════════════════
-- Preview GIF en DFrame separee (style boutique cosmetique). 100% Lua : DFrame
-- + DPanel + Material lazy-load dans Paint. Aucun DHTML (la cause du crash).
-- Une seule preview ouverte a la fois, X close button rouge top-right.
-- ════════════════════════════════════════════════════════════════════════════
local _LZY_RerollPreviewFrame = nil
local function OpenRerollGifPreview(item)
	if not item or not item.hover_gif then return end
	if IsValid(_LZY_RerollPreviewFrame) then _LZY_RerollPreviewFrame:Close() end

	-- Finisher : la choregraphie au poing pour un joueur hakuda (REROLL_DropApercu, sh_config).
	local gifData = (REROLL_DropApercu and REROLL_DropApercu(item, LocalPlayer())) or item.hover_gif
	local fps = tonumber(gifData.fps) or 18
	local frameFormat = gifData.frame_format or "%04d.png"

	local basePath = gifData.path or ""
	if basePath ~= "" and basePath:sub(-1) ~= "/" then basePath = basePath .. "/" end
	local frameKey = basePath:gsub("/+$", "")
	local frameList = LZY_REROLL_GIF_FRAMES and LZY_REROLL_GIF_FRAMES[frameKey]
	local frames = frameList and #frameList or math.max(1, math.floor(tonumber(gifData.frames) or 1))

	-- 50% largeur ecran, 16:9 + 80px (title + bottom pad).
	local W = math.floor(ScrW() * 0.50)
	local H = math.floor(W * 9 / 16) + 80

	local f = vgui.Create("DFrame")
	f:SetSize(W, H)
	f:Center()
	f:SetTitle("")
	f:SetDraggable(true)
	f:ShowCloseButton(false)
	f:MakePopup()
	_LZY_RerollPreviewFrame = f

	f.Paint = function(_, w, h)
		surface.SetDrawColor(15, 18, 28, 245)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(180, 200, 255, 60)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText("APERÇU : " .. tostring(item.name or "?"),
			"LZY_RerollRarityTip", w / 2, 16,
			Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Close X rouge top-right
	local closeBtn = vgui.Create("DButton", f)
	closeBtn:SetSize(36, 36)
	closeBtn:SetPos(W - 44, 8)
	closeBtn:SetText("")
	closeBtn:SetCursor("hand")
	closeBtn.Paint = function(selff, w, h)
		local hover = selff:IsHovered()
		surface.SetDrawColor(hover and 220 or 160, 60, 60, 220)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("X", "LZY_RerollRarityTip", w / 2, h / 2,
			color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeBtn.DoClick = function() f:Close() end

	-- GIF panel : lazy-load des Material() au premier Paint (une seule fois).
	local gifCache = nil
	local gifPanel = vgui.Create("DPanel", f)
	gifPanel:SetPos(20, 56)
	gifPanel:SetSize(W - 40, H - 76)
	gifPanel.Paint = function(_, w, h)
		if not gifCache then
			gifCache = {}
			for fIdx = 1, frames do
				local frameFile = frameList and frameList[fIdx] or string.format(frameFormat, fIdx)
				gifCache[fIdx] = Material(basePath .. frameFile, "smooth")
			end
		end
		local idx = math.floor(CurTime() * fps) % frames + 1
		draw.RoundedBox(8, 0, 0, w, h, Color(8, 10, 16, 255))
		local mat = gifCache[idx]
		if mat and not mat:IsError() then
			surface.SetMaterial(mat)
			surface.SetDrawColor(255, 255, 255, 255)
			local pad = 4
			surface.DrawTexturedRect(pad, pad, w - pad * 2, h - pad * 2)
		end
	end

	f.OnRemove = function()
		if _LZY_RerollPreviewFrame == f then _LZY_RerollPreviewFrame = nil end
	end
end

-- Map rarity key -> text color (uses rarity.color when available)
local function GetColorForRarityKey(rarityKey)
    if not rarityKey or rarityKey == "" then return Color(255, 255, 255) end
    local colorKey = ""
    if REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[rarityKey] then
        colorKey = REROLL_DROPS_RARITIES[rarityKey].color or ""
    end
    if colorKey == "blue"   then return Color(66, 133, 244) end
    if colorKey == "cyan"   then return Color(0, 188, 212)  end
    if colorKey == "green"  then return Color(111, 207, 20) end
    if colorKey == "red"    then return Color(244, 67, 54)  end
    if colorKey == "purple" then return Color(170, 80, 230) end
    if colorKey == "yellow" then return Color(255, 215, 0)  end
    if colorKey == "gray"   then return Color(170, 170, 170) end
    if colorKey == "secret" then return Color(255,  60, 200) end
    return Color(255, 255, 255)
end

local function TitleForRarityKey(rarityKey)
    if rarityKey == "commun" then return "Commun" end
    if rarityKey == "rare" then return "Rare" end
    if rarityKey == "epique" then return "Epique" end
    if rarityKey == "legendary" then return "Legendary" end
    if rarityKey == "mythique" then return "Mythique" end
    if rarityKey == "secret" then return "Secret" end
    return tostring(rarityKey or "?")
end

local function FormatWeight(value)
    if not value then return "0" end
    local n = tonumber(value) or 0
    if n == 0 then return "0" end
    if math.floor(n) == n then return tostring(math.floor(n)) end
    -- Décimales ADAPTATIVES : les très petites cotes (ex: SECRET 0.001%) doivent rester
    -- visibles au lieu d'être arrondies à "0" par un format figé à 2 décimales.
    -- Plus le nombre est petit, plus on montre de décimales : sinon un boost de pity sur une
    -- petite rareté (ex. mythique 0.01 -> 0.0128 au pity 14) s'arrondissait à "0.01" et semblait
    -- INCHANGÉ alors qu'il l'était bien (calcul OK, c'était l'affichage qui masquait).
    local decimals = 2
    if n < 1     then decimals = 3 end
    if n < 0.1   then decimals = 4 end
    if n < 0.001 then decimals = 5 end
    local s = string.format("%." .. decimals .. "f", n)
    s = s:gsub("0+$", "")
    s = s:gsub("%.$", "")
    return s
end

local function GetDropColor(drop)
    if not drop then return "" end
    if drop.color and drop.color ~= "" then return drop.color end
    if drop.rarity and REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[drop.rarity] then
        return REROLL_DROPS_RARITIES[drop.rarity].color or ""
    end
    return ""
end

-- Declaree ICI, definie plus bas : GetDropByWinId l'appelle, et un `local function` ecrit apres
-- son premier appel n'est pas encore en portee (Lua cherchait une globale -> nil, erreur a chaque
-- image dans le menu de reroll).
local NomSelonFamille

-- Helper function to get drop by win_id
local function GetDropByWinId(win_id, faction, category)
	if not win_id or win_id == "" then return nil end
	local pool = (REROLL_DROPS[faction] and REROLL_DROPS[faction][category]) or {}
	for i = 1, #pool do
		if pool[i].win_id == win_id then
			return NomSelonFamille(pool[i], category)
		end
	end
	return nil
end

local function BuildPityKey(_, category)
	return REROLL_PityKey(category)
end

local function RarityKeysToSortedFrenchList(tbl)
	local names = {}
	if type(tbl) ~= "table" then return "Legendary, Mythique" end
	for r, on in pairs(tbl) do
		if on then names[#names + 1] = TitleForRarityKey(r) end
	end
	table.sort(names)
	if #names == 0 then return "Legendary, Mythique" end
	return table.concat(names, ", ")
end

local function GetPityHelpTooltipText()
	local step = GetRerollPityStepRolls()
	local boostAdd = tonumber(REROLL_PITY_BOOST_PER_LEVEL) or 0
	local boosted = RarityKeysToSortedFrenchList(REROLL_PITY_BOOST_RARITIES)
	local reset = RarityKeysToSortedFrenchList(REROLL_PITY_RESET_ON_RARITIES)
	return string.format(
		"Comment ça marche ?\n\n" ..
		"• Si au bout de %d rerolls, vous n'avez pas obtenu un item de rareté « %s »,\n le niveau de pity augmente.\n\n" ..
		"• Chaque niveau de pity ajoute +%s au poids de la rareté « %s ».\n\n" ..
		"• Obtenir une rareté parmi « %s » remet la pity à 0 pour cette catégorie.\n\n" ..
		"• Avec Platinum, la pity ne se remet à 0 que si vous acceptez le drop.\nUn drop refusé compte comme un reroll de plus.\n\n" ..
		"• Chaque type de reroll (Art Spirituel, Style de Combat, Style d'Exécution et Aura Spirituel)\n conserve sa propre pity, partagée entre tous vos personnages (Shinigami et Hollow).",
		step,
		boosted,
		tostring(boostAdd),
		boosted,
		reset
	)
end

-- Palier de protection reroll (premium) : le joueur CHOISIT à partir de quelle
-- rareté la « Sécurité Reroll » demande confirmation — COMMUN / RARE (défaut) /
-- ÉPIQUE / LÉGENDAIRE / MYTHIQUE / SECRET (si disponible). En DESSOUS du palier,
-- aucune question : le tirage est refusé et l'objet équipé reste (cf. autoKept, sv_main).
-- Convar USERINFO (archive + userinfo) -> lue CÔTÉ SERVEUR (GetInfoNum) au tirage.
-- Valeurs = tiers serveur : 1=commun, 2=rare, 3=épique, 4=légendaire, 5=mythique, 6=secret.
-- Le serveur
-- ne la lit que pour un grade payant : la forcer en console sans premium ne donne rien.
local cvProtectFloor = CreateClientConVar("lzy_reroll_protect_floor", "2", true, true)
local cvConfirmUpgrades = CreateClientConVar("lzy_reroll_confirm_upgrades", "0", true, true)
local PROTECT_FLOORS = {
	{ tier = 1, label = "COMMUN",     col = Color(180, 185, 195) },
	{ tier = 2, label = "RARE",       col = Color(80, 200, 235) },
	{ tier = 3, label = "ÉPIQUE",     col = Color(170, 90, 220) },
	{ tier = 4, label = "LÉGENDAIRE", col = Color(230, 190, 70) },
	{ tier = 5, label = "MYTHIQUE",   col = Color(255, 60, 60) },
	{ tier = 6, label = "SECRET",     col = Color(255, 60, 200) },
}

local function GetAvailableProtectFloors(pool)
	local hasSecret = false
	for _, drop in ipairs(pool or {}) do
		if drop.rarity == "secret" then hasSecret = true break end
	end
	local floors = {}
	for _, floor in ipairs(PROTECT_FLOORS) do
		if floor.tier ~= 6 or hasSecret then floors[#floors + 1] = floor end
	end
	return floors
end

local function GetPremiumRerollTooltipText()
	return "Comment ça marche ?\n\n" ..
		"• Avec premium : un objet moins rare que l'actuel ne peut pas vous le faire perdre.\nSous le palier « DEMANDER DÈS », le tirage est refusé et vous gardez votre objet, sans\nquestion — y compris à rareté égale. À partir du palier, vous choisissez (OUI / NON).\n\n" ..
		"• Le sélecteur « DEMANDER DÈS » choisit ce palier : COMMUN, RARE (défaut),\nÉPIQUE, LÉGENDAIRE, MYTHIQUE ou SECRET (si disponible dans votre pool).\nUn tirage meilleur s'équipe automatiquement, sauf avec Platinum si la case\n« CONFIRMER LES AMÉLIORATIONS » est cochée.\n\n" ..
		"• Sans premium : AUCUNE protection. Le résultat du reroll s'applique dès\n l'obtention d'un nouvel objet, même s'il est moins rare — un mythique peut être\nremplacé par un commun."
end

local function GetPlatinumPityTooltipText()
	return "Sécurité Pity — Platinum uniquement\n\n" ..
		"• Si vous conservez votre objet actuel (NON), votre pity ne se remet pas à 0,\nmême après un drop légendaire, mythique ou secret. Ce reroll ajoute +1 à votre\nprogression de pity.\n\n" ..
		"• Un drop refusé automatiquement ou une confirmation laissée sans réponse\nconserve également votre progression.\n\n" ..
		"• Si vous acceptez le nouveau drop (OUI), ou si une amélioration s'équipe\nautomatiquement, une rareté qui réinitialise la pity la remet à 0.\n\n" ..
		"• Cet avantage est réservé au grade Platinum. Premium et VIP continuent\nde remettre la pity à 0 dès qu'une rareté concernée est tirée."
end

-- ════════════════════════════════════════════════════════════════════════════
-- Style d'infobulle commun, repris du menu OST (lzy_ost/client/cl_main.lua) :
-- plaque sombre a angles droits, lisere accent a gauche, contour 1px discret.
-- Toutes les bulles du reroll (panels Derma ET bulles dessinees a la main dans
-- les Paint) passent par ces helpers pour rester identiques.
-- ════════════════════════════════════════════════════════════════════════════
local TIP_BG     = Color(22, 22, 27)
local TIP_ACCENT = Color(207, 68, 78)
local TIP_BORDER = Color(255, 255, 255, 18)
local TIP_TEXT   = Color(238, 239, 243)
local TIP_MUTED  = Color(150, 154, 162)

local function DrawTooltipFrame(x, y, w, h)
	if EVO_UI and EVO_UI.PaintTooltip then
		return EVO_UI.PaintTooltip(x, y, w, h)
	end
	RNDX.Draw(0, x, y, w, h, TIP_BG)
	surface.SetDrawColor(TIP_ACCENT)
	surface.DrawRect(x, y, gRespX(3), h)
	surface.SetDrawColor(TIP_BORDER)
	surface.DrawOutlinedRect(x, y, w, h, 1)
end

-- Position ECRAN d'une bulle w x h ancree au-dessus de (cx, cy) : bascule sous
-- le point d'ancrage quand le haut deborde, puis clampe dans l'ecran -> la
-- bulle n'est jamais rognee par un bord, quelle que soit sa taille.
local function ClampTipToScreen(cx, cy, w, h, offset)
	local mx, my = gRespX(6), gRespY(6)
	local x = math.Clamp(cx - w * 0.5, mx, math.max(mx, ScrW() - w - mx))
	local y = cy - h - offset
	if y < my then y = cy + offset end
	y = math.Clamp(y, my, math.max(my, ScrH() - h - my))
	return x, y
end

-- Custom tooltip panel with dark theme
local TOOLTIP_PANEL = {}
function TOOLTIP_PANEL:Init()
	self:SetDrawOnTop(true)
	self:SetText("")
	self:SetFont("LZY_RerollTooltip") -- plus gros que DermaDefault (demande user 2026-07-26)
	self:SetTextColor(TIP_TEXT)
end
function TOOLTIP_PANEL:Paint(w, h)
	DrawTooltipFrame(0, 0, w, h)
end
function TOOLTIP_PANEL:PerformLayout()
	local w, h = self:GetContentSize()
	self:SetSize(w + gRespX(20), h + gRespY(12))
	self:SetContentAlignment(5)
end
function TOOLTIP_PANEL:OpenForPanel(panel)
	-- Get text from panel's tooltip text
	if panel and panel.strTooltipText then
		self:SetText(panel.strTooltipText)
	end
	-- InvalidateLayout(true) AVANT de lire la taille : sinon on positionnait la
	-- bulle avec l'ancienne taille (celle d'avant le SetText) et le clamp ecran
	-- portait sur des dimensions fausses -> debordement en bord d'ecran.
	self:InvalidateLayout(true)
	local cx, cy = input.GetCursorPos()
	self:SetPos(ClampTipToScreen(cx, cy, self:GetWide(), self:GetTall(), gRespY(18)))

	-- Set visible after delay
	self.TargetPanel = panel
	self.OpenDelay = isnumber(panel.numTooltipDelay) and panel.numTooltipDelay or 0.5
	if self.OpenDelay > 0 then
		self:SetVisible(false)
		timer.Simple(self.OpenDelay, function()
			if not IsValid(self) then return end
			if not IsValid(panel) then return end
			self:SetVisible(true)
		end)
	else
		self:SetVisible(true)
	end
end
function TOOLTIP_PANEL:Close()
	self:Remove()
end
vgui.Register("LZYCustomTooltip", TOOLTIP_PANEL, "DLabel")

-- ════════════════════════════════════════════════════════════════════════════
-- Tooltip dedie aux slots du loot pool : affiche juste la rarete avec une
-- font plus grosse (Bebas Neue 28pt) et un style premium.
-- ════════════════════════════════════════════════════════════════════════════
-- Font responsive : on calcule la taille inline (pas de dependance externe sur
-- gRespFont qui peut ne pas etre charge a l'inclusion du file). Meme formule
-- sqrt-conservative que glibs gRespFont. Regenere a chaque OnScreenSizeChanged.
local function _LZY_RerollRespFont(baseSize)
	local scaleX = ScrW() / 1920
	local scaleY = ScrH() / 1080
	local scale = math.min(scaleX, scaleY)
	local fontScale = 1 + (math.sqrt(scale) - 1) * 0.7
	return math.Round(baseSize * fontScale)
end
local function _LZY_RerollCreateFonts()
	surface.CreateFont("LZY_RerollRarityTip", {
		font = "Bebas Neue", size = _LZY_RerollRespFont(32), weight = 700,
		antialias = true, extended = true,
	})
	-- Police secondaire (rareté + taux de drop) du tooltip loot : plus petite que le nom.
	surface.CreateFont("LZY_RerollTipSmall", {
		font = "Bebas Neue", size = _LZY_RerollRespFont(22), weight = 500,
		antialias = true, extended = true,
	})
	-- Police des tooltips custom (pity / premium / sélecteur) : DermaDefault était
	-- trop petit (demande user 2026-07-26) -> Roboto ~19 responsive.
	surface.CreateFont("LZY_RerollTooltip", {
		font = "Roboto", size = _LZY_RerollRespFont(19), weight = 500,
		antialias = true, extended = true,
	})
	-- Police du sélecteur « DEMANDER DÈS » (bouton + options de la liste) : plus
	-- grosse que TipSmall (demande user 2026-07-26).
	surface.CreateFont("LZY_RerollProtect", {
		font = "Bebas Neue", size = _LZY_RerollRespFont(28), weight = 500,
		antialias = true, extended = true,
	})
end
_LZY_RerollCreateFonts()
hook.Add("OnScreenSizeChanged", "LZY_RerollFontsResp", _LZY_RerollCreateFonts)

local RARITY_TIP = {}
function RARITY_TIP:Init()
	self:SetDrawOnTop(true)
	self:SetFont("LZY_RerollRarityTip")
	self:SetTextColor(TIP_TEXT)
	self:SetContentAlignment(5)
end
function RARITY_TIP:Paint(w, h)
	DrawTooltipFrame(0, 0, w, h)
end
function RARITY_TIP:PerformLayout()
	local w, h = self:GetContentSize()
	self:SetSize(w + gRespX(20), h + gRespY(12))
	self:SetContentAlignment(5)
end
function RARITY_TIP:OpenForPanel(panel)
	if panel and panel.strTooltipText then self:SetText(panel.strTooltipText) end
	self:InvalidateLayout(true)
	local cx, cy = input.GetCursorPos()
	self:SetPos(ClampTipToScreen(cx, cy, self:GetWide(), self:GetTall(), gRespY(18)))
	self.TargetPanel = panel
	self.OpenDelay = isnumber(panel.numTooltipDelay) and panel.numTooltipDelay or 0.3
	if self.OpenDelay > 0 then
		self:SetVisible(false)
		timer.Simple(self.OpenDelay, function()
			if not IsValid(self) then return end
			if not IsValid(panel) then return end
			self:SetVisible(true)
		end)
	else
		self:SetVisible(true)
	end
end
function RARITY_TIP:Close() self:Remove() end
vgui.Register("LZY_RerollRarityTooltip", RARITY_TIP, "DLabel")

-- ════════════════════════════════════════════════════════════════════════════
-- Mapping win_id -> nom FR du pouvoir pour les arts spirituels.
-- Utilise pour le tooltip hover : on affiche le nom du pouvoir plutot que le
-- nom du personnage source. Lookup case-insensitive (lower) pour robustesse.
-- ════════════════════════════════════════════════════════════════════════════
-- Table DEPLACEE dans lzy_reroll/sh_config.lua (source unique, cf. EVO_ART_POWER_FR).
-- Elle vivait ici en `local`, donc invisible des autres addons : le panneau de
-- recreation de perso affichait « Unohana » au lieu de « Sang ».
local LZY_REROLL_ART_POWER_FR = EVO_ART_POWER_FR or {}

-- Retourne le nom FR du pouvoir pour un drop (art_spirituel uniquement), ou
-- fallback sur drop.name si pas trouve dans le mapping.
local function GetArtPowerNameFR(drop)
	if not drop then return "" end
	if drop.win_id then
		local key = tostring(drop.win_id):lower()
		local fr = LZY_REROLL_ART_POWER_FR[key]
		if fr then return fr end
	end
	return drop.name or ""
end

function PANEL:RefreshRerollLeftFromNW()
	local key = LZY_RerollStockKey(self.current_category or "")
	if not key then
		self.reroll_left = 0
		return
	end
	self.reroll_left = LocalPlayer():GetEvoNWInt(key, 0)
end

-- Filtre le pool de "style_de_combat" par la FAMILLE du joueur (katana / hakuda) — DOIT être
-- IDENTIQUE au filtre serveur (lzy_reroll/sv_main), même ordre : l'index du résultat de reroll
-- (envoyé par le serveur) pointe dans CE pool. Famille = override tuto (NWString NCM_TutoFamily)
-- sinon dérivée du style courant. Les autres catégories passent inchangées.
-- Finisher : copie renommée pour un Hakuda (même ordre, l'index serveur reste valable).
function NomSelonFamille(d, category)
	if category ~= "style_execution" or not d then return d end
	local s = REROLL_DropNom(d, category, LocalPlayer())
	if s == d.name then return d end
	local c = {}
	for k, v in pairs(d) do c[k] = v end
	c.name = s
	return c
end

local function FilterStylePoolByFamily(pool, category)
	if category == "style_execution" then
		local out = {}
		for i, d in ipairs(pool) do out[i] = NomSelonFamille(d, category) end
		return out
	end
	if category ~= "style_de_combat" then return pool end
	if not (EvoStyle and EvoStyle.GetStyleFamily) then return pool end
	local lp = LocalPlayer()
	if not IsValid(lp) then return pool end
	local sTuto = lp:GetEvoNWString("NCM_TutoFamily", "")
	local fam = (sTuto ~= "") and sTuto or EvoStyle.GetStyleFamily(lp:GetEvoNWString("StyleCombat", ""))
	local out = {}
	for _, d in ipairs(pool) do
		if (d.family or "katana") == fam then out[#out + 1] = d end
	end
	if #out > 0 then return out end
	return pool
end

function PANEL:Init()
	self.faction = LocalPlayer():GetEvoNWString("FactionName", "Shinigami")
	-- Catégorie de départ : "art_spirituel" par défaut, sauf présélection one-shot posée par
	-- LZY_Reroll_Open (ex. flux Maître d'Armes -> ouvre DIRECTEMENT la roulette "style_de_combat").
	self.start_category = (isstring(LZY_Reroll_StartCategory) and LZY_Reroll_StartCategory) or "art_spirituel"
	LZY_Reroll_StartCategory = nil
	self.current_category = self.start_category
	-- Resync du stock DEPUIS LA BASE des l'ouverture : le NWInt local peut etre en
	-- retard (credit livre par un AUTRE serveur pendant que le joueur etait ici).
	-- L'aller-retour SELECT revient en ~50ms, bien avant le premier clic ; le Think
	-- du bouton repercute ensuite la valeur fraiche automatiquement.
	self:_BindRerollNet()
	net.Start("lzy_reroll_resync")
	net.SendToServer()
	self:RefreshRerollLeftFromNW()
	self.coins = LocalPlayer():GetEvoNWInt("coins", 0)
	-- format coins (ex: 100000 -> 100 000)
	self.coins = string.format("%d", self.coins)
	self.coins = self.coins:reverse():gsub("(%d%d%d)", "%1 "):reverse()

	self.art_spirituel = LocalPlayer():GetEvoNWString("ArtSpirituel", "")
	self.style_combat = LocalPlayer():GetEvoNWString("StyleCombat", "")
	self.style_execution = LocalPlayer():GetEvoNWString("EvoFinisher", "")
	self.reiatsu_color = LocalPlayer():GetEvoNWString("ReiatsuColor", "")
	self.catalyseur = LocalPlayer():GetEvoNWString("EvoCatalyseur", "")

	self.pendingRollUpdate = nil
	self.pityByCategory = REROLL_CollapsePities(util.JSONToTable(LocalPlayer():GetEvoNWString("LZY_Reroll_Pities", "{}")) or {})

	self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	self:SetVisible(true)

	self.panelWidth = 1920
	self.panelHeight = 1080
	self:gSetSize(self.panelWidth, self.panelHeight)

	-- slot machine state
	self.currentPool = FilterStylePoolByFamily(REROLL_FilterHidden((REROLL_DROPS[self.faction] and REROLL_DROPS[self.faction][self.current_category]) or {}, LocalPlayer()), self.current_category)
	self.renderPool = {}
	self.slotGap = gRespX(10)
	self.slotSizeX = gRespX(200)
	self.slotSizeY = gRespY(200)
	self.stepSize = self.slotSizeX + self.slotGap
	self.scrollOffset = 0
	self.isSpinning = false
	self.spinPhase = "idle"
	self.spinStartTime = 0
	self.spinDuration = 9.0 -- total animation time in seconds (configurable)
	self.spinStartOffset = 0
	self.spinTargetOffset = 0
	self.spinDistance = 0
	self.pendingSpeed = gRespX(1200)
	self.isWaitingResult = false
	-- slot tick sound (plays when cursor passes a slot). Change to your custom file if needed
	self.tickSound = self.tickSound or "4wsd81r0bjysb8vy/j7yfn6t0r7a7d.wav"
	self._lastTickStep = math.floor(self.scrollOffset / (self.stepSize > 0 and self.stepSize or 1))

	self:BuildRenderPool()

	-- close button (top right) — croix standard DA : glyphe ✕, pas de fond,
	-- gris -> accent au survol (remplace le PNG materials.close).
	self.closeBtn = vgui.Create("DButton", self)
	self.closeBtn:gSetSize(60, 60)
	self.closeBtn:gSetPos(self.panelWidth - 60 - 162, 140)
	self.closeBtn:SetText("")
	self.closeBtn:SetCursor("hand")
	self.closeBtn.Paint = function(selff, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:30", w / 2, h / 2,
			selff:IsHovered() and Color(207, 68, 78) or Color(150, 154, 162),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.closeBtn.DoClick = function()
		self:Close()
	end

	-- Bouton MUTE des sons du reroll (demande user 2026-07-16, replacé 2026-07-16) : petite
	-- plaque « SON / ON-OFF » intégrée à la rangée haut-droite, collée à GAUCHE de la plaque
	-- EVO COINS (x = panelWidth-60-340, w 159) — même DA qu'elle (PaintCut coin bas-droit,
	-- libellé Bebas 16 + valeur Bebas 22, mêmes offsets +10/+26). L'ancien placement
	-- (170 de large à gauche de la croix) CHEVAUCHAIT la plaque EVO COINS. État persisté
	-- par client (cookie REROLL_MUTE_COOKIE), lu par PlayRerollSound -> coupe TOUS les sons
	-- du reroll (ticks de roulette + révélations).
	self.muteBtn = vgui.Create("DButton", self)
	self.muteBtn:gSetSize(70, 60)
	self.muteBtn:gSetPos(self.panelWidth - 60 - 340 - 80, 140)
	self.muteBtn:SetText("")
	self.muteBtn:SetCursor("hand")
	self.muteBtn.Paint = function(selff, w, h)
		local bMuted = cookie.GetString(REROLL_MUTE_COOKIE, "0") == "1"
		local colBg = selff:IsHovered() and Color(26, 28, 33, 235) or Color(17, 18, 22, 235)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, colBg, gRespY(10), "br")
		else
			RNDX.Draw(0, 0, 0, w, h, colBg)
		end
		-- Fontes agrandies 16/22 -> 20/30 (demande user 2026-07-17), offsets réajustés pour
		-- rester centrés dans la plaque de 60 de haut.
		draw.SimpleText("SON", "Bebas Neue:20", w / 2, gRespY(6), Color(150, 154, 162), TEXT_ALIGN_CENTER)
		draw.SimpleText(bMuted and "OFF" or "ON", "Bebas Neue:30", w / 2, gRespY(26),
			bMuted and Color(207, 68, 78) or Color(237, 238, 242), TEXT_ALIGN_CENTER)
	end
	self.muteBtn.DoClick = function()
		local bMuted = cookie.GetString(REROLL_MUTE_COOKIE, "0") == "1"
		cookie.Set(REROLL_MUTE_COOKIE, bMuted and "0" or "1")
	end

	-- ════════════════════════════════════════════════════════════════════════
	-- BARRE DES 4 CATEGORIES — DHTML stylise (remplace les 4 DButton + materials
	-- btn_art_spirituel / btn_hover_art_spirituel / btn_style_de_combat /
	-- btn_hover_style_de_combat / btn_exec / btn_exec_hover / btn_aura /
	-- btn_aura_hover). Single panel transparent qui sit au-dessus du
	-- left_top_bar_bg deja dessine en arriere-plan.
	-- Anim legeres uniquement : transition color/background/border-color (GPU
	-- compositor friendly, zero filter/blur/box-shadow anime).
	-- ════════════════════════════════════════════════════════════════════════
	self.categoryTabs = vgui.Create("DHTML", self)
	self.categoryTabs:gSetSize(1085, 43)
	self.categoryTabs:gSetPos(162 + 15, 134 + 15)
	self.categoryTabs:SetScrollbars(false)
	self.categoryTabs:SetAllowLua(false)
	self.categoryTabs:SetMouseInputEnabled(true)

	local tabsHtml = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; }
html, body {
  width: 100%; height: 100%; overflow: hidden;
  background: transparent; cursor: default;
  font-family: 'Bebas Neue', 'Arial Black', sans-serif;
}
.tabs { display: flex; height: 100%; gap: 8px; }
.tab {
  position: relative;
  flex: 1; height: 100%;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; font-weight: 700; letter-spacing: 0.08em; /* 5 onglets depuis le 10/06 */
  color: rgba(190, 190, 210, 0.75);
  background: rgba(15, 15, 22, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 4px;
  cursor: pointer;
  text-transform: uppercase;
  transition: color 0.18s ease, background 0.18s ease, border-color 0.18s ease;
}
/* Hover JS-managed (.hover class au lieu de :hover CSS) car en GMod Chromium,
   quand le curseur quitte vite le DHTML, le mouseleave n'arrive pas et l'etat
   :hover reste colle. La classe est forcement retiree par Lua OnCursorExited. */
.tab.hover {
  color: #fff;
  background: rgba(35, 40, 55, 0.7);
  border-color: rgba(180, 200, 255, 0.35);
}
.tab.active {
  color: #fff;
  background: linear-gradient(180deg, rgba(55, 75, 130, 0.55) 0%, rgba(30, 40, 80, 0.4) 100%);
  border-color: rgba(180, 200, 255, 0.7);
}
.tab.active::after {
  content: '';
  position: absolute;
  bottom: 3px; left: 22%; right: 22%; height: 2px;
  background: linear-gradient(90deg, transparent, rgba(180, 210, 255, 0.95), transparent);
}
body.spinning .tab { cursor: not-allowed; opacity: 0.5; pointer-events: none; }
</style></head><body>
<div class="tabs">
  <div class="tab" data-cat="art_spirituel"   onclick="pick('art_spirituel')">Art Spirituel</div>
  <div class="tab" data-cat="style_de_combat" onclick="pick('style_de_combat')">Style de Combat</div>
  <div class="tab" data-cat="style_execution" onclick="pick('style_execution')">Style d'Execution</div>
  <div class="tab" data-cat="reiatsu_color"   onclick="pick('reiatsu_color')">Couleur Reiatsu</div>
 __CATALYSEUR_TAB__</div>
<script>
function pick(cat) {
  try { gmod.pickCategory(cat); } catch(e) {}
}
function clearAllHover() {
  var tabs = document.querySelectorAll('.tab');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove('hover');
}
// Hover Lua-driven : Lua detecte l'index de tab sous la souris et pousse ici.
// idx = -1 -> aucune tab, sinon 0..3.
function setHoverIndex(idx) {
  var tabs = document.querySelectorAll('.tab');
  for (var i = 0; i < tabs.length; i++) {
    if (i === idx) tabs[i].classList.add('hover');
    else           tabs[i].classList.remove('hover');
  }
}
function setActive(cat) {
  var tabs = document.querySelectorAll('.tab');
  for (var i = 0; i < tabs.length; i++) {
    if (tabs[i].getAttribute('data-cat') === cat) tabs[i].classList.add('active');
    else tabs[i].classList.remove('active');
  }
}
function setSpinning(b) {
  if (b) document.body.classList.add('spinning');
  else   document.body.classList.remove('spinning');
}
</script>
</body></html>
]]
	-- Onglet Catalyseur : superadmins seulement tant que la catégorie est en test (10/07).
	local bCataTab = LocalPlayer():IsSuperAdmin()
	self._nCatTabs = bCataTab and 5 or 4
	tabsHtml = string.Replace(tabsHtml, " __CATALYSEUR_TAB__", bCataTab
		and [[  <div class="tab" data-cat="catalyseur"      onclick="pick('catalyseur')">Catalyseur</div>
]] or "")
	self.categoryTabs:SetHTML(tabsHtml)
	ApplyDHTMLScale(self.categoryTabs)

	self.categoryTabs:AddFunction("gmod", "pickCategory", function(cat)
		if self.isSpinning or self.isWaitingResult then return end
		if cat ~= "art_spirituel" and cat ~= "style_de_combat"
			and cat ~= "style_execution" and cat ~= "reiatsu_color" and cat ~= "catalyseur" then return end
		if cat == "catalyseur" and not LocalPlayer():IsSuperAdmin() then return end
		self.current_category = cat
		self.currentPool = FilterStylePoolByFamily(REROLL_FilterHidden((REROLL_DROPS[self.faction] and REROLL_DROPS[self.faction][self.current_category]) or {}, LocalPlayer()), self.current_category)
		self.scrollOffset = 0
		self:BuildRenderPool()
		self:RefreshRerollLeftFromNW()
		-- toujours cliquable : a 0 reroll le clic redirige vers la boutique
		if IsValid(self.btn_reroll) then self.btn_reroll:SetEnabled(true) end
		-- Sync visuel cote DHTML
		if IsValid(self.categoryTabs) then
			self.categoryTabs:RunJavascript("setActive('" .. cat .. "')")
		end
	end)

	-- Init de l'onglet actif apres que le HTML soit charge (deferred d'un frame).
	timer.Simple(0.1, function()
		if IsValid(self) and IsValid(self.categoryTabs) then
			self.categoryTabs:RunJavascript("setActive('" .. tostring(self.current_category) .. "')")
		end
	end)

	-- Petit Think qui sync l'etat spinning du Lua vers le DHTML (lock visuel des
	-- onglets pendant un spin OU pendant l'attente serveur). Verifie juste un
	-- diff bool chaque frame : cheap.
	self._lastSpinningSent = nil
	-- Invalide la cache quand le doc finit de charger pour forcer un re-sync
	-- (sinon les premiers calls Think tombent avant que <script> soit parse).
	self.categoryTabs.OnFinishLoadingDocument = function(selff)
		ApplyDHTMLScale(selff) -- garantit le zoom CSS responsive
		self._lastSpinningSent = nil
		if IsValid(self) and IsValid(self.categoryTabs) then
			self.categoryTabs:RunJavascript("if(typeof setActive==='function')setActive('" .. tostring(self.current_category) .. "')")
		end
	end
	-- Hover Lua-driven : on detecte la tab sous le curseur chaque frame depuis
	-- Lua (cursor pos + bornes du panel) et on pousse l'index a setHoverIndex.
	-- Plus robuste que les events Chromium mouseenter/mouseleave qui rate des
	-- transitions en GMod (souris qui sort/rentre vite). On envoie seulement
	-- quand l'index change pour rester cheap.
	self._lastHoverIdx = -2 -- -2 = jamais set, -1 = aucune, 0..3 = tab idx
	self.categoryTabs.Think = function(htmlSelf)
		-- Sync spinning / attente serveur (meme lock visuel des onglets)
		local s = (self.isSpinning or self.isWaitingResult) and true or false
		if s ~= self._lastSpinningSent then
			self._lastSpinningSent = s
			htmlSelf:RunJavascript("if(typeof setSpinning==='function')setSpinning(" .. tostring(s) .. ")")
		end

		-- Calcule l'index de tab hovered ; si le panel n'est pas hovered ou
		-- qu'on est en spinning / attente, idx = -1 (aucune tab hovered).
		local idx = -1
		if htmlSelf:IsHovered() and not self.isSpinning and not self.isWaitingResult then
			local mx, my = htmlSelf:CursorPos()
			local pw, ph = htmlSelf:GetSize()
			if mx >= 0 and mx < pw and my >= 0 and my < ph then
				-- 4 ou 5 tabs egales (Catalyseur = superadmins), gap 8px ignore pour la detection
				local nTabs = self._nCatTabs or 4
				local tabW = pw / nTabs
				idx = math.floor(mx / tabW)
				if idx < 0 then idx = -1 elseif idx > nTabs - 1 then idx = -1 end
			end
		end
		if idx ~= self._lastHoverIdx then
			self._lastHoverIdx = idx
			htmlSelf:RunJavascript("if(typeof setHoverIndex==='function')setHoverIndex(" .. tostring(idx) .. ")")
		end
	end

	-- ════════════════════════════════════════════════════════════════════════
	-- BOUTON REROLL — DHTML qui remplace DButton + materials btn_reroll/_blue/
	-- _red/btn_skip/_blue/_red + le bg reroll_btn_bg + le texte "X REROLL RESTANT".
	-- Contient tout : bg dark dans le style item possede + bouton centre + texte
	-- en dessous. Etat (REROLL/SKIP/disabled/count) sync via Think watcher.
	-- ════════════════════════════════════════════════════════════════════════
	-- Container 320x140. Position descendue : offset +150 -> y=620, ends y=760.
	local rerollBtnW, rerollBtnH = 320, 140
	local rerollBtnX = math.floor((self.panelWidth - rerollBtnW) / 2)
	local rerollBtnY = math.floor((self.panelHeight - rerollBtnH) / 2) + 150
	self.btn_reroll = vgui.Create("DHTML", self)
	self.btn_reroll:gSetSize(rerollBtnW, rerollBtnH)
	self.btn_reroll:gSetPos(rerollBtnX, rerollBtnY)
	self.btn_reroll:SetScrollbars(false)
	self.btn_reroll:SetAllowLua(false)

	-- Theme par faction : couleurs accent pour la border/glow du bouton
	local rerollFactionClass = (self.faction == "Shinigami") and "shinigami" or (self.faction == "Hollow") and "hollow" or ""
	local rerollBtnHtml = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; }
html, body {
  width: 100%; height: 100%; overflow: hidden; background: transparent; cursor: default;
  font-family: 'Bebas Neue', 'Arial Black', sans-serif;
}
.wrap {
  width: 100%; height: 100%;
  background: transparent; /* plus de BG rectangle - juste bouton + compteur */
  padding: 8px 0 0 0;
  display: flex; flex-direction: column; align-items: center; gap: 14px;
}

.btn {
  width: 220px; height: 62px;
  display: flex; align-items: center; justify-content: center;
  font-size: 30px; font-weight: 700; letter-spacing: 0.22em;
  text-transform: uppercase;
  background: linear-gradient(180deg, rgba(60, 80, 130, 0.55) 0%, rgba(35, 50, 90, 0.7) 100%);
  border: 2px solid rgba(180, 200, 255, 0.6);
  border-radius: 12px;
  color: #fff;
  cursor: pointer;
  transition: background 0.18s ease, border-color 0.18s ease, color 0.18s ease, box-shadow 0.18s ease;
  box-shadow: 0 0 12px rgba(180, 200, 255, 0.25);
}
.wrap.shinigami .btn {
  background: linear-gradient(180deg, rgba(40, 90, 160, 0.7) 0%, rgba(25, 55, 110, 0.85) 100%);
  border-color: rgba(120, 200, 255, 0.75);
  box-shadow: 0 0 14px rgba(120, 200, 255, 0.35);
}
.wrap.hollow .btn {
  background: linear-gradient(180deg, rgba(160, 40, 40, 0.7) 0%, rgba(100, 25, 25, 0.85) 100%);
  border-color: rgba(255, 130, 130, 0.75);
  box-shadow: 0 0 14px rgba(255, 130, 130, 0.35);
}
.btn.hover {
  background: linear-gradient(180deg, rgba(85, 110, 170, 0.75) 0%, rgba(55, 75, 130, 0.9) 100%);
  box-shadow: 0 0 22px rgba(180, 200, 255, 0.55);
}
.wrap.shinigami .btn.hover { background: linear-gradient(180deg, rgba(60, 130, 200, 0.85) 0%, rgba(40, 90, 160, 0.95) 100%);
                              box-shadow: 0 0 22px rgba(120, 200, 255, 0.6); }
.wrap.hollow .btn.hover    { background: linear-gradient(180deg, rgba(200, 60, 60, 0.85) 0%, rgba(140, 40, 40, 0.95) 100%);
                              box-shadow: 0 0 22px rgba(255, 130, 130, 0.6); }
.btn.disabled {
  opacity: 0.35; cursor: not-allowed;
  background: linear-gradient(180deg, rgba(50, 50, 60, 0.5) 0%, rgba(30, 30, 38, 0.7) 100%);
  border-color: rgba(120, 120, 130, 0.4);
  box-shadow: none;
}

.count {
  font-family: 'Bebas Neue', 'Arial Black', sans-serif;
  font-size: 14px; font-weight: 700; letter-spacing: 0.2em;
  color: rgba(180, 200, 220, 0.95);
  text-transform: uppercase;
  text-shadow: 0 0 10px rgba(0, 0, 0, 0.8);
}
</style></head><body>
<div class="wrap ]] .. rerollFactionClass .. [[">
  <div class="btn" id="btn"
       onclick="doClick()"
       onmouseenter="hov(this,1)" onmouseleave="hov(this,0)">REROLL</div>
  <div class="count"><span id="left">0</span> REROLL RESTANT</div>
</div>
<script>
var _enabled = true;
var _mode = 'reroll'; // reroll | skip | wait
function doClick() {
  if (!_enabled) return;
  try { gmod.doClick(); } catch(e) {}
}
function applyLabel() {
  var btn = document.getElementById('btn');
  if (!btn) return;
  if (_mode === 'wait') btn.textContent = '...';
  else if (_mode === 'skip') btn.textContent = 'SKIP';
  else btn.textContent = 'REROLL';
}
function setSpinning(s) {
  if (_mode === 'wait') return; // attente serveur prioritaire
  _mode = s ? 'skip' : 'reroll';
  applyLabel();
}
function setWaiting(w) {
  _mode = w ? 'wait' : 'reroll';
  applyLabel();
}
function setEnabled(b) {
  _enabled = b;
  var btn = document.getElementById('btn');
  if (b) btn.classList.remove('disabled');
  else   btn.classList.add('disabled');
}
function setLeft(n) {
  document.getElementById('left').textContent = n;
}
function hov(el, on) {
  if (_enabled) { if (on) el.classList.add('hover'); else el.classList.remove('hover'); }
}
function clearAllHover() {
  var els = document.querySelectorAll('.btn');
  for (var i = 0; i < els.length; i++) els[i].classList.remove('hover');
}
function forceHoverAt(x, y) {
  if (!_enabled) return;
  var z = window.__zoom || 1; x = x / z; y = y / z;
  clearAllHover();
  var el = document.elementFromPoint(x, y);
  while (el) {
    if (el.classList && el.classList.contains('btn')) { el.classList.add('hover'); return; }
    el = el.parentElement;
  }
}
</script>
</body></html>
]]
	self.btn_reroll:SetHTML(rerollBtnHtml)
	ApplyDHTMLScale(self.btn_reroll)

	self.btn_reroll:AddFunction("gmod", "doClick", function()
		if not IsValid(self.btn_reroll) or not self.btn_reroll:IsEnabled() then return end
		-- Verrouille tant que le serveur n'a pas repondu (result ou denied).
		if self.isWaitingResult then return end
		local stockKey = LZY_RerollStockKey(self.current_category or "")
		local left = stockKey and LocalPlayer():GetEvoNWInt(stockKey, 0) or 0
		if left <= 0 and not self.isSpinning then
			-- Le NWInt dit 0, mais il n'est PAS autoritatif : un credit livre par un
			-- AUTRE serveur (achat site) ne met a jour que la BASE, jamais ce compteur
			-- local. Rediriger vers la boutique sur cette seule valeur enverrait un
			-- joueur RACHETER des rerolls qu'il possede deja (le bug "il faut retry").
			-- On demande donc au serveur de resynchroniser depuis la base, puis on
			-- re-lit : si le vrai stock est > 0, on lance le reroll demande ; sinon
			-- seulement, on redirige vers la boutique.
			net.Start("lzy_reroll_resync")
			net.SendToServer()
			-- IMPORTANT : on NE ferme PAS le reroll (DHTML) et on n'ouvre PAS la
			-- boutique (DHTML) DEPUIS ce callback AddFunction. On est en plein dans
			-- le message pump JS du navigateur de ce bouton : detruire/recreer un
			-- DHTML ici fait CRASHER le client GMod (crash moteur, pas erreur Lua).
			-- Le differe (ici 0.4s, le temps de l'aller-retour SELECT) regle aussi ca.
			timer.Simple(0.4, function()
				if not IsValid(self) then return end
				if self.isWaitingResult or self.isSpinning then return end
				local fresh = stockKey and LocalPlayer():GetEvoNWInt(stockKey, 0) or 0
				if fresh > 0 then
					-- Le stock etait la (credit d'un autre serveur) : on honore le clic.
					self.reroll_left = fresh
					if IsValid(self.btn_reroll) then
						if self._lastRerollState then self._lastRerollState.left = fresh end
						self.btn_reroll:RunJavascript("if(typeof setLeft==='function')setLeft(" .. tostring(fresh) .. ")")
					end
					self:RequestReroll()
					return
				end
				if MUGEN and MUGEN.Notify then
					MUGEN.Notify("Plus de rerolls : ouverture de la boutique.", NOTIFY_HINT, 4)
				end
				if IsValid(self) then self:Close() end
				if LZY_Shop_OpenRerollTab then
					-- Directement la BONNE page d'achat (demande user 2026-07-16) : la clé de
					-- stock "rerolls_<cat>" donne la catégorie boutique (art_spirituel /
					-- combat_style / style_execution / aura_spirituel). Avant : écran de
					-- sélection -> mauvais reroll mis en avant.
					local shopCat = stockKey and stockKey:gsub("^rerolls_", "") or nil
					LZY_Shop_OpenRerollTab(shopCat)
				elseif OpenShop then
					OpenShop("LZY:Shop:Reroll")
				end
			end)
			return
		end
		self:RequestReroll()
	end)

	-- Think watcher : sync spinning + enabled + reroll_left vers le DHTML
	self._lastRerollState = { spinning = nil, enabled = nil, waiting = nil, left = nil }
	-- Quand le document HTML finit de charger, on invalide la cache pour forcer
	-- un re-sync au prochain Think (sinon les premiers appels Think sont silently
	-- ignores par le guard typeof car le <script> n'est pas encore parse).
	self.btn_reroll.OnFinishLoadingDocument = function(selff)
		ApplyDHTMLScale(selff) -- garantit le zoom CSS responsive
		self._lastRerollState = { spinning = nil, enabled = nil, waiting = nil, left = nil }
	end
	self.btn_reroll.Think = function(htmlSelf)
		local waiting = self.isWaitingResult and true or false
		-- Confirmation GARDER / REMPLACER en attente : bouton grise, mais PAS le label
		-- "..." (on n'attend pas le serveur, on attend le joueur). PENDANT le spin le
		-- bouton n'est PAS un bouton de tirage mais un SKIP (RequestReroll part sur
		-- SkipAnimation et ne redescend jamais dans DoReroll) : le griser la priverait
		-- le joueur d'avancer la roue, et pour rien — la confirmation n'est meme pas
		-- encore a l'ecran. Le verrou ne mord donc qu'a partir de la revelation, ce qui
		-- couvre bien la cutscene puis la popup.
		local locked = self:IsDecisionLocked() and not self.isSpinning
		-- SKIP uniquement pendant le vrai spin (apres reponse serveur). Pendant
		-- l'attente, le label est "..." via setWaiting.
		local s = (not waiting and self.isSpinning) and true or false
		-- Etat cliquable PILOTE ici, et plus seulement force a false. `waiting` etait
		-- toujours releve par quelqu'un (CancelWaitingForRoll, reception du resultat),
		-- mais RIEN ne repasse derriere le verrou de confirmation : tous les
		-- SetEnabled(true) du fichier partent AVANT la reponse du joueur (fin de spin,
		-- revelation), donc le bouton restait mort apres un GARDER. Ces deux drapeaux
		-- sont les seules raisons de griser ce bouton : ce Think peut en decider seul,
		-- et l'etat se repare de lui-meme quel que soit le chemin emprunte.
		local e = not waiting and not locked
		if htmlSelf:IsEnabled() ~= e then
			htmlSelf:SetEnabled(e)
		end
		-- Rafraichit le compteur depuis le NWInt EN DEHORS d'un spin : un credit peut
		-- arriver pendant que le menu est ouvert (livraison evo_stripe, resync). Sans
		-- ca l'affichage restait fige sur le champ mis en cache a l'ouverture.
		-- PENDANT un spin / attente on garde la valeur locale (autoritaire apres result,
		-- ou figee pendant wait ; le NW peut etre une frame en retard).
		if not self.isSpinning and not waiting then
			self:RefreshRerollLeftFromNW()
		end
		local l = self.reroll_left or 0
		if waiting ~= self._lastRerollState.waiting then
			self._lastRerollState.waiting = waiting
			htmlSelf:RunJavascript("if(typeof setWaiting==='function')setWaiting(" .. tostring(waiting) .. ")")
			-- En sortant de l'attente, resync le label SKIP/REROLL.
			if not waiting then
				self._lastRerollState.spinning = nil
			end
		end
		if s ~= self._lastRerollState.spinning then
			self._lastRerollState.spinning = s
			htmlSelf:RunJavascript("if(typeof setSpinning==='function')setSpinning(" .. tostring(s) .. ")")
		end
		if e ~= self._lastRerollState.enabled then
			self._lastRerollState.enabled = e
			htmlSelf:RunJavascript("if(typeof setEnabled==='function')setEnabled(" .. tostring(e) .. ")")
		end
		if l ~= self._lastRerollState.left then
			self._lastRerollState.left = l
			htmlSelf:RunJavascript("if(typeof setLeft==='function')setLeft(" .. tostring(l) .. ")")
		end
	end

	self.btn_reroll.OnCursorExited = function(htmlSelf) htmlSelf:RunJavascript("clearAllHover()") end
	self.btn_reroll.OnCursorEntered = function(htmlSelf)
		local mx, my = htmlSelf:CursorPos()
		htmlSelf:RunJavascript(string.format("forceHoverAt(%d, %d)", mx, my))
	end

	-- Init enabled state (sync ensuite via Think)
	self.btn_reroll:SetEnabled(true) -- toujours cliquable : a 0 reroll le clic redirige vers la boutique

	-- ════════════════════════════════════════════════════════════════════════
	-- BARRE LOOT + ? — DHTML (remplace btn_loot + btn_question materials).
	-- Container 252x45 a la position centree, contient un bouton "LOOT" (197x45)
	-- + un bouton "?" (45x45), separes de 10px. Hover JS-managed comme les tabs.
	-- ════════════════════════════════════════════════════════════════════════
	self.lootBarHtml = vgui.Create("DHTML", self)
	self.lootBarHtml:gSetSize(252, 45)
	self.lootBarHtml:gSetPos(math.floor((self.panelWidth - 252) / 2), 770)
	self.lootBarHtml:SetScrollbars(false)
	self.lootBarHtml:SetAllowLua(false)

	local lootHtml = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; }
html, body {
  width: 100%; height: 100%; overflow: hidden; background: transparent; cursor: default;
  font-family: 'Bebas Neue', 'Arial Black', sans-serif;
}
.row { display: flex; height: 100%; gap: 10px; padding: 1px 0; }
.btn {
  position: relative;
  height: 100%;
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(180deg, rgba(22, 25, 38, 0.85) 0%, rgba(12, 14, 22, 0.95) 100%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 6px;
  cursor: pointer;
  overflow: hidden;
  color: rgba(195, 200, 220, 0.85);
  transition: color 0.2s ease, border-color 0.2s ease, transform 0.15s ease, box-shadow 0.25s ease;
}
/* Liseré accent en haut, animé sur hover */
.btn::before {
  content: '';
  position: absolute; top: 0; left: 14%; right: 14%; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(180, 210, 255, 0.0), transparent);
  transition: background 0.25s ease;
  pointer-events: none;
}
/* Underline accent en bas, qui apparait sur hover */
.btn::after {
  content: '';
  position: absolute; bottom: 0; left: 50%; width: 0; height: 2px;
  background: linear-gradient(90deg, transparent, rgba(180, 210, 255, 0.95), transparent);
  transform: translateX(-50%);
  transition: width 0.25s ease;
  pointer-events: none;
}

.btn.loot { flex: 1; font-size: 22px; font-weight: 700; letter-spacing: 0.28em; }
.btn.help { width: 38px; font-size: 22px; font-weight: 700; }

.btn.hover {
  color: #ffffff;
  border-color: rgba(180, 210, 255, 0.55);
  box-shadow:
    0 0 16px rgba(120, 170, 255, 0.25),
    inset 0 0 14px rgba(120, 170, 255, 0.08);
  transform: translateY(-1px);
}
.btn.hover::before {
  background: linear-gradient(90deg, transparent, rgba(180, 210, 255, 0.7), transparent);
}
.btn.hover::after { width: 72%; }

.btn.pressed {
  transform: translateY(0px) scale(0.985);
  box-shadow:
    0 0 8px rgba(120, 170, 255, 0.18),
    inset 0 0 18px rgba(0, 0, 0, 0.35);
}
</style></head><body>
<div class="row">
  <div class="btn loot" onclick="pick('loot')"
       onmouseenter="hov(this,1)" onmouseleave="hov(this,0)"
       onmousedown="press(this,1)" onmouseup="press(this,0)">LOOT</div>
  <div class="btn help" onclick="pick('help')"
       onmouseenter="hov(this,1)" onmouseleave="hov(this,0)"
       onmousedown="press(this,1)" onmouseup="press(this,0)">?</div>
</div>
<script>
function pick(w) {
  try { gmod[w === 'loot' ? 'openLoot' : 'openHelp'](); } catch(e) {}
}
function hov(el, on) {
  if (on) {
    // Defensive : clear hover sur tous les autres boutons d'abord pour
    // eviter qu'une race mouseleave/mouseenter laisse deux .btn en .hover
    // en meme temps (loot + help highlights simultanes).
    var els = document.querySelectorAll('.btn');
    for (var i = 0; i < els.length; i++) {
      if (els[i] !== el) {
        els[i].classList.remove('hover');
        els[i].classList.remove('pressed');
      }
    }
    el.classList.add('hover');
  } else {
    el.classList.remove('hover');
    el.classList.remove('pressed');
  }
}
function press(el, on) {
  if (on) el.classList.add('pressed');
  else    el.classList.remove('pressed');
}
function clearAllHover() {
  var els = document.querySelectorAll('.btn');
  for (var i = 0; i < els.length; i++) {
    els[i].classList.remove('hover');
    els[i].classList.remove('pressed');
  }
}
function forceHoverAt(x, y) {
  var z = window.__zoom || 1; x = x / z; y = y / z;
  clearAllHover();
  var el = document.elementFromPoint(x, y);
  while (el) {
    if (el.classList && el.classList.contains('btn')) { el.classList.add('hover'); return; }
    el = el.parentElement;
  }
}
</script>
</body></html>
]]
	self.lootBarHtml:SetHTML(lootHtml)
	ApplyDHTMLScale(self.lootBarHtml)
	self.lootBarHtml.OnFinishLoadingDocument = function(selff) ApplyDHTMLScale(selff) end
	self.lootBarHtml:AddFunction("gmod", "openLoot", function() self:OpenLootList() end)
	self.lootBarHtml:AddFunction("gmod", "openHelp", function() self:OpenRaritiesList() end)
	self.lootBarHtml.OnCursorExited = function(htmlSelf) htmlSelf:RunJavascript("clearAllHover()") end
	self.lootBarHtml.OnCursorEntered = function(htmlSelf)
		local mx, my = htmlSelf:CursorPos()
		htmlSelf:RunJavascript(string.format("forceHoverAt(%d, %d)", mx, my))
	end

	-- ════════════════════════════════════════════════════════════════════════
	-- ITEM POSSEDE (equiped slot) — DHTML qui remplace materials.equiped_slot
	-- + draw du label "Item possede" + draw de l'icone equipee.
	-- PaintManual() depuis PANEL:Paint a l'endroit exact dans le paint flow.
	-- L'icone change selon la categorie active : Think watcher qui detecte
	-- les changements de win id equipe et push setIcon(path) au JS.
	-- ════════════════════════════════════════════════════════════════════════
	-- Sous loot bar (loot a y=770-815). Container 320x260 a y=820 -> finit y=1080.
	-- Slot aggrandi a 240 (visible vu que le container offre 260 de hauteur).
	local equipedSlotsX = math.floor((self.panelWidth - 320) / 2)
	local equipedSlotsY = math.floor((self.panelHeight - 150) / 2) + 355
	self.equipedHtml = vgui.Create("DHTML", self)
	self.equipedHtml:gSetSize(320, 260)
	self.equipedHtml:gSetPos(equipedSlotsX, equipedSlotsY)
	self.equipedHtml:SetScrollbars(false)
	self.equipedHtml:SetAllowLua(false)
	self.equipedHtml:SetMouseInputEnabled(false)
	self.equipedHtml:SetPaintedManually(true)

	local equipedHtmlContent = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; pointer-events: none; }
html, body {
  width: 100%; height: 100%; overflow: hidden; background: transparent;
  font-family: 'Bebas Neue', 'Arial Black', sans-serif;
  display: flex; flex-direction: column; align-items: center;
}
.slot {
  width: 180px; height: 180px;
  position: relative;
  /* Background dark avec une legere teinte rarete diffusee depuis le haut */
  background:
    linear-gradient(180deg, var(--tint, transparent) 0%, transparent 60%),
    linear-gradient(180deg, rgba(20, 22, 32, 0.95) 0%, rgba(10, 12, 18, 0.98) 100%);
  border: 1.5px solid var(--bc, rgba(210, 210, 220, 0.7));
  border-radius: 14px;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08),
              inset 0 0 24px rgba(0, 0, 0, 0.5);
  transition: border-color 0.25s ease, background 0.25s ease;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
}
/* Fine ligne de brillance au-dessus interne (effet carte premium) */
.slot::before {
  content: '';
  position: absolute; top: 0; left: 10%; right: 10%; height: 1px;
  background: linear-gradient(90deg, transparent, var(--bc, rgba(255,255,255,0.5)), transparent);
  opacity: 0.7;
  pointer-events: none;
}
/* Couleurs raretes : juste border + tint subtil en haut. Aucun glow externe. */
.slot.r-commun    { --bc: rgba(210, 210, 220, 0.7); --tint: rgba(210, 210, 220, 0.06); }
.slot.r-rare      { --bc: rgba( 80, 160, 255, 0.85); --tint: rgba( 80, 160, 255, 0.10); }
.slot.r-epique    { --bc: rgba(190,  90, 255, 0.85); --tint: rgba(190,  90, 255, 0.10); }
.slot.r-legendary { --bc: rgba(255, 215,   0, 0.9);  --tint: rgba(255, 215,   0, 0.13); }
.slot.r-mythique  { --bc: rgba(255,  60,  60, 0.9);  --tint: rgba(255,  60,  60, 0.13); }
.slot.r-secret    { --bc: rgba(255,  60, 200, 0.9);  --tint: rgba(255,  60, 200, 0.13); }
.icon-wrap {
  width: 130px; height: 130px;
  display: flex; align-items: center; justify-content: center;
}
.icon { max-width: 100%; max-height: 100%; object-fit: contain; opacity: 0; transition: opacity 0.25s ease; }
.icon.has { opacity: 1; }
/* Style de combat : ses icônes ne sont pas carrées -> "contain" les letterbox (plus petites
   que les autres catégories). On REMPLIT le carré (cover) pour une taille visible identique. */
body.cat-style_de_combat .icon { width: 100%; height: 100%; max-width: 100%; max-height: 100%; object-fit: cover; }

.label {
  margin-top: 6px;
  font-size: 14px; font-weight: 700; letter-spacing: 0.22em;
  color: rgba(190, 200, 220, 0.7);
  text-transform: uppercase;
}
.name {
  margin-top: 3px;
  font-size: 22px; font-weight: 700; letter-spacing: 0.05em;
  color: rgba(240, 242, 248, 0.96);
  text-transform: uppercase; text-align: center;
}
</style></head><body>
<div class="slot" id="slot">
  <div class="icon-wrap"><img class="icon" id="icon" alt=""></div>
</div>
<div class="label">Item poss&eacute;d&eacute;</div>
<div class="name" id="name"></div>
<script>
function setIcon(path) {
  var img = document.getElementById('icon');
  if (path && path.length > 0) {
    img.src = 'asset://garrysmod/materials/' + path;
    img.classList.add('has');
  } else {
    img.classList.remove('has');
    img.removeAttribute('src');
  }
}
function setRarity(r) {
  var slot = document.getElementById('slot');
  slot.classList.remove('r-commun','r-rare','r-epique','r-legendary','r-mythique','r-secret');
  if (r && r.length > 0) slot.classList.add('r-' + r);
}
function setName(t) {
  var el = document.getElementById('name');
  if (el) el.textContent = t || '';
}
function setCat(c) {
  document.body.className = c ? ('cat-' + c) : '';
}
</script>
</body></html>
]]
	self.equipedHtml:SetHTML(equipedHtmlContent)
	ApplyDHTMLScale(self.equipedHtml)

	-- Think watcher : pousse l'icone + rarete equipees au DHTML quand elles
	-- changent (selon la categorie active + le win id equipe). Cheap : diff par frame.
	self._lastEquippedIconPath = nil
	self._lastEquippedRarity   = nil
	self._lastEquippedName     = nil
	self._lastEquippedCat      = nil
	-- Invalide la cache au chargement du doc pour forcer le re-sync
	self.equipedHtml.OnFinishLoadingDocument = function(selff)
		ApplyDHTMLScale(selff) -- garantit le zoom CSS responsive
		self._lastEquippedIconPath = nil
		self._lastEquippedRarity   = nil
		self._lastEquippedName     = nil
	end
	self.equipedHtml.Think = function(htmlSelf)
		local eqWinId = ""
		if self.current_category == "art_spirituel" then eqWinId = self.art_spirituel or ""
		elseif self.current_category == "style_de_combat" then eqWinId = self.style_combat or ""
		elseif self.current_category == "style_execution" then eqWinId = self.style_execution or ""
		elseif self.current_category == "reiatsu_color" then eqWinId = self.reiatsu_color or ""
		elseif self.current_category == "catalyseur" then eqWinId = self.catalyseur or ""
		end
		local iconPath, rarity, name = "", "", ""
		if eqWinId ~= "" then
			local eqDrop = GetDropByWinId(eqWinId, self.faction, self.current_category)
			if eqDrop then
				if eqDrop.icon then iconPath = eqDrop.icon end
				if eqDrop.rarity then rarity = eqDrop.rarity end
				-- Nom affiche sous le slot equipe : pour l'art spirituel, le nom FR du
				-- pouvoir (Petales, ...) ; sinon le nom de l'item. (Avant : aucun nom.)
				name = (self.current_category == "art_spirituel") and GetArtPowerNameFR(eqDrop) or (eqDrop.name or "")
			end
		end
		if iconPath ~= self._lastEquippedIconPath then
			self._lastEquippedIconPath = iconPath
			-- Echappe les guillemets simples au cas ou (paths normalement safe)
			local safe = iconPath:gsub("'", "")
			htmlSelf:RunJavascript("if(typeof setIcon==='function')setIcon('" .. safe .. "')")
		end
		if rarity ~= self._lastEquippedRarity then
			self._lastEquippedRarity = rarity
			local safeR = rarity:gsub("'", "")
			htmlSelf:RunJavascript("if(typeof setRarity==='function')setRarity('" .. safeR .. "')")
		end
		if name ~= self._lastEquippedName then
			self._lastEquippedName = name
			local safeN = name:gsub("'", "")
			htmlSelf:RunJavascript("if(typeof setName==='function')setName('" .. safeN .. "')")
		end
		-- Pousse la catégorie active comme classe body -> CSS spécifique (ex. style de combat
		-- remplit le carré au lieu d'être letterboxé) pour une taille d'icône identique partout.
		local cat = self.current_category or ""
		if cat ~= self._lastEquippedCat then
			self._lastEquippedCat = cat
			htmlSelf:RunJavascript("if(typeof setCat==='function')setCat('" .. cat:gsub("'", "") .. "')")
		end
	end

	-- Hover zone over pity text (LZYCustomTooltip reads strTooltipText)
	self.pity_hit = vgui.Create("DPanel", self)
	self.pity_hit:SetMouseInputEnabled(true)
	self.pity_hit.Paint = function() end
	local pityHelp = GetPityHelpTooltipText()
	self.pity_hit:SetTooltip(pityHelp)
	self.pity_hit.strTooltipText = pityHelp
	self.pity_hit:SetTooltipPanelOverride("LZYCustomTooltip")
	self:UpdatePityHitLayout()

	self.premium_badge = vgui.Create("DPanel", self)
	self.premium_badge:SetMouseInputEnabled(true)
	self.premium_badge:SetZPos(20)
	self.premium_badge.Paint = function(s, w, h)
		local p = LocalPlayer()
		if not IsValid(p) then return end
		local isPremium = p:GetEvoNWInt("premium", 0) ~= 0
		local mat = isPremium and materials.premium_on or materials.premium_off
		if not mat or mat:IsError() then return end
		RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), mat)
	end
	local premHelp = GetPremiumRerollTooltipText()
	self.premium_badge:SetTooltip(premHelp)
	self.premium_badge.strTooltipText = premHelp
	self.premium_badge:SetTooltipPanelOverride("LZYCustomTooltip")

	self.platinum_badge = vgui.Create("DPanel", self)
	self.platinum_badge:SetMouseInputEnabled(true)
	self.platinum_badge:SetZPos(20)
	self.platinum_badge.Paint = function(s, w, h)
		local p = LocalPlayer()
		if not IsValid(p) then return end
		local active = p:GetEvoNWInt("premium", 0) == 3
		local col = active and Color(255, 80, 80) or Color(110, 114, 124)
		draw.RoundedBox(4, 0, 0, w, h, Color(14, 14, 17, 235))
		surface.SetDrawColor(col.r, col.g, col.b, s:IsHovered() and 255 or 180)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		-- Embleme diamant dessine a l'echelle du panel, sans asset externe.
		local cx, cy, radius = h * 0.6, h / 2, h * 0.28
		draw.NoTexture()
		surface.DrawPoly({
			{ x = cx, y = cy - radius }, { x = cx + radius, y = cy },
			{ x = cx, y = cy + radius }, { x = cx - radius, y = cy },
		})
		draw.SimpleText("PLATINUM", "LZY_RerollProtect", h * 1.15, cy,
			col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.RoundedBox(h * 0.08, w - h * 0.5, cy - h * 0.08,
			h * 0.16, h * 0.16, col)
	end
	local platinumHelp = GetPlatinumPityTooltipText()
	self.platinum_badge:SetTooltip(platinumHelp)
	self.platinum_badge.strTooltipText = platinumHelp
	self.platinum_badge:SetTooltipPanelOverride("LZYCustomTooltip")

	-- Sélecteur « DEMANDER DÈS » (PREMIUM SEULEMENT) : LISTE DÉROULANTE (demande
	-- COMMUN / RARE (défaut) / ÉPIQUE / LÉGENDAIRE / MYTHIQUE / SECRET (si disponible).
	-- Écrit la
	-- convar USERINFO lzy_reroll_protect_floor, lue côté serveur au moment du tirage.
	-- Sans grade payant il n'y a aucune protection à régler : le sélecteur est masqué
	-- (cf. son Think) et le serveur ignore la convar.
	local floorPool = self.currentPool
	local availableFloors = GetAvailableProtectFloors(floorPool)
	local function curFloor()
		local tier = cvProtectFloor:GetInt()
		for _, f in ipairs(availableFloors) do
			if f.tier == tier then return f end
		end
		return PROTECT_FLOORS[2] -- valeur inconnue -> RARE (défaut)
	end
	local function closeFloorList(pnl)
		if IsValid(pnl.rare_protect_list) then pnl.rare_protect_list:Remove() end
		pnl.rare_protect_list = nil
	end
	self.rare_protect_btn = vgui.Create("DButton", self)
	self.rare_protect_btn:SetText("")
	self.rare_protect_btn:SetZPos(20)
	self.rare_protect_btn.Paint = function(s, w, h)
		local f = curFloor()
		local bOpen = IsValid(self.rare_protect_list)
		draw.RoundedBox(6, 0, 0, w, h, Color(14, 14, 17, 235))
		surface.SetDrawColor(f.col.r, f.col.g, f.col.b, (s:IsHovered() or bOpen) and 255 or 170)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText("DEMANDER DÈS :", "LZY_RerollProtect", 12, h / 2,
			Color(150, 154, 162), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(f.label, "LZY_RerollProtect", w - 38, h / 2,
			f.col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		-- Flèche DESSINÉE (triangle) : le glyphe ▼/▲ rendait mal en Bebas (demande
		-- user 2026-07-26 « le tiret ... nickel »). Winding horaire obligatoire.
		local ax, ay = w - 20, h / 2
		surface.SetDrawColor(150, 154, 162, 255)
		draw.NoTexture()
		if bOpen then
			surface.DrawPoly({ { x = ax, y = ay - 4 }, { x = ax + 5, y = ay + 3 }, { x = ax - 5, y = ay + 3 } })
		else
			surface.DrawPoly({ { x = ax - 5, y = ay - 3 }, { x = ax + 5, y = ay - 3 }, { x = ax, y = ay + 4 } })
		end
	end
	self.rare_protect_btn.DoClick = function(btn)
		if IsValid(self.rare_protect_list) then closeFloorList(self) return end
		local floors = availableFloors
		-- Liste dépliée SOUS le bouton (coords écran réelles -> pas de re-scale glibs).
		local bx, by = btn:GetPos()
		local bw, bh = btn:GetSize()
		local rowH = bh
		local list = vgui.Create("DPanel", self)
		self.rare_protect_list = list
		list:SetZPos(30)
		list:SetPos(bx, by + bh + 2)
		list:SetSize(bw, #floors * rowH)
		list.Paint = function(_, w, h)
			draw.RoundedBox(6, 0, 0, w, h, Color(14, 14, 17, 250))
			surface.SetDrawColor(90, 93, 102, 255)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
			-- Fins séparateurs entre les options (rendu « nickel », demande user).
			surface.SetDrawColor(255, 255, 255, 14)
			for i = 1, #floors - 1 do
				surface.DrawRect(8, i * rowH, w - 16, 1)
			end
		end
		for i, f in ipairs(floors) do
			local row = vgui.Create("DButton", list)
			row:SetText("")
			row:SetPos(0, (i - 1) * rowH)
			row:SetSize(bw, rowH)
			row.Paint = function(s, w, h)
				if s:IsHovered() then draw.RoundedBox(4, 2, 2, w - 4, h - 4, Color(38, 38, 46, 255)) end
				local bCur = curFloor().tier == f.tier
				draw.SimpleText(f.label, "LZY_RerollProtect", 12, h / 2, f.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if bCur then
					draw.SimpleText("✔", "LZY_RerollProtect", w - 12, h / 2, f.col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			row.DoClick = function()
				cvProtectFloor:SetInt(f.tier)
				closeFloorList(self)
			end
		end
	end
	-- Visible UNIQUEMENT pour les premium (le sélecteur n'a de sens qu'avec le perk).
	self.rare_protect_btn.Think = function(s)
		if floorPool ~= self.currentPool then
			floorPool = self.currentPool
			availableFloors = GetAvailableProtectFloors(floorPool)
			closeFloorList(self)
		end
		-- Un seuil SECRET sauvegarde devient MYTHIQUE dans un pool sans secret.
		if cvProtectFloor:GetInt() == 6 and #availableFloors == 5 then
			cvProtectFloor:SetInt(5)
		end
		local p = LocalPlayer()
		local bVis = IsValid(p) and p:GetEvoNWInt("premium", 0) ~= 0
		if s:IsVisible() ~= bVis then s:SetVisible(bVis) end
		if not bVis and IsValid(self.rare_protect_list) then closeFloorList(self) end
	end
	local rareHelp = "DEMANDER DÈS — Sécurité Reroll (avantage premium)\n\n" ..
		"Ce réglage choisit à partir de quelle rareté le jeu te DEMANDE ton avis avant de\n" ..
		"remplacer l'objet que tu as équipé.\n" ..
		"En dessous de ce palier, aucune question : le tirage est refusé et tu gardes\n" ..
		"ton objet.\n\n" ..
		"• COMMUN : on te demande dès un tirage commun.\n" ..
		"   Aucun tirage de rareté égale ou inférieure n'est refusé sans te demander.\n" ..
		"• RARE (défaut) : on te demande dès un tirage rare.\n" ..
		"   Un commun ne remplacera jamais ton objet.\n" ..
		"• ÉPIQUE : on te demande dès un tirage épique.\n" ..
		"   Commun et rare sont refusés sans te déranger.\n" ..
		"• LÉGENDAIRE : on te demande dès un tirage légendaire.\n" ..
		"   Tout ce qui est en dessous est refusé sans te déranger.\n\n" ..
		"• MYTHIQUE : on te demande dès un tirage mythique.\n" ..
		"   Tout ce qui est en dessous est refusé sans te déranger.\n" ..
		"• SECRET (si disponible dans ton pool) : on te demande dès un tirage secret.\n" ..
		"   Tout ce qui est en dessous est refusé sans te déranger.\n" ..
		"   Dans un pool sans secret, ce réglage revient à MYTHIQUE.\n\n" ..
		"Dans tous les cas :\n" ..
		"• Un tirage MEILLEUR s'équipe automatiquement, sauf avec Platinum si tu coches\n" ..
		"   « CONFIRMER LES AMÉLIORATIONS » : tu choisis alors OUI / NON, même sous le palier.\n" ..
		"• Un tirage de la MÊME rareté te demande confirmation seulement si cette rareté\n" ..
		"   atteint le palier. En dessous, il est refusé : tu gardes ton objet.\n" ..
		"• Un tirage moins rare que ton objet te demande confirmation seulement s'il\n" ..
		"   atteint le palier. En dessous, il est refusé : tu gardes ton objet."
	self.rare_protect_btn:SetTooltip(rareHelp)
	self.rare_protect_btn.strTooltipText = rareHelp
	self.rare_protect_btn:SetTooltipPanelOverride("LZYCustomTooltip")

	self.confirm_upgrades_check = vgui.Create("DButton", self)
	self.confirm_upgrades_check:SetText("")
	self.confirm_upgrades_check:SetZPos(20)
	self.confirm_upgrades_check:SetVisible(IsValid(LocalPlayer()) and LocalPlayer():GetEvoNWInt("premium", 0) == 3)
	self.confirm_upgrades_check.Paint = function(s, w, h)
		local checked = cvConfirmUpgrades:GetBool()
		local col = checked and Color(230, 190, 70) or Color(150, 154, 162)
		local box = h * 0.5
		local x, y = 8, (h - box) / 2
		draw.RoundedBox(4, 0, 0, w, h, Color(14, 14, 17, 235))
		surface.SetDrawColor(col.r, col.g, col.b, s:IsHovered() and 255 or 180)
		surface.DrawOutlinedRect(x, y, box, box, 1)
		if checked then
			surface.DrawLine(x + box * 0.2, y + box * 0.5, x + box * 0.43, y + box * 0.75)
			surface.DrawLine(x + box * 0.43, y + box * 0.75, x + box * 0.8, y + box * 0.25)
		end
		draw.SimpleText("CONFIRMER LES AMÉLIORATIONS", "LZY_RerollTipSmall", x + box + 10,
			h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	self.confirm_upgrades_check.DoClick = function()
		local p = LocalPlayer()
		if not IsValid(p) or p:GetEvoNWInt("premium", 0) ~= 3 then return end
		cvConfirmUpgrades:SetInt(cvConfirmUpgrades:GetBool() and 0 or 1)
	end
	self.confirm_upgrades_check.Think = function(s)
		local p = LocalPlayer()
		local visible = IsValid(p) and p:GetEvoNWInt("premium", 0) == 3
		if s:IsVisible() ~= visible then s:SetVisible(visible) end
	end
	local upgradeHelp = "Confirmer les améliorations — Platinum uniquement\n\n" ..
		"CASE COCHÉE\n" ..
		"• Si le drop est plus rare que ton objet actuel : tu choisis toujours\n  OUI pour remplacer ou NON pour garder, quel que soit le palier.\n" ..
		"• Si le drop est de même rareté ou moins rare que ton objet actuel :\n  sous « DEMANDER DÈS », tu gardes ton objet sans popup ;\n  dès ce palier, une popup te laisse choisir de remplacer ou de garder.\n" ..
		"• Avec Platinum, refuser une amélioration conserve aussi ta pity.\n\n" ..
		"CASE DÉCOCHÉE\n" ..
		"• Si le drop est plus rare que ton objet actuel : il s'équipe sans popup,\n  même s'il atteint ou dépasse le palier « DEMANDER DÈS ».\n" ..
		"• Uniquement si le drop est de même rareté ou moins rare que ton objet actuel :\n  sous « DEMANDER DÈS », tu gardes ton objet sans popup ;\n  dès ce palier, une popup te laisse choisir de remplacer ou de garder."
	self.confirm_upgrades_check:SetTooltip(upgradeHelp)
	self.confirm_upgrades_check.strTooltipText = upgradeHelp
	self.confirm_upgrades_check:SetTooltipPanelOverride("LZYCustomTooltip")
	self.confirm_upgrades_check:SetTooltipDelay(0)

	self:UpdatePremiumHitLayout()

	-- ════════════════════════════════════════════════════════════════════════
	-- REROLL BG — DHTML stylise qui remplace le material reroll_bg/_blue/_red.
	-- Trick : SetPaintedManually(true) + appel PaintManual() dans PANEL:Paint
	-- au moment exact ou le bg material etait dessine. Permet de garder le
	-- DHTML DERRIERE le slot strip sans refactorer le rendering existant.
	-- ════════════════════════════════════════════════════════════════════════
	-- Hauteur 210 : slots 200 fit avec 5px margin top/bottom. Remontee de 55px
	-- pour liberer la place sous le strip ou se posera le reroll btn.
	local rerollBgX = math.floor((self.panelWidth - 1585) / 2)
	local rerollBgY = math.floor((self.panelHeight - 210) / 2) - 55
	self.reroll_bg_html = vgui.Create("DHTML", self)
	self.reroll_bg_html:gSetSize(1585, 210)
	self.reroll_bg_html:gSetPos(rerollBgX, rerollBgY)
	self.reroll_bg_html:SetScrollbars(false)
	self.reroll_bg_html:SetAllowLua(false)
	self.reroll_bg_html:SetMouseInputEnabled(false)
	self.reroll_bg_html:SetPaintedManually(true) -- on appelle PaintManual() depuis PANEL:Paint

	local bgFactionClass = (self.faction == "Shinigami") and "shinigami" or (self.faction == "Hollow") and "hollow" or ""
	local rerollBgHtmlContent = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; pointer-events: none; }
html, body { width: 100%; height: 100%; overflow: hidden; background: transparent; }
.bg {
  position: absolute; inset: 0;
  border-radius: 14px;
  background: linear-gradient(180deg, rgba(18, 18, 26, 0.92) 0%, rgba(8, 8, 14, 0.96) 100%);
  border: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: inset 0 0 60px rgba(0, 0, 0, 0.6);
  overflow: hidden;
}
/* Themes faction */
.bg.shinigami {
  background: linear-gradient(180deg, rgba(15, 25, 50, 0.92) 0%, rgba(8, 12, 25, 0.96) 100%);
  border-color: rgba(90, 160, 230, 0.4);
}
.bg.hollow {
  background: linear-gradient(180deg, rgba(45, 15, 18, 0.92) 0%, rgba(22, 8, 10, 0.96) 100%);
  border-color: rgba(220, 70, 70, 0.4);
}
/* Stries diagonales tres discretes (statiques, pas d'anim, pas de blur) */
.bg::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    -45deg,
    transparent 0,
    transparent 26px,
    rgba(255, 255, 255, 0.018) 26px,
    rgba(255, 255, 255, 0.018) 28px
  );
  pointer-events: none;
}
/* Highlight haut + bas (lignes lumineuses 1px) */
.bg::after {
  content: '';
  position: absolute; left: 8%; right: 8%; top: 0; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(180, 200, 255, 0.4), transparent);
  box-shadow: 0 206px 0 rgba(180, 200, 255, 0.25); /* mirror en bas */
}
.bg.shinigami::after { background: linear-gradient(90deg, transparent, rgba(120, 190, 255, 0.55), transparent);
                       box-shadow: 0 206px 0 rgba(120, 190, 255, 0.35); }
.bg.hollow::after    { background: linear-gradient(90deg, transparent, rgba(255, 130, 130, 0.55), transparent);
                       box-shadow: 0 206px 0 rgba(255, 130, 130, 0.35); }
/* 4 coins L-markers */
.corner {
  position: absolute; width: 24px; height: 24px;
  border: 2px solid rgba(180, 200, 255, 0.45);
}
.bg.shinigami .corner { border-color: rgba(120, 190, 255, 0.6); }
.bg.hollow .corner    { border-color: rgba(255, 130, 130, 0.6); }
.tl { top: 8px;    left: 8px;    border-right: none; border-bottom: none; }
.tr { top: 8px;    right: 8px;   border-left: none;  border-bottom: none; }
.bl { bottom: 8px; left: 8px;    border-right: none; border-top: none; }
.br { bottom: 8px; right: 8px;   border-left: none;  border-top: none; }
</style></head><body>
<div class="bg ]] .. bgFactionClass .. [[">
  <div class="corner tl"></div><div class="corner tr"></div>
  <div class="corner bl"></div><div class="corner br"></div>
</div>
</body></html>
]]
	self.reroll_bg_html:SetHTML(rerollBgHtmlContent)
	ApplyDHTMLScale(self.reroll_bg_html)
	self.reroll_bg_html.OnFinishLoadingDocument = function(selff) ApplyDHTMLScale(selff) end

	-- ════════════════════════════════════════════════════════════════════════
	-- OVERLAY EFFETS REROLL — DHTML transparent au-dessus du slot strip pour
	-- afficher glow border pulse pendant spin + flash de rarete au landing.
	-- SetMouseInputEnabled(false) pour que les clics sur le strip passent.
	-- ════════════════════════════════════════════════════════════════════════
	self.fx_overlay = vgui.Create("DHTML", self)
	-- Couvre le strip area (centre, 1585x285) avec un peu de padding pour que
	-- le glow border puisse deborder visuellement.
	-- Size align sur le slot strip 1585x210 + 10px padding chaque cote pour que
	-- le glow border puisse deborder visuellement. Position remontee de 55px pour
	-- matcher le nouveau placement du strip bg.
	self.fx_overlay:gSetSize(1605, 230)
	self.fx_overlay:gSetPos(math.floor((self.panelWidth - 1605) / 2), math.floor((self.panelHeight - 230) / 2) - 55)
	self.fx_overlay:SetScrollbars(false)
	self.fx_overlay:SetAllowLua(false)
	self.fx_overlay:SetMouseInputEnabled(false)
	self.fx_overlay:SetZPos(50) -- au-dessus du strip mais en-dessous des popups

	local fxHtml = [[
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
* { margin: 0; padding: 0; box-sizing: border-box; pointer-events: none; }
html, body { width: 100%; height: 100%; overflow: hidden; background: transparent; }

/* ──────────────────────────────────────────────────────────────────────────
   GLOW BORDER : pulse couleur faction pendant le spin.
   ────────────────────────────────────────────────────────────────────────── */
.glow {
  position: absolute; top: 10px; left: 10px; right: 10px; bottom: 10px;
  border-radius: 8px;
  border: 2px solid var(--glow-color);
  opacity: 0.25;
  transition: opacity 0.3s ease;
}
.glow.spinning {
  opacity: 1;
  animation: glow-pulse 0.9s ease-in-out infinite;
}
@keyframes glow-pulse {
  0%, 100% { box-shadow: inset 0 0 20px var(--glow-color), 0 0 14px var(--glow-color);
             border-color: var(--glow-color); }
  50%      { box-shadow: inset 0 0 36px var(--glow-color), 0 0 26px var(--glow-bright);
             border-color: var(--glow-bright); }
}
.glow                  { --glow-color: rgba(180, 200, 255, 0.55); --glow-bright: rgba(220, 230, 255, 0.9); }
.glow.shinigami        { --glow-color: rgba( 90, 180, 255, 0.65); --glow-bright: rgba(160, 220, 255, 0.95); }
.glow.hollow           { --glow-color: rgba(255,  80,  80, 0.65); --glow-bright: rgba(255, 160, 160, 0.95); }

/* ──────────────────────────────────────────────────────────────────────────
   FLASH RARETE : overlay couleur qui peak puis fade out.
   ────────────────────────────────────────────────────────────────────────── */
.flash {
  position: absolute; top: 10px; left: 10px; right: 10px; bottom: 10px;
  border-radius: 8px;
  border: 3px solid transparent;
  opacity: 0;
}
.flash.go { animation: rarity-flash 2.0s cubic-bezier(0.15, 0.85, 0.3, 1) forwards; }
@keyframes rarity-flash {
  0%   { opacity: 0;    transform: scale(0.92); }
  12%  { opacity: 1;    transform: scale(1.02); }
  40%  { opacity: 0.85; transform: scale(1.0);  }
  100% { opacity: 0;    transform: scale(1.06); }
}
.flash.commun    { background: radial-gradient(ellipse at center, rgba(230, 230, 230, 0.85), transparent 80%);
                   box-shadow: inset 0 0 80px rgba(230, 230, 230, 1.0), 0 0 40px rgba(230, 230, 230, 0.9);
                   border-color: rgba(230, 230, 230, 0.95); }
.flash.rare      { background: radial-gradient(ellipse at center, rgba( 66, 133, 244, 0.85), transparent 80%);
                   box-shadow: inset 0 0 80px rgba( 66, 133, 244, 1.0), 0 0 40px rgba( 66, 133, 244, 0.9);
                   border-color: rgba( 66, 133, 244, 0.95); }
.flash.epique    { background: radial-gradient(ellipse at center, rgba(170,  80, 230, 0.85), transparent 80%);
                   box-shadow: inset 0 0 80px rgba(170,  80, 230, 1.0), 0 0 40px rgba(170,  80, 230, 0.9);
                   border-color: rgba(170,  80, 230, 0.95); }
.flash.legendary { background: radial-gradient(ellipse at center, rgba(255, 215,   0, 0.85), transparent 80%);
                   box-shadow: inset 0 0 80px rgba(255, 215,   0, 1.0), 0 0 50px rgba(255, 215,   0, 0.95);
                   border-color: rgba(255, 215,   0, 1.0); }
.flash.mythique  { background: radial-gradient(ellipse at center, rgba(244,  67,  54, 0.9), transparent 80%);
                   box-shadow: inset 0 0 100px rgba(244,  67,  54, 1.0), 0 0 60px rgba(244,  67,  54, 1.0);
                   border-color: rgba(244,  67,  54, 1.0); }
.flash.secret    { background: radial-gradient(ellipse at center, rgba(255,  60, 200, 0.92), transparent 80%);
                   box-shadow: inset 0 0 110px rgba(255,  60, 200, 1.0), 0 0 70px rgba(255,  60, 200, 1.0);
                   border-color: rgba(255,  60, 200, 1.0); }

/* ──────────────────────────────────────────────────────────────────────────
   PARTICLES : 20 etoiles qui jaillissent du centre vers le bord au landing.
   Chaque particle a son angle/delay propre via CSS variable.
   ────────────────────────────────────────────────────────────────────────── */
.particle {
  position: absolute; top: 50%; left: 50%;
  width: 7px; height: 7px;
  background: radial-gradient(circle, var(--p-color, #fff) 0%, var(--p-color-edge, rgba(255,215,0,0.4)) 65%, transparent 100%);
  border-radius: 50%;
  transform: translate(-50%, -50%) scale(0);
  opacity: 0;
  box-shadow: 0 0 6px var(--p-color, #fff);
}
.particle.go {
  animation: particle-burst 1.2s cubic-bezier(0.2, 0.7, 0.3, 1) forwards;
  animation-delay: var(--delay, 0s);
}
@keyframes particle-burst {
  0%   { transform: translate(-50%, -50%) translate(0, 0) scale(0.2); opacity: 0; }
  15%  { transform: translate(-50%, -50%) translate(calc(var(--dx) * 0.15), calc(var(--dy) * 0.15)) scale(1.0); opacity: 0.9; }
  70%  { transform: translate(-50%, -50%) translate(calc(var(--dx) * 0.75), calc(var(--dy) * 0.75)) scale(0.7); opacity: 0.6; }
  100% { transform: translate(-50%, -50%) translate(var(--dx), var(--dy)) scale(0.2); opacity: 0; }
}
</style></head><body>
<div class="glow" id="glow"></div>
<div class="flash" id="flash"></div>
<div id="particles"></div>
<script>
// ────────────────────────────────────────────────────────────────────────────
// SPIN / STOP : active/desactive le glow border.
// ────────────────────────────────────────────────────────────────────────────
function startSpin(faction) {
  var g = document.getElementById('glow');
  g.classList.remove('shinigami', 'hollow');
  if (faction === 'Shinigami') g.classList.add('shinigami');
  else if (faction === 'Hollow') g.classList.add('hollow');
  g.classList.add('spinning');
}
function stopSpin() {
  document.getElementById('glow').classList.remove('spinning');
}

// ────────────────────────────────────────────────────────────────────────────
// FLASH RARETE : reset les classes pour re-trigger l'animation, puis re-applique.
// Pour legendary/mythique : balance aussi le bigwin + particle burst.
// ────────────────────────────────────────────────────────────────────────────
function flashRarity(rarity) {
  var f = document.getElementById('flash');
  f.classList.remove('go', 'commun', 'rare', 'epique', 'legendary', 'mythique', 'secret');
  void f.offsetWidth;
  if (rarity) f.classList.add(rarity);
  f.classList.add('go');

  // Particle burst pour les hautes raretes (sans texte casino-like)
  if (rarity === 'secret' || rarity === 'mythique' || rarity === 'legendary' || rarity === 'epique') {
    burstParticles(rarity);
  }
}

function burstParticles(rarity) {
  var container = document.getElementById('particles');
  container.innerHTML = '';
  var color = '#fff', edge = 'rgba(255,215,0,0.5)';
  if (rarity === 'secret')        { color = '#ff5fc8'; edge = 'rgba(255,60,200,0.5)'; }
  else if (rarity === 'mythique') { color = '#ff7060'; edge = 'rgba(244,67,54,0.5)'; }
  else if (rarity === 'legendary'){ color = '#ffd84a'; edge = 'rgba(255,215,0,0.5)'; }
  else if (rarity === 'epique')   { color = '#c890ff'; edge = 'rgba(170,80,230,0.5)'; }

  // Moins de particules, plus fines : 8 / 12 / 16 selon rarete.
  var count = (rarity === 'secret') ? 20 : (rarity === 'mythique') ? 16 : (rarity === 'legendary' ? 12 : 8);
  for (var i = 0; i < count; i++) {
    var p = document.createElement('div');
    p.className = 'particle';
    var angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
    var dist  = 180 + Math.random() * 100;
    p.style.setProperty('--dx', Math.cos(angle) * dist + 'px');
    p.style.setProperty('--dy', Math.sin(angle) * dist + 'px');
    p.style.setProperty('--p-color', color);
    p.style.setProperty('--p-color-edge', edge);
    p.style.setProperty('--delay', (Math.random() * 0.1) + 's');
    container.appendChild(p);
    setTimeout((function(el){ return function(){ el.classList.add('go'); }; })(p), 10);
  }
  setTimeout(function(){ container.innerHTML = ''; }, 1500);
}
</script>
</body></html>
]]
	self.fx_overlay:SetHTML(fxHtml)
	ApplyDHTMLScale(self.fx_overlay)
	self.fx_overlay.OnFinishLoadingDocument = function(selff) ApplyDHTMLScale(selff) end

	-- Think watcher : sync spinning + consume pending rarity flash
	self._lastSpinSent = false
	self.fx_overlay.Think = function(htmlSelf)
		local s = self.isSpinning and true or false
		if s ~= self._lastSpinSent then
			self._lastSpinSent = s
			if s then
				htmlSelf:RunJavascript("startSpin('" .. tostring(self.faction or "") .. "')")
			else
				htmlSelf:RunJavascript("stopSpin()")
			end
		end
		-- Si une rarete a ete capturee au moment du landing, fire le flash et reset
		if self._pendingFlashRarity then
			local r = self._pendingFlashRarity
			self._pendingFlashRarity = nil
			htmlSelf:RunJavascript("flashRarity('" .. r .. "')")
		end
	end
end

function PANEL:UpdatePityHitLayout()
	if not IsValid(self.pity_hit) then return end
	local w = self.panelWidth or 1920
	self.pity_hit:gSetPos(math.floor(w / 2 - 160), 338)
	self.pity_hit:gSetSize(320, 32)
end

function PANEL:UpdatePremiumHitLayout()
	if not IsValid(self.premium_badge) then return end
	self.premium_badge:gSetPos(1514, 317)
	self.premium_badge:gSetSize(220, 35)
	if IsValid(self.platinum_badge) then
		self.platinum_badge:gSetPos(1282, 317)
		self.platinum_badge:gSetSize(220, 35)
	end
	-- Sélecteur « DEMANDER DÈS » : SOUS l'onglet « Art Spirituel » (1er onglet de la
	-- barre à (177, 149), haute de 43) = à gauche, au-dessus de la zone reroll.
	-- Descendu à y=300 + agrandi 300x40 (fonte Bebas 28) — demandes user 2026-07-26.
	if IsValid(self.rare_protect_btn) then
		self.rare_protect_btn:gSetPos(177, 300)
		self.rare_protect_btn:gSetSize(300, 40)
	end
	if IsValid(self.confirm_upgrades_check) then
		self.confirm_upgrades_check:gSetPos(489, 300)
		self.confirm_upgrades_check:gSetSize(340, 40)
	end
end

function PANEL:PerformLayout()
	self:UpdatePityHitLayout()
	self:UpdatePremiumHitLayout()
end

function PANEL:GetCurrentCategoryPityRolls()
	local parsed = util.JSONToTable(LocalPlayer():GetEvoNWString("LZY_Reroll_Pities", "{}"))
	if istable(parsed) then
		self.pityByCategory = REROLL_CollapsePities(parsed)
	end
	local key = BuildPityKey(self.faction, self.current_category)
	return math.max(0, math.floor(tonumber((self.pityByCategory or {})[key]) or 0))
end

-- ════════════════════════════════════════════════════════════════════════════
-- Calcul des weights ajustes par la pity, cote client. Miroir de la logique
-- serveur (sv_main.lua ApplyPityToRarityWeights). On boost additivement les
-- rarites listees dans REROLL_PITY_BOOST_RARITIES puis on rescale tout pour
-- que la somme reste constante. Affichage utilise ces valeurs en %.
-- ════════════════════════════════════════════════════════════════════════════
function PANEL:GetAdjustedRarityWeights()
	if not REROLL_DROPS_RARITIES then return {} end

	local pityStep  = math.max(1, math.floor(tonumber(REROLL_PITY_STEP_ROLLS) or 10))
	local pityRolls = self:GetCurrentCategoryPityRolls()
	local pityLevel = math.floor(pityRolls / pityStep)

	-- Poids de base PAR CATÉGORIE (override aura, etc.), puis pity via la SOURCE UNIQUE
	-- partagée avec le serveur (REROLL_ComputeAdjustedWeights) -> les % affichés == les
	-- vraies chances de tirage.
	local base = {}
	for key in pairs(REROLL_DROPS_RARITIES) do
		base[key] = REROLL_GetRarityWeight(key, self.current_category)
	end
	return REROLL_ComputeAdjustedWeights(base, pityLevel)
end

function PANEL:RefreshRaritiesList()
	-- Plus de DHTML : on met juste a jour le cache des weights utilise par
	-- rarities_list.Paint (pur Lua, sans Chromium).
	if not self._raritiesRows then return end
	local weights = self:GetAdjustedRarityWeights()
	for i = 1, #self._raritiesRows do
		local r = self._raritiesRows[i]
		local adj  = weights[r.key] or 0
		local base = REROLL_GetRarityWeight(r.key, self.current_category)
		r.weight   = FormatWeight(adj)
		r.base     = FormatWeight(base)
		-- Modifié par la pity : l'ajusté diffère sensiblement de la base -> on affiche base → ajusté.
		r.modified = math.abs(adj - base) > 0.0001
	end
end

-- Recalcule le % de drop des tooltips de la liste de loot à partir des poids AJUSTÉS par la
-- pity (MÊMES poids que le panneau des raretés) -> le hover loot et le panneau raretés restent
-- COHÉRENTS, et se ré-actualisent quand la pity change. % d'un item = poids ajusté de sa rareté
-- / somme des poids ajustés de tous les items du pool.
function PANEL:RefreshLootRates()
	if not self._lootTips then return end
	local adj = self:GetAdjustedRarityWeights()
	-- Le % affiché = taux de la RARETÉ (somme sur les RARETÉS, PAS sur les items) -> "loot" et
	-- "rareté" affichent EXACTEMENT la même valeur pour une rareté donnée (demande user).
	local total = 0
	for _, w in pairs(adj) do total = total + w end
	for i = 1, #self._lootTips do
		local t = self._lootTips[i]
		t.pct = (total > 0) and ((adj[t.rarity_key] or 0) / total * 100) or 0
	end
end

-- Les % affichés (panneau raretés + tooltips de loot) sont calculés à partir de la pity.
-- Ils se rafraîchissent donc sur le changement de l'ÉTAT SERVEUR de la pity, et non à
-- l'arrivée du résultat de tirage : entre les deux, l'écriture en base peut encore
-- échouer et la pity rester à son ancienne valeur. Le texte « Pity N (x/10) » se relit
-- déjà à chaque frame dans Paint.
function PANEL:OnPityStateChanged()
	if IsValid(self.rarities_list) then self:RefreshRaritiesList() end
	if IsValid(self.loot_list) then self:RefreshLootRates() end
end

function PANEL:OpenRaritiesList()
	-- Toggle + anti-orphelin + exclusivité (cf. OpenLootList) : jamais 2 overlays
	-- plein écran empilés, jamais d'overlay orphelin qui capture la souris.
	if IsValid(self.rarities_list) or IsValid(self.rarities_overlay) then
		self:CloseRaritiesList()
		return
	end
	self:CloseLootList()
	-- Create the rarities list panel first (so overlay can reference it)
	-- Container aggrandi 328x361 -> 460x520 pour fit les fontes plus grosses.
	self.rarities_list = vgui.Create("DPanel", self)
	self.rarities_list:gSetSize(460, 520)
	self.rarities_list:gSetPos(math.floor((self.panelWidth - 460) / 2), math.floor((self.panelHeight - 520) / 2))
	self.rarities_list:SetText("")
	self.rarities_list:SetZPos(1000)

	-- Build l'ordre + cache les couleurs/noms (eval dans Paint serait + couteux).
	local order = { "commun", "rare", "epique", "legendary", "mythique", "secret" }
	local rows = {}
	for i = 1, #order do
		local key = order[i]
		-- "secret" ne s'affiche que si le POOL DU JOUEUR contient réellement un drop
		-- secret (remplace l'ancien test par catégorie). currentPool est déjà filtré
		-- par FAMILLE de style : un joueur HAKUDA n'a aucun style secret, la ligne
		-- disparaît donc chez lui (demande user 08/13) tout en restant chez un joueur
		-- katana ; et les catégories sans drop secret (art spirituel...) restent
		-- couvertes. Piloté par les données : un futur hakuda secret la refera
		-- apparaître sans retouche UI.
		local skipSecret = false
		if key == "secret" then
			skipSecret = true
			for _, d in ipairs(self.currentPool or {}) do
				if d.rarity == "secret" then skipSecret = false break end
			end
		end
		local entry = REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[key]
		if entry and not skipSecret then
			rows[#rows + 1] = {
				key   = key,
				color = GetColorForRarityKey(key),
				name  = string.upper(TitleForRarityKey(key)),
			}
		end
	end
	self._raritiesRows = rows
	-- Remplit weight/base/modified avec la pity COURANTE (affiche "base → ajusté" si modifié).
	self:RefreshRaritiesList()

	-- Paint Lua pur : remplace le DHTML enfant (crash Chromium suspecte).
	self.rarities_list.Paint = function(selff, w, h)
		draw.RoundedBox(16, 0, 0, w, h, Color(12, 14, 22, 245))
		surface.SetDrawColor(180, 200, 255, 60)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		-- Titre
		draw.SimpleText("RARETES", "LZY_RerollRarityTip",
			gRespX(32), gRespY(28), Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		surface.SetDrawColor(180, 200, 255, 50)
		surface.DrawRect(gRespX(32), gRespY(74), w - gRespX(64), 1)
		-- Rangees
		local rowsList = self._raritiesRows or {}
		local rowH = gRespY(48)
		local startY = gRespY(96)
		local padX = gRespX(32)
		for i = 1, #rowsList do
			local r = rowsList[i]
			local y = startY + (i - 1) * (rowH + gRespY(8))
			-- BG ligne + accent gauche
			draw.RoundedBox(6, padX, y, w - padX * 2, rowH, Color(255, 255, 255, 8))
			surface.SetDrawColor(r.color.r, r.color.g, r.color.b, 220)
			surface.DrawRect(padX, y, gRespX(4), rowH)
			-- Dot
			local dotR = gRespX(6)
			draw.NoTexture()
			surface.SetDrawColor(r.color.r, r.color.g, r.color.b, 255)
			draw.RoundedBox(dotR, padX + gRespX(16), y + rowH / 2 - dotR, dotR * 2, dotR * 2, r.color)
			-- Nom + weight
			draw.SimpleText(r.name, "LZY_RerollRarityTip",
				padX + gRespX(36), y + rowH / 2, r.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			-- Taux : si la pity l'a modifié, on montre "base → ajusté" (base en gris à gauche).
			local rightX = w - padX - gRespX(8)
			local cyW    = y + rowH / 2
			if r.modified then
				local adjStr = r.weight .. "%"
				draw.SimpleText(adjStr, "LZY_RerollRarityTip", rightX, cyW, r.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				surface.SetFont("LZY_RerollRarityTip")
				local aw = surface.GetTextSize(adjStr)
				draw.SimpleText((r.base or "") .. "%  →  ", "LZY_RerollTipSmall",
					rightX - aw - gRespX(6), cyW, Color(150, 155, 165), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText(r.weight .. "%", "LZY_RerollRarityTip", rightX, cyW, r.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end

		-- Rappel « lié au perso » (demande user 08/21). Ancré en BAS du panneau et pas
		-- sous la dernière ligne : le nombre de raretés varie (secret masqué chez certains).
		local noteY = h - gRespY(84)
		surface.SetDrawColor(180, 200, 255, 35)
		surface.DrawRect(padX, noteY, w - padX * 2, 1)
		draw.SimpleText("LES TIRAGES SONT LIÉS AU PERSONNAGE", "LZY_RerollTipSmall",
			w / 2, noteY + gRespY(14), Color(200, 210, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local tNote = {
			"Art spirituel, style de combat, aura :",
			"impossible de les transférer sur un",
			"autre perso, ex. un Arrancar.",
		}
		for i = 1, #tNote do
			draw.SimpleText(tNote[i], "LZY_RerollTipSmall", w / 2,
				noteY + gRespY(34) + (i - 1) * gRespY(16),
				Color(150, 155, 165), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Plus de DHTML pour les raretes : tout est peint en Lua dans rarities_list.Paint.
	-- raritiesBgHtml laisse a nil pour neutraliser RefreshRaritiesList (cf. plus bas).
	self.raritiesBgHtml = nil

	-- Create overlay panel that will draw blur and darkening
	-- This panel has lower Z position so rarities_list draws on top
	self.rarities_overlay = vgui.Create("DPanel", self)
	self.rarities_overlay:gSetSize(self.panelWidth, self.panelHeight)
	self.rarities_overlay:gSetPos(0, 0)
	self.rarities_overlay:SetZPos(500) -- Lower than rarities_list but higher than other elements
	self.rarities_overlay:SetMouseInputEnabled(true) -- Enable to detect clicks outside rarities list
	self.rarities_overlay.OnMousePressed = function(selff, keyCode)
		if keyCode == MOUSE_LEFT then
			-- Get click position relative to overlay panel
			local mx, my = selff:CursorPos()
			-- Overlay auto-cicatrisant (cf. loot_overlay) : orphelin -> se retire.
				-- Corrige aussi une erreur Lua latente (self.rarities_list nil -> :GetPos()).
				if not IsValid(self.rarities_list) then selff:Remove() return end
				-- Get rarities list position and size (both are children of main panel)
			local raritiesX, raritiesY = self.rarities_list:GetPos()
			local raritiesW, raritiesH = self.rarities_list:GetSize()
			
			-- Check if click is outside rarities list bounds (both use same parent coordinates)
			if mx < raritiesX or mx > raritiesX + raritiesW or my < raritiesY or my > raritiesY + raritiesH then
				self:CloseRaritiesList()
			end
		end
	end
	-- /!\ Le blur via matBlurScreen:Recompute() (12 passes ici, 3 par cote)
	-- crashait l'engine sur certaines GPU/drivers. Remplace par un simple
	-- overlay sombre. Voir aussi loot_overlay pour le meme fix.
	self.rarities_overlay.Paint = function(selff, w, h)
		if not IsValid(self.rarities_list) then return end

		local x, y = selff:LocalToScreen(0, 0)
		local raritiesX, raritiesY = self.rarities_list:GetPos()
		local raritiesW, raritiesH = self.rarities_list:GetSize()
		local raritiesSx, raritiesSy = self:LocalToScreen(raritiesX, raritiesY)

		local wasEnabled = DisableClipping(true)
		surface.SetDrawColor(0, 0, 0, 160)

		if raritiesSy > y then
			surface.DrawRect(x * -1, y * -1, ScrW(), raritiesSy - y)
		end
		if raritiesSy + raritiesH < ScrH() then
			surface.DrawRect(x * -1, raritiesSy + raritiesH, ScrW(), ScrH() - (raritiesSy + raritiesH))
		end
		if raritiesSx > x then
			surface.DrawRect(x * -1, raritiesSy, raritiesSx - x, raritiesH)
		end
		if raritiesSx + raritiesW < ScrW() then
			surface.DrawRect(raritiesSx + raritiesW, raritiesSy, ScrW() - (raritiesSx + raritiesW), raritiesH)
		end

		DisableClipping(wasEnabled)
	end
	
	-- add close button at top right of rarities list (reduit 60->40)
	self.rarities_list_close_btn = vgui.Create("DButton", self.rarities_list)
	self.rarities_list_close_btn:gSetSize(40, 40)
	self.rarities_list_close_btn:gSetPos(460 - 50, 10)
	self.rarities_list_close_btn:SetText("")
	self.rarities_list_close_btn.Paint = function(selff, w, h)
		RNDX.DrawMaterial(0, 0, 0, w, h, selff.hovered and Color(255, 255, 255, 200) or Color(255, 255, 255, 255), materials.close)
	end
	self.rarities_list_close_btn.DoClick = function()
		self:CloseRaritiesList()
	end
end

function PANEL:CloseRaritiesList()
	if IsValid(self.rarities_list) then
		self.rarities_list:Remove()
		self.rarities_list = nil
	end
	if IsValid(self.rarities_overlay) then
		self.rarities_overlay:Remove()
		self.rarities_overlay = nil
	end
end

function PANEL:OpenLootList()
	-- Toggle + anti-orphelin : si une liste loot est déjà ouverte (ou un overlay
	-- resté seul), on la REFERME au lieu d'en empiler une 2e. Empiler créait un
	-- overlay plein écran ORPHELIN (non référencé, mouse-capture) qui bloquait la
	-- souris à vie -> joueur "bloqué dedans, obligé de retry". Pendant un spin le
	-- bouton DHTML LOOT reste cliquable SOUS l'overlay (quirk DHTML), donc le
	-- double-open arrivait très facilement. On garde aussi loot et raretés
	-- MUTUELLEMENT EXCLUSIFS (jamais 2 overlays plein écran en même temps).
	if IsValid(self.loot_list) or IsValid(self.loot_overlay) then
		self:CloseLootList()
		return
	end
	self:CloseRaritiesList()
	-- Create the loot list panel first (so overlay can reference it)
	self.loot_list = vgui.Create("DPanel", self)
	-- Taille de l'UI loot RÉDUITE (avant 585x665 -> beaucoup trop grande à l'écran).
	-- On NE touche PAS aux cases (toujours 95) : la largeur 490 = 4 cases + 3 gaps +
	-- 2x scrollPadding, donc la grille remplit pile la fenêtre (bords égaux) sans
	-- l'excès qui la faisait flotter au centre. Hauteur réduite (665 -> 520) aussi.
	local LOOT_W, LOOT_H = 490, 520
	local x = math.floor((self.panelWidth - LOOT_W) / 2)
	local y = math.floor((self.panelHeight - LOOT_H) / 2)
	self.loot_list:gSetSize(LOOT_W, LOOT_H)
	self.loot_list:gSetPos(x, y)
	self.loot_list:SetText("")
	-- Set high Z position to ensure loot list draws on top of overlay
	self.loot_list:SetZPos(1000)
	self.loot_list.Paint = function(selff, w, h)
		-- BG Lua pur (plus de DHTML : Chromium crashait l'engine sur certaines configs).
		draw.RoundedBox(16, 0, 0, w, h, Color(12, 14, 22, 245))
		surface.SetDrawColor(180, 200, 255, 60)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		-- Titre
		draw.SimpleText("LISTE DE LOOT", "LZY_RerollRarityTip",
			gRespX(32), gRespY(34), Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		surface.SetDrawColor(180, 200, 255, 50)
		surface.DrawRect(gRespX(32), gRespY(72), w - gRespX(64), 1)
		-- Reset le tooltip courant en debut de frame : chaque itemPanel:Paint
		-- qui s'execute apres remettra self._hoveredLootTip s'il est hover.
		self._hoveredLootTip = nil
	end

	-- PaintOver s'execute APRES tous les enfants : on draw le tooltip ici pour
	-- qu'il soit au premier plan, au-dessus de tous les slots voisins.
	self.loot_list.PaintOver = function(selff, w, h)
		local tip = self._hoveredLootTip
		if not tip then return end

		-- 3 lignes : NOM (grand, blanc) / RARETÉ (couleur de rareté) / TAUX de drop %.
		-- Taux avec plus de décimales pour les raretés rares (sinon "0%" sur un secret).
		local pct = tip.pct or 0
		-- Décimales ADAPTATIVES (FormatWeight -> jusqu'à 4 déc.) : un secret ~0.0001% ne doit pas
		-- s'arrondir à "0.000". Affiche "0.0001%" au lieu de "0.000%".
		local pctStr = FormatWeight(pct) .. "%"

		local lines = {
			{ text = (tip.name ~= "" and tip.name) or "?", font = "LZY_RerollRarityTip", col = TIP_TEXT },
			{ text = tip.rarity or "",                      font = "LZY_RerollTipSmall", col = tip.col or TIP_MUTED },
			{ text = "Taux de drop : " .. pctStr,           font = "LZY_RerollTipSmall", col = TIP_MUTED },
		}

		-- Mesure : largeur = ligne la plus large ; hauteur = somme des lignes + interlignes.
		local padX, padY = gRespX(20), gRespY(12)
		local lineGap = gRespY(2)
		local maxW, totH = 0, 0
		for i, ln in ipairs(lines) do
			surface.SetFont(ln.font)
			local lw, lh = surface.GetTextSize(ln.text)
			ln.w, ln.h = lw, lh
			if lw > maxW then maxW = lw end
			totH = totH + lh
			if i < #lines then totH = totH + lineGap end
		end
		local boxW = maxW + padX * 2
		local boxH = totH + padY * 2

		-- Position : suit la souris, clampée dans l'ÉCRAN (pas dans le popup — une
		-- bulle plus large que la fenêtre loot se retrouvait tronquée). On repasse
		-- en coords locales pour dessiner et on coupe le clipping du panel.
		local cx, cy = selff:CursorPos()
		local ox, oy = selff:LocalToScreen(0, 0)
		local sx, sy = ClampTipToScreen(ox + cx, oy + cy, boxW, boxH, gRespY(18))
		local bx, by = sx - ox, sy - oy

		local wasEnabled = DisableClipping(true)
		DrawTooltipFrame(bx, by, boxW, boxH)

		local ty = by + padY
		for _, ln in ipairs(lines) do
			draw.SimpleText(ln.text, ln.font, bx + padX, ty, ln.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			ty = ty + ln.h + lineGap
		end
		DisableClipping(wasEnabled)
	end

	-- BG entierement Lua (cf. self.loot_list.Paint ci-dessus). Plus de DHTML pour
	-- ce bg : on isole le crash Chromium.

	-- Create overlay panel that will draw blur and darkening
	-- This panel has lower Z position so loot_list draws on top
	self.loot_overlay = vgui.Create("DPanel", self)
	self.loot_overlay:gSetSize(self.panelWidth, self.panelHeight)
	self.loot_overlay:gSetPos(0, 0)
	self.loot_overlay:SetZPos(500) -- Lower than loot_list but higher than other elements
	self.loot_overlay:SetMouseInputEnabled(true) -- Enable to detect clicks outside loot list
	self.loot_overlay.OnMousePressed = function(selff, keyCode)
		if keyCode == MOUSE_LEFT then
			-- Overlay auto-cicatrisant : si la liste associée n'existe plus (overlay
			-- devenu orphelin), on se retire NOUS-MÊME au lieu de rester à capturer
			-- la souris indéfiniment. Un seul clic suffit alors à se débloquer.
			if not IsValid(self.loot_list) then selff:Remove() return end
			-- Get click position relative to overlay panel
			local mx, my = selff:CursorPos()
			-- Get loot list position and size (both are children of main panel)
			local lootX, lootY = self.loot_list:GetPos()
			local lootW, lootH = self.loot_list:GetSize()
			
			-- Check if click is outside loot list bounds (both use same parent coordinates)
			if mx < lootX or mx > lootX + lootW or my < lootY or my > lootY + lootH then
				self:CloseLootList()
			end
		end
	end
	-- /!\ Le blur via matBlurScreen:Recompute() + render.UpdateScreenEffectTexture
	-- crashait l'engine sur certaines GPU/drivers (rapports utilisateur : "GMod
	-- se ferme quand je clique sur LOOT"). On le remplace par un simple overlay
	-- sombre 50% qui ne touche pas au pipeline shader => zero risque de crash.
	-- On dessine 4 rectangles autour de la zone loot_list pour garder la zone
	-- centrale visible sans effet de flou.
	self.loot_overlay.Paint = function(selff, w, h)
		if not IsValid(self.loot_list) then return end

		local x, y = selff:LocalToScreen(0, 0)
		local lootX, lootY = self.loot_list:GetPos()
		local lootW, lootH = self.loot_list:GetSize()
		local lootSx, lootSy = self:LocalToScreen(lootX, lootY)

		local wasEnabled = DisableClipping(true)
		surface.SetDrawColor(0, 0, 0, 160) -- overlay sombre simple (sans blur)

		if lootSy > y then
			surface.DrawRect(x * -1, y * -1, ScrW(), lootSy - y)
		end
		if lootSy + lootH < ScrH() then
			surface.DrawRect(x * -1, lootSy + lootH, ScrW(), ScrH() - (lootSy + lootH))
		end
		if lootSx > x then
			surface.DrawRect(x * -1, lootSy, lootSx - x, lootH)
		end
		if lootSx + lootW < ScrW() then
			surface.DrawRect(lootSx + lootW, lootSy, ScrW() - (lootSx + lootW), lootH)
		end

		DisableClipping(wasEnabled)
	end

	-- add close button at top right of loot list
	self.loot_list_close_btn = vgui.Create("DButton", self.loot_list)
	self.loot_list_close_btn:gSetSize(40, 40)
	self.loot_list_close_btn:gSetPos(LOOT_W - 50, 10)
	self.loot_list_close_btn:SetText("")
	self.loot_list_close_btn.Paint = function(selff, w, h)
		RNDX.DrawMaterial(0, 0, 0, w, h, selff.hovered and Color(255, 255, 255, 200) or Color(255, 255, 255, 255), materials.close)
	end
	self.loot_list_close_btn.DoClick = function()
		self:CloseLootList()
	end
	
	-- Create scroll panel for items grid
	local scrollPadding = 37
	local scrollMarginTop = 80
	local scrollPanel = vgui.Create("DScrollPanel", self.loot_list)
	scrollPanel:gSetPos(scrollPadding, scrollMarginTop)
	scrollPanel:gSetSize(LOOT_W - scrollPadding * 2, LOOT_H - scrollMarginTop - scrollPadding)
	scrollPanel.Paint = function() end -- No background

	-- Scrollbar verticale masquee : largeur 0 + paint vide. Le scroll a la
	-- molette reste fonctionnel.
	local vbar = scrollPanel:GetVBar()
	vbar:SetHideButtons(true)
	vbar:SetWide(0)
	vbar.Paint = function() end
	vbar.btnGrip.Paint = function() end
	function vbar:PerformLayout()
		self:SetWide(0)
		self.btnGrip:SetWide(0)
	end
	
	-- Create icon layout for grid
	-- IMPORTANT : on ne dock PAS FILL le DIconLayout — sinon sa hauteur est
	-- forcee a la zone visible du DScrollPanel et la barre de scroll ne se
	-- declenche jamais. On SetWide manuellement (largeur du canvas) et on
	-- laisse le Layout calculer la hauteur en fonction des enfants.
	-- Cases de taille FIXE raisonnable (pas étirées), 4 par ligne, grille CENTRÉE
	-- dans la zone de scroll -> bord gauche = bord droit. (Avant : left-aligned ->
	-- grand vide à droite ; puis fill -> cases trop grosses.) On centre une grille
	-- de largeur exacte (4 colonnes) au lieu d'agrandir les cases.
	local columns = 4
	local slotSize = 95                                                    -- design (gSetSize applique gRespX)
	local spacing = gRespX(12)                                             -- px actuels
	local availW = scrollPanel:GetWide()                                   -- px actuels
	local contentW = columns * gRespX(slotSize) + (columns - 1) * spacing  -- px actuels (4 colonnes)
	local sideOff = math.max(0, math.floor((availW - contentW) / 2))       -- marge égale gauche/droite
	local iconLayout = vgui.Create("DIconLayout", scrollPanel)
	iconLayout:SetPos(sideOff, 0)    -- décalage centré -> bords égaux
	iconLayout:SetSize(contentW, 1)  -- largeur = exactement 4 colonnes -> retour ligne après 4
	iconLayout:SetSpaceX(spacing)
	iconLayout:SetSpaceY(spacing)
	iconLayout:SetBorder(0)
	
	-- Get current category drops — TRIÉS PAR RARETÉ (commun -> secret) pour l'affichage.
	-- Copie LOCALE : on ne touche PAS self.currentPool, qui est l'espace d'index
	-- partagé avec le serveur pour le résultat du reroll (réordonner casserait le
	-- mapping index->drop). La boucle d'affichage n'utilise que les champs de l'item
	-- (icon/rarity/name/...), jamais l'index, donc trier la copie est sans effet de bord.
	-- Tri stable : tiebreak sur le nom pour un ordre déterministe à rareté égale.
	local drops = {}
	local srcPool = self.currentPool or {}
	for i = 1, #srcPool do drops[i] = srcPool[i] end
	table.sort(drops, function(a, b)
		local ra = LZY_REROLL_RARITY_RANK[a.rarity] or 99
		local rb = LZY_REROLL_RARITY_RANK[b.rarity] or 99
		if ra ~= rb then return ra < rb end
		return tostring(a.name or "") < tostring(b.name or "")
	end)

	-- Taux de drop % du tooltip : on collecte les hoverTips, puis RefreshLootRates calcule les %
	-- avec les poids AJUSTÉS par la pity (identique au panneau des raretés) -> hover loot et
	-- raretés COHÉRENTS, et ré-actualisés quand la pity change (cf. RefreshLootRates).
	self._lootTips = {}

	-- Preview reactive : click sur l'oeil ouvre OpenRerollGifPreview (DFrame
	-- 100% Lua, sans DHTML donc sans risque de crash Chromium qu'on avait avant).
	-- Detection click zone-eye via OnMousePressed (pas de sub-panel, evite les
	-- conflits de layout DIconLayout).

	-- Create item panels
	for i = 1, #drops do
		local item = drops[i]
		local itemPanel = vgui.Create("DPanel", iconLayout)
		itemPanel:gSetSize(slotSize, slotSize)
		itemPanel:SetText("")
		-- Input souris activé sur TOUS les slots (pas seulement ceux avec preview gif) :
		-- sinon IsHovered() reste faux et le tooltip nom/rareté/taux ne s'afficherait pas.
		itemPanel:SetMouseInputEnabled(true)

		if item.hover_gif then
			local capturedItem = item
			itemPanel.OnMousePressed = function(selff, keyCode)
				if keyCode ~= MOUSE_LEFT then return end
				local w, _ = selff:GetSize()
				local mx, my = selff:CursorPos()
				local eyeSize = math.max(14, math.floor(w * 0.22))
				local eyePad  = math.max(4, math.floor(w * 0.05))
				local eyeX    = w - eyeSize - eyePad
				local eyeY    = eyePad
				if mx >= eyeX and mx <= eyeX + eyeSize and my >= eyeY and my <= eyeY + eyeSize then
					PlayRerollSound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
					OpenRerollGifPreview(capturedItem)
				end
			end
		end

		-- Cache icon material outside Paint
		local iconMat = item.icon and Material(item.icon, "smooth") or nil

		-- Tooltip hover précalculé : NOM de la récompense + RARETÉ + TAUX de drop %.
		-- (art_spirituel -> nom FR du pouvoir ; sinon item.name.) Couleur de rareté =
		-- celle des bordures de slot (LZY_RerollGetBorder) pour rester cohérent.
		local rarityKey = item.rarity or ""
		local hoverTip = {
			name       = (self.current_category == "art_spirituel") and GetArtPowerNameFR(item) or (item.name or ""),
			rarity     = TitleForRarityKey(rarityKey),
			col        = LZY_RerollGetBorder(rarityKey),
			rarity_key = rarityKey,   -- sert à recalculer le % via RefreshLootRates (poids pity)
			pct        = 0,           -- rempli par RefreshLootRates (appelé en fin de build + au changement de pity)
		}
		self._lootTips[#self._lootTips + 1] = hoverTip

		itemPanel.Paint = function(selff, w, h)
			-- Style des slots : border BRILLANTE par rarete (mythique=rouge /
			-- legendary=jaune / epique=violet / rare=bleu / commun=gris).
			local rarity = item.rarity or ""
			local borderCol
			if rarity == "secret"    then borderCol = Color(255,  60, 200, 255)
			elseif rarity == "mythique"  then borderCol = Color(255,  60,  60, 255)
			elseif rarity == "legendary" then borderCol = Color(255, 215,   0, 255)
			elseif rarity == "epique"    then borderCol = Color(190,  90, 255, 255)
			elseif rarity == "rare"      then borderCol = Color( 80, 160, 255, 255)
			else                              borderCol = Color(210, 210, 220, 220) -- commun
			end
			local haloCol = Color(borderCol.r, borderCol.g, borderCol.b, 60)
			local SLOT_RADIUS = math.max(4, math.floor(gRespX(10)))

			-- Fond dark + highlight top (simule gradient)
			RNDX.Draw(SLOT_RADIUS, 0, 0, w, h, Color(20, 22, 32, 240))
			RNDX.Draw(SLOT_RADIUS - 2, 1, 1, w - 2, math.floor(h / 2), Color(255, 255, 255, 8))
			-- Halo glow exterieur
			RNDX.DrawOutlined(SLOT_RADIUS + 2, -3, -3, w + 6, h + 6, haloCol, 2)
			-- Border brillante 3px coloree par rareté
			RNDX.DrawOutlined(SLOT_RADIUS, 0, 0, w, h, borderCol, 3)

			-- Draw item icon centered
			if iconMat and not iconMat:IsError() then
				surface.SetMaterial(iconMat)
				surface.SetDrawColor(255, 255, 255, 255)
				-- Scale icon to 75% of slot size
				local iconScale = 0.75
				local iconSize = math.floor(w * iconScale)
				local iconX = math.floor((w - iconSize) / 2)
				local iconY = math.floor((h - iconSize) / 2)
				surface.DrawTexturedRect(iconX, iconY, iconSize, iconSize)
			end

			-- ── Œil preview (top-right) si l'item a un hover_gif ──
			-- Pas de DHTML, juste DrawPoly via DrawEyeIcon (safe pour le pipeline).
			if item.hover_gif then
				local eyeSize = math.max(14, math.floor(w * 0.22))
				local eyePad  = math.max(4, math.floor(w * 0.05))
				local eyeX    = w - eyeSize - eyePad
				local eyeY    = eyePad
				-- Fond rond semi-transparent
				draw.RoundedBox(math.floor(eyeSize / 2), eyeX, eyeY, eyeSize, eyeSize, Color(15, 18, 28, 180))
				-- Icone oeil vectorielle centree
				local cx = eyeX + eyeSize / 2
				local cy = eyeY + eyeSize / 2
				local iconW = eyeSize * 0.78
				local iconH = eyeSize * 0.62
				DrawEyeIcon(cx, cy, iconW, iconH, Color(230, 230, 240, 240), Color(10, 10, 14, 255))
			end

			-- ── Tooltip hover : nom + rareté + taux de drop ──
			-- On capture la table d'infos dans self._hoveredLootTip ; le draw effectif
			-- se fait dans loot_list.PaintOver, qui s'execute apres tous les enfants
			-- (slots inclus) => tooltip toujours au premier plan.
			if selff:IsHovered() then
				self._hoveredLootTip = hoverTip
			end
		end
	end

	-- % de drop initiaux (poids ajustés par la pity courante) -> cohérents avec le panneau raretés.
	self:RefreshLootRates()
end

function PANEL:CloseLootList()
	if IsValid(self.loot_list) then
		self.loot_list:Remove()
		self.loot_list = nil
	end
	if IsValid(self.loot_overlay) then
		self.loot_overlay:Remove()
		self.loot_overlay = nil
	end
end

function PANEL:HandleSlotTick()
	-- Calculate when cursor passes over slot centers
	-- Slot centers are at intervals of stepSize
	local stepSize = (self.stepSize > 0) and self.stepSize or 1
	-- Calculate which slot center is currently passing the cursor
	-- The offset accounts for where the first slot center would be relative to scrollOffset
	local w, h = self.panelWidth, self.panelHeight
	local rerollX = math.floor((w - gRespX(1585)) / 2)
	local stripLeft = rerollX + gRespX(30)
	local stripCenterX = math.floor(w / 2)
	-- Slot center offset from stripLeft
	local slotCenterOffset = self.slotSizeX / 2
	-- Calculate which slot center index we're passing
	local currentStep = math.floor((self.scrollOffset + stripCenterX - stripLeft - slotCenterOffset) / stepSize)
	if currentStep ~= self._lastTickStep then
		self._lastTickStep = currentStep
		PlayRerollSound(self.tickSound)
	end
end

function PANEL:Paint(w, h)
	-- background
	local bgMat = self.faction == "Shinigami" and materials.bg_blue or self.faction == "Hollow" and materials.bg_red or materials.bg
	RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), bgMat)

	-- Encart EVO COINS (DA Atelier) : mini-plaque à coin bas-droit coupé +
	-- libellé Bebas + montant DORÉ (remplace le PNG coins_bg).
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(gRespX(self.panelWidth - 60 - 340), gRespY(140), gRespX(159), gRespY(60), Color(17, 18, 22, 235), gRespY(10), "br")
	else
		RNDX.Draw(0, gRespX(self.panelWidth - 60 - 340), gRespY(140), gRespX(159), gRespY(60), Color(17, 18, 22, 235))
	end
	draw.SimpleText("EVO COINS", "Bebas Neue:16", gRespX(self.panelWidth - 340), gRespY(140 + 10), Color(150, 154, 162), TEXT_ALIGN_CENTER)
	draw.SimpleText(self.coins, "Bebas Neue:22", gRespX(self.panelWidth - 330 + 23), gRespY(140 + 26), Color(232, 179, 75), TEXT_ALIGN_RIGHT)

	RNDX.DrawMaterial(0, gRespX(self.panelWidth - 60 - 340 - 42 + 148), gRespY(140 + math.floor((60 - 42) / 2)), gRespX(42), gRespY(42), Color(255, 255, 255, 255), materials.coin)

	-- left top bar bg (left corner)
	RNDX.DrawMaterial(0, gRespX(162), gRespY(134), gRespX(1115), gRespY(73), Color(255, 255, 255, 255), materials.left_top_bar_bg)

	-- reroll bg (centered) : remplace par DHTML stylise. PaintManual() rend le
	-- DHTML ici dans l'ordre du paint -> reste DERRIERE le slot strip qui est
	-- dessine juste apres dans cette meme PANEL:Paint.
	-- Hauteur 210 : slots 200 fit avec 5px margin top/bottom. Remontee de 55px
	-- pour matcher la position du DHTML reroll_bg_html (libere place pour reroll btn).
	local REROLL_BG_H = 210
	local rerollX = math.floor((w - gRespX(1585)) / 2)
	local rerollY = math.floor((h - gRespY(REROLL_BG_H)) / 2) - gRespY(55)
	if IsValid(self.reroll_bg_html) then
		self.reroll_bg_html:PaintManual()
	end

	-- slot strip geometry
	local stripLeft = rerollX + gRespX(30)
	local stripRight = rerollX + gRespX(1585) - gRespX(30)
	local stripWidth = stripRight - stripLeft
	local stripCenterX = math.floor(w / 2)
	local stripTop = rerollY + math.floor((gRespY(REROLL_BG_H) - self.slotSizeY) / 2)

	-- animate spin: pending → easing
	if self.isSpinning and #self.renderPool > 0 then
		if self.spinPhase == "pending" then
			-- fast continuous spin while waiting for server result
			self.scrollOffset = self.scrollOffset + self.pendingSpeed * RealFrameTime()
			self:HandleSlotTick()
		elseif self.spinPhase == "easing" then
			local elapsed = CurTime() - self.spinStartTime
			local progress = math.min(elapsed / self.spinDuration, 1.0)
			-- exponential ease-out: starts fast, slows down exponentially towards the end
			local easedProgress
			if progress >= 1.0 then
				easedProgress = 1.0
			else
				-- standard easeOutExpo curve
				easedProgress = 1.0 - math.pow(2, -10 * progress)
			end
			self.scrollOffset = self.spinStartOffset + (self.spinDistance * easedProgress)
			self:HandleSlotTick()
			if progress >= 1.0 then
				-- snap to exact position
				local N = #self.renderPool
				local P = self.stepSize * N
				local desired = stripLeft + (self.targetRenderIndex - 1) * self.stepSize + (self.slotSizeX / 2) - stripCenterX
				local k = math.ceil((self.scrollOffset - desired) / P)
				self.scrollOffset = desired + k * P
				self.btn_reroll:SetEnabled(true) -- toujours cliquable : a 0 reroll le clic redirige vers la boutique
				self.isSpinning = false
				self.spinPhase = "idle"
				-- Play win sound if we won an item (server index > 0)
				if self.lastServerIndex and self.lastServerIndex > 0 then
					local drop = self.currentPool and self.currentPool[self.lastServerIndex]
					self.lastServerIndex = nil -- Clear it so it doesn't play again
					-- CUTSCENE : certains drops lancent une video plein ecran AVANT la
					-- revelation. Le son de gain, le flash ET LE POPUP de confirmation sont
					-- donc joues DANS le rappel : sinon ils partaient PENDANT la video
					-- (bug constate le 26/07 : le popup « garder / remplacer » apparaissait
					-- par-dessus la cutscene). EVO_Cutscene.Jouer appelle toujours le rappel,
					-- meme sans video ou en cas d'echec de chargement.
					local function revelation()
						if not IsValid(self) then return end
						PlayRerollSound("4wsd81r0bjysb8vy/417iarkuz4el6024d.ogg")
						if drop and drop.rarity then self._pendingFlashRarity = drop.rarity end
						self:ApplyPendingRollUpdate()
					end
					-- La cutscene a deja ete LANCEE a la reception du resultat : ici on ne
					-- fait qu'attendre sa fin. QuandFini execute le rappel immediatement
					-- s'il n'y a aucune video pour ce drop.
					if EVO_Cutscene then
						EVO_Cutscene.QuandFini(revelation)
					else
						revelation()
					end
				else
					-- Aucun gain : pas de cutscene, mais l'etat doit quand meme etre applique.
					self:ApplyPendingRollUpdate()
				end
			end
		end
	end

	-- draw slots (repeat items along X) clipped to reroll_bg
	local pool = self.renderPool or {}
	local N = #pool
	if N > 0 then
		-- clip to reroll background area so slots do not overflow
		local sx, sy = self:LocalToScreen(rerollX, rerollY)
		render.SetScissorRect(sx, sy, sx + gRespX(1585), sy + gRespY(REROLL_BG_H), true)
		-- compute visible range of indices along the infinite strip
		local firstIndex = math.floor((self.scrollOffset - (stripLeft - self.stepSize)) / self.stepSize) - 1
		local lastIndex = math.floor((self.scrollOffset - (stripLeft - stripWidth)) / self.stepSize) + 2
		-- Hot loop : on cache tout ce qui est invariant pour eviter recompute par
		-- slot. Couleurs/halos preallocs au niveau module (LZY_REROLL_RARITY_*).
		-- gRespX/Y, stepSize, slotSizeX/Y, scrollOffset, stripTop sortis du loop.
		local SLOT_RADIUS  = math.max(4, math.floor(gRespX(14)))
		local SLOT_RADIUS2 = SLOT_RADIUS - 2
		local SLOT_RADIUS3 = SLOT_RADIUS + 2
		local slotW   = self.slotSizeX
		local slotH   = self.slotSizeY
		local slotHalfH = math.floor(slotH / 2)
		local slotWm2 = slotW - 2
		local stepSize = self.stepSize
		local scrollOff = self.scrollOffset
		local iconW = gRespX(150)
		local iconH = gRespY(150)
		local iconOffX = math.floor((slotW - iconW) / 2)
		local iconOffY = math.floor((slotH - iconH) / 2)

		for k = firstIndex, lastIndex do
			local item = pool[(k % N) + 1]
			local x = stripLeft + k * stepSize - scrollOff
			-- Rarete + iconMat sont pre-resolus dans BuildRenderPool (cf. e.rarity,
			-- e.iconMat) -> plus de currentPool lookup ni de Material() par frame.
			local rarity = item.rarity or ""
			local borderCol = LZY_RerollGetBorder(rarity)
			local haloCol   = LZY_RerollGetHalo(rarity)

			-- Fond dark + highlight top (simule gradient)
			RNDX.Draw(SLOT_RADIUS, x, stripTop, slotW, slotH, LZY_REROLL_SLOT_BG_DARK)
			RNDX.Draw(SLOT_RADIUS2, x + 1, stripTop + 1, slotWm2, slotHalfH, LZY_REROLL_SLOT_BG_TOP)
			-- Halo glow exterieur (rect plus large derriere la border)
			RNDX.DrawOutlined(SLOT_RADIUS3, x - 2, stripTop - 2, slotW + 4, slotH + 4, haloCol, 1)
			-- Border fine 2px coloree par rareté
			RNDX.DrawOutlined(SLOT_RADIUS, x, stripTop, slotW, slotH, borderCol, 2)

			-- icon centered in slot (cache pre-resolu dans BuildRenderPool).
			-- Safety net : EMPTY entries ne dessinent RIEN (icon_empty barree
			-- supprimee user-request). Devrait jamais arriver vu BuildRenderPool,
			-- mais on protege au cas ou une entry empty slipperait par un autre
			-- code path.
			if item.kind ~= "empty" and item.iconMat then
				surface.SetMaterial(item.iconMat)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(x + iconOffX, stripTop + iconOffY, iconW, iconH)
			end
		end
		-- disable scissor
		render.SetScissorRect(0, 0, 0, 0, false)
	end

	-- Cursor central (reroll_cursor.png, ligne verticale blanche 16x253)
	-- Indique visuellement le slot de landing au centre du strip.
	do
		local curW = gRespX(16)
		local curH = gRespY(REROLL_BG_H)
		local curX = rerollX + math.floor(gRespX(1585) / 2) - math.floor(curW / 2)
		local curY = rerollY
		surface.SetMaterial(materials.reroll_cursor)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(curX, curY, curW, curH)
	end

	-- ── Hover tooltip sur le slot strip : nom FR du pouvoir (art_spirituel) ──
	-- Les slots sont dessines via surface.* dans Paint (pas des panels VGUI),
	-- donc :SetTooltip n'est pas applicable. On detecte le hover manuellement et
	-- on dessine la bulle ici, juste apres le strip pour qu'elle passe au-dessus.
	if self.current_category == "art_spirituel" and not self.isSpinning and N > 0 and self:IsHovered() then
		local mx, my = self:CursorPos()
		if my >= stripTop and my <= stripTop + self.slotSizeY
		   and mx >= stripLeft and mx <= stripRight then
			local stepSize = (self.stepSize and self.stepSize > 0) and self.stepSize or 1
			local idx = math.floor((mx + self.scrollOffset - stripLeft) / stepSize)
			local item = pool[(idx % N) + 1]
			if item and item.kind == "item" and item.refIndex and self.currentPool then
				local drop = self.currentPool[item.refIndex]
				local name = drop and GetArtPowerNameFR(drop) or ""
				if name ~= "" then
					surface.SetFont("LZY_RerollRarityTip")
					local tw, th = surface.GetTextSize(name)
					local padX, padY = gRespX(20), gRespY(12)
					local boxW = tw + padX * 2
					local boxH = th + padY * 2
					-- Ancrée au-dessus du strip, clampée dans l'écran (le panneau est
					-- plein écran, donc coords locales = coords écran).
					local boxX, boxY = ClampTipToScreen(mx, stripTop, boxW, boxH, gRespY(12))
					DrawTooltipFrame(boxX, boxY, boxW, boxH)
					draw.SimpleText(name, "LZY_RerollRarityTip",
						boxX + math.floor(boxW / 2),
						boxY + math.floor(boxH / 2),
						TIP_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
		end
	end

	-- reroll btn bg + bouton + texte "X REROLL RESTANT" : tout est maintenant
	-- dans self.btn_reroll (DHTML cree dans Init). Plus rien a dessiner ici.
	-- On garde rerollBtnBgX pour le pity text centre en dessous.
	local rerollBtnBgX = math.floor((w - gRespX(236)) / 2)

	-- pity text per category
	local pityRolls = self:GetCurrentCategoryPityRolls()
	local pityStep = GetRerollPityStepRolls()
	local pityLevel = math.floor(pityRolls / pityStep)
	local pityProgress = pityRolls % pityStep
	local pityText = string.format("Pity %d (%d/%d)", pityLevel, pityProgress, pityStep)
	draw.SimpleText(pityText, "Avenir Next World:20", rerollBtnBgX + gRespX(236) / 2, gRespY(350), Color(180, 180, 180), TEXT_ALIGN_CENTER)

	-- equipped preview (bottom center) : remplace par DHTML equipedHtml.
	-- PaintManual() rend ici dans l'ordre du paint, derriere les autres children
	-- mais devant les autres draws de PANEL:Paint qui precedent.
	if IsValid(self.equipedHtml) then
		self.equipedHtml:PaintManual()
	end
end

function PANEL:BuildRenderPool()
	local drops = self.currentPool or {}
	
	-- First, group items by rarity and count them (same logic as server)
	local rarityCounts = {}
	local rarityWeights = {}
	
	for i = 1, #drops do
		local drop = drops[i]
		if drop.rarity then
			rarityCounts[drop.rarity] = (rarityCounts[drop.rarity] or 0) + 1
			-- Get the total weight for this rarity (only once per rarity)
			if not rarityWeights[drop.rarity] then
				if REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[drop.rarity] then
					rarityWeights[drop.rarity] = tonumber(REROLL_DROPS_RARITIES[drop.rarity].weight) or 0
				else
					rarityWeights[drop.rarity] = 0
				end
			end
		end
	end
	
	-- Calculate total weight of all rarities present in this category
	local totalRarityWeight = 0
	for rarity, weight in pairs(rarityWeights) do
		totalRarityWeight = totalRarityWeight + weight
	end
	
	-- If total is less than 100, add the missing weight to "commun" rarity
	local missingWeight = 100 - totalRarityWeight
	if missingWeight > 0.01 and rarityWeights["commun"] then
		rarityWeights["commun"] = rarityWeights["commun"] + missingWeight
	end
	
	-- Calculate per-item weights by distributing rarity weights evenly (same as server)
	local weights = {}
	local total = 0
	for i = 1, #drops do
		local drop = drops[i]
		local weight = 0
		if drop.rarity and rarityCounts[drop.rarity] and rarityCounts[drop.rarity] > 0 then
			-- Distribute the rarity weight evenly among items of that rarity
			weight = rarityWeights[drop.rarity] / rarityCounts[drop.rarity]
		elseif drop.drop_rate then
			weight = tonumber(drop.drop_rate) or 0
		end
		weights[i] = weight
		total = total + weight
	end
	
	-- Create display weights that make rare items appear more common
	-- Items with 90%+ drop rate get reduced, others get boosted
	local displayWeights = {}
	local displayTotal = 0
	for i = 1, #drops do
		local actualWeight = weights[i]
		local displayWeight
		if actualWeight >= 60 then
			-- Reduce common items (90%+) by dividing
			displayWeight = actualWeight / 5
		else
			-- Boost rare items (<90%) by multiplying
			displayWeight = actualWeight * 5
		end
		displayWeights[i] = displayWeight
		displayTotal = displayTotal + displayWeight
	end
	
	-- EMPTY DROPS DESACTIVES (user request) : 0 case barree dans la roulette.
	-- Cf. sv_main.lua qui force aussi emptyWeight = 0 cote serveur. Plus aucune
	-- entry kind = "empty" ne sera generee, donc emptyMat (icon_empty.png) ne
	-- s'affichera plus jamais dans la bande de slots.
	local emptyWeight = 0
	local displayEmptyWeight = 0
	
	local renderSlots = 20
	local entries = {}
	local remainders = {}
	local sumBase = 0
	local function addCounts(count, kind, refIndex)
		for _ = 1, count do
			entries[#entries + 1] = { kind = kind, refIndex = refIndex }
		end
	end
	if total + emptyWeight <= 0 then
		-- fallback: at least place one empty
		entries = { { kind = "empty" } }
		self.renderPool = entries
		return
	end
	-- First, ensure every item gets at least 1 slot
	local counts = {}
	for i = 1, #drops do
		counts[i] = 1  -- Every item gets at least 1 slot
		sumBase = sumBase + 1
	end
	
	-- Calculate remaining slots after guaranteeing 1 per item
	local slotsUsedForItems = #drops
	local remainingSlots = renderSlots - slotsUsedForItems
	
	local emptyBase = 0
	if remainingSlots <= 0 then
		-- Not enough slots for all items + empty, just ensure all items have at least 1 slot
		-- No empty slots if we don't have enough room
	else
		-- Distribute remaining slots proportionally based on DISPLAY weights (not actual drop rates)
		local function proportionCount(displayWeight)
			return (displayWeight / (displayTotal + displayEmptyWeight)) * remainingSlots
		end
		
		-- Calculate additional slots for each item based on display weights
		local additionalCounts = {}
		local additionalSum = 0
		for i = 1, #drops do
			local exact = proportionCount(displayWeights[i])
			local base = math.floor(exact)
			additionalCounts[i] = base
			remainders[#remainders + 1] = { rem = exact - base, kind = "item", refIndex = i }
			additionalSum = additionalSum + base
		end
		
		-- Add additional slots to items
		for i = 1, #drops do
			counts[i] = counts[i] + additionalCounts[i]
			sumBase = sumBase + additionalCounts[i]
		end
		
		-- Handle empty slots (only if emptyWeight > 0)
		if emptyWeight > 0 then
			local exactEmpty = proportionCount(displayEmptyWeight)
			emptyBase = math.floor(exactEmpty)
			sumBase = sumBase + emptyBase
			remainders[#remainders + 1] = { rem = exactEmpty - emptyBase, kind = "empty", refIndex = 0 }
		end
		
		-- Distribute any remaining slots by largest remainders
		local remaining = math.max(0, remainingSlots - additionalSum - emptyBase)
		table.SortByMember(remainders, "rem", true)
		-- Filter out empty remainders if emptyWeight is 0
		local validRemainders = {}
		for _, r in ipairs(remainders) do
			if r.kind ~= "empty" or emptyWeight > 0 then
				table.insert(validRemainders, r)
			end
		end
		if #validRemainders > 0 then
			for i = 1, remaining do
				local r = validRemainders[((i - 1) % #validRemainders) + 1]
				if r.kind == "empty" then
					emptyBase = emptyBase + 1
				else
					counts[r.refIndex] = counts[r.refIndex] + 1
				end
			end
		end
	end
	-- add to entries
	for i = 1, #drops do
		addCounts(counts[i], "item", i)
	end
	addCounts(emptyBase, "empty", 0)
	-- if we somehow exceeded, trim
	while #entries > renderSlots do table.remove(entries) end
	-- randomize order for nicer visual distribution
	for i = #entries, 2, -1 do
		local j = math.random(1, i)
		entries[i], entries[j] = entries[j], entries[i]
	end
	-- enrich entries with icon/color/rarity/iconMat for drawing. iconMat est
	-- pre-resolu ici (Material() est cher, appel par-frame x10-15 slots visibles
	-- = couteux pendant le spin). rarity aussi pour eviter currentPool lookup
	-- dans la hot loop de Paint.
	for _, e in ipairs(entries) do
		if e.kind == "item" then
			local d = drops[e.refIndex]
			e.icon = d.icon
			e.color = GetDropColor(d)
			e.rarity = d.rarity or ""
			e.iconMat = (d.icon and d.icon ~= "") and Material(d.icon, "smooth") or nil
		else
			e.icon = nil
			e.color = nil
			e.rarity = ""
			e.iconMat = nil
		end
	end
	self.renderPool = entries
end

function PANEL:MapServerIndexToRenderIndex(serverIndex)
	if not self.renderPool or #self.renderPool == 0 then
		return nil
	end
	local candidates = {}
	if serverIndex == 0 then
		for i = 1, #self.renderPool do
			if self.renderPool[i].kind == "empty" then table.insert(candidates, i) end
		end
	else
		for i = 1, #self.renderPool do
			local e = self.renderPool[i]
			if e.kind == "item" and e.refIndex == serverIndex then table.insert(candidates, i) end
		end
	end
	-- If no candidate exists for the winning item, force-insert it by replacing an empty slot
	if #candidates == 0 then
		if serverIndex == 0 then
			-- No empties? fallback to any slot
			return 1
		else
			-- try to replace an empty entry
			local replaceIndex
			for i = 1, #self.renderPool do
				if self.renderPool[i].kind == "empty" then replaceIndex = i break end
			end
			if not replaceIndex then
				-- as a last resort, replace a random slot
				replaceIndex = math.random(1, #self.renderPool)
			end
			local d = self.currentPool and self.currentPool[serverIndex]
			if d then
				self.renderPool[replaceIndex] = {
					kind = "item",
					refIndex = serverIndex,
					icon = d.icon,
					color = GetDropColor(d),
				}
				return replaceIndex
			end
			return replaceIndex
		end
	end
	local selected = candidates[math.random(1, #candidates)]
	
	return selected
end

function PANEL:RequestReroll()
	-- Deja en attente d'une reponse serveur : ne pas renvoyer (anti double-clic).
	if self.isWaitingResult then return end
	if self.isSpinning then
		-- Skip animation if already spinning
		if self.spinPhase == "easing" and self.targetRenderIndex then
			-- Skip to end of animation
			self:SkipAnimation()
		end
		return
	end
	-- PAS DE BLOCAGE SUR LE STOCK ICI. Le NWInt n'est PAS autoritatif : un reroll
	-- credite par un AUTRE serveur (achat site livre pendant que le joueur est
	-- ailleurs) laisse ce compteur perime BAS, et le client refusait alors d'envoyer
	-- la requete — bouton mort, sans meme un message. C'est la cause du "il faut
	-- retry / se reconnecter pour avoir ses rerolls".
	-- Le SERVEUR decide desormais, en base et de facon atomique (UPDATE ... WHERE
	-- col > 0 + lignes affectees). Sur refus : popup + lzy_reroll_denied (PAS de
	-- lzy_reroll_result) -> la roue ne tourne pas et le stock n'est pas consomme.
	if not self.currentPool or #self.currentPool == 0 then return end
	if not self.current_category then return end
	if not self._netBound then
		self:_BindRerollNet()
	end
	
	-- Check if player has an epique or legendary item equipped in this category
	local currentWinId = ""
	if self.current_category == "art_spirituel" then
		currentWinId = self.art_spirituel or ""
	elseif self.current_category == "style_de_combat" then
		currentWinId = self.style_combat or ""
	elseif self.current_category == "style_execution" then
		currentWinId = self.style_execution or ""
	elseif self.current_category == "reiatsu_color" then
		currentWinId = self.reiatsu_color or ""
	elseif self.current_category == "catalyseur" then
		currentWinId = self.catalyseur or ""
	end
	
	-- Sans grade payant il n'existe AUCUNE protection au tirage (cf. sv_main) : ce
	-- rappel AVANT la roue est le seul filet. Mythique et secret y sont inclus depuis
	-- le 31/07 — ils etaient couverts par la confirmation serveur jusque-la, ils ne le
	-- sont plus, et se les faire ecraser par un commun sans un mot serait brutal.
	-- Un premium n'en a pas besoin : il tranche APRES la roue (GARDER / REMPLACER).
	local WARN_RARITIES = { epique = true, legendary = true, mythique = true, secret = true }
	if LocalPlayer():GetEvoNWInt("premium", 0) == 0 and currentWinId ~= "" then
		local currentDrop = GetDropByWinId(currentWinId, self.faction, self.current_category)
		if currentDrop and currentDrop.rarity and WARN_RARITIES[currentDrop.rarity] then
			-- Show confirmation popup in French
			local rarityName = TitleForRarityKey(currentDrop.rarity)
			local itemName = currentDrop.name or "cet objet"
			local message = string.format("Vous possédez actuellement un objet de rareté %s (%s) dans ce slot et vous risquez de le perdre lors du reroll. Voulez-vous continuer ?", rarityName, itemName)
			
			LocalPlayer():OpenYesNoPopup(message, "RerollConfirm", {
				panel = self
			})
			return
		end
	end
	
	-- No confirmation needed, proceed with reroll
	self:DoReroll()
end

-- Annule l'attente d'une reponse serveur (timeout / refus) SANS lancer la roue.
function PANEL:CancelWaitingForRoll(reason)
	if not self.isWaitingResult then return end
	self.isWaitingResult = false
	if self.rollTimeoutTimer then
		timer.Remove(self.rollTimeoutTimer)
		self.rollTimeoutTimer = nil
	end
	-- Pas de spin en cours a annuler (on n'en demarre plus avant la confirmation).
	self.isSpinning = false
	self.spinPhase = "idle"
	if IsValid(self.btn_reroll) then
		self.btn_reroll:SetEnabled(true)
		if self._lastRerollState then
			self._lastRerollState.enabled = true
			self._lastRerollState.waiting = false
			self._lastRerollState.spinning = nil -- force resync SKIP/REROLL au prochain Think
		end
		self.btn_reroll:RunJavascript("if(typeof setWaiting==='function')setWaiting(false)")
		self.btn_reroll:RunJavascript("if(typeof setEnabled==='function')setEnabled(true)")
	end
	-- Re-lit le stock depuis le NW (resync serveur possible sur refus).
	self:RefreshRerollLeftFromNW()
	if IsValid(self.btn_reroll) and self._lastRerollState then
		self._lastRerollState.left = self.reroll_left
		self.btn_reroll:RunJavascript("if(typeof setLeft==='function')setLeft(" .. tostring(self.reroll_left or 0) .. ")")
	end
	if reason and MUGEN and MUGEN.Notify then
		MUGEN.Notify(reason, NOTIFY_ERROR or 1, 5)
	end
end

-- Une confirmation GARDER / REMPLACER attend une reponse : le serveur refuse tout
-- nouveau tirage dans cette fenetre (cf. lzy_reroll_request), le bouton doit donc etre
-- mort. Le verrou est BORNE dans le temps, sur le meme TTL que le serveur : la popup se
-- ferme aussi a ECHAP, sans declencher aucun des deux callbacks, et un verrou eternel
-- rendrait le menu inutilisable jusqu'a la reconnexion.
function PANEL:IsDecisionLocked()
	return (self._decisionLockUntil or 0) > CurTime()
end

function PANEL:DoReroll()
	if self.isWaitingResult or self.isSpinning or self:IsDecisionLocked() then return end
	-- Prepare le pool d'affichage, mais NE lance PAS la roue tant que le serveur
	-- n'a pas confirme un vrai tirage (pattern SKR : waitingForRollResponse).
	self:BuildRenderPool()
	self.isWaitingResult = true
	if IsValid(self.btn_reroll) then
		self.btn_reroll:SetEnabled(false)
		if self._lastRerollState then
			self._lastRerollState.enabled = false
			self._lastRerollState.waiting = true
			self._lastRerollState.spinning = false
		end
		self.btn_reroll:RunJavascript("if(typeof setEnabled==='function')setEnabled(false)")
		self.btn_reroll:RunJavascript("if(typeof setWaiting==='function')setWaiting(true)")
	end

	-- Timeout 15s (comme SKR) : si aucune reponse (ni result ni denied), on annule.
	if self.rollTimeoutTimer then
		timer.Remove(self.rollTimeoutTimer)
		self.rollTimeoutTimer = nil
	end
	self.rollTimeoutTimer = "LZY:Reroll:Timeout:" .. tostring(CurTime())
	timer.Create(self.rollTimeoutTimer, 15, 1, function()
		if not IsValid(self) then return end
		if not self.isWaitingResult then return end
		self:CancelWaitingForRoll("Le serveur n'a pas répondu. Réessaie.")
	end)

	net.Start("lzy_reroll_request")
		net.WriteString(self.faction or "")
		net.WriteString(self.current_category or "")
	net.SendToServer()
end

function PANEL:_BindRerollNet()
	if self._netBound then return end
	self._netBound = true

	net.Receive("lzy_reroll_pending", function()
		local faction = net.ReadString()
		local category = net.ReadString()
		local oldWin = net.ReadString()
		local newWin = net.ReadString()
		local lockSeconds = net.ReadUInt(16)
		if not IsValid(self) or faction ~= self.faction then return end
		if self.isWaitingResult or self.isSpinning or self._decisionPopupShown then return end
		local oldDrop = GetDropByWinId(oldWin, faction, category)
		local newDrop = GetDropByWinId(newWin, faction, category)
		if not newDrop then return end
		self._decisionLockUntil = CurTime() + lockSeconds
		self:OpenPremiumRerollChoicePopup({
			oldName = oldDrop and oldDrop.name or oldWin,
			newName = newDrop.name or newWin,
			oldRarityTitle = TitleForRarityKey(oldDrop and oldDrop.rarity),
			newRarityTitle = TitleForRarityKey(newDrop.rarity),
			category = category,
			new_win_id = newWin,
		})
	end)

	-- La pity affichee suit l'etat pousse par le SERVEUR, jamais un calcul local.
	hook.Add("LZY:PlyState:Changed", "LZY_Reroll::PityRefresh", function(_, sKey)
		if sKey ~= "LZY_Reroll_Pities" then return end
		if not IsValid(self) then
			hook.Remove("LZY:PlyState:Changed", "LZY_Reroll::PityRefresh")
			return
		end
		self:OnPityStateChanged()
	end)

	-- Refus serveur (stock vide, DB down, busy...) : deverrouille SANS lancer la roue.
	-- Le stock n'a PAS ete consomme. 65535 = sentinelle "inconnu" -> on relit le NW.
	net.Receive("lzy_reroll_denied", function()
		local remaining = net.ReadUInt(16) or 65535
		if not IsValid(self) then return end
		if not self.isWaitingResult then return end -- stale
		if remaining ~= 65535 then
			self.reroll_left = remaining
			if self._lastRerollState then self._lastRerollState.left = remaining end
			if IsValid(self.btn_reroll) then
				self.btn_reroll:RunJavascript("if(typeof setLeft==='function')setLeft(" .. tostring(remaining) .. ")")
			end
		end
		self:CancelWaitingForRoll(nil) -- popup serveur deja affichee
	end)

	net.Receive("lzy_reroll_result", function()
		local faction = net.ReadString() or ""
		local category = net.ReadString() or ""
		local index = net.ReadUInt(16) or 1
		local pityRolls = net.ReadUInt(16) or 0
		local pityLevel = net.ReadUInt(16) or 0
		local needsPremiumChoice = net.ReadBool()
		-- Refus d'office par le plancher de protection : rien n'a change en base.
		local autoKept = net.ReadBool()
		-- Authoritative count for this category (NW can lag one frame behind this message)
		local remainingRerolls = net.ReadUInt(16) or 0

		if not IsValid(self) then return end

		-- Ignore les messages perimes (pas d'attente en cours) — pattern SKR.
		if not self.isWaitingResult then return end

		self.isWaitingResult = false
		if self.rollTimeoutTimer then
			timer.Remove(self.rollTimeoutTimer)
			self.rollTimeoutTimer = nil
		end
		if IsValid(self.btn_reroll) then
			if self._lastRerollState then self._lastRerollState.waiting = false end
			self.btn_reroll:RunJavascript("if(typeof setWaiting==='function')setWaiting(false)")
		end

		-- get won item name
		local itemName = "Empty (No Win)"
		if index > 0 and index <= #self.currentPool then
			itemName = self.currentPool[index].name or "Unknown Item"
		end
		
		-- Store server index to check if we won when animation ends
		self.lastServerIndex = index

		-- CUTSCENE (26/07) : DEUX effets INDEPENDANTS, a deux moments du tirage.
		--   * L'ETOILE part TOUT DE SUITE, c'est-a-dire au clic : ~1 s, fond
		--     TRANSPARENT, la roue reste visible derriere. C'est une ponctuation,
		--     pas un ecran : elle ne bloque ni la souris ni le clavier.
		--   * La VIDEO prend le plein ecran EVO_Cutscene.AvantArrivee secondes AVANT
		--     que la roue ne tombe (1,5 s), d'ou le retard spinDuration - cette
		--     avance. Elle recouvre la roue avant l'arrivee,
		--     donc le joueur ne voit JAMAIS son drop avant la video. C'est tout
		--     l'interet : avant, la roue s'arretait d'abord et la video ne revelait
		--     plus rien.
		-- TRACE (evo_cutscene_debug 1) : pose parce qu'on tournait en rond sur
		-- « ca ne change rien ». Elle dit EXACTEMENT quel drop est tombe, si une
		-- video existe pour lui, et a quelle seconde elle est planifiee.
		local bDbg = GetConVar("evo_cutscene_debug")
		bDbg = bDbg and bDbg:GetBool()
		if bDbg then
			local dd = (index > 0 and index <= #self.currentPool) and self.currentPool[index] or nil
			MsgC(Color(255, 180, 80), "[cutscene] resultat serveur : index=" .. tostring(index)
				.. "  win_id=" .. tostring(dd and dd.win_id or "-")
				.. "  rarete=" .. tostring(dd and dd.rarity or "-")
				.. "  video=" .. tostring(dd and dd.win_id and EVO_Cutscene and EVO_Cutscene.A
					and EVO_Cutscene.A(dd.win_id) or false)
				.. "  spinDuration=" .. tostring(self.spinDuration) .. "\n")
		end

		if EVO_Cutscene and index > 0 and index <= #self.currentPool then
			local d = self.currentPool[index]
			if d and d.win_id and EVO_Cutscene.A and EVO_Cutscene.A(d.win_id) then
				-- L'etoile prend la couleur de la rarete annoncee (jaune pour un
				-- legendaire, violet pour un epique...) : un rouge fixe promettait
				-- du mythique a chaque fois. `d.rarity` peut manquer -> repli interne.
				if EVO_Cutscene.Etoile then EVO_Cutscene.Etoile(d.rarity) end
				local sWin = d.win_id
				-- La roue commence son ralentissement ICI, a la reponse du serveur
				-- (StartSpinToRenderIndex plus bas pose spinStartTime = CurTime()).
				-- Les deux horloges partent donc du meme instant, l'avance est exacte.
				-- math.max(0, ...) : si la roue devenait plus courte que l'avance, on
				-- lance tout de suite au lieu de calculer un retard negatif.
				local nAvance = tonumber(EVO_Cutscene.AvantArrivee) or 1.5
				local nRetard = math.max(0, (tonumber(self.spinDuration) or 9) - nAvance)
				if bDbg then
					MsgC(Color(255, 180, 80), "[cutscene] video planifiee dans " .. string.format("%.2f", nRetard)
						.. " s (avance " .. tostring(nAvance) .. " s)\n")
				end
				timer.Simple(nRetard, function()
					-- Le panneau peut avoir ete ferme entre-temps : c'est LA cause la plus
					-- probable d'une video qui ne part jamais, donc on le dit.
					if not IsValid(self) then
						if bDbg then MsgC(Color(255, 90, 90), "[cutscene] ANNULEE : le menu de reroll a ete ferme\n") end
						return
					end
					local ok = EVO_Cutscene.Lancer(sWin)
					if bDbg then
						MsgC(Color(255, 180, 80), "[cutscene] Lancer(" .. sWin .. ") -> " .. tostring(ok) .. "\n")
					end
				end)
			end
		end
		
		if faction ~= self.faction or category ~= self.current_category then
			-- category changed mid-flight; ignore result if pools differ
			if IsValid(self.btn_reroll) then self.btn_reroll:SetEnabled(true) end
			return
		end

		self.reroll_left = remainingRerolls

		-- Push direct vers le DHTML btn_reroll : on ne se repose plus sur le
		-- Think diff-check (qui peut rater l'update si _lastRerollState.left
		-- contenait deja la nouvelle valeur a cause d'une race init). On force
		-- aussi le sync de la cache pour rester coherent avec le diff.
		if IsValid(self.btn_reroll) then
			if self._lastRerollState then self._lastRerollState.left = remainingRerolls end
			self.btn_reroll:RunJavascript("if(typeof setLeft==='function')setLeft(" .. tostring(remainingRerolls) .. ")")
		end

		-- PITY : le SERVEUR en est le seul maitre (tirage puis acceptation Platinum).
		-- Il n'annonce la nouvelle valeur qu'une fois la base ECRITE. On ne la recopie PAS dans
		-- l'etat local : on afficherait sinon une pity remise a zero que la base n'a
		-- peut-etre jamais enregistree (ecriture echouee, colonne illisible). L'affichage
		-- et les % se mettent a jour seuls quand l'etat serveur arrive
		-- (cf. OnPityStateChanged).
		if REROLL_DEBUG then
			print(string.format("[REROLL CLIENT] Pity annoncee pour %s => rolls=%d level=%d",
				BuildPityKey(faction, category), pityRolls, pityLevel))
		end

		self._premiumRerollChoice = nil
		self._decisionPopupShown = nil
		self._protectedKeep = nil
		self.pendingRollUpdate = nil

		-- VERROU pose DES MAINTENANT, et non a l'ouverture de la popup : celle-ci
		-- n'arrive qu'apres la roue ET la cutscene (plusieurs secondes sur un
		-- legendaire), or le bouton redevient cliquable des la fin du spin. C'est
		-- exactement le trou par lequel un joueur qui enchaine les clics relancait un
		-- tirage avant d'avoir repondu. Le serveur, lui, a deja memorise sa
		-- confirmation au moment du tirage : les deux verrous s'ouvrent ensemble.
		-- Pose sur le booleen reseau et non sur la popup effectivement affichee : si
		-- l'objet equipe est introuvable cote client la popup ne s'ouvre pas, et le
		-- bouton doit quand meme rester mort le temps que le serveur oublie.
		self._decisionLockUntil = needsPremiumChoice
			and (CurTime() + REROLL_PENDING_DECISION_TTL) or nil

		if (needsPremiumChoice or autoKept) and index > 0 and index <= #self.currentPool then
			local wonDrop = self.currentPool[index]
			local currentWinId = ""
			if category == "art_spirituel" then
				currentWinId = self.art_spirituel or ""
			elseif category == "style_de_combat" then
				currentWinId = self.style_combat or ""
			elseif category == "style_execution" then
				currentWinId = self.style_execution or ""
			elseif category == "reiatsu_color" then
				currentWinId = self.reiatsu_color or ""
			elseif category == "catalyseur" then
				currentWinId = self.catalyseur or ""
			end
			local eqDrop = (currentWinId ~= "") and GetDropByWinId(currentWinId, self.faction, category) or nil
			if wonDrop and eqDrop then
				local d = {
					oldName = eqDrop.name or "—",
					newName = wonDrop.name or "—",
					oldRarityTitle = TitleForRarityKey(eqDrop.rarity),
					newRarityTitle = TitleForRarityKey(wonDrop.rarity),
					category = category,
					new_win_id = wonDrop.win_id,
				}
				-- Les deux cas s'annoncent APRES la revelation (cf. ApplyPendingRollUpdate) :
				-- confirmation a trancher, ou simple info « ton objet a ete protege ».
				if needsPremiumChoice then
					self._premiumRerollChoice = d
				else
					self._protectedKeep = d
				end
			end
		elseif index > 0 and index <= #self.currentPool then
			local wonDrop = self.currentPool[index]
			if wonDrop and wonDrop.win_id then
				self.pendingRollUpdate = {
					category = category,
					win_id = wonDrop.win_id
				}
			end
		end
		
		-- map server index (0 = empty, >0 = item index in currentPool) to a renderPool index
		local targetRender = self:MapServerIndexToRenderIndex(index)
		
		if not targetRender then
			if IsValid(self.btn_reroll) then self.btn_reroll:SetEnabled(true) end
			return
		end
		
		-- Confirmation serveur recue : on lance ENFIN la roue vers le resultat.
		self:StartSpinToRenderIndex(targetRender)
	end)
end

function PANEL:OpenPremiumRerollChoicePopup(d)
	if not d then return end
	self._decisionPopupShown = true
	local msg = string.format(
		"Vous êtes premium : souhaitez-vous remplacer l'objet actuellement équipé par le drop obtenu ?\n\nActuel : %s (%s)\nObtenu : %s (%s)\n\nOUI = remplacer par le nouveau.\nNON = conserver l'actuel.",
		d.oldName,
		d.oldRarityTitle,
		d.newName,
		d.newRarityTitle
	)
	-- args: panel + new win for Replace callback (mirrors pendingRollUpdate for non-premium path)
	local popupArgs = {
		panel = self,
		category = d.category,
		new_win_id = d.new_win_id,
	}
	-- same args for yes/no (Replace uses new_win_id; Keep ignores it)
	-- Fermer sans repondre conserve le choix ; il sera restaure a la reouverture.
	LocalPlayer():OpenYesNoPopup(msg, "RerollPremiumReplace", popupArgs, "RerollPremiumKeep")
end

function PANEL:ApplyPendingRollUpdate()
	if self._premiumRerollChoice then
		local d = self._premiumRerollChoice
		self._premiumRerollChoice = nil
		self:OpenPremiumRerollChoicePopup(d)
		return
	end

	-- Refus d'office (tirage sous le plancher) : pas de question, mais une notif est
	-- OBLIGATOIRE. Sans elle, le joueur voit la roue s'arreter sur un commun et croit
	-- l'avoir recu, alors que son objet equipe n'a pas bouge.
	if self._protectedKeep then
		local d = self._protectedKeep
		self._protectedKeep = nil
		if MUGEN and MUGEN.Notify then
			MUGEN.Notify(string.format(
				"Protection reroll : %s (%s) refusé, vous gardez %s (%s).",
				d.newName, d.newRarityTitle, d.oldName, d.oldRarityTitle
			), NOTIFY_HINT or 3, 8, false, { group = "reroll_protection", maxVisible = 3 })
		end
		return
	end

	if not self.pendingRollUpdate then return end

	local update = self.pendingRollUpdate
	if update.category == "art_spirituel" then
		self.art_spirituel = update.win_id
	elseif update.category == "style_de_combat" then
		self.style_combat = update.win_id
	elseif update.category == "style_execution" then
		self.style_execution = update.win_id
	elseif update.category == "reiatsu_color" then
		self.reiatsu_color = update.win_id
	elseif update.category == "catalyseur" then
		self.catalyseur = update.win_id
	end

	self.pendingRollUpdate = nil
end

function PANEL:SkipAnimation()
	if not self.isSpinning or not self.targetRenderIndex then return end
	
	-- Calculate target position and snap to it
	local w, h = self.panelWidth, self.panelHeight
	local rerollX = math.floor((w - gRespX(1585)) / 2)
	local stripLeft = rerollX + gRespX(30)
	local stripCenterX = math.floor(w / 2)
	local desired = stripLeft + (self.targetRenderIndex - 1) * self.stepSize + (self.slotSizeX / 2) - stripCenterX
	
	local N = #self.renderPool
	local P = self.stepSize * N
	local k = math.ceil((self.scrollOffset - desired) / P)
	self.scrollOffset = desired + k * P
	
	self.isSpinning = false
	self.spinPhase = "idle"
	-- Play win sound if we won an item (server index > 0)
	if self.lastServerIndex and self.lastServerIndex > 0 then
		local drop = self.currentPool and self.currentPool[self.lastServerIndex]
		self.lastServerIndex = nil -- Clear it so it doesn't play again
		-- CUTSCENE : cf. l'autre point de revelation plus haut, meme logique. Le popup
		-- de confirmation part AUSSI dans le rappel, sinon il s'ouvre par-dessus la video.
		local function revelation()
			if not IsValid(self) then return end
			PlayRerollSound("4wsd81r0bjysb8vy/417iarkuz4el6024d.ogg")
			if drop and drop.rarity then self._pendingFlashRarity = drop.rarity end
			self:ApplyPendingRollUpdate()
		end
		-- La cutscene a deja ete LANCEE a la reception du resultat : ici on ne
		-- fait qu'attendre sa fin. QuandFini execute le rappel immediatement
		-- s'il n'y a aucune video pour ce drop.
		if EVO_Cutscene then
			EVO_Cutscene.QuandFini(revelation)
		else
			revelation()
		end
	else
		-- Aucun gain : pas de cutscene, mais l'etat doit quand meme etre applique.
		self:ApplyPendingRollUpdate()
	end
	-- Update button state based on reroll count
	self.btn_reroll:SetEnabled(true) -- toujours cliquable : a 0 reroll le clic redirige vers la boutique
end

function PANEL:StartSpinToRenderIndex(renderIndex)
	-- Avant : on n'acceptait la transition que depuis "pending". Desormais on
	-- demarre depuis idle (pas de spin tant que le serveur n'a pas confirme).
	if self.isSpinning and self.spinPhase == "easing" then
		return
	end
	if not self.renderPool or #self.renderPool == 0 then return end
	self.targetRenderIndex = math.Clamp(tonumber(renderIndex) or 1, 1, #self.renderPool)
	
	-- calculate target position
	local w, h = self.panelWidth, self.panelHeight
	local rerollX = math.floor((w - gRespX(1585)) / 2)
	local stripLeft = rerollX + gRespX(30)
	local stripCenterX = math.floor(w / 2)
	local targetOffset = stripLeft + (self.targetRenderIndex - 1) * self.stepSize + (self.slotSizeX / 2) - stripCenterX
	
	-- calculate distance to travel (add one full period for visual effect)
	local N = #self.renderPool
	local P = self.stepSize * N
	local currentOffset = self.scrollOffset
	local directDist = targetOffset - currentOffset
	local delta = ((directDist % P) + P) % P
	-- Depuis idle (pas de pending), on ajoute plus de tours pour un spin visible.
	local loops = (self.spinPhase == "pending") and 1 or 3
	local totalDistance = delta + (loops * P)
	
	-- setup easing animation from current position
	self.spinStartOffset = currentOffset
	self.spinTargetOffset = targetOffset
	self.spinDistance = totalDistance
	self.spinStartTime = CurTime()
	self.isSpinning = true
	self.spinPhase = "easing"

	-- Re-enable the button during easing so it can act as a Skip button
	if IsValid(self.btn_reroll) then
		self.btn_reroll:SetEnabled(true)
	end
end

function PANEL:OnClose()
	hook.Remove("LZY:PlyState:Changed", "LZY_Reroll::PityRefresh")
	-- Clean up timeout timer if it exists
	if self.rollTimeoutTimer then
		timer.Remove(self.rollTimeoutTimer)
		self.rollTimeoutTimer = nil
	end
	self.isWaitingResult = false
	-- Ferme aussi l'aperçu GIF (preview loot) s'il est resté ouvert : sinon il
	-- flotte à l'écran après fermeture du reroll, ce qui est confusant.
	if IsValid(_LZY_RerollPreviewFrame) then
		_LZY_RerollPreviewFrame:Close()
		_LZY_RerollPreviewFrame = nil
	end
	frame = nil
	self._premiumRerollChoice = nil
	self:Remove()
end

vgui.Register("lzy_reroll", PANEL, "DFrame")

-- Encore en progression Hollow (larve, Menos, Vasto) ? Le tirage n'a pas de sens
-- avant la transformation : la phase capacite qui SUIT l'arrivee en Arrancar
-- attribue deja l'art. Rerolle avant, le joueur brulait des tirages pour un art
-- qui lui sera redemande. Le serveur refuse de toute facon (lzy_reroll_request),
-- ceci evite juste d'ouvrir un menu qui ne peut rien faire.
local function EnProgressionHollow()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	return lp:GetEvoNWBool("EVO_HollowRaw", false) or lp:GetEvoNWBool("EVO_IsLarva", false)
end

local function RefusProgression()
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify("Tu choisiras ton art en devenant Arrancar. Garde tes rerolls.", NOTIFY_HINT or 1, 6)
	else
		chat.AddText(Color(255, 190, 90), "Tu choisiras ton art en devenant Arrancar. Garde tes rerolls.")
	end
end

function ToggleRerollMenu()
	if IsValid(frame) then
		frame:Close()
	else
		if EnProgressionHollow() then RefusProgression() return end
		frame = vgui.Create("lzy_reroll")
	end
end

-- Ouvre la roulette de reroll DIRECTEMENT sur une catégorie (ex. "style_de_combat" pour le flux
-- Maître d'Armes -> le joueur dépense son reroll offert tout de suite). Ferme une roulette déjà
-- ouverte puis en (r)ouvre une neuve présélectionnée sur la catégorie.
function LZY_Reroll_Open(startCategory)
	if EnProgressionHollow() then RefusProgression() return end
	if IsValid(frame) then frame:Close() end
	LZY_Reroll_StartCategory = isstring(startCategory) and startCategory or nil
	frame = vgui.Create("lzy_reroll")
end
