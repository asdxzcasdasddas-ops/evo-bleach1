-- "addons\\lzy_reroll\\lua\\lzy_reroll\\cl_cutscene.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- CUTSCENE DE DROP (26/07/26)
--
-- DEUX effets INDÉPENDANTS, à deux moments différents du tirage :
--
--   1. L'ÉTOILE — au clic sur « reroll », ~1,3 s, fond TRANSPARENT, AUX COULEURS
--      DE LA RARETÉ qui arrive (cf. EVO_Cutscene.CouleursRarete).
--      La roue reste visible derrière : c'est une ponctuation, pas un écran.
--      Purement décorative, elle ne bloque ni la souris ni le clavier.
--      MakePopup est indispensable : le menu de reroll est lui-même un popup et
--      GMod dessine tous les popups au-dessus du reste. Souris et clavier sont
--      recoupés juste après.
--
--   2. LA VIDÉO — plein écran, lancée EVO_Cutscene.AvantArrivee s AVANT que
--      la roue ne tombe (5 s, valeur mesurée : cf. le commentaire de la constante).
--      Elle recouvre la roue avant l'arrivée, donc le joueur ne voit jamais son
--      drop avant la vidéo. C'est tout l'intérêt.
--
-- Le navigateur intégré de GMod est un Chromium SANS codecs propriétaires :
-- WebM (VP9 + Opus) obligatoire, le MP4 et le HEVC donnent un écran noir.
--
-- PERFORMANCE : GMod rend la page en LOGICIEL. On n'anime donc QUE `transform`
-- et `opacity` — jamais un filtre, jamais une ombre portée. Un drop-shadow
-- animé faisait tomber l'animation à ~5 images par seconde.
--
-- RÈGLE INTANGIBLE : la cutscene ne doit JAMAIS empêcher le joueur de voir son
-- drop. Vidéo qui ne charge pas, connexion lente, serveur web indisponible : on
-- referme et le reroll continue. Les rappels partent UNE fois, quoi qu'il arrive.
-- ============================================================================
if not CLIENT then return end

EVO_Cutscene = EVO_Cutscene or {}

-- win_id EXACT -> URL de la vidéo. Ajouter une ligne suffit.
--
-- ⚠️ LA CASSE EST SIGNIFICATIVE, et ce n'est pas un détail de style : les win_id
-- se RÉPÈTENT d'une catégorie à l'autre et seule la casse les sépare.
--     Aizen  = art spirituel MYTHIQUE      ·  aizen  = couleur de reiatsu légendaire
--     Ichigo = art spirituel LÉGENDAIRE    ·  ichigo = couleur de reiatsu épique
-- Tant que la recherche passait tout en minuscules, la cutscene d'Aizen se
-- déclenchait AUSSI quand on tirait la simple aura du même nom. La comparaison
-- est donc exacte (cf. EVO_Cutscene.A) — ne PAS remettre de string.lower ici.
-- Les sept entrées ci-dessous sont toutes des ART SPIRITUEL. Le piège de casse
-- vaut aussi pour les deux dernières : « stark » (minuscule) est une couleur de
-- reiatsu ÉPIQUE et « halibel » une couleur RARE ; l'art spirituel s'écrit
-- CoyoteStarrk et TierHarribel. « Encre » (art SECRET) n'a pas d'homonyme : le
-- catalyseur « Reiatsu abyssal » s'ecrit 06_encre.
--
-- Le ?v= n'est pas décoratif : Cloudflare met les réponses en cache, y compris
-- les 404 servis avant la mise en ligne d'un fichier. Sans ce suffixe, une
-- vidéo tout juste ajoutée reste introuvable pour les joueurs le temps que le
-- cache expire. Incrémenter le numéro suffit aussi à publier une nouvelle
-- version d'une vidéo existante.
EVO_Cutscene.Videos = {
	["Aizen"]             = "https://evo-roleplay.com/BleachRP/video/aizen_cutscene.webm",     -- mythique, Shinigami
	["Yamamoto"]          = "https://evo-roleplay.com/BleachRP/video/yamamoto_cutscene.webm",  -- mythique, Shinigami
	["Ichigo"]            = "https://evo-roleplay.com/BleachRP/video/instinct_cutscene.webm",  -- « Instinct », LÉGENDAIRE, Shinigami
	["UlquirorraShifter"] = "https://evo-roleplay.com/BleachRP/video/ulquiorra_cutscene.webm", -- légendaire, Hollow
	["CoyoteStarrk"]      = "https://evo-roleplay.com/BleachRP/video/starrk_cutscene.webm?v=1",   -- MYTHIQUE, Hollow
	["TierHarribel"]      = "https://evo-roleplay.com/BleachRP/video/harribel_cutscene.webm?v=1", -- légendaire, Hollow
	["Encre"]             = "https://evo-roleplay.com/BleachRP/video/encre_cutscene.webm?v=1",    -- SECRET, Shinigami et Hollow (Ichibei)
}

-- ── COULEUR DE L'ÉTOILE, PAR RARETÉ ─────────────────────────────────────────
-- L'étoile reprend la couleur de ce que le joueur est en train de gagner, au
-- lieu du rouge unique d'origine. Un rouge fixe mentait dès qu'on a eu des
-- cutscenes de raretés différentes : Aizen et Yamamoto sont MYTHIQUES (rouge),
-- Instinct et Ulquiorra sont LÉGENDAIRES (jaune). Tout annoncer en rouge
-- promettait du mythique à chaque fois.
--
-- Les teintes suivent REROLL_DROPS_RARITIES (sh_config) : commun gris, rare
-- cyan, épique violet, légendaire jaune, mythique rouge.
--
-- On ne stocke QUE des triplets RVB, et l'hexadécimal en est dérivé : garder
-- les deux écritures à la main les aurait fait diverger à la première retouche.
EVO_Cutscene.CouleursRarete = {
	commun    = { sombre = "90,97,107",   moyen = "148,155,166", clair = "226,230,234" },
	rare      = { sombre = "21,131,160",  moyen = "53,198,232",  clair = "210,245,255" },
	epique    = { sombre = "109,47,181",  moyen = "168,107,240", clair = "234,217,255" },
	legendary = { sombre = "201,145,26",  moyen = "255,201,63",  clair = "255,242,204" },
	mythique  = { sombre = "207,68,78",   moyen = "255,107,115", clair = "255,218,220" },
	secret    = { sombre = "15,138,106",  moyen = "47,224,171",  clair = "211,255,240" },
}
EVO_Cutscene.RareteParDefaut = "mythique"

local function versHex(sRvb)
	local r, g, b = string.match(tostring(sRvb or ""), "(%d+),%s*(%d+),%s*(%d+)")
	if not r then return "#ffffff" end
	return string.format("#%02x%02x%02x", tonumber(r), tonumber(g), tonumber(b))
end

--- Palette de l'étoile pour une rareté. Repli sur la rareté par défaut : une
--- rareté inconnue doit donner une étoile normale, jamais une étoile invisible.
function EVO_Cutscene.Palette(sRarete)
	local t = EVO_Cutscene.CouleursRarete
	return (t and t[string.lower(tostring(sRarete or ""))])
		or (t and t[EVO_Cutscene.RareteParDefaut])
		or { sombre = "207,68,78", moyen = "255,107,115", clair = "255,218,220" }
end

-- SKIP : DÉSACTIVÉ (26/07, demande user). La vidéo démarre AvantArrivee secondes
-- avant que la roue ne tombe ; l'interrompre découvre donc la fin du défilement et
-- le joueur voit son drop arriver — exactement ce que la cutscene existe pour
-- cacher. En spammant la touche on tombait dessus à tous les coups.
-- Le mécanisme est conservé, seulement débrayé : repasser à true le réactive, et il
-- garde alors sa règle d'origine (skip permis à partir du 2e visionnage seulement).
-- ⚠️ Ne PAS confondre avec un blocage : les filets CHARGEMENT_MAX et SECURITE_MAX
-- ferment toujours la cutscene si la vidéo ne démarre pas ou se fige. Un joueur ne
-- peut donc jamais rester coincé, il n'a simplement plus la main pour abréger.
EVO_Cutscene.SkipAutorise = false

local ETOILE_DUREE   = 1.3    -- s : durée de l'étoile au clic
-- Avance de la VIDÉO sur l'arrivée de la roue. C'est LE réglage de mise en
-- scène : la vidéo doit recouvrir la roue tant qu'elle DÉFILE ENCORE, sinon le
-- joueur a déjà lu son drop et la vidéo ne révèle plus rien.
--
-- Pourquoi 5 s et pas 1,5 (26/07, mesuré) : la roue ralentit en easeOutExpo,
-- une courbe très brutale. Elle a fait 90 % du chemin en 3 s, 95 % en 4 s, et
-- 99,7 % à 7,5 s. Autrement dit elle est VISUELLEMENT À L'ARRÊT bien avant de
-- s'arrêter vraiment. Une avance de 1,5 s couvrait donc une roue figée : le
-- joueur voyait son drop, exactement le contraire du but.
-- Vitesse restante selon l'instant : 9,9 % à 3 s · 4,6 % à 4 s · 2,1 % à 5 s.
-- À 4 s (avance 5 s) elle défile encore assez pour rester illisible.
EVO_Cutscene.AvantArrivee = 5.0   -- s
local CHARGEMENT_MAX = 6      -- s : rien n'a démarré -> on abandonne
local SECURITE_MAX   = 30     -- s : filet absolu si la vidéo se fige
local FONDU          = 0.35   -- s : fondu au noir en sortie de vidéo
local VOLUME_VIDEO   = 0.75   -- 0 à 1. On ne touche PAS au volume du jeu :
                              -- GMod bloque la commande, et un plantage aurait
                              -- laissé le joueur avec le son coupé.

local _frame          -- panneau VIDÉO (un seul à la fois)
local _etoile         -- panneau ÉTOILE (indépendant du précédent)
-- Rappels à exécuter à la FIN de la vidéo. Une FILE, parce que le lancement et
-- la révélation sont deux moments distincts : la révélation arrive typiquement
-- PENDANT la vidéo.
local _rappels = {}

local function cleVue(sWinId)
	return "evo_cutscene_vue_" .. string.lower(tostring(sWinId or ""))
end

--- A-t-il DÉJÀ vu cette cutscene ? Sert à n'autoriser le skip qu'à partir du
--- deuxième visionnage : la première fois c'est un moment, la dixième une corvée.
function EVO_Cutscene.DejaVue(sWinId)
	return tonumber(cookie.GetString(cleVue(sWinId), "0")) == 1
end

local function marquerVue(sWinId)
	cookie.Set(cleVue(sWinId), "1")
end

----------------------------------------------------------------------
-- 1. L'ÉTOILE (au clic sur reroll)
----------------------------------------------------------------------

--- Éclat d'environ ETOILE_DUREE secondes, par-dessus la roue, AUX COULEURS DE
--- LA RARETÉ annoncée (cf. EVO_Cutscene.CouleursRarete). `sRarete` est optionnel :
--- sans lui on retombe sur la rareté par défaut, l'étoile s'affiche quand même.
--- Décoratif : ne bloque rien, ne renvoie rien, ne rappelle personne.
function EVO_Cutscene.Etoile(sRarete)
	if IsValid(_etoile) then _etoile:Remove() end

	_etoile = vgui.Create("DPanel")
	_etoile:SetSize(ScrW(), ScrH())
	_etoile:SetPos(0, 0)
	_etoile:SetPaintBackground(false)
	-- MakePopup EST NÉCESSAIRE (26/07) : le menu de reroll est lui-même un popup,
	-- et GMod dessine TOUS les popups au-dessus des panneaux ordinaires. Sans ça
	-- l'étoile passait DERRIÈRE le menu — invisible pendant un vrai tirage, alors
	-- qu'elle s'affichait bien via la commande de test, menu fermé.
	-- On coupe la souris et le clavier JUSTE APRÈS : MakePopup les active, or ce
	-- panneau doit rester purement décoratif et laisser le joueur cliquer.
	_etoile:MakePopup()
	_etoile:SetMouseInputEnabled(false)
	_etoile:SetKeyboardInputEnabled(false)
	_etoile:SetZPos(32767)

	local html = vgui.Create("DHTML", _etoile)
	html:SetSize(ScrW(), ScrH())
	html:SetPos(0, 0)
	html:SetAllowLua(false)
	html:SetMouseInputEnabled(false)

	local sD = tostring(ETOILE_DUREE)
	local P  = EVO_Cutscene.Palette(sRarete)
	local rgbSombre, rgbMoyen, rgbClair = P.sombre, P.moyen, P.clair
	local hexSombre, hexMoyen, hexClair = versHex(rgbSombre), versHex(rgbMoyen), versHex(rgbClair)

	-- Fond transparent : la roue continue de défiler derrière.
	html:SetHTML([[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
  html,body{margin:0;padding:0;background:transparent;overflow:hidden;
            width:100%;height:100%;}
  /* Centrage en PIXELS : `inset` et les unités `vh` sont mal supportés ici, le
     conteneur se retrouvait sans dimensions et tout partait en haut à gauche. */
  .c{position:absolute;top:50%;left:50%;}

  /* La lueur est un dégradé radial FIXE, pas un filtre : un drop-shadow animé
     force un flou plein écran recalculé à chaque image, en logiciel. */
  /* Voile LÉGER aux couleurs de la rareté : sans lui l'étoile se noyait dans
     le menu de reroll, qui est lumineux et chargé. Semi-transparent, la roue
     reste parfaitement lisible derrière. */
  #voile{position:absolute;top:0;left:0;width:100%;height:100%;
         background:]] .. hexSombre .. [[;opacity:0;will-change:opacity;
         animation:voile ]] .. sD .. [[s ease-out forwards;}
  @keyframes voile{0%{opacity:0;}18%{opacity:.34;}100%{opacity:0;}}

  #lueur{width:820px;height:820px;margin:-410px 0 0 -410px;border-radius:50%;
         background:radial-gradient(closest-side,rgba(]] .. rgbClair .. [[,.95),rgba(]] .. rgbSombre .. [[,.45) 38%,rgba(0,0,0,0) 72%);
         opacity:0;will-change:transform,opacity;
         animation:pop ]] .. sD .. [[s cubic-bezier(.15,.85,.3,1) forwards;}

  #onde{width:360px;height:360px;margin:-180px 0 0 -180px;border-radius:50%;
        border:3px solid rgba(]] .. rgbClair .. [[,.95);opacity:0;will-change:transform,opacity;
        animation:onde ]] .. sD .. [[s cubic-bezier(.1,.75,.25,1) forwards;}
  @keyframes onde{
    0%{opacity:.95;transform:scale(.25);}
    100%{opacity:0;transform:scale(3.4);}
  }

  #eclat{width:760px;height:760px;margin:-380px 0 0 -380px;opacity:0;
         will-change:transform,opacity;
         animation:pop ]] .. sD .. [[s cubic-bezier(.15,.85,.3,1) forwards;}
  @keyframes pop{
    0%{opacity:0;transform:scale(.12) rotate(-70deg);}
    28%{opacity:1;transform:scale(1.12) rotate(3deg);}
    45%{opacity:1;transform:scale(.98) rotate(0deg);}
    100%{opacity:0;transform:scale(1.9) rotate(0deg);}
  }
</style></head><body>
  <div id="voile"></div>
  <div class="c" id="lueur"></div>
  <div class="c" id="onde"></div>
  <svg class="c" id="eclat" viewBox="-100 -100 200 200">
    <defs>
      <radialGradient id="g" cx="50%" cy="50%" r="50%">
        <stop offset="0%"   stop-color="#ffffff"/>
        <stop offset="16%"  stop-color="]] .. hexClair .. [["/>
        <stop offset="40%"  stop-color="]] .. hexMoyen .. [["/>
        <stop offset="100%" stop-color="]] .. hexSombre .. [["/>
      </radialGradient>
    </defs>
    <g transform="rotate(45)" opacity="0.7">
      <path d="M0,-45 Q6,-11 0,0 Q-6,-11 0,-45 Z" fill="url(#g)"/>
      <path d="M45,0 Q11,6 0,0 Q11,-6 45,0 Z" fill="url(#g)"/>
      <path d="M0,45 Q-6,11 0,0 Q6,11 0,45 Z" fill="url(#g)"/>
      <path d="M-45,0 Q-11,-6 0,0 Q-11,6 -45,0 Z" fill="url(#g)"/>
    </g>
    <path d="M0,-99 Q7.5,-16 0,0 Q-7.5,-16 0,-99 Z" fill="url(#g)"/>
    <path d="M99,0 Q16,7.5 0,0 Q16,-7.5 99,0 Z" fill="url(#g)"/>
    <path d="M0,99 Q-7.5,16 0,0 Q7.5,16 0,99 Z" fill="url(#g)"/>
    <path d="M-99,0 Q-16,-7.5 0,0 Q-16,7.5 -99,0 Z" fill="url(#g)"/>
    <circle r="7.5" fill="#fff"/>
    <circle r="15" fill="#fff" opacity="0.28"/>
  </svg>
</body></html>]])

	-- Petite marge après la fin de l'animation avant de retirer le panneau.
	timer.Simple(ETOILE_DUREE + 0.3, function()
		if IsValid(_etoile) then _etoile:Remove() end
		_etoile = nil
	end)
end

----------------------------------------------------------------------
-- 2. LA VIDÉO
----------------------------------------------------------------------

--- Ferme la vidéo : fondu, puis vidange de la file de rappels.
local function fermer(bImmediat)
	local function final()
		hook.Remove("Think", "EVO_Cutscene::Skip")
		hook.Remove("OnPauseMenuShow", "EVO_Cutscene::NoMenu")
		if IsValid(_frame) then _frame:Remove() end
		_frame = nil
		-- On COPIE puis on vide AVANT d'exécuter : un rappel qui relancerait une
		-- cutscene ne doit pas voir sa propre entrée dans la file.
		local t = _rappels
		_rappels = {}
		for i = 1, #t do
			local ok, err = pcall(t[i])
			if not ok then ErrorNoHalt("[cutscene] rappel en erreur : " .. tostring(err) .. "\n") end
		end
	end
	if bImmediat or not IsValid(_frame) then return final() end

	local pVoile = vgui.Create("DPanel", _frame)
	pVoile:SetSize(ScrW(), ScrH())
	pVoile:SetPos(0, 0)
	pVoile:SetMouseInputEnabled(false)
	local nDebut = SysTime()
	pVoile.Paint = function(_, w, h)
		local a = math.Clamp((SysTime() - nDebut) / FONDU, 0, 1) * 255
		surface.SetDrawColor(0, 0, 0, a)
		surface.DrawRect(0, 0, w, h)
	end
	timer.Simple(FONDU, final)
end

--- Une vidéo est-elle à l'écran ?
function EVO_Cutscene.EstEnCours()
	return IsValid(_frame)
end

--- Existe-t-il une vidéo pour ce drop ?
--- Existe-t-il une cutscene pour ce win_id ? Comparaison EXACTE : la casse
--- distingue l'art spirituel de la couleur de reiatsu du meme nom.
function EVO_Cutscene.A(sWinId)
	return EVO_Cutscene.Videos[tostring(sWinId or "")] ~= nil
end

--- Exécute fRappel À LA FIN de la vidéo. Si aucune ne tourne, le rappel part
--- IMMÉDIATEMENT. L'appelant n'a donc pas à savoir si une vidéo existe.
function EVO_Cutscene.QuandFini(fRappel)
	if not fRappel then return end
	if IsValid(_frame) then
		_rappels[#_rappels + 1] = fRappel
		return
	end
	fRappel()
end

--- Démarre la vidéo de sWinId, plein écran. Ne porte aucun rappel : passer par
--- QuandFini. Renvoie true si une vidéo a été lancée.
function EVO_Cutscene.Lancer(sWinId)
	local sUrl = EVO_Cutscene.Videos[tostring(sWinId or "")]  -- casse EXACTE, cf. le tableau
	if not sUrl or IsValid(_frame) then return false end

	-- Le rappel ne doit partir QU'UNE FOIS : fin de vidéo, skip, erreur et délai
	-- peuvent se croiser.
	local bFini = false
	local function terminer(bImmediat)
		if bFini then return end
		bFini = true
		marquerVue(sWinId)
		fermer(bImmediat)
	end

	-- Débrayé globalement (cf. EVO_Cutscene.SkipAutorise). La condition « déjà vue »
	-- reste évaluée derrière, pour que réactiver l'option retrouve le comportement d'avant.
	local bSkipAutorise = (EVO_Cutscene.SkipAutorise == true) and EVO_Cutscene.DejaVue(sWinId)

	_frame = vgui.Create("DFrame")
	_frame:SetSize(ScrW(), ScrH())
	_frame:SetPos(0, 0)
	_frame:SetTitle("")
	_frame:ShowCloseButton(false)
	_frame:SetDraggable(false)
	_frame:MakePopup()
	_frame.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(0, 0, w, h)
	end

	-- ENTRÉE pour passer. Échap est avalé par le jeu avant d'atteindre le VGUI,
	-- et le DHTML enfant capte le clavier : ni OnKeyCodePressed ni OnPauseMenuShow
	-- n'étaient fiables. `input.IsKeyDown` dans un Think lit le clavier BRUT.
	-- On exige un relâchement avant de compter l'appui, sinon une touche déjà
	-- maintenue au lancement passerait la vidéo dans la même frame.
	local bRelachee = not (input.IsKeyDown(KEY_ENTER) or input.IsKeyDown(KEY_PAD_ENTER))
	hook.Add("Think", "EVO_Cutscene::Skip", function()
		if not IsValid(_frame) then
			hook.Remove("Think", "EVO_Cutscene::Skip")
			return
		end
		local bAppui = input.IsKeyDown(KEY_ENTER) or input.IsKeyDown(KEY_PAD_ENTER)
		if not bAppui then bRelachee = true return end
		if bRelachee and bSkipAutorise then terminer() end
	end)
	-- Le menu du jeu ne doit pas s'ouvrir par-dessus la vidéo.
	hook.Add("OnPauseMenuShow", "EVO_Cutscene::NoMenu", function()
		if not IsValid(_frame) then
			hook.Remove("OnPauseMenuShow", "EVO_Cutscene::NoMenu")
			return
		end
		return false
	end)

	local html = vgui.Create("DHTML", _frame)
	html:SetSize(ScrW(), ScrH())
	html:SetPos(0, 0)
	html:SetAllowLua(false)

	-- Pont JS -> Lua, déclaré AVANT SetHTML pour exister dès le 1er script.
	html:AddFunction("evo", "fin", function() terminer() end)
	html:AddFunction("evo", "erreur", function() terminer(true) end)
	html:AddFunction("evo", "demarre", function() if IsValid(_frame) then _frame._aDemarre = true end end)

	html:SetHTML([[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
  html,body{margin:0;padding:0;background:#000;overflow:hidden;width:100%;height:100%;}
  video{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain;
        background:#000;opacity:0;transition:opacity .3s;}
  video.on{opacity:1;}
  #skip{position:absolute;right:32px;bottom:26px;color:rgba(255,255,255,.6);
        font:600 15px/1 Arial,sans-serif;letter-spacing:.08em;text-transform:uppercase;
        opacity:0;transition:opacity .6s;}
</style></head><body>
  <video id="v" autoplay playsinline preload="auto"></video>
  <div id="skip">Entrée pour passer</div>
<script>
  var v = document.getElementById('v');
  var fini = false;
  function stop(ok){ if(fini) return; fini = true; ok ? evo.fin() : evo.erreur(); }
  v.addEventListener('playing', function(){ evo.demarre(); v.classList.add('on'); });
  v.addEventListener('ended',  function(){ stop(true); });
  v.addEventListener('error',  function(){ stop(false); });
  v.volume = ]] .. tostring(VOLUME_VIDEO) .. [[;
  v.src = ']] .. sUrl .. [[';
  v.play().catch(function(){ stop(false); });
  ]] .. (bSkipAutorise and [[
  setTimeout(function(){ document.getElementById('skip').style.opacity = 1; }, 900);
  ]] or "") .. [[
</script></body></html>]])

	-- FILET 1 : la vidéo n'a jamais commencé -> on n'immobilise pas le joueur.
	timer.Simple(CHARGEMENT_MAX, function()
		if bFini then return end
		if IsValid(_frame) and _frame._aDemarre then return end
		terminer(true)
	end)
	-- FILET 2 : elle a démarré mais s'est figée. Absolu.
	timer.Simple(SECURITE_MAX, function() terminer(true) end)

	return true
end

--- Compat : lance ET attend la fin. Le rappel part immédiatement s'il n'y a pas
--- de vidéo pour ce drop.
function EVO_Cutscene.Jouer(sWinId, fRappel)
	local b = EVO_Cutscene.Lancer(sWinId)
	EVO_Cutscene.QuandFini(fRappel)
	return b
end

concommand.Add("evo_cutscene_test", function(_, _, args)
	EVO_Cutscene.Jouer(args[1] or "Aizen", function() print("[cutscene] terminee") end)
end)

-- evo_etoile_test [rarete] : « commun », « rare », « epique », « legendary »,
-- « mythique », « secret ». Sans argument -> rareté par défaut.
concommand.Add("evo_etoile_test", function(_, _, args)
	EVO_Cutscene.Etoile(args[1])
end)

-- Remet à zéro le « déjà vue » pour retester le comportement du premier visionnage.
concommand.Add("evo_cutscene_reset", function(_, _, args)
	cookie.Set(cleVue(args[1] or "Aizen"), "0")
	print("[cutscene] marquee comme jamais vue : " .. (args[1] or "Aizen"))
end)

-- Trace de diagnostic : `evo_cutscene_debug 1` puis un reroll, et la console dit
-- quel drop est tombe, si une video existe, et quand elle est planifiee.
CreateClientConVar("evo_cutscene_debug", "0", true, false,
	"Affiche le deroule de la cutscene de reroll dans la console")
