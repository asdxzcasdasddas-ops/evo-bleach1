-- "addons\\lzy_reroll\\lua\\lzy_reroll\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
REROLL_DEBUG = false

-- ════════════════════════════════════════════════════════════════════════════
-- NOM DU POUVOIR D'UN ART SPIRITUEL (source UNIQUE, 26/07/26)
-- En RP, un personnage n'a pas « Unohana » : il a le SANG. On affiche donc le
-- pouvoir, pas le personnage de Bleach dont l'art est inspire.
--
-- Cette table vivait EN DOUBLE, en `local`, dans lzy_reroll/vgui/main.lua et
-- lzy_skilltree/vgui/category.lua. Le panneau de recreation de perso
-- (evo_lost_soul), lui, n'en avait aucune copie et affichait donc le nom brut
-- « Unohana » — c'est exactement le bug remonte. Une seule table partagee, ici,
-- dans un fichier SHARED : plus de copie a oublier.
-- ════════════════════════════════════════════════════════════════════════════
EVO_ART_POWER_FR = {
	-- Hollow
	yammyllargo          = "Col\195\168re",
	aaronarrurerie       = "Absorption",
	granzszayel          = "Parasite",
	zommari              = "Contr\195\180le",
	grimmjowjaegerjaquez = "Sauvage",
	noitoragilga         = "Brutalit\195\169",
	ulquirorrashifter    = "Ab\195\174me",
	tierharribel         = "Eau",
	barraganluisenbarn   = "Corrosion",
	coyotestarrk         = "Chasseur",
	-- Shinigami
	ikkaku               = "Ardeur",
	hitsugaya            = "Glace",
	byakuya              = "P\195\169tales",
	soifon               = "Assassin",
	urahara              = "Ruse",
	unohana              = "Sang",
	ichigo               = "Instinct",
	kenpachi             = "Furie",
	yamamoto             = "Flamme",
	aizen                = "Illusion",
	raijin               = "Tonnerre", -- art épique Shinigami (09/28, épique depuis le 10/01)
	cristal              = "Cristaux", -- art légendaire Hollow (09/28)
	carcasse             = "Carcasse", -- art épique Hollow (09/29, faction corrigée 09/30)
	plantes              = "Plantes", -- art légendaire Shinigami (09/29, légendaire depuis le 10/01)
	encre                = "Encre", -- art SECRET, Shinigami ET Hollow (Ichibei, 10/06)
}

-- Finishers AU POING (10/10, user : noms hakuda ≠ katana). Même win_id, chorégraphie POINGS
-- de sv_finisher_duos. AFFICHAGE seulement : le tirage serveur compare toujours drop.name.
REROLL_FINISHER_NOMS_POING = {
	["Commun"] = "Sentence sèche", ["Commun2"] = "Balayage éclair",
	["Rare"] = "Double impact", ["Rare2"] = "Contre brutal",
	["Epique"] = "Rafale brisante", ["Epique2"] = "Spirale de fer",
	["Légendaire"] = "Ascension fatale", ["Légendaire2"] = "Impact céleste",
	["Mythique"] = "Danse du jugement", ["Mythique2"] = "Chute du souverain",
}

--- Nom affiché d'un drop pour ce joueur (finisher au poing si sa famille est hakuda).
function REROLL_DropNom(drop, category, ply)
	if not drop then return "" end
	if category == "style_execution" and IsValid(ply) and EvoStyle and EvoStyle.GetPlayerFamily
		and EvoStyle.GetPlayerFamily(ply) == "hakuda" then
		return REROLL_FINISHER_NOMS_POING[drop.win_id] or drop.name or ""
	end
	return drop.name or ""
end

--- Apercu anime d'un drop pour ce joueur : la choregraphie AU POING si sa famille est hakuda
--- et que le drop en a une (hover_gif_poing, finishers refaits le 10/10), sinon hover_gif.
function REROLL_DropApercu(drop, ply)
	if not drop then return nil end
	if drop.hover_gif_poing and IsValid(ply) and EvoStyle and EvoStyle.GetPlayerFamily
		and EvoStyle.GetPlayerFamily(ply) == "hakuda" then
		return drop.hover_gif_poing
	end
	return drop.hover_gif
end

--- Nom affichable d'un art spirituel a partir de son win_id.
--- Repli sur `sDefaut` (souvent drop.name) puis sur l'identifiant : mieux vaut
--- afficher « Unohana » qu'une case vide si un art n'est pas encore mappe.
function EVO_ArtPowerName(sWinId, sDefaut)
	if sWinId and sWinId ~= "" then
		local fr = EVO_ART_POWER_FR[string.lower(tostring(sWinId))]
		if fr then return fr end
	end
	if sDefaut and sDefaut ~= "" then return sDefaut end
	return tostring(sWinId or "")
end


REROLL_PITY_STEP_ROLLS = 10 -- Nombre de rerolls pour passer au niveau de pity suivant.
-- Facteur de boost PAR DÉFAUT (utilisé seulement pour une rareté réglée à `true` ci-dessous).
REROLL_PITY_BOOST_PER_LEVEL = 0.05
-- Boost de pity PAR RARETÉ, désormais MULTIPLICATIF (avant : additif -> le mythique explosait,
-- 0.01% -> 0.06% dès le 1er niveau). À pity level N, le poids de la rareté est multiplié par
-- (1 + N * facteur), PUIS commun+rare sont réduits pour garder la somme constante. Petit facteur
-- = monte peu. Réglé pour que les hautes raretés montent MODÉRÉMENT : mythique le moins (doit
-- rester rare), légendaire un peu, épique un peu plus. (Mettre `true` = utilise le défaut.)
REROLL_PITY_BOOST_RARITIES = {
	-- Gains de pity par niveau, augmentés très légèrement (demande user 2026-07-21).
	epique    = 0.09,  -- 0.08 -> 0.09
	legendary = 0.05,  -- 0.04 -> 0.05
	mythique  = 0.025, -- 0.02 -> 0.025 (reste le plus bas des hautes raretés hors secret)
	-- Secret : MULTIPLICATIF 0.02 (demande user « il ne doit PAS dépasser le mythique »). INCHANGÉ
	-- volontairement : base secret 0.003 < base mythique 0.008 ET facteur secret 0.02 < facteur
	-- mythique 0.025 -> le ratio secret/mythique part de ~37,5% (pity 0) et DÉCROÎT avec la pity ->
	-- le secret ne dépasse JAMAIS le mythique, tout en montant un peu (poids à pity N = 0.003*(1+0.02*N)).
	-- Un ADDITIF serait incompatible (pente linéaire -> finit toujours par croiser le mythique) : garder
	-- du multiplicatif. Marge : le secret pourrait aller jusqu'à ~0.075 sans dépasser, on reste à 0.02.
	secret    = 0.02,
}
-- Boost de pity ADDITIF (+X au POIDS par niveau de pity). Format {amount, every} = +amount tous les
-- `every` niveaux (1 niveau = 10 rerolls). VIDE : le secret est en MULTIPLICATIF ci-dessus (un additif
-- finit toujours par faire dépasser le mythique). ⚠ Ne pas y remettre le secret en additif.
REROLL_PITY_BOOST_ADD = {
}
REROLL_PITY_RESET_ON_RARITIES = { -- Rarities that reset pity rolls to 0 when rolled.
	legendary = true,
	mythique = true,
	secret = true,
}
-- Duree de vie (secondes) d'une confirmation GARDER / REMPLACER laissee sans reponse.
-- Passe ce delai le serveur cesse de BLOQUER les nouveaux tirages (et oublie la
-- confirmation au prochain clic reroll). Une reponse OUI/NON est toujours honoree
-- TANT QUE cette confirmation n'a pas ete ecrasee : le joueur qui reflechit 1-2 min
-- devant la popup ne doit pas perdre son tirage. Le TTL ne sert qu'a deverrouiller
-- le bouton, pas a invalider un clic encore pose sur la meme confirmation.
REROLL_PENDING_DECISION_TTL = 120

REROLL_DROPS_RARITIES = REROLL_DROPS_RARITIES or {}
-- Baisse globale ~30% des taux au-dessus de commun (demande user 2026-07-18) : rare et plus
-- multipliés par 0.7 (15->10.5, 1->0.7, 0.1->0.07, 0.01->0.007, secret 0.001->0.0007) ;
-- commun absorbe la différence pour garder commun+rare+epique+leg+myth = 100 (les % affichés
-- restent exacts, secret reste un chouia au-dessus comme avant).
REROLL_DROPS_RARITIES = {
	["commun"] = {
	    ["color"] = "gray",
	    ["weight"] = 88.7197, -- ajusté pour somme 100 (mythique 0.006->0.008 ; secret 0.003)
	},
	["rare"] = {
	    ["color"] = "cyan",
	    ["weight"] = 10.5,
	},
	["epique"] = {
	    ["color"] = "purple",
	    ["weight"] = 0.7,
	},
	["legendary"] = {
	    ["color"] = "yellow",
	    ["weight"] = 0.07,
	},
	["mythique"] = {
	    ["color"] = "red",
	    ["weight"] = 0.008, -- 0.006 -> 0.008 (demande user 2026-07-21 : taux mythique augmenté légèrement). RESTE > secret 0.003 (~37,5%).
	},
	["secret"] = { -- rarete au-dessus de mythique (style de combat "Secret1")
	    ["color"] = "secret",
	    ["weight"] = 0.003, -- taux de BASE du secret (demande user 2026-07-21 ; commun ajusté pour somme 100)
	},
}

-- Poids de rareté SPÉCIFIQUES PAR CATÉGORIE (override des poids globaux ci-dessus, par rareté).
-- Une rareté listée ici remplace son poids global POUR CETTE CATÉGORIE ; les raretés non listées
-- gardent le poids global. (Auras = reiatsu_color : épique/légendaire/mythique plus généreux —
-- demande user. La somme commun+rare+epique+leg+myth = 100 -> les % affichés sont exacts.)
REROLL_DROPS_RARITIES_BY_CATEGORY = REROLL_DROPS_RARITIES_BY_CATEGORY or {}
-- Taux "généreux" PARTAGÉS par les auras (reiatsu_color) ET les styles d'exécution
-- (demande user : le style d'exécution doit avoir les mêmes taux que la couleur de reiatsu).
-- Baisse ~30% ici aussi (demande user 2026-07-18) : 15->10.5, 5->3.5, 1->0.7, 0.1->0.07 ;
-- commun absorbe (85.23) pour garder la somme = 100 -> % affichés exacts.
local _GENEROUS_RARITIES = {
	["commun"]    = 85.23,
	["rare"]      = 10.5,
	["epique"]    = 3.5,
	["legendary"] = 0.7,
	["mythique"]  = 0.07,
}
REROLL_DROPS_RARITIES_BY_CATEGORY = {
	["reiatsu_color"]   = _GENEROUS_RARITIES,
	["style_execution"] = _GENEROUS_RARITIES,
	["catalyseur"]      = _GENEROUS_RARITIES, -- cosmétique, mêmes taux que le style d'exécution
}

-- Poids de base d'une rareté pour une catégorie : override par catégorie si défini, sinon global.
function REROLL_GetRarityWeight(rarity, category)
	local byCat = category and REROLL_DROPS_RARITIES_BY_CATEGORY and REROLL_DROPS_RARITIES_BY_CATEGORY[category]
	if byCat and byCat[rarity] ~= nil then return math.max(0, tonumber(byCat[rarity]) or 0) end
	local g = REROLL_DROPS_RARITIES and REROLL_DROPS_RARITIES[rarity]
	return g and math.max(0, tonumber(g.weight) or 0) or 0
end

-- Facteur de boost de pity (multiplicatif / niveau) d'une rareté. `true` (legacy) -> défaut global.
function REROLL_GetPityBoostFactor(rarity)
	local b = REROLL_PITY_BOOST_RARITIES and REROLL_PITY_BOOST_RARITIES[rarity]
	if b == nil or b == false then return 0 end
	if b == true then return math.max(0, tonumber(REROLL_PITY_BOOST_PER_LEVEL) or 0) end
	return math.max(0, tonumber(b) or 0)
end

-- Boost ADDITIF de pity d'une rareté. Renvoie (amount, every) : +amount au poids tous les
-- `every` niveaux de pity. Accepte un nombre (every=1) ou une table {amount, every}.
function REROLL_GetPityBoostAdd(rarity)
	local a = REROLL_PITY_BOOST_ADD and REROLL_PITY_BOOST_ADD[rarity]
	if not a then return 0, 1 end
	if istable(a) then
		return math.max(0, tonumber(a.amount) or 0), math.max(1, math.floor(tonumber(a.every) or 1))
	end
	return math.max(0, tonumber(a) or 0), 1
end

-- Applique la pity à des poids de base (MULTIPLICATIF par rareté) puis absorbe le surplus en
-- réduisant UNIQUEMENT commun+rare (les hautes raretés gardent leur boost). Somme conservée.
-- SOURCE UNIQUE utilisée par le client (affichage) ET le serveur (tirage) -> les % affichés
-- correspondent aux vraies chances. baseWeights : table rareté->poids ; pityLevel : entier >= 0.
function REROLL_ComputeAdjustedWeights(baseWeights, pityLevel)
	local adjusted = {}
	local hasBoost = false
	local baseTotal = 0
	pityLevel = math.max(0, math.floor(tonumber(pityLevel) or 0))
	for rarity, weight in pairs(baseWeights) do
		local w = math.max(0, tonumber(weight) or 0)
		baseTotal = baseTotal + w
		local factor = REROLL_GetPityBoostFactor(rarity)        -- multiplicatif (épique/leg/myth)
		local addAmt, addEvery = REROLL_GetPityBoostAdd(rarity) -- additif par paliers (ex. secret)
		local addTotal  = (addAmt > 0 and pityLevel > 0) and (math.floor(pityLevel / addEvery) * addAmt) or 0
		local multTotal = (factor > 0 and pityLevel > 0) and (w * pityLevel * factor) or 0
		if multTotal > 0 or addTotal > 0 then
			adjusted[rarity] = w + multTotal + addTotal
			hasBoost = true
		else
			adjusted[rarity] = w
		end
	end
	if not hasBoost or baseTotal <= 0 then return adjusted end

	local adjustedTotal = 0
	for _, w in pairs(adjusted) do adjustedTotal = adjustedTotal + w end
	local overshoot = adjustedTotal - baseTotal
	if overshoot <= 0.0001 then return adjusted end

	local pool = (adjusted["commun"] or 0) + (adjusted["rare"] or 0)
	if pool <= overshoot then
		adjusted["commun"] = 0
		adjusted["rare"]   = 0
	else
		local scale = (pool - overshoot) / pool
		if adjusted["commun"] then adjusted["commun"] = adjusted["commun"] * scale end
		if adjusted["rare"]   then adjusted["rare"]   = adjusted["rare"]   * scale end
	end
	return adjusted
end

-- Pool VISIBLE par ce joueur : les entrées superadmin_only (arts en test) sont retirées pour
-- les autres. Appliqué AU TIRAGE (serveur) ET à la grille (client) : l'index renvoyé par le
-- serveur doit tomber sur la même entrée des deux côtés.
function REROLL_FilterHidden(pool, ply)
	if not istable(pool) or (IsValid(ply) and ply:IsSuperAdmin()) then return pool end
	local t = {}
	for _, d in ipairs(pool) do
		if not d.superadmin_only then t[#t + 1] = d end
	end
	return t
end

-- Pity partagee entre factions : une cle par categorie de reroll, commune aux deux.
-- Les anciennes cles "Shinigami::art_spirituel" / "Hollow::art_spirituel" se replient
-- sur "art_spirituel" en gardant le compteur le plus haut.
function REROLL_PityKey(category)
	return tostring(category or "")
end

function REROLL_CollapsePities(pities)
	if type(pities) ~= "table" then return {} end
	local collapsed = {}
	for key, value in pairs(pities) do
		local n = math.max(0, math.floor(tonumber(value) or 0))
		if n > 0 then
			local cat = tostring(key)
			local sep = string.find(cat, "::", 1, true)
			if sep then cat = string.sub(cat, sep + 2) end
			if cat ~= "" then
				collapsed[cat] = math.max(collapsed[cat] or 0, n)
			end
		end
	end
	return collapsed
end

REROLL_DROPS = REROLL_DROPS or {}
REROLL_DROPS = {
	["Shinigami"] = {
		["art_spirituel"] = {
			{
				["name"] = "Encre",
				["icon"] = "5pmtpk9ip4xmoxoe/encre_reroll.png",
				-- SECRET (10/06, user) : même taux que le style Secret (poids global 0.003), 2 factions.
				["rarity"] = "secret",
				["win_id"] = "Encre",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Plantes",
				["icon"] = "4lkv3nk9rxa1t2b23/reroll_plantes.png",
				["rarity"] = "legendary", -- épique -> légendaire (10/01, user)
				["win_id"] = "Plantes",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Tonnerre",
				["icon"] = "5pmtpk9ip4xmoxoe/reroll_tonnerre.png",
				["rarity"] = "epique", -- légendaire -> épique (10/01, user)
				["win_id"] = "Raijin",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Ikkaku Madarame",
				["icon"] = "yijguak0f4ex8xa3/ikkaku.png",
				["rarity"] = "commun",
				["win_id"] = "Ikkaku",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Toshiro Hitsugaya",
				["icon"] = "yijguak0f4ex8xa3/toshiro.png",
				["rarity"] = "legendary",
				["win_id"] = "Hitsugaya",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Byakuya Kuchiki",
				["icon"] = "yijguak0f4ex8xa3/byakuya.png",
				["rarity"] = "epique",
				["win_id"] = "Byakuya",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Soifon",
				["icon"] = "yijguak0f4ex8xa3/soifon.png",
				["rarity"] = "rare",
				["win_id"] = "Soifon",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Urahara",
				["icon"] = "yijguak0f4ex8xa3/urahara.png",
				["rarity"] = "rare",
				["win_id"] = "Urahara",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Unohana",
				["icon"] = "yijguak0f4ex8xa3/unohana.png",
				["rarity"] = "commun",
				["win_id"] = "Unohana",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo",
				["icon"] = "yijguak0f4ex8xa3/ichigo.png",
				["rarity"] = "legendary",
				["win_id"] = "Ichigo",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Kenpachi",
				["icon"] = "yijguak0f4ex8xa3/kenpachi.png",
				["rarity"] = "epique",
				["win_id"] = "Kenpachi",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Yamamoto",
				["icon"] = "yijguak0f4ex8xa3/yamamoto.png",
				["rarity"] = "mythique",
				["win_id"] = "Yamamoto",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Aizen",
				["icon"] = "yijguak0f4ex8xa3/aizen.png",
				["rarity"] = "mythique",
				["win_id"] = "Aizen",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			}
		},
		["style_de_combat"] = {
			{
				["name"] = "Style Mayuri",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/dleclncf9kcwe.png",
				["rarity"] = "commun",
				["win_id"] = "Commun1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Renji",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/cv10juyi3y0cu.png",
				["rarity"] = "commun",
				["win_id"] = "Commun2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Tosen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/twz1n1lseoqt5c85.png",
				["rarity"] = "rare",
				["win_id"] = "Rare1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo (Classique)",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/h8d6m0np10u98.png",
				["rarity"] = "rare",
				["win_id"] = "Rare2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Rukia",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/nz0uqf4i33hdg.png",
				["rarity"] = "epique",
				["win_id"] = "Epique1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Szayelaporro",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/lc8q9u4he7rcs.png",
				["rarity"] = "epique",
				["win_id"] = "Epique2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Shinji",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/sqmi252kurf9q427t.png",
				["rarity"] = "legendary",
				["win_id"] = "Legendaire1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo Soul Society",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/op60zjdamfu3d.png",
				["rarity"] = "legendary",
				["win_id"] = "Legendaire2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Kenpachi",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/x80nr9klqbsrka.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Aizen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/9pgnlyd810ce.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo TYBW",
				["icon"] = "1bhn2d03mwm1/secret1.png",
				["rarity"] = "secret",
				["win_id"] = "Secret1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			-- ── Styles HAKUDA (sans arme) : famille "hakuda", filtrés par EvoStyle.GetPlayerFamily.
			-- Le reroll joueur ne mélange JAMAIS katana et hakuda (filtre par famille du style courant).
			{
				["name"] = "Hakuda - Chad",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_commun.png",
				["rarity"] = "commun",
				["win_id"] = "hakuda1",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Chad SS",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_rare.png",
				["rarity"] = "rare",
				["win_id"] = "hakuda4",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Soifon Basique",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_epique.png",
				["rarity"] = "epique",
				["win_id"] = "hakuda5",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Soifon Capitaine",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_legandaire.png",
				["rarity"] = "legendary",
				["win_id"] = "hakuda2",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Yoruichi",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_mythique.png",
				["rarity"] = "mythique",
				["win_id"] = "hakuda3",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			}
		},
		["style_execution"] = {
			{
				["name"] = "Dernier Souffle",
				["icon"] = "yijguak0f4ex8xa3/commun1.png",
				["rarity"] = "commun",
				["win_id"] = "Commun",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/mugz3vv9ckh7ttran/", frames = 50, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/0tglbjqq34qvs3/", frames = 48, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Coup de Grâce",
				["icon"] = "yijguak0f4ex8xa3/commun2.png",
				["rarity"] = "commun",
				["win_id"] = "Commun2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/cyp5lpjuid6x/", frames = 40, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/otr9gl2zbhek2/", frames = 40, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Lame du Néant",
				["icon"] = "yijguak0f4ex8xa3/rare1.png",
				["rarity"] = "rare",
				["win_id"] = "Rare",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ixwrzzt9aw2t56o/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/0z8q5bprapenjl/", frames = 48, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Jugement Spirituel",
				["icon"] = "yijguak0f4ex8xa3/rare2.png",
				["rarity"] = "rare",
				["win_id"] = "Rare2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3dtn4f0ysso360w2/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/p2u4wa4nl1uz/", frames = 43, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Éclipse Écarlate",
				["icon"] = "yijguak0f4ex8xa3/epique1.png",
				["rarity"] = "epique",
				["win_id"] = "Epique",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/lau7jxmlzeunzst/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3qzz9l3fbwnpybeb/", frames = 51, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Faucheur d'Âmes",
				["icon"] = "yijguak0f4ex8xa3/epique2.png",
				["rarity"] = "epique",
				["win_id"] = "Epique2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ht20n2ttb1jkjkrz/", frames = 55, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/cw7a5joiiombp5/", frames = 47, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Crépuscule des Âmes",
				["icon"] = "yijguak0f4ex8xa3/legendaire1.png",
				["rarity"] = "legendary",
				["win_id"] = "Légendaire",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/bjduviz2xeh4vi3sc/", frames = 54, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ygjmy2xqeyy87ud/", frames = 53, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Sentence Divine",
				["icon"] = "yijguak0f4ex8xa3/legendaire2.png",
				["rarity"] = "legendary",
				["win_id"] = "Légendaire2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/rp6uwwq9yx7jz3txe/", frames = 50, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/c1k7c21pyweb2w/", frames = 46, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Kyomu no Shūen (Fin du Néant)",
				["icon"] = "yijguak0f4ex8xa3/mythique1.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/o42xu17ay42s48iz/", frames = 56, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3jsbfq12nzkd/", frames = 49, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Reikon Hōkai (Destruction de l'Âme)",
				["icon"] = "yijguak0f4ex8xa3/mythique2.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/pih3dbx9fvg1oyadt/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/kmpbvqava7m5q/", frames = 40, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			}
		},
		-- CATALYSEURS (10/06, user) : effet de particules sur la lame / les poings (pack
		-- DEV_CATALYSEURS_V7), cosmétique par perso. Rendu : ncm_combat_system cl_catalyseurs.
		["catalyseur"] = {
			{
				["name"] = "Souffle d’azur",
				["icon"] = "evo_catalyseurs/icone_01_reiatsu_azur.png",
				["rarity"] = "commun",
				["win_id"] = "01_reiatsu_azur",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Braise du dojo",
				["icon"] = "evo_catalyseurs/icone_02_braise.png",
				["rarity"] = "commun",
				["win_id"] = "02_braise",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Givre lunaire",
				["icon"] = "evo_catalyseurs/icone_03_givre.png",
				["rarity"] = "rare",
				["win_id"] = "03_givre",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Aurore errante",
				["icon"] = "evo_catalyseurs/icone_04_sakura.png",
				["rarity"] = "rare",
				["win_id"] = "04_sakura",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Raikō, Foudre vive",
				["icon"] = "evo_catalyseurs/icone_05_raikou.png",
				["rarity"] = "epique",
				["win_id"] = "05_raikou",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Reiatsu abyssal",
				["icon"] = "evo_catalyseurs/icone_06_encre.png",
				["rarity"] = "epique",
				["win_id"] = "06_encre",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Brasier solaire",
				["icon"] = "evo_catalyseurs/icone_07_feu_celeste.png",
				["rarity"] = "legendary",
				["win_id"] = "07_feu_celeste",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Marée spectrale",
				["icon"] = "evo_catalyseurs/icone_08_lotus.png",
				["rarity"] = "legendary",
				["win_id"] = "08_lotus",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Éclipse souveraine",
				["icon"] = "evo_catalyseurs/icone_09_eclipse.png",
				["rarity"] = "mythique",
				["win_id"] = "09_eclipse",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Brasier primordial",
				["icon"] = "evo_catalyseurs/icone_10_ryujin.png",
				["rarity"] = "mythique",
				["win_id"] = "10_ryujin",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
		},
		["reiatsu_color"] = {
			{
				["name"] = "Harribel",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/zswivgk4gtzy.png",
				["rarity"] = "rare",
				["win_id"] = "halibel",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/pgvpoz7qldpp2sffs/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Training",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/lqxmtvi54s75nv.png",
				["rarity"] = "commun",
				["win_id"] = "ichigo_training",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/46twxyyh04sb2jgm/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Zangetsu",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/nsijafhibf4f90yz0.png",
				["rarity"] = "rare",
				["win_id"] = "zangetsu",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/hl88ctu6chc1/", frames = 19 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Gin",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/urrl222v3kz57wj.png",
				["rarity"] = "commun",
				["win_id"] = "gin",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/inbc4cc7sglycin/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Aizen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/vlw04tay7m1c5.png",
				["rarity"] = "legendary",
				["win_id"] = "aizen",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/xy2txhz6p0hngpn/", frames = 23 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Byakuya",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/lsfoxzhgdgar6.png",
				["rarity"] = "legendary",
				["win_id"] = "byakuya",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/fm8843i1tzavdv/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Soifon",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/2stskxsd4li2vko.png",
				["rarity"] = "commun",
				["win_id"] = "soifon",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/zq8fd0geyq8a82kmk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Shunsui",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/hrk3u6pbsxjrg4a6.png",
				["rarity"] = "epique",
				["win_id"] = "shunsui",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/t6s1vkk0yu8k/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Dangai",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/pfg9nkoyis498f1t.png",
				["rarity"] = "mythique",
				["win_id"] = "ichigo_dangai",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/tj6rq38wwln4r2v/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y12u6ynllp2eczo7a.png",
				["rarity"] = "epique",
				["win_id"] = "ichigo",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/mq3ox0980v1rk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Rukia",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/a7bplcwg186xbll.png",
				["rarity"] = "rare",
				["win_id"] = "rukia",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/6cgwioojyu90vic/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Kokuto",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/qjf0x74e4i4o1.png",
				["rarity"] = "rare",
				["win_id"] = "kokuto",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/l3nyvag58vntxkwsa/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Mugetsu",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/fcggrk2od4es.png",
				["rarity"] = "legendary",
				["win_id"] = "ichigo_mugetsu",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/k7dv9tdat5pp9ly4/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Stark",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/jyf0r1qjjvp2o65.png",
				["rarity"] = "epique",
				["win_id"] = "stark",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/47u14qdggqjeq6h/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Ulquiorra",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/h0z8qbfxzdcc2m81.png",
				["rarity"] = "legendary",
				["win_id"] = "ulquiorra",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/c2xhav5wk3o4ogd9r/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Grimmjow",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/3ygr4qo2741dgx.png",
				["rarity"] = "epique",
				["win_id"] = "grimmjow",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/t1z86iolqdv1m9/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Toshiro",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/6n547f4gbabki.png",
				["rarity"] = "legendary",
				["win_id"] = "toshiro",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/k8rtaqp7wrc7t05t/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Aizen Final",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/p7khqldplf3g8tg.png",
				["rarity"] = "mythique",
				["win_id"] = "aizen_final",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/sy5pl6edtcdejgnfk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Skullclad",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/56f4ktyzorgiq4.png",
				["rarity"] = "epique",
				["win_id"] = "ichigo_skullclad",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/lv6i9frvk1b5o/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Yoruichi",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/5cayb6u8zmp6.png",
				["rarity"] = "rare",
				["win_id"] = "yoruichi",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/kx7505wyin7ao/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Barragan",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/u8jj4fhpk3cyww8.png",
				["rarity"] = "mythique",
				["win_id"] = "baraggan",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/mlb9st1ix119k/", frames = 20 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Rukia Dark",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ylddb6dzhtrm2e.png",
				["rarity"] = "mythique",
				["win_id"] = "rukia_dark",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/a5rfj6n0ydlx/", frames = 23 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Ywatch",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ik7hvba1efejy12.png",
				["rarity"] = "mythique",
				["win_id"] = "ywatch",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/nqhgtrkmw6zxa/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Supervillain",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/w8ukug631z0ug.png",
				["rarity"] = "mythique",
				["win_id"] = "supervillain",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/uk0p5teg7pj9g/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			-- Auras « Reload » (09/25) : DEUX crans au-dessus de leur aura d'origine, epique minimum.
			-- Apercus : noms des frames a ajouter dans sh_gif_frames.lua (fournis par le workshop).
			{
				["name"] = "Ichigo Training Reload",
				["rarity"] = "epique",
				["win_id"] = "ichigo_training_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/f8z7xzxakjvcn.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/dd97nlah7jv2h3v/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Gin Reload",
				["rarity"] = "epique",
				["win_id"] = "gin_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/uwf98ou4fwqp2.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/yatzi3yjc81v8g/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Grimmjow Reload",
				["rarity"] = "mythique",
				["win_id"] = "grimmjow_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/gqrtrzmgm8vto4.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/fc057g8yfstc4g9sp/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Getsuga Reload",
				["rarity"] = "mythique",
				["win_id"] = "getsuga_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/35u4ysmnehs0.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/ytypj6bry1hi/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Kokuto Reload",
				["rarity"] = "legendary",
				["win_id"] = "kokuto_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/1e8e2rw22rmvym7sj.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/tekzhe47z8k4t/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Rukia Reload",
				["rarity"] = "legendary",
				["win_id"] = "rukia_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/g1kqtwzzthaxra3cq.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/gcyrz8qdpkvyi/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Shunsui Reload",
				["rarity"] = "mythique",
				["win_id"] = "shunsui_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y8kls418bx9l.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/zn25341z582b2or/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Skullclad Reload",
				["rarity"] = "mythique",
				["win_id"] = "skullclad_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/hrdz5x0pck0j.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/b8ajjtb43p1jzowy/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Stark Reload",
				["rarity"] = "mythique",
				["win_id"] = "stark_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/fwy7ww1a3acy.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/81hjhj4cvzwp3qt/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Yoruichi Reload",
				["rarity"] = "legendary",
				["win_id"] = "yoruichi_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ljhfwhf3xjly6eff3.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/04b7puv7xmksnk5/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Zangetsu Reload",
				["rarity"] = "legendary",
				["win_id"] = "zangetsu_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/gfi8kvdub3lv7h.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/27ooe5il8dzix65/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Harribel Reload",
				["rarity"] = "legendary",
				["win_id"] = "halibel_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y5ln9xkk1gq4a9s.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/76o4t9jw5mqdjvel9/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

		}
	},
	["Hollow"] = {
		["art_spirituel"] = {
			-- Encre : de nouveau aux DEUX factions, en secret (10/06, user ; Shinigami seul du 10/01 au 10/06).
			{
				["name"] = "Encre",
				["icon"] = "5pmtpk9ip4xmoxoe/encre_reroll.png",
				-- SECRET (10/06, user) : même taux que le style Secret (poids global 0.003), 2 factions.
				["rarity"] = "secret",
				["win_id"] = "Encre",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Carcasse",
				["icon"] = "4lkv3nk9rxa1t2b23/reroll_carcasse.png",
				["rarity"] = "epique",
				["win_id"] = "Carcasse",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Cristaux",
				["icon"] = "4lkv3nk9rxa1t2b23/reroll_cristaux.png",
				["rarity"] = "legendary",
				["win_id"] = "Cristal",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Yammy",
				["icon"] = "yijguak0f4ex8xa3/yammy.png",
				["rarity"] = "commun",
				["win_id"] = "yammyLlargo",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
				{
				["name"] = "Aaroniero",
				["icon"] = "yijguak0f4ex8xa3/aaron.png",
				["rarity"] = "commun",
				["win_id"] = "aaronArrurerie",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Szayelaporro",
				["icon"] = "yijguak0f4ex8xa3/granz.png",
				["rarity"] = "rare",
				["win_id"] = "GranzSzayel",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Zommari",
				["icon"] = "yijguak0f4ex8xa3/zommari.png",
				["rarity"] = "rare",
				["win_id"] = "Zommari",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Grimmjow",
				["icon"] = "yijguak0f4ex8xa3/grimmjow.png",
				["rarity"] = "epique",
				["win_id"] = "GrimmjowJaegerjaquez",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Nnoitra",
				["icon"] = "yijguak0f4ex8xa3/nnoitra.png",
				["rarity"] = "epique",
				["win_id"] = "NoitoraGilga",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Ulquiorra",
				["icon"] = "yijguak0f4ex8xa3/ulquiorra.png",
				["rarity"] = "legendary",
				["win_id"] = "UlquirorraShifter",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Harribel",
				["icon"] = "yijguak0f4ex8xa3/harribel.png",
				["rarity"] = "legendary",
				["win_id"] = "TierHarribel",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Barragan",
				["icon"] = "yijguak0f4ex8xa3/barragan.png",
				["rarity"] = "mythique",
				["win_id"] = "BarraganLuisenbarn",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			},
			{
				["name"] = "Coyote Starrk",
				["icon"] = "yijguak0f4ex8xa3/coyote_starrk.png",
				["rarity"] = "mythique",
				["win_id"] = "CoyoteStarrk",
				["win_function"] = function(ply, drop)
					ply:GiveArtSpirituel(drop.win_id)
				end
			}
		},
		["style_de_combat"] = {
			{
				["name"] = "Style Mayuri",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/dleclncf9kcwe.png",
				["rarity"] = "commun",
				["win_id"] = "Commun1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Renji",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/cv10juyi3y0cu.png",
				["rarity"] = "commun",
				["win_id"] = "Commun2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Tosen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/twz1n1lseoqt5c85.png",
				["rarity"] = "rare",
				["win_id"] = "Rare1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo (Classique)",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/h8d6m0np10u98.png",
				["rarity"] = "rare",
				["win_id"] = "Rare2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Rukia",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/nz0uqf4i33hdg.png",
				["rarity"] = "epique",
				["win_id"] = "Epique1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Szayelaporro",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/lc8q9u4he7rcs.png",
				["rarity"] = "epique",
				["win_id"] = "Epique2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Shinji",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/sqmi252kurf9q427t.png",
				["rarity"] = "legendary",
				["win_id"] = "Legendaire1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo Soul Society",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/op60zjdamfu3d.png",
				["rarity"] = "legendary",
				["win_id"] = "Legendaire2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Kenpachi",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/x80nr9klqbsrka.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Aizen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/cr8nr4tlrxzj/9pgnlyd810ce.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique2",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Style Ichigo TYBW",
				["icon"] = "1bhn2d03mwm1/secret1.png",
				["rarity"] = "secret",
				["win_id"] = "Secret1",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			-- ── Styles HAKUDA (sans arme) : famille "hakuda", filtrés par EvoStyle.GetPlayerFamily.
			-- Le reroll joueur ne mélange JAMAIS katana et hakuda (filtre par famille du style courant).
			{
				["name"] = "Hakuda - Chad",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_commun.png",
				["rarity"] = "commun",
				["win_id"] = "hakuda1",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Chad SS",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_rare.png",
				["rarity"] = "rare",
				["win_id"] = "hakuda4",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Soifon Basique",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_epique.png",
				["rarity"] = "epique",
				["win_id"] = "hakuda5",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Soifon Capitaine",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_legandaire.png",
				["rarity"] = "legendary",
				["win_id"] = "hakuda2",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			},
			{
				["name"] = "Hakuda - Yoruichi",
				["icon"] = "etgmnxxbvsadh9/etgmnxxbvsadh9/hakuda_mythique.png",
				["rarity"] = "mythique",
				["win_id"] = "hakuda3",
				["family"] = "hakuda",
				["win_function"] = function(ply, drop)
					ply:GiveStyleCombat(drop.win_id)
				end
			}
		},
		["style_execution"] = {
			{
				["name"] = "Dernier Souffle",
				["icon"] = "yijguak0f4ex8xa3/commun1.png",
				["rarity"] = "commun",
				["win_id"] = "Commun",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/mugz3vv9ckh7ttran/", frames = 50, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/0tglbjqq34qvs3/", frames = 48, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Coup de Grâce",
				["icon"] = "yijguak0f4ex8xa3/commun2.png",
				["rarity"] = "commun",
				["win_id"] = "Commun2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/cyp5lpjuid6x/", frames = 40, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/otr9gl2zbhek2/", frames = 40, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Lame du Néant",
				["icon"] = "yijguak0f4ex8xa3/rare1.png",
				["rarity"] = "rare",
				["win_id"] = "Rare",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ixwrzzt9aw2t56o/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/0z8q5bprapenjl/", frames = 48, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Jugement Spirituel",
				["icon"] = "yijguak0f4ex8xa3/rare2.png",
				["rarity"] = "rare",
				["win_id"] = "Rare2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3dtn4f0ysso360w2/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/p2u4wa4nl1uz/", frames = 43, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Éclipse Écarlate",
				["icon"] = "yijguak0f4ex8xa3/epique1.png",
				["rarity"] = "epique",
				["win_id"] = "Epique",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/lau7jxmlzeunzst/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3qzz9l3fbwnpybeb/", frames = 51, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Faucheur d'Âmes",
				["icon"] = "yijguak0f4ex8xa3/epique2.png",
				["rarity"] = "epique",
				["win_id"] = "Epique2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ht20n2ttb1jkjkrz/", frames = 55, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/cw7a5joiiombp5/", frames = 47, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Crépuscule des Âmes",
				["icon"] = "yijguak0f4ex8xa3/legendaire1.png",
				["rarity"] = "legendary",
				["win_id"] = "Légendaire",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/bjduviz2xeh4vi3sc/", frames = 54, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/ygjmy2xqeyy87ud/", frames = 53, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Sentence Divine",
				["icon"] = "yijguak0f4ex8xa3/legendaire2.png",
				["rarity"] = "legendary",
				["win_id"] = "Légendaire2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/rp6uwwq9yx7jz3txe/", frames = 50, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/c1k7c21pyweb2w/", frames = 46, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Kyomu no Shūen (Fin du Néant)",
				["icon"] = "yijguak0f4ex8xa3/mythique1.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/o42xu17ay42s48iz/", frames = 56, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/3jsbfq12nzkd/", frames = 49, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			},
			{
				["name"] = "Reikon Hōkai (Destruction de l'Âme)",
				["icon"] = "yijguak0f4ex8xa3/mythique2.png",
				["rarity"] = "mythique",
				["win_id"] = "Mythique2",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/pih3dbx9fvg1oyadt/", frames = 60, fps = 10 },
				["hover_gif_poing"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/an55wgiaktk6furl/kmpbvqava7m5q/", frames = 40, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveStyleExecution(drop.win_id)
				end
			}
		},
		-- CATALYSEURS (10/06, user) : effet de particules sur la lame / les poings (pack
		-- DEV_CATALYSEURS_V7), cosmétique par perso. Rendu : ncm_combat_system cl_catalyseurs.
		["catalyseur"] = {
			{
				["name"] = "Souffle d’azur",
				["icon"] = "evo_catalyseurs/icone_01_reiatsu_azur.png",
				["rarity"] = "commun",
				["win_id"] = "01_reiatsu_azur",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Braise du dojo",
				["icon"] = "evo_catalyseurs/icone_02_braise.png",
				["rarity"] = "commun",
				["win_id"] = "02_braise",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Givre lunaire",
				["icon"] = "evo_catalyseurs/icone_03_givre.png",
				["rarity"] = "rare",
				["win_id"] = "03_givre",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Aurore errante",
				["icon"] = "evo_catalyseurs/icone_04_sakura.png",
				["rarity"] = "rare",
				["win_id"] = "04_sakura",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Raikō, Foudre vive",
				["icon"] = "evo_catalyseurs/icone_05_raikou.png",
				["rarity"] = "epique",
				["win_id"] = "05_raikou",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Reiatsu abyssal",
				["icon"] = "evo_catalyseurs/icone_06_encre.png",
				["rarity"] = "epique",
				["win_id"] = "06_encre",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Brasier solaire",
				["icon"] = "evo_catalyseurs/icone_07_feu_celeste.png",
				["rarity"] = "legendary",
				["win_id"] = "07_feu_celeste",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Marée spectrale",
				["icon"] = "evo_catalyseurs/icone_08_lotus.png",
				["rarity"] = "legendary",
				["win_id"] = "08_lotus",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Éclipse souveraine",
				["icon"] = "evo_catalyseurs/icone_09_eclipse.png",
				["rarity"] = "mythique",
				["win_id"] = "09_eclipse",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
			{
				["name"] = "Brasier primordial",
				["icon"] = "evo_catalyseurs/icone_10_ryujin.png",
				["rarity"] = "mythique",
				["win_id"] = "10_ryujin",
				["superadmin_only"] = true, -- en test (10/07, user) : invisible et jamais tiré hors superadmin
				["win_function"] = function(ply, drop)
					ply:GiveCatalyseur(drop.win_id)
				end
			},
		},
		["reiatsu_color"] = {
			{
				["name"] = "Harribel",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/zswivgk4gtzy.png",
				["rarity"] = "rare",
				["win_id"] = "halibel",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/pgvpoz7qldpp2sffs/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Training",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/lqxmtvi54s75nv.png",
				["rarity"] = "commun",
				["win_id"] = "ichigo_training",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/46twxyyh04sb2jgm/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Zangetsu",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/nsijafhibf4f90yz0.png",
				["rarity"] = "rare",
				["win_id"] = "zangetsu",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/hl88ctu6chc1/", frames = 19 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Gin",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/urrl222v3kz57wj.png",
				["rarity"] = "commun",
				["win_id"] = "gin",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/inbc4cc7sglycin/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Aizen",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/vlw04tay7m1c5.png",
				["rarity"] = "legendary",
				["win_id"] = "aizen",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/xy2txhz6p0hngpn/", frames = 23 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Byakuya",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/lsfoxzhgdgar6.png",
				["rarity"] = "legendary",
				["win_id"] = "byakuya",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/fm8843i1tzavdv/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Soifon",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/2stskxsd4li2vko.png",
				["rarity"] = "commun",
				["win_id"] = "soifon",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/zq8fd0geyq8a82kmk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Shunsui",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/hrk3u6pbsxjrg4a6.png",
				["rarity"] = "epique",
				["win_id"] = "shunsui",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/t6s1vkk0yu8k/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Dangai",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/pfg9nkoyis498f1t.png",
				["rarity"] = "mythique",
				["win_id"] = "ichigo_dangai",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/tj6rq38wwln4r2v/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y12u6ynllp2eczo7a.png",
				["rarity"] = "epique",
				["win_id"] = "ichigo",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/mq3ox0980v1rk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Rukia",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/a7bplcwg186xbll.png",
				["rarity"] = "rare",
				["win_id"] = "rukia",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/6cgwioojyu90vic/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Kokuto",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/qjf0x74e4i4o1.png",
				["rarity"] = "rare",
				["win_id"] = "kokuto",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/l3nyvag58vntxkwsa/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Mugetsu",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/fcggrk2od4es.png",
				["rarity"] = "legendary",
				["win_id"] = "ichigo_mugetsu",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/k7dv9tdat5pp9ly4/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Stark",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/jyf0r1qjjvp2o65.png",
				["rarity"] = "epique",
				["win_id"] = "stark",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/47u14qdggqjeq6h/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Ulquiorra",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/h0z8qbfxzdcc2m81.png",
				["rarity"] = "legendary",
				["win_id"] = "ulquiorra",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/c2xhav5wk3o4ogd9r/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Grimmjow",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/3ygr4qo2741dgx.png",
				["rarity"] = "epique",
				["win_id"] = "grimmjow",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/t1z86iolqdv1m9/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Toshiro",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/6n547f4gbabki.png",
				["rarity"] = "legendary",
				["win_id"] = "toshiro",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/k8rtaqp7wrc7t05t/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Aizen Final",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/p7khqldplf3g8tg.png",
				["rarity"] = "mythique",
				["win_id"] = "aizen_final",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/sy5pl6edtcdejgnfk/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Skullclad",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/56f4ktyzorgiq4.png",
				["rarity"] = "epique",
				["win_id"] = "ichigo_skullclad",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/lv6i9frvk1b5o/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Yoruichi",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/5cayb6u8zmp6.png",
				["rarity"] = "rare",
				["win_id"] = "yoruichi",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/kx7505wyin7ao/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Barragan",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/u8jj4fhpk3cyww8.png",
				["rarity"] = "mythique",
				["win_id"] = "baraggan",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/mlb9st1ix119k/", frames = 20 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Rukia Dark",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ylddb6dzhtrm2e.png",
				["rarity"] = "mythique",
				["win_id"] = "rukia_dark",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/a5rfj6n0ydlx/", frames = 23 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Ywatch",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ik7hvba1efejy12.png",
				["rarity"] = "mythique",
				["win_id"] = "ywatch",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/nqhgtrkmw6zxa/", frames = 22 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			{
				["name"] = "Supervillain",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/w8ukug631z0ug.png",
				["rarity"] = "mythique",
				["win_id"] = "supervillain",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/uk0p5teg7pj9g/", frames = 21 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},

			-- Auras « Reload » (09/25) : DEUX crans au-dessus de leur aura d'origine, epique minimum.
			-- Apercus : noms des frames a ajouter dans sh_gif_frames.lua (fournis par le workshop).
			{
				["name"] = "Ichigo Training Reload",
				["rarity"] = "epique",
				["win_id"] = "ichigo_training_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/f8z7xzxakjvcn.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/dd97nlah7jv2h3v/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Gin Reload",
				["rarity"] = "epique",
				["win_id"] = "gin_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/uwf98ou4fwqp2.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/yatzi3yjc81v8g/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Grimmjow Reload",
				["rarity"] = "mythique",
				["win_id"] = "grimmjow_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/gqrtrzmgm8vto4.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/fc057g8yfstc4g9sp/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Getsuga Reload",
				["rarity"] = "mythique",
				["win_id"] = "getsuga_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/35u4ysmnehs0.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/ytypj6bry1hi/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Kokuto Reload",
				["rarity"] = "legendary",
				["win_id"] = "kokuto_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/1e8e2rw22rmvym7sj.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/tekzhe47z8k4t/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Rukia Reload",
				["rarity"] = "legendary",
				["win_id"] = "rukia_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/g1kqtwzzthaxra3cq.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/gcyrz8qdpkvyi/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Shunsui Reload",
				["rarity"] = "mythique",
				["win_id"] = "shunsui_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y8kls418bx9l.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/zn25341z582b2or/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Ichigo Skullclad Reload",
				["rarity"] = "mythique",
				["win_id"] = "skullclad_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/hrdz5x0pck0j.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/b8ajjtb43p1jzowy/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Stark Reload",
				["rarity"] = "mythique",
				["win_id"] = "stark_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/fwy7ww1a3acy.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/81hjhj4cvzwp3qt/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Yoruichi Reload",
				["rarity"] = "legendary",
				["win_id"] = "yoruichi_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/ljhfwhf3xjly6eff3.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/04b7puv7xmksnk5/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Zangetsu Reload",
				["rarity"] = "legendary",
				["win_id"] = "zangetsu_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/gfi8kvdub3lv7h.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/27ooe5il8dzix65/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
			{
				["name"] = "Harribel Reload",
				["rarity"] = "legendary",
				["win_id"] = "halibel_reload",
				["icon"] = "4wsd81r0bjysb8vy/armszwz3ae1f8/kn7imiiz7cwtchs/y5ln9xkk1gq4a9s.png",
				["hover_gif"] = { path = "4wsd81r0bjysb8vy/armszwz3ae1f8/de4dhdit0irg26wj/76o4t9jw5mqdjvel9/", frames = 24, fps = 10 },
				["win_function"] = function(ply, drop)
					ply:GiveReiatsuColor(drop.win_id)
				end
			},
		}
	},
}

-- Reroll stock: in-game category (REROLL_DROPS) and shop keys -> players.* column / NWInt name (same string).
LZY_REROLL_STOCK_KEYS = LZY_REROLL_STOCK_KEYS or {
	["art_spirituel"] = "rerolls_art_spirituel",
	["style_de_combat"] = "rerolls_combat_style",
	["style_execution"] = "rerolls_style_execution",
	["catalyseur"] = "rerolls_catalyseur", -- 10/06 (shop : même clé « catalyseur »)
	["reiatsu_color"] = "rerolls_aura_spirituel",
	-- lzy_shop reroll_config keys
	["aura_spirituel"] = "rerolls_aura_spirituel",
	["combat_style"] = "rerolls_combat_style",
}
LZY_REROLL_STOCK_KEYS.catalyseur = "rerolls_catalyseur" -- aussi au rechargement à chaud (table « or { } »)

function LZY_RerollStockKey(category)
	if not category or category == "" then return nil end
	return LZY_REROLL_STOCK_KEYS[category]
end
