-- "addons\\lzy_reroll\\lua\\autorun\\lzy_reroll_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	include("lzy_reroll/sh_config.lua")
	include("lzy_reroll/sv_log.lua") -- avant sv_main : il y appelle LZY_RerollLog
	include("lzy_reroll/sv_main.lua")
	AddCSLuaFile("lzy_reroll/sh_config.lua")
	AddCSLuaFile("lzy_reroll/sh_gif_frames.lua")
	AddCSLuaFile("lzy_reroll/cl_cutscene.lua")
	AddCSLuaFile("lzy_reroll/vgui/main.lua")
else
	include("lzy_reroll/sh_config.lua")
	include("lzy_reroll/sh_gif_frames.lua")
	include("lzy_reroll/cl_cutscene.lua") -- avant vgui/main : il y appelle EVO_Cutscene
	include("lzy_reroll/vgui/main.lua")
end