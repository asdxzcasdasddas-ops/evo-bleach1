-- "addons\\evo_lockdown\\lua\\autorun\\lzy_lockdown_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_lockdown/cl_main.lua")
	include("lzy_lockdown/sv_main.lua")
else
	include("lzy_lockdown/cl_main.lua")
end
