-- "addons\\evo_npc_core\\lua\\autorun\\sh_evo_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Stub EVO_NPC (autorun, sans include — charge avant les vendeurs).
EVO_NPC = EVO_NPC or {}
EVO_NPC._providers = EVO_NPC._providers or {}
EVO_NPC._queue = EVO_NPC._queue or {}

function EVO_NPC.RegisterProvider(tProvider)
	if not istable(tProvider) or not tProvider.id then
		ErrorNoHalt("[EVO_NPC] RegisterProvider : id requis\n")
		return
	end
	if EVO_NPC._AcceptProvider then
		EVO_NPC._AcceptProvider(tProvider)
	else
		for _, p in ipairs(EVO_NPC._queue) do
			if p.id == tProvider.id then return end
		end
		EVO_NPC._queue[#EVO_NPC._queue + 1] = tProvider
	end
end

-- Enregistrement differe : retry tant que le bootstrap serveur n'a pas accepte le provider.
function EVO_NPC.RegisterProviderDeferred(tProvider)
	if not istable(tProvider) or not tProvider.id then return end

	local sId = tProvider.id

	local function isRegistered()
		return EVO_NPC._providers and EVO_NPC._providers[sId] ~= nil
	end

	local bQueued = false

	local function attempt()
		if isRegistered() then return true end
		if not bQueued and EVO_NPC and EVO_NPC.RegisterProvider then
			EVO_NPC.RegisterProvider(tProvider)
			bQueued = true
		end
		return isRegistered()
	end

	if attempt() then return end

	local sTimer = "EVO_NPC_DeferredReg_" .. sId
	if timer.Exists(sTimer) then return end

	timer.Create(sTimer, 0.1, 100, function()
		if attempt() then timer.Remove(sTimer) end
	end)
end
