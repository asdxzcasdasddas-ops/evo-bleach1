-- "addons\\evo_npc_core\\lua\\autorun\\evo_npc_interact.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- =====================================================================
-- EVO NPC INTERACT — interaction "[E]" À DISTANCE pour les PNJ vendeurs.
-- Le +use natif de GMod est bridé à ~90u par le moteur. Ici on détecte la
-- touche E côté client (quand un PNJ enregistré est à portée + visible) et on
-- déclenche son ENT:Use serveur via net -> on peut interagir jusqu'à la distance
-- d'affichage du prompt. Le throttle interne de chaque ENT:Use dédup le double
-- appel (natif + ce net) quand on est au contact.
-- =====================================================================

EVO_NPCInteract = EVO_NPCInteract or {}

-- Classe d'entité -> distance max d'interaction (units source). À garder = à la
-- PromptDistance du PNJ pour que "prompt affiché == clic possible".
EVO_NPCInteract.NPCs = {
    ["lzy_coiffeur_npc"]  = 160,
    ["lzy_tatoueur_npc"]  = 160,
    ["lzy_renommeur_npc"] = 160,
    ["lzy_sculpteur_npc"] = 160,
    ["lzy_npcshop_npc"]   = 160,
    ["ncm_npc_soin"]      = 160,
    ["ncm_npc_parchemin"] = 160,
    ["ncm_npc_shikai_renamer"] = 160,
    ["evo_npc_famille"]        = 160,
    ["ncm_npc_style_swap"]     = 160,
    ["evo_npc_clan"]           = 160,
    ["evo_npc_hdv"]            = 160,
    ["evo_npc_zanpakuto"]      = 160, -- Gardien des Lames (rituel evo_blanc)
    ["evo_npc_dresseur"]       = 160, -- Dresseur de compagnons (nom, evo_compagnons)
}

-- PNJ de personnalisation cosmétique (coiffeur / chirurgien esthétique-sculpteur / tatoueur) :
-- INACCESSIBLES en mode larva/hollow (le rendu est un modèle créature brut, ces menus n'ont aucun
-- sens et casseraient l'apparence). Le blocage est serveur (autoritaire) sur LES DEUX chemins :
-- le net "E à distance" ci-dessous ET le +use natif au contact (hook GM:PlayerUse).
EVO_NPCInteract.LarvaBlocked = {
    ["lzy_coiffeur_npc"]  = true,
    ["lzy_tatoueur_npc"]  = true,
    ["lzy_sculpteur_npc"] = true,
}

-- Vrai si `ply` (larva) ne peut PAS interagir avec ce PNJ cosmétique. Notifie une fois (throttle).
function EVO_NPCInteract.IsLarvaBlocked(ply, class)
    if not (IsValid(ply) and EVO_NPCInteract.LarvaBlocked[class]) then return false end
    if not ply:GetEvoNWBool("EVO_IsLarva", false) then return false end
    if SERVER and MUGEN and MUGEN.Notify and (ply._evoNpcLarvaNotify or 0) < CurTime() then
        ply._evoNpcLarvaNotify = CurTime() + 2
        MUGEN.Notify(ply, "Indisponible sous ta forme de Hollow.", NOTIFY_ERROR, 4)
    end
    return true
end

if SERVER then
    util.AddNetworkString("EVO_NPCInteract")

    net.Receive("EVO_NPCInteract", function(_, ply)
        if not (IsValid(ply) and ply:IsPlayer() and ply:Alive()) then return end
        if (ply._evoNpcIntNext or 0) > CurTime() then return end
        ply._evoNpcIntNext = CurTime() + 0.3

        local ent = net.ReadEntity()
        if not IsValid(ent) then return end
        local class = ent:GetClass()
        local dist = EVO_NPCInteract.NPCs[class]
        if not dist then return end -- pas un PNJ enregistré

        -- Larva/hollow : pas de PNJ cosmétique (coiffeur/tatoueur/sculpteur).
        if EVO_NPCInteract.IsLarvaBlocked(ply, class) then return end

        -- Validation serveur (anti-triche) : vraie distance.
        if ply:EyePos():Distance(ent:GetPos() + Vector(0, 0, 36)) > dist + 24 then return end

        -- Déclenche l'ouverture native du PNJ (son ENT:Use re-vérifie + throttle).
        if isfunction(ent.Use) then ent:Use(ply, ply) end
    end)

    -- +use natif AU CONTACT (≤ ~90u) : il NE passe PAS par le net ci-dessus -> on le bloque ici
    -- aussi pour la larva, sinon elle pourrait ouvrir le coiffeur/tatoueur/sculpteur de près.
    hook.Add("PlayerUse", "EVO_NPCInteract::LarvaBlock", function(ply, ent)
        if IsValid(ent) and EVO_NPCInteract.IsLarvaBlocked(ply, ent:GetClass()) then return false end
    end)

    return
end

-- ===================== CLIENT =====================

-- PNJ enregistré le plus proche, à portée ET visible (LOS world). nil sinon.
local function FindInteractTarget()
    local lp = LocalPlayer()
    if not IsValid(lp) then return nil end
    local eyes  = lp:EyePos()
    local lpPos = lp:GetPos()
    local bestEnt, bestD = nil, nil

    -- perf : UNE seule passe ents.Iterator() au lieu de 8 ents.FindByClass (= 8 scans
    -- complets + 8 tables allouées à CHAQUE pression de E). Lookup direct dans
    -- EVO_NPCInteract.NPCs (le registre EST le set classe->distance) : mêmes classes,
    -- même logique distance/priorité, zéro copie à maintenir.
    local npcs = EVO_NPCInteract.NPCs
    for _, e in ents.Iterator() do
        if IsValid(e) then
            local class = e:GetClass()
            local dist = npcs[class]
            if dist then
                -- Larva : on n'ENREGISTRE même pas les PNJ cosmétiques comme cible -> aucun prompt,
                -- aucun ping (E sert aussi à dévorer : pas de notif "indisponible" parasite).
                if EVO_NPCInteract.IsLarvaBlocked(lp, class) then continue end
                local maxSqr = dist * dist
                local d = e:GetPos():DistToSqr(lpPos)
                if d <= maxSqr and (not bestD or d < bestD) then
                    local center = e:GetPos() + Vector(0, 0, 40)
                    -- À l'écran (comme le prompt : on regarde vers le PNJ) + ligne de vue
                    -- (pas à travers un mur). Évite d'ouvrir un PNJ hors-champ quand on
                    -- presse E pour autre chose.
                    local sp = center:ToScreen()
                    local tr = util.TraceLine({
                        start  = eyes,
                        endpos = center,
                        filter = lp,
                        mask   = MASK_SOLID_BRUSHONLY,
                    })
                    if sp.visible and ((not tr.Hit) or tr.Fraction > 0.9) then
                        bestD, bestEnt = d, e
                    end
                end
            end
        end
    end
    return bestEnt
end

-- ══ PROMPT CENTRALISÉ « [E] Parler … » (demande user 2026-07-17) ═══════════════════════
-- AVANT : chaque addon de PNJ dessinait SA copie du prompt bas-écran (styles légèrement
-- différents) et plusieurs prompts se superposaient quand 2+ PNJ étaient à portée.
-- MAINTENANT : chaque addon ne déclare qu'un PROVIDER dans le registre global
-- EVO_NPC_PROMPTS (table simple -> AUCUNE contrainte d'ordre de chargement) :
--   EVO_NPC_PROMPTS["id"] = {
--       fGetTarget = function() -> ent|nil,        -- règles PROPRES à l'addon (portée, éligibilité, UI ouverte)
--       fLabel     = function(ent) -> string,      -- "[E] Parler au X"
--       fSub       = function(ent) -> string|nil,  -- sous-titre accent ("1000 coins"…), optionnel
--   }
-- Le core choisit LE PLUS PROCHE parmi toutes les cibles et dessine UNE SEULE plaque,
-- toujours dans la même DA (plaque Atelier coin coupé + barre accent gauche) : même UI et
-- même logique pour TOUS les PNJ (vendeurs, cosmétiques, PNJ de dialogue/quête ncm_pnj).
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}


local _pBest, _pNext = nil, 0

-- Libellé historique « [E] Parler au X » -> touche, action, nom (style 10/07 : NOM au-dessus,
-- « (E) Parler » dessous). « [E] Ouvrir » + sous-titre = nom porté par le sous-titre.
local DE = { " au ", " aux ", " à la ", " à l'", " à ", " a " }
local function decouper(txt, sub)
    local sKey, rest = string.match(txt, "^%[([^%]]+)%]%s*(.*)$")
    if not sKey then sKey, rest = "E", txt end
    local i = string.find(rest, " ", 1, true)
    if i then
        local sVerbe, sReste = string.sub(rest, 1, i - 1), string.sub(rest, i)
        for _, d in ipairs(DE) do
            if string.sub(sReste, 1, #d) == d then return sKey, sVerbe, string.sub(sReste, #d + 1), sub end
        end
        return sKey, "Interagir", rest, sub -- « Hôtel des ventes » : pas de verbe
    end
    if sub ~= "" then return sKey, rest, sub, "" end -- « Ouvrir » + « Coffre du clan »
    return sKey, rest, "", ""
end

-- Choix de la cible (~3 Hz : les fGetTarget scannent les entités) + publication pour les
-- étiquettes de nom (EVO_ZonePrompt.NpcTag s'efface sous l'invite complète).
-- PERF (10/08, profileur 0,93 ms/frame) : UN fournisseur interrogé par image, à tour de rôle
-- (avant : tous d'un coup 3 fois par seconde = grosse pointe). Le meilleur est choisi à chaque
-- image parmi les résultats gardés en cache, ce qui ne coûte presque rien.
local _tProvCles, _nProvTour, _tProvCible = {}, 0, {}
local _nProvListe = 0
hook.Add("Think", "EVO_NPCInteract::PromptPick", function()
    local lp = LocalPlayer()
    if not (IsValid(lp) and lp:Alive()) then
        _pBest = nil
        if EVO_ZonePrompt then EVO_ZonePrompt.Target = nil end
        return
    end
    local now = CurTime()
    if now >= _nProvListe then -- liste des fournisseurs relue 1 fois/s (ajouts au chargement)
        _nProvListe = now + 1
        _tProvCles = table.GetKeys(EVO_NPC_PROMPTS)
    end
    local n = #_tProvCles
    if n > 0 then
        _nProvTour = _nProvTour % n + 1
        local sCle = _tProvCles[_nProvTour]
        local prov = EVO_NPC_PROMPTS[sCle]
        local okT, ent = false, nil
        if prov then okT, ent = pcall(prov.fGetTarget) end
        _tProvCible[sCle] = (okT and IsValid(ent)) and ent or nil
    end
    _pBest = nil
    local lpPos, bestD = lp:GetPos(), nil
    for sCle, ent in pairs(_tProvCible) do
        local prov = EVO_NPC_PROMPTS[sCle]
        if prov and IsValid(ent) then
            local d = ent:GetPos():DistToSqr(lpPos)
            if not bestD or d < bestD then bestD, _pBest = d, { ent = ent, prov = prov } end
        else
            _tProvCible[sCle] = nil
        end
    end
    if EVO_ZonePrompt then EVO_ZonePrompt.Target = _pBest and _pBest.ent or nil end
end)

-- STYLE 10/07 (user, réf. « Marchand / (E) Parler ») : l'invite flotte au-dessus de la
-- cible, dans le monde (EVO_ZonePrompt), au lieu de la plaque bas-écran.
hook.Add("PostDrawTranslucentRenderables", "EVO_NPCInteract::Prompt", function(bDepth, _, b3DSky)
    if bDepth or b3DSky then return end
    local c = _pBest
    if not (c and IsValid(c.ent)) or not EVO_ZonePrompt or not EVO_ZonePrompt.DrawAt then return end
    if vgui.CursorVisible() then return end -- un menu est ouvert (créateur/shop/popup/dialogue…)
    local okL, txt = pcall(c.prov.fLabel, c.ent)
    if not okL or not isstring(txt) or txt == "" then return end
    local sub = ""
    if c.prov.fSub then
        local okS, s = pcall(c.prov.fSub, c.ent)
        if okS and isstring(s) then sub = s end
    end
    local sKey, sAction, sName, sInfo = decouper(txt, sub)
    EVO_ZonePrompt.DrawAt(c.ent:GetPos() + Vector(0, 0, EVO_ZonePrompt.AnchorZ(c.ent)), sName, sAction, sKey, nil, sInfo)
end)

hook.Add("PlayerButtonDown", "EVO_NPCInteract", function(ply, btn)
    if ply ~= LocalPlayer() then return end
    if btn ~= KEY_E then return end
    -- Pas pendant un menu / la console / une saisie texte / l'Échap.
    if vgui.CursorVisible() then return end
    if gui.IsGameUIVisible() then return end
    if IsValid(vgui.GetKeyboardFocus()) then return end

    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:Alive() then return end

    local ent = FindInteractTarget()
    if IsValid(ent) then
        net.Start("EVO_NPCInteract")
        net.WriteEntity(ent)
        net.SendToServer()
    end
end)
