-- "addons\\evo_ciel\\lua\\autorun\\sh_loader_ciel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL — repeindre le ciel de la map, en direct, sans redemarrage.
--
-- CE QUE CE N'EST PAS : un shader ecrit par nous. GMod ne charge pas de shader
-- maison (il faudrait livrer une DLL a chaque client, le systeme ne le permet
-- pas). On se sert du shader que Source livre DEJA, `SkyPaint`, pilote par
-- l'entite `env_skypaint` : ses variables sont repliquees, et le proxy client
-- de Facepunch (matproxy/sky_paint.lua) les recopie dans le materiau a chaque
-- frame. Resultat : cote serveur uniquement, instantane, aucun telechargement.
--
-- LES DEUX MAPS NE SONT PAS DANS LE MEME CAS (releve dans les BSP le 23/08) :
--   hueco_mundo_v1  : skyname "painted", env_skypaint DEJA dans la map.
--                     Le rouge s'applique tel quel.
--   rp_seireitei_v1 : skyname "skr_sky_day_", pas de env_skypaint.
--                     Il faut basculer sv_skyname sur "painted" et creer
--                     l'entite. Cette bascule est connue pour ne pas toujours
--                     remonter aux clients sur dedie (issue Facepunch 5400) :
--                     c'est LE point a verifier en dev avant d'y croire.
--
-- RIEN NE S'APPLIQUE AU DEMARRAGE. Tirer ce code ne rend pas le ciel rouge en
-- prod : il faut la commande. Volontaire, une ambiance permanente se decide,
-- elle ne s'attrape pas en faisant un pull.
-- ============================================================================

EVO_CIEL = EVO_CIEL or {}

if SERVER then
    util.AddNetworkString("evo_ciel:menu")   -- sv -> cl : ouvre le menu
    util.AddNetworkString("evo_ciel:set")    -- cl -> sv : ambiance choisie
    util.AddNetworkString("evo_ciel:cine")   -- sv -> cl : top depart cinematique

    AddCSLuaFile("evo_ciel/sh_config.lua")
    AddCSLuaFile("evo_ciel/cl_ui.lua")
    AddCSLuaFile("evo_ciel/cl_cine.lua")
    AddCSLuaFile("evo_ciel/cl_ciel.lua")
    AddCSLuaFile("evo_ciel/cl_encre.lua")
    AddCSLuaFile("evo_ciel/cl_manga.lua")
    AddCSLuaFile("evo_ciel/cl_cendres.lua")
    AddCSLuaFile("evo_ciel/cl_feu.lua")
    AddCSLuaFile("evo_ciel/cl_astres.lua")
    AddCSLuaFile("evo_ciel/cl_meteo.lua")
    AddCSLuaFile("evo_ciel/cl_horizon.lua")
end

include("evo_ciel/sh_config.lua")

if SERVER then
    include("evo_ciel/sv_ciel.lua")
else
    include("evo_ciel/cl_ciel.lua")
    include("evo_ciel/cl_ui.lua")
    include("evo_ciel/cl_cine.lua")
    include("evo_ciel/cl_encre.lua")
    include("evo_ciel/cl_manga.lua")
    include("evo_ciel/cl_cendres.lua")
    include("evo_ciel/cl_feu.lua")
    include("evo_ciel/cl_astres.lua")
    include("evo_ciel/cl_meteo.lua")
    include("evo_ciel/cl_horizon.lua")
end
