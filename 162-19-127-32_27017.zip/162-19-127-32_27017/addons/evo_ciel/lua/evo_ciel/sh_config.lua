-- "addons\\evo_ciel\\lua\\evo_ciel\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - les ambiances, partagees serveur et client.
--
-- LES COUCHES, de la moins chere a la plus chere. Chacune est optionnelle :
--   skyTeinte  : UN quad plein ecran en fusion MULTIPLICATIVE, pose entre le
--                ciel et le monde. Ca teinte le dessin EXISTANT : la lune du
--                mappeur garde sa forme, elle change juste de couleur.
--   monde      : UN quad plein ecran en multiplicatif, comme skyTeinte mais
--                sur toute l'image. `brightness`, `contrast` et `couleur` ne
--                sont PLUS lus : DrawColorModify n'etait pas neutre a
--                l'identite et saturait violemment sur une map HDR. Seuls les
--                trois multiplicateurs comptent, et ils sont plafonnes a 1 --
--                une multiplication ne sait qu'assombrir.
--   brouillard : deux hooks qui posent des valeurs. Cout nul.
--   soleil     : `false` masque l'env_sun de la map. Absent = on n'y touche
--                pas. Le halo du soleil est dessine APRES la teinte du ciel et
--                reste blanc meme multiplie par 0.118 : il ne s'assombrit pas,
--                il s'eteint.
--   faille     : la Garganta, en aplats.
--   eclairs    : un quad plein ecran, et seulement pendant l'eclair.
--   foudre     : le CORPS de l'eclair (cl_meteo) : trait brise, branches, halo,
--                lumiere dynamique, puis le tonnerre a un delai tire du meme
--                numero. Ne fait rien sans `eclairs`, qui donne le tempo.
--   precip     : pluie, neige ou sable (cl_meteo), particules autour du joueur.
--   lucioles   : points lumineux au ras du sol (cl_meteo) ; `montee` les fait
--                grimper : motes de reiatsu.
--   etoiles / filantes / lune / soleilNoir : les astres (cl_astres), dessines
--                dans le ciel derriere le monde, tires du temps.
--   sons       : des boucles du jeu de base sur le joueur (cl_feu), volume qui
--                suit la montee de l'ambiance.
--   sonsAlea   : des sons courts a intervalle tire au sort, poses a quelques
--                metres dans une direction au hasard (cl_meteo) : gouttes,
--                oiseaux, rafales.
--   encre      : le trait facon manga. La plus chere, et la plus voyante.
--
-- REGLE DE DOSAGE, apprise a l'usage : `skyTeinte` et `monde` doivent
-- s'ASSOMBRIR DE CONCERT. Un ciel multiplie par 0.38 au-dessus d'un monde
-- multiplie par 0.62 donne exactement ce que le user a vu au Seireitei : une
-- nuit dans le ciel et un coucher de soleil sur les toits. Les deux blocs se
-- lisent ensemble, jamais separement.
--
-- L'ENCRE N'EST PLUS QUE SUR `planche`. Elle etait sur la moitie des ambiances
-- et se voyait partout, alors que c'est un parti pris fort qui doit rester un
-- choix explicite du staff.
-- ============================================================================

EVO_CIEL = EVO_CIEL or {}

-- Qui peut changer le ciel : les superadmins, et le Gerant RP (palier 4) pour la trame
-- principale (demande user 10/09). Meme regle que les autres outils d'animation :
-- EVO_ANIM.Tier exige d'etre SUR son perso d'animation, un compte staff sur un perso RP
-- n'a aucun pouvoir. Partage : le serveur tranche, le panneau animateur s'en sert pour
-- n'afficher le bouton qu'a ceux qui passeront.
EVO_CIEL.TIER_MIN = 4
function EVO_CIEL.Peut(ply)
    if not (IsValid(ply) and ply:IsPlayer()) then return false end
    if ply:IsSuperAdmin() then return true end
    return ((EVO_ANIM and EVO_ANIM.Tier and EVO_ANIM.Tier(ply)) or 0) >= EVO_CIEL.TIER_MIN
end

EVO_CIEL.CleGlobale = "EVO_Ciel"
-- Instant ou l'ambiance a ete allumee, en temps SERVEUR : c'est lui qui permet
-- a la Garganta de grandir de la meme facon chez tout le monde.
EVO_CIEL.CleDebut = "EVO_CielDebut"
-- Ouverture IMPOSEE de la fente, entre 0 et 1. -1 = pas d'imposition, elle
-- grandit toute seule. Le staff veut souvent une Garganta deja beante pour une
-- arrivee : attendre une heure devant les joueurs n'a aucun sens, et relancer
-- l'ambiance pour la faire repartir de zero en a encore moins.
EVO_CIEL.CleOuverture = "EVO_CielOuverture"
-- Duree de montee IMPOSEE (secondes). 0 = celle de la config. Le staff choisit
-- au lancement : la meme nuit sert un fondu d'une minute en test et d'une
-- heure et demie en animation, sans toucher au code.
EVO_CIEL.CleDuree = "EVO_CielDuree"

-- Une ambiance `progressif` ne s'applique pas d'un coup : elle monte depuis le
-- NEUTRE jusqu'a ses valeurs, sur `duree`. C'est la nuit qui tombe au lieu de
-- s'allumer comme un interrupteur.
--
-- Meme date de reference que la Garganta, donc meme garantie : un joueur qui se
-- connecte au milieu voit la meme obscurite que les autres, au lieu de
-- recommencer la tombee de nuit pour lui tout seul.
--- L'avancement BRUT de la montee, lineaire, entre 0 et 1.
function EVO_CIEL.Progression(t)
    local p = t and t.progressif
    if not p then return 1 end
    local t0 = GetGlobalFloat(EVO_CIEL.CleDebut, 0)
    if t0 <= 0 then return 1 end
    -- La duree imposee par le staff au lancement l'emporte sur la config.
    local nDuree = GetGlobalFloat(EVO_CIEL.CleDuree, 0)
    if nDuree <= 0 then nDuree = p.duree or 600 end
    return math.Clamp((CurTime() - t0) / math.max(1, nDuree), 0, 1)
end

--- Ce que les couches appliquent : l'avancement passe par la `courbe` de
-- l'ambiance (30/09/2026). Une eclipse n'assombrit presque rien avant 80 % :
-- en lineaire, le monde s'eteignait des le premier quart.
function EVO_CIEL.Facteur(t)
    local f = EVO_CIEL.Progression(t)
    local k = t and t.progressif and t.progressif.courbe
    if k and k ~= 1 then return f ^ k end
    return f
end

--- L'ouverture FINALE de la fente, entre 0 et 1.
-- Une seule fonction pour les deux modes : la taille etait calculee moitie ici,
-- moitie dans le dessin, et deux endroits qui calculent la meme chose finissent
-- toujours par diverger.
function EVO_CIEL.Ouverture(t)
    local c = t and t.croissance
    if not c then return 1 end

    -- Mode IMPOSE : la taille demandee, telle quelle, sans courbe. Quand le
    -- staff choisit « a moitie ouverte », il doit voir la moitie -- pas la
    -- moitie corrigee par une acceleration qu'il n'a pas demandee.
    local fImpose = GetGlobalFloat(EVO_CIEL.CleOuverture, -1)
    if fImpose >= 0 then return math.Clamp(fImpose, 0, 1) end

    local t0 = GetGlobalFloat(EVO_CIEL.CleDebut, 0)
    local nDuree = GetGlobalFloat(EVO_CIEL.CleDuree, 0)
    if nDuree <= 0 then nDuree = c.duree or 3600 end
    local p = (t0 > 0) and math.Clamp((CurTime() - t0) / math.max(1, nDuree), 0, 1) or 1
    -- L'exposant 1.4 retarde le debut : une fente qui s'ouvre lentement puis
    -- s'emballe se lit comme une pression qui cede, une croissance lineaire se
    -- lit comme un curseur qu'on tire.
    local d = c.depart or 0
    return d + (1 - d) * math.pow(p, 1.4)
end

--- Vrai si la taille est imposee, donc figee. Le menu s'en sert pour dire au
-- staff ce qui va se passer AVANT qu'il clique.
function EVO_CIEL.OuvertureImposee()
    local f = GetGlobalFloat(EVO_CIEL.CleOuverture, -1)
    return f >= 0 and f or nil
end

-- LES TAILLES SONT DES UNITES A 12000 DU JOUEUR. Repere : la lune de la map
-- fait dans les 600 de rayon a cette distance.
local FISSURE = {
    inclinaison = -12,
    pas = 26, dents = 0.42, fentes = 2, fenteLong = 0.30, epaisseur = 90,
    -- PAS un noir pur : un noir absolu perce un TROU dans le ciel et la fente
    -- se lit comme un autocollant.
    vide = Color(14, 5, 6),
    bord = Color(150, 16, 16),
    lisere = Color(255, 132, 96),
    halo = Color(190, 30, 26),
    pulse = 0.07,
}

local function fissure(t)
    local f = table.Copy(FISSURE)
    for k, v in pairs(t) do f[k] = v end
    return f
end

-- `maps` restreint l'ambiance a certaines maps. Absent = partout. Le menu du
-- Seireitei ne doit pas proposer une Garganta, et celui du Hueco n'a que faire
-- d'une aurore : une liste qui propose l'impossible fait douter du reste.
EVO_CIEL.Ambiances = {

    -- ── LE QUOTIDIEN ────────────────────────────────────────────────────────

    nuit = {
        ordre = 1, label = "Nuit",
        resume = "Le jour tombe petit a petit. Etoiles, filantes, lucioles et grillons.",
        -- LES ASTRES (30/09/2026). Les etoiles n'apparaissent qu'une fois le ciel
        -- vraiment sombre (montee au carre), la voute tourne d'un tiers de degre
        -- par seconde : en une heure, le ciel n'est plus le meme.
        etoiles = { nombre = 240, taille = { 22, 120 }, vitesse = 0.3, voieLactee = true },
        filantes = { periode = 28, chance = 0.55, duree = 0.9 },
        -- Des lucioles au ras du sol, dehors seulement : cinq par seconde, qui
        -- vivent cinq secondes, donc une vingtaine a la fois.
        lucioles = { taux = 5, rayon = 650, hauteur = 90 },
        sons = { volume = 0.18, boucles = {
            { son = "ambient/levels/caves/cave_crickets_loop1.wav", volume = 1.0 },
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 0.45, ton = 90 },
        } },
        -- L'ETALONNAGE DE L'ECLIPSE, repris tel quel : c'est celui que le user a
        -- valide en jeu. Ma premiere nuit teintait en bleu et gardait la map
        -- trop claire ; celle-ci ecrase vraiment la lumiere, et le sol descend
        -- plus bas que le ciel -- exactement ce qui rend une nuit credible.
        -- ECLAIRCIE : 0.118 etait invivable une fois le fondu termine. Ces
        -- valeurs venaient de l'eclipse, mais l'eclipse passait par
        -- DrawColorModify qui REMONTAIT l'image au passage ; en multiplication
        -- pure, le meme nombre donne un ecran noir. Environ deux fois et demie
        -- plus clair, avec un souffle de bleu : une nuit doit rester jouable.
        skyTeinte = Color(86, 90, 116),
        monde = { mulr = 0.30, mulg = 0.29, mulb = 0.38 },
        -- PAS DE BROUILLARD A NOUS. Prendre la main dessus supprime celui de la
        -- map, et une nuit qui s'installe doit garder la brume du mappeur : la
        -- perdre en cours de fondu se voit comme une rupture. L'obscurite seule
        -- fait deja le travail.
        soleil = false,
        --[[ LE HUECO EST DEJA SOMBRE. Ces multiplicateurs sont etalonnes sur le
           Seireitei, en plein jour. Appliques tels quels au Hueco Mundo, deja
           nocturne, ils donnaient un ecran noir ou plus rien n'etait jouable
           (retour user 25/08). On remonte donc la lumiere de moitie sur cette
           carte : le resultat A L'ECRAN est le meme, une nuit, parce qu'on part
           de plus bas. ]]
        parMap = {
            hueco_mundo_v1 = { monde = { mulr = 0.62, mulg = 0.60, mulb = 0.70 } },
        },
        -- ELLE TOMBE, elle ne s'allume pas. Le fondu part du NEUTRE, c'est-a-dire
        -- du plein jour de la map : rien n'est touche a la premiere seconde.
        --
        -- 30 s POUR TESTER. A remettre a 5400 (une heure et demie) avant de
        -- l'utiliser devant les joueurs.
        progressif = { duree = 5400 },
    },

    aurore = {
        ordre = 2, label = "Aurore",
        resume = "Le petit matin, bleu pale et froid. Pour sortir de la nuit.",
        skyTeinte = Color(184, 196, 220),
        monde = { mulr = 0.80, mulg = 0.86, mulb = 0.96 },
        brouillard = { couleur = Color(122, 134, 152), debut = 700, fin = 12000, densite = 0.34 },
        -- (30/09/2026) Le petit matin s'entend : un vent leger et les oiseaux au loin.
        sons = { volume = 0.14, boucles = {
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 1.0, ton = 95 },
        } },
        sonsAlea = { sons = {
            "ambient/levels/forest/dist_birds1.wav", "ambient/levels/forest/dist_birds2.wav", "ambient/levels/forest/dist_birds3.wav",
            "ambient/levels/forest/dist_birds4.wav", "ambient/levels/forest/dist_birds5.wav", "ambient/levels/forest/dist_birds6.wav",
        }, intervalle = { 2.5, 7 }, volume = 0.45, distance = { 400, 1200 }, niveau = 75 },
    },

    crepuscule = {
        ordre = 3, label = "Crepuscule",
        resume = "Or et cuivre. Fin de journee, rien d'inquietant.",
        skyTeinte = Color(255, 172, 104),
        monde = { mulr = 1.00, mulg = 0.86, mulb = 0.69 },
        brouillard = { couleur = Color(124, 84, 54), debut = 900, fin = 15000, densite = 0.30 },
        sons = { volume = 0.12, boucles = {
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 1.0, ton = 88 },
        } },
        sonsAlea = { sons = {
            "ambient/levels/forest/dist_birds2.wav", "ambient/levels/forest/dist_birds4.wav", "ambient/levels/forest/dist_birds6.wav",
        }, intervalle = { 6, 14 }, volume = 0.35, distance = { 500, 1300 }, niveau = 75 },
    },

    brume = {
        ordre = 4, label = "Brume",
        resume = "Le brouillard mange l'horizon. Bon pour une traque.",
        skyTeinte = Color(188, 192, 196),
        monde = { mulr = 0.92, mulg = 0.94, mulb = 0.96 },
        -- La fin TRES courte est tout l'effet : c'est elle qui ferme l'horizon.
        brouillard = { couleur = Color(150, 154, 160), debut = 250, fin = 4200, densite = 0.66 },
        sons = { volume = 0.16, boucles = {
            { son = "ambient/wind/wind_moan1.wav", volume = 1.0, ton = 85 },
        } },
        sonsAlea = { sons = { "ambient/water/rain_drip1.wav", "ambient/water/rain_drip2.wav", "ambient/water/rain_drip3.wav", "ambient/water/rain_drip4.wav" },
                     intervalle = { 3, 9 }, volume = 0.3, distance = { 150, 500 }, niveau = 65 },
    },

    -- ── LA METEO (30/09/2026) ───────────────────────────────────────────────
    -- Trois ambiances qui ne racontent rien d'inquietant : le temps qu'il fait.
    -- Les particules vivent autour de chaque joueur (cl_meteo), jamais sous un
    -- toit, et les boucles de son sont celles du jeu de base.

    pluie = {
        ordre = 5, label = "Pluie",
        resume = "Ciel gris, pluie serree et vent. Sans eclairs.",
        skyTeinte = Color(150, 158, 170),
        monde = { mulr = 0.72, mulg = 0.74, mulb = 0.80 },
        brouillard = { couleur = Color(86, 92, 102), debut = 400, fin = 9000, densite = 0.42 },
        soleil = false,
        -- Traits fins et longs : a 1,3-2,2 de large la goutte se lisait comme un
        -- petit carre (retour axxou 30/09 : « pas dingue ») ; plus fins, plus longs
        -- et plus nombreux, c'est un rideau.
        precip = { type = "pluie", taux = 420, rayon = 520, hauteur = 420, vent = Vector(40, 15, 0),
                   vitesse = 1100, taille = { 0.9, 1.5 }, longueur = 58, alpha = 160 },
        -- Le vent moyen de HL2 et un rideau d'eau au loin ; les gouttes qui tombent
        -- autour du joueur toutes les secondes font le reste.
        sons = { volume = 0.32, boucles = {
            { son = "ambient/wind/wind_med1.wav", volume = 0.6, ton = 92 },
            { son = "ambient/levels/canals/dam_water_loop2.wav", volume = 0.4, ton = 65 },
        } },
        sonsAlea = { sons = { "ambient/water/rain_drip1.wav", "ambient/water/rain_drip2.wav", "ambient/water/rain_drip3.wav", "ambient/water/rain_drip4.wav" },
                     intervalle = { 0.5, 1.6 }, volume = 0.5, distance = { 100, 450 }, niveau = 68 },
        progressif = { duree = 120 },
    },

    neige = {
        ordre = 6, label = "Neige",
        resume = "Ciel blanc, flocons lents et vent leger. Le Seireitei en hiver.",
        skyTeinte = Color(200, 206, 220),
        monde = { mulr = 0.86, mulg = 0.88, mulb = 0.96 },
        brouillard = { couleur = Color(160, 168, 180), debut = 500, fin = 7000, densite = 0.45 },
        soleil = false,
        -- 160 flocons par seconde qui vivent dix secondes : ~1500 sprites de 3 a
        -- 5 unites, sans collision. Le poste le plus charge de la meteo, encore
        -- loin des cendres du Ciel en flammes en surface a l'ecran.
        -- Taille en unites : 1,2 a 2,4, c'est un flocon ; a 3-5 c'etaient des carres
        -- de la taille d'une main (retour axxou 30/09).
        precip = { type = "neige", taux = 220, rayon = 600, hauteur = 450, vent = Vector(18, 8, 0),
                   vitesse = 50, taille = { 1.2, 2.4 }, alpha = 200 },
        sons = { volume = 0.22, boucles = {
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 1.0, ton = 85 },
            { son = "ambient/wind/wind_moan2.wav", volume = 0.35, ton = 75 },
        } },
        sonsAlea = { sons = { "ambient/wind/wind_snippet1.wav", "ambient/wind/wind_snippet2.wav" },
                     intervalle = { 4, 10 }, volume = 0.35, distance = { 300, 900 }, niveau = 70 },
        progressif = { duree = 180 },
    },

    tempete = {
        ordre = 7, label = "Tempete de sable",
        resume = "Le desert se leve : sable qui fouette, vent, l'horizon a vingt metres.",
        maps = { hueco_mundo_v1 = true },
        skyTeinte = Color(214, 160, 96),
        monde = { mulr = 0.92, mulg = 0.78, mulb = 0.56 },
        -- Le brouillard fait la tempete : dense, et il commence tout de suite.
        brouillard = { couleur = Color(150, 112, 62), debut = 150, fin = 2600, densite = 0.78 },
        soleil = false,
        -- Des volutes rases et rapides, nees contre le vent pour traverser la vue.
        precip = { type = "sable", taux = 220, rayon = 600, vent = Vector(520, 140, 0), vitesse = 25,
                   taille = { 7, 16 }, alpha = 90, couleur = Color(218, 186, 128) },
        sons = { volume = 0.5, boucles = {
            { son = "ambient/wind/wasteland_wind.wav", volume = 1.0, ton = 90 },
            { son = "ambient/wind/wind_rooftop1.wav", volume = 0.55, ton = 80 },
            { son = "ambient/atmosphere/terrain_rumble1.wav", volume = 0.3, ton = 70 },
        } },
        sonsAlea = { sons = { "ambient/wind/wind_hit1.wav", "ambient/wind/wind_hit2.wav", "ambient/wind/wind_hit3.wav" },
                     intervalle = { 1, 3 }, volume = 0.8, distance = { 100, 500 }, niveau = 75, ton = { 80, 100 } },
        progressif = { duree = 90 },
    },

    -- ── LES NUITS REMARQUABLES (30/09/2026) ─────────────────────────────────
    -- Meme etalonnage que la Nuit (valide en jeu), chacune avec son spectacle.

    comete = {
        ordre = 8, label = "Comète",
        resume = "La nuit tombe et une grande comète traverse le ciel, avec ses deux queues.",
        skyTeinte = Color(80, 86, 118),
        monde = { mulr = 0.34, mulg = 0.34, mulb = 0.44 },
        soleil = false,
        parMap = { hueco_mundo_v1 = { monde = { mulr = 0.64, mulg = 0.62, mulb = 0.72 } } },
        etoiles = { nombre = 260, taille = { 22, 120 }, vitesse = 0.2, voieLactee = true },
        -- `dir` : la tete ; `queue` : ou la queue pointe (loin du soleil cache) ;
        -- `longueur` en degres de ciel ; `derive` : degres par heure.
        comete = { dir = Angle(-30, 135, 0), queue = Angle(-58, 205, 0), longueur = 38, rayon = 180, derive = 6 },
        sons = { volume = 0.14, boucles = {
            { son = "ambient/levels/caves/cave_crickets_loop1.wav", volume = 1.0 },
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 0.4, ton = 90 },
        } },
        progressif = { duree = 600 },
    },

    aurore_boreale = {
        ordre = 9, label = "Aurore boréale",
        resume = "Nuit froide et claire, des rideaux verts et violets ondulent dans le ciel.",
        skyTeinte = Color(70, 88, 112),
        monde = { mulr = 0.32, mulg = 0.38, mulb = 0.44 },
        soleil = false,
        parMap = { hueco_mundo_v1 = { monde = { mulr = 0.60, mulg = 0.66, mulb = 0.72 } } },
        etoiles = { nombre = 220, taille = { 20, 100 }, vitesse = 0.15, voieLactee = true },
        -- `yaw` : le centre des rideaux ; `largeur` et `haut` en degres.
        aurore = { yaw = 20, largeur = 150, bas = 9, haut = 30, rideaux = 3,
                   couleur = Color(80, 255, 150), sommet = Color(170, 90, 255) },
        sons = { volume = 0.16, boucles = {
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 1.0, ton = 80 },
        } },
        progressif = { duree = 600 },
    },

    hanami = {
        ordre = 10, label = "Hanami",
        resume = "Lumière douce et pétales de cerisier qui volent partout. Pour une fête.",
        maps = { rp_seireitei_v1 = true },
        skyTeinte = Color(255, 226, 236),
        monde = { mulr = 1.00, mulg = 0.95, mulb = 0.97 },
        precip = { type = "petales", taux = 70, rayon = 700, hauteur = 380, vent = Vector(30, 18, 0),
                   vitesse = 35, taille = { 1.6, 2.8 }, alpha = 235 },
        sons = { volume = 0.12, boucles = {
            { son = "ambient/ambience/wind_light02_loop.wav", volume = 1.0, ton = 100 },
        } },
        sonsAlea = { sons = {
            "ambient/levels/forest/dist_birds1.wav", "ambient/levels/forest/dist_birds3.wav", "ambient/levels/forest/dist_birds5.wav",
            "ambient/levels/canals/windchime2.wav", "ambient/levels/canals/windchime4.wav",
        }, intervalle = { 3, 8 }, volume = 0.35, distance = { 300, 1000 }, niveau = 72 },
        progressif = { duree = 60 },
    },

    automne = {
        ordre = 11, label = "Automne",
        resume = "Lumière rousse, vent, et des feuilles mortes qui tourbillonnent.",
        maps = { rp_seireitei_v1 = true },
        skyTeinte = Color(255, 196, 140),
        monde = { mulr = 1.00, mulg = 0.88, mulb = 0.74 },
        brouillard = { couleur = Color(130, 98, 70), debut = 900, fin = 14000, densite = 0.28 },
        precip = { type = "feuilles", taux = 45, rayon = 700, hauteur = 380, vent = Vector(70, 30, 0),
                   vitesse = 45, taille = { 2.4, 4 }, alpha = 245 },
        sons = { volume = 0.22, boucles = {
            { son = "ambient/wind/wind_med1.wav", volume = 0.7, ton = 95 },
        } },
        sonsAlea = { sons = { "ambient/wind/wind_snippet1.wav", "ambient/wind/wind_snippet2.wav" },
                     intervalle = { 4, 9 }, volume = 0.4, distance = { 200, 700 }, niveau = 70 },
        progressif = { duree = 90 },
    },

    -- ── LES EVENEMENTS ──────────────────────────────────────────────────────

    sang = {
        ordre = 20, label = "Lune de sang",
        resume = "Une lune rouge enorme qui palpite, le ciel vire au rouge sombre.",
        skyTeinte = Color(150, 26, 22),
        monde = { mulr = 0.94, mulg = 0.70, mulb = 0.68 },
        brouillard = { couleur = Color(58, 10, 9), debut = 900, fin = 16000, densite = 0.34 },
        -- LA LUNE (30/09/2026) : dessinee par nous, en plus de celle de la map.
        -- Direction ABSOLUE, la meme pour tous : les joueurs se la montrent du
        -- doigt. Rayon a 12000 unites (la lune de la map fait ~600).
        lune = { dir = Angle(-38, 215, 0), rayon = 820, couleur = Color(210, 26, 24), coeur = Color(255, 70, 50),
                 halo = 2.8, pulse = 0.10, vitesse = 0.9 },
        -- Une nappe sourde et un vent qui gemit, bas : ca pese sans qu'on sache d'ou.
        sons = { volume = 0.2, boucles = {
            { son = "ambient/atmosphere/ambience6.wav", volume = 1.0, ton = 70 },
            { son = "ambient/wind/wind_moan4.wav", volume = 0.5, ton = 70 },
        } },
    },

    pluie_sang = {
        ordre = 21, label = "Pluie de sang",
        resume = "La lune de sang, et il pleut rouge. Pour les nuits qui tournent mal.",
        skyTeinte = Color(140, 22, 20),
        monde = { mulr = 0.86, mulg = 0.62, mulb = 0.60 },
        brouillard = { couleur = Color(54, 9, 8), debut = 600, fin = 12000, densite = 0.42 },
        soleil = false,
        lune = { dir = Angle(-38, 215, 0), rayon = 820, couleur = Color(210, 26, 24), coeur = Color(255, 70, 50),
                 halo = 2.8, pulse = 0.10, vitesse = 0.9 },
        precip = { type = "pluie", taux = 380, rayon = 520, hauteur = 420, vent = Vector(30, 10, 0),
                   vitesse = 1000, taille = { 0.9, 1.6 }, longueur = 55, alpha = 185, couleur = Color(170, 16, 18) },
        sons = { volume = 0.28, boucles = {
            { son = "ambient/levels/canals/dam_water_loop2.wav", volume = 0.5, ton = 60 },
            { son = "ambient/atmosphere/ambience6.wav", volume = 0.8, ton = 65 },
        } },
        sonsAlea = { sons = { "ambient/water/rain_drip1.wav", "ambient/water/rain_drip2.wav", "ambient/water/rain_drip3.wav", "ambient/water/rain_drip4.wav" },
                     intervalle = { 0.6, 1.8 }, volume = 0.45, distance = { 100, 450 }, niveau = 68, ton = { 70, 85 } },
        progressif = { duree = 90 },
    },

    orage = {
        ordre = 22, label = "Orage",
        resume = "Ciel plombe, pluie battante, foudre qui dechire le ciel et tonnerre.",
        -- LA PLUIE (30/09/2026) : des traits rapides autour du joueur, pousses par
        -- le vent. 340 par seconde qui vivent moins d'une demi-seconde : ~150
        -- traits vivants, un trace vers le ciel par naissance.
        precip = { type = "pluie", taux = 460, rayon = 520, hauteur = 420, vent = Vector(90, 30, 0),
                   vitesse = 1150, taille = { 0.9, 1.5 }, longueur = 60, alpha = 165 },
        -- LE CORPS DE L'ECLAIR : il tombe au tempo de `eclairs`. Le tonnerre
        -- arrive entre 0,6 et 3,2 s apres, selon le numero de la periode ; sous
        -- 1,2 s le coup est proche : plus fort, plus grave, et le sol tremble.
        foudre = { largeur = 95, branches = 3, couleur = Color(214, 226, 255),
                   tonnerre = { min = 0.6, max = 3.2, volume = 0.95 }, lumiere = true, secousse = true },
        -- Le vent et le rideau de pluie, bas : deux boucles du jeu de base.
        sons = { volume = 0.36, boucles = {
            { son = "ambient/wind/wind_med2.wav", volume = 0.8, ton = 88 },
            { son = "ambient/wind/wind_moan1.wav", volume = 0.45, ton = 80 },
            { son = "ambient/levels/canals/dam_water_loop2.wav", volume = 0.45, ton = 65 },
        } },
        -- Gouttes et rafales, entre les coups de tonnerre.
        sonsAlea = { sons = {
            "ambient/water/rain_drip1.wav", "ambient/water/rain_drip2.wav", "ambient/water/rain_drip3.wav", "ambient/water/rain_drip4.wav",
            "ambient/wind/wind_hit1.wav", "ambient/wind/wind_hit2.wav", "ambient/wind/wind_hit3.wav",
        }, intervalle = { 0.6, 2.2 }, volume = 0.55, distance = { 100, 600 }, niveau = 70 },
        skyTeinte = Color(102, 110, 126),
        monde = { mulr = 0.52, mulg = 0.56, mulb = 0.68 },
        brouillard = { couleur = Color(32, 36, 46), debut = 500, fin = 9000, densite = 0.48 },
        -- Les eclairs sont TIRES DU TEMPS, pas du hasard local : tout le serveur
        -- voit le meme au meme instant. Un eclair que le voisin ne voit pas ne
        -- raconte rien, c'est l'erreur qu'avait la pluie.
        eclairs = { periode = 7, chance = 0.55, duree = 0.16, couleur = Color(214, 226, 255), force = 120 },
        -- Un ciel d'orage avec le soleil au milieu ne tient pas debout.
        soleil = false,
    },

    eclipse = {
        ordre = 23, label = "Eclipse",
        resume = "Le noir d'un coup. Un soleil noir a couronne, et les etoiles en plein jour.",
        -- LE SOLEIL NOIR (30/09/2026) : disque noir, couronne qui palpite, rais
        -- qui tournent (cl_astres), a la place de l'env_sun retire. L'ancien
        -- essai dessinait a l'ecran ; celui-ci est dans le ciel, derriere le
        -- monde, a l'echelle de la lune de la map.
        soleilNoir = { dir = Angle(-56, 75, 0), rayon = 560, couronne = Color(255, 226, 180), rais = 10 },
        etoiles = { nombre = 150, taille = { 20, 90 }, vitesse = 0, alpha = 0.8 },
        sons = { volume = 0.22, boucles = {
            { son = "ambient/atmosphere/ambience5.wav", volume = 1.0, ton = 75 },
            { son = "ambient/atmosphere/drone2lp.wav", volume = 0.4, ton = 60 },
        } },
        -- PAS DE SOLEIL NOIR DESSINE : le disque et ses rais ont ete retires,
        -- ils ne rendaient pas. Ce qui marche dans cette ambiance, c'est le seul
        -- etalonnage -- la lumiere qui tombe, pas un objet ajoute au ciel.
        --
        -- EXCEPTION ASSUMEE A LA REGLE DE DOSAGE. Partout ailleurs le ciel et le
        -- monde descendent ensemble ; ici le monde descend SEUL, une seconde
        -- fois d'un facteur 1.7, et le ciel reste ou il est. C'est ce que fait
        -- une vraie eclipse : le sol devient noir alors que la couronne tient
        -- encore le ciel. Le contraste entre les deux EST l'effet.
        skyTeinte = Color(49, 46, 61),
        monde = { mulr = 0.118, mulg = 0.112, mulb = 0.153 },
        brouillard = { couleur = Color(8, 7, 12), debut = 600, fin = 11000, densite = 0.52 },
        soleil = false,
        -- MEME CORRECTION QUE LA NUIT, et pour la meme raison : le Hueco Mundo
        -- est deja nocturne, ces valeurs sont etalonnees sur le plein jour du
        -- Seireitei. On applique le meme facteur de rattrapage (environ x2)
        -- pour retrouver A L'ECRAN l'obscurite voulue au lieu du noir complet.
        -- L'eclipse reste nettement plus sombre que la nuit sur les deux
        -- cartes : c'est le rapport entre les deux qui compte, pas le nombre.
        parMap = {
            hueco_mundo_v1 = { monde = { mulr = 0.245, mulg = 0.232, mulb = 0.317 } },
        },
    },

    -- L'ECLIPSE LENTE (30/09/2026) : la lune mange le soleil sur la duree choisie.
    -- Le soleil de la map est retire, on dessine le notre (cl_astres,
    -- `recouvrement`) ; la lumiere ne tombe vraiment qu'a la fin (`courbe` 4),
    -- comme une vraie eclipse ; couronne, anneau de diamant et etoiles a la
    -- totalite. C'est aussi le ciel de l'Eclipse rituelle d'evo_events.
    eclipse_lente = {
        ordre = 24, label = "Éclipse (lente)",
        resume = "La lune recouvre le soleil peu à peu, jusqu'à la totalité. Durée au choix.",
        skyTeinte = Color(49, 46, 61),
        monde = { mulr = 0.118, mulg = 0.112, mulb = 0.153 },
        brouillard = { couleur = Color(8, 7, 12), debut = 600, fin = 11000, densite = 0.52 },
        soleil = false,
        parMap = { hueco_mundo_v1 = { monde = { mulr = 0.245, mulg = 0.232, mulb = 0.317 } } },
        soleilNoir = { dir = Angle(-50, 75, 0), rayon = 560, couronne = Color(255, 226, 180), rais = 10, recouvrement = true },
        etoiles = { nombre = 160, taille = { 20, 90 }, vitesse = 0, alpha = 0.85, seuil = 0.93 },
        sons = { volume = 0.2, boucles = {
            { son = "ambient/atmosphere/ambience5.wav", volume = 1.0, ton = 75 },
            { son = "ambient/atmosphere/drone2lp.wav", volume = 0.35, ton = 60 },
        } },
        progressif = { duree = 600, courbe = 4 },
    },

    reiatsu = {
        ordre = 25, label = "Pression spirituelle",
        resume = "L'horizon se ferme a trente metres, des motes violettes montent du sol.",
        skyTeinte = Color(126, 84, 150),
        monde = { mulr = 0.72, mulg = 0.60, mulb = 0.82 },
        brouillard = { couleur = Color(46, 28, 62), debut = 300, fin = 5200, densite = 0.60 },
        -- (30/09/2026) Les motes : des lucioles violettes qui MONTENT, et un
        -- grondement sourd sous les pieds.
        lucioles = { taux = 9, rayon = 520, hauteur = 40, couleur = Color(200, 140, 255), montee = 22 },
        sons = { volume = 0.32, boucles = {
            { son = "ambient/atmosphere/terrain_rumble1.wav", volume = 1.0, ton = 60 },
            { son = "ambient/atmosphere/drone4lp.wav", volume = 0.45, ton = 55 },
        } },
    },

    -- LES MENOS (30/09/2026) : le vrai modele du Menos Grande (pack #5, celui du
    -- PNJ), plusieurs, immenses et voiles de brume, qui marchent lentement sur
    -- l'horizon du Hueco. De temps en temps l'un d'eux tire un cero vers le ciel.
    menos = {
        ordre = 26, label = "Menos à l'horizon",
        resume = "Des Menos Grande géants marchent lentement sur l'horizon. Parfois, un cero.",
        maps = { hueco_mundo_v1 = true },
        skyTeinte = Color(120, 108, 128),
        monde = { mulr = 0.80, mulg = 0.76, mulb = 0.84 },
        brouillard = { couleur = Color(36, 32, 44), debut = 800, fin = 11000, densite = 0.5 },
        -- `hauteur` : la taille d'un Menos a l'ecran, en unites a `distance` ;
        -- `base` : ou sont ses pieds par rapport aux yeux (sous l'horizon).
        menos = { nombre = 4, yaw = 60, ecart = 38, distance = 6500, hauteur = 2600, base = -900,
                  vitesse = 0.22, cero = { periode = 35, chance = 0.6, duree = 2.6 } },
        sons = { volume = 0.3, boucles = {
            { son = "ambient/atmosphere/terrain_rumble1.wav", volume = 1.0, ton = 55 },
            { son = "ambient/wind/wasteland_wind.wav", volume = 0.5, ton = 80 },
        } },
        progressif = { duree = 60 },
    },

    faille = {
        ordre = 27, label = "Garganta",
        resume = "Une dechirure s'ouvre. Taille reglable en bas du menu.",
        maps = { hueco_mundo_v1 = true },
        skyTeinte = Color(140, 24, 20),
        monde = { mulr = 0.92, mulg = 0.68, mulb = 0.66 },
        brouillard = { couleur = Color(52, 9, 8), debut = 800, fin = 15000, densite = 0.36 },
        faille = fissure({ dir = Angle(-22, 73.5, 0), longueur = 7800, hauteur = 1500 }),
        -- LE PLAN DE LA CINEMATIQUE, releve en jeu par le user. Une camera
        -- posee la ou le cadre est bon, et le meme pour tout le monde : faire
        -- pivoter la vue depuis les yeux de chacun donnait un mur ou un plafond
        -- selon l'endroit ou il se trouvait.
        cinematique = { pos = Vector(1399.30, 1775.95, 1691.77), ang = Angle(-12.65, 90.94, 0), fov = 75 },
        -- UNE HEURE. `depart` n'est pas nul : a zero, rien n'apparait pendant un
        -- quart d'heure et on croit que l'evenement ne marche pas.
        croissance = { duree = 3600, depart = 0.18 },
        -- (30/09/2026) La faille s'entend : une nappe grave et un vent qui gemit.
        sons = { volume = 0.24, boucles = {
            { son = "ambient/atmosphere/ambience_base.wav", volume = 1.0, ton = 65 },
            { son = "ambient/wind/wind_moan2.wav", volume = 0.5, ton = 70 },
            { son = "ambient/atmosphere/terrain_rumble1.wav", volume = 0.35, ton = 60 },
        } },
    },

    invasion = {
        ordre = 28, label = "Invasion",
        resume = "Garganta, ciel rouge et eclairs. Tout en meme temps.",
        maps = { hueco_mundo_v1 = true },
        skyTeinte = Color(126, 20, 16),
        monde = { mulr = 0.88, mulg = 0.60, mulb = 0.58 },
        brouillard = { couleur = Color(44, 8, 7), debut = 600, fin = 12000, densite = 0.44 },
        faille = fissure({ dir = Angle(-22, 73.5, 0), longueur = 9000, hauteur = 1800, dents = 0.5 }),
        -- LE PLAN DE LA CINEMATIQUE, releve en jeu par le user. Une camera
        -- posee la ou le cadre est bon, et le meme pour tout le monde : faire
        -- pivoter la vue depuis les yeux de chacun donnait un mur ou un plafond
        -- selon l'endroit ou il se trouvait.
        cinematique = { pos = Vector(1399.30, 1775.95, 1691.77), ang = Angle(-12.65, 90.94, 0), fov = 75 },
        croissance = { duree = 3600, depart = 0.18 },
        eclairs = { periode = 9, chance = 0.45, duree = 0.13, couleur = Color(255, 176, 150), force = 90 },
        -- (30/09/2026) Les eclairs ont un corps, rouge, et une PLUIE DE METEORES
        -- traverse le ciel toutes les cinq secondes : gros, orange, une tete qui
        -- brille. C'est le ciel qui tombe sur le Hueco.
        foudre = { largeur = 80, branches = 2, couleur = Color(255, 150, 120),
                   tonnerre = { min = 0.4, max = 2.4, volume = 0.9 }, lumiere = true, secousse = true },
        filantes = { periode = 5, chance = 0.85, duree = 1.1, couleur = Color(255, 120, 60), largeur = 3.2, tete = 900, queue = 0.12 },
        sons = { volume = 0.3, boucles = {
            { son = "ambient/atmosphere/ambience_base.wav", volume = 1.0, ton = 60 },
            { son = "ambient/wind/wind_rooftop1.wav", volume = 0.6, ton = 70 },
            { son = "ambient/atmosphere/terrain_rumble1.wav", volume = 0.5, ton = 55 },
        } },
        sonsAlea = { sons = { "ambient/wind/wind_hit1.wav", "ambient/wind/wind_hit2.wav", "ambient/wind/wind_hit3.wav" },
                     intervalle = { 2, 6 }, volume = 0.6, distance = { 150, 600 }, niveau = 72, ton = { 70, 90 } },
    },

    incendie = {
        ordre = 29, label = "Ciel en flammes",
        resume = "Le ciel brule, la cendre tombe, les braises montent. Le Seireitei en feu.",
        -- Etalonne sur le plein jour du Seireitei : c'est pour lui qu'il a ete
        -- demande (22/09/2026). Multiplier le ciel de jour par cet orange rend
        -- le bleu brun-rouge et les nuages orange vif : ce sont eux qui font
        -- « ca brule », on ne dessine aucune flamme.
        maps = { rp_seireitei_v1 = true },
        skyTeinte = Color(255, 92, 34),
        monde = { mulr = 0.98, mulg = 0.66, mulb = 0.44 },
        -- Une fumee rousse qui ferme l'horizon sans le boucher : on doit encore
        -- voir les toits bruler au loin.
        brouillard = { couleur = Color(88, 26, 10), debut = 500, fin = 8500, densite = 0.50 },
        -- Un soleil blanc au milieu d'un ciel en feu ne tient pas debout.
        soleil = false,
        -- La lueur : le monde respire comme sous un feu, une pulsation lente et
        -- irreguliere de la teinte (cl_ciel, EVO_CIEL.Lueur). `amplitude` est la
        -- part de lumiere qui s'en va au creux, `vitesse` le rythme.
        lueur = { amplitude = 0.09, vitesse = 1.7 },
        -- Les cendres (cl_cendres) : `taux` flocons par seconde autour de la
        -- camera, `braises` par seconde, dans un cylindre de `rayon` et de
        -- `hauteur` au-dessus des yeux, poussees par `vent` (unites/s).
        -- BUDGET : 20 flocons par seconde qui vivent 6 a 10 s, soit ~160 sprites
        -- de 3 a 5 unites vivants, un tracer par naissance. Rien de mesurable.
        cendres = { taux = 20, braises = 3, rayon = 700, hauteur = 420, chute = 16, vent = Vector(24, 10, 0) },
        -- Le feu s'entend (cl_feu) : des boucles du jeu de base sur le joueur,
        -- bas. `volume` est le plafond, chaque boucle en prend une part ; `ton`
        -- ralentit (85 = plus grave). Demande user du 22/09/2026 : « assez bas ».
        feu = { volume = 0.25, boucles = {
            { son = "ambient/fire/fire_small_loop2.wav", volume = 1.0 },           -- le crepitement
            { son = "ambient/fire/fire_big_loop1.wav",   volume = 0.4, ton = 85 }, -- le souffle, au loin
        } },
        -- La fumee dans le ciel (cl_feu) : `nappes` qui derivent en hauteur a
        -- `derive` degres par seconde, `colonnes` qui montent de l'horizon, le
        -- tout a `distance` unites, entre `taille` de large.
        -- BUDGET : c'est LE poste qui coute, par la surface translucide a
        -- l'ecran. 15 quads a cette distance et cette taille, dont la moitie
        -- hors champ et coupes avant le dessin : environ 0,4 ecran de
        -- surimpression, moins qu'une passe de teinte. Ne pas remonter
        -- `nappes` ou `taille` sans mesurer (evo_ciel_couche_fumee 0/1).
        fumee = { nappes = 10, colonnes = 5, distance = 11000, couleur = Color(40, 31, 27), alpha = 175,
                  derive = 0.35, taille = { 1300, 2400 } },
        -- Le ciel se transforme en TRENTE MINUTES (demande du 23/09/2026). La
        -- duree se change au lancement, comme pour la nuit.
        progressif = { duree = 1800 },
        -- Les feux du plan de la carte (evo_feux, !feu sauver) s'allument peu a
        -- peu sur `duree` secondes depuis le lancement, en courbe en S, dans
        -- l'ordre ou ils ont ete poses : avec 50 feux, ~10 a 15 min, ~30 a
        -- 30 min, tous a 50 min. Une duree imposee au lancement les accelere
        -- dans la meme proportion que le ciel.
        embrasement = { duree = 3000 },
    },

    planche = {
        ordre = 40, label = "Planche de manga",
        resume = "LE trait d'encre. Parti pris fort, quelques minutes maximum.",
        skyTeinte = Color(150, 30, 24),
        monde = { mulr = 1.00, mulg = 0.84, mulb = 0.82 },
        brouillard = { couleur = Color(48, 8, 7), debut = 700, fin = 13000, densite = 0.40 },
        -- La SEULE ambiance qui porte l'encre. Elle etait sur la moitie des
        -- autres et se voyait partout, alors que c'est un choix qui doit se
        -- decider, pas se subir.
        encre = { seuil = 0.32, force = 27 },
    },
}

--[[ SURCHARGE PAR CARTE (25/08). Une meme ambiance ne rend pas pareil selon la
   carte, parce que la carte n'est pas eclairee pareil. Le Seireitei est en
   plein jour ; le Hueco Mundo est deja un desert nocturne. Multiplier la
   lumiere par 0,30 sur une carte deja sombre ne donne pas une nuit, ca donne un
   ecran noir -- constate en jeu.

   Plutot que d'inventer une deuxieme ambiance « nuit du Hueco », qu'il faudrait
   penser a modifier a chaque retouche de la premiere, une ambiance peut
   remplacer certaines de ses valeurs sur une carte donnee. Le reste (label,
   resume, ordre, cinematique) reste ecrit une seule fois. ]]
local function fusionner(base, sur)
    local out = {}
    for k, v in pairs(base) do out[k] = v end
    for k, v in pairs(sur) do
        if istable(v) and istable(out[k]) then
            local t = {}
            for k2, v2 in pairs(out[k]) do t[k2] = v2 end
            for k2, v2 in pairs(v) do t[k2] = v2 end
            out[k] = t
        else
            out[k] = v
        end
    end
    return out
end

function EVO_CIEL.Ambiance(sNom)
    local t = EVO_CIEL.Ambiances[string.lower(sNom or "")]
    if not t then return nil end
    local sur = t.parMap and t.parMap[game.GetMap()]
    if not sur then return t end
    -- Recalculee a chaque appel : la carte ne change pas en cours de partie, et
    -- un cache ici obligerait a l'invalider au moindre rechargement de config.
    return fusionner(t, sur)
end

-- Triee par `ordre`, et filtree sur la map : sous le stress d'une animation, une
-- liste qui bouge ou qui propose l'impossible fait cliquer a cote.
function EVO_CIEL.ListeAmbiances()
    local sMap = game.GetMap()
    local t = {}
    for k, a in pairs(EVO_CIEL.Ambiances) do
        if not a.maps or a.maps[sMap] then t[#t + 1] = k end
    end
    table.sort(t, function(a, b)
        local oa = EVO_CIEL.Ambiances[a].ordre or 99
        local ob = EVO_CIEL.Ambiances[b].ordre or 99
        if oa ~= ob then return oa < ob end
        return a < b
    end)
    return t
end

-- L'ambiance en cours, lisible des deux cotes. "" = celle de la map.
function EVO_CIEL.EnCours()
    return GetGlobalString(EVO_CIEL.CleGlobale, "")
end
