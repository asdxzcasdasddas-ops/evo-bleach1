-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_meteo.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - la meteo : ce qui tombe (pluie, neige, sable), ce qui vole bas
-- (lucioles, motes de reiatsu), et la foudre avec son tonnerre.
--
-- DANS LE MONDE, PAS SUR L'ECRAN, comme les cendres : des particules 3D
-- (ParticleEmitter) autour de la camera de chaque client, sans collision (une
-- goutte qui traverse un toit ne se voit pas, une collision par goutte se
-- paierait), et un trace vers le ciel a la naissance : pas de pluie sous un
-- toit. Le nombre de naissances suit le TEMPS, pas les images.
--
-- LA FOUDRE : l'eclair de cl_ciel (le flash plein ecran) existait deja, tire
-- du temps. Ici on lui donne un CORPS : un trait brise du ciel a l'horizon,
-- ses branches, un halo au sommet, une lumiere dynamique qui eclaire vraiment
-- les murs du cote du coup, puis le tonnerre qui arrive APRES, a un delai tire
-- du meme numero de periode (proche = fort et vite, loin = sourd et tard).
-- Meme numero, meme instant, meme direction chez tout le monde.
--
-- Interrupteurs : evo_ciel_couche_precip, evo_ciel_couche_lucioles,
-- evo_ciel_couche_foudre.
-- ============================================================================

local CV_PRECIP = CreateClientConVar("evo_ciel_couche_precip", "1", true, false,
    "Pluie, neige et sable des ambiances")
local CV_LUCIOLES = CreateClientConVar("evo_ciel_couche_lucioles", "1", true, false,
    "Lucioles et motes des ambiances")
local CV_FOUDRE = CreateClientConVar("evo_ciel_couche_foudre", "1", true, false,
    "Trait de foudre, lumiere et tonnerre des ambiances")

-- Materiaux du jeu de base, rien a telecharger.
-- NEIGE : PAS `particle/snow` (retour axxou 30/09, capture) : cette texture est faite
-- pour le systeme de precipitations du moteur, en sprite elle rend un CARRE blanc
-- a bord sombre. Le sprite de fumee (celui des cendres, valide en jeu) en blanc
-- et petit donne un flocon doux.
local MATS = {
    pluie = "particle/rain",
    neige = "particle/smokesprites_0001",
    sable = "particle/smokesprites_0001",
    luciole = "sprites/light_glow02_add",
}
-- PETALES ET FEUILLES (30/09/2026) : les particules sakura du mappeur pointent
-- vers des materiaux qu'aucun pack ne livre (verifie dans les .gma et dans les
-- .bsp) ; on prend les eclats du jeu de base, teintes : un eclat de cendre rose
-- qui tourne sur lui-meme se lit comme un petale, un eclat de bois roux comme
-- une feuille morte.
local MATS_MULTI = {
    petales = { "effects/fleck_ash1", "effects/fleck_ash2" },
    feuilles = { "effects/fleck_wood1", "effects/fleck_wood2", "effects/fleck_ash3" },
}
local TEINTES_FEUILLES = { { 214, 96, 34 }, { 190, 60, 30 }, { 226, 160, 50 }, { 150, 86, 40 }, { 200, 120, 36 } }

local function AleaDe(n)
    local x = math.sin(n * 12.9898) * 43758.5453
    return x - math.floor(x)
end

-- ── L'emetteur partage ──────────────────────────────────────────────────────
local _em = nil
local function Emetteur()
    if _em and _em:IsValid() then return _em end
    _em = ParticleEmitter(EyePos(), false)
    if _em then _em:SetNearClip(8, 30) end
    return _em
end
local function Ranger()
    if _em and _em:IsValid() then _em:Finish() end
    _em = nil
end

local _tr = { mask = MASK_SOLID_BRUSHONLY }
local function VoitLeCiel(vPos)
    _tr.start = vPos
    _tr.endpos = vPos + Vector(0, 0, 9000)
    local tr = util.TraceLine(_tr)
    return (not tr.Hit) or tr.HitSky
end

-- ── Ce qui tombe ────────────────────────────────────────────────────────────
-- Une naissance de pluie : un trait etire le long de sa vitesse (longueur),
-- rapide, qui meurt a peu pres a la hauteur du sol. De neige : un flocon lent
-- qui derive. De sable : une volute rase et rapide, nee du cote d'ou vient le
-- vent pour traverser le champ de vision.
local function Naissance(em, P, vOeil)
    local typ = P.type or "pluie"
    local vent = P.vent or Vector(0, 0, 0)
    local a = math.Rand(0, math.pi * 2)
    local rayon = P.rayon or 520
    local vPos
    if typ == "sable" then
        -- Contre le vent, a mi-hauteur d'homme : les volutes arrivent sur le joueur.
        local d = vent:GetNormalized()
        vPos = vOeil - d * math.Rand(rayon * 0.6, rayon * 1.3)
            + Vector(math.cos(a), math.sin(a), 0) * math.Rand(0, rayon * 0.9)
            + Vector(0, 0, math.Rand(-70, 90))
    else
        local r = math.Rand(30, rayon)
        vPos = vOeil + Vector(math.cos(a) * r, math.sin(a) * r, math.Rand(80, P.hauteur or 420))
    end
    if not VoitLeCiel(vPos) then return end

    local tMulti = MATS_MULTI[typ]
    local p = em:Add(tMulti and tMulti[math.random(#tMulti)] or MATS[typ] or MATS.pluie, vPos)
    if not p then return end
    local taille = P.taille or {}
    local s = math.Rand(taille[1] or 1.5, taille[2] or 2.5)
    p:SetLighting(false)
    p:SetCollide(false)
    local c = P.couleur
    if typ == "pluie" then
        local vit = P.vitesse or 1150
        p:SetVelocity(vent + Vector(math.Rand(-20, 20), math.Rand(-20, 20), -vit))
        p:SetGravity(Vector(0, 0, 0))
        -- Morte a la hauteur du sol, a peu pres : le trajet vertical divise par la vitesse.
        p:SetDieTime((vPos.z - vOeil.z + 90) / vit)
        p:SetStartAlpha(P.alpha or 140) p:SetEndAlpha(P.alpha or 140)
        p:SetStartSize(s) p:SetEndSize(s)
        p:SetStartLength(P.longueur or 42) p:SetEndLength(P.longueur or 42)
        p:SetColor(c and c.r or 200, c and c.g or 212, c and c.b or 228)
    elseif typ == "neige" then
        local vit = P.vitesse or 55
        p:SetVelocity(vent + VectorRand() * 12 + Vector(0, 0, -vit))
        p:SetGravity(Vector(0, 0, -6))
        p:SetAirResistance(8)
        p:SetDieTime(math.Rand(7, 11))
        p:SetStartAlpha(P.alpha or 200) p:SetEndAlpha(0)
        p:SetStartSize(s) p:SetEndSize(s * 0.7)
        p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-0.6, 0.6))
        p:SetColor(c and c.r or 250, c and c.g or 252, c and c.b or 255)
    elseif typ == "petales" or typ == "feuilles" then
        -- Ils planent : chute lente, vent, et ils tournent vite sur eux-memes
        -- (c'est le tournoiement qui fait le petale, pas la forme).
        local vit = P.vitesse or 40
        p:SetVelocity(vent * math.Rand(0.7, 1.2) + VectorRand() * 18 + Vector(0, 0, -vit))
        p:SetGravity(Vector(0, 0, -6))
        p:SetAirResistance(6)
        p:SetDieTime(math.Rand(8, 12))
        p:SetStartAlpha(P.alpha or 235) p:SetEndAlpha(0)
        p:SetStartSize(s) p:SetEndSize(s)
        p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-4, 4))
        if typ == "petales" then
            local k = math.Rand(0, 1)
            p:SetColor(255, 176 + k * 40, 196 + k * 30)
        else
            local tc = TEINTES_FEUILLES[math.random(#TEINTES_FEUILLES)]
            p:SetColor(tc[1], tc[2], tc[3])
        end
    else -- sable
        p:SetVelocity(vent * math.Rand(0.8, 1.25) + VectorRand() * 30 + Vector(0, 0, -(P.vitesse or 25)))
        p:SetGravity(Vector(0, 0, -4))
        p:SetAirResistance(4)
        p:SetDieTime(math.Rand(2.5, 4.5))
        p:SetStartAlpha(P.alpha or 90) p:SetEndAlpha(0)
        p:SetStartSize(s) p:SetEndSize(s * 2.2)
        p:SetRoll(math.Rand(0, 360)) p:SetRollDelta(math.Rand(-2, 2))
        p:SetColor((c and c.r or 218) + math.Rand(-14, 14), (c and c.g or 186) + math.Rand(-14, 14), (c and c.b or 128) + math.Rand(-10, 10))
    end
end

-- ── Ce qui vole bas ─────────────────────────────────────────────────────────
-- Une luciole nait pres du SOL (trace vers le bas depuis un point autour du
-- joueur), derive lentement et clignote : son alpha suit une cloche sur sa vie
-- multipliee par un battement qui lui est propre. `montee` la fait grimper :
-- c'est la mote de reiatsu de la Pression spirituelle.
local _trBas = { mask = MASK_SOLID_BRUSHONLY }
local function Luciole(em, L, vOeil)
    local a = math.Rand(0, math.pi * 2)
    local r = math.Rand(60, L.rayon or 650)
    local vHaut = vOeil + Vector(math.cos(a) * r, math.sin(a) * r, 120)
    if not VoitLeCiel(vHaut) then return end
    _trBas.start = vHaut
    _trBas.endpos = vHaut - Vector(0, 0, 900)
    local tr = util.TraceLine(_trBas)
    if not tr.Hit then return end
    local vPos = tr.HitPos + Vector(0, 0, math.Rand(18, L.hauteur or 90))

    local p = em:Add(MATS.luciole, vPos)
    if not p then return end
    local c = L.couleur or Color(190, 255, 120)
    p:SetVelocity(VectorRand() * 9 + Vector(0, 0, L.montee or 0))
    p:SetGravity(Vector(0, 0, (L.montee or 0) * 0.3))
    p:SetAirResistance(2)
    p:SetDieTime(math.Rand(4, 7))
    p:SetStartAlpha(0) p:SetEndAlpha(0)
    local s = math.Rand(2.4, 4.2)
    p:SetStartSize(s) p:SetEndSize(s)
    p:SetColor(c.r, c.g, c.b)
    p:SetLighting(false)
    p:SetCollide(false)
    local phase, rythme = math.Rand(0, 6.28), math.Rand(2.5, 5)
    p:SetThinkFunction(function(pp)
        local u = pp:GetLifeTime() / math.max(0.1, pp:GetDieTime())
        local al = 255 * math.sin(math.min(1, u) * math.pi) * (0.35 + 0.65 * math.max(0, math.sin(RealTime() * rythme + phase)))
        pp:SetStartAlpha(al) pp:SetEndAlpha(al)
        pp:SetNextThink(CurTime() + 0.04)
    end)
    p:SetNextThink(CurTime() + 0.04)
end

local _dernier, _resteP, _resteL = 0, 0, 0
hook.Add("Think", "EVO_Ciel::Meteo", function()
    local t = EVO_CIEL.Vue()
    local P = t and t.precip
    local L = t and t.lucioles
    if not CV_PRECIP:GetBool() then P = nil end
    if not CV_LUCIOLES:GetBool() then L = nil end
    if not P and not L then
        if _em then Ranger() end
        _dernier = 0
        return
    end
    local now = RealTime()
    local dt = (_dernier > 0) and math.min(now - _dernier, 0.25) or 0
    _dernier = now
    if dt <= 0 then return end
    local f = EVO_CIEL.Facteur(t)
    if f <= 0.02 then return end
    local em = Emetteur()
    if not em then return end
    local vOeil = EyePos()

    if P then
        _resteP = _resteP + dt * (P.taux or 300) * f
        local n = math.floor(_resteP)
        _resteP = _resteP - n
        -- Plafond par image : un dt de 0,25 s a 340/s ferait 85 naissances d'un coup.
        for _ = 1, math.min(n, 40) do Naissance(em, P, vOeil) end
    end
    if L then
        _resteL = _resteL + dt * (L.taux or 5) * f
        local n = math.floor(_resteL)
        _resteL = _resteL - n
        for _ = 1, math.min(n, 3) do Luciole(em, L, vOeil) end
    end
end)

-- ── Les sons qui tombent au hasard ──────────────────────────────────────────
-- `sonsAlea` : des sons courts joues autour du joueur a intervalle tire au sort
-- (gouttes d'une pluie, oiseaux du matin, coup de vent...). Un seul a la fois par
-- ambiance, position a quelques metres dans une direction au hasard : ca vient
-- de quelque part, pas de la tete. Le volume suit la montee de l'ambiance.
local _prochainAlea = 0
hook.Add("Think", "EVO_Ciel::SonsAlea", function()
    local t = EVO_CIEL.Vue()
    local A = t and t.sonsAlea
    if not A then _prochainAlea = 0 return end
    local now = RealTime()
    if now < _prochainAlea then return end
    local iv = A.intervalle or { 2, 6 }
    _prochainAlea = now + math.Rand(iv[1] or 2, iv[2] or 6)
    local f = EVO_CIEL.Facteur(t)
    if f <= 0.05 then return end
    local sons = A.sons or {}
    if #sons == 0 then return end
    local ang = math.Rand(0, math.pi * 2)
    local d = math.Rand(A.distance and A.distance[1] or 150, A.distance and A.distance[2] or 600)
    local pos = EyePos() + Vector(math.cos(ang) * d, math.sin(ang) * d, math.Rand(-30, 120))
    sound.Play(sons[math.random(#sons)], pos, A.niveau or 70, math.random(A.ton and A.ton[1] or 92, A.ton and A.ton[2] or 108),
        math.Clamp((A.volume or 0.5) * f, 0, 1))
end)

-- ── La foudre ───────────────────────────────────────────────────────────────
-- Le TIMING est celui du flash de cl_ciel (t.eclairs) : meme periode, meme
-- chance, meme instant. Ce module ne decide rien, il donne un corps.
local MAT_ECLAIR = CreateMaterial("evo_ciel_eclair", "UnlitGeneric", {
    ["$basetexture"] = "sprites/lgtning",
    ["$additive"] = "1",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
    ["$nofog"] = "1",
    ["$nocull"] = "1",
})
local MAT_HALO = Material("sprites/light_glow02_add")
local DIST = 12000
local _ang = Angle(0, 0, 0)

-- L'eclair de la periode n : sa direction, son instant et son alpha a cet
-- instant. nil si rien ne tombe. Copie de la loi de cl_ciel, pour tomber au
-- meme moment que le flash.
local function EclairEnCours(E, tps)
    local P = E.periode or 7
    local n = math.floor(tps / P)
    if AleaDe(n) > (E.chance or 0.5) then return nil end
    local t0 = n * P + AleaDe(n + 0.5) * (P * 0.8)
    local dt = tps - t0
    local d = E.duree or 0.15
    if dt < 0 or dt > d * 1.6 then return nil end
    local u = dt / d
    local a = math.max(1 - u * 3, (u > 0.35 and u < 0.6) and (0.5 - math.abs(u - 0.47) * 4) or 0)
    -- Une traine plus lente que le flash : le trait reste grave un peu apres.
    local traine = math.max(0, 1 - u / 1.6) * 0.35
    return n, math.max(a, traine), dt
end

-- Les points du trait de la periode n, du sommet (haut dans le ciel) a
-- l'horizon, brises par le hachage. Calcules une fois par eclair.
local _cache = { n = nil, pts = nil, branches = nil, yaw = 0 }
local function Trait(n, oeil)
    if _cache.n == n and _cache.oeil == oeil then return _cache end
    local yaw = AleaDe(n + 0.7) * 360
    local pHaut = 32 + AleaDe(n + 0.9) * 30
    local K = 14
    local pts = {}
    for k = 0, K do
        local u = k / K
        local dev = math.sin(u * math.pi)
        _ang.p = -(Lerp(u, pHaut, 1.5) + (AleaDe(n * 7 + k) - 0.5) * 4)
        _ang.y = yaw + (AleaDe(n * 11 + k) - 0.5) * 16 * dev
        _ang.r = 0
        pts[k + 1] = oeil + _ang:Forward() * DIST
    end
    -- Deux ou trois branches courtes, nees au tiers et a la moitie du trait.
    local branches = {}
    for b = 1, 3 do
        local depart = 3 + math.floor(AleaDe(n * 13 + b) * 6)
        local br = { pts[depart] }
        local y0 = yaw + (AleaDe(n * 17 + b) - 0.5) * 30
        local p0 = pHaut * (1 - (depart - 1) / K)
        for k = 1, 5 do
            _ang.p = -(p0 - k * (2.5 + AleaDe(n * 19 + b * 5 + k) * 2))
            _ang.y = y0 + (AleaDe(n * 23 + b * 7 + k) - 0.5) * 8
            _ang.r = 0
            br[k + 1] = oeil + _ang:Forward() * DIST
        end
        branches[b] = br
    end
    _cache.n, _cache.oeil, _cache.pts, _cache.branches, _cache.yaw = n, oeil, pts, branches, yaw
    return _cache
end

hook.Add("PostDrawSkyBox", "EVO_Ciel::Foudre", function()
    if not CV_FOUDRE:GetBool() then return end
    local t = EVO_CIEL.Vue()
    local E, F = t and t.eclairs, t and t.foudre
    if not E or not F then return end
    local n, a = EclairEnCours(E, CurTime())
    if not n or a <= 0 then return end
    local oeil = EyePos()
    local T = Trait(n, oeil)
    local c = F.couleur or Color(214, 226, 255)
    local col = Color(c.r, c.g, c.b, 255 * a)
    local largeur = F.largeur or 95
    render.OverrideDepthEnable(true, false)
    render.SetMaterial(MAT_ECLAIR:IsError() and MAT_HALO or MAT_ECLAIR)
    local pts = T.pts
    for k = 1, #pts - 1 do
        render.DrawBeam(pts[k], pts[k + 1], largeur * (1 - (k / #pts) * 0.55), 0, 1, col)
    end
    for b = 1, math.min(F.branches or 3, #T.branches) do
        local br = T.branches[b]
        for k = 1, #br - 1 do
            render.DrawBeam(br[k], br[k + 1], largeur * 0.45 * (1 - k / #br * 0.6), 0, 1, col)
        end
    end
    -- Le halo au sommet : la ou le ciel se dechire.
    render.SetMaterial(MAT_HALO)
    render.DrawSprite(pts[1], 2600, 2600, Color(c.r, c.g, c.b, 200 * a))
    render.OverrideDepthEnable(false, false)
end)

-- La lumiere, le tonnerre et la secousse : dans Think, pas dans le dessin (une
-- interface qui cache le rendu ne doit pas etouffer le tonnerre).
local _dernierN = nil
hook.Add("Think", "EVO_Ciel::Tonnerre", function()
    if not CV_FOUDRE:GetBool() then return end
    local t = EVO_CIEL.Vue()
    local E, F = t and t.eclairs, t and t.foudre
    if not E or not F then _dernierN = nil return end
    local n, a = EclairEnCours(E, CurTime())
    if not n then return end
    local yaw = AleaDe(n + 0.7) * 360

    -- Une lumiere dynamique du cote du coup, le temps du flash.
    if F.lumiere ~= false and a > 0.05 then
        local dl = DynamicLight(30011)
        if dl then
            _ang.p, _ang.y, _ang.r = -35, yaw, 0
            dl.pos = EyePos() + _ang:Forward() * 700
            local c = F.couleur or Color(214, 226, 255)
            dl.r, dl.g, dl.b = c.r, c.g, c.b
            dl.brightness = 3.5 * a
            dl.size = 3200
            dl.decay = 3200 * 6
            dl.dietime = CurTime() + 0.08
        end
    end

    -- Le tonnerre, une fois par eclair, tire du meme numero : le delai dit la
    -- distance. Proche (moins d'une seconde) : fort, grave, et le sol tremble.
    if _dernierN ~= n then
        _dernierN = n
        local T = F.tonnerre or {}
        local delai = (T.min or 0.6) + AleaDe(n + 0.33) * ((T.max or 3.2) - (T.min or 0.6))
        local proche = delai < 1.2
        local son = "ambient/outro/thunder0" .. (1 + math.floor(AleaDe(n + 0.44) * 7)) .. ".wav"
        _ang.p, _ang.y, _ang.r = 0, yaw, 0
        local pos = EyePos() + _ang:Forward() * (proche and 700 or 2200)
        timer.Simple(delai, function()
            sound.Play(son, pos, proche and 100 or 85, proche and math.random(80, 92) or math.random(90, 108),
                (T.volume or 0.95) * (proche and 1 or 0.7))
            if proche and F.secousse ~= false then
                util.ScreenShake(EyePos(), 5, 5, 0.9, 1200)
            end
        end)
    end
end)
