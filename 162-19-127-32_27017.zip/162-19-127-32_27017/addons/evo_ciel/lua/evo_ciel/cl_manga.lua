-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_manga.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO MANGA - la passe plein ecran qui pose le trait d'encre et les aplats.
--
-- ELLE NE FAIT RIEN TANT QUE LE .vcs N'EST PAS COMPILE, et c'est voulu : le
-- shader est du CONTENU, il se livre par le Workshop. Un joueur qui ne l'a pas
-- encore recu doit voir le serveur normalement, pas un ecran rose de materiau
-- manquant. On teste le materiau UNE fois et on se tait ensuite.
--
-- Compilation du .vcs : voir shaders/README.md
-- ============================================================================

-- Le fichier COMPILE, pas le materiau. C'est le point important : un VMT dont
-- le $pixshader n'existe pas n'est PAS un materiau en erreur pour GMod. Le VMT
-- se charge, IsError renvoie faux, on croit le shader disponible, et on dessine
-- un quad plein ecran avec un shader introuvable : ecran noir.
--
-- C'est exactement ce qui est arrive le 23/08. Un seul poste avait le .vmt sans
-- le .vcs : lui voyait tout noir, les autres joueurs non. Une panne qui ne
-- frappe qu'une machine sur le meme serveur designe toujours un fichier local,
-- jamais le code.
--
-- On teste donc l'existence du .vcs lui-meme, une fois, au premier besoin.
local VCS = "shaders/fxc/evo_manga_ps20b.vcs"

local MAT = nil
local _dispo = nil

-- Expose a cl_ciel : c'est ce qui permet au trait natif de prendre le relais
-- quand le shader maison n'est pas installe, sans que les deux se superposent.
-- Elle RESOUT l'etat au lieu de le lire : appelee avant que le hook ci-dessous
-- n'ait tourne, une simple lecture aurait renvoye faux a la premiere frame et
-- on aurait dessine les deux traits l'un sur l'autre.
function EVO_CIEL.MangaDispo()
    if _dispo ~= nil then return _dispo end
    if not file.Exists(VCS, "GAME") then
        _dispo = false
        MsgN("[evo_ciel] " .. VCS .. " absent : trait d'encre natif.")
        return false
    end
    MAT = Material("evo_ciel/manga")
    _dispo = not MAT:IsError()
    if not _dispo then
        MsgN("[evo_ciel] materials/evo_ciel/manga.vmt absent : trait d'encre natif.")
    end
    return _dispo
end
local Disponible = EVO_CIEL.MangaDispo

hook.Add("RenderScreenspaceEffects", "EVO_Ciel::Manga", function()
    local t = EVO_CIEL.Vue and EVO_CIEL.Vue()
    local m = t and t.manga
    if not m then return end
    if not Disponible() then return end

    -- L'image en cours est copiee dans une texture, sinon le shader lirait la
    -- cible sur laquelle il ecrit.
    render.UpdateScreenEffectTexture()
    -- La profondeur n'est PAS resolue en permanence : sans cet appel, le tampon
    -- est celui de la frame precedente, ou vide, et le trait bave d'une image
    -- sur l'autre.
    render.UpdateFullScreenDepthTexture()

    MAT:SetTexture("$basetexture", render.GetScreenEffectTexture())
    MAT:SetTexture("$texture1", render.GetResolvedFullFrameDepth())

    MAT:SetFloat("$c0_x", m.seuil or 0.02)
    MAT:SetFloat("$c0_y", m.force or 26)
    MAT:SetFloat("$c0_z", m.paliers or 4)
    MAT:SetFloat("$c0_w", m.saturation or 0.85)
    -- La taille du texel vient d'ici : codee en dur elle serait fausse des que
    -- le joueur change de resolution, et le trait deviendrait deux fois trop
    -- epais ou invisible.
    MAT:SetFloat("$c1_x", 1 / ScrW())
    MAT:SetFloat("$c1_y", 1 / ScrH())

    render.SetMaterial(MAT)
    render.DrawScreenQuad()
end)
