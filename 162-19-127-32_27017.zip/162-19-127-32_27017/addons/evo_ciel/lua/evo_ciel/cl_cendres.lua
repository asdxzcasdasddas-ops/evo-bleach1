-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_cendres.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - les cendres. Des flocons gris qui tombent en derivant dans le
-- vent, et quelques braises qui montent. Pour l'ambiance « Ciel en flammes ».
--
-- DANS LE MONDE, PAS SUR L'ECRAN. La pluie d'avant etait dessinee en
-- surimpression et personne d'autre ne la voyait ; ici les cendres sont des
-- particules 3D (ParticleEmitter) posees autour de la camera de CHAQUE client,
-- donc chacun voit le ciel tomber autour de lui et autour des autres.
--
-- LE BUDGET : `taux` flocons par seconde, qui vivent sept a douze secondes,
-- soit deux a trois cents sprites vivants ; et trois braises par seconde. Un
-- seul emetteur, aucune collision (une cendre qui traverse un toit ne se voit
-- pas, une collision par particule se paierait), aucun eclairage.
--
-- PAS DE CENDRE SOUS UN TOIT : un trace vers le haut depuis le point de
-- naissance, seuls les points qui voient le ciel donnent un flocon. C'est ce
-- qui fait qu'un interieur reste un interieur.
--
-- MATERIAUX DU JEU DE BASE, rien a telecharger : le sprite de fumee de la
-- documentation de ParticleEmitter pour les flocons (translucide, donc il peut
-- etre gris), et le halo additif deja utilise ailleurs sur le serveur pour les
-- braises (additif, donc il ne sait que briller).
-- ============================================================================

local CV_CENDRES = CreateClientConVar("evo_ciel_couche_cendres", "1", true, false,
    "Cendres et braises de l'ambiance Ciel en flammes")

local MAT_FLOCON = "particle/smokesprites_0001"
local MAT_BRAISE = "sprites/light_glow02_add"

local _emetteur = nil
local _reste = 0        -- flocons dus mais pas encore nes (fraction de dt * taux)
local _resteBraises = 0

local function Emetteur()
    if _emetteur and _emetteur:IsValid() then return _emetteur end
    _emetteur = ParticleEmitter(EyePos(), false)
    if _emetteur then
        _emetteur:SetNearClip(12, 40)
    end
    return _emetteur
end

local function Ranger()
    if _emetteur and _emetteur:IsValid() then _emetteur:Finish() end
    _emetteur = nil
    _reste, _resteBraises = 0, 0
end

-- Le point voit-il le ciel ? Un toit, une voute, un pont : pas de cendre.
local _tr = { mask = MASK_SOLID_BRUSHONLY }
local function VoitLeCiel(vPos)
    _tr.start = vPos
    _tr.endpos = vPos + Vector(0, 0, 9000)
    local tr = util.TraceLine(_tr)
    return (not tr.Hit) or tr.HitSky
end

local function Flocon(em, C, vOeil)
    local a = math.Rand(0, math.pi * 2)
    local r = math.Rand(60, C.rayon or 700)
    local vPos = vOeil + Vector(math.cos(a) * r, math.sin(a) * r, math.Rand(-120, C.hauteur or 420))
    if not VoitLeCiel(vPos) then return end

    local p = em:Add(MAT_FLOCON, vPos)
    if not p then return end
    local vVent = C.vent or Vector(24, 10, 0)
    p:SetVelocity(vVent + VectorRand() * 14 + Vector(0, 0, -6))
    p:SetGravity(Vector(0, 0, -(C.chute or 16)))
    p:SetAirResistance(9)
    p:SetDieTime(math.Rand(6, 10))
    p:SetStartAlpha(math.Rand(130, 210))
    p:SetEndAlpha(0)
    local s = math.Rand(2.5, 5.5)
    p:SetStartSize(s)
    p:SetEndSize(s * 0.4)
    p:SetRoll(math.Rand(0, 360))
    p:SetRollDelta(math.Rand(-1.5, 1.5))
    -- Gris cendre, un peu variable : la teinte du monde les rechauffe ensuite.
    local g = math.Rand(-25, 25)
    p:SetColor(158 + g, 150 + g, 142 + g)
    p:SetLighting(false)
    p:SetCollide(false)
end

local function Braise(em, C, vOeil)
    local a = math.Rand(0, math.pi * 2)
    local r = math.Rand(80, (C.rayon or 700) * 0.8)
    local vPos = vOeil + Vector(math.cos(a) * r, math.sin(a) * r, math.Rand(-160, 40))
    if not VoitLeCiel(vPos) then return end

    local p = em:Add(MAT_BRAISE, vPos)
    if not p then return end
    local vVent = C.vent or Vector(24, 10, 0)
    p:SetVelocity(vVent * 1.4 + VectorRand() * 18 + Vector(0, 0, math.Rand(22, 48)))
    -- Elle MONTE : la chaleur la porte, puis elle s'eteint en l'air.
    p:SetGravity(Vector(0, 0, math.Rand(4, 12)))
    p:SetAirResistance(6)
    p:SetDieTime(math.Rand(3, 6))
    p:SetStartAlpha(255)
    p:SetEndAlpha(0)
    p:SetStartSize(math.Rand(1.8, 3.4))
    p:SetEndSize(0.4)
    p:SetColor(255, math.Rand(120, 165), math.Rand(20, 50))
    p:SetLighting(false)
    p:SetCollide(false)
end

-- Dans Think, pas dans un hook de dessin : le nombre de naissances depend du
-- temps ecoule, pas du nombre d'images. Une petite config a moins d'images,
-- elle doit avoir autant de cendres.
local _dernier = 0
hook.Add("Think", "EVO_Ciel::Cendres", function()
    local t = EVO_CIEL.Vue()
    local C = t and t.cendres
    if not C or not CV_CENDRES:GetBool() then
        if _emetteur then Ranger() end
        _dernier = 0
        return
    end

    local now = RealTime()
    local dt = (_dernier > 0) and math.min(now - _dernier, 0.25) or 0
    _dernier = now
    if dt <= 0 then return end

    -- L'ambiance monte progressivement : les cendres viennent avec elle.
    local f = EVO_CIEL.Facteur(t)
    if f <= 0.02 then return end

    local em = Emetteur()
    if not em then return end
    local vOeil = EyePos()

    _reste = _reste + dt * (C.taux or 26) * f
    local n = math.floor(_reste)
    _reste = _reste - n
    for _ = 1, math.min(n, 12) do Flocon(em, C, vOeil) end

    _resteBraises = _resteBraises + dt * (C.braises or 3) * f
    local nb = math.floor(_resteBraises)
    _resteBraises = _resteBraises - nb
    for _ = 1, math.min(nb, 3) do Braise(em, C, vOeil) end
end)
