-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_ciel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - client. Aucune texture, aucun shader ajoute, aucun telechargement.
--
-- LE BUDGET :
--   teinte du ciel : UN quad plein ecran en fusion multiplicative ;
--   brouillard     : deux hooks qui posent des valeurs, cout nul ;
--   monde          : UN quad plein ecran, en multiplicatif ;
--   clignement     : deux rectangles, et seulement pendant la transition.
-- Volontairement PAS de DrawBloom ni de DrawSunbeams : passes multiples, c'est
-- ce qui fait chuter les FPS des petites configs.
--
-- AUCUNE LUNE DESSINEE : la map en a une, en croissant, meilleure que tout ce
-- qu'on tracerait par dessus. On teinte la sienne.
--
-- PLUS DE PLUIE : elle etait dessinee en surimpression a l'ecran, donc visible
-- par un seul joueur et par aucun autre. Un effet que le voisin ne voit pas ne
-- raconte rien en RP, et celui-la n'etait meme pas beau (constat user 08/23).
-- Retiree entierement plutot que retouchee.
-- ============================================================================

-- L'ambiance REELLEMENT AFFICHEE, qui n'est pas celle du reseau.
--
-- Le serveur annonce le changement, mais le client ne l'applique qu'une fois
-- les paupieres fermees. Sans ce decalage le monde basculait AVANT le clin
-- d'oeil, qui arrivait ensuite comme un cheveu sur la soupe (constat user
-- 08/23) : on voyait le changement, puis on fermait les yeux dessus.
--
-- Tout le rendu client passe par ici, y compris cl_encre et cl_manga.
local _vue = ""
function EVO_CIEL.Vue()
    return EVO_CIEL.Ambiance(_vue)
end

local function Ambiance()
    return EVO_CIEL.Vue()
end

-- INTERRUPTEURS DE MESURE. Chaque couche s'eteint separement, en jeu, sans
-- redemarrer ni recharger quoi que ce soit.
--
-- POURQUOI ILS EXISTENT : une chute de 20 FPS a ete signalee sur la nuit, alors
-- que l'audit du code ne donne que deux rectangles plein ecran par image. Plutot
-- que de deviner et de corriger au hasard -- ce qui a deja fait perdre un tour
-- -- on isole. On coupe une couche a la fois avec l'ambiance active, et celle
-- qui rend les FPS est la coupable. Une mesure vaut mieux que trois hypotheses.
--
-- Ils restent apres le diagnostic : le jour ou un joueur se plaint, il n'y a
-- rien a redeployer pour savoir d'ou ca vient.
local CV_CIEL   = CreateClientConVar("evo_ciel_couche_ciel", "1", true, false,
    "Teinte du ciel (quad multiplicatif dans PostDrawSkyBox)")
local CV_MONDE  = CreateClientConVar("evo_ciel_couche_monde", "1", true, false,
    "Teinte du monde (quad multiplicatif dans RenderScreenspaceEffects)")
local CV_SOLEIL = CreateClientConVar("evo_ciel_couche_soleil", "1", true, false,
    "Retrait de l'env_sun de la map")
local CV_FAILLE = CreateClientConVar("evo_ciel_couche_faille", "1", true, false,
    "Dessin de la Garganta")

-- LE QUAD DE TEINTE, SANS CHANGEMENT DE PROJECTION.
--
-- La version precedente faisait `cam.Start2D()` + surface.DrawRect + End2D, deux
-- fois par image. Ce n'est pas le remplissage qui coute -- deux quads plein
-- ecran, c'est des microsecondes -- c'est la BASCULE DE PROJECTION au milieu du
-- rendu de la scene. Source empile ses commandes et, en rendu multicoeur, le
-- thread de rendu travaille en retard sur le principal ; passer en 2D force un
-- VIDAGE de la file et une synchronisation des deux threads. Ca ne se compte pas
-- en pixels mais en millisecondes, et le user a signale 20 FPS de moins.
--
-- render.DrawScreenQuad dessine le meme plein ecran dans le contexte 3D deja en
-- place : aucune bascule, aucun vidage. La couleur passe par $color du materiau
-- au lieu de surface.SetDrawColor, et le Vector est reutilise pour ne rien
-- allouer par image.
local MAT_TEINTE = CreateMaterial("evo_ciel_teinte", "UnlitGeneric", {
    ["$basetexture"] = "vgui/white",
    ["$ignorez"] = "1",
    ["$translucent"] = "1",
})
local _vTeinte = Vector(1, 1, 1)

local function Teinter(r, g, b)
    -- Repli si le materiau blanc manque : mieux vaut la version lente que le
    -- damier rose d'un materiau en erreur sur tout l'ecran.
    if MAT_TEINTE:IsError() then
        cam.Start2D()
            render.OverrideBlend(true, BLEND_DST_COLOR, BLEND_ZERO, BLENDFUNC_ADD)
            surface.SetDrawColor(r * 255, g * 255, b * 255, 255)
            surface.DrawRect(0, 0, ScrW(), ScrH())
            render.OverrideBlend(false)
        cam.End2D()
        return
    end
    _vTeinte.x, _vTeinte.y, _vTeinte.z = r, g, b
    MAT_TEINTE:SetVector("$color", _vTeinte)
    render.OverrideBlend(true, BLEND_DST_COLOR, BLEND_ZERO, BLENDFUNC_ADD)
        render.SetMaterial(MAT_TEINTE)
        render.DrawScreenQuad()
    render.OverrideBlend(false)
end

-- LA LUEUR D'UN FEU : une pulsation lente et irreguliere de la teinte, trois
-- sinus a des frequences sans rapport entre elles, donc jamais periodique a
-- l'oeil. Une multiplication ne sait qu'assombrir : la valeur de la config est
-- le point HAUT, la lueur descend en dessous et remonte. Cout : trois sinus.
-- `nPart` module la profondeur (le ciel respire moins que le sol).
function EVO_CIEL.Lueur(t, nPart)
    local L = t and t.lueur
    if not L then return 1 end
    local s = CurTime() * (L.vitesse or 1.5)
    local n = math.sin(s * 1.7) * 0.5 + math.sin(s * 2.9 + 1.3) * 0.3 + math.sin(s * 6.1 + 0.7) * 0.2
    return 1 - (L.amplitude or 0.08) * (nPart or 1) * (0.5 + 0.5 * n)
end

function EVO_CIEL.Couche(sNom)
    if sNom == "ciel" then return CV_CIEL:GetBool() end
    if sNom == "cendres" then
        local c = GetConVar("evo_ciel_couche_cendres")
        return (not c) or c:GetBool()
    end
    if sNom == "monde" then return CV_MONDE:GetBool() end
    if sNom == "soleil" then return CV_SOLEIL:GetBool() end
    if sNom == "faille" then return CV_FAILLE:GetBool() end
    return true
end

-- LA TEINTE DU CIEL ---------------------------------------------------------
-- Pose APRES le ciel et AVANT le monde, en fusion multiplicative. Multiplier
-- plutot que recouvrir, c'est ce qui garde le dessin : le croissant reste un
-- croissant, les nuages restent des nuages.
--
-- Cette voie a ete choisie apres l'echec de `$color` sur les materiaux de
-- skybox : la map charge des variantes HDR sous un autre nom, donc la teinte ne
-- prenait sur rien. Ici on ne depend d'aucun nom de materiau.
hook.Add("PostDrawSkyBox", "EVO_Ciel::TeinteCiel", function()
    if not CV_CIEL:GetBool() then return end
    local t = Ambiance()
    local c = t and t.skyTeinte
    if not c then return end
    -- Depuis le BLANC : multiplier par blanc rend l'image inchangee au pixel
    -- pres, c'est donc le point de depart exact d'une ambiance qui s'installe.
    -- Aucun seuil ici, contrairement a l'ancienne passe DrawColorModify : celle
    -- de la multiplication est neutre par construction.
    local f = EVO_CIEL.Facteur(t)
    if f <= 0 then return end
    local l = EVO_CIEL.Lueur(t, 0.6)
    Teinter(Lerp(f, 1, c.r / 255 * l), Lerp(f, 1, c.g / 255 * l), Lerp(f, 1, c.b / 255 * l))
end)

-- LE MONDE ------------------------------------------------------------------
-- L'ORDRE COMPTE : on aplatit les couleurs d'abord, on trace ensuite. Un
-- contour calcule avant l'aplatissement suit les nuances de la texture et
-- ressort sale ; calcule apres, il ne reste que les vraies ruptures.
local _hachures = {}
hook.Add("RenderScreenspaceEffects", "EVO_Ciel::Monde", function()
    local t = Ambiance()
    if not t then return end

    -- LA TEINTE DU MONDE, par MULTIPLICATION et non par DrawColorModify.
    --
    -- DrawColorModify N'EST PAS NEUTRE A L'IDENTITE. Meme avec des
    -- multiplicateurs a 1, une luminosite a 0 et un contraste a 1, la passe
    -- repasse le tampon par son shader et applique une conversion de gamme :
    -- sur une map HDR comme le Seireitei, ca sature violemment. Le user l'a vu
    -- a la seconde pres -- l'image basculait a deux minutes, soit exactement le
    -- seuil de 2 % de la tombee de nuit, avec des arbres vert fluo et des toits
    -- orange. Ce n'etait pas mon reglage, c'etait la passe elle-meme.
    --
    -- Un quad multiplicatif, lui, est neutre PAR CONSTRUCTION : multiplier par
    -- blanc rend l'image inchangee, au pixel pres. Il n'y a donc plus de seuil,
    -- plus de saut, et le fondu peut vraiment partir de zero. Il coute aussi
    -- moins cher qu'une passe de shader.
    --
    -- Ce qu'on y perd : contraste et saturation, qu'une multiplication ne sait
    -- pas faire. Assume -- a 0.118 de luminosite il ne reste presque rien a
    -- desaturer, et une image juste est preferable a une image reglee.
    local m = t.monde
    local f = EVO_CIEL.Facteur(t)
    if m and f > 0 and CV_MONDE:GetBool() then
        local l = EVO_CIEL.Lueur(t, 1)
        Teinter(Lerp(f, 1, math.min(m.mulr or 1, 1) * l),
                Lerp(f, 1, math.min(m.mulg or 1, 1) * l),
                Lerp(f, 1, math.min(m.mulb or 1, 1) * l))
    end

    -- LE TRAIT. PAS DrawSobel directement : il remplace l'image par sa
    -- detection et donne un ecran noir. EVO_CIEL.DessinerEncre passe par une
    -- cible hors ecran et SOUSTRAIT le resultat, ce qui laisse la scene et n'en
    -- garde que les traits. Il cede la place au shader maison quand celui-ci
    -- est installe : les deux ensemble donneraient un double trait.
    local e = t.encre
    if e and not (EVO_CIEL.MangaDispo and EVO_CIEL.MangaDispo()) then
        EVO_CIEL.DessinerEncre(e.seuil, e.force)
    end

    -- LES HACHURES, en dernier : la trame se pose SUR le dessin fini, comme une
    -- planche encree qu'on trame a la fin.
    local h = t.hachures
    if h then
        local mat = _hachures[h.motif]
        if mat == nil then
            mat = Material(h.motif)
            if mat:IsError() then mat = false end
            _hachures[h.motif] = mat
        end
        if mat then DrawTexturize(h.echelle or 2, mat) end
    end
end)

-- LE CLIGNEMENT -------------------------------------------------------------
-- Le monde ne bascule pas d'un coup : on ferme les paupieres, on change, on
-- rouvre. Sans cette coupure la teinte apparaissait en un claquement de doigt,
-- et ca se lisait comme un bug d'affichage plutot que comme un evenement.
--
-- Deux rectangles, et uniquement pendant les huit dixiemes de seconde de la
-- transition. Le reste du temps ce hook coute une comparaison de chaine.
local CLIGNE_FERME = 0.26   -- fermeture
local CLIGNE_TENU  = 0.10   -- noir complet, le temps que le monde ait change
local CLIGNE_OUVRE = 0.42   -- reouverture, plus lente : c'est la qu'on decouvre
local CLIGNE_TOTAL = CLIGNE_FERME + CLIGNE_TENU + CLIGNE_OUVRE

local _amorce = false  -- a-t-on deja vu passer une premiere valeur ?
local _debut = 0       -- instant de depart du clin, 0 = pas de clin en cours
local _ferme = 0       -- part de paupiere fermee, 0 a 1

-- La machine a etats tourne dans Think et PAS dans le hook de dessin : HUD
-- masque, menu ouvert, le changement d'ambiance doit quand meme aboutir. Sinon
-- un joueur restait bloque sur l'ancien monde pour avoir cache son interface.
hook.Add("Think", "EVO_Ciel::ClinEtat", function()
    local sNom = EVO_CIEL.EnCours()

    -- Premiere valeur : on l'applique SANS cligner. Un joueur qui se connecte
    -- pendant un evenement ne doit pas se prendre un clin d'oeil sans raison.
    if not _amorce then
        _amorce = true
        _vue = sNom
        return
    end

    -- Cinematique en cours : c'est ELLE qui decide quand le monde change, et
    -- elle dessine ses propres paupieres. Deux jeux superposes donneraient un
    -- ecran noir permanent.
    if EVO_CIEL.CineBloque and EVO_CIEL.CineBloque() then
        _ferme = 0
        return
    end

    if sNom ~= _vue and _debut == 0 then _debut = RealTime() end
    if _debut == 0 then _ferme = 0 return end

    local dt = RealTime() - _debut
    if dt >= CLIGNE_TOTAL then
        _debut, _ferme = 0, 0
        _vue = sNom
        return
    end

    if dt < CLIGNE_FERME then
        local f = dt / CLIGNE_FERME
        _ferme = f * f                              -- accelere : l'oeil claque
    elseif dt < CLIGNE_FERME + CLIGNE_TENU then
        _ferme = 1
        -- LE MONDE CHANGE ICI, paupieres closes. C'est tout l'interet.
        if _vue ~= sNom then
            _vue = sNom
            -- Le soleil suit dans la meme frame : attendre le tour du timer le
            -- laisserait allume trois secondes apres la reouverture des yeux.
            if EVO_CIEL.MajSoleil then EVO_CIEL.MajSoleil() end
        end
    else
        local f = 1 - (dt - CLIGNE_FERME - CLIGNE_TENU) / CLIGNE_OUVRE
        _ferme = f * f * (3 - 2 * f)                -- adouci : l'oeil s'ouvre
    end
end)

-- LES ECLAIRS ---------------------------------------------------------------
-- TIRES DU TEMPS, jamais du hasard local. Chaque client calcule le meme eclair
-- au meme instant a partir du numero de la periode en cours : tout le serveur
-- voit donc la meme chose. Un eclair que le voisin ne voit pas ne raconte rien
-- en RP -- c'est l'erreur exacte qu'avait la pluie, et elle a coute son
-- retrait.
--
-- Cout : un quad plein ecran, et seulement pendant les quelques centiemes de
-- seconde de l'eclair. Le reste du temps, deux multiplications.
local function AleaDe(n)
    local x = math.sin(n * 12.9898) * 43758.5453
    return x - math.floor(x)
end

hook.Add("HUDPaintBackground", "EVO_Ciel::Eclairs", function()
    local t = Ambiance()
    local E = t and t.eclairs
    if not E then return end

    local P = E.periode or 7
    local n = math.floor(CurTime() / P)
    if AleaDe(n) > (E.chance or 0.5) then return end

    -- L'instant de l'eclair DANS la periode, tire du meme numero : sans ce
    -- decalage tous les eclairs tomberaient pile sur le multiple de P et le
    -- rythme serait metronomique.
    local t0 = n * P + AleaDe(n + 0.5) * (P * 0.8)
    local dt = CurTime() - t0
    local d = E.duree or 0.15
    if dt < 0 or dt > d then return end

    -- Deux pics rapproches : un eclair unique fait flash d'appareil photo, deux
    -- font un vrai coup de foudre.
    local u = dt / d
    local a = math.max(1 - u * 3, (u > 0.35 and u < 0.6) and (0.5 - math.abs(u - 0.47) * 4) or 0)
    if a <= 0 then return end

    local c = E.couleur or color_white
    surface.SetDrawColor(c.r, c.g, c.b, a * (E.force or 110))
    surface.DrawRect(0, 0, ScrW(), ScrH())
end)

-- Appelee par la cinematique au moment PRECIS ou ses paupieres sont closes sur
-- le troisieme clin. Sans elle, le relais repassait par le clin ordinaire :
-- celui-ci redemarrait son propre cycle, la faille n'arrivait qu'un quart de
-- seconde plus tard, et le joueur voyait un quatrieme battement de paupieres
-- sorti de nulle part.
function EVO_CIEL.ForcerVue()
    _vue = EVO_CIEL.EnCours()
    _amorce = true
    _debut, _ferme = 0, 0
end

hook.Add("HUDPaintBackground", "EVO_Ciel::Clignement", function()
    if _ferme <= 0 then return end
    local w, h = ScrW(), ScrH()
    local n = math.ceil(h * 0.5 * _ferme)
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawRect(0, 0, w, n)
    surface.DrawRect(0, h - n, w, n)
end)

-- LE SOLEIL -----------------------------------------------------------------
-- On le SUPPRIME cote client. Deux tentatives plus faibles ont echoue avant :
--
--   1. l'assombrir avec le reste. Le halo d'un env_sun est dessine APRES la
--      teinte du ciel et il est si lumineux qu'a 0.118 il ressort encore blanc ;
--   2. SetNoDraw. Sans effet non plus : dans Source le halo du soleil passe par
--      un rendu d'overlay separe qui ne consulte pas le drapeau de dessin de
--      l'entite. Deux captures du user, une nuit reussie avec un soleil en
--      plein milieu a chaque fois.
--
-- Retirer l'entite chez le client est donc la seule voie qui marche. Elle n'est
-- PAS destructrice : env_sun est une entite reseau, un cl_fullupdate la
-- recree. C'est ce qui permet de la rendre au retour du jour, sans quoi un
-- cycle jour/nuit aurait supprime le soleil une fois pour toutes.
local _retire = false

function EVO_CIEL.MajSoleil()
    local t = Ambiance()
    -- `soleil` absent = on ne touche a rien. Une ambiance qui ne se prononce pas
    -- ne doit pas eteindre le soleil d'une autre.
    local bCacher = (t and t.soleil == false) or false
    if not CV_SOLEIL:GetBool() then bCacher = false end

    if bCacher then
        for _, e in ipairs(ents.FindByClass("env_sun")) do
            if IsValid(e) then e:Remove() end
        end
        _retire = true
        return
    end

    -- Retour du jour : on redemande l'etat complet au serveur, UNE fois. Sans le
    -- drapeau, l'appel partirait a chaque tour du timer et hacherait la partie.
    if _retire then
        _retire = false
        RunConsoleCommand("cl_fullupdate")
    end
end

timer.Create("EVO_Ciel::Soleil", 3, 0, EVO_CIEL.MajSoleil)
hook.Add("InitPostEntity", "EVO_Ciel::Soleil", function() timer.Simple(2, EVO_CIEL.MajSoleil) end)

-- LE BROUILLARD -------------------------------------------------------------
local function poser(b, nEchelle, f)
    -- La DENSITE seule est interpolee, pas les distances : faire venir le
    -- brouillard de l'infini donnerait un mur qui avance sur le joueur, alors
    -- qu'un brouillard qui s'epaissit sur place se lit comme le temps qui change.
    render.FogMode(MATERIAL_FOG_LINEAR)
    render.FogColor(b.couleur.r, b.couleur.g, b.couleur.b)
    -- L'echelle du skybox vient du hook : c'est la map qui la fixe via
    -- sky_camera, un 16 en dur serait faux a la premiere qui choisit autrement.
    render.FogStart(b.debut / (nEchelle or 1))
    render.FogEnd(b.fin / (nEchelle or 1))
    render.FogMaxDensity(Lerp(f or 1, 0, b.densite or 0.4))
    return true
end

-- NE PAS PRENDRE LA MAIN POUR NE RIEN FAIRE. Renvoyer true remplace le
-- brouillard de la MAP, meme si on pose une densite nulle : sa brume
-- atmospherique disparait, et le lointain ressort d'un coup plus sature et plus
-- contraste. C'est exactement ce que le user voyait au premier instant d'une
-- nuit progressive. Tant que notre brouillard ne vaut rien, on laisse celui du
-- mappeur tranquille.
local function fogSi(t, nEchelle)
    -- La brume toxique d'evo_events passe devant le brouillard d'ambiance : sans
    -- ca, le premier des deux hooks a repondre gagnait, au hasard.
    if EVO_EVENTS and EVO_EVENTS.BrumeFog and EVO_EVENTS.BrumeFog(nEchelle) then return true end
    if not (t and t.brouillard) then return end
    local f = EVO_CIEL.Facteur(t)
    -- Toujours un seuil ICI : prendre la main sur le brouillard supprime celui
    -- de la MAP, meme en posant une densite nulle.
    if f <= 0.02 then return end
    return poser(t.brouillard, nEchelle, f)
end

hook.Add("SetupWorldFog", "EVO_Ciel::Fog", function()
    return fogSi(Ambiance(), 1)
end)

hook.Add("SetupSkyboxFog", "EVO_Ciel::FogSky", function(nEchelle)
    return fogSi(Ambiance(), nEchelle)
end)
