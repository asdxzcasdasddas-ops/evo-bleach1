-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_horizon.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - l'horizon : des Menos Grande geants qui marchent lentement au loin
-- (ambiance « Menos a l'horizon », Hueco). Le vrai modele du Menos (pack #5,
-- celui du PNJ), en modeles client, a l'echelle d'une montagne.
--
-- DANS LE MONDE, a distance fixe de l'oeil : ils sont « a l'infini » comme le
-- ciel, mais le relief proche les cache (dessin normal, profondeur comprise),
-- et le brouillard de l'ambiance les voile. Eclairage impose (une lune froide
-- par-dessus, presque rien en dessous) : de loin, une silhouette et un masque.
--
-- TIRE DU TEMPS : ou ils sont, ou ils marchent, lequel tire un cero et quand.
-- Tout le monde voit le meme Menos au meme endroit.
-- Interrupteur : evo_ciel_couche_menos.
-- ============================================================================

local CV_MENOS = CreateClientConVar("evo_ciel_couche_menos", "1", true, false,
    "Menos Grande a l'horizon")

local MODELE = "models/evo/summons/hollow/evo_j8668oxblkb6y0iv/evo_1c71ya77emoke90p.mdl"
local CRI = "tbfpvq7ot1yh/menos_grande_sound.mp3"
local MAT_GLOW = Material("sprites/light_glow02_add")
local MAT_RAYON = CreateMaterial("evo_ciel_rayon", "UnlitGeneric", {
    ["$basetexture"] = "sprites/light_glow02", ["$additive"] = "1",
    ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nocull"] = "1",
})

local function AleaDe(n)
    local x = math.sin(n * 12.9898) * 43758.5453
    return x - math.floor(x)
end

local _geants = {}
local _actif = false

local function Detruire()
    for _, g in ipairs(_geants) do
        if IsValid(g.ent) then g.ent:Remove() end
    end
    _geants = {}
    _actif = false
end

local function Creer(M)
    Detruire()
    for i = 1, M.nombre or 4 do
        local e = ClientsideModel(MODELE, RENDERGROUP_OPAQUE)
        if IsValid(e) then
            e:SetNoDraw(true)
            -- L'echelle se deduit de la taille REELLE du modele : on vise une
            -- hauteur a l'ecran, pas un multiplicateur devine.
            local h = math.max(10, e:OBBMaxs().z - e:OBBMins().z)
            local ech = (M.hauteur or 2600) * (0.85 + AleaDe(i) * 0.3) / h
            e:SetModelScale(ech, 0)
            local seq = e:LookupSequence("walk")
            if not seq or seq < 0 then seq = e:LookupSequence("idle") end
            if seq and seq >= 0 then e:ResetSequence(seq) end
            _geants[#_geants + 1] = {
                ent = e, h = h * ech,
                yaw0 = (M.yaw or 60) + (i - ((M.nombre or 4) + 1) / 2) * (M.ecart or 38) + (AleaDe(i + 0.3) - 0.5) * 12,
                sens = (AleaDe(i + 0.6) > 0.5) and 1 or -1,
                dist = (M.distance or 6500) * (0.9 + AleaDe(i + 0.9) * 0.25),
                duree = (seq and seq >= 0) and e:SequenceDuration(seq) or 2,
                phase = AleaDe(i + 0.2),
            }
        end
    end
    _actif = #_geants > 0
end

-- La position d'un geant a l'instant t : il marche le long de l'horizon, dans
-- son sens, en faisant l'aller-retour sur 40 degres (sinon, en une heure, ils
-- auraient tous fait le tour de la carte).
local function Placer(g, M, oeil, t)
    local course = math.sin(t * (M.vitesse or 0.22) / 40 + g.phase * 6.28)
    local yaw = g.yaw0 + course * 20
    local dirMarche = math.cos(t * (M.vitesse or 0.22) / 40 + g.phase * 6.28)
    local a = Angle(0, yaw, 0)
    local pos = oeil + a:Forward() * g.dist
    pos.z = oeil.z + (M.base or -900)
    -- Il regarde ou il va : la tangente au cercle, dans le sens de sa marche.
    return pos, Angle(0, yaw + (dirMarche >= 0 and 90 or -90), 0)
end

local _dernierCri = 0

hook.Add("Think", "EVO_Ciel::Menos", function()
    local t = EVO_CIEL.Vue()
    local M = t and t.menos
    if not M or not CV_MENOS:GetBool() then
        if _actif then Detruire() end
        return
    end
    if not _actif then Creer(M) end
    -- L'animation de marche : on avance le cycle a la main (un modele client
    -- n'anime pas tout seul).
    local dt = FrameTime()
    for _, g in ipairs(_geants) do
        if IsValid(g.ent) then
            g.ent:SetCycle((g.ent:GetCycle() + dt / math.max(0.5, g.duree) * 0.6) % 1)
        end
    end
end)

-- Le cero : tire du temps, comme les eclairs. Renvoie le geant, l'avancement
-- (0 a 1) et le numero de la periode, ou nil.
local function CeroEnCours(M, now)
    local C = M.cero
    if not C or #_geants == 0 then return nil end
    local P = C.periode or 35
    local n = math.floor(now / P)
    if AleaDe(n + 0.13) > (C.chance or 0.6) then return nil end
    local t0 = n * P + AleaDe(n + 0.27) * (P * 0.6)
    local u = (now - t0) / (C.duree or 2.6)
    if u < 0 or u > 1 then return nil end
    return _geants[1 + math.floor(AleaDe(n + 0.41) * #_geants) % #_geants], u, n
end

hook.Add("PostDrawOpaqueRenderables", "EVO_Ciel::Menos", function(bProfondeur, bCiel)
    if bProfondeur or bCiel or not _actif then return end
    local t = EVO_CIEL.Vue()
    local M = t and t.menos
    if not M then return end
    local f = EVO_CIEL.Facteur(t)
    if f <= 0.05 then return end
    local oeil = EyePos()
    local now = CurTime()
    -- Une lune froide par-dessus, presque rien ailleurs : le relief se lit, le
    -- detail non. Le brouillard de l'ambiance fait le reste.
    render.SuppressEngineLighting(true)
    render.ResetModelLighting(0.035, 0.03, 0.045)
    render.SetModelLighting(BOX_TOP, 0.22, 0.2, 0.28)
    render.SetModelLighting(BOX_FRONT, 0.08, 0.07, 0.1)
    render.SetBlend(math.min(1, f * 1.5))
    for _, g in ipairs(_geants) do
        if IsValid(g.ent) then
            local pos, ang = Placer(g, M, oeil, now)
            g.pos, g.ang = pos, ang
            g.ent:SetPos(pos)
            g.ent:SetAngles(ang)
            g.ent:SetupBones()
            g.ent:DrawModel()
        end
    end
    render.SetBlend(1)
    render.SuppressEngineLighting(false)

    -- Le cero : une charge rouge devant le masque, puis un rayon qui monte.
    local g, u, n = CeroEnCours(M, now)
    if g and g.pos then
        local tete = g.pos + Vector(0, 0, g.h * 0.82) + g.ang:Forward() * g.h * 0.06
        local vers = (g.ang:Forward() + Vector(0, 0, 1.6)):GetNormalized()
        render.SetMaterial(MAT_GLOW)
        local charge = math.min(1, u / 0.35)
        render.DrawSprite(tete, g.h * 0.25 * charge, g.h * 0.25 * charge, Color(255, 60, 80, 255 * charge))
        if u > 0.35 then
            render.SetMaterial(MAT_RAYON)
            local k = 1 - math.Clamp((u - 0.85) / 0.15, 0, 1)
            render.DrawBeam(tete, tete + vers * g.h * 6, g.h * 0.09 * k, 0, 1, Color(255, 70, 90, 255 * k))
            render.DrawBeam(tete, tete + vers * g.h * 6, g.h * 0.035 * k, 0, 1, Color(255, 230, 235, 255 * k))
        end
        -- Le cri, une fois par cero, joue au loin dans sa direction.
        if n ~= _dernierCri then
            _dernierCri = n
            local dirSon = (g.pos - oeil):GetNormalized()
            sound.Play(CRI, oeil + dirSon * 1800, 95, math.random(70, 80), 0.9)
            timer.Simple(1, function() sound.Play("ambient/levels/labs/teleport_postblast_thunder1.wav", oeil + dirSon * 2000, 100, 70, 0.7) end)
        end
    end
end)
