-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_astres.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - les astres : etoiles, etoiles filantes (ou pluie de meteores), lune
-- de sang, soleil noir de l'eclipse. Dessines dans PostDrawSkyBox, derriere le
-- monde, avec un test de profondeur sans ecriture (comme la fumee) : un toit
-- cache une etoile, une montagne cache la lune.
--
-- TOUT EST TIRE DU TEMPS ET D'UN HACHAGE, jamais du hasard local : deux joueurs
-- cote a cote voient la meme etoile filante au meme endroit, au meme instant.
-- C'est la regle de tout l'addon (cf. les eclairs), et la seule qui fasse d'un
-- effet un evenement RP plutot qu'un caprice d'affichage.
--
-- LE BUDGET : les etoiles sont UN seul maillage de quads par image (jamais un
-- appel par etoile), les filantes deux ou trois segments pendant une seconde,
-- la lune et le soleil quelques polygones. Aucune passe d'ecran, aucun shader.
-- Interrupteur : evo_ciel_couche_astres.
-- ============================================================================

local CV_ASTRES = CreateClientConVar("evo_ciel_couche_astres", "1", true, false,
    "Etoiles, filantes, lune de sang et soleil noir des ambiances")

-- Le halo du jeu de base sur un materiau a nous : additif et SANS brouillard,
-- sinon a 12000 unites la brume de la map eteindrait toutes les etoiles.
local MAT_GLOW = CreateMaterial("evo_ciel_astre", "UnlitGeneric", {
    ["$basetexture"] = "sprites/light_glow02",
    ["$additive"] = "1",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
    ["$nofog"] = "1",
    ["$nocull"] = "1",
})
-- Un aplat opaque (le disque noir du soleil, le corps de la lune).
local MAT_APLAT = CreateMaterial("evo_ciel_aplat", "UnlitGeneric", {
    ["$basetexture"] = "vgui/white",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
    ["$translucent"] = "1",
    ["$nofog"] = "1",
    ["$nocull"] = "1",
})
-- Repli si la texture du halo n'existe pas sous ce nom : le materiau additif
-- du jeu, avec brouillard (moins bien, mais jamais un damier rose).
local function Glow()
    if MAT_GLOW:IsError() then return Material("sprites/light_glow02_add") end
    return MAT_GLOW
end

local DIST = 12000   -- comme la Garganta et la fumee : la lune de la map est a cette echelle

-- Le meme hachage que les eclairs et la fumee : un nombre stable par index.
local function AleaDe(n)
    local x = math.sin(n * 12.9898) * 43758.5453
    return x - math.floor(x)
end

-- Un quad face a l'oeil, a `dist` dans la direction `dir`. `right` et `up`
-- sont deduits de la direction : un quad pose au zenith avec le `up` du monde
-- degenererait en trait.
local _ang = Angle(0, 0, 0)
local function QuadVersLoeil(oeil, dir, dist, demi, r, g, b, a)
    local c = oeil + dir * dist
    _ang = dir:Angle()
    local right, up = _ang:Right() * demi, _ang:Up() * demi
    mesh.Position(c - right + up) mesh.TexCoord(0, 0, 0) mesh.Color(r, g, b, a) mesh.AdvanceVertex()
    mesh.Position(c + right + up) mesh.TexCoord(0, 1, 0) mesh.Color(r, g, b, a) mesh.AdvanceVertex()
    mesh.Position(c + right - up) mesh.TexCoord(0, 1, 1) mesh.Color(r, g, b, a) mesh.AdvanceVertex()
    mesh.Position(c - right - up) mesh.TexCoord(0, 0, 1) mesh.Color(r, g, b, a) mesh.AdvanceVertex()
end

-- Un disque plein face a l'oeil (polygone en eventail).
local function Disque(oeil, dir, dist, rayon, col, segments)
    local c = oeil + dir * dist
    local ang = dir:Angle()
    local right, up = ang:Right(), ang:Up()
    segments = segments or 40
    mesh.Begin(MATERIAL_POLYGON, segments)
    for i = 0, segments - 1 do
        local a = i / segments * math.pi * 2
        mesh.Position(c + right * (math.cos(a) * rayon) + up * (math.sin(a) * rayon))
        mesh.Color(col.r, col.g, col.b, col.a or 255)
        mesh.AdvanceVertex()
    end
    mesh.End()
end

-- ── La voie lactee ──────────────────────────────────────────────────────────
-- Une bande en travers du ciel : un grand cercle incline, fait d'une poussiere
-- d'etoiles pales et de quelques nappes laiteuses tres transparentes. Elle
-- tourne avec la voute (meme `rot` que les etoiles).
local MAT_LAIT = CreateMaterial("evo_ciel_lait", "UnlitGeneric", {
    ["$basetexture"] = "particle/smokesprites0001",
    ["$additive"] = "1", ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nofog"] = "1", ["$nocull"] = "1",
})
local _angPole = Angle(-58, 40, 0)

local function VoieLactee(oeil, force, rot)
    _angPole.y = 40 + rot
    local u, v = _angPole:Right(), _angPole:Up()
    local pole = _angPole:Forward()
    -- Les nappes : 26 halos larges, le long du cercle, au-dessus de l'horizon.
    render.SetMaterial(MAT_LAIT)
    mesh.Begin(MATERIAL_QUADS, 26)
    for i = 1, 26 do
        local a = (i / 26) * math.pi * 2
        local dir = (u * math.cos(a) + v * math.sin(a) + pole * (AleaDe(i + 0.7) - 0.5) * 0.12):GetNormalized()
        local k = (dir.z > -0.05) and 1 or 0
        QuadVersLoeil(oeil, dir, DIST, 900 + AleaDe(i + 0.3) * 900, 170, 185, 230, force * 26 * k)
    end
    mesh.End()
    -- La poussiere : 380 points serres autour du cercle.
    render.SetMaterial(Glow())
    mesh.Begin(MATERIAL_QUADS, 380)
    for i = 1, 380 do
        local a = AleaDe(i * 1.37) * math.pi * 2
        local ecart = (AleaDe(i * 2.11) + AleaDe(i * 3.07) - 1) * 0.16
        local dir = (u * math.cos(a) + v * math.sin(a) + pole * ecart):GetNormalized()
        local scint = 0.6 + 0.4 * math.sin(CurTime() * (1 + AleaDe(i) * 2) + i)
        local al = (dir.z > -0.05) and force * scint * (70 + AleaDe(i * 5.3) * 80) or 0
        QuadVersLoeil(oeil, dir, DIST, 14 + AleaDe(i * 4.1) * 22, 225, 232, 255, al)
    end
    mesh.End()
end

-- ── Les etoiles ─────────────────────────────────────────────────────────────
-- Reparties sur la voute (pitch tire d'un arcsinus : sans ca elles se tassent
-- au zenith), chacune avec sa taille, sa teinte et son scintillement. La voute
-- tourne lentement autour du zenith : en une heure, le ciel n'est plus le meme.
local function Etoiles(t, E, oeil, f, tps)
    local n = E.nombre or 220
    local tMin, tMax = (E.taille or {})[1] or 24, (E.taille or {})[2] or 120
    local rot = tps * (E.vitesse or 0.3)
    -- Elles n'apparaissent qu'une fois le ciel vraiment sombre : la montee est
    -- au carre, les premieres minutes d'une nuit qui tombe n'en montrent aucune.
    -- `seuil` (eclipse lente) : rien avant cet avancement, elles sortent a la
    -- totalite seulement.
    local force = f * f * (E.alpha or 1)
    if E.seuil then
        local brut = EVO_CIEL.Progression and EVO_CIEL.Progression(t) or f
        force = math.Clamp((brut - E.seuil) / math.max(0.01, 1 - E.seuil), 0, 1) * (E.alpha or 1)
    end
    if force <= 0.01 then return end
    if E.voieLactee then VoieLactee(oeil, force, tps * (E.vitesse or 0.3)) end
    render.SetMaterial(Glow())
    mesh.Begin(MATERIAL_QUADS, n)
    for i = 1, n do
        local yaw = AleaDe(i) * 360 + rot
        local pitch = math.deg(math.asin(0.04 + AleaDe(i + 0.1) * 0.96))
        _ang.p, _ang.y, _ang.r = -pitch, yaw, 0
        local dir = _ang:Forward()
        local k = AleaDe(i + 0.2)
        local demi = tMin + k * k * k * (tMax - tMin)
        -- Scintillement : chaque etoile a son rythme et sa phase.
        local scint = 0.62 + 0.38 * math.sin(tps * (1.3 + AleaDe(i + 0.3) * 2.6) + AleaDe(i + 0.4) * 6.28)
        local a = force * scint * (150 + k * 105)
        -- Blanc, un peu de bleu sur les grosses, un souffle de chaud sur quelques-unes.
        local teinte = AleaDe(i + 0.5)
        local r, g, b = 255, 255, 255
        if teinte < 0.25 then r, g = 205, 225 elseif teinte > 0.85 then g, b = 232, 200 end
        QuadVersLoeil(oeil, dir, DIST, demi, r, g, b, a)
    end
    mesh.End()
end

-- ── Les filantes ────────────────────────────────────────────────────────────
-- Tirees du temps comme les eclairs : numero de periode -> chance -> instant de
-- depart -> trajet. Le trajet est un arc entre deux directions du ciel, la tete
-- avance et la queue s'efface derriere elle. `tete` ajoute un halo au bout :
-- c'est ce qui fait le meteore de l'Invasion, gros, rouge et frequent.
local function Filantes(t, F, oeil, f, tps)
    local P = F.periode or 28
    local nP = math.floor(tps / P)
    if AleaDe(nP) > (F.chance or 0.55) then return end
    local duree = F.duree or 0.9
    local t0 = nP * P + AleaDe(nP + 0.5) * (P * 0.7)
    local u = (tps - t0) / duree
    if u < 0 or u > 1 then return end

    local yaw0 = AleaDe(nP + 0.7) * 360
    local p0 = 22 + AleaDe(nP + 0.9) * 48
    local yaw1 = yaw0 + 50 + AleaDe(nP + 0.11) * 70
    local p1 = 6 + AleaDe(nP + 0.13) * 30
    local function Point(k)
        _ang.p, _ang.y, _ang.r = -Lerp(k, p0, p1), Lerp(k, yaw0, yaw1), 0
        return oeil + _ang:Forward() * DIST
    end
    local c = F.couleur or Color(240, 244, 255)
    local a = f * 255 * math.sin(u * math.pi)
    local largeur = (F.largeur or 1.6) * 40
    render.SetMaterial(Glow())
    -- La queue : trois segments de plus en plus fins et pales derriere la tete.
    local queue = F.queue or 0.09
    local tete = Point(u)
    for s = 1, 3 do
        local k0, k1 = math.max(0, u - queue * s), math.max(0, u - queue * (s - 1))
        if k1 > k0 then
            local w = largeur * (1 - (s - 1) * 0.3)
            local al = a * (1 - (s - 1) * 0.4)
            render.DrawBeam(Point(k0), Point(k1), w, 0, 1, Color(c.r, c.g, c.b, al))
        end
    end
    if F.tete then
        render.DrawSprite(tete, F.tete, F.tete, Color(c.r, c.g, c.b, a))
    end
end

-- ── La lune de sang ─────────────────────────────────────────────────────────
-- Un corps sombre, un coeur plus clair, un halo large qui respire. Toujours au
-- meme endroit du ciel (direction absolue dans la config) : les joueurs se la
-- montrent du doigt.
local function Lune(t, L, oeil, f, tps)
    local dir = (L.dir or Angle(-38, 215, 0)):Forward()
    local rayon = L.rayon or 800
    local col, coeur = L.couleur or Color(210, 26, 24), L.coeur or Color(255, 70, 50)
    local pulse = 1 - (L.pulse or 0.1) * (0.5 + 0.5 * math.sin(tps * (L.vitesse or 0.9)))
    local a = f * 255
    -- Le halo, en deux couches : large et pale, puis serre et vif.
    render.SetMaterial(Glow())
    mesh.Begin(MATERIAL_QUADS, 2)
    QuadVersLoeil(oeil, dir, DIST, rayon * (L.halo or 2.8) * pulse, col.r, col.g, col.b, a * 0.42)
    QuadVersLoeil(oeil, dir, DIST, rayon * 1.55, coeur.r, coeur.g, coeur.b, a * 0.6 * pulse)
    mesh.End()
    -- Le corps : un disque sombre, puis un disque plus clair et plus petit,
    -- decale d'un cote : c'est l'ombre qui donne le volume.
    render.SetMaterial(MAT_APLAT)
    Disque(oeil, dir, DIST - 10, rayon, Color(col.r * 0.55, col.g * 0.5, col.b * 0.5, a))
    local ang = dir:Angle()
    local dec = (ang:Right() * -0.18 + ang:Up() * 0.12) * rayon
    Disque(oeil + dec, dir, DIST - 12, rayon * 0.78, Color(col.r * 0.85, col.g * 0.8, col.b * 0.8, a))
end

-- ── Le soleil noir ──────────────────────────────────────────────────────────
-- L'eclipse : un disque noir, une couronne qui palpite et des rais qui tournent
-- lentement. Dessine dans le ciel, a l'echelle de la lune de la map, la ou la
-- config le pose (l'env_sun de la map est retire par l'ambiance).
-- ── L'eclipse qui avance (`recouvrement`, eclipse lente) ────────────────────
-- Un vrai soleil, que le disque de la lune glisse recouvrir a mesure que
-- l'ambiance avance (avancement BRUT, lineaire : la lune avance a vitesse
-- constante, seule la lumiere du monde suit la courbe). A 95 % l'anneau de
-- diamant, a la totalite la couronne et ses rais.
local function EclipseLente(t, S, oeil, tps)
    local p = EVO_CIEL.Progression and EVO_CIEL.Progression(t) or 1
    local dir = (S.dir or Angle(-50, 75, 0)):Forward()
    local rayon = S.rayon or 560
    local ang = dir:Angle()
    local cote = ang:Right() * 0.8 + ang:Up() * 0.6
    local centre = oeil + dir * DIST
    local c = S.couronne or Color(255, 226, 180)
    local totale = math.Clamp((p - 0.97) / 0.03, 0, 1)
    render.SetMaterial(Glow())
    -- La couronne et les rais, seulement quand le soleil est cache.
    if totale > 0 then
        local souffle = 0.85 + 0.15 * math.sin(tps * 0.8) * math.sin(tps * 2.3)
        local right, up = ang:Right(), ang:Up()
        for i = 1, S.rais or 10 do
            local th = math.rad(i / (S.rais or 10) * 360 + tps * 1.0 + AleaDe(i) * 20)
            local lng = rayon * (1.8 + AleaDe(i + 0.3) * 1.6) * souffle
            local v = right * math.cos(th) + up * math.sin(th)
            render.DrawBeam(centre + v * rayon * 0.9, centre + v * lng, rayon * (0.1 + AleaDe(i + 0.6) * 0.16), 0, 1,
                Color(c.r, c.g, c.b, 255 * totale * (0.35 + AleaDe(i + 0.8) * 0.35)))
        end
        mesh.Begin(MATERIAL_QUADS, 1)
        QuadVersLoeil(oeil, dir, DIST, rayon * 3.2 * souffle, c.r, c.g, c.b, 130 * totale)
        mesh.End()
    end
    -- Le soleil : son halo faiblit a mesure qu'il est couvert, puis s'eteint.
    local visible = 1 - p ^ 3
    if visible > 0 then
        mesh.Begin(MATERIAL_QUADS, 2)
        QuadVersLoeil(oeil, dir, DIST, rayon * 5, 255, 236, 200, 150 * visible)
        QuadVersLoeil(oeil, dir, DIST, rayon * 2.2, 255, 248, 230, 230 * visible)
        mesh.End()
    end
    -- La lune n'existe QUE devant le soleil : une nouvelle lune est invisible
    -- dans le ciel de jour. Le disque solaire marque le stencil (meme quand il
    -- est eteint, a la totalite), la lune ne se dessine que sur cette marque.
    -- Sans ca, un disque noir se promenait a cote du soleil.
    render.ClearStencil()
    render.SetStencilEnable(true)
    render.SetStencilWriteMask(255)
    render.SetStencilTestMask(255)
    render.SetStencilReferenceValue(1)
    render.SetStencilCompareFunction(STENCIL_ALWAYS)
    render.SetStencilPassOperation(STENCIL_REPLACE)
    render.SetStencilFailOperation(STENCIL_KEEP)
    render.SetStencilZFailOperation(STENCIL_KEEP)
    render.SetMaterial(MAT_APLAT)
    Disque(oeil, dir, DIST - 30, rayon, Color(255, 246, 222, 255 * math.min(1, visible * 4)), 48)
    -- La lune : elle arrive du cote, et s'arrete pile sur le soleil.
    render.SetStencilCompareFunction(STENCIL_EQUAL)
    render.SetStencilPassOperation(STENCIL_KEEP)
    Disque(oeil + cote * rayon * 2.2 * (1 - p), dir, DIST - 40, rayon * 1.02, Color(4, 3, 6, 255), 48)
    render.SetStencilEnable(false)
    -- L'anneau de diamant : le dernier eclat du soleil, sur le bord oppose.
    local diam = math.max(0, 1 - math.abs(p - 0.975) / 0.022)
    if diam > 0 then
        render.SetMaterial(Glow())
        local pt = centre - cote:GetNormalized() * rayon * 0.98
        render.DrawSprite(pt, rayon * 2.6 * diam, rayon * 2.6 * diam, Color(255, 255, 255, 255 * diam))
        render.DrawSprite(pt, rayon * 7 * diam, rayon * 0.35 * diam, Color(255, 250, 235, 200 * diam))
    end
end

-- ── La comete ───────────────────────────────────────────────────────────────
-- Une tete (noyau blanc, chevelure vert pale), une queue de poussiere large,
-- courbe et doree, et une queue d'ions droite, fine et bleue, qui ondule. Les
-- deux sont des rubans face a l'oeil (render.AddBeam) le long d'un arc de ciel,
-- du noyau vers `queue`. Le motif de fumee glisse le long de la queue : elle
-- vit, sans rien de plus a calculer.
local MAT_QUEUE = CreateMaterial("evo_ciel_queue", "UnlitGeneric", {
    ["$basetexture"] = "trails/smoke",
    ["$additive"] = "1", ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nofog"] = "1", ["$nocull"] = "1",
})

local function Comete(t, C, oeil, f, tps)
    local a = f
    if a <= 0.02 then return end
    local derive = (C.derive or 6) * tps / 3600
    local angT = Angle((C.dir or Angle(-30, 135, 0)).p, (C.dir or Angle(-30, 135, 0)).y + derive, 0)
    local angQ = Angle((C.queue or Angle(-58, 205, 0)).p, (C.queue or Angle(-58, 205, 0)).y + derive, 0)
    local tete, vers = angT:Forward(), angQ:Forward()
    -- La fraction de l'arc tete -> `queue` que couvre la queue.
    local ecart = math.deg(math.acos(math.Clamp(tete:Dot(vers), -1, 1)))
    local frac = math.Clamp((C.longueur or 38) / math.max(1, ecart), 0, 1)
    local perp = tete:Cross(vers):GetNormalized()
    local R = C.rayon or 180
    local function point(s, courbe)
        local d = (tete * (1 - s * frac) + vers * (s * frac)):GetNormalized()
        if courbe then d = (d + perp * (s * s) * courbe):GetNormalized() end
        return oeil + d * DIST
    end
    local defil = tps * 0.03
    local N = 16
    -- La queue de poussiere : large, courbe, doree, qui s'evase.
    render.SetMaterial(MAT_QUEUE)
    render.StartBeam(N + 1)
    for k = 0, N do
        local s = k / N
        local al = a * 200 * (1 - s) ^ 1.3
        render.AddBeam(point(s, 0.07), R * (1.6 + s * 12), s * 2 + defil, Color(255, 236, 200, al))
    end
    render.EndBeam()
    -- La queue d'ions : droite, fine, bleue, en trois brins qui ondulent.
    render.SetMaterial(Glow())
    for b = 1, 3 do
        render.StartBeam(N + 1)
        for k = 0, N do
            local s = k / N
            local ond = math.sin(s * 9 - tps * (0.8 + b * 0.3) + b) * 0.004 * s
            local d = (point(s * 1.25, nil) - oeil):GetNormalized() + perp * (ond + (b - 2) * 0.006 * s)
            local al = a * (130 - b * 25) * (1 - s) ^ 0.8 * (0.8 + 0.2 * math.sin(tps * 3 + b + s * 5))
            render.AddBeam(oeil + d:GetNormalized() * DIST, R * (0.5 + s * 2.5), s, Color(150, 200, 255, al))
        end
        render.EndBeam()
    end
    -- Des grains qui filent le long de la queue de poussiere.
    for k = 1, 24 do
        local s = (AleaDe(k * 1.7) + tps * 0.004 * (0.5 + AleaDe(k))) % 1
        local p = point(s, 0.07) + perp * (AleaDe(k * 2.9) - 0.5) * R * 4 * s
        render.DrawSprite(p, 60, 60, Color(255, 240, 210, a * 150 * (1 - s)))
    end
    -- La tete : chevelure large, puis coeur, puis noyau.
    local centre = oeil + tete * DIST
    local pulse = 1 + 0.04 * math.sin(tps * 1.3)
    mesh.Begin(MATERIAL_QUADS, 3)
    QuadVersLoeil(oeil, tete, DIST, R * 6 * pulse, 170, 230, 210, a * 60)
    QuadVersLoeil(oeil, tete, DIST, R * 2.4, 200, 255, 230, a * 190)
    QuadVersLoeil(oeil, tete, DIST, R * 0.8, 255, 255, 255, a * 255)
    mesh.End()
    render.DrawSprite(centre, R * 0.5, R * 0.5, Color(255, 255, 255, a * 255))
end

-- ── L'aurore boreale ────────────────────────────────────────────────────────
-- Des rideaux : pour chacun, une rangee de colonnes verticales qui partent d'une
-- base ondulante ; chaque colonne a sa propre intensite (les stries), qui
-- change lentement. Couleur de la config en bas, `sommet` en haut qui s'efface.
-- Un seul maillage pour tout, des couleurs PREMULTIPLIEES (juste quel que soit
-- le mode additif du moteur).
local MAT_AURORE = CreateMaterial("evo_ciel_aurore", "UnlitGeneric", {
    ["$basetexture"] = "vgui/white",
    ["$additive"] = "1", ["$vertexcolor"] = "1", ["$vertexalpha"] = "1", ["$nofog"] = "1", ["$nocull"] = "1",
})

local function Aurore(t, A, oeil, f, tps)
    local force = f * f
    if force <= 0.01 then return end
    local N, nR = 90, A.rideaux or 3
    local c1, c2 = A.couleur or Color(80, 255, 150), A.sommet or Color(170, 90, 255)
    local function ptCiel(yaw, pitch)
        _ang.p, _ang.y, _ang.r = -pitch, yaw, 0
        return oeil + _ang:Forward() * DIST
    end
    render.SetMaterial(MAT_AURORE)
    mesh.Begin(MATERIAL_QUADS, N * nR)
    for j = 1, nR do
        local y0 = (A.yaw or 20) - (A.largeur or 150) / 2 + (j - 2) * 18
        local larg = (A.largeur or 150) * (0.7 + 0.15 * j)
        local haut = (A.haut or 30) * (1.1 - j * 0.15)
        local bas = (A.bas or 9) + j * 3
        for i = 0, N - 1 do
            local s0, s1 = i / N, (i + 1) / N
            local yawA, yawB = y0 + s0 * larg, y0 + s1 * larg
            local ondA = math.sin(s0 * 11 + tps * 0.35 + j) * 3 + math.sin(s0 * 23 - tps * 0.2 + j * 2) * 1.5
            local ondB = math.sin(s1 * 11 + tps * 0.35 + j) * 3 + math.sin(s1 * 23 - tps * 0.2 + j * 2) * 1.5
            -- Les stries : une intensite par colonne, qui derive doucement.
            local stri = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(i * 1.7 + j * 3 + tps * 0.6 + math.sin(i * 0.45 + tps * 0.25) * 2))
            local env = math.sin(s0 * math.pi) ^ 0.6 * (0.75 + 0.25 * math.sin(tps * 0.5 + j))
            local k = force * stri * env / nR * 1.6
            local r1, g1, b1 = c1.r * k, c1.g * k, c1.b * k
            local hA, hB = haut * (0.8 + 0.2 * math.sin(s0 * 7 + tps * 0.4)), haut * (0.8 + 0.2 * math.sin(s1 * 7 + tps * 0.4))
            local k2 = k * 0.12
            mesh.Position(ptCiel(yawA, bas + ondA)) mesh.Color(r1, g1, b1, 255) mesh.AdvanceVertex()
            mesh.Position(ptCiel(yawB, bas + ondB)) mesh.Color(r1, g1, b1, 255) mesh.AdvanceVertex()
            mesh.Position(ptCiel(yawB, bas + ondB + hB)) mesh.Color(c2.r * k2, c2.g * k2, c2.b * k2, 255) mesh.AdvanceVertex()
            mesh.Position(ptCiel(yawA, bas + ondA + hA)) mesh.Color(c2.r * k2, c2.g * k2, c2.b * k2, 255) mesh.AdvanceVertex()
        end
    end
    mesh.End()
end

local function SoleilNoir(t, S, oeil, f, tps)
    if S.recouvrement then return EclipseLente(t, S, oeil, tps) end
    local dir = (S.dir or Angle(-56, 75, 0)):Forward()
    local rayon = S.rayon or 560
    local c = S.couronne or Color(255, 226, 180)
    local a = f * 255
    local souffle = 0.85 + 0.15 * math.sin(tps * 0.8) * math.sin(tps * 2.3)
    render.SetMaterial(Glow())
    -- Les rais : des traits additifs qui partent du bord, longueur et angle
    -- tires du hachage, la roue tourne d'un degre par seconde.
    local ang = dir:Angle()
    local right, up = ang:Right(), ang:Up()
    local centre = oeil + dir * DIST
    local nb = S.rais or 10
    for i = 1, nb do
        local th = math.rad(i / nb * 360 + tps * 1.0 + AleaDe(i) * 20)
        local lng = rayon * (1.8 + AleaDe(i + 0.3) * 1.6) * souffle
        local v = right * math.cos(th) + up * math.sin(th)
        render.DrawBeam(centre + v * rayon * 0.9, centre + v * lng, rayon * (0.10 + AleaDe(i + 0.6) * 0.16), 0, 1,
            Color(c.r, c.g, c.b, a * (0.35 + AleaDe(i + 0.8) * 0.35)))
    end
    -- La couronne : deux halos, le serre presque blanc.
    mesh.Begin(MATERIAL_QUADS, 2)
    QuadVersLoeil(oeil, dir, DIST, rayon * 3.2 * souffle, c.r, c.g, c.b, a * 0.5)
    QuadVersLoeil(oeil, dir, DIST, rayon * 1.6, 255, 250, 240, a * 0.85)
    mesh.End()
    -- Le disque noir, en dernier, devant tout le reste : c'est lui l'eclipse.
    render.SetMaterial(MAT_APLAT)
    Disque(oeil, dir, DIST - 20, rayon, Color(4, 3, 6, a), 48)
end

hook.Add("PostDrawSkyBox", "EVO_Ciel::Astres", function()
    if not CV_ASTRES:GetBool() then return end
    local t = EVO_CIEL.Vue()
    if not t then return end
    if not (t.etoiles or t.filantes or t.lune or t.soleilNoir or t.comete or t.aurore) then return end
    local f = EVO_CIEL.Facteur(t)
    -- L'eclipse lente commence en plein jour : sa lune doit avancer des le
    -- debut, meme quand le Facteur (courbe) est encore a zero.
    if f <= 0.02 and not (t.soleilNoir and t.soleilNoir.recouvrement) then return end
    local oeil = EyePos()
    local tps = CurTime()
    -- Test de profondeur sans ecriture : le monde, dessine apres, passe devant.
    render.OverrideDepthEnable(true, false)
    if t.etoiles then Etoiles(t, t.etoiles, oeil, f, tps) end
    if t.aurore then Aurore(t, t.aurore, oeil, f, tps) end
    if t.comete then Comete(t, t.comete, oeil, f, tps) end
    if t.lune then Lune(t, t.lune, oeil, f, tps) end
    if t.soleilNoir then SoleilNoir(t, t.soleilNoir, oeil, f, tps) end
    if t.filantes then Filantes(t, t.filantes, oeil, f, tps) end
    render.OverrideDepthEnable(false, false)
end)
