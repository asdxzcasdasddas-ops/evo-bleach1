-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_ui.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - le menu des ambiances.
--
-- POURQUOI UN MENU plutot que des commandes : le staff choisit une ambiance en
-- pleine animation, souvent avec des joueurs qui attendent. Taper un nom exact
-- de tete, ou pire se tromper et lancer autre chose devant tout le monde, ca ne
-- tient pas. Le menu montre CE QUE FAIT chaque ambiance avant qu'on clique.
--
-- La grammaire visuelle est celle du reste du serveur : fond sombre, accent
-- rouge, angle coupe en haut a droite, Bebas Neue.
-- ============================================================================

surface.CreateFont("EVO_Ciel_Titre", { font = "Bebas Neue", size = 30, weight = 500, antialias = true })
surface.CreateFont("EVO_Ciel_Nom",   { font = "Bebas Neue", size = 25, weight = 500, antialias = true })
surface.CreateFont("EVO_Ciel_Info",  { font = "Roboto", size = 15, weight = 400, antialias = true })

local ACCENT = Color(207, 68, 78)
local BLANC  = Color(236, 236, 238)
local MUTED  = Color(150, 150, 158)
local VERT   = Color(120, 200, 130)

local _frame
-- Le choix d'ouverture retenu entre deux ouvertures du menu. nil = « qu'elle
-- grandisse toute seule », un nombre = taille imposee. Il sert au PROCHAIN
-- lancement : le staff regle une fois, puis enchaine les ambiances.
local _ouverture = nil
-- La duree de montee choisie (secondes). nil = celle de la config de
-- l'ambiance. Retenue entre deux ouvertures du menu, comme l'ouverture.
local _duree = nil

local function Fermer()
    if IsValid(_frame) then _frame:Remove() end
    _frame = nil
end

-- La pastille de couleur : elle donne la TEINTE de l'ambiance d'un coup d'oeil.
-- Un nom seul ne dit pas si on part sur du rouge ou du bleu nuit, et c'est la
-- premiere chose qu'on veut savoir.
local function Pastille(x, y, r, col)
    draw.NoTexture()
    surface.SetDrawColor(col)
    local p = {}
    for i = 0, 23 do
        local a = math.rad(i / 24 * 360)
        p[#p + 1] = { x = x + math.cos(a) * r, y = y + math.sin(a) * r }
    end
    surface.DrawPoly(p)
end

function EVO_CIEL.OuvrirMenu()
    Fermer()

    local noms = EVO_CIEL.ListeAmbiances()

    -- La barre d'ouverture n'a de sens que si la carte propose une ambiance qui
    -- grandit. Au Seireitei il n'y a pas de Garganta : afficher un reglage sans
    -- objet ferait chercher un effet qui n'existe pas.
    local bBarre = false
    for _, k in ipairs(noms) do
        if EVO_CIEL.Ambiances[k].croissance then bBarre = true break end
    end

    local L, LIGNE = 560, 64
    local BARRE = bBarre and 74 or 0
    -- 74 de plus pour la rangee des durees, presente sur toutes les maps.
    local H = 108 + (#noms + 1) * (LIGNE + 6) + 22 + BARRE + 74

    local f = vgui.Create("DFrame")
    _frame = f
    f:SetSize(L, math.min(H, ScrH() - 80))
    f:Center()
    f:SetTitle("")
    f:ShowCloseButton(false)
    f:MakePopup()
    f.Paint = function(_, w, h)
        draw.NoTexture()
        surface.SetDrawColor(12, 12, 15, 250)
        -- Angle coupe en haut a droite : la signature de la DA du serveur.
        surface.DrawPoly({
            { x = 0, y = 0 }, { x = w - 22, y = 0 }, { x = w, y = 22 },
            { x = w, y = h }, { x = 0, y = h },
        })
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, 5, h)
        draw.SimpleText("AMBIANCE DU CIEL", "EVO_Ciel_Titre", 22, 26, BLANC, 0, 1)
        draw.SimpleText(game.GetMap(), "EVO_Ciel_Info", w - 28, 28, MUTED, TEXT_ALIGN_RIGHT, 1)
        draw.SimpleText("Visible par TOUS les joueurs du serveur.", "EVO_Ciel_Info", 23, 58, MUTED, 0, 1)
    end

    local x = vgui.Create("DButton", f)
    x:SetSize(26, 26)
    x:SetPos(L - 34, 6)
    x:SetText("")
    x.Paint = function(pnl, w, h)
        draw.SimpleText("X", "EVO_Ciel_Nom", w / 2, h / 2,
            pnl:IsHovered() and ACCENT or MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = Fermer

    local liste = vgui.Create("DScrollPanel", f)
    liste:SetPos(14, 84)
    liste:SetSize(L - 28, f:GetTall() - 96 - BARRE - 74)

    local function Ligne(sCle, sNom, sResume, col, bActive)
        local b = vgui.Create("DButton", liste)
        b:Dock(TOP)
        b:DockMargin(0, 0, 0, 6)
        b:SetTall(LIGNE)
        b:SetText("")
        b.Paint = function(pnl, w, h)
            local surv = pnl:IsHovered()
            surface.SetDrawColor(bActive and Color(30, 18, 20) or (surv and Color(26, 26, 32) or Color(18, 18, 22)))
            surface.DrawRect(0, 0, w, h)
            if bActive then
                surface.SetDrawColor(VERT)
                surface.DrawRect(0, 0, 3, h)
            elseif surv then
                surface.SetDrawColor(ACCENT)
                surface.DrawRect(0, 0, 3, h)
            end
            if col then Pastille(34, h / 2, 11, col) end
            draw.SimpleText(sNom, "EVO_Ciel_Nom", 58, 20, bActive and VERT or BLANC, 0, 1)
            draw.SimpleText(sResume, "EVO_Ciel_Info", 58, 43, MUTED, 0, 1)
            if bActive then
                draw.SimpleText("EN COURS", "EVO_Ciel_Info", w - 14, h / 2, VERT, TEXT_ALIGN_RIGHT, 1)
            end
        end
        b.DoClick = function()
            surface.PlaySound("ui/buttonclickrelease.wav")
            net.Start("evo_ciel:set")
                net.WriteString(sCle)
                net.WriteBool(false)             -- on lance une ambiance
                net.WriteBool(_ouverture ~= nil) -- taille imposee ?
                if _ouverture then net.WriteFloat(_ouverture) end
                net.WriteFloat(_duree or 0)      -- 0 = duree de la config
            net.SendToServer()
            Fermer()
        end
    end

    -- LA BARRE D'OUVERTURE.
    -- Pourquoi des paliers et pas un curseur : on regle ca en pleine animation,
    -- souvent avec des joueurs qui attendent. Cinq boutons se cliquent sans
    -- viser ; un curseur se rate, et une Garganta a 3 % ne se voit pas.
    if bBarre then
        -- « Petite » IMPOSE la taille de base au lieu de rendre la main a la
        -- croissance : c'est ce qui permet de lancer l'ambiance Garganta (ciel
        -- rouge, brouillard) en GARDANT la faille telle qu'elle est deja au
        -- ciel, sans qu'elle reparte en croissance. La croissance automatique
        -- devient un choix explicite, le dernier bouton.
        local tChoix = {
            { l = "Petite", v = 0.10 },
            { l = "25 %", v = 0.25 },
            { l = "50 %", v = 0.50 },
            { l = "75 %", v = 0.75 },
            { l = "Ouverte", v = 1.00 },
            { l = "Grandit", v = "auto" },
        }
        local yB = f:GetTall() - BARRE + 4
        local nLarge = math.floor((L - 28 - (#tChoix - 1) * 6) / #tChoix)

        local lbl = vgui.Create("DLabel", f)
        lbl:SetPos(16, yB - 2)
        lbl:SetSize(L - 32, 18)
        lbl:SetFont("EVO_Ciel_Info")
        lbl:SetTextColor(MUTED)
        lbl:SetText("Ouverture de la Garganta")

        for i, c in ipairs(tChoix) do
            local bt = vgui.Create("DButton", f)
            bt:SetPos(14 + (i - 1) * (nLarge + 6), yB + 18)
            bt:SetSize(nLarge, 30)
            bt:SetText("")
            bt.Paint = function(pnl, w, h)
                -- Tolerance : la globale est un float 32 bits, 0.10 n'en
                -- revient jamais strictement egal a lui-meme.
                local bActif
                if c.v == "auto" then
                    bActif = (_ouverture == nil)
                else
                    bActif = _ouverture ~= nil and math.abs(_ouverture - c.v) < 0.005
                end
                local surv = pnl:IsHovered()
                surface.SetDrawColor(bActif and Color(30, 18, 20)
                    or (surv and Color(28, 28, 34) or Color(18, 18, 22)))
                surface.DrawRect(0, 0, w, h)
                if bActif then
                    surface.SetDrawColor(VERT)
                    surface.DrawRect(0, h - 2, w, 2)
                end
                draw.SimpleText(c.l, "EVO_Ciel_Info", w / 2, h / 2,
                    bActif and VERT or (surv and BLANC or MUTED),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            bt.DoClick = function()
                surface.PlaySound("ui/buttonclickrelease.wav")
                _ouverture = c.v ~= "auto" and c.v or nil
                -- Application IMMEDIATE si une ambiance a fente tourne deja :
                -- c'est tout l'interet, regler la taille sans relancer
                -- l'evenement ni refaire repartir le fondu devant tout le monde.
                -- Le menu reste ouvert pour comparer les paliers.
                local tEnCours = EVO_CIEL.Ambiance(EVO_CIEL.EnCours())
                if tEnCours and tEnCours.croissance then
                net.Start("evo_ciel:set")
                    net.WriteString("")
                    net.WriteBool(true)              -- ouverture seule
                    net.WriteBool(c.v ~= nil)
                    if c.v then net.WriteFloat(c.v) end
                    net.WriteFloat(0)
                net.SendToServer()
                end
            end
        end
    end

    -- LA DUREE DE MONTEE. Choisie AVANT de cliquer l'ambiance : la meme nuit
    -- sert un fondu d'une minute en test et d'une heure et demie en animation.
    -- Des paliers, pas un champ libre : ca se regle en pleine animation.
    do
        local tD = {
            { l = "Defaut", v = nil },
            { l = "1 min", v = 60 },
            { l = "5 min", v = 300 },
            { l = "15 min", v = 900 },
            { l = "45 min", v = 2700 },
            { l = "1 h 30", v = 5400 },
        }
        local yD = f:GetTall() - BARRE - 74
        local lbl2 = vgui.Create("DLabel", f)
        lbl2:SetPos(16, yD - 2)
        lbl2:SetSize(L - 32, 18)
        lbl2:SetFont("EVO_Ciel_Info")
        lbl2:SetTextColor(MUTED)
        lbl2:SetText("Duree de montee (nuit qui tombe, faille qui grandit...)")
        local nLarge2 = math.floor((L - 28 - (#tD - 1) * 6) / #tD)
        for i, c in ipairs(tD) do
            local bt = vgui.Create("DButton", f)
            bt:SetPos(14 + (i - 1) * (nLarge2 + 6), yD + 18)
            bt:SetSize(nLarge2, 30)
            bt:SetText("")
            bt.Paint = function(pnl, w, h)
                local bActif = (_duree == c.v)
                surface.SetDrawColor(bActif and Color(30, 18, 20)
                    or (pnl:IsHovered() and Color(28, 28, 34) or Color(18, 18, 22)))
                surface.DrawRect(0, 0, w, h)
                if bActif then
                    surface.SetDrawColor(VERT)
                    surface.DrawRect(0, h - 2, w, 2)
                end
                draw.SimpleText(c.l, "EVO_Ciel_Info", w / 2, h / 2,
                    bActif and VERT or (pnl:IsHovered() and BLANC or MUTED),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            bt.DoClick = function()
                surface.PlaySound("ui/buttonclickrelease.wav")
                _duree = c.v
            end
        end
    end

    local sEnCours = EVO_CIEL.EnCours()
    -- On repart de l'etat REEL du serveur : rouvrir le menu apres un
    -- redemarrage ou apres le reglage d'un autre membre du staff doit montrer ce
    -- qui est en place, pas ce que ce client avait choisi la derniere fois.
    _ouverture = EVO_CIEL.OuvertureImposee and EVO_CIEL.OuvertureImposee() or nil
    Ligne("normal", "Aucune", "Le ciel d'origine de la map.", nil, sEnCours == "")
    for _, k in ipairs(noms) do
        local t = EVO_CIEL.Ambiances[k]
        Ligne(k, t.label or k, t.resume or "", t.skyTeinte, sEnCours == k)
    end
end

net.Receive("evo_ciel:menu", EVO_CIEL.OuvrirMenu)
