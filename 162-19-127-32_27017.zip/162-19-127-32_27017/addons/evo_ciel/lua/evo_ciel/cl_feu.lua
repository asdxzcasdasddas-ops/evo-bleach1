-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_feu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - le feu : ce qu'on entend, et la fumee dans le ciel. Pour
-- l'ambiance « Ciel en flammes ».
--
-- LE SON : des boucles du jeu de base (ambient/fire), posees sur le joueur
-- lui-meme, bas. Le crepitement, et loin dessous le souffle d'un grand feu,
-- ralenti. Le volume suit la montee de l'ambiance et retombe avec elle ; il
-- n'est retouche que cinq fois par seconde, un fondu de moteur fait le reste.
--
-- LA FUMEE : des quads textures dans le ciel, avec le sprite de fumee du jeu
-- sur un materiau a nous : $nofog, sinon a 11000 unites le brouillard de
-- l'ambiance les mangerait tout entiers. Des nappes qui derivent lentement en
-- hauteur, et des colonnes qui montent de l'horizon, la ou la ville brule.
-- Dessinees dans PostDrawSkyBox comme la Garganta : derriere le monde, devant
-- le ciel, donc masquees par les batiments. Les positions sont tirees de
-- l'INDEX de la nappe (un hachage), pas du hasard : tout le monde voit les
-- memes nappes au meme endroit, et elles derivent avec le temps du serveur.
--
-- Cout : une quinzaine de quads translucides, loin. Ceux qui sont HORS CHAMP
-- (produit scalaire avec la vue sous un seuil) ne sont pas dessines du tout :
-- ni maillage, ni appel. Ce qui coute, c'est la surface translucide a
-- l'ecran, et elle est bornee par le nombre et la taille dans la config.
-- Interrupteurs : evo_ciel_couche_feu (le son), evo_ciel_couche_fumee.
-- ============================================================================

local CV_FEU = CreateClientConVar("evo_ciel_couche_feu", "1", true, false,
    "Son du feu de l'ambiance Ciel en flammes")
local CV_FUMEE = CreateClientConVar("evo_ciel_couche_fumee", "1", true, false,
    "Fumee dans le ciel de l'ambiance Ciel en flammes")

-- ── Le son ──────────────────────────────────────────────────────────────────
local _boucles = nil    -- { { patch = CSoundPatch, volume = part }, ... }
local _nomFeu = nil     -- l'ambiance dont viennent les boucles en cours
local _prochainVolume = 0

local function Eteindre()
    if _boucles then
        for _, b in ipairs(_boucles) do b.patch:Stop() end
    end
    _boucles, _nomFeu = nil, nil
end

local function Allumer(F, sNom)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    _boucles = {}
    for _, b in ipairs(F.boucles or {}) do
        local p = CreateSound(ply, b.son)
        if p then
            -- A zero : c'est ChangeVolume qui monte, avec la montee de l'ambiance.
            p:PlayEx(0, b.ton or 100)
            _boucles[#_boucles + 1] = { patch = p, volume = b.volume or 1 }
        end
    end
    _nomFeu = sNom
end

-- `sons` (30/09/2026) : les memes boucles pour n'importe quelle ambiance (les
-- grillons de la nuit, le vent de la tempete, la pluie de l'orage). `feu`
-- reste le nom historique du Ciel en flammes, meme mecanique.
hook.Add("Think", "EVO_Ciel::Feu", function()
    local t = EVO_CIEL.Vue()
    local F = t and (t.feu or t.sons)
    if not F or not CV_FEU:GetBool() then
        if _boucles then Eteindre() end
        return
    end
    local sNom = tostring(t.label or "")
    if _nomFeu ~= sNom then
        Eteindre()
        Allumer(F, sNom)
        if not _boucles then return end
    end
    local now = RealTime()
    if now < _prochainVolume then return end
    _prochainVolume = now + 0.2
    local v = (F.volume or 0.25) * EVO_CIEL.Facteur(t)
    for _, b in ipairs(_boucles) do
        b.patch:ChangeVolume(math.Clamp(v * b.volume, 0, 1), 0.4)
    end
end)

-- ── La fumee ────────────────────────────────────────────────────────────────
-- Le sprite de fumee du jeu (le VMT d'origine est un UnlitGeneric translucide a
-- couleur de sommet) sur un materiau a nous, pour y ajouter $nofog.
local MAT_FUMEE = CreateMaterial("evo_ciel_fumee", "UnlitGeneric", {
    ["$basetexture"] = "particle/smokesprites0001",
    ["$translucent"] = "1",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
    ["$nofog"] = "1",
    ["$nocull"] = "1",
})

-- Le meme hachage que les eclairs : un nombre stable par index.
local function AleaDe(n)
    local x = math.sin(n * 12.9898) * 43758.5453
    return x - math.floor(x)
end

-- Reutilises a chaque image, pour ne rien allouer.
local _couleur = Color(0, 0, 0, 0)

hook.Add("PostDrawSkyBox", "EVO_Ciel::Fumee", function()
    if not CV_FUMEE:GetBool() then return end
    local t = EVO_CIEL.Vue()
    local S = t and t.fumee
    if not S then return end
    local f = EVO_CIEL.Facteur(t)
    if f <= 0.02 then return end
    if MAT_FUMEE:IsError() then return end

    local oeil = EyePos()
    -- Sous ce seuil, le quad est derriere ou sur le cote : on ne le construit
    -- meme pas. 0.3 laisse de la marge aux grands champs de vision et aux quads
    -- larges qui debordent dans le champ par un bord.
    local avant = EyeAngles():Forward()
    local d = S.distance or 11000
    local c = S.couleur or color_black
    local alpha = (S.alpha or 175) * f
    local tps = CurTime()
    local taille = S.taille or {}
    local tMin, tMax = taille[1] or 1500, taille[2] or 2800
    _couleur.r, _couleur.g, _couleur.b = c.r, c.g, c.b

    render.SetMaterial(MAT_FUMEE)
    -- Test de profondeur sans ecriture : le monde, dessine apres, passe devant.
    render.OverrideDepthEnable(true, false)

    -- Les nappes : haut dans le ciel, elles derivent avec le vent, chacune a
    -- son rythme, et tournent lentement sur elles-memes.
    for i = 1, S.nappes or 14 do
        local yaw = AleaDe(i) * 360 + tps * (S.derive or 0.35) * (0.6 + AleaDe(i + 0.3) * 0.8)
        local pitch = 12 + AleaDe(i + 0.5) * 30
        -- Angle(pitch, lacet, roulis) : un tangage NEGATIF regarde vers le haut.
        local dir = Angle(-pitch, yaw, 0):Forward()
        if dir:Dot(avant) > 0.3 then
            local w = tMin + AleaDe(i + 0.7) * (tMax - tMin)
            local h = w * (0.55 + AleaDe(i + 0.9) * 0.3)
            local rot = AleaDe(i + 0.4) * 360 + tps * (AleaDe(i + 0.2) > 0.5 and 1.5 or -1.5)
            _couleur.a = alpha * (0.6 + AleaDe(i + 0.8) * 0.4)
            render.DrawQuadEasy(oeil + dir * d, -dir, w, h, _couleur, rot)
        end
    end

    -- Les colonnes : elles montent de l'horizon, la ou ca brule. Plus etroites,
    -- bien plus hautes, le pied a l'horizon, et elles ondulent a peine.
    for i = 1, S.colonnes or 6 do
        local k = 100 + i
        local yaw = AleaDe(k) * 360 + math.sin(tps * 0.15 + i) * 1.2
        local pitch = 3 + AleaDe(k + 0.5) * 5
        local dir = Angle(-pitch, yaw, 0):Forward()
        if dir:Dot(avant) > 0.3 then
            local w = (tMin + AleaDe(k + 0.7) * (tMax - tMin)) * 0.55
            local h = w * 2.6
            local pos = oeil + dir * d
            pos.z = pos.z + h * 0.35
            local rot = 90 + math.sin(tps * 0.25 + i * 2) * 4
            _couleur.a = alpha * 0.85
            render.DrawQuadEasy(pos, -dir, w, h, _couleur, rot)
        end
    end

    render.OverrideDepthEnable(false, false)
end)
