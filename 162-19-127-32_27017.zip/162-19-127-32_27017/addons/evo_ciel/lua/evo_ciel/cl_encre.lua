-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_encre.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - le trait d'encre, et la Garganta.
--
-- POURQUOI CE FICHIER EXISTE : appeler DrawSobel directement donnait un ecran
-- noir. Le sobel de GMod ne SURLIGNE pas les contours, il REMPLACE l'image par
-- sa detection : fond noir, aretes claires. Tel quel c'est un filtre
-- artistique, pas de l'encrage.
--
-- On le detourne : le sobel part dans une cible hors ecran, puis on le
-- SOUSTRAIT de l'image reelle. Les aretes, claires, retirent de la lumiere et
-- deviennent des traits noirs ; le fond, noir, ne retire rien et laisse la
-- scene intacte. La soustraction tient quelle que soit la teinte des aretes,
-- ce qu'une multiplication n'aurait pas fait.
-- ============================================================================

local MAT_SOBEL = Material("pp/sobel")

-- La cible et le materiau qui l'affiche, crees UNE fois. Un GetRenderTarget ou
-- un CreateMaterial par frame fuirait a chaque appel.
local _rt, _w, _h
local MAT_RT = CreateMaterial("evo_ciel_encre_rt", "UnlitGeneric", {
    ["$translucent"] = "1",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
    ["$ignorez"] = "1",
})

-- L'ecran peut changer de taille : la cible doit suivre, sinon le trait sort
-- etire ou tronque apres un passage en fenetre.
local function Cible()
    if _rt and _w == ScrW() and _h == ScrH() then return _rt end
    _w, _h = ScrW(), ScrH()
    _rt = GetRenderTarget("evo_ciel_encre_" .. _w .. "x" .. _h, _w, _h)
    MAT_RT:SetTexture("$basetexture", _rt)
    return _rt
end

function EVO_CIEL.DessinerEncre(nSeuil, nForce)
    local rt = Cible()

    -- La scene d'abord : le sobel travaille sur la texture d'effet, il faut
    -- donc la remplir AVANT de basculer sur notre cible, sinon on filtrerait
    -- une image vide.
    render.CopyRenderTargetToTexture(render.GetScreenEffectTexture())

    render.PushRenderTarget(rt)
        render.Clear(0, 0, 0, 255, true, true)
        MAT_SOBEL:SetTexture("$fbtexture", render.GetScreenEffectTexture())
        MAT_SOBEL:SetFloat("$threshold", nSeuil or 0.11)
        render.SetMaterial(MAT_SOBEL)
        render.DrawScreenQuad()
    render.PopRenderTarget()

    -- Destination MOINS source. L'alpha dose la force du trait : a 255 l'encre
    -- est franche, plus bas elle se fond dans l'image.
    render.OverrideBlend(true, BLEND_SRC_ALPHA, BLEND_ONE, BLENDFUNC_REVERSE_SUBTRACT)
        surface.SetDrawColor(255, 255, 255, math.Clamp(nForce or 255, 0, 255))
        render.SetMaterial(MAT_RT)
        render.DrawScreenQuadEx(0, 0, ScrW(), ScrH())
    render.OverrideBlend(false)
end

-- LA GARGANTA ----------------------------------------------------------------
-- Une FENTE qui s'ouvre dans le ciel, pas un trait qui se ramifie.
--
-- La version precedente partait d'un tronc et lui greffait des branches : ca
-- donnait un arbre, et le user l'a dit tel quel. Une Garganta n'a pas de
-- ramification, c'est une BOUCHE : deux levres dechirees qui s'ecartent sur du
-- noir, tres allongee, et deux fentes fines qui filent aux extremites.
--
-- Ce qui la fait lire comme une dechirure de l'espace plutot qu'une forme :
--   les levres sont en DENTS alternees, pas en bruit doux. Une irregularite
--   aleatoire donne un nuage ; une dent qui rentre puis sort donne du dechire ;
--   l'ecart des levres suit un profil en fuseau qui S'ANNULE aux deux pointes,
--   sinon la fente a des bouts carres et redevient un objet ;
--   les fentes des extremites prolongent la dechirure au lieu de s'en detacher.
--
-- Tout est tire UNE FOIS et garde en cache : le retirer chaque frame ferait
-- grouiller les levres comme du bruit video.
local _garganta = nil

local function ConstruireGarganta(F)
    local n = F.pas or 26
    local haut, bas = {}, {}
    local dent = F.dents or 0.42

    for i = 0, n do
        local u = i / n
        local x = (u - 0.5) * 2
        -- Profil en fuseau : large au centre, nul aux pointes. La puissance 0.7
        -- l'aplatit vers les bords, ce qui allonge la fente au lieu de lui
        -- donner un ventre d'amande.
        local ouv = math.pow(math.max(0, 1 - x * x), 0.7)
        -- Dents ALTERNEES : le signe change a chaque pas, l'amplitude est
        -- tiree. C'est l'alternance qui fait « dechire », pas le hasard seul.
        local s = (i % 2 == 0) and 1 or -1
        local dh = 1 + s * dent * math.random()
        local db = 1 - s * dent * math.random()
        haut[#haut + 1] = { x = x, y = -ouv * dh }
        bas[#bas + 1] = { x = x, y = ouv * db }
    end

    -- Les fentes des extremites : elles PROLONGENT la dechirure, en s'amincissant.
    local fentes = {}
    for _, cote in ipairs({ -1, 1 }) do
        for k = 1, (F.fentes or 2) do
            local pts = {}
            local x, y = cote, 0
            local a = (cote > 0) and 0 or math.pi
            a = a + (math.random() - 0.5) * 0.5
            local m = 6
            for j = 0, m do
                pts[#pts + 1] = { x = x, y = y, w = 1 - j / m }
                a = a + (math.random() - 0.5) * 0.7
                local d = (F.fenteLong or 0.30) / m
                x = x + math.cos(a) * d
                y = y + math.sin(a) * d * 0.5
            end
            fentes[#fentes + 1] = pts
        end
    end

    return { haut = haut, bas = bas, fentes = fentes }
end

-- LE SENS DES SOMMETS EST CRITIQUE : surface.DrawPoly ne dessine QUE les
-- polygones en sens HORAIRE, les autres sont supprimes sans le moindre message.
-- A l'ecran l'axe y descend, donc horaire = haut-gauche, haut-droite,
-- bas-droite, bas-gauche.

-- UN SEUL quad, reutilise pour tous. Ecrire `DrawPoly({ {..},{..},{..},{..} })`
-- alloue CINQ tables a chaque appel, et la Garganta en dessine 254 par frame :
-- 1270 tables par image, plus de 76 000 par seconde a 60 fps. Le ramasse-miettes
-- de Lua passe son temps a nettoyer derriere nous, et ca se voit sur les petites
-- configs. Les sommets sont donc reecrits sur place : zero allocation.
local _q = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }
local function Quad(x1, y1, x2, y2, x3, y3, x4, y4)
    local a, b, c, d = _q[1], _q[2], _q[3], _q[4]
    a.x, a.y = x1, y1
    b.x, b.y = x2, y2
    c.x, c.y = x3, y3
    d.x, d.y = x4, y4
    surface.DrawPoly(_q)
end

local function Fente(haut, bas, nL, nH, col, nGonfle)
    local g = nGonfle or 1
    surface.SetDrawColor(col)
    for i = 1, #haut - 1 do
        local h1, h2, b1, b2 = haut[i], haut[i + 1], bas[i + 1], bas[i]
        Quad(h1.x * nL, h1.y * nH * g,
             h2.x * nL, h2.y * nH * g,
             b1.x * nL, b1.y * nH * g,
             b2.x * nL, b2.y * nH * g)
    end
end

local function Trait(pts, nL, nH, nEp, col)
    surface.SetDrawColor(col)
    for i = 1, #pts - 1 do
        local a, b = pts[i], pts[i + 1]
        local ax, ay, bx, by = a.x * nL, a.y * nH, b.x * nL, b.y * nH
        local dx, dy = bx - ax, by - ay
        local l = math.sqrt(dx * dx + dy * dy)
        if l > 0.01 then
            local nx, ny = -dy / l, dx / l
            local wa, wb = nEp * a.w * 0.5, nEp * b.w * 0.5
            Quad(ax - nx * wa, ay - ny * wa,
                 bx - nx * wb, by - ny * wb,
                 bx + nx * wb, by + ny * wb,
                 ax + nx * wa, ay + ny * wa)
        end
    end
end

local function DessinerGarganta(F)
    if not _garganta then _garganta = ConstruireGarganta(F) end
    local G = _garganta

    local vPos = EyePos() + F.dir:Forward() * 12000
    local aAng = (EyePos() - vPos):Angle()
    aAng:RotateAroundAxis(aAng:Up(), 90)
    aAng:RotateAroundAxis(aAng:Forward(), 90)
    -- Une fente horizontale fait decor, une fente de travers fait accident.
    aAng:RotateAroundAxis(aAng:Forward(), F.inclinaison or -12)

    -- La respiration porte sur l'OUVERTURE seule, pas sur la longueur : une
    -- fente qui s'allonge et se raccourcit glisse dans le ciel, une fente qui
    -- s'ouvre et se referme respire.
    local nP = 1 + math.sin(RealTime() * 0.6) * (F.pulse or 0.07)
    -- La taille vient de EVO_CIEL.Ouverture : soit elle grandit depuis la MEME
    -- date pour tout le monde, soit le staff l'a imposee. Le dessin ne decide
    -- de rien, il applique.
    local g = F.ouverture or 1
    local L, H = (F.longueur or 7800) * g, (F.hauteur or 1500) * nP * g
    local ep = (F.epaisseur or 90) * nP * g

    render.OverrideDepthEnable(true, false)
    cam.Start3D2D(vPos, aAng, 1)
        draw.NoTexture()
        -- Halo en QUATRE paliers, jusqu'a 3.6 fois l'ouverture. Deux paliers
        -- serres donnaient un bord net qui posait la fente SUR le ciel comme un
        -- autocollant ; quatre paliers larges et tres transparents la font
        -- saigner dans le ciel et l'y incrustent. C'est la couche qui coute le
        -- moins et qui change le plus.
        local h = F.halo
        Fente(G.haut, G.bas, L, H, Color(h.r, h.g, h.b, 9), 3.6)
        Fente(G.haut, G.bas, L, H, Color(h.r, h.g, h.b, 15), 2.7)
        Fente(G.haut, G.bas, L, H, Color(h.r, h.g, h.b, 24), 2.0)
        Fente(G.haut, G.bas, L, H, Color(h.r, h.g, h.b, 38), 1.45)
        -- Lisere resserre : plus il deborde, plus il cerne la fente et la
        -- redetache du fond.
        Fente(G.haut, G.bas, L, H, F.lisere, 1.09)
        Fente(G.haut, G.bas, L, H, F.bord, 1.04)
        Fente(G.haut, G.bas, L, H, F.vide, 1.0)
        -- Les fentes des pointes, apres le vide : elles doivent se lire par
        -- dessus le noir, pas disparaitre dedans.
        for _, p in ipairs(G.fentes) do
            Trait(p, L, H, ep * 2.2, Color(F.halo.r, F.halo.g, F.halo.b, 26))
            Trait(p, L, H, ep * 1.4, Color(F.halo.r, F.halo.g, F.halo.b, 48))
            Trait(p, L, H, ep * 0.8, F.lisere)
            Trait(p, L, H, ep * 0.42, F.vide)
        end
    cam.End3D2D()
    render.OverrideDepthEnable(false, false)
end

hook.Add("PostDrawSkyBox", "EVO_Ciel::Fissure", function()
    -- EVO_CIEL.Vue et pas EnCours : la fente doit apparaitre AVEC le reste du
    -- monde, derriere le clin d'oeil, pas une demi-seconde avant lui.
    if EVO_CIEL.Couche and not EVO_CIEL.Couche("faille") then return end
    local t = EVO_CIEL.Vue and EVO_CIEL.Vue()
    if not (t and t.faille) then return end
    -- L'ouverture est portee par l'ambiance, pas par la fente : c'est
    -- l'evenement qui monte en puissance, la fente n'en est qu'une consequence.
    -- PLUS DE FAILLE PERMANENTE (retiree le 25/08, demande user) : la Garganta
    -- redevient un EVENEMENT. Elle n'apparait que si une ambiance a fente est
    -- lancee, comme avant.
    t.faille.ouverture = EVO_CIEL.Ouverture(t)
    DessinerGarganta(t.faille)
end)
