-- "addons\\evo_ciel\\lua\\evo_ciel\\cl_cine.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CIEL - la cinematique d'ouverture de la Garganta.
--
-- LE DEROULE : la camera se pose sur un PLAN de la map qui cadre la faille,
-- trois clignements -- rien, rien, puis elle EST la -- ecran noir avec des
-- « ? » qui glitchent, retour au point de vue du joueur.
--
-- UN PLAN FIXE, PAS UN TOUR DE TETE. La premiere version faisait pivoter la vue
-- depuis les yeux du joueur : selon ou il se trouvait, il voyait un mur, un
-- plafond, ou rien du tout. Une cinematique doit CADRER, donc la camera va se
-- poser la ou le plan est bon, le meme pour tout le monde.
--
-- LES DEUX COUPURES SONT CACHEES, et c'est ce qui evite le hoquet : on part sur
-- une paupiere qui se ferme, la camera saute pendant le noir ; on revient
-- pendant l'ecran noir de fin. Aucun travelling, aucune nausee, et le joueur ne
-- quitte jamais son corps.
--
-- CE QUI EST PARTAGE ET CE QUI NE L'EST PAS : le serveur envoie le TOP DEPART
-- et le nom de l'ambiance, donc tout le monde joue la meme sequence au meme
-- instant sur le meme plan. Le bruit du glitch est tire localement -- deux
-- ecrans qui gresillent differemment ne se remarquent pas, alors qu'un decalage
-- d'une seconde sur le troisieme clin, si.
-- ============================================================================

surface.CreateFont("EVO_Ciel_Glitch", { font = "Bebas Neue", size = 130, weight = 700, antialias = true })

-- Les bornes de chaque phase, en secondes depuis le top depart.
local T_COUPE  = 0.35   -- paupiere fermee : la camera se pose sur le plan
local T_OUVRE  = 1.10   -- on decouvre le cadre, la faille n'y est pas encore
local T_CLIN1  = 1.90
local T_CLIN2  = 2.70
local T_CLIN3  = 3.70
-- L'instant PRECIS ou les paupieres du troisieme clin sont closes. La courbe de
-- Clin ferme sur les 45 premiers pour cent de sa fenetre : c'est donc la, et
-- pas a la fin du clin, que le monde doit basculer.
local T_REVEL  = T_CLIN2 + (T_CLIN3 - T_CLIN2) * 0.45
local T_REGARD = 5.20   -- on la contemple
local T_NOIR   = 8.60   -- ecran noir et « ? »
local T_FIN    = 9.60   -- retour au joueur

local _debut = 0
local _plan = nil       -- { pos, ang } du plan, ou nil
local _revele = false   -- le monde a-t-il deja bascule sur ce tour ?

-- Un tirage LOCAL, et surtout pas math.randomseed. Reseeder le generateur du
-- jeu a chaque frame pendant trois secondes deregle tous les autres addons qui
-- s'en servent au meme moment. Ici on veut du bruit reproductible dans notre
-- coin, pas toucher au reste.
local function Bruit(n, k)
    local x = math.sin(n * 127.1 + k * 311.7) * 43758.5453
    return x - math.floor(x)
end
local function Entre(n, k, a, b)
    return a + math.floor(Bruit(n, k) * (b - a + 1))
end

-- Un clin : renvoie la part de paupiere fermee, de 0 a 1, sur sa fenetre.
local function Clin(dt, t0, t1)
    if dt < t0 or dt > t1 then return 0 end
    local u = (dt - t0) / (t1 - t0)
    -- Ferme vite, rouvre plus lentement : c'est ce rythme-la qui fait un oeil
    -- plutot qu'un rideau.
    if u < 0.45 then return math.pow(u / 0.45, 0.7) end
    return 1 - math.pow((u - 0.45) / 0.55, 1.6)
end

local function EnCours()
    return _debut > 0 and (RealTime() - _debut) < T_FIN
end

-- Lu par cl_ciel : tant que c'est vrai, l'ambiance annoncee par le serveur ne
-- doit PAS etre affichee.
function EVO_CIEL.CineBloque()
    if _debut <= 0 then return false end
    return (RealTime() - _debut) < T_REVEL
end

-- La bascule, declenchee une seule fois par sequence. Dans Think et pas dans le
-- hook de dessin : HUD masque, le monde doit changer quand meme.
hook.Add("Think", "EVO_Ciel::CineRevel", function()
    if _debut <= 0 or _revele then return end
    if (RealTime() - _debut) < T_REVEL then return end
    _revele = true
    if EVO_CIEL.ForcerVue then EVO_CIEL.ForcerVue() end
end)

net.Receive("evo_ciel:cine", function()
    local sNom = net.ReadString()
    _debut = RealTime()
    _plan = nil
    _revele = false
    -- Le plan vient de l'ambiance ANNONCEE par le serveur, pas de celle qui est
    -- affichee : on cadre une faille qui n'est pas encore la, c'est le propos.
    local t = EVO_CIEL.Ambiance(sNom)
    local c = t and t.cinematique
    if istable(c) and c.pos then _plan = c end
end)

-- LA CAMERA ------------------------------------------------------------------
hook.Add("CalcView", "EVO_Ciel::Cine", function(ply, pos, ang, fov)
    if not EnCours() or not _plan then return end

    local dt = RealTime() - _debut
    -- Avant la coupure et apres le retour, on laisse la vue du joueur : les deux
    -- bascules se font paupiere close ou ecran noir, donc invisibles.
    if dt < T_COUPE or dt > T_NOIR then return end

    -- Derive tres lente pendant tout le plan. Une camera parfaitement fixe se
    -- lit comme une capture d'ecran ; quelques degres suffisent a la rendre
    -- vivante sans qu'on remarque le mouvement.
    local u = (dt - T_COUPE) / math.max(0.01, T_NOIR - T_COUPE)
    local a = Angle(_plan.ang.p, _plan.ang.y + u * 3.5, 0)

    return {
        origin = _plan.pos,
        angles = a,
        fov = _plan.fov or 70,
        -- Le joueur est VISIBLE : le plan cadre la faille, mais les personnages
        -- au sol font l'echelle et rappellent que la scene est habitee.
        drawviewer = true,
    }
end)

-- Les commandes sont coupees pendant la sequence : un joueur qui bouge pendant
-- un plan fixe se retrouve ailleurs au retour, sans comprendre pourquoi.
hook.Add("CreateMove", "EVO_Ciel::CineFige", function(cmd)
    if not EnCours() then return end
    cmd:ClearMovement()
    cmd:ClearButtons()
    return true
end)

-- LE VOILE -------------------------------------------------------------------
hook.Add("HUDPaintBackground", "EVO_Ciel::Cine", function()
    if _debut <= 0 then return end
    local dt = RealTime() - _debut
    if dt > T_FIN then _debut = 0 return end

    local w, h = ScrW(), ScrH()

    -- La coupure d'entree, plus les trois clins. Le troisieme decouvre la
    -- faille : cl_ciel l'affiche des que CineBloque tombe a faux, pile a T_CLIN3.
    local f = math.max(
        Clin(dt, 0, T_OUVRE),
        Clin(dt, T_OUVRE, T_CLIN1),
        Clin(dt, T_CLIN1, T_CLIN2),
        Clin(dt, T_CLIN2, T_CLIN3))

    -- L'ecran noir, avec un fondu de chaque cote : un noir qui tombe d'un coup
    -- se lit comme un plantage.
    if dt >= T_REGARD then
        local a
        if dt < T_REGARD + 0.35 then
            a = (dt - T_REGARD) / 0.35
        elseif dt < T_NOIR then
            a = 1
        else
            a = 1 - math.Clamp((dt - T_NOIR) / (T_FIN - T_NOIR), 0, 1)
        end
        surface.SetDrawColor(0, 0, 0, a * 255)
        surface.DrawRect(0, 0, w, h)

        -- LES « ? ». Trois copies decalees en rouge, cyan et blanc : c'est la
        -- separation des canaux qui fait « signal casse », pas le tremblement.
        if a > 0.5 then
            -- 14 sauts par seconde : en dessous ca clignote, au-dessus l'oeil ne
            -- suit plus et la ligne devient une bouillie grise.
            local pas = math.floor(dt * 14)
            local n = 9 + Entre(pas, 1, 0, 10)
            local s = string.rep("?", n)
            local jx, jy = Entre(pas, 2, -16, 16), Entre(pas, 3, -7, 7)
            surface.SetFont("EVO_Ciel_Glitch")
            local tw, th = surface.GetTextSize(s)
            local x, y = w * 0.5 - tw * 0.5 + jx, h * 0.5 - th * 0.5 + jy
            local d = Entre(pas, 4, 4, 13)
            draw.SimpleText(s, "EVO_Ciel_Glitch", x - d, y, Color(220, 30, 40, 200))
            draw.SimpleText(s, "EVO_Ciel_Glitch", x + d, y, Color(40, 200, 220, 200))
            draw.SimpleText(s, "EVO_Ciel_Glitch", x, y, Color(236, 236, 238, 245))

            -- Bandes de dechirure : quelques lignes decalees, comme une image
            -- qui perd la synchro.
            for i = 1, 3 do
                local by = Entre(pas, 10 + i, 0, h)
                local bh = Entre(pas, 20 + i, 2, 9)
                surface.SetDrawColor(255, 255, 255, Entre(pas, 30 + i, 10, 26))
                surface.DrawRect(Entre(pas, 40 + i, -40, 40), by, w, bh)
            end
        end
    end

    if f > 0 then
        local n = math.ceil(h * 0.5 * f)
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(0, 0, w, n)
        surface.DrawRect(0, h - n, w, n)
    end
end)
