-- "addons\\evo_sam_theme\\lua\\autorun\\client\\cl_evo_sam_theme.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- EVO SAM THEME — reskin DA EVO du menu admin SAM (client)
-- ============================================================
-- Applique la charte EVO (carte sombre #0E0E11, accent rouge #cf444e, coins
-- arrondis, liseré accent, police Bebas Neue) SANS éditer le coeur de SAM :
-- on override la table de thème sui (sam.SUI) + le Paint de la Frame, exactement
-- comme SAM le fait lui-même dans sam/menu/cl_init.lua. => survit aux updates SAM.
-- Doit tourner APRÈS le chargement du menu SAM (sam.SUI créé) -> InitPostEntity + retry.
-- ============================================================

local ACCENT   = Color(207, 68, 78)  -- #cf444e
local ACCENT_S = "#cf444e"

-- Palette DA EVO (carte sombre)
local BG0      = "#0E0E11"  -- frame / fond principal
local BG1      = "#141418"  -- panneaux, menus déroulants, property sheet
local BG_RAIL  = "#0B0B0E"  -- rail d'onglets à gauche
local ROW      = "#1C1C21"
local ROW_H    = "#28282D"
local TXT      = "#EEEFF3"
local TXT_DIM  = "#969AA2"
local MUTED    = "#6E717A"
local LINE     = "#1C1C22"
local WHITE    = "#FFFFFF"

-- Police EVO (Bebas Neue = la police de titres de toutes les UIs EVO). Taille
-- mise à l'échelle comme le reste du menu (sui scale = ScrH/900).
local function FS(px) return math.max(1, math.floor(px * (ScrH() / 900) + 0.5)) end

local function ApplyEVOTheme()
	if not (sam and sam.SUI and sam.SUI.AddToTheme and sam.SUI.SetTheme) then return false end

	local SUI = sam.SUI
	local GetColor = SUI.GetColor

	-- ── 1) COULEURS : override complet du thème "Dark" -> DA EVO ──────────────
	-- (AddToTheme fusionne : seules les clés fournies changent, le reste garde SAM.)
	SUI.AddToTheme("Dark", {
		-- Fenêtre
		frame       = BG0,
		frame_blur  = false,
		header      = BG0,
		title       = TXT,
		line        = LINE,

		close       = MUTED,
		close_hover = ACCENT_S,
		close_press = Color(255, 255, 255, 30),

		-- Boutons pleins (action principale = rouge, comme SAM les faisait bleus)
		button               = ACCENT,
		button_text          = WHITE,
		button_hover         = Color(255, 255, 255, 26),
		button_click         = Color(255, 255, 255, 55),
		button_disabled      = ROW_H,
		button_disabled_text = MUTED,

		-- Boutons "ghost" (items de liste : teinte rouge discrète au survol/sélection)
		button2_hover    = ColorAlpha(ACCENT, 14),
		button2_selected = ColorAlpha(ACCENT, 26),

		on_sheet       = Color(20, 20, 24, 200),
		on_sheet_hover = ColorAlpha(ACCENT, 22),

		-- Scroll
		scroll               = ColorAlpha(ACCENT, 90),
		scroll_grip          = ACCENT,
		scroll_panel         = BG0,
		scroll_panel_outline = false,

		-- Champs texte
		text_entry_bg        = ROW,
		text_entry_bar_color = Color(0, 0, 0, 0),
		text_entry           = TXT,
		text_entry_2         = TXT_DIM,
		text_entry_3         = ACCENT,

		-- Onglets (property sheet, utilisé par la sous-config)
		property_sheet_bg         = BG1,
		property_sheet_tab        = TXT_DIM,
		property_sheet_tab_click  = Color(255, 255, 255, 30),
		property_sheet_tab_active = ACCENT,

		-- Toggles / sliders -> accent
		toggle_button               = MUTED,
		toggle_button_switch        = TXT,
		toggle_button_active        = ColorAlpha(ACCENT, 90),
		toggle_button_switch_active = ACCENT,
		slider_knob    = ACCENT,
		slider_track   = ColorAlpha(ACCENT, 65),
		slider_hover   = ColorAlpha(ACCENT, 14),
		slider_pressed = ColorAlpha(ACCENT, 30),

		-- Query box (confirmations)
		query_box_bg          = BG0,
		query_box_cancel      = ColorAlpha(ACCENT, 30),
		query_box_cancel_text = ACCENT_S,

		-- Menus déroulants (comboboxes : dont giveitem/getitem)
		menu                   = BG1,
		menu_option            = BG1,
		menu_option_text       = TXT_DIM,
		menu_option_hover      = ACCENT_S,
		menu_option_hover_text = WHITE,
		menu_spacer            = LINE,

		-- Rail d'onglets à gauche (kill du bleu #34a1e0 -> accent rouge)
		column_sheet                = BG0,
		column_sheet_bar            = BG_RAIL,
		column_sheet_tab            = BG_RAIL,
		column_sheet_tab_hover      = ROW,
		column_sheet_tab_active     = ROW,
		column_sheet_tab_icon       = MUTED,
		column_sheet_tab_icon_hover = TXT,
		column_sheet_tab_icon_active = ACCENT_S,

		-- Catégories repliables (sous-config)
		collapse_category_header             = BG1,
		collapse_category_header_hover       = "#1A1A1F",
		collapse_category_header_active      = ROW,
		collapse_category_header_text        = TXT_DIM,
		collapse_category_header_text_hover  = "#DCDCDC",
		collapse_category_header_text_active = ACCENT_S,
		collapse_category_item               = ROW,
		collapse_category_item_hover         = ROW_H,
		collapse_category_item_active        = "#303036",
		collapse_category_item_text          = TXT_DIM,
		collapse_category_item_text_hover    = "#DCDCDC",
		collapse_category_item_text_active   = WHITE,

		-- Clés ajoutées par SAM (liste joueurs / actions / page switch)
		menu_tabs_title  = TXT,
		page_switch_bg   = BG1,

		player_list_titles    = TXT,
		player_list_names     = "#EEEEEE",
		player_list_names_2   = ACCENT_S,
		player_list_data      = "#E8E8E8",
		player_list_rank      = ACCENT_S,
		player_list_console   = "#00C853",
		player_list_rank_text = "#0E0E11",
		player_list_steamid   = MUTED,

		actions_button            = Color(0, 0, 0, 0),
		actions_button_hover      = ColorAlpha(ACCENT, 55),
		actions_button_icon       = "#AAAAAA",
		actions_button_icon_hover = ACCENT_S,
	})
	SUI.SetTheme("Dark")  -- recompute + "SAM.ThemeChanged" -> panneaux live recolorés

	-- ── 2) FORME : Frame arrondie + ombre + liseré accent (override de Paint) ──
	if SUI.panels and SUI.panels.Frame then
		function SUI.panels.Frame:Paint(w, h)
			if RNDX and RNDX.DrawShadows then
				RNDX.DrawShadows(10, 0, 0, w, h, Color(0, 0, 0, 190), 22, 34)
			end
			draw.RoundedBox(10, 0, 0, w, h, GetColor("frame"))
		end

		function SUI.panels.Frame:HeaderPaint(w, h)
			draw.RoundedBoxEx(10, 0, 0, w, h, GetColor("header"), true, true, false, false)
			draw.RoundedBoxEx(10, 0, 0, w, 3, ACCENT, true, true, false, false) -- liseré accent
			draw.RoundedBox(0, 0, h - 1, w, 1, GetColor("line"))
		end
	end

	-- ── FR : masquer l'indicateur de langue clavier ("FR") dans TOUS les champs texte SAM
	if SUI.panels and SUI.panels.TextEntry and not SUI.panels.TextEntry._evoNoLangID then
		SUI.panels.TextEntry._evoNoLangID = true
		local origInit = SUI.panels.TextEntry.Init
		function SUI.panels.TextEntry:Init(...)
			if origInit then origInit(self, ...) end
			if self.SetDrawLanguageID then self:SetDrawLanguageID(false) end
		end
	end

	-- ── 3) POLICE : titres d'onglets en Bebas Neue (identité EVO) ─────────────
	surface.CreateFont("EVO_SAM_TabTitle", {
		font = "Bebas Neue", size = FS(30), weight = 400, extended = true, antialias = true,
	})
	SAM_TAB_TITLE_FONT = "EVO_SAM_TabTitle"

	return true
end

-- SAM charge son menu pendant le chargement Lua (avant InitPostEntity), donc à
-- InitPostEntity sam.SUI existe. Retry de sécurité si SAM charge tard.
hook.Add("InitPostEntity", "EVO_SAM_Theme_Apply", function()
	if ApplyEVOTheme() then return end
	local n = 0
	timer.Create("EVO_SAM_Theme_Retry", 1, 15, function()
		n = n + 1
		if ApplyEVOTheme() then timer.Remove("EVO_SAM_Theme_Retry") end
	end)
end)

-- Rechargement à chaud (autorefresh / lua_reload) : applique aussi tout de suite.
if sam and sam.SUI then ApplyEVOTheme() end
