-- "addons\\evo_note\\lua\\autorun\\sh_evo_note_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO NOTE — loader. Papier (Urahara Shop, 50 ¥) sur lequel on écrit une note
-- via une UI ; la note devient un item unique : lisible, montrable aux joueurs
-- proches, donnable, droppable/échangeable (systèmes natifs de l'inventaire).
-- ============================================================================
EVO_NOTE = EVO_NOTE or {}

if SERVER then
	AddCSLuaFile("evo_note/sh_config.lua")
	AddCSLuaFile("evo_note/cl_note.lua")
	include("evo_note/sh_config.lua")
	include("evo_note/sv_note.lua")
else
	include("evo_note/sh_config.lua")
	include("evo_note/cl_note.lua")
end
