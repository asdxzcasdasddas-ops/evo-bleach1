-- "addons\\evo_note\\lua\\evo_note\\cl_note.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO NOTE — client. Defs des notes (items dynamiques), UI d'ÉCRITURE (depuis
-- le papier), UI de LECTURE (Utiliser la note : montrer / donner), et viewer
-- "on te montre une note". DA Atelier : plaque coins coupés, accent #cf444e.
-- ============================================================================
local N = EVO_NOTE

N.Defs = N.Defs or {}   -- noteId -> { id, title, ownerName, createdAt }

-- ── Palette / helpers DA ────────────────────────────────────────────────────
local COL_CARD   = Color(13, 14, 17, 250)
local COL_TITLE  = Color(238, 239, 243)
local COL_MUTED  = Color(150, 154, 162)
local COL_DIM    = Color(106, 109, 118)
local COL_ACCENT = Color(207, 68, 78)
local COL_FIELD  = Color(8, 8, 10, 230)

local function R(v)
	if gRespY then return gRespY(v) end
	return math.floor(v * (ScrH() / 1080))
end
local function plate(x, y, w, h, col, rad)
	if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(x, y, w, h, col, rad or R(12))
	else draw.RoundedBox(8, x, y, w, h, col) end
end
local function titleSlash(txt, x, y, font)
	draw.SimpleText(txt, font, x, y, COL_TITLE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont(font)
	local tw, th = surface.GetTextSize(txt)
	if EVO_UI and EVO_UI.Ink and EVO_UI.TexSlash then
		EVO_UI.Ink(EVO_UI.TexSlash, x - R(3), y + th * 0.28, tw * 1.1, R(9), ColorAlpha(COL_ACCENT, 245))
	else
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(x, y + th * 0.34, tw, math.max(2, R(2)))
	end
end

-- Backdrop plein écran standard (flou + voile, Échap ferme, clic hors carte ferme).
local function makeBackdrop()
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH()) frame:SetPos(0, 0)
	frame:SetTitle("") frame:ShowCloseButton(false) frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false) frame:MakePopup()
	openedFrame = frame
	frame.OnRemove = function(s) if openedFrame == s then openedFrame = nil end end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.Paint = function(s, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR) end
		surface.SetDrawColor(5, 5, 7, 210) surface.DrawRect(0, 0, w, h)
	end
	frame.OnMousePressed = function(s) s:Remove() end
	return frame
end

local function mkBtn(parent, label, fill, fn)
	local b = vgui.Create("DButton", parent)
	b:SetText("") b:SetCursor("hand")
	b.Paint = function(s, w, h)
		local hov = s:IsHovered()
		if fill then
			if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(COL_ACCENT, hov and 255 or 220))
			else draw.RoundedBox(6, 0, 0, w, h, COL_ACCENT) end
		else
			if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, ColorAlpha(color_white, hov and 22 or 10))
			else draw.RoundedBox(6, 0, 0, w, h, Color(255, 255, 255, hov and 22 or 10)) end
		end
		draw.SimpleText(label, "Bebas Neue:26", w / 2, h / 2, fill and color_white or (hov and COL_TITLE or COL_MUTED), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fn
	return b
end

-- ── UI D'ÉCRITURE (Utiliser un papier) ──────────────────────────────────────
function N.OpenWrite()
	if IsValid(N._writeUI) then N._writeUI:Remove() end
	local frame = makeBackdrop()
	N._writeUI = frame

	local W, H = R(620), R(600)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		titleSlash("ÉCRIRE UNE NOTE", R(26), R(34), "Bebas Neue:42")
		draw.SimpleText("TITRE", "Bebas Neue:22", R(26), R(78), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("TEXTE", "Bebas Neue:22", R(26), R(158), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local x = vgui.Create("DButton", card)
	x:SetText("") x:SetSize(R(30), R(30)) x:SetPos(W - R(44), R(18)) x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() frame:Remove() end

	local titleE = vgui.Create("DTextEntry", card)
	titleE:SetPos(R(24), R(102)) titleE:SetSize(W - R(48), R(40))
	titleE:SetFont("Avenir Next World:20") titleE:SetDrawLanguageID(false)
	titleE:SetTextColor(COL_TITLE) titleE:SetCursorColor(COL_TITLE) titleE:SetPaintBackground(false)
	titleE:SetUpdateOnType(true)
	titleE.Paint = function(s, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Titre de la note…", "Avenir Next World:20", R(10), h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	titleE.OnValueChange = function(s, v)
		if #v > N.MaxTitleLen then s:SetText(string.sub(v, 1, N.MaxTitleLen)) s:SetCaretPos(N.MaxTitleLen) end
	end

	local textE = vgui.Create("DTextEntry", card)
	textE:SetPos(R(24), R(182)) textE:SetSize(W - R(48), H - R(182) - R(164))
	textE:SetFont("Avenir Next World:20") textE:SetDrawLanguageID(false)
	textE:SetMultiline(true) textE:SetUpdateOnType(true)
	textE:SetTextColor(COL_TITLE) textE:SetCursorColor(COL_TITLE) textE:SetPaintBackground(false)
	textE.Paint = function(s, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Écris ta note ici…", "Avenir Next World:20", R(10), R(8), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local counter = vgui.Create("DLabel", card)
	counter:SetPos(R(24), H - R(112)) counter:SetSize(W - R(48), R(18))
	counter:SetFont("Avenir Next World:16") counter:SetTextColor(COL_DIM) counter:SetContentAlignment(6)
	counter:SetText("0/" .. N.MaxTextLen)
	textE.OnValueChange = function(s, v)
		if #v > N.MaxTextLen then s:SetText(string.sub(v, 1, N.MaxTextLen)) s:SetCaretPos(N.MaxTextLen) v = s:GetText() end
		counter:SetText(#v .. "/" .. N.MaxTextLen)
	end

	-- ── Feuilles multiples : navigation + ajout (la note part avec toutes ses feuilles)
	local pages, cur = { "" }, 1
	local pageLbl
	local function gotoPage(i)
		pages[cur] = textE:GetValue() or ""
		cur = math.Clamp(i, 1, #pages)
		textE:SetText(pages[cur])
		counter:SetText(#pages[cur] .. "/" .. N.MaxTextLen)
		pageLbl:SetText("Feuille " .. cur .. " / " .. #pages)
	end
	local barY = H - R(156)
	local prev = mkBtn(card, "<", false, function() gotoPage(cur - 1) end)
	prev:SetPos(R(24), barY) prev:SetSize(R(38), R(34))
	pageLbl = vgui.Create("DLabel", card)
	pageLbl:SetPos(R(66), barY) pageLbl:SetSize(R(130), R(34))
	pageLbl:SetFont("Avenir Next World:17") pageLbl:SetTextColor(COL_MUTED) pageLbl:SetContentAlignment(5)
	pageLbl:SetText("Feuille 1 / 1")
	local nxt = mkBtn(card, ">", false, function() gotoPage(cur + 1) end)
	nxt:SetPos(R(200), barY) nxt:SetSize(R(38), R(34))
	local add = mkBtn(card, "+ FEUILLE", false, function()
		if #pages >= N.MaxPages then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Maximum " .. N.MaxPages .. " feuilles.", NOTIFY_ERROR, 3) end
			return
		end
		pages[cur] = textE:GetValue() or ""
		pages[#pages + 1] = ""
		gotoPage(#pages)
	end)
	add:SetPos(R(246), barY) add:SetSize(W - R(246) - R(24), R(34))

	local send = mkBtn(card, "ÉCRIRE LA NOTE (consomme le papier)", true, function()
		pages[cur] = textE:GetValue() or ""
		local any = false
		for _, p in ipairs(pages) do if string.Trim(p) ~= "" then any = true break end end
		if not any then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("La note est vide.", NOTIFY_ERROR, 3) end
			return
		end
		local n = math.min(#pages, N.MaxPages)
		net.Start("EVO:Note:Create")
			net.WriteString(titleE:GetValue() or "")
			net.WriteUInt(n, 4)
			for i = 1, n do net.WriteString(pages[i]) end
		net.SendToServer()
		frame:Remove()
	end)
	send:SetPos(R(24), H - R(84)) send:SetSize(W - R(48), R(46))
end

-- ── VIEWER (lecture) — partagé entre "je lis ma note" et "on me la montre" ──
-- opts : { noteId = <id> } -> boutons MONTRER / DONNER (détenteur) ;
--        { shower = "Nom" } -> bandeau "X te montre une note" (lecture seule).
local function OpenViewer(title, author, createdAt, text, opts)
	opts = opts or {}
	if IsValid(N._viewUI) then N._viewUI:Remove() end
	local frame = makeBackdrop()
	N._viewUI = frame

	local W, H = R(620), R(600)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	local sWhen = os.date("%d/%m à %H:%M", createdAt or os.time())
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		local y = R(34)
		if opts.shower then
			draw.SimpleText(opts.shower .. " te montre une note :", "Avenir Next World:18", R(26), R(14), COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			y = R(52)
		end
		titleSlash(title ~= "" and title or "NOTE", R(26), y, "Bebas Neue:42")
		draw.SimpleText("Écrite par " .. (author or "?") .. " · " .. sWhen, "Avenir Next World:16", R(26), y + R(30), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local x = vgui.Create("DButton", card)
	x:SetText("") x:SetSize(R(30), R(30)) x:SetPos(W - R(44), R(18)) x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() frame:Remove() end

	local hasBtns = opts.noteId ~= nil
	local pages = N.SplitPages(text)
	local hasPager = #pages > 1 or hasBtns -- pagination visible aussi pour le détenteur (compteur de feuilles)
	local topY = opts.shower and R(126) or R(108)
	local scroll = vgui.Create("DScrollPanel", card)
	scroll:SetPos(R(24), topY)
	scroll:SetSize(W - R(48), H - topY - (hasBtns and R(126) or (hasPager and R(66) or R(24))))
	scroll.Paint = function(_, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
	end
	local vbar = scroll:GetVBar()
	if IsValid(vbar) then
		vbar:SetWide(R(5)) vbar:SetHideButtons(true)
		vbar.Paint = function() end
		vbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(146, 152, 161, 90) surface.DrawRect(0, 0, w, h) end
	end
	local lbl = vgui.Create("DLabel", scroll)
	lbl:Dock(TOP) lbl:DockMargin(R(12), R(10), R(12), R(10))
	lbl:SetFont("Avenir Next World:20") lbl:SetTextColor(COL_TITLE)
	lbl:SetWrap(true) lbl:SetAutoStretchVertical(true)
	lbl:SetText(pages[1] or "")

	-- ── Navigation entre feuilles ───────────────────────────────────────────
	local cur = 1
	if hasPager then
		local barY = H - (hasBtns and R(118) or R(58))
		local pageLbl
		local function gotoPage(i)
			cur = math.Clamp(i, 1, #pages)
			lbl:SetText(pages[cur] or "")
			pageLbl:SetText("Feuille " .. cur .. " / " .. #pages)
			if IsValid(vbar) then vbar:SetScroll(0) end
		end
		local prev = mkBtn(card, "<", false, function() gotoPage(cur - 1) end)
		prev:SetPos(R(24), barY) prev:SetSize(R(38), R(32))
		pageLbl = vgui.Create("DLabel", card)
		pageLbl:SetPos(R(66), barY) pageLbl:SetSize(R(130), R(32))
		pageLbl:SetFont("Avenir Next World:17") pageLbl:SetTextColor(COL_MUTED) pageLbl:SetContentAlignment(5)
		pageLbl:SetText("Feuille 1 / " .. #pages)
		local nxt = mkBtn(card, ">", false, function() gotoPage(cur + 1) end)
		nxt:SetPos(R(200), barY) nxt:SetSize(R(38), R(32))
	end

	if hasBtns then
		local bw = (W - R(48) - R(16)) / 3
		local show = mkBtn(card, "MONTRER", false, function()
			net.Start("EVO:Note:ShowNearby") net.WriteString(opts.noteId) net.SendToServer()
		end)
		show:SetPos(R(24), H - R(72)) show:SetSize(bw, R(44))
		local give = mkBtn(card, "DONNER", true, function()
			net.Start("EVO:Note:GiveNearby") net.WriteString(opts.noteId) net.SendToServer()
			frame:Remove()
		end)
		give:SetPos(R(24) + bw + R(8), H - R(72)) give:SetSize(bw, R(44))
		local addP = mkBtn(card, "+ FEUILLE", false, function()
			if #pages >= N.MaxPages then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Bloc-notes plein (" .. N.MaxPages .. " feuilles).", NOTIFY_ERROR, 3) end
				return
			end
			frame:Remove()
			N.OpenAddPage(opts.noteId)
		end)
		addP:SetPos(R(24) + (bw + R(8)) * 2, H - R(72)) addP:SetSize(bw, R(44))
	end
end

-- ── Ajouter une feuille à un bloc-notes détenu (consomme UN papier) ─────────
function N.OpenAddPage(id)
	if IsValid(N._writeUI) then N._writeUI:Remove() end
	local frame = makeBackdrop()
	N._writeUI = frame

	local W, H = R(620), R(440)
	local card = vgui.Create("DPanel", frame)
	card:SetSize(W, H) card:Center()
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(_, w, h)
		plate(0, 0, w, h, COL_CARD, R(14))
		titleSlash("AJOUTER UNE FEUILLE", R(26), R(34), "Bebas Neue:42")
		draw.SimpleText("Consomme un papier (Urahara Shop).", "Avenir Next World:16", R(26), R(62), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local x = vgui.Create("DButton", card)
	x:SetText("") x:SetSize(R(30), R(30)) x:SetPos(W - R(44), R(18)) x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = function() frame:Remove() end

	local textE = vgui.Create("DTextEntry", card)
	textE:SetPos(R(24), R(92)) textE:SetSize(W - R(48), H - R(92) - R(120))
	textE:SetFont("Avenir Next World:20") textE:SetDrawLanguageID(false)
	textE:SetMultiline(true) textE:SetUpdateOnType(true)
	textE:SetTextColor(COL_TITLE) textE:SetCursorColor(COL_TITLE) textE:SetPaintBackground(false)
	textE.Paint = function(s, w, h)
		if RNDX and RNDX.Draw then RNDX.Draw(R(7), 0, 0, w, h, COL_FIELD) else draw.RoundedBox(6, 0, 0, w, h, COL_FIELD) end
		s:DrawTextEntryText(COL_TITLE, COL_ACCENT, COL_TITLE)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Écris la nouvelle feuille ici…", "Avenir Next World:20", R(10), R(8), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local counter = vgui.Create("DLabel", card)
	counter:SetPos(R(24), H - R(112)) counter:SetSize(W - R(48), R(18))
	counter:SetFont("Avenir Next World:16") counter:SetTextColor(COL_DIM) counter:SetContentAlignment(6)
	counter:SetText("0/" .. N.MaxTextLen)
	textE.OnValueChange = function(s, v)
		if #v > N.MaxTextLen then s:SetText(string.sub(v, 1, N.MaxTextLen)) s:SetCaretPos(N.MaxTextLen) v = s:GetText() end
		counter:SetText(#v .. "/" .. N.MaxTextLen)
	end

	local send = mkBtn(card, "AJOUTER LA FEUILLE (consomme un papier)", true, function()
		local txt = textE:GetValue() or ""
		if string.Trim(txt) == "" then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("La feuille est vide.", NOTIFY_ERROR, 3) end
			return
		end
		net.Start("EVO:Note:AddPage")
			net.WriteString(id)
			net.WriteString(txt)
		net.SendToServer()
		frame:Remove()
		-- Rouvre la note : AddPage puis RequestText partent dans l'ordre -> le texte
		-- reçu inclut la nouvelle feuille (ou l'ancienne version si le serveur a refusé,
		-- avec la notif du refus).
		N.OpenRead(id)
	end)
	send:SetPos(R(24), H - R(84)) send:SetSize(W - R(48), R(46))
end

-- ── Lecture : Utiliser la note -> demande le texte puis ouvre le viewer ─────
function N.OpenRead(id)
	-- Filet : DefAll differe / droppe → re-demande les defs avant lecture.
	if id and not (N.Defs and N.Defs[id]) then
		net.Start("EVO:Note:RequestDefs")
		net.SendToServer()
	end
	N._pendingRead = id
	net.Start("EVO:Note:RequestText") net.WriteString(id) net.SendToServer()
end

net.Receive("EVO:Note:Text", function()
	local id     = net.ReadString()
	local title  = net.ReadString()
	local text   = net.ReadString()
	local author = net.ReadString()
	local at     = net.ReadUInt(32)
	if N._pendingRead ~= id then return end
	N._pendingRead = nil
	OpenViewer(title, author, at, text, { noteId = id })
end)

net.Receive("EVO:Note:Shown", function()
	local shower = net.ReadString()
	local title  = net.ReadString()
	local text   = net.ReadString()
	local author = net.ReadString()
	local at     = net.ReadUInt(32)
	OpenViewer(title, author, at, text, { shower = shower })
end)

-- ── Defs des notes -> items d'inventaire CLIENT (nom + Utiliser = lire) ─────
local function installDef(d)
	N.Defs[d.id] = d
end
local function readDef()
	return { id = net.ReadString(), title = net.ReadString(), ownerName = net.ReadString(), createdAt = net.ReadUInt(32) }
end
local function removeDef(id)
	N.Defs[id] = nil
end

net.Receive("EVO:Note:DefAdd", function() installDef(readDef()) end)
net.Receive("EVO:Note:DefRemove", function() removeDef(net.ReadString()) end)
net.Receive("EVO:Note:DefAll", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do installDef(readDef()) end
end)

-- Papier vierge : enregistrement runtime côté client aussi (l'inventaire ré-assigne ITEMS).
timer.Create("EVO_Note::EnsurePaperCL", 2, 0, function()
	if N.RegisterPaperItem() and N.RegisterWrittenItem() then timer.Remove("EVO_Note::EnsurePaperCL") end
end)
N.RegisterPaperItem()
N.RegisterWrittenItem()
