-- "addons\\evo_note\\lua\\evo_note\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO NOTE — config partagée.
-- ============================================================================
EVO_NOTE = EVO_NOTE or {}
local N = EVO_NOTE

N.Model          = "models/evo/props/items/evo_dsddsc57kdezx96gbj/evo_dsddsc57kdezx96gbj.mdl"
-- Icône 2D de repli + réglage de l'aperçu 3D en case : model_lift REMONTE le modèle
-- (fraction de sa taille ; demande user 07/23 "légèrement trop bas" -> +0.15).
N.Icon           = "a8pi8v5e07z97o/iwjnbnd6ira9.png"
N.ModelLift      = 0.15
N.PaperItemId    = "papier_note"  -- feuille vierge (Urahara Shop, 50 ¥)
N.WrittenItemId  = "evo_note"     -- exemplaire écrit (une row inventory par copie)
N.ItemPrefix     = "evo_note_"    -- legacy item_id (migration boot)
N.MaxTitleLen    = 40
N.MaxTextLen     = 1200           -- longueur max PAR FEUILLE
N.MaxPages       = 10             -- feuilles max d'un bloc-notes (1 papier = 1 feuille ajoutée)
-- Séparateur de feuilles DANS note_text (même colonne BDD -> les notes déjà en
-- circulation = 1 feuille, rien à migrer). Caractère de CONTRÔLE : cleanText le
-- retire de toute saisie client, donc infalsifiable.
N.PageSep        = "\30"
N.GiveRadius     = 150            -- donner : au joueur le plus proche dans ce rayon
N.ShowRadius     = 250            -- montrer : à tous les joueurs dans ce rayon
N.CreateCooldown = 3
N.PurgeDays      = 30             -- purge BDD des notes plus vieilles que N jours (boot)

function N.NoteItemId(id) return N.ItemPrefix .. id end

function N.SplitPages(text)
	local pages = string.Explode(N.PageSep, text or "")
	if #pages == 0 then pages[1] = "" end
	return pages
end

-- Item PAPIER enregistré au RUNTIME (même pattern qu'evo_carte : l'inventaire RÉ-ASSIGNE
-- la table ITEMS à son include -> un enregistrement trop tôt serait écrasé). Appelé en
-- boucle courte par sv_note/cl_note jusqu'à ce qu'ITEMS existe.
function N.RegisterPaperItem()
	if not istable(ITEMS) then return false end
	ITEMS[N.PaperItemId] = {
		name         = "Papier",
		description  = "Une feuille de papier vierge.\nClic droit > Utiliser pour écrire une note.",
		category     = "object",
		rarity       = "common",
		icon         = N.Icon,       -- repli 2D (le model_path prime pour l'aperçu de case)
		model_path   = N.Model,
		model_lift   = N.ModelLift,  -- remonte le modèle dans la case (demande user 07/23 : "légèrement trop bas")
		is_droppable = true,
		is_deletable = true,
		stack_max    = 64,
		-- Client : ouvre l'UI d'écriture. Serveur : no-op (la création passe par le net
		-- EVO:Note:Create, revalidé — détention du papier, longueurs, censure).
		on_use       = CLIENT and function() if N.OpenWrite then N.OpenWrite() end end or function() end,
	}
	return true
end

--- Item NOTE ÉCRITE : un seul ITEMS[id], l'exemplaire porte instance_key = doc id.
function N.RegisterWrittenItem()
	if not istable(ITEMS) then return false end
	ITEMS[N.WrittenItemId] = {
		name         = "Note",
		description  = "Une note manuscrite. Clic droit > Utiliser pour la lire.",
		category     = "object",
		rarity       = "common",
		icon         = N.Icon,
		model_path   = N.Model,
		model_lift   = N.ModelLift,
		is_droppable = true,
		is_deletable = true,
		requires_instance_key = true,
		evo_note     = true,
		instance_name = function(key)
			local d = (CLIENT and N.Defs and N.Defs[key]) or (SERVER and N.Docs and N.Docs[key])
			local title = d and d.title or ""
			return "Note : " .. (title ~= "" and title or "sans titre")
		end,
		instance_description = function(key)
			local d = (CLIENT and N.Defs and N.Defs[key]) or (SERVER and N.Docs and N.Docs[key])
			if d then
				return "Note écrite par " .. (d.ownerName or "?") .. ".\nClic droit > Utiliser pour la lire."
			end
			return "Une note manuscrite. Clic droit > Utiliser pour la lire."
		end,
		on_use = CLIENT and function(_, slot)
			local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
			local key = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
			if key and N.OpenRead then N.OpenRead(key) end
		end or function() end,
	}
	return true
end
