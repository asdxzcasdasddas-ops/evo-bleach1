-- "addons\\defusal_event\\lua\\defusal\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
DefusalEvent = DefusalEvent or {}
DefusalEvent.Config = {}

local CFG = DefusalEvent.Config

-- Config par défaut (écrasées au chargement BDD)

CFG.Zone = {
    pos = Vector(-4314.95, -1664.96, 250.03),
    radius = 500
}

CFG.BombModel = "models/evo/props/props_anim/evo_2k8nhlyatkaep2/evo_jndo9z7c70o845wv.mdl"
CFG.BombCount = 2
CFG.MinSpacing = 100

CFG.DefusalFaction = "Hollow"

-- Faction qui DÉFEND les bombes (les protège -> gagne si elles ne sont pas désamorcées à temps).
-- Elle est prévenue de la zone DefendPrepTime secondes AVANT la faction ATTAQUANTE (qui doit, elle,
-- DÉSAMORCER = faction opposée = DefusalFaction, dérivée automatiquement quand DefendFaction est posé).
-- "" = pas de phase de défense -> démarrage direct (ancien comportement).
CFG.DefendFaction  = ""
CFG.DefendPrepTime = 300   -- avance (s) donnée aux défenseurs avant l'alerte des attaquants (~5 min)

CFG.ColorNormal = Color(255, 255, 255)
CFG.ColorDefused = Color(0, 255, 0)
CFG.ColorError = Color(255, 0, 0)

CFG.DefusalTime = 1
CFG.EventDuration = 15

-- Sons
CFG.Sounds = {
    Start = "",
    Win = "",
    Lose = ""
}