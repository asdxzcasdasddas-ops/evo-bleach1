-- "addons\\defusal_event\\lua\\defusal\\cl_defusal.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if not CLIENT then return end

DefusalEvent = DefusalEvent or {}
local CFG = DefusalEvent.Config

local CurrentSound = nil

function DefusalEvent.StopSound()
    if CurrentSound then
        CurrentSound:Stop()
        CurrentSound = nil
    end
end

local eventActive = false
local eventEndTime = 0
local bombStates = {}

local isDefusing = false
local defusalStartTime = 0
local currentBomb = nil

-- Phase de DÉFENSE (alerte anticipée des défenseurs) : waypoint de zone + compte à rebours d'assaut,
-- AVANT que l'event de désamorçage (eventActive) ne démarre vraiment.
local prepActive = false
local prepEndTime = 0
local prepZone = { pos = Vector(0, 0, 0), radius = 0 }

------------------------------------------------
-- RESPONSIVE SYSTEM (Copied from ZoneCapture)
------------------------------------------------
local BASE_WIDTH = 1920
local BASE_HEIGHT = 1080

local scaleX, scaleY

local function UpdateScaleFactors()
    scaleX = ScrW() / BASE_WIDTH
    scaleY = ScrH() / BASE_HEIGHT
end

local function gRespX(v) return math.Round(v * scaleX) end
local function gRespY(v) return math.Round(v * scaleY) end

local function gRespFont(size)
    local scale = math.min(scaleX, scaleY)
    return math.floor(size * (0.7 + scale * 0.3))
end

hook.Add("Initialize", "Defusal_InitFonts", function()
    UpdateScaleFactors()
end)

hook.Add("OnScreenSizeChanged", "Defusal_UpdateFonts", function()
    UpdateScaleFactors()
end)

UpdateScaleFactors()
------------------------------------------------

-- (DA Atelier 07/07) titres/chiffres = Bebas Neue 400 (jamais gras), corps = Roboto ; tailles inchangées.
surface.CreateFont("Defusal_Timer", {
    font = "Bebas Neue",
    size = 32,
    weight = 400,
    antialias = true
})

surface.CreateFont("Defusal_Label", {
    font = "Roboto",
    size = 24,
    weight = 500,
    antialias = true
})

surface.CreateFont("Defusal_Title", {
    font = "Bebas Neue",
    size = 40,
    weight = 400,
    antialias = true
})

net.Receive("Defusal_EventState", function()
    eventActive = net.ReadBool()
    prepActive = false -- l'assaut a démarré (ou l'event est terminé) -> fin de la phase de défense
    if eventActive then
        eventEndTime = net.ReadFloat()
        local zonePos = net.ReadVector()
        local zoneRadius = net.ReadFloat()

        CFG.Zone = {
            pos = zonePos,
            radius = zoneRadius
        }

        bombStates = {}
    else
        DefusalEvent.StopSound()
        eventEndTime = 0
        bombStates = {}
        isDefusing = false
    end
end)

-- Alerte ANTICIPÉE de la faction DÉFENSEUSE : waypoint de zone + compte à rebours avant l'assaut.
-- Les bombes existent déjà (à défendre) mais le désamorçage (eventActive) n'a pas encore démarré.
net.Receive("Defusal_DefenderWarn", function()
    local pos = net.ReadVector()
    local radius = net.ReadFloat()
    local secs = net.ReadUInt(16)
    prepActive = true
    prepEndTime = CurTime() + secs
    prepZone = { pos = pos, radius = radius }
    CFG.Zone = { pos = pos, radius = radius } -- alimente le cache des markers de bombes pendant la prep
    if MUGEN and MUGEN.Notify then
        MUGEN.Notify("Défendez les bombes ! Rejoignez la zone et tenez-la : l'ennemi arrive bientôt.", NOTIFY_GENERIC or 0, 10)
    end
    surface.PlaySound("buttons/button17.wav")
end)

net.Receive("Defusal_BombState", function()
    local ent = net.ReadEntity()
    local state = net.ReadInt(4)
    if IsValid(ent) then
        bombStates[ent:EntIndex()] = state
        if currentBomb == ent then
            isDefusing = false
            currentBomb = nil
        end
    end
end)

net.Receive("Defusal_WrongOrder", function()
    local ent = net.ReadEntity()
    if IsValid(ent) then
        bombStates[ent:EntIndex()] = 2
        ent:EmitSound("buttons/button10.wav")
    end
    
    timer.Create("Defusal_VisualReset", 0.5, 1, function()
        bombStates = {}
        surface.PlaySound("buttons/button19.wav")
    end)
end)

local color_bg = Color(20, 20, 20, 200)
local color_white = Color(255, 255, 255)
local color_cyan = Color(0, 255, 255)
local color_green = Color(0, 255, 0)
local color_red = Color(255, 0, 0)
local color_grey = Color(150, 150, 150)

local matHollowVictory = Material("hollow_win2.png", "noclamp smooth")
local matShinigamiVictory = Material("shinigami_win2.png", "noclamp smooth")
local matTimerBg = Material("temps_background.png", "noclamp smooth")

local gameOverData = nil
local gameOverStartTime = 0

-- Defusal_GameOver supprimé : géré par ncm_system_win

hook.Add("HUDPaint", "Defusal_HUD", function()
    -- Phase de DÉFENSE : bannière + compte à rebours avant l'assaut + distance à la zone (défenseurs).
    if prepActive and not eventActive then
        if CurTime() > prepEndTime + 15 then prepActive = false end -- self-heal si l'assaut n'arrive jamais
        local ply = LocalPlayer()
        if IsValid(ply) then
            local cx = ScrW() / 2
            local ty = gRespY(70)
            local timeStr = string.FormattedTime(math.max(0, prepEndTime - CurTime()), "%02i:%02i")
            draw.SimpleText("DÉFENDEZ LES BOMBES", "Defusal_Title", cx, ty, color_red, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            draw.SimpleText("Ennemi dans " .. timeStr, "Defusal_Timer", cx, ty + gRespY(40), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            local dist = math.floor(ply:GetPos():Distance(prepZone.pos) / 52.49)
            draw.SimpleText("Zone à " .. dist .. " m", "Defusal_Label", cx, ty + gRespY(78), color_grey, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
    end

    if eventActive then
        local ply = LocalPlayer()
        local maxDist = CFG.Zone.radius + 1000
        
        if IsValid(ply) and ply:GetPos():DistToSqr(CFG.Zone.pos) <= (maxDist * maxDist) then
            local timeLeft = math.max(0, eventEndTime - CurTime())
            local timeStr = string.FormattedTime(timeLeft, "%02i:%02i")
            
            -- Nouveau Timer (Haut de l'écran, style jeu vidéo)
            local w, h = gRespX(120), gRespY(30)
            local x, y = (ScrW() - w) / 2, gRespY(80)
            
            -- Fond avec image
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(matTimerBg)
            surface.DrawTexturedRect(x, y, w, h)
            
            -- Texte Timer
            draw.SimpleText(timeStr, "Defusal_Timer", x + w/2, y + h/2 + 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            -- Titre au dessus
            draw.SimpleText("Bombe spirituelle", "Defusal_Title", x + w/2, y - gRespY(22), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
    end
    
    if isDefusing then
        local progress = math.Clamp((CurTime() - defusalStartTime) / CFG.DefusalTime, 0, 1)
        local w, h = gRespX(350), gRespY(14)
        local x, y = (ScrW() - w) / 2, ScrH() - gRespY(250)
        
        -- (DA Atelier 07/07) piste plate CARRÉE + liseré acier 1px (fini l'arrondi)
        draw.RoundedBox(0, x, y, w, h, Color(17, 18, 22, 235))
        surface.SetDrawColor(146, 152, 161, 45)
        surface.DrawOutlinedRect(x, y, w, h, 1)

        -- Barre de progression (blanc métallisé = couleur CONTENU conservée, remplissage plat)
        local metallicWhite = Color(220, 225, 235)
        if progress > 0 then
            draw.RoundedBox(0, x + 2, y + 2, (w - 4) * progress, h - 4, metallicWhite)
        end
        
        -- Texte
        draw.SimpleText("En cours...", "Defusal_Label", ScrW() / 2, y - gRespY(25), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        
        -- Particules (Étincelles blanches)
        if progress < 1 then
            surface.SetDrawColor(255, 255, 255, 255)
            for i = 1, 2 do
                local px = x + 2 + ((w - 4) * progress) + math.random(-2, 2)
                local py = y + h/2 + math.random(-4, 4)
                surface.DrawRect(px, py, 2, 2)
            end
        end
    end
end)

local function ReportDefusalExpired()
    net.Start("Defusal_TimeExpired")
    net.SendToServer()
end

local function ReportDefusalComplete(ent)
    net.Start("Defusal_ClientComplete")
        net.WriteEntity(ent)
    net.SendToServer()
end

hook.Add("Think", "Defusal_ClientLogic", function()
    if not eventActive then 
        isDefusing = false
        currentBomb = nil
        return 
    end
    
    if CurTime() > eventEndTime then
        ReportDefusalExpired()  -- netgate: edge -- eventActive cleared right after the expiry send
        
        eventActive = false 
        return
    end
    
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    if ply:KeyDown(IN_USE) then
        local tr = ply:GetEyeTrace()
        local ent = tr.Entity
        
        if IsValid(ent) and ent:GetModel() == CFG.BombModel and bombStates[ent:EntIndex()] ~= 1 then
             if ent:GetPos():DistToSqr(ply:GetPos()) > 10000 then 
                 isDefusing = false
                 currentBomb = nil
                 return 
             end

             if not isDefusing then
                 isDefusing = true
                 defusalStartTime = CurTime()
                 currentBomb = ent
                 LocalPlayer():EmitSound("a4xy732ex6yeop2/1q9kcah77kmxhhyw.wav", 70, 80, 0.3)
             elseif currentBomb == ent then
                 if CurTime() - defusalStartTime >= CFG.DefusalTime then
                     ReportDefusalComplete(ent)  -- netgate: edge -- isDefusing/currentBomb cleared on completion
                     
                     isDefusing = false
                     currentBomb = nil
                 end
             else
                 isDefusing = true
                 defusalStartTime = CurTime()
                 currentBomb = ent
             end
        else
            isDefusing = false
            currentBomb = nil
        end
    else
        isDefusing = false
        currentBomb = nil
    end
end)

-- Cache des bombes côté client (peuplé quand on les détecte, pas de FindByClass chaque frame)
local _cachedBombs = {}
local _bombCacheTime = 0

hook.Add("PostDrawTranslucentRenderables", "Defusal_3DMarkers", function()
    -- Visible pendant l'event ACTIF ET pendant la phase de DÉFENSE (les défenseurs voient les bombes
    -- à protéger + une balise de zone pour s'y rendre).
    if not (eventActive or (prepActive and not eventActive)) then return end

    -- Pendant la prep : balise "ZONE À DÉFENDRE" au centre, face caméra, pour guider les défenseurs.
    if prepActive and not eventActive then
        local zp = prepZone.pos + Vector(0, 0, 90)
        local a = (EyePos() - zp):Angle()
        local ang = Angle(0, a.y - 90, 90)
        cam.Start3D2D(zp, ang, 0.25)
            draw.SimpleText("ZONE À DÉFENDRE", "Defusal_Label", 0, 0, color_red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end

    -- Rafraîchir le cache toutes les 2s (les bombes ne bougent pas)
    local now = CurTime()
    if now > _bombCacheTime then
        _bombCacheTime = now + 2
        _cachedBombs = {}
        local sqr = CFG.Zone.radius * CFG.Zone.radius * 4
        for _, ent in ipairs(ents.FindByClass("prop_dynamic")) do
            if IsValid(ent) and ent:GetModel() == CFG.BombModel and ent:GetPos():DistToSqr(CFG.Zone.pos) < sqr then
                _cachedBombs[#_cachedBombs + 1] = ent
            end
        end
    end

    local eyePos = EyePos()
    local eyeFwd = EyeAngles():Forward()

    for _, ent in ipairs(_cachedBombs) do
        if not IsValid(ent) then continue end

        local entPos = ent:GetPos()
        -- Culling frustum
        local dx = entPos.x - eyePos.x
        local dy = entPos.y - eyePos.y
        if dx * eyeFwd.x + dy * eyeFwd.y < 0 then continue end

        local state = bombStates[ent:EntIndex()] or 0
        local pos = entPos + Vector(0, 0, 60)
        local ang = Angle(0, now * 50, 0)
        local col = state == 1 and color_green or (state == 2 and color_red or color_white)

        cam.Start3D2D(pos, ang, 0.1)
            surface.SetDrawColor(col)
            surface.DrawRect(-10, -10, 20, 20)
        cam.End3D2D()

        cam.Start3D2D(pos, Angle(0, ang.y + 180, 0), 0.1)
            surface.SetDrawColor(col)
            surface.DrawRect(-10, -10, 20, 20)
        cam.End3D2D()
    end
end)

net.Receive("Defusal_PlaySound", function()
    local soundFile = net.ReadString()
    DefusalEvent.StopSound()
    
    CurrentSound = CreateSound(LocalPlayer(), soundFile)
    if CurrentSound then
        CurrentSound:Play()
    end
end)
