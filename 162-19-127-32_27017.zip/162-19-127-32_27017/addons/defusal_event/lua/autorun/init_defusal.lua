-- "addons\\defusal_event\\lua\\autorun\\init_defusal.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Defusal Event - Loader

if SERVER then
    AddCSLuaFile("defusal/sh_config.lua")
    AddCSLuaFile("defusal/cl_defusal.lua")
    include("defusal/sh_config.lua")
    include("defusal/sv_defusal.lua")
    resource.AddFile("materials/hollow_win2.png")
    resource.AddFile("materials/shinigami_win2.png")
    resource.AddFile("materials/temps_background.png")
end

if CLIENT then
    include("defusal/sh_config.lua")
    include("defusal/cl_defusal.lua")
end

-- print("[Defusal] Système de désamorçage chargé")
