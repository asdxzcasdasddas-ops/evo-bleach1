-- "addons\\evo_instructeur\\lua\\autorun\\sh_loader_instructeur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — loader. Menu instructeur (grade 6+) : cours de vol /
-- flashstep + tournoi maison. Bind « instructeur_ui » déclaré dans lzy_bindmenu.
-- ============================================================================

local root = "evo_instructeur/"

if SERVER then
	AddCSLuaFile(root .. "sh_config.lua")
	AddCSLuaFile(root .. "cl_ui.lua")
	AddCSLuaFile(root .. "cl_course.lua")
	AddCSLuaFile(root .. "cl_tournament.lua")
	AddCSLuaFile(root .. "cl_duel.lua")
	AddCSLuaFile(root .. "cl_king.lua")
	AddCSLuaFile(root .. "cl_infection.lua")
	AddCSLuaFile(root .. "cl_parryduel.lua")
	AddCSLuaFile(root .. "cl_battle.lua")
	AddCSLuaFile(root .. "cl_classement.lua")

	include(root .. "sh_config.lua")
	include(root .. "sv_main.lua")
	include(root .. "sv_stats.lua")    -- stats d'entraînement + service des classements
	include(root .. "sv_course.lua")
	include(root .. "sv_tournament.lua")
	include(root .. "sv_duel.lua")
	include(root .. "sv_king.lua")       -- événements : Roi de l'arène (1vAll / KOTR)
	include(root .. "sv_infection.lua")  -- événements : Infection / Zombie
	include(root .. "sv_parryduel.lua")  -- événements : Duel de parade
	include(root .. "sv_battle.lua")     -- événements : Grande bataille (6v6 → 10v10)
else
	include(root .. "sh_config.lua")
	include(root .. "cl_ui.lua")
	include(root .. "cl_course.lua")
	include(root .. "cl_tournament.lua")
	include(root .. "cl_duel.lua")
	include(root .. "cl_king.lua")
	include(root .. "cl_infection.lua")
	include(root .. "cl_parryduel.lua")
	include(root .. "cl_battle.lua")
	include(root .. "cl_classement.lua")
end
