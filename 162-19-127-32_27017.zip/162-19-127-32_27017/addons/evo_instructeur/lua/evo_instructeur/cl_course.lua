-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_course.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — COURS côté client : mode pose (cam libre pour le vol / viseur
-- sol pour le flashstep), rendu 3D des checkpoints, HUD chrono + classement.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- État courant du cours (depuis Sync) et du classement (depuis Board).
local course = nil   -- { active, kind, status, instr, requireFly, cpRadius, checkpoints, startTime, myIdx, isInstr }
local board  = nil   -- { cpCount, rows = { {name, idx, done, time} } }
local _passFlashIdx  = 0   -- n° du checkpoint qu'on vient de franchir (feedback écran)
local _passFlashTime = 0   -- CurTime de fin du flash
local _myFinishTime  = nil -- mon temps final (fige le chrono une fois le parcours terminé)

local UNITS_PER_METER = 52.49 -- Source : 1 u = 0.75 pouce -> 1 m ≈ 52.49 u

-- Son de click standard du projet (workshop obfusqué) — PAS un son de base GMod.
local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"

-- Nom LISIBLE de la touche réellement bindée au « Menu Instructeur » (jamais une touche en dur).
local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- État du mode pose (instructeur seulement).
local place = nil    -- { kind, origin, radius, freeCam, camPos, camAng, targetCount }

-- L'instructeur a-t-il un cours EN COURS (running) ? (pour le bouton « Arrêter » du menu)
function EVO_INSTRUCTEUR.IsInstructorRunningCourse()
	return course ~= nil and course.active and course.status == "running" and course.isInstr == true
end

-- ── PRESETS de parcours : stockés CLIENT (par joueur = fichier local), par MAP et par TYPE
-- (vol/flashstep), 3 slots. NON partagés. On peut sauver / charger / supprimer (remplacer = re-sauver). ──
local PRESET_FILE  = "evo_instructeur_presets.json"
local PRESET_SLOTS = 3
local presetData   = nil  -- { [map] = { [kind] = { ["1"]={{x,y,z},...}, ... } } }

local function loadPresets()
	if presetData then return presetData end
	presetData = {}
	if file.Exists(PRESET_FILE, "DATA") then
		presetData = util.JSONToTable(file.Read(PRESET_FILE, "DATA") or "") or {}
	end
	return presetData
end
local function savePresetsDisk() file.Write(PRESET_FILE, util.TableToJSON(presetData or {})) end

-- Renvoie un tableau {1,2,3} -> { count = N } ou nil (pour l'UI).
function EVO_INSTRUCTEUR.GetPresets(kind)
	local k = (loadPresets()[game.GetMap()] or {})[kind] or {}
	local out = {}
	for s = 1, PRESET_SLOTS do
		local pts = k[tostring(s)]
		out[s] = (istable(pts) and #pts > 0) and { count = #pts } or nil
	end
	return out
end

-- Sauve les checkpoints COURANTS dans un slot (remplace l'existant). Nécessite un cours en cours d'édition.
function EVO_INSTRUCTEUR.SavePreset(kind, slot)
	if not (course and course.checkpoints and #course.checkpoints > 0) then return false end
	local d, map = loadPresets(), game.GetMap()
	d[map] = d[map] or {} d[map][kind] = d[map][kind] or {}
	local pts = {}
	for i, v in ipairs(course.checkpoints) do pts[#pts + 1] = { v.x, v.y, v.z, (course.cpYaw and course.cpYaw[i]) or 0 } end
	d[map][kind][tostring(slot)] = pts
	savePresetsDisk()
	return #pts
end

function EVO_INSTRUCTEUR.DeletePreset(kind, slot)
	local d, map = loadPresets(), game.GetMap()
	if d[map] and d[map][kind] then d[map][kind][tostring(slot)] = nil savePresetsDisk() end
end

-- Charge un preset : envoie ses points au serveur (qui crée le cours pré-rempli + entre en pose).
function EVO_INSTRUCTEUR.LoadPreset(kind, slot)
	local pts = ((loadPresets()[game.GetMap()] or {})[kind] or {})[tostring(slot)]
	if not (istable(pts) and #pts > 0) then return false end
	net.Start("EVO:Instr:Course:LoadPreset")
		net.WriteString(kind)
		net.WriteUInt(#pts, 8)
		for i, t in ipairs(pts) do
			net.WriteVector(Vector(t[1], t[2], t[3]))
			local yaw = t[4]
			if not yaw then -- vieux preset sans orientation : déduire du tracé (vers le suivant / précédent)
				local nx = pts[i + 1] or pts[i - 1]
				yaw = nx and math.deg(math.atan2(nx[2] - t[2], nx[1] - t[1])) or 0
			end
			net.WriteFloat(yaw)
		end
	net.SendToServer()
	return true
end

-- ── Helpers de rendu 3D ──────────────────────────────────────
-- Anneau (cerceau) des checkpoints. OPTIMISÉ : avant = ~112 surface.DrawPoly/frame PAR anneau
-- (2 faces × 56 segments via cam.Start3D2D). Maintenant = UN SEUL IMesh d'anneau UNITÉ (construit
-- une fois) rendu par anneau via une matrice (rotate+scale+translate) -> 1 SEUL draw call/anneau.
-- Matériau $nocull -> visible des DEUX côtés sans dupliquer la géométrie.
local RING_SEGMENTS = 56
local RING_BAND     = 0.07 -- demi-épaisseur relative au rayon (= ancien radius*0.07)

local RING_MAT = CreateMaterial("evo_instr_ring", "UnlitGeneric", {
	["$basetexture"] = "color/white",
	["$model"]       = "1",
	["$vertexcolor"] = "1",
	["$vertexalpha"] = "1",
	["$nocull"]      = "1",
	["$translucent"] = "1",
})

-- IMesh d'un anneau UNITÉ (rayon 1) dans le plan local x=0 (normale = +X), construit 1 fois.
local _ringMesh
local function getRingMesh()
	if _ringMesh then return _ringMesh end
	local seg = RING_SEGMENTS
	local rOut, rIn = 1 + RING_BAND, 1 - RING_BAND
	local m = Mesh()
	mesh.Begin(m, MATERIAL_TRIANGLES, seg * 2) -- seg quads × 2 triangles
	for i = 0, seg - 1 do
		local a1 = (i / seg) * math.pi * 2
		local a2 = ((i + 1) / seg) * math.pi * 2
		local c1, s1 = math.cos(a1), math.sin(a1)
		local c2, s2 = math.cos(a2), math.sin(a2)
		local oO1 = Vector(0, rOut * c1, rOut * s1)
		local oI1 = Vector(0, rIn  * c1, rIn  * s1)
		local oI2 = Vector(0, rIn  * c2, rIn  * s2)
		local oO2 = Vector(0, rOut * c2, rOut * s2)
		mesh.Position(oO1) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
		mesh.Position(oI1) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
		mesh.Position(oI2) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
		mesh.Position(oO1) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
		mesh.Position(oI2) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
		mesh.Position(oO2) mesh.Color(255, 255, 255, 255) mesh.AdvanceVertex()
	end
	mesh.End()
	_ringMesh = m
	return m
end

-- Cerceau perpendiculaire à `normal`, centré sur `pos`, rayon `radius`, teinté `col` (1 draw call).
local function draw3DRing(pos, normal, radius, col)
	if not normal or normal:LengthSqr() < 0.001 then normal = Vector(0, 0, 1) end
	local m = Matrix()
	m:SetAngles(normal:Angle())            -- +X local -> normal : anneau perpendiculaire à normal
	m:Scale(Vector(radius, radius, radius))
	m:SetTranslation(pos)                  -- pos définie EN DERNIER -> jamais affectée par le Scale
	render.SetMaterial(RING_MAT)
	render.SetColorModulation((col.r or 255) / 255, (col.g or 255) / 255, (col.b or 255) / 255)
	render.SetBlend((col.a or 255) / 255)
	cam.PushModelMatrix(m)
		getRingMesh():Draw()
	cam.PopModelMatrix()
	render.SetColorModulation(1, 1, 1)
	render.SetBlend(1)
end

local function draw3DLabel(pos, txt, col)
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)
	cam.Start3D2D(pos + Vector(0, 0, 0), ang, 0.25)
		draw.SimpleTextOutlined(txt, "EVO_UI_Header", 0, 0, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,220))
	cam.End3D2D()
end

-- Distance fixe DEVANT le joueur où se pose la zone flashstep (on s'oriente/déplace avec le perso).
local FLASH_PLACE_DIST = 250

-- Position où le prochain checkpoint sera posé. Vol = juste devant la cam libre (on le pose en
-- volant à hauteur). Flashstep = JUSTE DEVANT le joueur à distance fixe (pas de visée caméra : on
-- bouge son perso pour le placer) et COLLÉ AU SOL (trace verticale). Le ghost ET le clic utilisent
-- CETTE fonction -> l'aperçu et la pose réelle sont toujours au même endroit.
local function getPlacePos()
	if not place then return nil end
	if place.freeCam and place.camPos and place.camAng then
		return place.camPos + place.camAng:Forward() * 250
	end
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	-- Direction APLATIE (yaw seul) : regarder en haut/bas ne déplace pas la zone.
	local ang = lp:EyeAngles() ang.p = 0 ang.r = 0
	local front = lp:GetPos() + ang:Forward() * FLASH_PLACE_DIST
	-- Collé au sol : trace verticale depuis au-dessus du point devant soi.
	local tr = util.TraceLine({
		start  = front + Vector(0, 0, 80),
		endpos = front - Vector(0, 0, 1000),
		filter = lp,
		mask   = MASK_SOLID_BRUSHONLY,
	})
	return tr.Hit and tr.HitPos or front
end

-- Orientation du cerceau : dans les DEUX modes (vol ET flashstep) c'est un cerceau VERTICAL
-- perpendiculaire au tracé HORIZONTAL (direction APLATIE z=0), qu'on TRAVERSE en suivant le
-- parcours. Le vol est juste centré en l'air, le flashstep posé au sol (cf. hoopCenter).
local function hoopNormal(kind, cps, i)
	local cur = cps[i]
	local d = (cps[i + 1] and (cps[i + 1] - cur)) or (cps[i - 1] and (cur - cps[i - 1]))
	if d then
		d = Vector(d.x, d.y, 0) -- cerceau droit (vertical), perpendiculaire au tracé horizontal
		if d:LengthSqr() > 1 then return d:GetNormalized() end
	end
	return Vector(1, 0, 0) -- 1 seul checkpoint / pas de direction : cerceau vertical par défaut
end

-- Centre VISUEL du cerceau. Flashstep : le checkpoint est posé AU SOL -> on remonte le cerceau de
-- son rayon pour qu'il REPOSE sur le sol (bas du cerceau au sol), on le traverse en courant. Vol :
-- centré sur la position posée (en l'air).
local function hoopCenter(kind, cp, radius)
	if kind == "flashstep" then return cp + Vector(0, 0, radius) end
	return cp
end

-- Normale (= plan) d'un cerceau à partir d'un yaw horizontal -> cerceau toujours VERTICAL.
local function yawToNormal(yaw) return Angle(0, yaw or 0, 0):Forward() end

-- Yaw de POSE = la direction où l'instructeur regarde : caméra libre (vol) ou perso (flashstep).
-- Le cerceau se TOURNE donc vers où on regarde, et garde ce yaw une fois posé (WYSIWYG).
local function placeYaw()
	if not place then return 0 end
	if place.freeCam and place.camAng then return place.camAng.y end
	local lp = LocalPlayer()
	return IsValid(lp) and lp:EyeAngles().y or 0
end

-- ── Rendu des checkpoints (tout le monde dans le cours). ────────────────────
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::CourseDraw", function(bDepth, bSky)
	if bDepth or bSky then return end
	-- 0 coût à vide (comme les autres hooks) : rien à dessiner si aucun cours actif ET pas en pose.
	if not ((course and course.active) or place) then return end
	local col = COL()

	-- Checkpoints du cours
	if course and course.active and course.checkpoints then
		local rad = course.cpRadius or 200
		local editing = course.status == "editing"
		local myIdx   = course.myIdx or 0           -- 0 = observateur/édition (voit tout) ; >0 = coureur
		local running = (course.status == "running") and myIdx > 0
		for i, cp in ipairs(course.checkpoints) do
			-- EN COURSE : les checkpoints DÉJÀ FRANCHIS DISPARAISSENT pour ce joueur -> il ne reste
			-- que le prochain + les suivants (« ça continue »).
			if not (running and i < myIdx) then
				local c
				if editing or myIdx == 0 then
					c = ColorAlpha(col.accent, 210)              -- édition / observateur : tout en accent
				elseif i == myIdx then
					c = ColorAlpha(col.accent, 255)              -- prochain
				else
					c = Color(200, 205, 215, 95)                 -- à venir
				end
				local pulse = (running and i == myIdx) and (0.7 + math.sin(CurTime() * 4) * 0.3) or 1
				local drawPos = hoopCenter(course.kind, cp, rad)
				-- Orientation : yaw POSÉ par l'instructeur (sinon repli sur le tracé pour vieilles données).
				local nrm = (course.cpYaw and course.cpYaw[i]) and yawToNormal(course.cpYaw[i])
					or hoopNormal(course.kind, course.checkpoints, i)
				draw3DRing(drawPos, nrm, rad, ColorAlpha(c, (c.a or 255) * pulse))
				-- Le PROCHAIN checkpoint affiche aussi la distance en mètres (savoir où aller).
				local lbl = "Checkpoint " .. i
				if running and i == myIdx then
					lbl = lbl .. "  ·  " .. math.Round(LocalPlayer():GetPos():Distance(cp) / UNITS_PER_METER) .. " m"
				end
				draw3DLabel(drawPos + Vector(0, 0, rad + 30), lbl, c)
			end
		end
	end

	-- Aperçu du PROCHAIN point (instructeur, tant que le parcours n'est pas complet) : un rond
	-- ambré pulsant AU MÊME endroit que la pose réelle, avec le n° du checkpoint écrit dessus.
	if place then
		local placed = (course and course.checkpoints and #course.checkpoints) or 0
		if placed < (place.targetCount or 1) then
			local ghost = getPlacePos()
			if ghost then
				local rad = (place.kind == "flashstep") and EVO_INSTRUCTEUR.Config.Course.Flashstep.CheckpointRadius
					or EVO_INSTRUCTEUR.Config.Course.Vol.CheckpointRadius
				-- Cerceau-aperçu VERTICAL orienté vers OÙ ON REGARDE (cam libre pour le vol, perso pour
				-- le flashstep) -> il se tourne avec la vue, plus simple à poser. Conserve ce yaw une
				-- fois posé (cf. AddPoint + cpYaw).
				local normal = yawToNormal(placeYaw())
				local drawPos = hoopCenter(place.kind, ghost, rad)
				local pulse = 0.5 + math.sin(CurTime() * 5) * 0.3
				draw3DRing(drawPos, normal, rad, Color(255, 221, 164, 200 * pulse))
				draw3DLabel(drawPos + Vector(0, 0, rad + 28), "Checkpoint " .. (placed + 1), Color(255, 221, 164))
			end
		end
	end
end)

-- ============================================================================
-- MODE POSE (instructeur)
-- ============================================================================
local MOVE_SPEED = 750

-- Sensibilité souris : x/y arrivent déjà multipliés par la sensibilité du joueur (ScaleMouse
-- côté moteur) ; il ne reste qu'à appliquer m_yaw/m_pitch comme ApplyMouse -> visée identique
-- au jeu normal, souris inversée (m_pitch négatif) incluse.
local cvar_m_yaw = GetConVar("m_yaw")
local cvar_m_pitch = GetConVar("m_pitch")

local function endPlacement()
	if not place then return end
	place = nil
	EVO_INSTRUCTEUR.PlacementActive = false
	-- Rend la caméra au gamemode + réactive les binds (cf. startPlacement).
	local lp = LocalPlayer()
	if IsValid(lp) then
		lp.ActiveCamera = true
		if lp.DisableBindKeys then lp:DisableBindKeys(false) end
	end
	if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = false end
	hook.Remove("CalcView", "EVO_Instr::PlaceCam")
	hook.Remove("InputMouseApply", "EVO_Instr::PlaceMouse")
	hook.Remove("CreateMove", "EVO_Instr::PlaceMove")
	hook.Remove("HUDPaint", "EVO_Instr::PlaceHUD")
end
EVO_INSTRUCTEUR.EndPlacement = endPlacement

local function startPlacement(kind, origin, radius, freeCam, targetCount)
	endPlacement()
	place = {
		kind = kind, origin = origin, radius = radius, freeCam = freeCam,
		targetCount = math.max(1, targetCount or 1),
		camPos = freeCam and (EyePos()) or nil,
		camAng = freeCam and (EyeAngles()) or nil,
	}
	EVO_INSTRUCTEUR.PlacementActive = true
	local lp = LocalPlayer()
	-- Bloque les binds custom (sorts, flashstep…) pendant la pose — comme ncm_free_camera.
	if IsValid(lp) and lp.DisableBindKeys then lp:DisableBindKeys(true) end

	if freeCam then
		-- CLÉ : la caméra du gamemode (MUGEN::CalcView::CameraSystem) cède seulement si
		-- ply.ActiveCamera = false. MAIS d'autres systèmes (orbite…) le remettent à true ->
		-- il faut le RÉ-AFFIRMER CHAQUE FRAME (comme les cinématiques liberation_spi/hollow_mask)
		-- + poser MUGEN.Camera.ForceDisable pour empêcher l'orbite de reprendre la cam.
		if IsValid(lp) then lp.ActiveCamera = false end
		if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = true end
		hook.Add("CalcView", "EVO_Instr::PlaceCam", function()
			if not place then return end
			local p = LocalPlayer()
			if IsValid(p) then p.ActiveCamera = false end
			if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = true end
			return { origin = place.camPos, angles = place.camAng, fov = 90, drawviewer = true }
		end)
		hook.Add("InputMouseApply", "EVO_Instr::PlaceMouse", function(cmd, x, y, angle)
			if not place or vgui.CursorVisible() then return end
			local sy = cvar_m_yaw and cvar_m_yaw:GetFloat() or 0.022
			local sp = cvar_m_pitch and cvar_m_pitch:GetFloat() or 0.022
			place.camAng.y = place.camAng.y - x * sy
			place.camAng.p = math.Clamp(place.camAng.p + y * sp, -89, 89)
			place.camAng.r = 0
			return true
		end)
	end

	hook.Add("CreateMove", "EVO_Instr::PlaceMove", function(cmd)
		if not place then return end
		if place.freeCam then
			-- Ré-affirme la prise de caméra AVANT CalcView (CreateMove tourne avant) -> la cam
			-- gamemode voit ActiveCamera=false à temps même si un autre système l'a remis à true.
			local p = LocalPlayer()
			if IsValid(p) then p.ActiveCamera = false end
			if MUGEN and MUGEN.Camera then MUGEN.Camera.ForceDisable = true end
			-- Déplace la cam libre (bornée au rayon + anti-clip), gèle le joueur.
			if not vgui.CursorVisible() then
				local dt = RealFrameTime()
				local sp = MOVE_SPEED * dt
				if cmd:KeyDown(IN_SPEED) then sp = sp * 2.4 end
				local fwd, rgt = place.camAng:Forward(), place.camAng:Right()
				local mv = Vector(0, 0, 0)
				if cmd:KeyDown(IN_FORWARD) then mv = mv + fwd * sp end
				if cmd:KeyDown(IN_BACK) then mv = mv - fwd * sp end
				if cmd:KeyDown(IN_MOVERIGHT) then mv = mv + rgt * sp end
				if cmd:KeyDown(IN_MOVELEFT) then mv = mv - rgt * sp end
				if cmd:KeyDown(IN_JUMP) then mv = mv + Vector(0, 0, sp) end
				if cmd:KeyDown(IN_DUCK) then mv = mv - Vector(0, 0, sp) end
				local np = place.camPos + mv
				local off = np - place.origin
				if off:Length() > place.radius then np = place.origin + off:GetNormalized() * place.radius end
				local tr = util.TraceLine({ start = place.camPos, endpos = np, filter = LocalPlayer(), mask = MASK_SOLID_BRUSHONLY })
				if tr.Hit then np = tr.HitPos + tr.HitNormal * 6 end
				place.camPos = np
			end
			-- Gèle le joueur + fige sa visée (la cam libre a ses propres angles) — comme ncm_free_camera.
			cmd:ClearMovement() cmd:ClearButtons()
			cmd:SetViewAngles(LocalPlayer():EyeAngles())
		else
			-- Sol (flashstep) : on bloque juste l'attaque (le clic G sert à poser).
			cmd:RemoveKey(IN_ATTACK)
		end
	end)

	hook.Add("HUDPaint", "EVO_Instr::PlaceHUD", function()
		if not place then return end
		local col = COL()
		local n = (course and course.checkpoints and #course.checkpoints) or 0
		local target = place.targetCount or 1
		local ready = n >= target
		local w = R(360)
		local x, y = ScrW() / 2 - w / 2, EVO_INSTRUCTEUR.HudTopY()
		-- Carte plate v2 : fond + liseré 1px + barre d'accent, kanji du mode à droite.
		surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, w, R(84))
		surface.SetDrawColor(ColorAlpha(col.line, 255)) surface.DrawOutlinedRect(x, y, w, R(84))
		surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, R(4), R(84))
		draw.SimpleText(place.kind == "flashstep" and "走" or "飛", "EVO_UI_Kanji", x + w - R(14), y + R(20), ColorAlpha(col.dim, 190), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText("MODE POSE · " .. (place.kind == "flashstep" and "COURSE" or "VOL"), "EVO_UI_Header", x + R(16), y + R(10), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("CHECKPOINTS " .. n .. " / " .. target .. (ready and "  ✓" or ""), "EVO_UI_Mono", x + R(16), y + R(42), ready and col.green or col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Clic G poser · Clic D retirer · Échap annuler", "EVO_Instr_Small", x + R(16), y + R(60), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end)
end

-- Entrées de pose : SOURIS UNIQUEMENT (le clavier crée des conflits moteur — Entrée = chat,
-- E = +use). Clic gauche = poser · Clic droit = retirer le dernier. Le reste (inviter, lancer,
-- sauver en preset) se fait dans le panneau qui s'ouvre une fois le parcours complet.
-- DÉBOUNCE : PlayerButtonDown peut se déclencher 2× pour un seul clic -> sans garde, on posait/
-- retirait 2 points d'un coup. On ignore donc tout clic survenu <0.2s après le précédent.
hook.Add("PlayerButtonDown", "EVO_Instr::PlaceInput", function(ply, btn)
	if ply ~= LocalPlayer() or not place then return end
	if vgui.CursorVisible() then return end
	if btn ~= MOUSE_LEFT and btn ~= MOUSE_RIGHT then return end
	if (place._nextInput or 0) > SysTime() then return end
	place._nextInput = SysTime() + 0.2

	if btn == MOUSE_LEFT then
		local placed = (course and course.checkpoints and #course.checkpoints) or 0
		if placed >= (place.targetCount or 1) then return end -- complet : le panneau de lancement gère la suite
		local pos = getPlacePos()
		if pos then
			net.Start("EVO:Instr:Course:AddPoint")
				net.WriteVector(pos)
				net.WriteFloat(placeYaw()) -- orientation = où on regarde à la pose
			net.SendToServer()
		end
	else -- MOUSE_RIGHT
		net.Start("EVO:Instr:Course:RemoveLast") net.SendToServer()
	end
end)

-- Échap pendant la pose = annuler. Le préfixe « ! » NE SUFFIT PAS (ordre des hooks non garanti
-- en GMod — c'est écrit dans lzy_escape_menu). Le pattern FIABLE du projet = exposer une fonction
-- OnEscape() que le hook OnPauseMenuShow de lzy_escape_menu appelle EXPLICITEMENT (comme
-- NCM_CHAR_SELECT.OnEscape). Renvoie true si l'Échap est consommé (mode pose actif) -> lzy_escape
-- bloque le menu pause. Si un picker d'invitation est ouvert, Échap le ferme au lieu d'annuler.
function EVO_INSTRUCTEUR.OnEscape()
	if not place then return false end
	if IsValid(EVO_INSTRUCTEUR._pickerPanel) then
		EVO_INSTRUCTEUR._pickerPanel:Remove()
		return true
	end
	net.Start("EVO:Instr:Course:Cancel") net.SendToServer()
	endPlacement()
	return true
end

-- ============================================================================
-- PANNEAU DE LANCEMENT (souris) — s'ouvre quand le parcours est complet. Tout se fait à la
-- souris. L'invitation est SÉPARÉE du départ : (1) on invite les élèves (ils reçoivent
-- l'invitation et voient le parcours), (2) on démarre quand on veut.
-- ============================================================================
function EVO_INSTRUCTEUR.OpenCourseLaunchPanel()
	if not place then return end
	if IsValid(EVO_INSTRUCTEUR._pickerPanel) then return end
	local kind = place.kind
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		if not place then return end -- pose annulée entre-temps
		local col = COL()
		local nCP = (course and course.checkpoints and #course.checkpoints) or 0
		local rows  = #list
		local listH = math.Clamp(rows * 30, 30, 200)
		local W, H = 420, 100 + listH + 150
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		local invited = {} -- sid -> true (déjà invité depuis ce panneau)
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Watermark(w, h, kind == "flashstep" and "走" or "飛", 1)
			EVO_UI.Header(w, "PARCOURS PRÊT", nCP .. " CP", 1, R(20))
			draw.SimpleText(rows > 0 and "1) Invite les élèves proches   2) Démarre le cours" or "Aucun élève proche : tu peux démarrer en solo (démo).", "EVO_Instr_Small", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		-- Checklist des élèves proches (un élève invité passe en « ✓ invité » et n'est plus cliquable)
		local checks = {}
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(88)) scroll:SetSize(R(W - 40), R(listH))
		for _, p in ipairs(list) do
			checks[p.sid] = false
			local row = scroll:Add(vgui.Create("DButton")) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(28)) row:SetText("")
			row.Paint = function(s, w, h)
				local inv = invited[p.sid]
				surface.SetDrawColor(ColorAlpha(color_white, inv and 18 or (checks[p.sid] and 24 or 10)))
				surface.DrawRect(0, 0, w, h)
				if checks[p.sid] and not inv then
					surface.SetDrawColor(col.accent)
					surface.DrawOutlinedRect(0, 0, w, h)
					surface.DrawRect(0, 0, R(2), h)
				end
				draw.SimpleText(p.name, "EVO_Instr_Small", R(10), h / 2, inv and col.muted or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(inv and "✓ invité" or (checks[p.sid] and "✓" or ""), "EVO_Instr_Small", w - R(12), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function() if not invited[p.sid] then checks[p.sid] = not checks[p.sid] end end
		end
		-- Bouton d'action du kit (coin bas-droit coupé) ; coordonnées non échelonnées -> R().
		local function btn(bx, by, bw, bh, label, fill, fn)
			local b = EVO_UI.ActionButton(f, R(bx), R(by), R(bw), R(bh), label, fill, fn)
			b:SetZPos(10)
			return b
		end
		local by = 88 + listH + 8
		-- 1) Inviter (cumulable) — l'invitation est envoyée AVANT le départ.
		btn(20, by, W - 40, 30, "INVITER LES SÉLECTIONNÉS", nil, function()
			local ids = {}
			for sid, on in pairs(checks) do if on and not invited[sid] then ids[#ids + 1] = sid invited[sid] = true checks[sid] = false end end
			if #ids == 0 then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Coche au moins un élève à inviter.", NOTIFY_ERROR or 1, 3) end
				return
			end
			net.Start("EVO:Instr:Course:Invite") net.WriteUInt(#ids, 8)
				for _, id in ipairs(ids) do net.WriteString(id) end
			net.SendToServer()
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(#ids .. " élève(s) invité(s).", NOTIFY_GENERIC or 0, 3) end
		end)
		by = by + 36
		-- 2) Démarrer
		btn(20, by, W - 40, 34, "DÉMARRER LE COURS", col.green, function()
			net.Start("EVO:Instr:Course:Start") net.SendToServer()
			f:Remove()
		end)
		by = by + 40
		local halfW = (W - 48) / 2
		btn(20, by, halfW, 28, "REPRENDRE LA POSE", col.muted, function()
			net.Start("EVO:Instr:Course:RemoveLast") net.SendToServer() -- repasse sous le seuil -> retour à la pose
			f:Remove()
		end)
		btn(20 + halfW + 8, by, halfW, 28, "ANNULER LE COURS", Color(120, 60, 64), function()
			net.Start("EVO:Instr:Course:Cancel") net.SendToServer()
			f:Remove()
		end)
		by = by + 34
		local tW = (W - 40 - 16) / 3
		for s = 1, 3 do
			btn(20 + (s - 1) * (tW + 8), by, tW, 24, "PRESET " .. s, nil, function()
				EVO_INSTRUCTEUR.SavePreset(kind, s)
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Parcours sauvé en preset " .. s .. ".", NOTIFY_GENERIC or 0, 3) end
			end)
		end
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ============================================================================
-- PANNEAU DE GESTION (souris) — s'ouvre via F6 pendant qu'un cours TOURNE. L'instructeur
-- peut inviter d'autres élèves en cours de route, REDÉMARRER tout le monde du début, ou
-- arrêter le cours.
-- ============================================================================
function EVO_INSTRUCTEUR.OpenCourseManagePanel()
	if not EVO_INSTRUCTEUR.IsInstructorRunningCourse() then return end
	if IsValid(EVO_INSTRUCTEUR._managePanel) then EVO_INSTRUCTEUR._managePanel:Remove() end
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		if not EVO_INSTRUCTEUR.IsInstructorRunningCourse() then return end
		local col = COL()
		local rows  = #list
		local listH = math.Clamp(rows * 30, 30, 180)
		local W, H = 420, 96 + listH + 152 -- +42 pour le bouton « 3,2,1 — Lancer le départ »
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._managePanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._managePanel == f then EVO_INSTRUCTEUR._managePanel = nil end end
		-- Re-presser la touche bindée FERME ce panneau (la touche n'atteint pas PlayerButtonDown
		-- quand l'UI a le focus clavier). _suppressOpenUntil empêche le ré-open du même appui.
		f.OnKeyCodePressed = function(s, key)
			local lp = LocalPlayer()
			if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
				EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
				f:Remove() return true
			end
		end
		-- Croix de fermeture (ferme juste l'UI ; le cours continue de tourner).
		closeX(f, W, function() f:Remove() end)
		local invited = {}
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Watermark(w, h, (course and course.kind == "flashstep") and "走" or "飛", 1)
			EVO_UI.Header(w, "GÉRER LE COURS", "EN COURS", 1, R(20))
			draw.SimpleText(rows > 0 and "Invite d'autres élèves, redémarre, ou arrête." or "Aucun élève proche à inviter.", "EVO_Instr_Small", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local checks = {}
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(88)) scroll:SetSize(R(W - 40), R(listH))
		for _, p in ipairs(list) do
			checks[p.sid] = false
			local row = scroll:Add(vgui.Create("DButton")) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(28)) row:SetText("")
			row.Paint = function(s, w, h)
				local inv = invited[p.sid]
				surface.SetDrawColor(ColorAlpha(color_white, inv and 18 or (checks[p.sid] and 24 or 10)))
				surface.DrawRect(0, 0, w, h)
				if checks[p.sid] and not inv then
					surface.SetDrawColor(col.accent)
					surface.DrawOutlinedRect(0, 0, w, h)
					surface.DrawRect(0, 0, R(2), h)
				end
				draw.SimpleText(p.name, "EVO_Instr_Small", R(10), h / 2, inv and col.muted or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(inv and "✓ invité" or (checks[p.sid] and "✓" or ""), "EVO_Instr_Small", w - R(12), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function() if not invited[p.sid] then checks[p.sid] = not checks[p.sid] end end
		end
		-- Bouton d'action du kit (coin bas-droit coupé) ; coordonnées non échelonnées -> R().
		local function btn(bx, by, bw, bh, label, fill, fn)
			local b = EVO_UI.ActionButton(f, R(bx), R(by), R(bw), R(bh), label, fill, fn)
			b:SetZPos(10)
			return b
		end
		local by = 88 + listH + 8
		btn(20, by, W - 40, 30, "INVITER LES SÉLECTIONNÉS", nil, function()
			local ids = {}
			for sid, on in pairs(checks) do if on and not invited[sid] then ids[#ids + 1] = sid invited[sid] = true checks[sid] = false end end
			if #ids == 0 then return end
			net.Start("EVO:Instr:Course:Invite") net.WriteUInt(#ids, 8)
				for _, id in ipairs(ids) do net.WriteString(id) end
			net.SendToServer()
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification(#ids .. " élève(s) invité(s).", NOTIFY_GENERIC or 0, 3) end
		end)
		by = by + 36
		btn(20, by, W - 40, 32, "DÉCOMPTE 3, 2, 1 · DÉPART", col.green, function()
			net.Start("EVO:Instr:Course:Countdown") net.SendToServer()
		end)
		by = by + 38
		local halfW = (W - 48) / 2
		btn(20, by, halfW, 34, "REDÉMARRER DU DÉBUT", col.muted, function()
			net.Start("EVO:Instr:Course:Restart") net.SendToServer()
			f:Remove()
		end)
		btn(20 + halfW + 8, by, halfW, 34, "ARRÊTER LE COURS", Color(120, 60, 64), function()
			net.Start("EVO:Instr:Course:Cancel") net.SendToServer()
			f:Remove()
		end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ============================================================================
-- HUD chrono + classement (tout le monde dans un cours lancé)
-- ============================================================================
hook.Add("HUDPaint", "EVO_Instr::CourseBoard", function()
	if not (course and course.active and course.status == "running") then return end
	local col = COL()
	local nCP = course.checkpoints and #course.checkpoints or 0

	-- Décompte « 3 · 2 · 1 · PARTEZ ! » lancé par l'instructeur (overlay central, signal de départ).
	if course.goEnd and course.goEnd > 0 then
		local rem = course.goEnd - CurTime()
		if rem > -1.2 then
			local txt = (rem > 0) and tostring(math.ceil(rem)) or "PARTEZ !"
			draw.SimpleTextOutlined(txt, "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, (rem > 0) and col.accent or col.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	end

	-- Chrono PERSO (haut centre) : il NE démarre PAS au lancement du cours mais quand CE joueur
	-- franchit le 1er checkpoint (course.startTime > 0) ; figé sur le temps final à l'arrivée.
	local myStart  = course.startTime or 0
	local finished = (course.myIdx or 0) > nCP and (course.myIdx or 0) > 0
	local yTop = EVO_INSTRUCTEUR.HudTopY()
	if myStart > 0 then
		local t = finished and (_myFinishTime or 0) or math.max(0, CurTime() - myStart)
		local chrono = string.format("%02d:%05.2f", math.floor(t / 60), t % 60)
		draw.SimpleText(chrono, "EVO_UI_Header", ScrW() / 2, yTop, finished and col.green or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	elseif (course.myIdx or 0) >= 1 then
		draw.SimpleText("Franchis le Checkpoint 1 pour lancer ton chrono", "EVO_Instr_Small", ScrW() / 2, yTop + R(2), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Instructeur : rappel pour gérer le cours (redémarrer / inviter / arrêter), via la touche BINDÉE.
	if course.isInstr then
		draw.SimpleText("Cours en cours · [" .. bindKeyName() .. "] pour gérer (redémarrer / inviter / arrêter)", "EVO_Instr_Small", ScrW() / 2, yTop + R(30), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- ── Guidage coureur (élève OU instructeur qui participe) : direction + DISTANCE (m) ──
	if course.checkpoints and (course.myIdx or 0) >= 1 then
		local nextCp = course.checkpoints[course.myIdx or 0]
		if nextCp then
			local meters = math.Round(LocalPlayer():GetPos():Distance(nextCp) / UNITS_PER_METER)
			local label  = "Checkpoint " .. course.myIdx .. "  ·  " .. meters .. " m"
			local scr = nextCp:ToScreen()
			if scr.visible then
				draw.SimpleTextOutlined(label, "EVO_Instr_Btn", scr.x, scr.y - R(46), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 220))
			else
				-- Hors champ : flèche au bord de l'écran pointant vers le checkpoint (pattern waypoint quête).
				local cx, cy = ScrW() / 2, ScrH() / 2
				local a = math.atan2(scr.y - cy, scr.x - cx)
				local edge = math.min(ScrW(), ScrH()) * 0.4
				local px, py = cx + math.cos(a) * edge, cy + math.sin(a) * edge
				local sz = R(16)
				surface.SetDrawColor(col.accent.r, col.accent.g, col.accent.b, 235)
				draw.NoTexture()
				surface.DrawPoly({
					{ x = px + math.cos(a) * sz * 1.6, y = py + math.sin(a) * sz * 1.6 },
					{ x = px + math.cos(a + 2.5) * sz, y = py + math.sin(a + 2.5) * sz },
					{ x = px + math.cos(a - 2.5) * sz, y = py + math.sin(a - 2.5) * sz },
				})
				draw.SimpleTextOutlined(label, "EVO_Instr_Small", px, py - R(26), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 220))
			end
		end
	end

	-- ── Feedback « checkpoint franchi » ──
	if CurTime() < _passFlashTime then
		local a = math.Clamp((_passFlashTime - CurTime()) / 0.6, 0, 1)
		draw.SimpleTextOutlined("✓ Checkpoint " .. _passFlashIdx .. " franchi !", "EVO_UI_Header", ScrW() / 2, ScrH() * 0.36, ColorAlpha(col.green, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, ColorAlpha(Color(0, 0, 0), 220 * a))
	end

	-- Classement (droite)
	if board and board.rows then
		local w, x = R(280), ScrW() - R(300)
		local y = R(160)
		local h = R(34) + #board.rows * R(24) + R(10)
		-- Carte plate v2 : fond + liseré 1px + barre d'accent.
		surface.SetDrawColor(ColorAlpha(col.bg, 220)) surface.DrawRect(x, y, w, h)
		surface.SetDrawColor(ColorAlpha(col.line, 255)) surface.DrawOutlinedRect(x, y, w, h)
		surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, R(3), h)
		draw.SimpleText("CLASSEMENT", "EVO_UI_Header", x + R(14), y + R(8), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local ry = y + R(40)
		for i, r in ipairs(board.rows) do
			local right = r.done and (string.format("%.2fs", r.time)) or (r.idx - 1) .. "/" .. (board.cpCount or 0)
			local rc = r.done and col.green or col.muted
			draw.SimpleText(i .. ". " .. r.name, "EVO_Instr_Small", x + R(14), ry, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(right, "EVO_UI_Mono", x + w - R(14), ry + R(2), rc, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			ry = ry + R(24)
		end
	end
end)

-- ============================================================================
-- NET : sync du cours / classement / entrée en mode pose
-- ============================================================================
net.Receive("EVO:Instr:Course:EnterEdit", function()
	local kind    = net.ReadString()
	local origin  = net.ReadVector()
	local radius  = net.ReadUInt(16)
	local freeCam = net.ReadBool()
	local target  = net.ReadUInt(8)
	startPlacement(kind, origin, radius, freeCam, target)
end)

net.Receive("EVO:Instr:Course:Sync", function()
	local active = net.ReadBool()
	if not active then
		course = nil
		if place then endPlacement() end
		return
	end
	local c = { active = true }
	c.kind       = net.ReadString()
	c.status     = net.ReadString()
	c.instr      = net.ReadString()
	c.requireFly = net.ReadBool()
	c.cpRadius   = net.ReadUInt(16)
	local n = net.ReadUInt(8)
	c.checkpoints = {}
	c.cpYaw = {}
	for i = 1, n do c.checkpoints[i] = net.ReadVector() c.cpYaw[i] = net.ReadFloat() end
	c.startTime = net.ReadFloat()
	c.myIdx     = net.ReadUInt(8)
	c.isInstr   = net.ReadBool()
	-- Décompte 3,2,1 (signal de départ) : ancré LOCALEMENT, expire seul. On ne ré-ancre que sur un
	-- NOUVEAU décompte (goRem > 0) ; sinon on conserve l'ancien (sinon il se réinitialiserait à 0).
	local goRem = net.ReadFloat()
	c.goEnd = (goRem > 0) and (CurTime() + goRem) or (course and course.goEnd) or 0
	local nCP   = #c.checkpoints
	-- Détecte le franchissement d'un checkpoint (myIdx a augmenté) -> feedback écran « franchi ».
	-- Vaut pour tout coureur, y compris l'instructeur qui participe.
	if course and course.active and c.status == "running"
		and (c.myIdx or 0) > (course.myIdx or 0) and (course.myIdx or 0) >= 1 then
		_passFlashIdx  = course.myIdx     -- le checkpoint qu'on vient de passer
		_passFlashTime = CurTime() + 2.2
		surface.PlaySound(SND_CLICK) -- click projet (remplace l'ancien son de base GMod buttons/button14)
	end
	-- Chrono perso : fige le temps final au passage de l'arrivée ; réinitialise au (re)départ.
	if c.status == "running" and (c.myIdx or 0) > nCP and (c.myIdx or 0) > 0 then
		if not _myFinishTime then
			_myFinishTime = (c.startTime or 0) > 0 and (CurTime() - c.startTime) or 0
		end
	elseif (c.myIdx or 0) <= 1 then
		_myFinishTime = nil  -- nouveau départ / redémarrage par l'instructeur
	end
	course = c
	-- Quand ça passe en "running", l'instructeur sort du mode pose.
	if c.status == "running" and place then endPlacement() end
	-- Parcours complet en édition -> ouvre le panneau de lancement (souris). Se ré-ouvre si le
	-- joueur l'a fermé puis re-complété (on n'ouvre que s'il n'est pas déjà affiché).
	if place and c.status == "editing" and #c.checkpoints >= (place.targetCount or 1)
		and not IsValid(EVO_INSTRUCTEUR._pickerPanel) then
		EVO_INSTRUCTEUR.OpenCourseLaunchPanel()
	end
end)

net.Receive("EVO:Instr:Course:Board", function()
	local cpCount = net.ReadUInt(8)
	local n = net.ReadUInt(8)
	local rows = {}
	for i = 1, n do
		rows[i] = { name = net.ReadString(), idx = net.ReadUInt(8), done = net.ReadBool(), time = net.ReadFloat() }
	end
	board = { cpCount = cpCount, rows = rows }
end)
