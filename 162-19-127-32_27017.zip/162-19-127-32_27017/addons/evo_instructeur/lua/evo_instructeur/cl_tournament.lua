-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_tournament.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — TOURNOI côté client : picker des joueurs proches (partagé),
-- panneau de gestion du bracket (instructeur) + HUD adversaire (participants).
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

local tourn = nil  -- { active, status, instr, myOpp, champion, rounds = { { {nameA,nameB,sa,sb,slot} } } }
local pTourn = nil -- panneau de gestion (instructeur)

-- Le tournoi n'a PAS d'arène/ring (bracket pur, combats arbitrés sur place) :
-- pas de SetEventRing possible. On expose « ce client est concerné par un
-- tournoi » pour que les tiers s'effacent (postes d'entraînement : leurs
-- anneaux/cartes se mélangeaient aux combats du tournoi, demande user 08/19).
function EVO_INSTRUCTEUR.IsInTournament()
	return tourn ~= nil
end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- Champ de SCORE thématisé EVO (remplace la DTextEntry blanche/illisible par défaut).
local function styleScoreEntry(e, col)
	e:SetNumeric(true)
	e:SetFont("EVO_UI_Mono")
	e:SetTextColor(col.title)
	e:SetCursorColor(col.title)
	e:SetPaintBackground(false)
	if e.SetDrawLanguageID then e:SetDrawLanguageID(false) end -- enlève le « FR » (langue clavier) dans le champ
	e:SetText("0")
	e.Paint = function(s, w, h)
		surface.SetDrawColor(ColorAlpha(color_white, 14)) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(s:HasFocus() and col.accent or ColorAlpha(col.muted, 110)) surface.DrawOutlinedRect(0, 0, w, h)
		s:DrawTextEntryText(col.title, col.accent, col.title)
	end
	return e
end

-- ============================================================================
-- PICKER des joueurs proches (partagé course + tournoi)
-- ============================================================================
-- Demande la liste des joueurs proches au serveur ; `cb(list)` est appelé à la réception.
-- list = { { sid, name }, ... }. Partagé : picker tournoi ET panneau de lancement de cours.
local buildPicker -- forward-declare (défini plus bas) pour que OpenNearbyPicker le capture
local pendingNearby = nil
function EVO_INSTRUCTEUR.RequestNearby(cb)
	pendingNearby = cb
	net.Start("EVO:Instr:Nearby") net.SendToServer()
end

function EVO_INSTRUCTEUR.OpenNearbyPicker(title, onConfirm)
	EVO_INSTRUCTEUR.RequestNearby(function(list) buildPicker(title, list, onConfirm) end)
end

function buildPicker(title, list, onConfirm)
	local col = COL()
	-- Anti-empilement : re-cliquer « Inscrire » (le panneau reste ouvert derrière) rouvrait un
	-- picker PAR-DESSUS l'ancien. On ferme toujours le picker précédent avant d'en créer un.
	if IsValid(EVO_INSTRUCTEUR._pickerPanel) then EVO_INSTRUCTEUR._pickerPanel:Remove() end
	if #list == 0 then
		if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Aucun joueur proche.", NOTIFY_ERROR, 4) end
		return
	end
	local W = 380
	local H = math.min(132 + #list * 34, 560)
	local f = vgui.Create("DFrame")
	f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	-- Référence partagée : permet à l'Échap du mode pose (cl_course) de fermer le picker
	-- au lieu d'annuler le cours.
	EVO_INSTRUCTEUR._pickerPanel = f
	f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
	-- `order` = ordre de CLIC réel. Sans lui, la liste envoyée venait d'un pairs() sur
	-- une table hash : ordre arbitraire mais FIGÉ pour un même groupe de joueurs, donc
	-- toujours les mêmes exclus quand le plafond mord, et toujours le même « premier ».
	-- Même patron que les pickers de l'infection et de la parade.
	local checks, order = {}, {}
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, string.upper(title), #list .. " PROCHE(S)", 1, R(20))
	end
	local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(16), R(66)) scroll:SetSize(R(W - 32), R(H - 122))
	for _, p in ipairs(list) do
		local row = scroll:Add(vgui.Create("DButton")) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(30)) row:SetText("")
		checks[p.sid] = false
		row.Paint = function(s, w, h)
			local on = checks[p.sid]
			if on then
				surface.SetDrawColor(ColorAlpha(col.accent, 36)) surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(0, 0, R(2), h)
			else
				local hf = EVO_UI.HoverFrac(s, 10)
				if hf > 0.01 then
					surface.SetDrawColor(ColorAlpha(col.accent, 20 * hf)) surface.DrawRect(0, 0, w, h)
				end
				surface.SetDrawColor(ColorAlpha(col.divider, 110)) surface.DrawRect(R(2), h - 1, w - R(4), 1)
			end
			draw.SimpleText(p.name, "EVO_Instr_Small", R(10), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(on and "✓" or "", "EVO_Instr_Small", w - R(12), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			if checks[p.sid] then
				checks[p.sid] = false
				for i = #order, 1, -1 do if order[i] == p.sid then table.remove(order, i) end end
			else
				checks[p.sid] = true
				order[#order + 1] = p.sid
			end
		end
	end
	EVO_UI.ActionButton(f, R(16), R(H - 50), R(W - 32), R(36), "INVITER LA SÉLECTION", nil, function()
		if onConfirm then onConfirm(order) end
		f:Remove()
	end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

net.Receive("EVO:Instr:Nearby", function()
	local n = net.ReadUInt(8)
	local list = {}
	for i = 1, n do list[i] = { sid = net.ReadString(), name = net.ReadString() } end
	if not pendingNearby then return end
	local cb = pendingNearby pendingNearby = nil
	cb(list)
end)

-- ============================================================================
-- PANNEAU DE GESTION DU TOURNOI (instructeur)
-- ============================================================================
local function rebuildTournBody(card, CARD_W)
	for _, ch in ipairs(card:GetChildren()) do if ch.EVO_TournBody then ch:Remove() end end
	local col = COL()
	local host = vgui.Create("DScrollPanel", card) host.EVO_TournBody = true
	-- Laisse R(50) en bas pour le bouton « Annuler le tournoi » : sinon le DScrollPanel le
	-- recouvrait et captait ses clics (« dur de cliquer dessus »).
	host:SetPos(R(16), R(64)) host:SetSize(R(CARD_W - 32), card:GetTall() - R(64) - R(50))
	if not tourn then return end

	local y = 0
	local function addLabel(txt, fnt, c, tall)
		local l = vgui.Create("DLabel", host) l:SetFont(fnt or "EVO_Instr_TText") l:SetTextColor(c or col.muted)
		l:SetPos(0, R(y)) l:SetSize(R(CARD_W - 40), R(tall or 22)) l:SetText(txt) l:SetWrap(true)
		y = y + (tall or 22) + 6
		return l
	end
	-- Bouton pleine largeur qui avance le curseur Y (mise en page fluide).
	local function chip(label, fill, fn, tall)
		local b = EVO_UI.ActionButton(host, 0, R(y), R(CARD_W - 40), R(tall or 40), label, fill, fn)
		y = y + (tall or 40) + 6
		return b
	end

	if tourn.status == "registering" then
		addLabel("Inscriptions ouvertes : invite les joueurs proches puis lance le bracket.", "EVO_Instr_TText", col.muted, 42)
		chip("INSCRIRE LES JOUEURS PROCHES", nil, function()
			EVO_INSTRUCTEUR.OpenNearbyPicker("Inscrire au tournoi", function(ids)
				net.Start("EVO:Instr:Tourn:Invite") net.WriteUInt(#ids, 8)
				for _, id in ipairs(ids) do net.WriteString(id) end net.SendToServer()
			end)
		end)
		chip("LANCER LE BRACKET", col.green, function() net.Start("EVO:Instr:Tourn:Start") net.SendToServer() end)
	end

	-- Bracket (toutes manches)
	if tourn.rounds then
		for rIdx, round in ipairs(tourn.rounds) do
			addLabel("MANCHE " .. rIdx, "EVO_UI_Header", col.accent, 26)
			for mIdx, m in ipairs(round) do
				local isCurrent = (rIdx == #tourn.rounds) and m.slot == 0 and m.nameA ~= "" and m.nameB ~= ""
				local rowH = isCurrent and 82 or 38
				local panel = vgui.Create("DPanel", host)
				panel:SetPos(0, R(y)) panel:SetSize(R(CARD_W - 40), R(rowH)) panel:SetPaintBackground(false)
				local nameA, nameB = (m.nameA ~= "" and m.nameA or "..."), (m.nameB ~= "" and m.nameB or "(bye)")
				panel.Paint = function(s, w, h)
					surface.SetDrawColor(255, 255, 255, 10) surface.DrawRect(0, 0, w, h)
					if isCurrent then
						surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(0, 0, R(2), h)
					end
					surface.SetDrawColor(ColorAlpha(col.divider, 110)) surface.DrawRect(0, h - 1, w, 1)
					local cA = (m.slot == 1) and col.green or col.title
					local cB = (m.slot == 2) and col.green or col.title
					draw.SimpleText(nameA, "EVO_Instr_TText", R(10), R(10), cA, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					draw.SimpleText(m.sa .. " - " .. m.sb, "EVO_UI_Mono", w / 2, R(12), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
					draw.SimpleText(nameB, "EVO_Instr_TText", w - R(10), R(10), cB, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				end
				if isCurrent then
					local fW = 64
					local eA = styleScoreEntry(vgui.Create("DTextEntry", panel), col) eA:SetPos(R(10), R(42)) eA:SetSize(R(fW), R(30))
					local eB = styleScoreEntry(vgui.Create("DTextEntry", panel), col) eB:SetPos(R(10 + fW + 8), R(42)) eB:SetSize(R(fW), R(30))
					local valX = 10 + (fW + 8) * 2
					EVO_UI.ActionButton(panel, R(valX), R(42), R(CARD_W - 40 - valX - 10), R(30), "VALIDER LE SCORE", col.green, function()
						net.Start("EVO:Instr:Tourn:SetScore")
							net.WriteUInt(rIdx, 8) net.WriteUInt(mIdx, 8)
							net.WriteUInt(math.Clamp(tonumber(eA:GetValue()) or 0, 0, 65535), 16)
							net.WriteUInt(math.Clamp(tonumber(eB:GetValue()) or 0, 0, 65535), 16)
						net.SendToServer()
					end)
				end
				y = y + rowH + 6
			end
		end
	end

	-- Vainqueur + « et après ? » : rejouer avec un NOUVEAU TIRAGE / ajouter des joueurs / repartir de zéro.
	if tourn.champion ~= "" then
		addLabel("VAINQUEUR : " .. tourn.champion, "EVO_UI_Header", col.green, 28)
		addLabel("Et maintenant ?", "EVO_Instr_TText", col.muted, 22)
		chip("REJOUER (NOUVEAU TIRAGE)", col.green, function() net.Start("EVO:Instr:Tourn:Replay") net.SendToServer() end)
		chip("AJOUTER DES JOUEURS ET RELANCER", nil, function() net.Start("EVO:Instr:Tourn:Reopen") net.SendToServer() end)
		chip("NOUVEAU TOURNOI (AUTRES JOUEURS)", nil, function() net.Start("EVO:Instr:Tourn:Reset") net.SendToServer() end)
	end
	host:GetCanvas():SetTall(R(y))
end

-- L'instructeur a-t-il un TOURNOI actif ? (pour rouvrir le panneau via la touche bindée)
function EVO_INSTRUCTEUR.IsRunningTournament()
	return tourn ~= nil and tourn.active and tourn.isInstr == true
end

function EVO_INSTRUCTEUR.OpenTournamentPanel()
	EVO_INSTRUCTEUR._isTournInstr = true
	if IsValid(pTourn) then pTourn:Remove() end
	local col = COL()
	local CARD_W, CARD_H = 520, 580
	pTourn = vgui.Create("DFrame")
	pTourn:SetSize(R(CARD_W), R(CARD_H)) pTourn:Center()
	pTourn:SetTitle("") pTourn:ShowCloseButton(false) pTourn:MakePopup()
	-- Re-presser la touche bindée FERME le panneau (la touche n'atteint pas PlayerButtonDown
	-- quand l'UI a le focus clavier). _suppressOpenUntil empêche le ré-open du même appui.
	pTourn.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			pTourn:Remove() return true
		end
	end
	pTourn.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(14))
		EVO_UI.Watermark(w, h, "闘", 1)
		EVO_UI.Header(w, "TOURNOI MAISON", "BRACKET", 1, R(20))
	end
	closeX(pTourn, CARD_W, function() pTourn:Remove() end)
	-- bouton Annuler le tournoi (bas), ZPos élevé pour rester AU-DESSUS du DScrollPanel.
	local cancel = EVO_UI.ActionButton(pTourn, R(16), R(CARD_H - 38), R(CARD_W - 32), R(26), "ANNULER LE TOURNOI", Color(120, 60, 64), function()
		net.Start("EVO:Instr:Tourn:Cancel") net.SendToServer() pTourn:Remove()
	end)
	cancel:SetZPos(100)
	pTourn.CARD_W = CARD_W
	rebuildTournBody(pTourn, CARD_W)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pTourn) end
end

-- ============================================================================
-- HUD adversaire (participants — pas l'instructeur qui a le panneau)
-- ============================================================================
hook.Add("HUDPaint", "EVO_Instr::TournHUD", function()
	if not (tourn and tourn.active) then return end
	if tourn.isInstr then return end -- l'instructeur a son panneau (flag serveur), pas le HUD passif
	local col = COL()
	local mode = (tourn.teamSize == 2 and "DUO") or (tourn.teamSize == 3 and "TRIO") or "SOLO"
	local w, x, y = R(300), R(20), R(160)
	local teamLine = (tourn.teamSize and tourn.teamSize > 1 and (tourn.myTeam or "") ~= "")
	local h = teamLine and R(98) or R(80)
	surface.SetDrawColor(ColorAlpha(col.bg, 220)) surface.DrawRect(x, y, w, h)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, R(3), h)
	draw.SimpleText("TOURNOI " .. mode .. " · " .. (tourn.instr or ""), "EVO_Instr_Small", x + R(14), y + R(10), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	local yy = y + R(32)
	if teamLine then
		draw.SimpleText("Ton équipe : " .. tourn.myTeam, "EVO_Instr_Small", x + R(14), yy, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		yy = yy + R(22)
	end
	if (tourn.champion or "") ~= "" then
		draw.SimpleText("Vainqueur : " .. tourn.champion, "EVO_Instr_Btn", x + R(14), yy, col.green, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	elseif tourn.status == "registering" then
		draw.SimpleText("Inscriptions en cours…", "EVO_Instr_Btn", x + R(14), yy, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	elseif (tourn.myOpp or "") ~= "" then
		draw.SimpleText("Adversaire : " .. tourn.myOpp, "EVO_Instr_Btn", x + R(14), yy, col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	else
		draw.SimpleText("Éliminé / en attente", "EVO_Instr_Btn", x + R(14), yy, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
end)

-- ============================================================================
-- NET : sync du tournoi
-- ============================================================================
net.Receive("EVO:Instr:Tourn:Sync", function()
	local active = net.ReadBool()
	if not active then
		tourn = nil
		EVO_INSTRUCTEUR._isTournInstr = false
		if IsValid(pTourn) then pTourn:Remove() pTourn = nil end
		return
	end
	local t = { active = true }
	t.status   = net.ReadString()
	t.instr    = net.ReadString()
	t.teamSize = net.ReadUInt(2)
	t.myTeam   = net.ReadString()
	t.myOpp    = net.ReadString()
	t.champion = net.ReadString()
	local nr = net.ReadUInt(8)
	t.rounds = {}
	for r = 1, nr do
		local nm = net.ReadUInt(8)
		local round = {}
		for m = 1, nm do
			round[m] = {
				nameA = net.ReadString(), nameB = net.ReadString(),
				sa = net.ReadUInt(16), sb = net.ReadUInt(16), slot = net.ReadUInt(2),
			}
		end
		t.rounds[r] = round
	end
	t.isInstr = net.ReadBool() -- SERVEUR-autoritatif : ce client est l'instructeur (panneau) ou un participant (HUD)
	tourn = t
	EVO_INSTRUCTEUR._isTournInstr = t.isInstr
	if t.isInstr then
		-- (Ré)ouvre le panneau si besoin (ex: après le « hide » d'un re-create qui l'avait fermé),
		-- sinon le reconstruit avec l'état à jour.
		if not IsValid(pTourn) then
			EVO_INSTRUCTEUR.OpenTournamentPanel()
		else
			rebuildTournBody(pTourn, pTourn.CARD_W or 460)
		end
	end
end)
