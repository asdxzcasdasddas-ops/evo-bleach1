-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_ui.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — menu hub (client). Ouvert via le bind « instructeur_ui »
-- (grade 6+). DA « ATELIER » (2026-07-06, même style que spell selector /
-- échap / squad / OST) : plaque de métal noir à coins coupés + liseré acier +
-- 4 vis, zangetsu (evo_ui/chars) en trame fantôme, titre Bebas sans bold +
-- entaille slash1 réduite + filet denté. Liste numérotée à gauche (kanji par
-- activité), panneau de détail à droite (portrait, chips, LANCER).
-- Navigation : clic = sélection, double-clic / ENTRÉE / bouton = lancer,
-- touches 1-8 = sélection directe. La logique (net, binds, gates) est
-- identique à la v1.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

local pMenu, lastBindAt = nil, 0

-- ── Spectateur ÉLOIGNÉ d'un event : HUD masqué LOCALEMENT (même principe que
-- la Fosse, demande user 08/06 : l'UI restait jusqu'à la fin de l'event même
-- très loin). Le client connaît sa position, le centre (sync) et le rayon
-- (sh_config) -> zéro réseau, réaction immédiate dans les deux sens. bFollow
-- (instructeur / participant) = jamais masqué. Hystérésis 500 u contre le
-- clignotement à la frontière. Le flag st._farHidden posé ici est relu par le
-- rendu du ring au sol de chaque module.
function EVO_INSTRUCTEUR.HudFarHidden(st, vCenter, nRadius, bFollow)
	if bFollow then st._farHidden = nil return false end
	local lp = LocalPlayer()
	if not (IsValid(lp) and vCenter) then return false end
	local nR = nRadius or 2500
	if not st._farHidden then nR = nR + 500 end -- visible -> on ne masque qu'un peu plus loin
	st._farHidden = lp:GetPos():DistToSqr(vCenter) > nR * nR
	return st._farHidden
end

-- ── Y de départ des cartes d'event centrées en haut ────────────────────────
-- La boussole (bleach_compass) occupe le haut de l'écran ET affiche sous elle des
-- libellés qui apparaissent selon l'endroit — « TERRAIN D'ENTRAÎNEMENT » (kanji 闘
-- gravé + filet accent) descend jusqu'à ~11 % de la hauteur. Les cartes d'event
-- démarraient à R(64) et passaient donc PAR-DESSUS (report user 08/09). On les
-- ancre sous tout ce bloc. Valeur FIXE et non calculée depuis la boussole : un
-- ancrage dynamique ferait sauter la carte dès qu'on entre / sort d'un terrain.
-- SOURCE UNIQUE : tous les modules d'event l'utilisent (Fosse comprise, qui en a
-- sa propre copie côté evo_fosse — pense à les garder alignées).
function EVO_INSTRUCTEUR.HudTopY()
	return math.Round(ScrH() * 0.13)
end

-- ── Anneau au sol des events (ring du duel / arène / infection / bataille) ──
-- SOURCE UNIQUE : cl_ui est le premier fichier client chargé (cf. loader), donc
-- tous les modules d'event peuvent l'appeler. Chaque module en portait sa propre
-- copie ; les copies divergent et le ring finit par ne plus être le même d'un
-- mode à l'autre.
function EVO_INSTRUCTEUR.DrawGroundRing(pos, radius, col)
	local n = Vector(0, 0, 1)
	local ang = n:Angle() ang:RotateAroundAxis(ang:Right(), 270)
	cam.Start3D2D(pos + Vector(0, 0, 3), ang, 1)
		draw.NoTexture()
		surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
		local band, seg = math.max(8, radius * 0.03), 72
		local rOut, rIn = radius + band, radius - band
		for i = 0, seg - 1 do
			local a1, a2 = (i / seg) * math.pi * 2, ((i + 1) / seg) * math.pi * 2
			local c1, s1, c2, s2 = math.cos(a1), math.sin(a1), math.cos(a2), math.sin(a2)
			surface.DrawPoly({
				{ x = rOut * c1, y = rOut * s1 }, { x = rIn * c1, y = rIn * s1 },
				{ x = rIn * c2, y = rIn * s2 }, { x = rOut * c2, y = rOut * s2 },
			})
		end
	cam.End3D2D()
end

-- ── Registre des RINGS D'ÉVÉNEMENT actifs (client) ──────────────────────────
-- Chaque module déclare son ring à la réception de son sync, et l'efface quand
-- l'event s'arrête. Le sync partant aussi aux SPECTATEURS proches, tout client qui
-- voit la scène a l'entrée correspondante.
-- Sert aux systèmes TIERS qui doivent s'effacer devant une arène en cours : les
-- postes d'entraînement (ncm_entrainement) sont posés par les instructeurs, donc
-- pile là où ils organisent leurs events -> anneau blanc + carte « APPUYER SUR E »
-- se superposaient au ring. Un tiers n'a ainsi pas à connaître les six modules ni
-- leurs états internes, qui sont des locals de fichier.
EVO_INSTRUCTEUR.EventRings = EVO_INSTRUCTEUR.EventRings or {}

function EVO_INSTRUCTEUR.SetEventRing(sKey, vPos, nRadius)
	if not vPos then EVO_INSTRUCTEUR.EventRings[sKey] = nil return end
	EVO_INSTRUCTEUR.EventRings[sKey] = { pos = vPos, radius = nRadius or 600 }
end

--- Ce point du monde est-il dans l'emprise d'un événement en cours ?
--- nMargin : marge en unités (passer le rayon de SON propre cercle = « nos deux
--- anneaux se croisent »).
function EVO_INSTRUCTEUR.IsInsideEventRing(vPos, nMargin)
	if not vPos then return false end
	for _, r in pairs(EVO_INSTRUCTEUR.EventRings) do
		local d = (r.radius or 0) + (nMargin or 0)
		if vPos:DistToSqr(r.pos) <= d * d then return true end
	end
	return false
end

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/OST) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

local function MakeFonts()
	if not gCreateRespFont then return end
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
	-- Police "Avenir Next World" conservée pour le TEXTE COURANT (descriptions,
	-- dialogues) ; les titres/boutons passent sur les fontes display du kit
	-- (Bebas Neue, désormais réellement livrée aux clients).
	gCreateRespFont("EVO_Instr_Menu",  "Avenir Next World Bold", 21)
	gCreateRespFont("EVO_Instr_Btn",   "Avenir Next World Bold", 18)
	gCreateRespFont("EVO_Instr_Small", "Avenir Next World", 15)
	-- Panneau de tournoi (lisibilité bracket + scores).
	gCreateRespFont("EVO_Instr_TBtn",  "Avenir Next World Bold", 22)
	gCreateRespFont("EVO_Instr_TText", "Avenir Next World", 19)
	-- Kanji filigrane du panneau détail (plus gros que le KanjiXL du kit).
	gCreateRespFont("EVO_Instr_KanjiXXL", "EVO Kanji", 220, 700)
end
hook.Add("Initialize", "EVO_Instr::Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Instr::Fonts2", MakeFonts)
MakeFonts()

function EVO_INSTRUCTEUR.CloseMenu()
	if IsValid(pMenu) then pMenu:Remove() pMenu = nil end
end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	-- Croix DA : même rendu que squad/selector (✕, pas de fond, gris -> accent).
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(34), R(34)) x:SetPos(R(cardW - 46), R(14)) x:SetZPos(1000)
	x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- ── Dialogue : nombre de checkpoints (avant la pose) ────────────────────────
local function openCountDialog(kind)
	local col = COL()
	local cfg = (kind == "flashstep") and EVO_INSTRUCTEUR.Config.Course.Flashstep or EVO_INSTRUCTEUR.Config.Course.Vol
	local maxN = cfg.MaxCheckpoints
	local count = math.min(5, maxN)
	local f = vgui.Create("DFrame") f:SetSize(R(360), R(214)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "NOMBRE DE CHECKPOINTS", nil, 1, R(20))
		draw.SimpleText(cfg.Label, "EVO_UI_Mono", R(20), R(74), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(count), "EVO_UI_Big", w / 2, R(118), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("MAX " .. maxN, "EVO_UI_Mono", w / 2, R(146), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	local bMinus = EVO_UI.ActionButton(f, R(24), R(94), R(48), R(48), "-", nil, function() count = math.max(2, count - 1) end) -- min 2 (à 1 CP, tous les temps = 0.00s)
	local bPlus  = EVO_UI.ActionButton(f, R(288), R(94), R(48), R(48), "+", nil, function() count = math.min(maxN, count + 1) end)
	bMinus._quietClick, bPlus._quietClick = true, true
	EVO_UI.ActionButton(f, R(24), R(164), R(312), R(36), "LANCER LA POSE", col.green, function()
		net.Start("EVO:Instr:Course:Create") net.WriteString(kind) net.WriteUInt(count, 8) net.SendToServer()
		f:Remove() EVO_INSTRUCTEUR.CloseMenu()
	end)
	closeX(f, 360, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Dialogue : mode du tournoi (solo / duo / trio) ──────────────────────────
local function openModeDialog()
	local f = vgui.Create("DFrame") f:SetSize(R(380), R(226)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "TOURNOI MAISON", "MODE", 1, R(20))
	end
	local function pick(size)
		net.Start("EVO:Instr:Tourn:Create") net.WriteUInt(size, 2) net.SendToServer()
		f:Remove() EVO_INSTRUCTEUR.CloseMenu()
		if EVO_INSTRUCTEUR.OpenTournamentPanel then EVO_INSTRUCTEUR.OpenTournamentPanel() end
	end
	local modes = {
		{ num = "01", label = "Solo · 1 v 1", kanji = "一", size = 1 },
		{ num = "02", label = "Duo · 2 v 2",  kanji = "二", size = 2 },
		{ num = "03", label = "Trio · 3 v 3", kanji = "三", size = 3 },
	}
	for i, m in ipairs(modes) do
		EVO_UI.RowButton(f, R(16), R(70 + (i - 1) * 46), R(348), R(44), m, function() pick(m.size) end)
	end
	closeX(f, 380, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Dialogue : presets du cours (3 slots par joueur/map/type) + nouveau parcours ─────────────
local function openCourseSetup(kind)
	local col = COL()
	local cfg = (kind == "flashstep") and EVO_INSTRUCTEUR.Config.Course.Flashstep or EVO_INSTRUCTEUR.Config.Course.Vol
	local f = vgui.Create("DFrame") f:SetSize(R(440), R(314)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, cfg.Label, "PRESETS", 1, R(20))
	end
	local body = vgui.Create("DPanel", f) body:SetPos(0, R(70)) body:SetSize(R(440), R(236)) body:SetPaintBackground(false)
	local rebuild
	rebuild = function()
		for _, ch in ipairs(body:GetChildren()) do ch:Remove() end
		local presets = (EVO_INSTRUCTEUR.GetPresets and EVO_INSTRUCTEUR.GetPresets(kind)) or {}
		local y = 0
		for slot = 1, 3 do
			local p = presets[slot]
			if p then
				-- Clic sur la rangée = charger ; petite croix à droite = supprimer.
				EVO_UI.RowButton(body, R(24), R(y), R(356), R(44),
					{ num = "0" .. slot, label = "Preset " .. slot .. " · " .. p.count .. " CP", kanji = EVO_UI.KanjiNums[slot] },
					function()
						EVO_INSTRUCTEUR.LoadPreset(kind, slot) f:Remove() EVO_INSTRUCTEUR.CloseMenu()
					end)
				local del = vgui.Create("DButton", body) del:SetText("") del:SetPos(R(386), R(y + 8)) del:SetSize(R(28), R(28))
				del.Paint = function(s, w, h)
					if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 40)) surface.DrawRect(0, 0, w, h) end
					draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				del.DoClick = function() EVO_INSTRUCTEUR.DeletePreset(kind, slot) rebuild() end
			else
				local row = vgui.Create("DPanel", body) row:SetPos(R(24), R(y)) row:SetSize(R(392), R(44)) row:SetPaintBackground(false)
				row.Paint = function(s, w, h)
					draw.SimpleText("0" .. slot, "EVO_UI_Mono", R(14), h / 2, ColorAlpha(col.dim, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText("VIDE", "EVO_UI_Mono", R(42), h / 2, ColorAlpha(col.dim, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					surface.SetDrawColor(ColorAlpha(col.divider, 70)) surface.DrawRect(R(2), h - 1, w - R(4), 1)
				end
			end
			y = y + 48
		end
		EVO_UI.ActionButton(body, R(24), R(y + 8), R(392), R(36), "NOUVEAU PARCOURS", col.green, function()
			f:Remove() openCountDialog(kind)
		end)
	end
	rebuild()
	closeX(f, 440, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Dialogue : mode « Roi de l'arène » (1 contre tous / King of the ring) ─────
local function openKingMode()
	local f = vgui.Create("DFrame") f:SetSize(R(420), R(180)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "ROI DE L'ARÈNE", "MODE", 1, R(20))
	end
	local function pick(mode)
		f:Remove() EVO_INSTRUCTEUR.CloseMenu()
		if EVO_INSTRUCTEUR.OpenKingPicker then EVO_INSTRUCTEUR.OpenKingPicker(mode) end
	end
	EVO_UI.RowButton(f, R(16), R(70), R(388), R(44),
		{ num = "01", label = "1 contre tous · PV ×3", kanji = "王" }, function() pick("gauntlet") end)
	EVO_UI.RowButton(f, R(16), R(116), R(388), R(44),
		{ num = "02", label = "King of the ring · PV ×2", kanji = "帝" }, function() pick("kotr") end)
	closeX(f, 420, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- Renvoie (fnPanneau, libellé) de l'activité instructeur EN COURS lancée par moi (pour le bind/menu),
-- par priorité. Sert au bouton « gérer » du hub ET à la touche bindée.
local function activeManage()
	local E = EVO_INSTRUCTEUR
	if E.IsRefereeingBattle    and E.IsRefereeingBattle()    then return E.OpenBattleManagePanel,  "la bataille" end
	if E.IsRefereeingKing      and E.IsRefereeingKing()      then return E.OpenKingManagePanel,    "l'arène" end
	if E.IsRefereeingInfection and E.IsRefereeingInfection() then return E.OpenInfectionManagePanel, "l'infection" end
	if E.IsRefereeingParryDuel and E.IsRefereeingParryDuel() then return E.OpenParryDuelPanel,     "le duel de parade" end
	if E.IsRefereeingDuel      and E.IsRefereeingDuel()      then return E.OpenDuelRefereePanel,   "le duel" end
	if E.IsInstructorRunningCourse and E.IsInstructorRunningCourse() then return E.OpenCourseManagePanel, "le cours" end
	if E.IsRunningTournament   and E.IsRunningTournament()   then return E.OpenTournamentPanel,    "le tournoi" end
	return nil
end

-- ── Les 7 activités du hub : kanji, description (2 lignes max), chips ────────
local function buildActs()
	return {
		{ label = "Cours de vol", kanji = "飛", portrait = "vol",
			desc = { "Pose un parcours en caméra libre,", "ou charge un preset enregistré." },
			chips = { "AÉRIEN", "CHRONO" },
			run = function() EVO_INSTRUCTEUR.CloseMenu() openCourseSetup("vol") end },
		{ label = "Entraînement à la course", kanji = "走", portrait = "course",
			desc = { "Des anneaux au sol à franchir en", "courant. Chrono et classement." },
			chips = { "SOL", "CHRONO" },
			run = function() EVO_INSTRUCTEUR.CloseMenu() openCourseSetup("flashstep") end },
		{ label = "Tournoi maison", kanji = "闘", portrait = "tournoi",
			desc = { "Solo, duo ou trio : inscris les", "proches, le bracket se gère seul." },
			chips = { "BRACKET", "16 MAX" },
			run = function() EVO_INSTRUCTEUR.CloseMenu() openModeDialog() end },
		{ label = "Duel arbitré 1v1", kanji = "剣", portrait = "duel",
			desc = { "Deux combattants, un ring borné.", "KO sans mort, au meilleur des 3." },
			chips = { "RING", "BO3" },
			run = function()
				EVO_INSTRUCTEUR.CloseMenu()
				if EVO_INSTRUCTEUR.OpenDuelPicker then EVO_INSTRUCTEUR.OpenDuelPicker() end
			end },
		{ label = "Roi de l'arène", kanji = "王", portrait = "roi",
			desc = { "Un contre tous (PV ×3) ou", "King of the ring (PV ×2)." },
			chips = { "ARÈNE", "KO" },
			run = function() EVO_INSTRUCTEUR.CloseMenu() openKingMode() end },
		{ label = "Infection", kanji = "虚", portrait = "infection",
			desc = { "Un infecté chasse au corps à", "corps. Le dernier sain l'emporte." },
			chips = { "TAG", "SURVIE" },
			run = function()
				EVO_INSTRUCTEUR.CloseMenu()
				if EVO_INSTRUCTEUR.OpenInfectionPicker then EVO_INSTRUCTEUR.OpenInfectionPicker() end
			end },
		{ label = "Duel de parade", kanji = "防", portrait = "parade",
			desc = { "Paires en 1v1 : le plus de", "parades parfaites l'emporte." },
			chips = { "TECHNIQUE", "PRÉCISION" },
			run = function()
				EVO_INSTRUCTEUR.CloseMenu()
				if EVO_INSTRUCTEUR.OpenParryDuelPicker then EVO_INSTRUCTEUR.OpenParryDuelPicker() end
			end },
		{ label = "Grande bataille d'entraînement", kanji = "戦", portrait = "duel",
			desc = { "Deux camps de 6 à 10. Le KO", "élimine : dernier camp debout." },
			chips = { "6v6 → 10v10", "ÉLIMINATION" },
			run = function()
				EVO_INSTRUCTEUR.CloseMenu()
				if EVO_INSTRUCTEUR.OpenBattlePicker then EVO_INSTRUCTEUR.OpenBattlePicker() end
			end },
	}
end

function EVO_INSTRUCTEUR.OpenMenu()
	MakeFonts()
	if IsValid(pMenu) then pMenu:Remove() end
	local col = COL()
	local ACTS = buildActs()
	-- Une activité tourne-t-elle déjà (lancée par moi) ? -> rangée « gérer » en bas de liste.
	local mgrFn, mgrLbl = activeManage()

	-- Layout +25% (demande user 06/07).
	local CARD_W = 950
	local LIST_X, LIST_Y, LIST_W, ROW_H = 30, 98, 412, 55
	local nRows = #ACTS + (mgrFn and 1 or 0)
	local bodyH = math.max(nRows * ROW_H, 375)
	local CARD_H = LIST_Y + bodyH + 18 + 45
	local DET_X = LIST_X + LIST_W + 20
	local DET_W = CARD_W - DET_X - 32
	local cardW, cardH = R(CARD_W), R(CARD_H)

	-- Rangée Atelier : puce brush1 (acier -> accent, blanche en sélection) +
	-- libellé Bebas — SANS numéro ni kanji (demande user 06/07). Même patron de
	-- sélection que RowButton (aplat accent + barre blanche).
	local function makeRow(parent, x, y, w, h, label, fill, fn)
		local b = vgui.Create("DButton", parent)
		b:SetText("") b:SetPos(x, y) b:SetSize(w, h)
		b._sel = false
		function b:SetSel(v) self._sel = v end
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, bw, bh)
			local accent = fill or col.accent
			local hf = EVO_UI.HoverFrac(s, 10)
			if s._sel then
				surface.SetDrawColor(accent) surface.DrawRect(0, 0, bw, bh)
				surface.SetDrawColor(255, 255, 255, 230) surface.DrawRect(0, 0, R(2), bh)
			else
				if hf > 0.01 then
					surface.SetDrawColor(ColorAlpha(accent, 26 * hf)) surface.DrawRect(0, 0, bw, bh)
					surface.SetDrawColor(ColorAlpha(accent, 255 * hf)) surface.DrawRect(0, 0, R(2), bh)
				end
				surface.SetDrawColor(ColorAlpha(col.divider, 45)) surface.DrawRect(R(2), bh - 1, bw - R(4), 1)
			end
			local brushPath = (EVO_UI.HasMat("evo_ui/tex/brush1.png") and "evo_ui/tex/brush1.png")
				or (EVO_UI.HasMat(EVO_UI.TexBrush) and EVO_UI.TexBrush or nil)
			if brushPath then
				local c = s._sel and ColorAlpha(color_white, 235)
					or (hf > 0.5 and ColorAlpha(accent, 240) or Color(150, 154, 162, 160))
				EVO_UI.Ink(brushPath, R(12), bh / 2 - R(7), R(24), R(14), c)
			end
			draw.SimpleText(label, "Bebas Neue:24", R(46), bh / 2,
				s._sel and color_white or (hf > 0.01 and col.title or col.muted), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function(s2) surface.PlaySound(EVO_UI.SndClick) if fn then fn(s2) end end
		return b
	end

	local sel = 1

	pMenu = vgui.Create("DFrame")
	pMenu:SetSize(ScrW(), ScrH()) pMenu:SetPos(0, 0)
	pMenu:SetTitle("") pMenu:ShowCloseButton(false) pMenu:SetDraggable(false)
	pMenu:SetPaintBackgroundEnabled(false) pMenu:MakePopup()
	openedFrame = pMenu
	pMenu._a = 0
	pMenu.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	pMenu.OnRemove = function(s) if openedFrame == s then openedFrame = nil end end
	pMenu.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		-- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * a) surface.DrawRect(0, 0, w, h)
	end
	pMenu.OnMousePressed = function() EVO_INSTRUCTEUR.CloseMenu() end

	local rowBtns = {}
	local function pick(i)
		if not ACTS[i] then return end
		sel = i
		for j, b in ipairs(rowBtns) do if IsValid(b) then b:SetSel(j == sel) end end
	end
	local function launch(i)
		local act = ACTS[i or sel]
		if act then act.run() end
	end

	-- Re-presser la touche bindée FERME le menu. Quand le menu a le focus clavier (MakePopup),
	-- la touche n'atteint PAS PlayerButtonDown -> on la capte ICI (comme inventory/skilltree).
	-- On pose une fenêtre _suppressOpenUntil : le PlayerButtonDown du MÊME appui (qui se déclenche
	-- juste après, une fois le focus libéré) ne doit PAS rouvrir aussitôt.
	-- ENTRÉE lance l'activité sélectionnée ; touches 1-8 = sélection directe.
	pMenu.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			EVO_INSTRUCTEUR.CloseMenu() return true
		end
		if key == KEY_ENTER or key == KEY_PAD_ENTER then launch() return true end
		if key >= KEY_1 and key <= KEY_9 then
			local i = key - KEY_1 + 1
			if ACTS[i] then pick(i) return true end
		end
	end

	local card = vgui.Create("DPanel", pMenu)
	card:SetSize(cardW, cardH) card:SetPos((ScrW() - cardW) / 2, (ScrH() - cardH) / 2)
	card:SetMouseInputEnabled(true) card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (IsValid(pMenu) and pMenu._a or 255) / 255
		-- Plaque de métal noir Atelier. DA dashboard 08/07 : plaque plate (plus de liseré acier).
		EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250 * a), R(16))
		-- zangetsu en TRAME FANTÔME : image ENTIÈRE (contain, moins zoomée que le
		-- cover-crop), poussée vers le BAS de la carte (demande user 06/07 : moins
		-- zoomé + descendre). Centrée horizontalement. Alpha 3.
		if EVO_UI.HasMat("evo_ui/chars/zangetsu.png") then
			local m = EVO_UI.Mat("evo_ui/chars/zangetsu.png")
			local iw, ih = m:Width(), m:Height()
			if iw > 0 and ih > 0 then
				-- Contain × facteur d'agrandissement (user : « encore beaucoup plus »).
				-- Ancrée en HAUT (user : « voir plus le haut que le bas ») : le bas
				-- de l'image déborde sous le panneau. Centrée horizontalement, alpha 3.
				local availW, availH = w, h - R(40)
				local sc = math.min(availW / iw, availH / ih) * 2.0
				local rw, rh = iw * sc, ih * sc
				-- Floutée (4 passes en quinconce, demande user 07/07).
				EVO_UI.GhostBlur(m, (w - rw) / 2, R(10), rw, rh, 3 * a)
			end
		end
		-- 4 vis d'angle alignées (retrait 18px uniforme — DA dashboard 08/07).
		local sr = R(5)
		drawScrew(R(18), R(18), sr)
		drawScrew(w - R(18), R(18), sr)
		drawScrew(w - R(18), h - R(18), sr)
		drawScrew(R(18), h - R(18), sr)
		-- Titre Bebas SANS bold + entaille slash1 réduite + filet denté.
		draw.SimpleText("MENU INSTRUCTEUR", "Bebas Neue:38", R(30), R(41), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:38")
		local twT, thT = surface.GetTextSize("MENU INSTRUCTEUR")
		-- Titre CENTER-aligné vertical (Y = R(41)) -> haut du texte = R(41) - thT/2,
		-- donc slash à R(41) + thT*0.78 - thT/2 = R(41) + thT*0.28 (règle réf « BOUTIQUE »).
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(28), R(41) + thT * 0.28, twT * 1.15, R(11), ColorAlpha(col.accent, 245 * a)) then
			surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
			surface.DrawRect(R(30), R(41) + thT * 0.34, twT, math.max(2, R(3)))
		end
		drawDashes(R(30), R(80), w - R(60), Color(255, 255, 255, 26 * a))
		-- filet vertical entre liste et détail
		surface.SetDrawColor(ColorAlpha(col.divider, 110 * a))
		surface.DrawRect(R(DET_X - 10), R(LIST_Y), 1, R(bodyH))
		-- pied : filet denté (kanji 護廷十三隊 RETIRÉ — demande user 06/07)
		drawDashes(R(30), h - R(45), w - R(60), Color(255, 255, 255, 22 * a))
	end

	-- ── Liste (gauche) : rangées Atelier (brush, sans numéros ni kanji) ──
	for i, act in ipairs(ACTS) do
		local b = makeRow(card, R(LIST_X), R(LIST_Y + (i - 1) * ROW_H), R(LIST_W), R(ROW_H),
			act.label, nil, function() pick(i) end)
		b.DoDoubleClick = function() launch(i) end
		rowBtns[i] = b
	end
	if mgrFn then
		makeRow(card, R(LIST_X), R(LIST_Y + #ACTS * ROW_H), R(LIST_W), R(ROW_H),
			"Gérer " .. mgrLbl, col.green, function() EVO_INSTRUCTEUR.CloseMenu() mgrFn() end)
	end
	pick(1)

	-- ── Détail (droite) ──
	local det = vgui.Create("DPanel", card)
	det:SetPos(R(DET_X), R(LIST_Y)) det:SetSize(R(DET_W), R(bodyH))
	det:SetPaintBackground(false)
	det.Paint = function(s, w, h)
		local a = (IsValid(pMenu) and pMenu._a or 255) / 255
		local act = ACTS[sel]
		if not act then return end
		-- Portrait PNG (materials/evo_ui/chars/<portrait>.png) ancré bas-droit ;
		-- si absent, on retombe sur le gros kanji filigrane.
		-- Kanji de l'activité en bas-droit : BLANC, énormément translucide,
		-- calé AU-DESSUS du bouton LANCER (pas derrière — user 06/07), sous le portrait.
		draw.SimpleText(act.kanji or "", "EVO_Instr_KanjiXXL", w - R(4), h - R(56),
			Color(255, 255, 255, 10 * a), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
		local pw, ph = R(262), R(312)
		EVO_UI.Portrait(w - pw, h - ph, pw, ph, act.portrait, 235 * a / 255)
		-- (Étiquette « ACTIVITÉ 01 » RETIRÉE — plus de numéros, demande user 06/07.)
		draw.SimpleText(act.label, "Bebas Neue:40", 0, R(6), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		for li, line in ipairs(act.desc) do
			draw.SimpleText(line, "Avenir Next World:20", 0, R(64 + (li - 1) * 35), ColorAlpha(col.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		local cx = 0
		for _, c in ipairs(act.chips) do
			cx = cx + EVO_UI.Chip(cx, R(152), c, a) + R(8)
		end
	end
	EVO_UI.ActionButton(det, 0, R(bodyH - 50), R(DET_W), R(50), "LANCER", nil, function() launch() end)

	closeX(card, CARD_W, EVO_INSTRUCTEUR.CloseMenu)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pMenu) end
end

concommand.Add("evo_instructeur_open", function()
	if not EVO_INSTRUCTEUR.IsInstructor(LocalPlayer()) then return end
	if EVO_INSTRUCTEUR.PlacementActive then return end -- déjà en mode pose (Échap annule)
	-- BASCULE : si une UI instructeur est déjà ouverte, la touche la FERME (comme les autres UI).
	if IsValid(pMenu) then EVO_INSTRUCTEUR.CloseMenu() return end
	if IsValid(EVO_INSTRUCTEUR._managePanel) then EVO_INSTRUCTEUR._managePanel:Remove() return end
	-- Sinon on ouvre : si une activité tourne (lancée par moi), son panneau de gestion ; sinon le hub.
	local mgrFn = activeManage()
	if mgrFn then mgrFn() return end
	EVO_INSTRUCTEUR.OpenMenu()
end)

-- Ouverture/fermeture via le bind « instructeur_ui » (lzy_bindmenu) : la touche BASCULE le menu.
hook.Add("PlayerButtonDown", "EVO_Instr::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if not ply.GetBindKey then return end
	local k = ply:GetBindKey("instructeur_ui")
	if not (k and k ~= 0 and btn == k) then return end
	if vgui.GetKeyboardFocus() then return end
	if EVO_INSTRUCTEUR.PlacementActive then return end -- en mode pose, c'est Échap qui annule
	-- Vient de fermer via la touche : la fermeture (OnKeyCodePressed) pose _suppressOpenUntil pour
	-- que le PlayerButtonDown du MÊME appui (focus libéré) ne rouvre pas aussitôt.
	if SysTime() < (EVO_INSTRUCTEUR._suppressOpenUntil or 0) then return end
	-- DÉBOUNCE : PlayerButtonDown peut se déclencher 2× pour un seul appui (listen-server).
	if SysTime() - (lastBindAt or 0) < 0.3 then return end
	lastBindAt = SysTime()
	RunConsoleCommand("evo_instructeur_open") -- ouvre (la fermeture se fait via OnKeyCodePressed)
end)
