-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_classement.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — panneau « Classements » (3 onglets : Familles / Joueurs /
-- Entraînement). Ouvert depuis la gestion de faction (bouton à côté de la
-- Banque de division). Les données viennent du serveur (sv_stats.lua) à la
-- demande ; le serveur formate déjà les valeurs en texte.
-- DA v2 « Seireitei » (evo_ui) : carte à coins coupés, onglets et chips carrés,
-- rangs/valeurs en mono, filigrane 王.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

-- Tailles responsives (ratio min largeur/hauteur, comme cl_ui).
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

local function makeFonts()
	-- Les fontes viennent du kit (EVO_UI_*) et de cl_ui (EVO_Instr_*), toutes
	-- responsives ; on s'assure juste que celles du kit existent (hot-reload).
	if EVO_UI.MakeFonts then EVO_UI.MakeFonts() end
end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = EVO_UI.Col
	-- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(34), R(34)) x:SetPos(R(cardW - 46), R(14)) x:SetZPos(1000)
	x:SetCursor("hand")
	x.Paint = function(s, w, h)
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- ── Helpers de dessin DA Atelier (mêmes recettes que le hub) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

-- Onglets : métriques disponibles + libellés.
local TABS = {
	-- Onglet « Clans » RETIRÉ (07/13) : evo_famille est désactivé (remplacé par les
	-- clans FIXES d'evo_clan, sans argent/niveaux agrégés) -> les requêtes famille
	-- ne renverraient que des données mortes. À re-brancher sur evo_clan_members si
	-- un classement de clans revient un jour.
	{ kind = "joueur", label = "Joueurs", faction = true, metrics = {
		{ id = "playtime", label = "Temps de jeu" },
		{ id = "rank",     label = "Grade" },
		{ id = "money",    label = "Yens" },
		{ id = "deaths",   label = "Morts" },
	} },
	{ kind = "entrainement", label = "Entraînement", metrics = {
		{ id = "victories",      label = "Victoires" },
		{ id = "participations", label = "Participations" },
	} },
}

-- Libellé uppercase de l'onglet courant (texte mono à droite du header).
local TAB_UP = { famille = "CLANS", joueur = "JOUEURS", entrainement = "ENTRAÎNEMENT" }

local cur      = { kind = "joueur", metric = "playtime", faction = "Shinigami" }
local rowsData = {}
local loading  = false
local pending  = nil
local listRef            -- DScrollPanel courant
local rebuildRows        -- forward (assignée dans OpenClassement)

local function reqKey(k, m, f) return k .. "|" .. m .. "|" .. (k == "joueur" and f or "-") end

local function request()
	loading  = true
	rowsData = {}
	pending  = reqKey(cur.kind, cur.metric, cur.faction)
	net.Start("EVO:Instr:Class:Req")
		net.WriteString(cur.kind)
		net.WriteString(cur.metric)
		net.WriteString(cur.faction)
	net.SendToServer()
end

net.Receive("EVO:Instr:Class:Res", function()
	local kind    = net.ReadString()
	local metric  = net.ReadString()
	local faction = net.ReadString()
	local n = net.ReadUInt(8)
	local rows = {}
	for i = 1, n do
		local nm = net.ReadString()
		local vl = net.ReadString()
		rows[i] = { name = nm, val = vl }
	end
	-- N'accepte que la réponse correspondant à la sélection courante.
	if reqKey(kind, metric, faction) ~= pending then return end
	rowsData = rows
	loading  = false
	if rebuildRows then rebuildRows() end
end)

function EVO_INSTRUCTEUR.OpenClassement()
	makeFonts()
	if IsValid(EVO_INSTRUCTEUR._classFrame) then EVO_INSTRUCTEUR._classFrame:Remove() end
	if IsValid(EVO_INSTRUCTEUR._classBg) then EVO_INSTRUCTEUR._classBg:Remove() end

	local col = EVO_UI.Col
	local W, H = R(820), R(600)

	-- Fond plein écran DERRIÈRE la carte : mêmes appels que la banque de division
	-- (RNDX.BLUR + voile 5,5,7,216) -> même translucidité perçue (demande user).
	local bg = vgui.Create("DPanel")
	bg:SetSize(ScrW(), ScrH())
	bg:SetPos(0, 0)
	bg._a = 0
	bg.Think = function(s) s._a = Lerp(FrameTime() * 12, s._a, 255) end
	bg.Paint = function(s, w, h)
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * (s._a / 255)) surface.DrawRect(0, 0, w, h)
	end
	EVO_INSTRUCTEUR._classBg = bg

	local f = vgui.Create("DFrame")
	f:SetSize(W, H)
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	EVO_INSTRUCTEUR._classFrame = f
	-- Le fond plein écran part AVEC la carte (Échap, croix, réouverture).
	f.OnRemove = function() if IsValid(bg) then bg:Remove() end end

	f.Paint = function(_, w, h)
		-- Plaque de métal noir Atelier PLATE : coins coupés SANS liseré acier ni
		-- image ; kanji 王 gravé clair, titre Bebas + entaille slash1 réduite + dents.
		EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250), R(16))
		draw.SimpleText("王", "EVO_UI_KanjiXL", w - R(8), h - R(2),
			Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
		local sr = R(5)
		drawScrew(R(10), R(10), sr)
		drawScrew(w - R(28), R(10), sr)
		drawScrew(w - R(10), h - R(10), sr)
		drawScrew(R(28), h - R(10), sr)
		draw.SimpleText("CLASSEMENTS", "Bebas Neue:30", R(24), R(33), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:30")
		local twT, thT = surface.GetTextSize("CLASSEMENTS")
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(22), R(33) + thT * 0.28, twT * 1.15, R(9), ColorAlpha(col.accent, 245)) then
			surface.SetDrawColor(col.accent)
			surface.DrawRect(R(24), R(33) + thT * 0.34, twT, math.max(2, R(3)))
		end
		draw.SimpleText(TAB_UP[cur.kind] or "", "Bebas Neue:20", w - R(56), R(33), col.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		drawDashes(R(24), R(62), w - R(48), Color(255, 255, 255, 26))
		-- pied : filet denté (hint ÉCHAP retiré — DA sans tutos)
		drawDashes(R(24), h - R(36), w - R(48), Color(255, 255, 255, 22))
	end

	closeX(f, 820, function() f:Remove() end)

	-- Conteneur des chips de métrique (reconstruit à chaque changement d'onglet).
	local chipHolder = vgui.Create("DPanel", f)
	chipHolder:SetPos(R(24), R(116))
	chipHolder:SetSize(W - R(48), R(30))
	chipHolder.Paint = function() end

	-- Liste scrollable (s'arrête au-dessus du pied de carte).
	local scroll = vgui.Create("DScrollPanel", f)
	scroll:SetPos(R(24), R(158))
	scroll:SetSize(W - R(48), H - R(158) - R(48))
	listRef = scroll
	local sbar = scroll:GetVBar()
	sbar:SetWide(R(6))
	sbar.Paint = function() end
	sbar.btnUp.Paint = function() end
	sbar.btnDown.Paint = function() end
	sbar.btnGrip.Paint = function(_, w, h) surface.SetDrawColor(col.accent) surface.DrawRect(0, 0, w, h) end

	local tabButtons = {}

	rebuildRows = function()
		if not IsValid(scroll) then return end
		scroll:GetCanvas():Clear()
		local function placeholder(txt)
			local p = scroll:Add("DPanel")
			p:SetTall(R(44)) p:Dock(TOP)
			p.Paint = function(_, w, h) draw.SimpleText(txt, "Bebas Neue:22", w / 2, h / 2, col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
		end
		if loading then placeholder("CHARGEMENT...") return end
		if #rowsData == 0 then placeholder("AUCUNE DONNÉE") return end
		for i, r in ipairs(rowsData) do
			local p = scroll:Add("DPanel")
			p:SetTall(R(40)) p:Dock(TOP) p:DockMargin(0, 0, R(8), 0)
			local rank, name, val = i, r.name, r.val
			p.Paint = function(_, w, h)
				-- Rangée plate : filet 1px en bas, fontes Bebas GROSSES (aussi
				-- lisibles que la banque de division — demande user 06/07).
				surface.SetDrawColor(ColorAlpha(col.divider, 110))
				surface.DrawRect(R(2), h - 1, w - R(4), 1)
				local rc = (rank == 1) and col.accent or (rank <= 3 and col.title or col.dim)
				draw.SimpleText(string.format("%02d", rank), "Bebas Neue:22", R(16), h / 2, rc, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(name, "Bebas Neue:26", R(66), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(val, "Bebas Neue:22", w - R(16), h / 2, col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	-- Rangée des catégories : responsive. Les chips de métrique se PARTAGENT la largeur
	-- dispo (en réservant la zone de droite pour la bascule de faction quand elle existe),
	-- ce qui évite tout chevauchement métriques <-> faction, quelle que soit la résolution.
	local function buildChips()
		chipHolder:Clear()
		local tab
		for _, t in ipairs(TABS) do if t.kind == cur.kind then tab = t break end end
		if not tab then return end

		local holderW = chipHolder:GetWide()
		local gap     = R(8)
		local facBtnW = R(112)
		local facZone = tab.faction and (2 * facBtnW + gap + R(18)) or 0 -- 2 boutons + marge avant les métriques

		local n     = #tab.metrics
		local avail = holderW - facZone
		local bw    = math.Clamp(math.floor((avail - (n - 1) * gap) / n), R(72), R(220))

		local cx = 0
		for _, mt in ipairs(tab.metrics) do
			local id, label = mt.id, mt.label
			local b = vgui.Create("DButton", chipHolder)
			b:SetText("") b:SetSize(bw, R(30)) b:SetPos(cx, 0)
			local labelUp = string.upper(label)
			b.Paint = function(bt, w, h)
				local act = (cur.metric == id)
				local hf = EVO_UI.HoverFrac(bt, 10)
				if act then
					surface.SetDrawColor(col.accent) surface.DrawRect(0, 0, w, h)
				elseif hf > 0.01 then
					surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h)
				end
				surface.SetDrawColor(col.line) surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(labelUp, "Bebas Neue:20", w / 2, h / 2, act and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function() cur.metric = id request() rebuildRows() end
			cx = cx + bw + gap
		end

		-- Bascule de faction, ANCRÉE à droite (onglet Joueurs uniquement).
		if tab.faction then
			local fns = { { id = "Shinigami", label = "Shinigami" }, { id = "Hollow", label = "Hollow" } }
			local fx  = holderW - (2 * facBtnW + gap)
			for _, fn in ipairs(fns) do
				local fid, flab = fn.id, fn.label
				local b = vgui.Create("DButton", chipHolder)
				b:SetText("") b:SetSize(facBtnW, R(30)) b:SetPos(fx, 0)
				local flabUp = string.upper(flab)
				b.Paint = function(bt, w, h)
					local act = (cur.faction == fid)
					local hf = EVO_UI.HoverFrac(bt, 10)
					if act then
						surface.SetDrawColor(col.accent) surface.DrawRect(0, 0, w, h)
					elseif hf > 0.01 then
						surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h)
					end
					surface.SetDrawColor(col.line) surface.DrawOutlinedRect(0, 0, w, h)
					draw.SimpleText(flabUp, "Bebas Neue:20", w / 2, h / 2, act and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				b.DoClick = function() cur.faction = fid request() rebuildRows() end
				fx = fx + facBtnW + gap
			end
		end
	end

	local function selectTab(kind)
		cur.kind = kind
		local tab
		for _, t in ipairs(TABS) do if t.kind == kind then tab = t break end end
		cur.metric = (tab and tab.metrics[1] and tab.metrics[1].id) or "money"
		for _, tb in ipairs(tabButtons) do tb.active = (tb.kind == kind) end
		buildChips()
		request()
		rebuildRows()
	end

	-- Onglets.
	local tx = R(24)
	for _, t in ipairs(TABS) do
		local bw = R(176)
		local kind, label = t.kind, t.label
		local b = vgui.Create("DButton", f)
		b:SetText("") b:SetSize(bw, R(34)) b:SetPos(tx, R(70))
		b.kind = kind
		b.active = (kind == cur.kind)
		b.Paint = function(bt, w, h)
			local hf = EVO_UI.HoverFrac(bt, 10)
			if bt.active then
				EVO_UI.PaintCut(0, 0, w, h, col.accent, R(8), "br")
				draw.SimpleText(label, "Bebas Neue:24", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				if hf > 0.01 then
					surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h)
				end
				surface.SetDrawColor(col.line) surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(label, "Bebas Neue:24", w / 2, h / 2, col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		b.DoClick = function() selectTab(kind) end
		tabButtons[#tabButtons + 1] = b
		tx = tx + bw + R(8)
	end

	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end

	selectTab("joueur") -- onglet Clans retiré (evo_famille désactivé, cf TABS)
end
