-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_infection.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — INFECTION / ZOMBIE, client : zone au sol (3D), HUD
-- (INFECTÉ / SAIN — survis !, sains restants, chrono), marquage des infectés
-- au-dessus de leur tête, picker des participants + panneau de gestion.
-- DA v2 « Seireitei » (evo_ui) : cartes à coins coupés, accent rouge, kanji 虚.
-- ============================================================================

if SERVER then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
-- EVO_UI est toujours chargé (même repo) : on pointe directement sur sa palette.
local function COL() return EVO_UI.Col end

local ev    = nil  -- état réseau courant
local pRef  = nil  -- panneau de gestion (instructeur)

-- Nom lisible de la touche bindée (pour les rappels HUD).
local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- L'instructeur arbitre-t-il une infection EN COURS ?
function EVO_INSTRUCTEUR.IsRefereeingInfection()
	return ev ~= nil and ev.active and ev.isInstr == true and ev.status ~= "done"
end

-- ── Zone au sol : helper PARTAGÉ (EVO_INSTRUCTEUR.DrawGroundRing, cl_ui.lua). ──
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::InfectZone", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (ev and ev.active and ev.zonePos) then return end
	if ev._farHidden then return end -- même règle que le HUD (cf. HudFarHidden)
	local col = COL()
	local pulse = 0.75 + math.sin(CurTime() * 3) * 0.25
	local c = (ev.status == "running") and col.accent or col.muted
	EVO_INSTRUCTEUR.DrawGroundRing(ev.zonePos, ev.zoneRadius or 1200, ColorAlpha(c, 230 * pulse))

	-- Marquage des infectés : nom rouge au-dessus de leur tête.
	if ev.infected then
		for _, inf in ipairs(ev.infected) do
			local p = player.GetBySteamID64 and player.GetBySteamID64(inf.sid)
			if IsValid(p) and p:Alive() then
				local pos = p:GetPos() + Vector(0, 0, 82)
				cam.Start3D2D(pos, Angle(0, (pos - EyePos()):Angle().y - 90, 90), 0.18)
					draw.SimpleText("☣ " .. (inf.name or "Infecté"), "EVO_Instr_TBtn", 0, 0, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				cam.End3D2D()
			end
		end
	end
end)

-- ── HUD ───────────────────────────────────────────────────────────────────────
hook.Add("HUDPaint", "EVO_Instr::InfectHUD", function()
	if not (ev and ev.active) then return end
	-- Rayon de VUE dérivé du rayon de JEU (réglable par l'organisateur) : avec la
	-- constante de config, une grande zone masquait le HUD aux joueurs au bord.
	if EVO_INSTRUCTEUR.HudFarHidden(ev, ev.zonePos, EVO_INSTRUCTEUR.InfectionViewRadius(ev.zoneRadius),
		ev.isInstr or ev.iAmIn) then return end
	local col = COL()
	local W = R(560)
	local x, y = ScrW() / 2 - W / 2, EVO_INSTRUCTEUR.HudTopY()
	local H = R(86)
	surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(col.line) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, W, R(3))

	draw.SimpleText("INFECTION  ·  " .. (ev.instr or ""), "EVO_Instr_Small", x + W / 2, y + R(10), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- État personnel.
	local myState, myCol
	if ev.iAmIn then
		if ev.iAmInfected then myState, myCol = "INFECTÉ — contamine les sains !", col.accent
		else myState, myCol = "SAIN — survis !", col.green end
	else
		myState, myCol = "Spectateur", col.muted
	end
	draw.SimpleText(myState, "EVO_Instr_TBtn", x + W / 2, y + R(36), myCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Sains restants + chrono / vainqueur.
	local bottom
	if ev.status == "done" then
		bottom = (ev.winnerName ~= "" and ("VAINQUEUR : " .. ev.winnerName)) or "Tous infectés"
	else
		bottom = "Sains restants : " .. (ev.sane or 0) .. " / " .. (ev.total or 0)
		-- Limite de temps (optionnelle) : tenir jusqu'à 00:00 = victoire.
		if ev.timeEnd then
			local rem = math.max(0, ev.timeEnd - CurTime())
			bottom = bottom .. "   ·   " .. string.format("%02d:%02d", math.floor(rem / 60), math.floor(rem % 60))
		end
	end
	-- Compteur en mono (kit) ; le nom du vainqueur reste en texte courant.
	draw.SimpleText(bottom, ev.status == "done" and "EVO_Instr_Small" or "EVO_UI_Mono", x + W / 2, y + R(64), ev.status == "done" and col.green or col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Bannière de fin au centre.
	if ev.status == "done" then
		-- « SURVIVANT(S) » et pas « DERNIER SURVIVANT » : avec une limite de temps,
		-- tous ceux encore sains à 00:00 gagnent ensemble.
		local txt = (ev.winnerName ~= "") and ("SURVIVANT(S) : " .. ev.winnerName) or "TOUS INFECTÉS"
		draw.SimpleTextOutlined(txt, "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
	end

	-- Rappel instructeur.
	if ev.isInstr and ev.status ~= "done" then
		draw.SimpleText("Instructeur : [" .. bindKeyName() .. "] pour gérer (annuler l'infection)", "EVO_Instr_Small", ScrW() / 2, y + H + R(6), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau de gestion (instructeur) ──────────────────────────────────────────
function EVO_INSTRUCTEUR.OpenInfectionManagePanel()
	if not EVO_INSTRUCTEUR.IsRefereeingInfection() then return end
	if IsValid(pRef) then pRef:Remove() end
	local col = COL()
	local W, H = 420, 268
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			f:Remove() return true
		end
	end
	-- Rayon de travail : initialisé sur celui de la partie, puis modifié localement
	-- par les paliers. Chaque changement est envoyé tout de suite (pas de « valider »).
	local ZONES = EVO_INSTRUCTEUR.Config.InfectionZonePresets
	local iZone = 1
	for i, r in ipairs(ZONES) do if ev and ev.zoneRadius and r <= ev.zoneRadius then iZone = i end end

	local function sendZone(bRecenter)
		net.Start("EVO:Instr:Infect:Zone")
			net.WriteUInt(ZONES[iZone], 16)
			net.WriteBool(bRecenter == true)
		net.SendToServer()
	end

	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "GÉRER L'INFECTION", "EN COURS", 1, R(20))
		draw.SimpleText((ev and ("Sains restants : " .. (ev.sane or 0) .. " / " .. (ev.total or 0))) or "", "EVO_UI_Mono", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- Chrono restant, s'il y a une limite de temps.
		if ev and ev.timeEnd then
			local rem = math.max(0, ev.timeEnd - CurTime())
			draw.SimpleText(string.format("%02d:%02d", math.floor(rem / 60), math.floor(rem % 60)),
				"EVO_UI_Mono", R(W - 20), R(74), col.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("ZONE DE JEU", "EVO_Instr_Small", R(20), R(108), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(ZONES[iZone] .. " u", "EVO_UI_Mono", R(W / 2), R(146), col.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeX(f, W, function() f:Remove() end)

	-- Rétrécir / élargir : le levier d'animation (resserrer la zone pour forcer le contact).
	EVO_UI.ActionButton(f, R(24), R(128), R(56), R(36), "−", nil, function()
		if iZone > 1 then iZone = iZone - 1 sendZone(false) end
	end)
	EVO_UI.ActionButton(f, R(W - 80), R(128), R(56), R(36), "+", nil, function()
		if iZone < #ZONES then iZone = iZone + 1 sendZone(false) end
	end)
	EVO_UI.ActionButton(f, R(24), R(174), R(W - 48), R(36), "RECENTRER LA ZONE SUR MOI", nil, function()
		sendZone(true)
	end)

	EVO_UI.ActionButton(f, R(24), R(216), R(W - 48), R(36), "ANNULER L'INFECTION", nil, function()
		net.Start("EVO:Instr:Infect:Cancel") net.SendToServer() f:Remove()
	end)

	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Picker des participants (instructeur) ─────────────────────────────────────
function EVO_INSTRUCTEUR.OpenInfectionPicker()
	if not EVO_INSTRUCTEUR.RequestNearby then return end
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		local col = COL()
		if #list < 2 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Il faut au moins 2 joueurs proches pour une infection.", NOTIFY_ERROR or 1, 4) end
			return
		end
		local listH = math.Clamp(#list * 30, 60, 300)
		-- 3 rangées de réglage (JE JOUE AUSSI / ZONE / DURÉE) entre la liste et les boutons.
		local W, H = 440, 248 + listH
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		local checks, order = {}, {}
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Header(w, "INFECTION", "PARTICIPANTS", 1, R(20))
			EVO_UI.Watermark(w, h, "虚", 1)
			local n = #order
			draw.SimpleText(n > 0 and (n .. " sélectionné(s) · 1er = infecté de départ") or "Aucun = tous les proches (infecté aléatoire)", "EVO_Instr_Small", R(20), R(72), n > 0 and col.green or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(88)) scroll:SetSize(R(W - 40), R(listH))
		for _, p in ipairs(list) do
			checks[p.sid] = false
			local row = scroll:Add(vgui.Create("DButton")) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(28)) row:SetText("")
			row.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
			row.Paint = function(s, w, h)
				local idx = 0
				for i = 1, #order do if order[i] == p.sid then idx = i break end end
				local on = checks[p.sid] == true
				local hf = EVO_UI.HoverFrac(s, 10)
				if on then
					-- 1er coché = infecté de départ : rangée pleine accent ; les autres en accent léger.
					surface.SetDrawColor(ColorAlpha(col.accent, idx == 1 and 235 or 60))
					surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(255, 255, 255, 230)
					surface.DrawRect(0, 0, R(2), h)
				else
					if hf > 0.01 then
						surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h)
						surface.SetDrawColor(ColorAlpha(col.accent, 255 * hf)) surface.DrawRect(0, 0, R(2), h)
					end
					surface.SetDrawColor(ColorAlpha(col.divider, 110))
					surface.DrawRect(R(2), h - 1, w - R(4), 1)
				end
				draw.SimpleText(p.name, "EVO_Instr_Small", R(12), h / 2, (on and idx == 1) and color_white or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if idx == 1 then
					draw.SimpleText("INFECTÉ", "EVO_UI_Mono", w - R(10), h / 2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				elseif on then
					draw.SimpleText(string.format("%02d", idx), "EVO_UI_Mono", w - R(10), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			row.DoClick = function()
				if checks[p.sid] then
					checks[p.sid] = false
					for i = #order, 1, -1 do if order[i] == p.sid then table.remove(order, i) end end
				else
					checks[p.sid] = true
					order[#order + 1] = p.sid
				end
			end
		end

		-- L'ORGANISATEUR JOUE-T-IL ? (demande user 08/09). Par défaut OUI : c'était la
		-- demande. Le décocher rend le mode arbitre, comme les cinq autres events.
		local bJoin = true
		local joinRow = vgui.Create("DButton", f)
		joinRow:SetPos(R(20), R(88 + listH + 6))
		joinRow:SetSize(R(W - 40), R(28))
		joinRow:SetText("")
		joinRow.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		joinRow.Paint = function(s, w, h)
			if bJoin then
				surface.SetDrawColor(ColorAlpha(col.accent, 60)) surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 255, 255, 230) surface.DrawRect(0, 0, R(2), h)
			else
				local hf = EVO_UI.HoverFrac(s, 10)
				if hf > 0.01 then surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h) end
			end
			surface.SetDrawColor(ColorAlpha(col.divider, 110)) surface.DrawRect(R(2), h - 1, w - R(4), 1)
			draw.SimpleText("JE JOUE AUSSI", "EVO_Instr_Small", R(12), h / 2,
				bJoin and col.green or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(bJoin and "OUI" or "NON · J'ARBITRE", "EVO_UI_Mono", w - R(10), h / 2,
				bJoin and col.green or col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		joinRow.DoClick = function() bJoin = not bJoin end

		-- ── ZONE + DURÉE : rangées à défilement (clic = palier suivant, clic droit =
		-- précédent). Mêmes visuels que « JE JOUE AUSSI » ; les paliers viennent de
		-- sh_config, le serveur reborne de toute façon.
		local ZONES, TIMES = EVO_INSTRUCTEUR.Config.InfectionZonePresets, EVO_INSTRUCTEUR.Config.InfectionTimePresets
		local iZone, iTime = 1, 1
		for i, r in ipairs(ZONES) do if r <= EVO_INSTRUCTEUR.Config.Infection.ZoneRadius then iZone = i end end

		local function settingRow(y, sLabel, fValue)
			local row = vgui.Create("DButton", f)
			row:SetPos(R(20), R(y)) row:SetSize(R(W - 40), R(28)) row:SetText("")
			row.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
			row.Paint = function(s, w, h)
				local hf = EVO_UI.HoverFrac(s, 10)
				if hf > 0.01 then
					surface.SetDrawColor(ColorAlpha(col.accent, 26 * hf)) surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(ColorAlpha(col.accent, 255 * hf)) surface.DrawRect(0, 0, R(2), h)
				end
				surface.SetDrawColor(ColorAlpha(col.divider, 110)) surface.DrawRect(R(2), h - 1, w - R(4), 1)
				draw.SimpleText(sLabel, "EVO_Instr_Small", R(12), h / 2, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(fValue(), "EVO_UI_Mono", w - R(10), h / 2, col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			return row
		end

		-- Clic droit = palier précédent : sans ça, revenir en arrière demande de
		-- refaire tout le tour de la liste.
		local function cycler(row, fGet, fSet, nMax)
			row.DoClick = function() fSet(fGet() % nMax + 1) end
			-- On INTERCEPTE le clic droit sans le transmettre à la base (pas de
			-- Depressed / DoClick), le clic gauche est chaîné tel quel.
			local fBasePressed = row.OnMousePressed
			row.OnMousePressed = function(s, m)
				if m == MOUSE_RIGHT then fSet((fGet() - 2) % nMax + 1) return end
				if fBasePressed then return fBasePressed(s, m) end
			end
		end

		local zoneRow = settingRow(88 + listH + 38, "TAILLE DE LA ZONE", function() return ZONES[iZone] .. " u" end)
		cycler(zoneRow, function() return iZone end, function(v) iZone = v end, #ZONES)

		local timeRow = settingRow(88 + listH + 70, "LIMITE DE TEMPS", function()
			local t = TIMES[iTime]
			if t == 0 then return "AUCUNE" end
			return string.format("%d min", math.floor(t / 60)) .. ((t % 60 > 0) and string.format(" %02d", t % 60) or "")
		end)
		cycler(timeRow, function() return iTime end, function(v) iTime = v end, #TIMES)

		local function launch(ids)
			net.Start("EVO:Instr:Infect:Create") net.WriteUInt(#ids, 8)
				for _, id in ipairs(ids) do net.WriteString(id) end
			net.WriteBool(bJoin) -- lu APRÈS les ids côté serveur (ordre net strict)
			net.WriteUInt(ZONES[iZone], 16)
			net.WriteUInt(TIMES[iTime], 16)
			net.SendToServer()
			f:Remove()
			if EVO_INSTRUCTEUR.CloseMenu then EVO_INSTRUCTEUR.CloseMenu() end
		end

		local halfW = (W - 40) / 2
		EVO_UI.ActionButton(f, R(20), R(H - 50), R(halfW - 4), R(36), "LANCER LA SÉLECTION", col.green, function()
			-- 3 = le minimum SERVEUR (hors organisateur) : à 2, le serveur refusait
			-- sans que le client prévienne.
			if #order < 3 then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Sélectionne au moins 3 joueurs, ou utilise « Tous les proches ».", NOTIFY_ERROR or 1, 3) end
				return
			end
			launch(order)
		end)

		EVO_UI.ActionButton(f, R(20 + halfW + 4), R(H - 50), R(halfW - 4), R(36), "TOUS LES PROCHES", nil, function() launch({}) end)

		closeX(f, W, function() f:Remove() end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ── NET : sync de l'infection (lecture STRICTEMENT dans l'ordre serveur). ─────
net.Receive("EVO:Instr:Infect:Sync", function()
	if not net.ReadBool() then
		ev = nil
		EVO_INSTRUCTEUR.SetEventRing("infection", nil)
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local d = { active = true }
	d.status      = net.ReadString()
	d.instr       = net.ReadString()
	d.zonePos     = net.ReadVector()
	d.zoneRadius  = net.ReadUInt(16)
	d.sane        = net.ReadUInt(6)
	d.total       = net.ReadUInt(6)
	d.phase       = net.ReadFloat()
	-- Limite de temps restante (0 = aucune). On la convertit en échéance LOCALE : le
	-- sync n'arrive qu'au changement d'état / battement 1 s, un affichage direct
	-- sauterait de seconde en seconde au lieu de s'écouler.
	d.timeLeft    = net.ReadFloat()
	d.timeEnd     = (d.timeLeft > 0) and (CurTime() + d.timeLeft) or nil
	d.iAmIn       = net.ReadBool()
	d.iAmInfected = net.ReadBool()
	d.winnerName  = net.ReadString()
	local nInf = net.ReadUInt(6)
	d.infected = {}
	for i = 1, nInf do
		local sid = net.ReadString()
		local name = net.ReadString()
		d.infected[#d.infected + 1] = { sid = sid, name = name }
	end
	d.isInstr     = net.ReadBool()
	ev = d
	EVO_INSTRUCTEUR.SetEventRing("infection", d.zonePos, d.zoneRadius)
	if d.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
