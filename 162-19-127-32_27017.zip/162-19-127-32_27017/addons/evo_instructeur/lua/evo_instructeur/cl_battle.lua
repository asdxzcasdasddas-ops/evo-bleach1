-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_battle.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — GRANDE BATAILLE D'ENTRAÎNEMENT, client (6v6 → 10x10).
--   • Picker de composition : clic sur un joueur = ROUGE → BLEU → non assigné,
--     plus un bouton « Répartir au hasard » (ne touche QUE les non-assignés, pour
--     ne pas effacer une composition faite à la main).
--   • Marqueur au-dessus de la tête de chaque combattant, coloré selon TON camp :
--     vert = allié, rouge = adversaire, gris barré = éliminé. L'instructeur, qui
--     arbitre sans camp, voit chaque équipe à sa couleur.
--   • HUD : effectifs restants par camp, chrono, état perso, décompte géant.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

local bat  = nil  -- état réseau du module
local pRef = nil  -- panneau de gestion (instructeur)

local function CFG()  return EVO_INSTRUCTEUR.Config and EVO_INSTRUCTEUR.Config.Battle or {} end
local function TEAM(i)
	local t = EVO_INSTRUCTEUR.Config and EVO_INSTRUCTEUR.Config.BattleTeams
	return (t and t[i]) or { name = "?", color = Color(200, 200, 200) }
end

-- Couleurs de marqueur hoistées (0 alloc/frame — règle projet).
local COL_ALLY  = Color(86, 204, 128)
local COL_ENEMY = Color(214, 76, 82)
local COL_DEAD  = Color(120, 122, 130)

local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- L'instructeur arbitre-t-il une bataille EN COURS ? (menu + touche)
function EVO_INSTRUCTEUR.IsRefereeingBattle()
	return bat ~= nil and bat.active and bat.isInstr == true and bat.status ~= "done"
end

-- ── Ring au sol (helper partagé). ───────────────────────────────────────────
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::BattleRing", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (bat and bat.active and bat.ringPos) then return end
	if bat._farHidden then return end -- même règle que le HUD (cf. HudFarHidden)
	local col = COL()
	local pulse = 0.75 + math.sin(CurTime() * 3) * 0.25
	local c = (bat.status == "fighting") and col.accent or col.muted
	EVO_INSTRUCTEUR.DrawGroundRing(bat.ringPos, bat.ringRadius or 1800, ColorAlpha(c, 230 * pulse))
end)

-- ── Marqueurs au-dessus des têtes : allié / adversaire / éliminé. ──────────
-- Même recette que le marquage des infectés (cam.Start3D2D billboardé), mais la
-- COULEUR dépend du camp du spectateur : c'est tout l'intérêt demandé (« voir si
-- ils sont avec nous ou pas »). L'arbitre n'a pas de camp -> couleur d'équipe.
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::BattleTags", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (bat and bat.active and bat.roster) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local myTeam = bat.myTeam -- nil pour l'arbitre / un spectateur

	for _, m in ipairs(bat.roster) do
		local p = player.GetBySteamID64 and player.GetBySteamID64(m.sid)
		if IsValid(p) and p ~= lp then
			local c, prefix
			if not m.alive then
				c, prefix = COL_DEAD, "✖ "
			elseif myTeam then
				local bAlly = (m.team == myTeam)
				c, prefix = (bAlly and COL_ALLY or COL_ENEMY), (bAlly and "▲ " or "▼ ")
			else
				c, prefix = TEAM(m.team).color, "● "
			end
			local pos = p:GetPos() + Vector(0, 0, 82)
			cam.Start3D2D(pos, Angle(0, (pos - EyePos()):Angle().y - 90, 90), 0.18)
				draw.SimpleText(prefix .. (m.name or "?"), "EVO_Instr_TBtn", 0, 0, c, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cam.End3D2D()
		end
	end
end)

-- ── Aura de camp sur les CORPS (08/19, demande user) : allié = halo VERT,
-- adversaire = halo ROUGE ; l'arbitre / un spectateur voit chaque camp à sa
-- couleur d'équipe. Petite aura discrète (1 passe), PAS à travers les murs
-- (ignoreZ false : ce n'est pas un ESP). Les éliminés n'ont pas d'aura (leur
-- marqueur ✖ suffit). Tables réutilisées : 0 alloc/frame (règle projet).
local tHaloA, tHaloB = {}, {}
hook.Add("PreDrawHalos", "EVO_Instr::BattleAuras", function()
	if not (bat and bat.active and bat.roster) then return end
	if bat._farHidden then return end
	if IsCinematicActive and IsCinematicActive() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	for i = #tHaloA, 1, -1 do tHaloA[i] = nil end
	for i = #tHaloB, 1, -1 do tHaloB[i] = nil end

	-- Combattant : A = mes alliés (vert), B = mes adversaires (rouge).
	-- Arbitre/spectateur : A = équipe 1, B = équipe 2, aux couleurs d'équipe.
	local myTeam = bat.myTeam
	local cA = myTeam and COL_ALLY  or TEAM(1).color
	local cB = myTeam and COL_ENEMY or TEAM(2).color

	for _, m in ipairs(bat.roster) do
		if m.alive then
			local p = player.GetBySteamID64 and player.GetBySteamID64(m.sid)
			if IsValid(p) and p ~= lp and p:Alive() then
				local bInA = myTeam and (m.team == myTeam) or (not myTeam and m.team == 1)
				if bInA then tHaloA[#tHaloA + 1] = p else tHaloB[#tHaloB + 1] = p end
			end
		end
	end

	if #tHaloA > 0 then halo.Add(tHaloA, cA, 3, 3, 1, true, false) end
	if #tHaloB > 0 then halo.Add(tHaloB, cB, 3, 3, 1, true, false) end
end)

-- ── HUD ─────────────────────────────────────────────────────────────────────
local function fmtTime(s)
	s = math.max(0, math.floor(s or 0))
	return string.format("%d:%02d", math.floor(s / 60), s % 60)
end

hook.Add("HUDPaint", "EVO_Instr::BattleHUD", function()
	if not (bat and bat.active) then return end
	if EVO_INSTRUCTEUR.HudFarHidden(bat, bat.ringPos, EVO_INSTRUCTEUR.Config.Battle.SpectateRadius,
		bat.isInstr or bat.myTeam ~= nil) then return end
	local col = COL()
	local W = R(620)
	local x, y = ScrW() / 2 - W / 2, EVO_INSTRUCTEUR.HudTopY()
	local H = R(104)
	surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.line, 255)) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, W, R(3))

	draw.SimpleText("GRANDE BATAILLE  ·  " .. (bat.size or 0) .. "v" .. (bat.size or 0) .. "  ·  " .. (bat.instr or ""),
		"EVO_Instr_Small", x + W / 2, y + R(10), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Effectifs restants : camp 1 à gauche, camp 2 à droite, chacun à sa couleur.
	local t1, t2 = TEAM(1), TEAM(2)
	draw.SimpleText(t1.name, "EVO_Instr_Small", x + R(20), y + R(36), t1.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(t2.name, "EVO_Instr_Small", x + W - R(20), y + R(36), t2.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	draw.SimpleText(tostring(bat.alive1 or 0), "EVO_UI_Header", x + R(20), y + R(52), t1.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(tostring(bat.alive2 or 0), "EVO_UI_Header", x + W - R(20), y + R(52), t2.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	draw.SimpleText("VS", "EVO_Instr_TBtn", x + W / 2, y + R(52), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Morts par camp (08/19, demande user : le verdict se lit en morts) : sous
	-- l'effectif restant de chaque côté.
	local d1 = math.max(0, (bat.size or 0) - (bat.alive1 or 0))
	local d2 = math.max(0, (bat.size or 0) - (bat.alive2 or 0))
	draw.SimpleText(d1 .. (d1 > 1 and " morts" or " mort"), "EVO_Instr_Small", x + R(20), y + R(80), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(d2 .. (d2 > 1 and " morts" or " mort"), "EVO_Instr_Small", x + W - R(20), y + R(80), col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

	-- Chrono au centre, sous le VS (décompté en LOCAL depuis le dernier sync).
	-- Fonte moyenne (08/19 : il était en Small, illisible pour un compte à rebours).
	if bat.status ~= "done" then
		local left = math.max(0, (bat.timeEnd or 0) - CurTime())
		draw.SimpleText(fmtTime(left), "EVO_Instr_TBtn", x + W / 2, y + R(76),
			left < 30 and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- État personnel (combattant uniquement).
	local myState, myCol
	if bat.myTeam then
		if bat.iAmAlive then myState, myCol = "EN VIE — équipe " .. TEAM(bat.myTeam).name, col.green
		else myState, myCol = "ÉLIMINÉ — tu restes à terre", col.accent end
	elseif bat.isInstr then
		myState, myCol = "Arbitre", col.muted
	end
	if myState then
		draw.SimpleText(myState, "EVO_Instr_Small", x + W / 2, y + H + R(6), myCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Décompte géant / résultat.
	if bat.status == "countdown" then
		local n = math.ceil((bat.phaseEnd or 0) - CurTime())
		if n > 0 then
			draw.SimpleTextOutlined(tostring(n), "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	elseif bat.status == "fighting" then
		-- Dernières secondes : compte à rebours géant au centre (08/19, demande user).
		local left = math.max(0, (bat.timeEnd or 0) - CurTime())
		if left > 0 and left <= 10 then
			draw.SimpleTextOutlined(tostring(math.ceil(left)), "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	elseif bat.status == "done" then
		local c = (bat.winner or 0) > 0 and TEAM(bat.winner).color or col.muted
		draw.SimpleTextOutlined((bat.resultText ~= "" and bat.resultText) or "Terminé", "EVO_UI_Header",
			ScrW() / 2, ScrH() * 0.4, c, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
	end

	if bat.isInstr and bat.status ~= "done" then
		draw.SimpleText("Instructeur · [" .. bindKeyName() .. "] pour gérer (annuler)", "EVO_Instr_Small",
			ScrW() / 2, y + H + R(24), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau de gestion (instructeur) ────────────────────────────────────────
function EVO_INSTRUCTEUR.OpenBattleManagePanel()
	if not EVO_INSTRUCTEUR.IsRefereeingBattle() then return end
	if IsValid(pRef) then pRef:Remove() end
	local col = COL()
	local W, H = 420, 152
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			f:Remove() return true
		end
	end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "GÉRER LA BATAILLE", (bat and ((bat.size or 0) .. "v" .. (bat.size or 0))) or "", 1, R(20))
		local line = bat and (TEAM(1).name .. " " .. (bat.alive1 or 0) .. "  —  " .. TEAM(2).name .. " " .. (bat.alive2 or 0)) or ""
		draw.SimpleText(line, "EVO_UI_Mono", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	EVO_UI.ActionButton(f, R(20), R(96), R(W - 40), R(40), "ANNULER LA BATAILLE", nil, function()
		net.Start("EVO:Instr:Battle:Cancel") net.SendToServer() f:Remove()
	end)
	closeX(f, W, function() f:Remove() end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Picker de composition des camps (instructeur) ───────────────────────────
function EVO_INSTRUCTEUR.OpenBattlePicker()
	if not EVO_INSTRUCTEUR.RequestNearby then return end
	local cfg = CFG()
	local tMin, tMax = cfg.TeamMin or 6, cfg.TeamMax or 10

	EVO_INSTRUCTEUR.RequestNearby(function(list)
		local col = COL()
		if #list < tMin * 2 then
			if MUGEN and MUGEN.AddNotification then
				MUGEN.AddNotification("Il faut au moins " .. (tMin * 2) .. " joueurs proches (" .. #list .. " trouvé(s)).", NOTIFY_ERROR or 1, 5)
			end
			return
		end
		if IsValid(EVO_INSTRUCTEUR._pickerPanel) then EVO_INSTRUCTEUR._pickerPanel:Remove() end

		local assign = {}  -- [sid] = 1 | 2 | nil
		local listH = math.Clamp(#list * 32, 120, 420)
		-- 248 = en-tête (132) + liste + 12 de gouttière + 2 rangées de boutons + marge basse.
		-- À 224 la liste (qui commence à 132) débordait de 12 sur la 1re rangée de boutons.
		local W, H = 480, 248 + listH
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		f.OnKeyCodePressed = function(s, key)
			local lp = LocalPlayer()
			if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
				EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
				f:Remove() return true
			end
		end

		local function counts()
			local a, b = 0, 0
			for _, t in pairs(assign) do
				if t == 1 then a = a + 1 elseif t == 2 then b = b + 1 end
			end
			return a, b
		end

		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Watermark(w, h, "戦", 1)
			EVO_UI.Header(w, "GRANDE BATAILLE", tMin .. "v" .. tMin .. " → " .. tMax .. "v" .. tMax, 1, R(20))
			local a, b = counts()
			local t1, t2 = TEAM(1), TEAM(2)
			draw.SimpleText(t1.name .. " : " .. a, "EVO_Instr_TBtn", R(20), R(74), t1.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(t2.name .. " : " .. b, "EVO_Instr_TBtn", w - R(20), R(74), t2.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			-- Diagnostic live : dit POURQUOI le bouton refuse, plutôt qu'un bouton mort.
			local msg, c
			if a ~= b then msg, c = "Les deux camps doivent avoir le même effectif.", col.accent
			elseif a < tMin then msg, c = "Encore " .. (tMin - a) .. " joueur(s) par camp.", col.muted
			elseif a > tMax then msg, c = "Maximum " .. tMax .. " par camp.", col.accent
			else msg, c = "Prêt : " .. a .. "v" .. b .. ".", col.green end
			draw.SimpleText(msg, "EVO_Instr_Small", w / 2, R(98), c, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Clic : Rouge → Bleu → aucun", "EVO_Instr_Small", w / 2, R(116), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(132)) scroll:SetSize(R(W - 40), R(listH))
		local rows = {}
		for i, p in ipairs(list) do
			local b = vgui.Create("DButton", scroll)
			b:SetText("") b:Dock(TOP) b:DockMargin(0, 0, 0, R(4)) b:SetTall(R(28))
			b.OnCursorEntered = function() if EVO_UI and EVO_UI.SndHover then surface.PlaySound(EVO_UI.SndHover) end end
			b.Paint = function(s, w, h)
				local t = assign[p.sid]
				local c = t and TEAM(t).color or col.dim
				if t then
					surface.SetDrawColor(ColorAlpha(c, 26)) surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(c) surface.DrawRect(0, 0, R(3), h)
				elseif s:IsHovered() then
					surface.SetDrawColor(ColorAlpha(col.title, 12)) surface.DrawRect(0, 0, w, h)
				end
				draw.SimpleText(p.name, "EVO_Instr_TBtn", R(12), h / 2, t and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(t and TEAM(t).name or "-", "EVO_Instr_Small", w - R(12), h / 2, c, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				local t = assign[p.sid]
				-- Cycle Rouge → Bleu → aucun, en refusant de dépasser TeamMax.
				local a, bb = counts()
				if t == nil then
					if a < tMax then assign[p.sid] = 1 elseif bb < tMax then assign[p.sid] = 2 end
				elseif t == 1 then
					assign[p.sid] = (bb < tMax) and 2 or nil
				else
					assign[p.sid] = nil
				end
				if EVO_UI and EVO_UI.SndClick then surface.PlaySound(EVO_UI.SndClick) end
			end
			rows[p.sid] = b
		end

		-- Répartition aléatoire : ne touche QUE les non-assignés (sinon le bouton
		-- effacerait la composition manuelle en cours), et remplit en alternant le
		-- camp le moins fourni -> camps équilibrés.
		EVO_UI.ActionButton(f, R(20), R(H - 104), R((W - 48) / 2), R(36), "RÉPARTIR AU HASARD", nil, function()
			local pool = {}
			for _, p in ipairs(list) do
				if assign[p.sid] == nil then pool[#pool + 1] = p.sid end
			end
			for i = #pool, 2, -1 do -- Fisher-Yates
				local j = math.random(i)
				pool[i], pool[j] = pool[j], pool[i]
			end
			for _, sid in ipairs(pool) do
				local a, b = counts()
				if a >= tMax and b >= tMax then break end
				if a <= b and a < tMax then assign[sid] = 1
				elseif b < tMax then assign[sid] = 2 end
			end
		end)

		EVO_UI.ActionButton(f, R(20) + R((W - 48) / 2) + R(8), R(H - 104), R((W - 48) / 2), R(36), "TOUT VIDER", nil, function()
			assign = {}
		end)

		EVO_UI.ActionButton(f, R(20), R(H - 56), R(W - 40), R(40), "LANCER LA BATAILLE", col.green, function()
			local a, b = counts()
			if a ~= b or a < tMin or a > tMax then
				if MUGEN and MUGEN.AddNotification then
					MUGEN.AddNotification("Deux camps égaux de " .. tMin .. " à " .. tMax .. " joueurs.", NOTIFY_ERROR or 1, 4)
				end
				return
			end
			local A, B = {}, {}
			for sid, t in pairs(assign) do
				if t == 1 then A[#A + 1] = sid elseif t == 2 then B[#B + 1] = sid end
			end
			net.Start("EVO:Instr:Battle:Create")
				net.WriteUInt(#A, 6)
				for _, sid in ipairs(A) do net.WriteString(sid) end
				net.WriteUInt(#B, 6)
				for _, sid in ipairs(B) do net.WriteString(sid) end
			net.SendToServer()
			f:Remove()
			if EVO_INSTRUCTEUR.CloseMenu then EVO_INSTRUCTEUR.CloseMenu() end
		end)

		closeX(f, W, function() f:Remove() end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ── NET : sync du module (symétrie STRICTE avec sv_battle.lua). ─────────────
net.Receive("EVO:Instr:Battle:Sync", function()
	if not net.ReadBool() then                                   -- 1er champ : actif
		bat = nil
		EVO_INSTRUCTEUR.SetEventRing("battle", nil)
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local b = { active = true }
	b.status     = net.ReadString()
	b.instr      = net.ReadString()
	b.ringPos    = net.ReadVector()
	b.ringRadius = net.ReadUInt(16)
	b.alive1     = net.ReadUInt(6)
	b.alive2     = net.ReadUInt(6)
	b.size       = net.ReadUInt(6)
	b.phase      = net.ReadFloat()
	b.timeLeft   = net.ReadFloat()
	b.resultText = net.ReadString()
	b.winner     = net.ReadUInt(2)
	b.roster     = {}
	local n = net.ReadUInt(6)
	for i = 1, n do
		local sid   = net.ReadString()
		local team  = net.ReadUInt(2)
		local alive = net.ReadBool()
		-- Nom résolu CÔTÉ CLIENT (nom RP), comme les nametags : rien à faire transiter.
		local p = player.GetBySteamID64 and player.GetBySteamID64(sid)
		local nm = IsValid(p) and ((p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname")) or p:Nick()) or "?"
		b.roster[#b.roster + 1] = { sid = sid, team = team, alive = alive, name = nm }
	end
	b.isInstr = net.ReadBool()                                   -- DERNIER champ

	-- Mon camp / mon état : déduits du roster (le serveur n'a rien à personnaliser).
	local lp = LocalPlayer()
	local mySid = IsValid(lp) and lp:SteamID64() or nil
	for _, m in ipairs(b.roster) do
		if m.sid == mySid then b.myTeam, b.iAmAlive = m.team, m.alive break end
	end

	b.phaseEnd = CurTime() + (b.phase or 0) -- décompte LOCAL (pas de re-sync en countdown)
	b.timeEnd  = CurTime() + (b.timeLeft or 0) -- chrono LOCAL : le serveur ne sync qu'1×/s
	bat = b
	EVO_INSTRUCTEUR.SetEventRing("battle", b.ringPos, b.ringRadius)
	if b.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
