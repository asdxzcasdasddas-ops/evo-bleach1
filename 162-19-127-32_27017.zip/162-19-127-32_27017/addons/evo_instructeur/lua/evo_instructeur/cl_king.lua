-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_king.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — ROI DE L'ARÈNE, client : ring au sol (3D), HUD (mode, nom
-- du champion/king, série/roi, adversaire, chrono), picker du champion (avec mode),
-- panneau de gestion (Annuler), aura + marqueur sur la CIBLE du champion. 2 sous-modes :
-- "gauntlet" (1 contre tous) et
-- "kotr" (winner-stays-on). DA v2 « Seireitei » (evo_ui) : cartes à coins
-- coupés, accent rouge unique, kanji 王 en filigrane sur le picker.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

local king  = nil  -- état réseau du module
local pRef  = nil  -- panneau de gestion (instructeur)

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- Nom lisible de la touche bindée (rappels HUD).
local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- L'instructeur arbitre-t-il un Roi de l'arène EN COURS ? (menu + touche)
function EVO_INSTRUCTEUR.IsRefereeingKing()
	return king ~= nil and king.active and king.isInstr == true and king.status ~= "done"
end

-- ── Ring au sol : helper PARTAGÉ (EVO_INSTRUCTEUR.DrawGroundRing, cl_ui.lua). ──
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::KingRing", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (king and king.active and king.ringPos) then return end
	if king._farHidden then return end -- même règle que le HUD (cf. HudFarHidden)
	local col = COL()
	local pulse = 0.75 + math.sin(CurTime() * 3) * 0.25
	local c = (king.status == "fighting") and col.accent or col.muted
	-- Repli sur la config partagée (l'ancien 700 en dur mentait depuis les élargissements).
	EVO_INSTRUCTEUR.DrawGroundRing(king.ringPos, king.ringRadius or EVO_INSTRUCTEUR.Config.King.RingRadius,
		ColorAlpha(c, 230 * pulse))
end)

-- ── LA CIBLE DU CHAMPION (demande user 08/30) ────────────────────────────────
-- Dans une foule on ne savait pas QUI le champion affronte : le HUD ne donnait
-- qu'un nom. On marque donc le corps de la cible, recette de cl_battle (aura
-- halo + étiquette 3D2D billboardée), en AMBRE : le ring au sol et l'accent de la
-- DA sont déjà rouges, une aura rouge s'y noierait.
-- Aura PAS à travers les murs (ignoreZ false) : c'est un repère d'arbitrage, pas un ESP.
local COL_CIBLE = Color(255, 176, 64)
local colCible  = Color(255, 176, 64) -- mutée au dessin (pulsation) : 0 alloc/frame
local tHaloCible = {}
local vTag, angTag = Vector(), Angle(0, 0, 90)

-- La cible n'existe QUE pendant un bout (décompte ou combat).
local function cibleActive()
	if not (king and king.active) then return nil end
	if king._farHidden then return nil end
	if king.status ~= "fighting" and king.status ~= "countdown" then return nil end
	local e = king.oppEnt
	if not (IsValid(e) and e:IsPlayer() and e:Alive()) then return nil end
	if e == LocalPlayer() then return nil end -- inutile de se marquer soi-même
	return e
end

hook.Add("PreDrawHalos", "EVO_Instr::KingCibleAura", function()
	local e = cibleActive()
	if not e then return end
	if IsCinematicActive and IsCinematicActive() then return end
	local p = 0.7 + math.sin(CurTime() * 6) * 0.3
	colCible.r, colCible.g, colCible.b = COL_CIBLE.r * p, COL_CIBLE.g * p, COL_CIBLE.b * p
	for i = #tHaloCible, 1, -1 do tHaloCible[i] = nil end
	tHaloCible[1] = e
	halo.Add(tHaloCible, colCible, 4, 4, 2, true, false)
end)

hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::KingCibleTag", function(bDepth, bSky)
	if bDepth or bSky then return end
	local e = cibleActive()
	if not e then return end
	-- Vecteur et angle REUTILISES : un marqueur dessine a chaque frame ne doit pas
	-- allouer (regle perf maison). Le yaw est calcule a la main pour eviter le
	-- Vector de soustraction + l Angle intermediaires.
	local o, ep = e:GetPos(), EyePos()
	vTag.x, vTag.y, vTag.z = o.x, o.y, o.z + 82
	angTag.y = math.deg(math.atan2(vTag.y - ep.y, vTag.x - ep.x)) - 90
	cam.Start3D2D(vTag, angTag, 0.18)
		draw.SimpleText("▼ CIBLE", "EVO_Instr_TBtn", 0, -12, COL_CIBLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(king.oppName ~= "" and king.oppName or "?", "EVO_Instr_Small", 0, 8, COL_CIBLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end)

-- ── HUD ──────────────────────────────────────────────────────────────────────
local function hpBar(x, y, w, h, frac, col)
	surface.SetDrawColor(ColorAlpha(color_white, 22))
	surface.DrawRect(x, y, w, h)
	local fw = math.max(0, math.min(1, frac or 0)) * w
	local c = (frac > 0.5 and col.green) or (frac > 0.25 and Color(220, 180, 70)) or col.accent
	if fw > 1 then surface.SetDrawColor(c) surface.DrawRect(x, y, fw, h) end
end

local function fmtTime(s)
	s = math.max(0, math.floor(s or 0))
	return string.format("%d:%02d", math.floor(s / 60), s % 60)
end

hook.Add("HUDPaint", "EVO_Instr::KingHUD", function()
	if not (king and king.active) then return end
	-- Pas d'auto-détection combattant : champion/challenger sont DANS le ring,
	-- donc toujours dans le rayon — seul l'instructeur suit de loin.
	if EVO_INSTRUCTEUR.HudFarHidden(king, king.ringPos, EVO_INSTRUCTEUR.Config.King.SpectateRadius,
		king.isInstr) then return end
	local col = COL()
	local W = R(560)
	local x, y = ScrW() / 2 - W / 2, EVO_INSTRUCTEUR.HudTopY()
	local H = R(100)
	-- Fond plat + liseré 1px + barre d'accent (DA v2, pas d'arrondi).
	surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.line, 255)) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, W, R(3))

	local modeLbl = (king.mode == "gauntlet") and "1 CONTRE TOUS" or "ROI DE LA COLLINE"
	draw.SimpleText("ROI DE L'ARÈNE  ·  " .. modeLbl .. "  ·  " .. (king.instr or ""), "EVO_Instr_Small", x + W / 2, y + R(10), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Champion / Roi à gauche, adversaire à droite.
	local champLabel = (king.mode == "gauntlet") and "CHAMPION" or "ROI"
	draw.SimpleText(champLabel .. " : " .. (king.champName or "?"), "EVO_Instr_TBtn", x + R(20), y + R(34), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText((king.oppName ~= "" and king.oppName) or "?", "EVO_Instr_TBtn", x + W - R(20), y + R(34), col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

	-- Centre : série (gauntlet) ou "Roi" (kotr).
	if king.mode == "gauntlet" then
		draw.SimpleText("Série : " .. (king.streak or 0), "EVO_UI_Header", x + W / 2, y + R(40), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText("Roi : " .. (king.champName or "?"), "EVO_Instr_TText", x + W / 2, y + R(40), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Barre de vie du CHAMPION UNIQUEMENT (demande user : on ne montre QUE sa barre, pas celle des
	-- challengers). Pleine largeur du panneau pour qu'elle soit clairement la sienne.
	hpBar(x + R(20), y + R(62), W - R(40), R(12), king.hpChamp, col)

	-- Ligne d'état + file + chrono (centre bas du panneau).
	local status = ""
	if king.status == "countdown" then status = "Préparez-vous : " .. (king.oppName ~= "" and king.oppName or "?")
	elseif king.status == "fighting" then status = "COMBAT" .. ((king.oppName ~= "") and (" vs " .. king.oppName) or "")
	elseif king.status == "waiting" then status = "En attente d'un challenger…"
	elseif king.status == "done" then status = (king.resultText ~= "" and king.resultText) or "Terminé" end
	if king.status ~= "done" and (king.queue or 0) > 0 then status = status .. "  ·  File : " .. king.queue end
	draw.SimpleText(status, "EVO_Instr_Small", x + W / 2, y + R(82), king.status == "done" and col.green or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Chrono (gauntlet uniquement) en haut à droite du panneau.
	if king.mode == "gauntlet" and king.status ~= "done" then
		local left = math.max(0, (king.deadlineEnd or 0) - CurTime())
		draw.SimpleText(fmtTime(left), "EVO_Instr_TBtn", x + W - R(20), y + R(10), left < 30 and col.accent or col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	end

	-- Décompte géant au centre de l'écran.
	if king.status == "countdown" then
		local n = math.ceil((king.phaseEnd or 0) - CurTime())
		if n > 0 then
			draw.SimpleTextOutlined(tostring(n), "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	elseif king.status == "done" then
		draw.SimpleTextOutlined((king.resultText ~= "" and king.resultText) or "Terminé", "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
	end

	-- Rappel instructeur.
	if king.isInstr and king.status ~= "done" then
		draw.SimpleText("Instructeur · [" .. bindKeyName() .. "] pour gérer (annuler)", "EVO_Instr_Small", ScrW() / 2, y + H + R(6), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau de gestion (instructeur) ─────────────────────────────────────────
function EVO_INSTRUCTEUR.OpenKingManagePanel()
	if not EVO_INSTRUCTEUR.IsRefereeingKing() then return end
	if IsValid(pRef) then pRef:Remove() end
	local col = COL()
	local W, H = 420, 152
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			f:Remove() return true
		end
	end
	local modeLbl = (king and king.mode == "gauntlet") and "1 CONTRE TOUS" or "ROI DE LA COLLINE"
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "GÉRER L'ARÈNE", modeLbl, 1, R(20))
		-- Détail dynamique (série / roi) : relu chaque frame, il évolue via le sync.
		local extra = ""
		if king then
			extra = (king.mode == "gauntlet") and ("SÉRIE " .. (king.streak or 0)) or ("ROI : " .. (king.champName or "?"))
		end
		draw.SimpleText(extra, "EVO_UI_Mono", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	EVO_UI.ActionButton(f, R(20), R(96), R(W - 40), R(40), "ANNULER L'ÉVÉNEMENT", nil, function()
		net.Start("EVO:Instr:King:Cancel") net.SendToServer() f:Remove()
	end)
	closeX(f, W, function() f:Remove() end)

	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Picker du champion (instructeur) — mode passé en argument. ───────────────
function EVO_INSTRUCTEUR.OpenKingPicker(mode)
	if not EVO_INSTRUCTEUR.RequestNearby then return end
	mode = (mode == "kotr") and "kotr" or "gauntlet"
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		local col = COL()
		if #list < 1 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Il faut au moins un joueur proche.", NOTIFY_ERROR or 1, 4) end
			return
		end
		local modeLbl = (mode == "gauntlet") and "1 CONTRE TOUS" or "ROI DE LA COLLINE"
		local listH = math.Clamp(#list * 30, 60, 240)
		local W, H = 420, 156 + listH
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		local selected = nil
		f.OnKeyCodePressed = function(s, key)
			local lp = LocalPlayer()
			if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
				EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
				f:Remove() return true
			end
		end
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Watermark(w, h, "王", 1)
			EVO_UI.Header(w, "ROI DE L'ARÈNE", modeLbl, 1, R(20))
			draw.SimpleText(selected and "Champion choisi" or "Choisis le champion de départ", "EVO_Instr_Small", R(20), R(72), selected and col.green or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(88)) scroll:SetSize(R(W - 40), R(listH))
		-- Rangées kit : clic = sélection (re-clic = désélection), visuel via SetSel.
		local rows = {}
		for i, p in ipairs(list) do
			local row = EVO_UI.RowButton(scroll, 0, 0, R(W - 40), R(28),
				{ num = string.format("%02d", i), label = p.name },
				function()
					selected = (selected == p.sid) and nil or p.sid
					for sid, r in pairs(rows) do if IsValid(r) then r:SetSel(selected == sid) end end
				end)
			row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(28))
			rows[p.sid] = row
		end
		EVO_UI.ActionButton(f, R(20), R(H - 56), R(W - 40), R(40), "LANCER L'ÉVÉNEMENT", col.green, function()
			if not selected then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Sélectionne un champion.", NOTIFY_ERROR or 1, 3) end
				return
			end
			net.Start("EVO:Instr:King:Create")
				net.WriteString(mode)
				net.WriteString(selected)
			net.SendToServer()
			f:Remove()
			if EVO_INSTRUCTEUR.CloseMenu then EVO_INSTRUCTEUR.CloseMenu() end
		end)
		closeX(f, W, function() f:Remove() end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ── NET : sync du module (symétrie STRICTE avec sv_king.lua). ────────────────
net.Receive("EVO:Instr:King:Sync", function()
	if not net.ReadBool() then                                  -- 1er champ : actif
		king = nil
		EVO_INSTRUCTEUR.SetEventRing("king", nil)
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local k = { active = true }
	k.mode       = net.ReadString()
	k.status     = net.ReadString()
	k.instr      = net.ReadString()
	k.champName  = net.ReadString()
	k.oppName    = net.ReadString()
	k.oppEnt     = net.ReadEntity() -- la cible (NULL hors combat / hors PVS)
	k.streak     = net.ReadUInt(12)
	k.queue      = net.ReadUInt(8)
	k.ringPos    = net.ReadVector()
	k.ringRadius = net.ReadUInt(16)
	k.hpChamp    = net.ReadFloat()
	k.hpOpp      = net.ReadFloat()
	k.phase      = net.ReadFloat()
	k.timeLeft   = net.ReadFloat()
	k.resultText = net.ReadString()
	k.isInstr    = net.ReadBool()                               -- DERNIER champ
	k.phaseEnd   = CurTime() + (k.phase or 0) -- decompte LOCAL (serveur ne re-sync pas en countdown)
	k.deadlineEnd = CurTime() + (k.timeLeft or 0) -- chrono gauntlet local (heartbeat serveur 1s)
	king = k
	EVO_INSTRUCTEUR.SetEventRing("king", k.ringPos, k.ringRadius)
	if k.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
