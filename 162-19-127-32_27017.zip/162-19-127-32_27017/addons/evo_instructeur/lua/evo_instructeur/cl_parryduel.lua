-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_parryduel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — DUEL DE PARADE, client : ring au sol (3D), HUD (adversaire +
-- tes parades parfaites + chrono), picker des combattants (appariement aléatoire
-- ou manuel 2 par 2) + panneau de gestion (paires + scores live, Lancer/Annuler).
-- DA v2 « Seireitei » (evo_ui) : cartes à coins coupés, accent rouge, kanji 防.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

local pd   = nil  -- { active, status, instr, ringPos, ringRadius, phase, oppName, myScore, oppScore, pairs = {{aName,bName,sa,sb}}, isInstr }
local pRef = nil  -- panneau de gestion (instructeur)

-- Nom lisible de la touche bindée (rappels HUD).
local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- L'instructeur arbitre-t-il un duel de parade EN COURS ?
function EVO_INSTRUCTEUR.IsRefereeingParryDuel()
	return pd ~= nil and pd.active and pd.isInstr == true and pd.status ~= "done"
end

-- ── Ring au sol : helper PARTAGÉ (EVO_INSTRUCTEUR.DrawGroundRing, cl_ui.lua). ──
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::ParryRing", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (pd and pd.active and pd.ringPos) then return end
	if pd._farHidden then return end -- même règle que le HUD (cf. HudFarHidden)
	local col = COL()
	local pulse = 0.75 + math.sin(CurTime() * 3) * 0.25
	local c = (pd.status == "fighting") and col.accent or col.muted
	EVO_INSTRUCTEUR.DrawGroundRing(pd.ringPos, pd.ringRadius or 800, ColorAlpha(c, 230 * pulse))
end)

-- ── HUD (participants + spectateurs + instructeur) ─────────────────────────────
hook.Add("HUDPaint", "EVO_Instr::ParryHUD", function()
	if not (pd and pd.active) then return end
	if EVO_INSTRUCTEUR.HudFarHidden(pd, pd.ringPos, EVO_INSTRUCTEUR.Config.Parry.SpectateRadius,
		pd.isInstr or (pd.oppName or "") ~= "") then return end
	local col = COL()
	local W = R(560)
	local x, y = ScrW() / 2 - W / 2, EVO_INSTRUCTEUR.HudTopY()
	local H = R(96)
	surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.line, 255)) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, W, R(3))

	local roundTxt = (pd.status ~= "registering") and ("  ·  Manche " .. (pd.round or 1) .. "/" .. (pd.maxRounds or 2)) or ""
	draw.SimpleText("DUEL DE PARADE" .. roundTxt .. "  ·  " .. (pd.instr or ""), "EVO_Instr_Small", x + W / 2, y + R(10), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- État / chrono central.
	local chronoTxt, chronoCol
	if pd.status == "fighting" then
		local left = math.max(0, (pd.phaseEnd or 0) - CurTime())
		chronoTxt = math.ceil(left) .. "s"
		chronoCol = col.accent
	elseif pd.status == "countdown" then chronoTxt = "PRÉPAREZ-VOUS" chronoCol = col.accent
	elseif pd.status == "registering" then chronoTxt = "En attente du départ" chronoCol = col.muted
	else chronoTxt = "Terminé" chronoCol = col.muted end
	draw.SimpleText(chronoTxt, "EVO_UI_Header", x + W / 2, y + R(40), chronoCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Décompte 3,2,1 GÉANT au centre de l'écran (avant chaque manche) — compté localement.
	if pd.status == "countdown" and pd.phaseEnd then
		local n = math.ceil(pd.phaseEnd - CurTime())
		if n > 0 then
			draw.SimpleTextOutlined(tostring(n), "EVO_UI_Big", ScrW() / 2, ScrH() * 0.4, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	end

	-- "ADVERSAIRE : X" + "Tes parades parfaites : N" (uniquement pour les participants).
	if pd.oppName and pd.oppName ~= "" then
		if pd.amAttacker then
			draw.SimpleText("TON ROLE : ATTAQUANT", "EVO_Instr_TBtn", x + R(20), y + R(34), col.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Donne des coups a " .. pd.oppName .. " - il doit les PARER.", "EVO_Instr_Small", x + R(20), y + R(60), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Parades de " .. pd.oppName .. " : " .. (pd.oppScore or 0), "EVO_Instr_Small", x + W - R(20), y + R(34), col.muted, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		else
			draw.SimpleText("TON ROLE : PARE", "EVO_Instr_TBtn", x + R(20), y + R(34), col.green, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Pare les coups de " .. pd.oppName .. ".", "EVO_Instr_Small", x + R(20), y + R(60), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Tes parades parfaites : " .. (pd.myScore or 0), "EVO_Instr_TBtn", x + W - R(20), y + R(34), col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
	elseif pd.isInstr then
		draw.SimpleText("Arbitre · " .. (#(pd.pairs or {})) .. " paire(s)", "EVO_Instr_TBtn", x + W / 2, y + R(60), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end

	-- Instructeur : la liste des paires + scores, à gauche de l'écran (mono).
	if pd.isInstr and pd.pairs then
		local lx, ly = R(24), R(180)
		draw.SimpleText("PAIRES · SCORES", "EVO_UI_Mono", lx, ly, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		ly = ly + R(22)
		for _, p2 in ipairs(pd.pairs) do
			local lead = (p2.sa ~= p2.sb) and col.green or col.muted -- les 2 marquent (manche chacun) -> on montre les 2 scores
			draw.SimpleText((p2.aName or "A") .. "  " .. (p2.sa or 0) .. " - " .. (p2.sb or 0) .. "  " .. (p2.bName or "B"),
				"EVO_UI_Mono", lx, ly, lead, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			ly = ly + R(20)
		end
	end

	-- Rappel instructeur.
	if pd.isInstr and pd.status ~= "done" then
		draw.SimpleText("Arbitre · [" .. bindKeyName() .. "] pour gérer (lancer / annuler)", "EVO_Instr_Small", ScrW() / 2, y + H + R(6), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau de gestion (instructeur) ──────────────────────────────────────────
function EVO_INSTRUCTEUR.OpenParryDuelPanel()
	if not EVO_INSTRUCTEUR.IsRefereeingParryDuel() then return end
	if IsValid(pRef) then pRef:Remove() end
	local col = COL()
	local nPairs = #(pd.pairs or {})
	local W, H = 440, 162 + math.Clamp(nPairs * 26, 26, 260) + 60
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.OnKeyCodePressed = function(s, key)
		if LocalPlayer().GetBindKey and key == LocalPlayer():GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			f:Remove() return true
		end
	end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Watermark(w, h, "防", 1)
		EVO_UI.Header(w, "DUEL DE PARADE", "ARBITRE", 1, R(20))
		local st = pd and pd.status or ""
		local fightLeft = (st == "fighting") and math.ceil(math.max(0, (pd.phaseEnd or 0) - CurTime())) or 0
		local stTxt = (st == "registering" and "Prêt à lancer")
			or (st == "countdown" and ("Manche " .. (pd.round or 1) .. " · 3, 2, 1…"))
			or (st == "fighting" and ("Manche " .. (pd.round or 1) .. " · " .. fightLeft .. "s"))
			or "Terminé"
		draw.SimpleText(stTxt, "EVO_UI_Mono", R(20), R(72), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- Paires + scores live (score de parade en mono, à droite).
		local ly = R(96)
		for _, p2 in ipairs((pd and pd.pairs) or {}) do
			draw.SimpleText((p2.aName or "A") .. " attaque  ->  " .. (p2.bName or "B") .. " pare",
				"EVO_Instr_TText", R(20), ly, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(tostring(p2.sb or 0), "EVO_UI_Mono", w - R(20), ly, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			ly = ly + R(26)
		end
	end
	closeX(f, W, function() f:Remove() end)

	-- Lancer (seulement en inscription) + Annuler.
	if pd and pd.status == "registering" then
		EVO_UI.ActionButton(f, R(24), R(H - 96), R(W - 48), R(40), "LANCER LE DUEL", col.green, function()
			net.Start("EVO:Instr:Parry:Start") net.SendToServer()
		end)
	end
	EVO_UI.ActionButton(f, R(24), R(H - 50), R(W - 48), R(40), "ANNULER LE DUEL", nil, function()
		net.Start("EVO:Instr:Parry:Cancel") net.SendToServer() f:Remove()
	end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Picker des combattants (instructeur) : N joueurs (pair) + appariement aléa/manuel ──
function EVO_INSTRUCTEUR.OpenParryDuelPicker()
	if not EVO_INSTRUCTEUR.RequestNearby then return end
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		local col = COL()
		if #list < 2 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Il faut au moins 2 joueurs proches.", NOTIFY_ERROR or 1, 4) end
			return
		end
		local listH = math.Clamp(#list * 30, 60, 280)
		local W, H = 440, 164 + listH
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		local checks, order = {}, {}  -- order = ordre de sélection (sert à l'appariement manuel 2 par 2)
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Header(w, "DUEL DE PARADE", "COMBATTANTS", 1, R(20))
			local n = #order
			local ok = (n >= 2 and n % 2 == 0)
			draw.SimpleText(n .. " sélectionné(s)" .. (n % 2 == 1 and "  (impair !)" or "") .. "  ·  par paire : 1er attaque, 2e pare", "EVO_Instr_Small", R(20), R(70), ok and col.green or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(84)) scroll:SetSize(R(W - 40), R(listH))
		for _, p in ipairs(list) do
			checks[p.sid] = false
			local row = scroll:Add(vgui.Create("DButton")) row:Dock(TOP) row:DockMargin(0, 0, 0, R(4)) row:SetTall(R(28)) row:SetText("")
			row.Paint = function(s, w, h)
				if checks[p.sid] then
					-- Sélectionné : fond teinté accent + barre à gauche (pattern RowButton).
					surface.SetDrawColor(ColorAlpha(col.accent, 36)) surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(col.accent) surface.DrawRect(0, 0, R(2), h)
				else
					surface.SetDrawColor(ColorAlpha(color_white, s:IsHovered() and 16 or 8)) surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(ColorAlpha(col.divider, 110)) surface.DrawRect(R(2), h - 1, w - R(4), 1)
				end
				-- Numéro d'ordre (pour visualiser l'appariement manuel 1-2 / 3-4 / ...).
				local idx = 0 for i = 1, #order do if order[i] == p.sid then idx = i break end end
				draw.SimpleText(p.name, "EVO_Instr_Small", R(10), h / 2, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(idx > 0 and ("#" .. idx) or "", "EVO_UI_Mono", w - R(12), h / 2, col.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function()
				if checks[p.sid] then
					checks[p.sid] = false
					for i = #order, 1, -1 do if order[i] == p.sid then table.remove(order, i) end end
				else
					checks[p.sid] = true
					order[#order + 1] = p.sid
				end
			end
		end
		-- Envoie la sélection : randomMode = true (aléatoire) ou false (manuel, ordre 2 par 2).
		local function send(randomMode)
			local n = #order
			if n < 2 or n % 2 == 1 then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Sélectionne un nombre PAIR (>= 2) de combattants.", NOTIFY_ERROR or 1, 3) end
				return
			end
			net.Start("EVO:Instr:Parry:Create")
				net.WriteUInt(n, 8)
				for _, id in ipairs(order) do net.WriteString(id) end
				net.WriteBool(randomMode)
			net.SendToServer()
			f:Remove()
			if EVO_INSTRUCTEUR.CloseMenu then EVO_INSTRUCTEUR.CloseMenu() end
			-- Pas d'auto-ouverture du panneau : l'instructeur reste LIBRE ; il l'ouvre via le bind pour lancer.
		end
		local halfW = (W - 56) / 2
		EVO_UI.ActionButton(f, R(24), R(H - 48), R(halfW), R(36), "PAIRES ALÉATOIRES", col.green, function() send(true) end)
		EVO_UI.ActionButton(f, R(24 + halfW + 8), R(H - 48), R(halfW), R(36), "PAIRES MANUELLES", nil, function() send(false) end)
		closeX(f, W, function() f:Remove() end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ── NET : sync du duel de parade (lecture STRICTEMENT dans l'ordre d'écriture serveur). ──
net.Receive("EVO:Instr:Parry:Sync", function()
	if not net.ReadBool() then
		pd = nil
		EVO_INSTRUCTEUR.SetEventRing("parryduel", nil)
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local d = { active = true }
	d.status     = net.ReadString()
	d.instr      = net.ReadString()
	d.ringPos    = net.ReadVector()
	d.ringRadius = net.ReadUInt(16)
	d.round      = net.ReadUInt(4)
	d.maxRounds  = net.ReadUInt(4)
	d.phase      = net.ReadFloat()
	d.oppName    = net.ReadString()
	d.myScore    = net.ReadUInt(8)
	d.oppScore   = net.ReadUInt(8)
	d.amAttacker = net.ReadBool()
	local nP     = net.ReadUInt(8)
	d.pairs = {}
	for i = 1, nP do
		local p2 = {}
		p2.aName = net.ReadString()
		p2.bName = net.ReadString()
		p2.sa    = net.ReadUInt(8)
		p2.sb    = net.ReadUInt(8)
		d.pairs[#d.pairs + 1] = p2
	end
	d.isInstr = net.ReadBool()
	-- Décompte / chrono LOCAL (serveur heartbeat 1s ; phase = seconds remaining at sync).
	d.phaseEnd = CurTime() + (d.phase or 0)
	pd = d
	EVO_INSTRUCTEUR.SetEventRing("parryduel", d.ringPos, d.ringRadius)
	if d.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
