-- "addons\\evo_instructeur\\lua\\evo_instructeur\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — config partagée (client + serveur).
--   À partir du grade 6 (FactionRank), un joueur devient INSTRUCTEUR : il peut
--   ouvrir le « Menu Instructeur » (bind), et organiser pour les joueurs proches :
--     • un COURS DE VOL    : checkpoints posés en CAMÉRA LIBRE (dans un rayon borné),
--                            à franchir en vol, avec chrono + classement.
--     • un COURS DE FLASHSTEP : checkpoints posés AU SOL (viseur), au sol, mêmes
--                            chrono + classement.
--     • un TOURNOI MAISON  : inscription des joueurs proches, l'instructeur entre
--                            les scores, chaque participant voit son adversaire.
-- ============================================================================

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local C = {}
EVO_INSTRUCTEUR.Config = C

-- Grade minimum (FactionRank) pour être instructeur. Revalidé SERVEUR sur chaque action.
C.MinGrade = 6 -- 8 -> 6 (demande user 08/01)

-- ── Cours (vol / flashstep) ─────────────────────────────────────────────────
C.Course = {
	Vol = {
		Label            = "Cours de vol",
		PlaceRadius      = 12000, -- rayon MAX de pose des checkpoints autour du départ (cam libre bornée) — ×2 le 08/07 (« trop petit »)
		CheckpointRadius = 320,   -- GROS cerceau vertical (= rayon de validation : on doit passer dedans)
		MaxCheckpoints   = 12,
		FreeCam          = true,  -- pose en caméra libre (en l'air)
		RequireFly       = true,  -- l'élève doit être en vol pour franchir (sinon simple proximité)
	},
	Flashstep = {
		Label            = "Entraînement à la course", -- (id interne reste "flashstep")
		PlaceRadius      = 8000,  -- ×2 le 08/07 (« trop petit »)
		CheckpointRadius = 280,   -- GROS cerceau VERTICAL posé au sol (on le traverse en courant) ; rayon de validation un peu + tolérant
		MaxCheckpoints   = 12,
		FreeCam          = false, -- pose au sol via le viseur (pas de cam libre)
		RequireFly       = false,
	},
	InviteRadius = 1400,  -- rayon d'invitation des élèves autour de l'instructeur
	MaxStudents  = 16,
}

-- ── Tournoi maison ──────────────────────────────────────────────────────────
C.Tournament = {
	InviteRadius    = 1400,
	MaxParticipants = 16,
}

-- ── Duel arbitré 1v1 ─────────────────────────────────────────────────────────
-- L'instructeur choisit 2 combattants proches, un ring borné s'ouvre sous lui ; KO SANS MORT
-- (réutilise ncm_ko_system), best-of-3, vainqueur de manche détecté au KO ; soin + repositionnement
-- entre les manches. L'arbitre peut forcer le vainqueur d'une manche ou annuler.
C.Duel = {
	InviteRadius   = 1400,  -- rayon pour choisir les combattants
	RingRadius     = 1200,  -- rayon du ring AU SOL (600 -> 1200 le 10/04 : un coup projetait hors ring)
	SpectateRadius = 2500,  -- qui voit le ring + le tableau de score
	WinRounds      = 2,     -- premier à N manches (best-of-3)
	CountdownSec   = 4,     -- décompte avant chaque manche (combattants figés)
	RoundResetSec  = 4,     -- pause entre 2 manches (soin + repositionnement)
	OutOfBoundsSec = 8,     -- temps hors-ring toléré (5 -> 8 le 10/04), en pause si projeté/au sol/gelé
	TimeLimit      = 180,   -- limite de temps du duel (s) : au bout, vainqueur au score (sinon nul)
}

-- ── Grande bataille d'entraînement (6v6 → 10v10) ────────────────────────────
-- Deux camps, ÉLIMINATION DIRECTE : être KO = éliminé, on reste au sol jusqu'à la fin
-- (pas de réa, pas de give-up, pas de finisher — verrouillé via les hooks EVO::KO::Block*).
-- Rayons élargis vs les autres modes : il faut réunir jusqu'à 20 combattants.
C.Battle = {
	InviteRadius   = 3000,  -- rayon de recrutement (1400 ailleurs : trop serré pour 20 joueurs)
	SpectateRadius = 5500,  -- qui voit le ring, le HUD et les marqueurs de camp
	RingRadius     = 5000,  -- 1800 -> 3000 -> 5000 (08/01, valeur exacte demandée par le user)
	TeamMin        = 6,     -- 6v6 minimum
	TeamMax        = 10,    -- 10v10 maximum
	CountdownSec   = 5,     -- combattants figés le temps que chacun se place
	OutOfBoundsSec = 8,     -- hors du ring trop longtemps = éliminé
	TimeLimit      = 300,   -- au bout : le camp avec le plus de survivants l'emporte
	DoneSec        = 10,    -- affichage du résultat avant nettoyage
}

-- ── Rayons de suivi des AUTRES events (partagés : le client masque lui-même son
-- HUD hors rayon, cf. EVO_INSTRUCTEUR.HudFarHidden). Ces valeurs vivaient en
-- local serveur (sv_king / sv_infection / sv_parryduel) ; les sv les lisent ici.
-- Ring du roi de l'arene DOUBLE le 08/09 (demande user) : 2500 -> 5000. RingRadius
-- vivait en local serveur (sv_king.lua) donc introuvable « dans la config » : remonte
-- ici, meme patron que C.Battle. SpectateRadius DOIT rester > RingRadius, sinon un
-- combattant au bord de sa propre arene perd HUD + cercle (cl_king.lua masque tout
-- hors rayon et n'exempte que l'instructeur).
C.King      = { RingRadius = 5000, SpectateRadius = 5500 }
-- Zone d'infection DOUBLEE le 08/09 (demande user) : 6000 -> 12000. Meme regle,
-- SpectateRadius doit COUVRIR la zone de jeu.
C.Infection = { ZoneRadius = 12000, SpectateRadius = 13000 }
C.Parry     = { SpectateRadius = 2500 }

-- ── Infection : réglages OFFERTS À L'ORGANISATEUR (picker + panneau de gestion) ──
-- Le rayon de zone et la limite de temps ne sont plus figés dans la config : ces
-- listes sont la SOURCE UNIQUE des choix proposés, le serveur borne quand même
-- (ZoneRadiusMin/Max, DurationMax dans sv_infection).
C.InfectionZonePresets = { 2000, 4000, 6000, 9000, 12000, 16000 }
-- 0 = pas de limite (comportement historique : on joue jusqu'au dernier survivant).
C.InfectionTimePresets = { 0, 120, 180, 300, 420, 600 }

-- La zone étant RÉGLABLE, un rayon de jeu au-delà du SpectateRadius de config ferait
-- perdre HUD et cercle aux joueurs au bord de LEUR PROPRE zone. On garde donc toujours
-- une marge au-dessus du rayon réel. Partagé : serveur (qui sync) et client (qui masque).
function EVO_INSTRUCTEUR.InfectionViewRadius(nZoneRadius)
	return math.max(C.Infection.SpectateRadius or 2500, (nZoneRadius or 0) + 1000)
end

-- Les 2 camps : id interne, nom affiché, couleur (partagée client/serveur pour les marqueurs).
C.BattleTeams = {
	[1] = { name = "Rouge", color = Color(214, 76, 82) },
	[2] = { name = "Bleu",  color = Color(78, 142, 214) },
}

-- ── Helper de gate (lisible client ET serveur : FactionRank est une NWInt) ───
-- NB : côté serveur le défaut FactionRank est 1, côté client 0 ; on lit avec 0 et
-- on compare >= MinGrade. Les superadmins sont toujours instructeurs (tests/events).
function EVO_INSTRUCTEUR.IsInstructor(ply)
	if not IsValid(ply) then return false end
	if ply:IsSuperAdmin() then return true end
	return (ply:GetEvoNWInt("FactionRank", 0) or 0) >= C.MinGrade
end

-- Live HUD sync throttle (duel / king / infection / parry tick loops).
-- Discrete state changes still call sync* immediately; ticks use dirty fingerprint
-- + heartbeat so we do not spam sphere viewers at 4 Hz with unchanged payloads.
EVO_INSTRUCTEUR.LIVE_SYNC_HEARTBEAT = 1.0

function EVO_INSTRUCTEUR.NeedLiveSync(st, fingerprint)
	if not st then return false end
	local now = CurTime()
	local hb = EVO_INSTRUCTEUR.LIVE_SYNC_HEARTBEAT or 1
	if st._liveFp ~= fingerprint then
		st._liveFp = fingerprint
		st._liveAt = now
		return true
	end
	if (now - (st._liveAt or 0)) >= hb then
		st._liveAt = now
		return true
	end
	return false
end

function EVO_INSTRUCTEUR.MarkLiveSynced(st, fingerprint)
	if not st then return end
	if fingerprint ~= nil then st._liveFp = fingerprint end
	st._liveAt = CurTime()
end
