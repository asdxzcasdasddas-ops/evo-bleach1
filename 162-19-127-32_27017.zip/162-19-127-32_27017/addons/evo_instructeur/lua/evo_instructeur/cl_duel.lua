-- "addons\\evo_instructeur\\lua\\evo_instructeur\\cl_duel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO INSTRUCTEUR — DUEL ARBITRÉ 1v1, client : ring au sol (3D), tableau de score
-- (noms + barres de vie + manches), décompte, panneau d'arbitrage (instructeur),
-- picker des 2 combattants. DA v2 « Seireitei » (evo_ui) : cartes à coins coupés,
-- headers kit, rangées RowButton, actions ActionButton, kanji 剣 en filigrane.
-- ============================================================================

if not CLIENT then return end

EVO_INSTRUCTEUR = EVO_INSTRUCTEUR or {}

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL() return EVO_UI and EVO_UI.Col or {
	bg = Color(16,16,19,250), title = Color(238,239,243), muted = Color(150,154,162),
	dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128),
	line = Color(255,255,255,16), divider = Color(255,255,255,18) } end

local duel  = nil  -- { active, status, instr, aName, bName, scoreA, scoreB, round, need, ringPos, ringRadius, hpA, hpB, phase, roundWinner, champion, isRef }
local pRef  = nil  -- panneau d'arbitrage (instructeur)

-- Nom lisible de la touche bindée (pour les rappels HUD).
local function bindKeyName()
	local lp = LocalPlayer()
	if IsValid(lp) and lp.GetBindKey then
		local k = lp:GetBindKey("instructeur_ui")
		if k and k ~= 0 then
			local nm = input.GetKeyName(k)
			if nm and nm ~= "" then return string.upper(nm) end
		end
	end
	return "ta touche Menu Instructeur"
end

-- Petite croix de fermeture locale : le CloseButton du kit se positionne en
-- gRespX (ratio largeur) alors que nos cartes sont dimensionnées en R()
-- (ratio min) -> sur ultrawide il sortirait de la carte.
local function closeX(parent, cardW, fn)
	local col = COL()
	local x = vgui.Create("DButton", parent) x:SetText("") x:SetSize(R(28), R(28)) x:SetPos(R(cardW - 42), R(19)) x:SetZPos(1000)
	x.Paint = function(s, w, h)
		if s:IsHovered() then surface.SetDrawColor(ColorAlpha(col.accent, 30)) surface.DrawRect(0, 0, w, h) end
		draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.accent or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	x.DoClick = fn
	return x
end

-- L'instructeur arbitre-t-il un duel EN COURS ? (pour le menu + la touche)
function EVO_INSTRUCTEUR.IsRefereeingDuel()
	return duel ~= nil and duel.active and duel.isRef == true and duel.status ~= "done"
end

-- ── Ring au sol : helper PARTAGÉ (EVO_INSTRUCTEUR.DrawGroundRing, cl_ui.lua). ──
hook.Add("PostDrawTranslucentRenderables", "EVO_Instr::DuelRing", function(bDepth, bSky)
	if bDepth or bSky then return end
	if not (duel and duel.active and duel.ringPos) then return end
	if duel._farHidden then return end -- même règle que le HUD (cf. HudFarHidden)
	local col = COL()
	local pulse = 0.75 + math.sin(CurTime() * 3) * 0.25
	local c = (duel.status == "fighting") and col.accent or col.muted
	EVO_INSTRUCTEUR.DrawGroundRing(duel.ringPos, duel.ringRadius or 600, ColorAlpha(c, 230 * pulse))
end)

-- ── Tableau de score (HUD) ───────────────────────────────────────────────────
local function hpBar(x, y, w, h, frac, col)
	-- Rects plats DA v2 (plus d'arrondis) : fond translucide + remplissage coloré.
	surface.SetDrawColor(ColorAlpha(color_white, 22))
	surface.DrawRect(x, y, w, h)
	local fw = math.max(0, math.min(1, frac or 0)) * w
	local c = (frac > 0.5 and col.green) or (frac > 0.25 and Color(220, 180, 70)) or col.accent
	if fw > 1 then
		surface.SetDrawColor(c)
		surface.DrawRect(x, y, fw, h)
	end
end

-- Vraie vie LIVE du combattant (lue chaque frame sur l'entite joueur, en PVS), repli sur le hpFrac synchro.
-- Vrai max via EVO_MaxHP : GetMaxHealth des AUTRES joueurs vaut 100 côté client (la barre de
-- l'adversaire restait pleine puis tombait d'un coup).
local function liveFrac(ent, fallback)
	if IsValid(ent) and ent:IsPlayer() then
		local nMax = ent:GetEvoNWInt("EVO_MaxHP", 0)
		if nMax <= 0 then return fallback or 0 end
		return math.Clamp(ent:Health() / nMax, 0, 1)
	end
	return fallback or 0
end

hook.Add("HUDPaint", "EVO_Instr::DuelHUD", function()
	if not (duel and duel.active) then return end
	if EVO_INSTRUCTEUR.HudFarHidden(duel, duel.ringPos, EVO_INSTRUCTEUR.Config.Duel.SpectateRadius,
		duel.isRef or duel.entA == LocalPlayer() or duel.entB == LocalPlayer()) then return end
	local col = COL()
	local W = R(560)
	local x, y = ScrW() / 2 - W / 2, EVO_INSTRUCTEUR.HudTopY()
	local H = R(96)
	-- Fond plat DA v2 : rect sombre + liseré 1px + barre d'accent en tête.
	surface.SetDrawColor(ColorAlpha(col.bg, 235)) surface.DrawRect(x, y, W, H)
	surface.SetDrawColor(col.line) surface.DrawOutlinedRect(x, y, W, H)
	surface.SetDrawColor(ColorAlpha(col.accent, 255)) surface.DrawRect(x, y, W, R(3))

	draw.SimpleText("DUEL ARBITRÉ  ·  " .. (duel.instr or ""), "EVO_UI_Mono", x + W / 2, y + R(10), col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Noms + score central
	draw.SimpleText(duel.aName or "A", "EVO_UI_Header", x + R(20), y + R(34), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(duel.bName or "B", "EVO_UI_Header", x + W - R(20), y + R(34), col.title, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	draw.SimpleText((duel.scoreA or 0) .. " - " .. (duel.scoreB or 0), "EVO_UI_Header", x + W / 2, y + R(40), col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Barres de vie
	local bw = R(190)
	hpBar(x + R(20), y + R(62), bw, R(12), liveFrac(duel.entA, duel.hpA), col)
	hpBar(x + W - R(20) - bw, y + R(62), bw, R(12), liveFrac(duel.entB, duel.hpB), col)

	-- Ligne d'état (centre bas du panneau)
	local status = ""
	if duel.status == "countdown" then status = "Manche " .. (duel.round or 1) .. " · prépare-toi"
	elseif duel.status == "fighting" then status = "Manche " .. (duel.round or 1) .. " · COMBAT (premier à " .. (duel.need or 2) .. ")"
	elseif duel.status == "roundover" then status = "Manche à " .. (duel.roundWinner ~= "" and duel.roundWinner or "?")
	elseif duel.status == "done" then status = "VAINQUEUR : " .. (duel.champion ~= "" and duel.champion or "?") end
	draw.SimpleText(status, "EVO_Instr_Small", x + W / 2, y + R(80), duel.status == "done" and col.green or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- Décompte géant au centre de l'écran
	if duel.status == "countdown" then
		local n = math.ceil((duel.phaseEnd or 0) - CurTime())
		if n > 0 then
			draw.SimpleTextOutlined(tostring(n), "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
		end
	elseif duel.status == "done" then
		draw.SimpleTextOutlined("VAINQUEUR : " .. (duel.champion ~= "" and duel.champion or "?"), "EVO_UI_Header", ScrW() / 2, ScrH() * 0.4, col.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, 230))
	end

	-- Rappel arbitre.
	if duel.isRef and duel.status ~= "done" then
		draw.SimpleText("Arbitre · [" .. bindKeyName() .. "] pour arbitrer (forcer la manche / annuler)", "EVO_Instr_Small", ScrW() / 2, y + H + R(6), col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

-- ── Panneau d'arbitrage (instructeur) ─────────────────────────────────────────
function EVO_INSTRUCTEUR.OpenDuelRefereePanel()
	if not EVO_INSTRUCTEUR.IsRefereeingDuel() then return end
	if IsValid(pRef) then pRef:Remove() end
	local col = COL()
	local W, H = 420, 210
	local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
	f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	pRef = f
	f.OnRemove = function() if pRef == f then pRef = nil end end
	f.OnKeyCodePressed = function(s, key)
		local lp = LocalPlayer()
		if lp.GetBindKey and key == lp:GetBindKey("instructeur_ui") then
			EVO_INSTRUCTEUR._suppressOpenUntil = SysTime() + 0.25
			f:Remove() return true
		end
	end
	f.Paint = function(s, w, h)
		EVO_UI.PaintCard(w, h, 1, R(12))
		EVO_UI.Header(w, "ARBITRER LE DUEL", "MANCHE " .. ((duel and duel.round) or 1), 1, R(20))
		EVO_UI.Watermark(w, h, "剣", 1)
		draw.SimpleText((duel and ((duel.aName or "A") .. "  " .. (duel.scoreA or 0) .. " - " .. (duel.scoreB or 0) .. "  " .. (duel.bName or "B"))) or "", "EVO_UI_Mono", R(20), R(74), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	closeX(f, W, function() f:Remove() end)

	local halfW = (W - 56) / 2
	EVO_UI.ActionButton(f, R(24), R(92), R(halfW), R(40), "VAINQUEUR : " .. (duel and duel.aName or "A"), col.green, function()
		net.Start("EVO:Instr:Duel:ForceWin") net.WriteUInt(1, 2) net.SendToServer()
	end)
	EVO_UI.ActionButton(f, R(24 + halfW + 8), R(92), R(halfW), R(40), "VAINQUEUR : " .. (duel and duel.bName or "B"), col.green, function()
		net.Start("EVO:Instr:Duel:ForceWin") net.WriteUInt(2, 2) net.SendToServer()
	end)
	EVO_UI.ActionButton(f, R(24), R(142), R(W - 48), R(40), "ANNULER LE DUEL", nil, function()
		net.Start("EVO:Instr:Duel:Cancel") net.SendToServer() f:Remove()
	end)
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
end

-- ── Picker des 2 combattants (instructeur) ────────────────────────────────────
function EVO_INSTRUCTEUR.OpenDuelPicker()
	if not EVO_INSTRUCTEUR.RequestNearby then return end
	EVO_INSTRUCTEUR.RequestNearby(function(list)
		local col = COL()
		if #list < 2 then
			if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Il faut 2 joueurs proches pour un duel.", NOTIFY_ERROR or 1, 4) end
			return
		end
		local listH = math.Clamp(#list * 30, 60, 240)
		local W, H = 420, 136 + listH
		local f = vgui.Create("DFrame") f:SetSize(R(W), R(H)) f:Center()
		f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
		EVO_INSTRUCTEUR._pickerPanel = f
		f.OnRemove = function() if EVO_INSTRUCTEUR._pickerPanel == f then EVO_INSTRUCTEUR._pickerPanel = nil end end
		local checks, order = {}, {}
		f.Paint = function(s, w, h)
			EVO_UI.PaintCard(w, h, 1, R(12))
			EVO_UI.Header(w, "DUEL ARBITRÉ 1V1", "CHOISIR 2", 1, R(20))
			local n = #order
			draw.SimpleText(n .. " / 2 SÉLECTIONNÉS", "EVO_UI_Mono", R(20), R(72), n == 2 and col.green or col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local scroll = vgui.Create("DScrollPanel", f) scroll:SetPos(R(20), R(84)) scroll:SetSize(R(W - 40), R(listH))
		for i, p in ipairs(list) do
			checks[p.sid] = false
			-- Rangée du kit : la sélection (SetSel) donne le fond accent + barre blanche.
			local b = EVO_UI.RowButton(scroll, 0, 0, 0, R(28),
				{ num = string.format("%02d", i), label = p.name }, function(s)
					if checks[p.sid] then
						checks[p.sid] = false
						for j = #order, 1, -1 do if order[j] == p.sid then table.remove(order, j) end end
					elseif #order < 2 then
						checks[p.sid] = true
						order[#order + 1] = p.sid
					end
					s:SetSel(checks[p.sid])
				end)
			b:Dock(TOP) b:DockMargin(0, 0, 0, R(4)) b:SetTall(R(28))
		end
		EVO_UI.ActionButton(f, R(20), R(H - 46), R(W - 40), R(36), "LANCER LE DUEL", col.green, function()
			if #order ~= 2 then
				if MUGEN and MUGEN.AddNotification then MUGEN.AddNotification("Sélectionne exactement 2 combattants.", NOTIFY_ERROR or 1, 3) end
				return
			end
			net.Start("EVO:Instr:Duel:Create") net.WriteUInt(#order, 8)
				for _, id in ipairs(order) do net.WriteString(id) end
			net.SendToServer()
			f:Remove()
			if EVO_INSTRUCTEUR.CloseMenu then EVO_INSTRUCTEUR.CloseMenu() end
		end)
		closeX(f, W, function() f:Remove() end)
		if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	end)
end

-- ── NET : sync du duel ────────────────────────────────────────────────────────
net.Receive("EVO:Instr:Duel:Sync", function()
	if not net.ReadBool() then
		duel = nil
		EVO_INSTRUCTEUR.SetEventRing("duel", nil)
		if IsValid(pRef) then pRef:Remove() pRef = nil end
		return
	end
	local d = { active = true }
	d.status     = net.ReadString()
	d.instr      = net.ReadString()
	d.aName      = net.ReadString()
	d.bName      = net.ReadString()
	d.scoreA     = net.ReadUInt(4)
	d.scoreB     = net.ReadUInt(4)
	d.round      = net.ReadUInt(4)
	d.need       = net.ReadUInt(4)
	d.ringPos    = net.ReadVector()
	d.ringRadius = net.ReadUInt(16)
	d.hpA        = net.ReadFloat()
	d.hpB        = net.ReadFloat()
	d.entA       = net.ReadEntity()  -- combattants : vraie vie lue LIVE cote client
	d.entB       = net.ReadEntity()
	d.phase      = net.ReadFloat()
	d.roundWinner= net.ReadString()
	d.champion   = net.ReadString()
	d.isRef      = net.ReadBool()
	d.phaseEnd   = CurTime() + (d.phase or 0)  -- decompte LOCAL (serveur ne re-sync pas chaque frame)
	duel = d
	EVO_INSTRUCTEUR.SetEventRing("duel", d.ringPos, d.ringRadius) -- efface les postes d'entraînement sous le ring
	if d.status == "done" and IsValid(pRef) then pRef:Remove() pRef = nil end
end)
