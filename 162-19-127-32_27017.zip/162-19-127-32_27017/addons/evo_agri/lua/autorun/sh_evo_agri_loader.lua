-- "addons\\evo_agri\\lua\\autorun\\sh_evo_agri_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AGRI — pot posé, graine dedans, arroser, récolter.
-- Session only : pots et plants disparaissent au changement de map / restart.
-- ============================================================================
EVO_AGRI = EVO_AGRI or {}

if SERVER then
	AddCSLuaFile("evo_agri/sh_config.lua")
	AddCSLuaFile("evo_agri/cl_agri.lua")
	AddCSLuaFile("evo_agri/cl_agri_editor.lua")
	AddCSLuaFile("evo_agri/cl_agri_placer.lua")
	include("evo_agri/sh_config.lua")
	include("evo_agri/sv_agri.lua")
	include("evo_agri/sv_agri_editor.lua")
else
	include("evo_agri/sh_config.lua")
	include("evo_agri/cl_agri.lua")
	include("evo_agri/cl_agri_editor.lua")
	include("evo_agri/cl_agri_placer.lua")
end
