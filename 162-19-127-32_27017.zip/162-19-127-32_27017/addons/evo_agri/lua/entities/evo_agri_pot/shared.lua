-- "addons\\evo_agri\\lua\\entities\\evo_agri_pot\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type           = "anim"
ENT.Base           = "base_anim"
ENT.PrintName      = "Pot de culture"
ENT.Author         = "EVO"
ENT.Category       = "Evo"
ENT.Spawnable      = false
ENT.AdminSpawnable = false
ENT.Model          = "models/evo/props/items/evo_526gbhaOKRFBgvef/evo_526gbhaOKRFBgvef.mdl"

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "PotId")
	self:NetworkVar("Int", 1, "Stage")
	self:NetworkVar("Bool", 0, "Watered")
	self:NetworkVar("Entity", 0, "Planter")
	self:NetworkVar("Entity", 1, "PotOwner")
	self:NetworkVar("String", 0, "CropId")
	self:NetworkVar("Float", 0, "GrowEnd")
end
