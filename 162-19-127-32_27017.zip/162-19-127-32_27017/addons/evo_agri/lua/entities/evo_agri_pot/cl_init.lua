-- "addons\\evo_agri\\lua\\entities\\evo_agri_pot\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("EVO_Agri_Tag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
})

ENT.RenderGroup = RENDERGROUP_BOTH

local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local TAG_MAX_DIST = 400
local FALLBACK_CROP = "models/evo/props/items/evo_152hbjfrejgvfer51efz/evo_152HBJfrejgvFER51efz.mdl"

local function cropOf(self)
	local A = EVO_AGRI
	if A and A.GetCrop then return A.GetCrop(self:GetCropId()) end
	return {
		name   = "Plante de blé",
		model  = FALLBACK_CROP,
		scales = { 0.75, 1.5, 2.25, 3.0 },
		stages = 4,
	}
end

function ENT:KillCropMdl()
	if IsValid(self._cropMdl) then
		self._cropMdl:Remove()
	end
	self._cropMdl = nil
	self._cropMdlPath = nil
	self._cropMdlSkin = nil
end

function ENT:EnsureCropMdl(sMdl, nSkin)
	nSkin = math.floor(tonumber(nSkin) or 0)
	if not isstring(sMdl) or sMdl == "" then sMdl = FALLBACK_CROP end
	if IsValid(self._cropMdl) and self._cropMdlPath == sMdl and self._cropMdlSkin == nSkin then
		return self._cropMdl
	end
	self:KillCropMdl()
	self._cropMdl = ClientsideModel(sMdl)
	self._cropMdlPath = sMdl
	self._cropMdlSkin = nSkin
	if IsValid(self._cropMdl) then
		self._cropMdl:SetNoDraw(true)
		self._cropMdl:SetSkin(nSkin)
	end
	return self._cropMdl
end

function ENT:Draw()
	self:DrawModel()
	local nStage = self:GetStage()
	if nStage < 1 then
		if IsValid(self._cropMdl) then self._cropMdl:SetNoDraw(true) end
		return
	end
	local crop = cropOf(self)
	local m = self:EnsureCropMdl(crop.model, crop.skin)
	if not IsValid(m) then return end
	local A = EVO_AGRI
	local pose = self._agriEditPose
	if not pose then
		local pot = A and A.GetPotByN and A.GetPotByN(self:GetPotId())
		pose = A and A.GetPlantPose and A.GetPlantPose(pot and pot.id, crop.id)
	end
	local off = (pose and pose.pos) or crop.offset or (A and A.POT_PLANT_OFFSET) or Vector(0, 0, 6)
	local ang = (pose and pose.ang) or Angle(0, 0, 0)
	m:SetPos(self:LocalToWorld(off))
	m:SetAngles(self:LocalToWorldAngles(ang))
	local nScale = (crop.scales and crop.scales[nStage]) or 1
	m:SetModelScale(nScale, 0)
	if crop.growth_bodygroup ~= nil then
		m:SetBodygroup(crop.growth_bodygroup, math.Clamp(nStage - 1, 0, (crop.stages or 1) - 1))
	end
	if crop.sequence then
		if m._agriSequenceName ~= crop.sequence then
			m._agriSequenceName = crop.sequence
			m._agriSequenceId = m:LookupSequence(crop.sequence)
			m._agriSequenceStart = CurTime()
			if m._agriSequenceId >= 0 then m:ResetSequence(m._agriSequenceId) end
		end
		if m._agriSequenceId >= 0 then
			local rate = crop.playback_rate or 1
			local duration = crop.sequence_duration or m:SequenceDuration(m._agriSequenceId)
			m:SetPlaybackRate(rate)
			-- Cycle absolu : ne double pas la vitesse si Draw est appelé plusieurs
			-- fois par frame ; reste en boucle même après un passage hors champ.
			m:SetCycle(((CurTime() - m._agriSequenceStart) * rate / math.max(0.01, duration)) % 1)
			m:InvalidateBoneCache()
			m:SetupBones()
		end
	end
	m:DrawModel()
end

function ENT:DrawTranslucent()
	if self:GetStage() < 1 then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > TAG_MAX_DIST * TAG_MAX_DIST then return end

	local crop = cropOf(self)
	local name = (crop and crop.name) or "Plante de blé"

	local top = tonumber(self:OBBMaxs().z) or 0
	if top < 20 then top = 28 end
	local nStage = self:GetStage()
	local nScale = (crop.scales and crop.scales[nStage]) or 1
	local pos = ePos + Vector(0, 0, top + 8 + (28 * nScale))
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	if self._tagName ~= name then
		surface.SetFont("EVO_Agri_Tag")
		self._tagName = name
		self._tagTW, self._tagTH = surface.GetTextSize(name)
	end

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.12)
		draw.RoundedBox(0, -self._tagTW * 0.5 - 16, -self._tagTH * 0.5 - 6, self._tagTW + 32, self._tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "EVO_Agri_Tag", 0, 0, COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end

function ENT:OnRemove()
	self:KillCropMdl()
end
