-- "addons\\evo_agri\\lua\\evo_agri\\cl_agri_placer.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AGRI — client : mode Placer (gizmo monde move/rotate, C menu).
-- Même famille que evo_config_positions / éditeur d'accessoire.
-- ============================================================================
if not CLIENT then return end

EVO_AGRI = EVO_AGRI or {}
local A = EVO_AGRI

local COL_ACCENT = Color(210, 185, 90)
local COL_TXT    = Color(235, 235, 240)
local COL_DIM    = Color(160, 160, 168)
local COL_TITLE  = Color(238, 239, 243)
local COL_BG     = Color(16, 16, 19, 250)
local COL_ROW    = Color(32, 32, 40, 255)
local AXIS_COLORS = {
	Color(207, 68, 78),
	Color(78, 196, 128),
	Color(90, 140, 240),
}
local AXIS_NAMES = { "X", "Y", "Z" }
local ROT_NAMES  = { "Roll", "Pitch", "Yaw" }

local GIZMO_PICK_PX = 22
local GIZMO_CENTER_PICK_PX = 18
local ROT_GIZMO_SEGMENTS = 36
local ROT_GIZMO_PICK_SAMPLES = 64
local ROT_GIZMO_PICK_PX = 32
local ROT_GIZMO_RADIUS_SCALE = 0.88
local DRAG_START_PX_SQ = 4
local STREAM_INTERVAL = 0.1

surface.CreateFont("EVOAgri_Placer", { font = "Roboto", size = 15, weight = 500, antialias = true })
surface.CreateFont("EVOAgri_PlacerGizmo", { font = "Roboto", size = 13, weight = 700, antialias = true })

local Mode = "move"
local Drag
local HoverPick
local GizmoScreen
local ModeBtns = {}
local KeyWas = {}
local LastStream = 0
local Panel

local function RX(n) return (gRespX and gRespX(n)) or n end
local function RY(n) return (gRespY and gRespY(n)) or n end
local function R(v)
	return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local function contextOpen()
	return MUGEN and MUGEN.IsContextMenuOpen and MUGEN.IsContextMenuOpen()
end

local function getContextFrame()
	local world = vgui.GetWorldPanel()
	if not IsValid(world) then return nil end
	for _, p in ipairs(world:GetChildren()) do
		if IsValid(p) and p.ClassName == "LZY:ContextMenu" then return p end
	end
end

local function overPanel()
	if not IsValid(Panel) then return false end
	local p = vgui.GetHoveredPanel()
	while IsValid(p) do
		if p == Panel then return true end
		p = p:GetParent()
	end
	return false
end

local function distPointSq(px, py, x, y)
	local dx, dy = px - x, py - y
	return dx * dx + dy * dy
end

local function distPointToSegmentSq(px, py, x1, y1, x2, y2)
	local dx, dy = x2 - x1, y2 - y1
	local lenSq = dx * dx + dy * dy
	if lenSq < 1e-6 then return distPointSq(px, py, x1, y1) end
	local t = math.Clamp(((px - x1) * dx + (py - y1) * dy) / lenSq, 0, 1)
	return distPointSq(px, py, x1 + dx * t, y1 + dy * t)
end

local function getGizmoWorldFrame(ent)
	if not IsValid(ent) then return nil end
	local origin = ent:GetPos()
	local camPos = EyePos()
	local arm = math.Clamp(origin:Distance(camPos) * 0.075, 24, 80)
	return {
		origin = origin,
		right = Vector(1, 0, 0),
		forward = Vector(0, 1, 0),
		up = Vector(0, 0, 1),
		arm = arm,
		camPos = camPos,
	}
end

local function getGizmoAxisWorldDir(frame, axis)
	if axis == 1 then return frame.right end
	if axis == 2 then return frame.forward end
	return frame.up
end

local function getGizmoRotatePlaneAxes(frame, axis)
	if axis == 1 then return frame.forward, frame.up end
	if axis == 2 then return frame.right, frame.up end
	return frame.right, frame.forward
end

local function getGizmoRingEdgeOn(frame, axis)
	if not frame or not frame.camPos then return 0 end
	local axisDir = getGizmoAxisWorldDir(frame, axis)
	local viewDir = (frame.camPos - frame.origin)
	if viewDir:LengthSqr() < 1e-6 then return 0 end
	viewDir:Normalize()
	return math.abs(axisDir:Dot(viewDir))
end

local function buildGizmoMoveScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end
	local cache = { kind = "move", origin = { x = originScr.x, y = originScr.y }, axes = {}, arm = frame.arm }
	for axis = 1, 3 do
		local dir = getGizmoAxisWorldDir(frame, axis)
		local endScr = (frame.origin + dir * frame.arm):ToScreen()
		if endScr.visible then
			cache.axes[axis] = { x1 = originScr.x, y1 = originScr.y, x2 = endScr.x, y2 = endScr.y }
		end
	end
	return cache
end

local function buildGizmoRotateScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end
	local cache = { kind = "rotate", origin = { x = originScr.x, y = originScr.y }, rings = {}, arm = frame.arm }
	local radius = frame.arm * ROT_GIZMO_RADIUS_SCALE
	for axis = 1, 3 do
		local u, v = getGizmoRotatePlaneAxes(frame, axis)
		local points, segs = {}, {}
		local faceOn = 1 - getGizmoRingEdgeOn(frame, axis)
		local alpha = math.floor(Lerp(getGizmoRingEdgeOn(frame, axis), 255, 72))
		local su = (frame.origin + u * radius):ToScreen()
		local sv = (frame.origin + v * radius):ToScreen()
		for i = 0, ROT_GIZMO_SEGMENTS - 1 do
			local t0 = (i / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local t1 = ((i + 1) / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local w0 = frame.origin + (u * math.cos(t0) + v * math.sin(t0)) * radius
			local w1 = frame.origin + (u * math.cos(t1) + v * math.sin(t1)) * radius
			local s0, s1 = w0:ToScreen(), w1:ToScreen()
			points[#points + 1] = { x = s0.x, y = s0.y, visible = s0.visible }
			if s0.visible or s1.visible then
				segs[#segs + 1] = { x1 = s0.x, y1 = s0.y, x2 = s1.x, y2 = s1.y, visible = s0.visible and s1.visible }
			end
		end
		cache.rings[axis] = {
			points = points, segs = segs, alpha = alpha, faceOn = faceOn,
			basis = { ux = su.x - originScr.x, uy = su.y - originScr.y, vx = sv.x - originScr.x, vy = sv.y - originScr.y },
		}
	end
	return cache
end

local function pickGizmoMoveFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= GIZMO_CENTER_PICK_PX * GIZMO_CENTER_PICK_PX then
		return 0
	end
	local bestPick, bestScore = nil, GIZMO_PICK_PX * GIZMO_PICK_PX
	for axis = 1, 3 do
		local seg = cache.axes[axis]
		if seg then
			local distSq = distPointToSegmentSq(mx, my, seg.x1, seg.y1, seg.x2, seg.y2)
			if distSq < bestScore then
				bestScore, bestPick = distSq, axis
			end
		end
	end
	return bestPick
end

local function distToRingCurveSq(mx, my, origin, ring)
	if not ring or not ring.basis or not origin then return math.huge end
	local best = math.huge
	for i = 0, ROT_GIZMO_PICK_SAMPLES - 1 do
		local t = (i / ROT_GIZMO_PICK_SAMPLES) * math.pi * 2
		local px = origin.x + ring.basis.ux * math.cos(t) + ring.basis.vx * math.sin(t)
		local py = origin.y + ring.basis.uy * math.cos(t) + ring.basis.vy * math.sin(t)
		local d = distPointSq(mx, my, px, py)
		if d < best then best = d end
	end
	return best
end

local function pickGizmoRotateFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end
	local centerPickPx = GIZMO_CENTER_PICK_PX + R(4)
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= centerPickPx * centerPickPx then
		return 0
	end
	local pickPx = ROT_GIZMO_PICK_PX + R(4)
	local bestPick, bestScore = nil, math.huge
	for axis = 1, 3 do
		local ring = cache.rings and cache.rings[axis]
		if ring then
			local distSq = distToRingCurveSq(mx, my, cache.origin, ring)
			local faceOn = ring.faceOn or 0.5
			local pickBonus = (1 - faceOn) * pickPx * 0.75
			local threshold = (pickPx + pickBonus) * (pickPx + pickBonus)
			if distSq <= threshold then
				local score = distSq / (0.15 + faceOn * 0.85)
				if score < bestScore then
					bestScore, bestPick = score, axis
				end
			end
		end
	end
	return bestPick
end

local function pickGizmoFromCache(mx, my, cache)
	if cache and cache.kind == "rotate" then
		return pickGizmoRotateFromCache(mx, my, cache)
	end
	return pickGizmoMoveFromCache(mx, my, cache)
end

local function axisDragDeltaFromCache(axis, dx, dy, cache)
	local seg = cache and cache.axes[axis]
	if not seg then return 0 end
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.sqrt(sx * sx + sy * sy)
	if len < 0.01 then return 0 end
	sx, sy = sx / len, sy / len
	return ((dx * sx + dy * sy) / len) * (cache.arm or 0)
end

local function ringDragAngleFromCache(mx, my, ax, ay, cache)
	if not cache or not cache.origin then return 0 end
	local cx, cy = cache.origin.x, cache.origin.y
	local delta = math.deg(math.atan2(my - cy, mx - cx) - math.atan2(ay - cy, ax - cx))
	if delta > 180 then delta = delta - 360
	elseif delta < -180 then delta = delta + 360 end
	return delta
end

local function drawWorldGizmoAxisFromCache(seg, col, highlight, label)
	if not seg then return end
	local drawCol = highlight and COL_TITLE or col
	surface.SetDrawColor(drawCol)
	surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.max(math.sqrt(sx * sx + sy * sy), 0.01)
	sx, sy = sx / len, sy / len
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) + sy * R(4), seg.y2 - sy * R(7) - sx * R(4))
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) - sy * R(4), seg.y2 - sy * R(7) + sx * R(4))
	if label then
		draw.SimpleText(label, "EVOAgri_PlacerGizmo", seg.x2 + sx * R(10), seg.y2 + sy * R(10), drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local function drawWorldGizmoRingFromCache(ring, col, highlight, label)
	if not ring or not ring.segs then return end
	local alpha = ring.alpha or 255
	local drawCol = highlight and COL_TITLE or ColorAlpha(col, alpha)
	surface.SetDrawColor(drawCol)
	for _, seg in ipairs(ring.segs) do
		if seg.visible ~= false then
			surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
		end
	end
	if label and ring.points then
		local pt = ring.points[math.floor(#ring.points * 0.125) + 1] or ring.points[1]
		if pt then
			draw.SimpleText(label, "EVOAgri_PlacerGizmo", pt.x, pt.y, drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

local function hitModeButton(mx, my)
	for i = 1, #ModeBtns do
		local b = ModeBtns[i]
		if mx >= b.x and my >= b.y and mx <= b.x + b.w and my <= b.y + b.h then
			return b.mode
		end
	end
end

-- netgate: stream
local function sendMoveLive()
	local ent = A._placerEnt
	if not IsValid(ent) then return end
	local p = A._placerPos
	local a = A._placerAng
	if not (isvector(p) and isangle(a)) then return end
	net.Start("EVO_Agri:MovePot")
	net.WriteEntity(ent)
	net.WriteVector(p)
	net.WriteAngle(a)
	net.SendToServer()
end

-- netgate: edge
local function sendMove()
	local ent = A._placerEnt
	if not IsValid(ent) then return end
	local p = A._placerPos
	local a = A._placerAng
	if not (isvector(p) and isangle(a)) then return end
	net.Start("EVO_Agri:MovePot")
	net.WriteEntity(ent)
	net.WriteVector(p)
	net.WriteAngle(a)
	net.SendToServer()
end

local function applyLocal()
	local ent = A._placerEnt
	if not IsValid(ent) then return end
	if isvector(A._placerPos) then ent:SetPos(A._placerPos) end
	if isangle(A._placerAng) then ent:SetAngles(A._placerAng) end
end

local function streamMove(bForce)
	if CurTime() < LastStream + STREAM_INTERVAL and not bForce then return end
	LastStream = CurTime()
	sendMoveLive()
end

local function hidePanel()
	if IsValid(Panel) then Panel:Remove() end
	Panel = nil
end

-- netgate: edge
local function sendPlacerEnd(bCommit)
	net.Start("EVO_Agri:PlacerEnd")
	net.WriteBool(bCommit and true or false)
	net.SendToServer()
end

local function closePlacer(bCommit)
	local ent = A._placerEnt
	Drag, HoverPick, GizmoScreen = nil, nil, nil
	ModeBtns = {}
	hidePanel()
	if IsValid(ent) then
		sendPlacerEnd(bCommit and true or false)
		if not bCommit and isvector(A._placerStartPos) and isangle(A._placerStartAng) then
			ent:SetPos(A._placerStartPos)
			ent:SetAngles(A._placerStartAng)
		elseif bCommit then
			sendMove()
		end
	else
		sendPlacerEnd(false)
	end
	A._placerEnt = nil
	A._placerPos = nil
	A._placerAng = nil
	A._placerStartPos = nil
	A._placerStartAng = nil
	A._placerOpen = nil
end

local function buildPanel(parent)
	if not IsValid(parent) then return end
	hidePanel()
	local W, H = 260, 168
	local f = vgui.Create("DPanel", parent)
	f:SetSize(RX(W), RY(H))
	f:SetPos(RX(16), RY(56))
	f:SetMouseInputEnabled(true)
	f:SetKeyboardInputEnabled(false)
	Panel = f
	f.OnRemove = function()
		if Panel == f then Panel = nil end
	end

	f.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, RY(12))
			EVO_UI.Header(w, "PLACER", "MOVE / ROTATE", 1, RX(16))
		else
			draw.RoundedBox(8, 0, 0, w, h, Color(16, 16, 20, 240))
			draw.SimpleText("Placer", "DermaLarge", RX(16), RY(12), color_white)
		end
		draw.SimpleText("G / R · modes", "EVOAgri_Placer", RX(16), RY(58), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local col = EVO_UI and EVO_UI.Col
	local function btn(bx, by, bw, bh, label, fill, fn)
		if EVO_UI and EVO_UI.ActionButton then
			local b = EVO_UI.ActionButton(f, RX(bx), RY(by), RX(bw), RY(bh), label, fill, fn)
			b:SetZPos(10)
			return b
		end
		local b = vgui.Create("DButton", f)
		b:SetPos(RX(bx), RY(by))
		b:SetSize(RX(bw), RY(bh))
		b:SetText(label)
		b.DoClick = fn
		return b
	end

	btn(16, 84, W - 32, 32, "VALIDER", col and col.green, function()
		closePlacer(true)
	end)
	btn(16, 122, W - 32, 32, "ANNULER", nil, function()
		closePlacer(false)
	end)
end

local function showPanel()
	local parent = getContextFrame()
	if IsValid(parent) then buildPanel(parent) end
end

local function syncPanelVis()
	if not A._placerOpen then
		hidePanel()
		return
	end
	if contextOpen() then
		if not IsValid(Panel) then showPanel() end
	else
		hidePanel()
	end
end

local function updateDrag()
	if not Drag or not IsValid(A._placerEnt) then return end
	local mx, my = gui.MousePos()
	local dx, dy = mx - Drag.anchorX, my - Drag.anchorY
	if not Drag.ready then
		if (dx * dx + dy * dy) < DRAG_START_PX_SQ then return end
		Drag.ready = true
	end

	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local cache = GizmoScreen or Drag.cache
	local startPos = Drag.startPos
	local startAng = Drag.startAng

	if Mode == "rotate" and startAng then
		if Drag.axis == 0 then
			A._placerAng = Angle(startAng.p - dy * 0.35, startAng.y + dx * 0.35, startAng.r)
		else
			local delta = ringDragAngleFromCache(mx, my, Drag.anchorX, Drag.anchorY, cache)
			if Drag.axis == 1 then
				A._placerAng = Angle(startAng.p, startAng.y, startAng.r + delta)
			elseif Drag.axis == 2 then
				A._placerAng = Angle(startAng.p + delta, startAng.y, startAng.r)
			else
				A._placerAng = Angle(startAng.p, startAng.y + delta, startAng.r)
			end
		end
	elseif Drag.axis == 0 and startPos then
		local right, up = lp:EyeAngles():Right(), lp:EyeAngles():Up()
		local scale = startPos:Distance(lp:EyePos()) * 0.0022
		A._placerPos = startPos + right * (dx * scale) - up * (dy * scale)
	elseif startPos then
		local along = axisDragDeltaFromCache(Drag.axis, dx, dy, cache)
		local dir = Drag.axis == 1 and Vector(1, 0, 0) or (Drag.axis == 2 and Vector(0, 1, 0) or Vector(0, 0, 1))
		A._placerPos = startPos + dir * along
	end

	local nMax = A.MOVE_MAX_DELTA or 256
	if isvector(A._placerStartPos) and isvector(A._placerPos) then
		local d = A._placerPos - A._placerStartPos
		if d:Length() > nMax then
			d:Normalize()
			A._placerPos = A._placerStartPos + d * nMax
		end
	end

	applyLocal()
	streamMove(false)
end

local function finishDrag()
	if not Drag then return end
	Drag = nil
	if A._placerOpen then sendMove() end
end

local function applyPick(mx, my)
	if not A._placerOpen or not contextOpen() then return false end
	local modeHit = hitModeButton(mx, my)
	if modeHit then
		Mode = modeHit
		return true
	end
	if overPanel() then return false end
	local cache = GizmoScreen
	if not cache then return false end
	local pick = pickGizmoFromCache(mx, my, cache)
	if pick == nil then return false end
	Drag = {
		axis = pick,
		startPos = A._placerPos and Vector(A._placerPos.x, A._placerPos.y, A._placerPos.z) or nil,
		startAng = A._placerAng and Angle(A._placerAng.p, A._placerAng.y, A._placerAng.r) or nil,
		anchorX = mx, anchorY = my,
		ready = false,
		cache = cache,
	}
	return true
end

local function edgeKey(key)
	local down = input.IsKeyDown(key)
	local was = KeyWas[key]
	KeyWas[key] = down
	return down and not was
end

local function paintWorldGizmo(mx, my)
	local ent = A._placerEnt
	if not IsValid(ent) then
		GizmoScreen, HoverPick = nil, nil
		return
	end
	local frame = getGizmoWorldFrame(ent)
	if not frame then
		GizmoScreen, HoverPick = nil, nil
		return
	end
	if Mode == "rotate" then
		GizmoScreen = buildGizmoRotateScreenCache(frame)
	else
		GizmoScreen = buildGizmoMoveScreenCache(frame)
	end
	local cache = GizmoScreen
	if not cache then
		HoverPick = nil
		return
	end
	HoverPick = pickGizmoFromCache(mx, my, cache)
	local activePick = Drag and Drag.axis or nil
	local ox, oy = cache.origin.x, cache.origin.y
	local centerHl = HoverPick == 0 or activePick == 0
	local centerR = R(centerHl and 9 or 7)
	draw.RoundedBox(centerR, ox - centerR, oy - centerR, centerR * 2, centerR * 2,
		centerHl and COL_TITLE or ColorAlpha(COL_TITLE, 180))
	surface.SetDrawColor(COL_BG)
	surface.DrawRect(ox - R(3), oy - R(3), R(6), R(6))

	local labels = (cache.kind == "rotate") and ROT_NAMES or AXIS_NAMES
	if cache.kind == "rotate" then
		for axis = 1, 3 do
			drawWorldGizmoRingFromCache(cache.rings[axis], AXIS_COLORS[axis], HoverPick == axis or activePick == axis, labels[axis])
		end
	else
		for axis = 1, 3 do
			drawWorldGizmoAxisFromCache(cache.axes[axis], AXIS_COLORS[axis], HoverPick == axis or activePick == axis, labels[axis])
		end
	end
end

local function drawModePills(x, y)
	ModeBtns = {}
	surface.SetFont("EVOAgri_Placer")
	local modes = { { "move", "MOVE" }, { "rotate", "ROTATE" } }
	local px = x
	for i = 1, #modes do
		local id, lab = modes[i][1], modes[i][2]
		local tw, th = surface.GetTextSize(lab)
		local bw, bh = tw + 16, th + 8
		ModeBtns[#ModeBtns + 1] = { mode = id, x = px, y = y, w = bw, h = bh }
		local on = Mode == id
		draw.RoundedBox(4, px, y, bw, bh, on and COL_ACCENT or COL_ROW)
		draw.SimpleText(lab, "EVOAgri_Placer", px + bw * 0.5, y + bh * 0.5, on and COL_TITLE or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		px = px + bw + 6
	end
end

function A.IsPlacerOpen()
	return A._placerOpen and IsValid(A._placerEnt)
end

function A.OpenPlacer(ent)
	if not IsValid(ent) then return end
	if A._placerOpen and A._placerEnt == ent then return end
	if A._placerOpen then closePlacer(false) end

	local vPos = ent:GetPos()
	local aAng = ent:GetAngles()
	A._placerEnt = ent
	A._placerStartPos = Vector(vPos.x, vPos.y, vPos.z)
	A._placerStartAng = Angle(aAng.p, aAng.y, aAng.r)
	A._placerPos = Vector(vPos.x, vPos.y, vPos.z)
	A._placerAng = Angle(aAng.p, aAng.y, aAng.r)
	A._placerOpen = true
	Mode = "move"
	Drag = nil
	LastStream = 0

	net.Start("EVO_Agri:PlacerBegin")
	net.WriteEntity(ent)
	net.SendToServer()

	if contextOpen() then showPanel() end
end

function A.ClosePlacer(bCommit)
	if not A._placerOpen then return end
	closePlacer(bCommit and true or false)
end

hook.Add("OnContextMenuOpen", "EVO_Agri::PlacerPanel", function()
	if A._placerOpen then showPanel() end
end)

hook.Add("OnContextMenuClose", "EVO_Agri::PlacerPanel", function()
	Drag = nil
	hidePanel()
end)

hook.Add("GUIMousePressed", "EVO_Agri::PlacerGizmo", function(mc)
	if not A._placerOpen then return end
	if mc == MOUSE_LEFT and applyPick(gui.MousePos()) then
		return true
	end
end)

hook.Add("GUIMouseReleased", "EVO_Agri::PlacerGizmoUp", function(mc)
	if mc == MOUSE_LEFT then finishDrag() end
end)

hook.Add("Think", "EVO_Agri::PlacerGizmo", function()
	if not A._placerOpen then
		GizmoScreen, HoverPick = nil, nil
		return
	end
	if not IsValid(A._placerEnt) then
		closePlacer(false)
		return
	end
	syncPanelVis()
	if not contextOpen() then
		Drag, HoverPick = nil, nil
		GizmoScreen = nil
		return
	end
	if Drag then
		if not input.IsMouseDown(MOUSE_LEFT) then
			finishDrag()
		else
			updateDrag()
		end
	end
	if edgeKey(KEY_G) then Mode = "move" end
	if edgeKey(KEY_R) then Mode = "rotate" end
end)

hook.Add("HUDPaint", "EVO_Agri::PlacerGizmo", function()
	if not A._placerOpen then return end
	if not contextOpen() then
		draw.SimpleText("Placer — maintiens C pour la souris (G move / R rotate)", "EVOAgri_Placer", ScrW() * 0.5, ScrH() * 0.86, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return
	end
	local mx, my = gui.MousePos()
	paintWorldGizmo(mx, my)
	drawModePills(ScrW() * 0.5 - 70, ScrH() * 0.12)
end)
