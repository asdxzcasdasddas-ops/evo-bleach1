-- "addons\\evo_agri\\lua\\evo_agri\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AGRI — config partagée (cultures, pots, items).
-- Une deuxième plante = une entrée dans Crops, pas une nouvelle SENT.
-- ============================================================================
EVO_AGRI = EVO_AGRI or {}
local A = EVO_AGRI

A.ENT_CLASS         = "evo_agri_pot"
A.GROW_SEC          = 30 * 60 -- 30 min par phase après arrosage
A.PLANT_RANGE       = 160
A.WATER_RANGE       = 120
A.HARVEST_RANGE     = 120
A.HARVEST_RANGE_SV  = 140 -- marge anti-rejet bord de portée
A.MOVE_RANGE        = 220 -- portée max joueur ↔ pot pendant le placement
A.MOVE_MAX_DELTA    = 256 -- écart max vs la pose au démarrage du mode Placer
A.MIN_SPACING       = 64
A.MAX_PLANTS        = 16 -- max pots par joueur (vides + plantés)
A.GROUND_DOT        = 0.72
A.SEED_PRICE        = 600 -- Urahara (lzy_npcshop), recopié en dur dans le rayon
A.POT_PRICE         = 500
A.SEED_ID           = "graine_ble"
A.WATER_ID          = "bar_eau"
-- Piles héritées bouteille_eau (item retiré) : encore consommables à l'arrosage.
A.WATER_IDS         = { "bar_eau", "bouteille_eau" }
A.WATER_ANIM        = "evo_5i142l4qixekb2fy"
A.WATER_BONE        = "ValveBiped.Bip01_L_Hand"
A.WATER_PARTICLE    = "water_splash_01"
-- Ancien modèle bar_graines : sac de grains (pas le blé planté).
A.SEED_MODEL        = "models/evo/props/items/evo_c78445edd7bd2b4126/evo_c78445edd7bd2b4126.mdl"
-- Mesh de la culture dans le pot (pas d'item inventaire).
A.PLANT_MODEL       = "models/evo/props/items/evo_152hbjfrejgvfer51efz/evo_152HBJfrejgvFER51efz.mdl"
A.SCIENCE_PLANT_MDL = "models/evo/props/items/plants/plants_01/evo_u8dwaEdKMAgaAhy1rYct.mdl"
A.POT_PLANT_OFFSET  = Vector(0, 0, 6)
A.MUSH_OFFSET       = Vector(0, 0, 10)
A.STACK_MAX         = 64
A.POT_STACK         = 16
A.WHEAT_SCALES      = { 0.75, 1.5, 2.25, 3.0 }
A.MUSH_SCALES       = { 0.45, 0.7, 0.95, 1.2 }
A.HERB_SCALES       = { 0.5, 0.8, 1.1, 1.4 }
-- Tirage wild science : common=100, rare=45, epic=18. Plus fréquent = plus de yield.
A.HARVEST_BY_RARITY = {
	common = { 3, 6 },
	rare   = { 2, 4 },
	epic   = { 2, 3 },
}

A.MushroomModels = {
	"models/evo/props/items/mushroom/mushroom_01/evo_k7m2v9qx4p.mdl",
	"models/evo/props/items/mushroom/mushroom_02/evo_r5t8n3wc6j.mdl",
	"models/evo/props/items/mushroom/mushroom_03/evo_z4h7b2kf9s.mdl",
	"models/evo/props/items/mushroom/mushroom_04/evo_p8x3m6dr2v.mdl",
	"models/evo/props/items/mushroom/mushroom_05/evo_f6q9c4ty7n.mdl",
	"models/evo/props/items/mushroom/mushroom_06/evo_w3j8s5kp2m.mdl",
	"models/evo/props/items/mushroom/mushroom_07/evo_n9v4d7rx6b.mdl",
	"models/evo/props/items/mushroom/mushroom_08/evo_c2m7q5zh8k.mdl",
	"models/evo/props/items/mushroom/mushroom_09/evo_t6b3w9fn4x.mdl",
	"models/evo/props/items/mushroom/mushroom_10/evo_h8r5k2vc7q.mdl",
	"models/evo/props/items/mushroom/mushroom_11/evo_m4x9p6jd3s.mdl",
	"models/evo/props/items/mushroom/mushroom_12/evo_q7n2f8wb5r.mdl",
	"models/evo/props/items/mushroom/mushroom_13/evo_v5c3z9kt6m.mdl",
	"models/evo/props/items/mushroom/mushroom_14/evo_j2s7r4px8n.mdl",
	"models/evo/props/items/mushroom/mushroom_15/evo_b9k6m3qh5v.mdl",
	"models/evo/props/items/mushroom/mushroom_16/evo_x4w8n2df7c.mdl",
	"models/evo/props/items/mushroom/mushroom_17/evo_d7p5v9sj3k.mdl",
	"models/evo/props/items/mushroom/mushroom_18/evo_s3q6x8mr4b.mdl",
	"models/evo/props/items/mushroom/mushroom_19/evo_g8v2k7tn5p.mdl",
	"models/evo/props/items/mushroom/mushroom_20/evo_y5m9c3wf6r.mdl",
}

A.Crops = {}
A.SeedToCrop = {}

local function harvestRange(sRar)
	local t = A.HARVEST_BY_RARITY[sRar] or A.HARVEST_BY_RARITY.common
	return t[1], t[2]
end

function A.RegisterCrop(def)
	def.stages = def.stages or 4
	def.scales = def.scales or A.WHEAT_SCALES
	def.offset = def.offset or A.POT_PLANT_OFFSET
	A.Crops[def.id] = def
	if def.seed_id then A.SeedToCrop[def.seed_id] = def.id end
end

A.RegisterCrop({
	id          = "ble",
	name        = "Plante de blé",
	seed_id     = "graine_ble",
	harvest_id  = "graine_ble",
	harvest_min = 8,
	harvest_max = 20,
	model       = A.PLANT_MODEL,
	scales      = A.WHEAT_SCALES,
	stages      = 4,
	kind        = "wheat",
})

-- Trois stades intégrés au modèle : jeune pousse / croissance / mûr.
A.RegisterCrop({
	id          = "riz",
	name        = "Plant de riz",
	seed_id     = "graine_riz",
	harvest_id  = "graine_riz",
	harvest_min = 8,
	harvest_max = 20,
	model       = "models/evo/props/recolte/plante_riz.mdl",
	scales      = { 1, 1, 1 },
	stages      = 3,
	growth_bodygroup = 0,
	sequence    = "idle",
	sequence_duration = 6,
	playback_rate = 1,
	kind        = "rice",
})

-- Champignons (2 modèles / variété ; aperçu = le 1er).
local tMush = {
	{ id = "champignon_reiatsu",   name = "Champignon de reiatsu",   rarity = "common", mdl = 1 },
	{ id = "amanite_ames",         name = "Amanite des Âmes",        rarity = "rare",   mdl = 3 },
	{ id = "morille_seireitei",    name = "Morille du Seireitei",    rarity = "rare",   mdl = 5 },
	{ id = "bolet_hueco",          name = "Bolet du Hueco",          rarity = "common", mdl = 7 },
	{ id = "cepe_menos",           name = "Cèpe des Menos",          rarity = "rare",   mdl = 9 },
	{ id = "trompette_limbes",     name = "Trompette des Limbes",    rarity = "rare",   mdl = 11 },
	{ id = "coprin_spectral",      name = "Coprin spectral",         rarity = "rare",   mdl = 13 },
	{ id = "girolle_ectoplasme",   name = "Girolle d'ectoplasme",    rarity = "epic",   mdl = 15 },
	{ id = "lepiote_carmine",      name = "Lépiote carmine",         rarity = "epic",   mdl = 17 },
	{ id = "chanterelle_garganta", name = "Chanterelle de Garganta", rarity = "epic",   mdl = 19 },
}
for i = 1, #tMush do
	local v = tMush[i]
	local nMin, nMax = harvestRange(v.rarity)
	A.RegisterCrop({
		id          = v.id,
		name        = v.name,
		seed_id     = v.id,
		harvest_id  = v.id,
		harvest_min = nMin,
		harvest_max = nMax,
		model       = A.MushroomModels[v.mdl],
		scales      = A.MUSH_SCALES,
		offset      = A.MUSH_OFFSET,
		kind        = "mushroom",
		rarity      = v.rarity,
	})
end

-- Plantes / fleurs / herbes (skin 0..9 = ordre science).
local tHerb = {
	{ id = "herbe_reishi",      name = "Herbe à reishi",    rarity = "common" },
	{ id = "feuille_lune",      name = "Feuille de lune",   rarity = "common" },
	{ id = "sauge_ames",        name = "Sauge des Âmes",    rarity = "common" },
	{ id = "fougere_spectrale", name = "Fougère spectrale", rarity = "rare" },
	{ id = "liane_garganta",    name = "Liane de Garganta", rarity = "rare" },
	{ id = "lys_seireitei",     name = "Lys du Seireitei",  rarity = "rare" },
	{ id = "chardon_hueco",     name = "Chardon du Hueco",  rarity = "rare" },
	{ id = "menthe_limbes",     name = "Menthe des Limbes", rarity = "epic" },
	{ id = "orchidee_carmine",  name = "Orchidée carmine",  rarity = "epic" },
	{ id = "rose_vide",         name = "Rose du Vide",      rarity = "epic" },
}
for i = 1, #tHerb do
	local v = tHerb[i]
	local nMin, nMax = harvestRange(v.rarity)
	A.RegisterCrop({
		id          = v.id,
		name        = v.name,
		seed_id     = v.id,
		harvest_id  = v.id,
		harvest_min = nMin,
		harvest_max = nMax,
		model       = A.SCIENCE_PLANT_MDL,
		skin        = i - 1,
		scales      = A.HERB_SCALES,
		kind        = "plant",
		rarity      = v.rarity,
	})
end

-- Houblon du Bar (common).
do
	local nMin, nMax = harvestRange("common")
	A.RegisterCrop({
		id          = "bar_houblon",
		name        = "Houblon",
		seed_id     = "bar_houblon",
		harvest_id  = "bar_houblon",
		harvest_min = nMin * 2,
		harvest_max = nMax * 2,
		model       = "models/evo/props/items/evo_1fe5262NJEFRHBufreer/evo_1fe5262NJEFRHBufreer.mdl",
		scales      = A.HERB_SCALES,
		kind        = "plant",
		rarity      = "common",
	})
end

A.Pots = {
	{ id = "pot_01", name = "Pot 01", model = "models/evo/props/items/evo_526gbhaOKRFBgvef/evo_526gbhaOKRFBgvef.mdl" },
	{ id = "pot_02", name = "Pot 02", model = "models/evo/props/items/evo_51frehbgre26rgtFRfer/evo_51frehbgre26rgtFRfer.mdl" },
	{ id = "pot_03", name = "Pot 03", model = "models/evo/props/items/evo_erf5263HBRFErfe15ref/evo_erf5263HBRFErfe15ref.mdl" },
	{ id = "pot_04", name = "Pot 04", model = "models/evo/props/items/evo_ref892ZDOKhbferez/evo_ref892ZDOKhbferez.mdl" },
	{ id = "pot_05", name = "Pot 05", model = "models/evo/props/items/evo_923NJRF2erfpokez/evo_923NJRF2erfpokez.mdl" },
	{ id = "pot_06", name = "Pot 06", model = "models/evo/props/items/evo_AOKvgvf65JIEFRHBef/evo_AOKvgvf65JIEFRHBef.mdl" },
}

A.PotsById = {}
for i = 1, #A.Pots do
	A.Pots[i].n = i
	A.PotsById[A.Pots[i].id] = A.Pots[i]
end

function A.GetCrop(sId)
	if isstring(sId) and A.Crops[sId] then return A.Crops[sId] end
	return A.Crops.ble
end

function A.CropIdFromSeed(sId)
	if sId == "bar_graines" then return "ble" end
	return A.SeedToCrop[sId]
end

function A.IsPlantable(sId)
	return A.CropIdFromSeed(sId) ~= nil
end

function A.GetPot(sId)
	return A.PotsById[sId]
end

function A.GetPotByN(n)
	return A.Pots[math.floor(tonumber(n) or 0)]
end

A.PlantPose = A.PlantPose or {}

function A.DefaultPlantPose(sCropId)
	local crop = A.Crops[sCropId]
	local pos = (crop and crop.offset) or A.POT_PLANT_OFFSET or Vector(0, 0, 6)
	local ang = (crop and crop.ang) or Angle(0, 0, 0)
	return {
		pos = Vector(pos.x, pos.y, pos.z),
		ang = Angle(ang.p, ang.y, ang.r),
	}
end

function A.GetPlantPose(sPotId, sCropId)
	local tPot = A.PlantPose[sPotId]
	if istable(tPot) then
		local pose = tPot[sCropId]
		if istable(pose) and isvector(pose.pos) then
			return {
				pos = Vector(pose.pos.x, pose.pos.y, pose.pos.z),
				ang = isangle(pose.ang) and Angle(pose.ang.p, pose.ang.y, pose.ang.r) or Angle(0, 0, 0),
			}
		end
	end
	return A.DefaultPlantPose(sCropId)
end

function A.SetPlantPose(sPotId, sCropId, vPos, aAng)
	if not (A.PotsById[sPotId] and A.Crops[sCropId] and isvector(vPos)) then return false end
	A.PlantPose[sPotId] = A.PlantPose[sPotId] or {}
	A.PlantPose[sPotId][sCropId] = {
		pos = Vector(vPos.x, vPos.y, vPos.z),
		ang = isangle(aAng) and Angle(aAng.p, aAng.y, aAng.r) or Angle(0, 0, 0),
	}
	return true
end

function A.ListCropsSorted()
	local t = {}
	for sId, crop in pairs(A.Crops) do
		t[#t + 1] = { id = sId, name = (crop and crop.name) or sId }
	end
	table.sort(t, function(a, b) return tostring(a.name) < tostring(b.name) end)
	return t
end

function A.IsSeedItem(sId)
	return A.IsPlantable(sId)
end

function A.IsPotItem(sId)
	return A.PotsById[sId] ~= nil
end

function A.IsWaterItem(sId)
	return sId == A.WATER_ID or sId == "bouteille_eau"
end

function A.CountWater(ply)
	if not (IsValid(ply) and ply.CountInventoryItem) then return 0 end
	local n = 0
	local t = A.WATER_IDS
	for i = 1, #t do
		n = n + (ply:CountInventoryItem(t[i]) or 0)
	end
	return n
end

function A.PickWaterId(ply)
	if not (IsValid(ply) and ply.CountInventoryItem) then return nil end
	local t = A.WATER_IDS
	for i = 1, #t do
		if (ply:CountInventoryItem(t[i]) or 0) > 0 then return t[i] end
	end
	return nil
end

function A.CountSeed(ply)
	return A.CountPlantable(ply)
end

function A.CountPlantable(ply)
	if not (IsValid(ply) and ply.CountInventoryItem) then return 0 end
	local n = 0
	for sSeed, _ in pairs(A.SeedToCrop) do
		n = n + (ply:CountInventoryItem(sSeed) or 0)
	end
	n = n + (ply:CountInventoryItem("bar_graines") or 0)
	return n
end

function A.ListPlantables(ply)
	local out = {}
	if not (IsValid(ply) and ply.CountInventoryItem) then return out end
	local seen = {}
	for sSeed, sCrop in pairs(A.SeedToCrop) do
		local n = ply:CountInventoryItem(sSeed) or 0
		if sSeed == A.SEED_ID then n = n + (ply:CountInventoryItem("bar_graines") or 0) end
		if n > 0 and not seen[sCrop] then
			seen[sCrop] = true
			local crop = A.Crops[sCrop]
			out[#out + 1] = {
				crop_id = sCrop,
				seed_id = sSeed,
				n = n,
				name = (crop and crop.name) or sCrop,
			}
		end
	end
	table.sort(out, function(a, b) return tostring(a.name) < tostring(b.name) end)
	return out
end

function A.PickSeedForCrop(ply, sCropId)
	local crop = A.Crops[sCropId]
	if not (crop and IsValid(ply) and ply.CountInventoryItem) then return nil end
	if (ply:CountInventoryItem(crop.seed_id) or 0) > 0 then return crop.seed_id end
	if crop.id == "ble" and (ply:CountInventoryItem("bar_graines") or 0) > 0 then
		return "bar_graines"
	end
	return nil
end

function A.PickSeedId(ply)
	return A.PickSeedForCrop(ply, "ble")
end

-- L'inventaire RÉ-ASSIGNE ITEMS à son include : retry court jusqu'à ce que la
-- table existe (même recette qu'evo_craft / evo_note).
function A.RegisterItems()
	if not istable(ITEMS) then
		return false, "ITEMS nil"
	end

	ITEMS[A.SEED_ID] = {
		name         = "Graine de blé",
		description  = "Une graine de blé : planter dans un pot (Utiliser) ou moudre à la distillerie du Bar. Récolte 8–20 graines.",
		category     = "object",
		rarity       = "common",
		model_path   = A.SEED_MODEL,
		is_droppable = true,
		is_deletable = true,
		stack_max    = A.STACK_MAX,
		on_use       = function(ply, slot)
			if SERVER then
				return
			end
			pcall(function()
				net.Start("EVO_Agri:Plant")
				net.WriteString("ble")
				net.WriteUInt(math.Clamp(math.floor(tonumber(slot) or 0), 0, 65535), 16)
				net.SendToServer()
			end)
		end,
	}

	for i = 1, #A.Pots do
		local pot = A.Pots[i]
		local sId = pot.id
		ITEMS[sId] = {
			name         = pot.name,
			description  = "Un pot de culture. Utiliser pour le poser, puis y planter une graine, un champignon ou une plante.",
			category     = "object",
			rarity       = "common",
			model_path   = pot.model,
			is_droppable = true,
			is_deletable = true,
			stack_max    = A.POT_STACK,
			on_use       = function(ply, slot)
				if SERVER then return end
				pcall(function()
					net.Start("EVO_Agri:PlacePot")
					net.WriteString(sId)
					net.WriteUInt(math.Clamp(math.floor(tonumber(slot) or 0), 0, 65535), 16)
					net.SendToServer()
				end)
			end,
		}
	end

	ITEMS.plante_ble = nil
	-- Ancien item agri : plus en rayon. Piles restantes s'affichent comme Eau.
	ITEMS.bouteille_eau = ITEMS.bar_eau

	-- Piles héritées bar_graines : même objet (planter + distillerie), plus en rayon.
	ITEMS.bar_graines = ITEMS[A.SEED_ID]

	return true, "ok"
end

local function tryRegister()
	return A.RegisterItems()
end

timer.Create("EVO_Agri::Items", 1, 60, tryRegister)
hook.Add("InitPostEntity", "EVO_Agri::Items", function()
	timer.Simple(0, tryRegister)
end)
tryRegister()
