-- "addons\\evo_agri\\lua\\evo_agri\\cl_agri.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AGRI — client : nametag via l'entité, plaque [E], panneau pot / plante.
-- ============================================================================
EVO_AGRI = EVO_AGRI or {}
local A = EVO_AGRI

surface.CreateFont("EVOAgri_Prompt", { font = "Roboto", size = 22, weight = 600, antialias = true })
surface.CreateFont("EVOAgri_PromptSub", { font = "Roboto", size = 16, weight = 400, antialias = true })

local COL_TXT    = Color(235, 235, 240)
local COL_ACCENT = Color(210, 185, 90)
local COL_BG     = Color(13, 14, 17, 220)

local function RX(n) return (gRespX and gRespX(n)) or n end
local function RY(n) return (gRespY and gRespY(n)) or n end

local _best, _bestMain, _bestSub, _nextScan = nil, "", "", 0
local _bestName, _bestInfo = "", "" -- invite unifiée : nom du pot/plante + état

local function cropOf(ent)
	return A.GetCrop and A.GetCrop(ent.GetCropId and ent:GetCropId()) or A.Crops.ble
end

local function potName(ent)
	local pot = A.GetPotByN and A.GetPotByN(ent.GetPotId and ent:GetPotId())
	return (pot and pot.name) or "Pot"
end

local function findPlant()
	if CurTime() < _nextScan then return _best end
	_nextScan = CurTime() + 0.25
	_best, _bestMain, _bestSub = nil, "", ""
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return nil end
	local range = A.HARVEST_RANGE or 120
	local vPos = lp:GetPos()
	local bestD = range * range
	for _, e in ipairs(ents.FindInSphere(vPos, range)) do
		if IsValid(e) and e:GetClass() == A.ENT_CLASS and e.GetStage and e ~= A._editorEnt and e ~= A._placerEnt then
			local d = e:GetPos():DistToSqr(vPos)
			if d <= bestD then
				bestD = d
				_best = e
			end
		end
	end
	if not IsValid(_best) then return nil end

	local nStage = _best:GetStage()
	_bestMain = "[E] Interagir"
	if nStage < 1 then
		_bestName, _bestInfo = potName(_best), "vide"
	else
		local crop = cropOf(_best)
		local nMax = (crop and crop.stages) or 4
		_bestName = (crop and crop.name) or "Plante de blé"
		_bestInfo = "phase " .. nStage .. "/" .. nMax
	end
	_bestSub = _bestName .. " · " .. _bestInfo
	return _best
end

hook.Add("HUDPaint", "EVO_Agri::Prompt", function()
	if vgui.CursorVisible() then return end
	if IsValid(A._frame) then return end
	if A._placerOpen then return end
	local ent = findPlant()
	if not IsValid(ent) then return end

	local cx, cy = ScrW() * 0.5, ScrH() * 0.78
	-- Style d'invite unifié (EVO_ZonePrompt) ; l'ancienne plaque reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.Draw2D then
		EVO_ZonePrompt.Draw2D(cx, cy, _bestName, "Interagir", "E", nil, _bestInfo)
		return
	end
	local txt, sub = _bestMain, _bestSub
	surface.SetFont("EVOAgri_Prompt")
	local tw, th = surface.GetTextSize(txt)
	surface.SetFont("EVOAgri_PromptSub")
	local sw, sh = surface.GetTextSize(sub)
	local boxW = math.max(tw, sw) + 40
	local boxH = th + sh + 26

	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, COL_BG, 8, "br")
	else
		draw.RoundedBox(0, cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, Color(0, 0, 0, 180))
	end
	surface.SetDrawColor(COL_ACCENT)
	surface.DrawRect(cx - boxW * 0.5, cy - boxH * 0.5, 2, boxH)
	draw.SimpleText(txt, "EVOAgri_Prompt", cx, cy - 8, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(sub, "EVOAgri_PromptSub", cx, cy + th * 0.5 + 2, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

local function notifyNeed(lp, msg)
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify(msg, 1, 4)
	elseif IsValid(lp) and lp.rpNotify then
		lp:rpNotify(msg, 1, 4)
	end
end

function A.SendPlantInPot(ent, sCropId)
	if not IsValid(ent) then return end
	net.Start("EVO_Agri:PlantInPot")
	net.WriteEntity(ent)
	net.WriteString(tostring(sCropId or ""))
	net.SendToServer()
end

function A.OpenCropPicker(ent)
	if not IsValid(ent) then return end

	local lp = LocalPlayer()
	local t = (A.ListPlantables and A.ListPlantables(lp)) or {}
	if #t < 1 then
		notifyNeed(lp, "Il te faut une graine, un champignon ou une plante.")
		return
	end
	if IsValid(A._frame) then A._frame:Remove() end
	if #t == 1 then
		A.SendPlantInPot(ent, t[1].crop_id)
		return
	end

	local nShow = math.min(#t, 8)
	local W, H = 380, 64 + nShow * 38 + 16
	local f = vgui.Create("DFrame")
	f:SetSize(RX(W), RY(H))
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	A._frame = f
	f.OnRemove = function()
		if A._frame == f then A._frame = nil end
	end

	f.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, RY(12))
			EVO_UI.Header(w, "PLANTER", "CHOISIS UNE RESSOURCE", 1, RX(20))
		else
			draw.RoundedBox(8, 0, 0, w, h, Color(16, 16, 20, 240))
			draw.SimpleText("Planter", "DermaLarge", RX(20), RY(18), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	if EVO_UI and EVO_UI.CloseButton then
		EVO_UI.CloseButton(f, W, function() f:Remove() end)
	end

	local sc = vgui.Create("DScrollPanel", f)
	sc:SetPos(RX(16), RY(58))
	sc:SetSize(RX(W - 32), RY(H - 70))

	local inner = vgui.Create("DPanel", sc)
	inner:SetSize(RX(W - 48), RY(#t * 36))
	inner.Paint = function() end
	if sc.AddItem then sc:AddItem(inner) end

	local col = EVO_UI and EVO_UI.Col
	for i = 1, #t do
		local row = t[i]
		local crop = A.Crops[row.crop_id]
		local nMin = (crop and crop.harvest_min) or 1
		local nMax = (crop and crop.harvest_max) or nMin
		local label = string.format("%s  x%d  (%d-%d)", row.name, row.n, nMin, nMax)
		local by = (i - 1) * 36
		if EVO_UI and EVO_UI.ActionButton then
			local b = EVO_UI.ActionButton(inner, 0, RY(by), RX(W - 48), RY(32), label, col and col.green, function()
				if not IsValid(ent) then f:Remove() return end
				A.SendPlantInPot(ent, row.crop_id)
				f:Remove()
			end)
			b:SetZPos(10)
		else
			local b = vgui.Create("DButton", inner)
			b:SetPos(0, RY(by))
			b:SetSize(RX(W - 48), RY(32))
			b:SetText(label)
			b.DoClick = function()
				if not IsValid(ent) then f:Remove() return end
				A.SendPlantInPot(ent, row.crop_id)
				f:Remove()
			end
		end
	end
end

-- empty, ripe, thirst
local function statusLine(ent)
	local nStage = ent:GetStage()
	if nStage < 1 then
		return "Vide — plante une graine, un champignon ou une plante", false, false, true
	end
	local crop = cropOf(ent)
	local nMax = (crop and crop.stages) or 4
	if nStage >= nMax then return "Mûre — prête à récolter", true, false, false end
	if ent:GetWatered() then return "En croissance — phase en cours", false, false, false end
	return "A soif — de l'eau (sac)", false, true, false
end

local function fmtLeft(nSec)
	nSec = math.max(0, math.floor((tonumber(nSec) or 0) + 0.5))
	return string.format("%d:%02d", math.floor(nSec / 60), nSec % 60)
end

-- frac 0-1, secondes restantes, growing
local function growState(ent)
	if not IsValid(ent) or not ent.GetStage then return 0, 0, false, false end
	local nStage = ent:GetStage()
	if nStage < 1 then return 0, 0, false, false end
	local crop = cropOf(ent)
	local nMax = (crop and crop.stages) or 4
	local nDur = A.GROW_SEC or 1800
	if nStage >= nMax then return 1, 0, false, true end
	if not ent:GetWatered() then return 0, nDur, false, false end
	local nEnd = (ent.GetGrowEnd and tonumber(ent:GetGrowEnd())) or 0
	if nEnd <= 0 then return 0, nDur, true, false end
	local nLeft = math.max(0, nEnd - CurTime())
	local nFrac = math.Clamp(1 - (nLeft / nDur), 0, 1)
	return nFrac, nLeft, true, false
end

function A.OpenPlantUI(ent)
	if not IsValid(ent) then return end
	if IsValid(A._frame) then A._frame:Remove() end

	local crop = cropOf(ent)
	local nMax = (crop and crop.stages) or 4
	local lp = LocalPlayer()
	local bPlanter = IsValid(lp) and ent.GetPlanter and ent:GetPlanter() == lp
	local bSA = IsValid(lp) and lp:IsSuperAdmin()
	local bOwner = IsValid(lp) and ent.GetPotOwner and ent:GetPotOwner() == lp
	local nStage = ent:GetStage()
	local sStatus, bRipe, bThirst, bEmpty = statusLine(ent)
	local sName = bEmpty and potName(ent) or ((crop and crop.name) or "Plante de blé")
	local sSub = bEmpty and "VIDE" or ("PHASE " .. nStage .. "/" .. nMax)

	local bTwoBtn = bEmpty
	local nExtra = 0
	if bOwner then nExtra = nExtra + 42 end
	if bSA then nExtra = nExtra + 42 end
	local W, H = 380, (bTwoBtn and 248 or (bEmpty and 200 or 236)) + nExtra
	local nBtnY = bTwoBtn and 112 or (bEmpty and 120 or 156)
	local f = vgui.Create("DFrame")
	f:SetSize(RX(W), RY(H))
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	A._frame = f
	f.OnRemove = function()
		if A._frame == f then A._frame = nil end
	end

	f.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, RY(12))
			EVO_UI.Header(w, string.upper(sName), sSub, 1, RX(20))
		else
			draw.RoundedBox(8, 0, 0, w, h, Color(16, 16, 20, 240))
			draw.SimpleText(sName, "DermaLarge", RX(20), RY(18), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		local col = (EVO_UI and EVO_UI.Col and EVO_UI.Col.muted) or Color(160, 160, 168)
		draw.SimpleText(sStatus, "EVOAgri_PromptSub", RX(22), RY(78), col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		if bEmpty then return end
		local nFrac, nLeft, bGrow, bDone = growState(ent)
		local bx, by, bw, bh = RX(22), RY(108), w - RX(44), RY(14)
		surface.SetDrawColor(28, 30, 36, 230)
		surface.DrawRect(bx, by, bw, bh)
		if nFrac > 0 then
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(bx, by, math.max(1, math.floor(bw * nFrac)), bh)
		end
		surface.SetDrawColor(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 80)
		surface.DrawOutlinedRect(bx, by, bw, bh, 1)

		local sBar
		if bDone then
			sBar = "Phase terminée"
		elseif bGrow then
			sBar = fmtLeft(nLeft) .. " / " .. fmtLeft(A.GROW_SEC or 1800)
		else
			sBar = "En attente d'eau — 30:00"
		end
		draw.SimpleText(sBar, "EVOAgri_PromptSub", bx + bw, by - RY(16), COL_ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	end

	if EVO_UI and EVO_UI.CloseButton then
		EVO_UI.CloseButton(f, W, function() f:Remove() end)
	end

	local col = EVO_UI and EVO_UI.Col
	local function btn(bx, by, bw, bh, label, fill, fn)
		if EVO_UI and EVO_UI.ActionButton then
			local b = EVO_UI.ActionButton(f, RX(bx), RY(by), RX(bw), RY(bh), label, fill, fn)
			b:SetZPos(10)
			return b
		end
		local b = vgui.Create("DButton", f)
		b:SetPos(RX(bx), RY(by))
		b:SetSize(RX(bw), RY(bh))
		b:SetText(label)
		b.DoClick = fn
		return b
	end

	if bEmpty then
		btn(20, nBtnY, W - 40, 36, "PLANTER", col and col.green, function()
			if not IsValid(ent) then f:Remove() return end
			A.OpenCropPicker(ent)
		end)
		btn(20, nBtnY + 42, W - 40, 36, "RAMASSER", nil, function()
			if not IsValid(ent) then f:Remove() return end
			net.Start("EVO_Agri:Pickup")
			net.WriteEntity(ent)
			net.SendToServer()
			f:Remove()
		end)
	elseif bThirst then
		btn(20, nBtnY, W - 40, 36, "ARROSER", col and col.green, function()
			if not IsValid(ent) then f:Remove() return end
			local nHave = (A.CountWater and A.CountWater(lp)) or 0
			if nHave < 1 then
				notifyNeed(lp, "Il te faut de l'eau.")
				return
			end
			net.Start("EVO_Agri:Water")
			net.WriteEntity(ent)
			net.SendToServer()
			f:Remove()
		end)
	elseif bRipe and bPlanter then
		btn(20, nBtnY, W - 40, 36, "RÉCOLTER", col and col.green, function()
			if not IsValid(ent) then f:Remove() return end
			net.Start("EVO_Agri:Harvest")
			net.WriteEntity(ent)
			net.SendToServer()
			f:Remove()
		end)
	else
		btn(20, nBtnY, W - 40, 36, "FERMER", nil, function() f:Remove() end)
	end

	local nExtraY = nBtnY + (bEmpty and 84 or 42)
	if bOwner then
		btn(20, nExtraY, W - 40, 36, "PLACER", col and col.green, function()
			if not IsValid(ent) then f:Remove() return end
			f:Remove()
			if A.OpenPlacer then A.OpenPlacer(ent) end
		end)
		nExtraY = nExtraY + 42
	end
	if bSA then
		btn(20, nExtraY, W - 40, 36, "SUPPRIMER", col and col.red, function()
			if not IsValid(ent) then f:Remove() return end
			net.Start("EVO_Agri:Delete")
			net.WriteEntity(ent)
			net.SendToServer()
			f:Remove()
		end)
	end
end

net.Receive("EVO_Agri:Open", function()
	local ent = net.ReadEntity()
	A.OpenPlantUI(ent)
end)

hook.Add("PlayerButtonDown", "EVO_Agri::InteractKey", function(ply, btn)
	if ply ~= LocalPlayer() or btn ~= KEY_E then return end
	if vgui.CursorVisible() then return end
	if gui.IsGameUIVisible() then return end
	if IsValid(vgui.GetKeyboardFocus()) then return end
	if IsValid(A._frame) then return end
	if A._placerOpen then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end

	local ent = findPlant()
	if not IsValid(ent) then return end
	net.Start("EVO_Agri:Open")
	net.WriteEntity(ent)
	net.SendToServer()
end)
