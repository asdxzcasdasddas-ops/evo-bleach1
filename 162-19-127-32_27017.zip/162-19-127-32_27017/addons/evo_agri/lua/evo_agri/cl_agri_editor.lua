-- "addons\\evo_agri\\lua\\evo_agri\\cl_agri_editor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO AGRI — client : petit panneau SuperAdmin + gizmo XYZ local au pot.
-- ============================================================================
if not CLIENT then return end

EVO_AGRI = EVO_AGRI or {}
local A = EVO_AGRI

local COL_ACCENT = Color(210, 185, 90)
local COL_TXT    = Color(235, 235, 240)
local COL_DIM    = Color(160, 160, 168)
local AXIS_COLORS = {
	Color(207, 68, 78),
	Color(78, 196, 128),
	Color(90, 140, 240),
}
local AXIS_NAMES = { "X", "Y", "Z" }
local GIZMO_PICK_PX = 22
local GIZMO_CENTER_PICK_PX = 16

surface.CreateFont("EVOAgri_Editor", { font = "Roboto", size = 15, weight = 500, antialias = true })

local function RX(n) return (gRespX and gRespX(n)) or n end
local function RY(n) return (gRespY and gRespY(n)) or n end

local Drag
local HoverAxis
local GizmoCache
local OffsetLbl

local function copyPose(pose)
	pose = pose or { pos = Vector(0, 0, 6), ang = Angle(0, 0, 0) }
	local pos = pose.pos or Vector(0, 0, 6)
	local ang = pose.ang or Angle(0, 0, 0)
	return {
		pos = Vector(pos.x, pos.y, pos.z),
		ang = Angle(ang.p, ang.y, ang.r),
	}
end

local function editorPose()
	local ent = A._editorEnt
	if IsValid(ent) and istable(ent._agriEditPose) then
		return ent._agriEditPose
	end
	return copyPose(A.GetPlantPose and A.GetPlantPose(A._editorPot, A._editorCrop))
end

local function setEditorPose(pose)
	local ent = A._editorEnt
	if not IsValid(ent) then return end
	ent._agriEditPose = copyPose(pose)
end

local function refreshOffsetLbl()
	if not IsValid(OffsetLbl) then return end
	local pose = editorPose()
	local p = pose.pos
	OffsetLbl:SetText(string.format("Offset  %.1f  %.1f  %.1f", p.x, p.y, p.z))
end

local function contextOpen()
	return MUGEN and MUGEN.IsContextMenuOpen and MUGEN.IsContextMenuOpen()
end

local function getContextFrame()
	local world = vgui.GetWorldPanel()
	if not IsValid(world) then return nil end
	for _, p in ipairs(world:GetChildren()) do
		if IsValid(p) and p.ClassName == "LZY:ContextMenu" then return p end
	end
end

local function overEditor()
	if not IsValid(A._editorFrame) then return false end
	local p = vgui.GetHoveredPanel()
	while IsValid(p) do
		if p == A._editorFrame then return true end
		p = p:GetParent()
	end
	return false
end

local function distPointSq(px, py, x, y)
	local dx, dy = px - x, py - y
	return dx * dx + dy * dy
end

local function distPointToSegmentSq(px, py, x1, y1, x2, y2)
	local dx, dy = x2 - x1, y2 - y1
	local lenSq = dx * dx + dy * dy
	if lenSq < 1e-6 then return distPointSq(px, py, x1, y1) end
	local t = math.Clamp(((px - x1) * dx + (py - y1) * dy) / lenSq, 0, 1)
	return distPointSq(px, py, x1 + dx * t, y1 + dy * t)
end

local function axisWorldDir(ent, axis)
	if axis == 1 then return ent:GetForward() end
	if axis == 2 then return ent:GetRight() end
	return ent:GetUp()
end

local function buildGizmoCache(ent, pose)
	if not (IsValid(ent) and istable(pose) and isvector(pose.pos)) then return nil end
	local origin = ent:LocalToWorld(pose.pos)
	local originScr = origin:ToScreen()
	if not originScr.visible then return nil end
	local arm = math.Clamp(origin:Distance(EyePos()) * 0.075, 20, 64)
	local cache = { origin = { x = originScr.x, y = originScr.y }, axes = {}, arm = arm }
	for axis = 1, 3 do
		local endScr = (origin + axisWorldDir(ent, axis) * arm):ToScreen()
		if endScr.visible then
			cache.axes[axis] = { x1 = originScr.x, y1 = originScr.y, x2 = endScr.x, y2 = endScr.y }
		end
	end
	return cache
end

local function pickAxis(mx, my, cache)
	if not cache or not cache.origin then return nil end
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= GIZMO_CENTER_PICK_PX * GIZMO_CENTER_PICK_PX then
		return nil
	end
	local bestPick, bestScore = nil, GIZMO_PICK_PX * GIZMO_PICK_PX
	for axis = 1, 3 do
		local seg = cache.axes[axis]
		if seg then
			local distSq = distPointToSegmentSq(mx, my, seg.x1, seg.y1, seg.x2, seg.y2)
			if distSq < bestScore then
				bestScore, bestPick = distSq, axis
			end
		end
	end
	return bestPick
end

local function axisDragDelta(axis, dx, dy, cache)
	local seg = cache and cache.axes[axis]
	if not seg then return 0 end
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.sqrt(sx * sx + sy * sy)
	if len < 0.01 then return 0 end
	sx, sy = sx / len, sy / len
	return ((dx * sx + dy * sy) / len) * (cache.arm or 0)
end

local function drawAxis(seg, col, highlight, label)
	if not seg then return end
	local drawCol = highlight and color_white or col
	surface.SetDrawColor(drawCol)
	surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.max(math.sqrt(sx * sx + sy * sy), 0.01)
	sx, sy = sx / len, sy / len
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * 7 + sy * 4, seg.y2 - sy * 7 - sx * 4)
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * 7 - sy * 4, seg.y2 - sy * 7 + sx * 4)
	draw.SimpleText(label, "EVOAgri_Editor", seg.x2 + sx * 10, seg.y2 + sy * 10, drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function sendSpawn()
	if not (A._editorPot and A._editorCrop) then return end
	net.Start("EVO_Agri:EditorSpawn")
	net.WriteString(A._editorPot)
	net.WriteString(A._editorCrop)
	net.WriteUInt(A._editorStage or 4, 3)
	net.SendToServer()
end

local function sendStage(n)
	A._editorStage = n
	net.Start("EVO_Agri:EditorStage")
	net.WriteUInt(n, 3)
	net.SendToServer()
end

local function sendSave()
	local pose = editorPose()
	net.Start("EVO_Agri:EditorSave")
	net.WriteString(A._editorPot or "")
	net.WriteString(A._editorCrop or "")
	net.WriteVector(pose.pos)
	net.WriteAngle(pose.ang)
	net.SendToServer()
end

function A.CloseEditorUI()
	Drag, HoverAxis, GizmoCache = nil, nil, nil
	if IsValid(A._editorEnt) then A._editorEnt._agriEditPose = nil end
	A._editorEnt = nil
	A._editorOpen = nil
	if IsValid(A._editorFrame) then A._editorFrame:Remove() end
	A._editorFrame = nil
	OffsetLbl = nil
end

local function hideEditorPanel()
	if IsValid(A._editorFrame) then A._editorFrame:Remove() end
	A._editorFrame = nil
	OffsetLbl = nil
	Drag = nil
end

local function buildEditorPanel(parent)
	if not IsValid(parent) then return end
	if IsValid(A._editorFrame) then A._editorFrame:Remove() end

	local crops = (A.ListCropsSorted and A.ListCropsSorted()) or {}
	local W, H = 280, 318
	local f = vgui.Create("DPanel", parent)
	f:SetSize(RX(W), RY(H))
	f:SetPos(RX(16), RY(56))
	f:SetMouseInputEnabled(true)
	f:SetKeyboardInputEnabled(false)
	A._editorFrame = f
	f.OnRemove = function()
		if A._editorFrame == f then A._editorFrame = nil end
	end

	f.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCard then
			EVO_UI.PaintCard(w, h, 1, RY(12))
			EVO_UI.Header(w, "AGRI EDITOR", "POT + POSE", 1, RX(16))
		else
			draw.RoundedBox(8, 0, 0, w, h, Color(16, 16, 20, 240))
			draw.SimpleText("Agri editor", "DermaLarge", RX(16), RY(12), color_white)
		end
	end

	local y = 62
	local function label(txt)
		local l = vgui.Create("DLabel", f)
		l:SetPos(RX(16), RY(y))
		l:SetSize(RX(W - 32), RY(16))
		l:SetFont("EVOAgri_Editor")
		l:SetTextColor(COL_DIM)
		l:SetText(txt)
		y = y + 18
	end

	label("Pot")
	local potBox = vgui.Create("DComboBox", f)
	potBox:SetPos(RX(16), RY(y))
	potBox:SetSize(RX(W - 32), RY(24))
	for i = 1, #(A.Pots or {}) do
		local pot = A.Pots[i]
		potBox:AddChoice(pot.name or pot.id, pot.id, pot.id == A._editorPot)
	end
	potBox.OnSelect = function(_, _, _, id)
		if id == A._editorPot then return end
		A._editorPot = id
		sendSpawn()
	end
	y = y + 32

	label("Plante")
	local cropBox = vgui.Create("DComboBox", f)
	cropBox:SetPos(RX(16), RY(y))
	cropBox:SetSize(RX(W - 32), RY(24))
	for i = 1, #crops do
		local row = crops[i]
		cropBox:AddChoice(row.name, row.id, row.id == A._editorCrop)
	end
	cropBox.OnSelect = function(_, _, _, id)
		if id == A._editorCrop then return end
		A._editorCrop = id
		local crop = A.GetCrop(id)
		A._editorStage = math.Clamp(A._editorStage or 1, 1, crop.stages or 4)
		sendSpawn()
		buildEditorPanel(parent)
	end
	y = y + 32

	label("Phase")
	local phaseY = y
	local crop = A.GetCrop(A._editorCrop)
	for i = 1, crop.stages or 4 do
		local n = i
		local b = vgui.Create("DButton", f)
		b:SetPos(RX(16 + (i - 1) * 62), RY(phaseY))
		b:SetSize(RX(56), RY(26))
		b:SetText(tostring(n))
		b.DoClick = function() sendStage(n) end
		b.Paint = function(s, bw, bh)
			local on = (A._editorStage or 4) == n
			surface.SetDrawColor(on and COL_ACCENT or Color(40, 42, 48))
			surface.DrawRect(0, 0, bw, bh)
			draw.SimpleText(tostring(n), "EVOAgri_Editor", bw * 0.5, bh * 0.5, on and Color(20, 20, 22) or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	y = phaseY + 36

	OffsetLbl = vgui.Create("DLabel", f)
	OffsetLbl:SetPos(RX(16), RY(y))
	OffsetLbl:SetSize(RX(W - 32), RY(18))
	OffsetLbl:SetFont("EVOAgri_Editor")
	OffsetLbl:SetTextColor(COL_ACCENT)
	OffsetLbl:SetText("Offset  0.0  0.0  0.0")
	refreshOffsetLbl()
	y = y + 26

	local hint = vgui.Create("DLabel", f)
	hint:SetPos(RX(16), RY(y))
	hint:SetSize(RX(W - 32), RY(28))
	hint:SetFont("EVOAgri_Editor")
	hint:SetTextColor(COL_DIM)
	hint:SetWrap(true)
	hint:SetText("Maintiens C. Glisse les axes X/Y/Z.")
	y = y + 34

	local function action(bx, sLabel, fill, fn)
		if EVO_UI and EVO_UI.ActionButton then
			return EVO_UI.ActionButton(f, RX(bx), RY(y), RX(118), RY(32), sLabel, fill, fn)
		end
		local b = vgui.Create("DButton", f)
		b:SetPos(RX(bx), RY(y))
		b:SetSize(RX(118), RY(32))
		b:SetText(sLabel)
		b.DoClick = fn
		return b
	end
	local col = EVO_UI and EVO_UI.Col
	action(16, "ENREGISTRER", col and col.green, sendSave)
	action(146, "FERMER", nil, function()
		net.Start("EVO_Agri:EditorClose")
		net.SendToServer()
		A.CloseEditorUI()
	end)
end

local function showEditorPanel()
	if not A._editorOpen then return end
	local ctx = getContextFrame()
	if not IsValid(ctx) then return end
	if IsValid(A._editorFrame) then
		if A._editorFrame:GetParent() ~= ctx then
			A._editorFrame:SetParent(ctx)
			A._editorFrame:SetPos(RX(16), RY(56))
		end
		A._editorFrame:SetVisible(true)
		return
	end
	buildEditorPanel(ctx)
end

local function syncEditorPanelVis()
	if A._editorOpen and contextOpen() then
		showEditorPanel()
	elseif IsValid(A._editorFrame) then
		hideEditorPanel()
	end
end

function A.OpenEditorUI()
	A._editorOpen = true
	A._editorPot = A._editorPot or "pot_01"
	A._editorStage = A._editorStage or 4
	local crops = (A.ListCropsSorted and A.ListCropsSorted()) or {}
	if not A._editorCrop and crops[1] then A._editorCrop = crops[1].id end
	sendSpawn()
	syncEditorPanelVis()
end

net.Receive("EVO_Agri:EditorOpen", function()
	A.OpenEditorUI()
end)

net.Receive("EVO_Agri:EditorClose", function()
	A.CloseEditorUI()
end)

net.Receive("EVO_Agri:EditorSpawn", function()
	local ent = net.ReadEntity()
	local nIdx = net.ReadUInt(16)
	A._editorPot = net.ReadString()
	A._editorCrop = net.ReadString()
	A._editorStage = net.ReadUInt(3)
	local function bind()
		local e = IsValid(ent) and ent or Entity(nIdx)
		if not IsValid(e) then return false end
		A._editorEnt = e
		setEditorPose(A.GetPlantPose(A._editorPot, A._editorCrop))
		refreshOffsetLbl()
		return true
	end
	if bind() then return end
	timer.Create("EVO_Agri::EditorBind", 0.05, 20, function()
		if bind() then timer.Remove("EVO_Agri::EditorBind") end
	end)
end)

net.Receive("EVO_Agri:EditorSync", function()
	A.PlantPose = {}
	local nPot = net.ReadUInt(8)
	for _ = 1, nPot do
		local sPot = net.ReadString()
		local nCrop = net.ReadUInt(8)
		for _ = 1, nCrop do
			local sCrop = net.ReadString()
			local pos = net.ReadVector()
			local ang = net.ReadAngle()
			if A.SetPlantPose then A.SetPlantPose(sPot, sCrop, pos, ang) end
		end
	end
	if A._editorOpen and A._editorPot and A._editorCrop then
		setEditorPose(A.GetPlantPose(A._editorPot, A._editorCrop))
		refreshOffsetLbl()
	end
end)

hook.Add("OnContextMenuOpen", "EVO_Agri::EditorPanel", function()
	if A._editorOpen then showEditorPanel() end
end)

hook.Add("OnContextMenuClose", "EVO_Agri::EditorPanel", function()
	Drag = nil
	hideEditorPanel()
end)

hook.Add("GUIMousePressed", "EVO_Agri::EditorGizmo", function(mc)
	if mc ~= MOUSE_LEFT or not A._editorOpen or not contextOpen() then return end
	if overEditor() then return end
	local ent = A._editorEnt
	if not IsValid(ent) then return end
	local cache = buildGizmoCache(ent, editorPose())
	local mx, my = gui.MousePos()
	local axis = pickAxis(mx, my, cache)
	if not axis then return end
	Drag = { axis = axis, lastX = mx, lastY = my, cache = cache }
end)

hook.Add("GUIMouseReleased", "EVO_Agri::EditorGizmoUp", function(mc)
	if mc == MOUSE_LEFT then Drag = nil end
end)

hook.Add("Think", "EVO_Agri::EditorGizmo", function()
	if not A._editorOpen then
		GizmoCache, HoverAxis = nil, nil
		return
	end
	syncEditorPanelVis()
	if not contextOpen() then
		Drag, HoverAxis = nil, nil
		GizmoCache = nil
		return
	end
	local ent = A._editorEnt
	local pose = editorPose()
	GizmoCache = IsValid(ent) and buildGizmoCache(ent, pose) or nil
	local mx, my = gui.MousePos()
	HoverAxis = (not Drag) and pickAxis(mx, my, GizmoCache) or (Drag and Drag.axis)

	if Drag then
		if not input.IsMouseDown(MOUSE_LEFT) or not IsValid(ent) then
			Drag = nil
			return
		end
		local dx, dy = mx - Drag.lastX, my - Drag.lastY
		Drag.lastX, Drag.lastY = mx, my
		local delta = axisDragDelta(Drag.axis, dx, dy, Drag.cache)
		if delta ~= 0 then
			local p = copyPose(pose)
			if Drag.axis == 1 then p.pos.x = p.pos.x + delta
			elseif Drag.axis == 2 then p.pos.y = p.pos.y + delta
			else p.pos.z = p.pos.z + delta end
			p.pos.x = math.Clamp(p.pos.x, -128, 128)
			p.pos.y = math.Clamp(p.pos.y, -128, 128)
			p.pos.z = math.Clamp(p.pos.z, -128, 128)
			setEditorPose(p)
			refreshOffsetLbl()
		end
	end
end)

hook.Add("HUDPaint", "EVO_Agri::EditorGizmo", function()
	if not A._editorOpen then return end
	if not contextOpen() then
		draw.SimpleText("Agri editor — maintiens C pour la souris", "EVOAgri_Editor", ScrW() * 0.5, ScrH() * 0.86, COL_ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		return
	end
	if not GizmoCache then return end
	if GizmoCache.origin then
		surface.SetDrawColor(255, 255, 255, 220)
		surface.DrawRect(GizmoCache.origin.x - 3, GizmoCache.origin.y - 3, 6, 6)
	end
	for axis = 1, 3 do
		drawAxis(GizmoCache.axes[axis], AXIS_COLORS[axis], HoverAxis == axis, AXIS_NAMES[axis])
	end
end)
