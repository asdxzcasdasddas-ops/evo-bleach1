-- "addons\\evo_equilibrage\\lua\\evo_equilibrage\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if not CLIENT then return end

EVO_EQUILIBRAGE = EVO_EQUILIBRAGE or {}

local ACCENT   = Color(207, 68, 78)
local FOND     = Color(14, 14, 18, 250)
local SURFACE  = Color(255, 255, 255, 10)
local LIGNE    = Color(255, 255, 255, 26)
local TEXTE    = Color(236, 236, 241)
local ESTOMPE  = Color(150, 150, 165)
local VERT     = Color(95, 211, 152)

local tArts, tStyles, tDivisions, tVoies, nGradeMax = {}, {}, {}, {}, 16

-- Nom lisible d'un art. Piège : dans lzy_skilltree/config.lua, TOUTES les catégories
-- d'art portent le même name générique « Art Spirituel » -> la liste affichait
-- « Art Spirituel » en boucle (remonté par le pôle équilibrage 07/23). Les vrais noms
-- (Ardeur, Glace, Pétales…) vivent dans LZY_ART_NAME_FR, qui n'existe que CÔTÉ CLIENT
-- (vgui/category.lua) : le serveur ne peut donc pas les envoyer, on les résout ici.
local function NomArt(tItem)
    local sCle = string.lower(tostring(tItem.id or ""))
    local sFr = LZY_ART_NAME_FR and LZY_ART_NAME_FR[sCle]
    if sFr and sFr ~= "" then return sFr end
    -- Repli : le nom du serveur s'il est spécifique, sinon la clé remise en forme.
    local sNom = tostring(tItem.nom or "")
    if sNom ~= "" and string.lower(sNom) ~= "art spirituel" then return sNom end
    return (tostring(tItem.id or ""):gsub("_", " "))
end

-- Liste des arts avec leur VRAI nom, triée sur ce nom (le tri serveur portait sur
-- le libellé générique, donc sur rien).
local function ArtsAffichables()
    local t = {}
    for _, it in ipairs(tArts) do
        t[#t + 1] = { id = it.id, nom = NomArt(it) }
    end
    table.sort(t, function(a, b) return a.nom < b.nom end)
    return t
end
local bSansCD, bPV, bBrut, bReiatsu, bStaff = false, false, false, false, false
local pPanneau

surface.CreateFont("EVO_Equi_Titre", { font = "Bebas Neue", size = 30, weight = 500, extended = true })
surface.CreateFont("EVO_Equi_Section", { font = "Roboto", size = 14, weight = 700, extended = true })
surface.CreateFont("EVO_Equi_Texte", { font = "Roboto", size = 16, weight = 500, extended = true })
surface.CreateFont("EVO_Equi_Petit", { font = "Roboto", size = 13, weight = 400, extended = true })

local function envoyer(sAction, valeur)
    net.Start("evo_equi_action")
        net.WriteString(sAction)
        net.WriteTable({ valeur = valeur })
    net.SendToServer()
end

local function titreSection(parent, sTexte)
    local l = parent:Add("DLabel")
    l:Dock(TOP)
    l:DockMargin(0, 14, 0, 6)
    l:SetTall(18)
    l:SetFont("EVO_Equi_Section")
    l:SetTextColor(ESTOMPE)
    l:SetText(string.upper(sTexte))
    return l
end

local function bouton(parent, sTexte, fClic, colFond)
    local b = parent:Add("DButton")
    b:Dock(TOP)
    b:DockMargin(0, 0, 0, 8)
    b:SetTall(38)
    b:SetText("")
    b.Paint = function(s, w, h)
        local c = colFond or SURFACE
        surface.SetDrawColor(s:IsHovered() and Color(c.r + 20, c.g + 20, c.b + 20, math.min(255, c.a + 30)) or c)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(LIGNE)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText(sTexte, "EVO_Equi_Texte", w / 2, h / 2, TEXTE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        fClic()
    end
    return b
end

local function liste(parent, tItems, sVide, fChoix)
    local c = parent:Add("DComboBox")
    c:Dock(TOP)
    c:DockMargin(0, 0, 0, 8)
    c:SetTall(36)
    c:SetValue(sVide)
    c:SetTextColor(TEXTE)
    c:SetFont("EVO_Equi_Texte")
    c.Paint = function(s, w, h)
        surface.SetDrawColor(SURFACE)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(LIGNE)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    for _, it in ipairs(tItems) do c:AddChoice(it.nom, it.id) end
    c.OnSelect = function(_, _, _, data) fChoix(data) end
    return c
end

-- Interrupteur : vert quand actif. Les trois options de test partagent le meme
-- rendu, ca evite d'ecrire trois fois la meme chose.
local function interrupteur(parent, fEtat, sOff, sOn, fClic)
    local b = parent:Add("DButton")
    b:Dock(TOP)
    b:DockMargin(0, 0, 0, 8)
    b:SetTall(38)
    b:SetText("")
    b.Paint = function(s2, w, h)
        local on = fEtat()
        local c = on and Color(46, 125, 91, 60) or SURFACE
        surface.SetDrawColor(s2:IsHovered() and Color(c.r + 20, c.g + 20, c.b + 20, math.min(255, c.a + 30)) or c)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(on and VERT or LIGNE)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText(on and sOn or sOff, "EVO_Equi_Texte", w / 2, h / 2,
            on and VERT or TEXTE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    b.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        fClic()
    end
    return b
end

-- Nom explicite : 'aide' seul entrait en collision avec une variable locale
-- du meme nom plus bas, qui masquait la fonction et la rendait inappelable.
local function ligneAide(parent, sTexte, nHaut)
    local l = parent:Add("DLabel")
    l:Dock(TOP)
    l:DockMargin(0, 0, 0, 8)
    l:SetTall(nHaut or 32)
    l:SetWrap(true)
    l:SetFont("EVO_Equi_Petit")
    l:SetTextColor(ESTOMPE)
    l:SetText(sTexte)
    return l
end

local function ouvrirPanneau()
    if IsValid(pPanneau) then pPanneau:Remove() end

    local L, H = 420, 620
    pPanneau = vgui.Create("DFrame")
    pPanneau:SetSize(L, H)
    pPanneau:Center()
    pPanneau:SetTitle("")
    pPanneau:ShowCloseButton(false)
    pPanneau:MakePopup()
    pPanneau.Paint = function(s, w, h)
        surface.SetDrawColor(FOND)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(LIGNE)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        surface.SetDrawColor(ACCENT)
        surface.DrawRect(0, 0, w, 2)
        draw.SimpleText("ÉQUILIBRAGE", "EVO_Equi_Titre", 20, 26, TEXTE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("Outils de test. Rien n'est sauvegardé.", "EVO_Equi_Petit", 20, 50, ESTOMPE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local x = pPanneau:Add("DButton")
    x:SetSize(34, 34)
    x:SetPos(L - 42, 10)
    x:SetText("")
    x.Paint = function(s, w, h)
        draw.SimpleText("✕", "EVO_Equi_Texte", w / 2, h / 2,
            s:IsHovered() and ACCENT or ESTOMPE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    x.DoClick = function() pPanneau:Remove() end

    local corps = pPanneau:Add("DScrollPanel")
    corps:Dock(FILL)
    corps:DockMargin(20, 46, 20, 20)
    local barre = corps:GetVBar()
    barre:SetWide(4)
    barre.Paint = function() end
    barre.btnUp.Paint, barre.btnDown.Paint = function() end, function() end
    barre.btnGrip.Paint = function(s, w, h)
        surface.SetDrawColor(LIGNE)
        surface.DrawRect(0, 0, w, h)
    end

    -- ── Art spirituel ──
    titreSection(corps, "Art spirituel")
    ligneAide(corps, "Débloque tous les sorts de l'art et les équipe dans la barre.", 32)
    liste(corps, ArtsAffichables(), "Choisir un art…", function(id) envoyer("art", id) end)

    -- ── Points de compétence ──
    titreSection(corps, "Points de compétence")
    bouton(corps, "+ 10 000 points", function() envoyer("points", true) end)

    -- ── Grade ──
    titreSection(corps, "Grade de faction")
    local tGrades = {}
    for i = 1, nGradeMax do tGrades[#tGrades + 1] = { id = i, nom = "Grade " .. i } end
    liste(corps, tGrades, "Choisir un grade…", function(id) envoyer("grade", id) end)

    -- ── Style de combat ──
    titreSection(corps, "Style de combat")
    if #tStyles > 0 then
        liste(corps, tStyles, "Choisir un style…", function(id) envoyer("style", id) end)
    else
        local vide = corps:Add("DLabel")
        vide:Dock(TOP)
        vide:DockMargin(0, 0, 0, 8)
        vide:SetTall(20)
        vide:SetFont("EVO_Equi_Petit")
        vide:SetTextColor(ESTOMPE)
        vide:SetText("Aucun style chargé sur ce serveur.")
    end

    -- ── Sorts de division ──
    titreSection(corps, "Sorts de division")
    if #tDivisions > 0 then
        ligneAide(corps, "Donne les sorts d'une division et les équipe dans les slots libres. Ne change PAS ta division.", 32)
        liste(corps, tDivisions, "Choisir une division…", function(id) envoyer("division", id) end)
    else
        ligneAide(corps, "Aucune division avec des sorts sur ce serveur.", 20)
    end

    -- ── Sorts de voie ──
    titreSection(corps, "Sorts de voie")
    if #tVoies > 0 then
        ligneAide(corps, "Donne les 5 sorts d'une voie (Katana / Hakuda) et les équipe. Ne change PAS ta façon de se battre : pour les LANCER, prends un style de cette voie juste au-dessus.", 46)
        liste(corps, tVoies, "Choisir une voie…", function(id) envoyer("voie", id) end)
    else
        ligneAide(corps, "Aucune voie de combat chargée sur ce serveur.", 20)
    end

    -- ── Déblocages ──
    titreSection(corps, "Débloquer")
    ligneAide(corps, "Vol et shunpo sont verrouillés tant que l'apprentissage n'est pas fait ; le vol de combat au niveau 100.", 46)
    bouton(corps, "Débloquer le vol", function() envoyer("debloquer", "fly") end)
    bouton(corps, "Débloquer le shunpo", function() envoyer("debloquer", "shunpo") end)
    bouton(corps, "Débloquer le vol de combat", function() envoyer("debloquer", "airwalk") end)
    bouton(corps, "Tout débloquer", function() envoyer("debloquer", "tout") end)

    -- ── Options de test ──
    titreSection(corps, "Tests")

    -- Mannequin de frappe : sans cible, impossible de mesurer un sort sans mobiliser
    -- un 2e testeur juste pour rester immobile.
    ligneAide(corps, "Pose un mannequin devant toi : 10 000 PV, immobile, il encaisse sans riposter. 4 au maximum.", 46)
    bouton(corps, "Faire spawn un mannequin", function() envoyer("bot", "spawn") end)
    bouton(corps, "Retirer les mannequins", function() envoyer("bot", "clear") end)

    ligneAide(corps, "10 000 PV pour toi. Sans ça tu meurs avant d'avoir pu mesurer quoi que ce soit.", 32)
    interrupteur(corps, function() return bPV end, "Passer à 10 000 PV", "10 000 PV",
        function() bPV = not bPV envoyer("pv", bPV) end)

    ligneAide(corps, "10 000 de reiatsu, rempli en continu. Tu peux enchaîner les sorts sans attendre la régénération.", 32)
    interrupteur(corps, function() return bReiatsu end, "Passer à 10 000 de reiatsu", "10 000 de reiatsu",
        function() bReiatsu = not bReiatsu envoyer("reiatsu", bReiatsu) end)

    ligneAide(corps, "Tes sorts tapent la valeur écrite dans la config, sans le bonus de grade, l'âge du perso, les points de reiatsu ni la défense de la cible.", 46)
    interrupteur(corps, function() return bBrut end, "Dégâts bruts", "Dégâts bruts",
        function() bBrut = not bBrut envoyer("brut", bBrut) end)

    ligneAide(corps, "Supprime le temps de recharge de tes sorts. Les autres joueurs ne sont pas affectés.", 32)
    interrupteur(corps, function() return bSansCD end, "Couper les cooldowns", "Cooldowns coupés",
        function() bSansCD = not bSansCD envoyer("cooldown", bSansCD) end)

    -- ── Mode staff ──
    titreSection(corps, "Mode staff")
    ligneAide(corps, "Le même que !staff : invisible, intangible, invincible, vol libre. Il se coupe aussi tout seul si tu meurs.", 46)
    interrupteur(corps, function() return bStaff end, "Passer en mode staff", "Mode staff actif",
        function() envoyer("staff", true) end)
end

net.Receive("evo_equi_ouvrir", function()
    tArts = net.ReadTable() or {}
    tStyles = net.ReadTable() or {}
    tDivisions = net.ReadTable() or {}
    tVoies = net.ReadTable() or {}
    nGradeMax = net.ReadUInt(8)
    bSansCD = net.ReadBool()
    bPV = net.ReadBool()
    bBrut = net.ReadBool()
    bReiatsu = net.ReadBool()
    bStaff = net.ReadBool()
    ouvrirPanneau()
end)

net.Receive("evo_equi_etat", function()
    bSansCD = net.ReadBool()
    bPV = net.ReadBool()
    bBrut = net.ReadBool()
    bReiatsu = net.ReadBool()
    bStaff = net.ReadBool()
end)

-- La touche vient du menu de binds (« equilibrage_panel »). On demande les listes
-- au serveur : c'est lui qui décide si le panneau s'ouvre.
hook.Add("PlayerButtonDown", "EVO::Equilibrage::Touche", function(ply, bouton)
    if not IsFirstTimePredicted() then return end
    local lp = LocalPlayer()
    if not IsValid(lp) or ply ~= lp then return end
    if not EVO_EQUILIBRAGE.PeutOuvrir(lp) then return end
    if vgui.CursorVisible() or (gui and gui.IsGameUIVisible and gui.IsGameUIVisible()) then return end

    local touche = lp.GetBindKey and lp:GetBindKey("equilibrage_panel")
    if not touche or touche == KEY_NONE or bouton ~= touche then return end

    if IsValid(pPanneau) then pPanneau:Remove() return end
    net.Start("evo_equi_demande")
    net.SendToServer()
end)
