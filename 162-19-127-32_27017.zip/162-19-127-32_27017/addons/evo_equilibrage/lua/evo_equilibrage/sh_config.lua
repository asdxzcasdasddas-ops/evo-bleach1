-- "addons\\evo_equilibrage\\lua\\evo_equilibrage\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
EVO_EQUILIBRAGE = EVO_EQUILIBRAGE or {}

-- Rang SAM qui ouvre le panneau. Créé par sv_main (hérite de "user", donc
-- AUCUN pouvoir SAM : le rang ne sert qu'à ouvrir ce menu).
EVO_EQUILIBRAGE.Rang = "equilibrage"

-- Orthographes déjà présentes chez certains serveurs : on les accepte pour ne pas
-- exiger un renommage, et on ne recrée pas de doublon.
EVO_EQUILIBRAGE.RangsEquivalents = {
    "equilibrage", "Equilibrage", "Équilibrage", "équilibrage",
    "moderateur_equilibrage", "Modérateur - Equilibrage", "Modérateur - Équilibrage",
}

EVO_EQUILIBRAGE.GradeMax = 16
EVO_EQUILIBRAGE.PointsParClic = 10000

-- Qui a le droit d'ouvrir le panneau ? Le superadmin toujours (il a déjà tout),
-- et quiconque porte l'un des rangs d'équilibrage.
-- Cette fonction est SHARED : le client s'en sert pour afficher la touche, le
-- serveur pour valider chaque action. Le client peut mentir, pas le serveur.
function EVO_EQUILIBRAGE.PeutOuvrir(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    if ply:IsSuperAdmin() then return true end

    local sRang = ply.GetUserGroup and ply:GetUserGroup() or ""
    for _, r in ipairs(EVO_EQUILIBRAGE.RangsEquivalents) do
        if sRang == r then return true end
    end
    return false
end

-- Coupure de cooldown PAR JOUEUR (pas la variable globale DevMode).
-- Lue par le calcul de cooldown du système de sorts.
function EVO_EQUILIBRAGE.SansCooldown(ply)
    return IsValid(ply) and ply._EvoEquiSansCD == true
end

-- PV de test : sans ça on meurt en deux coups et on ne peut rien mesurer.
EVO_EQUILIBRAGE.PV_TEST = 10000

-- Lue par lzy_stats (ApplyStats) : tant que c'est vrai, le max de PV est FORCÉ à
-- PV_TEST. Sans ça le moindre ApplyStats (inventaire, grade, métier, loot, SAM…)
-- ramenait le max au calcul normal et les 10 000 PV sautaient aussitôt.
function EVO_EQUILIBRAGE.PvTest(ply)
    return IsValid(ply) and ply._EvoEquiPV == true
end

-- Reiatsu de test : 10 000, et rempli en continu. Sans ça on lance trois sorts
-- puis on attend la régénération, ce qui rend toute mesure pénible.
-- Pas d'accesseur ici comme pour les cooldowns ou les dégâts bruts : aucun autre
-- addon n'a besoin de connaître cet état, seul sv_main s'en sert.
EVO_EQUILIBRAGE.REIATSU_TEST = 10000

-- Dégâts BRUTS : on annule tout ce qui multiplie la valeur écrite dans la config
-- (grade, âge du personnage, points de reiatsu, stats, défenses de la cible).
-- Sans ça, mesurer un sort donne un chiffre qui dépend de qui le lance et de qui
-- le reçoit, donc deux mesures ne sont jamais comparables.
-- Lue par sv_spell_utils (scaling de grade) et lzy_stats (tous les autres bonus).
function EVO_EQUILIBRAGE.DegatsBruts(ply)
    return IsValid(ply) and ply._EvoEquiBrut == true
end
