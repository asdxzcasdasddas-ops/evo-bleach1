-- "addons\\evo_equilibrage\\lua\\autorun\\sh_loader_equilibrage.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO ÉQUILIBRAGE — petit panneau de test pour le pôle Équilibrage.
-- ----------------------------------------------------------------------------
-- Un rang SAM « equilibrage » (aucun pouvoir SAM, comme les autres rangs staff)
-- ouvre une touche dans le menu de binds. Le panneau permet de :
--   - changer d'art spirituel (débloque et équipe tous ses sorts)
--   - se donner des points de compétence pour monter les paliers
--   - changer de grade de faction
--   - changer de style de combat
--   - couper ses propres cooldowns
--
-- ⚠️ Le « DevMode » historique (utils/sv_devmode.lua) est une variable GLOBALE :
-- il change le comportement du serveur ENTIER (bots, commande hp, cooldowns de
-- tous les superadmins). Le donner à un modérateur sur un serveur vivant serait
-- dangereux. Ici les cooldowns sont coupés PAR JOUEUR, et rien d'autre ne bouge.
--
-- Sécurité : l'ouverture est filtrée côté client, mais CHAQUE action est
-- revalidée côté serveur — les messages réseau sont appelables par n'importe
-- quel client.
-- ============================================================================

EVO_EQUILIBRAGE = EVO_EQUILIBRAGE or {}

if SERVER then
    util.AddNetworkString("evo_equi_ouvrir")   -- sv -> cl : autorise l'ouverture + envoie les listes
    util.AddNetworkString("evo_equi_demande")  -- cl -> sv : demande les listes
    util.AddNetworkString("evo_equi_action")   -- cl -> sv : une action du panneau
    util.AddNetworkString("evo_equi_etat")     -- sv -> cl : etat courant (no-cooldown)

    AddCSLuaFile("evo_equilibrage/sh_config.lua")
    AddCSLuaFile("evo_equilibrage/cl_main.lua")
end

include("evo_equilibrage/sh_config.lua")

if SERVER then
    include("evo_equilibrage/sv_main.lua")
    include("evo_equilibrage/sv_trace.lua")
else
    include("evo_equilibrage/cl_main.lua")
end
