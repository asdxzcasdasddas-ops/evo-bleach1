-- "addons\\evo_persos_fps\\lua\\autorun\\client\\cl_persos_analyse.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[ ============================================================================
     ANALYSE DU COUT DES PERSONNAGES (24/09/2026)

       evo_persos_analyse [secondes=6] [compare]

     Pendant N secondes, chaque DrawModel et chaque SetupBones lances depuis le
     Lua sont attribues au joueur qu'ils dessinent (le joueur lui-meme, une
     piece bonemergee dont il est le parent, ou ce qui est dessine pendant son
     rendu, comme le katana range), classes par categorie (tete, tenue, cheveux,
     tenue de division, epaulette, haori, accessoire, katana range...) et
     chronometres. Le RenderOverride de chaque joueur est enveloppe pour
     mesurer ce qu'il coute en tout, dont le Lua pur (override moins dessin
     moins squelettes). Les mannequins de lzy_crowd_spawn comptent comme des
     joueurs.

     Le rapport donne, par image : temps total, temps des joueurs, draw calls
     (une par materiau), squelettes, os, sommets ; le detail par categorie, les
     joueurs les plus chers, les modeles les plus lourds, l'etat des paliers et
     des imposteurs. Console + data/evo_persos_analyse.txt.

     `compare` : mesure avec les paliers dans leur etat actuel, puis dans
     l'etat inverse (evo_persos_actif), et donne l'ecart.
     ========================================================================= ]]
if SERVER then return end

EVO_PERSOS = EVO_PERSOS or {}
local P = EVO_PERSOS

local ENTM = FindMetaTable("Entity")
local DrawModelOrig  = ENTM.DrawModel
local SetupBonesOrig = ENTM.SetupBones

local mesure   -- nil quand rien ne tourne
local enCours  -- joueur dont le moteur dessine le modele en ce moment

local NOMS_SLOTS = {
	grade = "epaulette", brassard = "brassard", espada = "corps espada", haori = "haori",
	cape_roi = "cape du roi", division_body = "tenue de division", masque_base = "masque arrancar",
}

local function estPerso(e)
	return e._lzyCrowdDummy == true or (e.IsPlayer and e:IsPlayer())
end

local function proprietaire(e)
	if estPerso(e) then return e end
	local p = e:GetParent()
	if IsValid(p) and estPerso(p) then return p end
	if IsValid(enCours) then return enCours end
	return nil
end

local function categorie(e, prop)
	if e == prop then return "tete" end
	local parts = prop.PlayerModelParts
	if istable(parts) then
		if e == parts.body then return "tenue" end
		if e == parts.hair then return "cheveux" end
		if e == parts.beard then return "barbe" end
		if e == parts.mustache then return "moustache" end
	end
	local slot = e._lzyAccessorySlot
	if slot ~= nil then
		local s = tostring(slot)
		return NOMS_SLOTS[s] or ("accessoire slot " .. s)
	end
	local m = string.lower(e:GetModel() or "")
	if m:find("/weapons/katana/", 1, true) then return "katana range" end
	if m:find("/weapons/hakuda/", 1, true) then return "gantelet hakuda" end
	if m:find("arr_mask", 1, true) then return "masque" end
	if m:find("pet_epaule", 1, true) then return "familier" end
	if m:find("/accessories/", 1, true) then return "accessoire decale (fantome)" end
	return "autre"
end

local function nbMats(e)
	local n = e._evoNbMats
	if not n then n = #(e:GetMaterials() or {}) e._evoNbMats = n end
	return n
end

local function nbOs(e)
	local n = e._evoNbOs
	if not n then n = math.max(0, e:GetBoneCount() or 0) e._evoNbOs = n end
	return n
end

local function ligne(t, k)
	local l = t[k]
	if not l then l = { n = 0, ms = 0, nOs = 0, msOs = 0, mats = 0, os = 0, msOverride = 0 } t[k] = l end
	return l
end

local function noter(e, prop, dt)
	local cat = categorie(e, prop)
	local m, o = nbMats(e), nbOs(e)
	local c = ligne(mesure.cat, cat)
	c.n = c.n + 1 c.ms = c.ms + dt c.mats = c.mats + m c.os = c.os + o
	local j = ligne(mesure.joueur, prop)
	j.n = j.n + 1 j.ms = j.ms + dt j.mats = j.mats + m j.os = j.os + o
	local path = e:GetModel() or "?"
	local md = mesure.modele[path]
	if not md then md = { n = 0, ms = 0, cat = cat, mats = m, os = o, ent = e } mesure.modele[path] = md end
	md.n = md.n + 1 md.ms = md.ms + dt
end

local function noterOs(e, prop, dt)
	local cat = categorie(e, prop)
	local c = ligne(mesure.cat, cat)
	c.nOs = c.nOs + 1 c.msOs = c.msOs + dt
	local j = ligne(mesure.joueur, prop)
	j.nOs = j.nOs + 1 j.msOs = j.msOs + dt
end

local function installer()
	ENTM.DrawModel = function(self, flags)
		if not mesure then return DrawModelOrig(self, flags) end
		local prop = proprietaire(self)
		if not prop then return DrawModelOrig(self, flags) end
		local t = SysTime()
		DrawModelOrig(self, flags)
		noter(self, prop, SysTime() - t)
	end
	ENTM.SetupBones = function(self)
		if not mesure then return SetupBonesOrig(self) end
		local prop = proprietaire(self)
		if not prop then return SetupBonesOrig(self) end
		local t = SysTime()
		SetupBonesOrig(self)
		noterOs(self, prop, SysTime() - t)
	end
	hook.Add("PrePlayerDraw", "EVO_Persos::AnalyseDebut", function(ply) enCours = ply end)
	hook.Add("PostDrawOpaqueRenderables", "EVO_Persos::AnalyseFin", function() enCours = nil end)
end

local function desinstaller()
	ENTM.DrawModel = DrawModelOrig
	ENTM.SetupBones = SetupBonesOrig
	hook.Remove("PrePlayerDraw", "EVO_Persos::AnalyseDebut")
	hook.Remove("PostDrawOpaqueRenderables", "EVO_Persos::AnalyseFin")
	enCours = nil
end

-- Le RenderOverride de chaque joueur, enveloppe le temps de la mesure.
-- lzy_character compare RenderOverride a _lzyCompositeRenderOverride pour
-- detecter un composite a reparer : on pose l'enveloppe sur les deux, sinon le
-- watchdog reconstruirait tous les persos pendant la mesure.
-- Quelle passe du moteur appelle le rendu d'un perso : chaque appel redessine
-- TOUTES ses pieces. Vue principale opaque ou translucide, ombres, SSAO, ou une
-- autre vue (reflet d'eau, camera) reconnue au nom de sa cible de rendu.
local function passeDe(flags)
	flags = tonumber(flags) or 0
	local nom = "opaque"
	if STUDIO_SHADOWDEPTHTEXTURE and bit.band(flags, STUDIO_SHADOWDEPTHTEXTURE) ~= 0 then nom = "ombres"
	elseif STUDIO_SSAODEPTHTEXTURE and bit.band(flags, STUDIO_SSAODEPTHTEXTURE) ~= 0 then nom = "ssao"
	elseif STUDIO_TRANSPARENCY and bit.band(flags, STUDIO_TRANSPARENCY) ~= 0 then nom = "translucide" end
	local rt = render.GetRenderTarget()
	return (rt and rt:GetName() or "ecran") .. " " .. nom
end

local function enveloppe(ent)
	if not IsValid(ent) or not ent.RenderOverride or ent._evoOverrideEnveloppe then return end
	local orig = ent.RenderOverride
	local wrap = function(...)
		if not mesure then return orig(...) end
		local t = SysTime()
		orig(...)
		local j = ligne(mesure.joueur, ent)
		j.msOverride = j.msOverride + (SysTime() - t)
		local p = passeDe(select(2, ...))
		mesure.passes[p] = (mesure.passes[p] or 0) + 1
	end
	ent._evoOverrideEnveloppe = { orig = orig, wrap = wrap, composite = ent._lzyCompositeRenderOverride == orig }
	ent.RenderOverride = wrap
	if ent._lzyCompositeRenderOverride == orig then ent._lzyCompositeRenderOverride = wrap end
end

local function desenvelopper()
	local function d(ent)
		if not IsValid(ent) or not ent._evoOverrideEnveloppe then return end
		local e = ent._evoOverrideEnveloppe
		ent._evoOverrideEnveloppe = nil
		-- Reconstruit entre-temps (nouvelle apparence) : l'enveloppe a deja disparu.
		if ent.RenderOverride ~= e.wrap then return end
		ent.RenderOverride = e.orig
		if e.composite then ent._lzyCompositeRenderOverride = e.orig end
	end
	for _, ply in player.Iterator() do d(ply) end
	local dums = LZY_Crowd_Dummies and LZY_Crowd_Dummies()
	if dums then for _, x in ipairs(dums) do d(x) end end
end

-- Liste des mannequins locale a lzy_character : LZY_Crowd_Dummies() la donne.
local function envelopperTous()
	for _, ply in player.Iterator() do enveloppe(ply) end
	local dums = LZY_Crowd_Dummies and LZY_Crowd_Dummies()
	if dums then for _, x in ipairs(dums) do enveloppe(x) end end
end

-- ── Sommets par modele, calcules apres la mesure, quelques modeles par image ──
local sommetsCache = {}
local function sommetsDe(path)
	if sommetsCache[path] ~= nil then return sommetsCache[path] end
	local ok, meshes = pcall(util.GetModelMeshes, path, 0, 0)
	local n = 0
	if ok and istable(meshes) then
		for _, m in ipairs(meshes) do n = n + #(m.triangles or {}) end
	end
	sommetsCache[path] = n
	return n
end

-- ── Le rapport ───────────────────────────────────────────────────────────────
local function nomDe(ent)
	if not IsValid(ent) then return "?" end
	if ent.Nick then return ent:Nick() end
	return "mannequin " .. ent:EntIndex()
end

local function rapport(m, titre)
	local L = {}
	local function l(s) L[#L + 1] = s end
	local nf = math.max(1, m.frames)
	local msImage = m.tempsTotal / nf * 1000
	local totDraw, totMs, totOs, totMsOs, totMats, totOsN, totOverride = 0, 0, 0, 0, 0, 0, 0
	local nJoueurs = 0
	for ent, j in pairs(m.joueur) do
		if j.n > 0 or j.msOverride > 0 then nJoueurs = nJoueurs + 1 end
		totDraw = totDraw + j.n totMs = totMs + j.ms totOs = totOs + j.nOs totMsOs = totMsOs + j.msOs
		totMats = totMats + j.mats totOsN = totOsN + j.os totOverride = totOverride + j.msOverride
	end
	local sommets = 0
	for path, md in pairs(m.modele) do sommets = sommets + (sommetsCache[path] or 0) * md.n end
	local c0, c1, c2 = P.Compte()
	local imp = P.ImposteurStats and m.imposteurs or { actifs = 0, regenParSeconde = 0 }
	local luaPur = (totOverride - totMs - totMsOs) / nf * 1000

	l(string.format("=== %s : %d s, %d images, %.1f images/s, %s, %dx%d ===", titre, m.duree, m.frames, m.frames / m.duree, os.date("%Y-%m-%d %H:%M:%S"), ScrW(), ScrH()))
	l(string.format("  paliers : actif=%s dist_loin=%d dist_imposteur=%d lumiere=%s | %d proches, %d lointains, %d imposteurs (%d a l'ecran, %.1f photos/s)",
		P.Actif() and "1" or "0", P.DistLoin(), P.DistImposteur(), GetConVar("evo_persos_lumiere"):GetString(), c0, c1, c2, imp.actifs or 0, imp.regenParSeconde or 0))
	l(string.format("  PAR IMAGE : %.2f ms au total ; joueurs %.2f ms (dessin %.2f + squelettes %.2f + Lua des overrides %.2f)",
		msImage, (totMs + totMsOs) / nf * 1000 + math.max(0, luaPur), totMs / nf * 1000, totMsOs / nf * 1000, math.max(0, luaPur)))
	l(string.format("  PAR IMAGE : %d persos dessines, %.0f modeles, %.0f draw calls (materiaux), %.0f squelettes, %.0f os, %.2f M sommets",
		nJoueurs, totDraw / nf, totMats / nf, totOs / nf, totOsN / nf, sommets / nf / 1e6))
	if nJoueurs > 0 then
		l(string.format("  PAR PERSO  : %.1f modeles, %.1f draw calls, %.1f squelettes, %.3f ms", totDraw / nf / nJoueurs, totMats / nf / nJoueurs, totOs / nf / nJoueurs, ((totMs + totMsOs) / nf * 1000) / nJoueurs))
	end
	-- Plus d'un appel par perso et par image = le perso entier est redessine.
	local passes = {}
	for nom, n in pairs(m.passes or {}) do passes[#passes + 1] = { nom = nom, n = n } end
	table.sort(passes, function(a, b) return a.n > b.n end)
	if #passes > 0 then
		local s = {}
		for _, p in ipairs(passes) do s[#s + 1] = string.format("%s %.1f", p.nom, p.n / nf) end
		l("  PASSES (appels du rendu des persos par image) : " .. table.concat(s, ", "))
	end

	l("  -- par categorie (par image) --")
	l(string.format("  %-28s %7s %8s %9s %7s %8s %8s", "categorie", "modeles", "drawcall", "sommets", "squel.", "ms_dess", "ms_squel"))
	local cats = {}
	for k, c in pairs(m.cat) do cats[#cats + 1] = { k = k, c = c } end
	table.sort(cats, function(a, b) return (a.c.ms + a.c.msOs) > (b.c.ms + b.c.msOs) end)
	for _, x in ipairs(cats) do
		local c = x.c
		local som = 0
		for path, md in pairs(m.modele) do if md.cat == x.k then som = som + (sommetsCache[path] or 0) * md.n end end
		l(string.format("  %-28s %7.1f %8.1f %9.0f %7.1f %8.3f %8.3f", x.k, c.n / nf, c.mats / nf, som / nf, c.nOs / nf, c.ms / nf * 1000, c.msOs / nf * 1000))
	end

	l("  -- les 12 persos les plus chers (par image) --")
	l(string.format("  %-24s %-9s %5s %7s %8s %6s %8s %7s", "perso", "palier", "dist", "modeles", "drawcall", "os", "ms_total", "ms_lua"))
	local js = {}
	for ent, j in pairs(m.joueur) do js[#js + 1] = { e = ent, j = j } end
	table.sort(js, function(a, b) return (a.j.msOverride + a.j.ms) > (b.j.msOverride + b.j.ms) end)
	local lp = LocalPlayer()
	local NOMS = { [0] = "proche", [1] = "lointain", [2] = "imposteur" }
	for i = 1, math.min(12, #js) do
		local e, j = js[i].e, js[i].j
		local total = math.max(j.msOverride, j.ms + j.msOs)
		l(string.format("  %-24s %-9s %5d %7.1f %8.1f %6.0f %8.3f %7.3f", string.sub(nomDe(e), 1, 24), NOMS[IsValid(e) and P.Palier(e) or 0],
			IsValid(e) and IsValid(lp) and e:GetPos():Distance(lp:EyePos()) or 0, j.n / nf, j.mats / nf, j.os / nf, total / nf * 1000, math.max(0, j.msOverride - j.ms - j.msOs) / nf * 1000))
	end

	l("  -- les 12 modeles les plus lourds (cout total sur la mesure) --")
	l(string.format("  %-26s %6s %5s %4s %8s %7s  %s", "categorie", "instan", "mats", "os", "sommets", "ms/img", "modele"))
	local ms = {}
	for path, md in pairs(m.modele) do ms[#ms + 1] = { p = path, md = md } end
	table.sort(ms, function(a, b) return a.md.ms > b.md.ms end)
	for i = 1, math.min(12, #ms) do
		local md = ms[i].md
		l(string.format("  %-26s %6.1f %5d %4d %8s %7.3f  %s", md.cat, md.n / nf, md.mats, md.os,
			sommetsCache[ms[i].p] and tostring(sommetsCache[ms[i].p]) or "?", md.ms / nf * 1000, string.sub(ms[i].p, -60)))
	end
	return table.concat(L, "\n")
end

-- ── Deroulement ──────────────────────────────────────────────────────────────
local function demarrer(duree, titre, fini)
	if mesure then print("[persos] mesure deja en cours") return end
	installer()
	envelopperTous()
	if P.ImposteurStats then P.ImposteurStats() end -- remet le compteur de photos a zero
	mesure = { cat = {}, joueur = {}, modele = {}, passes = {}, frames = 0, tempsTotal = 0, duree = duree, titre = titre, fini = fini,
		tDebut = SysTime(), dernier = SysTime() }
	print(string.format("[persos] mesure « %s » pendant %d s, ne bouge pas la camera", titre, duree))
end

hook.Add("Think", "EVO_Persos::Analyse", function()
	if not mesure then return end
	local now = SysTime()
	mesure.frames = mesure.frames + 1
	mesure.tempsTotal = mesure.tempsTotal + (now - mesure.dernier)
	mesure.dernier = now
	if now - mesure.tDebut < mesure.duree then return end

	local m = mesure
	mesure = nil
	desinstaller()
	desenvelopper()
	m.imposteurs = P.ImposteurStats and P.ImposteurStats() or nil
	-- Sommets : util.GetModelMeshes est lourd, on l'etale sur plusieurs images
	-- et seulement pour les 40 modeles les plus dessines.
	local file_ = {}
	for path, md in pairs(m.modele) do file_[#file_ + 1] = { p = path, n = md.n } end
	table.sort(file_, function(a, b) return a.n > b.n end)
	local i = 0
	timer.Create("EVO_Persos::Sommets", 0, 0, function()
		for _ = 1, 2 do
			i = i + 1
			if i > math.min(40, #file_) then
				timer.Remove("EVO_Persos::Sommets")
				local txt = rapport(m, m.titre)
				print(txt)
				file.Append("evo_persos_analyse.txt", txt .. "\n\n")
				chat.AddText(Color(120, 230, 150), "[persos] ", color_white, "mesure « " .. m.titre .. " » finie : console + data/evo_persos_analyse.txt")
				if m.fini then m.fini(m) end
				return
			end
			sommetsDe(file_[i].p)
		end
	end)
end)

concommand.Add("evo_persos_analyse", function(_, _, args)
	local duree = math.Clamp(tonumber(args[1]) or 6, 2, 60)
	local compare = false
	for _, a in ipairs(args) do if a == "compare" then compare = true end end
	if not compare then
		demarrer(duree, "etat actuel")
		return
	end
	local avant = GetConVar("evo_persos_actif"):GetString()
	local resultats = {}
	demarrer(duree, "paliers " .. (avant == "1" and "actifs" or "coupes"), function(mA)
		resultats[1] = mA
		RunConsoleCommand("evo_persos_actif", avant == "1" and "0" or "1")
		timer.Simple(1.5, function()
			demarrer(duree, "paliers " .. (avant == "1" and "coupes" or "actifs"), function(mB)
				RunConsoleCommand("evo_persos_actif", avant)
				local function msImage(m) return m.tempsTotal / math.max(1, m.frames) * 1000 end
				local function msJoueurs(m)
					local t = 0
					for _, j in pairs(m.joueur) do t = t + math.max(j.msOverride, j.ms + j.msOs) end
					return t / math.max(1, m.frames) * 1000
				end
				local a, b = resultats[1], mB
				local txt = string.format("=== COMPARAISON : %s -> %s : image %.2f -> %.2f ms (%+.2f), joueurs %.2f -> %.2f ms (%+.2f), %.0f -> %.0f images/s",
					a.titre, b.titre, msImage(a), msImage(b), msImage(b) - msImage(a), msJoueurs(a), msJoueurs(b), msJoueurs(b) - msJoueurs(a),
					a.frames / a.duree, b.frames / b.duree)
				print(txt)
				file.Append("evo_persos_analyse.txt", txt .. "\n\n")
				chat.AddText(Color(120, 230, 150), "[persos] ", color_white, txt)
			end)
		end)
	end)
end)
