-- "addons\\evo_persos_fps\\lua\\autorun\\client\\cl_persos_paliers.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[ ============================================================================
     PALIERS DE DETAIL DES PERSONNAGES (24/09/2026)

     En rassemblement, un client dessine 40 a 60 personnages composites, chacun
     fait de 6 a 10 modeles bonemerges (tete, tenue, cheveux, insignes de
     grade, tenue de division, accessoires), avec squelette, IK des pieds,
     flexes du visage, os a ressort et eclairage calcules pour CHAQUE piece a
     CHAQUE image. Or on ne regarde de pres que les dix ou quinze plus proches.

     Ce module classe les autres joueurs en trois paliers, comme les moteurs
     modernes (proche / lointain / imposteur) :
       0  proche    : tout comme avant.
       1  lointain  : RETIRE le 28/09/2026 (LOD, flexes, ressorts, eclairage
                      partage : zero gain mesure, voir palierVoulu). Ses reglages
                      restent poses sur les pieces photographiees des imposteurs.
       2  imposteur : le personnage est rendu dans une texture et remplace par
                      un carre face camera (cl_persos_imposteur.lua). ACTIF par
                      defaut a 1000 unites (decision d'axxou du 28/09/2026),
                      reglable dans le menu Optimisations, jamais en dessous.
     Le palier est decide toutes les 0,15 s sur la distance, avec hysteresis
     (on entre a D, on ressort a 0,9 D) pour qu'un joueur qui hesite sur la
     frontiere ne clignote pas. Le rendu (lzy_character/cl_models.lua) ne fait
     que lire le palier et l'appliquer : rien n'est cree ni detruit ici.

     Convars (archivees, reprises dans le menu Optimisations) :
       evo_persos_actif 0|1           tout couper d'un coup
       evo_persos_dist_imposteur <u>  distance de l'imposteur (defaut et minimum 1000)
       evo_persos_dist_loin, evo_persos_lumiere : sans effet depuis le retrait
                                      du palier lointain
       evo_persos_debug 0|1           palier ecrit au-dessus de chaque joueur
     Mesure : evo_persos_analyse (cl_persos_analyse.lua).
     ========================================================================= ]]
if SERVER then return end

EVO_PERSOS = EVO_PERSOS or {}
local P = EVO_PERSOS

local cvActif   = CreateClientConVar("evo_persos_actif", "1", true, false, "Paliers de detail des autres joueurs (1 = actif)")
local cvLoin    = CreateClientConVar("evo_persos_dist_loin", "1500", true, false, "Distance du palier lointain, en unites")
-- Plancher a 1000 unites (demande d'axxou du 28/09/2026) : plus pres, l'image plate
-- se voit. La convar est bornee ET la valeur relue est bornee, une vieille valeur
-- enregistree plus basse ne passe pas. Pour couper : evo_persos_actif 0 (menu).
local DIST_IMPOSTEUR_MIN = 1000
local cvImp     = CreateClientConVar("evo_persos_dist_imposteur", "1000", true, false, "Distance a partir de laquelle un joueur devient une image plate (1000 minimum)", DIST_IMPOSTEUR_MIN, 20000)
local cvLumiere = CreateClientConVar("evo_persos_lumiere", "1", true, false, "Eclairage calcule une fois par joueur lointain et partage par ses pieces")
local cvDebug   = CreateClientConVar("evo_persos_debug", "0", false, false, "Ecrit le palier de chaque joueur au-dessus de sa tete")

P.FLAGS_TETE_LOIN = bit.bor(STUDIO_RENDER or 1, STUDIO_SKIP_FLEXES or 1024)
local LOD_LOIN    = 2
local HYSTERESIS  = 0.9
local INTERVALLE  = 0.15

-- Actif = le reglage du joueur ET l'interrupteur general du serveur
-- (evo_persos_images_plates, sh_persos_interrupteur.lua), lu a chaque appel :
-- la convar repliquee arrive apres le chargement de ce fichier.
function P.Actif()
	if not cvActif:GetBool() then return false end
	local general = GetConVar("evo_persos_images_plates")
	return not general or general:GetBool()
end
function P.DistLoin() return cvLoin:GetFloat() end
-- Distance reelle = la plus grande de : le reglage du joueur, le plancher de 1000,
-- et le plancher impose par le serveur (evo_persos_dist_serveur, 0 = aucun).
function P.DistImposteur()
	local serveur = GetConVar("evo_persos_dist_serveur")
	return math.max(DIST_IMPOSTEUR_MIN, cvImp:GetFloat(), serveur and serveur:GetFloat() or 0)
end

-- ── Choix du palier ──────────────────────────────────────────────────────────
local function palierVoulu(ent, dist)
	local actuel = ent._evoPalier or 0
	local dImp = P.DistImposteur()
	if dImp > 0 then
		local seuil = (actuel >= 2) and dImp * HYSTERESIS or dImp
		if dist >= seuil then return 2 end
	end
	-- Palier 1 (lointain) retire le 28/09/2026 : zero gain mesure (39,4 contre 39,6
	-- images/s sur 61 persos, le cout est en draw calls, pas en sommets), et son
	-- eclairage partage faisait clignoter la lumiere sur les joueurs a la frontiere.
	return 0
end

-- Ce qui se pose sur la TETE (le modele joueur lui-meme), une fois par changement.
-- Pas de SetIK ici : d'apres le wiki, SetIK(false) hors de Initialize ne prend
-- effet qu'apres un changement de modele, donc l'IK des pieds (deux traces au
-- sol par image et par joueur) ne se coupe pas du client. A traiter cote
-- serveur si la mesure le justifie.
local function appliquerTete(ent, palier)
	if ent._evoPalierTete == palier then return end
	ent._evoPalierTete = palier
	if ent.SetLOD then ent:SetLOD(palier >= 1 and LOD_LOIN or -1) end
end

local compte = { [0] = 0, [1] = 0, [2] = 0 }
local prochain = 0

hook.Add("Think", "EVO_Persos::Paliers", function()
	local now = CurTime()
	if now < prochain then return end
	prochain = now + INTERVALLE
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local oeil = lp:EyePos()
	-- P.Actif et pas la seule convar du joueur : coupe par le serveur, personne ne
	-- doit rester au palier imposteur (LOD, visage fige) en etant dessine en 3D.
	local actif = P.Actif()
	local spec = lp.GetEvoNWEntity and lp:GetEvoNWEntity("EVO_SpecTarget")
	local c0, c1, c2 = 0, 0, 0

	local function traiter(ent)
		local p = 0
		if actif and ent ~= lp and ent ~= spec then
			p = palierVoulu(ent, ent:GetPos():Distance(oeil))
		end
		ent._evoPalier = p
		appliquerTete(ent, p)
		if p == 2 then c2 = c2 + 1 elseif p == 1 then c1 = c1 + 1 else c0 = c0 + 1 end
	end

	for _, ply in player.Iterator() do
		if IsValid(ply) then traiter(ply) end
	end
	-- Les mannequins de lzy_crowd_spawn suivent les memes regles : c'est ce qui
	-- permet de mesurer sans reunir quarante joueurs. Leur liste est locale a
	-- lzy_character, d'ou LZY_Crowd_Dummies().
	local dums = LZY_Crowd_Dummies and LZY_Crowd_Dummies()
	if dums then
		for _, d in ipairs(dums) do
			if IsValid(d) then traiter(d) end
		end
	end
	compte[0], compte[1], compte[2] = c0, c1, c2
end)

function P.Palier(ent)
	return ent._evoPalier or 0
end

function P.Compte()
	return compte[0], compte[1], compte[2]
end

-- ── Ce qui se pose sur les PIECES bonemergees ────────────────────────────────
-- LOD force et os a ressort figes (ManipulateBoneJiggle 2 = force sans jiggle,
-- 0 = retour au modele). Une piece toute neuve au palier 0 n'a rien a recevoir.
local function appliquerPiece(m, palier)
	if not IsValid(m) or m._evoPalier == palier then return end
	if m._evoPalier == nil and palier == 0 then
		m._evoPalier = 0
		return
	end
	m._evoPalier = palier
	if m.SetLOD then m:SetLOD(palier >= 1 and LOD_LOIN or -1) end
	if m.ManipulateBoneJiggle then
		local j = (palier >= 1) and 2 or 0
		for i = 0, m:GetBoneCount() - 1 do m:ManipulateBoneJiggle(i, j) end
	end
end

-- Eclairage partage : six echantillons autour du joueur (le cube ambiant du
-- moteur), rafraichis toutes les 0,25 s, poses avant de dessiner ses pieces.
-- Le moteur ne calcule alors plus l'eclairage pour chacune d'elles.
-- (Une lumiere fixe unique a ete essayee le 28/09/2026 : rendu pire, retiree.)
local DIRS = {
	{ BOX_FRONT,  Vector(1, 0, 0) },  { BOX_BACK,   Vector(-1, 0, 0) },
	{ BOX_RIGHT,  Vector(0, 1, 0) },  { BOX_LEFT,   Vector(0, -1, 0) },
	{ BOX_TOP,    Vector(0, 0, 1) },  { BOX_BOTTOM, Vector(0, 0, -1) },
}

function P.Lumiere(ent)
	local now = CurTime()
	local e = ent._evoLum
	if e and e.t > now then return e end
	local pos = ent:WorldSpaceCenter()
	e = e or { c = {} }
	for i = 1, 6 do
		e.c[i] = render.ComputeLighting(pos, DIRS[i][2])
	end
	e.t = now + 0.25
	ent._evoLum = e
	return e
end

function P.PoserLumiere(ent)
	local e = P.Lumiere(ent)
	render.SuppressEngineLighting(true)
	render.SetLocalModelLights({})
	for i = 1, 6 do
		local c = e.c[i]
		render.SetModelLighting(DIRS[i][1], c.x, c.y, c.z)
	end
end

local lumiereActive = false

function P.PiecesDebut(ent, parts, palier)
	if not parts then return end
	appliquerPiece(parts.body, palier)
	appliquerPiece(parts.hair, palier)
	appliquerPiece(parts.beard, palier)
	appliquerPiece(parts.mustache, palier)
	if istable(parts.accessories) then
		for i = 1, #parts.accessories do appliquerPiece(parts.accessories[i], palier) end
	end
	if palier >= 1 and cvLumiere:GetBool() then
		P.PoserLumiere(ent)
		lumiereActive = true
	end
end

function P.PiecesFin()
	if lumiereActive then
		render.SuppressEngineLighting(false)
		lumiereActive = false
	end
end

-- ── Debug ────────────────────────────────────────────────────────────────────
local NOMS = { [0] = "proche", [1] = "lointain", [2] = "imposteur" }
local COULEURS = { [0] = Color(120, 230, 150), [1] = Color(240, 200, 90), [2] = Color(240, 120, 110) }

hook.Add("HUDPaint", "EVO_Persos::Debug", function()
	if not cvDebug:GetBool() then return end
	local lp = LocalPlayer()
	local function etiquette(ent)
		local s = (ent:EyePos() + Vector(0, 0, 14)):ToScreen()
		if s.visible then
			draw.SimpleTextOutlined(NOMS[ent._evoPalier] .. " " .. math.Round(ent:GetPos():Distance(lp:EyePos())),
				"DermaDefaultBold", s.x, s.y, COULEURS[ent._evoPalier], TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, color_black)
		end
	end
	for _, ply in player.Iterator() do
		if IsValid(ply) and ply ~= lp and ply:Alive() and ply._evoPalier then etiquette(ply) end
	end
	local dums = LZY_Crowd_Dummies and LZY_Crowd_Dummies()
	if dums then
		for _, d in ipairs(dums) do
			if IsValid(d) and d._evoPalier then etiquette(d) end
		end
	end
	local c0, c1, c2 = P.Compte()
	draw.SimpleTextOutlined(string.format("paliers : %d proches, %d lointains, %d imposteurs", c0, c1, c2),
		"DermaDefaultBold", 12, ScrH() - 60, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)
end)
