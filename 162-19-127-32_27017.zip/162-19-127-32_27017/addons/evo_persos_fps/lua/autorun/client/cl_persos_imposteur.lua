-- "addons\\evo_persos_fps\\lua\\autorun\\client\\cl_persos_imposteur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[ ============================================================================
     IMPOSTEURS DE JOUEURS LOINTAINS (24/09/2026)

     Palier 2 de cl_persos_paliers : le joueur n'est plus dessine par le moteur
     (PrePlayerDraw renvoie true, ce qui coupe aussi le RenderOverride de
     lzy_character et le katana range). A la place, quelques fois par seconde,
     ou des qu'on a tourne de plus de ANGLE_MORT degres autour de lui, le
     personnage complet (tete, tenue, cheveux, insignes, accessoires) est rendu
     UNE fois dans sa case d'un atlas partage (8x8 cases de 256 px), puis un
     seul carre vertical face camera par joueur, pose au moment ou le moteur
     dessine le joueur (voir PoserCarre) : zero squelette.

     C'est la technique des foules des gros jeux (billboards). De pres on
     verrait un decoupage plat, d'ou la distance de bascule
     (evo_persos_dist_imposteur, 0 = jamais).

     Un seul atlas : un RenderTarget par joueur saturerait la VRAM et
     multiplierait les changements de cible de rendu. Atlas plein (64 joueurs
     lointains a la fois) = rendu normal pour les suivants, jamais un trou.
     ========================================================================= ]]
if SERVER then return end

EVO_PERSOS = EVO_PERSOS or {}
local P = EVO_PERSOS

local TAILLE, COTE = 256, 8
local ATLAS_PX  = TAILLE * COTE
local MAX_CASES = COTE * COTE
local ANGLE_MORT = 25
local MAX_REGEN_PAR_IMAGE = 6
-- Le cadrage : camera a 1,6 hauteur, champ 42 degres -> la case couvre
-- 2 * 1,6 * tan(21) = 1,228 hauteur, centree a mi-hauteur.
local RECUL, CHAMP, COUVERTURE = 1.6, 42, 1.228

local cvHz = CreateClientConVar("evo_persos_imposteur_hz", "10", true, false, "Rafraichissements par seconde d'un imposteur")

local atlas, matAtlas
local function AtlasPret()
	if atlas then return true end
	local nom = "evo_persos_imposteur_" .. ATLAS_PX
	if GetRenderTargetEx and IMAGE_FORMAT_BGRA8888 ~= nil then
		-- 4 clamp S, 8 clamp T, 256 sans mipmap, 8192 alpha 8 bits ; profondeur
		-- separee pour que les cheveux passent devant le visage dans la photo.
		atlas = GetRenderTargetEx(nom, ATLAS_PX, ATLAS_PX, RT_SIZE_LITERAL or 1,
			MATERIAL_RT_DEPTH_SEPARATE or 1, bit.bor(4, 8, 256, 8192), 0, IMAGE_FORMAT_BGRA8888)
	end
	if not atlas then atlas = GetRenderTarget(nom, ATLAS_PX, ATLAS_PX) end
	if not atlas then return false end
	matAtlas = CreateMaterial("evo_persos_imposteur_mat", "UnlitGeneric", {
		["$basetexture"] = atlas:GetName(),
		["$alphatest"] = "1",
		-- Seuil bas : le fond est efface a 0, tout pixel du perso passe. A 0,5, un
		-- alpha de profondeur (voir Regenerer) faisait disparaitre le perso par moments.
		["$alphatestreference"] = "0.05",
		["$nolod"] = "1",
		["$nocull"] = "1",
	})
	return true
end

-- Etat par joueur : case attribuee, prochaine photo, angle de la derniere
-- photo, hauteur du personnage, derniere image ou le moteur voulait le dessiner.
local etats  = {}
local libres = {}
local stats  = { regen = 0, t0 = 0 }

local function CaseLibre()
	if #libres > 0 then return table.remove(libres) end
	local n = table.Count(etats)
	if n >= MAX_CASES then return nil end
	return n
end

-- DEBUG (30/09/2026, « ca clignote encore et des fois il disparait ») :
--   wzl_imposteur_debug 1 : une etiquette au-dessus de chaque perso suivi (ce qui a
--   ete dessine A CETTE IMAGE : carre, 3D, rien), et une ligne en console a chaque
--   changement de mode d'un perso, avec la raison. 2 : aussi chaque photo.
--   wzl_imposteur_dump : l'etat complet en console.
local cvDebug = CreateClientConVar("wzl_imposteur_debug", "0", false, false,
	"Debug des images plates : 1 = etiquettes + journal des changements, 2 = aussi les photos", 0, 2)
local function dbg() return cvDebug:GetInt() end
local function nomDe(ent)
	if IsValid(ent) and ent.Nick then return ent:Nick() end
	return tostring(ent)
end
-- Le mode du perso (carre, 3D, ineligible...), garde SUR L'ENTITE : l'etat de
-- l'imposteur peut etre libere, le journal doit survivre pour dire d'ou on vient.
local function journal(ply, mode, e)
	if dbg() <= 0 then return end
	local d = ply._wzlDbg
	if d and d.mode == mode then return end
	local oeil = EyePos()
	print(string.format("[wzl imposteur] %-24s %s -> %s | d=%d palier=%d frame=%d t=%.2f%s",
		nomDe(ply), d and d.mode or "(debut)", mode,
		IsValid(ply) and ply:GetPos():Distance(oeil) or -1, P.Palier(ply) or -1, FrameNumber(), CurTime(),
		e and string.format(" | angle=%.0f case=%s", e.angle or -999, tostring(e.case)) or ""))
	ply._wzlDbg = { mode = mode, t = CurTime() }
end

local function Liberer(ply, raison)
	local e = etats[ply]
	if not e then return end
	if dbg() > 0 then print(string.format("[wzl imposteur] %-24s etat libere (%s) frame=%d", nomDe(ply), raison or "?", FrameNumber())) end
	libres[#libres + 1] = e.case
	etats[ply] = nil
end

hook.Add("EntityRemoved", "EVO_Persos::ImposteurMenage", function(ent)
	if etats[ent] then Liberer(ent) end
end)

-- Hauteur reelle du personnage, mesuree une fois : les modeles n'ont pas tous
-- la meme taille, un carre fixe couperait les grands.
local function HauteurDe(ply)
	local mn, mx = ply:GetRenderBounds()
	local h = math.abs(mx.z - mn.z)
	return (h > 16 and h or 72)
end

-- Renvoie (ok, passager, raison) : la raison nomme la condition qui refuse, pour
-- le journal de debug. Sans elle, un perso qui clignote ne dit pas pourquoi.
local function eligible(ply)
	if P.Palier(ply) ~= 2 then return false, false, "palier" end
	-- Les mannequins de lzy_crowd_spawn sont des modeles client : ni Alive, ni portail.
	local estJoueur = ply:IsPlayer()
	if estJoueur and not ply:Alive() then return false, false, "mort" end
	local st = ply._lzyDrawState
	if not st then return false, false, "sans etat lzy" end
	if not st.shouldDraw then return false, false, "shouldDraw" end
	if not st.instanceOk then return false, false, "instance" end
	if st.hidden then return false, false, "hidden" end
	if st.tfActive then return false, false, "transformation" end
	if st.dormant then return false, false, "dormant" end
	if st.charMenuHideOthers then return false, false, "menu perso" end
	-- Hors distance de dessin, le composite n'existe plus : rien a photographier.
	if not st.inFaceRange then return false, false, "hors face range" end
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply) then return false, false, "larve" end
	if estJoueur and EVO_Portal and EVO_Portal.PlayersSeparated and EVO_Portal.PlayersSeparated(LocalPlayer(), ply) then return false, false, "portail" end
	if estJoueur and LZY_Character_ShouldDrawOtherPlayer and not LZY_Character_ShouldDrawOtherPlayer(ply) then return false, false, "ShouldDrawOtherPlayer" end
	-- Pieces absentes alors que tout le reste autorise le dessin : elles sont en
	-- construction ou en reparation. Cas passager, signale comme tel (2e valeur).
	local parts = ply.PlayerModelParts
	if not istable(parts) or not IsValid(parts.body) then return false, true, "pieces absentes" end
	return true
end

local function DessinerPiece(m)
	if IsValid(m) then m:DrawModel() end
end

--[[ La photo : le joueur et toutes ses pieces, rendus dans sa case, avec
     l'eclairage echantillonne a sa position (cl_persos_paliers) pour que la
     photo ait la luminosite de l'endroit ou il se trouve. ]]
local function Regenerer(ply, e)
	local cx = (e.case % COTE) * TAILLE
	local cy = math.floor(e.case / COTE) * TAILLE
	local centre = ply:GetPos() + Vector(0, 0, e.haut * 0.5)
	local dir = EyePos() - centre
	dir.z = 0
	if dir:LengthSqr() < 1 then return false end
	dir:Normalize()
	local recul = e.haut * RECUL

	render.PushRenderTarget(atlas)
	render.SetViewPort(cx, cy, TAILLE, TAILLE)
	render.SetScissorRect(cx, cy, cx + TAILLE, cy + TAILLE, true)
	-- Ecriture de l'alpha ouverte AVANT d'effacer : sinon, selon la carte graphique,
	-- le fond de la case garde un alpha opaque et le joueur s'affiche dans un carre.
	render.OverrideAlphaWriteEnable(true, true)
	render.Clear(0, 0, 0, 0, true, true)
	-- Dans la vue principale, le moteur ecrit la PROFONDEUR dans l'alpha (effets de
	-- profondeur) au lieu de l'opacite : la silhouette de la photo avait un alpha
	-- variable, le perso disparaissait ou changeait de lumiere d'une photo a l'autre.
	local profAlpha = render.SetWriteDepthToDestAlpha ~= nil
	if profAlpha then render.SetWriteDepthToDestAlpha(false) end
	cam.Start3D(centre + dir * recul, (dir * -1):Angle(), CHAMP, cx, cy, TAILLE, TAILLE, 1, recul * 3)
		P.PoserLumiere(ply)
		-- Un DrawModel lance hors du rendu du moteur relance le rendu complet du perso
		-- (RenderOverride de lzy_character, qui dessine deja tete ET pieces). P.enPhoto
		-- empeche l'imposteur de se remplacer lui-meme pendant sa propre photo ; les
		-- pieces ne sont dessinees ici que si ce rendu complet n'a pas tourne.
		P.enPhoto, P.photoComplete = true, false
		ply:DrawModel(P.FLAGS_TETE_LOIN)
		P.enPhoto = false
		local parts = ply.PlayerModelParts
		if not P.photoComplete and istable(parts) then
			DessinerPiece(parts.body)
			DessinerPiece(parts.hair)
			DessinerPiece(parts.beard)
			DessinerPiece(parts.mustache)
			if istable(parts.accessories) then
				for i = 1, #parts.accessories do DessinerPiece(parts.accessories[i]) end
			end
		end
		render.SuppressEngineLighting(false)
	cam.End3D()
	if profAlpha then render.SetWriteDepthToDestAlpha(true) end
	render.OverrideAlphaWriteEnable(false)
	render.SetScissorRect(0, 0, 0, 0, false)
	render.SetViewPort(0, 0, ScrW(), ScrH())
	render.PopRenderTarget()

	e.angle = dir:Angle().y
	e.photoT = SysTime()
	e.photos = (e.photos or 0) + 1
	if dbg() >= 2 then print(string.format("[wzl imposteur] %-24s photo n%d angle=%.0f frame=%d", nomDe(ply), e.photos, e.angle, FrameNumber())) end
	return true
end

-- Le carre d'un perso, pose DANS son propre dessin : il est trie avec les particules
-- comme le vrai modele et ecrit la profondeur (alphatest). Pose apres toute la scene
-- (PostDrawTranslucentRenderables, avant le 30/09), il passait devant les particules
-- situees entre lui et la camera. Les joueurs sont en RENDERMODE_TRANSCOLOR, donc
-- dessines en passe translucide : la passe opaque ne les verrait pas encore.
local PROFONDEUR = bit.bor(STUDIO_SHADOWDEPTHTEXTURE or 0, STUDIO_SSAODEPTHTEXTURE or 0)
local function PoserCarre(ply, e, flags)
	if e.angle == -999 or not matAtlas then return end
	if flags and bit.band(flags, PROFONDEUR) ~= 0 then return end
	local centre = ply:GetPos() + Vector(0, 0, e.haut * 0.5)
	local vers = EyePos() - centre
	vers.z = 0
	local s = 1 / COTE
	-- Un texel de marge dans chaque case : a la frontiere exacte, le filtrage lisse
	-- melangeait la case voisine, d'ou une fine ligne noire sur le bord du carre. Le
	-- carre retrecit d'autant pour garder la taille du perso.
	local m = 1 / ATLAS_PX
	local su = s - 2 * m
	local demi = e.haut * COUVERTURE * 0.5 * (TAILLE - 2) / TAILLE
	local right = (vers * -1):Angle():Right() * demi
	local up = Vector(0, 0, demi)
	local u0 = (e.case % COTE) * s + m
	local v0 = math.floor(e.case / COTE) * s + m
	-- Debug : on note QUELLE image et COMBIEN de fois (passes, vues) le carre a ete
	-- pose, et on le teinte en rose pour le distinguer du 3D sur une capture.
	local frame = FrameNumber()
	e.quadN = (e.quadFrame == frame) and (e.quadN + 1) or 1
	e.quadFrame = frame
	-- Quelles VUES posent le carre (ecran, reflet d'eau, portail, camera...) : c'est
	-- ce qui dit qui dessine les joueurs plusieurs fois par image.
	if dbg() > 0 then
		local rt = render.GetRenderTarget()
		local nomRT = rt and rt:GetName() or "ecran"
		if e.vuesFrame ~= frame then e.vues, e.vuesFrame = {}, frame end
		e.vues[nomRT] = (e.vues[nomRT] or 0) + 1
	end
	local cr, cg, cb = 255, 255, 255
	if dbg() > 0 then cg = 170 end
	render.SetMaterial(matAtlas)
	mesh.Begin(MATERIAL_QUADS, 1)
	mesh.Position(centre - right + up) mesh.TexCoord(0, u0, v0)           mesh.Color(cr, cg, cb, 255) mesh.AdvanceVertex()
	mesh.Position(centre + right + up) mesh.TexCoord(0, u0 + su, v0)      mesh.Color(cr, cg, cb, 255) mesh.AdvanceVertex()
	mesh.Position(centre + right - up) mesh.TexCoord(0, u0 + su, v0 + su) mesh.Color(cr, cg, cb, 255) mesh.AdvanceVertex()
	mesh.Position(centre - right - up) mesh.TexCoord(0, u0, v0 + su)      mesh.Color(cr, cg, cb, 255) mesh.AdvanceVertex()
	mesh.End()
end

-- Renvoie true si l'imposteur remplace ce personnage a cette image, et pose alors
-- son carre. On note l'image pour ne photographier que ceux que le moteur voulait
-- vraiment dessiner (a l'ecran, en PVS). Appele par PrePlayerDraw pour les joueurs et
-- par le RenderOverride de lzy_character pour les mannequins de test.
function P.ImposteurPrend(ply, flags)
	if P.enPhoto then return false end
	if not P.Actif() or P.DistImposteur() <= 0 then return false end
	if not AtlasPret() then return false end
	local e = etats[ply]
	local ok, passager, raison = eligible(ply)
	if not ok then
		-- Pieces en reconstruction : la derniere photo reste affichee, sinon le perso
		-- clignotait le temps que lzy_character le reconstruise.
		if passager and e and e.angle ~= -999 then
			e.vu = FrameNumber()
			e.passager = e.vu -- pas de nouvelle photo tant que les pieces manquent
			journal(ply, "carre (pieces absentes)", e)
			PoserCarre(ply, e, flags)
			return true
		end
		journal(ply, "3D : " .. tostring(raison), e)
		if e then Liberer(ply, raison) end
		return false
	end
	if not e then
		local c = CaseLibre()
		if not c then journal(ply, "3D : atlas plein") return false end
		e = { case = c, prochain = 0, angle = -999, haut = HauteurDe(ply) }
		etats[ply] = e
	end
	e.vu = FrameNumber()
	-- Tant que sa premiere photo n'existe pas, le perso reste dessine en 3D : sinon il
	-- disparaissait le temps d'avoir sa photo (6 photos par image au plus). L'image
	-- ou il est dessine en 3D, son carre n'est pas pose.
	if e.angle == -999 then
		e.en3D = e.vu
		journal(ply, "3D : photo pas encore prise", e)
		return false
	end
	journal(ply, "carre", e)
	PoserCarre(ply, e, flags)
	return true
end

-- PrePlayerDraw : renvoyer true empeche le moteur de dessiner le joueur (et
-- donc son RenderOverride). Rien renvoye = dessin normal.
hook.Add("PrePlayerDraw", "EVO_Persos::Imposteur", function(ply, flags)
	if P.ImposteurPrend(ply, flags) then return true end
end)

-- Les photos, une fois la scene dessinee : les carres de cette image sont deja
-- poses (PoserCarre), une photo neuve sert a l'image suivante. Meme identifiant
-- qu'avant pour qu'un rechargement du Lua remplace l'ancien hook qui dessinait.
hook.Add("PostDrawTranslucentRenderables", "EVO_Persos::ImposteurDessin", function(depth, sky)
	if sky or depth then return end
	-- VUE PRINCIPALE SEULEMENT (30/09/2026, « ca clignote encore, des fois il
	-- disparait »). Ce hook tourne aussi dans les vues secondaires (reflets d'eau,
	-- portails, cameras RenderView), ou EyePos() est la camera de CETTE vue. La
	-- photo y etait prise depuis le mauvais angle, puis reprise depuis le bon a la
	-- vue suivante : une photo par image, en ping-pong (« photo il y a 0,0 s »),
	-- d'ou le clignotement ; et une photo prise d'une camera qui ne voit pas le
	-- joueur le faisait disparaitre. Le carre d'Elio etait pose 16 fois par image :
	-- autant de vues. Une vue secondaire rend dans une cible de rendu, la vue
	-- principale dans le tampon d'ecran (cible nil).
	if render.GetRenderTarget() ~= nil then return end
	if not atlas or not next(etats) then return end
	local frame = FrameNumber()
	local now = SysTime()
	local intervalle = 1 / math.max(1, cvHz:GetInt())
	local oeil = EyePos()
	local regen = 0
	local actifs = 0

	local vus = {}
	for ply, e in pairs(etats) do
		if not IsValid(ply) then
			Liberer(ply, "entite invalide")
		elseif e.vu == frame then
			vus[#vus + 1] = { ply = ply, e = e }
		elseif e.vu and frame - e.vu > 300 then
			-- Plus vu depuis cinq secondes : on rend la case.
			Liberer(ply, "plus vu depuis 5 s")
		end
	end
	-- Les persos encore sans photo passent en premier : tant qu'ils n'en ont pas, ils
	-- sont dessines en 3D, donc chers (une foule entre d'un coup dans le champ).
	table.sort(vus, function(a, b) return a.e.angle == -999 and b.e.angle ~= -999 end)

	for i = 1, #vus do
		local ply, e = vus[i].ply, vus[i].e
		local centre = ply:GetPos() + Vector(0, 0, e.haut * 0.5)
		local vers = oeil - centre
		vers.z = 0
		local yaw = vers:Angle().y
		-- Regeneration a l'heure, ou si on a tourne autour de lui ; etalee
		-- par case et plafonnee par image, sinon le pic annule le gain.
		if regen < MAX_REGEN_PAR_IMAGE and e.passager ~= frame
			and (now >= e.prochain or math.abs(math.AngleDifference(yaw, e.angle)) > ANGLE_MORT) then
			if Regenerer(ply, e) then
				regen = regen + 1
				e.prochain = now + intervalle * (1 + (e.case % COTE) / COTE)
			end
		end
		-- Compte pour evo_persos_analyse : ceux qui ont eu un carre a cette image.
		if e.angle ~= -999 and e.en3D ~= frame then actifs = actifs + 1 end
	end
	stats.regen = stats.regen + regen
	stats.total = (stats.total or 0) + regen
	stats.actifs = actifs
	if P.TraceImage then P.TraceImage(frame, vus, oeil) end
end)

-- Pour evo_persos_analyse : imposteurs a l'ecran et photos par seconde.
function P.ImposteurStats()
	local now = SysTime()
	local dt = now - (stats.t0 or now)
	local r = { actifs = stats.actifs or 0, regenParSeconde = dt > 0 and stats.regen / dt or 0 }
	stats.regen, stats.t0 = 0, now
	return r
end

-- ── Debug : etiquettes au-dessus des persos, dump en console ────────────────
-- Ce qui compte, c'est CE QUI A ETE DESSINE A CETTE IMAGE : un perso qui clignote
-- alterne entre deux etiquettes, un perso qui disparait montre « vu, rien pose »
-- (le moteur a voulu le dessiner, on a refuse le 3D sans poser de carre) ou
-- « pas appele » (le moteur ne l'a pas dessine du tout : culling ou entite absente).
local COL_VERT, COL_JAUNE, COL_ORANGE, COL_ROUGE, COL_GRIS =
	Color(90, 255, 120), Color(255, 220, 80), Color(255, 150, 60), Color(255, 70, 70), Color(180, 180, 180)
local _rate = { t = 0, total = 0, val = 0 }
hook.Add("HUDPaint", "EVO_Persos::ImposteurDebug", function()
	if dbg() <= 0 then return end
	local frame, now, oeil = FrameNumber(), SysTime(), EyePos()
	if now - _rate.t >= 1 then
		_rate.val = ((stats.total or 0) - _rate.total) / math.max(0.001, now - _rate.t)
		_rate.t, _rate.total = now, stats.total or 0
	end
	draw.SimpleText(string.format("wzl_imposteur_debug | actif=%s  dist=%d  | etats=%d/%d  | photos/s=%.1f  | frame=%d",
		tostring(P.Actif()), P.DistImposteur(), table.Count(etats), MAX_CASES, _rate.val, frame),
		"DermaDefaultBold", 12, 300, COL_GRIS)

	local vus = {}
	for _, ply in ipairs(player.GetAll()) do if ply ~= LocalPlayer() then vus[ply] = true end end
	for ent in pairs(etats) do if IsValid(ent) then vus[ent] = true end end
	local n = 0
	for ent in pairs(vus) do
		local d = ent:GetPos():Distance(oeil)
		if d < 7000 then
			local e = etats[ent]
			local pos = (ent:GetPos() + Vector(0, 0, (e and e.haut or 72) + 12)):ToScreen()
			if pos.visible then
				local mode, col
				if e then
					if e.quadFrame == frame then
						local v = {}
						for nomRT, k in pairs(e.vues or {}) do v[#v + 1] = nomRT .. " " .. k end
						table.sort(v)
						mode, col = "CARRE x" .. (e.quadN or 1) .. " (" .. table.concat(v, ", ") .. ")", COL_VERT
					elseif e.en3D == frame then mode, col = "3D (attente photo)", COL_JAUNE
					elseif e.vu == frame then mode, col = "VU, RIEN POSE", COL_ORANGE
					else mode, col = "PAS APPELE CETTE IMAGE", COL_ROUGE end
				else
					local w = ent._wzlDbg
					mode, col = (w and w.mode or "jamais passe par ImposteurPrend"), COL_GRIS
				end
				draw.SimpleText(string.format("%s  d=%d  P%d  %s", nomDe(ent), d, P.Palier(ent) or -1, mode),
					"DermaDefaultBold", pos.x, pos.y, col, TEXT_ALIGN_CENTER)
				if e then
					draw.SimpleText(string.format("photo il y a %.1fs (n%d)  angle=%.0f  case=%s%s",
						e.photoT and (now - e.photoT) or -1, e.photos or 0, e.angle or -999, tostring(e.case),
						e.passager == frame and "  PIECES ABSENTES" or ""),
						"DermaDefaultBold", pos.x, pos.y + 14, col, TEXT_ALIGN_CENTER)
				end
				n = n + 1
				if n >= 40 then break end
			end
		end
	end
end)

-- LA TRACE : `wzl_imposteur_trace 30` note, a CHAQUE image pendant 30 s, l'etat de
-- chaque perso suivi (mode, carres poses et par quelles vues, angle, photos), puis
-- ecrit le tout dans garrysmod/data/wzl_imposteur_trace.txt. C'est ce fichier
-- qu'axxou envoie pour qu'on lise l'alternance image par image, sans rejouer.
local _trace = nil
function P.TraceImage(frame, vus, oeil)
	if not _trace then return end
	if SysTime() > _trace.fin or #_trace.lignes > 40000 then
		file.Write("wzl_imposteur_trace.txt", table.concat(_trace.lignes, "\n"))
		print(string.format("[wzl imposteur] trace terminee : %d lignes dans garrysmod/data/wzl_imposteur_trace.txt", #_trace.lignes))
		_trace = nil
		return
	end
	local ang = EyeAngles()
	for _, v in ipairs(vus) do
		local ply, e = v.ply, v.e
		local vues = {}
		for nomRT, k in pairs(e.vues or {}) do vues[#vues + 1] = nomRT .. ":" .. k end
		table.sort(vues)
		local mode = (e.quadFrame == frame) and "CARRE" or ((e.en3D == frame) and "3D" or "RIEN")
		_trace.lignes[#_trace.lignes + 1] = string.format("%d\t%.3f\t%s\t%s\tquads=%d\tvues=%s\tangle=%.0f\tphotos=%d\tphoto_age=%.3f\td=%d\tpalier=%d\tpassager=%s\toeil_yaw=%.0f\tmode_journal=%s",
			frame, SysTime() - _trace.debut, nomDe(ply), mode, e.quadN or 0, table.concat(vues, ","), e.angle or -999, e.photos or 0,
			e.photoT and (SysTime() - e.photoT) or -1, IsValid(ply) and ply:GetPos():Distance(oeil) or -1, P.Palier(ply) or -1,
			tostring(e.passager == frame), ang.y, tostring(IsValid(ply) and ply._wzlDbg and ply._wzlDbg.mode))
	end
end

concommand.Add("wzl_imposteur_trace", function(_, _, args)
	local n = math.Clamp(tonumber(args[1]) or 30, 1, 120)
	_trace = { debut = SysTime(), fin = SysTime() + n, lignes = {
		"frame\tt\tperso\tmode\tquads\tvues\tangle\tphotos\tphoto_age\td\tpalier\tpassager\toeil_yaw\tmode_journal",
	} }
	if cvDebug:GetInt() <= 0 then RunConsoleCommand("wzl_imposteur_debug", "1") end
	print(string.format("[wzl imposteur] trace lancee pour %d s (debug active) : ne bouge pas la camera brutalement, laisse clignoter", n))
end)

concommand.Add("wzl_imposteur_dump", function()
	print(string.format("[wzl imposteur] actif=%s dist=%d etats=%d/%d frame=%d photos=%d",
		tostring(P.Actif()), P.DistImposteur(), table.Count(etats), MAX_CASES, FrameNumber(), stats.total or 0))
	for ent, e in pairs(etats) do
		print(string.format("  %-24s case=%s angle=%.0f vu=%s en3D=%s quadFrame=%s quadN=%s passager=%s photos=%s mode=%s",
			nomDe(ent), tostring(e.case), e.angle or -999, tostring(e.vu), tostring(e.en3D), tostring(e.quadFrame),
			tostring(e.quadN), tostring(e.passager), tostring(e.photos), tostring(IsValid(ent) and ent._wzlDbg and ent._wzlDbg.mode)))
	end
end)
