-- "addons\\evo_persos_fps\\lua\\autorun\\sh_persos_interrupteur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[ ============================================================================
     REGLAGES GENERAUX DES IMAGES PLATES (28/09/2026)

     Convars du SERVEUR, repliquees a tous les clients. Dans la console du
     serveur (Pelican) :
       evo_persos_images_plates 0     coupees pour TOUT le monde, tout de suite
       evo_persos_images_plates 1     rendues : chaque joueur retrouve son reglage
       evo_persos_dist_serveur 5000   personne ne les voit a moins de 5000 unites
       evo_persos_dist_serveur 0      plus de plancher serveur (defaut)

     Chaque client les lit dans EVO_PERSOS.Actif et EVO_PERSOS.DistImposteur
     (cl_persos_paliers.lua). Pour que ca tienne apres un redemarrage, mettre les
     lignes dans server.cfg.
     ========================================================================= ]]
CreateConVar("evo_persos_images_plates", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED),
	"Images plates des joueurs lointains pour tout le serveur (0 = coupees pour tous)", 0, 1)
CreateConVar("evo_persos_dist_serveur", "0", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED),
	"Distance minimale des images plates imposee a tous les joueurs (0 = aucune)", 0, 20000)
