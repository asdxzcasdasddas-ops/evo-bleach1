-- "addons\\lzy_hud\\lua\\autorun\\lzy_hud_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_hud/cl_weapon_selector.lua")
	AddCSLuaFile("lzy_hud/cl_hud.lua")
	AddCSLuaFile("lzy_hud/cl_logo.lua") -- logo serveur + Discord (ex-addon lzy_logo, fusionne 2026-07-14)
	resource.AddFile("materials/evo_lg.png")
	resource.AddFile("materials/discord_logo.png")
	resource.AddFile("materials/logo_shinigami.png")
	resource.AddFile("materials/logo_hollow.png")
else
	include("lzy_hud/cl_weapon_selector.lua")
	include("lzy_hud/cl_hud.lua")
	include("lzy_hud/cl_logo.lua")
end