-- "addons\\lzy_hud\\lua\\autorun\\client\\cl_server_year.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- ANNÉE RP DU SERVEUR — « AN 1300 » en haut à DROITE, au-dessus du logo Discord (user 07/24 ;
-- initialement haut à gauche le 2026-07-23).
-- Point de départ : AN 1300 (EPOCH ci-dessous = date réelle du lancement).
-- Le temps RP avance d'1 AN PAR JOUR RÉEL (demande user 27/07) : même constante
-- que l'âge des personnages (EVO_CHARACTER_AGE_SECONDS_PER_YEAR, lzy_character
-- sh_character.lua) -> l'année du monde et l'âge des persos vieillissent au
-- MÊME rythme. Affichage Bebas + barre accent (DA Atelier), masqué quand le
-- HUD gameplay l'est (menu perso, staff mode, mode cinématique).
-- ============================================================================

if not CLIENT then return end

local YEAR_START = 1300
-- Date RÉELLE à laquelle l'an RP vaut YEAR_START (heure locale serveur ; la
-- granularité de 12 h absorbe les écarts). À CALER sur le lancement officiel.
local EPOCH = os.time({ year = 2026, month = 7, day = 23, hour = 0, min = 0, sec = 0 })

-- Année RP courante (helper global : réutilisable par d'autres UIs / le RP).
function EVO_GetServerYear()
	-- Repli aligné sur sh_character.lua (86400 = 1 an/jour). Il valait 43200 : si le
	-- fichier partagé n'était pas encore chargé, l'année RP affichée avançait deux
	-- fois plus vite que l'âge des persos, alors que les deux doivent coïncider.
	local nPerYear = EVO_CHARACTER_AGE_SECONDS_PER_YEAR or 86400
	local nElapsed = math.max(0, os.time() - EPOCH)
	return YEAR_START + math.floor(nElapsed / nPerYear)
end

-- Fontes responsive (glibs) — recréées au resize, pattern projet.
local function MakeFonts()
	if not gCreateRespFont then return end
	gCreateRespFont("EVO_ServerYear", "Bebas Neue", 28, 600)
end
hook.Add("Initialize", "EVO_ServerYear::Fonts", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_ServerYear::Fonts", MakeFonts)
MakeFonts()

local COL_TXT    = Color(235, 235, 240, 235)
local COL_ACCENT = Color(207, 68, 78, 235)
local COL_SHADOW = Color(0, 0, 0, 200)

-- Cache texte : l'année ne change que 2x par jour -> recalcul 1x/5 s,
-- ZÉRO alloc/concat par frame (règle perf projet).
local sYearText, nNextCompute = "AN " .. YEAR_START, 0

hook.Add("HUDPaint", "EVO_ServerYear::Draw", function()
	if not (gRespX and gRespY) then return end -- glibs pas encore prêt (1res frames)
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Masqué avec le reste du HUD gameplay : menu de perso + staff mode. Le mode
	-- CINÉMATIQUE n'a pas besoin de garde ici : ncm_cinematic renvoie false sur
	-- HUDShouldDraw quand il est actif -> HUDPaint ne tourne plus du tout.
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end
	if lp:GetEvoNWBool("EVO_StaffMode", false) then return end

	if RealTime() >= nNextCompute then
		nNextCompute = RealTime() + 5
		sYearText = "AN " .. EVO_GetServerYear()
	end

	-- Haut-DROITE, centré AU-DESSUS du bloc logo Discord (demande user 07/24 : déplacé de haut-gauche
	-- -> haut-droite, au-dessus du logo). Mêmes constantes que cl_logo.lua (pad 0.014, logoSize 0.13
	-- de ScrH) -> l'année est centrée sur le logo ; le bloc logo est REMONTÉ au ras du haut (topY ~0.005) et son PNG a une marge transparente en haut ; police année réduite à 24 pour
	-- lui laisser la place au-dessus.
	local pad      = math.Round(ScrH() * 0.014)
	local logoSize = math.Round(ScrH() * 0.13)
	local cx       = ScrW() - pad - logoSize / 2
	local y        = math.Round(ScrH() * 0.004)
	-- « AN 1300 » NU + entaille slash1 COLLÉE dessous (règle titre-slash : slash à TOP + 0.78 ×
	-- hauteur mesurée du texte, centré sur sa largeur) ; fallback trait accent sans EVO_UI.
	draw.SimpleTextOutlined(sYearText, "EVO_ServerYear", cx, y, COL_TXT,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, COL_SHADOW)
	surface.SetFont("EVO_ServerYear")
	local tw, th = surface.GetTextSize(sYearText)
	local inked = EVO_UI and EVO_UI.Ink
		and EVO_UI.Ink(EVO_UI.TexSlash, cx - tw * 0.575, y + th * 0.78, tw * 1.15, gRespY(9), COL_ACCENT)
	if not inked then
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(cx - tw / 2, y + th * 0.84, tw, math.max(2, gRespY(3)))
	end
end)
