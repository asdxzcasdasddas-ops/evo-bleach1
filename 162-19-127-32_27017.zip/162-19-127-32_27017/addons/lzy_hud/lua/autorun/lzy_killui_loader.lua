-- "addons\\lzy_hud\\lua\\autorun\\lzy_killui_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_killui/cl_main.lua")
	include("lzy_killui/sv_main.lua")
else
	include("lzy_killui/cl_main.lua")
end