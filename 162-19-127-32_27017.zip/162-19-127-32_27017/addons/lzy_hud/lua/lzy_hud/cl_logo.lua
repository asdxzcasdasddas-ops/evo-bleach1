-- "addons\\lzy_hud\\lua\\lzy_hud\\cl_logo.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Logo serveur en haut à droite (HUD) + lien Discord en texte, centré sous le logo.
-- Le logo est le même que le menu Échap (même chemin référencé : etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png).
local logo_material = Material("etgmnxxbvsadh9/etgmnxxbvsadh9/dazqsdqz.png", "smooth")

-- Lien Discord officiel du serveur (cf. menu Échap : bouton Discord).
local DISCORD_LINK = "discord.gg/evobleach"

-- Fonte dédiée : Gilroy (Bold) — police "cool" embarquée par le gamemode (cf. système
-- de fontes MUGEN). Recréée si la résolution change ; petite (demande user).
local function MakeLogoFonts()
    surface.CreateFont("LZY_Logo_Discord", {
        font      = "Gilroy",
        size      = math.max(11, math.Round(ScrH() * 0.013)),
        weight    = 800,
        antialias = true,
        extended  = true,
    })
end
hook.Add("Initialize", "LZY_Logo_Fonts", MakeLogoFonts)
hook.Add("OnScreenSizeChanged", "LZY_Logo_Fonts", MakeLogoFonts)
MakeLogoFonts()

hook.Add("HUDPaint", "LZY_Logo_Draw", function()
    -- Mort / écran de respawn : masquer le logo + lien Discord (ils flottaient par-dessus
    -- l'écran de mort, cf. gate Alive() de EVO:Hook:HUD).
    local lp = LocalPlayer()
    if IsValid(lp) and not lp:Alive() then return end
    local pad      = math.Round(ScrH() * 0.014)  -- marge depuis les bords
    local logoSize = math.Round(ScrH() * 0.13)   -- logo agrandi (demande user)
    local gap      = math.Round(ScrH() * -0.01)  -- décalage logo->texte (responsive, ×ScrH) : négatif = remonte le Discord, positif = descend ; ajustable

    surface.SetFont("LZY_Logo_Discord")
    local txtW = surface.GetTextSize(DISCORD_LINK)

    -- Centre commun (logo + texte) : l'élément le plus large touche le bord droit,
    -- ainsi rien ne déborde de l'écran et le texte reste CENTRÉ sous le logo.
    local blockW = math.max(logoSize, txtW)
    local cx     = ScrW() - pad - blockW / 2
    -- Y de départ du bloc (logo + Discord). REMONTÉ AU RAS DU HAUT (~0.005 × ScrH, demande user 07/24 :
    -- « remonte le logo vraiment, collé sous l'AN »). Le PNG du logo a une MARGE TRANSPARENTE en haut
    -- (le cercle EVO est dans la moitié basse de l'image carrée logoSize=0.13) -> ce haut transparent
    -- recouvre la zone de l'ANNÉE RP et le cercle visible remonte COLLÉ sous l'AN. On ne va PAS en
    -- négatif (ça couperait les flammes du logo). Plus petit = plus haut ; augmenter pour redescendre.
    -- 0.012 (au lieu de 0.005) : DESCEND très légèrement le logo pour AÉRER l'espace entre
    -- « AN 1300 » (cl_server_year, y ~0.004×ScrH) et le logo (demande user). Valeur en FRACTION
    -- de ScrH -> gap proportionnel = même rendu quelle que soit la résolution (16:9). ↑ = + d'espace.
    local topY   = math.Round(ScrH() * 0.012)

    -- Logo (centré sur cx)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(logo_material)
    surface.DrawTexturedRect(cx - logoSize / 2, topY, logoSize, logoSize)

    -- Lien Discord en texte, centré sous le logo (même cx)
    draw.SimpleTextOutlined(DISCORD_LINK, "LZY_Logo_Discord", cx, topY + logoSize + gap,
        Color(235, 238, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 220))
end)
