-- "addons\\lzy_hud\\lua\\lzy_hud\\cl_hud.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Desactive completement le scoreboard par defaut de GMod (touche TAB) : on
-- n'en veut pas dans le gamemode Bleach RP. Retourner false ici empeche le
-- gamemode_call("ScoreboardShow") de declencher l'ouverture du panel.
hook.Add("ScoreboardShow", "LZY_HUD_DisableDefaultScoreboard", function()
	return false
end)

-- ============================================================================
-- HELPERS RESPONSIVE ULTRAWIDE (3440x1440 / 5120x1440 / etc.)
-- ----------------------------------------------------------------------------
-- Le HUD est designe pour 1920x1080 avec :
--   - Annonce faction en haut (Y design ~300, anchored TOP)
--   - Player info (HP/Mana/Money/Level/PM) en bas (Y design ~920-1000, anchored BOTTOM)
--   - Tout est anchored a GAUCHE (X design 30-500)
--
-- Sur ultrawide (scaleX > scaleY) gRespX(v) etire les elements horizontalement
-- car scaleX = 1.79 vs scaleY = 1.33 -> bars rectangulaires deviennent plus
-- larges, cercles deviennent ovales, et les positions sont decalees vers la
-- droite par rapport au bord ecran.
--
-- Solution : utiliser un scale UNIFORME (min) pour tailles + positions, et
-- ancrer les Y selon le bord (top ou bottom) plutot que de scaler depuis 0.
-- ============================================================================
-- perf : hScale() est appelé ~45-50x par frame pour une valeur qui ne change
-- qu'au resize -> on cache le résultat tant que ScrW/ScrH ne bougent pas.
local _scaleW, _scaleH, _scaleVal
local function hScale()
	local w, h = ScrW(), ScrH()
	if w ~= _scaleW or h ~= _scaleH then
		_scaleW, _scaleH = w, h
		_scaleVal = math.min(w / 1920, h / 1080)
	end
	return _scaleVal
end
-- Sizes / positions X anchored a gauche, ou widths : v * minScale
local function hSz(v) return math.Round(v * hScale()) end
-- perf : noms de fonts "Avenir Next World:N" reconstruits par concat (+ sqrt dans gRespFont)
-- a chaque frame alors qu'ils ne changent qu'au resize -> caches par resolution.
local _fontResW, _fontResH, _fontAvenir12, _fontAvenir14
local function hAvenirFonts()
	local w, h = ScrW(), ScrH()
	if w ~= _fontResW or h ~= _fontResH then
		_fontResW, _fontResH = w, h
		_fontAvenir12 = "Avenir Next World:" .. gRespFont(12)
		_fontAvenir14 = "Avenir Next World:" .. gRespFont(14)
	end
	return _fontAvenir12, _fontAvenir14
end
-- perf : "X ans" reconstruit par frame alors que l'age change 1x/jour -> cache par valeur.
local _ageCacheVal, _ageCacheStr
-- Position Y anchored au BORD BAS : convertit design Y (proche de 1080) en
-- coord ecran reelle. Distance au bord bas en design = 1080-v.
local function hYB(v) return ScrH() - hSz(1080 - v) end
-- Position Y anchored au BORD HAUT : v * minScale, comme hSz.
local function hYT(v) return hSz(v) end

local materials             = {
	hp_progress_bg = Material("materials/yc5uunqp9of5t/lcnphczvzuecq.png", "smooth"),   -- 350x50
	hp_progress_fill = Material("materials/yc5uunqp9of5t/n23qet5si7v6r35d.png", "smooth"), -- 350x50
	mana_progress_bg = Material("materials/yc5uunqp9of5t/2b9y6qjn23q4.png", "smooth"),  -- 350x50
	mana_progress_fill = Material("materials/yc5uunqp9of5t/u50wafsmzhnqh.png", "smooth"), -- 350x50
	heart_icon = Material("materials/yc5uunqp9of5t/jxv5tnmmj22q.png", "smooth"),        -- 30x30
	mana_icon = Material("materials/yc5uunqp9of5t/8udagomikpm6pbg.png", "smooth"),      -- 30x30
	pm_frame = Material("materials/yc5uunqp9of5t/8s70uwkp5y2d4v.png", "smooth"),        -- 93x104
	money_icon = Material("materials/yc5uunqp9of5t/dtv26o0y16owrlzi.png", "smooth"),    -- 27x26
	hollow_icon = Material("materials/yc5uunqp9of5t/e7wafjvsp1smu2.png", "smooth"),     -- 43x43
	shinigami_icon = Material("materials/yc5uunqp9of5t/zwf4gaupu5d3h.png", "smooth"),   -- 43x43
}

-- Couleurs constantes du HUD : hoistees au scope fichier pour eviter ~19 tables
-- Color() reallouees PAR FRAME dans le hook HUDPaint (churn GC). Read-only.
local HUD_COL_WHITE         = Color(255, 255, 255, 255) -- == Color(255, 255, 255)
local HUD_COL_BLACK         = Color(0, 0, 0, 255)
local HUD_COL_GOLD          = Color(169, 159, 124, 255)
-- Debuff « blessures profondes » (ncm_heal_bed) : pilule rouge au-dessus de la vie.
-- Fond plus opaque que la pilule de l'inventaire (ici on est par-dessus le monde, pas une carte sombre).
local HUD_COL_DEBUFF_BG     = Color(60, 14, 18, 200)
local HUD_COL_DEBUFF        = Color(255, 120, 130)
-- perf : string/width/font caches (rebuild uniquement quand les minutes restantes ou la reso changent).
local _debuffKey, _debuffStr, _debuffW, _debuffFont, _debuffResW, _debuffResH
-- Bouclier spirituel (EvoStyle.GiveShield, NWFloat EVO_ShieldHP) : pilule bleutée.
local HUD_COL_SHIELD_BG     = Color(16, 34, 52, 200)
local HUD_COL_SHIELD        = Color(120, 190, 255)
local _shieldKey, _shieldStr, _shieldW, _shieldFont, _shieldResW, _shieldResH

-- Buffs potions (evo_science) : pilules SOUS la barre de reiatsu (user 08/09).
-- Largeurs memoisees par REFERENCE de liste (GetActiveEffects rebuild ~0.5 s
-- -> nouvelle table) : zero GetTextSize/alloc par frame entre deux rebuilds.
local HUD_COL_FXPILL_BG = Color(10, 10, 14, 200)
local _fxLast, _fxFont

local annonce_division_icon = Material("hnztk71178zj/9bff5xzqi48bihk.png") -- 42x43
local annonce_division_text = Material("hnztk71178zj/tak66pskkbqbztn.png") -- 206x19
local annonce_division_bar  = Material("hnztk71178zj/hjsako5d0y4p6.png")   -- 411x22

-- Faction announcement system
local announcementQueue     = {}
local currentAnnouncement   = nil
local announcementStartTime = 0
-- perf : scratch/caches du rendu d'annonce (Color mutee par frame ; upper + hauteur multiline
-- calcules une fois par TEXTE et par resolution au lieu de chaque frame).
local _annColor = Color(255, 255, 255, 255)
local _annCacheText, _annCacheW, _annCacheH, _annCacheUpper, _annCacheTexth

-- Function to show a faction announcement for a specific duration
-- Ding à l'apparition des annonces de ce canal (demande user 08/05) — distinct de la
-- cloche bell_sfx réservée à la bannière ANNONCE FACTION (lzy_annonce_faction). Joué au
-- défilement de la file (pas à la réception : une annonce en attente ne sonne pas
-- pendant la précédente).
local ANNONCE_SFX = "tgw7tau20hu4/ding_sfx.wav"

local function ShowFactionAnnouncement(text, duration, author)
	if not text or not duration then return end

	-- Add announcement to queue
	table.insert(announcementQueue, {
		text = text,
		duration = duration,
		author = author or "",
		fadeInTime = 0.5, -- Fade in over 0.5 seconds
		fadeOutTime = 0.5 -- Fade out over 0.5 seconds
	})

	-- If no announcement is currently showing, start the first one
	if not currentAnnouncement and #announcementQueue > 0 then
		currentAnnouncement = table.remove(announcementQueue, 1)
		announcementStartTime = CurTime()
		surface.PlaySound(ANNONCE_SFX)
	end
end

-- Function to clear all announcements
local function ClearFactionAnnouncements()
	announcementQueue = {}
	currentAnnouncement = nil
	announcementStartTime = 0
end

local function DrawFactionAnnouncement()
	if not LocalPlayer():GetEvoNWString("FactionName") then return end

	-- If no current announcement, try to get the next one from queue
	if not currentAnnouncement and #announcementQueue > 0 then
		currentAnnouncement = table.remove(announcementQueue, 1)
		announcementStartTime = CurTime()
		surface.PlaySound(ANNONCE_SFX)
	end

	-- If still no announcement, don't draw anything
	if not currentAnnouncement then return end

	local currentTime = CurTime()
	local elapsed = currentTime - announcementStartTime
	local alpha = 255

	-- Calculate fade in/out
	if elapsed < currentAnnouncement.fadeInTime then
		-- Fade in
		alpha = math.Round(255 * (elapsed / currentAnnouncement.fadeInTime))
	elseif elapsed > currentAnnouncement.duration - currentAnnouncement.fadeOutTime then
		-- Fade out
		local fadeOutProgress = (elapsed - (currentAnnouncement.duration - currentAnnouncement.fadeOutTime)) /
			currentAnnouncement.fadeOutTime
		alpha = math.Round(255 * (1 - fadeOutProgress))
	end

	-- Check if announcement has finished
	if elapsed >= currentAnnouncement.duration then
		currentAnnouncement = nil
		announcementStartTime = 0
		return
	end

	-- Don't draw if completely transparent
	if alpha <= 0 then return end

	-- perf : Color scratch mutee par frame (l'alpha varie) + upper/mesure caches par TEXTE
	-- et par resolution (avant : 2x string.upper + 1 mesure multiline + 1 Color PAR FRAME).
	_annColor.a = alpha
	local announcementColor = _annColor
	local baseY = hYT(300) -- TOP-anchored, uniform scale
	-- Bandeau de lieu (division / TP) au même Y ~30 % : pousser l'annonce dessous.
	local occupied = 0
	if BleachCompass_ZoneLabelsBottomY then
		occupied = math.max(occupied, BleachCompass_ZoneLabelsBottomY())
	end
	if EVO_ZoneBanner and EVO_ZoneBanner.GetBottomY then
		occupied = math.max(occupied, EVO_ZoneBanner.GetBottomY())
	end
	if occupied > 0 then
		baseY = math.max(baseY, occupied + hSz(16))
	end
	local yOff = baseY - hYT(300)

	if _annCacheText ~= currentAnnouncement.text or _annCacheW ~= ScrW() or _annCacheH ~= ScrH() then
		_annCacheText = currentAnnouncement.text
		_annCacheW, _annCacheH = ScrW(), ScrH()
		_annCacheUpper = string.upper(_annCacheText)
		local _
		_, _annCacheTexth = gGetMultilineTextSize(_annCacheUpper, "Black Han Sans Bold:24", 20, 400, 4)
	end
	local texth = _annCacheTexth

	-- Auteur sous le bandeau titre, seulement s'il est transmis (annonce de
	-- division). Le message et la barre descendent d'autant ; sans nom, le
	-- calage d'origine (12, 50, 55) reste intact.
	local sAuthor = currentAnnouncement.author or ""
	local authorPad = (sAuthor ~= "") and 20 or 0
	local designExtra = yOff * 1080 / ScrH()

	-- Espacements RAW preserves de l'origine (12, 50, 55) pour ne pas changer
	-- l'ordre/proportions des elements. Tailles + positions uniform-scaled.
	RNDX.DrawMaterial(0, hSz(3), baseY, hSz(42), hSz(43), announcementColor, annonce_division_icon)
	RNDX.DrawMaterial(0, hSz(50), baseY + hSz(12), hSz(206), hSz(19), announcementColor, annonce_division_text)
	if authorPad > 0 then
		-- Sous le visuel titre, à droite de l'icône (elle occupe le x 3..45).
		draw.SimpleText("par " .. sAuthor, "Black Han Sans:16", gRespX(50), gRespY(300 + 36 + designExtra),
			announcementColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	-- gRespDrawMultilineText scale x/y en interne -> on passe base coords (300+50=350)
	-- yOff est en pixels écran : on le reconvertit en coords design (base 1080).
	gRespDrawMultilineText(_annCacheUpper, "Black Han Sans Bold:24", 15, 300 + 50 + authorPad + designExtra,
		announcementColor, TEXT_ALIGN_LEFT, 20, 400, 4)
	RNDX.DrawMaterial(0, 0, baseY + hSz(55 + authorPad) + texth, hSz(411), hSz(22), announcementColor, annonce_division_bar)
end

local mat_vgui_white = Material("vgui/white")
local XP_RING_SEGMENTS_FULL = 56
local XP_RING_OUTER_FRAC = 0.9
local XP_RING_THICKNESS_FRAC = 0.1
local XP_RING_R, XP_RING_G, XP_RING_B, XP_RING_A = 169, 159, 124, 220

-- Cache des matrices de rotation : elles ne dépendent que de (pivot, angle), qui ne
-- changent qu'au resize ou quand le texte mesuré change (HP/argent/niveau) — PAS
-- chaque frame. Évite ~6 Matrix + ~18 Vector + 6 Angle alloués/frame (churn GC).
-- La matrice cachée n'est jamais re-mutée après création -> réutilisable telle quelle.
-- perf : cache a niveaux indexe par NOMBRES (x -> y -> angle) au lieu d'une cle string
-- concatenee a chaque appel (~7 strings + coercions nombre->string par frame pour rien).
-- Meme politique d'eviction : reset complet au-dela de 256 matrices creees.
local _rotMatCache, _rotMatCount = {}, 0
local function getRotMatrix(pivot_x, pivot_y, angle)
	local byX = _rotMatCache[pivot_x]
	local byY = byX and byX[pivot_y]
	local m = byY and byY[angle]
	if not m then
		if _rotMatCount > 256 then
			_rotMatCache, _rotMatCount = {}, 0
			byX, byY = nil, nil -- les refs pointent sur l'ancien cache jete -> a recreer
		end
		if not byX then byX = {} _rotMatCache[pivot_x] = byX end
		if not byY then byY = {} byX[pivot_y] = byY end
		m = Matrix()
		m:Translate(Vector(pivot_x, pivot_y, 0))
		m:Rotate(Angle(0, -angle, 0))
		m:Translate(Vector(-pivot_x, -pivot_y, 0))
		byY[angle] = m
		_rotMatCount = _rotMatCount + 1
	end
	return m
end

local function draw_simple_text_outlined_rotated(text, font, x, y, color, x_align, y_align, outline_width, outline_color,
												 angle)
	local text_width, text_height = surface.GetTextSize(text)

	local pivot_x = x
	local pivot_y = y

	if x_align == TEXT_ALIGN_CENTER then
		pivot_x = x - (text_width * 0.5)
	elseif x_align == TEXT_ALIGN_RIGHT then
		pivot_x = x - text_width
	end

	if y_align == TEXT_ALIGN_CENTER then
		pivot_y = y - (text_height * 0.5)
	elseif y_align == TEXT_ALIGN_BOTTOM then
		pivot_y = y - text_height
	end

	cam.PushModelMatrix(getRotMatrix(pivot_x, pivot_y, angle))
	if outline_width and outline_color then
		draw.SimpleTextOutlined(text, font, x, y, color, x_align, y_align, outline_width, outline_color)
	else
		draw.SimpleText(text, font, x, y, color, x_align, y_align)
	end
	cam.PopModelMatrix()
end

-- Cache de la géométrie de l'anneau XP (détail dans le corps de la fonction).
local _xpVerts, _xpSegs = {}, 0
local _xp_k_cx, _xp_k_cy, _xp_k_r, _xp_k_frac
local function draw_xp_ring(cx, cy, radius, progress_frac)
	progress_frac = math.min(1, math.max(0, progress_frac))
	if progress_frac <= 0 then
		return
	end

	local r_out = radius * XP_RING_OUTER_FRAC
	local thick = math.max(2, radius * XP_RING_THICKNESS_FRAC)
	local r_in = math.max(radius * 0.35, r_out - thick)
	local span = 2 * math.pi * progress_frac
	local start_rad = math.rad(-60) -- 1 o'clock
	local segs = math.max(4, math.ceil(XP_RING_SEGMENTS_FULL * progress_frac))

	if not mat_vgui_white:IsError() then
		-- Géométrie de l'anneau mise en cache : ne change qu'avec (cx,cy,radius,frac).
		-- frac ne bouge qu'au gain d'XP (exp/maxEXP entiers) -> on ne reconstruit les
		-- ~56 quads qu'alors, en mutant des tables réutilisées (zéro alloc/frame). Les
		-- DrawPoly restent par-frame (c'est le GPU), mais plus de churn GC.
		if _xp_k_cx ~= cx or _xp_k_cy ~= cy or _xp_k_r ~= radius or _xp_k_frac ~= progress_frac then
			_xp_k_cx, _xp_k_cy, _xp_k_r, _xp_k_frac = cx, cy, radius, progress_frac
			for i = 0, segs - 1 do
				local t1 = start_rad - span * (i / segs)
				local t2 = start_rad - span * ((i + 1) / segs)
				local c1, s1 = math.cos(t1), math.sin(t1)
				local c2, s2 = math.cos(t2), math.sin(t2)
				local q = _xpVerts[i + 1]
				if not q then
					q = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }
					_xpVerts[i + 1] = q
				end
				-- Keep winding order consistent when arc runs counter-clockwise.
				q[1].x = cx + c2 * r_out; q[1].y = cy + s2 * r_out
				q[2].x = cx + c1 * r_out; q[2].y = cy + s1 * r_out
				q[3].x = cx + c1 * r_in; q[3].y = cy + s1 * r_in
				q[4].x = cx + c2 * r_in; q[4].y = cy + s2 * r_in
			end
			_xpSegs = segs
		end
		surface.SetMaterial(mat_vgui_white)
		surface.SetDrawColor(XP_RING_R, XP_RING_G, XP_RING_B, XP_RING_A)
		for i = 1, _xpSegs do
			surface.DrawPoly(_xpVerts[i])
		end
		return
	end

	surface.SetDrawColor(XP_RING_R, XP_RING_G, XP_RING_B, XP_RING_A)
	local half_l = math.max(0, math.floor(thick * 0.4))
	for off = -half_l, half_l do
		for i = 0, segs - 1 do
			local t1 = start_rad - span * (i / segs)
			local t2 = start_rad - span * ((i + 1) / segs)
			local c1, s1 = math.cos(t1), math.sin(t1)
			local c2, s2 = math.cos(t2), math.sin(t2)
			surface.DrawLine(
				cx + c1 * (r_out + off),
				cy + s1 * (r_out + off),
				cx + c2 * (r_out + off),
				cy + s2 * (r_out + off)
			)
		end
	end
end

-- Poly du cercle (masque stencil) mis en cache : appelé avec des args constants
-- (position/rayon du portrait, fixes par résolution) -> on ne reconstruit la table
-- de 65 points qu'au changement, pas chaque frame. Le DrawPoly reste par-frame.
local _circlePoly
local _circle_x, _circle_y, _circle_r, _circle_seg
local function draw_circle(x, y, radius, seg)
	if _circle_x ~= x or _circle_y ~= y or _circle_r ~= radius or _circle_seg ~= seg then
		_circle_x, _circle_y, _circle_r, _circle_seg = x, y, radius, seg
		_circlePoly = _circlePoly or {}
		for i = 0, seg do
			local a = math.rad((i / seg) * -360)
			_circlePoly[i + 1] = {
				x = x + math.sin(a) * radius,
				y = y + math.cos(a) * radius,
			}
		end
		for i = seg + 2, #_circlePoly do _circlePoly[i] = nil end
	end
	draw.NoTexture()
	surface.DrawPoly(_circlePoly)
end

local pmPanel
local pm_hud_model_overlay
local pm_lastModelName
local pm_lastHadChar

-- Portrait cache : 1 live DModelPanel draw on change, capture exact backbuffer pixels, then 2D blit.
local PORTRAIT_RT_SIZE = 256
-- Warmup frames after setup before backbuffer capture (bones / materials / scale settle).
-- Too low -> intermittent crown-centered or bare-face snaps on spawn.
local PORTRAIT_BAKE_FRAMES_BEFORE_CAPTURE = 3
local pmPortraitCache = nil
local pmPortraitMat = nil
local pmPortraitDirty = true
local pmPortraitBakeSig = nil
local pmPortraitPendingSig = nil
local pmPortraitBakeWait = 0
local pmPortraitScreenCopyMat = nil
local hudPmNeedSetup = false
local pm_lastCompositeSig = nil
-- Set while the pending portrait is a larva/vasto/lost-soul creature (not face composite).
local pmPortraitIsLarva = false

-- If the portrait is still invisible, set false (some drivers choke on stencil + DModelPanel 3D in HUDPaint).
local LZY_HUD_USE_CIRCLE_STENCIL = true

-- Raw creature body (larva / vasto / lost soul) — same rules as cl_models LZY_IsRawBodyModel.
local function LZY_HUD_IsRawPortraitBody(model)
	if not isstring(model) or model == "" then return false end
	if EVO_HollowProg and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(model) then
		return true
	end
	if EVO_LostSoul and EVO_LostSoul.IsLostSoulBodyModel and EVO_LostSoul.IsLostSoulBodyModel(model) then
		return true
	end
	return false
end

-- Face-center LookAt from eyes attachment (or head bone). Fixed Z=66 frames the crown on
-- some scales / genders / resolutions because DModelPanel never tracked the mesh.
local HUD_PORTRAIT_LOOK_Z_BIAS = -1.5
local HUD_PORTRAIT_FALLBACK_LOOK_Z = 64
local HUD_PORTRAIT_CAM_DIST = 17
local HUD_PORTRAIT_FOV = 45

local function LZY_HUD_GetPortraitLookAtLocal(ent)
	if not IsValid(ent) then return Vector(0, 0, HUD_PORTRAIT_FALLBACK_LOOK_Z) end
	ent:SetupBones()
	local aid = ent:LookupAttachment("eyes")
	if aid and aid > 0 then
		local t = ent:GetAttachment(aid)
		if t and t.Pos then
			local worldFocus = t.Pos
			if t.Ang then
				-- Negative Up = toward the face from a typical QC "eyes" brow placement.
				worldFocus = t.Pos + t.Ang:Up() * HUD_PORTRAIT_LOOK_Z_BIAS
			else
				worldFocus = t.Pos + Vector(0, 0, HUD_PORTRAIT_LOOK_Z_BIAS)
			end
			local localPos = ent:WorldToLocal(worldFocus)
			return Vector(0, 0, localPos.z)
		end
	end
	local headBone = ent:LookupBone("ValveBiped.Bip01_Head1") or ent:LookupBone("ValveBiped.Bip01_Head")
	if headBone and headBone >= 0 then
		local pos = select(1, ent:GetBonePosition(headBone))
		if pos then
			local localPos = ent:WorldToLocal(pos)
			return Vector(0, 0, localPos.z - 2)
		end
	end
	return Vector(0, 0, HUD_PORTRAIT_FALLBACK_LOOK_Z)
end

-- Larva / Vasto mesh hangs BELOW the origin. Look-at must be the HEAD (mask),
-- not mid-AABB (that is the belly on a hunched hollow). Distance still scales
-- with full height so the head fills the circle without a skin close-up.
local HUD_RAW_PORTRAIT_LOOK_FRAC = 0.10
local HUD_RAW_PORTRAIT_CAM_FRAC = 0.36
local HUD_RAW_PORTRAIT_CAM_MIN = 85
local HUD_RAW_HEAD_BONES = {
	"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Head", "ValveBiped.Bip01_Neck1",
	"bip_head", "Bip01_Head1", "Head", "head",
}

local function LZY_HUD_FindRawHeadZ(ent, minsZ, maxsZ)
	if not IsValid(ent) then return nil end
	ent:SetupBones()
	local band = (maxsZ - minsZ) * 0.45
	local function accept(z)
		if z and z >= maxsZ - band then return z end
	end
	for i = 1, #HUD_RAW_HEAD_BONES do
		local b = ent:LookupBone(HUD_RAW_HEAD_BONES[i])
		if b and b >= 0 then
			local pos = select(1, ent:GetBonePosition(b))
			if pos then
				local z = accept(ent:WorldToLocal(pos).z)
				if z then return z end
			end
		end
	end
	local n = ent:GetBoneCount() or 0
	for i = 0, n - 1 do
		local name = string.lower(ent:GetBoneName(i) or "")
		if string.find(name, "head", 1, true) or string.find(name, "neck", 1, true)
			or string.find(name, "skull", 1, true) or string.find(name, "masque", 1, true) then
			local pos = select(1, ent:GetBonePosition(i))
			if pos then
				local z = accept(ent:WorldToLocal(pos).z)
				if z then return z end
			end
		end
	end
	for _, att in ipairs({ "eyes", "anim_attachment_head", "head" }) do
		local aid = ent:LookupAttachment(att)
		if aid and aid > 0 then
			local t = ent:GetAttachment(aid)
			if t and t.Pos then
				local z = accept(ent:WorldToLocal(t.Pos).z)
				if z then return z end
			end
		end
	end
	return nil
end

local function LZY_HUD_GetRawPortraitCam(ent)
	if not IsValid(ent) then return 0, HUD_RAW_PORTRAIT_CAM_MIN end
	local scale = math.max((ent.GetModelScale and ent:GetModelScale()) or 1, 0.1)
	local mins, maxs = ent:GetModelBounds()
	local minsZ, maxsZ, height
	if mins and maxs then
		minsZ, maxsZ = mins.z * scale, maxs.z * scale
		height = maxsZ - minsZ
	else
		mins, maxs = ent:GetRenderBounds()
		minsZ = mins and mins.z or 0
		maxsZ = maxs and maxs.z or 0
		height = maxsZ - minsZ
	end
	if height < 8 then return 0, HUD_RAW_PORTRAIT_CAM_MIN end
	local lookZ = LZY_HUD_FindRawHeadZ(ent, minsZ, maxsZ)
		or (maxsZ - height * HUD_RAW_PORTRAIT_LOOK_FRAC)
	return lookZ, math.max(HUD_RAW_PORTRAIT_CAM_MIN, height * HUD_RAW_PORTRAIT_CAM_FRAC)
end

local function LZY_HUD_RawPortraitMeshReady(ent)
	if not IsValid(ent) then return false end
	if not LZY_HUD_IsRawPortraitBody(ent:GetModel()) then return false end
	local mins, maxs = ent:GetModelBounds()
	if mins and maxs and (maxs.z - mins.z) >= 8 then return true end
	mins, maxs = ent:GetRenderBounds()
	return mins and maxs and (maxs.z - mins.z) >= 8
end

local function LZY_HUD_ApplyPortraitCamera(panel, ent, isLarvaRaw)
	if not IsValid(panel) or not IsValid(ent) then return end
	if isLarvaRaw then
		local lookZ, camDist = LZY_HUD_GetRawPortraitCam(ent)
		panel:SetLookAt(Vector(0, 0, lookZ))
		panel:SetCamPos(Vector(camDist, 0, lookZ))
	else
		local look = LZY_HUD_GetPortraitLookAtLocal(ent)
		panel:SetLookAt(look)
		panel:SetCamPos(Vector(HUD_PORTRAIT_CAM_DIST, 0, look.z))
	end
	panel:SetFOV(HUD_PORTRAIT_FOV)
end

local function LZY_HUD_ComputePortraitBakeSig(ply, characterData, faceModel, isLarvaRaw)
	if isLarvaRaw then
		local sc = 1
		if characterData and EVO_HollowProg and EVO_HollowProg.GetScale then
			sc = EVO_HollowProg.GetScale(characterData.unique_id) or 1
		elseif IsValid(ply) then
			sc = ply:GetModelScale() or 1
		end
		-- unique_id + model + scale only: live ply bodygroups churn at spawn and
		-- retriggered a bake every frame (flicker).
		return "larva:" .. tostring(faceModel)
			.. ":" .. tostring(characterData and characterData.unique_id)
			.. ":sc:" .. string.format("%.3f", sc)
	end
	local sig = ""
	if characterData and LZY_Character_PlayerModel_ComputeBuildSig then
		sig = LZY_Character_PlayerModel_ComputeBuildSig(characterData) or ""
	end
	local sc = (characterData and tonumber(characterData.scale)) or (IsValid(ply) and ply:GetModelScale()) or 1
	sig = sig .. "|" .. tostring(faceModel)
		.. "|" .. tostring(characterData and characterData.skin_color)
		.. "|" .. tostring(characterData and characterData.bodygroupsString)
		.. "|sc:" .. string.format("%.3f", sc)
	return sig
end

local function LZY_HUD_MarkPortraitDirty()
	pmPortraitDirty = true
end

-- Never assign nil: it shadows DModelPanel:PreDrawModel and DrawModel() will crash.
local function LZY_HUD_PreDrawModelNoop()
	return true
end

-- Same DModelPanel lights as character-creator previews (cl_character_creation).
-- Default Init is ambient 50 + TOP/FRONT only — fine on a pale face, a silhouette
-- on the dark hollow mesh. Larva gets the UI fill; humans keep stock defaults.
local function LZY_HUD_ApplyPortraitPanelLights(panel, isLarvaRaw)
	if not IsValid(panel) then return end
	if isLarvaRaw then
		panel:SetAmbientLight(Color(200, 200, 200))
		panel:SetDirectionalLight(BOX_TOP, Color(255, 255, 255))
		panel:SetDirectionalLight(BOX_FRONT, Color(255, 255, 255))
		panel:SetDirectionalLight(BOX_RIGHT, Color(180, 180, 180))
		panel:SetDirectionalLight(BOX_LEFT, Color(140, 140, 140))
	else
		panel:SetAmbientLight(Color(50, 50, 50))
		panel:SetDirectionalLight(BOX_TOP, Color(255, 255, 255))
		panel:SetDirectionalLight(BOX_FRONT, Color(255, 255, 255))
		panel:SetDirectionalLight(BOX_RIGHT, color_black)
		panel:SetDirectionalLight(BOX_LEFT, color_black)
	end
end

local function LZY_HUD_EnsurePanelPreDrawModel(panel)
	if not IsValid(panel) then return end
	if panel.PreDrawModel == nil then
		panel.PreDrawModel = LZY_HUD_PreDrawModelNoop
	end
end

--- Tear down live portrait rig on the hidden DModelPanel (shared parts return to holder).
local function LZY_HUD_ReleasePortraitLiveModel()
	if not IsValid(pmPanel) then return end
	pmPanel:SetVisible(false)
	pmPanel.PreDrawModel = LZY_HUD_PreDrawModelNoop
	local ent = pmPanel.Entity
	if IsValid(ent) then
		ent._inventoryModelOverlay = nil
		ent._lzySharedOverlayBoneMap = nil
		if LZY_Character_PlayerModel_ReleaseEntityParts then
			LZY_Character_PlayerModel_ReleaseEntityParts(ent)
		else
			ent.PlayerModelParts = nil
			ent.RenderOverride = nil
		end
	end
end

local function LZY_HUD_InvalidatePortrait()
	hudPmNeedSetup = true
	pm_lastModelName = nil
	pm_lastCompositeSig = nil
	pm_lastHadChar = nil
	pmPortraitIsLarva = false
	LZY_HUD_MarkPortraitDirty()
	LZY_HUD_ReleasePortraitLiveModel()
end

--- Steady state: cached bitmap only (no live DModelPanel draw).
function LZY_HUD_EnsurePortraitImageOnly()
	if pmPortraitMat and not pmPortraitDirty then
		if IsValid(pmPanel) then pmPanel:SetVisible(false) end
		hudPmNeedSetup = false
		pmPortraitBakeWait = 0
		return
	end
	LZY_HUD_ReleasePortraitLiveModel()
end

local function LZY_HUD_GetPortraitRT()
	if pmPortraitCache and pmPortraitCache.rt and pmPortraitCache.mat then
		return pmPortraitCache
	end
	local rtName = "lzy_hud_portrait_rt"
	local rt = GetRenderTarget(rtName, PORTRAIT_RT_SIZE, PORTRAIT_RT_SIZE)
	if not rt then return nil end
	local matName = "lzy_hud_portrait_mat"
	local mat
	local okMat, created = pcall(function()
		return CreateMaterial(matName, "UnlitGeneric", {
			["$basetexture"] = rt:GetName(),
			["$vertexcolor"] = 1,
			["$vertexalpha"] = 1,
			["$ignorez"] = 1,
		})
	end)
	mat = okMat and created or Material(matName)
	if not mat or mat:IsError() then return nil end
	pmPortraitCache = { rt = rt, mat = mat }
	return pmPortraitCache
end

local function LZY_HUD_GetPortraitScreenCopyMat()
	if pmPortraitScreenCopyMat then return pmPortraitScreenCopyMat end
	local ok, mat = pcall(function()
		return CreateMaterial("lzy_hud_portrait_screen_copy", "UnlitGeneric", {
			["$basetexture"] = "_rt_FullFrameFB",
			["$vertexcolor"] = 1,
			["$vertexalpha"] = 1,
		})
	end)
	pmPortraitScreenCopyMat = ok and mat or Material("pp/copy")
	return pmPortraitScreenCopyMat
end

--- Copy the live portrait rect from the backbuffer (after PaintManual) into our cache RT.
local function LZY_HUD_CapturePortraitFromScreen(pmX, pmY, pmW, pmH)
	local cache = LZY_HUD_GetPortraitRT()
	if not cache then return false end

	render.UpdateScreenEffectTexture()

	local scrW, scrH = ScrW(), ScrH()
	if scrW <= 0 or scrH <= 0 then return false end

	local u0, v0 = pmX / scrW, pmY / scrH
	local u1, v1 = (pmX + pmW) / scrW, (pmY + pmH) / scrH

	local ok = pcall(function()
		render.PushRenderTarget(cache.rt)
		render.OverrideAlphaWriteEnable(true, true)
		render.Clear(0, 0, 0, 0, true, true)
		cam.Start2D()
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(LZY_HUD_GetPortraitScreenCopyMat())
		surface.DrawTexturedRectUV(0, 0, PORTRAIT_RT_SIZE, PORTRAIT_RT_SIZE, u0, v0, u1, v1)
		cam.End2D()
		render.OverrideAlphaWriteEnable(false)
		render.PopRenderTarget()
	end)

	return ok
end

--- Blit cached portrait (circle stencil optional).
local function LZY_HUD_DrawPortraitRT(pmX, pmY, pmW, pmH)
	if not pmPortraitMat then return end

	local scr_x = pmX + pmW * 0.5 - hSz(2)
	local scr_y = pmY + pmH * 0.5
	local radius = math.min(pmW, pmH) * 0.5

	render.SetScissorRect(0, 0, 0, 0, false)

	if LZY_HUD_USE_CIRCLE_STENCIL then
		render.ClearStencil()
		render.SetStencilEnable(true)
		render.SetStencilWriteMask(255)
		render.SetStencilTestMask(255)
		render.SetStencilReferenceValue(1)
		render.SetStencilCompareFunction(STENCIL_ALWAYS)
		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)
		render.SetStencilPassOperation(STENCIL_REPLACE)

		cam.Start2D()
		render.SetColorMaterial()
		surface.SetDrawColor(27, 27, 27)
		draw_circle(scr_x, scr_y, radius, 64)
		cam.End2D()

		render.SetStencilCompareFunction(STENCIL_EQUAL)
		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)
		render.SetStencilPassOperation(STENCIL_KEEP)
		render.SetStencilReferenceValue(1)
	end

	surface.SetDrawColor(255, 255, 255, 255)
	surface.SetMaterial(pmPortraitMat)
	surface.DrawTexturedRect(pmX, pmY, pmW, pmH)

	if LZY_HUD_USE_CIRCLE_STENCIL then
		render.SetStencilEnable(false)
	end
end

-- Cache des strings HP/mana (reconstruites seulement quand la valeur change,
-- au lieu d'une concat à chaque frame).
local pm_hpStr, pm_hpKey = "0 / 0", nil
local pm_mpStr, pm_mpKey = "0 / 0", nil

-- Default draw is PANEL.Paint in garrysmod/lua/vgui/dmodelpanel.lua — SkinHook alone often never calls it (custom derma skins).
local lzy_hud_dmpaint    = nil
local function LZY_HUD_GetDModelPanelPaint()
	if lzy_hud_dmpaint then return lzy_hud_dmpaint end
	local t = vgui.GetControlTable("DModelPanel")
	lzy_hud_dmpaint = (t and t.Paint) or false
	return lzy_hud_dmpaint
end

local function LZY_HUD_DModelPanelSkinPaint(self, ww, hh)
	local fn = LZY_HUD_GetDModelPanelPaint()
	if fn then
		fn(self, ww, hh)
		return
	end
	if derma.SkinHook then
		derma.SkinHook("Paint", "DModelPanel", self, ww, hh)
	end
end

--- Circle stencil (optional) + PaintManual. Entity starts with SetNoDraw(true) from DModelPanel:SetModel.
local function DrawModelCircleMask(panel, scr_x, scr_y, radius)
	if not IsValid(panel) or not panel:IsVisible() then return end
	if not IsValid(panel.Entity) then return end

	render.SetScissorRect(0, 0, 0, 0, false)

	if LZY_HUD_USE_CIRCLE_STENCIL then
		render.ClearStencil()
		render.SetStencilEnable(true)
		render.SetStencilWriteMask(255)
		render.SetStencilTestMask(255)
		render.SetStencilReferenceValue(1)
		render.SetStencilCompareFunction(STENCIL_ALWAYS)
		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)
		render.SetStencilPassOperation(STENCIL_REPLACE)

		cam.Start2D()
		render.SetColorMaterial()
		surface.SetDrawColor(27, 27, 27)
		draw_circle(scr_x, scr_y, radius, 64)
		cam.End2D()

		render.SetStencilCompareFunction(STENCIL_EQUAL)
		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)
		render.SetStencilPassOperation(STENCIL_KEEP)
		render.SetStencilReferenceValue(1)
	end

	if IsValid(pm_hud_model_overlay) then pm_hud_model_overlay:SetNoDraw(false) end

	LZY_HUD_EnsurePanelPreDrawModel(panel)
	panel:PaintManual()

	if LZY_HUD_USE_CIRCLE_STENCIL then
		render.SetStencilEnable(false)
	end
end

--- One live DModelPanel draw (identical to legacy HUD), then snapshot backbuffer pixels into the cache RT.
local function LZY_HUD_PreparePortraitDraw(ent, characterData)
	if LZY_Character_PlayerModel_PreparePanelForDraw then
		LZY_Character_PlayerModel_PreparePanelForDraw(ent, characterData)
	end
	if LZY_Character_PlayerModel_RefreshFaceMaterials then
		LZY_Character_PlayerModel_RefreshFaceMaterials(ent, characterData)
	end
end

local function LZY_HUD_DrawPortraitLive(pmX, pmY, pmW, pmH, scr_x, scr_y, radius)
	if not IsValid(pmPanel) or not IsValid(pmPanel.Entity) then return end
	pmPanel:SetVisible(true)
	pmPanel:SetPos(pmX, pmY)
	pmPanel:SetSize(pmW, pmH)
	DrawModelCircleMask(pmPanel, scr_x, scr_y, radius)
end

local function LZY_HUD_BakePortrait(pmX, pmY, pmW, pmH, scr_x, scr_y, radius)
	if not pmPortraitDirty then return false end
	if not IsValid(pmPanel) or not IsValid(pmPanel.Entity) then return false end

	local ent = pmPanel.Entity
	local ply = LocalPlayer()
	local characterData = (IsValid(ply) and GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply)) or nil
	local srcData = (IsValid(ply) and GetPlayerCharacterData and GetPlayerCharacterData(ply)) or characterData
	local isLarva = pmPortraitIsLarva
		or (LZY_IsLarvaCharacter and IsValid(ply) and LZY_IsLarvaCharacter(ply, srcData))

	-- Intending larva but the panel still has the face (or a path the detector missed):
	-- put the creature on the panel. Silent wait left the circle empty.
	if isLarva and not LZY_HUD_IsRawPortraitBody(ent:GetModel()) then
		local cfg = EVO_HollowProg and EVO_HollowProg.Config
		local want
		if IsValid(ply) and LZY_HUD_IsRawPortraitBody(ply:GetModel()) then
			want = ply:GetModel()
		elseif LZY_HUD_IsRawPortraitBody(srcData and srcData.body_model) then
			want = srcData.body_model
		elseif cfg then
			local srcBody = srcData and srcData.body_model
			want = (srcBody and cfg.VastoModel and string.lower(srcBody) == string.lower(cfg.VastoModel))
				and cfg.VastoModel or cfg.LarvaModel
		end
		if isstring(want) and want ~= "" then
			ent:SetModel(want)
		end
		if not LZY_HUD_IsRawPortraitBody(ent:GetModel()) then
			return false
		end
	end
	if isLarva and not LZY_HUD_RawPortraitMeshReady(ent) then
		return false
	end
	-- Human composite not ready yet — wait (otherwise we snap a bald face / wrong framing).
	if (not isLarva) and characterData and characterData.body_model
		and isstring(characterData.hair_model) and characterData.hair_model ~= "" then
		if not ent.RenderOverride then
			return false
		end
	end

	if isLarva then
		ent:SetAngles(Angle(0, 0, 0))
		ent:SetSequence(0)
		ent:SetCycle(0)
		ent:SetupBones()
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, true)
	else
		LZY_HUD_PreparePortraitDraw(ent, characterData)
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, false)
	end

	if pmPortraitBakeWait > 0 then
		pmPortraitBakeWait = pmPortraitBakeWait - 1
		LZY_HUD_DrawPortraitLive(pmX, pmY, pmW, pmH, scr_x, scr_y, radius)
		return false
	end

	LZY_HUD_DrawPortraitLive(pmX, pmY, pmW, pmH, scr_x, scr_y, radius)

	if not LZY_HUD_CapturePortraitFromScreen(pmX, pmY, pmW, pmH) then
		return false
	end

	local cache = LZY_HUD_GetPortraitRT()
	pmPortraitMat = cache and cache.mat or pmPortraitMat
	pmPortraitDirty = false
	pmPortraitBakeSig = pmPortraitPendingSig

	LZY_HUD_ReleasePortraitLiveModel()
	return true
end

local function LZY_HUD_UpdatePlayerModel(ply, x, y, w, h)
	if not IsValid(ply) then return end

	local characterData = (GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply)) or nil
	local srcData = (GetPlayerCharacterData and GetPlayerCharacterData(ply)) or characterData
	local dataBody = characterData and characterData.body_model
	local origBody = srcData and srcData.body_model
	local bodyIsRaw = LZY_HUD_IsRawPortraitBody(dataBody) or LZY_HUD_IsRawPortraitBody(origBody)
	local plyModel = ply:GetModel() or ""
	local plyModelIsRaw = LZY_HUD_IsRawPortraitBody(plyModel)

	-- LZY_IsLarvaCharacter returns false while the player entity still has a human face
	-- (sticky NW / SetModel in flight). That makes the HUD call SetupPanelEntity with
	-- larva body_model on the face model → bald human in the circle. Override only for
	-- that race (NW raw or ply already creature, or larva DB row with empty hair_model).
	-- Do NOT override when NW is clear and the ply is already a human face with hair —
	-- that is the Hollow→Arrancar cleanup path (stale body_model in playersModels).
	-- Check BOTH display and CSM body: GetDisplayBodyModel used to swap the larva for
	-- the Hollow rank-1 academy outfit, which hid bodyIsRaw and baked the default face.
	local isLarvaRaw = (LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply, srcData)) or false
	if (not isLarvaRaw) and bodyIsRaw then
		local nwRaw = ply:GetEvoNWBool("EVO_HollowRaw", false) or ply:GetEvoNWBool("EVO_IsLarva", false)
		local hair = (srcData and srcData.hair_model) or (characterData and characterData.hair_model)
		if nwRaw or plyModelIsRaw or (not isstring(hair) or hair == "") then
			isLarvaRaw = true
		end
	end
	pmPortraitIsLarva = isLarvaRaw

	local faceModel = nil
	local larvaCharData = nil
	if isLarvaRaw then
		-- Prefer the live player path (server SetModel uses CFG case). DB/CSM
		-- paths can differ in case and fail to load on Linux → blank panel.
		local cfg = EVO_HollowProg and EVO_HollowProg.Config
		local function canonRaw(path)
			if not (cfg and isstring(path)) then return path end
			local low = string.lower(path)
			if low == string.lower(cfg.VastoModel or "") then return cfg.VastoModel end
			if low == string.lower(cfg.LarvaModel or "") then return cfg.LarvaModel end
			return path
		end
		if plyModelIsRaw then
			faceModel = plyModel
		elseif LZY_HUD_IsRawPortraitBody(origBody) then
			faceModel = canonRaw(origBody)
		elseif LZY_HUD_IsRawPortraitBody(dataBody) then
			faceModel = canonRaw(dataBody)
		elseif cfg then
			faceModel = cfg.LarvaModel
		else
			faceModel = plyModel
		end
		larvaCharData = srcData or characterData
		characterData = nil
	else
		if characterData and LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel then
			faceModel = LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender)
		end
		faceModel = faceModel or plyModel
	end

	local bakeSig = LZY_HUD_ComputePortraitBakeSig(ply, isLarvaRaw and larvaCharData or characterData, faceModel, isLarvaRaw)
	pmPortraitPendingSig = bakeSig
	local portraitCacheValid = pmPortraitMat and not pmPortraitDirty and bakeSig == pmPortraitBakeSig

	if not IsValid(pmPanel) then
		pmPanel = vgui.Create("DModelPanel", vgui.GetWorldPanel())
		pmPanel:SetMouseInputEnabled(false)
		pmPanel:SetZPos(32000)
		pmPanel:SetAlpha(255)
		pmPanel:SetPaintedManually(true)
		pmPanel:SetCamPos(Vector(HUD_PORTRAIT_CAM_DIST, 0, HUD_PORTRAIT_FALLBACK_LOOK_Z))
		pmPanel:SetLookAt(Vector(0, 0, HUD_PORTRAIT_FALLBACK_LOOK_Z))
		pmPanel:SetFOV(HUD_PORTRAIT_FOV)
		pmPanel:SetAnimated(true)
		LZY_HUD_ApplyPortraitPanelLights(pmPanel, false)

		pmPanel.LayoutEntity = function(panel, ent)
			if not IsValid(ent) then return end
			ent:SetAngles(Angle(0, 0, 0))
			ent:FrameAdvance(RealFrameTime())
			ent:SetSequence(0)
			ent:SetCycle(0)
		end

		pmPanel.Paint = LZY_HUD_DModelPanelSkinPaint
	end

	if portraitCacheValid then
		if IsValid(pmPanel) then pmPanel:SetVisible(false) end
		hudPmNeedSetup = false
		return
	end

	pmPanel:SetPos(x, y)
	pmPanel:SetSize(w, h)
	pmPanel:SetVisible(true)
	pmPanel:MoveToFront()

	if pmPanel.Paint ~= LZY_HUD_DModelPanelSkinPaint then
		pmPanel.Paint = LZY_HUD_DModelPanelSkinPaint
	end

	local modelOrDataChanged = (pm_lastModelName ~= faceModel) or (pm_lastHadChar ~= (characterData and true or larvaCharData and true))
	local compositeSig = (LZY_Character_PlayerModel_ComputeBuildSig and characterData)
		and LZY_Character_PlayerModel_ComputeBuildSig(characterData) or nil
	local compositeChanged = compositeSig ~= nil and pm_lastCompositeSig ~= compositeSig
	if compositeChanged then pm_lastCompositeSig = compositeSig end

	if modelOrDataChanged or not IsValid(pmPanel.Entity) then
		pm_lastModelName = faceModel
		pm_lastHadChar = (characterData and true) or (larvaCharData and true) or false
		pmPanel:SetModel(faceModel)
		modelOrDataChanged = true
		pmPortraitBakeWait = PORTRAIT_BAKE_FRAMES_BEFORE_CAPTURE
		LZY_HUD_MarkPortraitDirty()
	end

	local ent = pmPanel.Entity
	if not IsValid(ent) then return end
	ent.skipDim = true

	if isLarvaRaw then
		if modelOrDataChanged then
			if LZY_Character_PlayerModel_ReleaseEntityParts then
				LZY_Character_PlayerModel_ReleaseEntityParts(ent)
			else
				ent.PlayerModelParts = nil
				ent.RenderOverride = nil
			end
			ent._inventoryModelOverlay = nil
			pmPanel.PreDrawModel = LZY_HUD_PreDrawModelNoop
			LZY_HUD_ApplyPortraitPanelLights(pmPanel, true)

			if larvaCharData and EVO_HollowProg and EVO_HollowProg.ApplyAppearance
				and EVO_HollowProg.IsLarvaBodyModel and EVO_HollowProg.IsLarvaBodyModel(faceModel) then
				local cfg = EVO_HollowProg.Config
				local isVasto = cfg and larvaCharData.body_model == cfg.VastoModel
				EVO_HollowProg.ApplyAppearance(ent, isVasto, larvaCharData.unique_id)
			end
			if plyModelIsRaw then
				ent:SetSkin(ply:GetSkin() or 0)
				for i = 0, ent:GetNumBodyGroups() - 1 do
					ent:SetBodygroup(i, ply:GetBodygroup(i))
				end
			end
			if LZY_Character_ApplyModelScale and larvaCharData then
				LZY_Character_ApplyModelScale(ent, larvaCharData)
			elseif ent.SetModelScale then
				ent:SetModelScale(ply:GetModelScale() or 1, 0)
			end
			pmPortraitBakeWait = math.max(pmPortraitBakeWait, 5)
		end
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, true)
		return
	end

	local needSetup = modelOrDataChanged or compositeChanged
	if not portraitCacheValid and not needSetup and characterData and characterData.body_model and characterData.hair_model then
		needSetup = (not ent.PlayerModelParts or not ent.RenderOverride)
			or ent._lzyPanelBuildSig ~= compositeSig
			or (LZY_Character_PlayerModel_IsSharedRigReady and not LZY_Character_PlayerModel_IsSharedRigReady())
	end
	if needSetup or hudPmNeedSetup then
		hudPmNeedSetup = false
		pmPortraitBakeWait = PORTRAIT_BAKE_FRAMES_BEFORE_CAPTURE
		if characterData and characterData.body_model and characterData.hair_model then
			-- Never run the human composite path on a larva body_model (bald face early-out).
			if LZY_HUD_IsRawPortraitBody(characterData.body_model) then
				LZY_HUD_MarkPortraitDirty()
				return
			end
			LZY_HUD_ApplyPortraitPanelLights(pmPanel, false)
			ent:SetSkin(characterData.skin_color or 0)
			if characterData.bodygroupsString and ent.SetBodyGroups then
				ent:SetBodyGroups(characterData
					.bodygroupsString)
			end
			LZY_Character_PlayerModel_SetupPanelEntity(ent, characterData, pm_hud_model_overlay)
			pm_hud_model_overlay = LZY_Character_PlayerModel_GetSharedOverlay and
				LZY_Character_PlayerModel_GetSharedOverlay() or pm_hud_model_overlay
			pmPanel.PreDrawModel = LZY_HUD_PreDrawModelNoop
		else
			ent:SetSkin(ply:GetSkin() or 0)
			ent.PlayerModelParts = nil
			ent.RenderOverride = nil
			ent._inventoryModelOverlay = nil
			pmPanel.PreDrawModel = LZY_HUD_PreDrawModelNoop
			LZY_HUD_ApplyPortraitPanelLights(pmPanel, false)
			for k = 0, (ply:GetNumBodyGroups() or 0) - 1 do
				ent:SetBodygroup(k, ply:GetBodygroup(k) or 0)
			end
			if MUGEN and MUGEN.Character and MUGEN.Character.Config then
				if LZY_Character_PlayerModel_GetSharedOverlay then
					pm_hud_model_overlay = LZY_Character_PlayerModel_GetSharedOverlay()
				end
				if not IsValid(pm_hud_model_overlay) then
					pm_hud_model_overlay = ClientsideModel(
						MUGEN.Character.Config.StandartModel or "models/ali/bleach/vetement_homme.mdl",
						RENDERGROUP_OPAQUE)
					pm_hud_model_overlay.skipDim = true
					if IsValid(pm_hud_model_overlay) then pm_hud_model_overlay:SetNoDraw(true) end
				end
				if IsValid(pm_hud_model_overlay) then
					pm_hud_model_overlay:SetSkin(ply:GetSkin() or 0)
					local bodygroupsTable = util.JSONToTable(ply:GetEvoNWString("OverlayBodygroups", "{}"))
					if istable(bodygroupsTable) then
						for indexStr, value in pairs(bodygroupsTable) do
							local index = tonumber(indexStr)
							if index and isnumber(value) and pm_hud_model_overlay:GetBodygroupCount(index) > 1 then
								pm_hud_model_overlay:SetBodygroup(index, value)
							end
						end
					end
					local overlayBoneMap = nil
					pmPanel.PreDrawModel = function(panel, e)
						if IsValid(pm_hud_model_overlay) and IsValid(e) then
							e:SetupBones()
							pm_hud_model_overlay:SetupBones()
							if not overlayBoneMap then
								overlayBoneMap = {}
								for i = 0, pm_hud_model_overlay:GetBoneCount() - 1 do
									local entBone = e:LookupBone(pm_hud_model_overlay:GetBoneName(i))
									if entBone then overlayBoneMap[i] = entBone end
								end
							end
							for i, entBone in pairs(overlayBoneMap) do
								local matrix = e:GetBoneMatrix(entBone)
								if matrix then pm_hud_model_overlay:SetBoneMatrix(i, matrix) end
							end
							pm_hud_model_overlay:SetPos(e:GetPos())
							pm_hud_model_overlay:SetAngles(e:GetAngles())
							pm_hud_model_overlay:DrawModel()
						end
					end
				end
			end
		end
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, false)
		LZY_HUD_MarkPortraitDirty()
	elseif bakeSig ~= pmPortraitBakeSig then
		pmPortraitBakeWait = PORTRAIT_BAKE_FRAMES_BEFORE_CAPTURE
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, false)
		LZY_HUD_MarkPortraitDirty()
	else
		LZY_HUD_ApplyPortraitCamera(pmPanel, ent, false)
	end
end

local function LZY_HUD_RefreshPortraitFaceMaterials()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	local characterData = GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply)
	local srcData = (GetPlayerCharacterData and GetPlayerCharacterData(ply)) or characterData
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply, srcData) then return end
	if not characterData or not characterData.body_model then return end
	if not IsValid(pmPanel) or not IsValid(pmPanel.Entity) then
		hudPmNeedSetup = true
		return
	end
	local ent = pmPanel.Entity
	if characterData.body_model and characterData.hair_model and not ent.RenderOverride then
		local faceModel = LZY_CHARACTER_CONFIG and LZY_CHARACTER_CONFIG.GetDefaultFaceModel(characterData.gender) or ply:GetModel()
		local bakeSig = LZY_HUD_ComputePortraitBakeSig(ply, characterData, faceModel, false)
		if pmPortraitMat and not pmPortraitDirty and bakeSig == pmPortraitBakeSig then
			return
		end
		hudPmNeedSetup = true
		return
	end
	if LZY_Character_PlayerModel_RefreshFaceMaterials then
		LZY_Character_PlayerModel_RefreshFaceMaterials(ent, characterData)
	end
	pmPortraitBakeWait = PORTRAIT_BAKE_FRAMES_BEFORE_CAPTURE
	LZY_HUD_MarkPortraitDirty()
end

local function LZY_HUD_ForcePortraitRebuild()
	LZY_HUD_InvalidatePortrait()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	local characterData = GetPlayerDisplayCharacterData and GetPlayerDisplayCharacterData(ply)
	local srcData = (GetPlayerCharacterData and GetPlayerCharacterData(ply)) or characterData
	if LZY_IsLarvaCharacter and LZY_IsLarvaCharacter(ply, srcData) then
		return
	end
	if not characterData or not characterData.body_model then return end
	if not IsValid(pmPanel) or not IsValid(pmPanel.Entity) then return end
	if LZY_Character_PlayerModel_SetupPanelEntity then
		LZY_Character_PlayerModel_SetupPanelEntity(pmPanel.Entity, characterData, pm_hud_model_overlay)
	end
end

hook.Add("LZY_Character:RefreshPanelFaceMaterials", "LZY_HUD:PortraitFaceRefresh", LZY_HUD_RefreshPortraitFaceMaterials)

hook.Add("LZY_Character:SharedPanelRigInvalidated", "LZY_HUD:PortraitRigInvalidated", function()
	hudPmNeedSetup = true
	pm_lastCompositeSig = nil
	LZY_HUD_MarkPortraitDirty()
end)

hook.Add("LZY_Character:RepairPanelModels", "LZY_HUD:PortraitFullRepair", LZY_HUD_ForcePortraitRebuild)

hook.Add("GRubTextureRestore", "LZY_HUD:PortraitTextureRestore", function()
	LZY_HUD_MarkPortraitDirty()
end)

hook.Add("OnReloaded", "LZY_HUD:PortraitReload", function()
	pmPortraitCache = nil
	pmPortraitMat = nil
	pmPortraitScreenCopyMat = nil
	LZY_HUD_MarkPortraitDirty()
	hudPmNeedSetup = true
end)

hook.Add("OnGameFocusChanged", "LZY_HUD:PortraitOnFocus", function()
	LZY_HUD_ForcePortraitRebuild()
end)

hook.Add("OnScreenSizeChanged", "LZY_HUD:PortraitLayoutCaches", function()
	_rotMatCache, _rotMatCount = {}, 0
	_circlePoly = nil
	_circle_x, _circle_y, _circle_r, _circle_seg = nil, nil, nil, nil
	_xpVerts, _xpSegs = {}, 0
	_xp_k_cx, _xp_k_cy, _xp_k_r, _xp_k_frac = nil, nil, nil, nil
	LZY_HUD_MarkPortraitDirty()
end)

hook.Add("LZY:PlyState:Changed", "LZY_HUD:PortraitHollowTransition", function(ent, name)
	if not IsValid(ent) or ent ~= LocalPlayer() then return end
	if name ~= "EVO_HollowRaw" and name ~= "EVO_IsLarva" then return end
	LZY_HUD_InvalidatePortrait()
end)

hook.Add("HUDPaint", "EVO:Hook:HUD", function()
	local ply = LocalPlayer()

	if not IsValid(ply) then return end
	-- MORT / écran de respawn (2026-07-21) : le deathscreen (LZY_KO_SequenceHUD) prend tout l'écran,
	-- mais son voile n'est qu'à ~78% -> sans ce gate, portrait / PV / reiatsu / niveau / argent se
	-- dessinent PAR-DESSUS (ou transparaissent) pendant tout le respawn = « bug d'affichage ».
	if not ply:Alive() then
		if IsValid(pmPanel) then pmPanel:SetVisible(false) end
		return
	end
	-- Mode staff : on observe -> on masque tout le HUD gameplay (PV/reiatsu/portrait…).
	if ply:GetEvoNWBool("EVO_StaffMode", false) then
		if IsValid(pmPanel) then pmPanel:SetVisible(false) end
		return
	end
	local nick = (LZY_PlyState and LZY_PlyState.Get(ply, "Nickname", "")) or ply:GetEvoNWString("Nickname", "")
	if nick == "" or not GetPlayerCharacterData(ply) then
		if IsValid(pmPanel) then pmPanel:SetVisible(false) end
		pm_lastHadChar = false
		return
	end

	local name = (nick ~= "" and nick) or ply:GetEvoNWString("Nickname", "Unknown")
	local money = ply:GetCharMoney()
	-- Arrondi au superieur : la regen HP/Reiatsu produit des valeurs a virgule,
	-- on ne veut jamais afficher de decimales sur le HUD.
	local maxHealth = math.ceil(ply:GetMaxHealth())
	-- Illusion d'Aizen (passif slot 8) : la barre de vie ment quelques secondes.
	local nFauxPV = EVO_IllusionFauxPV and EVO_IllusionFauxPV()
	local health = nFauxPV and math.ceil(maxHealth * nFauxPV) or math.ceil(ply:Health())
	local reiatsu = math.ceil(ply:GetCharReiatsu())
	local maxReiatsu = math.ceil(ply:GetCharMaxReiatsu())

	-- Strings HP/mana : reconstruites seulement quand la valeur change.
	local hpKey = health * 1000000 + maxHealth
	if pm_hpKey ~= hpKey then
		pm_hpKey = hpKey; pm_hpStr = health .. " / " .. maxHealth
	end
	local mpKey = reiatsu * 1000000 + maxReiatsu
	if pm_mpKey ~= mpKey then
		pm_mpKey = mpKey; pm_mpStr = reiatsu .. " / " .. maxReiatsu
	end
	local level = ply:GetEvoNWInt("Level", 1)
	local exp = ply:GetEvoNWInt("Exp", 0)
	local maxEXP = ply:GetEvoNWInt("MaxEXP", 100)
	local faction = ply:GetEvoNWString("FactionName", "Shinigami")

	-- Player model portrait : cached image (live DModelPanel snapshot on change, 2D blit each frame).
	local pmX, pmY, pmW, pmH = hSz(41), hYB(947), hSz(72.5), hSz(72.5)
	local pmScrX = pmX + pmW * 0.5 - hSz(2)
	local pmScrY = pmY + pmH * 0.5
	local pmRadius = math.min(pmW, pmH) * 0.5
	LZY_HUD_UpdatePlayerModel(ply, pmX, pmY, pmW, pmH)

	local bakedThisFrame = LZY_HUD_BakePortrait(pmX, pmY, pmW, pmH, pmScrX, pmScrY, pmRadius)
	if not bakedThisFrame and not pmPortraitDirty and pmPortraitMat then
		LZY_HUD_DrawPortraitRT(pmX, pmY, pmW, pmH)
	end

	-- HP Progressbar
	local hpBarX, hpBarY = hSz(123), hYB(934)
	local hpBarW, hpBarH = hSz(350), hSz(50)
	RNDX.DrawMaterial(0, hpBarX, hpBarY, hpBarW, hpBarH, HUD_COL_WHITE, materials.hp_progress_bg)
	local hpFrac = maxHealth > 0 and math.Clamp(health / maxHealth, 0, 1) or 0
	if hpFrac > 0 then
		surface.SetMaterial(materials.hp_progress_fill)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRectUV(hpBarX, hpBarY, hpBarW * hpFrac, hpBarH, 0, 0, hpFrac, 1)
	end
	surface.SetFont("Avenir Next World:18")
	draw_simple_text_outlined_rotated(
		pm_hpStr,
		"Avenir Next World:18",
		hSz(445),
		hpBarY + hpBarH / 2 - hSz(1),
		HUD_COL_WHITE,
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER,
		1,
		HUD_COL_BLACK,
		2.5
	)
	RNDX.DrawMaterial(0, hSz(132), hYB(954), hSz(30), hSz(30), HUD_COL_WHITE, materials.heart_icon)

	-- DEBUFF « BLESSURES PROFONDES » (ncm_heal_bed) : pilule rouge AU-DESSUS de la
	-- barre de vie (demande user 07/21) — même wording que la carte stats de
	-- l'inventaire. NWBool EVO_SoinDebuff + NWFloat EVO_SoinDebuffEnd (deadline
	-- CurTime ; 0 = pas de deadline -> « SOIN REQUIS »).
	-- LARVE : le système est désactivé pour elle côté serveur (08/02) -> pilule masquée.
	if ply:GetEvoNWBool("EVO_SoinDebuff", false) and not ply:GetEvoNWBool("EVO_IsLarva", false) then
		local nEnd = ply:GetEvoNWFloat("EVO_SoinDebuffEnd", 0)
		-- Décompte LIVE en MM:SS (demande user 2026-07-21 « rajouter un décompte du 20 min,
		-- le garder visible dans le HUD ») : clé par SECONDE (au lieu de la minute) pour que la
		-- pilule égrène vraiment le temps jusqu'à résorption. nEnd = 0 -> pas d'échéance
		-- (debuff permanent, ne devrait plus arriver en jeu) -> « SOIN REQUIS ».
		local nRem = nEnd > 0 and math.max(0, math.ceil(nEnd - CurTime())) or -1
		local scrW, scrH = ScrW(), ScrH()
		if _debuffKey ~= nRem or _debuffResW ~= scrW or _debuffResH ~= scrH then
			_debuffKey, _debuffResW, _debuffResH = nRem, scrW, scrH
			_debuffFont = "Bebas Neue:" .. gRespFont(20)
			if nRem > 0 then
				_debuffStr = string.format("BLESSURES PROFONDES · %d:%02d", math.floor(nRem / 60), nRem % 60)
			else
				_debuffStr = "BLESSURES PROFONDES · SOIN REQUIS"
			end
			surface.SetFont(_debuffFont)
			_debuffW = (surface.GetTextSize(_debuffStr))
		end
		-- Aligne le bord gauche sur la barre de vie, posee au-dessus du bloc HUD
		-- (les elements les plus hauts du bloc : argent Y916 / icone faction Y920).
		local bH = hSz(30)
		local bX, bY = hSz(123), hYB(882)
		RNDX.Draw(bH * 0.35, bX, bY, _debuffW + hSz(20), bH, HUD_COL_DEBUFF_BG)
		draw.SimpleText(_debuffStr, _debuffFont, bX + hSz(10), bY + bH * 0.5, HUD_COL_DEBUFF, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- BOUCLIER SPIRITUEL (EvoStyle.GiveShield, ex. Katana 4 Rasen Zan) : pilule
	-- bleutée au-dessus de la barre de vie, PV restants du bouclier en live.
	-- Monte d'un cran si la pilule blessures profondes occupe déjà la place.
	local nShield = ply:GetEvoNWFloat("EVO_ShieldHP", 0)
	if nShield > 0 then
		local nShieldInt = math.ceil(nShield)
		local scrW2, scrH2 = ScrW(), ScrH()
		if _shieldKey ~= nShieldInt or _shieldResW ~= scrW2 or _shieldResH ~= scrH2 then
			_shieldKey, _shieldResW, _shieldResH = nShieldInt, scrW2, scrH2
			_shieldFont = "Bebas Neue:" .. gRespFont(20)
			_shieldStr = "BOUCLIER · " .. nShieldInt .. " PV"
			surface.SetFont(_shieldFont)
			_shieldW = (surface.GetTextSize(_shieldStr))
		end
		local bH = hSz(30)
		local bX = hSz(123)
		local bY = (ply:GetEvoNWBool("EVO_SoinDebuff", false) and not ply:GetEvoNWBool("EVO_IsLarva", false))
			and hYB(846) or hYB(882)
		RNDX.Draw(bH * 0.35, bX, bY, _shieldW + hSz(20), bH, HUD_COL_SHIELD_BG)
		draw.SimpleText(_shieldStr, _shieldFont, bX + hSz(10), bY + bH * 0.5, HUD_COL_SHIELD, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- Mana Progressbar
	local manaBarX, manaBarY = hSz(135), hYB(964)
	local manaBarW, manaBarH = hSz(350), hSz(50)
	RNDX.DrawMaterial(0, manaBarX, manaBarY, manaBarW, manaBarH, HUD_COL_WHITE, materials.mana_progress_bg)
	local manaFrac = maxReiatsu > 0 and math.Clamp(reiatsu / maxReiatsu, 0, 1) or 0
	if manaFrac > 0 then
		surface.SetMaterial(materials.mana_progress_fill)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRectUV(manaBarX, manaBarY, manaBarW * manaFrac, manaBarH, 0, 0, manaFrac, 1)
	end
	surface.SetFont("Avenir Next World:18")
	draw_simple_text_outlined_rotated(
		pm_mpStr,
		"Avenir Next World:18",
		hSz(450),
		manaBarY + manaBarH / 2 - hSz(2.5),
		HUD_COL_WHITE,
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER,
		1,
		HUD_COL_BLACK,
		2.5
	)
	RNDX.DrawMaterial(0, hSz(144), hYB(983), hSz(30), hSz(30), HUD_COL_WHITE, materials.mana_icon)

	-- BUFFS POTIONS + MALADIE (evo_science) : rangee de pilules colorees sous la
	-- barre de reiatsu ("DÉGÂTS +25% · 8 min", "FIÈVRE ÉCARLATE · VIE MAX −10%").
	-- La maladie vit ICI depuis le 08/09 (l'ancienne carte a mi-ecran est retiree).
	local fxList = EVO_SCIENCE and EVO_SCIENCE.GetActiveEffects and EVO_SCIENCE.GetActiveEffects() or nil
	if fxList and #fxList > 0 then
		if _fxLast ~= fxList then
			_fxLast = fxList
			_fxFont = "Bebas Neue:" .. gRespFont(17)
			surface.SetFont(_fxFont)
			for i = 1, #fxList do
				local e = fxList[i]
				e._w = (surface.GetTextSize(e.line or e.txt))
			end
		end
		local bH = hSz(24)
		local fx, fy = hSz(135), hYB(1018)
		for i = 1, #fxList do
			local e = fxList[i]
			if e._w then
				local pw = e._w + hSz(16)
				RNDX.Draw(bH * 0.35, fx, fy, pw, bH, HUD_COL_FXPILL_BG)
				draw.SimpleText(e.line or e.txt, _fxFont, fx + hSz(8), fy + bH * 0.5,
					e.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				fx = fx + pw + hSz(6)
			end
		end
	end

	-- Money
	RNDX.DrawMaterial(0, hSz(447), hYB(916), hSz(30), hSz(30), HUD_COL_WHITE, materials.money_icon)
	draw_simple_text_outlined_rotated(
		money,
		"Avenir Next World:16",
		hSz(444),
		hYB(932),
		HUD_COL_WHITE,
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER,
		1,
		HUD_COL_BLACK,
		2.5
	)

	-- Name
	draw_simple_text_outlined_rotated(
		name,
		"Avenir Next World:18",
		hSz(150),
		hYB(943),
		HUD_COL_WHITE,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER,
		1,
		HUD_COL_BLACK,
		2.5
	)

	-- Âge du personnage (demande user) : "X ans" en doré, juste après le nom (même ligne).
	-- Calculé côté client depuis les NWInts EVO_AgeStart/EVO_AgeCreatedUnix via le helper
	-- partagé (sh_character) : age_start + 1 an / jour réel écoulé.
	if ply.GetCharacterAge then
		local age = ply:GetCharacterAge()
		if age > 0 then
			surface.SetFont("Avenir Next World:18")
			local nameW = surface.GetTextSize(name)
			-- perf : string d'age cache par valeur + font cachee par resolution (0 concat/frame)
			if _ageCacheVal ~= age then _ageCacheVal = age _ageCacheStr = age .. " ans" end
			local _, fontAv14 = hAvenirFonts()
			draw_simple_text_outlined_rotated(
				_ageCacheStr,
				fontAv14,
				hSz(150) + nameW + hSz(10),
				hYB(942),
				HUD_COL_GOLD,
				TEXT_ALIGN_LEFT,
				TEXT_ALIGN_CENTER,
				1,
				HUD_COL_BLACK,
				2.5
			)
		end
	end

	-- Faction Icon
	if faction == "Hollow" then
		RNDX.DrawMaterial(0, hSz(114), hYB(920), hSz(43), hSz(43), HUD_COL_WHITE, materials.hollow_icon)
	elseif faction == "Shinigami" then
		RNDX.DrawMaterial(0, hSz(114), hYB(920), hSz(43), hSz(43), HUD_COL_WHITE, materials.shinigami_icon)
	end

	-- PM Frame
	RNDX.DrawMaterial(0, hSz(30), hYB(926), hSz(93), hSz(104), HUD_COL_WHITE, materials.pm_frame)

	-- XP Circular Progressbar
	local xp_frac = maxEXP > 0 and math.Clamp(exp / maxEXP, 0, 1) or 0
	local xp_cx = hSz(76)
	local xp_cy = hYB(984)
	local xp_radius = hSz(48)
	draw_xp_ring(xp_cx, xp_cy, xp_radius, xp_frac)

	-- Level
	-- perf : fonts cachees par resolution (0 concat/frame)
	local fontAv12, fontAv14 = hAvenirFonts()
	draw_simple_text_outlined_rotated(
		"LV. ",
		fontAv12,
		hSz(77),
		hYB(935),
		HUD_COL_WHITE,
		TEXT_ALIGN_CENTER,
		TEXT_ALIGN_CENTER,
		1,
		HUD_COL_GOLD,
		2.5
	)
	draw_simple_text_outlined_rotated(
		level,
		fontAv14,
		hSz(88),
		hYB(935),
		HUD_COL_GOLD,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER,
		nil,
		nil,
		2.5
	)
end)

-- DrawOverlay (pas HUDPaint) : au-dessus du VGUI — menus ouverts ne doivent pas
-- masquer l'annonce de division (demande user 10/06). Même canal que
-- LZY_AnnonceFaction_Draw (faction).
hook.Add("DrawOverlay", "EVO:Hook:HUD:AnnonceDivision", function()
	DrawFactionAnnouncement()
end)

hook.Add("ShutDown", "LZY_HUD:DModel_NoWorldHooksCleanup", function()
	-- hook.Remove("PreDrawOpaqueRenderables", "LZY_HUD:PortraitNoWorld_Opaque")
	-- hook.Remove("PreDrawTranslucentRenderables", "LZY_HUD:PortraitNoWorld_Trans")
	if IsValid(pm_hud_model_overlay) then
		SafeRemoveEntity(pm_hud_model_overlay)
		pm_hud_model_overlay = nil
	end
	if IsValid(pmPanel) and IsValid(pmPanel.Entity) then
		if LZY_Character_PlayerModel_ReleaseEntityParts then
			LZY_Character_PlayerModel_ReleaseEntityParts(pmPanel.Entity)
		else
			pmPanel.Entity.PlayerModelParts = nil
			pmPanel.Entity.RenderOverride = nil
		end
	end
	if IsValid(pmPanel) then
		pmPanel:Remove()
		pmPanel = nil
	end
	pmPortraitCache = nil
	pmPortraitMat = nil
	pmPortraitScreenCopyMat = nil
	pmPortraitDirty = true
	pmPortraitBakeSig = nil
	pmPortraitPendingSig = nil
	pmPortraitIsLarva = false
	pm_lastModelName = nil
	pm_lastHadChar = nil
	pm_lastCompositeSig = nil
end)

net.Receive("HUD:ShowFactionAnnouncement", function()
	local text = net.ReadString()
	local duration = net.ReadFloat()
	local author = string.sub(string.gsub(net.ReadString() or "", "[\r\n]", " "), 1, 48)
	ShowFactionAnnouncement(text, duration, author)
	-- Trace relisible dans le chat custom (canal ANNONCE). Uniquement quand un
	-- auteur est présent = annonce de DIVISION (le message de zone staff
	-- réutilise ce net sans auteur et ne doit pas polluer le chat).
	if author ~= "" then
		local sChat = string.gsub(text or "", "[\r\n]+", " ")
		local sLine = "[Annonce division] " .. author .. " : " .. sChat
		if LZY_Chat_AddAnnonceLine then
			LZY_Chat_AddAnnonceLine(sLine)
		elseif LZY_Chat_AddSystemLine then
			LZY_Chat_AddSystemLine("annonce", sLine)
		else
			chat.AddText(Color(207, 68, 78), sLine)
		end
	end
end)

local playerMeta = FindMetaTable("Player")

function playerMeta:HUD_UpdatePlayerModel()
	LZY_HUD_InvalidatePortrait()
end

net.Receive("EVO:Client:HUD:UpdatePlayerModel", function(len, ply)
	if not IsValid(ply) then return end
	ply:HUD_UpdatePlayerModel()
end)
