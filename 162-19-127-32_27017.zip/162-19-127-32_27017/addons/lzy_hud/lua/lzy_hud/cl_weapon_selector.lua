-- "addons\\lzy_hud\\lua\\lzy_hud\\cl_weapon_selector.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local materials = {
	weapon_bg = Material("ouujpmexb5se/6xmmeoefr2n36p.png", "smooth"),
	hand = Material("ouujpmexb5se/qd33awcn0kbyfqf.png", "smooth"),
	camera = Material("ouujpmexb5se/6cc78o0ltc0wkzh.png", "smooth"),
	katana = Material("ouujpmexb5se/emjbo9lq9dhnl4t5.png", "smooth"),
	cooldown_bg = Material("ouujpmexb5se/3clvfjzk2r7cg.png", "smooth"), -- 52x52
    heavy_attack = Material("wqnfa3ildngsvqfe/coup_lourd.png", "smooth"), -- 42x42 (Coup Lourd, ex-dash/vanish)
    flashstep = Material("ouujpmexb5se/vw2rzufplatqdifan.png", "smooth"), -- 28x28
    double_jump = Material("ouujpmexb5se/3evwkmrwn2eqrxf.png", "smooth"), -- 28x28
    keys = Material("ouujpmexb5se/u2bguugci6ak2.png", "smooth"),
}

local weapon_icons = {
	["gmod_camera"] = materials.camera,
	["citron_freecam"] = materials.camera,
	["mugen_hands"] = materials.hand,
	["citron_combat_weapons"] = materials.katana,
	["citron_shinai_weapons"] = materials.katana,
}

local weapon_order = {
	["citron_combat_weapons"] = 1,
	["citron_shinai_weapons"] = 1,
	["mugen_hands"] = 2,
	["gmod_camera"] = 4,
	["citron_freecam"] = 5,
}

local mat_vgui_white = Material("vgui/white")
local COOLDOWN_BASE_PX = 52
local COOLDOWN_RING_SEGMENTS_FULL = 56
-- Outer edge of ring as fraction of half-size; inner = outer minus thickness.
local COOLDOWN_RING_OUTER_FRAC = 0.9
local COOLDOWN_RING_THICKNESS_FRAC = 0.16
local COOLDOWN_OVERLAY_R, COOLDOWN_OVERLAY_G, COOLDOWN_OVERLAY_B, COOLDOWN_OVERLAY_A = 255, 255, 255, 220
-- perf : couleurs constantes hoistées (jamais mutées, RNDX ne fait que lire r/g/b/a) au lieu de Color() par frame.
local COL_WHITE = Color(255, 255, 255, 255)
local COL_WHITE_128 = Color(255, 255, 255, 128)

local FADE_AFTER = 2.2
local LERP_SPEED = 14
local ANGLE_STEP_DEG = 32
local ARC_GUIDE_START = 118
local ARC_GUIDE_END = 242
-- Dense chords so the arc reads solid (DrawPoly is inconsistent across GMod builds).
local ARC_SEGMENTS_MIN = 96
local ARC_SEGMENTS_MAX = 200
local ARC_DEG_PER_SEGMENT = 0.72
local SCROLL_DELAY = 0.05
-- Play when the highlighted slot moves (path is under garrysmod/sound/).
local WEAPON_SELECTOR_SCROLL_SOUND = "6515xw26amw1br/v0otye6a7k9zojzla.ogg"
local WEAPON_SELECTOR_CONFIRM_SOUND = "6515xw26amw1br/5q3pv2f791tp.ogg"
-- true = mouse wheel / invnext & invprev move selection opposite to default GMod mapping.
local INVERT_WEAPON_SCROLL = true
-- Guide stroke width at 1080p reference height (scales with HUD).
local ARC_GUIDE_THICKNESS_PX = 2
-- Pure black disappears on dark maps; tweak toward white for a harder edge.
local ARC_GUIDE_R, ARC_GUIDE_G, ARC_GUIDE_B = 0, 0, 0
-- Ellipse semi-axes (fraction of screen height). ry > rx reads as a vertical “egg” along the arc.
-- Smaller X = narrower arc; higher CENTER_RIGHT_FRAC = center further past the right edge = arc hugs the border.
local SELECTOR_RADIUS_X_FRAC = 0.32
local SELECTOR_RADIUS_Y_FRAC = 0.22
local SELECTOR_CENTER_RIGHT_FRAC = 0.62

local hide_until = 0
local target_index = 1
local smooth_index = 1
local weapons_cache = {}
local last_scroll_time = 0
-- List of { x, y, start, duration } screen top-left, CurTime-based; multiple can run at once.
local cooldown_visuals = {}

local function weapon_selector_enabled()
	if hook.Run("LZY_HUD_WeaponSelector_Enabled") == false then
		return false
	end
	return true
end

local function slot_sort(a, b)
	if not IsValid(a) then
		return false
	end
	if not IsValid(b) then
		return true
	end
	local sa, sb = a:GetSlot(), b:GetSlot()
	if sa ~= sb then
		return sa < sb
	end
	return (a:GetSlotPos() or 0) < (b:GetSlotPos() or 0)
end

local function get_weapon_display_order(wep)
	if not IsValid(wep) then
		return math.huge
	end
	local class = wep:GetClass()
	return weapon_order[class] or math.huge
end

local function weapon_display_sort(a, b)
	if not IsValid(a) then
		return false
	end
	if not IsValid(b) then
		return true
	end

	local oa, ob = get_weapon_display_order(a), get_weapon_display_order(b)
	if oa ~= ob then
		return oa > ob
	end

	-- Keep predictable ordering for non-configured weapons (inverted).
	if slot_sort(a, b) then return false end
	if slot_sort(b, a) then return true end
	return (a:GetClass() or "") > (b:GetClass() or "")
end

local function rebuild_weapon_cache(ply)
	local list = {}
	for _, w in ipairs(ply:GetWeapons()) do
		if IsValid(w) then
			table.insert(list, w)
		end
	end
	table.sort(list, weapon_display_sort)
	weapons_cache = list
end

local function index_of_active(ply)
	local aw = ply:GetActiveWeapon()
	if not IsValid(aw) then
		return 1
	end
	for i, w in ipairs(weapons_cache) do
		if w == aw then
			return i
		end
	end
	return 1
end

local function get_weapon_icon_mat(class)
	local m = weapon_icons[class]
	if m and not m:IsError() then
		return m
	end
	local stored = weapons.GetStored(class)
	if stored and isstring(stored.Icon) and stored.Icon ~= "" then
		local im = Material(stored.Icon, "smooth")
		if not im:IsError() then
			return im
		end
	end
	if not materials.hand:IsError() then
		return materials.hand
	end
	return materials.hand
end

local function ellipse_point(cx, cy, rx, ry, t)
	return cx + math.cos(t) * rx, cy + math.sin(t) * ry
end

local function ellipse_outward_normal(rx, ry, t)
	local nx = -ry * math.cos(t)
	local ny = -rx * math.sin(t)
	local len = math.sqrt(nx * nx + ny * ny)
	if len < 1e-6 then
		return 0, 1
	end
	return nx / len, ny / len
end

-- Squared distance from (x,y) to (cx,cy)
local function dist_sq_xy(x, y, cx, cy)
	local dx, dy = x - cx, y - cy
	return dx * dx + dy * dy
end

-- True if the segment (x1,y1)-(x2,y2) intersects or lies inside a circle at (cx,cy) with radius r.
local function segment_intersects_circle(x1, y1, x2, y2, cx, cy, r)
	local r2 = r * r
	if dist_sq_xy(x1, y1, cx, cy) <= r2 or dist_sq_xy(x2, y2, cx, cy) <= r2 then
		return true
	end
	local dx, dy = x2 - x1, y2 - y1
	local len2 = dx * dx + dy * dy
	if len2 < 1e-12 then
		return false
	end
	local t = ((cx - x1) * dx + (cy - y1) * dy) / len2
	t = math.max(0, math.min(1, t))
	local mx, my = x1 + t * dx, y1 + t * dy
	return dist_sq_xy(mx, my, cx, cy) <= r2
end

local function arc_segment_blocked_by_holes(x1, y1, x2, y2, holes)
	if not holes or #holes == 0 then
		return false
	end
	for i = 1, #holes do
		local h = holes[i]
		if h and h.r and h.r > 0 and segment_intersects_circle(x1, y1, x2, y2, h.x, h.y, h.r) then
			return true
		end
	end
	return false
end

-- holes: optional list of { x, y, r } — arc strokes that enter these circles are skipped (e.g. weapon_bg discs).
local function draw_arc_outline_ellipse(cx, cy, radius_x, radius_y, deg_start, deg_end, r, g, b, a, line_width, holes)
	local arc_span = deg_end - deg_start
	local segments = math.floor(arc_span / ARC_DEG_PER_SEGMENT + 0.5)
	segments = math.min(ARC_SEGMENTS_MAX, math.max(ARC_SEGMENTS_MIN, segments))
	local step = arc_span / segments
	local half_px = math.max(0, math.floor(line_width * 0.5 + 0.35))

	-- perf : points/normales ne dépendent que du segment (pas de l'offset) -> calculés UNE seule fois
	-- hors de la boucle des offsets (mêmes expressions -> mêmes valeurs -> rendu identique).
	local pt_x, pt_y, nrm_x, nrm_y = {}, {}, {}, {}
	for i = 0, segments do
		local t = math.rad(deg_start + i * step)
		pt_x[i], pt_y[i] = ellipse_point(cx, cy, radius_x, radius_y, t)
		nrm_x[i], nrm_y[i] = ellipse_outward_normal(radius_x, radius_y, t)
	end

	surface.SetDrawColor(r, g, b, a)
	for off = -half_px, half_px do
		for i = 0, segments - 1 do
			local ax1, ay1 = pt_x[i] + nrm_x[i] * off, pt_y[i] + nrm_y[i] * off
			local ax2, ay2 = pt_x[i + 1] + nrm_x[i + 1] * off, pt_y[i + 1] + nrm_y[i + 1] * off
			if arc_segment_blocked_by_holes(ax1, ay1, ax2, ay2, holes) then
				continue
			end
			surface.DrawLine(ax1, ay1, ax2, ay2)
		end
	end
end

local function selector_open()
	-- Possession (boss jouable ncm_transform) : pas de sélecteur d'arme du tout.
	local lp = LocalPlayer()
	if IsValid(lp) and lp:GetEvoNWBool("NCM_TF_Active", false) then return false end
	return RealTime() < hide_until
end

-- Exposé : le free camera (citron_free_camera) doit savoir si la roulette est ouverte
-- pour réafficher le HUD (sinon son HUDShouldDraw cache tout, roulette comprise) et
-- pour laisser passer la molette / le clic de validation pendant la sélection.
function LZY_HUD_WeaponSelectorOpen()
	return selector_open()
end

-- perf : quads pré-alloués réutilisés par surface.DrawPoly (zéro alloc/frame),
-- même pattern que _xpVerts de cl_hud. DrawPoly lit la table immédiatement, aucune référence gardée.
local _ringQuads = {}
for i = 1, COOLDOWN_RING_SEGMENTS_FULL do
	_ringQuads[i] = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }
end

-- Border-only ring: fixed end at 12 o'clock; arc recedes counter-clockwise (opposite of clockwise-from-top).
local function draw_cooldown_ring(cx, cy, radius, elapsed_frac)
	elapsed_frac = math.min(1, math.max(0, elapsed_frac))
	local remaining_frac = 1 - elapsed_frac
	if remaining_frac <= 0 then
		return
	end
	local r_out = radius * COOLDOWN_RING_OUTER_FRAC
	local thick = math.max(2, radius * COOLDOWN_RING_THICKNESS_FRAC)
	local r_in = math.max(radius * 0.35, r_out - thick)
	local span = 2 * math.pi * remaining_frac
	local end_rad = -math.pi * 0.5
	local arc_start = end_rad - span
	local segs = math.max(4, math.ceil(COOLDOWN_RING_SEGMENTS_FULL * remaining_frac))

	if not mat_vgui_white:IsError() then
		surface.SetMaterial(mat_vgui_white)
		surface.SetDrawColor(COOLDOWN_OVERLAY_R, COOLDOWN_OVERLAY_G, COOLDOWN_OVERLAY_B, COOLDOWN_OVERLAY_A)
		for i = 0, segs - 1 do
			local t1 = arc_start + span * (i / segs)
			local t2 = arc_start + span * ((i + 1) / segs)
			local c1, s1 = math.cos(t1), math.sin(t1)
			local c2, s2 = math.cos(t2), math.sin(t2)
			-- perf : mutation du quad pré-alloué au lieu de 5 tables neuves par segment (même géométrie).
			local q = _ringQuads[i + 1]
			q[1].x = cx + c1 * r_out; q[1].y = cy + s1 * r_out
			q[2].x = cx + c2 * r_out; q[2].y = cy + s2 * r_out
			q[3].x = cx + c2 * r_in; q[3].y = cy + s2 * r_in
			q[4].x = cx + c1 * r_in; q[4].y = cy + s1 * r_in
			surface.DrawPoly(q)
		end
		return
	end

	surface.SetDrawColor(COOLDOWN_OVERLAY_R, COOLDOWN_OVERLAY_G, COOLDOWN_OVERLAY_B, COOLDOWN_OVERLAY_A)
	local half_l = math.max(0, math.floor(thick * 0.4))
	for off = -half_l, half_l do
		for i = 0, segs - 1 do
			local t1 = arc_start + span * (i / segs)
			local t2 = arc_start + span * ((i + 1) / segs)
			local c1, s1 = math.cos(t1), math.sin(t1)
			local c2, s2 = math.cos(t2), math.sin(t2)
			surface.DrawLine(
				cx + c1 * (r_out + off),
				cy + s1 * (r_out + off),
				cx + c2 * (r_out + off),
				cy + s2 * (r_out + off)
			)
		end
	end
end

function TriggerCoolDownHUD(icon, time)
	if not isnumber(time) or time <= 0 then
		return
	end
	if icon == "heavy_attack" then
		x = 1857
		y = 448
	elseif icon == "flashstep" then
		x = 1857
		y = 518
	elseif icon == "double_jump" then
		x = 1857
		y = 588
	end
	table.insert(cooldown_visuals, {
		x = x,
		y = y,
		start = CurTime(),
		duration = time,
		icon = icon,
	})
end

local function cooldown_preview_icon_active(icon_id)
	if not icon_id or #cooldown_visuals == 0 then
		return false
	end
	local now = CurTime()
	for _, cd in ipairs(cooldown_visuals) do
		if cd.icon == icon_id then
			local elapsed = (now - cd.start) / cd.duration
			if elapsed < 1 then
				return true
			end
		end
	end
	return false
end

hook.Add("HUDPaint", "LZY_HUD_WeaponCooldown_Draw", function()
	if #cooldown_visuals == 0 then
		return
	end

	local now = CurTime()
	local size = COOLDOWN_BASE_PX

	local idx = 1
	while idx <= #cooldown_visuals do
		local cd = cooldown_visuals[idx]
		local elapsed = (now - cd.start) / cd.duration
		if elapsed >= 1 then
			table.remove(cooldown_visuals, idx)
		else
			local x, y = cd.x, cd.y
			local cx = x + size * 0.5
			local cy = y + size * 0.5
			local radius = size * 0.5

			if not materials.cooldown_bg:IsError() then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(materials.cooldown_bg)
				surface.DrawTexturedRect(gRespX(x), gRespY(y), gRespX(size), gRespY(size))
			else
				surface.SetDrawColor(40, 40, 45, 220)
				draw.NoTexture()
				surface.DrawRect(gRespX(x), gRespY(y), gRespX(size), gRespY(size))
			end

			draw_cooldown_ring(gRespX(cx), gRespY(cy), gRespX(radius), elapsed)
			idx = idx + 1

			local icon = cd.icon
			if icon then
				local icon_mat = materials[icon]
				if icon_mat and not icon_mat:IsError() then
					local isz = (icon == "heavy_attack") and 42 or 28 -- Coup Lourd un peu plus gros
					local iw, ih = isz, isz
					RNDX.DrawMaterial(0, gRespX(x + (size - iw) * 0.5), gRespY(y + (size - ih) * 0.5), gRespX(iw), gRespY(ih), COL_WHITE, icon_mat) -- perf : couleur constante hoistée
				end
			end
		end
	end

	surface.SetDrawColor(255, 255, 255, 255)
	draw.NoTexture()
end)

-- Dessin de la roulette + previews de cooldown. Extrait en fonction GLOBALE pour que la
-- caméra libre puisse le dessiner via PostRenderVGUI (le freecam masque tout le HUDPaint,
-- mais le weapon selector doit s'afficher EXACTEMENT comme hors caméra libre). Même logique,
-- mêmes gates (enabled / selector_open / alive) -> rien ne change.
-- perf (choix user) : la liste d'armes n'est reconstruite qu'a l'OUVERTURE de la roulette au lieu
-- de CHAQUE frame pendant ~2.2s (les handlers de scroll/selection rebuildent DEJA avant usage, et
-- les boucles de rendu gardent IsValid -> une arme strippee pendant l'ouverture ne casse rien).
-- Tradeoff assume : une arme RAMASSEE roulette ouverte n'apparait qu'au prochain scroll.
local _selectorWasOpen = false

function LZY_HUD_DrawWeaponSelector()
	if not weapon_selector_enabled() then
		_selectorWasOpen = false
		return
	end
	if not selector_open() then
		_selectorWasOpen = false
		return
	end

	local ply = LocalPlayer()
	if not IsValid(ply) or not ply:Alive() or ply:InVehicle() then
		return
	end

	if not _selectorWasOpen then
		_selectorWasOpen = true
		rebuild_weapon_cache(ply) -- perf : rebuild a l'ouverture uniquement (transition ferme -> ouvert)
	end
	local count = #weapons_cache
	if count == 0 then
		return
	end

	target_index = math.max(1, math.min(target_index, count))
	smooth_index = smooth_index + (target_index - smooth_index) * math.min(1, FrameTime() * LERP_SPEED)

	local sw, sh = ScrW(), ScrH()
	local scale = sh / 1080
	local radius_x = sh * SELECTOR_RADIUS_X_FRAC
	local radius_y = sh * SELECTOR_RADIUS_Y_FRAC
	local cx = sw + radius_x * SELECTOR_CENTER_RIGHT_FRAC
	local cy = sh * 0.5

	local fade = 1
	local t_left = hide_until - RealTime()
	if t_left < 0.35 then
		fade = math.max(0, t_left / 0.35)
	end

	local bg_size = 74 * scale
	local icon_size = 43 * scale
	local half_bg = bg_size * 0.5
	local half_icon = icon_size * 0.5
	local guide_thickness = ARC_GUIDE_THICKNESS_PX * scale

	-- Mask radii for weapon_bg circles so the guide arc does not draw through them (texture may be translucent).
	-- Smaller pad = arc runs closer to the circle edge (tighter gap). Keep >= ~half line width so strokes don’t bleed in.
	local arc_holes = {}
	local hole_pad = math.max(0.3, guide_thickness * 0.3)
	for i, wep in ipairs(weapons_cache) do
		if IsValid(wep) then
			local delta = i - smooth_index
			local ang_deg = 180 + delta * ANGLE_STEP_DEG
			local rad = math.rad(ang_deg)
			local px = cx + math.cos(rad) * radius_x
			local py = cy + math.sin(rad) * radius_y
			if px < sw - bg_size and px > -bg_size and py > -bg_size and py < sh + bg_size then
				arc_holes[#arc_holes + 1] = { x = px, y = py, r = half_bg + hole_pad }
			end
		end
	end

	local alpha_guide = math.floor(220 * fade)
	draw_arc_outline_ellipse(cx, cy, radius_x, radius_y, ARC_GUIDE_START, ARC_GUIDE_END, ARC_GUIDE_R, ARC_GUIDE_G, ARC_GUIDE_B, alpha_guide, guide_thickness, arc_holes)

	for i, wep in ipairs(weapons_cache) do
		if IsValid(wep) then
			local delta = i - smooth_index
			local ang_deg = 180 + delta * ANGLE_STEP_DEG
			local rad = math.rad(ang_deg)
			local px = cx + math.cos(rad) * radius_x
			local py = cy + math.sin(rad) * radius_y

			if px < sw - bg_size and px > -bg_size and py > -bg_size and py < sh + bg_size then
				local is_focus = math.abs(delta) < 0.35
				local slot_alpha = math.floor((is_focus and 255 or 200) * fade)

				surface.SetDrawColor(255, 255, 255, slot_alpha)
				if not materials.weapon_bg:IsError() then
					surface.SetMaterial(materials.weapon_bg)
					surface.DrawTexturedRect(px - half_bg, py - half_bg, bg_size, bg_size)
				else
					local fill_a = math.floor(210 * fade)
					draw.RoundedBox(math.max(6, 8 * scale), px - half_bg, py - half_bg, bg_size, bg_size, Color(28, 28, 28, fill_a))
				end

				-- if is_focus then
				-- 	surface.SetDrawColor(0, 0, 0, math.floor(255 * fade))
				-- 	surface.DrawOutlinedRect(px - half_bg - 1, py - half_bg - 1, bg_size + 2, bg_size + 2, 2)
				-- end

				local ico = get_weapon_icon_mat(wep:GetClass())
				surface.SetDrawColor(255, 255, 255, slot_alpha)
				surface.SetMaterial(ico)
				surface.DrawTexturedRect(px - half_icon, py - half_icon, icon_size, icon_size)
			end
		end
	end

	-- Idle cooldown previews (hidden while that ability is on cooldown — same slots as TriggerCoolDown design coords).
	if not cooldown_preview_icon_active("heavy_attack") then
		RNDX.DrawMaterial(0, gRespX(1857), gRespY(448), gRespX(52), gRespY(52), COL_WHITE_128, materials.cooldown_bg)
		RNDX.DrawMaterial(0, gRespX(1857 + (COOLDOWN_BASE_PX - 42) * 0.5), gRespY(448 + (COOLDOWN_BASE_PX - 42) * 0.5), gRespX(42), gRespY(42), COL_WHITE_128, materials.heavy_attack)
	end
	if not cooldown_preview_icon_active("flashstep") then
		RNDX.DrawMaterial(0, gRespX(1857), gRespY(518), gRespX(52), gRespY(52), COL_WHITE_128, materials.cooldown_bg)
		RNDX.DrawMaterial(0, gRespX(1857 + (COOLDOWN_BASE_PX - 28) * 0.5), gRespY(518 + (COOLDOWN_BASE_PX - 28) * 0.5), gRespX(28), gRespY(28), COL_WHITE_128, materials.flashstep)
	end
	if not cooldown_preview_icon_active("double_jump") then
		RNDX.DrawMaterial(0, gRespX(1857), gRespY(588), gRespX(52), gRespY(52), COL_WHITE_128, materials.cooldown_bg)
		RNDX.DrawMaterial(0, gRespX(1857 + (COOLDOWN_BASE_PX - 28) * 0.5), gRespY(588 + (COOLDOWN_BASE_PX - 28) * 0.5), gRespX(28), gRespY(28), COL_WHITE_128, materials.double_jump)
	end
end

-- Rendu normal (hors caméra libre) : HUDPaint classique.
hook.Add("HUDPaint", "LZY_HUD_WeaponSelector_Draw", LZY_HUD_DrawWeaponSelector)

hook.Add("HUDShouldDraw", "LZY_HUD_WeaponSelector_HideDefault", function(name)
	if name == "CHudWeaponSelection" then
		return false
	end
end)

-- Negative priority runs before default 0 so we win over unrelated hooks that no-op.
hook.Add("PlayerBindPress", "LZY_HUD_WeaponSelector_Scroll", function(ply, bind, pressed)
	if not weapon_selector_enabled() or not pressed then
		return
	end
	if bind ~= "invnext" and bind ~= "invprev" then
		return
	end
	-- Possession : la molette n'ouvre/cycle PAS le sélecteur d'arme (return true = bind ignoré).
	if IsValid(ply) and ply:GetEvoNWBool("NCM_TF_Active", false) then return true end
	if gui.IsGameUIVisible() then
		return
	end
	if not IsValid(ply) or ply ~= LocalPlayer() then
		return
	end
	if not ply:Alive() or ply:InVehicle() then
		return
	end

	if input.IsMouseDown(MOUSE_LEFT) or input.IsMouseDown(MOUSE_RIGHT) then
		return true
	end

	if CurTime() < last_scroll_time + SCROLL_DELAY then
		return true
	end
	last_scroll_time = CurTime()

	rebuild_weapon_cache(ply)
	if LZY_Inventory_TryResyncMissingCombatWeapon then
		LZY_Inventory_TryResyncMissingCombatWeapon()
	end
	local count = #weapons_cache
	if count == 0 then
		return
	end

	local open = selector_open()
	if not open then
		target_index = index_of_active(ply)
		smooth_index = target_index
	end

	local go_next = bind == "invnext"
	if INVERT_WEAPON_SCROLL then
		go_next = not go_next
	end

	local prev_index = target_index
	if go_next then
		target_index = target_index + 1
		if target_index > count then
			target_index = 1
		end
	else
		target_index = target_index - 1
		if target_index < 1 then
			target_index = count
		end
	end

	if prev_index ~= target_index then
		surface.PlaySound(WEAPON_SELECTOR_SCROLL_SOUND)
	end

	hide_until = RealTime() + FADE_AFTER
	return true
end)

hook.Add("PlayerBindPress", "LZY_HUD_WeaponSelector_Attack", function(ply, bind, pressed)
	if not weapon_selector_enabled() or not pressed then
		return
	end
	if not selector_open() then
		return
	end
	if not IsValid(ply) or ply ~= LocalPlayer() then
		return
	end

	rebuild_weapon_cache(ply)

	if bind == "+attack" then
		local wep = weapons_cache[target_index]
		if not IsValid(wep) then
			hide_until = 0
			return true
		end
		surface.PlaySound(WEAPON_SELECTOR_CONFIRM_SOUND)
		local cur = ply:GetActiveWeapon()
		if IsValid(cur) and cur == wep then
			hide_until = 0
			return true
		end
		input.SelectWeapon(wep)
		hide_until = 0
		return true
	end

	if bind == "+attack2" then
		hide_until = 0
		return true
	end
end)

hook.Add("PlayerSpawn", "LZY_HUD_WeaponSelector_Reset", function(ply)
	if ply == LocalPlayer() then
		hide_until = 0
		table.Empty(cooldown_visuals)
	end
end)

concommand.Add("test_cd", function(ply, cmd, args)
    TriggerCoolDownHUD("heavy_attack", 3)
    TriggerCoolDownHUD("flashstep", 5)
    TriggerCoolDownHUD("double_jump", 7)
end)

net.Receive("Evo:Client:TriggerCoolDownHUD", function(len)
    local icon = net.ReadString()
    local time = net.ReadFloat()
    TriggerCoolDownHUD(icon, time)
end)