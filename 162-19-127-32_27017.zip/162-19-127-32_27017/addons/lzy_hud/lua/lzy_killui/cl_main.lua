-- "addons\\lzy_hud\\lua\\lzy_killui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local killUiSeconds = 3
local killSound = "tbfpvq7ot1yh/voom5ex2d6ew4.wav"
local killSoundDelay = 0.2

local materials = {
	bg = Material("tbfpvq7ot1yh/ml0f4gtc7is3sv.png"), -- 275x133
	title_txt = Material("tbfpvq7ot1yh/dqhxwpvu3j81x.png"), -- 140x13
}
local PANEL = {}
local frame = nil

function PANEL:Init()
	self:SetDraggable(false)
	self:SetSizable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:SetSize(275, 133)
	self:SetPos(ScrW() / 2 - 137.5, ScrH() * 0.75)
	self.killedName = ""

	-- Play a sound
	timer.Simple(killSoundDelay, function()
		if IsValid(self) then
			surface.PlaySound(killSound)
		end
	end)
end

function PANEL:Paint(w, h)
	RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.bg, 0)
	RNDX.DrawMaterial(0, w / 2 - 70, h / 2 - 20, 140, 13, Color(255, 255, 255, 255), materials.title_txt, 0)
	draw.SimpleText(self.killedName, "Ubuntu Mono:" .. tostring(gRespFont(23)), w / 2, h / 2 + 12, Color(255, 189, 190, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PANEL:OnClose()
	frame = nil
	self:Remove()
end

vgui.Register("lzy_killui", PANEL, "DFrame")

local function OpenKillUI(killedName)
	if frame then return end
	frame = vgui.Create("lzy_killui")
	frame.killedName = killedName

	-- Close after killUiSeconds seconds
	timer.Simple(killUiSeconds, function()
		frame:Close()
	end)
end

net.Receive("LZY:KillUI", function(len)
	local killedPlayer = net.ReadPlayer()
	-- Source unique EVO_GetRPDisplayName (lzy_meet) : présentation + masque d'anonymat.
	-- Une victime masquée ne doit pas être identifiée par son tueur.
	local killedName
	if EVO_GetRPDisplayName then
		killedName = EVO_GetRPDisplayName(killedPlayer)
	else
		killedName = LocalPlayer():DoIKnowHim(killedPlayer:GetUniqueID()) and (killedPlayer:GetEvoNWString("Nickname", "") ~= "" and killedPlayer:GetEvoNWString("Nickname") or killedPlayer:Nick()) or "???"
	end
	OpenKillUI(killedName)
end)
