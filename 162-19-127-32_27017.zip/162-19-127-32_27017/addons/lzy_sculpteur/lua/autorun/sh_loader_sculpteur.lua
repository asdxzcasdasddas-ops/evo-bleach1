-- "addons\\lzy_sculpteur\\lua\\autorun\\sh_loader_sculpteur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Loader addon Sculpteur du visage (PNJ qui ouvre le character creator avec
-- acces aux subpages Visage + Yeux uniquement, pas de changement de nom).

LZY_SCULPTEUR = LZY_SCULPTEUR or {}

if SERVER then
	AddCSLuaFile("lzy_sculpteur/sh_config.lua")
	AddCSLuaFile("lzy_sculpteur/cl_main.lua")

	util.AddNetworkString("LZY_Sculpteur:OpenEditor")
	util.AddNetworkString("LZY_Sculpteur:SaveEdit")
end

include("lzy_sculpteur/sh_config.lua")

if SERVER then
	include("lzy_sculpteur/sv_main.lua")
else
	include("lzy_sculpteur/cl_main.lua")
end
