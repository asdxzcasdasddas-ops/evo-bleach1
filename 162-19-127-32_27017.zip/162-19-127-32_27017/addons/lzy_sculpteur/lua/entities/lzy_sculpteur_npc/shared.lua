-- "addons\\lzy_sculpteur\\lua\\entities\\lzy_sculpteur_npc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Entity sculpteur PNJ.

ENT.Type        = "anim"
ENT.Base        = "base_anim"
ENT.PrintName   = "Sculpteur"
ENT.Author      = "lzy_sculpteur"
ENT.Spawnable   = false
ENT.AdminOnly   = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsSculpteur")
end
