-- "addons\\lzy_sculpteur\\lua\\entities\\lzy_sculpteur_npc\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("LZY_Sculpteur_NameTag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
	outline   = false,
})

-- RENDERGROUP_BOTH : model en passe OPAQUE (Draw), nametag en passe TRANSLUCIDE
-- (DrawTranslucent) qui tourne APRES tous les props -> avec IgnoreZ le nametag
-- ne peut plus etre occluded par un prop dessine devant.
ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette de nom.
ENT.EVO_PromptZ = 100

-- Pré-alloc : évite 2 Color() + 1 GetTextSize par frame (le nom est constant).
local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ePos = self:GetPos()
	-- Cull a 750u (avant 1500u : portee trop large)
	if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

	local cfg = LZY_SCULPTEUR and LZY_SCULPTEUR.Config or {}
	local name = cfg.NPCName or "Sculpteur"
	-- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 100, nil, 750, "parler") return end

	local pos = ePos + Vector(0, 0, 100)
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90) -- face caméra de rendu (suit la cam orbitale)

	-- cam.IgnoreZ : nametag toujours visible, pas occluded par le model NPC ou
	-- autres entites (cf. coiffeur cl_init pour explication).
	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		if _tagName ~= name then
			_tagName = name
			surface.SetFont("LZY_Sculpteur_NameTag")
			_tagTW, _tagTH = surface.GetTextSize(name)
		end
		draw.RoundedBox(8, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "LZY_Sculpteur_NameTag", 0, 0,
			COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
