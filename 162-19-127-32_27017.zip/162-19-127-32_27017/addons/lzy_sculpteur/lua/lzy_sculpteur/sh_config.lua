-- "addons\\lzy_sculpteur\\lua\\lzy_sculpteur\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Config addon Sculpteur du visage

LZY_SCULPTEUR = LZY_SCULPTEUR or {}
LZY_SCULPTEUR.Config = LZY_SCULPTEUR.Config or {}

local CFG = LZY_SCULPTEUR.Config

-- Modèle dédié (commit f4f267de) en TOUT-MINUSCULE : les .gma montent leurs fichiers en
-- minuscules -> l'ancienne casse mixte (evo_34SABfe9f4v9zdsda.mdl) ne matchait pas le fichier
-- réel. Si le pack n'est pas monté, le fallback d'init.lua spawn un citoyen + warning console.
CFG.NPCModel = "models/evo/summons/shinigami/evo_34sabfe9f4v9zdsda/evo_34SABfe9f4v9zdsda.mdl" -- casse exacte fournie par le user (2026-06)
-- Hueco Mundo = serveur Arrancar : ce PNJ y est un Arrancar (demande user 2026-07-24).
-- Override AVANT le repli de validité ci-dessous (il protège donc aussi ce modèle).
-- Le Seireitei garde son modèle Shinigami.
if game.GetMap() == "hueco_mundo_v1" then
	CFG.NPCModel = "models/evo/summons/arrancar/evo_w42qywutq3awo/evo_k87h3m96ffoee2.mdl"
end
-- Repli auto : modèle dédié absent -> modèle commun (le PNJ reste un vendeur,
-- pas un citoyen) ; init.lua garde le repli citoyen en tout dernier recours.
if SERVER and not util.IsValidModel(CFG.NPCModel) then
	print("[Sculpteur] modele dedie absent (" .. CFG.NPCModel .. ") -> fallback modele commun")
	CFG.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end
CFG.NPCSkin = 0
CFG.NPCBodygroups = {}
CFG.NPCScale = 1.0

CFG.NPCName = "Chirurgien esthétique"
CFG.NPCSubtitle = "Modifie ton visage et tes yeux"

CFG.InteractDistance = 200 -- check ENT:Use large : interaction via evo_npc_interact (E client) jusqu'à PromptDistance
CFG.PromptDistance = 160 -- portée d'interaction réelle (E marche jusque-là, demande user)
CFG.InteractKey = KEY_E

CFG.SpawnPositions = {
	rp_seireitei_v1 = {
		-- Recul de 90u sur l'axe X uniquement (Y inchangé) — encore -20
		{ pos = Vector(-8514.040039, 7909.192811, 428.948334), ang = Angle(0, -0.132463, 0) },
	},
	hueco_mundo_v1 = {
		-- Pos user 2026-06 (setpos 3184.97 8529.17 5376.59, regard yaw 175.99).
		-- Yaw BRUT : le +180 le mettait pile à l'envers (vérifié in-game).
		{ pos = Vector(3184.968750, 8529.166992, 5376.593262), ang = Angle(0, 175.99, 0) },
	},
	gm_construct = {
		{ pos = Vector(240, -80, -135), ang = Angle(0, 90, 0) },
	},
}

CFG.MaxZDelta = 200

-- Cout du service de sculpture : AU CHOIX coins OU yens (09/01, demande user),
-- le joueur choisit sa monnaie dans la popup, une seule est debitee. Mettre
-- l'une a 0 la retire du choix.
CFG.PriceCoins = 200
CFG.PriceYens  = 30000

-- Prix EFFECTIF pour ce joueur : GRATUIT pour un perso ANIMATION (NWBool
-- EVO_AnimChar, pose serveur par lzy_character, non spoofable) — l'animateur
-- prepare ses persos d'evenement sans frais (demande user 08/20). PARTAGE
-- client/serveur : le prompt [E], la popup de confirmation et les debits SQL
-- lisent le MEME prix ; a 0 tous les blocs `if price > 0` se sautent d'eux-memes.
function CFG.PrixPour(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return tonumber(CFG.PriceCoins) or 0
end

-- Part en YENS, meme gratuite pour les persos ANIMATION.
function CFG.PrixYensPour(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return tonumber(CFG.PriceYens) or 0
end
