-- "addons\\lzy_sculpteur\\lua\\lzy_sculpteur\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client-side sculpteur : prompt HUD + reception OpenEditor + flag SCULPTOR_MODE.

LZY_SCULPTEUR = LZY_SCULPTEUR or {}
local CFG = LZY_SCULPTEUR.Config or {}

local function findNearestSculpteur()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil, math.huge end

	local lpPos = lp:GetPos()
	local promptDist = tonumber(CFG.PromptDistance) or 250
	local maxZ = tonumber(CFG.MaxZDelta) or 200
	local promptDistSqr = promptDist * promptDist

	local best, bestDistSqr = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("lzy_sculpteur_npc")) do
		if IsValid(ent) then
			local ePos = ent:GetPos()
			if math.abs(ePos.z - lpPos.z) <= maxZ then
				local d2 = ePos:DistToSqr(lpPos)
				if d2 <= promptDistSqr and d2 < bestDistSqr then
					best, bestDistSqr = ent, d2
				end
			end
		end
	end
	return best, bestDistSqr
end

surface.CreateFont("LZY_Sculpteur_Prompt", {
	font     = "Roboto",
	size     = 22,
	weight   = 600,
	antialias = true,
})
surface.CreateFont("LZY_Sculpteur_Subtitle", {
	font     = "Roboto",
	size     = 16,
	weight   = 400,
	antialias = true,
})

-- Prompt « [E] Parler … » : DESSINÉ PAR LE SYSTÈME CENTRAL evo_npc_core (même UI plaque
-- Atelier + même logique « le plus proche affiche » pour TOUS les PNJ, user 2026-07-17).
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["sculpteur"] = {
	fGetTarget = function()
		if LZY_CHARACTER_BARBER_MODE or LZY_CHARACTER_TATTOO_MODE or LZY_CHARACTER_SCULPTOR_MODE then return nil end
		return (findNearestSculpteur())
	end,
	fLabel = function() return "[E] Parler au " .. (CFG.NPCName or "Sculpteur") end,
	fSub = function()
		-- PrixPour : 0 pour un perso ANIMATION -> affiche « Gratuit » plutôt que le tarif.
		local price = CFG.PrixPour(LocalPlayer())
		local priceYens = CFG.PrixYensPour and CFG.PrixYensPour(LocalPlayer()) or 0
		if price <= 0 and priceYens <= 0 then
			if (tonumber(CFG.PriceCoins) or 0) > 0 or (tonumber(CFG.PriceYens) or 0) > 0 then
				return "Gratuit (perso animation)"
			end
			return CFG.NPCSubtitle or ""
		end
		local t = {}
		if price > 0 then t[#t + 1] = price .. " coins" end
		if priceYens > 0 then t[#t + 1] = string.Comma(priceYens) .. " ¥" end
		return table.concat(t, " ou ")
	end,
}

local COLOR_FIELDS = {
	"hair_color1", "hair_color2", "hair_details_color", "eyes_color",
	"tattoo_color", "tattoo_color_2",
}

local NUMBER_FIELDS = {
	"skin_color", "scale", "hair_gradient_angle",
	"tattoo_pos_x", "tattoo_pos_y", "tattoo_scale_x", "tattoo_scale_y", "tattoo_opacity",
	"tattoo_pos_x_2", "tattoo_pos_y_2", "tattoo_scale_x_2", "tattoo_scale_y_2", "tattoo_opacity_2",
}

local function rewrapColors(data)
	for _, field in ipairs(COLOR_FIELDS) do
		local v = data[field]
		if istable(v) and not IsColor(v) and v.r and v.g and v.b then
			data[field] = Color(v.r, v.g, v.b, v.a or 255)
		end
	end
	for _, field in ipairs(NUMBER_FIELDS) do
		local v = data[field]
		if v ~= nil and not isnumber(v) then
			data[field] = tonumber(v) or 0
		end
	end
end

net.Receive("LZY_Sculpteur:OpenEditor", function()
	local data = net.ReadTable()
	if not istable(data) then return end

	rewrapColors(data)

	-- SCULPTOR_MODE implique BARBER_MODE (pas de nom editable, pas de page nom/genre).
	-- En plus, le flag SCULPTOR_MODE specifique fait afficher uniquement les boutons
	-- Visage + Yeux dans la nav et ouvre subpage 2 par defaut.
	LZY_CHARACTER_BARBER_MODE = true
	LZY_CHARACTER_SCULPTOR_MODE = true
	LZY_CHARACTER_BARBER_DATA = data

	if OpenCharacterCreator then
		OpenCharacterCreator()
	else
		MsgC(Color(255, 80, 80), "[Sculpteur] OpenCharacterCreator introuvable - addon lzy_character non charge ?", "\n")
	end
end)

-- ── Confirmation de PAIEMENT (demande user 2026-07-20) ───────────────────────
-- Popup DA (même style que le soigneur PNJ) : prix + solde AVANT d'envoyer la
-- sauvegarde (= avant le débit serveur, en COINS ici). L'éditeur est déjà FERMÉ
-- quand on arrive ici -> ANNULER = rien n'est appliqué NI payé.
surface.CreateFont("LZYSculpt_CfTitle", { font = "Roboto", size = 26, weight = 800 })
surface.CreateFont("LZYSculpt_CfBody",  { font = "Roboto", size = 19, weight = 500 })
surface.CreateFont("LZYSculpt_CfBtn",   { font = "Roboto", size = 18, weight = 700 })

local function askPayConfirm(price, money, priceYens, yens, onYes)
	-- AU CHOIX (09/01) : un bouton PAR monnaie, actif si le solde suffit ;
	-- onYes recoit la monnaie choisie ("coins"/"yens").
	local bCoinsOK = price > 0 and money >= price
	local bYensOK = priceYens > 0 and yens >= priceYens
	local W, H = 430, 286
	local f = vgui.Create("DFrame")
	f:SetSize(W, H) f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		surface.SetDrawColor(18, 18, 22, 245) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 25) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("Chirurgien esthétique", "LZYSculpt_CfTitle", w / 2, 26, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local sTarif = (price > 0 and priceYens > 0) and string.format("%d coins ou %s ¥, au choix", price, string.Comma(priceYens))
			or (price > 0 and string.format("%d coins", price) or string.format("%s ¥", string.Comma(priceYens)))
		draw.SimpleText("Chirurgie : " .. sTarif, "LZYSculpt_CfBody", w / 2, 72, Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.format("Tes coins : %d", money), "LZYSculpt_CfBody", w / 2, 100,
			bCoinsOK and Color(200, 200, 200) or Color(230, 90, 90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.format("Tes yens : %s ¥", string.Comma(yens)), "LZYSculpt_CfBody", w / 2, 128,
			bYensOK and Color(200, 200, 200) or Color(230, 90, 90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	local function mkB(x, y, label, col, colH, fn)
		local b = vgui.Create("DButton", f)
		b:SetText("") b:SetSize(180, 42) b:SetPos(x, y)
		b.Paint = function(_, w, h)
			draw.RoundedBox(6, 0, 0, w, h, b:IsHovered() and colH or col)
			draw.SimpleText(label, "LZYSculpt_CfBtn", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
	end
	local function payer(bOk, sMode)
		if not bOk then surface.PlaySound("a4xy732ex6yeop2/g1kpyv29gwai.mp3") return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		f:Remove()
		onYes(sMode)
	end
	mkB(W / 2 - 190, H - 116, string.format("%d coins", price),
		bCoinsOK and Color(45, 150, 85) or Color(60, 60, 65),
		bCoinsOK and Color(60, 180, 100) or Color(60, 60, 65), function() payer(bCoinsOK, "coins") end)
	mkB(W / 2 + 10, H - 116, string.Comma(priceYens) .. " ¥",
		bYensOK and Color(45, 150, 85) or Color(60, 60, 65),
		bYensOK and Color(60, 180, 100) or Color(60, 60, 65), function() payer(bYensOK, "yens") end)
	mkB(W / 2 - 90, H - 58, "Annuler", Color(60, 60, 65), Color(85, 85, 92), function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		f:Remove()
	end)
end

function LZY_SCULPTEUR.SendSaveToServer(characterData)
	if not istable(characterData) then return end
	-- PrixPour : 0 pour un perso ANIMATION -> pas de popup de paiement, envoi direct.
	local price = CFG.PrixPour(LocalPlayer())
	local priceYens = CFG.PrixYensPour and CFG.PrixYensPour(LocalPlayer()) or 0
	if price > 0 or priceYens > 0 then
		askPayConfirm(price, LocalPlayer():GetEvoNWInt("coins", 0),
			priceYens, LocalPlayer():GetEvoNWInt("Money", 0), function(sMode)
			LZY_SCULPTEUR._DoSendSave(characterData, sMode)
		end)
		return
	end
	LZY_SCULPTEUR._DoSendSave(characterData)
end

-- Seulement les champs visage/yeux/taille/peau (miroir serveur FACE_FIELDS).
local SAVE_FIELDS = {
	"shape_keys", "bodygroups", "bodygroupsString", "shapeKeysByName",
	"eyes_color", "pupils_texture", "pupils_separate", "pupil_left", "pupil_right",
	"scale", "skin_color",
}

function LZY_SCULPTEUR._DoSendSave(characterData, sPayMode)
	local payload = {}
	for _, field in ipairs(SAVE_FIELDS) do
		if characterData[field] ~= nil then payload[field] = characterData[field] end
	end

	net.Start("LZY_Sculpteur:SaveEdit")
	net.WriteTable(payload)
	net.WriteString(sPayMode or "") -- monnaie choisie ("coins"/"yens", vide = gratuit)
	net.SendToServer()

	local lp = LocalPlayer()
	if not IsValid(lp) or not lp.HUD_UpdatePlayerModel then return end
	for _, delay in ipairs({ 0.1, 0.4, 0.8, 1.5 }) do
		timer.Simple(delay, function()
			if IsValid(lp) and lp.HUD_UpdatePlayerModel then
				lp:HUD_UpdatePlayerModel()
			end
		end)
	end
end
