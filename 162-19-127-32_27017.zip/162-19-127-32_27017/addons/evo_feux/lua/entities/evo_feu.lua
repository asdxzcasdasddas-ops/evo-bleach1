-- "addons\\evo_feux\\lua\\entities\\evo_feu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO FEU - un feu pose par le staff (evo_feux). Une seule entite reseau par
-- feu ; tout le visuel est fait CHEZ LE CLIENT avec les systemes de particules
-- de feu de HL2 (particles/fire_01.pcf, deja dans le jeu).
--
-- POURQUOI PAS env_fire (23/09/2026) : dans ce moteur, env_fire range sa
-- taille dans quatre cases (tiny, small, medium, large, par tranches de 36)
-- et affiche le systeme de la case. Tout ce qui depasse 108 donne le meme
-- « env_fire_large » : grand, enorme et geant etaient exactement le meme feu,
-- constate en jeu par axxou. On ne peut pas grossir un systeme de particules
-- depuis Lua ; on COMPOSE : un coeur plus haut (fire_large_01/02) et un anneau
-- de grands feux autour pour la largeur.
--
-- LE COUT, borne :
--   * une entite par feu (pas une par flamme : l'anneau n'existe que chez le
--     client, aucune entite en plus) ;
--   * transmise au PVS seulement : un feu hors de vue n'existe pas chez le
--     client ;
--   * UN BUDGET chez chaque joueur, quel que soit le nombre de feux poses :
--     les 12 plus proches en plein detail (a moins de 4000 unites), les 18
--     suivants avec leur coeur seul (a moins de 12000), les autres rien ;
--     4 sons en boucle au plus (a moins de 1500), 6 lueurs au plus (a moins
--     de 2200). Pire cas, 80 geants autour de soi : ~130 systemes, pas 640 ;
--   * un changement de detail doit tenir une seconde avant d'etre applique :
--     pas de feu qui clignote a la limite quand on bouge.
-- ============================================================================
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Feu"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_OTHER

-- Ce qu'on affiche pour chaque taille. `coeur` : les systemes poses au centre ;
-- `anneau` : `n` systemes `nom` sur un cercle de `rayon` unites. `son` : volume
-- de la boucle ; `lueur` : rayon de la lumiere dynamique.
ENT.Formes = {
    petit  = { coeur = { "env_fire_small" },  son = 0.35, lueur = 180 },
    moyen  = { coeur = { "env_fire_medium" }, son = 0.45, lueur = 260 },
    grand  = { coeur = { "env_fire_large" },  son = 0.55, lueur = 380 },
    -- Deux fois le grand : un coeur plus haut, trois grands feux autour.
    enorme = { coeur = { "fire_large_01" }, anneau = { nom = "env_fire_large", n = 3, rayon = 70 },
               son = 0.7, lueur = 560 },
    -- Trois fois : deux coeurs superposes, six grands feux sur un cercle large.
    geant  = { coeur = { "fire_large_02", "fire_large_01" }, anneau = { nom = "env_fire_large", n = 6, rayon = 130 },
               son = 0.85, lueur = 780 },
}

game.AddParticles("particles/fire_01.pcf")
for _, n in ipairs({ "env_fire_small", "env_fire_medium", "env_fire_large", "fire_large_01", "fire_large_02" }) do
    PrecacheParticleSystem(n)
end

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "Taille")
    self:NetworkVar("Bool", 0, "Lueur")
    -- Date (CurTime du serveur) a laquelle le feu s'eteint ; 0 = il brule.
    self:NetworkVar("Float", 0, "Extinction")
end

if SERVER then
    function ENT:Initialize()
        -- Un modele minuscule jamais dessine : une entite sans modele n'est pas
        -- toujours transmise, et c'est la transmission qui porte le feu.
        self:SetModel("models/props_junk/PopCan01a.mdl")
        self:SetMoveType(MOVETYPE_NONE)
        self:SetSolid(SOLID_NONE)
        self:SetCollisionGroup(COLLISION_GROUP_WORLD)
        self:DrawShadow(false)
    end

    function ENT:UpdateTransmitState()
        return TRANSMIT_PVS
    end

    return
end

-- ── Client ──────────────────────────────────────────────────────────────────
local SON_BOUCLE = "ambient/fire/fire_small_loop2.wav"
local DETAIL_COMPLET, DETAIL_COEUR = 4000, 12000
local SON_DIST, LUEUR_DIST = 1500, 2200
local BUDGET_COMPLET, BUDGET_COEURS, BUDGET_SONS, BUDGET_LUEURS = 12, 18, 4, 6
local EXTINCTION_S = 3   -- la lueur et le son tombent en trois secondes

function ENT:Draw() end

-- Un systeme pose dans le monde, sans entite : on le detruit nous-memes.
local function Systeme(nom, pos)
    if CreateParticleSystemNoEntity then return CreateParticleSystemNoEntity(nom, pos) end
    return CreateParticleSystem(game.GetWorld(), nom, PATTACH_WORLDORIGIN, 0, pos)
end

-- Chaque systeme est garde avec son nom et sa place : s'il disparait, on sait
-- le reposer au meme endroit.
local function Poser(liste, nom, pos)
    liste[#liste + 1] = { nom = nom, pos = pos, ps = Systeme(nom, pos) }
end

-- bNet : tout enlever d'un coup (depart, hors de vue). Sinon on arrete
-- seulement d'emettre et les flammes en vol finissent leur vie (extinction).
local function Arreter(liste, bNet)
    for _, s in ipairs(liste or {}) do
        if s.ps and s.ps:IsValid() then s.ps:StopEmission(false, bNet == true) end
    end
end

-- Pose les systemes du niveau de detail voulu (2 = tout, 1 = coeur, 0 = rien).
function ENT:PoserDetail(niveau)
    if self._niveau == niveau then return end
    Arreter(self._systemes, true)
    self._systemes = {}
    self._niveau = niveau
    local F = self.Formes[self:GetTaille()] or self.Formes.moyen
    local pos = self:GetPos()
    if niveau >= 1 then
        for _, nom in ipairs(F.coeur) do Poser(self._systemes, nom, pos) end
    end
    if niveau >= 2 and F.anneau then
        local A = F.anneau
        -- Un depart d'angle tire de la position : deux feux voisins n'ont pas
        -- leur anneau aligne, ca ne se lit pas comme un motif.
        local a0 = (pos.x * 0.013 + pos.y * 0.007) % (2 * math.pi)
        for i = 1, A.n do
            local a = a0 + (i - 1) * 2 * math.pi / A.n
            Poser(self._systemes, A.nom, pos + Vector(math.cos(a) * A.rayon, math.sin(a) * A.rayon, 0))
        end
    end
end

-- Hors du PVS, l'entite dort et son Think s'arrete, mais des systemes poses
-- sans entite continueraient de tourner : on enleve tout en partant, le
-- Think reposera le bon detail au retour.
function ENT:Endormir()
    Arreter(self._systemes, true)
    self._systemes, self._niveau, self._voulu = nil, nil, nil
    if self._son then self._son:Stop() self._son = nil end
end

hook.Add("NotifyShouldTransmit", "EVO_Feu::Dormance", function(ent, bTransmis)
    if not bTransmis and IsValid(ent) and ent:GetClass() == "evo_feu" and ent.Endormir then ent:Endormir() end
end)

-- LE BUDGET, deux fois par seconde : on classe les feux par distance et on
-- distribue le detail, les sons et les lueurs aux plus proches.
local _prochainBudget = 0
hook.Add("Think", "EVO_Feu::Budget", function()
    local now = CurTime()
    if now < _prochainBudget then return end
    _prochainBudget = now + 0.5
    local oeil, l = EyePos(), {}
    for _, e in ipairs(ents.FindByClass("evo_feu")) do
        if IsValid(e) and not e:IsDormant() and e:GetExtinction() <= 0 then
            l[#l + 1] = { e = e, d = oeil:DistToSqr(e:GetPos()) }
        end
    end
    table.sort(l, function(a, b) return a.d < b.d end)
    local nComplets, nCoeurs, nSons, nLueurs = 0, 0, 0, 0
    for _, x in ipairs(l) do
        local d, e = math.sqrt(x.d), x.e
        local niveau = 0
        if d < DETAIL_COMPLET and nComplets < BUDGET_COMPLET then
            niveau, nComplets = 2, nComplets + 1
        elseif d < DETAIL_COEUR and nCoeurs < BUDGET_COEURS then
            niveau, nCoeurs = 1, nCoeurs + 1
        end
        e._budgetNiveau = niveau
        e._budgetSon = niveau > 0 and d < SON_DIST and nSons < BUDGET_SONS
        if e._budgetSon then nSons = nSons + 1 end
        e._budgetLueur = e:GetLueur() and d < LUEUR_DIST and nLueurs < BUDGET_LUEURS
        if e._budgetLueur then nLueurs = nLueurs + 1 end
    end
end)

function ENT:Lueur(F, k)
    local dl = DynamicLight(self:EntIndex())
    if not dl then return end
    local t = CurTime() * 9 + self:EntIndex()
    dl.pos = self:GetPos() + Vector(0, 0, 40)
    dl.r, dl.g, dl.b = 255, 120, 40
    dl.brightness = (2.2 + math.sin(t) * 0.35 + math.sin(t * 2.3) * 0.2) * k
    dl.decay = 1000
    dl.size = F.lueur
    dl.dietime = CurTime() + 0.2
end

function ENT:Think()
    if self:GetTaille() == "" then return end
    local F = self.Formes[self:GetTaille()] or self.Formes.moyen

    -- L'EXTINCTION : plus d'emission, les flammes en vol finissent, le son et
    -- la lueur tombent en trois secondes. L'entite part cote serveur apres.
    local tExt = self:GetExtinction()
    if tExt > 0 then
        if not self._eteint then
            self._eteint = true
            Arreter(self._systemes, false)
            if self._son then self._son:ChangeVolume(0, EXTINCTION_S) end
        end
        local k = 1 - math.Clamp((CurTime() - tExt) / EXTINCTION_S, 0, 1)
        if k > 0 and self._budgetLueur then self:Lueur(F, k) end
        return
    end

    -- Le detail donne par le budget, applique s'il tient une seconde.
    local voulu = self._budgetNiveau or 0
    if voulu ~= self._niveau then
        if self._voulu ~= voulu then self._voulu, self._depuis = voulu, CurTime() end
        if self._niveau == nil or CurTime() - self._depuis >= 1 then self:PoserDetail(voulu) end
    end

    -- Un systeme qui s'est termine (s'il n'etait pas en boucle) repart, un
    -- systeme perdu est repose a sa place.
    if (self._prochainControle or 0) < CurTime() then
        self._prochainControle = CurTime() + 1
        for _, s in ipairs(self._systemes or {}) do
            if not (s.ps and s.ps:IsValid()) then
                s.ps = Systeme(s.nom, s.pos)
            elseif s.ps:IsFinished() then
                s.ps:Restart()
            end
        end
    end

    if self._budgetSon and not self._son then
        self._son = CreateSound(self, SON_BOUCLE)
        if self._son then
            self._son:SetSoundLevel(70)
            self._son:PlayEx(F.son, 100)
        end
    elseif not self._budgetSon and self._son then
        self._son:Stop()
        self._son = nil
    end

    if self._budgetLueur then self:Lueur(F, 1) end
end

function ENT:OnRemove()
    self:Endormir()
end
