-- "addons\\lzy_renommeur\\lua\\lzy_renommeur\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Config addon Renommeur (PNJ « Scribe » — changement de prénom / nom).

LZY_RENOMMEUR = LZY_RENOMMEUR or {}
LZY_RENOMMEUR.Config = LZY_RENOMMEUR.Config or {}

local CFG = LZY_RENOMMEUR.Config

-- Modèle du PNJ : même logique que le coiffeur voisin (Shinigami au Seireitei,
-- Arrancar au Hueco Mundo, repli commun si le modèle dédié n'est pas monté).
CFG.NPCModel = "models/evo/summons/shinigami/evo_bdfze942fzd3sdaadxdzd/evo_Bdfze942fzd3sdaadXDZD.mdl"
if game.GetMap() == "hueco_mundo_v1" then
	CFG.NPCModel = "models/evo/summons/arrancar/evo_w42qywutq3awo/evo_k87h3m96ffoee2.mdl"
end
if SERVER and not util.IsValidModel(CFG.NPCModel) then
	print("[Renommeur] modele dedie absent (" .. CFG.NPCModel .. ") -> fallback modele commun")
	CFG.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end

CFG.NPCSkin = 0
CFG.NPCBodygroups = {}
CFG.NPCScale = 1.0

CFG.NPCName = "Scribe"
CFG.NPCSubtitle = "Change ton prénom et ton nom"

-- Mêmes portées que le coiffeur (interaction via evo_npc_interact jusqu'au prompt).
CFG.InteractDistance = 200
CFG.PromptDistance = 160
CFG.MaxZDelta = 200

-- Coût du changement de nom : AU CHOIX coins OU yens (09/01, demande user),
-- le joueur choisit sa monnaie, une seule est debitee. 0 = retire du choix.
CFG.PriceCoins = 300
CFG.PriceYens  = 40000

-- Prix EFFECTIF pour ce joueur : GRATUIT pour un perso ANIMATION (NWBool
-- EVO_AnimChar, posé serveur par lzy_character, non spoofable) — même patron que
-- le chirurgien (lzy_sculpteur, user 08/25). PARTAGÉ client/serveur : prompt [E],
-- fenêtre et débits SQL lisent le MÊME prix ; à 0 les blocs `if price > 0` se sautent.
function CFG.PrixPour(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return tonumber(CFG.PriceCoins) or 0
end

-- Part en YENS, meme gratuite pour les persos ANIMATION.
function CFG.PrixYensPour(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return tonumber(CFG.PriceYens) or 0
end

-- Positions par map : ~180u à DROITE du coiffeur + avancé de ~50u vers l'avant
-- (08/01 : le spot précédent débordait sur un sol plus bas, le PNJ n'était pas
-- à la hauteur du coiffeur/doyen). Le snap au sol fait la hauteur finale.
CFG.SpawnPositions = {
	rp_seireitei_v1 = {
		-- Reculé de ~30u (08/01, ajustement final user, comme au Hueco).
		{ pos = Vector(-1586.86, -11218.76, 427.77), ang = Angle(0, 177.754608, 0) },
	},
	hueco_mundo_v1 = {
		-- Reculé de ~30u (08/01, ajustement final user « très légèrement »).
		{ pos = Vector(2891.79, 7958.53, 5359.37), ang = Angle(0, 85.40, 0) },
	},
	gm_construct = {
		{ pos = Vector(260, -80, -135), ang = Angle(0, 90, 0) },
	},
}
