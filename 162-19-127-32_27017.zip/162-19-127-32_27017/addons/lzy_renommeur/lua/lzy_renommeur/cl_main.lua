-- "addons\\lzy_renommeur\\lua\\lzy_renommeur\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client Renommeur : prompt « [E] Parler au Scribe » (système central evo_npc_core)
-- + dialogue prénom / nom (prénom obligatoire, nom optionnel).

LZY_RENOMMEUR = LZY_RENOMMEUR or {}
local CFG = LZY_RENOMMEUR.Config or {}

local function findNearestRenommeur()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end

	local lpPos = lp:GetPos()
	local promptDist = tonumber(CFG.PromptDistance) or 160
	local maxZ = tonumber(CFG.MaxZDelta) or 200
	local promptDistSqr = promptDist * promptDist

	local best, bestDistSqr = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("lzy_renommeur_npc")) do
		if IsValid(ent) then
			local ePos = ent:GetPos()
			if math.abs(ePos.z - lpPos.z) <= maxZ then
				local d2 = ePos:DistToSqr(lpPos)
				if d2 <= promptDistSqr and d2 < bestDistSqr then
					best, bestDistSqr = ent, d2
				end
			end
		end
	end
	return best
end

EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["renommeur"] = {
	fGetTarget = findNearestRenommeur,
	fLabel = function() return "[E] Parler au " .. (CFG.NPCName or "Scribe") end,
	fSub = function()
		local price = CFG.PrixPour(LocalPlayer())
		local priceYens = CFG.PrixYensPour and CFG.PrixYensPour(LocalPlayer()) or 0
		if price <= 0 and priceYens <= 0 then
			if (tonumber(CFG.PriceCoins) or 0) > 0 or (tonumber(CFG.PriceYens) or 0) > 0 then
				return "Gratuit (perso animation)"
			end
			return CFG.NPCSubtitle or ""
		end
		local t = {}
		if price > 0 then t[#t + 1] = price .. " coins" end
		if priceYens > 0 then t[#t + 1] = string.Comma(priceYens) .. " ¥" end
		return table.concat(t, " ou ")
	end,
}

----------------------------------------------------------------------
-- Dialogue prénom / nom
----------------------------------------------------------------------

surface.CreateFont("LZYRenom_Title", { font = "Roboto", size = 26, weight = 800 })
surface.CreateFont("LZYRenom_Body",  { font = "Roboto", size = 18, weight = 500 })
surface.CreateFont("LZYRenom_Entry", { font = "Roboto", size = 20, weight = 600 })
surface.CreateFont("LZYRenom_Btn",   { font = "Roboto", size = 18, weight = 700 })

local COL_BG     = Color(18, 18, 22, 245)
local COL_BORDER = Color(255, 255, 255, 25)
local COL_FIELD  = Color(30, 31, 37)
local COL_TXT    = Color(236, 236, 240)
local COL_DIM    = Color(150, 150, 162)

net.Receive("LZY_Renommeur:Open", function()
	local curFirst = net.ReadString()
	local curLast  = net.ReadString()

	local nPrice = CFG.PrixPour(LocalPlayer()) -- 0 pour un perso animation
	local nPriceYens = CFG.PrixYensPour and CFG.PrixYensPour(LocalPlayer()) or 0
	local bGratuit = nPrice <= 0 and nPriceYens <= 0
	local bCoinsOK = nPrice > 0 and LocalPlayer():GetEvoNWInt("coins", 0) >= nPrice
	local bYensOK = nPriceYens > 0 and LocalPlayer():GetEvoNWInt("Money", 0) >= nPriceYens
	-- Payant = une rangee de plus (deux boutons de paiement au choix + Annuler).
	local W, H = 460, bGratuit and 332 or 384
	local f = vgui.Create("DFrame")
	f:SetSize(W, H) f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		surface.SetDrawColor(COL_BG) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_BORDER) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("Changement de nom", "LZYRenom_Title", w / 2, 26, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Le prénom est obligatoire, le nom est optionnel.", "LZYRenom_Body", w / 2, 56, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		if nPrice > 0 or nPriceYens > 0 then
			local t = {}
			if nPrice > 0 then t[#t + 1] = nPrice .. " coins" end
			if nPriceYens > 0 then t[#t + 1] = string.Comma(nPriceYens) .. " ¥" end
			draw.SimpleText("Coût : " .. table.concat(t, " ou ")
				.. " (tu as " .. LocalPlayer():GetEvoNWInt("coins", 0) .. " coins et "
				.. string.Comma(LocalPlayer():GetEvoNWInt("Money", 0)) .. " ¥)",
				"LZYRenom_Body", w / 2, 78, Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("Prénom", "LZYRenom_Body", 30, 104, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Nom", "LZYRenom_Body", 30, 178, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local function mkEntry(y, value)
		local e = vgui.Create("DTextEntry", f)
		e:SetPos(28, y) e:SetSize(W - 56, 38)
		e:SetFont("LZYRenom_Entry") e:SetText(value or "")
		e:SetTextColor(COL_TXT) e:SetCursorColor(COL_TXT) e:SetPaintBackground(false)
		e:SetUpdateOnType(false)
		if e.SetDrawLanguageID then e:SetDrawLanguageID(false) end -- retire l'indicateur « FR » dans le champ
		e.Paint = function(self, w, h)
			draw.RoundedBox(4, 0, 0, w, h, COL_FIELD)
			self:DrawTextEntryText(COL_TXT, Color(207, 68, 78), COL_TXT)
		end
		return e
	end
	local eFirst = mkEntry(118, curFirst)
	local eLast  = mkEntry(192, curLast)
	timer.Simple(0, function() if IsValid(eFirst) then eFirst:RequestFocus() end end)

	local function submit(sMode)
		local firstname = string.Trim(eFirst:GetValue() or "")
		local lastname  = string.Trim(eLast:GetValue() or "")
		if firstname == "" then
			MUGEN.Notify("Le prénom est obligatoire.", NOTIFY_ERROR, 4)
			return
		end
		net.Start("LZY_Renommeur:Save")
			net.WriteString(string.sub(firstname, 1, 32))
			net.WriteString(string.sub(lastname, 1, 32))
			net.WriteString(sMode or "") -- monnaie choisie ("coins"/"yens", vide = gratuit)
		net.SendToServer()
		f:Remove()
	end
	-- Entree = la premiere monnaie payable (coins d'abord), comme le bouton.
	local function submitDefaut() submit(bCoinsOK and "coins" or "yens") end
	eFirst.OnEnter = bGratuit and function() submit("") end or submitDefaut
	eLast.OnEnter = eFirst.OnEnter

	local function mkBtn(x, y, label, col, colH, fn)
		local b = vgui.Create("DButton", f)
		b:SetText("") b:SetSize(185, 42) b:SetPos(x, y)
		b.Paint = function(_, w, h)
			draw.RoundedBox(6, 0, 0, w, h, b:IsHovered() and colH or col)
			draw.SimpleText(label, "LZYRenom_Btn", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
	end
	if bGratuit then
		mkBtn(W / 2 - 195, H - 58, "Valider",
			Color(45, 150, 85), Color(60, 180, 100), function() submit("") end)
		mkBtn(W / 2 + 10, H - 58, "Annuler", Color(60, 60, 65), Color(85, 85, 92), function() f:Remove() end)
	else
		mkBtn(W / 2 - 195, H - 110, "Payer " .. nPrice .. " coins",
			bCoinsOK and Color(45, 150, 85) or Color(60, 60, 65),
			bCoinsOK and Color(60, 180, 100) or Color(60, 60, 65),
			function() if bCoinsOK then submit("coins") end end)
		mkBtn(W / 2 + 10, H - 110, "Payer " .. string.Comma(nPriceYens) .. " ¥",
			bYensOK and Color(45, 150, 85) or Color(60, 60, 65),
			bYensOK and Color(60, 180, 100) or Color(60, 60, 65),
			function() if bYensOK then submit("yens") end end)
		mkBtn(W / 2 - 92, H - 58, "Annuler", Color(60, 60, 65), Color(85, 85, 92), function() f:Remove() end)
	end
end)
