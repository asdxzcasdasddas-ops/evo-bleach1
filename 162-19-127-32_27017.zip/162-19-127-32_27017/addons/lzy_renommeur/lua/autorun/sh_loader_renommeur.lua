-- "addons\\lzy_renommeur\\lua\\autorun\\sh_loader_renommeur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Loader addon Renommeur : PNJ « Scribe » qui change le prénom / nom du personnage
-- (comme le setname du menu SAM, mais en self-service). Prénom requis, nom optionnel.
-- Posé à côté du coiffeur (Seireitei + Hueco Mundo), même patron d'addon que lzy_coiffeur.

LZY_RENOMMEUR = LZY_RENOMMEUR or {}

if SERVER then
	AddCSLuaFile("lzy_renommeur/sh_config.lua")
	AddCSLuaFile("lzy_renommeur/cl_main.lua")

	util.AddNetworkString("LZY_Renommeur:Open") -- server -> client : ouvre le dialogue avec prénom/nom actuels
	util.AddNetworkString("LZY_Renommeur:Save") -- client -> server : nouveau prénom + nom
end

include("lzy_renommeur/sh_config.lua")

if SERVER then
	include("lzy_renommeur/sv_main.lua")
else
	include("lzy_renommeur/cl_main.lua")
end
