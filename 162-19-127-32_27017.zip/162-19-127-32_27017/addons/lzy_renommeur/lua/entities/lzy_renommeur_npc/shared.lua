-- "addons\\lzy_renommeur\\lua\\entities\\lzy_renommeur_npc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Entity PNJ Scribe (anim simple, pas de NextBot/AI) : même patron que lzy_coiffeur_npc.

ENT.Type        = "anim"
ENT.Base        = "base_anim"
ENT.PrintName   = "Scribe"
ENT.Author      = "lzy_renommeur"
ENT.Spawnable   = false
ENT.AdminOnly   = true

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsRenommeur")
end
