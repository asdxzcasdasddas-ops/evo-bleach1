-- "addons\\evo_faille\\lua\\evo_faille\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- La Faille — client : dôme (même demi-sphère que la Bataille), HUD, popup,
-- avertissement de sortie, bannière de fin.
-- ============================================================================
if not CLIENT then return end

EVO_FAILLE = EVO_FAILLE or {}
local CFG = EVO_FAILLE.Config

local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local function COL()
    return EVO_UI and EVO_UI.Col or {
        bg = Color(16, 16, 19, 250), title = Color(238, 239, 243), muted = Color(150, 154, 162),
        dim = Color(106, 109, 118), accent = Color(207, 68, 78), green = Color(78, 196, 128),
    }
end

local function makeFonts()
    local mk = gCreateRespFont
    if not mk then
        local sc = math.max(1, ScrH() / 1080)
        mk = function(name, font, size)
            surface.CreateFont(name, { font = font, size = math.Round(size * sc), weight = 400, extended = true })
        end
    end
    mk("EVO_Faille_Small", "Bebas Neue", 22, 400)
    mk("EVO_Faille_Text",  "Bebas Neue", 28, 400)
    mk("EVO_Faille_Head",  "Bebas Neue", 36, 400)
    mk("EVO_Faille_Banner", "Bebas Neue", 64, 400)
end
makeFonts()
hook.Add("Initialize", "EVO_Faille::Fonts", makeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Faille::Fonts", makeFonts)

-- ── État ────────────────────────────────────────────────────────────────────
local elig = { see = false, hasArena = false, center = Vector(0, 0, 0), radius = 0, height = 0 }
local hud = { active = false, phase = 0, wave = 0, waves = 0, alive = 0, total = 0, remain = 0, players = 0, recvAt = 0 }
local exitWarn = { active = false, endsAt = 0 }
local banner = nil
local COL_VIOLET = Color(170, 100, 220)
local COL_GOLD   = Color(255, 200, 60)

function EVO_FAILLE.IsLocalInEvent() return hud.active == true end

-- ── Nets ────────────────────────────────────────────────────────────────────
net.Receive("EVO_Faille:Eligibility", function()
    elig.see = net.ReadBool()
    elig.hasArena = net.ReadBool()
    if elig.hasArena then
        elig.center = net.ReadVector()
        elig.radius = net.ReadFloat()
        elig.height = net.ReadFloat()
        if not elig.height or elig.height <= 0 then elig.height = elig.radius end
    end
end)

net.Receive("EVO_Faille:Hud", function()
    local active = net.ReadBool()
    if not active then hud.active = false return end
    hud.active  = true
    hud.phase   = net.ReadUInt(2)
    hud.wave    = net.ReadUInt(8)
    hud.waves   = net.ReadUInt(8)
    hud.alive   = net.ReadUInt(16)
    hud.total   = net.ReadUInt(16)
    hud.remain  = net.ReadUInt(16)
    hud.players = net.ReadUInt(8)
    hud.recvAt  = CurTime()
end)

net.Receive("EVO_Faille:ExitWarn", function()
    local on = net.ReadBool()
    local grace = net.ReadFloat()
    exitWarn.active = on
    exitWarn.endsAt = CurTime() + grace
end)

net.Receive("EVO_Faille:Banner", function()
    local kind = net.ReadString()
    local kills = net.ReadUInt(16)
    local now = RealTime()
    banner = { kind = kind, kills = kills, born = now, expire = now + ((CFG and CFG.BannerDuration) or 10) }
    surface.PlaySound((CFG and CFG.BannerSound) or "friends/friend_online.wav")
end)

-- Popup oui -> confirmation d'entrée (même patron que BatailleEnter).
LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.FailleEnter = function(_args)
    net.Start("EVO_Faille:EnterConfirm")
    net.SendToServer()
end

-- ── Dôme : même demi-sphère que la Bataille des Clans ───────────────────────
hook.Add("PostDrawTranslucentRenderables", "EVO_Faille::Dome", function(bDepth, bSky)
    if bDepth or bSky then return end
    if not elig.see or not elig.hasArena then return end
    if EVO_BATAILLE and EVO_BATAILLE.DrawHemiSphere then
        EVO_BATAILLE.DrawHemiSphere(elig.center, elig.radius, elig.height)
    end
end)

-- ── HUD ─────────────────────────────────────────────────────────────────────
local function formatTimer(sec)
    sec = math.max(0, math.floor(sec))
    return string.format("%02d:%02d", math.floor(sec / 60), sec % 60)
end

hook.Add("HUDPaint", "EVO_Faille::Hud", function()
    local col = COL()

    if exitWarn.active then
        local left = exitWarn.endsAt - CurTime()
        if left <= 0 then
            exitWarn.active = false
        else
            draw.SimpleText(string.format("REVIENS DANS LA ZONE — %d", math.ceil(left)), "EVO_Faille_Head",
                ScrW() * 0.5, ScrH() * 0.42, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    if hud.active then
        local remain = math.max(0, hud.remain - math.floor(CurTime() - (hud.recvAt or CurTime())))
        local title = (CFG and CFG.HudTitle) or "LA FAILLE"
        local big, lines = "", {}
        if hud.phase == 0 then
            big = "OUVERTURE " .. formatTimer(remain)
            lines[1] = "Les défenseurs se rassemblent…"
        else
            big = string.format("VAGUE %d / %d", hud.wave, hud.waves)
            lines[1] = string.format("Hollows restants : %d / %d", hud.alive, hud.total)
            lines[2] = "Temps : " .. formatTimer(remain)
        end
        lines[#lines + 1] = string.format("Défenseurs : %d / %d", hud.players, (CFG and CFG.MaxPlayers) or 20)

        surface.SetFont("EVO_Faille_Small")
        local maxW = surface.GetTextSize(title)
        surface.SetFont("EVO_Faille_Head")
        maxW = math.max(maxW, surface.GetTextSize(big))
        surface.SetFont("EVO_Faille_Text")
        for _, ln in ipairs(lines) do maxW = math.max(maxW, surface.GetTextSize(ln)) end

        local padX, padY, lineH = R(28), R(14), R(26)
        local boxW = maxW + padX * 2
        local boxH = padY + R(22) + R(8) + R(34) + R(8) + (#lines * lineH) + padY
        local x, y = R(15), R(12)

        -- Badge INSTANCE (même gabarit que la Bataille).
        local sBadge = "INSTANCE : LA FAILLE"
        local badgeFont = "NCM_Instance_Badge"
        surface.SetFont(badgeFont)
        local btw, bth = surface.GetTextSize(sBadge)
        if btw <= 0 then
            badgeFont = "EVO_Faille_Small"
            surface.SetFont(badgeFont)
            btw, bth = surface.GetTextSize(sBadge)
        end
        local badgeH = bth + R(10)
        local badgeW = math.max(boxW, btw + R(20))
        surface.SetDrawColor(13, 14, 17, 220)
        surface.DrawRect(x, y, badgeW, badgeH)
        surface.SetDrawColor(COL_VIOLET.r, COL_VIOLET.g, COL_VIOLET.b, 255)
        surface.DrawRect(x, y, R(2), badgeH)
        draw.SimpleText(sBadge, badgeFont, x + R(10), y + R(5), COL_VIOLET, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        y = y + badgeH + R(6)

        surface.SetDrawColor(13, 14, 17, 230)
        surface.DrawRect(x, y, boxW, boxH)
        surface.SetDrawColor(COL_VIOLET.r, COL_VIOLET.g, COL_VIOLET.b, 255)
        surface.DrawRect(x, y, R(3), boxH)
        local tx, ty = x + padX, y + padY
        draw.SimpleText(title, "EVO_Faille_Small", tx, ty, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        ty = ty + R(22) + R(4)
        draw.SimpleText(big, "EVO_Faille_Head", tx, ty, hud.phase == 0 and col.title or COL_GOLD, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        ty = ty + R(34) + R(4)
        for _, ln in ipairs(lines) do
            draw.SimpleText(ln, "EVO_Faille_Text", tx, ty, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            ty = ty + lineH
        end
    end

    if banner then
        local now = RealTime()
        if now > banner.expire then banner = nil return end
        local age = now - banner.born
        local a = 255
        if age < 0.4 then a = math.floor(255 * (age / 0.4)) end
        local left = banner.expire - now
        if left < 1 then a = math.floor(a * left) end
        local txt = banner.kind == "win" and "LA FAILLE EST REPOUSSÉE" or "LA FAILLE VOUS A SUBMERGÉS"
        local sub = string.format("%d Hollows abattus", banner.kills)
        local cy = ScrH() * 0.22
        draw.SimpleText(txt, "EVO_Faille_Banner", ScrW() * 0.5, cy,
            Color(banner.kind == "win" and COL_GOLD.r or COL_VIOLET.r, banner.kind == "win" and COL_GOLD.g or COL_VIOLET.g, banner.kind == "win" and COL_GOLD.b or COL_VIOLET.b, a),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(sub, "EVO_Faille_Text", ScrW() * 0.5, cy + R(48), Color(col.title.r, col.title.g, col.title.b, a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)
