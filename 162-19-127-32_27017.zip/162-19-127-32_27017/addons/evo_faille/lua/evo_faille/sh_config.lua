-- "addons\\evo_faille\\lua\\evo_faille\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- La Faille — configuration partagée
-- ============================================================================
EVO_FAILLE = EVO_FAILLE or {}

EVO_FAILLE.Config = {
    -- Chaque serveur host joue SA Faille (pas de cross-serveur : l'event a lieu
    -- en même temps des deux côtés, dans la Zone Neutre 2 de chaque map).
    HostMaps = {
        ["hueco_mundo_v1"]  = true,
        ["rp_seireitei_v1"] = true,
        -- ["gm_construct"] = true, -- décommenter pour tester sur gm_construct (l'arène de test existe plus bas)
    },

    -- Arènes = MÊMES dômes que la Bataille des Clans (Zone Neutre 2 des deux maps,
    -- calage user 08/14). center/radius/height : demi-ellipsoïde (sh_geometry).
    Arenas = {
        ["hueco_mundo_v1"] = {
            center = Vector(147.92, -1471.53, 8656.18),
            radius = 8000, height = 5000, name = "Zone Neutre 2",
        },
        ["rp_seireitei_v1"] = {
            center = Vector(3616.60, 844.63, -7509.47),
            radius = 8000, height = 8000, name = "Zone Neutre 2",
        },
        ["gm_construct"] = {
            center = Vector(-2321.89, 1210.60, -130.83),
            radius = 800, height = 800, name = "Zone de test",
        },
    },

    -- VERROU DE TEST (user 08/26) : false = aucun démarrage automatique, seules
    -- les commandes SA (evo_faille_start) lancent une Faille. Passer à true pour
    -- activer le rendez-vous hebdomadaire ci-dessous.
    AutoStart = false,

    -- Jours : os.date("*t").wday — 1=dimanche, 2=lundi, 3=mardi, 4=MERCREDI…
    Days = { [4] = true },

    JoinStart = { h = 21, m = 0 },  -- ouverture du dôme (popup dans la zone)
    JoinEnd   = { h = 21, m = 10 }, -- fermeture des entrées = la 1re vague s'ouvre
    SoftEnd   = { h = 21, m = 45 }, -- couperet : la Faille se referme quoi qu'il arrive

    -- Offsets (minutes depuis le lancement) pour evo_faille_start (SA).
    ForceStart = { JoinMinutes = 3, SoftEndMinutes = 30 },

    ExitGraceSeconds = 8,
    ZoneID           = "faille_hollows",
    MaxPlayers       = 20, -- défenseurs simultanés dans la Faille (user 08/26)

    -- Gargantas : réparties dans TOUT le dôme (user 08/26), chacune crache sa part de
    -- la vague. Positions tirées uniformément jusqu'à SpawnAreaFrac du rayon, sol
    -- obligatoire (point sans sol ou hors dôme = retiré), SpawnMinSep entre deux.
    SpawnAreaFrac      = 0.85,
    SpawnMinSep        = 700,
    HollowsPerGarganta = 3,    -- 1 Garganta pour ~3 Hollows
    GargantaMin        = 3,
    GargantaMax        = 14,
    GargantaClusterR   = 260,  -- rayon de sortie des Hollows autour de leur portail
    GargantaStagger    = 0.25, -- s entre deux ouvertures de portail

    EnemyGroup   = "hollow_fodder", -- SpawnGroup ncm_pnj (chien, alas, crapaud, base)
    EnemyHP      = 200,             -- PV forcés (event rapide, comme l'ancienne Faille)
    EnemyDamage  = nil,             -- nil = dégâts naturels du Hollow
    -- Vagues dimensionnées pour TargetPlayers défenseurs ; en dessous, l'effectif
    -- est réduit au prorata (plancher MinScale). Plafond nextbots serveur = 50
    -- (NCM_PNJ.GlobalHardCap), chasse ambiante comprise.
    TargetPlayers = 20,
    MinScale      = 0.3,

    -- Vagues : enemies (à effectif complet), delay (s entre deux sorties d'un même
    -- portail), timeLimit (s pour nettoyer la vague, sinon « submergés » = défaite).
    -- keepHp = PV naturels (boss). class = classe forcée (sinon tirage EnemyGroup).
    Waves = {
        { enemies = 8,  delay = 0.5, timeLimit = 90 },
        { enemies = 12, delay = 0.4, timeLimit = 120 },
        { enemies = 18, delay = 0.4, timeLimit = 150 },
        { enemies = 24, delay = 0.3, timeLimit = 180 },
        { enemies = 30, delay = 0.3, timeLimit = 210 },
        { enemies = 2,  delay = 1,   timeLimit = 300, class = "ncm_pnj_hollow_menos", keepHp = true }, -- finale
    },
    WaveGapSeconds = 4, -- respiration entre deux vagues

    -- Récompenses : top 10 des DÉGÂTS infligés (event coopératif), comme l'ancienne
    -- Faille. Coffres evo_loot ; distribuées à la victoire ET à la défaite.
    Rewards = { [1] = "coffre_legendaire", [2] = "coffre_epique", [3] = "coffre_epique" },
    RewardDefault = "coffre_rare",
    RewardTop     = 10,
    WinYens       = 2000, -- bonus de victoire à chaque participant récompensé

    PopupMessage   = "Une Faille s'ouvre : rejoindre la défense de la Zone Neutre ?",
    HudTitle       = "LA FAILLE",
    BannerDuration = 10,
    BannerSound    = "friends/friend_online.wav",
}

function EVO_FAILLE.IsHostMap(sMap)
    sMap = sMap or game.GetMap()
    local cfg = EVO_FAILLE.Config
    return cfg.HostMaps and cfg.HostMaps[sMap] == true
end

function EVO_FAILLE.GetArena(sMap)
    sMap = sMap or game.GetMap()
    local a = EVO_FAILLE.Config.Arenas and EVO_FAILLE.Config.Arenas[sMap]
    if not a or not a.center then return nil end
    return a
end

function EVO_FAILLE.GetArenaHeight(arena)
    if not arena then return 0 end
    local h = tonumber(arena.height)
    if h and h > 0 then return h end
    return tonumber(arena.radius) or 0
end

-- Même géométrie que la Bataille (sh_geometry) quand elle est chargée, sinon
-- repli demi-ellipsoïde local identique.
function EVO_FAILLE.IsInsideArena(vPos, arena)
    if not (vPos and arena and arena.center) then return false end
    if EVO_BATAILLE and EVO_BATAILLE.IsInsideArena then
        return EVO_BATAILLE.IsInsideArena(vPos, arena.center, arena.radius, EVO_FAILLE.GetArenaHeight(arena))
    end
    local r = tonumber(arena.radius) or 0
    if r <= 0 then return false end
    local h = EVO_FAILLE.GetArenaHeight(arena)
    local dz = vPos.z - arena.center.z
    if dz < -32 or dz > h then return false end
    local dx, dy = vPos.x - arena.center.x, vPos.y - arena.center.y
    return (dx * dx + dy * dy) / (r * r) + (dz * dz) / (h * h) <= 1
end

function EVO_FAILLE.TodayAt(tHM)
    local d = os.date("*t")
    d.hour = tonumber(tHM.h) or 0
    d.min  = tonumber(tHM.m) or 0
    d.sec  = 0
    return os.time(d)
end
