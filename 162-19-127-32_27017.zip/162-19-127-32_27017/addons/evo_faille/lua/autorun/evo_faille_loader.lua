-- "addons\\evo_faille\\lua\\autorun\\evo_faille_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LA FAILLE — vagues de Hollows en INSTANCE partagée (user 08/24), même logique
-- que la Bataille des Clans : dôme d'éligibilité, popup d'entrée, fenêtre de
-- join, grâce de sortie, KO = mort = éliminé, HUD, bannière, force-start SA.
-- Mercredi 21h, Zone Neutre 2 (Hueco ET Seireitei, chaque serveur joue la sienne).
-- ============================================================================
EVO_FAILLE = EVO_FAILLE or {}

if SERVER then
    AddCSLuaFile("evo_faille/sh_config.lua")
    AddCSLuaFile("evo_faille/cl_main.lua")
    util.AddNetworkString("EVO_Faille:Eligibility")
    util.AddNetworkString("EVO_Faille:EnterConfirm")
    util.AddNetworkString("EVO_Faille:Hud")
    util.AddNetworkString("EVO_Faille:ExitWarn")
    util.AddNetworkString("EVO_Faille:Banner")
end

include("evo_faille/sh_config.lua")

if SERVER then
    include("evo_faille/sv_main.lua")
else
    include("evo_faille/cl_main.lua")
end
