-- "addons\\lzy_ost\\lua\\lzy_ost\\client\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

LZY_OST = LZY_OST or {}

-- Client playback state & favorites (ported from old OST)
LZY_OST.ClientActiveSounds = LZY_OST.ClientActiveSounds or {}
LZY_OST.StartTrack = LZY_OST.StartTrack or nil
LZY_OST.ActiveStation = LZY_OST.ActiveStation or nil
LZY_OST.CanCustomize = LZY_OST.CanCustomize or false
LZY_OST.CanWorld = LZY_OST.CanWorld or false
LZY_OST.CanServer = LZY_OST.CanServer or false

local favorites = {}
local durationCache = {}

-- Préférence client : masquer les pistes bCopyright de la liste ET ne plus entendre
-- celles jouées par les AUTRES. Défaut false (= tout visible/audible). Persistance
-- data/lzy_ost_settings.txt (même schéma que favorites / binds / optimisations).
local OST_SETTINGS_FILE = "lzy_ost_settings.txt"
local muteCopyrightOthers = false
local copyrightPaths = {}

-- Repetition, 3 etats (demande joueur 26/10 : ne plus rester une heure sur la meme piste) :
--   "off"  : la piste s arrete a sa fin ;
--   "one"  : la piste en cours reboucle indefiniment. Le drapeau loop voyage jusqu au
--            serveur, qui le renvoie aux auditeurs en zone (sinon eux entendraient la
--            piste s arreter alors qu elle tourne encore chez le diffuseur) ;
--   "list" : a la fin d une piste, on lance la suivante de la liste affichee au
--            lancement (categorie, Favoris ou recherche), en boucle. Les Favoris
--            servent ainsi de playlist perso.
-- shuffleEnabled melange l ordre de cette liste. Persistance dans le meme fichier de
-- reglages que muteCopyrightOthers.
-- "list" PAR DEFAUT (user 26/10) : on s attend a ce que les Favoris s enchainent sans
-- reglage, et le mode etait introuvable a 2 clics du defaut. Seul un "off" choisi
-- explicitement au bouton est conserve.
local repeatMode = "list"
local shuffleEnabled = false

local function RebuildCopyrightPaths()
    copyrightPaths = {}
    for _, s in ipairs(LZY_OST.Config.Sounds or {}) do
        if s.sPath and s.bCopyright then
            copyrightPaths[s.sPath] = true
        end
    end
end
RebuildCopyrightPaths()

local function LoadFavorites()
    if file.Exists("lzy_ost_favorites.txt", "DATA") then
        local content = file.Read("lzy_ost_favorites.txt", "DATA")
        favorites = util.JSONToTable(content) or {}
    end
end
LoadFavorites()

local function LoadDurations()
    if file.Exists("lzy_ost_durations.txt", "DATA") then
        local content = file.Read("lzy_ost_durations.txt", "DATA")
        durationCache = util.JSONToTable(content) or {}
    end
end
LoadDurations()

local function LoadSettings()
    if not file.Exists(OST_SETTINGS_FILE, "DATA") then return end
    local content = file.Read(OST_SETTINGS_FILE, "DATA")
    local data = util.JSONToTable(content or "")
    if istable(data) then
        muteCopyrightOthers = data.muteCopyrightOthers == true
        if data.repeatMode == "off" or data.repeatMode == "one" or data.repeatMode == "list" then
            repeatMode = data.repeatMode
        elseif data.repeatEnabled == true then
            repeatMode = "one" -- ancien reglage (booleen) d avant le mode liste
        end
        -- Ancien repeatEnabled = false : l ancienne version l ecrivait meme sans clic sur
        -- le bouton (toggle « masquer © »), ce n est pas un choix -> reste au defaut "list".
        shuffleEnabled = data.shuffleEnabled == true
    end
end
LoadSettings()

local function SaveFavorites()
    file.Write("lzy_ost_favorites.txt", util.TableToJSON(favorites))
end

local function SaveDurations()
    file.Write("lzy_ost_durations.txt", util.TableToJSON(durationCache or {}))
end

local function SaveSettings()
    file.Write(OST_SETTINGS_FILE, util.TableToJSON({
        muteCopyrightOthers = muteCopyrightOthers == true,
        repeatMode = repeatMode,
        shuffleEnabled = shuffleEnabled == true,
    }))
end

-- Coupe immédiatement les streams © déjà en cours chez les autres (toggle ON
-- pendant qu'ils jouent). Les prochains Sync sont filtrés dans PlayLocal.
local function StopMutedOtherCopyrightSounds()
    if not muteCopyrightOthers then return end
    local lp = LocalPlayer()
    for ply, data in pairs(LZY_OST.ClientActiveSounds) do
        -- Une OST serveur (staff) doit arriver à tout le monde, même avec « masquer © ».
        if ply ~= lp and not data.isServer and data.path and copyrightPaths[data.path] then
            if IsValid(data.station) then data.station:Stop() end
            LZY_OST.ClientActiveSounds[ply] = nil
        end
    end
end

local function ShouldMuteOtherCopyright(ply, sPath, isServer)
    if isServer then return false end
    return muteCopyrightOthers and IsValid(ply) and ply ~= LocalPlayer() and copyrightPaths[sPath] == true
end

-- Remonte un échec de chargement audio au joueur (sinon : aucun son + aucune
-- indication, l'UI reste figée comme "en lecture").
local function OST_NotifyLoadFail(sPath, errCode, errStr)
    chat.AddText(Color(255, 80, 80), "[OST] ", Color(255, 255, 255), "Impossible de charger cette piste (code " .. tostring(errCode or "?") .. ").")
    print("[LZY_OST] PlayFile fail:", sPath, "code=" .. tostring(errCode), errStr)
end

local function IsFavorite(name)
    return favorites[name] == true
end

local function ToggleFavorite(name)
    favorites[name] = not favorites[name]
    SaveFavorites()
end

local volume = 50
local rangeValue = 0.5 -- 0-1, mapped to actual meters when sending to server
LZY_OST.DebugRangePreview = LZY_OST.DebugRangePreview or { radius = 0, untilTime = 0 }
local UpdatePlayerUI -- defined later, used from net handlers
local onlyForMeEnabled = true
local serverBroadcast = false -- 3e mode (superadmin / Gérant RP) : tout le serveur

-- File de lecture : la liste affichee quand on a lance une piste depuis le menu. Elle vit
-- hors du PANEL pour que le mode "list" continue menu ferme. paths = chemins figes au
-- lancement ; order = indices dans paths (melanges si aleatoire) ; pos = position dans
-- order. pending : un play est parti, on attend son retour avant de rien relancer.
local playQueue = { paths = {}, order = {}, pos = 0, pending = false, pendingAt = 0 }

local function FindSoundByPath(sPath)
    for _, v in ipairs(LZY_OST.Config.Sounds or {}) do
        if v.sPath == sPath then return v end
    end
end

-- Fisher-Yates. firstIdx : piste a garder en tete (celle qu on vient de cliquer).
-- avoidIdx : piste a ne pas mettre en tete (la derniere du tour precedent, sinon on
-- l entendrait deux fois d affilee au moment du remelange).
local function ShuffleOrder(order, firstIdx, avoidIdx)
    for i = #order, 2, -1 do
        local j = math.random(i)
        order[i], order[j] = order[j], order[i]
    end
    for k, idx in ipairs(order) do
        if idx == firstIdx then
            order[1], order[k] = order[k], order[1]
            return
        end
    end
    if avoidIdx and #order > 1 and order[1] == avoidIdx then
        local k = math.random(2, #order)
        order[1], order[k] = order[k], order[1]
    end
end

local function BuildOrder(firstIdx)
    local order = {}
    for i = 1, #playQueue.paths do order[i] = i end
    if shuffleEnabled then ShuffleOrder(order, firstIdx) end
    playQueue.order = order
    playQueue.pos = 1
    for k, idx in ipairs(order) do
        if idx == firstIdx then
            playQueue.pos = k
            break
        end
    end
end

local function BuildQueue(paths, startPath)
    playQueue.paths = paths
    local first = 1
    for i, p in ipairs(paths) do
        if p == startPath then
            first = i
            break
        end
    end
    BuildOrder(first)
end

local function ClearQueue()
    playQueue.paths = {}
    playQueue.order = {}
    playQueue.pos = 0
    playQueue.pending = false
end

local function QueueCurrentPath()
    return playQueue.paths[playQueue.order[playQueue.pos] or 0]
end

-- Recale la position sur la piste qui joue vraiment. Deux Suivant en moins de 0,2 s :
-- le serveur ignore le 2e play (anti-spam), la file aurait une piste d avance et
-- l enchainement ne reconnaitrait plus la piste en cours. Faux si elle n est pas dans
-- la file (lancee par autre chose).
local function SyncQueueTo(sPath)
    if QueueCurrentPath() == sPath then return true end
    for k, idx in ipairs(playQueue.order) do
        if playQueue.paths[idx] == sPath then
            playQueue.pos = k
            return true
        end
    end
    return false
end

-- Avance (dir = 1) ou recule (dir = -1) en bouclant. En aleatoire, chaque nouveau tour
-- est remelange.
local function QueueStep(dir)
    local n = #playQueue.order
    if n == 0 then return nil end
    local pos = playQueue.pos + dir
    if pos > n then
        if shuffleEnabled and n > 1 then
            ShuffleOrder(playQueue.order, nil, playQueue.order[n])
        end
        pos = 1
    elseif pos < 1 then
        pos = n
    end
    playQueue.pos = pos
    return QueueCurrentPath()
end

-- Envoi du play au serveur avec les reglages courants du lecteur (volume, Moi / Zone /
-- Serveur, portee, repetition). Hors du PANEL : l enchainement automatique l appelle
-- aussi menu ferme.
local function SendPlayTrack(soundData)
    if not soundData or not soundData.sPath then return end

    -- En attente jusqu au retour du play. Couvre aussi le stop que le serveur envoie
    -- juste avant quand on passe de Zone a Moi : il ne doit pas vider la file.
    playQueue.pending = true
    playQueue.pendingAt = CurTime()

    local serverMode = serverBroadcast and LZY_OST.CanServer == true
    local isArea = serverMode or not onlyForMeEnabled

    local data = {
        path   = soundData.sPath,
        volume = volume / 100,
        isArea = isArea,
        loop   = repeatMode == "one"
    }

    -- Map client-side slider (0-1) to an absolute range; server clamps within permissions
    if serverMode then
        data.isServer = true
        data.isArea = true
    elseif isArea then
        local maxRange = LZY_OST.Config.DefaultLevelRange or 500
        local minRange = 100
        local cr = math.floor(rangeValue * maxRange)
        if cr < minRange then cr = minRange end
        data.customRange = cr
    end

    -- La duree part avec la piste : le serveur s'en sert pour la retirer a sa fin
    -- (sans elle, il la croyait en cours pour toujours). Deja connue si le menu l'a
    -- mesuree ; sinon on la lit avant d'envoyer (fichier local, quasi immediat).
    local function SendPlay()
        net.Start("EVO_OST_Action")
            net.WriteString("play")
            net.WriteTable(data)
        net.SendToServer()
    end
    local known = durationCache[soundData.sPath]
    if known and known > 0 then
        data.length = known
        SendPlay()
        return
    end
    sound.PlayFile(soundData.sPath, "noplay", function(station)
        if IsValid(station) then
            local len = station:GetLength() or 0
            station:Stop()
            if len > 0 then
                data.length = len
                durationCache[soundData.sPath] = len
                SaveDurations()
            end
        end
        SendPlay()
    end)
end

-- Joue la piste voisine dans la file (Suivant / Precedent / fin de piste en mode liste).
local function PlayQueueStep(dir)
    -- Pas pendant un envoi : la piste en cours est encore l ancienne, on perdrait le pas.
    local mine = LZY_OST.ClientActiveSounds[LocalPlayer()]
    if mine and not playQueue.pending then SyncQueueTo(mine.path) end
    local soundData = FindSoundByPath(QueueStep(dir))
    if not soundData then return false end
    SendPlayTrack(soundData)
    return true
end

-- Ma piste est-elle arrivee au bout ? Avec un canal, c est son etat qui fait foi : une
-- lecture perso mise en pause par une zone prioritaire reprend la ou elle en etait, le
-- temps ecoule depuis le lancement ne veut alors plus rien dire. Sans canal (en Zone, un
-- diffuseur prioritaire a coupe mon propre flux, la piste continue chez mes auditeurs),
-- on se rabat sur le temps ecoule.
local function HasMyTrackEnded(mine)
    if not mine or mine.isPaused or mine.loop then return false end
    if IsValid(mine.station) then
        return mine.station:GetState() == GMOD_CHANNEL_STOPPED
    end
    local len = durationCache[mine.path] or 0
    if len <= 0 then return false end
    return CurTime() - (mine.startTime or CurTime()) >= len
end

-- Mode liste : enchaine sur la piste suivante quand la mienne se termine.
-- netgate: edge -- n'envoie qu'a la fin de ma piste ; playQueue.pending (pose par SendPlayTrack) bloque tout renvoi jusqu'au retour du play, 1 relance max / 3 s s'il se perd
local function TryAdvanceQueue()
    if repeatMode ~= "list" or #playQueue.order < 2 then return end
    if playQueue.pending then
        if CurTime() - playQueue.pendingAt < 3 then return end
        playQueue.pending = false -- play perdu ou refuse : on se debloque
    end
    local mine = LZY_OST.ClientActiveSounds[LocalPlayer()]
    -- Piste hors file (lancee par autre chose) : on ne touche a rien.
    if not mine or not HasMyTrackEnded(mine) or not SyncQueueTo(mine.path) then return end
    PlayQueueStep(1)
end

-- Boucle native du canal : BASS reboucle sans re-telecharger le fichier, donc pas
-- de blanc entre deux tours (un re-PlayFile a chaque fin en laisserait un).
local function ApplyLoop(station, data)
    if not IsValid(station) or not data then return end
    if station.EnableLooping then station:EnableLooping(data.loop == true) end
end

-- Ramene un temps de lecture dans la piste. En boucle, les compteurs du serveur
-- (startTime, pausedAt) continuent de grimper au-dela de la duree : sans le modulo,
-- SetTime pointerait apres la fin et le canal s arreterait aussitot (auditeur en
-- zone qui entre en cours de route, reprise apres pause, flux recree).
local function WrapTime(station, data, t)
    t = t or 0
    if t < 0 then t = 0 end
    if data and data.loop and IsValid(station) and station.GetLength then
        local len = station:GetLength() or 0
        if len > 0 then t = t % len end
    end
    return t
end

local function ElapsedFor(station, data)
    return WrapTime(station, data, CurTime() - (data.startTime or CurTime()))
end

local function HasTrackEnded(data)
    return not data.loop and not data.isPaused and data.length and data.length > 0
        and CurTime() - (data.startTime or CurTime()) >= data.length
end

local function PlayLocal(ply, sPath, vol, isArea, range, isWorld, startTime, pausedAt, isPaused, isLoop, nPrio, isServer)
    if not IsValid(ply) then return end
    isServer = isServer == true
    -- Le play attendu par l enchainement est revenu : la file peut reprendre la main.
    if ply == LocalPlayer() then playQueue.pending = false end

    -- Préférence « masquer © » : ignore uniquement les pistes copyrightées des AUTRES
    -- (ses propres lectures restent audibles, y compris ©). L'OST serveur passe quand même.
    if ShouldMuteOtherCopyright(ply, sPath, isServer) then
        local existing = LZY_OST.ClientActiveSounds[ply]
        if existing then
            if IsValid(existing.station) then existing.station:Stop() end
            LZY_OST.ClientActiveSounds[ply] = nil
        end
        return
    end

    if LZY_OST.ClientActiveSounds[ply] and IsValid(LZY_OST.ClientActiveSounds[ply].station) then
        LZY_OST.ClientActiveSounds[ply].station:Stop()
    end

    local soundData = {
        station = nil,
        isArea = isArea,
        isWorld = isWorld,
        isServer = isServer,
        range = range,
        path = sPath,
        owner = ply,
        isListening = false,
        waitingForStream = false,
        isPaused = isPaused,
        startTime = startTime,
        pausedAt = pausedAt,
        loop = isLoop == true,
        prio = tonumber(nPrio) or 0 -- priorité du diffuseur (staff SAM × 100 + grade), cf. serveur
    }
    LZY_OST.ClientActiveSounds[ply] = soundData

    local function OnStationCreated(station)
        if not IsValid(ply) or LZY_OST.ClientActiveSounds[ply] ~= soundData then
            if IsValid(station) then station:Stop() end
            return
        end

        soundData.station = station
        -- The mixer decides audibility on Think, including server overrides.
        station:SetVolume(0)
        ApplyLoop(station, soundData)

        if soundData.isPaused then
            station:SetTime(WrapTime(station, soundData, soundData.pausedAt))
            station:Pause()
        else
            station:SetTime(ElapsedFor(station, soundData))
            station:Play()
        end

        if ply == LocalPlayer() then
            LZY_OST.ActiveStation = station
            for _, v in ipairs(LZY_OST.Config.Sounds or {}) do
                if v.sPath == sPath then
                    LZY_OST.StartTrack = v
                    break
                end
            end
            if UpdatePlayerUI then UpdatePlayerUI() end
        end
    end

    if not isArea then
        sound.PlayFile(sPath, "noplay", function(station, errCode, errStr)
            -- A previous load can complete after play/stop/play, including errors.
            if not IsValid(ply) or LZY_OST.ClientActiveSounds[ply] ~= soundData then
                if IsValid(station) then station:Stop() end
                return
            end
            if IsValid(station) then
                OnStationCreated(station)
            else
                OST_NotifyLoadFail(sPath, errCode, errStr)
                LZY_OST.ClientActiveSounds[ply] = nil
                if ply == LocalPlayer() then
                    ClearQueue() -- ne pas enchainer d echec en echec
                    LZY_OST.StartTrack = nil
                    LZY_OST.ActiveStation = nil
                    if UpdatePlayerUI then UpdatePlayerUI() end
                end
            end
        end)
    else
        if ply == LocalPlayer() then
            for _, v in ipairs(LZY_OST.Config.Sounds or {}) do
                if v.sPath == sPath then
                    LZY_OST.StartTrack = v
                    break
                end
            end
            if UpdatePlayerUI then UpdatePlayerUI() end
        end
    end
end

local frame = nil
local can_open = true

-- ============================================================================
-- DA « ATELIER » (2026-07-06, même style que spell selector / menu échap /
-- squad) : carte = PLAQUE de métal noir à coins coupés + liseré acier + 4 VIS
-- d'angle (fente 38°), kanji 月 gravé (passe claire ultra-légère), titre en
-- Bebas Neue SANS bold + entaille slash1 réduite, filet DENTÉ sous le titre,
-- fond écran = mêmes appels que le selector (blur RNDX + voile 5,5,7,216 — le
-- EVO_UI.DrawBlur d'avant coûtait 4 captures écran/frame). Fontes d'affichage
-- en Bebas ; champs de saisie en Avenir (lisible en bas-de-casse). Seules les
-- POCHETTES des musiques et l'étoile de favori restent des matériaux.
-- ============================================================================

-- ── Helpers de dessin DA Atelier (mêmes recettes que le menu échap/squad) ──
local function drawCircle(cx, cy, r, col)
    local pts = {}
    for i = 0, 11 do
        local a = math.rad(i * 30)
        pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
    end
    draw.NoTexture()
    surface.SetDrawColor(col)
    surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
    drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
    drawCircle(cx, cy, r, Color(23, 25, 29, 255))
    drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
    draw.NoTexture()
    surface.SetDrawColor(0, 0, 0, 140)
    surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
    surface.SetDrawColor(col)
    local dw, gap = gRespX(6), gRespX(5)
    local cx = x
    while cx < x + w do
        surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
        cx = cx + dw + gap
    end
end

-- Palette DA (hoistée : jamais de Color() par frame dans les Paint).
local COL = {
    card        = Color(14, 14, 17),        -- #0E0E11 : fond de la carte
    sub         = Color(22, 22, 27),        -- #16161B : cartes internes
    sub2        = Color(28, 28, 34),        -- #1C1C22 : hover
    hover       = Color(34, 34, 41),
    accent      = Color(207, 68, 78),       -- #cf444e : accent (sélection, barres, actions)
    accentHover = Color(224, 92, 102),
    accentSoft  = Color(207, 68, 78, 30),   -- teinte de la ligne en lecture
    title       = Color(238, 239, 243),
    muted       = Color(150, 154, 162),
    dim         = Color(106, 109, 118),
    divider     = Color(255, 255, 255, 18),
    track       = Color(255, 255, 255, 26), -- fond des barres (volume/portée/seek)
    trackDim    = Color(255, 255, 255, 60), -- remplissage "inactif" (piste finie / grisé)
    xHoverBg    = Color(255, 255, 255, 14),
    grip        = Color(255, 255, 255, 40),
    gold        = Color(255, 215, 0),
    goldInk     = Color(28, 22, 12),
    faded       = Color(255, 255, 255, 100),
}
local COL_WHITE = Color(255, 255, 255, 255)
local COL_PREVIEW = Color(0, 200, 255)

-- Infobulle sombre dédiée au menu OST (le DTooltip natif est clair).
local OST_TOOLTIP = {}
function OST_TOOLTIP:Init()
    self:SetDrawOnTop(true)
    self:SetText("")
    self:SetFont("Avenir Next World:15")
    self:SetTextColor(COL.title)
end
function OST_TOOLTIP:Paint(w, h)
    if EVO_UI and EVO_UI.PaintTooltip then
        return EVO_UI.PaintTooltip(0, 0, w, h)
    end
    RNDX.Draw(0, 0, 0, w, h, COL.sub)
    surface.SetDrawColor(COL.accent)
    surface.DrawRect(0, 0, gRespX(3), h)
    surface.SetDrawColor(COL.divider)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end
function OST_TOOLTIP:PerformLayout()
    local w, h = self:GetContentSize()
    self:SetSize(w + gRespX(20), h + gRespY(12))
    self:SetContentAlignment(5)
end
function OST_TOOLTIP:OpenForPanel(panel)
    if panel and panel.strTooltipText then
        self:SetText(panel.strTooltipText)
    end

    self:InvalidateLayout(true)
    local x, y = input.GetCursorPos()
    self:SetPos(
        math.Clamp(x - self:GetWide() / 2, 0, ScrW() - self:GetWide()),
        math.Clamp(y - self:GetTall() - gRespY(12), 0, ScrH() - self:GetTall())
    )
end
function OST_TOOLTIP:Close()
    self:Remove()
end
vgui.Register("LZY_OST_DarkTooltip", OST_TOOLTIP, "DLabel")

-- Géométrie de la carte (espace 1920x1080, converti via gRespX/gRespY).
local CARD_X, CARD_Y = 400, 200
local CARD_W, CARD_H = 1120, 680
local PAD_X = 26                                  -- marge interne horizontale
local CONTENT_X = CARD_X + PAD_X                  -- 426
local CONTENT_W = CARD_W - PAD_X * 2              -- 1068
local CAT_Y, CAT_H = 272, 36
local LIST_Y, LIST_H = 320, 428
local BAR_Y, BAR_H = 764, 92                      -- bandeau "en lecture"

-- Étoile de favori (seul matériau de chrome conservé — c'est une icône, pas un fond).
local matFavorite = Material("materials/r1n1mtedmal9vcf/a1vsb90til36m29.png", "smooth") -- 14x14

-- Cache des matériaux de pochette : Material() par chaîne était appelé dans Paint
-- CHAQUE frame (piste courante + chaque ligne de musique visible).
local iconMatCache = {}
local function GetIconMaterial(path)
    path = path or "lzy_ost/icon_music_1.png"
    local m = iconMatCache[path]
    if not m then
        m = Material(path)
        iconMatCache[path] = m
    end
    return m
end

-- Fontes du header : celles du kit EVO_UI (Bebas + croix Roboto). Filet si le kit
-- n'est pas encore chargé (ordre de chargement) : on crée des équivalents locaux.
local function EnsureFonts()
    if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() return end
    if gCreateRespFont then
        gCreateRespFont("EVO_UI_Header", "Bebas Neue", 30, 700)
        gCreateRespFont("EVO_UI_X", "Roboto", 28, 500)
    end
end

-- Glyphes du lecteur dessinés (triangles lecture/précédent/suivant).
local function DrawTriangle(x, y, size, col, pointLeft)
    draw.NoTexture()
    surface.SetDrawColor(col)
    if pointLeft then
        surface.DrawPoly({
            { x = x + size, y = y },
            { x = x + size, y = y + size },
            { x = x,        y = y + size / 2 },
        })
    else
        surface.DrawPoly({
            { x = x,        y = y },
            { x = x + size, y = y + size / 2 },
            { x = x,        y = y + size },
        })
    end
end

-- État de lecture pour la barre de seek : station locale + durée + position.
-- Non interactif si pas de station valide, durée inconnue (stream) ou piste finie.
local function GetSeekState()
    local st = LZY_OST.ActiveStation
    if not IsValid(st) then return nil, 0, 0, false end
    local len = st:GetLength() or 0
    local cur = st:GetTime() or 0
    if len > 0 then cur = math.Clamp(cur, 0, len) end
    local interactive = len > 0 and st:GetState() ~= GMOD_CHANNEL_STOPPED
    return st, len, cur, interactive
end

-- Envoi réseau du seek, espacé de 0.25s (le serveur rate-limite EVO_OST_Action à
-- 0.2s : sans ça un double-clic rapide serait silencieusement ignoré -> désync
-- entre la position locale et le startTime serveur). Le dernier seek gagne.
local pendingSeekTime = nil
local lastSeekSend = 0
local function FlushSeekNet()
    if pendingSeekTime == nil then return end
    local t = pendingSeekTime
    pendingSeekTime = nil
    lastSeekSend = RealTime()
    net.Start("EVO_OST_Action")
        net.WriteString("seek")
        net.WriteTable({ time = t })
    net.SendToServer()
end
local function RequestSeekNet(t)
    pendingSeekTime = t
    local wait = (lastSeekSend + 0.25) - RealTime()
    if wait <= 0 then
        FlushSeekNet()
    else
        timer.Create("LZY_OST::SeekFlush", wait, 1, FlushSeekNet)
    end
end

function PANEL:Init()
    EnsureFonts()

    self:gSetSize(1920, 1080)
    self:gSetPos(0, 0)
    self:SetTitle("")
    self:SetDraggable(false)
    self:ShowCloseButton(false)
    self:MakePopup()
    if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end

    -- Clic dans le vide (hors carte) = fermeture, comme les autres menus EVO.
    -- La carte est DESSINÉE dans le Paint de la frame plein écran (pas un panel
    -- enfant) : on ne ferme donc que si le clic tombe hors de son rectangle.
    self.OnMousePressed = function(s)
        local mx, my = s:CursorPos()
        local cx, cy = gRespX(CARD_X), gRespY(CARD_Y)
        if mx < cx or mx > cx + gRespX(CARD_W) or my < cy or my > cy + gRespY(CARD_H) then
            s:Close()
        end
    end

    -- Fondu d'apparition de l'assombrissement (pattern evo_map / EVO_UI.Backdrop).
    self._a = 0

    -- Croix de fermeture : EXACTEMENT la même que squad/selector (user 06/07) —
    -- glyphe ✕, pas de fond au survol, gris -> accent.
    self.closeButton = vgui.Create("DButton", self)
    self.closeButton:gSetSize(38, 38)
    self.closeButton:gSetPos(CARD_X + CARD_W - 50, CARD_Y + 11)
    self.closeButton:SetText("")
    self.closeButton:SetMouseInputEnabled(true)
    self.closeButton:SetKeyboardInputEnabled(false)
    self.closeButton:SetCursor("hand")
    self.closeButton.Paint = function(selff, w, h)
        draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
            selff:IsHovered() and COL.accent or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.closeButton.DoClick = function()
        self:Close()
    end

    -- Barre de recherche (carte interne sombre, aucune bordure).
    self.searchBar = vgui.Create("DTextEntry", self)
    self.searchBar:gSetSize(310, 34)
    self.searchBar:gSetPos(CARD_X + CARD_W - 48 - 10 - 310, CARD_Y + 16)
    self.searchBar:SetText("")
    self.searchBar:SetFont("Avenir Next World:16")
    self.searchBar:SetPlaceholderText("Rechercher...")
    self.searchBar:SetDrawBackground(false)
    self.searchBar:SetDrawBorder(false)
    self.searchBar:SetTextColor(COL.title)
    self.searchBar:SetPlaceholderColor(COL.dim)
    self.searchBar:SetDrawLanguageID(false)
    self.searchBar.Paint = function(selff, w, h)
        RNDX.Draw(0, 0, 0, w, h, COL.sub)

        if selff:GetText() == "" and not selff:IsEditing() then
            draw.SimpleText(selff:GetPlaceholderText(), "Avenir Next World:16", gRespX(14), h / 2, COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(selff:GetText(), "Avenir Next World:16", gRespX(14), h / 2, COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    self.searchBar.OnTextChanged = function(selff)
        if IsValid(self) then
            self:CreateMusicList()
        end
    end

    -- Checkbox : masquer les sons © diffusés par les autres joueurs (défaut OFF).
    -- Placé à gauche de la recherche, même hauteur / style carte interne.
    self.muteCopyrightBtn = vgui.Create("DButton", self)
    self.muteCopyrightBtn:gSetSize(188, 34)
    self.muteCopyrightBtn:gSetPos(CARD_X + CARD_W - 48 - 10 - 310 - 10 - 188, CARD_Y + 16)
    self.muteCopyrightBtn:SetText("")
    self.muteCopyrightBtn:SetMouseInputEnabled(true)
    self.muteCopyrightBtn:SetKeyboardInputEnabled(false)
    self.muteCopyrightBtn:SetCursor("hand")
    local copyrightTip = "Masque les pistes © de la liste et des autres joueurs."
    self.muteCopyrightBtn:SetTooltip(copyrightTip)
    self.muteCopyrightBtn.strTooltipText = copyrightTip
    self.muteCopyrightBtn:SetTooltipPanelOverride("LZY_OST_DarkTooltip")
    self.muteCopyrightBtn.Paint = function(selff, w, h)
        local on = muteCopyrightOthers
        RNDX.Draw(0, 0, 0, w, h, on and COL.sub2 or (selff:IsHovered() and COL.sub2 or COL.sub))

        local box = gRespY(14)
        local bx, by = gRespX(10), math.floor((h - box) / 2)
        surface.SetDrawColor(on and COL.accent or COL.dim)
        surface.DrawOutlinedRect(bx, by, box, box, 1)
        if on then
            surface.SetDrawColor(COL.accent)
            surface.DrawRect(bx + 3, by + 3, box - 6, box - 6)
        end

        local tcol = on and COL.title or (selff:IsHovered() and COL.title or COL.muted)
        draw.SimpleText("MASQUER ©", "Bebas Neue:16", gRespX(10) + box + gRespX(8), h / 2, tcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    self.muteCopyrightBtn.DoClick = function()
        muteCopyrightOthers = not muteCopyrightOthers
        SaveSettings()
        StopMutedOtherCopyrightSounds()
        self:CreateMusicList()
    end

    self.current_category = 1
    self:CreateCategoriesButtons()

    self:CreateMusicList()
    self:CreatePlayedSoundArea()
end

-- Opacite du menu pendant qu'on regle la PORTEE. Le reglage dessine un cercle
-- d'apercu DANS LE MONDE (DebugRangePreview, sphere filaire), mais le menu est en
-- plein ecran : on ne voyait donc jamais ce qu'on etait en train de regler.
-- Tant que l'apercu est actif, le menu s'efface pour laisser voir la portee reelle,
-- puis revient tout seul. SetAlpha porte sur le panneau ET ses enfants.
local OST_ALPHA_APERCU = 40   -- 0 = invisible, 255 = opaque

function PANEL:Think()
    self._a = Lerp(FrameTime() * 12, self._a or 0, 255)

    local ap = LZY_OST.DebugRangePreview
    local bApercu = ap and (ap.untilTime or 0) > CurTime() and (ap.radius or 0) > 0
    self._aMenu = Lerp(FrameTime() * 10, self._aMenu or 255, bApercu and OST_ALPHA_APERCU or 255)
    self:SetAlpha(math.floor(self._aMenu))
end

function PANEL:Paint(w, h)
    -- Fond plein écran = mêmes appels que le spell selector (blur RNDX + voile),
    -- fondu conservé. (Remplace EVO_UI.DrawBlur : 4 captures écran/frame.)
    RNDX.Draw(0, 0, 0, w, h, COL_WHITE, RNDX.BLUR)
    local a = (self._a or 255) / 255
    surface.SetDrawColor(5, 5, 7, 216 * a)
    surface.DrawRect(0, 0, w, h)

    -- Plaque de métal noir Atelier : coins coupés 45° + liseré acier.
    local cx, cy = gRespX(CARD_X), gRespY(CARD_Y)
    local cw, ch = gRespX(CARD_W), gRespY(CARD_H)
    -- DA dashboard 08/07 : plaque plate, plus de lisere acier.
    EVO_UI.PaintCut(cx, cy, cw, ch, COL.card, gRespY(16))

    -- (Image fantôme RETIRÉE — user 06/07 : zangetsu réservée à l'UI instructeur.)

    -- Kanji 月 gravé (une passe claire ultra-légère, copie du #platekanji).
    draw.SimpleText("月", "EVO_UI_KanjiXL", cx + cw - gRespX(10), cy + ch - gRespY(4),
        Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)

    -- 4 vis d'angle (TR/BL décalées : coins coupés).
    local sr = gRespY(5)
    drawScrew(cx + gRespX(18), cy + gRespY(18), sr)
    drawScrew(cx + cw - gRespX(18), cy + gRespY(18), sr)
    drawScrew(cx + cw - gRespX(18), cy + ch - gRespY(18), sr)
    drawScrew(cx + gRespX(18), cy + ch - gRespY(18), sr)

    -- Titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
    draw.SimpleText("MENU OST", "Bebas Neue:30", cx + gRespX(PAD_X), cy + gRespY(33), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    surface.SetFont("Bebas Neue:30")
    local twT, thT = surface.GetTextSize("MENU OST")
    -- Titre CENTER-aligné à Y = cy+gRespY(33) : haut = c - th/2, slash = haut + th*0.78 = c + th*0.28.
    if not EVO_UI.Ink(EVO_UI.TexSlash, cx + gRespX(PAD_X - 2), cy + gRespY(33) + thT * 0.28, twT * 1.15, gRespY(9), ColorAlpha(COL.accent, 245)) then
        surface.SetDrawColor(COL.accent)
        surface.DrawRect(cx + gRespX(PAD_X), cy + gRespY(33) + thT * 0.34, twT, math.max(2, gRespY(3)))
    end
    drawDashes(cx + gRespX(PAD_X), cy + gRespY(62), cw - gRespX(PAD_X * 2), Color(255, 255, 255, 26))

    -- Bandeau "en lecture" (carte interne).
    RNDX.Draw(0, gRespX(CONTENT_X), gRespY(BAR_Y), gRespX(CONTENT_W), gRespY(BAR_H), COL.sub)

    -- Petits libellés des curseurs volume / portée.
    draw.SimpleText("VOLUME", "Bebas Neue:15", gRespX(1114), gRespY(794), COL.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("PORTÉE", "Bebas Neue:15", gRespX(1243), gRespY(794), COL.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    -- Musique en cours (depuis LZY_OST.StartTrack).
    local track = LZY_OST.StartTrack
    if not track then
        draw.SimpleText("AUCUNE MUSIQUE EN LECTURE", "Bebas Neue:22", gRespX(510), gRespY(810), COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        return
    end

    local cur = 0
    local len = track.nDuration or 0

    -- Fallback to cached duration if we have one for this path
    if (not len or len <= 0) and track.sPath and durationCache[track.sPath] then
        len = durationCache[track.sPath]
        track.nDuration = len
    end

    if IsValid(LZY_OST.ActiveStation) then
        local chan = LZY_OST.ActiveStation
        cur = math.floor(chan:GetTime() or 0)
        local chanLen = chan:GetLength() or 0
        if chanLen > 0 then
            len = math.floor(chanLen)
            track.nDuration = len
            -- N'écrire sur disque QUE si la durée a changé (sinon file.Write
            -- + sérialisation JSON à CHAQUE frame tant que le menu est ouvert).
            if track.sPath and durationCache[track.sPath] ~= len then
                durationCache[track.sPath] = len
                SaveDurations()
            end

            -- Also update the currently visible list entry so its duration updates live
            if self.currentCategoryMusicList then
                for _, music in ipairs(self.currentCategoryMusicList) do
                    if music.sName == track.sName then
                        music.nDuration = len
                        break
                    end
                end
            end
        end
    end
    if len > 0 then cur = math.Clamp(cur, 0, len) end

    -- Pochette + nom de la piste.
    local mat = GetIconMaterial(track.sMats)
    RNDX.DrawMaterial(gRespY(8), gRespX(442), gRespY(782), gRespX(56), gRespY(56), COL_WHITE, mat)
    -- 345 (et non plus 370) : laisse la place au bouton Aléatoire, posé en x = 866.
    draw.SimpleText(self:LimitTextWidth(track.sName or "", gRespX(345), "Bebas Neue:25"), "Bebas Neue:25", gRespX(510), gRespY(792), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    -- Temps écoulé / durée totale (m:ss) autour de la barre de seek.
    -- Pendant un drag : on affiche la position FANTÔME (accent) au lieu du temps réel.
    local shownCur, curCol = cur, COL.muted
    if IsValid(self.seekBar) and self.seekBar._dragging and len > 0 then
        shownCur = math.floor(self.seekBar._ghostFrac * len)
        curCol = COL.accent
    end
    draw.SimpleText(self:ConvertTimeToText(shownCur), "Bebas Neue:18", gRespX(558), gRespY(828), curCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    draw.SimpleText(self:ConvertTimeToText(len), "Bebas Neue:18", gRespX(824), gRespY(828), COL.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

function PANEL:OnClose()
    frame = nil
    self:Remove()
    timer.Simple(0.1, function() can_open = true end)
end

function PANEL:OnKeyCodePressed(keycode)
	-- Toggle : rappuyer sur la MEME touche qui ouvre le menu le ferme. On resout la vraie touche
	-- (bind ost_menu du joueur) au lieu du F4 code en dur -> marche quel que soit le bind (meme
	-- wantKey que le serveur). (Le HOME reserve au tampon a saute avec l'arene FFA, 08/27.)
	local lp = LocalPlayer()
	local wantKey = (IsValid(lp) and lp.GetBindKey and lp:GetBindKey("ost_menu")) or KEY_F4
	if keycode == wantKey and can_open == false then
		self:Close()
	end
end

function PANEL:ConvertTimeToText(nTime)
    nTime = math.max(0, tonumber(nTime) or 0)
    local nMinutes = math.floor(nTime / 60)
    local nSeconds = math.floor(nTime % 60)
    return string.format("%d:%02d", nMinutes, nSeconds)
end

function PANEL:LimitTextWidth(sText, nWidth, sFont)
    surface.SetFont(sFont or "Avenir Next World:17")
    local nTextWidth = surface.GetTextSize(sText)

    if nTextWidth > nWidth then
        local nMaxChars = math.floor(nWidth / nTextWidth * #sText)
        if nMaxChars <= 3 then
            return "..."
        end

        local sTrimmed = string.sub(sText, 1, nMaxChars - 3)
        return sTrimmed .. "..."
    end
    return sText
end

function PANEL:CreateCategoriesButtons()
    local categories = LZY_OST.Config.Categories or {}
    local count = #categories

    local gap = 8

    -- RESPONSIVE : toutes les catégories tiennent dans la largeur de contenu de la
    -- carte (CONTENT_W), plafonnées à 200 quand il y en a peu (sinon énormes).
    local btnWidth = (count > 0) and math.min(200, (CONTENT_W - (count - 1) * gap) / count) or 200

    self.categoryButtons = self.categoryButtons or {}

    for i, categoryName in ipairs(categories) do
        local btn = vgui.Create("DButton", self)
        btn:gSetSize(btnWidth, CAT_H)

        local x = CONTENT_X + (i - 1) * (btnWidth + gap)
        btn:gSetPos(x, CAT_Y)

        btn:SetText("")
        btn:SetMouseInputEnabled(true)
        btn:SetKeyboardInputEnabled(false)

        btn.Paint = function(selff, w, h)
            local active = (self.current_category == i)
            local bg = active and COL.accent or (selff:IsHovered() and COL.sub2 or COL.sub)
            RNDX.Draw(0, 0, 0, w, h, bg)

            local tcol = active and COL_WHITE or (selff:IsHovered() and COL.title or COL.muted)
            draw.SimpleText(categoryName, "Bebas Neue:22", w / 2, h / 2, tcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        btn.DoClick = function()
            self.current_category = i
            self:CreateMusicList()
        end

        self.categoryButtons[i] = btn
    end
end

function PANEL:CreateMusicList()
    -- Build current list from global config based on category/search/favorites
    self.currentCategoryMusicList = {}

    local categories = LZY_OST.Config.Categories or {}
    local currentCatName = categories[self.current_category] or categories[1] or "Epique"
    local filter = string.lower(self.searchBar:GetText() or "")

    local btnHeight = 64
    local gapY = 8

    -- Create / reuse scroll panel for the music list
    if not IsValid(self.musicScroll) then
        self.musicScroll = vgui.Create("DScrollPanel", self)
        self.musicScroll:gSetSize(CONTENT_W, LIST_H)
        self.musicScroll:gSetPos(CONTENT_X, LIST_Y)

        local vbar = self.musicScroll:GetVBar()
        vbar:SetWide(4)

        vbar.Paint = function() end
        vbar.btnUp.Paint = function() end
        vbar.btnDown.Paint = function() end

        vbar.btnGrip.Paint = function(selff, w, h)
            RNDX.Draw(0, 0, 0, w, h, COL.grip)
        end
    end

    -- Filter sounds
    for _, v in ipairs(LZY_OST.Config.Sounds or {}) do
        if muteCopyrightOthers and v.bCopyright then goto CONTINUE end

        if currentCatName == "Favoris" then
            if not IsFavorite(v.sName) then goto CONTINUE end
        elseif v.sCategory ~= currentCatName then
            goto CONTINUE
        end

        if filter ~= "" and not string.find(string.lower(v.sName), filter, 1, true) then
            goto CONTINUE
        end

        -- Try to use cached duration first, then any value already on the config entry
        local dur = 0
        if durationCache[v.sPath] then
            dur = durationCache[v.sPath]
        else
            dur = v.nDuration or 0
        end

        -- If this is the currently playing track and we have a live channel, refresh the duration
        if LZY_OST.StartTrack and LZY_OST.StartTrack.sName == v.sName and IsValid(LZY_OST.ActiveStation) then
            local len = LZY_OST.ActiveStation:GetLength() or dur
            if len > 0 then
                dur = math.floor(len)
                v.nDuration = dur
                durationCache[v.sPath] = dur
                SaveDurations()
            end
        end

        table.insert(self.currentCategoryMusicList, {
            sName = v.sName,
            sPath = v.sPath,
            nDuration = dur,
            nCurrentTime = 0,
            sMaterial = v.sMats or "lzy_ost/icon_music_1.png",
            bIsPlaying = false,
        })

        ::CONTINUE::
    end

    self.musicButtons = self.musicButtons or {}

    -- Clear previous buttons if any
    for _, btn in ipairs(self.musicButtons) do
        if IsValid(btn) then
            btn:Remove()
        end
    end
    self.musicButtons = {}

    for i, music in ipairs(self.currentCategoryMusicList) do
        local btn = vgui.Create("DButton", self.musicScroll)
        btn:Dock(TOP)
        btn:DockMargin(0, i == 1 and 0 or gapY, 8, 0)
        btn:SetTall(gRespY(btnHeight))

        btn:SetText("")
        btn:SetMouseInputEnabled(true)
        btn:SetKeyboardInputEnabled(false)

        btn.Paint = function(selff, w, h)
            local isActive = false
            if LZY_OST.StartTrack and LZY_OST.StartTrack.sName == music.sName and IsValid(LZY_OST.ActiveStation) then
                isActive = true
            end

            -- Carte interne : sombre, hover légèrement plus clair, AUCUNE bordure.
            RNDX.Draw(0, 0, 0, w, h, selff:IsHovered() and COL.sub2 or COL.sub)
            if isActive then
                -- Piste en lecture : teinte + liseré accent (DA sélection = rouge).
                RNDX.Draw(0, 0, 0, w, h, COL.accentSoft)
                surface.SetDrawColor(COL.accent)
                surface.DrawRect(0, gRespY(12), gRespX(3), h - gRespY(24))
            end

            -- Pochette (gauche)
            RNDX.DrawMaterial(gRespY(6), gRespX(8), gRespY(8), gRespY(48), gRespY(48), COL_WHITE, GetIconMaterial(music.sMaterial))

            -- Nom de la musique
            local displayName = self:LimitTextWidth(music.sName, w * 0.6, "Bebas Neue:24")
            draw.SimpleText(displayName, "Bebas Neue:24", gRespX(70), h / 2, isActive and COL.title or (selff:IsHovered() and COL.title or COL.muted), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            -- Durée (droite, position FIXE — ne saute plus au survol)
            local totalSeconds = music.nDuration or 0
            if isActive then
                totalSeconds = math.floor(LZY_OST.ActiveStation:GetLength() or totalSeconds)
            end
            draw.SimpleText(self:ConvertTimeToText(totalSeconds), "Bebas Neue:18", w - gRespX(92), h / 2, COL.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

            -- Étoile de favori (emplacement fixe : visible si favori ou au survol)
            local isFav = IsFavorite(music.sName)
            if isFav or selff:IsHovered() then
                local favSize = gRespX(18)
                RNDX.DrawMaterial(0, w - gRespX(74), (h - favSize) / 2, favSize, favSize, isFav and COL.gold or COL.faded, matFavorite)
            end

            -- Triangle lecture (au survol uniquement)
            if selff:IsHovered() then
                local ps = gRespY(16)
                DrawTriangle(w - gRespX(38), (h - ps) / 2, ps, COL.title, false)
            end
        end

        btn.DoClick = function(selff)
            if not self.currentCategoryMusicList then return end

            -- Clic sur l'étoile de favori ? (même emplacement fixe que le Paint, + marge)
            local mx, my = selff:LocalCursorPos()
            local favSize = gRespX(18)
            local favX = selff:GetWide() - gRespX(74)
            local favY = (selff:GetTall() - favSize) / 2
            local pad = gRespX(5)

            if mx >= favX - pad and mx <= favX + favSize + pad and my >= favY - pad and my <= favY + favSize + pad then
                ToggleFavorite(music.sName)
                return
            end

            -- Otherwise, play the track
            self:PlayMusicAtIndex(i)
        end

        self.musicButtons[i] = btn
    end
end

-- Helper to find the index of the currently playing track in the visible list
function PANEL:FindCurrentTrackIndex()
    if not LZY_OST.StartTrack or not self.currentCategoryMusicList then return nil end

    local currentName = LZY_OST.StartTrack.sName
    if not currentName then return nil end

    for i, music in ipairs(self.currentCategoryMusicList) do
        if music.sName == currentName then
            return i
        end
    end

    return nil
end

-- Helper to play a track by its index in the visible list
function PANEL:PlayMusicAtIndex(idx)
    if not self.currentCategoryMusicList or #self.currentCategoryMusicList == 0 then return end

    idx = math.Clamp(idx, 1, #self.currentCategoryMusicList)
    local music = self.currentCategoryMusicList[idx]
    if not music then return end

    -- Find real config entry for path/icon
    local soundData
    for _, v in ipairs(LZY_OST.Config.Sounds or {}) do
        if v.sName == music.sName then
            soundData = v
            break
        end
    end
    if not soundData then return end

    -- La liste affichee devient la file : Suivant / Precedent et le mode liste la
    -- parcourent, meme si le menu est ferme ou montre ensuite une autre categorie.
    local paths = {}
    for _, m in ipairs(self.currentCategoryMusicList) do
        if m.sPath then paths[#paths + 1] = m.sPath end
    end
    BuildQueue(paths, soundData.sPath)

    SendPlayTrack(soundData)
end

function PANEL:CreatePlayedSoundArea()
    -- Bouton Précédent (glyphe dessiné)
    self.previousButton = vgui.Create("DButton", self)
    self.previousButton:gSetSize(30, 30)
    self.previousButton:gSetPos(896, 795)
    self.previousButton:SetText("")
    self.previousButton:SetMouseInputEnabled(true)
    self.previousButton:SetKeyboardInputEnabled(false)
    self.previousButton.Paint = function(selff, w, h)
        local col = selff:IsHovered() and COL.title or COL.muted
        local gs = gRespY(14)
        local gy = math.floor((h - gs) / 2)
        surface.SetDrawColor(col)
        surface.DrawRect(math.floor(w / 2) - gRespX(9), gy, gRespX(3), gs)
        DrawTriangle(math.floor(w / 2) - gRespX(4), gy, gs, col, true)
    end
    self.previousButton.DoClick = function()
        -- File de lecture d abord (respecte l aleatoire, et la liste lancee meme si le
        -- menu montre maintenant une autre categorie). Sans file : la liste visible.
        if #playQueue.order > 0 and PlayQueueStep(-1) then return end
        if not self.currentCategoryMusicList or #self.currentCategoryMusicList == 0 then return end

        local currentIndex = self:FindCurrentTrackIndex() or 1
        local newIndex = currentIndex - 1
        if newIndex < 1 then
            newIndex = #self.currentCategoryMusicList
        end

        self:PlayMusicAtIndex(newIndex)
    end

    -- Bouton Lecture/Pause (cercle accent, glyphe dessiné)
    self.playButton = vgui.Create("DButton", self)
    self.playButton:gSetSize(42, 42)
    self.playButton:gSetPos(938, 789)
    self.playButton:SetText("")
    self.playButton:SetMouseInputEnabled(true)
    self.playButton:SetKeyboardInputEnabled(false)
    self.playButton.Paint = function(selff, w, h)
        -- When music is actively playing, show pause; when stopped or paused, show play
        local isPlaying = false
        local myData = LZY_OST.ClientActiveSounds[LocalPlayer()]
        if myData and not myData.isPaused and IsValid(LZY_OST.ActiveStation) and LZY_OST.ActiveStation:GetState() == GMOD_CHANNEL_PLAYING then
            isPlaying = true
        end

        RNDX.Draw(w, 0, 0, w, h, selff:IsHovered() and COL.accentHover or COL.accent)

        if isPlaying then
            local bw, bh = gRespX(4), gRespY(14)
            local by = math.floor((h - bh) / 2)
            surface.SetDrawColor(COL_WHITE)
            surface.DrawRect(math.floor(w / 2) - gRespX(6), by, bw, bh)
            surface.DrawRect(math.floor(w / 2) + gRespX(2), by, bw, bh)
        else
            local gs = gRespY(14)
            DrawTriangle(math.floor(w / 2) - gRespX(4), math.floor((h - gs) / 2), gs, COL_WHITE, false)
        end
    end
    self.playButton.DoClick = function()
        if LZY_OST.ClientActiveSounds[LocalPlayer()] then
            net.Start("EVO_OST_Action")
                net.WriteString("pause")
                net.WriteTable({})
            net.SendToServer()
        end
    end

    -- Bouton Suivant (glyphe dessiné)
    self.nextButton = vgui.Create("DButton", self)
    self.nextButton:gSetSize(30, 30)
    self.nextButton:gSetPos(992, 795)
    self.nextButton:SetText("")
    self.nextButton:SetMouseInputEnabled(true)
    self.nextButton:SetKeyboardInputEnabled(false)
    self.nextButton.Paint = function(selff, w, h)
        local col = selff:IsHovered() and COL.title or COL.muted
        local gs = gRespY(14)
        local gy = math.floor((h - gs) / 2)
        DrawTriangle(math.floor(w / 2) - gRespX(10), gy, gs, col, false)
        surface.SetDrawColor(col)
        surface.DrawRect(math.floor(w / 2) + gRespX(6), gy, gRespX(3), gs)
    end
    self.nextButton.DoClick = function()
        if #playQueue.order > 0 and PlayQueueStep(1) then return end
        if not self.currentCategoryMusicList or #self.currentCategoryMusicList == 0 then return end

        local currentIndex = self:FindCurrentTrackIndex() or 1
        local newIndex = currentIndex + 1
        if newIndex > #self.currentCategoryMusicList then
            newIndex = 1
        end

        self:PlayMusicAtIndex(newIndex)
    end

    -- Bouton Aleatoire : deux fleches croisees, accent quand actif. Melange la file en
    -- cours (la piste qui joue reste la courante) et les suivantes.
    local shuffleTip = "Lecture aléatoire de la liste."
    self.shuffleButton = vgui.Create("DButton", self)
    self.shuffleButton:gSetSize(26, 26)
    self.shuffleButton:gSetPos(866, 797)
    self.shuffleButton:SetText("")
    self.shuffleButton:SetMouseInputEnabled(true)
    self.shuffleButton:SetKeyboardInputEnabled(false)
    self.shuffleButton:SetCursor("hand")
    self.shuffleButton:SetTooltip(shuffleTip)
    self.shuffleButton.strTooltipText = shuffleTip
    self.shuffleButton:SetTooltipPanelOverride("LZY_OST_DarkTooltip")
    self.shuffleButton.Paint = function(selff, w, h)
        local col = shuffleEnabled and COL.accent or (selff:IsHovered() and COL.title or COL.muted)
        local x0, x1 = gRespX(5), w - gRespX(10)
        local y0, y1 = gRespY(8), h - gRespY(8)
        local hs = gRespY(7)
        surface.SetDrawColor(col)
        -- Deux traits croises, doubles d un pixel pour l epaisseur.
        for o = 0, 1 do
            surface.DrawLine(x0, y0 + o, x1, y1 + o)
            surface.DrawLine(x0, y1 + o, x1, y0 + o)
        end
        DrawTriangle(x1, y0 - hs / 2, hs, col, false)
        DrawTriangle(x1, y1 - hs / 2, hs, col, false)
    end
    self.shuffleButton.DoClick = function()
        shuffleEnabled = not shuffleEnabled
        SaveSettings()
        -- Refait l ordre de la file autour de la piste courante.
        if #playQueue.order > 0 then
            BuildOrder(playQueue.order[playQueue.pos] or 1)
        end
    end

    -- Bouton Repetition, 3 etats (cf. repeatMode) : off (gris), repeter la piste (accent
    -- + « 1 » au centre), enchainer la liste (accent). Le reglage est global au menu (pas
    -- par piste) : il s applique a la lecture en cours ET a toutes les suivantes, comme
    -- le bouton repeat d un lecteur.
    local REPEAT_NEXT = { off = "one", one = "list", list = "off" }
    local REPEAT_TIPS = {
        off  = "Répétition désactivée : la musique s'arrête à la fin.",
        one  = "Répète la musique en boucle.",
        list = "Enchaîne la liste affichée en boucle (catégorie, Favoris ou recherche).",
    }
    self.repeatButton = vgui.Create("DButton", self)
    self.repeatButton:gSetSize(26, 26)
    self.repeatButton:gSetPos(1024, 797)
    self.repeatButton:SetText("")
    self.repeatButton:SetMouseInputEnabled(true)
    self.repeatButton:SetKeyboardInputEnabled(false)
    self.repeatButton:SetCursor("hand")
    self.repeatButton:SetTooltip(REPEAT_TIPS[repeatMode])
    self.repeatButton.strTooltipText = REPEAT_TIPS[repeatMode]
    self.repeatButton:SetTooltipPanelOverride("LZY_OST_DarkTooltip")
    self.repeatButton.Paint = function(selff, w, h)
        local col = repeatMode ~= "off" and COL.accent or (selff:IsHovered() and COL.title or COL.muted)
        local cx, cy = w / 2, h / 2
        local r = gRespY(9)
        -- Anneau : disque plein puis disque de la couleur du bandeau au centre.
        drawCircle(cx, cy, r, col)
        drawCircle(cx, cy, r - math.max(2, gRespY(3)), COL.sub)
        -- Fleche : sans elle l anneau se lit comme une simple pastille.
        DrawTriangle(cx + gRespX(2), cy - r - gRespY(3), gRespY(9), col, false)
        if repeatMode == "one" then
            draw.SimpleText("1", "Bebas Neue:15", cx, cy, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    self.repeatButton.DoClick = function(selff)
        repeatMode = REPEAT_NEXT[repeatMode] or "off"
        SaveSettings()
        selff:SetTooltip(REPEAT_TIPS[repeatMode])
        selff.strTooltipText = REPEAT_TIPS[repeatMode]

        local loop = repeatMode == "one"

        -- Effet immediat sur la piste en cours, sinon il faudrait la relancer.
        local mine = LZY_OST.ClientActiveSounds[LocalPlayer()]
        if mine and mine.loop ~= loop then
            mine.loop = loop
            ApplyLoop(mine.station, mine)
            -- Repetition coupee apres plusieurs tours : on ramene le depart dans le tour
            -- en cours, comme le fait le serveur. Sinon, en attendant sa reponse, le mode
            -- liste croirait la piste finie et passerait aussitot a la suivante.
            local len = durationCache[mine.path] or 0
            if not loop and not mine.isPaused and len > 0 then
                local el = CurTime() - (mine.startTime or CurTime())
                if el > len then mine.startTime = CurTime() - (el % len) end
            end
        end

        -- Le serveur retient l etat pour les auditeurs en zone et pour les flux
        -- recrees plus tard (entree dans la portee, resynchro).
        net.Start("EVO_OST_Action")
            net.WriteString("loop")
            net.WriteTable({ loop = loop })
        net.SendToServer()
    end

    -- ── Barre de progression / SEEK ──────────────────────────────────────────
    -- Cliquable et draggable : pendant le drag on affiche une position FANTÔME
    -- (aucun SetTime), au relâchement on applique localement (feedback immédiat)
    -- + on envoie l'action "seek" au serveur (déjà supportée) pour recaler son
    -- startTime -> les auditeurs en zone et les streams recréés restent synchro.
    -- Grisée/non interactive si pas de station, durée inconnue ou piste finie.
    self.seekBar = vgui.Create("DPanel", self)
    self.seekBar:gSetSize(250, 20)
    self.seekBar:gSetPos(566, 818)
    self.seekBar:SetMouseInputEnabled(true)
    self.seekBar:SetKeyboardInputEnabled(false)
    self.seekBar._dragging = false
    self.seekBar._ghostFrac = 0

    -- netgate: edge -- `_dragging` latches false here, so one seek per drag
    local function CommitSeek(selff)
        if not selff._dragging then return end
        selff._dragging = false
        selff:MouseCapture(false)

        local st, len, _, interactive = GetSeekState()
        if not (st and interactive) then return end

        -- Légère marge avant la toute fin : seek pile sur GetLength() = piste
        -- instantanément terminée (état STOPPED), ce qui fige les contrôles.
        local t = math.Clamp(selff._ghostFrac * len, 0, math.max(len - 0.25, 0))
        st:SetTime(t)
        RequestSeekNet(t)
    end

    self.seekBar.OnMousePressed = function(selff, code)
        if code ~= MOUSE_LEFT then return end
        local _, _, _, interactive = GetSeekState()
        if not interactive then return end

        selff._dragging = true
        selff:MouseCapture(true)
        local mx = selff:CursorPos()
        selff._ghostFrac = math.Clamp(mx / math.max(selff:GetWide(), 1), 0, 1)
    end
    self.seekBar.OnCursorMoved = function(selff, mx)
        if selff._dragging then
            selff._ghostFrac = math.Clamp(mx / math.max(selff:GetWide(), 1), 0, 1)
        end
    end
    self.seekBar.OnMouseReleased = function(selff, code)
        if code == MOUSE_LEFT then CommitSeek(selff) end
    end
    self.seekBar.Think = function(selff)
        -- Filet : si le relâchement se perd (souris hors capture), on applique.
        if selff._dragging and not input.IsMouseDown(MOUSE_LEFT) then
            CommitSeek(selff)
        end
    end
    self.seekBar.Paint = function(selff, w, h)
        local _, len, cur, interactive = GetSeekState()
        local trackH = gRespY(5)
        local ty = math.floor((h - trackH) / 2)

        RNDX.Draw(trackH, 0, ty, w, trackH, COL.track)

        if not interactive then
            -- Piste finie : remplissage terne figé. Stream sans durée / rien en
            -- lecture : juste le fond, pas de curseur.
            if len > 0 and cur > 0 then
                RNDX.Draw(trackH, 0, ty, w * math.Clamp(cur / len, 0, 1), trackH, COL.trackDim)
            end
            return
        end

        local frac = selff._dragging and selff._ghostFrac or (cur / len)
        frac = math.Clamp(frac, 0, 1)
        if frac > 0 then
            RNDX.Draw(trackH, 0, ty, w * frac, trackH, COL.accent)
        end

        -- Curseur rond au bout du remplissage (grossit au survol/drag).
        local kr = (selff:IsHovered() or selff._dragging) and gRespY(6) or gRespY(5)
        local kx = math.Clamp(w * frac - kr, 0, w - kr * 2)
        RNDX.Draw(kr * 2, kx, math.floor(h / 2) - kr, kr * 2, kr * 2, selff._dragging and COL.accentHover or COL.title)
    end

    -- Toggle diffusion : MOI (privé) / ZONE / SERVEUR (superadmin + Gérant RP).
    -- SERVEUR couvre toute la carte et prime sur les autres lectures.
    self.onlyForMeButton = vgui.Create("DButton", self)
    self.onlyForMeButton:gSetSize(180, 30)
    self.onlyForMeButton:gSetPos(1298, 795)
    self.onlyForMeButton:SetText("")
    self.onlyForMeButton:SetMouseInputEnabled(true)
    self.onlyForMeButton:SetKeyboardInputEnabled(false)
    local diffuseTip = LZY_OST.CanServer
        and "MOI : toi seul. ZONE : autour de toi. SERVEUR : tout le serveur, remplace les autres OST."
        or "MOI : toi seul. ZONE : autour de toi."
    self.onlyForMeButton:SetTooltip(diffuseTip)
    self.onlyForMeButton.strTooltipText = diffuseTip
    self.onlyForMeButton:SetTooltipPanelOverride("LZY_OST_DarkTooltip")
    self.onlyForMeButton.Paint = function(selff, w, h)
        -- CanZone (07/26) : le bouton MOI/ZONE se débloque pour TOUT joueur autorisé à
        -- diffuser (staff, whitelist, palier niveau, palier GRADE) — plus seulement le staff.
        local canZone = LZY_OST.CanZone
        local canServer = LZY_OST.CanServer == true
        local serverMode = serverBroadcast and canServer
        local zone = (not onlyForMeEnabled) and not serverMode
        local canToggle = canZone or canServer
        local bg, label, tcol
        if serverMode then
            bg = COL.gold
            label = "DIFFUSION : SERVEUR"
            tcol = COL.goldInk
        elseif zone then
            bg = COL.accent
            label = "DIFFUSION : ZONE"
            tcol = COL_WHITE
        else
            bg = (selff:IsHovered() and canToggle) and COL.hover or COL.sub2
            label = "DIFFUSION : MOI"
            tcol = canToggle and COL.muted or COL.dim
        end
        RNDX.Draw(0, 0, 0, w, h, bg)
        draw.SimpleText(label, "Bebas Neue:15", w / 2, h / 2, tcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.onlyForMeButton.DoClick = function()
        local canZone = LZY_OST.CanZone == true
        local canServer = LZY_OST.CanServer == true
        if not canZone and not canServer then
            onlyForMeEnabled = true
            serverBroadcast = false
            return
        end

        -- MOI → ZONE (si droit) → SERVEUR (si droit) → MOI.
        if serverBroadcast and canServer then
            serverBroadcast = false
            onlyForMeEnabled = true
            return
        end
        if not onlyForMeEnabled then
            if canServer then
                serverBroadcast = true
                onlyForMeEnabled = false
            else
                onlyForMeEnabled = true
            end
            return
        end
        if canZone then
            onlyForMeEnabled = false
            serverBroadcast = false
        else
            serverBroadcast = true
            onlyForMeEnabled = false
        end
    end

    -- Volume Slider (barre fine, remplissage accent + curseur rond)
    self.volumeSlider = vgui.Create("DSlider", self)
    self.volumeSlider:gSetSize(120, 18)
    self.volumeSlider:gSetPos(1054, 806)
    self.volumeSlider:SetMouseInputEnabled(true)
    self.volumeSlider:SetKeyboardInputEnabled(false)
    self.volumeSlider:SetLockY(0.5)
    self.volumeSlider:SetTrapInside(true)
    -- Initialize slider position from current global volume (persists across UI reopen)
    self.volumeSlider:SetSlideX(math.Clamp((volume or 50) / 100, 0, 1))
    -- Hide the knob so it looks like a pure progress bar
    if IsValid(self.volumeSlider.Knob) then
        self.volumeSlider.Knob:SetVisible(false)
        self.volumeSlider.Knob.Paint = function() end
    end
    self.volumeSlider.Paint = function(selff, w, h)
        local trackH = gRespY(5)
        local ty = math.floor((h - trackH) / 2)
        RNDX.Draw(trackH, 0, ty, w, trackH, COL.track)

        local frac = math.Clamp(selff:GetSlideX(), 0, 1)
        if frac > 0 then
            RNDX.Draw(trackH, 0, ty, w * frac, trackH, COL.accent)
        end

        local kr = gRespY(5)
        local kx = math.Clamp(w * frac - kr, 0, w - kr * 2)
        RNDX.Draw(kr * 2, kx, math.floor(h / 2) - kr, kr * 2, kr * 2, COL.title)
    end
    self.volumeSlider.OnValueChanged = function(selff, value)
        -- value is 0-1
        volume = math.Clamp(value * 100, 0, 100)
        local sd = LZY_OST.ClientActiveSounds and LZY_OST.ClientActiveSounds[LocalPlayer()]
        if IsValid(LZY_OST.ActiveStation) and not (sd and sd.extVol) then -- extVol : volume piloté ailleurs
            LZY_OST.ActiveStation:SetVolume(volume / 100)
        end
    end

    -- Range Slider (grisé visuellement en mode "pour moi", reste fonctionnel)
    self.rangeSlider = vgui.Create("DSlider", self)
    self.rangeSlider:gSetSize(90, 18)
    self.rangeSlider:gSetPos(1198, 806)
    self.rangeSlider:SetMouseInputEnabled(true)
    self.rangeSlider:SetKeyboardInputEnabled(false)
    self.rangeSlider:SetLockY(0.5)
    self.rangeSlider:SetTrapInside(true)
    -- Initialize from global rangeValue so it persists across UI reopen
    self.rangeSlider:SetSlideX(rangeValue)
    if IsValid(self.rangeSlider.Knob) then
        self.rangeSlider.Knob:SetVisible(false)
        self.rangeSlider.Knob.Paint = function() end
    end
    self.rangeSlider.Paint = function(selff, w, h)
        local trackH = gRespY(5)
        local ty = math.floor((h - trackH) / 2)
        RNDX.Draw(trackH, 0, ty, w, trackH, COL.track)

        local frac = math.Clamp(selff:GetSlideX(), 0, 1)
        local zoneMode = (not onlyForMeEnabled) and not (serverBroadcast and LZY_OST.CanServer)
        local fillCol = zoneMode and COL.accent or COL.trackDim
        if frac > 0 then
            RNDX.Draw(trackH, 0, ty, w * frac, trackH, fillCol)
        end

        local kr = gRespY(5)
        local kx = math.Clamp(w * frac - kr, 0, w - kr * 2)
        RNDX.Draw(kr * 2, kx, math.floor(h / 2) - kr, kr * 2, kr * 2, zoneMode and COL.title or COL.dim)
    end
    self.rangeSlider.OnValueChanged = function(selff, value)
        -- Persist 0-1 range fraction; server will clamp to allowed range per player
        rangeValue = math.Clamp(value or 0, 0, 1)

        -- La portée ne s'applique qu'en diffusion ZONE.
        if onlyForMeEnabled or (serverBroadcast and LZY_OST.CanServer) then return end

        -- Setup a short-lived debug sphere preview around the local player
        local maxRange = LZY_OST.Config.DefaultLevelRange or 500
        local minRange = 100
        local r = math.floor(rangeValue * maxRange)
        if r < minRange then r = minRange end
        LZY_OST.DebugRangePreview.radius = r
        LZY_OST.DebugRangePreview.untilTime = CurTime() + 2
    end
end

vgui.Register("lzy_ost", PANEL, "DFrame")

-- Update "now playing" info when network tells us about a new track
UpdatePlayerUI = function()
    -- UI reads directly from LZY_OST.StartTrack in Paint; nothing to do here
end

function OpenOSTMenu()
	if IsValid(frame) then
		frame:Close()
	else
		frame = vgui.Create("lzy_ost")
		can_open = false
	end
end

net.Receive("EVO::OpenPanelOst", function()
    if can_open == false then return end
    local canCustomize = net.ReadBool()
    local maxRange = net.ReadFloat()
    local canWorld = net.ReadBool()
    -- (07/26) 4e champ : « peut diffuser en Zone » (paliers grade/niveau inclus). Un vieux
    -- serveur ne l'envoie pas -> ReadBool rend false -> on retombe sur canCustomize (ancien
    -- comportement : Zone réservée au staff).
    local canZone = net.ReadBool() or canCustomize
    local canServer = net.ReadBool()

    LZY_OST.CanCustomize = canCustomize
    LZY_OST.CanWorld = canWorld
    LZY_OST.CanZone = canZone
    LZY_OST.CanServer = canServer

    -- If server provides a per-player max range, use it as the client default
    if maxRange and maxRange > 0 then
        LZY_OST.Config = LZY_OST.Config or {}
        LZY_OST.Config.DefaultLevelRange = maxRange
    end

    -- Sans droit de diffusion Zone, « pour moi seul » démarre activé.
    -- SERVEUR reste disponible pour superadmin / Gérant RP même sans la zone.
    if not LZY_OST.CanServer then
        serverBroadcast = false
    end
    if not LZY_OST.CanZone and not (serverBroadcast and LZY_OST.CanServer) then
        onlyForMeEnabled = true
    end

    OpenOSTMenu()
end)

net.Receive("EVO_OST_Sync", function()
    local action = net.ReadString()

    if action == "batch" then
        local batchData = net.ReadTable()
        for _, item in pairs(batchData) do
            local ply = item.owner
            local d = item.data
            if IsValid(ply) and d then
                PlayLocal(ply, d.sPath, d.volume, d.isArea, d.range, d.isWorld, d.startTime, d.pausedAt, d.isPaused, d.loop, d.prio, d.isServer)
            end
        end
        return
    end

    local d = net.ReadTable()
    local ply = d.owner
    if not IsValid(ply) then return end

    if action == "play" then
        PlayLocal(ply, d.sPath, d.volume, d.isArea, d.range, d.isWorld, d.startTime, d.pausedAt, d.isPaused, d.loop, d.prio, d.isServer)

    elseif action == "loop" then
        -- Le diffuseur a change le mode boucle en cours de lecture : on l applique
        -- au flux deja cree, sans le relancer (pas de coupure).
        local data = LZY_OST.ClientActiveSounds[ply]
        if data then
            data.loop = d.loop == true
            -- Repetition coupee : le serveur a ramene le depart dans le tour en cours.
            if d.startTime then data.startTime = d.startTime end
            ApplyLoop(data.station, data)
        end

    elseif action == "stop" then
        local data = LZY_OST.ClientActiveSounds[ply]
        -- Le serveur retire ma piste a sa fin (endsAt + 1 s). Normalement le mode liste a
        -- deja enchaine avant ; si ce n est pas le cas (client en retard), on enchaine ici.
        -- Un stop pour une autre raison vide la file.
        -- Fin jugee sur le temps, comme le serveur : mon canal peut etre a quelques
        -- dixiemes de la fin quand le stop arrive.
        local advance = false
        if ply == LocalPlayer() and not playQueue.pending then
            local len = data and durationCache[data.path] or 0
            advance = repeatMode == "list" and #playQueue.order >= 2 and data ~= nil
                and not data.isPaused and not data.loop and len > 0
                and CurTime() - (data.startTime or CurTime()) >= len - 1.5
                and SyncQueueTo(data.path)
            if not advance then ClearQueue() end
        end
        if data then
            if IsValid(data.station) then data.station:Stop() end
        end
        LZY_OST.ClientActiveSounds[ply] = nil

        if ply == LocalPlayer() then
            LZY_OST.ActiveStation = nil
            LZY_OST.StartTrack = nil
            if UpdatePlayerUI then UpdatePlayerUI() end
            if advance then PlayQueueStep(1) end
        end

    elseif action == "pause" then
        local paused = d.isPaused
        local timestamp = d.timestamp

        local data = LZY_OST.ClientActiveSounds[ply]
        if data then
            data.isPaused = paused
            if paused then
                data.pausedAt = timestamp
            else
                data.startTime = timestamp
                data.pausedAt = 0
            end

            if IsValid(data.station) then
                if paused then
                    data.station:SetTime(WrapTime(data.station, data, data.pausedAt))
                    data.station:Pause()
                else
                    data.station:SetTime(ElapsedFor(data.station, data))
                    data.station:Play()
                end
            end

            -- UI reads live playback state directly
        end

    elseif action == "seek" then
        local timestamp = d.timestamp
        local data = LZY_OST.ClientActiveSounds[ply]
        if data then
            if data.isPaused then
                data.pausedAt = timestamp
                if IsValid(data.station) then data.station:SetTime(WrapTime(data.station, data, timestamp)) end
            else
                data.startTime = timestamp
                if IsValid(data.station) then
                    data.station:SetTime(ElapsedFor(data.station, data))
                end
            end
        end
    end
end)

-- Area/private volume management (ported)
-- Une OST serveur gagne toujours sur une zone / une lecture perso. Entre deux
-- OST serveur : priorité (superadmin > Gérant RP), puis la plus récente.
local function OstPrefers(data, dist, bestData, bestDist)
    if not bestData then return true end
    local aSrv = data.isServer == true
    local bSrv = bestData.isServer == true
    if aSrv ~= bSrv then return aSrv end
    local ap = tonumber(data.prio) or 0
    local bp = tonumber(bestData.prio) or 0
    if ap ~= bp then return ap > bp end
    if aSrv then
        local at = tonumber(data.startTime) or 0
        local bt = tonumber(bestData.startTime) or 0
        if at ~= bt then return at > bt end
    end
    return dist < bestDist
end

hook.Add("Think", "LZY_OST:VolumeManagement", function()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    if not next(LZY_OST.ClientActiveSounds) then return end -- aucun son actif -> 0 coût

    -- Mode liste : AVANT le nettoyage ci-dessous, qui retire ma piste finie (je ne
    -- saurais plus qu elle vient de se terminer).
    TryAdvanceQueue()

    local myPos = lp:GetPos()
    local bestCandidate = nil
    local bestDistSqr = math.huge
    local bestData = nil

    for ply, data in pairs(LZY_OST.ClientActiveSounds) do
        -- A live channel can still be finishing its current pass after repeat
        -- was disabled. Use its state; elapsed time is for unloaded streams.
        local ended = data.isArea and (
            (IsValid(data.station) and data.station:GetState() == GMOD_CHANNEL_STOPPED)
            or (not IsValid(data.station) and HasTrackEnded(data)))
        if not IsValid(ply) or ended then
            if IsValid(data.station) then data.station:Stop() end
            LZY_OST.ClientActiveSounds[ply] = nil
            if ply == lp then LZY_OST.ActiveStation = nil end
        elseif data.isArea and not data.isPaused then
            local dist = math.huge
            local isCandidate = false

            if data.isServer then
                -- Tout le serveur, y compris le diffuseur. Distance égale pour tous :
                -- le départage se fait par priorité puis par date de lancement.
                dist = 1e15
                isCandidate = true
            elseif ply == lp then
                dist = 0.1
                isCandidate = true
            elseif data.isWorld then
                dist = 999999999999
                isCandidate = true
            else
                local distSqr = myPos:DistToSqr(ply:GetPos())
                if distSqr <= (data.range * data.range) then
                    dist = distSqr
                    isCandidate = true
                end
            end

            if isCandidate and OstPrefers(data, dist, bestData, bestDistSqr) then
                bestDistSqr = dist
                bestData = data
                bestCandidate = ply
            end
        end
    end

    local activeZoneOverride = false

    for ply, data in pairs(LZY_OST.ClientActiveSounds) do
        if IsValid(ply) and data.isArea then
            data.isListening = ply == bestCandidate
            if ply == bestCandidate then
                activeZoneOverride = true

                if not IsValid(data.station) and not data.waitingForStream then
                    data.waitingForStream = true
                    sound.PlayFile(data.path, "noplay", function(station, errCode, errStr)
                        data.waitingForStream = false
                        if not IsValid(ply) or LZY_OST.ClientActiveSounds[ply] ~= data then
                            if IsValid(station) then station:Stop() end
                            return
                        end
                        -- Range/priority/pause may have changed while loading.
                        if not data.isListening or data.isPaused then
                            if IsValid(station) then station:Stop() end
                            return
                        end

                        if IsValid(station) then
                            data.length = station:GetLength()
                            if HasTrackEnded(data) then
                                station:Stop()
                                LZY_OST.ClientActiveSounds[ply] = nil
                                if ply == LocalPlayer() then LZY_OST.ActiveStation = nil end
                                return
                            end
                            data.station = station
                            station:SetVolume(0)
                            ApplyLoop(station, data)

                            if data.isPaused then
                                station:SetTime(WrapTime(station, data, data.pausedAt))
                                station:Pause()
                            else
                                station:SetTime(ElapsedFor(station, data))
                                station:Play()
                            end

                            if ply == LocalPlayer() then
                                LZY_OST.ActiveStation = station
                            end
                        else
                            -- Échec : remonter l'erreur ET retirer l'entrée pour
                            -- STOPPER le re-PlayFile à chaque frame (sinon spam silencieux).
                            OST_NotifyLoadFail(data.path, errCode, errStr)
                            LZY_OST.ClientActiveSounds[ply] = nil
                            if ply == LocalPlayer() then
                                ClearQueue() -- ne pas enchainer d echec en echec
                                LZY_OST.ActiveStation = nil
                                LZY_OST.StartTrack = nil
                                if UpdatePlayerUI then UpdatePlayerUI() end
                            end
                        end
                    end)
                elseif IsValid(data.station) then
                    if data.station:GetState() == GMOD_CHANNEL_STOPPED then
                        data.station = nil
                        LZY_OST.ClientActiveSounds[ply] = nil
                        if ply == LocalPlayer() then LZY_OST.ActiveStation = nil end
                    else
                        data.station:SetVolume(volume / 100)
                    end
                end

            else
                if IsValid(data.station) then
                    data.station:Stop()
                    data.station = nil
                    if ply == LocalPlayer() then LZY_OST.ActiveStation = nil end
                end

            end
        end
    end

    for _, data in pairs(LZY_OST.ClientActiveSounds) do
        if not data.isArea and IsValid(data.station) then
            if activeZoneOverride then
                if data.station:GetState() == GMOD_CHANNEL_PLAYING then
                    data.station:Pause()
                end
            else
                if data.station:GetState() == GMOD_CHANNEL_PAUSED and not data.isPaused then
                    data.station:Play()
                end
                -- extVol : volume piloté par un autre addon (ex. fondu d'intro ncm_intro_cinematic).
                -- Sans ce garde, on réécrit le volume chaque frame et on se bat avec lui -> grésillement.
                if not data.extVol then data.station:SetVolume(volume / 100) end
            end
        end
    end
end)

-- Client-side debug preview of current range slider selection
hook.Add("PostDrawTranslucentRenderables", "LZY_OST_RangePreview", function()
    local preview = LZY_OST.DebugRangePreview
    if not preview or CurTime() > (preview.untilTime or 0) then return end

    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local radius = preview.radius or 0
    if radius <= 0 then return end

    render.SetColorMaterial()
    local center = lp:GetPos()
    render.DrawWireframeSphere(center, radius, 16, 16, COL_PREVIEW, true)
end)
