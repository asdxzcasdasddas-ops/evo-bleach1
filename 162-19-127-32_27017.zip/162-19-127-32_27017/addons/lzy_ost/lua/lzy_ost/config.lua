-- "addons\\lzy_ost\\lua\\lzy_ost\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_OST = LZY_OST or {}
LZY_OST.Config = {}

LZY_OST.Config.Categories = {
    "Epique",
    "Joyeux",
    "Suspens",
    "Triste",
    "Anime",
    "Favoris"
}

LZY_OST.Config.Sounds = {
    { sName = "Naruto Sadness And Sorrow", sPath = "sound/n9up65zys7zbducp/ost_anime/01_naruto_sadness_and_sorrow.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/01_naruto_sadness_and_sorrow.png", bCopyright = true },
    { sName = "Number One", sPath = "sound/n9up65zys7zbducp/ost_anime/01_number_one.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/01_number_one.png", bCopyright = true },
    { sName = "Naruto Raising Fighting Spirit", sPath = "sound/n9up65zys7zbducp/ost_anime/02_naruto_raising_fighting_spirit.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/02_naruto_raising_fighting_spirit.png", bCopyright = true },
    { sName = "Treachery", sPath = "sound/n9up65zys7zbducp/ost_anime/02_treachery.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/02_treachery.png", bCopyright = true },
    { sName = "Naruto Girei Pain", sPath = "sound/n9up65zys7zbducp/ost_anime/03_naruto_girei_pain.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/03_naruto_girei_pain.png", bCopyright = true },
    { sName = "Nothing Can Be Explained", sPath = "sound/n9up65zys7zbducp/ost_anime/03_nothing_can_be_explained.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/03_nothing_can_be_explained.png", bCopyright = true },
    { sName = "On The Precipice Of Defeat", sPath = "sound/n9up65zys7zbducp/ost_anime/04_on_the_precipice_of_defeat.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/04_on_the_precipice_of_defeat.png", bCopyright = true },
    { sName = "One Piece Overtaken", sPath = "sound/n9up65zys7zbducp/ost_anime/04_onepiece_overtaken.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/04_onepiece_overtaken.png", bCopyright = true },
    { sName = "One Piece Difficult", sPath = "sound/n9up65zys7zbducp/ost_anime/05_onepiece_difficult.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/05_onepiece_difficult.png", bCopyright = true },
    { sName = "Soundscape To Ardor", sPath = "sound/n9up65zys7zbducp/ost_anime/05_soundscape_to_ardor.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/05_soundscape_to_ardor.png", bCopyright = true },
    { sName = "One Piece Binks Sake", sPath = "sound/n9up65zys7zbducp/ost_anime/06_onepiece_binks_sake.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/06_onepiece_binks_sake.png", bCopyright = true },
    { sName = "Storm Center", sPath = "sound/n9up65zys7zbducp/ost_anime/06_storm_center.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/06_storm_center.png", bCopyright = true },
    { sName = "DBZ Vegeta Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/07_dbz_vegeta_theme.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/07_dbz_vegeta_theme.png", bCopyright = true },
    { sName = "Invasion", sPath = "sound/n9up65zys7zbducp/ost_anime/07_invasion.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/07_invasion.png", bCopyright = true },
    { sName = "Fight To The Death", sPath = "sound/n9up65zys7zbducp/ost_anime/08_fight_to_the_death.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/08_fight_to_the_death.png", bCopyright = true },
    { sName = "HxH Hyouka", sPath = "sound/n9up65zys7zbducp/ost_anime/08_hxh_hyouka.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/08_hxh_hyouka.png", bCopyright = true },
    { sName = "HxH Kingdom Of Predators", sPath = "sound/n9up65zys7zbducp/ost_anime/09_hxh_kingdom_of_predators.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/09_hxh_kingdom_of_predators.png", bCopyright = true },
    { sName = "Stand Up Be Strong", sPath = "sound/n9up65zys7zbducp/ost_anime/09_stand_up_be_strong.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/09_stand_up_be_strong.png", bCopyright = true },
    { sName = "AOT Youseebiggirl", sPath = "sound/n9up65zys7zbducp/ost_anime/10_aot_youseebiggirl.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/10_aot_youseebiggirl.png", bCopyright = true },
    { sName = "Never Meant To Belong", sPath = "sound/n9up65zys7zbducp/ost_anime/10_never_meant_to_belong.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/10_never_meant_to_belong.png", bCopyright = true },
    { sName = "AOT Vogel Im Kafig", sPath = "sound/n9up65zys7zbducp/ost_anime/11_aot_vogel_im_kafig.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/11_aot_vogel_im_kafig.png", bCopyright = true },
    { sName = "La Distancia Para Un Duelo", sPath = "sound/n9up65zys7zbducp/ost_anime/11_la_distancia_para_un_duelo.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/11_la_distancia_para_un_duelo.png", bCopyright = true },
    { sName = "AOT Call Of Silence", sPath = "sound/n9up65zys7zbducp/ost_anime/12_aot_call_of_silence.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/12_aot_call_of_silence.png", bCopyright = true },
    { sName = "Clavar La Espada", sPath = "sound/n9up65zys7zbducp/ost_anime/12_clavar_la_espada.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/12_clavar_la_espada.png", bCopyright = true },
    { sName = "DS Kamado Tanjiro No Uta", sPath = "sound/n9up65zys7zbducp/ost_anime/13_ds_kamado_tanjiro_no_uta.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/13_ds_kamado_tanjiro_no_uta.png", bCopyright = true },
    { sName = "Power To Strive", sPath = "sound/n9up65zys7zbducp/ost_anime/13_power_to_strive.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/13_power_to_strive.png", bCopyright = true },
    { sName = "Battle Ignition", sPath = "sound/n9up65zys7zbducp/ost_anime/14_battle_ignition.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/14_battle_ignition.png", bCopyright = true },
    { sName = "DS Rengoku Vs Akaza", sPath = "sound/n9up65zys7zbducp/ost_anime/14_ds_rengoku_vs_akaza.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/14_ds_rengoku_vs_akaza.png", bCopyright = true },
    { sName = "Going Home", sPath = "sound/n9up65zys7zbducp/ost_anime/15_going_home.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/15_going_home.png", bCopyright = true },
    { sName = "JJK Gojo Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/15_jjk_gojo_theme.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/15_jjk_gojo_theme.png", bCopyright = true },
    { sName = "JJK Domain Expansion", sPath = "sound/n9up65zys7zbducp/ost_anime/16_jjk_domain_expansion.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/16_jjk_domain_expansion.png", bCopyright = true },
    { sName = "Will Of The Heart", sPath = "sound/n9up65zys7zbducp/ost_anime/16_will_of_the_heart.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/16_will_of_the_heart.png", bCopyright = true },
    { sName = "Requiem For The Lost Ones", sPath = "sound/n9up65zys7zbducp/ost_anime/17_requiem_for_the_lost_ones.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/17_requiem_for_the_lost_ones.png", bCopyright = true },
    { sName = "TG Glassy Sky", sPath = "sound/n9up65zys7zbducp/ost_anime/17_tg_glassy_sky.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/17_tg_glassy_sky.png", bCopyright = true },
    { sName = "Escalon", sPath = "sound/n9up65zys7zbducp/ost_anime/18_escalon.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/18_escalon.png", bCopyright = true },
    { sName = "TG Licht Und Schatten", sPath = "sound/n9up65zys7zbducp/ost_anime/18_tg_licht_und_schatten.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/18_tg_licht_und_schatten.png", bCopyright = true },
    { sName = "Cometose", sPath = "sound/n9up65zys7zbducp/ost_anime/19_cometose.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/19_cometose.png", bCopyright = true },
    { sName = "DN Ls Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/19_dn_ls_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/19_dn_ls_theme.png", bCopyright = true },
    { sName = "DN Low Of Solipsism", sPath = "sound/n9up65zys7zbducp/ost_anime/20_dn_low_of_solipsism.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/20_dn_low_of_solipsism.png", bCopyright = true },
    { sName = "Nube Negra", sPath = "sound/n9up65zys7zbducp/ost_anime/20_nube_negra.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/20_nube_negra.png", bCopyright = true },
    { sName = "CG Madder Sky", sPath = "sound/n9up65zys7zbducp/ost_anime/21_cg_madder_sky.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/21_cg_madder_sky.png", bCopyright = true },
    { sName = "Diferencia 3", sPath = "sound/n9up65zys7zbducp/ost_anime/21_diferencia_3.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/21_diferencia_3.png", bCopyright = true },
    { sName = "CG Continued Story", sPath = "sound/n9up65zys7zbducp/ost_anime/22_cg_continued_story.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/22_cg_continued_story.png", bCopyright = true },
    { sName = "Oblivion", sPath = "sound/n9up65zys7zbducp/ost_anime/22_oblivion.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/22_oblivion.png", bCopyright = true },
    { sName = "Berserk Forces", sPath = "sound/n9up65zys7zbducp/ost_anime/23_berserk_forces.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/23_berserk_forces.png", bCopyright = true },
    { sName = "Number One Bankai", sPath = "sound/n9up65zys7zbducp/ost_anime/23_number_one_bankai.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/23_number_one_bankai.png", bCopyright = true },
    { sName = "Berserk Guts", sPath = "sound/n9up65zys7zbducp/ost_anime/24_berserk_guts.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/24_berserk_guts.png", bCopyright = true },
    { sName = "Cometh The Hour", sPath = "sound/n9up65zys7zbducp/ost_anime/24_cometh_the_hour.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/24_cometh_the_hour.png", bCopyright = true },
    { sName = "Monster Grain", sPath = "sound/n9up65zys7zbducp/ost_anime/25_monster_grain.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/25_monster_grain.png", bCopyright = true },
    { sName = "TYBW Main Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/25_tybw_main_theme.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/25_tybw_main_theme.png", bCopyright = true },
    { sName = "One True Messiah", sPath = "sound/n9up65zys7zbducp/ost_anime/26_one_true_messiah.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/26_one_true_messiah.png", bCopyright = true },
    { sName = "Parasyte Next To You", sPath = "sound/n9up65zys7zbducp/ost_anime/26_parasyte_next_to_you.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/26_parasyte_next_to_you.png", bCopyright = true },
    { sName = "The Almighty", sPath = "sound/n9up65zys7zbducp/ost_anime/27_the_almighty.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/27_the_almighty.png", bCopyright = true },
    { sName = "Last Judgement", sPath = "sound/n9up65zys7zbducp/ost_anime/28_last_judgement.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/28_last_judgement.png", bCopyright = true },
    { sName = "Psychopass Main Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/28_psychopass_main_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/28_psychopass_main_theme.png", bCopyright = true },
    { sName = "Blaze Of Soul", sPath = "sound/n9up65zys7zbducp/ost_anime/29_blaze_of_soul.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/29_blaze_of_soul.png", bCopyright = true },
    { sName = "EVA Decisive Battle", sPath = "sound/n9up65zys7zbducp/ost_anime/29_eva_decisive_battle.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/29_eva_decisive_battle.png", bCopyright = true },
    { sName = "EVA Hedgehogs Dilemma", sPath = "sound/n9up65zys7zbducp/ost_anime/30_eva_hedgehogs_dilemma.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/30_eva_hedgehogs_dilemma.png", bCopyright = true },
    { sName = "Raw Breath Of Danger", sPath = "sound/n9up65zys7zbducp/ost_anime/30_raw_breath_of_danger.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/30_raw_breath_of_danger.png", bCopyright = true },
    { sName = "Bebop Tank", sPath = "sound/n9up65zys7zbducp/ost_anime/31_bebop_tank.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/31_bebop_tank.png", bCopyright = true },
    { sName = "Bebop Space Lion", sPath = "sound/n9up65zys7zbducp/ost_anime/32_bebop_space_lion.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/32_bebop_space_lion.png", bCopyright = true },
    { sName = "Bebop Rain", sPath = "sound/n9up65zys7zbducp/ost_anime/33_bebop_rain.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/33_bebop_rain.png", bCopyright = true },
    { sName = "Gurren Libera Me From Hell", sPath = "sound/n9up65zys7zbducp/ost_anime/34_gurren_libera_me_from_hell.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/34_gurren_libera_me_from_hell.png", bCopyright = true },
    { sName = "Gurren Nikopol Viral", sPath = "sound/n9up65zys7zbducp/ost_anime/35_gurren_nikopol_viral.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/35_gurren_nikopol_viral.png", bCopyright = true },
    { sName = "GITS Making Of A Cyborg", sPath = "sound/n9up65zys7zbducp/ost_anime/36_gits_making_of_a_cyborg.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/36_gits_making_of_a_cyborg.png", bCopyright = true },
    { sName = "Akira Kaneda", sPath = "sound/n9up65zys7zbducp/ost_anime/37_akira_kaneda.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/37_akira_kaneda.png", bCopyright = true },
    { sName = "Steinsgate Gate Of Steiner", sPath = "sound/n9up65zys7zbducp/ost_anime/38_steinsgate_gate_of_steiner.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/38_steinsgate_gate_of_steiner.png", bCopyright = true },
    { sName = "Champloo Aruarian Dance", sPath = "sound/n9up65zys7zbducp/ost_anime/39_champloo_aruarian_dance.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/39_champloo_aruarian_dance.png", bCopyright = true },
    { sName = "Champloo Battlecry", sPath = "sound/n9up65zys7zbducp/ost_anime/40_champloo_battlecry.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/40_champloo_battlecry.png", bCopyright = true },
    { sName = "FMAB Brothers", sPath = "sound/n9up65zys7zbducp/ost_anime/41_fmab_brothers.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/41_fmab_brothers.png", bCopyright = true },
    { sName = "FMAB Lapis Philosophorum", sPath = "sound/n9up65zys7zbducp/ost_anime/42_fmab_lapis_philosophorum.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/42_fmab_lapis_philosophorum.png", bCopyright = true },
    { sName = "YLIA Watashi No Uso", sPath = "sound/n9up65zys7zbducp/ost_anime/43_ylia_watashi_no_uso.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/43_ylia_watashi_no_uso.png", bCopyright = true },
    { sName = "Clannad Dango Daikazoku", sPath = "sound/n9up65zys7zbducp/ost_anime/44_clannad_dango_daikazoku.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/44_clannad_dango_daikazoku.png", bCopyright = true },
    { sName = "MIA Hanezeve Caradhina", sPath = "sound/n9up65zys7zbducp/ost_anime/45_mia_hanezeve_caradhina.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/45_mia_hanezeve_caradhina.png", bCopyright = true },
    { sName = "Ghibli One Summers Day", sPath = "sound/n9up65zys7zbducp/ost_anime/46_ghibli_one_summers_day.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/46_ghibli_one_summers_day.png", bCopyright = true },
    { sName = "Ghibli Merry Go Round Of Life", sPath = "sound/n9up65zys7zbducp/ost_anime/47_ghibli_merry_go_round_of_life.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/47_ghibli_merry_go_round_of_life.png", bCopyright = true },
    { sName = "JoJo Il Vento Doro", sPath = "sound/n9up65zys7zbducp/ost_anime/48_jojo_il_vento_doro.mp3", sCategory = "Anime", sMats = "n9up65zys7zbducp/ost_covers/48_jojo_il_vento_doro.png", bCopyright = true },
    { sName = "SAO Swordland", sPath = "sound/n9up65zys7zbducp/ost_anime/49_sao_swordland.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/49_sao_swordland.png", bCopyright = true },
    { sName = "Fate Emiya", sPath = "sound/n9up65zys7zbducp/ost_anime/50_fate_emiya.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/50_fate_emiya.png", bCopyright = true },

    -- ── Lot ajouté le 03/08 ─────────────────────────────────────────────────
    -- 29 OST d'anime supplémentaires. Même dossier et même convention que les
    -- 80 premières (numérotation reprise à 51). Quatre pistes du lot fourni ont
    -- été écartées : empreinte audio identique à une piste déjà au catalogue
    -- (Low Of Solipsism, Il Vento D'Oro, Clavar La Espada, Girei).
    { sName = "Berserk My Brother", sPath = "sound/n9up65zys7zbducp/ost_anime/51_berserk_my_brother.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/51_berserk_my_brother.png", bCopyright = true },
    { sName = "HxH Emperor's Time", sPath = "sound/n9up65zys7zbducp/ost_anime/52_hxh_emperors_time.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/52_hxh_emperors_time.png", bCopyright = true },
    { sName = "JoJo Stardust Crusaders", sPath = "sound/n9up65zys7zbducp/ost_anime/53_jojo_stardust_crusaders.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/53_jojo_stardust_crusaders.png", bCopyright = true },
    { sName = "One Piece Nika Joy Boy", sPath = "sound/n9up65zys7zbducp/ost_anime/54_op_nika_joy_boy.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/54_op_nika_joy_boy.png", bCopyright = true },
    { sName = "Berserk The Golden Age", sPath = "sound/n9up65zys7zbducp/ost_anime/55_berserk_the_golden_age.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/55_berserk_the_golden_age.png", bCopyright = true },
    { sName = "One Punch Man Seigi Shikkou", sPath = "sound/n9up65zys7zbducp/ost_anime/56_opm_seigi_shikkou.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/56_opm_seigi_shikkou.png", bCopyright = true },
    { sName = "Your Battle Is My Battle", sPath = "sound/n9up65zys7zbducp/ost_anime/57_your_battle_is_my_battle.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/57_your_battle_is_my_battle.png", bCopyright = true },
    { sName = "HxH Iai No Kyoujin (Nobunaga)", sPath = "sound/n9up65zys7zbducp/ost_anime/58_hxh_iai_no_kyoujin.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers/58_hxh_iai_no_kyoujin.png", bCopyright = true },
    { sName = "BNHA Hero A", sPath = "sound/n9up65zys7zbducp/ost_anime/59_bnha_hero_a.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/59_bnha_hero_a.png", bCopyright = true },
    { sName = "DBZ Gatebreaker", sPath = "sound/n9up65zys7zbducp/ost_anime/60_dbz_gatebreaker.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/60_dbz_gatebreaker.png", bCopyright = true },
    { sName = "One Piece Franky Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/61_op_franky_theme.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/61_op_franky_theme.png", bCopyright = true },
    { sName = "One Piece Wano Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/62_op_wano_theme.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers/62_op_wano_theme.png", bCopyright = true },
    { sName = "HxH Genei No Banka", sPath = "sound/n9up65zys7zbducp/ost_anime/63_hxh_genei_no_banka.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/63_hxh_genei_no_banka.png", bCopyright = true },
    { sName = "Confrontment", sPath = "sound/n9up65zys7zbducp/ost_anime/64_confrontment.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/64_confrontment.png", bCopyright = true },
    { sName = "HxH Dirge From Dark Side", sPath = "sound/n9up65zys7zbducp/ost_anime/65_hxh_dirge_from_dark_side.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/65_hxh_dirge_from_dark_side.png", bCopyright = true },
    { sName = "One Piece Imu Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/66_op_imu_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/66_op_imu_theme.png", bCopyright = true },
    { sName = "Naruto Madara Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/67_naruto_madara_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/67_naruto_madara_theme.png", bCopyright = true },
    { sName = "One Piece New World Symphony", sPath = "sound/n9up65zys7zbducp/ost_anime/68_op_new_world_symphony.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/68_op_new_world_symphony.png", bCopyright = true },
    { sName = "Naruto Tobi Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/69_naruto_tobi_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/69_naruto_tobi_theme.png", bCopyright = true },
    { sName = "HxH Gyakujuuji No Otoko (Chrollo)", sPath = "sound/n9up65zys7zbducp/ost_anime/70_hxh_gyakujuuji_no_otoko.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/70_hxh_gyakujuuji_no_otoko.png", bCopyright = true },
    { sName = "HxH Sono Kyoukan", sPath = "sound/n9up65zys7zbducp/ost_anime/71_hxh_sono_kyoukan.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers/71_hxh_sono_kyoukan.png", bCopyright = true },
    { sName = "Naruto Samidare (Jiraiya)", sPath = "sound/n9up65zys7zbducp/ost_anime/72_naruto_samidare.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/72_naruto_samidare.png", bCopyright = true },
    { sName = "HxH Spiders Canzone", sPath = "sound/n9up65zys7zbducp/ost_anime/73_hxh_spiders_canzone.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/73_hxh_spiders_canzone.png", bCopyright = true },
    { sName = "HxH No No Haru", sPath = "sound/n9up65zys7zbducp/ost_anime/74_hxh_no_no_haru.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/74_hxh_no_no_haru.png", bCopyright = true },
    { sName = "Meirono Nakano Leina", sPath = "sound/n9up65zys7zbducp/ost_anime/75_meirono_nakano_leina.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/75_meirono_nakano_leina.png", bCopyright = true },
    { sName = "Requiem Aranea", sPath = "sound/n9up65zys7zbducp/ost_anime/76_requiem_aranea.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/76_requiem_aranea.png", bCopyright = true },
    { sName = "Mozart Lacrimosa", sPath = "sound/n9up65zys7zbducp/ost_anime/77_mozart_lacrimosa.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/77_mozart_lacrimosa.png", bCopyright = true },
    { sName = "BNHA All For One", sPath = "sound/n9up65zys7zbducp/ost_anime/78_bnha_all_for_one.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/78_bnha_all_for_one.png", bCopyright = true },
    { sName = "BNHA Seigi No Fuhai (Tomura)", sPath = "sound/n9up65zys7zbducp/ost_anime/79_bnha_seigi_no_fuhai.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers/79_bnha_seigi_no_fuhai.png", bCopyright = true },

    -- ── Lot Bleach ajouté le 27/08 ──────────────────────────────────────────
    -- Demande du staff (Jayro, salon suggestions) : le menu était noyé sous les
    -- OST hors univers, ce qui casse l'immersion. Ce lot n'ajoute QUE du Bleach.
    -- Catégories reprises des ambiances qu'il a lui-même indiquées.
    -- Trois pistes de sa liste sont écartées, déjà au catalogue : Soundscape To
    -- Ardor (05), Nothing Can Be Explained (03), Invasion (07).
    -- Pas de sMats : sans pochette le client retombe sur l'icône par défaut
    -- (GetIconMaterial), alors qu'un chemin de PNG absent afficherait un damier.
    { sName = "Ceremony Commences", sPath = "sound/n9up65zys7zbducp/ost_anime/80_ceremony_commences.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Anguish", sPath = "sound/n9up65zys7zbducp/ost_anime/81_anguish.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "BL_35", sPath = "sound/n9up65zys7zbducp/ost_anime/82_bl_35.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Princess In Captivity", sPath = "sound/n9up65zys7zbducp/ost_anime/83_princess_in_captivity.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "The One Path To Take", sPath = "sound/n9up65zys7zbducp/ost_anime/84_the_one_path_to_take.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Hollowed", sPath = "sound/n9up65zys7zbducp/ost_anime/85_hollowed.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Turn The Tables", sPath = "sound/n9up65zys7zbducp/ost_anime/86_turn_the_tables.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Attack On The Beat", sPath = "sound/n9up65zys7zbducp/ost_anime/87_attack_on_the_beat.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Breakthrough Even", sPath = "sound/n9up65zys7zbducp/ost_anime/88_breakthrough_even.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Eerie Blank", sPath = "sound/n9up65zys7zbducp/ost_anime/89_eerie_blank.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "The Fate", sPath = "sound/n9up65zys7zbducp/ost_anime/90_the_fate.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Shadows Close In", sPath = "sound/n9up65zys7zbducp/ost_anime/91_shadows_close_in.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "BL_73", sPath = "sound/n9up65zys7zbducp/ost_anime/92_bl_73.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Pray That You Always Understand Me", sPath = "sound/n9up65zys7zbducp/ost_anime/93_pray_that_you_always_understand_me.mp3", sCategory = "Triste", bCopyright = true },
    { sName = "Wrapped In Kindness", sPath = "sound/n9up65zys7zbducp/ost_anime/94_wrapped_in_kindness.mp3", sCategory = "Joyeux", bCopyright = true },
    { sName = "BL_56", sPath = "sound/n9up65zys7zbducp/ost_anime/95_bl_56.mp3", sCategory = "Joyeux", bCopyright = true },
    { sName = "BL_40", sPath = "sound/n9up65zys7zbducp/ost_anime/96_bl_40.mp3", sCategory = "Joyeux", bCopyright = true },
    { sName = "BL_60", sPath = "sound/n9up65zys7zbducp/ost_anime/97_bl_60.mp3", sCategory = "Joyeux", bCopyright = true },
    -- Ajouts du 16/09/2026 : pas de pochette, l'icone par defaut du menu prend le relais.
    { sName = "CG Black Knights", sPath = "sound/n9up65zys7zbducp/ost_anime/98_cg_black_knights.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "CG Zero", sPath = "sound/n9up65zys7zbducp/ost_anime/99_cg_zero.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "CG The Master", sPath = "sound/n9up65zys7zbducp/ost_anime/100_cg_the_master.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "CG Nightmare", sPath = "sound/n9up65zys7zbducp/ost_anime/101_cg_nightmare.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Smash Final Destination", sPath = "sound/n9up65zys7zbducp/ost_anime/102_smash_final_destination.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Smash Lifelight", sPath = "sound/n9up65zys7zbducp/ost_anime/103_smash_lifelight.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Parasyte Speak", sPath = "sound/n9up65zys7zbducp/ost_anime/104_parasyte_speak.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Phantom Karma", sPath = "sound/n9up65zys7zbducp/ost_anime/105_phantom_karma.mp3", sCategory = "Triste", bCopyright = true },
    { sName = "Elfen Lied Lilium", sPath = "sound/n9up65zys7zbducp/ost_anime/106_elfen_lied_lilium.mp3", sCategory = "Triste", bCopyright = true },
    { sName = "Saint Seiya Hades", sPath = "sound/n9up65zys7zbducp/ost_anime/107_saint_seiya_hades.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Berserk Griffith", sPath = "sound/n9up65zys7zbducp/ost_anime/108_berserk_griffith.mp3", sCategory = "Triste", bCopyright = true },
    { sName = "NieR A Beautiful Song", sPath = "sound/n9up65zys7zbducp/ost_anime/109_nier_a_beautiful_song.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "NieR Kaine Salvation", sPath = "sound/n9up65zys7zbducp/ost_anime/110_nier_kaine_salvation.mp3", sCategory = "Triste", bCopyright = true },
    -- Ajouts du 28/09/2026 (demande axxou), meme principe : pas de pochette.
    { sName = "Ichigo True Bankai Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/111_ichigo_true_bankai_theme.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "I Escaped", sPath = "sound/n9up65zys7zbducp/ost_anime/112_i_escaped.mp3", sCategory = "Suspens", bCopyright = true },
    { sName = "Gerard Valkyrie Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/113_gerard_valkyrie_theme.mp3", sCategory = "Epique", bCopyright = true },
    -- Ajouts du 03/10/2026 (demande axxou, 3 themes Star Wars + Hisoka), toujours sans pochette.
    { sName = "Darth Revan x Nazgul Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/114_darth_revan_x_nazgul_theme.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Darth Malgus Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/115_darth_malgus_theme.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "Valkorion Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/116_valkorion_theme.mp3", sCategory = "Epique", bCopyright = true },
    { sName = "HxH Hisoka Theme", sPath = "sound/n9up65zys7zbducp/ost_anime/117_hxh_hisoka_theme.mp3", sCategory = "Suspens", bCopyright = true },

    -- ── LIBRES DE DROITS ────────────────────────────────────────────────────
    -- Reprises/remix sans copyright : bCopyright = false. Conséquence voulue,
    -- ce sont les SEULES pistes que tout le monde peut diffuser en Zone sans le
    -- palier de grade, et que le filtre client « masquer le copyright » laisse
    -- passer. Jusqu'ici 100 % du catalogue était copyright, ce chemin ne servait
    -- jamais (cf. commentaire sv_main.lua).
    { sName = "Battle We Saiyans Have No Limits", sPath = "sound/n9up65zys7zbducp/ost_libre/01_saiyans_no_limits.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/01_saiyans_no_limits.png", bCopyright = false },
    { sName = "Believe In Yourself", sPath = "sound/n9up65zys7zbducp/ost_libre/02_believe_in_yourself.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/02_believe_in_yourself.png", bCopyright = false },
    { sName = "DBZ Budokai 2", sPath = "sound/n9up65zys7zbducp/ost_libre/03_dbz_budokai_2.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/03_dbz_budokai_2.png", bCopyright = false },
    { sName = "DBZ Budokai 3", sPath = "sound/n9up65zys7zbducp/ost_libre/04_dbz_budokai_3.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/04_dbz_budokai_3.png", bCopyright = false },
    { sName = "Jaka Jaan", sPath = "sound/n9up65zys7zbducp/ost_libre/05_jaka_jaan.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/05_jaka_jaan.png", bCopyright = false },
    { sName = "My Heart's Not Calm", sPath = "sound/n9up65zys7zbducp/ost_libre/06_my_hearts_not_calm.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/06_my_hearts_not_calm.png", bCopyright = false },
    { sName = "Saiyan 3 Theme", sPath = "sound/n9up65zys7zbducp/ost_libre/07_saiyan_3_theme.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/07_saiyan_3_theme.png", bCopyright = false },
    { sName = "Solid State Scouter", sPath = "sound/n9up65zys7zbducp/ost_libre/08_solid_state_scouter.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/08_solid_state_scouter.png", bCopyright = false },
    { sName = "Ultra Instinct Perfected", sPath = "sound/n9up65zys7zbducp/ost_libre/09_ultra_instinct_perfected.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/09_ultra_instinct_perfected.png", bCopyright = false },
    { sName = "Vegito Vs Zamasu", sPath = "sound/n9up65zys7zbducp/ost_libre/10_vegito_vs_zamasu.mp3", sCategory = "Epique", sMats = "n9up65zys7zbducp/ost_covers_libre/10_vegito_vs_zamasu.png", bCopyright = false },
    { sName = "Cha-La Head-Cha-La", sPath = "sound/n9up65zys7zbducp/ost_libre/11_cha_la_head_cha_la.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers_libre/11_cha_la_head_cha_la.png", bCopyright = false },
    { sName = "Dan Dan Kokoro", sPath = "sound/n9up65zys7zbducp/ost_libre/12_dan_dan_kokoro.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers_libre/12_dan_dan_kokoro.png", bCopyright = false },
    { sName = "Dragon Soul", sPath = "sound/n9up65zys7zbducp/ost_libre/13_dragon_soul.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers_libre/13_dragon_soul.png", bCopyright = false },
    { sName = "Hitori Janai", sPath = "sound/n9up65zys7zbducp/ost_libre/14_hitori_janai.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers_libre/14_hitori_janai.png", bCopyright = false },
    { sName = "Mystical Adventure", sPath = "sound/n9up65zys7zbducp/ost_libre/15_mystical_adventure.mp3", sCategory = "Joyeux", sMats = "n9up65zys7zbducp/ost_covers_libre/15_mystical_adventure.png", bCopyright = false },
    { sName = "Android 17 Theme", sPath = "sound/n9up65zys7zbducp/ost_libre/16_android_17_theme.mp3", sCategory = "Suspens", sMats = "n9up65zys7zbducp/ost_covers_libre/16_android_17_theme.png", bCopyright = false },
    { sName = "Crushing Defeat", sPath = "sound/n9up65zys7zbducp/ost_libre/17_crushing_defeat.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers_libre/17_crushing_defeat.png", bCopyright = false },
    { sName = "Day Of Fate", sPath = "sound/n9up65zys7zbducp/ost_libre/18_day_of_fate.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers_libre/18_day_of_fate.png", bCopyright = false },
    { sName = "Symphony For Akira Toriyama", sPath = "sound/n9up65zys7zbducp/ost_libre/19_symphony_akira_toriyama.mp3", sCategory = "Triste", sMats = "n9up65zys7zbducp/ost_covers_libre/19_symphony_akira_toriyama.png", bCopyright = false },
}

-- Grade de FACTION donnant l'accès diffusion ZONE, en plus des rangs staff. Demande user
-- 08/16 : à partir du grade 6 (>= 6, grade 6 INCLUS) on peut diffuser en Zone (copyright
-- inclus ; c'était grade 10 depuis le 08/01). C'est le SEUL chemin joueur : le palier par
-- NIVEAU a été RETIRÉ (07/26, demande user « pas de blocage par niveau, seulement par
-- grade »). Mettre à nil pour désactiver. Le check est FactionRank >= cette valeur.
LZY_OST.Config.GradeRequiredForArea = 6

-- Cles en MINUSCULES : le lookup (sv_main.lua CanPlayArea) lowercase le usergroup, donc TOUTES
-- les orthographes SAM matchent (moderateur/Modérateur/modérateur/moderator, admin/Administrateur…).
-- AVANT : cles 'Moderateur'/'Animateur' (majuscule) qui ne matchaient AUCUN usergroup reel
-- (GetUserGroup renvoie du minuscule) -> le perk staff etait MORT.
LZY_OST.Config.StaffPermissions = {
    ['superadmin']     = { allowed = true, range = 10000 },
    ['admin']          = { allowed = true, range = 4000 },
    ['administrateur'] = { allowed = true, range = 4000 },
    ['gérant']         = { allowed = true, range = 4000 },
    -- Gérant RP (10/09, demande user) : diffusion SERVEUR (`world`, tout le monde l'entend
    -- où qu'il soit) pour la musique de la trame principale. Les deux orthographes du rang
    -- (cf. evo_staff/sv_staff_ranks.lua). `world` est lu par CanPlayArea (sv_main.lua).
    ['gerant_rp']      = { allowed = true, range = 10000, world = true },
    ['gérant rp']      = { allowed = true, range = 10000, world = true },
    -- 09/08 : la cle etait ['resp modo'], un nom qu'AUCUN usergroup SAM ne porte —
    -- exactement le bug decrit au-dessus, une 2e fois. Le respo modo n'avait donc pas
    -- la diffusion, alors qu'un simple moderateur l'a. Vraies orthographes du rang
    -- (cf. evo_staff/sv_staff_ranks.lua) ; lookup deja en lower, qui ne touche pas
    -- aux accents, d'ou les deux cles.
    ['responsable_moderateur']  = { allowed = true, range = 4000 },
    ['responsable modérateur']  = { allowed = true, range = 4000 },
    ['moderateur']     = { allowed = true, range = 4000 },
    ['modérateur']     = { allowed = true, range = 4000 },
    ['moderator']      = { allowed = true, range = 4000 },
    ['moderateur_plus'] = { allowed = true, range = 4000 },
    ['moderateur plus'] = { allowed = true, range = 4000 },
    ['animateur']      = { allowed = true, range = 4000 },
    ['mj']             = { allowed = true, range = 4000 },
    ['mj_plus']        = { allowed = true, range = 4000 },
    -- HELPEUR autorisé (revirement 08/20, demande user « c'est bizarre qu'un helper
    -- ne puisse pas mettre d'OST en zone ») : il diffuse comme un modérateur. La
    -- règle inverse du 07/21 (« les helpeurs ne diffusent JAMAIS en Zone ») est
    -- annulée — les deux entrées du denylist ci-dessous ont été retirées.
    ['helper']  = { allowed = true, range = 4000 }, -- groupe SAM réel (evo_staff/sv_staff_ranks.lua)
    ['helpeur'] = { allowed = true, range = 4000 }, -- alias orthographique par sécurité
}

-- Rangs EXPLICITEMENT privés de diffusion Zone/World : refus AVANT le palier de
-- grade dans CanPlayArea (la whitelist OST individuelle reste un override
-- AU-DESSUS). Clés en minuscule (le lookup lowercase le usergroup). VIDE depuis le
-- 08/20 : le helpeur, seul rang qui y figurait (07/21), a récupéré la diffusion.
LZY_OST.Config.DeniedAreaGroups = {}

-- PRIORITÉ ENTRE DIFFUSEURS (user 08/26) : quand deux zones OST se chevauchent, un
-- auditeur n'entend QUE la piste du diffuseur le plus prioritaire (à égalité : la plus
-- proche, la sienne d'abord). Score = poids du rang STAFF (menu SAM) × 100 + GRADE de
-- faction (0..16). Un staff prime donc toujours sur un joueur, et entre joueurs le
-- grade tranche. Clés en minuscules (mêmes orthographes que StaffPermissions).
LZY_OST.Config.PriorityStaff = {
    ['superadmin']              = 5,
    ['admin']                   = 4,
    ['administrateur']          = 4,
    ['gérant']                  = 4,
    ['gerant_rp']               = 4,
    ['gérant rp']               = 4,
    ['responsable_moderateur']  = 3,
    ['responsable modérateur']  = 3,
    ['moderateur']              = 2,
    ['modérateur']              = 2,
    ['moderator']               = 2,
    ['moderateur_plus']         = 2,
    ['moderateur plus']         = 2,
    ['animateur']               = 2,
    ['mj']                      = 2,
    ['mj_plus']                 = 2,
    ['helper']                  = 1,
    ['helpeur']                 = 1,
}
LZY_OST.Config.PriorityWhitelist = 1 -- whitelist OST sans rang staff : au-dessus des joueurs

-- PRIORITÉ ENTRE DIFFUSEURS (user 08/26) : quand deux zones OST se chevauchent, un
-- auditeur n'entend QUE la piste du diffuseur le plus prioritaire (à égalité : la plus
-- proche, la sienne d'abord). Score = poids du rang STAFF (menu SAM) × 100 + GRADE de
-- faction (0..16). Un staff prime donc toujours sur un joueur, et entre joueurs le
-- grade tranche. Clés en minuscules (mêmes orthographes que StaffPermissions).
LZY_OST.Config.PriorityStaff = {
    ['superadmin']              = 5,
    ['admin']                   = 4,
    ['administrateur']          = 4,
    ['gérant']                  = 4,
    ['gerant_rp']               = 4,
    ['gérant rp']               = 4,
    ['responsable_moderateur']  = 3,
    ['responsable modérateur']  = 3,
    ['moderateur']              = 2,
    ['modérateur']              = 2,
    ['moderator']               = 2,
    ['moderateur_plus']         = 2,
    ['moderateur plus']         = 2,
    ['animateur']               = 2,
    ['mj']                      = 2,
    ['mj_plus']                 = 2,
    ['helper']                  = 1,
    ['helpeur']                 = 1,
}
LZY_OST.Config.PriorityWhitelist = 1 -- whitelist OST sans rang staff : au-dessus des joueurs

-- Portee de diffusion PAR DEFAUT (joueur sans rang staff), et plafond du curseur
-- de portee dans le menu. 500 -> 1500 (26/07) : a 500 unites la musique ne portait
-- pas au-dela d'une piece, inutilisable pour une scene RP a plusieurs.
LZY_OST.Config.DefaultLevelRange = 1500

-- Diffusion SERVEUR (menu OST) : toute la carte, et elle PRIME sur les OST de zone
-- et personnelles. Superadmin est toujours inclus via IsSuperAdmin() (pas besoin
-- de cle). Les autres cles sont des usergroups SAM, en minuscules (le lookup
-- lowercase, il ne retire pas les accents).
LZY_OST.Config.ServerGroups = {
    ['gerant_rp'] = true,
    ['gérant rp'] = true,
    ['gerant rp'] = true,
}
