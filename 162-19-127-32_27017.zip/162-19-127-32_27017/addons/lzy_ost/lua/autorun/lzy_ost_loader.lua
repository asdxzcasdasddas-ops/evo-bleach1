-- "addons\\lzy_ost\\lua\\autorun\\lzy_ost_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_ost/config.lua")
    AddCSLuaFile("lzy_ost/client/cl_main.lua")
    include("lzy_ost/config.lua")
    include("lzy_ost/server/sv_main.lua")
else
    include("lzy_ost/config.lua")
    include("lzy_ost/client/cl_main.lua")
end