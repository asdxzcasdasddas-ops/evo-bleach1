-- "addons\\bleach_ping\\lua\\bleach_ping\\cl_waypoints.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- Bleach Ping System - CLIENT (cl_waypoints.lua)
-- Gère l'envoi des pings, le stockage local, et le rendu HUD
-- avec ToScreen(), fade-out, distance, et suivi d'entité.
-- Style visuel : DA EVO (accent #cf444e, Bebas Neue, texte clair, propre — plus d'anime).
-- ============================================================

-- =====================
-- Localisation des fonctions globales (micro-optimisation)
-- Utilisé dans le HUDPaint qui tourne chaque frame
-- =====================
local surface_SetDrawColor = surface.SetDrawColor
local surface_DrawRect = surface.DrawRect
local surface_SetFont = surface.SetFont
local surface_GetTextSize = surface.GetTextSize
local surface_SetTextColor = surface.SetTextColor
local surface_SetTextPos = surface.SetTextPos
local surface_DrawText = surface.DrawText
local draw_SimpleTextOutlined = draw.SimpleTextOutlined
local draw_RoundedBox = draw.RoundedBox
local math_floor = math.floor
local math_Clamp = math.Clamp
local math_sin = math.sin
local math_abs = math.abs
local CurTime = CurTime
local IsValid = IsValid
local LocalPlayer = LocalPlayer

-- =====================
-- Configuration client
-- =====================
local PING_TRACE_DISTANCE = 50000    -- Distance max du raycast (en unités Source)
local FADE_START = 3                  -- Commence le fade X secondes avant la fin
local UNITS_TO_METERS = 0.01905      -- 1 unité Source ≈ 0.01905 mètres

-- =====================
-- Palette DA EVO : accent rouge #cf444e + texte clair, outline noir (fini le bleu anime).
-- =====================
local COLOR_PING_LOCATION = Color(236, 237, 243, 255)   -- Blanc cassé : "Aller ici" (repère neutre)
local COLOR_PING_DANGER   = Color(207, 68, 78, 255)     -- Accent EVO #cf444e : "Cible / Danger"
local COLOR_OUTLINE = Color(0, 0, 0, 255)               -- Outline noir (lisibilité)
local COLOR_GLOW_LOCATION = Color(236, 237, 243, 40)    -- Glow clair discret
local COLOR_GLOW_DANGER = Color(207, 68, 78, 55)        -- Glow accent

-- Couleurs réutilisables dans le HUDPaint (évite GC)
local _c_temp = Color(0, 0, 0, 0)
local _c_white_alpha = Color(255, 255, 255, 0)
local _c_black_alpha = Color(0, 0, 0, 0)

-- =====================
-- Table locale des pings actifs
-- =====================
local active_pings = {}

-- =====================
-- Polices DA EVO : Bebas Neue (titres de toutes les UIs EVO) + Roboto (données).
-- =====================
surface.CreateFont("BleachPing:Label", {
    font = "Bebas Neue",
    size = 26,
    weight = 400,
    extended = true,
    antialias = true,
})

surface.CreateFont("BleachPing:Distance", {
    font = "Roboto",
    size = 15,
    weight = 600,
    antialias = true,
})

surface.CreateFont("BleachPing:Owner", {
    font = "Roboto",
    size = 13,
    weight = 500,
    antialias = true,
})

-- =====================
-- Envoi de la demande de ping au serveur
-- Effectue un trace depuis les yeux du joueur pour trouver
-- le point d'impact et détecter si c'est une entité.
-- =====================
local function SendPingRequest()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    -- Origine + direction du trace : par défaut les yeux du perso. Si la caméra
    -- ORBITALE (3e personne stationnaire) est active, ply:EyeAngles() est FIGÉ ->
    -- on vise avec la VRAIE vue caméra (CitronOrbitCam.GetView) pour pinger là où
    -- l'écran pointe. GetView() renvoie nil hors orbite -> repli sur les yeux.
    local startPos = ply:EyePos()
    local dir = ply:EyeAngles():Forward()
    if CitronOrbitCam and CitronOrbitCam.GetView then
        local oPos, oAng = CitronOrbitCam.GetView()
        if oPos and oAng then
            startPos = oPos
            dir = oAng:Forward()
        end
    end

    local trace = util.TraceLine({
        start = startPos,
        endpos = startPos + dir * PING_TRACE_DISTANCE,
        filter = ply,
    })
    if not trace.Hit then return end -- Rien touché

    local ping_pos = trace.HitPos
    local hit_ent = trace.Entity
    local has_entity = false

    -- Détection contextuelle : entité (NPC ou joueur) = ping danger
    if IsValid(hit_ent) and (hit_ent:IsNPC() or (hit_ent:IsPlayer() and hit_ent ~= ply)) then
        has_entity = true
    end

    -- Envoi réseau au serveur
    net.Start("Bleach:Ping:Request")
        net.WriteVector(ping_pos)
        net.WriteBool(has_entity)
        if has_entity then
            net.WriteEntity(hit_ent)
        end
    net.SendToServer()
end

-- =====================
-- Hook KeyPress : détection de la touche de ping via le système de bind
-- Utilise un hook événementiel au lieu d'un Think (performance)
-- =====================
hook.Add("PlayerButtonDown", "Bleach:Ping:KeyDetect", function(ply, button)
    if ply ~= LocalPlayer() then return end
    local ping_key = ply:GetBindKey("ping")
    if ping_key and button == ping_key then
        SendPingRequest()
    end
end)

-- =====================
-- Commandes console pour déclencher le ping (dont l'usage bindable « bind g +bleach_ping »).
-- SendPingRequest est défini au-dessus -> les callbacks le voient à l'exécution.
-- =====================
concommand.Add("bleach_ping_now", function() SendPingRequest() end)
concommand.Add("+bleach_ping", function() SendPingRequest() end) -- ping à la PRESSION (bind « + »)
concommand.Add("-bleach_ping", function() end)                   -- relâchement : no-op

-- =====================
-- Réception du ping validé par le serveur
-- On stocke le ping dans la table locale pour le dessiner
-- =====================
net.Receive("Bleach:Ping:Broadcast", function()
    local ping_pos = net.ReadVector()
    local has_ent = net.ReadBool()
    local ent = nil

    if has_ent then
        ent = net.ReadEntity()
    end

    local duration = net.ReadUInt(8)
    local owner = net.ReadEntity()

    -- Supprime le ping précédent du même joueur (remplacement)
    for i = #active_pings, 1, -1 do
        if IsValid(owner) and active_pings[i].owner == owner then
            table.remove(active_pings, i)
        end
    end

    -- Création du ping dans la table active
    active_pings[#active_pings + 1] = {
        pos = ping_pos,
        has_ent = has_ent,
        ent = ent,
        start = CurTime(),
        duration = duration,
        owner = owner,
    }
end)

-- =====================
-- Dessin d'un losange (forme diamant) stylisé - motif récurrent anime
-- =====================
local _diamond_poly = { {x=0,y=0}, {x=0,y=0}, {x=0,y=0}, {x=0,y=0} }

local function DrawDiamond(x, y, size, color)
    draw.NoTexture()
    surface_SetDrawColor(color)
    _diamond_poly[1].x = x;              _diamond_poly[1].y = y - size
    _diamond_poly[2].x = x + size * 0.6; _diamond_poly[2].y = y
    _diamond_poly[3].x = x;              _diamond_poly[3].y = y + size
    _diamond_poly[4].x = x - size * 0.6; _diamond_poly[4].y = y
    surface.DrawPoly(_diamond_poly)
end

-- =====================
-- Dessin de lignes fines décoratives (style HUD anime)
-- =====================
local function DrawAccentLines(x, y, width, color)
    surface_SetDrawColor(color)
    -- Ligne horizontale fine sous le marqueur
    surface_DrawRect(x - width * 0.5, y, width, 1)
    -- Petits tirets aux extrémités
    surface_DrawRect(x - width * 0.5, y - 2, 1, 5)
    surface_DrawRect(x + width * 0.5, y - 2, 1, 5)
end

-- =====================
-- Indicateur directionnel (bord d'écran) - losange anime
-- =====================
local function DrawEdgeIndicator(screen_pos, color, alpha)
    local sw, sh = ScrW(), ScrH()
    local cx, cy = sw * 0.5, sh * 0.5
    local margin = 50

    local dx = screen_pos.x - cx
    local dy = screen_pos.y - cy
    local abs_dx = math_abs(dx)
    local abs_dy = math_abs(dy)

    if abs_dx < 1 and abs_dy < 1 then return end

    local scale_x = (sw * 0.5 - margin) / abs_dx
    local scale_y = (sh * 0.5 - margin) / abs_dy
    local scale = math.min(scale_x, scale_y)

    local edge_x = cx + dx * scale
    local edge_y = cy + dy * scale

    -- Losange directionnel avec glow
    _c_temp.r = color.r; _c_temp.g = color.g; _c_temp.b = color.b
    _c_temp.a = alpha * 0.3
    DrawDiamond(edge_x, edge_y, 10, _c_temp)
    _c_temp.a = alpha
    DrawDiamond(edge_x, edge_y, 6, _c_temp)

    -- Petit contour noir (manga outline)
    _c_black_alpha.a = alpha * 0.5
    DrawDiamond(edge_x, edge_y, 7, _c_black_alpha)
    _c_temp.a = alpha
    DrawDiamond(edge_x, edge_y, 5, _c_temp)
end

-- =====================
-- RENDU HUD : style anime / manga / Bleach RP
--
-- ToScreen() : convertit une position 3D -> coordonnées 2D écran
--   .x / .y  = position pixel sur l'écran
--   .visible = true si le point est DEVANT la caméra
-- =====================
hook.Add("HUDPaint", "Bleach:Ping:DrawPings", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local cur = CurTime()
    local ply_pos = ply:GetPos()

    for i = #active_pings, 1, -1 do
        local ping = active_pings[i]
        local elapsed = cur - ping.start
        local remaining = ping.duration - elapsed

        -- Suppression des pings expirés
        if remaining <= 0 then
            table.remove(active_pings, i)
        else
            -- Position dynamique (suivi d'entité)
            local world_pos = ping.pos
            if ping.has_ent and IsValid(ping.ent) then
                world_pos = ping.ent:GetPos() + ping.ent:OBBCenter()
            end

            -- Conversion 3D -> 2D (offset vertical pour le marqueur au-dessus)
            local screen = (world_pos + Vector(0, 0, 20)):ToScreen()

            -- Opacité avec fade-out progressif
            local alpha = 255
            if remaining < FADE_START then
                alpha = math_floor(255 * (remaining / FADE_START))
            end
            alpha = math_Clamp(alpha, 0, 255)

            -- Couleurs selon le type
            local is_danger = ping.has_ent
            local ping_color = is_danger and COLOR_PING_DANGER or COLOR_PING_LOCATION
            local glow_color = is_danger and COLOR_GLOW_DANGER or COLOR_GLOW_LOCATION

            if screen.visible then
                local sx, sy = screen.x, screen.y

                -- =====================
                -- Pulsation TRÈS subtile (DA EVO propre : plus de wobble ni de flottement anime).
                -- =====================
                local breathe = math_sin(cur * 3) * 0.06 + 1 -- oscille entre 0.94 et 1.06

                -- =====================
                -- GLOW : halo lumineux derrière le marqueur
                -- =====================
                local glow_size = 30 * breathe
                _c_temp.r = glow_color.r; _c_temp.g = glow_color.g; _c_temp.b = glow_color.b; _c_temp.a = alpha * 0.15
                draw_RoundedBox(math_floor(glow_size),
                    sx - glow_size, sy - glow_size,
                    glow_size * 2, glow_size * 2,
                    _c_temp)

                -- =====================
                -- MARQUEUR PRINCIPAL : double losange superposé (style anime)
                -- Losange extérieur (contour sombre)
                -- =====================
                local diamond_size = 14 * breathe
                _c_black_alpha.a = alpha * 0.8
                DrawDiamond(sx, sy, diamond_size + 2, _c_black_alpha)
                -- Losange principal (couleur du ping)
                _c_temp.r = ping_color.r; _c_temp.g = ping_color.g; _c_temp.b = ping_color.b; _c_temp.a = alpha
                DrawDiamond(sx, sy, diamond_size, _c_temp)
                -- Losange intérieur lumineux (coeur brillant)
                _c_white_alpha.a = alpha * 0.9
                DrawDiamond(sx, sy, diamond_size * 0.45, _c_white_alpha)

                -- =====================
                -- Ligne verticale fine au-dessus du marqueur (style waypoint anime)
                -- =====================
                local line_height = 25
                surface_SetDrawColor(ping_color.r, ping_color.g, ping_color.b, alpha * 0.6)
                surface_DrawRect(sx, sy - diamond_size - line_height, 1, line_height)

                -- Petit losange au sommet de la ligne
                _c_temp.r = ping_color.r; _c_temp.g = ping_color.g; _c_temp.b = ping_color.b; _c_temp.a = alpha * 0.8
                DrawDiamond(sx, sy - diamond_size - line_height - 4, 3, _c_temp)

                -- =====================
                -- Lignes décoratives horizontales sous le marqueur
                -- =====================
                local accent_y = sy + diamond_size + 6
                _c_temp.a = alpha * 0.4
                DrawAccentLines(sx, accent_y, 50, _c_temp)

                -- =====================
                -- LABEL : texte du type de ping (outlined, style manga)
                -- =====================
                local label = is_danger and "CIBLE" or "ALLER ICI"
                local label_y = accent_y + 6

                _c_temp.r = ping_color.r; _c_temp.g = ping_color.g; _c_temp.b = ping_color.b; _c_temp.a = alpha
                _c_black_alpha.a = alpha
                draw_SimpleTextOutlined(
                    label,
                    "BleachPing:Label",
                    sx, label_y,
                    _c_temp,
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP,
                    2, _c_black_alpha
                )

                -- =====================
                -- DISTANCE en mètres (police HeliosExt, style données anime)
                -- =====================
                local dist_units = ply_pos:Distance(world_pos)
                local dist_meters = math_floor(dist_units * UNITS_TO_METERS)
                local dist_text = dist_meters .. "m"

                surface_SetFont("BleachPing:Label")
                local _, lh = surface_GetTextSize(label)

                _c_white_alpha.a = alpha * 0.85
                _c_black_alpha.a = alpha * 0.9
                draw_SimpleTextOutlined(
                    dist_text,
                    "BleachPing:Distance",
                    sx, label_y + lh + 2,
                    _c_white_alpha,
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP,
                    1, _c_black_alpha
                )

                -- =====================
                -- NOM de l'auteur (au-dessus, style italic discret)
                -- =====================
                if IsValid(ping.owner) then
                    -- Nom RP (NWString "Nickname") et non le nom Steam (:Nick()).
                    -- Repli sur le nom Steam seulement si aucun nom RP défini.
                    -- Masque d'anonymat / presentation (09/08) : source unique lzy_meet.
                    -- Sans ca, un masque se trahissait au premier ping.
                    local owner_name
                    if EVO_GetRPDisplayName then
                        owner_name = EVO_GetRPDisplayName(ping.owner)
                    else
                        owner_name = ping.owner:GetEvoNWString("Nickname", "")
                        if owner_name == "" then owner_name = ping.owner:Nick() end
                    end
                    _c_white_alpha.a = alpha * 0.5
                    _c_black_alpha.a = alpha * 0.5
                    draw_SimpleTextOutlined(
                        owner_name,
                        "BleachPing:Owner",
                        sx, sy - diamond_size - line_height - 20,
                        _c_white_alpha,
                        TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM,
                        1, _c_black_alpha
                    )
                end

                -- =====================
                -- PULSE d'apparition (anime energy burst)
                -- Double ring qui s'agrandit avec fade rapide
                -- =====================
                if elapsed < 0.8 then
                    local pulse_t = elapsed / 0.8
                    local ring_size = diamond_size + 40 * pulse_t
                    local ring_alpha = math_floor(alpha * (1 - pulse_t) * 0.6)

                    _c_temp.r = ping_color.r; _c_temp.g = ping_color.g; _c_temp.b = ping_color.b
                    _c_temp.a = ring_alpha * 0.3
                    DrawDiamond(sx, sy, ring_size, _c_temp)
                    _c_temp.a = ring_alpha
                    DrawDiamond(sx, sy, ring_size * 0.7, _c_temp)
                end

            else
                -- Ping derrière la caméra : indicateur directionnel sur le bord
                DrawEdgeIndicator(screen, ping_color, alpha)
            end
        end
    end
end)

-- =====================
-- Nettoyage des pings lors du changement de map ou respawn
-- =====================
hook.Add("InitPostEntity", "Bleach:Ping:ClearOnLoad", function()
    active_pings = {}
end)
