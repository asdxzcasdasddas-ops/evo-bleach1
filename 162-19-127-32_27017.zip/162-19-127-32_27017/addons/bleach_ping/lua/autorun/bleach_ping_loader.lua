-- "addons\\bleach_ping\\lua\\autorun\\bleach_ping_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================
-- Bleach Ping System - Loader
-- Charge les fichiers serveur et client du système de ping
-- ============================================================

if SERVER then
    AddCSLuaFile("bleach_ping/cl_waypoints.lua")

    include("bleach_ping/sv_waypoints.lua")
end

if CLIENT then
    include("bleach_ping/cl_waypoints.lua")
end
