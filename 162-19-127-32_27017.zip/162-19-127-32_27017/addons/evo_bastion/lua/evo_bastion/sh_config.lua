-- "addons\\evo_bastion\\lua\\evo_bastion\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BASTION — config partagée. Plusieurs cartes par map (Shinigami et/ou
-- Hollow). pos = setpos du user (hauteur des yeux, noclip) : le rendu snappe
-- au sol tout seul, la carte flotte à CardHeight au-dessus du sol.
-- ============================================================================
EVO_BASTION = EVO_BASTION or {}

EVO_BASTION.Config = {
	Bastions = {
		["hueco_mundo_v1"] = {
			{ faction = "Shinigami", name = "Bastion Shinigami", pos = Vector(-6229.97, 9646.71, 9883.84) }, -- setpos user 08/27
		},
		["rp_seireitei_v1"] = {
			{ faction = "Hollow", name = "Bastion Hollow", pos = Vector(9999.29, -8772.34, -7128.02) }, -- setpos user 08/27
		},
	},

	CardHeight  = 250,  -- hauteur de la carte au-dessus du sol (comme les drapeaux)
	CardScale   = 0.25,
	CardMaxDist = 2000, -- carte visible en dessous de cette distance

	Colors = {
		Shinigami = Color(80, 170, 255),
		Hollow    = Color(207, 68, 78),
	},
	-- Icônes de faction de l'écran de choix (les mêmes que les drapeaux).
	Icons = {
		Shinigami = "l1acam515ehakdj3/6i05nkvlbs70099.png",
		Hollow    = "l1acam515ehakdj3/kflc5qgaqm0fcm4o9.png",
	},
}

local MAP_HOME_FACTION = {
	["hueco_mundo_v1"] = "Hollow",
	["rp_seireitei_v1"] = "Shinigami",
}

function EVO_BASTION.ListForMap(sMap)
	sMap = sMap or game.GetMap()
	local raw = EVO_BASTION.Config.Bastions and EVO_BASTION.Config.Bastions[sMap]
	if not istable(raw) then return {} end
	-- Ancien format : un seul objet { pos, faction } par map.
	if isvector(raw.pos) then return { raw } end
	return raw
end

function EVO_BASTION.GetForMap(sMap)
	return EVO_BASTION.ListForMap(sMap)[1]
end

--- Faction adverse de la map (Shinigami dans le Hueco, Hollow au Seireitei).
function EVO_BASTION.EnemyFactionForMap(sMap)
	local home = MAP_HOME_FACTION[sMap or game.GetMap()]
	if home == "Hollow" then return "Shinigami" end
	if home == "Shinigami" then return "Hollow" end
	return "Shinigami"
end
