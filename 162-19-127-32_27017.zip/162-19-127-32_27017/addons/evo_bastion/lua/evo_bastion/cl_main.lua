-- "addons\\evo_bastion\\lua\\evo_bastion\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BASTION — rendu client. Même recette que le panneau des drapeaux
-- (flagcapture cl_hud) : carte sombre DA EVO face à la CAMÉRA DE RENDU (EyePos,
-- caméra orbitale comprise) avec l'icône de faction et son halo. Aucun marquage
-- au sol (retiré à la demande du user 08/27).
-- ============================================================================
if not CLIENT then return end

EVO_BASTION = EVO_BASTION or {}
local CFG = EVO_BASTION.Config

surface.CreateFont("EVO_Bastion_Name", { font = "Bebas Neue", size = 64, weight = 800, antialias = true, extended = true })
surface.CreateFont("EVO_Bastion_Fac",  { font = "Bebas Neue", size = 46, weight = 700, antialias = true, extended = true })
surface.CreateFont("EVO_Bastion_Text", { font = "Roboto",     size = 28, weight = 600, antialias = true, extended = true })

local COL_CARD  = Color(14, 14, 17, 240)
local COL_WHITE = Color(237, 238, 242)
local COL_GREY  = Color(150, 154, 162)

local mats = {}
local function facIcon(sFaction)
	local m = mats[sFaction]
	if m == nil then
		local p = CFG.Icons and CFG.Icons[sFaction]
		m = p and Material(p, "smooth") or false
		if m and m:IsError() then m = false end
		mats[sFaction] = m
	end
	return m or nil
end

local function facColor(sFaction)
	return (CFG.Colors and CFG.Colors[sFaction]) or COL_GREY
end

-- Sol sous le setpos : cache par carte, invalidé si la pose bouge.
local grounds = {}
local function groundOf(idx, vPos)
	local key = math.floor(vPos.x) .. ":" .. math.floor(vPos.y) .. ":" .. math.floor(vPos.z)
	local slot = grounds[idx]
	if slot and slot.key == key then return slot.data end
	local tr = util.TraceLine({ start = vPos + Vector(0, 0, 16), endpos = vPos - Vector(0, 0, 2500), mask = MASK_SOLID_BRUSHONLY })
	if not (tr.Hit and not tr.StartSolid) then
		tr = util.TraceLine({ start = vPos + Vector(0, 0, 16), endpos = vPos - Vector(0, 0, 2500), mask = MASK_NPCWORLDSTATIC })
	end
	if not (tr.Hit and not tr.StartSolid) then
		grounds[idx] = nil
		return nil
	end
	local data = { pos = tr.HitPos + Vector(0, 0, 2), normal = tr.HitNormal }
	grounds[idx] = { key = key, data = data }
	return data
end

local function drawCard(b, g)
	local col = facColor(b.faction)
	local cardPos = g.pos + Vector(0, 0, CFG.CardHeight or 250)
	local ang = Angle(0, (cardPos - EyePos()):Angle().y - 90, 90)
	local icon = facIcon(b.faction)
	local sFac = string.upper(b.faction or "")
	local pulse = 0.5 + 0.5 * math.sin(CurTime() * 2)

	cam.Start3D2D(cardPos, ang, b.scale or CFG.CardScale or 0.25)
		local w, h   = 600, 340
		local x0, y0 = -w / 2, -h / 2
		draw.RoundedBox(24, x0, y0, w, h, COL_CARD)
		draw.SimpleText("BASTION", "EVO_Bastion_Name", 0, y0 + 50, COL_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.RoundedBox(2, -90, y0 + 88, 180, 4, col)
		if icon then
			local isize = 132
			surface.SetMaterial(icon)
			surface.SetDrawColor(col.r, col.g, col.b, 40 + math.floor(35 * pulse))
			local hs = isize * (1.22 + 0.08 * pulse)
			surface.DrawTexturedRect(-hs / 2, -hs / 2 + 6, hs, hs)
			surface.SetDrawColor(col.r, col.g, col.b, 255)
			surface.DrawTexturedRect(-isize / 2, -isize / 2 + 6, isize, isize)
		end
		draw.SimpleText(sFac, "EVO_Bastion_Fac", 0, y0 + h - 78, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("AVANT-POSTE EN TERRITOIRE ENNEMI", "EVO_Bastion_Text", 0, y0 + h - 40, COL_GREY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end

hook.Add("PostDrawTranslucentRenderables", "EVO_Bastion::Draw", function(bDepth, bSky)
	if bDepth or bSky then return end
	local list = EVO_BASTION.ListForMap and EVO_BASTION.ListForMap()
	if not istable(list) or #list == 0 then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local nMax = CFG.CardMaxDist or 2000
	local maxSqr = nMax * nMax
	local eye = lp:GetPos()
	for i, b in ipairs(list) do
		if istable(b) and isvector(b.pos) then
			local g = groundOf(i, b.pos)
			if g and eye:DistToSqr(g.pos) < maxSqr then
				drawCard(b, g)
			end
		end
	end
end)
