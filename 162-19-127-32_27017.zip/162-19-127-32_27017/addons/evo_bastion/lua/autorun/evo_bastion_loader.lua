-- "addons\\evo_bastion\\lua\\autorun\\evo_bastion_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BASTION — marqueur 3D des bastions (avant-postes en territoire ennemi) :
-- Bastion Shinigami dans le Hueco, Bastion Hollow au Seireitei. Purement visuel
-- (même recette que le panneau des drapeaux : anneau au sol + carte face caméra).
-- ============================================================================
EVO_BASTION = EVO_BASTION or {}

if SERVER then
	AddCSLuaFile("evo_bastion/sh_config.lua")
	AddCSLuaFile("evo_bastion/cl_main.lua")
	include("evo_bastion/sh_config.lua")
else
	include("evo_bastion/sh_config.lua")
	include("evo_bastion/cl_main.lua")
end
