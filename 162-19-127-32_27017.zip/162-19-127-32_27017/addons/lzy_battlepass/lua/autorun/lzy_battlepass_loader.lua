-- "addons\\lzy_battlepass\\lua\\autorun\\lzy_battlepass_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_battlepass/config.lua")
	AddCSLuaFile("lzy_battlepass/cl_main.lua")
	AddCSLuaFile("lzy_battlepass/cl_themes.lua")
	AddCSLuaFile("lzy_battlepass/cl_theme_admin.lua")
	-- Les textures des thèmes sont distribuées par le pack Workshop.
	include("lzy_battlepass/config.lua")
	include("lzy_battlepass/sv_themes.lua")
	include("lzy_battlepass/sv_main.lua")
else
	include("lzy_battlepass/config.lua")
	include("lzy_battlepass/cl_themes.lua")
	include("lzy_battlepass/cl_theme_admin.lua")
    include("lzy_battlepass/cl_main.lua")
end
