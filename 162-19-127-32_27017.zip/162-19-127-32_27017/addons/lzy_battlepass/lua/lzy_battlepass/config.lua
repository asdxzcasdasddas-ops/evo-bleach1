-- "addons\\lzy_battlepass\\lua\\lzy_battlepass\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
BATTLEPASS_CONFIG = BATTLEPASS_CONFIG or {}

BATTLEPASS_CONFIG.reward_time = 1 -- (obsolète : ancien mode "1 palier/jour", remplacé par l'XP)
BATTLEPASS_CONFIG.premium_price = 2000 -- in coins

-- PROGRESSION FAÇON FORTNITE : on gagne de l'XP de BATTLE PASS via les activités, et chaque
-- palier coûte `xp_per_level`. (30 paliers x 1000 = 30000 XP pour finir la saison.)
-- CALIBRAGE : ~8h/jour -> saison finie en ~20 jours. Le temps de jeu est le socle
-- (180 XP/h = 1440 XP/8h -> 30000/1440 ≈ 21 jours en jeu seul) ; les activités accélèrent.
BATTLEPASS_CONFIG.xp_per_level = 1000
BATTLEPASS_CONFIG.xp_sources = {
	quest             = 0,    -- quête normale : NE donne PLUS d'XP de pass (seules les quotidiennes, demande user)
	daily_quest       = 250,  -- quête QUOTIDIENNE : calibré 4/jour x 250 = 1000/jour -> 30000/1000 = 30 jours pile
	npc_kill          = 0,    -- PNJ tué : désactivé (plus d'XP de pass)
	boss_kill         = 0,    -- boss tué : désactivé (plus d'XP de pass)
	playtime          = 30,   -- par intervalle de temps de jeu (GARDÉ, demande user)
	playtime_interval = 10,   -- minutes  ->  30 XP / 10 min = 180 XP/h
}

-- SAISON : le battlepass dure `duration_days` jours puis se RENOUVELLE automatiquement.
-- `GetEndDate()` renvoie la date de fin (string "YYYY-MM-DD") de la saison COURANTE,
-- alignée sur des cycles de `duration_days` jours depuis `season_anchor` (déterministe).
-- Sert d'expiration du premium (lzy_reroll : premium actif tant que la date stockée
-- == saison courante). La PROGRESSION (XP / paliers) utilise `GetProgressKey()`, pas
-- cette date seule — sinon un swap d'items en cours de cycle (2026-08-29) laisse
-- tout le monde au même palier, et un serveur resté allumé copie l'XP dans la nouvelle clé.
BATTLEPASS_CONFIG.duration_days = 40 -- durée d'une SAISON (jours) ; reset auto pour TOUS à la fin. NB : le pass se TERMINE déjà en ~30 j via les quotidiennes (daily_quest=250), sans toucher à la saison. Passer la saison à 30 EXIGE une migration BDD (bp_end_date) sinon RESET XP de pass + RÉVOCATION premium payé -> en attente décision user.
BATTLEPASS_CONFIG.season_anchor = "2026-01-01" -- ancre (00:00) des cycles, alignée pour tout le monde
-- Piste de récompenses. Bump +1 à CHAQUE rotation d'items (nouvelle "saison contenu"),
-- même si le calendrier `GetEndDate()` n'a pas encore bougé. Ne pas réutiliser un id.
-- 2 = piste 2026-08-29 (pets / Slash / Gin). 1 = piste lunette / Tetsu / cigare / éventails.
-- 3..7 = passes PLANIFIÉS par saison (cf. `BATTLEPASS_CONFIG.seasons` en bas de fichier) :
-- la valeur ci-dessous est celle de la piste de BASE (saison en cours, fin 2026-10-08) ;
-- ApplySeasonContent() la remplace par celle de la saison courante dès la suivante.
BATTLEPASS_CONFIG.content_id = 2
-- Cycle de saison contenant `now` : { from, to } (epochs, fin EXCLUE = instant du reset)
-- + s = "YYYY-MM-DD" de la fin. Mémoïsé PAR INDEX de cycle (GetEndDate est appelé à chaque
-- frame par le timer du menu, et aussi sur des dates d'événements par les thèmes UI :
-- zéro mktime / os.date en régime établi, et les deux usages ne se chassent pas).
local anchorEpoch, cycleSig
local cycleCache = {} -- [idx] = { from, to, s }
local function seasonCycle(now)
	-- Signature (ancre + durée) testée d'abord : un changement de config à chaud (lua_run)
	-- vide le cache au lieu de servir des cycles périmés.
	local sAnchor = tostring(BATTLEPASS_CONFIG.season_anchor or "2026-01-01")
	local dur = math.max(1, math.floor(tonumber(BATTLEPASS_CONFIG.duration_days) or 30)) * 86400
	local sig = sAnchor .. "|" .. dur
	if sig ~= cycleSig then
		cycleSig = sig
		cycleCache = {}
		local y, m, d = sAnchor:match("(%d+)-(%d+)-(%d+)")
		anchorEpoch = os.time({ year = tonumber(y) or 2026, month = tonumber(m) or 1, day = tonumber(d) or 1, hour = 0, min = 0, sec = 0 })
	end
	local idx = math.floor((now - anchorEpoch) / dur)
	if idx < 0 then idx = 0 end
	local c = cycleCache[idx]
	if not c then
		local from, to = anchorEpoch + idx * dur, anchorEpoch + (idx + 1) * dur
		c = { from = from, to = to, s = os.date("%Y-%m-%d", to) }
		cycleCache[idx] = c
	end
	return c
end
function BATTLEPASS_CONFIG.GetEndDate(now)
	return seasonCycle(now or os.time()).s
end

-- Habillage uniquement : ne modifie ni les récompenses, ni les clés XP/premium.
-- Le mode manuel se choisit avec la commande superadmin !battlepass_ui.
BATTLEPASS_CONFIG.ui_theme_events = {
	{ date = "2026-10-31", theme = "halloween" },
	{ date = "2026-12-25", theme = "noel" },
}
function BATTLEPASS_CONFIG.GetScheduledUITheme(at_time)
	local season_end = BATTLEPASS_CONFIG.GetEndDate(at_time)
	for _, event in ipairs(BATTLEPASS_CONFIG.ui_theme_events or {}) do
		local y, m, d = tostring(event.date):match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
		if y and (event.theme == "halloween" or event.theme == "noel") then
			local event_time = os.time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 12 })
			if BATTLEPASS_CONFIG.GetEndDate(event_time) == season_end then return event.theme end
		end
	end
	return "normal"
end
BATTLEPASS_CONFIG.GetUITheme = BATTLEPASS_CONFIG.GetScheduledUITheme
function BATTLEPASS_CONFIG.GetProgressKey()
	-- Le contenu (donc content_id) suit la saison : posé ICI pour que la clé soit toujours
	-- celle de la saison courante (le timer serveur BattlePass_RefreshSeason lit cette clé
	-- toutes les 60 s -> rollover + rechargement des joueurs au changement de saison).
	-- Un seul `now` pour la saison ET le contenu : pas de clé bâtarde à la seconde du passage.
	local now = os.time()
	local endDate = BATTLEPASS_CONFIG.GetEndDate(now)
	if BATTLEPASS_CONFIG.ApplySeasonContent then BATTLEPASS_CONFIG.ApplySeasonContent(endDate) end
	local cid = math.max(1, math.floor(tonumber(BATTLEPASS_CONFIG.content_id) or 1))
	return endDate .. ":" .. cid
end
-- Valeur courante (recalculée périodiquement côté serveur, cf. sv_main.lua) — lue aussi
-- par lzy_reroll / lzy_shop. Ne JAMAIS remettre une date fixe ici.
BATTLEPASS_CONFIG.end_date = BATTLEPASS_CONFIG.GetEndDate()

-- Secondes restantes avant la FIN (reset) de la saison courante -> alimente le TIMER du menu.
function BATTLEPASS_CONFIG.GetSecondsLeft()
	local now = os.time()
	return math.max(0, seasonCycle(now).to - now) -- instant EXACT du reset (pas de re-parse de la date)
end

-- Rerolls : colonnes DB (players) + libellés par catégorie (cf. lzy_shop REROLL_CONFIG).
-- Prix unitaire en coins (pour info / dosage) : art=300, aura=150, style=150, combat=200.
local REROLL_COLS = {
	art_spirituel   = "rerolls_art_spirituel",
	aura_spirituel  = "rerolls_aura_spirituel",
	style_execution = "rerolls_style_execution",
	combat_style    = "rerolls_combat_style",
}
local REROLL_LABEL = {
	art_spirituel   = "Art spirituel",
	aura_spirituel  = "Aura spirituel",
	style_execution = "Style d'exécution",
	combat_style    = "Style de combat",
}
-- Descriptions affichées au survol (tooltip) — expliquent chaque type de récompense.
local REROLL_DESC = {
	art_spirituel   = "Jeton de reroll : permet de relancer ton ART SPIRITUEL (ton pouvoir) dans le menu de reroll.",
	aura_spirituel  = "Jeton de reroll : permet de relancer ton AURA SPIRITUELLE dans le menu de reroll.",
	style_execution = "Jeton de reroll : permet de relancer ton STYLE D'EXÉCUTION (finisher) dans le menu de reroll.",
	combat_style    = "Jeton de reroll : permet de relancer ton STYLE DE COMBAT dans le menu de reroll.",
}
local DESC_XP  = "Expérience : fait progresser ton niveau de personnage."
local DESC_YEN = "Yens : la monnaie en jeu (achats, services, échanges...)."

-- ============================================================================
-- RÉCOMPENSES : chaque palier appelle BATTLEPASS_CONFIG.GiveReward(ply, { ... }).
--   xp     -> ply:AddXP() (niveau du joueur)
--   yens   -> characters.money du PERSO ACTIF (argent in-game)
--   coins  -> players.coins (par COMPTE) + popup (gardé pour flexibilité, non utilisé ici)
--   reroll -> { categorie, nombre } : +N rerolls de la catégorie (players.rerolls_<cat>)
-- (Serveur uniquement — claim_function n'est appelée que côté serveur.)
-- ============================================================================
function BATTLEPASS_CONFIG.GiveReward(ply, r)
	if not SERVER or not IsValid(ply) or type(r) ~= "table" then return end
	local sid = ply:SteamID64()

	-- XP (niveau joueur). Pendant "Récupérer tout", ClaimAll accumule dans
	-- `_bpClaimXP` puis verse une seule fois : AddXP est un SELECT+SET, pas un
	-- incrément SQL, donc N appels parallèles s'écrasaient (last write wins).
	if (tonumber(r.xp) or 0) > 0 then
		local amt = math.floor(r.xp)
		if ply._bpClaimXP ~= nil then
			ply._bpClaimXP = ply._bpClaimXP + amt
		elseif isfunction(ply.AddXP) then
			ply:AddXP(amt)
		end
	end

	-- Coins (par compte Steam)
	if (tonumber(r.coins) or 0) > 0 and MUGEN and MUGEN.Query then
		local amt = math.floor(r.coins)
		MUGEN.Query(string.format("UPDATE players SET coins = coins + %d WHERE steamid64 = '%s'", amt, sid))
		ply:SetEvoNWInt("coins", ply:GetEvoNWInt("coins", 0) + amt)
		if util.NetworkStringToID("EVO:CoinsReceived") ~= 0 then
			net.Start("EVO:CoinsReceived") net.WriteUInt(amt, 32) net.Send(ply)
		end
	end

	-- Yens (argent in-game = characters.money du perso ACTIF)
	if (tonumber(r.yens) or 0) > 0 and MUGEN and MUGEN.Query then
		local amt = math.floor(r.yens)
		MUGEN.Query(string.format("UPDATE characters SET money = money + %d WHERE steamid64 = '%s' AND unique_id = %s", amt, sid, sql.SQLStr(ply:GetUniqueID())))
		ply:SetEvoNWInt("Money", ply:GetEvoNWInt("Money", 0) + amt)
		if MUGEN.Notify then MUGEN.Notify(ply, "Battle Pass : +" .. amt .. " yens", NOTIFY_GENERIC, 4) end
	end

	-- Reroll (stock par COMPTE : players.rerolls_<cat>, comme l'achat boutique)
	if istable(r.reroll) and MUGEN and MUGEN.Query then
		local col = REROLL_COLS[r.reroll[1]]
		local cnt = math.floor(tonumber(r.reroll[2]) or 0)
		if col and cnt > 0 then
			MUGEN.Query(string.format("UPDATE players SET `%s` = `%s` + %d WHERE steamid64 = '%s'", col, col, cnt, sid))
			ply:SetEvoNWInt(col, ply:GetEvoNWInt(col, 0) + cnt)
			if MUGEN.Notify then MUGEN.Notify(ply, "Battle Pass : +" .. cnt .. " reroll (" .. (REROLL_LABEL[r.reroll[1]] or r.reroll[1]) .. ")", NOTIFY_GENERIC, 4) end
		end
	end

	-- Cosmétique : dépose l'item dans le sac du PERSO ACTIF + débloque au niveau COMPTE
	-- (lzy_shop_unlocks, faction '' = toutes factions). Même registre que la boutique
	-- coins / Stripe : re-donné à chaque perso au chargement, indép. de la saison.
	if isstring(r.cosmetic) and r.cosmetic ~= "" then
		local iid = r.cosmetic
		-- Unlock compte D'ABORD : si l'inventaire du perso n'est pas encore chargé (GiveItem échoue
		-- en silence), l'item est livré au prochain chargement de perso (hook inventory.Loaded).
		-- faction '' : le pass est PAR COMPTE, pas par faction du perso qui claim.
		if LZY_Shop_RecordUnlock then LZY_Shop_RecordUnlock(ply, iid, "") end
		-- "Récupérer tout" : on n'appelle PAS GiveItem ici. ClaimAll verse la
		-- liste d'un coup via GiveMultipleItems (un persist, pas N qui s'écrasent).
		if istable(ply._bpClaimItems) then
			ply._bpClaimItems[#ply._bpClaimItems + 1] = iid
		elseif isfunction(ply.GiveItem) then
			ply:GiveItem(iid)
		end
		if MUGEN and MUGEN.Notify then MUGEN.Notify(ply, "Battle Pass : cosm\195\169tique d\195\169bloqu\195\169 (voir l'inventaire)", NOTIFY_GENERIC, 5) end
	end
end

-- Icônes par TYPE (1 récompense/palier -> 1 icône). Chemins tels qu'existant dans leur
-- workshop (reroll/coin sans préfixe, yen/xp avec "materials/" — correct, cf. HUD).
local ICON_XP     = "materials/5pmtpk9ip4xmoxoe/6assh2s06ssp2u7n/3n28ikvi123q32u.png" -- icône XP (générique BP)
local ICON_YEN    = "materials/yc5uunqp9of5t/dtv26o0y16owrlzi.png"                    -- icône yens (= money HUD)
local ICON_REROLL = "fe4zd3gqw9qxmx3m2/zj98eqipe4n30ru/lfofrmuvza8mw.png"             -- icône reroll (= boutique reroll)
-- Taille de dessin (fraction de la case 120px, centrée).
local SCALE_XP, SCALE_YEN, SCALE_REROLL = 0.8, 0.45, 0.6
local SEASON_DAYS = 30 -- NOMBRE DE PALIERS par piste (progression par XP, cf. xp_per_level) ; la DURÉE de la saison est `duration_days` (40 j), pas ceci

-- Paliers "REROLL" {catégorie, nombre} (remplacent les anciens coins). Valeur = nombre x prix.
-- GRATUIT : aura(150) + style(150) + combat(200) = 500 de valeur.
local FREE_REROLLS = {
	[10] = { "aura_spirituel", 1 },
	[20] = { "style_execution", 1 },
	[30] = { "combat_style", 1 },
}
-- PREMIUM : 5 de CHAQUE catégorie = art 5x300 + aura 5x150 + style 5x150 + combat 5x200
-- = 1500 + 750 + 750 + 1000 = 4000 de valeur. (jours 21 & 30 -> XP/yens)
-- Catégories ALTERNÉES (et non groupées) pour qu'on croise art / aura / finisher (style
-- d'exécution) / style de combat tout au long de la saison. Total inchangé = 4000.
local PREMIUM_REROLLS = {
	[3]  = { "art_spirituel", 2 },   [6]  = { "aura_spirituel", 2 },
	[9]  = { "style_execution", 2 }, [12] = { "combat_style", 2 },
	[15] = { "art_spirituel", 3 },   [18] = { "aura_spirituel", 3 },
	[24] = { "style_execution", 3 }, [27] = { "combat_style", 3 },
}

-- ── Paliers GRATUITS ────────────────────────────────────────────────────────
-- UNE récompense/palier : reroll (jours 10/20/30, ~500 de valeur), sinon XP (jours
-- impairs) ou yens (jours pairs).
BATTLEPASS_CONFIG.items = {}
for i = 1, SEASON_DAYS do
	local reward, icon, qty, label, scale, desc
	local rr = FREE_REROLLS[i]
	if rr then
		reward, icon, qty, scale = { reroll = rr }, ICON_REROLL, rr[2], SCALE_REROLL
		label = rr[2] .. " reroll " .. (REROLL_LABEL[rr[1]] or rr[1])
		desc  = REROLL_DESC[rr[1]] or ""
	elseif i % 2 == 1 then
		local xp = math.floor((150 + i * 10) / 3)      -- ÷3 global XP 2026-07-26 : ~53 -> 150
		reward, icon, qty, label, scale, desc = { xp = xp }, ICON_XP, xp, xp .. " XP", SCALE_XP, DESC_XP
	else
		local yens = 300 + i * 20                       -- 340 -> 920
		reward, icon, qty, label, scale, desc = { yens = yens }, ICON_YEN, yens, yens .. " yens", SCALE_YEN, DESC_YEN
	end
	BATTLEPASS_CONFIG.items[i] = {
		name = label, description = desc, icon = icon, icon_scale = scale, quantity = qty,
		claim_function = function(ply) BATTLEPASS_CONFIG.GiveReward(ply, reward) end,
	}
end

-- ── Paliers PREMIUM (bonus) ──────────────────────────────────────────────────
-- UNE récompense/palier : reroll (8 jours, 5 de CHAQUE catégorie = 4000 de valeur),
-- sinon GROS XP (jours impairs, ~1 niveau/palier) ou yens (jours pairs).
BATTLEPASS_CONFIG.items_premium = {}
for i = 1, SEASON_DAYS do
	local reward, icon, qty, label, scale, desc
	local rr = PREMIUM_REROLLS[i]
	if rr then
		reward, icon, qty, scale = { reroll = rr }, ICON_REROLL, rr[2], SCALE_REROLL
		label = rr[2] .. " reroll " .. (REROLL_LABEL[rr[1]] or rr[1])
		desc  = REROLL_DESC[rr[1]] or ""
	elseif i % 2 == 1 then
		local xp = math.floor((500 + (i - 1) * 30) / 3) -- ÷3 global XP 2026-07-26 : ~167 -> 457
		reward, icon, qty, label, scale, desc = { xp = xp }, ICON_XP, xp, xp .. " XP", SCALE_XP, DESC_XP
	else
		local yens = 700 + (i - 1) * 40                  -- 700 -> 1860
		reward, icon, qty, label, scale, desc = { yens = yens }, ICON_YEN, yens, yens .. " yens", SCALE_YEN, DESC_YEN
	end
	BATTLEPASS_CONFIG.items_premium[i] = {
		name = label, description = desc, icon = icon, icon_scale = scale, quantity = qty,
		claim_function = function(ply) BATTLEPASS_CONFIG.GiveReward(ply, reward) end,
	}
end

-- ── RÉCOMPENSES COSMÉTIQUES (demande user 2026-07-25) ───────────────────────────────────────
-- On SURCHARGE, APRÈS les boucles, le palier du MILIEU (15) et le DERNIER (30 = SEASON_DAYS) sur
-- les 2 pistes. Le champ `model` fait afficher le vrai modèle 3D dans la tuile (cl_main.lua : si
-- `model` est posé, il prime sur `icon`) ; `icon` reste comme repli. Le grant réel = GiveReward
-- { cosmetic = <item_id> } (unlock compte lzy_shop_unlocks + dépôt dans le sac du perso actif).
-- RÉCOMPENSES DE LA PISTE DE BASE (demande user 2026-08-29, content_id = 2) — servies
-- jusqu'à la fin de la saison en cours (`base_season_end`, 2026-10-08) ; ensuite
-- ApplySeasonContent() (bas de fichier) les remplace à chaque saison par celles de
-- `BATTLEPASS_CONFIG.seasons`.
-- Quand tu changes ces 4 tuiles, bump `content_id` (sinon les paliers restent).
--   items[15]         = Pet d'épaule Petit démon (GRATUIT)  -> milieu
--   items[30]         = Slash, arme hakuda      (GRATUIT)  -> dernier
--   items_premium[15] = Pet d'épaule Fantôme    (PREMIUM)  -> milieu
--   items_premium[30] = Katana Gin              (PREMIUM)  -> dernier
-- Les deux ARMES sont créées pour le pass et n'existent nulle part ailleurs
-- (KATANA_SKINS "gin" / NCM_HAKUDA_GAUNTLETS "slash", absentes de shop_config,
-- sans `is_shikai` donc hors du rituel de la Salle Blanche) : exclusives au pass.
-- Les deux PETS existaient déjà (pet_demon_garcon / pet_fantome) et restent
-- tirables au coffre -- c'est un choix, pas un oubli.
-- Saisons précédentes (lunette_simple / katana_tetsu / cigare_croco /
-- gauntlet_eventails) : plus distribuées, mais gardées dans account_cosmetics.
--
-- account_cosmetics : ids GAGNÉS via le pass (toutes saisons). On ACCUMULE, on ne
-- reset pas quand la saison change — sert à ne pas révoquer l'unlock à la suppression
-- (pas rachetable, contrairement à la boutique).
-- ⚠ ON N'EN RETIRE JAMAIS : cette table dit à lzy_shop de NE PAS révoquer le
-- déblocage quand le joueur supprime l'objet (une récompense de pass n'est pas
-- rachetable). Enlever un id d'une ancienne saison, c'est le perdre à jamais
-- pour ceux qui l'avaient gagné.
BATTLEPASS_CONFIG.account_cosmetics = BATTLEPASS_CONFIG.account_cosmetics or {
	-- Saisons précédentes
	lunette_simple = true,
	katana_tetsu = true,
	cigare_croco = true,
	gauntlet_eventails = true,
	-- Piste de base (2026-08-29)
	pet_demon_garcon = true,
	gauntlet_slash = true,
	pet_fantome = true,
	katana_gin = true,
	-- Passes planifiés (cf. BATTLEPASS_CONFIG.seasons) : listés en dur pour survivre à la
	-- suppression d'une entrée de saison passée (sinon l'unlock serait révocable).
	-- Saison fin 2026-11-17 (« octobre »)
	bp_bouche_brin_riz = true, katana_bp_riziere = true, bp_peigne_vagues = true, gauntlet_bp_noeuds_ambre = true,
	-- Saison fin 2026-12-27 (« novembre »)
	bp_bouche_pinceau = true, gauntlet_bp_fers_scribes = true, bp_bourse_sel_rituel = true, katana_bp_sillage_encre = true,
	-- Saison fin 2027-02-05 (« décembre »)
	bp_bouche_billet_plie = true, katana_bp_braise_douce = true, bp_eventail_nuque = true, gauntlet_bp_gong_couchant = true,
	-- Saison fin 2027-03-17 (« janvier »)
	bp_bouche_prunier = true, gauntlet_bp_ecorce_givre = true, bp_renard_ceinture = true, katana_bp_prunier_hiver = true,
	-- Saison fin 2027-04-26 (« février »)
	bp_corde_shimenawa = true, katana_bp_lune_voilee = true, bp_bouche_kiseru = true, gauntlet_bp_cinq_astres = true,
}

function BATTLEPASS_CONFIG.IsBattlePassCosmetic(item_id)
	return isstring(item_id) and BATTLEPASS_CONFIG.account_cosmetics[item_id] == true
end

-- Cosmétiques claimés dans `progress` (saison dont les tuiles MATCHENT la config
-- courante — n'appeler qu'avec la progression de la saison EN COURS).
function BATTLEPASS_CONFIG.GetClaimedCosmeticIds(progress)
	local ids = {}
	if not istable(progress) then return ids end
	local seen = {}
	local function add(tile, claimed)
		if not claimed or not tile or not isstring(tile.cosmetic) or tile.cosmetic == "" then return end
		if seen[tile.cosmetic] then return end
		seen[tile.cosmetic] = true
		ids[#ids + 1] = tile.cosmetic
	end
	for _, entry in ipairs(progress) do
		local lvl = tonumber(entry.bp_level)
		if lvl then
			add(BATTLEPASS_CONFIG.items and BATTLEPASS_CONFIG.items[lvl], entry.claimed)
			add(BATTLEPASS_CONFIG.items_premium and BATTLEPASS_CONFIG.items_premium[lvl], entry.claimed_premium)
		end
	end
	return ids
end

local function bpCosmeticTile(sName, sDesc, sModel, sItemId)
	BATTLEPASS_CONFIG.account_cosmetics[sItemId] = true
	return {
		name = sName, description = sDesc, model = sModel, cosmetic = sItemId,
		icon = ICON_XP, icon_scale = 0.9, quantity = 1,
		claim_function = function(ply) BATTLEPASS_CONFIG.GiveReward(ply, { cosmetic = sItemId }) end,
	}
end

-- Tuiles GÉNÉRIQUES (XP / yens / reroll) des paliers 15 et 30, telles que sorties des
-- boucles : resservies pour une saison NON planifiée (cf. ApplySeasonContent).
local loopTiles = {
	free_mid = BATTLEPASS_CONFIG.items[15],         free_last = BATTLEPASS_CONFIG.items[30],
	prem_mid = BATTLEPASS_CONFIG.items_premium[15], prem_last = BATTLEPASS_CONFIG.items_premium[30],
}
local DESC_PET = "Un petit compagnon perch\195\169 sur ton \195\169paule."
BATTLEPASS_CONFIG.items[15]         = bpCosmeticTile("Petit d\195\169mon", DESC_PET,                       "models/evo/accessories/body/pet_epaule/demon_garcon/demon_garcon.mdl",                        "pet_demon_garcon")
BATTLEPASS_CONFIG.items[30]         = bpCosmeticTile("Slash",         "Arme de mains nues (Hakuda).", "models/evo/weapons/hakuda/divers/evo_dez863febhrfee/evo_dez863feBHrfee.mdl",                   "gauntlet_slash")
BATTLEPASS_CONFIG.items_premium[15] = bpCosmeticTile("Fant\195\180me",       DESC_PET,                       "models/evo/accessories/body/pet_epaule/fantome/fantome.mdl",                                  "pet_fantome")
BATTLEPASS_CONFIG.items_premium[30] = bpCosmeticTile("Katana Gin",    "Skin de katana.",              "models/evo/weapons/katana/shinigami/evo_zed63efm8fvefrrfefer/evo_zed63efm8fvefrRFEfer.mdl",   "katana_gin")

-- ── PASSES PLANIFIÉS PAR SAISON (demande user 2026-09-16) ───────────────────────────────
-- Un pass par SAISON, c.-à-d. par cycle de `duration_days` = 40 j : MÊME DURÉE que le pass
-- actuel (demande user), enchaînés sans trou ni troncature. Clé = date de FIN de la saison
-- telle que renvoyée par GetEndDate() ("YYYY-MM-DD"), qui est aussi la date d'expiration
-- du premium. Les étiquettes user (« octobre » … « février ») donnent l'ORDRE des passes,
-- pas des mois calendaires : les dates réelles sont en commentaire de chaque entrée.
-- Par saison : 2 cosmétiques GRATUITS (accessoire au palier 15, arme au 30) + 2 PREMIUM
-- (idem) ; les armes alternent katana / hakuda. content_id UNIQUE par saison (3..7),
-- jamais réutilisé. Objets : katana_<skin> (KATANA_SKINS, ncm_ranger_katana),
-- gauntlet_<id> (NCM_HAKUDA_GAUNTLETS, ncm_combat_system), accessoires = ITEMS
-- (inventory/config.lua). Aucun n'est en boutique ni au coffre : exclusifs au pass.
-- Tuile = { nom, description, modèle, item_id } (cf. bpCosmeticTile). Gratuit = rareté
-- epic, premium = legendary.
-- AJOUTER UNE SAISON : une entrée ["YYYY-MM-DD"] (fin du cycle suivant = dernière clé
-- + 40 j ; une clé qui n'est pas une vraie fin de cycle est signalée au boot serveur) +
-- content_id suivant + objets créés dans les 3 fichiers ci-dessus + ids dans
-- account_cosmetics. Une saison SANS entrée (après la piste de base) sert les paliers
-- 15/30 GÉNÉRIQUES (XP/yens, aucun cosmétique) + avertissement serveur ; la progression
-- repart quand même (fin de saison).
BATTLEPASS_CONFIG.base_season_end = "2026-10-08" -- fin de la saison servie par la piste de BASE (content_id 2) ; toute saison finissant AVANT ou À cette date = piste de base
BATTLEPASS_CONFIG.seasons = {
	["2026-11-17"] = { content_id = 3, -- pass « octobre » : 2026-10-08 -> 2026-11-17
		free_mid  = { "Brin de riz",              "Un brin de riz tenu dans la bouche.",                 "models/evo/accessories/head/bp_bouche_brin_riz/bp_bouche_brin_riz.mdl",              "bp_bouche_brin_riz" },
		free_last = { "Katana des rizières",      "Skin de katana.",                                     "models/evo/weapons/katana/divers/bp_katana_riziere/bp_katana_riziere.mdl",           "katana_bp_riziere" },
		prem_mid  = { "Peigne des vagues",        "Un peigne orné de vagues, porté dans les cheveux.",   "models/evo/accessories/head/bp_peigne_vagues/bp_peigne_vagues.mdl",                  "bp_peigne_vagues" },
		prem_last = { "Hakuda des nœuds d'ambre", "Arme de mains nues (Hakuda).",                        "models/evo/weapons/hakuda/divers/bp_hakuda_noeuds_ambre/bp_hakuda_noeuds_ambre.mdl", "gauntlet_bp_noeuds_ambre" },
	},
	["2026-12-27"] = { content_id = 4, -- pass « novembre » : 2026-11-17 -> 2026-12-27
		free_mid  = { "Pinceau de voyage",         "Un pinceau de voyage tenu dans la bouche.",           "models/evo/accessories/head/bp_bouche_pinceau/bp_bouche_pinceau.mdl",                "bp_bouche_pinceau" },
		free_last = { "Hakuda des fers du scribe", "Arme de mains nues (Hakuda).",                        "models/evo/weapons/hakuda/divers/bp_hakuda_fers_scribes/bp_hakuda_fers_scribes.mdl", "gauntlet_bp_fers_scribes" },
		prem_mid  = { "Bourse de sel rituel",      "Une bourse de sel rituel accrochée à la ceinture.",   "models/evo/accessories/body/bp_bourse_sel_rituel/bp_bourse_sel_rituel.mdl",          "bp_bourse_sel_rituel" },
		prem_last = { "Katana du sillage d'encre", "Skin de katana.",                                     "models/evo/weapons/katana/divers/bp_katana_sillage_encre/bp_katana_sillage_encre.mdl", "katana_bp_sillage_encre" },
	},
	["2027-02-05"] = { content_id = 5, -- pass « décembre » : 2026-12-27 -> 2027-02-05
		free_mid  = { "Billet de prière plié",     "Un billet de prière plié tenu dans la bouche.",       "models/evo/accessories/head/bp_bouche_billet_plie/bp_bouche_billet_plie.mdl",        "bp_bouche_billet_plie" },
		free_last = { "Katana de la braise douce", "Skin de katana.",                                     "models/evo/weapons/katana/divers/bp_katana_braise_douce/bp_katana_braise_douce.mdl", "katana_bp_braise_douce" },
		prem_mid  = { "Éventail de nuque",         "Un éventail glissé dans la nuque.",                   "models/evo/accessories/head/bp_eventail_nuque/bp_eventail_nuque.mdl",                "bp_eventail_nuque" },
		prem_last = { "Hakuda du gong couchant",   "Arme de mains nues (Hakuda).",                        "models/evo/weapons/hakuda/divers/bp_hakuda_gong_couchant/bp_hakuda_gong_couchant.mdl", "gauntlet_bp_gong_couchant" },
	},
	["2027-03-17"] = { content_id = 6, -- pass « janvier » : 2027-02-05 -> 2027-03-17
		free_mid  = { "Branche de prunier",        "Une branche de prunier tenue dans la bouche.",        "models/evo/accessories/head/bp_bouche_prunier/bp_bouche_prunier.mdl",                "bp_bouche_prunier" },
		free_last = { "Hakuda d'écorce givrée",    "Arme de mains nues (Hakuda).",                        "models/evo/weapons/hakuda/divers/bp_hakuda_ecorce_givre/bp_hakuda_ecorce_givre.mdl", "gauntlet_bp_ecorce_givre" },
		prem_mid  = { "Renard de ceinture",        "Un petit renard accroché à la ceinture.",             "models/evo/accessories/body/bp_renard_ceinture/bp_renard_ceinture.mdl",              "bp_renard_ceinture" },
		prem_last = { "Katana du prunier d'hiver", "Skin de katana.",                                     "models/evo/weapons/katana/divers/bp_katana_prunier_hiver/bp_katana_prunier_hiver.mdl", "katana_bp_prunier_hiver" },
	},
	["2027-04-26"] = { content_id = 7, -- pass « février » : 2027-03-17 -> 2027-04-26
		free_mid  = { "Corde shimenawa",           "Une corde shimenawa portée autour du corps.",         "models/evo/accessories/body/bp_corde_shimenawa/bp_corde_shimenawa.mdl",              "bp_corde_shimenawa" },
		free_last = { "Katana de la lune voilée",  "Skin de katana.",                                     "models/evo/weapons/katana/divers/bp_katana_lune_voilee/bp_katana_lune_voilee.mdl",   "katana_bp_lune_voilee" },
		prem_mid  = { "Kiseru de jade",            "Une pipe kiseru de jade tenue dans la bouche.",       "models/evo/accessories/head/bp_bouche_kiseru/bp_bouche_kiseru.mdl",                  "bp_bouche_kiseru" },
		prem_last = { "Hakuda des cinq astres",    "Arme de mains nues (Hakuda).",                        "models/evo/weapons/hakuda/divers/bp_hakuda_cinq_astres/bp_hakuda_cinq_astres.mdl",   "gauntlet_bp_cinq_astres" },
	},
}

local BASE_CONTENT_ID = BATTLEPASS_CONFIG.content_id
local baseTiles = {
	free_mid = BATTLEPASS_CONFIG.items[15],         free_last = BATTLEPASS_CONFIG.items[30],
	prem_mid = BATTLEPASS_CONFIG.items_premium[15], prem_last = BATTLEPASS_CONFIG.items_premium[30],
}
local appliedKey -- date de fin de la saison dont le contenu est posé ; nil = rien posé encore

-- Tuile de planning valide = { nom, description, modèle, item_id }, 4 strings.
local function seasonTileOk(t)
	return istable(t) and isstring(t[1]) and isstring(t[2]) and isstring(t[3]) and isstring(t[4]) and t[4] ~= ""
end
-- Entrée de planning VALIDE (content_id numérique + 4 tuiles complètes) pour la fin de
-- saison `sKey`, sinon nil -> traitée comme non planifiée (tuiles génériques + alerte),
-- jamais une piste à moitié posée.
local function seasonEntry(sKey)
	local sched = BATTLEPASS_CONFIG.seasons
	local e = istable(sched) and sched[sKey]
	if istable(e) and tonumber(e.content_id)
		and seasonTileOk(e.free_mid) and seasonTileOk(e.free_last)
		and seasonTileOk(e.prem_mid) and seasonTileOk(e.prem_last) then
		return e
	end
	return nil
end
-- Plus grand content_id planifié (>= base) : suffixe de clé d'une saison NON planifiée,
-- pour que l'ajout de son entrée (content_id suivant) déclenche bien un nouveau départ.
local function seasonsMaxContentId()
	local n = BASE_CONTENT_ID
	for _, e in pairs(istable(BATTLEPASS_CONFIG.seasons) and BATTLEPASS_CONFIG.seasons or {}) do
		local c = istable(e) and tonumber(e.content_id)
		if c and c > n then n = c end
	end
	return n
end

-- Pose les 4 tuiles + content_id de la saison finissant à `endDate` ("YYYY-MM-DD", tel que
-- GetEndDate()). Jusqu'à `base_season_end` inclus : piste de base. Idempotent et peu
-- coûteux : appelé par GetProgressKey() (serveur : timer de rollover toutes les 60 s, donc
-- bascule automatique à la fin de saison sans restart) et par le client à la construction
-- du menu avec la clé REÇUE DU SERVEUR (InitData) : c'est l'horloge du serveur qui décide
-- de la saison, pas celle du client. Renvoie true si le contenu a changé.
function BATTLEPASS_CONFIG.ApplySeasonContent(endDate)
	if not isstring(endDate) or endDate == "" then return false end
	if appliedKey == endDate then return false end
	-- `appliedKey` n'est posé qu'une fois le contenu ENTIÈREMENT en place : une erreur en
	-- cours de route serait retentée à l'appel suivant, jamais verrouillée à moitié posée.
	local items, prem = BATTLEPASS_CONFIG.items, BATTLEPASS_CONFIG.items_premium
	if endDate <= tostring(BATTLEPASS_CONFIG.base_season_end or "") then
		BATTLEPASS_CONFIG.content_id = BASE_CONTENT_ID
		items[15], items[30] = baseTiles.free_mid, baseTiles.free_last
		prem[15],  prem[30]  = baseTiles.prem_mid, baseTiles.prem_last
		appliedKey = endDate
		return true
	end
	local entry = seasonEntry(endDate)
	if not entry then
		-- Saison non planifiée (ou content_id manquant) : pas de cosmétique (les resservir
		-- ferait un doublon en sac à chaque saison), paliers 15/30 génériques.
		BATTLEPASS_CONFIG.content_id = seasonsMaxContentId()
		items[15], items[30] = loopTiles.free_mid, loopTiles.free_last
		prem[15],  prem[30]  = loopTiles.prem_mid, loopTiles.prem_last
		appliedKey = endDate
		if SERVER then
			ErrorNoHalt("[BattlePass] Aucun contenu planifié pour la saison finissant le " .. endDate .. " (entrée absente, sans content_id ou tuile incomplète) : paliers 15/30 génériques, aucun cosmétique. Corriger BATTLEPASS_CONFIG.seasons.\n")
		end
		return true
	end
	-- Les 4 tuiles sont construites AVANT d'être posées : swap tout-ou-rien.
	local fm, fl = bpCosmeticTile(unpack(entry.free_mid)), bpCosmeticTile(unpack(entry.free_last))
	local pm, pl = bpCosmeticTile(unpack(entry.prem_mid)), bpCosmeticTile(unpack(entry.prem_last))
	BATTLEPASS_CONFIG.content_id = math.floor(tonumber(entry.content_id))
	items[15], items[30] = fm, fl
	prem[15],  prem[30]  = pm, pl
	appliedKey = endDate
	return true
end
-- Fin de saison dont le contenu est actuellement APPLIQUÉ ("" = rien encore) : envoyée au
-- client dans InitData pour qu'il affiche exactement ce que le serveur sert.
function BATTLEPASS_CONFIG.GetAppliedSeasonKey()
	return appliedKey or ""
end
-- Auto-contrôle au boot (serveur) : chaque clé de `seasons` doit être une VRAIE fin de
-- cycle (duration_days / season_anchor), sinon l'entrée ne serait jamais servie (typo,
-- ou durée / ancre modifiées après coup).
if SERVER then
	for sKey in pairs(BATTLEPASS_CONFIG.seasons) do
		local y, m, d = tostring(sKey):match("^(%d+)-(%d+)-(%d+)$")
		local t = y and os.time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 0, min = 0, sec = 0 })
		if not t or BATTLEPASS_CONFIG.GetEndDate(t - 1) ~= sKey then
			ErrorNoHalt("[BattlePass] BATTLEPASS_CONFIG.seasons[\"" .. tostring(sKey) .. "\"] n'est pas une fin de cycle (duration_days / season_anchor) : cette saison ne sera JAMAIS servie.\n")
		end
	end
end
BATTLEPASS_CONFIG.ApplySeasonContent(BATTLEPASS_CONFIG.GetEndDate(os.time()))
