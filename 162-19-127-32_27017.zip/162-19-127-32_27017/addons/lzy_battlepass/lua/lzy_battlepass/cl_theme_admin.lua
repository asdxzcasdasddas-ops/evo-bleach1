-- "addons\\lzy_battlepass\\lua\\lzy_battlepass\\cl_theme_admin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local menu
local choices = {
	{ "Automatique — calendrier des saisons", "auto" },
	{ "Normal", "normal" },
	{ "Halloween — La Nuit des Âmes", "halloween" },
	{ "Noël — La Veillée des Âmes", "noel" },
}
net.Receive("evo_bp:ui_menu", function()
	local selected, active = net.ReadString(), net.ReadString()
	if not IsValid(LocalPlayer()) or not LocalPlayer():IsSuperAdmin() then return end
	if IsValid(menu) then menu:Remove() end
	menu = vgui.Create("DFrame")
	local panel = menu
	panel:SetSize(math.min(520, ScrW() - 32), 230)
	panel:Center()
	panel:SetTitle("Battle Pass — Habillage serveur")
	panel:MakePopup()
	panel:DockPadding(20, 42, 20, 20)
	local info = vgui.Create("DLabel", panel)
	info:Dock(TOP)
	info:SetTall(65)
	info:SetWrap(true)
	info:SetText("Habillage actif : " .. active .. "\nLe choix s'applique à tous les joueurs et reste enregistré après un redémarrage. Automatique réactive le calendrier.")
	local picker = vgui.Create("DComboBox", panel)
	picker:Dock(TOP)
	picker:SetTall(34)
	picker:SetSortItems(false)
	for _, choice in ipairs(choices) do
		picker:AddChoice(choice[1], choice[2], selected == choice[2])
	end
	picker.OnSelect = function(_, _, _, mode) selected = mode end
	local apply = vgui.Create("DButton", panel)
	apply:Dock(BOTTOM)
	apply:SetTall(36)
	apply:SetText("Appliquer à tous les joueurs")
	apply.DoClick = function()
		apply:SetEnabled(false)
		net.Start("evo_bp:ui_set")
			net.WriteString(selected)
		net.SendToServer()
		timer.Simple(1, function() if IsValid(apply) then apply:SetEnabled(true) end end)
	end
end)
