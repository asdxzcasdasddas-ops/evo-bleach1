-- "addons\\lzy_battlepass\\lua\\lzy_battlepass\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Share the one-model-per-frame queue while preserving this menu's camera setup.
local function QueuePreviewModel(panel, load)
    local previews = LZY_INVENTORY_ITEM_PREVIEW
    if previews and previews.QueueModelLoad then
        previews.QueueModelLoad(panel, load)
    else
        load(panel)
    end
end

local frame = nil
local PANEL = {}
local can_open = true

-- ── PLEIN ÉCRAN ─────────────────────────────────────────────────────────────
-- Le menu a été designé centré dans un sous-rect de 1920×1080. On le REMAPPE
-- linéairement pour qu'il remplisse l'écran. Tout reste cohérent (échelle
-- uniforme), et pour ajuster les marges il suffit de toucher BP_DST.
--   fx/fy = positions ABSOLUES (enfants directs du frame + draws de Paint)
--   fw/fh = tailles et offsets RELATIFS (dans un conteneur/carte) -> échelle seule
local BP_SRC = { x = 273, y = 90, w = 1375, h = 806 }   -- ancien sous-rect du contenu
-- BP_DST = BP_SRC -> remap NEUTRE = tailles/positions d'origine (pas d'agrandissement).
-- Pour étirer vers le plein écran, élargir BP_DST (ex: x=120,y=60,w=1680,h=960).
local BP_DST = { x = 273, y = 90, w = 1375, h = 806 }
local BP_SX  = BP_DST.w / BP_SRC.w
local BP_SY  = BP_DST.h / BP_SRC.h
local function fx(v) return BP_DST.x + (v - BP_SRC.x) * BP_SX end
local function fy(v) return BP_DST.y + (v - BP_SRC.y) * BP_SY end
local function fw(v) return v * BP_SX end
local function fh(v) return v * BP_SY end

local materials = {
	close = Material("materials/5pmtpk9ip4xmoxoe/ckomgan3lqq0s3.png", "smooth"), -- 60x60
	title_txt = Material("materials/5pmtpk9ip4xmoxoe/pm8xjdsbvbhy.png", "smooth"), -- 299x19
	reward_time_panel = Material("materials/5pmtpk9ip4xmoxoe/h80539hmcu94x6.png", "smooth"), -- 324x65
	gift_btn = Material("materials/5pmtpk9ip4xmoxoe/18n77m27cisots9.png", "smooth"), -- 45x45
	buy_premium_btn = Material("materials/5pmtpk9ip4xmoxoe/amyphkaajojk7.png", "smooth"), -- 280x45
	claim_all_btn = Material("materials/5pmtpk9ip4xmoxoe/yej34clg89q5uw.png", "smooth"), -- 170x45
	free_panel = Material("materials/5pmtpk9ip4xmoxoe/jwqlmokag296yq.png", "smooth"), -- 1375x290
	premium_panel = Material("materials/5pmtpk9ip4xmoxoe/u0c2iq51vontl.png", "smooth"), -- 1375x290
	free_item_panel = Material("materials/5pmtpk9ip4xmoxoe/aofpkjiipxcu96eec.png", "smooth"), -- 180x230
	free_item_panel_hover = Material("materials/5pmtpk9ip4xmoxoe/dk77gxb11iyag.png", "smooth"), -- 180x230
	premium_item_panel = Material("materials/5pmtpk9ip4xmoxoe/m7dyygrozaipe99.png", "smooth"), -- 180x230
	premium_item_panel_hover = Material("materials/5pmtpk9ip4xmoxoe/c11eg9n1hqh0t6b.png", "smooth"), -- 180x230
	free_banner = Material("materials/5pmtpk9ip4xmoxoe/kpbot0btxdragqc.png", "smooth"), -- 168x290
	premium_banner = Material("materials/5pmtpk9ip4xmoxoe/nl3tvr95c11twt0.png", "smooth"), -- 168x290
	claim_btn = Material("materials/5pmtpk9ip4xmoxoe/8a7e6a422metsvyuo.png", "smooth"), -- 164x30
	claim_btn_premium = Material("materials/5pmtpk9ip4xmoxoe/a66pm4w63oz8mz.png", "smooth"), -- 164x30
	gift_menu_bg = Material("materials/5pmtpk9ip4xmoxoe/oqylnp31y8dde8k.png", "smooth"), -- 406x491
	gift_menu_item_bg = Material("materials/5pmtpk9ip4xmoxoe/uhakkcibqzod491sh.png", "smooth"), -- 366x50
	gift_menu_item_bg_hover = Material("materials/5pmtpk9ip4xmoxoe/z7ygv55m4apa.png", "smooth"), -- 366x50
	searchbox_bg = Material("materials/5pmtpk9ip4xmoxoe/l2f2sw0e8kpgjqy.png", "smooth"), -- 143x45
	premium_lock_icon = Material("materials/5pmtpk9ip4xmoxoe/ccp9yo5h3o4u.png", "smooth"), -- 88x111
	item_claimed = Material("materials/5pmtpk9ip4xmoxoe/ljskpyu3x271c.png", "smooth"), -- 180x230
	coins_bg = Material("4wsd81r0bjysb8vy/itk1zoy41wcirx.png"), -- 159x60
	coin = Material("fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "noclamp smooth"), -- 42x42
}

local normal_materials = materials
local theme = nil
local server_theme = "normal"
local preview_theme

local function apply_server_theme(selected)
	server_theme = selected
	if IsValid(frame) and not preview_theme and frame.bpThemeId ~= selected then
		frame:Close()
		frame = vgui.Create("lzy_battlepass")
		can_open = false
	end
end

net.Receive("evo_bp:ui_changed", function()
	apply_server_theme(net.ReadString())
end)

net.Receive("evo_bp:ui_preview", function()
	local selected, active = net.ReadString(), net.ReadString()
	if not IsValid(LocalPlayer()) or not LocalPlayer():IsSuperAdmin() then return end
	if selected ~= "normal" and selected ~= "halloween" and selected ~= "noel" then return end
	if IsValid(frame) then frame:Close() end
	server_theme = active
	preview_theme = selected
	frame = vgui.Create("lzy_battlepass")
	can_open = false
end)

local playerProgress = {} -- {{ bp_level = 1, claimed = true/false, claimed_premium = true/false }, ... }
local serverSeasonKey = nil -- fin de saison "YYYY-MM-DD" servie par le serveur (InitData, passes planifiés) ; nil avant réception -> horloge locale
local connectedPlayers = {} -- { {steamid64 = "...", name = "..." }, ... }

-- Compact read (must match server WriteProgressTable / WriteConnectedPlayersTable)
local function ReadProgressTable()
	local n = net.ReadUInt(16)
	local t = {}
	for i = 1, n do
		t[i] = {
			bp_level = net.ReadUInt(32),
			claimed = net.ReadBool(),
			claimed_premium = net.ReadBool()
		}
	end
	return t
end

local function ReadConnectedPlayersTable()
	local n = net.ReadUInt(16)
	local t = {}
	for i = 1, n do
		t[i] = {
			steamid64 = net.ReadString(),
			name = net.ReadString()
		}
	end
	return t
end

-- (Les callbacks popup BuyBattlePassPremium / GiftBattlePassPremium sont enregistrés
-- de façon centralisée dans lzy_popup/cl_callbacks.lua.)
-- playerProgress reste {} jusqu'à réception de client:lzy_battlepass.InitData.

	-- ── CADRAGE DES MODÈLES RIGÉS SUR UN SQUELETTE JOUEUR ──────────────────────
-- Un pet d'épaule (comme un accessoire de tête ou une arme hakuda) n'est PAS un
-- prop : son mesh est rigué sur un squelette de joueur, loin de l'origine du
-- modèle. La caméra par défaut vise cette origine -- les PIEDS -- donc le pet,
-- perché à l'épaule, sortait par le haut de la case (rapport user 08/29 : « ils
-- dépassent de la case, on ne les voit pas »).
-- Même remède que l'aperçu d'inventaire (cl_item_preview_model, preview_bone_focus) :
-- on vise la MOYENNE DES OS QUI PORTENT le mesh, dans la pose réellement rendue,
-- et on règle la distance sur la taille du mesh -- pas sur les bornes du modèle,
-- qui sont celles du squelette entier (~72 u pour un pet de 10).
local meshBonesCache, meshSizeCache = {}, {}

-- Os portant au moins un sommet du mesh (poids > 0,3). util.GetModelMeshes est
-- COÛTEUX : résultat gardé en cache, et `false` mémorisé pour ne pas réessayer.
local function PetMeshBones(mdl)
	local c = meshBonesCache[mdl]
	if c ~= nil then return c or nil end
	local meshes = util.GetModelMeshes(mdl)
	if not istable(meshes) or not meshes[1] then meshBonesCache[mdl] = false return nil end
	local seen, out = {}, {}
	for _, m in ipairs(meshes) do
		for _, v in ipairs(m.triangles or {}) do
			for _, w in ipairs(v.weights or {}) do
				local b = tonumber(w.bone)
				if b and b >= 0 and (tonumber(w.weight) or 0) > 0.3 and not seen[b] then
					seen[b] = true
					out[#out + 1] = b
				end
			end
		end
	end
	if #out == 0 then meshBonesCache[mdl] = false return nil end
	meshBonesCache[mdl] = out
	return out
end

-- Plus grande dimension du MESH (et pas des bornes du modèle), en unités.
local function PetMeshSize(mdl)
	local c = meshSizeCache[mdl]
	if c then return c end
	local meshes = util.GetModelMeshes(mdl)
	if not istable(meshes) or not meshes[1] then meshSizeCache[mdl] = 12 return 12 end
	local mn, mx
	for _, m in ipairs(meshes) do
		for _, v in ipairs(m.triangles or {}) do
			local p = v.pos
			if p then
				if not mn then mn, mx = Vector(p), Vector(p) end
				mn.x = math.min(mn.x, p.x) mn.y = math.min(mn.y, p.y) mn.z = math.min(mn.z, p.z)
				mx.x = math.max(mx.x, p.x) mx.y = math.max(mx.y, p.y) mx.z = math.max(mx.z, p.z)
			end
		end
	end
	local n = mn and math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z) or 12
	n = math.max(n, 4) -- un mesh minuscule ne doit pas coller la caméra dedans
	meshSizeCache[mdl] = n
	return n
end

-- ŒIL D'APERÇU (même icône que la boutique et le marché de nuit : tracée à la main,
-- pas de matériau à monter). Polygones pré-alloués et mutés au dessin : zéro
-- allocation par image, règle perf maison.
local _EYE_SEGS = 20
local _EYE_COS, _EYE_SIN = {}, {}
for i = 0, _EYE_SEGS - 1 do
	local a = (i / _EYE_SEGS) * math.pi * 2
	_EYE_COS[i + 1] = math.cos(a)
	_EYE_SIN[i + 1] = math.sin(a)
end
local _EYE_POLY_OUTER, _EYE_POLY_INNER, _EYE_POLY_PUPIL = {}, {}, {}
for i = 1, _EYE_SEGS do
	_EYE_POLY_OUTER[i] = { x = 0, y = 0 }
	_EYE_POLY_INNER[i] = { x = 0, y = 0 }
	_EYE_POLY_PUPIL[i] = { x = 0, y = 0 }
end
local function DrawEyeIcon(cx, cy, w, h, col, bgCol)
	local hw, hh = w * 0.5, h * 0.5
	local ihw, ihh = hw * 0.88, hh * 0.85
	local pr = math.min(hw, hh) * 0.42
	for i = 1, _EYE_SEGS do
		local cosA, sinA = _EYE_COS[i], _EYE_SIN[i]
		local po = _EYE_POLY_OUTER[i] po.x = cx + cosA * hw  po.y = cy + sinA * hh
		local pi = _EYE_POLY_INNER[i] pi.x = cx + cosA * ihw pi.y = cy + sinA * ihh
		local pp = _EYE_POLY_PUPIL[i] pp.x = cx + cosA * pr  pp.y = cy + sinA * pr
	end
	draw.NoTexture()
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_OUTER)
	surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a or 255)
	surface.DrawPoly(_EYE_POLY_INNER)
	surface.SetDrawColor(col.r, col.g, col.b, col.a or 255)
	surface.DrawPoly(_EYE_POLY_PUPIL)
end

-- Cadrage d'un modele dans une case : FOV, camera, et la branche qui convient au
-- type de modele. Partagee par la TUILE et par l'APERCU au survol -- deux copies
-- de ces reglages divergeraient au premier ajustement.
local function BP_ConfigurerModele(pnl, model_path)
	if not (IsValid(pnl) and isstring(model_path) and model_path ~= "") then return end
	-- Réglages par défaut : conviennent à un modèle POSÉ (katana, prop).
	pnl:SetCamPos(Vector(50, 50, 50))
	pnl:SetLookAt(Vector(0, 0, 0))
	pnl:SetFOV(45)
	pnl:SetAnimated(true)
	pnl:SetAmbientLight(Color(255, 255, 255))
	pnl:SetDirectionalLight(BOX_TOP, Color(255, 255, 255))
	pnl:SetDirectionalLight(BOX_FRONT, Color(255, 255, 255))
	
	-- Auto-rotate the model
	pnl.LayoutEntity = function(panel, ent)
		if IsValid(ent) then
			ent:SetAngles(Angle(0, (CurTime() * 20) % 360, 0))
			ent:FrameAdvance(RealFrameTime())
		end
	end

	-- ACCESSOIRE DE TÊTE (lunette / cigare) : le mesh est rigué à hauteur de TÊTE et HORS
	-- origine -> la caméra fixe (qui vise l'origine = les pieds) le laissait hors cadre.
	-- On vise l'os ValveBiped.Bip01_Head1 (là où l'accessoire est réellement), on DÉZOOME et
	-- on fige le modèle en 3/4 (mêmes réglages que l'aperçu inventaire). Demande user :
	-- « dézoomer + regarder plus en bas ». Les armes (katana/éventails) gardent leur cadrage.
	if string.find(string.lower(model_path), "accessories/head", 1, true) then
		pnl:SetFOV(25)
		pnl.LayoutEntity = function(panel, ent)
			if not IsValid(ent) then return end
			ent:SetAngles(Angle(-25, 40, 0))
			local focus = Vector(0, 0, 66) -- repli tant que l'os n'est pas prêt (1res frames)
			local hb = ent:LookupBone("ValveBiped.Bip01_Head1")
			if hb and hb >= 0 then
				local m = ent:GetBoneMatrix(hb)
				if m then focus = m:GetTranslation() end
			end
			local dir = Vector(0.72, 0.52, 0.45)
			dir:Normalize()
			panel:SetLookAt(focus)
			panel:SetCamPos(focus + dir * 26) -- 26 u + FOV 25 = tête entière + accessoire visibles
			ent:FrameAdvance(RealFrameTime())
		end
	end

	-- ARME HAKUDA (éventails) : le mesh est bonemergé aux MAINS (~hauteur torse) et HORS
	-- origine -> la caméra fixe (qui vise les pieds) le cadrait mal. On monte la visée à
	-- hauteur du torse (os Spine2, sur l'axe de rotation) + dézoom, rotation gardée. Demande
	-- user : « pas parfaitement placé ». Le katana (weapons/katana) garde son cadrage.
	if string.find(string.lower(model_path), "weapons/hakuda", 1, true) then
		pnl:SetFOV(42)
		pnl.LayoutEntity = function(panel, ent)
			if not IsValid(ent) then return end
			ent:SetAngles(Angle(0, (CurTime() * 20) % 360, 0))
			local z = 40 -- repli tant que l'os n'est pas prêt
			local sb = ent:LookupBone("ValveBiped.Bip01_Spine2")
			if sb and sb >= 0 then
				local m = ent:GetBoneMatrix(sb)
				if m then z = m:GetTranslation().z end
			end
			local aim = Vector(0, 0, z) -- sur l'AXE de rotation -> le modèle tourne sans dériver
			panel:SetLookAt(aim)
			panel:SetCamPos(aim + Vector(0.72, 0.52, 0.30):GetNormalized() * 64) -- dézoomé (52 -> 64) pour mieux voir les éventails
			ent:FrameAdvance(RealFrameTime())
		end
	end

	-- PET D'ÉPAULE : le mesh est rigué près de l'ÉPAULE du squelette, à ~60 u
	-- au-dessus de l'origine visée par la caméra par défaut -- il sortait donc
	-- par le haut de la case. On vise les os qui portent vraiment le mesh et on
	-- pose la caméra à la distance qu'exige SA taille (cf. helpers plus haut).
	-- La visée est recalculée à chaque image : elle suit l'épaule pendant que le
	-- modèle tourne, donc le pet reste centré au lieu d'orbiter hors cadre.
	if string.find(string.lower(model_path), "accessories/body/pet_epaule", 1, true) then
		local nFov = 40
		-- Distance qui fait tenir un objet de `nDemi` de demi-taille dans le champ,
		-- + 25 % de marge pour l'animation (le pet bouge dans sa pose d'attente).
		local nDemi = PetMeshSize(model_path) * 0.5
		local nDist = (nDemi / math.tan(math.rad(nFov * 0.5))) * 1.25
		local vDir  = Vector(0.72, 0.52, 0.30):GetNormalized()
		pnl:SetFOV(nFov)
		pnl.LayoutEntity = function(panel, ent)
			if not IsValid(ent) then return end
			ent:SetAngles(Angle(0, (CurTime() * 20) % 360, 0))
			ent:FrameAdvance(RealFrameTime())
			-- Repli tant que les os ne sont pas posés (premières images) : hauteur
			-- d'épaule, pour ne jamais montrer une case vide.
			local vFocus = Vector(0, 0, 60)
			local tBones = PetMeshBones(model_path)
			if tBones then
				local vSum, nB = Vector(0, 0, 0), 0
				for _, b in ipairs(tBones) do
					local m = ent:GetBoneMatrix(b)
					if m then vSum = vSum + m:GetTranslation() nB = nB + 1 end
				end
				if nB > 0 then vFocus = vSum / nB end
			end
			panel:SetLookAt(vFocus)
			panel:SetCamPos(vFocus + vDir * nDist)
		end
	end
end

function PANEL:CreateItemPanels()
	-- Passes planifiés : pose les tuiles de la saison SERVIE PAR LE SERVEUR avant de
	-- construire (idempotent) — l'horloge du serveur décide, pas celle du client. Avant le
	-- premier InitData (menu ouvert trop tôt) : horloge locale, corrigé à la réception.
	if BATTLEPASS_CONFIG and BATTLEPASS_CONFIG.ApplySeasonContent then
		local sKey = serverSeasonKey
		if (sKey == nil or sKey == "") and BATTLEPASS_CONFIG.GetEndDate then sKey = BATTLEPASS_CONFIG.GetEndDate(os.time()) end
		BATTLEPASS_CONFIG.ApplySeasonContent(sKey)
	end
	-- Function to create item panel (same as in CreateScrollPanel)
	local function CreateItemPanel(parent, isPremium, index, icon_path, quantity, claimed, model_path, icon_scale, item_name, item_desc, cosmetic_id)
		local itemPanel = vgui.Create("DButton", parent)
		local icon_material = not model_path and icon_path and Material(icon_path, "smooth")
		local itemWidth = fw(180)
		local itemHeight = fh(230)
		local spacing = fw(10)
		local startX = fw(30)
		
		itemPanel:gSetSize(itemWidth, itemHeight)
		itemPanel:gSetPos(startX + (index * (itemWidth + spacing)), (fh(290) - itemHeight) / 2)
		itemPanel:SetText("")
		itemPanel:SetPaintBackgroundEnabled(false)
		itemPanel.hovered = false
		
		-- Create DModelPanel for 3D model rendering if model_path is provided
		local modelPanel = nil
		if model_path then
			modelPanel = vgui.Create("DModelPanel", itemPanel)
			modelPanel:gSetPos(fw(30), fh(55))
			modelPanel:gSetSize(fw(120), fh(120))
			modelPanel:SetMouseInputEnabled(false)
			modelPanel:SetZPos(5)
			QueuePreviewModel(modelPanel, function(panel)
				panel:SetModel(model_path)
				BP_ConfigurerModele(panel, model_path)
			end)

			-- ŒIL D'APERÇU, en haut à droite de la case (demande user 08/29 : « l'œil de
			-- preview comme pour les cosmétiques »). Même geste que la boutique : il ouvre
			-- l'aperçu COSMÉTIQUE GLOBAL, qui montre l'objet sur TON personnage
			-- (LZY_SHOP_COSMETIC_PREVIEW, lzy_shop/client/cosmetic_preview.lua).
			-- Seulement sur les paliers qui donnent un vrai objet : un palier d'XP ou de
			-- yens n'a rien à essayer.
			local tItem = cosmetic_id and ITEMS and ITEMS[cosmetic_id]
			if tItem and LZY_SHOP_COSMETIC_PREVIEW and LZY_SHOP_COSMETIC_PREVIEW.Open then
				local eyeW, eyeH = fw(34), fh(22)
				local eye = vgui.Create("DButton", itemPanel)
				eye:SetText("")
				eye:gSetSize(eyeW, eyeH)
				eye:gSetPos(itemWidth - eyeW - fw(12), fh(12))
				eye:SetZPos(1000) -- au-dessus du modèle, sinon le clic ne porte pas
				eye:SetCursor("hand")
				eye:SetTooltip("Aperçu sur ton perso")
				eye:SetAlpha(130)
				eye.OnCursorEntered = function(selff) selff:Stop() selff:AlphaTo(255, 0.15, 0) end
				eye.OnCursorExited  = function(selff) selff:Stop() selff:AlphaTo(130, 0.15, 0) end
				local COL_EYE, COL_EYE_BG = Color(230, 230, 240, 240), Color(10, 10, 14, 255)
				eye.Paint = function(selff, ew, eh)
					DrawEyeIcon(ew / 2, eh / 2, ew * 0.82, eh * 0.72, COL_EYE, COL_EYE_BG)
				end
				eye.DoClick = function()
					surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
					LZY_SHOP_COSMETIC_PREVIEW.Open(tItem)
				end
			end
			
		end
		
		itemPanel.Paint = function(selff, w, h)
			local mat = isPremium and ((selff.hovered and LocalPlayer():GetEvoNWBool("BattlePass_IsPremium", false)) and materials.premium_item_panel_hover or materials.premium_item_panel)
							or (selff.hovered and materials.free_item_panel_hover or materials.free_item_panel)
			RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), mat)

			if claimed then
				RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), materials.item_claimed)
			end

			-- Item Icon (only draw if no model_path) — dessinée à `icon_scale` (fraction de
			-- la case 120px) et CENTRÉE dans cette case, pour des icônes plus petites/nettes.
			if icon_material then
				local sc  = icon_scale or 1
				local isz = 120 * sc
				local off = (120 - isz) / 2
				RNDX.DrawMaterial(0, gRespX(fw(30 + off)), gRespY(fh(55 + off)), gRespX(fw(isz)), gRespY(fh(isz)), selff.hovered and Color(255, 255, 255, 255) or Color(255, 255, 255, 200), icon_material)
			end

			-- Item Quantity
			if quantity then
				draw.SimpleText("X" .. tostring(quantity), "Avenir Next World:" .. gRespFont(26), w/2, selff.hovered and gRespY(fh(180)) or gRespY(fh(196)), selff.hovered and Color(255, 255, 255, 255) or Color(255, 255, 255, 130), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		
		local claimButton = nil

		if not claimed and (index + 1 <= LocalPlayer():GetEvoNWInt("BattlePass_CanClaimLevel", 0)) and not (isPremium and not LocalPlayer():GetEvoNWBool("BattlePass_IsPremium", false)) then
			claimButton = vgui.Create("DButton", itemPanel)
			claimButton:gSetSize(fw(164), fh(30))
			claimButton:gSetPos(fw(8), fh(192))
			claimButton:SetText("")
			claimButton:SetPaintBackgroundEnabled(false)
			claimButton:SetVisible(false)
			claimButton:SetZPos(10)
			claimButton.isPremium = isPremium
			claimButton.itemIndex = index + 1
			
			claimButton.Paint = function(selff, w, h)
				local mat = selff.isPremium and materials.claim_btn_premium or materials.claim_btn
				RNDX.DrawMaterial(0, 0, 0, w, h, selff.hovered and Color(255, 255, 255, 150) or Color(255, 255, 255, 255), mat)
			end
			
			claimButton.DoClick = function(selff)
				net.Start("server:lzy_battlepass.ClaimItem")
				net.WriteUInt(selff.itemIndex, 32)
				net.WriteBool(selff.isPremium)
				net.SendToServer()

				selff:SetVisible(false)
				selff:SetDisabled(true)
			end
		end
		
		itemPanel.OnCursorEntered = function(selff)
			selff.hovered = true
			-- Tooltip de description (dessiné par PANEL:PaintOver, non clippé par le scroll).
			self.bpHover = { name = item_name, desc = item_desc, panel = itemPanel }
			if IsValid(claimButton) then
				claimButton:SetVisible(true)
			end
		end

		itemPanel.OnCursorExited = function(selff)
			selff.hovered = false
			if self.bpHover and self.bpHover.panel == itemPanel then self.bpHover = nil end
			timer.Simple(0.05, function()
				if not IsValid(itemPanel) or not IsValid(claimButton) then return end
				if not itemPanel:IsHovered() and not claimButton:IsHovered() then
					claimButton:SetVisible(false)
				end
			end)
		end

		if not claimed and (index + 1 <= LocalPlayer():GetEvoNWInt("BattlePass_CanClaimLevel", 0)) and not (isPremium and not LocalPlayer():GetEvoNWBool("BattlePass_IsPremium", false)) then
			claimButton.OnCursorEntered = function(selff)
				selff.hovered = true
				if IsValid(itemPanel) then
					itemPanel.hovered = true
				end
			end
			
			claimButton.OnCursorExited = function(selff)
				selff.hovered = false
				if IsValid(itemPanel) and not itemPanel:IsHovered() then
					itemPanel.hovered = false
					selff:SetVisible(false)
				end
			end
		end
		
		itemPanel.DoClick = function(selff)
		end
		
		return itemPanel
	end
	
	-- Get number of items from config
	local numFreeItems = 0
	local numPremiumItems = 0
	
	if BATTLEPASS_CONFIG and BATTLEPASS_CONFIG.items then
		for k, v in pairs(BATTLEPASS_CONFIG.items) do
			if type(k) == "number" and k > numFreeItems then
				numFreeItems = k
			end
		end
	end
	
	if BATTLEPASS_CONFIG and BATTLEPASS_CONFIG.items_premium then
		for k, v in pairs(BATTLEPASS_CONFIG.items_premium) do
			if type(k) == "number" and k > numPremiumItems then
				numPremiumItems = k
			end
		end
	end

	-- Use the maximum number of items for layout
	local numItems = math.max(numFreeItems, numPremiumItems, 10) -- Default to 10 if config not loaded
	
	-- Create free item panels based on config
	for i = 1, numFreeItems do
		if BATTLEPASS_CONFIG.items[i] then
			local claimed = false

			for _, progress in ipairs(playerProgress) do
				if progress.bp_level == i then
					claimed = progress.claimed
					break
				end
			end

			CreateItemPanel(self.freeItemsRow, false, i - 1, BATTLEPASS_CONFIG.items[i].icon, BATTLEPASS_CONFIG.items[i].quantity, claimed, BATTLEPASS_CONFIG.items[i].model, BATTLEPASS_CONFIG.items[i].icon_scale, BATTLEPASS_CONFIG.items[i].name, BATTLEPASS_CONFIG.items[i].description,
				BATTLEPASS_CONFIG.items[i].cosmetic)
		end
	end

	-- Create premium item panels based on config
	for i = 1, numPremiumItems do
		if BATTLEPASS_CONFIG.items_premium[i] then
			local claimed = false

			for _, progress in ipairs(playerProgress) do
				if progress.bp_level == i then
					claimed = progress.claimed_premium
					break
				end
			end
			
			CreateItemPanel(self.premiumItemsRow, true, i - 1, BATTLEPASS_CONFIG.items_premium[i].icon, BATTLEPASS_CONFIG.items_premium[i].quantity, claimed, BATTLEPASS_CONFIG.items_premium[i].model, BATTLEPASS_CONFIG.items_premium[i].icon_scale, BATTLEPASS_CONFIG.items_premium[i].name, BATTLEPASS_CONFIG.items_premium[i].description,
				BATTLEPASS_CONFIG.items_premium[i].cosmetic)
		end
	end

	self.numItems = numItems -- Store for use in progress function
	self.numFreeItems = numFreeItems -- Store number of free items for progress bar
end

function PANEL:CreateScrollPanel()
	-- Create scroll container that covers both free and premium panels
	self.scrollContainer = vgui.Create("DPanel", self)
	self.scrollContainer:gSetPos(fx(273 + 80), fy(250))
	self.scrollContainer:gSetSize(fw(1350 - 55), fh(580)) -- Covers both panels (290 + 290 = 580)
	self.scrollContainer:SetZPos(100)
	self.scrollContainer:SetPaintBackgroundEnabled(false)
	self.scrollContainer:SetMouseInputEnabled(true)
	self.scrollContainer.scrollX = 0
	self.scrollContainer.isDragging = false
	self.scrollContainer.dragStartX = 0
	self.scrollContainer.dragStartScroll = 0

	self.scrollContainer.Paint = function(selff, w, h) end

	-- Container for all items (both rows) - this will be scrolled
	local itemsContainer = vgui.Create("DPanel", self.scrollContainer)
	itemsContainer:SetPos(0, 0)
	itemsContainer:SetPaintBackgroundEnabled(false)
	itemsContainer.Paint = function(selff, w, h) end

	-- Free items row
	self.freeItemsRow = vgui.Create("DPanel", itemsContainer)
	self.freeItemsRow:SetPos(0, 0)
	self.freeItemsRow:gSetSize(fw(2000), fh(290))
	self.freeItemsRow:SetPaintBackgroundEnabled(false)
	self.freeItemsRow.Paint = function(selff, w, h) end

	-- Premium items row
	self.premiumItemsRow = vgui.Create("DPanel", itemsContainer)
	self.premiumItemsRow:gSetPos(0, fh(290))
	self.premiumItemsRow:gSetSize(fw(2000), fh(290))
	self.premiumItemsRow:SetPaintBackgroundEnabled(false)
	self.premiumItemsRow.Paint = function(selff, w, h) end

	self:CreateItemPanels()

	local itemWidth = fw(180)
	local spacing = fw(10)
	local startX = fw(30)
	local totalWidth = startX + (self.numItems * (itemWidth + spacing)) + fw(30)
	
	-- Store layout values for progress calculation
	self.progressItemWidth = itemWidth
	self.progressSpacing = spacing
	self.progressStartX = startX
	self.progressTotalWidth = totalWidth
	
	itemsContainer:gSetSize(totalWidth, fh(580))

	-- Les rangées étaient figées à 2000px -> les tuiles au-delà (~J12+) étaient CLIPPÉES
	-- (coupées hors-cadre). On les élargit à TOUTE la largeur du contenu (tous les paliers).
	self.freeItemsRow:gSetSize(totalWidth, fh(290))
	self.premiumItemsRow:gSetSize(totalWidth, fh(290))

	-- Store item positions for progress bar circles (based on free items)
	self.freeItemPositions = {}
	for i = 1, self.numFreeItems do
		local itemX = startX + ((i - 1) * (itemWidth + spacing)) + (itemWidth / 2)
		table.insert(self.freeItemPositions, itemX)
	end
	
	-- Progress bar panel (centered between free and premium panels)
	self.progressBarPanel = vgui.Create("DPanel", itemsContainer)
	self.progressBarPanel:gSetPos(fw(8), fh(263)) -- Position exactly at the center between panels (free ends at 290, premium starts at 290)
	self.progressBarPanel:gSetSize(totalWidth - fw(50), fh(50)) -- Height for progress bar and circles
	self.progressBarPanel:SetPaintBackgroundEnabled(false)
	self.progressBarPanel.progress = 0 -- Example progress (0 to 1)
	self.progressBarPanel.Paint = function(selff, w, h)
		-- Draw progress bar background
		local barHeight = 4
		local barY = h / 2 -- Center vertically
		RNDX.Draw(8, barY, gRespX(25), w, gRespY(barHeight), theme and theme.track or Color(55, 55, 55, 255))
		
		-- Draw progress bar fill
		local progressWidth = w * selff.progress
		RNDX.Draw(8, barY, gRespX(25), progressWidth, gRespY(barHeight), theme and theme.progress or color_white)
		
		-- Draw circles on top of progress bar aligned with free items
		-- circleY est en coords panel-local (h est deja scale par gSetSize) donc
		-- on ne re-applique PAS gRespY dessus (sinon double-scaling => les cercles
		-- partent dans la zone du lock blur sur 4K).
		local circleRadius = fw(16)
		local circleY = h / 2 -- Center vertically on the bar
		local barStartX = 8
		local progressWidth = w * selff.progress

		for i, itemX in ipairs(self.freeItemPositions) do
			local circleX = itemX - fw(10) -- Adjusted X position for circle (matching SetProgressStep calculation)

			-- Check if progress bar has passed this circle
			local isPassed = i <= self.progressStep

			-- Set circle color: white if passed, gray if not
			local circleColor = isPassed and Color(255, 255, 255, 255) or Color(55, 55, 55, 255)

			if theme then
				RNDX.DrawMaterial(0, gRespX(circleX - circleRadius), circleY - gRespY(circleRadius), gRespX(circleRadius * 2), gRespY(circleRadius * 2), color_white, isPassed and materials.progress_node or materials.progress_node_locked)
			else
			-- Draw circle outline using surface.DrawPoly
			draw.NoTexture()
			surface.SetDrawColor(circleColor.r, circleColor.g, circleColor.b, circleColor.a)

			-- Create circle vertices
			local segments = 32
			local vertices = {}
			for j = 0, segments do
				local angle = math.rad((j / segments) * 360)
				local px = gRespX(circleX) + math.cos(angle) * gRespX(circleRadius)
				local py = circleY + math.sin(angle) * gRespY(circleRadius)
				table.insert(vertices, {x = px, y = py})
			end

			if #vertices > 2 then
				surface.DrawPoly(vertices)
			end

			end
			-- Draw text inside circle (1, 2, 3...)
			local text = tostring(i)
			draw.SimpleText(text, "Avenir Next World Bold:" .. gRespFont(18), gRespX(circleX), circleY, isPassed and Color(0, 0, 0, 255) or Color(185, 185, 185, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Store reference for scrolling
	self.itemsContainer = itemsContainer
	self.scrollContainer.maxScroll = gRespX(math.max(0, totalWidth - fw(1320)))

	-- Handle mouse wheel scrolling
	self.scrollContainer.OnMouseWheeled = function(selff, delta)
		selff.scrollX = math.Clamp(selff.scrollX - (delta * 50), 0, selff.maxScroll)
		itemsContainer:SetPos(-selff.scrollX, 0)
		return true
	end

	-- Glisser-déposer horizontal : maintenir le clic gauche et tirer à gauche/droite
	-- pour naviguer (comme le skilltree). Basé sur l'état souris GLOBAL (gui.MouseX +
	-- input.IsMouseDown) pour fonctionner même quand le clic part sur une carte.
	self.scrollContainer.Think = function(selff)
		local down = input.IsMouseDown(MOUSE_LEFT)
		local mx = gui.MouseX()
		if down then
			if not selff._dragging then
				local sx, sy = selff:LocalToScreen(0, 0)
				local my = gui.MouseY()
				if mx >= sx and mx <= sx + selff:GetWide() and my >= sy and my <= sy + selff:GetTall() then
					selff._dragging = true
					selff._dragStartX = mx
					selff._dragStartScroll = selff.scrollX
				end
			else
				selff.scrollX = math.Clamp(selff._dragStartScroll - (mx - selff._dragStartX), 0, selff.maxScroll)
				itemsContainer:SetPos(-selff.scrollX, 0)
			end
		else
			selff._dragging = false
		end
	end
end

-- Function to update item panels with current playerProgress
function PANEL:UpdateItemPanels()
	if not IsValid(self.freeItemsRow) or not IsValid(self.premiumItemsRow) then
		return
	end
	
	-- Clear existing item panels
	self.freeItemsRow:Clear()
	self.premiumItemsRow:Clear()
	
	self:CreateItemPanels()
end

-- Function to set progress bar to a specific step
function PANEL:SetProgressStep(step)
	if not IsValid(self.progressBarPanel) then
		return
	end
	
	local numFreeItems = self.numFreeItems or 10
	step = math.Clamp(step, 0, numFreeItems)
	self.progressStep = step
	
	-- Calculate progress based on circle positions
	-- The progress bar starts at X=8, and we need to reach the center of the circle
	local progress = 0
	
	if step == 0 then
		progress = 0
	elseif step >= numFreeItems then
		progress = 1
	else
		-- Calculate circle position for this step using stored layout values
		local itemWidth = self.progressItemWidth or 180
		local spacing = self.progressSpacing or 10
		local startX = self.progressStartX or 30
		local totalWidth = self.progressTotalWidth or 2000
		
		local itemX = startX + ((step - 1) * (itemWidth + spacing)) + (itemWidth / 2)
		local circleX = itemX - 26 -- Circle center X position (adjusted for circle offset)
		
		-- Progress bar starts at X=8, so calculate progress to reach circle center
		local barStartX = 8
		local progressWidth = circleX - barStartX
		progress = math.Clamp(progressWidth / totalWidth, 0, 1)
	end
	
	self.progressBarPanel.progress = progress
end

function PANEL:CreateGiftMenu()
	-- Request fresh connected players list from server so new joiners are visible
	net.Start("server:lzy_battlepass.RequestConnectedPlayers")
	net.SendToServer()

	-- Create blurred backdrop that covers the entire frame
	self.giftMenuBackdrop = vgui.Create("DPanel", self)
	self.giftMenuBackdrop:gSetSize(self.bgPanelWidth, self.bgPanelHeight)
	self.giftMenuBackdrop:gSetPos(0, 0)
	self.giftMenuBackdrop:SetPaintBackgroundEnabled(true)
	self.giftMenuBackdrop:SetMouseInputEnabled(true)
	self.giftMenuBackdrop:SetZPos(500) -- Below gift menu but above other elements
	self.giftMenuBackdrop.Paint = function(selff, w, h)
		-- Blurred background
		RNDX.Draw(0, 0, 0, w, h, Color(255, 255, 255), RNDX.BLUR)
		-- Dark overlay
		RNDX.Draw(0, 0, 0, w, h, Color(0, 0, 0, 64))
	end

	-- Close gift menu when clicking on backdrop
	local parentPanel = self -- Store reference to parent panel
	self.giftMenuBackdrop.OnMousePressed = function(selff, keyCode)
		if keyCode == MOUSE_LEFT then
			-- Get click position relative to backdrop panel (both panels are children of same parent)
			local mx, my = selff:CursorPos()
			
			-- Check if gift menu exists and if click is within its bounds
			if IsValid(parentPanel.giftMenu) then
				local giftX, giftY = parentPanel.giftMenu:GetPos()
				local giftW, giftH = parentPanel.giftMenu:GetSize()
				
				-- Check if click is outside gift menu bounds
				if mx < giftX or mx > giftX + giftW or my < giftY or my > giftY + giftH then
					-- Click is outside gift menu, close it
					parentPanel.giftMenu:Remove()
					parentPanel.giftMenu = nil
					if IsValid(parentPanel.giftMenuBackdrop) then
						parentPanel.giftMenuBackdrop:Remove()
						parentPanel.giftMenuBackdrop = nil
					end
				end
			else
				-- Gift menu doesn't exist, just remove backdrop
				if IsValid(parentPanel.giftMenuBackdrop) then
					parentPanel.giftMenuBackdrop:Remove()
					parentPanel.giftMenuBackdrop = nil
				end
			end
		end
	end
	
	-- Create gift menu
	self.giftMenu = vgui.Create("DPanel", self)
	self.giftMenu:gSetSize(406, 491)
	self.giftMenu:gSetPos(757, 281)
	self.giftMenu:SetPaintBackgroundEnabled(false)
	self.giftMenu:SetMouseInputEnabled(true)
	self.giftMenu:SetZPos(600) -- Above backdrop
	self.giftMenu.Paint = function(selff, w, h)
		if theme then
			RNDX.DrawMaterial(0, 0, 0, w, h, color_white, materials.gift_menu_bg)
			draw.SimpleText("OFFRIR À", "Bebas Neue:26", gRespX(24), gRespY(42), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return
		end
		-- Plaque de métal noir Atelier + titre Bebas pour le thème normal.
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250), gRespY(14))
			-- DA dashboard 08/07 : plaque plate, plus de lisere acier.
		else
			RNDX.Draw(0, 0, 0, w, h, Color(13, 14, 17, 250))
		end
		draw.SimpleText("OFFRIR À", "Bebas Neue:26", gRespX(24), gRespY(42), Color(237, 238, 242), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Prevent clicks on gift menu from closing it
	self.giftMenu.DoClick = function() end

	-- Add custom searchbox
	local searchbox = vgui.Create("DTextEntry", self.giftMenu)
	searchbox:gSetPos(170, 20)
	searchbox:gSetSize(143, 45)
	searchbox:SetText("")
	searchbox:SetFont("Avenir Next World:" .. gRespFont(18))
	searchbox:SetTextColor(Color(255, 255, 255, 255))
	searchbox:SetPlaceholderText("RECHERCHER...")
	searchbox:SetDrawBackground(false)
	searchbox:SetDrawBorder(false)
	searchbox:SetTextColor(Color(255, 255, 255, 255))
	searchbox:SetPlaceholderColor(Color(100, 100, 100, 255))
	searchbox:SetDrawLanguageID(false)
	searchbox.Paint = function(self, w, h)
		-- Case sombre plate + soulignement accent quand actif (plus de PNG).
		if theme then
			RNDX.DrawMaterial(0, 0, 0, w, h, color_white, materials.searchbox_bg)
		else
			RNDX.Draw(0, 0, 0, w, h, Color(26, 26, 32, 255))
		end
		if self:IsEditing() then
			RNDX.Draw(0, gRespX(8), h - gRespY(2), w - gRespX(16), gRespY(2), Color(207, 68, 78))
		end
		if not self:HasFocus() and self:GetValue() == "" then
			draw.SimpleText(self:GetPlaceholderText(), "Avenir Next World:" .. gRespFont(15), w/2, h/2, Color(255, 255, 255, 190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			self:DrawTextEntryText(Color(255, 255, 255, 255), Color(255, 215, 0, 60), Color(255, 255, 255, 255))
		end
	end

	-- Create scrollable player list container using DScrollPanel
	local playerListContainer = vgui.Create("DScrollPanel", self.giftMenu)
	playerListContainer:gSetPos(20, 80) -- Position inside gift menu (adjust as needed)
	playerListContainer:gSetSize(366, 380) -- Width matches gift_menu_item_bg, height for scrollable area
	playerListContainer:SetPaintBackgroundEnabled(false)
	
	-- Get the canvas (where items will be added)
	local playersItemsContainer = playerListContainer:GetCanvas()
	playersItemsContainer:SetPaintBackgroundEnabled(false)
	
	-- Customize scrollbar to be black and modern
	local function CustomizeScrollbar()
		local vbar = playerListContainer:GetVBar()
		if not IsValid(vbar) then
			-- Try again next frame if VBar isn't ready yet
			timer.Simple(0.01, function()
				if IsValid(playerListContainer) then
					CustomizeScrollbar()
				end
			end)
			return
		end
		
		-- Set scrollbar width
		vbar:SetWide(8)
		
		-- Hide up/down arrow buttons
		vbar:SetHideButtons(true)
		
		-- Customize VBar background (black)
		vbar.Paint = function(selff, w, h)
			-- Draw black background with rounded corners effect
			surface.SetDrawColor(0, 0, 0, 100)
			surface.DrawRect(0, 0, w, h)
		end
		
		-- Customize scrollbar grip (the draggable part)
		if IsValid(vbar.btnGrip) then
			vbar.btnGrip.Paint = function(grip, w, h)
				-- Draw black grip with slight transparency
				surface.SetDrawColor(65, 65, 65, 200)
				surface.DrawRect(0, 0, w, h)
			end
		end
	end
	
	-- Customize scrollbar after a short delay to ensure it's created
	timer.Simple(0.01, function()
		if IsValid(playerListContainer) then
			CustomizeScrollbar()
		end
	end)

	-- Function to create player item panel
	local function CreatePlayerItem(parent, playerData, index)
		local itemHeight = 50
		local spacing = 5
		local itemPanel = vgui.Create("DButton", parent)
		
		-- Get canvas width (accounts for scrollbar automatically)
		itemPanel:gSetSize(350, itemHeight)
		itemPanel:SetText("")
		itemPanel:SetPaintBackgroundEnabled(false)
		itemPanel.hovered = false
		itemPanel.playerData = playerData
		
		itemPanel.Paint = function(selff, w, h)
			local mat = selff.hovered and materials.gift_menu_item_bg_hover or materials.gift_menu_item_bg
			RNDX.DrawMaterial(0, 0, 0, w, h, Color(255, 255, 255, 255), mat)
			
			-- Draw player name
			draw.SimpleText(selff.playerData.name or "Unknown", "Avenir Next World:20", gRespX(20), h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		itemPanel.OnCursorEntered = function(selff)
			selff.hovered = true
		end
		
		itemPanel.OnCursorExited = function(selff)
			selff.hovered = false
		end
		
		itemPanel.DoClick = function(selff)
			if LocalPlayer():GetEvoNWInt("coins", 0) < tonumber(BATTLEPASS_CONFIG.premium_price) then
				LocalPlayer():OpenPopup("Vous n'avez pas assez de coins ! Achetez des coins dans la boutique.", "error")
				return
			end
			LocalPlayer():OpenYesNoPopup("Voulez-vous vraiment envoyer le battlepass premium à " .. (selff.playerData.name or "Unknown") .. " ?", "GiftBattlePassPremium", {
				steamid64 = selff.playerData.steamid64
			})
		end
		
		return itemPanel
	end

	-- Function to update player list
	local function UpdatePlayerList()
		-- Clear existing items
		if IsValid(playersItemsContainer) then
			playersItemsContainer:Clear()
		end
		
		-- Get search filter text (case-insensitive)
		local searchText = ""
		local searchboxRef = searchbox -- Use local closure variable, fallback to stored reference if needed
		if not IsValid(searchboxRef) and IsValid(self.giftMenu) then
			searchboxRef = self.giftMenu.searchbox
		end
		if IsValid(searchboxRef) then
			searchText = string.lower(searchboxRef:GetValue() or "")
		end
		
		-- Filter players based on search text
		local filteredPlayers = {}
		for i, playerData in ipairs(connectedPlayers) do
			local playerName = string.lower(playerData.name or "")
			if searchText == "" or string.find(playerName, searchText, 1, true) then
				table.insert(filteredPlayers, playerData)
			end
		end
		
		-- Create player items for filtered players
		local itemHeight = 50
		local spacing = 5
		
		for i, playerData in ipairs(filteredPlayers) do
			local itemPanel = CreatePlayerItem(playersItemsContainer, playerData, i)
			-- Position items vertically with spacing
			itemPanel:gSetPos(0, (i - 1) * (itemHeight + spacing))
		end
		
		-- DScrollPanel will automatically handle layout and scrolling
		playerListContainer:Rebuild()
	end

	-- Set up searchbox OnTextChanged callback to filter player list
	searchbox.OnTextChanged = function()
		if IsValid(self.giftMenu) and self.giftMenu.UpdatePlayerList then
			self.giftMenu.UpdatePlayerList()
		end
	end

	-- Store reference for updates
	self.giftMenu.playerListContainer = playerListContainer
	self.giftMenu.playersItemsContainer = playersItemsContainer
	self.giftMenu.UpdatePlayerList = UpdatePlayerList
	self.giftMenu.searchbox = searchbox

	-- Initial update
	UpdatePlayerList()
end

function PANEL:Init()
	self.bpThemeId = preview_theme or server_theme
	self.bpPreview = preview_theme ~= nil
	theme, materials = BATTLEPASS_CONFIG.ResolveUITheme(normal_materials, self.bpThemeId)
	self:SetDraggable(false)
	self:SetSizable(false)
	self:SetKeyboardInputEnabled(true)
	self:ShowCloseButton(false)
	self:SetTitle("")
	self:MakePopup()
	-- Échap : on s'enregistre comme `openedFrame` GLOBAL. C'est le hook OnPauseMenuShow
	-- de lzy_escape_menu qui ferme `openedFrame` sur Échap (et empêche le menu pause).
	-- C'est LE système Échap qui marche ici (EVO_MakeEscClosable n'existe pas dans cette
	-- branche -> l'ancien appel était un no-op, d'où "Échap ne ferme pas").
	openedFrame = self
	-- Garde anti-flash : la touche bindée ne peut FERMER (via OnKeyCodePressed) qu'après
	-- 0.25s, sinon l'appui d'OUVERTURE (qui arrive jusqu'à la frame) refermerait aussitôt.
	self._opened = false
	timer.Simple(0.25, function() if IsValid(self) then self._opened = true end end)
	self:SetVisible(true)
	self.bgPanelWidth = 1920
	self.bgPanelHeight = 1080
	self.panelWidth = 1382
	self.panelHeight = 796
	self:gSetSize(self.bgPanelWidth, self.bgPanelHeight)
	self:gSetPos(0, 0)

	-- Close Button
	self.closeButton = vgui.Create("DButton", self)
	self.closeButton:gSetSize(60, 60)
	self.closeButton:gSetPos(fx(1581), fy(97.5))
	self.closeButton:SetText("")
	self.closeButton:SetMouseInputEnabled(true)
	self.closeButton:SetKeyboardInputEnabled(false)
	self.closeButton:SetZPos(100)
	self.closeButton.Paint = function(selff, w, h)
		if theme then
			RNDX.DrawMaterial(0, 0, 0, w, h, color_white, materials.close)
			return
		end
		-- Croix standard DA : glyphe ✕, pas de fond, gris -> accent (remplace le PNG).
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			selff.hovered and Color(207, 68, 78) or Color(150, 154, 162), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.closeButton.DoClick = function()
		self:Close()
	end
	self.closeButton.OnCursorEntered = function(selff)
		selff.hovered = true
	end
	self.closeButton.OnCursorExited = function(selff)
		selff.hovered = false
	end

	-- Gift Button
	self.giftButton = vgui.Create("DButton", self)
	self.giftButton:gSetSize(fw(45), fh(45))
	self.giftButton:gSetPos(fx(273), fy(846))
	self.giftButton:SetText("")
	self.giftButton:SetMouseInputEnabled(true)
	self.giftButton:SetKeyboardInputEnabled(false)
	self.giftButton:SetZPos(100)
	self.giftButton.Paint = function(selff, w, h)
		RNDX.DrawMaterial(0, 0, 0, w, h, selff.hovered and Color(255, 255, 255, 150) or Color(255, 255, 255, 255), materials.gift_btn)
	end
	self.giftButton.DoClick = function()
		if IsValid(self.giftMenu) then
			-- Close gift menu and backdrop
			if IsValid(self.giftMenu) then
				self.giftMenu:Remove()
				self.giftMenu = nil
			end
			if IsValid(self.giftMenuBackdrop) then
				self.giftMenuBackdrop:Remove()
				self.giftMenuBackdrop = nil
			end
		else
			self:CreateGiftMenu()
		end
	end
	self.giftButton.OnCursorEntered = function(selff)
		selff.hovered = true
	end
	self.giftButton.OnCursorExited = function(selff)
		selff.hovered = false
	end

	-- Buy Premium Button
	self.buyPremiumButton = vgui.Create("DButton", self)
	self.buyPremiumButton:gSetSize(fw(280), fh(45))
	self.buyPremiumButton:gSetPos(fx(328), fy(846))
	self.buyPremiumButton:SetText("")
	self.buyPremiumButton:SetMouseInputEnabled(true)
	self.buyPremiumButton:SetKeyboardInputEnabled(false)
	self.buyPremiumButton:SetZPos(100)
	-- Visuel rendu en DHTML (look premium doré) au lieu du PNG. Paint vide : c'est le
	-- DHTML enfant (ci-dessous) qui peint ; le DButton garde le clic + le hover.
	self.buyPremiumButton.Paint = function() end

	if theme then
		self.buyPremiumButton.Paint = function(selff, w, h)
			RNDX.DrawMaterial(0, 0, 0, w, h, selff.hovered and Color(255, 255, 255, 210) or color_white, materials.buy_premium_btn)
			draw.SimpleText("ACHETER PREMIUM", "Bebas Neue:" .. gRespFont(23), w * 0.35, h / 2, Color(40, 20, 25), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(tostring(BATTLEPASS_CONFIG.premium_price), "Bebas Neue:" .. gRespFont(20), w * 0.82, h / 2, theme.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			RNDX.DrawMaterial(0, w * 0.92, h * 0.28, h * 0.44, h * 0.44, color_white, materials.coin)
		end
	else
	local bpHtml = vgui.Create("DHTML", self.buyPremiumButton)
	bpHtml:Dock(FILL)
	bpHtml:SetMouseInputEnabled(false) -- les clics traversent vers le DButton en dessous
	bpHtml:SetKeyboardInputEnabled(false) -- ne pas voler le focus clavier de la DFrame (sinon le re-appui-pour-fermer via OnKeyCodePressed ne reçoit plus la touche)
	self.buyPremiumButton._html = bpHtml

	-- Icône de pièce (EVO coin) inline en base64 (asset:// peu fiable en CEF) + fallback CSS.
	local _bpCoinRaw = file.Read("materials/fe4zd3gqw9qxmx3m2/sf2bzokdtqepolq0.png", "GAME")
	local _bpCoinURI = (_bpCoinRaw and _bpCoinRaw ~= "")
		and ("data:image/png;base64," .. util.Base64Encode(_bpCoinRaw, true)) or ""
	local coinHTML = (_bpCoinURI ~= "")
		and ('<img class="coin" src="' .. _bpCoinURI .. '">')
		or '<span class="coin coin-css"></span>'

	-- Concaténation (pas string.format) -> pas besoin d'échapper les % du CSS.
	bpHtml:SetHTML([[<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html,body { width:100%; height:100%; overflow:hidden; background:transparent;
  font-family:'Bebas Neue','Tungsten','Segoe UI',sans-serif; }
.btn { position:absolute; top:0; right:0; bottom:0; left:0;
  display:flex; align-items:center; justify-content:center; white-space:nowrap;
  border-radius:0.4rem;
  background: linear-gradient(180deg, #ffd24f 0%, #f4ad1d 100%);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,0.4), 0 1px 6px rgba(0,0,0,0.32);
  transition: filter 0.15s ease-out, transform 0.12s ease-out; }
.label { color:#2a1d04; font-weight:700; letter-spacing:0.04rem; font-size:0.8rem; text-transform:uppercase; }
.price { color:#2a1d04; font-weight:800; margin-left:0.5rem; font-size:0.92rem; display:flex; align-items:center; }
.coin { width:1rem; height:1rem; margin-left:0.3rem; vertical-align:middle; image-rendering:-webkit-optimize-contrast; }
.coin-css { display:inline-block; border-radius:50%; background:radial-gradient(circle at 35% 30%, #fff7d0, #d99a16 72%); box-shadow: inset 0 0 0 1px rgba(80,45,0,0.45); }
body.hovered .btn { filter:brightness(1.06); transform:translateY(-1px); }
</style></head><body>
<div class="btn"><span class="label">Acheter Premium</span><span class="price">]] .. tostring(BATTLEPASS_CONFIG.premium_price) .. coinHTML .. [[</span></div>
<script>
function fit(){ document.documentElement.style.fontSize = (window.innerHeight * 0.36) + 'px'; }
window.onload=fit; window.onresize=fit; fit();
</script></body></html>]])
	end
	self.buyPremiumButton.DoClick = function()
		if LocalPlayer():GetEvoNWBool("BattlePass_IsPremium", false) then
			LocalPlayer():OpenPopup("Vous avez déjà le battlepass premium !", "error")
			return
		end
		if LocalPlayer():GetEvoNWInt("coins", 0) < tonumber(BATTLEPASS_CONFIG.premium_price) then
			LocalPlayer():OpenPopup("Vous n'avez pas assez de coins ! Achetez des coins dans la boutique.", "error")
			return
		end
		LocalPlayer():OpenYesNoPopup("Voulez-vous vraiment acheter le battlepass premium pour " .. tostring(BATTLEPASS_CONFIG.premium_price) .. " coins ?", "BuyBattlePassPremium")
	end
	self.buyPremiumButton.OnCursorEntered = function(selff)
		selff.hovered = true
		if IsValid(selff._html) then selff._html:RunJavascript("if(document.body)document.body.classList.add('hovered');") end
	end
	self.buyPremiumButton.OnCursorExited = function(selff)
		selff.hovered = false
		if IsValid(selff._html) then selff._html:RunJavascript("if(document.body)document.body.classList.remove('hovered');") end
	end

	-- Claim All : bouton VGUI propre (RNDX arrondi + texte centré). Fiable et bien
	-- dimensionné — fini les soucis de police DHTML. Libellé "Récupérer tout".
	local claimW, claimH = fw(250), fh(54)
	local claimX, claimY = fx(1648) - claimW, fy(845)
	self.claimAllButton = vgui.Create("DButton", self)
	self.claimAllButton:gSetSize(claimW, claimH)
	self.claimAllButton:gSetPos(claimX, claimY)
	self.claimAllButton:SetText("")
	self.claimAllButton:SetMouseInputEnabled(true)
	self.claimAllButton:SetKeyboardInputEnabled(false)
	self.claimAllButton:SetZPos(100)
	self.claimAllButton.hovered = false
	self.claimAllButton.Paint = function(selff, w, h)
		if theme then
			RNDX.DrawMaterial(0, 0, 0, w, h, color_white, materials.claim_all_btn)
			draw.SimpleText("RÉCUPÉRER TOUT", "Bebas Neue:24", w / 2, h / 2, selff.hovered and theme.accent or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		-- Bouton Atelier : coin bas-droit coupé + liseré acier, libellé Bebas.
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, selff.hovered and Color(38, 38, 46, 255) or Color(22, 23, 28, 255), gRespY(10), "br")
			-- DA dashboard 08/07 : bouton plat, plus de lisere acier.
		else
			RNDX.Draw(0, 0, 0, w, h, selff.hovered and Color(38, 38, 46, 255) or Color(27, 27, 32, 255))
		end
		draw.SimpleText("RÉCUPÉRER TOUT", "Bebas Neue:24", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.claimAllButton.DoClick = function()
		net.Start("server:lzy_battlepass.ClaimAllItems")
		net.SendToServer()
	end
	self.claimAllButton.OnCursorEntered = function(selff) selff.hovered = true selff:SetCursor("hand") end
	self.claimAllButton.OnCursorExited = function(selff) selff.hovered = false end

	self:CreateScrollPanel()
	self:SetProgressStep(LocalPlayer():GetEvoNWInt("BattlePass_LastBpLevel", 0) + 1)
	
	-- Lock panel pousse plus bas (560 -> 585) pour laisser respirer la ligne
	-- des cercles J1..J10 (centree sur la frontiere free/premium @540) - sinon
	-- le blur RNDX empiete visuellement sur les cercles et les rend illisibles.
	-- Hauteur ajustee (270 -> 245) pour conserver la fin a 830.
	-- Icon premium recadre verticalement pour rester centre dans le nouveau panneau.
	self.premiumItemsRowLockPanel = vgui.Create("DPanel", self)
	self.premiumItemsRowLockPanel:gSetSize(fw(1375), fh(245))
	self.premiumItemsRowLockPanel:gSetPos(fx(273), fy(585))
	self.premiumItemsRowLockPanel:SetPaintBackgroundEnabled(false)
	self.premiumItemsRowLockPanel:SetMouseInputEnabled(false)
	self.premiumItemsRowLockPanel:SetZPos(105)
	self.premiumItemsRowLockPanel.Paint = function(selff, w, h)
		if not LocalPlayer():GetEvoNWBool("BattlePass_IsPremium", false) then
			RNDX.Draw(0, 0, 0, w, h, Color(255, 255, 255, 255), RNDX.BLUR)
			RNDX.DrawMaterial(0, gRespX(fw(643)), gRespY(fh(67)), gRespX(fw(88)), gRespY(fh(111)), Color(255, 255, 255, 255), materials.premium_lock_icon)
		end
	end

	-- Banner panel (renders on top of everything)
	self.bannerPanel = vgui.Create("DPanel", self)
	self.bannerPanel:gSetPos(fx(273), fy(250))
	self.bannerPanel:gSetSize(fw(168), fh(580)) -- Height covers both banners (290 + 290)
	self.bannerPanel:SetZPos(106) -- High Z position to be on top
	self.bannerPanel:SetPaintBackgroundEnabled(false)
	self.bannerPanel:SetMouseInputEnabled(false) -- Don't block mouse input
	self.bannerPanel.Paint = function(selff, w, h)
		RNDX.DrawMaterial(0, 0, 0, w, gRespY(fh(290)), Color(255, 255, 255, 255), materials.free_banner)
		RNDX.DrawMaterial(0, 0, gRespY(fh(290)), w, gRespY(fh(290)), Color(255, 255, 255, 255), materials.premium_banner)
	end
end

function PANEL:Paint(w, h)
	if theme then
		RNDX.DrawMaterial(0, 0, 0, w, h, color_white, materials.background)
		RNDX.DrawMaterial(0, gRespX(fx(266)), gRespY(fy(113)), gRespX(302), gRespY(24), color_white, materials.title_txt)
		RNDX.DrawMaterial(0, gRespX(fx(273)), gRespY(fy(165)), gRespX(700), gRespY(80), color_white, materials.edition_header)
	else
	-- Fond = mêmes appels que le spell selector (blur RNDX + voile 5,5,7,216).
	RNDX.Draw(0, 0, 0, w, h, Color(255, 255, 255), RNDX.BLUR)
	RNDX.Draw(0, 0, 0, w, h, Color(5, 5, 7, 216))

	-- Titre Bebas SANS bold + entaille slash1 réduite (remplace le PNG title_txt).
	draw.SimpleText("BATTLE PASS", "Bebas Neue:40", gRespX(fx(266)), gRespY(fy(104)), Color(237, 238, 242), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	surface.SetFont("Bebas Neue:40")
	local twT, thT = surface.GetTextSize("BATTLE PASS")
	if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(fx(266) - 2), gRespY(fy(104)) + thT * 0.78,
		twT * 1.15, gRespY(10), Color(207, 68, 78, 245))) then
		surface.SetDrawColor(theme and theme.accent or Color(207, 68, 78, 255))
		surface.DrawRect(gRespX(fx(266)), gRespY(fy(104)) + thT * 0.84, twT, gRespY(3))
	end

	end
	-- Timer de SAISON : temps restant avant le reset (commun à tous). Calculé depuis
	-- BATTLEPASS_CONFIG.GetEndDate() (saison roulante).
	if BATTLEPASS_CONFIG.GetSecondsLeft then
		local s  = BATTLEPASS_CONFIG.GetSecondsLeft()
		local dD = math.floor(s / 86400)
		local hH = math.floor((s % 86400) / 3600)
		local mM = math.floor((s % 3600) / 60)
		local txt = (dD > 0) and (dD .. "j " .. hH .. "h") or (hH .. "h " .. mM .. "m")
		draw.SimpleText("Fin de saison dans " .. txt, "Bebas Neue:" .. gRespFont(20), gRespX(fx(theme and 1120 or 266)), gRespY(fy(theme and 210 or 160)), Color(150, 154, 162), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	RNDX.DrawMaterial(0, gRespX(fx(273)), gRespY(fy(250)), gRespX(fw(1375)), gRespY(fh(290)), Color(255, 255, 255, 255), materials.free_panel)
	RNDX.DrawMaterial(0, gRespX(fx(273)), gRespY(fy(540)), gRespX(fw(1375)), gRespY(fh(290)), Color(255, 255, 255, 255), materials.premium_panel)

	-- ── Récompense quotidienne (encart sombre arrondi + écriture façon boutique) ──
	local bpXP   = LocalPlayer():GetEvoNWInt("BattlePass_XP", 0)
	local perLvl = math.max(1, BATTLEPASS_CONFIG.xp_per_level or 1000)
	local maxLvl = (BATTLEPASS_CONFIG.items and #BATTLEPASS_CONFIG.items) or 0
	local curLvl = math.min(maxLvl, math.floor(bpXP / perLvl))
	local rewardTxt = (curLvl >= maxLvl) and "Pass complété" or ((bpXP % perLvl) .. " / " .. perLvl .. " XP Pass")
	-- Encart = petite plaque Atelier (coin bas-droit coupé + liseré acier).
	if theme then
		RNDX.DrawMaterial(0, gRespX(fx(912)), gRespY(fy(95)), gRespX(324), gRespY(65), color_white, materials.reward_time_panel)
	elseif EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(gRespX(fx(912)), gRespY(fy(95)), gRespX(324), gRespY(65), Color(13, 14, 17, 220), gRespY(10), "br")
		-- DA dashboard 08/07 : encart plat, plus de lisere acier.
	else
		RNDX.Draw(0, gRespX(fx(912)), gRespY(fy(95)), gRespX(324), gRespY(65), Color(16, 16, 16, 200))
	end
	-- Libellé + valeur EMPILÉS (et non côte à côte). Sur une seule ligne, le long
	-- libellé "Récompense quotidienne" (~27px = quasi toute la largeur des 324px de
	-- l'encart) et la valeur XP alignée à droite se CHEVAUCHAIENT. On met le libellé
	-- en caption (petit, atténué) au-dessus, et la valeur en dessous — même principe
	-- que l'encart "EVO Coins" voisin.
	draw.SimpleText("Récompense quotidienne", "Avenir Next World:14", gRespX(fx(912) + 20), gRespY(fy(95) + 8), Color(255, 255, 255, 110), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(rewardTxt, "Bebas Neue:24", gRespX(fx(912) + 20), gRespY(fy(95) + 30), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	-- ── EVO Coins (petite plaque Atelier + écriture façon boutique) ──
	if theme then
		RNDX.DrawMaterial(0, gRespX(fx(1300)), gRespY(fy(97.5)), gRespX(159), gRespY(60), color_white, materials.coins_bg)
	elseif EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(gRespX(fx(1300)), gRespY(fy(97.5)), gRespX(159), gRespY(60), Color(13, 14, 17, 220), gRespY(10), "br")
		-- DA dashboard 08/07 : encart plat, plus de lisere acier.
	else
		RNDX.Draw(0, gRespX(fx(1300)), gRespY(fy(97.5)), gRespX(159), gRespY(60), Color(16, 16, 16, 200))
	end
	draw.SimpleText("EVO Coins", "Bebas Neue:20", gRespX(fx(1300) + 100), gRespY(fy(97.5) + 8), Color(255, 255, 255, 90), TEXT_ALIGN_RIGHT)
	draw.SimpleText(LocalPlayer():GetEvoNWInt("coins", 0), "Bebas Neue:24", gRespX(fx(1300) + 100), gRespY(fy(97.5) + 28), Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT)
	RNDX.DrawMaterial(0, gRespX(fx(1300) + 108), gRespY(fy(97.5) + 9), gRespX(42), gRespY(42), Color(255, 255, 255, 255), materials.coin)
end

-- Tooltip de description au survol d'un palier (dessiné APRÈS les enfants -> au-dessus,
-- et non clippé par le scroll). `self.bpHover` = { name, desc, panel } posé par les tuiles.
function PANEL:PaintOver(w, h)
	if self.bpPreview then
		draw.SimpleText("APERÇU STAFF · " .. self.bpThemeId .. " · Fermer pour revenir au thème du serveur", "Avenir Next World:" .. gRespFont(16), w / 2, gRespY(920), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
	-- Tooltip "XP du Battle Pass" au survol du bloc Récompense quotidienne :
	-- explique COMMENT gagner de l'XP de pass (valeurs lues dans la config -> exactes).
	do
		local rx, ry = gRespX(fx(912)), gRespY(fy(95))
		local rw, rh = gRespX(fw(324)), gRespY(fh(65))
		local mx, my = self:CursorPos()
		if mx >= rx and mx <= rx + rw and my >= ry and my <= ry + rh then
			local src = BATTLEPASS_CONFIG.xp_sources or {}
			local per = BATTLEPASS_CONFIG.xp_per_level or 1000
			local lines = {
				"Quête terminée  +" .. (src.quest or 0),
				"Quête quotidienne  +" .. (src.daily_quest or 0),
				"PNJ tué  +" .. (src.npc_kill or 0),
				"Boss tué  +" .. (src.boss_kill or 0),
				"Temps de jeu  +" .. (src.playtime or 0) .. " / " .. (src.playtime_interval or 10) .. " min",
			}
			local fT, fS = "Avenir Next World:" .. gRespFont(16), "Avenir Next World:" .. gRespFont(13)
			local padH = gRespX(14)
			local tw, th = gRespX(330), gRespY(190)
			-- Suit le curseur (avec clamp pour rester à l'écran).
			local tx = mx + gRespX(18)
			local ty = my + gRespY(12)
			if tx + tw > w then tx = mx - tw - gRespX(14) end
			if ty + th > h then ty = h - th - gRespY(8) end
			if tx < 0 then tx = gRespX(4) end
			if ty < 0 then ty = gRespY(4) end
			RNDX.Draw(gRespY(8), tx, ty, tw, th, Color(14, 14, 17, 250))
			surface.SetDrawColor(theme and theme.accent or Color(207, 68, 78, 255))
			surface.DrawRect(tx, ty, gRespX(3), th)
			local cy = ty + gRespY(12)
			draw.SimpleText("XP DU BATTLE PASS", fT, tx + padH, cy, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			cy = cy + gRespY(24)
			draw.SimpleText("Comment en gagner :", fS, tx + padH, cy, Color(150, 154, 162), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			cy = cy + gRespY(20)
			for _, l in ipairs(lines) do
				draw.SimpleText(l, fS, tx + padH, cy, Color(220, 222, 228), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				cy = cy + gRespY(20)
			end
			cy = cy + gRespY(4)
			draw.SimpleText(per .. " XP = 1 palier débloqué", fS, tx + padH, cy, Color(243, 195, 59), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local info = self.bpHover
	if not info or IsValid(self.giftMenu) then return end
	-- Auto-clear si on ne survole plus la tuile (ex: scroll sans OnCursorExited).
	if not (IsValid(info.panel) and info.panel:IsHovered()) then self.bpHover = nil return end
	if not info.name or info.name == "" then return end

	local titleFont = "Avenir Next World:" .. gRespFont(17)
	local descFont  = "Avenir Next World:" .. gRespFont(14)
	local pad, maxW = gRespX(12), gRespX(250)

	-- Word wrap de la description
	surface.SetFont(descFont)
	local lines = {}
	for _, raw in ipairs(string.Explode("\n", info.desc or "")) do
		local cur = ""
		for _, word in ipairs(string.Explode(" ", raw)) do
			local test = (cur == "") and word or (cur .. " " .. word)
			if surface.GetTextSize(test) > maxW and cur ~= "" then
				lines[#lines + 1] = cur ; cur = word
			else
				cur = test
			end
		end
		if cur ~= "" then lines[#lines + 1] = cur end
	end

	surface.SetFont(titleFont)
	local tw, th = surface.GetTextSize(info.name)
	surface.SetFont(descFont)
	local _, lh = surface.GetTextSize("Ag")
	local longest = tw
	for _, l in ipairs(lines) do
		local lw = surface.GetTextSize(l)
		if lw > longest then longest = lw end
	end

	local gap  = gRespY(6)
	local boxW = longest + pad * 2
	local boxH = pad * 2 + th + (#lines > 0 and (gap + #lines * lh) or 0)

	local mx, my = self:CursorPos()
	local bx, by = mx + gRespX(18), my + gRespY(10)
	if bx + boxW > w then bx = mx - boxW - gRespX(14) end
	if by + boxH > h then by = h - boxH - gRespY(8) end
	if bx < 0 then bx = gRespX(4) end
	if by < 0 then by = gRespY(4) end

	if RNDX then
		RNDX.Draw(gRespY(8), bx, by, boxW, boxH, Color(14, 14, 17, 250))
	else
		draw.RoundedBox(8, bx, by, boxW, boxH, Color(14, 14, 17, 250))
	end
	surface.SetDrawColor(theme and theme.accent or Color(207, 68, 78, 255))
	surface.DrawRect(bx, by, gRespX(3), boxH)

	draw.SimpleText(info.name, titleFont, bx + pad, by + pad, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	local ty = by + pad + th + gap
	for _, l in ipairs(lines) do
		draw.SimpleText(l, descFont, bx + pad, ty, Color(185, 188, 194), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		ty = ty + lh
	end
end

-- FERMETURE par re-appui sur la touche bindée : géré ICI (la DFrame reçoit OnKeyCodePressed
-- car elle a le focus clavier) et PAS dans PlayerButtonDown — ce dernier est SUPPRIMÉ quand
-- le menu a le focus, donc il ne reçoit jamais la touche pour fermer. Garde `_opened` (0.25s,
-- posée dans Init) pour que l'appui d'OUVERTURE ne referme pas aussitôt (sinon flash).
function PANEL:OnKeyCodePressed(keycode)
	if self._opened and keycode == LocalPlayer():GetBindKey("battlepass") then
		self:Close()
	end
end

function PANEL:OnClose()
	preview_theme = nil
	-- Clean up gift menu and backdrop if they exist
	if IsValid(self.giftMenu) then
		self.giftMenu:Remove()
		self.giftMenu = nil
	end
	if IsValid(self.giftMenuBackdrop) then
		self.giftMenuBackdrop:Remove()
		self.giftMenuBackdrop = nil
	end
	self:Remove()
	frame = nil
	if openedFrame == self then openedFrame = nil end
	timer.Simple(0.1, function() can_open = true end)
end

vgui.Register("lzy_battlepass", PANEL, "DFrame")

function OpenBattlePass()
	if IsValid(frame) then
		frame:Close()
	else
		frame = vgui.Create("lzy_battlepass")
		can_open = false
	end
end

-- OUVERTURE SEULE. La FERMETURE par re-appui est dans PANEL:OnKeyCodePressed (voir plus
-- haut) car PlayerButtonDown est SUPPRIMÉ quand le menu a le focus -> il ne reçoit jamais
-- la touche pour fermer. Open-only règle AUSSI le "flash" : sur l'appui d'ouverture,
-- PlayerButtonDown fire 2× (MakePopup re-poll l'input) ; le 2e appel voit `frame` valide
-- -> `not IsValid(frame)` est faux -> aucune action (donc plus de fermeture parasite).
hook.Add("PlayerButtonDown", "BattlePass_OpenMenu", function(ply, button)
    if button ~= LocalPlayer():GetBindKey("battlepass") then return end
    if not IsValid(frame) and can_open == true then
        OpenBattlePass()
    end
end)

-- (Échap = géré par `openedFrame` + le hook OnPauseMenuShow de lzy_escape_menu, voir Init.
--  Pas de hook Think/gui.IsGameUIVisible ici : le menu pause est justement EMPÊCHÉ par
--  OnPauseMenuShow, donc gui.IsGameUIVisible() ne serait jamais vrai.)

net.Receive("client:lzy_battlepass.InitData", function()
	playerProgress = ReadProgressTable()
	net.ReadBool() -- Ancien indicateur journalier, conservé dans le protocole serveur.
	-- Le serveur choisit la saison : aucune dépendance à l'horloge du joueur.
	apply_server_theme(net.ReadString())
	serverSeasonKey = net.ReadString() -- saison servie (passes planifiés) : les tuiles suivent le serveur, pas l'horloge du joueur
	if IsValid(frame) then
		frame:UpdateItemPanels()
		frame:SetProgressStep(LocalPlayer():GetEvoNWInt("BattlePass_LastBpLevel", 0) + 1)
	end
end)

net.Receive("client:lzy_battlepass.InitConnectedPlayers", function()
	connectedPlayers = ReadConnectedPlayersTable()
	if IsValid(frame) and IsValid(frame.giftMenu) and frame.giftMenu.UpdatePlayerList then
		frame.giftMenu.UpdatePlayerList()
	end
end)

net.Receive("client:lzy_battlepass.AddConnectedPlayer", function()
	local steamid64 = net.ReadString()
	local name = net.ReadString()

	-- Check if player is already in the connected players list
	for i, player in ipairs(connectedPlayers) do
		if player.steamid64 == steamid64 then
			return
		end
	end

	-- Add player to the connected players list
	table.insert(connectedPlayers, {
		steamid64 = steamid64,
		name = name
	})
	
	-- Update player list if gift menu is open
	if IsValid(frame) and IsValid(frame.giftMenu) and frame.giftMenu.UpdatePlayerList then
		frame.giftMenu.UpdatePlayerList()
	end
end)

net.Receive("client:lzy_battlepass.RemoveConnectedPlayer", function()
	local steamid64 = net.ReadString()

	for i, player in ipairs(connectedPlayers) do
		if player.steamid64 == steamid64 then
			table.remove(connectedPlayers, i)
			break
		end
	end
	
	-- Update player list if gift menu is open
	if IsValid(frame) and IsValid(frame.giftMenu) and frame.giftMenu.UpdatePlayerList then
		frame.giftMenu.UpdatePlayerList()
	end
end)

net.Receive("client:lzy_battlepass.UpdatePlayerProgress", function()
	playerProgress = ReadProgressTable()

	-- if frame is open, update item panels
	if IsValid(frame) then
		frame:UpdateItemPanels()
	end
end)
