-- "addons\\lzy_battlepass\\lua\\lzy_battlepass\\cl_themes.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local cached = {}
local palettes = {
	halloween = { accent = Color(245, 139, 69), progress = Color(194, 154, 234), track = Color(50, 40, 63) },
	noel = { accent = Color(226, 182, 116), progress = Color(169, 233, 234), track = Color(36, 65, 77) },
}
local asset_names = {
	"background", "title_txt", "edition_header", "free_panel", "premium_panel",
	"free_item_panel", "free_item_panel_hover", "premium_item_panel", "premium_item_panel_hover",
	"item_claimed", "free_banner", "premium_banner", "gift_btn", "buy_premium_btn",
	"claim_btn", "claim_btn_premium", "claim_all_btn", "close", "progress_node", "progress_node_locked",
	"reward_time_panel", "coins_bg", "gift_menu_bg", "gift_menu_item_bg", "gift_menu_item_bg_hover",
	"searchbox_bg",
}

-- Appelé à l'ouverture uniquement ; aucun chargement de matériau dans Paint.
function BATTLEPASS_CONFIG.ResolveUITheme(normal_materials, selected)
	local palette = palettes[selected]
	if not palette then return nil, normal_materials end
	if cached[selected] == false then return nil, normal_materials end
	if not cached[selected] then
		local materials = {}
		for _, name in ipairs(asset_names) do
			local path = "evo_battlepass/" .. selected .. "/" .. name .. ".png"
			local material = Material(path, "smooth")
			if material:IsError() then
				ErrorNoHalt("[BattlePass] Texture manquante : " .. path .. "; retour au thème normal.\n")
				cached[selected] = false
				return nil, normal_materials
			end
			materials[name] = material
		end
		cached[selected] = setmetatable(materials, { __index = normal_materials })
	end
	return palette, cached[selected]
end
