-- "addons\\evo_support\\lua\\autorun\\client\\cl_support.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO SUPPORT — fenêtre du menu C (bouton SUPPORT). Onglets :
--   Poser une question (FAQ + envoi Helpers) · Faire un report
--   (sélectionné / récent) · Signaler un bug (catégories) · Mes dossiers · Guides
-- Style EVO_UI (kit partagé). Les envois passent par le serveur (net) -> tickets.
--
-- RESPONSIVE : tout est posé en unités de base (1920x1080) et mis à l'échelle
-- UNE SEULE fois via R() avec un facteur UNIFORME (même X et Y). La fenêtre garde
-- donc ses proportions sur n'importe quel écran / ratio (16:9, 16:10, 5:4,
-- ultrawide) — plus de déformation ni de chevauchement sur les écrans non-1080p.
-- ============================================================================

if not CLIENT then return end

-- Échelle uniforme : facteur LINÉAIRE min(largeur, hauteur). Les fonts (cf. MakeFonts) utilisent
-- EXACTEMENT ce même facteur -> texte et boîtes scalent à l'identique. (On n'utilise PAS le
-- gRespFont de glibs qui scale la police de façon conservatrice et désynchroniserait le texte.)
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/OST/forge) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

-- ── Contenu éditable : FAQ + Guides (remplis ça avec tes vrais textes) ──────
local FAQ = {
	{ q = "Comment débloquer mon Shikai ?", a = "Atteins le niveau requis puis va voir ton instructeur de division pour lancer la quête de Shikai. Suis l'objectif affiché dans le tracker." },
	{ q = "Comment rejoindre une division ?", a = "Parle au capitaine ou au PNJ de recrutement de la division au Seireitei, puis accepte la quête d'intégration." },
	{ q = "Comment gagner des coins ?", a = "Complète des quêtes, gagne des events, ou achète des coins sur la boutique du site." },
}

local GUIDES = {
	{ t = "Comment devenir Shinigami", body = "Rejoins l'Académie au Seireitei, suis le tutoriel d'entrainement (flashstep, concentration, combat), puis passe l'examen d'entrée." },
	{ t = "Comment devenir Arrancar", body = "Depuis le Hueco Mundo en tant que Hollow, accumule de la puissance puis arrache ton masque (quête Hollow Mask) pour évoluer en Arrancar." },
	{ t = "Comment obtenir son Shikai", body = "Atteins le niveau requis, lance la quête de Shikai auprès de ton instructeur, communie avec ton zanpakuto et termine l'épreuve." },
	{ t = "Comment rejoindre une division", body = "Va au Seireitei, parle au PNJ de recrutement de la division visée et accepte la quête d'intégration." },
}

local BUG_CATS = { "Quête", "Map", "Pouvoir", "Animation", "Interface", "Autre" }

-- Catégories d'un signalement joueur.
-- Catégories du report. `cible = true` -> il FAUT designer un joueur ; sinon la
-- cible est facultative (26/07/26 : un report ne concerne pas forcement quelqu'un,
-- ça peut être un objet perdu, un souci de map, un besoin de staff en jeu).
local REPORT_CATS = {
	{ label = "Freekill",            cible = true },
	{ label = "Cheat",               cible = true },
	{ label = "Insultes",            cible = true },
	{ label = "Troll",               cible = true },
	{ label = "Bug Abuse",           cible = true },
	{ label = "Métagaming",          cible = true },
	{ label = "Besoin d'un staff",   cible = false },
	{ label = "Objet / argent perdu", cible = false },
	{ label = "Problème sur la map", cible = false },
	{ label = "Autre",               cible = false },
}

-- Libellé lisible d'un type de ticket + date courte.
local TYPE_LABELS = { question = "Question", player_report = "Report", bug = "Bug" }
local function typeLabel(ty) return TYPE_LABELS[ty] or ty or "?" end
local function fmtDate(ts) ts = tonumber(ts) or 0 if ts <= 0 then return "—" end return os.date("%d/%m %H:%M", ts) end

-- Joueur présélectionné par le clic-droit "Signaler le joueur".
local preselectTarget = nil

-- ── Suivi des joueurs croisés récemment (persiste même après leur déco) ─────
local RECENT = {}   -- liste { steamid, name }
local recentNext = 0
hook.Add("Think", "EVO_Support::TrackRecent", function()
	local t = CurTime()
	if t < recentNext then return end
	recentNext = t + 2
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	for _, p in player.Iterator() do
		-- STAFF EN SERVICE EXCLU (09/08). Ce hook tourne chez TOUT LE MONDE, pas seulement
		-- chez le staff, et la liste s'affiche telle quelle dans « Signaler un joueur ».
		-- Sans ce filtre, n'importe quel joueur voyait apparaître le nom RP et le SteamID64
		-- d'un modérateur, d'un responsable ou d'un superadmin invisible qui passait à moins
		-- de 1500 u — le cloak masque le corps, il ne masquait pas cette liste.
		-- Double test volontaire : EVO_StaffMode couvre le mode staff/animateur networké,
		-- GetNoDraw rattrape tout autre masquage de rendu (sam_cloak posé à la main, etc.).
		if p ~= lp and IsValid(p)
			and not p:GetEvoNWBool("EVO_StaffMode", false) and not p:GetNoDraw()
			and p:GetPos():DistToSqr(lp:GetPos()) <= (1500 * 1500) then
			local sid = p:SteamID64()
			local nm  = p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname", "") or p:Nick()
			local found
			for _, e in ipairs(RECENT) do if e.steamid == sid then found = e break end end
			if found then found.name = nm
			else table.insert(RECENT, 1, { steamid = sid, name = nm }) end
		end
	end
	while #RECENT > 12 do table.remove(RECENT) end
end)

-- Joueur visé par l'eye-trace (= "joueur sélectionné")
local function AimedPlayer()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local tr = util.TraceLine({ start = lp:EyePos(), endpos = lp:EyePos() + lp:GetAimVector() * 4000, filter = lp })
	local e = tr.Entity
	if IsValid(e) and e:IsPlayer() then return e end
	return nil
end

-- ── Rôle (helper/staff) + chat, reçus du serveur ───────────────────────────
local ROLE = { helper = false, staff = false, soumisService = false }

-- Réclamer exige le mode staff (gate serveur sv_support/claimThen). Les tickets restent
-- VISIBLES hors service — c'est la prise en charge qui est bloquée, pas la lecture.
-- Renvoie true si CE joueur peut réclamer maintenant.
local function peutReclamer()
	if not ROLE.soumisService then return true end
	local lp = LocalPlayer()
	return IsValid(lp) and lp:GetEvoNWBool("EVO_StaffMode", false) == true
end
local pSupport, EVO_Sup_CurTab   -- forward (pSupport assigné dans EVO_OpenSupport)
net.Receive("EVO:Support:Role", function()
	local h, s = net.ReadBool(), net.ReadBool()
	local serv = net.ReadBool()
	local changed = (ROLE.helper ~= h) or (ROLE.staff ~= s)
	ROLE.helper, ROLE.staff, ROLE.soumisService = h, s, serv
	-- Si le rôle change pendant que le menu est ouvert, on le réouvre pour
	-- afficher/retirer les onglets Réponses/Signalements tout de suite.
	if changed and IsValid(pSupport) and EVO_OpenSupport then EVO_OpenSupport(EVO_Sup_CurTab) end
end)

local CHAT = { id = nil, onMsgs = nil }
net.Receive("EVO:Support:ChatMsgs", function()
	local id = net.ReadString()
	local msgs = net.ReadTable()
	if CHAT.id == id and CHAT.onMsgs then CHAT.onMsgs(msgs) end
end)
local EVO_Support_OnQueue, EVO_Support_OnReports
net.Receive("EVO:Support:Queue",   function() local l = net.ReadTable() if EVO_Support_OnQueue   then EVO_Support_OnQueue(l)   end end)
net.Receive("EVO:Support:Reports", function() local l = net.ReadTable() if EVO_Support_OnReports then EVO_Support_OnReports(l) end end)

-- ── Fenêtre ─────────────────────────────────────────────────────────────────
pSupport = nil
local C = function() return EVO_UI and EVO_UI.Col or { bg = Color(16,16,19,250), border = Color(255,255,255,20), divider = Color(255,255,255,18), title = Color(238,239,243), muted = Color(150,154,162), dim = Color(106,109,118), accent = Color(207,68,78), green = Color(78,196,128) } end

-- IMPORTANT : on N'UTILISE PAS gCreateRespFont (glibs) ici. Son scaling de police est volontairement
-- "conservateur" (racine carrée : fontScale = 1 + (sqrt(scale)-1)*0.7, cf. glibs/responsive.lua) ->
-- la police bougeait BEAUCOUP MOINS que les boîtes/positions posées via R() (échelle LINÉAIRE
-- min(largeur,hauteur)). Résultat : noms de dossiers "pas responsive" (texte trop gros dans des
-- lignes rétrécies en petit écran, trop petit en grand). On recrée donc les fonts avec le MÊME
-- facteur LINÉAIRE que R() -> texte et boîtes scalent à l'identique sur tout écran/ratio.
local function MakeFonts()
	local f = math.min(ScrW() / 1920, ScrH() / 1080) -- identique au facteur de R()
	local function mk(name, fam, size, weight)
		surface.CreateFont(name, { font = fam, size = math.Round(size * f), weight = weight, antialias = true })
	end
	-- DA Atelier : Bebas Neue SANS bold pour l'affichage (onglets/titres/boutons),
	-- Roboto conservée pour le corps de texte (lisible en bas-de-casse).
	mk("EVO_Sup_Title", "Bebas Neue", 34, 400)
	mk("EVO_Sup_Tab",   "Bebas Neue", 21, 400)
	mk("EVO_Sup_H",     "Bebas Neue", 24, 400)
	mk("EVO_Sup_Body",  "Roboto", 15, 400)
	mk("EVO_Sup_Small", "Roboto", 13, 500)
	mk("EVO_Sup_Btn",   "Bebas Neue", 19, 400)
end
hook.Add("Initialize", "EVO_Support::FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "EVO_Support::Fonts", MakeFonts)
MakeFonts() -- création immédiate (surface.CreateFont est dispo dès le chargement)
MakeFonts()

-- Petite croix de fermeture (échelle uniforme, parentée sur la carte).
local function CloseBtn(parent, cardWbase, fClose)
	local col = C()
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(R(28), R(28))
	b:SetPos(R(cardWbase - 42), R(19))
	b.Paint = function(s, w, h)
		-- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			s:IsHovered() and col.accent or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClose
	return b
end

-- Petit bouton plein (accent) ou contour. x/y/w/h en unités de BASE.
local function StyledButton(parent, label, x, y, w, h, filled)
	local col = C()
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(R(x), R(y))
	b:SetSize(R(w), R(h))
	b.Paint = function(s, bw, bh)
		local hov = s:IsHovered()
		if filled then
			RNDX.Draw(0, 0, 0, bw, bh, ColorAlpha(col.accent, hov and 255 or 220))
			draw.SimpleText(label, "EVO_Sup_Btn", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			RNDX.Draw(0, 0, 0, bw, bh, ColorAlpha(color_white, hov and 14 or 7))
			RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(col.border, hov and 60 or 32), 1)
			draw.SimpleText(label, "EVO_Sup_Btn", bw / 2, bh / 2, hov and col.title or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	return b
end

-- x/y/w/h en unités de BASE.
local function StyledEntry(parent, x, y, w, h, placeholder, multiline)
	local col = C()
	local e = vgui.Create("DTextEntry", parent)
	e:SetPos(R(x), R(y))
	e:SetSize(R(w), R(h))
	e:SetFont("EVO_Sup_Body")
	e:SetDrawLanguageID(false)
	e:SetMultiline(multiline or false)
	e:SetPlaceholderText(placeholder or "")
	e:SetPlaceholderColor(ColorAlpha(col.dim, 200))
	e:SetTextColor(col.title)
	e:SetPaintBackground(false)
	e.Paint = function(s, bw, bh)
		RNDX.Draw(0, 0, 0, bw, bh, ColorAlpha(Color(8, 8, 10), 230))
		RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(col.border, s:HasFocus() and 70 or 34), 1)
		s:DrawTextEntryText(col.title, col.accent, col.title)
		if not s:HasFocus() and s:GetValue() == "" then
			draw.SimpleText(s:GetPlaceholderText() or "", "EVO_Sup_Body", R(10), bh / 2, ColorAlpha(col.dim, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	return e
end

local function Notify(msg, ok)
	if MUGEN and MUGEN.Notify then MUGEN.Notify(msg, ok and (NOTIFY_GENERIC or 0) or NOTIFY_ERROR, 5) else chat.AddText(msg) end
end

local function Submit(payload, fThen)
	net.Start("EVO:Support:Submit")
	net.WriteTable(payload)
	net.SendToServer()
	if fThen then fThen() end
end

-- Envoi d'une action staff sur un signalement (TP / bring / freeze / close).
-- NB : réclamer exige d'être EN SERVICE (mode staff). Le refus est posé SERVEUR
-- (sv_support, claimThen) et pas ici : le client ne connaît pas CanStaffMode, qui
-- vit côté serveur, donc un garde client bloquerait aussi le cas — prévu serveur —
-- de quelqu'un qui a la permission support sans pouvoir passer en mode staff. Le
-- serveur renvoie une notif qui dit quoi faire, c'est suffisant.
local function ReportAction(id, action)
	net.Start("EVO:Support:ReportAction")
	net.WriteString(id) net.WriteString(action)
	net.SendToServer()
end

-- ── Popups de signalement (haut-gauche, façon SAM) ──────────────────────────
-- Apparaissent chez le staff quand un joueur fait un signalement. Cliquables
-- quand le curseur est dispo (ouvre le menu contexte C). 1 SEUL staff peut
-- "Claim" un ticket ; après claim : TP / Bring / Retour / Geler / Traité.
-- Quand il y en a beaucoup, les derniers (en bas) sont estompés + floutés.
local POPUPS = {}   -- le plus récent en tête

local function popupById(id)
	for _, p in ipairs(POPUPS) do if IsValid(p) and p._rid == id then return p end end
end

local function reflowPopups()
	-- Hauteurs VARIABLES (description multi-lignes, 08/02) : on garde ce qui TIENT à
	-- l'écran en cumulant les hauteurs réelles, et on supprime les plus anciens (queue
	-- de liste) qui déborderaient — l'ancien calcul par hauteur fixe (124) laissait
	-- les popups longs sortir de l'écran. Le plus récent est toujours gardé.
	local yFit, maxY, keep = R(96), ScrH() - R(30), 0
	for i, p in ipairs(POPUPS) do
		if IsValid(p) then
			local ph = p:GetTall()
			if i > 1 and yFit + ph > maxY then break end
			yFit = yFit + ph + R(8)
		end
		keep = i
	end
	while #POPUPS > math.max(1, keep) do
		local old = table.remove(POPUPS, #POPUPS)
		if IsValid(old) then old:Remove() end
	end
	local n, y = #POPUPS, R(96)
	for i, p in ipairs(POPUPS) do
		if IsValid(p) then
			p:SetPos(R(12), y)
			local fromBottom = n - i
			if n >= 4 and fromBottom == 0 then p._fade, p._blur = 0.30, true
			elseif n >= 5 and fromBottom == 1 then p._fade, p._blur = 0.62, false
			else p._fade, p._blur = 1, false end
			local interactive = not p._blur
			p:SetMouseInputEnabled(interactive)
			if p._setInteractive then p._setInteractive(interactive) end
			y = y + p:GetTall() + R(8)
		end
	end
end

local function removePopup(p)
	for i = #POPUPS, 1, -1 do if POPUPS[i] == p then table.remove(POPUPS, i) break end end
	if IsValid(p) then p:Remove() end
	reflowPopups()
end

local function showReportPopup(rep)
	if popupById(rep.id) then return end
	local col = C()
	local W = 332

	-- Description COMPLÈTE (demande user 08/02 : « le message est coupé, les modos
	-- doivent lire l'intégralité ») : wrap en plusieurs lignes via splitText (glibs,
	-- même découpe que gRespDrawMultilineText), le popup s'adapte à la hauteur du
	-- texte. Garde-fou anti-pavé : 12 lignes max puis « … ». Repli sans glibs :
	-- l'ancienne troncature 1 ligne.
	surface.SetFont("EVO_Sup_Small")
	local descLines
	if splitText then
		descLines = splitText(rep.desc or "", "EVO_Sup_Small", R(W - 26))
		if #descLines == 0 then descLines = { "" } end
		if #descLines > 12 then
			for i = #descLines, 13, -1 do descLines[i] = nil end
			descLines[12] = descLines[12] .. " …"
		end
	else
		local d, maxw = rep.desc or "", R(W - 26)
		if surface.GetTextSize(d) > maxw then
			while surface.GetTextSize(d .. "…") > maxw and #d > 1 do d = string.sub(d, 1, #d - 2) end
			d = d .. "…"
		end
		descLines = { d }
	end
	-- Hauteur adaptative : base 122 pour 1 ligne de description, +16 par ligne en plus.
	local H = 122 + (#descLines - 1) * 16

	local p = vgui.Create("DPanel")
	p._rid, p._state, p._claimer = rep.id, "free", ""
	p._fade, p._blur, p._a = 1, false, 0
	p._descLines = descLines
	p:SetSize(R(W), R(H))
	p.Think = function(s) s._a = Lerp(FrameTime() * 10, s._a, 1) end
	p.Paint = function(s, w, h)
		local a = s._a * (s._fade or 1)
		if s._blur and EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 4) end
		RNDX.Draw(0, 0, 0, w, h, ColorAlpha(col.bg, 250 * a))
		RNDX.DrawOutlined(0, 0, 0, w, h, ColorAlpha(s._state == "mine" and col.green or col.accent, 70 * a), 1)
		surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
		surface.DrawRect(R(13), R(13), R(3), R(12))
		draw.SimpleText("SIGNALEMENT", "EVO_Sup_Btn", R(23), R(13), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(rep.reporter .. "  →  " .. (rep.target ~= "" and rep.target or "?"), "EVO_Sup_Small", R(13), R(33), ColorAlpha(col.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local dy = R(50)
		for _, ln in ipairs(s._descLines or {}) do
			draw.SimpleText(ln, "EVO_Sup_Small", R(13), dy, ColorAlpha(col.dim, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			dy = dy + R(16)
		end
		if s._state == "other" then
			draw.SimpleText("Réclamé par " .. (s._claimer ~= "" and s._claimer or "un staff"), "EVO_Sup_Small", R(13), dy + R(6), ColorAlpha(col.accent, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
	end

	local x = vgui.Create("DButton", p) x:SetText("")
	x:SetSize(R(20), R(20)) x:SetPos(R(W - 26), R(9))
	x.Paint = function(s, w, h) draw.SimpleText("×", "EVO_UI_X", w / 2, h / 2, s:IsHovered() and col.title or col.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
	x.DoClick = function() removePopup(p) end

	-- boutons dynamiques selon l'état
	local btns = {}
	local function clearBtns() for _, b in ipairs(btns) do if IsValid(b) then b:Remove() end end btns = {} end
	local function addBtn(label, bx, bw, filled, fn)
		local b = StyledButton(p, label, bx, H - 34, bw, 26, filled)
		b.DoClick = fn
		btns[#btns + 1] = b
	end
	local function rebuild()
		clearBtns()
		if p._state == "mine" then
			local defs = { { "TP", "goto" }, { "Bring", "bring" }, { "Retour", "return" }, { "Geler", "freeze" }, { "Traité", "close", true } }
			local bx, bw, gap = 13, 57, 4
			for _, d in ipairs(defs) do
				addBtn(d[1], bx, bw, d[3], function() ReportAction(rep.id, d[2]) if d[2] == "close" then removePopup(p) end end)
				bx = bx + bw + gap
			end
		elseif p._state == "free" then
			-- Le ticket reste VISIBLE hors service : seule la prise en charge est bloquee.
			-- Le libelle le dit au lieu de laisser cliquer sur un bouton muet.
			-- On RE-teste au clic (et pas la valeur capturee a la construction) : entre
			-- l'affichage du popup et le clic, le staff a pu passer en service.
			local bOk = peutReclamer()
			p._claimOk = bOk
			addBtn(bOk and "Claim" or "Mode staff requis", 13, 122, bOk, function()
				if not peutReclamer() then
					Notify("Passe en mode staff (!staff) pour prendre un signalement.", false)
					return
				end
				ReportAction(rep.id, "claim")
			end)
			addBtn("Traité", 141, 100, false, function() ReportAction(rep.id, "close") removePopup(p) end)
		end
	end
	p._setInteractive = function(on) for _, b in ipairs(btns) do if IsValid(b) then b:SetMouseInputEnabled(on) end end end
	-- Le popup vit pendant que le staff tape !staff : on suit le changement de service
	-- pour reconstruire les boutons, sinon le libelle restait bloque sur l ancien etat.
	--
	-- ⚠ ON CHAÎNE, on ne remplace PAS. Ce panel a déjà un Think, et il ne fait pas
	-- de la décoration : c'est lui qui monte `_a` de 0 à 1, l'opacité que le Paint
	-- applique à TOUT le popup. L'écraser laissait `_a` à 0 -> le signalement
	-- s'affichait totalement transparent, et le staff concluait qu'il ne recevait
	-- plus les tickets (report user 05/08, personne ne les voyait plus).
	local thinkFondu = p.Think
	p.Think = function(s2)
		if thinkFondu then thinkFondu(s2) end
		if s2._state ~= "free" then return end
		local bOk = peutReclamer()
		if s2._claimOk ~= bOk then rebuild() end
	end
	p._setState = function(state, claimer) p._state, p._claimer = state, claimer or "" rebuild() end
	rebuild()

	table.insert(POPUPS, 1, p)
	reflowPopups()
end

-- ── Clic sur les tickets quand le menu contexte C est ouvert ────────────────
-- Les popups de signalement sont des panneaux NON-popup ; le menu C (plein écran
-- MakePopup) passe AU-DESSUS et capte les clics VGUI -> impossible de cliquer les
-- tickets normalement. Le menu C diffuse `GUIMousePressed` exprès -> on l'écoute et
-- on déclenche À LA MAIN le bouton du ticket survolé (hit-test par rect écran).
-- Fonctionne quelle que soit la source du curseur (menu C, property menu, etc.).
hook.Add("GUIMousePressed", "EVO:Support:PopupClicks", function(code)
	if code ~= MOUSE_LEFT then return end
	local mx, my = gui.MousePos()
	for _, p in ipairs(POPUPS) do
		if IsValid(p) and not p._blur then
			for _, c in ipairs(p:GetChildren()) do
				if IsValid(c) and c:IsVisible() and isfunction(c.DoClick) then
					local bx, by = c:LocalToScreen(0, 0)
					local bw, bh = c:GetSize()
					if mx >= bx and mx <= bx + bw and my >= by and my <= by + bh then
						c:DoClick()
						return
					end
				end
			end
		end
	end
end)

net.Receive("EVO:Support:NewReport", function()
	showReportPopup({
		id        = net.ReadString(),
		reporter  = net.ReadString(),
		target    = net.ReadString(),
		targetSid = net.ReadString(),
		desc      = net.ReadString(),
	})
end)

net.Receive("EVO:Support:ReportClaimed", function()
	local id, sid, nm = net.ReadString(), net.ReadString(), net.ReadString()
	local p = popupById(id)
	if not p then return end
	local lp = LocalPlayer()
	if IsValid(lp) and sid == lp:SteamID64() then p._setState("mine") else p._setState("other", nm) end
	reflowPopups()
end)

net.Receive("EVO:Support:ReportClosed", function()
	local p = popupById(net.ReadString())
	if p then removePopup(p) end
end)

-- Wrap d'un texte en <= maxlines lignes (avec "…" si ça déborde). maxw en px réels.
local function WrapText(text, font, maxw, maxlines)
	maxlines = maxlines or 2
	surface.SetFont(font)
	local out, cur = {}, ""
	for _, wd in ipairs(string.Explode(" ", tostring(text or ""))) do
		local test = (cur == "") and wd or (cur .. " " .. wd)
		if surface.GetTextSize(test) <= maxw or cur == "" then cur = test
		else out[#out + 1] = cur cur = wd end
	end
	if cur ~= "" then out[#out + 1] = cur end
	if #out > maxlines then
		local last = out[maxlines]
		while surface.GetTextSize(last .. "…") > maxw and #last > 1 do last = string.sub(last, 1, #last - 1) end
		out[maxlines] = last .. "…"
		for i = #out, maxlines + 1, -1 do out[i] = nil end
	end
	return out
end

-- ── Contenus des onglets ────────────────────────────────────────────────────
-- Chaque builder remplit le panel `host` (déjà vidé). ctx.cw/ctx.ch en BASE.
local TABS, BuildChat

local function BuildQuestion(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Poser une question")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	local entry = StyledEntry(host, 0, 34, ctx.cw, 36, "Écris ta question…")
	local answer = vgui.Create("DPanel", host)
	answer:SetPos(R(0), R(120)) answer:SetSize(R(ctx.cw), R(ctx.ch - 120))
	answer:SetPaintBackground(false)
	answer._txt, answer._helpers = nil, false
	answer.Paint = function(s, w, h)
		if not s._txt then return end
		RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, 6))
		RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(col.border, 30), 1)
		local pad = R(14)
		surface.SetFont("EVO_Sup_Body")
		local y = R(14)
		-- wrap simple
		local words, cur = string.Explode(" ", s._txt), ""
		local maxw = w - pad * 2
		for _, wd in ipairs(words) do
			local test = cur == "" and wd or cur .. " " .. wd
			if surface.GetTextSize(test) > maxw and cur ~= "" then
				draw.SimpleText(cur, "EVO_Sup_Body", pad, y, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				y = y + R(18) cur = wd
			else cur = test end
		end
		if cur ~= "" then draw.SimpleText(cur, "EVO_Sup_Body", pad, y, col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) end
	end

	StyledButton(host, "Rechercher", 0, 78, 150, 34, true).DoClick = function()
		local q = string.lower(entry:GetValue() or "")
		if #q < 3 then return end
		local best
		for _, e in ipairs(FAQ) do
			local lq = string.lower(e.q)
			if string.find(lq, q, 1, true) or string.find(q, string.lower(string.sub(e.q, 1, 12)), 1, true) then best = e break end
		end
		if best then answer._txt = "Réponse : " .. best.a
		else answer._txt = "Aucune réponse automatique trouvée. Envoie ta question aux Helpers ci-dessous." end
		answer._helpers = (best == nil)
		if IsValid(ctx.sendBtn) then ctx.sendBtn:SetVisible(answer._helpers) end
	end

	ctx.sendBtn = StyledButton(host, "Envoyer aux Helpers", 160, 78, 180, 34, false)
	ctx.sendBtn:SetVisible(false)
	ctx.sendBtn.DoClick = function()
		local q = entry:GetValue() or ""
		if #q < 5 then return end
		Submit({ kind = "question", category = "question", categoryLabel = "Question", description = q })
		Notify("Question envoyée aux Helpers.", true)
		EVO_OpenSupport("Mes dossiers")
	end
end

local function BuildReportPlayer(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Faire un report")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	-- Catégorie (chips qui s'enroulent).
	local catLbl = vgui.Create("DLabel", host) catLbl:SetFont("EVO_Sup_Small") catLbl:SetTextColor(col.dim)
	catLbl:SetText("Catégorie :") catLbl:SetPos(R(0), R(30)) catLbl:SetSize(R(200), R(16))
	local chosenCat = { id = "", label = "", cible = false }
	local startX, gap, lineH = 0, R(6), R(26)
	local maxW, cx, cy = R(ctx.cw), 0, R(48)
	local fMajCible -- defini plus bas (le libelle de la cible depend de la categorie)
	for _, cat in ipairs(REPORT_CATS) do
		local label = cat.label
		surface.SetFont("EVO_Sup_Small")
		local tw = select(1, surface.GetTextSize(label))
		if tw <= 0 then tw = #label * R(8) end -- fallback si font pas prête
		local bw = tw + R(20)
		if cx + bw > maxW then cx = startX cy = cy + lineH + gap end
		local lab = label
		local chip = vgui.Create("DButton", host) chip:SetText("")
		chip:SetPos(cx, cy) chip:SetSize(bw, R(24))
		chip.Paint = function(s, w, h)
			local on = chosenCat.label == lab
			if on then RNDX.Draw(0, 0, 0, w, h, ColorAlpha(col.accent, 230))
			else RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, s:IsHovered() and 14 or 7)) RNDX.DrawOutlined(0, 0, 0, w, h, ColorAlpha(col.border, 30), 1) end
			draw.SimpleText(lab, "EVO_Sup_Small", w / 2, h / 2, on and color_white or col.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		chip.DoClick = function()
			chosenCat.label = lab
			chosenCat.id    = string.lower((lab:gsub("%s", "_")))
			chosenCat.cible = cat.cible == true
			if fMajCible then fMajCible() end
		end
		cx = cx + bw + gap
	end

	local selected = { steamid = "", name = "" }
	local lblSel = vgui.Create("DLabel", host)
	lblSel:SetFont("EVO_Sup_Small") lblSel:SetTextColor(col.muted)
	lblSel:SetPos(R(0), R(150)) lblSel:SetSize(R(ctx.cw), R(20))
	-- Dit CLAIREMENT si la cible est requise pour la categorie choisie, plutot que
	-- de laisser le joueur decouvrir le refus au moment d'envoyer.
	fMajCible = function()
		if not IsValid(lblSel) then return end
		if selected.steamid ~= "" then
			lblSel:SetText("Cible : " .. selected.name .. "  (" .. selected.steamid .. ")")
		elseif chosenCat.label == "" then
			lblSel:SetText("Choisis d'abord une catégorie.")
		elseif chosenCat.cible then
			lblSel:SetText("Aucun joueur sélectionné (obligatoire pour « " .. chosenCat.label .. " »).")
		else
			lblSel:SetText("Aucun joueur sélectionné (facultatif pour « " .. chosenCat.label .. " »).")
		end
	end
	local function setSel(sid, nm) selected.steamid, selected.name = sid, nm fMajCible() end
	fMajCible()

	StyledButton(host, "Joueur visé (viseur)", 0, 100, 180, 32, true).DoClick = function()
		local p = AimedPlayer()
		if not IsValid(p) then Notify("Vise un joueur puis réessaie.", false) return end
		setSel(p:SteamID64(), p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname") or p:Nick())
	end

	-- Présélection (clic-droit "Signaler le joueur").
	if preselectTarget then setSel(preselectTarget.steamid, preselectTarget.name) preselectTarget = nil end

	-- Liste joueurs récents (scroll)
	local lblR = vgui.Create("DLabel", host)
	lblR:SetFont("EVO_Sup_Small") lblR:SetTextColor(col.dim) lblR:SetText("OU joueurs croisés récemment :")
	lblR:SetPos(R(300), R(102)) lblR:SetSize(R(ctx.cw - 300), R(18))
	local scroll = vgui.Create("DScrollPanel", host)
	scroll:SetPos(R(300), R(124)) scroll:SetSize(R(ctx.cw - 300), R(50))
	for _, e in ipairs(RECENT) do
		local r = vgui.Create("DButton", scroll) r:SetText("") r:Dock(TOP) r:SetTall(R(24)) r:DockMargin(0, 0, 0, R(3))
		r.Paint = function(s, w, h)
			if s:IsHovered() then RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, 12)) end
			draw.SimpleText(e.name, "EVO_Sup_Small", R(8), h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		r.DoClick = function() setSel(e.steamid, e.name) end
	end

	local desc = StyledEntry(host, 0, 182, ctx.cw, ctx.ch - 182 - 46, "Décris ce qu'il s'est passé (RDM, insultes, triche, objet perdu…)", true)
	StyledButton(host, "Envoyer le report", 0, ctx.ch - 40, 220, 34, true).DoClick = function()
		if chosenCat.label == "" then Notify("Choisis une catégorie.", false) return end
		-- Cible exigée SEULEMENT pour les catégories qui visent quelqu'un.
		if chosenCat.cible and selected.steamid == "" then
			Notify("Cette catégorie vise un joueur : choisis-le d'abord.", false) return
		end
		if #(desc:GetValue() or "") < 5 then Notify("Ajoute une description.", false) return end
		Submit({ kind = "player", category = chosenCat.id, categoryLabel = chosenCat.label, targetSteamId = selected.steamid, targetName = selected.name, description = desc:GetValue() })
		Notify("Report envoyé. Merci !", true)
		EVO_OpenSupport("Mes dossiers")
	end
end

local function BuildReportBug(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Signaler un bug")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	-- Les bugs se signalent sur le SITE : on peut y joindre des liens vidéo / preuves.
	-- (Même mise en page que "Signalement externe" pour que le bouton soit au MÊME endroit.)
	local info = vgui.Create("DLabel", host)
	info:SetFont("EVO_Sup_Body") info:SetTextColor(col.muted) info:SetWrap(true) info:SetContentAlignment(7)
	info:SetPos(R(0), R(40)) info:SetSize(R(ctx.cw), R(130))
	info:SetText("Les bugs se signalent sur le site : tu peux y joindre des liens vidéo, des screenshots et donner plus de détails.\n\nRécompense selon la gravité : Mineur ≈ 50 coins · Important ≈ 200 coins · Critique ≈ 500 coins.")

	StyledButton(host, "Ouvrir le formulaire (site)", 0, 158, 260, 40, true).DoClick = function()
		gui.OpenURL("https://evo-roleplay.com/BleachRP/panel/report?type=bug")
		Notify("Formulaire de bug ouvert dans ton navigateur.", true)
	end
end

-- ── Signalement externe : signaler un joueur avec PREUVES via le site ────────
-- Complète "Faire un report" (rapide, in-game) pour les cas où il faut
-- joindre une vidéo / des screenshots, ou quand le joueur est hors-ligne.
local function BuildExternalReport(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Signalement externe")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	local info = vgui.Create("DLabel", host)
	info:SetFont("EVO_Sup_Body") info:SetTextColor(col.muted) info:SetWrap(true) info:SetContentAlignment(7)
	info:SetPos(R(0), R(40)) info:SetSize(R(ctx.cw), R(130))
	info:SetText("Utilise ce formulaire pour signaler un joueur avec des PREUVES (vidéo, screenshots) ou quand il est hors-ligne / quand ça s'est passé plus tôt.\n\nLe formulaire du site permet de tout détailler et de joindre des fichiers. Pense à donner son nom et/ou son SteamID.")

	StyledButton(host, "Ouvrir le formulaire (site)", 0, 158, 260, 40, true).DoClick = function()
		gui.OpenURL("https://evo-roleplay.com/BleachRP/panel/report?type=player_report")
		Notify("Formulaire de signalement ouvert dans ton navigateur.", true)
	end
end

local STAT = false
local function StatusOf(col, status)
	local M = { open = { "En attente", col.muted }, in_review = { "En cours", Color(224,162,60) }, resolved = { "Traité", col.green }, rejected = { "Refusé", col.accent }, escalated = { "En cours (modération)", Color(224,162,60) } }
	return M[status] or { status or "?", col.muted }
end

-- Liste générique de tickets dans `scroll`. onOpen(t) si la ligne est cliquable.
local function FillTicketList(scroll, list, col, emptyMsg, onOpen, rightHint)
	if not IsValid(scroll) then return end
	scroll:GetCanvas():Clear()
	if not list or #list == 0 then
		local l = vgui.Create("DLabel", scroll) l:SetFont("EVO_Sup_Body") l:SetTextColor(col.dim) l:SetText(emptyMsg) l:Dock(TOP) l:SetTall(R(24)) return
	end
	for _, t in ipairs(list) do
		local clickable = onOpen and (t.type == "question" or rightHint == "report" or rightHint == "dossier")
		local r = vgui.Create(clickable and "DButton" or "DPanel", scroll)
		if clickable then r:SetText("") end
		r:Dock(TOP) r:SetTall(R(50)) r:DockMargin(0, 0, R(6), R(8)) r:SetPaintBackground(false)
		r.Paint = function(s, w, h)
			RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, (clickable and s:IsHovered()) and 13 or 7))
			-- ligne 1 : #id + type ; ligne 2 : date (+ cible si présente)
			local tyLbl = typeLabel(t.type)
			-- id de longueur variable : on mesure sa largeur réelle (draw.SimpleText
			-- la renvoie) et on colle le type juste après, sinon un x fixe chevauchait
			-- le type sur les id longs (#SUP-...).
			local idW = draw.SimpleText("#" .. (t.id or "?"), "EVO_Sup_Small", R(14), R(13), col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(tyLbl, "EVO_Sup_Small", R(14) + idW + R(12), R(13), col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local meta = fmtDate(t.createdAt)
			-- Serveur du joueur : les 2 serveurs partagent la meme file de tickets, un
			-- helper doit savoir OU aller avant de se deplacer (demande user 27/07).
			if t.serveur and t.serveur ~= "" then meta = meta .. "  ·  " .. t.serveur end
			if t.targetName and t.targetName ~= "" then meta = meta .. "  ·  cible: " .. t.targetName
			elseif t.categoryLabel and t.categoryLabel ~= "" and t.categoryLabel ~= tyLbl then meta = meta .. "  ·  " .. t.categoryLabel end
			draw.SimpleText(meta, "EVO_Sup_Small", R(14), R(30), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local st = StatusOf(col, t.status)
			draw.SimpleText(st[1], "EVO_Sup_Small", w - R(14), R(13), st[2], TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			if clickable then draw.SimpleText((rightHint == "report") and "Ouvrir ›" or "Détails ›", "EVO_Sup_Small", w - R(14), R(30), col.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP) end
		end
		if clickable then r.DoClick = function() onOpen(t) end end
	end
end

-- Un dossier s'ouvre sur la vue CHAT (BuildChat) : le joueur lit les réponses
-- ET peut répondre (demande user 02/08 — l'ancienne vue détail était lecture seule).
local BuildDossiers
function BuildDossiers(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Mes dossiers")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	local scroll = vgui.Create("DScrollPanel", host)
	scroll:SetPos(R(0), R(34)) scroll:SetSize(R(ctx.cw), R(ctx.ch - 34))

	EVO_Support_OnDossiers = function(list)
		FillTicketList(scroll, list, col, "Aucun dossier pour l'instant.", function(t)
			host:Clear() BuildChat(host, ctx, t, function() host:Clear() BuildDossiers(host, ctx) end)
		end, "dossier")
	end
	net.Start("EVO:Support:GetDossiers") net.SendToServer()
end

-- ── Onglet "Mes sanctions" (joueur) ─────────────────────────────────────────
-- Montre les AVERTISSEMENTS reçus (evo_warns, retirés inclus) + les restrictions
-- LIVE (mute micro / mute chat). Lecture seule, le serveur ne renvoie que SES
-- propres sanctions. Callback global (même schéma que EVO_Support_OnDossiers).
local function fmtRemainSecs(sec)
	sec = tonumber(sec) or 0
	if sec < 0 then return "permanent" end
	if sec >= 86400 then return math.floor(sec / 86400) .. "j " .. math.floor((sec % 86400) / 3600) .. "h"
	elseif sec >= 3600 then return math.floor(sec / 3600) .. "h " .. math.floor((sec % 3600) / 60) .. "m"
	elseif sec >= 60 then return math.floor(sec / 60) .. "m"
	else return math.floor(sec) .. "s" end
end

local function BuildSanctions(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Mes sanctions")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	-- Zone STATUT (restrictions live) — TOUJOURS présente (pas de reflow async).
	local status = vgui.Create("DPanel", host)
	status:SetPos(R(0), R(34)) status:SetSize(R(ctx.cw), R(46)) status:SetPaintBackground(false)
	status._lines = nil -- nil = chargement ; {} = aucune restriction
	status.Paint = function(s, w, h)
		local active = s._lines and #s._lines > 0
		RNDX.Draw(0, 0, 0, w, h, ColorAlpha(active and col.accent or color_white, active and 22 or 7))
		RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(active and col.accent or col.border, active and 60 or 26), 1)
		if not s._lines then
			draw.SimpleText("Chargement…", "EVO_Sup_Small", R(12), h / 2, col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return
		end
		if #s._lines == 0 then
			draw.SimpleText("Aucune restriction active (micro / chat).", "EVO_Sup_Small", R(12), h / 2, col.green, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return
		end
		local single = #s._lines == 1
		local y = single and (h / 2) or R(10)
		for _, ln in ipairs(s._lines) do
			draw.SimpleText(ln, "EVO_Sup_Small", R(12), y, col.accent, TEXT_ALIGN_LEFT, single and TEXT_ALIGN_CENTER or TEXT_ALIGN_TOP)
			y = y + R(18)
		end
	end

	local subt = vgui.Create("DLabel", host)
	subt:SetFont("EVO_Sup_Small") subt:SetTextColor(col.dim) subt:SetText("AVERTISSEMENTS")
	subt:SetPos(R(2), R(90)) subt:SetSize(R(ctx.cw), R(16))

	local scroll = vgui.Create("DScrollPanel", host)
	scroll:SetPos(R(0), R(110)) scroll:SetSize(R(ctx.cw), R(ctx.ch - 110))

	EVO_Support_OnSanctions = function(data)
		if not (IsValid(status) and IsValid(scroll)) then return end
		data = data or {}

		-- SAM (ce build) : gag = micro, mute = chat texte (cf. serveur).
		local lines = {}
		if data.gagged then lines[#lines + 1] = "Micro coupé — " .. fmtRemainSecs(data.gagRemain) end
		if data.muted  then lines[#lines + 1] = "Chat coupé — "  .. fmtRemainSecs(data.muteRemain) end
		status._lines = lines

		scroll:GetCanvas():Clear()
		local warns = data.warns or {}
		if #warns == 0 then
			local l = vgui.Create("DLabel", scroll) l:SetFont("EVO_Sup_Body") l:SetTextColor(col.dim)
			l:SetText("Aucun avertissement. Continue comme ça !") l:Dock(TOP) l:SetTall(R(24))
			return
		end
		for _, wn in ipairs(warns) do
			local removed = wn.removed
			local expired = (not removed) and wn.expired == true -- plus actif par ancienneté (7 j)
			local r = vgui.Create("DPanel", scroll)
			r:Dock(TOP) r:SetTall(R(60)) r:DockMargin(0, 0, R(6), R(8)) r:SetPaintBackground(false)
			r.Paint = function(s, w, h)
				RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, 7))
				surface.SetDrawColor(removed and col.green or (expired and col.dim or col.accent))
				surface.DrawRect(0, R(9), R(3), h - R(18))
				draw.SimpleText(wn.title ~= "" and wn.title or "Avertissement", "EVO_Sup_Btn", R(14), R(9), (removed or expired) and col.muted or col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				local d = wn.reason or ""
				surface.SetFont("EVO_Sup_Small")
				local maxw = w - R(120)
				if surface.GetTextSize(d) > maxw then
					while surface.GetTextSize(d .. "…") > maxw and #d > 1 do d = string.sub(d, 1, #d - 2) end
					d = d .. "…"
				end
				draw.SimpleText(d ~= "" and d or "-", "EVO_Sup_Small", R(14), R(28), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(fmtDate(wn.at) .. "  ·  par " .. (wn.staff or "?"), "EVO_Sup_Small", R(14), R(43), col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(removed and "Retiré" or (expired and "Expiré" or "Actif"), "EVO_Sup_Small", w - R(14), R(9), removed and col.green or (expired and col.dim or col.accent), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
			end
		end
	end
	net.Start("EVO:Support:GetSanctions") net.SendToServer()
end

local function BuildGuides(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host)
	title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Guides")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))

	local body = vgui.Create("DLabel", host)
	body:SetFont("EVO_Sup_Body") body:SetTextColor(col.muted) body:SetWrap(true) body:SetContentAlignment(7)
	body:SetPos(R(232), R(34)) body:SetSize(R(ctx.cw - 232), R(ctx.ch - 34))
	body:SetText("Choisis un guide à gauche.")

	local scroll = vgui.Create("DScrollPanel", host)
	scroll:SetPos(R(0), R(34)) scroll:SetSize(R(216), R(ctx.ch - 34))
	for _, g in ipairs(GUIDES) do
		local r = vgui.Create("DButton", scroll) r:SetText("") r:Dock(TOP) r:SetTall(R(34)) r:DockMargin(0, 0, 0, R(5))
		r.Paint = function(s, w, h)
			RNDX.Draw(0, 0, 0, w, h, ColorAlpha(color_white, s:IsHovered() and 13 or 7))
			draw.SimpleText(g.t, "EVO_Sup_Small", R(10), h / 2, s:IsHovered() and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		r.DoClick = function() body:SetText(g.body) end
	end
end

-- ── Vue CHAT d'un ticket (joueur <-> helper/staff) ──────────────────────────
-- BuildChat est forward-déclaré (utilisé par les listes plus haut).
function BuildChat(host, ctx, t, backFn)
	local col = C()
	local staffView = ROLE.helper or ROLE.staff

	local back = StyledButton(host, "‹ Retour", 0, 0, 96, 28, false)
	back.DoClick = function() CHAT.id = nil CHAT.onMsgs = nil if backFn then backFn() end end

	local hdr = vgui.Create("DLabel", host) hdr:SetFont("EVO_Sup_H") hdr:SetTextColor(col.title)
	hdr:SetText("#" .. (t.id or "") .. (t.targetName and t.targetName ~= "" and ("  ·  " .. t.targetName) or ""))
	hdr:SetPos(R(108), R(0)) hdr:SetSize(R(ctx.cw - 108 - 120), R(28))

	-- Statut du ticket côté joueur (l'ancienne vue détail l'affichait ; le staff a
	-- ses boutons d'action à cet emplacement).
	if not staffView then
		hdr:SetWide(R(ctx.cw - 108 - 172))
		local st = StatusOf(col, t.status)
		local sl = vgui.Create("DLabel", host) sl:SetFont("EVO_Sup_Btn") sl:SetTextColor(st[2])
		sl:SetText(st[1]) sl:SetContentAlignment(6)
		sl:SetPos(R(ctx.cw - 160), R(0)) sl:SetSize(R(160), R(28))
	end

	local scroll = vgui.Create("DScrollPanel", host)
	scroll:SetPos(R(0), R(40)) scroll:SetSize(R(ctx.cw), R(ctx.ch - 40 - 46))

	local function bubble(name, text, mine)
		local p = vgui.Create("DPanel", scroll) p:Dock(TOP) p:DockMargin(0, 0, R(8), R(8)) p:SetPaintBackground(false)
		local maxw = R(ctx.cw) - R(28)
		local lines = WrapText(text or "", "EVO_Sup_Body", maxw - R(20), 12)
		p:SetTall(R(22) + #lines * R(17) + R(10))
		p.Paint = function(s, w, h)
			RNDX.Draw(0, 0, 0, w, h, ColorAlpha(mine and col.accent or color_white, mine and 30 or 8))
			draw.SimpleText(name or "?", "EVO_Sup_Small", R(12), R(8), mine and col.accent or col.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local y = R(26)
			for _, ln in ipairs(lines) do draw.SimpleText(ln, "EVO_Sup_Body", R(12), y, col.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) y = y + R(17) end
		end
	end

	local function render(msgs)
		if not IsValid(scroll) then return end
		scroll:GetCanvas():Clear()
		bubble((t.reporterName or "Joueur") .. " (demande)", t.desc or "", not staffView)
		for _, m in ipairs(msgs or {}) do bubble(m.name .. (m.staff and " (staff)" or ""), m.msg, m.staff == staffView) end
		timer.Simple(0, function() if IsValid(scroll) then scroll:ScrollToChild(scroll:GetCanvas():GetChildren()[#scroll:GetCanvas():GetChildren()] or scroll) end end)
	end
	CHAT.id = t.id CHAT.onMsgs = render
	net.Start("EVO:Support:ChatGet") net.WriteString(t.id) net.SendToServer()
	-- rafraîchissement léger toutes les 3s tant que le chat est ouvert
	timer.Create("EVO_Sup_ChatPoll", 3, 0, function()
		if not IsValid(scroll) or CHAT.id ~= t.id then timer.Remove("EVO_Sup_ChatPoll") return end
		net.Start("EVO:Support:ChatGet") net.WriteString(t.id) net.SendToServer()
	end)

	-- Ticket clos : plus de saisie côté joueur (il n'est plus dans aucune file
	-- staff, la réponse partirait dans le vide). Le serveur bloque aussi (miroir).
	local closed = (t.status == "resolved" or t.status == "rejected")
	if closed and not staffView then
		local cl = vgui.Create("DLabel", host) cl:SetFont("EVO_Sup_Body") cl:SetTextColor(col.dim)
		cl:SetText("Ticket clos — tu ne peux plus répondre. Refais un ticket si besoin.")
		cl:SetPos(R(0), R(ctx.ch - 38)) cl:SetSize(R(ctx.cw), R(32))
	else
		local input = StyledEntry(host, 0, ctx.ch - 38, ctx.cw - 112, 32, "Écris un message…")
		local function send()
			local m = input:GetValue() or "" if #m < 1 then return end
			net.Start("EVO:Support:ChatSend") net.WriteString(t.id) net.WriteString(m) net.SendToServer()
			input:SetText("")
			timer.Simple(0.25, function() if CHAT.id == t.id then net.Start("EVO:Support:ChatGet") net.WriteString(t.id) net.SendToServer() end end)
		end
		input.OnEnter = send
		StyledButton(host, "Envoyer", ctx.cw - 102, ctx.ch - 38, 102, 32, true).DoClick = send
	end

	-- Bouton "Marquer traité" en HAUT À DROITE (helper/staff) : ferme le ticket
	-- et revient à la liste (où il disparaît, car les traités ne sont plus listés).
	if staffView then
		StyledButton(host, "Marquer traité", ctx.cw - 112, 0, 112, 28, true).DoClick = function()
			net.Start("EVO:Support:SetStatus") net.WriteString(t.id) net.WriteString("resolved") net.SendToServer()
			Notify("Ticket traité.", true)
			CHAT.id = nil CHAT.onMsgs = nil
			if backFn then backFn() end
		end

		-- TRANSMETTRE AUX MODÉRATEURS (26/07/26) : un helper qui bute sur une question
		-- (sanction, litige, triche) la passe au staff sans que le joueur refasse un
		-- ticket. Réservé aux QUESTIONS non déjà transmises : un report est déjà chez
		-- les modérateurs, et re-transmettre n'aurait aucun sens.
		if t.type == "question" and t.status ~= "escalated" then
			StyledButton(host, "Transmettre aux modérateurs", ctx.cw - 112 - R(212), 0, 204, 28, false).DoClick = function()
				Derma_StringRequest(
					"Transmettre aux modérateurs",
					"Pourquoi ? (facultatif, visible dans le fil du ticket)",
					"",
					function(sRaison)
						net.Start("EVO:Support:Escalate")
						net.WriteString(t.id)
						net.WriteString(sRaison or "")
						net.SendToServer()
						CHAT.id = nil CHAT.onMsgs = nil
						if backFn then backFn() end
					end,
					function() end,
					"Transmettre", "Annuler"
				)
			end
		end
	end
end

-- ── Onglet HELPER : Réponses (questions) ────────────────────────────────────
local function BuildQueue(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host) title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Réponses : questions des joueurs")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))
	local scroll = vgui.Create("DScrollPanel", host) scroll:SetPos(R(0), R(34)) scroll:SetSize(R(ctx.cw), R(ctx.ch - 34))
	EVO_Support_OnQueue = function(list)
		FillTicketList(scroll, list, col, "Aucune question en attente.", function(t)
			host:Clear() BuildChat(host, ctx, t, function() host:Clear() BuildQueue(host, ctx) end)
		end, "report")
	end
	net.Start("EVO:Support:GetQueue") net.SendToServer()
end

-- ── Vue ACTION d'un signalement (staff) : Claim + TP/Bring/Retour/Geler/Close ─
-- (≠ chat : un signalement sert à intervenir sur la scène, pas à discuter.)
local function BuildReportAction(host, ctx, t, backFn)
	local col = C()
	local lp = LocalPlayer()
	local assigned = t.assignedSteamId or ""
	local mine = assigned ~= "" and IsValid(lp) and assigned == lp:SteamID64()
	local claimedOther = assigned ~= "" and not mine

	local back = StyledButton(host, "‹ Retour", 0, 0, 96, 28, false)
	back.DoClick = function() if backFn then backFn() end end

	local hdr = vgui.Create("DLabel", host) hdr:SetFont("EVO_Sup_H") hdr:SetTextColor(col.title)
	hdr:SetText("#" .. (t.id or "") .. (t.targetName and t.targetName ~= "" and ("  ·  cible: " .. t.targetName) or ""))
	hdr:SetPos(R(108), R(0)) hdr:SetSize(R(ctx.cw - 108 - 120), R(28))

	-- Le joueur peut répondre depuis « Mes dossiers » (02/08) : le staff doit donc
	-- pouvoir lire / répondre au fil d'un signalement aussi, pas seulement agir.
	StyledButton(host, "Discussion", ctx.cw - 112, 0, 112, 28, false).DoClick = function()
		host:Clear() BuildChat(host, ctx, t, function() host:Clear() BuildReportAction(host, ctx, t, backFn) end)
	end

	-- infos + LOGS AUTO (scroll) : catégorie, scène, description, et l'activité
	-- récente du joueur ciblé attachée automatiquement par le serveur.
	local info = vgui.Create("DScrollPanel", host)
	info:SetPos(R(0), R(40)) info:SetSize(R(ctx.cw), R(ctx.ch - 40 - 92))
	local function iline(txt, font, color, mtop)
		local l = vgui.Create("DLabel", info) l:Dock(TOP) l:DockMargin(R(2), R(mtop or 0), R(8), 0)
		l:SetFont(font) l:SetTextColor(color) l:SetText(txt) l:SetTall(R(18))
		return l
	end
	local function iblock(txt, color)
		local l = vgui.Create("DLabel", info) l:Dock(TOP) l:DockMargin(R(2), R(2), R(8), 0)
		l:SetFont("EVO_Sup_Body") l:SetTextColor(color or col.title) l:SetText(txt)
		l:SetWrap(true) l:SetAutoStretchVertical(true)
		return l
	end

	iline("Signalé par : " .. (t.reporterName or "?") .. (claimedOther and "   (réclamé par un autre staff)" or mine and "   (réclamé par toi)" or ""),
		"EVO_Sup_Small", claimedOther and col.accent or mine and col.green or col.muted)
	iline("Cible : " .. (t.targetName and t.targetName ~= "" and t.targetName or "?") .. "   ·   " .. (t.categoryLabel or t.category or "-"), "EVO_Sup_Small", col.accent, 2)
	-- Sur QUEL serveur le joueur a ouvert le ticket : sans ca un helper du Seireitei
	-- pouvait chercher pendant 5 minutes un joueur qui etait sur Hueco.
	if t.serveur and t.serveur ~= "" then
		iline("Serveur : " .. t.serveur, "EVO_Sup_Small", col.muted, 2)
	end
	iline("Description", "EVO_Sup_H", col.title, 8)
	iblock(t.desc and t.desc ~= "" and t.desc or "—")

	-- Logs auto (JSON attaché au ticket)
	local logs = (t.logs and t.logs ~= "") and util.JSONToTable(t.logs) or nil
	iline("Logs auto", "EVO_Sup_H", col.title, 12)
	if not istable(logs) then
		iblock("Aucun log (joueur hors ligne au moment du signalement).", col.dim)
	else
		if logs.pos and logs.pos ~= "" then iline("Position : " .. logs.pos, "EVO_Sup_Small", col.muted, 2) end
		local LOGCATS = { { "damage", "Dégâts récents" }, { "powers", "Pouvoirs utilisés" }, { "kills", "Kills" }, { "deaths", "Morts / KO" }, { "chat", "Chat" } }
		local any = false
		for _, lc in ipairs(LOGCATS) do
			local arr = logs[lc[1]]
			if istable(arr) and #arr > 0 then
				any = true
				iline(lc[2], "EVO_Sup_Small", col.title, 6)
				for _, e in ipairs(arr) do iline("· " .. tostring(e), "EVO_Sup_Small", col.dim) end
			end
		end
		if not any and (not logs.pos or logs.pos == "") then iblock("Aucune activité récente enregistrée.", col.dim) end
	end

	-- deux rangées d'actions (curseur garanti ici : le menu est ouvert)
	local r1, r2 = ctx.ch - 84, ctx.ch - 42
	-- Actions qui RECLAMENT le ticket au passage (meme liste que le gate serveur) :
	-- hors mode staff elles sont refusees, donc on previent avant le clic. « Marquer
	-- traite » n'en fait pas partie, clore ne reclame pas.
	local RECLAME = { claim = true, goto = true, bring = true, ["return"] = true, freeze = true }
	local function act(label, action, x, y, filled, closeAfter)
		local bBloque = RECLAME[action] and not peutReclamer()
		StyledButton(host, label, x, y, 158, 34, filled and not bBloque).DoClick = function()
			-- Re-test au clic : le staff a pu passer en service depuis l'ouverture de la fiche.
			if RECLAME[action] and not peutReclamer() then
				Notify("Passe en mode staff (!staff) pour prendre un signalement.", false)
				return
			end
			ReportAction(t.id, action) Notify("Action : " .. label, true)
			if closeAfter and backFn then backFn() end
		end
	end
	act("Claim",          "claim",  0,   r1, false)
	act("Téléporter",     "goto",   166, r1, false)
	act("Ramener",        "bring",  332, r1, false)
	act("Retour",         "return", 0,   r2, false)
	act("Geler",          "freeze", 166, r2, false)
	act("Marquer traité", "close",  332, r2, true, true)
end

-- ── Onglet STAFF : Signalements (joueurs) ───────────────────────────────────
local function BuildReports(host, ctx)
	local col = C()
	local title = vgui.Create("DLabel", host) title:SetFont("EVO_Sup_H") title:SetTextColor(col.title) title:SetText("Signalements : joueurs")
	title:SetPos(R(0), R(0)) title:SetSize(R(ctx.cw), R(24))
	local scroll = vgui.Create("DScrollPanel", host) scroll:SetPos(R(0), R(34)) scroll:SetSize(R(ctx.cw), R(ctx.ch - 34))
	EVO_Support_OnReports = function(list)
		FillTicketList(scroll, list, col, "Aucun signalement.", function(t)
			host:Clear() BuildReportAction(host, ctx, t, function() host:Clear() BuildReports(host, ctx) end)
		end, "report")
	end
	net.Start("EVO:Support:GetReports") net.SendToServer()
end

TABS = {
	{ id = "Poser une question", build = BuildQuestion },
	{ id = "Faire un report",    build = BuildReportPlayer },
	{ id = "Signalement externe", build = BuildExternalReport },
	{ id = "Signaler un bug",    build = BuildReportBug },
	{ id = "Mes dossiers",       build = BuildDossiers },
	{ id = "Mes sanctions",      build = BuildSanctions },
	{ id = "Guides",             build = BuildGuides },
}

function EVO_OpenSupport(startTab)
	MakeFonts() -- garantit les fonts du support (glibs dispo au runtime)
	if EVO_UI and EVO_UI.MakeFonts then EVO_UI.MakeFonts() end -- idem fonts du kit
	if IsValid(pSupport) then pSupport:Remove() end
	local col = C()
	local CARD_W, CARD_H = 950, 590 -- agrandie (+25%, demande user 06/07)
	local SIDEBAR = 260
	local cardW, cardH = R(CARD_W), R(CARD_H)

	-- Backdrop PLEIN ÉCRAN flouté (le flou n'est pas clippé ici)
	pSupport = vgui.Create("DFrame")
	pSupport:SetSize(ScrW(), ScrH())
	pSupport:SetPos(0, 0)
	pSupport:SetTitle("") pSupport:ShowCloseButton(false) pSupport:SetDraggable(false)
	pSupport:SetPaintBackgroundEnabled(false) -- sinon la DFrame dessine un fond CARRÉ derrière la carte arrondie
	pSupport:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(pSupport) end
	pSupport._a = 0
	-- Fondu d'ouverture ACCÉLÉRÉ (12 -> 30, comme le menu échap) : le "temps
	-- d'attente avant l'ouverture" ressenti était ce fade de ~0.35s. À 30 il
	-- atteint ~255 en ~0.11s : l'UI s'ouvre net sans à-coup.
	pSupport.Think = function(s) s._a = Lerp(FrameTime() * 30, s._a, 255) end
	pSupport.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		-- Fond = mêmes appels que le spell selector (RNDX.BLUR + voile 5,5,7,216).
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * a)
		surface.DrawRect(0, 0, w, h)
	end
	pSupport.OnMousePressed = function() if IsValid(pSupport) then pSupport:Remove() end end
	net.Start("EVO:Support:WantRole") net.SendToServer() -- rôle frais (prise en compte d'un changement de rang)

	-- Carte centrée (ENFANT) -> coins arrondis propres (plus de bug de clipping)
	local card = vgui.Create("DPanel", pSupport)
	card:SetSize(cardW, cardH)
	card:SetPos(math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2))
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (pSupport and pSupport._a or 255) / 255
		if a < 0.01 then return end
		-- Plaque de métal noir Atelier : coins coupés 45° (plaque plate).
		local cut = R(16)
		EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250 * a), cut)
		-- (liseré acier retiré — DA dashboard 08/07)

		-- grimmjow (evo_ui/chars) en TRAME FANTÔME : image ENTIÈRE (contain,
		-- dézoomée — demande user), ancrée en haut, centrée. Alpha 3.
		if EVO_UI.HasMat("evo_ui/chars/grimmjow.png") then
			local m = EVO_UI.Mat("evo_ui/chars/grimmjow.png")
			local iw, ih = m:Width(), m:Height()
			if iw > 0 and ih > 0 then
				local ins = R(28)
				local sc = math.min((w - ins * 2) / iw, (h - ins * 2) / ih)
				local rw, rh = iw * sc, ih * sc
				-- Floutée (4 passes en quinconce, demande user 07/07).
				EVO_UI.GhostBlur(m, (w - rw) / 2, ins, rw, rh, 3 * a)
			end
		end

		-- Kanji 護 gravé (une passe claire ultra-légère, copie du #platekanji).
		draw.SimpleText("護", "EVO_UI_KanjiXL", w - R(8), h - R(2),
			Color(210, 216, 224, 9), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)

		-- 4 vis d'angle alignées (retrait 18px uniforme — DA dashboard 08/07).
		local sr = R(5)
		drawScrew(R(18), R(18), sr)
		drawScrew(w - R(18), R(18), sr)
		drawScrew(w - R(18), h - R(18), sr)
		drawScrew(R(18), h - R(18), sr)

		-- Titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
		-- (Fonte LOCALE EVO_Sup_Title : ce fichier scale ses fontes en linéaire
		-- comme R(), pas avec le sqrt des strings glibs.)
		draw.SimpleText("SUPPORT EVO", "EVO_Sup_Title", R(24), R(33), ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("EVO_Sup_Title")
		local twT, thT = surface.GetTextSize("SUPPORT EVO")
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(22), R(33) + thT * 0.28, twT * 1.15, R(9), ColorAlpha(col.accent, 245 * a)) then
			surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
			surface.DrawRect(R(24), R(33) + thT * 0.34, twT, math.max(2, R(3)))
		end
		drawDashes(R(24), R(62), w - R(48), Color(255, 255, 255, 26 * a))
		surface.SetDrawColor(ColorAlpha(col.divider, 150 * a))
		surface.DrawRect(R(SIDEBAR), R(70), 1, h - R(82))
	end

	CloseBtn(card, CARD_W, function() pSupport:Remove() end)

	-- contenu (enfant de la carte)
	local content = vgui.Create("DPanel", card)
	content:SetPos(R(SIDEBAR + 24), R(74))
	content:SetSize(R(CARD_W - SIDEBAR - 48), R(CARD_H - 90))
	content:SetPaintBackground(false)
	local ctx = { cw = CARD_W - SIDEBAR - 48, ch = CARD_H - 90 }

	-- onglets = base + onglets de rôle (Réponses si helper, Signalements si staff)
	local tabs = {}
	for _, t in ipairs(TABS) do tabs[#tabs + 1] = t end
	if ROLE.helper then tabs[#tabs + 1] = { id = "Réponses", build = BuildQueue } end
	if ROLE.staff  then tabs[#tabs + 1] = { id = "Signalements", build = BuildReports } end

	local current = startTab or "Poser une question"
	local function selectTab(id)
		current = id
		EVO_Sup_CurTab = id
		content:Clear()
		for _, t in ipairs(tabs) do if t.id == id then t.build(content, ctx) break end end
	end

	-- sidebar tabs — cases EXACTEMENT comme les items du menu échap (demande
	-- user 06/07) : puce brush1 acier -> rouge, libellé Bebas qui glisse,
	-- plaque acier à coin coupé + barre accent au survol / sélection,
	-- soubassement denté entre les items. Espacement ADAPTATIF conservé.
	local topY, btnH = 84, 50
	local availH = CARD_H - topY - 16
	local step = (#tabs > 1) and math.min(56, (availH - btnH) / (#tabs - 1)) or 56
	for i, t in ipairs(tabs) do
		local b = vgui.Create("DButton", card) b:SetText("")
		b:SetPos(R(16), R(topY + (i - 1) * step)) b:SetSize(R(SIDEBAR - 24), R(btnH))
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local on = (current == t.id)
			local hf = EVO_UI.HoverFrac(s, 10)
			local vis = on and 1 or hf
			if vis > 0.02 then
				EVO_UI.PaintCut(0, R(2), w, h - R(4), Color(17, 18, 22, 205 * vis), R(10), "br")
				-- Liseré tracé à l'INTÉRIEUR (bord droit à x=w-1) : sinon le bord
				-- droit de la plaque (x=w) était clippé par le panneau (08/07).
				local ol = EVO_UI.CutPoints(0, R(2), w - 1, h - R(4), R(10), "br")
				EVO_UI.OutlineCut(ol, Color(226, 230, 238, 26 * vis))
				surface.SetDrawColor(207, 68, 78, 235 * vis)
				surface.DrawRect(0, R(2), R(2), h - R(4))
			end
			local brushPath = (EVO_UI.HasMat("evo_ui/tex/brush1.png") and "evo_ui/tex/brush1.png")
				or (EVO_UI.HasMat(EVO_UI.TexBrush) and EVO_UI.TexBrush or nil)
			if brushPath then
				local c = (on or hf > 0.5) and ColorAlpha(col.accent, 240) or Color(150, 154, 162, 150)
				EVO_UI.Ink(brushPath, R(10), h / 2 - R(6), R(20), R(12), c)
			end
			draw.SimpleText(t.id, "EVO_Sup_Tab", R(38) + vis * R(6), h / 2,
				(on or hf > 0.01) and col.title or col.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if i < #tabs and vis < 0.98 then
				drawDashes(R(10), h - 1, w - R(20), Color(255, 255, 255, 22 * (1 - vis)))
			end
		end
		b.DoClick = function() surface.PlaySound(EVO_UI.SndClick) selectTab(t.id) end
	end

	selectTab(current)
end

-- Ouvre le support sur "Faire un report" avec une cible déjà sélectionnée
-- (appelé par l'action clic-droit "Signaler le joueur" du property menu).
function EVO_OpenSupportReport(target)
	if IsValid(target) and target:IsPlayer() then
		preselectTarget = {
			steamid = target:SteamID64(),
			name = target:GetEvoNWString("Nickname", "") ~= "" and target:GetEvoNWString("Nickname") or target:Nick(),
		}
	end
	if EVO_OpenSupport then EVO_OpenSupport("Faire un report") end
end

net.Receive("EVO:Support:Dossiers", function()
	local list = net.ReadTable()
	if EVO_Support_OnDossiers then EVO_Support_OnDossiers(list) end
end)

net.Receive("EVO:Support:Sanctions", function()
	local data = net.ReadTable()
	if EVO_Support_OnSanctions then EVO_Support_OnSanctions(data) end
end)

-- Diagnostic + raccourci : taper `evo_support` dans la console ouvre le menu.
concommand.Add("evo_support", function() if EVO_OpenSupport then EVO_OpenSupport() end end)

-- Ouverture demandee par une commande de chat (!ticket, !bug, !report...).
-- Chaine vide = onglet par defaut.
net.Receive("EVO:Support:Open", function()
	local sTab = net.ReadString() or ""
	if not EVO_OpenSupport then return end
	EVO_OpenSupport(sTab ~= "" and sTab or nil)
end)

-- ── NOTATION DU STAFF, à la fermeture d'un signalement ─────────────────────
-- Le joueur donne une note de 1 à 5 sur celui qui a traité son signalement.
-- Fenêtre volontairement minuscule et sans champ libre : on veut une réponse en
-- un clic, pas un formulaire. Une question qui prend du temps n'obtient pas de
-- réponse, et une note sur deux personnes ne vaut rien.
net.Receive("EVO:Support:DemandeNote", function()
	local sID    = net.ReadString() or ""
	local sStaff = net.ReadString() or "le staff"
	if sID == "" then return end

	local c = C()
	local nL, nH = 420, 210

	local f = vgui.Create("DFrame")
	f:SetSize(nL, nH)
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	f.Paint = function(s, w, h)
		if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 4) end
		if EVO_UI and EVO_UI.PaintCard then
			-- Signature = PaintCard(w, h, ...) : PAS de panel en 1er argument. Le passer
			-- envoyait un userdata dans le math.min de CutPoints -> erreur Lua à CHAQUE
			-- frame chez le joueur dont le signalement venait d'être traité (x821 dans le
			-- rapport). La fenêtre de notation était donc cassée depuis sa création.
			EVO_UI.PaintCard(w, h)
		else
			draw.RoundedBox(0, 0, 0, w, h, c.bg)
			surface.SetDrawColor(c.border); surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		draw.SimpleText("Ton signalement a été traité", "DermaLarge", w / 2, 30, c.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Par " .. sStaff .. " · comment s'est passé l'échange ?", "DermaDefault", w / 2, 58, c.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Les cinq notes, en boutons carrés comme le reste de la DA.
	local nTaille, nEcart = 52, 10
	local nDepart = (nL - (nTaille * 5 + nEcart * 4)) / 2
	local bEnvoye = false
	for i = 1, 5 do
		local b = vgui.Create("DButton", f)
		b:SetSize(nTaille, nTaille)
		b:SetPos(nDepart + (i - 1) * (nTaille + nEcart), 88)
		b:SetText("")
		b.Paint = function(s, w, h)
			local bSurvol = s:IsHovered()
			draw.RoundedBox(0, 0, 0, w, h, bSurvol and c.accent or Color(255, 255, 255, 12))
			surface.SetDrawColor(bSurvol and c.accent or c.border)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
			draw.SimpleText(i, "DermaLarge", w / 2, h / 2, bSurvol and color_white or c.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			if bEnvoye then return end
			bEnvoye = true
			net.Start("EVO:Support:Note")
				net.WriteString(sID)
				net.WriteUInt(i, 3)
			net.SendToServer()
			f:Close()
		end
	end

	-- Repère de lecture : sans lui, « 1 » et « 5 » sont ambigus.
	local lbl = vgui.Create("DLabel", f)
	lbl:SetPos(0, 150); lbl:SetSize(nL, 16)
	lbl:SetContentAlignment(5)
	lbl:SetFont("DermaDefault")
	lbl:SetTextColor(c.dim)
	lbl:SetText("1 = très mauvais          5 = parfait")

	-- Passer est TOUJOURS possible : une note arrachée de force ne dit rien de
	-- la qualité du staff, elle dit juste que le joueur voulait fermer la fenêtre.
	local skip = vgui.Create("DButton", f)
	skip:SetSize(120, 26)
	skip:SetPos((nL - 120) / 2, nH - 40)
	skip:SetText("")
	skip.Paint = function(s, w, h)
		draw.SimpleText("Passer", "DermaDefault", w / 2, h / 2,
			s:IsHovered() and c.title or c.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	skip.DoClick = function() f:Close() end
end)
