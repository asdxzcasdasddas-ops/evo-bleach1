-- "addons\\evo_business\\lua\\evo_business\\cl_drink.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — overlay d'ivresse progressif (EVO_BeerLevel 1..4).
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}
local CFG = EVO_BUSINESS.CFG

local nUntil = 0
local nLevel = 0
local _mergedNext, _mergedCache, _mergedSrc = 0, nil, nil

net.Receive("evo_biz:drink", function()
	nUntil = CurTime() + (net.ReadFloat() or 60)
	nLevel = math.Clamp(net.ReadUInt(3) or 1, 1, 4)
	net.ReadUInt(5) -- count
	_mergedNext = 0 -- rebuild pilule HUD immédiat
	if EVO_SCIENCE then EVO_SCIENCE._fxNext = 0 end
end)

local function clearLocal()
	nUntil = 0
	nLevel = 0
	_mergedNext = 0
	_mergedCache = nil
end

local function activeLevel()
	local lp = LocalPlayer()
	if not IsValid(lp) then return 0 end
	-- Source de vérité = NW serveur (mort / respawn le remettent à 0).
	local t = lp:GetEvoNWFloat("EVO_BeerUntil", 0)
	if t <= CurTime() then
		clearLocal()
		return 0
	end
	local lvl = math.max(nLevel, lp:GetEvoNWInt("EVO_BeerLevel", 0))
	if lvl < 1 then return 0 end
	return math.Clamp(lvl, 1, 4)
end

hook.Add("PlayerDeath", "EVO_Business::BeerClearLocal", function(ply)
	if ply == LocalPlayer() then clearLocal() end
end)

hook.Add("PlayerSpawn", "EVO_Business::BeerClearLocal", function(ply)
	if ply == LocalPlayer() then clearLocal() end
end)

hook.Add("RenderScreenspaceEffects", "EVO_Business::BeerBlur", function()
	local lvl = activeLevel()
	if lvl < 1 then return end
	local st = CFG.Drink and CFG.Drink.stages and CFG.Drink.stages[lvl]
	if not st then return end
	DrawMotionBlur(st.blurAdd or 0.12, st.blurDraw or 0.45, 0.01)
	DrawColorModify({
		["$pp_colour_addr"] = 0.02 * lvl,
		["$pp_colour_addg"] = 0.01 * lvl,
		["$pp_colour_addb"] = 0,
		["$pp_colour_brightness"] = st.bright or -0.02,
		["$pp_colour_contrast"] = 1.02 + 0.03 * lvl,
		["$pp_colour_colour"] = st.colour or 1.15,
		["$pp_colour_mulr"] = 0,
		["$pp_colour_mulg"] = 0,
		["$pp_colour_mulb"] = 0,
	})
	if lvl >= 3 then
		DrawToyTown(math.min(3, lvl - 1), ScrH() * (0.3 + 0.08 * lvl))
	end
end)

-- Effets visuels locaux des recettes spéciales, adoucis pendant les 3 dernières secondes.
hook.Add("RenderScreenspaceEffects", "EVO_Business::SpecialBeerVision", function()
	local id, _, untilT = EVO_BUSINESS.ActiveBeerEffect(LocalPlayer())
	if not id then return end
	local fade = math.Clamp((untilT - CurTime()) / 3, 0, 1)
	if id == "hallucination" then
		local wave = math.sin(CurTime() * 1.2)
		DrawMotionBlur(0.08, 0.65 * fade, 0.02)
		DrawColorModify({
			["$pp_colour_addr"] = (0.06 + wave * 0.04) * fade,
			["$pp_colour_addg"] = 0.02 * fade,
			["$pp_colour_addb"] = (0.06 - wave * 0.04) * fade,
			["$pp_colour_brightness"] = 0,
			["$pp_colour_contrast"] = 1 + 0.2 * fade,
			["$pp_colour_colour"] = 1 + (1 + wave * 0.3) * fade,
			["$pp_colour_mulr"] = 0, ["$pp_colour_mulg"] = 0, ["$pp_colour_mulb"] = 0,
		})
	elseif id == "blur" then
		DrawMotionBlur(0.05, 0.85 * fade, 0.02)
		DrawToyTown(3 * fade, ScrH() * 0.65)
	end
end)

-- Pas de CalcView : un return non-nil court-circuite MUGEN thirdperson → 1re personne.
-- ViewPunch s'ajoute à la cam sans remplacer l'orbite / 3e personne.
local nNextPunch = 0
hook.Add("Think", "EVO_Business::BeerSway", function()
	local lvl = activeLevel()
	local special, def = EVO_BUSINESS.ActiveBeerEffect(LocalPlayer())
	if lvl < 1 and special ~= "balance" then return end
	if CurTime() < nNextPunch then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local st = CFG.Drink and CFG.Drink.stages and CFG.Drink.stages[lvl]
	local sway = (st and st.sway) or 0
	if special == "balance" then sway = math.max(sway, def.sway) end
	if sway <= 0 then return end
	nNextPunch = CurTime() + math.Rand(0.12, 0.28)
	lp:ViewPunch(Angle(
		math.Rand(-1, 1) * sway * 0.9,
		math.Rand(-1, 1) * sway * 0.7,
		math.Rand(-1, 1) * sway * 0.4
	))
end)

-- ── Pilule HUD (même rangée que potions / maladies via GetActiveEffects) ─────
local FX_COL_DRUNK = Color(226, 150, 60)
local STAGE_LABEL = {
	"IVRESSE LÉGÈRE",
	"VISION TROUBLE",
	"IVRESSE",
	"IVRESSE LOURDE",
}

local function fmtLeftShort(nSec)
	if nSec >= 60 then return math.ceil(nSec / 60) .. " min" end
	return math.max(1, math.floor(nSec)) .. " s"
end

local function beerHudFx(now)
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local untilT = lp:GetEvoNWFloat("EVO_BeerUntil", 0)
	if untilT <= now then return nil end
	local lvl = math.Clamp(math.max(nLevel, lp:GetEvoNWInt("EVO_BeerLevel", 1)), 1, 4)
	local sTxt = STAGE_LABEL[lvl] or "IVRESSE"
	local sSub = fmtLeftShort(untilT - now)
	return {
		txt = sTxt,
		sub = sSub,
		col = FX_COL_DRUNK,
		line = sTxt .. "  " .. sSub,
	}
end

-- Cache fusionné : même rythme 0.5 s que evo_science, sans muter FX_CACHE.
local function installHudFx()
	if not (EVO_SCIENCE and EVO_SCIENCE.GetActiveEffects) then return false end
	if EVO_BUSINESS._hudFxWrapped then return true end
	EVO_BUSINESS._hudFxWrapped = true
	local old = EVO_SCIENCE.GetActiveEffects
	function EVO_SCIENCE.GetActiveEffects()
		local src = old()
		local now = CurTime()
		if now < _mergedNext and _mergedSrc == src and _mergedCache then
			return _mergedCache
		end
		_mergedNext = now + 0.5
		_mergedSrc = src
		local fx = beerHudFx(now)
		local special, def, untilT = EVO_BUSINESS.ActiveBeerEffect(LocalPlayer())
		if not fx and not special then
			_mergedCache = src
			return src
		end
		local out = {}
		if istable(src) then
			for i = 1, #src do out[i] = src[i] end
		end
		if fx then out[#out + 1] = fx end
		if special then
			local label = string.upper(def.label)
			local remaining = fmtLeftShort(untilT - now)
			out[#out + 1] = { txt = label, sub = remaining, col = FX_COL_DRUNK, line = label .. "  " .. remaining }
		end
		_mergedCache = out
		return out
	end
	return true
end

hook.Add("InitPostEntity", "EVO_Business::HudDrunk", function()
	timer.Simple(1, installHudFx)
end)
timer.Create("EVO_Business::HudDrunkInstall", 2, 15, function()
	if installHudFx() then timer.Remove("EVO_Business::HudDrunkInstall") end
end)
