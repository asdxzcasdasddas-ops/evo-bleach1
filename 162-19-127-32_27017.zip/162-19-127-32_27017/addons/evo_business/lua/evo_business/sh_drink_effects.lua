-- "addons\\evo_business\\lua\\evo_business\\sh_drink_effects.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Effets des bières : un effet spécial actif, délai serveur, mouvement prédit.
local B = EVO_BUSINESS

function B.ActiveBeerEffect(ply)
	if not (IsValid(ply) and ply:IsPlayer() and ply:Alive()) then return end
	if ply:GetEvoNWBool("EVO_IsKO", false) then return end
	local untilT = ply:GetEvoNWFloat("EVO_BeerEffectUntil", 0)
	if untilT <= CurTime() then return end
	local id = ply:GetEvoNWString("EVO_BeerEffect", "")
	local def = B.CFG.BeerEffects[id]
	if def then return id, def, untilT end
end

hook.Add("SetupMove", "EVO_Business::SpecialBeerMovement", function(ply, mv)
	local id, def = B.ActiveBeerEffect(ply)
	if not id then return end
	if ply:InVehicle() or ply:GetMoveType() ~= MOVETYPE_WALK then return end
	local forward, side = mv:GetForwardSpeed(), mv:GetSideSpeed()
	if id == "inverse" then
		mv:SetForwardSpeed(-forward)
		mv:SetSideSpeed(-side)
		local buttons = mv:GetButtons()
		local swapped = bit.band(buttons, bit.bnot(bit.bor(IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT)))
		if bit.band(buttons, IN_FORWARD) ~= 0 then swapped = bit.bor(swapped, IN_BACK) end
		if bit.band(buttons, IN_BACK) ~= 0 then swapped = bit.bor(swapped, IN_FORWARD) end
		if bit.band(buttons, IN_MOVELEFT) ~= 0 then swapped = bit.bor(swapped, IN_MOVERIGHT) end
		if bit.band(buttons, IN_MOVERIGHT) ~= 0 then swapped = bit.bor(swapped, IN_MOVELEFT) end
		mv:SetButtons(swapped)
	elseif id == "balance" then
		-- Dévie légèrement la marche sans déplacer un joueur immobile.
		local angle = math.rad(math.sin(CurTime() * 2.5) * def.angle)
		local c, s = math.cos(angle), math.sin(angle)
		mv:SetForwardSpeed(forward * c - side * s)
		mv:SetSideSpeed(forward * s + side * c)
	end
end)

hook.Add("Move", "EVO_Business::SpecialBeerSlow", function(ply, mv)
	local id, def = B.ActiveBeerEffect(ply)
	if id ~= "slow" then return end
	if ply:InVehicle() or ply:GetMoveType() ~= MOVETYPE_WALK then return end
	mv:SetMaxSpeed(mv:GetMaxSpeed() * def.speed)
	mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * def.speed)
end)
