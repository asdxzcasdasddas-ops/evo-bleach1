-- "addons\\evo_business\\lua\\evo_business\\cl_station_games.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — mini-jeux des étapes distillerie (moulin / cuve / fermenteur).
-- Raté ou fermeture : rien n'est dépensé. Succès → callback (le net start).
-- Sons atelier, jamais de sons GMod de base.
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}

local COL_DIMBG    = Color(4, 4, 8, 220)
local COL_SUB      = Color(20, 20, 24, 255)
local COL_SUB_HI   = Color(27, 27, 33, 255)
local COL_ACCENT   = Color(207, 68, 78)
local COL_ACC_WASH = Color(207, 68, 78, 26)
local COL_TITLE    = Color(237, 238, 242)
local COL_MUTED    = Color(150, 154, 162)
local COL_DIMTXT   = Color(110, 113, 120)
local COL_RING_BG  = Color(255, 255, 255, 13)
local COL_CURSOR   = Color(255, 255, 255, 245)
local COL_GOOD     = Color(120, 230, 140)
local COL_MID      = Color(235, 200, 90)
local COL_BAD      = Color(235, 90, 80)
local COL_ZONE     = Color(207, 68, 78, 185)
local COL_ZONE_GLOW = Color(207, 68, 78, 46)

local SND_STRIKE = "tbfpvq7ot1yh/enchantement_sound.mp3"
local SND_RING   = "tbfpvq7ot1yh/forge_sound.mp3"
local SND_MISS   = "tbfpvq7ot1yh/fail.mp3"
local SND_DONE   = "a4xy732ex6yeop2/tv6cllaafv0qtz08d.wav"

local OVERLAY

local function SX(n)
	return gRespX and gRespX(n) or n
end
local function SY(n)
	return gRespY and gRespY(n) or n
end

local function fill(r, x, y, w, h, col)
	if RNDX and RNDX.Draw then
		RNDX.Draw(r, x, y, w, h, col)
	else
		surface.SetDrawColor(col)
		surface.DrawRect(x, y, w, h)
	end
end

local function ring(cx, cy, rad, col, thick)
	if RNDX and RNDX.DrawCircleOutlined then
		RNDX.DrawCircleOutlined(cx, cy, rad, col, thick)
	end
end

local function clNotify(msg, typ)
	if MUGEN and MUGEN.Notify then
		MUGEN.Notify(msg, typ or NOTIFY_ERROR, 3)
	else
		notification.AddLegacy(msg, typ or NOTIFY_ERROR, 3)
	end
end

local function makeCloseCross(parent, x, y, fClick)
	if EVO_CRAFT and EVO_CRAFT.MakeCloseCross then
		local b = EVO_CRAFT.MakeCloseCross(parent, x, y, fClick)
		b:SetZPos(32000)
		if b.SetCursor then b:SetCursor("hand") end
		return b
	end
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(SX(52), SY(52))
	b:SetPos(x, y)
	b:SetZPos(32000)
	b:SetCursor("hand")
	b.Paint = function(s, w, h)
		if s:IsHovered() then fill(SY(10), 0, 0, w, h, COL_SUB_HI) end
		draw.SimpleText("×", "Bebas Neue:44", w / 2, h / 2 - SY(2),
			s:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClick
	return b
end

local function destroyOverlay()
	if not IsValid(OVERLAY) then
		OVERLAY = nil
		return
	end
	local ov = OVERLAY
	OVERLAY = nil
	ov:Remove()
end

local function setStationInput(bOn)
	if EVO_BUSINESS.SetStationUIInput then
		EVO_BUSINESS.SetStationUIInput(bOn)
	end
end

local function closeOverlay()
	destroyOverlay()
	setStationInput(true)
end

local function openOverlay(sTitle, sHint)
	destroyOverlay()
	local ov = vgui.Create("DPanel")
	OVERLAY = ov
	ov:SetSize(ScrW(), ScrH())
	ov:SetPos(0, 0)
	ov:SetZPos(30000)
	ov:MakePopup()
	ov:MoveToFront()
	ov:SetKeyboardInputEnabled(true)
	ov:SetMouseInputEnabled(true)
	setStationInput(false)
	ov._title = sTitle
	ov._hint = sHint
	ov.PaintHead = function(_, w)
		local cx = w * 0.5
		draw.SimpleText(sTitle, "Bebas Neue:64", cx, SY(92), COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		fill(SY(2), cx - SX(120), SY(126), SX(240), SY(4), COL_ACCENT)
		draw.SimpleText(sHint, "Avenir Next World:20", cx, SY(160), COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return ov
end

-- ── Moulin : geste circulaire (mortier) ─────────────────────────────────────

local function openGrind(fDone)
	local ov = openOverlay("MOUDRE LE MALT", "Relâche le clic, puis maintiens et tourne autour de la meule, d'un geste régulier.")
	local nGoal = 4 * math.pi * 2
	local nProgress, nCasse = 0, 0
	local nLastAng, nLastT, nAngSmooth = nil, RealTime(), 0
	local bSettled, bArmed = false, false

	local function settle(ok)
		if bSettled then return end
		bSettled = true
		surface.PlaySound(ok and SND_DONE or SND_MISS)
		-- Commit réseau AVANT de fermer l'UI.
		if ok then
			if fDone then fDone() end
			closeOverlay()
		else
			closeOverlay()
			clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
		end
	end

	ov.OnRemove = function()
		if OVERLAY == ov then OVERLAY = nil end
		if not bSettled then
			bSettled = true
			setStationInput(true)
			clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
		else
		end
	end
	ov.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE then
			settle(false)
		end
	end

	ov.Think = function(pnl)
		if bSettled then return end
		-- Le clic du bouton LANCER est encore enfoncé à l'ouverture : on attend
		-- le relâchement, sinon le 1er mouvement fait exploser la vitesse → échec.
		if not bArmed then
			if not input.IsMouseDown(MOUSE_LEFT) then
				bArmed = true
				nLastAng, nLastT, nAngSmooth = nil, RealTime(), 0
			end
			return
		end
		local cx, cy = pnl:GetWide() * 0.5, pnl:GetTall() * 0.5
		local mx, my = pnl:CursorPos()
		local nAng = math.atan2(my - cy, mx - cx)
		local now = RealTime()
		-- Plancher dt (~30 FPS) : à haut FPS, dθ/dt explose et casse la meule à tort.
		local dt = math.max(1 / 30, now - nLastT)
		nLastT = now
		local bHeld = input.IsMouseDown(MOUSE_LEFT)
		if nLastAng and bHeld then
			local d = math.abs(math.NormalizeAngle(math.deg(nAng - nLastAng)))
			local nSpeed = math.rad(d) / dt
			nAngSmooth = nAngSmooth + (nSpeed - nAngSmooth) * math.min(1, dt * 8)
			if nAngSmooth >= 2 and nAngSmooth <= 9 then
				nProgress = nProgress + math.rad(d)
			elseif nAngSmooth > 14 then
				nCasse = nCasse + (nAngSmooth - 14) * dt * 0.12
			end
		end
		nLastAng = nAng
		if nCasse >= 1 then
			settle(false)
			return
		end
		if nProgress >= nGoal then
			settle(true)
			return
		end
	end

	ov.Paint = function(pnl, w, h)
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)
		pnl:PaintHead(w)
		local cx, cy = w * 0.5, h * 0.52
		local R = SX(160)
		ring(cx, cy, R, COL_ACC_WASH, SY(18))
		ring(cx, cy, R * 0.38, COL_ACCENT, SY(4))
		local mx, my = pnl:CursorPos()
		local nAng = math.atan2(my - cy, mx - cx)
		if bArmed and input.IsMouseDown(MOUSE_LEFT) then
			ring(cx + math.cos(nAng) * R, cy + math.sin(nAng) * R, SX(18), COL_CURSOR, SY(3))
		end
		local prog = math.Clamp(nProgress / nGoal, 0, 1)
		local barW, barH = SX(420), SY(18)
		local bx, by = cx - barW / 2, cy + R + SY(48)
		fill(SY(4), bx, by, barW, barH, COL_SUB)
		fill(SY(4), bx, by, barW * prog, barH, COL_GOOD)
		if not bArmed then
			draw.SimpleText("Relâche le clic pour commencer…", "Avenir Next World:20", cx, by + barH + SY(28),
				COL_MID, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif nCasse > 0 then
			fill(SY(4), bx, by + barH + SY(10), barW * math.Clamp(nCasse, 0, 1), SY(8), COL_BAD)
			draw.SimpleText("Trop vite — la meule casse", "Avenir Next World:18", cx, by + barH + SY(28),
				COL_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	makeCloseCross(ov, ov:GetWide() - SX(104), SY(40), function() settle(false) end)
end

-- ── Cuve : jauge SPACE (enchantement) ───────────────────────────────────────

local function openTiming(fDone)
	local ov = openOverlay("TENIR LE FEU", "BARRE ESPACE quand le curseur traverse la zone colorée")
	local nMax, nNeed = 3, 2
	local scores, strikeCols = {}, {}
	local speed, t0 = 0.7, RealTime()
	local zoneC, zoneW = 0.3 + math.random() * 0.4, 0.18
	local lastHit, sFeedback, feedbackUntil = 0, nil, 0
	local bSettled, sEnd = false, nil

	local function cursorPos()
		return math.abs(((RealTime() - t0) * speed) % 2 - 1)
	end
	local function setSpeed(nNew)
		local phase = (RealTime() - t0) * speed
		t0 = RealTime() - phase / nNew
		speed = nNew
	end

	local function settle(ok)
		if bSettled then return end
		bSettled = true
		sEnd = ok and "ok" or "fail"
		surface.PlaySound(ok and SND_DONE or SND_MISS)
		timer.Simple(1.2, function()
			if ok then
				if fDone then fDone() end
				closeOverlay()
			else
				closeOverlay()
				clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
			end
		end)
	end

	ov.OnRemove = function()
		if OVERLAY == ov then OVERLAY = nil end
		if not bSettled then
			bSettled = true
			setStationInput(true)
			clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
		end
	end
	ov.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE and not sEnd then settle(false) end
	end

	local function Strike()
		if sEnd then return end
		if RealTime() - lastHit < 0.25 then return end
		lastHit = RealTime()
		local prec = math.max(0, 1 - math.abs(cursorPos() - zoneC) / zoneW)
		scores[#scores + 1] = prec
		strikeCols[#scores] = prec >= 0.75 and COL_GOOD or (prec >= 0.35 and COL_MID or COL_BAD)
		surface.PlaySound(prec > 0 and SND_STRIKE or SND_MISS)
		sFeedback = prec >= 0.85 and "PARFAIT !" or (prec >= 0.5 and "BIEN" or (prec > 0 and "JUSTE" or "RATÉ"))
		feedbackUntil = RealTime() + 0.7
		if #scores >= nMax then
			local nIn = 0
			for _, v in ipairs(scores) do
				if v > 0 then nIn = nIn + 1 end
			end
			settle(nIn >= nNeed)
		else
			setSpeed(speed + 0.25)
			zoneW = zoneW * 0.85
			zoneC = 0.2 + math.random() * 0.6
		end
	end

	local bSpaceWas = true
	ov.Think = function()
		if sEnd then return end
		local down = input.IsKeyDown(KEY_SPACE)
		if down and not bSpaceWas then Strike() end
		bSpaceWas = down
	end

	ov.Paint = function(pnl, w, h)
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)
		pnl:PaintHead(w)
		if sEnd == "ok" then
			draw.SimpleText("FEU TENU", "Bebas Neue:40", w / 2, SY(766), COL_GOOD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		elseif sEnd == "fail" then
			draw.SimpleText("FEU RATÉ", "Bebas Neue:40", w / 2, SY(766), COL_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Rien n'a été dépensé.", "Avenir Next World:20", w / 2, SY(812), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		local gaugeW, gaugeH = SX(760), SY(34)
		local gx, gy = (w - gaugeW) / 2, SY(520)
		fill(gaugeH / 2, gx, gy, gaugeW, gaugeH, COL_SUB)
		local zx = gx + (zoneC - zoneW) * gaugeW
		local zw = zoneW * 2 * gaugeW
		fill(gaugeH / 2, zx - SX(6), gy - SY(4), zw + SX(12), gaugeH + SY(8), COL_ZONE_GLOW)
		fill(gaugeH / 2, zx, gy, zw, gaugeH, COL_ZONE)
		local cxu = gx + cursorPos() * gaugeW
		fill(SX(2), cxu - SX(2), gy - SY(8), SX(4), gaugeH + SY(16), COL_CURSOR)
		for i = 1, nMax do
			fill(SY(4), gx + (i - 1) * SX(34), gy + gaugeH + SY(16), SX(24), SY(8), strikeCols[i] or COL_RING_BG)
		end
		if sFeedback and feedbackUntil > RealTime() then
			draw.SimpleText(sFeedback, "Black Han Sans:34", w / 2, SY(640),
				strikeCols[#strikeCols] or COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("FRAPPE " .. math.min(#scores + 1, nMax) .. " / " .. nMax,
			"Bebas Neue:28", w / 2, SY(700), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	makeCloseCross(ov, ov:GetWide() - SX(104), SY(40), function()
		if sEnd then return end
		settle(false)
	end)
end

-- ── Fermenteur : anneau qui se resserre (assassin) ──────────────────────────

local function openRing(fDone)
	local ov = openOverlay("SURVEILLER LA FERMENTATION", "Clique quand l'anneau touche le cercle rouge")
	local nTotal, nNeed = 3, 2
	local nRound, nHits = 1, 0
	local tMarks = {}
	local sFeedback, colFeedback, feedbackUntil = nil, COL_TITLE, 0
	local lastClick, sEnd, bSettled = 0, nil, false
	local hw = SX(460)
	local hx, hy = (ov:GetWide() - hw) / 2, SY(196)
	local R0 = hw * 0.62
	local RT = hw * 0.20
	local TOL = hw * 0.075
	local ringBorn = RealTime() + 0.6
	local ringLife = 1.7

	local function ringRadius()
		local f = (RealTime() - ringBorn) / ringLife
		if f < 0 then return nil end
		return Lerp(math.Clamp(f, 0, 1), R0, 0)
	end

	local function settle(ok)
		if bSettled then return end
		bSettled = true
		sEnd = ok and "ok" or "fail"
		surface.PlaySound(ok and SND_DONE or SND_MISS)
		timer.Simple(1.2, function()
			if ok then
				if fDone then fDone() end
				closeOverlay()
			else
				closeOverlay()
				clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
			end
		end)
	end

	local function finish()
		settle(nHits >= nNeed)
	end

	local function nextRound(bHit, nPrec)
		if sEnd then return end
		tMarks[nRound] = bHit and (nPrec >= 0.7 and COL_GOOD or COL_MID) or COL_BAD
		sFeedback = bHit and (nPrec >= 0.7 and "PARFAIT !" or "BIEN") or "RATÉ"
		colFeedback = tMarks[nRound]
		feedbackUntil = RealTime() + 0.6
		if bHit then
			nHits = nHits + 1
			surface.PlaySound(SND_RING)
		else
			surface.PlaySound(SND_MISS)
		end
		nRound = nRound + 1
		if nRound > nTotal then finish() return end
		ringLife = math.max(0.9, ringLife - 0.25)
		ringBorn = RealTime() + 0.45
	end

	ov.OnRemove = function()
		if OVERLAY == ov then OVERLAY = nil end
		if not bSettled then
			bSettled = true
			setStationInput(true)
			clNotify("Lot annulé — rien n'a été dépensé.", NOTIFY_ERROR)
		end
	end
	ov.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE and not sEnd then settle(false) end
	end
	ov.Think = function()
		if sEnd then return end
		local r = ringRadius()
		if r and r < RT - TOL then nextRound(false, 0) end
	end
	ov.Paint = function(pnl, w, h)
		surface.SetDrawColor(COL_DIMBG)
		surface.DrawRect(0, 0, w, h)
		pnl:PaintHead(w)
		if sEnd == "ok" then
			draw.SimpleText("FERMENTATION LANCÉE", "Bebas Neue:40", w / 2, SY(766), COL_GOOD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		elseif sEnd == "fail" then
			draw.SimpleText("FERMENTATION RATÉE", "Bebas Neue:40", w / 2, SY(766), COL_BAD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Rien n'a été dépensé.", "Avenir Next World:20", w / 2, SY(812), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		local mx0 = w / 2 - SX((nTotal * 34 - 10) / 2)
		for i = 1, nTotal do
			fill(SY(4), mx0 + (i - 1) * SX(34), SY(716), SX(24), SY(8), tMarks[i] or COL_RING_BG)
		end
		if sFeedback and feedbackUntil > RealTime() then
			draw.SimpleText(sFeedback, "Black Han Sans:34", w / 2, SY(766), colFeedback, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		draw.SimpleText("COUP " .. math.min(nRound, nTotal) .. " / " .. nTotal,
			"Bebas Neue:28", w / 2, SY(842), COL_DIMTXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local catch = vgui.Create("DButton", ov)
	catch:SetSize(hw + SX(160), hw + SY(160))
	catch:SetPos(hx - SX(80), hy - SY(80))
	catch:SetText("")
	catch:SetZPos(31000)
	local ccx, ccy = hw / 2 + SX(80), hw / 2 + SY(80)
	catch.Paint = function()
		if sEnd then return end
		ring(ccx, ccy, RT + TOL, COL_ACC_WASH, TOL * 2)
		ring(ccx, ccy, RT, COL_ACCENT, SY(3))
		local r = ringRadius()
		if r and r > 2 then ring(ccx, ccy, r, COL_CURSOR, SY(4)) end
	end
	catch.DoClick = function()
		if sEnd then return end
		if RealTime() - lastClick < 0.15 then return end
		lastClick = RealTime()
		local r = ringRadius()
		if not r then return end
		local nDist = math.abs(r - RT)
		if nDist <= TOL then
			nextRound(true, 1 - nDist / TOL)
		else
			nextRound(false, 0)
		end
	end

	makeCloseCross(ov, ov:GetWide() - SX(104), SY(40), function()
		if sEnd then return end
		settle(false)
	end)
end

function EVO_BUSINESS.OpenStationGame(sType, fDone)
	if IsValid(OVERLAY) then
		return
	end
	sType = tostring(sType or "")
	if sType == "moulin" then
		openGrind(fDone)
	elseif sType == "cuve" then
		openTiming(fDone)
	elseif sType == "fermenteur" then
		openRing(fDone)
	else
		if fDone then fDone() end
	end
end
