-- "addons\\evo_business\\lua\\evo_business\\cl_sale.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local CARD = Color(13, 14, 17, 250)
local ACCENT = Color(207, 68, 78)
local TEXT = Color(235, 235, 240)
local DIM = Color(150, 150, 160)
local priceFrame, offerFrame

local function frame(title, height)
	local panel = vgui.Create("DFrame")
	panel:SetSize(math.min(560, ScrW() - 32), height)
	panel:Center()
	panel:SetTitle("")
	panel:SetDraggable(false)
	panel:MakePopup()
	panel.Paint = function(_, w, h)
		draw.RoundedBox(8, 0, 0, w, h, CARD)
		surface.SetDrawColor(ACCENT) surface.DrawRect(0, 0, w, 4)
		draw.SimpleText(title, "DermaLarge", 20, 22, TEXT)
	end
	if EVO_MakeEscClosable then EVO_MakeEscClosable(panel) end
	return panel
end
local function label(parent, text, y, height)
	local l = vgui.Create("DLabel", parent)
	l:SetPos(20, y) l:SetSize(parent:GetWide() - 40, height or 40)
	l:SetText(text) l:SetTextColor(DIM) l:SetWrap(true)
	return l
end
local function button(parent, text, x, fn)
	local b = vgui.Create("DButton", parent)
	b:SetPos(x, parent:GetTall() - 54) b:SetSize((parent:GetWide() - 52) / 2, 34)
	b:SetText(text) b:SetTextColor(TEXT)
	b.Paint = function(s, w, h) draw.RoundedBox(5, 0, 0, w, h, s:IsHovered() and ACCENT or Color(40, 40, 48)) end
	b.DoClick = fn
	return b
end
local function money(n) return string.Comma(n) .. " ¥" end

net.Receive("evo_biz:sale_prompt", function()
	local target, targetName, biz = net.ReadEntity(), net.ReadString(), net.ReadString()
	if not IsValid(target) then return end
	if IsValid(priceFrame) then priceFrame:Remove() end
	local p = frame("Vendre l'entreprise", 290)
	priceFrame = p
	label(p, "Proposer la vente à " .. targetName .. ". Après la vente, tu quitteras le commerce.", 64, 44)
	label(p, "Prix de vente (¥)", 118, 24)
	local entry = vgui.Create("DTextEntry", p)
	entry:SetPos(20, 146) entry:SetSize(p:GetWide() - 40, 32)
	entry:SetNumeric(true) entry:SetPlaceholderText("Saisir un prix entier") entry:RequestFocus()
	local errorLabel = label(p, "", 184, 40)
	local sellerUID = LocalPlayer():GetEvoNWString("Character::Unique::ID", "none")
	local function submit()
		local value = tonumber(entry:GetValue())
		if not value or value ~= math.floor(value) or value < 1 or value > (EVO_BUSINESS.CFG.SaleMaxPrice or 2000000000) then
			errorLabel:SetText("Saisis un prix entier entre 1 et " .. money(EVO_BUSINESS.CFG.SaleMaxPrice or 2000000000) .. ".")
			return
		end
		if not IsValid(target) then p:Remove() return end
		net.Start("evo_biz:sale_offer") net.WriteEntity(target) net.WriteUInt(value, 32) net.SendToServer()
		p:Remove()
	end
	entry.OnEnter = submit
	button(p, "PROPOSER", 20, submit)
	button(p, "ANNULER", p:GetWide() / 2 + 6, function() p:Remove() end)
	local expires = CurTime() + (EVO_BUSINESS.CFG.SaleTimeout or 60)
	p.Think = function()
		local me = LocalPlayer()
		if CurTime() >= expires or not IsValid(target) or me:GetEvoNWString("Character::Unique::ID", "none") ~= sellerUID
			or me:GetEvoNWString("EVO_BusinessId", "") ~= biz or not me:GetEvoNWBool("EVO_BusinessLeader", false) then p:Remove() end
	end
end)

net.Receive("evo_biz:sale_received", function()
	local id, biz, seller, price, timeout = net.ReadUInt(32), net.ReadString(), net.ReadString(), net.ReadUInt(32), net.ReadFloat()
	if IsValid(offerFrame) then offerFrame:Remove() end
	local p = frame("Acheter l'entreprise", 300)
	offerFrame = p
	p.offerId = id
	label(p, seller .. " te propose de devenir le leader de « " .. biz .. " » pour " .. money(price) .. ".", 64, 64)
	label(p, "En acceptant, le prix sera débité de ton argent et versé au vendeur.", 136, 44)
	local countdown = label(p, "", 190, 28)
	local expires = CurTime() + timeout
	local answered = false
	local function answer(accept)
		if answered then return end
		answered = true
		net.Start("evo_biz:sale_answer") net.WriteUInt(id, 32) net.WriteBool(accept) net.SendToServer()
		p:Remove()
	end
	p.OnRemove = function() if not answered then answer(false) end end
	p.Think = function()
		local remaining = math.max(0, math.ceil(expires - CurTime()))
		countdown:SetText("Proposition valable encore " .. remaining .. " s.")
		if remaining == 0 then answered = true p:Remove() end
	end
	p.CancelFromServer = function() answered = true p:Remove() end
	button(p, "ACCEPTER — " .. money(price), 20, function() answer(true) end)
	button(p, "REFUSER", p:GetWide() / 2 + 6, function() answer(false) end)
end)

net.Receive("evo_biz:sale_close", function()
	local id = net.ReadUInt(32)
	if IsValid(offerFrame) and offerFrame.offerId == id then offerFrame.CancelFromServer() end
end)
