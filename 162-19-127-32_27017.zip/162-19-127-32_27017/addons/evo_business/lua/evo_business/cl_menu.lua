-- "addons\\evo_business\\lua\\evo_business\\cl_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — menu de gestion (roster, kick, grades) + popup d'invitation.
-- DA EVO (carte #0E0E11, accent #cf444e). Bind "business", !bar / !entreprise.
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}

local COL_FOND   = Color(5, 5, 7, 216)
local COL_CARD   = Color(13, 14, 17, 250)
local COL_ROW    = Color(26, 26, 32, 255)
local COL_ACCENT = Color(207, 68, 78, 255)
local COL_TXT    = Color(235, 235, 240, 255)
local COL_DIM    = Color(150, 150, 160, 255)
local COL_GREEN  = Color(78, 196, 128, 255)
local COL_FIELD  = Color(20, 20, 26, 255)

local STATE = {}
local pMenu, pInvite
local rankDraftName = ""
local rankDraftPerms = 0

local function sendAction(s, extra)
	net.Start("evo_biz:action")
	net.WriteString(s)
	if extra then extra() end
	net.SendToServer()
end

local function requestState()
	net.Start("evo_biz:get")
	net.SendToServer()
end

local function hasPerm(nBits, nPerm)
	return EVO_BUSINESS.HasPermBits and EVO_BUSINESS.HasPermBits(nBits, nPerm)
		or (bit.band(tonumber(nBits) or 0, tonumber(nPerm) or 0) ~= 0)
end

local function permSummary(nPerms)
	local t = {}
	for _, p in ipairs(STATE.permList or EVO_BUSINESS.PermList or {}) do
		if bit.band(nPerms or 0, p.bit or 0) ~= 0 then t[#t + 1] = p.label end
	end
	return #t > 0 and table.concat(t, " · ") or "aucune"
end

local function mkBtn(parent, x, y, w, h, label, kind, fn)
	local b
	if EVO_UI and EVO_UI.ActionButton then
		b = EVO_UI.ActionButton(parent, x, y, w, h, label, nil, fn)
		if kind == "danger" then b._danger = true end
		b._font = "Bebas Neue:24"
		return b
	end
	b = vgui.Create("DButton", parent)
	b:SetPos(x, y)
	b:SetSize(w, h)
	b:SetText("")
	b.Paint = function(s, bw, bh)
		local c = kind == "danger" and COL_ACCENT or COL_ROW
		if s:IsHovered() then c = Color(c.r + 20, c.g + 20, c.b + 20) end
		if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, bw, bh, c, 8)
		else draw.RoundedBox(6, 0, 0, bw, bh, c) end
		draw.SimpleText(label, "DermaDefaultBold", bw / 2, bh / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fn
	return b
end

local function attachPermChips(parent, getBits, setBits, y)
	y = y or 48
	local x = 16
	for _, p in ipairs(STATE.permList or EVO_BUSINESS.PermList or {}) do
		local nBit = p.bit or 0
		local chip = vgui.Create("DButton", parent)
		chip:SetPos(x, y)
		chip:SetSize(118, 28)
		chip:SetText("")
		chip.Paint = function(s, w, h)
			local bOn = bit.band(getBits() or 0, nBit) ~= 0
			draw.RoundedBox(4, 0, 0, w, h, bOn and COL_ACCENT or COL_FIELD)
			draw.SimpleText(p.label, "Bebas Neue:16", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		chip.DoClick = function()
			setBits(bit.bxor(getBits() or 0, nBit))
		end
		x = x + 126
	end
end

local function OpenUI()
	if IsValid(pMenu) then pMenu:Remove() end
	local W, H = 760, 640
	if gRespX then W, H = gRespX(760), gRespY(640) end
	local frame = vgui.Create("DFrame")
	pMenu = frame
	frame:SetSize(W, H)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.Paint = function(s, w, h)
		if EVO_UI and EVO_UI.DrawBlur then EVO_UI.DrawBlur(s, 5) end
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, 14)
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(0, 0, w - 14, 4)
		else
			draw.RoundedBox(8, 0, 0, w, h, COL_CARD)
		end
		draw.SimpleText(string.upper(STATE.label or "COMMERCE"), "Bebas Neue:40", 24, 28, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local sRole = STATE.isLeader and "LEADER" or "EMPLOYÉ"
		draw.SimpleText(sRole, "Bebas Neue:22", w - 70, 28, STATE.isLeader and COL_GREEN or COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	frame._bindKey = (LocalPlayer().GetBindKey and LocalPlayer():GetBindKey("business")) or 0
	frame._bindWasDown = true
	frame.Think = function(s)
		local k = s._bindKey
		if k and k > 0 then
			local down = input.IsButtonDown(k)
			if down and not s._bindWasDown then s:Remove() return end
			s._bindWasDown = down
		end
	end

	local close = vgui.Create("DButton", frame)
	close:SetText("")
	close:SetSize(34, 34)
	close:SetPos(W - 48, 12)
	close.Paint = function(s, w, h)
		draw.SimpleText("✕", "DermaLarge", w / 2, h / 2, s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Remove() end

	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:SetPos(24, 64)
	scroll:SetSize(W - 48, H - 140)
	frame._scroll = scroll

	local function rebuild()
		if not IsValid(scroll) then return end
		scroll:GetCanvas():Clear()
		local members = STATE.members or {}
		if STATE.bizId == "" or not STATE.bizId then
			if IsValid(frame._leave) then frame._leave:Remove() frame._leave = nil end
			local lbl = scroll:Add("DLabel")
			lbl:Dock(TOP)
			lbl:SetTall(80)
			lbl:SetFont("Bebas Neue:24")
			lbl:SetTextColor(COL_DIM)
			lbl:SetContentAlignment(5)
			lbl:SetText("Tu n'appartiens à aucun commerce.")
			return
		end
		local cap = STATE.cap or 10
		local head = scroll:Add("DLabel")
		head:Dock(TOP)
		head:SetTall(28)
		head:SetFont("Bebas Neue:22")
		head:SetTextColor(COL_DIM)
		head:SetText(#members .. " / " .. cap .. " membres")

		for _, m in ipairs(members) do
			local row = scroll:Add("DPanel")
			row:Dock(TOP)
			row:DockMargin(0, 0, 8, 6)
			row:SetTall(STATE.isLeader and not m.isLeader and 86 or 52)
			local sGrade = m.isLeader and "Leader" or (m.rankName or "Employé")
			row.Paint = function(_, w, h)
				if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, w, h, COL_ROW, 8)
				else draw.RoundedBox(6, 0, 0, w, h, COL_ROW) end
				draw.SimpleText(m.name or "?", "Bebas Neue:26", 16, 18, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local sSub = sGrade .. (m.online and "  ·  en ligne" or "  ·  hors-ligne")
				draw.SimpleText(sSub, "Bebas Neue:18", 16, 38, m.online and COL_GREEN or COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			if STATE.isLeader and not m.isLeader then
				local kick = vgui.Create("DButton", row)
				kick:SetText("")
				kick:SetSize(100, 28)
				kick:SetPos(row:GetWide() > 0 and (row:GetWide() - 110) or 520, 12)
				kick.Think = function(s)
					local pw = row:GetWide()
					if pw > 0 then s:SetPos(pw - 110, 12) end
				end
				kick.Paint = function(s, w, h)
					local c = s:IsHovered() and COL_ACCENT or Color(60, 30, 34)
					draw.RoundedBox(4, 0, 0, w, h, c)
					draw.SimpleText("RENVOYER", "Bebas Neue:16", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				kick.DoClick = function()
					sendAction("kick", function() net.WriteString(m.uid or "") end)
				end

				local combo = vgui.Create("DComboBox", row)
				combo:SetSize(220, 26)
				combo:SetPos(16, 52)
				combo:SetValue(m.rankName or "Sans grade")
				combo:AddChoice("Sans grade", 0)
				for _, rk in ipairs(STATE.ranks or {}) do
					combo:AddChoice(rk.name, rk.id)
				end
				combo.OnSelect = function(_, _, _, data)
					local nId = tonumber(data) or 0
					sendAction("rank_assign", function()
						net.WriteString(m.uid or "")
						net.WriteUInt(nId, 8)
					end)
				end
			end
		end

		-- Grades (leader)
		if STATE.isLeader then
			local sep = scroll:Add("DLabel")
			sep:Dock(TOP)
			sep:DockMargin(0, 16, 0, 4)
			sep:SetTall(28)
			sep:SetFont("Bebas Neue:26")
			sep:SetTextColor(COL_TXT)
			sep:SetText("GRADES")

			local ranks = STATE.ranks or {}
			local nMax = STATE.maxRanks or 8
			local info = scroll:Add("DLabel")
			info:Dock(TOP)
			info:SetTall(22)
			info:SetFont("Bebas Neue:18")
			info:SetTextColor(COL_DIM)
			info:SetText(#ranks .. " / " .. nMax .. " grades")

			for _, rk in ipairs(ranks) do
				local card = scroll:Add("DPanel")
				card:Dock(TOP)
				card:DockMargin(0, 0, 8, 8)
				card:SetTall(120)
				card._perms = rk.perms or 0
				card._name = rk.name or "?"
				card.Paint = function(_, w, h)
					if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, w, h, COL_ROW, 8)
					else draw.RoundedBox(6, 0, 0, w, h, COL_ROW) end
					draw.SimpleText(card._name, "Bebas Neue:24", 16, 16, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText((rk.members or 0) .. " membre(s) · " .. permSummary(card._perms),
						"Bebas Neue:16", 16, 36, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				attachPermChips(card, function() return card._perms end, function(v) card._perms = v end, 48)

				local save = vgui.Create("DButton", card)
				save:SetText("")
				save:SetSize(90, 26)
				save:SetPos(16, 88)
				save.Paint = function(s, w, h)
					draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and COL_GREEN or Color(40, 70, 50))
					draw.SimpleText("SAUVER", "Bebas Neue:16", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				save.DoClick = function()
					sendAction("rank_update", function()
						net.WriteString(tostring(rk.id) .. "\t" .. tostring(card._name))
						net.WriteUInt(bit.band(card._perms or 0, EVO_BUSINESS.PermAll or 7), 16)
					end)
				end
				local del = vgui.Create("DButton", card)
				del:SetText("")
				del:SetSize(90, 26)
				del:SetPos(116, 88)
				del.Paint = function(s, w, h)
					draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and COL_ACCENT or Color(60, 30, 34))
					draw.SimpleText("SUPPR.", "Bebas Neue:16", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				del.DoClick = function()
					sendAction("rank_delete", function() net.WriteUInt(rk.id or 0, 8) end)
				end
			end

			if #ranks < nMax then
				local create = scroll:Add("DPanel")
				create:Dock(TOP)
				create:DockMargin(0, 4, 8, 8)
				create:SetTall(130)
				create.Paint = function(_, w, h)
					if EVO_UI and EVO_UI.PaintCut then EVO_UI.PaintCut(0, 0, w, h, COL_ROW, 8)
					else draw.RoundedBox(6, 0, 0, w, h, COL_ROW) end
					draw.SimpleText("NOUVEAU GRADE", "Bebas Neue:22", 16, 16, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				local entry = vgui.Create("DTextEntry", create)
				entry:SetPos(16, 40)
				entry:SetSize(280, 28)
				entry:SetPlaceholderText("Nom du grade")
				entry:SetValue(rankDraftName)
				entry.OnChange = function(s) rankDraftName = s:GetValue() or "" end
				attachPermChips(create, function() return rankDraftPerms end, function(v) rankDraftPerms = v end, 78)
				local add = vgui.Create("DButton", create)
				add:SetText("")
				add:SetSize(140, 28)
				add:SetPos(310, 40)
				add.Paint = function(s, w, h)
					draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and COL_ACCENT or COL_FIELD)
					draw.SimpleText("CRÉER", "Bebas Neue:18", w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				add.DoClick = function()
					local sName = string.Trim(rankDraftName or "")
					if sName == "" then return end
					sendAction("rank_create", function()
						net.WriteString(sName)
						net.WriteUInt(bit.band(rankDraftPerms or 0, EVO_BUSINESS.PermAll or 7), 16)
					end)
					rankDraftName = ""
					rankDraftPerms = 0
				end
			end
		end

		if IsValid(frame._leave) then frame._leave:Remove() frame._leave = nil end
		if not STATE.isLeader then
			frame._leave = mkBtn(frame, 24, H - 60, 200, 40, "QUITTER", "danger", function()
				sendAction("leave")
				frame:Remove()
			end)
		end
	end
	frame._rebuild = rebuild
	frame._leave = nil

	rebuild()
	requestState()
end
EVO_BUSINESS.OpenUI = OpenUI

net.Receive("evo_biz:state", function()
	STATE = net.ReadTable() or {}
	if IsValid(pMenu) and pMenu._rebuild then pMenu._rebuild() end
end)

net.Receive("evo_biz:openui", function()
	if not IsValid(pMenu) then OpenUI() end
end)

concommand.Add("evo_business_menu", function() OpenUI() end)

hook.Add("PlayerButtonDown", "EVO_Business::OpenBind", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if IsValid(pMenu) then return end
	if not ply.GetBindKey then return end
	local k = ply:GetBindKey("business")
	if k and k > 0 and btn == k then OpenUI() end
end)

net.Receive("evo_biz:invited", function()
	local sLabel = net.ReadString()
	local sFrom = net.ReadString()
	local nTimeout = net.ReadFloat()
	if IsValid(pInvite) then pInvite:Remove() end

	local W, H = 600, 220
	if gRespX then W, H = gRespX(600), gRespY(220) end
	local frame = vgui.Create("DFrame")
	pInvite = frame
	frame:SetSize(W, H)
	frame:SetPos((ScrW() - W) / 2, ScrH() * 0.16)
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(false)
	local nEnd = CurTime() + (nTimeout or 60)
	frame.Paint = function(_, w, h)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, COL_CARD, 14)
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(0, 0, w - 14, 4)
		else
			draw.RoundedBox(8, 0, 0, w, h, COL_CARD)
		end
		draw.SimpleText(string.upper(sLabel), "Bebas Neue:32", w * 0.5, 38, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sFrom .. " t'invite à rejoindre le commerce.", "DermaDefault", w * 0.5, 78, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local nLeft = math.max(0, math.ceil(nEnd - CurTime()))
		draw.SimpleText(nLeft .. " s", "DermaDefault", w - 20, 22, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	frame.Think = function(s)
		if CurTime() >= nEnd then s:Remove() end
	end
	local function answer(b)
		net.Start("evo_biz:answer")
		net.WriteBool(b)
		net.SendToServer()
		if IsValid(frame) then frame:Remove() end
	end
	mkBtn(frame, 36, 132, 245, 60, "ACCEPTER", "primary", function() answer(true) end)
	mkBtn(frame, W - 36 - 245, 132, 245, 60, "REFUSER", "danger", function() answer(false) end)
end)
