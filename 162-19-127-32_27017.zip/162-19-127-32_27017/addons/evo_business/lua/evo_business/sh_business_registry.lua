-- "addons\\evo_business\\lua\\evo_business\\sh_business_registry.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — registre multi-commerces (extras persistés + sync clients).
-- Les builtins (sh_config, ex. « bar ») restent ; les SA en ajoutent via SAM.
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}
local CFG = EVO_BUSINESS.CFG
local DATA_FILE = "evo_businesses.json"

local function sanitizeId(s)
	s = string.lower(string.Trim(tostring(s or "")))
	s = string.gsub(s, "[^%w_]", "")
	if #s < 2 or #s > 32 then return nil end
	if s == "none" then return nil end
	return s
end

local function extrasOnly()
	local out = {}
	for id, def in pairs(CFG.Businesses or {}) do
		if istable(def) and def._extra then
			out[id] = {
				id = def.id or id,
				label = def.label or id,
				kind = def.kind or "bar",
				desc = def.desc or "",
			}
		end
	end
	return out
end

local function saveExtras()
	if not SERVER then return end
	file.Write(DATA_FILE, util.TableToJSON(extrasOnly(), true) or "{}")
end

local function applyDef(id, def, bExtra)
	if not (isstring(id) and istable(def)) then return end
	CFG.Businesses = CFG.Businesses or {}
	CFG.Businesses[id] = {
		id = id,
		label = tostring(def.label or id),
		kind = tostring(def.kind or "bar"),
		desc = tostring(def.desc or ""),
		_extra = bExtra and true or nil,
	}
end

function EVO_BUSINESS.BroadcastBusinessList(ply)
	if not SERVER then return end
	local payload = {}
	for id, def in pairs(CFG.Businesses or {}) do
		if istable(def) then
			payload[id] = {
				id = def.id or id,
				label = def.label or id,
				kind = def.kind or "bar",
				desc = def.desc or "",
				_extra = def._extra and true or nil,
			}
		end
	end
	net.Start("evo_biz:bizlist")
	net.WriteTable(payload)
	if IsValid(ply) then net.Send(ply) else net.Broadcast() end
end

function EVO_BUSINESS.RegisterBusiness(sId, sLabel, sKind, bPersist)
	sId = sanitizeId(sId)
	if not sId then return false, "id_invalide" end
	if CFG.Businesses[sId] and not CFG.Businesses[sId]._extra and bPersist then
		return false, "builtin"
	end
	sLabel = string.Trim(tostring(sLabel or sId))
	if sLabel == "" then sLabel = sId end
	if #sLabel > 48 then sLabel = string.sub(sLabel, 1, 48) end
	sKind = string.lower(string.Trim(tostring(sKind or "bar")))
	if sKind == "" then sKind = "bar" end
	applyDef(sId, { label = sLabel, kind = sKind }, true)
	if bPersist ~= false then saveExtras() end
	if SERVER then EVO_BUSINESS.BroadcastBusinessList() end
	return true, sId
end

function EVO_BUSINESS.UnregisterBusiness(sId)
	sId = sanitizeId(sId)
	if not sId then return false, "id_invalide" end
	local def = CFG.Businesses and CFG.Businesses[sId]
	if not def then return false, "inconnu" end
	if not def._extra then return false, "builtin" end
	CFG.Businesses[sId] = nil
	saveExtras()
	if SERVER then EVO_BUSINESS.BroadcastBusinessList() end
	return true, sId
end

function EVO_BUSINESS.ListBusinessIds()
	local t = {}
	for id in pairs(CFG.Businesses or {}) do
		t[#t + 1] = id
	end
	table.sort(t)
	return t
end

if SERVER then
	local function loadExtras()
		if not file.Exists(DATA_FILE, "DATA") then return end
		local raw = file.Read(DATA_FILE, "DATA")
		local t = raw and util.JSONToTable(raw)
		if not istable(t) then return end
		for id, def in pairs(t) do
			local sid = sanitizeId(id)
			if sid and istable(def) then
				applyDef(sid, def, true)
			end
		end
	end
	loadExtras()

	hook.Add("PlayerInitialSpawn", "EVO_Business::BizList", function(ply)
		timer.Simple(3, function()
			if IsValid(ply) then EVO_BUSINESS.BroadcastBusinessList(ply) end
		end)
	end)
else
	net.Receive("evo_biz:bizlist", function()
		local t = net.ReadTable() or {}
		CFG.Businesses = CFG.Businesses or {}
		-- Retire les anciens extras, garde les builtins du sh_config.
		for id, def in pairs(CFG.Businesses) do
			if istable(def) and def._extra then
				CFG.Businesses[id] = nil
			end
		end
		for id, def in pairs(t) do
			if istable(def) then
				CFG.Businesses[id] = {
					id = def.id or id,
					label = def.label or id,
					kind = def.kind or "bar",
					desc = def.desc or "",
					_extra = def._extra and true or nil,
				}
			end
		end
	end)
end
