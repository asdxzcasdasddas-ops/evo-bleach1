-- "addons\\evo_business\\lua\\evo_business\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — config partagée.
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}
local CFG = {}
EVO_BUSINESS.CFG = CFG

CFG.InviteRadius  = 600
CFG.InviteTimeout = 60
CFG.SaleTimeout   = 60
CFG.SaleMaxPrice  = 2000000000
CFG.MaxMembers    = 10
CFG.ZoneRadius    = 70
CFG.ZoneBandBelow = 40
CFG.ZoneBandAbove = 140
CFG.CoffreInteract = 220
CFG.CoffreEscrow   = "__barchest__"
CFG.CoffreSnapMax  = 400
CFG.CoffreLogMax   = 80
CFG.CoffreModel    = "models/evo/props/items/evo_efttede452hk/evo_efttede452hk.mdl"

CFG.Businesses = {
	bar = {
		id    = "bar",
		label = "Bar",
		kind  = "bar",
		desc  = "Brasserie du quartier : bière et saké.",
	},
}

CFG.StationTypes = {
	distillerie = {
		id    = "distillerie",
		label = "Distillerie",
		sub   = "Bière et saké — préparer, chauffer, fermenter",
		model = "models/evo/props/items/evo_15623hbfre26hbfrefre/evo_15623HBfre26HBFREfre.mdl",
	},
}

-- Fumée au sommet pendant un craft (état busy uniquement).
CFG.Smoke = {
	z         = 100,
	interval  = 0.14,
	dieTime   = 2.4,
	startSize = 8,
	endSize   = 52,
	alpha     = 75,
	speed     = 32,
	spread    = 10,
	material  = "particle/particle_smokegrenade",
	maxDist   = 2200,
}

-- Bouilloire pendant busy : clients ≤ maxDist, EmitSound local (sync fumée).
-- Chemin sans préfixe sound/ — disque : garrysmod/sound/6515xw26amw1br/boiling_sfx.wav
-- (Source : 44100 / 22050 / 11025 Hz uniquement).
CFG.BoilSound = {
	path      = "6515xw26amw1br/boiling_sfx.wav",
	maxDist   = 300,
	volume    = 1,
	duration  = 4, -- repli si SoundDuration échoue ; ajuster à la longueur du clip
}

CFG.Products = {
	{ id = "biere", label = "Bière" },
	{ id = "sake", label = "Saké" },
}

-- Les ids historiques de la bière restent valides pour les lots persistés.
CFG.Steps = {
	{ id = "moulin",     product = "biere", game = "moulin",     label = "Moudre",    sub = "Graine de blé → malt moulu" },
	{ id = "cuve",       product = "biere", game = "cuve",       label = "Chauffer",  sub = "Malt + eau + houblon → moût" },
	{ id = "fermenteur", product = "biere", variant = "classique", game = "fermenteur", label = "Fermenter", sub = "Moût + levure → bière" },
	{ id = "sake_cuire", product = "sake",  game = "cuve",       label = "Cuire",     sub = "Riz + eau → riz cuit" },
	{ id = "sake_fermenter", product = "sake", game = "fermenteur", label = "Fermenter", sub = "Riz cuit + kōji + levure → saké" },
}

-- Recettes par étape. Durées en secondes (horloge murale).
CFG.Recipes = {
	moulin = {
		inputs   = { graine_ble = 3 },
		output   = "bar_malt_moulu",
		qty      = 1,
		duration = 20,
	},
	cuve = {
		inputs   = { bar_malt_moulu = 1, bar_eau = 1, bar_houblon = 1 },
		output   = "bar_mout",
		qty      = 1,
		duration = 60,
		needHeat = true,
	},
	fermenteur = {
		inputs   = { bar_mout = 1, bar_levure = 1 },
		output   = "bar_biere",
		qty      = 1,
		duration = 120, -- 2 min
	},
	sake_cuire = {
		inputs   = { graine_riz = 3, bar_eau = 1 },
		output   = "bar_riz_cuit",
		qty      = 1,
		duration = 60,
		needHeat = true,
	},
	sake_fermenter = {
		inputs   = { bar_riz_cuit = 1, bar_koji = 1, bar_levure = 1 },
		output   = "bar_sake",
		qty      = 1,
		duration = 180,
	},
}

-- Ajouter une variété ici crée sa recette de fermentation et son item.
-- Le malt et le moût restent communs à toutes les bières.
CFG.BeerVariants = {
	{ id = "classique", name = "Bière classique", item = "bar_biere", step = "fermenteur" },
	{ id = "farceuse", name = "Bière Farceuse", item = "bar_biere_farceuse", step = "biere_farceuse",
		ingredients = { amanite_ames = 2 }, effect = "inverse", duration = 20 },
	{ id = "pachyderme", name = "Bière du Pachyderme", item = "bar_biere_pachyderme", step = "biere_pachyderme",
		ingredients = { bolet_hueco = 2 }, effect = "slow", duration = 15 },
	{ id = "mirage", name = "Bière Mirage", item = "bar_biere_mirage", step = "biere_mirage",
		ingredients = { coprin_spectral = 1, feuille_lune = 1 }, effect = "hallucination", duration = 30 },
	{ id = "funambule", name = "Bière du Funambule", item = "bar_biere_funambule", step = "biere_funambule",
		ingredients = { trompette_limbes = 2 }, effect = "balance", duration = 25 },
	{ id = "brume", name = "Bière des Brumes", item = "bar_biere_brume", step = "biere_brume",
		ingredients = { sauge_ames = 2 }, effect = "blur", duration = 30 },
}
CFG.BeerEffects = {
	inverse = { label = "Déplacements inversés" },
	slow = { label = "Lenteur extrême", speed = 0.18 },
	hallucination = { label = "Hallucinations visuelles" },
	balance = { label = "Perte d'équilibre", angle = 18, sway = 1.4 },
	blur = { label = "Vision trouble" },
}
for _, beer in ipairs(CFG.BeerVariants) do
	if beer.ingredients then
		local inputs = { bar_mout = 1, bar_levure = 1 }
		for id, qty in pairs(beer.ingredients) do inputs[id] = qty end
		CFG.Recipes[beer.step] = { inputs = inputs, output = beer.item, qty = 1, duration = 150 }
		CFG.Steps[#CFG.Steps + 1] = {
			id = beer.step, product = "biere", variant = beer.id, game = "fermenteur",
			label = "Fermenter", sub = beer.name,
		}
	end
end

function EVO_BUSINESS.BeerVariant(id)
	for _, beer in ipairs(CFG.BeerVariants) do
		if beer.id == id then return beer end
	end
end

-- Lots : ×N dépense N recettes d'un coup, durée = 1×duration (parallèle).
CFG.MaxBatch = 5

-- Ancien id distillerie : les piles déjà en sac comptent / se consomment comme graine_ble.
CFG.ItemAliases = {
	bar_graines = "graine_ble",
}

CFG.Heat = {
	item     = "res_bois",
	amount   = 3,
	duration = 600,  -- 10 min par alimentation
	max      = 1800, -- cap 30 min
}

CFG.Drink = {
	duration   = 90,
	useCD      = 2,
	window     = 3600, -- historique d'ivresse (1 h)
	-- Points d'ivresse par boisson ; un saké équivaut à deux bières.
	strength   = { bar_biere = 1, bar_sake = 2 },
	koThreshold = 10,  -- >10 points dans la fenêtre → jet KO
	koChance   = 0.5,
	handPos    = Vector(1.5, 1.2, 0),
	handAng    = Angle(0, 0, 0),
	handScale  = 0.85,
	-- Niveaux 1..4 selon les points d'ivresse dans la fenêtre.
	stages = {
		{ max = 2, slow = 0.92, blurAdd = 0.08, blurDraw = 0.25, colour = 1.05, bright = -0.01, sway = 0.15, lag = 0 },
		{ max = 4, slow = 0.82, blurAdd = 0.14, blurDraw = 0.45, colour = 1.12, bright = -0.03, sway = 0.35, lag = 0.15 },
		{ max = 7, slow = 0.68, blurAdd = 0.20, blurDraw = 0.65, colour = 1.20, bright = -0.05, sway = 0.60, lag = 0.35 },
		{ max = 99, slow = 0.50, blurAdd = 0.28, blurDraw = 0.85, colour = 1.30, bright = -0.08, sway = 1.00, lag = 0.55 },
	},
}
CFG.Drink.special = {}
for _, beer in ipairs(CFG.BeerVariants) do
	CFG.Drink.strength[beer.item] = 1
	if beer.effect then CFG.Drink.special[beer.item] = { effect = beer.effect, duration = beer.duration } end
end

-- Grades perso (bitmask). Leader = tout. Sans grade (rank_id 0) = DefaultMemberPerms.
CFG.MaxRanks = 8
EVO_BUSINESS.PERM = {
	DISTILLERIE = 1, -- utiliser la distillerie
	COFFRE      = 2, -- ouvrir / retirer du coffre
	RECRUIT     = 4, -- inviter un employé
}
EVO_BUSINESS.PermList = {
	{ bit = EVO_BUSINESS.PERM.DISTILLERIE, label = "DISTILLERIE" },
	{ bit = EVO_BUSINESS.PERM.COFFRE,      label = "COFFRE" },
	{ bit = EVO_BUSINESS.PERM.RECRUIT,     label = "RECRUTER" },
}
EVO_BUSINESS.PermAll = 0
for _, nBit in pairs(EVO_BUSINESS.PERM) do
	EVO_BUSINESS.PermAll = bit.bor(EVO_BUSINESS.PermAll, nBit)
end
-- Employé sans grade : aucune permission (le leader doit assigner un grade).
CFG.DefaultMemberPerms = 0

-- Placements par map : remplis via !config_positions (listes vides par défaut).
CFG.Stations = {}
CFG.Coffres  = {}

function EVO_BUSINESS.BusinessById(sId)
	return CFG.Businesses[tostring(sId or "")]
end

-- kind « bar » = brasserie (Urahara barOnly, distillerie/coffre bar).
function EVO_BUSINESS.BusinessKind(sId)
	local t = EVO_BUSINESS.BusinessById(sId)
	return t and tostring(t.kind or t.id or "") or ""
end

function EVO_BUSINESS.IsBarBusiness(sId)
	return EVO_BUSINESS.BusinessKind(sId) == "bar"
end

function EVO_BUSINESS.IsMember(ply, sBiz)
	if not (IsValid(ply) and ply.GetEvoNWString) then return false end
	local id = ply:GetEvoNWString("EVO_BusinessId", "")
	if id == "" then return false end
	if sBiz and sBiz ~= "" and id ~= sBiz then return false end
	return true
end

-- Membre d'AU MOINS un commerce du kind donné (ex. "bar").
function EVO_BUSINESS.IsKindMember(ply, sKind)
	if not (IsValid(ply) and ply.GetEvoNWString) then return false end
	local id = ply:GetEvoNWString("EVO_BusinessId", "")
	if id == "" then return false end
	return EVO_BUSINESS.BusinessKind(id) == tostring(sKind or "")
end

function EVO_BUSINESS.StationBusiness(e)
	if istable(e) and isstring(e.business) and e.business ~= "" then
		return e.business
	end
	return "bar"
end

function EVO_BUSINESS.IsLeader(ply, sBiz)
	if not EVO_BUSINESS.IsMember(ply, sBiz) then return false end
	return ply:GetEvoNWBool("EVO_BusinessLeader", false)
end

function EVO_BUSINESS.DrinkStage(nCount)
	nCount = math.max(0, math.floor(tonumber(nCount) or 0))
	local stages = (CFG.Drink and CFG.Drink.stages) or {}
	for i, st in ipairs(stages) do
		if nCount <= (st.max or 99) then return i, st end
	end
	local last = stages[#stages]
	return #stages, last
end

-- Bits effectifs : leader = tout ; sinon grade perso, sinon DefaultMemberPerms.
function EVO_BUSINESS.ResolvePerms(bLeader, nRankPerms, bHasRank)
	if bLeader then return EVO_BUSINESS.PermAll or 0 end
	if bHasRank then return tonumber(nRankPerms) or 0 end
	return tonumber(CFG.DefaultMemberPerms) or 0
end

function EVO_BUSINESS.HasPermBits(nBits, nPerm)
	nBits = tonumber(nBits) or 0
	nPerm = tonumber(nPerm) or 0
	if nPerm == 0 then return true end
	return bit.band(nBits, nPerm) ~= 0
end

function EVO_BUSINESS.StationDef(sType)
	return CFG.StationTypes[tostring(sType or "")]
end

function EVO_BUSINESS.RecipeFor(sType)
	return CFG.Recipes[tostring(sType or "")]
end

function EVO_BUSINESS.StepDef(sId)
	sId = tostring(sId or "")
	for _, st in ipairs(CFG.Steps or {}) do
		if st.id == sId then return st end
	end
end

function EVO_BUSINESS.ItemName(sId)
	sId = tostring(sId or "")
	local alias = CFG.ItemAliases and CFG.ItemAliases[sId]
	if alias then sId = alias end
	local it = ITEMS and ITEMS[sId]
	if it and it.name then return it.name end
	if EVO_CRAFT and EVO_CRAFT.ResourceName then return EVO_CRAFT.ResourceName(sId) end
	return (sId ~= "" and sId:gsub("_", " ")) or "?"
end

-- Ancre au sol (même recette que les établis labo / ateliers).
local _spot, _zone = {}, {}
function EVO_BUSINESS.InvalidateAnchors()
	_spot, _zone = {}, {}
end

local function snapGround(v)
	if not isvector(v) then return Vector(0, 0, 0) end
	local tr = util.TraceLine({
		start  = v + Vector(0, 0, 16),
		endpos = v - Vector(0, 0, 512),
		mask   = MASK_SOLID_BRUSHONLY,
	})
	if tr.Hit and not tr.StartSolid then return tr.HitPos end
	return v
end

function EVO_BUSINESS.StationSpot(e)
	if not (istable(e) and isvector(e.pos)) then return Vector(0, 0, 0) end
	local key = (e.type or "?") .. "|" .. math.Round(e.pos.x) .. "|" .. math.Round(e.pos.y)
	local v = _spot[key]
	if v then return v end
	v = snapGround(e.pos)
	_spot[key] = v
	return v
end

function EVO_BUSINESS.StationZoneSpot(e)
	if not istable(e) then return Vector(0, 0, 0) end
	if not e.zonePos then return EVO_BUSINESS.StationSpot(e) end
	local key = (e.type or "?") .. "|zone|" .. math.Round(e.zonePos.x) .. "|" .. math.Round(e.zonePos.y)
	local v = _zone[key]
	if v then return v end
	v = snapGround(e.zonePos)
	_zone[key] = v
	return v
end

function EVO_BUSINESS.EnsureStationList(map)
	map = map or game.GetMap()
	CFG.Stations[map] = CFG.Stations[map] or {}
	for _, e in ipairs(CFG.Stations[map]) do
		if istable(e) and (e.type == "moulin" or e.type == "cuve" or e.type == "fermenteur") then
			e.type = "distillerie"
		end
	end
	return CFG.Stations[map]
end

function EVO_BUSINESS.EnsureCoffreList(map)
	map = map or game.GetMap()
	CFG.Coffres[map] = CFG.Coffres[map] or {}
	return CFG.Coffres[map]
end

function EVO_BUSINESS.InputIds(sId)
	sId = tostring(sId or "")
	local t = { sId }
	for old, canon in pairs(CFG.ItemAliases or {}) do
		if canon == sId then t[#t + 1] = old end
	end
	return t
end

function EVO_BUSINESS.CountBagExact(ply, sId)
	if not (IsValid(ply) and isstring(sId)) then return 0 end
	if ply.CountInventoryItem then return ply:CountInventoryItem(sId) end
	if INVENTORY_CONFIG and INVENTORY_CONFIG.CountBagItem then
		return INVENTORY_CONFIG.CountBagItem(ply.inventory, sId)
	end
	return 0
end

function EVO_BUSINESS.CountBag(ply, sId)
	local n = 0
	for _, id in ipairs(EVO_BUSINESS.InputIds(sId)) do
		n = n + EVO_BUSINESS.CountBagExact(ply, id)
	end
	return n
end
