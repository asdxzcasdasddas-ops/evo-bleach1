-- "addons\\evo_business\\lua\\evo_business\\sh_items.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — items du Bar.
-- Définis dans inventory/lua/inventory/config.lua (ITEMS.bar_*).
-- Les bières spéciales sont générées depuis CFG.BeerVariants.
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}

-- Miroir optionnel pour ItemName / UI si un appel lit EVO_BUSINESS.Items.
EVO_BUSINESS.Items = {
	bar_eau = true,
	bar_houblon = true,
	bar_levure = true,
	bar_malt_moulu = true,
	bar_mout = true,
	bar_biere = true,
	graine_riz = true,
	bar_koji = true,
	bar_riz_cuit = true,
	bar_sake = true,
}

function EVO_BUSINESS.RegisterBeerItems()
	if not istable(ITEMS) then return end
	local cfg = EVO_BUSINESS.CFG
	for _, beer in ipairs(cfg.BeerVariants or {}) do
		if beer.ingredients then
			local id = beer.item
			local effect = cfg.BeerEffects[beer.effect]
			ITEMS[id] = {
				name = beer.name,
				description = "Bière du Bar. Utiliser pour boire : " .. effect.label .. " pendant " .. beer.duration
					.. " s. Remplace l'effet spécial précédent. Compte comme une bière pour l'ivresse.",
				category = "object", rarity = "rare", stack_max = 64, is_droppable = true,
				model_path = "models/evo/props/items/evo_26fgrbh5reg1nhre62r/evo_26FGRBH5reg1nhRE62r.mdl",
				on_use = function(ply)
					if SERVER and EVO_BUSINESS.DrinkAlcohol then EVO_BUSINESS.DrinkAlcohol(ply, id) end
				end,
			}
			EVO_BUSINESS.Items[id] = true
		end
	end
end

-- L'inventaire appelle aussi ce registre à la fin de son chargement : les deux
-- ordres d'include et les rechargements de sa table ITEMS sont supportés.
EVO_BUSINESS.RegisterBeerItems()
