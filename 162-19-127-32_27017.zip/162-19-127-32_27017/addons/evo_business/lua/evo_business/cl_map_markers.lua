-- "addons\\evo_business\\lua\\evo_business\\cl_map_markers.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — marqueur « Bar » sur tableau map + carte de poche.
-- Position monde reçue du serveur (distillerie config_positions).
-- ============================================================================

if not CLIENT then return end

EVO_BUSINESS = EVO_BUSINESS or {}

local MARKER_NAME = "Bar"
local _poiPos -- Vector ou nil

local CALIB = {
	seireitei = {
		ax = 2.5562e-5, bx = -3.9139e-6, cx = 0.4946,
		ay = -7.2011e-7, by = -2.9355e-5, cy = 0.4968,
		server = "rp_seireitei_v1",
	},
	hueco_lasnoches = {
		ax = 3.850928e-5, bx = -2.113656e-6, cx = 0.605734,
		ay = -3.568784e-7, by = -3.825103e-5, cy = 0.542366,
		server = "hueco_mundo_v1",
	},
}

local function regionForMap()
	local map = game.GetMap()
	if string.find(map, "hueco", 1, true) then return "hueco_lasnoches" end
	return "seireitei"
end

local function worldToImage(region, pos)
	local c = CALIB[region]
	if not c or not isvector(pos) then return nil end
	if c.server and game.GetMap() ~= c.server then return nil end
	local x = c.ax * pos.x + c.bx * pos.y + c.cx
	local y = c.ay * pos.x + c.by * pos.y + c.cy
	if x < -0.02 or x > 1.02 or y < -0.02 or y > 1.02 then return nil end
	return math.Clamp(x, 0, 1), math.Clamp(y, 0, 1)
end

local function buildMarker(mapId)
	if not _poiPos then return nil end
	local region = regionForMap()
	if mapId ~= region then return nil end
	local x, y = worldToImage(region, _poiPos)
	if not x then return nil end
	return {
		x = x, y = y,
		name = MARKER_NAME,
		kind = "poi",
		pos = _poiPos,
		key = region .. "|" .. MARKER_NAME,
		_evoBusiness = true,
	}
end

net.Receive("evo_biz:map_poi", function()
	if net.ReadBool() then
		_poiPos = net.ReadVector()
	else
		_poiPos = nil
	end
end)

local _origGetMarkers
local function install()
	if not EVO_Map_GetMarkers then return false end
	if _origGetMarkers then return true end
	_origGetMarkers = EVO_Map_GetMarkers
	function EVO_Map_GetMarkers(map_id)
		local list = _origGetMarkers(map_id) or {}
		for _, m in ipairs(list) do
			if m.name == MARKER_NAME then return list end
		end
		local m = buildMarker(map_id)
		if not m then return list end
		local out = {}
		for i, v in ipairs(list) do out[i] = v end
		out[#out + 1] = m
		return out
	end
	return true
end

hook.Add("InitPostEntity", "EVO_Business::MapMarker", function()
	timer.Simple(2, install)
end)
timer.Create("EVO_Business::MapMarkerInstall", 3, 10, function()
	if install() then timer.Remove("EVO_Business::MapMarkerInstall") end
end)
