-- "addons\\evo_business\\lua\\evo_business\\cl_stations.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — UI distillerie (bière / saké, un lot à la fois) + plaque [E].
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}
local CFG = EVO_BUSINESS.CFG

local COL_CARD   = Color(13, 14, 17, 250)
local COL_INNER  = Color(18, 19, 23, 255)
local COL_INNER2 = Color(22, 23, 28, 255)
local COL_SEL    = Color(32, 24, 26, 255)
local COL_ACCENT = Color(207, 68, 78, 255)
local COL_TXT    = Color(235, 235, 240, 255)
local COL_DIM    = Color(150, 150, 160, 255)
local COL_MUTED  = Color(110, 113, 120, 255)
local COL_GREEN  = Color(78, 196, 128, 255)
local COL_SUB_HI = Color(27, 27, 33, 255)
local COL_SLOT   = Color(20, 20, 24, 255)
local COL_SLOT_OUT = Color(18, 36, 26, 255)
local COL_BAR_BG = Color(8, 8, 10, 255)

local FRAME
local SNAP = {}

function EVO_BUSINESS.SetStationUIInput(bOn)
	if not IsValid(FRAME) then return end
	FRAME:SetMouseInputEnabled(bOn and true or false)
	FRAME:SetKeyboardInputEnabled(bOn and true or false)
end

local function SX(n)
	return gRespX and gRespX(n) or n
end
local function SY(n)
	return gRespY and gRespY(n) or n
end

local function parseSnap(raw)
	local ok, t = pcall(util.JSONToTable, raw or "")
	return (ok and istable(t)) and t or {}
end

local function fmtLeft(n)
	n = math.max(0, math.floor(tonumber(n) or 0))
	if n >= 60 then return math.floor(n / 60) .. " min " .. (n % 60) .. " s" end
	return n .. " s"
end

local function paintPlate(x, y, w, h, col, cut, corner)
	if EVO_UI and EVO_UI.PaintCut then
		EVO_UI.PaintCut(x, y, w, h, col, cut or SY(10), corner)
	elseif RNDX and RNDX.Draw then
		RNDX.Draw(cut or 8, x, y, w, h, col)
	else
		draw.RoundedBox(6, x, y, w, h, col)
	end
end

local function styleBeerChoice(choice)
	choice:SetFont("Bebas Neue:22")
	choice:SetTextInset(SX(14), 0)
	choice:SetTextColor(COL_TXT)
	choice:SetCursor("hand")
	choice.UpdateColours = function() end
	if IsValid(choice.DropButton) then choice.DropButton:SetVisible(false) end
	choice.Paint = function(p, w, h)
		local enabled = p:IsEnabled()
		local open = p:IsMenuOpen()
		local active = enabled and (open or p:IsHovered())
		paintPlate(0, 0, w, h, active and COL_SEL or COL_INNER, SY(8), "br")
		p:SetTextColor(enabled and COL_TXT or COL_MUTED)
		surface.SetDrawColor(active and COL_ACCENT or COL_MUTED)
		surface.DrawRect(0, 0, SX(2), h)
		local x, y, size = w - SX(22), h / 2, SY(4)
		local direction = open and -1 or 1
		surface.DrawLine(x - size, y - size * direction / 2, x, y + size * direction / 2)
		surface.DrawLine(x, y + size * direction / 2, x + size, y - size * direction / 2)
	end
	choice.OnMenuOpened = function(p, menu)
		menu:SetDrawColumn(false)
		menu:SetDrawBorder(false)
		menu.Paint = function(_, w, h)
			paintPlate(0, 0, w, h, COL_CARD, SY(8), "br")
		end
		for _, option in ipairs(menu:GetCanvas():GetChildren()) do
			local selected = option:GetText() == p:GetText()
			option:SetFont("Bebas Neue:22")
			option:SetTextInset(SX(14), 0)
			option:SetTextColor(selected and COL_ACCENT or COL_TXT)
			option.UpdateColours = function() end
			option.PerformLayout = function(row) row:SetTall(SY(32)) end
			option:SetTall(SY(32))
			option.Paint = function(row, w, h)
				local hovered = row:IsHovered()
				paintPlate(0, 0, w, h, hovered and COL_SUB_HI or (selected and COL_SEL or COL_INNER), SY(6), "br")
				row:SetTextColor((selected or hovered) and COL_ACCENT or COL_TXT)
				if selected or hovered then
					surface.SetDrawColor(COL_ACCENT)
					surface.DrawRect(0, 0, SX(2), h)
				end
			end
		end
		-- Recalcule la hauteur et le placement à l'écran avec les lignes EVO.
		local x, y = p:LocalToScreen(0, p:GetTall())
		menu:Open(x, y, false, p)
	end
end

local function makeCloseCross(parent, x, y, fClick)
	if EVO_CRAFT and EVO_CRAFT.MakeCloseCross then
		local b = EVO_CRAFT.MakeCloseCross(parent, x, y, fClick)
		b:SetZPos(32000)
		if b.SetCursor then b:SetCursor("hand") end
		return b
	end
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetSize(SX(52), SY(52))
	b:SetPos(x, y)
	b:SetZPos(32000)
	b:SetCursor("hand")
	b.Paint = function(s, w, h)
		if s:IsHovered() then paintPlate(0, 0, w, h, COL_SUB_HI, SY(10)) end
		draw.SimpleText("×", "Bebas Neue:44", w / 2, h / 2 - SY(2),
			s:IsHovered() and COL_ACCENT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = fClick
	return b
end

local function itemDef(sId)
	if not sId then return nil end
	return ITEMS and ITEMS[sId]
end

local function sortedInputs(t)
	local keys = {}
	for id in pairs(t or {}) do keys[#keys + 1] = id end
	table.sort(keys)
	local out = {}
	for _, id in ipairs(keys) do
		out[#out + 1] = { id = id, n = tonumber(t[id]) or 0 }
	end
	return out
end

local function stepList(s)
	if istable(s.steps) then
		if #s.steps > 0 then return s.steps end
		local tmp = {}
		for k, v in pairs(s.steps) do
			local i = tonumber(k)
			if i and istable(v) then tmp[i] = v end
		end
		if istable(tmp[1]) then return tmp end
	end
	local out = {}
	for _, st in ipairs(CFG.Steps or {}) do
		local rec = EVO_BUSINESS.RecipeFor(st.id) or {}
		out[#out + 1] = {
			id = st.id,
			product = st.product,
			variant = st.variant,
			game = st.game,
			label = st.label,
			sub = st.sub,
			inputs = rec.inputs or {},
			output = rec.output,
			qty = rec.qty or 1,
			duration = rec.duration or 0,
			needHeat = rec.needHeat and true or false,
		}
	end
	return out
end

local function stepById(s, id)
	id = tostring(id or "")
	for _, st in ipairs(stepList(s)) do
		if st.id == id then return st end
	end
end

local function recipeLine(rec)
	if not rec then return "" end
	local bits = {}
	for _, e in ipairs(sortedInputs(rec.inputs)) do
		bits[#bits + 1] = EVO_BUSINESS.ItemName(e.id)
	end
	local src = #bits > 0 and table.concat(bits, " + ") or "—"
	return src .. "  →  " .. EVO_BUSINESS.ItemName(rec.output)
end

local function stockOf(id)
	local stock = SNAP.stock
	if istable(stock) and stock[id] ~= nil then
		return math.max(0, math.floor(tonumber(stock[id]) or 0))
	end
	return EVO_BUSINESS.CountBag(LocalPlayer(), id)
end

local function maxAffordable(inputs)
	local nMax = CFG.MaxBatch or 5
	for id, n in pairs(inputs or {}) do
		n = tonumber(n) or 0
		if n > 0 then
			nMax = math.min(nMax, math.floor(stockOf(id) / n))
		end
	end
	return math.max(0, nMax)
end

local function liveLeft()
	local readyAt = tonumber(SNAP.readyAt) or 0
	if readyAt > 0 then return math.max(0, readyAt - os.time()) end
	return math.max(0, tonumber(SNAP.left) or 0)
end

local function liveHeat()
	local heatUntil = tonumber(SNAP.heatUntil) or 0
	if heatUntil > 0 then return math.max(0, heatUntil - os.time()) end
	return math.max(0, tonumber(SNAP.heatLeft) or 0)
end

local function liveState()
	local st = SNAP.state or "idle"
	if st == "busy" and liveLeft() <= 0 and (tonumber(SNAP.readyAt) or 0) > 0 then
		return "ready"
	end
	return st
end

local function jobTotal()
	local readyAt = tonumber(SNAP.readyAt) or 0
	local startedAt = tonumber(SNAP.startedAt) or 0
	if readyAt > startedAt and startedAt > 0 then return readyAt - startedAt end
	return math.max(1, tonumber(SNAP.total) or 1)
end

local function jobFrac()
	local tot = jobTotal()
	if tot <= 0 then return 0 end
	return math.Clamp(1 - liveLeft() / tot, 0, 1)
end

local function stepLabel(id)
	local st = stepById(SNAP, id)
	return (st and st.label) or id or "Lot"
end

local function statusText()
	local st = liveState()
	if st == "busy" then
		return (stepLabel(SNAP.step) or "Lot") .. " — " .. fmtLeft(liveLeft())
	end
	if st == "ready" then
		local name = EVO_BUSINESS.ItemName(SNAP.output)
		local nQty = tonumber(SNAP.qty) or 1
		return (name or "Lot") .. " prêt" .. (nQty > 1 and (" ×" .. nQty) or "")
	end
	return "En attente"
end

local function statusColor()
	local st = liveState()
	if st == "ready" then return COL_GREEN end
	if st == "busy" then return COL_ACCENT end
	return COL_DIM
end

local function makeSlot(parent, x, y, sz, sId, nQty, tOpt)
	tOpt = tOpt or {}
	local pnl = vgui.Create("DPanel", parent)
	pnl:SetPos(x, y)
	pnl:SetSize(sz, sz)
	local it = itemDef(sId)
	local sName = (it and it.name) or EVO_BUSINESS.ItemName(sId)
	if sName and sName ~= "" then
		pnl:SetTooltip(sName .. (nQty and nQty > 0 and (" ×" .. nQty) or ""))
		pnl:SetTooltipPanelOverride("EVO_Tooltip")
	end
	local colBg = tOpt.ready and COL_SLOT_OUT or COL_SLOT
	pnl.Paint = function(_, w, h)
		if RNDX and RNDX.Draw then
			RNDX.Draw(8, 0, 0, w, h, colBg)
			if tOpt.ready and RNDX.DrawOutlined then
				RNDX.DrawOutlined(8, 0, 0, w, h, COL_GREEN, 2)
			elseif tOpt.ghost and RNDX.DrawOutlined then
				RNDX.DrawOutlined(8, 0, 0, w, h, Color(90, 90, 100, 70), 1)
			end
		else
			draw.RoundedBox(6, 0, 0, w, h, colBg)
		end
		if not it then
			draw.SimpleText("—", "Bebas Neue:22", w / 2, h / 2, COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	if it then
		local hold = vgui.Create("DPanel", pnl)
		hold:SetPos(4, 2)
		hold:SetSize(sz - 8, sz - 20)
		hold:SetMouseInputEnabled(false)
		hold.Paint = nil
		if tOpt.ghost then hold:SetAlpha(120) end
		if LZY_INVENTORY_ITEM_PREVIEW and LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel then
			LZY_INVENTORY_ITEM_PREVIEW.SetupModelPanel(hold, it, 30)
			hold.Think = function(s)
				local mp = s._modelPanel
				if IsValid(mp) and mp:IsMouseInputEnabled() then mp:SetMouseInputEnabled(false) end
			end
		else
			hold.Paint = function(_, w, h)
				draw.SimpleText(string.upper(string.sub(sName or "?", 1, 1)), "Bebas Neue:28",
					w / 2, h / 2, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
	if nQty and nQty > 0 then
		local q = vgui.Create("DLabel", pnl)
		q:SetSize(sz - 6, 16)
		q:SetPos(3, sz - 17)
		q:SetFont("Bebas Neue:16")
		q:SetTextColor(tOpt.missing and COL_ACCENT or COL_TXT)
		q:SetContentAlignment(6)
		q:SetText("×" .. nQty)
	end
	return pnl
end

local function makeSlotRow(parent, y, snap, rec, st, nLots)
	local w = parent:GetWide() - SX(40)
	local sz = SY(64)
	local gap = SX(8)
	local tIn = {}
	local nOut = math.max(1, (tonumber(rec.qty) or 1) * nLots)
	local bInGhost, bOutGhost, bOutReady = true, true, false
	local bThisJob = (snap.step == rec.id) and st ~= "idle"
	if st == "idle" or not bThisJob then
		for _, e in ipairs(sortedInputs(rec.inputs)) do
			tIn[#tIn + 1] = {
				id = e.id,
				n = e.n * nLots,
				missing = st == "idle" and stockOf(e.id) < e.n * nLots,
			}
		end
		nOut = math.max(1, (tonumber(rec.qty) or 1) * nLots)
	else
		tIn = sortedInputs(snap.put)
		bInGhost = st == "ready"
		bOutGhost = st ~= "ready"
		bOutReady = st == "ready"
		nOut = math.max(1, tonumber(snap.qty) or 1)
	end

	local nCells = #tIn + 1
	local rowW = nCells * sz + math.max(0, nCells - 1) * gap + SX(28)
	local x = SX(20) + math.max(0, math.floor((w - rowW) / 2))
	for _, e in ipairs(tIn) do
		makeSlot(parent, x, y, sz, e.id, e.n, { ghost = bInGhost, missing = e.missing })
		x = x + sz + gap
	end
	local arrow = vgui.Create("DLabel", parent)
	arrow:SetPos(x, y)
	arrow:SetSize(SX(20), sz)
	arrow:SetFont("Bebas Neue:28")
	arrow:SetTextColor((bThisJob and st == "ready") and COL_GREEN or COL_DIM)
	arrow:SetContentAlignment(5)
	arrow:SetText("→")
	x = x + SX(28)
	local sOut = (bThisJob and snap.output) or rec.output
	makeSlot(parent, x, y, sz, sOut, nOut, { ghost = bOutGhost, ready = bOutReady })
	return sz + SY(8)
end

local function paintTimerLabels()
	if not IsValid(FRAME) then return end
	if IsValid(FRAME._stLbl) then
		FRAME._stLbl:SetText(statusText())
		FRAME._stLbl:SetTextColor(statusColor())
	end
	if IsValid(FRAME._heatLbl) then
		local nHeat = liveHeat()
		FRAME._heatLbl:SetTextColor(nHeat > 0 and COL_GREEN or COL_ACCENT)
		FRAME._heatLbl:SetText(nHeat > 0
			and ("Chaleur : " .. fmtLeft(nHeat))
			or "Froide — alimente avec du bois")
	end
	if IsValid(FRAME._etaLbl) and liveState() == "busy" and SNAP.step == FRAME._step then
		FRAME._etaLbl:SetText("Reste " .. fmtLeft(liveLeft()))
	end
end

local function Rebuild()
	if not IsValid(FRAME) then return end
	local card = FRAME._card
	if not IsValid(card) then return end
	card:Clear()
	FRAME._heatLbl = nil
	FRAME._etaLbl = nil

	local s = SNAP
	local st = liveState()
	local allSteps = stepList(s)
	if st ~= "idle" and s.step then
		FRAME._step = s.step
		local active = stepById(s, s.step)
		FRAME._product = active and active.product or "biere"
		if active and active.variant then FRAME._variant = active.variant end
	end
	FRAME._product = FRAME._product or "biere"
	FRAME._variant = FRAME._variant or "classique"
	local steps = {}
	local selected
	for _, step in ipairs(allSteps) do
		if (step.product or "biere") == FRAME._product and (not step.variant or step.variant == FRAME._variant) then
			steps[#steps + 1] = step
			if step.id == FRAME._step then selected = step end
		end
	end
	if not selected then
		FRAME._step = steps[1] and steps[1].id
	end
	local rec = stepById(s, FRAME._step) or steps[1]
	if not rec then return end

	local nCap = CFG.MaxBatch or 5
	local nMaxBag = maxAffordable(rec.inputs)
	FRAME._qty = math.Clamp(math.floor(tonumber(FRAME._qty) or 1), 1, math.max(1, nCap))
	if st == "idle" and nMaxBag > 0 then
		FRAME._qty = math.min(FRAME._qty, nMaxBag)
	end
	local nLots = FRAME._qty
	local nHeat = liveHeat()
	local machineBusy = st ~= "idle"
	local thisJob = machineBusy and s.step == rec.id

	local y = SY(8)
	local pad = SX(20)
	local innerW = card:GetWide() - pad * 2
	local products = CFG.Products or {}
	local productW = math.floor((innerW - SX(8) * math.max(0, #products - 1)) / math.max(1, #products))
	for i, product in ipairs(products) do
		local productId = product.id
		local productLabel = product.label
		local selectedProduct = FRAME._product == productId
		local button = vgui.Create("DButton", card)
		button:SetPos(pad + (i - 1) * (productW + SX(8)), y)
		button:SetSize(productW, SY(36))
		button:SetText("")
		button:SetCursor(machineBusy and "arrow" or "hand")
		button:SetTooltip(machineBusy and "Range le lot dans le coffre avant de changer de boisson." or productLabel)
		button:SetTooltipPanelOverride("EVO_Tooltip")
		button.Paint = function(p, w, h)
			paintPlate(0, 0, w, h, selectedProduct and COL_SEL or COL_INNER, SY(8))
			draw.SimpleText(productLabel, "Bebas Neue:26", w / 2, h / 2,
				selectedProduct and COL_ACCENT or (machineBusy and COL_MUTED or COL_TXT), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function()
			if machineBusy or FRAME._product == productId then return end
			FRAME._product = productId
			FRAME._step = nil
			FRAME._qty = 1
			Rebuild()
		end
	end
	y = y + SY(48)
	if FRAME._product == "biere" then
		local beer = EVO_BUSINESS.BeerVariant(FRAME._variant) or CFG.BeerVariants[1]
		local choice = vgui.Create("DComboBox", card)
		choice:SetPos(pad, y)
		choice:SetSize(innerW, SY(32))
		choice:SetValue(beer.name)
		choice:SetSortItems(false)
		choice:SetEnabled(not machineBusy)
		styleBeerChoice(choice)
		for _, variant in ipairs(CFG.BeerVariants) do choice:AddChoice(variant.name, variant.id) end
		choice.OnSelect = function(_, _, _, id)
			if machineBusy or FRAME._variant == id then return end
			FRAME._variant = id
			-- Garde les étapes communes, change uniquement la fermentation.
			local current = stepById(s, FRAME._step)
			if current and current.variant then FRAME._step = EVO_BUSINESS.BeerVariant(id).step end
			FRAME._qty = 1
			Rebuild()
		end
		local effect = vgui.Create("DLabel", card)
		effect:SetPos(pad, y + SY(36))
		effect:SetSize(innerW, SY(20))
		effect:SetFont("DermaDefault")
		effect:SetTextColor(COL_DIM)
		effect:SetText(beer.effect and (CFG.BeerEffects[beer.effect].label .. " · " .. beer.duration .. " s · remplace l'effet spécial précédent")
			or "Bière classique · ivresse habituelle")
		y = y + SY(64)
	end
	local nCards = math.max(1, #steps)
	local gap = SX(8)
	local cardW = math.floor((innerW - gap * (nCards - 1)) / nCards)
	local cardH = SY(118)

	for i, step in ipairs(steps) do
		local stDef = step
		local bLocked = machineBusy and stDef.id ~= s.step
		local bSelected = FRAME._step == stDef.id
		local bBusyThis = st == "busy" and stDef.id == s.step
		local bReadyThis = st == "ready" and stDef.id == s.step
		local bx = pad + (i - 1) * (cardW + gap)
		local btn = vgui.Create("DButton", card)
		btn:SetPos(bx, y)
		btn:SetSize(cardW, cardH)
		btn:SetText("")
		btn:SetCursor(bLocked and "arrow" or "hand")
		btn.Paint = function(p, w, h)
			local bg = bSelected and COL_SEL or COL_INNER
			if p:IsHovered() and not bLocked then bg = COL_INNER2 end
			paintPlate(0, 0, w, h, bg, SY(10), "br")
			if bSelected then
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawRect(0, 0, 3, h - SY(10))
			end
			local colTitle = bLocked and COL_MUTED or COL_TXT
			draw.SimpleText(string.upper(stDef.label or ""), "Bebas Neue:26", SX(12), SY(8), colTitle, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local sLine
			local colLine = COL_DIM
			if bBusyThis then
				sLine = fmtLeft(liveLeft())
				colLine = COL_ACCENT
			elseif bReadyThis then
				sLine = "Prêt pour le coffre"
				colLine = COL_GREEN
			elseif bLocked then
				sLine = "Occupée"
				colLine = COL_MUTED
			else
				sLine = stDef.sub or ""
			end
			draw.SimpleText(sLine, "DermaDefault", SX(12), SY(38), colLine, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(stDef.sub or "", "DermaDefault", SX(12), SY(58), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			if bBusyThis then
				local barY, barH = h - SY(14), SY(6)
				surface.SetDrawColor(COL_BAR_BG)
				surface.DrawRect(SX(12), barY, w - SX(24), barH)
				surface.SetDrawColor(COL_ACCENT)
				surface.DrawRect(SX(12), barY, math.floor((w - SX(24)) * jobFrac()), barH)
			end
		end
		btn.DoClick = function()
			if bLocked then return end
			FRAME._step = stDef.id
			Rebuild()
		end
	end
	y = y + cardH + SY(14)

	local sub = vgui.Create("DLabel", card)
	sub:SetPos(pad, y)
	sub:SetSize(innerW, SY(22))
	sub:SetFont("Bebas Neue:20")
	sub:SetTextColor(COL_DIM)
	sub:SetText(recipeLine(rec))
	y = y + SY(26)

	y = y + makeSlotRow(card, y, s, rec, st, nLots)

	if st == "idle" then
		local row = vgui.Create("DPanel", card)
		row:SetPos(pad, y)
		row:SetSize(innerW, SY(44))
		row:SetPaintBackground(false)
		local minus = vgui.Create("DButton", row)
		minus:SetSize(SY(44), SY(44))
		minus:SetPos(0, 0)
		minus:SetText("")
		minus.Paint = function(btn, w, h)
			local on = nLots > 1
			paintPlate(0, 0, w, h, btn:IsHovered() and on and COL_SUB_HI or Color(20, 20, 24), SY(8))
			draw.SimpleText("−", "Bebas Neue:32", w / 2, h / 2, on and COL_TXT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		minus.DoClick = function()
			FRAME._qty = math.max(1, nLots - 1)
			Rebuild()
		end
		local qtyLbl = vgui.Create("DLabel", row)
		qtyLbl:SetPos(SY(52), 0)
		qtyLbl:SetSize(row:GetWide() - SY(104), SY(44))
		qtyLbl:SetFont("Bebas Neue:28")
		qtyLbl:SetTextColor(COL_TXT)
		qtyLbl:SetContentAlignment(5)
		qtyLbl:SetText("×" .. nLots)
		local plus = vgui.Create("DButton", row)
		plus:SetSize(SY(44), SY(44))
		plus:SetPos(row:GetWide() - SY(44), 0)
		plus:SetText("")
		plus.Paint = function(btn, w, h)
			local on = nLots < nCap and nMaxBag > nLots
			paintPlate(0, 0, w, h, btn:IsHovered() and on and COL_SUB_HI or Color(20, 20, 24), SY(8))
			draw.SimpleText("+", "Bebas Neue:32", w / 2, h / 2, on and COL_TXT or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		plus.DoClick = function()
			local nextQ = nLots + 1
			if nextQ > nCap or nextQ > nMaxBag then return end
			FRAME._qty = nextQ
			Rebuild()
		end
		y = y + SY(50)

		local nNeedDur = tonumber(rec.duration) or 0
		local eta = vgui.Create("DLabel", card)
		eta:SetPos(pad, y)
		eta:SetSize(innerW, SY(20))
		eta:SetFont("DermaDefault")
		local sEta = "Durée : " .. fmtLeft(nNeedDur)
			.. (nLots > 1 and ("  (×" .. nLots .. " lots, même temps)") or "")
		if rec.needHeat and nHeat < nNeedDur then
			sEta = sEta .. "  — chaleur insuffisante"
			eta:SetTextColor(COL_ACCENT)
		else
			eta:SetTextColor(COL_DIM)
		end
		eta:SetText(sEta)
		y = y + SY(24)
	elseif thisJob and st == "busy" then
		local bar = vgui.Create("DPanel", card)
		bar:SetPos(pad, y)
		bar:SetSize(innerW, SY(18))
		bar:SetPaintBackground(false)
		bar.Paint = function(_, w, h)
			surface.SetDrawColor(COL_BAR_BG)
			surface.DrawRect(0, 4, w, h - 8)
			surface.SetDrawColor(COL_ACCENT)
			surface.DrawRect(0, 4, math.floor(w * jobFrac()), h - 8)
		end
		local eta = vgui.Create("DLabel", card)
		eta:SetPos(pad, y + SY(18))
		eta:SetSize(innerW, SY(18))
		eta:SetFont("DermaDefault")
		eta:SetTextColor(COL_ACCENT)
		eta:SetText("Reste " .. fmtLeft(liveLeft()))
		FRAME._etaLbl = eta
		y = y + SY(40)
	end

	if rec.needHeat then
		local heat = vgui.Create("DLabel", card)
		heat:SetPos(pad, y)
		heat:SetSize(innerW, SY(20))
		heat:SetFont("Bebas Neue:20")
		heat:SetTextColor(nHeat > 0 and COL_GREEN or COL_ACCENT)
		heat:SetText(nHeat > 0
			and ("Chaleur : " .. fmtLeft(nHeat))
			or "Froide — alimente avec du bois")
		FRAME._heatLbl = heat
		y = y + SY(24)
	end

	local bw, bh = innerW, SY(44)
	local function act(label, fn, fill)
		local b
		if EVO_UI and EVO_UI.ActionButton then
			b = EVO_UI.ActionButton(card, pad, y, bw, bh, label, fill, fn)
			b._font = "Bebas Neue:24"
		else
			b = vgui.Create("DButton", card)
			b:SetPos(pad, y)
			b:SetSize(bw, bh)
			b:SetText(label)
			b.DoClick = fn
		end
		y = y + bh + SY(8)
		return b
	end

	if machineBusy and not thisJob then
		local lock = vgui.Create("DLabel", card)
		lock:SetPos(pad, y)
		lock:SetSize(innerW, SY(22))
		lock:SetFont("DermaDefault")
		lock:SetTextColor(COL_MUTED)
		lock:SetContentAlignment(5)
		lock:SetText("Un lot occupe déjà la distillerie — range-le dans le coffre d'abord.")
		y = y + SY(28)
	elseif st == "idle" then
		local sLaunch = nLots > 1 and ("LANCER ×" .. nLots) or "LANCER"
		act(sLaunch, function()
			if nMaxBag < nLots then
				notification.AddLegacy("Pas assez d'ingrédients pour ×" .. nLots .. ".", NOTIFY_ERROR, 3)
				return
			end
			local nNeedDur = tonumber(rec.duration) or 0
			if rec.needHeat and liveHeat() < nNeedDur then
				notification.AddLegacy("Alimente la distillerie : pas assez de chaleur pour ce lot.", NOTIFY_ERROR, 4)
				return
			end
			local qty = FRAME._qty or 1
			local stepId = rec.id
			local function sendStart()
				net.Start("evo_biz:st_start")
				net.WriteString(stepId)
				net.WriteUInt(math.Clamp(qty, 1, nCap), 4)
				net.SendToServer()
			end
			if EVO_BUSINESS.OpenStationGame then
				EVO_BUSINESS.OpenStationGame(rec.game or stepId, sendStart)
			else
				sendStart()
			end
		end)
	elseif thisJob and st == "ready" then
		act("RANGER DANS LE COFFRE", function()
			net.Start("evo_biz:st_collect")
			net.SendToServer()
		end, COL_GREEN)
	end

	if rec.needHeat then
		act("ALIMENTER (" .. (s.fuelAmt or 3) .. " × " .. EVO_BUSINESS.ItemName(s.fuelItem or "res_bois") .. ")", function()
			net.Start("evo_biz:st_fuel")
			net.SendToServer()
		end)
	end

	FRAME._liveSt = st
end

local function OpenFrame()
	if IsValid(FRAME) then FRAME:Remove() end
	local W, H = SX(780), SY(752)
	local headerH = SY(72)
	local frame = vgui.Create("DFrame")
	FRAME = frame
	frame._qty = 1
	frame._step = SNAP.step
	frame:SetSize(W, H)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
	frame.Paint = function(_, w, h)
		paintPlate(0, 0, w, h, COL_CARD, SY(12))
		surface.SetDrawColor(COL_ACCENT)
		surface.DrawRect(0, 0, w - SY(12), 4)
	end

	local title = vgui.Create("DLabel", frame)
	title:SetPos(SX(22), SY(10))
	title:SetSize(W - SX(90), SY(32))
	title:SetFont("Bebas Neue:36")
	title:SetTextColor(COL_TXT)
	title:SetText(string.upper(SNAP.label or "DISTILLERIE"))

	local stLbl = vgui.Create("DLabel", frame)
	stLbl:SetPos(SX(22), SY(42))
	stLbl:SetSize(W - SX(90), SY(22))
	stLbl:SetFont("Bebas Neue:20")
	stLbl:SetTextColor(statusColor())
	stLbl:SetText(statusText())
	frame._stLbl = stLbl

	local card = vgui.Create("DPanel", frame)
	card:SetPos(0, headerH)
	card:SetSize(W, H - headerH)
	card:SetPaintBackground(false)
	frame._card = card

	makeCloseCross(frame, W - SX(64), SY(8), function()
		frame:Remove()
	end)

	FRAME._liveSt = liveState()
	frame.Think = function(s)
		if not IsValid(s) then return end
		local now = CurTime()
		if (s._tickAt or 0) + 0.2 > now then return end
		s._tickAt = now
		local st = liveState()
		if st ~= s._liveSt then
			s._liveSt = st
			Rebuild()
			return
		end
		paintTimerLabels()
	end

	Rebuild()
end

net.Receive("evo_biz:st_open", function()
	SNAP = parseSnap(net.ReadString())
	OpenFrame()
end)

net.Receive("evo_biz:st_snap", function()
	SNAP = parseSnap(net.ReadString())
	if IsValid(FRAME) then Rebuild() end
end)

-- ── Plaques [E] ─────────────────────────────────────────────────────────────

local function currentStation()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return nil end
	if not EVO_BUSINESS.IsKindMember(lp, "bar") then return nil end
	local sMyBiz = lp:GetEvoNWString("EVO_BusinessId", "")
	local list = CFG.Stations[game.GetMap()]
	if not istable(list) then return nil end
	local p = lp:GetPos()
	local r = CFG.ZoneRadius or 70
	local r2 = r * r
	for i, e in ipairs(list) do
		if EVO_BUSINESS.StationBusiness(e) ~= sMyBiz then continue end
		local a = EVO_BUSINESS.StationZoneSpot(e)
		local dz = p.z - a.z
		if dz >= -(CFG.ZoneBandBelow or 40) and dz <= (CFG.ZoneBandAbove or 140) then
			local dx, dy = p.x - a.x, p.y - a.y
			if dx * dx + dy * dy <= r2 then
				return i, e
			end
		end
	end
end

hook.Add("PostDrawTranslucentRenderables", "EVO_Business::StationZones", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return end
	if not EVO_BUSINESS.IsKindMember(lp, "bar") then return end
	local list = CFG.Stations[game.GetMap()]
	if not istable(list) then return end
	local sMyBiz = lp:GetEvoNWString("EVO_BusinessId", "")
	local eye = EyePos()
	for _, e in ipairs(list) do
		if EVO_BUSINESS.StationBusiness(e) ~= sMyBiz then continue end
		local def = EVO_BUSINESS.StationDef(e.type)
		if def then
			local gpos = EVO_BUSINESS.StationZoneSpot(e)
			if eye:DistToSqr(gpos) < (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then
				EVO_ZonePrompt.Draw(gpos, string.upper(def.label), def.sub or "Travailler")
			end
		end
	end
end)

hook.Add("PlayerButtonDown", "EVO_Business::StationKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if IsValid(vgui.GetKeyboardFocus()) then return end
	if IsValid(FRAME) then return end
	local i = currentStation()
	if not i then return end
	net.Start("evo_biz:st_open")
	net.SendToServer()
end)

-- ── Fumée + bouilloire sommet distillerie (craft en cours) ───────────────────

local SMOKE_BUSY = {} -- [index] = readyAt (os.time)
local smokeNext = {}
local boilNext = {}   -- [index] = RealTime prochain EmitSound
local boilPlaying = {} -- [index] = true tant qu'un EmitSound est actif côté local

local function boilPath()
	return (CFG.BoilSound and CFG.BoilSound.path) or "6515xw26amw1br/boiling_sfx.wav"
end

local function StopBoilSound(i)
	boilNext[i] = nil
	if not boilPlaying[i] then return end
	boilPlaying[i] = nil
	local lp = LocalPlayer()
	if IsValid(lp) then lp:StopSound(boilPath()) end
end

local function StopAllBoilSounds()
	local any = next(boilPlaying) ~= nil
	boilNext = {}
	boilPlaying = {}
	if any then
		local lp = LocalPlayer()
		if IsValid(lp) then lp:StopSound(boilPath()) end
	end
end

do
	util.PrecacheSound(boilPath())
end

net.Receive("evo_biz:st_smoke", function()
	local i = net.ReadUInt(8)
	local readyAt = net.ReadUInt(32)
	if readyAt > 0 then
		SMOKE_BUSY[i] = readyAt
	else
		SMOKE_BUSY[i] = nil
		smokeNext[i] = nil
		StopBoilSound(i)
	end
end)

hook.Add("Think", "EVO_Business::DistillerieSmoke", function()
	if next(SMOKE_BUSY) == nil then return end
	local sm = CFG.Smoke or {}
	local nNow = os.time()
	local rt = RealTime()
	local list = CFG.Stations[game.GetMap()]
	if not istable(list) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local eye = lp:EyePos()
	local maxDist = tonumber(sm.maxDist) or 2200
	local maxDist2 = maxDist * maxDist
	local mat = sm.material or "particle/particle_smokegrenade"
	local zOff = tonumber(sm.z) or 100
	local interval = tonumber(sm.interval) or 0.14

	for i, readyAt in pairs(SMOKE_BUSY) do
		if nNow >= (tonumber(readyAt) or 0) then
			SMOKE_BUSY[i] = nil
			smokeNext[i] = nil
			StopBoilSound(i)
			continue
		end
		if (smokeNext[i] or 0) > rt then continue end
		smokeNext[i] = rt + interval
		local e = list[i]
		if not (istable(e) and isvector(e.pos)) then continue end
		local base = EVO_BUSINESS.StationSpot(e)
		if eye:DistToSqr(base) > maxDist2 then continue end
		local pos = base + Vector(0, 0, zOff)
		local emitter = ParticleEmitter(pos, false)
		if not emitter then continue end
		local p = emitter:Add(mat, pos + VectorRand() * 3)
		if p then
			local spread = tonumber(sm.spread) or 10
			p:SetVelocity(Vector(math.Rand(-spread, spread), math.Rand(-spread, spread), tonumber(sm.speed) or 32))
			p:SetDieTime(tonumber(sm.dieTime) or 2.4)
			p:SetStartAlpha(tonumber(sm.alpha) or 75)
			p:SetEndAlpha(0)
			p:SetStartSize(tonumber(sm.startSize) or 8)
			p:SetEndSize(tonumber(sm.endSize) or 52)
			p:SetRoll(math.Rand(0, 360))
			p:SetRollDelta(math.Rand(-0.4, 0.4))
			p:SetColor(190, 190, 195)
			p:SetGravity(Vector(0, 0, 12))
			p:SetAirResistance(40)
		end
		emitter:Finish()
	end
end)

-- Bouilloire : chaque client ≤ maxDist joue en local ; StopSound dès fin de craft / hors portée.
hook.Add("Think", "EVO_Business::DistillerieBoil", function()
	if next(SMOKE_BUSY) == nil then
		if next(boilPlaying) ~= nil then StopAllBoilSounds() end
		return
	end
	local cfg = CFG.BoilSound or {}
	local path = boilPath()
	local maxDist = tonumber(cfg.maxDist) or 300
	local maxDist2 = maxDist * maxDist
	local volBase = math.Clamp(tonumber(cfg.volume) or 1, 0, 1)
	local dur = tonumber(cfg.duration) or 0
	if dur <= 0 then dur = tonumber(SoundDuration(path)) or 0 end
	if dur <= 0 then dur = 4 end
	dur = math.Clamp(dur, 0.5, 30)
	local gap = math.max(dur * 0.95, 0.25)

	local nNow = os.time()
	local rt = RealTime()
	local list = CFG.Stations[game.GetMap()]
	if not istable(list) then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local eye = lp:EyePos()

	for i, readyAt in pairs(SMOKE_BUSY) do
		if nNow >= (tonumber(readyAt) or 0) then
			SMOKE_BUSY[i] = nil
			smokeNext[i] = nil
			StopBoilSound(i)
			continue
		end
		local e = list[i]
		if not (istable(e) and isvector(e.pos)) then
			StopBoilSound(i)
			continue
		end
		local base = EVO_BUSINESS.StationSpot(e)
		local dist2 = eye:DistToSqr(base)
		if dist2 > maxDist2 then
			StopBoilSound(i)
			continue
		end
		if (boilNext[i] or 0) > rt then continue end
		boilNext[i] = rt + gap
		-- Stop avant rejoue : évite empilement si le clip chevauche le gap.
		if boilPlaying[i] then lp:StopSound(path) end
		lp:EmitSound(path, 75, 100, volBase, CHAN_STATIC)
		boilPlaying[i] = true
	end
end)
