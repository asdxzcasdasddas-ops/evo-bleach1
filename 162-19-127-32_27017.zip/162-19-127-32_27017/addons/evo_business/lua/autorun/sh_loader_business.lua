-- "addons\\evo_business\\lua\\autorun\\sh_loader_business.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO BUSINESS — commerces (leader + employés). Multi-bars supportés :
-- !createbusiness + lier distillerie/coffre via !config_positions.
-- Appartenance PAR PERSONNAGE (character_uid). Un perso = un commerce max.
-- Superadmin nomme le leader (SAM !setbusinessleader <joueur> [business]).
-- ============================================================================

EVO_BUSINESS = EVO_BUSINESS or {}

if SERVER then
	AddCSLuaFile("evo_business/sh_config.lua")
	AddCSLuaFile("evo_business/sh_business_registry.lua")
	AddCSLuaFile("evo_business/sh_items.lua")
	AddCSLuaFile("evo_business/sh_drink_effects.lua")
	AddCSLuaFile("evo_business/cl_menu.lua")
	AddCSLuaFile("evo_business/cl_stations.lua")
	AddCSLuaFile("evo_business/cl_station_games.lua")
	AddCSLuaFile("evo_business/cl_coffre.lua")
	AddCSLuaFile("evo_business/cl_drink.lua")
	AddCSLuaFile("evo_business/cl_map_markers.lua")
	AddCSLuaFile("evo_business/cl_sale.lua")

	util.AddNetworkString("evo_biz:openui")
	util.AddNetworkString("evo_biz:get")
	util.AddNetworkString("evo_biz:state")
	util.AddNetworkString("evo_biz:invite")
	util.AddNetworkString("evo_biz:invited")
	util.AddNetworkString("evo_biz:answer")
	util.AddNetworkString("evo_biz:action")
	util.AddNetworkString("evo_biz:bizlist")

	util.AddNetworkString("evo_biz:st_open")
	util.AddNetworkString("evo_biz:st_snap")
	util.AddNetworkString("evo_biz:st_start")
	util.AddNetworkString("evo_biz:st_collect")
	util.AddNetworkString("evo_biz:st_fuel")
	util.AddNetworkString("evo_biz:st_smoke")

	util.AddNetworkString("evo_biz:coffre_open")
	util.AddNetworkString("evo_biz:coffre_snap")
	util.AddNetworkString("evo_biz:coffre_don")
	util.AddNetworkString("evo_biz:coffre_take")
	util.AddNetworkString("evo_biz:coffre_sort")
	util.AddNetworkString("evo_biz:coffre_close")
	util.AddNetworkString("evo_biz:coffre_openreq")
	util.AddNetworkString("evo_biz:coffre_folder_create")
	util.AddNetworkString("evo_biz:coffre_folder_rename")
	util.AddNetworkString("evo_biz:coffre_folder_delete")
	util.AddNetworkString("evo_biz:coffre_folder_move")

	util.AddNetworkString("evo_biz:drink")
	util.AddNetworkString("evo_biz:map_poi")
end

include("evo_business/sh_config.lua")
include("evo_business/sh_business_registry.lua")
include("evo_business/sh_items.lua")
include("evo_business/sh_drink_effects.lua")

if SERVER then
	include("evo_business/sv_members.lua")
	include("evo_business/sv_sale.lua")
	include("evo_business/sv_stations.lua")
	include("evo_business/sv_coffre.lua")
	include("evo_business/sv_drink.lua")
else
	include("evo_business/cl_menu.lua")
	include("evo_business/cl_sale.lua")
	include("evo_business/cl_stations.lua")
	include("evo_business/cl_station_games.lua")
	include("evo_business/cl_coffre.lua")
	include("evo_business/cl_drink.lua")
	include("evo_business/cl_map_markers.lua")
end
