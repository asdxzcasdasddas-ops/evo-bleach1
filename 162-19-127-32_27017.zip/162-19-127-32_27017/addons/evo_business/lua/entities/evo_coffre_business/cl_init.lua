-- "addons\\evo_business\\lua\\entities\\evo_coffre_business\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

surface.CreateFont("EVO_CoffreBiz_Tag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
})

ENT.RenderGroup = RENDERGROUP_BOTH

local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local top = self:OBBMaxs().z
	if not isnumber(top) or top <= 0 then top = 48 end
	self.EVO_PromptZ = top + 18 -- invite (E) d'evo_npc_core au meme endroit
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > 80 * 80 then return end

	local name = self:GetLabelOverride() ~= "" and self:GetLabelOverride() or "Coffre du Bar"
	-- Etiquette unifiee (EVO_ZonePrompt) ; l'ancienne boite noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, top + 18, nil, 80, "coffre") return end
	local pos = ePos + Vector(0, 0, top + 18)
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	if self._tagName ~= name then
		surface.SetFont("EVO_CoffreBiz_Tag")
		self._tagName = name
		self._tagTW, self._tagTH = surface.GetTextSize(name)
	end

	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		draw.RoundedBox(0, -self._tagTW * 0.5 - 16, -self._tagTH * 0.5 - 6, self._tagTW + 32, self._tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "EVO_CoffreBiz_Tag", 0, 0,
			COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
