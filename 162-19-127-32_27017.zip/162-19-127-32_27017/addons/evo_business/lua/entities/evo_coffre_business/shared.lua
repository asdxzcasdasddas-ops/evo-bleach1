-- "addons\\evo_business\\lua\\entities\\evo_coffre_business\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type      = "anim"
ENT.Base      = "base_anim"
ENT.PrintName = "Coffre du Bar"
ENT.Author    = "EVO"
ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "BusinessId")
	self:NetworkVar("String", 1, "LabelOverride")
end
