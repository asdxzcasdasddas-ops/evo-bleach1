-- "addons\\evo_livre\\lua\\autorun\\evo_livre_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Archives du serveur : livres écrits par les joueurs (Livre vierge du Urahara
-- Shop), rangés/imprimés dans les zones Archives. Signer = grade 2+, ranger dans
-- un rayon de division et retirer = grade 10+, toutes divisions.

if SERVER then
	AddCSLuaFile("evo_livre/sh_config.lua")
	AddCSLuaFile("evo_livre/cl_livre.lua")

	include("evo_livre/sh_config.lua")
	include("evo_livre/sv_livre.lua")
end

if CLIENT then
	include("evo_livre/sh_config.lua")
	include("evo_livre/cl_livre.lua")
end
