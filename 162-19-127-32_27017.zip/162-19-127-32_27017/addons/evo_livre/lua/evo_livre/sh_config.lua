-- "addons\\evo_livre\\lua\\evo_livre\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Archives : config partagée + sanitize du contenu (appliqué CLIENT et SERVEUR)
-- + enregistrement des items. Modèle : on ACHÈTE un livre vierge au Urahara Shop,
-- on l'écrit librement (item libre : drop/trade/suppression), puis on peut le
-- RANGER aux archives dans une zone au sol ; tout le monde peut IMPRIMER une
-- archive de sa faction pour en avoir l'exemplaire en inventaire.

EVO_LIVRE = EVO_LIVRE or {}

EVO_LIVRE.CFG = {
	MaxPages     = 10,
	-- CALIBRÉ sur la page du LECTEUR (540x740, Georgia 16px/1.45, padding 40/48,
	-- overflow caché) : capacité réelle ~1350 caractères avec les retours de
	-- ligne. Ne pas monter sans réduire la police du lecteur, sinon le texte
	-- déborde en INVISIBLE sans prévenir. (950 -> 1200 le 08/11, demande user.)
	MaxTextLen   = 1200, -- par page
	MaxTitleLen  = 60,
	MaxBooks     = 40,
	MaxDataLen   = 60000, -- JSON décompressé (garde net ~64 Ko)

	ItemId      = "livre_lore",   -- MORT : ancien item générique, purgé des inventaires au boot
	BlankItemId = "livre_vierge", -- « Livre » du Urahara Shop, s'utilise pour créer SON livre
	WrittenItemId = "evo_livre",  -- exemplaire écrit (une row inventory par copie)
	BookPrefix  = "livre_",       -- legacy item_id : livre_<id BDD>
	-- Brouillons (livres pas encore rangés aux archives) max par joueur : borne le
	-- nombre de lignes BDD/items dynamiques qu'un seul joueur peut générer.
	MaxPersonalPerPlayer = 5,
	-- RANGER dans un rayon de division et RETIRER une archive = grade 10+,
	-- TOUTES DIVISIONS. Imprimer et consulter = tout le monde.
	ManageMinRank = 10,
	-- Grade du CHEF de faction (Sotaicho / Roi du Hueco Mundo).
	ChefRank = 16,
	-- Rayon COMMUN : ouvert à tous, et SIGNER comme y RANGER descendent à ce
	-- grade (demande user). Les autres rayons restent à ManageMinRank.
	CommonCategory = "commune",
	CommonMinRank  = 2,
	-- Budget PROPRE au rayon Commune, hors MaxBooks. Étant ouvert au grade 2, un
	-- plafond partagé permettait à un seul joueur de bloquer le rangement de
	-- TOUTE la faction, chef compris.
	CommonMaxBooks = 40,
	ClanMaxBooks = 40, -- budget indépendant pour CHAQUE clan
	ClanCategory = "clan",
	-- Réécrire un livre DÉJÀ SIGNÉ sans passer par le retrait de signature
	-- (demande user) : la signature bascule au nom de celui qui retouche.
	RewriteMinRank = 15,

	-- ── COMMANDEMENT : accès transversal (user 08\12) ───────────────────────
	-- Les gradés 2+ de la Division 1 / Ordre 1 voient TOUS les rayons de LEUR
	-- faction, quelle que soit leur division. C'est une passe-partout de commandement, pas
	-- un contournement de faction : la séparation Shinigami / Hollow ne bouge
	-- jamais. « Commandement » = index 2 dans LZY_FACTION_CONFIG.divisions ; on
	-- teste par NOM d'abord, l'index sert de repli.
	CommandementRank = 2,
	CommandementDivision = { Shinigami = "Division 1", Hollow = "Ordre 1" },
	CommandementDivisionIndex = 2,
	-- SEULE exception à cette passe-partout : le rayon « Secret défense ».

	-- ── RAYONS FIXES (refonte user 08\12) ───────────────────────────────────
	-- ⚠️ L'ACCÈS EST PORTÉ PAR LE RAYON, plus par le livre : une archive hérite
	-- des droits du rayon où elle est rangée. L'ancienne colonne `secrecy`
	-- d'evo_livres n'est plus écrite ; elle sert de filet pour les archives
	-- d'avant la refonte, sans rayon valide (cf. LegacyLockedRank).
	-- PLUS AUCUNE création en jeu : la liste est ici, point. Chaque rayon est
	-- adossé à une DIVISION (index dans LZY_FACTION_CONFIG.divisions, identique
	-- Shinigami / Hollow) et n'est visible que par elle. Trois dérogations :
	--   • « Commune » (open) n'a pas de division : tout le monde la voit, et
	--     signer/y ranger descend au grade CommonMinRank ;
	--   • Commandement (grade 2+, division idx 2) voit TOUT sauf le secret ;
	--   • « Secret défense » n'a pas de division : chef de faction (16) et les
	--     personnes qu'il y invite, personne d'autre.
	SecretCategory = "secret",
	Categories = {
		{ id = "commune",      name = "Commune",      open = true },
		{ id = "commandement", name = "Commandement", div = 2 },
		{ id = "assassin",     name = "Assassin",     div = 3 },
		{ id = "scientifique", name = "Scientifique", div = 4 },
		{ id = "medecin",      name = "Médecin",      div = 5 },
		{ id = "combat",       name = "Combat",       div = 6 },
		{ id = "secret",       name = "Secret défense" },
	},
	-- Archives dont le rayon a disparu (ou d'avant la refonte) : elles n'ont
	-- plus de droits à elles. Celles qui étaient classifiées restent verrouillées
	-- à ce grade tant que personne ne les a re-rangées, pour ne pas publier d'un
	-- coup ce qui était secret.
	UnclassifiedName = "Non classé",
	LegacyLockedRank = 15,


	-- ZONES AU SOL de consultation/écriture PAR MAP (cercles 3D2D + touche E,
	-- même mécanique que les postes d'analyse evo_science). pos = setpos BRUTES.
	StationRadius = 90,
	Stations = {
		-- Positions RAPPROCHÉES de ~18% vers leur centre commun (demande user 08/10,
		-- sens inverse du premier essai). Le z est recalé au sol par le trace client.
		["hueco_mundo_v1"] = {
			-- 4 zones repositionnées (setpos user 08/11, pris en vol : le z est
			-- recalé au sol par StationAnchor).
			{ pos = Vector(-11650.14, -1463.52, 6472.72), yaw = -179.59 },
			{ pos = Vector(-11117.86, -1508.08, 6472.72), yaw = -0.73 },
			{ pos = Vector(-11133.00, -1999.96, 6472.46), yaw = 1.51 },
			{ pos = Vector(-11663.85, -2120.80, 6472.72), yaw = -177.61 },
			-- Setpos user 08/11 (2 zones supplémentaires).
			{ pos = Vector(-11603.15, -1171.03, 6379.73), yaw = -6.83 },
			{ pos = Vector(-11111.02, -1060.28, 6407.56), yaw = 4.53 },
			-- 3 zones d'ordre (repositionnées user 08/22 : assassin / combat /
			-- médecin — remplacent les 3 du 08/12).
			{ pos = Vector(8992.364258, 372.081696, 6732.480957), yaw = -89.616325 },
			{ pos = Vector(4512.625000, 6191.755859, 6865.959473), yaw = 1.476019 },
			{ pos = Vector(-14586.067383, 4492.036133, 6346.503418), yaw = 88.524094 },
		},
		["rp_seireitei_v1"] = {
			-- 7 zones (setpos user 08/11, 2e passe : anciennes positions remplacées ;
			-- prises en vol, le z est recalé au sol par StationAnchor).
			{ pos = Vector(-4083.16, -95.70, 14498.72), yaw = 93.70 },
			{ pos = Vector(-4915.14, -460.74, 14498.71), yaw = -87.05 },
			{ pos = Vector(-5690.84, -470.85, 14498.72), yaw = -91.80 },
			{ pos = Vector(-4987.88, -632.28, 14498.72), yaw = 88.68 },
			{ pos = Vector(-4624.66, 576.91, 14498.71), yaw = 88.68 },
			{ pos = Vector(5677.28, 9751.26, 15106.72), yaw = -4.87 },
			{ pos = Vector(5676.93, 9597.38, 15106.72), yaw = 4.37 },
			-- 4 zones ajoutées (setpos user 08\12). Le z est ~14000 en dessous des
			-- 7 précédentes : ce sont les 4 coins d'une autre partie de la map.
			{ pos = Vector(5883.50, -10557.19, 541.97), yaw = -90.97 },
			{ pos = Vector(-8255.34, -6941.15, 641.71), yaw = 90.66 },
			{ pos = Vector(-14274.04, 11655.41, 596.97), yaw = 97.26 },
			{ pos = Vector(5767.97, 14863.86, 598.62), yaw = 0.11 },
			-- Zone ajoutée (setpos user 08\15), avec son étagère décor (cf. CFG.Decor).
			{ pos = Vector(12487.31, 14651.50, 15455.72), yaw = 2.34 },
		},
		-- gm_construct : 2 bibliothèques de TEST, une par faction (`fac` surcharge
		-- la faction de map, qui n'existe pas ici). Positions reprises des postes
		-- d'analyse evo_science, déjà éprouvées : coin de test près du spawn et
		-- plaine à l'écart. Le z est de toute façon recalé au sol par StationAnchor.
		["gm_construct"] = {
			{ pos = Vector(-620, 924, -148), yaw = 0, radius = 120, fac = "Shinigami" },
			{ pos = Vector(1500, 1500, -60), yaw = 0, radius = 120, fac = "Hollow" },
		},
	},

	-- DÉCOR posé par le serveur au boot (prop_dynamic, PAR MAP) : habille les
	-- zones Archives. pos = setpos BRUT, le z est recalé au sol par StationAnchor
	-- comme les zones. yaw BRUT du setang (règle projet : jamais de +180 magique).
	Decor = {
		["rp_seireitei_v1"] = {
			{ model = "models/echoes/env/sm_b_012_bookshelf_01a.mdl",
				pos = Vector(12487.31, 14651.50, 15455.72), yaw = 2.34 },
		},
	},

	-- Faction de chaque BIBLIOTHÈQUE : les archives ne sont PAS partagées entre
	-- factions (demande user). La liste affichée dans une zone = les livres de
	-- CETTE bibliothèque, et y ranger un livre le classe dans SA faction.
	-- Défaut par map, surchargeable par station avec fac = "Hollow"/"Shinigami".
	StationFaction = {
		["hueco_mundo_v1"]  = "Hollow",
		["rp_seireitei_v1"] = "Shinigami",
	},
}

-- L'instance est autoritaire côté serveur. Le NW ne sert qu'au rendu client.
function EVO_LIVRE.DomaineClanKey(ply)
	if not (IsValid(ply) and ply:IsPlayer() and EVO_CLAN and EVO_CLAN.IsDomaineZone) then return nil end
	local zone
	if SERVER then
		zone = NCM_INSTANCE and NCM_INSTANCE.GetZoneID and NCM_INSTANCE.GetZoneID(ply)
	else
		zone = ply:GetEvoNWString("NCM_InstanceZone", "")
	end
	if not EVO_CLAN.IsDomaineZone(zone or "") then return nil end
	return string.sub(zone, #"clan_dom_" + 1)
end

function EVO_LIVRE.IsClanMember(ply, clan_key)
	return IsValid(ply) and ply:IsPlayer() and clan_key ~= "" and clan_key ~= nil
		and ply:GetEvoNWString("EVO_ClanKey", "") == clan_key
end

--- CHEF de clan (ou son BRAS DROIT) du clan `clan_key`. NW posés par le serveur
--- d'evo_clan depuis la BDD (SyncPlayerClan), jamais par le client — même source que
--- sv_domaine. Il GÈRE LES ARCHIVES DE SON CLAN (user 09/15) : retirer, supprimer,
--- réécrire et re-ranger ses documents sans grade de faction. Aucun droit ailleurs.
function EVO_LIVRE.IsClanBoss(ply, clan_key)
	if not EVO_LIVRE.IsClanMember(ply, clan_key) then return false end
	return ply:GetEvoNWBool("EVO_ClanLeader", false) == true
		or ply:GetEvoNWBool("EVO_ClanOfficer", false) == true
end

--- Chef de clan POUR CE LIVRE : document d'un clan (ck) dont il est le chef.
function EVO_LIVRE.IsClanBossOf(ply, e)
	return istable(e) and (e.ck or "") ~= "" and EVO_LIVRE.IsClanBoss(ply, e.ck)
end

--- Le joueur se tient dans la station d'archives de SON clan ET en est le chef.
function EVO_LIVRE.ManagesCurrentClanArchive(ply)
	local clan_key = EVO_LIVRE.CurrentArchiveClan(ply)
	return clan_key ~= "" and EVO_LIVRE.IsClanBoss(ply, clan_key)
end

local clan_stations = {}
local no_stations = {}
function EVO_LIVRE.StationList(ply)
	if CLIENT and not IsValid(ply) then ply = LocalPlayer() end
	local clan_key = EVO_LIVRE.DomaineClanKey(ply)
	if clan_key ~= nil then
		-- Un invité au domaine ne voit ni cette station ni les archives du monde.
		if not EVO_LIVRE.IsClanMember(ply, clan_key) then return no_stations end
		local poses = EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses[game.GetMap()]
		local pose = poses and poses.archive
		if not pose then return no_stations end
		local cached = clan_stations[clan_key]
		if not cached or cached.pose ~= pose then
			cached = { pose = pose, { pos = pose.pos, yaw = pose.ang.y, clan_key = clan_key } }
			clan_stations[clan_key] = cached
		end
		return cached
	end
	return (EVO_LIVRE.CFG.Stations or {})[game.GetMap()] or {}
end

-- Ancrage AU SOL, PARTAGÉ client/serveur : les setpos de la config peuvent avoir
-- été pris en vol/noclip (z au-dessus du sol). Le rendu ET le check du cylindre
-- doivent utiliser le MÊME z ancré, sinon des zones s'affichent au sol mais la
-- touche E (et les gates serveur Print/Archive) refusent (bug « 2 zones sur 4 »).
local tAnchors = {}
function EVO_LIVRE.InvalidateAnchors()
	tAnchors = {}
	clan_stations = {}
end
function EVO_LIVRE.StationAnchor(st)
	local a = tAnchors[st]
	if a then return a end
	local tr = util.TraceLine({
		start = st.pos + Vector(0, 0, 30),
		endpos = st.pos - Vector(0, 0, 1000),
		mask = MASK_SOLID_BRUSHONLY,
	})
	a = tr.Hit and tr.HitPos or st.pos
	tAnchors[st] = a
	return a
end

-- Cylindre comme les postes evo_science : distance horizontale < rayon, dz mesuré
-- contre le z ANCRÉ (pas le z brut du setpos). Retourne la STATION (pour sa
-- faction de bibliothèque), nil hors zone.
function EVO_LIVRE.CurrentStation(ply)
	if not IsValid(ply) then return nil end
	local p = ply:GetPos()
	for _, st in ipairs(EVO_LIVRE.StationList(ply)) do
		local r = st.radius or EVO_LIVRE.CFG.StationRadius or 90
		local dx, dy = p.x - st.pos.x, p.y - st.pos.y
		if dx * dx + dy * dy <= r * r and math.abs(p.z - EVO_LIVRE.StationAnchor(st).z) <= 160 then
			return st
		end
	end
	return nil
end

function EVO_LIVRE.IsInStation(ply)
	return EVO_LIVRE.CurrentStation(ply) ~= nil
end

-- Retourne exclusivement le clan de la station où le joueur se tient réellement.
function EVO_LIVRE.CurrentArchiveClan(ply)
	local station = EVO_LIVRE.CurrentStation(ply)
	return station and station.clan_key or ""
end

function EVO_LIVRE.BookMatchesStation(ply, entry)
	local station = EVO_LIVRE.CurrentStation(ply)
	if not station then return false end
	local clan_key = entry.ck or ""
	if (station.clan_key or "") ~= clan_key then return false end
	if clan_key ~= "" then return EVO_LIVRE.IsClanMember(ply, clan_key) end
	return (entry.fa or "") == "" or entry.fa == EVO_LIVRE.StationFaction(station)
end

-- Faction de la bibliothèque d'une station : override par station (st.fac),
-- sinon défaut de la map.
function EVO_LIVRE.StationFaction(st)
	return (st and st.fac) or (EVO_LIVRE.CFG.StationFaction or {})[game.GetMap()] or ""
end

-- Gradé : grade 10+ (NW FactionRank, pattern evo_fosse), toutes divisions, ou
-- SA. Peut RANGER dans un rayon de division et RETIRER les archives.
-- Écrire = détenir l'item ; imprimer et consulter = tout le monde.
function EVO_LIVRE.CanManage(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= (EVO_LIVRE.CFG.ManageMinRank or 10)
end

local function RankAtLeast(ply, n)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= n
end

--- SIGNER / dé-signer : descendu au grade du rayon Commune (demande user). Le
--- grade 10+ reste exigé pour RANGER ailleurs que dans Commune (CanFileIn), et
--- c'est lui le vrai garde-fou : un gradé 10+ pouvait de toute façon signer
--- lui-même le livre qu'il range.
function EVO_LIVRE.CanSign(ply)
	return RankAtLeast(ply, EVO_LIVRE.CFG.CommonMinRank or 2)
end

--- Ranger / déplacer une archive DANS ce rayon : Commune est ouverte aux 2+,
--- tous les autres rayons restent aux gradés 10+.
function EVO_LIVRE.CanFileIn(ply, sCat)
	if sCat == EVO_LIVRE.CFG.ClanCategory then
		-- Grade 2+, OU chef de clan dans les archives de SON clan (user 09/15).
		return EVO_LIVRE.CurrentArchiveClan(ply) ~= ""
			and (EVO_LIVRE.CanSign(ply) or EVO_LIVRE.ManagesCurrentClanArchive(ply))
	end
	if sCat == (EVO_LIVRE.CFG.CommonCategory or "commune") then return EVO_LIVRE.CanSign(ply) end
	return EVO_LIVRE.CanManage(ply)
end

--- Réécrire un livre DÉJÀ SIGNÉ sans retirer la signature : haut commandement
--- (15/16). La signature ne saute pas, elle passe à SON nom : elle endosse un
--- contenu, elle doit donc suivre celui qui le change.
function EVO_LIVRE.CanRewriteSigned(ply)
	return RankAtLeast(ply, EVO_LIVRE.CFG.RewriteMinRank or 15)
end

-- ── RAYONS ───────────────────────────────────────────────────────────────────
-- TOUT rayon est créé en jeu (plus aucun rayon de base). Cache partagé :
-- Tout l'accès se déduit du grade, de la division et d'un seul booléen
-- répliqué (invité au Secret défense) : le client applique EXACTEMENT la même
-- règle que le serveur, qui reste seul autoritaire.
-- ── RAYONS ───────────────────────────────────────────────────────────────────
-- Liste FIXE (CFG.Categories) : plus rien ne se crée en jeu. Chaque rayon est
-- adossé à une division ; « Secret défense » n'en a pas.
local _catById
local clan_category = { id = EVO_LIVRE.CFG.ClanCategory, name = "Clan", open = true }
local function CatById(sId)
	if sId == EVO_LIVRE.CFG.ClanCategory then return clan_category end
	if not _catById then
		_catById = {}
		for _, c in ipairs(EVO_LIVRE.CFG.Categories) do _catById[c.id] = c end
	end
	return _catById[sId]
end
EVO_LIVRE.CatById = CatById

function EVO_LIVRE.IsCategory(sId)
	return CatById(sId) ~= nil
end

--- Libellé d'un rayon ; une archive sans rayon valide (d'avant la refonte)
--- affiche « Non classé » plutôt qu'un id brut.
function EVO_LIVRE.CategoryName(sId)
	local c = CatById(sId)
	return (c and c.name) or EVO_LIVRE.CFG.UnclassifiedName or "Non classé"
end

--- Gradé 2+ de la Division 1 / Ordre 1 : voit TOUS les rayons de SA faction,
--- sauf le secret. Test par NOM de division d'abord (LZY_FACTION_CONFIG),
--- index en repli — même recette que evo_science IsScientist.
function EVO_LIVRE.IsCommandement(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	if (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) < (EVO_LIVRE.CFG.CommandementRank or 2) then
		return false
	end
	local fac = ply:GetEvoNWString("FactionName", "")
	if fac == "" then return false end
	local idx = ply:GetEvoNWInt("FactionDivision", 0)
	local want = (EVO_LIVRE.CFG.CommandementDivision or {})[fac]
	if want and istable(LZY_FACTION_CONFIG) and istable(LZY_FACTION_CONFIG.divisions) then
		local divs = LZY_FACTION_CONFIG.divisions[fac]
		if divs then return divs[idx] == want end
	end
	return idx == (EVO_LIVRE.CFG.CommandementDivisionIndex or 2)
end

function EVO_LIVRE.IsChef(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if ply:IsSuperAdmin() then return true end
	return (tonumber(ply:GetEvoNWInt("FactionRank", 0)) or 0) >= (EVO_LIVRE.CFG.ChefRank or 16)
end

--- Invité au rayon « Secret défense » ? Miroir NWBool posé par le serveur
--- depuis sa table ; le client ne peut pas se le donner tout seul, et chaque
--- net reste revalidé serveur contre la table.
function EVO_LIVRE.HasSecretAccess(ply)
	return IsValid(ply) and ply:GetEvoNWBool("EVO_LivreHabilite", false) == true
end

--- PORTE UNIQUE des rayons, identique client et serveur (tout est déductible
--- du grade, de la division et d'un seul booléen répliqué) :
---   • Secret défense : chef de faction, ou personne qu'il y a invitée ;
---   • sinon Commandement (grade 2+, division idx 2) voit tout ;
---   • sinon on ne voit QUE le rayon de sa propre division.
--- ⚠️ La FACTION se teste à part, sur le livre : elle ne bouge jamais.
function EVO_LIVRE.CanSeeCategory(ply, sId)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if sId == EVO_LIVRE.CFG.ClanCategory then return EVO_LIVRE.CurrentArchiveClan(ply) ~= "" end
	if ply:IsSuperAdmin() then return true end
	local c = CatById(sId)
	if not c then return false end
	if c.id == (EVO_LIVRE.CFG.SecretCategory or "secret") then
		return EVO_LIVRE.IsChef(ply) or EVO_LIVRE.HasSecretAccess(ply)
	end
	if c.open then return true end
	if EVO_LIVRE.IsCommandement(ply) then return true end
	return ply:GetEvoNWInt("FactionDivision", 0) == c.div
end

--- Rayons que ce joueur peut ouvrir, dans l'ordre de la config.
function EVO_LIVRE.CategoriesFor(ply)
	if EVO_LIVRE.CurrentArchiveClan(ply) ~= "" then
		return { { id = EVO_LIVRE.CFG.ClanCategory, name = "Clan", open = true } }
	end
	local out = {}
	for _, c in ipairs(EVO_LIVRE.CFG.Categories) do
		if EVO_LIVRE.CanSeeCategory(ply, c.id) then
			out[#out + 1] = { id = c.id, name = c.name, open = c.open == true,
				secret = c.id == EVO_LIVRE.CFG.SecretCategory }
		end
	end
	return out
end

function EVO_LIVRE.SqlSafe(s)
	return (string.gsub(tostring(s or ""), "\\", ""))
end

-- Garde \n, retire \r et les caractères de contrôle, borne la longueur.
function EVO_LIVRE.CleanText(s, maxLen)
	s = tostring(s or "")
	s = string.gsub(s, "\r", "")
	s = string.gsub(s, "[%z\1-\9\11-\31]", "")
	if maxLen and #s > maxLen then s = string.sub(s, 1, maxLen) end
	return s
end

-- Nettoie/borne un livre {title, pages = {{t}}} : TEXTE SEUL (les images ont
-- été retirées du système ; un vieux livre qui en portait les perd au prochain
-- enregistrement, le lecteur les ignore de toute façon). Retourne nil si
-- structure invalide. Appelé des DEUX côtés (client avant envoi, serveur avant
-- écriture) comme EVO_CARTE.SanitizeStrokes.
function EVO_LIVRE.SanitizeBook(t)
	if not istable(t) then return nil end
	local cfg = EVO_LIVRE.CFG
	local out = {
		-- Titre MONOLIGNE (les couvertures n'affichent qu'une ligne).
		title = string.gsub(EVO_LIVRE.CleanText(t.title, cfg.MaxTitleLen), "\n", " "),
		pages = {},
	}
	if not istable(t.pages) then return nil end
	for i = 1, math.min(#t.pages, cfg.MaxPages) do
		local p = t.pages[i]
		if not istable(p) then break end
		out.pages[#out.pages + 1] = { t = EVO_LIVRE.CleanText(p.t, cfg.MaxTextLen) }
	end
	if #out.pages == 0 then out.pages[1] = { t = "" } end
	return out
end

-- ── ITEMS ───────────────────────────────────────────────────────────────────
-- L'addon inventory RÉ-ASSIGNE la table ITEMS à son include : enregistrement au
-- RUNTIME avec retry (pattern evo_note), jamais au chargement du fichier.

-- Modèle ANIMÉ du livre (séquences : idle = fermé, open = ouverture,
-- idle_open = ouvert, close = fermeture). Sert de preview 3D dans l'inventaire
-- (LZY_INVENTORY_ITEM_PREVIEW suit model_path), de modèle au sol (drop) et
-- d'animation d'ouverture/fermeture du lecteur (cl_livre PlayBookAnim).
local BOOK_MODEL = "models/evo/props/items/evo_sfxzlfig52qsgd/evo_sfxzlfig52qsgd.mdl"

--- Id d'item d'un livre BDD (legacy). Les rows actuelles utilisent WrittenItemId.
function EVO_LIVRE.BookItemId(id)
	return EVO_LIVRE.CFG.BookPrefix .. tostring(id)
end

--- Id BDD depuis un id d'item, nil si l'item n'est pas un livre dynamique
--- ("livre_lore" legacy ne matche pas le %d+, c'est voulu).
function EVO_LIVRE.BookIdFromItem(sItemId)
	return tonumber(string.match(tostring(sItemId or ""), "^" .. EVO_LIVRE.CFG.BookPrefix .. "(%d+)$"))
end

EVO_LIVRE.ItemMeta = EVO_LIVRE.ItemMeta or {}

local function bookMeta(key)
	local n = tonumber(key)
	return EVO_LIVRE.ItemMeta[n] or EVO_LIVRE.ItemMeta[tostring(key or "")]
end

local function bookRestricted(t)
	if not t then return false end
	local bMasked = t.mk == true or t.mk == 1
	return bMasked or t.ca == (EVO_LIVRE.CFG.SecretCategory or "secret")
end

local function bookDesc(t)
	if not t then return "Un livre. Clic droit > Utiliser pour le lire." end
	local nAr = tonumber(t.ar) or 0
	local sAuthor = (t.au and t.au ~= "") and t.au or "?"
	local bMasked = t.mk == true or t.mk == 1
	if bMasked then
		return "Document classifié des archives.\nTu n'as pas accès au rayon dans lequel il est rangé."
	elseif nAr == 0 then
		return "Livre de " .. sAuthor .. ".\nClic droit > Utiliser pour le lire ou l'écrire."
			.. "\nFais-le signer par un gradé " .. (EVO_LIVRE.CFG.CommonMinRank or 2)
			.. "+, qui pourra ensuite le ranger dans une zone Archives."
	end
	return "Archive du serveur, écrite par " .. sAuthor .. ".\nClic droit > Utiliser pour la lire."
		.. "\nRayon : " .. EVO_LIVRE.CategoryName(t.ca)
end

function EVO_LIVRE.RegisterWrittenItem()
	if not istable(ITEMS) then return false end
	ITEMS[EVO_LIVRE.CFG.WrittenItemId] = {
		name        = "Livre",
		description = "Un livre. Clic droit > Utiliser pour le lire.",
		category    = "object",
		rarity      = "epic",
		model_path  = BOOK_MODEL,
		preview_static = true,
		model_margin = 0.9,
		preview_shift_left = 0.24,
		preview_focus_up = 0.35,
		is_droppable = true,
		is_deletable = true,
		bDocumentItem = true, -- document RP : un perso animation peut le jeter (gate inventory net.lua)
		requires_instance_key = true,
		instance_name = function(key)
			local t = bookMeta(key)
			if not t then return "Livre" end
			if t.mk == true or t.mk == 1 then return "Archive classifiée" end
			return (t.ti and t.ti ~= "") and t.ti or "Sans titre"
		end,
		instance_description = function(key)
			return bookDesc(bookMeta(key))
		end,
		instance_droppable = function(key)
			return not bookRestricted(bookMeta(key))
		end,
		on_use = CLIENT and function(_, slot)
			local inv = LocalPlayer().GetInventory and LocalPlayer():GetInventory()
			local key = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, slot)
			local id = tonumber(key)
			if id and EVO_LIVRE.OpenBook then EVO_LIVRE.OpenBook(id) end
		end or function() end,
	}
	return true
end

--- Enregistre (ou met à jour) les métadonnées d'affichage d'un livre.
--- t = { id, ti (titre), au (auteur), ar (0 brouillon / 1 archivé / 2 retiré),
--- ca (rayon), mk (entrée caviardée) }.
function EVO_LIVRE.RegisterBookItem(t)
	if not istable(t) then return false end
	local id = tonumber(t.id)
	if not id or id < 1 then return false end
	EVO_LIVRE.ItemMeta[id] = t
	return EVO_LIVRE.RegisterWrittenItem()
end

function EVO_LIVRE.RegisterItem()
	if not istable(ITEMS) then return false end
	-- LE livre (vendu au Urahara Shop) : l'utiliser crée TON livre (ligne BDD
	-- + item livre_<id>) et ouvre l'éditeur. Conversion 100% serveur.
	-- (L'ancien item générique « livre_lore » n'existe plus : purgé au boot.)
	ITEMS[EVO_LIVRE.CFG.BlankItemId] = {
		name        = "Livre",
		description = "Un livre aux pages blanches.\nClic droit > Utiliser pour commencer à l'écrire : il devient TON livre.",
		category    = "object",
		rarity      = "rare",
		model_path  = BOOK_MODEL,
		-- Case d'inventaire (demande user) : FIGÉ, plus zoomé et plus bas.
		preview_static = true,
		model_margin = 0.9,
		preview_shift_left = 0.24,
		preview_focus_up = 0.35,
		is_droppable = true,
		is_deletable = true,
		bDocumentItem = true,
		stack_max   = 64,
		on_use = SERVER and function(ply)
			if EVO_LIVRE.UseBlank then EVO_LIVRE.UseBlank(ply) end
		end or function() end,
	}
	return EVO_LIVRE.RegisterWrittenItem()
end

-- GARDIEN permanent (et pas 30 essais puis mort) : si un refresh Lua ré-assigne
-- la table ITEMS après coup, les items disparaissaient de l'inventaire À L'ÉCRAN
-- (cases vides) jusqu'au restart. Coût nul : un test de présence par période.
timer.Create("EVO_Livre_RegisterItem", 2, 0, function()
	if not istable(ITEMS) then return end
	if not ITEMS[EVO_LIVRE.CFG.BlankItemId] then EVO_LIVRE.RegisterItem() end
	if not ITEMS[EVO_LIVRE.CFG.WrittenItemId] then EVO_LIVRE.RegisterWrittenItem() end
end)
