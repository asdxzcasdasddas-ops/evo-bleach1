-- "addons\\evo_livre\\lua\\evo_livre\\cl_livre.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Archives, client : bibliothèque des archives (couvertures), lecteur = VRAI
-- livre DHTML (couverture qui s'ouvre, tourne-page animé, numéros de page),
-- éditeur VGUI (texte DTextEntry). Chaque livre est un ITEM dynamique
-- livre_<id> (registre poussé par le serveur, nom d'item = titre du livre).
-- Les IMAGES ont été RETIRÉES du système (demande user 08/11) : texte seul.

if not CLIENT then return end

EVO_LIVRE = EVO_LIVRE or {}
local CFG = EVO_LIVRE.CFG

local ACCENT    = Color(207, 68, 78)
local COL_GOLD  = Color(216, 185, 106)
local COL_TITLE = Color(238, 239, 243)
local COL_MUTED = Color(150, 154, 162)
local COL_PAPER = Color(240, 232, 214)
local COL_INK   = Color(45, 38, 30)

local SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"
local SND_PAGE  = "physics/cardboard/cardboard_box_impact_soft2.wav"
-- Mêmes sons que le livre de la gestion faction (lzy_faction soundsData).
local SND_BOOK_OPEN  = "hnztk71178zj/5zo1hwzpkxdtckv3.ogg"
local SND_BOOK_CLOSE = "hnztk71178zj/2mok7z21c6op24.ogg"

-- Polices papier (Georgia = police système, dispo dans VGUI). 22 -> 18 en même
-- temps que le lecteur (950 -> 1200 caractères par page) : l'éditeur garde une
-- densité proche de la page finale.
local function fs(n) return math.max(12, math.Round(n * (ScrH() / 1080))) end
surface.CreateFont("EVOLivre_Text",   { font = "Georgia", size = fs(18), weight = 500, antialias = true })
surface.CreateFont("EVOLivre_Title",  { font = "Georgia", size = fs(30), weight = 700, antialias = true })

local function Notify(msg)
	chat.AddText(ACCENT, "[Archives] ", color_white, msg)
end

-- ============================================================================
-- REGISTRE DES LIVRES (poussé par le serveur) : [id] = { id, ti, au, ar }.
-- Sert à enregistrer les items dynamiques livre_<id> côté client (nom = titre)
-- et à savoir quels livres détenus sont encore des brouillons (ar = 0).
-- ============================================================================
local tRegistry = {}
local bRegistryReceived = false

local function RegisterRegistryItems()
	if not istable(ITEMS) then return false end
	for id, e in pairs(tRegistry) do
		EVO_LIVRE.RegisterBookItem(e)
	end
	return EVO_LIVRE.RegisterWrittenItem()
end

net.Receive("EVO:Livre:Items", function()
	local nLen = net.ReadUInt(32)
	local sJson = util.Decompress(net.ReadData(nLen), 200000)
	local arr = util.JSONToTable(sJson or "[]") or {}
	tRegistry = {}
	for _, e in ipairs(arr) do
		local id = tonumber(e.id)
		if id and id > 0 then
			-- mk = entrée CAVIARDÉE par le serveur (pas accès au rayon) : le titre
			-- est un placeholder, et ni la catégorie ni le niveau ne sont transmis.
			tRegistry[id] = {
				id = id,
				ti = tostring(e.ti or ""),
				au = tostring(e.au or ""),
				ar = tonumber(e.ar) or 1,
				si = tostring(e.si or ""),
				ca = e.ca and tostring(e.ca) or nil,
				ck = tostring(e.ck or ""),
				sc = tonumber(e.sc) or 0,
				mk = e.mk == 1 or e.mk == true,
			}
		end
	end
	bRegistryReceived = true
	-- Re-registre FORCÉ (pas RegisterRegistryItems : lui ne comble que les items
	-- MANQUANTS pour le gardien) : un titre renommé doit ÉCRASER l'entrée ITEMS
	-- existante, sinon l'inventaire garde l'ancien nom jusqu'à reconnexion.
	-- ITEMS peut ne pas encore exister (ré-assignée par inventory) : le timer
	-- gardien repassera.
	if istable(ITEMS) then
		for _, e in pairs(tRegistry) do EVO_LIVRE.RegisterBookItem(e) end
	end
end)

-- GARDIEN permanent (et pas 30 essais puis mort) : redemande le registre tant
-- qu'il n'est pas arrivé (le serveur peut être en plein rechargement), puis
-- ré-enregistre tout item dynamique manquant si un refresh Lua a ré-assigné
-- ITEMS. Sans lui, les livres devenaient des cases vides « supprimées » à
-- l'écran jusqu'au restart.
timer.Create("EVO_Livre_RegItemsCl", 2, 0, function()
	if not bRegistryReceived then
		net.Start("EVO:Livre:ItemsReq")
		net.SendToServer()
		return
	end
	RegisterRegistryItems()
end)

--- Détient-on l'item de CE livre (sac ou équipé) ?
local function HasBookItem(id)
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp.GetInventory then return false end
	local inv = lp:GetInventory()
	local want = EVO_LIVRE.CFG.WrittenItemId
	local key = tostring(id)
	local legacy = EVO_LIVRE.BookItemId(id)
	for i, iid in pairs(inv.items or {}) do
		if iid == legacy then return true end
		if iid == want then
			local k = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, i)
			if k == key then return true end
		end
	end
	for i, iid in pairs(inv.equipped_items or {}) do
		if iid == legacy then return true end
		if iid == want then
			local k = INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, i)
			if k == key then return true end
		end
	end
	return false
end

--- Brouillons (livres pas encore archivés) détenus, dédupliqués par id.
local function PersonalBooksHeld()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp.GetInventory then return {} end
	local inv = lp:GetInventory()
	local out, seen = {}, {}
	local clan_key = EVO_LIVRE.CurrentArchiveClan(lp)
	local function scan(t)
		for i, iid in pairs(t or {}) do
			local id = EVO_LIVRE.BookIdFromItem(iid)
			if not id and iid == EVO_LIVRE.CFG.WrittenItemId then
				id = tonumber(INVENTORY_CONFIG.GetSlotInstanceKey and INVENTORY_CONFIG.GetSlotInstanceKey(inv, i))
			end
			if id and not seen[id] and tRegistry[id] and tRegistry[id].ar == 0
				and not tRegistry[id].mk and ((tRegistry[id].ck or "") == "" or tRegistry[id].ck == clan_key) then
				seen[id] = true
				out[#out + 1] = tRegistry[id]
			end
		end
	end
	scan(inv.items)
	scan(inv.equipped_items)
	return out
end

-- « Sans titre » n'est jamais un vrai titre : il s'affiche en FANTÔME (translucide),
-- jamais en dur (demande user). Couvre aussi les anciens livres où le placeholder
-- avait été STOCKÉ en BDD.
local function IsGhostTitle(ti)
	return ti == nil or ti == "" or ti == "Sans titre"
end

local function jsEsc(s)
	s = string.gsub(tostring(s or ""), "[\r\n]", " ")
	return (string.gsub(s, "[\\'\"]", "\\%0"))
end

local function tpl(html, map)
	return (string.gsub(html, "{{(%w+)}}", map))
end

-- ============================================================================
-- ÉTAT / NAVIGATION ENTRE VUES
-- ============================================================================
local frame
local tList = {}
local sPendingMode = nil -- "read" | "edit" : intention posée avant EVO:Livre:Get

local function freshContent()
	if not IsValid(frame) then return nil end
	if IsValid(frame._content) then frame._content:Remove() end
	local c = vgui.Create("DPanel", frame)
	c:SetSize(frame:GetWide(), frame:GetTall())
	c:SetPos(0, 0)
	c.Paint = function() end
	frame._content = c
	return c
end

local CloseBookWithAnim
local closingBookVisual

local function makeFrame()
	-- Un calque de fermeture encore en cours (reouverture rapide) est retire.
	if IsValid(closingBookVisual) then closingBookVisual:Remove() end
	if IsValid(frame) then frame:Remove() end
	-- DFrame et pas DPanel (pattern evo_note makeBackdrop) : un DPanel MakePopup
	-- ne redonne pas le focus clavier aux DTextEntry quand un autre popup vient
	-- de se fermer (l'inventaire se ferme juste APRÈS l'on_use) -> titre muet.
	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:SetPaintBackgroundEnabled(false)
	frame:MakePopup()
	frame.Paint = function(s, w, h)
		rRect(0, 0, 1920, 1080, color_white, 0, RNDX.BLUR)
		rRect(0, 0, 1920, 1080, Color(8, 7, 6, 225))
	end
	if EVO_MakeEscClosable then
		EVO_MakeEscClosable(frame)
	else
		openedFrame = frame
		frame.OnRemove = function(s) if openedFrame == s then openedFrame = nil end end
	end
	-- Filet : quelle que soit la sortie (Échap compris), l'anim de lecture du
	-- joueur s'arrête côté serveur si elle avait démarré.
	local fPrevRemove = frame.OnRemove
	frame.OnRemove = function(s)
		if fPrevRemove then fPrevRemove(s) end
		if s._readAnim then
			s._readAnim = nil
			net.Start("EVO:Livre:ReadStop")
			net.SendToServer()
		end
	end
	-- FERMETURE ANIMEE (portage evo-ds 09/06) : un livre ouvert se REFERME avant de
	-- disparaitre, quelle que soit la sortie (Echap passe par Close). La bibliotheque
	-- seule (aucun livre ouvert) se ferme sec, comme avant.
	frame.Close = function(s)
		if s._readAnim or s._bookAnimation then
			CloseBookWithAnim(function() if IsValid(s) then s:Remove() end end)
		else
			s:Remove()
		end
	end
	return frame
end

local function RequestBook(id, mode)
	sPendingMode = mode
	net.Start("EVO:Livre:Get")
		net.WriteUInt(id, 32)
	net.SendToServer()
end

-- ============================================================================
-- ANIMATION DU LIVRE — COUVERTURE PEINTE (portee d'evo-ds le 09/06, aucun modele :
-- cuir / papier / bronze dessines en 2D, la couverture pivote via DrawPoly).
-- Meme principe que le livre de la gestion faction : l'animation joue AVANT l'UI
-- (ouverture) et APRES (fermeture, sur un calque qui survit au cadre).
-- Les noms de sequences (open / idle_open / close / idle) sont conserves comme
-- simples etiquettes : seul `closing` compte.
-- ============================================================================
local archiveCoverFontSize
-- Same geometry and materials as the live reader; no model download needed.
local function PaintArchiveBook(w, h, phase)
    local scale = math.min(w / 1160, h / 836)
    local ox, oy = (w - 1160 * scale) / 2, (h - 836 * scale) / 2
    local eased = phase * phase * (3 - 2 * phase)
    local hinge = ox + (580 - 270 * (1 - eased)) * scale
    local y, pw, ph = oy + 62 * scale, 540 * scale, 740 * scale
    local leather, bronze, paper = Color(69, 24, 35), Color(169, 133, 78), Color(239, 223, 191)
    if phase > 0 then
        draw.RoundedBox(8 * scale, hinge - 5 * scale, y - 8 * scale, pw + 13 * scale, ph + 16 * scale, leather)
        draw.RoundedBox(4 * scale, hinge, y, pw, ph, paper)
        surface.SetDrawColor(186, 162, 119)
        surface.DrawOutlinedRect(hinge + 18 * scale, y + 18 * scale, pw - 36 * scale, ph - 36 * scale)
    end
    local edge = math.cos(eased * math.pi) * pw
    local lift = math.sin(eased * math.pi) * 18 * scale
    draw.NoTexture()
    surface.SetDrawColor(edge >= 0 and leather or paper)
    surface.DrawPoly(edge >= 0 and {
        {x=hinge,y=y}, {x=hinge+edge,y=y-lift}, {x=hinge+edge,y=y+ph+lift}, {x=hinge,y=y+ph}
    } or {
        {x=hinge+edge,y=y-lift}, {x=hinge,y=y}, {x=hinge,y=y+ph}, {x=hinge+edge,y=y+ph+lift}
    })
    surface.SetDrawColor(bronze)
    surface.DrawLine(hinge+edge,y-lift,hinge+edge,y+ph+lift)
    if phase == 0 then
        for _, inset in ipairs({12, 24}) do
            surface.DrawOutlinedRect(hinge+inset*scale,y+inset*scale,pw-inset*2*scale,ph-inset*2*scale)
        end
        local fontSize = math.max(14, math.floor(28 * scale))
        if archiveCoverFontSize ~= fontSize then
            archiveCoverFontSize = fontSize
            surface.CreateFont("EVO:Archive:Cover", {font="Georgia",size=fontSize,weight=500,extended=true})
        end
        draw.SimpleText("ARCHIVES", "EVO:Archive:Cover",hinge+pw/2,y+ph*.42,bronze,TEXT_ALIGN_CENTER)
        draw.SimpleText("◇", "EVO:Archive:Cover",hinge+pw/2,y+ph*.55,bronze,TEXT_ALIGN_CENTER)
    end
end

local function PlayBookAnim(sSeq, sHold, fDone)
    local owner = frame
    local closing = sSeq == "close"
    local c
    if closing then
        if IsValid(closingBookVisual) then closingBookVisual:Remove() end
        c = vgui.Create("DPanel")
        c:SetSize(owner:GetSize())
        c:SetPos(owner:GetPos())
        c:SetZPos(32760)
        c:SetMouseInputEnabled(false)
        c:SetKeyboardInputEnabled(false)
        closingBookVisual = c
        if IsValid(owner._content) then owner._content:SetVisible(false) end
    else
        c = freshContent()
    end
    if not IsValid(c) then return end
    c._view = "bookanim"
    local started = SysTime()
    local hold, duration = .18, .78
    owner._bookAnimation = c
    c.Paint = function(_, w, h)
        local p = math.Clamp((SysTime() - started - (closing and 0 or hold)) / duration, 0, 1)
        PaintArchiveBook(w, h, closing and (1 - p) or p)
    end
    timer.Simple(duration + hold, function()
        if not IsValid(c) then return end
        if closing then c:Remove() end
        if not IsValid(owner) or frame ~= owner then return end
        if not closing and owner._content ~= c then return end
        owner._bookAnimation = nil
        if fDone then fDone() end
    end)
end


--- Fin d'anim d'ouverture : affiche le livre arrivé PENDANT l'animation (ou
--- arme le passage direct si les données arrivent après).
local function TryShowPendingBook()
	if not IsValid(frame) then return end
	frame._animDone = true
	local p = frame._pendingBook
	frame._pendingBook = nil
	if not p then return end
	if p.edit then EVO_LIVRE.ShowEditor(p.book) else EVO_LIVRE.ShowReader(p.book) end
end

--- Lance l'ouverture animée : le livre 3D s'ouvre (puis tient idle_open) pendant
--- que les données du livre voyagent ; le lecteur/éditeur s'affiche quand LES
--- DEUX sont prêts.
local function BeginBookOpen()
	if not IsValid(frame) then return end
	frame._animDone = false
	frame._pendingBook = nil
	-- Le JOUEUR se met à lire (recette gestion faction) : gel + anim de lecture
	-- + livre 3D ouvert dans les mains, pour tous ceux qui le regardent.
	frame._readAnim = true
	net.Start("EVO:Livre:ReadStart")
	net.SendToServer()
	surface.PlaySound(SND_BOOK_OPEN)
	PlayBookAnim("open", "idle_open", TryShowPendingBook)
end

local function SendReadStop()
	if IsValid(frame) and frame._readAnim then
		frame._readAnim = nil
		net.Start("EVO:Livre:ReadStop")
		net.SendToServer()
	end
end

--- Fermeture animée puis suite (retour bibliothèque ou fermeture du cadre).
CloseBookWithAnim = function(fAfter)
	if not IsValid(frame) or frame._closingBook then return end
	local owner = frame
	owner._closingBook = true
	owner._pendingBook = nil
	SendReadStop()
	surface.PlaySound(SND_BOOK_CLOSE)
	PlayBookAnim("close", "idle", function()
		owner._closingBook = nil
		if fAfter then fAfter() end
	end)
end

--- Bibliothèque des archives. bInZone : ouvre depuis une zone au sol (les
--- boutons IMPRIMER / RANGER n'apparaissent que là, revalidés serveur).
function EVO_LIVRE.Open(bInZone)
	makeFrame()
	frame._inZone = bInZone == true
	tList = {} -- pas de flash de l'ancienne bibliothèque lors d'un changement de domaine
	EVO_LIVRE.ShowLibrary()
	net.Start("EVO:Livre:List")
	net.SendToServer()
end

--- Ouvre UN livre depuis son item (clic droit > Utiliser) ou après création.
--- L'anim 3D d'ouverture joue PENDANT que les données voyagent.
function EVO_LIVRE.OpenBook(id, bEdit)
	id = tonumber(id) or 0
	if id < 1 then return end
	makeFrame()
	frame._fromItem = true
	BeginBookOpen()
	RequestBook(id, bEdit and "edit" or "read")
end

net.Receive("EVO:Livre:OpenBook", function()
	local id = net.ReadUInt(32)
	local bEdit = net.ReadBool()
	EVO_LIVRE.OpenBook(id, bEdit)
end)

LZY_POPUP_CALLBACKS = LZY_POPUP_CALLBACKS or {}
LZY_POPUP_CALLBACKS.EvoLivre_Delete = function(args)
	if not args or not args.id then return end
	net.Start("EVO:Livre:Delete")
		net.WriteUInt(tonumber(args.id) or 0, 32)
	net.SendToServer()
end
-- SUPPRIMER un document des archives du CLAN (chef de clan, user 09/15).
LZY_POPUP_CALLBACKS.EvoLivre_Discard = function(args)
	if not args or not args.id then return end
	net.Start("EVO:Livre:Discard")
		net.WriteUInt(tonumber(args.id) or 0, 32)
	net.SendToServer()
end

-- ============================================================================
-- CLASSEMENT DES ARCHIVES : catégories + niveaux de confidentialité
-- ============================================================================
-- Filtre de rayon de la bibliotheque ("" = tous). Persiste entre ouvertures.
local sCatFilter = ""
-- Invites du Secret defense, recus par le chef de faction seulement.
local tSecretList = {}

--- Liste déroulante maison, DA du projet (jamais DermaMenu : look hors charte).
--- fLabel() -> texte affiché ; fGet() -> { {txt, val} } ; fSet(val) au clic.
--- tMenu (optionnel) = { parent, x, y } : où DÉPLOYER le menu. ⚠️ VGUI CLIPPE
--- les enfants au cadre du parent, en dessin ET en détection de clic : un menu
--- posé dans une petite carte devenait invisible et incliquable dès qu'il la
--- dépassait (les rayons créés et le niveau Secret défense étaient hors cadre).
--- Quand la liste peut être longue, passer un parent PLEIN ÉCRAN.
--- Fermeture de la liste actuellement ouverte, quelle qu'elle soit (une seule
--- à la fois dans toute l'UI).
local _openDrop
local function DropDown(parent, x, y, w, h, fLabel, fGet, fSet, tMenu)
	local ddl, catch
	local function closeDDL()
		if IsValid(ddl) then ddl:Remove() end
		if IsValid(catch) then catch:Remove() end
		ddl, catch = nil, nil
		if _openDrop == closeDDL then _openDrop = nil end
	end
	local b = gPanel(x, y, w, h, parent)
	b:SetCursor("hand")
	b.Paint = function(s)
		local hov = s.Hovered or IsValid(ddl)
		rRect(0, 0, w, h, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, hov and 55 or 25), 6)
		rOutlinedRect(0, 0, w, h, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, hov and 200 or 90), 6, 1)
		rSimpleText(fLabel(), "Bebas Neue:20", 16, h / 2, hov and color_white or COL_GOLD,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		rSimpleText(IsValid(ddl) and "▲" or "▼", "Bebas Neue:14", w - 20, h / 2 + 1,
			hov and color_white or COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		if IsValid(ddl) then closeDDL() return end
		-- Une seule liste ouverte à la fois : sans ça elles s'empilaient et il
		-- fallait re-cliquer sur chaque bouton pour les refermer une par une.
		if _openDrop then _openDrop() end
		local items = fGet()
		local rowH = 40
		local mp = (tMenu and IsValid(tMenu.parent)) and tMenu.parent or parent
		local mx = (tMenu and tMenu.x) or x
		local my = (tMenu and tMenu.y) or (y + h + 4)
		-- Borné à l'écran, puis TOUJOURS défilant : peu importe le nombre de
		-- rayons créés, la liste reste entièrement atteignable.
		local nFull = #items * rowH + 8
		local nH = math.max(rowH + 8, math.min(nFull, 1060 - my))
		-- VOILE cliquable derrière la liste (pattern maison evo_science
		-- openDropList) : n'importe quel clic à côté referme. Créé AVANT la
		-- liste pour rester dessous, et en pixels bruts pour couvrir tout le
		-- parent quelle que soit l'échelle.
		catch = vgui.Create("DButton", mp)
		catch:SetText("")
		catch:SetCursor("arrow")
		catch:SetSize(mp:GetWide(), mp:GetTall())
		catch:SetPos(0, 0)
		catch.Paint = function() end
		catch.DoClick = closeDDL
		ddl = gPanel(mx, my, w, nH, mp)
		_openDrop = closeDDL
		-- Le parent est reconstruit (rebuild de vue) : la liste orpheline part
		-- avec, mais le voile, lui, doit être nettoyé explicitement.
		ddl.OnRemove = function() if IsValid(catch) then catch:Remove() end end
		ddl.Paint = function(s, pw, ph)
			local pts = EVO_UI.PaintCut(0, 0, pw, ph, Color(14, 14, 17, 252), gRespY(10))
			if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 70)) end
		end
		local sc = vgui.Create("DScrollPanel", ddl)
		sc:gSetPos(4, 4)
		sc:gSetSize(w - 8, nH - 8)
		if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(sc) end
		local cv = vgui.Create("DPanel", sc)
		sc:AddItem(cv)
		cv:gSetSize(w - 8, #items * rowH)
		cv.Paint = function() end
		for i, it in ipairs(items) do
			local row = gPanel(0, (i - 1) * rowH, w - 8, rowH, cv)
			row:SetCursor("hand")
			row.Paint = function(s)
				if s.Hovered then rRect(2, 2, w - 12, rowH - 4, Color(ACCENT.r, ACCENT.g, ACCENT.b, 30), 4) end
				rSimpleText(it.txt, "Bebas Neue:20", 14, rowH / 2,
					s.Hovered and color_white or (it.col or COL_TITLE), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			row.OnMousePressed = function()
				surface.PlaySound(SND_CLICK)
				closeDDL()
				fSet(it.val)
			end
		end
		ddl:MoveToFront()
	end
	return b
end

--- Panneau de RANGEMENT / DÉPLACEMENT : on ne choisit plus qu'un RAYON, c'est
--- lui qui porte les droits. Seuls les rayons auxquels on a accès sont
--- proposés (le serveur ne nous envoie même pas les autres).
--- Panneau de RANGEMENT / DÉPLACEMENT : on ne choisit qu'un RAYON parmi ceux
--- auxquels on a accès (liste fixe, déduite du grade et de la division).
local function ShowClassifyPanel(c, entry, bFiling)
	local lp = LocalPlayer()
	local clan_archive = EVO_LIVRE.CurrentArchiveClan(lp) ~= ""
	-- RANGER : on ne propose que les rayons où l'on a le droit de DÉPOSER, sinon
	-- le serveur refuse et le joueur ne comprend pas pourquoi. DÉPLACER reste
	-- réservé aux gradés 10+, la liste complète y est donc légitime.
	-- Une archive du Secret défense ne SORT que par le chef (règle serveur) :
	-- proposer d'autres rayons serait promettre un déplacement toujours refusé.
	local bStuck = entry.ca == CFG.SecretCategory and not EVO_LIVRE.IsChef(lp)
	local tCats = {}
	for _, cat in ipairs(EVO_LIVRE.CategoriesFor(lp)) do
		local bOk = (not bFiling) or EVO_LIVRE.CanFileIn(lp, cat.id)
		if bStuck then bOk = cat.id == CFG.SecretCategory end
		if bOk then tCats[#tCats + 1] = cat end
	end
	local sCat = entry.ca or ""
	local bOffered = false
	for _, cat in ipairs(tCats) do
		if cat.id == sCat then bOffered = true break end
	end
	-- ⚠️ Le repli ne tombe JAMAIS sur le rayon OUVERT : Commune est visible de
	-- tous, donc tCats[1] valait « Commune » pour tout le monde et un RANGER sans
	-- toucher au menu publiait le livre à toute la faction. On retombe sur le
	-- rayon de sa propre division, comme avant l'ouverture du rayon commun.
	if not bOffered then
		sCat = ""
		for _, cat in ipairs(tCats) do
			if not cat.open and not cat.secret then sCat = cat.id break end
		end
		if sCat == "" then sCat = tCats[1] and tCats[1].id or "" end
	end

	local ov = gPanel(0, 0, 1920, 1080, c)
	ov.Paint = function() rRect(0, 0, 1920, 1080, Color(6, 6, 8, 200)) end
	ov.OnMousePressed = function() ov:Remove() end
	ov:MoveToFront()

	local card = gPanel(700, 380, 520, 320, ov)
	card.OnMousePressed = function() end -- absorbe le clic
	-- ⚠️ PaintCut travaille en PIXELS RÉELS : on prend w et h, jamais les
	-- constantes de design (la plaque se décalait de son contenu).
	card.Paint = function(s, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, Color(16, 16, 20, 252), gRespY(14))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 90)) end
		rSimpleText(bFiling and "RANGER AUX ARCHIVES" or "DÉPLACER L'ARCHIVE", "Bebas Neue:30",
			260, 44, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local bGhost = IsGhostTitle(entry.ti)
		rSimpleText(bGhost and "Sans titre" or entry.ti, "Avenir Next World:16", 260, 76,
			bGhost and Color(COL_TITLE.r, COL_TITLE.g, COL_TITLE.b, 90) or COL_TITLE,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rSimpleText("RAYON", "Bebas Neue:18", 40, 124, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local sHint = bStuck and "Seul le chef de faction peut sortir un document du Secret défense."
			or "Tu n'as accès à aucun rayon."
		if #tCats > 0 and not bStuck then
			local cSel
			for _, cat in ipairs(tCats) do
				if cat.id == sCat then cSel = cat break end
			end
			if clan_archive then
				sHint = "Seuls les membres de ton clan verront cette archive."
			elseif cSel and cSel.open then
				sHint = "Rayon ouvert : toute ta faction verra cette archive."
			elseif cSel and cSel.secret then
				sHint = "Seuls le chef de faction et ses invités verront cette archive."
			else
				sHint = "Seule ta division (et le Commandement) verra cette archive."
			end
		end
		rSimpleText(sHint, "Avenir Next World:13", 40, 216, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	DropDown(card, 40, 142, 440, 46, function()
		return sCat ~= "" and EVO_LIVRE.CategoryName(sCat) or "Aucun rayon"
	end, function()
		local t = {}
		for _, cat in ipairs(tCats) do
			t[#t + 1] = { txt = cat.name, val = cat.id, col = cat.secret and ACCENT or nil }
		end
		return t
	end, function(v) sCat = v end, { parent = ov, x = 740, y = 572 })

	local ok = gPanel(40, 246, 210, 46, card)
	ok:SetCursor("hand")
	ok.Paint = function(s)
		rRect(0, 0, 210, 46, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, s.Hovered and 70 or 30), 6)
		rSimpleText(bFiling and "RANGER" or "DÉPLACER", "Bebas Neue:22", 105, 23,
			s.Hovered and color_white or COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	ok.OnMousePressed = function()
		if sCat == "" then return end
		surface.PlaySound(SND_CLICK)
		net.Start(bFiling and "EVO:Livre:Archive" or "EVO:Livre:Classify")
			net.WriteUInt(entry.id, 32)
			net.WriteString(sCat)
		net.SendToServer()
		ov:Remove()
	end

	local no = gPanel(270, 246, 210, 46, card)
	no:SetCursor("hand")
	no.Paint = function(s)
		rRect(0, 0, 210, 46, Color(255, 255, 255, s.Hovered and 26 or 12), 6)
		rSimpleText("ANNULER", "Bebas Neue:22", 105, 23, s.Hovered and color_white or COL_MUTED,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	no.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		ov:Remove()
	end
end

-- ============================================================================
-- VUE 3 : INVITÉS DU SECRET DÉFENSE (chef de faction, grade 16)
-- ============================================================================
net.Receive("EVO:Livre:Secret", function()
	local nLen = net.ReadUInt(32)
	local sJson = util.Decompress(net.ReadData(nLen), 200000)
	tSecretList = util.JSONToTable(sJson or "[]") or {}
	if IsValid(frame) and IsValid(frame._content) and frame._content._view == "secret" then
		EVO_LIVRE.ShowSecret()
	end
end)

function EVO_LIVRE.ShowSecret()
	local c = freshContent()
	if not c then return end
	c._view = "secret"

	local lp = LocalPlayer()
	local sMyFac = IsValid(lp) and lp:GetEvoNWString("FactionName", "") or ""

	c.Paint = function()
		rSimpleText("SECRET DÉFENSE", "Bebas Neue:52", 960, 84, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rRect(910, 118, 100, 3, ACCENT)
		rSimpleText("Qui peut ouvrir ce rayon, en plus de toi",
			"Avenir Next World:16", 960, 142, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local back = gPanel(40, 34, 200, 48, c)
	back:SetCursor("hand")
	back.Paint = function(s)
		rRect(0, 0, 200, 48, Color(255, 255, 255, s.Hovered and 26 or 12), 6)
		rSimpleText("◀ ARCHIVES", "Bebas Neue:22", 100, 24, s.Hovered and color_white or COL_MUTED,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	back.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		EVO_LIVRE.ShowLibrary()
	end

	local closeb = gPanel(1830, 30, 56, 56, c)
	closeb:SetCursor("hand")
	closeb.Paint = function(s)
		rRect(0, 0, 56, 56, Color(255, 255, 255, s.Hovered and 26 or 12), 8)
		rSimpleText("✕", "Bebas Neue:30", 28, 27, s.Hovered and color_white or COL_MUTED,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeb.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		if IsValid(frame) then frame:Remove() end
	end

	-- Ajouter : joueurs CONNECTÉS de ma faction (le serveur revalide la faction).
	DropDown(c, 660, 200, 600, 52, function() return "INVITER UNE PERSONNE" end, function()
		local t = {}
		local seen = {}
		for _, m in ipairs(tSecretList) do seen[tostring(m.k or "")] = true end
		for _, p in player.Iterator() do
			if IsValid(p) and p ~= lp and p:GetEvoNWString("FactionName", "") == sMyFac then
				local sKey = p:SteamID64() .. "|" .. tostring(p:GetUniqueID())
				if not seen[sKey] then
					t[#t + 1] = { txt = p:GetEvoNWString("Nickname", p:Nick()), val = p }
				end
			end
		end
		if #t == 0 then t[1] = { txt = "Personne de ta faction en ligne", val = false } end
		return t
	end, function(p)
		if not IsValid(p) then return end
		net.Start("EVO:Livre:SecretSet")
			net.WriteBool(true)
			net.WriteEntity(p)
		net.SendToServer()
	end)

	local scroll = vgui.Create("DScrollPanel", c)
	scroll:gSetPos(660, 280)
	scroll:gSetSize(600, 730)
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end
	local rowH = 60
	local content = vgui.Create("DPanel", scroll)
	scroll:AddItem(content)
	content:gSetSize(580, math.max(60, #tSecretList * (rowH + 8) + 8))
	content.Paint = function() end
	for i, m in ipairs(tSecretList) do
		local row = gPanel(0, (i - 1) * (rowH + 8), 580, rowH, content)
		row.Paint = function()
			rRect(0, 0, 580, rowH, Color(22, 22, 27, 240), 6)
			rRect(0, 0, 4, rowH, ACCENT)
			rSimpleText(m.nm ~= "" and m.nm or "?", "Bebas Neue:22", 22, rowH / 2, COL_TITLE,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local rev = gPanel(444, 13, 116, 34, row)
		rev:SetCursor("hand")
		rev.Paint = function(s)
			rRect(0, 0, 116, 34, Color(30, 10, 10, s.Hovered and 250 or 190), 4)
			rSimpleText("RETIRER", "Bebas Neue:16", 58, 16, s.Hovered and ACCENT or Color(160, 90, 95),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		rev.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			net.Start("EVO:Livre:SecretSet")
				net.WriteBool(false)
				net.WriteString(tostring(m.k or ""))
			net.SendToServer()
		end
	end
	scroll:InvalidateLayout(true)
end
function EVO_LIVRE.ShowLibrary()
	local c = freshContent()
	if not c then return end
	c._view = "library"
	-- Grade 10+ : peut RETIRER et DÉPLACER une archive. L'impression est ouverte
	-- à TOUS, et RANGER descend au grade du rayon Commune (bFiler). Le CHEF DE CLAN
	-- dans les archives de SON clan (user 09/15) retire, supprime et range ses
	-- documents comme un gradé — revalidé serveur.
	local bBossHere = EVO_LIVRE.ManagesCurrentClanArchive(LocalPlayer())
	local bWriter = EVO_LIVRE.CanManage(LocalPlayer()) or bBossHere
	local bFiler = EVO_LIVRE.CanSign(LocalPlayer()) or bBossHere
	local bInZone = IsValid(frame) and frame._inZone == true
	local clan_key = EVO_LIVRE.CurrentArchiveClan(LocalPlayer())
	local clan_archive = clan_key ~= ""
	if frame._libraryScope ~= clan_key then
		sCatFilter = ""
		frame._libraryScope = clan_key
	end

	c.Paint = function(s, w, h)
		rSimpleText(clan_archive and "ARCHIVES DU CLAN" or "ARCHIVES", "Bebas Neue:52", 960, 84, COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rRect(910, 118, 100, 3, COL_GOLD)
		rSimpleText(clan_archive and "Une bibliothèque privée, réservée aux membres de ton clan"
			or bInZone and "Les livres du serveur, écrits par ses habitants et rangés ici"
			or "Rends-toi dans une zone Archives pour imprimer ou ranger un livre",
			"Avenir Next World:16", 960, 142, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		-- Sans ce mot, un non gradé voit juste le bouton RANGER absent et croit à
		-- un bug (il a pourtant bien fait signer son livre).
		if bInZone and not bFiler then
			rSimpleText("Fais appel à un gradé pour ranger ton livre : il faut au moins le grade "
				.. (CFG.CommonMinRank or 2) .. " pour déposer aux archives.",
				"Avenir Next World:13", 960, 1046, Color(140, 128, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif bInZone and not bWriter and not clan_archive then
			rSimpleText("Tu ne peux ranger que dans le rayon "
				.. EVO_LIVRE.CategoryName(CFG.CommonCategory) .. " : les rayons de division demandent le grade "
				.. (CFG.ManageMinRank or 10) .. "+.",
				"Avenir Next World:13", 960, 1046, Color(140, 128, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif bInZone and clan_archive and bBossHere then
			rSimpleText("Chef de clan : tu peux ranger, retirer, réécrire et supprimer les documents de ces archives.",
				"Avenir Next World:13", 960, 1046, Color(140, 128, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	-- Ranger un de SES brouillons aux archives (zone uniquement, revalidé serveur :
	-- zone + détention + signature + limite ; l'item est déposé avec le livre).
	-- Liste DÉROULANTE maison dans la DA (pas de DermaMenu, look Derma hors charte).
	-- RANGER : la signature ne suffit pas, il faut aussi le grade du rayon visé.
	-- Le seuil bas (rayon Commune) ouvre le menu, le rayon lui-même est filtré
	-- dans ShowClassifyPanel. Revalidé serveur dans les deux cas.
	local tDrafts = (bInZone and bFiler) and PersonalBooksHeld() or {}
	if #tDrafts > 0 then
		local ddl
		local rangb = gPanel(40, 34, 310, 48, c)
		rangb:SetCursor("hand")
		rangb.Paint = function(s)
			local hovered = s.Hovered or IsValid(ddl)
			rRect(0, 0, 310, 48, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, hovered and 55 or 25), 6)
			rOutlinedRect(0, 0, 310, 48, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, hovered and 200 or 90), 6, 1)
			rSimpleText("RANGER UN LIVRE AUX ARCHIVES", "Bebas Neue:22", 145, 24,
				hovered and color_white or COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText(IsValid(ddl) and "▲" or "▼", "Bebas Neue:16", 290, 25,
				hovered and color_white or COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		rangb.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			if IsValid(ddl) then
				ddl:Remove()
				ddl = nil
				return
			end
			local rowH = 52
			local n = #tDrafts
			ddl = gPanel(40, 86, 310, n * rowH + 8, c)
			ddl.Paint = function(s, w, h)
				local pts = EVO_UI.PaintCut(0, 0, w, h, Color(14, 14, 17, 252), gRespY(10))
				if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 70)) end
			end
			for i, e in ipairs(tDrafts) do
				local bSigned = (e.si or "") ~= ""
				local row = gPanel(4, 4 + (i - 1) * rowH, 302, rowH, ddl)
				row:SetCursor("hand")
				row.Paint = function(s)
					if s.Hovered then
						rRect(2, 2, 298, rowH - 4, Color(ACCENT.r, ACCENT.g, ACCENT.b, 30), 4)
					end
					local bGhost = IsGhostTitle(e.ti)
					rSimpleText(bGhost and "Sans titre" or e.ti, "Bebas Neue:22", 16, 18,
						bGhost and Color(COL_TITLE.r, COL_TITLE.g, COL_TITLE.b, s.Hovered and 140 or 80)
						or (s.Hovered and color_white or COL_TITLE), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					-- Le serveur refuse un livre non signé : l'état s'explique d'ici.
					rSimpleText(bSigned and "Signé, prêt à ranger" or "Non signé",
						"Avenir Next World:12", 16, 38, bSigned and COL_GOLD or COL_MUTED,
						TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					if i > 1 then
						rRect(10, 0, 282, 1, Color(255, 255, 255, 12))
					end
				end
				row.OnMousePressed = function()
					surface.PlaySound(SND_CLICK)
					if IsValid(ddl) then
						ddl:Remove()
						ddl = nil
					end
					-- Le rangement passe par le panneau de classement : catégorie et
					-- confidentialité se choisissent AU MOMENT où le livre entre.
					ShowClassifyPanel(c, e, true)
				end
			end
		end
	end

	-- SECRET DÉFENSE : gérer les invités du rayon (chef de faction seul).
	local nBtnX = 370
	if not clan_archive and EVO_LIVRE.IsChef(LocalPlayer()) then
		local cb = gPanel(nBtnX, 34, 220, 48, c)
		cb:SetCursor("hand")
		cb.Paint = function(s)
			rRect(0, 0, 220, 48, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, s.Hovered and 55 or 25), 6)
			rOutlinedRect(0, 0, 220, 48, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, s.Hovered and 200 or 90), 6, 1)
			rSimpleText("SECRET DÉFENSE", "Bebas Neue:22", 110, 24, s.Hovered and color_white or ACCENT,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		cb.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			net.Start("EVO:Livre:SecretReq")
			net.SendToServer()
			EVO_LIVRE.ShowSecret()
		end
		nBtnX = nBtnX + 240
	end

	-- Fermer.
	local closeb = gPanel(1830, 30, 56, 56, c)
	closeb:SetCursor("hand")
	closeb.Paint = function(s)
		rRect(0, 0, 56, 56, Color(255, 255, 255, s.Hovered and 26 or 12), 8)
		rSimpleText("✕", "Bebas Neue:30", 28, 27, s.Hovered and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	closeb.OnMousePressed = function()
		surface.PlaySound(SND_CLICK)
		if IsValid(frame) then frame:Remove() end
	end

	-- ── Filtre par CATÉGORIE : puces cliquables, filtrage 100% client sur la
	-- liste déjà reçue (le serveur a déjà retiré ce qu'on n'a pas le droit de voir).
	local lp2 = LocalPlayer()
	local sFilterFac = IsValid(lp2) and lp2:GetEvoNWString("FactionName", "") or ""
	-- Un rayon SUPPRIMÉ laisse des archives avec un id orphelin, et le filtre
	-- courant peut lui-même pointer sur ce rayon disparu : on ramène les deux au
	-- rayon par défaut, sinon l'archive n'était atteignable par AUCUNE puce et la
	-- bibliothèque restait vide sans explication.
	if sCatFilter ~= "" and not EVO_LIVRE.IsCategory(sCatFilter) then sCatFilter = "" end
	local function normCat(sId)
		return EVO_LIVRE.IsCategory(sId) and sId or ""
	end

	local tShown = {}
	for _, e in ipairs(tList) do
		if (e.ck or "") == clan_key and (sCatFilter == "" or normCat(e.ca) == sCatFilter) then
			tShown[#tShown + 1] = e
		end
	end

	local tChips = { { id = "", name = "TOUTES" } }
	for _, cat in ipairs(EVO_LIVRE.CategoriesFor(lp2)) do
		tChips[#tChips + 1] = { id = cat.id, name = cat.name, custom = cat.custom }
	end
	-- Les rayons créés s'ajoutent aux 6 de base : la rangée PASSE À LA LIGNE
	-- plutôt que de sortir de l'écran, et la grille descend d'autant.
	local cx, cy = 160, 174
	for _, chip in ipairs(tChips) do
		surface.SetFont("Bebas Neue:20")
		local tw = surface.GetTextSize(string.upper(chip.name))
		local cw = math.max(90, tw + 34)
		if cx + cw > 1760 then
			cx = 160
			cy = cy + 44
		end
		local px, py = cx, cy
		local bSel = sCatFilter == chip.id
		local chipb = gPanel(px, py, cw, 36, c)
		chipb:SetCursor("hand")
		chipb.Paint = function(s)
			rRect(0, 0, cw, 36, bSel and Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 60)
				or Color(255, 255, 255, s.Hovered and 22 or 10), 18)
			rSimpleText(string.upper(chip.name), "Bebas Neue:20", cw / 2, 18,
				bSel and COL_GOLD or (s.Hovered and color_white or (chip.custom and Color(190, 170, 120) or COL_MUTED)),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		chipb.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			sCatFilter = chip.id
			EVO_LIVRE.ShowLibrary()
		end
		cx = cx + cw + 10
	end

	local nGridY = cy + 56
	local scroll = vgui.Create("DScrollPanel", c)
	scroll:gSetPos(160, nGridY)
	scroll:gSetSize(1600, math.max(300, 1030 - nGridY))
	if EVO_UI and EVO_UI.StyleScrollBar then EVO_UI.StyleScrollBar(scroll) end

	local rows = math.max(1, math.ceil(#tShown / 5))
	local content = vgui.Create("DPanel", scroll)
	scroll:AddItem(content)
	content:gSetSize(1560, 20 + rows * 420)
	content.Paint = (#tShown == 0) and function()
		rSimpleText(sCatFilter == "" and "Aucune archive pour le moment."
			or "Aucune archive dans cette catégorie.",
			"Avenir Next World:18", 780, 120, COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end or function() end

	local slot = 0
	local function slotPos()
		local col = slot % 5
		local row = math.floor(slot / 5)
		slot = slot + 1
		return 20 + col * 310, 10 + row * 420
	end

	local bCanClassify = not clan_archive and EVO_LIVRE.CanManage(LocalPlayer())
	-- Une archive du Secret défense ne SORT que par le chef (règle serveur, deux
	-- portes : Classify et Delete). Un invité gradé 10+ la voit : sans ce test,
	-- DÉPLACER et RETIRER lui étaient proposés puis refusés, et la confirmation
	-- de RETIRER promettait un résultat impossible.
	local bChef = EVO_LIVRE.IsChef(LocalPlayer())
	local function bCanMove(entry)
		return entry.ca ~= CFG.SecretCategory or bChef
	end

	for _, entry in ipairs(tShown) do
		local x, y = slotPos()
		local cov = gPanel(x, y, 270, 380, content)
		cov:SetCursor("hand")
		cov.Paint = function(s)
			-- Couverture cuir + dorures.
			rRect(0, 0, 270, 380, Color(38, 16, 18, 250), 8)
			rRect(4, 4, 262, 372, Color(58, 24, 27, 255), 6)
			rRect(14, 0, 6, 380, Color(24, 10, 11, 255)) -- tranche reliure
			rOutlinedRect(24, 18, 232, 344, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, s.Hovered and 220 or 120), 4, 2)
			if IsGhostTitle(entry.ti) then
				rSimpleText("Sans titre", "Bebas Neue:28", 145, 120,
					Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				local lines = string.Explode("\n", entry.ti or "")
				rSimpleText(lines[1] or "", "Bebas Neue:28", 145, 120, COL_GOLD, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			rRect(105, 156, 80, 2, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 130))
			-- Bandeau de CLASSIFICATION : seul un niveau > 0 se voit (les archives
			-- publiques n'ont pas à porter d'étiquette).
			if entry.ca == CFG.SecretCategory then
				rRect(24, 190, 232, 28, Color(ACCENT.r, ACCENT.g, ACCENT.b, 45))
				rRect(24, 190, 4, 28, ACCENT)
				rSimpleText("SECRET DÉFENSE", "Bebas Neue:18", 145, 204, ACCENT,
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			rSimpleText(EVO_LIVRE.CategoryName(entry.ca), "Avenir Next World:12", 145, 250,
				Color(170, 150, 115, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText("par " .. (entry.au ~= "" and entry.au or "?"), "Avenir Next World:14", 145, 292,
				Color(200, 180, 140, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			rSimpleText(entry.np .. (entry.np > 1 and " pages" or " page"), "Avenir Next World:12", 145, 318,
				Color(170, 150, 115, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			if s.Hovered then
				rRect(24, 18, 232, 344, Color(255, 245, 220, 10), 4)
			end
		end

		-- CLASSER : change catégorie et confidentialité d'une archive déjà rangée.
		-- Visible dès qu'on peut poser au moins un niveau (gradé 10+), revalidé
		-- serveur (grade ET accès au rayon de destination).
		if bInZone and bCanClassify and bCanMove(entry) then
			local cb = gPanel(30, 26, 92, 26, cov)
			cb:SetCursor("hand")
			cb.Paint = function(s)
				rRect(0, 0, 92, 26, Color(20, 17, 8, s.Hovered and 250 or 190), 4)
				rSimpleText("DÉPLACER", "Bebas Neue:16", 46, 12, s.Hovered and COL_GOLD or Color(180, 158, 100),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			cb.OnMousePressed = function()
				surface.PlaySound(SND_CLICK)
				ShowClassifyPanel(c, entry, false)
			end
		end
		cov.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			BeginBookOpen()
			RequestBook(entry.id, "read")
		end

		-- IMPRIMER : donne l'exemplaire de CE livre en inventaire (zone uniquement,
		-- revalidé serveur : zone + faction + pas déjà détenu).
		if bInZone then
			-- IMPRIMER prend toute la largeur quand RETIRER n'est pas là (non gradé,
			-- ou archive du Secret défense que seul le chef peut sortir). Dans les
			-- archives d'un CLAN, un 3e bouton SUPPRIMER (chef de clan / SA, user 09/15).
			local bManage = bWriter and bCanMove(entry)
			-- SUPPRIMER : chef de clan / SA seulement (miroir exact du gate serveur Discard) ;
			-- un gradé 10+ simple membre a RETIRER, pas SUPPRIMER.
			local bDiscard = clan_archive and bCanMove(entry) and (bBossHere or LocalPlayer():IsSuperAdmin())
			local pw = bDiscard and 70 or (bManage and 112 or 222)
			local pb = gPanel(24, 330, pw, 34, cov)
			pb:SetCursor("hand")
			pb.Paint = function(s)
				rRect(0, 0, pw, 34, Color(20, 17, 8, s.Hovered and 250 or 200), 4)
				rSimpleText("IMPRIMER", "Bebas Neue:18", pw / 2, 16,
					s.Hovered and COL_GOLD or Color(190, 165, 105), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			pb.OnMousePressed = function()
				surface.PlaySound(SND_CLICK)
				net.Start("EVO:Livre:Print")
					net.WriteUInt(entry.id, 32)
				net.SendToServer()
			end
			-- RETIRER des archives (gradé 10+ / SA, ou chef de clan dans SON clan) : la
			-- ligne reste en BDD, les exemplaires imprimés restent lisibles.
			if bManage then
				local dx, dw = bDiscard and 98 or 144, bDiscard and 72 or 102
				local db = gPanel(dx, 330, dw, 34, cov)
				db:SetCursor("hand")
				db.Paint = function(s)
					rRect(0, 0, dw, 34, Color(30, 10, 10, s.Hovered and 250 or 200), 4)
					rSimpleText("RETIRER", "Bebas Neue:16", dw / 2, 16, s.Hovered and ACCENT or Color(160, 90, 95), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				db.OnMousePressed = function()
					surface.PlaySound(SND_CLICK)
					local lp = LocalPlayer()
					if IsValid(lp) and lp.OpenYesNoPopup then
						lp:OpenYesNoPopup("Retirer « " .. (entry.ti or "?") .. " » des archives ? Le livre reviendra dans ton inventaire.",
							"EvoLivre_Delete", { id = entry.id })
					end
				end
			end
			-- SUPPRIMER (archives de CLAN, chef / SA) : le document disparaît des
			-- archives sans revenir en inventaire (les exemplaires imprimés restent lisibles).
			if bDiscard then
				local xb = gPanel(174, 330, 72, 34, cov)
				xb:SetCursor("hand")
				xb.Paint = function(s)
					rRect(0, 0, 72, 34, Color(40, 8, 8, s.Hovered and 250 or 200), 4)
					rSimpleText("SUPPRIMER", "Bebas Neue:16", 36, 16, s.Hovered and ACCENT or Color(175, 80, 85), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				xb.OnMousePressed = function()
					surface.PlaySound(SND_CLICK)
					local lp = LocalPlayer()
					if IsValid(lp) and lp.OpenYesNoPopup then
						lp:OpenYesNoPopup("Supprimer « " .. (entry.ti or "?") .. " » des archives du clan ? Le document disparaît des archives (les exemplaires déjà imprimés restent lisibles).",
							"EvoLivre_Discard", { id = entry.id })
					end
				end
			end
		end
	end
	scroll:InvalidateLayout(true)
end

-- ============================================================================
-- VUE 2 : LECTEUR (vrai livre DHTML)
-- ============================================================================
local READER_HTML = [[
<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:100%; height:100%; overflow:hidden; background:transparent; }
/* PAS de raccourci inset:/gap: : le Chromium GMod ne les connaît pas. */
/* 836 de haut = 32px de bande boutons + 30px de bande titre + le livre (740) +
   la pagebar. Le titre a sa PROPRE ligne : partagée avec les boutons, il était
   coincé entre eux et débordait dès qu'un titre ou un signataire était long. */
.scaler { position:absolute; left:50%; top:50%; width:1160px; height:836px;
	margin-left:-580px; margin-top:-418px;
	-webkit-transform-origin:center center; transform-origin:center center; }
.bookwrap { position:absolute; left:40px; top:62px; width:1080px; height:740px;
	-webkit-perspective:2600px; perspective:2600px; }
.pg { position:absolute; top:0; width:540px; height:740px;
	-webkit-backface-visibility:hidden; backface-visibility:hidden;
	-webkit-transition:-webkit-transform 0.22s ease-in; transition:transform 0.22s ease-in;
	background:#efe6d2; }
.pg.l { left:0; -webkit-transform-origin:right center; transform-origin:right center;
	border-radius:8px 0 0 8px;
	background:-webkit-linear-gradient(left, #e3d8c0, #efe6d2 12%, #f2ead8 90%, #dfd3ba);
	box-shadow:inset -18px 0 26px -18px rgba(60,40,20,0.55); }
.pg.r { left:540px; -webkit-transform-origin:left center; transform-origin:left center;
	border-radius:0 8px 8px 0;
	background:-webkit-linear-gradient(left, #dfd3ba, #f2ead8 10%, #efe6d2 88%, #e3d8c0);
	box-shadow:inset 18px 0 26px -18px rgba(60,40,20,0.55); }
.pg.l.turn { -webkit-transform:rotateY(86deg); transform:rotateY(86deg); }
.pg.r.turn { -webkit-transform:rotateY(-86deg); transform:rotateY(-86deg); }
.spine { position:absolute; left:538px; top:0; width:4px; height:740px;
	background:-webkit-linear-gradient(left, rgba(60,40,20,0.4), rgba(60,40,20,0.7), rgba(60,40,20,0.4)); }
.edge { position:absolute; left:-8px; top:8px; width:1096px; height:740px;
	background:#cbbc9e; border-radius:10px; box-shadow:0 14px 40px rgba(0,0,0,0.6); }
/* Padding et police calés sur CFG.MaxTextLen (1200) : ~28 lignes de ~57
   caractères = ~1350 de capacité réelle. Toute retouche ici doit re-vérifier
   qu'une page PLEINE tient (le débordement est INVISIBLE, overflow caché). */
.pin { position:absolute; left:0; top:0; width:100%; height:100%; padding:40px 40px 48px 40px; overflow:hidden; }
.ptxt { position:relative; white-space:pre-wrap; font-family:Georgia,'Times New Roman',serif;
	font-size:16px; line-height:1.45; color:#3a332b; word-wrap:break-word; }
.pnum { position:absolute; bottom:14px; left:0; width:100%; text-align:center;
	font-family:Georgia,serif; font-size:14px; color:#8a7c62; }
.pempty { position:absolute; left:0; top:0; width:100%; height:100%; }
.pagebar { position:absolute; left:0; width:100%; top:806px; text-align:center;
	font-family:Georgia,serif; font-style:italic; font-size:18px; letter-spacing:1px;
	color:rgba(216,185,106,0.75); opacity:0; -webkit-transition:opacity 0.4s; transition:opacity 0.4s; }
.pagebar .orn { font-style:normal; font-size:13px; color:rgba(216,185,106,0.45);
	padding:0 14px 0 14px; }
body.open .pagebar { opacity:1; }

/* Titre/auteur/signature (plus de couverture 2D). Ligne DÉDIÉE sous les
   boutons, pleine largeur ; font-size re-calculée par fitHead(), la valeur
   ci-dessous n'est que le maximum. */
.bookhead { position:absolute; left:24px; right:24px; top:34px; height:26px; line-height:26px;
	text-align:center; font-family:'EVOBebas','Bebas Neue','Impact',sans-serif;
	font-size:17px; letter-spacing:2px;
	color:rgba(216,185,106,0.9); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

.nz { position:absolute; top:0; width:120px; height:740px; cursor:pointer; z-index:4; opacity:0;
	-webkit-transition:opacity 0.2s; transition:opacity 0.2s; }
.nz:hover { opacity:1; }
.nz.left { left:0; background:-webkit-linear-gradient(left, rgba(0,0,0,0.18), transparent); border-radius:8px 0 0 8px; }
.nz.right { left:960px; background:-webkit-linear-gradient(right, rgba(0,0,0,0.18), transparent); border-radius:0 8px 8px 0; }
.nz .arr { position:absolute; top:50%; margin-top:-24px; font-size:44px; color:rgba(255,250,235,0.9);
	text-shadow:0 2px 8px rgba(0,0,0,0.8); font-family:Georgia,serif; }
.nz.left .arr { left:18px; }
.nz.right .arr { right:18px; }

.topbtn { position:absolute; top:0; z-index:8; cursor:pointer;
	font-family:'EVOBebas','Bebas Neue','Impact',sans-serif; letter-spacing:2px;
	color:rgba(238,239,243,0.75); font-size:17px; padding:6px 12px 6px 12px; }
.topbtn:hover { color:#fff; }
/* Boutons de gauche EN FLUX et plus à des left: en dur : depuis que le haut
   commandement réécrit un livre SIGNÉ, ÉCRIRE / RETIRER LA SIGNATURE / SIGNER
   peuvent s'afficher ensemble, et les positions fixes se recouvraient. */
.topleft { position:absolute; top:0; left:0; z-index:8; white-space:nowrap; }
.topleft .topbtn { position:relative; }
#btnclose { right:0; }
#btnedit { color:rgba(216,185,106,0.8); display:none; }
#btnedit:hover { color:#d8b96a; }
body.writable #btnedit { display:inline-block; }
#btnshow { right:110px; color:rgba(216,185,106,0.8); display:none; }
#btnshow:hover { color:#d8b96a; }
body.canshow #btnshow { display:block; }
#btnsign { color:rgba(216,185,106,0.8); display:none; }
#btnsign:hover { color:#d8b96a; }
body.cansign #btnsign { display:inline-block; }
#btnunsign { color:rgba(207,68,78,0.8); display:none; }
#btnunsign:hover { color:#cf444e; }
body.canunsign #btnunsign { display:inline-block; }
{{BEBAS}}
</style></head>
<body>
<div class="scaler" id="scaler">
	<div class="topleft">
		<div class="topbtn" id="btnedit">✎ ÉCRIRE</div>
		<div class="topbtn" id="btnunsign">✕ RETIRER LA SIGNATURE</div>
		<div class="topbtn" id="btnsign">✒ SIGNER</div>
	</div>
	<div class="topbtn" id="btnshow">MONTRER AUX PROCHES</div>
	<div class="topbtn" id="btnclose">✕ FERMER</div>
	<div class="bookwrap">
		<div class="edge"></div>
		<div class="pg l" id="pl"><div class="pin" id="plc"></div></div>
		<div class="pg r" id="pr"><div class="pin" id="prc"></div></div>
		<div class="spine"></div>
		<div class="nz left" id="nzl"><div class="arr">❮</div></div>
		<div class="nz right" id="nzr"><div class="arr">❯</div></div>
	</div>
	<div class="bookhead" id="bookhead"></div>
	<div class="pagebar" id="pagebar"></div>
</div>
<script>
var PAGES = {{PAGES}};
var META = {{META}};
var spread = 0;
var turning = false;
function esc(s){ return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function pageHTML(i){
	if (i >= PAGES.length) return '<div class="pempty"></div>';
	var p = PAGES[i] || {};
	var h = '<div class="ptxt">' + esc(p.t) + '</div>';
	h += '<div class="pnum">Page ' + (i + 1) + ' / ' + PAGES.length + '</div>';
	return h;
}
function render(){
	document.getElementById('plc').innerHTML = pageHTML(spread * 2);
	document.getElementById('prc').innerHTML = pageHTML(spread * 2 + 1);
	var l = spread * 2 + 1, r = spread * 2 + 2, n = PAGES.length;
	var t = (r <= n) ? ('Pages ' + l + ' et ' + r) : ('Page ' + l);
	document.getElementById('pagebar').innerHTML =
		'<span class="orn">✦</span>' + t + ' / ' + n + '<span class="orn">✦</span>';
}
function go(dir){
	if (turning || !document.body.className.match('open')) return;
	var ns = spread + dir;
	var max = Math.max(0, Math.ceil(PAGES.length / 2) - 1);
	if (ns < 0 || ns > max) return;
	turning = true;
	var el = document.getElementById(dir > 0 ? 'pr' : 'pl');
	el.className = el.className + ' turn';
	if (window.gmod && gmod.sfx) gmod.sfx();
	setTimeout(function(){
		spread = ns;
		render();
		el.className = el.className.replace(' turn', '');
		turning = false;
	}, 210);
}
function fit(){
	var s = Math.min(window.innerWidth / 1160, window.innerHeight / 836);
	var sc = document.getElementById('scaler');
	sc.style.webkitTransform = 'scale(' + s + ')';
	sc.style.transform = 'scale(' + s + ')';
}
if (META.writable) document.body.className += ' writable';
if (META.canshow) document.body.className += ' canshow';
if (META.cansign) document.body.className += ' cansign';
if (META.canunsign) document.body.className += ' canunsign';
/* Livre directement OUVERT (l'anim 3D d'ouverture vient de jouer). */
document.body.className += ' open';
/* Un titre long ou un signataire au pseudo à rallonge débordait du bandeau :
   on descend la police jusqu'à ce que la ligne tienne (plancher 10px). */
function fitHead(el){
	var s = 17;
	el.style.fontSize = s + 'px';
	while (s > 10 && el.scrollWidth > el.clientWidth) {
		s -= 1;
		el.style.fontSize = s + 'px';
	}
}
function renderHead(){
	var h = META.ghost ? 'Sans titre' : META.title;
	if (META.author) h += '   ·   par ' + META.author;
	if (META.cat) h += '   ·   ' + META.cat;
	if (META.signed) h += '   ·   Signé par ' + META.signed;
	var el = document.getElementById('bookhead');
	el.innerText = h;
	fitHead(el);
}
function setSigned(n){ META.signed = n; renderHead(); }
/* Pose/retire une classe SANS doublon : signer deux fois de suite ajoutait deux
   fois ' canunsign', et le retrait n'en enlevait qu'une (bouton fantôme). */
function setFlag(n, on){
	var c = ' ' + document.body.className + ' ';
	c = c.split(' ' + n + ' ').join(' ');
	if (on) c += n + ' ';
	document.body.className = c.replace(/^\s+|\s+$/g, '');
}
renderHead();
document.getElementById('nzl').onclick = function(){ go(-1); };
document.getElementById('nzr').onclick = function(){ go(1); };
document.getElementById('btnclose').onclick = function(){ if (window.gmod && gmod.close) gmod.close(); };
document.getElementById('btnedit').onclick = function(){ if (window.gmod && gmod.edit) gmod.edit(); };
document.getElementById('btnshow').onclick = function(){ if (window.gmod && gmod.show) gmod.show(); };
document.getElementById('btnsign').onclick = function(){ if (window.gmod && gmod.sign) gmod.sign(); };
document.getElementById('btnunsign').onclick = function(){ if (window.gmod && gmod.unsign) gmod.unsign(); };
render();
fit();
setInterval(fit, 400);
/* EVOBebas peut arriver APRÈS le premier calcul : les largeurs changent, on
   re-mesure le bandeau deux fois plutôt que de boucler indéfiniment. */
setTimeout(function(){ renderHead(); }, 300);
setTimeout(function(){ renderHead(); }, 1200);
</script>
</body></html>
]]

-- Bebas embarquée en base64 (pattern evo_science) : sans elle, retombe sur Impact.
local function bebasCSS()
	local raw = file.Read("resource/fonts/BebasNeue-Regular.ttf", "GAME")
	if not raw then return "" end
	return "@font-face { font-family:'EVOBebas'; src:url(data:font/truetype;base64,"
		.. util.Base64Encode(raw, true) .. ") format('truetype'); }"
end

--- État de signature RECALCULÉ ET POUSSÉ PAR LE SERVEUR après chaque Signer /
--- Retirer la signature, succès comme refus. Le client ne redérive RIEN : il ne
--- connaît ni le SteamID du signataire ni celui de l'auteur, donc il ne peut pas
--- rejouer CanUnsign, et une entrée caviardée du registre le trompait. Un simple
--- affichage optimiste mentait durablement dès que le serveur refusait.
net.Receive("EVO:Livre:SignState", function()
	local id = net.ReadUInt(32)
	local sSigned = net.ReadString()
	local bSign, bUnsign, bEdit = net.ReadBool(), net.ReadBool(), net.ReadBool()
	local c = IsValid(frame) and frame._content or nil
	if not (c and c._view == "reader" and IsValid(c._html) and istable(c._book)) then return end
	if (c._bookId or 0) ~= id then return end
	c._book.canedit = bEdit
	c._html:RunJavascript(string.format(
		"setFlag('writable', %s); setFlag('cansign', %s); setFlag('canunsign', %s); setSigned('%s');",
		bEdit and "true" or "false", bSign and "true" or "false",
		bUnsign and "true" or "false", jsEsc(sSigned)))
end)

function EVO_LIVRE.ShowReader(book)
	local c = freshContent()
	if not c then return end
	c._view = "reader"

	local meta = {
		title = tostring(book.title or ""),
		ghost = IsGhostTitle(book.title),
		author = tostring(book.author or ""),
		-- Droits calculés par le SERVEUR (détenteur d'un brouillon, ou SA).
		writable = book.canedit == true,
		-- Montrer : il faut l'exemplaire en inventaire (revalidé serveur).
		canshow = HasBookItem(tonumber(book.id) or 0),
		-- Signature (grade 2+, calculé serveur) : sésame du rangement. Elle FIGE le
		-- livre, sauf pour le haut commandement qui réécrit par-dessus : ÉCRIRE et
		-- RETIRER LA SIGNATURE peuvent donc s'afficher ENSEMBLE (cf. .topleft).
		signed = tostring(book.signed or ""),
		cansign = book.cansign == true,
		canunsign = book.canunsign == true,
		-- Classement : mention dans le bandeau du lecteur (on doit savoir qu'on
		-- lit un document classifié sans avoir à retourner à la bibliothèque).
		cat = (tonumber(book.archived) or 0) == 1 and EVO_LIVRE.CategoryName(book.category) or "",
	}
	-- "</" échappé en "<\/" : un texte de page contenant "</script>" terminerait le
	-- bloc <script> au PARSING HTML (même dans une string JS) = casse + injection.
	local function jsonForJS(t, fallback)
		local s = util.TableToJSON(t) or fallback
		return (string.gsub(s, "</", "<\\/"))
	end
	local html = vgui.Create("DHTML", c)
	c._bookId, c._book, c._html = tonumber(book.id) or 0, book, html
	html:Dock(FILL)
	html:SetKeyboardInputEnabled(false)
	html:SetHTML(tpl(READER_HTML, {
		PAGES = jsonForJS(book.pages or {}, "[]"),
		META = jsonForJS(meta, "{}"),
		BEBAS = bebasCSS(),
	}))
	html:AddFunction("gmod", "close", function()
		if not IsValid(frame) then return end
		-- Anim 3D de fermeture, puis : ouvert depuis l'item -> tout se referme,
		-- sinon retour à la bibliothèque.
		CloseBookWithAnim(function()
			if not IsValid(frame) then return end
			if frame._fromItem then frame:Remove() else EVO_LIVRE.ShowLibrary() end
		end)
	end)
	html:AddFunction("gmod", "edit", function()
		if IsValid(frame) and book.canedit == true then
			EVO_LIVRE.ShowEditor(book)
		end
	end)
	html:AddFunction("gmod", "show", function()
		if not IsValid(frame) then return end
		net.Start("EVO:Livre:ShowNearby")
			net.WriteUInt(tonumber(book.id) or 0, 32)
		net.SendToServer()
	end)
	html:AddFunction("gmod", "sign", function()
		if not IsValid(frame) then return end
		net.Start("EVO:Livre:Sign")
			net.WriteUInt(tonumber(book.id) or 0, 32)
		net.SendToServer()
		-- Aucun affichage optimiste : le serveur répond par EVO:Livre:SignState,
		-- succès comme refus. Signer FIGE le livre pour qui ne peut pas réécrire
		-- par-dessus, et deviner ça ici se trompait dès que le serveur refusait.
	end)
	html:AddFunction("gmod", "unsign", function()
		if not IsValid(frame) then return end
		net.Start("EVO:Livre:Unsign")
			net.WriteUInt(tonumber(book.id) or 0, 32)
		net.SendToServer()
		-- Idem : l'état revient du serveur par EVO:Livre:SignState.
	end)
	html:AddFunction("gmod", "sfx", function()
		surface.PlaySound(SND_PAGE)
	end)
end

-- ============================================================================
-- VUE 3 : ÉDITEUR (VGUI : texte DTextEntry)
-- ============================================================================
function EVO_LIVRE.ShowEditor(book)
	local c = freshContent()
	if not c then return end
	c._view = "editor"

	-- Copie de travail (le lecteur garde son exemplaire intact).
	local eBook = {
		id = tonumber(book.id) or 0,
		title = tostring(book.title or ""),
		pages = {},
	}
	for _, pg in ipairs(book.pages or {}) do
		eBook.pages[#eBook.pages + 1] = { t = tostring(pg.t or "") }
	end
	if #eBook.pages == 0 then eBook.pages[1] = { t = "" } end
	local nCur = 1
	local bSaving = false
	-- Déverrouille ENREGISTRER quand le serveur répond SaveAck(false) (sinon le
	-- bouton restait mort jusqu'au timer de secours de 8s).
	c._resetSaving = function() bSaving = false end

	c.Paint = function()
		rSimpleText("ÉCRIRE LE LIVRE", "Bebas Neue:44", 960, 66,
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		rRect(910, 96, 100, 3, COL_GOLD)
	end

	-- ── Page papier (mêmes proportions que le lecteur : 540x740 -> 600x820). ──
	local page = gPanel(360, 130, 600, 820, c)
	page.Paint = function(s, w, h)
		-- Épaisseur du livre : hors des bornes du panel -> clipping désactivé le temps du trait.
		DisableClipping(true)
		rRect(-6, 8, 612, 820, Color(120, 105, 80, 120), 8)
		DisableClipping(false)
		rRect(0, 0, 600, 820, COL_PAPER, 6)
		rRect(0, 0, 600, 8, Color(200, 188, 160, 160), 6)
		rRect(0, 812, 600, 8, Color(200, 188, 160, 160), 6)
	end

	local entry = vgui.Create("DTextEntry", page)
	entry:gSetPos(34, 34)
	entry:gSetSize(532, 700)
	entry:SetMultiline(true)
	entry:SetVerticalScrollbarEnabled(true)
	entry:SetUpdateOnType(true)
	entry:SetPaintBackground(false)
	entry:SetFont("EVOLivre_Text")
	entry:SetTextColor(COL_INK)
	entry:SetCursorColor(COL_INK)
	if entry.SetDrawLanguageID then entry:SetDrawLanguageID(false) end
	entry.Paint = function(s, w, h)
		s:DrawTextEntryText(COL_INK, ACCENT, COL_INK)
	end
	entry.OnValueChange = function(s, v)
		if #v > CFG.MaxTextLen then
			v = string.sub(v, 1, CFG.MaxTextLen)
			s:SetText(v)
			s:SetCaretPos(#v)
		end
		eBook.pages[nCur].t = v
	end

	local pageNumLabel = gPanel(0, 770, 600, 30, page)
	pageNumLabel:SetMouseInputEnabled(false)
	pageNumLabel.Paint = function()
		rSimpleText("Page " .. nCur .. " / " .. #eBook.pages, "EVOLivre_Text", 300, 15,
			Color(138, 124, 98), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local function gotoPage(n)
		eBook.pages[nCur].t = entry:GetValue()
		nCur = math.Clamp(n, 1, #eBook.pages)
		entry:SetText(eBook.pages[nCur].t)
	end

	-- ── Barre latérale. ──
	local side = gPanel(1030, 130, 480, 820, c)
	side.Paint = function(s, w, h)
		local pts = EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 240), gRespY(12))
		if EVO_UI.OutlineCut then EVO_UI.OutlineCut(pts, Color(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 50)) end
		rSimpleText("TITRE DU LIVRE", "Bebas Neue:20", 30, 34, COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local nLen = #(eBook.pages[nCur].t or "")
		rSimpleText(nLen .. " / " .. CFG.MaxTextLen .. " caractères", "Avenir Next World:13", 30, 262,
			nLen >= CFG.MaxTextLen and ACCENT or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local titleEntry = vgui.Create("DTextEntry", side)
	titleEntry:gSetPos(30, 52)
	titleEntry:gSetSize(420, 46)
	titleEntry:SetFont("EVOLivre_Title")
	titleEntry:SetUpdateOnType(true)
	titleEntry:SetTextColor(COL_GOLD)
	titleEntry:SetCursorColor(COL_GOLD)
	if titleEntry.SetDrawLanguageID then titleEntry:SetDrawLanguageID(false) end
	titleEntry:SetText(eBook.title)
	titleEntry:SetPaintBackground(false)
	titleEntry.Paint = function(s, w, h)
		surface.SetDrawColor(255, 255, 255, 10)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(COL_GOLD.r, COL_GOLD.g, COL_GOLD.b, 120)
		surface.DrawRect(0, h - 2, w, 2)
		s:DrawTextEntryText(COL_GOLD, ACCENT, COL_GOLD)
		if s:GetText() == "" and not s:HasFocus() then
			draw.SimpleText("Titre du livre…", "EVOLivre_Title", gRespX(6), h / 2,
				Color(150, 130, 80, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	titleEntry.OnValueChange = function(s, v)
		if #v > CFG.MaxTitleLen then
			v = string.sub(v, 1, CFG.MaxTitleLen)
			s:SetText(v)
			s:SetCaretPos(#v)
		end
		eBook.title = v
	end

	local function sideButton(x, y, w, h, label, col, fn)
		local b = gPanel(x, y, w, h, side)
		b:SetCursor("hand")
		b.Paint = function(s)
			local hovered = s.Hovered
			rRect(0, 0, w, h, Color(col.r, col.g, col.b, hovered and 55 or 25), 6)
			rOutlinedRect(0, 0, w, h, Color(col.r, col.g, col.b, hovered and 200 or 90), 6, 1)
			rSimpleText(label, "Bebas Neue:20", w / 2, h / 2, hovered and color_white or Color(col.r, col.g, col.b),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.OnMousePressed = function()
			surface.PlaySound(SND_CLICK)
			fn(b)
		end
		return b
	end

	-- Navigation de pages.
	sideButton(30, 130, 70, 46, "❮", COL_TITLE, function() gotoPage(nCur - 1) end)
	local pgLbl = gPanel(110, 130, 260, 46, side)
	pgLbl:SetMouseInputEnabled(false)
	pgLbl.Paint = function()
		rSimpleText("PAGE  " .. nCur .. " / " .. #eBook.pages, "Bebas Neue:26", 130, 23,
			COL_TITLE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	sideButton(380, 130, 70, 46, "❯", COL_TITLE, function() gotoPage(nCur + 1) end)

	sideButton(30, 190, 205, 46, "+ PAGE", COL_GOLD, function()
		if #eBook.pages >= CFG.MaxPages then
			Notify("Maximum " .. CFG.MaxPages .. " pages.")
			return
		end
		eBook.pages[nCur].t = entry:GetValue()
		table.insert(eBook.pages, nCur + 1, { t = "" })
		gotoPage(nCur + 1)
	end)
	sideButton(245, 190, 205, 46, "RETIRER LA PAGE", ACCENT, function()
		if #eBook.pages <= 1 then
			Notify("Un livre garde au moins une page.")
			return
		end
		table.remove(eBook.pages, nCur)
		nCur = math.Clamp(nCur, 1, #eBook.pages)
		entry:SetText(eBook.pages[nCur].t)
	end)

	sideButton(30, 700, 420, 52, "ENREGISTRER", COL_GOLD, function()
		if bSaving then return end
		eBook.pages[nCur].t = entry:GetValue()
		bSaving = true
		local clean = EVO_LIVRE.SanitizeBook({ title = eBook.title, pages = eBook.pages })
		if not clean then
			bSaving = false
			Notify("Contenu invalide.")
			return
		end
		local sJson = util.TableToJSON(clean) or "{}"
		if #sJson > CFG.MaxDataLen then
			bSaving = false
			Notify("Livre trop volumineux : allège le texte.")
			return
		end
		local d = util.Compress(sJson)
		net.Start("EVO:Livre:Save")
			net.WriteUInt(eBook.id, 32)
			net.WriteUInt(#d, 32)
			net.WriteData(d, #d)
		net.SendToServer()
		timer.Simple(8, function() bSaving = false end)
	end)
	-- Ouvert depuis l'item : pas de bibliothèque derrière -> FERMER referme tout.
	-- Dans les deux cas, l'anim 3D de fermeture joue d'abord.
	local bFromItem = IsValid(frame) and frame._fromItem == true
	sideButton(30, 762, 420, 42, bFromItem and "FERMER LE LIVRE" or "RETOUR À LA BIBLIOTHÈQUE", COL_MUTED, function()
		CloseBookWithAnim(function()
			if not IsValid(frame) then return end
			if bFromItem then
				frame:Remove()
				return
			end
			EVO_LIVRE.ShowLibrary()
			net.Start("EVO:Livre:List")
			net.SendToServer()
		end)
	end)

	entry:SetText(eBook.pages[nCur].t)
	entry:RequestFocus()
end

-- ============================================================================
-- NET
-- ============================================================================
net.Receive("EVO:Livre:ListData", function()
	local nLen = net.ReadUInt(32)
	local sJson = util.Decompress(net.ReadData(nLen), 200000)
	tList = util.JSONToTable(sJson or "[]") or {}
	if IsValid(frame) and IsValid(frame._content) and frame._content._view == "library" then
		EVO_LIVRE.ShowLibrary()
	end
end)

net.Receive("EVO:Livre:Data", function()
	local nLen = net.ReadUInt(32)
	local sJson = util.Decompress(net.ReadData(nLen), CFG.MaxDataLen + 4096)
	local book = util.JSONToTable(sJson or "{}")
	if not istable(book) or not IsValid(frame) then return end
	-- Un Data POUSSÉ (montré par un joueur) qu'on n'a pas demandé ne doit JAMAIS
	-- écraser un éditeur ouvert : le travail non sauvegardé serait perdu.
	local sView = IsValid(frame._content) and frame._content._view or nil
	if sView == "editor" and sPendingMode == nil then return end
	-- Les droits viennent du SERVEUR (book.canedit) : détenteur d'un brouillon ou SA.
	local bEdit = sPendingMode == "edit" and book.canedit == true
	sPendingMode = nil
	-- L'anim 3D d'ouverture joue encore : le livre attend la fin de l'animation
	-- (TryShowPendingBook l'affichera), sinon affichage immédiat.
	if frame._animDone == false then
		frame._pendingBook = { book = book, edit = bEdit }
		return
	end
	if bEdit then
		EVO_LIVRE.ShowEditor(book)
	else
		EVO_LIVRE.ShowReader(book)
	end
end)

-- ============================================================================
-- MARQUEURS DE ZONE : plaque « ARCHIVES [E] Consulter / Ranger » face au joueur
-- (EVO_ZonePrompt, recette cachot — plus de cercle au sol, user 08/24). Touche E
-- dans le cylindre pour ouvrir. Visibles par TOUT LE MONDE : chacun y consulte /
-- imprime les archives de sa faction et y range ses propres livres.
-- ============================================================================

-- Ancrage AU SOL : EVO_LIVRE.StationAnchor (sh_config), PARTAGÉ avec IsInStation :
-- le rendu et le check E/serveur utilisent le même z ancré (sinon des zones
-- s'affichaient au sol mais refusaient le E, bug « 2 zones sur 4 » Hueco).

hook.Add("PostDrawTranslucentRenderables", "EVO_Livre::ZoneMarkers", function(bDepth, bSkybox)
	if bDepth or bSkybox then return end
	if not EVO_ZonePrompt then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local zones = EVO_LIVRE.StationList()
	if #zones == 0 then return end

	local eye = EyePos()
	for _, st in ipairs(zones) do
		if eye:DistToSqr(st.pos) < (EVO_ZonePrompt.DrawDistSqr or (300 * 300)) then
			EVO_ZonePrompt.Draw(EVO_LIVRE.StationAnchor(st), st.clan_key and "ARCHIVES DU CLAN" or "ARCHIVES", "Consulter / Ranger")
		end
	end
end)

hook.Add("PlayerButtonDown", "EVO_Livre::UseKey", function(ply, btn)
	if ply ~= LocalPlayer() then return end -- RÈGLE : tout PlayerButtonDown filtre son 1er arg
	if btn ~= KEY_E then return end
	if vgui.CursorVisible() or gui.IsGameUIVisible() then return end
	if IsValid(frame) then return end
	if EVO_LIVRE.IsInStation(ply) then
		EVO_LIVRE.Open(true)
	end
end)

-- Quelqu'un nous montre son livre : bandeau chat + le LIVRE s'ouvre directement.
-- Le serveur POUSSE les données juste après ce message (canal net ordonné) : on
-- prépare seulement le cadre, SANS envoyer de Get (le gate de lecture refuserait
-- un livre qu'on ne détient pas).
net.Receive("EVO:Livre:Shown", function()
	local sName = net.ReadString()
	local _ = net.ReadUInt(32) -- id (le Data qui suit porte déjà tout le livre)
	-- Éditeur ouvert : on ne vole PAS la vue (travail non sauvegardé), le Data
	-- poussé sera ignoré par la garde du receiver Data.
	if IsValid(frame) and IsValid(frame._content) and frame._content._view == "editor" then
		Notify(sName .. " voulait te montrer son livre (tu étais en pleine écriture).")
		return
	end
	Notify(sName .. " te montre son livre.")
	makeFrame()
	frame._fromItem = true
	sPendingMode = "read"
	BeginBookOpen()
end)

-- Fermeture forcée par le serveur (dégâts pendant la lecture) : l'anim est déjà
-- coupée côté serveur, on referme l'UI sans rejouer la fermeture animée.
net.Receive("EVO:Livre:ForceClose", function()
	if IsValid(frame) then
		frame._readAnim = nil
		frame:Remove()
	end
end)

-- Force l'animation de lecture sur TOUS les clients qui voient un lecteur
-- (recette gestion faction : NWBool posé par le serveur + séquence forcée).
local tReadSeqCache = {}
hook.Add("UpdateAnimation", "EVO_Livre:ReadAnimForce", function(ply)
	if not IsValid(ply) then return end
	if not ply:GetEvoNWBool("EVO::IsReadingLivre", false) then
		ply._LivreReadSeqSet = nil
		return
	end
	local sKey = ply:GetModel() .. "_evo_hwndw1d2gtqzzdvkf"
	if tReadSeqCache[sKey] == nil then
		tReadSeqCache[sKey] = ply:LookupSequence("evo_hwndw1d2gtqzzdvkf") or -1
	end
	local nSeq = tReadSeqCache[sKey]
	if nSeq and nSeq > 0 then
		-- Ne reset la séquence qu'une fois pour ne pas bloquer l'animation.
		if not ply._LivreReadSeqSet then
			ply:ResetSequence(nSeq)
			ply:SetCycle(0)
			ply._LivreReadSeqSet = true
		end
		ply:SetPlaybackRate(1)
		return true
	end
end)

net.Receive("EVO:Livre:SaveAck", function()
	local bOk = net.ReadBool()
	if not IsValid(frame) then return end
	if bOk then
		surface.PlaySound(SND_PAGE)
		-- Anim 3D de fermeture puis : édition depuis l'item -> on referme (le
		-- popup serveur confirme déjà), sinon retour à la bibliothèque.
		CloseBookWithAnim(function()
			if not IsValid(frame) then return end
			if frame._fromItem then
				frame:Remove()
				return
			end
			EVO_LIVRE.ShowLibrary()
			net.Start("EVO:Livre:List")
			net.SendToServer()
		end)
	elseif IsValid(frame._content) and frame._content._resetSaving then
		frame._content._resetSaving()
	end
end)
