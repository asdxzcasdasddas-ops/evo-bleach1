-- "addons\\evo_config_positions\\lua\\autorun\\client\\cl_evo_config_positions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CONFIG POSITIONS — client : gizmos style éditeur d'accessoire,
-- clic prioritaire (C menu WorldClicker), preview live des PNJ.
-- ============================================================================

if not CLIENT then return end

EVO_ConfigPos = EVO_ConfigPos or {}

local KIND = EVO_ConfigPos.KIND
local Active = false
local Items = {}
local Selected
local Mode = "move"
local CatsOn = {}
local Drag
local KeyWas = {}
local MouseWasDown = false
local GizmoFrame
local GizmoScreen
local HoverPick
local LastStream = 0

for _, c in ipairs(EVO_ConfigPos.CATS) do
	CatsOn[c.id] = true
end

local DOME_PROVIDERS = {
	bataille_dome = true,
	capture_dome = true,
}
local DOME_MIN, DOME_MAX = 64, 20000

local function isDomeItem(it)
	return it and DOME_PROVIDERS[it.provider]
end

local function boxToDome(mins, maxs)
	if not (mins and maxs) then return nil, 0, 0 end
	local r = math.max(math.abs(maxs.x - mins.x), math.abs(maxs.y - mins.y)) * 0.5
	local h = math.abs(maxs.z - mins.z)
	if r < DOME_MIN then r = DOME_MIN end
	if h < DOME_MIN then h = DOME_MIN end
	local z = math.min(mins.z, maxs.z)
	return Vector((mins.x + maxs.x) * 0.5, (mins.y + maxs.y) * 0.5, z), r, h
end

local function boxFromDome(c, r, h)
	if not c then return nil, nil end
	r = math.Clamp(tonumber(r) or DOME_MIN, DOME_MIN, DOME_MAX)
	h = math.Clamp(tonumber(h) or DOME_MIN, DOME_MIN, DOME_MAX)
	return Vector(c.x - r, c.y - r, c.z), Vector(c.x + r, c.y + r, c.z + h)
end

local function nudgeDome(it, fR, fH)
	if not (it and it.mins and it.maxs) then return end
	local c, r, h = boxToDome(it.mins, it.maxs)
	it.mins, it.maxs = boxFromDome(c, r * (fR or 1), h * (fH or 1))
end

local function canScaleItem(it)
	return it and (isDomeItem(it) or it.provider == "world_models" or it.provider == "bastion_hud_shinigami" or it.provider == "bastion_hud_hollow")
end

local function canRotateItem(it)
	return it and (it.kind == KIND.POINT_ANG or isDomeItem(it))
end

local function validModes(it)
	local modes = { "move" }
	if canRotateItem(it) then modes[#modes + 1] = "rotate" end
	if canScaleItem(it) then modes[#modes + 1] = "scale" end
	return modes
end

local MODE_ORDER = { "move", "rotate", "scale" }
local MODE_LAB = { move = "MOVE", rotate = "ROTATE", scale = "SCALE" }
local ModeBtns = {}

local function hitModeButton(mx, my)
	for i = 1, #ModeBtns do
		local b = ModeBtns[i]
		if mx >= b.x and my >= b.y and mx <= b.x + b.w and my <= b.y + b.h then
			return b.mode
		end
	end
end

local function R(v)
	return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080))
end

local AXIS_COLORS = {
	Color(207, 68, 78),
	Color(78, 196, 128),
	Color(90, 140, 240),
}
local AXIS_NAMES = { "X", "Y", "Z" }
-- Source/GMod : Pitch = autour de Y, Yaw = autour de Z, Roll = autour de X.
local ROT_NAMES = { "Roll", "Pitch", "Yaw" }

local COL_BOX = Color(80, 200, 255, 40)
local COL_BOX_LINE = Color(80, 200, 255, 220)
local COL_MARK = Color(255, 210, 80, 230)
local COL_SEL = Color(255, 255, 255, 255)
local COL_LAB = Color(240, 240, 245)
local COL_HUD = Color(20, 20, 24, 210)
local COL_TITLE = Color(238, 239, 243)
local COL_BG = Color(16, 16, 19, 250)
local COL_PANEL = Color(24, 24, 30, 255)
local COL_ROW = Color(32, 32, 40, 255)
local COL_ROWSEL = Color(60, 48, 52, 255)
local COL_ACCENT = Color(207, 68, 78)
local COL_TXT = Color(232, 232, 238)
local COL_DIM = Color(150, 154, 162)

local EditorPanel
local SelCat = "domaine"
local SelProvider
local SelModelPreset
local QuestTypeFilter = ""
local rebuildEditorPanel
local openEditorPanel
local syncEditorPanelVis
local hideEditorPanel
local showEditorPanel

local MARKER_DIST_SQR = 8000 * 8000
local LABEL_DIST_SQR = 2500 * 2500
local MARKER_PICK_PX = 48
local GIZMO_PICK_PX = 22
local GIZMO_CENTER_PICK_PX = 18
local ROT_GIZMO_SEGMENTS = 36
local ROT_GIZMO_PICK_SAMPLES = 64
local ROT_GIZMO_PICK_PX = 32
local ROT_GIZMO_RADIUS_SCALE = 0.88
local DRAG_START_PX_SQ = 4
local STREAM_INTERVAL = 0.08

surface.CreateFont("EVO_ConfigPos_HUD", { font = "Trebuchet MS", size = 16, weight = 600 })
surface.CreateFont("EVO_ConfigPos_Lab", { font = "Trebuchet MS", size = 14, weight = 500 })
surface.CreateFont("EVO_ConfigPos_Gizmo", { font = "Trebuchet MS", size = 13, weight = 700 })

local function itemOrigin(it)
	if not it then return nil end
	if isDomeItem(it) and it.mins and it.maxs then
		local c = boxToDome(it.mins, it.maxs)
		return c
	end
	if it.kind == KIND.BOX and it.mins and it.maxs then
		return (it.mins + it.maxs) * 0.5
	end
	return it.pos
end

local function catOn(it)
	return CatsOn[it.cat] ~= false
end

local function itemVisible(it)
	if not catOn(it) then return false end
	local p = EVO_ConfigPos.Providers[it.provider]
	if p and p.hidden then return false end
	if it.cat == "quetes" then
		if p and p.questGiverType then return true end
		return it.provider == SelProvider
	end
	return true
end

local function findItem(provider, id)
	for _, it in ipairs(Items) do
		if it.provider == provider and it.id == id then return it end
	end
end

local function selectedKey()
	if not Selected then return nil end
	return Selected.provider .. "\0" .. Selected.id
end

local function restoreSelection(key)
	if not key then return end
	local p, id = string.match(key, "^(.*)\0(.*)$")
	if p then Selected = findItem(p, id) end
end

local function contextOpen()
	return MUGEN and MUGEN.IsContextMenuOpen and MUGEN.IsContextMenuOpen()
end

local function overEditorPanel()
	if not IsValid(EditorPanel) then return false end
	local p = vgui.GetHoveredPanel()
	while IsValid(p) do
		if p == EditorPanel then return true end
		p = p:GetParent()
	end
	return false
end

local function overContextChrome()
	if overEditorPanel() then return true end
	local p = vgui.GetHoveredPanel()
	if not IsValid(p) then return false end
	if p.ClassName == "LZY:ContextMenu" then return false end
	local cur = p
	while IsValid(cur) do
		if cur.ClassName == "LZY:ContextMenu" then
			return true
		end
		cur = cur:GetParent()
	end
	return false
end

local function distPointSq(px, py, x, y)
	local ax, ay = px - x, py - y
	return ax * ax + ay * ay
end

local function distPointToSegmentSq(px, py, x1, y1, x2, y2)
	local dx, dy = x2 - x1, y2 - y1
	local lenSq = dx * dx + dy * dy
	if lenSq < 1e-6 then return distPointSq(px, py, x1, y1) end
	local t = math.Clamp(((px - x1) * dx + (py - y1) * dy) / lenSq, 0, 1)
	return distPointSq(px, py, x1 + dx * t, y1 + dy * t)
end

local function getGizmoWorldFrame(it)
	local origin = itemOrigin(it)
	if not origin then return nil end
	local camPos = EyePos()
	local arm = math.Clamp(origin:Distance(camPos) * 0.075, 24, 80)
	return {
		origin = origin,
		right = Vector(1, 0, 0),
		forward = Vector(0, 1, 0),
		up = Vector(0, 0, 1),
		arm = arm,
		camPos = camPos,
	}
end

local function getGizmoAxisWorldDir(frame, axis)
	if axis == 1 then return frame.right end
	if axis == 2 then return frame.forward end
	return frame.up
end

local function getGizmoRotatePlaneAxes(frame, axis)
	if axis == 1 then return frame.forward, frame.up end
	if axis == 2 then return frame.right, frame.up end
	return frame.right, frame.forward
end

local function getGizmoRingEdgeOn(frame, axis)
	if not frame or not frame.camPos then return 0 end
	local axisDir = getGizmoAxisWorldDir(frame, axis)
	local viewDir = (frame.camPos - frame.origin)
	if viewDir:LengthSqr() < 1e-6 then return 0 end
	viewDir:Normalize()
	return math.abs(axisDir:Dot(viewDir))
end

local function buildGizmoMoveScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end
	local cache = { kind = "move", origin = { x = originScr.x, y = originScr.y }, axes = {}, arm = frame.arm }
	for axis = 1, 3 do
		local dir = getGizmoAxisWorldDir(frame, axis)
		local endScr = (frame.origin + dir * frame.arm):ToScreen()
		if endScr.visible then
			cache.axes[axis] = { x1 = originScr.x, y1 = originScr.y, x2 = endScr.x, y2 = endScr.y }
		end
	end
	return cache
end

local function buildGizmoRotateScreenCache(frame)
	if not frame then return nil end
	local originScr = frame.origin:ToScreen()
	if not originScr.visible then return nil end
	local cache = { kind = "rotate", origin = { x = originScr.x, y = originScr.y }, rings = {}, arm = frame.arm }
	local radius = frame.arm * ROT_GIZMO_RADIUS_SCALE
	for axis = 1, 3 do
		local u, v = getGizmoRotatePlaneAxes(frame, axis)
		local points, segs = {}, {}
		local faceOn = 1 - getGizmoRingEdgeOn(frame, axis)
		local alpha = math.floor(Lerp(getGizmoRingEdgeOn(frame, axis), 255, 72))
		local su = (frame.origin + u * radius):ToScreen()
		local sv = (frame.origin + v * radius):ToScreen()
		for i = 0, ROT_GIZMO_SEGMENTS - 1 do
			local t0 = (i / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local t1 = ((i + 1) / ROT_GIZMO_SEGMENTS) * math.pi * 2
			local w0 = frame.origin + (u * math.cos(t0) + v * math.sin(t0)) * radius
			local w1 = frame.origin + (u * math.cos(t1) + v * math.sin(t1)) * radius
			local s0, s1 = w0:ToScreen(), w1:ToScreen()
			points[#points + 1] = { x = s0.x, y = s0.y, visible = s0.visible }
			if s0.visible or s1.visible then
				segs[#segs + 1] = { x1 = s0.x, y1 = s0.y, x2 = s1.x, y2 = s1.y, visible = s0.visible and s1.visible }
			end
		end
		cache.rings[axis] = {
			points = points, segs = segs, alpha = alpha, faceOn = faceOn,
			basis = { ux = su.x - originScr.x, uy = su.y - originScr.y, vx = sv.x - originScr.x, vy = sv.y - originScr.y },
		}
	end
	return cache
end

local function pickGizmoMoveFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= GIZMO_CENTER_PICK_PX * GIZMO_CENTER_PICK_PX then
		return 0
	end
	local bestPick, bestScore = nil, GIZMO_PICK_PX * GIZMO_PICK_PX
	for axis = 1, 3 do
		local seg = cache.axes[axis]
		if seg then
			local distSq = distPointToSegmentSq(mx, my, seg.x1, seg.y1, seg.x2, seg.y2)
			if distSq < bestScore then
				bestScore, bestPick = distSq, axis
			end
		end
	end
	return bestPick
end

local function distToRingCurveSq(mx, my, origin, ring)
	if not ring or not ring.basis or not origin then return math.huge end
	local best = math.huge
	for i = 0, ROT_GIZMO_PICK_SAMPLES - 1 do
		local t = (i / ROT_GIZMO_PICK_SAMPLES) * math.pi * 2
		local px = origin.x + ring.basis.ux * math.cos(t) + ring.basis.vx * math.sin(t)
		local py = origin.y + ring.basis.uy * math.cos(t) + ring.basis.vy * math.sin(t)
		local d = distPointSq(mx, my, px, py)
		if d < best then best = d end
	end
	return best
end

local function pickGizmoRotateFromCache(mx, my, cache)
	if not cache or not cache.origin then return nil end
	local centerPickPx = GIZMO_CENTER_PICK_PX + R(4)
	if distPointSq(mx, my, cache.origin.x, cache.origin.y) <= centerPickPx * centerPickPx then
		return 0
	end
	local pickPx = ROT_GIZMO_PICK_PX + R(4)
	local bestPick, bestScore = nil, math.huge
	for axis = 1, 3 do
		local ring = cache.rings and cache.rings[axis]
		if ring then
			local distSq = distToRingCurveSq(mx, my, cache.origin, ring)
			local faceOn = ring.faceOn or 0.5
			local pickBonus = (1 - faceOn) * pickPx * 0.75
			local threshold = (pickPx + pickBonus) * (pickPx + pickBonus)
			if distSq <= threshold then
				local score = distSq / (0.15 + faceOn * 0.85)
				if score < bestScore then
					bestScore, bestPick = score, axis
				end
			end
		end
	end
	return bestPick
end

local function pickGizmoFromCache(mx, my, cache)
	if cache and cache.kind == "rotate" then
		return pickGizmoRotateFromCache(mx, my, cache)
	end
	return pickGizmoMoveFromCache(mx, my, cache)
end

local function axisDragDeltaFromCache(axis, dx, dy, cache)
	local seg = cache and cache.axes[axis]
	if not seg then return 0 end
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.sqrt(sx * sx + sy * sy)
	if len < 0.01 then return 0 end
	sx, sy = sx / len, sy / len
	return ((dx * sx + dy * sy) / len) * (cache.arm or 0)
end

local function ringDragAngleFromCache(mx, my, ax, ay, cache)
	if not cache or not cache.origin then return 0 end
	local cx, cy = cache.origin.x, cache.origin.y
	local delta = math.deg(math.atan2(my - cy, mx - cx) - math.atan2(ay - cy, ax - cx))
	if delta > 180 then delta = delta - 360
	elseif delta < -180 then delta = delta + 360 end
	return delta
end

local function drawWorldGizmoAxisFromCache(seg, col, highlight, label)
	if not seg then return end
	local drawCol = highlight and COL_TITLE or col
	surface.SetDrawColor(drawCol)
	surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
	local sx, sy = seg.x2 - seg.x1, seg.y2 - seg.y1
	local len = math.max(math.sqrt(sx * sx + sy * sy), 0.01)
	sx, sy = sx / len, sy / len
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) + sy * R(4), seg.y2 - sy * R(7) - sx * R(4))
	surface.DrawLine(seg.x2, seg.y2, seg.x2 - sx * R(7) - sy * R(4), seg.y2 - sy * R(7) + sx * R(4))
	if label then
		draw.SimpleText(label, "EVO_ConfigPos_Gizmo", seg.x2 + sx * R(10), seg.y2 + sy * R(10), drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local function drawWorldGizmoRingFromCache(ring, col, highlight, label)
	if not ring or not ring.segs then return end
	local alpha = ring.alpha or 255
	local drawCol = highlight and COL_TITLE or ColorAlpha(col, alpha)
	surface.SetDrawColor(drawCol)
	for _, seg in ipairs(ring.segs) do
		if seg.visible ~= false then
			surface.DrawLine(seg.x1, seg.y1, seg.x2, seg.y2)
		end
	end
	if label and ring.points then
		local pt = ring.points[math.floor(#ring.points * 0.125) + 1] or ring.points[1]
		if pt then
			draw.SimpleText(label, "EVO_ConfigPos_Gizmo", pt.x, pt.y, drawCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

local function boxHitScreen(it, mx, my)
	if it.kind ~= KIND.BOX or not it.mins or not it.maxs then return false end
	local a, b = it.mins, it.maxs
	local minx, miny, maxx, maxy
	local any
	for _, x in ipairs({ a.x, b.x }) do
		for _, y in ipairs({ a.y, b.y }) do
			for _, z in ipairs({ a.z, b.z }) do
				local s = Vector(x, y, z):ToScreen()
				if s.visible then
					any = true
					minx = minx and math.min(minx, s.x) or s.x
					miny = miny and math.min(miny, s.y) or s.y
					maxx = maxx and math.max(maxx, s.x) or s.x
					maxy = maxy and math.max(maxy, s.y) or s.y
				end
			end
		end
	end
	if not any then return false end
	local pad = 28
	return mx >= minx - pad and mx <= maxx + pad and my >= miny - pad and my <= maxy + pad
end

local function pickItem(mx, my)
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil end
	local eye = lp:EyePos()
	local best, bestD
	for _, it in ipairs(Items) do
		if not itemVisible(it) then continue end
		local o = itemOrigin(it)
		if not o or eye:DistToSqr(o) > MARKER_DIST_SQR then continue end
		local s = o:ToScreen()
		if not s.visible then continue end
		local d = distPointSq(mx, my, s.x, s.y)
		local lim = MARKER_PICK_PX * MARKER_PICK_PX
		if it.kind == KIND.BOX and boxHitScreen(it, mx, my) then
			d = math.min(d, lim * 0.25)
		end
		if d < lim and (not bestD or d < bestD) then
			best, bestD = it, d
		end
	end
	return best
end

local function pickBoxCorner(mx, my)
	if not Selected or Selected.kind ~= KIND.BOX then return nil end
	local best, bestD
	for _, h in ipairs({ { id = "cmin", pos = Selected.mins }, { id = "cmax", pos = Selected.maxs } }) do
		if h.pos then
			local s = h.pos:ToScreen()
			if s.visible then
				local d = distPointSq(mx, my, s.x, s.y)
				if d < (22 * 22) and (not bestD or d < bestD) then
					best, bestD = h.id, d
				end
			end
		end
	end
	return best
end

local function moveTagged(field, want, pos, ang)
	if want == nil then return nil end
	for _, e in ipairs(ents.GetAll()) do
		if IsValid(e) and e[field] == want then
			if EVO_ConfigPos.TeleportFrozen then
				EVO_ConfigPos.TeleportFrozen(e, pos, ang)
			else
				e:SetPos(pos)
				if ang then e:SetAngles(ang) end
			end
			return e
		end
	end
end

local function moveByModel(mdl, pos, ang, sticky)
	if IsValid(sticky) then
		if EVO_ConfigPos.TeleportFrozen then
			EVO_ConfigPos.TeleportFrozen(sticky, pos, ang)
		else
			sticky:SetPos(pos)
			if ang then sticky:SetAngles(ang) end
		end
		return sticky
	end
	if not (isstring(mdl) and mdl ~= "") then return nil end
	local best, bestD
	for _, e in ipairs(ents.GetAll()) do
		if IsValid(e) and e:GetModel() == mdl then
			local d = e:GetPos():DistToSqr(pos)
			if not bestD or d < bestD then
				best, bestD = e, d
			end
		end
	end
	if not IsValid(best) then return nil end
	if EVO_ConfigPos.TeleportFrozen then
		EVO_ConfigPos.TeleportFrozen(best, pos, ang)
	else
		best:SetPos(pos)
		if ang then best:SetAngles(ang) end
	end
	return best
end

local function previewEnt(it)
	if not it or it.kind == KIND.BOX or not isvector(it.pos) then return end
	if it.provider == "craft_assassin" or it.provider == "craft_soin" or it.provider == "craft_combat" then
		local n = tonumber(string.match(it.id or "", "^model:(%d+)$"))
		if n then
			local e = moveTagged("_evoCraftStation", n, it.pos, it.ang)
			if not IsValid(e) then
				e = moveByModel(it.entClass, it.pos, it.ang, Drag and Drag.ent)
				if Drag then Drag.ent = e end
			end
		end
		return
	end
	if it.provider == "craft_coffres" then
		moveTagged("_evoCoffreIdx", tonumber(it.id), it.pos, it.ang)
		return
	end
	if it.provider == "sci_etablie_01" or it.provider == "sci_etablie_02" or it.provider == "sci_etablie_03" then
		local n = tonumber(string.match(it.id or "", "^model:(%d+)$"))
		if n then moveTagged("_evoSciEtablie", n, it.pos, it.ang) end
		return
	end
	if it.provider == "quest_boards" then
		moveTagged("_ncmQuestBoardIdx", tonumber(it.id), it.pos, it.ang)
		return
	end
	if it.provider == "map_boards" then
		moveTagged("_evoCarteIdx", tonumber(it.id), it.pos, it.ang)
		return
	end
	if it.provider == "livre_decor" then
		moveTagged("_evoLivreDecorId", tonumber(it.id), it.pos, it.ang)
		return
	end
	if it.provider == "missive_desk" then
		local e = moveTagged("_evoMissiveDeskIdx", tonumber(it.id), it.pos, it.ang)
		if not IsValid(e) then
			e = moveByModel(it.entClass, it.pos, it.ang, Drag and Drag.ent)
			if Drag then Drag.ent = e end
		end
		return
	end
	if it.provider == "domaine_emplacements" then
		local e = moveTagged("_EvoClanPorte", it.id, it.pos, it.ang)
		if not IsValid(e) then
			e = moveByModel(it.entClass, it.pos, it.ang, Drag and Drag.ent)
			if Drag then Drag.ent = e end
		end
		return
	end
	if it.provider == "world_models" then
		local e = moveTagged("_evoWorldModel", it.id, it.pos, it.ang)
			or moveTagged("_evoWorldModel", tonumber(it.id), it.pos, it.ang)
		if IsValid(e) then
			e:SetModelScale(EVO_ConfigPos.ClampScale(it.scale), 0)
		end
		return
	end
	if it.provider == "quete_givers" or it.provider == "quete_prog_givers"
		or (EVO_ConfigPos.Providers[it.provider] and EVO_ConfigPos.Providers[it.provider].questGiverType) then
		local pnjType = (EVO_ConfigPos.Providers[it.provider] and EVO_ConfigPos.Providers[it.provider].questGiverType) or it.id
		for _, e in ipairs(ents.FindByClass("ncm_npc_questgiver")) do
			if IsValid(e) and e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == pnjType then
				if EVO_ConfigPos.TeleportFrozen then
					EVO_ConfigPos.TeleportFrozen(e, it.pos, it.ang)
				else
					e:SetPos(it.pos)
					if it.ang then e:SetAngles(it.ang) end
				end
				return
			end
		end
		return
	end
	if it.entClass and it.entClass ~= "" and EVO_ConfigPos.MoveByClass then
		EVO_ConfigPos.MoveByClass(it.entClass, it.id, it.pos, it.ang)
		return
	end
	if it.provider == "maitrise_npc" then
		for _, e in ipairs(ents.GetAll()) do
			if IsValid(e) and e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == "weapon_training" then
				if EVO_ConfigPos.TeleportFrozen then
					EVO_ConfigPos.TeleportFrozen(e, it.pos, it.ang)
				else
					e:SetPos(it.pos)
					if it.ang then e:SetAngles(it.ang) end
				end
				return
			end
		end
	end
end

local function applyNow(it)
	if not it then return end
	EVO_ConfigPos.ApplyItem(game.GetMap(), it.provider, it.id, it)
	previewEnt(it)
end

-- netgate: edge
local function sendSet(it)
	net.Start("EVO_ConfigPos:Set")
		net.WriteString(it.provider)
		net.WriteString(it.id)
		EVO_ConfigPos.WriteData(it)
	net.SendToServer()
end

-- netgate: stream
local function sendSetLive(it)
	net.Start("EVO_ConfigPos:Set")
		net.WriteString(it.provider)
		net.WriteString(it.id)
		EVO_ConfigPos.WriteData(it)
	net.SendToServer()
end

-- netgate: edge
local function sendReset(it)
	net.Start("EVO_ConfigPos:Reset")
		net.WriteString(it.provider)
		net.WriteString(it.id)
	net.SendToServer()
end

-- netgate: edge
local function sendPrint()
	net.Start("EVO_ConfigPos:Print")
	net.SendToServer()
end

-- netgate: edge
local function sendExport()
	net.Start("EVO_ConfigPos:Export")
	net.SendToServer()
end

local function currentWorldModel()
	if IsValid(EditorPanel) and IsValid(EditorPanel._modelPath) then
		local v = EditorPanel._modelPath:GetValue()
		if isstring(v) and v ~= "" then return v end
	end
	if isstring(EVO_ConfigPos.PendingWorldModel) and EVO_ConfigPos.PendingWorldModel ~= "" then
		return EVO_ConfigPos.PendingWorldModel
	end
	local pre = EVO_ConfigPos.WorldModelPresets and EVO_ConfigPos.WorldModelPresets[1]
	return (pre and pre.model) or ""
end

-- netgate: edge
local function sendAdd(provider)
	local model = ""
	if provider == "world_models" or provider == "livre_decor" then
		model = currentWorldModel()
		EVO_ConfigPos.PendingWorldModel = model
	elseif provider == "flag_zones" then
		model = isstring(EVO_ConfigPos.PendingFlagName) and EVO_ConfigPos.PendingFlagName or ""
		EVO_ConfigPos.PendingFlagName = nil
	elseif provider == "boss_spawns" then
		model = isstring(EVO_ConfigPos.PendingBossName) and EVO_ConfigPos.PendingBossName or ""
		EVO_ConfigPos.PendingBossName = nil
	elseif provider == "bar_distillerie" or provider == "bar_coffre" then
		model = isstring(EVO_ConfigPos.PendingBusiness) and EVO_ConfigPos.PendingBusiness or "bar"
	end
	net.Start("EVO_ConfigPos:Add")
		net.WriteString(provider)
		net.WriteString((Selected and Selected.id) or "")
		net.WriteString(model)
	net.SendToServer()
end

-- netgate: edge
local function sendRemove(it)
	net.Start("EVO_ConfigPos:Remove")
		net.WriteString(it.provider)
		net.WriteString(it.id)
	net.SendToServer()
end

local function finishDrag()
	if not Drag then return end
	local it = Drag.item
	Drag = nil
	if it then
		applyNow(it)
		sendSet(it)
	end
end

local function applyPick(mx, my)
	if not Active or not contextOpen() then return false end
	local modeHit = hitModeButton(mx, my)
	if modeHit then
		Mode = modeHit
		return true
	end
	if overContextChrome() then return false end

	if Selected and itemVisible(Selected) then
		local corner = pickBoxCorner(mx, my)
		if corner then
			Drag = {
				item = Selected,
				handle = corner,
				axis = 0,
				startPos = Selected.pos and Vector(Selected.pos.x, Selected.pos.y, Selected.pos.z) or nil,
				startMins = Selected.mins and Vector(Selected.mins.x, Selected.mins.y, Selected.mins.z) or nil,
				startMaxs = Selected.maxs and Vector(Selected.maxs.x, Selected.maxs.y, Selected.maxs.z) or nil,
				startAng = Selected.ang and Angle(Selected.ang.p, Selected.ang.y, Selected.ang.r) or nil,
				startScale = tonumber(Selected.scale) or 1,
				anchorX = mx, anchorY = my,
				ready = false,
				cache = GizmoScreen,
			}
			return true
		end
		local cache = GizmoScreen
		if cache then
			local pick = pickGizmoFromCache(mx, my, cache)
			if pick ~= nil then
				Drag = {
					item = Selected,
					handle = "gizmo",
					axis = pick,
					startPos = Selected.pos and Vector(Selected.pos.x, Selected.pos.y, Selected.pos.z) or nil,
					startMins = Selected.mins and Vector(Selected.mins.x, Selected.mins.y, Selected.mins.z) or nil,
					startMaxs = Selected.maxs and Vector(Selected.maxs.x, Selected.maxs.y, Selected.maxs.z) or nil,
					startAng = Selected.ang and Angle(Selected.ang.p, Selected.ang.y, Selected.ang.r) or nil,
					startScale = tonumber(Selected.scale) or 1,
					anchorX = mx, anchorY = my,
					ready = false,
					cache = cache,
				}
				return true
			end
		end
	end

	local it = pickItem(mx, my)
	if it then
		Selected = it
		SelCat = it.cat or SelCat
		SelProvider = it.provider
		if rebuildEditorPanel then rebuildEditorPanel() end
		return true
	end
	return false
end

local function updateDrag()
	if not Drag or not Drag.item then return end
	local it = Drag.item
	local mx, my = gui.MousePos()
	local dx, dy = mx - Drag.anchorX, my - Drag.anchorY
	if not Drag.ready then
		if (dx * dx + dy * dy) < DRAG_START_PX_SQ then return end
		Drag.ready = true
	end

	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	if Drag.handle == "cmin" or Drag.handle == "cmax" then
		local right, up = lp:EyeAngles():Right(), lp:EyeAngles():Up()
		local origin = itemOrigin(it)
		local scale = (origin and origin:Distance(lp:EyePos()) or 200) * 0.0022
		local delta = right * (dx * scale) - up * (dy * scale)
		if Drag.handle == "cmin" and Drag.startMins then
			it.mins = Drag.startMins + delta
		elseif Drag.handle == "cmax" and Drag.startMaxs then
			it.maxs = Drag.startMaxs + delta
		end
	else
		local cache = GizmoScreen or Drag.cache
		if isDomeItem(it) and Drag.startMins and Drag.startMaxs and (Mode == "scale" or Mode == "rotate") then
			local c, r0, h0 = boxToDome(Drag.startMins, Drag.startMaxs)
			if Mode == "scale" then
				if Drag.axis == 0 then
					local f = math.exp(-dy * 0.008)
					it.mins, it.maxs = boxFromDome(c, r0 * f, h0 * f)
				elseif Drag.axis == 3 then
					local along = axisDragDeltaFromCache(3, dx, dy, cache)
					it.mins, it.maxs = boxFromDome(c, r0, h0 + along)
				else
					local along = axisDragDeltaFromCache(Drag.axis, dx, dy, cache)
					it.mins, it.maxs = boxFromDome(c, r0 + along, h0)
				end
			else
				local delta = 0
				if Drag.axis == 0 then
					delta = -dy * 0.35
				else
					delta = ringDragAngleFromCache(mx, my, Drag.anchorX, Drag.anchorY, cache)
				end
				local f = math.exp(delta * 0.012)
				if Drag.axis == 2 then
					it.mins, it.maxs = boxFromDome(c, r0, h0 * f)
				else
					it.mins, it.maxs = boxFromDome(c, r0 * f, h0)
				end
			end
		elseif Mode == "scale" and canScaleItem(it) then
			it.scale = EVO_ConfigPos.ClampScale((Drag.startScale or 1) * math.exp(-dy * 0.01))
		elseif Mode == "rotate" and it.kind == KIND.POINT_ANG and Drag.startAng then
			if Drag.axis == 0 then
				it.ang = Angle(Drag.startAng.p - dy * 0.35, Drag.startAng.y + dx * 0.35, Drag.startAng.r)
			else
				local delta = ringDragAngleFromCache(mx, my, Drag.anchorX, Drag.anchorY, cache)
				if Drag.axis == 1 then
					it.ang = Angle(Drag.startAng.p, Drag.startAng.y, Drag.startAng.r + delta)
				elseif Drag.axis == 2 then
					it.ang = Angle(Drag.startAng.p + delta, Drag.startAng.y, Drag.startAng.r)
				else
					it.ang = Angle(Drag.startAng.p, Drag.startAng.y + delta, Drag.startAng.r)
				end
			end
		elseif Drag.axis == 0 then
			local right, up = lp:EyeAngles():Right(), lp:EyeAngles():Up()
			local origin = itemOrigin(it)
			local scale = (origin and origin:Distance(lp:EyePos()) or 200) * 0.0022
			local delta = right * (dx * scale) - up * (dy * scale)
			if it.kind == KIND.BOX and Drag.startMins and Drag.startMaxs then
				it.mins = Drag.startMins + delta
				it.maxs = Drag.startMaxs + delta
			elseif Drag.startPos then
				it.pos = Drag.startPos + delta
			end
		else
			local along = axisDragDeltaFromCache(Drag.axis, dx, dy, cache)
			local dir = Drag.axis == 1 and Vector(1, 0, 0) or (Drag.axis == 2 and Vector(0, 1, 0) or Vector(0, 0, 1))
			local delta = dir * along
			if it.kind == KIND.BOX and Drag.startMins and Drag.startMaxs then
				it.mins = Drag.startMins + delta
				it.maxs = Drag.startMaxs + delta
			elseif Drag.startPos then
				it.pos = Drag.startPos + delta
			end
		end
	end

	applyNow(it)
	if CurTime() >= LastStream + STREAM_INTERVAL then
		LastStream = CurTime()
		sendSetLive(it)
	end
end

function EVO_ConfigPos.TryContextClick(code)
	if not Active then return false end
	if code == MOUSE_LEFT then
		return applyPick(gui.MousePos())
	end
	if code == MOUSE_RIGHT and Selected then
		Selected = nil
		if rebuildEditorPanel then rebuildEditorPanel() end
		return true
	end
	return false
end

hook.Add("GUIMousePressed", "EVO_ConfigPos::PriorityClick", function(code)
	if not Active then return end
	if code == MOUSE_LEFT and applyPick(gui.MousePos()) then
		return true
	end
	if code == MOUSE_RIGHT and Selected and not overContextChrome() then
		Selected = nil
		if rebuildEditorPanel then rebuildEditorPanel() end
		return true
	end
end)

local function edgeKey(key)
	local down = input.IsKeyDown(key)
	local was = KeyWas[key]
	KeyWas[key] = down
	return down and not was
end

local function isTypingFocus()
	if gui.IsConsoleVisible() or gui.IsGameUIVisible() then return true end
	local kb = vgui.GetKeyboardFocus()
	if not IsValid(kb) or not kb.GetClassName then return false end
	return kb:GetClassName() == "TextEntry"
end

local lastModeCycle = 0
local function cycleMode()
	if not Active then return end
	if isTypingFocus() then return end
	local now = RealTime()
	if now - lastModeCycle < 0.12 then return end
	lastModeCycle = now

	local modes = Selected and validModes(Selected) or { "move", "rotate" }
	local idx = 1
	for i, m in ipairs(modes) do
		if m == Mode then
			idx = i
			break
		end
	end
	Mode = modes[(idx % #modes) + 1]
end

hook.Add("Think", "EVO_ConfigPos::Think", function()
	if not Active then
		if Drag then finishDrag() end
		MouseWasDown = false
		return
	end

	local down = input.IsMouseDown(MOUSE_LEFT)
	if contextOpen() then
		if down and not MouseWasDown then
			applyPick(gui.MousePos())
		end
		if Drag then
			if not down then
				finishDrag()
			else
				updateDrag()
			end
		end
	elseif Drag then
		finishDrag()
	end
	MouseWasDown = down

	syncEditorPanelVis()

	-- MakePopup du menu C mute IsKeyDown / PlayerButtonDown. IsButtonDown = état brut.
	local rDown = input.IsButtonDown(KEY_R)
	if rDown and not KeyWas[KEY_R] then
		cycleMode()
	end
	KeyWas[KEY_R] = rDown
	if contextOpen() and canScaleItem(Selected) and not overEditorPanel() then
		local dome = isDomeItem(Selected)
		if edgeKey(KEY_RBRACKET) then
			if dome then nudgeDome(Selected, 1.1, 1.1) else
				Selected.scale = EVO_ConfigPos.ClampScale((tonumber(Selected.scale) or 1) * 1.1)
			end
			applyNow(Selected)
			sendSet(Selected)
		elseif edgeKey(KEY_LBRACKET) then
			if dome then nudgeDome(Selected, 1 / 1.1, 1 / 1.1) else
				Selected.scale = EVO_ConfigPos.ClampScale((tonumber(Selected.scale) or 1) / 1.1)
			end
			applyNow(Selected)
			sendSet(Selected)
		elseif input.WasMousePressed(MOUSE_WHEEL_UP) then
			if dome then nudgeDome(Selected, 1.08, 1.08) else
				Selected.scale = EVO_ConfigPos.ClampScale((tonumber(Selected.scale) or 1) * 1.08)
			end
			applyNow(Selected)
			sendSet(Selected)
		elseif input.WasMousePressed(MOUSE_WHEEL_DOWN) then
			if dome then nudgeDome(Selected, 1 / 1.08, 1 / 1.08) else
				Selected.scale = EVO_ConfigPos.ClampScale((tonumber(Selected.scale) or 1) / 1.08)
			end
			applyNow(Selected)
			sendSet(Selected)
		end
	end
	if contextOpen() and Selected and edgeKey(KEY_BACKSPACE) then
		sendReset(Selected)
	end
	if contextOpen() and edgeKey(KEY_P) then
		sendPrint()
	end
	if contextOpen() and edgeKey(KEY_E) then
		sendExport()
	end
end)

hook.Remove("PlayerButtonDown", "EVO_ConfigPos::ModeKey")
hook.Remove("CreateMove", "EVO_ConfigPos::ModeKey")

hook.Add("OnContextMenuOpen", "EVO_ConfigPos::ShowPanel", function()
	if Active then showEditorPanel() end
end)

hook.Add("OnContextMenuClose", "EVO_ConfigPos::EndDrag", function()
	finishDrag()
	hideEditorPanel()
end)

hook.Add("GUIMouseReleased", "EVO_ConfigPos::Release", function(code)
	if code == MOUSE_LEFT then finishDrag() end
end)

local function drawBox(mins, maxs, colFill, colLine)
	render.SetColorMaterial()
	render.DrawBox(vector_origin, angle_zero, mins, maxs, colFill, true)
	render.DrawWireframeBox(vector_origin, angle_zero, mins, maxs, colLine, true)
end

local function hemiPoint(center, radius, height, lat, lon)
	local c = math.cos(lat)
	return Vector(
		center.x + radius * c * math.cos(lon),
		center.y + radius * c * math.sin(lon),
		center.z + height * math.sin(lat)
	)
end

local function drawDome(mins, maxs, colLine)
	local center, radius, height = boxToDome(mins, maxs)
	if EVO_BATAILLE and EVO_BATAILLE.DrawHemiSphere then
		EVO_BATAILLE.DrawHemiSphere(center, radius, height)
		return
	end
	local col = colLine or COL_BOX_LINE
	local segs = 24
	local meridians = 8
	local twoPi = math.pi * 2
	local halfPi = math.pi * 0.5
	local prev
	for i = 0, segs do
		local p = hemiPoint(center, radius, height, 0, (i / segs) * twoPi)
		if prev then render.DrawLine(prev, p, col, true) end
		prev = p
	end
	for mi = 0, meridians - 1 do
		local lon = (mi / meridians) * twoPi
		prev = nil
		for li = 0, 8 do
			local p = hemiPoint(center, radius, height, (li / 8) * halfPi, lon)
			if prev then render.DrawLine(prev, p, col, true) end
			prev = p
		end
	end
end

hook.Add("PostDrawTranslucentRenderables", "EVO_ConfigPos::World", function()
	if not Active then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local eye = lp:EyePos()
	local sel = Selected

	for _, it in ipairs(Items) do
		if not itemVisible(it) then continue end
		local o = itemOrigin(it)
		if not o or eye:DistToSqr(o) > MARKER_DIST_SQR then continue end
		local isSel = sel and sel.provider == it.provider and sel.id == it.id
		if it.kind == KIND.BOX then
			if DOME_PROVIDERS[it.provider] then
				drawDome(it.mins, it.maxs, isSel and COL_SEL or COL_BOX_LINE)
			else
				drawBox(it.mins, it.maxs, isSel and Color(255, 220, 80, 35) or COL_BOX, isSel and COL_SEL or COL_BOX_LINE)
			end
			if isSel then
				cam.IgnoreZ(true)
				render.DrawWireframeSphere(it.mins, 8, 8, 8, AXIS_COLORS[1], true)
				render.DrawWireframeSphere(it.maxs, 8, 8, 8, AXIS_COLORS[3], true)
				cam.IgnoreZ(false)
			end
		else
			local s = isSel and 12 or 10
			local questNpc = EVO_ConfigPos.Providers[it.provider] and EVO_ConfigPos.Providers[it.provider].questGiverType
			if questNpc then cam.IgnoreZ(true) end
			render.DrawWireframeBox(o, angle_zero, Vector(-s, -s, -s), Vector(s, s, s), isSel and COL_SEL or COL_MARK, true)
			if it.ang then
				render.DrawLine(o, o + it.ang:Forward() * 36, Color(255, 180, 60), true)
			end
			if questNpc then cam.IgnoreZ(false) end
		end
	end
end)

local function paintWorldGizmo(mx, my)
	if not (Selected and itemVisible(Selected)) then
		GizmoFrame, GizmoScreen, HoverPick = nil, nil, nil
		return
	end
	local modes = validModes(Selected)
	local ok = false
	for _, m in ipairs(modes) do
		if m == Mode then ok = true break end
	end
	if not ok then Mode = "move" end
	GizmoFrame = getGizmoWorldFrame(Selected)
	if not GizmoFrame then
		GizmoScreen, HoverPick = nil, nil
		return
	end
	if Mode == "rotate" and canRotateItem(Selected) then
		GizmoScreen = buildGizmoRotateScreenCache(GizmoFrame)
	else
		GizmoScreen = buildGizmoMoveScreenCache(GizmoFrame)
	end
	local cache = GizmoScreen
	if not cache then
		HoverPick = nil
		return
	end
	HoverPick = pickGizmoFromCache(mx, my, cache)
	local activePick = Drag and Drag.axis or nil
	local ox, oy = cache.origin.x, cache.origin.y
	local centerHl = HoverPick == 0 or activePick == 0
	local centerR = R(centerHl and 9 or 7)
	draw.RoundedBox(centerR, ox - centerR, oy - centerR, centerR * 2, centerR * 2,
		centerHl and COL_TITLE or ColorAlpha(COL_TITLE, 180))
	surface.SetDrawColor(COL_BG)
	surface.DrawRect(ox - R(3), oy - R(3), R(6), R(6))

	local labels = (cache.kind == "rotate") and ROT_NAMES or AXIS_NAMES
	if isDomeItem(Selected) then
		if cache.kind == "rotate" then
			labels = { "Rayon", "Hauteur", "Rayon" }
		elseif Mode == "scale" then
			labels = { "Rayon", "Rayon", "Hauteur" }
		end
	end
	if cache.kind == "rotate" then
		for axis = 1, 3 do
			drawWorldGizmoRingFromCache(cache.rings[axis], AXIS_COLORS[axis], HoverPick == axis or activePick == axis, labels[axis])
		end
	else
		for axis = 1, 3 do
			local col = AXIS_COLORS[axis]
			if Mode == "scale" then col = Color(255, 200, 70) end
			drawWorldGizmoAxisFromCache(cache.axes[axis], col, HoverPick == axis or activePick == axis, labels[axis])
		end
	end
end

local function drawModePills(x, y)
	ModeBtns = {}
	surface.SetFont("EVO_ConfigPos_HUD")
	local allowed = {}
	for _, m in ipairs(Selected and validModes(Selected) or { "move", "rotate" }) do
		allowed[m] = true
	end
	local px, maxH, totalW = x, 0, -6
	for _, m in ipairs(MODE_ORDER) do
		if not allowed[m] then continue end
		local tw, th = surface.GetTextSize(MODE_LAB[m])
		local bw, bh = tw + 16, th + 8
		ModeBtns[#ModeBtns + 1] = { mode = m, x = px, y = y, w = bw, h = bh }
		local on = Mode == m
		draw.RoundedBox(4, px, y, bw, bh, on and COL_ACCENT or COL_ROW)
		draw.SimpleText(MODE_LAB[m], "EVO_ConfigPos_HUD", px + bw * 0.5, y + bh * 0.5, on and COL_TITLE or COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		px = px + bw + 6
		maxH = math.max(maxH, bh)
		totalW = totalW + bw + 6
	end
	return math.max(totalW, 0), maxH
end

hook.Add("HUDPaint", "EVO_ConfigPos::HUD", function()
	if not Active then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local eye = lp:EyePos()
	local mx, my = gui.MousePos()

	for _, it in ipairs(Items) do
		if not itemVisible(it) then continue end
		local o = itemOrigin(it)
		if not o or eye:DistToSqr(o) > LABEL_DIST_SQR then continue end
		local s = o:ToScreen()
		if not s.visible then continue end
		draw.SimpleTextOutlined(it.label, "EVO_ConfigPos_Lab", s.x, s.y - 18, COL_LAB, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(0, 0, 0, 200))
	end

	paintWorldGizmo(mx, my)

	ModeBtns = {}
	if not contextOpen() then
		local modeLabel = MODE_LAB[Mode] or "MOVE"
		local lines = {
			"MODE : " .. modeLabel,
			"CONFIG POSITIONS  —  maintiens C pour le panneau",
		}
		surface.SetFont("EVO_ConfigPos_HUD")
		local w, h = 0, 0
		for _, l in ipairs(lines) do
			local tw, th = surface.GetTextSize(l)
			w = math.max(w, tw)
			h = h + th + 2
		end
		local x, y = ScrW() - w - 24, 80
		draw.RoundedBox(6, x - 8, y - 6, w + 16, h + 12, COL_HUD)
		local yy = y
		for i, l in ipairs(lines) do
			draw.SimpleText(l, "EVO_ConfigPos_HUD", x, yy, i == 1 and COL_TITLE or COL_LAB, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			local _, th = surface.GetTextSize(l)
			yy = yy + th + 2
		end
		return
	end

	local lines = {
		"R = cycle   Backspace = origine Lua   P = dump   E = exporter",
	}
	if Selected then
		local sel = "Selection : " .. Selected.label
		if isDomeItem(Selected) then
			local _, r, h = boxToDome(Selected.mins, Selected.maxs)
			sel = sel .. string.format("  r%d  h%d", math.floor(r + 0.5), math.floor(h + 0.5))
			lines[#lines + 1] = sel
			lines[#lines + 1] = "Molette ou [ ] = echelle uniforme"
		elseif canScaleItem(Selected) then
			sel = sel .. string.format("  x%.2f", tonumber(Selected.scale) or 1)
			lines[#lines + 1] = sel
			lines[#lines + 1] = "Molette ou [ ] = echelle"
		else
			lines[#lines + 1] = sel
		end
	else
		lines[#lines + 1] = "Clic un marqueur ou une ligne pour selectionner"
	end

	surface.SetFont("EVO_ConfigPos_HUD")
	local w, h = 0, 0
	for _, l in ipairs(lines) do
		local tw, th = surface.GetTextSize(l)
		w = math.max(w, tw)
		h = h + th + 2
	end
	local pillW, pillH = 0, 28
	do
		local allowed = Selected and validModes(Selected) or { "move", "rotate" }
		local px = 0
		for _, m in ipairs(allowed) do
			local tw, th = surface.GetTextSize(MODE_LAB[m])
			px = px + tw + 16 + 6
			pillH = math.max(pillH, th + 8)
		end
		pillW = math.max(0, px - 6)
	end
	w = math.max(w, pillW)
	h = h + pillH + 8
	local x, y = ScrW() - w - 24, 80
	draw.RoundedBox(6, x - 8, y - 6, w + 16, h + 12, COL_HUD)
	drawModePills(x, y)
	local yy = y + pillH + 8
	for _, l in ipairs(lines) do
		draw.SimpleText(l, "EVO_ConfigPos_HUD", x, yy, COL_LAB, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local _, th = surface.GetTextSize(l)
		yy = yy + th + 2
	end
end)

local function styleBtn(b, col)
	b:SetTextColor(COL_TXT)
	b.Paint = function(s, w, h)
		local bg = COL_ROW
		if not s:IsEnabled() then
			bg = Color(28, 28, 34)
		elseif s:IsHovered() then
			bg = col or COL_ACCENT
		end
		draw.RoundedBox(4, 0, 0, w, h, bg)
	end
end

local function getContextFrame()
	local world = vgui.GetWorldPanel()
	if not IsValid(world) then return nil end
	for _, p in ipairs(world:GetChildren()) do
		if IsValid(p) and p.ClassName == "LZY:ContextMenu" then return p end
	end
end

local function providersInCat(cat)
	local out = {}
	for _, pid in ipairs(EVO_ConfigPos._ProviderOrder) do
		local p = EVO_ConfigPos.Providers[pid]
		if p and p.cat == cat and not p.hidden then
			out[#out + 1] = pid
		end
	end
	return out
end

local function catNeedsTypeSearch(cat)
	return cat == "quetes" or cat == "ateliers"
end

local function providerMatchesFilter(pid)
	if QuestTypeFilter == "" or not catNeedsTypeSearch(SelCat) then return true end
	local p = EVO_ConfigPos.Providers[pid]
	local hay = string.lower((p and p.label or "") .. " " .. pid)
	return string.find(hay, QuestTypeFilter, 1, true) ~= nil
end

local function ensureSelProvider()
	if SelProvider then
		local p = EVO_ConfigPos.Providers[SelProvider]
		if p and p.cat == SelCat and not p.hidden and providerMatchesFilter(SelProvider) then
			return SelProvider
		end
	end
	if Selected and Selected.cat == SelCat then
		local p = EVO_ConfigPos.Providers[Selected.provider]
		if p and not p.hidden and providerMatchesFilter(Selected.provider) then
			SelProvider = Selected.provider
			return SelProvider
		end
	end
	local list = providersInCat(SelCat)
	for _, pid in ipairs(list) do
		if providerMatchesFilter(pid) then
			SelProvider = pid
			return SelProvider
		end
	end
	SelProvider = list[1]
	return SelProvider
end

local function confirmRemove(it)
	if not it then return end
	local msg = "Supprimer « " .. (it.label or it.id) .. " » ?"
	if it.provider == "domaine_emplacements" then
		msg = msg .. "\nUn clan qui possede cet emplacement en base n'aura plus de porte.\nLes entrees Lua (s01 / h01…) ne peuvent pas etre supprimees."
	end
	Derma_Query(msg, "ConfigPos", "Supprimer", function()
		sendRemove(it)
	end, "Annuler")
end

local function countCat(cat)
	local n = 0
	for _, it in ipairs(Items) do
		if it.cat == cat then
			local p = EVO_ConfigPos.Providers[it.provider]
			if not (p and p.hidden) then
				n = n + 1
			end
		end
	end
	return n
end

local function countProv(pid)
	local n = 0
	for _, it in ipairs(Items) do
		if it.provider == pid then n = n + 1 end
	end
	return n
end

local function setAllCatsVisible(on)
	for _, c in ipairs(EVO_ConfigPos.CATS) do
		CatsOn[c.id] = on
	end
end

rebuildEditorPanel = function()
	if not IsValid(EditorPanel) then return end
	if not (IsValid(EditorPanel._cats) and IsValid(EditorPanel._types) and IsValid(EditorPanel._items)) then return end
	ensureSelProvider()
	local showModel = SelCat == "modeles"
	local showBiz = SelProvider == "bar_distillerie" or SelProvider == "bar_coffre"
	local showTypeSearch = catNeedsTypeSearch(SelCat)
	if IsValid(EditorPanel._modelPick) then
		EditorPanel._modelPick:SetVisible(showModel)
		EditorPanel._modelPick:SetTall(showModel and 52 or 0)
	end
	if IsValid(EditorPanel._bizPick) then
		EditorPanel._bizPick:SetVisible(showBiz)
		EditorPanel._bizPick:SetTall(showBiz and 52 or 0)
		if showBiz and EditorPanel._refreshBizCombo then EditorPanel._refreshBizCombo() end
	end
	if IsValid(EditorPanel._typeSearch) then
		EditorPanel._typeSearch:SetVisible(showTypeSearch)
		EditorPanel._typeSearch:SetTall(showTypeSearch and 24 or 0)
		if showTypeSearch then
			EditorPanel._typeSearch:SetPlaceholderText(SelCat == "quetes" and "Filtrer les quetes..." or "Filtrer les types...")
		end
	end
	if IsValid(EditorPanel._types) then
		local nTypes = 0
		if showModel then
			nTypes = 1 + #(EVO_ConfigPos.WorldModelPresets or {})
		else
			for _, pid in ipairs(providersInCat(SelCat)) do
				if providerMatchesFilter(pid) then
					nTypes = nTypes + 1
				end
			end
		end
		-- ~31 px par ligne (28 + marge). Ateliers a 12 types : tout doit tenir
		-- sans scroller hors écran (Moulin / Cuve / Fermenteur / Coffre du Bar).
		local maxH = showTypeSearch and 260 or 250
		local h = math.Clamp(8 + nTypes * 31, 140, maxH)
		if showModel then h = math.max(h, 168) end
		EditorPanel._types:SetTall(h)
	end
	if showModel and IsValid(EditorPanel._modelPath) and EVO_ConfigPos.PendingWorldModel then
		if EditorPanel._modelPath:GetValue() ~= EVO_ConfigPos.PendingWorldModel then
			EditorPanel._modelPath:SetValue(EVO_ConfigPos.PendingWorldModel)
		end
	end
	EditorPanel._cats:GetCanvas():Clear()
	EditorPanel._types:GetCanvas():Clear()
	EditorPanel._items:GetCanvas():Clear()

	for _, c in ipairs(EVO_ConfigPos.CATS) do
		local n = countCat(c.id)
		local row = vgui.Create("DPanel", EditorPanel._cats)
		row:Dock(TOP)
		row:DockMargin(4, 3, 4, 0)
		row:SetTall(34)
		row.Paint = function(_, w, h)
			local vis = CatsOn[c.id] ~= false
			local bg = SelCat == c.id and COL_ROWSEL or COL_ROW
			draw.RoundedBox(5, 0, 0, w, h, bg)
			if SelCat == c.id then
				draw.RoundedBox(0, 0, 0, 3, h, COL_ACCENT)
			end
			draw.SimpleText(c.label, "DermaDefaultBold", 10, h / 2 - 1, vis and COL_TXT or COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(tostring(n), "DermaDefault", w - 80, h / 2, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local vis = vgui.Create("DButton", row)
		vis:Dock(RIGHT)
		vis:DockMargin(0, 6, 6, 6)
		vis:SetWide(68)
		vis:SetText("")
		vis.Paint = function(s, w, h)
			local on = CatsOn[c.id] ~= false
			local bg = on and Color(46, 96, 62) or Color(38, 38, 44)
			if s:IsHovered() then
				bg = on and Color(56, 118, 74) or Color(52, 52, 60)
			end
			draw.RoundedBox(4, 0, 0, w, h, bg)
			draw.SimpleText(on and "Visible" or "Masque", "DermaDefault", w / 2, h / 2, on and Color(186, 232, 196) or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		vis.DoClick = function()
			CatsOn[c.id] = not (CatsOn[c.id] ~= false)
		end

		local hit = vgui.Create("DButton", row)
		hit:Dock(FILL)
		hit:SetText("")
		hit.Paint = function() end
		hit.DoClick = function()
			SelCat = c.id
			SelProvider = nil
			Selected = nil
			if QuestTypeFilter ~= "" then
				QuestTypeFilter = ""
				if IsValid(EditorPanel._typeSearch) then
					EditorPanel._typeSearch:SetValue("")
				end
			end
			rebuildEditorPanel()
		end
	end

	if SelCat == "modeles" then
		SelProvider = "world_models"
		local presets = EVO_ConfigPos.WorldModelPresets or {}
		if not SelModelPreset then
			SelModelPreset = presets[1] and presets[1].id or "custom"
		end
		local function addTypeRow(id, label, model, extra)
			local b = vgui.Create("DButton", EditorPanel._types)
			b:Dock(TOP)
			b:DockMargin(4, 3, 4, 0)
			b:SetTall(28)
			b:SetText("")
			b.Paint = function(_, w, h)
				local on = SelModelPreset == id
				draw.RoundedBox(4, 0, 0, w, h, on and COL_ROWSEL or COL_ROW)
				if on then draw.RoundedBox(0, 0, 0, 3, h, COL_ACCENT) end
				draw.SimpleText(label, "DermaDefault", 10, h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if extra then
					draw.SimpleText(extra, "DermaDefault", w - 10, h / 2, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			b.DoClick = function()
				SelProvider = "world_models"
				SelModelPreset = id
				if model and model ~= "" then
					EVO_ConfigPos.PendingWorldModel = model
					if IsValid(EditorPanel._modelPath) then
						EditorPanel._modelPath:SetValue(model)
					end
				end
				rebuildEditorPanel()
			end
		end
		for _, pre in ipairs(presets) do
			addTypeRow(pre.id, pre.label, pre.model)
		end
		addTypeRow("custom", "Chemin custom", nil)
	else
		for _, pid in ipairs(providersInCat(SelCat)) do
			if not providerMatchesFilter(pid) then continue end
			local p = EVO_ConfigPos.Providers[pid]
			local n = countProv(pid)
			local b = vgui.Create("DButton", EditorPanel._types)
			b:Dock(TOP)
			b:DockMargin(4, 3, 4, 0)
			b:SetTall(28)
			b:SetText("")
			b.Paint = function(s, w, h)
				local on = SelProvider == pid
				draw.RoundedBox(4, 0, 0, w, h, on and COL_ROWSEL or COL_ROW)
				if on then draw.RoundedBox(0, 0, 0, 3, h, COL_ACCENT) end
				draw.SimpleText((p and p.label) or pid, "DermaDefault", 10, h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(tostring(n), "DermaDefault", w - 10, h / 2, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function()
				SelProvider = pid
				Selected = nil
				rebuildEditorPanel()
			end
		end
	end

	for _, it in ipairs(Items) do
		if it.cat ~= SelCat or it.provider ~= SelProvider then continue end
		local b = vgui.Create("DButton", EditorPanel._items)
		b:Dock(TOP)
		b:DockMargin(4, 3, 4, 0)
		b:SetTall(26)
		b:SetText("")
		b.Paint = function(s, w, h)
			local isSel = Selected and Selected.provider == it.provider and Selected.id == it.id
			draw.RoundedBox(4, 0, 0, w, h, isSel and COL_ROWSEL or COL_ROW)
			draw.SimpleText(it.label, "DermaDefault", 8, h / 2, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			Selected = it
			SelProvider = it.provider
			SelCat = it.cat or SelCat
			rebuildEditorPanel()
		end
		if it.provider == "flag_zones" or it.provider == "boss_spawns" then
			b.DoRightClick = function()
				Selected = it
				local fallback = it.provider == "boss_spawns" and "Boss" or "Drapeau"
				local title = it.provider == "boss_spawns" and "Renommer le spot boss" or "Renommer le drapeau"
				local prompt = it.provider == "boss_spawns" and "Nom du spot (annonce) :" or "Nom du drapeau :"
				Derma_StringRequest(title, prompt, it.name or string.match(it.label or "", "^(.*) %[[%d]+%]$") or fallback, function(name)
					if not (isstring(name) and string.Trim(name) ~= "") then return end
					it.name = string.sub(string.Trim(name), 1, 64)
					it.label = it.name .. " [" .. it.id .. "]"
					applyNow(it)
					sendSet(it)
				end)
			end
		end
	end

	local selP = SelProvider and EVO_ConfigPos.Providers[SelProvider]
	if IsValid(EditorPanel._addBtn) then
		EditorPanel._addBtn:SetEnabled(selP and isfunction(selP.Add) and true or false)
	end
	if IsValid(EditorPanel._delBtn) then
		EditorPanel._delBtn:SetEnabled(selP and isfunction(selP.Remove) and Selected ~= nil)
	end
end

local function closeEditorPanel()
	if IsValid(EditorPanel) then EditorPanel:Remove() end
	EditorPanel = nil
end

hideEditorPanel = function()
	closeEditorPanel()
end

showEditorPanel = function()
	if not Active then return end
	local ctx = getContextFrame()
	if not IsValid(ctx) then return end
	if IsValid(EditorPanel) then
		if EditorPanel:GetParent() ~= ctx then
			EditorPanel:SetParent(ctx)
			EditorPanel:SetPos(16, 56)
		end
		if not EditorPanel:IsVisible() then
			EditorPanel:SetVisible(true)
		end
		return
	end
	openEditorPanel(ctx)
end

syncEditorPanelVis = function()
	if Active and contextOpen() then
		showEditorPanel()
	elseif IsValid(EditorPanel) then
		hideEditorPanel()
	end
end

openEditorPanel = function(parent)
	closeEditorPanel()
	parent = IsValid(parent) and parent or getContextFrame()
	if not IsValid(parent) then return end

	local fr = vgui.Create("DPanel", parent)
	fr:SetSize(320, math.min(760, ScrH() * 0.78))
	fr:SetPos(16, 56)
	fr:SetMouseInputEnabled(true)
	fr:SetKeyboardInputEnabled(false)
	fr.Paint = function(_, w, h)
		draw.RoundedBox(8, 0, 0, w, h, COL_BG)
		draw.SimpleText("CONFIG POSITIONS", "DermaLarge", 14, 10, COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Categorie + type, puis Ajouter ici", "DermaDefault", 15, 38, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	fr.OnRemove = function(s)
		if EditorPanel == s then EditorPanel = nil end
	end

	local headPad = vgui.Create("DPanel", fr)
	headPad:Dock(TOP)
	headPad:SetTall(54)
	headPad.Paint = nil

	local visBar = vgui.Create("DPanel", fr)
	visBar:Dock(TOP)
	visBar:DockMargin(10, 0, 10, 4)
	visBar:SetTall(26)
	visBar.Paint = function(_, _, h)
		draw.SimpleText("Dans le monde", "DermaDefaultBold", 2, h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local allOff = vgui.Create("DButton", visBar)
	allOff:Dock(RIGHT)
	allOff:SetWide(52)
	allOff:SetText("Rien")
	styleBtn(allOff, Color(70, 70, 90))
	allOff.DoClick = function() setAllCatsVisible(false) end
	local allOn = vgui.Create("DButton", visBar)
	allOn:Dock(RIGHT)
	allOn:DockMargin(0, 0, 4, 0)
	allOn:SetWide(52)
	allOn:SetText("Tout")
	styleBtn(allOn, Color(60, 110, 70))
	allOn.DoClick = function() setAllCatsVisible(true) end

	local modeBar = vgui.Create("DPanel", fr)
	modeBar:Dock(TOP)
	modeBar:DockMargin(8, 0, 8, 4)
	modeBar:SetTall(28)
	modeBar.Paint = nil
	for _, spec in ipairs({
		{ id = "move", label = "Move" },
		{ id = "rotate", label = "Rotate" },
		{ id = "scale", label = "Scale" },
	}) do
		local b = vgui.Create("DButton", modeBar)
		b:Dock(LEFT)
		b:SetWide(98)
		b:DockMargin(0, 0, 4, 0)
		b:SetText(spec.label)
		b:SetTextColor(COL_TXT)
		b.DoClick = function()
			local allowed = Selected and validModes(Selected) or { "move", "rotate" }
			for _, m in ipairs(allowed) do
				if m == spec.id then
					Mode = spec.id
					return
				end
			end
		end
		b.Paint = function(s, w, h)
			local allowed = false
			local modes = Selected and validModes(Selected) or { "move", "rotate" }
			for _, m in ipairs(modes) do
				if m == spec.id then allowed = true break end
			end
			local bg = COL_ROW
			if not allowed then
				bg = Color(28, 28, 34)
			elseif Mode == spec.id then
				bg = COL_ACCENT
			elseif s:IsHovered() then
				bg = Color(50, 50, 62)
			end
			draw.RoundedBox(4, 0, 0, w, h, bg)
		end
	end

	local cats = vgui.Create("DScrollPanel", fr)
	cats:Dock(TOP)
	cats:DockMargin(8, 0, 8, 4)
	cats:SetTall(6 * 37 + 10)
	cats.Paint = function(_, w, h) draw.RoundedBox(6, 0, 0, w, h, COL_PANEL) end

	local typeBar = vgui.Create("DPanel", fr)
	typeBar:Dock(TOP)
	typeBar:DockMargin(10, 2, 10, 2)
	typeBar:SetTall(16)
	typeBar.Paint = function(_, _, h)
		draw.SimpleText("Type", "DermaDefaultBold", 2, h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local typeSearch = vgui.Create("DTextEntry", fr)
	typeSearch:Dock(TOP)
	typeSearch:DockMargin(8, 0, 8, 4)
	typeSearch:SetTall(0)
	typeSearch:SetVisible(false)
	typeSearch:SetUpdateOnType(true)
	typeSearch:SetPlaceholderText("Filtrer les quetes...")
	typeSearch:SetValue(QuestTypeFilter)
	typeSearch.OnGetFocus = function()
		fr:SetKeyboardInputEnabled(true)
	end
	typeSearch.OnLoseFocus = function()
		fr:SetKeyboardInputEnabled(false)
	end
	typeSearch.OnValueChange = function(_, v)
		local nextFilter = string.lower(string.Trim(v or ""))
		if nextFilter == QuestTypeFilter then return end
		QuestTypeFilter = nextFilter
		if rebuildEditorPanel then rebuildEditorPanel() end
	end

	local types = vgui.Create("DScrollPanel", fr)
	types:Dock(TOP)
	types:DockMargin(8, 0, 8, 4)
	types:SetTall(140)
	types.Paint = function(_, w, h) draw.RoundedBox(6, 0, 0, w, h, COL_PANEL) end

	local modelPick = vgui.Create("DPanel", fr)
	modelPick:Dock(TOP)
	modelPick:DockMargin(8, 0, 8, 4)
	modelPick:SetTall(0)
	modelPick:SetVisible(false)
	modelPick.Paint = function(_, w, h)
		if h < 8 then return end
		draw.RoundedBox(6, 0, 0, w, h, COL_PANEL)
		draw.SimpleText("Modele .mdl", "DermaDefaultBold", 8, 6, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local modelPath = vgui.Create("DTextEntry", modelPick)
	modelPath:Dock(FILL)
	modelPath:DockMargin(6, 24, 6, 6)
	modelPath:SetUpdateOnType(true)
	modelPath:SetPlaceholderText("models/...")
	local firstPre = EVO_ConfigPos.WorldModelPresets and EVO_ConfigPos.WorldModelPresets[1]
	modelPath:SetValue(EVO_ConfigPos.PendingWorldModel or (firstPre and firstPre.model) or "")
	modelPath.OnGetFocus = function()
		fr:SetKeyboardInputEnabled(true)
	end
	modelPath.OnLoseFocus = function(s)
		fr:SetKeyboardInputEnabled(false)
		EVO_ConfigPos.PendingWorldModel = s:GetValue()
	end
	modelPath.OnValueChange = function(s, v)
		EVO_ConfigPos.PendingWorldModel = v
	end

	local bizPick = vgui.Create("DPanel", fr)
	bizPick:Dock(TOP)
	bizPick:DockMargin(8, 0, 8, 4)
	bizPick:SetTall(0)
	bizPick:SetVisible(false)
	bizPick.Paint = function(_, w, h)
		if h < 8 then return end
		draw.RoundedBox(6, 0, 0, w, h, COL_PANEL)
		draw.SimpleText("Commerce (ajout distillerie / coffre)", "DermaDefaultBold", 8, 6, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	local bizCombo = vgui.Create("DComboBox", bizPick)
	bizCombo:Dock(FILL)
	bizCombo:DockMargin(6, 24, 6, 6)
	local function refreshBizCombo()
		if not IsValid(bizCombo) then return end
		bizCombo:Clear()
		local cur = EVO_ConfigPos.PendingBusiness or "bar"
		local ids = (EVO_BUSINESS and EVO_BUSINESS.ListBusinessIds and EVO_BUSINESS.ListBusinessIds()) or { "bar" }
		local bFound = false
		for _, id in ipairs(ids) do
			local d = EVO_BUSINESS and EVO_BUSINESS.BusinessById and EVO_BUSINESS.BusinessById(id)
			local label = (d and d.label or id) .. " (" .. id .. ")"
			bizCombo:AddChoice(label, id, id == cur)
			if id == cur then bFound = true end
		end
		if not bFound then
			EVO_ConfigPos.PendingBusiness = "bar"
			bizCombo:SetValue("Bar (bar)")
		end
	end
	bizCombo.OnSelect = function(_, _, _, data)
		EVO_ConfigPos.PendingBusiness = tostring(data or "bar")
	end
	refreshBizCombo()

	local itemBar = vgui.Create("DPanel", fr)
	itemBar:Dock(TOP)
	itemBar:DockMargin(10, 2, 10, 2)
	itemBar:SetTall(16)
	itemBar.Paint = function(_, _, h)
		local p = SelProvider and EVO_ConfigPos.Providers[SelProvider]
		draw.SimpleText(p and p.label or "Positions", "DermaDefaultBold", 2, h / 2, COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local btns = vgui.Create("DPanel", fr)
	btns:Dock(TOP)
	btns:DockMargin(8, 4, 8, 6)
	btns:SetTall(40)
	btns.Paint = nil

	local items = vgui.Create("DScrollPanel", fr)
	items:Dock(FILL)
	items:DockMargin(8, 0, 8, 8)
	items.Paint = function(_, w, h) draw.RoundedBox(6, 0, 0, w, h, COL_PANEL) end

	local addBtn = vgui.Create("DButton", btns)
	addBtn:Dock(LEFT)
	addBtn:SetWide(100)
	addBtn:DockMargin(0, 0, 4, 0)
	addBtn:SetText("Ajouter ici")
	styleBtn(addBtn, Color(60, 110, 70))
	addBtn.DoClick = function()
		local pid = ensureSelProvider()
		if not pid then return end
		if pid == "flag_zones" then
			Derma_StringRequest("Nouveau drapeau", "Nom du drapeau :", "Drapeau", function(name)
				EVO_ConfigPos.PendingFlagName = name
				sendAdd(pid)
			end)
			return
		end
		if pid == "boss_spawns" then
			Derma_StringRequest("Nouveau spot boss", "Nom du spot (annonce) :", "Boss", function(name)
				EVO_ConfigPos.PendingBossName = name
				sendAdd(pid)
			end)
			return
		end
		sendAdd(pid)
	end

	local delBtn = vgui.Create("DButton", btns)
	delBtn:Dock(LEFT)
	delBtn:SetWide(100)
	delBtn:DockMargin(0, 0, 4, 0)
	delBtn:SetText("Supprimer")
	styleBtn(delBtn, Color(120, 60, 60))
	delBtn.DoClick = function()
		if not Selected then return end
		confirmRemove(Selected)
	end

	local rstBtn = vgui.Create("DButton", btns)
	rstBtn:Dock(FILL)
	rstBtn:SetText("Origine Lua")
	rstBtn:SetTooltip("Remet la selection a sa position d'origine (fichiers Lua), sans la supprimer.")
	styleBtn(rstBtn, Color(70, 70, 90))
	rstBtn.DoClick = function()
		if Selected then sendReset(Selected) end
	end

	fr._cats = cats
	fr._types = types
	fr._typeSearch = typeSearch
	fr._items = items
	fr._modelPick = modelPick
	fr._modelPath = modelPath
	fr._bizPick = bizPick
	fr._bizCombo = bizCombo
	fr._refreshBizCombo = refreshBizCombo
	fr._addBtn = addBtn
	fr._delBtn = delBtn
	EditorPanel = fr
	rebuildEditorPanel()
end

net.Receive("EVO_ConfigPos:Toggle", function()
	Active = net.ReadBool()
	EVO_ConfigPos.Active = Active
	local keep = selectedKey()
	Items = {}
	Selected = nil
	Drag = nil
	if not Active then
		closeEditorPanel()
		return
	end
	local n = net.ReadUInt(16)
	for i = 1, n do
		Items[i] = EVO_ConfigPos.ReadItem()
	end
	restoreSelection(keep)
	if Selected then
		SelCat = Selected.cat or SelCat
		SelProvider = Selected.provider
	end
	if not IsValid(EditorPanel) then
		openEditorPanel()
	else
		rebuildEditorPanel()
	end
	syncEditorPanelVis()
end)

net.Receive("EVO_ConfigPos:Item", function()
	local it = EVO_ConfigPos.ReadItem()
	if Drag and Drag.item and Drag.item.provider == it.provider and Drag.item.id == it.id then
		return
	end
	local cur = findItem(it.provider, it.id)
	if cur then
		cur.pos, cur.ang, cur.mins, cur.maxs = it.pos, it.ang, it.mins, it.maxs
		cur.scale = it.scale or cur.scale
		cur.entClass = it.entClass or cur.entClass
		applyNow(cur)
	else
		Items[#Items + 1] = it
		applyNow(it)
	end
	if rebuildEditorPanel then rebuildEditorPanel() end
end)

local function readMapOfData()
	local out = {}
	local nProv = net.ReadUInt(8)
	for _ = 1, nProv do
		local pid = net.ReadString()
		out[pid] = {}
		local nInst = net.ReadUInt(16)
		for _ = 1, nInst do
			local id = net.ReadString()
			out[pid][id] = EVO_ConfigPos.ReadData()
		end
	end
	return out
end

net.Receive("EVO_ConfigPos:Sync", function()
	local map = game.GetMap()
	EVO_ConfigPos.Overrides[map] = readMapOfData()
	EVO_ConfigPos.Removed[map] = {}
	local nRem = net.ReadUInt(8)
	for _ = 1, nRem do
		local pid = net.ReadString()
		EVO_ConfigPos.Removed[map][pid] = {}
		local nId = net.ReadUInt(16)
		for _ = 1, nId do
			EVO_ConfigPos.Removed[map][pid][net.ReadString()] = true
		end
	end
	EVO_ConfigPos.Extras[map] = readMapOfData()
	EVO_ConfigPos.Lists[map] = {}
	local nList = net.ReadUInt(8)
	for _ = 1, nList do
		local pid = net.ReadString()
		local raw = net.ReadString()
		EVO_ConfigPos.Lists[map][pid] = (raw ~= "" and util.JSONToTable(raw)) or {}
	end
	EVO_ConfigPos.ApplyPersisted(map)
end)

net.Receive("EVO_ConfigPos:Print", function()
	local n = net.ReadUInt(16)
	for _ = 1, n do
		print(net.ReadString())
	end
end)

net.Receive("EVO_ConfigPos:Export", function()
	local fileName = net.ReadString()
	local bundlePath = net.ReadString()
	local posPath = net.ReadString()
	local placerPath = net.ReadString()
	local json = net.ReadString()
	if json ~= "" then
		SetClipboardText(json)
	end
	chat.AddText(Color(255, 210, 80), "[ConfigPos] ", color_white, "Pour un autre serveur :")
	chat.AddText(color_white, "1. Copie ", Color(120, 200, 255), bundlePath)
	chat.AddText(color_white, "   (ou ", Color(120, 200, 255), posPath, color_white, " + ", Color(120, 200, 255), placerPath, color_white, ")")
	chat.AddText(color_white, "2. Colle au meme chemin sur l'autre serveur")
	chat.AddText(color_white, "3. ", Color(120, 200, 255), "!config_positions_import", color_white, " (ou restart)")
	if json ~= "" then
		chat.AddText(Color(180, 180, 180), "Le JSON du bundle est aussi dans le presse-papier.")
	end
	print("[ConfigPos] Export : " .. fileName)
	print("[ConfigPos] " .. bundlePath)
end)
