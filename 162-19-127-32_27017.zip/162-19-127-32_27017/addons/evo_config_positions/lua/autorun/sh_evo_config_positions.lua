-- "addons\\evo_config_positions\\lua\\autorun\\sh_evo_config_positions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CONFIG POSITIONS — éditeur gizmo SuperAdmin (positions de config).
-- Overrides persistés (data/evo_config_positions.json) et appliqués dans les
-- tables Lua déjà lues par le jeu. Les PNJ déjà gérés par evo_placer passent
-- par EVO_PLACER pour ne pas dédoubler data/evo_placer.json.
-- ============================================================================

EVO_ConfigPos = EVO_ConfigPos or {}

EVO_ConfigPos.KIND = {
	POINT = 0,
	POINT_ANG = 1,
	BOX = 2,
}

EVO_ConfigPos.CATS = {
	{ id = "domaine",     label = "Domaine" },
	{ id = "zones",       label = "Zones" },
	{ id = "metiers",     label = "Metiers" },
	{ id = "ateliers",    label = "Ateliers" },
	{ id = "archives",    label = "Archives" },
	{ id = "missions",    label = "Missions" },
	{ id = "quetes",      label = "Quetes" },
	{ id = "events",      label = "Events" },
	{ id = "tableaux",    label = "Tableaux" },
	{ id = "modeles",     label = "Modeles" },
	{ id = "npc_svc",     label = "PNJ services" },
	{ id = "npc_combat",  label = "PNJ combat" },
	{ id = "npc_hollow",  label = "PNJ Hollow" },
}

EVO_ConfigPos.WorldModels = EVO_ConfigPos.WorldModels or {}
EVO_ConfigPos.PendingWorldModel = EVO_ConfigPos.PendingWorldModel or ""
EVO_ConfigPos.PendingBusiness = EVO_ConfigPos.PendingBusiness or "bar"
EVO_ConfigPos.WorldModelPresets = {
	-- Doit suivre EVO_CRAFT.CFG.StationModels (sync dans sh_config craft).
	{ id = "assassin", label = "Etabli assassin", model = "models/models/watcherprops/watcher_konoha_stuff_68.mdl" },
	{ id = "soin",     label = "Etabli medecin",  model = "models/evo/props/items/evo_md4ks8wq1ht/evo_Md4Ks8Wq1Ht.mdl" },
	{ id = "combat",   label = "Etabli combat",   model = "models/evo/props/items/evo_fg6nz3rc7yp/evo_Fg6Nz3Rc7Yp.mdl" },
	-- Doit suivre EVO_MISSIVE.DeskModel (sh_config missive).
	{ id = "bureau_missions", label = "Bureau des missions", model = "models/models/watcherprops/watcher_konoha_stuff_71.mdl" },
	{ id = "coffre",   label = "Coffre",          model = "models/evo/props/items/evo_efttede452hk/evo_efttede452hk.mdl" },
	{ id = "etagere",  label = "Etagere",         model = "models/echoes/env/sm_b_012_bookshelf_01a.mdl" },
	{ id = "mur_fort", label = "Mur fort",        model = "models/props_medieval/fort_wall.mdl" },
	{ id = "tente",    label = "Tente bastion",   model = "models/evo/props/items/tente_bastion/evo_572apnfyhg85s.mdl" },
	{ id = "bar_distillerie", label = "Distillerie (Bar)", model = "models/evo/props/items/evo_15623hbfre26hbfrefre/evo_15623HBfre26HBFREfre.mdl" },
	{ id = "bar", label = "Bar", model = "models/evo/props/items/evo_6352hgfpoilkujtg/evo_6352hgfPOILKUJtg.mdl" },
	{ id = "chaise_bar", label = "Chaise du bar", model = "models/evo/props/items/evo_15gyhbgt51rtgbhgrht51/evo_15GYHBGT51rtgbhGRHT51.mdl" },
	-- Lit d'infirmerie (médecins) : spawn du prop + spot [E] S'allonger lié
	-- (opérable via evo_repos / ncm_heal_bed). Voir syncHealBedSpot.
	{ id = "lit_medecin", label = "Lit medecin", model = "models/props_unique/hospital/hospital_bed.mdl" },
	-- Lit d'opération du labo scientifique (user 09/20).
	{ id = "lit_scientifique", label = "Lit scientifique", model = "models/reizer_props/alysseum_project/medicine_obj/med_sofa_01/med_sofa_01.mdl" },
	-- Mobilier du pack Seirei - Taverne.
	{ id = "taverne_table_low", label = "Taverne - Table basse", model = "models/seirei/tavern/table_low.mdl" },
	{ id = "taverne_table_long", label = "Taverne - Grande table basse", model = "models/seirei/tavern/table_long.mdl" },
	{ id = "taverne_tatami", label = "Taverne - Tatami", model = "models/seirei/tavern/tatami.mdl" },
	{ id = "taverne_cushion", label = "Taverne - Coussin bordeaux", model = "models/seirei/tavern/cushion.mdl" },
	{ id = "taverne_bench", label = "Taverne - Banc en bois", model = "models/seirei/tavern/bench.mdl" },
	{ id = "taverne_shelf", label = "Taverne - Etagere a vaisselle", model = "models/seirei/tavern/shelf.mdl" },
	{ id = "taverne_cabinet", label = "Taverne - Commode a tiroirs", model = "models/seirei/tavern/cabinet.mdl" },
	{ id = "taverne_chest", label = "Taverne - Coffre de rangement", model = "models/seirei/tavern/chest.mdl" },
	{ id = "taverne_barrel", label = "Taverne - Tonneau", model = "models/seirei/tavern/barrel.mdl" },
	{ id = "taverne_jar", label = "Taverne - Jarre en ceramique", model = "models/seirei/tavern/jar.mdl" },
	{ id = "taverne_sake_bottle", label = "Taverne - Bouteille de sake", model = "models/seirei/tavern/sake_bottle.mdl" },
	{ id = "taverne_cup", label = "Taverne - Tasse a the", model = "models/seirei/tavern/cup.mdl" },
	{ id = "taverne_bowl", label = "Taverne - Bol de service", model = "models/seirei/tavern/bowl.mdl" },
	{ id = "taverne_teapot", label = "Taverne - Theiere", model = "models/seirei/tavern/teapot.mdl" },
	{ id = "taverne_tea_tray", label = "Taverne - Service a the", model = "models/seirei/tavern/tea_tray.mdl" },
	{ id = "taverne_bottle_set", label = "Taverne - Plateau de bouteilles", model = "models/seirei/tavern/bottle_set.mdl" },
	{ id = "taverne_lantern_paper", label = "Taverne - Lanterne suspendue", model = "models/seirei/tavern/lantern_paper.mdl" },
	{ id = "taverne_lantern_table", label = "Taverne - Lanterne de table", model = "models/seirei/tavern/lantern_table.mdl" },
	{ id = "taverne_banner", label = "Taverne - Banniere", model = "models/seirei/tavern/banner.mdl" },
	{ id = "taverne_wall_scroll", label = "Taverne - Parchemin decoratif", model = "models/seirei/tavern/wall_scroll.mdl" },
	{ id = "taverne_vase", label = "Taverne - Vase decoratif", model = "models/seirei/tavern/vase.mdl" },
	{ id = "taverne_blossom_vase", label = "Taverne - Vase fleuri", model = "models/seirei/tavern/blossom_vase.mdl" },
	{ id = "taverne_potted_tree", label = "Taverne - Arbre en pot", model = "models/seirei/tavern/potted_tree.mdl" },
}

-- PROPS DU CODE (09/20) : posés d'office, identiques sur un serveur neuf. `key` STABLE et
-- UNIQUE (sauvée dans l'instantané de l'éditeur) ; pos = au sol ou un peu au-dessus, le
-- spawn retrace le sol dessous. Déplaçables au gizmo ; supprimés dans l'éditeur, ils
-- REVIENNENT au boot (le code prime) : pour en retirer un, l'enlever d'ici.
EVO_ConfigPos.WorldModelDefaults = {
	["hueco_mundo_v1"] = {
		-- Lit scientifique du labo de l'Ordre 3 (user 09/20). Son setpos était pris en noclip
		-- au-dessus (z 6519, pitch 89) : x / y / yaw gardés, z = celui du point S'allonger.
		{ key = "lit_sci_hueco_1", model = "models/reizer_props/alysseum_project/medicine_obj/med_sofa_01/med_sofa_01.mdl",
		  pos = Vector(-11139.255859, 656.661011, 6309.788086), ang = Angle(0, 2.205942, 0) },
	},
}

EVO_ConfigPos.Providers = EVO_ConfigPos.Providers or {}
EVO_ConfigPos._ProviderOrder = EVO_ConfigPos._ProviderOrder or {}

-- Overrides[map][provider][id] = { kind, pos?, ang?, mins?, maxs? }
EVO_ConfigPos.Overrides = EVO_ConfigPos.Overrides or {}
-- Removed[map][provider][id] = true  — Lua default hidden
EVO_ConfigPos.Removed = EVO_ConfigPos.Removed or {}
-- Extras[map][provider][id] = data   — created in-game (stable ids / singles)
EVO_ConfigPos.Extras = EVO_ConfigPos.Extras or {}
-- Lists[map][provider] = snapshot    — full array after add/delete
EVO_ConfigPos.Lists = EVO_ConfigPos.Lists or {}

function EVO_ConfigPos.RegisterProvider(p)
	if not (istable(p) and isstring(p.id) and isfunction(p.List) and isfunction(p.Apply)) then
		ErrorNoHalt("[evo_config_positions] RegisterProvider : id + List + Apply requis\n")
		return
	end
	if not EVO_ConfigPos.Providers[p.id] then
		EVO_ConfigPos._ProviderOrder[#EVO_ConfigPos._ProviderOrder + 1] = p.id
	end
	EVO_ConfigPos.Providers[p.id] = p
end

function EVO_ConfigPos.UnregisterProvider(id)
	if not isstring(id) then return end
	EVO_ConfigPos.Providers[id] = nil
	for i = #EVO_ConfigPos._ProviderOrder, 1, -1 do
		if EVO_ConfigPos._ProviderOrder[i] == id then
			table.remove(EVO_ConfigPos._ProviderOrder, i)
		end
	end
end

function EVO_ConfigPos.ClampScale(s)
	s = tonumber(s) or 1
	if s ~= s then return 1 end
	return math.Clamp(s, 0.05, 20)
end

-- prop_physics gelé : Entity:SetPos seul laisse le PhysObj à l'ancienne pose,
-- donc le mesh ne suit pas le gizmo (établi assassin watcherprops 08/24).
function EVO_ConfigPos.TeleportFrozen(ent, pos, ang)
	if not IsValid(ent) then return false end
	if not isvector(pos) then return false end
	ent:SetPos(pos)
	if isangle(ang) then ent:SetAngles(ang) end
	local phys = ent:GetPhysicsObject()
	if IsValid(phys) then
		-- Gravité OFF pendant le dégel : un Wake() laissait le Z retomber
		-- (établi assassin / watcherprops).
		phys:EnableGravity(false)
		phys:EnableMotion(true)
		phys:SetPos(pos)
		if isangle(ang) then phys:SetAngles(ang) end
		phys:EnableMotion(false)
		phys:EnableGravity(true)
		phys:Sleep()
	else
		ent:SetMoveType(MOVETYPE_NONE)
	end
	return true
end

function EVO_ConfigPos.CopyData(d)
	if not istable(d) then return nil end
	local o = { kind = tonumber(d.kind) or EVO_ConfigPos.KIND.POINT }
	if isvector(d.pos) then o.pos = Vector(d.pos.x, d.pos.y, d.pos.z) end
	if isangle(d.ang) then o.ang = Angle(d.ang.p, d.ang.y, d.ang.r) end
	if isvector(d.mins) then o.mins = Vector(d.mins.x, d.mins.y, d.mins.z) end
	if isvector(d.maxs) then o.maxs = Vector(d.maxs.x, d.maxs.y, d.maxs.z) end
	if tonumber(d.scale) then o.scale = EVO_ConfigPos.ClampScale(d.scale) end
	if isstring(d.name) and d.name ~= "" then o.name = d.name end
	return o
end

function EVO_ConfigPos.FindItem(map, provider, id)
	local p = EVO_ConfigPos.Providers[provider]
	if not p then return nil end
	local ok, list = pcall(p.List, map)
	if not (ok and istable(list)) then return nil end
	for _, it in ipairs(list) do
		if it.id == id then return it end
	end
	return nil
end

function EVO_ConfigPos.ApplyItem(map, provider, id, data)
	local p = EVO_ConfigPos.Providers[provider]
	if not p then return false end
	local ok, err = pcall(p.Apply, map, id, data)
	if not ok then
		ErrorNoHalt("[evo_config_positions] Apply " .. tostring(provider) .. "/" .. tostring(id) .. " : " .. tostring(err) .. "\n")
		return false
	end
	if SERVER and isfunction(p.Refresh) then pcall(p.Refresh, map, id) end
	return true
end

function EVO_ConfigPos.ApplyAll(map)
	map = map or game.GetMap()
	local provs = EVO_ConfigPos.Overrides[map]
	if not istable(provs) then return end
	for pid, insts in pairs(provs) do
		if istable(insts) then
			for id, data in pairs(insts) do
				EVO_ConfigPos.ApplyItem(map, pid, id, data)
			end
		end
	end
end

local function restoreLists(storeMap, applyMap)
	local lists = EVO_ConfigPos.Lists[storeMap]
	if not istable(lists) then return end
	for pid, rows in pairs(lists) do
		local p = EVO_ConfigPos.Providers[pid]
		if p and isfunction(p.RestoreList) then
			pcall(p.RestoreList, applyMap or storeMap, rows)
		end
	end
end

-- Boot / sync : Lists -> Removed -> Extras -> Overrides, dans les tables live.
function EVO_ConfigPos.ApplyPersisted(map)
	map = map or game.GetMap()
	restoreLists("_global", map)
	restoreLists(map)
	local lists = EVO_ConfigPos.Lists[map]
	local rem = EVO_ConfigPos.Removed[map]
	if istable(rem) then
		for pid, ids in pairs(rem) do
			local p = EVO_ConfigPos.Providers[pid]
			if p and not p.array and isfunction(p.Remove) then
				for id, flag in pairs(ids) do
					if flag then pcall(p.Remove, map, id) end
				end
			end
		end
	end
	local extras = EVO_ConfigPos.Extras[map]
	if istable(extras) then
		for pid, insts in pairs(extras) do
			local p = EVO_ConfigPos.Providers[pid]
			-- Lists snapshot wins; extras stay for array providers until the first Add/Remove.
			local skipExtras = p and p.array and (
				(istable(lists) and lists[pid] ~= nil)
				or (p.global and istable(EVO_ConfigPos.Lists["_global"]) and EVO_ConfigPos.Lists["_global"][pid] ~= nil)
			)
			if p and not skipExtras then
				for id, data in pairs(insts) do
					if isfunction(p.RestoreExtra) then
						pcall(p.RestoreExtra, map, id, data)
					elseif not p.array then
						EVO_ConfigPos.ApplyItem(map, pid, id, data)
					end
				end
			end
		end
	end
	EVO_ConfigPos.ApplyAll(map)
end

function EVO_ConfigPos.WriteItem(it)
	net.WriteString(it.provider or "")
	net.WriteString(it.id or "")
	net.WriteString(it.cat or "")
	net.WriteString(it.label or "")
	net.WriteString(it.entClass or "")
	local kind = tonumber(it.kind) or EVO_ConfigPos.KIND.POINT
	net.WriteUInt(kind, 2)
	if kind == EVO_ConfigPos.KIND.BOX then
		net.WriteVector(it.mins or vector_origin)
		net.WriteVector(it.maxs or vector_origin)
	else
		net.WriteVector(it.pos or vector_origin)
		if kind == EVO_ConfigPos.KIND.POINT_ANG then
			net.WriteAngle(it.ang or angle_zero)
		end
	end
	local scale = tonumber(it.scale)
	net.WriteBool(scale ~= nil)
	if scale then net.WriteFloat(EVO_ConfigPos.ClampScale(scale)) end
end

function EVO_ConfigPos.ReadItem()
	local it = {
		provider = net.ReadString(),
		id = net.ReadString(),
		cat = net.ReadString(),
		label = net.ReadString(),
		entClass = net.ReadString(),
		kind = net.ReadUInt(2),
	}
	if it.entClass == "" then it.entClass = nil end
	if it.kind == EVO_ConfigPos.KIND.BOX then
		it.mins = net.ReadVector()
		it.maxs = net.ReadVector()
	else
		it.pos = net.ReadVector()
		if it.kind == EVO_ConfigPos.KIND.POINT_ANG then
			it.ang = net.ReadAngle()
		end
	end
	if net.ReadBool() then it.scale = EVO_ConfigPos.ClampScale(net.ReadFloat()) end
	return it
end

function EVO_ConfigPos.WriteData(data)
	local kind = tonumber(data.kind) or EVO_ConfigPos.KIND.POINT
	net.WriteUInt(kind, 2)
	if kind == EVO_ConfigPos.KIND.BOX then
		net.WriteVector(data.mins or vector_origin)
		net.WriteVector(data.maxs or vector_origin)
	else
		net.WriteVector(data.pos or vector_origin)
		net.WriteBool(data.ang ~= nil)
		if data.ang then net.WriteAngle(data.ang) end
	end
	local scale = tonumber(data.scale)
	net.WriteBool(scale ~= nil)
	if scale then net.WriteFloat(EVO_ConfigPos.ClampScale(scale)) end
	local name = isstring(data.name) and string.Trim(data.name) or ""
	net.WriteBool(name ~= "")
	if name ~= "" then net.WriteString(string.sub(name, 1, 64)) end
end

function EVO_ConfigPos.ReadData()
	local data = { kind = net.ReadUInt(2) }
	if data.kind == EVO_ConfigPos.KIND.BOX then
		data.mins = net.ReadVector()
		data.maxs = net.ReadVector()
	else
		data.pos = net.ReadVector()
		if net.ReadBool() then data.ang = net.ReadAngle() end
	end
	if net.ReadBool() then data.scale = EVO_ConfigPos.ClampScale(net.ReadFloat()) end
	if net.ReadBool() then data.name = net.ReadString() end
	return data
end

if SERVER then
	util.AddNetworkString("EVO_ConfigPos:Toggle")
	util.AddNetworkString("EVO_ConfigPos:Sync")
	util.AddNetworkString("EVO_ConfigPos:Set")
	util.AddNetworkString("EVO_ConfigPos:Reset")
	util.AddNetworkString("EVO_ConfigPos:Print")
	util.AddNetworkString("EVO_ConfigPos:Item")
	util.AddNetworkString("EVO_ConfigPos:Export")
	util.AddNetworkString("EVO_ConfigPos:Add")
	util.AddNetworkString("EVO_ConfigPos:Remove")
end
