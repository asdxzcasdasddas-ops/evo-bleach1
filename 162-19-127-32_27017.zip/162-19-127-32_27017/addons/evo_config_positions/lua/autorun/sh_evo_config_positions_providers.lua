-- "addons\\evo_config_positions\\lua\\autorun\\sh_evo_config_positions_providers.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- EVO CONFIG POSITIONS — providers v1 (List + Apply partagés, Refresh serveur).
-- ============================================================================

if not (EVO_ConfigPos and EVO_ConfigPos.RegisterProvider) then return end

local KIND = EVO_ConfigPos.KIND

local function moveByClass(class, iid, pos, ang)
	if not (isstring(class) and isvector(pos)) then return end
	local list = ents.FindByClass(class)
	local found
	for _, e in ipairs(list) do
		if e.EvoPlacerId == iid then
			found = e
			break
		end
	end
	if not IsValid(found) then
		local n = tonumber(string.match(iid or "", "^npc:(%d+)$"))
		found = n and list[n] or nil
	end
	if not IsValid(found) and #list == 1 then
		found = list[1]
	end
	if not IsValid(found) then
		local best, bestD
		for _, e in ipairs(list) do
			local d = e:GetPos():DistToSqr(pos)
			if not bestD or d < bestD then
				best, bestD = e, d
			end
		end
		found = best
	end
	if not IsValid(found) then return end
	found:SetPos(pos)
	if isangle(ang) then found:SetAngles(ang) end
	found.EvoPlacerId = iid
	if found._spawnPos then found._spawnPos = pos end
	if found._spawnAng then found._spawnAng = ang end
end

EVO_ConfigPos.MoveByClass = moveByClass

local BOX_HALF = 64
local INTERIOR_POSE_KEYS = { "arrivee", "retour", "invite", "coffre", "archive" }
local WORLD_POSE_KEYS = { "entree", "sortie" }
local POSE_LABELS = {
	entree = "Entree",
	arrivee = "Arrivee",
	sortie = "Sortie",
	retour = "Retour",
	invite = "Inviter",
	coffre = "Coffre",
	archive = "Archives du clan",
}

local function domaineHasEmplacements(map)
	local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements
	list = list and list[map]
	return istable(list) and #list > 0
end

-- Toujours lister entree/sortie si elles existent dans Lua : les cacher
-- faisait croire qu'elles etaient supprimees. Sur une map a emplacements
-- elles ne servent plus au E (DomainePorte), d'ou le suffixe.
local function domainePoseLabel(map, key)
	local base = POSE_LABELS[key] or key
	if (key == "entree" or key == "sortie") and domaineHasEmplacements(map) then
		return base .. " (inutilisee)"
	end
	return base
end

local function domainePoseKeys()
	local keys = {}
	for _, k in ipairs(WORLD_POSE_KEYS) do keys[#keys + 1] = k end
	for _, k in ipairs(INTERIOR_POSE_KEYS) do keys[#keys + 1] = k end
	return keys
end

-- Add ne recree pas entree/sortie quand les portes achetees existent deja.
local function domaineAddKeys(map)
	local keys = {}
	for _, k in ipairs(INTERIOR_POSE_KEYS) do keys[#keys + 1] = k end
	if not domaineHasEmplacements(map) then
		for _, k in ipairs(WORLD_POSE_KEYS) do keys[#keys + 1] = k end
	end
	return keys
end

local function feetBox(origin)
	local p = origin.pos
	return {
		mins = Vector(p.x - BOX_HALF, p.y - BOX_HALF, p.z - BOX_HALF),
		maxs = Vector(p.x + BOX_HALF, p.y + BOX_HALF, p.z + BOX_HALF),
	}
end

local function encodeV(v)
	if not isvector(v) then return { 0, 0, 0 } end
	return { v.x, v.y, v.z }
end

local function decodeV(t)
	if isvector(t) then return Vector(t.x, t.y, t.z) end
	if not istable(t) then return Vector(0, 0, 0) end
	return Vector(tonumber(t[1]) or 0, tonumber(t[2]) or 0, tonumber(t[3]) or 0)
end

local function encodeA(a)
	if not isangle(a) then return { 0, 0, 0 } end
	return { a.p, a.y, a.r }
end

local function decodeA(t)
	if isangle(t) then return Angle(t.p, t.y, t.r) end
	if not istable(t) then return Angle(0, 0, 0) end
	return Angle(tonumber(t[1]) or 0, tonumber(t[2]) or 0, tonumber(t[3]) or 0)
end

local function refillArray(dst, src)
	for i = #dst, 1, -1 do dst[i] = nil end
	for _, v in ipairs(src) do
		dst[#dst + 1] = v
	end
end

local function spawnServiceNPC(class, id, pos, ang)
	if CLIENT or not isstring(class) then return end
	local ent = ents.Create(class)
	if not IsValid(ent) then return end
	ent:SetPos(pos)
	ent:SetAngles(ang or Angle(0, 0, 0))
	ent:Spawn()
	ent:Activate()
	ent.EvoPlacerId = id
	ent._spawnPos = pos
	ent._spawnAng = ang
	return ent
end

local function removeServiceNPC(class, id)
	if CLIENT or not isstring(class) then return end
	local n = tonumber(string.match(id or "", "^npc:(%d+)$"))
	for _, e in ipairs(ents.FindByClass(class)) do
		if e.EvoPlacerId == id then
			e:Remove()
			return
		end
	end
	if n then
		local list = ents.FindByClass(class)
		if IsValid(list[n]) then list[n]:Remove() end
	end
end

local function remapServiceNpcIds(class, removedIndex)
	if CLIENT or not isstring(class) then return end
	for _, e in ipairs(ents.FindByClass(class)) do
		local m = tonumber(string.match(e.EvoPlacerId or "", "^npc:(%d+)$"))
		if m and m > removedIndex then
			e.EvoPlacerId = "npc:" .. (m - 1)
		end
	end
end

local function nextEmplacementId(map, list)
	local prefix = "x"
	if map == "rp_seireitei_v1" then
		prefix = "s"
	elseif map == "hueco_mundo_v1" then
		prefix = "h"
	end
	local used = {}
	for _, e in ipairs(list or {}) do
		if e.id then used[tostring(e.id)] = true end
	end
	for i = 1, 99 do
		local id = prefix .. string.format("%02d", i)
		if not used[id] then return id end
	end
	return prefix .. tostring((os.time() % 10000))
end

local function listSpawnRows(map, positions, label, entClass)
	local out = {}
	local list = positions and positions[map]
	if not istable(list) then return out end
	for i, p in ipairs(list) do
		if istable(p) and isvector(p.pos) then
			out[#out + 1] = {
				id = "npc:" .. i,
				label = label .. " [" .. i .. "]",
				kind = KIND.POINT_ANG,
				pos = p.pos,
				ang = p.ang or Angle(0, 0, 0),
				entClass = entClass,
			}
		end
	end
	return out
end

local function applySpawnRow(positions, map, id, data)
	local list = positions and positions[map]
	local n = tonumber(string.match(id or "", "^npc:(%d+)$"))
	if not (list and n and list[n] and isvector(data.pos)) then return end
	list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
	if data.ang then list[n].ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
end

local function listPlacerRows(map, placerId, positions, label, entClass)
	local out = listSpawnRows(map, positions, label, entClass)
	if not (placerId and EVO_PLACER and EVO_PLACER.GetOverride) then return out end
	for _, it in ipairs(out) do
		local ov = EVO_PLACER.GetOverride(map, placerId, it.id)
		if ov then
			it.pos = ov.pos or it.pos
			it.ang = ov.ang or it.ang
		end
	end
	return out
end

-- ── Domaine ─────────────────────────────────────────────────────────────────

EVO_ConfigPos.RegisterProvider({
	id = "domaine_poses",
	cat = "domaine",
	label = "Poses domaine",
	List = function(map)
		local out = {}
		local t = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses and EVO_CLAN.Domaine.Poses[map]
		if not t then return out end
		for _, key in ipairs(domainePoseKeys()) do
			local p = t[key]
			if istable(p) and isvector(p.pos) then
				out[#out + 1] = {
					id = key,
					label = domainePoseLabel(map, key),
					kind = KIND.POINT_ANG,
					pos = p.pos,
					ang = p.ang or Angle(0, 0, 0),
					entClass = key == "coffre" and EVO_CLAN.Domaine.CoffreModel or nil,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local t = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses
		t = t and t[map]
		if not (t and t[id] and isvector(data.pos)) then return end
		t[id].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then t[id].ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		if EVO_LIVRE and EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
	end,
	Refresh = function(map, id)
		if CLIENT then return end
		if id and id ~= "coffre" then return end
		if EVO_CLAN.SyncCoffreEntity then
			EVO_CLAN.SyncCoffreEntity()
		elseif EVO_CLAN.RespawnCoffre then
			EVO_CLAN.RespawnCoffre()
		end
	end,
	RestoreExtra = function(map, id, data)
		if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses and isvector(data.pos)) then return end
		EVO_CLAN.Domaine.Poses[map] = EVO_CLAN.Domaine.Poses[map] or {}
		EVO_CLAN.Domaine.Poses[map][id] = {
			pos = Vector(data.pos.x, data.pos.y, data.pos.z),
			ang = data.ang and Angle(data.ang.p, data.ang.y, data.ang.r) or Angle(0, 0, 0),
		}
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		if EVO_LIVRE and EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
	end,
	Add = function(map, origin)
		if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses) then return nil, "no_domaine" end
		EVO_CLAN.Domaine.Poses[map] = EVO_CLAN.Domaine.Poses[map] or {}
		local t = EVO_CLAN.Domaine.Poses[map]
		local key
		for _, k in ipairs(domaineAddKeys(map)) do
			if not (istable(t[k]) and isvector(t[k].pos)) then
				key = k
				break
			end
		end
		if not key then return nil, "exists" end
		t[key] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		return key
	end,
	Remove = function(map, id)
		local t = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Poses and EVO_CLAN.Domaine.Poses[map]
		if not t then return false end
		t[id] = nil
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		return true
	end,
})

local function domainePorteModel(map)
	local cfg = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Porte
	cfg = cfg and cfg[map]
	return (cfg and cfg.modele) or nil
end

-- Lua s01/h01… est la source des portes. On ne remplace JAMAIS cette table
-- par un snapshot JSON : un snapshot incomplet orphelinerait les slots
-- evo_clan_domaine.slot en base. Extra / Lists ne font qu'ajouter un id
-- encore absent ; un Extra s01 n'ecrase plus la pose Lua.
local function emplacementHasId(list, id)
	id = tostring(id or "")
	for _, e in ipairs(list or {}) do
		if tostring(e.id) == id then return e end
	end
end

local function appendEmplacement(map, id, pos, ang)
	if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements and isvector(pos)) then return end
	id = tostring(id or "")
	if id == "" then return end
	EVO_CLAN.Domaine.Emplacements[map] = EVO_CLAN.Domaine.Emplacements[map] or {}
	local list = EVO_CLAN.Domaine.Emplacements[map]
	if emplacementHasId(list, id) then return end
	list[#list + 1] = {
		id = id,
		pos = Vector(pos.x, pos.y, pos.z),
		ang = ang and Angle(ang.p, ang.y, ang.r) or Angle(0, 0, 0),
	}
	if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
end

-- Ids du Lua (s01… / h01…) figes avant ApplyPersisted. On refuse de les
-- retirer : evo_clan_domaine.slot pointe ces cles.
local BUILTIN_EMP_IDS = {}
local function freezeBuiltinEmpIds()
	local t = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements
	if not istable(t) then return end
	for mapName, list in pairs(t) do
		if istable(list) and not BUILTIN_EMP_IDS[mapName] then
			local ids = {}
			for _, e in ipairs(list) do
				if e.id then ids[tostring(e.id)] = true end
			end
			BUILTIN_EMP_IDS[mapName] = ids
		end
	end
end
freezeBuiltinEmpIds()
hook.Add("InitPostEntity", "EVO_ConfigPos::FreezeDomaineEmp", freezeBuiltinEmpIds)

EVO_ConfigPos.RegisterProvider({
	id = "domaine_emplacements",
	cat = "domaine",
	label = "Entrees de domaine",
	List = function(map)
		local out = {}
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements
		list = list and list[map]
		if not istable(list) then return out end
		local mdl = domainePorteModel(map)
		for _, e in ipairs(list) do
			if istable(e) and e.id and isvector(e.pos) then
				out[#out + 1] = {
					id = tostring(e.id),
					label = "Entree " .. e.id,
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = e.ang or Angle(0, 0, 0),
					entClass = mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements
		list = list and list[map]
		local e = emplacementHasId(list, id)
		if not (e and isvector(data.pos)) then return end
		e.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then e.ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
	end,
	-- Snapshot eventuel (test local) : n'ajoute que les ids absents, ne
	-- detruit et ne deplace aucune porte Lua.
	RestoreList = function(map, rows)
		for _, row in ipairs(rows or {}) do
			if row.id then appendEmplacement(map, row.id, decodeV(row.pos), decodeA(row.ang)) end
		end
	end,
	RestoreExtra = function(map, id, data)
		appendEmplacement(map, id, data.pos, data.ang)
	end,
	Add = function(map, origin)
		if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements) then return nil, "no_domaine" end
		EVO_CLAN.Domaine.Emplacements[map] = EVO_CLAN.Domaine.Emplacements[map] or {}
		local list = EVO_CLAN.Domaine.Emplacements[map]
		local id = nextEmplacementId(map, list)
		list[#list + 1] = {
			id = id,
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		return id
	end,
	Remove = function(map, id)
		id = tostring(id or "")
		if BUILTIN_EMP_IDS[map] and BUILTIN_EMP_IDS[map][id] then return false end
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Emplacements
		list = list and list[map]
		if not istable(list) then return false end
		for i, e in ipairs(list) do
			if tostring(e.id) == id then
				table.remove(list, i)
				if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
				return true
			end
		end
		return false
	end,
	Refresh = function(_, id)
		if CLIENT then return end
		if EVO_CLAN.InvalidateDomaineSol then EVO_CLAN.InvalidateDomaineSol() end
		if EVO_CLAN.DomaineSyncPorte then
			EVO_CLAN.DomaineSyncPorte(id)
		elseif EVO_CLAN.DomainePoserPortes then
			EVO_CLAN.DomainePoserPortes()
		end
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "domaine_terrain",
	cat = "domaine",
	label = "Terrain domaine",
	List = function(map)
		local out = {}
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain
		list = list and list[map]
		if not istable(list) then return out end
		for i, box in ipairs(list) do
			if istable(box) and box.a and box.b then
				out[#out + 1] = {
					id = "terrain:" .. i,
					label = "Terrain domaine [" .. i .. "]",
					kind = KIND.BOX,
					mins = Vector(math.min(box.a.x, box.b.x), math.min(box.a.y, box.b.y), math.min(box.a.z, box.b.z)),
					maxs = Vector(math.max(box.a.x, box.b.x), math.max(box.a.y, box.b.y), math.max(box.a.z, box.b.z)),
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain
		list = list and list[map]
		local n = tonumber(string.match(id or "", "^terrain:(%d+)$"))
		if not (list and n and list[n] and isvector(data.mins) and isvector(data.maxs)) then return end
		list[n].a = Vector(data.mins.x, data.mins.y, data.mins.z)
		list[n].b = Vector(data.maxs.x, data.maxs.y, data.maxs.z)
		if EVO_CLAN.InvalidateDomaineTerrain then EVO_CLAN.InvalidateDomaineTerrain() end
	end,
	array = true,
	EncodeList = function(map)
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain
		list = list and list[map]
		if not istable(list) then return {} end
		local out = {}
		for _, box in ipairs(list) do
			if istable(box) and box.a and box.b then
				out[#out + 1] = { a = encodeV(box.a), b = encodeV(box.b) }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain) then return end
		local nextList = {}
		for _, box in ipairs(rows or {}) do
			nextList[#nextList + 1] = { a = decodeV(box.a), b = decodeV(box.b) }
		end
		EVO_CLAN.Domaine.Terrain[map] = nextList
		if EVO_CLAN.InvalidateDomaineTerrain then EVO_CLAN.InvalidateDomaineTerrain() end
	end,
	Add = function(map, origin)
		if not (EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain) then return nil, "no_domaine" end
		EVO_CLAN.Domaine.Terrain[map] = EVO_CLAN.Domaine.Terrain[map] or {}
		local list = EVO_CLAN.Domaine.Terrain[map]
		local box = feetBox(origin)
		list[#list + 1] = { a = box.mins, b = box.maxs }
		if EVO_CLAN.InvalidateDomaineTerrain then EVO_CLAN.InvalidateDomaineTerrain() end
		return "terrain:" .. #list
	end,
	Remove = function(map, id)
		local list = EVO_CLAN and EVO_CLAN.Domaine and EVO_CLAN.Domaine.Terrain
		list = list and list[map]
		local n = tonumber(string.match(id or "", "^terrain:(%d+)$"))
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		if EVO_CLAN.InvalidateDomaineTerrain then EVO_CLAN.InvalidateDomaineTerrain() end
		return true
	end,
})

-- ── Zones d'entraînement ────────────────────────────────────────────────────

EVO_ConfigPos.RegisterProvider({
	id = "entrainement_zones",
	cat = "zones",
	label = "Zones entrainement",
	List = function(map)
		local out = {}
		local list = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[map]
		if not istable(list) then return out end
		for i, z in ipairs(list) do
			if istable(z) and isvector(z.mins) and isvector(z.maxs) then
				out[#out + 1] = {
					id = tostring(i),
					label = (z.name or "Zone") .. " [" .. i .. "]",
					kind = KIND.BOX,
					mins = z.mins,
					maxs = z.maxs,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.mins) and isvector(data.maxs)) then return end
		list[n].mins = Vector(data.mins.x, data.mins.y, data.mins.z)
		list[n].maxs = Vector(data.maxs.x, data.maxs.y, data.maxs.z)
		if NCM_ENTRAINEMENT.CalculerPlafonds then NCM_ENTRAINEMENT.CalculerPlafonds() end
	end,
	array = true,
	EncodeList = function(map)
		local list = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[map]
		if not istable(list) then return {} end
		local out = {}
		for _, z in ipairs(list) do
			if istable(z) and z.mins and z.maxs then
				out[#out + 1] = { name = z.name, mins = encodeV(z.mins), maxs = encodeV(z.maxs) }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not NCM_ENTRAINEMENT then return end
		NCM_ENTRAINEMENT.Zones = NCM_ENTRAINEMENT.Zones or {}
		local nextList = {}
		for _, z in ipairs(rows or {}) do
			nextList[#nextList + 1] = { name = z.name or "Zone", mins = decodeV(z.mins), maxs = decodeV(z.maxs) }
		end
		NCM_ENTRAINEMENT.Zones[map] = nextList
		if NCM_ENTRAINEMENT.CalculerPlafonds then NCM_ENTRAINEMENT.CalculerPlafonds() end
	end,
	Add = function(map, origin)
		if not NCM_ENTRAINEMENT then return nil, "no_zones" end
		NCM_ENTRAINEMENT.Zones = NCM_ENTRAINEMENT.Zones or {}
		NCM_ENTRAINEMENT.Zones[map] = NCM_ENTRAINEMENT.Zones[map] or {}
		local list = NCM_ENTRAINEMENT.Zones[map]
		local box = feetBox(origin)
		list[#list + 1] = { name = "Zone", mins = box.mins, maxs = box.maxs }
		if NCM_ENTRAINEMENT.CalculerPlafonds then NCM_ENTRAINEMENT.CalculerPlafonds() end
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Zones and NCM_ENTRAINEMENT.Zones[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		if NCM_ENTRAINEMENT.CalculerPlafonds then NCM_ENTRAINEMENT.CalculerPlafonds() end
		return true
	end,
})

-- ── Zones sans appâts (cube blanc / pièces : pas de Garganta) ───────────────

EVO_ConfigPos.RegisterProvider({
	id = "no_npc_item_zones",
	cat = "zones",
	label = "Zone sans appats",
	List = function(map)
		local out = {}
		local list = EVO_CRAFT and EVO_CRAFT.NoNpcZones and EVO_CRAFT.NoNpcZones[map]
		if not istable(list) then return out end
		for i, z in ipairs(list) do
			if istable(z) and isvector(z.mins) and isvector(z.maxs) then
				out[#out + 1] = {
					id = tostring(i),
					label = (z.name or "Zone") .. " [" .. i .. "]",
					kind = KIND.BOX,
					mins = z.mins,
					maxs = z.maxs,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_CRAFT and EVO_CRAFT.NoNpcZones and EVO_CRAFT.NoNpcZones[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.mins) and isvector(data.maxs)) then return end
		list[n].mins = Vector(data.mins.x, data.mins.y, data.mins.z)
		list[n].maxs = Vector(data.maxs.x, data.maxs.y, data.maxs.z)
	end,
	array = true,
	EncodeList = function(map)
		local list = EVO_CRAFT and EVO_CRAFT.NoNpcZones and EVO_CRAFT.NoNpcZones[map]
		if not istable(list) then return {} end
		local out = {}
		for _, z in ipairs(list) do
			if istable(z) and z.mins and z.maxs then
				out[#out + 1] = { name = z.name, mins = encodeV(z.mins), maxs = encodeV(z.maxs) }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_CRAFT then return end
		EVO_CRAFT.NoNpcZones = EVO_CRAFT.NoNpcZones or {}
		local nextList = {}
		for _, z in ipairs(rows or {}) do
			nextList[#nextList + 1] = { name = z.name or "Zone", mins = decodeV(z.mins), maxs = decodeV(z.maxs) }
		end
		EVO_CRAFT.NoNpcZones[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_CRAFT then return nil, "no_zones" end
		EVO_CRAFT.NoNpcZones = EVO_CRAFT.NoNpcZones or {}
		EVO_CRAFT.NoNpcZones[map] = EVO_CRAFT.NoNpcZones[map] or {}
		local list = EVO_CRAFT.NoNpcZones[map]
		local box = feetBox(origin)
		list[#list + 1] = { name = "Zone", mins = box.mins, maxs = box.maxs }
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_CRAFT and EVO_CRAFT.NoNpcZones and EVO_CRAFT.NoNpcZones[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
})

-- ── Cubes de faction (AABB anti-entrée) ─────────────────────────────────────

local CUBE_KINDS = {
	{ id = "faction_cube_hollow",    faction = "Hollow",    label = "Bloque Hollow" },
	{ id = "faction_cube_shinigami", faction = "Shinigami", label = "Bloque Shinigami" },
}
local CUBE_SHARE = { "faction_cube_hollow", "faction_cube_shinigami" }

local function factionCubes(map, bCreate)
	if not EVO_FACTION_WALL then return nil end
	EVO_FACTION_WALL.Cubes = EVO_FACTION_WALL.Cubes or {}
	if bCreate then
		EVO_FACTION_WALL.Cubes[map] = EVO_FACTION_WALL.Cubes[map] or {}
	end
	return EVO_FACTION_WALL.Cubes[map]
end

local function encodeFactionCubes(map)
	local list = factionCubes(map)
	if not istable(list) then return {} end
	local out = {}
	for _, c in ipairs(list) do
		if istable(c) and c.mins and c.maxs and isstring(c.faction) then
			out[#out + 1] = {
				mins = encodeV(c.mins),
				maxs = encodeV(c.maxs),
				faction = c.faction,
			}
		end
	end
	return out
end

local function restoreFactionCubes(map, rows)
	if not EVO_FACTION_WALL then return end
	EVO_FACTION_WALL.Cubes = EVO_FACTION_WALL.Cubes or {}
	local nextList = {}
	for _, c in ipairs(rows or {}) do
		if isstring(c.faction) and c.faction ~= "" then
			nextList[#nextList + 1] = {
				mins = decodeV(c.mins),
				maxs = decodeV(c.maxs),
				faction = c.faction,
			}
		end
	end
	EVO_FACTION_WALL.Cubes[map] = nextList
	if SERVER and EVO_FACTION_WALL.Rebuild then EVO_FACTION_WALL.Rebuild() end
end

for _, spec in ipairs(CUBE_KINDS) do
	local faction = spec.faction
	local label = spec.label
	EVO_ConfigPos.RegisterProvider({
		id = spec.id,
		cat = "zones",
		label = label,
		array = true,
		shareList = CUBE_SHARE,
		List = function(map)
			local out = {}
			local list = factionCubes(map)
			if not istable(list) then return out end
			for i, c in ipairs(list) do
				if istable(c) and isvector(c.mins) and isvector(c.maxs) and c.faction == faction then
					out[#out + 1] = {
						id = "cube:" .. i,
						label = label .. " [" .. i .. "]",
						kind = KIND.BOX,
						mins = c.mins,
						maxs = c.maxs,
					}
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			local list = factionCubes(map)
			local n = tonumber(string.match(id or "", "^cube:(%d+)$"))
			if not (list and n and list[n] and isvector(data.mins) and isvector(data.maxs)) then return end
			list[n].mins = Vector(data.mins.x, data.mins.y, data.mins.z)
			list[n].maxs = Vector(data.maxs.x, data.maxs.y, data.maxs.z)
		end,
		EncodeList = encodeFactionCubes,
		RestoreList = restoreFactionCubes,
		Add = function(map, origin)
			local list = factionCubes(map, true)
			if not list then return nil, "no_cubes" end
			local box = feetBox(origin)
			list[#list + 1] = {
				mins = box.mins,
				maxs = box.maxs,
				faction = faction,
			}
			return "cube:" .. #list
		end,
		Remove = function(map, id)
			local list = factionCubes(map)
			local n = tonumber(string.match(id or "", "^cube:(%d+)$"))
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			return true
		end,
		Refresh = function()
			if SERVER and EVO_FACTION_WALL and EVO_FACTION_WALL.Rebuild then
				EVO_FACTION_WALL.Rebuild()
			end
		end,
	})
end

-- ── Métiers ─────────────────────────────────────────────────────────────────

local METIER_LABEL = {
	Resistance = "Resistance",
	Combat = "Combat",
	Meditation = "Meditation",
}

local function ensureMetierList(sType, map)
	local cfg = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Config and NCM_ENTRAINEMENT.Config[sType]
	local zone = cfg and cfg.Zone
	if not zone then return nil end
	zone.Positions = zone.Positions or {}
	local p = zone.Positions
	if p[1] ~= nil then return p end
	p[map] = p[map] or {}
	return p[map]
end

local function registerMetier(sType)
	EVO_ConfigPos.RegisterProvider({
		id = "metier_" .. string.lower(sType),
		cat = "metiers",
		label = "Metier " .. (METIER_LABEL[sType] or sType),
		array = true,
		List = function()
			local out = {}
			local cfg = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Config and NCM_ENTRAINEMENT.Config[sType]
			local zone = cfg and cfg.Zone
			local list = zone and NCM_ENTRAINEMENT.GetZonePositions and NCM_ENTRAINEMENT.GetZonePositions(zone)
			if not istable(list) then return out end
			for i, v in ipairs(list) do
				if isvector(v) then
					out[#out + 1] = {
						id = tostring(i),
						label = (METIER_LABEL[sType] or sType) .. " [" .. i .. "]",
						kind = KIND.POINT,
						pos = v,
					}
				end
			end
			return out
		end,
		Apply = function(_, id, data)
			local cfg = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Config and NCM_ENTRAINEMENT.Config[sType]
			local zone = cfg and cfg.Zone
			local list = zone and NCM_ENTRAINEMENT.GetZonePositions and NCM_ENTRAINEMENT.GetZonePositions(zone)
			local n = tonumber(id)
			if not (list and n and isvector(data.pos)) then return end
			list[n] = Vector(data.pos.x, data.pos.y, data.pos.z)
		end,
		EncodeList = function(map)
			local list = ensureMetierList(sType, map)
			if not list then return {} end
			local out = {}
			for _, v in ipairs(list) do
				if isvector(v) then out[#out + 1] = encodeV(v) end
			end
			return out
		end,
		RestoreList = function(map, rows)
			local list = ensureMetierList(sType, map)
			if not list then return end
			local nextList = {}
			for _, t in ipairs(rows or {}) do
				nextList[#nextList + 1] = decodeV(t)
			end
			refillArray(list, nextList)
		end,
		Add = function(map, origin)
			local list = ensureMetierList(sType, map)
			if not list then return nil, "no_metier" end
			list[#list + 1] = Vector(origin.pos.x, origin.pos.y, origin.pos.z)
			return tostring(#list)
		end,
		Remove = function(_, id)
			local cfg = NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.Config and NCM_ENTRAINEMENT.Config[sType]
			local zone = cfg and cfg.Zone
			local list = zone and NCM_ENTRAINEMENT.GetZonePositions and NCM_ENTRAINEMENT.GetZonePositions(zone)
			local n = tonumber(id)
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			return true
		end,
	})
end

registerMetier("Resistance")
registerMetier("Combat")
registerMetier("Meditation")

-- ── Maîtrise ────────────────────────────────────────────────────────────────

EVO_ConfigPos.RegisterProvider({
	id = "maitrise_npc",
	cat = "metiers",
	label = "Maitre d'Armes",
	List = function(map)
		local t = NCM_START_TRAINING and NCM_START_TRAINING.NPC_POSITIONS
		t = t and t[map]
		if not (t and isvector(t.pos)) then return {} end
		return {{
			id = "npc",
			label = "Maitre d'Armes",
			kind = KIND.POINT_ANG,
			pos = t.pos,
			ang = t.ang or Angle(0, 0, 0),
			entClass = NCM_START_TRAINING.NPC_CLASS,
		}}
	end,
	Apply = function(map, _, data)
		local t = NCM_START_TRAINING and NCM_START_TRAINING.NPC_POSITIONS
		t = t and t[map]
		if not (t and isvector(data.pos)) then return end
		t.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then t.ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
	end,
	RestoreExtra = function(map, _, data)
		if not (NCM_START_TRAINING and NCM_START_TRAINING.NPC_POSITIONS and isvector(data.pos)) then return end
		NCM_START_TRAINING.NPC_POSITIONS[map] = {
			pos = Vector(data.pos.x, data.pos.y, data.pos.z),
			ang = data.ang and Angle(data.ang.p, data.ang.y, data.ang.r) or Angle(0, 0, 0),
		}
	end,
	Add = function(map, origin)
		if not (NCM_START_TRAINING and NCM_START_TRAINING.NPC_POSITIONS) then return nil, "no_maitrise" end
		local t = NCM_START_TRAINING.NPC_POSITIONS[map]
		if t and isvector(t.pos) then return nil, "exists" end
		NCM_START_TRAINING.NPC_POSITIONS[map] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		return "npc"
	end,
	Remove = function(map)
		if not (NCM_START_TRAINING and NCM_START_TRAINING.NPC_POSITIONS) then return false end
		NCM_START_TRAINING.NPC_POSITIONS[map] = nil
		if CLIENT then return true end
		for _, e in ipairs(ents.GetAll()) do
			if IsValid(e) and (e._isWeaponTrainingNPC or (e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == "weapon_training")) then
				e:Remove()
				break
			end
		end
		return true
	end,
	Refresh = function()
		if CLIENT then return end
		if NCM_START_TRAINING and NCM_START_TRAINING.RefreshWeaponTrainingNPC then
			NCM_START_TRAINING.RefreshWeaponTrainingNPC()
		end
	end,
})

local function registerTrainingPoint(id, key, label)
	EVO_ConfigPos.RegisterProvider({
		id = id,
		cat = "metiers",
		label = label,
		List = function(map)
			local t = NCM_START_TRAINING and NCM_START_TRAINING.TRAINING_POSITIONS
			t = t and t[map]
			if not (t and isvector(t[key])) then return {} end
			return {{ id = key, label = label, kind = KIND.POINT, pos = t[key] }}
		end,
		Apply = function(map, _, data)
			local t = NCM_START_TRAINING and NCM_START_TRAINING.TRAINING_POSITIONS
			t = t and t[map]
			if not (t and isvector(data.pos)) then return end
			t[key] = Vector(data.pos.x, data.pos.y, data.pos.z)
		end,
		RestoreExtra = function(map, _, data)
			if not (NCM_START_TRAINING and NCM_START_TRAINING.TRAINING_POSITIONS and isvector(data.pos)) then return end
			NCM_START_TRAINING.TRAINING_POSITIONS[map] = NCM_START_TRAINING.TRAINING_POSITIONS[map] or {}
			NCM_START_TRAINING.TRAINING_POSITIONS[map][key] = Vector(data.pos.x, data.pos.y, data.pos.z)
		end,
		Add = function(map, origin)
			if not (NCM_START_TRAINING and NCM_START_TRAINING.TRAINING_POSITIONS) then return nil, "no_maitrise" end
			NCM_START_TRAINING.TRAINING_POSITIONS[map] = NCM_START_TRAINING.TRAINING_POSITIONS[map] or {}
			local t = NCM_START_TRAINING.TRAINING_POSITIONS[map]
			if isvector(t[key]) then return nil, "exists" end
			t[key] = Vector(origin.pos.x, origin.pos.y, origin.pos.z)
			return key
		end,
		Remove = function(map)
			local t = NCM_START_TRAINING and NCM_START_TRAINING.TRAINING_POSITIONS
			t = t and t[map]
			if not t then return false end
			t[key] = nil
			return true
		end,
	})
end

registerTrainingPoint("maitrise_flashstep", "flashstep", "Maitrise flashstep")
registerTrainingPoint("maitrise_fly", "fly", "Maitrise vol")

-- ── PNJ services (placer + extras) ──────────────────────────────────────────

local function ensureSpawnList(getPositions, map)
	local positions = getPositions()
	if not istable(positions) then return nil end
	positions[map] = positions[map] or {}
	return positions[map]
end

local function encodeSpawnList(map, getPositions)
	local list = getPositions() and getPositions()[map]
	if not istable(list) then return {} end
	local out = {}
	for _, p in ipairs(list) do
		if istable(p) and isvector(p.pos) then
			out[#out + 1] = { pos = encodeV(p.pos), ang = encodeA(p.ang) }
		end
	end
	return out
end

local function restoreSpawnList(map, getPositions, rows)
	local positions = getPositions()
	if not istable(positions) then return end
	local nextList = {}
	for _, r in ipairs(rows or {}) do
		nextList[#nextList + 1] = { pos = decodeV(r.pos), ang = decodeA(r.ang) }
	end
	positions[map] = nextList
end

local function addSpawnAtFeet(map, getPositions, class, origin)
	local list = ensureSpawnList(getPositions, map)
	if not list then return nil, "no_spawns" end
	list[#list + 1] = {
		pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
		ang = Angle(0, origin.ang.y, 0),
	}
	local id = "npc:" .. #list
	spawnServiceNPC(class, id, list[#list].pos, list[#list].ang)
	return id
end

local function removeSpawnRow(map, getPositions, class, id)
	local positions = getPositions()
	local list = positions and positions[map]
	local n = tonumber(string.match(id or "", "^npc:(%d+)$"))
	if not (list and n and list[n]) then return false end
	removeServiceNPC(class, id)
	table.remove(list, n)
	remapServiceNpcIds(class, n)
	return true
end

local function registerPlacerNPC(pid, placerId, label, class, getPositions)
	EVO_ConfigPos.RegisterProvider({
		id = pid,
		cat = "npc_svc",
		label = label,
		viaPlacer = placerId,
		array = true,
		BaseList = function(map)
			return listSpawnRows(map, getPositions(), label, class)
		end,
		List = function(map)
			return listPlacerRows(map, placerId, getPositions(), label, class)
		end,
		Apply = function(_, id, data)
			if isvector(data.pos) then moveByClass(class, id, data.pos, data.ang) end
		end,
		EncodeList = function(map)
			return encodeSpawnList(map, getPositions)
		end,
		RestoreList = function(map, rows)
			restoreSpawnList(map, getPositions, rows)
		end,
		Add = function(map, origin)
			return addSpawnAtFeet(map, getPositions, class, origin)
		end,
		Remove = function(map, id)
			return removeSpawnRow(map, getPositions, class, id)
		end,
		Refresh = function(map, id)
			if id then
				local it = EVO_ConfigPos.FindItem(map or game.GetMap(), pid, id)
				if it then moveByClass(class, id, it.pos, it.ang) end
				return
			end
			for _, it in ipairs(listPlacerRows(map or game.GetMap(), placerId, getPositions(), label, class)) do
				moveByClass(class, it.id, it.pos, it.ang)
			end
		end,
	})
end

local function registerExtraNPC(pid, label, class, getPositions)
	EVO_ConfigPos.RegisterProvider({
		id = pid,
		cat = "npc_svc",
		label = label,
		array = true,
		List = function(map)
			return listSpawnRows(map, getPositions(), label, class)
		end,
		Apply = function(map, id, data)
			applySpawnRow(getPositions(), map, id, data)
			moveByClass(class, id, data.pos, data.ang)
		end,
		EncodeList = function(map)
			return encodeSpawnList(map, getPositions)
		end,
		RestoreList = function(map, rows)
			restoreSpawnList(map, getPositions, rows)
		end,
		Add = function(map, origin)
			return addSpawnAtFeet(map, getPositions, class, origin)
		end,
		Remove = function(map, id)
			return removeSpawnRow(map, getPositions, class, id)
		end,
		Refresh = function(map, id)
			map = map or game.GetMap()
			if id then
				local it = EVO_ConfigPos.FindItem(map, pid, id)
				if it then moveByClass(class, id, it.pos, it.ang) end
				return
			end
			for _, it in ipairs(listSpawnRows(map, getPositions(), label, class)) do
				moveByClass(class, it.id, it.pos, it.ang)
			end
		end,
	})
end

registerPlacerNPC("npc_coiffeur", "npc_coiffeur", "PNJ Coiffeur", "lzy_coiffeur_npc", function()
	return LZY_COIFFEUR and LZY_COIFFEUR.Config and LZY_COIFFEUR.Config.SpawnPositions
end)
registerPlacerNPC("npc_tatoueur", "npc_tatoueur", "PNJ Tatoueur", "lzy_tatoueur_npc", function()
	return LZY_TATOUEUR and LZY_TATOUEUR.Config and LZY_TATOUEUR.Config.SpawnPositions
end)
registerPlacerNPC("npc_sculpteur", "npc_sculpteur", "PNJ Chirurgien", "lzy_sculpteur_npc", function()
	return LZY_SCULPTEUR and LZY_SCULPTEUR.Config and LZY_SCULPTEUR.Config.SpawnPositions
end)
registerPlacerNPC("npc_style_swap", "npc_style_swap", "PNJ Maitre des Arts", "ncm_npc_style_swap", function()
	return NCM_STYLE_SWAP and NCM_STYLE_SWAP.Config and NCM_STYLE_SWAP.Config.SpawnPositions
end)
registerPlacerNPC("npc_doyen", "npc_doyen", "PNJ Doyen des Clans", "evo_npc_clan", function()
	return EVO_CLAN and EVO_CLAN.Config and EVO_CLAN.Config.NPCSpawnPositions
end)
registerPlacerNPC("npc_hdv", "npc_hdv", "PNJ Hotel des ventes", "evo_npc_hdv", function()
	return EVO_HDV and EVO_HDV.Config and EVO_HDV.Config.SpawnPositions
end)
registerPlacerNPC("npc_forgeron_ames", "npc_forgeron_ames", "PNJ Forgeron d'Ames", "ncm_npc_shikai_renamer", function()
	return NCM_SHIKAI_RENAMER and NCM_SHIKAI_RENAMER.Config and NCM_SHIKAI_RENAMER.Config.SpawnPositions
end)
-- Gardien des Lames : evo_blanc n'enregistre AUCUN provider dans evo_placer, donc
-- surtout pas de viaPlacer ici -- l'override partait dans EVO_PLACER.SetOverride,
-- qui jette tout ce qui vient d'un provider inconnu, et le Refresh qui suit
-- reposait le PNJ sur sa position de config : le gizmo ne deplacait rien.
registerExtraNPC("npc_zanpakuto", "PNJ Gardien des Lames", "evo_npc_zanpakuto", function()
	return EVO_BLANC and EVO_BLANC.Rituel and EVO_BLANC.Rituel.SpawnPositions
end)

registerExtraNPC("npc_renommeur", "PNJ Scribe", "lzy_renommeur_npc", function()
	return LZY_RENOMMEUR and LZY_RENOMMEUR.Config and LZY_RENOMMEUR.Config.SpawnPositions
end)
registerExtraNPC("npc_dresseur", "PNJ Dresseur", "evo_npc_dresseur", function()
	return EVO_COMP and EVO_COMP.Dresseur and EVO_COMP.Dresseur.SpawnPositions
end)
registerExtraNPC("npc_parchemin", "PNJ Parchemin", "ncm_npc_parchemin", function()
	return NCM_PARCHEMIN_VENDOR and NCM_PARCHEMIN_VENDOR.SpawnPositions
end)
registerExtraNPC("npc_soin", "PNJ Soigneur", "ncm_npc_soin", function()
	return NCM_NPC_SOIN and NCM_NPC_SOIN.Config and NCM_NPC_SOIN.Config.SpawnPositions
end)
registerExtraNPC("npc_urahara", "Urahara Shop", "lzy_npcshop_npc", function()
	return NPCSHOP_CONFIG and NPCSHOP_CONFIG.SpawnPositions
end)

-- ── PNJ combat ──────────────────────────────────────────────────────────────

EVO_ConfigPos.RegisterProvider({
	id = "ncm_pnj_spawns",
	cat = "npc_combat",
	label = "PNJ combat",
	List = function(map)
		local out = {}
		local list = NCM_PNJ and NCM_PNJ.Spawns
		if not istable(list) then return out end
		for i, e in ipairs(list) do
			if istable(e) and e.sMap == map and isvector(e.vPos) then
				out[#out + 1] = {
					id = "spawn:" .. i,
					label = (e.sClass or "PNJ") .. " [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.vPos,
					ang = e.aAng or Angle(0, 0, 0),
					entClass = e.sClass,
				}
			end
		end
		return out
	end,
	Apply = function(_, id, data)
		local list = NCM_PNJ and NCM_PNJ.Spawns
		local n = tonumber(string.match(id or "", "^spawn:(%d+)$"))
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].vPos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].aAng = Angle(data.ang.p, data.ang.y, data.ang.r) end
	end,
	array = true,
	EncodeList = function()
		local list = NCM_PNJ and NCM_PNJ.Spawns
		if not istable(list) then return {} end
		local out = {}
		for _, e in ipairs(list) do
			if istable(e) and e.sMap and isvector(e.vPos) then
				out[#out + 1] = {
					sMap = e.sMap,
					sClass = e.sClass,
					vPos = encodeV(e.vPos),
					aAng = encodeA(e.aAng),
					bPatrol = e.bPatrol,
					bAggressive = e.bAggressive,
					sGroup = e.sGroup,
					nRespawn = e.nRespawn,
					nBossZoneRadius = e.nBossZoneRadius,
					tDialogue = e.tDialogue,
					tChoices = e.tChoices,
				}
			end
		end
		return out
	end,
	RestoreList = function(_, rows)
		if not NCM_PNJ then return end
		local nextList = {}
		for _, e in ipairs(rows or {}) do
			nextList[#nextList + 1] = {
				sMap = e.sMap,
				sClass = e.sClass,
				vPos = decodeV(e.vPos),
				aAng = decodeA(e.aAng),
				bPatrol = e.bPatrol,
				bAggressive = e.bAggressive,
				sGroup = e.sGroup,
				nRespawn = e.nRespawn,
				nBossZoneRadius = e.nBossZoneRadius,
				tDialogue = e.tDialogue,
				tChoices = e.tChoices,
			}
		end
		NCM_PNJ.Spawns = nextList
	end,
	Add = function(map, origin)
		if not NCM_PNJ then return nil, "no_combat" end
		NCM_PNJ.Spawns = NCM_PNJ.Spawns or {}
		local sClass
		for _, e in ipairs(NCM_PNJ.Spawns) do
			if e.sMap == map and e.sClass then
				sClass = e.sClass
				break
			end
		end
		if not sClass and NCM_PNJ.Config then
			for k in pairs(NCM_PNJ.Config) do
				sClass = k
				break
			end
		end
		sClass = sClass or "ncm_pnj_soulreaper_a"
		local entry = {
			sMap = map,
			sClass = sClass,
			vPos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			aAng = Angle(0, origin.ang.y, 0),
			bPatrol = false,
			bAggressive = false,
			nRespawn = 30,
		}
		NCM_PNJ.Spawns[#NCM_PNJ.Spawns + 1] = entry
		local n = #NCM_PNJ.Spawns
		if SERVER and NCM_PNJ.Spawn then
			local ent = NCM_PNJ.Spawn(entry.sClass, entry.vPos, entry.aAng)
			if IsValid(ent) then
				ent._ncmSpawnIdx = n
				ent._ncmSpawnEntry = entry
				ent._spawnPos = entry.vPos
				ent._spawnAng = entry.aAng
				ent._ncmNoPatrol = true
			end
		end
		return "spawn:" .. n
	end,
	Remove = function(_, id)
		local list = NCM_PNJ and NCM_PNJ.Spawns
		local n = tonumber(string.match(id or "", "^spawn:(%d+)$"))
		if not (list and n and list[n]) then return false end
		if SERVER then
			for _, e in ipairs(ents.GetAll()) do
				if IsValid(e) and e._ncmSpawnIdx == n then
					e:Remove()
				elseif IsValid(e) and tonumber(e._ncmSpawnIdx) and e._ncmSpawnIdx > n then
					e._ncmSpawnIdx = e._ncmSpawnIdx - 1
				end
			end
		end
		table.remove(list, n)
		return true
	end,
	Refresh = function(_, id)
		if CLIENT then return end
		local n = tonumber(string.match(id or "", "^spawn:(%d+)$"))
		if not n then return end
		local eEntry = NCM_PNJ and NCM_PNJ.Spawns and NCM_PNJ.Spawns[n]
		if not eEntry then return end
		for _, e in ipairs(ents.GetAll()) do
			if IsValid(e) and e._ncmSpawnIdx == n then
				e:SetPos(eEntry.vPos)
				if eEntry.aAng then e:SetAngles(eEntry.aAng) end
				e._spawnPos = eEntry.vPos
				e._spawnAng = eEntry.aAng
				if e._ncmSpawnEntry then
					e._ncmSpawnEntry.vPos = eEntry.vPos
					e._ncmSpawnEntry.aAng = eEntry.aAng
				end
				return
			end
		end
	end,
})

-- ── PNJ Hollow (zones de chasse WorldHunt) ───────────────────────────────────

local HUNT_KINDS = {
	{ id = "hunt_frequent", kind = "frequent", label = "Zones neutres" },
	{ id = "hunt_rotation", kind = "rotation", label = "Rotation" },
	{ id = "hunt_menos",    kind = "menos",    label = "Menos" },
}
local HUNT_SHARE = { "hunt_frequent", "hunt_rotation", "hunt_menos" }

local function huntZones(map, bCreate)
	if not (NCM_PNJ and NCM_PNJ.HuntSpawnZones) then return nil end
	if bCreate then
		NCM_PNJ.HuntSpawnZones[map] = NCM_PNJ.HuntSpawnZones[map] or {}
	end
	return NCM_PNJ.HuntSpawnZones[map]
end

local function huntKindOf(e)
	if isvector(e) then return "rotation" end
	if not istable(e) then return nil end
	if e.permanent or e.forceClass == "ncm_pnj_hollow_menos" then return "menos" end
	if e.frequent then return "frequent" end
	return "rotation"
end

local function huntPos(e)
	if isvector(e) then return e end
	if istable(e) then return e.pos end
end

local function encodeHuntZones(map)
	local list = huntZones(map)
	if not istable(list) then return {} end
	local out = {}
	for _, e in ipairs(list) do
		local pos = huntPos(e)
		if isvector(pos) then
			local row = { pos = encodeV(pos) }
			if istable(e) then
				row.frequent = e.frequent
				row.permanent = e.permanent
				row.forceClass = e.forceClass
				row.count = e.count
				row.hpMult = e.hpMult
				row.dmgMult = e.dmgMult
			end
			out[#out + 1] = row
		end
	end
	return out
end

local function restoreHuntZones(map, rows)
	if not NCM_PNJ then return end
	NCM_PNJ.HuntSpawnZones = NCM_PNJ.HuntSpawnZones or {}
	local nextList = {}
	for _, e in ipairs(rows or {}) do
		local row = { pos = decodeV(e.pos) }
		if e.frequent then row.frequent = true end
		if e.permanent then row.permanent = true end
		if isstring(e.forceClass) then row.forceClass = e.forceClass end
		if tonumber(e.count) then row.count = tonumber(e.count) end
		if tonumber(e.hpMult) then row.hpMult = tonumber(e.hpMult) end
		if tonumber(e.dmgMult) then row.dmgMult = tonumber(e.dmgMult) end
		nextList[#nextList + 1] = row
	end
	NCM_PNJ.HuntSpawnZones[map] = nextList
end

local function copyHuntFlags(src, kind)
	local out = { pos = nil }
	if kind == "frequent" then
		out.frequent = true
		if istable(src) then
			out.hpMult = src.hpMult
			out.dmgMult = src.dmgMult
			out.count = src.count
		end
	elseif kind == "menos" then
		out.permanent = true
		out.forceClass = (istable(src) and src.forceClass) or "ncm_pnj_hollow_menos"
		out.count = (istable(src) and src.count) or 1
	elseif istable(src) then
		out.hpMult = src.hpMult
		out.dmgMult = src.dmgMult
		out.count = src.count
	end
	return out
end

for _, spec in ipairs(HUNT_KINDS) do
	EVO_ConfigPos.RegisterProvider({
		id = spec.id,
		cat = "npc_hollow",
		label = spec.label,
		array = true,
		shareList = HUNT_SHARE,
		List = function(map)
			local out = {}
			local list = huntZones(map)
			if not istable(list) then return out end
			for i, e in ipairs(list) do
				if huntKindOf(e) == spec.kind then
					local pos = huntPos(e)
					if isvector(pos) then
						out[#out + 1] = {
							id = "zone:" .. i,
							label = spec.label .. " [" .. i .. "]",
							kind = KIND.POINT,
							pos = pos,
						}
					end
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			local list = huntZones(map)
			local n = tonumber(string.match(id or "", "^zone:(%d+)$"))
			if not (list and n and list[n] and isvector(data.pos)) then return end
			local p = Vector(data.pos.x, data.pos.y, data.pos.z)
			if isvector(list[n]) then
				list[n] = p
			else
				list[n].pos = p
			end
		end,
		EncodeList = encodeHuntZones,
		RestoreList = restoreHuntZones,
		Add = function(map, origin)
			local list = huntZones(map, true)
			if not list then return nil, "no_hunt" end
			local src
			local sel = tonumber(string.match(origin.selId or "", "^zone:(%d+)$"))
			if sel and list[sel] and huntKindOf(list[sel]) == spec.kind then
				src = list[sel]
			end
			local row = copyHuntFlags(src, spec.kind)
			row.pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z)
			list[#list + 1] = row
			return "zone:" .. #list
		end,
		Remove = function(map, id)
			local list = huntZones(map)
			local n = tonumber(string.match(id or "", "^zone:(%d+)$"))
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			return true
		end,
		Refresh = function(map, id)
			if CLIENT then return end
			local n = tonumber(string.match(id or "", "^zone:(%d+)$"))
			if n then
				local list = huntZones(map or game.GetMap())
				local pos = list and huntPos(list[n])
				if isvector(pos) and NCM_PNJ.MoveHuntZone then
					NCM_PNJ.MoveHuntZone(n, pos)
					return
				end
			end
			if NCM_PNJ.RebuildHuntZones then NCM_PNJ.RebuildHuntZones() end
		end,
	})
end

-- ── Ateliers / archives / missions / modèles ────────────────────────────────

local CRAFT_ROLES = {
	{ id = "craft_assassin", role = "assassin", label = "Assassin" },
	{ id = "craft_soin",     role = "soin",     label = "Medecin" },
	{ id = "craft_combat",   role = "combat",   label = "Combat" },
}
local CRAFT_SHARE = { "craft_assassin", "craft_soin", "craft_combat" }

local function craftStations(map)
	if not (EVO_CRAFT and EVO_CRAFT.CFG) then return nil end
	EVO_CRAFT.CFG.Stations = EVO_CRAFT.CFG.Stations or {}
	EVO_CRAFT.CFG.Stations[map] = EVO_CRAFT.CFG.Stations[map] or {}
	return EVO_CRAFT.CFG.Stations[map]
end

local function encodeCraftStations(map)
	local list = craftStations(map)
	if not list then return {} end
	local out = {}
	for _, st in ipairs(list) do
		if istable(st) and isvector(st.pos) then
			out[#out + 1] = {
				pos = encodeV(st.pos),
				yaw = tonumber(st.yaw) or 0,
				role = st.role,
				zonePos = st.zonePos and encodeV(st.zonePos) or nil,
				radius = st.radius,
				modelOffZ = tonumber(st.modelOffZ) or 0,
			}
		end
	end
	return out
end

local function restoreCraftStations(map, rows)
	local list = craftStations(map)
	if not list then return end
	local nextList = {}
	for _, st in ipairs(rows or {}) do
		nextList[#nextList + 1] = {
			pos = decodeV(st.pos),
			yaw = tonumber(st.yaw) or 0,
			role = st.role,
			zonePos = st.zonePos and decodeV(st.zonePos) or nil,
			radius = st.radius,
			modelOffZ = tonumber(st.modelOffZ) or 0,
		}
	end
	refillArray(list, nextList)
	if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
end

local function moveCraftStationEnt(n, pos, yaw)
	if CLIENT or not n then return false end
	local ang = Angle(0, tonumber(yaw) or 0, 0)
	for _, e in ipairs(ents.GetAll()) do
		if IsValid(e) and e._evoCraftStation == n then
			return EVO_ConfigPos.TeleportFrozen(e, pos, ang)
		end
	end
	return false
end

for _, spec in ipairs(CRAFT_ROLES) do
	EVO_ConfigPos.RegisterProvider({
		id = spec.id,
		cat = "ateliers",
		label = spec.label,
		array = true,
		shareList = CRAFT_SHARE,
		List = function(map)
			local out = {}
			local list = craftStations(map)
			if not list then return out end
			local roleLabel = EVO_CRAFT and EVO_CRAFT.RoleLabel and EVO_CRAFT.RoleLabel(spec.role) or spec.label
			for i, st in ipairs(list) do
				if istable(st) and st.role == spec.role and isvector(st.pos) then
					out[#out + 1] = {
						id = "model:" .. i,
						label = roleLabel .. " etabli [" .. i .. "]",
						kind = KIND.POINT_ANG,
						pos = (EVO_CRAFT.StationModelPos and EVO_CRAFT.StationModelPos(st)) or st.pos,
						ang = Angle(0, tonumber(st.yaw) or 0, 0),
						entClass = (EVO_CRAFT.CFG.StationModels or {})[spec.role],
					}
					out[#out + 1] = {
						id = "zone:" .. i,
						label = roleLabel .. " rond [" .. i .. "]",
						kind = KIND.POINT,
						pos = st.zonePos or st.pos,
					}
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			local list = craftStations(map)
			local n = tonumber(string.match(id or "", "^model:(%d+)$"))
			local z = tonumber(string.match(id or "", "^zone:(%d+)$"))
			local st = list and list[n or z]
			if not st then return end
			if n and isvector(data.pos) then
				st.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
				if data.ang then st.yaw = data.ang.y end
				if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
				local g = EVO_CRAFT.StationAnchor and EVO_CRAFT.StationAnchor(st)
				st.modelOffZ = g and (data.pos.z - g.z) or 0
			elseif z and isvector(data.pos) then
				st.zonePos = Vector(data.pos.x, data.pos.y, data.pos.z)
			end
			if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
		end,
		EncodeList = encodeCraftStations,
		RestoreList = restoreCraftStations,
		Add = function(map, origin)
			local list = craftStations(map)
			if not list then return nil, "no_craft" end
			list[#list + 1] = {
				pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
				yaw = origin.ang.y,
				role = spec.role,
				zonePos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			}
			if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
			return "model:" .. #list
		end,
		Remove = function(map, id)
			local list = craftStations(map)
			local n = tonumber(string.match(id or "", "^model:(%d+)$"))
				or tonumber(string.match(id or "", "^zone:(%d+)$"))
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
			return true
		end,
		Refresh = function(map, id)
			map = map or game.GetMap()
			if EVO_CRAFT.InvalidateAnchors then EVO_CRAFT.InvalidateAnchors() end
			if CLIENT then return end
			if not id then
				if EVO_CRAFT.RespawnDecor then EVO_CRAFT.RespawnDecor() end
				return
			end
			local n = tonumber(string.match(id, "^model:(%d+)$"))
			local list = craftStations(map)
			local st = n and list and list[n]
			if st and isvector(st.pos) then
				local pos = (EVO_CRAFT.StationModelPos and EVO_CRAFT.StationModelPos(st)) or st.pos
				if moveCraftStationEnt(n, pos, st.yaw) then return end
			end
			if EVO_CRAFT.RespawnDecor then EVO_CRAFT.RespawnDecor() end
		end,
	})
end

EVO_ConfigPos.RegisterProvider({
	id = "craft_coffres",
	cat = "ateliers",
	label = "Coffres de division",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_CRAFT and EVO_CRAFT.CFG and EVO_CRAFT.CFG.Coffres and EVO_CRAFT.CFG.Coffres[map]
		if not istable(list) then return out end
		for i, c in ipairs(list) do
			if istable(c) and isvector(c.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = (c.division or "Coffre") .. " [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = c.pos,
					ang = Angle(0, tonumber(c.yaw) or 0, 0),
					entClass = EVO_CRAFT.CFG.CoffreModel,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_CRAFT and EVO_CRAFT.CFG and EVO_CRAFT.CFG.Coffres and EVO_CRAFT.CFG.Coffres[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].yaw = data.ang.y end
	end,
	EncodeList = function(map)
		local list = EVO_CRAFT and EVO_CRAFT.CFG and EVO_CRAFT.CFG.Coffres and EVO_CRAFT.CFG.Coffres[map]
		if not istable(list) then return {} end
		local out = {}
		for _, c in ipairs(list) do
			if istable(c) and isvector(c.pos) then
				out[#out + 1] = { pos = encodeV(c.pos), yaw = tonumber(c.yaw) or 0, division = c.division }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not (EVO_CRAFT and EVO_CRAFT.CFG) then return end
		EVO_CRAFT.CFG.Coffres = EVO_CRAFT.CFG.Coffres or {}
		local nextList = {}
		for _, c in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(c.pos), yaw = tonumber(c.yaw) or 0, division = c.division }
		end
		EVO_CRAFT.CFG.Coffres[map] = nextList
	end,
	Add = function(map, origin)
		if not (EVO_CRAFT and EVO_CRAFT.CFG) then return nil, "no_craft" end
		EVO_CRAFT.CFG.Coffres = EVO_CRAFT.CFG.Coffres or {}
		EVO_CRAFT.CFG.Coffres[map] = EVO_CRAFT.CFG.Coffres[map] or {}
		local list = EVO_CRAFT.CFG.Coffres[map]
		local div = (isstring(map) and string.find(map, "hueco", 1, true)) and "Ordre 1" or "Division 11"
		local sel = tonumber(origin.selId)
		if sel and list[sel] and list[sel].division then
			div = list[sel].division
		elseif list[1] and list[1].division then
			div = list[1].division
		end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			yaw = origin.ang.y,
			division = div,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_CRAFT and EVO_CRAFT.CFG and EVO_CRAFT.CFG.Coffres and EVO_CRAFT.CFG.Coffres[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = EVO_CRAFT and EVO_CRAFT.CFG and EVO_CRAFT.CFG.Coffres
			list = list and list[map or game.GetMap()]
			local c = list and list[n]
			if c then
				for _, e in ipairs(ents.FindByClass("evo_coffre_division")) do
					if e._evoCoffreIdx == n then
						e:SetPos(c.pos)
						e:SetAngles(Angle(0, tonumber(c.yaw) or 0, 0))
						return
					end
				end
			end
		end
		if EVO_CRAFT.RespawnCoffres then EVO_CRAFT.RespawnCoffres() end
	end,
})

-- ── Bar (evo_business) : distillerie / coffre ────────────────────────────────

local function barStations(map, bCreate)
	if not EVO_BUSINESS then return nil end
	if bCreate and EVO_BUSINESS.EnsureStationList then
		return EVO_BUSINESS.EnsureStationList(map)
	end
	local cfg = EVO_BUSINESS.CFG
	if not cfg then return nil end
	cfg.Stations = cfg.Stations or {}
	cfg.Stations[map] = cfg.Stations[map] or {}
	return cfg.Stations[map]
end

local function barCoffres(map, bCreate)
	if not EVO_BUSINESS then return nil end
	if bCreate and EVO_BUSINESS.EnsureCoffreList then
		return EVO_BUSINESS.EnsureCoffreList(map)
	end
	local cfg = EVO_BUSINESS.CFG
	if not cfg then return nil end
	cfg.Coffres = cfg.Coffres or {}
	cfg.Coffres[map] = cfg.Coffres[map] or {}
	return cfg.Coffres[map]
end

local function encodeBarStations(map)
	local list = barStations(map)
	if not list then return {} end
	local out = {}
	for _, st in ipairs(list) do
		if istable(st) and isvector(st.pos) then
			out[#out + 1] = {
				pos = encodeV(st.pos),
				ang = encodeA(st.ang or Angle(0, 0, 0)),
				type = st.type,
				zonePos = st.zonePos and encodeV(st.zonePos) or nil,
				business = st.business or "bar",
			}
		end
	end
	return out
end

local function restoreBarStations(map, rows)
	local list = barStations(map, true)
	if not list then return end
	local nextList = {}
	for _, st in ipairs(rows or {}) do
		local stype = st.type
		if stype == "moulin" or stype == "cuve" or stype == "fermenteur" or not stype or stype == "" then
			stype = "distillerie"
		end
		nextList[#nextList + 1] = {
			pos = decodeV(st.pos),
			ang = decodeA(st.ang),
			type = stype,
			zonePos = st.zonePos and decodeV(st.zonePos) or nil,
			business = (isstring(st.business) and st.business ~= "" and st.business) or "bar",
		}
	end
	refillArray(list, nextList)
	if EVO_BUSINESS and EVO_BUSINESS.InvalidateAnchors then EVO_BUSINESS.InvalidateAnchors() end
end

local function pendingBusinessId(origin)
	local s = origin and origin.model
	if not (isstring(s) and s ~= "") then
		s = EVO_ConfigPos.PendingBusiness
	end
	if isstring(s) and s ~= "" and EVO_BUSINESS and EVO_BUSINESS.BusinessById and EVO_BUSINESS.BusinessById(s) then
		return s
	end
	return "bar"
end

local function bizLabelShort(sBiz)
	local t = EVO_BUSINESS and EVO_BUSINESS.BusinessById and EVO_BUSINESS.BusinessById(sBiz)
	return (t and t.label) or tostring(sBiz or "bar")
end

for _, id in ipairs({ "bar_moulin", "bar_cuve", "bar_fermenteur" }) do
	if EVO_ConfigPos.UnregisterProvider then EVO_ConfigPos.UnregisterProvider(id) end
end

EVO_ConfigPos.RegisterProvider({
	id = "bar_distillerie",
	cat = "ateliers",
	label = "Distillerie (Bar)",
	array = true,
	List = function(map)
		local out = {}
		local list = barStations(map)
		if not istable(list) then return out end
		local def = EVO_BUSINESS and EVO_BUSINESS.StationDef and EVO_BUSINESS.StationDef("distillerie")
		local name = (def and def.label) or "Distillerie"
		local mdl = def and def.model
		for i, e in ipairs(list) do
			if istable(e) and isvector(e.pos) and (e.type == "distillerie" or e.type == "moulin" or e.type == "cuve" or e.type == "fermenteur") then
				local sBiz = e.business or "bar"
				out[#out + 1] = {
					id = "model:" .. i,
					label = name .. " · " .. bizLabelShort(sBiz) .. " [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = e.ang or Angle(0, 0, 0),
					entClass = mdl,
				}
				out[#out + 1] = {
					id = "zone:" .. i,
					label = name .. " rond · " .. bizLabelShort(sBiz) .. " [" .. i .. "]",
					kind = KIND.POINT,
					pos = e.zonePos or e.pos,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = barStations(map)
		local n = tonumber(string.match(id or "", "^model:(%d+)$"))
		local z = tonumber(string.match(id or "", "^zone:(%d+)$"))
		local e = list and list[n or z]
		if not e then return end
		if n and isvector(data.pos) then
			e.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
			if data.ang then e.ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
		elseif z and isvector(data.pos) then
			e.zonePos = Vector(data.pos.x, data.pos.y, data.pos.z)
		end
		if EVO_BUSINESS and EVO_BUSINESS.InvalidateAnchors then EVO_BUSINESS.InvalidateAnchors() end
	end,
	EncodeList = encodeBarStations,
	RestoreList = restoreBarStations,
	Add = function(map, origin)
		local list = barStations(map, true)
		if not list then return nil, "no_business" end
		local sBiz = pendingBusinessId(origin)
		list[#list + 1] = {
			type = "distillerie",
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
			zonePos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			business = sBiz,
		}
		if EVO_BUSINESS and EVO_BUSINESS.InvalidateAnchors then EVO_BUSINESS.InvalidateAnchors() end
		return "model:" .. #list
	end,
	Remove = function(map, id)
		local list = barStations(map)
		local n = tonumber(string.match(id or "", "^model:(%d+)$"))
			or tonumber(string.match(id or "", "^zone:(%d+)$"))
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		if EVO_BUSINESS and EVO_BUSINESS.InvalidateAnchors then EVO_BUSINESS.InvalidateAnchors() end
		return true
	end,
	Refresh = function(map, id)
		map = map or game.GetMap()
		if EVO_BUSINESS and EVO_BUSINESS.InvalidateAnchors then EVO_BUSINESS.InvalidateAnchors() end
		if CLIENT then return end
		if not id then
			if EVO_BUSINESS and EVO_BUSINESS.RespawnStations then EVO_BUSINESS.RespawnStations() end
			return
		end
		local n = tonumber(string.match(id, "^model:(%d+)$"))
		local list = barStations(map)
		local e = n and list and list[n]
		if e and isvector(e.pos) then
			local pos = EVO_BUSINESS.StationSpot and EVO_BUSINESS.StationSpot(e) or e.pos
			if EVO_BUSINESS.MoveStationEnt and EVO_BUSINESS.MoveStationEnt(n, pos, e.ang) then return end
		end
		if EVO_BUSINESS and EVO_BUSINESS.RespawnStations then EVO_BUSINESS.RespawnStations() end
	end,
})

do
	local oldApply = EVO_ConfigPos.ApplyPersisted
	if isfunction(oldApply) and not EVO_ConfigPos._barDistillerieMigrate then
		EVO_ConfigPos._barDistillerieMigrate = true
		function EVO_ConfigPos.ApplyPersisted(map)
			map = map or game.GetMap()
			local function moveLists(store)
				local lists = EVO_ConfigPos.Lists[store]
				if not istable(lists) then return end
				if not istable(lists.bar_distillerie) then
					local src = lists.bar_moulin or lists.bar_cuve or lists.bar_fermenteur
					if istable(src) then lists.bar_distillerie = src end
				end
				lists.bar_moulin, lists.bar_cuve, lists.bar_fermenteur = nil, nil, nil
			end
			moveLists(map)
			moveLists("_global")
			return oldApply(map)
		end
	end
end

local function encodeBarCoffres(map)
	local list = barCoffres(map)
	if not list then return {} end
	local out = {}
	for _, c in ipairs(list) do
		if istable(c) and isvector(c.pos) then
			out[#out + 1] = {
				pos = encodeV(c.pos),
				ang = encodeA(c.ang or Angle(0, 0, 0)),
				business = c.business,
				label = c.label,
				model = c.model,
			}
		end
	end
	return out
end

local function restoreBarCoffres(map, rows)
	local list = barCoffres(map, true)
	if not list then return end
	local nextList = {}
	for _, c in ipairs(rows or {}) do
		nextList[#nextList + 1] = {
			pos = decodeV(c.pos),
			ang = decodeA(c.ang),
			business = c.business or "bar",
			label = c.label,
			model = c.model,
		}
	end
	refillArray(list, nextList)
end

EVO_ConfigPos.RegisterProvider({
	id = "bar_coffre",
	cat = "ateliers",
	label = "Coffre du Bar",
	array = true,
	List = function(map)
		local out = {}
		local list = barCoffres(map)
		if not istable(list) then return out end
		local mdl = EVO_BUSINESS and EVO_BUSINESS.CFG and EVO_BUSINESS.CFG.CoffreModel
		for i, c in ipairs(list) do
			if istable(c) and isvector(c.pos) then
				local sBiz = c.business or "bar"
				out[#out + 1] = {
					id = "model:" .. i,
					label = (c.label or "Coffre") .. " · " .. bizLabelShort(sBiz) .. " [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = c.pos,
					ang = c.ang or Angle(0, 0, 0),
					entClass = c.model or mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = barCoffres(map)
		local n = tonumber(string.match(id or "", "^model:(%d+)$"))
		local e = list and n and list[n]
		if not e then return end
		if isvector(data.pos) then
			e.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		end
		if data.ang then e.ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
	end,
	EncodeList = encodeBarCoffres,
	RestoreList = restoreBarCoffres,
	Add = function(map, origin)
		local list = barCoffres(map, true)
		if not list then return nil, "no_business" end
		local sBiz = pendingBusinessId(origin)
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
			business = sBiz,
			label = "Coffre · " .. bizLabelShort(sBiz),
		}
		return "model:" .. #list
	end,
	Remove = function(map, id)
		local list = barCoffres(map)
		local n = tonumber(string.match(id or "", "^model:(%d+)$"))
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		map = map or game.GetMap()
		if CLIENT then return end
		if not id then
			if EVO_BUSINESS and EVO_BUSINESS.RespawnCoffres then EVO_BUSINESS.RespawnCoffres() end
			return
		end
		local n = tonumber(string.match(id, "^model:(%d+)$"))
		local list = barCoffres(map)
		local e = n and list and list[n]
		if e and isvector(e.pos) then
			if EVO_BUSINESS and EVO_BUSINESS.MoveCoffreEnt and EVO_BUSINESS.MoveCoffreEnt(n, e.pos, e.ang) then return end
		end
		if EVO_BUSINESS and EVO_BUSINESS.RespawnCoffres then EVO_BUSINESS.RespawnCoffres() end
	end,
})

-- ── Ateliers scientifiques (etablis labo + postes d'analyse) ─────────────────

local function sciHub()
	return EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.Hub
end

local function sciPlacements(map, bCreate)
	local hub = sciHub()
	if not hub then return nil end
	hub.EtabliePlacements = hub.EtabliePlacements or {}
	if bCreate then
		hub.EtabliePlacements[map] = hub.EtabliePlacements[map] or {}
	end
	return hub.EtabliePlacements[map]
end

local function sciEtablieDef(sId)
	return EVO_SCIENCE and EVO_SCIENCE.EtablieById and EVO_SCIENCE.EtablieById(sId)
end

local function encodeSciPlacements(map)
	local list = sciPlacements(map)
	if not istable(list) then return {} end
	local out = {}
	for _, e in ipairs(list) do
		if istable(e) and isvector(e.pos) then
			out[#out + 1] = {
				id = e.id,
				pos = encodeV(e.pos),
				ang = encodeA(e.ang),
				zonePos = e.zonePos and encodeV(e.zonePos) or nil,
				coffre = e.coffre,
				label = e.label,
			}
		end
	end
	return out
end

local function restoreSciPlacements(map, rows)
	local hub = sciHub()
	if not hub then return end
	hub.EtabliePlacements = hub.EtabliePlacements or {}
	local nextList = {}
	for _, e in ipairs(rows or {}) do
		nextList[#nextList + 1] = {
			id = e.id,
			pos = decodeV(e.pos),
			ang = decodeA(e.ang),
			zonePos = e.zonePos and decodeV(e.zonePos) or nil,
			coffre = e.coffre,
			label = e.label,
		}
	end
	hub.EtabliePlacements[map] = nextList
	if EVO_SCIENCE.InvalidateEtablieAnchors then EVO_SCIENCE.InvalidateEtablieAnchors() end
end

local function moveSciEtablieEnt(n, pos, ang)
	if CLIENT or not n then return false end
	for _, e in ipairs(ents.GetAll()) do
		if IsValid(e) and e._evoSciEtablie == n then
			e:SetPos(pos)
			if ang then e:SetAngles(ang) end
			return true
		end
	end
	return false
end

local SCI_ETAB_SHARE = { "sci_etablie_01", "sci_etablie_02", "sci_etablie_03" }
local SCI_ETAB_KINDS = {
	{ id = "sci_etablie_01", etablie = "etablie_01", label = "Frigo labo" },
	{ id = "sci_etablie_02", etablie = "etablie_02", label = "Preparation" },
	{ id = "sci_etablie_03", etablie = "etablie_03", label = "Ordinateur" },
}

for _, spec in ipairs(SCI_ETAB_KINDS) do
	EVO_ConfigPos.RegisterProvider({
		id = spec.id,
		cat = "ateliers",
		label = spec.label,
		array = true,
		shareList = SCI_ETAB_SHARE,
		List = function(map)
			local out = {}
			local list = sciPlacements(map)
			if not istable(list) then return out end
			local def = sciEtablieDef(spec.etablie)
			local name = (def and def.name) or spec.label
			for i, e in ipairs(list) do
				if istable(e) and e.id == spec.etablie and isvector(e.pos) then
					out[#out + 1] = {
						id = "model:" .. i,
						label = name .. " [" .. i .. "]",
						kind = KIND.POINT_ANG,
						pos = e.pos,
						ang = e.ang or Angle(0, 0, 0),
						entClass = def and def.model or nil,
					}
					out[#out + 1] = {
						id = "zone:" .. i,
						label = name .. " rond [" .. i .. "]",
						kind = KIND.POINT,
						pos = e.zonePos or e.pos,
					}
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			local list = sciPlacements(map)
			local n = tonumber(string.match(id or "", "^model:(%d+)$"))
			local z = tonumber(string.match(id or "", "^zone:(%d+)$"))
			local e = list and list[n or z]
			if not e then return end
			if n and isvector(data.pos) then
				e.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
				if data.ang then e.ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
			elseif z and isvector(data.pos) then
				e.zonePos = Vector(data.pos.x, data.pos.y, data.pos.z)
			end
			if EVO_SCIENCE.InvalidateEtablieAnchors then EVO_SCIENCE.InvalidateEtablieAnchors() end
		end,
		EncodeList = encodeSciPlacements,
		RestoreList = restoreSciPlacements,
		Add = function(map, origin)
			local list = sciPlacements(map, true)
			if not list then return nil, "no_science" end
			local row = {
				id = spec.etablie,
				pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
				ang = Angle(0, origin.ang.y, 0),
				zonePos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			}
			if spec.etablie == "etablie_01" then
				row.coffre = (isstring(map) and string.find(map, "hueco", 1, true)) and "Ordre 3" or "Division 12"
				row.label = "Frigo du laboratoire"
				local sel = tonumber(string.match(origin.selId or "", "^model:(%d+)$"))
					or tonumber(string.match(origin.selId or "", "^zone:(%d+)$"))
				if sel and list[sel] and list[sel].id == spec.etablie then
					row.coffre = list[sel].coffre or row.coffre
					row.label = list[sel].label or row.label
				end
			end
			list[#list + 1] = row
			if EVO_SCIENCE.InvalidateEtablieAnchors then EVO_SCIENCE.InvalidateEtablieAnchors() end
			return "model:" .. #list
		end,
		Remove = function(map, id)
			local list = sciPlacements(map)
			local n = tonumber(string.match(id or "", "^model:(%d+)$"))
				or tonumber(string.match(id or "", "^zone:(%d+)$"))
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			if EVO_SCIENCE.InvalidateEtablieAnchors then EVO_SCIENCE.InvalidateEtablieAnchors() end
			return true
		end,
		Refresh = function(map, id)
			map = map or game.GetMap()
			if EVO_SCIENCE.InvalidateEtablieAnchors then EVO_SCIENCE.InvalidateEtablieAnchors() end
			if CLIENT then return end
			if not id then
				if EVO_SCIENCE.RespawnEtablies then EVO_SCIENCE.RespawnEtablies() end
				return
			end
			local n = tonumber(string.match(id, "^model:(%d+)$"))
			local list = sciPlacements(map)
			local e = n and list and list[n]
			if e and isvector(e.pos) then
				local pos = EVO_SCIENCE.EtablieSpot and EVO_SCIENCE.EtablieSpot(e) or e.pos
				if moveSciEtablieEnt(n, pos, e.ang) then return end
			end
			if EVO_SCIENCE.RespawnEtablies then EVO_SCIENCE.RespawnEtablies() end
		end,
	})
end

EVO_ConfigPos.RegisterProvider({
	id = "sci_lab_zones",
	cat = "ateliers",
	label = "Postes analyse",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.LabZones and EVO_SCIENCE.CFG.LabZones[map]
		if not istable(list) then return out end
		for i, z in ipairs(list) do
			if istable(z) and isvector(z.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Analyse [" .. i .. "]",
					kind = KIND.POINT,
					pos = z.pos,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.LabZones and EVO_SCIENCE.CFG.LabZones[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if EVO_SCIENCE.InvalidateLabAnchors then EVO_SCIENCE.InvalidateLabAnchors() end
	end,
	EncodeList = function(map)
		local list = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.LabZones and EVO_SCIENCE.CFG.LabZones[map]
		if not istable(list) then return {} end
		local out = {}
		for _, z in ipairs(list) do
			if istable(z) and isvector(z.pos) then
				out[#out + 1] = { pos = encodeV(z.pos), radius = z.radius }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not (EVO_SCIENCE and EVO_SCIENCE.CFG) then return end
		EVO_SCIENCE.CFG.LabZones = EVO_SCIENCE.CFG.LabZones or {}
		local nextList = {}
		for _, z in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(z.pos), radius = z.radius or 55 }
		end
		EVO_SCIENCE.CFG.LabZones[map] = nextList
		if EVO_SCIENCE.InvalidateLabAnchors then EVO_SCIENCE.InvalidateLabAnchors() end
	end,
	Add = function(map, origin)
		if not (EVO_SCIENCE and EVO_SCIENCE.CFG) then return nil, "no_science" end
		EVO_SCIENCE.CFG.LabZones = EVO_SCIENCE.CFG.LabZones or {}
		EVO_SCIENCE.CFG.LabZones[map] = EVO_SCIENCE.CFG.LabZones[map] or {}
		local list = EVO_SCIENCE.CFG.LabZones[map]
		local r = 55
		if list[1] and tonumber(list[1].radius) then r = list[1].radius end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			radius = r,
		}
		if EVO_SCIENCE.InvalidateLabAnchors then EVO_SCIENCE.InvalidateLabAnchors() end
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_SCIENCE and EVO_SCIENCE.CFG and EVO_SCIENCE.CFG.LabZones and EVO_SCIENCE.CFG.LabZones[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		if EVO_SCIENCE.InvalidateLabAnchors then EVO_SCIENCE.InvalidateLabAnchors() end
		return true
	end,
	Refresh = function()
		if EVO_SCIENCE.InvalidateLabAnchors then EVO_SCIENCE.InvalidateLabAnchors() end
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "livre_stations",
	cat = "archives",
	label = "Zones",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Stations and EVO_LIVRE.CFG.Stations[map]
		if not istable(list) then return out end
		for i, st in ipairs(list) do
			if istable(st) and isvector(st.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Archive [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = st.pos,
					ang = Angle(0, tonumber(st.yaw) or 0, 0),
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Stations and EVO_LIVRE.CFG.Stations[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].yaw = data.ang.y end
		if EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
	end,
	EncodeList = function(map)
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Stations and EVO_LIVRE.CFG.Stations[map]
		if not istable(list) then return {} end
		local out = {}
		for _, st in ipairs(list) do
			if istable(st) and isvector(st.pos) then
				out[#out + 1] = {
					pos = encodeV(st.pos),
					yaw = tonumber(st.yaw) or 0,
					radius = st.radius,
					fac = st.fac,
				}
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not (EVO_LIVRE and EVO_LIVRE.CFG) then return end
		EVO_LIVRE.CFG.Stations = EVO_LIVRE.CFG.Stations or {}
		local nextList = {}
		for _, st in ipairs(rows or {}) do
			nextList[#nextList + 1] = {
				pos = decodeV(st.pos),
				yaw = tonumber(st.yaw) or 0,
				radius = st.radius,
				fac = st.fac,
			}
		end
		EVO_LIVRE.CFG.Stations[map] = nextList
		if EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
	end,
	Add = function(map, origin)
		if not (EVO_LIVRE and EVO_LIVRE.CFG) then return nil, "no_livre" end
		EVO_LIVRE.CFG.Stations = EVO_LIVRE.CFG.Stations or {}
		EVO_LIVRE.CFG.Stations[map] = EVO_LIVRE.CFG.Stations[map] or {}
		local list = EVO_LIVRE.CFG.Stations[map]
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			yaw = origin.ang.y,
		}
		if EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Stations and EVO_LIVRE.CFG.Stations[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		if EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
		return true
	end,
	Refresh = function()
		if EVO_LIVRE.InvalidateAnchors then EVO_LIVRE.InvalidateAnchors() end
	end,
})

-- ── ENCLUME DE FORGE (user 09/22) ───────────────────────────────────────────
-- NCM_FORGE.AUTO_SPAWN_POSITIONS[map] = liste de { pos, ang }. Le spawn SNAPPE
-- deja au sol tout seul (TraceLine dans sv_autospawn), donc le Z pose ici n'est
-- qu'un point de depart : inutile de le regler au pixel.
-- Refresh repose les entites : sans ca le gizmo bougeait la config sans bouger
-- l'enclume visible, et l'ecart ne se voyait qu'au redemarrage.
local function forgeList(map)
	if not NCM_FORGE then return nil end
	NCM_FORGE.AUTO_SPAWN_POSITIONS = NCM_FORGE.AUTO_SPAWN_POSITIONS or {}
	NCM_FORGE.AUTO_SPAWN_POSITIONS[map] = NCM_FORGE.AUTO_SPAWN_POSITIONS[map] or {}
	return NCM_FORGE.AUTO_SPAWN_POSITIONS[map]
end

local function forgeRespawn()
	if SERVER and NCM_FORGE and NCM_FORGE.RespawnForges then NCM_FORGE.RespawnForges() end
end

EVO_ConfigPos.RegisterProvider({
	id = "forge_enclumes",
	cat = "ateliers",
	label = "Enclume de forge",
	array = true,
	List = function(map)
		local out = {}
		local list = forgeList(map)
		if not istable(list) then return out end
		for i, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Enclume [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = isangle(e.ang) and Angle(0, e.ang.y, 0) or Angle(0, 0, 0),
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = forgeList(map)
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		-- Yaw SEUL : une enclume couchee n'a aucun sens, et le spawn force deja
		-- pitch/roll a 0 de son cote.
		if data.ang then list[n].ang = Angle(0, data.ang.y, 0) end
	end,
	EncodeList = function(map)
		local list = forgeList(map)
		if not istable(list) then return {} end
		local out = {}
		for _, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = { pos = encodeV(e.pos), yaw = isangle(e.ang) and e.ang.y or 0 }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		local list = forgeList(map)
		if not istable(list) then return end
		local nextList = {}
		for _, e in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(e.pos), ang = Angle(0, tonumber(e.yaw) or 0, 0) }
		end
		NCM_FORGE.AUTO_SPAWN_POSITIONS[map] = nextList
		forgeRespawn()
	end,
	Add = function(map, origin)
		local list = forgeList(map)
		if not istable(list) then return nil, "no_forge" end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		forgeRespawn()
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = forgeList(map)
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		forgeRespawn()
		return true
	end,
	Refresh = forgeRespawn,
})

local function encodeDecorList(src)
	if not istable(src) then return {} end
	local out = {}
	for _, d in ipairs(src) do
		if istable(d) and isvector(d.pos) then
			out[#out + 1] = { model = d.model, pos = encodeV(d.pos), yaw = tonumber(d.yaw) or 0 }
		end
	end
	return out
end

local function restoreDecorList(dst, map, rows)
	local nextList = {}
	for _, d in ipairs(rows or {}) do
		nextList[#nextList + 1] = { model = d.model, pos = decodeV(d.pos), yaw = tonumber(d.yaw) or 0 }
	end
	dst[map] = nextList
end

EVO_ConfigPos.RegisterProvider({
	id = "livre_decor",
	cat = "archives",
	label = "Etageres",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Decor and EVO_LIVRE.CFG.Decor[map]
		if not istable(list) then return out end
		for i, d in ipairs(list) do
			if istable(d) and isvector(d.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Etagere [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = d.pos,
					ang = Angle(0, tonumber(d.yaw) or 0, 0),
					entClass = d.model,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Decor and EVO_LIVRE.CFG.Decor[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].yaw = data.ang.y end
	end,
	EncodeList = function(map)
		return encodeDecorList(EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Decor and EVO_LIVRE.CFG.Decor[map])
	end,
	RestoreList = function(map, rows)
		if not (EVO_LIVRE and EVO_LIVRE.CFG) then return end
		EVO_LIVRE.CFG.Decor = EVO_LIVRE.CFG.Decor or {}
		restoreDecorList(EVO_LIVRE.CFG.Decor, map, rows)
	end,
	Add = function(map, origin)
		if not (EVO_LIVRE and EVO_LIVRE.CFG) then return nil, "no_livre" end
		EVO_LIVRE.CFG.Decor = EVO_LIVRE.CFG.Decor or {}
		EVO_LIVRE.CFG.Decor[map] = EVO_LIVRE.CFG.Decor[map] or {}
		local list = EVO_LIVRE.CFG.Decor[map]
		local mdl = origin.model
		if not (isstring(mdl) and mdl ~= "") then
			mdl = (list[1] and list[1].model) or "models/echoes/env/sm_b_012_bookshelf_01a.mdl"
		end
		list[#list + 1] = {
			model = mdl,
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			yaw = origin.ang.y,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Decor and EVO_LIVRE.CFG.Decor[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(_, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = EVO_LIVRE and EVO_LIVRE.CFG and EVO_LIVRE.CFG.Decor
			list = list and list[game.GetMap()]
			local d = list and list[n]
			if d then
				for _, e in ipairs(ents.GetAll()) do
					if IsValid(e) and e._evoLivreDecorId == n then
						e:SetPos(d.pos)
						e:SetAngles(Angle(0, tonumber(d.yaw) or 0, 0))
						return
					end
				end
			end
		end
		if EVO_LIVRE.RespawnDecor then EVO_LIVRE.RespawnDecor() end
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "missive_zone",
	cat = "missions",
	label = "Zone du bureau",
	List = function(map)
		local z = EVO_MISSIVE and EVO_MISSIVE.Zones and EVO_MISSIVE.Zones[map]
		if not (istable(z) and isvector(z.pos)) then return {} end
		return {{
			id = "zone",
			label = "Bureau des missions",
			kind = KIND.POINT,
			pos = z.pos,
		}}
	end,
	Apply = function(map, _, data)
		local z = EVO_MISSIVE and EVO_MISSIVE.Zones and EVO_MISSIVE.Zones[map]
		if not (z and isvector(data.pos)) then return end
		z.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
	end,
	RestoreExtra = function(map, _, data)
		if not (EVO_MISSIVE and EVO_MISSIVE.Zones and isvector(data.pos)) then return end
		EVO_MISSIVE.Zones[map] = {
			pos = Vector(data.pos.x, data.pos.y, data.pos.z),
			radius = (EVO_MISSIVE.Zones[map] and EVO_MISSIVE.Zones[map].radius) or 140,
		}
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
	end,
	Add = function(map, origin)
		if not EVO_MISSIVE then return nil, "no_missive" end
		EVO_MISSIVE.Zones = EVO_MISSIVE.Zones or {}
		local z = EVO_MISSIVE.Zones[map]
		if z and isvector(z.pos) then return nil, "exists" end
		EVO_MISSIVE.Zones[map] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			radius = 140,
		}
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
		return "zone"
	end,
	Remove = function(map)
		if not (EVO_MISSIVE and EVO_MISSIVE.Zones) then return false end
		EVO_MISSIVE.Zones[map] = nil
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
		return true
	end,
	Refresh = function()
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "missive_desk",
	cat = "missions",
	label = "Table des missions",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_MISSIVE and EVO_MISSIVE.Decor and EVO_MISSIVE.Decor[map]
		if not istable(list) then return out end
		local mdl = EVO_MISSIVE.DeskModel
		for i, d in ipairs(list) do
			if istable(d) and isvector(d.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Table des missions [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = d.pos,
					ang = Angle(0, tonumber(d.yaw) or 0, 0),
					entClass = mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		if not (EVO_MISSIVE and EVO_MISSIVE.Decor) then return end
		local list = EVO_MISSIVE.Decor[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].yaw = data.ang.y end
		-- Le bureau physique est le centre de la zone E (sh_config missive).
		EVO_MISSIVE.Zones = EVO_MISSIVE.Zones or {}
		local z = EVO_MISSIVE.Zones[map]
		if z then
			z.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		end
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
	end,
	EncodeList = function(map)
		local list = EVO_MISSIVE and EVO_MISSIVE.Decor and EVO_MISSIVE.Decor[map]
		if not istable(list) then return {} end
		local out = {}
		for _, d in ipairs(list) do
			if istable(d) and isvector(d.pos) then
				out[#out + 1] = { pos = encodeV(d.pos), yaw = tonumber(d.yaw) or 0 }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_MISSIVE then return end
		EVO_MISSIVE.Decor = EVO_MISSIVE.Decor or {}
		local nextList = {}
		for _, d in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(d.pos), yaw = tonumber(d.yaw) or 0 }
		end
		EVO_MISSIVE.Decor[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_MISSIVE then return nil, "no_missive" end
		EVO_MISSIVE.Decor = EVO_MISSIVE.Decor or {}
		EVO_MISSIVE.Decor[map] = EVO_MISSIVE.Decor[map] or {}
		local list = EVO_MISSIVE.Decor[map]
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			yaw = origin.ang.y,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_MISSIVE and EVO_MISSIVE.Decor and EVO_MISSIVE.Decor[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(_, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = EVO_MISSIVE and EVO_MISSIVE.Decor
			list = list and list[game.GetMap()]
			local d = list and list[n]
			if d then
				for _, e in ipairs(ents.GetAll()) do
					if IsValid(e) and e._evoMissiveDeskIdx == n then
						EVO_ConfigPos.TeleportFrozen(e, d.pos, Angle(0, tonumber(d.yaw) or 0, 0))
						if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
						return
					end
				end
			end
		end
		if EVO_MISSIVE.RespawnDesk then EVO_MISSIVE.RespawnDesk() end
		if EVO_MISSIVE.InvalidateAnchor then EVO_MISSIVE.InvalidateAnchor() end
	end,
})

local function questBoardModel(map)
	local cfg = NCM_QUETE and NCM_QUETE.QUEST_BOARD
	if not cfg then return nil end
	return (cfg.modelByMap and cfg.modelByMap[map]) or cfg.model
end

local function questBoardList(map)
	return NCM_QUETE and NCM_QUETE.QUEST_BOARD_POSITIONS and NCM_QUETE.QUEST_BOARD_POSITIONS[map]
end

local function mapBoardList(map)
	if EVO_CARTE and EVO_CARTE.BoardSpawnsFor then
		return EVO_CARTE.BoardSpawnsFor(map)
	end
	return EVO_CARTE and EVO_CARTE.BoardSpawns and EVO_CARTE.BoardSpawns[map]
end

EVO_ConfigPos.RegisterProvider({
	id = "quest_boards",
	cat = "tableaux",
	label = "Tableau des quetes",
	array = true,
	List = function(map)
		local out = {}
		local list = questBoardList(map)
		if not istable(list) then return out end
		local mdl = questBoardModel(map)
		for i, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Tableau quetes [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = Angle(0, (e.ang and e.ang.y) or 0, 0),
					entClass = mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = questBoardList(map)
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].ang = Angle(0, data.ang.y, 0) end
	end,
	EncodeList = function(map)
		local list = questBoardList(map)
		if not istable(list) then return {} end
		local out = {}
		for _, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = { pos = encodeV(e.pos), ang = encodeA(e.ang or Angle(0, 0, 0)) }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not NCM_QUETE then return end
		NCM_QUETE.QUEST_BOARD_POSITIONS = NCM_QUETE.QUEST_BOARD_POSITIONS or {}
		local nextList = {}
		for _, e in ipairs(rows or {}) do
			local a = decodeA(e.ang)
			nextList[#nextList + 1] = { pos = decodeV(e.pos), ang = Angle(0, a.y, 0) }
		end
		NCM_QUETE.QUEST_BOARD_POSITIONS[map] = nextList
	end,
	Add = function(map, origin)
		if not NCM_QUETE then return nil, "no_quete" end
		NCM_QUETE.QUEST_BOARD_POSITIONS = NCM_QUETE.QUEST_BOARD_POSITIONS or {}
		NCM_QUETE.QUEST_BOARD_POSITIONS[map] = NCM_QUETE.QUEST_BOARD_POSITIONS[map] or {}
		local list = NCM_QUETE.QUEST_BOARD_POSITIONS[map]
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = questBoardList(map)
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = questBoardList(map or game.GetMap())
			local d = list and list[n]
			if d then
				for _, e in ipairs(ents.GetAll()) do
					if IsValid(e) and e._ncmQuestBoardIdx == n then
						e:SetPos(d.pos)
						e:SetAngles(Angle(0, (d.ang and d.ang.y) or 0, 0))
						local phys = e:GetPhysicsObject()
						if IsValid(phys) then phys:EnableMotion(false) phys:Wake() end
						return
					end
				end
			end
		end
		if NCM_QUETE and NCM_QUETE.RespawnQuestBoards then NCM_QUETE.RespawnQuestBoards() end
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "map_boards",
	cat = "tableaux",
	label = "Tableau carte du monde",
	array = true,
	List = function(map)
		local out = {}
		local list = mapBoardList(map)
		if not istable(list) then return out end
		local mdl = EVO_CARTE and EVO_CARTE.BoardModelFor and EVO_CARTE.BoardModelFor(map)
		for i, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Carte du monde [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = Angle(0, (e.ang and e.ang.y) or 0, 0),
					entClass = mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = mapBoardList(map)
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].ang = Angle(0, data.ang.y, 0) end
	end,
	EncodeList = function(map)
		local list = mapBoardList(map)
		if not istable(list) then return {} end
		local out = {}
		for _, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					pos = encodeV(e.pos),
					ang = encodeA(e.ang or Angle(0, 0, 0)),
					skin = tonumber(e.skin) or 0,
					zoff = e.zoff,
				}
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_CARTE then return end
		EVO_CARTE.BoardSpawns = EVO_CARTE.BoardSpawns or {}
		local nextList = {}
		for _, e in ipairs(rows or {}) do
			local a = decodeA(e.ang)
			nextList[#nextList + 1] = {
				pos = decodeV(e.pos),
				ang = Angle(0, a.y, 0),
				skin = tonumber(e.skin) or 0,
				zoff = tonumber(e.zoff),
			}
		end
		EVO_CARTE.BoardSpawns[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_CARTE then return nil, "no_carte" end
		EVO_CARTE.BoardSpawns = EVO_CARTE.BoardSpawns or {}
		local list = mapBoardList(map)
		if not list then
			list = {}
			EVO_CARTE.BoardSpawns[map] = list
		end
		local skin, zoff = 0, nil
		local sel = tonumber(origin.selId)
		if sel and list[sel] then
			skin = tonumber(list[sel].skin) or 0
			zoff = list[sel].zoff
		elseif list[1] then
			skin = tonumber(list[1].skin) or 0
			zoff = list[1].zoff
		end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
			skin = skin,
			zoff = zoff,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = mapBoardList(map)
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = mapBoardList(map or game.GetMap())
			local d = list and list[n]
			if d then
				for _, e in ipairs(ents.FindByClass("evo_carte_prop")) do
					if e._evoCarteIdx == n then
						e:SetPos(d.pos)
						e:SetAngles(Angle(0, (d.ang and d.ang.y) or 0, 0))
						if d.skin then e:SetSkin(d.skin) end
						local phys = e:GetPhysicsObject()
						if IsValid(phys) then phys:EnableMotion(false) phys:Wake() end
						return
					end
				end
			end
		end
		if EVO_CARTE and EVO_CARTE.RespawnBoardProps then EVO_CARTE.RespawnBoardProps() end
	end,
})

local function carnetList(map)
	return EVO_CARNET and EVO_CARNET.Spawns and EVO_CARNET.Spawns[map]
end

EVO_ConfigPos.RegisterProvider({
	id = "carnet_commande",
	cat = "tableaux",
	label = "Carnet de commande",
	array = true,
	List = function(map)
		local out = {}
		local list = carnetList(map)
		if not istable(list) then return out end
		local mdl = EVO_CARNET and EVO_CARNET.ModelFor and EVO_CARNET.ModelFor(map)
		for i, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Carnet de commande [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = e.pos,
					ang = Angle(0, (e.ang and e.ang.y) or 0, 0),
					entClass = mdl,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = carnetList(map)
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].ang = Angle(0, data.ang.y, 0) end
	end,
	EncodeList = function(map)
		local list = carnetList(map)
		if not istable(list) then return {} end
		local out = {}
		for _, e in ipairs(list) do
			if istable(e) and isvector(e.pos) then
				out[#out + 1] = {
					pos = encodeV(e.pos),
					ang = encodeA(e.ang or Angle(0, 0, 0)),
				}
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_CARNET then return end
		EVO_CARNET.Spawns = EVO_CARNET.Spawns or {}
		local nextList = {}
		for _, e in ipairs(rows or {}) do
			local a = decodeA(e.ang)
			nextList[#nextList + 1] = {
				pos = decodeV(e.pos),
				ang = Angle(0, a.y, 0),
			}
		end
		EVO_CARNET.Spawns[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_CARNET then return nil, "no_carnet" end
		EVO_CARNET.Spawns = EVO_CARNET.Spawns or {}
		local list = carnetList(map)
		if not list then
			list = {}
			EVO_CARNET.Spawns[map] = list
		end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = carnetList(map)
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		if CLIENT then return end
		local n = tonumber(id)
		if n then
			local list = carnetList(map or game.GetMap())
			local d = list and list[n]
			if d then
				for _, e in ipairs(ents.FindByClass("evo_carnet_prop")) do
					if e._evoCarnetIdx == n then
						e:SetPos(d.pos)
						e:SetAngles(Angle(0, (d.ang and d.ang.y) or 0, 0))
						local phys = e:GetPhysicsObject()
						if IsValid(phys) then phys:EnableMotion(false) phys:Wake() end
						return
					end
				end
			end
		end
		if EVO_CARNET and EVO_CARNET.Respawn then EVO_CARNET.Respawn() end
	end,
})

-- PROPS DU CODE (EVO_ConfigPos.WorldModelDefaults, 09/20) : ajoutés en FIN de liste à la 1re
-- lecture, et de nouveau après chaque RestoreList (qui repart d'une table neuve). La clé
-- évite le doublon quand l'instantané contient déjà le prop (déplacé ou non). Marqueur posé
-- SUR la table (clé texte : ignorée par ipairs / # / EncodeList). Même ordre client et serveur.
local function mergeWorldDefaults(map, list)
	if list._defaultsMerged then return end
	list._defaultsMerged = true
	local defs = EVO_ConfigPos.WorldModelDefaults and EVO_ConfigPos.WorldModelDefaults[map]
	if not istable(defs) then return end
	local have = {}
	for _, d in ipairs(list) do
		if isstring(d.key) then have[d.key] = true end
	end
	for _, def in ipairs(defs) do
		if isstring(def.key) and not have[def.key] and isstring(def.model) and isvector(def.pos) then
			have[def.key] = true
			list[#list + 1] = {
				key = def.key,
				model = def.model,
				pos = Vector(def.pos.x, def.pos.y, def.pos.z),
				ang = isangle(def.ang) and Angle(def.ang.p, def.ang.y, def.ang.r) or Angle(0, 0, 0),
				scale = EVO_ConfigPos.ClampScale(def.scale),
			}
		end
	end
end

local function worldList(map)
	EVO_ConfigPos.WorldModels[map] = EVO_ConfigPos.WorldModels[map] or {}
	local list = EVO_ConfigPos.WorldModels[map]
	mergeWorldDefaults(map, list)
	return list
end

local function applyWorldModelScale(ent, scale)
	if not IsValid(ent) then return end
	local s = EVO_ConfigPos.ClampScale(scale)
	ent:SetModelScale(s, 0)
	local mins, maxs = ent:GetModelBounds()
	if mins and maxs then
		ent:SetCollisionBounds(mins * s, maxs * s)
	end
	local phys = ent:GetPhysicsObject()
	if IsValid(phys) then
		phys:EnableMotion(false)
		phys:Sleep()
	end
end

-- Lit médecin (hospital_bed) : le prop seul est décoratif ; le soin passe par un
-- spot evo_repos ([E] S'allonger → emote soignable). On le crée / déplace / retire
-- avec le prop. Yaw = EVO_REPOS.LieYawForBed (même règle que le Lie live).
local HEAL_BED_MDL = "models/props_unique/hospital/hospital_bed.mdl"

local function isHealBedModel(mdl)
	return isstring(mdl) and string.lower(mdl) == HEAL_BED_MDL
end

local function healBedSpotPose(pos, ang, scale, ent)
	local s = EVO_ConfigPos.ClampScale(scale)
	local localOff = Vector(0, 0, 32)
	local a = ang or Angle(0, 0, 0)
	if IsValid(ent) then
		local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
		if mins and maxs then
			localOff = Vector(
				(mins.x + maxs.x) * 0.5,
				(mins.y + maxs.y) * 0.5,
				mins.z + (maxs.z - mins.z) * 0.65
			)
		end
	end
	localOff:Mul(s)
	local yaw = a.y
	if EVO_REPOS and EVO_REPOS.LieYawForBed and IsValid(ent) then
		yaw = EVO_REPOS.LieYawForBed(ent) or yaw
	elseif EVO_REPOS and tonumber(EVO_REPOS.HealBedLocalYaw) then
		yaw = (a + Angle(0, EVO_REPOS.HealBedLocalYaw, 0)).y
	end
	return LocalToWorld(localOff, Angle(0, 0, 0), pos, a), math.NormalizeAngle(yaw)
end

local function syncHealBedSpot(d, ent)
	if CLIENT or not istable(d) or not isHealBedModel(d.model) then return end
	if not (EVO_REPOS and EVO_REPOS.AddSpot) then return end
	local basePos = (IsValid(ent) and ent:GetPos()) or d.pos
	local baseAng = (IsValid(ent) and ent:GetAngles()) or (d.ang or Angle(0, 0, 0))
	if not isvector(basePos) then return end
	local pos, yaw = healBedSpotPose(basePos, baseAng, d.scale, ent)
	if isstring(d.reposUid) and d.reposUid ~= "" and EVO_REPOS.MoveSpot then
		if EVO_REPOS.MoveSpot(d.reposUid, pos, yaw) then return end
	end
	-- Extra déjà sur le lit (ajout manuel, ou spot créé au boot avant que
	-- reposUid soit sauvé dans l'instantané) : on le réclame, pas de doublon.
	local list = EVO_REPOS.Spots and EVO_REPOS.Spots[game.GetMap()]
	if istable(list) then
		local best, bestD
		for _, s in ipairs(list) do
			if not s.code and isstring(s.uid) and isvector(s.pos) then
				local dist = s.pos:DistToSqr(pos)
				if dist < 40 * 40 and (not bestD or dist < bestD) then
					best, bestD = s, dist
				end
			end
		end
		if best then
			d.reposUid = best.uid
			if EVO_REPOS.MoveSpot then EVO_REPOS.MoveSpot(best.uid, pos, yaw) end
			return
		end
	end
	d.reposUid = EVO_REPOS.AddSpot(pos, yaw, 90, "S'allonger")
end

local function dropHealBedSpot(d)
	if CLIENT or not istable(d) then return end
	if isstring(d.reposUid) and d.reposUid ~= "" and EVO_REPOS and EVO_REPOS.RemoveSpot then
		EVO_REPOS.RemoveSpot(d.reposUid)
	end
	d.reposUid = nil
end

local function spawnWorldModel(id, mdl, pos, ang, scale)
	if CLIENT then return end
	local ent = ents.Create("prop_physics")
	if not IsValid(ent) then return end
	if not util.IsValidModel(mdl) then
		mdl = "models/props_c17/FurnitureTable002a.mdl"
	end
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 8),
		endpos = pos - Vector(0, 0, 20000),
		mask = MASK_SOLID_BRUSHONLY,
	})
	ent:SetModel(mdl)
	ent:SetPos(tr.Hit and (tr.HitPos + Vector(0, 0, 2)) or pos)
	ent:SetAngles(ang or Angle(0, 0, 0))
	ent:Spawn()
	ent:Activate()
	ent._evoWorldModel = id
	-- Collision joueur : prop_dynamic + SOLID_VPHYSICS ne bloque pas ; physobj figé.
	ent:SetSolid(SOLID_VPHYSICS)
	ent:SetCollisionGroup(COLLISION_GROUP_NONE)
	local phys = ent:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
		phys:EnableMotion(false)
		phys:Sleep()
	else
		ent:PhysicsInit(SOLID_VPHYSICS)
		ent:SetMoveType(MOVETYPE_VPHYSICS)
		ent:SetSolid(SOLID_VPHYSICS)
		phys = ent:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
			phys:Sleep()
		else
			ent:SetMoveType(MOVETYPE_NONE)
			ent:PhysicsInitStatic(SOLID_VPHYSICS)
		end
	end
	applyWorldModelScale(ent, scale)
	return ent
end

local function moveWorldModel(id, pos, ang, scale)
	for _, e in ipairs(ents.GetAll()) do
		if IsValid(e) and e._evoWorldModel == id then
			if EVO_ConfigPos.TeleportFrozen then
				EVO_ConfigPos.TeleportFrozen(e, pos, ang)
			else
				e:SetPos(pos)
				if ang then e:SetAngles(ang) end
			end
			if scale ~= nil then applyWorldModelScale(e, scale) end
			return e
		end
	end
end

EVO_ConfigPos.RegisterProvider({
	id = "world_models",
	cat = "modeles",
	label = "Props",
	array = true,
	List = function(map)
		local out = {}
		for i, d in ipairs(worldList(map)) do
			if istable(d) and isvector(d.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = (d.model and string.GetFileFromFilename(d.model) or "prop") .. " [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = d.pos,
					ang = d.ang or Angle(0, 0, 0),
					scale = EVO_ConfigPos.ClampScale(d.scale),
					entClass = d.model,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = worldList(map)
		local n = tonumber(id)
		if not (n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then list[n].ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
		if data.scale ~= nil then list[n].scale = EVO_ConfigPos.ClampScale(data.scale) end
	end,
	EncodeList = function(map)
		local out = {}
		for _, d in ipairs(worldList(map)) do
			if istable(d) and isvector(d.pos) then
				out[#out + 1] = {
					model = d.model,
					pos = encodeV(d.pos),
					ang = encodeA(d.ang),
					scale = EVO_ConfigPos.ClampScale(d.scale),
					key = d.key, -- prop du code : sa clé suit l'instantané
					reposUid = isstring(d.reposUid) and d.reposUid ~= "" and d.reposUid or nil,
				}
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		local nextList = {}
		for _, d in ipairs(rows or {}) do
			nextList[#nextList + 1] = {
				model = d.model,
				pos = decodeV(d.pos),
				ang = decodeA(d.ang),
				scale = EVO_ConfigPos.ClampScale(d.scale),
				key = isstring(d.key) and d.key or nil,
				reposUid = isstring(d.reposUid) and d.reposUid ~= "" and d.reposUid or nil,
			}
		end
		EVO_ConfigPos.WorldModels[map] = nextList
	end,
	Add = function(map, origin)
		local list = worldList(map)
		local mdl = origin.model
		if not (isstring(mdl) and mdl ~= "") then
			local pre = EVO_ConfigPos.WorldModelPresets and EVO_ConfigPos.WorldModelPresets[1]
			mdl = (pre and pre.model) or "models/props_c17/FurnitureTable002a.mdl"
		end
		list[#list + 1] = {
			model = mdl,
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
			scale = 1,
		}
		local id = tostring(#list)
		local ent = spawnWorldModel(id, mdl, list[#list].pos, list[#list].ang, 1)
		syncHealBedSpot(list[#list], ent)
		return id
	end,
	Remove = function(map, id)
		local list = worldList(map)
		local n = tonumber(id)
		if not (n and list[n]) then return false end
		dropHealBedSpot(list[n])
		if SERVER then
			for _, e in ipairs(ents.GetAll()) do
				if IsValid(e) and e._evoWorldModel == id then
					e:Remove()
				elseif IsValid(e) and tonumber(e._evoWorldModel) and tonumber(e._evoWorldModel) > n then
					e._evoWorldModel = tostring(tonumber(e._evoWorldModel) - 1)
				end
			end
		end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		map = map or game.GetMap()
		if CLIENT then
			local n = tonumber(id)
			local d = n and worldList(map)[n]
			if d then moveWorldModel(id, d.pos, d.ang, d.scale) end
			return
		end
		if id then
			local n = tonumber(id)
			local d = n and worldList(map)[n]
			if not d then return end
			local ent = moveWorldModel(id, d.pos, d.ang, d.scale)
			if not ent then
				ent = spawnWorldModel(id, d.model, d.pos, d.ang, d.scale)
			end
			syncHealBedSpot(d, ent)
			return
		end
		for _, e in ipairs(ents.GetAll()) do
			if IsValid(e) and e._evoWorldModel then e:Remove() end
		end
		for i, d in ipairs(worldList(map)) do
			local ent = spawnWorldModel(tostring(i), d.model, d.pos, d.ang, d.scale)
			syncHealBedSpot(d, ent)
		end
	end,
})

-- ── Points « [E] S'allonger » (evo_repos, 09/20) ────────────────────────────
-- Ajout / déplacement / suppression au gizmo des EXTRAS d'evo_repos (mêmes points que le
-- panneau evo_repos_menu). ⚠ evo_repos reste la SEULE source de vérité : ni EncodeList ni
-- RestoreList, donc aucun instantané d'ici ne peut masquer les spots du code ou ceux du
-- panneau (le piège des libellés de world boss). Les spots du CODE ne sont PAS listés : ils
-- s'éditent dans sh_evo_repos.lua. Identifiant = uid STABLE de l'extra, jamais un index.
-- Un déplacement laisse un override chez nous : rejoué au boot il repose la MÊME pose
-- (evo_repos l'a déjà enregistrée), et il est sans effet si le point a été supprimé.
EVO_ConfigPos.RegisterProvider({
	id = "repos_spots",
	cat = "modeles",
	label = "S'allonger [E]",
	array = true,
	List = function(map)
		local out = {}
		local list = EVO_REPOS and EVO_REPOS.Spots and EVO_REPOS.Spots[map]
		if not istable(list) then return out end
		local n = 0
		for _, sp in ipairs(list) do
			if not sp.code and isstring(sp.uid) and isvector(sp.pos) then
				n = n + 1
				out[#out + 1] = {
					id = sp.uid,
					label = "S'allonger [" .. n .. "]",
					kind = KIND.POINT_ANG,
					pos = sp.pos,
					ang = Angle(0, tonumber(sp.yaw) or 0, 0),
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		if not (EVO_REPOS and isvector(data.pos)) then return end
		local nYaw = isangle(data.ang) and data.ang.y or nil
		if SERVER then
			if map == game.GetMap() and EVO_REPOS.MoveSpot then EVO_REPOS.MoveSpot(id, data.pos, nYaw) end
			return
		end
		-- Client : aperçu immédiat sous le gizmo ; la vraie liste revient par le sync d'evo_repos.
		for _, sp in ipairs((EVO_REPOS.Spots and EVO_REPOS.Spots[map]) or {}) do
			if not sp.code and sp.uid == id then
				sp.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
				if nYaw then sp.yaw = nYaw end
				break
			end
		end
	end,
	Add = function(map, origin)
		if not (SERVER and EVO_REPOS and EVO_REPOS.AddSpot) then return nil, "no_repos" end
		if map ~= game.GetMap() then return nil, "map" end
		return EVO_REPOS.AddSpot(origin.pos, math.Round(origin.ang.y, 3), 90, "S'allonger")
	end,
	Remove = function(map, id)
		if not (SERVER and EVO_REPOS and EVO_REPOS.RemoveSpot) then return false end
		return EVO_REPOS.RemoveSpot(id)
	end,
})

-- ── Events : boss, dômes 1-max, carte HUD bastion ───────────────────────────

local DOME_ADD_RADIUS = 1500
local DOME_ADD_HEIGHT = 1500

local function arenaToBox(a)
	local c = a.center
	local r = tonumber(a.radius) or 800
	local h = tonumber(a.height) or r
	if r < 64 then r = 64 end
	if h < 64 then h = 64 end
	return Vector(c.x - r, c.y - r, c.z), Vector(c.x + r, c.y + r, c.z + h)
end

local function boxToArena(mins, maxs)
	local r = math.max(math.abs(maxs.x - mins.x), math.abs(maxs.y - mins.y)) * 0.5
	if r < 64 then r = 64 end
	local h = math.abs(maxs.z - mins.z)
	if h < 64 then h = 64 end
	local z = math.min(mins.z, maxs.z)
	return Vector((mins.x + maxs.x) * 0.5, (mins.y + maxs.y) * 0.5, z), r, h
end

local function soloArena(cfg)
	if not istable(cfg) then return nil, nil end
	local arenas = cfg.Arenas or {}
	for mapName, on in pairs(cfg.HostMaps or {}) do
		if on and istable(arenas[mapName]) and isvector(arenas[mapName].center) then
			return mapName, arenas[mapName]
		end
	end
	for mapName, a in pairs(arenas) do
		if istable(a) and isvector(a.center) then
			return mapName, a
		end
	end
end

local function registerSoloDome(opts)
	EVO_ConfigPos.RegisterProvider({
		id = opts.id,
		cat = "events",
		label = opts.label,
		array = true,
		global = true,
		maxCount = 1,
		List = function(map)
			if not opts.getCfg then return {} end
			local host, arena = soloArena(opts.getCfg())
			if not (host == map and istable(arena) and isvector(arena.center)) then return {} end
			local mins, maxs = arenaToBox(arena)
			return {
				{
					id = "1",
					label = arena.name or opts.label,
					kind = KIND.BOX,
					mins = mins,
					maxs = maxs,
				},
			}
		end,
		Apply = function(map, _, data)
			if not (opts.setSolo and isvector(data.mins) and isvector(data.maxs)) then return end
			local c, r, h = boxToArena(data.mins, data.maxs)
			local host, arena = soloArena(opts.getCfg and opts.getCfg())
			local dest = host or map
			local name = (arena and arena.name) or opts.defaultName
			opts.setSolo(dest, c, r, h, name)
		end,
		EncodeList = function()
			if not opts.getCfg then return {} end
			local host, arena = soloArena(opts.getCfg())
			if not (host and istable(arena) and isvector(arena.center)) then return {} end
			return {
				{
					map = host,
					name = arena.name or opts.defaultName,
					center = encodeV(arena.center),
					radius = tonumber(arena.radius) or 800,
					height = tonumber(arena.height) or tonumber(arena.radius) or 800,
				},
			}
		end,
		RestoreList = function(_, rows)
			local row = rows and rows[1]
			if not (istable(row) and isstring(row.map) and row.map ~= "") then
				if opts.clearSolo then opts.clearSolo() end
				return
			end
			if not opts.setSolo then return end
			opts.setSolo(row.map, decodeV(row.center), row.radius, row.height, row.name or opts.defaultName)
		end,
		Add = function(map, origin)
			if not opts.setSolo then return nil, "no_addon" end
			local host, arena
			if opts.getCfg then
				host, arena = soloArena(opts.getCfg())
			end
			if host == map then return nil, "one_max" end
			local p = origin.pos
			opts.setSolo(map, Vector(p.x, p.y, p.z), DOME_ADD_RADIUS, DOME_ADD_HEIGHT, (arena and arena.name) or opts.defaultName)
			return "1"
		end,
		Remove = function()
			if not opts.clearSolo then return false end
			opts.clearSolo()
			return true
		end,
	})
end

local function bossSpots(map)
	if not NCM_WORLD_BOSS then return nil end
	NCM_WORLD_BOSS.POSITIONS = NCM_WORLD_BOSS.POSITIONS or {}
	NCM_WORLD_BOSS.POSITIONS[map] = NCM_WORLD_BOSS.POSITIONS[map] or {}
	return NCM_WORLD_BOSS.POSITIONS[map]
end

EVO_ConfigPos.RegisterProvider({
	id = "boss_spawns",
	cat = "events",
	label = "Boss",
	array = true,
	List = function(map)
		local out = {}
		local list = NCM_WORLD_BOSS and NCM_WORLD_BOSS.POSITIONS and NCM_WORLD_BOSS.POSITIONS[map]
		if not istable(list) then return out end
		for i, s in ipairs(list) do
			if istable(s) and isvector(s.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = (s.label or "Boss") .. " [" .. i .. "]",
					kind = KIND.POINT,
					pos = s.pos,
					name = s.label or "Boss",
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = NCM_WORLD_BOSS and NCM_WORLD_BOSS.POSITIONS and NCM_WORLD_BOSS.POSITIONS[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		local old = list[n].pos
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if isstring(data.name) then
			local name = string.Trim(data.name)
			if name ~= "" then list[n].label = string.sub(name, 1, 64) end
		end
		if SERVER and NCM_WORLD_BOSS.RelocateLive then
			NCM_WORLD_BOSS.RelocateLive(old, list[n].pos, list[n].label)
		end
	end,
	EncodeList = function(map)
		local list = NCM_WORLD_BOSS and NCM_WORLD_BOSS.POSITIONS and NCM_WORLD_BOSS.POSITIONS[map]
		if not istable(list) then return {} end
		local out = {}
		for _, s in ipairs(list) do
			if istable(s) and isvector(s.pos) then
				out[#out + 1] = { pos = encodeV(s.pos), label = s.label or "Boss" }
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not NCM_WORLD_BOSS then return end
		NCM_WORLD_BOSS.POSITIONS = NCM_WORLD_BOSS.POSITIONS or {}
		local nextList = {}
		for _, s in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(s.pos), label = s.label or "Boss" }
		end
		NCM_WORLD_BOSS.POSITIONS[map] = nextList
		-- Anciens noms du Hueco persistés : recalés sur le bon étage (09/19).
		if NCM_WORLD_BOSS.FixLegacyLabels then NCM_WORLD_BOSS.FixLegacyLabels(map) end
	end,
	Add = function(map, origin)
		if not NCM_WORLD_BOSS then return nil, "no_boss" end
		local list = bossSpots(map)
		local name = "Boss"
		if isstring(origin.model) then
			local trimmed = string.Trim(origin.model)
			if trimmed ~= "" then name = string.sub(trimmed, 1, 64) end
		end
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			label = name,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = NCM_WORLD_BOSS and NCM_WORLD_BOSS.POSITIONS and NCM_WORLD_BOSS.POSITIONS[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		if SERVER and NCM_WORLD_BOSS.DespawnLiveAt then
			NCM_WORLD_BOSS.DespawnLiveAt(list[n].pos)
		end
		table.remove(list, n)
		return true
	end,
})

local function flagRegion(map)
	if FlagCapture and FlagCapture.RegionForMap then
		return FlagCapture.RegionForMap(map)
	end
	local cfg = FlagCapture and FlagCapture.Config
	return (cfg and cfg.RegionByMap and cfg.RegionByMap[map]) or (cfg and cfg.DefaultRegion) or "seireitei"
end

local function flagZones()
	return FlagCapture and FlagCapture.Config and FlagCapture.Config.FlagZones
end

EVO_ConfigPos.RegisterProvider({
	id = "flag_zones",
	cat = "events",
	label = "Drapeaux",
	array = true,
	List = function(map)
		local out = {}
		local list = flagZones()
		if not istable(list) then return out end
		local region = flagRegion(map)
		for i, z in ipairs(list) do
			if istable(z) and isvector(z.pos) and (z.region or "seireitei") == region then
				out[#out + 1] = {
					id = tostring(i),
					label = (z.name or "Drapeau") .. " [" .. i .. "]",
					kind = KIND.POINT,
					pos = z.pos,
					name = z.name or "Drapeau",
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = flagZones()
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		if (list[n].region or "seireitei") ~= flagRegion(map) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if isstring(data.name) then
			local name = string.Trim(data.name)
			if name ~= "" then list[n].name = string.sub(name, 1, 64) end
		end
	end,
	EncodeList = function(map)
		local list = flagZones()
		if not istable(list) then return {} end
		local region = flagRegion(map)
		local out = {}
		for _, z in ipairs(list) do
			if istable(z) and isvector(z.pos) and (z.region or "seireitei") == region then
				out[#out + 1] = {
					name = z.name,
					pos = encodeV(z.pos),
					radius = tonumber(z.radius) or 400,
					danger = tonumber(z.danger) or 1,
					region = region,
					borderZOffset = tonumber(z.borderZOffset),
				}
			end
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not FlagCapture then return end
		FlagCapture.Config.FlagZones = FlagCapture.Config.FlagZones or {}
		local region = flagRegion(map)
		local others = {}
		for _, z in ipairs(FlagCapture.Config.FlagZones) do
			if istable(z) and (z.region or "seireitei") ~= region then
				others[#others + 1] = z
			end
		end
		local mine = {}
		for _, z in ipairs(rows or {}) do
			mine[#mine + 1] = {
				name = z.name or "Drapeau",
				pos = decodeV(z.pos),
				radius = tonumber(z.radius) or 400,
				danger = tonumber(z.danger) or 1,
				region = region,
				borderZOffset = tonumber(z.borderZOffset),
			}
		end
		-- Seireitei d'abord (comme le lua d'origine), Hueco ensuite.
		FlagCapture.Config.FlagZones = {}
		if region == "seireitei" then
			for _, z in ipairs(mine) do FlagCapture.Config.FlagZones[#FlagCapture.Config.FlagZones + 1] = z end
			for _, z in ipairs(others) do FlagCapture.Config.FlagZones[#FlagCapture.Config.FlagZones + 1] = z end
		else
			for _, z in ipairs(others) do FlagCapture.Config.FlagZones[#FlagCapture.Config.FlagZones + 1] = z end
			for _, z in ipairs(mine) do FlagCapture.Config.FlagZones[#FlagCapture.Config.FlagZones + 1] = z end
		end
	end,
	Add = function(map, origin)
		if not FlagCapture then return nil, "no_flags" end
		FlagCapture.Config.FlagZones = FlagCapture.Config.FlagZones or {}
		local list = FlagCapture.Config.FlagZones
		local region = flagRegion(map)
		local name = "Drapeau"
		if isstring(origin.model) then
			local trimmed = string.Trim(origin.model)
			if trimmed ~= "" then name = string.sub(trimmed, 1, 64) end
		end
		list[#list + 1] = {
			name = name,
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			radius = 400,
			danger = 1,
			region = region,
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = flagZones()
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		if (list[n].region or "seireitei") ~= flagRegion(map) then return false end
		table.remove(list, n)
		return true
	end,
	Refresh = function(map, id)
		if CLIENT or not FlagCapture then return end
		local n = tonumber(id)
		if n and FlagCapture.MoveLiveZone then
			FlagCapture.MoveLiveZone(n)
			return
		end
		if FlagCapture.SyncLiveZones then FlagCapture.SyncLiveZones() end
	end,
})

registerSoloDome({
	id = "bataille_dome",
	label = "Dome bataille",
	defaultName = "Bataille des Clans",
	getCfg = function()
		return EVO_BATAILLE and EVO_BATAILLE.Config
	end,
	setSolo = function(map, center, radius, height, name)
		if EVO_BATAILLE and EVO_BATAILLE.SetSoloArena then
			EVO_BATAILLE.SetSoloArena(map, center, radius, height, name)
		end
	end,
	clearSolo = function()
		if EVO_BATAILLE and EVO_BATAILLE.ClearSoloArena then
			EVO_BATAILLE.ClearSoloArena()
		end
	end,
})

registerSoloDome({
	id = "capture_dome",
	label = "Dome capture",
	defaultName = "Capture de zone",
	getCfg = function()
		return ZoneCapture and ZoneCapture.Config
	end,
	setSolo = function(map, center, radius, height, name)
		if ZoneCapture and ZoneCapture.SetSoloArena then
			ZoneCapture.SetSoloArena(map, center, radius, height, name)
		end
	end,
	clearSolo = function()
		if ZoneCapture and ZoneCapture.ClearSoloArena then
			ZoneCapture.ClearSoloArena()
		end
	end,
})

local function bastionList(map, bCreate)
	if not EVO_BASTION then return nil end
	EVO_BASTION.Config.Bastions = EVO_BASTION.Config.Bastions or {}
	local raw = EVO_BASTION.Config.Bastions[map]
	if istable(raw) and isvector(raw.pos) then
		raw = { raw }
		EVO_BASTION.Config.Bastions[map] = raw
	end
	if not istable(raw) then
		if not bCreate then return nil end
		raw = {}
		EVO_BASTION.Config.Bastions[map] = raw
	end
	return raw
end

local function bastionScale(b)
	local cfg = EVO_BASTION and EVO_BASTION.Config
	return EVO_ConfigPos.ClampScale((b and b.scale) or (cfg and cfg.CardScale) or 0.25)
end

local function encodeBastions(map)
	local list = bastionList(map)
	if not istable(list) then return {} end
	local out = {}
	for _, b in ipairs(list) do
		if istable(b) and isvector(b.pos) then
			out[#out + 1] = {
				faction = b.faction,
				name = b.name,
				pos = encodeV(b.pos),
				scale = bastionScale(b),
			}
		end
	end
	return out
end

local function restoreBastions(map, rows)
	if not EVO_BASTION then return end
	EVO_BASTION.Config.Bastions = EVO_BASTION.Config.Bastions or {}
	local nextList = {}
	for _, b in ipairs(rows or {}) do
		if istable(b) then
			local fac = b.faction
			if fac ~= "Shinigami" and fac ~= "Hollow" then
				fac = (EVO_BASTION.EnemyFactionForMap and EVO_BASTION.EnemyFactionForMap(map)) or "Shinigami"
			end
			nextList[#nextList + 1] = {
				faction = fac,
				name = b.name or ("Bastion " .. fac),
				pos = decodeV(b.pos),
				scale = tonumber(b.scale) and EVO_ConfigPos.ClampScale(b.scale) or nil,
			}
		end
	end
	EVO_BASTION.Config.Bastions[map] = nextList
end

local BASTION_HUD_KINDS = {
	{ id = "bastion_hud_shinigami", faction = "Shinigami", label = "HUD Bastion Shinigami" },
	{ id = "bastion_hud_hollow",    faction = "Hollow",    label = "HUD Bastion Hollow" },
}
local BASTION_HUD_SHARE = { "bastion_hud_shinigami", "bastion_hud_hollow" }

-- Ancien type unique « Carte HUD bastion » (reste en mémoire après lua refresh).
if EVO_ConfigPos.UnregisterProvider then
	EVO_ConfigPos.UnregisterProvider("bastion_hud")
else
	EVO_ConfigPos.Providers["bastion_hud"] = nil
	local order = EVO_ConfigPos._ProviderOrder
	if istable(order) then
		for i = #order, 1, -1 do
			if order[i] == "bastion_hud" then table.remove(order, i) end
		end
	end
end

for _, spec in ipairs(BASTION_HUD_KINDS) do
	local faction = spec.faction
	EVO_ConfigPos.RegisterProvider({
		id = spec.id,
		cat = "events",
		label = spec.label,
		array = true,
		shareList = BASTION_HUD_SHARE,
		List = function(map)
			local out = {}
			local list = bastionList(map)
			if not istable(list) then return out end
			for i, b in ipairs(list) do
				if istable(b) and isvector(b.pos) and b.faction == faction then
					out[#out + 1] = {
						id = tostring(i),
						label = (b.name or spec.label) .. " [" .. i .. "]",
						kind = KIND.POINT,
						pos = b.pos,
						scale = bastionScale(b),
					}
				end
			end
			return out
		end,
		Apply = function(map, id, data)
			local list = bastionList(map)
			local n = tonumber(id)
			if not (list and n and list[n] and isvector(data.pos)) then return end
			list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
			if data.scale ~= nil then list[n].scale = EVO_ConfigPos.ClampScale(data.scale) end
		end,
		EncodeList = encodeBastions,
		RestoreList = restoreBastions,
		Add = function(map, origin)
			local list = bastionList(map, true)
			if not list then return nil, "no_bastion" end
			list[#list + 1] = {
				faction = faction,
				name = "Bastion " .. faction,
				pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			}
			return tostring(#list)
		end,
		Remove = function(map, id)
			local list = bastionList(map)
			local n = tonumber(id)
			if not (list and n and list[n]) then return false end
			table.remove(list, n)
			return true
		end,
	})
end

-- ── Quetes : PNJ donneurs (classiques + progression) ─────────────────────────

local QUEST_GIVER_CLASS = "ncm_npc_questgiver"
local QUETE_GIVER_ORDER = { "instructeur", "chasseur", "messager", "forgeron", "gardien" }
local QUETE_PROG_ORDER = { "prog_beginner", "prog_hollow_mask", "prog_shikai", "prog_bankai", "prog_liberation_spi" }

local function findLiveQuestGiver(sType)
	if not SERVER then return nil end
	if not (isstring(sType) and sType ~= "") then return nil end
	if NCM_QUETE then
		local ent = NCM_QUETE._SpawnedPNJs and NCM_QUETE._SpawnedPNJs[sType]
		if IsValid(ent) then return ent end
		local prog = NCM_QUETE._SpawnedProgressionPNJs
		if istable(prog) then
			for _, e in pairs(prog) do
				if IsValid(e) and e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == sType then
					return e
				end
			end
		end
	end
	for _, e in ipairs(ents.FindByClass(QUEST_GIVER_CLASS)) do
		if IsValid(e) and e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == sType then
			return e
		end
	end
end

local function moveQuestGiverByType(sType, pos, ang)
	if not (isstring(sType) and sType ~= "" and isvector(pos)) then return false end
	local ent = findLiveQuestGiver(sType)
	if not IsValid(ent) then return false end
	if EVO_ConfigPos.TeleportFrozen then
		EVO_ConfigPos.TeleportFrozen(ent, pos, ang)
	else
		ent:SetPos(pos)
		if isangle(ang) then ent:SetAngles(ang) end
	end
	ent._spawnPos = pos
	if isangle(ang) then ent._spawnAng = ang end
	return true
end

local function copyQuestNpcRow(v)
	if not (istable(v) and isvector(v.pos)) then return nil end
	return {
		pos = Vector(v.pos.x, v.pos.y, v.pos.z),
		ang = v.ang and Angle(v.ang.p, v.ang.y, v.ang.r) or Angle(0, 0, 0),
	}
end

local function ensureKeyedMap(getRoot, getLive, map)
	local root = getRoot()
	if not istable(root) then return nil end
	if not istable(root[map]) then
		local copy = {}
		local live = getLive and getLive(map)
		if istable(live) then
			for k, v in pairs(live) do
				local row = copyQuestNpcRow(v)
				if row then copy[k] = row end
			end
		end
		root[map] = copy
	end
	return root[map]
end

local function encodeKeyedQuestNpcs(t, order)
	local out, seen = {}, {}
	if not istable(t) then return out end
	for _, key in ipairs(order) do
		local e = t[key]
		if istable(e) and isvector(e.pos) then
			out[#out + 1] = { id = key, pos = encodeV(e.pos), ang = encodeA(e.ang) }
			seen[key] = true
		end
	end
	for key, e in pairs(t) do
		if not seen[key] and istable(e) and isvector(e.pos) then
			out[#out + 1] = { id = key, pos = encodeV(e.pos), ang = encodeA(e.ang) }
		end
	end
	return out
end

local function restoreKeyedQuestNpcs(getRoot, map, rows)
	local root = getRoot()
	if not istable(root) then return end
	local nextMap = {}
	for _, r in ipairs(rows or {}) do
		if isstring(r.id) and r.id ~= "" then
			nextMap[r.id] = { pos = decodeV(r.pos), ang = decodeA(r.ang) }
		end
	end
	root[map] = nextMap
end

local function registerKeyedQuestNpcPersist(opts)
	EVO_ConfigPos.RegisterProvider({
		id = opts.id,
		cat = "quetes",
		label = opts.label,
		hidden = true,
		array = true,
		List = function() return {} end,
		Apply = function() end,
		EncodeList = function(map)
			local t = opts.getRoot() and opts.getRoot()[map]
			if not t and SERVER and opts.getLive then t = opts.getLive(map) end
			return encodeKeyedQuestNpcs(t, opts.order)
		end,
		RestoreList = function(map, rows)
			restoreKeyedQuestNpcs(opts.getRoot, map, rows)
		end,
	})
end

local function registerOneKeyedQuestNpc(opts, key)
	local pid = opts.id .. "_" .. key
	EVO_ConfigPos.UnregisterProvider(pid)
	EVO_ConfigPos.RegisterProvider({
		id = pid,
		cat = "quetes",
		label = opts.labelOf(key),
		questGiverType = key,
		List = function(map)
			local t = opts.getRoot() and opts.getRoot()[map]
			if not t and SERVER and opts.getLive then t = opts.getLive(map) end
			local e = t and t[key]
			local pos, ang
			if istable(e) and isvector(e.pos) then
				pos, ang = e.pos, e.ang
			end
			local live = findLiveQuestGiver(key)
			if IsValid(live) then
				pos, ang = live:GetPos(), live:GetAngles()
			end
			if not isvector(pos) then return {} end
			return {{
				id = key,
				label = opts.labelOf(key),
				kind = KIND.POINT_ANG,
				pos = pos,
				ang = ang or Angle(0, 0, 0),
			}}
		end,
		Apply = function(map, id, data)
			if not isvector(data.pos) then return end
			id = key
			local t = ensureKeyedMap(opts.getRoot, opts.getLive, map)
			if not t then return end
			t[id] = t[id] or {}
			t[id].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
			if data.ang then t[id].ang = Angle(0, data.ang.y, 0) end
			moveQuestGiverByType(id, t[id].pos, t[id].ang)
		end,
		RestoreExtra = function(map, _, data)
			if not isvector(data.pos) then return end
			local t = ensureKeyedMap(opts.getRoot, opts.getLive, map)
			if not t then return end
			t[key] = {
				pos = Vector(data.pos.x, data.pos.y, data.pos.z),
				ang = data.ang and Angle(0, data.ang.y, 0) or Angle(0, 0, 0),
			}
		end,
		Add = function(map, origin)
			local t = ensureKeyedMap(opts.getRoot, opts.getLive, map)
			if not t then return nil, opts.missingErr end
			t[key] = {
				pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
				ang = Angle(0, origin.ang.y, 0),
			}
			return key
		end,
		Remove = function(map)
			local t = ensureKeyedMap(opts.getRoot, opts.getLive, map)
			if t then t[key] = nil end
			if CLIENT then return true end
			if opts.onRemove then opts.onRemove(key) end
			return true
		end,
		Refresh = function(map)
			if CLIENT then return end
			map = map or game.GetMap()
			local t = opts.getRoot() and opts.getRoot()[map]
			local row = t and t[key]
			if not (row and isvector(row.pos)) then return end
			if not moveQuestGiverByType(key, row.pos, row.ang) and opts.onSpawn then
				opts.onSpawn(key)
			end
		end,
	})
end

local function registerKeyedQuestNpcs(opts)
	EVO_ConfigPos.UnregisterProvider(opts.id)
	registerKeyedQuestNpcPersist(opts)
	for _, key in ipairs(opts.order) do
		registerOneKeyedQuestNpc(opts, key)
	end
end

registerKeyedQuestNpcs({
	id = "quete_givers",
	label = "PNJ donneurs",
	order = QUETE_GIVER_ORDER,
	missingErr = "no_quete",
	getRoot = function()
		if not NCM_QUETE then return nil end
		NCM_QUETE.PNJ_POSITIONS = NCM_QUETE.PNJ_POSITIONS or {}
		return NCM_QUETE.PNJ_POSITIONS
	end,
	getLive = function(map)
		return NCM_QUETE.GetPNJPositionsForMap and NCM_QUETE.GetPNJPositionsForMap(map)
	end,
	labelOf = function(id)
		local cfg = NCM_QUETE and NCM_QUETE.PNJ_TYPES and NCM_QUETE.PNJ_TYPES[id]
		return (cfg and cfg.name) or id
	end,
	onSpawn = function(id)
		if NCM_QUETE.SpawnPNJOfType then NCM_QUETE.SpawnPNJOfType(id) end
	end,
	onRemove = function(id)
		local ent = NCM_QUETE._SpawnedPNJs and NCM_QUETE._SpawnedPNJs[id]
		if IsValid(ent) then ent:Remove() end
		if NCM_QUETE._SpawnedPNJs then NCM_QUETE._SpawnedPNJs[id] = nil end
	end,
})

registerKeyedQuestNpcs({
	id = "quete_prog_givers",
	label = "PNJ progression",
	order = QUETE_PROG_ORDER,
	missingErr = "no_quete",
	getRoot = function()
		if not NCM_QUETE then return nil end
		NCM_QUETE.PROGRESSION_PNJ_POSITIONS = NCM_QUETE.PROGRESSION_PNJ_POSITIONS or {}
		return NCM_QUETE.PROGRESSION_PNJ_POSITIONS
	end,
	getLive = function(map)
		return NCM_QUETE.GetProgressionPNJPositionsForMap and NCM_QUETE.GetProgressionPNJPositionsForMap(map)
	end,
	labelOf = function(id)
		for _, cfg in pairs((NCM_QUETE and NCM_QUETE.PROGRESSION) or {}) do
			if cfg.npc_type == id then return cfg.npc_name or id end
		end
		return id
	end,
	onSpawn = function(id)
		if NCM_QUETE.SpawnProgressionPNJOfType then
			NCM_QUETE.SpawnProgressionPNJOfType(id)
		elseif NCM_QUETE.SpawnProgressionPNJs then
			NCM_QUETE.SpawnProgressionPNJs()
		end
	end,
	onRemove = function(id)
		local spawned = NCM_QUETE._SpawnedProgressionPNJs
		if not istable(spawned) then return end
		for k, e in pairs(spawned) do
			if IsValid(e) and e.GetEvoNWString and e:GetEvoNWString("ncm_pnjType", "") == id then
				e:Remove()
				spawned[k] = nil
				return
			end
		end
	end,
})

-- ── Quetes (marqueurs partagés + une vue par quête) ─────────────────────────

local function markersToItems(markers)
	local out = {}
	for _, m in ipairs(markers or {}) do
		if m and m.id and isvector(m.pos) then
			out[#out + 1] = {
				id = m.id,
				label = m.label or m.id,
				kind = KIND.POINT,
				pos = m.pos,
			}
		end
	end
	return out
end

local QUETE_SOURCES = {
	{ id = "quete_pve_zones",     label = "Zones PVE" },
	{ id = "quete_survival_zones", label = "Zones survie" },
	{ id = "quete_delivery_wp",   label = "Livraison" },
	{ id = "quete_beginner_wp",   label = "Debutant" },
}

for _, spec in ipairs(QUETE_SOURCES) do
	local srcId = spec.id
	EVO_ConfigPos.RegisterProvider({
		id = srcId,
		cat = "quetes",
		label = spec.label,
		hidden = true,
		List = function(map)
			if not (NCM_QUETE and NCM_QUETE.ListSourceMarkers) then return {} end
			return markersToItems(NCM_QUETE.ListSourceMarkers(srcId, map))
		end,
		Apply = function(map, id, data)
			if not (NCM_QUETE and NCM_QUETE.ApplySourceMarker) then return end
			NCM_QUETE.ApplySourceMarker(srcId, map, id, data)
		end,
	})
end

local function registerQuestViewProviders()
	if EVO_ConfigPos._QuestViewsDone then return end
	if not (NCM_QUETE and NCM_QUETE.SortedQuestIds) then return end
	local ids = NCM_QUETE.SortedQuestIds()
	if #ids == 0 then return end
	EVO_ConfigPos._QuestViewsDone = true
	for _, questId in ipairs(ids) do
		local q = NCM_QUETE.Quests[questId]
		local title = (q and isstring(q.title) and q.title) or questId
		EVO_ConfigPos.RegisterProvider({
			id = "quete_" .. questId,
			cat = "quetes",
			label = title,
			persistAs = function(map, id)
				if not NCM_QUETE.CollectQuestMarkers then return end
				for _, m in ipairs(NCM_QUETE.CollectQuestMarkers(questId, map)) do
					if m.id == id then
						return m.persistProvider, m.id
					end
				end
			end,
			List = function(map)
				if not NCM_QUETE.CollectQuestMarkers then return {} end
				return markersToItems(NCM_QUETE.CollectQuestMarkers(questId, map))
			end,
			Apply = function(map, id, data)
				if not NCM_QUETE.ApplyQuestMarker then return end
				NCM_QUETE.ApplyQuestMarker(questId, map, id, data)
			end,
			Refresh = function()
				if NCM_QUETE.ResyncQuestEditorWaypoint then
					NCM_QUETE.ResyncQuestEditorWaypoint(questId)
				end
			end,
		})
	end
end

EVO_ConfigPos.RegisterQuestViewProviders = registerQuestViewProviders
hook.Add("Initialize", "EVO_ConfigPos::QuestViews", registerQuestViewProviders)


-- ── Carte du monde MURALE (evo_map/sh_map_wall) : panneaux 3D2D live ─────────
EVO_ConfigPos.RegisterProvider({
	id = "map_wall",
	cat = "tableaux",
	label = "Carte du monde murale",
	array = true,
	List = function(map)
		local out = {}
		for i, p in ipairs((EVO_MAP_WALL and EVO_MAP_WALL.Panels and EVO_MAP_WALL.Panels[map]) or {}) do
			if istable(p) and isvector(p.pos) then
				out[#out + 1] = {
					id = tostring(i),
					label = "Carte murale [" .. i .. "]",
					kind = KIND.POINT_ANG,
					pos = p.pos,
					ang = p.ang or angle_zero,
					scale = p.scale or 0.35,
				}
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_MAP_WALL and EVO_MAP_WALL.Panels and EVO_MAP_WALL.Panels[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return end
		if isvector(data.pos) then list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z) end
		if isangle(data.ang) then list[n].ang = Angle(data.ang.p, data.ang.y, data.ang.r) end
		if tonumber(data.scale) then list[n].scale = EVO_ConfigPos.ClampScale(data.scale) end
	end,
	EncodeList = function(map)
		local out = {}
		for _, p in ipairs((EVO_MAP_WALL and EVO_MAP_WALL.Panels and EVO_MAP_WALL.Panels[map]) or {}) do
			out[#out + 1] = {
				pos = encodeV(p.pos), ang = encodeA(p.ang or angle_zero),
				scale = p.scale, region = p.region, path = p.path,
			}
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_MAP_WALL then return end
		EVO_MAP_WALL.Panels = EVO_MAP_WALL.Panels or {}
		local nextList = {}
		for _, r in ipairs(rows or {}) do
			nextList[#nextList + 1] = {
				pos = decodeV(r.pos), ang = decodeA(r.ang), scale = r.scale or 0.35,
				-- region/path : ceux du snapshot, repli sur la carte du Seireitei.
				region = r.region or "seireitei",
				path = r.path or "m0q3cwmieqogu5/seireitei_map.png",
			}
		end
		EVO_MAP_WALL.Panels[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_MAP_WALL then return nil, "no_wall" end
		EVO_MAP_WALL.Panels = EVO_MAP_WALL.Panels or {}
		EVO_MAP_WALL.Panels[map] = EVO_MAP_WALL.Panels[map] or {}
		local list = EVO_MAP_WALL.Panels[map]
		local ref = list[1]
		list[#list + 1] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = isangle(origin.ang) and Angle(origin.ang.p, origin.ang.y, origin.ang.r) or Angle(0, 0, 0),
			scale = (ref and ref.scale) or 0.35,
			region = (ref and ref.region) or "seireitei",
			path = (ref and ref.path) or "m0q3cwmieqogu5/seireitei_map.png",
		}
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_MAP_WALL and EVO_MAP_WALL.Panels and EVO_MAP_WALL.Panels[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
})

-- ── Cube corrompu (evo_cube_corrompu) : la Cuve et l'apparition du cube ─────
EVO_ConfigPos.RegisterProvider({
	id = "cube_cuve",
	cat = "events",
	label = "Cuve de l'Objet étrange",
	List = function(map)
		local t = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tCuves and EVO_CUBE.CFG.tCuves[map]
		if not (t and isvector(t.pos)) then return {} end
		return { { id = "cuve", label = "Cuve (E pour ouvrir)", kind = KIND.POINT, pos = t.pos } }
	end,
	Apply = function(map, id, data)
		local t = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tCuves and EVO_CUBE.CFG.tCuves[map]
		if not (t and istable(data) and isvector(data.pos)) then return end
		t.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
	end,
})

EVO_ConfigPos.RegisterProvider({
	id = "cube_ancre",
	cat = "events",
	label = "Apparition du Cube corrompu",
	List = function(map)
		local t = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tAncres and EVO_CUBE.CFG.tAncres[map]
		if not (t and isvector(t.pos)) then return {} end
		return { { id = "cube", label = "Cube (événement)", kind = KIND.POINT_ANG,
			pos = t.pos, ang = Angle(0, t.yaw or 0, 0) } }
	end,
	Apply = function(map, id, data)
		local t = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tAncres and EVO_CUBE.CFG.tAncres[map]
		if not (t and istable(data)) then return end
		if isvector(data.pos) then t.pos = Vector(data.pos.x, data.pos.y, data.pos.z) end
		if isangle(data.ang) then t.yaw = data.ang.y end
	end,
})

-- ── Zone E de la carte murale (séparée du tableau, user 08/28) ──────────────
EVO_ConfigPos.RegisterProvider({
	id = "map_wall_e",
	cat = "tableaux",
	label = "Zone E de la carte murale",
	array = true,
	List = function(map)
		local out = {}
		for i, p in ipairs((EVO_MAP_WALL and EVO_MAP_WALL.ZonesE and EVO_MAP_WALL.ZonesE[map]) or {}) do
			if istable(p) and isvector(p.pos) then
				out[#out + 1] = { id = tostring(i), label = "Zone E [" .. i .. "]", kind = KIND.POINT, pos = p.pos }
			end
		end
		return out
	end,
	Apply = function(map, id, data)
		local list = EVO_MAP_WALL and EVO_MAP_WALL.ZonesE and EVO_MAP_WALL.ZonesE[map]
		local n = tonumber(id)
		if not (list and n and list[n] and isvector(data.pos)) then return end
		list[n].pos = Vector(data.pos.x, data.pos.y, data.pos.z)
	end,
	EncodeList = function(map)
		local out = {}
		for _, p in ipairs((EVO_MAP_WALL and EVO_MAP_WALL.ZonesE and EVO_MAP_WALL.ZonesE[map]) or {}) do
			out[#out + 1] = { pos = encodeV(p.pos) }
		end
		return out
	end,
	RestoreList = function(map, rows)
		if not EVO_MAP_WALL then return end
		EVO_MAP_WALL.ZonesE = EVO_MAP_WALL.ZonesE or {}
		local nextList = {}
		for _, r in ipairs(rows or {}) do
			nextList[#nextList + 1] = { pos = decodeV(r.pos) }
		end
		EVO_MAP_WALL.ZonesE[map] = nextList
	end,
	Add = function(map, origin)
		if not EVO_MAP_WALL then return nil, "no_wall" end
		EVO_MAP_WALL.ZonesE = EVO_MAP_WALL.ZonesE or {}
		EVO_MAP_WALL.ZonesE[map] = EVO_MAP_WALL.ZonesE[map] or {}
		local list = EVO_MAP_WALL.ZonesE[map]
		list[#list + 1] = { pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z) }
		return tostring(#list)
	end,
	Remove = function(map, id)
		local list = EVO_MAP_WALL and EVO_MAP_WALL.ZonesE and EVO_MAP_WALL.ZonesE[map]
		local n = tonumber(id)
		if not (list and n and list[n]) then return false end
		table.remove(list, n)
		return true
	end,
})

-- ── Point de vue de la cinematique de l'etoile (evo_cube_corrompu) ──────────
-- Doit rester un endroit DEGAGE a ciel ouvert : c'est de la que TOUT LE MONDE
-- regarde l'etoile tomber, y compris les joueurs enfermes en interieur.
EVO_ConfigPos.RegisterProvider({
	id = "cube_cam_etoile",
	cat = "events",
	label = "Vue cinematique de l'etoile",
	List = function(map)
		local t = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tCamEtoile and EVO_CUBE.CFG.tCamEtoile[map]
		if not isvector(t) then return {} end
		return { { id = "cam", label = "Vue de l'etoile", kind = KIND.POINT, pos = t } }
	end,
	Apply = function(map, id, data)
		local tbl = EVO_CUBE and EVO_CUBE.CFG and EVO_CUBE.CFG.tCamEtoile
		if not (tbl and tbl[map] and istable(data) and isvector(data.pos)) then return end
		tbl[map] = Vector(data.pos.x, data.pos.y, data.pos.z)
	end,
})

-- ── Cloche d'annonce (evo_cloche) ───────────────────────────────────────────
-- Singleton par map : une seule cloche, deplacable au gizmo. Le YAW seul est
-- conserve (une cloche couchee n'a pas de sens), comme les tableaux de map.
EVO_ConfigPos.RegisterProvider({
	id = "cloche_annonce",
	cat = "modeles",
	label = "Cloche d'annonce",
	List = function(map)
		local t = EVO_CLOCHE and EVO_CLOCHE.Spawns and EVO_CLOCHE.Spawns[map]
		if not (istable(t) and isvector(t.pos)) then return {} end
		local out = {{
			id = "cloche",
			label = "Cloche d'annonce",
			kind = KIND.POINT_ANG,
			pos = t.pos,
			ang = Angle(0, (t.ang and t.ang.y) or 0, 0),
			entClass = EVO_CLOCHE and EVO_CLOCHE.Model or nil,
		}}
		-- Point du « E » : entrée SÉPARÉE (user 08/31). Affiché même quand il n'est
		-- pas encore configuré (il vaut alors la position de la cloche) : sinon on ne
		-- pourrait jamais le saisir au gizmo pour l'en détacher.
		local vUse = EVO_CLOCHE.UsePointFor and EVO_CLOCHE.UsePointFor(map)
		if isvector(vUse) then
			out[#out + 1] = { id = "use", label = "Cloche : point du E", kind = KIND.POINT, pos = vUse }
		end
		return out
	end,
	Apply = function(map, id, data)
		if not (EVO_CLOCHE and isvector(data.pos)) then return end
		if id == "use" then
			EVO_CLOCHE.UsePoints = EVO_CLOCHE.UsePoints or {}
			EVO_CLOCHE.UsePoints[map] = Vector(data.pos.x, data.pos.y, data.pos.z)
			return
		end
		local t = EVO_CLOCHE.Spawns and EVO_CLOCHE.Spawns[map]
		if not istable(t) then return end
		t.pos = Vector(data.pos.x, data.pos.y, data.pos.z)
		if data.ang then t.ang = Angle(0, data.ang.y, 0) end
	end,
	RestoreExtra = function(map, id, data)
		if not (EVO_CLOCHE and isvector(data.pos)) then return end
		if id == "use" then
			EVO_CLOCHE.UsePoints = EVO_CLOCHE.UsePoints or {}
			EVO_CLOCHE.UsePoints[map] = Vector(data.pos.x, data.pos.y, data.pos.z)
			return
		end
		EVO_CLOCHE.Spawns = EVO_CLOCHE.Spawns or {}
		local a = data.ang
		EVO_CLOCHE.Spawns[map] = {
			pos = Vector(data.pos.x, data.pos.y, data.pos.z),
			ang = Angle(0, (a and a.y) or 0, 0),
		}
	end,
	Add = function(map, origin)
		if not EVO_CLOCHE then return nil, "no_cloche" end
		EVO_CLOCHE.Spawns = EVO_CLOCHE.Spawns or {}
		if EVO_CLOCHE.Spawns[map] then return nil, "exists" end
		EVO_CLOCHE.Spawns[map] = {
			pos = Vector(origin.pos.x, origin.pos.y, origin.pos.z),
			ang = Angle(0, origin.ang.y, 0),
		}
		return "cloche"
	end,
	Remove = function(map, id)
		if not (EVO_CLOCHE and EVO_CLOCHE.Spawns) then return false end
		if id == "use" then -- retire l'écart : le E revient sur la cloche
			if EVO_CLOCHE.UsePoints then EVO_CLOCHE.UsePoints[map] = nil end
			return true
		end
		EVO_CLOCHE.Spawns[map] = nil
		if EVO_CLOCHE.UsePoints then EVO_CLOCHE.UsePoints[map] = nil end
		if CLIENT then return true end
		for _, e in ipairs(ents.FindByClass("evo_cloche_prop")) do
			if IsValid(e) then e:Remove() end
		end
		return true
	end,
	Refresh = function()
		if CLIENT then return end
		if EVO_CLOCHE and EVO_CLOCHE.Respawn then EVO_CLOCHE.Respawn() end
	end,
})
