-- "addons\\lzy_bindmenu\\lua\\autorun\\lzy_bindmenu_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile("lzy_bindmenu/config.lua")
	AddCSLuaFile("lzy_bindmenu/cl_main.lua")
	AddCSLuaFile("lzy_bindmenu/vgui/main.lua")

	include("lzy_bindmenu/config.lua")
	include("lzy_bindmenu/sv_main.lua")
end

if CLIENT then
	include("lzy_bindmenu/config.lua")
	include("lzy_bindmenu/cl_main.lua")
	include("lzy_bindmenu/vgui/main.lua")
end