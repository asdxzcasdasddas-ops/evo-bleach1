-- "addons\\lzy_bindmenu\\lua\\lzy_bindmenu\\config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
LZY_DEFAULT_BINDS = {
	systemBinds = {
		["skilltree"] = {
			name = "Ouvrir le Skilltree",
			bind = "KEY_P",
			order = 1,
		},
		["spellselector"] = {
			name = "Ouvrir le Selecteur de Spell",
			bind = "KEY_K",
			order = 2,
		},
		["inventory"] = {
			name = "Ouvrir l'inventaire",
			bind = "KEY_I",
			order = 3,
		},
		["battlepass"] = {
			name = "Ouvrir le Battlepass",
			bind = "KEY_F2",
			order = 4,
		},
		["voicerange"] = {
			name = "Portee de voix",
			bind = "KEY_J",
			order = 5,
		},
		["animation_menu"] = {
			name = "Ouvrir le menu des animations",
			bind = "KEY_L",
			order = 6,
		},
		["switch_camera"] = {
			name = "Changer de caméra",
			bind = "KEY_F1",
			order = 7,
		},
		["ost_menu"] = {
			name = "Ouvrir le menu de l'OST",
			bind = "KEY_COMMA",   -- "," (demande user) : libere F4 pour le Vol de Combat. NB : "," est aussi le bind senkaimon (Shinigami grade 10+) -> chevauchement pour ce sous-ensemble uniquement
			order = 8,
		},
		-- "fly" (Voler) : déplacé dans combatBinds (catégorie Techniques & Combat) le 2026-07-16
		-- (demande user). Touche sauvegardée migrée par MergeNewBinds (cl_main.lua).
		["cinematic"] = {
			name = "Mode Cinematique",
			bind = "KEY_F7",
			order = 9,
		},
		["private_message"] = {
			name = "Message Prive",
			bind = "KEY_F5",   -- F5 (libere par le deplacement d'animateur_ui) ; libere F3
			order = 10,
		},
		-- "flagmap" (Gestion Drapeau, F6) RETIRÉ du menu de binds (demande user :
		-- inutile). L'UI reste ouvrable via ncm_flagmap / le bouton de menu ; les
		-- lecteurs (flagcapture cl_flagmap) tolèrent l'absence du bind (nil-check),
		-- et MergeNewBinds purge automatiquement l'entrée des fichiers sauvegardés.
		["famille"] = {
			-- ⚠️ id "famille" CONSERVÉ (binds sauvegardés des joueurs) mais ouvre
			-- désormais le menu CLAN d'evo_clan (evo_famille désactivé 07/13).
			name = "Mon Clan",
			bind = "KEY_F10",               -- F10 : deconflit du F6 (partageait F6 avec instructeur_ui + hardcodes char-select/skilltree)
			order = 11,
			familyOnly = true,              -- visible UNIQUEMENT si membre d'un clan (EVO_ClanKey non vide) ; sans clan = pas de bind, cf. filtre vgui/main.lua (07/14)
		},
		["business"] = {
			name = "Mon commerce",
			bind = "KEY_F3",
			order = 11.5,
			businessOnly = true,            -- visible UNIQUEMENT si membre d'un commerce (EVO_BusinessId)
		},
		["admin_panel"] = {
			name = "Actions Rapides (Admin)",
			bind = "KEY_LBRACKET",  -- [ : touche PEU COMMUNE (bind SuperAdmin, rare) -> libere TAB (scoreboard)
			order = 12,
			superadmin = true, -- visible uniquement par les super admins (filtre vgui/main.lua)
		},
		["equilibrage_panel"] = {
			name = "Panneau Équilibrage",
			bind = "KEY_SEMICOLON",  -- ; : touche libre, et le panneau ne concerne qu'une poignée de personnes
			order = 15,
			equilibrage = true, -- visible uniquement pour le rang equilibrage (filtre vgui/main.lua)
		},
		["spell_balance"] = {
			name = "Équilibrage des Sorts",
			bind = "KEY_RBRACKET",  -- ] : touche PEU COMMUNE (bind rare) -> libere F9
			order = 16,
			equilibrage = true, -- super-admin + rang equilibrage (filtre vgui/main.lua)
		},
		["animateur_ui"] = {
			name = "Ouvrir l'UI Animateur",
			-- Touche PEU COMMUNE (apostrophe) : bind STAFF/animateur (rare acces) -> on garde les
			-- touches communes libres pour les joueurs. (F8 est LIBRE depuis le 05/07 : le retour
			-- choix-perso passe par le bouton PERSONNAGE du menu Échap, plus par une touche.)
			bind = "KEY_APOSTROPHE",
			order = 13,
			animstaff = true, -- visible uniquement animateur / admin / superadmin (filtre vgui/main.lua)
		},
		["senkaimon"] = {
			name = "Ouvrir un Senkaimon",
			bind = "KEY_COMMA",  -- , : touche peu commune (Shinigami, rare)
			order = 14,
			requiredUnlock  = "EVO_PortalUnlocked", -- auto au GRADE 3 (revalidé serveur)
			requiredFaction = "Shinigami",          -- visible UNIQUEMENT pour les Shinigami
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18)
		},
		["garganta"] = {
			name = "Ouvrir une Garganta",
			bind = "KEY_PERIOD",  -- . : touche peu commune (Hollow, rare)
			order = 15,
			requiredUnlock  = "EVO_PortalUnlocked", -- auto au GRADE 3 (revalidé serveur)
			requiredFaction = "Hollow",             -- visible UNIQUEMENT pour les Hollow
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18)
		},
		["instructeur_ui"] = {
			name = "Menu Instructeur",
			bind = "KEY_F11",  -- F11 : deconflit du F6 (partageait F6 avec famille)
			order = 16,
			requiredRank = 8, -- grade 8+ (revalidé serveur dans evo_instructeur sur chaque action)
			menuRequiresUnlock = true, -- caché du MENU tant que grade < 8 (demande user 07/18)
		},
		["calendrier"] = {
			name = "Ouvrir le Calendrier",
			bind = "KEY_BACKSLASH",  -- \ : touche PEU COMMUNE (animstaff, rare) ; END n'etait pas dans la display map du menu
			order = 17,
			animstaff = true, -- RÉSERVÉ animateur / admin / superadmin (PAS les joueurs) ; le serveur re-gate
		},
		["shikai_ui"] = {
			name = "Ouvrir le menu Shikai / Resurrección Partielle",
			bind = "KEY_N",  -- N : libre (l'ancien senkaimon N est passe sur "," ; commentaire evo_portals perime)
			order = 18,
			requiredUnlock = "EVO_ShikaiUnlocked", -- visible/utilisable seulement shikai debloque (evo_shikai_ui)
			menuRequiresUnlock = true, -- EXCEPTION : masque AUSSI ce bind dans le menu tant que non débloqué (menu de pouvoir inutile sinon, demande user 07/14)
		},
		["bankai_ui"] = {
			name = "Ouvrir le menu Bankai / Resurrección",
			bind = "KEY_M",  -- M : libre (voisine de N pour le menu du palier superieur)
			order = 19,
			requiredUnlock = "EVO_BankaiUnlocked", -- visible/utilisable seulement bankai debloque (evo_shikai_ui)
			menuRequiresUnlock = true, -- EXCEPTION : masque AUSSI ce bind dans le menu tant que non débloqué (menu de pouvoir inutile sinon, demande user 07/14)
		},
		["carnet_amende"] = {
			name = "Ouvrir le carnet d'amendes",
			bind = "KEY_U",  -- U : libre
			order = 20,
			requiredDivision = 2, -- Division 1 (Shinigami) / Ordre 1 (Hollow) uniquement — même index dans les 2 factions (ncm_police, revalidé serveur)
		},
		["staff_dashboard"] = {
			name = "Dashboard Staff",
			bind = "KEY_F8",  -- F8 : LIBRE ; bind STAFF (modérateurs + admins) — le serveur re-gate tout
			order = 21,
			staffmode = true, -- visible en mode staff actif OU superadmin (filtre vgui/main.lua + IsBindAllowed)
		},
		["science_ui"] = {
			name = "Ouvrir le Laboratoire (Scientifique)",
			bind = "KEY_F6",  -- F6 : LIBRE (flagmap retiré, instructeur passé F11, famille F10)
			order = 22,
			requiredDivision = 4, -- Division 12 (Shinigami) / Ordre 3 (Hollow) — même index (evo_science, revalidé serveur)
		},
		["registre_soin"] = {
			name = "Ouvrir le registre médical",
			bind = "KEY_O",  -- O : libre (lettre commune non-mouvement)
			order = 22,
			requiredDivision = 5, -- Division 4 (Shinigami) / Ordre 4 (Hollow) = division de SOIN — même index dans les 2 factions (ncm_police/ncm_system_soin, revalidé serveur)
		},
		["fosse_menu"] = {
			name = "Ouvrir la Fosse (duels sanctionnés)",
			bind = "KEY_F9",  -- F9 : libre (F3/F9/F12 restants ; F12 = screenshot Steam)
			order = 23,
			requiredDivision = 6, -- Division 11 (Shinigami) / Ordre 5 (Hollow) = division de COMBAT — même index (evo_fosse, revalidé serveur ; menu ouvrable seulement PRÈS de l'arène)
		},
		-- Radio squad (demande user 08/04) : les 2 toggles étaient HARDCODÉS (";" et "M")
		-- dans lzy_squad/cl_hud.lua -> désormais rebindables ici. Défauts = touches
		-- historiques (le chevauchement M/bankai_ui et ;/equilibrage_panel préexistait ;
		-- rebinder résout). Le HUD squad affiche la touche LIVE (cl_hud.lua).
		["squad_mic"] = {
			name = "Radio Squad : Micro",
			bind = "KEY_SEMICOLON",
			order = 24,
		},
		["squad_hear"] = {
			name = "Radio Squad : Haut-parleur",
			bind = "KEY_M",
			order = 25,
		},
		-- (Plus de bind « récompenses boss » : le panneau se réduit en compact tout seul + bouton souris
		--  « −/+ » sur le panneau lui-même — cf. ncm_pnj/cl_healthbar.lua.)
	},
	combatBinds = {
		["ability1"] = {
			name = "Competence 1",
			bind = "KEY_1",
			order = 1,
		},
		["ability2"] = {
			name = "Competence 2",
			bind = "KEY_2",
			order = 2,
		},
		["ability3"] = {
			name = "Competence 3",
			bind = "KEY_3",
			order = 3,
		},
		["ability4"] = {
			name = "Competence 4",
			bind = "KEY_4",
			order = 4,
		},
		["ability5"] = {
			name = "Competence 5",
			bind = "KEY_5",
			order = 5,
		},
		["ability6"] = {
			name = "Competence 6",
			bind = "KEY_6",
			order = 6,
		},
		-- "ability7" RETIRÉ (08/11) : la barre passe à 6 sorts (2 barres de 6, bind
		-- switch_spellbar pour basculer). MergeNewBinds purge l'entrée sauvegardée.
		["switch_spellbar"] = {
			name = "Changer la barre de spell",
			bind = "KEY_7",   -- 7 : liberee par le retrait de Competence 7, dans la continuite des sorts 1-6
			order = 7,
		},
		--[[ Bind "vanish" (mini-dash) DESACTIVE a la demande (decommenter pour reactiver)
		["vanish"] = {
			name = "Dash",
			bind = "KEY_7",
			order = 7,
		},
		]]
		["dash"] = {
			name = "Flashstep",
			bind = "KEY_8",
			order = 8,
			requiredUnlock = "NCM_FlashstepTrainingDone",
			trainingNWBool = "NCM_ShowFlashstepBind",
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18) ; visible PENDANT l'entraînement via trainingNWBool
		},
		["dashstep"] = {
			name = "Esquive (Touche + Direction)",
			bind = "KEY_LALT",
			order = 9,
		},
		--[[ Bind "garde" RETIRE : non branche (aucun handler ne le lit, EnableGardeDefense jamais appele)
		["garde"] = {
			name = "Garde",
			bind = "KEY_0",
			order = 9,
		},
		]]
		["Executer"] = {
			name = "Executer",
			bind = "KEY_9",
			order = 10,
		},
		["heavy_attack"] = {
			name = "Coup Lourd",
			bind = "KEY_Y",        -- Y : libre + NON-mouvement + meme emplacement QWERTY/AZERTY (W=avancer QWERTY, Z=avancer AZERTY, R=reiatsu)
			order = 11,
		},
		["reiatsu_charge"] = {
			name = "Recharge Reiatsu",
			bind = "KEY_R",
			order = 12,
		},
		["aura_vision"] = {
			name = "Aura Vision",
			bind = "KEY_B",
			order = 13,
		},
		["ping"] = {
			name = "Ping",
			bind = "KEY_G",
			order = 14,
		},
		["shikai"] = {
			name = "Activer Shikai",
			bind = "KEY_H",
			order = 15,
			requiredUnlock = "EVO_ShikaiUnlocked",
			powerActivation = true, -- bind d'ACTIVATION (pas le menu) : libellé "Activer le Shikai / la Resurrección Partielle" (cf. ResolveBindName vgui/main.lua) ; distingue du bind shikai_ui qui, lui, OUVRE le menu
			menuRequiresUnlock = true, -- masqué du menu tant que Shikai/Resurrección Partielle non débloqué (demande user 07/14 ; Bankai/Resurrección cascadent depuis cette activation, pas de bind séparé)
		},
		["parade"] = {
			name = "Parade",
			bind = "KEY_F",
			order = 16,
		},
		["hollowmask"] = {
			name = "Masque Hollow",
			bind = "KEY_V",
			order = 17,
			requiredUnlock  = "EVO_HollowMaskUnlocked", -- visible/utilisable seulement si débloqué (quête de progression ou cmd admin)
			requiredFaction = "Shinigami",              -- pour le moment : Shinigami uniquement (Vizard)
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18)
		},
		["liberation_spi"] = {
			name = "Libération Spirituelle",
			bind = "KEY_V",   -- MEME touche que hollowmask (V) : les 2 sont faction-exclusifs (Shinigami=masque, Hollow=liberation) -> la faction decide, jamais de conflit. Libere C.
			order = 18,
			requiredUnlock  = "EVO_LiberationSpiUnlocked", -- visible/utilisable seulement si débloqué (quête « Maître du Néant » + parchemin ou cmd admin)
			requiredFaction = "Hollow",                    -- équivalent Hollow du Masque Hollow (Vizard) ; addon citron_liberation_spi
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18, miroir hollowmask)
		},
		["aerial_combat"] = {
			name = "Vol de Combat (aérien)",
			bind = "KEY_F4",   -- F4 (demande user) : l'OST est passe sur "," pour liberer F4. ACTIVABLE EN L'AIR uniquement (ncm_aerial_combat)
			order = 19,
			requiredUnlock = "NCM_AerialCombatUnlocked", -- caché tant que niveau < 100 (débloqué au niveau 100)
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18)
		},
		["fly"] = {
			name = "Voler (Touche + Avancer)",
			bind = "KEY_T",
			order = 20,   -- déplacé depuis systemBinds/Menu (demande user 2026-07-16) ; à côté du Vol de Combat
			requiredUnlock = "NCM_FlyTrainingDone",
			trainingNWBool = "NCM_ShowFlyBind",
			menuRequiresUnlock = true, -- caché du MENU tant que non débloqué (demande user 07/18) ; visible PENDANT l'entraînement via trainingNWBool
		},
		["quick_item"] = {
			name = "Consommable rapide",
			bind = "KEY_0", -- touche « à/0 » (demande user), dans la continuite des sorts 1-7 ; libre (le KEY_0 de « garde » est commente/retire)
			order = 21, -- utilise le consommable assigne au petit slot de la spell bar (clic droit inventaire > Action rapide)
		},
	},
}

-- ============================================================================
-- TOUCHES RÉSERVÉES au jeu (E = interagir/réanimer, C = menu contextuel, clic
-- gauche = attaque) : aucun bind ne peut les prendre. La liste vivait en local
-- dans le menu, donc elle ne filtrait QUE la boîte de réassignation ; le serveur
-- acceptait la touche par net et gardait les binds déjà enregistrés dessus.
-- ============================================================================
local RESERVED_KEYS = {
	["KEY_C"]      = true,
	["KEY_E"]      = true,
	["MOUSE_LEFT"] = true,
}

function LZY_BindMenu_IsKeyReserved(sKey)
	return sKey ~= nil and RESERVED_KEYS[sKey] == true
end

-- ============================================================================
-- CONDITIONS D'UN BIND — point de vérité PARTAGÉ (client + serveur).
-- Un bind conditionné (division / faction / mode staff) devient MUET partout dès
-- que la condition n'est plus remplie (ex. quitter la division de police -> la
-- touche du carnet ne fait plus RIEN), au lieu d'être seulement masqué dans le
-- menu de binds (demande user 07/17, règle GÉNÉRALE tous cas de figure). Branché
-- dans GetBindKey des DEUX réalms -> tous les addons consommateurs en héritent
-- sans modification. (`requiredUnlock` n'est volontairement PAS gaté ici : ces
-- NWBools servent d'indicateurs d'affichage et les features concernées
-- revalident déjà leur déblocage — couper la touche sur un NW manquant pourrait
-- casser un déplacement de base comme le vol.)
function LZY_BindMenu_IsBindAllowed(ply, bindIndex)
	if not (IsValid(ply) and ply.GetEvoNWInt) then return true end
	local t = LZY_DEFAULT_BINDS
	local def = (t.systemBinds and t.systemBinds[bindIndex]) or (t.combatBinds and t.combatBinds[bindIndex])
	if not def then return true end
	-- Mêmes conditions que le filtre de VISIBILITÉ du menu (vgui/main.lua) — ici
	-- elles coupent aussi L'USAGE de la touche :
	if def.staffmode and not (ply:GetEvoNWBool("EVO_StaffMode", false) or ply:IsSuperAdmin()) then return false end
	if def.requiredDivision and ply:GetEvoNWInt("FactionDivision", 0) ~= def.requiredDivision then return false end
	if def.requiredFaction and ply:GetEvoNWString("FactionName", "") ~= def.requiredFaction then return false end
	if def.familyOnly and ply:GetEvoNWString("EVO_ClanKey", "") == "" then return false end
	if def.businessOnly and ply:GetEvoNWString("EVO_BusinessId", "") == "" then return false end
	if def.superadmin and not ply:IsSuperAdmin() then return false end
	if def.animstaff then
		local ug = ply.GetUserGroup and ply:GetUserGroup() or ""
		if not (ply:IsAdmin() or ug == "admin" or ug == "superadmin" or (EVO_ANIM ~= nil and EVO_ANIM.IsAnimGroupName(ug))) then
			return false
		end
	end
	return true
end
