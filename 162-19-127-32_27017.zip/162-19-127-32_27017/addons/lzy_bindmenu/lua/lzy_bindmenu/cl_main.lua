-- "addons\\lzy_bindmenu\\lua\\lzy_bindmenu\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client-side bind menu system
-- Handles local file storage and server synchronization

local LZY_BIND_FILE = "lzy_bindmenu_binds.txt"
local localBinds = {}

-- Avertissement VISIBLE en jeu (diagnostic : binds qui "ne se sauvegardent pas"
-- entre deux restarts = fichier local illisible ou inscriptible, sinon invisible).
local function WarnBinds(msg)
    timer.Simple(8, function()
        if IsValid(LocalPlayer()) then
            chat.AddText(Color(207, 68, 78), "[Binds] ", Color(235, 235, 240), msg)
        end
    end)
end

-- Load binds from local file
local function LoadLocalBinds()
    if file.Exists(LZY_BIND_FILE, "DATA") then
        local content = file.Read(LZY_BIND_FILE, "DATA")
        if content and content ~= "" then
            local success, data = pcall(util.JSONToTable, content)
            if success and data then
                localBinds = data
                return true
            end
            -- Fichier présent mais illisible : on le sauvegarde en .bak (au lieu de
            -- l'écraser silencieusement par les défauts) et on prévient le joueur.
            file.Write("lzy_bindmenu_binds_corrupt.bak.txt", content)
            WarnBinds("Fichier de binds local illisible — binds réinitialisés (copie gardée : data/lzy_bindmenu_binds_corrupt.bak.txt).")
        end
    end
    return false
end

-- Save binds to local file
local function SaveLocalBinds()
    local content = util.TableToJSON(localBinds, true)
    file.Write(LZY_BIND_FILE, content)
    -- Vérifie que l'écriture a réellement abouti : si le disque/fichier refuse,
    -- les binds marchent en session (mémoire) mais reviennent aux défauts au
    -- prochain boot — on le dit AU MOMENT du problème plutôt que de laisser deviner.
    if file.Size(LZY_BIND_FILE, "DATA") ~= #content then
        WarnBinds("Impossible d'écrire le fichier de binds (data/" .. LZY_BIND_FILE .. ") — tes binds ne survivront pas au prochain redémarrage !")
    end
end

-- Initialize default binds from config
local function InitializeDefaultBinds()
    localBinds = {
        systemBinds = {},
        combatBinds = {},
    }
    
    -- Copy default binds from config
    for key, value in pairs(LZY_DEFAULT_BINDS.systemBinds) do
        localBinds.systemBinds[key] = table.Copy(value)
    end
    
    for key, value in pairs(LZY_DEFAULT_BINDS.combatBinds) do
        localBinds.combatBinds[key] = table.Copy(value)
    end
    
    SaveLocalBinds()
end

-- Merge new binds from config into existing local binds
local function MergeNewBinds()
    if not localBinds.systemBinds then
        localBinds.systemBinds = {}
    end
    if not localBinds.combatBinds then
        localBinds.combatBinds = {}
    end
    
    local hasChanges = false

    -- Migration ciblée (2026-07-16) : « fly » (Voler) a changé de catégorie — Menu (systemBinds)
    -- -> Techniques & Combat (combatBinds). On recopie l'entrée sauvegardée AVANT les boucles de
    -- merge/purge : la purge system jetterait sinon la touche personnalisée du joueur (retour au
    -- défaut T) ; la boucle combat normalise ensuite name/order en GARDANT .bind.
    -- IDEMPOTENT : no-op dès que l'ancienne entrée system a été purgée (1er passage).
    if localBinds.systemBinds.fly and not localBinds.combatBinds.fly then
        localBinds.combatBinds.fly = table.Copy(localBinds.systemBinds.fly)
        hasChanges = true
    end
    
    -- Check for new system binds and update existing ones
    for key, defaultValue in pairs(LZY_DEFAULT_BINDS.systemBinds) do
        if not localBinds.systemBinds[key] then
            localBinds.systemBinds[key] = table.Copy(defaultValue)
            hasChanges = true
        else
            local savedBind = localBinds.systemBinds[key].bind
            local existingName = localBinds.systemBinds[key].name
            local existingOrder = localBinds.systemBinds[key].order

            if existingName ~= defaultValue.name or existingOrder ~= defaultValue.order then
                localBinds.systemBinds[key] = table.Copy(defaultValue)
                localBinds.systemBinds[key].bind = savedBind
                hasChanges = true
            end
        end
    end

    -- Remove system binds that no longer exist in config
    for key in pairs(localBinds.systemBinds) do
        if not LZY_DEFAULT_BINDS.systemBinds[key] then
            localBinds.systemBinds[key] = nil
            hasChanges = true
        end
    end

    -- Check for new combat binds and update existing ones
    for key, defaultValue in pairs(LZY_DEFAULT_BINDS.combatBinds) do
        if not localBinds.combatBinds[key] then
            localBinds.combatBinds[key] = table.Copy(defaultValue)
            hasChanges = true
        else
            local savedBind = localBinds.combatBinds[key].bind
            local existingName = localBinds.combatBinds[key].name
            local existingOrder = localBinds.combatBinds[key].order

            if existingName ~= defaultValue.name or existingOrder ~= defaultValue.order then
                localBinds.combatBinds[key] = table.Copy(defaultValue)
                localBinds.combatBinds[key].bind = savedBind
                hasChanges = true
            end
        end
    end

    -- Remove combat binds that no longer exist in config
    for key in pairs(localBinds.combatBinds) do
        if not LZY_DEFAULT_BINDS.combatBinds[key] then
            localBinds.combatBinds[key] = nil
            hasChanges = true
        end
    end

    -- Migration ciblee (2026-07-02) : le Vol de Combat (aerial_combat) a pris F4. Pour les binds
    -- DEJA sauvegardes, MergeNewBinds conserve la touche existante -> l'OST resterait sur F4 et
    -- entrerait en conflit avec le Vol de Combat. On deplace donc l'ancien defaut OST (F4) vers ",".
    -- IDEMPOTENT : ne bouge QUE depuis KEY_F4 (un joueur deja sur "," ou une autre touche = intact).
    if localBinds.systemBinds.ost_menu and localBinds.systemBinds.ost_menu.bind == "KEY_F4" then
        localBinds.systemBinds.ost_menu.bind = "KEY_COMMA"
        hasChanges = true
    end

    -- Clean up old gmod binds if they exist
    if localBinds.gmodBinds then
        localBinds.gmodBinds = nil
        hasChanges = true
    end

    -- Save if anything changed
    if hasChanges then
        SaveLocalBinds()
    end
end

-- Send binds to server
local function SendBindsToServer()
    net.Start("LZY:BindMenu:ClientBinds")
    net.WriteTable(localBinds.systemBinds)
    net.WriteTable(localBinds.combatBinds)
    net.SendToServer()
end

-- Update a specific bind
local function UpdateBind(bindIndex, newKey, bindCategory)
    if not localBinds[bindCategory .. "Binds"] then
        localBinds[bindCategory .. "Binds"] = {}
    end
    
    -- Ensure the bind exists (use default if not)
    if not localBinds[bindCategory .. "Binds"][bindIndex] then
        local defaultBinds = LZY_DEFAULT_BINDS[bindCategory .. "Binds"]
        if defaultBinds and defaultBinds[bindIndex] then
            localBinds[bindCategory .. "Binds"][bindIndex] = table.Copy(defaultBinds[bindIndex])
        end
    end
    
    -- Update the bind
    if localBinds[bindCategory .. "Binds"][bindIndex] then
        localBinds[bindCategory .. "Binds"][bindIndex].bind = newKey
        SaveLocalBinds()
        
        -- Send update to server
        net.Start("LZY:SaveBindKey")
        net.WriteString(bindIndex)
        net.WriteString(newKey)
        net.WriteString(bindCategory)
        net.SendToServer()

        -- Notifie les UIs qui affichent une touche mise en cache (ex: la spell bar
        -- résout la touche de chaque slot à la création) -> refresh visuel immédiat
        -- sans attendre un re-Deploy de l'arme.
        hook.Run("LZY:BindMenu:Changed", bindIndex, newKey, bindCategory)
    end
end

-- Reset ALL binds to config defaults in one shot (local file + server).
-- Do NOT loop UpdateBind/SaveBindKey: the server throttles SaveBindKey to 1/0.25s,
-- so a multi-key reset left the UI/file on defaults while GetBindKey (server) kept
-- the old keys — "reset in menu but old binds still work".
local function ResetToDefaults()
    if not localBinds.systemBinds then localBinds.systemBinds = {} end
    if not localBinds.combatBinds then localBinds.combatBinds = {} end

    for key, value in pairs(LZY_DEFAULT_BINDS.systemBinds) do
        if localBinds.systemBinds[key] then
            localBinds.systemBinds[key].bind = value.bind
        else
            localBinds.systemBinds[key] = table.Copy(value)
        end
    end
    for key, value in pairs(LZY_DEFAULT_BINDS.combatBinds) do
        if localBinds.combatBinds[key] then
            localBinds.combatBinds[key].bind = value.bind
        else
            localBinds.combatBinds[key] = table.Copy(value)
        end
    end

    SaveLocalBinds()

    net.Start("LZY:BindMenu:ResetBinds")
    net.SendToServer()

    for key, value in pairs(LZY_DEFAULT_BINDS.systemBinds) do
        hook.Run("LZY:BindMenu:Changed", key, value.bind, "system")
    end
    for key, value in pairs(LZY_DEFAULT_BINDS.combatBinds) do
        hook.Run("LZY:BindMenu:Changed", key, value.bind, "combat")
    end
end

-- Get current binds
local function GetLocalBinds()
    return localBinds
end

-- Initialize when client loads
hook.Add("Initialize", "LZY:BindMenu:ClientInit", function()
	-- Load existing binds or initialize defaults
	if not LoadLocalBinds() then
		InitializeDefaultBinds()
	else
		-- Merge any new binds from config into existing local binds
		MergeNewBinds()
	end
end)

-- Send binds when player is ready
hook.Add("InitPostEntity", "LZY:BindMenu:SendBindsOnReady", function()
	-- Wait a bit for everything to be ready
	timer.Simple(2, function()
		if IsValid(LocalPlayer()) then
			SendBindsToServer()
		end
	end)
end)

-- NB : le net.Receive("LZY:BindMenu:UpdateBinds") vit dans vgui/main.lua (un seul
-- handler possible par message — celui qui était ici était écrasé car chargé en
-- premier). Il met à jour sa table d'affichage ET resynchronise localBinds + le
-- fichier via LZY_BindMenu.GetLocalBinds()/SaveLocalBinds() exposés ci-dessous.

-- Expose functions to other addons
LZY_BindMenu = LZY_BindMenu or {}
LZY_BindMenu.UpdateBind = UpdateBind
LZY_BindMenu.ResetToDefaults = ResetToDefaults
LZY_BindMenu.GetLocalBinds = GetLocalBinds
LZY_BindMenu.SaveLocalBinds = SaveLocalBinds

-- Block flashlight
hook.Add("PlayerBindPress", "LZY:BindMenu:BlockNativeBinds", function(ply, bind, pressed)
	if bind == "impulse 100" then
		return true
	end
	-- NOCLIP : pour tout joueur SANS permission (≠ superadmin et ≠ perso animateur), on
	-- AVALE le bind ICI, côté client -> la touche ne fait RIEN. Sans ça, presser noclip
	-- déclenchait la PRÉDICTION client (noclip activé ~1 frame) avant que le serveur le
	-- refuse (evo_cmd_lockdown PlayerNoClip) = le "petit truc bizarre" qui s'active puis
	-- s'enlève. Le refus serveur reste le garde-fou autoritaire (console / cheat client).
	if string.find(string.lower(bind), "noclip", 1, true) then
		if not (IsValid(ply) and (ply:IsSuperAdmin() or ply:GetEvoNWBool("EVO_AnimChar", false))) then
			return true
		end
	end
end)

-- ============================================================
-- Important Keybinds HUD (bottom-right corner)
-- ============================================================

local function InitBindHUDFonts()
	if not gCreateRespFont then
		surface.CreateFont("LZY_BindHUD_Key",  { font = "Roboto", size = 17, weight = 800 })
		surface.CreateFont("LZY_BindHUD_Name", { font = "Roboto", size = 18, weight = 600 })
		return
	end
	gCreateRespFont("LZY_BindHUD_Key",  "Roboto", 14, 800)
	gCreateRespFont("LZY_BindHUD_Name", "Roboto", 15, 600)
end

if gCreateRespFont then InitBindHUDFonts() end
hook.Add("Initialize",         "LZY::BindHUD::InitFonts",    InitBindHUDFonts)
hook.Add("OnScreenSizeChanged", "LZY::BindHUD::RefreshFonts", InitBindHUDFonts)

-- Nom localise du "dash" (pas eclair) selon la faction : Shunpo (Shinigami) /
-- Sonido (Hollow). Applique aux libelles du HUD des binds.
local function HUDMovementName(lp)
	if IsValid(lp) and lp:GetEvoNWString("FactionName", "") == "Hollow" then return "Sonido" end
	return "Shunpo"
end

local importantBinds = {
	{ bindID = nil,               label = "Parametre / Bind",            fixedKey = "ECHAP" },
	{ bindID = "skilltree",       label = "Ouvrir le Skilltree",         category = "system" },
	{ bindID = "spellselector",   label = "Ouvrir le Spell Selector",   category = "system" },
	{ bindID = "inventory",       label = "Inventaire",                  category = "system" },
	{ bindID = "battlepass",      label = "Battlepass",                  category = "system" },
	{ bindID = "voicerange",      label = "Portee de voix",             category = "system" },
	{ bindID = "animation_menu",  label = "Menu des animations",        category = "system" },
	{ bindID = "ost_menu",        label = "Menu OST",                   category = "system" },
	{ bindID = "private_message", label = "Message prive",              category = "system" },
	{ bindID = "cinematic",       label = "Mode cinematique",           category = "system" },
	{ bindID = "heavy_attack",    label = "Coup Lourd",          category = "combat" },
	{ bindID = "reiatsu_charge",  label = "Recharge de reiatsu", category = "combat" },
	{ bindID = "parade",          label = "Parade",                             category = "combat" },
	{ bindID = "dashstep",        label = "Esquive (Touche + Direction)",       category = "combat" },
	{ bindID = "dash",            label = "Flash Step",                         category = "combat",
		fCheck = function(lp) return lp:GetEvoNWBool("NCM_FlashstepTrainingDone", false) end },
	{ bindID = "fly",             label = "Vol Spirituel (Touche + Avancer)",   category = "system",
		fCheck = function(lp) return lp:GetEvoNWBool("NCM_FlyTrainingDone", false) end },
	{ bindID = "pression_spirituelle", label = "Pression Spirituelle",          category = "combat",
		fCheck = function(lp) return lp:GetEvoNWInt("FactionRank", 0) >= 12 end },
}

local function GetBindDisplayKey(entry)
	if entry.fixedKey then return entry.fixedKey end

	local binds = GetLocalBinds()
	if not binds then return "?" end

	local cat = entry.category .. "Binds"
	local tbl = binds[cat]
	if not tbl or not tbl[entry.bindID] then return "?" end

	local enumName = tbl[entry.bindID].bind
	if not enumName then return "?" end

	local lp = LocalPlayer()
	if IsValid(lp) and lp.ConvertBindToDisplayName then
		return lp:ConvertBindToDisplayName(enumName) or enumName
	end
	return enumName
end

-- Binds conditionnels : affichés selon une fonction de check
-- Toujours affichés même si NCM_HideBindHUD est true
local conditionalBinds = {
	{
		bindID   = "dash",
		label    = "Flash Step",
		category = "combat",
		fCheck   = function(lp)
			return lp:GetEvoNWBool("NCM_ShowFlashstepBind", false)
		end,
	},
	{
		bindID   = "fly",
		label    = "Vol Spirituel (Touche + Avancer)",
		category = "system",
		fCheck   = function(lp)
			return lp:GetEvoNWBool("NCM_ShowFlyBind", false)
		end,
	},
}

-- ── DA EVO (cohérent avec le menu de binds vgui/main.lua) ───────────────────
-- Échelle uniforme (comme R() du menu) : capuchons de touche carrés sur tout ratio.
local function BHUD_R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end

-- Couleurs hoistées (évite une allocation Color() par ligne par frame).
local BHUD_LABEL        = Color(208, 210, 216)
local BHUD_LABEL_SHADOW = Color(0, 0, 0, 200)
local KEY_LIP    = Color(0, 0, 0, 210)    -- tranche basse du capuchon (relief 3D)
local KEY_FACE   = Color(32, 32, 39)      -- dessus du capuchon
local KEY_GLOSS  = Color(255, 255, 255, 14) -- reflet haut
local KEY_BORDER = Color(255, 255, 255, 32)
local KEY_ACCENT = Color(207, 68, 78)     -- liseré accent en bas (DA EVO)
local KEY_TEXT   = Color(237, 238, 242)

-- Dessine une touche de clavier : capuchon arrondi avec relief, reflet et liseré accent.
local function DrawKeyCap(x, y, w, h, txt, font)
	local r     = BHUD_R(6)
	local depth = BHUD_R(3)
	RNDX.Draw(r, x, y + depth, w, h, KEY_LIP)                                                     -- tranche / ombre portée
	RNDX.Draw(r, x, y, w, h, KEY_FACE)                                                            -- dessus
	RNDX.Draw(r, x + BHUD_R(1), y + BHUD_R(1), w - BHUD_R(2), math.floor(h * 0.42), KEY_GLOSS, RNDX.NO_BL + RNDX.NO_BR) -- reflet
	RNDX.Draw(r, x, y + h - depth, w, depth, KEY_ACCENT, RNDX.NO_TL + RNDX.NO_TR)                 -- liseré accent
	RNDX.DrawOutlined(r, x, y, w, h, KEY_BORDER, 1)
	-- Le glyphe "I" de la police a un bearing asymétrique et paraît décalé à droite :
	-- on le recale de 2 px vers la gauche (correctif purement visuel).
	local cx = math.Round(x + w / 2) - (txt == "I" and 2 or 0)
	draw.SimpleText(txt, font, cx, math.Round(y + h / 2 - depth / 2), KEY_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

-- OPTIM : le LAYOUT du HUD (fCheck NW + résolution des touches + GetTextSize pour
-- ~16 entrées) coûtait cher recalculé 60×/s. On le reconstruit à ~3 Hz seulement
-- (ou sur changement d'écran) dans un cache, et chaque frame on se contente de
-- DESSINER le cache. Un rebind / une fin d'entraînement se reflète en ≤ 0,35 s
-- (imperceptible pour un HUD passif).
local bindHUD_cache = nil
local bindHUD_next  = 0

local function BuildBindHUD(lp)
	-- Binds conditionnels actifs
	local tConditional = {}
	for _, entry in ipairs(conditionalBinds) do
		if entry.fCheck(lp) then
			tConditional[#tConditional + 1] = entry
		end
	end

	-- Construire la liste : statiques (si HUD visible) + conditionnels (toujours)
	-- Pref "Cacher les touches" = cookie LOCAL persistant (cf. Actions Rapides), plus un NWBool
	-- serveur qui se faisait clobber par le tuto et ne se sauvegardait pas entre 2 connexions.
	-- DÉFAUT INVERSÉ (demande user 2026-07-17) : cookie absent = "1" = touches CACHÉES par
	-- défaut ; on DÉCOCHE « Cacher les touches » (Actions Rapides) pour les afficher.
	local bHideNormal = cookie.GetString("NCM_AR_NCM_HideBindHUD", "1") == "1"
	local tDisplay = {}
	if not bHideNormal then
		for _, entry in ipairs(importantBinds) do
			if not entry.fCheck or entry.fCheck(lp) then
				tDisplay[#tDisplay + 1] = entry
			end
		end
	end
	for _, entry in ipairs(tConditional) do
		tDisplay[#tDisplay + 1] = entry
	end
	if #tDisplay == 0 then return nil end

	local keyH         = BHUD_R(26)
	local lineH        = BHUD_R(34)
	local gap          = BHUD_R(10)
	local padX         = BHUD_R(9)
	local marginRight  = BHUD_R(16)
	local marginBottom = BHUD_R(16)
	local rightX       = ScrW() - marginRight -- ScrW figé = celui du build

	local totalH = #tDisplay * lineH
	local startY = ScrH() - totalH - marginBottom

	surface.SetFont("LZY_BindHUD_Key")
	-- Largeur UNIFORME pour les touches standards (lettres / chiffres / F1..F12) :
	-- on la cale sur la plus large d'entre elles ("F12") afin que "I" et "F1" aient
	-- exactement le même capuchon. Les touches spéciales plus longues (ECHAP, SPACE,
	-- ENTER, MOUSE1...) s'élargissent au-delà de cette base.
	local baseKeyW = math.max(keyH, surface.GetTextSize("F12") + padX * 2)

	local items = {}
	for i, entry in ipairs(tDisplay) do
		local key  = string.upper(GetBindDisplayKey(entry))
		local kw   = surface.GetTextSize(key)
		local keyW = math.max(baseKeyW, kw + padX * 2)

		local rowY = startY + (i - 1) * lineH
		local keyX = rightX - keyW

		items[i] = {
			label  = (entry.bindID == "dash") and HUDMovementName(lp) or entry.label,
			key    = key,
			keyX   = keyX,
			keyY   = rowY + math.floor((lineH - keyH) / 2),
			keyW   = keyW,
			keyH   = keyH,
			labelX = keyX - gap, -- bord droit du libellé (aligné à droite, à gauche du capuchon)
			labelY = rowY + lineH / 2,
		}
	end
	return { items = items }
end

hook.Add("HUDPaint", "LZY::BindHUD::ImportantKeys", function()
	-- Gating bon marché À CHAQUE frame (réaction immédiate mort / menu perso).
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	if lp:GetEvoNWBool("InCharacterMenu", false) then return end

	-- Layout lourd reconstruit à ~3 Hz seulement.
	local now = CurTime()
	if now >= bindHUD_next or not bindHUD_cache then
		bindHUD_cache = BuildBindHUD(lp)
		bindHUD_next  = now + 0.35
	end

	local c = bindHUD_cache
	if not c then return end

	for _, it in ipairs(c.items) do
		-- Libellé (ombre + texte) aligné à droite, juste à gauche du capuchon.
		draw.SimpleText(it.label, "LZY_BindHUD_Name", it.labelX + 1, it.labelY + 1, BHUD_LABEL_SHADOW, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(it.label, "LZY_BindHUD_Name", it.labelX, it.labelY, BHUD_LABEL, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		-- Touche de clavier (capuchon DA EVO).
		DrawKeyCap(it.keyX, it.keyY, it.keyW, it.keyH, it.key, "LZY_BindHUD_Key")
	end
end)

-- Changement de résolution : positions/polices recalculées -> on invalide le cache.
hook.Add("OnScreenSizeChanged", "LZY::BindHUD::Invalidate", function()
	bindHUD_cache = nil
	bindHUD_next  = 0
end)
concommand.Add("lzy_show_binds", function()
	local binds = GetLocalBinds()
	print("=== Current Local Binds ===")
	print("System Binds:")
	for key, value in pairs(binds.systemBinds or {}) do
		print("  " .. key .. ": " .. value.bind .. " (" .. value.name .. ")")
	end
	print("Combat Binds:")
	for key, value in pairs(binds.combatBinds or {}) do
		print("  " .. key .. ": " .. value.bind .. " (" .. value.name .. ")")
	end
end)
