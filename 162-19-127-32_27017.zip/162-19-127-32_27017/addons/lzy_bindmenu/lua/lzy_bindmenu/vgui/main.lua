-- "addons\\lzy_bindmenu\\lua\\lzy_bindmenu\\vgui\\main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- LZY BIND MENU — refait en DA EVO (carte sombre #0E0E11 / accent rouge #cf444e),
-- responsive UNIFORME (R() = min largeur/hauteur, comme le menu support) : vrais
-- composants VGUI (sidebar catégories + DScrollPanel de lignes cliquables + dialogue
-- de réassignation). La LOGIQUE est préservée (gating GetOrderedKeys, détection de
-- touche, swap, reset, méthodes Player, net).
-- ============================================================================

local PANEL = {}
local frame = nil
local data = {
	systemBinds = {},
	combatBinds = {},
}
local bindsDisabled = false
-- Touches réservées : liste unique dans config.lua (partagée avec le serveur).
local activeBindDialogHook = nil
local activeBindDialogOverlay = nil

-- ── DA EVO + responsive uniforme ────────────────────────────────────────────
local function R(v) return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080)) end
local COL = {
	card   = Color(13, 14, 17),                 -- plaque métal noir (Atelier)
	edge   = Color(146, 152, 161, 33),          -- liseré acier 1px
	sub    = Color(22, 22, 27),
	sub2   = Color(30, 30, 36),
	line   = Color(255, 255, 255, 20),
	title  = Color(237, 238, 242),
	muted  = Color(150, 154, 162),
	dim    = Color(108, 111, 120),
	accent = Color(207, 68, 78),
}

-- ── Helpers de dessin DA Atelier (mêmes recettes que échap/squad/support) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end

local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end

local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = R(6), R(5)
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

local function MakeFonts()
	if not gCreateRespFont then return end
	-- DA Atelier : Bebas Neue SANS bold pour l'affichage, Roboto pour les
	-- petits textes d'aide / corps de dialogue.
	gCreateRespFont("LZY_Bind_Title",    "Bebas Neue", 36, 400)
	gCreateRespFont("LZY_Bind_Sub",      "Roboto", 15, 500)
	gCreateRespFont("LZY_Bind_Tab",      "Bebas Neue", 24, 400)
	gCreateRespFont("LZY_Bind_Name",     "Bebas Neue", 25, 400)
	gCreateRespFont("LZY_Bind_Key",      "Bebas Neue", 22, 400)
	gCreateRespFont("LZY_Bind_Btn",      "Bebas Neue", 23, 400)
	gCreateRespFont("LZY_Bind_X",        "Roboto", 30, 400)
	gCreateRespFont("LZY_Bind_DlgTitle", "Bebas Neue", 27, 400)
	gCreateRespFont("LZY_Bind_DlgBody",  "Roboto", 16, 400)
	gCreateRespFont("LZY_Bind_Small",    "Roboto", 15, 500)
end
-- Diffère la création (l'addon peut charger avant glibs).
hook.Add("Initialize", "LZY_Bind::FontsInit", MakeFonts)
hook.Add("OnScreenSizeChanged", "LZY_Bind::Fonts", MakeFonts)
MakeFonts()

-- Bouton stylé (rempli accent OU contour). x/y/w/h en unités de BASE (1920x1080).
local function StyledButton(parent, label, x, y, w, h, filled)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b:SetPos(R(x), R(y))
	b:SetSize(R(w), R(h))
	b.Paint = function(s, bw, bh)
		local hov = s:IsHovered()
		if filled then
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(COL.accent, hov and 255 or 220))
			draw.SimpleText(label, "LZY_Bind_Btn", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			RNDX.Draw(R(8), 0, 0, bw, bh, ColorAlpha(color_white, hov and 14 or 7))
			RNDX.DrawOutlined(R(8), 0, 0, bw, bh, ColorAlpha(COL.line, hov and 60 or 32), 1)
			draw.SimpleText(label, "LZY_Bind_Btn", bw / 2, bh / 2, hov and COL.title or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	return b
end

local function NotifyBindError(msg)
	local lp = LocalPlayer()
	if IsValid(lp) and lp.Notif then
		lp:Notif(1, 4, msg)
		return
	end

	if MUGEN and MUGEN.Notify then
		-- Client-side fallback
		MUGEN.Notify(msg)
		return
	end

	MUGEN.AddNotification(msg, NOTIFY_ERROR, 4)
end

-- Helper function to get ordered keys using the order field from LZY_DEFAULT_BINDS
-- Filtre les binds avec requiredDivision si la division du joueur ne correspond pas
local function GetOrderedKeys(bindCategory, defaultTable)
	local tempTable = {}
	local lp = LocalPlayer()
	local playerDivision = IsValid(lp) and lp:GetEvoNWInt("FactionDivision", 0) or 0

	-- Create a temporary table with order information
	for key, value in pairs(bindCategory) do
		local defaultEntry = defaultTable[key]
		-- Métadonnées de gating : on lit celles du config (defaultEntry) si présentes,
		-- sinon celles portées par le bind lui-même (value). ROBUSTE si LZY_DEFAULT_BINDS
		-- a perdu une injection (reset de config.lua / refresh / ordre de chargement) :
		-- sinon les passifs de division s'affichaient TOUS en même temps.
		local meta = defaultEntry or value
		local defaultOrder = (meta and meta.order) or 999

		-- Filtrer les binds dont la division requise ne correspond pas
		if meta and meta.requiredDivision and meta.requiredDivision ~= playerDivision then
			continue
		end

		-- NOTE (demande user) : on N'APPLIQUE PLUS les gates de PROGRESSION dans le MENU de binds
		-- (requiredUnlock / trainingNWBool / requiredRank). But : TOUTES les touches d'action
		-- apparaissent et sont CONFIGURABLES même avant d'avoir débloqué la capacité (vol,
		-- flashstep, shikai, pression, senkaimon...) -> plus de "le fly n'apparaît pas". Les
		-- handlers vérifient de toute façon le déblocage à l'USAGE (le bind visible ne débloque
		-- rien). On garde uniquement les gates de PERTINENCE / PERMISSION ci-dessous (faction,
		-- division, famille, superadmin, animateur). Le HUD de binds (cl_main.lua), lui, garde
		-- ses fCheck : il n'affiche le rappel de touche qu'une fois la capacité débloquée.

		-- EXCEPTION à la règle « toutes les touches visibles » ci-dessus (flag menuRequiresUnlock) :
		-- ces binds n'apparaissent QUE si leur condition est remplie. D'abord réservé aux menus de
		-- pouvoir shikai_ui / bankai_ui (demande user 07/14), GÉNÉRALISÉ le 07/18 (demande user) à
		-- TOUTE capacité à progression : le flag se pose dans la config du bind, à côté de sa
		-- condition — requiredUnlock (NWBool), trainingNWBool (visible PENDANT l'entraînement),
		-- requiredRank (grade). Une seule condition remplie suffit à afficher l'entrée.
		if meta and meta.menuRequiresUnlock then
			local bShow = false
			if meta.requiredUnlock and IsValid(lp) and lp:GetEvoNWBool(meta.requiredUnlock, false) then bShow = true end
			if not bShow and meta.trainingNWBool and IsValid(lp) and lp:GetEvoNWBool(meta.trainingNWBool, false) then bShow = true end
			if not bShow and meta.requiredRank and IsValid(lp) and lp:GetEvoNWInt("FactionRank", 0) >= meta.requiredRank then bShow = true end
			if not bShow then continue end
		end

		-- Filtrer les binds réservés à une faction (ex: Senkaimon = Shinigami,
		-- Garganta = Hollow : on ne montre que le portail de SA faction)
		if meta and meta.requiredFaction and lp:GetEvoNWString("FactionName", "") ~= meta.requiredFaction then
			continue
		end

		-- Filtrer les binds réservés aux membres d'un CLAN (evo_clan) : NWString
		-- EVO_ClanKey non vide = le perso appartient à un clan. SANS clan -> PAS
		-- de bind (demande user 07/14) : on crée/rejoint un clan chez le Doyen ;
		-- !clan / evo_clan_menu restent dispo (dont l'onglet Admin des SA).
		if meta and meta.familyOnly and (not IsValid(lp)
			or lp:GetEvoNWString("EVO_ClanKey", "") == "") then
			continue
		end

		-- Filtrer les binds réservés aux membres d'un COMMERCE (evo_business).
		if meta and meta.businessOnly and (not IsValid(lp)
			or lp:GetEvoNWString("EVO_BusinessId", "") == "") then
			continue
		end

		-- Filtrer les binds réservés aux super admins (ex: panneau Actions Rapides)
		if meta and meta.superadmin and not (IsValid(lp) and lp:IsSuperAdmin()) then
			continue
		end

		-- Bind réservé au pôle Équilibrage : le panneau n'a de sens que pour eux, et
		-- le serveur revalide de toute façon chaque action.
		if meta and meta.equilibrage and not (EVO_EQUILIBRAGE and EVO_EQUILIBRAGE.PeutOuvrir and EVO_EQUILIBRAGE.PeutOuvrir(lp)) then
			continue
		end

		-- Bind staff (dashboard) : visible en mode staff ACTIF, ou superadmin (toujours).
		if meta and meta.staffmode and not (IsValid(lp) and (lp:GetEvoNWBool("EVO_StaffMode", false) or lp:IsSuperAdmin())) then
			continue
		end

		-- Bind réservé au staff d'animation (animateur / admin / superadmin) : on n'insère
		-- que si autorisé (insertion conditionnelle, sans 'continue' supplémentaire).
		local bAnimOk = true
		if meta and meta.animstaff then
			local ug = IsValid(lp) and lp:GetUserGroup() or ""
			bAnimOk = (IsValid(lp) and (lp:IsAdmin() or ug == "admin" or ug == "superadmin" or (EVO_ANIM ~= nil and EVO_ANIM.IsAnimGroupName(ug)))) or false
		end

		if bAnimOk then
			table.insert(tempTable, {key = key, order = defaultOrder})
		end
	end

	-- Sort by order field
	table.sort(tempTable, function(a, b) return a.order < b.order end)

	-- Extract just the keys in order
	local orderedKeys = {}
	for _, item in ipairs(tempTable) do
		table.insert(orderedKeys, item.key)
	end

	return orderedKeys
end

-- ════════════════════════════════════════════════════════════════════════════
--  PANNEAU
-- ════════════════════════════════════════════════════════════════════════════

local CARD_W, CARD_H, SIDEBAR = 900, 580, 250

-- Nom d'affichage d'un bind : certains libellés se localisent selon la FACTION
-- du joueur (detectes via requiredUnlock — robuste au renommage de cle) :
--   dash   -> "Shunpo" (Shinigami) / "Sonido" (Hollow)
--   shikai -> ACTIVATION (powerActivation) : "Activer le Shikai" / "Activer la Resurrección Partielle"
--             MENU (shikai_ui)             : "Ouvrir le menu Shikai" / "Ouvrir le menu Resurrección Partielle"
--   bankai -> "Ouvrir le menu Bankai" / "Ouvrir le menu Resurrección"
local function ResolveBindName(bindData, fallback)
	if bindData then
		local lp = LocalPlayer()
		local bHollow = IsValid(lp) and lp:GetEvoNWString("FactionName", "") == "Hollow"
		if bindData.requiredUnlock == "NCM_FlashstepTrainingDone" then
			return bHollow and "Sonido" or "Shunpo"
		elseif bindData.requiredUnlock == "EVO_ShikaiUnlocked" then
			-- Deux binds partagent ce unlock : celui d'ACTIVATION (powerActivation) et celui qui
			-- OUVRE le menu (shikai_ui). Ne pas confondre "Activer" et "Ouvrir le menu".
			if bindData.powerActivation then
				return bHollow and "Activer la Resurrección Partielle" or "Activer le Shikai"
			end
			return bHollow and "Ouvrir le menu Resurrección Partielle" or "Ouvrir le menu Shikai"
		elseif bindData.requiredUnlock == "EVO_BankaiUnlocked" then
			return bHollow and "Ouvrir le menu Resurrección" or "Ouvrir le menu Bankai"
		end
	end
	return (bindData and bindData.name) or fallback or ""
end

function PANEL:Init()
	LocalPlayer():DisableBindKeys(true)
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:SetTitle("")
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetPaintBackgroundEnabled(false)
	self:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(self) end
	-- Fermeture Échap fiable (comme shop/inventaire) : OnPauseMenuShow de lzy_escape_menu
	-- ferme `openedFrame` + return false.
	openedFrame = self

	self.bindCategory = "system"
	self._a = 0

	local cardW, cardH = R(CARD_W), R(CARD_H)
	local cardX, cardY = math.floor((ScrW() - cardW) / 2), math.floor((ScrH() - cardH) / 2)

	-- Backdrop plein écran = mêmes appels que le spell selector.
	self.Paint = function(s, w, h)
		local a = s._a / 255
		if a < 0.01 then return end
		if RNDX and RNDX.Draw and RNDX.BLUR then
			RNDX.Draw(0, 0, 0, w, h, color_white, RNDX.BLUR)
		elseif EVO_UI and EVO_UI.DrawBlur then
			EVO_UI.DrawBlur(s, 5)
		end
		surface.SetDrawColor(5, 5, 7, 216 * a)
		surface.DrawRect(0, 0, w, h)
	end
	self.OnMousePressed = function() self:Close() end -- clic dehors = fermer

	-- Carte centrée (enfant -> coins arrondis propres).
	local card = vgui.Create("DPanel", self)
	card:SetSize(cardW, cardH)
	card:SetPos(cardX, cardY)
	card:SetMouseInputEnabled(true)
	card.OnMousePressed = function() end
	card.Paint = function(s, w, h)
		local a = (self._a or 255) / 255
		if a < 0.01 then return end
		-- Plaque de métal noir Atelier : coins coupés + liseré acier + vis.
		EVO_UI.PaintCut(0, 0, w, h, ColorAlpha(COL.card, 250 * a), R(16))
		-- DA dashboard 08/07 : plaque plate, plus de lisere acier.
		local sr = R(5)
		drawScrew(R(18), R(18), sr)
		drawScrew(w - R(18), R(18), sr)
		drawScrew(w - R(18), h - R(18), sr)
		drawScrew(R(18), h - R(18), sr)
		-- Titre Bebas SANS bold + entaille slash1 réduite + filet DENTÉ.
		draw.SimpleText("BIND", "LZY_Bind_Title", R(22), R(26), ColorAlpha(COL.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("LZY_Bind_Title")
		local tw, th = surface.GetTextSize("BIND")
		if not EVO_UI.Ink(EVO_UI.TexSlash, R(20), R(26) + th * 0.28, tw * 1.15, R(9), ColorAlpha(COL.accent, 245 * a)) then
			surface.SetDrawColor(ColorAlpha(COL.accent, 255 * a))
			surface.DrawRect(R(22), R(26) + th * 0.34, tw, math.max(2, R(3)))
		end
		draw.SimpleText("RACCOURCIS CLAVIER", "LZY_Bind_Sub", R(22) + tw + R(14), R(28), ColorAlpha(COL.muted, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- Divider vertical (sidebar | contenu) + filet denté sous le header
		surface.SetDrawColor(ColorAlpha(COL.line, 150 * a))
		surface.DrawRect(R(SIDEBAR), R(70), 1, h - R(82))
		drawDashes(R(24), R(58), w - R(48), Color(255, 255, 255, 26 * a))
	end
	self.card = card

	-- Croix de fermeture (grise -> blanche au survol).
	local close = vgui.Create("DButton", card)
	close:SetText("")
	close:SetSize(R(28), R(28))
	close:SetPos(R(CARD_W - 42), R(19))
	close.Paint = function(s, w, h)
		-- Croix standard DA : glyphe ✕, pas de fond au survol, gris -> accent.
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2, s:IsHovered() and COL.accent or COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() self:Close() end

	-- Bouton "Réinitialiser les touches" (bas-droite).
	local reset = StyledButton(card, "Réinitialiser les touches", CARD_W - 24 - 250, CARD_H - 24 - 34, 250, 34, false)
	reset.DoClick = function() self:ResetToDefaults() end

	-- Catégories (sidebar gauche).
	-- Cases sidebar = items du menu échap (puce brush1 acier -> rouge, plaque
	-- acier à coin coupé + barre accent en survol/sélection, dents entre items).
	local cats = { { id = "system", label = "Menu" }, { id = "combat", label = "Techniques & Combat" } }
	for i, c in ipairs(cats) do
		local b = vgui.Create("DButton", card)
		b:SetText("")
		b:SetPos(R(16), R(80 + (i - 1) * 50))
		b:SetSize(R(SIDEBAR - 24), R(44))
		b.OnCursorEntered = function() surface.PlaySound(EVO_UI.SndHover) end
		b.Paint = function(s, w, h)
			local on = (self.bindCategory == c.id)
			local hf = EVO_UI.HoverFrac(s, 10)
			local vis = on and 1 or hf
			if vis > 0.02 then
				EVO_UI.PaintCut(0, R(2), w, h - R(4), Color(17, 18, 22, 205 * vis), R(9), "br")
				-- DA dashboard 08/07 : plaque plate, plus de lisere acier (barre accent conservee).
				surface.SetDrawColor(207, 68, 78, 235 * vis)
				surface.DrawRect(0, R(2), R(2), h - R(4))
			end
			local brushPath = (EVO_UI.HasMat("evo_ui/tex/brush1.png") and "evo_ui/tex/brush1.png")
				or (EVO_UI.HasMat(EVO_UI.TexBrush) and EVO_UI.TexBrush or nil)
			if brushPath then
				local cc = (on or hf > 0.5) and ColorAlpha(COL.accent, 240) or Color(150, 154, 162, 150)
				EVO_UI.Ink(brushPath, R(9), h / 2 - R(5), R(18), R(11), cc)
			end
			draw.SimpleText(c.label, "LZY_Bind_Tab", R(34) + vis * R(5), h / 2,
				(on or hf > 0.01) and COL.title or COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			if i < #cats and vis < 0.98 then
				drawDashes(R(8), h - 1, w - R(16), Color(255, 255, 255, 22 * (1 - vis)))
			end
		end
		b.DoClick = function() surface.PlaySound(EVO_UI.SndClick) self:SetBindCategory(c.id) end
	end

	-- Liste des binds (scroll, à droite du divider).
	self.list = vgui.Create("DScrollPanel", card)
	self.list:SetPos(R(SIDEBAR + 24), R(74))
	self.list:SetSize(R(CARD_W - SIDEBAR - 48), R(CARD_H - 74 - 64))
	local sb = self.list:GetVBar()
	sb:SetWide(R(6))
	sb.Paint = function() end
	sb.btnUp.Paint, sb.btnDown.Paint = function() end, function() end
	sb.btnGrip.Paint = function(s, w, h) RNDX.Draw(R(3), 0, 0, w, h, Color(70, 70, 80)) end
end

function PANEL:Think()
	self._a = Lerp(FrameTime() * 12, self._a or 0, 255)
end

function PANEL:SetBinds(systemBinds, combatBinds)
	self.systemBinds = systemBinds
	self.combatBinds = combatBinds
	self.selectedBindsCategory = systemBinds
	self.bindCategory = "system"
	self:RebuildList()
end

function PANEL:SetBindCategory(bindCategory)
	self.bindCategory = bindCategory
	if bindCategory == "system" then
		self.selectedBindsCategory = self.systemBinds
	elseif bindCategory == "combat" then
		self.selectedBindsCategory = self.combatBinds
	end
	self:RebuildList()
end

-- (Re)construit les lignes de binds dans le DScrollPanel selon la catégorie courante.
-- Chaque ligne peint EN DIRECT depuis bindData (référence) -> la touche affichée se met
-- à jour toute seule après une réassignation (pas besoin de rebuild).
function PANEL:RebuildList()
	if not IsValid(self.list) then return end
	self.list:GetCanvas():Clear()
	if not self.selectedBindsCategory then return end

	local defaultTable = (self.bindCategory == "system") and LZY_DEFAULT_BINDS.systemBinds or LZY_DEFAULT_BINDS.combatBinds
	local orderedKeys = GetOrderedKeys(self.selectedBindsCategory, defaultTable)

	for _, key in ipairs(orderedKeys) do
		local bindData = self.selectedBindsCategory[key]
		if bindData then
			local row = vgui.Create("DButton", self.list)
			row:Dock(TOP) row:DockMargin(0, 0, R(8), R(8)) row:SetTall(R(46)) row:SetText("") row:SetCursor("hand")
			row.Paint = function(s, w, h)
				local hov = s:IsHovered()
				RNDX.Draw(R(10), 0, 0, w, h, hov and COL.sub2 or COL.sub)
					-- DA dashboard 08/07 : bordure rouge au survol (bouton-carte cliquable).
					local hf = EVO_UI.HoverFrac(s, 10) if hf > 0.02 then RNDX.DrawOutlined(R(10), 0, 0, w, h, ColorAlpha(COL.accent, 235 * hf), 1.5) end
				draw.SimpleText(ResolveBindName(bindData, key), "LZY_Bind_Name", R(16), h / 2, hov and COL.title or COL.muted, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				-- Chip de la touche (accent) à droite.
				local disp = LocalPlayer():ConvertBindToDisplayName(bindData.bind)
				disp = (disp and disp ~= "" and bindData.bind ~= "") and string.upper(disp) or "—"
				surface.SetFont("LZY_Bind_Key")
				local tw = surface.GetTextSize(disp)
				local chipW = math.max(R(46), tw + R(22))
				local chipX = w - R(12) - chipW
				RNDX.Draw(R(7), chipX, h / 2 - R(15), chipW, R(30), ColorAlpha(COL.accent, hov and 255 or 220))
				draw.SimpleText(disp, "LZY_Bind_Key", chipX + chipW / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function() self:OnBindButtonClicked(key, bindData) end
		end
	end
end

function PANEL:OnBindButtonClicked(bindIndex, bindData)
	self:CreateKeyBindingDialog(bindIndex, bindData)
end

function PANEL:CreateKeyBindingDialog(bindIndex, bindData)
	-- Sécurité : un seul dialogue de bind actif à la fois
	if activeBindDialogHook then
		hook.Remove("Think", activeBindDialogHook)
		activeBindDialogHook = nil
	end
	if IsValid(activeBindDialogOverlay) then
		activeBindDialogOverlay:Remove()
		activeBindDialogOverlay = nil
	end

	-- Overlay plein écran (assombri) + carte de dialogue DA EVO.
	local overlay = vgui.Create("DPanel")
	overlay:SetSize(ScrW(), ScrH())
	overlay:SetPos(0, 0)
	overlay:MakePopup()
	overlay:SetPaintBackground(false)
	activeBindDialogOverlay = overlay

	local mainPanel = self

	-- Carte centrée en vraies dimensions écran (centrage correct sur tout ratio).
	local dw, dh = R(420), R(210)
	local dx, dy = math.floor((ScrW() - dw) / 2), math.floor((ScrH() - dh) / 2)

	overlay.Paint = function(s, w, h)
		surface.SetDrawColor(0, 0, 0, 170)
		surface.DrawRect(0, 0, w, h)
		RNDX.Draw(R(16), dx, dy, dw, dh, COL.card)
		-- accent + titre
		surface.SetDrawColor(COL.accent)
		surface.DrawRect(dx + R(24), dy + R(26), R(3), R(18))
		draw.SimpleText("CHANGER LE BIND", "LZY_Bind_DlgTitle", dx + R(38), dy + R(34), COL.title, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		-- nom du bind
		draw.SimpleText(ResolveBindName(bindData, ""), "LZY_Bind_DlgBody", dx + dw / 2, dy + R(74), COL.muted, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		-- touche actuelle (chip accent)
		local disp = LocalPlayer():ConvertBindToDisplayName(bindData.bind)
		disp = (disp and disp ~= "" and bindData.bind ~= "") and string.upper(disp) or "—"
		surface.SetFont("LZY_Bind_Key")
		local tw = surface.GetTextSize(disp)
		local chipW = math.max(R(54), tw + R(24))
		RNDX.Draw(R(8), dx + dw / 2 - chipW / 2, dy + R(94), chipW, R(34), ColorAlpha(COL.accent, 235))
		draw.SimpleText(disp, "LZY_Bind_Key", dx + dw / 2, dy + R(111), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		-- instructions
		draw.SimpleText("Appuie sur une touche pour l'assigner", "LZY_Bind_DlgBody", dx + dw / 2, dy + R(150), COL.title, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Échap ou clic à côté pour annuler", "LZY_Bind_Small", dx + dw / 2, dy + R(174), COL.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Key detection variables
	local keyPressed = false
	local newKey = nil
	local lastKeyState = {}
	local detectionStartTime = CurTime() + 0.2 -- Wait before starting detection

	-- Create a unique hook name for this dialog
	local hookName = "LZY_KeyBindingDialog_" .. tostring(overlay)
	activeBindDialogHook = hookName

	-- Add hook for key detection
	hook.Add("Think", hookName, function()
		if not IsValid(overlay) then
			hook.Remove("Think", hookName)
			return
		end

		-- Wait before starting key detection
		if CurTime() < detectionStartTime then
			return
		end

		if not keyPressed then
		-- Check for letter keys (A-Z)
		local letterKeys = {
			[KEY_A] = "KEY_A", [KEY_B] = "KEY_B", [KEY_C] = "KEY_C", [KEY_D] = "KEY_D", [KEY_E] = "KEY_E",
			[KEY_F] = "KEY_F", [KEY_G] = "KEY_G", [KEY_H] = "KEY_H", [KEY_I] = "KEY_I", [KEY_J] = "KEY_J",
			[KEY_K] = "KEY_K", [KEY_L] = "KEY_L", [KEY_M] = "KEY_M", [KEY_N] = "KEY_N", [KEY_O] = "KEY_O",
			[KEY_P] = "KEY_P", [KEY_Q] = "KEY_Q", [KEY_R] = "KEY_R", [KEY_S] = "KEY_S", [KEY_T] = "KEY_T",
			[KEY_U] = "KEY_U", [KEY_V] = "KEY_V", [KEY_W] = "KEY_W", [KEY_X] = "KEY_X", [KEY_Y] = "KEY_Y",
			[KEY_Z] = "KEY_Z"
		}

		for key, keyName in pairs(letterKeys) do
			local isDown = input.IsKeyDown(key)
			if isDown and not lastKeyState[key] then
				newKey = keyName
				keyPressed = true
				break
			end
			lastKeyState[key] = isDown
		end

			-- Check for number keys (0-9)
			for key = KEY_0, KEY_9 do
				local isDown = input.IsKeyDown(key)
				if isDown and not lastKeyState[key] then
					newKey = "KEY_" .. tostring(key - KEY_0)
					keyPressed = true
					break
				end
				lastKeyState[key] = isDown
			end

			-- Check for function keys (F1-F12)
			for key = KEY_F1, KEY_F12 do
				local isDown = input.IsKeyDown(key)
				if isDown and not lastKeyState[key] then
					newKey = "KEY_F" .. (key - KEY_F1 + 1)
					keyPressed = true
					break
				end
				lastKeyState[key] = isDown
			end

			-- Check for special keys
			local specialKeys = {
				[KEY_SPACE]      = "KEY_SPACE",
				[KEY_ENTER]      = "KEY_ENTER",
				[KEY_TAB]        = "KEY_TAB",
				[KEY_ESCAPE]     = "KEY_ESCAPE",
				-- Modificateurs
				[KEY_LSHIFT]     = "KEY_LSHIFT",
				[KEY_RSHIFT]     = "KEY_RSHIFT",
				[KEY_LALT]       = "KEY_LALT",
				[KEY_RALT]       = "KEY_RALT",
				[KEY_LCONTROL]   = "KEY_LCONTROL",
				[KEY_RCONTROL]   = "KEY_RCONTROL",
				-- Ponctuation
				[KEY_SEMICOLON]  = "KEY_SEMICOLON",
				[KEY_APOSTROPHE] = "KEY_APOSTROPHE",
				[KEY_BACKQUOTE]  = "KEY_BACKQUOTE",
				[KEY_COMMA]      = "KEY_COMMA",
				[KEY_PERIOD]     = "KEY_PERIOD",
				[KEY_SLASH]      = "KEY_SLASH",
				[KEY_BACKSLASH]  = "KEY_BACKSLASH",
				[KEY_LBRACKET]   = "KEY_LBRACKET",
				[KEY_RBRACKET]   = "KEY_RBRACKET",
				[KEY_MINUS]      = "KEY_MINUS",
				[KEY_EQUAL]      = "KEY_EQUAL"
			}

			for key, keyName in pairs(specialKeys) do
				local isDown = input.IsKeyDown(key)
				if isDown and not lastKeyState[key] then
					if key == KEY_ESCAPE then
						hook.Remove("Think", hookName)
						overlay:Remove()
						return
					else
						newKey = keyName
						keyPressed = true
						break
					end
				end
				lastKeyState[key] = isDown
			end

			-- Check for mouse buttons
			local mouseButtons = {
				[MOUSE_LEFT] = "MOUSE_LEFT",
				[MOUSE_RIGHT] = "MOUSE_RIGHT",
				[MOUSE_MIDDLE] = "MOUSE_MIDDLE",
				[MOUSE_4] = "MOUSE_4",
				[MOUSE_5] = "MOUSE_5"
			}

			for mouseBtn, btnName in pairs(mouseButtons) do
				local isDown = input.IsMouseDown(mouseBtn)
				if isDown and not lastKeyState[mouseBtn] then
					newKey = btnName
					keyPressed = true
					break
				end
				lastKeyState[mouseBtn] = isDown
			end

			-- If a key was pressed, update the bind
			if keyPressed and newKey then
				if LZY_BindMenu_IsKeyReserved(newKey) then
					local blockedName = LocalPlayer():ConvertBindToDisplayName(newKey) or newKey
					NotifyBindError("La touche " .. blockedName .. " est reservee et ne peut pas etre assignee.")
					hook.Remove("Think", hookName)
					activeBindDialogHook = nil
					overlay:Remove()
					activeBindDialogOverlay = nil
					return
				end

				-- Check if the key is already used by another bind and swap
				local categories = {"system", "combat", "gmod"}
				for _, cat in ipairs(categories) do
					local bindsTable = (cat == "system") and mainPanel.systemBinds or (cat == "combat") and mainPanel.combatBinds or mainPanel.gmodBinds
					if bindsTable then
						for bKey, bData in pairs(bindsTable) do
							if bData.bind == newKey and not (bKey == bindIndex and cat == mainPanel.bindCategory) then
								-- Clear the old bind
								bData.bind = ""
								if LZY_BindMenu and LZY_BindMenu.UpdateBind then
									LZY_BindMenu.UpdateBind(bKey, "", cat)
								end
								if data[cat .. "Binds"] and data[cat .. "Binds"][bKey] then
									data[cat .. "Binds"][bKey].bind = ""
								end
							end
						end
					end
				end

				-- Update the bind data
				self.selectedBindsCategory[bindIndex].bind = newKey

				self:SaveNewBindKey(bindIndex, newKey)

				-- Remove hook and close dialog
				hook.Remove("Think", hookName)
				activeBindDialogHook = nil
				overlay:Remove()
				activeBindDialogOverlay = nil
			end
		end
	end)

	-- Close on click outside
	overlay.OnMousePressed = function(self, mouseCode)
		if mouseCode == MOUSE_LEFT then
			local mouseX, mouseY = self:CursorPos()
			if mouseX < dx or mouseX > dx + dw or mouseY < dy or mouseY > dy + dh then
				hook.Remove("Think", hookName)
				activeBindDialogHook = nil
				self:Remove()
				activeBindDialogOverlay = nil
			end
		end
	end
end

function PANEL:SaveNewBindKey(bindIndex, newKey)
	local bindCategory = self.bindCategory

	-- Use the client-side system to save the bind
	if LZY_BindMenu and LZY_BindMenu.UpdateBind then
		LZY_BindMenu.UpdateBind(bindIndex, newKey, bindCategory)
	end

	-- Update local data immediately for UI responsiveness
	if data[bindCategory .. "Binds"] and data[bindCategory .. "Binds"][bindIndex] then
		data[bindCategory .. "Binds"][bindIndex].bind = newKey
	end
end

function PANEL:ResetToDefaults()
	-- Un seul sync serveur (pas N× SaveBindKey throttle) — cf. LZY_BindMenu.ResetToDefaults.
	if LZY_BindMenu and LZY_BindMenu.ResetToDefaults then
		LZY_BindMenu.ResetToDefaults()
	end

	-- Aligne les tables d'affichage / GetBindKey client sur le storage local (mêmes refs
	-- si PreloadData/OpenBindMenu ont déjà partagé les tables ; sinon on rebranche).
	local lb = LZY_BindMenu and LZY_BindMenu.GetLocalBinds and LZY_BindMenu.GetLocalBinds()
	if lb then
		data.systemBinds = lb.systemBinds or data.systemBinds
		data.combatBinds = lb.combatBinds or data.combatBinds
		self.systemBinds = data.systemBinds
		self.combatBinds = data.combatBinds
	end

	self:RebuildList()
end

function PANEL:OnClose()
	LocalPlayer():DisableBindKeys(false)
	self:Remove()
end

-- Nettoyage sur TOUTE fermeture (×, Échap via openedFrame, Close) : réactive les binds + libère openedFrame.
function PANEL:OnRemove()
	if IsValid(LocalPlayer()) then LocalPlayer():DisableBindKeys(false) end
	if openedFrame == self then openedFrame = nil end
end

vgui.Register("LZY:BindMenu", PANEL, "DFrame")

local Player = FindMetaTable("Player")

function Player:OpenBindMenu()
	-- Load current binds from client-side system
	if LZY_BindMenu and LZY_BindMenu.GetLocalBinds then
		local localBinds = LZY_BindMenu.GetLocalBinds()
		if localBinds then
			data.systemBinds = localBinds.systemBinds or {}
			data.combatBinds = localBinds.combatBinds or {}
		end
	end

	-- Open the bind menu
	frame = vgui.Create("LZY:BindMenu")
	frame:SetBinds(data.systemBinds, data.combatBinds)
end

-- Signal partagé "le menu de binds est ouvert" (frame valide = carte du menu OU dialogue
-- de réassignation affiché). Robuste/auto-nettoyant (basé sur IsValid, pas un booléen qui
-- pourrait rester bloqué). Utilisé par la spell bar pour NE PAS lancer un sort quand on
-- presse une touche pendant qu'on réassigne un bind.
LZY_BindMenu = LZY_BindMenu or {}
function LZY_BindMenu.IsMenuOpen()
	return IsValid(frame)
end

function Player:DisableBindKeys(disable)
	if disable == nil then disable = true end
	bindsDisabled = disable
	net.Start("LZY:DisableBindKeysServer")
	net.WriteBool(bindsDisabled)
	net.SendToServer()
end

-- Return the bind key for the given bindIndex (seach in all the bind categories)
function Player:GetBindKey(bindIndex, returnString)
	if bindsDisabled then return nil end
	-- Conditions du bind (division / faction / staff) : touche MUETTE partout si la
	-- condition n'est plus remplie (cf. LZY_BindMenu_IsBindAllowed, config.lua).
	if LZY_BindMenu_IsBindAllowed and not LZY_BindMenu_IsBindAllowed(self, bindIndex) then return nil end
	local systemBinds = data.systemBinds or {}
	local combatBinds = data.combatBinds or {}

	for key, value in pairs(systemBinds) do
		if key == bindIndex then
			if returnString then
				return value.bind
			else
				return _G[value.bind]
			end
		end
	end

	for key, value in pairs(combatBinds) do
		if key == bindIndex then
			if returnString then
				return value.bind
			else
				return _G[value.bind]
			end
		end
	end

	return nil
end

-- Return the bind index for the given keyCode (seach in all the bind categories)
function Player:GetBindIndexByKey(keyCode)
	if bindsDisabled then return nil end
    local systemBinds = data.systemBinds or {}
    local combatBinds = data.combatBinds or {}

    for bindIndex, value in pairs(systemBinds) do
        local enumName = value and value.bind
        local enumCode = enumName and _G[enumName]
        if enumCode and enumCode == keyCode
        and (not LZY_BindMenu_IsBindAllowed or LZY_BindMenu_IsBindAllowed(self, bindIndex)) then
            return bindIndex
        end
    end

    for bindIndex, value in pairs(combatBinds) do
        local enumName = value and value.bind
        local enumCode = enumName and _G[enumName]
        if enumCode and enumCode == keyCode
        and (not LZY_BindMenu_IsBindAllowed or LZY_BindMenu_IsBindAllowed(self, bindIndex)) then
            return bindIndex
        end
    end

	return nil
end

-- Return the bind name for the given bindIndex (seach in all the bind categories)
-- Passe par ResolveBindName -> libellés localisés par faction (Shunpo/Sonido,
-- Shikai/Resurrección Partielle, Bankai/Resurrección) partout où le nom est affiché.
function Player:GetBindName(bindIndex)
	local systemBinds = data.systemBinds
	local combatBinds = data.combatBinds

	for key, value in pairs(systemBinds) do
		if key == bindIndex then
			return ResolveBindName(value)
		end
	end

	for key, value in pairs(combatBinds) do
		if key == bindIndex then
			return ResolveBindName(value)
		end
	end

	return nil
end

function Player:ConvertBindToDisplayName(bindEnum)
	if not bindEnum then return nil end

	-- Convert enum names to display names
	local displayNames = {
		-- Letter keys
		["KEY_A"] = "A", ["KEY_B"] = "B", ["KEY_C"] = "C", ["KEY_D"] = "D", ["KEY_E"] = "E",
		["KEY_F"] = "F", ["KEY_G"] = "G", ["KEY_H"] = "H", ["KEY_I"] = "I", ["KEY_J"] = "J",
		["KEY_K"] = "K", ["KEY_L"] = "L", ["KEY_M"] = "M", ["KEY_N"] = "N", ["KEY_O"] = "O",
		["KEY_P"] = "P", ["KEY_Q"] = "Q", ["KEY_R"] = "R", ["KEY_S"] = "S", ["KEY_T"] = "T",
		["KEY_U"] = "U", ["KEY_V"] = "V", ["KEY_W"] = "W", ["KEY_X"] = "X", ["KEY_Y"] = "Y",
		["KEY_Z"] = "Z",

		-- Number keys
		["KEY_0"] = "0", ["KEY_1"] = "1", ["KEY_2"] = "2", ["KEY_3"] = "3", ["KEY_4"] = "4",
		["KEY_5"] = "5", ["KEY_6"] = "6", ["KEY_7"] = "7", ["KEY_8"] = "8", ["KEY_9"] = "9",

		-- Function keys
		["KEY_F1"] = "F1", ["KEY_F2"] = "F2", ["KEY_F3"] = "F3", ["KEY_F4"] = "F4",
		["KEY_F5"] = "F5", ["KEY_F6"] = "F6", ["KEY_F7"] = "F7", ["KEY_F8"] = "F8",
		["KEY_F9"] = "F9", ["KEY_F10"] = "F10", ["KEY_F11"] = "F11", ["KEY_F12"] = "F12",

		-- Special keys
		["KEY_SPACE"] = "SPACE", ["KEY_ENTER"] = "ENTER", ["KEY_TAB"] = "TAB", ["KEY_ESCAPE"] = "ESC",

		-- Modificateurs
		["KEY_LSHIFT"]     = "LSHIFT",
		["KEY_RSHIFT"]     = "RSHIFT",
		["KEY_LALT"]       = "LALT",
		["KEY_RALT"]       = "RALT",
		["KEY_LCONTROL"]   = "LCTRL",
		["KEY_RCONTROL"]   = "RCTRL",

		-- Ponctuation
		["KEY_SEMICOLON"]  = ";",
		["KEY_APOSTROPHE"] = "'",
		["KEY_BACKQUOTE"]  = "`",
		["KEY_COMMA"]      = ",",
		["KEY_PERIOD"]     = ".",
		["KEY_SLASH"]      = "/",
		["KEY_BACKSLASH"]  = "\\",
		["KEY_LBRACKET"]   = "[",
		["KEY_RBRACKET"]   = "]",
		["KEY_MINUS"]      = "-",
		["KEY_EQUAL"]      = "=",

		-- Mouse buttons
		["MOUSE_LEFT"] = "MOUSE1", ["MOUSE_RIGHT"] = "MOUSE2", ["MOUSE_MIDDLE"] = "MOUSE3",
		["MOUSE_4"] = "MOUSE4", ["MOUSE_5"] = "MOUSE5"
	}

	return displayNames[bindEnum] or bindEnum
end

-- Pré-charger les binds locaux dans data dès l'init pour que GetBindKey fonctionne immédiatement
hook.Add("InitPostEntity", "LZY::BindMenu::PreloadData", function()
	if LZY_BindMenu and LZY_BindMenu.GetLocalBinds then
		local localBinds = LZY_BindMenu.GetLocalBinds()
		if localBinds then
			data.systemBinds = localBinds.systemBinds or {}
			data.combatBinds = localBinds.combatBinds or {}
			data.gmodBinds = localBinds.gmodBinds or {}
		end
	end
end)

net.Receive("LZY:BindMenu:UpdateBinds", function()
	-- Le serveur n'écrit que DEUX tables (sv_main.lua) : l'ancien 3e ReadTable
	-- (gmodBinds) lisait au-delà du message.
	data.systemBinds = net.ReadTable() or {}
	data.combatBinds = net.ReadTable() or {}
	-- Resynchronise AUSSI le stockage fichier de cl_main : ce handler écrasait son
	-- homonyme de cl_main (un seul net.Receive par message), donc l'écho serveur
	-- n'était plus jamais persisté sur disque.
	if LZY_BindMenu and LZY_BindMenu.GetLocalBinds then
		local lb = LZY_BindMenu.GetLocalBinds()
		if lb then
			lb.systemBinds = data.systemBinds
			lb.combatBinds = data.combatBinds
			if LZY_BindMenu.SaveLocalBinds then LZY_BindMenu.SaveLocalBinds() end
		end
	end
end)

net.Receive("LZY:DisableBindKeys", function()
	local disable = net.ReadBool()
	bindsDisabled = disable
end)
