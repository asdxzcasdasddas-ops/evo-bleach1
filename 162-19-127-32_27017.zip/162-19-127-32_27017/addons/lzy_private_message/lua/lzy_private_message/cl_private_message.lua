-- "addons\\lzy_private_message\\lua\\lzy_private_message\\cl_private_message.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ============================================================================
-- PAPILLON DE L'ENFER — REFONTE VISUELLE (DA Atelier 07/07) : plus de chrome
-- PNG (papillon.png en carte, fermer/envoyer_*.png en boutons). Plaque métal
-- noir #0E0E11 à coins coupés + liseré acier + 4 vis d'angle, titre Bebas avec
-- entaille slash1 + filet denté, ✕ standard, champs sombres soulignés, bouton
-- d'action accent #cf444e (coin bas-droit coupé, jamais de liseré dessus).
-- Le papillon reste en TRAME FANTÔME dans la carte (simple décor, alpha 6).
-- Tout le FONCTIONNEL est inchangé : mêmes net messages (LZY_PM_ToggleMenu /
-- LZY_PM_Send / LZY_PM_Receive), mêmes timers/hooks (papillon 3D, message en
-- attente, bind E, drag custom), mêmes sons et notifications chat.
-- ============================================================================

-- ── Fontes DA Atelier : Bebas (SANS bold) pour l'affichage, Avenir pour la
-- saisie et le ✕ — strings glibs globales (remplacent les CreateFont
-- Arial/Gilroy locaux ; plus rien à créer au Initialize).
local F_TITLE = "Bebas Neue:30"                -- titre du bandeau
local F_LABEL = "Bebas Neue:18"                -- intitulés de section / compteur / rangées
local F_BTN   = "Bebas Neue:22"                -- libellés ENVOYER / FERMER + lettre E
local F_X     = "Avenir Next World Bold:26"    -- ✕ (croix standard DA)
local F_INPUT = "Avenir Next World:18"         -- champs texte + placeholders

local function SetPrivateMessageMenuOpen(open)
    net.Start("LZY_PM_ToggleMenu")
        net.WriteBool(open == true)
    net.SendToServer()
end

-- ── Palette DA Atelier (module-locale : rien de réalloué par frame) ──
local COL_CARD        = Color(13, 14, 17, 250)     -- plaque métal noir
local COL_EDGE        = Color(146, 152, 161, 33)   -- liseré acier 1px
local COL_TXT         = Color(237, 238, 242, 255)  -- texte principal
local COL_MUTED       = Color(150, 154, 162, 255)  -- texte secondaire / ✕ au repos
local COL_DIM         = Color(108, 111, 120, 255)  -- texte éteint (labels, bouton non prêt)
local COL_ACCENT      = Color(207, 68, 78, 255)    -- #cf444e (accent unique)
local COL_ACCENT_HOV  = Color(224, 92, 102, 255)   -- accent éclairci (survol bouton prêt)
local COL_ACCENT_ON   = Color(207, 68, 78, 230)    -- aplat du bouton prêt (repos)
local COL_PLATE       = Color(17, 18, 22, 205)     -- mini-plaque (rangée / bouton éteint)
local COL_PLATE_HOV   = Color(24, 25, 30, 235)     -- mini-plaque survolée
local COL_FIELD       = Color(17, 18, 22, 235)     -- fond plat des champs texte
local COL_LINE        = Color(255, 255, 255, 22)   -- soulignement champ au repos
local COL_DASH        = Color(255, 255, 255, 26)   -- filet denté sous le bandeau
local COL_PLACEHOLDER = Color(255, 255, 255, 64)   -- placeholder des champs
local COL_GHOST       = Color(255, 255, 255, 6)    -- trame fantôme du papillon
local COL_DROP        = Color(8, 8, 10, 252)       -- fond de la liste déroulante
local COL_SCROLL      = Color(58, 58, 68, 220)     -- grip d'ascenseur discret
local COL_HINT_BG     = Color(13, 14, 17, 220)     -- pastille [E] au-dessus de l'épaule

-- ── Helpers de dessin DA Atelier (copies par fichier, mêmes recettes que
-- échap/squad/clan/forge) ──
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end
-- Couleurs des vis HOISTÉES (0 alloc Color par frame — règle perf projet ; elles
-- étaient recréées 3× par vis × 4 vis à chaque frame de Paint).
local COL_SCREW_RIM  = Color(0, 0, 0, 155)
local COL_SCREW_BODY = Color(23, 25, 29, 255)
local COL_SCREW_CORE = Color(51, 55, 61, 255)
local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, COL_SCREW_RIM)
	drawCircle(cx, cy, r, COL_SCREW_BODY)
	drawCircle(cx, cy, r * 0.62, COL_SCREW_CORE)
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end
local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = 6, 5
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

-- Papillon de l'enfer (ancienne carte PNG) : gardé en simple décor fantôme
-- dans la plaque — il n'est PLUS le chrome structurel de la fenêtre.
local MAT_BG = Material("materials/papillon.png", "smooth")

-- Carte DA commune aux deux fenêtres (composer / lire) : plaque à coins
-- coupés + liseré, trame papillon, 4 vis, titre Bebas + entaille + filet.
local function PaintPMCard(w, h, sTitle)
    if EVO_UI and EVO_UI.PaintCut then
        -- DA dashboard 08/07 : plus de liseré acier (plaque plate).
        EVO_UI.PaintCut(0, 0, w, h, COL_CARD, gRespY(16))
    else
        surface.SetDrawColor(COL_CARD)
        surface.DrawRect(0, 0, w, h)
    end

    -- Trame fantôme : rect droit en retrait (inset > coupe), alpha très bas.
    if not MAT_BG:IsError() then
        local ins = gRespY(22)
        surface.SetDrawColor(COL_GHOST)
        surface.SetMaterial(MAT_BG)
        surface.DrawTexturedRect(ins, ins, w - ins * 2, h - ins * 2)
    end

    -- 4 vis d'angle — DA dashboard 08/07 : alignées 18px sur les 2 axes.
    local sr = gRespY(5)
    drawScrew(gRespX(18), gRespY(18), sr)
    drawScrew(w - gRespX(18), gRespY(18), sr)
    drawScrew(w - gRespX(18), h - gRespY(18), sr)
    drawScrew(gRespX(18), h - gRespY(18), sr)

    -- Titre Bebas SANS bold + entaille slash1 (fallback barre accent).
    draw.SimpleText(sTitle, F_TITLE, gRespX(24), gRespY(30), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    surface.SetFont(F_TITLE)
    local twT, thT = surface.GetTextSize(sTitle)
    -- Distance titre->slash = 78% de la hauteur mesurée du titre (réf. BOUTIQUE).
    -- Titre CENTER-aligné à Y=gRespY(30) -> haut = gRespY(30) - thT/2 -> slashY = gRespY(30) + thT*0.28.
    if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(22), gRespY(30) + thT * 0.28, twT * 1.15, gRespY(9), ColorAlpha(COL_ACCENT, 245))) then
        surface.SetDrawColor(COL_ACCENT)
        surface.DrawRect(gRespX(24), gRespY(30) + thT * 0.34, twT, math.max(2, gRespY(3)))
    end
    drawDashes(gRespX(24), gRespY(58), w - gRespX(48), COL_DASH)
end

-- Champ texte DA : case sombre plate + soulignement 2px (accent quand actif).
local function PaintPMField(entry, w, h, sPlaceholder)
    surface.SetDrawColor(COL_FIELD)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(entry:HasFocus() and COL_ACCENT or COL_LINE)
    surface.DrawRect(0, h - 2, w, 2)
    entry:DrawTextEntryText(COL_TXT, COL_ACCENT, COL_TXT)
    if sPlaceholder and entry:GetValue() == "" and not entry:HasFocus() then
        draw.SimpleText(sPlaceholder, entry:GetFont(), gRespX(8), h / 2, COL_PLACEHOLDER, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

-- ✕ standard DA du bandeau (gris -> accent au survol, sans fond) : remplace
-- fermer.png. Ferme le frame (OnClose fait déjà tout le ménage réseau).
local function MakePMClose(frame)
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetSize(gRespX(34), gRespX(34))
    closeBtn:SetPos(frame:GetWide() - gRespX(50), gRespY(12))
    closeBtn:SetText("")
    closeBtn:SetCursor("hand")
    closeBtn.Paint = function(self, w, h)
        draw.SimpleText("✕", F_X, w / 2, h / 2, self:IsHovered() and COL_ACCENT or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    closeBtn.DoClick = function()
        frame:Close()
    end
    return closeBtn
end

-- Variable globale pour empêcher l'ouverture multiple
local LZY_PM_Frame = nil
local LZY_PM_Opening = false
local LZY_PM_OpeningTarget = nil -- { uid, name } si E pendant LZY_PM_Opening
-- File d'attente : UN papillon par conversation (unique_id), pas un seul slot global.
local LZY_PM_Pending = {}      -- [uid] = { uid, sender, name, msg }
local LZY_PM_PendingOrder = {} -- FIFO pour la touche E
-- Aligné sur PM_COOLDOWN serveur (2s) : le bouton ENVOYER reste off pendant le délai.
local LZY_PM_SEND_COOLDOWN = 2
-- Papillons anonymes REÇUS : une conversation PAR EXPÉDITEUR, en lecture seule, sous
-- un uid « ~anon:<clé> » (même préfixe que ANON_PREFIX dans sv_private_message.lua).
local function IsAnonUid(uid)
    return string.sub(tostring(uid or ""), 1, 6) == "~anon:"
end
local LZY_PM_SendCooldownUntil = 0
-- Forward decls
local EnsurePendingReceiveUI
local ClearPendingReceiveUI
local OpenPMMenu
local HasPendingReceive
local UpsertPendingReceive
local PopOldestPendingReceive
local RemovePendingReceive

local function PendingReceiveCount()
    return #LZY_PM_PendingOrder
end

HasPendingReceive = function()
    return LZY_PM_PendingOrder[1] ~= nil
end

UpsertPendingReceive = function(uid, sender, name, msg)
    if not uid or uid == "" then return false end
    local bNew = LZY_PM_Pending[uid] == nil
    LZY_PM_Pending[uid] = {
        uid = uid,
        sender = sender,
        name = name or "?",
        msg = msg or "",
    }
    if bNew then
        LZY_PM_PendingOrder[#LZY_PM_PendingOrder + 1] = uid
    end
    -- Timeout individuel 60s par conversation.
    local sTimer = "LZY_PM_Timeout_" .. uid
    if timer.Exists(sTimer) then
        timer.Adjust(sTimer, 60)
        timer.Start(sTimer)
    else
        timer.Create(sTimer, 60, 1, function()
            if not LZY_PM_Pending[uid] then return end
            RemovePendingReceive(uid)
            chat.AddText(Color(255, 255, 0), "[PM] ", Color(255, 255, 255), "Un papillon est parti, vous avez manqué un message.")
            if HasPendingReceive() then
                EnsurePendingReceiveUI()
            else
                SetPrivateMessageMenuOpen(false)
                ClearPendingReceiveUI()
            end
        end)
    end
    return bNew
end

RemovePendingReceive = function(uid)
    if not uid then return end
    LZY_PM_Pending[uid] = nil
    local sTimer = "LZY_PM_Timeout_" .. uid
    if timer.Exists(sTimer) then timer.Remove(sTimer) end
    for i = #LZY_PM_PendingOrder, 1, -1 do
        if LZY_PM_PendingOrder[i] == uid then
            table.remove(LZY_PM_PendingOrder, i)
        end
    end
end

PopOldestPendingReceive = function()
    while LZY_PM_PendingOrder[1] do
        local uid = LZY_PM_PendingOrder[1]
        local pending = LZY_PM_Pending[uid]
        table.remove(LZY_PM_PendingOrder, 1)
        if pending then
            LZY_PM_Pending[uid] = nil
            local sTimer = "LZY_PM_Timeout_" .. uid
            if timer.Exists(sTimer) then timer.Remove(sTimer) end
            return pending
        end
    end
    return nil
end


-- Nom RP du personnage (fallback Steam si vide)
local function rpName(p)
    return IsValid(p) and (p:GetEvoNWString("Nickname", "") ~= "" and p:GetEvoNWString("Nickname") or p:Nick()) or "?"
end

local function FormatPMDate(ts)
    ts = tonumber(ts) or 0
    if ts <= 0 then return "--/--/---- --:--" end
    return os.date("%d/%m/%Y %H:%M", ts)
end

local function StylePMScroll(panel)
    local vbar = panel:GetVBar()
    if not IsValid(vbar) then return end
    vbar:SetHideButtons(true)
    vbar:SetWide(math.max(3, gRespX(5)))
    vbar.Paint = function() end
    vbar.btnGrip.Paint = function(s, gw, gh)
        surface.SetDrawColor(s:IsHovered() and COL_ACCENT or COL_SCROLL)
        surface.DrawRect(0, 0, gw, gh)
    end
end

local function FindPlayerByUniqueID(uid)
    if not uid or uid == "" or uid == "none" then return nil end
    uid = tostring(uid)
    for _, v in player.Iterator() do
        if IsValid(v) and not v:IsBot() and v.GetUniqueID and tostring(v:GetUniqueID()) == uid then
            return v
        end
    end
    return nil
end

local function PlayerUniqueID(p)
    if not IsValid(p) or not p.GetUniqueID then return nil end
    local uid = tostring(p:GetUniqueID() or "")
    if uid == "" or uid == "none" then return nil end
    return uid
end

local function PreviewPMText(s, nMax)
    s = tostring(s or "")
    s = string.gsub(s, "[\r\n]+", " ")
    if #s > nMax then
        return string.sub(s, 1, nMax - 1) .. "…"
    end
    return s
end

-- Retourne le texte wrappé (\n) + hauteur totale pour un max width donné.
local function WrapPMBody(sText, sFont, nMaxW)
    sText = tostring(sText or "")
    sText = string.gsub(sText, "\r\n", "\n")
    surface.SetFont(sFont)
    local _, nLineH = surface.GetTextSize("Ay")
    nLineH = math.max(nLineH, 1)
    nMaxW = math.max(nMaxW or 0, 1)

    local tLines = {}
    for sParagraph in string.gmatch(sText .. "\n", "(.-)\n") do
        if sParagraph == "" then
            tLines[#tLines + 1] = ""
        else
            local sCur = ""
            for sWord in string.gmatch(sParagraph, "%S+") do
                local sTry = (sCur == "") and sWord or (sCur .. " " .. sWord)
                if surface.GetTextSize(sTry) <= nMaxW then
                    sCur = sTry
                else
                    if sCur ~= "" then
                        tLines[#tLines + 1] = sCur
                    end
                    -- Mot plus large que la ligne : coupe dure.
                    if surface.GetTextSize(sWord) <= nMaxW then
                        sCur = sWord
                    else
                        local sChunk = ""
                        for i = 1, #sWord do
                            local sNext = sChunk .. string.sub(sWord, i, i)
                            if sChunk ~= "" and surface.GetTextSize(sNext) > nMaxW then
                                tLines[#tLines + 1] = sChunk
                                sChunk = string.sub(sWord, i, i)
                            else
                                sChunk = sNext
                            end
                        end
                        sCur = sChunk
                    end
                end
            end
            if sCur ~= "" then
                tLines[#tLines + 1] = sCur
            end
        end
    end

    if #tLines == 0 then tLines[1] = "" end
    return table.concat(tLines, "\n"), #tLines * nLineH, nLineH
end

OpenPMMenu = function(toUid, toName)
    -- Déjà ouvert : bascule juste sur la conversation demandée (E / notif).
    if IsValid(LZY_PM_Frame) then
        if toUid and LZY_PM_Frame.SelectConversation then
            LZY_PM_Frame.SelectConversation(toUid, toName)
        end
        return
    end
    if LZY_PM_Opening then
        LZY_PM_OpeningTarget = { uid = toUid, name = toName }
        return
    end

    -- Informer le serveur d'afficher le papillon
    net.Start("LZY_PM_ToggleMenu")
    net.WriteBool(true)
    net.SendToServer()
    
    LZY_PM_Opening = true
    local openTarget = (toUid and { uid = toUid, name = toName }) or LZY_PM_OpeningTarget
    LZY_PM_OpeningTarget = nil

    -- L'UI d'envoi spawn QUASI INSTANTANÉMENT (0.1s) au lieu d'attendre le papillon
    -- (ancien 3s -> 0.8 -> 0.1, user 2026-07-26 « ça doit spawn directement »). Le
    -- papillon vole en parallèle, purement décoratif -> plus de temps mort.
    timer.Simple(0.1, function()
        LZY_PM_Opening = false

        local frame = vgui.Create("DFrame")
        LZY_PM_Frame = frame -- Sauvegarder la référence
        frame:SetSize(gRespX(920), gRespY(600))
        frame:Center()
        frame:SetTitle("")
        frame:MakePopup()
        if EVO_MakeEscClosable then EVO_MakeEscClosable(frame) end
        frame:ShowCloseButton(false)

        frame.PM_Conversations = {}
        frame.PM_SelectedUid = nil -- nil = mode Nouveau (unique_id personnage)
        frame.PM_SelectedName = nil
        frame.PM_Thread = {}

        -- Custom Dragging
        frame:SetDraggable(false)
        local dragging = false
        local dragX, dragY
        
        frame.OnMousePressed = function(self, code)
            if code == MOUSE_LEFT then
                dragging = true
                dragX, dragY = self:CursorPos()
                self:MouseCapture(true)
            end
        end
        
        frame.OnMouseReleased = function(self, code)
            dragging = false
            self:MouseCapture(false)
        end
        
        frame.Think = function(self)
            if dragging then
                local mx, my = gui.MousePos()
                self:SetPos(mx - dragX, my - dragY)
            end
        end

        local leftW = gRespX(280)
        local pad = gRespX(24)
        local rightX = leftW + gRespX(16)
        local rightW = frame:GetWide() - rightX - pad

        frame.Paint = function(self, w, h)
            PaintPMCard(w, h, "MESSAGE PRIVÉ")
            -- Séparateur vertical liste / conversation
            surface.SetDrawColor(COL_DASH)
            surface.DrawRect(leftW, gRespY(70), 1, h - gRespY(94))
            draw.SimpleText("CONVERSATIONS", F_LABEL, pad, gRespY(78), COL_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        -- ✕ standard DA dans le bandeau (remplace fermer.png)
        MakePMClose(frame)

        frame.OnClose = function()
            LZY_PM_Frame = nil
            -- Papillons d'autres conversations encore en attente : garder le papillon + [E].
            if HasPendingReceive() then
                SetPrivateMessageMenuOpen(true)
                EnsurePendingReceiveUI()
            else
                SetPrivateMessageMenuOpen(false)
            end
        end

        -- ── Gauche : Nouveau + liste ──────────────────────────────────────
        local newBtn = vgui.Create("DButton", frame)
        newBtn:SetSize(leftW - pad * 2, gRespY(34))
        newBtn:SetPos(pad, gRespY(100))
        newBtn:SetText("")
        newBtn:SetCursor("hand")
        newBtn.Paint = function(self, w, h)
            local hov = self:IsHovered() or frame.PM_SelectedUid == nil
            local colBtn = hov and COL_ACCENT_ON or COL_PLATE
            if EVO_UI and EVO_UI.PaintCut then
                EVO_UI.PaintCut(0, 0, w, h, colBtn, 6, "br")
            else
                surface.SetDrawColor(colBtn)
                surface.DrawRect(0, 0, w, h)
            end
            draw.SimpleText("NOUVEAU", F_LABEL, w / 2, h / 2, hov and color_white or COL_MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local convScroll = vgui.Create("DScrollPanel", frame)
        convScroll:SetPos(pad, gRespY(142))
        convScroll:SetSize(leftW - pad * 2, frame:GetTall() - gRespY(166))
        StylePMScroll(convScroll)

        -- ── Droite : en-tête + fil + compose ─────────────────────────────
        local headerLabel = vgui.Create("DLabel", frame)
        headerLabel:SetFont(F_TITLE)
        headerLabel:SetTextColor(COL_TXT)
        headerLabel:SetText("NOUVEAU MESSAGE")
        headerLabel:SetPos(rightX, gRespY(78))
        headerLabel:SetSize(rightW, gRespY(28))

        local threadScroll = vgui.Create("DScrollPanel", frame)
        threadScroll:SetPos(rightX, gRespY(112))
        threadScroll:SetSize(rightW, gRespY(250))
        StylePMScroll(threadScroll)

        local selectedPlayer = nil
        local UpdateSendButton
        local RefreshConversationList
        local RefreshThreadView
        local EnterNouveauMode
        local SelectConversation

        local destLabel = vgui.Create("DLabel", frame)
        destLabel:SetFont(F_LABEL)
        destLabel:SetTextColor(COL_DIM)
        destLabel:SetText("DESTINATAIRE")
        destLabel:SetPos(rightX, gRespY(368))
        destLabel:SizeToContents()

        local playerSearch = vgui.Create("DTextEntry", frame)
        playerSearch:SetSize(rightW, gRespY(34))
        playerSearch:SetPos(rightX, gRespY(388))
        playerSearch:SetFont(F_INPUT)
        playerSearch:SetTextColor(COL_TXT)
        playerSearch:SetDrawBackground(false)
        playerSearch:SetDrawLanguageID(false)
        playerSearch.Paint = function(self, w, h)
            PaintPMField(self, w, h, "Sélectionner un joueur...")
        end

        local msgLabel = vgui.Create("DLabel", frame)
        msgLabel:SetFont(F_LABEL)
        msgLabel:SetTextColor(COL_DIM)
        msgLabel:SetText("MESSAGE")
        msgLabel:SetPos(rightX, gRespY(428))
        msgLabel:SizeToContents()

        -- Case « ANONYME » (10/25) : le destinataire ne reçoit ni nom ni conversation
        -- à notre nom. Alignée à droite sur la ligne de l'intitulé MESSAGE.
        frame.PM_Anon = false
        local anonBox = vgui.Create("DButton", frame)
        anonBox:SetText("")
        anonBox:SetCursor("hand")
        anonBox:SetTooltip("Le destinataire ne saura pas qui a envoyé ce papillon.")
        surface.SetFont(F_LABEL)
        local nAnonTxtW, nAnonTxtH = surface.GetTextSize("ENVOYER ANONYMEMENT")
        local nAnonSq = math.max(nAnonTxtH - gRespY(4), gRespY(10))
        anonBox:SetSize(nAnonSq + gRespX(8) + nAnonTxtW, nAnonTxtH)
        anonBox:SetPos(rightX + rightW - anonBox:GetWide(), gRespY(428))
        anonBox.Paint = function(self, w, h)
            local bOn, hov = frame.PM_Anon == true, self:IsHovered()
            local y0 = (h - nAnonSq) / 2
            surface.SetDrawColor(COL_FIELD)
            surface.DrawRect(0, y0, nAnonSq, nAnonSq)
            surface.SetDrawColor((bOn or hov) and COL_ACCENT or COL_LINE)
            surface.DrawOutlinedRect(0, y0, nAnonSq, nAnonSq, 1)
            if bOn then
                local ins = math.max(2, math.floor(nAnonSq * 0.25))
                surface.SetDrawColor(COL_ACCENT)
                surface.DrawRect(ins, y0 + ins, nAnonSq - ins * 2, nAnonSq - ins * 2)
            end
            draw.SimpleText("ENVOYER ANONYMEMENT", F_LABEL, nAnonSq + gRespX(8), h / 2,
                bOn and COL_TXT or (hov and COL_MUTED or COL_DIM), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        anonBox.DoClick = function()
            frame.PM_Anon = not frame.PM_Anon
            surface.PlaySound("garrysmod/ui_click.wav")
        end

        local maxChars = 500
        local messageEntry = vgui.Create("DTextEntry", frame)
        messageEntry:SetSize(rightW, gRespY(72))
        messageEntry:SetPos(rightX, gRespY(448))
        messageEntry:SetFont(F_INPUT)
        messageEntry:SetMultiline(true)
        messageEntry:SetDrawBackground(false)
        messageEntry:SetDrawLanguageID(false)
        messageEntry:SetTextColor(COL_TXT)
        messageEntry.Paint = function(self, w, h)
            PaintPMField(self, w, h)
        end

        local charCount = vgui.Create("DLabel", frame)
        charCount:SetText("0/" .. maxChars)
        charCount:SetFont(F_LABEL)
        charCount:SetTextColor(COL_MUTED)
        charCount:SizeToContents()
        charCount:SetPos(rightX + rightW - charCount:GetWide(), gRespY(522))

        local resultsPanel = vgui.Create("DScrollPanel", frame)
        resultsPanel:SetSize(rightW, gRespY(120))
        resultsPanel:SetPos(rightX, gRespY(424))
        resultsPanel:SetVisible(false)
        resultsPanel.Paint = function(self, w, h)
            surface.SetDrawColor(COL_DROP)
            surface.DrawRect(0, 0, w, h)
        end
        StylePMScroll(resultsPanel)

        resultsPanel.Think = function(self)
            if self:IsVisible() and input.IsMouseDown(MOUSE_LEFT) then
                local hovered = vgui.GetHoveredPanel()
                local p = hovered
                local isSafe = false
                while IsValid(p) do
                    if p == self or p == playerSearch then
                        isSafe = true
                        break
                    end
                    p = p:GetParent()
                end
                if not isSafe then
                    self:SetVisible(false)
                end
            end
        end

        local function UpdateResults(filter)
            resultsPanel:GetCanvas():Clear()
            local count = 0
            for _, v in player.Iterator() do
                if v != LocalPlayer() and not v:IsBot() and (filter == "" or string.find(string.lower(rpName(v)), string.lower(filter), 1, true)) then
                    local btn = resultsPanel:Add("DButton")
                    local sName = rpName(v)
                    btn:SetText("")
                    btn:SetCursor("hand")
                    btn:Dock(TOP)
                    btn:DockMargin(gRespX(4), gRespY(3), gRespX(4), gRespY(1))
                    btn:SetTall(gRespY(28))
                    btn.Paint = function(s, w, h)
                        local hov = s:IsHovered()
                        if EVO_UI and EVO_UI.PaintCut then
                            EVO_UI.PaintCut(0, 0, w, h, hov and COL_PLATE_HOV or COL_PLATE, 6, "br")
                        else
                            surface.SetDrawColor(hov and COL_PLATE_HOV or COL_PLATE)
                            surface.DrawRect(0, 0, w, h)
                        end
                        if hov then
                            surface.SetDrawColor(COL_ACCENT)
                            surface.DrawRect(0, 0, 2, h)
                        end
                        draw.SimpleText(sName, F_LABEL, gRespX(12), h / 2, hov and COL_TXT or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    end
                    btn.DoClick = function()
                        if not IsValid(v) then return end
                        selectedPlayer = v
                        playerSearch:SetText(rpName(v))
                        resultsPanel:SetVisible(false)
                        if UpdateSendButton then UpdateSendButton() end
                    end
                    count = count + 1
                end
            end
            resultsPanel:SetVisible(count > 0)
            resultsPanel:MoveToFront()
        end

        playerSearch.OnGetFocus = function()
            if frame.PM_SelectedUid then return end
            UpdateResults(playerSearch:GetValue())
        end
        
        playerSearch.OnChange = function()
            if frame.PM_SelectedUid then return end
            selectedPlayer = nil
            UpdateResults(playerSearch:GetValue())
            if UpdateSendButton then UpdateSendButton() end
        end
        
        playerSearch.OnLoseFocus = function()
            timer.Simple(0.1, function() 
                local hovered = vgui.GetHoveredPanel()
                local p = hovered
                local isSafe = false
                while IsValid(p) do
                    if p == resultsPanel or p == playerSearch then
                        isSafe = true
                        break
                    end
                    p = p:GetParent()
                end
                if IsValid(resultsPanel) and not isSafe then
                    resultsPanel:SetVisible(false) 
                end
            end)
        end

        messageEntry.OnChange = function(self)
            local text = self:GetValue()
            if #text > maxChars then
                self:SetText(string.sub(text, 1, maxChars))
                self:SetCaretPos(maxChars)
                surface.PlaySound("common/talk.wav")
                text = self:GetValue()
            end
            charCount:SetText(#text .. "/" .. maxChars)
            charCount:SizeToContents()
            charCount:SetPos(rightX + rightW - charCount:GetWide(), gRespY(522))
            if UpdateSendButton then UpdateSendButton() end
        end

        local sendBtn = vgui.Create("DButton", frame)
        sendBtn:SetSize(rightW, gRespY(48))
        sendBtn:SetPos(rightX, gRespY(536))
        sendBtn:SetText("")
        sendBtn:SetCursor("hand")

        local canSend = false
        local bOnSendCooldown = false
        local bTargetOffline = false
        local bAnonThread = false

        UpdateSendButton = function()
            local text = messageEntry:GetValue()
            local targetOk = false
            bTargetOffline = false
            bAnonThread = IsAnonUid(frame.PM_SelectedUid)
            if bAnonThread then
                -- Papillons anonymes reçus : personne à qui répondre.
                targetOk = false
            elseif frame.PM_SelectedUid then
                -- Conversation existante : hors ligne si le perso n'est pas connecté.
                targetOk = FindPlayerByUniqueID(frame.PM_SelectedUid) ~= nil
                bTargetOffline = not targetOk
            else
                if selectedPlayer and IsValid(selectedPlayer) then
                    targetOk = true
                elseif selectedPlayer ~= nil then
                    -- Avait un destinataire qui a déconnecté.
                    bTargetOffline = true
                end
            end
            bOnSendCooldown = CurTime() < LZY_PM_SendCooldownUntil
            canSend = targetOk and text and text ~= "" and not bOnSendCooldown
            if IsValid(sendBtn) then
                sendBtn:SetCursor(canSend and "hand" or "arrow")
            end
        end

        sendBtn.Paint = function(self, w, h)
            local colBtn = canSend and (self:IsHovered() and COL_ACCENT_HOV or COL_ACCENT_ON) or COL_PLATE
            if EVO_UI and EVO_UI.PaintCut then
                EVO_UI.PaintCut(0, 0, w, h, colBtn, 9, "br")
            else
                surface.SetDrawColor(colBtn)
                surface.DrawRect(0, 0, w, h)
            end
            local sLabel = frame.PM_Anon and "ENVOYER ANONYMEMENT" or "ENVOYER"
            if bAnonThread then
                sLabel = "RÉPONSE IMPOSSIBLE (ANONYME)"
            elseif bTargetOffline then
                sLabel = "HORS LIGNE"
            elseif bOnSendCooldown then
                local nLeft = math.ceil(LZY_PM_SendCooldownUntil - CurTime())
                if nLeft > 0 then sLabel = tostring(nLeft) .. "s" end
            end
            draw.SimpleText(sLabel, F_BTN, w / 2, h / 2, canSend and color_white or COL_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local function TrySendMessage()
            UpdateSendButton()
            if not canSend then return end

            local target = nil
            if frame.PM_SelectedUid then
                target = FindPlayerByUniqueID(frame.PM_SelectedUid)
            else
                target = selectedPlayer
            end

            -- Nouvelle conversation : il faut un joueur present. Un FIL existant,
            -- lui, part par uid meme sans joueur ici (relais inter-serveur).
            if not IsValid(target) and not frame.PM_SelectedUid then
                chat.AddText(Color(255, 0, 0), "[PM] ", Color(255, 255, 255), "Le joueur a quitt\195\169 le serveur.")
                return
            end

            local text = messageEntry:GetValue()
            -- Entrée seule envoie : retirer un éventuel \n final collé par le TextEntry.
            text = string.gsub(text, "[\r\n]+$", "")
            if text == "" then return end

            -- Cooldown client = serveur : bloque ENVOYER / Entrée pendant 2s.
            LZY_PM_SendCooldownUntil = CurTime() + LZY_PM_SEND_COOLDOWN

            if IsValid(target) then
                net.Start("LZY_PM_Send")
                    net.WriteEntity(target)
                    net.WriteString(text)
                    net.WriteBool(frame.PM_Anon == true)
                net.SendToServer()
            else
                net.Start("LZY_PM_SendByUid")
                    net.WriteString(frame.PM_SelectedUid)
                    net.WriteString(text)
                    net.WriteBool(frame.PM_Anon == true)
                net.SendToServer()
            end

            messageEntry:SetText("")
            if IsValid(playerSearch) then playerSearch:KillFocus() end
            charCount:SetText("0/" .. maxChars)
            charCount:SizeToContents()
            charCount:SetPos(rightX + rightW - charCount:GetWide(), gRespY(522))
            UpdateSendButton()
        end

        sendBtn.DoClick = TrySendMessage

        -- Entrée = envoyer ; Shift+Entrée = nouvelle ligne (champ multiligne).
        messageEntry.OnKeyCodeTyped = function(self, code)
            if code == KEY_ENTER or code == KEY_PAD_ENTER then
                if input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT) then
                    return
                end
                TrySendMessage()
                return true
            end
        end

        -- Refresh cooldown label / réactivation du bouton chaque frame.
        local fnThinkDrag = frame.Think
        frame.Think = function(self)
            if fnThinkDrag then fnThinkDrag(self) end
            UpdateSendButton()
        end
        local function ScrollThreadToBottom()
            if not IsValid(threadScroll) then return end
            -- Les hauteurs wrappées se stabilisent sur 1–2 frames : on recolle plusieurs fois.
            local function stick()
                if not IsValid(threadScroll) then return end
                threadScroll:InvalidateLayout(true)
                local canvas = threadScroll:GetCanvas()
                if IsValid(canvas) then canvas:InvalidateLayout(true) end
                local vbar = threadScroll:GetVBar()
                if not IsValid(vbar) then return end
                vbar:InvalidateLayout(true)
                local nMax = vbar.CanvasSize or 0
                if nMax < 0 then nMax = 0 end
                vbar:SetScroll(nMax)
            end
            stick()
            timer.Simple(0, stick)
            timer.Simple(0.05, stick)
            timer.Simple(0.15, stick)
        end

        RefreshThreadView = function()
            if not IsValid(threadScroll) then return end
            threadScroll:GetCanvas():Clear()

            local rows = frame.PM_Thread or {}
            if #rows == 0 then
                local empty = threadScroll:Add("DLabel")
                empty:SetText(frame.PM_SelectedUid and "Aucun message dans cette conversation." or "Choisissez un destinataire ou une conversation.")
                empty:SetFont(F_INPUT)
                empty:SetTextColor(COL_MUTED)
                empty:Dock(TOP)
                empty:DockMargin(gRespX(4), gRespY(8), gRespX(4), 0)
                empty:SetWrap(true)
                empty:SetAutoStretchVertical(true)
                return
            end

            for _, msg in ipairs(rows) do
                local row = threadScroll:Add("DPanel")
                row:Dock(TOP)
                row:DockMargin(0, 0, 0, gRespY(6))

                local dir = msg.sent and (msg.anon and "ENVOYÉ · ANONYME" or "ENVOYÉ") or "REÇU"
                local when = FormatPMDate(msg.created_at)
                local bodyRaw = tostring(msg.message or "")
                local nPadX = gRespX(12)
                local nHeadY = gRespY(8)
                local nBodyY = gRespY(34)
                local nPadBot = gRespY(10)

                -- Largeur utile ≈ panel thread (évite crop) ; recalculée au layout.
                local nBodyW = math.max(threadScroll:GetWide() - gRespX(24), gRespX(120))
                local sWrapped, nBodyH = WrapPMBody(bodyRaw, F_INPUT, nBodyW)
                row:SetTall(nBodyY + nBodyH + nPadBot)

                row.PerformLayout = function(self, w, h)
                    local nW = math.max(w - nPadX * 2, gRespX(80))
                    local sWrap, nH = WrapPMBody(bodyRaw, F_INPUT, nW)
                    self._pmWrapped = sWrap
                    local nNeed = nBodyY + nH + nPadBot
                    if self:GetTall() ~= nNeed then
                        self:SetTall(nNeed)
                    end
                end

                row.Paint = function(s, w, h)
                    if EVO_UI and EVO_UI.PaintCut then
                        EVO_UI.PaintCut(0, 0, w, h, COL_PLATE, 6, "br")
                    else
                        surface.SetDrawColor(COL_PLATE)
                        surface.DrawRect(0, 0, w, h)
                    end
                    surface.SetDrawColor(msg.sent and COL_ACCENT or COL_MUTED)
                    surface.DrawRect(0, 0, 2, h)
                    draw.SimpleText(dir, F_LABEL, nPadX, nHeadY, msg.sent and COL_ACCENT or COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText(when, F_LABEL, w - gRespX(10), nHeadY, COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                    draw.DrawText(s._pmWrapped or sWrapped, F_INPUT, nPadX, nBodyY, COL_TXT, TEXT_ALIGN_LEFT)
                end
            end

            -- Toujours collé en bas (dernier message) à l'ouverture / refresh du fil.
            ScrollThreadToBottom()
        end

        RefreshConversationList = function()
            if not IsValid(convScroll) then return end
            convScroll:GetCanvas():Clear()

            for _, conv in ipairs(frame.PM_Conversations or {}) do
                local btn = convScroll:Add("DButton")
                btn:SetText("")
                btn:SetCursor("hand")
                btn:Dock(TOP)
                btn:DockMargin(0, 0, 0, gRespY(4))
                btn:SetTall(gRespY(56))

                local uid = conv.uid
                local name = conv.name
                local preview = PreviewPMText((conv.sent and conv.anon and "(anonyme) " or "") .. tostring(conv.preview or ""), 42)
                local when = FormatPMDate(conv.created_at)
                local selected = frame.PM_SelectedUid == uid

                btn.Paint = function(s, w, h)
                    local hov = s:IsHovered() or selected
                    if EVO_UI and EVO_UI.PaintCut then
                        EVO_UI.PaintCut(0, 0, w, h, hov and COL_PLATE_HOV or COL_PLATE, 6, "br")
                    else
                        surface.SetDrawColor(hov and COL_PLATE_HOV or COL_PLATE)
                        surface.DrawRect(0, 0, w, h)
                    end
                    if hov then
                        surface.SetDrawColor(COL_ACCENT)
                        surface.DrawRect(0, 0, 2, h)
                    end
                    draw.SimpleText(name, F_LABEL, gRespX(10), gRespY(8), COL_TXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText(when, F_LABEL, w - gRespX(8), gRespY(8), COL_DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                    draw.SimpleText(preview, F_INPUT, gRespX(10), gRespY(30), COL_MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end

                btn.DoClick = function()
                    SelectConversation(uid, name)
                end
            end
        end

        EnterNouveauMode = function()
            frame.PM_SelectedUid = nil
            frame.PM_SelectedName = nil
            frame.PM_Thread = {}
            selectedPlayer = nil
            headerLabel:SetText("NOUVEAU MESSAGE")
            destLabel:SetVisible(true)
            playerSearch:SetVisible(true)
            playerSearch:SetEditable(true)
            playerSearch:SetText("")
            anonBox:SetVisible(true)
            messageEntry:SetEnabled(true)
            threadScroll:SetTall(gRespY(250))
            RefreshThreadView()
            RefreshConversationList()
            UpdateSendButton()
        end

        SelectConversation = function(uid, name)
            frame.PM_SelectedUid = uid
            frame.PM_SelectedName = name or "?"
            selectedPlayer = FindPlayerByUniqueID(uid)
            headerLabel:SetText(string.upper(frame.PM_SelectedName))
            destLabel:SetVisible(false)
            playerSearch:SetVisible(false)
            resultsPanel:SetVisible(false)
            -- Plus de champ destinataire : le fil gagne la place.
            threadScroll:SetTall(gRespY(310))
            -- Fil des anonymes reçus : lecture seule (ni case anonyme ni saisie).
            local bAnonConv = IsAnonUid(uid)
            anonBox:SetVisible(not bAnonConv)
            messageEntry:SetEnabled(not bAnonConv)
            RefreshConversationList()

            -- Ouvrir la conversation consomme le papillon pending de ce contact.
            if uid and LZY_PM_Pending[uid] then
                RemovePendingReceive(uid)
                if HasPendingReceive() then
                    EnsurePendingReceiveUI()
                else
                    ClearPendingReceiveUI()
                end
            end

            net.Start("LZY_PM_HistoryThread")
                net.WriteString(uid)
            net.SendToServer()
            UpdateSendButton()
        end

        newBtn.DoClick = function()
            EnterNouveauMode()
        end

        -- Hooks frame pour les net.Receive (menu ouvert)
        frame.ApplyHistoryList = function(self, list)
            self.PM_Conversations = list or {}
            RefreshConversationList()
        end

        frame.ApplyHistoryThread = function(self, otherUid, rows)
            if self.PM_SelectedUid ~= otherUid then return end
            rows = rows or {}
            -- Chronologique : le nom récent est en fin de fil.
            local nameSrc = rows[#rows] or rows[1]
            if nameSrc and nameSrc.other_name and nameSrc.other_name ~= "" then
                self.PM_SelectedName = nameSrc.other_name
                headerLabel:SetText(string.upper(self.PM_SelectedName))
            end
            self.PM_Thread = rows
            RefreshThreadView()
        end

        frame.ApplySendAck = function(self, targetUid, targetName, message, createdAt, bAnon)
            -- Upsert conversation en tête
            local list = self.PM_Conversations or {}
            for i = #list, 1, -1 do
                if list[i].uid == targetUid then
                    table.remove(list, i)
                end
            end
            table.insert(list, 1, {
                uid = targetUid,
                name = targetName,
                preview = message,
                created_at = createdAt,
                sent = true,
                anon = bAnon,
            })
            self.PM_Conversations = list

            if self.PM_SelectedUid == nil then
                -- Après un nouveau message : bascule sur la conversation
                SelectConversation(targetUid, targetName)
                -- Prefill thread immédiatement (le fetch serveur suivra)
                self.PM_Thread = {
                    { sent = true, message = message, created_at = createdAt, other_name = targetName, anon = bAnon }
                }
                RefreshThreadView()
            elseif self.PM_SelectedUid == targetUid then
                table.insert(self.PM_Thread, {
                    sent = true,
                    message = message,
                    created_at = createdAt,
                    other_name = targetName,
                    anon = bAnon,
                })
                RefreshThreadView()
            end
            RefreshConversationList()
        end

        frame.SelectConversation = SelectConversation

        if openTarget and openTarget.uid then
            SelectConversation(openTarget.uid, openTarget.name)
        else
            EnterNouveauMode()
        end

        net.Start("LZY_PM_HistoryList")
        net.SendToServer()
    end)
end

concommand.Add("lzy_pm", OpenPMMenu)

hook.Add("PlayerButtonDown", "LZY_PM_BindKey", function(ply, button)
	if not IsValid(ply) or ply ~= LocalPlayer() then return end
	-- Menu/console/curseur visibles : la touche sert à écrire/naviguer, pas à ouvrir le
	-- menu MP (pattern standard des binds du projet, cf. cl_aerial_combat).
	if gui.IsGameUIVisible() or gui.IsConsoleVisible() then return end
	if vgui.CursorVisible() then return end
	if button == ply:GetBindKey("private_message") then
		OpenPMMenu()
	end
end)

-- Chat Command
hook.Add("OnPlayerChat", "LZY_PM_ChatCommand", function(ply, text)
    if ply == LocalPlayer() and (string.lower(text) == "!pm" or string.lower(text) == "/pm") then
        OpenPMMenu()
        return true -- Hide the command from chat
    end
end)

net.Receive("LZY_PM_HistoryList", function()
    local n = net.ReadUInt(8)
    local list = {}
    for i = 1, n do
        list[i] = {
            uid = net.ReadString(),
            name = net.ReadString(),
            preview = net.ReadString(),
            created_at = net.ReadUInt(32),
            sent = net.ReadBool(),
            anon = net.ReadBool(),
        }
    end
    if IsValid(LZY_PM_Frame) and LZY_PM_Frame.ApplyHistoryList then
        LZY_PM_Frame:ApplyHistoryList(list)
    end
end)

net.Receive("LZY_PM_HistoryThread", function()
    local otherUid = net.ReadString()
    local n = net.ReadUInt(8)
    local rows = {}
    for i = 1, n do
        rows[i] = {
            sent = net.ReadBool(),
            message = net.ReadString(),
            created_at = net.ReadUInt(32),
            other_name = net.ReadString(),
            anon = net.ReadBool(),
        }
    end
    if IsValid(LZY_PM_Frame) and LZY_PM_Frame.ApplyHistoryThread then
        LZY_PM_Frame:ApplyHistoryThread(otherUid, rows)
    end
end)

net.Receive("LZY_PM_SendAck", function()
    local targetUid = net.ReadString()
    local targetName = net.ReadString()
    local message = net.ReadString()
    local createdAt = net.ReadUInt(32)
    local bAnon = net.ReadBool()
    if IsValid(LZY_PM_Frame) and LZY_PM_Frame.ApplySendAck then
        LZY_PM_Frame:ApplySendAck(targetUid, targetName, message, createdAt, bAnon)
    end
end)

-- Hint [E] + timeouts : un papillon (slot) par conversation en attente.
local HINT_OFFSET = Vector(5, -15, 60) -- hoisté : pas d'alloc Vector par frame

ClearPendingReceiveUI = function()
    if timer.Exists("LZY_PM_Arrival") then timer.Remove("LZY_PM_Arrival") end
    hook.Remove("PlayerBindPress", "LZY_PM_OpenMessage")
    hook.Remove("HUDPaint", "LZY_PM_DrawInteraction")
end

EnsurePendingReceiveUI = function()
    if not HasPendingReceive() then
        ClearPendingReceiveUI()
        return
    end

    hook.Add("HUDPaint", "LZY_PM_DrawInteraction", function()
        if not HasPendingReceive() then return end
        -- Pas de pastille [E] tant que l'UI est ouverte.
        if IsValid(LZY_PM_Frame) or LZY_PM_Opening then return end

        local ply = LocalPlayer()
        local pos = ply:LocalToWorld(HINT_OFFSET)
        local scr = pos:ToScreen()

        if scr.visible then
            local x, y = scr.x, scr.y
            local size = gRespX(25)
            local nCount = PendingReceiveCount()

            drawCircle(x, y, size / 2 + 1, COL_HINT_BG)
            surface.DrawCircle(x, y, size / 2, COL_ACCENT)
            draw.SimpleText("E", F_BTN, x, y, COL_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if nCount > 1 then
                draw.SimpleText("×" .. nCount, F_LABEL, x + size * 0.7, y - size * 0.35, COL_ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        end
    end)

    hook.Add("PlayerBindPress", "LZY_PM_OpenMessage", function(ply, bind, pressed)
        if not HasPendingReceive() or bind ~= "+use" or not pressed then return end
        if IsValid(LZY_PM_Frame) or LZY_PM_Opening then return end

        local pending = PopOldestPendingReceive()
        if not pending then return end

        if HasPendingReceive() then
            EnsurePendingReceiveUI()
        else
            ClearPendingReceiveUI()
        end

        -- Ouvre le messenger directement sur la conversation (plus de popup lecture seule).
        OpenPMMenu(pending.uid, pending.name)
        return true
    end)
end

-- Réception d'un papillon, quel que soit le trajet : direct (entité expéditeur),
-- relais inter-serveur ou anonyme (uid + nom seulement, cf. LZY_PM_ReceiveRemote).
-- sender = entité si connue ici, sinon nil.
local function OnPapillonReceived(uid, sName, msg, sender)
    if not msg or #msg == 0 then return end
    if #msg > 500 then msg = string.sub(msg, 1, 500) end
    sName = (sName and sName ~= "") and sName or "?"

    chat.AddText(Color(0, 255, 0), "[PM] ", Color(255, 255, 255), sName .. ": " .. msg)
    surface.PlaySound("buttons/blip1.wav")

    if not uid or uid == "" then return end

    local bUiBusy = IsValid(LZY_PM_Frame) or LZY_PM_Opening
    local bHadAny = HasPendingReceive()
    local bNewConv = UpsertPendingReceive(uid, sender, sName, msg)

    -- Menu messenger ouvert : rafraîchir liste (+ fil si conversation active).
    if IsValid(LZY_PM_Frame) and LZY_PM_Frame.ApplyHistoryList then
        local list = LZY_PM_Frame.PM_Conversations or {}
        for i = #list, 1, -1 do
            if list[i].uid == uid then table.remove(list, i) end
        end
        table.insert(list, 1, {
            uid = uid,
            name = sName,
            preview = msg,
            created_at = os.time(),
            sent = false,
        })
        LZY_PM_Frame:ApplyHistoryList(list)
        if LZY_PM_Frame.PM_SelectedUid == uid then
            -- Déjà en train de lire cette conversation : plus besoin du papillon pending.
            RemovePendingReceive(uid)
            local thread = LZY_PM_Frame.PM_Thread or {}
            table.insert(thread, {
                sent = false,
                message = msg,
                created_at = os.time(),
                other_name = sName,
            })
            LZY_PM_Frame:ApplyHistoryThread(uid, thread)
        end
    end

    if bUiBusy then
        if HasPendingReceive() then
            EnsurePendingReceiveUI()
            chat.AddText(Color(255, 255, 0), "[PM] ", Color(255, 255, 255), "Nouveau message en attente. Fermez le menu, puis appuyez sur 'E'.")
        end
        return
    end

    if not bNewConv then
        -- Même conversation : un seul papillon, contenu mis à jour.
        EnsurePendingReceiveUI()
        chat.AddText(Color(100, 255, 100), "[PM] ", Color(255, 255, 255), "Message mis à jour. Appuyez sur 'E'.")
        return
    end

    if bHadAny then
        -- Autre conversation : nouveau papillon en file (E×N).
        EnsurePendingReceiveUI()
        chat.AddText(Color(100, 255, 100), "[PM] ", Color(255, 255, 255),
            "Nouveau papillon de " .. sName .. " (" .. PendingReceiveCount() .. " en attente). Appuyez sur 'E'.")
        return
    end

    -- Premier papillon : arrivée visuelle.
    SetPrivateMessageMenuOpen(true)

    if timer.Exists("LZY_PM_Arrival") then timer.Remove("LZY_PM_Arrival") end

    timer.Create("LZY_PM_Arrival", 0.1, 1, function()
        if not HasPendingReceive() then return end
        EnsurePendingReceiveUI()
        if not IsValid(LZY_PM_Frame) and not LZY_PM_Opening then
            chat.AddText(Color(100, 255, 100), "[PM] ", Color(255, 255, 255), "Appuyez sur 'E' pour ouvrir la conversation.")
        end
    end)
end

net.Receive("LZY_PM_Receive", function()
    local sender = net.ReadEntity()
    local msg = net.ReadString()
    if not IsValid(sender) or not sender:IsPlayer() then return end
    OnPapillonReceived(PlayerUniqueID(sender), rpName(sender), msg, sender)
end)

-- Relais inter-serveur ET papillon anonyme : pas d'entité, l'uid (réel ou
-- « ~anon:<clé> ») et le nom affiché (« Anonyme #3F9A ») viennent du serveur.
net.Receive("LZY_PM_ReceiveRemote", function()
    local uid = net.ReadString()
    local sName = net.ReadString()
    local msg = net.ReadString()
    OnPapillonReceived(uid, sName, msg, nil)
end)


-- Gestion des papillons (Client-side)
local activeButterflies = {}
local butterflyAnims = {}

-- Papillon d'un joueur INVISIBLE (staff cloaké / NoDraw / noclip) : ne pas trahir sa
-- position (demande user 08/03). Même signal que le gate serveur (qui ne broadcast déjà
-- plus) ; ce filet client couvre le cas « il se cloake APRÈS l'arrivée du papillon ».
local function IsHiddenPly(ply)
    return IsValid(ply) and ply ~= LocalPlayer()
        and (ply:GetNoDraw() or ply:GetEvoNWBool("EVO_StaffMode", false) or ply:GetMoveType() == MOVETYPE_NOCLIP)
end

local function CreateButterfly(ply)
    if not IsValid(ply) then return end
    if IsHiddenPly(ply) then return end

    -- Gestion si le papillon existe déjà
    if IsValid(activeButterflies[ply]) then 
        local data = butterflyAnims[ply]
        -- Si il est en train de partir, on le fait revenir
        if data and data.type == "departure" then
            local butterfly = activeButterflies[ply]
            local currentPos = butterfly:GetPos()
            local startPos = currentPos
            
            -- On relance l'animation d'arrivée depuis sa position actuelle
            butterflyAnims[ply] = {
                ent = butterfly,
                -- Vitesse d'arrivée/départ du papillon. Historique : 2/3/3 -> 1/1.5/1.5
                -- (26/07) -> 0.5/0.8/0.8 (26/07, encore trop lent a l'usage).
                startPos = startPos,
                startTime = CurTime(),
                duration = 0.5, -- retour (2 -> 1 -> 0.5)
                type = "arrival",
                lifeTime = CurTime() + 60
            }
        elseif data then
            -- Si il est déjà là ou arrive, on prolonge sa durée de vie
            data.lifeTime = CurTime() + 60
        end
        -- Si il est déjà là ou arrive, on ne fait rien
        return 
    end
    
    local butterfly = ClientsideModel("models/evo/props/items/evo_krtkgo09sbce318/evo_b65s3vme02dq4l7dp.mdl")
    if not IsValid(butterfly) then return end

    -- Position de départ (Monde)
    local startPos = ply:LocalToWorld(Vector(100, 100, 150))
    
    butterfly:SetPos(startPos)
    butterfly:SetAngles(Angle(0,0,0))
    butterfly:SetNoDraw(false)
    
    -- Animation
    local seq = butterfly:LookupSequence("idle")
    if seq and seq >= 0 then
        butterfly:SetSequence(seq)
        butterfly:SetPlaybackRate(1.0)
    end
    
    activeButterflies[ply] = butterfly
    
    -- Lancer l'animation d'arrivée (3 -> 1.5 -> 0.8)
    butterflyAnims[ply] = {
        ent = butterfly,
        startPos = startPos,
        startTime = CurTime(),
        duration = 0.8,
        type = "arrival",
        lifeTime = CurTime() + 60 -- Durée de vie de 60s avant départ auto
    }
end

local function RemoveButterfly(ply)
    if IsValid(activeButterflies[ply]) then
        local butterfly = activeButterflies[ply]
        
        -- On déparente pour qu'il puisse voler librement (virtuellement, car ClientsideModel n'est pas parenté de base sauf si on le fait)
        butterfly:SetParent(nil)
        
        local currentPos = butterfly:GetPos()
        local targetPos = currentPos + Vector(0, 0, 200) + VectorRand() * 50
        
        -- Lancer l'animation de départ (3 -> 1.5 -> 0.8)
        butterflyAnims[ply] = {
            ent = butterfly,
            startPos = currentPos,
            endPos = targetPos,
            startTime = CurTime(),
            duration = 0.8,
            type = "departure"
        }
    else
        activeButterflies[ply] = nil
        butterflyAnims[ply] = nil
    end
end

hook.Add("Think", "LZY_PM_ButterflyAnim_Client", function()
    if next(butterflyAnims) == nil then return end

    local time = CurTime()
    for ply, data in pairs(butterflyAnims) do
        if not data then butterflyAnims[ply] = nil continue end
        if IsValid(data.ent) then
            -- Vérifier si le joueur est toujours valide
            if not IsValid(ply) and data.type == "arrival" then
                data.ent:Remove()
                butterflyAnims[ply] = nil
                activeButterflies[ply] = nil
                continue
            end

            -- Joueur devenu invisible (cloak/staff/noclip) papillon posé ou en vol vers lui :
            -- retrait IMMÉDIAT (une envolée depuis sa position trahirait l'emplacement).
            if data.type ~= "departure" and IsHiddenPly(ply) then
                data.ent:Remove()
                activeButterflies[ply] = nil
                butterflyAnims[ply] = nil
                continue
            end

            local elapsed = time - data.startTime
            local fraction = math.Clamp(elapsed / data.duration, 0, 1)

            -- Animation de l'idle du papillon
            data.ent:FrameAdvance(FrameTime())

            if data.type == "arrival" then
                -- Arrivée : On update la position cible (épaule du joueur) en temps réel
                local targetPos = ply:LocalToWorld(Vector(5, -15, 60))
                local currentPos = LerpVector(fraction, data.startPos, targetPos)
                
                data.ent:SetPos(currentPos)
                
                -- Orientation vers la cible
                local dir = (targetPos - currentPos):GetNormalized()
                if dir != Vector(0,0,0) then
                    data.ent:SetAngles(dir:Angle())
                end
                
                if fraction >= 1 then
                    -- Fin de l'arrivée : on parente au joueur
                    data.ent:SetParent(ply)
                    data.ent:SetLocalPos(Vector(5, -15, 60))
                    data.ent:SetLocalAngles(Angle(0, 0, 0))
                    data.type = "attached"
                end
            
            elseif data.type == "attached" then
                -- Le papillon est attaché, on continue juste l'animation idle
                -- Pas de mouvement à gérer car parenté
                
                -- Vérification du temps de vie (Timeout pour les autres joueurs)
                if CurTime() > data.lifeTime then
                    RemoveButterfly(ply)
                end
                
            elseif data.type == "departure" then
                -- Départ : On va vers un point fixe dans le monde
                local currentPos = LerpVector(fraction, data.startPos, data.endPos)
                data.ent:SetPos(currentPos)
                
                -- Orientation vers la fuite
                local dir = (data.endPos - currentPos):GetNormalized()
                if dir != Vector(0,0,0) then
                    data.ent:SetAngles(dir:Angle())
                end
                
                if fraction >= 1 then
                    data.ent:Remove()
                    activeButterflies[ply] = nil
                    butterflyAnims[ply] = nil
                end
            end
        else
            butterflyAnims[ply] = nil
        end
    end
end)

hook.Add("NotifyPlayerDisconnected", "LZY_PM_CleanupButterfly", function(ply)
    if activeButterflies[ply] then
        if IsValid(activeButterflies[ply]) then
            activeButterflies[ply]:Remove()
        end
        activeButterflies[ply] = nil
    end
    butterflyAnims[ply] = nil
end)

net.Receive("LZY_PM_ToggleMenu", function()
    local ply = net.ReadEntity()
    local isOpen = net.ReadBool()

    if not IsValid(ply) then return end

    if isOpen then
        CreateButterfly(ply)
    else
        RemoveButterfly(ply)
    end
end)



