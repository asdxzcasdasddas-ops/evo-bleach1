-- "addons\\lzy_private_message\\lua\\autorun\\lzy_private_message_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile("lzy_private_message/cl_private_message.lua")
    include("lzy_private_message/sv_private_message.lua")
    resource.AddFile("materials/fermer_rdy.png")
    resource.AddFile("materials/envoyer_nrdy.png")
    resource.AddFile("materials/envoyer_rdy.png")
    resource.AddFile("materials/fermer.png")
    resource.AddFile("materials/papillon.png")
else
    include("lzy_private_message/cl_private_message.lua")
end
