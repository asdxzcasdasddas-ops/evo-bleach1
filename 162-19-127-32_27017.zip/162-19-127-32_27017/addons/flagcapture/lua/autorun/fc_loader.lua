-- "addons\\flagcapture\\lua\\autorun\\fc_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Flag Capture - Loader

if SERVER then
    AddCSLuaFile("flagcapture/sh_config.lua")
    AddCSLuaFile("flagcapture/cl_hud.lua")
    AddCSLuaFile("flagcapture/cl_flag_render.lua")
    AddCSLuaFile("flagcapture/cl_flagmap.lua")

    include("flagcapture/sh_config.lua")
    include("flagcapture/sv_flagcapture.lua")
    include("flagcapture/sv_cross.lua")
end

if CLIENT then
    include("flagcapture/sh_config.lua")
    include("flagcapture/cl_hud.lua")
    include("flagcapture/cl_flag_render.lua")
    include("flagcapture/cl_flagmap.lua")
end