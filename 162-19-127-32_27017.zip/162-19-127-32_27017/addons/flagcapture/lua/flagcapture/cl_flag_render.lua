-- "addons\\flagcapture\\lua\\flagcapture\\cl_flag_render.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ════════════════════════════════════════════════════════════════════════════
-- Flag Capture — Render distance limit
-- Les drapeaux (prop_dynamic "soul_crystal") sont visibles partout sur la map
-- par defaut. Trop verbose visuellement quand le joueur est loin. On cap leur
-- distance d'affichage en posant un RenderOverride qui skip le draw au-dela.
-- ════════════════════════════════════════════════════════════════════════════

local FLAG_MODEL_PATH = "models/evo/Props/props_anim/evo_fa1fymh8f7kefj3/evo_6zswihfj1dnttql.mdl"
-- Comparaison en MINUSCULES des deux côtés : le littéral contient "Props" avec
-- majuscule, or GetModel() est comparé lowercasé -> l'égalité était IMPOSSIBLE
-- et ce fichier était un no-op complet (aucun cull jamais posé).
local FLAG_MODEL_LOWER = string.lower(FLAG_MODEL_PATH)
local FLAG_RENDER_DIST_SQR = 2500 * 2500 -- 2500 units = ~38m, ajustable

local function IsFlagEntity(ent)
    if not IsValid(ent) then return false end
    local mdl = ent:GetModel()
    if not mdl then return false end
    return string.lower(mdl) == FLAG_MODEL_LOWER
end

local function AttachFlagDistanceCull(ent)
    if not IsValid(ent) then return end
    if ent._fc_distCullAttached then return end
    ent._fc_distCullAttached = true

    -- On wrap le DrawModel default via RenderOverride.
    ent.RenderOverride = function()
        local lp = LocalPlayer()
        if not IsValid(lp) then return end
        if ent:GetPos():DistToSqr(lp:GetPos()) > FLAG_RENDER_DIST_SQR then
            return -- trop loin, on skip le draw
        end
        ent:DrawModel()
    end
end

-- Au spawn de chaque nouvelle entity, on check si c'est un drapeau et on
-- attache le cull. Defere d'un frame car GetModel() peut etre vide juste
-- apres OnEntityCreated (le modele arrive un poil plus tard via le snapshot).
hook.Add("OnEntityCreated", "FC:FlagDistanceCull", function(ent)
    timer.Simple(0, function()
        if IsFlagEntity(ent) then
            AttachFlagDistanceCull(ent)
        end
    end)
end)

-- Au load du file (rechargement scripts) : scanne les drapeaux deja presents
-- (chemin en minuscules : le moteur normalise les chemins de modeles).
for _, ent in ipairs(ents.FindByModel(FLAG_MODEL_LOWER)) do
    AttachFlagDistanceCull(ent)
end
