-- "addons\\flagcapture\\lua\\flagcapture\\cl_hud.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
﻿if not CLIENT then return end

FlagCapture = FlagCapture or {}
FlagCapture.Zones = {}

local CFG = FlagCapture.Config or {}
CFG.Teams = CFG.Teams or { SHINIGAMI = "Shinigami", HOLLOW = "Hollow" }

-- Polices DA EVO (Bebas Neue titres / Roboto texte) — billboard 3D au-dessus des drapeaux
surface.CreateFont("FC_DA_Name", { font = "Bebas Neue", size = 60,  weight = 800, antialias = true, extended = true })
surface.CreateFont("FC_DA_Big",  { font = "Bebas Neue", size = 110, weight = 900, antialias = true, extended = true })
surface.CreateFont("FC_DA_Text", { font = "Roboto",     size = 30,  weight = 600, antialias = true, extended = true })

-- Couleurs DA EVO (carte sombre #0E0E11, accent rouge #cf444e, sans bordure grise/blanche)
local COL_CARD      = Color(14, 14, 17, 240)
local COL_ACCENT    = Color(207, 68, 78)
local COL_WHITE     = Color(237, 238, 242)
local COL_GREY      = Color(150, 154, 162)
local COL_TRACK     = Color(38, 38, 44, 255)
local COL_SHINIGAMI = Color(80, 170, 255)
local COL_HOLLOW    = Color(207, 68, 78)

-- Icônes de faction = mêmes que l'écran de choix de faction (lzy_character)
local FC_ICON_SHINIGAMI = Material("l1acam515ehakdj3/6i05nkvlbs70099.png", "smooth")
local FC_ICON_HOLLOW    = Material("l1acam515ehakdj3/kflc5qgaqm0fcm4o9.png", "smooth")

local function FC_FactionColor(team)
    if team == "Shinigami" then return COL_SHINIGAMI end
    if team == "Hollow"    then return COL_HOLLOW end
    return COL_GREY
end

local function FC_FactionIcon(team)
    if team == "Shinigami" then return FC_ICON_SHINIGAMI end
    if team == "Hollow"    then return FC_ICON_HOLLOW end
    return nil
end

net.Receive("FC_StopGame", function()
    -- FlagCapture.StopSound() retiré : la fonction n'existe pas (PlaySound a été
    -- supprimé côté serveur) -> l'appel levait une erreur Lua qui empêchait le
    -- nettoyage des zones ci-dessous (drapeaux non effacés côté client à la
    -- fermeture / à 01h avec le scheduler horaire).
    FlagCapture.Zones = {}
end)

-- Bannière haut-centre : lancement (adverse) ou règle cassée (présents sur le point).
local FC_BANNER_FADE  = 0.25
local fc_banner_queue = {}
local fc_banner       = nil
local fc_banner_t0    = 0
local fc_banner_fonts = false

hook.Add("OnScreenSizeChanged", "FC_BannerFonts", function()
    fc_banner_fonts = false
end)

local function FC_EnsureBannerFonts()
    if fc_banner_fonts then return end
    if gCreateRespFont then
        gCreateRespFont("FC_Banner_Title", "Bebas Neue", 28, 400)
        gCreateRespFont("FC_Banner_Body",  "Roboto",     18, 500)
        gCreateRespFont("FC_Banner_Small", "Roboto",     15, 500)
    else
        local ratio = ScrH() / 1080
        surface.CreateFont("FC_Banner_Title", { font = "Bebas Neue", size = 28 * ratio, weight = 400, antialias = true, extended = true })
        surface.CreateFont("FC_Banner_Body",  { font = "Roboto",     size = 18 * ratio, weight = 500, antialias = true, extended = true })
        surface.CreateFont("FC_Banner_Small", { font = "Roboto",     size = 15 * ratio, weight = 500, antialias = true, extended = true })
    end
    fc_banner_fonts = true
end

local function FC_PushBanner(t)
    fc_banner_queue[#fc_banner_queue + 1] = t
    if not t.chat or t.chat == "" then return end
    if t.eventChat then
        if LZY_Chat_AddEventLine then
            LZY_Chat_AddEventLine(t.chat)
        elseif LZY_Chat_AddSystemLine then
            LZY_Chat_AddSystemLine("events", t.chat)
        else
            chat.AddText(Color(255, 132, 56), "[EVENT] ", Color(255, 255, 255), t.chat)
        end
        return
    end
    chat.AddText(Color(255, 220, 80), "[FLAG] ", Color(255, 255, 255), t.chat)
end

net.Receive("FC_InsufficientPlayers", function()
    local sName    = net.ReadString()
    local nCurrent = net.ReadUInt(8)
    local nNeed    = net.ReadUInt(8)
    local nPoints  = net.ReadUInt(8)
    local nMaxPts  = net.ReadUInt(8)

    local tLines = {}
    local nMax = (FlagCapture.Config and FlagCapture.Config.MaxPlayersToCapture) or nNeed
    if nCurrent < nNeed or nCurrent > nMax then
        tLines[#tLines + 1] = string.format("De %d à %d joueurs requis (3ème siège+ exclus) : %d",
            nNeed, nMax, nCurrent)
    end
    if nPoints > nMaxPts then
        tLines[#tLines + 1] = string.format("Total d'équipe trop élevé : %d/%d pts", nPoints, nMaxPts)
    end
    if #tLines == 0 then
        tLines[1] = "Composition d'équipe invalide."
    end

    FC_PushBanner({
        title  = "CAPTURE BLOQUÉE",
        name   = sName,
        team   = "",
        lines  = tLines,
        dur    = 4.5,
        chat   = sName .. " — " .. table.concat(tLines, " · "),
    })
end)

local fc_started_at = {} -- [name|team] = CurTime()

net.Receive("FC_CaptureStarted", function()
    local sName  = net.ReadString()
    local sTeam  = net.ReadString()
    local nCount = net.ReadUInt(3)
    local tRanks = {}
    for i = 1, nCount do
        tRanks[i] = net.ReadUInt(4)
    end
    local nPoints = net.ReadUInt(8)
    local sKey = tostring(sName) .. "|" .. tostring(sTeam)
    local nLast = fc_started_at[sKey]
    if nLast and CurTime() - nLast < 25 then return end
    fc_started_at[sKey] = CurTime()
    local sGrades = #tRanks > 0 and table.concat(tRanks, ", ") or "—"
    FC_PushBanner({
        title  = "CAPTURE LANCÉE",
        name   = sName,
        team   = sTeam,
        lines  = {
            "Grades : " .. sGrades,
            string.format("Total d'équipe : %d pts", nPoints or 0),
        },
        dur       = 5,
        eventChat = true,
        chat      = string.format("Capture de %s lancée par %s — grades %s (%d pts)",
            sName, sTeam, sGrades, nPoints or 0),
    })
end)

hook.Add("HUDPaint", "FC_CaptureStartedBanner", function()
    if not fc_banner and #fc_banner_queue > 0 then
        fc_banner    = table.remove(fc_banner_queue, 1)
        fc_banner_t0 = CurTime()
    end
    if not fc_banner then return end

    local nDur = fc_banner.dur or 5
    local elapsed = CurTime() - fc_banner_t0
    if elapsed >= nDur then
        fc_banner = nil
        return
    end

    local alpha = 255
    if elapsed < FC_BANNER_FADE then
        alpha = math.Round(255 * (elapsed / FC_BANNER_FADE))
    elseif elapsed > nDur - FC_BANNER_FADE then
        alpha = math.Round(255 * (1 - (elapsed - (nDur - FC_BANNER_FADE)) / FC_BANNER_FADE))
    end
    if alpha <= 0 then return end

    FC_EnsureBannerFonts()
    local a = alpha / 255
    local col = (EVO_UI and EVO_UI.Col) or {
        title = Color(238, 239, 243), muted = Color(150, 154, 162),
        dim = Color(106, 109, 118), accent = Color(207, 68, 78),
        divider = Color(255, 255, 255, 18),
    }
    local RX = gRespX or function(v) return math.floor(v * ScrW() / 1920) end
    local RY = gRespY or function(v) return math.floor(v * ScrH() / 1080) end

    local sTitle = fc_banner.title or "CAPTURE"
    local sFlag  = fc_banner.name or "Drapeau"
    local sTeam  = string.upper(fc_banner.team or "")
    local tLines = fc_banner.lines or {}

    surface.SetFont("FC_Banner_Title")
    local titleW, titleH = surface.GetTextSize(sTitle)
    surface.SetFont("FC_Banner_Small")
    local tagW, tagH = surface.GetTextSize(sTeam)
    surface.SetFont("FC_Banner_Body")
    local bodyH  = draw.GetFontHeight("FC_Banner_Body")
    local flagW  = surface.GetTextSize(sFlag)
    local maxLineW = flagW
    for i = 1, #tLines do
        local lw = surface.GetTextSize(tLines[i])
        if lw > maxLineW then maxLineW = lw end
    end

    local padX, padY = RX(28), RY(16)
    local accentW    = RX(3)
    local tagBoxW    = (sTeam ~= "") and (tagW + RX(20)) or 0
    local headerW    = accentW + RX(12) + titleW + RX(16) + tagBoxW
    local contentW   = math.max(headerW, maxLineW)
    local nBody      = 1 + #tLines
    local cardW      = math.min(contentW + padX * 2, RX(980))
    local cardH      = padY + titleH + RY(10) + nBody * bodyH + math.max(0, nBody - 1) * RY(5) + padY
    local cardX      = math.floor((ScrW() - cardW) / 2)
    local cardY      = RY(52)
    local cut        = RY(12)

    if EVO_UI and EVO_UI.PaintCut then
        EVO_UI.PaintCut(cardX, cardY, cardW, cardH, Color(13, 14, 17, 250 * a), cut)
        if EVO_UI.OutlineCut and EVO_UI.CutPoints then
            EVO_UI.OutlineCut(EVO_UI.CutPoints(cardX + 1, cardY + 1, cardW - 2, cardH - 2, cut), ColorAlpha(col.divider, 150 * a))
        end
    else
        draw.RoundedBox(cut, cardX, cardY, cardW, cardH, Color(13, 14, 17, 250 * a))
    end

    local hx  = cardX + padX
    local hcy = cardY + padY + titleH / 2
    surface.SetDrawColor(ColorAlpha(col.accent, 255 * a))
    surface.DrawRect(hx, hcy - titleH / 2 + RY(2), accentW, titleH - RY(4))
    draw.SimpleText(sTitle, "FC_Banner_Title", hx + accentW + RX(12), hcy, ColorAlpha(col.title, 255 * a), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    if sTeam ~= "" then
        local chipH = tagH + RY(6)
        local chipX = cardX + cardW - padX - tagBoxW
        local chipY = hcy - chipH / 2
        local chipCol = FC_FactionColor(fc_banner.team)
        if EVO_UI and EVO_UI.PaintCut then
            EVO_UI.PaintCut(chipX, chipY, tagBoxW, chipH, ColorAlpha(chipCol, 45 * a), RY(5))
        else
            draw.RoundedBox(RY(5), chipX, chipY, tagBoxW, chipH, ColorAlpha(chipCol, 45 * a))
        end
        draw.SimpleText(sTeam, "FC_Banner_Small", chipX + tagBoxW / 2, chipY + chipH / 2, ColorAlpha(chipCol, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local by = cardY + padY + titleH + RY(10)
    draw.SimpleText(sFlag, "FC_Banner_Body", cardX + cardW / 2, by, ColorAlpha(col.title, 235 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    by = by + bodyH + RY(5)
    for i = 1, #tLines do
        draw.SimpleText(tLines[i], "FC_Banner_Body", cardX + cardW / 2, by, ColorAlpha(col.accent, 255 * a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        by = by + bodyH + RY(5)
    end
end)

-- Drapeau PRIS. sFrom vide = capture sur CE serveur ; sinon la capture vient de
-- l'autre monde (relais MySQL partage, cf. sv_flagcapture CrossPublish).
net.Receive("FC_CaptureDone", function()
    local sName = net.ReadString()
    local sTeam = net.ReadString()
    local sFrom = net.ReadString()
    local sMsg
    if sFrom ~= "" then
        sMsg = string.format("%s (%s) vient d'etre capture par la faction %s !", sName, sFrom, sTeam)
    else
        sMsg = string.format("%s vient d'etre capture par la faction %s !", sName, sTeam)
    end
    if MUGEN and MUGEN.Notify then
        MUGEN.Notify(sMsg, NOTIFY_GENERIC, 7)
    else
        chat.AddText(Color(255, 220, 80), "[FLAG] ", Color(255, 255, 255), sMsg)
    end
end)

-- Notification "lourde capture en cours" : envoyee uniquement aux grades > 10
net.Receive("FC_HeavyCaptureWarning", function()
    local sName = net.ReadString()
    local sTeam = net.ReadString()
    local sMsg = string.format("LOURDE CAPTURE en cours sur %s par la faction %s : drapeau force-delock !", sName, sTeam)
    if MUGEN and MUGEN.Notify then
        MUGEN.Notify(sMsg, NOTIFY_ERROR, 8)
    else
        chat.AddText(Color(255, 80, 80), "[FLAG] ", Color(255, 255, 255), sMsg)
    end
end)

-- Overlay centre-ecran "Drapeau X - Y/Z joueurs requis" RETIRE : la notif
-- (FC_InsufficientPlayers ci-dessus) suffit. hook.Remove pour purger le hook
-- deja enregistre lors d'un hot-reload (retirer le hook.Add ne suffit pas).
hook.Remove("HUDPaint", "FC_InsufficientPlayersHUD")

net.Receive("FC_UpdateZone", function()
    local id = net.ReadUInt(8)
    local progress = net.ReadFloat()
    local rate = net.ReadFloat()
    local lastUpdate = net.ReadFloat()
    local owner = net.ReadString()
    local capturingTeam = net.ReadString()
    local radius = net.ReadFloat()
    local unlockTime = net.ReadFloat()
    local pos = net.ReadVector()
    local name = net.ReadString()
    if capturingTeam == "" then capturingTeam = nil end
    if owner == "" then owner = nil end
    if name == "" then name = nil end

    local found = false
    for i, zone in ipairs(FlagCapture.Zones) do
        if zone.id == id then
            zone.progress = progress
            zone.rate = rate
            zone.lastUpdate = lastUpdate
            zone.owner = owner
            zone.capturingTeam = capturingTeam
            zone.radius = radius
            zone.unlockTime = unlockTime
            zone.pos = pos
            zone.name = name
            zone.sentClaim = false
            found = true
            break
        end
    end
    if not found then
        table.insert(FlagCapture.Zones, {
            id = id,
            progress = progress,
            rate = rate,
            lastUpdate = lastUpdate,
            owner = owner,
            capturingTeam = capturingTeam,
            radius = radius,
            unlockTime = unlockTime,
            sentClaim = false,
            pos = pos,
            name = name,
        })
    end
end)

local function ClaimCaptureZone(id)
    net.Start("FC_ClaimZone")
        net.WriteUInt(id, 8)
    net.SendToServer()
end

hook.Add("Think", "FC_ClientSimulation", function()
    if not FlagCapture.Zones then return end
    
    for _, zone in ipairs(FlagCapture.Zones) do
        if zone.rate and zone.rate ~= 0 then
            local timeDelta = CurTime() - (zone.lastUpdate or CurTime())
            zone.displayProgress = math.Clamp(zone.progress + (timeDelta * zone.rate), 0, 100)
            
            if zone.displayProgress >= 100 and zone.rate > 0 and not zone.sentClaim then
                zone.sentClaim = true
                ClaimCaptureZone(zone.id)  -- netgate: edge -- zone.sentClaim latch
            end
        else
            zone.displayProgress = zone.progress
        end
    end
end)

local FC_FloorTraces = {}

-- Rafraîchit la trace toutes les 0.2 sec (optimal)
local function UpdateZoneFloors()
    if not FlagCapture.Zones then return end

    for _, zone in ipairs(FlagCapture.Zones) do
        if not FC_FloorTraces[zone.id] then
            FC_FloorTraces[zone.id] = { hit = false, pos = nil, normal = nil, t = 0 }
        end

        local traceData = FC_FloorTraces[zone.id]
        if CurTime() < traceData.t then continue end
        traceData.t = CurTime() + 0.2

        local tr = util.TraceLine({
            start  = zone.pos + Vector(0, 0, 200),
            endpos = zone.pos - Vector(0, 0, 1000),
            mask   = MASK_SOLID_BRUSHONLY
        })

        if tr.Hit then
            traceData.hit    = true
            traceData.pos    = tr.HitPos + tr.HitNormal * 0.1
            traceData.normal = tr.HitNormal
        else
            traceData.hit = false
        end
    end
end

hook.Add("Think", "FC_FloorTraceThink", UpdateZoneFloors)

hook.Add("PostDrawTranslucentRenderables", "FC_DrawZones", function()
    if not FlagCapture.Zones then return end

    -- Distance d'affichage du contour : visible <= ZONE_FULL (alpha plein),
    -- fade lineaire jusqu'a ZONE_FADE (alpha 0), invisible au-dela.
    local ZONE_FULL_SQR = 1100 * 1100
    local ZONE_FADE_SQR = 1700 * 1700
    local lpPos = LocalPlayer():GetPos()

    for _, zone in ipairs(FlagCapture.Zones) do
        local traceData = FC_FloorTraces[zone.id]
        local currentProgress = zone.displayProgress or zone.progress or 0

        if traceData and traceData.hit then
            local distSqr = lpPos:DistToSqr(zone.pos)
            if distSqr <= ZONE_FADE_SQR then
                local alpha = 160
                if distSqr > ZONE_FULL_SQR then
                    local t = (distSqr - ZONE_FULL_SQR) / (ZONE_FADE_SQR - ZONE_FULL_SQR)
                    alpha = math.floor(160 * (1 - math.Clamp(t, 0, 1)))
                end
                local color = Color(255, 255, 255, alpha)

                -- Offset Z optionnel par zone (config sh_config FlagZones[i].borderZOffset)
                -- pour remonter visuellement le contour sur certains drapeaux (terrains
                -- complexes ou le snap au sol ne donne pas le rendu voulu).
                local borderZOffset = 0
                local zoneCfg = FlagCapture.Config
                    and FlagCapture.Config.FlagZones
                    and FlagCapture.Config.FlagZones[zone.id]
                if zoneCfg and zoneCfg.borderZOffset then
                    borderZOffset = zoneCfg.borderZOffset
                end

                local pos = traceData.pos + Vector(0, 0, borderZOffset)
                local ang = traceData.normal:Angle()
                ang:RotateAroundAxis(ang:Right(), 90)

                cam.Start3D2D(pos, ang, 1)
                    surface.SetDrawColor(color)
                draw.NoTexture()

                local radius = zone.radius or 300

                -- Dessin du cercle : anneau de quads (epaisseur ~4 unites)
                -- Winding CW pour que la face visible soit celle tournee vers le ciel
                -- (sinon backface culling cache le rond, on voit le sol "a l'envers").
                local segments = 96
                local rOut = radius + 2
                local rIn  = radius - 2
                local twoPi = math.pi * 2
                for i = 0, segments - 1 do
                    local a1 = (i / segments) * twoPi
                    local a2 = ((i + 1) / segments) * twoPi
                    local c1, s1 = math.cos(a1), math.sin(a1)
                    local c2, s2 = math.cos(a2), math.sin(a2)
                    surface.DrawPoly({
                        { x = rOut * c1, y = rOut * s1 },
                        { x = rIn  * c1, y = rIn  * s1 },
                        { x = rIn  * c2, y = rIn  * s2 },
                        { x = rOut * c2, y = rOut * s2 },
                    })
                end
                cam.End3D2D()
            end
        end

        local dist = LocalPlayer():GetPos():DistToSqr(zone.pos)
        if dist < 4000000 then
            local barPos = zone.pos + Vector(0, 0, 250)
            -- Le billboard fait TOUJOURS face à la caméra de rendu (EyePos) et non
            -- à l'angle du joueur -> il suit correctement la caméra orbitale
            -- (citron_orbit_camera) quand on tourne la vue sans bouger le perso.
            local ang = Angle(0, (barPos - EyePos()):Angle().y - 90, 90)

            local zoneCfg = FlagCapture.Config and FlagCapture.Config.FlagZones
                and FlagCapture.Config.FlagZones[zone.id]
            local flagName = zone.name or (zoneCfg and zoneCfg.name) or ("Drapeau " .. zone.id)

            local locked    = zone.unlockTime and zone.unlockTime > CurTime()
            local capturing = zone.capturingTeam ~= nil
            local owned     = zone.owner ~= nil

            -- Capture ouverte selon l'horaire (GlobalBool posée par le serveur).
            -- Les drapeaux restent visibles 24/7 mais ne sont capturables qu'en fenêtre.
            local captureOpen = GetGlobalBool("FC_CaptureOpen", true)
            -- Repli aligné sur sh_config (20h). Il était fige a 18 : le jour ou
            -- l'horaire a change, un client qui n'aurait pas encore recu la config
            -- aurait annonce 18h pendant que le serveur ouvrait a 20h. Un repli qui
            -- ment est pire qu'un repli absent.
            local startH = (FlagCapture.Config and FlagCapture.Config.Schedule
                and FlagCapture.Config.Schedule.StartHour) or 20

            cam.Start3D2D(barPos, ang, 0.25)
                local w, h   = 600, 320
                local x0, y0 = -w / 2, -h / 2

                -- Carte sombre arrondie (DA EVO) — aucune bordure grise/blanche
                draw.RoundedBox(24, x0, y0, w, h, COL_CARD)

                -- Nom du drapeau (toujours, en haut) + fine ligne accent rouge
                draw.SimpleText(string.upper(flagName), "FC_DA_Name", 0, y0 + 48, COL_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.RoundedBox(2, -90, y0 + 84, 180, 4, COL_ACCENT)

                if owned and not capturing then
                    -- CAPTURÉ : icône de faction (teinte couleur faction) + libellé
                    local facCol  = FC_FactionColor(zone.owner)
                    local facIcon = FC_FactionIcon(zone.owner)
                    if facIcon then
                        local isize = 132
                        surface.SetMaterial(facIcon)
                        surface.SetDrawColor(facCol.r, facCol.g, facCol.b, 55)   -- halo
                        surface.DrawTexturedRect(-isize * 0.62, -isize * 0.62, isize * 1.24, isize * 1.24)
                        surface.SetDrawColor(facCol.r, facCol.g, facCol.b, 255)  -- icône nette
                        surface.DrawTexturedRect(-isize / 2, -isize / 2, isize, isize)
                    end

                    draw.SimpleText("CONTRÔLÉ PAR " .. string.upper(zone.owner), "FC_DA_Text", 0, y0 + h - 46, facCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    if locked then
                        local timeLeft = zone.unlockTime - CurTime()
                        draw.SimpleText(string.format("VERROUILLÉ  %02d:%02d", math.floor(timeLeft / 60), math.floor(timeLeft % 60)), "FC_DA_Text", 0, y0 + h - 80, COL_GREY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    elseif not captureOpen then
                        draw.SimpleText(string.format("FERMÉ : OUVRE À %dH", startH), "FC_DA_Text", 0, y0 + h - 80, COL_GREY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                else
                    -- NEUTRE / CAPTURE EN COURS : % + barre de progression
                    local percentText
                    if currentProgress >= 100 then
                        percentText = "CAPTURÉ"
                    elseif currentProgress <= 0 then
                        percentText = owned and "SÉCURISÉ" or "NEUTRE"
                    else
                        percentText = math.Round(currentProgress) .. "%"
                    end
                    draw.SimpleText(percentText, "FC_DA_Big", 0, -2, COL_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                    local statusText, statusCol
                    if not captureOpen then
                        statusText, statusCol = string.format("FERMÉ — OUVRE À %dH", startH), COL_GREY
                    elseif capturing then
                        statusText, statusCol = "CAPTURE — " .. string.upper(zone.capturingTeam), FC_FactionColor(zone.capturingTeam)
                    elseif owned then
                        statusText, statusCol = "CONTRÔLÉ — " .. string.upper(zone.owner), FC_FactionColor(zone.owner)
                    else
                        statusText, statusCol = "À CAPTURER", COL_GREY
                    end
                    draw.SimpleText(statusText, "FC_DA_Text", 0, y0 + h - 86, statusCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                    local barW, barH = w - 90, 18
                    local barX, barY = -barW / 2, y0 + h - 52
                    draw.RoundedBox(barH / 2, barX, barY, barW, barH, COL_TRACK)
                    if currentProgress > 0 then
                        local fillCol = FC_FactionColor(zone.capturingTeam or zone.owner)
                        draw.RoundedBox(barH / 2, barX, barY, math.max(barH, barW * (currentProgress / 100)), barH, fillCol)
                    end
                end
            cam.End3D2D()
        end
    end
end)

-- Sons et victory screen supprimés : gérés par ncm_system_win
