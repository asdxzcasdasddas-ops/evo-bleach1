-- "addons\\flagcapture\\lua\\flagcapture\\cl_flagmap.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if not CLIENT then return end

-- ════════════════════════════════════════════════════════════
--  GESTION DRAPEAU — UI DHTML plein écran (DA EVO), responsive, cross-serveur.
--  Onglets = régions (Seireitei / Hueco Mundo / Monde des vivants). La LOCALE est rendue en
--  live (FlagCapture.Zones), les régions DISTANTES viennent de la DB partagée
--  (poussées par le serveur via FC_RemoteState).
--  Ouverture : bind menu (Menu -> "Gestion Drapeau", F6) ou console (ncm_flagmap).
-- ════════════════════════════════════════════════════════════

FlagCapture = FlagCapture or {}
FlagCapture.RemoteFlags = FlagCapture.RemoteFlags or {}
FlagCapture.LocalRegion = FlagCapture.LocalRegion or "seireitei"

-- Réception de l'état des régions distantes (depuis le serveur / DB partagée).
net.Receive("FC_RemoteState", function()
    FlagCapture.LocalRegion = net.ReadString()
    local json = net.ReadString()
    FlagCapture.RemoteFlags = util.JSONToTable(json) or {}
end)

-- ── Helpers données ──
local function Teams()
    return (FlagCapture.Config and FlagCapture.Config.Teams) or { SHINIGAMI = "Shinigami", HOLLOW = "Hollow" }
end

local function GetLiveZone(id)
    if not FlagCapture.Zones then return nil end
    for _, z in ipairs(FlagCapture.Zones) do
        if z.id == id then return z end
    end
    return nil
end

local function BuildFlagList()
    local out = {}
    local cfg = FlagCapture.Config and FlagCapture.Config.FlagZones
    if not cfg then return out end
    local myRegion = FlagCapture.LocalRegion or "seireitei"
    for i, zc in ipairs(cfg) do
        if (zc.region or "seireitei") ~= myRegion then continue end
        local live = GetLiveZone(i)
        out[#out + 1] = {
            id            = i,
            name          = (live and live.name) or zc.name or ("Drapeau " .. i),
            pos           = zc.pos,
            danger        = zc.danger or 1,
            owner         = live and live.owner or nil,
            progress      = live and (live.displayProgress or live.progress) or 0,
            capturingTeam = live and live.capturingTeam or nil,
            unlockTime    = live and live.unlockTime or 0,
            active        = live ~= nil,
        }
    end
    return out
end

-- Région LOCALE (live) -> { flags, counts }
local function BuildLocalRegion()
    local t = Teams()
    local cfg = FlagCapture.Config
    local perFlagYen = (cfg and cfg.PassiveYenPerFlag) or 100
    local lp = LocalPlayer()
    local lpPos = IsValid(lp) and lp:GetPos() or Vector(0, 0, 0)
    local flags = {}
    local nSh, nHo, nFree = 0, 0, 0

    for _, f in ipairs(BuildFlagList()) do
        local stype, reset = "free", 0
        if not f.active then stype = "inactive"
        elseif f.unlockTime and f.unlockTime > CurTime() then
            stype = "locked"
            reset = math.Round(f.unlockTime - CurTime())
        elseif f.capturingTeam and (f.progress or 0) > 0 then stype = "capturing"
        elseif f.owner then stype = "held" end

        if f.owner == t.SHINIGAMI then nSh = nSh + 1
        elseif f.owner == t.HOLLOW then nHo = nHo + 1
        else nFree = nFree + 1 end

        flags[#flags + 1] = {
            id       = f.id,
            name     = f.name,
            team     = f.owner or "",
            capTeam  = f.capturingTeam or "",
            stype    = stype,
            progress = math.Round(f.progress or 0),
            reset    = reset,
            dist     = IsValid(lp) and math.Round(lpPos:Distance(f.pos) / 52.5) or 0,
            danger   = f.danger or 1,
            yen      = math.Round(perFlagYen * (f.danger or 1)),
        }
    end
    return { flags = flags, counts = { sh = nSh, ho = nHo, free = nFree } }
end

-- Régions DISTANTES (depuis FlagCapture.RemoteFlags, fourni par le serveur)
local function AddRemoteRegions(out)
    local t = Teams()
    local cfg = FlagCapture.Config
    local perFlagYen = (cfg and cfg.PassiveYenPerFlag) or 100
    local now = os.time()

    for _, row in ipairs(FlagCapture.RemoteFlags or {}) do
        local rRegion = row.region or "?"
        local reg = out.regions[rRegion]
        if not reg then
            reg = { flags = {}, counts = { sh = 0, ho = 0, free = 0 } }
            out.regions[rRegion] = reg
        end

        local owner = row.owner
        if owner == "" then owner = nil end
        local danger = tonumber(row.danger) or 1
        local unlock = tonumber(row.unlock_until) or 0

        local stype, reset = "free", 0
        if unlock > now then stype = "locked" reset = unlock - now
        elseif owner then stype = "held" end

        reg.flags[#reg.flags + 1] = {
            id       = tonumber(row.flag_id) or 0,
            name     = row.name or "Drapeau",
            team     = owner or "",
            capTeam  = "",
            stype    = stype,
            progress = 0,
            reset    = reset,
            dist     = -1, -- autre serveur : distance N/A
            danger   = danger,
            yen      = math.Round(perFlagYen * danger),
        }

        if owner == t.SHINIGAMI then reg.counts.sh = reg.counts.sh + 1
        elseif owner == t.HOLLOW then reg.counts.ho = reg.counts.ho + 1
        else reg.counts.free = reg.counts.free + 1 end
    end
end

-- Payload complet (toutes régions) envoyé au JS.
local function BuildPayload()
    local t = Teams()
    local cfg = FlagCapture.Config
    local localRegion = FlagCapture.LocalRegion or "seireitei"

    local out = {
        teamNames   = { sh = t.SHINIGAMI, ho = t.HOLLOW },
        localRegion = localRegion,
        regions     = {},
        info = {
            minPlayers      = (cfg and cfg.MinPlayersToCapture) or 5,
            maxPlayers      = (cfg and cfg.MaxPlayersToCapture) or 5,
            maxPoints       = (cfg and cfg.MaxCaptureTeamPoints) or 10,
            schedEnabled    = (cfg and cfg.Schedule and cfg.Schedule.Enabled) or false,
            schedStart      = (cfg and cfg.Schedule and cfg.Schedule.StartHour) or 0,
            schedEnd        = (cfg and cfg.Schedule and cfg.Schedule.EndHour) or 24,
            captureTime     = (cfg and cfg.CaptureTime) or 300,
            cooldown        = (cfg and cfg.CaptureCooldown) or 3600,
            heavyPlayers    = (cfg and cfg.HeavyCaptureMinPlayers) or 10,
            heavyHigh       = (cfg and cfg.HeavyCaptureMinHighRank) or 2,
            heavyRank       = (cfg and cfg.HeavyCaptureMinRank) or 10,
            rewardChests    = (cfg and cfg.RewardMaxChests) or 5,
            passiveYen      = (cfg and cfg.PassiveYenPerFlag) or 100,
            passiveInterval = (cfg and cfg.PassiveRewardInterval) or 300,
        },
    }

    out.regions[localRegion] = BuildLocalRegion()
    AddRemoteRegions(out)
    return out
end

-- ── HTML / CSS / JS (inline, CEF-safe : % + rem, pas de gap/inset/conic/vh/vw) ──
local FLAGMAP_HTML = [==[
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    * { margin:0; padding:0; box-sizing:border-box; -webkit-user-select:none; user-select:none; }
    html { font-size:16px; }
    html, body { width:100%; height:100%; overflow:hidden;
        font-family:"Trebuchet MS","Segoe UI",sans-serif; }
    body { background: radial-gradient(circle at 50% 38%, #16161c 0%, #0c0c0f 62%, #070709 100%);
        color:#ECECEC; }

    #card { position:absolute; top:2%; left:1.5%; right:1.5%; bottom:2%;
        background:#0E0E11; border-radius:1rem; overflow:hidden;
        box-shadow:0 1.5rem 4rem rgba(0,0,0,.6); display:flex; flex-direction:column; }

    #head { position:relative; flex:0 0 auto; height:6.2rem; }
    #title { position:absolute; top:1.6rem; left:2rem; font-size:2.6rem; font-weight:800;
        letter-spacing:.4rem; color:#ECECEC; }
    #title span { font-size:1.1rem; font-weight:600; letter-spacing:.2rem; color:#cf444e; margin-left:1rem; }
    #accent { position:absolute; top:4.9rem; left:2.1rem; width:3.8rem; height:.22rem;
        background:#cf444e; border-radius:.2rem; }
    #counts { position:absolute; top:2.1rem; right:5.4rem; text-align:right; font-size:1.3rem; }
    #close { position:absolute; top:1.6rem; right:1.8rem; width:2.8rem; height:2.8rem;
        border-radius:.6rem; background:#17171c; color:#8A8A93;
        font-size:1.6rem; line-height:2.8rem; text-align:center; cursor:pointer; transition:all .12s ease; }
    #close:hover { background:#cf444e; color:#fff; }

    #tabs { position:relative; flex:0 0 auto; height:3.2rem; padding:0 2rem; }
    .tab { display:inline-block; height:3.2rem; line-height:2.7rem; margin-right:2.2rem;
        font-size:1.45rem; font-weight:700; letter-spacing:.05rem; color:#6c6c76; cursor:pointer;
        border-bottom:.22rem solid transparent; transition:color .12s ease, border-color .12s ease; }
    .tab:hover { color:#b9b9c0; }
    .tab.active { color:#ECECEC; border-bottom-color:#cf444e; }

    #body { position:relative; flex:1 1 auto; }
    .view { position:absolute; top:.6rem; left:1.4rem; right:1.4rem; bottom:1.4rem; }
    #view_seireitei, #view_hueco, #view_monde { overflow-y:auto; }
    #view_seireitei::-webkit-scrollbar, #view_hueco::-webkit-scrollbar, #view_monde::-webkit-scrollbar { width:.5rem; }
    #view_seireitei::-webkit-scrollbar-thumb, #view_hueco::-webkit-scrollbar-thumb, #view_monde::-webkit-scrollbar-thumb { background:#2a2a31; border-radius:.25rem; }

    #subinfo { padding:.4rem .6rem 1rem .6rem; font-size:1.15rem; color:#8A8A93; }
    #subinfo b { color:#cdcdd3; }

    .fgrid { display:flex; flex-wrap:wrap; }
    .gempty { width:100%; text-align:center; padding:5rem 1rem; color:#5a5a64;
        font-size:1.6rem; letter-spacing:.1rem; }
    .fcard { flex:1 1 25rem; min-width:23rem; margin:.55rem; background:#15151a;
        border-radius:.9rem; border-top:.32rem solid #5a5a64; padding:1.2rem 1.4rem 1.3rem 1.4rem; }
    .fc-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; }
    .fc-name { font-size:1.8rem; font-weight:800; color:#ECECEC; }
    .fc-pill { font-size:1.05rem; font-weight:700; color:#fff; padding:.3rem .85rem; border-radius:1rem; white-space:nowrap; }
    .fc-row { display:flex; justify-content:space-between; align-items:baseline;
        padding:.5rem 0; border-top:1px solid rgba(255,255,255,.05); font-size:1.3rem; }
    .fc-k { color:#8A8A93; }
    .fc-v { font-weight:700; color:#ECECEC; text-align:right; }
    .fc-bar { margin-top:.85rem; height:.6rem; background:#0c0c0f; border-radius:.3rem; overflow:hidden; }
    .fc-barfill { height:100%; border-radius:.3rem; transition:width .25s ease; }

    /* Onglet Règles — 2 colonnes, tient sur une page (pas de scroll) */
    #view_rules { overflow:hidden; }
    #rules { display:flex; flex-wrap:wrap; align-content:flex-start; padding:.2rem; }
    .rule { flex:1 1 30rem; min-width:27rem; margin:.45rem; background:#15151a;
        border-radius:.7rem; border-left:.28rem solid #cf444e; padding:.8rem 1.1rem; }
    .rule-t { font-size:1.3rem; font-weight:800; color:#ECECEC; margin-bottom:.3rem; }
    .rule-b { font-size:1.12rem; line-height:1.42; color:#b9b9c0; }
    .rule-b b { color:#ECECEC; font-weight:700; }
    /* Icône argent (remplace le ¥, cf. helper JS mny()) */
    .mny { height:.85em; width:auto; vertical-align:-.06em; margin-left:.15em; }
</style>
</head>
<body>
    <div id="card">
        <div id="head">
            <div id="title">DRAPEAUX<span>CONTROLE DE ZONE</span></div>
            <div id="accent"></div>
            <div id="counts"></div>
            <div id="close" onmouseenter="gmod.hover()" onclick="gmod.close()">&#10005;</div>
        </div>
        <div id="tabs">
            <div class="tab active" data-t="seireitei" onmouseenter="gmod.hover()" onclick="switchTab('seireitei')">Seireitei</div>
            <div class="tab" data-t="hueco" onmouseenter="gmod.hover()" onclick="switchTab('hueco')">Hueco Mundo</div>
            <div class="tab" data-t="monde" onmouseenter="gmod.hover()" onclick="switchTab('monde')">Monde des vivants</div>
            <div class="tab" data-t="rules" onmouseenter="gmod.hover()" onclick="switchTab('rules')">Règles</div>
        </div>
        <div id="body">
            <div id="view_seireitei" class="view">
                <div id="subinfo"></div>
                <div class="fgrid" id="fgrid_seireitei"></div>
            </div>
            <div id="view_hueco" class="view" style="display:none">
                <div class="fgrid" id="fgrid_hueco"></div>
            </div>
            <div id="view_monde" class="view" style="display:none">
                <div class="fgrid" id="fgrid_monde"></div>
            </div>
            <div id="view_rules" class="view" style="display:none">
                <div id="rules"></div>
            </div>
        </div>
    </div>

<script>
    var D = null;
    var activeTab = 'seireitei';

    function setRootFont(){
        var s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
        if(s < 0.62) s = 0.62;
        document.documentElement.style.fontSize = (16 * s) + "px";
    }
    window.addEventListener("resize", setRootFont);
    setRootFont();

    function switchTab(t){
        activeTab = t;
        var tabs = document.querySelectorAll('.tab');
        for(var i=0;i<tabs.length;i++){
            tabs[i].className = (tabs[i].getAttribute('data-t') === t) ? 'tab active' : 'tab';
        }
        document.getElementById('view_seireitei').style.display = (t === 'seireitei') ? 'block' : 'none';
        document.getElementById('view_hueco').style.display = (t === 'hueco') ? 'block' : 'none';
        document.getElementById('view_monde').style.display = (t === 'monde') ? 'block' : 'none';
        document.getElementById('view_rules').style.display = (t === 'rules') ? 'block' : 'none';
        renderActive(); // rend l'onglet nouvellement actif tout de suite
    }

    // Icône argent du HUD (data-URI injectée par le Lua) à la place du « ¥ ».
    // Fallback : texte " ¥" si l'icône n'a pas pu être lue.
    var MONEY_ICON = "";
    function mny(){ return MONEY_ICON ? '<img class="mny" src="' + MONEY_ICON + '">' : ' ¥'; }

    function teamColor(team){
        if(!D) return '#5a5a64';
        if(team === D.teamNames.sh) return '#4a90e2';
        if(team === D.teamNames.ho) return '#d6453f';
        return '#5a5a64';
    }
    function dangerColor(d){
        if(d >= 2.5) return '#cf444e';
        if(d >= 2)   return '#e0863a';
        if(d >= 1.5) return '#d6b24a';
        return '#8A8A93';
    }
    function dangerLabel(d){
        if(d >= 2.5) return 'Dangereux';
        if(d >= 1.5) return 'Moyen';
        return 'Facile';
    }
    function stateLabel(f){
        if(f.stype === 'inactive')  return 'Inactif (hors horaire)';
        if(f.stype === 'locked')    return 'Verrouille';
        if(f.stype === 'capturing') return 'En capture';
        if(f.stype === 'held')      return 'Tenu';
        return 'Libre';
    }
    function stateColor(f){
        if(f.stype === 'inactive')  return '#6c6c76';
        if(f.stype === 'free')      return '#6fcf6f';
        if(f.stype === 'locked')    return '#cf444e';
        if(f.stype === 'capturing') return teamColor(f.capTeam);
        return teamColor(f.team);
    }
    function fmtReset(sec){
        if(!sec || sec <= 0) return null;
        var h = Math.floor(sec/3600), m = Math.floor((sec%3600)/60), s = Math.floor(sec%60);
        if(h > 0) return h + "h" + (m<10?"0":"") + m;
        return (m<10?"0":"") + m + ":" + (s<10?"0":"") + s;
    }
    function fmtDur(sec){
        if(sec >= 3600 && sec % 3600 === 0) return (sec/3600) + ' h';
        if(sec % 60 === 0) return (sec/60) + ' min';
        return Math.floor(sec/60) + ' min ' + (sec%60) + ' s';
    }

    function renderCounts(region){
        var r = D.regions[region];
        var c = r ? r.counts : { sh:0, ho:0, free:0 };
        document.getElementById('counts').innerHTML =
            '<b style="color:#4a90e2">'+D.teamNames.sh+' '+c.sh+'</b>'
          + '<span style="color:#3a3a42"> &nbsp;|&nbsp; </span>'
          + '<b style="color:#d6453f">'+D.teamNames.ho+' '+c.ho+'</b>'
          + '<span style="color:#3a3a42"> &nbsp;|&nbsp; </span>'
          + '<b style="color:#8A8A93">Libres '+c.free+'</b>';
    }

    function renderInfo(){
        var t = 'De <b>' + D.info.minPlayers + '</b> à <b>' + D.info.maxPlayers + '</b> joueurs · max <b>' + D.info.maxPoints + '</b> pts';
        if(D.info.schedEnabled){
            t += ' &nbsp;·&nbsp; Capturable de <b>' + D.info.schedStart + 'h</b> à <b>' + D.info.schedEnd + 'h</b>';
        }
        document.getElementById('subinfo').innerHTML = t;
    }

    function row(k, v, col){
        return '<div class="fc-row"><span class="fc-k">'+k+'</span>'
             + '<span class="fc-v"'+(col?(' style="color:'+col+'"'):'')+'>'+v+'</span></div>';
    }

    function renderRegion(region){
        var el = document.getElementById('fgrid_' + region);
        if(!el) return;
        var r = D.regions[region];
        if(!r || !r.flags || r.flags.length === 0){
            el.innerHTML = '<div class="gempty">Aucun drapeau pour le moment</div>';
            return;
        }
        var html = '';
        for(var i=0;i<r.flags.length;i++){
            var f = r.flags[i];
            var hc = teamColor(f.team);
            var holder = f.team ? f.team : 'Personne';
            html += '<div class="fcard" style="border-top-color:'+hc+'">'
                  +   '<div class="fc-head"><span class="fc-name">'+f.name+'</span>'
                  +     '<span class="fc-pill" style="background:'+hc+'">'+holder+'</span></div>';
            html += row('Detenu par', holder, hc);
            if(f.dist >= 0) html += row('Distance', f.dist + ' m');
            html += row('Etat', stateLabel(f), stateColor(f));
            html += row('Dangerosité', dangerLabel(f.danger), dangerColor(f.danger));
            html += row('Revenu passif', f.yen + mny() + ' / ' + Math.round(D.info.passiveInterval/60) + ' min');
            var rs = fmtReset(f.reset);
            if(rs) html += row('Reset dans', rs, '#cf444e');
            if(f.stype === 'capturing'){
                html += row('Capture', f.progress + '% (' + f.capTeam + ')', teamColor(f.capTeam));
                html += '<div class="fc-bar"><div class="fc-barfill" style="width:'+f.progress+'%;background:'+teamColor(f.capTeam)+'"></div></div>';
            }
            html += '</div>';
        }
        el.innerHTML = html;
    }

    function ruleBlock(title, body){
        return '<div class="rule"><div class="rule-t">'+title+'</div><div class="rule-b">'+body+'</div></div>';
    }
    function renderRules(){
        var f = D.info;
        var h = '';
        h += ruleBlock('Objectif',
            'Deux factions s\'affrontent : <b style="color:#4a90e2">'+D.teamNames.sh+'</b> et <b style="color:#d6453f">'+D.teamNames.ho
          + '</b>. Capture les drapeaux pour ta faction — chaque capture déclenche une victoire pour ton camp (et une défaite pour l\'autre).');
        h += ruleBlock('Comment capturer',
            'Reste dans la zone d\'un drapeau avec ta faction : la capture met <b>'+fmtDur(f.captureTime)+'</b> à atteindre 100%. '
          + 'Il faut <b>de '+f.minPlayers+' à '+f.maxPlayers+' joueurs</b> de ta faction (3ème siège et plus exclus) et un total d\'équipe de <b>'+f.maxPoints+' points max</b> pour que la progression monte.');
        h += ruleBlock('Zone contestée',
            'Si les <b>deux factions</b> sont présentes en même temps, la progression est <b>gelée</b> tant qu\'une seule ne reste pas.');
        h += ruleBlock('Progression qui redescend',
            'Si l\'adversaire reprend la zone, la progression <b>redescend 2× plus vite</b>. '
          + 'Si la zone se vide, elle revient lentement vers 0 (0,5×).');
        h += ruleBlock('Cooldown après capture',
            'Une fois capturé, le drapeau est <b style="color:#cf444e">verrouillé '+fmtDur(f.cooldown)+'</b> : impossible de le reprendre normalement pendant ce temps.');
        h += ruleBlock('Lourde capture (forcer un verrou)',
            'Un drapeau verrouillé peut être <b>forcé</b> si au moins <b>'+f.heavyPlayers+' ennemis</b> sont dans la zone, '
          + 'dont au moins <b>'+f.heavyHigh+'</b> de grade supérieur à <b>'+f.heavyRank+'</b>. Les hauts gradés sont alertés.');
        if(f.schedEnabled){
            h += ruleBlock('Horaires d\'ouverture',
                'La capture n\'est possible que de <b>'+f.schedStart+'h</b> à <b>'+f.schedEnd+'h</b>. En dehors, les drapeaux sont inactifs.');
        }
        h += ruleBlock('Dangerosité & revenu passif',
            'Chaque drapeau a une <b>dangerosité</b> (Facile, Moyen ou Dangereux). La faction qui le détient touche un <b>revenu passif</b> toutes les <b>'+Math.round(f.passiveInterval/60)
          + ' min</b> : <b>'+f.passiveYen+mny()+'</b> × dangerosité, par drapeau. Plus un drapeau est dangereux, plus il rapporte.');
        h += ruleBlock('Récompenses',
            'À chaque capture, jusqu\'à <b>'+f.rewardChests+' coffres</b> sont distribués au hasard aux joueurs de la faction gagnante présents sur le drapeau (communs, rares, épiques).');
        document.getElementById('rules').innerHTML = h;
    }

    var staticRendered = false;
    function renderActive(){
        if(!D) return;
        if(activeTab === 'seireitei' || activeTab === 'hueco' || activeTab === 'monde'){
            renderRegion(activeTab);   // seul l'onglet visible est re-rendu (live)
            renderCounts(activeTab);
        }
    }
    function EVO_SetData(d){
        D = d;
        if(!staticRendered){
            renderInfo(); renderRules(); staticRendered = true; // statiques : 1 seule fois
            // 1res données : ouvre sur l'onglet de SA région (le serveur local), pas
            // toujours Seireitei (3 régions depuis la zone neutre Monde des vivants).
            if(D.localRegion && D.localRegion !== activeTab && document.getElementById('view_' + D.localRegion)){
                switchTab(D.localRegion); // switchTab -> renderActive
                return;
            }
        }
        renderActive();
    }

    document.addEventListener("keydown", function(e){
        var kc = e.keyCode || e.which || 0;
        if((kc === 27 || e.key === "Escape" || e.key === "Esc") && window.gmod && gmod.close){
            if(e.preventDefault) e.preventDefault();
            gmod.close();
        }
    });

    if(window.gmod && gmod.ready) gmod.ready();
</script>
</body>
</html>
]==]

-- ── Ouverture / fermeture ──
local PUSH_TIMER = "EVO_FlagMap_Push"

function FlagCapture.OpenMap()
    -- Toggle : si la fenêtre est DÉJÀ ouverte, un nouvel appui la FERME (au lieu de
    -- ne rien faire). Couvre tous les chemins (concommand ncm_flagmap, bouton menu
    -- "Gestion Drapeau", appel direct). Le keybind a en plus son toggle via le Think.
    if IsValid(FlagCapture._MapFrame) then
        FlagCapture._MapFrame:Remove()
        FlagCapture._MapFrame = nil
        return
    end

    -- Demande l'état distant frais au serveur (DB partagée).
    net.Start("FC_RequestRemote")
    net.SendToServer()

    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH())
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame.Paint = function() end -- pas de chrome : le DHTML couvre tout l'écran
    FlagCapture._MapFrame = frame

    -- ÉCHAP (système STANDARD du projet : shop/inventaire/skilltree/battlepass...) : on
    -- s'enregistre comme `openedFrame` GLOBAL -> le hook `OnPauseMenuShow` de lzy_escape_menu
    -- ferme `openedFrame` sur Échap ET fait `return false` => empêche le menu pause de s'ouvrir.
    openedFrame = frame

    -- Timestamp d'ouverture (garde 0.25s : l'appui qui OUVRE ne doit pas refermer aussitôt).
    frame._opened = CurTime()

    -- FERMETURE par re-appui sur la touche bindée. On POLL la touche dans Think
    -- (input.IsButtonDown = état BRUT, indépendant du focus) au lieu d'un OnKeyCodePressed : le
    -- DHTML plein écran (souris activée) vole le focus clavier dès qu'on clique dedans (onglets/✕),
    -- ce qui tuerait un OnKeyCodePressed. Front montant + garde 0.25s. ⚠ Touche bindée UNIQUEMENT,
    -- PAS Échap (poll Échap = le menu pause spawn) ; Échap est géré par openedFrame/OnPauseMenuShow.
    frame._bindWasDown = false
    function frame:Think()
        local lp = LocalPlayer()
        if not IsValid(lp) or not lp.GetBindKey then return end
        local k = lp:GetBindKey("flagmap")
        if not k or k == KEY_NONE then return end
        local down = input.IsButtonDown(k)
        if down and not self._bindWasDown and (CurTime() - self._opened) > 0.25 then
            self:Remove()
            return
        end
        self._bindWasDown = down
    end

    local html = vgui.Create("DHTML", frame)
    html:SetPos(0, 0)
    html:SetSize(ScrW(), ScrH())
    html:SetAllowLua(false)
    -- Le DHTML garde la SOURIS (onglets/✕ cliquables) mais NE capte PAS le clavier (bonne
    -- hygiène ; la fermeture par re-appui passe de toute façon par un poll input.IsButtonDown).
    html:SetKeyboardInputEnabled(false)
    FlagCapture._MapHTML = html

    local function Push()
        if not IsValid(frame) or not IsValid(html) then return end
        html:RunJavascript("if(window.EVO_SetData){EVO_SetData(" .. util.TableToJSON(BuildPayload()) .. ");}")
    end

    html:AddFunction("gmod", "close", function()
        if IsValid(frame) then frame:Remove() end
    end)
    html:AddFunction("gmod", "hover", function()
        surface.PlaySound("a4xy732ex6yeop2/g1kpyv29gwai.mp3") -- hover custom projet (ncm_ui_sounds)
    end)
    html:AddFunction("gmod", "ready", function()
        -- Icône argent (data-URI) AVANT le premier push (les rendus utilisent mny()).
        if IsValid(html) and MUGEN and MUGEN.MoneyIconDataURI then
            html:RunJavascript(string.format("window.MONEY_ICON = %q", MUGEN.MoneyIconDataURI()))
        end
        Push()
    end)

    html:SetHTML(FLAGMAP_HTML)

    local nTick = 0
    timer.Create(PUSH_TIMER, 0.5, 0, function()
        if not IsValid(frame) then timer.Remove(PUSH_TIMER) return end
        nTick = nTick + 1
        if nTick % 16 == 0 then -- ~8s : rafraîchit l'état des régions distantes
            -- netgate: edge (throttled to ~8s, and only while the map UI is open)
            net.Start("FC_RequestRemote")
            net.SendToServer()
        end
        Push()
    end)
    Push()

    frame.OnRemove = function()
        timer.Remove(PUSH_TIMER)
        FlagCapture._mapClosedAt = SysTime() -- debounce anti-réouverture par le MÊME appui
        if FlagCapture._MapFrame == frame then FlagCapture._MapFrame = nil end
        if openedFrame == frame then openedFrame = nil end
    end
end

concommand.Add("ncm_flagmap", FlagCapture.OpenMap)

-- OUVERTURE via la touche BINDÉE pour "flagmap" (bind menu ; PAS F6 en dur). La FERMETURE se fait
-- par le poll input.IsButtonDown dans frame:Think (re-appui touche) + openedFrame/OnPauseMenuShow
-- (Échap). PlayerButtonDown ne sert qu'à OUVRIR -> guard `if IsValid(_MapFrame) then return` +
-- debounce `_mapClosedAt` pour ne pas rouvrir juste après une fermeture.
hook.Add("PlayerButtonDown", "NCM_FlagMap_Bind", function(ply, button)
    if not IsValid(ply) or ply ~= LocalPlayer() then return end
    if IsValid(FlagCapture._MapFrame) then return end
    -- Debounce (équivalent du `can_open` du battle pass) : si on VIENT de fermer (poll Think
    -- / Échap / ✕), ne PAS rouvrir avec le même appui. Sinon : le Think retire la frame, puis
    -- PlayerButtonDown la voit absente dans la même frame et la ROUVRE (= le bug "ça rouvre").
    if SysTime() - (FlagCapture._mapClosedAt or 0) < 0.3 then return end
    if not ply.GetBindKey then return end
    local bindKey = ply:GetBindKey("flagmap")
    if bindKey and button == bindKey then
        FlagCapture.OpenMap()
    end
end)
