-- "addons\\flagcapture\\lua\\flagcapture\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Flag Capture - Configuration
FlagCapture = FlagCapture or {}
FlagCapture.Config = {}

local CFG = FlagCapture.Config

-- Factions
CFG.Teams = {
    SHINIGAMI = "Shinigami",
    HOLLOW    = "Hollow"
}

-- ────────────────────────────────────────────────────────────
-- CROSS-SERVEUR (Seireitei <-> Hueco Mundo)
-- Chaque serveur écrit l'état de SES drapeaux dans une table MySQL PARTAGÉE
-- (taguée par région) et lit l'état des AUTRES régions pour l'afficher dans
-- l'UI (onglets). La région courante est déduite de la map.
-- ⚠ Nécessite que les 2 serveurs pointent sur la MÊME base MySQL.
-- ────────────────────────────────────────────────────────────
CFG.RegionByMap = {
    ["rp_seireitei_v1"]  = "seireitei",
    ["hueco_mundo_v1"]   = "hueco",
    ["rp_shinonome_evo"] = "monde", -- zone neutre Monde des vivants (3e serveur)
}
CFG.DefaultRegion      = "seireitei" -- si la map n'est pas mappée ci-dessus
CFG.RegionLabels       = { seireitei = "Seireitei", hueco = "Hueco Mundo", monde = "Monde des vivants" }
CFG.CrossWriteInterval = 30 -- écriture de l'état local en DB (s)
CFG.CrossReadInterval  = 20 -- lecture des régions distantes (s)

function FlagCapture.RegionForMap(sMap)
    sMap = sMap or game.GetMap()
    local cfg = FlagCapture.Config
    return (cfg.RegionByMap and cfg.RegionByMap[sMap]) or cfg.DefaultRegion or "seireitei"
end

-- ────────────────────────────────────────────────────────────
-- ZONES DE DRAPEAUX (positions en dur)
-- Le Z final est snappe au sol via TraceLine dans sv_flagcapture.lua,
-- donc la Z donnee est juste un point de depart au-dessus du sol.
-- ────────────────────────────────────────────────────────────
-- borderZOffset (optionnel) : decale verticalement le carre visuel autour de
-- la zone, sans toucher au point de capture. Utile pour les drapeaux poses sur
-- des terrains complexes (plateformes, escaliers) ou le sol "snap" reel ne
-- correspond pas au rendu visuel souhaite. Par defaut 0.
-- danger (optionnel, defaut 1) : dangerosité du drapeau = multiplicateur du yen
-- passif (PassiveYenPerFlag × danger). Plus c'est dangereux, plus ça rapporte.
-- Liste à plat : Initialize() ne spawn QUE les drapeaux dont le champ `region`
-- correspond à la map courante (FlagCapture.GetRegion). Un drapeau sans `region`
-- vaut "seireitei". -> chaque drapeau Hueco DOIT avoir region = "hueco".
CFG.FlagZones = {
    -- ── Seireitei (rp_seireitei_v1) ──
    { name = "Bois du Jugement",    pos = Vector(-2278.04, -8326.09, -14966.48), radius = 400, danger = 3, region = "seireitei" }, -- élevée
    { name = "Place des Veilleurs", pos = Vector( 9515.55,  1995.77, -14467.10), radius = 400, danger = 3, region = "seireitei" }, -- élevée
    { name = "Gorge des Esprits",   pos = Vector(12795.73, -2626.91,  -7292.12), radius = 400, danger = 1, region = "seireitei" }, -- faible
    { name = "Pic des Esprits",     pos = Vector( 7158.04, -8579.40,  -5821.56), radius = 400, danger = 2, region = "seireitei" }, -- moyenne
    { name = "Ravin des Âmes",      pos = Vector( 5843.40,  5048.25,  -7336.09), radius = 400, danger = 2, region = "seireitei" }, -- moyenne
    { name = "Bois de la Cascade",  pos = Vector(-1797.79,  2844.25, -14792.91), radius = 400, danger = 2, region = "seireitei" }, -- moyenne

    -- ── Hueco Mundo (hueco_mundo_v1) ──
    -- Zone neutre 1
    { name = "Oasis des Âmes Perdues",      pos = Vector(-5120.79, -11030.15,    100.89), radius = 400, danger = 3, region = "hueco" }, -- élevée
    { name = "Arène des Exilés",            pos = Vector(10414.99,  10716.05,    121.98), radius = 400, danger = 2, region = "hueco" }, -- moyenne
    -- Forêt des Menos
    { name = "Clairière des Menos Anciens", pos = Vector( 9123.49,  -6405.79, -12913.08), radius = 400, danger = 3, region = "hueco" }, -- élevée
    { name = "Lisière des Hurlements",      pos = Vector(-8857.66,   1926.46, -12918.40), radius = 400, danger = 2, region = "hueco" }, -- moyenne
    -- Zone neutre 2
    { name = "Falaises de la Lune Blanche", pos = Vector(10613.63, -10084.96,   9117.05), radius = 400, danger = 2, region = "hueco" }, -- moyenne
    { name = "Croisée des Âmes",            pos = Vector( 2754.43,   6489.48,   8915.59), radius = 400, danger = 1, region = "hueco" }, -- faible
    { name = "Dunes du Croissant Noir",     pos = Vector(-9997.55,  -8186.98,   9705.17), radius = 400, danger = 1, region = "hueco" }, -- faible

    -- ── Zone neutre Monde des vivants (rp_shinonome_evo) ── 3 poses user 08/27.
    -- Noms inventés (libres d'être renommés) ; dangerosité croissante vers le nord.
    { name = "Berges de la Rivière", pos = Vector(798.374939, 5203.502441, 146.027588),  radius = 400, danger = 1, region = "monde" }, -- faible
    { name = "Vieux Marché",         pos = Vector(3666.682373, 8570.769531, 33.350857),  radius = 400, danger = 2, region = "monde" }, -- moyenne
    { name = "Sanctuaire de l'Aube", pos = Vector(2771.742676, 13520.449219, 80.761086), radius = 400, danger = 3, region = "monde" }, -- élevée
    -- (4e drapeau « Colline Centrale » retiré le 08/27 sur demande user : il était dans
    -- le dôme des events du soir, ~943 u du centre d'arène.)
}

-- Temps de capture (secondes) : 5 min
CFG.CaptureTime = 300

-- Lock apres capture : 1h = 3600s
CFG.CaptureCooldown = 3600

-- ────────────────────────────────────────────────────────────
-- RESET AUTOMATIQUE APRES CAPTURE (demande user 2026-07-30)
-- Passe ce delai, le drapeau redevient NEUTRE tout seul et redevient capturable
-- dans la foulee. Sans ca, une faction qui capture a 00h50 garde le drapeau
-- indefiniment : les drapeaux restent sur la map en permanence et rien ne les
-- rendait jamais, donc une map "toute rouge" le restait des jours.
--
-- ATTENTION - ce reset LEVE aussi le verrou anti-recapture. C'est obligatoire :
-- un drapeau neutre encore verrouille serait incapturable par TOUT LE MONDE (la
-- lourde capture elle-meme exige un proprietaire pour se declencher). Comme ce
-- delai est plus court que CaptureCooldown, c'est lui qui borne en pratique la
-- duree du verrou.
--
-- Le reset tourne AUSSI hors horaire d'ouverture : c'est une expiration, pas une
-- capture. Chaque soiree repart donc d'une carte neutre.
-- Mettre 0 desactive completement le reset (comportement d'avant).
--
-- DESACTIVE le 08/21 (demande user « a la fin de l'heure de verrouillage le
-- drapeau doit rester capture, pas redevenir neutre ») : le drapeau reste tenu
-- par la faction qui l'a pris jusqu'a ce que l'ADVERSAIRE le reprenne. Seul le
-- verrou expire (CaptureCooldown, 1 h) et rouvre la contestation. Consequence
-- assumee : une carte capturee le reste d'un soir a l'autre (c'etait la raison
-- du reset de 07/30) -- remettre 2400 ici ET dans le re-force plus bas pour revenir.
CFG.ResetAfterCapture = 0

-- REMISE AU NEUTRE À L'OUVERTURE (08/21, demande user, remplace le reset à 40 min) :
-- à chaque OUVERTURE de la capture (transition fermé -> ouvert du Schedule), tous les
-- drapeaux encore tenus redeviennent neutres — la soirée repart sur une carte vierge,
-- mais EN COURS de soirée un drapeau capturé le RESTE (ResetAfterCapture = 0).
-- Un redémarrage serveur en pleine soirée ne compte PAS comme une ouverture (au boot
-- l'état « tenu » est relu depuis la BDD partagée et conservé).
-- false = les drapeaux survivent d'un soir à l'autre.
CFG.ResetAtOpening = true

-- Rayon (units) autour du drapeau dans lequel l'ecran de victoire/defaite plein
-- ecran (ncm_system_win) est affiche a la capture. AVANT : net.Broadcast, donc
-- l'enorme visuel s'affichait a TOUT le serveur, meme a l'autre bout de la map.
-- Maintenant : seuls les joueurs proches du drapeau le voient (les autres ont
-- toujours la notif chat MUGEN.Notify).
-- Repere : le rayon de zone d'un drapeau est 400 -> 1500 = zone + alentours.
CFG.WinScreenRadius = 1500

-- Equipe de capture : 3 a 5 joueurs de la meme faction (10/09, user : minimum 5 -> 3).
-- Hors fourchette : notif aux presents et progress = 0.
-- Le 3eme siege / Grand Fraccion et au-dessus (grade > CaptureCountMaxRank)
-- ne comptent PAS dans l'equipe (ils peuvent quand meme CONTESTER en defense).
CFG.MinPlayersToCapture   = 3
CFG.MaxPlayersToCapture   = 5
CFG.CaptureCountMaxRank   = 12
-- Plafond du total d'equipe (reglement 1.3) : au-dessus, capture bloquee
-- meme si l'effectif est pile a 5. Grade lu EN LIVE (1.5).
CFG.MaxCaptureTeamPoints  = 10

-- Bareme de points d'equipe (reglement captures) : le total = somme des
-- points des 5 membres qui comptent. Grade 13+ = 0 (exclus de l'equipe).
CFG.CaptureRankPointBands = {
    { min = 1,  max = 4,  pts = 1 }, -- Aspirant / Shinigami 3e-1re (Arrancar equiv.)
    { min = 5,  max = 6,  pts = 2 }, -- Kashikan (Menor)
    { min = 7,  max = 9,  pts = 3 }, -- Junshikan (Fraccion novicia-avanzada)
    { min = 10, max = 12, pts = 4 }, -- 6e / 5e / 4e siege (Fraccion principal-Suprema)
}

function FlagCapture.RankCapturePoints(nRank)
    nRank = tonumber(nRank) or 0
    local tBands = FlagCapture.Config.CaptureRankPointBands
    if not tBands then return 0 end
    for i = 1, #tBands do
        local band = tBands[i]
        if nRank >= band.min and nRank <= band.max then return band.pts end
    end
    return 0
end

-- Membre qui COMPTE dans les 5 : pas KO, grade 1..CaptureCountMaxRank.
function FlagCapture.IsCaptureSquadMember(ply)
    if not IsValid(ply) then return false end
    if ply:GetEvoNWBool("EVO_IsKO", false) then return false end
    local nRank = ply:GetEvoNWInt("FactionRank", 0)
    local nMax  = (FlagCapture.Config and FlagCapture.Config.CaptureCountMaxRank) or 12
    return nRank >= 1 and nRank <= nMax
end

-- ────────────────────────────────────────────────────────────
-- HORAIRE D'OUVERTURE
-- La capture de drapeaux ne FONCTIONNE que dans cette plage horaire (heure locale
-- du serveur). En dehors : l'event est arrete (drapeaux retires) et plus aucune
-- capture n'est possible ; il redemarre automatiquement a l'ouverture.
-- Fenetre passant minuit supportee (StartHour > EndHour, ex: 20h -> 01h).
-- HourOffset : decalage horaire si l'horloge du serveur n'est pas a l'heure locale
-- voulue (ex: serveur en UTC -> mettre 2 pour l'heure de Paris en ete).
-- Pour tester hors horaire : passer Enabled = false (capture dispo 24h/24).
-- ────────────────────────────────────────────────────────────
CFG.Schedule = {
    Enabled    = true,
    StartHour  = 20,  -- ouverture : 20h (heure de Paris) — 18h -> 20h le 08/08 (demande user)
    EndHour    = 1,   -- fermeture : 01h
    -- Décalage UTC -> heure FRANÇAISE, en AUTO (heure d'été européenne gérée toute seule) : ouvre
    -- à 20h heure FR toute l'année, sur Seireitei ET Hueco, quel que soit le fuseau de l'OS (le calcul
    -- est basé sur l'UTC forcé, cf. FC_ParisUTCOffset dans sv_flagcapture.lua).
    -- "auto" = recommandé. Mettre un NOMBRE (ex. 2 été / 1 hiver) force le décalage manuellement (debug).
    HourOffset = "auto",
}

-- ────────────────────────────────────────────────────────────
-- LOURDE CAPTURE
-- Permet de delock un drapeau encore en cooldown si suffisamment de
-- joueurs adverses sont presents dans la zone (avec un minimum de
-- joueurs de rang eleve pour eviter qu'une masse de bas-rang force).
-- ────────────────────────────────────────────────────────────
CFG.HeavyCaptureMinPlayers     = 10  -- joueurs adverses dans la zone pour delock
CFG.HeavyCaptureMinHighRank    = 2   -- dont au moins X joueurs de rang > MinRank
-- GRÂCE après une capture (08/21, report user « à 100% ça se relance direct ») :
-- pendant ce délai, la lourde capture NE PEUT PAS faire sauter le verrou. Sans ça,
-- les perdants encore massés sur le point au moment du 100% (10+ dont 2 gradés =
-- précisément les grosses batailles) délockaient dans la seconde -> le verrou d'1 h
-- ne démarrait jamais. Passé la grâce, la lourde capture redevient possible.
-- 0 = comportement d'avant (délock possible immédiatement).
CFG.HeavyCaptureGraceAfterCapture = 900 -- 15 min
CFG.HeavyCaptureMinRank        = 9   -- seuil de rang : > 9 (donc 10+) ; 10 -> 9 le 08/01 (limites 11+ passent a 10+)
CFG.HighRankNotifMinRank       = 9   -- les rangs > 9 (donc 10+) recoivent la notif "lourde capture"

-- IMPORTANT : game_manager (flagcapture_server.lua) fait un table.Merge depuis la BDD
-- environ 2s apres le boot, qui peut ECRASER ces valeurs avec d'anciennes valeurs
-- stockees en BDD (typiquement 10/10 par defaut). On force la re-application 5s plus
-- tard pour s'assurer que sh_config reste la source de verite, et on resync la BDD.
if SERVER then
    timer.Simple(5, function()
        FlagCapture.Config.CaptureTime        = 300
        FlagCapture.Config.CaptureCooldown    = 3600
        FlagCapture.Config.ResetAfterCapture  = 0 -- 08/21 : plus de retour au neutre (cf. bloc CFG plus haut)
        -- Seuils de rang re-forces aussi (08/01) : d'anciennes valeurs BDD (10) ecraseraient le passage a 9.
        FlagCapture.Config.HeavyCaptureMinRank  = 9
        FlagCapture.Config.HighRankNotifMinRank = 9
        FlagCapture.Config.MinPlayersToCapture  = 3 -- 10/09 : la BDD gardait 5
        FlagCapture.Config.MaxPlayersToCapture  = 5
        if GameManager and GameManager.FlagCapture and GameManager.FlagCapture.SaveToDB then
            GameManager.FlagCapture.SaveToDB()
        end
    end)
end

-- ────────────────────────────────────────────────────────────
-- RECOMPENSES : coffres distribues aleatoirement aux joueurs
-- qui ont capture (max RewardMaxChests, tirage random parmi le pool)
-- ────────────────────────────────────────────────────────────
CFG.RewardMaxChests = 5
CFG.RewardChestPool = {
    "coffre_commun",
    "coffre_commun",
    "coffre_commun",
    "coffre_rare",
    "coffre_rare",
    "coffre_epique",
}

-- ────────────────────────────────────────────────────────────
-- RÉCOMPENSES DE CONTRÔLE (capture + revenu passif + suprématie)
-- ────────────────────────────────────────────────────────────
-- À la capture : yen donné à chaque joueur de la faction gagnante présent sur le
-- drapeau (EN PLUS des coffres RewardChestPool ci-dessus).
CFG.CaptureYenReward = 100

-- Revenu passif : toutes les PassiveRewardInterval secondes, chaque joueur reçoit
-- PassiveYenPerFlag yen PAR drapeau détenu par sa faction (chaque drapeau = même montant).
CFG.PassiveRewardInterval = 1800   -- 30 min
CFG.PassiveYenPerFlag     = 50

-- Bonus "suprématie" = faction qui détient le PLUS de drapeaux (égalité = personne) :
--   • chance, par joueur et par intervalle, d'obtenir un coffre aléatoire du pool
CFG.LeadChestChance = 0.01        -- 1 %
CFG.LeadChestPool   = { "coffre_rare", "coffre_rare", "coffre_epique", "coffre_epique", "coffre_legendaire", "coffre_mythique" }
--   • bonus de dégâts spell + katana contre les PNJ
CFG.LeadNpcDamageBonus = 0.10     -- +10 %

-- ────────────────────────────────────────────────────────────
-- RÉCOLTE DES DRAPEAUX (08/31, demande user) : à chaque tick passif, chaque
-- membre de la faction fait des TIRAGES DE PLANTES DE LABO selon les drapeaux
-- détenus, toutes régions confondues. Le pool suit la RÉGION du drapeau :
-- tenir un drapeau au Seireitei donne les plantes qui ne poussent QUE là-bas
-- (Lys, Orchidée carmine) et réciproquement au Hueco (Liane, Chardon, Rose du
-- Vide) — c'est l'avantage stratégique de capturer chez l'ennemi. Les drapeaux
-- des ZONES NEUTRES (Monde des vivants) tirent dans les DEUX pools mélangés.
-- ids = items evo_science (HUB.Plants), donnés en sac via GiveMultipleItems.
-- ⚠ CE GAIN SE MULTIPLIE PAR LE NOMBRE DE CONNECTÉS (le plafond est PAR JOUEUR) :
-- c'est la population, pas le réglage par joueur, qui pilote le volume injecté.
-- Repère de calibrage : la cueillette MANUELLE plafonne à ~18 plantes/h pour TOUTE
-- une map (2 pousses / 10 min, 1 à 3 plantes chacune) — tout réglage doit être
-- comparé à ça, PAS au ressenti par joueur.
-- DIVISÉ PAR 10 le 08/31 (2e passe user) : Chance 0.25 -> 0.02, MaxPerTick 3 -> 1.
-- Donne ~0,26 plante / 30 min / joueur à 8 drapeaux, soit ~10 plantes/h à 20
-- joueurs et ~31/h à 60. Historique : 0.4/6 puis 0.25/3.
-- ────────────────────────────────────────────────────────────
CFG.PassivePlants = {
    Chance        = 0.02, -- chance qu'UN tirage donne une plante
    DrawsPerFlag  = 1,   -- tirages par drapeau détenu…
    DrawsDanger2  = 2,   -- …porté à ça si dangerosité >= 2
    SupremacyMult = 1.5, -- tirages x1.5 pour la faction qui MÈNE (comptes globaux)
    MaxPerTick    = 1,   -- plafond de plantes reçues par joueur et par tick
    -- Poids par plante = rarété science (common 60 / rare 30 / epic 10).
    Pools = {
        seireitei = {
            { id = "herbe_reishi", w = 60 }, { id = "feuille_lune", w = 60 }, { id = "sauge_ames", w = 60 },
            { id = "fougere_spectrale", w = 30 }, { id = "lys_seireitei", w = 30 },
            { id = "orchidee_carmine", w = 10 }, { id = "menthe_limbes", w = 10 },
        },
        hueco = {
            { id = "herbe_reishi", w = 60 }, { id = "feuille_lune", w = 60 }, { id = "sauge_ames", w = 60 },
            { id = "fougere_spectrale", w = 30 }, { id = "liane_garganta", w = 30 }, { id = "chardon_hueco", w = 30 },
            { id = "rose_vide", w = 10 }, { id = "menthe_limbes", w = 10 },
        },
    },
}

-- Modèle du drapeau
CFG.FlagModel = "models/props_junk/wood_crate001a.mdl"

-- Sons
CFG.Sounds = {
    Win = ""
}
