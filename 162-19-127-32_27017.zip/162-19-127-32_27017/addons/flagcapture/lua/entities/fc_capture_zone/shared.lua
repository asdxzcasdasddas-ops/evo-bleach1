-- "addons\\flagcapture\\lua\\entities\\fc_capture_zone\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Flag Capture Zone"
ENT.Author = "Seirei"
ENT.Spawnable = false
ENT.AdminSpawnable = false
