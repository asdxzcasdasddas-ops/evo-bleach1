-- "addons\\lzy_chat\\lua\\autorun\\lzy_chat_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then AddCSLuaFile("lzy_chat/sh_permissions.lua") end
include("lzy_chat/sh_permissions.lua")

if SERVER then
	AddCSLuaFile("lzy_chat/vgui/cl_main.lua")
	include("lzy_chat/sv_main.lua")
else
	include("lzy_chat/vgui/cl_main.lua")
end
