-- "addons\\lzy_chat\\lua\\lzy_chat\\vgui\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}
local MESSAGE_PANEL = {}
local frame = nil

-- ── Historique des messages envoyés (rappel via ↑ / ↓ dans l'input, style terminal) ──
-- Stocke le TEXTE BRUT tapé (avant parsing de canal) -> ↑ rejoue EXACTEMENT ce qu'on a écrit
-- (« /me ... » inclus). Scope fichier = survit à la fermeture/réouverture du chat.
local _chatHistory   = {}  -- ancien -> récent
local _chatHistIdx   = 1   -- position de navigation (#+1 = brouillon en cours)
local _chatHistDraft = ""  -- texte en cours sauvegardé quand on entre dans l'historique
local CHAT_HIST_MAX  = 50

-- Ajoute un message envoyé + remet le curseur au brouillon.
local function ChatHistPush(s)
	s = tostring(s or "")
	if s == "" then return end
	-- Pas de doublon consécutif (rappuyer Entrée sur le même message ne le duplique pas).
	if _chatHistory[#_chatHistory] ~= s then
		_chatHistory[#_chatHistory + 1] = s
		if #_chatHistory > CHAT_HIST_MAX then table.remove(_chatHistory, 1) end
	end
	_chatHistIdx   = #_chatHistory + 1
	_chatHistDraft = ""
end

-- Réinitialise le curseur au brouillon (appelé à l'ouverture) : ↑ repart du plus récent.
local function ChatHistReset()
	_chatHistIdx   = #_chatHistory + 1
	_chatHistDraft = ""
end

-- ↑ : remonte vers les messages plus anciens.
local function ChatHistUp(entry)
	if #_chatHistory == 0 then return end
	if _chatHistIdx > #_chatHistory then
		_chatHistDraft = entry:GetValue() or "" -- on quitte le brouillon -> le mémoriser
	end
	if _chatHistIdx > 1 then _chatHistIdx = _chatHistIdx - 1 end
	local s = _chatHistory[_chatHistIdx] or ""
	entry:SetText(s)
	entry:SetCaretPos(#s)
end

-- ↓ : redescend vers les messages plus récents, puis restaure le brouillon.
local function ChatHistDown(entry)
	if #_chatHistory == 0 then return end
	if _chatHistIdx <= #_chatHistory then _chatHistIdx = _chatHistIdx + 1 end
	local s
	if _chatHistIdx > #_chatHistory then
		s = _chatHistDraft or ""
	else
		s = _chatHistory[_chatHistIdx] or ""
	end
	entry:SetText(s)
	entry:SetCaretPos(#s)
end

-- Sons UI (memes que le reste du jeu via ncm_ui_sounds) : hover = son de survol
-- partage (ex: menu "Supprimer"), click = son du shop. Definis ici car les
-- boutons CloseButton/SettingsButton du chat overrident OnMousePressed/
-- OnCursorEntered (ce qui court-circuite le patch global) -> on rejoue a la main.
local CHAT_SND_HOVER = "a4xy732ex6yeop2/g1kpyv29gwai.mp3"
local CHAT_SND_CLICK = "a4xy732ex6yeop2/adgwz38nw3s9.mp3"

-- Joue un son UI qui se superpose au lieu de se couper : surface.PlaySound rejoue
-- le meme fichier sur un seul canal (coupe l'instance precedente quand on survole
-- vite plusieurs boutons), alors que EmitSound(CHAN_AUTO) alloue un canal libre.
local function PlayChatUISound(snd)
	local lp = LocalPlayer()
	if IsValid(lp) then
		lp:EmitSound(snd, 75, 100, 1, CHAN_AUTO)
	else
		surface.PlaySound(snd)
	end
end

-- Cable les sons hover/click (superposables) sur un DButton, en wrappant ses
-- callbacks existants. On desactive le patch global (ncm_ui_sounds) pour ce
-- bouton via les flags NoUI* afin d'eviter tout double-son.
local function AddChatButtonSounds(btn)
	if not IsValid(btn) then return end
	btn.NoUIHoverSound = true
	btn.NoUIClickSound = true
	local oldEnter = btn.OnCursorEntered
	btn.OnCursorEntered = function(s2, ...)
		PlayChatUISound(CHAT_SND_HOVER)
		if oldEnter then return oldEnter(s2, ...) end
	end
	local oldClick = btn.DoClick
	btn.DoClick = function(s2, ...)
		PlayChatUISound(CHAT_SND_CLICK)
		if oldClick then return oldClick(s2, ...) end
	end
end

-- ── Helpers de dessin DA Atelier (copies locales, mêmes recettes que échap/
-- squad/clan) : vis d'angle + filets dentés de la plaque de réglages. (DA Atelier 07/07)
local function drawCircle(cx, cy, r, col)
	local pts = {}
	for i = 0, 11 do
		local a = math.rad(i * 30)
		pts[i + 1] = { x = cx + math.cos(a) * r, y = cy + math.sin(a) * r }
	end
	draw.NoTexture()
	surface.SetDrawColor(col)
	surface.DrawPoly(pts)
end
local function drawScrew(cx, cy, r)
	drawCircle(cx, cy, r + 1, Color(0, 0, 0, 155))
	drawCircle(cx, cy, r, Color(23, 25, 29, 255))
	drawCircle(cx, cy, r * 0.62, Color(51, 55, 61, 255))
	draw.NoTexture()
	surface.SetDrawColor(0, 0, 0, 140)
	surface.DrawTexturedRectRotated(cx, cy, r * 1.52, math.max(1, math.floor(r * 0.24)), 38)
end
local function drawDashes(x, y, w, col)
	surface.SetDrawColor(col)
	local dw, gap = 6, 5
	local cx = x
	while cx < x + w do
		surface.DrawRect(cx, y, math.min(dw, x + w - cx), 1)
		cx = cx + dw + gap
	end
end

-- Vrai pendant un aperçu live des settings (drag de slider). Quand actif, la
-- recreation du chat NE doit PAS appeler MakePopup() ni gui.EnableScreenClicker,
-- sinon le curseur se coupe et le drag du slider casse.
local _liveApplying = false

-- Quand on envoie un message avec Entrée, l'input se ferme (SetFocused(false)),
-- mais la MÊME touche Entrée est aussi captée par le hook PlayerButtonDown
-- "LZY:OpenChat" qui rouvre aussitôt le chat. On supprime la réouverture
-- pendant un court instant après un envoi pour rester fermé.
local _suppressOpenUntil = 0

-- Touche d'ouverture du chat : bind "messagemode" du joueur, sinon T par defaut.
local function GetChatKey()
	local chatBind = input.LookupBinding("messagemode")
	if chatBind then
		return input.GetKeyCode(chatBind)
	end
	-- Fallback to default chat key (T)
	return KEY_T
end

-- Store /me messages above player heads
local playerMeMessages = {} -- [player] = {text = "", time = 0}

-- ============================================================================
-- Settings persistents (cookies client). Defaults raisonnables, modifiables
-- via le panel de settings (bouton engrenage du chat).
-- ============================================================================
LZY_CHAT_SETTINGS = LZY_CHAT_SETTINGS or {}
local CHAT_DEFAULTS = {
	size_mult     = 0.85, -- multiplicateur global de taille (panel + fonts)
	hide_delay    = 3,     -- secondes avant que le chat se cache si pas focus
	font_size     = 18,    -- taille de font de base (design baseline 1920x1080)
	max_messages  = 100,   -- nombre max de messages gardes en historique
	message_gap   = 0,     -- espace en pixels entre messages
}
local function LoadChatSetting(key, default)
	local raw = cookie.GetString("LZY_Chat_" .. key, nil)
	if raw == nil then return default end
	local n = tonumber(raw)
	if n == nil then return default end
	return n
end
local function SaveChatSetting(key, value)
	cookie.Set("LZY_Chat_" .. key, tostring(value))
	LZY_CHAT_SETTINGS[key] = value
end
local function LoadAllChatSettings()
	for k, v in pairs(CHAT_DEFAULTS) do
		LZY_CHAT_SETTINGS[k] = LoadChatSetting(k, v)
	end
end
LoadAllChatSettings()

-- ============================================================================
-- Canaux de chat (channels) : OOC, LOOC, NAR, AD, ME, ROLL, REPORT, FAC, IT.
-- Le canal choisi pilote le routage serveur (global / local / faction) et la
-- couleur du petit label affiche devant chaque message. Les labels/selecteur
-- sont dessines en RNDX (pas d'asset image) pour rester dans le style du chat.
-- CHAT_OOC_ENABLED doit matcher CHAT_CONFIG.oocEnabled cote serveur.
-- (Definis ici, avant les parametres, pour que la fenetre de reglages puisse
-- lister les canaux a masquer.)
-- ============================================================================
local CHAT_OOC_ENABLED = true

-- Canaux retirés (demande user) : OOC, AD, FAC, IT. Gardés : HRP (ex-LOOC), NAR, ME, ROLL, REPORT, HDV, EVENT.
-- HRP = canal Hors-RP LOCAL (proximité) : remplace l'ancien LOOC ; les joueurs PEUVENT y parler.
--       (Serveur agnostique : tout canal non spécial route en proximité -> HRP = OOC local. /hrp marche.)
-- ROLL n'est PAS un canal où l'on tape : cliquer dessus (ou taper /roll) lance directement
-- un jet de dé 0-100 (cf. ChannelButton.DoClick / OnEnter + serveur). Il reste listé pour
-- son bouton + le label/couleur du message de résultat.
-- REPORT n'est pas de la parole non plus : le message part au support (evo_support) sous
-- forme de TICKET pour le staff, et n'est renvoyé QU'À son auteur (cf. sv_main.lua).
-- HDV n'est pas de la parole : les mises en vente de l'Hôtel des ventes y sont annoncées
-- (nom, rareté, prix). Masquable dans les réglages, absent du sélecteur.
-- MODÉRATION DES NARRATIONS (demande user 08/07) : qui a le droit de voir l'auteur d'un
-- /na ou /it, seuls canaux où l'on poste sans que personne ne sache qui parle. Mêmes
-- groupes SAM que le pôle modération de evo_staff (cl_voir_staff), volontairement FERMÉ :
-- un rang absent de cette liste ne voit rien, il n'hérite d'aucune visibilité par défaut.
-- GetUserGroup() est disponible côté client (renseigné par SAM), même patron que là-bas.
local NARRATION_AUTHOR_GROUPS = {
	superadmin = true, admin = true,
	responsable_moderateur = true, ["responsable modérateur"] = true, -- alias SAM (cf. sv_staff_ranks)
	moderateur = true,
	moderateur_plus = true, ["moderateur plus"] = true,
}
function LZY_Chat_CanSeeNarrationAuthor(ply)
	if not (IsValid(ply) and ply.GetUserGroup) then return false end
	return NARRATION_AUTHOR_GROUPS[string.lower(ply:GetUserGroup() or "")] == true
end

local CHANNELS = {
	{ value = "hrp",    label = "HRP",    color = Color(190, 196, 208) }, -- Canal HRP (ex-LOOC) : Hors-RP local
	{ value = "nar",    label = "NAR",    color = Color(77, 154, 255) },
	-- IT (remis le 06/08, demande user) = de la NARRATION, mais AUTOUR DE SOI.
	-- Même usage que NAR (texte impersonnel, aucun pseudo affiché), seule la portée
	-- change : NAR parle à tout le serveur, IT reste en proximité comme /me. C'est
	-- ce qui permet de décrire une scène locale sans l'imposer aux 100 connectés.
	-- Rien à ajouter côté serveur : tout canal qui n'est pas traité à part y route
	-- déjà en proximité (cf. sv_main.lua, la branche `else` de GetChatRecipients).
	-- Bleu VOISIN de NAR mais pas identique : même famille de lecture, tout en
	-- restant distinguable dans l'historique, où la portée ne se devine pas.
	{ value = "it",     label = "IT",     color = Color(126, 196, 240) },
	-- CLAN / DIV : parole globale entre membres (même clan, ou même division/ordre).
	-- Absents du sélecteur si le joueur n'y a pas droit ; le serveur revalide.
	{ value = "clan",   label = "CLAN",   color = Color(186, 130, 255) },
	{ value = "div",    label = "DIV",    color = Color(80, 200, 170) },
	{ value = "me",     label = "ME",     color = Color(255, 255, 0) },
	{ value = "roll",   label = "ROLL",   color = Color(51, 255, 0) },
	{ value = "report", label = "REPORT", color = Color(235, 35, 9) },
	-- HDV = annonces de mises en vente (Hôtel des ventes). Listen-only : le
	-- joueur ne peut ni le sélectionner ni y parler ; masquable dans les réglages.
	{ value = "hdv",    label = "HDV",    color = Color(230, 196, 120) },
	-- EVENTS = annonces PvP (capture de drapeau / zone, batailles de clans…).
	-- Listen-only, même patron que HDV. Couleur ember, distincte de NAR / HDV / REPORT.
	{ value = "events", label = "EVENT",  color = Color(255, 132, 56) },
	-- ANNONCE = bannières faction / division (lzy_annonce_faction + lzy_hud).
	-- Listen-only (demande user 10/06) : relisible dans le chat après disparition HUD.
	{ value = "annonce", label = "ANNONCE", color = Color(207, 68, 78) },
}
local CHANNEL_COLORS = {}
for _, c in ipairs(CHANNELS) do CHANNEL_COLORS[c.value] = c.color end

-- Éligibilité CLAN / DIV : lecture NW uniquement (mêmes clés que evo_clan / lzy_faction).
-- Index division 1 = "Aucune" → pas de canal. Le serveur revalide, le client ne fait
-- que cacher le sélecteur pour ne pas proposer un canal qui serait droppé.
local function LocalHasClan()
	local lp = LocalPlayer()
	return IsValid(lp) and lp:GetEvoNWString("EVO_ClanKey", "") ~= ""
end
local function LocalHasDivision()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	local fac = lp:GetEvoNWString("FactionName", "")
	local div = tonumber(lp:GetEvoNWInt("FactionDivision", 0)) or 0
	return fac ~= "" and div > 1
end
local function ChannelIsSelectable(ch)
	local value = istable(ch) and ch.value or ch
	if value == "ooc" and not CHAT_OOC_ENABLED then return false end
	if value == "hdv" or value == "events" or value == "annonce" then return false end -- listen-only (annonces)
	if value == "clan" then return LocalHasClan() end
	if value == "div" then return LocalHasDivision() end
	return true
end
-- Tag court de la pill (3-4 lettres, largeur uniforme calée sur REPORT).
-- Hollow : ORD (Ordre) ; Shinigami : DIV (Division).
local function ChannelTag(ch)
	local value = istable(ch) and ch.value or ch
	if value == "div" then
		local word = "Division"
		if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionWord then
			word = LZY_FACTION_CONFIG.DivisionWord(LocalPlayer()) or "Division"
		end
		return string.lower(string.sub(word, 1, 3))
	end
	if value == "events" then return "event" end -- pill "E V E N T" (pas "E V E N T S")
	if value == "annonce" then return "ann" end -- pill courte (comme EVENT)
	return value or "hrp"
end
local function ChannelMenuLabel(ch)
	if ch.value == "div" then
		local w = "DIVISION"
		if LZY_FACTION_CONFIG and LZY_FACTION_CONFIG.DivisionWord then
			w = string.upper(LZY_FACTION_CONFIG.DivisionWord(LocalPlayer()) or "Division")
		end
		return w
	end
	return ch.label
end

-- ── CHAT STAFF (demande user 07/23) ────────────────────────────────────────
-- Ce n'est PAS un canal de plus : c'est un SECOND CHAT, avec son propre onglet et
-- son propre historique, dans la même fenêtre. On bascule de l'un à l'autre par
-- l'onglet en haut. Réservé au staff ; les pseudos y sont TOUJOURS les vrais.
local STAFF_CHAT_COLOR = Color(255, 170, 70)
CHANNEL_COLORS["staff"] = STAFF_CHAT_COLOR
-- ⚠ MIROIR EXACT de lzy_chat/sv_main.lua:41 — à garder synchronisé à la lettre.
-- Cette copie avait pris du retard (corrigé 09/08) : il manquait le responsable
-- modérateur et les 2 paliers d'animateur. Le serveur les acceptait bien à l'écriture,
-- mais côté client l'onglet STAFF ne s'affichait pas — ils avaient donc le droit de
-- parler dans un chat qu'ils ne pouvaient pas ouvrir.
local STAFF_GROUPS = {
	helper = true, helpeur = true,
	animateur = true, animateur_test = true, animateur_gerant = true, gerant_rp = true, ["gérant rp"] = true,
	mj = true, mj_plus = true,
	moderateur = true, ["modérateur"] = true, moderator = true,
	moderateur_plus = true, ["moderateur plus"] = true,
	responsable_moderateur = true, ["responsable modérateur"] = true,
	admin = true, administrateur = true, superadmin = true, ["super-admin"] = true,
	owner = true, fondateur = true, developer = true,
}
local function IsLocalStaff()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	if lp:IsAdmin() or lp:IsSuperAdmin() then return true end
	return STAFF_GROUPS[string.lower(lp:GetUserGroup() or "")] == true
end

-- Canaux masques par le joueur : set { [value] = true }, persiste en cookie
-- (liste de valeurs separees par des virgules). Les messages d'un canal masque
-- ne sont pas affiches et ne font pas apparaitre le chat.
local hiddenChannels = {}
local function SaveHiddenChannels()
	local list = {}
	for ch, hidden in pairs(hiddenChannels) do
		if hidden then list[#list + 1] = ch end
	end
	cookie.Set("LZY_Chat_hidden_channels", table.concat(list, ","))
end
local function LoadHiddenChannels()
	hiddenChannels = {}
	local raw = cookie.GetString("LZY_Chat_hidden_channels", "")
	if raw and raw ~= "" then
		for _, ch in ipairs(string.Explode(",", raw)) do
			if ch ~= "" then hiddenChannels[ch] = true end
		end
	end
end
local function IsChannelHidden(ch)
	return ch ~= nil and hiddenChannels[ch] == true
end
LoadHiddenChannels()

-- ============================================================================
-- Helper de scale uniforme : le chat est designe en 1920x1080 baseline.
-- s(v) renvoie v * min(scaleX, scaleY) * size_mult pour eviter l'etirement
-- sur ultrawide (3440x1440) et garder les proportions.
-- ============================================================================
local function s(v)
	return math.Round(v * math.min(ScrW() / 1920, ScrH() / 1080) * (LZY_CHAT_SETTINGS.size_mult or CHAT_DEFAULTS.size_mult))
end
-- Helper pour la font size. Les fonts "Ubuntu Mono:N" sont pre-enregistrees
-- par glibs (N de 1 a 100) avec gRespFont(N) applique en interne (scale ecran).
-- On retourne donc une TAILLE DESIGN (1-100), pas des pixels reels.
--
-- La police suit DEUX reglages :
--   - font_size (Taille de font)   : pilote direct de la taille du texte
--   - size_mult (Taille globale)   : agrandit/reduit tout le chat, police comprise
--
-- On NORMALISE size_mult par rapport a son defaut : au reglage par defaut le
-- facteur global vaut 1.0, donc sFont(designSize) == designSize * (font_size/18).
-- Resultat : a taille globale par defaut, "Taille de font" mappe ~1:1 en px et
-- a un effet visible sur toute sa plage (pas de zone morte au plancher). Et
-- augmenter la taille globale agrandit bien la police en proportion.
local function sFont(designSize)
	local userMult = (LZY_CHAT_SETTINGS.font_size or CHAT_DEFAULTS.font_size) / 18
	local sizeMult = LZY_CHAT_SETTINGS.size_mult or CHAT_DEFAULTS.size_mult
	local norm     = sizeMult / CHAT_DEFAULTS.size_mult -- 1.0 au defaut
	return math.Clamp(math.Round(designSize * userMult * norm), 6, 100)
end

-- ============================================================================
-- Settings panel : ouvre une fenetre avec sliders pour ajuster les prefs chat.
-- Cookies persistents -> rechargees au prochain spawn.
-- ============================================================================
local _settingsFrame = nil

local function ApplyChatSettings()
	if not IsValid(frame) then return end
	-- Re-init le panel pour appliquer tailles + fonts. On preserve les messages
	-- existants en les re-ajoutant apres recreation.
	local oldMessages = {}
	if IsValid(frame.Messages) and frame.Messages.messages then
		for _, m in ipairs(frame.Messages.messages) do
			if IsValid(m) then
				oldMessages[#oldMessages + 1] = {
					name = m.messageName, text = m.messageText,
					nameCol = m.nameColor, textCol = m.messageColor,
					isMe = m.isMeMessage, msgType = m.messageType,
					msgID = m.messageID,
					senderSid = m.senderSid,
				}
			end
		end
	end
	frame:Remove()
	frame = vgui.Create("lzy_chat")
	for _, m in ipairs(oldMessages) do
		frame:AddMessage(m.name, m.text, m.nameCol, m.textCol, m.isMe, m.msgType, m.msgID, m.senderSid)
	end

	-- Si la fenetre de settings est ouverte, le chat doit rester affiche derriere
	-- elle sans timer d'auto-hide (les sliders volent le focus de l'input).
	if IsValid(_settingsFrame) then
		if frame.hideTimer then
			timer.Remove(frame.hideTimer)
			frame.hideTimer = nil
		end
		frame:SetVisible(true)
		frame.isVisible = true
		if IsValid(frame.Messages) then
			frame.Messages:SetVisible(true)
		end
		return
	end

	-- Affiche le chat qq secondes pour que l'utilisateur voie le resultat,
	-- meme s'il n'y a aucun message (sinon le chat reste cache).
	if IsValid(frame) and frame.ShowForMessage then
		frame:ShowForMessage()
	end
end

-- Applique les settings EN DIRECT pendant qu'on bouge un slider. Throttle a
-- ~30 fps (au lieu d'un debounce) pour un ressenti instantane sans recreer le
-- chat a chaque pixel. Un apply "trailing" garantit que la valeur finale est
-- bien prise meme apres la derniere maj throttlee.
-- ApplyChatSettings recree le chat (MakePopup) -> on remet ensuite le panel de
-- settings au premier plan pour ne pas voler le focus du slider en cours.
local _lastLiveApply = 0
local function _doLiveApply()
	-- Recree le chat SANS toucher au focus/curseur (le slider garde la main)
	_liveApplying = true
	ApplyChatSettings()
	_liveApplying = false
	-- Garde le panel de settings au-dessus du chat recree
	if IsValid(_settingsFrame) then
		_settingsFrame:MoveToFront()
	end
end
local function ApplyChatSettingsLive()
	local now = SysTime()
	if now - _lastLiveApply < 0.03 then
		-- Trop tot : programme un apply final (trailing) pour ne rien rater
		timer.Create("LZY_Chat_LiveApply", 0.04, 1, _doLiveApply)
		return
	end
	_lastLiveApply = now
	if timer.Exists("LZY_Chat_LiveApply") then timer.Remove("LZY_Chat_LiveApply") end
	_doLiveApply()
end

local function OpenChatSettings()
	if IsValid(_settingsFrame) then _settingsFrame:Close(); _settingsFrame = nil; return end

	local W, H = math.floor(ScrW() * 0.22), math.floor(ScrH() * 0.64)
	local f = vgui.Create("DFrame")
	f:SetSize(W, H)
	f:Center()
	f:SetTitle("")
	f:ShowCloseButton(false)
	f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	_settingsFrame = f
	-- Les settings volent le focus clavier a l'input ; on garde quand meme le
	-- chat visible tant que cette fenetre est ouverte.
	if IsValid(frame) then
		local chat = frame
		if chat.hideTimer then
			timer.Remove(chat.hideTimer)
			chat.hideTimer = nil
		end
		chat:SetVisible(true)
		chat.isVisible = true
		if IsValid(chat.Messages) then
			chat.Messages:SetVisible(true)
		end
	end
	f.OnRemove = function()
		if _settingsFrame == f then _settingsFrame = nil end
		-- Si le chat n'est plus en mode saisie apres fermeture des settings,
		-- on reprend le comportement normal d'auto-hide.
		if IsValid(frame) and not frame.isFocused then
			local chat = frame
			chat:ScheduleHide(LZY_CHAT_SETTINGS.hide_delay or CHAT_DEFAULTS.hide_delay)
		end
	end

	f.Paint = function(_, w, h)
		-- Plaque métal noir Atelier : coins coupés 45° + liseré acier, 4 vis
		-- d'angle, titre Bebas + entaille slash1, filet denté. (DA Atelier 07/07)
		if EVO_UI and EVO_UI.PaintCut then
			local pts = EVO_UI.PaintCut(0, 0, w, h, Color(13, 14, 17, 250), 16)
			EVO_UI.OutlineCut(pts, Color(146, 152, 161, 33))
		else
			-- Repli sans evo_ui : simple rect sombre + liseré acier (jamais
			-- d'outline sur une forme à coins coupés -> ici rect droit).
			surface.SetDrawColor(13, 14, 17, 250)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(146, 152, 161, 33)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end

		-- 4 vis d'angle (TR/BL décalées : coins coupés)
		local sr = gRespY(5)
		drawScrew(gRespX(10), gRespY(10), sr)
		drawScrew(w - gRespX(28), gRespY(10), sr)
		drawScrew(w - gRespX(10), h - gRespY(10), sr)
		drawScrew(gRespX(28), h - gRespY(10), sr)

		-- Titre Bebas SANS bold + entaille slash1 accent (repli : barre accent)
		draw.SimpleText("PARAMÈTRES", "Bebas Neue:30", gRespX(18), gRespY(26),
			Color(237, 238, 242), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("Bebas Neue:30")
		local twT, thT = surface.GetTextSize("PARAMÈTRES")
		if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, gRespX(16), gRespY(26) + thT * 0.28, twT * 1.15, 9, ColorAlpha(Color(207, 68, 78), 245))) then
			surface.SetDrawColor(207, 68, 78)
			surface.DrawRect(gRespX(18), gRespY(26) + thT * 0.34, twT, 3)
		end
		-- Filet DENTÉ sous le bandeau (remplace le liseré doré plein)
		drawDashes(gRespX(20), gRespY(56), w - gRespX(40), Color(255, 255, 255, 26))
	end

	-- Croix standard DA : glyphe ✕, gris -> accent au survol (remplace le "X" doré)
	local cb = vgui.Create("DButton", f)
	cb:SetSize(28, 28)
	cb:SetPos(W - 36, 8)
	cb:SetText("")
	cb:SetCursor("hand")
	cb.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		draw.SimpleText("✕", "Avenir Next World Bold:26", w / 2, h / 2,
			hov and Color(207, 68, 78) or Color(150, 154, 162), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	cb.DoClick = function() f:Close() end
	AddChatButtonSounds(cb)

	-- Helper : cree un slider label + value display
	local rowY = gRespY(70)
	local rowGap = gRespY(72)
	local function addSlider(label, key, min, max, decimals, suffix)
		local row = vgui.Create("DPanel", f)
		row:SetPos(gRespX(20), rowY)
		row:SetSize(W - gRespX(40), gRespY(64))
		row.Paint = function() end

		local lbl = vgui.Create("DLabel", row)
		lbl:SetPos(0, 0)
		lbl:SetSize(W - gRespX(40), gRespY(20))
		lbl:SetFont("Avenir Next World:" .. gRespFont(13))
		lbl:SetTextColor(Color(150, 154, 162))
		lbl:SetText(label)

		local slider = vgui.Create("DNumSlider", row)
		slider:SetPos(-gRespX(60), gRespY(22))
		slider:SetSize(W - gRespX(40) + gRespX(60), gRespY(36))
		slider:SetMin(min)
		slider:SetMax(max)
		slider:SetDecimals(decimals or 0)
		slider:SetText("")
		slider:SetValue(LZY_CHAT_SETTINGS[key] or CHAT_DEFAULTS[key])
		slider.Label:SetVisible(false)
		if slider.TextArea then
			slider.TextArea:SetFont("Avenir Next World:" .. gRespFont(13))
			slider.TextArea:SetTextColor(Color(237, 238, 242))
		end
		-- Piste plate sombre + remplissage accent jusqu'au curseur, curseur
		-- CARRÉ accent (pas de rond, pas d'outline). (DA Atelier 07/07)
		if IsValid(slider.Slider) then
			local track = slider.Slider
			track.Paint = function(p, w, h)
				local kx = 0
				if IsValid(p.Knob) then
					local knobX = select(1, p.Knob:GetPos())
					kx = knobX + p.Knob:GetWide() / 2
				end
				surface.SetDrawColor(17, 18, 22, 235)
				surface.DrawRect(0, h / 2 - 1, w, 3)
				surface.SetDrawColor(207, 68, 78, 255)
				surface.DrawRect(0, h / 2 - 1, kx, 3)
			end
			if IsValid(track.Knob) then
				track.Knob.Paint = function(k, w, h)
					local lit = k:IsHovered() or k.Depressed
					local sz = math.max(6, math.min(w, h) - 6)
					surface.SetDrawColor(lit and 224 or 207, lit and 92 or 68, lit and 102 or 78, 255)
					surface.DrawRect((w - sz) / 2, (h - sz) / 2, sz, sz)
				end
			end
		end
		slider.OnValueChanged = function(selff, val)
			LZY_CHAT_SETTINGS[key] = val
			SaveChatSetting(key, val)
			-- Aperçu en direct : le chat se reconstruit pour refléter le réglage
			ApplyChatSettingsLive()
		end

		rowY = rowY + rowGap
	end

	addSlider("Taille globale (×)",        "size_mult",    0.2, 1.5, 2)
	addSlider("Taille de font (px)",       "font_size",    10,  30,  0)
	addSlider("Delai auto-hide (s)",       "hide_delay",   1,   10,  1)
	addSlider("Max messages historique",   "max_messages", 20,  300, 0)
	addSlider("Espace entre messages (px)","message_gap",  0,   30,  0)

	-- Section : visibilite des canaux (clic sur un chip = masquer/afficher).
	rowY = rowY + gRespY(2)
	local secLbl = vgui.Create("DLabel", f)
	secLbl:SetPos(gRespX(20), rowY)
	secLbl:SetSize(W - gRespX(40), gRespY(20))
	secLbl:SetFont("Avenir Next World:" .. gRespFont(13))
	secLbl:SetTextColor(Color(150, 154, 162))
	secLbl:SetText("Canaux affiches (clic pour masquer)")
	rowY = rowY + gRespY(26)

	local cols = 3
	local cgap = gRespX(6)
	local chipW = math.floor((W - gRespX(40) - cgap * (cols - 1)) / cols)
	local chipH = gRespY(30)
	local vgap = gRespY(6)
	for i, ch in ipairs(CHANNELS) do
		local col = (i - 1) % cols
		local rowi = math.floor((i - 1) / cols)
		local chip = vgui.Create("DButton", f)
		chip:SetText("")
		chip:SetCursor("hand")
		chip:SetSize(chipW, chipH)
		chip:SetPos(gRespX(20) + col * (chipW + cgap), rowY + rowi * (chipH + vgap))
		chip.Paint = function(selff, w, h)
			local on = not IsChannelHidden(ch.value)
			local hov = selff:IsHovered()
			-- Onglet plat : canal affiché = souligné accent 2px + libellé blanc ;
			-- masqué = libellé éteint ; survol = libellé titre. (DA Atelier 07/07)
			surface.SetDrawColor(on and 26 or 17, on and 27 or 18, on and 32 or 22, 235)
			surface.DrawRect(0, 0, w, h)
			if on then
				if hov then
					surface.SetDrawColor(224, 92, 102, 255)
				else
					surface.SetDrawColor(207, 68, 78, 255)
				end
			else
				surface.SetDrawColor(255, 255, 255, hov and 44 or 22)
			end
			surface.DrawRect(0, h - 2, w, 2)
			local tc = on and Color(237, 238, 242) or (hov and Color(237, 238, 242) or Color(150, 154, 162))
			draw.SimpleText(ch.label, "Bebas Neue:18", w / 2, h / 2,
				tc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		chip.DoClick = function()
			-- toggle : present => masque, absent => affiche
			hiddenChannels[ch.value] = (not IsChannelHidden(ch.value)) or nil
			SaveHiddenChannels()
			if IsValid(frame) and IsValid(frame.Messages) then
				frame.Messages:RepositionMessages()
				frame.Messages:ScrollToBottom()
			end
		end
		AddChatButtonSounds(chip)
	end
	rowY = rowY + math.ceil(#CHANNELS / cols) * (chipH + vgap)

	-- Bouton "Appliquer & Fermer"
	local apply = vgui.Create("DButton", f)
	apply:SetSize(W - gRespX(40), gRespY(36))
	apply:SetPos(gRespX(20), H - gRespY(96))
	apply:SetText("")
	apply.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		-- Bouton d'action Atelier : plaque accent coin coupé BR, JAMAIS
		-- d'outline sur une forme coupée. (DA Atelier 07/07)
		local col = hov and Color(224, 92, 102, 255) or Color(207, 68, 78, 230)
		if EVO_UI and EVO_UI.PaintCut then
			EVO_UI.PaintCut(0, 0, w, h, col, 9, "br")
		else
			surface.SetDrawColor(col.r, col.g, col.b, col.a)
			surface.DrawRect(0, 0, w, h)
		end
		draw.SimpleText("APPLIQUER & FERMER", "Bebas Neue:22", w / 2, h / 2,
			Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	apply.DoClick = function()
		ApplyChatSettings()
		f:Close()
	end
	AddChatButtonSounds(apply)

	-- Bouton "Reset par defaut"
	local reset = vgui.Create("DButton", f)
	reset:SetSize(W - gRespX(40), gRespY(32))
	reset:SetPos(gRespX(20), H - gRespY(50))
	reset:SetText("")
	reset.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		-- Bouton neutre DA : carte sombre plate, libellé accent au survol. (DA Atelier 07/07)
		surface.SetDrawColor(hov and 36 or 26, hov and 36 or 26, hov and 44 or 32, 255)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("RESET PAR DEFAUT", "Bebas Neue:18", w / 2, h / 2,
			hov and Color(207, 68, 78) or Color(150, 154, 162), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	reset.DoClick = function()
		for k, v in pairs(CHAT_DEFAULTS) do
			SaveChatSetting(k, v)
		end
		-- Reaffiche tous les canaux
		hiddenChannels = {}
		SaveHiddenChannels()
		f:Close()
		ApplyChatSettings()
		OpenChatSettings()
	end
	AddChatButtonSounds(reset)
end

-- Nom affiché devant un message. Point de passage UNIQUE du chat : couvre tous les
-- canaux, /me compris.
-- Depuis le 09/08 la règle vit dans EVO_GetRPDisplayName (lzy_meet) — elle réunit la
-- présentation (« ??? » tant qu'on ne se connaît pas) ET le masque d'anonymat. Garde nil :
-- lzy_meet fournit le helper ; sans lui on retombe sur l'ancienne logique locale plutôt
-- que d'afficher « ??? » à tout le monde.
local function GetPlayerDisplayName(ply)
	if not IsValid(ply) then return "???" end
	if EVO_GetRPDisplayName then return (EVO_GetRPDisplayName(ply)) end

	-- Repli (lzy_meet absent) : pseudo du PERSONNAGE, sinon nom Steam.
	local rpName = ply.GetEvoNWString and ply:GetEvoNWString("Nickname", "") or ""
	if rpName == "" then rpName = ply:Nick() end
	local localPly = LocalPlayer()
	if not IsValid(localPly) then return rpName end
	if localPly.DoIKnowHim and ply.GetUniqueID then
		local uniqueID = ply:GetUniqueID()
		if uniqueID and not localPly:DoIKnowHim(uniqueID) then
			return "???"
		end
	end
	return rpName
end

-- ============================================================================
-- Style DA Atelier (07/07) : accent rouge #cf444e, gris acier, Bebas pour la
-- chrome, PAS de marqueurs en L ni de doré. Le chat reste LÉGER et translucide
-- (il survole le gameplay) : rect droit sombre bas alpha, jamais de plaque
-- opaque. Tout est dessine en RNDX/surface avec les coords deja scalees par
-- s() (pas de gRespX -> evite le double scaling).
-- ============================================================================
local CHAT_COL = {
	bg         = Color(10, 11, 14, 180),    -- fond panneau (translucide, léger)
	bg_inner   = Color(17, 18, 22, 220),    -- fond input focus / pill idle (plat)
	bg_active  = Color(24, 25, 30, 235),    -- pill/hover (plat, un cran plus clair)
	border     = Color(146, 152, 161, 40),  -- liseré acier 1px bas alpha
	accent     = Color(207, 68, 78, 255),   -- accent rouge Atelier
	accent_lit = Color(224, 92, 102, 255),  -- accent éclairci (survol)
	text       = Color(237, 238, 242, 255), -- titres
	text_dim   = Color(150, 154, 162, 255), -- éteint
}

-- Bordure 1px (ou thick) sur les 4 cotes, coords scalees brutes.
local function DrawBorder(x, y, w, h, col, thick)
	thick = thick or 1
	surface.SetDrawColor(col.r, col.g, col.b, col.a)
	surface.DrawRect(x, y, w, thick)
	surface.DrawRect(x, y + h - thick, w, thick)
	surface.DrawRect(x, y, thick, h)
	surface.DrawRect(x + w - thick, y, thick, h)
end

-- (Les marqueurs en L du style "Valorant" sont supprimés : la DA Atelier n'en
-- a pas — la définition du cadre passe par le liseré acier bas alpha.) (DA Atelier 07/07)

-- Detecte un prefixe de canal en debut de message ("/me ...", "/ooc ...", etc.).
-- Renvoie (canal, reste_du_message) si match, sinon nil. Les commandes inconnues
-- (ex: "/staff", "!menu") ne matchent pas et passent telles quelles au serveur.
local function ParseChannelPrefix(text)
	local cmd, rest = text:match("^/(%a+)%s*(.*)$")
	if not cmd then return nil end
	cmd = string.lower(cmd)
	if cmd == "na" then cmd = "nar" end -- alias : "/na" = canal Narration ("/nar") (demande user)
	if cmd == "ordre" or cmd == "division" then cmd = "div" end
	if cmd == "event" then cmd = "events" end
	if not CHANNEL_COLORS[cmd] then return nil end
	if cmd == "ooc" and not CHAT_OOC_ENABLED then return nil end
	if cmd == "hdv" or cmd == "events" or cmd == "annonce" then return nil end -- listen-only
	return cmd, rest
end

local function ChannelLabelFont()
	return "Avenir Next World Bold:" .. sFont(10)
end

local function ChannelLabelHeight()
	surface.SetFont(ChannelLabelFont())
	local _, th = surface.GetTextSize("A")
	return th + s(3)
end

-- Texte capitales espacees ("L O O C") pour matcher le style du shop.
local function SpacedCaps(str)
	return string.upper(str):gsub("(.)", "%1 "):gsub(" $", "")
end

-- Largeur UNIFORME pour tous les labels de canal = largeur du plus large
-- ("R E P O R T"). Ainsi tous les tags ont la meme taille et le texte des
-- messages s'aligne. Mise en cache par police (la police change avec le scale).
local _uniformLabelW = { font = nil, w = 0 }
local function ChannelLabelUniformWidth()
	local f = ChannelLabelFont()
	if _uniformLabelW.font == f then return _uniformLabelW.w end
	surface.SetFont(f)
	local maxTw = 0
	for _, c in ipairs(CHANNELS) do
		local tw = surface.GetTextSize(SpacedCaps(c.value))
		if tw > maxTw then maxTw = tw end
	end
	local w = maxTw + s(14)
	_uniformLabelW.font, _uniformLabelW.w = f, w
	return w
end

-- Largeur (px scaled) du label d'un canal, pour reserver la place dans le wrap.
-- Uniforme : identique pour tous les canaux.
local function ChannelLabelWidth(messageType)
	return ChannelLabelUniformWidth()
end

-- Dessine la "pill" du canal a (x, y) (coin haut-gauche), style shop : fond
-- sombre + bordure 1px dans la couleur du canal + capitales espacees. Largeur
-- uniforme (meme taille pour tous les canaux), texte centre.
local function DrawChannelLabel(x, y, messageType)
	local up  = SpacedCaps(ChannelTag(messageType or "looc"))
	local col = CHANNEL_COLORS[messageType] or color_white
	surface.SetFont(ChannelLabelFont())
	local _, th = surface.GetTextSize(up)
	local w, h = ChannelLabelUniformWidth(), th + s(3)
	surface.SetDrawColor(10, 10, 14, 230)
	surface.DrawRect(x, y, w, h)
	DrawBorder(x, y, w, h, Color(col.r, col.g, col.b, 200), 1)
	draw.SimpleText(up, ChannelLabelFont(), x + w / 2, y + h / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	return w, h
end

-- Message Panel (individual message display)
-- ────────────────────────────────────────────────────────────────
--  LIENS DANS LE CHAT (26/07/26)
--  Le texte est dessine avec draw.SimpleText : il n'est donc PAS selectionnable
--  a la souris. Plutot que de reecrire tout le rendu, on repere les liens, on les
--  souligne, et on les rend copiables/ouvrables au clic.
-- ────────────────────────────────────────────────────────────────
local LINK_COL = Color(120, 180, 255)

-- Un lien = jusqu'au prochain espace. Le retour a la ligne se faisant sur les
-- espaces, un lien n'est jamais coupe en deux : on peut chercher ligne par ligne.
local LINK_PATTERNS = { "https?://[^%s]+", "discord%.gg/[^%s]+", "www%.[^%s]+" }

local function FindLinks(sText)
	local out = {}
	if not sText or sText == "" then return out end
	for _, sPat in ipairs(LINK_PATTERNS) do
		local nInit = 1
		while true do
			local nS, nE = string.find(sText, sPat, nInit)
			if not nS then break end
			nInit = nE + 1
			-- Ponctuation de fin de phrase : elle ne fait pas partie du lien.
			local sBrut = string.sub(sText, nS, nE)
			local sNet = string.match(sBrut, "^(.-)[%.,;:!%?%)]+$") or sBrut
			nE = nS + #sNet - 1
			if #sNet > 0 then
				-- « https://discord.gg/x » matche 2 motifs : on ne garde qu'une entree.
				local bChevauche = false
				for _, l in ipairs(out) do
					if nS <= l.e and nE >= l.s then bChevauche = true break end
				end
				if not bChevauche then out[#out + 1] = { s = nS, e = nE, url = sNet } end
			end
		end
	end
	table.sort(out, function(a, b) return a.s < b.s end)
	return out
end

local function CopierDansLePressePapier(sTexte, sQuoi)
	SetClipboardText(sTexte)
	notification.AddLegacy((sQuoi or "Texte") .. " copie", NOTIFY_GENERIC, 3)
	surface.PlaySound("buttons/button15.wav")
end

function MESSAGE_PANEL:Init()
	self:SetDrawBackground(false)
	self.messageName = ""
	self.messageText = ""
	self.messageColor = Color(255, 255, 255, 255)
	self.nameColor = Color(200, 200, 255, 255)
	self.messageType = "looc" -- Canal pour le label
	self.messageID = nil -- ID serveur (pour la suppression moderateur)
	self.paddingTop = 0 -- Top padding
	self.paddingBottom = 0 -- Bottom padding (set to 0 to remove gap)
	-- Police style shop (Avenir Next World), scale uniforme via sFont.
	self.font = "Avenir Next World:" .. sFont(15)
	-- Mouse input pour le clic droit moderateur (actif quand le chat a le curseur)
	self:SetMouseInputEnabled(true)
end

-- Copie pour tous ; suppression et fiche staff pour les rangs de moderation autorises.
function MESSAGE_PANEL:OpenModMenu()
	local menu = DermaMenu()
	menu.Paint = function(_, w, h)
		-- Menu déroulant DA : fond sombre opaque + liseré acier (le fond du chat
		-- est translucide, un menu doit rester lisible). (DA Atelier 07/07)
		surface.SetDrawColor(8, 8, 10, 250)
		surface.DrawRect(0, 0, w, h)
		DrawBorder(0, 0, w, h, CHAT_COL.border, 1)
	end

	local sPolice = "Avenir Next World:" .. sFont(12)
	local function Ajouter(sLabel, fAction, cCouleur)
		local o = menu:AddOption(sLabel, fAction)
		o:SetFont(sPolice)
		if cCouleur then o:SetTextColor(cCouleur) end
		return o
	end

	-- Un lien tronque dans le menu reste reconnaissable, et le menu reste etroit.
	local function Court(s)
		return #s > 42 and (string.sub(s, 1, 42) .. "...") or s
	end

	for _, l in ipairs(self.links or {}) do
		Ajouter("Copier le lien : " .. Court(l.url), function()
			CopierDansLePressePapier(l.url, "Lien")
		end, LINK_COL)
		Ajouter("Ouvrir : " .. Court(l.url), function()
			-- gui.OpenURL passe par le navigateur Steam : l'URL doit avoir un schema.
			local sUrl = l.url
			if not string.find(sUrl, "^https?://") then sUrl = "https://" .. sUrl end
			gui.OpenURL(sUrl)
		end, LINK_COL)
	end

	Ajouter("Copier le message", function()
		CopierDansLePressePapier(self.messageText or "", "Message")
	end)

	local lp = LocalPlayer()
	if LZY_Chat_CanModerate(lp) then
		local senderSid, messageID = self.senderSid, self.messageID
		if senderSid and EVO_OpenStaffDashboard then
			Ajouter("Ouvrir le profil staff", function()
				if not LZY_Chat_CanModerate(LocalPlayer()) then return end
				-- Resoudre le SteamID conserve, jamais une entite dont l'index
				-- pourrait avoir ete reutilise apres une deconnexion.
				local target = player.GetBySteamID64(senderSid)
				if not LZY_Chat_CanOpenStaffProfile(LocalPlayer(), target) then
					notification.AddLegacy("Profil indisponible ou inaccessible.", NOTIFY_ERROR, 3)
					return
				end
				if IsValid(frame) then frame:SetFocused(false) end
				EVO_OpenStaffDashboard(senderSid, nil, target)
			end)
		end
		if messageID then
			Ajouter("Supprimer le message", function()
				if not LZY_Chat_CanModerate(LocalPlayer()) then return end
				net.Start("LZY:DeleteChat")
				net.WriteUInt(messageID, 32)
				net.SendToServer()
			end, Color(207, 68, 78))
		end
	end

	menu:Open()
end

function MESSAGE_PANEL:OnMousePressed(code)
	if code == MOUSE_RIGHT then
		self:OpenModMenu()
	elseif code == MOUSE_LEFT then
		-- Raccourci : un seul lien dans le message -> clic gauche = copie directe.
		-- Plusieurs liens -> on ouvre le menu, on ne devine pas lequel il veut.
		local tLinks = self.links or {}
		if #tLinks == 1 then
			CopierDansLePressePapier(tLinks[1].url, "Lien")
		elseif #tLinks > 1 then
			self:OpenModMenu()
		end
	end
	-- Un clic sur un message ne doit pas couper la saisie en cours : on redonne
	-- le focus clavier a l'input si le chat est ouvert.
	if IsValid(frame) and frame.isFocused and IsValid(frame.InputLine) then
		timer.Simple(0, function()
			if IsValid(frame) and frame.isFocused and IsValid(frame.InputLine) then
				frame.InputLine:RequestFocus()
			end
		end)
	end
end

function MESSAGE_PANEL:SetPadding(top, bottom)
	self.paddingTop = top or 5
	self.paddingBottom = bottom or 0
	-- Recalculate size if message is already set
	if self.messageName ~= "" then
		self:SetMessage(self.messageName, self.messageText, self.nameColor, self.messageColor)
	end
end

function MESSAGE_PANEL:SetMessage(name, text, nameCol, textCol, isMeMessage, messageType)
	self.messageName = name or ""
	self.messageText = text or ""
	self.messageType = messageType or self.messageType or "looc"
	-- Always set colors (use provided or keep defaults)
	if nameCol then
		self.nameColor = nameCol
	else
		-- Keep default if no color provided
		self.nameColor = self.nameColor or Color(200, 200, 255, 255)
	end
	if textCol then
		self.messageColor = textCol
	else
		-- Keep default if no color provided
		self.messageColor = self.messageColor or Color(255, 255, 255, 255)
	end
	self.isMeMessage = isMeMessage or false
	-- Liens du message ENTIER : sert au menu du clic droit. Le rendu, lui, les
	-- recherche ligne par ligne (les indices changent apres le retour a la ligne).
	self.links = FindLinks(self.messageText)
	self:SetCursor(#self.links > 0 and "hand" or "arrow")

	-- Police style shop (Avenir Next World). Pas de variante italique dispo,
	-- les /me restent differencies par leur couleur grise + label ME.
	self.font = "Avenir Next World:" .. sFont(15)

	-- Calculate height needed for text
	surface.SetFont(self.font)
	local nameW, nameH = surface.GetTextSize(self.messageName .. ": ")

	-- Word wrap text if needed (account for name width on first line)
	-- Get messagesWidth from main panel (parent of parent)
	local mainPanel = self:GetParent()
	if IsValid(mainPanel) then
		mainPanel = mainPanel:GetParent()
	end

	local maxWidth = s(500) -- Default fallback (design 500)
	if IsValid(mainPanel) and mainPanel.messagesWidth then
		-- Use custom width if set (deja en pixels scaled)
		maxWidth = mainPanel.messagesWidth
	elseif IsValid(mainPanel) and mainPanel.chatPanelWidth then
		-- Calculate auto width (same as UpdateMessagesPanelLayout)
		maxWidth = mainPanel.chatPanelWidth - s(40) -- 20px margin on each side
	end

	-- Account for scrollbar width (10px) and margins when calculating text width
	local messagesPanel = self:GetParent()
	if IsValid(messagesPanel) then
		local marginX = messagesPanel.GetMessageMarginX and messagesPanel:GetMessageMarginX() or 0
		maxWidth = maxWidth - s(10) - marginX - s(20) -- scrollbar + margin + padding
	end

	-- Reserve la place du label de canal (dessine avant le nom)
	self.labelWidth = ChannelLabelWidth(self.messageType)
	self.labelGap = s(5)
	maxWidth = maxWidth - self.labelWidth - self.labelGap

	local firstLineMaxWidth = maxWidth - nameW -- First line has less space due to name
	local wrappedText = self:WrapText(self.messageText, firstLineMaxWidth, maxWidth)
	self.wrappedLines = string.Explode("\n", wrappedText)

	local totalHeight = math.max(nameH, s(20)) -- At least ~20px scaled for name
	for i, line in ipairs(self.wrappedLines) do
		local _, lineH = surface.GetTextSize(line)
		totalHeight = totalHeight + lineH + s(2) -- 2px spacing between lines
	end

	self.nameWidth = nameW
	-- Set size to exact content height + padding (no extra bottom padding by default)
	self:SetSize(s(550), totalHeight + self.paddingTop + self.paddingBottom)
end

function MESSAGE_PANEL:WrapText(text, firstLineMaxWidth, subsequentLineMaxWidth)
	subsequentLineMaxWidth = subsequentLineMaxWidth or firstLineMaxWidth
	surface.SetFont(self.font)
	local words = string.Explode(" ", text)
	local lines = {}
	local currentLine = ""
	local isFirstLine = true

	for _, word in ipairs(words) do
		local testLine = currentLine == "" and word or currentLine .. " " .. word
		local w, _ = surface.GetTextSize(testLine)
		local maxW = isFirstLine and firstLineMaxWidth or subsequentLineMaxWidth

		if w > maxW and currentLine ~= "" then
			table.insert(lines, currentLine)
			currentLine = word
			isFirstLine = false
		else
			currentLine = testLine
		end
	end

	if currentLine ~= "" then
		table.insert(lines, currentLine)
	end

	return table.concat(lines, "\n")
end

-- Dessine une ligne en decoupant les liens : couleur distincte + souligne, pour
-- qu'on voie tout de suite qu'ils sont cliquables.
function MESSAGE_PANEL:DrawTextWithLinks(sLine, nX, nY, cBase)
	local tLinks = FindLinks(sLine)
	if #tLinks == 0 then
		draw.SimpleText(sLine, self.font, nX, nY, cBase, TEXT_ALIGN_LEFT)
		return
	end

	surface.SetFont(self.font)
	local nPos = 1
	for _, l in ipairs(tLinks) do
		if l.s > nPos then
			local sAvant = string.sub(sLine, nPos, l.s - 1)
			draw.SimpleText(sAvant, self.font, nX, nY, cBase, TEXT_ALIGN_LEFT)
			nX = nX + surface.GetTextSize(sAvant)
		end
		local nW, nH = surface.GetTextSize(l.url)
		draw.SimpleText(l.url, self.font, nX, nY, LINK_COL, TEXT_ALIGN_LEFT)
		surface.SetDrawColor(LINK_COL.r, LINK_COL.g, LINK_COL.b, 200)
		surface.DrawRect(nX, nY + nH - s(2), nW, s(1))
		nX = nX + nW
		nPos = l.e + 1
	end
	if nPos <= #sLine then
		draw.SimpleText(string.sub(sLine, nPos), self.font, nX, nY, cBase, TEXT_ALIGN_LEFT)
	end
end

function MESSAGE_PANEL:Paint(w, h)
	if not self.wrappedLines then return end

	local lx = s(10) -- left padding scale uniforme

	-- Draw channel label (pill), vertically centered against the first text line
	surface.SetFont(self.font)
	local _, lineH = surface.GetTextSize("A")
	local labelH = ChannelLabelHeight()
	local labelY = self.paddingTop + math.max(0, (lineH - labelH) / 2)
	DrawChannelLabel(lx, labelY, self.messageType)

	-- Le nom/texte commence apres le label
	local textStartX = lx + (self.labelWidth or ChannelLabelWidth(self.messageType)) + (self.labelGap or s(5))

	-- Draw name
	if not self.isMeMessage then
		draw.SimpleText(self.messageName .. ": ", self.font, textStartX, self.paddingTop, self.nameColor, TEXT_ALIGN_LEFT)
	end

	-- Draw text (word wrapped, using pre-calculated lines)
	local yPos = self.paddingTop

	for i, line in ipairs(self.wrappedLines) do
		if i == 1 and not self.isMeMessage then
			-- First line starts after name
			self:DrawTextWithLinks(line, textStartX + (self.nameWidth or 0), yPos, self.messageColor)
		else
			-- Subsequent lines start at left margin (after label)
			self:DrawTextWithLinks(line, textStartX, yPos, self.messageColor)
		end

		surface.SetFont(self.font)
		local _, lineHi = surface.GetTextSize(line)
		yPos = yPos + lineHi + s(2)
	end
end

vgui.Register("lzy_chat_message", MESSAGE_PANEL, "DPanel")

-- Messages Container Panel (scrollable)
local MESSAGES_PANEL = {}
function MESSAGES_PANEL:Init()
	self:SetDrawBackground(false)
	self.messages = {}
	-- Settings live : maxMessages et messageGap lus de LZY_CHAT_SETTINGS (cookies).
	self.maxMessages = LZY_CHAT_SETTINGS.max_messages or CHAT_DEFAULTS.max_messages
	self.messageGap = LZY_CHAT_SETTINGS.message_gap or CHAT_DEFAULTS.message_gap
	self.messageMarginX = 0 -- Left margin for messages

	-- Customize scrollbar
	self:CustomizeScrollbar()
end

function MESSAGES_PANEL:CustomizeScrollbar()
	local vbar = self:GetVBar()
	if not IsValid(vbar) then
		-- Try again next frame if VBar isn't ready yet
		timer.Simple(0.01, function()
			if IsValid(self) then
				self:CustomizeScrollbar()
			end
		end)
		return
	end

	-- Scrollbar fine DA : track sombre + grip acier, accent au survol (DA Atelier 07/07)
	vbar:SetWide(s(4))

	-- Hide up/down arrow buttons
	vbar:SetHideButtons(true)

	-- Track sombre
	vbar.Paint = function(selff, w, h)
		surface.SetDrawColor(10, 10, 14, 200)
		surface.DrawRect(0, 0, w, h - s(5))
	end

	-- Grip : accent rouge au hover/drag, acier sinon
	if IsValid(vbar.btnGrip) then
		vbar.btnGrip.Paint = function(grip, w, h)
			local active = grip:IsHovered() or (grip.Depressed == true)
			local c = active and CHAT_COL.accent or CHAT_COL.border
			surface.SetDrawColor(c.r, c.g, c.b, active and 255 or 180)
			surface.DrawRect(0, 0, w, h - s(5))
		end
	end
end

function MESSAGES_PANEL:SetMessageGap(gap)
	self.messageGap = gap or 0
	self:RepositionMessages()
end

function MESSAGES_PANEL:GetMessageGap()
	return self.messageGap or 0
end

function MESSAGES_PANEL:SetMessageMarginX(margin)
	self.messageMarginX = margin or 10
	self:RepositionMessages()
end

function MESSAGES_PANEL:GetMessageMarginX()
	return self.messageMarginX or 10
end

function MESSAGES_PANEL:GetMessageRowAdvance(msg)
	if not IsValid(msg) then return 0 end
	-- Match the original compact stacking used when messages are first added.
	return msg:GetTall() - s(15) + self:GetMessageGap()
end

function MESSAGES_PANEL:AddMessage(name, text, nameCol, textCol, isMeMessage, messageType, messageID, senderSid)
	-- Create message panel
	local msgPanel = vgui.Create("lzy_chat_message", self)
	msgPanel:SetMessage(name, text, nameCol, textCol, isMeMessage, messageType)
	msgPanel.messageID = messageID
	msgPanel.senderSid = senderSid
	-- Canal masque : le panel reste stocke (pour reapparaitre si reactive) mais
	-- n'est pas affiche ni positionne.
	local hidden = IsChannelHidden(messageType)
	msgPanel:SetVisible(not hidden)

	-- Calculate position (stack from top) — chevauchement vertical scale uniforme
	local yPos = 0
	for i, msg in ipairs(self.messages) do
		if IsValid(msg) and not IsChannelHidden(msg.messageType) then
			yPos = yPos + self:GetMessageRowAdvance(msg)
		end
	end

	msgPanel:SetPos(self:GetMessageMarginX(), yPos)

	-- Add to messages list
	table.insert(self.messages, msgPanel)

	-- Remove old messages if we exceed limit
	if #self.messages > self.maxMessages then
		local oldMsg = self.messages[1]
		if IsValid(oldMsg) then
			oldMsg:Remove()
		end
		table.remove(self.messages, 1)

		-- Reposition remaining messages
		self:RepositionMessages()
	end

	-- Update canvas size
	self:UpdateCanvasSize()

	-- Scroll to bottom (sauf si le message est masque -> inutile de scroller)
	if not hidden then
		self:ScrollToBottom()
	end
end

function MESSAGES_PANEL:UpdateCanvasSize()
	-- Calculate total height of all messages (including gaps)
	local totalHeight = 0
	for i, msg in ipairs(self.messages) do
		if IsValid(msg) and not IsChannelHidden(msg.messageType) then
			totalHeight = totalHeight + self:GetMessageRowAdvance(msg)
		end
	end

	-- Set canvas size (width is panel width, height is total messages height)
	local canvas = self:GetCanvas()
	if canvas then
		canvas:SetSize(self:GetWide(), math.max(totalHeight, self:GetTall()))
	end
end

function MESSAGES_PANEL:RepositionMessages()
	local yPos = 0
	local marginX = self:GetMessageMarginX()
	for i, msg in ipairs(self.messages) do
		if IsValid(msg) then
			if IsChannelHidden(msg.messageType) then
				msg:SetVisible(false)
			else
				msg:SetVisible(true)
				msg:SetPos(marginX, yPos)
				yPos = yPos + self:GetMessageRowAdvance(msg)
			end
		end
	end
	-- Update canvas size after repositioning
	self:UpdateCanvasSize()
end

function MESSAGES_PANEL:ScrollToBottom()
	-- Scroll to bottom with multiple attempts to ensure it works
	local function doScroll(attempt)
		attempt = attempt or 1
		if not IsValid(self) then return end

		local vbar = self:GetVBar()
		local canvas = self:GetCanvas()

		if vbar and canvas then
			-- Calculate max scroll: canvas height - panel height
			local maxScroll = math.max(0, canvas:GetTall() - self:GetTall())
			vbar:SetScroll(maxScroll)

			-- If still not at bottom after a delay, retry (up to 3 times)
			if attempt < 3 then
				timer.Simple(0.05, function()
					if IsValid(self) then
						local currentScroll = vbar:GetScroll()
						local expectedScroll = math.max(0, canvas:GetTall() - self:GetTall())
						-- If we're not at the bottom, try again
						if math.abs(currentScroll - expectedScroll) > 1 then
							doScroll(attempt + 1)
						end
					end
				end)
			end
		elseif attempt < 3 then
			-- VBar or canvas not ready yet, try again
			timer.Simple(0.05, function()
				if IsValid(self) then
					doScroll(attempt + 1)
				end
			end)
		end
	end

	-- Start scrolling after a small delay to ensure canvas is updated
	timer.Simple(0.01, function()
		if IsValid(self) then
			doScroll(1)
		end
	end)
end

function MESSAGES_PANEL:Clear()
	for _, msg in ipairs(self.messages) do
		if IsValid(msg) then
			msg:Remove()
		end
	end
	self.messages = {}
end

vgui.Register("lzy_chat_messages", MESSAGES_PANEL, "DScrollPanel")

function PANEL:Init()
	self:SetDraggable(false)
	self:SetSizable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
	-- Toutes les dimensions sont en design 1920x1080, scalees via s() pour
	-- rester proportionnees sur n'importe quel ecran (ultrawide compris).
	self.panelWidth = s(700)
	self.panelHeight = s(500)
	self.chatPanelWidth = s(561)
	self.chatPanelHeight = s(331)
	self.chatPanelX = s(20)
	self.chatPanelY = s(50)
	self:SetSize(self.panelWidth, self.panelHeight)
	self:SetPos(0, ScrH()/3)
	-- Pendant un aperçu live, ne pas voler le focus/curseur (le slider garde la main)
	if not _liveApplying then
		self:MakePopup()
	end

	-- State management
	self.isFocused = false
	self.isVisible = false
	self:SetVisible(false) -- Start hidden
	if not _liveApplying then
		gui.EnableScreenClicker(false) -- Disable cursor initially
	end
	self.hideTimer = nil -- Timer for auto-hiding panel

	-- Store input position and size for drawing background in Paint.
	-- La hauteur de l'input est derivee de SA police (et non juste de size_mult)
	-- pour que le placeholder "ENTREZ UN MESSAGE" tienne toujours dans la box,
	-- meme quand la police est grande. gRespFont() donne les px reels de la font.
	local inputFontPx = gRespFont(sFont(16))
	local inputWidth = s(529)
	local inputHeight = math.max(s(38), inputFontPx + s(12))
	self.inputX = self.chatPanelX + (self.chatPanelWidth - inputWidth) / 2 -- Center horizontally
	self.inputY = self.chatPanelY + self.chatPanelHeight - inputHeight - s(10) -- 10px margin from bottom
	self.inputWidth = inputWidth
	self.inputHeight = inputHeight

	-- ── Selecteur de canal (channel selector) a gauche de l'input ──
	-- Canal courant (defaut LOOC, comme bc_chat). Le bouton ouvre un menu liste.
	self.currentChannel = "hrp" -- défaut : canal HRP (Hors-RP local) (demande user)
	-- Largeur = celle du plus large tag de canal ("REPORT") + sa marge, pour que
	-- le texte (meme REPORT) ne touche pas les bords, comme les tags des messages.
	local dropW = math.max(s(62), ChannelLabelUniformWidth() + s(8))
	local dropH = math.max(s(16), self.inputHeight - s(12))
	self.ChannelButton = vgui.Create("DButton", self)
	self.ChannelButton:SetSize(dropW, dropH)
	self.ChannelButton:SetPos(self.inputX + s(8), self.inputY + (self.inputHeight - dropH) / 2)
	self.ChannelButton:SetText("")
	self.ChannelButton:SetMouseInputEnabled(true)
	self.ChannelButton:SetKeyboardInputEnabled(false)
	self.ChannelButton:SetZPos(1000)
	self.ChannelButton:SetVisible(false)
	self.ChannelButton.Paint = function(selff, w, h)
		local hov = selff:IsHovered()
		local col = CHANNEL_COLORS[self.currentChannel] or color_white
		-- Onglet plat DA : fond sombre plein + souligné accent 2px (canal
		-- sélectionné), libellé couleur du canal. Plus de bordure dorée. (DA Atelier 07/07)
		surface.SetDrawColor(hov and CHAT_COL.bg_active.r or CHAT_COL.bg_inner.r,
			hov and CHAT_COL.bg_active.g or CHAT_COL.bg_inner.g,
			hov and CHAT_COL.bg_active.b or CHAT_COL.bg_inner.b, 240)
		surface.DrawRect(0, 0, w, h)
		local uc = hov and CHAT_COL.accent_lit or CHAT_COL.accent
		local ut = math.max(1, s(2))
		surface.SetDrawColor(uc.r, uc.g, uc.b, 255)
		surface.DrawRect(0, h - ut, w, ut)
		-- Texte du canal centre
		draw.SimpleText(SpacedCaps(ChannelTag(self.currentChannel)), ChannelLabelFont(), w / 2, h / 2,
			col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.ChannelButton.DoClick = function(selff)
		-- Ferme un menu déjà ouvert avant d'en rouvrir un (toggle propre).
		if IsValid(self.ChannelMenu) then self.ChannelMenu:Remove() end
		local menu = DermaMenu()
		self.ChannelMenu = menu
		menu.Paint = function(_, w, h)
			-- Menu déroulant DA : fond sombre opaque + liseré acier (DA Atelier 07/07)
			surface.SetDrawColor(8, 8, 10, 250)
			surface.DrawRect(0, 0, w, h)
			DrawBorder(0, 0, w, h, CHAT_COL.border, 1)
		end
		for _, ch in ipairs(CHANNELS) do
			if ChannelIsSelectable(ch) then
				local opt = menu:AddOption(ChannelMenuLabel(ch), function()
					if ch.value == "roll" then
						-- ROLL = action DIRECTE : on lance un dé (0-100) tout de suite via le
						-- serveur (anti-triche). On NE bascule PAS sur un canal "roll".
						net.Start("LZY:RequestRoll")
						net.SendToServer()
					else
						self.currentChannel = ch.value
					end
					-- Re-focus l'input apres selection (le menu a vole le focus)
					timer.Simple(0, function()
						if IsValid(self) and IsValid(self.InputLine) and self.isFocused then
							self.InputLine:RequestFocus()
						end
					end)
				end)
				-- Libellé d'onglet DA : Bebas (fonte string globale, jamais de
				-- Bebas bold locale), couleur du canal conservée. (DA Atelier 07/07)
				opt:SetFont("Bebas Neue:18")
				opt:SetTextColor(ch.color)
			end
		end
		local x, y = selff:LocalToScreen(0, selff:GetTall() + s(2))
		menu:Open(x, y)
	end

	-- Custom input — police style shop (Avenir Next World)
	self.InputLine = vgui.Create("DTextEntry", self)
	self.InputLine:SetFont("Avenir Next World:" .. sFont(13))
	self.InputLine:SetTextColor(Color(255, 255, 255, 255))
	self.InputLine:SetDrawBackground(false)
	self.InputLine:SetDrawBorder(false)
	self.InputLine:SetMultiline(false)
	self.InputLine:SetPlaceholderText("ENTREZ UN MESSAGE...")
	self.InputLine:SetPlaceholderColor(Color(150, 150, 160, 255))
	self.InputLine:SetPos(self.inputX + s(8) + dropW + s(8), self.inputY)
	self.InputLine:SetSize(self.inputWidth - s(8) - dropW - s(16), self.inputHeight)
	self.InputLine:SetVisible(false) -- Start hidden (only show when focused)
	self.InputLine:SetDrawLanguageID(false)

	-- Handle enter key
	self.InputLine.OnEnter = function(entry)
		local text = entry:GetValue()
		local rawInput = text -- capturé AVANT le parsing de canal (pour l'historique ↑/↓)

		-- Prefixe de canal ("/me ...", "/ooc ...") -> bascule le canal + retire
		-- le prefixe. Si seul le prefixe est tape, on switch et on reste ouvert.
		local ch, rest = ParseChannelPrefix(text)
		-- Préfixe d'un canal auquel on n'a pas droit (pas de clan, division Aucune) :
		-- on CONSOMME le préfixe pour qu'il ne parte pas en commande PlayerSay, mais
		-- on ne bascule pas et on n'envoie rien.
		if ch and not ChannelIsSelectable(ch) then
			entry:SetText("")
			entry:SetCaretPos(0)
			return true
		end
		if ch == "roll" then
			-- /roll = jet de dé DIRECT (0-100, via serveur), comme le bouton ROLL.
			net.Start("LZY:RequestRoll")
			net.SendToServer()
			entry:SetText("")
			entry:SetCaretPos(0)
			return true
		end
		if ch then
			self.currentChannel = ch
			text = rest
			if text == "" then
				entry:SetText("")
				entry:SetCaretPos(0)
				return true
			end
		end

		-- ONGLET STAFF : on parle dans le chat staff, quel que soit le canal RP
		-- sélectionné. Les canaux (HRP/NAR/ME/ROLL) n'ont aucun sens ici : c'est un
		-- autre chat, pas une catégorie du chat RP.
		if self.activeTab == "staff" then
			if text ~= "" then
				net.Start("LZY:ChatMessage")
				net.WriteString(text)
				net.WriteString("staff")
				net.SendToServer()
				ChatHistPush(rawInput)
			end
			entry:SetText("") entry:SetCaretPos(0)
			return true
		end

		-- Filet : on ne "tape" JAMAIS dans le canal ROLL. Si le canal courant est ROLL (peu importe
		-- comment), Entrée lance un jet de dé au lieu d'envoyer le texte.
		self:EnsureChannelSelectable()
		if self.currentChannel == "roll" then
			net.Start("LZY:RequestRoll") net.SendToServer()
			entry:SetText("") entry:SetCaretPos(0)
			return true
		end

		if text ~= "" then
			-- Send chat message to server with selected channel
			net.Start("LZY:ChatMessage")
			net.WriteString(text)
			net.WriteString(self.currentChannel or "nar")
			net.SendToServer()
			ChatHistPush(rawInput) -- historique ↑/↓ : mémorise le message envoyé

			-- Use SetText instead of SetValue (SetValue doesn't work when focused)
			entry:SetText("")
			entry:SetCaretPos(0)

			-- Unfocus after sending + supprime la réouverture par la même touche Entrée
			_suppressOpenUntil = CurTime() + 0.2
			self:SetFocused(false)

			return true
		end
	end

	-- TAB (et Ctrl+TAB) change de canal sans quitter l'input. On intercepte AVANT
	-- le comportement par defaut du DTextEntry (qui gere l'autocomplete/focus).
	local baseKeyCodeTyped = self.InputLine.OnKeyCodeTyped
	self.InputLine.OnKeyCodeTyped = function(entry, code)
		-- ↑ / ↓ : parcourt l'historique de NOS messages envoyés (style terminal). Single-line ->
		-- ces touches n'ont aucun effet par défaut, on peut les intercepter sans rien casser.
		if code == KEY_UP then ChatHistUp(entry) return true end
		if code == KEY_DOWN then ChatHistDown(entry) return true end
		if code == KEY_TAB then
			local backwards = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
			self:CycleChannel(backwards)
			return true
		end
		if baseKeyCodeTyped then return baseKeyCodeTyped(entry, code) end
	end

	-- Close button (top right corner)
	self.CloseButton = vgui.Create("DButton", self)
	self.CloseButton:SetSize(s(24), s(26))
	self.CloseButton:SetPos(self.chatPanelWidth - s(15), self.chatPanelY + s(10))
	self.CloseButton:SetText("")
	self.CloseButton:SetMouseInputEnabled(true)
	self.CloseButton:SetKeyboardInputEnabled(false)
	self.CloseButton:SetZPos(1000)
	self.CloseButton.hovered = false
	self.CloseButton.Paint = function(selff, w, h)
		-- Croix standard DA : glyphe ✕, gris -> accent au survol (remplace le PNG). (DA Atelier 07/07)
		draw.SimpleText("✕", "Avenir Next World Bold:" .. sFont(19), w / 2, h / 2,
			selff.hovered and CHAT_COL.accent or CHAT_COL.text_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.CloseButton.OnMousePressed = function(selff, keyCode)
		PlayChatUISound(CHAT_SND_CLICK)
		self:SetFocused(false)
		return true
	end
	self.CloseButton.OnCursorEntered = function()
		self.CloseButton.hovered = true
		PlayChatUISound(CHAT_SND_HOVER)
	end
	self.CloseButton.OnCursorExited = function()
		self.CloseButton.hovered = false
	end

	-- Bouton réglages (bandeau, à gauche du ✕) : texte Bebas "PARAMÈTRES" au
	-- lieu de l'engrenage PNG — largeur calculée sur le texte pour ne jamais
	-- déborder quelle que soit la taille de police choisie. (DA Atelier 07/07)
	local settingsFont = "Bebas Neue:" .. sFont(15)
	surface.SetFont(settingsFont)
	local settingsTw = surface.GetTextSize("PARAMÈTRES")
	local settingsW = settingsTw + s(12)
	-- Bord GAUCHE du bouton PARAMÈTRES, mémorisé pour LayoutTabs : les onglets RP/STAFF
	-- se placent à sa gauche (sinon l'onglet STAFF déborde SOUS "PARAMÈTRES" — capture user 07/25).
	self.settingsBtnX = self.chatPanelWidth - s(15) - s(6) - settingsW
	self.SettingsButton = vgui.Create("DButton", self)
	self.SettingsButton:SetSize(settingsW, s(26))
	self.SettingsButton:SetPos(self.settingsBtnX, self.chatPanelY + s(10))
	self.SettingsButton:SetText("")
	self.SettingsButton:SetMouseInputEnabled(true)
	self.SettingsButton:SetKeyboardInputEnabled(false)
	self.SettingsButton:SetZPos(1000)
	self.SettingsButton.hovered = false
	self.SettingsButton.Paint = function(selff, w, h)
		draw.SimpleText("PARAMÈTRES", settingsFont, w / 2, h / 2,
			selff.hovered and CHAT_COL.accent or CHAT_COL.text_dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.SettingsButton.OnMousePressed = function(selff, keyCode)
		if keyCode == MOUSE_LEFT then
			PlayChatUISound(CHAT_SND_CLICK)
			OpenChatSettings()
		end
		return true
	end
	self.SettingsButton.OnCursorEntered = function()
		self.SettingsButton.hovered = true
		PlayChatUISound(CHAT_SND_HOVER)
	end
	self.SettingsButton.OnCursorExited = function()
		self.SettingsButton.hovered = false
	end

	-- Messages panel configuration (can be customized)
	self.messagesX = nil -- nil = auto (chatPanelX + 20)
	self.messagesY = self.chatPanelY + s(45) -- nil = auto (chatPanelY + 60)
	self.messagesWidth = nil -- nil = auto (chatPanelWidth - 40)
	self.messagesHeight = self.inputY - self.messagesY -- nil = auto (inputY - messagesY - 20)

	-- Messages panel (scrollable chat messages)
	self.Messages = vgui.Create("lzy_chat_messages", self)
	-- SECOND chat (staff) : même position, son propre historique. Un seul des deux
	-- est visible à la fois -> l'onglet ne fait que basculer la visibilité, donc on
	-- ne perd JAMAIS ce qui s'est dit dans l'autre.
	self.MessagesStaff = vgui.Create("lzy_chat_messages", self)
	self.activeTab = "rp"
	self:BuildTabs()
	self:UpdateMessagesPanelLayout()
	self:ApplyTab()

	self:SetFocused(false)
end

-- ── ONGLETS RP / STAFF ─────────────────────────────────────────────────────
-- Deux boutons plats dans le bandeau du haut, à droite du titre. L'onglet STAFF
-- n'existe que pour le staff : un joueur normal ne le voit même pas.
function PANEL:BuildTabs()
	self.Tabs = {}
	local tabs = { { id = "rp", label = "RP" }, { id = "staff", label = "STAFF" } }
	for _, t in ipairs(tabs) do
		local b = vgui.Create("DButton", self)
		b:SetText("")
		b.tabID = t.id
		b.tabLabel = t.label
		b.Paint = function(pnl, w, h)
			local actif = (self.activeTab == pnl.tabID)
			local col = actif and CHAT_COL.text or CHAT_COL.text_dim
			if pnl.hovered and not actif then col = CHAT_COL.text end
			draw.SimpleText(pnl.tabLabel, "Bebas Neue:" .. sFont(17), w * 0.5, h * 0.5,
				col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			-- Soulignement accent sur l'onglet actif (même signature que le titre).
			if actif then
				surface.SetDrawColor(CHAT_COL.accent.r, CHAT_COL.accent.g, CHAT_COL.accent.b, 235)
				surface.DrawRect(w * 0.12, h - math.max(1, s(2)), w * 0.76, math.max(1, s(2)))
			end
			-- Pastille : il s'est dit des choses dans l'autre onglet pendant qu'on n'y était pas.
			if not actif and pnl.tabID == "staff" and (self.staffUnread or 0) > 0 then
				surface.SetDrawColor(STAFF_CHAT_COLOR.r, STAFF_CHAT_COLOR.g, STAFF_CHAT_COLOR.b, 255)
				surface.DrawRect(w - s(7), s(5), s(5), s(5))
			end
		end
		b.OnCursorEntered = function(pnl) pnl.hovered = true end
		b.OnCursorExited  = function(pnl) pnl.hovered = false end
		b.DoClick = function(pnl)
			surface.PlaySound("ui/buttonclick.wav")
			self.activeTab = pnl.tabID
			if pnl.tabID == "staff" then self.staffUnread = 0 end
			self:ApplyTab()
		end
		self.Tabs[#self.Tabs + 1] = b
	end
	self:LayoutTabs()
end

function PANEL:LayoutTabs()
	if not self.Tabs then return end
	local tw, th = s(56), s(24)
	-- Visibilité d'abord (l'onglet STAFF n'apparaît QUE pour le staff) pour ne compter
	-- QUE les onglets réellement affichés dans le calcul de largeur.
	-- Hors focus : chrome masqué (aperçu message-only, pas d'onglets).
	local nVis = 0
	for _, b in ipairs(self.Tabs) do
		if IsValid(b) then
			local show = self.isFocused and (b.tabID ~= "staff" or IsLocalStaff())
			b:SetVisible(show)
			if show then nVis = nVis + 1 end
		end
	end
	-- Bord droit des onglets = juste à GAUCHE du bouton PARAMÈTRES (sa largeur RÉELLE, mémorisée
	-- dans Init), et non un s(46) FIXE : sinon l'onglet STAFF passait SOUS "PARAMÈTRES" (capture user).
	local rightEdge = (self.settingsBtnX or (self.chatPanelX + self.chatPanelWidth - s(46))) - s(8)
	local x = rightEdge - tw * nVis
	for _, b in ipairs(self.Tabs) do
		if IsValid(b) and b:IsVisible() then
			b:SetSize(tw, th)
			b:SetPos(x, self.chatPanelY + s(8))
			x = x + tw
		end
	end
end

-- Bascule la visibilité des deux historiques selon l'onglet courant.
function PANEL:ApplyTab()
	-- Sécurité : si on n'est plus staff (perte de grade), on retombe sur le RP.
	if self.activeTab == "staff" and not IsLocalStaff() then self.activeTab = "rp" end
	if IsValid(self.Messages)      then self.Messages:SetVisible(self.activeTab == "rp") end
	if IsValid(self.MessagesStaff) then self.MessagesStaff:SetVisible(self.activeTab == "staff") end
	self:LayoutTabs()
end

-- L'historique où écrire / afficher selon l'onglet courant.
function PANEL:ActiveMessages()
	if self.activeTab == "staff" and IsValid(self.MessagesStaff) then return self.MessagesStaff end
	return self.Messages
end

-- Si le canal courant n'est plus accessible (quitté le clan, division Aucune),
-- on retombe sur HRP pour ne pas envoyer un paquet que le serveur dropperait.
function PANEL:EnsureChannelSelectable()
	if not ChannelIsSelectable(self.currentChannel or "hrp") then
		self.currentChannel = "hrp"
	end
end

-- Passe au canal suivant (ou precedent si backwards), en sautant OOC desactive
-- et les canaux clan/div auxquels le joueur n'a pas droit.
function PANEL:CycleChannel(backwards)
	local list = {}
	for _, ch in ipairs(CHANNELS) do
		-- ROLL est GARDÉ dans le cycle (on peut le sélectionner), mais on ne peut PAS y
		-- parler : Entrée y lance un jet de dé (cf. filet dans InputLine.OnEnter).
		if ChannelIsSelectable(ch) then
			list[#list + 1] = ch.value
		end
	end
	if #list == 0 then return end

	local cur = 1
	for i, v in ipairs(list) do
		if v == self.currentChannel then
			cur = i
			break
		end
	end

	local nxt
	if backwards then
		nxt = (cur - 2) % #list + 1
	else
		nxt = cur % #list + 1
	end
	self.currentChannel = list[nxt]
end

function PANEL:UpdateMessagesPanelLayout()
	if not IsValid(self.Messages) then return end

	-- Calculate position and size (use custom values if set, otherwise auto-calculate)
	local messagesX = self.messagesX
	if messagesX == nil then
		messagesX = self.chatPanelX + s(20) -- 20px margin from left
	end

	local messagesY = self.messagesY
	if messagesY == nil then
		messagesY = self.chatPanelY + s(60) -- 60px from top (below buttons)
	end

	local messagesWidth = self.messagesWidth
	if messagesWidth == nil then
		messagesWidth = self.chatPanelWidth - s(40) -- 20px margin on each side
	end

	local messagesHeight = self.messagesHeight
	if messagesHeight == nil then
		-- Height: from messagesY to inputY, with 20px margin above input
		-- messagesY is already calculated above, so use it directly
		messagesHeight = self.inputY - messagesY - s(20)
	end

	self.Messages:SetPos(messagesX, messagesY)
	self.Messages:SetSize(messagesWidth, messagesHeight)
	-- Le chat staff occupe exactement la même zone (on n'en montre qu'un à la fois).
	if IsValid(self.MessagesStaff) then
		self.MessagesStaff:SetPos(messagesX, messagesY)
		self.MessagesStaff:SetSize(messagesWidth, messagesHeight)
	end
	self:LayoutTabs()
end

function PANEL:SetMessagesPanelPos(x, y)
	self.messagesX = x
	self.messagesY = y
	self:UpdateMessagesPanelLayout()
end

function PANEL:GetMessagesPanelPos()
	return self.messagesX, self.messagesY
end

function PANEL:SetMessagesPanelSize(width, height)
	self.messagesWidth = width
	self.messagesHeight = height
	self:UpdateMessagesPanelLayout()
end

function PANEL:GetMessagesPanelSize()
	return self.messagesWidth, self.messagesHeight
end

function PANEL:SetMessagesGap(gap)
	if IsValid(self.Messages) then
		self.Messages:SetMessageGap(gap)
	end
end

function PANEL:GetMessagesGap()
	if IsValid(self.Messages) then
		return self.Messages:GetMessageGap()
	end
	return 0
end

function PANEL:SetMessagePadding(top, bottom)
	-- Set padding for all existing messages
	if IsValid(self.Messages) then
		for _, msg in ipairs(self.Messages.messages) do
			if IsValid(msg) then
				msg:SetPadding(top, bottom)
			end
		end
	end
end

function PANEL:Paint(w, h)
	-- Aperçu message (hors focus) : pas de cadre / blur / titre — uniquement le
	-- fil de texte (évite de recouvrir le gameplay / les QTE d'entraînement).
	if not self.isFocused then return end

	local px, py = self.chatPanelX, self.chatPanelY
	local pw, ph = self.chatPanelWidth, self.chatPanelHeight

	-- Fond LÉGER translucide (le chat survole le gameplay, pas de plaque
	-- opaque) : blur derriere pour la lisibilite + voile sombre bas alpha,
	-- rect DROIT sans arrondi. (DA Atelier 07/07)
	RNDX.Draw(0, px, py, pw, ph, Color(255, 255, 255, 255), RNDX.BLUR)
	surface.SetDrawColor(CHAT_COL.bg.r, CHAT_COL.bg.g, CHAT_COL.bg.b, CHAT_COL.bg.a)
	surface.DrawRect(px, py, pw, ph)

	-- Définition minimale du cadre : liseré acier 1px bas alpha (les marqueurs
	-- en L dorés sont supprimés — la DA Atelier n'en a pas)
	DrawBorder(px, py, pw, ph, CHAT_COL.border, 1)

	-- Bandeau : titre Bebas + entaille slash1 accent (repli : barre accent),
	-- filet DENTÉ dessous (remplace le liseré doré plein)
	draw.SimpleText("CHAT", "Bebas Neue:" .. sFont(20), px + s(10), py + s(19),
		CHAT_COL.text_dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	surface.SetFont("Bebas Neue:" .. sFont(20))
	local twT, thT = surface.GetTextSize("CHAT")
	if not (EVO_UI and EVO_UI.Ink and EVO_UI.Ink(EVO_UI.TexSlash, px + s(8), py + s(19) + thT * 0.28, twT * 1.15, s(7), ColorAlpha(CHAT_COL.accent, 235))) then
		surface.SetDrawColor(CHAT_COL.accent.r, CHAT_COL.accent.g, CHAT_COL.accent.b, 235)
		surface.DrawRect(px + s(10), py + s(19) + thT * 0.34, twT, math.max(1, s(2)))
	end
	drawDashes(px + s(3), py + s(40), pw - s(6), Color(255, 255, 255, 26))

	-- Fond de l'input : plat sombre + ligne basse accent 2px
	local ix, iy, iw, ih = self.inputX, self.inputY, self.inputWidth, self.inputHeight
	surface.SetDrawColor(CHAT_COL.bg_inner.r, CHAT_COL.bg_inner.g, CHAT_COL.bg_inner.b, CHAT_COL.bg_inner.a)
	surface.DrawRect(ix, iy, iw, ih)
	local ut = math.max(1, s(2))
	surface.SetDrawColor(CHAT_COL.accent.r, CHAT_COL.accent.g, CHAT_COL.accent.b, 255)
	surface.DrawRect(ix, iy + ih - ut, iw, ut)
end

function PANEL:ScheduleHide(delay)
	delay = delay or 5 -- Default 5 seconds
	-- Cancel existing timer if any
	if self.hideTimer then
		timer.Remove(self.hideTimer)
		self.hideTimer = nil
	end
	if IsValid(_settingsFrame) then return end
	-- Schedule hide with unique timer name
	if not self.timerID then
		self.timerID = "LZY_ChatHide_" .. CurTime() .. "_" .. math.random(1000, 9999)
	end
	self.hideTimer = self.timerID
	timer.Create(self.hideTimer, delay, 1, function()
		if IsValid(self) and not self.isFocused and not IsValid(_settingsFrame) then
			self:SetVisible(false)
			self.isVisible = false
		end
		self.hideTimer = nil
	end)
end

function PANEL:SetFocused(focused)
	-- Cinématique d'intro (ncm_intro_cinematic) : on n'ouvre PAS le chat pendant la cine.
	if focused and EVO_IntroCine and EVO_IntroCine.Active then return end
	-- Mode cinématique (F7, ncm_cinematic) : idem, plan propre.
	if focused and IsCinematicActive and IsCinematicActive() then return end
	-- Entraînement scripté : saisie interdite (les messages restent visibles en aperçu).
	if focused and NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.IsClientBlocked and NCM_ENTRAINEMENT.IsClientBlocked() then return end
	local wasFocused = self.isFocused
	self.isFocused = focused
	-- Indicateur « ... » au-dessus de la tête (evo_me_indicator) : open/close chat.
	if wasFocused ~= focused then
		hook.Run("LZY_ChatFocusChanged", focused)
	end
	if focused then
		self:EnsureChannelSelectable()
		ChatHistReset() -- ↑/↓ repart du message le plus récent à chaque ouverture du chat
		-- Cancel any pending hide timer
		if self.hideTimer then
			timer.Remove(self.hideTimer)
			self.hideTimer = nil
		end
		-- Make panel popup first to ensure it can receive input
		self:MakePopup()
		-- Enable keyboard input
		self:SetKeyboardInputEnabled(true)
		self:SetMouseInputEnabled(true)
		-- Show panel and input
		self:SetVisible(true)
		self.isVisible = true
		self.InputLine:SetVisible(true)
		if self.ChannelButton then
			self.ChannelButton:SetVisible(true)
			self.ChannelButton:SetMouseInputEnabled(true)
		end
		if IsValid(self.CloseButton) then self.CloseButton:SetVisible(true) end
		if IsValid(self.SettingsButton) then self.SettingsButton:SetVisible(true) end
		self:ApplyTab()
		-- Enable cursor for input
		gui.EnableScreenClicker(true)
		-- Request focus on input with multiple retries to ensure it works
		local function requestFocus(attempt)
			attempt = attempt or 1
			if IsValid(self) and IsValid(self.InputLine) and self.isFocused then
				self.InputLine:RequestFocus()
				-- If still not focused after a delay, retry (up to 3 times)
				if attempt < 3 then
					timer.Simple(0.15, function()
						if IsValid(self) and IsValid(self.InputLine) and self.isFocused then
							-- Check if input actually has focus
							if vgui.GetKeyboardFocus() ~= self.InputLine then
								requestFocus(attempt + 1)
							end
						end
					end)
				end
			end
		end
		-- Start focus request after a short delay
		timer.Simple(0.1, function()
			requestFocus(1)
		end)
	else
		-- Ferme la liste déroulante de canaux restée ouverte (Échap / × / OnClose) :
		-- le DermaMenu est un popup indépendant, il ne se ferme pas avec le chat.
		if IsValid(self.ChannelMenu) then
			self.ChannelMenu:Remove()
			self.ChannelMenu = nil
		end
		self.InputLine:SetVisible(false)
		self.InputLine:KillFocus()
		if self.ChannelButton then
			self.ChannelButton:SetVisible(false)
			self.ChannelButton:SetMouseInputEnabled(false)
		end
		if IsValid(self.CloseButton) then self.CloseButton:SetVisible(false) end
		if IsValid(self.SettingsButton) then self.SettingsButton:SetVisible(false) end
		if self.Tabs then
			for _, b in ipairs(self.Tabs) do
				if IsValid(b) then b:SetVisible(false) end
			end
		end
		self:SetKeyboardInputEnabled(false)
		gui.EnableScreenClicker(false)
		self:SetVisible(false)
		self.isVisible = false
	end
end

function PANEL:ShowForMessage()
	-- Cinématique d'intro : pas de pop-up chat pendant la cine (le message reste dans l'historique).
	if EVO_IntroCine and EVO_IntroCine.Active then return end
	-- Mode cinématique (F7, ncm_cinematic) : idem, le message reste dans l'historique.
	if IsCinematicActive and IsCinematicActive() then return end
	-- Aperçu message-only (sans cadre / input) — y compris pendant un entraînement.
	if not self.isFocused then
		-- Disable keyboard and mouse input to prevent popup from enabling cursor
		self:SetKeyboardInputEnabled(false)
		self:SetMouseInputEnabled(false)
		self:SetVisible(true)
		self.isVisible = true
		-- Chrome UI masqué : on ne montre que le fil de messages.
		if IsValid(self.CloseButton) then self.CloseButton:SetVisible(false) end
		if IsValid(self.SettingsButton) then self.SettingsButton:SetVisible(false) end
		if self.Tabs then
			for _, b in ipairs(self.Tabs) do
				if IsValid(b) then b:SetVisible(false) end
			end
		end
		self:ApplyTab()
		-- Pendant un aperçu live, ne pas couper le curseur (sinon le drag casse)
		if not _liveApplying then
			gui.EnableScreenClicker(false)
		end

		self:ScheduleHide(LZY_CHAT_SETTINGS.hide_delay or CHAT_DEFAULTS.hide_delay)
	end
end

function PANEL:OnKeyCodePressed(keycode)
	if keycode == KEY_ENTER then
		-- Ne pas rouvrir si on vient d'envoyer un message (la même touche Entrée)
		if CurTime() < _suppressOpenUntil then return end
		if not self.isFocused then
			self:SetFocused(true)
		end
		return true
	elseif keycode == KEY_ESCAPE then
		if self.isFocused then
			-- Unfocus
			self:SetFocused(false)
			return true
		end
	end
end

function PANEL:OnClose()
	-- Cancel any pending hide timer
	if self.hideTimer then
		timer.Remove(self.hideTimer)
		self.hideTimer = nil
	end
	-- Don't destroy the panel, just unfocus it
	self:SetFocused(false)
end

function PANEL:OnRemove()
	-- Clean up timer when panel is removed
	if self.hideTimer then
		timer.Remove(self.hideTimer)
		self.hideTimer = nil
	end
end

function PANEL:AddMessage(name, text, nameCol, textCol, isMeMessage, messageType, messageID, senderSid)
	-- CHAT STAFF : il part dans SON historique, pas dans le fil RP. C'est ce qui en
	-- fait un vrai second chat et pas une catégorie -> le RP n'est jamais pollué.
	if messageType == "staff" then
		if not IsValid(self.MessagesStaff) then return end
		self.MessagesStaff:AddMessage(name, text, nameCol, textCol, isMeMessage, messageType, messageID, senderSid)
		self:ShowForMessage()
		-- Pastille sur l'onglet si on est en train de lire le RP.
		if self.activeTab ~= "staff" then self.staffUnread = (self.staffUnread or 0) + 1 end
		return
	end

	-- Canal masque : on garde le message (stocke) mais on ne fait pas apparaitre
	-- le chat. Sinon, comportement normal (popup + affichage).
	if not IsChannelHidden(messageType) then
		self:ShowForMessage()
	end
	-- Add message to chat (if Messages panel exists)
	if self.Messages then
		self.Messages:AddMessage(name, text, nameCol, textCol, isMeMessage, messageType, messageID, senderSid)
	end
end

vgui.Register("lzy_chat", PANEL, "DFrame")

-- Hide default GMod chat HUD element
hook.Add("HUDShouldDraw", "LZY:HideDefaultChat", function(name)
	if name == "CHudChat" then
		return false
	end
end)

-- Create chat panel once when player spawns
hook.Add("PlayerSpawn", "LZY:CreateChatPanel", function(ply)
	if not IsValid(frame) then
		frame = vgui.Create("lzy_chat")
	end
end)

-- Initialize chat panel on client init
hook.Add("Initialize", "LZY:CreateChatPanel", function()
	if not IsValid(frame) then
		frame = vgui.Create("lzy_chat")
	end
end)

-- Press the chat key (bind "messagemode", defaut T) ou Entrée pour ouvrir/focus le chat.
hook.Add("PlayerButtonDown", "LZY:OpenChat", function(ply, button)
	local isChatKey  = button == GetChatKey()
	local isEnterKey = button == KEY_ENTER or button == KEY_PAD_ENTER
	-- Entrée ouvre le chat (demande user), MAIS on ne vole pas la touche si un autre
	-- champ de saisie a deja le focus clavier (valider un dialogue/texte ailleurs ne
	-- doit pas ouvrir le chat par-dessus). Le bind "messagemode" garde son comportement.
	if isEnterKey and not isChatKey then
		local focus = vgui.GetKeyboardFocus()
		if IsValid(focus) and (not IsValid(frame) or focus ~= frame.InputLine) then return end
	end
	if isChatKey or isEnterKey then
		-- Entraînement scripté (QTE) : les touches passent pendant un QTE, le chat
		-- s'ouvrait par-dessus et le masquait. On refuse tant que ça bloque.
		if NCM_ENTRAINEMENT and NCM_ENTRAINEMENT.IsClientBlocked and NCM_ENTRAINEMENT.IsClientBlocked() then return end
		-- Ne pas rouvrir si on vient d'envoyer un message
		if CurTime() < _suppressOpenUntil then return end
		if IsValid(frame) then
			-- Always focus the chat when the chat key is pressed
			if not frame.isFocused then
				frame:SetFocused(true)
			end
		end
	end
end)

-- Entraînement scripté lancé pendant que le joueur écrivait : on ferme la saisie.
-- L'aperçu message-only (texte seul, sans cadre) reste autorisé via ShowForMessage.
hook.Add("EVO::TrainingBlockedStart", "LZY:Chat:UnfocusOnTraining", function()
	if IsValid(frame) and frame.isFocused then
		frame:SetFocused(false)
	end
end)

-- Prevent GMod escape menu when chat is focused
hook.Add("PlayerButtonDown", "LZY:Chat:PreventEscapeMenu", function(ply, button)
	if button == KEY_ESCAPE then
		if IsValid(frame) and frame.isFocused then
			-- Unfocus chat and prevent escape menu
			frame:SetFocused(false)
			return true -- Prevent default behavior
		end
	end
end)

-- Prevent escape menu from opening when chat is focused
hook.Add("OnPauseMenuShow", "LZY:Chat:PreventEscapeMenu2", function()
	if IsValid(frame) and frame.isFocused then
		-- Unfocus chat and prevent escape menu
		frame:SetFocused(false)
		return false -- Prevent menu from showing
	end
end)

-- Receive chat messages from server
net.Receive("LZY:ReceiveChat", function()
	local sender = net.ReadEntity()
	local text = net.ReadString()
	local messageType = net.ReadString()
	if messageType == "" then messageType = "looc" end
	local dead = net.ReadBool()
	local colorR = net.ReadUInt(8)
	local colorG = net.ReadUInt(8)
	local colorB = net.ReadUInt(8)
	local messageID = net.ReadUInt(32)
	if messageID == 0 then messageID = nil end -- 0 = systeme, non supprimable

	if not IsValid(frame) then return end

	-- Nom du joueur (logique DoIKnowHim). Sender peut etre le monde (msg systeme).
	-- CHAT STAFF : on affiche TOUJOURS le vrai pseudo (demande user « on voit les noms
	-- d'office ») — entre staff on doit savoir qui parle, pas « Inconnu ».
	local name
	if messageType == "staff" and IsValid(sender) and sender:IsPlayer() then
		name = sender:Nick()
	else
		name = (IsValid(sender) and sender:IsPlayer()) and GetPlayerDisplayName(sender) or ""
	end
	local nameColor = Color(colorR, colorG, colorB, 255)
	-- Couleur de POLICE du message = couleur du canal (looc/ooc = blanc ; nar=bleu,
	-- ad=orange, report=rouge, fac=magenta, it=bleu clair, ...). Le pseudo garde sa
	-- couleur aléatoire perso. Les morts repassent en gris plus bas.
	local textColor = CHANNEL_COLORS[messageType] or Color(255, 255, 255, 255)

	-- me / roll : le nom est deja dans le texte -> pas de nom affiche.
	-- nar (Narration, alias /na) : texte impersonnel -> AUCUN pseudo affiché (demande user).
	-- it : même nature que nar (narration), donc même règle. L'oublier ici aurait
	-- suffi à trahir l'auteur d'une narration censée être impersonnelle.
	local hideName = (messageType == "me" or messageType == "roll"
		or messageType == "nar" or messageType == "it")

	-- MODÉRATION (demande user 08/07) : un modérateur+ voit l'AUTEUR des narrations
	-- (/na, /it), sinon impersonnelles — c'est le seul canal où un joueur peut poster
	-- sans que personne ne sache qui c'est. Purement CLIENT : chaque client décide selon
	-- SON propre rang, aucun paquet supplémentaire (l'entité auteur est déjà networkée
	-- pour tous). Le préfixe ⚑ rappelle que ce pseudo n'est visible QUE du staff — sans
	-- lui, un modo pourrait croire l'auteur public et sanctionner de travers.
	if hideName and (messageType == "nar" or messageType == "it")
		and LZY_Chat_CanSeeNarrationAuthor(LocalPlayer()) and IsValid(sender) and sender:IsPlayer() then
		hideName = false
		name = "⚑ " .. sender:Nick()
	end

	if hideName then name = "" end

	-- Prefixe joueurs morts
	if dead then
		name = "*DEAD* " .. name
		textColor = Color(200, 200, 200, 255) -- Gray text for dead players
		nameColor = Color(200, 200, 200, 255)
	end

	local senderSid = IsValid(sender) and sender:IsPlayer() and sender:SteamID64() or nil
	frame:AddMessage(name, text, nameColor, textColor, hideName, messageType, messageID, senderSid)
end)

-- ============================================================================
-- API PUBLIQUE : ajoute une ligne SYSTÈME (sans pseudo) dans un canal donné.
-- Utilisée par d'autres addons pour écrire dans un canal (ex: world boss -> "nar"
-- = canal Narration). Couleur = celle du canal ; isMeMessage=true -> AUCUN
-- "pseudo: " devant (sinon le Paint dessine un ": " parasite). messageID nil =
-- système, non supprimable. No-op tant que le chat n'est pas créé.
-- ============================================================================
function LZY_Chat_AddSystemLine(channel, text)
	if not IsValid(frame) then return end
	channel = channel or "nar"
	local col = CHANNEL_COLORS[channel] or Color(255, 255, 255, 255)
	frame:AddMessage("", tostring(text or ""), col, col, true, channel, nil)
end

-- Annonces PvP (capture de drapeau / zone, batailles de clans, …) : canal EVENT.
-- Même contrat que AddSystemLine : no-op si le chat n'est pas encore créé.
function LZY_Chat_AddEventLine(text)
	LZY_Chat_AddSystemLine("events", text)
end

-- Annonces faction / division (bannières HUD) : canal ANNONCE. Même contrat.
function LZY_Chat_AddAnnonceLine(text)
	LZY_Chat_AddSystemLine("annonce", text)
end

-- Suppression d'un message par la moderation : on retire le panel correspondant
-- (les clients qui n'ont pas ce message ignorent simplement).
net.Receive("LZY:ChatDeleted", function()
	local id = net.ReadUInt(32)
	if id == 0 or not IsValid(frame) then return end

	for _, list in pairs({frame.Messages, frame.MessagesStaff}) do
		if IsValid(list) then
			local msgs, removed = list.messages, false
			for i = #msgs, 1, -1 do
				local m = msgs[i]
				if IsValid(m) and m.messageID == id then
					m:Remove()
					table.remove(msgs, i)
					removed = true
				end
			end
			if removed then list:RepositionMessages() end
		end
	end
end)

-- Receive /me messages from server : texte au-dessus de la tete + ligne de chat
-- "* Nom action" (canal ME). D'autres addons emettent directement ce message
-- (ex: shikai), donc l'affichage chat reste pilote ici.
net.Receive("LZY:ReceiveMeChat", function()
	local sender = net.ReadEntity()
	local meText = net.ReadString()
	local dead = net.ReadBool()
	-- ID optionnel en fin de paquet : present uniquement quand le message vient
	-- de NOTRE serveur. Les addons externes (shikai, menotte, ...) n'ecrivent pas
	-- ce champ -> on ne lit l'ID que s'il reste au moins 4 octets a lire.
	local messageID = nil
	if (net.BytesLeft() or 0) >= 4 then
		messageID = net.ReadUInt(32)
		if messageID == 0 then messageID = nil end
	end

	if not IsValid(sender) or not IsValid(frame) then return end

	local name = GetPlayerDisplayName(sender) -- Use DoIKnowHim logic

	-- Store message to display above player's head
	playerMeMessages[sender] = {
		text = meText,
		time = CurTime(),
		dead = dead,
		type = "me",
	}

	-- Purge a 10 s : DOIT rester alignee sur le fondu du rendu 3D2D (plus bas).
	-- Si ce nombre est plus petit, le texte disparait d'un coup en plein fondu ;
	-- s'il est plus grand, il reste affiche a alpha 0 pour rien.
	timer.Simple(10, function()
		if playerMeMessages[sender] then
			playerMeMessages[sender] = nil
		end
	end)

	-- Display in chat with gray color and italic font (canal ME)
	local grayColor = Color(200, 200, 200)
	local senderSid = sender:IsPlayer() and sender:SteamID64() or nil
	frame:AddMessage("", "* " .. name .. " " .. meText, grayColor, grayColor, true, "me", messageID, senderSid)
end)

-- Receive /roll messages from server (texte au-dessus de la tete uniquement).
net.Receive("LZY:ReceiveRollChat", function()
	local sender = net.ReadEntity()
	local rollText = net.ReadString()
	local dead = net.ReadBool()

	if not IsValid(sender) then return end

	playerMeMessages[sender] = {
		text = rollText,
		time = CurTime(),
		dead = dead,
		type = "roll",
	}

	-- Purge a 10 s : DOIT rester alignee sur le fondu du rendu 3D2D (plus bas).
	-- Si ce nombre est plus petit, le texte disparait d'un coup en plein fondu ;
	-- s'il est plus grand, il reste affiche a alpha 0 pour rien.
	timer.Simple(10, function()
		if playerMeMessages[sender] then
			playerMeMessages[sender] = nil
		end
	end)
end)

-- Handle chat messages
hook.Add("ChatText", "LZY:ChatText", function(index, name, text, type)
	-- Pas de notif de connexion/déconnexion dans le chat ("X a rejoint le serveur").
	-- On skippe le type moteur "joinleave" ET on renvoie true pour couper aussi
	-- l'affichage par défaut du chat moteur.
	if type == "joinleave" then return true end
	if IsValid(frame) then
		frame:AddMessage(name, text, nil, nil, false, "ooc")
	end
end)

concommand.Add("lzy_chat", function(ply, cmd, args)
	local name = ply:Nick()
	local text = "Hello, world!"
	if IsValid(frame) then
		frame:AddMessage(name, text, nil, nil, false, "looc")
	end
end)

-- Draw /me messages above player heads
-- Rendu en PostDrawEffects = APRÈS le composite des halos (shikai / aura-vision), pour que le
-- contour additif ne déteigne PAS sur le texte /me. PostPlayerDraw(ply) ne donnait que les
-- joueurs en cours de rendu -> ici on itère les /me ACTIFS (cull distance 500u inchangé).
-- Pas de cam.IgnoreZ -> le texte reste occludé par les murs/props (depth de la scène encore en place).
hook.Add("PostDrawEffects", "LZY:DrawMeMessages", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- Créateur / HUB : pas de /me flottant sur des joueurs masqués (PrePlayerDraw).
	-- Même filet local que lzy_meet (NW InCharacterMenu peut laguer).
	if lp:GetEvoNWBool("InCharacterMenu", false)
		or (LZY_Character_IsLocalInCharMenu and LZY_Character_IsLocalInCharMenu()) then return end
	local myPos = lp:GetPos()
	local nNow  = CurTime()
	local eyePos = EyePos()

	for ply, meData in pairs(playerMeMessages) do
		-- Cible au menu perso / NoDraw : pas de /me flottant sur un corps invisible
		-- (InCharacterMenu remote peut dropper ; SetNoDraw hub reste la vérité moteur).
		if not IsValid(ply) or not meData then continue end
		if ply:GetEvoNWBool("InCharacterMenu", false) or ply:GetNoDraw() then continue end
		if myPos:Distance(ply:GetPos()) <= 500 then
			-- Hauteur HARMONISÉE avec le nametag lzy_meet (80 × échelle du modèle) : les
			-- bounds du modèle sont trompeurs ici (face.mdl custom = bounds minuscules,
			-- modèle complet = 72 -> le /me flottait à ~112u au-dessus de la tête, « trop
			-- haut », report user 07/17). Légèrement AU-DESSUS du nom (94 vs 80) pour
			-- coexister proprement quand les deux s'affichent en même temps.
			local headPos = ply:GetPos() + Vector(0, 0, 94 * (ply:GetModelScale() or 1))

			-- Duree DOUBLEE : 10 s au lieu de 5, fondu sur les 2 dernieres secondes
			-- (demande user 2026-07-28). Une narration fait souvent plusieurs lignes, et
			-- 4 s de pleine opacite ne suffisaient pas a la lire — surtout si on tourne la
			-- tete au mauvais moment. Le fondu passe de 1 s a 2 s pour rester proportionne.
			local timeElapsed = nNow - meData.time
			local alpha = 255
			if timeElapsed > 8 then
				alpha = math.Clamp(255 * ((10 - timeElapsed) / 2), 0, 255)
			end

			-- Calculate angle to face camera (same method as lzy_meet for consistency)
			local dir = (eyePos - headPos):Angle()
			local ang = Angle(0, dir.y, 0)
			ang:RotateAroundAxis(ang:Right(), 90)
			ang:RotateAroundAxis(ang:Up(), -90)
			ang:RotateAroundAxis(ang:Right(), 180)

			-- Start 3D2D rendering (use same scale as name tag for consistency)
			cam.Start3D2D(headPos, ang, 0.2)
				local grayColor = Color(200, 200, 200, alpha)
				-- /me garde l'asterisque ; /roll affiche "obtient X" sans prefixe
				local prefix = (meData.type == "roll") and "" or "* "
				local text = prefix .. meData.text

				-- Draw text with outline — police style shop (Avenir), scale uniforme
				draw.SimpleTextOutlined(
					text,
					"Avenir Next World:" .. sFont(22),
					0, 0,
					grayColor,
					TEXT_ALIGN_CENTER,
					TEXT_ALIGN_CENTER,
					1,
					Color(0, 0, 0, alpha)
				)
			cam.End3D2D()
		end
	end
end)
