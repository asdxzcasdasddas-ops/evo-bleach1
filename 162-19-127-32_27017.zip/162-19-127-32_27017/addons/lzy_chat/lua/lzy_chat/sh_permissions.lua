-- "addons\\lzy_chat\\lua\\lzy_chat\\sh_permissions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Meme droit dans le menu client et le recepteur serveur. Les helpers staff
-- resolvent les rangs canoniques et leurs alias SAM sans dupliquer les listes.
function LZY_Chat_CanModerate(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	return ply:IsSuperAdmin()
		or (EVO_IsRespoModo ~= nil and EVO_IsRespoModo(ply))
		or (EVO_IsModoPlus ~= nil and EVO_IsModoPlus(ply))
end

-- Ne pas injecter dans le dashboard un profil masque par ses regles serveur.
function LZY_Chat_CanOpenStaffProfile(actor, target)
	if not LZY_Chat_CanModerate(actor) or not (IsValid(target) and target:IsPlayer()) then return false end
	if actor:IsSuperAdmin() then return true end
	if target:IsSuperAdmin() then return false end
	if EVO_IsRespoModo and EVO_IsRespoModo(target) and not EVO_IsRespoModo(actor) then return false end
	return true
end
