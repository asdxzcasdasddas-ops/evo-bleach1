-- "addons\\lzy_coiffeur\\lua\\entities\\lzy_coiffeur_npc\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

-- Font pour le nametag 3D2D. Creee une seule fois au chargement client.
surface.CreateFont("LZY_Coiffeur_NameTag", {
	font      = "Roboto",
	size      = 64,
	weight    = 800,
	antialias = true,
	outline   = false,
})

-- RENDERGROUP_BOTH : model en passe OPAQUE (Draw), nametag en passe TRANSLUCIDE
-- (DrawTranslucent) qui tourne APRES tous les props -> avec IgnoreZ le nametag
-- ne peut plus etre occluded par un prop dessine devant.
ENT.RenderGroup = RENDERGROUP_BOTH

-- Hauteur de l'invite (E) d'evo_npc_core = celle de l'étiquette de nom.
ENT.EVO_PromptZ = 100

-- Pré-alloc : évite 2 Color() + 1 GetTextSize par frame (le nom est constant).
local COL_TAG_BG  = Color(0, 0, 0, 180)
local COL_TAG_TXT = Color(255, 255, 255, 255)
local _tagName, _tagTW, _tagTH = nil, 0, 0

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	-- Nametag 3D2D au-dessus de la tete, billboard yaw-only face au joueur.
	-- Distance cull a 750u (avant 1500u : portee de lecture trop large vu la
	-- taille du tag).
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ePos = self:GetPos()
	if ePos:DistToSqr(lp:GetPos()) > 750 * 750 then return end

	local cfg = LZY_COIFFEUR and LZY_COIFFEUR.Config or {}
	local name = cfg.NPCName or "Coiffeur"
	-- Étiquette unifiée (EVO_ZonePrompt) ; l'ancienne boîte noire ci-dessous reste en repli.
	if EVO_ZonePrompt and EVO_ZonePrompt.NpcTag then EVO_ZonePrompt.NpcTag(self, name, 100, nil, 750, "parler") return end

	-- Position : ~100u au-dessus de l'origin (model humain ~72u + ~28u de
	-- separation visuelle au-dessus de la tete pour que le tag soit clairement
	-- detache du model).
	local pos = ePos + Vector(0, 0, 100)

	-- Billboard yaw-only : face TOUJOURS la caméra de rendu (EyePos), pas l'angle du
	-- joueur -> suit la caméra orbitale (citron_orbit_camera) quand on tourne la vue
	-- sans bouger. roll = 90 redresse le texte ; pitch = 0 le garde horizontal.
	local ang = Angle(0, (pos - EyePos()):Angle().y - 90, 90)

	-- cam.IgnoreZ : le nametag est dessine sans depth test pour rester visible
	-- meme quand le model NPC (opaque) ou d'autres entites se trouvent entre
	-- la camera et le tag. Sans ca, le 3D2D etait occluded par les entites
	-- draw apres dans le opaque pass (effet "nametag derriere l'entite").
	cam.IgnoreZ(true)
	cam.Start3D2D(pos, ang, 0.15)
		if _tagName ~= name then
			_tagName = name
			surface.SetFont("LZY_Coiffeur_NameTag")
			_tagTW, _tagTH = surface.GetTextSize(name)
		end
		-- Background carré semi-transparent (DA : plus de pill arrondie).
		draw.RoundedBox(0, -_tagTW * 0.5 - 16, -_tagTH * 0.5 - 6, _tagTW + 32, _tagTH + 12, COL_TAG_BG)
		draw.SimpleText(name, "LZY_Coiffeur_NameTag", 0, 0,
			COL_TAG_TXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end
