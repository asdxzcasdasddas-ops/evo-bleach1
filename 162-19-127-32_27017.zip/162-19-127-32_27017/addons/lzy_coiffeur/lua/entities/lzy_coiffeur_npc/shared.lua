-- "addons\\lzy_coiffeur\\lua\\entities\\lzy_coiffeur_npc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Entity coiffeur PNJ (anim simple, pas de NextBot/AI). Spawn via le code
-- serveur de l'addon. Le joueur interagit via PlayerUse (+use / E) ou via
-- prompt client a proximite.

ENT.Type        = "anim"
ENT.Base        = "base_anim"
ENT.PrintName   = "Coiffeur"
ENT.Author      = "lzy_coiffeur"
ENT.Spawnable   = false -- pas dans le Q menu, spawn auto via config
ENT.AdminOnly   = true

function ENT:SetupDataTables()
	-- Flag NW pour le hud client (prompt d'interaction) et pour identifier
	-- l'entity rapidement sans lire la classe.
	self:NetworkVar("Bool", 0, "IsCoiffeur")
end
