-- "addons\\lzy_coiffeur\\lua\\autorun\\sh_loader_coiffeur.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Loader addon Coiffeur (PNJ qui ouvre le character creator en mode edit, sans
-- possibilite de changer le nom). Charge la config + les fichiers serveur /
-- client + ajoute les net strings.

LZY_COIFFEUR = LZY_COIFFEUR or {}

if SERVER then
	AddCSLuaFile("lzy_coiffeur/sh_config.lua")
	AddCSLuaFile("lzy_coiffeur/cl_main.lua")

	util.AddNetworkString("LZY_Coiffeur:OpenEditor") -- server -> client : ouvre l'editeur avec la data character actuelle
	util.AddNetworkString("LZY_Coiffeur:SaveEdit")   -- client -> server : applique les modifs (sans nom)
end

include("lzy_coiffeur/sh_config.lua")

if SERVER then
	include("lzy_coiffeur/sv_main.lua")
else
	include("lzy_coiffeur/cl_main.lua")
end
