-- "addons\\lzy_coiffeur\\lua\\lzy_coiffeur\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Config addon Coiffeur

LZY_COIFFEUR = LZY_COIFFEUR or {}
LZY_COIFFEUR.Config = LZY_COIFFEUR.Config or {}

local CFG = LZY_COIFFEUR.Config

-- Modele du PNJ coiffeur. Doit etre un .mdl valide accessible cote serveur ET
-- client (sinon le PNJ apparait sous forme de point d'erreur rose & noir).
-- Par defaut : un model PNJ shinigami existant (soulreaper_a) qui est deja
-- charge sur le serveur (utilise par ncm_pnj).
CFG.NPCModel = "models/evo/summons/shinigami/evo_bdfze942fzd3sdaadxdzd/evo_Bdfze942fzd3sdaadXDZD.mdl" -- casse exacte fournie par le user (2026-06)
-- Hueco Mundo = serveur Arrancar : ce PNJ y est un Arrancar (demande user 2026-07-24).
-- Override AVANT le repli de validité ci-dessous (il protège donc aussi ce modèle).
-- Le Seireitei garde son modèle Shinigami.
if game.GetMap() == "hueco_mundo_v1" then
	CFG.NPCModel = "models/evo/summons/arrancar/evo_w42qywutq3awo/evo_k87h3m96ffoee2.mdl"
end
-- Repli auto : modèle dédié absent -> modèle commun (le PNJ reste un vendeur).
if SERVER and not util.IsValidModel(CFG.NPCModel) then
	print("[Coiffeur] modele dedie absent (" .. CFG.NPCModel .. ") -> fallback modele commun")
	CFG.NPCModel = "models/evo/summons/shinigami/evo_6kgr5pap4was1w4i4/evo_0z6x7pjz5zgl.mdl"
end

-- Skin du model (si le model a plusieurs skins). 0 = default.
CFG.NPCSkin = 0

-- Bodygroups : table { [bg_index] = sub_index, ... } a appliquer apres spawn.
-- Laisse vide {} si pas besoin.
CFG.NPCBodygroups = {}

-- Echelle visuelle du PNJ (1.0 = taille normale du model).
CFG.NPCScale = 1.0

-- Nom affiche au-dessus du PNJ (3D2D billboard) + dans le prompt.
CFG.NPCName = "Coiffeur"

-- Description sous le nom dans le prompt d'interaction.
CFG.NPCSubtitle = "Modifie ton apparence"

-- Check ENT:Use mis LARGE (200) : l'interaction passe par evo_npc_interact
-- (détection E client -> net -> ENT:Use) jusqu'à PromptDistance, ce check ne doit
-- donc pas bloquer dans cette portée (le +use natif reste ~90u, c'est OK).
CFG.InteractDistance = 200

-- Portée d'interaction réelle = affichage du prompt ET du clic (E marche jusque-là
-- via evo_npc_interact). Demande user : pouvoir parler de loin sans se coller au PNJ.
CFG.PromptDistance = 160

-- Touche d'interaction (par defaut : E / +use). KEY_* constants GMod.
-- Laisse a KEY_E ou utilise IN_USE via PlayerUse hook (deja gere cote sv).
CFG.InteractKey = KEY_E

-- Positions de spawn des coiffeurs, par map. Chaque entree = un PNJ.
-- pos = Vector(x, y, z), ang = Angle(pitch, yaw, roll).
-- Pour ajouter une position : ramasse les coords avec `getpos` console.
CFG.SpawnPositions = {
	rp_seireitei_v1 = {
		-- Avance de ~100u dans la direction du regard (yaw 177.75°)
		{ pos = Vector(-1573.928023, -11399.395728, 427.765717), ang = Angle(0, 177.754608, 0) },
	},
	hueco_mundo_v1 = {
		-- Pos user 2026-06 (setpos 2710.77 7953.03 5359.37, regard yaw 85.40).
		-- Yaw BRUT : le +180 le mettait pile à l'envers (vérifié in-game).
		{ pos = Vector(2710.770752, 7953.031250, 5359.369629), ang = Angle(0, 85.40, 0) },
	},
	-- gm_construct : a cote de la zone de spawn, sur le sol beton plat, face
	-- au spawn pour que le PNJ regarde le joueur quand il arrive.
	gm_construct = {
		{ pos = Vector(80, -80, -135), ang = Angle(0, 90, 0) },
	},
}

-- Distance verticale (Z) max pour qu'un joueur soit considere "proche" du PNJ
-- meme s'il est sur un etage different (evite que le prompt apparaisse a un
-- joueur 3 etages au-dessus du PNJ).
CFG.MaxZDelta = 200

-- Cout en yens du service de coiffure. Debite quand le joueur clique sur
-- "Terminer" pour valider ses modifs. Si le joueur n'a pas assez, la save
-- est refusee et un message lui est affiche.
CFG.PriceYens = 500

-- Prix EFFECTIF pour ce joueur : GRATUIT pour un perso ANIMATION (NWBool
-- EVO_AnimChar, pose serveur par lzy_character, non spoofable) — l'animateur
-- prepare ses persos d'evenement sans frais (demande user 08/20). PARTAGE
-- client/serveur : le prompt [E], la popup de confirmation et les debits SQL
-- lisent le MEME prix ; a 0 tous les blocs `if price > 0` se sautent d'eux-memes.
function CFG.PrixPour(ply)
	if IsValid(ply) and ply:GetEvoNWBool("EVO_AnimChar", false) then return 0 end
	return tonumber(CFG.PriceYens) or 0
end
