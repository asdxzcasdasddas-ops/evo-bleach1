-- "addons\\lzy_coiffeur\\lua\\lzy_coiffeur\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Client-side coiffeur : prompt HUD a proximite + reception du net "OpenEditor".

LZY_COIFFEUR = LZY_COIFFEUR or {}
local CFG = LZY_COIFFEUR.Config or {}

----------------------------------------------------------------------
-- Prompt HUD "Appuyer E pour parler" quand a portee d'un coiffeur
----------------------------------------------------------------------

local function findNearestCoiffeur()
	local lp = LocalPlayer()
	if not IsValid(lp) then return nil, math.huge end

	local lpPos = lp:GetPos()
	local promptDist = tonumber(CFG.PromptDistance) or 250
	local maxZ = tonumber(CFG.MaxZDelta) or 200
	local promptDistSqr = promptDist * promptDist

	local best, bestDistSqr = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("lzy_coiffeur_npc")) do
		if IsValid(ent) then
			local ePos = ent:GetPos()
			if math.abs(ePos.z - lpPos.z) <= maxZ then
				local d2 = ePos:DistToSqr(lpPos)
				if d2 <= promptDistSqr and d2 < bestDistSqr then
					best, bestDistSqr = ent, d2
				end
			end
		end
	end
	return best, bestDistSqr
end

surface.CreateFont("LZY_Coiffeur_Prompt", {
	font     = "Roboto",
	size     = 22,
	weight   = 600,
	antialias = true,
})
surface.CreateFont("LZY_Coiffeur_Subtitle", {
	font     = "Roboto",
	size     = 16,
	weight   = 400,
	antialias = true,
})

-- Prompt « [E] Parler … » : DESSINÉ PAR LE SYSTÈME CENTRAL evo_npc_core (même UI plaque
-- Atelier + même logique « le plus proche affiche » pour TOUS les PNJ, user 2026-07-17).
-- (Créateur/éditeur ouvert = curseur visible -> le core masque déjà le prompt ; on garde
-- le flag barber en ceinture-bretelles.)
EVO_NPC_PROMPTS = EVO_NPC_PROMPTS or {}
EVO_NPC_PROMPTS["coiffeur"] = {
	fGetTarget = function()
		if LZY_CHARACTER_BARBER_MODE then return nil end
		return (findNearestCoiffeur())
	end,
	fLabel = function() return "[E] Parler au " .. (CFG.NPCName or "Coiffeur") end,
	fSub = function()
		-- PrixPour : 0 pour un perso ANIMATION -> affiche « Gratuit » plutôt que le tarif.
		local price = CFG.PrixPour(LocalPlayer())
		if price <= 0 and (tonumber(CFG.PriceYens) or 0) > 0 then return "Gratuit (perso animation)" end
		return price > 0 and string.format("%d yens", price) or (CFG.NPCSubtitle or "")
	end,
}

----------------------------------------------------------------------
-- Reception : le serveur a accepte +use, envoie la data character actuelle
-- et on ouvre le character creator en mode barber.
----------------------------------------------------------------------

-- Re-wrap les tables {r, g, b, a} en vrais Color objects (avec metatable) car
-- net.ReadTable les transfere comme tables nues -> certains widgets du
-- character creator font IsColor() / utilisent les methodes Color, ce qui
-- echoue si on garde des tables nues.
local COLOR_FIELDS = {
	"hair_color1", "hair_color2", "hair_details_color", "eyes_color",
	"tattoo_color", "tattoo_color_2",
}

-- Champs qui doivent etre des numbers cote client. La DB peut les retourner
-- comme strings ("3" au lieu de 3) selon le driver SQL, ce qui casse les
-- comparaisons d'egalite avec les .id des selectors (Lua "3" ~= 3).
-- Sans ce cast, la couleur de peau / scale / etc. du joueur ne s'affichent
-- pas comme selectionnees dans l'editeur (le preset visuel n'apparait pas).
local NUMBER_FIELDS = {
	"skin_color", "scale", "hair_gradient_angle",
	"tattoo_pos_x", "tattoo_pos_y", "tattoo_scale_x", "tattoo_scale_y",
	"tattoo_opacity", "tattoo_rotation",
	"tattoo_pos_x_2", "tattoo_pos_y_2", "tattoo_scale_x_2", "tattoo_scale_y_2",
	"tattoo_opacity_2", "tattoo_rotation_2",
}

local function rewrapColors(data)
	for _, field in ipairs(COLOR_FIELDS) do
		local v = data[field]
		if istable(v) and not IsColor(v) and v.r and v.g and v.b then
			data[field] = Color(v.r, v.g, v.b, v.a or 255)
		end
	end
	for _, field in ipairs(NUMBER_FIELDS) do
		local v = data[field]
		if v ~= nil and not isnumber(v) then
			data[field] = tonumber(v) or 0
		end
	end
end

net.Receive("LZY_Coiffeur:OpenEditor", function()
	local data = net.ReadTable()
	if not istable(data) then return end

	rewrapColors(data)

	-- Flag global lu par cl_character_creation pour passer en mode edit.
	LZY_CHARACTER_BARBER_MODE = true
	LZY_CHARACTER_BARBER_DATA = data

	-- Ouvre l'editeur. La fonction OpenCharacterCreator() est definie dans
	-- lzy_character / cl_character_creation.lua et instancie le panneau.
	if OpenCharacterCreator then
		OpenCharacterCreator()
	else
		MUGEN.Notify("[Coiffeur] OpenCharacterCreator introuvable - addon lzy_character non charge ?", NOTIFY_ERROR, 5)
	end
end)

----------------------------------------------------------------------
-- API client : appele par cl_character_creation a la sauvegarde quand
-- LZY_CHARACTER_BARBER_MODE est true. Envoie la character data au serveur
-- qui fera l'update DB + broadcast.
----------------------------------------------------------------------

-- ── Confirmation de PAIEMENT (demande user 2026-07-20) ───────────────────────
-- Popup DA (même style que le soigneur PNJ) : prix + solde AVANT d'envoyer la
-- sauvegarde (= avant le débit serveur). L'éditeur est déjà FERMÉ quand on arrive
-- ici -> ANNULER = rien n'est appliqué NI payé.
surface.CreateFont("LZYCoif_CfTitle", { font = "Roboto", size = 26, weight = 800 })
surface.CreateFont("LZYCoif_CfBody",  { font = "Roboto", size = 19, weight = 500 })
surface.CreateFont("LZYCoif_CfBtn",   { font = "Roboto", size = 18, weight = 700 })

local function askPayConfirm(price, money, onYes)
	local canAfford = money >= price
	local W, H = 430, 200
	local f = vgui.Create("DFrame")
	f:SetSize(W, H) f:Center() f:SetTitle("") f:ShowCloseButton(false) f:MakePopup()
	if EVO_MakeEscClosable then EVO_MakeEscClosable(f) end
	f.Paint = function(_, w, h)
		surface.SetDrawColor(18, 18, 22, 245) surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 255, 255, 25) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("Coiffeur", "LZYCoif_CfTitle", w / 2, 26, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.format("Nouvelle coupe : %d yens", price), "LZYCoif_CfBody", w / 2, 72, Color(232, 179, 75), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.format("Tes yens : %d", money), "LZYCoif_CfBody", w / 2, 100,
			canAfford and Color(200, 200, 200) or Color(230, 90, 90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	local function mkB(x, label, col, colH, fn)
		local b = vgui.Create("DButton", f)
		b:SetText("") b:SetSize(180, 42) b:SetPos(x, H - 58)
		b.Paint = function(_, w, h)
			draw.RoundedBox(6, 0, 0, w, h, b:IsHovered() and colH or col)
			draw.SimpleText(label, "LZYCoif_CfBtn", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = fn
	end
	mkB(W / 2 - 190, "Confirmer (" .. price .. " ¥)",
		canAfford and Color(45, 150, 85) or Color(60, 60, 65),
		canAfford and Color(60, 180, 100) or Color(60, 60, 65), function()
		if not canAfford then surface.PlaySound("a4xy732ex6yeop2/g1kpyv29gwai.mp3") return end
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		f:Remove()
		onYes()
	end)
	mkB(W / 2 + 10, "Annuler", Color(60, 60, 65), Color(85, 85, 92), function()
		surface.PlaySound("a4xy732ex6yeop2/adgwz38nw3s9.mp3")
		f:Remove()
	end)
end

function LZY_COIFFEUR.SendSaveToServer(characterData)
	if not istable(characterData) then return end
	-- PrixPour : 0 pour un perso ANIMATION -> pas de popup de paiement, envoi direct.
	local price = CFG.PrixPour(LocalPlayer())
	if price > 0 then
		askPayConfirm(price, LocalPlayer():GetEvoNWInt("Money", 0), function()
			LZY_COIFFEUR._DoSendSave(characterData)
		end)
		return
	end
	LZY_COIFFEUR._DoSendSave(characterData)
end

-- Seulement les champs edites chez le coiffeur (miroir serveur HAIR_FIELDS).
-- shape_keys : sourcils uniquement côté serveur (merge ciblé, pas de wipe visage).
local SAVE_FIELDS = {
	"hair_model", "hair_color1", "hair_color2", "hair_details_color",
	"hair_gradient_angle", "hide_hair",
	"beard_model", "mustache_model",
	"shape_keys", "shapeKeysByName",
}

function LZY_COIFFEUR._DoSendSave(characterData)
	local payload = {}
	for _, field in ipairs(SAVE_FIELDS) do
		if characterData[field] ~= nil then payload[field] = characterData[field] end
	end

	net.Start("LZY_Coiffeur:SaveEdit")
	net.WriteTable(payload)
	net.SendToServer()

	-- Force le refresh HUD a plusieurs instants pour gerer la latence du
	-- broadcast serveur. Le path normal (server -> broadcast -> client receive
	-- -> ply:HUD_UpdatePlayerModel) marche en theorie, mais en pratique il y a
	-- des races avec la fermeture du panel character creator et son
	-- CleanupClientsideModels qui peuvent laisser le HUD dans un etat
	-- inconsistant. Refresh manuel et insistant = solution la plus robuste.
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp.HUD_UpdatePlayerModel then return end
	for _, delay in ipairs({ 0.1, 0.4, 0.8, 1.5 }) do
		timer.Simple(delay, function()
			if IsValid(lp) and lp.HUD_UpdatePlayerModel then
				lp:HUD_UpdatePlayerModel()
			end
		end)
	end
end
